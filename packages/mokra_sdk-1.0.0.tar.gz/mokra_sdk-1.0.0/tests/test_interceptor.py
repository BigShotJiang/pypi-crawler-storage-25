"""Tests for mockworld.interceptor module."""

import pytest
import responses

from mokra.config import configure
from mokra.interceptor import (
    _should_intercept,
    _rewrite_url,
    _add_auth_headers,
    install_interceptor,
    uninstall_interceptor,
)


class TestShouldIntercept:
    """Tests for _should_intercept() function."""

    def test_returns_false_when_not_active(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")
        # Interceptor not installed, should return False
        assert _should_intercept("https://api.stripe.com/v1/charges") is False

    def test_returns_false_without_base_url(self):
        # No base_url configured
        install_interceptor()
        try:
            assert _should_intercept("https://api.stripe.com/v1/charges") is False
        finally:
            uninstall_interceptor()

    def test_returns_false_for_mock_server_url(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")
        install_interceptor()
        try:
            # Should not intercept requests to the mock server itself
            assert _should_intercept("https://api.mokra.ai/api/health") is False
        finally:
            uninstall_interceptor()

    def test_returns_false_for_unknown_service(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")
        install_interceptor()
        try:
            assert _should_intercept("https://unknown.example.com/api") is False
        finally:
            uninstall_interceptor()

    def test_returns_true_for_known_service(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")
        install_interceptor()
        try:
            assert _should_intercept("https://api.stripe.com/v1/charges") is True
        finally:
            uninstall_interceptor()


class TestRewriteUrl:
    """Tests for _rewrite_url() function."""

    def test_rewrites_stripe_url(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")
        result = _rewrite_url("https://api.stripe.com/v1/charges")
        assert result == "https://api.mokra.ai/api/mock/stripe/v1/charges"

    def test_preserves_query_string(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")
        result = _rewrite_url("https://api.stripe.com/v1/charges?limit=10")
        assert result == "https://api.mokra.ai/api/mock/stripe/v1/charges?limit=10"

    def test_returns_original_without_base_url(self):
        # No base_url configured
        result = _rewrite_url("https://api.stripe.com/v1/charges")
        assert result == "https://api.stripe.com/v1/charges"

    def test_returns_original_for_unknown_service(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")
        result = _rewrite_url("https://unknown.example.com/api")
        assert result == "https://unknown.example.com/api"


class TestAddAuthHeaders:
    """Tests for _add_auth_headers() function."""

    def test_adds_api_key_header(self):
        configure(api_key="test-key")
        result = _add_auth_headers({})
        assert "X-API-Key" in result
        assert result["X-API-Key"] == "test-key"

    def test_preserves_existing_headers(self):
        configure(api_key="test-key")
        result = _add_auth_headers({"Content-Type": "application/json"})
        assert result["Content-Type"] == "application/json"
        assert result["X-API-Key"] == "test-key"

    def test_handles_none_headers(self):
        configure(api_key="test-key")
        result = _add_auth_headers(None)
        assert result["X-API-Key"] == "test-key"

    def test_adds_context_headers_with_original_url(self):
        configure(api_key="test-key", base_url="https://api.mokra.ai/api")
        result = _add_auth_headers({}, "https://api.stripe.com/v1/charges")
        assert result["X-Mockworld-Original-Host"] == "api.stripe.com"
        assert result["X-Mockworld-Original-URL"] == "https://api.stripe.com/v1/charges"


class TestInstallUninstallInterceptor:
    """Tests for install_interceptor() and uninstall_interceptor()."""

    def test_install_and_uninstall(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        # Before install
        assert _should_intercept("https://api.stripe.com/v1/charges") is False

        install_interceptor()
        assert _should_intercept("https://api.stripe.com/v1/charges") is True

        uninstall_interceptor()
        assert _should_intercept("https://api.stripe.com/v1/charges") is False

    def test_multiple_installs_safe(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        install_interceptor()
        install_interceptor()  # Should not cause issues

        assert _should_intercept("https://api.stripe.com/v1/charges") is True

        uninstall_interceptor()
        assert _should_intercept("https://api.stripe.com/v1/charges") is False


class TestInterceptorIntegration:
    """Integration tests for HTTP interception."""

    @responses.activate
    def test_intercepts_requests_to_known_service(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        # Mock the mock server endpoint
        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/mock/stripe/v1/charges",
            json={"id": "ch_123", "status": "succeeded"},
            status=200,
        )

        install_interceptor()
        try:
            import requests
            response = requests.post(
                "https://api.stripe.com/v1/charges",
                json={"amount": 1000, "currency": "usd"},
            )
            assert response.status_code == 200
            assert response.json()["id"] == "ch_123"
        finally:
            uninstall_interceptor()

    @responses.activate
    def test_does_not_intercept_unknown_service(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        # Mock the actual endpoint (not mock server)
        responses.add(
            responses.GET,
            "https://unknown.example.com/api/data",
            json={"data": "original"},
            status=200,
        )

        install_interceptor()
        try:
            import requests
            response = requests.get("https://unknown.example.com/api/data")
            assert response.status_code == 200
            assert response.json()["data"] == "original"
        finally:
            uninstall_interceptor()

    @responses.activate
    def test_adds_auth_headers_to_intercepted_request(self):
        configure(base_url="https://api.mokra.ai/api", api_key="my-secret-key")

        def request_callback(request):
            # Verify auth header was added
            assert request.headers["X-API-Key"] == "my-secret-key"
            return (200, {}, '{"success": true}')

        responses.add_callback(
            responses.GET,
            "https://api.mokra.ai/api/mock/github/repos/user/repo",
            callback=request_callback,
            content_type="application/json",
        )

        install_interceptor()
        try:
            import requests
            response = requests.get("https://api.github.com/repos/user/repo")
            assert response.status_code == 200
        finally:
            uninstall_interceptor()

    @responses.activate
    def test_preserves_original_request_body(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        def request_callback(request):
            import json
            body = json.loads(request.body)
            assert body["amount"] == 5000
            assert body["currency"] == "eur"
            return (200, {}, '{"id": "ch_456"}')

        responses.add_callback(
            responses.POST,
            "https://api.mokra.ai/api/mock/stripe/v1/charges",
            callback=request_callback,
            content_type="application/json",
        )

        install_interceptor()
        try:
            import requests
            response = requests.post(
                "https://api.stripe.com/v1/charges",
                json={"amount": 5000, "currency": "eur"},
            )
            assert response.status_code == 200
        finally:
            uninstall_interceptor()
