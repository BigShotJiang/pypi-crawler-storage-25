"""Tests for mockworld.world module."""

import pytest
import responses

from mokra.config import configure
from mokra.world import (
    World,
    State,
    StateRecord,
    ResourceState,
    mockworld,
    get_current_world,
    get_current_test_id,
    get_current_run_id,
)


class TestStateRecord:
    """Tests for StateRecord class."""

    def test_id_property(self):
        record = StateRecord({"id": "rec_123", "name": "Test"})
        assert record.id == "rec_123"

    def test_id_returns_none_if_missing(self):
        record = StateRecord({"name": "Test"})
        assert record.id is None

    def test_getitem(self):
        record = StateRecord({"id": "rec_123", "name": "Test", "value": 42})
        assert record["name"] == "Test"
        assert record["value"] == 42
        assert record["missing"] is None

    def test_repr(self):
        record = StateRecord({"id": "rec_123"})
        assert "StateRecord" in repr(record)
        assert "rec_123" in repr(record)


class TestResourceState:
    """Tests for ResourceState class."""

    def test_count(self):
        state = ResourceState("products", [{"id": "1"}, {"id": "2"}, {"id": "3"}])
        assert state.count == 3

    def test_records(self):
        state = ResourceState("products", [{"id": "1"}, {"id": "2"}])
        records = state.records
        assert len(records) == 2
        assert all(isinstance(r, StateRecord) for r in records)

    def test_find_by_id(self):
        state = ResourceState("products", [
            {"id": "prod_1", "name": "Product 1"},
            {"id": "prod_2", "name": "Product 2"},
        ])
        record = state.find_by_id("prod_2")
        assert record is not None
        assert record["name"] == "Product 2"

    def test_find_by_id_returns_none_if_not_found(self):
        state = ResourceState("products", [{"id": "prod_1"}])
        assert state.find_by_id("nonexistent") is None

    def test_repr(self):
        state = ResourceState("products", [{"id": "1"}])
        assert "ResourceState" in repr(state)
        assert "products" in repr(state)


class TestState:
    """Tests for State class."""

    def test_total(self):
        state = State({
            "products": [{"id": "1"}, {"id": "2"}],
            "orders": [{"id": "3"}],
        })
        assert state.total == 3

    def test_resource_types(self):
        state = State({
            "products": [{"id": "1"}],
            "orders": [{"id": "2"}],
        })
        assert set(state.resource_types) == {"products", "orders"}

    def test_getitem(self):
        state = State({"products": [{"id": "1", "name": "Test"}]})
        products = state["products"]
        assert isinstance(products, ResourceState)
        assert products.count == 1

    def test_getitem_returns_empty_for_unknown(self):
        state = State({"products": [{"id": "1"}]})
        orders = state["orders"]
        assert isinstance(orders, ResourceState)
        assert orders.count == 0

    def test_repr(self):
        state = State({"products": [{"id": "1"}]})
        assert "State" in repr(state)


class TestMockworldFunction:
    """Tests for mockworld() factory function."""

    def test_raises_without_name(self):
        with pytest.raises(ValueError, match="name is required"):
            mockworld(None)  # type: ignore

    @responses.activate
    def test_creates_world_with_string_services(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={
                "mockworld": {
                    "id": "test_123",
                    "mockServers": [
                        {"mockServerId": "ms_1", "mockServer": {"id": "ms_1", "service": {"slug": "stripe"}}},
                        {"mockServerId": "ms_2", "mockServer": {"id": "ms_2", "service": {"slug": "shopify"}}},
                    ],
                },
            },
            status=200,
        )

        world = mockworld("my test", "stripe", "shopify")
        assert world.id == "test_123"
        assert "stripe" in world.services
        assert "shopify" in world.services

    @responses.activate
    def test_creates_world_with_keyword_style(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={
                "mockworld": {
                    "id": "test_456",
                    "mockServers": [
                        {"mockServerId": "ms_1", "mockServer": {"id": "ms_1", "service": {"slug": "stripe"}}},
                    ],
                },
            },
            status=200,
        )

        world = mockworld(name="Refund test", services_list=["stripe"])
        assert world.id == "test_456"

    @responses.activate
    def test_creates_world_with_dict_services(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        def request_callback(request):
            import json
            body = json.loads(request.body)
            services = body["services"]
            assert len(services) == 2
            assert services[0]["name"] == "stripe"
            assert services[1]["name"] == "shopify"
            assert services[1]["serverId"] == "existing_ms_id"
            return (200, {}, '{"mockworld": {"id": "test_789", "mockServers": []}}')

        responses.add_callback(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            callback=request_callback,
            content_type="application/json",
        )

        world = mockworld(
            "my test",
            "stripe",
            {"name": "shopify", "server_id": "existing_ms_id"},
        )
        assert world.id == "test_789"


class TestWorld:
    """Tests for World class."""

    @responses.activate
    def test_raises_without_base_url(self):
        # No base_url configured
        with pytest.raises(ValueError, match="base_url not configured"):
            World("test", [{"name": "stripe"}])

    @responses.activate
    def test_run_with_function(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        # Mock createMockworld
        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={
                "mockworld": {
                    "id": "test_123",
                    "mockServers": [{"mockServerId": "ms_1", "mockServer": {"id": "ms_1", "service": {"slug": "stripe"}}}],
                },
            },
            status=200,
        )

        # Mock create run
        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/tests/test_123/runs",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        # Mock complete run
        responses.add(
            responses.PATCH,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123",
            json={"run": {"id": "run_123", "status": "PASSED"}},
            status=200,
        )

        world = World("test", [{"name": "stripe"}])

        result = []
        def agent_code(services):
            result.append("executed")
            return "done"

        ret = world.run(agent_code)
        assert ret == "done"
        assert result == ["executed"]

    @responses.activate
    def test_run_as_context_manager(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={
                "mockworld": {
                    "id": "test_123",
                    "mockServers": [{"mockServerId": "ms_1", "mockServer": {"id": "ms_1", "service": {"slug": "stripe"}}}],
                },
            },
            status=200,
        )

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/tests/test_123/runs",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        responses.add(
            responses.PATCH,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123",
            json={"run": {"id": "run_123", "status": "PASSED"}},
            status=200,
        )

        world = World("test", [{"name": "stripe"}])

        executed = False
        with world.run() as services:
            executed = True
            assert isinstance(services, dict)

        assert executed

    @responses.activate
    def test_observe(self, capsys):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={
                "mockworld": {
                    "id": "test_123",
                    "mockServers": [],
                },
            },
            status=200,
        )

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/tests/test_123/runs",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        responses.add(
            responses.PATCH,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        responses.add(
            responses.GET,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123",
            json={
                "run": {
                    "observations": [
                        {
                            "type": "HTTP_REQUEST",
                            "httpMethod": "POST",
                            "httpUrl": "https://api.stripe.com/v1/charges",
                            "httpStatus": 200,
                        },
                    ],
                },
            },
            status=200,
        )

        world = World("test", [{"name": "stripe"}])
        with world.run():
            pass

        observations = world.observe()
        assert len(observations) == 1
        assert observations[0]["type"] == "HTTP_REQUEST"

        captured = capsys.readouterr()
        assert "POST" in captured.out
        assert "stripe.com" in captured.out

    @responses.activate
    def test_assert_raises_on_failure(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={"mockworld": {"id": "test_123", "mockServers": []}},
            status=200,
        )

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/tests/test_123/runs",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        responses.add(
            responses.PATCH,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123/assert",
            json={
                "results": [
                    {"passed": False, "assertion": "a charge was created"},
                ],
            },
            status=200,
        )

        world = World("test", [{"name": "stripe"}])
        with world.run():
            pass

        with pytest.raises(AssertionError, match="Assertion.*failed"):
            world.assert_("a charge was created")

    @responses.activate
    def test_assert_passes(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={"mockworld": {"id": "test_123", "mockServers": []}},
            status=200,
        )

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/tests/test_123/runs",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        responses.add(
            responses.PATCH,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123/assert",
            json={
                "results": [
                    {"passed": True, "assertion": "a charge was created"},
                ],
            },
            status=200,
        )

        world = World("test", [{"name": "stripe"}])
        with world.run():
            pass

        # Should not raise
        results = world.assert_("a charge was created")
        assert len(results) == 1
        assert results[0]["passed"] is True

    @responses.activate
    def test_state(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={
                "mockworld": {
                    "id": "test_123",
                    "mockServers": [{"mockServerId": "ms_1", "mockServer": {"id": "ms_1", "service": {"slug": "stripe"}}}],
                },
            },
            status=200,
        )

        responses.add(
            responses.GET,
            "https://api.mokra.ai/api/mock-servers/ms_1/state",
            json={
                "charges": [
                    {"id": "ch_1", "amount": 1000},
                    {"id": "ch_2", "amount": 2000},
                ],
                "customers": [
                    {"id": "cus_1", "email": "test@example.com"},
                ],
            },
            status=200,
        )

        world = World("test", [{"name": "stripe"}])
        state = world.state()

        assert state.total == 3
        assert "charges" in state.resource_types
        assert "customers" in state.resource_types
        assert state["charges"].count == 2
        assert state["customers"].count == 1


class TestContextFunctions:
    """Tests for context tracking functions."""

    @responses.activate
    def test_get_current_world_during_run(self):
        configure(base_url="https://api.mokra.ai/api", api_key="test-key")

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/createMockworld",
            json={"mockworld": {"id": "test_123", "mockServers": []}},
            status=200,
        )

        responses.add(
            responses.POST,
            "https://api.mokra.ai/api/tests/test_123/runs",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        responses.add(
            responses.PATCH,
            "https://api.mokra.ai/api/tests/test_123/runs/run_123",
            json={"run": {"id": "run_123"}},
            status=200,
        )

        world = World("test", [{"name": "stripe"}])

        captured_world = None
        captured_test_id = None
        captured_run_id = None

        def agent_code(services):
            nonlocal captured_world, captured_test_id, captured_run_id
            captured_world = get_current_world()
            captured_test_id = get_current_test_id()
            captured_run_id = get_current_run_id()

        world.run(agent_code)

        assert captured_world is world
        assert captured_test_id == "test_123"
        assert captured_run_id == "run_123"

    def test_get_current_world_outside_run(self):
        assert get_current_world() is None
        assert get_current_test_id() is None
        assert get_current_run_id() is None
