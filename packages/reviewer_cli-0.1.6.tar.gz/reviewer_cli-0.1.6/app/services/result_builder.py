from datetime import datetime, timedelta, timezone

from app.models.analysis import (
    AnalysisContext,
    AnalysisCoverage,
    ChangedFilePreviewGroup,
    CheckRunSummary,
    ClassifiedFile,
    GithubCommitSummary,
    GithubPrMetadata,
    PrAnalysisResult,
    RiskSignal,
    SafeguardSummary,
    ScoreSummary,
    TopRiskFile,
)
from app.models.review_domain import ReviewAnalysis, ReviewFinding
from app.services.recommendation_engine import generate_recommendations
from app.services.scoring_engine import compute_score


analysis_limitations = [
    "This analysis does not inspect deployment health or real coverage deltas yet.",
    "Patch structure hints are based on changed hunks, not full repository semantics.",
    "Reviewer does not compute real coverage deltas or repository-wide dependency graphs yet.",
]


historical_ci_cutoff_days = 30

TOP_FILE_REASON_LABELS = {
    "migration": "schema or migration path changed",
    "config": "runtime or workflow configuration changed",
    "dependency": "dependency surface changed",
    "shared_core": "shared or reused code touched",
    "middleware": "request or auth flow touched",
    "api": "API boundary changed",
    "frontend": "user-facing behavior may shift",
    "backend": "server-side behavior changed",
    "test": "tests changed alongside implementation",
    "generated": "generated output changed",
    "lockfile": "lockfile or dependency pin changed",
}


def build_affected_areas(files: list[ClassifiedFile]) -> list[str]:
    tags: set[str] = set()
    for file in files:
        for tag in file.tags:
            tags.add(tag)
    return list(tags)[:10]


def build_review_focus(signals: list[RiskSignal]) -> list[str]:
    ranked_signals = sorted(
        [signal for signal in signals if signal.score_impact < 0],
        key=lambda item: (item.severity == "high", abs(item.score_impact)),
        reverse=True,
    )
    return [signal.label for signal in ranked_signals[:3]]


def build_analysis_coverage(
    files: list[ClassifiedFile],
    total_files: int,
    partial_reasons: list[str],
) -> AnalysisCoverage:
    patchless_files = sum(1 for file in files if not file.patch)
    files_analyzed = len(files)
    normalized_total_files = max(total_files, files_analyzed)
    coverage_partial_reasons = list(partial_reasons)

    if patchless_files > 0:
        coverage_partial_reasons.append(
            f"GitHub did not provide patch hunks for {patchless_files} changed files, so structure hints are limited there."
        )

    return AnalysisCoverage(
        files_analyzed=files_analyzed,
        total_files=normalized_total_files,
        patchless_files=patchless_files,
        is_partial=bool(coverage_partial_reasons),
        partial_reasons=coverage_partial_reasons,
    )


def is_historical_merged_pr(metadata: GithubPrMetadata) -> bool:
    if not metadata.merged:
        return False

    timestamp = metadata.merged_at or metadata.updated_at
    try:
        parsed_at = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
    except ValueError:
        return False

    return datetime.now(timezone.utc) - parsed_at >= timedelta(days=historical_ci_cutoff_days)


def build_safeguards(
    metadata: GithubPrMetadata,
    files: list[ClassifiedFile],
    check_runs: list[CheckRunSummary],
) -> SafeguardSummary:
    tests_changed = any("test" in file.areas for file in files)
    checks_passed = sum(
        1
        for check_run in check_runs
        if check_run.status.lower() == "completed" and (check_run.conclusion or "").lower() in {"success", "neutral", "skipped"}
    )
    checks_failed = sum(
        1
        for check_run in check_runs
        if (check_run.conclusion or "").lower() in {"failure", "timed_out", "cancelled", "action_required"}
    )
    checks_pending = any(
        check_run.status.lower() in {"queued", "in_progress", "waiting", "requested", "pending"}
        for check_run in check_runs
    )
    missing_safeguards: list[str] = []
    historical_merged_pr = is_historical_merged_pr(metadata)

    if checks_failed > 0:
        ci_state = "failing"
        missing_safeguards.append("At least one CI check is failing on the PR head commit.")
    elif checks_pending:
        ci_state = "pending"
        missing_safeguards.append("Some CI checks are still running, so merge safety is not fully known yet.")
    elif not check_runs and historical_merged_pr:
        ci_state = "unavailable"
    elif not check_runs:
        ci_state = "missing"
        missing_safeguards.append("No GitHub check runs were reported for the PR head commit.")
    elif checks_passed == len(check_runs):
        ci_state = "passing"
    else:
        ci_state = "unknown"
        missing_safeguards.append("GitHub check runs returned mixed or unclear conclusions.")

    if not tests_changed and any("test" not in file.areas and "docs" not in file.areas for file in files):
        missing_safeguards.append("No test files changed in this PR.")

    if ci_state == "passing" and tests_changed and not missing_safeguards:
        summary = "CI checks are passing and this PR includes test changes."
    elif ci_state == "passing" and not tests_changed:
        summary = "CI checks are passing, but no test files changed in this PR."
    elif ci_state == "failing":
        summary = "CI checks are failing on the PR head commit."
    elif ci_state == "pending":
        summary = "CI checks are still running for the PR head commit."
    elif ci_state == "missing":
        summary = "No CI check runs were reported for the PR head commit."
    elif ci_state == "unavailable":
        summary = "GitHub no longer exposes CI checks for this historical merged PR."
    else:
        summary = "CI check status is unclear for the PR head commit."

    return SafeguardSummary(
        ci_state=ci_state,
        summary=summary,
        checks_total=len(check_runs),
        checks_passed=checks_passed,
        checks_failed=checks_failed,
        tests_changed=tests_changed,
        missing_safeguards=missing_safeguards,
        check_runs=check_runs[:10],
    )


def build_confidence_in_score(
    files: list[ClassifiedFile],
    signals: list[RiskSignal],
    commits: list[GithubCommitSummary],
    coverage: AnalysisCoverage,
    cache_status: str,
    safeguards: SafeguardSummary,
) -> str:
    if cache_status == "fallback" or coverage.is_partial:
        return "low"

    if safeguards.ci_state in {"failing", "missing"}:
        return "low"

    if safeguards.ci_state in {"pending", "unknown", "unavailable"}:
        return "medium"

    if len(files) >= 35 or len(commits) >= 20:
        return "low"

    if len(files) <= 8 and len(signals) <= 4 and coverage.patchless_files == 0:
        return "high"

    return "medium"


def build_confidence_summary(
    files: list[ClassifiedFile],
    commits: list[GithubCommitSummary],
    cache_status: str,
    coverage: AnalysisCoverage,
) -> str:
    scope_summary = f"{coverage.files_analyzed} of {coverage.total_files} changed files analyzed"
    patch_summary = f"{coverage.patchless_files} files without patch hunks" if coverage.patchless_files else "full patch hints where available"

    if cache_status == "fallback":
        return (
            f"Showing the latest saved analysis because GitHub could not serve a fresh review right now. "
            f"Saved context covers {scope_summary} and {len(commits)} commits. Patch coverage note: {patch_summary}."
        )

    if len(files) >= 35 or len(commits) >= 20:
        return (
            f"Built from GitHub metadata, {scope_summary}, {len(commits)} commits, rule-based risk scoring, "
            f"and patch-level structure hints. The review surface is broad enough that this score should guide triage more than final approval. "
            f"Patch coverage note: {patch_summary}. Response source: {cache_status}."
        )

    return (
        f"Built from GitHub metadata, {scope_summary}, {len(commits)} commits, rule-based risk scoring, "
        f"and patch-level structure hints. Patch coverage note: {patch_summary}. Response source: {cache_status}."
    )


def pick_group_files(files: list[ClassifiedFile], matcher) -> list[ClassifiedFile]:
    return sorted(
        [file for file in files if matcher(file)],
        key=lambda item: (item.blast_radius_weight, item.changes),
        reverse=True,
    )[:5]


def build_file_groups(files: list[ClassifiedFile]) -> list[ChangedFilePreviewGroup]:
    groups = [
        ChangedFilePreviewGroup(
            label="Highest risk",
            files=pick_group_files(files, lambda file: file.is_sensitive or file.blast_radius_weight >= 4),
        ),
        ChangedFilePreviewGroup(
            label="Config / Infra",
            files=pick_group_files(
                files,
                lambda file: "config" in file.areas or "dependency" in file.areas or "infra" in file.areas,
            ),
        ),
        ChangedFilePreviewGroup(
            label="Shared / Core",
            files=pick_group_files(files, lambda file: "shared_core" in file.areas or "api" in file.areas),
        ),
        ChangedFilePreviewGroup(
            label="Tests",
            files=pick_group_files(files, lambda file: "test" in file.areas),
        ),
    ]

    return [group for group in groups if group.files]


def build_patch_excerpt(file: ClassifiedFile, max_lines: int = 8) -> list[str]:
    if not file.patch:
        return []

    excerpt_lines: list[str] = []

    for patch_line in file.patch.splitlines():
        if patch_line.startswith("@@"):
            if excerpt_lines:
                break
            excerpt_lines.append(patch_line[:180])
            continue

        if not patch_line.startswith(("+", "-")) or patch_line.startswith(("+++", "---")):
            continue

        trimmed_line = patch_line.rstrip()
        if not trimmed_line:
            continue

        excerpt_lines.append(trimmed_line[:180])
        if len(excerpt_lines) >= max_lines:
            break

    return excerpt_lines


def build_reviewer_hints(file: ClassifiedFile) -> list[str]:
    reviewer_hints: list[str] = []

    if "backend" in file.areas or "api" in file.areas or "middleware" in file.areas:
        reviewer_hints.append("backend reviewer")

    if "frontend" in file.areas:
        reviewer_hints.append("frontend reviewer")

    if "migration" in file.areas or "database" in file.symbol_hints:
        reviewer_hints.append("data reviewer")

    if "config" in file.areas or "infra" in file.areas or "dependency" in file.areas:
        reviewer_hints.append("platform reviewer")

    if "shared_core" in file.areas:
        reviewer_hints.append("core maintainer")

    if "test" in file.areas:
        reviewer_hints.append("test owner")

    return reviewer_hints[:3] or ["code owner"]


def build_file_reasons(file: ClassifiedFile, test_files_present: bool) -> list[str]:
    reasons: list[str] = []

    if file.is_sensitive:
        reasons.append("sensitive execution path touched")

    if file.blast_radius_weight >= 4:
        reasons.append("high blast radius across shared code")
    elif file.blast_radius_weight >= 3:
        reasons.append("moderate blast radius")

    if file.status == "renamed" and file.previous_filename:
        reasons.append(f"renamed from {file.previous_filename}")

    for area in file.areas:
        label = TOP_FILE_REASON_LABELS.get(area)
        if label and label not in reasons:
            reasons.append(label)

    if file.symbol_hints:
        reasons.append(f"structural hints: {', '.join(file.symbol_hints[:2])}")

    if not test_files_present and (file.is_sensitive or file.blast_radius_weight >= 4):
        reasons.append("no test changes detected for this risk area")

    if not file.patch:
        reasons.append("patch hunk unavailable from GitHub")

    if file.changes >= 120:
        reasons.append(f"large diff footprint ({file.changes} lines)")
    elif file.changes >= 50:
        reasons.append(f"meaningful diff footprint ({file.changes} lines)")

    return reasons[:4] or ["changed in this pull request"]


def compute_top_file_score(file: ClassifiedFile, test_files_present: bool) -> int:
    score = file.blast_radius_weight * 10 + min(file.changes, 180)

    if file.is_sensitive:
        score += 25

    if "migration" in file.areas:
        score += 20

    if "config" in file.areas or "dependency" in file.areas:
        score += 14

    if "shared_core" in file.areas or "api" in file.areas or "middleware" in file.areas:
        score += 10

    if file.symbol_hints:
        score += 8

    if file.status == "renamed" and file.previous_filename:
        score += 6

    if not test_files_present and (file.is_sensitive or file.blast_radius_weight >= 4):
        score += 12

    if "generated" in file.areas or "asset" in file.areas:
        score -= 10

    return score


def build_top_risk_files(files: list[ClassifiedFile]) -> list[TopRiskFile]:
    test_files_present = any("test" in file.areas for file in files)

    ranked_files = sorted(
        files,
        key=lambda file: (compute_top_file_score(file, test_files_present), file.changes),
        reverse=True,
    )[:5]

    top_files: list[TopRiskFile] = []
    for file in ranked_files:
        file_score = compute_top_file_score(file, test_files_present)
        if file_score >= 70:
            risk_level = "high"
        elif file_score >= 40:
            risk_level = "medium"
        else:
            risk_level = "low"

        top_files.append(
            TopRiskFile(
                filename=file.filename,
                risk_level=risk_level,
                reasons=build_file_reasons(file, test_files_present),
                reviewer_hints=build_reviewer_hints(file),
                patch_excerpt=build_patch_excerpt(file),
                changes=file.changes,
                areas=file.areas,
                is_sensitive=file.is_sensitive,
                blob_url=file.blob_url,
            )
        )

    return top_files


def build_findings(
    signals: list[RiskSignal],
    top_risk_files: list[TopRiskFile],
    recommendations: list,
    safeguards: SafeguardSummary,
    confidence_in_score: str,
) -> list[ReviewFinding]:
    findings: list[ReviewFinding] = []

    for signal in signals[:5]:
        findings.append(
            ReviewFinding(
                id=f"signal:{signal.id}",
                severity=signal.severity,
                confidence=confidence_in_score,
                category="signal",
                title=signal.label,
                body=signal.evidence[0] if signal.evidence else "Reviewer detected a risk signal without explicit evidence text.",
                evidence=signal.evidence[:4],
                suggested_action="Review the attached evidence before approving the pull request.",
            )
        )

    for file in top_risk_files[:5]:
        findings.append(
            ReviewFinding(
                id=f"file:{file.filename}",
                severity=file.risk_level,
                confidence="medium" if file.patch_excerpt else "low",
                category="file",
                title=f"Inspect {file.filename}",
                body=file.reasons[0] if file.reasons else "Reviewer ranked this file near the top of the review queue.",
                path=file.filename,
                evidence=file.reasons[:4],
                blob_url=file.blob_url,
                suggested_action=file.reviewer_hints[0] if file.reviewer_hints else "Open this file first.",
            )
        )

    if safeguards.ci_state in {"failing", "pending", "missing", "unknown"}:
        findings.append(
            ReviewFinding(
                id=f"safeguard:{safeguards.ci_state}",
                severity="high" if safeguards.ci_state == "failing" else "medium",
                confidence="high",
                category="safeguard",
                title="Check merge safeguards",
                body=safeguards.summary,
                evidence=safeguards.missing_safeguards[:4],
                suggested_action="Verify CI and test coverage before merging.",
            )
        )

    for recommendation in recommendations[:3]:
        findings.append(
            ReviewFinding(
                id=f"recommendation:{recommendation.id}",
                severity="medium" if recommendation.priority == "now" else "low",
                confidence=confidence_in_score,
                category="recommendation",
                title=recommendation.title,
                body=recommendation.detail,
                evidence=[recommendation.detail],
                suggested_action=recommendation.title,
            )
        )

    return findings


def build_review_analysis(
    metadata: GithubPrMetadata,
    files: list[ClassifiedFile],
    commits: list[GithubCommitSummary],
    signals: list[RiskSignal],
    check_runs: list[CheckRunSummary] | None = None,
    cache_status: str = "live",
    total_files: int | None = None,
    partial_reasons: list[str] | None = None,
) -> ReviewAnalysis:
    score_payload = compute_score(signals)
    coverage = build_analysis_coverage(files, total_files or len(files), partial_reasons or [])
    safeguards = build_safeguards(metadata, files, check_runs or [])
    confidence_in_score = build_confidence_in_score(files, signals, commits, coverage, cache_status, safeguards)
    recommendations = generate_recommendations(signals)
    top_risk_files = build_top_risk_files(files)
    summary = build_confidence_summary(files, commits, cache_status, coverage)

    return ReviewAnalysis(
        metadata=metadata,
        score=score_payload["score"],
        label=score_payload["label"],
        verdict=score_payload["verdict"],
        summary=summary,
        review_focus=build_review_focus(signals),
        affected_areas=build_affected_areas(files),
        risk_breakdown=score_payload["risk_breakdown"],
        triggered_signals=signals,
        findings=build_findings(signals, top_risk_files, recommendations, safeguards, confidence_in_score),
        recommendations=recommendations,
        safeguards=safeguards,
        changed_file_groups=build_file_groups(files),
        top_risk_files=top_risk_files,
        commits=commits,
        score_summary=ScoreSummary(**score_payload["score_summary"]),
        analysis_context=AnalysisContext(
            confidence_in_score=confidence_in_score,
            summary=summary,
            limitations=analysis_limitations,
            data_sources=["GitHub PR metadata", "GitHub changed files", "GitHub commits", "rule-based risk engine"],
            cache_status=cache_status,
            coverage=coverage,
        ),
    )


def build_result(
    metadata: GithubPrMetadata,
    files: list[ClassifiedFile],
    commits: list[GithubCommitSummary],
    signals: list[RiskSignal],
    check_runs: list[CheckRunSummary] | None = None,
    cache_status: str = "live",
    total_files: int | None = None,
    partial_reasons: list[str] | None = None,
) -> PrAnalysisResult:
    review_analysis = build_review_analysis(
        metadata,
        files,
        commits,
        signals,
        check_runs=check_runs,
        cache_status=cache_status,
        total_files=total_files,
        partial_reasons=partial_reasons,
    )

    return PrAnalysisResult(
        metadata=review_analysis.metadata,
        score=review_analysis.score,
        label=review_analysis.label,
        verdict=review_analysis.verdict,
        review_focus=review_analysis.review_focus,
        affected_areas=review_analysis.affected_areas,
        risk_breakdown=review_analysis.risk_breakdown,
        triggered_signals=review_analysis.triggered_signals,
        recommendations=review_analysis.recommendations,
        safeguards=review_analysis.safeguards,
        changed_file_groups=review_analysis.changed_file_groups,
        top_risk_files=review_analysis.top_risk_files,
        commits=review_analysis.commits,
        score_summary=review_analysis.score_summary,
        analysis_context=review_analysis.analysis_context,
    )
