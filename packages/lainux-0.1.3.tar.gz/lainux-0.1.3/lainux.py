"""LAInux -- CyberSecAI OS. https://lainux.co.uk"""

def main():
    print('\n  LAInux -- CyberSecAI OS\n  https://lainux.co.uk\n')

if __name__ == '__main__':
    main()
