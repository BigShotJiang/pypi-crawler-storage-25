# LAInux

CyberSecAI OS.

https://lainux.co.uk

---

If you are monitoring our downloads -- you are warned. This and all CyberSecAI creations are protected under BSL 1.1 (Business Source License). We monitor all repositories, downloads, and usage. Any violations whatsoever will lead to legal action without further notice.

(c) CyberSecAI Ltd. All rights reserved.
