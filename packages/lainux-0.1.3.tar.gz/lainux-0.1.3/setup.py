from setuptools import setup

setup(
    name='lainux',
    version='0.1.3',
    description='CyberSecAI OS',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='CyberSecAI Ltd',
    url='https://lainux.co.uk',
    py_modules=['lainux'],
    entry_points={'console_scripts': ['lainux=lainux:main']},
    python_requires='>=3.8',
    license='BUSL-1.1',
    keywords='lainux',
)
