"""Shared CLI update helpers for SAGE.

This module centralizes version checks and self-update behavior so the
terminal backend, standard CLI, and REPL all use the same logic.
"""

from __future__ import annotations

from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path
import logging
import shutil
import subprocess
import sys
import threading
import time

from sage import __version__

logger = logging.getLogger("sage.updater")


@dataclass
class CLIVersion:
    """Version information for the installed CLI."""

    current: str
    latest: str
    update_available: bool


@dataclass
class CLIUpdateResult:
    """Outcome of an update check or update attempt."""

    ok: bool
    updated: bool
    attempted: bool
    current: str
    latest: str
    message: str


def build_sage_run_command() -> list[str]:
    """Build the most reliable `sage run` invocation for the current env."""

    executable_dir = Path(sys.executable).resolve().parent
    for name in ("sage", "sage.exe"):
        candidate = executable_dir / name
        if candidate.exists():
            return [str(candidate), "run"]

    sage_cmd = shutil.which("sage")
    if sage_cmd:
        return [sage_cmd, "run"]

    return [
        sys.executable,
        "-c",
        "import sys; sys.argv = ['sage', 'run']; from sage.main import app; app()",
    ]


class CLIAutoUpdater:
    """Handles update checks and in-place upgrades for sage-ai-cli."""

    PACKAGE_NAME = "sage-ai-cli"

    def __init__(self) -> None:
        self._cache_timeout = 300
        self._last_check = 0.0
        self._cached_version: CLIVersion | None = None
        self._lock = threading.Lock()

    def get_current_version(self) -> str:
        """Get the installed package version for the active Python env."""

        if __version__ and __version__ != "0.0.0":
            return __version__

        try:
            return package_version(self.PACKAGE_NAME)
        except PackageNotFoundError:
            return __version__
        except Exception as exc:
            logger.warning("Failed to read installed SAGE version: %s", exc)
            return __version__

    def get_latest_version(self) -> str:
        """Check pip index for the newest published version."""

        try:
            result = subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip",
                    "index",
                    "versions",
                    self.PACKAGE_NAME,
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode == 0 and "(" in result.stdout:
                return result.stdout.split("(", 1)[1].split(")", 1)[0].strip()
        except Exception as exc:
            logger.warning("Failed to check latest SAGE version: %s", exc)
        return self.get_current_version()

    def check_for_update(self, force: bool = False) -> CLIVersion:
        """Return current and latest version information."""

        now = time.time()
        if not force and self._cached_version and (now - self._last_check) < self._cache_timeout:
            return self._cached_version

        current = self.get_current_version()
        latest = self.get_latest_version()
        version = CLIVersion(
            current=current,
            latest=latest,
            update_available=self._compare_versions(current, latest) < 0,
        )
        self._cached_version = version
        self._last_check = now
        return version

    def apply_update(self) -> bool:
        """Upgrade sage-ai-cli in the current Python environment."""

        with self._lock:
            try:
                result = subprocess.run(
                    [
                        sys.executable,
                        "-m",
                        "pip",
                        "install",
                        "--upgrade",
                        "--disable-pip-version-check",
                        self.PACKAGE_NAME,
                    ],
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
                if result.returncode == 0:
                    self._cached_version = None
                    self._last_check = 0
                    logger.info("Successfully updated %s", self.PACKAGE_NAME)
                    return True
                logger.error("SAGE update failed: %s", result.stderr.strip())
            except Exception as exc:
                logger.error("Failed to apply SAGE update: %s", exc)
        return False

    def ensure_latest(self) -> CLIUpdateResult:
        """Check for updates and apply them when available."""

        version = self.check_for_update()
        if not version.update_available:
            return CLIUpdateResult(
                ok=True,
                updated=False,
                attempted=False,
                current=version.current,
                latest=version.latest,
                message=f"SAGE AI is already up to date (v{version.current}).",
            )

        success = self.apply_update()
        refreshed = self.check_for_update(force=True)
        if success:
            return CLIUpdateResult(
                ok=True,
                updated=True,
                attempted=True,
                current=refreshed.current,
                latest=refreshed.latest,
                message=(
                    f"Updated SAGE AI from v{version.current} to v{refreshed.current}."
                ),
            )

        return CLIUpdateResult(
            ok=False,
            updated=False,
            attempted=True,
            current=refreshed.current,
            latest=version.latest,
            message=(
                f"Failed to update SAGE AI from v{version.current} to v{version.latest}."
            ),
        )

    @staticmethod
    def _compare_versions(v1: str, v2: str) -> int:
        """Compare two version strings."""

        def parse(version: str) -> tuple[int, ...]:
            parts: list[int] = []
            for part in version.replace("-", ".").split("."):
                try:
                    parts.append(int(part))
                except ValueError:
                    parts.append(0)
            return tuple(parts)

        p1, p2 = parse(v1), parse(v2)
        if p1 < p2:
            return -1
        if p1 > p2:
            return 1
        return 0
