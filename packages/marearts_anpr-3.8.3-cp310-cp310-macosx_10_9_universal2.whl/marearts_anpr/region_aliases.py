"""Region alias normalization helpers for ANPR OCR APIs."""

from typing import Dict

# Canonical public region codes.
# These are stable, short names we expose to users and CLI.
CANONICAL_REGIONS = ("kr", "eup", "na", "cn", "univ")

# Canonical -> internal model region names used by backend OCR modules.
CANONICAL_TO_INTERNAL: Dict[str, str] = {
    "kr": "kor",
    "eup": "euplus",
    "na": "na",
    "cn": "china",
    "univ": "univ",
}

# User input aliases -> canonical codes.
REGION_ALIASES: Dict[str, str] = {
    # Korea
    "kr": "kr",
    "kor": "kr",
    "korea": "kr",
    "korean": "kr",
    "korearepublic": "kr",

    # Europe+
    "eup": "eup",
    "euplus": "eup",
    "eu": "eup",
    "europe": "eup",
    "european": "eup",
    "europeplus": "eup",

    # North America
    "na": "na",
    "northamerica": "na",
    "northamerican": "na",
    "north-america": "na",

    # China
    "cn": "cn",
    "china": "cn",
    "chinese": "cn",

    # Universal
    "univ": "univ",
    "universal": "univ",
    "all": "univ",
    "global": "univ",
    "world": "univ",
}


def _normalize_region_key(region: str) -> str:
    if region is None:
        return "univ"
    return str(region).strip().lower().replace("_", "").replace(" ", "")


def normalize_region_alias(region: str) -> str:
    """Return canonical code: kr/eup/na/cn/univ."""
    key = _normalize_region_key(region)
    canonical = REGION_ALIASES.get(key)
    if canonical:
        return canonical
    raise ValueError(
        "Unsupported region '{}'. Supported aliases map to: {}".format(
            region, ", ".join(CANONICAL_REGIONS)
        )
    )


def to_internal_region(region: str) -> str:
    """Map user alias/canonical region to internal backend region name."""
    canonical = normalize_region_alias(region)
    return CANONICAL_TO_INTERNAL[canonical]


def to_api_region(region: str) -> str:
    """Map user alias/canonical region to public API region code."""
    return normalize_region_alias(region)
