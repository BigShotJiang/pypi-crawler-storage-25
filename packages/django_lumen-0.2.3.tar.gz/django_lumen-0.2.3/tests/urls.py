from django.urls import path, include

urlpatterns = [
    path('lumen/', include('django_lumen.urls')),
]
