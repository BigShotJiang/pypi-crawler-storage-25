from django.db import models


class Status(models.TextChoices):
    DRAFT = 'draft', 'Draft'
    PUBLISHED = 'published', 'Published'
    ARCHIVED = 'archived', 'Archived'


class Author(models.Model):
    name = models.CharField(max_length=100, help_text='Full name of the author')
    email = models.EmailField(unique=True)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.DRAFT)

    class Meta:
        app_label = 'tests'


class Book(models.Model):
    title = models.CharField(max_length=200, db_index=True)
    isbn = models.CharField(max_length=13, unique=True)
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='books')

    class Meta:
        app_label = 'tests'
        indexes = [models.Index(fields=['title', 'isbn'], name='book_title_isbn_idx')]
        constraints = [
            models.UniqueConstraint(fields=['title', 'author'], name='book_title_author_uniq')
        ]


class Tag(models.Model):
    name = models.CharField(max_length=50)
    books = models.ManyToManyField(Book, related_name='tags', blank=True)

    class Meta:
        app_label = 'tests'
        indexes = [models.Index(fields=['name'], name='tag_name_idx')]


class PriceMixin:
    pass


class Product(PriceMixin, models.Model):
    price = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        app_label = 'tests'


class DiscountedProduct(Product):
    class Meta:
        app_label = 'tests'
