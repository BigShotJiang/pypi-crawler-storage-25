from django.urls import path

from .views import DiagramView, ExcludedAppsView, HelpView, SavePreferencesView, SettingsView

urlpatterns = [
    path('', DiagramView.as_view(), name='django-lumen-diagram'),
    path('save-preferences/', SavePreferencesView.as_view(), name='django-lumen-save-preferences'),
    path('settings/', SettingsView.as_view(), name='django-lumen-settings'),
    path('settings/excluded-apps/', ExcludedAppsView.as_view(), name='django-lumen-excluded-apps'),
    path('help/', HelpView.as_view(), name='django-lumen-help'),
]
