import django.db.models.deletion
import django_lumen.models
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='DiagramPreferences',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('selected_apps', models.JSONField(blank=True, default=list)),
                ('excluded_apps', models.JSONField(blank=True, default=django_lumen.models._default_excluded_apps)),
                ('routing_style', models.CharField(
                    choices=[
                        ('orthogonal', 'Orthogonal'),
                        ('direct', 'Direct'),
                        ('oblique', 'Oblique'),
                        ('curved', 'Curved'),
                    ],
                    default='curved',
                    max_length=20,
                )),
                ('show_only_managed', models.BooleanField(default=False)),
                ('user', models.OneToOneField(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name='lumen_preferences',
                    to=settings.AUTH_USER_MODEL,
                )),
            ],
            options={
                'verbose_name': 'diagram preferences',
                'verbose_name_plural': 'diagram preferences',
            },
        ),
    ]
