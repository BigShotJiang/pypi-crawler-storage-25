from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('django_lumen', '0003_diagrampreferences_exclude_models'),
    ]

    operations = [
        migrations.AddField(
            model_name='diagrampreferences',
            name='show_inheritance',
            field=models.BooleanField(default=False),
        ),
    ]
