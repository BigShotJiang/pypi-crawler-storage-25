from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('django_lumen', '0002_alter_diagrampreferences_id'),
    ]

    operations = [
        migrations.AddField(
            model_name='diagrampreferences',
            name='exclude_models',
            field=models.JSONField(blank=True, default=list),
        ),
    ]
