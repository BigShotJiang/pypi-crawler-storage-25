from django.conf import settings
from django.db import models

ROUTING_CHOICES = [
    ('orthogonal', 'Orthogonal'),
    ('direct', 'Direct'),
    ('oblique', 'Oblique'),
    ('curved', 'Curved'),
]


def _default_excluded_apps():
    return ['contenttypes', 'sessions', 'admin', 'auth', 'django_lumen']


class DiagramPreferences(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='lumen_preferences',
    )
    selected_apps = models.JSONField(default=list, blank=True)
    excluded_apps = models.JSONField(default=_default_excluded_apps, blank=True)
    exclude_models = models.JSONField(default=list, blank=True)
    routing_style = models.CharField(max_length=20, choices=ROUTING_CHOICES, default='curved')
    show_only_managed = models.BooleanField(default=False)
    show_inheritance = models.BooleanField(default=False)

    class Meta:
        verbose_name = 'diagram preferences'
        verbose_name_plural = 'diagram preferences'

    def __str__(self):
        return f'DiagramPreferences({self.user})'
