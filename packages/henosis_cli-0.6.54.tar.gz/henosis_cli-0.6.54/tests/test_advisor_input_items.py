from henosis_cli_tools.advisor import build_advisor_input_items


def test_same_provider_advisor_preserves_native_prefix_for_cache():
    native = [
        {"role": "user", "content": "start"},
        {"type": "function_call", "call_id": "c1", "name": "read_file", "arguments": "{\"path\":\"a.py\"}"},
        {"type": "function_call_output", "call_id": "c1", "output": "{\"ok\":true}"},
    ]

    out = build_advisor_input_items(
        system_prompt="system prompt should not wrap prefix",
        conversation_items=native,
        provider_name="openai",
        advisor_provider_name="openai",
        model_name="gpt-5.4",
        tool_constraints_text="control_level=2; tools_enabled=True",
    )

    assert out[: len(native)] == native
    assert out[-1]["role"] == "user"
    assert "strategic advisor" in out[-1]["content"]
    assert "Cross-provider note" not in out[-1]["content"]


def test_cross_provider_openai_tool_call_and_result_become_assistant_xml():
    native = [
        {"role": "user", "content": "start"},
        {"type": "function_call", "call_id": "c1", "name": "read_file", "arguments": "{\"path\":\"a.py\"}"},
        {"type": "function_call_output", "call_id": "c1", "output": "{\"ok\":true}"},
    ]

    out = build_advisor_input_items(
        system_prompt="",
        conversation_items=native,
        provider_name="openai",
        advisor_provider_name="anthropic",
        model_name="gpt-5.4",
    )

    assert out[0] == {"role": "user", "content": "start"}
    exchange = out[1]
    assert exchange["role"] == "assistant"
    assert "<tool_exchange" in exchange["content"]
    assert "provider=\"openai\"" in exchange["content"]
    assert "id=\"c1\"" in exchange["content"]
    assert "name=\"read_file\"" in exchange["content"]
    assert "<tool_call>" in exchange["content"]
    assert "<tool_result>" in exchange["content"]
    assert out[-1]["role"] == "user"
    assert "Cross-provider note" in out[-1]["content"]


def test_cross_provider_anthropic_tool_result_is_assistant_block():
    native = [
        {"role": "user", "content": [{"type": "text", "text": "start"}]},
        {"role": "assistant", "content": [{"type": "tool_use", "id": "t1", "name": "read_file", "input": {"path": "a.py"}}]},
        {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "t1", "content": "ok"}]},
    ]

    out = build_advisor_input_items(
        system_prompt="",
        conversation_items=native,
        provider_name="anthropic",
        advisor_provider_name="openai",
        model_name="claude-sonnet-4-6",
    )

    assert out[0]["role"] == "user"
    assert out[1]["role"] == "assistant"
    assert "<tool_exchange" in out[1]["content"]
    assert "<tool_result>" in out[1]["content"]
    assert "ok" in out[1]["content"]
