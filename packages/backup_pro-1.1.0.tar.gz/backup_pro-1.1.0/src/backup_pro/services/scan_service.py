#!/usr/bin/env python3
from __future__ import annotations

import os
import re
import stat
import sys
import time
from re import Pattern

from ..common.singleton import Singleton
from ..common.utils import expand_path, sanitize_path, StrPath
from ..repository import Repository
from ..repository.dao import IndexMetadata

__all__ = [
    "ScanService"
]


class ScanService(metaclass=Singleton):
    def __init__(self):
        self.repository: Repository = Repository()

    def diff(self, since: int = None, paths: list[StrPath] = None) -> list[str]:
        paths = [] if paths is None else [os.fspath(sanitize_path(p)) for p in paths]
        return ScanHandler(self.repository).diff(since, paths)

    def scan(self, paths: list[StrPath] = None) -> None:
        paths = [] if paths is None else [os.fspath(sanitize_path(p)) for p in paths]
        ScanHandler(self.repository).scan(paths)

    def prune(self, cutoff: int) -> None:
        ScanHandler(self.repository).prune(cutoff)

    def add_scan_exclude_path(self, path: StrPath) -> None:
        self.repository.set_scan_exclude_path(sanitize_path(path))

    def remove_scan_exclude_path(self, path: StrPath) -> None:
        self.repository.remove_scan_exclude_path(sanitize_path(path))

    def add_scan_exclude_pattern(self, pattern: str) -> None:
        self.repository.set_scan_exclude_pattern(pattern)

    def remove_scan_exclude_pattern(self, pattern: str) -> None:
        self.repository.remove_scan_exclude_pattern(pattern)


class ScanHandler:
    def __init__(self, repository: Repository):
        self.repository = repository

        self.scan_exclude_paths: set[str] = {os.fspath(expand_path(p))
                                             for p in self.repository.get_scan_exclude_paths()}
        self.scan_exclude_patterns: list[Pattern[str]] = [re.compile(p)
                                                          for p in self.repository.get_scan_exclude_patterns()]

    def diff(self, since: int = None, paths: list[str] = None) -> list[str]:
        index_snapshot = self.repository.get_index_snapshot()
        snapshot = index_snapshot.snapshot

        if not snapshot:
            return []

        result: list[str] = []
        for path, entries in snapshot.items():
            if paths and not self._is_child_of(paths, path):
                continue

            if since is not None:
                # Show paths whose latest entry is newer than SINCE
                if entries[-1].mtime > since:
                    result.append(path)
            else:
                # Show paths with multiple entries (i.e. something changed)
                if len(entries) >= 2:
                    result.append(path)

        return sorted(result)

    @staticmethod
    def _is_child_of(parent_paths: list[str], path: str) -> bool:
        """Check if path is a child of (or equal to) one of the parent paths."""
        for parent in parent_paths:
            if path == parent or path.startswith(parent.rstrip(os.sep) + os.sep):
                return True
        return False

    def prune(self, cutoff: int) -> None:
        index_snapshot = self.repository.get_index_snapshot()
        snapshot = index_snapshot.snapshot

        keys_to_delete = []
        for path, entries in snapshot.items():
            if self._is_excluded_path(path):
                keys_to_delete.append(path)
                continue
            elif len(entries) == 1 and not entries[-1].is_deleted():
                continue

            last = len(entries) - 1
            pruned = [e for i, e in enumerate(entries)
                      if e.mtime >= cutoff or (i == last and not e.is_deleted())]

            if pruned:
                snapshot[path] = pruned
            else:
                keys_to_delete.append(path)

        for key in keys_to_delete:
            del snapshot[key]

        self.repository.save_index_snapshot(index_snapshot)

    def _is_excluded_path(self, path: str) -> bool:
        if path in self.scan_exclude_paths:
            return True

        for pattern in self.scan_exclude_patterns:
            if pattern.search(path):
                return True

        return False

    def scan(self, paths: list[str] = None) -> None:
        if paths:
            scan_roots = sorted(os.fspath(expand_path(p)) for p in paths)
        else:
            scan_roots = [os.path.abspath(os.sep)]

        index_snapshot = self.repository.get_index_snapshot()
        snapshot = index_snapshot.snapshot
        current_time = int(time.time())

        # Walk filesystem and collect current state
        current_state: dict[str, IndexMetadata] = {}
        for root in scan_roots:
            self._scan_path(root, current_state)

        # Update snapshot with changes
        for path, current in current_state.items():
            entries = snapshot.get(path)
            if entries:
                latest = entries[-1]
                if latest.mtime != current.mtime or latest.size != current.size:
                    entries.append(current)
            else:
                snapshot[path] = [current]

        # Mark deletions: paths in snapshot under scanned roots but not found on filesystem
        for path, entries in snapshot.items():
            if not entries or entries[-1].is_deleted():
                continue

            if self._is_child_of(scan_roots, path) and path not in current_state:
                entries.append(IndexMetadata(mtime=current_time, size=-entries[-1].size))

        self.repository.save_index_snapshot(index_snapshot)

    def _scan_path(self, path: str, result: dict[str, IndexMetadata], st: os.stat_result = None) -> None:
        if path in result:
            return

        if self._is_excluded_path(path):
            return

        try:
            if st is None:
                st = os.stat(path, follow_symlinks=False)

            if stat.S_ISREG(st.st_mode) or stat.S_ISLNK(st.st_mode) or self._is_junction(st):
                result[path] = IndexMetadata(mtime=int(st.st_mtime), size=st.st_size)
            elif stat.S_ISDIR(st.st_mode):
                result[path] = IndexMetadata(mtime=int(st.st_mtime), size=st.st_size)
                self._scan_dir(path, result)
        except OSError as e:
            print(f"{e.__class__.__name__}: {e}", file=sys.stderr)
            return

    @staticmethod
    def _is_junction(st: os.stat_result) -> bool:
        if os.name == "nt":
            reparse_point = getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 1024)
            mount_point = getattr(stat, "IO_REPARSE_TAG_MOUNT_POINT", 2684354563)

            return bool(getattr(st, "st_file_attributes", 0) & reparse_point) and \
                getattr(st, "st_reparse_tag", 0) == mount_point

        return False

    def _scan_dir(self, dir_path: str, result: dict[str, IndexMetadata]) -> None:
        try:
            with os.scandir(dir_path) as entries:
                children = []
                for entry in sorted(entries, key=lambda a: a.name):
                    try:
                        children.append((entry.path, entry.stat(follow_symlinks=False)))
                    except OSError as e:
                        print(f"{e.__class__.__name__}: {e}", file=sys.stderr)
        except OSError as e:
            print(f"{e.__class__.__name__}: {e}", file=sys.stderr)
            return

        for entry in children:
            self._scan_path(entry[0], result, st=entry[1])
