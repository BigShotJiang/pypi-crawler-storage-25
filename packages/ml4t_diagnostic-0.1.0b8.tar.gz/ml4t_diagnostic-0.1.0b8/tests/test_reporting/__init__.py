"""Tests for reporting module."""
