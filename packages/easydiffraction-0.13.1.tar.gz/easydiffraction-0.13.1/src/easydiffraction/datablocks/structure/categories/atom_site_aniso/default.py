# SPDX-FileCopyrightText: 2026 EasyScience contributors <https://github.com/easyscience>
# SPDX-License-Identifier: BSD-3-Clause
"""
Anisotropic ADP category.

Defines :class:`AtomSiteAniso` items and
:class:`AtomSiteAnisoCollection` used alongside :class:`AtomSites` to
hold anisotropic displacement parameters.
"""

from __future__ import annotations

from easydiffraction.core.category import CategoryCollection
from easydiffraction.core.category import CategoryItem
from easydiffraction.core.metadata import TypeInfo
from easydiffraction.core.validation import AttributeSpec
from easydiffraction.core.validation import RangeValidator
from easydiffraction.core.variable import Parameter
from easydiffraction.core.variable import StringDescriptor
from easydiffraction.datablocks.structure.categories.atom_site_aniso.factory import (
    AtomSiteAnisoFactory,
)
from easydiffraction.io.cif.handler import CifHandler


class AtomSiteAniso(CategoryItem):
    """
    Single atom site anisotropic ADP entry.

    Each entry mirrors an :class:`AtomSite` by label and holds six
    tensor components whose physical meaning (B or U) is determined by
    ``atom_site.adp_type``.
    """

    def __init__(self) -> None:
        """Initialise with default zero-valued tensor components."""
        super().__init__()

        self._label = StringDescriptor(
            name='label',
            description='Atom-site label matching the parent atom_site entry.',
            value_spec=AttributeSpec(default=''),
            cif_handler=CifHandler(names=['_atom_site_aniso.label']),
        )

        self._adp_11 = Parameter(
            name='adp_11',
            description='Anisotropic ADP tensor component (1,1).',
            units='Å²',
            value_spec=AttributeSpec(
                default=0.0,
                validator=RangeValidator(ge=0.0, le=10.0),
            ),
            cif_handler=CifHandler(
                names=[
                    '_atom_site_aniso.B_11',
                    '_atom_site_aniso.U_11',
                ]
            ),
        )
        self._adp_22 = Parameter(
            name='adp_22',
            description='Anisotropic ADP tensor component (2,2).',
            units='Å²',
            value_spec=AttributeSpec(
                default=0.0,
                validator=RangeValidator(ge=0.0, le=10.0),
            ),
            cif_handler=CifHandler(
                names=[
                    '_atom_site_aniso.B_22',
                    '_atom_site_aniso.U_22',
                ]
            ),
        )
        self._adp_33 = Parameter(
            name='adp_33',
            description='Anisotropic ADP tensor component (3,3).',
            units='Å²',
            value_spec=AttributeSpec(
                default=0.0,
                validator=RangeValidator(ge=0.0, le=10.0),
            ),
            cif_handler=CifHandler(
                names=[
                    '_atom_site_aniso.B_33',
                    '_atom_site_aniso.U_33',
                ]
            ),
        )
        self._adp_12 = Parameter(
            name='adp_12',
            description='Anisotropic ADP tensor component (1,2).',
            units='Å²',
            value_spec=AttributeSpec(
                default=0.0,
                validator=RangeValidator(),
            ),
            cif_handler=CifHandler(
                names=[
                    '_atom_site_aniso.B_12',
                    '_atom_site_aniso.U_12',
                ]
            ),
        )
        self._adp_13 = Parameter(
            name='adp_13',
            description='Anisotropic ADP tensor component (1,3).',
            units='Å²',
            value_spec=AttributeSpec(
                default=0.0,
                validator=RangeValidator(),
            ),
            cif_handler=CifHandler(
                names=[
                    '_atom_site_aniso.B_13',
                    '_atom_site_aniso.U_13',
                ]
            ),
        )
        self._adp_23 = Parameter(
            name='adp_23',
            description='Anisotropic ADP tensor component (2,3).',
            units='Å²',
            value_spec=AttributeSpec(
                default=0.0,
                validator=RangeValidator(),
            ),
            cif_handler=CifHandler(
                names=[
                    '_atom_site_aniso.B_23',
                    '_atom_site_aniso.U_23',
                ]
            ),
        )

        self._identity.category_code = 'atom_site_aniso'
        self._identity.category_entry_name = lambda: str(self.label.value)

    # ------------------------------------------------------------------
    #  Public properties
    # ------------------------------------------------------------------

    @property
    def label(self) -> StringDescriptor:
        """Label matching the parent atom_site entry."""
        return self._label

    @label.setter
    def label(self, value: str) -> None:
        self._label.value = value

    @property
    def adp_11(self) -> Parameter:
        """Anisotropic ADP tensor component (1,1) in Å²."""
        return self._adp_11

    @adp_11.setter
    def adp_11(self, value: float) -> None:
        self._adp_11.value = value

    @property
    def adp_22(self) -> Parameter:
        """Anisotropic ADP tensor component (2,2) in Å²."""
        return self._adp_22

    @adp_22.setter
    def adp_22(self, value: float) -> None:
        self._adp_22.value = value

    @property
    def adp_33(self) -> Parameter:
        """Anisotropic ADP tensor component (3,3) in Å²."""
        return self._adp_33

    @adp_33.setter
    def adp_33(self, value: float) -> None:
        self._adp_33.value = value

    @property
    def adp_12(self) -> Parameter:
        """Anisotropic ADP tensor component (1,2) in Å²."""
        return self._adp_12

    @adp_12.setter
    def adp_12(self, value: float) -> None:
        self._adp_12.value = value

    @property
    def adp_13(self) -> Parameter:
        """Anisotropic ADP tensor component (1,3) in Å²."""
        return self._adp_13

    @adp_13.setter
    def adp_13(self, value: float) -> None:
        self._adp_13.value = value

    @property
    def adp_23(self) -> Parameter:
        """Anisotropic ADP tensor component (2,3) in Å²."""
        return self._adp_23

    @adp_23.setter
    def adp_23(self, value: float) -> None:
        self._adp_23.value = value


@AtomSiteAnisoFactory.register
class AtomSiteAnisoCollection(CategoryCollection):
    """Collection of :class:`AtomSiteAniso` instances."""

    type_info = TypeInfo(
        tag='default',
        description='Anisotropic ADP collection',
    )

    def __init__(self) -> None:
        """Initialise an empty aniso-ADP collection."""
        super().__init__(item_type=AtomSiteAniso)

    def _skip_cif_serialization(self) -> bool:
        """
        Return ``True`` when no atoms use an anisotropic ADP type.

        Returns
        -------
        bool
            ``True`` if CIF output should be suppressed.
        """
        structure = getattr(self, '_parent', None)
        if structure is None:
            return True
        atom_sites = getattr(structure, '_atom_sites', None)
        if atom_sites is None:
            return True
        from easydiffraction.datablocks.structure.categories.atom_sites.enums import (  # noqa: PLC0415
            AdpTypeEnum,
        )

        aniso_types = {AdpTypeEnum.BANI.value, AdpTypeEnum.UANI.value}
        return not any(atom.adp_type.value in aniso_types for atom in atom_sites)

    def _iso_labels(self) -> set[str]:
        """Return labels of atoms with isotropic ADP type."""
        structure = getattr(self, '_parent', None)
        if structure is None:
            return set()
        atom_sites = getattr(structure, '_atom_sites', None)
        if atom_sites is None:
            return set()
        from easydiffraction.datablocks.structure.categories.atom_sites.enums import (  # noqa: PLC0415
            AdpTypeEnum,
        )

        iso_types = {AdpTypeEnum.BISO.value, AdpTypeEnum.UISO.value}
        return {atom.label.value for atom in atom_sites if atom.adp_type.value in iso_types}

    def _format_cif_row(self, item: object) -> list[str] | None:
        """
        Return ``?`` markers for isotropic atoms, ``None`` otherwise.

        Used by :func:`category_collection_to_cif` as a per-row hook.
        Atoms whose ADP type is isotropic get ``?`` for the six tensor
        components so they are not mistaken for genuine zeros.

        Parameters
        ----------
        item : object
            An :class:`AtomSiteAniso` instance.

        Returns
        -------
        list[str] | None
            Formatted row when overridden, ``None`` for default output.
        """
        if item.label.value not in self._iso_labels():
            return None
        from easydiffraction.io.cif.serialize import format_param_value  # noqa: PLC0415
        from easydiffraction.io.cif.serialize import format_value  # noqa: PLC0415

        row = [format_param_value(item._label)]
        row.extend([format_value(None)] * 6)
        return row
