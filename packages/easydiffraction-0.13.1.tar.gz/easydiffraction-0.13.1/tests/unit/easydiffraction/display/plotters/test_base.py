# SPDX-FileCopyrightText: 2025 EasyScience contributors <https://github.com/easyscience>
# SPDX-License-Identifier: BSD-3-Clause

import sys
import types


def test_module_import():
    import easydiffraction.display.plotters.base as MUT

    expected_module_name = 'easydiffraction.display.plotters.base'
    actual_module_name = MUT.__name__
    assert expected_module_name == actual_module_name


def test_default_engine_switches_with_notebook(monkeypatch):
    from easydiffraction.display.plotting import PlotterEngineEnum

    # Simulate running in a Jupyter kernel
    mod = types.ModuleType('IPython')
    mod.get_ipython = lambda: types.SimpleNamespace(config={'IPKernelApp': True})
    monkeypatch.setitem(sys.modules, 'IPython', mod)
    assert PlotterEngineEnum.default().value == 'plotly'

    # Now simulate non-notebook environment
    mod2 = types.ModuleType('IPython')
    mod2.get_ipython = lambda: None
    monkeypatch.setitem(sys.modules, 'IPython', mod2)
    assert PlotterEngineEnum.default().value == 'asciichartpy'


def test_default_axes_labels_keys_present():
    import easydiffraction.display.plotters.base as pb
    from easydiffraction.datablocks.experiment.item.enums import SampleFormEnum
    from easydiffraction.datablocks.experiment.item.enums import ScatteringTypeEnum

    # Powder Bragg
    assert (
        SampleFormEnum.POWDER,
        ScatteringTypeEnum.BRAGG,
        pb.XAxisType.TWO_THETA,
    ) in pb.DEFAULT_AXES_LABELS
    assert (
        SampleFormEnum.POWDER,
        ScatteringTypeEnum.BRAGG,
        pb.XAxisType.TIME_OF_FLIGHT,
    ) in pb.DEFAULT_AXES_LABELS
    assert (
        SampleFormEnum.POWDER,
        ScatteringTypeEnum.BRAGG,
        pb.XAxisType.D_SPACING,
    ) in pb.DEFAULT_AXES_LABELS
    # Single crystal Bragg
    assert (
        SampleFormEnum.SINGLE_CRYSTAL,
        ScatteringTypeEnum.BRAGG,
        pb.XAxisType.INTENSITY_CALC,
    ) in pb.DEFAULT_AXES_LABELS
    assert (
        SampleFormEnum.SINGLE_CRYSTAL,
        ScatteringTypeEnum.BRAGG,
        pb.XAxisType.D_SPACING,
    ) in pb.DEFAULT_AXES_LABELS
    assert (
        SampleFormEnum.SINGLE_CRYSTAL,
        ScatteringTypeEnum.BRAGG,
        pb.XAxisType.SIN_THETA_OVER_LAMBDA,
    ) in pb.DEFAULT_AXES_LABELS
