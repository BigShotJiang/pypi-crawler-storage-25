# SPDX-FileCopyrightText: 2026 EasyScience contributors <https://github.com/easyscience>
# SPDX-License-Identifier: BSD-3-Clause

import numpy as np
import pytest

from easydiffraction.datablocks.experiment.categories.experiment_type import ExperimentType
from easydiffraction.datablocks.experiment.item.enums import BeamModeEnum
from easydiffraction.datablocks.experiment.item.enums import RadiationProbeEnum
from easydiffraction.datablocks.experiment.item.enums import SampleFormEnum
from easydiffraction.datablocks.experiment.item.enums import ScatteringTypeEnum
from easydiffraction.datablocks.experiment.item.total_pd import TotalPdExperiment


def _mk_type_powder_total():
    et = ExperimentType()
    et._set_sample_form(SampleFormEnum.POWDER.value)
    et._set_beam_mode(BeamModeEnum.CONSTANT_WAVELENGTH.value)
    et._set_radiation_probe(RadiationProbeEnum.NEUTRON.value)
    et._set_scattering_type(ScatteringTypeEnum.TOTAL.value)
    return et


def test_load_ascii_data_pdf(tmp_path: pytest.TempPathFactory):
    expt = TotalPdExperiment(name='pdf1', type=_mk_type_powder_total())

    # Mock diffpy.utils.parsers.loaddata.loadData by creating a small parser module on sys.path
    data = np.column_stack([
        np.array([0.0, 1.0, 2.0]),
        np.array([10.0, 11.0, 12.0]),
        np.array([0.01, 0.02, 0.03]),
    ])
    f = tmp_path / 'g.dat'
    np.savetxt(f, data)

    try:
        from diffpy.utils.parsers import load_data  # noqa: F401
    except ImportError:
        has_diffpy = False
    else:
        has_diffpy = True

    if not has_diffpy:
        with pytest.raises(ImportError):
            expt._load_ascii_data_to_experiment(str(f))
        return

    # With diffpy available, load should succeed
    expt._load_ascii_data_to_experiment(str(f))
    assert np.allclose(expt.data.x, data[:, 0])
    assert np.allclose(expt.data.intensity_meas, data[:, 1])
    assert np.allclose(expt.data.intensity_meas_su, data[:, 2])
