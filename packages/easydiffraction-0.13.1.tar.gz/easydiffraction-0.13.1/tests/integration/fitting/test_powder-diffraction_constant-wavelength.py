# SPDX-FileCopyrightText: 2026 EasyScience contributors <https://github.com/easyscience>
# SPDX-License-Identifier: BSD-3-Clause

import tempfile

import pytest
from numpy.testing import assert_almost_equal

from easydiffraction import ExperimentFactory
from easydiffraction import Project
from easydiffraction import StructureFactory
from easydiffraction import download_data

TEMP_DIR = tempfile.gettempdir()


def test_single_fit_neutron_pd_cwl_lbco() -> None:
    # Set structure
    model = StructureFactory.from_scratch(name='lbco')
    model.space_group.name_h_m = 'P m -3 m'
    model.cell.length_a = 3.88
    model.atom_sites.create(
        label='La',
        type_symbol='La',
        fract_x=0,
        fract_y=0,
        fract_z=0,
        wyckoff_letter='a',
        occupancy=0.5,
        adp_iso=0.1,
    )
    model.atom_sites.create(
        label='Ba',
        type_symbol='Ba',
        fract_x=0,
        fract_y=0,
        fract_z=0,
        wyckoff_letter='a',
        occupancy=0.5,
        adp_iso=0.1,
    )
    model.atom_sites.create(
        label='Co',
        type_symbol='Co',
        fract_x=0.5,
        fract_y=0.5,
        fract_z=0.5,
        wyckoff_letter='b',
        adp_iso=0.1,
    )
    model.atom_sites.create(
        label='O',
        type_symbol='O',
        fract_x=0,
        fract_y=0.5,
        fract_z=0.5,
        wyckoff_letter='c',
        adp_iso=0.1,
    )

    # Set experiment
    data_path = download_data(id=3, destination=TEMP_DIR)

    expt = ExperimentFactory.from_data_path(
        name='hrpt',
        data_path=data_path,
    )

    expt.instrument.setup_wavelength = 1.494
    expt.instrument.calib_twotheta_offset = 0

    expt.peak.broad_gauss_u = 0.1
    expt.peak.broad_gauss_v = -0.1
    expt.peak.broad_gauss_w = 0.2
    expt.peak.broad_lorentz_x = 0
    expt.peak.broad_lorentz_y = 0

    expt.linked_phases.create(id='lbco', scale=5.0)

    expt.background.create(id='1', x=10, y=170)
    expt.background.create(id='2', x=165, y=170)

    # Create project
    project = Project()
    project.structures.add(model)
    project.experiments.add(expt)

    # Prepare for fitting
    project.analysis.current_minimizer = 'lmfit'

    # ------------ 1st fitting ------------

    # Select fitting parameters
    model.cell.length_a.free = True
    expt.linked_phases['lbco'].scale.free = True
    expt.instrument.calib_twotheta_offset.free = True
    expt.background['1'].y.free = True
    expt.background['2'].y.free = True

    # Perform fit
    project.analysis.fit()

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=5.79,
        decimal=1,
    )

    # ------------ 2nd fitting ------------

    # Select fitting parameters
    expt.peak.broad_gauss_u.free = True
    expt.peak.broad_gauss_v.free = True
    expt.peak.broad_gauss_w.free = True
    expt.peak.broad_lorentz_y.free = True

    # Perform fit
    project.analysis.fit()

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=4.41,
        decimal=1,
    )

    # ------------ 3rd fitting ------------

    # Select fitting parameters
    model.atom_sites['La'].adp_iso.free = True
    model.atom_sites['Ba'].adp_iso.free = True
    model.atom_sites['Co'].adp_iso.free = True
    model.atom_sites['O'].adp_iso.free = True

    # Perform fit
    project.analysis.fit()

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=1.3,
        decimal=1,
    )


@pytest.mark.fast
def test_single_fit_neutron_pd_cwl_lbco_with_constraints() -> None:
    # Set structure
    model = StructureFactory.from_scratch(name='lbco')

    space_group = model.space_group
    space_group.name_h_m = 'P m -3 m'

    cell = model.cell
    cell.length_a = 3.8909

    atom_sites = model.atom_sites
    atom_sites.create(
        label='La',
        type_symbol='La',
        fract_x=0,
        fract_y=0,
        fract_z=0,
        wyckoff_letter='a',
        adp_iso=1.0,
        occupancy=0.5,
    )
    atom_sites.create(
        label='Ba',
        type_symbol='Ba',
        fract_x=0,
        fract_y=0,
        fract_z=0,
        wyckoff_letter='a',
        adp_iso=1.0,
        occupancy=0.5,
    )
    atom_sites.create(
        label='Co',
        type_symbol='Co',
        fract_x=0.5,
        fract_y=0.5,
        fract_z=0.5,
        wyckoff_letter='b',
        adp_iso=1.0,
    )
    atom_sites.create(
        label='O',
        type_symbol='O',
        fract_x=0,
        fract_y=0.5,
        fract_z=0.5,
        wyckoff_letter='c',
        adp_iso=1.0,
    )

    # Set experiment
    data_path = download_data(id=3, destination=TEMP_DIR)

    expt = ExperimentFactory.from_data_path(
        name='hrpt',
        data_path=data_path,
    )

    instrument = expt.instrument
    instrument.setup_wavelength = 1.494
    instrument.calib_twotheta_offset = 0.6225

    peak = expt.peak
    peak.broad_gauss_u = 0.0834
    peak.broad_gauss_v = -0.1168
    peak.broad_gauss_w = 0.123
    peak.broad_lorentz_x = 0
    peak.broad_lorentz_y = 0.0797

    background = expt.background
    background.create(id='10', x=10, y=174.3)
    background.create(id='20', x=20, y=159.8)
    background.create(id='30', x=30, y=167.9)
    background.create(id='50', x=50, y=166.1)
    background.create(id='70', x=70, y=172.3)
    background.create(id='90', x=90, y=171.1)
    background.create(id='110', x=110, y=172.4)
    background.create(id='130', x=130, y=182.5)
    background.create(id='150', x=150, y=173.0)
    background.create(id='165', x=165, y=171.1)

    expt.linked_phases.create(id='lbco', scale=9.0976)

    # Create project
    project = Project()
    project.structures.add(model)
    project.experiments.add(expt)

    # Prepare for fitting
    project.analysis.current_minimizer = 'lmfit'

    # ------------ 1st fitting ------------

    # Select fitting parameters
    atom_sites['La'].occupancy.free = True
    atom_sites['Ba'].occupancy.free = True
    atom_sites['La'].adp_iso.free = True
    atom_sites['Ba'].adp_iso.free = True
    atom_sites['Co'].adp_iso.free = True
    atom_sites['O'].adp_iso.free = True

    # Compare parameter values before fit
    assert_almost_equal(atom_sites['La'].adp_iso.value, 1.0, decimal=2)
    assert_almost_equal(atom_sites['Ba'].adp_iso.value, 1.0, decimal=2)
    assert_almost_equal(atom_sites['Co'].adp_iso.value, 1.0, decimal=2)
    assert_almost_equal(atom_sites['O'].adp_iso.value, 1.0, decimal=2)
    assert_almost_equal(atom_sites['La'].occupancy.value, 0.5, decimal=2)
    assert_almost_equal(atom_sites['Ba'].occupancy.value, 0.5, decimal=2)

    # Perform fit
    project.analysis.fit()

    # Compare parameter values after fit
    assert_almost_equal(atom_sites['La'].adp_iso.value, desired=15.0945, decimal=2)
    assert_almost_equal(atom_sites['Ba'].adp_iso.value, desired=0.5226, decimal=2)
    assert_almost_equal(atom_sites['Co'].adp_iso.value, desired=0.2398, decimal=2)
    assert_almost_equal(atom_sites['O'].adp_iso.value, desired=1.4049, decimal=2)
    assert_almost_equal(atom_sites['La'].occupancy.value, desired=0.011, decimal=2)
    assert_almost_equal(atom_sites['Ba'].occupancy.value, desired=1.3206, decimal=2)

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=1.24,
        decimal=1,
    )

    # ------------ 2nd fitting ------------

    # Set aliases for parameters
    project.analysis.aliases.create(
        label='biso_La',
        param=atom_sites['La'].adp_iso,
    )
    project.analysis.aliases.create(
        label='biso_Ba',
        param=atom_sites['Ba'].adp_iso,
    )
    project.analysis.aliases.create(
        label='occ_La',
        param=atom_sites['La'].occupancy,
    )
    project.analysis.aliases.create(
        label='occ_Ba',
        param=atom_sites['Ba'].occupancy,
    )

    # Set constraints
    project.analysis.constraints.create(expression='biso_Ba = biso_La')
    project.analysis.constraints.create(expression='occ_Ba = 1 - occ_La')

    # Perform fit
    project.analysis.fit()

    # Compare parameter values after fit
    assert_almost_equal(atom_sites['La'].adp_iso.value, desired=0.5443, decimal=2)
    assert_almost_equal(atom_sites['Ba'].adp_iso.value, desired=0.5443, decimal=2)
    assert_almost_equal(atom_sites['Co'].adp_iso.value, desired=0.2335, decimal=2)
    assert_almost_equal(atom_sites['O'].adp_iso.value, desired=1.4056, decimal=2)
    assert_almost_equal(atom_sites['La'].occupancy.value, desired=0.5274, decimal=2)
    assert_almost_equal(atom_sites['Ba'].occupancy.value, desired=0.4726, decimal=2)

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=1.24,
        decimal=1,
    )


def test_fit_neutron_pd_cwl_hs() -> None:
    # Set structure
    model = StructureFactory.from_scratch(name='hs')
    model.space_group.name_h_m = 'R -3 m'
    model.space_group.it_coordinate_system_code = 'h'
    model.cell.length_a = 6.8615
    model.cell.length_c = 14.136
    model.atom_sites.create(
        label='Zn',
        type_symbol='Zn',
        fract_x=0,
        fract_y=0,
        fract_z=0.5,
        wyckoff_letter='b',
        adp_iso=0.1,
    )
    model.atom_sites.create(
        label='Cu',
        type_symbol='Cu',
        fract_x=0.5,
        fract_y=0,
        fract_z=0,
        wyckoff_letter='e',
        adp_iso=1.2,
    )
    model.atom_sites.create(
        label='O',
        type_symbol='O',
        fract_x=0.206,
        fract_y=-0.206,
        fract_z=0.061,
        wyckoff_letter='h',
        adp_iso=0.7,
    )
    model.atom_sites.create(
        label='Cl',
        type_symbol='Cl',
        fract_x=0,
        fract_y=0,
        fract_z=0.197,
        wyckoff_letter='c',
        adp_iso=1.1,
    )
    model.atom_sites.create(
        label='H',
        type_symbol='2H',
        fract_x=0.132,
        fract_y=-0.132,
        fract_z=0.09,
        wyckoff_letter='h',
        adp_iso=2.3,
    )

    # Set experiment
    data_path = download_data(id=11, destination=TEMP_DIR)

    expt = ExperimentFactory.from_data_path(name='hrpt', data_path=data_path)

    expt.instrument.setup_wavelength = 1.89
    expt.instrument.calib_twotheta_offset = 0.0

    expt.peak.broad_gauss_u = 0.1579
    expt.peak.broad_gauss_v = -0.3571
    expt.peak.broad_gauss_w = 0.3498
    expt.peak.broad_lorentz_x = 0.2927
    expt.peak.broad_lorentz_y = 0

    expt.background.create(id='1', x=4.4196, y=648.413)
    expt.background.create(id='2', x=6.6207, y=523.788)
    expt.background.create(id='3', x=10.4918, y=454.938)
    expt.background.create(id='4', x=15.4634, y=435.913)
    expt.background.create(id='5', x=45.6041, y=472.972)
    expt.background.create(id='6', x=74.6844, y=486.606)
    expt.background.create(id='7', x=103.4187, y=472.409)
    expt.background.create(id='8', x=121.6311, y=496.734)
    expt.background.create(id='9', x=159.4116, y=473.146)

    expt.linked_phases.create(id='hs', scale=0.492)

    # Create project
    project = Project()
    project.structures.add(model)
    project.experiments.add(expt)

    # Prepare for fitting
    project.analysis.current_minimizer = 'lmfit'

    # ------------ 1st fitting ------------

    # Select fitting parameters
    model.cell.length_a.free = True
    model.cell.length_c.free = True
    expt.linked_phases['hs'].scale.free = True
    expt.instrument.calib_twotheta_offset.free = True

    # Perform fit
    project.analysis.fit()

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=2.11,
        decimal=1,
    )

    # ------------ 2nd fitting ------------

    # Select fitting parameters
    expt.peak.broad_gauss_u.free = True
    expt.peak.broad_gauss_v.free = True
    expt.peak.broad_gauss_w.free = True
    expt.peak.broad_lorentz_x.free = True
    for point in expt.background:
        point.y.free = True

    # Perform fit
    project.analysis.fit()

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=2.11,
        decimal=1,
    )

    # ------------ 3rd fitting ------------

    # Select fitting parameters
    model.atom_sites['O'].fract_x.free = True
    model.atom_sites['O'].fract_z.free = True
    model.atom_sites['Cl'].fract_z.free = True
    model.atom_sites['H'].fract_x.free = True
    model.atom_sites['H'].fract_z.free = True

    # Perform fit
    project.analysis.fit()

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=2.11,
        decimal=1,
    )

    # ------------ 3rd fitting ------------

    # Select fitting parameters
    model.atom_sites['Zn'].adp_iso.free = True
    model.atom_sites['Cu'].adp_iso.free = True
    model.atom_sites['O'].adp_iso.free = True
    model.atom_sites['Cl'].adp_iso.free = True
    model.atom_sites['H'].adp_iso.free = True

    # Perform fit
    project.analysis.fit()

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=2.11,
        decimal=1,
    )


def test_single_fit_neutron_pd_cwl_lbco_with_constraints_from_project(tmp_path) -> None:
    import easydiffraction as ed

    # Create a project from CIF files
    project = ed.Project()
    project.structures.add_from_cif_path(ed.download_data(id=1, destination='data'))
    project.experiments.add_from_cif_path(ed.download_data(id=2, destination='data'))

    # Set constraints
    project.analysis.aliases.create(
        label='biso_La',
        param=project.structures['lbco'].atom_sites['La'].adp_iso,
    )
    project.analysis.aliases.create(
        label='biso_Ba',
        param=project.structures['lbco'].atom_sites['Ba'].adp_iso,
    )

    project.analysis.aliases.create(
        label='occ_La',
        param=project.structures['lbco'].atom_sites['La'].occupancy,
    )
    project.analysis.aliases.create(
        label='occ_Ba',
        param=project.structures['lbco'].atom_sites['Ba'].occupancy,
    )

    project.analysis.constraints.create(expression='biso_Ba = biso_La')
    project.analysis.constraints.create(expression='occ_Ba = 1 - occ_La')

    # More fit patams
    project.structures['lbco'].atom_sites['La'].occupancy.free = True

    # Save to a directory
    proj_dir = str(tmp_path / 'lbco_project')
    project.save_as(proj_dir)

    # Load Project from Directory
    project = ed.Project.load(proj_dir)

    # Perform Analysis
    project.analysis.fit()

    # Compare fit quality
    assert_almost_equal(
        project.analysis.fit_results.reduced_chi_square,
        desired=1.28,
        decimal=1,
    )


if __name__ == '__main__':
    test_fit_neutron_pd_cwl_hs()
    test_single_fit_neutron_pd_cwl_lbco()
    test_single_fit_neutron_pd_cwl_lbco_with_constraints()
