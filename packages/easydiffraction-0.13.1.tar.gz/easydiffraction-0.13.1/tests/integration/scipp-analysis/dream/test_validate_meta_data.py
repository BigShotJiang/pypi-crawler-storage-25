# SPDX-FileCopyrightText: 2026 EasyScience contributors <https://github.com/easyscience>
# SPDX-License-Identifier: BSD-3-Clause

"""Tests for validating metadata structure in CIF files.

These tests verify that the CIF file contains the expected data blocks,
loops, and calibration parameters required for TOF diffraction analysis.
"""

import gemmi
import pytest


def test_validate_meta_data__block_exists(
    cif_document: gemmi.cif.Document,
) -> None:
    """Verify that single datablock 'reduced_tof' is present."""
    assert len(cif_document) == 1
    assert cif_document.sole_block().name == 'reduced_tof'


def test_validate_meta_data__diffrn_radiation(
    cif_block: gemmi.cif.Block,
) -> None:
    """Verify _diffrn_radiation.probe is 'neutron'."""
    probe = cif_block.find_value('_diffrn_radiation.probe')
    assert probe is not None
    assert isinstance(probe, str)
    assert probe == 'neutron'


def test_validate_meta_data__d_to_tof_loop(
    cif_block: gemmi.cif.Block,
) -> None:
    """Verify the d_to_tof calibration loop exists with correct
    structure.
    """
    loop = cif_block.find(['_pd_calib_d_to_tof.id']).loop
    assert loop is not None

    # Check loop has exactly 1 row
    assert loop.length() == 1

    # Check all expected columns exist
    assert '_pd_calib_d_to_tof.id' in loop.tags
    assert '_pd_calib_d_to_tof.power' in loop.tags
    assert '_pd_calib_d_to_tof.coeff' in loop.tags


def test_validate_meta_data__d_to_tof_difc(
    cif_block: gemmi.cif.Block,
) -> None:
    """Verify DIFC calibration coefficient is approximately 28385.3."""
    table = cif_block.find([
        '_pd_calib_d_to_tof.id',
        '_pd_calib_d_to_tof.power',
        '_pd_calib_d_to_tof.coeff',
    ])
    loop = table.loop
    assert loop is not None

    id_, power, coeff = loop.values
    assert id_ == 'DIFC'
    assert int(power) == 1
    assert pytest.approx(float(coeff), rel=0.01) == 28385.3


def test_validate_meta_data__data_loop_exists(
    cif_block: gemmi.cif.Block,
) -> None:
    """Verify the main data loop exists with required columns."""
    loop = cif_block.find(['_pd_data.point_id']).loop
    assert loop is not None

    # Check all expected columns exist
    assert '_pd_data.point_id' in loop.tags
    assert '_pd_meas.time_of_flight' in loop.tags
    assert '_pd_proc.intensity_norm' in loop.tags
    assert '_pd_proc.intensity_norm_su' in loop.tags
