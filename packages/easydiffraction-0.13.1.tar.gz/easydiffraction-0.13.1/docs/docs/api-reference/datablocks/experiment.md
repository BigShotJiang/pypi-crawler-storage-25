::: easydiffraction.datablocks.experiment
