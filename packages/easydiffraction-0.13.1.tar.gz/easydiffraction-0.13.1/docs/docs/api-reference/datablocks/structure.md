::: easydiffraction.datablocks.structure
