::: easydiffraction.analysis
