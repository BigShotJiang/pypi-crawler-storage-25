"""Phase transition display for Ralph pipeline.

Renders visually distinct banners and separators at pipeline phase boundaries
so the user can easily follow the flow of planning → development → review → …
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from rich.rule import Rule
from rich.text import Text

from ralph.display.theme import make_console

if TYPE_CHECKING:
    from rich.console import Console

_PHASE_STYLES: dict[str, str] = {
    "planning": "theme.phase.planning",
    "development": "theme.phase.development",
    "development_analysis": "theme.phase.development_analysis",
    "development_commit": "theme.phase.development_commit",
    "review": "theme.phase.review",
    "review_analysis": "theme.phase.review_analysis",
    "review_commit": "theme.phase.review_commit",
    "commit": "theme.phase.commit",
    "fix": "theme.phase.fix",
    "complete": "theme.phase.complete",
    "failed": "theme.phase.failed",
}

_MAJOR_TRANSITIONS: frozenset[tuple[str, str]] = frozenset(
    {
        ("planning", "development"),
        ("development_analysis", "development_commit"),
        ("development_analysis", "development"),
        ("development_commit", "review"),
        ("review", "complete"),
        ("review_analysis", "review_commit"),
        ("review_analysis", "fix"),
        ("fix", "review"),
        ("review_commit", "complete"),
        ("review_commit", "development"),
        ("review_commit", "planning"),
        ("development_commit", "planning"),
    }
)

_TRANSITION_DESCRIPTIONS: dict[tuple[str, str], str] = {
    ("planning", "development"): "Plan ready — starting development",
    ("development", "development_analysis"): "Development complete — analyzing results",
    ("development_analysis", "development_commit"): "Analysis approved — committing changes",
    ("development_analysis", "development"): (
        "Analysis requested changes — returning to development"
    ),
    ("development_commit", "review"): "Changes committed — starting review",
    ("development_commit", "planning"): "Commit complete — re-planning needed",
    ("review", "review_analysis"): "Review complete — analyzing findings",
    ("review_analysis", "review_commit"): "Review analysis approved — committing review changes",
    ("review_analysis", "fix"): "Review found issues — routing to fix",
    ("fix", "review"): "Fix complete — re-reviewing",
    ("review_commit", "complete"): "Review changes committed — pipeline complete",
    ("review_commit", "development"): "Review committed — continuing development",
    ("review_commit", "planning"): "Review committed — re-planning needed",
    ("review", "complete"): "All reviews passed",
}


def _phase_style(phase: str) -> str:
    """Return the rich style string for a phase name."""
    return _PHASE_STYLES.get(phase, "dim")


def _phase_label(phase: str) -> str:
    """Return a human-readable label for a phase name.

    Examples:
        >>> _phase_label("development_analysis")
        'Development Analysis'
        >>> _phase_label("review_commit")
        'Review Commit'
    """
    return phase.replace("_", " ").title()


def show_phase_transition(
    from_phase: str,
    to_phase: str,
    *,
    context: dict[str, object] | None = None,
    console: Console | None = None,
) -> None:
    """Display a visual transition between pipeline phases.

    Major transitions (e.g. planning → development) get a prominent banner.
    Minor transitions (e.g. development → development_analysis) get a simple rule.

    Args:
        from_phase: The phase being left.
        to_phase: The phase being entered.
        context: Optional key-value context to display alongside the transition.
        console: Rich console for output.
    """
    c = console or make_console()

    style = _phase_style(to_phase)
    from_label = _phase_label(from_phase)
    to_label = _phase_label(to_phase)
    description = _TRANSITION_DESCRIPTIONS.get((from_phase, to_phase))

    is_major = (from_phase, to_phase) in _MAJOR_TRANSITIONS

    if is_major:
        c.print()
        c.print(Rule(style=style))
        banner = Text()
        banner.append(f"  {from_label}", style="dim")
        banner.append(" → ", style="bold")
        banner.append(to_label, style=style)
        if context:
            detail = "  ".join(f"{k}={v}" for k, v in context.items())
            banner.append(f"  ({detail})", style="dim")
        c.print(banner)
        if description:
            c.print(Text(f"  {description}", style="dim italic"))
        c.print(Rule(style=style))
    else:
        c.print()
        title = Text()
        title.append(f"{from_label} → {to_label}")
        if description:
            title.append(f"  {description}", style="dim italic")
        c.print(Rule(title=title, style=style))


@dataclass(frozen=True)
class PhaseStartContext:
    """Optional counters and metadata for phase start display."""

    iteration: int | None = None
    total_iterations: int | None = None
    reviewer_pass: int | None = None
    total_reviewer_passes: int | None = None
    agent_name: str | None = None
    development_analysis_iteration: int | None = None
    max_development_analysis_iterations: int | None = None
    review_analysis_iteration: int | None = None
    max_review_analysis_iterations: int | None = None


def _build_analysis_suffix(
    iteration: int,
    max_iterations: int,
) -> str:
    """Build the analysis iteration suffix string."""
    return f" [analysis {iteration + 1}/{max_iterations}]"


def show_phase_start(
    phase: str,
    *,
    ctx: PhaseStartContext | None = None,
    agent_name: str | None = None,
    console: Console | None = None,
) -> None:
    """Display the start of a pipeline phase.

    Args:
        phase: Phase name.
        ctx: Optional context with iteration/reviewer counters.
        agent_name: Name of the agent being invoked (shortcut; also settable via ctx).
        console: Rich console for output.
    """
    c = console or make_console()
    style = _phase_style(phase)
    label = _phase_label(phase)

    line = Text()
    line.append("▶ ", style=style)
    line.append(label, style=style)

    if ctx is not None:
        if ctx.iteration is not None and ctx.total_iterations is not None:
            line.append(f" [iteration {ctx.iteration + 1}/{ctx.total_iterations}]", style="dim")
        if ctx.reviewer_pass is not None and ctx.total_reviewer_passes is not None:
            line.append(f" [pass {ctx.reviewer_pass + 1}/{ctx.total_reviewer_passes}]", style="dim")
        if (
            phase == "development_analysis"
            and ctx.development_analysis_iteration is not None
            and ctx.max_development_analysis_iterations is not None
        ):
            suffix = _build_analysis_suffix(
                ctx.development_analysis_iteration,
                ctx.max_development_analysis_iterations,
            )
            line.append(suffix, style="dim")
        if (
            phase == "review_analysis"
            and ctx.review_analysis_iteration is not None
            and ctx.max_review_analysis_iterations is not None
        ):
            suffix = _build_analysis_suffix(
                ctx.review_analysis_iteration,
                ctx.max_review_analysis_iterations,
            )
            line.append(suffix, style="dim")
        effective_agent = ctx.agent_name or agent_name
    else:
        effective_agent = agent_name

    if effective_agent is not None:
        line.append(f"  agent={effective_agent}", style="dim")

    c.print(line)


def _get_int_attr(obj: object, attr: str) -> int | None:
    """Extract a typed int attribute from any object, returning None if absent or wrong type."""
    val: object = getattr(obj, attr, None)
    return val if isinstance(val, int) else None


def _get_str_attr(obj: object, attr: str) -> str | None:
    """Extract a typed str attribute from any object, returning None if absent or wrong type."""
    val: object = getattr(obj, attr, None)
    return val if isinstance(val, str) else None


def show_phase_start_from_state(
    state: object,
    phase: str,
    *,
    console: Console | None = None,
) -> None:
    """Display phase start using counters extracted from a pipeline state object.

    Args:
        state: Any object with optional iteration/reviewer/analysis counter attributes.
        phase: Phase name to display.
        console: Rich console for output.
    """
    ctx = PhaseStartContext(
        iteration=_get_int_attr(state, "iteration"),
        total_iterations=_get_int_attr(state, "total_iterations"),
        reviewer_pass=_get_int_attr(state, "reviewer_pass"),
        total_reviewer_passes=_get_int_attr(state, "total_reviewer_passes"),
        agent_name=_get_str_attr(state, "agent_name"),
        development_analysis_iteration=_get_int_attr(state, "development_analysis_iteration"),
        max_development_analysis_iterations=_get_int_attr(
            state, "max_development_analysis_iterations"
        ),
        review_analysis_iteration=_get_int_attr(state, "review_analysis_iteration"),
        max_review_analysis_iterations=_get_int_attr(state, "max_review_analysis_iterations"),
    )
    show_phase_start(phase, ctx=ctx, console=console)


def show_phase_complete(
    phase: str,
    *,
    decision: str | None = None,
    console: Console | None = None,
) -> None:
    """Display phase completion with an optional decision outcome.

    Args:
        phase: Phase that completed.
        decision: Optional decision (e.g. 'approved', 'needs changes').
        console: Rich console for output.
    """
    c = console or make_console()
    style = _phase_style(phase)
    label = _phase_label(phase)

    line = Text()
    line.append("✓ ", style=style)
    line.append(f"{label} complete", style=style)
    if decision is not None:
        line.append(f" — {decision}", style="bold")

    c.print(line)
