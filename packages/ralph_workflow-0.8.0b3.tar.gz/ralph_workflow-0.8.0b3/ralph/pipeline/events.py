"""Pipeline events representing all state transitions."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class PipelineEvent(StrEnum):
    AGENT_SUCCESS = "agent_success"
    AGENT_FAILURE = "agent_failure"
    AGENT_RETRY = "agent_retry"
    ANALYSIS_SUCCESS = "analysis_success"
    ANALYSIS_LOOPBACK = "analysis_loopback"
    REVIEW_CLEAN = "review_clean"
    REVIEW_ISSUES_FOUND = "review_issues_found"
    FIX_SUCCESS = "fix_success"
    FIX_FAILURE = "fix_failure"
    COMMIT_SUCCESS = "commit_success"
    COMMIT_SKIPPED = "commit_skipped"
    COMMIT_FAILURE = "commit_failure"
    CHECKPOINT_SAVED = "checkpoint_saved"
    CONTEXT_CLEANED = "context_cleaned"
    INTERRUPTED = "interrupted"
    COMPLETE = "complete"
    FAILED = "failed"
    PROMPT_PREPARED = "prompt_prepared"
    PHASE_ADVANCE = "phase_advance"
    FAN_OUT_STARTED = "fan_out_started"
    WORKERS_RESUMED = "workers_resumed"
    ALL_WORKERS_COMPLETE = "all_workers_complete"


@dataclass(frozen=True)
class PhaseFailureEvent:
    """Event emitted when a phase handler encounters a failure condition.

    This event carries a recoverable flag that determines how the reducer
    processes the failure:
    - recoverable=True: routes through _handle_agent_failure retry/fallback logic
    - recoverable=False: routes directly to PHASE_FAILED (terminal failure)

    Attributes:
        phase: Name of the phase that generated this event.
        reason: Human-readable description of what caused the failure.
        recoverable: Whether this failure should trigger retry/fallback (True)
            or act as a terminal decision (False).
        retry_in_session: When True and the agent's transport supports session
            resume, the recovery path should preserve the active session ID so
            the next retry continues in the same agent session rather than
            starting from scratch. Only meaningful when recoverable=True.
    """

    phase: str
    reason: str
    recoverable: bool
    retry_in_session: bool = False


@dataclass(frozen=True)
class WorkerStartedEvent:
    unit_id: str


@dataclass(frozen=True)
class WorkerCompletedEvent:
    unit_id: str
    exit_code: int
    commit_sha: str


@dataclass(frozen=True)
class WorkerFailedEvent:
    unit_id: str
    exit_code: int
    error: str


Event = (
    PipelineEvent
    | PhaseFailureEvent
    | WorkerStartedEvent
    | WorkerCompletedEvent
    | WorkerFailedEvent
)
