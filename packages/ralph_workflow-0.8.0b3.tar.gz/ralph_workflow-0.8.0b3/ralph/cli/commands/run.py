"""Run pipeline command for Ralph Workflow CLI.

This module implements the main pipeline execution command.
"""

from __future__ import annotations

import importlib
import pathlib  # noqa: TC003
from inspect import signature
from typing import TYPE_CHECKING, NamedTuple, Protocol, cast

from loguru import logger
from rich.panel import Panel
from rich.text import Text

from ralph.agents.registry import AgentRegistry
from ralph.config.enums import Verbosity  # noqa: TC001
from ralph.config.loader import load_config
from ralph.pipeline import checkpoint as ckpt
from ralph.pipeline.state import PipelineState  # noqa: TC001
from ralph.policy.loader import load_policy
from ralph.policy.validation import (
    CheckpointPolicyMismatchError,
    PolicyValidationError,
    validate_agent_chains_satisfiable,
    validate_checkpoint_against_policy,
    validate_recovery_config,
)
from ralph.workspace.scope import WorkspaceScope, resolve_workspace_scope

if TYPE_CHECKING:
    from ralph.config.models import UnifiedConfig
    from ralph.policy.models import PolicyBundle


class _RunnerFunc(Protocol):
    def __call__(
        self,
        config: UnifiedConfig,
        initial_state: PipelineState | None,
        **kwargs: object,
    ) -> int: ...


# Late import to avoid circular dependency
try:
    from ralph.pipeline.runner import run as _imported_run_func
except ImportError:
    _run_func: _RunnerFunc | None = None
else:
    _run_func = cast("_RunnerFunc", _imported_run_func)


class _FallbackConsole:
    def print(self, *args: object, **kwargs: object) -> None:
        return None


class _ConsoleLike(Protocol):
    def print(self, *args: object, **kwargs: object) -> None: ...


ConfigOverrides = dict[str, object]


def _create_console() -> _ConsoleLike:
    try:
        console_module = importlib.import_module("rich.console")
    except ModuleNotFoundError:
        return _FallbackConsole()

    return cast("_ConsoleLike", console_module.Console())


console: _ConsoleLike = _create_console()


# Exit codes
_EXIT_SUCCESS = 0
_EXIT_CONFIG_ERROR = 1
_EXIT_INTERRUPT = 130
_EXIT_PREFLIGHT = 2


class _LoadResult(NamedTuple):
    config: UnifiedConfig
    workspace_scope: WorkspaceScope | None
    initial_state: PipelineState | None
    policy_bundle: PolicyBundle | None


def _load_configuration(
    config_path: pathlib.Path | None,
    cli_overrides: ConfigOverrides,
    resume: bool,
) -> _LoadResult | int:
    """Load configuration and resolve workspace scope.

    Returns:
        _LoadResult on success, or int error code on failure.
    """
    try:
        workspace_scope = None if config_path is not None else resolve_workspace_scope()
        config = load_config(config_path, cli_overrides, workspace_scope=workspace_scope)
    except Exception as e:
        logger.error("Failed to load configuration: {}", e)
        return _EXIT_CONFIG_ERROR

    initial_state: PipelineState | None = None
    policy_bundle: PolicyBundle | None = None

    if workspace_scope is not None:
        try:
            policy_bundle = load_policy(workspace_scope.root / ".agent")
        except Exception as e:
            logger.warning("Failed to load policy bundle: {}", e)
            console.print(f"[red]Preflight error: {e}[/red]")
            return _EXIT_PREFLIGHT

    if resume:
        initial_state = ckpt.load()
        if initial_state is None:
            console.print("[yellow]No checkpoint found to resume from[/yellow]")

    return _LoadResult(
        config=config,
        workspace_scope=workspace_scope,
        initial_state=initial_state,
        policy_bundle=policy_bundle,
    )


def _print_not_initialized_panel() -> None:
    """Print a friendly 'not initialized' panel for completely fresh workspaces."""
    content = Text()
    content.append(
        "Ralph Workflow orchestrates AI coding agents through a "
        "planning → development → review → fix loop "
        "driven by your PROMPT.md.\n\n"
    )
    content.append("Next steps:\n", style="bold cyan")
    content.append("  1. Run ")
    content.append("ralph --init", style="cyan")
    content.append(" to scaffold PROMPT.md and .agent/ configs\n")
    content.append("  2. Edit ")
    content.append("PROMPT.md", style="cyan")
    content.append(" with your task\n")
    content.append("  3. Run ")
    content.append("ralph", style="cyan")
    content.append(" to start the pipeline\n\n")
    content.append("Docs: ", style="dim")
    content.append("docs/sphinx/getting-started.md", style="dim cyan")
    content.append(" — step-by-step walkthrough for new users", style="dim")
    panel = Panel(
        content,
        title="Ralph Workflow is not initialized here yet",
        border_style="yellow",
        padding=(1, 2),
    )
    console.print(panel)


def _run_preflight_checks(  # noqa: PLR0911
    config: UnifiedConfig,
    workspace_scope: WorkspaceScope | None,
    policy_bundle: object,
    initial_state: PipelineState | None,
) -> int:
    """Run all preflight validation checks.

    Returns:
        _EXIT_SUCCESS if all checks pass, _EXIT_PREFLIGHT if any check fails.
    """
    from ralph.policy.models import PolicyBundle  # noqa: PLC0415
    from ralph.policy.validation import validate_required_inputs  # noqa: PLC0415

    # validate_required_inputs requires workspace_scope
    if workspace_scope is not None:
        # Fresh-state detection: workspace has neither PROMPT.md nor .agent
        prompt_path = workspace_scope.root / "PROMPT.md"
        agent_dir = workspace_scope.root / ".agent"
        if not prompt_path.exists() and not agent_dir.exists():
            _print_not_initialized_panel()
            return _EXIT_PREFLIGHT

        try:
            validate_required_inputs(workspace_scope)
        except PolicyValidationError as e:
            console.print(f"[red]Preflight error: {e.message}[/red]")
            return _EXIT_PREFLIGHT

    # Only run policy-based validations if we have a policy bundle
    if policy_bundle is not None and isinstance(policy_bundle, PolicyBundle):
        # validate_drain_contracts
        try:
            from ralph.policy.validation import validate_drain_contracts  # noqa: PLC0415
            validate_drain_contracts(policy_bundle)
        except PolicyValidationError as e:
            console.print(f"[red]Preflight error: {e.message}[/red]")
            return _EXIT_PREFLIGHT

        # validate_agent_chains_satisfiable requires agent registry
        try:
            agent_registry = AgentRegistry.from_config(config)
            validate_agent_chains_satisfiable(policy_bundle, agent_registry)
        except PolicyValidationError as e:
            console.print(f"[red]Preflight error: {e.message}[/red]")
            return _EXIT_PREFLIGHT

        # validate_recovery_config
        try:
            validate_recovery_config(policy_bundle)
        except PolicyValidationError as e:
            console.print(f"[red]Preflight error: {e.message}[/red]")
            return _EXIT_PREFLIGHT

        # validate_checkpoint_against_policy
        if initial_state is not None:
            try:
                validate_checkpoint_against_policy(initial_state, policy_bundle)
            except CheckpointPolicyMismatchError as e:
                console.print(f"[red]Checkpoint mismatch: {e}[/red]")
                return _EXIT_PREFLIGHT
            except PolicyValidationError as e:
                console.print(f"[red]Preflight error: {e.message}[/red]")
                return _EXIT_PREFLIGHT

    return _EXIT_SUCCESS


def _print_dry_run(initial_state: PipelineState | None, config: UnifiedConfig) -> None:
    """Print dry-run information."""
    console.print("[cyan]Dry run mode[/cyan]")
    console.print(_detail_text("Phase", initial_state.phase if initial_state else "planning"))
    console.print(_detail_text("Iterations", str(config.general.developer_iters)))
    console.print(_detail_text("Review passes", str(config.general.reviewer_reviews)))


def _execute_pipeline(
    config: UnifiedConfig,
    initial_state: PipelineState | None,
    policy_bundle: object,
    verbosity: Verbosity | None,
) -> int:
    """Execute the pipeline.

    Returns:
        Exit code from pipeline runner.
    """
    if _run_func is None:
        logger.error("Pipeline runner is unavailable")
        console.print("[red]Pipeline runner is unavailable[/red]")
        return _EXIT_CONFIG_ERROR

    try:
        kwargs: dict[str, object] = {}
        runner_params = signature(_run_func).parameters
        if verbosity is not None and "verbosity" in runner_params:
            kwargs["verbosity"] = verbosity
        if policy_bundle is not None and "policy_bundle" in runner_params:
            kwargs["policy_bundle"] = policy_bundle
        return _run_func(config, initial_state, **kwargs)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        if initial_state is not None:
            _save_interrupt_checkpoint(initial_state)
        return _EXIT_INTERRUPT
    except CheckpointPolicyMismatchError as e:
        console.print(f"[red]Checkpoint mismatch: {e}[/red]")
        return _EXIT_PREFLIGHT
    except PolicyValidationError as e:
        console.print(f"[red]Pipeline configuration error: {e.message}[/red]")
        return _EXIT_PREFLIGHT
    except Exception as e:
        logger.exception("Pipeline execution failed: {}")
        console.print(_status_text("Pipeline failed", str(e), "red"))
        return _EXIT_CONFIG_ERROR


def _save_interrupt_checkpoint(initial_state: PipelineState) -> None:
    """Save checkpoint on interrupt."""
    try:
        update_data: ConfigOverrides = {"interrupted_by_user": True}
        interrupted_state = initial_state.model_copy(update=update_data)
        ckpt.save(interrupted_state)
    except Exception:
        logger.warning("Checkpoint save failed during interrupt", exc_info=True)


def _status_text(label: str, detail: str, style: str) -> Text:
    text = Text()
    text.append(f"{label}:", style=style)
    text.append(" ")
    text.append(detail)
    return text


def _detail_text(label: str, detail: str) -> Text:
    text = Text()
    text.append(f"  {label}: ")
    text.append(detail)
    return text


# Backward compatibility: expose run_pipeline for direct invocation
def run_pipeline(
    config_path: pathlib.Path | None = None,
    cli_overrides: ConfigOverrides | None = None,
    dry_run: bool = False,
    resume: bool = False,
    verbosity: Verbosity | None = None,
) -> int:
    """Run the Ralph Workflow pipeline (backward compatibility wrapper).

    Args:
        config_path: Path to configuration file.
        cli_overrides: CLI flag overrides for config.
        dry_run: If True, run without invoking agents.
        resume: If True, resume from checkpoint.
        verbosity: Optional explicit verbosity passed through to the runner.

    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    # Phase 1: Load configuration
    load_result = _load_configuration(config_path, cli_overrides or {}, resume)
    if isinstance(load_result, int):
        return load_result

    # Phase 2: Preflight validation (before any pipeline activity)
    preflight_result = _run_preflight_checks(
        load_result.config,
        load_result.workspace_scope,
        load_result.policy_bundle,
        load_result.initial_state,
    )
    if preflight_result != _EXIT_SUCCESS:
        return preflight_result

    # Phase 3: Handle dry-run
    if dry_run:
        _print_dry_run(load_result.initial_state, load_result.config)
        return _EXIT_SUCCESS

    # Phase 4: Execute pipeline
    return _execute_pipeline(
        load_result.config,
        load_result.initial_state,
        load_result.policy_bundle,
        verbosity,
    )
