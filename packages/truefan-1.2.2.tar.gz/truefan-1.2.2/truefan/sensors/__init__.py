"""Sensor backend interface and shared types."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import StrEnum


class SensorClass(StrEnum):
    """Classification of a temperature sensor."""

    CPU = "cpu"
    AMBIENT = "ambient"
    DRIVE = "drive"
    NVME = "nvme"
    OTHER = "other"


def sensor_name(backend: str, *parts: str) -> str:
    """Build a normalized sensor name from backend and device path parts.

    Joins with underscores, replaces spaces and hyphens with underscores.
    E.g. sensor_name("ipmi", "CPU Temp") → "ipmi_CPU_Temp".
    """
    raw = "_".join([backend, *parts])
    return raw.replace(" ", "_").replace("-", "_")


@dataclass(frozen=True, kw_only=True)
class SensorReading:
    """A single temperature reading from a sensor.

    The name is a normalized id built by sensor_name(), e.g.
    "ipmi_CPU_Temp", "smart_sda", "lmsensors_coretemp_isa_0000_Core_0".
    If the hardware reports thermal limits, temp_max and temp_crit
    carry those values. A sensor's temp_max overrides the curve's
    max_cooling_temp when computing demanded duty.
    """

    name: str
    sensor_class: SensorClass
    temperature: float
    temp_max: float | None = None
    temp_crit: float | None = None


class SensorError(Exception):
    """Base exception for sensor-related failures."""


class SensorBackend(ABC):
    """Interface for a temperature sensor backend.

    Each backend discovers and reads sensors every poll cycle.
    If no sensors are available, scan() returns an empty list.
    """

    @abstractmethod
    def scan(self) -> list[SensorReading]:
        """Discover sensors and return current readings."""


def available_backends(bmc: "BmcConnection | None" = None) -> list[SensorBackend]:
    """Probe the system and return backends for available sensor sources.

    If a BmcConnection is provided, the IPMI sensor backend is included.
    Subprocess-based backends (SMART, NVMe, lm-sensors) are included
    if their tools are found on PATH.
    """
    import shutil

    # Local imports: avoid circular dependency (sensor backends import from
    # this module, so we can't import them at module level).
    from truefan.sensors.ipmi import IpmiSensorBackend
    from truefan.sensors.lmsensors import LmSensorBackend
    from truefan.sensors.nvme import NvmeSensorBackend
    from truefan.sensors.smart import SmartSensorBackend

    backends: list[SensorBackend] = []
    if bmc is not None:
        backends.append(IpmiSensorBackend(bmc))
    if shutil.which("smartctl"):
        backends.append(SmartSensorBackend())
    if shutil.which("nvme"):
        backends.append(NvmeSensorBackend())
    if shutil.which("sensors"):
        backends.append(LmSensorBackend())
    return backends
