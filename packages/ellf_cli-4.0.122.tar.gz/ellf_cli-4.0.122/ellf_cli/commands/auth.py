"""ellf auth — token transfer between machines.

The device-flow login is awkward when the ellf CLI is running on a
remote workstation: the operator has to either keep the SSH session
alive while completing a browser sign-in within the device-code's
short polling window, or run ``ellf login --no-browser`` separately
and tab-switch between terminals.

``ellf auth push <host>`` short-circuits all of that: it serialises
the local machine's FileSecrets blob and pipes it via SSH to ``ellf
auth import`` on the remote, which writes it to the remote's secrets
file. The operator authenticates once on their laptop (where the
browser flow works naturally) and shares the resulting token with
each remote that needs it.
"""

import subprocess
import sys
from typing import Optional

from radicli import Arg
from wasabi import msg

from ..auth import FileSecrets
from ..cli import cli
from ._state import get_root_cfg


@cli.subcommand("auth", "import")
def auth_import() -> None:
    """Read a serialised FileSecrets blob from stdin and write it to
    the local secrets file.

    Counterpart to ``ellf auth push``. Existing local auth state is
    overwritten; the file is written 0600 by FileSecrets.save.
    """
    raw = sys.stdin.read()
    if not raw.strip():
        msg.fail("No input on stdin — pipe a token blob from 'ellf auth push'.")
        raise SystemExit(1)
    try:
        secrets = FileSecrets.model_validate_json(raw)
    except Exception as e:
        msg.fail(f"Invalid token blob: {e}")
        raise SystemExit(1)
    ctx = get_root_cfg()
    secrets.save(ctx.secrets_path)
    msg.good(f"Auth state imported to {ctx.secrets_path}")


@cli.subcommand(
    "auth",
    "push",
    host=Arg(help="SSH host to push the token to"),
    remote_ellf=Arg(
        "--remote-ellf",
        help=(
            "Command to run on the remote (default: 'ellf' from PATH). "
            "Pass an absolute path or shell-expanded form when ellf isn't "
            "on the remote login shell's PATH, e.g. '$HOME/ellf-test/venv/bin/ellf'."
        ),
    ),
)
def auth_push(host: str, remote_ellf: Optional[str] = None) -> None:
    """Push local auth state to a remote machine via SSH.

    Reads the local FileSecrets, JSON-serialises it, and pipes it to
    ``<remote_ellf> auth import`` over an SSH connection to *host*.
    Authentication is delegated to ssh — anything in your ssh config
    (host aliases, ProxyJump, key-based auth) just works.

    The pushed blob includes id_token, api_token, and any cached
    broker_tokens. id_token expiry is dictated by the issuer (typically
    ~1h), so this is a "give the remote a usable session" operation,
    not a permanent provisioning. Re-run when the token expires.
    """
    ctx = get_root_cfg()
    # Use model_validate_json directly rather than FileSecrets.load — the
    # protocol-typed return value erases the concrete FileSecrets type and
    # hides model_dump_json. This also lets us treat "no file" distinctly
    # from "empty FileSecrets", giving a more useful error message.
    try:
        raw_secrets = ctx.secrets_path.read_text()
    except FileNotFoundError:
        msg.fail(f"No local auth state at {ctx.secrets_path} — run 'ellf login' first.")
        raise SystemExit(1)
    secrets = FileSecrets.model_validate_json(raw_secrets)
    if not secrets.id_token:
        msg.fail("No id_token in local auth state — run 'ellf login' first.")
        raise SystemExit(1)
    blob = secrets.model_dump_json()
    remote_cmd = (remote_ellf or "ellf") + " auth import"
    msg.info(f"Pushing auth state to {host} ({remote_cmd})...")
    result = subprocess.run(
        ["ssh", host, remote_cmd],
        input=blob,
        text=True,
        capture_output=True,
    )
    if result.stdout:
        sys.stdout.write(result.stdout)
    if result.stderr:
        sys.stderr.write(result.stderr)
    if result.returncode != 0:
        msg.fail(f"ssh exited {result.returncode}")
        raise SystemExit(result.returncode)
    msg.good(f"Auth state pushed to {host}.")
