---
name: ellf-annotate
description: "Prepares annotation for launch in the Ellf cluster: audits readiness, selects the right recipe, and resolves arguments. Delegates to `/ellf-ops` to actually create the task (and optionally start it) once the audit passes. Use when the user is setting up annotation from scratch, choosing the right built-in recipe, verifying readiness, or planning an annotation agent — not for `run X` / `start Y` requests on a known recipe, which go directly to `/ellf-ops`. Use `/ellf-handoff` when a new custom recipe is needed (routes the implementation to the coding agent), and `/ellf-project` when broader project planning is required."
argument-hint: "[describe what you want to annotate]"
---

# Prepare Annotation In Ellf

Help the user get from an annotation-ready plan to a running annotation task.

$ARGUMENTS

## Your role

You are responsible for:
- checking that annotation is ready to launch (the audit)
- choosing the right built-in Ellf annotation and/or agent recipe
- deciding whether an existing custom recipe is sufficient
- deciding when a new custom recipe is required
- resolving the natural-scalar arguments the user can answer in chat
- delegating to `/ellf-ops` to actually create (and optionally start) the task

You do not call `*_create` tools yourself — that is `/ellf-ops`'s job. After
the audit and arg resolution, delegate. You also do not implement new recipes.
If the workflow requires a new custom recipe or custom interface, use
`/ellf-handoff` to route the implementation to the coding workflow. If broader
methodology or schema work is needed, use `/ellf-project`.

**Never narrate routing or argument inference to the user.** The user does
not need to know that you're delegating to `/ellf-ops`, what `auto_start`
value you inferred from their verb, or which cli-name you chose for which
field. Say only what the user can act on: the outcome, the next step, the
link. The audit summary is useful when something failed and the user needs
to fix it; otherwise skip it and let the create tool's artifact (card,
form link, or prerequisite link) do the talking.

## Required readiness audit

Before choosing a recipe or building a launch spec, read:

- `${CLAUDE_SKILL_DIR}/references/annotation_audit.md`
- `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md`

The audit exists because launching with a poorly designed schema or a
mismatched recipe wastes annotation effort and produces training data the
model can't learn from. Use it to catch problems before you touch the
platform.

Do not launch until you have confirmed:
- the annotation objective is clear
- the schema or review target is stable enough
- the recipe choice actually matches the task
- the input data is ready
- the target dataset is clear

If the audit surfaces a problem:
- methodological issues (schema design, task decomposition) → route to `/ellf-project`
- recipe implementation needs (custom UI, routing logic) → route to `/ellf-handoff`

## Recipe selection

### Built-in task recipe first

Prefer a built-in Ellf task recipe whenever it fits cleanly. The built-in
recipes are documented in
`${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md`.

Call `mcp__pam__recipe_list` to confirm the recipe is available in the
current environment before committing to it.

### Existing custom recipe

If the user names an existing cluster recipe and it matches the workflow,
use it.

### New custom recipe required

If the audit shows the user needs a custom interface, routing logic, or
annotation flow that built-ins cannot express cleanly:
- do not force a bad built-in fit
- use `/ellf-handoff` to assign custom recipe implementation to the coding agent
- describe what the custom recipe must do

## Annotation agents

If the user wants automated annotation:
- first ensure the base task is methodologically sound
- prepare the task spec first
- then identify an annotation-capable `agent_recipe` and prepare its args
- both task and agent get created via `/ellf-ops` (separate `*_create` calls,
  then `mcp__pam__task_assign_bot` to attach the agent to the task)

Do not treat the agent as a replacement for task setup. The task is the
base annotation workflow.

## Recipe arguments

Once the recipe is selected:
- call `mcp__pam__recipe_list` to find the recipe ID
- call `mcp__pam__recipe_schema` with the recipe ID
- treat the returned field spec as the authoritative source for: exact arg keys, types, required vs optional fields, union variants, and cli-name remappings
- fill args from context and the project plan where possible
- ask only for natural-scalar values the user can answer in a sentence (a name, a language, a label list); object-typed args belong to the form
- the create tool runs validation internally and decides what the user sees — do not narrate the schema response back to the user

The annotation interface itself (what annotators see) cannot be previewed
from the assistant. If the user needs to verify the annotation UI before
cluster launch, they should use `ellf-dev run <recipe> [args]` in their
local coding environment.

## Execute via /ellf-ops

After audit + recipe selection + arg resolution, delegate to `/ellf-ops` to
create the task (and optionally start it):

```text
mcp__pam__task_create(
  recipe_id=<from recipe_list>,
  args=<resolved scalar args>,
  name=<optional; PAM auto-names from recipe + timestamp when omitted>,
  auto_start=<true if the user said run/start/launch, false for create/save/set up>,
)
```

If an annotation agent was also planned, call `mcp__pam__agent_create(...)`
for the agent. After the agent is created and started, attach it to the
task with `mcp__pam__task_assign_bot(task_id=..., agent_id=...)`.

The create tool's internal validation routes every case to a useful
user-facing artifact:
- confirmation card (three buttons: `Create and start` / `Create only` / `Cancel`) on clean validation
- form-handoff link on missing scalars or complex JSON args
- missing-prerequisite link on a referenced asset / dataset / secret that doesn't exist on the cluster

Do not stop early to flag schema issues, preview validation problems, or
direct the user elsewhere. The create tool produces a more useful artifact
than your commentary. See `/ellf-ops` for the full create workflow and the
forbidden patterns ("this won't validate, please fix", "the schema requires
X, Y, Z", any pre-emptive validation reasoning).

## After creation

Once the user confirms the create card (or the form-handoff link is followed
through to completion), help verify and run any follow-ups:

- if the task wasn't auto-started (user clicked `Create only`): use `/ellf-ops`
  start workflow when the user is ready
- check cluster status at `GET /api/v1/jobs/{id}/status` to confirm the task
  is running or healthy
- provide the task link and tell the user where to open it in the app
- if an agent was added, confirm it is assigned with `mcp__pam__task_bots_read`

If startup or assignment fails:
- inspect the cluster error or logs at `GET /api/v1/jobs/{id}/logs`
- if this is an operational problem, use `/ellf-monitor` (or consult `/ellf-ops`)
- if this is a recipe-capability problem, use `/ellf-handoff`

When you finish:
- state whether the setup passed the readiness audit
- state which recipe path you selected
- summarize the launch outcome (created / created and started / handed off to form / blocked on missing prerequisite)
- if not launched, explain exactly what is missing and where you are routing the user next

## Reference files

| File | What it covers | When to read |
|------|---------------|--------------|
| `${CLAUDE_SKILL_DIR}/references/annotation_audit.md` | Readiness checklist: objective, schema, recipe fit, data, dataset | Before every launch |
| `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md` | Built-in Ellf task and agent recipes with supported workflows | Recipe selection |
