# Data & Infrastructure CLI Reference

## Assets

Assets are registered pointers to data resources (files, directories, models, etc.) on the cluster.

```bash
ellf assets list [--json]
ellf assets info "<name>" [--json]
ellf assets create "<name>" --kind <input|model|patterns|vectors> "<cluster_path>"
ellf assets delete "<name>"
```

## Datasets

Datasets are named Prodigy annotation stores on the cluster database.

```bash
ellf datasets list [--json]
ellf datasets info "<name>" [--json]
ellf datasets create "<name>" --kind <kind>
ellf datasets delete "<name>"
ellf datasets export "<name>" --output <path>   # exports as JSONL
```

## Files

Manage files on the cluster's storage bucket directly.

```bash
ellf files ls "<remote_path>" [--recurse]
ellf files cp "<src>" "<dest>" [--recurse] [--make-dirs] [--overwrite]
ellf files rm "<remote_path>" [--recurse] [--missing-ok]
ellf files rsync "<src>" "<dest>"
ellf files stats "<remote_path>"
```

Use path aliases (e.g. `{assets}`) as variables in remote paths:
```bash
ellf files ls "{assets}/"
ellf files cp ./data.jsonl "{assets}/project/data.jsonl" --make-dirs
```

## Secrets

Secrets are named pointers to credentials stored securely on the cluster as Kubernetes secrets.

**NEVER ask the user to paste an API key or secret value in conversation.** Secret values must not appear in chat history. Instead, instruct the user to run the command themselves in a separate shell.

### How secrets work

`ellf secrets create` does two things: stores the actual value on the cluster (running in K8s), and registers a metadata pointer in PAM. The secret value is passed as a `KEY=VALUE` positional argument, or entered interactively via hidden `getpass()` prompt if omitted.

### Commands

```bash
ellf secrets list [--json]
ellf secrets info "<name>" [--json]
ellf secrets create "<name>" [KEY=VALUE ...] [--secrets-path "<path_prefix>"]
ellf secrets delete "<name>"
```

### Creating a secret with a value

To create a secret with its actual value, the user must run one of these **in a separate shell** (not in this conversation):

```bash
# Option 1: pass value inline
ellf secrets create MY_SECRET MY_SECRET=the-actual-value

# Option 2: interactive hidden prompt (more secure)
ellf secrets create MY_SECRET
# → will prompt for the value via getpass()
```

Use `--exists-ok` to overwrite an existing secret. Use `--secrets-path` to namespace secrets under a prefix.

### When a recipe or agent needs a secret

1. Check if the secret exists: `ellf secrets list --json`
2. If missing, tell the user to create it themselves in a separate shell, providing the exact command template (with a placeholder for the value)
3. Wait for the user to confirm before proceeding

## Packages

Python packages published to the cluster for use by recipes.

```bash
ellf packages list [--json]
ellf packages info "<name>" [--json]
ellf packages delete "<name>"
```

## Path aliases

Named variables for cluster storage locations, usable as `{alias}` in paths.

```bash
ellf paths list [--json]
ellf paths info "<name>" [--json]
ellf paths create "<name>" "<remote_path>"
ellf paths delete "<name>"
```

## Publishing

### Publish data (upload + register as asset in one step)

```bash
ellf publish data <src> "<dest>" \
  --name "<asset_name>" \
  [--version 1.0.0] \
  [--kind <input|patterns|...>] \
  [--loader jsonl]
```

This is the preferred way to upload local files to the cluster — it copies the file and creates the asset record atomically.

### Publish code (recipe package)

```bash
ellf publish code <package_path> --package-version <version>
```

Use this to publish a finished local recipe package. If the package still needs code changes, use `/ellf-prodigy` first.

## Recipes

```bash
ellf recipes list [--json]
ellf recipes info "<name>" [--json]
ellf recipes init <package_name>     # scaffold a new recipes package
```

## Cluster management

```bash
# Status and health
ellf clusters check               # connectivity and service health
ellf clusters check --deep        # K8s, NFS, database checks
ellf clusters nodes --json        # node capacity and utilization

# Manage
ellf clusters list [--json]
ellf clusters info "<name>" [--json]
ellf clusters update "<name>" [--address "<url>"]
```

## Projects

```bash
ellf projects list [--json]
ellf projects info "<name>" [--json]
ellf projects create "<name>" "<description>"
ellf projects delete "<name>"
```
