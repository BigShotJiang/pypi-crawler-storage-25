---
name: ellf-support
description: Prepare and send a support request to the Ellf team from the web assistant. Use when the user wants human help, wants to contact the Ellf team, needs expert review of a stuck workflow, or says things like "I need support", "can someone look at this", "send this to the Ellf team", "I'm stuck", or "I want human feedback". This skill collects the issue, summarizes the current state, asks whether to attach the full conversation transcript, and sends it via `mcp__pam__support_request_create`. If the tool is unavailable or fails, it prepares a support-ready summary and tells the user how to send it.
argument-hint: "[describe your issue]"
---

# Human Support From The Web Assistant

Help the user escalate to human support cleanly and accurately.

$ARGUMENTS

## Scope

You are not a debugging skill here. Your job is to:
- collect the user's support request
- summarize the current issue and relevant context
- include the most relevant recent operational state when useful
- ask whether to attach the full conversation transcript
- submit the request with `mcp__pam__support_request_create` when available
- otherwise provide a support-ready summary and clear next steps

Do not claim that a request was sent unless `mcp__pam__support_request_create` actually succeeded.

## Collect the issue

If `$ARGUMENTS` already contains a clear issue description, use it.

Otherwise use `AskUserQuestion` to collect:
- what is going wrong
- what the user expected
- whether they want debugging help, workflow advice, or product feedback

Keep the question short and practical.

## Transcript consent

Always ask explicitly whether the user wants to attach the full conversation
transcript from PAM.

In the web assistant, the transcript source is the PAM conversation history for
the current conversation. This is not the local Claude Code session JSONL and
does not include the local debug log from `~/.claude/debug/...`.

Use `AskUserQuestion` with two clear choices:
- summary only
- summary + full transcript

Do not attach the transcript unless the user opts in.
When calling the tool, pass the exact string `summary_only` or
`attach_full_transcript` in `transcript_consent`. Do not use booleans.

## Gather context

Use the current conversation as the main context source.

The web assistant is already scoped to the current PAM project and conversation.
Do not run `ellf projects list`, `ellf projects info`, or any other CLI project
discovery command here.

Use these tools exactly when relevant:
- `mcp__pam__support_request_create` to submit the support request
- `mcp__pam__project_plan_read` to gather current project context
- `mcp__pam__todo_list` and `mcp__pam__todo_read` for recent request context
- `mcp__pam__task_list`, `mcp__pam__action_list`, and `mcp__pam__agent_list`
  for project runtime state inside PAM
- `mcp__cluster__cluster_request` only for cluster/runtime state that PAM does not provide

If the user indicates the request is not tied to the current project, explain
that this skill is scoped to the current project session and offer to prepare a
support-ready summary they can send manually instead of guessing another project.

If useful, gather only the minimum relevant state:
- current project plan summary
- task, action, or agent status if the issue is operational
- recent error messages or cluster failures if they are central to the issue

Do not try to read unavailable private logs or cluster file contents.

## Build the support summary

Produce a concise support-ready summary with:
- user issue
- what the user was trying to accomplish
- relevant project or workflow context
- key failure symptoms or errors
- current state
- what has already been tried

Keep it compact and high signal.

## Submission rule

If `mcp__pam__support_request_create` is available and succeeds:
- call it with `user_comment`, `summary`, and `transcript_consent`
- confirm that the request was sent
- provide the returned reference ID
- say whether the PAM conversation transcript was attached
- if the user opted in to transcript but `transcript_attached` is false, check
  `transcript_empty_reason` and tell the user clearly

The tool is already scoped to the current project and current conversation.
Do not try to choose a different project in this skill.

If the tool is unavailable or fails:
- do not pretend to send anything
- tell the user direct submission is not available in this session
- provide the support-ready summary in the response
- tell the user to email Ellf support directly at `support@ellf.ai`

## Output format

When direct submission is unavailable, present:

| Field | Value |
|---|---|
| Issue | <short title> |
| Type | <bug / workflow advice / feedback> |
| Current state | <short summary> |

Then include a short support-ready summary they can send.

## Tone

Be direct and calm. Do not over-apologize. Do not imply backend submission happened unless it actually did.
