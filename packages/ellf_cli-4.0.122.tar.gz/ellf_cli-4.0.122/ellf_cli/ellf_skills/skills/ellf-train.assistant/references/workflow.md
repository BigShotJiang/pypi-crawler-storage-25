# Training Workflow (Assistant)

This is your decision guide for the Ellf web assistant. At each step you'll see
what the assistant can handle directly and when to delegate to `/ellf-handoff`.

Every training run gets a full analysis — don't just check if the overall score
is "good enough."

---

## Phase 1: Setup

```
START
  |
  +-- Have annotated data?
  |     +-- No  -> Invoke `ellf-annotate`.
  |     |     Pass the task type, labels, and any data source.
  |     +-- Yes -> Is it exported to .spacy format?
  |                 +-- No (still a Prodigy dataset) ->
  |                 |     /ellf-handoff: export with data-to-spacy, validate with
  |                 |     spacy debug data. Return here when .spacy files are ready.
  |                 +-- Yes -> Continue
  |
  +-- Check data volume before proceeding
  |     Query the dataset size — via PAM, cluster, or whatever the user
  |     has told you. If the user gave you example counts or you can
  |     retrieve annotation stats, check against these thresholds:
  |
  |       - textcat: 200+ total examples, 30+ per label
  |       - NER: 50+ examples per entity type
  |       - new pipeline from scratch: 100+ total (hard minimum)
  |
  |     Below these, training will produce near-random models. Don't
  |     launch a cluster job that burns GPU time to arrive at "need
  |     more data."
  |
  |     +-- Thresholds not met
  |     |     Tell the user the data is insufficient and what the gaps
  |     |     are (which labels, how many more needed). Route to
  |     |     `ellf-annotate` with the task type, current labels, and
  |     |     per-label counts.
  |     |
  |     +-- Can't determine volume (no stats available)
  |     |     Ask the user how many examples they have. Don't assume
  |     |     the data is sufficient just because it exists.
  |     |
  |     +-- Thresholds met -> Continue
  |
  +-- Select training paradigm (assistant handles this — knowledge only)
  |     Read: training_paradigms.md (full decision framework)
  |     Read: model_selection.md (base model choice within fine-tuning)
  |     +-- Fine-tune pretrained (default) -> Continue below
  |     +-- Other strategy (pretraining, distillation, active learning) ->
  |           Discuss strategy here, then /ellf-handoff for implementation
  |
  +-- Have a config?
  |     +-- No  -> Discuss architecture here first, then /ellf-handoff to generate
  |     |     Read: model_selection.md (to inform the architecture discussion)
  |     |     Tell the coding agent: task type, labels, paradigm, base model,
  |     |     expected output path, dataset location on cluster
  |     +-- Yes, config exists on cluster -> Continue
  |
  +-- READY TO TRAIN -> Launch section below
```

---

## Launch

Cluster training runs as an action. Launch via PAM → cluster.

### 1. Find the training recipe

```text
mcp__pam__recipe_list
```

Filter for training-type recipes. If multiple candidates exist, pick the one
matching the user's framework (spaCy, Prodigy, etc.).

### 2. Prepare args

```text
mcp__pam__recipe_schema(recipe_id="<id>")
```

The returned field spec is authoritative for arg keys, types, required vs
optional, and union variants. Fill from context (config path, output dir,
dataset paths on cluster). Ask the user only for natural-scalar values
that are obviously missing. The create tool runs validation internally
and decides what the user sees next.

### 3. Create the action

```text
mcp__pam__action_create(recipe_id="<id>", name="<name>", args=<resolved args>)
```

### 4. Read back the created action

```text
mcp__pam__action_read(action_id="<id>")
```

You need the full `plan` object for the cluster start payload.

### 5. Start the action

```text
mcp__cluster__cluster_request(
  method="POST",
  path="/api/v1/jobs/start-job",
  body={
    "job_id": "<action.id>",
    "job_type": "action",
    "name": "<action.name>",
    "container": "<action.plan.container>",
    "plan": {
      "recipe_name": "<action.plan.recipe_name>",
      "args": "<action.plan.args>",
      "positional_fields": "<action.plan.positional_fields>",
      "cli_names": "<action.plan.cli_names>",
      "package_name": "<action.plan.package_name>",
      "objects": "<action.plan.objects>"
    }
  }
)
```

### 6. Confirm start

```text
mcp__cluster__cluster_request(method="GET", path="/api/v1/jobs/{id}/status")
```

Report the action name, job ID, and current state.

---

## Phase 2: Train & Monitor

```
TRAINING LAUNCHED
  |
  +-- DURING TRAINING — check status and interpret alerts:
  |
  |     mcp__cluster__cluster_request GET /api/v1/jobs/{id}/status
  |     mcp__cluster__cluster_request GET /api/v1/jobs/{id}/logs?tail_lines=100
  |
  |     +-- nan_loss
  |     |     Alert immediately, recommend stopping via `ellf-ops`.
  |     |     Read: diagnostics.md Class 2
  |     |
  |     +-- loss_spike
  |     |     Don't surface unless sustained (3+ consecutive).
  |     |
  |     +-- plateau
  |     |     Mention after 8+ evals without improvement.
  |     |
  |     +-- overfitting
  |           Mention when sustained. If best score is low (e.g., F < 0.75 for NER):
  |           Read: diagnostics.md Class 3
  |
  +-- TRAINING COMPLETE -> Phase 3
```

For continuous /loop monitoring, delegate to `ellf-monitor`.

---

## Phase 3: Analyze Results

Full evaluation (spacy evaluate, training curves from JSONL, model applied to corpus)
requires local file access — use `/ellf-handoff` for that. From the assistant you
can analyze whatever scores the training job emitted to logs.

```
TRAINING COMPLETE
  |
  +-- 1. EXTRACT SCORES FROM LOGS
  |     mcp__cluster__cluster_request GET /api/v1/jobs/{id}/logs
  |     Look for the final score and best checkpoint score.
  |     Read: evaluation_guide.md S1 (reading score output)
  |
  +-- 2. CHECK PER-LABEL SCORES (if available in logs)
  |     Read: evaluation_guide.md S2 (Per-Label Error Analysis)
  |     A model at 0.90 overall can have one label at 0.30.
  |     Diagnose P/R pattern per underperforming label:
  |       High P, low R -> too few or diverse examples
  |       Low P, high R -> label ambiguous or overlaps another
  |       Low P, low R  -> label not learned
  |
  +-- 3. CHECK AGAINST BASELINES (knowledge-based)
  |     A model at 79% means little if a prior-probability baseline gets 78%.
  |
  +-- 4. FULL ANALYSIS -> /ellf-handoff
  |     Training curves (training_log.jsonl)
  |     spacy evaluate on model-best
  |     Model applied to training corpus (false positive/negative inspection)
  |     Data split quality, selection bias checks
  |
  +-- 5. SYNTHESIZE -> Phase 4
```

---

## Phase 4: Decide Next Step

Recommend ONE next action. Follow the priority order.

```
DECISION POINT
  |
  +-- Are there data issues?
  |     +-- Labels with < 50 examples -> Invoke `ellf-annotate`
  |     +-- Contradictory annotations / split issues ->
  |           /ellf-handoff: audit data, re-split, re-export, retrain
  |
  +-- Is the label scheme the problem?
  |     +-- Labels confused or unlearnable ->
  |           Discuss here, then invoke `ellf-annotate` for re-annotation
  |     Read: evaluation_guide.md S9
  |
  +-- Is training config or architecture the problem?
  |     -> /ellf-handoff: config tuning, architecture change, experiment design
  |     Read: model_selection.md (to inform the architecture discussion first)
  |
  +-- Are results good but need experiments (variance, sweeps)?
  |     -> /ellf-handoff: multi-trial or sweep scripts
  |
  +-- Results are good, no structural issues
        DONE — model is ready.
        Consider: package model, update project plan.
```

## Priority Order for Fixes

1. **Fix data** — more examples for underperforming labels, clean contradictions, fix alignment
2. **Fix label scheme** — merge confusing labels, remove unlearnable ones
3. **Tune training config** — dropout, LR, batch size → `/ellf-handoff`
4. **Change architecture** — only after data and labels are sound → `/ellf-handoff`
5. **Advanced experiments** — sweeps, pretraining → `/ellf-handoff`

Recommend the first actionable item, not the full list.

---

## Error Handling

```
ERROR OCCURRED
  |
  +-- Runtime failure (job crashed, cluster shows failed state)
  |     mcp__cluster__cluster_request GET /api/v1/jobs/{id}/logs
  |     mcp__cluster__cluster_request GET /api/v1/jobs/{id}/errors
  |     Read: diagnostics.md (6 problem classes with detection signals)
  |     If fix requires config or code changes -> /ellf-handoff
  |
  +-- Monitoring anomaly (NaN loss, divergence)
  |     Read: diagnostics.md Class 2 or Class 3
  |     Recommend stopping via `ellf-ops` if unrecoverable
  |
  +-- Operational issue (can't start, wrong worker class)
        Use `ellf-ops` for stop/restart; /ellf-handoff if recipe fix needed
```
