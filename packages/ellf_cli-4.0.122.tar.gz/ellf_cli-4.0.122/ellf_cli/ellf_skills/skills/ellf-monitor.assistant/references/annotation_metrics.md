# Annotation Metrics

Use this reference to interpret annotation activity and quality signals.

## What to watch

- Total annotation count — from `mcp__cluster__dataset_example_count`
- Dataset growth over time — compare counts across checks
- Number of active annotators or agents — from `mcp__cluster__dataset_session_counts`
  (each non-null key is a session_id; `null` means examples written directly via
  `db-in` rather than through an annotation session)
- Whether a running task is producing new examples — combine job status with
  example count over time

## Warning signals

- Very fast growth can indicate careless annotation
- Very slow or flat growth can indicate task reachability or assignment problems
- Frequent agent errors with no dataset growth usually mean the agent is failing to annotate
- Repeated pauses or restarts may indicate an unstable launch or worker issue

## Interpretation rules

- Do not infer annotation quality from counts alone
- Use counts and status to describe activity, not to prove correctness
- If progress is suspicious, recommend operational checks first, then methodology review if needed
