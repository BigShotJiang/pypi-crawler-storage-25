from __future__ import annotations

import html
import time
from datetime import date, timedelta
from datetime import date as _date
from decimal import Decimal
from pathlib import Path

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request
from fastapi import status as fastapi_status
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from loguru import logger
from sqlmodel import Session

from net_alpha.audit import (
    CashRef,
    NetContributedRef,
    Period,
    RealizedPLRef,
    UnrealizedPLRef,
    WashImpactRef,
)
from net_alpha.config import TaxConfig
from net_alpha.db.repository import Repository
from net_alpha.inbox.aggregator import gather_inbox
from net_alpha.inbox.config import load_inbox_config
from net_alpha.inbox.dismissals import toggle_dismissal
from net_alpha.portfolio.account_value import (
    AccountValueWarning,
    account_value_at,
    account_value_at_with_warnings,
    build_account_value_series,
    build_eval_dates,
)
from net_alpha.portfolio.allocation import build_allocation
from net_alpha.portfolio.calendar_pnl import monthly_pl_lifetime_stats, monthly_realized_pl_series
from net_alpha.portfolio.carryforward import get_effective_carryforward
from net_alpha.portfolio.cash_flow import (
    build_cash_balance_series,
    build_cash_deployment_series,
    cash_allocation_slice,
    compute_cash_kpis,
    compute_chart_head_kpis,
)
from net_alpha.portfolio.freshness import compute_price_freshness
from net_alpha.portfolio.models import AccountValuePoint
from net_alpha.portfolio.pnl import compute_kpis, compute_wash_impact
from net_alpha.portfolio.positions import (
    compute_open_option_positions,
    compute_open_positions,
    compute_open_short_option_positions,
)
from net_alpha.portfolio.tax_planner import (
    MissingTaxConfig,
    TaxBrackets,
    compute_offset_budget,
    project_year_end_tax,
)
from net_alpha.portfolio.top_movers import build_top_movers
from net_alpha.portfolio.wash_watch import recent_loss_closes
from net_alpha.prefs.overview_layout import OverviewLayout
from net_alpha.prefs.profile import resolve_effective_profile
from net_alpha.pricing.service import PricingService
from net_alpha.web.account_filter import parse_accounts
from net_alpha.web.dependencies import get_pricing_service, get_repository
from net_alpha.web.fragment_cache import bump_fragment_revision

router = APIRouter()

# Forward-fill window mirrored from account_value._FORWARD_FILL_DAYS so the
# warm range covers the dates the per-(ticker,date) loop will actually probe.
_CURVE_WARM_PADDING_DAYS = 7


def _warm_historical_for_curve(
    *,
    svc: PricingService,
    eval_dates: list[date],
    equity_lots: list,
    benchmark_symbol: str | None,
) -> None:
    """Bulk-prefetch closes for every (equity ticker + benchmark, date) the
    curve builder will probe. Without this, Lifetime view fan-outs to ~12K
    sequential Yahoo calls and Yahoo rate-limits us into a hung request."""
    if not eval_dates:
        return
    equity_tickers = sorted({lot.ticker for lot in equity_lots if lot.option_details is None})
    # Skip when there's no portfolio history — the curve is trivially empty
    # and warming the benchmark alone produces no useful chart.
    if not equity_tickers:
        return
    tickers = list(equity_tickers)
    if benchmark_symbol:
        tickers.append(benchmark_symbol)
    warm_start = min(eval_dates) - timedelta(days=_CURVE_WARM_PADDING_DAYS)
    warm_end = max(eval_dates)
    svc.warm_historical_range(tickers, warm_start, warm_end)


def _resolve_profile(repo: Repository, accounts: list[str]):
    prefs = repo.list_user_preferences()
    filter_id = _resolve_account_id(accounts, repo)
    return resolve_effective_profile(prefs=prefs, filter_account_id=filter_id)


def _parse_period(period: str | None, current_year: int) -> tuple[tuple[int, int] | None, str]:
    """Return ((start, end_exclusive) | None, label)."""
    if not period or period == "ytd":
        return ((current_year, current_year + 1), f"YTD {current_year}")
    if period == "lifetime":
        return (None, "Lifetime")
    try:
        y = int(period)
        return ((y, y + 1), str(y))
    except ValueError:
        return ((current_year, current_year + 1), f"YTD {current_year}")


def _resolve_account_id(accounts: list[str], repo: Repository) -> int | None:
    """Resolve to a single account ID when exactly ONE account is selected, else None.

    Provenance MetricRefs encode a single int; multi-select degrades to None
    (taxpayer-level). The user re-applies the filter on the destination page.
    """
    if len(accounts) != 1:
        return None
    target = accounts[0]
    for a in repo.list_accounts():
        if f"{a.broker}/{a.label}" == target:
            return a.id
    return None


def _build_metric_refs(
    period_tuple: tuple[int, int] | None,
    period_label: str,
    account_id: int | None,
) -> dict[str, object]:
    """Pre-compute one MetricRef per KPI cell on the Portfolio dashboard."""
    refs: dict[str, object] = {
        "lifetime_realized": RealizedPLRef(
            kind="realized_pl",
            period=Period(start=_date(1970, 1, 1), end=_date(2100, 1, 1), label="Lifetime"),
            account_id=account_id,
            symbol=None,
        ),
        "lifetime_unrealized": UnrealizedPLRef(
            kind="unrealized_pl",
            account_id=account_id,
            symbol=None,
        ),
        "period_unrealized": UnrealizedPLRef(
            kind="unrealized_pl",
            account_id=account_id,
            symbol=None,
        ),
        "cash": CashRef(kind="cash", account_id=account_id),
    }
    if period_tuple is not None:
        period = Period(
            start=_date(period_tuple[0], 1, 1),
            end=_date(period_tuple[1], 1, 1),
            label=period_label,
        )
        refs["realized_period"] = RealizedPLRef(
            kind="realized_pl",
            period=period,
            account_id=account_id,
            symbol=None,
        )
        refs["wash_impact_period"] = WashImpactRef(
            kind="wash_impact",
            period=period,
            account_id=account_id,
        )
        refs["net_contributed_period"] = NetContributedRef(
            kind="net_contributed",
            period=period,
            account_id=account_id,
        )
    return refs


@router.post("/splits/sync")
def sync_splits(
    request: Request,
    symbols: str | None = Query(default="ALL"),
    svc: PricingService = Depends(get_pricing_service),
    repo: Repository = Depends(get_repository),
) -> dict[str, object]:
    if not symbols:
        raise HTTPException(status_code=400, detail="symbols query param required")
    if symbols.strip().upper() == "ALL":
        sym_list = sorted({lot.ticker for lot in repo.all_lots() if lot.option_details is None})
    else:
        sym_list = [s.strip() for s in symbols.split(",") if s.strip()]
    if not sym_list:
        return {"applied_count": 0, "skipped_count": 0, "error_symbols": []}
    result = svc.sync_splits(sym_list, repo=repo)
    if result.applied_count:
        bump_fragment_revision(request)
    return {
        "applied_count": result.applied_count,
        "skipped_count": result.skipped_count,
        "error_symbols": result.error_symbols,
    }


@router.post("/prices/refresh")
def refresh_prices(
    request: Request,
    symbols: str | None = Query(default=None),
    svc: PricingService = Depends(get_pricing_service),
    repo: Repository = Depends(get_repository),
) -> dict[str, object]:
    if not symbols:
        raise HTTPException(status_code=400, detail="symbols query param required")
    if symbols.strip().upper() == "ALL":
        sym_list = sorted({lot.ticker for lot in repo.all_lots() if lot.option_details is None})
    else:
        sym_list = [s.strip() for s in symbols.split(",") if s.strip()]
    if not sym_list:
        # Nothing to refresh (no open lots, or empty list)
        return {"fetched": [], "missing": [], "degraded": False}
    quotes = svc.refresh(sym_list)
    snap = svc.last_snapshot()
    if quotes:
        bump_fragment_revision(request)
    return {
        "fetched": list(quotes.keys()),
        "missing": snap.missing_symbols,
        "degraded": snap.degraded,
    }


@router.get("/", response_class=HTMLResponse)
def portfolio_page(
    request: Request,
    period: str | None = None,
    account: list[str] = Query(default_factory=list),
    group_options: str = "merge",
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    accounts: list[str] = parse_accounts(account)
    account_filter_active: bool = bool(accounts)
    imports = repo.list_imports()
    accounts_available = sorted({imp.account_display for imp in imports})

    today = date.today()
    current_year = today.year
    import_years = {imp.imported_at.year for imp in imports}
    available_years = sorted(import_years | {current_year}, reverse=True)

    selected_period = period or "ytd"
    snap = svc.last_snapshot()
    price_freshness, price_freshness_label = compute_price_freshness(snap)
    return request.app.state.templates.TemplateResponse(
        request,
        "portfolio.html",
        {
            "imports": imports,
            "accounts_available": accounts_available,
            "selected_accounts": accounts,
            "account_filter_active": account_filter_active,
            "available_years": available_years,
            "current_year": current_year,
            "selected_period": selected_period,
            "group_options": group_options,
            "toolbar_action": "/",
            "toolbar_hx_target": "#portfolio-body",
            "toolbar_hx_get": "/portfolio/body",
            "price_freshness": price_freshness,
            "price_freshness_label": price_freshness_label,
        },
    )


@router.get("/portfolio/kpis", response_class=HTMLResponse)
def portfolio_kpis(
    request: Request,
    period: str | None = None,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    accounts: list[str] = parse_accounts(account)
    account_filter_active: bool = bool(accounts)
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)
    trades = repo.all_trades()
    lots = repo.all_lots()
    symbols = sorted({lot.ticker for lot in lots if lot.option_details is None})
    prices = svc.get_prices(symbols)
    kpis = compute_kpis(
        trades=trades,
        lots=lots,
        prices=prices,
        period_label=period_label,
        period=period_tuple,
        accounts=accounts or None,
        gl_lots=repo.list_all_gl_lots(),
    )
    wi = compute_wash_impact(
        violations=repo.all_violations(),
        period_label=period_label,
        period=period_tuple,
        accounts=accounts or None,
    )
    snap = svc.last_snapshot()
    account_id = _resolve_account_id(accounts, repo)
    # Open shorts (CSPs) — used for cash-secured / pledged-cash badges in the
    # Cash KPI tile so the user can see how much of their cash is collateral.
    scoped_trades_for_shorts = [t for t in trades if t.account in set(accounts)] if accounts else trades
    open_shorts = compute_open_short_option_positions(
        scoped_trades_for_shorts,
        gl_option_closures=repo.get_option_gl_closures(),
    )
    cash_secured_total = sum((s.cash_secured for s in open_shorts), start=Decimal("0"))
    csp_count = sum(1 for s in open_shorts if s.call_put == "P")
    offset_budget = compute_offset_budget(
        repo=repo,
        year=today.year,
        carryforward=get_effective_carryforward(repo, today.year),
    )
    cfg = request.app.state.tax_brackets_cfg
    projection = None
    has_tax_config = cfg is not None
    if cfg is not None:
        brackets = TaxBrackets(
            filing_status=cfg.filing_status,
            state=cfg.state,
            federal_marginal_rate=cfg.federal_marginal_rate,
            state_marginal_rate=cfg.state_marginal_rate,
            ltcg_rate=cfg.ltcg_rate,
            qualified_div_rate=cfg.qualified_div_rate,
        )
        try:
            projection = project_year_end_tax(repo=repo, year=today.year, brackets=brackets)
        except MissingTaxConfig:
            projection = None
            has_tax_config = False
    profile = _resolve_profile(repo, accounts)

    # Cash KPIs — needed for the Cash tile and for total_account_value.
    cash_events = repo.list_cash_events(account_id=None)
    if accounts:
        cash_events = [e for e in cash_events if e.account in set(accounts)]
        scoped_trades_for_cash = [t for t in trades if t.account in set(accounts)]
    else:
        scoped_trades_for_cash = trades
    holdings_value = kpis.open_position_value or Decimal("0")
    # Period start anchor for Total Return — account value at the close of the day
    # before the period began. Lifetime → 0; YTD/year → value on Dec 31 prior.
    if period_tuple is None:
        period_starting_value = Decimal("0")
    else:
        boundary = date(period_tuple[0], 1, 1) - timedelta(days=1)
        cash_points_for_anchor = build_cash_balance_series(
            events=cash_events,
            trades=scoped_trades_for_cash,
            period=None,  # need full history through the boundary
        )
        scoped_lots_for_anchor = [lt for lt in lots if lt.account in set(accounts)] if accounts else lots
        period_starting_value = account_value_at(
            on=boundary,
            trades=scoped_trades_for_cash,
            lots=scoped_lots_for_anchor,
            cash_points=cash_points_for_anchor,
            get_close=svc.get_historical_close,
        )
    cash_kpis = compute_cash_kpis(
        events=cash_events,
        trades=scoped_trades_for_cash,
        holdings_value=holdings_value,
        period=period_tuple,
        period_starting_value=period_starting_value,
    )

    # Hero / Today tile context.
    total_account_value: Decimal | None = (
        (kpis.open_position_value + cash_kpis.cash_balance) if kpis.open_position_value is not None else None
    )
    vs_contributed_delta: Decimal | None = (
        (total_account_value - cash_kpis.net_contributions) if total_account_value is not None else None
    )

    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_kpis.html",
        {
            "kpis": kpis,
            "snapshot": snap,
            "wash_impact_total": wi.disallowed_total,
            "wash_violations": wi.violation_count,
            "metric_refs": _build_metric_refs(period_tuple, period_label, account_id),
            "offset_budget": offset_budget,
            "projection": projection,
            "has_tax_config": has_tax_config,
            "profile": profile,
            "cash_secured_total": cash_secured_total,
            "csp_count": csp_count,
            "cash_kpis": cash_kpis,
            "total_account_value": total_account_value,
            "vs_contributed_delta": vs_contributed_delta,
            "selected_period": period or "ytd",
            "selected_accounts": accounts,
            "account_filter_active": account_filter_active,
        },
    )


PAGE_SIZE = 25


PAGE_SIZE_OPTIONS = (10, 25, 50, 100)


_SORT_KEYS: dict[str, callable] = {
    "symbol": lambda r: r.symbol.upper(),
    "qty": lambda r: r.qty,
    "market_value": lambda r: r.market_value,
    "open_cost": lambda r: r.open_cost,
    "avg_basis": lambda r: r.avg_basis,
    "cash_sunk": lambda r: r.cash_sunk_per_share,
    "unrealized": lambda r: r.unrealized_pl,
}


def _sort_rows(rows: list, sort: str | None, direction: str | None) -> list:
    """Sort holdings rows by a stable key. None values are pushed to the end
    regardless of direction so the user always sees priced rows first."""
    key_fn = _SORT_KEYS.get(sort or "")
    if key_fn is None:
        # Default: market_value desc with None last (the historical behavior).
        priced = [r for r in rows if r.market_value is not None]
        unpriced = [r for r in rows if r.market_value is None]
        priced.sort(key=lambda r: r.market_value, reverse=True)
        return priced + unpriced
    desc = (direction or "desc").lower() == "desc"
    has = [r for r in rows if key_fn(r) is not None]
    none_rows = [r for r in rows if key_fn(r) is None]
    has.sort(key=key_fn, reverse=desc)
    return has + none_rows


@router.get("/portfolio/positions", response_class=HTMLResponse)
def portfolio_positions(
    request: Request,
    period: str | None = None,
    account: list[str] = Query(default_factory=list),
    group_options: str = "merge",
    show: str = "open",  # "open" | "all"
    page: int = 1,
    page_size: int = PAGE_SIZE,
    symbols: str | None = None,
    q: str | None = None,
    sort: str | None = None,
    dir: str | None = None,
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    accounts: list[str] = parse_accounts(account)
    account_filter_active: bool = bool(accounts)
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)
    trades = repo.all_trades()
    lots = repo.all_lots()
    gl_closures = repo.get_equity_gl_closures()
    gl_option_closures = repo.get_option_gl_closures()
    all_lot_tickers = sorted({lot.ticker for lot in lots if lot.option_details is None})
    prices = svc.get_prices(all_lot_tickers)
    include_closed = show == "all"
    account_id_by_display = {f"{a.broker}/{a.label}": a.id for a in repo.list_accounts()}
    all_rows = compute_open_positions(
        trades=trades,
        lots=lots,
        prices=prices,
        period=period_tuple,
        accounts=accounts or None,
        include_closed=include_closed,
        gl_closures=gl_closures,
        gl_option_closures=gl_option_closures,
        gl_lots=repo.list_all_gl_lots(),
        account_id_by_display=account_id_by_display,
    )
    selected_symbols: set[str] = set()
    if symbols:
        selected_symbols = {s.strip().upper() for s in symbols.split(",") if s.strip()}
    # Universe for the symbol-picker reflects the current Show mode (Open vs All)
    # — independent of any active selection, so the user can pick a different
    # symbol after applying a filter. Selected symbols outside that universe are
    # not surfaced (e.g. you selected "GPRO" while in Show=All, then switched to
    # Show=Open — GPRO is closed and shouldn't reappear in the picker).
    universe = {r.symbol for r in all_rows}
    if selected_symbols:
        rows = [r for r in all_rows if r.symbol.upper() in selected_symbols]
    else:
        rows = list(all_rows)
    # Free-form substring filter on the underlying symbol — driven by the
    # page-level search input on /positions. Lets matches on later pages
    # surface (the client-side DOM filter only sees the current page).
    q_clean = (q or "").strip().upper()
    if q_clean:
        rows = [r for r in rows if q_clean in r.symbol.upper()]
    rows = _sort_rows(rows, sort, dir)
    if page_size not in PAGE_SIZE_OPTIONS:
        page_size = PAGE_SIZE
    total_rows = len(rows)
    total_pages = max(1, (total_rows + page_size - 1) // page_size)
    page = max(1, min(page, total_pages))
    start = (page - 1) * page_size
    page_rows = rows[start : start + page_size]
    query_parts = [f"period={period or 'ytd'}"]
    query_parts.extend(f"account={a}" for a in accounts)
    query_parts.append(f"group_options={group_options}")
    query_parts.append(f"symbols={'%2C'.join(sorted(selected_symbols))}")
    symbol_filter_config = {
        "selected": sorted(selected_symbols),
        "all": sorted(universe),
        "qsTemplate": "&".join(query_parts),
        "show": show,
        "pageSize": page_size,
    }
    profile = _resolve_profile(repo, accounts)
    extra_columns = profile.default_columns("holdings")
    # Inject targets-by-symbol + 'target' column when any targets exist.
    targets = repo.list_targets()
    targets_by_symbol = {t.symbol: t for t in targets}
    if targets and "target" not in extra_columns:
        extra_columns = list(extra_columns) + ["target"]
    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_table.html",
        {
            "rows": page_rows,
            "period_label": period_label,
            "show": show,
            "page": page,
            "total_pages": total_pages,
            "total_rows": total_rows,
            "page_size": page_size,
            "page_size_options": PAGE_SIZE_OPTIONS,
            "selected_symbols": sorted(selected_symbols),
            "symbol_filter_config": symbol_filter_config,
            "selected_period": period or "ytd",
            "selected_accounts": accounts,
            "account_filter_active": account_filter_active,
            "group_options": group_options,
            "profile": profile,
            "extra_columns": extra_columns,
            "targets_by_symbol": targets_by_symbol,
            "sort": sort or "market_value",
            "dir": (dir or "desc").lower(),
        },
    )


@router.get("/portfolio/allocation", response_class=HTMLResponse)
def portfolio_allocation_fragment(
    request: Request,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    accounts: list[str] = parse_accounts(account)
    today = date.today()
    trades = repo.all_trades()
    lots = repo.all_lots()
    symbols = sorted({lot.ticker for lot in lots if lot.option_details is None})
    prices = svc.get_prices(symbols)
    positions = compute_open_positions(
        trades=trades,
        lots=lots,
        prices=prices,
        period=(today.year, today.year + 1),
        accounts=accounts or None,
        gl_closures=repo.get_equity_gl_closures(),
        gl_option_closures=repo.get_option_gl_closures(),
        gl_lots=repo.list_all_gl_lots(),
    )
    allocation = build_allocation(positions=positions, top_n=10)
    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_allocation.html",
        {"allocation": allocation},
    )


@router.get("/holdings/options", response_class=HTMLResponse)
def holdings_options(
    request: Request,
    account: list[str] = Query(default_factory=list),
    page: int = 1,
    page_size: int = 25,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    """All open option positions (long + short) panel — rendered on /holdings.

    Pure read of trades + lots + GL closures, scoped by account. Sorted by
    expiry so the next contract to roll/manage is always at the top.
    """
    accounts: list[str] = parse_accounts(account)
    today = date.today()
    trades = repo.all_trades()
    lots = repo.all_lots()
    open_options_all = compute_open_option_positions(
        trades,
        lots,
        accounts=accounts or None,
        gl_closures=repo.get_equity_gl_closures(),
        gl_option_closures=repo.get_option_gl_closures(),
    )
    # Filter expired contracts (expiry < today): their collateral has already
    # been released — see pledged_cash_at() in portfolio/cash_flow.py — and
    # the broker has typically already closed them server-side. Leaving them
    # in the open list mixes non-actionable rows with truly open contracts
    # and overstates open exposure. The expired tally still surfaces via
    # ``expired_count`` for the panel header.
    open_options = [o for o in open_options_all if o.expiry >= today]
    expired_count = len(open_options_all) - len(open_options)
    cash_secured_total = sum((o.cash_secured for o in open_options), start=Decimal("0"))
    premium_received_total = sum((o.cash_basis for o in open_options if o.side == "short"), start=Decimal("0"))
    long_cost_total = sum((o.cash_basis for o in open_options if o.side == "long"), start=Decimal("0"))
    # 3-card mini-summary for the panel header (H7). Net premium signs short
    # premium received as a credit and long cost paid as a debit. Avg DTE is
    # qty-weighted across all open contracts (clamped to 0 when nothing open).
    total_qty = sum((o.qty for o in open_options), start=Decimal("0"))
    if total_qty > 0:
        avg_dte = sum(((o.expiry - today).days * o.qty for o in open_options), start=Decimal("0")) / total_qty
    else:
        avg_dte = Decimal("0")
    options_summary = {
        "open_contracts": total_qty,
        "net_premium": premium_received_total - long_cost_total,
        "avg_dte": avg_dte,
    }
    # Compute per-side/per-type counts from the full (pre-slice) list so the
    # summary header reflects totals even when pagination is active.
    long_count = sum(1 for o in open_options if o.side == "long")
    short_count = sum(1 for o in open_options if o.side == "short")
    put_count = sum(1 for o in open_options if o.call_put == "P")
    call_count = sum(1 for o in open_options if o.call_put == "C")
    option_counts = {
        "long": long_count,
        "short": short_count,
        "puts": put_count,
        "calls": call_count,
    }

    page_size_norm = page_size if page_size in (10, 25, 50, 100) else 25
    page_norm = max(1, page)
    total_rows = len(open_options)
    total_pages = max(1, (total_rows + page_size_norm - 1) // page_size_norm)
    page_norm = min(page_norm, total_pages)
    start_idx = (page_norm - 1) * page_size_norm
    end_idx = start_idx + page_size_norm
    open_options_page = open_options[start_idx:end_idx]
    pagination = {
        "page": page_norm,
        "page_size": page_size_norm,
        "total_pages": total_pages,
        "total_rows": total_rows,
        "page_size_options": (10, 25, 50, 100),
    }

    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_open_options.html",
        {
            "open_options": open_options_page,
            "cash_secured_total": cash_secured_total,
            "premium_received_total": premium_received_total,
            "long_cost_total": long_cost_total,
            "options_summary": options_summary,
            "option_counts": option_counts,
            "expired_count": expired_count,
            "today": today,
            "selected_accounts": accounts,
            "account_filter_active": bool(accounts),
            "pagination": pagination,
        },
    )


@router.get("/holdings/short-options", response_class=HTMLResponse)
def holdings_short_options_legacy(
    request: Request,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    """Backwards-compat alias — renders the unified options panel."""
    return holdings_options(request, account=account, repo=repo)


@router.get("/portfolio/equity-curve", response_class=HTMLResponse)
def portfolio_equity_curve(
    request: Request,
    period: str | None = None,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    accounts: list[str] = parse_accounts(account)
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)

    trades = repo.all_trades()
    lots = repo.all_lots()
    if accounts:
        accs_set = set(accounts)
        trades = [t for t in trades if t.account in accs_set]
        lots = [lot for lot in lots if lot.account in accs_set]

    cash_events = repo.list_cash_events(account_id=None)
    if accounts:
        cash_events = [e for e in cash_events if e.account in accs_set]

    # Lifetime cash points: build_account_value_series requires this so the
    # first AccountValuePoint of the period anchors on the pre-period
    # cumulative contributions; otherwise compute_chart_head_kpis would
    # double-count the contributions and emit a phantom negative period_growth.
    cash_points = build_cash_balance_series(
        events=cash_events,
        trades=trades,
        period=None,
    )

    event_dates = sorted({t.date for t in trades} | {e.event_date for e in cash_events})
    eval_dates = build_eval_dates(period=period_tuple, today=today, event_dates=event_dates)

    benchmark_symbol = request.app.state.pricing_config.benchmark_symbol
    _warm_historical_for_curve(
        svc=svc,
        eval_dates=eval_dates,
        equity_lots=lots,
        benchmark_symbol=benchmark_symbol,
    )

    account_points = build_account_value_series(
        trades=trades,
        lots=lots,
        cash_points=cash_points,
        eval_dates=eval_dates,
        get_close=svc.get_historical_close,
    )

    benchmark_points: list = []

    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_equity_curve.html",
        {
            "account_points": account_points,
            "benchmark_points": benchmark_points,
            "benchmark_symbol": benchmark_symbol,
            "period_label": period_label,
            "selected_period": period or "ytd",
            "selected_accounts": accounts,
        },
    )


@router.get("/portfolio/wash-watch", response_class=HTMLResponse)
def portfolio_wash_watch_fragment(
    request: Request,
    account: list[str] = Query(default_factory=list),
    window_days: int = 30,
    repo: Repository = Depends(get_repository),
) -> HTMLResponse:
    accounts: list[str] = parse_accounts(account)
    rows = recent_loss_closes(
        repo=repo,
        today=date.today(),
        window_days=window_days,
        accounts=accounts or None,
    )
    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_wash_watch.html",
        {"rows": rows, "window_days": window_days},
    )


def _compute_portfolio_body_context(
    *,
    request: Request,
    period: str | None,
    accounts: list[str],
    repo: Repository,
    svc: PricingService,
) -> dict[str, object]:
    """Heavy compute behind /portfolio/body. Pure function of (DB rows, prices,
    period, accounts); cached by portfolio_body keyed on the fragment revision."""
    today = date.today()
    current_year = today.year
    import_years = {imp.imported_at.year for imp in repo.list_imports()}
    available_years = sorted(import_years | {current_year}, reverse=True)
    period_tuple, period_label = _parse_period(period, today.year)

    all_trades = repo.all_trades()
    all_lots = repo.all_lots()
    if accounts:
        accs_set = set(accounts)
        scoped_trades = [t for t in all_trades if t.account in accs_set]
        scoped_lots = [lot for lot in all_lots if lot.account in accs_set]
    else:
        scoped_trades = all_trades
        scoped_lots = all_lots
    symbols = sorted({lot.ticker for lot in scoped_lots if lot.option_details is None})
    prices = svc.get_prices(symbols)
    snap = svc.last_snapshot()

    gl_lots_all = repo.list_all_gl_lots()
    gl_lots_scoped = [g for g in gl_lots_all if g.account_display in set(accounts)] if accounts else gl_lots_all
    kpis = compute_kpis(
        trades=scoped_trades,
        lots=scoped_lots,
        prices=prices,
        period_label=period_label,
        period=period_tuple,
        gl_lots=gl_lots_scoped,
    )
    # Hoist gl_option_closures so we don't re-scan the table for both
    # compute_open_positions and compute_open_short_option_positions.
    gl_option_closures = repo.get_option_gl_closures()
    positions_for_alloc = compute_open_positions(
        trades=scoped_trades,
        lots=scoped_lots,
        prices=prices,
        period=(today.year, today.year + 1),
        gl_closures=repo.get_equity_gl_closures(),
        gl_option_closures=gl_option_closures,
        gl_lots=gl_lots_scoped,
    )

    top_movers = build_top_movers(positions_for_alloc)

    # --- Cash flow ---
    cash_events = repo.list_cash_events(account_id=None)
    if accounts:
        cash_events = [e for e in cash_events if e.account in accs_set]
    # Use the same total `compute_kpis` already produced for the Hero tile and
    # `account_value_at` (period-start anchor) — both include open long-option
    # lots carried at basis. Summing `compute_open_positions` market values
    # alone skips those lots (it only iterates equity), which made the Total
    # Return tile read low by the long-option-basis amount and disagree with
    # the Hero tile and the explain panel on the same page.
    holdings_value_total = kpis.open_position_value or Decimal("0")
    # Period start anchor for Total Return — account value at the close of the day
    # before the period began. Lifetime → 0; YTD/year → value on Dec 31 prior.
    if period_tuple is None:
        period_starting_value = Decimal("0")
    else:
        boundary = date(period_tuple[0], 1, 1) - timedelta(days=1)
        cash_points_for_anchor = build_cash_balance_series(
            events=cash_events,
            trades=scoped_trades,
            period=None,  # need full history through the boundary
        )
        period_starting_value = account_value_at(
            on=boundary,
            trades=scoped_trades,
            lots=scoped_lots,
            cash_points=cash_points_for_anchor,
            get_close=svc.get_historical_close,
        )
    cash_kpis = compute_cash_kpis(
        events=cash_events,
        trades=scoped_trades,
        holdings_value=holdings_value_total,
        period=period_tuple,
        period_starting_value=period_starting_value,
    )
    # Monthly realized P&L series — feeds the wide bar chart on the overview
    # body, sits directly below the equity-curve row. Honors the page's
    # Period selector by truncating future months (YTD) or spanning the
    # first-trade-year through today (Lifetime). Trades are already
    # pre-scoped on `scoped_trades` above.
    monthly_pl_points = monthly_realized_pl_series(
        trades=scoped_trades,
        period=period_tuple,
        today=today,
    )
    # build_account_value_series requires the LIFETIME cash series (so the
    # first AccountValuePoint of the period anchors on the pre-period
    # cumulative contributions; see the docstring on build_account_value_series).
    # Period-scoped variant is not currently consumed elsewhere in this body,
    # but if reintroduced should be built separately.
    cash_points = build_cash_balance_series(
        events=cash_events,
        trades=scoped_trades,
        period=None,
    )
    cash_slice = cash_allocation_slice(
        events=cash_events,
        trades=scoped_trades,
    )

    # Account-value series (the redesigned equity curve). Built off the
    # lifetime cash_points + an event-anchored eval-date axis. See
    # docs/superpowers/specs/2026-05-02-equity-curve-redesign-design.md.
    account_event_dates = sorted({t.date for t in scoped_trades} | {e.event_date for e in cash_events})
    account_eval_dates = build_eval_dates(
        period=period_tuple,
        today=today,
        event_dates=account_event_dates,
    )
    benchmark_symbol = request.app.state.pricing_config.benchmark_symbol
    _warm_historical_for_curve(
        svc=svc,
        eval_dates=account_eval_dates,
        equity_lots=scoped_lots,
        benchmark_symbol=benchmark_symbol,
    )
    account_points = build_account_value_series(
        trades=scoped_trades,
        lots=scoped_lots,
        cash_points=cash_points,
        eval_dates=account_eval_dates,
        get_close=svc.get_historical_close,
    )
    # Cash deployment series (free / pledged / invested) — feeds the new
    # stacked-area cash chart. Reuses the AccountValuePoint date axis so the
    # equity and cash charts align tick-for-tick.
    cash_deployment_points = build_cash_deployment_series(
        account_points=account_points,
        trades=scoped_trades,
        events=cash_events,
        accounts=accounts,
        with_pledged=True,
    )

    benchmark_points: list = []

    open_shorts = compute_open_short_option_positions(
        scoped_trades,
        gl_option_closures=gl_option_closures,
    )
    cash_secured_total = sum(
        (s.cash_secured for s in open_shorts),
        start=Decimal("0"),
    )
    allocation = build_allocation(
        positions=positions_for_alloc,
        top_n=10,
        cash=cash_slice,
        cash_pledged=cash_secured_total,
    )
    premium_received_total = sum(
        (s.premium_received for s in open_shorts),
        start=Decimal("0"),
    )
    csp_count = sum(1 for s in open_shorts if s.call_put == "P")

    account_id = _resolve_account_id(accounts, repo)
    offset_budget = compute_offset_budget(
        repo=repo,
        year=today.year,
        carryforward=get_effective_carryforward(repo, today.year),
    )
    cfg = request.app.state.tax_brackets_cfg
    projection = None
    has_tax_config = cfg is not None
    if cfg is not None:
        brackets = TaxBrackets(
            filing_status=cfg.filing_status,
            state=cfg.state,
            federal_marginal_rate=cfg.federal_marginal_rate,
            state_marginal_rate=cfg.state_marginal_rate,
            ltcg_rate=cfg.ltcg_rate,
            qualified_div_rate=cfg.qualified_div_rate,
        )
        try:
            projection = project_year_end_tax(repo=repo, year=today.year, brackets=brackets)
        except MissingTaxConfig:
            projection = None
            has_tax_config = False
    profile = _resolve_profile(repo, accounts)

    # Hero / Today tile context (same as portfolio_kpis handler).
    body_total_account_value: Decimal | None = (
        (kpis.open_position_value + cash_kpis.cash_balance) if kpis.open_position_value is not None else None
    )
    body_vs_contributed_delta: Decimal | None = (
        (body_total_account_value - cash_kpis.net_contributions) if body_total_account_value is not None else None
    )

    if period_tuple is not None:
        # The brush strip was removed (it duplicated the Period dropdown and
        # the lifetime account-value compute it required dominated cold body
        # latency). The remaining lifetime stats below are cheap pure-data
        # ops, so they stay inline and feed the cash/monthly footnotes and
        # the per-tile "Lifetime …" subtext on the KPI row.
        lifetime_cash_points = build_cash_balance_series(
            events=cash_events,
            trades=scoped_trades,
            period=None,
        )
        # Lifetime cash deployment series — feeds compute_chart_head_kpis'
        # lifetime min/max KPI line, which only reads free_cash + pledged.
        # We synthesize cheap zero-priced AccountValuePoints off the lifetime
        # cash series so build_cash_deployment_series can reuse its date axis
        # without invoking the historical pricing pipeline (the lifetime
        # account-value compute used to dominate cold body latency — see the
        # comment on the brush-strip removal above).
        lifetime_avps = [
            AccountValuePoint(
                on=p.on,
                contributions=p.cumulative_contributions,
                holdings_value=Decimal("0"),
                cash_balance=p.cash_balance,
                account_value=p.cash_balance,
                net_pl=Decimal("0"),
            )
            for p in lifetime_cash_points
        ]
        lifetime_cash_deployment = build_cash_deployment_series(
            account_points=lifetime_avps,
            trades=scoped_trades,
            events=cash_events,
            accounts=accounts,
            with_pledged=True,
        )
        lifetime_monthly_pl = monthly_realized_pl_series(
            trades=scoped_trades,
            period=None,
            today=today,
        )
        monthly_pl_lifetime = monthly_pl_lifetime_stats(lifetime_monthly_pl)
        lifetime_kpis = compute_kpis(
            trades=scoped_trades,
            lots=scoped_lots,
            prices=prices,
            period_label="Lifetime",
            period=None,
            gl_lots=gl_lots_scoped,
        )
    else:
        lifetime_cash_deployment = []
        monthly_pl_lifetime = None
        lifetime_kpis = None

    chart_head_kpis = compute_chart_head_kpis(
        account_points=account_points,
        cash_deployment_points=cash_deployment_points,
        lifetime_cash_points=lifetime_cash_deployment,
        period_starting_value=cash_kpis.period_starting_value,
    )

    return {
        "kpis": kpis,
        "snapshot": snap,
        "allocation": allocation,
        "open_shorts": open_shorts,
        "cash_secured_total": cash_secured_total,
        "premium_received_total": premium_received_total,
        "csp_count": csp_count,
        "today": today,
        "cash_kpis": cash_kpis,
        "cash_points": cash_points,
        "cash_deployment_points": cash_deployment_points,
        "chart_head_kpis": chart_head_kpis,
        "cash_slice": cash_slice,
        "metric_refs": _build_metric_refs(period_tuple, period_label, account_id),
        "offset_budget": offset_budget,
        "projection": projection,
        "has_tax_config": has_tax_config,
        "profile": profile,
        "total_account_value": body_total_account_value,
        "vs_contributed_delta": body_vs_contributed_delta,
        "top_movers": top_movers,
        "benchmark_points": benchmark_points,
        "benchmark_symbol": benchmark_symbol,
        "account_points": account_points,
        "period_label": period_label,
        "monthly_pl_points": monthly_pl_points,
        "accounts": accounts,  # used by the inbox lazy-load wrapper
        "selected_period": period or "ytd",
        "selected_accounts": accounts,
        "account_filter_active": bool(accounts),
        "monthly_pl_lifetime": monthly_pl_lifetime,
        "lifetime_kpis": lifetime_kpis,
        "current_year": current_year,
        "available_years": available_years,
    }


@router.get("/portfolio/body", response_class=HTMLResponse)
def portfolio_body(
    request: Request,
    period: str | None = None,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    """Bundled fragment: KPIs + equity-curve + allocation + wash-watch.

    Heavy compute is memoized per (period, accounts, fragment_revision); the
    template still renders each request so request-scoped Jinja globals work.
    """
    accounts: list[str] = parse_accounts(account)
    t0 = time.perf_counter()
    cache = request.app.state.fragment_cache
    revision = request.app.state.fragment_revision
    key = ("/portfolio/body", period or "", tuple(sorted(accounts)), revision)
    ctx = cache.get(key)
    cache_hit = ctx is not None
    if ctx is None:
        ctx = _compute_portfolio_body_context(request=request, period=period, accounts=accounts, repo=repo, svc=svc)
        cache.set(key, ctx)
    # A2.2: When the toolbar triggers a body swap, also emit an OOB fragment
    # for the page H1 subline (which sits outside #portfolio-body).
    is_htmx = request.headers.get("HX-Request") == "true"
    if is_htmx:
        accounts_label = ", ".join(accounts) if accounts else "All accounts"
        period_label_for_subline = (period or "ytd").upper()
        oob_subline_html = (
            f'<div id="portfolio-subline" hx-swap-oob="true" '
            f'class="text-[13px] text-label-2 mt-[3px]">'
            f"{html.escape(accounts_label)} · {html.escape(period_label_for_subline)}"
            f"</div>"
        )
        # Don't mutate the cached ctx — build a per-request shallow copy.
        ctx = {**ctx, "oob_subline_html": oob_subline_html}
    else:
        ctx = {**ctx, "oob_subline_html": ""}
    profile = _resolve_profile(repo, accounts)
    layout = repo.get_overview_layout(profile.profile)
    ctx = {**ctx, "layout": layout, "edit_mode": False}
    response = request.app.state.templates.TemplateResponse(request, "_portfolio_body.html", ctx)
    if is_htmx:
        # Push the canonical Overview URL (/) instead of the fragment URL,
        # so reloads and shares of the current state land back on a full page.
        from urllib.parse import quote

        qs_parts = [f"period={period or 'ytd'}"]
        for a in accounts:
            qs_parts.append(f"account={quote(a, safe='')}")
        response.headers["HX-Push-Url"] = "/?" + "&".join(qs_parts)
    elapsed_ms = (time.perf_counter() - t0) * 1000
    logger.debug(
        "portfolio_body: {:.0f} ms cache_hit={} period={} accounts={!r}",
        elapsed_ms,
        cache_hit,
        period or "ytd",
        accounts,
    )
    return response


@router.post("/portfolio/layout/reorder", status_code=fastapi_status.HTTP_204_NO_CONTENT)
async def portfolio_layout_reorder(
    request: Request,
    repo: Repository = Depends(get_repository),
) -> Response:
    form_data = await request.form()
    row: list[str] = list(form_data.getlist("row"))
    raw_accounts: list[str] = list(form_data.getlist("account")) + list(request.query_params.getlist("account"))
    accounts = parse_accounts(raw_accounts)
    profile = _resolve_profile(repo, accounts)
    current = repo.get_overview_layout(profile.profile)
    new_layout = OverviewLayout(rows=row, hidden=current.hidden)
    repo.set_overview_layout(profile.profile, new_layout)
    return Response(status_code=204)


@router.post("/portfolio/layout/visibility", status_code=fastapi_status.HTTP_204_NO_CONTENT)
def portfolio_layout_visibility(
    row: str = Form(...),
    hidden: str = Form(...),
    account: list[str] = Form(default_factory=list),
    repo: Repository = Depends(get_repository),
) -> Response:
    """Toggle a single row's visibility in the current profile's overview layout.

    Body params:
    - ``row``: a KNOWN_ROWS key (unknown keys are silently dropped by sanitize).
    - ``hidden``: ``"true"`` to hide the row, ``"false"`` to show it.

    Idempotent: hiding an already-hidden row or showing an already-visible row
    is a no-op. Always returns 204.
    """
    accounts = parse_accounts(account)
    profile = _resolve_profile(repo, accounts)
    current = repo.get_overview_layout(profile.profile)
    want_hidden = hidden.lower() == "true"
    new_hidden = list(current.hidden)
    if want_hidden and row not in new_hidden:
        new_hidden.append(row)
    elif not want_hidden and row in new_hidden:
        new_hidden.remove(row)
    new_layout = OverviewLayout(rows=current.rows, hidden=new_hidden)
    repo.set_overview_layout(profile.profile, new_layout)
    return Response(status_code=204)


@router.post("/portfolio/layout/reset")
def portfolio_layout_reset(
    request: Request,
    account: list[str] = Form(default_factory=list),
    repo: Repository = Depends(get_repository),
) -> Response:
    """Reset the current profile's overview layout to the default row order.

    Deletes the saved ``overview_layout`` row for the profile so the next read
    returns ``default_overview_layout()``.

    HTMX callers (``HX-Request: true``) receive a 204 with an ``HX-Redirect``
    header pointing at ``/`` so the full page reloads cleanly. Non-HTMX callers
    receive a 303 redirect to ``/``.
    """
    accounts = parse_accounts(account)
    profile = _resolve_profile(repo, accounts)
    repo.clear_overview_layout(profile.profile)
    if request.headers.get("HX-Request") == "true":
        return Response(status_code=204, headers={"HX-Redirect": "/"})
    return RedirectResponse(url="/", status_code=303)


def _resolve_inbox_rates(tax: TaxConfig | None) -> tuple[Decimal, Decimal]:
    """Pull (short-term, long-term) effective rates from the cached tax config.

    ST = federal_marginal_rate + state_marginal_rate (ordinary income on ST gains)
    LT = ltcg_rate + state_marginal_rate (LTCG federal + state)

    Falls back to (0, 0) when no tax config is set — the LT-eligibility signal
    still emits items, but with dollar_impact = None, which the template
    renders without the +$X clause.

    Reads from app.state.tax_brackets_cfg (loaded once at startup, refreshed
    by the /settings POST) rather than re-reading config.yaml per request, so
    the inbox stays in sync with the rest of the dashboard's tax projections.
    """
    if tax is None:
        return Decimal("0"), Decimal("0")
    st = Decimal(str(tax.federal_marginal_rate)) + Decimal(str(tax.state_marginal_rate))
    lt = Decimal(str(tax.ltcg_rate)) + Decimal(str(tax.state_marginal_rate))
    return st, lt


@router.get("/portfolio/inbox", response_class=HTMLResponse)
def portfolio_inbox(
    request: Request,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    pricing: PricingService = Depends(get_pricing_service),
):
    accounts: list[str] = parse_accounts(account)
    cfg = load_inbox_config(Path.home() / ".net_alpha" / "config.yaml")
    st_rate, lt_rate = _resolve_inbox_rates(request.app.state.tax_brackets_cfg)
    today = _date.today()
    # gather_inbox only accepts a single account string; pass the first selected
    # account when exactly one is active, or None for all-accounts.
    inbox_account = accounts[0] if len(accounts) == 1 else None
    with Session(repo.engine) as session:
        items = gather_inbox(
            repo=repo,
            prices=pricing,
            session=session,
            today=today,
            config=cfg,
            st_rate=st_rate,
            lt_rate=lt_rate,
            account=inbox_account,
        )
    return request.app.state.templates.TemplateResponse(
        request,
        "_portfolio_inbox.html",
        {"items": items, "accounts": accounts, "account_filter_active": bool(accounts)},
    )


@router.post("/portfolio/inbox/dismiss/{dismiss_key:path}", response_class=HTMLResponse)
def portfolio_inbox_dismiss(
    request: Request,
    dismiss_key: str,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    pricing: PricingService = Depends(get_pricing_service),
):
    with Session(repo.engine) as session:
        toggle_dismissal(session, dismiss_key)
    return portfolio_inbox(request=request, account=account, repo=repo, pricing=pricing)


@router.get("/portfolio/explain/total-return", response_class=HTMLResponse)
def explain_total_return(
    request: Request,
    period: str | None = None,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    """Math explainer fragment for the Total Return KPI tile."""
    from net_alpha.portfolio.explain import build_total_return_breakdown

    accounts: list[str] = parse_accounts(account)
    today = date.today()
    period_tuple, period_label = _parse_period(period, today.year)

    trades = repo.all_trades()
    lots = repo.all_lots()
    if accounts:
        accs_set = set(accounts)
        trades = [t for t in trades if t.account in accs_set]
        lots = [lt for lt in lots if lt.account in accs_set]
    cash_events = repo.list_cash_events(account_id=None)
    if accounts:
        cash_events = [e for e in cash_events if e.account in accs_set]

    cash_points_full = build_cash_balance_series(
        events=cash_events,
        trades=trades,
        period=None,
    )

    starting_warning = AccountValueWarning()
    if period_tuple is None:
        starting_value = Decimal("0")
        is_lifetime = True
    else:
        boundary = date(period_tuple[0], 1, 1) - timedelta(days=1)
        starting_value, starting_warning = account_value_at_with_warnings(
            on=boundary,
            trades=trades,
            lots=lots,
            cash_points=cash_points_full,
            get_close=svc.get_historical_close,
        )
        is_lifetime = False

    symbols = sorted({lot.ticker for lot in lots if lot.option_details is None})
    prices = svc.get_prices(symbols) if symbols else {}
    gl_lots_all = repo.list_all_gl_lots()
    gl_lots_scoped = [g for g in gl_lots_all if g.account_display in accs_set] if accounts else gl_lots_all
    kpis_now = compute_kpis(
        trades=trades,
        lots=lots,
        prices=prices,
        period_label=period_label,
        period=period_tuple,
        gl_lots=gl_lots_scoped,
    )
    holdings_value = kpis_now.open_position_value or Decimal("0")
    cash_kpis = compute_cash_kpis(
        events=cash_events,
        trades=trades,
        holdings_value=holdings_value,
        period=period_tuple,
        period_starting_value=starting_value,
    )

    breakdown = build_total_return_breakdown(
        period_label=period_label,
        ending_value=cash_kpis.account_value,
        starting_value=starting_value,
        contributions=cash_kpis.period_net_contributions,
        realized_in_period=kpis_now.period_realized,
        is_lifetime=is_lifetime,
        unpriced_lot_count=starting_warning.dropped_lot_count,
        unpriced_basis_total=starting_warning.dropped_basis_total,
        unpriced_tickers=starting_warning.dropped_tickers,
    )
    return request.app.state.templates.TemplateResponse(
        request,
        "_explain_total_return.html",
        {"b": breakdown},
    )


@router.get("/portfolio/explain/unrealized", response_class=HTMLResponse)
def explain_unrealized(
    request: Request,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    """Math explainer fragment for the Unrealized P/L KPI tile.

    Period-agnostic — Unrealized always shows current open positions.
    """
    from net_alpha.portfolio.explain import build_unrealized_breakdown
    from net_alpha.portfolio.positions import consume_lots_fifo

    accounts: list[str] = parse_accounts(account)
    today = date.today()
    trades = repo.all_trades()
    lots = repo.all_lots()
    if accounts:
        accs_set = set(accounts)
        trades = [t for t in trades if t.account in accs_set]
        lots = [lt for lt in lots if lt.account in accs_set]

    gl_closures = repo.get_equity_gl_closures()
    gl_option_closures = repo.get_option_gl_closures()
    if accounts:
        gl_closures = {k: v for k, v in gl_closures.items() if k[0] in accs_set}
        gl_option_closures = {k: v for k, v in gl_option_closures.items() if k[0] in accs_set}

    consumed = consume_lots_fifo(
        lots=lots,
        trades=trades,
        gl_closures=gl_closures,
        gl_option_closures=gl_option_closures,
    )
    short_rows = compute_open_short_option_positions(
        trades,
        gl_option_closures=gl_option_closures,
    )
    symbols = sorted({lot.ticker for lot in lots} | {row.ticker for row in short_rows})
    prices = svc.get_prices(symbols) if symbols else {}

    breakdown = build_unrealized_breakdown(
        consumed=consumed,
        short_option_rows=short_rows,
        prices=prices,
        as_of=today,
    )
    return request.app.state.templates.TemplateResponse(
        request,
        "_explain_unrealized.html",
        {"b": breakdown},
    )


@router.get("/portfolio/explain/account-value", response_class=HTMLResponse)
def explain_account_value(
    request: Request,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    """Math explainer fragment for the TOTAL ACCOUNT VALUE hero KPI tile.

    Period-agnostic — Account Value is always a "right now" snapshot.
    """
    from net_alpha.portfolio.explain import build_account_value_breakdown
    from net_alpha.portfolio.positions import consume_lots_fifo

    accounts: list[str] = parse_accounts(account)
    today = date.today()
    trades = repo.all_trades()
    lots = repo.all_lots()
    if accounts:
        accs_set = set(accounts)
        trades = [t for t in trades if t.account in accs_set]
        lots = [lt for lt in lots if lt.account in accs_set]

    cash_events = repo.list_cash_events(account_id=None)
    if accounts:
        cash_events = [e for e in cash_events if e.account in accs_set]

    gl_lots = repo.list_all_gl_lots()
    if accounts:
        gl_lots = [g for g in gl_lots if g.account_display in accs_set]
    gl_closures = repo.get_equity_gl_closures()
    gl_option_closures = repo.get_option_gl_closures()
    if accounts:
        gl_closures = {k: v for k, v in gl_closures.items() if k[0] in accs_set}
        gl_option_closures = {k: v for k, v in gl_option_closures.items() if k[0] in accs_set}

    consumed = consume_lots_fifo(
        lots=lots,
        trades=trades,
        gl_closures=gl_closures,
        gl_option_closures=gl_option_closures,
    )
    short_rows = compute_open_short_option_positions(
        trades,
        gl_option_closures=gl_option_closures,
    )
    symbols = sorted({lot.ticker for lot in lots} | {row.ticker for row in short_rows})
    prices = svc.get_prices(symbols) if symbols else {}

    # KPIs for lifetime_realized_economic + missing_symbols.
    kpis_now = compute_kpis(
        trades=trades,
        lots=lots,
        prices=prices,
        period_label="Lifetime",
        period=None,
        gl_lots=gl_lots,
    )
    holdings_value = kpis_now.open_position_value or Decimal("0")
    cash_kpis = compute_cash_kpis(
        events=cash_events,
        trades=trades,
        holdings_value=holdings_value,
        period=None,
        period_starting_value=Decimal("0"),
    )

    fetched_at = svc.last_snapshot().fetched_at

    # Cash events that move the cash balance but are neither contributions
    # (transfers) nor trade P&L: dividends, interest, fees. Without this term
    # the source equation under-counts those flows.
    non_contribution_cash_flow = Decimal("0")
    for e in cash_events:
        if e.kind == "dividend" or e.kind == "interest":
            non_contribution_cash_flow += Decimal(str(e.amount))
        elif e.kind == "fee":
            non_contribution_cash_flow -= Decimal(str(e.amount))

    # In-kind share transfers create lots with cost basis but no cash impact.
    # The lot's basis sits in long_cost on the composition side; we mirror it
    # on the source side so transfers don't masquerade as P&L. transfer_out
    # rows carry basis on `proceeds` for split segments and None otherwise —
    # un-split rows leave a residual the builder surfaces.
    share_transfer_basis_net = Decimal("0")
    for t in trades:
        if t.basis_source == "transfer_in":
            share_transfer_basis_net += Decimal(str(t.cost_basis or 0))
        elif t.basis_source == "transfer_out":
            share_transfer_basis_net -= Decimal(str(t.proceeds or 0))

    breakdown = build_account_value_breakdown(
        consumed=consumed,
        short_option_rows=short_rows,
        prices=prices,
        cash_balance=cash_kpis.cash_balance,
        net_contributed=cash_kpis.net_contributions,
        lifetime_realized_economic=kpis_now.lifetime_realized_economic,
        non_contribution_cash_flow=non_contribution_cash_flow,
        share_transfer_basis_net=share_transfer_basis_net,
        missing_symbols=tuple(kpis_now.missing_symbols),
        fetched_at=fetched_at,
        as_of=today,
    )
    return request.app.state.templates.TemplateResponse(
        request,
        "_explain_account_value.html",
        {"b": breakdown},
    )


@router.get("/portfolio/explain/equity-point", response_class=HTMLResponse)
def explain_equity_point(
    request: Request,
    on: date,
    period: str | None = None,
    account: list[str] = Query(default_factory=list),
    repo: Repository = Depends(get_repository),
    svc: PricingService = Depends(get_pricing_service),
) -> HTMLResponse:
    """Math explainer fragment for a single point on the equity curve.

    Re-derives the active series to find ``previous_on`` (the prior point
    in the same filtered series), then calls the pure-function builder
    and renders ``_explain_equity_point.html``.
    """
    from dataclasses import replace as dc_replace

    from net_alpha.portfolio.cash_flow import CONTRIB_INFLOW_KINDS, CONTRIB_OUTFLOW_KINDS
    from net_alpha.portfolio.explain import build_equity_point_breakdown
    from net_alpha.portfolio.positions import consume_lots_fifo

    accounts: list[str] = parse_accounts(account)
    today = date.today()
    period_tuple, _period_label = _parse_period(period, today.year)

    trades = repo.all_trades()
    lots = repo.all_lots()
    cash_events = repo.list_cash_events(account_id=None)
    if accounts:
        accs_set = set(accounts)
        trades = [t for t in trades if t.account in accs_set]
        lots = [lt for lt in lots if lt.account in accs_set]
        cash_events = [e for e in cash_events if e.account in accs_set]

    # Re-derive the active series so we can locate `on` and its predecessor.
    # Lifetime cash points required by build_account_value_series (see its docstring).
    cash_points = build_cash_balance_series(
        events=cash_events,
        trades=trades,
        period=None,
    )
    event_dates = sorted({t.date for t in trades} | {e.event_date for e in cash_events})
    eval_dates = build_eval_dates(period=period_tuple, today=today, event_dates=event_dates)
    series = build_account_value_series(
        trades=trades,
        lots=lots,
        cash_points=cash_points,
        eval_dates=eval_dates,
        get_close=svc.get_historical_close,
    )

    by_date = {p.on: p for p in series}
    if on not in by_date:
        # Click on a date not in the filtered series — treat as starting snapshot.
        previous_on: date | None = None
        delta_av = Decimal("0")
    else:
        sorted_dates = sorted(by_date.keys())
        idx = sorted_dates.index(on)
        if idx == 0:
            previous_on = None
            delta_av = Decimal("0")
        else:
            previous_on = sorted_dates[idx - 1]
            cur = by_date[on].account_value
            prev = by_date[previous_on].account_value
            if cur is None or prev is None:
                delta_av = Decimal("0")
            else:
                delta_av = (cur - prev).quantize(Decimal("0.01"))

    # Open-lots-as-of-previous_on snapshots, mirroring `holdings_value_at`'s
    # FIFO-consumption pattern. We materialise remaining-qty/basis snapshots
    # via `Lot.model_copy(...)` so `_compute_mtm_movers` (which only reads
    # `.ticker`, `.quantity`, `.adjusted_basis`) sees the live-remainder.
    open_lots_prev: list = []
    extra_unpriced: list[str] = []
    extra_unpriced_basis = Decimal("0")
    if previous_on is not None:
        trades_asof = [t for t in trades if t.date <= previous_on]
        lots_asof = [lt for lt in lots if lt.date <= previous_on]
        consumed = consume_lots_fifo(lots=lots_asof, trades=trades_asof)
        for lot, rem_qty, rem_basis in consumed:
            if rem_qty <= 0:
                continue
            if lot.option_details is not None:
                # Options aren't priced via get_close. Surface them in the
                # unpriced caveat so the user understands why ΔUnrealized may
                # not fully account for an option-close between previous_on
                # and on.
                if lot.ticker not in extra_unpriced:
                    extra_unpriced.append(lot.ticker)
                extra_unpriced_basis += Decimal(str(rem_basis))
                continue
            open_lots_prev.append(
                lot.model_copy(update={"quantity": float(rem_qty), "adjusted_basis": float(rem_basis)})
            )

    trades_on = [t for t in trades if t.date == on]
    cash_on_date = [
        e
        for e in cash_events
        if e.event_date == on and (e.kind in CONTRIB_INFLOW_KINDS or e.kind in CONTRIB_OUTFLOW_KINDS)
    ]
    dividends_on_date = [e for e in cash_events if e.event_date == on and e.kind == "dividend"]
    violations = [v for v in repo.all_violations() if v.loss_sale_date == on]
    exempt_matches = [em for em in repo.list_exempt_matches() if _safe_iso_to_date(em.loss_sale_date) == on]

    # Starting "contributed-to-date" snapshot — reuse the lifetime cash-balance
    # series (which already folds contributions via the canonical
    # `cash_flow._event_contrib_delta` convention) and pick the last point
    # whose date is ``<= on``. Single source of truth, no parallel walk.
    cash_points_lifetime = build_cash_balance_series(
        events=cash_events,
        trades=trades,
        period=None,
    )
    contributed_to_date = next(
        (p.cumulative_contributions for p in reversed(cash_points_lifetime) if p.on <= on),
        Decimal("0"),
    )

    breakdown = build_equity_point_breakdown(
        on=on,
        previous_on=previous_on,
        trades_on_date=trades_on,
        cash_events_on_date=cash_on_date,
        dividend_events_on_date=dividends_on_date,
        open_lots_prev_day=open_lots_prev,
        violations_on_date=violations,
        exempt_matches_on_date=exempt_matches,
        get_close=svc.get_historical_close,
        delta_account_value=delta_av,
        starting_contributed_to_date=contributed_to_date,
    )
    if extra_unpriced:
        merged_tickers = tuple(sorted(set(breakdown.unpriced_tickers) | set(extra_unpriced)))
        merged_basis = breakdown.unpriced_basis_total + extra_unpriced_basis
        breakdown = dc_replace(
            breakdown,
            unpriced_tickers=merged_tickers,
            unpriced_basis_total=merged_basis,
        )
    return request.app.state.templates.TemplateResponse(
        request,
        "_explain_equity_point.html",
        {"b": breakdown},
    )


def _safe_iso_to_date(s: str | None) -> date | None:
    if not s:
        return None
    try:
        return date.fromisoformat(s)
    except (TypeError, ValueError):
        return None


@router.get("/portfolio/explain/dismiss", response_class=HTMLResponse)
def explain_dismiss() -> HTMLResponse:
    """Empty fragment used by the explainer panels' close button."""
    return HTMLResponse("")
