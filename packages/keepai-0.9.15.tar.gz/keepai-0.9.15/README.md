# keep

> **keep** = auto**mation** minus the auto. You stay in control.

CC Worker orchestration CLI — manage multiple groups with multiple workers across your terminal of choice (cmux, iTerm2, tmux, kitty, Terminal.app).

## What keep is

`keep` is an organizational control layer for AI work.

- In the current CLI, a `group` is the runtime term. Conceptually, it behaves like a `project`.
- A `task` is a work order / ticket inside that project.
- `supervisor`, `reviewer`, and `worker` are project members with different state-transition powers.
- The system is not mainly about how models think. It is about who can move state, who can approve escalation, and who can notify the final result.

In human-system terms, `keep` is closest to:

- a lightweight `ServiceNow` / ITSM flow
- a door-access approval system
- an OA-style approval workflow
- a small control plane that settles state after role-separated actions

Its job is to turn AI behavior into auditable state transitions, permission escalations, and multi-agent collaboration with explicit responsibility boundaries.

## What keep is not

`keep` is not:

- a plain chat protocol
- a generic agent-DAG framework
- a todo list with nicer wording
- bare RBAC

It sits above all of those. The unit it manages is not a message; it is a governed state transition inside an AI project.

## Design discipline

This abstraction is only useful if it stays strict.

- Keep the noun set small.
- Prefer real command attempts over hidden side channels.
- Prefer explicit state transitions over free-form conversation.
- Prefer auditability over cleverness.

If every exception grows a new entity, a new pseudo-command, or a hidden transport path, `keep` collapses into a worse BPM system with extra ceremony. The point is not to sound profound; the point is to keep AI labor governable.

## The Three-Party System

`keep` implements a relay system between three parties: **Human**, **Supervisor CC**, and **Worker CC**. At least one of them is always active — the system never stalls.

```
Worker stops → Daemon relays → Supervisor wakes up, evaluates, instructs Worker
                                        → Worker works → stops → Daemon relays → ...

All plans done → Supervisor notifies Human → Human decides: more plans or done
```

- **Worker CC** does the actual coding work. It doesn't know it's being managed.
- **Supervisor CC** is the direct manager of the project. It evaluates execution output, drives task and group state forward, and is accountable for the project's operational flow.
- **Human** sets the group direction and makes final decisions. Only gets notified when Supervisor needs input.
- **Daemon** is the relay — Worker stop 会通知 Supervisor；Reviewer stop 会被解析为 review 结果、聚合后再统一通知 Supervisor。Pure event bridge, no business decisions.

> **Supervisor and Worker are homogeneous agent sessions**. Their difference is role, not kind. The current runtime supports both Claude Code and Codex interactive sessions. A plain bash shell cannot serve as either: delivering notification text to a surface is not the same as acting on it. The session must be able to parse `<keep event>` tags, run group-scoped supervisor/task commands, and carry out the supervision loop.

## Reviewer

Reviewer 是人的分身，承载产品/技术/设计视角，作为 Supervisor 的独立外审。

### 创建 Reviewer
```bash
# 先在 ~/.keep/reviewers/ 下准备视角文件
keep <group_id> reviewer create --name product
```

### Reviewer 的 3 个状态审查事件
1. **task_proposed_review** — 审批 task 设计请求，结果是每个 task 进入 `pending` 或退回/保持 `proposed`
2. **task_submitted_review** — 审批 task 完成请求，结果是每个 task 进入 `completed` 或退回/保持 `in_progress`
3. **group_stop** — 最终 stop 闸门，同时承担原 `align` 语义：Reviewer 给出 `group -> stopped` 或 `group -> active`

另有一个**非判决同步通知**：`group_sync`。它只负责把最新 Group prompt / task 摘要同步给 Reviewer，不要求回传。

### Reviewer 审批机制

Reviewer 不再调用 `keep <group_id> reviewer <event_id> pass|reject|submit ...`。

收到 `review_request` 后，Reviewer 只做三件事：

1. 读取 review_request 和相关 rationale / task 上下文
2. 用同一个命令面行权：
   `task_proposed_review` 用 `keep <group_id> task update --status pending|proposed`
   `task_submitted_review` 用 `keep <group_id> task update --status completed|in_progress`
   `group_stop` 用 `keep group stop <group_id> --status stopped|active`
3. 等 daemon 聚合结算，并由 supervisor 收到统一的 `review_result`

Daemon 会读取 reviewer 提交到 open review 的资源目标状态，并把 reviewer 的最后一条消息作为解释上下文，一起聚合多 reviewer 结论，落 task / group 状态，并向 supervisor 发统一的 `review_result` 通知。

`keep group stop <group_id> --rationale <file>` 也遵循同一模型：supervisor 只能发起 stop 尝试；`group -> stopped` 的最终裁决权属于 reviewer。系统会自动发起 `group_stop` 审批，真正的 stop / 不 stop 通过后续 `review_result` 驱动。

## Task 状态机

proposed → pending → in_progress → completed

- `proposed`：初始状态，task create 后；通过 `task update --tasks ... --status pending --rationale ...` 提交设计审查。审查期间 task 仍保持 `proposed`
- `pending`：Reviewer 批准设计，可以派发给 Worker
- `in_progress`：Worker 正在执行
- `completed`：通过 `task update --tasks ... --status completed --rationale ...` 提交完成审查；审查通过后 task 才真正进入 `completed`

## Requirements

- Python 3.12+
- [uv](https://github.com/astral-sh/uv)
- CC Stop hook configured (see [Setup](#setup))
- One of the supported terminal backends below

### Terminal backends

Pick any one — `keep` drives them via their native automation API.

| Backend | Setup |
|---------|-------|
| **cmux** | Settings → Socket Control Mode → **Automation** |
| **iTerm2** | Settings → General → Magic → **Enable Python API**. Install deps: `uv add iterm2 pyobjc-framework-Cocoa` |
| **tmux** | `brew install tmux` (no extra config) |
| **kitty** | In `~/.config/kitty/kitty.conf`: `allow_remote_control yes` and `listen_on unix:/tmp/kitty.sock`. Export `KITTY_LISTEN_ON=unix:/tmp/kitty.sock` |
| **Terminal.app** | System Settings → Privacy & Security → Accessibility (grant to your shell/terminal). Known issue: reviewer/worker create hangs — prefer another backend for multi-role missions |

## Install

```bash
uv tool install keep
```

## Setup

Configure CC's Stop hook globally so `keep` can consume the shared stop transport for both Worker and Reviewer:

```json
// Claude Code: ~/.claude/settings.json (or your cac env settings)
{
  "hooks": {
    "Stop": [
      {
        "hooks": [{ "type": "command", "command": "bash ~/.keep/on-stop.sh" }]
      }
    ]
  }
}
```

Create the hook script:

```bash
mkdir -p ~/.keep

cat > ~/.keep/on-stop.sh << 'EOF'
#!/bin/bash
set -euo pipefail
INPUT=$(cat)
KEEP_WRITTEN_AT=$(python3 - <<'PY'
import time
print(time.time())
PY
)
SESSION_ID=$(echo "$INPUT" | jq -r '.session_id')
USER_SESSION="${KEEP_USER_SESSION:-${SESSION_ID}}"
STATE_DIR="${KEEP_HOME:-$HOME/.keep}"
ENRICHED=$(echo "$INPUT" | jq \
  --arg keep_written_at "$KEEP_WRITTEN_AT" \
  --arg keep_group_id "${KEEP_GROUP_ID:-}" \
  --arg keep_user_session "$USER_SESSION" \
  '. + {
    keep_written_at: $keep_written_at,
    keep_group_id: $keep_group_id,
    keep_user_session: $keep_user_session
  }')
printf '%s' "$ENRICHED" > "$STATE_DIR/stop-${USER_SESSION}"
EOF

chmod +x ~/.keep/on-stop.sh
```

## Quick Start

```bash
# Start daemon
keep self start

# Show or update keep-level defaults
keep self config
keep self config --terminal iterm2 --agent codex --workers-enabled true

# Create group — ID is auto-generated and printed, e.g. 'a3f2c1d9'
# New groups start in stopped state; configure first, then start
# Group snapshots terminal / default agent / workers_enabled at creation
keep group create --terminal iterm2 --agent codex
# → Group 'a3f2c1d9' 已创建。

# Set group prompt (inline text or file path)
keep group update a3f2c1d9 "Implement chat receipts"
keep group update a3f2c1d9 ~/path/to/group.md

# Create tasks and supervisor (allowed while stopped)
keep a3f2c1d9 task create "Backend read API"
keep a3f2c1d9 supervisor create --name my-supervisor

# Activate group — required before worker create / send / wake
keep group start a3f2c1d9

# Spawn worker
keep a3f2c1d9 worker create --name my-worker

# Single-worker group: worker_id can be omitted for send/read/wake
# send requires a file path; write your message file to messages/ first
echo "开始实现 Backend read API" > ~/.keep/groups/a3f2c1d9/messages/task-1.md
keep a3f2c1d9 supervisor send ~/.keep/groups/a3f2c1d9/messages/task-1.md
keep a3f2c1d9 supervisor read
keep a3f2c1d9 supervisor wake

# Check system and group state
keep self show
keep group show a3f2c1d9
keep group ls            # alias for group list

# Stop / reset
keep self stop
keep self reset
```

## Terminal backend

Each group maps to **one terminal container** (window / workspace / session, chosen per backend). The supervisor, reviewer, and all workers of the same group share that container, arranged by role — supervisor top-left, reviewer top-right, workers in the bottom region. Additional workers degrade into tabs or splits depending on what the backend supports.

Pick the backend per group with `keep group create --terminal <name>` (`cmux | iterm2 | tmux | kitty | terminal`); omit to use the config default.

Group-scoped execution mode is controlled separately:
- `keep self config --workers-enabled false` sets the keep-level default
- `keep group create --no-workers` or `keep group update <id> --workers-enabled false` overrides it per group
- `workers_enabled=true`: supervisor coordinates real workers
- `workers_enabled=false`: supervisor uses Agent tool subagents instead of workers

| Backend | Container | Layout |
|---------|-----------|--------|
| cmux | workspace | sup = top-left pane, reviewer = top-right pane, worker = bottom pane (extra workers become surface tabs inside the worker pane) |
| iTerm2 | window | 3 panes in 1 tab: sup \| reviewer on top, worker-1 on bottom; extra workers = new tabs |
| tmux | session | window 0 has `sup \| reviewer \| worker-1` panes; extra workers = new windows |
| kitty | OS window | one tab per role (supervisor / reviewer / worker-1); extra workers = hsplit inside the worker-1 tab |
| Terminal.app | window | one tab per role+instance (no split-pane API — pure tab degradation) |

## Multi-Group

```bash
keep group create   # → Group 'aa11bb22' 已创建。
keep group create   # → Group 'cc33dd44' 已创建。

keep aa11bb22 worker create --name worker-a
keep aa11bb22 supervisor create --name sup-a
keep aa11bb22 task create "Step 1"

keep cc33dd44 worker create --name worker-b
keep cc33dd44 supervisor create --name sup-b
keep cc33dd44 task create "Step 1"

keep group list
```

## Multi-Worker

A group can have multiple workers. In that case, `supervisor send/read/wake` must explicitly pass `worker_id`.

```bash
# assuming group id is 'a3f2c1d9'
keep a3f2c1d9 worker create --name worker-frontend
keep a3f2c1d9 worker create --name worker-backend

keep a3f2c1d9 supervisor send worker-frontend ~/.keep/groups/a3f2c1d9/messages/task-ui.md
keep a3f2c1d9 supervisor send worker-backend ~/.keep/groups/a3f2c1d9/messages/task-api.md
keep a3f2c1d9 supervisor read worker-frontend
keep a3f2c1d9 supervisor wake worker-backend
```

## Content Resolution

`group update <group_id> <prompt>` accepts file paths or inline text:

| Input | Detection | Behavior |
|-------|-----------|----------|
| `~/path/to/file.md` | File exists on disk | Read file content at display/use time |
| `"Implement feature X"` | Not a file path | Use text as-is |

## CLI Reference

### Self
| Command | Description |
|---------|-------------|
| `keep self start [-f]` | Start daemon (`-f`: foreground) |
| `keep self stop` | Stop daemon and lock state |
| `keep self show` | Show system status and group summary |
| `keep self reset` | Stop daemon and clear all state |

### Group
| Command | Description |
|---------|-------------|
| `keep self config [--terminal <backend>] [--agent <claude-code\|codex>] [--workers-enabled <true\|false>]` | Show or update keep-level defaults |
| `keep group create [--terminal <backend>] [--agent <claude-code\|codex>] [--workers-enabled <true\|false> \| --no-workers]` | Create a group (ID auto-generated, printed on creation). Terminal/agent/workers mode snapshot from explicit flags or keep defaults |
| `keep group update <group_id> [<prompt>] [--terminal <backend>] [--agent <claude-code\|codex>] [--workers-enabled <true\|false> \| --no-workers]` | Update group prompt or group-level overrides |
| `keep group remove <group_id>` | Delete a group |
| `keep group list` / `keep group ls` | List groups |
| `keep group show <group_id>` | Show group details |
| `keep group start <group_id>` | Mark group active (prints supervisor/worker/task readiness check) |
| `keep group stop <group_id>` | Try to stop a group; if direct stop is not allowed, keep auto-submits a `group_stop` approval and the final outcome arrives via `review_result` |

### Group-scoped Task
| Command | Description |
|---------|-------------|
| `keep <group_id> task create <subject>` | Create task |
| `keep <group_id> task update --tasks CSV [--status/--owner/--description/--blocks/--blocked-by] [--rationale FILE]` | Update task batch or single task |
| `keep <group_id> task remove <task_id>` | Remove task |
| `keep <group_id> task list` | List tasks |
| `keep <group_id> task show <task_id>` | Show task |

### Group-scoped Worker
| Command | Description |
|---------|-------------|
| `keep <group_id> worker create [--agent <claude-code|codex>] [--name <name>] [--path <path>]` | Spawn new worker agent session, inject contract, wait for ready reply. Omit `--agent` to use the group default |
| `keep <group_id> worker create --session <session_id>` | Re-attach an existing session as worker (skips spawn) |
| `keep <group_id> worker update <worker_id> [--name <name>] [--path <path>]` | Update worker metadata |
| `keep <group_id> worker remove <worker_id>` | Remove worker |
| `keep <group_id> worker list` | List workers |
| `keep <group_id> worker show <worker_id>` | Show worker details |

### Group-scoped Supervisor
| Command | Description |
|---------|-------------|
| `keep <group_id> supervisor create [--agent <claude-code|codex>] [--name <name>] [--path <path>]` | Create/replace supervisor agent session + contract and wait for ready reply. Omit `--agent` to use the group default |
| `keep <group_id> supervisor update <supervisor_id> [--name <name>] [--path <path>]` | Update supervisor metadata |
| `keep <group_id> supervisor remove <supervisor_id>` | Remove supervisor |
| `keep <group_id> supervisor list` | Show current supervisor |
| `keep <group_id> supervisor show <supervisor_id>` | Show supervisor details |
| `keep <group_id> supervisor send [worker_id] <file_path>` | Send message file to worker (`<file_path>` must exist; files outside `messages/` are auto-copied with a warning) |
| `keep <group_id> supervisor read [worker_id]` | Read worker latest message |
| `keep <group_id> supervisor wake [worker_id]` | Send Enter key to worker |

## How It Works

1. **Worker creation**: `keep <group_id> worker create` generates a UUID user id, starts the selected agent runtime with the bootstrap prompt and contract, waits until the session emits its ready reply, then records runtime cache and contract metadata. Use `--session <id>` to re-attach an existing session without spawning a new one.
2. **Idle detection**: CC Stop hook writes a signal file when Worker finishes responding. Daemon polls for this file every 2s.
3. **Stop relay**: Daemon consumes the stop signal, always saves the Worker's full reply to `~/.keep/groups/<name>/messages/` (as `<seq>-worker-<session>-stop.md`), then injects a `<keep event="stop" group="..." worker="..." output_file="...">` notification into the Supervisor session. `output_file` is included when the reply exceeds 200 characters; the path can be forwarded directly to downstream workers — no transcription needed.
4. **Stall detection**: Worker idle >3min triggers a stall notification with progressive backoff (180s → 240s → 300s). Multiple workers stalling simultaneously produce a single aggregated `[stall ×N]` message instead of N separate messages.
5. **Stall hint**: At `stall_count=2`, the notification body includes a hint suggesting the Supervisor can remove the worker and re-attach it later via `worker create --session`. At the cap (`stall_max=10`), automatic reminders stop.
6. **Runtime state persistence**: Stall counts, notification timestamps, and closed-worker state survive daemon restarts (`~/.keep/daemon-runtime.json`). Worker bootstrap state is persisted per-worker so the first real task stop is never mistakenly suppressed after a restart.
7. **Send is fire-and-forget**: `keep <group_id> supervisor send ...` delivers text via the active backend's automation API (cmux RPC / iTerm2 Python API / tmux / kitty / AppleScript). Text is split-sent with CR + 2s gap to escape the CC TUI's bracketed-paste envelope. Success = text reached the terminal; CC queues it if Worker is busy.
8. **Supervisor creation**: each group stores one supervisor user via `keep <group_id> supervisor create`. Daemon resolves `session → PID → backend-specific surface ref` dynamically on each notification (e.g. `CMUX_SURFACE_ID` for cmux, iTerm2 session id, tmux pane id, kitty window id, Terminal.app tab id).
9. **Dormant until supervisor exists**: a group without a supervisor user is skipped by daemon event routing.
10. **Active group required**: `supervisor send`, `supervisor wake`, and `worker create` (both spawn and `--session`) are blocked when the group is `stopped`. Run `keep group start <id>` first.
11. **Multi-group routing**: daemon iterates active groups and routes events per group-local supervisor relationship.
12. **Cache refresh**: Worker cache (PID, surface_id, JSONL path) auto-refreshes on `supervisor send/read/wake`.

## State Files

```
~/.keep/
  global.json                          # daemon_pid, stopped
  daemon-runtime.json                  # persisted stall counts, notify timestamps, closed set
  daemon.log                           # daemon log
  stop-<session_id>                    # signal file (CC Stop hook writes, daemon consumes)
  on-stop.sh                           # CC Stop hook script
  groups/<name>.json                   # per-group: users, relationships, group_prompt
  groups/<name>/transcript.jsonl       # worker→supervisor reply transcript
  groups/<name>/messages/              # unified inbox: all group communications
    index.json                         # sequential index of all events (worker stop, daemon events, supervisor sends)
    <seq>-worker-<session>-stop.md     # worker stop output (always written, full content)
    <seq>-daemon-<type>.md             # daemon events (align, stall)
    <arbitrary>.md                     # supervisor message files
```

User roles: `worker` (executor), `supervisor` (project manager). Group has 0 or 1 supervisor; claim replaces.

## License

MIT
