from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from keep._state.users import (
    User,
    user_jsonl_path,
    user_ready,
    user_target_id,
    user_thread_id,
)
from keep.agent import agent_last_message


def test_user_model_resolves_role() -> None:
    assert User.model_validate({"session": "s1", "role": "supervisor"}).role == "supervisor"
    assert User.model_validate({"session": "w1", "role": "worker"}).role == "worker"
    assert User.model_validate({"session": "r1", "role": "reviewer"}).role == "reviewer"


def test_user_kind_defaults_to_agent() -> None:
    user = User.model_validate({"session": "s1", "role": "supervisor"})
    assert user.kind == "agent"


def test_user_accessors_read_cache_fields() -> None:
    user = {
        "session": "r1",
        "role": "reviewer",
        "kind": "agent",
        "cache": {
            "target_id": "surface-1",
            "jsonl_path": "/tmp/demo.jsonl",
            "thread_id": "thread-1",
        },
    }

    assert user_target_id(user) == "surface-1"
    assert user_jsonl_path(user) == Path("/tmp/demo.jsonl")
    assert user_thread_id(user) == "thread-1"
    assert user_ready(user) is True


def test_agent_last_message_uses_codex_agent(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, str | None, Path | None]] = []

    class FakeCodexAgent:
        def last_message(self, session: str, *, session_id: str | None = None, jsonl_path: Path | None = None):
            calls.append((session, session_id, jsonl_path))
            return SimpleNamespace(text="codex says hi")

    monkeypatch.setattr("keep.agents.codex.CodexAgent", FakeCodexAgent)

    message = agent_last_message(
        {
            "session": "r1",
            "role": "reviewer",
            "kind": "agent",
            "agent_type": "codex",
            "cache": {"thread_id": "thread-1", "jsonl_path": "/tmp/demo.jsonl"},
        }
    )

    assert message is not None
    assert message.text == "codex says hi"
    assert calls == [("r1", "thread-1", Path("/tmp/demo.jsonl"))]


def test_agent_last_message_uses_cc_agent(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, Path | None]] = []

    class FakeCCAgent:
        def last_message(self, session: str, *, jsonl_path: Path | None = None):
            calls.append((session, jsonl_path))
            return SimpleNamespace(text="cc says hi")

    monkeypatch.setattr("keep.agents.cc.CCAgent", FakeCCAgent)

    message = agent_last_message(
        {
            "session": "w1",
            "role": "worker",
            "kind": "agent",
            "agent_type": "claude-code",
            "cache": {"jsonl_path": "/tmp/worker.jsonl"},
        }
    )

    assert message is not None
    assert message.text == "cc says hi"
    assert calls == [("w1", Path("/tmp/worker.jsonl"))]
