from __future__ import annotations

import os
from pathlib import Path

import pytest
from typer.testing import CliRunner

from keep import state
from keep._cli.contracts import build_reviewer_layer1, build_supervisor_contract_v1
from keep.cli import app


runner = CliRunner()


def _activate_group(group_id: str) -> None:
    global_state = state.new_global()
    global_state["daemon_pid"] = os.getpid()
    state.save_global(global_state)
    group = state.load_group(group_id)
    assert group is not None
    group["status"] = "active"
    state.save_group(group_id, group)
    supervisor_session = f"sup-{group_id}"
    state.add_supervisor(group_id, supervisor_session, name="sup")
    os.environ["KEEP_GROUP_ID"] = group_id
    os.environ["KEEP_USER_SESSION"] = supervisor_session


def _as_user(group_id: str, session: str) -> None:
    os.environ["KEEP_GROUP_ID"] = group_id
    os.environ["KEEP_USER_SESSION"] = session


def test_task_update_pending_with_rationale_creates_review_batch(tmp_path: Path) -> None:
    group_id = "batch-review-group-1"
    state.create_group(group_id)
    _activate_group(group_id)
    state.add_user(group_id, "reviewer-task-pending", role="reviewer", triggers=["task_proposed_review"])
    state.create_task(group_id, subject="Task 1")
    state.create_task(group_id, subject="Task 2")

    rationale_file = tmp_path / "pending.md"
    rationale_file.write_text("design proof", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1,2",
            "--status",
            "pending",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 0
    assert "你无权直接将 #1, #2 更新为 pending" in result.stdout
    assert "batch re1" in result.stdout
    task1 = state.get_task(group_id, "1")
    task2 = state.get_task(group_id, "2")
    assert task1 is not None and task2 is not None
    assert task1["status"] == "proposed"
    assert task2["status"] == "proposed"
    assert task1["review_event_id"] == "re1"
    assert task2["review_event_id"] == "re1"
    event = state.get_review_event(group_id, "re1")
    assert event["type"] == "task_proposed_review"
    assert event["batch_id"] == "re1"
    assert event["task_ids"] == ["1", "2"]
    assert event["user_resource_states"] == {}


def test_task_update_completed_with_rationale_creates_review_batch(tmp_path: Path) -> None:
    group_id = "batch-review-group-1b"
    state.create_group(group_id)
    _activate_group(group_id)
    state.add_user(group_id, "reviewer-task-completed", role="reviewer", triggers=["task_submitted_review"])
    state.create_task(group_id, subject="Task 1")
    state.create_task(group_id, subject="Task 2")
    state.update_task(group_id, "1", {"status": "in_progress"})
    state.update_task(group_id, "2", {"status": "in_progress"})

    rationale_file = tmp_path / "completed.md"
    rationale_file.write_text("done proof", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1,2",
            "--status",
            "completed",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 0
    assert "你无权直接将 #1, #2 更新为 completed" in result.stdout
    assert "batch re1" in result.stdout
    task1 = state.get_task(group_id, "1")
    task2 = state.get_task(group_id, "2")
    assert task1 is not None and task2 is not None
    assert task1["status"] == "in_progress"
    assert task2["status"] == "in_progress"
    assert task1["review_event_id"] == "re1"
    assert task2["review_event_id"] == "re1"
    event = state.get_review_event(group_id, "re1")
    assert event["type"] == "task_submitted_review"
    assert event["batch_id"] == "re1"
    assert event["task_ids"] == ["1", "2"]
    assert event["user_resource_states"] == {}


def test_task_review_request_auto_starts_daemon_when_keep_not_stopped(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    group_id = "batch-review-group-autostart"
    state.create_group(group_id)
    group = state.load_group(group_id)
    assert group is not None
    group["status"] = "active"
    state.save_group(group_id, group)
    state.save_global({"daemon_pid": None, "stopped": False})
    supervisor_session = f"sup-{group_id}"
    state.add_supervisor(group_id, supervisor_session, name="sup")
    _as_user(group_id, supervisor_session)
    state.add_user(group_id, "reviewer-task-pending-autostart", role="reviewer", triggers=["task_proposed_review"])
    state.create_task(group_id, subject="Task 1")

    states = iter([False, True])
    monkeypatch.setattr("keep._cli.helpers.is_daemon_running", lambda global_state: next(states))
    launched: list[bool] = []

    def fake_launch(global_state: dict, foreground: bool, *, quiet: bool = False) -> None:
        launched.append(True)
        global_state["daemon_pid"] = 12345
        global_state["stopped"] = False
        state.save_global(global_state)

    monkeypatch.setattr("keep._cli.spawn.launch_daemon", fake_launch)

    rationale_file = tmp_path / "pending.md"
    rationale_file.write_text("design proof", encoding="utf-8")
    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "pending",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 0
    assert launched == [True]
    assert state.get_review_event(group_id, "re1")["type"] == "task_proposed_review"


def test_task_update_rejects_rationale_for_non_review_status(tmp_path: Path) -> None:
    group_id = "batch-review-group-2"
    state.create_group(group_id)
    _activate_group(group_id)
    state.create_task(group_id, subject="Task 1")

    rationale_file = tmp_path / "note.md"
    rationale_file.write_text("note", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "in_progress",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 2
    assert "--rationale is only allowed with --status pending|completed" in result.stderr


def test_reviewer_can_submit_task_proposed_decision_via_task_update(tmp_path: Path) -> None:
    group_id = "batch-review-group-reviewer-1"
    state.create_group(group_id)
    _activate_group(group_id)
    reviewer_id = "reviewer-task-pending-approve"
    state.add_user(group_id, reviewer_id, role="reviewer", triggers=["task_proposed_review"])
    state.create_task(group_id, subject="Task 1")
    state.create_task(group_id, subject="Task 2")
    state.add_review_event(
        group_id,
        {
            "type": "task_proposed_review",
            "task_ids": ["1", "2"],
            "user_resource_states": {},
        },
    )
    state.update_tasks(group_id, ["1", "2"], {"review_event_id": "re1"})
    _as_user(group_id, reviewer_id)

    rationale_file = tmp_path / "reviewer-pending.md"
    rationale_file.write_text("looks good", encoding="utf-8")
    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1,2",
            "--status",
            "pending",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 0
    assert "审批已记录" in result.stdout
    event = state.get_review_event(group_id, "re1")
    assert event["user_resource_states"] == {reviewer_id: {"1": "pending", "2": "pending"}}
    assert reviewer_id in event["user_rationales"]


def test_reviewer_can_submit_task_rejection_via_task_update(tmp_path: Path) -> None:
    group_id = "batch-review-group-reviewer-2"
    state.create_group(group_id)
    _activate_group(group_id)
    reviewer_id = "reviewer-task-completed-reject"
    state.add_user(group_id, reviewer_id, role="reviewer", triggers=["task_submitted_review"])
    state.create_task(group_id, subject="Task 1")
    state.update_task(group_id, "1", {"status": "in_progress", "review_event_id": "re1"})
    state.add_review_event(
        group_id,
        {
            "type": "task_submitted_review",
            "task_ids": ["1"],
            "user_resource_states": {},
        },
    )
    _as_user(group_id, reviewer_id)

    rationale_file = tmp_path / "reviewer-reject.md"
    rationale_file.write_text("needs more work", encoding="utf-8")
    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "in_progress",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 0
    assert "审批已记录" in result.stdout
    event = state.get_review_event(group_id, "re1")
    assert event["user_resource_states"] == {reviewer_id: {"1": "in_progress"}}


def test_reviewer_can_submit_task_decision_without_rationale_file(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    group_id = "batch-review-group-reviewer-lastmsg"
    state.create_group(group_id)
    _activate_group(group_id)
    reviewer_id = "reviewer-task-lastmsg"
    state.add_user(group_id, reviewer_id, role="reviewer", triggers=["task_proposed_review"])
    state.create_task(group_id, subject="Task 1")
    state.add_review_event(
        group_id,
        {
            "type": "task_proposed_review",
            "task_ids": ["1"],
            "user_resource_states": {},
        },
    )
    state.update_task(group_id, "1", {"review_event_id": "re1"})
    _as_user(group_id, reviewer_id)
    monkeypatch.setattr(
        "keep._cli.dispatch_task.persist_user_last_message",
        lambda group_id, user, event_type="user_note": "/tmp/reviewer-last-message.txt",
    )

    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "pending",
        ],
    )

    assert result.exit_code == 0
    event = state.get_review_event(group_id, "re1")
    assert event["user_resource_states"] == {reviewer_id: {"1": "pending"}}
    assert event["user_rationales"][reviewer_id] == "/tmp/reviewer-last-message.txt"


def test_reviewer_can_submit_partial_batch_decisions_across_multiple_task_updates(tmp_path: Path) -> None:
    group_id = "batch-review-group-reviewer-3"
    state.create_group(group_id)
    _activate_group(group_id)
    reviewer_id = "reviewer-task-partial-approve"
    state.add_user(group_id, reviewer_id, role="reviewer", triggers=["task_proposed_review"])
    state.create_task(group_id, subject="Task 1")
    state.create_task(group_id, subject="Task 2")
    state.add_review_event(
        group_id,
        {
            "type": "task_proposed_review",
            "task_ids": ["1", "2"],
            "user_resource_states": {},
        },
    )
    state.update_tasks(group_id, ["1", "2"], {"review_event_id": "re1"})
    _as_user(group_id, reviewer_id)

    rationale1 = tmp_path / "partial-1.md"
    rationale1.write_text("task1 ok", encoding="utf-8")
    result1 = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "pending",
            "--rationale",
            str(rationale1),
        ],
    )
    assert result1.exit_code == 0

    rationale2 = tmp_path / "partial-2.md"
    rationale2.write_text("task2 reject", encoding="utf-8")
    result2 = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "2",
            "--status",
            "proposed",
            "--rationale",
            str(rationale2),
        ],
    )
    assert result2.exit_code == 0

    event = state.get_review_event(group_id, "re1")
    assert event["user_resource_states"] == {
        reviewer_id: {"1": "pending", "2": "proposed"}
    }


def test_task_update_rejects_legacy_submitted_status(tmp_path: Path) -> None:
    group_id = "batch-review-group-2b"
    state.create_group(group_id)
    _activate_group(group_id)
    state.create_task(group_id, subject="Task 1")
    state.update_task(group_id, "1", {"status": "in_progress"})

    rationale_file = tmp_path / "legacy.md"
    rationale_file.write_text("legacy", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "submitted",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 2
    assert "Invalid --status 'submitted'" in result.stderr


def test_task_update_completed_review_requires_in_progress_source(tmp_path: Path) -> None:
    group_id = "batch-review-group-2c"
    state.create_group(group_id)
    _activate_group(group_id)
    state.add_user(group_id, "reviewer-source-check", role="reviewer", triggers=["task_submitted_review"])
    state.create_task(group_id, subject="Task 1")

    rationale_file = tmp_path / "completed.md"
    rationale_file.write_text("done", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "completed",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 1
    assert "requires tasks currently in in_progress" in result.stderr


def test_task_review_request_rejected_when_keep_is_stopped(tmp_path: Path) -> None:
    group_id = "batch-review-group-2d"
    state.create_group(group_id)
    _activate_group(group_id)
    state.create_task(group_id, subject="Task 1")
    global_state = state.load_global()
    assert global_state is not None
    global_state["daemon_pid"] = None
    global_state["stopped"] = True
    state.save_global(global_state)

    rationale_file = tmp_path / "pending.md"
    rationale_file.write_text("design", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "pending",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 1
    assert "Keep 已停止" in result.stderr
    assert state.load_group(group_id)["review_events"] == []


def test_task_review_request_rejected_when_no_reviewer_covers_event(tmp_path: Path) -> None:
    group_id = "batch-review-group-2e"
    state.create_group(group_id)
    _activate_group(group_id)
    state.create_task(group_id, subject="Task 1")
    state.add_user(
        group_id,
        "reviewer-group-stop",
        role="reviewer",
        name="stop-only",
        triggers=["group_stop"],
    )

    rationale_file = tmp_path / "pending.md"
    rationale_file.write_text("design", encoding="utf-8")

    result = runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "pending",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 1
    assert "没有 reviewer 覆盖 task_proposed_review" in result.stderr
    assert state.load_group(group_id)["review_events"] == []


def test_reviewer_submit_cli_is_deprecated(tmp_path: Path) -> None:
    group_id = "batch-review-group-3"
    state.create_group(group_id)
    _activate_group(group_id)
    reviewer_id = state.add_user(group_id, "sess-1", role="reviewer", name="rev")["session"]
    state.create_task(group_id, subject="Task 1")
    state.create_task(group_id, subject="Task 2")
    state.update_task(group_id, "1", {"status": "in_progress"})
    state.update_task(group_id, "2", {"status": "in_progress"})

    rationale_file = tmp_path / "completed.md"
    rationale_file.write_text("ship it", encoding="utf-8")
    runner.invoke(
        app,
        [
            group_id,
            "task",
            "update",
            "--tasks",
            "1,2",
            "--status",
            "completed",
            "--rationale",
            str(rationale_file),
        ],
        catch_exceptions=False,
    )

    result = runner.invoke(
        app,
        [
            group_id,
            "reviewer",
            "re1",
            "submit",
            "--round",
            "1",
            "--reviewer-id",
            reviewer_id,
        ],
    )

    assert result.exit_code == 1
    assert "reviewer verdict CLI 已废弃" in result.stderr
    event = state.get_review_event(group_id, "re1")
    assert event["user_resource_states"] == {}


def test_prompts_use_task_update_and_review_result() -> None:
    supervisor = build_supervisor_contract_v1(workers_enabled=True)
    reviewer = build_reviewer_layer1("group-123", "影")

    assert "task review proposed" not in supervisor
    assert "task review submitted" not in supervisor
    assert "task update --tasks <ids> --status pending --rationale <file>" in supervisor
    assert "task update --tasks <ids> --status completed --rationale <file>" in supervisor
    assert "review_result" in supervisor
    assert "系统会自动上报给 reviewer 审批" in supervisor

    assert "不要调用 keep reviewer verdict CLI" in reviewer
    assert "task update --tasks <ids> --status pending|proposed" in reviewer
    assert "keep group stop group-123 --status stopped|active" in reviewer
