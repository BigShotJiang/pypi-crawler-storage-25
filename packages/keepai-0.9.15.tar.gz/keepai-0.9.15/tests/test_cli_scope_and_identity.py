import json
import os
import time
from pathlib import Path
from types import SimpleNamespace

import pytest
from typer.testing import CliRunner

from keep import state
from keep._cli.spawn import (
    _check_codex_stop_hook,
    spawn_claude_session,
    spawn_codex_session,
    spawn_and_wait_for_ready as _spawn_and_wait_for_ready,
    wait_for_worker_ready as _wait_for_worker_ready,
)
from keep._cli.identity_env import build_user_env, shell_env_prefix
from keep.cli import app
from keep.workflow_policy import ActorRole, group_status_mutation_allowed


runner = CliRunner()


def _create_active_group(name: str) -> None:
    """Create a group and mark it active — required for send/kick/worker create tests."""
    global_state = state.load_global() or state.new_global()
    global_state["daemon_pid"] = os.getpid()
    state.save_global(global_state)
    m = state.create_group(name)
    m["status"] = "active"
    state.save_group(name, m)
    state.add_supervisor(name, S1, name="sup")
    os.environ["KEEP_GROUP_ID"] = name
    os.environ["KEEP_USER_SESSION"] = S1


W1 = "11111111-1111-4111-8111-111111111111"
W2 = "11111111-1111-4111-8111-222222222222"
WMISS = "11111111-1111-4111-8111-333333333333"
S1 = "22222222-2222-4222-8222-222222222222"
SMISS = "22222222-2222-4222-8222-333333333333"


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    (state_dir / "missions").mkdir(parents=True)
    monkeypatch.setenv("KEEP_HOME", str(state_dir))
    state.save_global(state.new_global())
    return state_dir


def test_root_help_does_not_advertise_group_flag_scope_fallback() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "MATION_MISSION" not in result.stdout
    assert "-m" not in result.stdout
    assert "--group" not in result.stdout


def test_build_user_env_passes_absolute_pythonpath(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PYTHONPATH", ".")
    env = build_user_env(
        group_id="group-123",
        user_session=W1,
    )
    assert env["KEEP_GROUP_ID"] == "group-123"
    assert env["KEEP_USER_SESSION"] == W1
    assert env["PYTHONPATH"].startswith(str(Path.cwd()))


def test_shell_env_prefix_exports_keep_env_persistently() -> None:
    prefix = shell_env_prefix(
        {
            "KEEP_GROUP_ID": "group-123",
            "KEEP_USER_SESSION": W1,
        }
    )
    assert prefix.startswith("export KEEP_GROUP_ID=")
    assert "; export KEEP_USER_SESSION=" in prefix


def test_group_scoped_help_uses_path_not_option_scope() -> None:
    result = runner.invoke(app, ["group-123", "task", "--help"])
    assert result.exit_code == 0
    assert "create" in result.stdout
    assert "update" in result.stdout
    assert "remove" in result.stdout
    assert "list" in result.stdout
    assert "show" in result.stdout
    assert "-m" not in result.stdout
    assert "--group" not in result.stdout


def test_supervisor_create_help_exposes_name_and_path_only() -> None:
    result = runner.invoke(app, ["group-123", "supervisor", "create", "--help"])
    assert result.exit_code == 0
    assert "--name" in result.stdout
    assert "--path" in result.stdout
    assert "--session" not in result.stdout


def test_worker_create_help_exposes_name_and_path_only() -> None:
    result = runner.invoke(app, ["group-123", "worker", "create", "--help"])
    assert result.exit_code == 0
    assert "--name" in result.stdout
    assert "--path" in result.stdout
    assert "--session" not in result.stdout


def test_worker_create_fails_fast_when_path_missing(isolated_state: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _create_active_group("group-123")
    monkeypatch.delenv("KEEP_GROUP_ID", raising=False)
    monkeypatch.delenv("KEEP_USER_SESSION", raising=False)

    result = runner.invoke(
        app,
        ["group-123", "worker", "create", "--path", "/tmp/keep-nonexistent-worker-path-xyz"],
    )

    assert result.exit_code == 1
    assert "path 不存在或不是目录" in result.stderr


def test_supervisor_create_fails_fast_when_path_missing(isolated_state: Path) -> None:
    state.create_group("group-123")

    result = runner.invoke(
        app,
        ["group-123", "supervisor", "create", "--path", "/tmp/keep-nonexistent-supervisor-path-xyz"],
    )

    assert result.exit_code == 1
    assert "path 不存在或不是目录" in result.stderr


def test_group_scoped_help_discoverable_without_group_id() -> None:
    task_help = runner.invoke(app, ["task", "--help"])
    assert task_help.exit_code == 0
    assert "Usage: keep <group_id> task" in task_help.stdout
    assert "create" in task_help.stdout

    supervisor_help = runner.invoke(app, ["supervisor", "--help"])
    assert supervisor_help.exit_code == 0
    assert "Usage: keep <group_id> supervisor" in supervisor_help.stdout
    assert "send" in supervisor_help.stdout

    worker_help = runner.invoke(app, ["worker", "--help"])
    assert worker_help.exit_code == 0
    assert "Usage: keep <group_id> worker" in worker_help.stdout
    assert "list" in worker_help.stdout


def test_create_help_discoverable_without_group_id() -> None:
    supervisor_create_help = runner.invoke(app, ["supervisor", "create", "--help"])
    assert supervisor_create_help.exit_code == 0
    assert "Usage: keep <group_id> supervisor create" in supervisor_create_help.stdout
    assert "--name" in supervisor_create_help.stdout
    assert "--path" in supervisor_create_help.stdout

    worker_create_help = runner.invoke(app, ["worker", "create", "--help"])
    assert worker_create_help.exit_code == 0
    assert "Usage: keep <group_id> worker create" in worker_create_help.stdout
    assert "--name" in worker_create_help.stdout
    assert "--path" in worker_create_help.stdout


def test_group_create_auto_generates_id(isolated_state: Path) -> None:
    result = runner.invoke(app, ["group", "create"])
    assert result.exit_code == 0
    # Output: "Group '<id>' 已创建。"
    import re
    match = re.search(r"Group '(\w+)' 已创建", result.stdout)
    assert match is not None, f"Unexpected output: {result.stdout}"
    group_id = match.group(1)
    group = state.load_group(group_id)
    assert group is not None
    assert group["name"] == group_id
    assert group["group_prompt"] is None



def test_group_scoped_task_commands_operate_on_path_scope(isolated_state: Path) -> None:
    _create_active_group("group-123")

    create_result = runner.invoke(app, ["group-123", "task", "create", "first-task"])
    assert create_result.exit_code == 0
    assert "Task '1'" in create_result.stdout

    list_result = runner.invoke(app, ["group-123", "task", "list"])
    assert list_result.exit_code == 0
    assert "first-task" in list_result.stdout

    show_result = runner.invoke(app, ["group-123", "task", "show", "--tasks", "1"])
    assert show_result.exit_code == 0
    assert "first-task" in show_result.stdout


def test_group_scoped_task_update_and_remove(isolated_state: Path) -> None:
    _create_active_group("group-123")
    runner.invoke(app, ["group-123", "task", "create", "first-task"])

    update_result = runner.invoke(
        app,
        [
            "group-123",
            "task",
            "update",
            "--tasks",
            "1",
            "--status",
            "in_progress",
            "--owner",
            W1,
            "--description",
            "desc",
        ],
    )
    assert update_result.exit_code == 0

    task = state.get_task("group-123", "1")
    assert task is not None
    assert task["status"] == "in_progress"
    assert task["owner"] == W1
    assert task["description"] == "desc"

    remove_result = runner.invoke(app, ["group-123", "task", "remove", "--tasks", "1"])
    assert remove_result.exit_code == 0

    show_result = runner.invoke(app, ["group-123", "task", "show", "--tasks", "1"])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    list_result = runner.invoke(app, ["group-123", "task", "list"])
    assert list_result.exit_code == 0
    assert "first-task" not in list_result.stdout


def test_group_scoped_task_update_requires_id_and_rejects_unknown_field(isolated_state: Path) -> None:
    state.create_group("group-123")
    _m = state.load_group('group-123'); _m['status'] = 'active'; state.save_group('group-123', _m)
    runner.invoke(app, ["group-123", "task", "create", "first-task"])

    missing_id_result = runner.invoke(app, ["group-123", "task", "update"])
    assert missing_id_result.exit_code == 2
    assert "--tasks is required" in missing_id_result.stderr

    unknown_field_result = runner.invoke(
        app,
        ["group-123", "task", "update", "--tasks", "1", "--invalid", "x"],
    )
    assert unknown_field_result.exit_code == 2
    assert "No such option '--invalid'" in unknown_field_result.stderr


def test_worker_create_uses_uuid_prompt_contract_and_persists_contract_metadata(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    monkeypatch.delenv("KEEP_GROUP_ID", raising=False)
    monkeypatch.delenv("KEEP_USER_SESSION", raising=False)

    launches: list[tuple[str, str | None, str, str, dict[str, str] | None]] = []

    class FakeInfo:
        running = True
        pid = 123
        target_id = "surface-1"
        jsonl_path = "/tmp/fake.jsonl"
        jsonl_search = None

    def fake_spawn(session, path, *, bootstrap_prompt, append_system_prompt, terminal_type, role, group_id, env=None):
        launches.append((session, path, bootstrap_prompt, append_system_prompt, env))

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", fake_spawn)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr("keep._cli.spawn.wait_for_worker_ready", lambda *args, **kwargs: FakeInfo())
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": info.jsonl_path},
    )

    work_path = isolated_state / "work"
    work_path.mkdir(parents=True)

    result = runner.invoke(
        app,
        ["group-123", "worker", "create", "--name", "worker-a", "--path", str(work_path)],
    )
    assert result.exit_code == 0

    group = state.load_group("group-123")
    worker = state.find_worker(group, "11111111-1111-4111-8111-111111111111")
    assert worker is not None
    assert worker["name"] == "worker-a"
    assert worker["path"] == str(work_path)
    assert worker["contract"]["version"] == "v1"
    assert worker["contract"]["kind"] == "worker"
    assert worker["contract"]["applied_via"] == "claude-create"
    assert "session id: 11111111-1111-4111-8111-111111111111" in worker["contract"]["bootstrap_prompt"]
    assert "User id" not in worker["contract"]["bootstrap_prompt"]
    assert str(work_path) not in worker["contract"]["bootstrap_prompt"]
    assert launches[0][:4] == (
        "11111111-1111-4111-8111-111111111111",
        str(work_path),
        worker["contract"]["bootstrap_prompt"],
        worker["contract"]["append_system_prompt"],
    )
    assert launches[0][4] is not None
    assert launches[0][4]["KEEP_GROUP_ID"] == "group-123"
    assert launches[0][4]["KEEP_USER_SESSION"] == "11111111-1111-4111-8111-111111111111"


def test_supervisor_create_uses_uuid_prompt_contract_and_persists_contract_metadata(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")

    launches: list[tuple[str, str | None, str, str, dict[str, str] | None]] = []

    class FakeInfo:
        running = True
        pid = 456
        target_id = "surface-2"
        jsonl_path = "/tmp/sup.jsonl"
        jsonl_search = None

    def fake_spawn(session, path, *, bootstrap_prompt, append_system_prompt, terminal_type, role, group_id, env=None):
        launches.append((session, path, bootstrap_prompt, append_system_prompt, env))

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", fake_spawn)
    monkeypatch.setattr("keep._cli.dispatch_supervisor.generate_session_id", lambda: "22222222-2222-4222-8222-222222222222")
    monkeypatch.setattr("keep._cli.spawn.wait_for_worker_ready", lambda *args, **kwargs: FakeInfo())
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": info.jsonl_path},
    )

    sup_path = isolated_state / "sup"
    sup_path.mkdir(parents=True)

    result = runner.invoke(
        app,
        ["group-123", "supervisor", "create", "--name", "sup-a", "--path", str(sup_path)],
    )
    assert result.exit_code == 0

    group = state.load_group("group-123")
    supervisor = state.find_supervisor(group)
    assert supervisor is not None
    assert supervisor["session"] == "22222222-2222-4222-8222-222222222222"
    assert supervisor["name"] == "sup-a"
    assert supervisor["path"] == str(sup_path)
    assert supervisor["contract"]["version"] == "v1"
    assert supervisor["contract"]["kind"] == "supervisor"
    assert supervisor["contract"]["applied_via"] == "claude-create"
    assert "session_id: 22222222-2222-4222-8222-222222222222" in supervisor["contract"]["bootstrap_prompt"]
    assert "User id" not in supervisor["contract"]["bootstrap_prompt"]
    assert str(sup_path) not in supervisor["contract"]["bootstrap_prompt"]
    assert launches[0][:4] == (
        "22222222-2222-4222-8222-222222222222",
        str(sup_path),
        supervisor["contract"]["bootstrap_prompt"],
        supervisor["contract"]["append_system_prompt"],
    )
    assert launches[0][4] is not None
    assert launches[0][4]["KEEP_GROUP_ID"] == "group-123"
    assert launches[0][4]["KEEP_USER_SESSION"] == "22222222-2222-4222-8222-222222222222"


def test_worker_create_supports_codex_agent_and_persists_metadata(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    monkeypatch.delenv("KEEP_GROUP_ID", raising=False)
    monkeypatch.delenv("KEEP_USER_SESSION", raising=False)

    launches: list[tuple[str, str | None, str, str, dict[str, str] | None]] = []

    class FakeInfo:
        running = True
        pid = 123
        target_id = "surface-codex-1"
        jsonl_path = "/tmp/codex-transcript.jsonl"
        jsonl_search = None
        thread_id = "codex-thread-1"

    def fake_spawn(session, path, *, bootstrap_prompt, append_system_prompt, terminal_type, role, group_id, env=None):
        launches.append((session, path, bootstrap_prompt, append_system_prompt, env))

    monkeypatch.setattr("keep._cli.spawn.spawn_codex_session", fake_spawn)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: W1)
    monkeypatch.setattr("keep._cli.spawn.wait_for_worker_ready", lambda *args, **kwargs: FakeInfo())
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {
            "pid": info.pid,
            "target_id": info.target_id,
            "jsonl_path": info.jsonl_path,
            "thread_id": info.thread_id,
        },
    )

    work_path = isolated_state / "codex-work"
    work_path.mkdir(parents=True)

    result = runner.invoke(
        app,
        ["group-123", "worker", "create", "--agent", "codex", "--name", "worker-codex", "--path", str(work_path)],
    )
    assert result.exit_code == 0

    group = state.load_group("group-123")
    worker = state.find_worker(group, W1)
    assert worker is not None
    assert worker["agent_type"] == "codex"
    assert worker["contract"]["agent_type"] == "codex"
    assert worker["contract"]["applied_via"] == "codex-create"
    assert worker["cache"]["thread_id"] == "codex-thread-1"
    assert launches[0][:4] == (
        W1,
        str(work_path),
        worker["contract"]["bootstrap_prompt"],
        worker["contract"]["append_system_prompt"],
    )
    assert launches[0][4] is not None
    assert launches[0][4]["KEEP_GROUP_ID"] == "group-123"
    assert launches[0][4]["KEEP_USER_SESSION"] == W1


def test_supervisor_create_uses_group_default_agent_when_unspecified(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", default_agent="codex")

    captured: dict[str, object] = {}

    monkeypatch.setattr("keep._cli.dispatch_supervisor.generate_session_id", lambda: S1)

    def fake_spawn_and_wait_for_ready(
        session,
        path,
        *,
        agent_type,
        terminal_type,
        bootstrap_prompt,
        append_system_prompt,
        role,
        group_id,
        user_env,
    ):
        captured["agent_type"] = agent_type
        captured["append_system_prompt"] = append_system_prompt
        _ = (session, path, terminal_type, bootstrap_prompt, role, group_id, user_env)
        return {"target_id": "surface-1"}, None

    monkeypatch.setattr("keep._cli.spawn.spawn_and_wait_for_ready", fake_spawn_and_wait_for_ready)

    result = runner.invoke(app, ["group-123", "supervisor", "create", "--name", "sup-a"])
    assert result.exit_code == 0
    assert captured["agent_type"] == "codex"


def test_supervisor_contract_uses_worker_mode_when_workers_enabled(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", workers_enabled=True)
    monkeypatch.setattr("keep._cli.dispatch_supervisor.generate_session_id", lambda: S1)
    captured: dict[str, str] = {}

    def fake_spawn_and_wait_for_ready(
        session,
        path,
        *,
        agent_type,
        terminal_type,
        bootstrap_prompt,
        append_system_prompt,
        role,
        group_id,
        user_env,
    ):
        _ = (session, path, agent_type, terminal_type, bootstrap_prompt, role, group_id, user_env)
        captured["append_system_prompt"] = append_system_prompt
        return {"target_id": "surface-1"}, None

    monkeypatch.setattr("keep._cli.spawn.spawn_and_wait_for_ready", fake_spawn_and_wait_for_ready)

    result = runner.invoke(app, ["group-123", "supervisor", "create", "--name", "sup-a"])
    assert result.exit_code == 0
    assert "supervisor send/read/wake" in captured["append_system_prompt"]
    assert "pending：选择合适 worker" in captured["append_system_prompt"]
    assert "pending：用 Agent tool 派 subagent 实现" not in captured["append_system_prompt"]
    assert "rationale.md 必须 ≤ 150 字" in captured["append_system_prompt"]


def test_supervisor_contract_uses_subagent_mode_when_workers_disabled(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", workers_enabled=False)
    monkeypatch.setattr("keep._cli.dispatch_supervisor.generate_session_id", lambda: S1)
    captured: dict[str, str] = {}

    def fake_spawn_and_wait_for_ready(
        session,
        path,
        *,
        agent_type,
        terminal_type,
        bootstrap_prompt,
        append_system_prompt,
        role,
        group_id,
        user_env,
    ):
        _ = (session, path, agent_type, terminal_type, bootstrap_prompt, role, group_id, user_env)
        captured["append_system_prompt"] = append_system_prompt
        return {"target_id": "surface-1"}, None

    monkeypatch.setattr("keep._cli.spawn.spawn_and_wait_for_ready", fake_spawn_and_wait_for_ready)

    result = runner.invoke(app, ["group-123", "supervisor", "create", "--name", "sup-a"])
    assert result.exit_code == 0
    assert "Agent tool 派 subagent" in captured["append_system_prompt"]
    assert "当前 group workers_enabled=false" in captured["append_system_prompt"]
    assert "pending：用 Agent tool 派 subagent 实现" in captured["append_system_prompt"]
    assert "rationale.md 必须 ≤ 150 字" in captured["append_system_prompt"]


def test_reviewer_create_supports_codex_agent(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")

    class FakeInfo:
        running = True
        pid = 321
        target_id = "surface-reviewer-1"
        jsonl_path = "/tmp/reviewer-transcript.jsonl"
        jsonl_search = None
        thread_id = "codex-reviewer-thread"

    reviewer_dir = isolated_state / "reviewers"
    reviewer_dir.mkdir(parents=True, exist_ok=True)
    (reviewer_dir / "alice.md").write_text("reviewer spec", encoding="utf-8")

    monkeypatch.setattr("keep._cli.dispatch_reviewer.generate_session_id", lambda: "33333333-3333-4333-8333-333333333333")
    monkeypatch.setattr("keep._cli.spawn.spawn_codex_session", lambda *args, **kwargs: "surface-reviewer-1")
    monkeypatch.setattr("keep._cli.spawn.wait_for_worker_ready", lambda *args, **kwargs: FakeInfo())
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {
            "pid": info.pid,
            "target_id": info.target_id,
            "jsonl_path": info.jsonl_path,
            "thread_id": info.thread_id,
        },
    )

    result = runner.invoke(app, ["group-123", "reviewer", "create", "--agent", "codex", "--name", "alice"])
    assert result.exit_code == 0

    reviewers = list(state.iter_reviewers("group-123"))
    assert len(reviewers) == 1
    assert reviewers[0]["agent_type"] == "codex"
    assert reviewers[0]["session"] == "33333333-3333-4333-8333-333333333333"
    assert reviewers[0]["cache"]["thread_id"] == "codex-reviewer-thread"


def test_reviewer_create_parses_frontmatter_triggers_and_strips_it_from_prompt(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")

    reviewer_dir = isolated_state / "reviewers"
    reviewer_dir.mkdir(parents=True, exist_ok=True)
    (reviewer_dir / "alice.md").write_text(
        "---\n"
        "triggers: [task_submitted_review, group_stop]\n"
        "---\n\n"
        "# Alice Reviewer\n"
        "只看正文。\n",
        encoding="utf-8",
    )

    monkeypatch.setattr(
        "keep._cli.dispatch_reviewer.generate_session_id",
        lambda: "33333333-3333-4333-8333-333333333333",
    )
    captured: dict[str, str] = {}

    def fake_spawn_and_wait_for_ready(
        session,
        path,
        *,
        agent_type,
        terminal_type,
        bootstrap_prompt,
        append_system_prompt,
        role,
        group_id,
        user_env,
        on_failure,
    ):
        _ = (session, path, agent_type, terminal_type, bootstrap_prompt, role, group_id, user_env, on_failure)
        captured["append_system_prompt"] = append_system_prompt
        return {"target_id": "surface-reviewer-1"}, None

    monkeypatch.setattr("keep._cli.spawn.spawn_and_wait_for_ready", fake_spawn_and_wait_for_ready)

    result = runner.invoke(app, ["group-123", "reviewer", "create", "--name", "alice"])
    assert result.exit_code == 0

    reviewers = list(state.iter_reviewers("group-123"))
    assert len(reviewers) == 1
    assert reviewers[0]["triggers"] == ["task_submitted_review", "group_stop"]
    assert "triggers:" not in captured["append_system_prompt"]
    assert "# Alice Reviewer" in captured["append_system_prompt"]
    assert "rationale.md 必须 ≤ 150 字" in captured["append_system_prompt"]


def _stub_reviewer_spawn(monkeypatch: pytest.MonkeyPatch) -> dict[str, object]:
    captured: dict[str, object] = {}

    def fake_spawn_and_wait_for_ready(
        session,
        path,
        *,
        agent_type,
        terminal_type,
        bootstrap_prompt,
        append_system_prompt,
        role,
        group_id,
        user_env,
        on_failure,
    ):
        captured["session"] = session
        captured["path"] = path
        captured["agent_type"] = agent_type
        captured["bootstrap_prompt"] = bootstrap_prompt
        captured["append_system_prompt"] = append_system_prompt
        return {"target_id": "surface-reviewer-1"}, None

    monkeypatch.setattr("keep._cli.spawn.spawn_and_wait_for_ready", fake_spawn_and_wait_for_ready)
    monkeypatch.setattr(
        "keep._cli.dispatch_reviewer.generate_session_id",
        lambda: "33333333-3333-4333-8333-333333333333",
    )
    return captured


def test_reviewer_create_path_option_is_cwd_passed_to_spawn(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")
    reviewer_dir = isolated_state / "reviewers"
    reviewer_dir.mkdir(parents=True, exist_ok=True)
    (reviewer_dir / "alice.md").write_text("reviewer spec", encoding="utf-8")
    captured = _stub_reviewer_spawn(monkeypatch)

    cwd_dir = isolated_state / "reviewer-cwd"
    cwd_dir.mkdir()
    result = runner.invoke(
        app,
        ["group-123", "reviewer", "create", "--name", "alice", "--path", str(cwd_dir)],
    )
    assert result.exit_code == 0, result.stderr

    assert captured["path"] == str(cwd_dir)
    reviewers = list(state.iter_reviewers("group-123"))
    assert len(reviewers) == 1
    assert reviewers[0]["prompt"].endswith("alice.md")
    assert reviewers[0]["path"] == str(cwd_dir)


def test_reviewer_create_prompt_option_takes_explicit_file(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")
    custom_prompt = isolated_state / "custom-spec.md"
    custom_prompt.write_text(
        "---\ntriggers: [task_proposed_review]\n---\n# Custom\n",
        encoding="utf-8",
    )
    captured = _stub_reviewer_spawn(monkeypatch)

    cwd_dir = isolated_state / "another-cwd"
    cwd_dir.mkdir()
    result = runner.invoke(
        app,
        [
            "group-123", "reviewer", "create",
            "--prompt", str(custom_prompt),
            "--path", str(cwd_dir),
        ],
    )
    assert result.exit_code == 0, result.stderr

    assert captured["path"] == str(cwd_dir)
    reviewers = list(state.iter_reviewers("group-123"))
    assert reviewers[0]["prompt"] == str(custom_prompt.resolve())
    assert reviewers[0]["name"] == "custom-spec"
    assert reviewers[0]["triggers"] == ["task_proposed_review"]


def test_reviewer_create_path_pointing_at_md_file_is_rejected(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")
    reviewer_dir = isolated_state / "reviewers"
    reviewer_dir.mkdir(parents=True, exist_ok=True)
    md_file = reviewer_dir / "alice.md"
    md_file.write_text("reviewer spec", encoding="utf-8")
    _stub_reviewer_spawn(monkeypatch)

    result = runner.invoke(
        app,
        ["group-123", "reviewer", "create", "--path", str(md_file)],
    )
    assert result.exit_code != 0
    assert "--prompt" in (result.stderr or result.stdout)


def test_reviewer_v5_path_migrates_to_prompt(isolated_state: Path) -> None:
    """v5 reviewers stored prompt-file path under `path`. v6 splits it: prompt
    holds the file, path becomes cwd (None when not set)."""
    name = "legacy-group"
    reviewer_md = isolated_state / "reviewers" / "legacy.md"
    reviewer_md.parent.mkdir(parents=True, exist_ok=True)
    reviewer_md.write_text("legacy reviewer", encoding="utf-8")

    raw = {
        "schema_version": 5,
        "name": name,
        "status": "stopped",
        "participants": [
            {
                "session": "rev-1",
                "role": "reviewer",
                "name": "legacy",
                "path": str(reviewer_md),
                "agent_type": "codex",
            }
        ],
        "review_events": [],
        "terminal_type": "cmux",
        "terminal_container": None,
        "default_agent": "codex",
        "workers_enabled": True,
        "group_prompt": None,
    }
    from keep._state.groups import _group_file
    _group_file(name).write_text(json.dumps(raw), encoding="utf-8")

    group = state.load_group(name)
    assert group is not None
    reviewers = [u for u in group["users"] if u.get("role") == "reviewer"]
    assert reviewers[0]["prompt"] == str(reviewer_md)
    assert reviewers[0].get("path") in (None, "")


def test_group_start_requires_reviewer_coverage_matrix(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")
    state.add_supervisor("group-123", S1, name="sup")
    state.add_user("group-123", "sess-reviewer-1", role="reviewer", name="reviewer-a", triggers=["task_submitted_review"])
    monkeypatch.setattr("keep.cli.check_stop_hook_or_fail", lambda agent_types: None)

    result = runner.invoke(app, ["group", "start", "group-123"])

    assert result.exit_code == 1
    assert "task_proposed_review" in result.stderr
    assert "group_stop" in result.stderr


def test_group_start_succeeds_with_full_reviewer_coverage(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")
    state.add_supervisor("group-123", S1, name="sup")
    state.add_user("group-123", "sess-reviewer-1", role="reviewer", name="shadow", triggers=["task_proposed_review", "task_submitted_review"])
    state.add_user("group-123", "sess-reviewer-2", role="reviewer", name="align", triggers=["group_stop"])
    monkeypatch.setattr("keep.cli.check_stop_hook_or_fail", lambda agent_types: None)

    result = runner.invoke(app, ["group", "start", "group-123"])

    assert result.exit_code == 0
    assert "Review Coverage:" in result.stdout
    assert "group_stop=align" in result.stdout
    assert state.load_group("group-123")["status"] == "active"


def test_supervisor_can_start_update_pause_and_resume_group(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    group = state.load_group("group-123")
    assert group is not None
    group["status"] = "stopped"
    state.save_group("group-123", group)
    state.add_user("group-123", "sess-reviewer-1", role="reviewer", name="shadow", triggers=["task_proposed_review", "task_submitted_review"])
    state.add_user("group-123", "sess-reviewer-2", role="reviewer", name="align", triggers=["group_stop"])
    monkeypatch.setattr("keep.cli.check_stop_hook_or_fail", lambda agent_types: None)

    start_result = runner.invoke(app, ["group", "start", "group-123"])
    assert start_result.exit_code == 0
    assert state.load_group("group-123")["status"] == "active"

    update_result = runner.invoke(app, ["group", "update", "group-123", "refined scope"])
    assert update_result.exit_code == 0
    assert state.load_group("group-123")["group_prompt"] == "refined scope"

    pause_result = runner.invoke(app, ["group", "pause", "group-123"])
    assert pause_result.exit_code == 0
    assert state.load_group("group-123")["status"] == "paused"

    resume_result = runner.invoke(app, ["group", "resume", "group-123"])
    assert resume_result.exit_code == 0
    assert state.load_group("group-123")["status"] == "active"


def test_supervisor_still_cannot_remove_group(
    isolated_state: Path,
) -> None:
    _create_active_group("group-123")

    result = runner.invoke(app, ["group", "remove", "group-123"])

    assert result.exit_code == 1
    assert "无权执行 group.remove" in result.stderr


def test_supervisor_can_run_self_start(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A supervisor process should be able to revive the daemon if it dies, since
    none of its other commands work without one."""
    _create_active_group("group-123")
    # _create_active_group sets daemon_pid to test pid, which is_daemon_running
    # would see as live; clear it so self_start can proceed past the guard.
    gs = state.load_global() or state.new_global()
    gs["daemon_pid"] = None
    state.save_global(gs)
    captured: dict[str, object] = {}
    monkeypatch.setattr("keep.cli.launch_daemon", lambda gs, fg, quiet=False: captured.setdefault("called", True))

    result = runner.invoke(app, ["self", "start"])

    assert captured.get("called") is True
    assert result.exit_code == 0


def test_supervisor_still_cannot_run_self_stop(
    isolated_state: Path,
) -> None:
    _create_active_group("group-123")

    result = runner.invoke(app, ["self", "stop"])

    assert result.exit_code == 1
    assert "无权执行 self.stop" in result.stderr


def test_supervisor_does_not_have_direct_group_stop_state_authority() -> None:
    assert group_status_mutation_allowed(
        actor_role=ActorRole.SUPERVISOR,
        source_status="active",
        target_status="stopped",
    ) is False


def test_group_stop_fails_fast_when_no_reviewer_covers_group_stop(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_user("group-123", "sess-reviewer-1", role="reviewer", name="reviewer-a", triggers=["task_proposed_review", "task_submitted_review"])
    monkeypatch.setattr("keep.cli._request_group_stop_review", lambda group_id, group, rationale: (_ for _ in ()).throw(AssertionError("should not dispatch stop review")))

    result = runner.invoke(app, ["group", "stop", "group-123"])

    assert result.exit_code == 1
    assert "没有 reviewer 覆盖 group_stop" in result.stderr


def test_spawn_and_wait_for_ready_allows_codex_with_transcript_path(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    info = SimpleNamespace(
        session=W1,
        agent_type="codex",
        running=True,
        pid=123,
        target_id="surface-codex-1",
        jsonl_path="/tmp/codex-transcript.jsonl",
        jsonl_search=None,
        thread_id="codex-thread-1",
    )

    monkeypatch.setattr("keep._cli.spawn.spawn_agent_session", lambda *args, **kwargs: "surface-codex-1")
    monkeypatch.setattr("keep._cli.spawn.wait_for_worker_ready", lambda *args, **kwargs: info)
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda worker_info: {
            "pid": worker_info.pid,
            "target_id": worker_info.target_id,
            "jsonl_path": worker_info.jsonl_path,
            "thread_id": worker_info.thread_id,
        },
    )

    cache, ready_info = _spawn_and_wait_for_ready(
        W1,
        None,
        agent_type="codex",
        terminal_type="cmux",
        bootstrap_prompt="boot",
        append_system_prompt="sys",
        role="worker",
        group_id="group-123",
    )

    assert ready_info is info
    assert cache == {
        "pid": 123,
        "target_id": "surface-codex-1",
        "jsonl_path": "/tmp/codex-transcript.jsonl",
        "thread_id": "codex-thread-1",
    }


def test_spawn_codex_session_marks_target_path_trusted(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", terminal_type="cmux")
    calls: dict[str, object] = {}
    codex_home = isolated_state / "codex-home"
    codex_home.mkdir(parents=True)
    config_dir = codex_home / ".codex"
    config_dir.mkdir(parents=True)
    (config_dir / "config.toml").write_text("[features]\ncodex_hooks = true\n", encoding="utf-8")

    class FakeTerminal:
        def ensure_group_container(self, group_id: str) -> str:
            calls["ensure_group_id"] = group_id
            return "workspace:1"

        def spawn_in_container(
            self,
            ref: str,
            role: str,
            role_index: int,
            target_path: str,
            cmd: str,
        ) -> str:
            calls["ref"] = ref
            calls["role"] = role
            calls["role_index"] = role_index
            calls["target_path"] = target_path
            calls["cmd"] = cmd
            return "surface-1"

    monkeypatch.setattr("keep._cli.spawn.check_stop_hook_or_fail", lambda agent_types: None)
    monkeypatch.setattr("keep._cli.spawn.get_terminal", lambda terminal_type: FakeTerminal())
    monkeypatch.setattr("keep._cli.spawn.Path.home", lambda: codex_home)

    target_id = spawn_codex_session(
        "session-1",
        "/tmp/codex-trusted-path",
        bootstrap_prompt="boot",
        append_system_prompt="sys",
        terminal_type="cmux",
        role="supervisor",
        group_id="group-123",
    )

    assert target_id == "surface-1"
    assert calls["ensure_group_id"] == "group-123"
    assert calls["ref"] == "workspace:1"
    assert calls["role"] == "supervisor"
    assert calls["role_index"] == 0
    assert calls["target_path"] == "/tmp/codex-trusted-path"
    assert "codex --dangerously-bypass-approvals-and-sandbox" in str(calls["cmd"])
    assert "trust_level" not in str(calls["cmd"])
    config_text = (config_dir / "config.toml").read_text(encoding="utf-8")
    assert 'approval_policy = "never"' in config_text
    assert 'sandbox_mode = "danger-full-access"' in config_text
    assert '[projects."/private/tmp/codex-trusted-path"]' in config_text
    assert 'trust_level = "trusted"' in config_text


def test_spawn_codex_session_upgrades_existing_project_trust_entry(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", terminal_type="cmux")
    codex_home = isolated_state / "codex-home"
    codex_home.mkdir(parents=True)
    config_dir = codex_home / ".codex"
    config_dir.mkdir(parents=True)
    target_path = "/private/tmp/codex-trusted-path"
    (config_dir / "config.toml").write_text(
        f'[projects."{target_path}"]\ntrust_level = "untrusted"\n',
        encoding="utf-8",
    )

    class FakeTerminal:
        def ensure_group_container(self, group_id: str) -> str:
            return "workspace:1"

        def spawn_in_container(
            self,
            ref: str,
            role: str,
            role_index: int,
            target_path: str,
            cmd: str,
        ) -> str:
            return "surface-1"

    monkeypatch.setattr("keep._cli.spawn.check_stop_hook_or_fail", lambda agent_types: None)
    monkeypatch.setattr("keep._cli.spawn.get_terminal", lambda terminal_type: FakeTerminal())
    monkeypatch.setattr("keep._cli.spawn.Path.home", lambda: codex_home)

    spawn_codex_session(
        "session-1",
        target_path,
        bootstrap_prompt="boot",
        append_system_prompt="sys",
        terminal_type="cmux",
        role="supervisor",
        group_id="group-123",
    )

    config_text = (config_dir / "config.toml").read_text(encoding="utf-8")
    assert 'trust_level = "untrusted"' not in config_text
    assert config_text.count(f'[projects."{target_path}"]') == 1
    assert config_text.count('trust_level = "trusted"') == 1


def test_spawn_codex_session_upgrades_root_approval_settings(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", terminal_type="cmux")
    codex_home = isolated_state / "codex-home"
    codex_home.mkdir(parents=True)
    config_dir = codex_home / ".codex"
    config_dir.mkdir(parents=True)
    (config_dir / "config.toml").write_text(
        'approval_policy = "on-request"\n'
        'sandbox_mode = "workspace-write"\n'
        '[features]\n'
        'codex_hooks = true\n',
        encoding="utf-8",
    )

    class FakeTerminal:
        def ensure_group_container(self, group_id: str) -> str:
            return "workspace:1"

        def spawn_in_container(self, ref: str, role: str, role_index: int, target_path: str, cmd: str) -> str:
            return "surface-1"

    monkeypatch.setattr("keep._cli.spawn.check_stop_hook_or_fail", lambda agent_types: None)
    monkeypatch.setattr("keep._cli.spawn.get_terminal", lambda terminal_type: FakeTerminal())
    monkeypatch.setattr("keep._cli.spawn.Path.home", lambda: codex_home)

    spawn_codex_session(
        "session-1",
        "/tmp/codex-trusted-path",
        bootstrap_prompt="boot",
        append_system_prompt="sys",
        terminal_type="cmux",
        role="supervisor",
        group_id="group-123",
    )

    config_text = (config_dir / "config.toml").read_text(encoding="utf-8")
    assert 'approval_policy = "on-request"' not in config_text
    assert 'sandbox_mode = "workspace-write"' not in config_text
    assert 'approval_policy = "never"' in config_text
    assert 'sandbox_mode = "danger-full-access"' in config_text


def test_spawn_codex_session_trusts_raw_and_resolved_tmp_aliases(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", terminal_type="cmux")
    codex_home = isolated_state / "codex-home"
    codex_home.mkdir(parents=True)
    config_dir = codex_home / ".codex"
    config_dir.mkdir(parents=True)
    (config_dir / "config.toml").write_text("[features]\ncodex_hooks = true\n", encoding="utf-8")

    class FakeTerminal:
        def ensure_group_container(self, group_id: str) -> str:
            return "workspace:1"

        def spawn_in_container(self, ref: str, role: str, role_index: int, target_path: str, cmd: str) -> str:
            return "surface-1"

    monkeypatch.setattr("keep._cli.spawn.check_stop_hook_or_fail", lambda agent_types: None)
    monkeypatch.setattr("keep._cli.spawn.get_terminal", lambda terminal_type: FakeTerminal())
    monkeypatch.setattr("keep._cli.spawn.Path.home", lambda: codex_home)

    spawn_codex_session(
        "session-1",
        "/tmp/codex-trusted-path",
        bootstrap_prompt="boot",
        append_system_prompt="sys",
        terminal_type="cmux",
        role="supervisor",
        group_id="group-123",
    )

    config_text = (config_dir / "config.toml").read_text(encoding="utf-8")
    assert '[projects."/tmp/codex-trusted-path"]' in config_text
    assert '[projects."/private/tmp/codex-trusted-path"]' in config_text


def _stub_claude_terminal(monkeypatch: pytest.MonkeyPatch, calls: dict[str, object]):
    class FakeTerminal:
        def ensure_group_container(self, group_id: str) -> str:
            calls["ensure_mission_id"] = group_id
            return "workspace:1"

        def spawn_in_container(
            self,
            ref: str,
            role: str,
            role_index: int,
            target_path: str,
            cmd: str,
        ) -> str:
            calls["ref"] = ref
            calls["role"] = role
            calls["role_index"] = role_index
            calls["target_path"] = target_path
            calls["cmd"] = cmd
            return "surface-1"

    monkeypatch.setattr("keep._cli.spawn.check_stop_hook_or_fail", lambda agent_types: None)
    monkeypatch.setattr("keep._cli.spawn.get_terminal", lambda terminal_type: FakeTerminal())


def test_spawn_claude_session_marks_target_path_trusted(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", terminal_type="cmux")
    calls: dict[str, object] = {}
    claude_home = isolated_state / "claude-home"
    claude_home.mkdir(parents=True)
    _stub_claude_terminal(monkeypatch, calls)
    monkeypatch.setattr("keep._cli.spawn.Path.home", lambda: claude_home)

    target_id = spawn_claude_session(
        "session-1",
        "/tmp/claude-trusted-path",
        bootstrap_prompt="boot",
        append_system_prompt="sys",
        terminal_type="cmux",
        role="supervisor",
        group_id="group-123",
    )

    assert target_id == "surface-1"
    assert calls["target_path"] == "/tmp/claude-trusted-path"
    config_path = claude_home / ".claude.json"
    assert config_path.exists()
    config = json.loads(config_path.read_text(encoding="utf-8"))
    projects = config["projects"]
    assert projects["/tmp/claude-trusted-path"]["hasTrustDialogAccepted"] is True
    assert projects["/private/tmp/claude-trusted-path"]["hasTrustDialogAccepted"] is True


def test_spawn_claude_session_preserves_existing_claude_config(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", terminal_type="cmux")
    calls: dict[str, object] = {}
    claude_home = isolated_state / "claude-home"
    claude_home.mkdir(parents=True)
    config_path = claude_home / ".claude.json"
    config_path.write_text(
        json.dumps(
            {
                "userID": "user-abc",
                "projects": {
                    "/some/other/project": {
                        "hasTrustDialogAccepted": True,
                        "allowedTools": ["bash"],
                    },
                    "/tmp/claude-trusted-path": {"allowedTools": ["read"]},
                },
            }
        ),
        encoding="utf-8",
    )
    _stub_claude_terminal(monkeypatch, calls)
    monkeypatch.setattr("keep._cli.spawn.Path.home", lambda: claude_home)

    spawn_claude_session(
        "session-1",
        "/tmp/claude-trusted-path",
        bootstrap_prompt="boot",
        append_system_prompt="sys",
        terminal_type="cmux",
        role="supervisor",
        group_id="group-123",
    )

    config = json.loads(config_path.read_text(encoding="utf-8"))
    assert config["userID"] == "user-abc"
    other = config["projects"]["/some/other/project"]
    assert other["hasTrustDialogAccepted"] is True
    assert other["allowedTools"] == ["bash"]
    target = config["projects"]["/tmp/claude-trusted-path"]
    assert target["hasTrustDialogAccepted"] is True
    assert target["allowedTools"] == ["read"]


def test_worker_create_attach_existing_codex_session_without_transcript_path(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    monkeypatch.delenv("KEEP_GROUP_ID", raising=False)
    monkeypatch.delenv("KEEP_USER_SESSION", raising=False)

    monkeypatch.setattr(
        "keep._cli.dispatch_worker.resolve_worker",
        lambda session, terminal_type=None, **kwargs: SimpleNamespace(
            session=session,
            agent_type="codex",
            running=True,
            pid=123,
            target_id="surface-codex-1",
            jsonl_path=None,
            jsonl_search=None,
            thread_id=None,
        ),
    )
    monkeypatch.setattr(
        "keep._cli.dispatch_worker.worker_cache_from_info",
        lambda info: {
            "pid": info.pid,
            "target_id": info.target_id,
            "thread_id": info.thread_id,
        },
    )

    result = runner.invoke(
        app,
        ["group-123", "worker", "create", "--agent", "codex", "--session", "codex-thread-1"],
    )
    assert result.exit_code == 0

    group = state.load_group("group-123")
    worker = state.find_worker(group, "codex-thread-1")
    assert worker is not None
    assert worker["agent_type"] == "codex"
    assert worker["cache"]["thread_id"] == "codex-thread-1"


def test_wait_for_worker_ready_for_codex_matches_user_session(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    started_at = time.time() - 1
    wrong_payload = isolated_state / "stop-wrong-thread"
    right_payload = isolated_state / "stop-right-thread"
    right_payload.write_text(
        json.dumps(
            {
                "session_id": "right-thread",
                "keep_user_session": W1,
                "transcript_path": "/tmp/right.jsonl",
                "last_assistant_message": "ready",
            }
        ),
        encoding="utf-8",
    )
    wrong_payload.write_text(
        json.dumps(
            {
                "session_id": "wrong-thread",
                "keep_user_session": "worker-other",
                "transcript_path": "/tmp/wrong.jsonl",
                "last_assistant_message": "ready",
            }
        ),
        encoding="utf-8",
    )
    os.utime(right_payload, (started_at + 0.1, started_at + 0.1))
    os.utime(wrong_payload, (started_at + 0.2, started_at + 0.2))

    info = SimpleNamespace(
        session=W1,
        agent_type="codex",
        running=True,
        pid=123,
        target_id="surface-codex-1",
        jsonl_path=None,
        jsonl_search=None,
        thread_id=None,
    )
    monkeypatch.setattr("keep._cli.spawn.resolve_worker", lambda *args, **kwargs: info)
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: None)

    result = _wait_for_worker_ready(
        W1,
        agent_type="codex",
        terminal_type="cmux",
        cache_hint={"target_id": "surface-codex-1"},
        started_at=started_at,
        user_session=W1,
    )

    assert result is info
    assert result.thread_id == "right-thread"
    assert str(result.jsonl_path) == "/tmp/right.jsonl"


def test_worker_create_fails_when_workers_disabled(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123", workers_enabled=False)
    with state.mutate_group("group-123") as group:
        group["status"] = "active"
    monkeypatch.delenv("KEEP_GROUP_ID", raising=False)
    monkeypatch.delenv("KEEP_USER_SESSION", raising=False)

    result = runner.invoke(app, ["group-123", "worker", "create", "--name", "worker-a"])
    assert result.exit_code == 1
    assert "workers_enabled=false" in result.stderr


def test_supervisor_send_fails_when_workers_disabled(
    isolated_state: Path,
) -> None:
    _create_active_group("group-123")
    with state.mutate_group("group-123") as group:
        group["workers_enabled"] = False

    result = runner.invoke(app, ["group-123", "supervisor", "send", "/tmp/message.md"])
    assert result.exit_code == 1
    assert "workers_enabled=false" in result.stderr


def test_wait_for_worker_ready_succeeds_when_ready_arrives_in_later_poll_round(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    info = SimpleNamespace(
        running=True,
        pid=123,
        target_id="surface-1",
        jsonl_path=None,
        jsonl_search=None,
    )
    payloads = iter([None] * 12 + [("provider-session", {"transcript_path": "/tmp/fake.jsonl", "last_assistant_message": "OK"})])
    sleeps: list[float] = []

    monkeypatch.setattr("keep._cli.spawn.resolve_worker", lambda *args, **kwargs: info)
    monkeypatch.setattr("keep._cli.spawn._find_stop_payload_after", lambda *args, **kwargs: next(payloads))
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: sleeps.append(seconds))

    result = _wait_for_worker_ready(W1, agent_type="claude-code", terminal_type="cmux", user_session=W1)

    assert result is info
    assert str(result.jsonl_path) == "/tmp/fake.jsonl"
    assert sleeps == [0.2] * 12


def test_find_stop_payload_after_prefers_payload_timestamp_over_mtime(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from keep._cli.spawn import _find_stop_payload_after

    started_at = time.time() - 1
    older = isolated_state / "stop-older"
    newer = isolated_state / "stop-newer"
    older.write_text(
        json.dumps(
            {
                "session_id": "older",
                "keep_user_session": W1,
                "keep_written_at": str(started_at + 0.1),
                "last_assistant_message": "old",
            }
        ),
        encoding="utf-8",
    )
    newer.write_text(
        json.dumps(
            {
                "session_id": "newer",
                "keep_user_session": W1,
                "keep_written_at": str(started_at + 0.2),
                "last_assistant_message": "new",
            }
        ),
        encoding="utf-8",
    )
    os.utime(older, (started_at + 5, started_at + 5))
    os.utime(newer, (started_at + 1, started_at + 1))

    payload = _find_stop_payload_after(started_at, user_session=W1)

    assert payload is not None
    assert payload[0] == "newer"


def test_check_codex_stop_hook_keeps_feature_error_even_if_hook_is_configured(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    hook_script = isolated_state / "on-stop.sh"
    hook_script.write_text("#!/bin/bash\nexit 0\n", encoding="utf-8")

    codex_home = isolated_state / "codex-home"
    codex_home.mkdir(parents=True)
    config_dir = codex_home / ".codex"
    config_dir.mkdir(parents=True)
    (config_dir / "config.toml").write_text("[features]\ncodex_hooks = false\n", encoding="utf-8")
    hooks_path = config_dir / "hooks.json"
    hooks_path.write_text(
        '{"hooks":{"Stop":[{"type":"command","command":"bash '
        + str(hook_script).replace("\\", "\\\\").replace('"', '\\"')
        + '"}]}}',
        encoding="utf-8",
    )

    monkeypatch.setattr("keep._cli.spawn.Path.home", lambda: codex_home)
    monkeypatch.setattr("keep._cli.spawn._codex_hook_paths", lambda: [hooks_path])

    errors: list[str] = []
    _check_codex_stop_hook(errors)

    assert any("Codex hooks feature 未启用" in err for err in errors)
    assert not any("Codex hooks 未配置 stop hook" in err for err in errors)


def test_worker_create_waits_until_ready_ack_before_persisting(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    monkeypatch.delenv("KEEP_GROUP_ID", raising=False)
    monkeypatch.delenv("KEEP_USER_SESSION", raising=False)

    info = SimpleNamespace(running=True, pid=123, target_id="surface-1", jsonl_path=None, jsonl_search=None)
    payloads = iter([
        None,
        None,
        ("claude-provider-session", {"transcript_path": "/tmp/fake.jsonl", "last_assistant_message": "OK"}),
    ])
    sleeps: list[float] = []

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr("keep._cli.spawn.resolve_worker", lambda *args, **kwargs: info)
    monkeypatch.setattr("keep._cli.spawn._find_stop_payload_after", lambda *args, **kwargs: next(payloads))
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: sleeps.append(seconds))
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    result = runner.invoke(app, ["group-123", "worker", "create"])

    assert result.exit_code == 0
    assert sleeps == [0.2, 0.2]


def test_worker_create_fails_when_ready_ack_never_arrives(isolated_state: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _create_active_group("group-123")
    monkeypatch.delenv("KEEP_GROUP_ID", raising=False)
    monkeypatch.delenv("KEEP_USER_SESSION", raising=False)

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr(
        "keep._cli.spawn.resolve_worker",
        lambda *args, **kwargs: SimpleNamespace(running=True, pid=123, target_id="surface-1", jsonl_path=None, jsonl_search=None),
    )
    monkeypatch.setattr("keep._cli.spawn._find_stop_payload_after", lambda *args, **kwargs: None)
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: None)

    result = runner.invoke(app, ["group-123", "worker", "create"])

    assert result.exit_code == 1
    assert "ready" in result.stderr.lower()
    group = state.load_group("group-123")
    assert state.find_worker(group, "11111111-1111-4111-8111-111111111111") is None


def test_worker_create_succeeds_when_process_exits_but_ready_ack_is_present(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    monkeypatch.delenv("KEEP_GROUP_ID", raising=False)
    monkeypatch.delenv("KEEP_USER_SESSION", raising=False)

    monkeypatch.setattr("keep._cli.spawn.spawn_claude_session", lambda *args, **kwargs: None)
    monkeypatch.setattr("keep._cli.dispatch_worker.generate_session_id", lambda: "11111111-1111-4111-8111-111111111111")
    monkeypatch.setattr(
        "keep._cli.spawn.resolve_worker",
        lambda *args, **kwargs: SimpleNamespace(running=False, pid=123, target_id="surface-1", jsonl_path=None, jsonl_search=None),
    )
    monkeypatch.setattr(
        "keep._cli.spawn._find_stop_payload_after",
        lambda *args, **kwargs: ("claude-provider-session", {"transcript_path": "/tmp/fake.jsonl", "last_assistant_message": "OK"}),
    )
    monkeypatch.setattr("keep._cli.spawn.time.sleep", lambda seconds: None)
    monkeypatch.setattr(
        "keep._cli.spawn.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    result = runner.invoke(app, ["group-123", "worker", "create"])

    assert result.exit_code == 0
    group = state.load_group("group-123")
    worker = state.find_worker(group, "11111111-1111-4111-8111-111111111111")
    assert worker is not None
    assert worker["cache"]["jsonl_path"] == "/tmp/fake.jsonl"


def test_worker_create_rejects_manual_session_id(isolated_state: Path) -> None:
    state.create_group("group-123")

    result = runner.invoke(app, ["group-123", "worker", "create", W1])

    assert result.exit_code == 2
    assert "No such argument" in result.stderr


def test_supervisor_create_rejects_manual_session_id(isolated_state: Path) -> None:
    state.create_group("group-123")

    result = runner.invoke(app, ["group-123", "supervisor", "create", S1])

    assert result.exit_code == 2
    assert "No such argument" in result.stderr


def test_worker_list_show_update_remove_under_group(isolated_state: Path) -> None:
    state.create_group("group-123")
    state.add_worker(
        "group-123",
        W1,
        name="worker-a",
        path="/tmp/work-a",
        cache={"pid": 101, "target_id": "s1", "jsonl_path": "/tmp/worker-1.jsonl"},
    )

    list_result = runner.invoke(app, ["group-123", "worker", "list"])
    assert list_result.exit_code == 0
    assert W1 in list_result.stdout

    show_result = runner.invoke(app, ["group-123", "worker", "show", W1])
    assert show_result.exit_code == 0
    assert f'"session": "{W1}"' in show_result.stdout
    assert '"name": "worker-a"' in show_result.stdout
    assert '"path": "/tmp/work-a"' in show_result.stdout
    assert '"role": "worker"' in show_result.stdout

    update_result = runner.invoke(
        app,
        ["group-123", "worker", "update", W1, "--name", "worker-b", "--path", "/tmp/work-b"],
    )
    assert update_result.exit_code == 0

    group = state.load_group("group-123")
    worker = state.find_worker(group, W1)
    assert worker is not None
    assert worker["name"] == "worker-b"
    assert worker["path"] == "/tmp/work-b"

    remove_result = runner.invoke(app, ["group-123", "worker", "remove", W1])
    assert remove_result.exit_code == 0

    list_after_remove = runner.invoke(app, ["group-123", "worker", "list"])
    assert list_after_remove.exit_code == 0
    assert W1 not in list_after_remove.stdout

    show_after_remove = runner.invoke(app, ["group-123", "worker", "show", W1])
    assert show_after_remove.exit_code == 1
    assert "不存在" in show_after_remove.stderr


def test_worker_show_update_remove_error_when_target_missing(isolated_state: Path) -> None:
    state.create_group("group-123")

    show_result = runner.invoke(app, ["group-123", "worker", "show", WMISS])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    update_result = runner.invoke(
        app,
        ["group-123", "worker", "update", WMISS, "--name", "worker-b"],
    )
    assert update_result.exit_code == 1
    assert "不存在" in update_result.stderr

    remove_result = runner.invoke(app, ["group-123", "worker", "remove", WMISS])
    assert remove_result.exit_code == 1
    assert "不存在" in remove_result.stderr


def test_supervisor_list_show_update_remove_under_group(isolated_state: Path) -> None:
    state.create_group("group-123")
    state.add_supervisor(
        "group-123",
        S1,
        name="sup-a",
        path="/tmp/sup-a",
        cache={"pid": 202, "target_id": "s2", "jsonl_path": "/tmp/sup-1.jsonl"},
    )

    list_result = runner.invoke(app, ["group-123", "supervisor", "list"])
    assert list_result.exit_code == 0
    assert S1 in list_result.stdout

    show_result = runner.invoke(app, ["group-123", "supervisor", "show", S1])
    assert show_result.exit_code == 0
    assert f'"session": "{S1}"' in show_result.stdout
    assert '"name": "sup-a"' in show_result.stdout
    assert '"path": "/tmp/sup-a"' in show_result.stdout
    assert '"role": "supervisor"' in show_result.stdout

    update_result = runner.invoke(
        app,
        ["group-123", "supervisor", "update", S1, "--name", "sup-b", "--path", "/tmp/sup-b"],
    )
    assert update_result.exit_code == 0

    group = state.load_group("group-123")
    supervisor = state.find_supervisor(group)
    assert supervisor is not None
    assert supervisor["name"] == "sup-b"
    assert supervisor["path"] == "/tmp/sup-b"

    remove_result = runner.invoke(app, ["group-123", "supervisor", "remove", S1])
    assert remove_result.exit_code == 0

    list_after_remove = runner.invoke(app, ["group-123", "supervisor", "list"])
    assert list_after_remove.exit_code == 0
    assert S1 not in list_after_remove.stdout

    show_after_remove = runner.invoke(app, ["group-123", "supervisor", "show", S1])
    assert show_after_remove.exit_code == 1
    assert "不存在" in show_after_remove.stderr


def test_supervisor_show_update_remove_error_when_target_missing(isolated_state: Path) -> None:
    state.create_group("group-123")

    show_result = runner.invoke(app, ["group-123", "supervisor", "show", SMISS])
    assert show_result.exit_code == 1
    assert "不存在" in show_result.stderr

    update_result = runner.invoke(
        app,
        ["group-123", "supervisor", "update", SMISS, "--name", "sup-b"],
    )
    assert update_result.exit_code == 1
    assert "不存在" in update_result.stderr

    remove_result = runner.invoke(app, ["group-123", "supervisor", "remove", SMISS])
    assert remove_result.exit_code == 1
    assert "不存在" in remove_result.stderr


def test_supervisor_read_outputs_last_message_for_explicit_worker(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=101,
            target_id="surface-1",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.dispatch_supervisor.agent_last_message",
        lambda worker: SimpleNamespace(text="latest reply"),
    )

    result = runner.invoke(app, ["group-123", "supervisor", "read", W1])
    assert result.exit_code == 0
    assert "latest reply" in result.stdout


def test_supervisor_read_uses_codex_agent_for_codex_worker(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker(
        "group-123",
        W1,
        agent_type="codex",
        cache={"target_id": "surface-1", "thread_id": "codex-thread-1"},
    )

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None, **kwargs: SimpleNamespace(
            session=session,
            running=True,
            pid=101,
            target_id="surface-1",
            jsonl_path=Path("/tmp/codex-transcript.jsonl"),
            thread_id="codex-thread-1",
        ),
    )

    monkeypatch.setattr(
        "keep._cli.dispatch_supervisor.agent_last_message",
        lambda worker: SimpleNamespace(text="codex latest reply"),
    )

    result = runner.invoke(app, ["group-123", "supervisor", "read", W1])
    assert result.exit_code == 0
    assert "codex latest reply" in result.stdout


def test_supervisor_send_uses_resolved_worker_surface(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "stale-surface"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=202,
            target_id="surface-live",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    sent: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda surface, text: sent.append((surface, text)),
            send_key=lambda *a, **k: None,
            close=lambda *a, **k: None,
        ),
    )

    # Write message file into messages/ dir so send accepts it
    msg_dir = state.messages_dir("group-123")
    msg_file = msg_dir / "hello.md"
    msg_file.write_text("hello worker")

    result = runner.invoke(app, ["group-123", "supervisor", "send", W1, str(msg_file)])
    assert result.exit_code == 0
    assert sent == [("surface-live", "hello worker")]


def test_supervisor_kick_sends_enter_to_worker_surface(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=303,
            target_id="surface-kick",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    keys: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda *a, **k: None,
            send_key=lambda target_id, key: keys.append((target_id, key)),
            close=lambda *a, **k: None,
        ),
    )

    result = runner.invoke(app, ["group-123", "supervisor", "wake", W1])
    assert result.exit_code == 0
    assert keys == [("surface-kick", "enter")]


def test_supervisor_send_read_kick_fail_when_worker_missing(isolated_state: Path) -> None:
    _create_active_group("group-123")

    send_result = runner.invoke(app, ["group-123", "supervisor", "send", WMISS, "hello"])
    assert send_result.exit_code == 1
    assert "Worker not found in group" in send_result.stderr

    read_result = runner.invoke(app, ["group-123", "supervisor", "read", WMISS])
    assert read_result.exit_code == 1
    assert "Worker not found in group" in read_result.stderr

    kick_result = runner.invoke(app, ["group-123", "supervisor", "wake", WMISS])
    assert kick_result.exit_code == 1
    assert "Worker not found in group" in kick_result.stderr


def test_supervisor_send_read_kick_allow_omitting_worker_for_single_worker(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=404,
            target_id="surface-single",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )
    monkeypatch.setattr(
        "keep._cli.dispatch_supervisor.agent_last_message",
        lambda worker: SimpleNamespace(text="single latest"),
    )

    sent: list[tuple[str, str]] = []
    keys: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda surface, text: sent.append((surface, text)),
            send_key=lambda target_id, key: keys.append((target_id, key)),
            close=lambda *a, **k: None,
        ),
    )

    # Write message file into messages/ dir
    msg_dir = state.messages_dir("group-123")
    msg_file = msg_dir / "hello.md"
    msg_file.write_text("hello single worker")

    send_result = runner.invoke(app, ["group-123", "supervisor", "send", str(msg_file)])
    assert send_result.exit_code == 0
    assert sent == [("surface-single", "hello single worker")]

    read_result = runner.invoke(app, ["group-123", "supervisor", "read"])
    assert read_result.exit_code == 0
    assert "single latest" in read_result.stdout

    kick_result = runner.invoke(app, ["group-123", "supervisor", "wake"])
    assert kick_result.exit_code == 0
    assert keys == [("surface-single", "enter")]


def test_supervisor_send_read_kick_require_worker_for_multi_worker(
    isolated_state: Path,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})
    state.add_worker("group-123", W2, cache={"target_id": "surface-2"})

    send_result = runner.invoke(app, ["group-123", "supervisor", "send", "hello"])
    assert send_result.exit_code == 1
    assert "Multiple workers" in send_result.stderr

    read_result = runner.invoke(app, ["group-123", "supervisor", "read"])
    assert read_result.exit_code == 1
    assert "Multiple workers" in read_result.stderr

    kick_result = runner.invoke(app, ["group-123", "supervisor", "wake"])
    assert kick_result.exit_code == 1
    assert "Multiple workers" in kick_result.stderr


def test_worker_id_prefix_unique_match_for_show_update_remove(isolated_state: Path) -> None:
    state.create_group("group-123")
    state.add_worker("group-123", W1, name="worker-a", path="/tmp/work-a", cache={"target_id": "s1"})

    prefix = W1[:8]
    show_result = runner.invoke(app, ["group-123", "worker", "show", prefix])
    assert show_result.exit_code == 0
    assert W1 in show_result.stdout

    update_result = runner.invoke(app, ["group-123", "worker", "update", prefix, "--name", "worker-b"])
    assert update_result.exit_code == 0

    remove_result = runner.invoke(app, ["group-123", "worker", "remove", prefix])
    assert remove_result.exit_code == 0


def test_worker_id_prefix_ambiguous_reports_candidates(isolated_state: Path) -> None:
    state.create_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "s1"})
    state.add_worker("group-123", W2, cache={"target_id": "s2"})

    result = runner.invoke(app, ["group-123", "worker", "show", "11111111"])
    assert result.exit_code == 1
    assert "歧义" in result.stderr
    assert W1 in result.stderr
    assert W2 in result.stderr


def test_alias_like_id_is_rejected(isolated_state: Path) -> None:
    state.create_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "s1"})

    result = runner.invoke(app, ["group-123", "worker", "show", "alice"])
    assert result.exit_code == 1
    assert "UUID" in result.stderr


def test_supervisor_send_read_kick_consistent_offline_error(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    msg_file = state.messages_dir("group-123") / "hello.md"
    msg_file.write_text("hello worker")

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=False,
            pid=202,
            target_id="surface-live",
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )

    for cmd in (["send", W1, str(msg_file)], ["read", W1], ["wake", W1]):
        result = runner.invoke(app, ["group-123", "supervisor", *cmd])
        assert result.exit_code == 1
        assert "Worker is offline" in result.stderr


def test_supervisor_send_read_kick_consistent_surface_error(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={})

    msg_file = state.messages_dir("group-123") / "hello.md"
    msg_file.write_text("hello worker")

    # Ensure the cached target_id (if any) is blanked — resolve_worker returns target_id=None,
    # but refresh_worker_cache is meant to preserve existing. Remove via add_worker cache={}.
    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session,
            running=True,
            pid=202,
            target_id=None,
            jsonl_path=Path("/tmp/worker-1.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    for cmd in (["send", W1, str(msg_file)], ["read", W1], ["wake", W1]):
        result = runner.invoke(app, ["group-123", "supervisor", *cmd])
        assert result.exit_code == 1
        assert "Worker target unavailable" in result.stderr


def test_supervisor_send_rejects_inline_string(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session, running=True, pid=1, target_id="s", jsonl_path=Path("/tmp/x.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    result = runner.invoke(app, ["group-123", "supervisor", "send", W1, "inline string message"])
    assert result.exit_code == 2
    assert "file path" in result.stderr.lower()


def test_supervisor_send_rejects_missing_path(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session, running=True, pid=1, target_id="s", jsonl_path=Path("/tmp/x.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    result = runner.invoke(app, ["group-123", "supervisor", "send", W1, "/tmp/keep-does-not-exist-xyz.md"])
    assert result.exit_code == 2
    assert "file not found" in result.stderr.lower()


def test_supervisor_send_copies_file_outside_messages_dir(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session, running=True, pid=1, target_id="surface-1", jsonl_path=Path("/tmp/x.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    sent: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda surface, text: sent.append((surface, text)),
            send_key=lambda *a, **k: None,
            close=lambda *a, **k: None,
        ),
    )

    # File is outside messages/ — should be copied with warning
    src = tmp_path / "outside.md"
    src.write_text("content from outside")

    result = runner.invoke(app, ["group-123", "supervisor", "send", W1, str(src)])
    assert result.exit_code == 0
    assert "Warning" in result.stderr
    assert "copied" in result.stderr.lower()
    assert sent == [("surface-1", "content from outside")]

    # Verify copied into messages/
    msg_dir = state.messages_dir("group-123")
    assert (msg_dir / "outside.md").exists()

    # Verify index entry
    import json
    index = json.loads((msg_dir / "index.json").read_text())
    assert any(e["type"] == "send" and e["file"] == "outside.md" for e in index)


def test_supervisor_send_file_already_in_messages_dir_no_warning(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    monkeypatch.setattr(
        "keep._cli.helpers.resolve_worker",
        lambda session, terminal_type=None: SimpleNamespace(
            session=session, running=True, pid=1, target_id="surface-1", jsonl_path=Path("/tmp/x.jsonl"),
        ),
    )
    monkeypatch.setattr(
        "keep._cli.helpers.worker_cache_from_info",
        lambda info: {"pid": info.pid, "target_id": info.target_id, "jsonl_path": str(info.jsonl_path)},
    )

    sent: list[tuple[str, str]] = []
    monkeypatch.setattr(
        "keep.terminal._factory",
        lambda terminal_type: SimpleNamespace(
            send_text=lambda surface, text: sent.append((surface, text)),
            send_key=lambda *a, **k: None,
            close=lambda *a, **k: None,
        ),
    )

    # File already in messages/
    msg_dir = state.messages_dir("group-123")
    msg_file = msg_dir / "task-30.md"
    msg_file.write_text("already in inbox")

    result = runner.invoke(app, ["group-123", "supervisor", "send", W1, str(msg_file)])
    assert result.exit_code == 0
    assert "Warning" not in result.stderr
    assert sent == [("surface-1", "already in inbox")]


def test_task_create_help_does_not_create_task(isolated_state: Path) -> None:
    state.create_group("group-123")

    result = runner.invoke(app, ["group-123", "task", "create", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <group_id> task create" in result.stdout

    tasks = state.list_tasks("group-123")
    assert tasks == []


def test_task_update_help_is_supported(isolated_state: Path) -> None:
    state.create_group("group-123")

    result = runner.invoke(app, ["group-123", "task", "update", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <group_id> task update" in result.stdout


def test_supervisor_send_help_does_not_send_message(isolated_state: Path) -> None:
    _create_active_group("group-123")
    state.add_worker("group-123", W1, cache={"target_id": "surface-1"})

    result = runner.invoke(app, ["group-123", "supervisor", "send", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <group_id> supervisor send" in result.stdout


def test_supervisor_read_help_is_supported(isolated_state: Path) -> None:
    state.create_group("group-123")

    result = runner.invoke(app, ["group-123", "supervisor", "read", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <group_id> supervisor read" in result.stdout


def test_supervisor_kick_help_is_supported(isolated_state: Path) -> None:
    _create_active_group("group-123")

    result = runner.invoke(app, ["group-123", "supervisor", "wake", "-h"])
    assert result.exit_code == 0
    assert "Usage: keep <group_id> supervisor wake" in result.stdout


def test_task_update_rejects_removed_and_accepts_deleted(isolated_state: Path) -> None:
    _create_active_group("group-123")
    runner.invoke(app, ["group-123", "task", "create", "first-task"])

    removed_result = runner.invoke(
        app,
        ["group-123", "task", "update", "--tasks", "1", "--status", "removed"],
    )
    assert removed_result.exit_code == 2
    assert "Invalid --status" in removed_result.stderr

    deleted_result = runner.invoke(
        app,
        ["group-123", "task", "update", "--tasks", "1", "--status", "deleted"],
    )
    assert deleted_result.exit_code == 0
    task = state.get_task("group-123", "1")
    assert task is not None
    assert task["status"] == "deleted"


@pytest.mark.parametrize("action", ["pass", "reject", "submit"])
def test_reviewer_verdict_cli_is_deprecated(isolated_state: Path, action: str) -> None:
    state.create_group("group-123")
    state.add_user("group-123", "sess-1", role="reviewer", name="rev")
    result = runner.invoke(app, ["group-123", "reviewer", "re1", action, "--round", "1"])
    assert result.exit_code == 1
    assert "reviewer verdict CLI 已废弃" in result.stderr


def test_supervisor_show_uses_supervisor_env_when_id_is_omitted(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    state.create_group("group-123")
    state.add_supervisor("group-123", S1, name="sup")
    monkeypatch.setenv("KEEP_GROUP_ID", "group-123")
    monkeypatch.setenv("KEEP_USER_SESSION", S1)

    result = runner.invoke(app, ["group-123", "supervisor", "show"])

    assert result.exit_code == 0
    assert S1 in result.stdout


def test_reviewer_verdict_deprecated_without_registered_reviewers(isolated_state: Path) -> None:
    state.create_group("group-123")
    result = runner.invoke(app, ["group-123", "reviewer", "re1", "pass", "--round", "1"])
    assert result.exit_code == 1
    assert "reviewer verdict CLI 已废弃" in result.stderr


def test_group_stop_submits_request_and_returns_immediately(
    isolated_state: Path,
    tmp_path: Path,
) -> None:
    from keep.daemon import group_stop_signal_file

    _create_active_group("group-123")
    state.add_user("group-123", "sess-1", role="reviewer", name="rev", triggers=["group_stop"])
    rationale_file = tmp_path / "stop.md"
    rationale_file.write_text("stop now", encoding="utf-8")

    result = runner.invoke(
        app,
        ["group", "stop", "group-123", "--rationale", str(rationale_file)],
    )

    assert result.exit_code == 0
    assert "你无权直接停止 group 'group-123'" in result.stdout
    queued_rationale = group_stop_signal_file("group-123").read_text(encoding="utf-8")
    assert queued_rationale != str(rationale_file)
    assert Path(queued_rationale).exists()
    assert state.load_group("group-123")["status"] == "active"
    assert state.load_group("group-123")["review_events"] == []


def test_reviewer_can_submit_group_stop_decision_via_group_stop(
    isolated_state: Path,
    tmp_path: Path,
) -> None:
    _create_active_group("group-123")
    reviewer_id = "sess-reviewer"
    state.add_user("group-123", reviewer_id, role="reviewer", name="rev", triggers=["group_stop"])
    state.add_review_event(
        "group-123",
        {
            "type": "group_stop",
            "user_resource_states": {},
        },
    )
    os.environ["KEEP_GROUP_ID"] = "group-123"
    os.environ["KEEP_USER_SESSION"] = reviewer_id

    rationale_file = tmp_path / "keep-active.md"
    rationale_file.write_text("not done yet", encoding="utf-8")
    result = runner.invoke(
        app,
        [
            "group",
            "stop",
            "group-123",
            "--status",
            "active",
            "--rationale",
            str(rationale_file),
        ],
    )

    assert result.exit_code == 0
    assert "审批已记录" in result.stdout
    event = state.get_review_event("group-123", "re1")
    assert event["user_resource_states"] == {reviewer_id: {"group": "active"}}


def test_reviewer_can_submit_group_stop_without_rationale_file(
    isolated_state: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _create_active_group("group-123")
    reviewer_id = "sess-reviewer-lastmsg"
    state.add_user("group-123", reviewer_id, role="reviewer", name="rev", triggers=["group_stop"])
    state.add_review_event(
        "group-123",
        {
            "type": "group_stop",
            "user_resource_states": {},
        },
    )
    os.environ["KEEP_GROUP_ID"] = "group-123"
    os.environ["KEEP_USER_SESSION"] = reviewer_id
    monkeypatch.setattr(
        "keep.cli.persist_user_last_message",
        lambda group_id, user, event_type="user_note": "/tmp/reviewer-group-last-message.txt",
    )

    result = runner.invoke(
        app,
        [
            "group",
            "stop",
            "group-123",
            "--status",
            "active",
        ],
    )

    assert result.exit_code == 0
    event = state.get_review_event("group-123", "re1")
    assert event["user_resource_states"] == {reviewer_id: {"group": "active"}}
    assert event["user_rationales"][reviewer_id] == "/tmp/reviewer-group-last-message.txt"


def test_group_stop_rejects_duplicate_open_request(
    isolated_state: Path,
) -> None:
    _create_active_group("group-123")
    state.add_user("group-123", "sess-1", role="reviewer", name="rev", triggers=["group_stop"])
    state.add_review_event(
        "group-123",
        {
            "type": "group_stop",
            "user_resource_states": {},
        },
    )

    result = runner.invoke(app, ["group", "stop", "group-123"])

    assert result.exit_code == 1
    assert "已有未结算的 group stop 审批" in result.stderr


def test_group_stop_request_rejected_when_group_is_paused(
    isolated_state: Path,
) -> None:
    _create_active_group("group-123")
    group = state.load_group("group-123")
    assert group is not None
    group["status"] = "paused"
    state.save_group("group-123", group)
    state.add_user("group-123", "sess-1", role="reviewer", name="rev", triggers=["group_stop"])

    result = runner.invoke(app, ["group", "stop", "group-123"])

    assert result.exit_code == 1
    assert "已暂停" in result.stderr


@pytest.mark.parametrize(
    ("command", "args"),
    [
        ("create", ["new-task"]),
        ("update", ["--tasks", "1", "--subject", "changed"]),
    ],
)
def test_task_mutations_cancel_pending_group_stop(
    isolated_state: Path,
    command: str,
    args: list[str],
) -> None:
    from keep._daemon import runtime_state

    _create_active_group("group-123")
    state.create_task("group-123", subject="existing-task")
    state.add_review_event(
        "group-123",
        {
            "type": "group_stop",
            "user_resource_states": {},
        },
    )
    runtime_state.pending_stop_event["group-123"] = "re1"
    runtime_state.save()

    result = runner.invoke(app, ["group-123", "task", command, *args])
    assert result.exit_code == 0
    event = state.get_review_event("group-123", "re1")
    assert event["final_verdict"] == "cancelled"


# ── cross-role hint on resolve_session_id_by_prefix_or_fail ───────
from keep._cli.helpers import resolve_session_id_by_prefix_or_fail  # noqa: E402
import typer as _typer  # noqa: E402


def _group_with(*users: dict) -> dict:
    return {"name": "m", "users": list(users)}


def test_resolve_role_mismatch_full_supervisor_uuid_as_worker_emits_hint(
    capsys: pytest.CaptureFixture[str],
) -> None:
    group = _group_with(
        {"role": "supervisor", "session": S1},
    )
    with pytest.raises(_typer.Exit) as exc:
        resolve_session_id_by_prefix_or_fail(
            group=group, role="worker", raw_id=S1, id_label="worker_id",
        )
    assert exc.value.exit_code == 1
    captured = capsys.readouterr()
    assert f"worker_id '{S1}' 不存在" in captured.err
    assert "supervisor" in captured.err
    assert f"session={S1[:8]}" in captured.err
    assert "不是 worker" in captured.err
    assert "supervisor send 是 supervisor 单向向 worker 发消息的工具。" in captured.err


def test_resolve_role_mismatch_prefix_matches_only_supervisor_emits_hint(
    capsys: pytest.CaptureFixture[str],
) -> None:
    group = _group_with(
        {"role": "supervisor", "session": S1},
        {"role": "worker", "session": W1},
    )
    # S1 starts with "22222222"; this prefix only matches the supervisor.
    prefix = "22222222"
    with pytest.raises(_typer.Exit) as exc:
        resolve_session_id_by_prefix_or_fail(
            group=group, role="worker", raw_id=prefix, id_label="worker_id",
        )
    assert exc.value.exit_code == 1
    captured = capsys.readouterr()
    assert f"worker_id '{prefix}' 不存在" in captured.err
    assert "属于 group 'm' 的 supervisor" in captured.err
    assert f"session={S1[:8]}" in captured.err
    assert "supervisor send 是 supervisor 单向向 worker 发消息的工具。" in captured.err


def test_resolve_unknown_id_falls_back_to_generic_error(
    capsys: pytest.CaptureFixture[str],
) -> None:
    group = _group_with(
        {"role": "supervisor", "session": S1},
        {"role": "worker", "session": W1},
    )
    unknown = "99999999-9999-4999-8999-999999999999"
    with pytest.raises(_typer.Exit) as exc:
        resolve_session_id_by_prefix_or_fail(
            group=group, role="worker", raw_id=unknown, id_label="worker_id",
        )
    assert exc.value.exit_code == 1
    captured = capsys.readouterr()
    assert captured.err.strip() == f"worker_id '{unknown}' 不存在"
    # No cross-role hint must appear
    assert "属于 group" not in captured.err
    assert "supervisor send 是" not in captured.err


def test_resolve_prefix_ambiguous_across_roles_worker_wins_without_hint() -> None:
    # Pick worker + supervisor that share the first 4 hex chars.
    worker_shared = "abcd1111-1111-4111-8111-111111111111"
    sup_shared = "abcd2222-2222-4222-8222-222222222222"
    group = _group_with(
        {"role": "worker", "session": worker_shared},
        {"role": "supervisor", "session": sup_shared},
    )
    # Prefix "abcd" matches both roles, but only the worker match is considered
    # inside the requested role (there's exactly one worker with this prefix).
    resolved = resolve_session_id_by_prefix_or_fail(
        group=group, role="worker", raw_id="abcd", id_label="worker_id",
    )
    assert resolved == worker_shared


def test_resolve_supervisor_lookup_with_worker_id_emits_first_line_only(
    capsys: pytest.CaptureFixture[str],
) -> None:
    group = _group_with(
        {"role": "supervisor", "session": S1},
        {"role": "worker", "session": W1},
    )
    with pytest.raises(_typer.Exit) as exc:
        resolve_session_id_by_prefix_or_fail(
            group=group, role="supervisor", raw_id=W1, id_label="supervisor_id",
        )
    assert exc.value.exit_code == 1
    captured = capsys.readouterr()
    assert f"supervisor_id '{W1}' 不存在" in captured.err
    assert "属于 group 'm' 的 worker" in captured.err
    assert f"session={W1[:8]}" in captured.err
    assert "不是 supervisor" in captured.err
    # The second, worker-specific hint must NOT appear
    assert "supervisor send 是 supervisor 单向向 worker 发消息的工具" not in captured.err
