from __future__ import annotations

import pytest

from keep._daemon import loop
from keep.daemon import group_sync_signal_file
from keep import state


def test_run_daemon_exits_on_fatal_group_error(monkeypatch):
    monkeypatch.setattr(loop, "_startup", lambda: None)
    monkeypatch.setattr(loop, "_install_signal_handlers", lambda: None)
    monkeypatch.setattr(loop, "load_global", lambda: {"daemon_pid": 1, "stopped": False})
    monkeypatch.setattr(loop, "list_groups", lambda: ["m1"])
    monkeypatch.setattr(loop, "_tick_group", lambda group_name: (_ for _ in ()).throw(ValueError("bad group")))
    monkeypatch.setattr(loop.time, "sleep", lambda seconds: None)

    with pytest.raises(ValueError):
        loop.run_daemon()


def test_tick_group_consumes_group_sync_even_when_group_stopped(monkeypatch):
    state.save_global(state.new_global())
    group = state.create_group("m-sync-stopped")
    group["status"] = "stopped"
    state.save_group("m-sync-stopped", group)
    group_sync_signal_file("m-sync-stopped").write_text("", encoding="utf-8")

    calls: list[str] = []
    monkeypatch.setattr(loop, "check_group_sync_signal", lambda group_name, group: calls.append(group_name))

    loop._tick_group("m-sync-stopped")

    assert calls == ["m-sync-stopped"]


def test_tick_group_consumes_group_sync_without_supervisor(monkeypatch):
    state.save_global(state.new_global())
    group = state.create_group("m-sync-unclaimed")
    group["status"] = "active"
    state.save_group("m-sync-unclaimed", group)
    group_sync_signal_file("m-sync-unclaimed").write_text("", encoding="utf-8")

    calls: list[str] = []
    monkeypatch.setattr(loop, "check_group_sync_signal", lambda group_name, group: calls.append(group_name))
    monkeypatch.setattr(loop, "find_supervisor", lambda group: None)

    loop._tick_group("m-sync-unclaimed")

    assert calls == ["m-sync-unclaimed"]
