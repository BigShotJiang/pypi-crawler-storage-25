from __future__ import annotations

from pathlib import Path

from keep.agent import AgentMessage
from keep.agents.codex import CodexAgent


_ASSISTANT_TEXT = "当前目录是 /tmp/demo。"
_AGENT_EVENT_TEXT = "等待下一步指令。"


def test_last_message_reads_latest_assistant_response_item(tmp_path: Path) -> None:
    path = tmp_path / "rollout-abc.jsonl"
    path.write_text(
        "\n".join(
            [
                '{"timestamp":"2026-04-22T06:28:29.496Z","type":"session_meta","payload":{"id":"abc"}}',
                '{"timestamp":"2026-04-22T06:29:31.758Z","type":"response_item","payload":{"type":"message","role":"assistant","content":[{"type":"output_text","text":"'
                + _ASSISTANT_TEXT
                + '"}]}}',
                '{"timestamp":"2026-04-22T06:29:37.836Z","type":"event_msg","payload":{"type":"agent_message","message":"'
                + _AGENT_EVENT_TEXT
                + '"}}',
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    msg = CodexAgent().last_message("ignored", jsonl_path=path)

    assert isinstance(msg, AgentMessage)
    assert msg is not None
    assert msg.text == _AGENT_EVENT_TEXT
    assert msg.ts == "2026-04-22T06:29:37.836Z"


def test_last_message_skips_malformed_lines_and_returns_none_for_missing(tmp_path: Path) -> None:
    missing = tmp_path / "missing.jsonl"
    assert CodexAgent().last_message("ignored", jsonl_path=missing) is None

    dirty = tmp_path / "dirty.jsonl"
    dirty.write_text(
        "{ not-json\n"
        '{"timestamp":"2026-04-22T06:29:31.758Z","type":"response_item","payload":{"type":"message","role":"assistant","content":[{"type":"output_text","text":"ok"}]}}'
        "\n",
        encoding="utf-8",
    )

    msg = CodexAgent().last_message("ignored", jsonl_path=dirty)
    assert msg is not None
    assert msg.text == "ok"


def test_last_message_accepts_string_path() -> None:
    path = Path("/tmp/codex-agent-string-path.jsonl")
    try:
        path.write_text(
            '{"timestamp":"2026-04-22T06:29:31.758Z","type":"response_item","payload":{"type":"message","role":"assistant","content":[{"type":"output_text","text":"string path ok"}]}}\n',
            encoding="utf-8",
        )
        msg = CodexAgent().last_message("ignored", jsonl_path=str(path))
        assert msg is not None
        assert msg.text == "string path ok"
    finally:
        path.unlink(missing_ok=True)
