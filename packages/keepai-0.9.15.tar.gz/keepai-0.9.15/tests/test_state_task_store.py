from pathlib import Path

import pytest

from keep import state


@pytest.fixture
def isolated_state(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    state_dir = tmp_path / "state"
    (state_dir / "missions").mkdir(parents=True)
    (state_dir / "keep_id" / "tasks").mkdir(parents=True)
    monkeypatch.setenv("KEEP_HOME", str(state_dir))
    return state_dir


def test_task_store_dir_is_per_group(isolated_state: Path) -> None:
    task_dir = state.task_store_dir("group-1")
    assert task_dir == isolated_state / "keep_id" / "tasks" / "group-1"


def test_create_task_initializes_lock_highwatermark_and_first_task(isolated_state: Path) -> None:
    task = state.create_task("group-1", subject="first task")
    task_dir = state.task_store_dir("group-1")

    assert task["id"] == "1"
    assert task["subject"] == "first task"
    assert task["description"] == ""
    assert task["status"] == "proposed"
    assert task["owner"] == ""
    assert task["blocks"] == []
    assert task["blockedBy"] == []
    assert (task_dir / ".lock").exists()
    assert (task_dir / ".highwatermark").read_text(encoding="utf-8").strip() == "1"
    assert (task_dir / "1.json").exists()


def test_create_task_increments_highwatermark(isolated_state: Path) -> None:
    first = state.create_task("group-1", subject="one")
    second = state.create_task("group-1", subject="two")

    assert first["id"] == "1"
    assert second["id"] == "2"
    assert state.highwatermark_file("group-1").read_text(encoding="utf-8").strip() == "2"


def test_create_task_recovers_when_highwatermark_lags_existing_tasks(isolated_state: Path) -> None:
    state.create_task("group-1", subject="one")
    state.create_task("group-1", subject="two")
    state.create_task("group-1", subject="three")

    state.highwatermark_file("group-1").write_text("1", encoding="utf-8")

    created = state.create_task("group-1", subject="four")

    assert created["id"] == "4"
    assert state.get_task("group-1", "1")["subject"] == "one"
    assert state.get_task("group-1", "2")["subject"] == "two"
    assert state.get_task("group-1", "3")["subject"] == "three"
    assert state.get_task("group-1", "4")["subject"] == "four"
    assert state.highwatermark_file("group-1").read_text(encoding="utf-8").strip() == "4"


def test_create_task_recovers_when_highwatermark_is_missing(isolated_state: Path) -> None:
    task_dir = state.task_store_dir("group-1")
    task_dir.mkdir(parents=True, exist_ok=True)
    for task_id, subject in (("1", "one"), ("3", "three")):
        state.task_file("group-1", task_id).write_text(
            (
                "{\n"
                f'  "id": "{task_id}",\n'
                f'  "subject": "{subject}",\n'
                '  "description": "",\n'
                '  "status": "completed",\n'
                '  "owner": "",\n'
                '  "blocks": [],\n'
                '  "blockedBy": []\n'
                "}\n"
            ),
            encoding="utf-8",
        )
    state.highwatermark_file("group-1").unlink(missing_ok=True)

    created = state.create_task("group-1", subject="four")

    assert created["id"] == "4"
    assert state.get_task("group-1", "1")["subject"] == "one"
    assert state.get_task("group-1", "3")["subject"] == "three"
    assert state.get_task("group-1", "4")["subject"] == "four"
    assert state.highwatermark_file("group-1").read_text(encoding="utf-8").strip() == "4"


def test_list_tasks_returns_id_order(isolated_state: Path) -> None:
    state.create_task("group-1", subject="one")
    state.create_task("group-1", subject="two")
    tasks = state.list_tasks("group-1")
    assert [task["id"] for task in tasks] == ["1", "2"]


def test_update_task_supports_task_fields_only(isolated_state: Path) -> None:
    state.create_task("group-1", subject="one")
    updated = state.update_task(
        "group-1",
        "1",
        {
            "description": "desc",
            "status": "in_progress",
            "owner": "supervisor-1",
            "blocks": ["2"],
            "blockedBy": ["3"],
        },
    )
    assert updated["description"] == "desc"
    assert updated["status"] == "in_progress"
    assert updated["owner"] == "supervisor-1"
    assert updated["blocks"] == ["2"]
    assert updated["blockedBy"] == ["3"]


def test_remove_task_deletes_task_file(isolated_state: Path) -> None:
    state.create_task("group-1", subject="one")
    assert state.remove_task("group-1", "1") is True
    assert not (state.task_store_dir("group-1") / "1.json").exists()


def test_group_state_no_longer_embeds_plans() -> None:
    group = state.new_group("group-1")
    assert "plans" not in group
    assert "next_plan_id" not in group
