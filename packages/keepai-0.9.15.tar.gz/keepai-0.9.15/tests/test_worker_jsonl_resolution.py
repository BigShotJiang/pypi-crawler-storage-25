from __future__ import annotations

from pathlib import Path

from keep import worker


def test_find_jsonl_searches_current_claude_config_env(tmp_path: Path, monkeypatch):
    env_root = tmp_path / "envs" / "api" / ".claude" / "projects" / "proj"
    env_root.mkdir(parents=True)
    jsonl = env_root / "session.jsonl"
    jsonl.write_text(
        '{"type":"custom-title","customTitle":"runtime-smoke-worker-2"}\n',
        encoding="utf-8",
    )

    monkeypatch.setenv("CLAUDE_CONFIG_DIR", str(tmp_path / "envs" / "api" / ".claude"))
    monkeypatch.setattr(worker.Path, "home", classmethod(lambda cls: tmp_path))

    result = worker._find_jsonl("runtime-smoke-worker-2")

    assert result.path == jsonl
