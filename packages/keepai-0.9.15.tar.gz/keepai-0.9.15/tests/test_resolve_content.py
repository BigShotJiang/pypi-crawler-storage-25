"""Tests for keep.state.resolve_content.

Regression coverage for the ENAMETOOLONG bug in CPython 3.12 on macOS:
`Path.is_file()` does not catch errno 63 from stat(), so long inline
content passed to `resolve_content` used to bubble up OSError.
"""

from pathlib import Path

from keep.state import resolve_content


def test_empty_input() -> None:
    assert resolve_content(None) == ""
    assert resolve_content("") == ""


def test_short_text_non_path() -> None:
    # Short string not matching any file — returned as-is
    assert resolve_content("not-a-real-path-xyz") == "not-a-real-path-xyz"


def test_existing_file_is_read(tmp_path: Path) -> None:
    f = tmp_path / "plan.md"
    f.write_text("file content here")
    assert resolve_content(str(f)) == "file content here"


def test_long_ascii_inline_text() -> None:
    # 500 bytes of ASCII, single component, no slash → triggers ENAMETOOLONG
    # on CPython 3.12 macOS. Must return the raw text, not raise.
    long_text = "x" * 500
    assert resolve_content(long_text) == long_text


def test_long_multibyte_inline_text() -> None:
    # Real-world scenario: inline plan content with Chinese (3 bytes/char)
    # and slashes, where one component's byte length exceeds NAME_MAX=255.
    long_text = "目标：给 mation 加功能。" * 80 + "/结尾"
    assert resolve_content(long_text) == long_text


def test_path_with_newlines_treated_as_text() -> None:
    # Multiline content is never a file path; return as-is.
    text = "line 1\nline 2\nline 3"
    assert resolve_content(text) == text
