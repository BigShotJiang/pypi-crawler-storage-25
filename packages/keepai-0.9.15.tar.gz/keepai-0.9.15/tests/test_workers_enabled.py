"""Tests for keep defaults / group overrides / idle detection.

Covers:
  - Global config read/write (keep._state.config)
  - is_workers_enabled resolver (global/group/default)
  - Daemon check_idle skips for workers_enabled=true
  - Daemon check_idle sends group_idle notification for workers_enabled=false
  - CLI: keep self config show/update
  - CLI: keep group create snapshots keep defaults
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import pytest
from typer.testing import CliRunner

from keep.cli import app
from keep._state.config import (
    get_global_config,
    is_workers_enabled,
    set_global_config,
    workers_enabled_global,
)
from keep.state import (
    create_group,
    load_group,
    mutate_group,
    new_global,
    save_global,
)


runner = CliRunner()


# ── Fixtures ────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def _isolate_keep_home(tmp_path, monkeypatch):
    """Give each test its own KEEP_HOME so config/group state is isolated."""
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    yield


@pytest.fixture
def _global_state(tmp_path, monkeypatch):
    """Create a minimal global.json so CLI commands that call require_global() pass."""
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    gs = new_global()
    save_global(gs)
    return gs


# ── Global config read/write ─────────────────────────────────────


def test_get_global_config_absent_returns_empty():
    assert get_global_config() == {}


def test_workers_enabled_global_default_is_true():
    assert workers_enabled_global() is True


def test_set_and_get_workers_enabled_false():
    set_global_config("workers_enabled", False)
    assert workers_enabled_global() is False


def test_set_and_get_workers_enabled_true_explicit():
    set_global_config("workers_enabled", True)
    assert workers_enabled_global() is True


def test_set_global_config_writes_json(tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    set_global_config("workers_enabled", False)
    config_file = tmp_path / "config.json"
    assert config_file.exists()
    data = json.loads(config_file.read_text())
    assert data["workers_enabled"] is False


def test_set_global_config_preserves_other_keys(tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    set_global_config("other_key", "hello")
    set_global_config("workers_enabled", False)
    config = get_global_config()
    assert config["other_key"] == "hello"
    assert config["workers_enabled"] is False


def test_get_global_config_reloads_when_file_changes_externally(tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    config_file = tmp_path / "config.json"
    config_file.write_text('{"workers_enabled": true}', encoding="utf-8")
    assert get_global_config()["workers_enabled"] is True

    config_file.write_text('{"workers_enabled": false}', encoding="utf-8")
    # Force a different mtime so the cache cannot accidentally look fresh.
    newer = config_file.stat().st_mtime + 1
    import os
    os.utime(config_file, (newer, newer))

    assert get_global_config()["workers_enabled"] is False


# ── is_workers_enabled resolver ──────────────────────────────────


def test_is_workers_enabled_default_true_no_config():
    create_group("testm")
    assert is_workers_enabled("testm") is True


def test_is_workers_enabled_global_false_propagates():
    set_global_config("workers_enabled", False)
    create_group("testm")
    assert is_workers_enabled("testm") is False


def test_is_workers_enabled_group_overrides_global_false():
    set_global_config("workers_enabled", False)
    create_group("testm", workers_enabled=True)
    assert is_workers_enabled("testm") is True


def test_is_workers_enabled_group_overrides_global_true():
    # global default is True, group says False
    create_group("testm", workers_enabled=False)
    assert is_workers_enabled("testm") is False


def test_is_workers_enabled_group_none_uses_global():
    # group has no workers_enabled field → falls through to global
    set_global_config("workers_enabled", False)
    create_group("testm")
    # Verify the group actually has no workers_enabled field
    m = load_group("testm")
    assert "workers_enabled" not in m
    assert is_workers_enabled("testm") is False


def test_is_workers_enabled_group_explicit_none_uses_global():
    # Passing workers_enabled=None to create_group → absent from JSON
    create_group("testm", workers_enabled=None)
    m = load_group("testm")
    assert "workers_enabled" not in m
    assert is_workers_enabled("testm") is True  # global default


# ── Group create with workers_enabled field ────────────────────


def test_create_group_workers_enabled_false_persists():
    create_group("testm", workers_enabled=False)
    m = load_group("testm")
    assert m["workers_enabled"] is False


def test_create_group_workers_enabled_true_persists():
    create_group("testm", workers_enabled=True)
    m = load_group("testm")
    assert m["workers_enabled"] is True


def test_create_group_workers_enabled_absent_by_default():
    create_group("testm")
    m = load_group("testm")
    assert "workers_enabled" not in m


# ── Daemon check_idle behavior ───────────────────────────────────


def _make_group(
    group_name: str,
    jsonl_path: str | None = None,
    workers_enabled: bool | None = None,
) -> dict[str, Any]:
    """Build a minimal group dict with a supervisor user."""
    cache: dict[str, Any] = {}
    if jsonl_path:
        cache["jsonl_path"] = jsonl_path
    d: dict[str, Any] = {
        "name": group_name,
        "status": "active",
        "users": [
            {
                "session": "sup-session-1",
                "role": "supervisor",
                "kind": "agent",
                "cache": cache,
            }
        ],
    }
    if workers_enabled is not None:
        d["workers_enabled"] = workers_enabled
    return d


@pytest.fixture
def _clear_idle_runtime():
    from keep._daemon import runtime_state
    runtime_state.idle_since.clear()
    runtime_state.idle_fired.clear()
    yield
    runtime_state.idle_since.clear()
    runtime_state.idle_fired.clear()


def test_check_idle_skips_when_workers_enabled_true(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """When workers_enabled=true, check_idle is a no-op."""
    # Create group with workers_enabled=True (default)
    create_group("testm")

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _group, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    group = _make_group("testm")
    check_idle("testm", group)

    assert notifications == [], "check_idle should be a no-op for workers_enabled=true"


def test_check_idle_skips_when_no_supervisor(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """When workers_enabled=false but no supervisor, check_idle does nothing."""
    create_group("testm", workers_enabled=False)

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _group, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    group = {
        "name": "testm",
        "status": "active",
        "workers_enabled": False,
        "users": [],
    }
    check_idle("testm", group)

    assert notifications == []


def test_check_idle_skips_when_no_jsonl_path(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """Supervisor exists but has no jsonl_path → no idle detection."""
    create_group("testm", workers_enabled=False)

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _group, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    group = _make_group("testm", jsonl_path=None, workers_enabled=False)
    check_idle("testm", group)

    assert notifications == []


def test_check_idle_no_notification_when_jsonl_fresh(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """Fresh JSONL (just written) → no group_idle notification."""
    create_group("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text('{"type": "assistant"}', encoding="utf-8")
    # mtime is "now", so age < IDLE_TIMEOUT

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _group, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    group = _make_group("testm", jsonl_path=str(jsonl), workers_enabled=False)
    check_idle("testm", group)

    assert notifications == []


def test_check_idle_sends_notification_when_jsonl_stale(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """JSONL older than IDLE_TIMEOUT → group_idle notification sent to supervisor."""
    from keep._daemon.constants import IDLE_TIMEOUT
    from keep._daemon import runtime_state

    create_group("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text('{"type": "assistant"}', encoding="utf-8")

    # Set mtime to IDLE_TIMEOUT + 10 seconds ago
    stale_time = time.time() - IDLE_TIMEOUT - 10
    import os
    os.utime(jsonl, (stale_time, stale_time))

    # Pre-seed idle_since so the "start timer" path is already past
    runtime_state.idle_since["testm"] = stale_time - IDLE_TIMEOUT
    runtime_state.save()

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _group, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    group = _make_group("testm", jsonl_path=str(jsonl), workers_enabled=False)
    check_idle("testm", group)

    assert len(notifications) == 1, "Expected exactly one group_idle notification"
    msg = notifications[0]
    assert 'event="group_idle"' in msg
    assert "testm" in msg
    assert 'role="supervisor"' in msg


def test_check_idle_notification_is_valid_xml(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """group_idle notification is well-formed XML."""
    from xml.etree import ElementTree
    from keep._daemon.constants import IDLE_TIMEOUT
    from keep._daemon import runtime_state

    create_group("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text("{}", encoding="utf-8")

    stale_time = time.time() - IDLE_TIMEOUT - 10
    import os
    os.utime(jsonl, (stale_time, stale_time))

    runtime_state.idle_since["testm"] = stale_time - IDLE_TIMEOUT
    runtime_state.save()

    notifications: list[str] = []
    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda _group, msg: notifications.append(msg),
    )

    from keep._daemon.idle import check_idle
    group = _make_group("testm", jsonl_path=str(jsonl), workers_enabled=False)
    check_idle("testm", group)

    assert notifications
    root = ElementTree.fromstring(notifications[0])
    assert root.tag == "keep"
    assert root.attrib["event"] == "group_idle"
    assert root.attrib["group"] == "testm"


def test_check_idle_resets_after_notification(
    tmp_path, monkeypatch, _clear_idle_runtime,
):
    """After sending the notification, idle tracking is reset."""
    from keep._daemon.constants import IDLE_TIMEOUT
    from keep._daemon import runtime_state

    create_group("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text("{}", encoding="utf-8")

    stale_time = time.time() - IDLE_TIMEOUT - 10
    import os
    os.utime(jsonl, (stale_time, stale_time))

    runtime_state.idle_since["testm"] = stale_time - IDLE_TIMEOUT
    runtime_state.save()

    monkeypatch.setattr(
        "keep._daemon.idle.notify_supervisor",
        lambda *a: None,
    )

    from keep._daemon.idle import check_idle
    group = _make_group("testm", jsonl_path=str(jsonl), workers_enabled=False)
    check_idle("testm", group)

    # After notification, idle_since should be cleared and idle_fired should be clear
    assert "testm" not in runtime_state.idle_since
    assert "testm" not in runtime_state.idle_fired


# ── CLI: keep self config ────────────────────────────────────────


def test_cli_root_config_command_is_removed(_global_state):
    result = runner.invoke(app, ["config", "get", "workers_enabled"])
    assert result.exit_code == 2
    assert "No such command 'config'" in result.stderr


def test_cli_self_config_shows_effective_defaults(_global_state):
    result = runner.invoke(app, ["self", "config"])
    assert result.exit_code == 0
    assert "Default Terminal: cmux" in result.stdout
    assert "Default Agent: claude-code" in result.stdout
    assert "Workers Enabled: true" in result.stdout


def test_cli_self_config_sets_workers_enabled_false(_global_state):
    result = runner.invoke(app, ["self", "config", "--workers-enabled", "false"])
    assert result.exit_code == 0
    assert "Workers Enabled: false" in result.stdout

    config = get_global_config()
    assert config["workers_enabled"] is False


def test_cli_self_config_sets_terminal_and_agent(_global_state):
    result = runner.invoke(app, ["self", "config", "--terminal", "tmux", "--agent", "codex"])
    assert result.exit_code == 0
    assert "Default Terminal: tmux" in result.stdout
    assert "Default Agent: codex" in result.stdout

    config = get_global_config()
    assert config["default_terminal"] == "tmux"
    assert config["default_agent"] == "codex"


def test_cli_self_config_rejects_invalid_agent(_global_state):
    result = runner.invoke(app, ["self", "config", "--agent", "unknown-agent"])
    assert result.exit_code == 1


def test_cli_self_config_rejects_invalid_workers_enabled(_global_state):
    result = runner.invoke(app, ["self", "config", "--workers-enabled", "maybe"])
    assert result.exit_code == 1


# ── CLI: keep group create --no-workers ──────────────────────────


def test_cli_group_create_no_workers_flag(_global_state):
    result = runner.invoke(app, ["group", "create", "--no-workers"])
    assert result.exit_code == 0
    assert "workers_enabled=false" in result.output


def test_cli_group_create_no_workers_sets_field(_global_state, tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    # Need global state in the new tmp_path
    gs = new_global()
    save_global(gs)

    result = runner.invoke(app, ["group", "create", "--no-workers"])
    assert result.exit_code == 0

    # Find the group name from output
    output = result.output.strip()
    # Output: "Group '<id>' 已创建。..."
    import re
    m = re.search(r"Group '([^']+)'", output)
    assert m, f"Could not find group name in output: {output!r}"
    group_name = m.group(1)

    group = load_group(group_name)
    assert group is not None
    assert group.get("workers_enabled") is False


def test_cli_group_create_default_no_workers_field(_global_state, tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    gs = new_global()
    save_global(gs)

    result = runner.invoke(app, ["group", "create"])
    assert result.exit_code == 0
    assert "workers_enabled=false" not in result.output

    import re
    m = re.search(r"Group '([^']+)'", result.output)
    assert m
    group_name = m.group(1)

    group = load_group(group_name)
    assert group is not None
    assert group["workers_enabled"] is True
    assert group["default_agent"] == "claude-code"


def test_cli_group_create_snapshots_keep_defaults(_global_state, tmp_path, monkeypatch):
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    gs = new_global()
    save_global(gs)

    set_result = runner.invoke(
        app,
        ["self", "config", "--terminal", "tmux", "--agent", "codex", "--workers-enabled", "false"],
    )
    assert set_result.exit_code == 0

    result = runner.invoke(app, ["group", "create"])
    assert result.exit_code == 0
    assert "terminal: tmux" in result.output
    assert "agent: codex" in result.output
    assert "workers_enabled=false" in result.output

    import re
    m = re.search(r"Group '([^']+)'", result.output)
    assert m
    group = load_group(m.group(1))
    assert group is not None
    assert group["terminal_type"] == "tmux"
    assert group["default_agent"] == "codex"
    assert group["workers_enabled"] is False


# ── CR-004: additional unit tests ───────────────────────────────────


def test_jsonl_age_missing_file():
    from keep._daemon.worker_check import jsonl_age
    user = {
        "session": "s1",
        "role": "worker",
        "kind": "agent",
        "cache": {"jsonl_path": "/nonexistent/path/sup.jsonl"},
    }
    result = jsonl_age(user, time.time())
    assert result is None


def test_is_workers_enabled_string_false_treated_as_disabled():
    """String 'false' in group JSON must not be truthy."""
    create_group("testm")
    with mutate_group("testm") as m:
        m["workers_enabled"] = "false"
    assert is_workers_enabled("testm") is False


def test_is_workers_enabled_string_true_treated_as_enabled():
    create_group("testm")
    with mutate_group("testm") as m:
        m["workers_enabled"] = "true"
    assert is_workers_enabled("testm") is True


def test_check_idle_renotifies_after_second_timeout(tmp_path, monkeypatch, _clear_idle_runtime):
    """After reset, a second IDLE_TIMEOUT of silence fires a second notification."""
    from keep._daemon.constants import IDLE_TIMEOUT
    from keep._daemon import runtime_state

    create_group("testm", workers_enabled=False)
    jsonl = tmp_path / "sup.jsonl"
    jsonl.write_text("{}", encoding="utf-8")

    stale_time = time.time() - IDLE_TIMEOUT - 10
    import os
    os.utime(jsonl, (stale_time, stale_time))

    # Pre-seed so first notification fires
    runtime_state.idle_since["testm"] = stale_time - IDLE_TIMEOUT

    notifications: list[str] = []
    monkeypatch.setattr("keep._daemon.idle.notify_supervisor", lambda _m, msg: notifications.append(msg))

    from keep._daemon.idle import check_idle
    group = _make_group("testm", jsonl_path=str(jsonl), workers_enabled=False)

    # First call — fires notification and resets tracking
    check_idle("testm", group)
    assert len(notifications) == 1

    # Simulate another IDLE_TIMEOUT of silence: re-seed idle_since
    runtime_state.idle_since["testm"] = time.time() - IDLE_TIMEOUT - 1

    # Second call — should fire again
    check_idle("testm", group)
    assert len(notifications) == 2
