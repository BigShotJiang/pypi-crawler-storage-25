"""Upgrade-path migrations driven by `_ensure_dirs`."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from keep import state
from keep._state import paths as _paths
from keep._state.groups import _migrate_group_shape


@pytest.fixture
def home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setenv("KEEP_HOME", str(tmp_path))
    return tmp_path


def test_migrate_legacy_storage_dir_renames_missions_to_groups(home: Path) -> None:
    legacy = home / "missions"
    legacy.mkdir()
    (legacy / "g1.json").write_text("{}", encoding="utf-8")

    _paths._ensure_dirs()

    assert (home / "groups" / "g1.json").exists()
    assert not legacy.exists()


def test_migrate_legacy_storage_dir_tolerates_concurrent_rename(home: Path) -> None:
    """Bug 1: TOCTOU — second migrator must not raise when groups/ now exists."""
    legacy = home / "missions"
    legacy.mkdir()
    (legacy / "g1.json").write_text("{}", encoding="utf-8")

    # Simulate the rename happening between the existence check and rename:
    # we patch Path.rename to fail the first time, after first ensuring
    # `groups/` is in place (as a winner process would have done).
    real_rename = Path.rename
    calls = {"n": 0}

    def fake_rename(self: Path, target: Path) -> Path:
        if calls["n"] == 0 and self.name == "missions":
            calls["n"] += 1
            # Winner finished the rename already.
            real_rename(self, target)
            raise OSError("loser process: destination already populated")
        return real_rename(self, target)

    import unittest.mock as _mock
    with _mock.patch.object(Path, "rename", fake_rename):
        _paths._ensure_dirs()  # must not raise

    assert (home / "groups" / "g1.json").exists()


def test_migrate_legacy_signal_files_renamed(home: Path) -> None:
    """Bug 2: mission-stop-* / mission-sync-* renamed to group-*."""
    home.mkdir(exist_ok=True)
    (home / "mission-stop-foo").write_text("", encoding="utf-8")
    (home / "mission-sync-bar").write_text("", encoding="utf-8")
    # Co-existing group-* file (already migrated earlier) must not be clobbered.
    (home / "group-stop-baz").write_text("keep-me", encoding="utf-8")
    (home / "mission-stop-baz").write_text("stale", encoding="utf-8")

    _paths._ensure_dirs()

    assert (home / "group-stop-foo").exists()
    assert not (home / "mission-stop-foo").exists()
    assert (home / "group-sync-bar").exists()
    assert not (home / "mission-sync-bar").exists()
    # Existing target preserved; legacy stale file left alone (don't clobber).
    assert (home / "group-stop-baz").read_text(encoding="utf-8") == "keep-me"


def test_v5_migration_rekeys_resource_states(home: Path) -> None:
    """Bug 3: in-flight resource_states[reviewer]['mission'] → ['group']."""
    group = {
        "schema_version": 4,
        "name": "g1",
        "status": "stopped",
        "participants": [],
        "created_at": 0.0,
        "review_events": [
            {
                "id": "re1",
                "type": "task_submitted_review",
                "participant_resource_states": {
                    "rev-a": {"mission": "stopped", "1": "approved"},
                    # Existing "group" must not be clobbered.
                    "rev-b": {"mission": "active", "group": "stopped"},
                    "rev-c": {"1": "approved"},
                },
            }
        ],
        "terminal_type": "tmux",
        "terminal_container": None,
    }

    changed = _migrate_group_shape(group)
    assert changed

    # After v7 migration, key is `user_resource_states`.
    states = group["review_events"][0]["user_resource_states"]
    assert states["rev-a"] == {"group": "stopped", "1": "approved"}
    assert states["rev-b"] == {"mission": "active", "group": "stopped"}
    assert states["rev-c"] == {"1": "approved"}
    assert group["schema_version"] == 7


def test_load_group_runs_v5_resource_state_rekey_end_to_end(home: Path) -> None:
    """Sanity: legacy file on disk is rekeyed via the load_group path."""
    legacy_dir = home / "missions"
    legacy_dir.mkdir()
    (legacy_dir / "g1.json").write_text(
        json.dumps(
            {
                "schema_version": 4,
                "name": "g1",
                "status": "stopped",
                "participants": [],
                "created_at": 0.0,
                "review_events": [
                    {
                        "id": "re1",
                        "type": "task_submitted_review",
                        "participant_resource_states": {
                            "rev-a": {"mission": "stopped"},
                        },
                    }
                ],
                "terminal_type": "tmux",
                "terminal_container": None,
            }
        ),
        encoding="utf-8",
    )

    group = state.load_group("g1")

    assert group is not None
    states = group["review_events"][0]["user_resource_states"]
    assert states["rev-a"] == {"group": "stopped"}


def test_v7_migration_renames_participants_to_users(home: Path) -> None:
    group = {
        "schema_version": 6,
        "name": "g7a",
        "status": "stopped",
        "participants": [{"role": "supervisor", "session": "s1", "cache": {}}],
        "created_at": 0.0,
        "review_events": [],
        "terminal_type": "tmux",
        "terminal_container": None,
    }

    changed = _migrate_group_shape(group)

    assert changed
    assert "users" in group
    assert "participants" not in group
    assert group["schema_version"] == 7


def test_v7_migration_adds_kind_to_each_user(home: Path) -> None:
    group = {
        "schema_version": 6,
        "name": "g7b",
        "status": "stopped",
        "participants": [
            {"role": "supervisor", "session": "s1", "cache": {}},
            {"role": "worker", "session": "w1", "cache": {}},
        ],
        "created_at": 0.0,
        "review_events": [],
        "terminal_type": "tmux",
        "terminal_container": None,
    }

    _migrate_group_shape(group)

    for user in group["users"]:
        assert user["kind"] == "agent"


def test_v7_migration_rekeys_all_four_review_event_keys(home: Path) -> None:
    group = {
        "schema_version": 6,
        "name": "g7c",
        "status": "stopped",
        "participants": [],
        "created_at": 0.0,
        "review_events": [
            {
                "id": "re1",
                "type": "task_submitted_review",
                "participant_resource_states": {"r1": {"1": "completed"}},
                "participant_rationales": {"r1": "/tmp/x"},
                "participant_verdicts": {"r1": "pass"},
                "participant_task_verdicts": {"r1": {"1": "pass"}},
            }
        ],
        "terminal_type": "tmux",
        "terminal_container": None,
    }

    _migrate_group_shape(group)

    evt = group["review_events"][0]
    assert "user_resource_states" in evt
    assert "user_rationales" in evt
    assert "user_verdicts" in evt
    assert "user_task_verdicts" in evt
    assert "participant_resource_states" not in evt
    assert "participant_rationales" not in evt
    assert "participant_verdicts" not in evt
    assert "participant_task_verdicts" not in evt


def test_v4_to_v7_chain_loads(home: Path) -> None:
    """Full chain: legacy v4 file on disk loads as v7 with all renames applied."""
    legacy_dir = home / "missions"
    legacy_dir.mkdir()
    (legacy_dir / "g1.json").write_text(
        json.dumps(
            {
                "schema_version": 4,
                "name": "g1",
                "status": "stopped",
                "participants": [
                    {"role": "supervisor", "session": "s1", "cache": {}},
                ],
                "created_at": 0.0,
                "review_events": [
                    {
                        "id": "re1",
                        "type": "task_submitted_review",
                        "participant_resource_states": {
                            "rev-a": {"mission": "stopped"},
                        },
                        "participant_rationales": {"rev-a": "/tmp/r"},
                    }
                ],
                "terminal_type": "tmux",
                "terminal_container": None,
            }
        ),
        encoding="utf-8",
    )

    group = state.load_group("g1")

    assert group is not None
    assert group["schema_version"] == 7
    assert "users" in group and "participants" not in group
    assert group["users"][0]["kind"] == "agent"
    evt = group["review_events"][0]
    assert evt["user_resource_states"]["rev-a"] == {"group": "stopped"}
    assert evt["user_rationales"]["rev-a"] == "/tmp/r"


def test_post_v7_migration_find_supervisor_and_iter_workers_work(home: Path) -> None:
    """API smoke: v7-migrated groups must work with find_supervisor / iter_workers."""
    legacy_dir = home / "missions"
    legacy_dir.mkdir()
    (legacy_dir / "g1.json").write_text(
        json.dumps(
            {
                "schema_version": 6,
                "name": "g1",
                "status": "stopped",
                "participants": [
                    {"role": "supervisor", "session": "s1", "cache": {}},
                    {"role": "worker", "session": "w1", "cache": {}},
                    {"role": "worker", "session": "w2", "cache": {}},
                ],
                "created_at": 0.0,
                "review_events": [],
                "terminal_type": "tmux",
                "terminal_container": None,
            }
        ),
        encoding="utf-8",
    )

    group = state.load_group("g1")
    assert group is not None

    sup = state.find_supervisor(group)
    assert sup is not None and sup["session"] == "s1"

    workers = state.iter_workers(group)
    assert {w["session"] for w in workers} == {"w1", "w2"}
