"""Shared agent-type helpers.

`keep` currently supports two interactive agent providers:
- Claude Code (`claude-code`)
- Codex CLI (`codex`)
"""

from __future__ import annotations

DEFAULT_AGENT_TYPE = "claude-code"
VALID_AGENT_TYPES = frozenset({"claude-code", "codex"})


def normalize_agent_type(agent_type: str | None) -> str:
    if not agent_type:
        return DEFAULT_AGENT_TYPE
    raw = agent_type.strip().lower()
    if raw in {"claude", "claude-code", "cc"}:
        return "claude-code"
    if raw == "codex":
        return "codex"
    raise ValueError(f"Unsupported agent type: {agent_type}")

