"""Claude Code implementation of `keep.agent.Agent`.

Plan #14 walking skeleton — only `last_message()` is implemented. The impl
wraps the existing `keep.worker.resolve_worker` + `read_last_message`
helpers rather than duplicating their logic, so behavior stays consistent
with the pre-abstraction `keep read` command.

Plan #14 Part 3 requires the `last_message` read path to be exercisable on
my-laptop (Linux Python 3.12.3, no cmux installed). `resolve_worker`
unconditionally requires cmux env vars (CMUX_WORKSPACE_ID /
CMUX_SURFACE_ID) and `ps` reachability for the CC process, which is a hard
block on cmux-less environments. To keep the Protocol signature clean
while making Part 3 possible, `last_message()` accepts an **optional**
`jsonl_path` keyword argument that short-circuits `resolve_worker`. The
Protocol itself only advertises `last_message(session)`; the keyword arg
is a CC-impl-specific dependency-injection hatch for tests and for
cmux-less realistic testing.

This DI hatch is **the minimum deviation from Plan #11 §3.2** required to
make the walking skeleton testable end-to-end without cmux. It is called
out explicitly in the Plan #14 report.
"""

from __future__ import annotations

from pathlib import Path

from keep.agent import AgentMessage
from keep.worker import read_last_message, resolve_worker


class CCAgent:
    """Plan #14 walking skeleton CCAgent — implements `Agent.last_message` only."""

    name = "claude-code"

    def last_message(
        self,
        session: str,
        *,
        jsonl_path: Path | str | None = None,
    ) -> AgentMessage | None:
        """Return the most recent assistant reply for a CC session.

        Resolution order for the JSONL file:

        1. If `jsonl_path` is provided explicitly, use it directly. This is
           the DI hatch for tests and for cmux-less realistic testing (see
           module docstring).
        2. Otherwise call `resolve_worker(session)` to discover the JSONL
           via the `ps` + cmux env var path used by the rest of keep.

        Returns None for any failure mode — missing file, malformed file,
        no assistant entries yet, or unreachable session. Query method,
        never raises. All three error branches of the underlying
        `worker.read_last_message` collapse into None (see Plan #14 report
        for the specific CLI error-message specificity loss this causes
        in `keep read`).
        """
        if jsonl_path is not None:
            path = Path(jsonl_path)
        else:
            info = resolve_worker(session, None)
            if info.jsonl_path is None:
                return None
            path = info.jsonl_path

        result = read_last_message(path)
        if not result.get("ok"):
            return None

        return AgentMessage(
            text=result["message"],
            ts=result.get("timestamp") or None,
        )
