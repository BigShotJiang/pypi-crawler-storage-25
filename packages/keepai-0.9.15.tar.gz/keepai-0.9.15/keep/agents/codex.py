"""Codex transcript-backed implementation of `keep.agent.Agent`.

Unlike Claude Code, modern Codex CLI writes a structured session transcript
under `~/.codex/sessions/.../rollout-<thread_id>.jsonl`. We read that file
directly instead of shelling out to `codex exec resume --output-last-message`
because the CLI path can create extra turns / hook noise and has become prompt-
dependent in recent releases.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from keep.agent import AgentMessage


def _read_tail(path: Path, max_bytes: int = 256 * 1024) -> list[str]:
    size = path.stat().st_size
    with open(path, "rb") as f:
        if size > max_bytes:
            f.seek(size - max_bytes)
            f.readline()
        return f.read().decode("utf-8", errors="replace").strip().split("\n")


def _extract_assistant_message(record: dict[str, Any]) -> AgentMessage | None:
    timestamp = record.get("timestamp")
    record_type = record.get("type")

    if record_type == "response_item":
        payload = record.get("payload") or {}
        if payload.get("type") != "message" or payload.get("role") != "assistant":
            return None
        parts: list[str] = []
        for item in payload.get("content") or []:
            if not isinstance(item, dict):
                continue
            if item.get("type") in {"output_text", "text"}:
                text = item.get("text")
                if isinstance(text, str) and text:
                    parts.append(text)
        text = "".join(parts).strip()
        if text:
            return AgentMessage(text=text, ts=timestamp)
        return None

    if record_type == "event_msg":
        payload = record.get("payload") or {}
        if payload.get("type") != "agent_message":
            return None
        text = payload.get("message")
        if isinstance(text, str) and text.strip():
            return AgentMessage(text=text, ts=timestamp)
    return None


def _find_codex_jsonl(session_id: str) -> Path | None:
    sessions_root = Path.home() / ".codex" / "sessions"
    if not session_id or not sessions_root.exists():
        return None

    direct = list(sessions_root.rglob(f"*{session_id}.jsonl"))
    if direct:
        return direct[-1]

    for jsonl_path in sessions_root.rglob("rollout-*.jsonl"):
        try:
            for line in _read_tail(jsonl_path, max_bytes=16 * 1024):
                if not line.strip():
                    continue
                record = json.loads(line)
                if record.get("type") != "session_meta":
                    continue
                payload = record.get("payload") or {}
                if payload.get("id") == session_id:
                    return jsonl_path
                break
        except (OSError, json.JSONDecodeError):
            continue
    return None


class CodexAgent:
    name = "codex"

    def last_message(
        self,
        session: str,
        *,
        session_id: str | None = None,
        jsonl_path: Path | str | None = None,
    ) -> AgentMessage | None:
        path: Path | None
        if jsonl_path is not None:
            path = Path(jsonl_path)
        else:
            resolved_session = session_id or session
            path = _find_codex_jsonl(resolved_session)

        if path is None or not path.exists():
            return None

        try:
            lines = _read_tail(path)
        except OSError:
            return None

        for line in reversed(lines):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            message = _extract_assistant_message(record)
            if message is not None:
                return message
        return None
