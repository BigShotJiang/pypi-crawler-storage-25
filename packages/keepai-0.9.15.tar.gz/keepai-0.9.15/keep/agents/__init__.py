"""Concrete `Agent` implementations.

Each submodule hosts one implementation of `keep.agent.Agent`:

- `cc` — Claude Code (this plan)
- (future) `codex` — OpenAI Codex CLI (Plan #17 per Plan #11 §9)
"""
