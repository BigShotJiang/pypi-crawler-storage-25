"""Internal CLI package.

Split out of `keep.cli` by responsibility:

- `constants` — static help text, regexes, allowed-status sets
- `contracts` — Worker/Supervisor/Reviewer system-prompt and bootstrap builders
- `helpers` — parse / validate / resolve helpers used by command dispatch
- `spawn`   — Claude-session spawn, readiness wait, terminal close, daemon launch
- `dispatch`, `dispatch_task`, `dispatch_worker`, `dispatch_supervisor`,
  `dispatch_reviewer` — group-scoped verb routing

`keep.cli` remains the public entry point and owns the typer `app` wiring; it
imports from this package for implementation.
"""
