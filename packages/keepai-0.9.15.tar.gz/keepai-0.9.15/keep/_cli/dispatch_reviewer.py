"""`keep <group_id> reviewer ...` verb dispatch.

Reviewer only exposes CRUD. Review results return via the user's stop
event and are settled by the daemon.
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from keep.agent_types import normalize_agent_type
from keep._cli.authority import authorize_operation
from keep._state import paths as _paths
from keep._cli.contracts import (
    build_reviewer_bootstrap_prompt_v1,
    build_reviewer_contract_v1,
    build_reviewer_layer1,
)
from keep._cli.identity_env import (
    build_user_env,
    resolve_current_user_session,
)
from keep._cli.helpers import (
    extract_named_option,
    generate_session_id,
    parse_optional_name_path_update,
    resolve_session_id_by_prefix_or_fail,
    validate_spawn_path_or_fail,
)
from keep._cli import spawn as _spawn_mod
from keep._state.config import group_default_agent
from keep.state import (
    add_user,
    get_user,
    iter_reviewers,
    load_group,
    group_terminal_type,
    remove_user,
    update_user,
)
from keep.workflow_policy import OperationName


def _resolve_reviewer_file(name: str | None, prompt_val: str | None) -> Path:
    if prompt_val is not None:
        return Path(prompt_val).expanduser().resolve()
    if name is not None:
        reviewers_dir = _paths.STATE_DIR / "reviewers"
        return reviewers_dir / f"{name}.md"
    typer.echo("--name or --prompt is required", err=True)
    raise typer.Exit(2)


def _parse_reviewer_frontmatter(text: str) -> tuple[list[str] | None, str]:
    """Parse simple markdown frontmatter and strip it from the prompt body."""
    if not text.startswith("---"):
        return None, text

    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return None, text

    end_index: int | None = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end_index = idx
            break
    if end_index is None:
        return None, text

    triggers: list[str] | None = None
    for raw_line in lines[1:end_index]:
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        key, sep, value = line.partition(":")
        if sep and key.strip() == "triggers":
            value = value.strip()
            if value.startswith("[") and value.endswith("]"):
                triggers = [item.strip() for item in value[1:-1].split(",") if item.strip()]

    body = "\n".join(lines[end_index + 1:])
    if text.endswith("\n"):
        body += "\n"
    return triggers, body


def _cmd_create(group_id: str, group: dict, payload: list[str]) -> None:
    authorize_operation(OperationName.REVIEWER_CREATE, group_id=group_id)
    agent_raw, rest = extract_named_option(payload, "--agent")
    name, rest = extract_named_option(rest, "--name")
    prompt_val, rest = extract_named_option(rest, "--prompt")
    cwd_val, rest = extract_named_option(rest, "--path")
    if rest:
        typer.echo("No such argument", err=True)
        raise typer.Exit(2)
    if cwd_val is not None and cwd_val.endswith(".md"):
        typer.echo(
            "--path is the reviewer cwd; pass --prompt for the reviewer prompt file.",
            err=True,
        )
        raise typer.Exit(2)
    if agent_raw is None:
        agent_type = group_default_agent(group)
    else:
        try:
            agent_type = normalize_agent_type(agent_raw)
        except ValueError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(2)

    reviewer_file = _resolve_reviewer_file(name, prompt_val)
    if not reviewer_file.is_file():
        typer.echo(f"Reviewer file not found: {reviewer_file}", err=True)
        raise typer.Exit(1)

    reviewer_name = name or reviewer_file.stem
    layer2_raw = reviewer_file.read_text(encoding="utf-8")
    triggers, layer2 = _parse_reviewer_frontmatter(layer2_raw)
    validate_spawn_path_or_fail(cwd_val)

    session = generate_session_id()
    reviewer_data_tmp: dict = {
        "name": reviewer_name,
        "prompt": str(reviewer_file),
        "path": cwd_val,
        "status": "inactive",
        "agent_type": agent_type,
    }
    if triggers is not None:
        reviewer_data_tmp["triggers"] = triggers
    reviewer_id = session
    add_user(
        group_id,
        reviewer_id,
        role="reviewer",
        **reviewer_data_tmp,
    )
    layer1 = build_reviewer_layer1(group_id, reviewer_name)
    append_system_prompt = build_reviewer_contract_v1(layer1, layer2)
    update_user(group_id, reviewer_id, role="reviewer", system_prompt=append_system_prompt)
    bootstrap_prompt = build_reviewer_bootstrap_prompt_v1(
        group_id, session, reviewer_id, reviewer_name
    )
    user_env = build_user_env(
        group_id=group_id,
        user_session=session,
    )
    terminal_type = group_terminal_type(group)
    reviewer_cache, _info = _spawn_mod.spawn_and_wait_for_ready(
        session,
        cwd_val,
        agent_type=agent_type,
        terminal_type=terminal_type,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        role="reviewer",
        group_id=group_id,
        user_env=user_env,
        on_failure=lambda: remove_user(group_id, reviewer_id, role="reviewer"),
    )
    update_user(
        group_id, reviewer_id,
        role="reviewer",
        status="active", cache=reviewer_cache,
    )
    typer.echo(f"Reviewer '{reviewer_name}' ({reviewer_id[:8]}) 已创建。")
    # Signal daemon to sync group to the new reviewer
    from keep.daemon import group_sync_signal_file
    group_sync_signal_file(group_id).write_text("")


def _cmd_list(group_id: str) -> None:
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    if not reviewers:
        typer.echo("(无 reviewer)")
        return
    for r in reviewers:
        rid = r.get("id", "?")
        rname = r.get("name", "")
        rstatus = r.get("status", "?")
        typer.echo(f"{rid}  {rname}  [{rstatus}]")


def _cmd_show(group_id: str, payload: list[str]) -> None:
    resolved = _resolve_reviewer_target(group_id, payload[0] if payload else None)
    try:
        reviewer = get_user(group_id, resolved, role="reviewer")
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    reviewer_view = {**reviewer, "id": reviewer.get("session")}
    typer.echo(json.dumps(reviewer_view, ensure_ascii=False, indent=2))


def _cmd_update(group_id: str, payload: list[str]) -> None:
    authorize_operation(OperationName.REVIEWER_UPDATE, group_id=group_id)
    reviewer_id_raw, name, path_val = parse_optional_name_path_update(payload)
    resolved = _resolve_reviewer_target(group_id, reviewer_id_raw)
    kwargs: dict = {}
    if name is not None:
        kwargs["name"] = name
    if path_val is not None:
        kwargs["path"] = path_val
    try:
        update_user(group_id, resolved, role="reviewer", **kwargs)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Reviewer '{resolved}' 已更新。")


def _cmd_remove(group_id: str, group: dict, payload: list[str]) -> None:
    authorize_operation(OperationName.REVIEWER_REMOVE, group_id=group_id)
    resolved = _resolve_reviewer_target(group_id, payload[0] if payload else None)
    reviewer = get_user(group_id, resolved, role="reviewer")
    reviewer_session = reviewer.get("session") if reviewer else None
    if reviewer:
        _spawn_mod.kill_and_close_worker(reviewer, group)
    try:
        removed = remove_user(group_id, resolved, role="reviewer")
        if not removed:
            raise ValueError(f"Reviewer '{resolved}' 不存在")
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    if reviewer_session:
        from keep._daemon import runtime_state as _rt
        _rt.purge_worker(group_id, reviewer_session)
    typer.echo(f"Reviewer '{resolved}' 已删除。")


def _cmd_verdict_deprecated(group_id: str, event_id_candidate: str, action: str) -> None:
    typer.echo(
        "reviewer verdict CLI 已废弃。"
        f" 收到的是 keep {group_id} reviewer {event_id_candidate} {action} ... 。"
        "Reviewer 现在必须用 task update / group stop 提交审批结果，由 daemon 自动结算。",
        err=True,
    )
    raise typer.Exit(1)


def _resolve_reviewer_target(group_id: str, raw_id: str | None) -> str:
    if raw_id is not None:
        group = load_group(group_id)
        if group is None:
            typer.echo(f"Group '{group_id}' 不存在", err=True)
            raise typer.Exit(1)
        return resolve_session_id_by_prefix_or_fail(
            group=group,
            role="reviewer",
            raw_id=raw_id,
            id_label="reviewer_id",
        )
    env_reviewer_id = _current_reviewer_id(group_id)
    if env_reviewer_id is not None:
        return env_reviewer_id
    typer.echo(
        "reviewer_id is required（或在 keep 管理的 reviewer 进程中依赖环境变量自动识别）",
        err=True,
    )
    raise typer.Exit(2)


def _current_reviewer_id(group_id: str) -> str | None:
    user_session = resolve_current_user_session(group_id)
    if user_session is None:
        return None
    group = load_group(group_id)
    if group is None:
        typer.echo(f"Group '{group_id}' 不存在", err=True)
        raise typer.Exit(1)
    user = get_user(group_id, user_session)
    if user.get("role") != "reviewer":
        typer.echo(
            f"当前 user '{user_session}' 不是 group '{group_id}' 的 reviewer。",
            err=True,
        )
        raise typer.Exit(1)
    return user_session


def dispatch(group_id: str, group: dict, command: str | None, payload: list[str]) -> None:
    if command == "create":
        _cmd_create(group_id, group, payload)
    elif command == "list":
        _cmd_list(group_id)
    elif command == "show":
        _cmd_show(group_id, payload)
    elif command == "update":
        _cmd_update(group_id, payload)
    elif command == "remove":
        _cmd_remove(group_id, group, payload)
    elif command is not None and payload and payload[0] in {"pass", "reject", "submit"}:
        _cmd_verdict_deprecated(group_id, command, payload[0])
    else:
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)
