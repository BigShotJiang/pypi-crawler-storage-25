"""Group-scoped dispatch: `keep <group_id> <resource> <command> ...`.

Routes to the per-resource module (`dispatch_task`, `dispatch_worker`,
`dispatch_supervisor`, `dispatch_reviewer`) after loading the group.
"""

from __future__ import annotations

import typer

from keep._cli import (
    dispatch_reviewer,
    dispatch_supervisor,
    dispatch_task,
    dispatch_worker,
)
from keep._cli.helpers import require_global, require_group_by_name


def dispatch_group_scoped(group_id: str, args: list[str]) -> None:
    if not args:
        typer.echo(f"Group '{group_id}' requires a scoped command", err=True)
        raise typer.Exit(2)

    require_global()
    group = require_group_by_name(group_id)
    resource = args[0]
    command = args[1] if len(args) > 1 else None
    payload = args[2:]

    if resource == "task":
        dispatch_task.dispatch(group_id, group, command, payload)
    elif resource == "worker":
        dispatch_worker.dispatch(group_id, group, command, payload)
    elif resource == "supervisor":
        dispatch_supervisor.dispatch(group_id, group, command, payload)
    elif resource == "reviewer":
        dispatch_reviewer.dispatch(group_id, group, command, payload)
    else:
        typer.echo(f"No such command '{resource}'", err=True)
        raise typer.Exit(2)
