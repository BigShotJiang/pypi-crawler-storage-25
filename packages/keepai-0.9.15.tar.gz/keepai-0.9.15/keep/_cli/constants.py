"""Static text and validation data for the CLI layer."""

from __future__ import annotations

import re
from pathlib import Path

from keep._state import paths as _paths


def _keep_config_path() -> Path:
    return _paths.STATE_DIR / "config.json"


def __getattr__(name: str):
    if name == "KEEP_CONFIG_PATH":
        return _keep_config_path()
    raise AttributeError(f"module 'keep._cli.constants' has no attribute {name!r}")

_HELP = """keep CLI

全局主体只有：
  self
  group
"""

GROUP_HELP = """group 管理

Commands:
  create
  update
  remove
  list
  show
  start
  stop

Group-scoped 用法:
  keep <group_id> task ...
  keep <group_id> supervisor ...
  keep <group_id> worker ...
  keep <group_id> reviewer ...

继续查看:
  keep group task -h
  keep group supervisor -h
  keep group worker -h
  keep group reviewer -h
"""

GROUP_SCOPED_HELP = {
    "task": """Usage: keep <group_id> task [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n""",
    "supervisor": """Usage: keep <group_id> supervisor [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n  send\n  read\n  wake\n""",
    "worker": """Usage: keep <group_id> worker [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n""",
    "reviewer": """Usage: keep <group_id> reviewer [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  create\n  update\n  remove\n  list\n  show\n""",
}

OLD_ROOT_COMMANDS = {
    "start", "stop", "resume", "status", "send", "read", "wake",
    "transcript", "plan", "prompt", "worker", "config",
}

TASK_STATUS_ALLOWED = {
    "proposed", "pending", "in_progress", "completed", "deleted",
}

UUID_CANONICAL_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
UUID_PREFIX_RE = re.compile(r"^[0-9a-fA-F-]{1,36}$")

CREATE_HELP = {
    "supervisor": """Usage: keep <group_id> supervisor create [OPTIONS]\n\nOptions:\n  --agent TEXT\n  --name TEXT\n  --path TEXT\n  -h, --help
""",
    "worker": """Usage: keep <group_id> worker create [OPTIONS]\n\nOptions:\n  --agent TEXT\n  --name TEXT\n  --path TEXT\n  -h, --help
""",
    "reviewer": """Usage: keep <group_id> reviewer create [OPTIONS]\n\nOptions:\n  --agent TEXT\n  --name TEXT\n  --path TEXT\n  -h, --help
""",
}

COMMAND_HELP = {
    "task": {
        "create": """Usage: keep <group_id> task create <subject>\n""",
        "update": """Usage: keep <group_id> task update --tasks CSV [--subject TEXT] [--description TEXT] [--status TEXT] [--owner TEXT] [--blocks CSV] [--blocked-by CSV] [--rationale FILE]\n""",
    },
    "supervisor": {
        "send": """Usage: keep <group_id> supervisor send [worker_id] <file_path>\n\nSupervisor→Worker 单向工具：supervisor 发送指令文件给指定 worker。\n""",
        "read": """Usage: keep <group_id> supervisor read [worker_id]\n""",
        "wake": """Usage: keep <group_id> supervisor wake [worker_id]\n""",
    },
}
