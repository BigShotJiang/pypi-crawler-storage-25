"""Global keep config reader/writer.

Config file: KEEP_HOME/config.json
Supported user-facing fields:
  default_terminal: str
  default_agent: str
  workers_enabled: bool
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from keep.agent_types import DEFAULT_AGENT_TYPE, normalize_agent_type
from keep._state.paths import DEFAULT_TERMINAL, VALID_TERMINALS

_log = logging.getLogger("keep.state")

_config_cache: dict[str, Any] | None = None
_config_cache_path: Path | None = None
_config_cache_mtime: float | None = None


def _config_path() -> Path:
    from keep._state import paths as _paths
    return _paths.KEEP_HOME / "config.json"


def get_global_config() -> dict[str, Any]:
    """Read KEEP_HOME/config.json, return {} if absent or unreadable."""
    global _config_cache, _config_cache_path, _config_cache_mtime
    path = _config_path()
    if _config_cache is not None and _config_cache_path == path:
        if not path.exists():
            if _config_cache_mtime is None:
                return _config_cache
        else:
            try:
                mtime = path.stat().st_mtime
            except OSError:
                mtime = None
            if mtime == _config_cache_mtime:
                return _config_cache
    if not path.exists():
        _config_cache = {}
        _config_cache_path = path
        _config_cache_mtime = None
        return _config_cache
    try:
        mtime = path.stat().st_mtime
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            _config_cache = data
        else:
            _config_cache = {}
    except Exception as e:
        _log.warning("Failed to read global config %s: %s", path, e)
        _config_cache = {}
        mtime = None
    _config_cache_path = path
    _config_cache_mtime = mtime
    return _config_cache


def _invalidate_cache() -> None:
    global _config_cache, _config_cache_path, _config_cache_mtime
    _config_cache = None
    _config_cache_path = None
    _config_cache_mtime = None


def set_global_config(key: str, value: Any) -> None:
    """Write a single key to KEEP_HOME/config.json (creates file if absent)."""
    from keep._state.paths import atomic_write_text
    path = _config_path()
    config = get_global_config()
    config[key] = value
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(path, json.dumps(config, indent=2, ensure_ascii=False))
    _invalidate_cache()


def _coerce_default_terminal(value: Any) -> str | None:
    if value is None:
        return None
    raw = str(value).strip().lower()
    if raw == "terminal.app":
        raw = "terminal"
    if raw in VALID_TERMINALS:
        return raw
    return None


def default_terminal_global() -> str:
    """Return the global default terminal, with legacy-key fallback."""
    config = get_global_config()
    value = _coerce_default_terminal(
        config.get("default_terminal", config.get("terminal"))
    )
    if value is None:
        legacy = config.get("default_terminal", config.get("terminal"))
        if legacy is not None:
            _log.warning("Invalid default_terminal in config.json: %r", legacy)
        return DEFAULT_TERMINAL
    return value


def default_agent_global() -> str:
    """Return the global default agent."""
    config = get_global_config()
    raw = config.get("default_agent")
    if raw is None:
        return DEFAULT_AGENT_TYPE
    try:
        return normalize_agent_type(raw)
    except ValueError:
        _log.warning("Invalid default_agent in config.json: %r", raw)
        return DEFAULT_AGENT_TYPE


def _coerce_workers_enabled(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value.lower() in {"true", "1", "yes"}
    return bool(value)


def workers_enabled_global() -> bool:
    """Return global workers_enabled config value (default True)."""
    value = _coerce_workers_enabled(get_global_config().get("workers_enabled"))
    return True if value is None else value


def is_workers_enabled_for_group(group: dict[str, Any] | None) -> bool:
    if group is not None:
        value = _coerce_workers_enabled(group.get("workers_enabled"))
        if value is not None:
            return value
    return workers_enabled_global()


def is_workers_enabled(group_name: str) -> bool:
    """Effective workers_enabled for a group.

    Priority: group-level field > global config > True (default).
    """
    from keep._state.groups import load_group
    return is_workers_enabled_for_group(load_group(group_name))


def group_default_agent(group: dict[str, Any] | None) -> str:
    """Return the group's default agent, falling back to keep defaults."""
    if group is not None and group.get("default_agent") is not None:
        try:
            return normalize_agent_type(group.get("default_agent"))
        except ValueError:
            _log.warning(
                "Invalid group default_agent for %r: %r",
                group.get("name"),
                group.get("default_agent"),
            )
    return default_agent_global()
