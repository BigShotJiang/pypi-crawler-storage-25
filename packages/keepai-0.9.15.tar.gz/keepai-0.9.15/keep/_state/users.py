"""User helpers.

User = {session, role, kind, agent_type?, cache?, name?, path?, contract?}
  role:  "worker" | "supervisor" | "reviewer"
  kind:  "agent" (future: "human" / "cli")
  agent_type: "claude-code" | "codex"（缺省视为 claude-code）
  cache: 运行时信息（pid/target_id/jsonl_path/thread_id），可选

terminal_type 不存在 user 上：group 是唯一来源。

Mutator pattern (并发安全)：
  add_*/remove_* 接 group_id，内部通过 `mutate_group` 取 per-group
  file lock，load → mutate → save 原子化。caller **不要** 自己
  `load_group + save_group` —— 那样绕开了锁，会和 daemon / 其他 CLI
  进程 race 写（后写覆盖前写，state 丢失）。
"""

from __future__ import annotations

from typing import Any
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict

from keep.agent_types import normalize_agent_type
from keep._state.groups import VALID_USER_ROLES, list_groups, load_group, mutate_group


class User(BaseModel):
    model_config = ConfigDict(extra="allow")

    session: str = ""
    role: Literal["worker", "supervisor", "reviewer"]
    kind: Literal["agent"] = "agent"
    name: str = ""
    path: str = ""
    contract: dict | None = None
    agent_type: str | None = None
    cache: dict | None = None

    def normalized_agent_type(self) -> str:
        return normalize_agent_type(self.agent_type)

    def target_id(self) -> str | None:
        return str((self.cache or {}).get("target_id") or "") or None

    def jsonl_path(self) -> Path | None:
        raw = (self.cache or {}).get("jsonl_path")
        if not raw:
            return None
        return Path(str(raw))

    def thread_id(self) -> str | None:
        raw = (self.cache or {}).get("thread_id")
        return str(raw) if raw else None

    def is_ready(self) -> bool:
        return bool(self.target_id())


def _users_by_role(group: dict[str, Any], role: str) -> list[dict[str, Any]]:
    return [u for u in group.get("users", []) if u.get("role") == role]


def iter_users(group: dict[str, Any], *, role: str | None = None) -> list[dict[str, Any]]:
    if role is None:
        return list(group.get("users", []))
    return _users_by_role(group, role)


def user_agent_type(user: dict[str, Any]) -> str:
    return User.model_validate(user).normalized_agent_type()


def user_ready(user: dict[str, Any]) -> bool:
    return User.model_validate(user).is_ready()


def user_target_id(user: dict[str, Any]) -> str | None:
    return User.model_validate(user).target_id()


def user_jsonl_path(user: dict[str, Any]) -> Path | None:
    return User.model_validate(user).jsonl_path()


def user_thread_id(user: dict[str, Any]) -> str | None:
    return User.model_validate(user).thread_id()


def worker_session_id(worker: dict[str, Any]) -> str | None:
    """Return keep's stable user session id for routing stop files."""
    session = worker.get("session")
    if session:
        return str(session)
    thread_id = user_thread_id(worker)
    if thread_id:
        return str(thread_id)
    return None


def iter_workers(group: dict[str, Any]) -> list[dict[str, Any]]:
    """返回 group 里所有 role=worker 的 user。"""
    return iter_users(group, role="worker")


def iter_reviewer_users(group: dict[str, Any]) -> list[dict[str, Any]]:
    return iter_users(group, role="reviewer")


def iter_reviewers(group_id: str) -> list[dict[str, Any]]:
    group = load_group(group_id)
    if group is None:
        raise ValueError(f"Group '{group_id}' 不存在")
    return [
        {**reviewer, "id": reviewer.get("session")}
        for reviewer in iter_reviewer_users(group)
    ]


def find_worker(group: dict[str, Any], session: str) -> dict[str, Any] | None:
    return find_user(group, session, role="worker")


def find_user(
    group: dict[str, Any],
    session: str,
    *,
    role: str | None = None,
) -> dict[str, Any] | None:
    users = iter_users(group, role=role)
    return next(
        (u for u in users if u.get("session") == session),
        None,
    )


def get_user(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
) -> dict[str, Any]:
    group = load_group(group_id)
    if group is None:
        raise ValueError(f"Group '{group_id}' 不存在")
    user = find_user(group, session, role=role)
    if user is None:
        label = role or "user"
        raise ValueError(f"{label.title()} '{session}' 不存在")
    return user


def find_worker_globally(session: str) -> str | None:
    """检查 session 是否已作为 worker 在任何 group 中，返回 group name 或 None。"""
    return find_user_globally(session, role="worker")


def find_user_globally(session: str, *, role: str | None = None) -> str | None:
    """检查 session 是否已作为 user 在任何 group 中，返回 group name 或 None。"""
    for name in list_groups():
        m = load_group(name)
        if m and find_user(m, session, role=role):
            return name
    return None


def find_supervisor(group: dict[str, Any]) -> dict[str, Any] | None:
    """返回 group 的 supervisor user（若有）。"""
    return next(iter(iter_users(group, role="supervisor")), None)


def add_user(
    group_id: str,
    session: str,
    *,
    role: str,
    cache: dict | None = None,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
    bootstrapped: bool | None = None,
    **extra_fields: Any,
) -> dict[str, Any]:
    existing = find_user_globally(session, role=role)
    if existing and existing != group_id:
        raise ValueError(
            f"User '{session}' 已在 group '{existing}' 中，"
            f"先从该 group 中移除"
        )
    user: dict[str, Any] = {
        "session": session,
        "role": role,
        "kind": "agent",
        "name": name or "",
        "path": path or "",
        "contract": contract,
        "agent_type": normalize_agent_type(agent_type),
        "cache": cache,
    }
    if bootstrapped is not None:
        user["bootstrapped"] = bootstrapped
    user.update(extra_fields)
    with mutate_group(group_id) as group:
        group.setdefault("users", [])
        if role == "supervisor":
            existing_supervisor = find_supervisor(group)
            if existing_supervisor is not None:
                old_id = existing_supervisor.get("name") or existing_supervisor.get("session", "")
                raise ValueError(
                    f"Group already has a supervisor ({old_id}). "
                    "Remove it first: keep supervisor remove"
                )
        if find_user(group, session, role=role):
            raise ValueError(f"{role.title()} '{session}' 已在此 group 中")
        group["users"].append(user)
    return user


def update_user(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    with mutate_group(group_id) as group:
        user = find_user(group, session, role=role)
        if user is None:
            label = role or "user"
            raise ValueError(f"{label.title()} '{session}' 不存在")
        user.update(kwargs)
        user["session"] = session
        if role is not None:
            user["role"] = role
        return user


def remove_user(
    group_id: str,
    session: str,
    *,
    role: str | None = None,
) -> bool:
    with mutate_group(group_id) as group:
        users = group.get("users", [])
        new_users = [
            u for u in users
            if not (
                u.get("session") == session
                and (role is None or u.get("role") == role)
            )
        ]
        if len(new_users) == len(users):
            return False
        group["users"] = new_users
    return True


def add_worker(
    group_id: str,
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
    bootstrapped: bool = False,
) -> dict[str, Any]:
    return add_user(
        group_id,
        session,
        role="worker",
        cache=cache,
        name=name,
        path=path,
        contract=contract,
        agent_type=agent_type,
        bootstrapped=bootstrapped,
    )


def remove_worker(group_id: str, session: str) -> bool:
    return remove_user(group_id, session, role="worker")


def add_supervisor(
    group_id: str,
    session: str,
    cache: dict | None = None,
    *,
    name: str | None = None,
    path: str | None = None,
    contract: dict | None = None,
    agent_type: str | None = None,
) -> dict[str, Any]:
    return add_user(
        group_id,
        session,
        role="supervisor",
        cache=cache,
        name=name,
        path=path,
        contract=contract,
        agent_type=agent_type,
    )


def remove_supervisor(group_id: str) -> bool:
    group = load_group(group_id)
    if group is None:
        return False
    supervisor = find_supervisor(group)
    if supervisor is None:
        return False
    return remove_user(group_id, str(supervisor["session"]), role="supervisor")
