"""Inline/file content resolution helpers."""

from __future__ import annotations

from pathlib import Path
from keep._state import paths as _paths


def _is_within(parent: Path, child: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


def resolve_content(value: str | None) -> str:
    """解析内容：如果是文件路径则读取文件，否则原样返回。

    CPython 3.12 `Path.is_file()` 没把 ENAMETOOLONG (errno 63) 加进 _ignore_error
    白名单——macOS 单段路径字节 > 255（中文 3 字节，inline 长内容很容易踩）会抛
    OSError 而不是返回 False。CPython 3.14 已修。这里手动兜底。
    """
    if not value:
        return ""
    path = Path(value).expanduser()
    try:
        is_file = path.is_file()
    except OSError:
        is_file = False
    if is_file:
        return path.read_text()
    return value


def read_keep_home_text(
    path_value: str | None,
    *,
    missing_message: str,
    outside_message: str,
) -> str:
    """Read a text file only if it resolves under KEEP_HOME.

    Returns a caller-provided sentinel string for missing files or paths that
    resolve outside KEEP_HOME.
    """
    if not path_value:
        return ""
    path = Path(path_value).expanduser()
    try:
        resolved = path.resolve(strict=False)
        keep_home = _paths.KEEP_HOME.resolve()
    except OSError:
        return missing_message.format(path=path_value)
    if not _is_within(keep_home, resolved):
        return outside_message.format(path=path_value)
    try:
        return resolved.read_text(encoding="utf-8")
    except OSError:
        return missing_message.format(path=path_value)
