"""Global daemon state (~/.keep/global.json)."""

from __future__ import annotations

import json
from typing import Any

from keep._state import paths as _paths
from keep._state.paths import atomic_write_text, _ensure_dirs


def load_global() -> dict[str, Any] | None:
    # Import locally to avoid a circular reference at module import time
    # (v0.2 migration writes a global state as part of bootstrap).
    from keep._state.groups import _migrate_v2
    _migrate_v2()
    if not _paths.GLOBAL_FILE.exists():
        return None
    return json.loads(_paths.GLOBAL_FILE.read_text())


def save_global(state: dict[str, Any]) -> None:
    _ensure_dirs()
    atomic_write_text(_paths.GLOBAL_FILE, json.dumps(state, ensure_ascii=False, indent=2))


def delete_global() -> None:
    if _paths.GLOBAL_FILE.exists():
        _paths.GLOBAL_FILE.unlink()


def new_global() -> dict[str, Any]:
    return {
        "daemon_pid": None,
    }
