"""Per-group task store."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from filelock import FileLock

from keep._state import paths as _paths
from keep._state.paths import atomic_write_text


def task_store_dir(group_id: str) -> Path:
    return _paths.STATE_DIR / "keep_id" / "tasks" / group_id


def task_file(group_id: str, task_id: str) -> Path:
    return task_store_dir(group_id) / f"{task_id}.json"


def highwatermark_file(group_id: str) -> Path:
    return task_store_dir(group_id) / ".highwatermark"


def lock_file(group_id: str) -> Path:
    return task_store_dir(group_id) / ".lock"


def _ensure_task_store(group_id: str) -> Path:
    task_dir = task_store_dir(group_id)
    task_dir.mkdir(parents=True, exist_ok=True)
    lf = lock_file(group_id)
    if not lf.exists():
        lf.write_text("", encoding="utf-8")
    hw = highwatermark_file(group_id)
    if not hw.exists():
        hw.write_text("0", encoding="utf-8")
    return task_dir


def _max_existing_task_id(task_dir: Path) -> int:
    """Return the largest numeric task filename in the store, ignoring metadata files."""
    max_id = 0
    for task_path in task_dir.glob("*.json"):
        try:
            max_id = max(max_id, int(task_path.stem))
        except ValueError:
            continue
    return max_id


def _task_record(
    *,
    task_id: str,
    subject: str,
    description: str = "",
    status: str = "proposed",
    owner: str = "",
    blocks: list[str] | None = None,
    blocked_by: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "id": task_id,
        "subject": subject,
        "description": description,
        "status": status,
        "owner": owner,
        "blocks": blocks or [],
        "blockedBy": blocked_by or [],
    }


def _write_task(group_id: str, task: dict[str, Any]) -> None:
    _ensure_task_store(group_id)
    atomic_write_text(
        task_file(group_id, str(task["id"])),
        json.dumps(task, ensure_ascii=False, indent=2),
    )


def next_task_id(group_id: str) -> str:
    """Atomically allocate the next task ID, self-healing a stale highwatermark."""
    task_dir = _ensure_task_store(group_id)
    hw = highwatermark_file(group_id)
    with FileLock(str(lock_file(group_id))):
        raw = hw.read_text(encoding="utf-8").strip()
        try:
            current = int(raw or "0")
        except ValueError:
            current = 0
        current = max(current, _max_existing_task_id(task_dir))
        new_value = current + 1
        atomic_write_text(hw, str(new_value))
    return str(new_value)


def create_task(
    group_id: str,
    *,
    subject: str,
    description: str = "",
    status: str = "proposed",
    owner: str = "",
    blocks: list[str] | None = None,
    blocked_by: list[str] | None = None,
) -> dict[str, Any]:
    task = _task_record(
        task_id=next_task_id(group_id),
        subject=subject,
        description=description,
        status=status,
        owner=owner,
        blocks=blocks,
        blocked_by=blocked_by,
    )
    _write_task(group_id, task)
    return task


def get_task(group_id: str, task_id: str) -> dict[str, Any] | None:
    f = task_file(group_id, task_id)
    if not f.exists():
        return None
    return json.loads(f.read_text(encoding="utf-8"))


def list_tasks(group_id: str) -> list[dict[str, Any]]:
    task_dir = task_store_dir(group_id)
    if not task_dir.exists():
        return []
    tasks = [
        json.loads(task_path.read_text(encoding="utf-8"))
        for task_path in task_dir.glob("*.json")
    ]
    return sorted(tasks, key=lambda task: int(task["id"]))


_ALLOWED_TASK_PATCH_KEYS = frozenset({
    "subject", "description", "status", "owner",
    "blocks", "blockedBy", "rationale", "review_event_id", "review_rationale",
})


def update_task(group_id: str, task_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    """Atomically update a task. Held under per-group task lock to prevent
    concurrent updates from clobbering each other's fields."""
    _ensure_task_store(group_id)
    with FileLock(str(lock_file(group_id))):
        task = get_task(group_id, task_id)
        if task is None:
            raise ValueError(f"Task '{task_id}' 不存在")
        for key, value in patch.items():
            if key in _ALLOWED_TASK_PATCH_KEYS:
                task[key] = value
        _write_task(group_id, task)
    return task


def update_tasks(
    group_id: str,
    task_ids: list[str],
    patch: dict[str, Any],
) -> list[dict[str, Any]]:
    """Atomically apply the same patch to multiple tasks."""
    _ensure_task_store(group_id)
    with FileLock(str(lock_file(group_id))):
        updated: list[dict[str, Any]] = []
        for task_id in task_ids:
            task = get_task(group_id, task_id)
            if task is None:
                raise ValueError(f"Task '{task_id}' 不存在")
            for key, value in patch.items():
                if key in _ALLOWED_TASK_PATCH_KEYS:
                    task[key] = value
            _write_task(group_id, task)
            updated.append(task)
    return updated


def remove_task(group_id: str, task_id: str) -> bool:
    f = task_file(group_id, task_id)
    if not f.exists():
        return False
    f.unlink()
    return True
