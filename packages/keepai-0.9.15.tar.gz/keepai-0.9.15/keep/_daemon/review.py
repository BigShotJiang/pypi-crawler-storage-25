"""Review event lifecycle: dispatch, verdict aggregation, signal-file checks.

Per-type verdict actions (marking tasks, stopping missions, etc.) live in
`verdict_handlers.py` to keep this module focused on the lifecycle edges.
Called by the daemon main loop once per group tick. Any mutation to group
status goes through `mutate_group` so atomic writes + per-group locks are
respected.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from keep._daemon import runtime_state, verdict_handlers
from keep._daemon.constants import (
    EV_GROUP_STOP,
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
    log,
    group_stop_signal_file,
    group_sync_signal_file,
    stop_file,
)
from keep._daemon.notify import notify_all_reviewers, sync_group_to_reviewers
from keep._daemon.xml_format import (
    build_review_summary,
    format_review_request_msg,
)
from keep._state.content import resolve_content
from keep.state import (
    add_review_event,
    get_review_event,
    load_group,
    mutate_group,
    update_review_event,
    worker_session_id,
    write_and_index_message,
)
from keep._state.users import iter_reviewer_users


TASK_PROPOSED_STATES = frozenset({"pending", "proposed"})
TASK_SUBMITTED_STATES = frozenset({"completed", "in_progress"})
ADVANCE_STATE_BY_EVENT = {
    EV_TASK_PROPOSED_REVIEW: "pending",
    EV_TASK_SUBMITTED_REVIEW: "completed",
    EV_GROUP_STOP: "stopped",
}
RETURN_STATE_BY_EVENT = {
    EV_TASK_PROPOSED_REVIEW: "proposed",
    EV_TASK_SUBMITTED_REVIEW: "in_progress",
    EV_GROUP_STOP: "active",
}


def event_round(event: dict[str, Any]) -> int:
    """Current round for a review event; defaults to 1 for pre-round events."""
    raw = event.get("round", 1)
    try:
        return int(raw)
    except (TypeError, ValueError):
        return 1


def is_event_open(event: dict[str, Any]) -> bool:
    return not event.get("final_verdict")


def find_latest_review_event(
    group: dict[str, Any],
    *,
    event_type: str,
    predicate=None,
) -> dict[str, Any] | None:
    for event in reversed(group.get("review_events", [])):
        if event.get("type") != event_type:
            continue
        if predicate is not None and not predicate(event):
            continue
        return event
    return None
def _group_reviewers(group: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            **user,
            "id": user.get("session"),
        }
        for user in iter_reviewer_users(group)
    ]


def _expected_reviewer_ids(group: dict[str, Any], event_type: str | None) -> list[str]:
    expected_ids: list[str] = []
    for reviewer in _group_reviewers(group):
        reviewer_id = reviewer.get("id")
        if not reviewer_id:
            continue
        reviewer_triggers = reviewer.get("triggers")
        if reviewer_triggers is None or (event_type and event_type in reviewer_triggers):
            expected_ids.append(reviewer_id)
    return expected_ids


def _user_resource_states(event: dict[str, Any]) -> dict[str, dict[str, str]]:
    raw = dict(event.get("user_resource_states") or {})
    parsed: dict[str, dict[str, str]] = {}
    for reviewer_id, resource_states in raw.items():
        if not isinstance(resource_states, dict):
            continue
        parsed[str(reviewer_id)] = {
            str(resource_id): str(target_state)
            for resource_id, target_state in resource_states.items()
        }
    return parsed


def _legacy_task_states_for_reviewer(
    event: dict[str, Any],
    reviewer_id: str,
    *,
    event_type: str,
) -> dict[str, str] | None:
    advance_state = ADVANCE_STATE_BY_EVENT[event_type]
    return_state = RETURN_STATE_BY_EVENT[event_type]
    task_ids = [str(task_id) for task_id in (event.get("task_ids") or [])]
    if not task_ids:
        return None

    task_verdicts_by_reviewer = dict(event.get("user_task_verdicts") or {})
    reviewer_map = task_verdicts_by_reviewer.get(reviewer_id)
    if isinstance(reviewer_map, dict):
        converted: dict[str, str] = {}
        for task_id in task_ids:
            verdict = reviewer_map.get(task_id)
            if verdict == "pass":
                converted[task_id] = advance_state
            elif verdict == "reject":
                converted[task_id] = return_state
            else:
                return None
        return converted

    verdict = dict(event.get("user_verdicts") or {}).get(reviewer_id)
    if verdict == "pass":
        return {task_id: advance_state for task_id in task_ids}
    if verdict == "reject":
        return {task_id: return_state for task_id in task_ids}
    return None


def _task_states_for_reviewer(
    event: dict[str, Any],
    reviewer_id: str,
    *,
    event_type: str,
) -> dict[str, str] | None:
    task_ids = [str(task_id) for task_id in (event.get("task_ids") or [])]
    resource_states = _user_resource_states(event).get(reviewer_id)
    if resource_states is not None:
        if set(resource_states) != set(task_ids):
            return None
        allowed_states = (
            TASK_PROPOSED_STATES
            if event_type == EV_TASK_PROPOSED_REVIEW
            else TASK_SUBMITTED_STATES
        )
        if set(resource_states.values()) <= allowed_states:
            return resource_states
        return None
    return _legacy_task_states_for_reviewer(event, reviewer_id, event_type=event_type)


def _group_state_for_reviewer(event: dict[str, Any], reviewer_id: str) -> str | None:
    resource_states = _user_resource_states(event).get(reviewer_id)
    if resource_states is not None:
        group_state = resource_states.get("group")
        if group_state in {"stopped", "active"}:
            return group_state
        return None

    verdict = dict(event.get("user_verdicts") or {}).get(reviewer_id)
    if verdict == "pass":
        return "stopped"
    if verdict == "reject":
        return "active"
    return None


def pending_task_proposed_review_grouper_ids(group: dict[str, Any], event: dict[str, Any]) -> set[str] | None:
    task_ids = [str(task_id) for task_id in (event.get("task_ids") or [])]
    advance_state = ADVANCE_STATE_BY_EVENT[EV_TASK_PROPOSED_REVIEW]
    reviewer_ids = {reviewer["id"] for reviewer in _group_reviewers(group) if reviewer.get("id")}
    pending: set[str] = set()
    for reviewer_id in reviewer_ids:
        reviewer_states = _task_states_for_reviewer(
            event,
            reviewer_id,
            event_type=EV_TASK_PROPOSED_REVIEW,
        )
        if reviewer_states is None:
            pending.add(reviewer_id)
            continue
        if set(reviewer_states) != set(task_ids):
            pending.add(reviewer_id)
            continue
        if any(task_state != advance_state for task_state in reviewer_states.values()):
            pending.add(reviewer_id)
    return pending


def _mark_user_bootstrapped(group_name: str, session: str) -> None:
    try:
        with mutate_group(group_name) as group:
            for user in group.get("users", []):
                if user.get("session") == session:
                    user["bootstrapped"] = True
                    return
    except Exception as e:
        log.warning("Failed to mark user %s bootstrapped [%s]: %s", session, group_name, e)


def _read_stop_payload(sf: Path, group_name: str, session: str) -> dict[str, Any]:
    try:
        payload = json.loads(sf.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        log.warning(
            "reviewer stop signal [%s/%s] unreadable (%s): %s",
            group_name, session, sf, e,
        )
        return {}
    if not isinstance(payload, dict):
        log.warning(
            "reviewer stop signal [%s/%s] malformed: expected JSON object, got %s",
            group_name, session, type(payload).__name__,
        )
        return {}
    return payload


def _save_reviewer_rationale(
    group_name: str,
    session: str,
    rationale_text: str,
) -> str | None:
    try:
        _, out_file = write_and_index_message(
            group_name,
            role="reviewer",
            session=session,
            event_type="review_rationale",
            content=rationale_text,
        )
        return str(out_file)
    except Exception as e:
        log.warning(
            "Failed to save reviewer rationale [%s/%s]: %s",
            group_name, session, e,
        )
        return None


def _parse_reviewer_stop_result(
    group_name: str,
    session: str,
    payload: dict[str, Any],
) -> dict[str, Any] | None:
    last_msg = str(payload.get("last_assistant_message") or "").strip()
    if not last_msg:
        return None

    resolved = resolve_content(last_msg).strip()
    if not resolved:
        return None
    try:
        raw_result = json.loads(resolved)
    except json.JSONDecodeError:
        return None
    if not isinstance(raw_result, dict):
        log.warning(
            "Reviewer stop result [%s/%s] must be a JSON object",
            group_name, session,
        )
        return None

    rationale_path: str | None = None
    rationale_file = raw_result.get("rationale_file")
    if isinstance(rationale_file, str) and rationale_file.strip():
        rationale_path = rationale_file.strip()
    else:
        rationale_text = raw_result.get("rationale")
        if isinstance(rationale_text, str) and rationale_text.strip():
            rationale_path = _save_reviewer_rationale(
                group_name,
                session,
                rationale_text.strip(),
            )

    raw_tasks = raw_result.get("tasks")
    raw_group = raw_result.get("group")
    has_tasks = isinstance(raw_tasks, dict)
    has_group = isinstance(raw_group, str)
    if has_tasks == has_group:
        log.warning(
            "Reviewer stop result [%s/%s] must contain exactly one of 'tasks' or 'group'",
            group_name, session,
        )
        return None

    if has_tasks:
        task_states = {
            str(task_id): str(target_state)
            for task_id, target_state in raw_tasks.items()
        }
        if not task_states:
            log.warning("Reviewer stop result [%s/%s] has empty task state map", group_name, session)
            return None
        state_values = set(task_states.values())
        if state_values <= TASK_PROPOSED_STATES:
            event_type = EV_TASK_PROPOSED_REVIEW
        elif state_values <= TASK_SUBMITTED_STATES:
            event_type = EV_TASK_SUBMITTED_REVIEW
        else:
            log.warning(
                "Reviewer stop result [%s/%s] has unsupported task states: %s",
                group_name, session, sorted(state_values),
            )
            return None
        return {
            "event_type": event_type,
            "resource_states": task_states,
            "rationale_path": rationale_path,
        }

    group_state = raw_group.strip()
    if group_state not in {"stopped", "active"}:
        log.warning(
            "Reviewer stop result [%s/%s] has unsupported group state %r",
            group_name, session, raw_group,
        )
        return None
    return {
        "event_type": EV_GROUP_STOP,
        "resource_states": {"group": group_state},
        "rationale_path": rationale_path,
    }


def _match_review_event_for_reviewer_result(
    group_name: str,
    group: dict[str, Any],
    reviewer_id: str,
    parsed_result: dict[str, Any],
) -> dict[str, Any] | None:
    event_type = parsed_result["event_type"]
    expected_ids = set(_expected_reviewer_ids(group, event_type))
    if reviewer_id not in expected_ids:
        log.warning(
            "Reviewer %s returned %s result but is not configured for that review type [%s]",
            reviewer_id, event_type, group_name,
        )
        return None

    if event_type == EV_GROUP_STOP:
        matches = [
            event
            for event in group.get("review_events", [])
            if event.get("type") == EV_GROUP_STOP and is_event_open(event)
        ]
    else:
        task_ids = set(parsed_result["resource_states"])
        matches = [
            event
            for event in group.get("review_events", [])
            if event.get("type") == event_type
            and is_event_open(event)
            and set(str(task_id) for task_id in (event.get("task_ids") or [])) == task_ids
        ]

    if len(matches) != 1:
        log.warning(
            "Reviewer %s stop result matched %d open %s events [%s]; ignoring result",
            reviewer_id, len(matches), event_type, group_name,
        )
        return None
    return matches[0]


def _record_reviewer_result(
    group_name: str,
    reviewer_id: str,
    event: dict[str, Any],
    parsed_result: dict[str, Any],
) -> None:
    fresh_event = get_review_event(group_name, str(event["id"]))
    resource_states = _user_resource_states(fresh_event)
    resource_states[reviewer_id] = dict(parsed_result["resource_states"])
    update_kwargs: dict[str, Any] = {
        "user_resource_states": resource_states,
    }
    rationale_path = parsed_result.get("rationale_path")
    if rationale_path:
        rationales = dict(fresh_event.get("user_rationales") or {})
        rationales[reviewer_id] = rationale_path
        update_kwargs["user_rationales"] = rationales
    update_review_event(group_name, str(event["id"]), **update_kwargs)


def check_reviewer_stop_signals(group_name: str, group: dict[str, Any]) -> None:
    for reviewer in _group_reviewers(group):
        reviewer_id = reviewer.get("id")
        if not reviewer_id:
            continue
        session_id = worker_session_id(reviewer)
        if not session_id:
            continue
        sf = stop_file(session_id)
        if not sf.exists():
            continue

        payload = _read_stop_payload(sf, group_name, reviewer_id)
        sf.unlink(missing_ok=True)
        if reviewer_id not in runtime_state.first_stop_suppressed:
            runtime_state.first_stop_suppressed.add(reviewer_id)
            _mark_user_bootstrapped(group_name, reviewer_id)
            runtime_state.mark_dirty()
            log.info("Initial reviewer stop suppressed [%s/%s]", group_name, reviewer_id)
            continue

        parsed_result = _parse_reviewer_stop_result(group_name, reviewer_id, payload)
        if parsed_result is None:
            log.info("Ignored reviewer stop without structured result [%s/%s]", group_name, reviewer_id)
            continue

        matched_event = _match_review_event_for_reviewer_result(
            group_name,
            group,
            reviewer_id,
            parsed_result,
        )
        if matched_event is None:
            continue
        try:
            _record_reviewer_result(group_name, reviewer_id, matched_event, parsed_result)
            log.info(
                "Recorded reviewer %s stop result for %s event %s [%s]",
                reviewer_id, parsed_result["event_type"], matched_event["id"], group_name,
            )
        except Exception as e:
            log.warning(
                "Failed to record reviewer stop result [%s/%s -> %s]: %s",
                group_name, reviewer_id, matched_event.get("id"), e,
            )


def cancel_review_event(group_name: str, event_id: str) -> dict[str, Any] | None:
    """Mark an open review event as cancelled and clear runtime dispatch state."""
    try:
        event = get_review_event(group_name, event_id)
    except Exception as e:
        log.warning("Cannot load review event %s [%s] for cancel: %s", event_id, group_name, e)
        return None

    if event.get("final_verdict"):
        return event

    try:
        update_review_event(group_name, event_id, final_verdict="cancelled")
    except Exception as e:
        log.warning("Failed to cancel review event %s [%s]: %s", event_id, group_name, e)
        return None

    runtime_state.review_dispatched.discard(f"{group_name}:{event_id}")
    if event.get("type") == EV_GROUP_STOP:
        runtime_state.pending_stop_event.pop(group_name, None)
    runtime_state.save()
    event["final_verdict"] = "cancelled"
    return event
def cancel_pending_group_stop(group_name: str) -> str | None:
    """Cancel the current group_stop review thread, even before daemon dispatch."""
    signal_file = group_stop_signal_file(group_name)
    rationale_path = ""
    had_signal = False
    try:
        rationale_path = signal_file.read_text(encoding="utf-8").strip()
        signal_file.unlink(missing_ok=True)
        had_signal = True
    except FileNotFoundError:
        pass

    group = load_group(group_name)
    if group is None:
        runtime_state.pending_stop_event.pop(group_name, None)
        runtime_state.save()
        return None

    existing = find_latest_review_event(
        group,
        event_type=EV_GROUP_STOP,
        predicate=is_event_open,
    )
    if existing is not None:
        cancel_review_event(group_name, str(existing["id"]))
        return str(existing["id"])

    if not had_signal:
        runtime_state.pending_stop_event.pop(group_name, None)
        runtime_state.save()
        return None

    try:
        event_data: dict[str, Any] = {
            "type": EV_GROUP_STOP,
            "user_resource_states": {},
            "final_verdict": "cancelled",
        }
        if rationale_path:
            event_data["rationale"] = rationale_path
        event_id = add_review_event(group_name, event_data)
    except Exception as e:
        log.warning(
            "Failed to register cancelled group_stop event for %r: %s",
            group_name, e,
        )
        runtime_state.pending_stop_event.pop(group_name, None)
        runtime_state.save()
        return None

    runtime_state.review_dispatched.discard(f"{group_name}:{event_id}")
    runtime_state.pending_stop_event.pop(group_name, None)
    runtime_state.save()
    return event_id


# ── Dispatch ──────────────────────────────────────────────────────
def dispatch_review_event(
    group_name: str,
    group: dict[str, Any],
    event_id: str,
    event_type: str,
    summary: str,
) -> None:
    """发送 review 请求给所有 reviewers，标记为已 dispatch。"""
    dispatch_key = f"{group_name}:{event_id}"
    if dispatch_key in runtime_state.review_dispatched:
        return
    event = get_review_event(group_name, event_id)
    msg = format_review_request_msg(
        group_name,
        event_id,
        event_type,
        summary,
        round_number=event_round(event),
    )
    reviewer_ids: set[str] | None = None
    if event_type == EV_TASK_PROPOSED_REVIEW:
        reviewer_ids = pending_task_proposed_review_grouper_ids(group, event)

    # Filter by per-reviewer triggers (if declared in frontmatter)
    all_reviewers = _group_reviewers(group)
    triggered_ids: set[str] = set()
    for r in all_reviewers:
        rid = r.get("id")
        if not rid:
            continue
        r_triggers = r.get("triggers")
        if r_triggers is None:
            # No triggers declared → backward-compat, include always
            triggered_ids.add(rid)
        elif event_type in r_triggers:
            triggered_ids.add(rid)

    # Intersect with any existing reviewer_ids filter (e.g. pending_task_proposed_review)
    all_ids = {r.get("id") for r in all_reviewers if r.get("id")}
    if reviewer_ids is not None:
        reviewer_ids = reviewer_ids & triggered_ids
    else:
        # Only pass an explicit set when triggers actually filter something out
        reviewer_ids = triggered_ids if triggered_ids != all_ids else None

    notify_all_reviewers(group, msg, reviewer_ids=reviewer_ids)
    runtime_state.review_dispatched.add(dispatch_key)
    log.info("Review event %s dispatched to reviewers [%s]", event_id, group_name)
    runtime_state.save()


# ── Verdict aggregation ───────────────────────────────────────────
def aggregate_reviewer_verdict(
    group: dict[str, Any],
    event: dict[str, Any],
) -> str | None:
    """聚合 reviewer 结果，返回内部终态 approved / rejected / None。"""
    event_type = event.get("type")
    expected_ids = _expected_reviewer_ids(group, event_type)

    if not expected_ids:
        return "approved"

    if event_type == EV_GROUP_STOP:
        group_states: list[str] = []
        for reviewer_id in expected_ids:
            group_state = _group_state_for_reviewer(event, reviewer_id)
            if group_state is None:
                return None
            group_states.append(group_state)
        if any(group_state == RETURN_STATE_BY_EVENT[EV_GROUP_STOP] for group_state in group_states):
            return "rejected"
        return "approved"

    verdicts: dict[str, str] = dict(event.get("user_verdicts") or {})
    for reviewer_id in expected_ids:
        if reviewer_id not in verdicts:
            return None
    if any(verdicts[reviewer_id] == "reject" for reviewer_id in expected_ids):
        return "rejected"
    return "approved"


def aggregate_task_review_verdicts(
    group: dict[str, Any],
    event: dict[str, Any],
) -> tuple[str | None, dict[str, str] | None]:
    event_type = event.get("type")
    if event_type not in {EV_TASK_PROPOSED_REVIEW, EV_TASK_SUBMITTED_REVIEW}:
        return None, None

    task_ids = [str(task_id) for task_id in (event.get("task_ids") or [])]
    if not task_ids:
        return None, None

    expected_ids = _expected_reviewer_ids(group, event_type)
    if not expected_ids:
        advance_state = ADVANCE_STATE_BY_EVENT[event_type]
        return "approved", {task_id: advance_state for task_id in task_ids}

    advance_state = ADVANCE_STATE_BY_EVENT[event_type]
    return_state = RETURN_STATE_BY_EVENT[event_type]
    for reviewer_id in expected_ids:
        reviewer_map = _task_states_for_reviewer(event, reviewer_id, event_type=event_type)
        if reviewer_map is None:
            return None, None
        for task_id in task_ids:
            if reviewer_map.get(task_id) not in {advance_state, return_state}:
                return None, None

    final_task_states: dict[str, str] = {}
    for task_id in task_ids:
        reviewer_votes = [
            _task_states_for_reviewer(event, reviewer_id, event_type=event_type)[task_id]
            for reviewer_id in expected_ids
        ]
        final_task_states[task_id] = (
            return_state if any(vote == return_state for vote in reviewer_votes) else advance_state
        )

    overall_verdict = (
        "approved"
        if all(state == advance_state for state in final_task_states.values())
        else "rejected"
    )
    return overall_verdict, final_task_states


def handle_review_verdict(
    group_name: str,
    group: dict[str, Any],
    event_id: str,
    verdict: str,
    *,
    final_resource_states: dict[str, Any] | None = None,
) -> None:
    """处理聚合后的判决（approved 或 rejected）：settle 事件 + dispatch 到对应 handler。"""
    try:
        event = get_review_event(group_name, event_id)
    except Exception as e:
        log.warning("Cannot load review event %s [%s]: %s", event_id, group_name, e)
        return

    event_type = event.get("type")
    if not event_type:
        log.error(
            "Review event %s [%s] missing 'type' field — cannot dispatch verdict %r; event=%r",
            event_id, group_name, verdict, event,
        )
        return
    log.info(
        "Review verdict: %s for event %s (type=%s) [%s]",
        verdict, event_id, event_type, group_name,
    )

    # Mark event as settled
    try:
        update_kwargs: dict[str, Any] = {"final_verdict": verdict}
        if final_resource_states is not None:
            update_kwargs["final_resource_states"] = final_resource_states
        update_review_event(group_name, event_id, **update_kwargs)
    except Exception as e:
        log.warning("Failed to update review event %s: %s", event_id, e)
    runtime_state.review_dispatched.discard(f"{group_name}:{event_id}")

    # Reload group so subsequent save_group calls don't overwrite final_verdict
    reloaded = load_group(group_name)
    if reloaded is not None:
        group.update(reloaded)

    if final_resource_states is not None:
        event["final_resource_states"] = final_resource_states
    verdict_handlers.dispatch(group_name, group, event_id, event, event_type, verdict)


# ── Pending / signal checks (called by main loop) ─────────────────
def check_pending_review_verdicts(group_name: str, group: dict[str, Any]) -> None:
    """检查所有未结案的 review events：派发未 dispatch 的事件，聚合已有判决。"""
    try:
        review_events = group.get("review_events", [])
    except Exception:
        return

    for event in list(review_events):  # snapshot; group mutates mid-loop
        event_id = event.get("id")
        if not event_id:
            continue
        # Reload from disk to pick up verdicts submitted since last tick
        fresh_event = get_review_event(group_name, event_id)
        if fresh_event is None:
            continue
        if fresh_event.get("final_verdict"):
            continue
        # Dispatch to reviewers if not yet sent (handles events created by CLI)
        dispatch_key = f"{group_name}:{event_id}"
        if dispatch_key not in runtime_state.review_dispatched:
            event_type = fresh_event.get("type")
            if not event_type:
                log.error(
                    "Review event %s [%s] missing 'type' field — skipping dispatch; event=%r",
                    event_id, group_name, fresh_event,
                )
                continue
            summary = build_review_summary(fresh_event, group_name)
            dispatch_review_event(group_name, group, event_id, event_type, summary)
        final_resource_states: dict[str, Any] | None = None
        if fresh_event.get("type") in {EV_TASK_PROPOSED_REVIEW, EV_TASK_SUBMITTED_REVIEW}:
            verdict, final_task_states = aggregate_task_review_verdicts(group, fresh_event)
            if final_task_states is not None:
                final_resource_states = {"tasks": final_task_states}
            if verdict is None:
                verdict = aggregate_reviewer_verdict(group, fresh_event)
        else:
            verdict = aggregate_reviewer_verdict(group, fresh_event)
            if verdict is not None and fresh_event.get("type") == EV_GROUP_STOP:
                final_resource_states = {
                    "group": (
                        ADVANCE_STATE_BY_EVENT[EV_GROUP_STOP]
                        if verdict == "approved"
                        else RETURN_STATE_BY_EVENT[EV_GROUP_STOP]
                    )
                }
        if verdict is not None:
            handle_review_verdict(
                group_name,
                group,
                event_id,
                verdict,
                final_resource_states=final_resource_states,
            )
            updated = load_group(group_name)
            if updated is not None:
                group.update(updated)
def check_group_sync_signal(group_name: str, group: dict[str, Any]) -> None:
    """检测 group sync 信号文件，有则推送最新 group 内容给所有 reviewers。"""
    sf = group_sync_signal_file(group_name)
    if not sf.exists():
        return
    sf.unlink(missing_ok=True)
    log.info("Group sync signal detected, syncing to reviewers [%s]", group_name)
    sync_group_to_reviewers(group_name, group)


def check_group_stop_signal(group_name: str, group: dict[str, Any]) -> bool:
    """检测 group stop 信号文件，如有 reviewers 则创建 review event，否则直接 stop。

    返回 True 表示 group 被停止（无论直接还是通过 review），调用方应 continue。
    """
    sf = group_stop_signal_file(group_name)
    if not sf.exists():
        return False

    reviewers = _group_reviewers(group)

    if not reviewers:
        sf.unlink(missing_ok=True)
        with mutate_group(group_name) as fresh:
            fresh["status"] = "stopped"
        group["status"] = "stopped"
        log.info("group_stop: no reviewers, stopping immediately [%s]", group_name)
        return True

    # Already has a pending stop event — consume signal file to prevent re-dispatch on restart
    if group_name in runtime_state.pending_stop_event:
        sf.unlink(missing_ok=True)
        return False

    rationale_path = sf.read_text(encoding="utf-8").strip()
    sf.unlink(missing_ok=True)
    try:
        event_data: dict[str, Any] = {
            "type": EV_GROUP_STOP,
            "user_resource_states": {},
        }
        if rationale_path:
            event_data["rationale"] = rationale_path
        event_id = add_review_event(group_name, event_data)
        runtime_state.pending_stop_event[group_name] = event_id
        runtime_state.save()
        log.info("Created group_stop review event %s [%s]", event_id, group_name)
    except Exception as e:
        log.warning("Failed to create group_stop event for %r: %s", group_name, e)
        return False

    summary = build_review_summary(event_data | {"id": event_id}, group_name)
    dispatch_review_event(group_name, group, event_id, EV_GROUP_STOP, summary)
    return False
