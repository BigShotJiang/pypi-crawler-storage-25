"""Daemon main loop: iterate missions, route events, sleep, repeat.

Intentionally thin — all detection and notification logic lives in sibling
modules (`worker_check`, `idle`, `review`, `notify`). `run_daemon` is the
only function exported back to the public facade.
"""

from __future__ import annotations

import os
import signal
import sys
import time
from typing import Any

from keep._daemon import runtime_state
from keep._daemon.constants import POLL_INTERVAL, log
from keep._daemon.constants import stop_file as _stop_file  # noqa: F401  (re-exported via facade)
from keep._daemon.notify import notify_supervisor
from keep._daemon.idle import check_idle
from keep._daemon.review import (
    check_group_stop_signal,
    check_group_sync_signal,
    check_pending_review_verdicts,
    check_reviewer_stop_signals,
)
from keep._daemon.worker_check import check_worker
from keep._daemon.xml_format import format_aggregated_silent_msg, format_silent_msg
from keep.hooks import fire_hook
from keep._state import paths as _paths
from keep.state import (
    find_supervisor,
    iter_workers,
    list_groups,
    load_global,
    load_group,
    write_and_index_message,
)


def _startup() -> None:
    """One-time daemon startup: clean stale signals, restore runtime state."""
    log.info("Daemon started (pid=%d)", os.getpid())

    for f in _paths.STATE_DIR.glob("stop-*"):
        f.unlink(missing_ok=True)
        log.info(f"Cleaned stale signal: {f.name}")

    runtime_state.load()


def _install_signal_handlers() -> None:
    def handle_signal(signum: int, frame: Any) -> None:
        log.info("Daemon stopping")
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)


def _write_silent_to_messages(group_name: str, silent_batch: list[dict[str, Any]], msg: str) -> None:
    """Persist silent event to messages/ index. Never raises."""
    try:
        if len(silent_batch) == 1:
            write_and_index_message(
                group_name,
                role="daemon",
                session=silent_batch[0]["session"],
                event_type="silent",
                content=msg,
            )
        else:
            write_and_index_message(
                group_name,
                role="daemon",
                event_type="silent",
                content=msg,
            )
    except Exception as e:
        log.warning("Failed to write silent event to messages/ [%s]: %s", group_name, e)


def _process_silent_batch(group_name: str, group: dict[str, Any], silent_batch: list[dict[str, Any]]) -> None:
    """Build, persist, notify, fire hook for a batch of simultaneous silents."""
    if not silent_batch:
        return
    if len(silent_batch) == 1:
        s = silent_batch[0]
        msg = format_silent_msg(
            group_name,
            s["session"],
            s["age"],
            s["silent_count"],
        )
    else:
        msg = format_aggregated_silent_msg(group_name, silent_batch)

    _write_silent_to_messages(group_name, silent_batch, msg)
    notify_supervisor(group, msg)
    fire_hook("silent", {"group": group_name, "workers": len(silent_batch)})


def _tick_group(group_name: str) -> None:
    """Run one tick of detection / routing for a single group.

    Returns early when group is stopped / paused / unclaimed.
    """
    try:
        group = load_group(group_name)
        if group is None:
            return

        # group sync is pure reviewer-side context refresh. It should not be
        # gated on group active state or supervisor presence.
        check_group_sync_signal(group_name, group)

        if group.get("status") in {"stopped", "paused"}:
            return

        # ── group stop signal (from CLI) ──────────────────────
        # Must be checked before supervisor guard, because stop signal is written
        # by the CLI before setting status=stopped.
        if check_group_stop_signal(group_name, group):
            return  # Group was stopped immediately
        group = load_group(group_name) or group
        if group.get("status") == "stopped":
            return

        # Unclaimed group = dormant. 没 supervisor 说明还没 wire 起来，
        # 主动跳过比"跑完再丢弃"更干净，也不留 warning 噪声。
        if not find_supervisor(group):
            return

        # ── reviewer stop results / review settlement ───────────
        check_reviewer_stop_signals(group_name, group)
        group = load_group(group_name) or group
        if group.get("status") == "stopped":
            return

        # Check pending review events; settle any where all reviewers have
        # returned results (this mutates group state, reload afterwards).
        check_pending_review_verdicts(group_name, group)
        group = load_group(group_name) or group
        if group.get("status") == "stopped":
            return

        # ── group sync signal (from group update / reviewer add) ──
        check_group_sync_signal(group_name, group)

        # ── worker stop/silent detection ────────────────────────
        silent_batch: list[dict[str, Any]] = []
        for worker in iter_workers(group):
            silent = check_worker(group_name, group, worker)
            if silent:
                silent_batch.append(silent)
        _process_silent_batch(group_name, group, silent_batch)

        # ── idle detection ─────────────────────────────────
        check_idle(group_name, group)
    finally:
        runtime_state.flush_if_dirty()


def _is_fatal_daemon_error(exc: Exception) -> bool:
    return isinstance(exc, ValueError)


def run_daemon() -> None:
    _startup()
    _install_signal_handlers()

    while True:
        try:
            g = load_global()
            if g is None:
                log.info("No active keep, exiting")
                break

            for group_name in list_groups():
                try:
                    _tick_group(group_name)
                except Exception as exc:
                    if _is_fatal_daemon_error(exc):
                        log.exception(
                            "Daemon fatal group error [%s]; exiting",
                            group_name,
                        )
                        raise
                    log.exception("Daemon group loop error [%s]", group_name)

        except Exception as exc:
            if _is_fatal_daemon_error(exc):
                raise
            log.exception("Daemon main loop error")

        time.sleep(POLL_INTERVAL)
