"""Per-event-type verdict handlers called after reviewers reach consensus.

Split out of `review.py` to keep that module focused on dispatch + aggregation.
Each handler is responsible for its own group/task mutations + any follow-up
notification to the supervisor.
"""

from __future__ import annotations

from typing import Any, Callable
from xml.sax.saxutils import escape as xml_escape

from keep._daemon import runtime_state
from keep._daemon.constants import (
    EV_GROUP_STOP,
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
    log,
    group_stop_signal_file,
)
from keep._daemon.notify import notify_supervisor
from keep._daemon.xml_format import build_event_xml
from keep._state.content import read_keep_home_text
from keep.state import (
    get_task,
    mutate_group,
    update_task,
)
from keep.workflow_policy import ActorRole, group_status_mutation_allowed, task_status_mutation_allowed


VerdictHandler = Callable[[str, dict[str, Any], str, dict[str, Any], str], None]


def _task_result_map(event: dict[str, Any], verdict: str) -> dict[str, str]:
    final_resource_states = dict(event.get("final_resource_states") or {})
    final_task_states = dict(final_resource_states.get("tasks") or {})
    if final_task_states:
        return {str(task_id): str(task_state) for task_id, task_state in final_task_states.items()}

    final_task_verdicts = dict(event.get("final_task_verdicts") or {})
    if final_task_verdicts:
        if event.get("type") == EV_TASK_PROPOSED_REVIEW:
            return {
                str(task_id): ("in_progress" if task_verdict == "approved" else "proposed")
                for task_id, task_verdict in final_task_verdicts.items()
            }
        return {
            str(task_id): ("completed" if task_verdict == "approved" else "in_progress")
            for task_id, task_verdict in final_task_verdicts.items()
        }

    task_ids = [
        str(task_id)
        for task_id in (event.get("task_ids") or ([event["task_id"]] if event.get("task_id") else []))
    ]
    if event.get("type") == EV_TASK_PROPOSED_REVIEW:
        fallback = "in_progress" if verdict == "approved" else "proposed"
    else:
        fallback = "completed" if verdict == "approved" else "in_progress"
    return {task_id: fallback for task_id in task_ids}


def _reviewer_result_text(event: dict[str, Any]) -> str:
    resource_states = dict(event.get("user_resource_states") or {})
    parts: list[str] = []
    for reviewer_id, rationale_path in dict(event.get("user_rationales") or {}).items():
        reviewer_states = resource_states.get(reviewer_id) or {}
        if reviewer_states.get("group") is not None:
            state_summary = f"group={reviewer_states['group']}"
        elif reviewer_states:
            state_summary = ", ".join(
                f"#{resource_id}={target_state}"
                for resource_id, target_state in sorted(reviewer_states.items())
            )
        else:
            state_summary = "no-state"
        text = read_keep_home_text(
            rationale_path,
            missing_message="(rationale file not found: {path})",
            outside_message="(blocked: outside KEEP_HOME: {path})",
        )
        parts.append(f"[{reviewer_id} -> {state_summary}] {text}")
    return " ".join(parts)


def _notify_task_review_result(
    group_name: str,
    group: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    event_type: str,
    verdict: str,
) -> None:
    task_results = _task_result_map(event, verdict)
    state_groups: dict[str, list[str]] = {}
    for task_id, task_state in task_results.items():
        state_groups.setdefault(task_state, []).append(f"#{task_id}")
    state_parts = [
        f"{task_state}: {', '.join(task_ids)}"
        for task_state, task_ids in sorted(state_groups.items())
    ]
    reviewer_text = _reviewer_result_text(event)
    body = f"{event_type} settled. " + " ".join(state_parts)
    if reviewer_text:
        body += f" reviewers: {reviewer_text}"
    notify_supervisor(
        group,
        build_event_xml(
            "review_result",
            {
                "group": group_name,
                "event_id": event_id,
                "batch_id": str(event.get("batch_id") or event_id),
                "type": event_type,
            },
            xml_escape(body),
        ),
    )


def _handle_task_submitted_review(
    group_name: str,
    group: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    verdict: str,
) -> None:
    task_results = _task_result_map(event, verdict)
    if not task_results:
        log.warning("task_submitted_review event %s missing task_id(s)", event_id)
        return

    for task_id, target_status in task_results.items():
        try:
            current_task = get_task(group_name, str(task_id))
            current_status = current_task.get("status") if current_task else None
            if current_status is not None and not task_status_mutation_allowed(
                actor_role=ActorRole.REVIEWER,
                source_status=current_status,
                target_status=target_status,
            ):
                log.warning(
                    "Reviewer settlement not allowed for task %s: %s -> %s [%s]",
                    task_id, current_status, target_status, group_name,
                )
                continue
            update_task(
                group_name,
                str(task_id),
                {
                    "status": target_status,
                    "review_event_id": "",
                    "review_rationale": "",
                },
            )
            log.info(
                "Task %s -> %s after task_submitted_review [%s]",
                task_id, target_status, group_name,
            )
        except Exception as e:
            log.warning("Failed to update task %s to %s: %s", task_id, target_status, e)
    _notify_task_review_result(
        group_name, group, event_id, event, EV_TASK_SUBMITTED_REVIEW, verdict
    )


def _handle_task_proposed_review(
    group_name: str,
    group: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    verdict: str,
) -> None:
    task_results = _task_result_map(event, verdict)
    for task_id, next_status in task_results.items():
        try:
            current_task = get_task(group_name, str(task_id))
            current_status = current_task.get("status") if current_task else None
            if current_status is not None and not task_status_mutation_allowed(
                actor_role=ActorRole.REVIEWER,
                source_status=current_status,
                target_status=next_status,
            ):
                log.warning(
                    "Reviewer settlement not allowed for task %s: %s -> %s [%s]",
                    task_id, current_status, next_status, group_name,
                )
                continue
            update_task(
                group_name,
                str(task_id),
                {
                    "status": next_status,
                    "review_event_id": "",
                    "review_rationale": "",
                },
            )
            log.info("Task %s -> %s after task_proposed_review [%s]", task_id, next_status, group_name)
        except Exception as e:
            log.warning("Failed to transition task %s → %s: %s", task_id, next_status, e)
    _notify_task_review_result(
        group_name, group, event_id, event, EV_TASK_PROPOSED_REVIEW, verdict
    )


def _handle_group_stop(
    group_name: str,
    group: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    verdict: str,
) -> None:
    runtime_state.pending_stop_event.pop(group_name, None)
    runtime_state.save()
    group_stop_signal_file(group_name).unlink(missing_ok=True)

    group_result = dict(event.get("final_resource_states") or {}).get("group")
    if group_result not in {"stopped", "active"}:
        group_result = "stopped" if verdict == "approved" else "active"

    if not group_status_mutation_allowed(
        actor_role=ActorRole.REVIEWER,
        source_status="active",
        target_status=group_result,
    ):
        log.warning(
            "Reviewer settlement not allowed for group %s: active -> %s",
            group_name, group_result,
        )
        group_result = "active"

    if group_result == "stopped":
        log.info("group_stop settled -> stopped for %r", group_name)
        with mutate_group(group_name) as fresh:
            fresh["status"] = "stopped"
        group["status"] = "stopped"
    reviewer_text = _reviewer_result_text(event)
    body = f"group_stop settled. group: {group_result}."
    if reviewer_text:
        body += f" reviewers: {reviewer_text}"
    notify_supervisor(
        group,
        build_event_xml(
            "review_result",
            {"group": group_name, "event_id": event_id, "type": EV_GROUP_STOP},
            xml_escape(body),
        ),
    )


HANDLERS: dict[str, VerdictHandler] = {
    EV_TASK_SUBMITTED_REVIEW: _handle_task_submitted_review,
    EV_TASK_PROPOSED_REVIEW: _handle_task_proposed_review,
    EV_GROUP_STOP: _handle_group_stop,
}


def dispatch(
    group_name: str,
    group: dict[str, Any],
    event_id: str,
    event: dict[str, Any],
    event_type: str,
    verdict: str,
) -> None:
    """Look up and invoke the handler for `event_type`. Logs + no-op on unknown type."""
    handler = HANDLERS.get(event_type)
    if handler is None:
        log.warning("No verdict handler for event_type=%s", event_type)
        return
    handler(group_name, group, event_id, event, verdict)
