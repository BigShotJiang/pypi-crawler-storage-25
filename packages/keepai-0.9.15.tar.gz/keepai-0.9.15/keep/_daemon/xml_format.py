"""XML message construction for daemon → supervisor / reviewer notifications.

All outgoing `<keep event=...>` payloads route through `build_event_xml` so
attribute quoting / escaping is uniform and single-line (Escape breaks
Claude Code mid-generation if multi-line).
"""

from __future__ import annotations

from typing import Any
from xml.sax.saxutils import escape as xml_escape, quoteattr

from keep._daemon.constants import (
    EV_GROUP_STOP,
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
    SILENT_MAX_COUNT,
    SILENT_SUSPEND_HINT_AT,
    log,
)
from keep._state.content import read_keep_home_text


def build_event_xml(
    kind: str,
    attrs: dict[str, str],
    body: str = "",
) -> str:
    """Build a well-formed `<keep event=... ...>body</keep>` element.

    - Attribute values go through `xml.sax.saxutils.quoteattr` (which
      handles both quoting and escaping in one step and returns the value
      already wrapped in quotes).
    - `body` is embedded **as-is**. The caller is responsible for
      constructing valid body content: plain text must already be
      `xml_escape`-d, nested elements must have their own text content
      escaped. The helper does not guess structure.
    - Empty body → self-closing tag `<keep ... />`.

    Returns a single-line XML string (no embedded newlines).
    """
    attr_str = " ".join(f"{k}={quoteattr(v)}" for k, v in attrs.items())
    if attr_str:
        open_tag = f"<keep event={quoteattr(kind)} {attr_str}"
    else:
        open_tag = f"<keep event={quoteattr(kind)}"
    if not body:
        return f"{open_tag}/>"
    return f"{open_tag}>{body}</keep>"


def format_silent_msg(
    group_name: str,
    session: str,
    age: int,
    silent_count: int,
) -> str:
    body = ""
    if silent_count == SILENT_SUSPEND_HINT_AT:
        body = xml_escape(
            f"若认为此 worker 工作已告一段落，可 `keep {group_name} worker remove {session[:8]}` 暂停，"
            f"需要时用 `keep {group_name} worker create --session {session}` 拉回。"
        )
    return build_event_xml(
        "silent",
        {
            "group": group_name,
            "worker": session,
            "silent": f"{age}s",
            "silent_count": str(silent_count),
            "silent_max": str(SILENT_MAX_COUNT),
        },
        body,
    )


def format_stop_msg(
    group_name: str,
    session: str,
    last_msg: str,
    output_file: Path | None = None,
) -> str:
    """构造 stop 事件消息，含嵌套 `<reply>` 元素。

    `last_msg` 是 Worker 任意文本回复（经常包含 `<`, `>`, `&`, 甚至字面
    `</reply>` / `</keep>` ——review 报告、代码示例、XML 讨论都会命中），
    必须在包进 `<reply>` 前 `xml_escape`。外层标签和属性交给 `build_event_xml`。
    """
    attrs: dict[str, str] = {"group": group_name, "worker": session}
    if output_file:
        attrs["output_file"] = str(output_file)
    escaped_reply = xml_escape(last_msg)
    return build_event_xml("stop", attrs, f"<reply>{escaped_reply}</reply>")


def format_aggregated_silent_msg(
    group_name: str,
    silents: list[dict[str, Any]],
) -> str:
    """多 worker 同时 silent 时的聚合消息，一条代替 N 条。"""
    max_count = max(s["silent_count"] for s in silents)
    return build_event_xml(
        "silent",
        {
            "group": group_name,
            "workers": str(len(silents)),
            "silent_count_max": str(max_count),
            "silent_max": str(SILENT_MAX_COUNT),
        },
    )


def format_review_request_msg(
    group_name: str,
    event_id: str,
    event_type: str,
    summary: str,
    *,
    round_number: int,
) -> str:
    """构造发给 Reviewer 的 review 请求消息。"""
    body = xml_escape(summary)
    return build_event_xml(
        "review_request",
        {
            "group": group_name,
            "event_id": event_id,
            "type": event_type,
            "round": str(round_number),
        },
        body,
    )


# ── Review summary builder ────────────────────────────────────────
def _read_rationale(rationale_path: str) -> str:
    """Read a rationale file if path is set; return a pre-formatted block.

    Returns empty string if no path configured; returns a sentinel line if the
    file is missing so the reviewer sees *something* actionable.
    """
    if not rationale_path:
        return ""
    text = read_keep_home_text(
        rationale_path,
        missing_message="(file not found: {path})",
        outside_message="(blocked: outside KEEP_HOME: {path})",
    )
    return "\n\nSupervisor rationale:\n" + text


def build_review_summary(event: dict[str, Any], group_name: str) -> str:
    """Build a human-readable summary for a review event dispatch."""
    event_type = event.get("type")
    event_id = event.get("id", "?")
    if not event_type:
        log.error(
            "Review event %s [%s] missing 'type' field — using fallback summary; event=%r",
            event_id, group_name, event,
        )
        return f"Review event {event_id} (UNKNOWN TYPE) pending verdict."

    builder = _SUMMARY_BUILDERS.get(event_type)
    if builder is None:
        return f"Review event {event_id} ({event_type}) pending verdict."
    return builder(event, group_name, event_id)


def _summary_task_proposed_review(event: dict[str, Any], group_name: str, event_id: str) -> str:
    task_ids = event.get("task_ids", [])
    subjects = event.get("task_subjects", task_ids)
    rationale_text = _read_rationale(event.get("rationale", ""))
    round_number = event.get("round", 1)
    task_selector = ",".join(str(task_id) for task_id in task_ids) or "<ids>"
    return (
        f"【任务设计审批 task_proposed_review】{len(task_ids)} 个 task 等待审批（round {round_number}）\n"
        "审批内容：这些 task 的拆分是否合理、描述是否清晰、验收标准是否可执行？通过后 tasks 变 pending，之后才能进入执行。\n\n"
        + "\n".join(str(s) for s in subjects)
        + rationale_text
        + "\n\n使用命令提交审批结果："
        + f"\nkeep {group_name} task update --tasks {task_selector} --status pending"
        + f"\nkeep {group_name} task update --tasks {task_selector} --status proposed"
        + "\n其中 pending=通过，proposed=退回。需要补充上下文时可额外带 --rationale。不要调用 reviewer verdict CLI。"
    )


def _summary_task_submitted_review(event: dict[str, Any], group_name: str, event_id: str) -> str:
    task_ids = event.get("task_ids") or (
        [str(event["task_id"])] if event.get("task_id") else []
    )
    subjects = event.get("task_subjects", [])
    rationale_text = _read_rationale(event.get("rationale", ""))
    round_number = event.get("round", 1)
    tasks_text = "\n".join(
        subjects[i] if i < len(subjects) else f"Task #{tid}"
        for i, tid in enumerate(task_ids)
    )
    task_selector = ",".join(str(task_id) for task_id in task_ids) or "<ids>"
    return (
        f"【任务完成审批 task_submitted_review】{len(task_ids)} 个 task 请求进入 completed（round {round_number}）\n"
        "审批内容：这些 task 是否真正完成、证明是否充分、质量是否达标？通过后 tasks 变 completed；拒绝则退回 in_progress。\n\n"
        + tasks_text
        + rationale_text
        + "\n\n使用命令提交审批结果："
        + f"\nkeep {group_name} task update --tasks {task_selector} --status completed"
        + f"\nkeep {group_name} task update --tasks {task_selector} --status in_progress"
        + "\n其中 completed=通过，in_progress=退回继续补做。需要补充上下文时可额外带 --rationale。不要调用 reviewer verdict CLI。"
    )


def _summary_group_stop(event: dict[str, Any], group_name: str, event_id: str) -> str:
    rationale_text = _read_rationale(event.get("rationale", ""))
    round_number = event.get("round", 1)
    return (
        f"Group '{group_name}' stop requested. (round {round_number})"
        f"{rationale_text}\n"
        "使用命令提交审批结果： "
        f"\nkeep group stop {group_name} --status stopped"
        f"\nkeep group stop {group_name} --status active"
        "\n其中 stopped=允许 stop，active=维持 group 继续运行。需要补充上下文时可额外带 --rationale。不要调用 reviewer verdict CLI。"
    )


_SUMMARY_BUILDERS = {
    EV_TASK_PROPOSED_REVIEW: _summary_task_proposed_review,
    EV_TASK_SUBMITTED_REVIEW: _summary_task_submitted_review,
    EV_GROUP_STOP: _summary_group_stop,
}
