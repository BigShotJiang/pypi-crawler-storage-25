# Multi-Terminal Support Design

**Date:** 2026-04-16  
**Status:** Ready for implementation

## Background

keep currently hardcodes CMUX as the only terminal backend. Every session spawn, send, read, and close goes through `cmux.py` (Unix socket RPC). This spec adds TMUX, Terminal.app, and Kitty support behind a common abstraction.

## User Interface

```bash
keep self config --terminal <cmux|tmux|terminal|kitty>
```

Writes to `~/.keep/config.json`:
```json
{ "terminal": "tmux" }
```

Config is read once at `keep run` time. All sessions in a group use the same terminal type.

## Architecture

### New files

```
keep/
  terminal.py          # Terminal Protocol + factory
  terminals/
    cmux.py            # existing cmux.py logic, refactored
    tmux.py
    terminal_app.py
    kitty.py
```

### Protocol

```python
class Terminal(Protocol):
    def new_surface(self, cwd: str, cmd: str) -> str:
        """Spawn a new terminal session. Returns target_id."""

    def send_text(self, target_id: str, text: str) -> None:
        """Send text + Enter to the session."""

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key: 'escape', 'enter', 'ctrl-c'."""

    def read_screen(self, target_id: str) -> str:
        """Return current visible screen content."""

    def close(self, target_id: str) -> None:
        """Close the session."""
```

### Factory

```python
def get_terminal() -> Terminal:
    config = load_config()  # ~/.keep/config.json
    match config.get("terminal", "cmux"):
        case "cmux":     return CmuxTerminal()
        case "tmux":     return TmuxTerminal()
        case "terminal": return TerminalAppTerminal()
        case "kitty":    return KittyTerminal()
```

## Session Cache

Add `terminal_type` and rename `surface_id` → `target_id` in participant cache:

```json
{
  "cache": {
    "pid": 12345,
    "terminal_type": "tmux",
    "target_id": "keep-worker:0.%0",
    "jsonl_path": "/path/to/session.jsonl"
  }
}
```

`target_id` is terminal-specific:
| Terminal | target_id format | Example |
|----------|-----------------|---------|
| CMUX | CMUX surface UUID | `a3f2-...` |
| TMUX | `session:window.pane_id` | `keep-worker:0.%0` |
| Terminal.app | macOS window ID | `39453` |
| Kitty | Kitty window integer ID | `4` |

## Per-Terminal Implementation

### CMUX
- **new_surface**: `cmux new-surface` CLI → surface UUID
- **send_text**: socket RPC `surface.send_text`
- **send_key**: socket RPC `surface.send_key`
- **read_screen**: `cmux read-screen` CLI
- **close**: socket RPC `surface.close`
- **Prerequisite**: CMUX Settings → Socket Control → Automation Mode

### TMUX
- **new_surface**: `tmux new-session -d -s <name>`, returns `<name>:0.%0`
- **send_text**: `tmux send-keys -t <target_id> <text> Enter`
- **send_key**: `tmux send-keys -t <target_id> <key>`
- **read_screen**: `tmux capture-pane -t <target_id> -p`
- **close**: `tmux kill-session -t <session>`
- **Enter encoding**: `\n`
- **Prerequisite**: none

### Terminal.app
- **new_surface**: `osascript do script` → window ID via `id of front window`
- **send_text**: `set frontmost of window` + `CGEventPostToPid` (char by char) + Return key code 36
- **send_key**: `CGEventPostToPid` with macOS key codes
- **read_screen**: `osascript contents of tab 1 of window`
- **close**: `osascript close window saving no`
- **Enter encoding**: key code 36 (Return)
- **Prerequisite**: System Settings → Privacy → Accessibility (one-time prompt on first use)
- **Dependency**: `pyobjc-framework-Quartz` (installed via uv on first use)

### Kitty
- **new_surface**: `kitty @ --to unix:<sock> new-window -- <cmd>` → integer window ID
- **send_text**: `kitty @ --to unix:<sock> send-text --match id:<id> <text>` + `\r`
- **send_key**: `kitty @ --to unix:<sock> send-text --match id:<id> <key>`
- **read_screen**: `kitty @ --to unix:<sock> get-text --match id:<id> --extent screen`
- **close**: `kitty @ --to unix:<sock> close-window --match id:<id>`
- **Enter encoding**: `\r`
- **Prerequisite**: `allow_remote_control yes` in `~/.config/kitty/kitty.conf`
- **Socket path**: `KITTY_LISTEN_ON` env var (set by Kitty when `listen_on` is configured)

## Claude Code Spawn Flag

All terminals spawn Claude Code with `--dangerously-skip-permissions`.

Remove the `read_screen` workspace-trust polling loop at `cli.py:730-746`. If the trust dialog appears (e.g., due to mismatched `CLAUDE_CONFIG_DIR`), handle it in the bootstrap wait loop by checking `read_screen` output for the trust prompt text and sending `\r` to confirm.

## keep self config command

New subcommand under `keep self`:

```
keep self config --terminal <cmux|tmux|terminal|kitty>
```

- Writes `~/.keep/config.json`
- Validates the terminal type
- For `terminal`: checks Accessibility permission, prompts user if missing
- For `kitty`: checks `KITTY_LISTEN_ON` is set, warns if not
- For `cmux`: no runtime check (CMUX automation mode is a manual one-time setup)

## What Changes

| File | Change |
|------|--------|
| `keep/cmux.py` | Refactor into `keep/terminals/cmux.py`, logic unchanged |
| `keep/terminal.py` | New: Protocol + factory |
| `keep/terminals/tmux.py` | New |
| `keep/terminals/terminal_app.py` | New |
| `keep/terminals/kitty.py` | New |
| `keep/cli.py:730-746` | Remove `read_screen` trust polling loop |
| `keep/cli.py` (spawn) | Add `--dangerously-skip-permissions` to claude invocation |
| `keep/cli.py` (self config) | New `keep self config --terminal` subcommand |
| `keep/state.py` | Add `terminal_type`, rename `surface_id` → `target_id` in cache |
| `keep/daemon.py` | Use `get_terminal()` factory instead of `cmux.send_text` directly |
| `~/.keep/config.json` | New global config file |

## Tested & Verified

All four terminals tested against real Claude Code TUI (not just `cat`):

| Test | CMUX | TMUX | Terminal.app | Kitty |
|------|------|------|-------------|-------|
| new_surface | ✅ existing | ✅ | ✅ | ✅ |
| send_text → Claude TUI | ✅ existing | ✅ BANANA | ✅ BANANA | ✅ BANANA |
| read_screen | ✅ existing | ✅ | ✅ | ✅ |
| close | ✅ existing | ✅ | ✅ | ✅ |
| no focus steal | ✅ | ✅ | ✅ verified | ✅ socket IPC |
