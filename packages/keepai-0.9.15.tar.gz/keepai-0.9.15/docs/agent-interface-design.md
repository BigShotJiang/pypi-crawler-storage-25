# Agent Interface Design — v3 draft

**Status**: v3, ready for implementation. Not yet implemented. Follow-up
plans (§13.5 in Plan #16's feasibility analysis) will implement the pieces
approved here.

**Command-model note (important)**: this document is a design/audit artifact.
Legacy command strings such as `mation read`, `mation send`, `mation kick`,
`group claim`, and `worker add` are kept only to trace old touchpoints.
They are **not** the current user-facing CLI. For current commands, use
`README.md` and `docs/command-model-design.md`.

**v2 → v3 diff**:

- §3.1 `AgentMessage.ts`: `datetime | None` → **`str | None`** (Plan #14
  discrepancy #1, Accepted Option A, effective immediately in v3). Raw
  ISO8601 string preserves byte-identity with agent sources that don't
  round-trip through `datetime.isoformat()`.
- §3.2 `Agent.last_message` docstring: added impl-extension clause
  (Plan #14 discrepancy #3, Accepted). Impls may add optional keyword
  args; Protocol-typed callers see only the minimal signature.
- §3.4 Error model: added query error-collapse clause (Plan #14
  discrepancy #2, Accepted). Query methods may collapse multiple
  distinct errors into a single `None`.
- §3.6 (new): "Discrepancies discovered during Plan #14 walking
  skeleton" — traceability entries for all three discrepancies with
  background, discovery, resolution, and doc location.
- §5 Codex research: upgraded with **`ClaudeHooksEngine`** evidence
  (`codex-rs/hooks/src/engine/mod.rs:63`). Codex upstream implements
  CC's exact Stop hook protocol; mation's `on-stop.sh` runs verbatim
  under Codex. Former OQ #2 ("Codex legacy notify JSON payload")
  resolved. Session-naming workaround for Gap #1 added to §5.1.
- §6 CodexAgent pseudo: rewritten to use `codex exec --output-last-message`
  (zero-parse) and `~/.codex/hooks.json` Stop registration (vs. the old
  `config.toml [notify]` path).
- §9 Implementation plan breakdown: marked **Superseded by §13.5** (Plan
  #16 provided a more granular Phase A-H breakdown).
- §10 Open questions: dropped resolved OQ #2; kept OQ #1 (Codex TUI
  submit key, needs my-laptop test) and OQ #3 (per-group agent
  migration strategy).

v1 → v2 diff (for history): added §3.4 Error model and §3.5 Method
classification table; resolved v1 open questions #3/#5/#6 in place;
§10 shrank from 6 to 3 questions.

**Plan**: `mation-evolution#11` — first plan against group direction 1
(Multi-Agent). Directions 2 (Multi-Terminal) and 3 (Auto Worker Spawn) have
explicit seams reserved but are not designed here.

## 1. Group context

`mation` currently hard-codes Claude Code (CC) semantics throughout the
daemon, CLI, and worker resolution layer. The group prompt asks us to turn
mation into a generic orchestrator that can drive any CLI AI agent. This
document proposes an `Agent` protocol grounded in the exact CC assumptions
the existing code makes, validated against OpenAI Codex CLI as a concrete
second implementation target.

Design constraints (from the plan):

- ≤ 7 interface methods (target)
- Pydantic for structured return types
- CC first-class — CC implementation code must stay at current size + ≤ 20%
- Seams for Multi-Terminal + Auto Spawn without implementing either
- No `.py` changes in this plan, design only

## 2. CC touchpoint inventory (legacy CLI touchpoints)

Every place in the current tree that bakes in CC-specific behavior. Each row
shows file:line, the assumption, and which interface method will absorb it
(§3). These 11 touchpoints drive the entire abstraction; anything not listed
here is out of scope.

| # | Location | Current assumption about CC | Future home |
|---|---|---|---|
| T1 | `mation/worker.py:28-68` `_find_claude_pid` | Agent binary is `claude`, launched with `--resume <session>` or `--name <session>`, discoverable via `ps -eo pid,args` grep; prefer non-bash wrapper | `Agent.status()` |
| T2 | `mation/worker.py:71-84` `_read_env_from_pid` | Process env inherits `CMUX_WORKSPACE_ID` + `CMUX_SURFACE_ID` (cmux parent), readable via `ps eww -p <pid>` | `Agent.status()` internals; partly leaks to §7 Terminal seam |
| T3 | `mation/worker.py:96-139` `_find_jsonl` | Agent persists session to `~/.cac/envs/main/.claude/projects/<encoded-cwd>/<uuid>.jsonl` or `~/.claude/projects/...`; session string is either UUID filename or matches JSONL line `{"type":"custom-title","customTitle":...}` | `Agent.status()`/`last_message()` internals |
| T4 | `mation/worker.py:196-229` `read_last_message` | JSONL line schema: `{"type":"assistant","message":{"content": str \| [{"type":"text","text":...}]}}`; reverse-scan last 256 KB of file | `Agent.last_message()` |
| T5 | `mation/daemon.py:154-176` stop branch | `~/.mation/stop-<session_id>` signal file written by external CC Stop hook; contains JSON with `last_assistant_message` field; consumed-once (daemon `unlink`s after reading) | `Agent.poll_events()` (StopEvent) |
| T6 | `mation/daemon.py:178-198` stall branch | JSONL file mtime is the Worker heartbeat — updated every turn. `age = now - jsonl.stat().st_mtime` is the stall clock | `AgentStatus.last_activity`; daemon computes stall itself |
| T7 | `mation/cli.py:666` `send()` | `cmux.send_text(surface_id, msg)` + sleep 1s + `send_key Enter` delivers input. Assumes a terminal input box where Enter submits | `Agent.send()` (Terminal seam — §7) |
| T8 | `mation/cli.py:688-690` `kick()` | `cmux.send_escape` is the cancel key; follow-up `send_text("继续当前任务")` resumes | `Agent.interrupt()` + `Agent.send()` |
| T9 | `mation/cli.py:694-716` `mation read` | Delegates to T4 via `read_last_message(jsonl_path)` | `Agent.last_message()` |
| T10 | `~/.mation/on-stop.sh` + `~/.cac/envs/main/.claude/settings.json` hooks.Stop | CC Stop hook system: stdin JSON `{session_id, transcript_path, ...}`, invoked on every turn end. mation's hook writes the payload to `stop-<session_id>` | `Agent.poll_events()` contract (install is CC-specific) |
| T11 | `group claim` / `worker add` flow + `user.session` field | Session string is a human-chosen name passed to `claude --name <X>` or a UUID matching the JSONL filename. Must be stable across restarts, re-findable via both ps and disk | `Agent` method argument: `session: str` |

**Dead code** (not part of the abstraction): `~/.mation/on-submit.sh`
(orphaned after `9ce96ef` dropped UserPromptSubmit receipt) and
`~/.mation/on-notification.sh` (present but no consumer in daemon/cli). A
follow-up hygiene plan should delete these; v1 design ignores them.

## 3. Proposed `Agent` interface

Python `Protocol` (structural typing), 5 methods, 3 Pydantic models, 1
exception. Every method maps to at least one touchpoint above.

### 3.1 Data models

```python
from datetime import datetime
from typing import Any, Literal, Protocol
from pydantic import BaseModel, ConfigDict


class AgentStatus(BaseModel):
    """Snapshot of a session's runtime state."""
    model_config = ConfigDict(extra="forbid")

    session_id: str                     # agent-stable identifier, echo of input
    running: bool                       # is the underlying process alive
    pid: int | None = None              # OS pid if discoverable
    last_activity: datetime | None = None  # UTC; used by daemon for stall calc
    surface_hint: str | None = None     # cmux surface id. Transitional leak: stays until
                                        # direction 2 (Multi-Terminal) lands, then renames to
                                        # `terminal_handle` as a deliberate breaking change.
                                        # Resolved from v1 OQ — not an open question anymore.
    metadata: dict[str, Any] = {}       # agent-specific escape hatch: jsonl_path (CC), rollout_path (Codex), etc.
                                        # core code must not parse metadata


class AgentMessage(BaseModel):
    """Single assistant reply as plain text."""
    model_config = ConfigDict(extra="forbid")

    text: str
    ts: str | None = None               # v3: raw ISO8601 source string, verbatim.
                                        # NOT datetime. Reason: CC JSONL writes
                                        # `2026-04-09T01:55:03.323Z`; datetime
                                        # round-trip produces `.323000+00:00`,
                                        # breaking byte-identity with the source
                                        # and thereby `mation read` output.
                                        # Resolution: Plan #14 discrepancy #1,
                                        # Accepted Option A. Callers that need
                                        # datetime math parse on demand — see
                                        # state.py `_parse_iso_utc` used by
                                        # `mation transcript --since`.
    turn_id: str | None = None          # opaque id for future cross-referencing


class StopEvent(BaseModel):
    """Emitted once when the agent finishes a turn."""
    model_config = ConfigDict(extra="forbid")

    kind: Literal["stop"] = "stop"
    ts: datetime                        # UTC, when the daemon observed the event
    reply: AgentMessage                 # the assistant message that closed the turn


# v1 only defines StopEvent. Future discriminated union will add others:
#   AgentEvent = Annotated[Union[StopEvent, ToolCallEvent, ...], Discriminator("kind")]
# v1 code treats `list[AgentEvent]` as `list[StopEvent]` but the type alias leaves room.
AgentEvent = StopEvent


class AgentUnavailable(RuntimeError):
    """Raised when an operation requires a running session but the impl
    cannot deliver it (process not found, surface not resolvable, etc.)."""
```

### 3.2 Protocol

```python
class Agent(Protocol):
    """Protocol for an AI coding agent that mation orchestrates.

    Implementations wrap agent-specific process discovery, log reading, input
    delivery, and turn-completion detection. mation daemon/cli code talks to
    this Protocol, never to a concrete implementation.

    Lifecycle: instances are cheap and stateless; mation will construct one
    per registered agent type at daemon/CLI startup and reuse it for every
    session.
    """

    name: str   # class-level identifier, e.g. "claude-code", "codex".
                # Canonical form only — no aliases (no "cc", no "ccode"). Two
                # names means two registry entries means divergent state; the
                # string `claude-code` is the single stable key across
                # group.json, transcript entries, logs, and CLI args.

    def status(self, session: str) -> AgentStatus:
        """Return a snapshot of the session's runtime state.

        Must always return; never raises. `running=False` with
        `last_activity=None` and empty metadata is the valid "unknown"
        response. Idempotent, safe to call on every poll tick.

        Maps T1, T2, T3, T6, T11.
        """

    def poll_events(self, session: str) -> list[AgentEvent]:
        """Drain pending events since the last call.

        Semantics (important — this is the contract that the file-based
        CC implementation forces):

        - **Consume-once**: each call atomically removes whatever signals
          the impl observed. A StopEvent is returned at most once per turn
          across all poll_events calls on all processes. The CC impl
          enforces this via `unlink` of the signal file; other impls may
          use different consume-once mechanisms (read cursor on a log,
          DB row deletion, etc.).
        - **Ordered**: events in the returned list are in the order the
          impl observed them. v1 lists at most one StopEvent per call so
          ordering within the list is trivial.
        - **Non-blocking**: must return quickly even with zero events.
          Daemon polls once every `POLL_INTERVAL` (2 s); long operations
          starve other sessions.
        - **No stall events here**: stall is computed by daemon from
          `status().last_activity`, not emitted by the impl. Keeps impl
          state minimal and stall heuristic owned by the orchestrator.
        - **Concurrency**: consume-once is per-process. Two concurrent
          daemons on the same host would race; mation already assumes
          a single daemon per host, so this is no regression. The
          `Protocol` contract does **not** guarantee multi-reader
          semantics — if we later add that, it's a breaking change.

        Maps T5, T10.
        """

    def last_message(self, session: str) -> AgentMessage | None:
        """Return the most recent assistant reply, or None if none found.

        Read-only, non-consuming. Idempotent: repeated calls return the
        same message until a new turn completes. Used by `mation read` and
        by diagnostic code; **not** used for completion detection — that's
        `poll_events()`'s job.

        **Impl-extension clause (v3, Plan #14 discrepancy #3 Accepted)**:
        Concrete implementations may add optional keyword arguments to
        this method signature. For example, `CCAgent.last_message` in
        `mation/agents/cc.py` accepts an optional `jsonl_path: Path |
        str | None = None` to bypass `worker.resolve_worker` for
        dependency injection in tests and cmux-less environments. Callers
        **typed as `Agent`** (the Protocol) see only the minimal
        signature `last_message(session: str)` and never depend on
        impl-specific extensions. This is the standard Python Protocol
        structural-typing pattern: the Protocol declares the floor, each
        impl is free to offer extras that only its impl-typed callers
        can reach.

        Maps T3, T4, T9.
        """

    def send(self, session: str, text: str) -> None:
        """Deliver a user message to the agent's input.

        Raises `AgentUnavailable` if the session can't accept input right
        now (not running, no reachable transport). On success, delivery is
        fire-and-forget; there is no receipt. The caller logs to the
        transcript after send returns without raising.

        In v1 the CC impl reaches cmux directly via `cmux.send_text` +
        Enter. Direction 2 (Multi-Terminal) will pass a `Terminal` object
        instead; see §7.

        Maps T7.
        """

    def interrupt(self, session: str) -> None:
        """Cancel the in-progress generation, best-effort.

        Raises `AgentUnavailable` if the session isn't reachable. No
        guarantee the agent actually stopped — some agents may ignore
        interrupts or take seconds to honor them.

        **Non-blocking contract**: `interrupt()` may return immediately
        after delivering the cancel signal. It does **not** wait for the
        cancel to take effect. Callers that follow `interrupt()` with
        `send()` (the `mation kick` pattern) own their own delay; the
        protocol deliberately does not bake a sleep into `interrupt()`
        because the right amount depends on the agent and on whether a
        follow-up `send()` is even coming. Today's `mation kick` inserts
        a 1s sleep at the call site — that stays at the call site.

        Maps T8.
        """
```

### 3.3 Why 5 methods, not more

- No `spawn()` / `attach()` in v1. Worker lifecycle is driven by
  `mation worker add` which assumes the agent was started out-of-band by
  the Human. Auto Spawn is direction 3 and adds `spawn()` later (§7).
- No `close()` / `terminate()`. mation never kills an agent; Human
  controls CC process lifetime directly. Direction 3 may revisit.
- No `stream_output()` for live streaming. `last_message()` returns the
  completed assistant reply; live streaming is a product feature not a
  protocol requirement for stall/completion detection.
- No separate `heartbeat()` — folded into `status().last_activity` to
  avoid two methods that the impl has to keep in sync.
- Stop and stall are **not symmetric**: stop is event-driven (the agent
  or its hook must push), stall is observer-driven (daemon computes from
  `last_activity`). Folding them into one method hides this asymmetry.

### 3.4 Error model

The protocol splits into **query** methods and **action** methods with
deliberately different error surfaces:

- **Query methods** (`status`, `last_message`, `poll_events`) — **never
  raise**. Unknown, unreachable, and corrupted sources all map to
  benign empty results: `AgentStatus(running=False, ...)`,
  `last_message() → None`, `poll_events() → []`. This keeps the
  daemon's polling loop trivial: it loops over sessions, calls queries,
  reacts to whatever it gets. No try/except sprinkling, no poisoned
  sessions taking down the whole loop.

  **Error collapse clause (v3, Plan #14 discrepancy #2 Accepted)**:
  Query methods that fail for multiple distinct reasons may collapse
  them into a single `None` / empty response. Example: `CCAgent.last_message`
  returns `None` regardless of whether the JSONL file is missing,
  unreadable, or contains no assistant entries — the three underlying
  errors (`read_last_message` returns three distinct `error` strings in
  `worker.py:196-229`) are flattened at the Agent-boundary. Error
  specificity loss is the deliberate price of query simplicity: daemon
  polling loops treat all query failures as "no information right now"
  without branching. Impls that want to expose a richer diagnostic path
  should add a separate **non-Protocol** method (e.g.
  `CCAgent.last_message_diagnostic`); Protocol-typed callers never see
  it, so the collapse stays the Protocol's face.

- **Action methods** (`send`, `interrupt`) — **raise
  `AgentUnavailable`** when the session cannot accept the action right
  now (process not running, transport not resolvable, surface gone).
  Action failure is information the caller needs — a CLI user running
  `mation send` expects a non-zero exit and a readable error when
  delivery is impossible. Swallowing here would be a silent-failure
  anti-pattern.

**Rationale for the asymmetry**: observability must not break the
observed system (same principle as `append_transcript` in state.py).
The daemon observes many sessions on every tick; one bad session must
not poison the others. Action methods, by contrast, are invoked once
per deliberate human decision — failing loudly at that point is
correct behavior, and the caller is already in a position to react.

**Implementer obligation**: a concrete `Agent` that raises from a
query method is a **bug**, not a quirk. Its tests must include
filesystem-blocker and process-not-found cases asserting no exception
propagates. A concrete Agent that silently succeeds from `send()` when
the session is unreachable is also a bug — the method must inspect
reachability before attempting delivery.

### 3.5 Method classification (quick reference)

| Method          | Tier | Never raises? | Side effect on source | Maps touchpoints |
|-----------------|------|--------------:|-----------------------|------------------|
| `status`        | Q    | ✅            | none (read-only)       | T1, T2, T3, T6, T11 |
| `last_message`  | Q    | ✅            | none (read-only)       | T3, T4, T9       |
| `poll_events`   | Q    | ✅            | consume-once (unlinks signal) | T5, T10 |
| `send`          | A    | ❌ `AgentUnavailable` | delivers text to agent | T7 |
| `interrupt`     | A    | ❌ `AgentUnavailable` | delivers cancel to agent | T8 |

Q = Query (daemon loop-safe, error-swallowing). A = Action (loud
failure on unreachable session). Implementers use this table as the
checklist when wiring up a new `Agent` impl's tests.

### 3.6 Discrepancies discovered during Plan #14 walking skeleton

Plan #14 built a minimal `CCAgent.last_message` walking skeleton and
wired it through the `mation read` CLI. Before any code ran, three
design-level mismatches between this spec and the existing CC behavior
surfaced. All three were reported to Supervisor before continuing and
all three were resolved via **Accept Option A, effective immediately in
v3**. They are documented here so future readers understand why the
corresponding fields / clauses look the way they do.

#### Discrepancy #1 — `AgentMessage.ts` raw-string preservation

- **Background**: v2 §3.1 declared `ts: datetime | None`. Plan #14 Part
  1 needed to preserve byte-identical CLI output from `mation read`.
- **Discovery**: Real CC JSONL writes timestamps as `2026-04-09T01:55:03.323Z`
  (trailing `Z`, millisecond precision). Python's
  `datetime.fromisoformat(...).isoformat()` round-trip produces
  `2026-04-09T01:55:03.323000+00:00` — pads microseconds to 6 digits
  and replaces `Z` with `+00:00`. Not byte-identical. `mation read`
  header `Worker 'X' 的最后消息，时间 <ts>:` would shift shape on
  every CC session if `ts` were stored as `datetime`.
- **Resolution**: **Accepted Option A, effective immediately in v3**.
  `AgentMessage.ts` is now typed `str | None`, holding the raw source
  ISO8601 string verbatim. The turn_id field already follows this
  opaque-string pattern. Callers that need datetime math (e.g.
  `state.read_transcript`'s `--since` filter) parse on demand via
  `state._parse_iso_utc`.
- **Doc location**: §3.1 `AgentMessage.ts` field definition and inline
  comment carry the updated type and rationale. §1 header v2→v3 diff
  entry cross-references this discrepancy.

#### Discrepancy #2 — Query error collapse

- **Background**: v2 §3.4 error model required query methods
  (`status`, `last_message`, `poll_events`) to never raise and return
  empty / `None` on any failure. The existing CC implementation
  `worker.read_last_message` returns a richer dict with three distinct
  `error` strings: `"JSONL 不存在"`, `"无法读取 JSONL"`, `"没有
  assistant 消息"`. The current CLI echoes each distinctly.
- **Discovery**: Collapsing `last_message` into `AgentMessage | None`
  discards the error specificity. `mation read`'s three distinct error
  messages merge into a single `"无法读取 Worker 消息"`. Minor UX
  regression at the failure path; happy path byte-identical.
- **Resolution**: **Accepted Option A, effective immediately in v3**.
  Query methods are allowed to collapse distinct failure modes into a
  single `None` / empty. §3.4 carries an explicit error-collapse
  clause. Impls that want to preserve specificity should expose a
  **non-Protocol** diagnostic method (e.g.
  `CCAgent.last_message_diagnostic`) that only impl-typed callers
  reach. This keeps the Protocol face narrow and daemon loops trivial.
- **Doc location**: §3.4 "Error collapse clause" paragraph. §1 header
  v2→v3 diff entry cross-references this discrepancy.

#### Discrepancy #3 — Impl-specific keyword arguments

- **Background**: v2 §3.2 Protocol declared `last_message(session: str)
  -> AgentMessage | None`. Plan #14 Part 3 required the walking
  skeleton to run on `my-laptop` (Linux, no cmux installed). Without
  cmux, `worker.resolve_worker` cannot discover the CC session's
  runtime info — the whole `last_message` chain breaks.
- **Discovery**: Adding an optional `jsonl_path` keyword argument to
  **`CCAgent.last_message`** (not to the Protocol) bypasses
  `resolve_worker` and lets tests / cmux-less realistic runs inject a
  JSONL file path directly. The Protocol itself stays on
  `last_message(session)` only. Python's structural-typing semantics
  allow this without breaking `Agent`-typed callers.
- **Resolution**: **Accepted Option A, effective immediately in v3**.
  Impls may add optional keyword arguments. The Protocol declares the
  floor. Each impl is free to offer extras that only impl-typed callers
  can reach. This is the standard Python Protocol pattern and was used
  by Plan #14 walking skeleton without incident — 58 tests passed on
  both Mac and Linux.
- **Doc location**: §3.2 `Agent.last_message` docstring "Impl-extension
  clause". §1 header v2→v3 diff entry cross-references this discrepancy.

**Why these three are not "open questions"**: each was fully analyzed
and decided before the walking-skeleton commits landed (`487a502`,
`a844a90`). The doc updates in v3 record the decisions; they are not
pending choices. Future plans may revisit, but until then the Protocol,
impls, and tests treat Options A above as canonical.

## 4. CCAgent pseudo-implementation

Shows every existing function this abstraction absorbs and proves the
mapping is lossless. Pseudo-code only — not runnable.

```python
class CCAgent:
    name = "claude-code"

    def status(self, session: str) -> AgentStatus:
        info = resolve_worker(session)          # existing worker.py function
        last_activity = None
        if info.jsonl_path and info.jsonl_path.exists():
            last_activity = datetime.fromtimestamp(
                info.jsonl_path.stat().st_mtime, tz=timezone.utc
            )
        return AgentStatus(
            session_id=session,
            running=info.running,
            pid=info.pid,
            last_activity=last_activity,
            surface_hint=info.surface_id,      # leaks cmux id in v1; §7 moves this
            metadata={
                "jsonl_path": str(info.jsonl_path) if info.jsonl_path else "",
                "workspace_id": info.workspace_id or "",
            },
        )

    def poll_events(self, session: str) -> list[AgentEvent]:
        session_id = worker_session_id_lookup(session)  # jsonl stem or session name
        sf = STATE_DIR / f"stop-{session_id}"
        if not sf.exists():
            return []
        try:
            payload = json.loads(sf.read_text())
            reply_text = payload.get("last_assistant_message", "")
        except (json.JSONDecodeError, OSError):
            reply_text = ""
        sf.unlink(missing_ok=True)    # consume-once
        return [StopEvent(
            ts=datetime.now(timezone.utc),
            reply=AgentMessage(text=reply_text),
        )]

    def last_message(self, session: str) -> AgentMessage | None:
        info = resolve_worker(session)
        if not info.jsonl_path:
            return None
        result = read_last_message(info.jsonl_path)   # existing
        if not result.get("ok"):
            return None
        return AgentMessage(
            text=result["message"],
            ts=_parse_cc_timestamp(result.get("timestamp")),
        )

    def send(self, session: str, text: str) -> None:
        info = resolve_worker(session)
        if not info.running or not info.surface_id:
            raise AgentUnavailable(f"CC session {session!r} has no surface")
        cmux.send_text(info.surface_id, text)   # includes Enter internally

    def interrupt(self, session: str) -> None:
        info = resolve_worker(session)
        if not info.running or not info.surface_id:
            raise AgentUnavailable(f"CC session {session!r} has no surface")
        cmux.send_escape(info.surface_id)
```

Line count: ~50 lines of pseudo-code. The actual implementation will
essentially repackage the existing `worker.py` + `daemon.py` stop branch +
`cli.py` send/kick paths behind the protocol. Net code change inside
`CCAgent` is roughly the delta of the five method bodies above, with
existing helpers (`resolve_worker`, `read_last_message`, `cmux.send_text`)
reused verbatim. CC-specific line count stays ≤ current + 20%.

## 5. Codex CLI research

Methodology: originally `gh api` against `openai/codex` (v2). **Upgraded
in v3**: Plan #16 cloned the full tree to `/tmp/codex-research` via
`git clone --depth=1 https://github.com/openai/codex.git` and read
`codex-rs/hooks/`, `codex-rs/rollout/`, `codex-rs/exec/`, and
`codex-rs/core/src/config/mod.rs` directly. The v2 WebFetch timeouts
(on `developers.openai.com`) are now moot — the authoritative answers
live in the Rust source.

### 5.1 Question 1 — session naming and resume

**Answer**: Codex has first-class session resume **and** first-class
session aliasing, though with one semantic gap versus CC's
`--name` flag.

- `codex exec resume <SESSION_ID-or-THREAD-NAME>` — resume by UUID or
  thread name. `--last` picks the most recent session. `--all` disables
  the implicit `cwd` filter.
- Session IDs are UUIDs. On first turn, Codex exec emits a
  `thread.started` JSONL event carrying `thread_id: String`.
- Thread names are managed via an append-only index at
  `$CODEX_HOME/sessions/session_index.jsonl` with entries `{id: ThreadId,
  thread_name: String, updated_at: String}`. `append_thread_name(home,
  uuid, name)` registers or updates the alias.
- `find_thread_path_by_name_str(home, name)` looks up a rollout file by
  human name; `find_thread_name_by_id(home, uuid)` does the reverse.
- Rollout files live at `$CODEX_HOME/sessions/rollout-<RFC3339>-<uuid>.jsonl`
  (codex-rs/rollout/src/recorder.rs:67-68, 670-683).

**Gap vs CC — no `--name` at launch**: CC supports `claude --name
worker-1` which fingerprints the session name in process argv from the
first tick, so `ps` reverse-lookup works immediately. Codex has **no
equivalent CLI flag** — thread names are assigned post-creation via
`append_thread_name` or the TUI's in-session `/name` command. A
Codex process just launched has a fresh UUID and no human alias in argv.

**Workaround**: CodexAgent bootstrap sequence records both the UUID and
the chosen human name up-front:

1. Start `codex exec --json [--resume <id>]` and parse stdout for the
   `thread.started` event carrying `thread_id`.
2. Immediately call `append_thread_name(codex_home, thread_id, human_name)`
   to write the alias into `session_index.jsonl`.
3. mation persists the human name in `group.json`'s user
   record; each subsequent `CodexAgent.status(name)` call resolves via
   `find_thread_path_by_name_str → UUID → ps grep codex.*<UUID>`.

Cost: 3-5 lines in CodexAgent's bootstrap path. Not a structural
blocker. Tracked as Plan #16 Gap #1 in §13.3.

Evidence:
- `codex-rs/exec/src/cli.rs:115-145` — `Command::Resume(ResumeArgs)`
  with `session_id: Option<String>`, `--last`, `--all` flags. Doc
  comment: "Conversation/session id (UUID) or thread name. UUIDs take
  precedence if it parses."
- `codex-rs/exec/src/exec_events.rs` — `ThreadStartedEvent { pub
  thread_id: String }`.
- `codex-rs/rollout/src/session_index.rs:28 append_thread_name`,
  `:116 find_thread_path_by_name_str`, `:67 find_thread_name_by_id`.
- `codex-rs/rollout/src/recorder.rs:67-68` header comment showing
  rollout path formula; `:670-683` filename generation.

**Fit with T1 / T11**: partial but workable. `CodexAgent.status()` uses
the alias index → UUID → `ps` chain instead of a direct `ps` name
match. 2 partial ⚠ cells in §13.1 matrix; both closed by this
bootstrap pattern.

### 5.2 Question 2 — notification hook / turn-completion signal

**Answer**: Codex has **three** hook mechanisms, one of which is a
deliberate reimplementation of Claude Code's Stop hook protocol with
byte-compatible payload shape. This is the **killer finding** of Plan
#16: mation's existing `~/.mation/on-stop.sh` script runs verbatim
under Codex — no rewrite, no adapter, no payload translation.

**Mechanism 1 — `ClaudeHooksEngine` (the CC-compatible path, recommended)**:

Codex ships a module literally named `ClaudeHooksEngine` at
`codex-rs/hooks/src/engine/mod.rs:63`. It replays CC's hook protocol
exactly, including the same five event names:

- `PreToolUse`
- `PostToolUse`
- `SessionStart`
- `UserPromptSubmit`
- **`Stop`**

Discovery reads `hooks.json` from each configuration layer folder (project
/ user / system) — parallel to CC's `settings.json.hooks` block but
stored as a separate file. Schema:

```json
{
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {"type": "command", "command": "bash ~/.mation/on-stop.sh"}
        ]
      }
    ]
  }
}
```

Identical structure to CC's `~/.cac/envs/main/.claude/settings.json`
`hooks` block. mation installs the same shell script in two places and
both agents call it.

**Stop event payload (byte-compatible with CC)**:

```rust
// codex-rs/hooks/src/events/stop.rs:22-32
pub struct StopRequest {
    pub session_id: ThreadId,
    pub turn_id: String,             // +1 field vs CC
    pub cwd: PathBuf,
    pub transcript_path: Option<PathBuf>,
    pub model: String,               // +1 field vs CC
    pub permission_mode: String,
    pub stop_hook_active: bool,
    pub last_assistant_message: Option<String>,
}
```

Compared to CC's live Stop payload (inspected from real
`~/.mation/stop-<uuid>` file):

```
['session_id', 'transcript_path', 'cwd', 'permission_mode',
 'hook_event_name', 'stop_hook_active', 'last_assistant_message']
```

**Every field mation reads is present**: `session_id` and
`last_assistant_message` are the only ones `daemon.py:210` touches.
Codex is a **superset** (adds `turn_id` and `model`). The existing
`on-stop.sh` reads `.session_id` and writes to `stop-<session_id>`;
the daemon reads `last_assistant_message` from there. Zero code change
required.

**Mechanism 2 — legacy notify hook**:

`~/.codex/config.toml` `[notify]` registers a shell command that gets
the full `UserNotification::AgentTurnComplete` JSON appended as the
last argv:

```toml
notify = ["bash", "/home/user/.mation/on-stop-legacy.sh"]
```

The payload (`codex-rs/hooks/src/legacy_notify.rs:12-22`) is:

```rust
AgentTurnComplete {
    thread_id: String,
    turn_id: String,
    cwd: String,
    client: Option<String>,
    input_messages: Vec<String>,
    last_assistant_message: Option<String>,
}
```

Alternate path — available if for some reason the `ClaudeHooksEngine`
path is disabled. Not preferred since the `hooks.json` path reuses
mation's existing `on-stop.sh` directly.

**Mechanism 3 — `codex exec --json` stdout event stream**:

For headless CodexAgent mode (future Direction 3), `codex exec --json`
prints a JSONL event stream to stdout:

- `thread.started` with `thread_id`
- `turn.started`
- `turn.completed` with `usage`
- `turn.failed` with `error`
- `item.started/updated/completed`
- `error`

Event schema in `codex-rs/exec/src/exec_events.rs`. No hooks needed,
no signal files, no cmux — mation would spawn `codex exec` per turn
and parse stdout. This is the **subprocess-ownership** alternative and
is §7.2 direction 3 territory, not v3 first-class.

Evidence:
- `codex-rs/hooks/src/engine/mod.rs:63` — `ClaudeHooksEngine` struct.
- `codex-rs/hooks/src/engine/discovery.rs:37 "hooks.json"` — config
  file name.
- `codex-rs/hooks/src/engine/config.rs` — `HooksFile` + `HookEvents`
  struct with `pre_tool_use`, `post_tool_use`, `session_start`,
  `user_prompt_submit`, `stop`.
- `codex-rs/hooks/src/events/stop.rs:22-32` — `StopRequest` field list.
- `codex-rs/hooks/src/legacy_notify.rs:12-22` — legacy payload
  `UserNotification::AgentTurnComplete` variant.
- `codex-rs/core/src/config/mod.rs:280-299` — `config.notify: Option<Vec<String>>`
  docstring showing `notify = ["notify-send", "Codex"]` invocation
  pattern.
- `codex-rs/hooks/src/registry.rs:20-48` — `HooksConfig` wires
  `legacy_notify_argv` into the after_agent hook chain.
- `codex-rs/exec/src/exec_events.rs` — full `ThreadEvent` enum for the
  `--json` stdout stream.

**Fit with T5 / T10**: ✅ **full + byte-compatible**. The CodexAgent
reuses `mation/on-stop.sh` without modification; mation just ensures
`~/.codex/hooks.json` has the Stop entry pointing to the same script.
`poll_events()` consumes `~/.mation/stop-<session_id>` files
identically for both CC and Codex sessions. This is the v3 stance —
the v2 "open question" about legacy notify payload is now fully
resolved via the `ClaudeHooksEngine` + `StopRequest` evidence, no need
to fall back to the legacy notify path.

### 5.3 Question 3 — input injection

**Answer**: Depends on execution mode.

- **TUI mode inside cmux**: identical to CC. Codex TUI is a keystroke-driven
  terminal app; `cmux.send_text(surface_id, msg)` + Enter submits. I did
  not find evidence that Codex uses a non-standard submit key, but this
  is an **open question** (§10) — needs a live test.
- **`codex exec` (non-interactive)**: prompt is an argv positional or
  stdin pipe. One-shot: process starts, runs, exits. You can't "send
  more" to a finished exec process; you'd `codex exec resume <id>` to
  continue the session, which starts a new process with the prior
  history. That's a **different architecture** than mation's long-lived
  Worker model and is not what v1 targets.

Evidence:
- `codex-rs/exec/src/cli.rs` — `prompt: Option<String>` field, doc
  comment: "Initial instructions for the agent. If not provided as an
  argument (or if `-` is used), instructions are read from stdin. If
  stdin is piped and a prompt is also provided, stdin is appended as a
  `<stdin>` block."
- TUI submit-key behavior — not found in source inspection budget.

**Fit with T7**: v1 CodexAgent targets TUI-in-cmux mode, same `Agent.send()`
path as CC. This is good news: the abstraction doesn't need a per-agent
submit-key parameter.

### 5.4 Question 4 — headless / exec mode

**Answer**: Yes, fully supported and machine-friendly.

- `codex exec [PROMPT]` runs one turn non-interactively.
- `--json` (alias `--experimental-json`) prints events to stdout as JSONL.
- `-o / --output-last-message FILE` writes the final assistant message to
  a file — literally a built-in `last_message()` equivalent.
- `--ephemeral` runs without persisting session files.
- Event schema (`exec_events.rs`):
  `ThreadEvent::ThreadStarted { thread_id }` /
  `TurnStarted {}` / `TurnCompleted { usage }` / `TurnFailed { error }` /
  `ItemStarted/Updated/Completed { item: ThreadItem }` / `Error { message }`.
  Each emitted with `#[serde(tag = "type")]` as `thread.started` etc.

Evidence:
- `codex-rs/exec/src/cli.rs` — full flag set.
- `codex-rs/exec/src/exec_events.rs` — full ThreadEvent enum.
- `codex-rs/exec/src/event_processor_with_jsonl_output.rs` — the JSONL
  emitter itself.

**Fit**: This is an **alternative architecture** for CodexAgent —
per-turn `codex exec` invocations instead of a long-lived TUI. mation
would hold the session id, invoke `codex exec resume <id> <prompt>
--json -o last.txt`, parse stdout events until `turn.completed`, read
`last.txt`. No hooks needed, no cmux needed, no stall polling needed
(the process lifetime *is* the stall clock).

v1 does **not** adopt this architecture because:
1. It's a fundamentally different ownership model (mation spawns
   per-turn subprocesses instead of observing a peer).
2. The existing Worker CC mental model (Human starts a CC, mation
   observes) breaks.
3. Direction 3 (Auto Worker Spawn) is the natural home for this
   subprocess-ownership pattern.

v1 notes it as a future CodexAgent variant (§7 seam for direction 3).

### 5.5 Verdict

Codex CLI is a **viable and well-matched** second agent. The abstraction
survives contact with it: all 5 methods map cleanly, and the asymmetries
that exist (SQLite state DB for metadata vs JSONL for rollouts, richer
event schema for exec mode) are captured in `AgentStatus.metadata` and
future extension points — they do not force the core protocol wider.

The validation is strong enough to proceed with implementation plans
without picking up a third candidate.

## 6. CodexAgent pseudo-implementation (TUI-in-cmux mode, v3 target)

v3 update: rewritten to use the `ClaudeHooksEngine` path for stop
events (Plan #16 finding §5.2) and Codex's built-in
`--output-last-message FILE` flag to avoid re-parsing the rollout
JSONL schema.

```python
class CodexAgent:
    name = "codex"

    def status(self, session: str) -> AgentStatus:
        # session is the human-chosen thread name registered in
        # ~/.codex/sessions/session_index.jsonl via append_thread_name.
        # Resolve name → UUID via the index, then ps grep for codex
        # process carrying that UUID.
        codex_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
        thread_id = _find_codex_thread_id_by_name(codex_home, session)
        # thread_id may be None for newly-spawned sessions before
        # append_thread_name has been called — treat as "unknown".

        pid = _find_codex_pid_by_uuid(thread_id) if thread_id else None
        rollout = _find_codex_rollout(codex_home, thread_id) if thread_id else None

        last_activity = None
        if rollout and rollout.exists():
            last_activity = datetime.fromtimestamp(
                rollout.stat().st_mtime, tz=timezone.utc
            )

        surface = _read_env_from_pid(pid, "CMUX_SURFACE_ID") if pid else None

        return AgentStatus(
            session_id=session,
            running=pid is not None,
            pid=pid,
            last_activity=last_activity,
            surface_hint=surface,          # cmux handle in v3; Terminal abstraction in direction 2
            metadata={
                "codex_home": str(codex_home),
                "thread_id": thread_id or "",           # UUID once known
                "rollout_path": str(rollout) if rollout else "",
            },
        )

    def poll_events(self, session: str) -> list[AgentEvent]:
        # CodexAgent ships the same on-stop.sh script as CCAgent, installed
        # in ~/.codex/hooks.json rather than CC's settings.json. The
        # ClaudeHooksEngine (codex-rs/hooks/src/engine/mod.rs:63) invokes
        # it with a StopRequest payload that is a superset of CC's Stop
        # payload (codex-rs/hooks/src/events/stop.rs:22-32), so
        # on-stop.sh's `.session_id` read and `stop-<session_id>` write
        # work unchanged. poll_events reads the signal file exactly like
        # CCAgent.
        codex_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
        thread_id = _find_codex_thread_id_by_name(codex_home, session)
        if not thread_id:
            return []

        sf = STATE_DIR / f"stop-{thread_id}"
        if not sf.exists():
            return []

        try:
            payload = json.loads(sf.read_text())
            reply_text = payload.get("last_assistant_message", "")
        except (json.JSONDecodeError, OSError):
            reply_text = ""
        sf.unlink(missing_ok=True)    # consume-once

        return [StopEvent(
            ts=datetime.now(timezone.utc),
            reply=AgentMessage(text=reply_text),
        )]

    def last_message(self, session: str) -> AgentMessage | None:
        # v3: zero-parse path. Codex exposes `--output-last-message FILE`
        # on `codex exec`, writing the last assistant message to a
        # caller-declared file. For a resumed session the exec command
        # returns immediately (no new turn), just materializing the
        # current tail into the file.
        #
        # Requires `codex exec resume <thread_name> --ephemeral
        # --output-last-message <tmpfile>`. --ephemeral prevents writing
        # a new rollout on this no-op resume. The alternative would be
        # to tail-scan ~/.codex/sessions/rollout-*-<uuid>.jsonl for the
        # latest assistant ResponseItem variant, which requires a
        # schema-specific parser (different from CC's JSONL tail format).
        # --output-last-message is cleaner and requires no schema
        # knowledge on mation's side.
        codex_home = Path(os.environ.get("CODEX_HOME", Path.home() / ".codex"))
        thread_id = _find_codex_thread_id_by_name(codex_home, session)
        if not thread_id:
            return None

        with tempfile.NamedTemporaryFile(
            mode="r", suffix=".txt", delete=False
        ) as tmp:
            tmp_path = Path(tmp.name)
        try:
            subprocess.run(
                [
                    "codex", "exec", "resume", thread_id,
                    "--ephemeral",
                    "--output-last-message", str(tmp_path),
                ],
                check=False, capture_output=True, timeout=10,
            )
            if not tmp_path.exists() or tmp_path.stat().st_size == 0:
                return None
            text = tmp_path.read_text(encoding="utf-8", errors="replace")
        finally:
            tmp_path.unlink(missing_ok=True)

        # Codex's exec output does not carry a ts in the file content.
        # Fall back to rollout file mtime as a best-effort stamp, or
        # leave ts as None. Byte-identity to upstream source is N/A here
        # — the file is caller-declared, not agent-declared.
        return AgentMessage(text=text, ts=None)

    def send(self, session: str, text: str) -> None:
        # TUI-in-cmux mode: identical wire path to CCAgent, just a
        # different cmux surface id. Direction 2 (Multi-Terminal) will
        # replace cmux with an injected Terminal.
        info = self.status(session)
        if not info.running or not info.surface_hint:
            raise AgentUnavailable(
                f"Codex session {session!r} not running or no surface"
            )
        cmux.send_text(info.surface_hint, text)   # sleep + Enter internal

    def interrupt(self, session: str) -> None:
        info = self.status(session)
        if not info.running or not info.surface_hint:
            raise AgentUnavailable(
                f"Codex session {session!r} not running or no surface"
            )
        cmux.send_escape(info.surface_hint)
```

**Bootstrap requirement** (Plan #16 Gap #1 + §5.2 install):

A new session's one-time setup:

1. User starts Codex: `codex` (TUI) or `codex exec --json ...`.
2. mation reads `thread_id` from the first `thread.started` event (or
   from the latest rollout filename).
3. mation calls `append_thread_name(codex_home, thread_id, human_name)`
   to register the alias in `session_index.jsonl`.
4. mation ensures `~/.codex/hooks.json` contains the Stop hook entry
   pointing to `~/.mation/on-stop.sh` — the **same file already used
   by CC**. One script, two agents, zero code duplication.

Follow-up plan (Phase F §13.5): `mation agent install codex` setup
subcommand that writes `~/.codex/hooks.json` on first use. The
subcommand is idempotent — re-running it on an already-installed host
is a no-op.

## 7. Open seams for directions 2 and 3

This plan does not implement either direction, but v1 reserves the
seams so later plans don't have to reshape the core protocol.

### 7.1 Direction 2 — Multi-Terminal (future `Terminal` interface)

Touchpoint T2 and T7 currently hard-code cmux. The `surface_hint` field
on `AgentStatus` and the cmux calls inside `Agent.send()` / `interrupt()`
are the exact sites that need abstraction.

Planned shape (not v1):

```python
class Terminal(Protocol):
    def send_text(self, surface: str, text: str) -> None: ...
    def send_key(self, surface: str, key: str) -> None: ...
    def discover_surface(self, pid: int) -> str | None: ...
```

Migration path:
1. Extract current `cmux.py` calls behind a `CmuxTerminal(Terminal)` impl.
2. `Agent.__init__(self, terminal: Terminal)` — constructor injection, no
   per-call parameter change.
3. `AgentStatus.surface_hint` becomes terminal-opaque; Agent impl asks
   its injected Terminal via `discover_surface(pid)`.
4. Add `TmuxTerminal`, `ScreenTerminal`, etc. alongside `CmuxTerminal`.

**Breaking change risk**: zero for existing CC users — CcAgent defaults
to CmuxTerminal, behavior identical.

### 7.2 Direction 3 — Auto Worker Spawn (future `spawn()` method)

Current flow: Human launches CC in cmux → copies session name → runs
`mation worker add`. Direction 3 wants `mation worker spawn --agent cc`
to do both steps automatically.

Two options for where `spawn` lives:

```python
# Option A: instance method on Agent
class Agent(Protocol):
    def spawn(self, cwd: Path, terminal: Terminal) -> SpawnedSession: ...

# Option B: class/module-level factory with Agent registry
def spawn_agent(agent_name: str, cwd: Path, terminal: Terminal) -> SpawnedSession: ...
```

Option A couples spawn to the protocol; Option B keeps `Agent` narrow
and lets `spawn` live in a registry module. **Recommendation for
direction 3 plan: Option B**, because not all agents will be spawnable
(some may only be adoptable), and Protocol members that throw
`NotImplementedError` defeat the point of Protocols.

The `codex exec --json` architecture from §5.4 is the best candidate for
the first `spawn`-mode implementation: fully headless, fully observable
via stdout JSONL, no cmux coupling.

**v1 stance**: `Agent` protocol has no `spawn()`. Auto Spawn is a
direction 3 plan that adds a separate spawn registry without
renegotiating the core protocol.

## 8. Backward compatibility checklist

The v1 implementation must leave every existing CC workflow
byte-identical. The following regressions must be explicitly covered
by the implementation plan's test suite:

| Workflow | Current path | Post-abstraction path | Test must cover |
|---|---|---|---|
| `mation worker add <session>` | `worker.py:resolve_worker` | `CCAgent().status()` returns `running=True` with same pid, surface_id, jsonl_path | existing worker add smoke |
| `mation send "hello"` | `cli.py:send()` → `cmux.send_text` | `CCAgent().send()` → same `cmux.send_text` | transcript write, cmux delivery idempotent |
| `mation read` | `worker.py:read_last_message` | `CCAgent().last_message().text` equals today's output | byte-for-byte of existing read |
| daemon stop event | `daemon.py` reads `stop-*` signal file | `CCAgent().poll_events()` returns `[StopEvent]`, consumes file identically | signal file unlinked exactly once |
| daemon stall event | mtime heuristic in daemon | daemon computes from `CCAgent().status().last_activity` | same stall threshold fires at same age |
| `mation group show` users section | `find_supervisor` / `iter_workers` + inline liveness | `CCAgent().status()` for each user | no schema change to group.json |
| `mation transcript` | unchanged | unchanged — transcript write sites in cli.py/daemon.py call `append_transcript` before/after `Agent.send/poll_events` | transcript entries identical to today |
| CC hooks install | existing `on-stop.sh` + settings.json | unchanged in v1 — CCAgent keeps using the same signal-file contract | `on-stop.sh` and settings.json byte-identical |

The abstraction introduction itself should land as a no-op refactor:
same tests, same state, same behavior. Only then can CodexAgent land as
a purely additive change.

## 9. Implementation plan breakdown (suggested follow-ups) — **SUPERSEDED**

> **⚠ Superseded by §13.5 (Plan #16 feasibility analysis).**
>
> v1/v2 of this doc proposed an 8-plan breakdown below (Plans #12-19
> in the old numbering). Plan #16's feasibility analysis produced a
> revised 8-phase breakdown (**Phase A-H**) grounded in the actual
> Codex / tmux research. **Use §13.5 as the canonical implementation
> plan list.** The list below is retained as **historical context**
> for readers comparing v2 and v3 of this doc — do **not** act on it.
>
> Key differences between the two:
> - v2 §9 assumed Plan #11 §3 was the last word on the Protocol shape;
>   §13.5 takes Plan #14 walking-skeleton results (§3.6 discrepancies)
>   into account.
> - v2 §9 grouped "Protocol + CCAgent implementation" into a single
>   Plan #13; §13.5 splits it into Phase B Plan #18 (status + poll_events)
>   and Phase B Plan #19 (send + interrupt) for smaller reviewable units.
> - v2 §9 placed CodexAgent as Plan #17 with a `config.toml [notify]`
>   install; §13.5 places it as Phase F with the `~/.codex/hooks.json`
>   install per Plan #16's `ClaudeHooksEngine` discovery.

v1 design approval should open these follow-up plans. Each is
committable and revertible independently.

1. **Plan #12 — scaffold `Agent` protocol + data models**. Add
   `mation/agent/__init__.py`, `agent/protocol.py`, `agent/models.py`.
   Pure type definitions, no implementations, no wiring. Tests:
   Pydantic model validation round-trips for `AgentStatus`,
   `AgentMessage`, `StopEvent`.

2. **Plan #13 — `CCAgent` implementation, no wiring**. Add
   `mation/agent/cc.py` implementing the 5 methods against existing
   `worker.py` / `cmux.py` helpers. Tests: each method against a
   mocked `~/.mation/stop-*` / JSONL fixture, no daemon / cli changes.

3. **Plan #14 — migrate `daemon.py` to use `CCAgent`**. Replace inline
   `resolve_worker` / `read_last_message` / signal-file logic with
   calls to a single registered `CCAgent` instance. Daemon keeps the
   stall heuristic itself (reads `agent.status().last_activity`).
   Regression tests: all stop/stall behavior identical by inspection
   of `daemon.log` output.

4. **Plan #15 — migrate `cli.py` send/kick/read to `CCAgent`**.
   `cmux.send_text` stays inside `CCAgent.send()`; transcript write in
   `cli.send()` wraps `agent.send()` with the same fire-and-forget
   semantics.

5. **Plan #16 — agent registry + `--agent` flag on `group create`**.
   Add `mation/agent/registry.py` that holds `{ "claude-code": CCAgent() }`.
   group.json gains an optional `agent: str` field defaulting to
   `"claude-code"` on read for backward compat. Daemon and CLI resolve
   the agent per group via the registry.

6. **Plan #17 — `CodexAgent` v1 (TUI-in-cmux mode)**. Add
   `mation/agent/codex.py`, `mation agent install codex` setup command
   that writes the notify hook to `~/.codex/config.toml`. Tests against
   a fixture `~/.codex/sessions/rollout-*.jsonl` file.

7. **Plan #18 — direction 3 exploration**: `spawn()` registry + headless
   CodexAgent mode using `codex exec --json`. Separate group direction,
   not a dependency of Plans #12-17.

8. **Plan #19 — hygiene**: delete `on-submit.sh`, `on-notification.sh`,
   and their unused signal-file cleanup paths in `state.py` (`delete_all`
   still loops over `submit-*`).

Plans #12-16 must all land before #17 starts — CodexAgent has nothing
to talk to until the registry exists.

## 10. Open questions for v3

**v2 → v3 change**: reduced from three to two. v2 OQ #2 ("Codex legacy
notify JSON payload") is **resolved in v3 via §5.2** — Plan #16 cloned
the Codex tree and found both the `ClaudeHooksEngine` path (which
reuses CC's exact Stop hook protocol byte-for-byte) and the full
`StopRequest` struct at `codex-rs/hooks/src/events/stop.rs:22-32`. The
worry was unnecessary; the `hooks.json` path is cleaner than the legacy
notify path anyway.

The remaining two open questions:

1. **Codex TUI submit key**: confirm Enter submits in Codex TUI (vs
   Ctrl+Enter, Ctrl+J, or similar). Needs a live test on `my-laptop`.
   If different, `Agent.send()` may need a per-impl `_submit_key`
   attribute or a `SubmitKey` enum on `Agent`. **Phase F Plan #23**
   (CodexAgent first-class, §13.5) will open a sub-plan for the live
   test before coding `CodexAgent.send()`. Not a blocker for design
   approval.

2. **Per-group agent selection migration**: group.json currently
   has no `agent` field. **Phase E Plan #22** adds it with a default
   `"claude-code"`. Existing production missions without the field
   should get CC implicitly via `_migrate_group_shape`. Explicit
   re-save at migration time vs lazy default-on-read is a Plan #22
   design decision — not v3's call.

## 11. What v1 is **not** doing

Explicit non-goals so scope doesn't drift:

- Not implementing any `.py` file — this is design only.
- Not making any `Agent` method optional or defaulted — Protocol members
  are all required; if an impl can't do `interrupt()`, that's an impl
  bug we'll discover in Plan #13.
- Not designing an event subscription / async model. v1 is polling.
- Not modeling tool calls, permissions, plan mode, or any other
  richer agent event stream. `StopEvent` is the only v1 event.
- Not designing a `Terminal` interface. §7.1 sketches it; Direction 2
  plan will own it.
- Not designing a `spawn()` factory. §7.2 sketches it; Direction 3
  plan will own it.
- Not deleting `on-submit.sh` / `on-notification.sh`. Hygiene plan (§9
  Plan #19) will do that.

---

**End of v3 draft.** Plan #14 discrepancies (§3.6) resolved and
absorbed. Plan #16 feasibility verdict (§13) confirmed feasible, with
the `ClaudeHooksEngine` finding upgrading §5.2's Codex hook story from
"legacy notify, payload TBD" to "byte-compatible CC protocol, install
`hooks.json`". v3 is ready for Phase A (this doc's own v3 bump, just
done) → Phase B (first code walking skeletons for `status()` /
`poll_events()`) per §13.5.

---

## 12. Cmux touchpoint inventory (Plan #14 Part 2)

Appended after Plan #14 walking-skeleton Part 2 cmux survey. Same
methodology as §2's CC touchpoint table: grep the tree for every site
that touches cmux, record `file:line`, the cmux call/concept, what the
site assumes, and a rough future `Terminal` method candidate. This is
**inventory only**: no `Terminal` Protocol is designed here, no
`CmuxTerminal` class is written. Direction 2 (Multi-Terminal) will own
the design plan; v1 just wants to know the shape and size of the seam
before committing to a Protocol.

### 12.1 Touchpoint table

| # | Location | Cmux surface | Assumption | Future `Terminal` method candidate |
|---|---|---|---|---|
| **C1** | `mation/cmux.py:14-17` | `SOCKET_PATH` from `CMUX_SOCKET_PATH` env or default `~/Library/Application Support/cmux/cmux.sock` | cmux installed locally; socket reachable; macOS default path baked in | Each `Terminal` impl picks its own transport config |
| **C2** | `mation/cmux.py:20-32` `rpc(method, params)` | JSON-RPC over unix socket | cmux `automation` mode enabled; socket speaks JSON-RPC | `Terminal` impls pick transport (tmux CLI / tmux socket / screen / native) |
| **C3** | `mation/cmux.py:35-36` `get_current_surface()` reads `CMUX_SURFACE_ID` env | **Dead code** — never called anywhere in `mation/` | Self-discovery of current surface via env | `Terminal.current_surface()` optional — delete on migration |
| **C4** | `mation/cmux.py:39-43` `send_text(surface_id, text)` | Sends `surface.send_text` + `time.sleep(1)` + `send_key("Enter")` | Surface active; agent input-box uses Enter to submit; cmux/CC needs ~1s to process pasted text before Enter fires | `Terminal.send_text_with_submit(handle, text)` — encapsulates the sleep + submit-key detail |
| **C5** | `mation/cmux.py:46-47` `send_escape(surface_id)` | `surface.send_key("escape")` | Escape is the agent's cancel key | `Terminal.send_key(handle, "escape")` or `Terminal.interrupt(handle)` |
| **C6** | `mation/cmux.py:50-55` `ping()` | `system.ping` health probe | **Dead code** — never called anywhere in `mation/` | `Terminal.health()` optional — delete on migration |
| **C7** | `mation/worker.py:160-161` `_read_env_from_pid(pid, "CMUX_WORKSPACE_ID")` + `CMUX_SURFACE_ID` | Reads cmux ids from CC process env via `ps eww -p <pid>` | Agent process is a cmux child; inherits env vars; `ps eww` available (macOS flag) | `Terminal.discover_surface(pid) -> handle \| None` |
| **C8** | `mation/worker.py:22` `WorkerInfo.surface_id: str \| None` + `worker.py:178-179` `worker_cache_from_info` stores `cache["surface_id"]` | Surface id is a stable UUID string, cacheable in group.json | Handle type assumed `str`; see §10 OQ #3 on `surface_hint → terminal_handle` rename | `Terminal`'s handle type should be an opaque string or bytes — impls differ |
| **C9** | `mation/daemon.py:54-58` `_send_to_surface(surface_id, message)` | Wraps `cmux.send_text` with `try/except RuntimeError → log.error` | cmux RPC raises `RuntimeError` on error; swallow + log | `Terminal` should define a unified error type instead of per-impl `RuntimeError` |
| **C10** | `mation/daemon.py:73-76` guard `not info.running or not info.surface_id` | Preconditions for `notify_supervisor` | Reachability = running PID + cached surface id | `Terminal.reachable(handle) -> bool` |
| **C11** | `mation/daemon.py:80` `safe_message = message.replace("\n", " ")` | Caller-side hack: newlines in cmux paste trigger Escape which breaks CC generation | **cmux+CC-specific bug**, not generic terminal concern | Must be solved at message-construction layer, not `Terminal` |
| **C12** | `mation/daemon.py:85` `_send_to_surface(info.surface_id, safe_message)` | Actual notify-supervisor send | Same as C4 via wrapper | Same as C4 |
| **C13** | `mation/cli.py:666-669` `send()` → `cmux.send_text(info.surface_id, message)` | Primary user-input delivery | Surface active; action method (per §3.4) must raise on unreachable session before calling | Same as C4 |
| **C14** | `mation/cli.py:695-700` `kick()`: `send_escape` + `time.sleep(1)` + `send_text("继续当前任务")` | Interrupt+resume pattern — escape to cancel, wait, then text to re-prompt | Caller-side sleep is another cmux/CC timing hack mirroring C4's internal sleep | `Terminal.interrupt(handle)` + `Terminal.send_text_with_submit(handle, text)`; caller still owns the delay (see Plan #11 §3.2 `interrupt()` docstring) |
| **C15** | `mation/cli.py:429, 438, 528, 582, 615, 639` | Display strings `PID {info.pid}, surface {info.surface_id}` in `group show`, `group claim`, `worker add`, `worker ls`, `worker show` | Human UX leaks cmux surface-id UUID shape | `Terminal.display_handle(handle) -> str` optional, or accept that handle format is user-visible |

### 12.2 Observations

**Total touchpoints**: **15**, spanning 4 files (`cmux.py`, `worker.py`,
`daemon.py`, `cli.py`). `cmux.py` is the only "pure" cmux wrapper
(6 touchpoints). The other 9 are caller sites that assume cmux
semantics.

**Categorization**:

- **Direct cmux RPC** (4): C2, C4, C5, C6 — all inside `cmux.py`.
- **Env-var discovery** (1): C7 in `worker.py`.
- **Constants / transport config** (1): C1 `SOCKET_PATH`.
- **State carrying surface id** (1): C8 `WorkerInfo.surface_id` + cache.
- **Caller wrappers around cmux** (4): C9, C10, C12, C13.
- **Caller-side timing/escape hacks** (2): C11 (`\n → space`), C14
  (`kick()` sleep).
- **Display leakage** (1): C15 — six echo sites reusing the same pattern.

**Dead code found**: two of the six functions in `cmux.py` are
**unreachable from anywhere in `mation/`**:

- `cmux.get_current_surface()` (C3) — defined, imported by nobody.
- `cmux.ping()` (C6) — defined, imported by nobody.

They were likely intended for a readiness/self-check path that was
either never wired or was dropped during earlier refactors. **Delete
candidates for Plan #19 (hygiene).** Not this plan's scope.

**Caller-side hacks that will be the hardest to abstract**:

- **C11 `safe_message.replace("\n", " ")`** — this isn't about cmux the
  IPC layer, it's about **cmux running CC in a terminal where newlines
  trigger Escape which interrupts CC generation**. A generic `Terminal`
  interface can't solve this: it belongs at the message-construction
  layer (daemon must never produce multi-line stall/stop messages in the
  first place). Plan #4 already moved stall messages to single-line; the
  `replace` is defense-in-depth that should survive the Terminal
  abstraction.

- **C4 internal `time.sleep(1)` + C14 external `time.sleep(1)`** — the
  1-second wait appears in two places, once as cmux-internal
  (`send_text` always waits) and once as caller-side (`kick` waits
  between escape and text). They encode the same cmux/CC paste-settle
  timing but at different layers. Any `Terminal.send_text_with_submit`
  will have to absorb at least the paste-settle case; the kick timing
  stays at the caller per the Plan #11 §3.2 `interrupt()` contract.

**Pretend-but-not-really cmux uses**: C15 — the six `surface {...}`
echo sites don't actually call cmux, they just read cached surface ids
and print them. They're not functional touchpoints, but they bake the
UUID-string shape of cmux handles into user-visible output. A future
Terminal with different handle format (tmux `%0`, screen `1.0`, a TCP
endpoint) will force all six display strings to change. A
`Terminal.display_handle(handle)` optional method could hide this, or
the display can just accept that handles are user-visible and of
impl-specific shape.

**Reachability gate C10** assumes surface-id-or-nothing. Once
`Terminal` lands, "reachable" becomes a per-impl question (socket
open? pane alive? TTY attached?) and shouldn't be derivable from a
single cached string. Plan #11 §3.1 `AgentStatus.running` already
returns `bool`; the Terminal abstraction should expose its own
`reachable(handle)` that `AgentStatus.running` queries, not the other
way around.

**Migration scale estimate**: 15 touchpoints but only ~6 are
**substantive logic** that would change shape under a `Terminal`
abstraction (C1, C2, C4, C5, C7, C11). The rest are wrappers (C9, C12,
C13, C14) or state carriers (C8, C10, C15) that the Direction 2 plan
can mostly mechanical-refactor once the `Terminal` Protocol is agreed.
**Direction 2 is larger than Direction 1 by about 2×** — more
touchpoints, more entrenched timing assumptions, and the dead-code
cleanup (C3, C6) piggybacks on it. Suggest allocating roughly twice the
walking-skeleton effort (i.e. two Plan-#14-sized spikes plus the
follow-up migrations) before committing to the full `Terminal`
Protocol shape.

### 12.3 What §12 does **not** do

- No `Terminal` Protocol design — that's the Direction 2 Plan.
- No `CmuxTerminal` class — same reason.
- No deletion of `get_current_surface` / `ping` — belongs in Plan #19
  (hygiene) or the Direction 2 migration, whichever lands first.
- No impact on Plan #14 Part 1's `Agent` scope. `Agent.status()` and
  `Agent.send()` (future plans) will consume Terminal, not contain it.

---

## 13. Feasibility analysis — Codex / tmux equivalents (Plan #16)

**Status**: engineer-route feasibility check. Zero code. Every `✅` has a
source reference: `codex-rs/...:line`, `man tmux` section, or tmux doc URL.
Every `❌` / `❓` has the specific thing that was searched and either
missed or confirmed absent.

**Methodology**:
1. Clone `openai/codex` at `main` to `/tmp/codex-research` (`git clone --depth=1`). Read `codex-rs/hooks/`, `codex-rs/rollout/`, `codex-rs/exec/`, `codex-rs/core/src/config/mod.rs`, `docs/config.md`, and related files directly — no WebFetch fragments.
2. `man tmux` on-host + cross-reference with https://github.com/tmux/tmux.
3. For each CC touchpoint in §2 (T1-T11) check Codex. For each cmux touchpoint in §12 (C1-C15) check tmux.
4. Classify each cell: `✅ <evidence>` / `❓ <what was searched>` / `N/A` (touchpoint doesn't belong to this axis) / `❌ <confirmed absent>`.

### 13.1 CC touchpoints → Codex equivalence matrix

| # | CC touchpoint | Codex equivalent | Evidence / gap |
|---|---|---|---|
| **T1** | `worker.py:28 _find_claude_pid` — ps grep `claude --resume/--name <session>` | **⚠ Partial**. Codex supports resume via `codex exec resume <UUID-or-thread-name>`, and named threads exist via `session_index.jsonl`. But Codex has **no `--name` launch flag** that fingerprints the process in argv at startup — the name is assigned post-first-turn. | `codex-rs/exec/src/cli.rs:115-145` (Resume command); `codex-rs/rollout/src/session_index.rs:116 find_thread_path_by_name_str`. **Gap**: `ps` reverse-lookup must match by UUID only (not name) at launch time; named resolution happens via `session_index.jsonl` lookup after first turn. Workaround: CodexAgent.status() takes session string, resolves via `session_index.jsonl` → UUID → ps grep for `codex.*<UUID>`. |
| **T2** | `worker.py:71 _read_env_from_pid CMUX_WORKSPACE_ID / CMUX_SURFACE_ID` | **N/A** — T2 reads cmux env, not CC env. This belongs in the cmux→tmux axis (§13.2 C7). | — |
| **T3** | `worker.py:96 _find_jsonl` — find `~/.cac/.../{uuid}.jsonl` or customTitle-matched file | **✅ Full**. Codex rollouts at `$CODEX_HOME/sessions/rollout-<RFC3339>-<uuid>.jsonl`; `find_thread_path_by_id_str` does the UUID lookup; `find_thread_path_by_name_str` does the name lookup via session_index. Simpler and cleaner than CC's customTitle scan. | `codex-rs/rollout/src/recorder.rs:67-68,670-683` (filename formula); `codex-rs/rollout/src/list.rs:1256-1264 find_thread_path_by_id_str`; `codex-rs/rollout/src/session_index.rs:116` |
| **T4** | `worker.py:196 read_last_message` — reverse-scan JSONL for `{type: "assistant", ...}` | **✅ Full with a cleaner path available**. Rollout JSONL has a different schema (`ResponseItem` variants per entry — see `codex-rs/rollout/src/policy.rs`), so reverse-scan logic would need to target Codex's `AssistantMessage` variant, not CC's `{type:"assistant"}`. But **there's a built-in shortcut**: `codex exec --output-last-message FILE` writes the last assistant message to a file directly — mation can use this for headless operation, bypassing rollout parsing entirely. | `codex-rs/rollout/src/recorder.rs:67-68`; `codex-rs/exec/src/cli.rs:103 --output-last-message`. Schema gap is real (CC and Codex rollout formats differ) but is abstracted at the `read_last_message` layer — each agent impl owns its own tail-scan. |
| **T5** | `daemon.py:154 stop branch` — reads `~/.mation/stop-<session_id>` signal file written by CC Stop hook; reads `last_assistant_message` field | **✅ FULL — byte-compatible**. Codex implements a `ClaudeHooksEngine` that replays CC's exact Stop hook protocol. The `StopRequest` struct carries `session_id, turn_id, cwd, transcript_path, model, permission_mode, stop_hook_active, last_assistant_message` — a **superset** of CC's payload. mation's existing `on-stop.sh` script reads `.session_id` and writes to `stop-<session_id>`; the **same script works verbatim for Codex**. | `codex-rs/hooks/src/engine/mod.rs:63 ClaudeHooksEngine`; `codex-rs/hooks/src/events/stop.rs:22-32 StopRequest`; `codex-rs/hooks/src/engine/discovery.rs:33-90` (loads from `hooks.json` in config layers). Note: Codex also has `legacy_notify_argv` as an alternate path (`codex-rs/hooks/src/legacy_notify.rs`) which emits the same `last_assistant_message` field. |
| **T6** | `daemon.py:178 stall branch` — JSONL file mtime as heartbeat | **✅ Full**. Codex rollout file mtime updates per turn via `recorder.rs`'s `AsyncWriteExt` flush. Same mtime-as-heartbeat technique works. | `codex-rs/rollout/src/recorder.rs` — `RolloutRecorder` flushes per write |
| **T7** | `cli.py:666 send()` — cmux.send_text + sleep + Enter | **N/A for CC→Codex axis**. T7 is a cmux touchpoint, not CC-specific. See §13.2 C4. | — |
| **T8** | `cli.py:688 kick()` — cmux.send_escape | **N/A**. Same — cmux axis. See §13.2 C5. | — |
| **T9** | `cli.py:694 mation read` — delegates to T4 | **✅ Full (same as T4)**. Directly reuses T4 mechanism. | — |
| **T10** | `~/.mation/on-stop.sh` + `settings.json` `hooks.Stop` wiring | **✅ FULL — same file, different config location**. CC installs via `~/.cac/envs/main/.claude/settings.json` → `"hooks": {"Stop": [...]}`. Codex installs via `~/.codex/hooks.json` → identical `{"hooks": {"Stop": [...]}}` structure because Codex reimplements CC's hook schema. **Literally the same on-stop.sh shell script runs under both agents.** mation just installs it in two places. | `codex-rs/hooks/src/engine/discovery.rs:37 "hooks.json"`; `codex-rs/hooks/src/engine/config.rs` `HooksFile` struct |
| **T11** | Session identity — human-chosen name via `claude --name <X>` | **⚠ Partial**. Codex supports named threads (`append_thread_name(uuid, name)`) but **the name is assigned after thread creation**, not at launch. There's no `codex --name my-worker` equivalent. Workaround: CodexAgent spawns with UUID, then immediately calls `append_thread_name` to register the human name → mation's session string maps to thread name, resolved via `session_index.jsonl` to UUID at each `status()` call. | `codex-rs/rollout/src/session_index.rs:28 append_thread_name`. Gap is **semantic** (post-hoc naming vs. at-launch naming), not structural — a 3-line CodexAgent bootstrap sequence closes it. |

**CC → Codex coverage**: **9 of 9 CC-axis touchpoints** covered (T2/T7/T8 excluded as cmux-axis). **7 full ✅**, **2 partial ⚠ with known workarounds**, **0 missing ❌**. Coverage: **100% functional, 78% zero-workaround**.

### 13.2 cmux touchpoints → tmux equivalence matrix

| # | cmux touchpoint | tmux equivalent | Evidence / gap |
|---|---|---|---|
| **C1** | `cmux.py:14 SOCKET_PATH` — `~/Library/Application Support/cmux/cmux.sock` | **✅ Full**. tmux socket path in `$TMUX` env var (format `path,pid,session`); also configurable via `-S /path` flag. Conceptually identical transport layer (Unix socket), different protocol. | `man tmux` DESCRIPTION section (page intro); `$TMUX` per ENVIRONMENT section line ~3297 |
| **C2** | `cmux.py:20 rpc(method, params)` — JSON-RPC over socket | **✅ Full (different shape)**. tmux commands are invoked as shell (`tmux send-keys ...`, `tmux list-panes ...`) and each invocation connects to the server socket. Not JSON-RPC, but each command maps to an RPC equivalent. Subprocess-per-call cost is higher than cmux's persistent socket; on the order of ms, probably fine for mation's poll rates. | `man tmux` COMMANDS section line 399; subprocess invocation is standard shell pattern |
| **C3** | `cmux.py:35 get_current_surface()` — reads `CMUX_SURFACE_ID` env | **✅ Full (dead code on mation side anyway)**. tmux sets `TMUX_PANE` in every child process env. Parallel to `CMUX_SURFACE_ID`. And `CMUX_SURFACE_ID` is **dead code** in mation (§12 observation), so the equivalence is academic. | `man tmux` WINDOWS AND PANES, page line 503: "The pane ID is passed to the child process of the pane in the TMUX_PANE environment variable." |
| **C4** | `cmux.py:39 send_text(surface, text)` + `sleep(1)` + `send_key("Enter")` | **✅ Full**. `tmux send-keys -l -t <pane> "text"` sends literal UTF-8; separate `tmux send-keys -t <pane> Enter` submits. tmux has **no built-in paste-settle sleep** — caller would need to insert the 1s delay externally. This is actually cleaner than cmux's implicit sleep; the CmuxTerminal / TmuxTerminal impls can own the timing policy independently. | `man tmux` send-keys page line 1827: "-l flag disables key name lookup and processes the keys as literal UTF-8 characters" |
| **C5** | `cmux.py:46 send_escape(surface)` | **✅ Full**. `tmux send-keys -t <pane> Escape`. Key names documented. | `man tmux` send-keys page line 1827-1850 |
| **C6** | `cmux.py:50 ping()` | **✅ Full (dead code on mation side)**. `tmux has-session -t <name>` returns 0/1. Also `tmux list-sessions` exit status can serve as health. Dead code in mation, so equivalence is academic. | `man tmux` has-session (alias in COMMANDS section) |
| **C7** | `worker.py:160 ps eww CMUX_WORKSPACE_ID / CMUX_SURFACE_ID` — discover pane id from process env | **✅ Full**. `ps eww -p <pid>` on Linux/macOS reads any child process env including tmux-set `TMUX_PANE`. The discovery mechanism is identical; only the env var name changes. | `man tmux` line 503 confirming TMUX_PANE is in child env; POSIX `ps eww` is standard |
| **C8** | `WorkerInfo.surface_id: str \| None` + group.json cache | **✅ Full**. tmux pane id is an opaque string (`%0`, `%1`, ...), stable for the lifetime of the pane per tmux ID docs. Cache field just stores the string — format shape differs (`%0` vs UUID) but cacheability is identical. | `man tmux` WINDOWS AND PANES line 500: "These are unique and are unchanged for the life of the session, window or pane" |
| **C9** | `daemon.py:54 _send_to_surface` wrapping cmux.send_text | **N/A** — caller wrapper, adapts to whatever Terminal.send_text raises. Each impl picks its own error type. | — |
| **C10** | `daemon.py:73 reachability gate info.running or info.surface_id` | **✅ Full**. tmux `has-session -t <session>` or `list-panes -t <pane>` exit status provides reachability. | `man tmux` COMMANDS section |
| **C11** | `daemon.py:80 safe_message.replace("\n", " ")` — newline-to-space hack | **N/A — not a terminal concern**. This is a **cmux+CC bug specifically**: newlines delivered via cmux's paste buffer trigger Escape which interrupts CC generation. Whether the escape is generic to all terminals or specific to cmux's paste handling is unknown without further testing. Safe assumption: keep the replace as defense-in-depth regardless of Terminal backend. Not in the abstraction. | Inferred from `mation/daemon.py:77-78` comment "Escape will interrupt Claude Code generation" |
| **C12** | `daemon.py:85 _send_to_surface` | **N/A** — wrapper, same as C9 | — |
| **C13** | `cli.py:666-669 send()` → `cmux.send_text` | **✅ Full (via C4)** | — |
| **C14** | `cli.py:695-700 kick()` — escape + sleep + text | **✅ Full (via C4 + C5)**. The 1s sleep stays at the caller per Plan #11 §3.2 `interrupt()` docstring. Maps directly: `tmux send-keys Escape; sleep 1; tmux send-keys -l "继续当前任务"; tmux send-keys Enter`. | Same evidence as C4 and C5 |
| **C15** | `cli.py:429 etc.` — display string `surface {info.surface_id}` | **⚠ Partial**. tmux pane id format (`%0`) differs from cmux UUID. All 6 display sites output the handle verbatim, so the user would see `%0` instead of `XXXXXXXX-XXXX-...`. Functionally OK, visually different. Need a `Terminal.display_handle(handle) → str` shim or accept the format change. | `man tmux` line 500 confirms the format |

**cmux → tmux coverage**: **11 of 15 cmux touchpoints** have direct tmux equivalents; **4 N/A** (caller-side wrappers C9/C11/C12 or dead-code equivalents); **0 missing ❌**. Coverage: **100% functional, ~90% zero-workaround** (C15 display format shift is cosmetic).

### 13.3 Top 3 gaps (with workarounds)

**Gap #1 — Codex has no `--name` launch flag** (T1 / T11)

- **What**: `claude --name worker-1` starts a CC session whose argv contains the string "worker-1" immediately, so `ps` reverse-lookup works from the first process tick. `codex` has no equivalent. You get a UUID, and you can later alias it via `append_thread_name(uuid, name)`, but there is no process-fingerprint path until the alias is recorded in `session_index.jsonl`.
- **Impact**: `CCAgent.status(session)` can find a just-launched CC via ps grep. `CodexAgent.status(session)` **cannot** find a just-launched Codex via ps unless it's already been told the UUID.
- **Workaround**: `CodexAgent` spawn / attach flow must record the UUID at bootstrap time. Either:
  - (a) spawn via `codex exec --json` and read the `thread.started` event's `thread_id` from stdout, then `append_thread_name(uuid, human_name)` so future `status()` calls can resolve via `session_index.jsonl` → UUID → ps grep.
  - (b) track UUIDs in group.json as the primary identity, treat human names as optional aliases.
- **Cost**: Small (a few lines in CodexAgent bootstrap). Not a design-level blocker.

**Gap #2 — Codex rollout schema differs from CC JSONL schema** (T4)

- **What**: mation's `read_last_message` reverse-scans for `{"type": "assistant", "message": {"content": [...]}}`. Codex rollout writes `ResponseItem` variants (`AssistantMessage`, `UserMessage`, `ToolCall`, etc.) serialized differently.
- **Impact**: A shared `read_last_message` function cannot serve both. Each agent's `last_message` implementation owns its own tail-scan.
- **Workaround**: Two parallel helpers — `worker.py` already has `read_last_message` specific to CC, CodexAgent would add a `codex_rollout.read_last_message` specific to Codex schema. Alternatively, `codex exec --output-last-message FILE` is a **cleaner path** for headless CodexAgent mode: Codex writes the last assistant message to a pre-declared file on every turn, mation reads the file. No schema parsing needed on mation's side.
- **Cost**: Medium. Schema parsing is mechanical but each tail-scan needs its own test fixtures and malformed-line handling. The `--output-last-message` shortcut eliminates the cost entirely if CodexAgent targets headless exec mode.

**Gap #3 — cmux's implicit paste-settle sleep has no tmux counterpart** (C4)

- **What**: `cmux.send_text` internally waits 1s between text and Enter to let cmux's paste buffer settle before submit. tmux's `send-keys` has no such wait; it fires immediately.
- **Impact**: A naive `tmux send-keys text; tmux send-keys Enter` sequence may submit before the TUI has fully ingested the text, leading to truncated / corrupted input. This is a real operational concern, not theoretical.
- **Workaround**: Terminal abstraction should expose `send_text_with_submit(handle, text)` at the Protocol level, and each impl owns its own timing policy. `CmuxTerminal` wraps the current 1s sleep; `TmuxTerminal` may need its own sleep (probably shorter, since tmux is faster than cmux's web-based IPC), to be tuned empirically on my-laptop.
- **Cost**: Small-to-medium. The Protocol design is easy (one method with internal timing); the empirical tuning needs a real tmux + Codex session to validate. **This is the only gap that requires my-laptop experimentation before committing to a Terminal abstraction shape.**

### 13.4 Feasibility verdict

**Verdict: ✅ 可行 (Feasible) — proceed with Plan #11 Protocol as v3 (minor adjustments from Plan #14 discrepancies), begin implementation.**

**Data supporting the verdict**:

- **CC → Codex axis**: 100% functional coverage, 0 missing features, 2 minor semantic gaps (T1/T11 both about pre-launch naming). Codex has **byte-compatible Stop hook payload** reusing the same `on-stop.sh` script. Codex has **first-class named session support** via `session_index.jsonl`. Codex has **built-in `--output-last-message FILE`** that eliminates rollout schema parsing if headless mode is chosen. **Strongly positive**: Codex implements `ClaudeHooksEngine` which literally replays CC's hook protocol — mation's tooling transfers with near-zero change.
- **cmux → tmux axis**: 100% functional coverage, 0 missing features, 1 cosmetic gap (C15 handle display format) and 1 timing gap (C4 paste-settle) that needs empirical tuning. All cmux primitives map to tmux subprocess equivalents: `send-keys`, `capture-pane`, `list-panes`, `has-session`, `set-environment`, `TMUX_PANE` env var. Subprocess-per-call cost vs cmux's persistent socket is the main non-functional difference, and at mation's poll rates (~2s) it's noise.
- **Plan #14 walking skeleton result**: `CCAgent.last_message` already wrapped existing CC logic and ran on my-laptop Linux against a real CC-written JSONL. The abstraction mechanism is proven — not speculative.
- **Plan #11 §3 Protocol shape survives**: None of the gaps force a structural change. The 3 discrepancies found in Plan #14 (`ts: str | None`, `AgentMessage | None` error collapse, DI hatch via impl-specific keyword args) are all field-level or extension-level, not method-level. The 5-method Protocol (`status`, `poll_events`, `last_message`, `send`, `interrupt`) remains the right shape.

**Why not "需改 design"**: no method signature needs to change; only field types and hook payload semantics need minor documentation updates. Plan #11 v3 is documentation maintenance, not design work.

**Why not "方向错"**: every required CC behavior has a Codex equivalent that exists **today** in upstream source (verified by reading `codex-rs/` at HEAD). Codex's hook engine is explicitly named `ClaudeHooksEngine` — the upstream has already done the interop work for us. This is the opposite of "wrong direction" — it's "direction is so right that the target system has already aligned to it."

### 13.5 Follow-up plan breakdown (if Supervisor approves feasibility)

Concrete successor plans with file/class-level granularity. These supersede Plan #11 §9 and the old Plan #14/#15 breakdown.

**Phase A — Apply Plan #14 discrepancies to Plan #11 design doc (no code, ~20 min)**
- Plan #17: `docs: agent interface design v3 — accept Plan #14 discrepancies`.
  - Change `AgentMessage.ts` spec from `datetime | None` to `str | None` in §3.1 with rationale (CC JSONL round-trip byte-identity).
  - Add to §3.4 error model: "query-method `None` may collapse distinct failure modes; error specificity is not guaranteed across impls."
  - Add to §3.2 Protocol docstring: "impls may add optional keyword args to method signatures; callers typed as `Agent` stay on the minimal signature."
  - Resolve §10 remaining open questions #1 (Codex TUI submit key — now confirmed cmux/CC issue, tmux/Codex may need empirical tuning) and #2 (Codex legacy notify payload — now confirmed full schema via `codex-rs/hooks/src/events/stop.rs`).

**Phase B — Code scaffold (small plans, ~30-60 min each)**
- Plan #18: `feat(agent): add status() and poll_events() to CCAgent`
  - Extend `mation/agent.py` Protocol with the two new methods + `AgentStatus` / `StopEvent` Pydantic models.
  - Extend `mation/agents/cc.py` with implementations wrapping `worker.resolve_worker` and the existing stop-signal-file logic from `daemon.py`.
  - Tests: mirror Plan #14's walking-skeleton pattern with fixture `stop-<session>` files and fixture `ps` output.
  - Scope: don't touch `daemon.py` yet. Standalone walking skeleton.

- Plan #19: `feat(agent): add send() and interrupt() to CCAgent`
  - Extend Protocol with the two action methods + `AgentUnavailable` exception.
  - `CCAgent.send` wraps `cmux.send_text`; `CCAgent.interrupt` wraps `cmux.send_escape`.
  - Tests: CLI-runner style — mock `cmux.send_text` / `cmux.send_escape`, assert they receive the right surface_id.

**Phase C — Daemon migration (bigger plan, ~60-90 min)**
- Plan #20: `refactor(daemon): route stop/stall detection through CCAgent`
  - Replace `_check_worker` inline logic with `CCAgent()` calls: `agent.poll_events(session)` for the stop branch, `agent.status(session).last_activity` for the stall clock.
  - Regression test: all 58 existing tests green + pre-existing daemon_stall tests should not need changes since the XML wire format stays the same.
  - Reinstall + restart daemon required (per CLAUDE.local.md rule).

**Phase D — CLI migration (medium plan, ~40-60 min)**
- Plan #21: `refactor(cli): route send/kick through CCAgent`
  - `cli.send` → `CCAgent().send(session, message)`; `cli.kick` → `CCAgent().interrupt(session); time.sleep(1); CCAgent().send(session, "继续当前任务")`.
  - `mation read` already migrated in Plan #14.
  - Byte-identical CLI output for both commands (transcript write stays byte-identical).

**Phase E — Registry + group.json migration (medium, ~40-60 min)**
- Plan #22: `feat(agent): add agent registry + `agent` field in group.json`
  - `mation/agent_registry.py` with `{"claude-code": CCAgent()}`.
  - group.json v0.5 adds optional `agent: str` field defaulting to `"claude-code"` via `_migrate_group_shape`.
  - `daemon.py` / `cli.py` resolve agent per-group via registry.
  - Tests: multi-group with mixed agents.

**Phase F — Codex first-class (biggest plan, ~90-120 min)**
- Plan #23: `feat(agent): add CodexAgent with hook-based stop detection`
  - `mation/agents/codex.py` implementing all 5 methods.
  - Bootstrap command: `mation agent install codex` that writes `~/.codex/hooks.json` with the same `on-stop.sh` script (Codex's `ClaudeHooksEngine` will execute it just like CC does).
  - Rollout JSONL tail-scan specific to Codex's schema (separate from `worker.read_last_message`).
  - **Realistic test on my-laptop**: install codex on my-laptop first (Part 3 Plan #16 explicitly said "don't install" but Plan #23 will need it), start a codex session, verify mation can send/read/stop-detect.
  - Scope: v1 CodexAgent targets cmux-hosted Codex TUI mode. Headless `codex exec --json` mode is Plan #24.

**Phase G — Terminal abstraction (direction 2, large plan(s))**
- Plan #24 and beyond: Terminal protocol + CmuxTerminal + TmuxTerminal, then migrate `Agent.send` / `interrupt` to consume `Terminal` via constructor injection. Empirical tuning of the paste-settle sleep on my-laptop with tmux + live CC / Codex.
- Direction 2 is ~2× direction 1 per §12.2 estimate; budget two walking-skeleton spikes plus the migrations.

**Phase H — Hygiene plan (small)**
- Plan #25: `refactor: delete dead cmux code + unused hook scripts`. Drops `cmux.get_current_surface`, `cmux.ping`, `~/.mation/on-submit.sh`, `~/.mation/on-notification.sh`, and `delete_all`'s `submit-*` loop.

### 13.6 What §13 does **not** do

- No design decision on Plan #14 discrepancies — the three are already Accepted (per session decision) but the Plan #11 doc update to reflect them is **Phase A** above.
- No installation of `codex` or `tmux` on any host — research only.
- No testing on my-laptop — research only.
- No code changes — research only.
- No override of Plan #11 §9's plan list — Phase A-H above is a revised, more granular version. If Supervisor prefers the old §9 list, revert.
