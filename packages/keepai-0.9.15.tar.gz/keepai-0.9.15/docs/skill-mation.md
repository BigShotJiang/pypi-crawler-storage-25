---
name: keep
description: keep 使用指南与监督心智模型。仅在“需要解释 keep 用法、建立监督心智模型、给出 group/task/supervisor 最佳实践”时触发。
allowed-tools: Bash(keep:*)
---

## 启动

!`keep self show 2>&1`

## 配置层次

- Keep 级默认配置：`keep self config`
- Group 级覆盖：`keep group create/update --terminal/--agent/--workers-enabled`
- `workers_enabled=true`：Supervisor 协调 Worker
- `workers_enabled=false`：Supervisor 使用 Agent tool 派 subagent，不走 Worker 通道

## 双循环模型

### group 外循环

- 对齐 group 目标与当前任务队列。
- 若任务耗尽但目标未达成：基于 group 生成新 task。
- 若目标达成：收口 group。

### task 内循环

#### workers_enabled=true

1. `keep <group_id> task list`
2. `keep <group_id> task review proposed <rationale_file>`
3. `keep <group_id> supervisor send [worker_id] <message_file>`
4. `keep <group_id> supervisor wake [worker_id]`
5. `keep <group_id> supervisor read [worker_id]`
6. `keep <group_id> task update <task_id> --status submitted`
7. `keep <group_id> task review submitted <rationale_file>`

#### workers_enabled=false

1. `keep <group_id> task list`
2. `keep <group_id> task review proposed <rationale_file>`
3. Supervisor 用 Agent tool 派 subagent 执行
4. `keep <group_id> task update <task_id> --status submitted`
5. `keep <group_id> task review submitted <rationale_file>`

## stop 事件

1. `keep <group_id> supervisor read [worker_id]`
2. 完成则：`keep <group_id> task update <task_id> --status submitted`
3. 补充 rationale 后：`keep <group_id> task review submitted <rationale_file>`
4. 未完成则：`keep <group_id> supervisor send [worker_id] <下一步消息文件>`

## stall 事件

1. `keep <group_id> supervisor read [worker_id]`
2. 需要推进时：`keep <group_id> supervisor wake [worker_id]`
3. 必要时：`keep <group_id> supervisor send [worker_id] <下一步消息文件>`

## preference

- 主线优先：每轮只推进一件事（派发 / 读取 / 收口）。
- 禁止表演：不要结构化空话，不扩写无关内容。
- 强绑定 keep：所有判断与动作都落到 group/task/supervisor 命令。
