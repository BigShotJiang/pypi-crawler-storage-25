# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
from pathlib import Path
from typing import Awaitable, Callable, Dict, Mapping, Optional, Set, Union

from aria_mps_cli.cli_lib.common import log_exceptions
from aria_mps_cli.cli_lib.constants import DisplayStatus, ErrorCode
from aria_mps_cli.cli_lib.http_helper import HttpHelper
from aria_mps_cli.cli_lib.multi_recording_request import (
    MultiRecordingModel,
    MultiRecordingRequest,
)
from aria_mps_cli.cli_lib.request_monitor import RequestMonitor, RequestMonitorModel
from aria_mps_cli.cli_lib.types import (
    ModelState,
    MpsAriaDevice,
    MpsFeature,
    MpsRequest,
    MpsRequestSource,
)

logger = logging.getLogger(__name__)


class MultiRecordingMps:
    """Manage multi recording MPS request end to end"""

    http_helper_: HttpHelper

    def __init__(
        self,
        recordings: Set[Path],
        output_dir: Path,
        force: bool,
        retry_failed: bool,
        http_helper: HttpHelper,
        requestor: MultiRecordingRequest,
        request_monitor: RequestMonitor,
        source: MpsRequestSource,
        persist_on_failure: bool = False,
        name: Optional[str] = None,
        suffix: Optional[str] = None,
        on_state_changed: Optional[
            Callable[[Union[MultiRecordingModel, RequestMonitorModel]], Awaitable[None]]
        ] = None,
        feedback_id: Optional[str] = None,
    ):
        self._recordings: Set[Path] = recordings
        self._output_dir: Path = output_dir
        self._force: bool = force
        self._retry_failed: bool = retry_failed
        self._persist_on_failure: bool = persist_on_failure
        self._http_helper: HttpHelper = http_helper
        self._requestor: MultiRecordingRequest = requestor
        self._request_monitor: RequestMonitor = request_monitor
        self._source: MpsRequestSource = source
        self._name: Optional[str] = name
        self._suffix: Optional[str] = suffix
        self._feedback_id: Optional[str] = feedback_id

        async def __noop(*args, **kwargs):
            pass

        self._on_state_changed: Callable[
            [Union[MultiRecordingModel, RequestMonitorModel]], Awaitable[None]
        ] = on_state_changed or __noop

        self._model: Optional[Union[MultiRecordingModel, RequestMonitorModel]] = None
        self._finish_status: Mapping[Path, ModelState] = {}
        self._device_types_cache: Dict[Path, Optional[MpsAriaDevice]] = {}
        self._running: bool = False

    @property
    def recordings(self) -> Set[Path]:
        return self._recordings

    @log_exceptions
    async def run(self) -> None:
        """
        Process a single VRS file through MPS
        The recording first goes through the requestor.
        The recording may get submitted to server for processing, if necessary.
        After that it will go through the request monitor.
        """
        #
        # First submit the recording to the requestor. One request per feature
        #
        self._model = await self._requestor.add_new_recordings(
            recordings=self._recordings,
            output_dir=self._output_dir,
            force=self._force,
            retry_failed=self._retry_failed,
            persist_on_failure=self._persist_on_failure,
            name=self._name,
            suffix=self._suffix,
            feedback_id=self._feedback_id,
        )
        await self._on_state_changed(self._model)
        logger.debug(f"{self._model}")
        logger.debug(f"{self._model.task}")

        # Set running = True after all the models are submitted
        self._running = True

        if not self._model.task:
            raise RuntimeError("No task found for model")
        await self._model.task

        # Cache device types before the model is destroyed
        for rec in self._model.recordings:
            if rec.path not in self._device_types_cache:
                logger.debug(f"Recording {rec.path} has device type {rec.device_type}")
                self._device_types_cache[rec.path] = rec.device_type

        #
        # As requestor is done, it will either SUCCEED or FAIL.
        # If it succeeds there are 3 scenarios:
        # 1. This feature request was identified as a new request and needs to be
        #    submitted.
        # 2. This feature request was identified as a past request and needs to be
        #    tracked.
        # 3. Past output exists for this feature and nothings needs to be done
        #
        await self._on_state_changed(self._model)
        self._requestor.remove_model(self._model)
        if self._model.is_SUCCESS_PAST_OUTPUT() or self._model.is_FAILURE():
            # Set the state to SUCCESS or FAILURE
            self._finish_status = {
                r: self._model.get_status(r) for r in self._recordings
            }
            self._model = None
        elif self._model.is_SUCCESS_PAST_REQUEST():
            logger.debug(f"Past request found for {self._model}")
            # Pass the request to the monitor for tracking
            self._model = self._request_monitor.track_feature_request(
                self._model.recordings, self._model.feature_request
            )
        elif self._model.is_SUCCESS_NEW_REQUEST():
            # The feature request was identified as a new request and needs to be
            # submitted
            try:
                request: MpsRequest = await self._http_helper.submit_request(
                    name=self._name or f"{MpsFeature.MULTI_SLAM.name} request",
                    recording_ids=[rec.fbid or 0 for rec in self._model.recordings],
                    features={MpsFeature.MULTI_SLAM},
                    source=self._source,
                    persist_on_failure=self._persist_on_failure,
                    feedback_id=self._feedback_id,
                    # Request for multi SLAM is expected to be for a single device.
                    # Additionally, the device type is expected to be Aria gen1
                    # as processing of Aria gen2's recordings is not supported yet.
                    device_type=self._model.recordings[0].device_type
                    or MpsAriaDevice.UNKNOWN,
                )
                self._model = self._request_monitor.track_feature_request(
                    recordings=self._model.recordings,
                    feature_request=request.features[MpsFeature.MULTI_SLAM],
                )
            except Exception as e:
                logger.exception(f"Failed to submit request {e}")
                self._finish_status = {
                    r: ModelState(
                        status=DisplayStatus.ERROR,
                        error_code=str(ErrorCode.SUBMIT_FAILURE),
                    )
                    for r in self._recordings
                }

        #
        # Now wait for the request monitor to finish if there is a request to track
        #
        if self._model:
            await self._on_state_changed(self._model)
            logger.debug(f"Waiting for {self._model}")
            if self._model.task:
                await self._model.task
            self._finish_status = {
                r: self._model.get_status(r) for r in self._recordings
            }
            self._request_monitor.remove_model(self._model)
            await self._on_state_changed(self._model)

    @log_exceptions
    def get_status(self, recording: Path) -> ModelState:
        """Get the status of a feature request"""
        # First check the finish_status
        if recording in self._finish_status:
            return self._finish_status[recording]

        if not self._model or not self._running:
            return ModelState(status=DisplayStatus.CREATED)

        # If not found, check the model status
        return self._model.get_status(recording)

    def get_device_type(self, recording_path: Path) -> Optional[MpsAriaDevice]:
        """Get device type for a recording"""
        device_type: Optional[MpsAriaDevice] = self._device_types_cache.get(
            recording_path
        )
        if not device_type and self._model:
            # If not in cache, look through requests
            for rec in self._model.recordings:
                if rec.path == recording_path and rec.device_type is not None:
                    logger.debug(
                        f"Recording {rec.path} has device type {rec.device_type}"
                    )
                    self._device_types_cache[recording_path] = rec.device_type
                    device_type = rec.device_type
                    break

        return device_type
