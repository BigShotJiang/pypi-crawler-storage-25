# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import functools
import logging
import multiprocessing
import platform
import shutil
import sys
import tempfile
import zipfile
from concurrent.futures import ProcessPoolExecutor
from configparser import ConfigParser
from datetime import datetime
from functools import wraps
from pathlib import Path
from typing import (
    Any,
    Callable,
    Dict,
    List,
    MutableMapping,
    Optional,
    Sequence,
    Tuple,
    Type,
    TypeVar,
    Union,
)

import aiohttp
from aria_mps_cli.cli_lib.constants import (
    CONFIG_FILE,
    ConfigBoundKey,
    ConfigKey,
    ConfigSection,
)


logger = logging.getLogger(__name__)


async def run_subprocess_with_logging(
    *args,
    log_stdout: bool = True,
    log_stderr: bool = True,
    logger_instance: Optional[logging.Logger] = None,
) -> tuple[bytes, bytes, Optional[int]]:
    """
    Run a command via asyncio.create_subprocess_exec and log stdout/stderr.

    Args:
        *args: Command and arguments to run
        log_stdout: Whether to log stdout output
        log_stderr: Whether to log stderr output
        logger_instance: Logger to use (defaults to module logger)

    Returns:
        Tuple of (stdout, stderr, return_code)
    """
    log = logger_instance or logger

    process = await asyncio.create_subprocess_exec(
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    stdout, stderr = await process.communicate()

    # Log stdout output if enabled
    if log_stdout and stdout:
        stdout_text = stdout.decode().strip()
        if stdout_text:
            for line in stdout_text.splitlines():
                log.debug(f"[stdout] {line}")

    # Log stderr output if enabled
    if log_stderr and stderr:
        stderr_text = stderr.decode().strip()
        if stderr_text:
            for line in stderr_text.splitlines():
                log.debug(f"[stderr] {line}")

    return stdout, stderr, process.returncode


T = TypeVar("T")


class CustomAdapter(logging.LoggerAdapter):
    """Custom logging adapter to print the contextual information like vrs file"""

    def process(
        self, msg: Any, kwargs: MutableMapping[str, str]
    ) -> Tuple[str, MutableMapping[str, str]]:
        suffix = (
            " ".join([f"[{k}:{v}]" for k, v in self.extra.items()])
            if self.extra
            else ""
        )
        return " ".join([str(suffix), str(msg)]), kwargs


async def to_proc(func: Callable[..., T], /, *args: Any, **kwargs: Any) -> T:
    """
    Use this for synchronous cpu bound tasks
    Main functionality is to maintain context when offloading to OS threads.
    """
    if not hasattr(to_proc, "process_pool"):
        # Default to "fork" (fast, shares parent state). Switch to "spawn"
        # only where fork is unsafe or unavailable:
        # - Windows: no fork().
        # - macOS PyInstaller-frozen apps (e.g. Aria Studio): the parent has
        #   already loaded Obj-C / CoreFoundation runtimes and the Aria SDK's
        #   folly thread pool; fork() inherits locks held by vanished threads
        #   and deadlocks. The standalone CLI doesn't load those, so fork is
        #   fine — and "spawn" there hits "bad value(s) in fds_to_keep" FD
        #   races during pool startup.
        if platform.system() == "Windows" or (
            platform.system() == "Darwin" and getattr(sys, "frozen", False)
        ):
            mp_context = multiprocessing.get_context("spawn")
        else:
            mp_context = multiprocessing.get_context("fork")
        to_proc.process_pool = ProcessPoolExecutor(
            mp_context=mp_context,
        )
    loop = asyncio.get_running_loop()
    func_call = functools.partial(func, *args, **kwargs)
    return await loop.run_in_executor(to_proc.process_pool, func_call)


def unzip(zip_filepath: Path, dest_dir: Path) -> None:
    """
    Unzips a zip file into a destination directory.
    Initially unzip files into temporary directory and then moves them to final
    destination. It prevents showing incomplete output in the destination directory.
    """
    # First unzip to temporary folder
    with tempfile.TemporaryDirectory() as tmp_dir:
        with zipfile.ZipFile(zip_filepath, "r") as zip_ref:
            zip_ref.extractall(tmp_dir)
        if dest_dir.is_dir():
            shutil.rmtree(dest_dir)
        elif dest_dir.is_file():
            dest_dir.unlink()
        shutil.move(tmp_dir, dest_dir)


def retry(
    exceptions: Optional[Sequence[Type[Exception]]] = None,
    error_codes: Optional[Sequence[int]] = None,
    retries: int = 3,
    interval: float = 1,
    backoff: float = 1.5,
):
    """
    Decorator for retrying functions up to `retries` retries if exceptions are thrown.
    Does exponential backoff between retries.
    ClientResponseError from aiohttp is treated special and will only be retried if
    the status code is in `error_codes`.
    At least one of `exceptions` or `error_codes` must be provided.

    Args:
        exceptions: List of exceptions to catch
        error_codes: List of HTTP status codes to catch
        retries: Number of times to retry
        interval: Interval between retries in seconds
        backoff: Backoff multiplier

    Usage:
    @retry(exceptions=[ValueError, TypeError], retries=5, interval=2, backoff=2)
    async def my_async_function():
        # code that might raise an exception

    """
    if not exceptions and not error_codes:
        raise ValueError(
            "At least one of `exceptions` or `error_codes` must be provided."
        )
    exceptions = list(exceptions or [])
    if error_codes and aiohttp.ClientResponseError not in exceptions:
        exceptions.append(aiohttp.ClientResponseError)

    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            attempts = 0
            while True:
                try:
                    return await func(*args, **kwargs)
                except tuple(exceptions) as e:
                    if (
                        isinstance(e, aiohttp.ClientResponseError)
                        and error_codes
                        and e.status not in error_codes
                    ):
                        logger.exception(e)
                        raise e from e
                    if attempts > retries:
                        logger.error(f"Maximum number of retries reached ({retries}).")
                        raise e from e
                    logger.warning(f"Exception encountered: {e}")
                    sleep_time = interval * (backoff ** (attempts))
                    attempts += 1
                    logger.warning(
                        f"Retrying attempt {attempts}/{retries + 1} in {sleep_time} seconds..."
                    )
                    await asyncio.sleep(sleep_time)

        return wrapper

    return decorator


def log_exceptions(func):
    """Decorator to log exceptions and re-raise them"""

    @functools.wraps(func)
    def sync_wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.exception(f"Exception occurred in {func.__name__} \n {e}")
            raise

    @functools.wraps(func)
    async def async_wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            logger.exception(f"Exception occurred in {func.__name__} \n {e}")
            raise

    # Check if the function is a coroutine (async)
    if asyncio.iscoroutinefunction(func):
        return async_wrapper
    else:
        return sync_wrapper


def get_pretty_size(num_bytes: float, suffix="B") -> Optional[str]:
    """
    Returns a human readable size string
    """
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P", "E", "Z"]:
        if num_bytes < factor:
            return f"{num_bytes:.2f} {unit}{suffix}"
        num_bytes /= factor


class Config(ConfigParser):
    """
    Simple class to access the config object
    We use a singleton pattern here so we can have one instance of the config object
    across all modules
    The actual config file is located at ~/.projectaria/mps.ini
    We leverage the ConfigParser library to parse the config file
    If the config file does not exist, we create it with default values
    Users can then overwrite the values by editing the config file directly
    """

    _config = None

    _is_verbose: bool = False
    _log_path: Optional[Path] = None

    # Default config values
    DEFAULT_CONFIG: Dict[str, Dict[str, str]] = {
        ConfigSection.DEFAULT: {
            ConfigKey.LOG_DIR: "/tmp/logs/projectaria/mps/ # Path to log directory",
            ConfigKey.STATUS_CHECK_INTERVAL: "30 # Status check interval in seconds",
            ConfigKey.CONCURRENT_PROCESSING: "25 # Maximum number of recordings being processed concurrently",
        },
        ConfigSection.HASH: {
            ConfigKey.CONCURRENT_HASHES: "4 # Maximum number of recordings whose hashes will be calculated concurrently",
            ConfigKey.CHUNK_SIZE: "10485760 # 10 * 2**20 (10MB)",
        },
        ConfigSection.HEALTH_CHECK: {
            ConfigKey.CONCURRENT_HEALTH_CHECKS: "4  # Maximum number of checks that can run concurrently",
        },
        ConfigSection.ENCRYPTION: {
            ConfigKey.CHUNK_SIZE: "52428800 # 50 * 2**20 (50MB)",
            ConfigKey.CONCURRENT_ENCRYPTIONS: "5 # Maximum number of recordings that will be encrypted concurrently",
            ConfigKey.DELETE_ENCRYPTED_FILES: "true # Delete encrypted files after upload is done",
        },
        ConfigSection.UPLOAD: {
            ConfigKey.BACKOFF: "1.5 # Backoff factor for retries",
            ConfigKey.CONCURRENT_UPLOADS: "4 # Maximum number of concurrent uploads",
            ConfigKey.INTERVAL: "20 # Interval between runs",
            ConfigKey.MAX_CHUNK_SIZE: "104857600 # 100 * 2**20 (100 MB)",
            ConfigKey.MIN_CHUNK_SIZE: "5242880 # 5 * 2**20 (5MB)",
            ConfigKey.RETRIES: "10 # Number of times to retry a failed upload",
            ConfigKey.SMOOTHING_WINDOW_SIZE: "10 # Size of the smoothing window",
            ConfigKey.TARGET_CHUNK_UPLOAD_SECS: "3 # Target duration to upload a chunk",
        },
        ConfigSection.DOWNLOAD: {
            ConfigKey.BACKOFF: "1.5 # Backoff factor for retries",
            ConfigKey.CHUNK_SIZE: "10485760 # 10 * 2**20 (10MB)",
            ConfigKey.CONCURRENT_DOWNLOADS: "10 # Maximum number of concurrent downloads",
            ConfigKey.DELETE_ZIP: "true # Delete zip files after extracting",
            ConfigKey.INTERVAL: "20 # Interval between runs",
            ConfigKey.RETRIES: "10 # Number of times to retry a failed upload",
        },
        ConfigSection.GRAPHQL: {
            ConfigKey.BACKOFF: "1.5 # Backoff factor for retries",
            ConfigKey.INTERVAL: "4 # Interval between runs",
            ConfigKey.RETRIES: "3 # Number of times to retry a failed upload",
        },
    }

    # Configuration bounds for validation (min and max values)
    # These values are synchronized with aria_studio/react/src/common/components/Settings/setting.config.js
    CONFIG_BOUNDS: Dict[str, Dict[str, Dict[str, Union[str, int, float]]]] = {
        ConfigSection.DEFAULT: {
            ConfigKey.STATUS_CHECK_INTERVAL: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 30,
            },
            ConfigKey.CONCURRENT_PROCESSING: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 100,
            },
        },
        ConfigSection.HASH: {
            ConfigKey.CONCURRENT_HASHES: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 10,
            },
            ConfigKey.CHUNK_SIZE: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1048576,
                ConfigBoundKey.MAX_VALUE: 10485760,
            },
        },
        ConfigSection.HEALTH_CHECK: {
            ConfigKey.CONCURRENT_HEALTH_CHECKS: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 10,
            },
        },
        ConfigSection.ENCRYPTION: {
            ConfigKey.CHUNK_SIZE: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1048576,
                ConfigBoundKey.MAX_VALUE: 52428800,
            },
            ConfigKey.CONCURRENT_ENCRYPTIONS: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 10,
            },
        },
        ConfigSection.UPLOAD: {
            ConfigKey.BACKOFF: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_FLOAT,
                ConfigBoundKey.MIN_VALUE: 1.0,
                ConfigBoundKey.MAX_VALUE: 10.0,
            },
            ConfigKey.CONCURRENT_UPLOADS: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 10,
            },
            ConfigKey.INTERVAL: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 20,
            },
            ConfigKey.MAX_CHUNK_SIZE: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1048576,
                ConfigBoundKey.MAX_VALUE: 104857600,
            },
            ConfigKey.MIN_CHUNK_SIZE: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1048576,
                ConfigBoundKey.MAX_VALUE: 10485760,
            },
            ConfigKey.RETRIES: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 0,
                ConfigBoundKey.MAX_VALUE: 10,
            },
            ConfigKey.SMOOTHING_WINDOW_SIZE: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 3,
                ConfigBoundKey.MAX_VALUE: 30,
            },
            ConfigKey.TARGET_CHUNK_UPLOAD_SECS: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 10,
            },
        },
        ConfigSection.GRAPHQL: {
            ConfigKey.BACKOFF: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_FLOAT,
                ConfigBoundKey.MIN_VALUE: 1.0,
                ConfigBoundKey.MAX_VALUE: 10.0,
            },
            ConfigKey.INTERVAL: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 10,
            },
            ConfigKey.RETRIES: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 0,
                ConfigBoundKey.MAX_VALUE: 10,
            },
        },
        ConfigSection.DOWNLOAD: {
            ConfigKey.BACKOFF: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_FLOAT,
                ConfigBoundKey.MIN_VALUE: 1.0,
                ConfigBoundKey.MAX_VALUE: 10.0,
            },
            ConfigKey.INTERVAL: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 20,
            },
            ConfigKey.RETRIES: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 0,
                ConfigBoundKey.MAX_VALUE: 10,
            },
            ConfigKey.CHUNK_SIZE: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1048576,
                ConfigBoundKey.MAX_VALUE: 10485760,
            },
            ConfigKey.CONCURRENT_DOWNLOADS: {
                ConfigBoundKey.TYPE: ConfigBoundKey.TYPE_INT,
                ConfigBoundKey.MIN_VALUE: 1,
                ConfigBoundKey.MAX_VALUE: 10,
            },
        },
    }

    @staticmethod
    def _apply_config_limits() -> None:
        """
        Apply min/max value constraints from CONFIG_BOUNDS to the loaded configuration.
        This should be called after all config values are loaded/merged.
        """
        if Config._config is None:
            raise ValueError("Config was not loaded yet")

        for section, keys in Config.CONFIG_BOUNDS.items():
            for key, bounds in keys.items():
                if Config._config.has_option(section, key):
                    value_type = bounds.get(
                        ConfigBoundKey.TYPE, ConfigBoundKey.TYPE_INT
                    )
                    min_value = bounds.get(ConfigBoundKey.MIN_VALUE)
                    max_value = bounds.get(ConfigBoundKey.MAX_VALUE)

                    if value_type == ConfigBoundKey.TYPE_FLOAT:
                        current_value = Config._config.getfloat(section, key)
                    else:
                        current_value = Config._config.getint(section, key)

                    clamped_value = current_value
                    if min_value is not None and current_value < min_value:
                        logger.warning(
                            f"Config {section}.{key}={current_value} is below minimum of {min_value}. "
                            f"Using {min_value}."
                        )
                        clamped_value = min_value
                    elif max_value is not None and current_value > max_value:
                        logger.warning(
                            f"Config {section}.{key}={current_value} exceeds maximum of {max_value}. "
                            f"Using {max_value}."
                        )
                        clamped_value = max_value

                    if clamped_value != current_value:
                        Config._config.set(section, key, str(clamped_value))

    @staticmethod
    def _configure_logging() -> None:
        """
        Setup logging to file and remove default logger unless verbose mode is enabled
        """
        config = Config.get()
        log_dir = Path(config.get(ConfigSection.DEFAULT, ConfigKey.LOG_DIR))
        log_dir.mkdir(parents=True, exist_ok=True)
        log_file: Path = log_dir / f"{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.log"
        handlers: List[logging.StreamHandler] = [logging.FileHandler(log_file)]
        if Config._is_verbose:
            handlers.append(logging.StreamHandler())
        logging.basicConfig(
            handlers=handlers,
            level=logging.DEBUG,
            format="%(asctime)s [%(process)d] [%(levelname)s] [%(filename)s:%(lineno)d] - %(message)s",
        )

        logger.info(f"log file : {log_file}")
        Config._log_path = log_file

    @staticmethod
    def get() -> ConfigParser:
        """
        Get the config object
        Loads the config from ~/.projectaria/mps.ini. if it doesn't exist, creates it
        with default values. If the config exists but is missing keys, adds the missing
        keys from DEFAULT_CONFIG.
        """
        if Config._config is None:
            Config._config = ConfigParser(inline_comment_prefixes="#")

            if not CONFIG_FILE.is_file():
                c = ConfigParser()
                c.read_dict(Config.DEFAULT_CONFIG)
                CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
                with CONFIG_FILE.open("w") as fd:
                    c.write(fd)

            Config._config.read(CONFIG_FILE)
            Config._configure_logging()

            # Load missing sections and keys from DEFAULT_CONFIG into memory
            # This does NOT modify the file, only the in-memory ConfigParser
            for section, keys in Config.DEFAULT_CONFIG.items():
                # DEFAULT section always exists in ConfigParser
                if section != ConfigSection.DEFAULT and not Config._config.has_section(
                    section
                ):
                    Config._config.add_section(section)
                    logger.debug(
                        f"Loaded missing config section from defaults: {section}"
                    )

                for key, value in keys.items():
                    if not Config._config.has_option(section, key):
                        # Extract just the value part (before the comment)
                        actual_value = value.split("#")[0].strip()
                        Config._config.set(section, key, actual_value)
                        logger.debug(
                            f"Loaded missing config key from defaults: {section}.{key} = {actual_value}"
                        )

            # Apply max value limits after all configs are merged
            Config._apply_config_limits()

            logger.info(f"Loaded config file {CONFIG_FILE}")
        return Config._config

    @staticmethod
    def reload() -> None:
        """
        Reload the config object from the file.
        Clears the current configuration and reads the updated config file.
        Used in Aria Studio to reload the config after it is updated using UI

        This method also updates all registered components that depend on configuration values.

        Raises:
            ConfigUpdateError: If updating components fails after config reload.
        """
        if Config._config is not None:
            # Clear the current configuration
            Config._config.clear()
            # Re-read the configuration file
            Config._config.read(CONFIG_FILE)

            # Apply max value limits after config is reloaded
            Config._apply_config_limits()

            logger.info(f"Reloaded config file {CONFIG_FILE}")

            # Update all components semaphore configuration values
            try:
                # Import here to avoid circular import
                from aria_mps_cli.cli_lib.config_updatable import update_all_components

                update_all_components()
                logger.info("Updated all components with new configuration values")
            except Exception as e:
                logger.error(f"Error updating components: {e}")
                raise ConfigUpdateError(
                    f"Failed to update components after config reload: {e}"
                ) from e

    @staticmethod
    def set_is_verbose(is_verbose: bool) -> None:
        """
        Set the verbose logging mode flag.
        """
        Config._is_verbose = is_verbose

    @staticmethod
    def get_log_path() -> Path:
        """
        Get the log file path.
        """
        if Config._log_path is None:
            raise ValueError("Config was not loaded yet")

        return Config._log_path


class ConfigUpdateError(Exception):
    """Exception raised when configuration update fails."""

    pass
