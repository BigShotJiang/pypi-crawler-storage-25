# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import json
import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Final, final, List, Optional

from aria_mps_cli.cli_lib.constants import (
    ErrorCode,
    KEY_VHC_ARIA_GEN1_DEFAULT,
    KEY_VHC_ARIA_GEN2_DEFAULT,
)
from aria_mps_cli.cli_lib.http_helper import HttpHelper
from aria_mps_cli.cli_lib.types import AriaRecording, MpsAriaDevice, MpsFeature

logger = logging.getLogger(__name__)


async def validate_recording_eligibility(
    recording: AriaRecording,
    feature: MpsFeature,
    http_helper: HttpHelper,
) -> Optional[int]:
    """
    Validates recording eligibility by determining device type and checking feature compatibility.

    Args:
        recording: The AriaRecording to validate
        feature: The MpsFeature to check eligibility for
    Returns:
        ErrorCode if validation fails, None if successful
    Raises:
        FileNotFoundError: If the VRS Health Check output file does not exist.
        ValueError: If the feature is not supported.
    """

    if recording.device_type is None:
        logger.error(f"Failed to determine device type for {recording.path}")
        return ErrorCode.HEALTH_CHECK_FAILURE

    logger.info(f"Device type: {recording.device_type}")
    if recording.device_type is MpsAriaDevice.ARIA_GEN1:
        eligibility_checker = EligibilityCheckerGen1(http_helper, recording)
    elif recording.device_type is MpsAriaDevice.ARIA_GEN2:
        eligibility_checker = EligibilityCheckerGen2(http_helper, recording)
    else:
        logger.error(
            f"Failed to determine device type for {recording.path}. device_type={recording.device_type}"
        )
        return ErrorCode.DEVICE_TYPE_UNSUPPORTED

    error_code: Optional[int] = await eligibility_checker.check_eligibility_error(
        feature
    )
    if error_code:
        logger.error(f"VrsHealthCheck failed for {recording.path}")
    return error_code


class EligibilityChecker(ABC):
    """
    Base class for checking if a recording is eligible for processing with a given MPS feature.
    """

    VHC_KEY_SECTION_DEFAULT: str = ""
    VHC_KEY_SECTION_LOCATION: str = ""
    VHC_KEY_SECTION_HAND_TRACKING: str = ""

    _VHC_KEY_FINAL_RESULT: Final[str] = "final_result"
    _VHC_KEY_FAILED_CHECKS: Final[str] = "failed_checks"
    _VHC_KEY_WARN_CHECKS: Final[str] = "warn_checks"
    _VHC_KEY_STREAM_CHECKS: Final[str] = "performed_checks_with_details"

    _VHC_OUT_PASS: Final[str] = "pass"
    _VHC_OUT_WARN: Final[str] = "warn"
    _VHC_OUT_FAIL: Final[str] = "fail"

    _query_lock: asyncio.Lock
    _allowed_features: List[MpsFeature]

    def __init__(self, http_helper: HttpHelper, recording: AriaRecording) -> None:
        self._recording: AriaRecording = recording
        self._http_helper: HttpHelper = http_helper

    @final
    async def check_eligibility_error(self, feature: MpsFeature) -> Optional[int]:
        """
        Checks if an Aria Recording is eligible for processing with selected MPS feature
        based on the results of the VRS Health Check.

        Args:
            feature (MpsFeature): The MPS feature to check eligibility for.
        Returns:
            None if the recording is eligible for processing with the selected feature, an error code otherwise.
        Raises:
            FileNotFoundError: If the VRS Health Check output file does not exist.
        """
        if not self._recording.device_type:
            logger.error(f"Failed to determine device type for {self._recording.path}")
            return ErrorCode.HEALTH_CHECK_FAILURE

        # query graphql for features supported by the device
        async with self._query_lock:
            if not self._allowed_features:
                # Set a static variable for a child class to avoid multiple queries
                self.__class__._allowed_features = (
                    await self._http_helper.query_allowed_features(
                        self._recording.device_type
                    )
                )

        if feature not in self._allowed_features:
            logger.error(
                f"Feature {feature} is not supported by {self._recording.device_type}"
            )
            return ErrorCode.DEVICE_TYPE_UNSUPPORTED
        # else: feature supported on back-end, check if recording is eligible

        if not self._recording.health_check_path.exists():
            raise FileNotFoundError(f"No health check found for {self._recording.path}")

        with open(self._recording.health_check_path) as vhc:
            vhc_json: Dict[str, Any] = json.load(vhc)

        # perform device agnostic eligibility check
        if feature in [MpsFeature.SLAM, MpsFeature.MULTI_SLAM]:
            return self._is_eligible(vhc_json, self.VHC_KEY_SECTION_LOCATION)
        elif feature == MpsFeature.HAND_TRACKING:
            return self._is_eligible(vhc_json, self.VHC_KEY_SECTION_HAND_TRACKING)

        # run device specific eligibility check
        return self._check_eligibility_error_internal(vhc_json, feature)

    @abstractmethod
    def _check_eligibility_error_internal(
        self, vhc_json: Dict[str, Any], feature: MpsFeature
    ) -> Optional[int]:
        """
        Checks if an Aria Recording is eligible for processing with selected MPS feature
        based on the results of the VRS Health Check. Actual logic of the check,
        to be implemented by subclasses.

        Args:
            vhc_json (Dict[str, Any]): The JSON output of the VRS Health Check.
            feature (MpsFeature): The MPS feature to check eligibility for.
        Raises:
            NotImplementedError: If the method is not implemented in the subclass.
        """
        raise NotImplementedError()

    def _is_eligible(
        self, vhc_json: Dict[str, Any], section_name: str
    ) -> Optional[int]:
        """
        Check if the Aria Recording's stream is eligible for MPS processing.

        Args:
            vhc_json (Dict[str, Any]): The JSON output of the VRS Health Check.
            section_name (str): The section of the JSON output to check.
        Returns:
            None if the Aria Recording's stream is eligible for MPS processing, an error code otherwise.
        """
        section: Dict[str, Any] = vhc_json[section_name]
        status: Optional[str] = section.get(self._VHC_KEY_FINAL_RESULT)

        if not status:
            logger.error("Unable to determine location status from VHC output")
            return ErrorCode.HEALTH_CHECK_FAILURE

        if status == self._VHC_OUT_WARN:
            warnings: List[str] = section.get(self._VHC_KEY_WARN_CHECKS, [])
            logger.warning(f"VHC output contains warnings: {', '.join(warnings)}")

        return ErrorCode.HEALTH_CHECK_FAILURE if status == self._VHC_OUT_FAIL else None


class EligibilityCheckerGen1(EligibilityChecker):
    """
    Check if an Aria gen1 recording is eligible for processing with a given MPS feature.
    """

    VHC_KEY_SECTION_DEFAULT: str = KEY_VHC_ARIA_GEN1_DEFAULT
    VHC_KEY_SECTION_LOCATION: str = "AriaGen1_Location"
    VHC_KEY_SECTION_HAND_TRACKING: str = "AriaGen1_Handtracking"

    __VHC_KEY_EYE_CAMERA_STREAM: Final[str] = "Eye Camera Class #1"

    _query_lock: asyncio.Lock = asyncio.Lock()
    _allowed_features: List[MpsFeature] = []

    def _check_eligibility_error_internal(
        self, vhc_json: Dict[str, Any], feature: MpsFeature
    ) -> Optional[int]:
        """
        Checks if an Aria Recording is eligible for processing with selected MPS feature
        based on the results of the VRS Health Check.

        Args:
            vhc_json (Dict[str, Any]): The JSON output of the VRS Health Check.
            feature (MpsFeature): The MPS feature to check eligibility for.
        Returns:
            None if the recording is eligible for processing with the selected feature, an error code otherwise.
        """

        section: Dict[str, Any] = vhc_json[self.VHC_KEY_SECTION_DEFAULT]
        if feature != MpsFeature.EYE_GAZE:
            return None

        has_stream: bool = (
            self.__VHC_KEY_EYE_CAMERA_STREAM in section[self._VHC_KEY_STREAM_CHECKS]
        )
        if not has_stream:
            return ErrorCode.HEALTH_CHECK_FAILURE

        errors: List[str] = [
            check
            for check in section[self._VHC_KEY_FAILED_CHECKS]
            if check.startswith(self.__VHC_KEY_EYE_CAMERA_STREAM)
        ]
        if errors:
            logger.debug(f"Failed checks: {errors}")
            return ErrorCode.HEALTH_CHECK_FAILURE

        warnings: List[str] = [
            check
            for check in section[self._VHC_KEY_WARN_CHECKS]
            if check.startswith(self.__VHC_KEY_EYE_CAMERA_STREAM)
        ]
        if warnings:
            logger.debug(f"Warning checks: {warnings}")

        return None


class EligibilityCheckerGen2(EligibilityChecker):
    """
    Check if an Aria gen2 recording is eligible for processing with a given MPS feature.
    """

    VHC_KEY_SECTION_DEFAULT: str = KEY_VHC_ARIA_GEN2_DEFAULT
    VHC_KEY_SECTION_LOCATION: str = "AriaGen2_Location"
    VHC_KEY_SECTION_HAND_TRACKING: str = "AriaGen2_Handtracking"

    _query_lock: asyncio.Lock = asyncio.Lock()
    _allowed_features: List[MpsFeature] = []

    def _check_eligibility_error_internal(
        self, vhc_json: Dict[str, Any], feature: MpsFeature
    ) -> Optional[int]:
        """
        Checks if an Aria Recording is eligible for processing with selected MPS feature
        based on the results of the VRS Health Check.

        Args:
            vhc_json (Dict[str, Any]): The JSON output of the VRS Health Check.
            feature (MpsFeature): The MPS feature to check eligibility for.
        Returns:
            None if the recording is eligible for processing with the selected feature, an error code otherwise.
        """

        if feature == MpsFeature.EYE_GAZE:
            # requestor should reject the Recording in a previous step
            return ErrorCode.DEVICE_TYPE_UNSUPPORTED

        return None
