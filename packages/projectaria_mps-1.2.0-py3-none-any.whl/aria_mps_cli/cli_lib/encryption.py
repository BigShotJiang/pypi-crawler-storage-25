# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import io
import logging
import shutil
from asyncio import Semaphore
from multiprocessing import connection, Pipe
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import final

from aiofiles.os import stat
from aria_mps_cli.cli_lib.common import Config, CustomAdapter, to_proc
from aria_mps_cli.cli_lib.config_updatable import ConfigUpdatable
from aria_mps_cli.cli_lib.constants import ConfigKey, ConfigSection
from aria_mps_cli.cli_lib.runner_with_progress import RunnerWithProgress
from Crypto.Cipher import AES, PKCS1_v1_5
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes

logger = logging.getLogger(__name__)
config = Config.get()


class EncryptionException(RuntimeError):
    """
    Raised when encryption fails
    """

    pass


class VrsEncryptor(RunnerWithProgress, ConfigUpdatable):
    """
    Encrypt a vrs file and report progress
    """

    semaphore_: Semaphore = Semaphore(
        config.getint(ConfigSection.ENCRYPTION, ConfigKey.CONCURRENT_ENCRYPTIONS)
    )

    @classmethod
    def get_setting_keys(cls) -> tuple[str, str]:
        """Return the config section and key for the encryptor's semaphore setting"""
        return ConfigSection.ENCRYPTION, ConfigKey.CONCURRENT_ENCRYPTIONS

    def __init__(
        self, src_path: Path, dest_path: Path, encryption_key: str, key_id: int
    ):
        super().__init__()
        self._src_path = src_path
        self._dest_path = dest_path
        self._encryption_key = encryption_key
        self._encryption_key_id = key_id
        self._logger: CustomAdapter = CustomAdapter(
            logging.getLogger(__name__), {"vrs": str(src_path)}
        )

    @classmethod
    @final
    def get_key(
        cls, src_path: Path, dest_path: Path, encryption_key: str, key_id: int
    ) -> str:
        """Get a unique key for this Runner instance"""
        return f"{src_path}_{dest_path}_{encryption_key}_{key_id}"

    @final
    async def _run(self) -> None:
        """
        Encrypt the source file and write it to destination
        Encryption is a CPU intensive operation, so in order to avoid blocking the event
        loop, we run it in a ProcessPoolExecutor.
        The encryption progress is reported back via a pipe.
        """

        self._total = (await stat(self._src_path)).st_size
        async with self.semaphore_:
            receiver, sender = Pipe(duplex=False)
            try:
                encrypt_task: asyncio.Task = asyncio.create_task(
                    to_proc(
                        _encrypt_file,
                        self._src_path,
                        self._dest_path,
                        self._encryption_key,
                        self._encryption_key_id,
                        self._total,
                        config.getint(ConfigSection.ENCRYPTION, ConfigKey.CHUNK_SIZE),
                        sender,
                    )
                )
                done = None
                while not done:
                    done, pending = await asyncio.wait([encrypt_task], timeout=1)
                    while receiver.poll():
                        self._processed = receiver.recv()
                    self._logger.debug(f"Encrypted {self.progress:.2f}%")
            finally:
                receiver.close()
                sender.close()


class FileEncryptor:
    """
    This class is responsible for performing envelope encryption of the vrs file.
    TODO: Handle files bigger than 64 GB
    """

    def __init__(
        self,
        encryption_key: str,
        key_id: int,
        chunk_size: int,
        src_file: Path,
        dest_file: Path,
        src_file_size: int,
    ):
        self._crypto_version: int = 1
        self._symmetric_key_length: int = 32
        self._k_iv_len: int = 12
        self._k_aria_encryption_version: int = 1
        self._chunk_size = chunk_size

        self._crypto_key_id: int = key_id
        self._pub_key: RSA.RsaKey = RSA.import_key(encryption_key)
        self._src_file: Path = src_file
        self._src_file_size: int = src_file_size
        self._dest_file: Path = dest_file
        self._logger: CustomAdapter = CustomAdapter(
            logging.getLogger(__name__), {"vrs": str(src_file)}
        )

    def _header(self, dest_stream: io.BufferedWriter):
        """
        output format: [version: 1byte][key ID: 1byte][IV: 12 bytes][key size: 2bytes][key:
        256bytes][tag: 16 bytes][ciphertext: 45 bytes] ciphertext: [symmetric key: 32 bytes][IV: 12
        bytes][Aria Encryption Version: 1 byte]
        """
        self._logger.debug("Writing encryption header")

        # Even though the payload to encrypt is just 45 bytes
        # (32 bytes symmetric key + 12 bytes IV + 1 byte), much smaller than
        # 245 bytes, the limit of RSA-2056 encryption, we need to perform an envelope
        # encryption  because the Crypto service used for remote decryption on backend
        # expects it.
        encrypted_data: bytearray = bytearray(
            [self._crypto_version, self._crypto_key_id]
        )

        envelope_iv = get_random_bytes(self._k_iv_len)
        encrypted_data.extend(envelope_iv)

        # Generate a random symmetric key and encrypt it using the public key
        envelope_symmetric_key = get_random_bytes(self._symmetric_key_length)
        ciphertext = PKCS1_v1_5.new(self._pub_key).encrypt(envelope_symmetric_key)

        # Write encrypted key length (256 bytes) in little endian
        encrypted_data.extend(len(ciphertext).to_bytes(2, byteorder="little"))
        # Write encrypted key
        encrypted_data.extend(ciphertext)
        envelope_cipher = AES.new(envelope_symmetric_key, AES.MODE_GCM, envelope_iv)

        symmetric_key = get_random_bytes(self._symmetric_key_length)
        iv = get_random_bytes(self._k_iv_len)

        self._cipher = AES.new(symmetric_key, AES.MODE_GCM, iv)

        plain_text: bytearray = bytearray()
        plain_text.extend(symmetric_key)
        plain_text.extend(iv)
        plain_text.append(self._k_aria_encryption_version)

        cipher_text, tag = envelope_cipher.encrypt_and_digest(plain_text)
        encrypted_data.extend(tag)
        encrypted_data.extend(cipher_text)

        dest_stream.write(encrypted_data)

    def _write_data(self, dest_stream: io.BufferedWriter, conn: connection.Connection):
        """Encrypt the data from the source file and write to the destination stream"""
        with self._src_file.open("rb") as fr:
            processed_bytes: int = 0
            while True:
                chunk = fr.read(self._chunk_size)
                if not chunk:
                    if processed_bytes != self._src_file_size:
                        raise EncryptionException(
                            f"Encrypted {processed_bytes} bytes, expected {self._src_file_size}"
                        )
                    break
                cipher_text = self._cipher.encrypt(chunk)
                dest_stream.write(cipher_text)
                processed_bytes += len(chunk)
                self._logger.debug(f"Encrypted {processed_bytes} bytes")
                conn.send(processed_bytes)
            dest_stream.write(self._cipher.digest())
        self._logger.debug("Finished writing encrypted data")

    def encrypt(self, conn: connection.Connection) -> None:
        """Perform encryption"""
        temp_file = NamedTemporaryFile(suffix=".vrs", delete=False)
        try:
            self._header(temp_file)
            self._write_data(temp_file, conn)
            temp_file.flush()
            temp_file.close()
            # once encryption is done, move the file to its final location
            shutil.move(temp_file.name, str(self._dest_file))
        except Exception:
            temp_file.close()
            Path(temp_file.name).unlink(missing_ok=True)
            raise


def _encrypt_file(
    src_file: Path,
    dest_file: Path,
    encryption_key: str,
    key_id: int,
    src_file_size: int,
    chunk_size: int,
    conn: connection.Connection,
) -> None:
    """Helper function to pass to the process pool
    Args:
        src_file: The file to encrypt
        dest_file: The encrypted file to create
        encryption_key: The RSA public key to encrypt the file
        key_id: The ID of provided encryption key
        src_file_size: The size of the source file
        chunk_size: The size of each chunk to encrypt
        conn: The connection (Pipe) to send progress updates over

    We use a temporary directory to avoid having to deal with partially encrypted file
    """
    FileEncryptor(
        encryption_key, key_id, chunk_size, src_file, dest_file, src_file_size
    ).encrypt(conn)
