# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import logging
import os
from asyncio import Semaphore, Task
from typing import Any, Dict, final, Optional

from aria_mps_cli.cli_lib.common import Config, run_subprocess_with_logging, to_proc
from aria_mps_cli.cli_lib.config_updatable import ConfigUpdatable
from aria_mps_cli.cli_lib.constants import (
    ConfigKey,
    ConfigSection,
    KEY_VHC_ARIA_GEN1_DEFAULT,
    KEY_VHC_ARIA_GEN2_DEFAULT,
    USE_ARK_APIS,
)
from aria_mps_cli.cli_lib.runner_with_progress import RunnerWithProgress
from aria_mps_cli.cli_lib.types import AriaRecording, MpsAriaDevice

logger = logging.getLogger(__name__)
config = Config.get()


def _run_vrs_health_check_in_process(path: str, json_out_filename: str) -> None:
    """
    Run VRS health check in a separate process to avoid blocking the event loop.

    The C++ run_vrs_health_check holds the GIL for its entire duration, which
    blocks the asyncio event loop even when wrapped in asyncio.to_thread().
    Running in a separate process avoids GIL contention entirely.

    The import is deferred to the child process so the C++ extension is loaded
    fresh there — the function object itself is not picklable, but this
    module-level wrapper with primitive arguments is.

    Args:
        path: Path to the VRS file
        json_out_filename: Output path for the health check JSON
    """
    from projectaria_vrs_health_check.vrs_health_check import run_vrs_health_check

    run_vrs_health_check(
        path=path, json_out_filename=json_out_filename, print_stats=True
    )


class HealthCheckRunner(RunnerWithProgress, ConfigUpdatable):
    """
    Run health check on a given vrs file.
    """

    semaphore_: Semaphore = Semaphore(
        value=config.getint(
            ConfigSection.HEALTH_CHECK, ConfigKey.CONCURRENT_HEALTH_CHECKS
        )
    )

    @classmethod
    def get_setting_keys(cls) -> tuple[str, str]:
        """Return the config section and key for the health check runner's semaphore setting"""
        return ConfigSection.HEALTH_CHECK, ConfigKey.CONCURRENT_HEALTH_CHECKS

    def __init__(self, recording: AriaRecording) -> None:
        self._recording: AriaRecording = recording

        # Declare for parent class
        self._task: Optional[Task] = None

    @classmethod
    @final
    def get_key(cls, recording: AriaRecording) -> str:
        """
        Get a unique key for this Runner instance.

        Args:
            recording (AriaRecording): The Aria Recording to get the key for.
        Returns:
            A unique key for this Runner instance.
        """

        return f"{recording.path}_{recording.health_check_path}"

    @final
    async def _run(self) -> None:
        """
        Run the health check on this vrs file.
        Repeatedly calling run will await on the same task
        """

        if self._recording.health_check_path.exists():
            logger.info(
                f"Health check found for {self._recording.path}, checking if this is valid"
            )
            try:
                device_type: Optional[MpsAriaDevice] = self._recording.device_type
                with open(self._recording.health_check_path, "r") as f:
                    vhc_json: Dict[str, Any] = json.load(f)
                if (
                    device_type == MpsAriaDevice.ARIA_GEN1
                    and KEY_VHC_ARIA_GEN1_DEFAULT in vhc_json
                ) or (
                    device_type == MpsAriaDevice.ARIA_GEN2
                    and KEY_VHC_ARIA_GEN2_DEFAULT in vhc_json
                ):
                    logger.info("Health check is valid")
                    return
                logger.error(
                    f"Invalid or older version health check found for {self._recording.path}"
                )
            except Exception as e:
                logger.error(f"Error checking health check validity: {e}")

        async with self.semaphore_:
            logger.info(f"Running health check on {self._recording.path}")
            if os.environ.get(USE_ARK_APIS):
                logger.info("Using VRS health check API directly")
                await to_proc(
                    _run_vrs_health_check_in_process,
                    self._recording.path.as_posix(),
                    self._recording.health_check_path.as_posix(),
                )
            else:
                logger.info("Running VRS health check binary directly")
                _, _, _ = await run_subprocess_with_logging(
                    "run_vrs_health_check",
                    "--path",
                    self._recording.path.as_posix(),
                    "--output-json",
                    self._recording.health_check_path.as_posix(),
                    "--print-stats",
                    logger_instance=logger,
                )
