# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import unittest

from aria_mps_cli.cli_lib.constants import (
    KEY_CDN_URL,
    KEY_CREATION_TIME,
    KEY_ERROR_CODE,
    KEY_FEATURE,
    KEY_FEATURES,
    KEY_FILE_HASH,
    KEY_ID,
    KEY_MPS_RESULTS,
    KEY_NAME,
    KEY_NODES,
    KEY_PERSIST_ON_FAILURE,
    KEY_RECORDING_HASH,
    KEY_RECORDING_NAME,
    KEY_RECORDINGS,
    KEY_REMAINING_TTL,
    KEY_RESULT_TYPE,
    KEY_STATUS,
    KEY_STATUS_MESSAGE,
)
from aria_mps_cli.cli_lib.response_parser import ResponseParser
from aria_mps_cli.cli_lib.types import MpsFeature, MpsResultType, Status


class TestResponseParserParseResults(unittest.TestCase):
    """Tests for ResponseParser.parse_results method."""

    def test_parse_results_empty_list(self) -> None:
        """
        Test parsing an empty results list.

        Arrange: Empty response list.
        Act: Call parse_results with empty list.
        Assert: Returns an empty list.
        """
        response: list = []

        results = ResponseParser.parse_results(response)

        self.assertEqual(results, [])

    def test_parse_results_single_result_with_recording_hash(self) -> None:
        """
        Test parsing a single result with recording_hash field.

        Arrange: Response with one result containing recording_hash.
        Act: Call parse_results.
        Assert: Returns list with one properly parsed MpsResult.
        """
        response = [
            {
                "id": 123,
                KEY_RESULT_TYPE: "SLAM_ZIP",
                KEY_CDN_URL: "https://example.com/result.zip",
                KEY_RECORDING_HASH: "abc123hash",
                KEY_RECORDING_NAME: "test_recording.vrs",
            }
        ]

        results = ResponseParser.parse_results(response)

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].fbid, 123)
        self.assertEqual(results[0].result_type, MpsResultType.SLAM_ZIP)
        self.assertEqual(results[0].cdn_url, "https://example.com/result.zip")
        self.assertEqual(results[0].recording_hash, "abc123hash")
        self.assertEqual(results[0].recording_name, "test_recording.vrs")

    def test_parse_results_fallback_to_file_hash(self) -> None:
        """
        Test parsing a result that uses deprecated file_hash field.

        Arrange: Response with file_hash instead of recording_hash.
        Act: Call parse_results.
        Assert: Falls back to file_hash for recording_hash value.
        """
        response = [
            {
                "id": 456,
                KEY_RESULT_TYPE: "EYE_GAZE_ZIP",
                KEY_CDN_URL: "https://example.com/eyegaze.zip",
                KEY_FILE_HASH: "legacy_hash_value",
            }
        ]

        results = ResponseParser.parse_results(response)

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].recording_hash, "legacy_hash_value")

    def test_parse_results_multiple_results(self) -> None:
        """
        Test parsing multiple results.

        Arrange: Response with multiple result entries.
        Act: Call parse_results.
        Assert: Returns list with all results properly parsed.
        """
        response = [
            {
                "id": 1,
                KEY_RESULT_TYPE: "SLAM_ZIP",
                KEY_CDN_URL: "https://example.com/slam.zip",
                KEY_RECORDING_HASH: "hash1",
            },
            {
                "id": 2,
                KEY_RESULT_TYPE: "EYE_GAZE_ZIP",
                KEY_CDN_URL: "https://example.com/eyegaze.zip",
                KEY_RECORDING_HASH: "hash2",
            },
            {
                "id": 3,
                KEY_RESULT_TYPE: "SUMMARY",
                KEY_CDN_URL: "https://example.com/summary.json",
                KEY_RECORDING_HASH: "hash3",
            },
        ]

        results = ResponseParser.parse_results(response)

        self.assertEqual(len(results), 3)
        self.assertEqual(results[0].fbid, 1)
        self.assertEqual(results[1].fbid, 2)
        self.assertEqual(results[2].fbid, 3)


class TestResponseParserParseMpsFeatureRequest(unittest.TestCase):
    """Tests for ResponseParser.parse_mps_feature_request method."""

    def test_parse_mps_feature_request_minimal(self) -> None:
        """
        Test parsing a minimal feature request response.

        Arrange: Response with required fields only.
        Act: Call parse_mps_feature_request.
        Assert: Returns properly parsed MpsFeatureRequest with empty results.
        """
        response = {
            KEY_ID: 789,
            KEY_STATUS: "SCHEDULED",
            KEY_FEATURE: "SLAM",
            KEY_ERROR_CODE: None,
            KEY_CREATION_TIME: 1234567890,
        }

        request = ResponseParser.parse_mps_feature_request(response)

        self.assertEqual(request.fbid, 789)
        self.assertEqual(request.status, Status.SCHEDULED)
        self.assertEqual(request.feature, MpsFeature.SLAM)
        self.assertIsNone(request.error_code)
        self.assertEqual(request.creation_time, 1234567890)
        self.assertEqual(request.results, [])

    def test_parse_mps_feature_request_with_results(self) -> None:
        """
        Test parsing a feature request with results.

        Arrange: Response with mps_results containing nodes.
        Act: Call parse_mps_feature_request.
        Assert: Returns MpsFeatureRequest with parsed results.
        """
        response = {
            KEY_ID: 100,
            KEY_STATUS: "SUCCEEDED",
            KEY_FEATURE: "EYE_GAZE",
            KEY_ERROR_CODE: None,
            KEY_CREATION_TIME: 1234567890,
            KEY_MPS_RESULTS: {
                KEY_NODES: [
                    {
                        "id": 200,
                        KEY_RESULT_TYPE: "EYE_GAZE_ZIP",
                        KEY_CDN_URL: "https://example.com/eyegaze.zip",
                        KEY_RECORDING_HASH: "testhash",
                    }
                ]
            },
        }

        request = ResponseParser.parse_mps_feature_request(response)

        self.assertEqual(request.status, Status.SUCCEEDED)
        self.assertEqual(len(request.results), 1)
        self.assertEqual(request.results[0].fbid, 200)

    def test_parse_mps_feature_request_with_error(self) -> None:
        """
        Test parsing a feature request with error code and message.

        Arrange: Response with error_code and status_message.
        Act: Call parse_mps_feature_request.
        Assert: Returns MpsFeatureRequest with error information.
        """
        response = {
            KEY_ID: 300,
            KEY_STATUS: "FAILED",
            KEY_FEATURE: "SLAM",
            KEY_ERROR_CODE: 102,
            KEY_STATUS_MESSAGE: "Health check failed",
            KEY_CREATION_TIME: 1234567890,
        }

        request = ResponseParser.parse_mps_feature_request(response)

        self.assertEqual(request.status, Status.FAILED)
        self.assertEqual(request.error_code, 102)
        self.assertEqual(request.status_message, "Health check failed")


class TestResponseParserParseMpsRequest(unittest.TestCase):
    """Tests for ResponseParser.parse_mps_request method."""

    def test_parse_mps_request_minimal(self) -> None:
        """
        Test parsing a minimal MPS request response.

        Arrange: Response with required fields and empty features/recordings.
        Act: Call parse_mps_request.
        Assert: Returns properly parsed MpsRequest.
        """
        response = {
            KEY_ID: 1000,
            KEY_NAME: "test_request",
            KEY_CREATION_TIME: 1234567890,
            KEY_FEATURES: {KEY_NODES: []},
        }

        request = ResponseParser.parse_mps_request(response)

        self.assertEqual(request.fbid, 1000)
        self.assertEqual(request.name, "test_request")
        self.assertEqual(request.creation_time, 1234567890)
        self.assertEqual(request.features, {})
        self.assertEqual(request.recordings_fbids, [])
        self.assertFalse(request.persist_on_failure)

    def test_parse_mps_request_with_recordings(self) -> None:
        """
        Test parsing an MPS request with recordings.

        Arrange: Response with recordings nodes.
        Act: Call parse_mps_request.
        Assert: Returns MpsRequest with recording IDs.
        """
        response = {
            KEY_ID: 2000,
            KEY_NAME: "request_with_recordings",
            KEY_CREATION_TIME: 1234567890,
            KEY_FEATURES: {KEY_NODES: []},
            KEY_RECORDINGS: {
                KEY_NODES: [
                    {KEY_ID: 5001},
                    {KEY_ID: 5002},
                    {KEY_ID: 5003},
                ]
            },
        }

        request = ResponseParser.parse_mps_request(response)

        self.assertEqual(request.recordings_fbids, [5001, 5002, 5003])

    def test_parse_mps_request_with_persist_on_failure(self) -> None:
        """
        Test parsing an MPS request with persist_on_failure flag.

        Arrange: Response with persist_on_failure set to True.
        Act: Call parse_mps_request.
        Assert: Returns MpsRequest with persist_on_failure True.
        """
        response = {
            KEY_ID: 3000,
            KEY_NAME: "persistent_request",
            KEY_CREATION_TIME: 1234567890,
            KEY_FEATURES: {KEY_NODES: []},
            KEY_PERSIST_ON_FAILURE: True,
        }

        request = ResponseParser.parse_mps_request(response)

        self.assertTrue(request.persist_on_failure)

    def test_parse_mps_request_with_features(self) -> None:
        """
        Test parsing an MPS request with features.

        Arrange: Response with feature nodes.
        Act: Call parse_mps_request.
        Assert: Returns MpsRequest with features dictionary.
        """
        response = {
            KEY_ID: 4000,
            KEY_NAME: "request_with_features",
            KEY_CREATION_TIME: 1234567890,
            KEY_FEATURES: {
                KEY_NODES: [
                    {
                        KEY_ID: 6001,
                        KEY_STATUS: "PROCESSING",
                        KEY_FEATURE: "SLAM",
                        KEY_ERROR_CODE: None,
                        KEY_CREATION_TIME: 1234567890,
                    },
                    {
                        KEY_ID: 6002,
                        KEY_STATUS: "SCHEDULED",
                        KEY_FEATURE: "EYE_GAZE",
                        KEY_ERROR_CODE: None,
                        KEY_CREATION_TIME: 1234567891,
                    },
                ]
            },
        }

        request = ResponseParser.parse_mps_request(response)

        self.assertEqual(len(request.features), 2)
        self.assertIn(MpsFeature.SLAM, request.features)
        self.assertIn(MpsFeature.EYE_GAZE, request.features)
        self.assertEqual(request.features[MpsFeature.SLAM].status, Status.PROCESSING)
        self.assertEqual(request.features[MpsFeature.EYE_GAZE].status, Status.SCHEDULED)


class TestResponseParserParseRecordingIdAndTtl(unittest.TestCase):
    """Tests for ResponseParser.parse_recording_id_and_ttl method."""

    def test_parse_recording_id_and_ttl_with_recording(self) -> None:
        """
        Test parsing response with valid recording.

        Arrange: Response with recording containing id and remaining_ttl.
        Act: Call parse_recording_id_and_ttl.
        Assert: Returns tuple of (id, ttl).
        """
        response = {"recording": {KEY_ID: "12345", KEY_REMAINING_TTL: "86400"}}

        result = ResponseParser.parse_recording_id_and_ttl(response)

        self.assertIsNotNone(result)
        self.assertEqual(result[0], 12345)
        self.assertEqual(result[1], 86400)

    def test_parse_recording_id_and_ttl_with_none_recording(self) -> None:
        """
        Test parsing response with null recording.

        Arrange: Response with recording set to None.
        Act: Call parse_recording_id_and_ttl.
        Assert: Returns None.
        """
        response = {"recording": None}

        result = ResponseParser.parse_recording_id_and_ttl(response)

        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()
