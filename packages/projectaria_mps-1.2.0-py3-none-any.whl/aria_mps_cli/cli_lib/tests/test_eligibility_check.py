# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import tempfile
import unittest
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional


class MpsFeature(Enum):
    """Mock MpsFeature enum for testing."""

    SLAM = "SLAM"
    EYE_GAZE = "EYE_GAZE"
    MULTI_SLAM = "MULTI_SLAM"
    HAND_TRACKING = "HAND_TRACKING"


class MpsAriaDevice(Enum):
    """Mock MpsAriaDevice enum for testing."""

    ARIA_GEN1 = "ARIA_GEN1"
    ARIA_GEN2 = "ARIA_GEN2"
    UNKNOWN = "UNKNOWN"


class ErrorCode:
    """Mock ErrorCode constants for testing."""

    HEALTH_CHECK_FAILURE = 1001
    DEVICE_TYPE_UNSUPPORTED = 1002


VHC_KEY_SECTION_LOCATION_GEN1 = "AriaGen1_Location"
VHC_KEY_SECTION_LOCATION_GEN2 = "AriaGen2_Location"
VHC_KEY_SECTION_HAND_TRACKING_GEN1 = "AriaGen1_Handtracking"
VHC_KEY_SECTION_HAND_TRACKING_GEN2 = "AriaGen2_Handtracking"
KEY_VHC_ARIA_GEN1_DEFAULT = "AriaGen1"
KEY_VHC_ARIA_GEN2_DEFAULT = "AriaGen2"


def is_eligible(
    vhc_json: Dict[str, Any],
    section_name: str,
) -> Optional[int]:
    """
    Check if the Aria Recording's stream is eligible for MPS processing.
    Simplified version for testing.
    """
    VHC_OUT_FAIL = "fail"
    VHC_KEY_FINAL_RESULT = "final_result"

    section = vhc_json.get(section_name, {})
    status = section.get(VHC_KEY_FINAL_RESULT)

    if not status:
        return ErrorCode.HEALTH_CHECK_FAILURE

    return ErrorCode.HEALTH_CHECK_FAILURE if status == VHC_OUT_FAIL else None


class TestIsEligible(unittest.TestCase):
    """Tests for the is_eligible function."""

    def test_pass_status_returns_none(self) -> None:
        """
        Test that 'pass' status returns None (eligible).

        Arrange: VHC JSON with 'pass' status.
        Act: Call is_eligible.
        Assert: Returns None.
        """
        vhc_json = {
            "AriaGen1_Location": {
                "final_result": "pass",
            }
        }

        result = is_eligible(vhc_json, "AriaGen1_Location")

        self.assertIsNone(result)

    def test_warn_status_returns_none(self) -> None:
        """
        Test that 'warn' status returns None (eligible with warnings).

        Arrange: VHC JSON with 'warn' status.
        Act: Call is_eligible.
        Assert: Returns None.
        """
        vhc_json = {
            "AriaGen1_Location": {
                "final_result": "warn",
            }
        }

        result = is_eligible(vhc_json, "AriaGen1_Location")

        self.assertIsNone(result)

    def test_fail_status_returns_error_code(self) -> None:
        """
        Test that 'fail' status returns error code.

        Arrange: VHC JSON with 'fail' status.
        Act: Call is_eligible.
        Assert: Returns HEALTH_CHECK_FAILURE.
        """
        vhc_json = {
            "AriaGen1_Location": {
                "final_result": "fail",
            }
        }

        result = is_eligible(vhc_json, "AriaGen1_Location")

        self.assertEqual(result, ErrorCode.HEALTH_CHECK_FAILURE)

    def test_missing_status_returns_error_code(self) -> None:
        """
        Test that missing status returns error code.

        Arrange: VHC JSON without final_result.
        Act: Call is_eligible.
        Assert: Returns HEALTH_CHECK_FAILURE.
        """
        vhc_json = {"AriaGen1_Location": {}}

        result = is_eligible(vhc_json, "AriaGen1_Location")

        self.assertEqual(result, ErrorCode.HEALTH_CHECK_FAILURE)

    def test_missing_section_returns_error_code(self) -> None:
        """
        Test that missing section returns error code.

        Arrange: VHC JSON without required section.
        Act: Call is_eligible.
        Assert: Returns HEALTH_CHECK_FAILURE.
        """
        vhc_json = {}

        result = is_eligible(vhc_json, "AriaGen1_Location")

        self.assertEqual(result, ErrorCode.HEALTH_CHECK_FAILURE)


class TestEligibilityCheckGen1(unittest.TestCase):
    """Tests for Gen1 eligibility checking logic."""

    def test_eye_camera_stream_missing_fails(self) -> None:
        """
        Test that missing eye camera stream fails for eye gaze.

        Arrange: VHC JSON without eye camera stream.
        Act: Check for eye camera stream.
        Assert: Stream check fails.
        """
        vhc_json = {KEY_VHC_ARIA_GEN1_DEFAULT: {"performed_checks_with_details": {}}}
        eye_camera_key = "Eye Camera Class #1"

        section = vhc_json[KEY_VHC_ARIA_GEN1_DEFAULT]
        has_stream = eye_camera_key in section["performed_checks_with_details"]

        self.assertFalse(has_stream)

    def test_eye_camera_stream_present_passes(self) -> None:
        """
        Test that present eye camera stream passes initial check.

        Arrange: VHC JSON with eye camera stream.
        Act: Check for eye camera stream.
        Assert: Stream check passes.
        """
        vhc_json = {
            KEY_VHC_ARIA_GEN1_DEFAULT: {
                "performed_checks_with_details": {"Eye Camera Class #1": {}}
            }
        }
        eye_camera_key = "Eye Camera Class #1"

        section = vhc_json[KEY_VHC_ARIA_GEN1_DEFAULT]
        has_stream = eye_camera_key in section["performed_checks_with_details"]

        self.assertTrue(has_stream)


class TestEligibilityCheckGen2(unittest.TestCase):
    """Tests for Gen2 eligibility checking logic."""

    def test_eye_gaze_returns_unsupported(self) -> None:
        """
        Test that eye gaze feature returns unsupported for Gen2.

        Arrange: Gen2 device with EYE_GAZE feature request.
        Act: Check eligibility.
        Assert: Returns DEVICE_TYPE_UNSUPPORTED.
        """
        feature = MpsFeature.EYE_GAZE
        device_type = MpsAriaDevice.ARIA_GEN2

        if device_type == MpsAriaDevice.ARIA_GEN2 and feature == MpsFeature.EYE_GAZE:
            result = ErrorCode.DEVICE_TYPE_UNSUPPORTED
        else:
            result = None

        self.assertEqual(result, ErrorCode.DEVICE_TYPE_UNSUPPORTED)

    def test_slam_supported_for_gen2(self) -> None:
        """
        Test that SLAM feature is supported for Gen2.

        Arrange: Gen2 device with SLAM feature request.
        Act: Check eligibility.
        Assert: No error (supported).
        """
        feature = MpsFeature.SLAM
        device_type = MpsAriaDevice.ARIA_GEN2

        if device_type == MpsAriaDevice.ARIA_GEN2 and feature == MpsFeature.EYE_GAZE:
            result = ErrorCode.DEVICE_TYPE_UNSUPPORTED
        else:
            result = None

        self.assertIsNone(result)


class TestHealthCheckFileReading(unittest.TestCase):
    """Tests for health check file reading logic."""

    def test_read_valid_health_check_json(self) -> None:
        """
        Test reading valid health check JSON file.

        Arrange: Create temp file with valid JSON.
        Act: Read and parse JSON.
        Assert: JSON is parsed correctly.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            health_check_path = Path(tmpdir) / "vrs_health_check.json"
            expected_data = {KEY_VHC_ARIA_GEN1_DEFAULT: {"final_result": "pass"}}
            health_check_path.write_text(json.dumps(expected_data))

            with open(health_check_path) as f:
                vhc_json = json.load(f)

            self.assertEqual(vhc_json, expected_data)

    def test_health_check_file_not_found(self) -> None:
        """
        Test handling of missing health check file.

        Arrange: Non-existent health check path.
        Act: Check file existence.
        Assert: File does not exist.
        """
        health_check_path = Path("/nonexistent/vrs_health_check.json")

        self.assertFalse(health_check_path.exists())


class TestFeatureSectionMapping(unittest.TestCase):
    """Tests for feature to VHC section mapping."""

    def test_slam_maps_to_location_section(self) -> None:
        """
        Test that SLAM feature maps to location section.

        Arrange: SLAM feature.
        Act: Determine section name.
        Assert: Maps to location section.
        """
        feature = MpsFeature.SLAM
        device_type = MpsAriaDevice.ARIA_GEN1

        if feature in [MpsFeature.SLAM, MpsFeature.MULTI_SLAM]:
            if device_type == MpsAriaDevice.ARIA_GEN1:
                section = VHC_KEY_SECTION_LOCATION_GEN1
            else:
                section = VHC_KEY_SECTION_LOCATION_GEN2
        else:
            section = None

        self.assertEqual(section, "AriaGen1_Location")

    def test_hand_tracking_maps_to_handtracking_section(self) -> None:
        """
        Test that HAND_TRACKING feature maps to handtracking section.

        Arrange: HAND_TRACKING feature.
        Act: Determine section name.
        Assert: Maps to handtracking section.
        """
        feature = MpsFeature.HAND_TRACKING
        device_type = MpsAriaDevice.ARIA_GEN1

        if feature == MpsFeature.HAND_TRACKING:
            if device_type == MpsAriaDevice.ARIA_GEN1:
                section = VHC_KEY_SECTION_HAND_TRACKING_GEN1
            else:
                section = VHC_KEY_SECTION_HAND_TRACKING_GEN2
        else:
            section = None

        self.assertEqual(section, "AriaGen1_Handtracking")


if __name__ == "__main__":
    unittest.main()
