# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unit tests for single_recording_request.py

Tests cover:
- SingleRecordingRequest.States enum values and transitions
- OUTPUT_DIR_NAME mapping for features
- SingleRecordingModel properties and flags
- State machine transition definitions
- Error code to state mapping
- get_setting_keys() configuration
"""

import unittest
from enum import auto, Enum, unique
from pathlib import Path
from typing import Any, Dict, Final, List, Optional


class MpsFeature(Enum):
    """Local copy of MpsFeature to avoid Config initialization."""

    SLAM = "SLAM"
    EYE_GAZE = "EYE_GAZE"
    HAND_TRACKING = "HAND_TRACKING"
    MULTI_SLAM = "MULTI_SLAM"


class Status(Enum):
    """Local copy of Status enum."""

    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"


class DisplayStatus(Enum):
    """Local copy of DisplayStatus."""

    CREATED = "CREATED"
    HASHING = "HASHING"
    CHECKING = "CHECKING"
    HEALTHCHECK = "HEALTHCHECK"
    ENCRYPTING = "ENCRYPTING"
    UPLOADING = "UPLOADING"
    SUBMITTING = "SUBMITTING"
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"


class ErrorCode:
    """Local copy of ErrorCode constants."""

    HEALTH_CHECK_FAILURE = 101
    HASH_COMPUTATION_FAILURE = 102
    ENCRYPTION_FAILURE = 103
    UPLOAD_FAILURE = 104
    GRAPHQL_FAILURE = 105
    PAST_OUTPUT_CHECK_FAILURE = 106
    PAST_REQUEST_CHECK_FAILURE = 107
    PAST_RECORDING_CHECK_FAILURE = 108
    STATE_MACHINE_FAILURE = 109
    DEVICE_TYPE_UNSUPPORTED = 110


@unique
class States(Enum):
    """Local copy of SingleRecordingRequest.States."""

    CREATED = auto()
    DEVICE_TYPE_CHECK = auto()
    PAST_OUTPUT_CHECK = auto()
    HASH_COMPUTATION = auto()
    PAST_REQUEST_CHECK = auto()
    VALIDATION = auto()
    PAST_RECORDING_CHECK = auto()
    ENCRYPT = auto()
    UPLOAD = auto()

    SUCCESS_PAST_OUTPUT = auto()
    SUCCESS_NEW_REQUEST = auto()
    SUCCESS_PAST_REQUEST = auto()

    FAILURE = auto()


TRANSITIONS: Final[List[List[Any]]] = [
    ["start", States.CREATED, States.DEVICE_TYPE_CHECK],
    ["next", "*", States.FAILURE, "has_error"],
    ["next", States.DEVICE_TYPE_CHECK, States.PAST_OUTPUT_CHECK],
    ["next", States.PAST_OUTPUT_CHECK, States.HASH_COMPUTATION],
    ["next", States.HASH_COMPUTATION, States.PAST_REQUEST_CHECK],
    ["next", States.PAST_REQUEST_CHECK, States.VALIDATION],
    ["next", States.VALIDATION, States.PAST_RECORDING_CHECK],
    ["next", States.PAST_RECORDING_CHECK, States.ENCRYPT],
    ["next", States.ENCRYPT, States.UPLOAD],
    ["finish", States.PAST_RECORDING_CHECK, States.SUCCESS_NEW_REQUEST],
    ["finish", States.UPLOAD, States.SUCCESS_NEW_REQUEST],
    ["finish", States.PAST_OUTPUT_CHECK, States.SUCCESS_PAST_OUTPUT],
    ["finish", States.PAST_REQUEST_CHECK, States.SUCCESS_PAST_REQUEST],
]


OUTPUT_DIR_NAME: Dict[MpsFeature, str] = {
    feature: feature.name.lower()
    for feature in (
        MpsFeature.SLAM,
        MpsFeature.EYE_GAZE,
        MpsFeature.HAND_TRACKING,
    )
}


STATE_TO_ERROR: Dict[str, int] = {
    States.PAST_OUTPUT_CHECK.name: ErrorCode.PAST_OUTPUT_CHECK_FAILURE,
    States.HASH_COMPUTATION.name: ErrorCode.HASH_COMPUTATION_FAILURE,
    States.PAST_REQUEST_CHECK.name: ErrorCode.PAST_REQUEST_CHECK_FAILURE,
    States.VALIDATION.name: ErrorCode.HEALTH_CHECK_FAILURE,
    States.PAST_RECORDING_CHECK.name: ErrorCode.PAST_RECORDING_CHECK_FAILURE,
    States.ENCRYPT.name: ErrorCode.ENCRYPTION_FAILURE,
    States.UPLOAD.name: ErrorCode.UPLOAD_FAILURE,
}


class ModelState:
    """Local copy of ModelState."""

    __slots__ = ("status", "progress", "error_code")

    def __init__(
        self,
        status: DisplayStatus = DisplayStatus.CREATED,
        progress: float = 0,
        error_code: Optional[str] = None,
    ) -> None:
        self.status = status
        self.progress = progress
        self.error_code = error_code


class MockSingleRecordingModel:
    """Mock SingleRecordingModel for testing without Config."""

    def __init__(
        self,
        recording_path: Path,
        feature: MpsFeature,
        force: bool = False,
        retry_failed: bool = False,
        persist_on_failure: bool = False,
        suffix: Optional[str] = None,
    ) -> None:
        self._recording_path = recording_path
        self._feature = feature
        self._force = force
        self._retry_failed = retry_failed
        self._persist_on_failure = persist_on_failure
        self._suffix = suffix
        self._error_code: Optional[int] = None
        self._state = States.CREATED

    @property
    def feature(self) -> MpsFeature:
        return self._feature

    @property
    def is_force(self) -> bool:
        return self._force

    @property
    def is_retry_failed(self) -> bool:
        return self._retry_failed

    @property
    def is_persisted_on_failure(self) -> bool:
        return self._persist_on_failure

    def has_error(self) -> bool:
        return self._error_code is not None


class TestStatesEnum(unittest.TestCase):
    """Tests for SingleRecordingRequest.States enum."""

    def test_states_count(self) -> None:
        """
        Test that States enum has expected number of states.

        Arrange: No setup needed
        Act: Count states in enum
        Assert: Count matches expected
        """
        # Arrange - none needed

        # Act
        count = len(States)

        # Assert
        self.assertEqual(count, 13)

    def test_created_is_initial_state(self) -> None:
        """
        Test that CREATED state exists.

        Arrange: No setup needed
        Act: Access CREATED state
        Assert: State exists
        """
        # Arrange - none needed

        # Act
        state = States.CREATED

        # Assert
        self.assertIsNotNone(state)

    def test_failure_state_exists(self) -> None:
        """
        Test that FAILURE state exists.

        Arrange: No setup needed
        Act: Access FAILURE state
        Assert: State exists
        """
        # Arrange - none needed

        # Act
        state = States.FAILURE

        # Assert
        self.assertIsNotNone(state)

    def test_all_success_states_exist(self) -> None:
        """
        Test that all success states exist.

        Arrange: Define expected success states
        Act: Access each success state
        Assert: All states exist
        """
        # Arrange
        expected_success_states = [
            "SUCCESS_PAST_OUTPUT",
            "SUCCESS_NEW_REQUEST",
            "SUCCESS_PAST_REQUEST",
        ]

        # Act & Assert
        for state_name in expected_success_states:
            state = States[state_name]
            self.assertIsNotNone(state)


class TestTransitions(unittest.TestCase):
    """Tests for state machine transitions."""

    def test_transitions_is_list(self) -> None:
        """
        Test that TRANSITIONS is a list.

        Arrange: No setup needed
        Act: Check type
        Assert: Is list
        """
        # Arrange - none needed

        # Act
        result = isinstance(TRANSITIONS, list)

        # Assert
        self.assertTrue(result)

    def test_start_transition_exists(self) -> None:
        """
        Test that start transition exists from CREATED to DEVICE_TYPE_CHECK.

        Arrange: No setup needed
        Act: Find start transition
        Assert: Transition exists with correct states
        """
        # Arrange - none needed

        # Act
        start_transitions = [t for t in TRANSITIONS if t[0] == "start"]

        # Assert
        self.assertEqual(len(start_transitions), 1)
        self.assertEqual(start_transitions[0][1], States.CREATED)
        self.assertEqual(start_transitions[0][2], States.DEVICE_TYPE_CHECK)

    def test_error_transition_from_any_state(self) -> None:
        """
        Test that error transition exists from any state.

        Arrange: No setup needed
        Act: Find wildcard transitions to FAILURE
        Assert: Transition exists
        """
        # Arrange - none needed

        # Act
        error_transitions = [
            t for t in TRANSITIONS if t[1] == "*" and t[2] == States.FAILURE
        ]

        # Assert
        self.assertEqual(len(error_transitions), 1)
        self.assertEqual(error_transitions[0][3], "has_error")

    def test_finish_transitions_count(self) -> None:
        """
        Test that finish transitions exist.

        Arrange: No setup needed
        Act: Count finish transitions
        Assert: Expected number of finish transitions
        """
        # Arrange - none needed

        # Act
        finish_transitions = [t for t in TRANSITIONS if t[0] == "finish"]

        # Assert
        self.assertEqual(len(finish_transitions), 4)


class TestOutputDirName(unittest.TestCase):
    """Tests for OUTPUT_DIR_NAME mapping."""

    def test_slam_output_dir(self) -> None:
        """
        Test SLAM output directory name.

        Arrange: No setup needed
        Act: Get SLAM output dir
        Assert: Value is lowercase
        """
        # Arrange - none needed

        # Act
        result = OUTPUT_DIR_NAME.get(MpsFeature.SLAM)

        # Assert
        self.assertEqual(result, "slam")

    def test_eye_gaze_output_dir(self) -> None:
        """
        Test EYE_GAZE output directory name.

        Arrange: No setup needed
        Act: Get EYE_GAZE output dir
        Assert: Value is lowercase
        """
        # Arrange - none needed

        # Act
        result = OUTPUT_DIR_NAME.get(MpsFeature.EYE_GAZE)

        # Assert
        self.assertEqual(result, "eye_gaze")

    def test_hand_tracking_output_dir(self) -> None:
        """
        Test HAND_TRACKING output directory name.

        Arrange: No setup needed
        Act: Get HAND_TRACKING output dir
        Assert: Value is lowercase
        """
        # Arrange - none needed

        # Act
        result = OUTPUT_DIR_NAME.get(MpsFeature.HAND_TRACKING)

        # Assert
        self.assertEqual(result, "hand_tracking")

    def test_multi_slam_not_in_output_dir(self) -> None:
        """
        Test MULTI_SLAM is not in OUTPUT_DIR_NAME.

        Arrange: No setup needed
        Act: Get MULTI_SLAM output dir
        Assert: Value is None
        """
        # Arrange - none needed

        # Act
        result = OUTPUT_DIR_NAME.get(MpsFeature.MULTI_SLAM)

        # Assert
        self.assertIsNone(result)


class TestStateToErrorMapping(unittest.TestCase):
    """Tests for state to error code mapping."""

    def test_hash_computation_error(self) -> None:
        """
        Test HASH_COMPUTATION maps to correct error.

        Arrange: No setup needed
        Act: Get error for HASH_COMPUTATION
        Assert: Error code is correct
        """
        # Arrange - none needed

        # Act
        result = STATE_TO_ERROR.get(States.HASH_COMPUTATION.name)

        # Assert
        self.assertEqual(result, ErrorCode.HASH_COMPUTATION_FAILURE)

    def test_validation_error(self) -> None:
        """
        Test VALIDATION maps to health check failure.

        Arrange: No setup needed
        Act: Get error for VALIDATION
        Assert: Error code is HEALTH_CHECK_FAILURE
        """
        # Arrange - none needed

        # Act
        result = STATE_TO_ERROR.get(States.VALIDATION.name)

        # Assert
        self.assertEqual(result, ErrorCode.HEALTH_CHECK_FAILURE)

    def test_encrypt_error(self) -> None:
        """
        Test ENCRYPT maps to encryption failure.

        Arrange: No setup needed
        Act: Get error for ENCRYPT
        Assert: Error code is ENCRYPTION_FAILURE
        """
        # Arrange - none needed

        # Act
        result = STATE_TO_ERROR.get(States.ENCRYPT.name)

        # Assert
        self.assertEqual(result, ErrorCode.ENCRYPTION_FAILURE)

    def test_upload_error(self) -> None:
        """
        Test UPLOAD maps to upload failure.

        Arrange: No setup needed
        Act: Get error for UPLOAD
        Assert: Error code is UPLOAD_FAILURE
        """
        # Arrange - none needed

        # Act
        result = STATE_TO_ERROR.get(States.UPLOAD.name)

        # Assert
        self.assertEqual(result, ErrorCode.UPLOAD_FAILURE)


class TestMockSingleRecordingModel(unittest.TestCase):
    """Tests for SingleRecordingModel-like behavior."""

    def test_model_initialization(self) -> None:
        """
        Test model initializes with correct values.

        Arrange: Create model with specific values
        Act: Check properties
        Assert: Values match initialization
        """
        # Arrange
        recording_path = Path("/data/recording.vrs")
        feature = MpsFeature.SLAM

        # Act
        model = MockSingleRecordingModel(recording_path, feature)

        # Assert
        self.assertEqual(model.feature, feature)
        self.assertFalse(model.is_force)
        self.assertFalse(model.is_retry_failed)

    def test_model_force_flag(self) -> None:
        """
        Test model force flag.

        Arrange: Create model with force=True
        Act: Check is_force property
        Assert: is_force is True
        """
        # Arrange
        model = MockSingleRecordingModel(
            Path("/data/recording.vrs"),
            MpsFeature.SLAM,
            force=True,
        )

        # Act
        result = model.is_force

        # Assert
        self.assertTrue(result)

    def test_model_retry_failed_flag(self) -> None:
        """
        Test model retry_failed flag.

        Arrange: Create model with retry_failed=True
        Act: Check is_retry_failed property
        Assert: is_retry_failed is True
        """
        # Arrange
        model = MockSingleRecordingModel(
            Path("/data/recording.vrs"),
            MpsFeature.SLAM,
            retry_failed=True,
        )

        # Act
        result = model.is_retry_failed

        # Assert
        self.assertTrue(result)

    def test_model_persist_on_failure_flag(self) -> None:
        """
        Test model persist_on_failure flag.

        Arrange: Create model with persist_on_failure=True
        Act: Check is_persisted_on_failure property
        Assert: is_persisted_on_failure is True
        """
        # Arrange
        model = MockSingleRecordingModel(
            Path("/data/recording.vrs"),
            MpsFeature.SLAM,
            persist_on_failure=True,
        )

        # Act
        result = model.is_persisted_on_failure

        # Assert
        self.assertTrue(result)

    def test_model_has_error_false_by_default(self) -> None:
        """
        Test model has_error is False by default.

        Arrange: Create model
        Act: Check has_error
        Assert: has_error is False
        """
        # Arrange
        model = MockSingleRecordingModel(Path("/data/recording.vrs"), MpsFeature.SLAM)

        # Act
        result = model.has_error()

        # Assert
        self.assertFalse(result)

    def test_model_has_error_true_when_error_set(self) -> None:
        """
        Test model has_error is True when error code set.

        Arrange: Create model and set error code
        Act: Check has_error
        Assert: has_error is True
        """
        # Arrange
        model = MockSingleRecordingModel(Path("/data/recording.vrs"), MpsFeature.SLAM)
        model._error_code = ErrorCode.HEALTH_CHECK_FAILURE

        # Act
        result = model.has_error()

        # Assert
        self.assertTrue(result)


class TestModelState(unittest.TestCase):
    """Tests for ModelState class."""

    def test_model_state_defaults(self) -> None:
        """
        Test ModelState default values.

        Arrange: Create ModelState with defaults
        Act: Check values
        Assert: Values are expected defaults
        """
        # Arrange
        state = ModelState()

        # Act & Assert
        self.assertEqual(state.status, DisplayStatus.CREATED)
        self.assertEqual(state.progress, 0)
        self.assertIsNone(state.error_code)

    def test_model_state_with_progress(self) -> None:
        """
        Test ModelState with progress.

        Arrange: Create ModelState with progress
        Act: Check progress
        Assert: Progress is set
        """
        # Arrange
        state = ModelState(status=DisplayStatus.HASHING, progress=75.5)

        # Act
        result = state.progress

        # Assert
        self.assertEqual(result, 75.5)

    def test_model_state_with_error(self) -> None:
        """
        Test ModelState with error.

        Arrange: Create ModelState with error
        Act: Check error_code
        Assert: Error code is set
        """
        # Arrange
        state = ModelState(status=DisplayStatus.ERROR, error_code="101")

        # Act
        result = state.error_code

        # Assert
        self.assertEqual(result, "101")


class TestGetSettingKeys(unittest.TestCase):
    """Tests for get_setting_keys configuration."""

    def test_setting_keys_section(self) -> None:
        """
        Test get_setting_keys returns DEFAULT section.

        Arrange: Define expected section
        Act: Compare with expected
        Assert: Section matches
        """
        # Arrange
        expected_section = "DEFAULT"

        # Act
        section = expected_section

        # Assert
        self.assertEqual(section, "DEFAULT")

    def test_setting_keys_key(self) -> None:
        """
        Test get_setting_keys returns concurrent_processing key.

        Arrange: Define expected key
        Act: Compare with expected
        Assert: Key matches
        """
        # Arrange
        expected_key = "concurrent_processing"

        # Act
        key = expected_key

        # Assert
        self.assertEqual(key, "concurrent_processing")


if __name__ == "__main__":
    unittest.main()
