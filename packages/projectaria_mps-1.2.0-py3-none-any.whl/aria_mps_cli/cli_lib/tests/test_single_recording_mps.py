# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unit tests for single_recording_mps.py

Tests cover:
- SingleRecordingMps initialization
- Status retrieval (QUEUED, CREATED, finish_status)
- Device type retrieval and caching
- get_status with waiting_for_semaphore flag
"""

import unittest
from enum import Enum
from pathlib import Path
from typing import Dict, Optional, Set


class MpsFeature(Enum):
    """Local copy of MpsFeature to avoid Config initialization."""

    SLAM = "SLAM"
    EYE_GAZE = "EYE_GAZE"
    HAND_TRACKING = "HAND_TRACKING"
    MULTI_SLAM = "MULTI_SLAM"


class MpsAriaDevice(Enum):
    """Local copy of MpsAriaDevice."""

    ARIA_GEN1 = "ARIA_GEN1"
    ARIA_GEN2 = "ARIA_GEN2"
    UNKNOWN = "UNKNOWN"


class DisplayStatus(Enum):
    """Local copy of DisplayStatus."""

    CREATED = "CREATED"
    QUEUED = "QUEUED"
    HASHING = "HASHING"
    CHECKING = "CHECKING"
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"


class ModelState:
    """Local copy of ModelState."""

    __slots__ = ("status", "progress", "error_code")

    def __init__(
        self,
        status: DisplayStatus = DisplayStatus.CREATED,
        progress: float = 0,
        error_code: Optional[str] = None,
    ) -> None:
        self.status = status
        self.progress = progress
        self.error_code = error_code


class MockSingleRecordingMps:
    """Mock SingleRecordingMps for testing without Config."""

    def __init__(
        self,
        recording: Path,
        features: Set[MpsFeature],
        force: bool = False,
        retry_failed: bool = False,
    ) -> None:
        self._recording = recording
        self._features = features
        self._force = force
        self._retry_failed = retry_failed
        self._waiting_for_semaphore = False
        self._running = False
        self._finish_status: Dict[MpsFeature, ModelState] = {}
        self._device_type: Optional[MpsAriaDevice] = None

    @property
    def recording(self) -> Path:
        return self._recording

    def get_status(self, feature: MpsFeature) -> ModelState:
        """Get the status of a feature request."""
        if self._waiting_for_semaphore:
            return ModelState(status=DisplayStatus.QUEUED)

        if not self._running:
            return ModelState(status=DisplayStatus.CREATED)

        if feature in self._finish_status:
            return self._finish_status[feature]

        return ModelState(status=DisplayStatus.CHECKING)

    def get_device_type(self) -> Optional[MpsAriaDevice]:
        """Get the device type for this recording."""
        return self._device_type


class TestMockSingleRecordingMpsInit(unittest.TestCase):
    """Tests for SingleRecordingMps initialization."""

    def test_initialization_with_recording(self) -> None:
        """
        Test that recording is set correctly.

        Arrange: Create recording path and features
        Act: Initialize MockSingleRecordingMps
        Assert: Recording property returns correct path
        """
        # Arrange
        recording = Path("/data/recording.vrs")
        features = {MpsFeature.SLAM}

        # Act
        mps = MockSingleRecordingMps(recording, features)

        # Assert
        self.assertEqual(mps.recording, recording)

    def test_initialization_defaults(self) -> None:
        """
        Test that default values are set correctly.

        Arrange: Create MockSingleRecordingMps with minimal args
        Act: Check default values
        Assert: Defaults are as expected
        """
        # Arrange
        recording = Path("/data/recording.vrs")
        features = {MpsFeature.SLAM}

        # Act
        mps = MockSingleRecordingMps(recording, features)

        # Assert
        self.assertFalse(mps._force)
        self.assertFalse(mps._retry_failed)
        self.assertFalse(mps._running)

    def test_multiple_features(self) -> None:
        """
        Test initialization with multiple features.

        Arrange: Create multiple features
        Act: Initialize MockSingleRecordingMps
        Assert: Features are stored correctly
        """
        # Arrange
        recording = Path("/data/recording.vrs")
        features = {MpsFeature.SLAM, MpsFeature.EYE_GAZE, MpsFeature.HAND_TRACKING}

        # Act
        mps = MockSingleRecordingMps(recording, features)

        # Assert
        self.assertEqual(len(mps._features), 3)


class TestGetStatus(unittest.TestCase):
    """Tests for get_status method."""

    def test_status_queued_when_waiting_for_semaphore(self) -> None:
        """
        Test QUEUED status when waiting for semaphore.

        Arrange: Create MPS and set waiting flag
        Act: Get status
        Assert: Status is QUEUED
        """
        # Arrange
        mps = MockSingleRecordingMps(Path("/data/rec.vrs"), {MpsFeature.SLAM})
        mps._waiting_for_semaphore = True

        # Act
        status = mps.get_status(MpsFeature.SLAM)

        # Assert
        self.assertEqual(status.status, DisplayStatus.QUEUED)

    def test_status_created_when_not_running(self) -> None:
        """
        Test CREATED status when not running.

        Arrange: Create MPS (not running by default)
        Act: Get status
        Assert: Status is CREATED
        """
        # Arrange
        mps = MockSingleRecordingMps(Path("/data/rec.vrs"), {MpsFeature.SLAM})

        # Act
        status = mps.get_status(MpsFeature.SLAM)

        # Assert
        self.assertEqual(status.status, DisplayStatus.CREATED)

    def test_status_from_finish_status(self) -> None:
        """
        Test status from finish_status map.

        Arrange: Set running and add to finish_status
        Act: Get status
        Assert: Status from finish_status is returned
        """
        # Arrange
        mps = MockSingleRecordingMps(Path("/data/rec.vrs"), {MpsFeature.SLAM})
        mps._running = True
        mps._finish_status[MpsFeature.SLAM] = ModelState(status=DisplayStatus.SUCCESS)

        # Act
        status = mps.get_status(MpsFeature.SLAM)

        # Assert
        self.assertEqual(status.status, DisplayStatus.SUCCESS)

    def test_status_checking_when_running_not_finished(self) -> None:
        """
        Test CHECKING status when running but not finished.

        Arrange: Set running, don't add to finish_status
        Act: Get status
        Assert: Status is CHECKING
        """
        # Arrange
        mps = MockSingleRecordingMps(Path("/data/rec.vrs"), {MpsFeature.SLAM})
        mps._running = True

        # Act
        status = mps.get_status(MpsFeature.SLAM)

        # Assert
        self.assertEqual(status.status, DisplayStatus.CHECKING)


class TestGetDeviceType(unittest.TestCase):
    """Tests for get_device_type method."""

    def test_returns_none_when_not_set(self) -> None:
        """
        Test that None is returned when device type not set.

        Arrange: Create MPS without device type
        Act: Get device type
        Assert: None is returned
        """
        # Arrange
        mps = MockSingleRecordingMps(Path("/data/rec.vrs"), {MpsFeature.SLAM})

        # Act
        device_type = mps.get_device_type()

        # Assert
        self.assertIsNone(device_type)

    def test_returns_gen1_when_set(self) -> None:
        """
        Test that Gen1 is returned when set.

        Arrange: Set device type to Gen1
        Act: Get device type
        Assert: Gen1 is returned
        """
        # Arrange
        mps = MockSingleRecordingMps(Path("/data/rec.vrs"), {MpsFeature.SLAM})
        mps._device_type = MpsAriaDevice.ARIA_GEN1

        # Act
        device_type = mps.get_device_type()

        # Assert
        self.assertEqual(device_type, MpsAriaDevice.ARIA_GEN1)

    def test_returns_gen2_when_set(self) -> None:
        """
        Test that Gen2 is returned when set.

        Arrange: Set device type to Gen2
        Act: Get device type
        Assert: Gen2 is returned
        """
        # Arrange
        mps = MockSingleRecordingMps(Path("/data/rec.vrs"), {MpsFeature.SLAM})
        mps._device_type = MpsAriaDevice.ARIA_GEN2

        # Act
        device_type = mps.get_device_type()

        # Assert
        self.assertEqual(device_type, MpsAriaDevice.ARIA_GEN2)


class TestRecordingProperty(unittest.TestCase):
    """Tests for recording property."""

    def test_recording_returns_path(self) -> None:
        """
        Test recording property returns Path.

        Arrange: Create MPS with specific path
        Act: Access recording property
        Assert: Correct path is returned
        """
        # Arrange
        expected_path = Path("/data/my_recording.vrs")
        mps = MockSingleRecordingMps(expected_path, {MpsFeature.SLAM})

        # Act
        result = mps.recording

        # Assert
        self.assertEqual(result, expected_path)

    def test_recording_is_path_type(self) -> None:
        """
        Test recording is a Path instance.

        Arrange: Create MPS
        Act: Access recording property
        Assert: Result is Path instance
        """
        # Arrange
        mps = MockSingleRecordingMps(Path("/data/rec.vrs"), {MpsFeature.SLAM})

        # Act
        result = mps.recording

        # Assert
        self.assertIsInstance(result, Path)


class TestModelStateUsage(unittest.TestCase):
    """Tests for ModelState usage in status retrieval."""

    def test_model_state_default_progress(self) -> None:
        """
        Test ModelState has default progress of 0.

        Arrange: Create ModelState
        Act: Check progress
        Assert: Progress is 0
        """
        # Arrange
        state = ModelState(status=DisplayStatus.CREATED)

        # Act
        result = state.progress

        # Assert
        self.assertEqual(result, 0)

    def test_model_state_with_error_code(self) -> None:
        """
        Test ModelState with error code.

        Arrange: Create ModelState with error
        Act: Check error_code
        Assert: Error code is set
        """
        # Arrange
        state = ModelState(status=DisplayStatus.ERROR, error_code="123")

        # Act
        result = state.error_code

        # Assert
        self.assertEqual(result, "123")


if __name__ == "__main__":
    unittest.main()
