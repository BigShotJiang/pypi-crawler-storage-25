# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import unittest
from pathlib import Path
from typing import Optional, Tuple
from unittest.mock import MagicMock


class UploadPending(Exception):
    """
    Raised when the upload is still pending.
    Copied from uploader.py to avoid Config initialization.
    """

    pass


class MockUploader:
    """
    Simplified Uploader class for testing.
    Avoids imports that trigger Config initialization.
    """

    semaphore_: asyncio.Semaphore = asyncio.Semaphore(3)

    def __init__(
        self,
        input_path: Path,
        input_hash: str,
        http_helper: MagicMock,
    ):
        self._input_path = input_path
        self._input_hash = input_hash
        self._http_helper = http_helper
        self._processed = 0
        self._total = 0

    @classmethod
    def get_key(cls, input_path: Path, input_hash: str, http_helper: MagicMock) -> str:
        """Get a unique key for this Runner instance."""
        return input_hash

    @classmethod
    def get_setting_keys(cls) -> Tuple[str, str]:
        """Return the config section and key for the uploader's semaphore setting."""
        return "UPLOAD", "CONCURRENT_UPLOADS"

    @property
    def progress(self) -> float:
        """Calculate upload progress percentage."""
        if self._total == 0:
            return 0
        return (self._processed / self._total) * 100


class TestUploaderKey(unittest.TestCase):
    """Tests for Uploader.get_key method."""

    def test_get_key_returns_hash(self) -> None:
        """
        Test that get_key returns the input hash.

        Arrange: Input path and hash.
        Act: Call get_key.
        Assert: Key equals the input hash.
        """
        input_path = Path("/tmp/test.vrs")
        input_hash = "abc123def456"

        key = MockUploader.get_key(input_path, input_hash, MagicMock())

        self.assertEqual(key, input_hash)

    def test_get_key_unique_for_different_hashes(self) -> None:
        """
        Test that different hashes produce different keys.

        Arrange: Same path but different hashes.
        Act: Generate keys.
        Assert: Keys are different.
        """
        input_path = Path("/tmp/test.vrs")
        hash1 = "abc123"
        hash2 = "def456"

        key1 = MockUploader.get_key(input_path, hash1, MagicMock())
        key2 = MockUploader.get_key(input_path, hash2, MagicMock())

        self.assertNotEqual(key1, key2)

    def test_get_key_same_for_same_hash_different_paths(self) -> None:
        """
        Test that same hash produces same key regardless of path.

        Arrange: Different paths but same hash.
        Act: Generate keys.
        Assert: Keys are equal.
        """
        path1 = Path("/tmp/test1.vrs")
        path2 = Path("/tmp/test2.vrs")
        same_hash = "abc123"

        key1 = MockUploader.get_key(path1, same_hash, MagicMock())
        key2 = MockUploader.get_key(path2, same_hash, MagicMock())

        self.assertEqual(key1, key2)


class TestUploaderInit(unittest.TestCase):
    """Tests for Uploader initialization."""

    def test_init_stores_parameters(self) -> None:
        """
        Test that initialization stores all parameters.

        Arrange: Create Uploader with parameters.
        Act: Access stored properties.
        Assert: All parameters are stored correctly.
        """
        input_path = Path("/tmp/test.vrs")
        input_hash = "abc123"
        http_helper = MagicMock()

        uploader = MockUploader(
            input_path=input_path,
            input_hash=input_hash,
            http_helper=http_helper,
        )

        self.assertEqual(uploader._input_path, input_path)
        self.assertEqual(uploader._input_hash, input_hash)

    def test_init_progress_starts_at_zero(self) -> None:
        """
        Test that progress starts at zero.

        Arrange: Create Uploader.
        Act: Check initial progress.
        Assert: Progress is 0.
        """
        uploader = MockUploader(
            input_path=Path("/tmp/test.vrs"),
            input_hash="abc123",
            http_helper=MagicMock(),
        )

        self.assertEqual(uploader._processed, 0)
        self.assertEqual(uploader._total, 0)


class TestUploaderProgress(unittest.TestCase):
    """Tests for Uploader progress calculation."""

    def test_progress_zero_when_total_zero(self) -> None:
        """
        Test that progress is 0 when total is 0.

        Arrange: Create Uploader with total=0.
        Act: Get progress.
        Assert: Progress is 0.
        """
        uploader = MockUploader(
            input_path=Path("/tmp/test.vrs"),
            input_hash="abc123",
            http_helper=MagicMock(),
        )
        uploader._total = 0
        uploader._processed = 0

        self.assertEqual(uploader.progress, 0)

    def test_progress_50_percent(self) -> None:
        """
        Test that progress is 50% when half uploaded.

        Arrange: Create Uploader with half processed.
        Act: Get progress.
        Assert: Progress is 50.
        """
        uploader = MockUploader(
            input_path=Path("/tmp/test.vrs"),
            input_hash="abc123",
            http_helper=MagicMock(),
        )
        uploader._total = 1000000
        uploader._processed = 500000

        self.assertEqual(uploader.progress, 50.0)

    def test_progress_100_when_complete(self) -> None:
        """
        Test that progress is 100 when fully uploaded.

        Arrange: Create Uploader with all bytes processed.
        Act: Get progress.
        Assert: Progress is 100.
        """
        uploader = MockUploader(
            input_path=Path("/tmp/test.vrs"),
            input_hash="abc123",
            http_helper=MagicMock(),
        )
        uploader._total = 1000000
        uploader._processed = 1000000

        self.assertEqual(uploader.progress, 100.0)


class TestUploadPending(unittest.TestCase):
    """Tests for UploadPending exception."""

    def test_is_exception(self) -> None:
        """
        Test that UploadPending is an Exception.

        Arrange: UploadPending class.
        Act: Check inheritance.
        Assert: It is a subclass of Exception.
        """
        self.assertTrue(issubclass(UploadPending, Exception))

    def test_can_be_raised_and_caught(self) -> None:
        """
        Test that UploadPending can be raised and caught.

        Arrange: UploadPending class.
        Act: Raise and catch the exception.
        Assert: Exception is caught with correct message.
        """
        with self.assertRaises(UploadPending) as context:
            raise UploadPending("Upload timed out")

        self.assertEqual(str(context.exception), "Upload timed out")


class TestCheckIfAlreadyUploaded(unittest.TestCase):
    """Tests for check_if_already_uploaded logic."""

    MIN_REMAINING_TTL_SECS = 0

    def _check_if_already_uploaded(
        self,
        recording_info: Optional[Tuple[int, int]],
    ) -> Optional[int]:
        """
        Check if a file has already been successfully uploaded.
        Simplified version for testing.
        """
        if (
            recording_info is not None
            and recording_info[1] > self.MIN_REMAINING_TTL_SECS
        ):
            return recording_info[0]
        return None

    def test_returns_fbid_when_uploaded_with_valid_ttl(self) -> None:
        """
        Test that returns fbid when file is uploaded with valid TTL.

        Arrange: Recording info with valid TTL.
        Act: Check if already uploaded.
        Assert: Returns the fbid.
        """
        recording_info = (12345, 3600)

        result = self._check_if_already_uploaded(recording_info)

        self.assertEqual(result, 12345)

    def test_returns_none_when_not_uploaded(self) -> None:
        """
        Test that returns None when file is not uploaded.

        Arrange: No recording info.
        Act: Check if already uploaded.
        Assert: Returns None.
        """
        recording_info = None

        result = self._check_if_already_uploaded(recording_info)

        self.assertIsNone(result)

    def test_returns_none_when_ttl_zero(self) -> None:
        """
        Test that returns None when TTL is zero.

        Arrange: Recording info with zero TTL.
        Act: Check if already uploaded.
        Assert: Returns None.
        """
        recording_info = (12345, 0)

        result = self._check_if_already_uploaded(recording_info)

        self.assertIsNone(result)


class TestUploaderSettingKeys(unittest.TestCase):
    """Tests for Uploader config setting keys."""

    def test_get_setting_keys_returns_tuple(self) -> None:
        """
        Test that get_setting_keys returns a tuple.

        Arrange: MockUploader class.
        Act: Call get_setting_keys.
        Assert: Returns tuple with section and key.
        """
        result = MockUploader.get_setting_keys()

        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 2)

    def test_get_setting_keys_values(self) -> None:
        """
        Test that get_setting_keys returns correct values.

        Arrange: MockUploader class.
        Act: Call get_setting_keys.
        Assert: Returns UPLOAD section and CONCURRENT_UPLOADS key.
        """
        section, key = MockUploader.get_setting_keys()

        self.assertEqual(section, "UPLOAD")
        self.assertEqual(key, "CONCURRENT_UPLOADS")


class TestUploadUrlFormat(unittest.TestCase):
    """Tests for upload URL formatting."""

    URL_UPLOAD = "https://rupload.facebook.com/mps_recording_upload"

    def test_upload_url_format(self) -> None:
        """
        Test that upload URL is formatted correctly.

        Arrange: Input hash and path hash.
        Act: Generate upload URL.
        Assert: URL follows expected format.
        """
        input_hash = "abc123"
        path_hash = "def456"

        upload_url = f"{self.URL_UPLOAD}/{input_hash}_{path_hash}"

        self.assertEqual(
            upload_url,
            "https://rupload.facebook.com/mps_recording_upload/abc123_def456",
        )


if __name__ == "__main__":
    unittest.main()
