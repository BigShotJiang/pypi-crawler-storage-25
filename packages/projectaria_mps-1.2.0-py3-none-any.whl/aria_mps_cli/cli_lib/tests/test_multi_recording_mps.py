# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unit tests for multi_recording_mps.py

Tests cover:
- MultiRecordingMps initialization
- Status retrieval for multiple recordings
- Device type retrieval and caching
- Recordings property
"""

import unittest
from enum import Enum
from pathlib import Path
from typing import Dict, Mapping, Optional, Set


class MpsFeature(Enum):
    """Local copy of MpsFeature to avoid Config initialization."""

    SLAM = "SLAM"
    EYE_GAZE = "EYE_GAZE"
    HAND_TRACKING = "HAND_TRACKING"
    MULTI_SLAM = "MULTI_SLAM"


class MpsAriaDevice(Enum):
    """Local copy of MpsAriaDevice."""

    ARIA_GEN1 = "ARIA_GEN1"
    ARIA_GEN2 = "ARIA_GEN2"
    UNKNOWN = "UNKNOWN"


class DisplayStatus(Enum):
    """Local copy of DisplayStatus."""

    CREATED = "CREATED"
    QUEUED = "QUEUED"
    HASHING = "HASHING"
    CHECKING = "CHECKING"
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"


class ModelState:
    """Local copy of ModelState."""

    __slots__ = ("status", "progress", "error_code")

    def __init__(
        self,
        status: DisplayStatus = DisplayStatus.CREATED,
        progress: float = 0,
        error_code: Optional[str] = None,
    ) -> None:
        self.status = status
        self.progress = progress
        self.error_code = error_code


class MockMultiRecordingMps:
    """Mock MultiRecordingMps for testing without Config."""

    def __init__(
        self,
        recordings: Set[Path],
        output_dir: Path,
        force: bool = False,
        retry_failed: bool = False,
        name: Optional[str] = None,
    ) -> None:
        self._recordings = recordings
        self._output_dir = output_dir
        self._force = force
        self._retry_failed = retry_failed
        self._name = name
        self._running = False
        self._finish_status: Mapping[Path, ModelState] = {}
        self._device_types_cache: Dict[Path, Optional[MpsAriaDevice]] = {}

    @property
    def recordings(self) -> Set[Path]:
        return self._recordings

    def get_status(self, recording: Path) -> ModelState:
        """Get the status of a recording."""
        if recording in self._finish_status:
            return self._finish_status[recording]

        if not self._running:
            return ModelState(status=DisplayStatus.CREATED)

        return ModelState(status=DisplayStatus.CHECKING)

    def get_device_type(self, recording_path: Path) -> Optional[MpsAriaDevice]:
        """Get device type for a recording."""
        return self._device_types_cache.get(recording_path)


class TestMultiRecordingMpsInit(unittest.TestCase):
    """Tests for MultiRecordingMps initialization."""

    def test_initialization_with_recordings(self) -> None:
        """
        Test that recordings are set correctly.

        Arrange: Create set of recordings
        Act: Initialize MockMultiRecordingMps
        Assert: Recordings property returns correct set
        """
        # Arrange
        recordings = {Path("/data/rec1.vrs"), Path("/data/rec2.vrs")}
        output_dir = Path("/output")

        # Act
        mps = MockMultiRecordingMps(recordings, output_dir)

        # Assert
        self.assertEqual(mps.recordings, recordings)

    def test_initialization_with_name(self) -> None:
        """
        Test initialization with name parameter.

        Arrange: Create MPS with name
        Act: Check name
        Assert: Name is stored
        """
        # Arrange
        recordings = {Path("/data/rec1.vrs")}
        output_dir = Path("/output")
        name = "test_request"

        # Act
        mps = MockMultiRecordingMps(recordings, output_dir, name=name)

        # Assert
        self.assertEqual(mps._name, name)

    def test_default_values(self) -> None:
        """
        Test default values are set correctly.

        Arrange: Create MPS with minimal args
        Act: Check defaults
        Assert: Defaults are correct
        """
        # Arrange
        recordings = {Path("/data/rec1.vrs")}
        output_dir = Path("/output")

        # Act
        mps = MockMultiRecordingMps(recordings, output_dir)

        # Assert
        self.assertFalse(mps._force)
        self.assertFalse(mps._retry_failed)
        self.assertFalse(mps._running)


class TestMultiGetStatus(unittest.TestCase):
    """Tests for get_status method."""

    def test_status_created_when_not_running(self) -> None:
        """
        Test CREATED status when not running.

        Arrange: Create MPS (not running by default)
        Act: Get status for a recording
        Assert: Status is CREATED
        """
        # Arrange
        rec = Path("/data/rec1.vrs")
        mps = MockMultiRecordingMps({rec}, Path("/output"))

        # Act
        status = mps.get_status(rec)

        # Assert
        self.assertEqual(status.status, DisplayStatus.CREATED)

    def test_status_from_finish_status(self) -> None:
        """
        Test status from finish_status map.

        Arrange: Add to finish_status
        Act: Get status
        Assert: Status from finish_status is returned
        """
        # Arrange
        rec = Path("/data/rec1.vrs")
        mps = MockMultiRecordingMps({rec}, Path("/output"))
        mps._finish_status = {rec: ModelState(status=DisplayStatus.SUCCESS)}

        # Act
        status = mps.get_status(rec)

        # Assert
        self.assertEqual(status.status, DisplayStatus.SUCCESS)

    def test_status_checking_when_running(self) -> None:
        """
        Test CHECKING status when running.

        Arrange: Set running flag
        Act: Get status
        Assert: Status is CHECKING
        """
        # Arrange
        rec = Path("/data/rec1.vrs")
        mps = MockMultiRecordingMps({rec}, Path("/output"))
        mps._running = True

        # Act
        status = mps.get_status(rec)

        # Assert
        self.assertEqual(status.status, DisplayStatus.CHECKING)


class TestMultiGetDeviceType(unittest.TestCase):
    """Tests for get_device_type method."""

    def test_returns_none_when_not_cached(self) -> None:
        """
        Test None returned when device type not cached.

        Arrange: Create MPS without cached device types
        Act: Get device type
        Assert: None is returned
        """
        # Arrange
        rec = Path("/data/rec1.vrs")
        mps = MockMultiRecordingMps({rec}, Path("/output"))

        # Act
        device_type = mps.get_device_type(rec)

        # Assert
        self.assertIsNone(device_type)

    def test_returns_cached_device_type(self) -> None:
        """
        Test cached device type is returned.

        Arrange: Cache device type
        Act: Get device type
        Assert: Cached value is returned
        """
        # Arrange
        rec = Path("/data/rec1.vrs")
        mps = MockMultiRecordingMps({rec}, Path("/output"))
        mps._device_types_cache[rec] = MpsAriaDevice.ARIA_GEN1

        # Act
        device_type = mps.get_device_type(rec)

        # Assert
        self.assertEqual(device_type, MpsAriaDevice.ARIA_GEN1)

    def test_different_recordings_different_types(self) -> None:
        """
        Test different recordings can have different device types.

        Arrange: Cache different device types for different recordings
        Act: Get device types
        Assert: Correct types are returned for each
        """
        # Arrange
        rec1 = Path("/data/rec1.vrs")
        rec2 = Path("/data/rec2.vrs")
        mps = MockMultiRecordingMps({rec1, rec2}, Path("/output"))
        mps._device_types_cache[rec1] = MpsAriaDevice.ARIA_GEN1
        mps._device_types_cache[rec2] = MpsAriaDevice.ARIA_GEN2

        # Act
        type1 = mps.get_device_type(rec1)
        type2 = mps.get_device_type(rec2)

        # Assert
        self.assertEqual(type1, MpsAriaDevice.ARIA_GEN1)
        self.assertEqual(type2, MpsAriaDevice.ARIA_GEN2)


class TestRecordingsProperty(unittest.TestCase):
    """Tests for recordings property."""

    def test_recordings_returns_set(self) -> None:
        """
        Test recordings property returns a Set.

        Arrange: Create MPS with recordings
        Act: Access recordings property
        Assert: Result is a set
        """
        # Arrange
        recordings = {Path("/data/rec1.vrs"), Path("/data/rec2.vrs")}
        mps = MockMultiRecordingMps(recordings, Path("/output"))

        # Act
        result = mps.recordings

        # Assert
        self.assertIsInstance(result, set)

    def test_recordings_count(self) -> None:
        """
        Test recordings count is correct.

        Arrange: Create MPS with multiple recordings
        Act: Count recordings
        Assert: Count is correct
        """
        # Arrange
        recordings = {
            Path("/data/rec1.vrs"),
            Path("/data/rec2.vrs"),
            Path("/data/rec3.vrs"),
        }
        mps = MockMultiRecordingMps(recordings, Path("/output"))

        # Act
        count = len(mps.recordings)

        # Assert
        self.assertEqual(count, 3)


class TestFlags(unittest.TestCase):
    """Tests for force and retry_failed flags."""

    def test_force_flag_true(self) -> None:
        """
        Test force flag when set to True.

        Arrange: Create MPS with force=True
        Act: Check force flag
        Assert: Flag is True
        """
        # Arrange
        mps = MockMultiRecordingMps(
            {Path("/data/rec1.vrs")}, Path("/output"), force=True
        )

        # Act
        result = mps._force

        # Assert
        self.assertTrue(result)

    def test_retry_failed_flag_true(self) -> None:
        """
        Test retry_failed flag when set to True.

        Arrange: Create MPS with retry_failed=True
        Act: Check retry_failed flag
        Assert: Flag is True
        """
        # Arrange
        mps = MockMultiRecordingMps(
            {Path("/data/rec1.vrs")}, Path("/output"), retry_failed=True
        )

        # Act
        result = mps._retry_failed

        # Assert
        self.assertTrue(result)


if __name__ == "__main__":
    unittest.main()
