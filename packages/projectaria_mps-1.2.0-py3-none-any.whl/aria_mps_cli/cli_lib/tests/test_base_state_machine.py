# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import unittest
from pathlib import Path
from typing import List, Mapping
from unittest.mock import MagicMock


class MockModelState:
    """Mock ModelState for testing."""

    __slots__ = ("status",)

    def __init__(self, status: str):
        self.status = status


class MockMpsFeature:
    """Mock MpsFeature for testing."""

    SLAM = "SLAM"
    EYE_GAZE = "EYE_GAZE"


class BaseStateMachine:
    """
    Simplified base state machine for testing.
    Copied from base_state_machine.py to avoid heavy imports.
    """

    def __init__(self, *args, **kwargs):
        self._tasks: List[asyncio.Task] = []
        self._models: List = []

    @property
    def tasks(self):
        """Return list of tasks (usually one per model)."""
        return self._tasks

    @property
    def models(self):
        """Return list of models."""
        return self._models

    def add_model(self, model) -> None:
        """Add a model to the state machine."""
        self._models.append(model)

    def fetch_current_model_states(
        self,
    ) -> Mapping[Path, Mapping[str, MockModelState]]:
        """Get the current state of each model."""
        raise NotImplementedError()


class TestBaseStateMachine(unittest.TestCase):
    """Tests for the BaseStateMachine class."""

    def test_initial_tasks_empty(self) -> None:
        """
        Test that tasks list is empty on initialization.

        Arrange: Create BaseStateMachine instance.
        Act: Access tasks property.
        Assert: Tasks list is empty.
        """
        machine = BaseStateMachine()

        self.assertEqual(machine.tasks, [])

    def test_initial_models_empty(self) -> None:
        """
        Test that models list is empty on initialization.

        Arrange: Create BaseStateMachine instance.
        Act: Access models property.
        Assert: Models list is empty.
        """
        machine = BaseStateMachine()

        self.assertEqual(machine.models, [])

    def test_add_model(self) -> None:
        """
        Test that add_model adds model to list.

        Arrange: Create BaseStateMachine and mock model.
        Act: Add model to state machine.
        Assert: Model is in models list.
        """
        machine = BaseStateMachine()
        mock_model = MagicMock()

        machine.add_model(mock_model)

        self.assertEqual(len(machine.models), 1)
        self.assertEqual(machine.models[0], mock_model)

    def test_add_multiple_models(self) -> None:
        """
        Test that multiple models can be added.

        Arrange: Create BaseStateMachine and multiple mock models.
        Act: Add multiple models to state machine.
        Assert: All models are in models list.
        """
        machine = BaseStateMachine()
        model1 = MagicMock()
        model2 = MagicMock()
        model3 = MagicMock()

        machine.add_model(model1)
        machine.add_model(model2)
        machine.add_model(model3)

        self.assertEqual(len(machine.models), 3)

    def test_tasks_property_returns_list(self) -> None:
        """
        Test that tasks property returns a list.

        Arrange: Create BaseStateMachine.
        Act: Access tasks property.
        Assert: Returns a list type.
        """
        machine = BaseStateMachine()

        self.assertIsInstance(machine.tasks, list)

    def test_fetch_current_model_states_not_implemented(self) -> None:
        """
        Test that fetch_current_model_states raises NotImplementedError.

        Arrange: Create BaseStateMachine instance.
        Act: Call fetch_current_model_states.
        Assert: NotImplementedError is raised.
        """
        machine = BaseStateMachine()

        with self.assertRaises(NotImplementedError):
            machine.fetch_current_model_states()


class TestBaseStateMachineWithTasks(unittest.TestCase):
    """Tests for BaseStateMachine task management."""

    def test_tasks_can_be_appended(self) -> None:
        """
        Test that tasks can be appended to tasks list.

        Arrange: Create BaseStateMachine and mock task.
        Act: Append task to tasks list.
        Assert: Task is in tasks list.
        """
        machine = BaseStateMachine()
        mock_task = MagicMock(spec=asyncio.Task)

        machine._tasks.append(mock_task)

        self.assertEqual(len(machine.tasks), 1)

    def test_tasks_list_is_mutable(self) -> None:
        """
        Test that tasks list can be modified externally.

        Arrange: Create BaseStateMachine with tasks.
        Act: Clear tasks list.
        Assert: Tasks list is empty.
        """
        machine = BaseStateMachine()
        machine._tasks.append(MagicMock())
        machine._tasks.append(MagicMock())

        machine._tasks.clear()

        self.assertEqual(len(machine.tasks), 0)


if __name__ == "__main__":
    unittest.main()
