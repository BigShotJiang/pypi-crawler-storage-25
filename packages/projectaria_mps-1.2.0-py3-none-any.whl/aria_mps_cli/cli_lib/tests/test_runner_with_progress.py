# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import unittest
from abc import ABC, abstractmethod
from typing import Any, Final, final
from weakref import WeakValueDictionary


class RunnerWithProgress(ABC):
    """Test copy of RunnerWithProgress to avoid module import side effects."""

    weak_instances_: WeakValueDictionary[str, Any] = WeakValueDictionary()
    mutex_: Final[asyncio.Lock] = asyncio.Lock()

    def __init__(self):
        self._processed: int = 0
        self._total: int = 0
        self._task = None

    @classmethod
    async def get(cls, *args, **kwargs) -> Any:
        key: str = f"{cls.__name__}:{cls.get_key(*args, **kwargs)}"
        async with cls.mutex_:
            if key not in cls.weak_instances_:
                instance = cls(*args, **kwargs)
                cls.weak_instances_[key] = instance
            return cls.weak_instances_[key]

    @classmethod
    @abstractmethod
    def get_key(cls, *args, **kwargs) -> str:
        raise NotImplementedError()

    @final
    async def run(self) -> Any:
        if not self._task or self._task.done() and not self._task.cancelled():
            self._task = asyncio.create_task(self._run())
        return await self._task

    @abstractmethod
    async def _run(self) -> Any:
        raise NotImplementedError()

    @property
    def progress(self):
        return self._processed * 100 / self._total if self._total else 0


class ConcreteRunner(RunnerWithProgress):
    """Concrete implementation of RunnerWithProgress for testing."""

    def __init__(self, result_value: str = "result") -> None:
        """
        Initialize test runner.

        Args:
            result_value: The value to return from _run.
        """
        super().__init__()
        self._result_value = result_value

    @classmethod
    def get_key(cls, result_value: str = "result") -> str:
        """
        Get unique key for this runner instance.

        Args:
            result_value: The result value used to generate key.

        Returns:
            Unique key string.
        """
        return f"concrete_{result_value}"

    async def _run(self) -> str:
        """
        Execute the runner logic.

        Returns:
            The configured result value.
        """
        self._total = 100
        self._processed = 100
        return self._result_value


class TestRunnerWithProgress(unittest.TestCase):
    """Tests for the RunnerWithProgress abstract base class."""

    def setUp(self) -> None:
        """
        Set up test fixtures.

        Arrange: Clear weak instances cache before each test.
        """
        RunnerWithProgress.weak_instances_.clear()

    def test_progress_returns_zero_when_total_is_zero(self) -> None:
        """
        Test that progress returns 0 when total is 0.

        Arrange: Create runner with default total of 0.
        Act: Access progress property.
        Assert: Returns 0.
        """
        runner = ConcreteRunner()

        result = runner.progress

        self.assertEqual(result, 0)

    def test_progress_calculates_percentage(self) -> None:
        """
        Test that progress calculates correct percentage.

        Arrange: Create runner and set processed/total values.
        Act: Access progress property.
        Assert: Returns correct percentage.
        """
        runner = ConcreteRunner()
        runner._total = 200
        runner._processed = 100

        result = runner.progress

        self.assertEqual(result, 50.0)

    def test_progress_returns_100_when_complete(self) -> None:
        """
        Test that progress returns 100 when fully processed.

        Arrange: Create runner with processed equal to total.
        Act: Access progress property.
        Assert: Returns 100.
        """
        runner = ConcreteRunner()
        runner._total = 100
        runner._processed = 100

        result = runner.progress

        self.assertEqual(result, 100.0)

    def test_run_executes_run_method(self) -> None:
        """
        Test that run() executes _run() and returns result.

        Arrange: Create concrete runner.
        Act: Call run() asynchronously.
        Assert: Returns expected result value.
        """
        runner = ConcreteRunner("test_result")

        result = asyncio.run(runner.run())

        self.assertEqual(result, "test_result")

    def test_run_reuses_existing_task(self) -> None:
        """
        Test that multiple run() calls reuse the same task.

        Arrange: Create runner and start first run.
        Act: Call run() multiple times concurrently.
        Assert: All calls return the same result.
        """
        runner = ConcreteRunner("shared_result")

        async def run_multiple() -> list:
            """Run multiple concurrent calls."""
            return await asyncio.gather(runner.run(), runner.run(), runner.run())

        results = asyncio.run(run_multiple())

        self.assertEqual(results, ["shared_result", "shared_result", "shared_result"])

    def test_get_caches_instances(self) -> None:
        """
        Test that get() caches and returns same instance for same args.

        Arrange: Empty cache.
        Act: Call get() twice with same arguments.
        Assert: Returns same instance both times.
        """

        async def test_caching() -> tuple:
            """Test instance caching."""
            instance1 = await ConcreteRunner.get("value1")
            instance2 = await ConcreteRunner.get("value1")
            return instance1, instance2

        instance1, instance2 = asyncio.run(test_caching())

        self.assertIs(instance1, instance2)

    def test_get_returns_different_instances_for_different_args(self) -> None:
        """
        Test that get() returns different instances for different args.

        Arrange: Empty cache.
        Act: Call get() with different arguments.
        Assert: Returns different instances.
        """

        async def test_different_args() -> tuple:
            """Test different args create different instances."""
            instance1 = await ConcreteRunner.get("value1")
            instance2 = await ConcreteRunner.get("value2")
            return instance1, instance2

        instance1, instance2 = asyncio.run(test_different_args())

        self.assertIsNot(instance1, instance2)


if __name__ == "__main__":
    unittest.main()
