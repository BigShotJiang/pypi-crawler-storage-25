# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import tempfile
import unittest
from enum import Enum
from pathlib import Path
from typing import Optional


class MpsAriaDevice(Enum):
    """Mock MpsAriaDevice enum for testing."""

    ARIA_GEN1 = "ARIA_GEN1"
    ARIA_GEN2 = "ARIA_GEN2"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_device_type(cls, device_type: Optional[str]) -> "MpsAriaDevice":
        """Convert device type string to enum."""
        if device_type in ["Ariane", "Aria"]:
            return cls.ARIA_GEN1
        elif device_type == "Oatmeal":
            return cls.ARIA_GEN2
        return cls.UNKNOWN


class MockAriaRecording:
    """Mock AriaRecording for testing."""

    __slots__ = ("path",)

    def __init__(self, path: Path):
        self.path = path


class TestMpsAriaDeviceFromDeviceType(unittest.TestCase):
    """Tests for MpsAriaDevice.from_device_type method."""

    def test_ariane_maps_to_gen1(self) -> None:
        """
        Test that 'Ariane' device type maps to ARIA_GEN1.

        Arrange: Device type string 'Ariane'.
        Act: Call from_device_type.
        Assert: Returns ARIA_GEN1.
        """
        result = MpsAriaDevice.from_device_type("Ariane")

        self.assertEqual(result, MpsAriaDevice.ARIA_GEN1)

    def test_aria_maps_to_gen1(self) -> None:
        """
        Test that 'Aria' device type maps to ARIA_GEN1.

        Arrange: Device type string 'Aria'.
        Act: Call from_device_type.
        Assert: Returns ARIA_GEN1.
        """
        result = MpsAriaDevice.from_device_type("Aria")

        self.assertEqual(result, MpsAriaDevice.ARIA_GEN1)

    def test_oatmeal_maps_to_gen2(self) -> None:
        """
        Test that 'Oatmeal' device type maps to ARIA_GEN2.

        Arrange: Device type string 'Oatmeal'.
        Act: Call from_device_type.
        Assert: Returns ARIA_GEN2.
        """
        result = MpsAriaDevice.from_device_type("Oatmeal")

        self.assertEqual(result, MpsAriaDevice.ARIA_GEN2)

    def test_unknown_string_maps_to_unknown(self) -> None:
        """
        Test that unknown device type string maps to UNKNOWN.

        Arrange: Unknown device type string.
        Act: Call from_device_type.
        Assert: Returns UNKNOWN.
        """
        result = MpsAriaDevice.from_device_type("SomeOtherDevice")

        self.assertEqual(result, MpsAriaDevice.UNKNOWN)

    def test_none_maps_to_unknown(self) -> None:
        """
        Test that None device type maps to UNKNOWN.

        Arrange: None device type.
        Act: Call from_device_type.
        Assert: Returns UNKNOWN.
        """
        result = MpsAriaDevice.from_device_type(None)

        self.assertEqual(result, MpsAriaDevice.UNKNOWN)

    def test_empty_string_maps_to_unknown(self) -> None:
        """
        Test that empty string maps to UNKNOWN.

        Arrange: Empty string device type.
        Act: Call from_device_type.
        Assert: Returns UNKNOWN.
        """
        result = MpsAriaDevice.from_device_type("")

        self.assertEqual(result, MpsAriaDevice.UNKNOWN)


class TestDeviceVersionCheckRunnerKey(unittest.TestCase):
    """Tests for DeviceVersionCheckRunner.get_key method."""

    def test_get_key_returns_path_string(self) -> None:
        """
        Test that get_key returns the recording path as string.

        Arrange: Create recording with specific path.
        Act: Generate key from recording.
        Assert: Key matches path string.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "test.vrs"
            recording = MockAriaRecording(path=path)

            key = f"{recording.path}"

            self.assertEqual(key, str(path))

    def test_get_key_unique_for_different_paths(self) -> None:
        """
        Test that different paths produce different keys.

        Arrange: Create recordings with different paths.
        Act: Generate keys for both.
        Assert: Keys are different.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            path1 = Path(tmpdir) / "test1.vrs"
            path2 = Path(tmpdir) / "test2.vrs"
            recording1 = MockAriaRecording(path=path1)
            recording2 = MockAriaRecording(path=path2)

            key1 = f"{recording1.path}"
            key2 = f"{recording2.path}"

            self.assertNotEqual(key1, key2)


class TestDeviceVersionCheckSemaphore(unittest.TestCase):
    """Tests for DeviceVersionCheckRunner semaphore behavior."""

    def test_semaphore_limits_concurrency(self) -> None:
        """
        Test that semaphore can limit concurrent operations.

        Arrange: Create semaphore with limit of 4.
        Act: Check semaphore value.
        Assert: Initial value is 4.
        """
        semaphore = asyncio.Semaphore(4)

        self.assertEqual(semaphore._value, 4)

    def test_semaphore_acquire_decrements_value(self) -> None:
        """
        Test that acquiring semaphore decrements its value.

        Arrange: Create semaphore.
        Act: Acquire semaphore.
        Assert: Value is decremented.
        """

        async def test_acquire():
            semaphore = asyncio.Semaphore(4)
            async with semaphore:
                # Inside context, value should be 3
                return semaphore._value

        result = asyncio.run(test_acquire())
        self.assertEqual(result, 3)


if __name__ == "__main__":
    unittest.main()
