# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import unittest
from enum import auto, Enum
from typing import Dict, List, Mapping, Optional


class MpsFeature(Enum):
    """Mock MpsFeature enum for testing."""

    SLAM = "SLAM"
    EYE_GAZE = "EYE_GAZE"
    MULTI_SLAM = "MULTI_SLAM"
    HAND_TRACKING = "HAND_TRACKING"


class MpsResultType(Enum):
    """Mock MpsResultType enum for testing."""

    SUMMARY = "SUMMARY"
    SLAM_ZIP = "SLAM_ZIP"
    EYE_GAZE_ZIP = "EYE_GAZE_ZIP"
    HAND_TRACKING_ZIP = "HAND_TRACKING_ZIP"


class Status(Enum):
    """Mock Status enum for testing."""

    SCHEDULED = "SCHEDULED"
    PROCESSING = "PROCESSING"
    SUCCEEDED = "SUCCEEDED"
    FAILED = "FAILED"


class DisplayStatus:
    """Mock DisplayStatus constants for testing."""

    DOWNLOADING = "Downloading"
    SUCCESS = "Success"
    ERROR = "Error"


class ErrorCode:
    """Mock ErrorCode constants for testing."""

    GRAPHQL_FAILURE = 2001
    PROCESSING_FAILURE = 2002
    DOWNLOAD_FAILURE = 2003
    STATE_MACHINE_FAILURE = 2004


RESULT_TYPES_BY_FEATURE: Mapping[MpsFeature, List[MpsResultType]] = {
    MpsFeature.MULTI_SLAM: [MpsResultType.SLAM_ZIP],
    MpsFeature.SLAM: [MpsResultType.SLAM_ZIP],
    MpsFeature.EYE_GAZE: [MpsResultType.EYE_GAZE_ZIP],
    MpsFeature.HAND_TRACKING: [MpsResultType.HAND_TRACKING_ZIP],
}


class MockModelState:
    """Mock ModelState for testing."""

    __slots__ = ("status", "progress", "error_code")

    def __init__(
        self, status: str, progress: float = 0, error_code: Optional[str] = None
    ):
        self.status = status
        self.progress = progress
        self.error_code = error_code


class MockMpsFeatureRequest:
    """Mock MpsFeatureRequest for testing."""

    def __init__(
        self,
        fbid: int,
        feature: MpsFeature,
        status: Status,
        results: List = None,
        error_code: Optional[int] = None,
    ):
        self.fbid = fbid
        self.feature = feature
        self.status = status
        self.results = results or []
        self.error_code = error_code

    def is_pending(self) -> bool:
        """Check if request is pending."""
        return self.status in [Status.SCHEDULED, Status.PROCESSING]


class TestResultTypesByFeature(unittest.TestCase):
    """Tests for RESULT_TYPES_BY_FEATURE mapping."""

    def test_slam_maps_to_slam_zip(self) -> None:
        """
        Test that SLAM feature maps to SLAM_ZIP result type.

        Arrange: RESULT_TYPES_BY_FEATURE mapping.
        Act: Get result types for SLAM.
        Assert: Contains SLAM_ZIP.
        """
        result_types = RESULT_TYPES_BY_FEATURE[MpsFeature.SLAM]

        self.assertIn(MpsResultType.SLAM_ZIP, result_types)

    def test_multi_slam_maps_to_slam_zip(self) -> None:
        """
        Test that MULTI_SLAM feature maps to SLAM_ZIP result type.

        Arrange: RESULT_TYPES_BY_FEATURE mapping.
        Act: Get result types for MULTI_SLAM.
        Assert: Contains SLAM_ZIP.
        """
        result_types = RESULT_TYPES_BY_FEATURE[MpsFeature.MULTI_SLAM]

        self.assertIn(MpsResultType.SLAM_ZIP, result_types)

    def test_eye_gaze_maps_to_eye_gaze_zip(self) -> None:
        """
        Test that EYE_GAZE feature maps to EYE_GAZE_ZIP result type.

        Arrange: RESULT_TYPES_BY_FEATURE mapping.
        Act: Get result types for EYE_GAZE.
        Assert: Contains EYE_GAZE_ZIP.
        """
        result_types = RESULT_TYPES_BY_FEATURE[MpsFeature.EYE_GAZE]

        self.assertIn(MpsResultType.EYE_GAZE_ZIP, result_types)

    def test_hand_tracking_maps_to_hand_tracking_zip(self) -> None:
        """
        Test that HAND_TRACKING feature maps to HAND_TRACKING_ZIP result type.

        Arrange: RESULT_TYPES_BY_FEATURE mapping.
        Act: Get result types for HAND_TRACKING.
        Assert: Contains HAND_TRACKING_ZIP.
        """
        result_types = RESULT_TYPES_BY_FEATURE[MpsFeature.HAND_TRACKING]

        self.assertIn(MpsResultType.HAND_TRACKING_ZIP, result_types)


class TestMockMpsFeatureRequest(unittest.TestCase):
    """Tests for MpsFeatureRequest behavior."""

    def test_is_pending_when_scheduled(self) -> None:
        """
        Test that is_pending returns True when scheduled.

        Arrange: Feature request with SCHEDULED status.
        Act: Call is_pending.
        Assert: Returns True.
        """
        request = MockMpsFeatureRequest(
            fbid=123,
            feature=MpsFeature.SLAM,
            status=Status.SCHEDULED,
        )

        self.assertTrue(request.is_pending())

    def test_is_pending_when_processing(self) -> None:
        """
        Test that is_pending returns True when processing.

        Arrange: Feature request with PROCESSING status.
        Act: Call is_pending.
        Assert: Returns True.
        """
        request = MockMpsFeatureRequest(
            fbid=123,
            feature=MpsFeature.SLAM,
            status=Status.PROCESSING,
        )

        self.assertTrue(request.is_pending())

    def test_not_pending_when_succeeded(self) -> None:
        """
        Test that is_pending returns False when succeeded.

        Arrange: Feature request with SUCCEEDED status.
        Act: Call is_pending.
        Assert: Returns False.
        """
        request = MockMpsFeatureRequest(
            fbid=123,
            feature=MpsFeature.SLAM,
            status=Status.SUCCEEDED,
        )

        self.assertFalse(request.is_pending())

    def test_not_pending_when_failed(self) -> None:
        """
        Test that is_pending returns False when failed.

        Arrange: Feature request with FAILED status.
        Act: Call is_pending.
        Assert: Returns False.
        """
        request = MockMpsFeatureRequest(
            fbid=123,
            feature=MpsFeature.SLAM,
            status=Status.FAILED,
        )

        self.assertFalse(request.is_pending())


class TestRequestMonitorStates(unittest.TestCase):
    """Tests for RequestMonitor state definitions."""

    class States(Enum):
        """Mock States enum for testing."""

        CREATE = auto()
        WAIT = auto()
        DOWNLOAD = auto()
        SUCCESS = auto()
        FAILURE = auto()

    def test_all_states_defined(self) -> None:
        """
        Test that all expected states are defined.

        Arrange: States enum.
        Act: Get all state names.
        Assert: Contains expected states.
        """
        expected_states = {"CREATE", "WAIT", "DOWNLOAD", "SUCCESS", "FAILURE"}
        actual_states = {state.name for state in self.States}

        self.assertEqual(actual_states, expected_states)

    def test_states_are_unique(self) -> None:
        """
        Test that all states have unique values.

        Arrange: States enum.
        Act: Get all state values.
        Assert: All values are unique.
        """
        values = [state.value for state in self.States]

        self.assertEqual(len(values), len(set(values)))


class TestRequestMonitorTransitions(unittest.TestCase):
    """Tests for RequestMonitor state transitions."""

    TRANSITIONS = [
        ["next", "*", "FAILURE", "has_error"],
        ["start", "CREATE", "WAIT"],
        ["next", "WAIT", "DOWNLOAD"],
        ["next", "DOWNLOAD", "SUCCESS"],
    ]

    def test_transitions_defined(self) -> None:
        """
        Test that transitions are properly defined.

        Arrange: TRANSITIONS list.
        Act: Check structure.
        Assert: Contains expected number of transitions.
        """
        self.assertEqual(len(self.TRANSITIONS), 4)

    def test_failure_transition_from_any_state(self) -> None:
        """
        Test that failure transition can come from any state.

        Arrange: TRANSITIONS list.
        Act: Find failure transition.
        Assert: Source is '*' (any state).
        """
        failure_transition = next(t for t in self.TRANSITIONS if t[2] == "FAILURE")

        self.assertEqual(failure_transition[1], "*")

    def test_success_only_from_download(self) -> None:
        """
        Test that success can only come from download state.

        Arrange: TRANSITIONS list.
        Act: Find success transition.
        Assert: Source is DOWNLOAD.
        """
        success_transition = next(t for t in self.TRANSITIONS if t[2] == "SUCCESS")

        self.assertEqual(success_transition[1], "DOWNLOAD")


class TestModelStateStatus(unittest.TestCase):
    """Tests for ModelState status generation."""

    def test_create_state_returns_submitted(self) -> None:
        """
        Test that CREATE state returns 'Submitted' status.

        Arrange: Model in CREATE state.
        Act: Generate status.
        Assert: Status is 'Submitted'.
        """
        state = MockModelState(status="Submitted")

        self.assertEqual(state.status, "Submitted")

    def test_download_state_includes_progress(self) -> None:
        """
        Test that DOWNLOAD state includes progress.

        Arrange: Model in DOWNLOAD state with progress.
        Act: Generate status.
        Assert: Status includes progress.
        """
        state = MockModelState(status=DisplayStatus.DOWNLOADING, progress=75.0)

        self.assertEqual(state.status, "Downloading")
        self.assertEqual(state.progress, 75.0)

    def test_success_state_returns_success(self) -> None:
        """
        Test that SUCCESS state returns success status.

        Arrange: Model in SUCCESS state.
        Act: Generate status.
        Assert: Status is DisplayStatus.SUCCESS.
        """
        state = MockModelState(status=DisplayStatus.SUCCESS)

        self.assertEqual(state.status, "Success")

    def test_failure_state_includes_error_code(self) -> None:
        """
        Test that FAILURE state includes error code.

        Arrange: Model in FAILURE state with error code.
        Act: Generate status.
        Assert: Status is ERROR and includes error code.
        """
        state = MockModelState(status=DisplayStatus.ERROR, error_code="2001")

        self.assertEqual(state.status, "Error")
        self.assertEqual(state.error_code, "2001")


class TestStateToErrorCodeMapping(unittest.TestCase):
    """Tests for state to error code mapping."""

    state_to_error_code: Dict[str, int] = {
        "WAIT": ErrorCode.PROCESSING_FAILURE,
        "DOWNLOAD": ErrorCode.DOWNLOAD_FAILURE,
    }

    def test_wait_state_maps_to_processing_failure(self) -> None:
        """
        Test that WAIT state maps to PROCESSING_FAILURE.

        Arrange: State to error code mapping.
        Act: Get error for WAIT.
        Assert: Returns PROCESSING_FAILURE.
        """
        error = self.state_to_error_code.get("WAIT")

        self.assertEqual(error, ErrorCode.PROCESSING_FAILURE)

    def test_download_state_maps_to_download_failure(self) -> None:
        """
        Test that DOWNLOAD state maps to DOWNLOAD_FAILURE.

        Arrange: State to error code mapping.
        Act: Get error for DOWNLOAD.
        Assert: Returns DOWNLOAD_FAILURE.
        """
        error = self.state_to_error_code.get("DOWNLOAD")

        self.assertEqual(error, ErrorCode.DOWNLOAD_FAILURE)

    def test_unknown_state_returns_none(self) -> None:
        """
        Test that unknown state returns None.

        Arrange: State to error code mapping.
        Act: Get error for unknown state.
        Assert: Returns None.
        """
        error = self.state_to_error_code.get("UNKNOWN")

        self.assertIsNone(error)


if __name__ == "__main__":
    unittest.main()
