# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import tempfile
import unittest
from pathlib import Path

from aria_mps_cli.cli_lib.types import (
    AriaRecording,
    MpsAriaDevice,
    MpsFeature,
    MpsFeatureRequest,
    Status,
)


class TestMpsAriaDevice(unittest.TestCase):
    """Tests for the MpsAriaDevice.from_device_type class method."""

    def test_from_device_type_mappings(self) -> None:
        """
        Test device type string to MpsAriaDevice enum mapping.

        Arrange: Define test cases mapping device type strings to expected enum values.
        Act: Call from_device_type for each device type string.
        Assert: Each device type maps to the correct MpsAriaDevice enum value.
        """
        test_cases = [
            ("Ariane", MpsAriaDevice.ARIA_GEN1),
            ("Aria", MpsAriaDevice.ARIA_GEN1),
            ("Oatmeal", MpsAriaDevice.ARIA_GEN2),
            ("SomeOtherDevice", MpsAriaDevice.UNKNOWN),
            (None, MpsAriaDevice.UNKNOWN),
        ]

        for device_type, expected in test_cases:
            with self.subTest(device_type=device_type):
                result = MpsAriaDevice.from_device_type(device_type)
                self.assertEqual(result, expected)


class TestAriaRecording(unittest.TestCase):
    """Tests for the AriaRecording dataclass."""

    def test_create_with_default_output_path(self) -> None:
        """
        Test creating AriaRecording with default output path.

        Arrange: Create a temporary VRS file.
        Act: Call AriaRecording.create with only the vrs_path.
        Assert: Output paths are correctly derived from the input path.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            vrs_path = Path(tmpdir) / "test.vrs"
            vrs_path.touch()

            recording = AriaRecording.create(vrs_path)

            expected_output = Path(tmpdir) / "mps_test_vrs"
            self.assertEqual(recording.path, vrs_path)
            self.assertEqual(recording.output_path, expected_output)
            self.assertEqual(recording.encrypted_path, expected_output / "test.vrs.enc")
            self.assertEqual(
                recording.health_check_path, expected_output / "vrs_health_check.json"
            )

    def test_create_with_custom_output_path(self) -> None:
        """
        Test creating AriaRecording with custom output path.

        Arrange: Create temporary directories for input and output.
        Act: Call AriaRecording.create with both vrs_path and output_path.
        Assert: Output path uses the provided custom path.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            vrs_path = Path(tmpdir) / "input" / "test.vrs"
            vrs_path.parent.mkdir(parents=True)
            vrs_path.touch()
            output_path = Path(tmpdir) / "custom_output"

            recording = AriaRecording.create(vrs_path, output_path)

            self.assertEqual(recording.path, vrs_path)
            self.assertEqual(recording.output_path, output_path)
            self.assertEqual(recording.encrypted_path, output_path / "test.vrs.enc")

    def test_optional_fields_default_to_none(self) -> None:
        """
        Test that optional fields default to None.

        Arrange: Create AriaRecording instance.
        Act: Access optional fields.
        Assert: All optional fields are None by default.
        """
        with tempfile.TemporaryDirectory() as tmpdir:
            vrs_path = Path(tmpdir) / "test.vrs"
            vrs_path.touch()

            recording = AriaRecording.create(vrs_path)

            self.assertIsNone(recording.fbid)
            self.assertIsNone(recording.file_hash)
            self.assertIsNone(recording.device_type)


class TestMpsFeatureRequest(unittest.TestCase):
    """Tests for the MpsFeatureRequest dataclass."""

    def test_is_pending_returns_correct_value_for_each_status(self) -> None:
        """
        Test that is_pending correctly identifies pending vs completed statuses.

        Arrange: Define test cases mapping Status enum values to expected pending state.
        Act: Create MpsFeatureRequest for each status and call is_pending().
        Assert: SCHEDULED and PROCESSING return True, SUCCEEDED and FAILED return False.
        """
        test_cases = [
            (Status.SCHEDULED, True),
            (Status.PROCESSING, True),
            (Status.SUCCEEDED, False),
            (Status.FAILED, False),
        ]

        for status, expected_pending in test_cases:
            with self.subTest(status=status):
                request = MpsFeatureRequest(
                    fbid=123,
                    feature=MpsFeature.SLAM,
                    status=status,
                    results=[],
                    creation_time=1234567890,
                )
                self.assertEqual(request.is_pending(), expected_pending)


if __name__ == "__main__":
    unittest.main()
