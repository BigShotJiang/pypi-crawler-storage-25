# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unit tests for health_check.py

Tests cover:
- HealthCheckRunner.get_key() for unique key generation
- get_setting_keys() returns correct config section and key
- Health check path validation scenarios
- Device type-based VHC key validation
- to_proc usage for non-blocking health check execution
"""

import json
import os
import tempfile
import unittest
from asyncio import Semaphore
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional


class MpsAriaDevice(Enum):
    """Local copy of MpsAriaDevice to avoid Config initialization."""

    ARIA_GEN1 = "ARIA_GEN1"
    ARIA_GEN2 = "ARIA_GEN2"
    UNKNOWN = "UNKNOWN"


KEY_VHC_ARIA_GEN1_DEFAULT = "aria_gen1_default"
KEY_VHC_ARIA_GEN2_DEFAULT = "aria_gen2_default"


class MockAriaRecording:
    """Mock AriaRecording for testing without Config."""

    def __init__(
        self,
        path: Path,
        health_check_path: Optional[Path] = None,
        device_type: Optional[MpsAriaDevice] = None,
    ) -> None:
        self.path = path
        self._health_check_path = health_check_path
        self.device_type = device_type

    @property
    def health_check_path(self) -> Path:
        if self._health_check_path:
            return self._health_check_path
        return self.path.parent / f"{self.path.stem}_vhc.json"


class MockHealthCheckRunner:
    """Mock HealthCheckRunner to avoid Config initialization at class level."""

    semaphore_: Semaphore = Semaphore(value=4)

    @classmethod
    def get_setting_keys(cls) -> tuple:
        """Return the config section and key for the health check runner's semaphore."""
        return "HEALTH_CHECK", "concurrent_health_checks"

    @classmethod
    def get_key(cls, recording: MockAriaRecording) -> str:
        """Get a unique key for this Runner instance."""
        return f"{recording.path}_{recording.health_check_path}"


def is_health_check_valid(
    health_check_path: Path,
    device_type: Optional[MpsAriaDevice],
    vhc_json: Dict[str, Any],
) -> bool:
    """
    Check if a health check file is valid based on device type.

    Simplified version of the validation logic in HealthCheckRunner._run().
    """
    if not health_check_path.exists():
        return False

    if (
        device_type == MpsAriaDevice.ARIA_GEN1 and KEY_VHC_ARIA_GEN1_DEFAULT in vhc_json
    ) or (
        device_type == MpsAriaDevice.ARIA_GEN2 and KEY_VHC_ARIA_GEN2_DEFAULT in vhc_json
    ):
        return True

    return False


class TestHealthCheckRunnerGetKey(unittest.TestCase):
    """Tests for HealthCheckRunner.get_key() method."""

    def test_get_key_returns_path_and_health_check_path(self) -> None:
        """
        Test that get_key returns a string combining path and health_check_path.

        Arrange: Create a mock recording with path and health_check_path
        Act: Call get_key with the recording
        Assert: Key contains both path and health_check_path
        """
        # Arrange
        vrs_path = Path("/data/recording.vrs")
        hc_path = Path("/data/recording_vhc.json")
        recording = MockAriaRecording(path=vrs_path, health_check_path=hc_path)

        # Act
        key = MockHealthCheckRunner.get_key(recording)

        # Assert
        self.assertIn(str(vrs_path), key)
        self.assertIn(str(hc_path), key)

    def test_get_key_different_recordings_produce_different_keys(self) -> None:
        """
        Test that different recordings produce different keys.

        Arrange: Create two different mock recordings
        Act: Call get_key for each recording
        Assert: Keys are different
        """
        # Arrange
        recording1 = MockAriaRecording(
            path=Path("/data/rec1.vrs"),
            health_check_path=Path("/data/rec1_vhc.json"),
        )
        recording2 = MockAriaRecording(
            path=Path("/data/rec2.vrs"),
            health_check_path=Path("/data/rec2_vhc.json"),
        )

        # Act
        key1 = MockHealthCheckRunner.get_key(recording1)
        key2 = MockHealthCheckRunner.get_key(recording2)

        # Assert
        self.assertNotEqual(key1, key2)

    def test_get_key_same_recording_produces_same_key(self) -> None:
        """
        Test that the same recording produces the same key.

        Arrange: Create a mock recording
        Act: Call get_key twice with the same recording
        Assert: Keys are identical
        """
        # Arrange
        recording = MockAriaRecording(
            path=Path("/data/recording.vrs"),
            health_check_path=Path("/data/recording_vhc.json"),
        )

        # Act
        key1 = MockHealthCheckRunner.get_key(recording)
        key2 = MockHealthCheckRunner.get_key(recording)

        # Assert
        self.assertEqual(key1, key2)


class TestHealthCheckRunnerGetSettingKeys(unittest.TestCase):
    """Tests for HealthCheckRunner.get_setting_keys() method."""

    def test_get_setting_keys_returns_tuple(self) -> None:
        """
        Test that get_setting_keys returns a tuple.

        Arrange: No setup needed
        Act: Call get_setting_keys
        Assert: Result is a tuple with section and key
        """
        # Arrange - none needed

        # Act
        result = MockHealthCheckRunner.get_setting_keys()

        # Assert
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 2)

    def test_get_setting_keys_returns_health_check_section(self) -> None:
        """
        Test that get_setting_keys returns HEALTH_CHECK section.

        Arrange: No setup needed
        Act: Call get_setting_keys
        Assert: Section is HEALTH_CHECK
        """
        # Arrange - none needed

        # Act
        section, _ = MockHealthCheckRunner.get_setting_keys()

        # Assert
        self.assertEqual(section, "HEALTH_CHECK")


class TestHealthCheckValidation(unittest.TestCase):
    """Tests for health check validation logic."""

    def setUp(self) -> None:
        """Set up temp directory for test files."""
        self._temp_dir = tempfile.mkdtemp()

    def test_valid_gen1_health_check(self) -> None:
        """
        Test that Gen1 health check with correct key is valid.

        Arrange: Create a health check file with Gen1 key
        Act: Check validity for Gen1 device
        Assert: Health check is valid
        """
        # Arrange
        hc_path = Path(self._temp_dir) / "gen1_vhc.json"
        vhc_data = {KEY_VHC_ARIA_GEN1_DEFAULT: {"status": "pass"}}
        with open(hc_path, "w") as f:
            json.dump(vhc_data, f)

        # Act
        result = is_health_check_valid(hc_path, MpsAriaDevice.ARIA_GEN1, vhc_data)

        # Assert
        self.assertTrue(result)

    def test_valid_gen2_health_check(self) -> None:
        """
        Test that Gen2 health check with correct key is valid.

        Arrange: Create a health check file with Gen2 key
        Act: Check validity for Gen2 device
        Assert: Health check is valid
        """
        # Arrange
        hc_path = Path(self._temp_dir) / "gen2_vhc.json"
        vhc_data = {KEY_VHC_ARIA_GEN2_DEFAULT: {"status": "pass"}}
        with open(hc_path, "w") as f:
            json.dump(vhc_data, f)

        # Act
        result = is_health_check_valid(hc_path, MpsAriaDevice.ARIA_GEN2, vhc_data)

        # Assert
        self.assertTrue(result)

    def test_invalid_gen1_health_check_wrong_key(self) -> None:
        """
        Test that Gen1 health check with Gen2 key is invalid.

        Arrange: Create a health check file with Gen2 key
        Act: Check validity for Gen1 device
        Assert: Health check is invalid
        """
        # Arrange
        hc_path = Path(self._temp_dir) / "wrong_key_vhc.json"
        vhc_data = {KEY_VHC_ARIA_GEN2_DEFAULT: {"status": "pass"}}
        with open(hc_path, "w") as f:
            json.dump(vhc_data, f)

        # Act
        result = is_health_check_valid(hc_path, MpsAriaDevice.ARIA_GEN1, vhc_data)

        # Assert
        self.assertFalse(result)

    def test_invalid_nonexistent_file(self) -> None:
        """
        Test that non-existent health check file is invalid.

        Arrange: Create a path to a non-existent file
        Act: Check validity
        Assert: Health check is invalid
        """
        # Arrange
        hc_path = Path(self._temp_dir) / "nonexistent.json"
        vhc_data: Dict[str, Any] = {}

        # Act
        result = is_health_check_valid(hc_path, MpsAriaDevice.ARIA_GEN1, vhc_data)

        # Assert
        self.assertFalse(result)

    def test_unknown_device_type_is_invalid(self) -> None:
        """
        Test that unknown device type results in invalid health check.

        Arrange: Create health check file with both keys
        Act: Check validity for UNKNOWN device
        Assert: Health check is invalid
        """
        # Arrange
        hc_path = Path(self._temp_dir) / "unknown_vhc.json"
        vhc_data = {
            KEY_VHC_ARIA_GEN1_DEFAULT: {"status": "pass"},
            KEY_VHC_ARIA_GEN2_DEFAULT: {"status": "pass"},
        }
        with open(hc_path, "w") as f:
            json.dump(vhc_data, f)

        # Act
        result = is_health_check_valid(hc_path, MpsAriaDevice.UNKNOWN, vhc_data)

        # Assert
        self.assertFalse(result)


class TestSemaphoreBehavior(unittest.TestCase):
    """Tests for semaphore behavior in health check runner."""

    def test_semaphore_initial_value(self) -> None:
        """
        Test that semaphore has expected initial value.

        Arrange: Check the mock class semaphore
        Act: Access semaphore value
        Assert: Value is expected default
        """
        # Arrange - semaphore defined on class

        # Act
        value = MockHealthCheckRunner.semaphore_._value

        # Assert
        self.assertEqual(value, 4)

    def test_semaphore_update(self) -> None:
        """
        Test that semaphore can be updated with new value.

        Arrange: Create a new semaphore with different value
        Act: Assign to class
        Assert: Value is updated
        """
        # Arrange
        old_semaphore = MockHealthCheckRunner.semaphore_
        new_semaphore = Semaphore(value=8)

        # Act
        MockHealthCheckRunner.semaphore_ = new_semaphore

        # Assert
        self.assertEqual(MockHealthCheckRunner.semaphore_._value, 8)

        # Cleanup
        MockHealthCheckRunner.semaphore_ = old_semaphore


class TestHealthCheckRunsInProcess(unittest.IsolatedAsyncioTestCase):
    """Tests that VRS health check runs via to_proc to avoid blocking the event loop."""

    async def test_run_uses_to_proc_when_ark_apis_set(self) -> None:
        """
        Verify that _run() delegates to to_proc when USE_ARK_APIS is set,
        offloading the GIL-holding C++ health check to a separate process.

        Arrange: Import real HealthCheckRunner, create mock recording with no existing
                 health check file
        Act: Call _run() with USE_ARK_APIS env var set and to_proc patched
        Assert: to_proc was called with the module-level wrapper function and
                correct positional arguments (path, health_check_path)
        """
        from unittest.mock import AsyncMock, MagicMock, patch

        from aria_mps_cli.cli_lib.health_check import (
            _run_vrs_health_check_in_process,
            HealthCheckRunner,
        )

        mock_recording = MagicMock()
        mock_recording.path.as_posix.return_value = "/data/test.vrs"
        mock_recording.health_check_path.exists.return_value = False
        mock_recording.health_check_path.as_posix.return_value = "/tmp/test_vhc.json"

        runner = HealthCheckRunner(mock_recording)

        mock_to_proc = AsyncMock()

        with (
            patch.dict(os.environ, {"USE_ARK_APIS": "TRUE"}),
            patch("aria_mps_cli.cli_lib.health_check.to_proc", mock_to_proc),
        ):
            await runner._run()

            mock_to_proc.assert_called_once_with(
                _run_vrs_health_check_in_process,
                "/data/test.vrs",
                "/tmp/test_vhc.json",
            )


if __name__ == "__main__":
    unittest.main()
