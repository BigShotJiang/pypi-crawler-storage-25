# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unit tests for config_updatable.py

Tests cover:
- ConfigUpdatable abstract interface
- Semaphore update mechanism
- get_setting_keys() abstract method
- update_from_config() class method
"""

import unittest
from abc import ABC, abstractmethod
from asyncio import Semaphore
from typing import List, Tuple, Type


class MockConfigUpdatable(ABC):
    """Mock ConfigUpdatable interface for testing."""

    semaphore_: Semaphore

    @classmethod
    def update_from_config(cls, new_value: int) -> None:
        """Update this component with a new semaphore value."""
        current_value = cls.semaphore_._value
        if current_value != new_value:
            cls.semaphore_ = Semaphore(value=new_value)

    @classmethod
    @abstractmethod
    def get_setting_keys(cls) -> Tuple[str, str]:
        """Return the config section and key for this component's semaphore setting."""
        pass


class MockUploader(MockConfigUpdatable):
    """Mock Uploader class for testing."""

    semaphore_: Semaphore = Semaphore(value=4)

    @classmethod
    def get_setting_keys(cls) -> Tuple[str, str]:
        return "UPLOAD", "concurrent_uploads"


class MockDownloader(MockConfigUpdatable):
    """Mock Downloader class for testing."""

    semaphore_: Semaphore = Semaphore(value=4)

    @classmethod
    def get_setting_keys(cls) -> Tuple[str, str]:
        return "DOWNLOAD", "concurrent_downloads"


class MockHashCalculator(MockConfigUpdatable):
    """Mock HashCalculator class for testing."""

    semaphore_: Semaphore = Semaphore(value=8)

    @classmethod
    def get_setting_keys(cls) -> Tuple[str, str]:
        return "HASH", "concurrent_hash_calculations"


class MockHealthCheckRunner(MockConfigUpdatable):
    """Mock HealthCheckRunner class for testing."""

    semaphore_: Semaphore = Semaphore(value=4)

    @classmethod
    def get_setting_keys(cls) -> Tuple[str, str]:
        return "HEALTH_CHECK", "concurrent_health_checks"


def update_all_components(
    components: List[Type[MockConfigUpdatable]], new_value: int
) -> None:
    """Update all components semaphores with a new value."""
    for component_class in components:
        component_class.update_from_config(new_value)


class TestConfigUpdatableInterface(unittest.TestCase):
    """Tests for ConfigUpdatable interface."""

    def test_get_setting_keys_returns_tuple(self) -> None:
        """
        Test that get_setting_keys returns a tuple.

        Arrange: No setup needed
        Act: Call get_setting_keys
        Assert: Result is a tuple with 2 elements
        """
        # Arrange - none needed

        # Act
        result = MockUploader.get_setting_keys()

        # Assert
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 2)

    def test_uploader_setting_keys(self) -> None:
        """
        Test Uploader returns correct setting keys.

        Arrange: No setup needed
        Act: Get setting keys
        Assert: Section and key are correct
        """
        # Arrange - none needed

        # Act
        section, key = MockUploader.get_setting_keys()

        # Assert
        self.assertEqual(section, "UPLOAD")
        self.assertEqual(key, "concurrent_uploads")

    def test_downloader_setting_keys(self) -> None:
        """
        Test Downloader returns correct setting keys.

        Arrange: No setup needed
        Act: Get setting keys
        Assert: Section and key are correct
        """
        # Arrange - none needed

        # Act
        section, key = MockDownloader.get_setting_keys()

        # Assert
        self.assertEqual(section, "DOWNLOAD")
        self.assertEqual(key, "concurrent_downloads")

    def test_health_check_setting_keys(self) -> None:
        """
        Test HealthCheckRunner returns correct setting keys.

        Arrange: No setup needed
        Act: Get setting keys
        Assert: Section and key are correct
        """
        # Arrange - none needed

        # Act
        section, key = MockHealthCheckRunner.get_setting_keys()

        # Assert
        self.assertEqual(section, "HEALTH_CHECK")
        self.assertEqual(key, "concurrent_health_checks")


class TestSemaphoreUpdate(unittest.TestCase):
    """Tests for semaphore update mechanism."""

    def setUp(self) -> None:
        """Reset semaphores before each test."""
        MockUploader.semaphore_ = Semaphore(value=4)
        MockDownloader.semaphore_ = Semaphore(value=4)
        MockHashCalculator.semaphore_ = Semaphore(value=8)

    def test_update_changes_semaphore_value(self) -> None:
        """
        Test that update_from_config changes semaphore value.

        Arrange: Get initial value
        Act: Update with new value
        Assert: Semaphore value is changed
        """
        # Arrange
        initial_value = MockUploader.semaphore_._value
        new_value = 10

        # Act
        MockUploader.update_from_config(new_value)

        # Assert
        self.assertNotEqual(MockUploader.semaphore_._value, initial_value)
        self.assertEqual(MockUploader.semaphore_._value, new_value)

    def test_update_with_same_value_no_change(self) -> None:
        """
        Test that update with same value doesn't create new semaphore.

        Arrange: Get initial semaphore
        Act: Update with same value
        Assert: Semaphore reference is unchanged (value same)
        """
        # Arrange
        initial_value = MockUploader.semaphore_._value

        # Act
        MockUploader.update_from_config(initial_value)

        # Assert
        self.assertEqual(MockUploader.semaphore_._value, initial_value)

    def test_update_independent_per_class(self) -> None:
        """
        Test that updates are independent per class.

        Arrange: Get initial values for multiple classes
        Act: Update only one class
        Assert: Other classes are unaffected
        """
        # Arrange
        downloader_initial = MockDownloader.semaphore_._value

        # Act
        MockUploader.update_from_config(20)

        # Assert
        self.assertEqual(MockUploader.semaphore_._value, 20)
        self.assertEqual(MockDownloader.semaphore_._value, downloader_initial)


class TestUpdateAllComponents(unittest.TestCase):
    """Tests for update_all_components function."""

    def setUp(self) -> None:
        """Reset semaphores before each test."""
        MockUploader.semaphore_ = Semaphore(value=4)
        MockDownloader.semaphore_ = Semaphore(value=4)
        MockHashCalculator.semaphore_ = Semaphore(value=8)
        MockHealthCheckRunner.semaphore_ = Semaphore(value=4)

    def test_updates_all_components(self) -> None:
        """
        Test that update_all_components updates all classes.

        Arrange: Create list of component classes
        Act: Update all with new value
        Assert: All semaphores are updated
        """
        # Arrange
        components = [MockUploader, MockDownloader, MockHashCalculator]
        new_value = 16

        # Act
        update_all_components(components, new_value)

        # Assert
        for component in components:
            self.assertEqual(component.semaphore_._value, new_value)

    def test_empty_components_list(self) -> None:
        """
        Test that empty components list works.

        Arrange: Create empty list
        Act: Call update_all_components
        Assert: No error occurs
        """
        # Arrange
        components: List[Type[MockConfigUpdatable]] = []

        # Act & Assert - no exception raised
        update_all_components(components, 10)


class TestSemaphoreInitialValues(unittest.TestCase):
    """Tests for initial semaphore values."""

    def test_uploader_initial_value(self) -> None:
        """
        Test Uploader initial semaphore value.

        Arrange: Reset semaphore
        Act: Check value
        Assert: Value is 4
        """
        # Arrange
        MockUploader.semaphore_ = Semaphore(value=4)

        # Act
        value = MockUploader.semaphore_._value

        # Assert
        self.assertEqual(value, 4)

    def test_hash_calculator_initial_value(self) -> None:
        """
        Test HashCalculator initial semaphore value.

        Arrange: Reset semaphore
        Act: Check value
        Assert: Value is 8
        """
        # Arrange
        MockHashCalculator.semaphore_ = Semaphore(value=8)

        # Act
        value = MockHashCalculator.semaphore_._value

        # Assert
        self.assertEqual(value, 8)


class TestAbstractMethod(unittest.TestCase):
    """Tests for abstract method enforcement."""

    def test_cannot_instantiate_without_get_setting_keys(self) -> None:
        """
        Test that class without get_setting_keys cannot be instantiated.

        Arrange: Define incomplete subclass
        Act: Try to instantiate
        Assert: TypeError is raised
        """

        # Arrange
        class IncompleteComponent(MockConfigUpdatable):
            semaphore_ = Semaphore(value=1)
            # Missing get_setting_keys implementation

        # Act & Assert
        with self.assertRaises(TypeError):
            IncompleteComponent()  # type: ignore


if __name__ == "__main__":
    unittest.main()
