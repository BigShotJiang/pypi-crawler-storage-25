# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unit tests for mps.py

Tests cover:
- Command type constants
- Mps initialization
- Feature setting based on mode
- Input path validation (file vs directory, vrs extension)
- Recording collection from input paths
- Status retrieval patterns
- Device type retrieval patterns
"""

import argparse
import tempfile
import unittest
from enum import Enum
from pathlib import Path
from typing import List, Optional, Set


class MpsFeature(Enum):
    """Local copy of MpsFeature to avoid Config initialization."""

    SLAM = "SLAM"
    EYE_GAZE = "EYE_GAZE"
    HAND_TRACKING = "HAND_TRACKING"
    MULTI_SLAM = "MULTI_SLAM"


class MpsAriaDevice(Enum):
    """Local copy of MpsAriaDevice to avoid Config initialization."""

    ARIA_GEN1 = "ARIA_GEN1"
    ARIA_GEN2 = "ARIA_GEN2"
    UNKNOWN = "UNKNOWN"


class ModelState:
    """Local copy of ModelState to avoid Config initialization."""

    __slots__ = ("status", "progress", "error_code")

    def __init__(
        self,
        status: str = "CREATED",
        progress: float = 0,
        error_code: Optional[str] = None,
    ) -> None:
        self.status = status
        self.progress = progress
        self.error_code = error_code


_SINGLE_COMMAND: str = "single"
_MULTI_COMMAND: str = "multi"


def collect_recordings_from_input(input_paths: List[Path]) -> Set[Path]:
    """
    Collect recordings from input paths.

    Simplified version of the recording collection logic in Mps.run().
    """
    recordings: Set[Path] = set()
    for input_path in input_paths:
        if input_path.is_file():
            if input_path.suffix == ".vrs":
                recordings.add(input_path)
        elif input_path.is_dir():
            for vrs_file in input_path.rglob("*.vrs"):
                recordings.add(vrs_file)
    return recordings


def get_features_for_mode(mode: str, features: Set[MpsFeature]) -> List[MpsFeature]:
    """
    Get features based on mode.

    Simplified version of the feature selection logic in Mps.run().
    """
    if mode == _SINGLE_COMMAND:
        return list(features)
    else:
        return [MpsFeature.MULTI_SLAM]


class TestMpsConstants(unittest.TestCase):
    """Tests for Mps command constants."""

    def test_single_command_constant(self) -> None:
        """
        Test SINGLE_COMMAND constant value.

        Arrange: No setup needed
        Act: Check constant value
        Assert: Constant equals "single"
        """
        # Arrange - none needed

        # Act
        result = _SINGLE_COMMAND

        # Assert
        self.assertEqual(result, "single")

    def test_multi_command_constant(self) -> None:
        """
        Test MULTI_COMMAND constant value.

        Arrange: No setup needed
        Act: Check constant value
        Assert: Constant equals "multi"
        """
        # Arrange - none needed

        # Act
        result = _MULTI_COMMAND

        # Assert
        self.assertEqual(result, "multi")


class TestFeatureSelection(unittest.TestCase):
    """Tests for feature selection based on mode."""

    def test_single_mode_uses_provided_features(self) -> None:
        """
        Test that single mode uses provided features.

        Arrange: Create a set of features
        Act: Get features for single mode
        Assert: All provided features are returned
        """
        # Arrange
        features = {MpsFeature.SLAM, MpsFeature.EYE_GAZE}

        # Act
        result = get_features_for_mode(_SINGLE_COMMAND, features)

        # Assert
        self.assertEqual(set(result), features)

    def test_multi_mode_uses_multi_slam(self) -> None:
        """
        Test that multi mode always uses MULTI_SLAM.

        Arrange: Create a set of features
        Act: Get features for multi mode
        Assert: Only MULTI_SLAM is returned
        """
        # Arrange
        features = {MpsFeature.SLAM, MpsFeature.EYE_GAZE}

        # Act
        result = get_features_for_mode(_MULTI_COMMAND, features)

        # Assert
        self.assertEqual(result, [MpsFeature.MULTI_SLAM])

    def test_multi_mode_ignores_provided_features(self) -> None:
        """
        Test that multi mode ignores provided features.

        Arrange: Create features without MULTI_SLAM
        Act: Get features for multi mode
        Assert: MULTI_SLAM is returned, not provided features
        """
        # Arrange
        features = {MpsFeature.HAND_TRACKING}

        # Act
        result = get_features_for_mode(_MULTI_COMMAND, features)

        # Assert
        self.assertNotIn(MpsFeature.HAND_TRACKING, result)
        self.assertIn(MpsFeature.MULTI_SLAM, result)


class TestRecordingCollection(unittest.TestCase):
    """Tests for recording collection from input paths."""

    def setUp(self) -> None:
        """Set up temp directory for test files."""
        self._temp_dir = tempfile.mkdtemp()
        self._temp_path = Path(self._temp_dir)

    def test_collect_single_vrs_file(self) -> None:
        """
        Test collecting a single VRS file.

        Arrange: Create a single VRS file
        Act: Collect recordings
        Assert: Single file is collected
        """
        # Arrange
        vrs_file = self._temp_path / "recording.vrs"
        vrs_file.touch()

        # Act
        result = collect_recordings_from_input([vrs_file])

        # Assert
        self.assertEqual(len(result), 1)
        self.assertIn(vrs_file, result)

    def test_ignore_non_vrs_file(self) -> None:
        """
        Test that non-VRS files are ignored.

        Arrange: Create a non-VRS file
        Act: Collect recordings
        Assert: No files are collected
        """
        # Arrange
        txt_file = self._temp_path / "recording.txt"
        txt_file.touch()

        # Act
        result = collect_recordings_from_input([txt_file])

        # Assert
        self.assertEqual(len(result), 0)

    def test_collect_vrs_from_directory(self) -> None:
        """
        Test collecting VRS files from a directory.

        Arrange: Create multiple VRS files in a directory
        Act: Collect recordings from directory
        Assert: All VRS files are collected
        """
        # Arrange
        vrs1 = self._temp_path / "rec1.vrs"
        vrs2 = self._temp_path / "rec2.vrs"
        vrs1.touch()
        vrs2.touch()

        # Act
        result = collect_recordings_from_input([self._temp_path])

        # Assert
        self.assertEqual(len(result), 2)
        self.assertIn(vrs1, result)
        self.assertIn(vrs2, result)

    def test_collect_vrs_from_subdirectories(self) -> None:
        """
        Test collecting VRS files from subdirectories recursively.

        Arrange: Create VRS files in nested directories
        Act: Collect recordings from root directory
        Assert: All VRS files including nested ones are collected
        """
        # Arrange
        subdir = self._temp_path / "subdir"
        subdir.mkdir()
        vrs1 = self._temp_path / "rec1.vrs"
        vrs2 = subdir / "rec2.vrs"
        vrs1.touch()
        vrs2.touch()

        # Act
        result = collect_recordings_from_input([self._temp_path])

        # Assert
        self.assertEqual(len(result), 2)
        self.assertIn(vrs1, result)
        self.assertIn(vrs2, result)

    def test_collect_from_multiple_paths(self) -> None:
        """
        Test collecting from multiple input paths.

        Arrange: Create VRS files in different locations
        Act: Collect recordings from multiple paths
        Assert: All VRS files are collected
        """
        # Arrange
        dir1 = self._temp_path / "dir1"
        dir2 = self._temp_path / "dir2"
        dir1.mkdir()
        dir2.mkdir()
        vrs1 = dir1 / "rec1.vrs"
        vrs2 = dir2 / "rec2.vrs"
        vrs1.touch()
        vrs2.touch()

        # Act
        result = collect_recordings_from_input([dir1, dir2])

        # Assert
        self.assertEqual(len(result), 2)

    def test_empty_directory_returns_empty_set(self) -> None:
        """
        Test that empty directory returns empty set.

        Arrange: Create an empty directory
        Act: Collect recordings
        Assert: Empty set is returned
        """
        # Arrange
        empty_dir = self._temp_path / "empty"
        empty_dir.mkdir()

        # Act
        result = collect_recordings_from_input([empty_dir])

        # Assert
        self.assertEqual(len(result), 0)

    def test_mixed_files_collects_only_vrs(self) -> None:
        """
        Test that mixed file types only collects VRS files.

        Arrange: Create VRS and non-VRS files in directory
        Act: Collect recordings
        Assert: Only VRS files are collected
        """
        # Arrange
        vrs_file = self._temp_path / "recording.vrs"
        txt_file = self._temp_path / "notes.txt"
        json_file = self._temp_path / "config.json"
        vrs_file.touch()
        txt_file.touch()
        json_file.touch()

        # Act
        result = collect_recordings_from_input([self._temp_path])

        # Assert
        self.assertEqual(len(result), 1)
        self.assertIn(vrs_file, result)


class TestMpsStatusRetrieval(unittest.TestCase):
    """Tests for Mps status retrieval patterns."""

    def test_model_state_default_values(self) -> None:
        """
        Test ModelState default values.

        Arrange: Create a ModelState with defaults
        Act: Check default values
        Assert: Values are as expected
        """
        # Arrange
        state = ModelState()

        # Act & Assert
        self.assertEqual(state.status, "CREATED")
        self.assertEqual(state.progress, 0)
        self.assertIsNone(state.error_code)

    def test_model_state_with_progress(self) -> None:
        """
        Test ModelState with progress.

        Arrange: Create a ModelState with progress
        Act: Check progress value
        Assert: Progress is set correctly
        """
        # Arrange
        state = ModelState(status="HASHING", progress=50.5)

        # Act
        progress = state.progress

        # Assert
        self.assertEqual(progress, 50.5)

    def test_model_state_with_error(self) -> None:
        """
        Test ModelState with error code.

        Arrange: Create a ModelState with error
        Act: Check error code
        Assert: Error code is set correctly
        """
        # Arrange
        state = ModelState(status="ERROR", error_code="123")

        # Act
        error_code = state.error_code

        # Assert
        self.assertEqual(error_code, "123")


class TestMpsDeviceType(unittest.TestCase):
    """Tests for device type retrieval."""

    def test_aria_gen1_device_type(self) -> None:
        """
        Test ARIA_GEN1 device type value.

        Arrange: No setup needed
        Act: Get ARIA_GEN1 value
        Assert: Value is correct
        """
        # Arrange - none needed

        # Act
        result = MpsAriaDevice.ARIA_GEN1.value

        # Assert
        self.assertEqual(result, "ARIA_GEN1")

    def test_aria_gen2_device_type(self) -> None:
        """
        Test ARIA_GEN2 device type value.

        Arrange: No setup needed
        Act: Get ARIA_GEN2 value
        Assert: Value is correct
        """
        # Arrange - none needed

        # Act
        result = MpsAriaDevice.ARIA_GEN2.value

        # Assert
        self.assertEqual(result, "ARIA_GEN2")

    def test_unknown_device_type(self) -> None:
        """
        Test UNKNOWN device type value.

        Arrange: No setup needed
        Act: Get UNKNOWN value
        Assert: Value is correct
        """
        # Arrange - none needed

        # Act
        result = MpsAriaDevice.UNKNOWN.value

        # Assert
        self.assertEqual(result, "UNKNOWN")


class TestArgsNamespace(unittest.TestCase):
    """Tests for argument namespace patterns used by Mps."""

    def test_namespace_with_single_mode(self) -> None:
        """
        Test args namespace with single mode.

        Arrange: Create namespace with single mode
        Act: Check mode value
        Assert: Mode is single
        """
        # Arrange
        args = argparse.Namespace(
            mode=_SINGLE_COMMAND,
            features={MpsFeature.SLAM},
            input=[Path("/data/recording.vrs")],
            force=False,
            retry_failed=False,
            suffix=None,
            persist_on_failure=False,
        )

        # Act
        mode = args.mode

        # Assert
        self.assertEqual(mode, _SINGLE_COMMAND)

    def test_namespace_with_multi_mode(self) -> None:
        """
        Test args namespace with multi mode.

        Arrange: Create namespace with multi mode
        Act: Check mode value
        Assert: Mode is multi
        """
        # Arrange
        args = argparse.Namespace(
            mode=_MULTI_COMMAND,
            input=[Path("/data/")],
            output_dir=Path("/output"),
            name="test_request",
            force=True,
            retry_failed=True,
            suffix=None,
            persist_on_failure=True,
        )

        # Act
        mode = args.mode

        # Assert
        self.assertEqual(mode, _MULTI_COMMAND)

    def test_features_from_namespace(self) -> None:
        """
        Test extracting features from namespace.

        Arrange: Create namespace with multiple features
        Act: Get features
        Assert: Features are correct
        """
        # Arrange
        expected_features = {MpsFeature.SLAM, MpsFeature.EYE_GAZE}
        args = argparse.Namespace(mode=_SINGLE_COMMAND, features=expected_features)

        # Act
        features = args.features

        # Assert
        self.assertEqual(features, expected_features)


if __name__ == "__main__":
    unittest.main()
