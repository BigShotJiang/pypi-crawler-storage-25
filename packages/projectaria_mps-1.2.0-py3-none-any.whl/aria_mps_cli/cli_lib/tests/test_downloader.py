# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import unittest
from pathlib import Path
from typing import Optional, Tuple
from unittest.mock import MagicMock


class MockConfigUpdatable:
    """Mock ConfigUpdatable interface for testing."""

    semaphore_: asyncio.Semaphore = asyncio.Semaphore(3)

    @classmethod
    def get_setting_keys(cls) -> Tuple[str, str]:
        """Return the config section and key for this component's semaphore setting."""
        return "DOWNLOAD", "CONCURRENT_DOWNLOADS"

    @classmethod
    def update_from_config(cls) -> None:
        """Update this component with the latest config values."""
        pass


class MockDownloader(MockConfigUpdatable):
    """
    Simplified Downloader class for testing.
    Avoids imports that trigger Config initialization.
    """

    def __init__(
        self,
        url: str,
        download_dir: Path,
        http_helper: MagicMock,
        download_filename: Optional[str] = None,
        unzip: bool = False,
    ):
        self._url = url
        self._download_dir = download_dir
        self._http_helper = http_helper
        self._download_filename = download_filename
        self._unzip = unzip
        self._processed = 0
        self._total = 0

    @classmethod
    def get_key(
        cls,
        url: str,
        download_dir: Path,
        http_helper: MagicMock,
        download_filename: Optional[str] = None,
        unzip: bool = False,
    ) -> str:
        """Get a unique key for this Runner instance."""
        return f"{url}_{download_dir}"

    @property
    def progress(self) -> float:
        """Calculate download progress percentage."""
        if self._total == 0:
            return 0
        return (self._processed / self._total) * 100


class TestDownloaderKey(unittest.TestCase):
    """Tests for Downloader.get_key method."""

    def test_get_key_combines_url_and_dir(self) -> None:
        """
        Test that get_key combines URL and directory.

        Arrange: URL and download directory.
        Act: Call get_key.
        Assert: Key contains both URL and directory.
        """
        url = "https://example.com/file.zip"
        download_dir = Path("/tmp/downloads")

        key = MockDownloader.get_key(url, download_dir, MagicMock())

        self.assertIn(url, key)
        self.assertIn(str(download_dir), key)

    def test_get_key_unique_for_different_urls(self) -> None:
        """
        Test that different URLs produce different keys.

        Arrange: Different URLs with same directory.
        Act: Generate keys.
        Assert: Keys are different.
        """
        url1 = "https://example.com/file1.zip"
        url2 = "https://example.com/file2.zip"
        download_dir = Path("/tmp/downloads")

        key1 = MockDownloader.get_key(url1, download_dir, MagicMock())
        key2 = MockDownloader.get_key(url2, download_dir, MagicMock())

        self.assertNotEqual(key1, key2)

    def test_get_key_unique_for_different_dirs(self) -> None:
        """
        Test that different directories produce different keys.

        Arrange: Same URL with different directories.
        Act: Generate keys.
        Assert: Keys are different.
        """
        url = "https://example.com/file.zip"
        dir1 = Path("/tmp/downloads1")
        dir2 = Path("/tmp/downloads2")

        key1 = MockDownloader.get_key(url, dir1, MagicMock())
        key2 = MockDownloader.get_key(url, dir2, MagicMock())

        self.assertNotEqual(key1, key2)


class TestDownloaderInit(unittest.TestCase):
    """Tests for Downloader initialization."""

    def test_init_stores_parameters(self) -> None:
        """
        Test that initialization stores all parameters.

        Arrange: Create Downloader with parameters.
        Act: Access stored properties.
        Assert: All parameters are stored correctly.
        """
        url = "https://example.com/file.zip"
        download_dir = Path("/tmp/downloads")
        http_helper = MagicMock()
        filename = "custom.zip"

        downloader = MockDownloader(
            url=url,
            download_dir=download_dir,
            http_helper=http_helper,
            download_filename=filename,
            unzip=True,
        )

        self.assertEqual(downloader._url, url)
        self.assertEqual(downloader._download_dir, download_dir)
        self.assertEqual(downloader._download_filename, filename)
        self.assertTrue(downloader._unzip)

    def test_init_default_values(self) -> None:
        """
        Test that initialization uses correct defaults.

        Arrange: Create Downloader with minimal parameters.
        Act: Access optional properties.
        Assert: Default values are applied.
        """
        downloader = MockDownloader(
            url="https://example.com/file.zip",
            download_dir=Path("/tmp"),
            http_helper=MagicMock(),
        )

        self.assertIsNone(downloader._download_filename)
        self.assertFalse(downloader._unzip)


class TestDownloaderProgress(unittest.TestCase):
    """Tests for Downloader progress calculation."""

    def test_progress_zero_when_total_zero(self) -> None:
        """
        Test that progress is 0 when total is 0.

        Arrange: Create Downloader with total=0.
        Act: Get progress.
        Assert: Progress is 0.
        """
        downloader = MockDownloader(
            url="https://example.com/file.zip",
            download_dir=Path("/tmp"),
            http_helper=MagicMock(),
        )
        downloader._total = 0
        downloader._processed = 0

        self.assertEqual(downloader.progress, 0)

    def test_progress_50_percent(self) -> None:
        """
        Test that progress is 50% when half downloaded.

        Arrange: Create Downloader with half processed.
        Act: Get progress.
        Assert: Progress is 50.
        """
        downloader = MockDownloader(
            url="https://example.com/file.zip",
            download_dir=Path("/tmp"),
            http_helper=MagicMock(),
        )
        downloader._total = 1000
        downloader._processed = 500

        self.assertEqual(downloader.progress, 50.0)

    def test_progress_100_when_complete(self) -> None:
        """
        Test that progress is 100 when fully downloaded.

        Arrange: Create Downloader with all bytes processed.
        Act: Get progress.
        Assert: Progress is 100.
        """
        downloader = MockDownloader(
            url="https://example.com/file.zip",
            download_dir=Path("/tmp"),
            http_helper=MagicMock(),
        )
        downloader._total = 1000
        downloader._processed = 1000

        self.assertEqual(downloader.progress, 100.0)


class TestDownloaderSettingKeys(unittest.TestCase):
    """Tests for Downloader config setting keys."""

    def test_get_setting_keys_returns_tuple(self) -> None:
        """
        Test that get_setting_keys returns a tuple.

        Arrange: MockDownloader class.
        Act: Call get_setting_keys.
        Assert: Returns tuple with section and key.
        """
        result = MockDownloader.get_setting_keys()

        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 2)

    def test_get_setting_keys_values(self) -> None:
        """
        Test that get_setting_keys returns correct values.

        Arrange: MockDownloader class.
        Act: Call get_setting_keys.
        Assert: Returns DOWNLOAD section and CONCURRENT_DOWNLOADS key.
        """
        section, key = MockDownloader.get_setting_keys()

        self.assertEqual(section, "DOWNLOAD")
        self.assertEqual(key, "CONCURRENT_DOWNLOADS")


class TestUnzipValidation(unittest.TestCase):
    """Tests for unzip filename validation."""

    def test_zip_extension_valid_for_unzip(self) -> None:
        """
        Test that .zip extension is valid for unzip.

        Arrange: Filename ending with .zip.
        Act: Check extension.
        Assert: File ends with .zip.
        """
        filename = "results.zip"

        self.assertTrue(filename.endswith(".zip"))

    def test_non_zip_extension_invalid_for_unzip(self) -> None:
        """
        Test that non-.zip extension is invalid for unzip.

        Arrange: Filename not ending with .zip.
        Act: Check extension.
        Assert: File does not end with .zip.
        """
        filename = "results.tar.gz"

        self.assertFalse(filename.endswith(".zip"))


if __name__ == "__main__":
    unittest.main()
