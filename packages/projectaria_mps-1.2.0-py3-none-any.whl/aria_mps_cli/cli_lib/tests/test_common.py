# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import unittest
from typing import Any, MutableMapping, Tuple


class CustomAdapter(logging.LoggerAdapter):
    """Custom logging adapter to print the contextual information like vrs file."""

    def process(
        self, msg: Any, kwargs: MutableMapping[str, str]
    ) -> Tuple[str, MutableMapping[str, str]]:
        suffix = (
            " ".join([f"[{k}:{v}]" for k, v in self.extra.items()])
            if self.extra
            else ""
        )
        return " ".join([str(suffix), str(msg)]), kwargs


def get_pretty_size(num_bytes: float, suffix: str = "B") -> str:
    """Returns a human readable size string."""
    factor = 1024
    for unit in ["", "K", "M", "G", "T", "P", "E", "Z"]:
        if num_bytes < factor:
            return f"{num_bytes:.2f} {unit}{suffix}"
        num_bytes /= factor
    return f"{num_bytes:.2f} Y{suffix}"


class ConfigUpdateError(Exception):
    """Exception raised when configuration update fails."""

    pass


class TestCustomAdapter(unittest.TestCase):
    """Tests for the CustomAdapter logging adapter."""

    def test_process_with_extra_context(self) -> None:
        """
        Test that process adds extra context to log messages.

        Arrange: Create CustomAdapter with extra context dict.
        Act: Call process with a message.
        Assert: Message includes formatted extra context.
        """
        logger = logging.getLogger("test")
        adapter = CustomAdapter(logger, {"vrs": "test.vrs", "feature": "SLAM"})

        result_msg, kwargs = adapter.process("Test message", {})

        self.assertIn("[vrs:test.vrs]", result_msg)
        self.assertIn("[feature:SLAM]", result_msg)
        self.assertIn("Test message", result_msg)

    def test_process_without_extra_context(self) -> None:
        """
        Test process behavior without extra context.

        Arrange: Create CustomAdapter with empty extra dict.
        Act: Call process with a message.
        Assert: Message is preserved without extra formatting.
        """
        logger = logging.getLogger("test")
        adapter = CustomAdapter(logger, {})

        result_msg, kwargs = adapter.process("Test message", {})

        self.assertIn("Test message", result_msg)


class TestGetPrettySize(unittest.TestCase):
    """Tests for the get_pretty_size utility function."""

    def test_formats_bytes_to_human_readable(self) -> None:
        """
        Test that byte values are formatted into human-readable strings.

        Arrange: Define test cases mapping byte values to expected formatted strings.
        Act: Call get_pretty_size for each byte value.
        Assert: Each byte value is formatted correctly (B, KB, MB, GB) with 2 decimal places.
        """
        test_cases = [
            (0, "0.00 B"),
            (512, "512.00 B"),
            (1536, "1.50 KB"),
            (2048, "2.00 KB"),
            (5 * 1024 * 1024, "5.00 MB"),
            (3 * 1024 * 1024 * 1024, "3.00 GB"),
        ]

        for num_bytes, expected in test_cases:
            with self.subTest(num_bytes=num_bytes):
                result = get_pretty_size(num_bytes)
                self.assertEqual(result, expected)


class TestConfigUpdateError(unittest.TestCase):
    """Tests for the ConfigUpdateError exception."""

    def test_is_exception(self) -> None:
        """
        Test that ConfigUpdateError is an Exception.

        Arrange: ConfigUpdateError class.
        Act: Create and raise an instance.
        Assert: Can be caught as an Exception with correct message.
        """
        with self.assertRaises(Exception) as ctx:
            raise ConfigUpdateError("Config update failed")

        self.assertIn("Config update failed", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
