# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import unittest
from enum import Enum


class LoginMethod(Enum):
    """
    Enum representing different login methods available for users.
    Copied from authentication.py to avoid Config initialization at import time.
    """

    MMA = "MMA"
    PASSWORD = "Password"
    UNKNOWN = "Unknown"


class AuthenticationError(RuntimeError):
    """
    Raised when authentication fails.
    Copied from authentication.py to avoid Config initialization at import time.
    """

    pass


class TestAuthenticationError(unittest.TestCase):
    """Tests for the AuthenticationError exception."""

    def test_is_runtime_error(self) -> None:
        """
        Test that AuthenticationError is a RuntimeError.

        Arrange: AuthenticationError class.
        Act: Check inheritance.
        Assert: It is a subclass of RuntimeError.
        """
        self.assertTrue(issubclass(AuthenticationError, RuntimeError))

    def test_can_be_raised_and_caught(self) -> None:
        """
        Test that AuthenticationError can be raised and caught.

        Arrange: AuthenticationError class.
        Act: Raise and catch the exception.
        Assert: Exception message is preserved.
        """
        error_message = "Login failed with invalid credentials"

        with self.assertRaises(AuthenticationError) as context:
            raise AuthenticationError(error_message)

        self.assertEqual(str(context.exception), error_message)

    def test_can_be_caught_as_runtime_error(self) -> None:
        """
        Test that AuthenticationError can be caught as RuntimeError.

        Arrange: AuthenticationError class.
        Act: Raise AuthenticationError and catch as RuntimeError.
        Assert: Successfully caught.
        """
        caught = False
        try:
            raise AuthenticationError("test")
        except RuntimeError:
            caught = True

        self.assertTrue(caught)


class TestEmailConversion(unittest.TestCase):
    """Tests for email conversion logic used in authentication."""

    DEFAULT_DOMAIN = "tfbnw.net"
    TEST_DOMAIN = ".wptst.com"
    DOMAINS = {DEFAULT_DOMAIN, TEST_DOMAIN}

    def _get_email(self, username: str) -> str:
        """
        Converts the username to email format if necessary.
        Simplified version of Authenticator._get_email for testing.
        """
        if username.count("@") > 1:
            raise ValueError(f"Invalid email address: {username}.")

        if any((username.lower().endswith(domain) for domain in self.DOMAINS)):
            return username

        if username.count("@") == 1:
            raise ValueError(
                f"Invalid email address: {username}. Expected format: <username>@{self.DEFAULT_DOMAIN}"
            )
        return f"{username}@{self.DEFAULT_DOMAIN}"

    def test_username_without_domain_adds_default(self) -> None:
        """
        Test that username without domain gets default domain appended.

        Arrange: Username without @ symbol.
        Act: Convert to email.
        Assert: Default domain is appended.
        """
        result = self._get_email("testuser")

        self.assertEqual(result, "testuser@tfbnw.net")

    def test_email_with_default_domain_unchanged(self) -> None:
        """
        Test that email with default domain is returned unchanged.

        Arrange: Email with tfbnw.net domain.
        Act: Convert to email.
        Assert: Email is unchanged.
        """
        email = "testuser@tfbnw.net"

        result = self._get_email(email)

        self.assertEqual(result, email)

    def test_email_with_test_domain_unchanged(self) -> None:
        """
        Test that email with test domain is returned unchanged.

        Arrange: Email with .wptst.com domain.
        Act: Convert to email.
        Assert: Email is unchanged.
        """
        email = "testuser@test.wptst.com"

        result = self._get_email(email)

        self.assertEqual(result, email)

    def test_email_with_invalid_domain_raises(self) -> None:
        """
        Test that email with invalid domain raises ValueError.

        Arrange: Email with unsupported domain.
        Act: Convert to email.
        Assert: ValueError is raised.
        """
        with self.assertRaises(ValueError) as context:
            self._get_email("testuser@gmail.com")

        self.assertIn("Invalid email address", str(context.exception))

    def test_multiple_at_signs_raises(self) -> None:
        """
        Test that email with multiple @ signs raises ValueError.

        Arrange: String with multiple @ symbols.
        Act: Convert to email.
        Assert: ValueError is raised.
        """
        with self.assertRaises(ValueError) as context:
            self._get_email("test@user@domain.com")

        self.assertIn("Invalid email address", str(context.exception))


class TestPasswordEncryption(unittest.TestCase):
    """Tests for password encryption helper functions."""

    def test_encrypted_password_format(self) -> None:
        """
        Test that encrypted password follows expected format.

        Arrange: Expected password format prefix.
        Act: Create mock encrypted password string.
        Assert: Format matches expected pattern.
        """
        prefix = "#PWD_ENC:2:"
        mock_encrypted = f"{prefix}12345678:base64encodeddata"

        self.assertTrue(mock_encrypted.startswith(prefix))
        parts = mock_encrypted.split(":")
        self.assertEqual(len(parts), 4)


if __name__ == "__main__":
    unittest.main()
