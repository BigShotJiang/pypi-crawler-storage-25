# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import unittest
from unittest.mock import MagicMock


class GraphQLError(Exception):
    """
    Raised when a GraphQL error occurs.
    Copied from types.py to avoid Config initialization.
    """

    pass


class MockHttpHelper:
    """Mock HttpHelper for testing."""

    def __init__(self):
        self._http_session = MagicMock()
        self._auth_token = None

    @property
    def session(self):
        return self._http_session

    def set_auth_token(self, auth_token: str) -> None:
        """Set the authentication token header for Http Session."""
        self._auth_token = auth_token
        self._http_session.headers = {"Authorization": f"OAuth {auth_token}"}


class TestHttpHelperSetAuthToken(unittest.TestCase):
    """Tests for HttpHelper.set_auth_token method."""

    def test_set_auth_token_stores_token(self) -> None:
        """
        Test that set_auth_token stores the token.

        Arrange: Create HttpHelper.
        Act: Set auth token.
        Assert: Token is stored in headers.
        """
        helper = MockHttpHelper()

        helper.set_auth_token("test_token_123")

        self.assertEqual(
            helper._http_session.headers["Authorization"], "OAuth test_token_123"
        )

    def test_set_auth_token_uses_oauth_prefix(self) -> None:
        """
        Test that set_auth_token uses OAuth prefix.

        Arrange: Create HttpHelper.
        Act: Set auth token.
        Assert: Authorization header has OAuth prefix.
        """
        helper = MockHttpHelper()

        helper.set_auth_token("my_token")

        self.assertTrue(
            helper._http_session.headers["Authorization"].startswith("OAuth ")
        )


class TestGraphQLError(unittest.TestCase):
    """Tests for GraphQLError exception."""

    def test_is_exception(self) -> None:
        """
        Test that GraphQLError is an Exception.

        Arrange: GraphQLError class.
        Act: Check inheritance.
        Assert: It is a subclass of Exception.
        """
        self.assertTrue(issubclass(GraphQLError, Exception))

    def test_can_be_raised_and_caught(self) -> None:
        """
        Test that GraphQLError can be raised and caught.

        Arrange: GraphQLError class with error message.
        Act: Raise and catch the exception.
        Assert: Exception is caught.
        """
        error_details = {"message": "Some GraphQL error", "code": 123}

        with self.assertRaises(GraphQLError) as context:
            raise GraphQLError(error_details)

        self.assertIn("message", str(context.exception))


class TestResponseParsing(unittest.TestCase):
    """Tests for response parsing patterns used in HTTP helper."""

    def test_extract_data_from_response(self) -> None:
        """
        Test extracting data from GraphQL response.

        Arrange: Mock GraphQL response.
        Act: Extract data.
        Assert: Data is extracted correctly.
        """
        response = {"data": {"me": {"alias": "testuser"}}}

        alias = response["data"]["me"]["alias"]

        self.assertEqual(alias, "testuser")

    def test_detect_errors_in_response(self) -> None:
        """
        Test detecting errors in GraphQL response.

        Arrange: Mock GraphQL response with errors.
        Act: Check for errors.
        Assert: Errors are detected.
        """
        response = {"data": None, "errors": [{"message": "Not found"}]}

        has_errors = "errors" in response

        self.assertTrue(has_errors)

    def test_no_errors_in_successful_response(self) -> None:
        """
        Test that successful response has no errors.

        Arrange: Mock successful GraphQL response.
        Act: Check for errors.
        Assert: No errors present.
        """
        response = {"data": {"result": "success"}}

        has_errors = "errors" in response

        self.assertFalse(has_errors)


class TestDocIdConstants(unittest.TestCase):
    """Tests for GraphQL document ID constants."""

    DOC_ID_SUBMIT_MPS_REQUEST = 28480305154918594
    DOC_ID_QUERY_ME = 26147971811524376
    DOC_ID_QUERY_MPS_REQUEST = 8119818841375479

    def test_doc_ids_are_integers(self) -> None:
        """
        Test that document IDs are integers.

        Arrange: Document ID constants.
        Act: Check types.
        Assert: All are integers.
        """
        self.assertIsInstance(self.DOC_ID_SUBMIT_MPS_REQUEST, int)
        self.assertIsInstance(self.DOC_ID_QUERY_ME, int)
        self.assertIsInstance(self.DOC_ID_QUERY_MPS_REQUEST, int)

    def test_doc_ids_are_positive(self) -> None:
        """
        Test that document IDs are positive.

        Arrange: Document ID constants.
        Act: Check values.
        Assert: All are positive.
        """
        self.assertGreater(self.DOC_ID_SUBMIT_MPS_REQUEST, 0)
        self.assertGreater(self.DOC_ID_QUERY_ME, 0)
        self.assertGreater(self.DOC_ID_QUERY_MPS_REQUEST, 0)


class TestGqlUrlConstant(unittest.TestCase):
    """Tests for GraphQL URL constant."""

    GQL_URL = "https://graph.oculus.com/graphql"

    def test_gql_url_is_https(self) -> None:
        """
        Test that GraphQL URL uses HTTPS.

        Arrange: GQL_URL constant.
        Act: Check URL scheme.
        Assert: URL starts with https.
        """
        self.assertTrue(self.GQL_URL.startswith("https://"))

    def test_gql_url_ends_with_graphql(self) -> None:
        """
        Test that GraphQL URL ends with /graphql.

        Arrange: GQL_URL constant.
        Act: Check URL path.
        Assert: URL ends with /graphql.
        """
        self.assertTrue(self.GQL_URL.endswith("/graphql"))


class TestSubmitRequestPayload(unittest.TestCase):
    """Tests for submit request payload formatting."""

    KEY_NAME = "name"
    KEY_RECORDINGS = "recordings"
    KEY_FEATURES = "features"
    KEY_SOURCE = "source"
    KEY_PERSIST_ON_FAILURE = "persist_on_failure"
    KEY_DEVICE_TYPE = "device_type"

    def test_payload_includes_all_required_fields(self) -> None:
        """
        Test that submit request payload includes all required fields.

        Arrange: Create payload with all required fields.
        Act: Check field presence.
        Assert: All required fields present.
        """
        payload = {
            self.KEY_NAME: "test_request",
            self.KEY_RECORDINGS: [123, 456],
            self.KEY_FEATURES: ["SLAM"],
            self.KEY_SOURCE: "MPS_CLI",
            self.KEY_PERSIST_ON_FAILURE: True,
            self.KEY_DEVICE_TYPE: "ARIA_GEN1",
        }

        self.assertIn(self.KEY_NAME, payload)
        self.assertIn(self.KEY_RECORDINGS, payload)
        self.assertIn(self.KEY_FEATURES, payload)
        self.assertIn(self.KEY_SOURCE, payload)
        self.assertIn(self.KEY_PERSIST_ON_FAILURE, payload)
        self.assertIn(self.KEY_DEVICE_TYPE, payload)

    def test_recordings_is_list(self) -> None:
        """
        Test that recordings field is a list.

        Arrange: Create payload.
        Act: Check recordings type.
        Assert: Recordings is a list.
        """
        payload = {self.KEY_RECORDINGS: [123, 456]}

        self.assertIsInstance(payload[self.KEY_RECORDINGS], list)

    def test_features_is_list(self) -> None:
        """
        Test that features field is a list.

        Arrange: Create payload.
        Act: Check features type.
        Assert: Features is a list.
        """
        payload = {self.KEY_FEATURES: ["SLAM", "EYE_GAZE"]}

        self.assertIsInstance(payload[self.KEY_FEATURES], list)


class TestQueryPagination(unittest.TestCase):
    """Tests for query pagination constants and logic."""

    QUERY_DEFAULT_PAGE_SIZE = 1000

    def test_default_page_size_is_reasonable(self) -> None:
        """
        Test that default page size is reasonable.

        Arrange: QUERY_DEFAULT_PAGE_SIZE constant.
        Act: Check value.
        Assert: Page size is between 100 and 10000.
        """
        self.assertGreaterEqual(self.QUERY_DEFAULT_PAGE_SIZE, 100)
        self.assertLessEqual(self.QUERY_DEFAULT_PAGE_SIZE, 10000)

    def test_pagination_variables(self) -> None:
        """
        Test pagination variable structure.

        Arrange: Create pagination variables.
        Act: Check structure.
        Assert: Contains page_size and cursor.
        """
        variables = {
            "page_size": self.QUERY_DEFAULT_PAGE_SIZE,
            "cursor": None,
        }

        self.assertIn("page_size", variables)
        self.assertIn("cursor", variables)


if __name__ == "__main__":
    unittest.main()
