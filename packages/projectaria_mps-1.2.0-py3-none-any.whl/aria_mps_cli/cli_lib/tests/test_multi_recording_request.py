# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unit tests for multi_recording_request.py

Tests cover:
- MultiRecordingRequest.States enum values
- State machine transitions
- Output mapping file handling
- Error code handling for multiple recordings
- Device consistency checks
"""

import json
import tempfile
import unittest
from enum import auto, Enum, unique
from pathlib import Path
from typing import Any, Dict, Final, List, Mapping, Optional, Set


class MpsFeature(Enum):
    """Local copy of MpsFeature to avoid Config initialization."""

    SLAM = "SLAM"
    EYE_GAZE = "EYE_GAZE"
    HAND_TRACKING = "HAND_TRACKING"
    MULTI_SLAM = "MULTI_SLAM"


class MpsAriaDevice(Enum):
    """Local copy of MpsAriaDevice."""

    ARIA_GEN1 = "ARIA_GEN1"
    ARIA_GEN2 = "ARIA_GEN2"
    UNKNOWN = "UNKNOWN"


class DisplayStatus(Enum):
    """Local copy of DisplayStatus."""

    CREATED = "CREATED"
    HASHING = "HASHING"
    CHECKING = "CHECKING"
    HEALTHCHECK = "HEALTHCHECK"
    ENCRYPTING = "ENCRYPTING"
    UPLOADING = "UPLOADING"
    SUBMITTING = "SUBMITTING"
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"


class ErrorCode:
    """Local copy of ErrorCode constants."""

    HEALTH_CHECK_FAILURE = 101
    HASH_COMPUTATION_FAILURE = 102
    ENCRYPTION_FAILURE = 103
    UPLOAD_FAILURE = 104
    GRAPHQL_FAILURE = 105
    PAST_OUTPUT_CHECK_FAILURE = 106
    PAST_REQUEST_CHECK_FAILURE = 107
    INPUT_OUTPUT_MISMATCH_FAILURE = 108
    NON_EMPTY_OUTPUT_DIR_FAILURE = 109
    DUPLICATE_RECORDING_FAILURE = 110
    MIXED_DEVICE_GENERATION_FAILURE = 111
    SOMETHING_ELSE_FAILURE = 999


@unique
class States(Enum):
    """Local copy of MultiRecordingRequest.States."""

    CREATED = auto()
    DEVICE_TYPE_CHECK = auto()
    DEVICE_CONSISTENCY_CHECK = auto()
    PAST_OUTPUTS_CHECK = auto()
    HASH_COMPUTATION = auto()
    PAST_REQUESTS_CHECK = auto()
    VALIDATION = auto()
    UPLOAD = auto()
    SUBMIT = auto()

    SUCCESS_PAST_OUTPUT = auto()
    SUCCESS_NEW_REQUEST = auto()
    SUCCESS_PAST_REQUEST = auto()

    FAILURE = auto()


TRANSITIONS: Final[List[List[Any]]] = [
    ["next", "*", States.FAILURE, "has_error"],
    ["start", States.CREATED, States.FAILURE, "has_error"],
    ["start", States.CREATED, States.DEVICE_TYPE_CHECK],
    ["next", States.DEVICE_TYPE_CHECK, States.DEVICE_CONSISTENCY_CHECK],
    ["next", States.DEVICE_CONSISTENCY_CHECK, States.PAST_OUTPUTS_CHECK],
    ["next", States.PAST_OUTPUTS_CHECK, States.HASH_COMPUTATION],
    ["next", States.HASH_COMPUTATION, States.PAST_REQUESTS_CHECK],
    ["next", States.PAST_REQUESTS_CHECK, States.VALIDATION],
    ["next", States.VALIDATION, States.UPLOAD],
    ["finish", States.PAST_OUTPUTS_CHECK, States.SUCCESS_PAST_OUTPUT],
    ["finish", States.PAST_REQUESTS_CHECK, States.SUCCESS_PAST_REQUEST],
    ["finish", States.UPLOAD, States.SUCCESS_NEW_REQUEST],
]


_VRS_TO_MULTI_SLAM_JSON: str = "vrs_to_multi_slam.json"
_SLAM: str = "slam"


class ModelState:
    """Local copy of ModelState."""

    __slots__ = ("status", "progress", "error_code")

    def __init__(
        self,
        status: DisplayStatus = DisplayStatus.CREATED,
        progress: float = 0,
        error_code: Optional[str] = None,
    ) -> None:
        self.status = status
        self.progress = progress
        self.error_code = error_code


def load_or_create_output_mapping(
    output_dir: Path, recordings: Set[Path]
) -> Mapping[Path, str]:
    """
    Load existing output mapping from disk or create a new one.

    Simplified version of MultiRecordingModel._load_or_create_output_mapping().
    """
    output_mapping_path: Path = output_dir / _VRS_TO_MULTI_SLAM_JSON
    output_mapping: Dict[Path, str] = {}

    if output_mapping_path.exists():
        with open(output_mapping_path, "r") as fp:
            output_mapping = {Path(k): v for k, v in json.load(fp).items()}
    else:
        for i, rec in enumerate(sorted(recordings)):
            output_mapping[rec] = str(i)

        with open(output_mapping_path, "w") as fp:
            json.dump({str(k): v for k, v in output_mapping.items()}, fp, indent=2)

    return output_mapping


def check_device_consistency(
    recordings_devices: Dict[Path, MpsAriaDevice],
) -> Optional[int]:
    """
    Check that all recordings are from the same device generation.

    Returns error code if mixed, None if consistent.
    """
    device_types = {d for d in recordings_devices.values() if d is not None}
    if len(device_types) > 1:
        return ErrorCode.MIXED_DEVICE_GENERATION_FAILURE
    return None


class TestMultiStatesEnum(unittest.TestCase):
    """Tests for MultiRecordingRequest.States enum."""

    def test_states_count(self) -> None:
        """
        Test that States enum has expected number of states.

        Arrange: No setup needed
        Act: Count states in enum
        Assert: Count matches expected (13 states)
        """
        # Arrange - none needed

        # Act
        count = len(States)

        # Assert
        self.assertEqual(count, 13)

    def test_created_is_initial_state(self) -> None:
        """
        Test that CREATED state exists.

        Arrange: No setup needed
        Act: Access CREATED state
        Assert: State exists
        """
        # Arrange - none needed

        # Act
        state = States.CREATED

        # Assert
        self.assertIsNotNone(state)

    def test_device_consistency_check_exists(self) -> None:
        """
        Test that DEVICE_CONSISTENCY_CHECK state exists.

        Arrange: No setup needed
        Act: Access state
        Assert: State exists
        """
        # Arrange - none needed

        # Act
        state = States.DEVICE_CONSISTENCY_CHECK

        # Assert
        self.assertIsNotNone(state)


class TestMultiTransitions(unittest.TestCase):
    """Tests for state machine transitions."""

    def test_transitions_is_list(self) -> None:
        """
        Test that TRANSITIONS is a list.

        Arrange: No setup needed
        Act: Check type
        Assert: Is list
        """
        # Arrange - none needed

        # Act
        result = isinstance(TRANSITIONS, list)

        # Assert
        self.assertTrue(result)

    def test_start_transitions_with_error_check(self) -> None:
        """
        Test that start has both error and normal transitions.

        Arrange: No setup needed
        Act: Find start transitions
        Assert: Both exist with correct conditions
        """
        # Arrange - none needed

        # Act
        start_transitions = [t for t in TRANSITIONS if t[0] == "start"]

        # Assert
        self.assertEqual(len(start_transitions), 2)

    def test_device_consistency_transition(self) -> None:
        """
        Test transition from DEVICE_TYPE_CHECK to DEVICE_CONSISTENCY_CHECK.

        Arrange: No setup needed
        Act: Find transition
        Assert: Transition exists
        """
        # Arrange - none needed

        # Act
        transitions = [
            t
            for t in TRANSITIONS
            if t[1] == States.DEVICE_TYPE_CHECK
            and t[2] == States.DEVICE_CONSISTENCY_CHECK
        ]

        # Assert
        self.assertEqual(len(transitions), 1)


class TestOutputMapping(unittest.TestCase):
    """Tests for output mapping functionality."""

    def setUp(self) -> None:
        """Set up temp directory for tests."""
        self._temp_dir = tempfile.mkdtemp()
        self._output_dir = Path(self._temp_dir)

    def test_create_new_mapping(self) -> None:
        """
        Test creating a new output mapping.

        Arrange: Create recordings set
        Act: Call load_or_create_output_mapping
        Assert: Mapping is created with numbered entries
        """
        # Arrange
        recordings = {Path("/data/rec1.vrs"), Path("/data/rec2.vrs")}

        # Act
        mapping = load_or_create_output_mapping(self._output_dir, recordings)

        # Assert
        self.assertEqual(len(mapping), 2)
        self.assertIn("0", mapping.values())
        self.assertIn("1", mapping.values())

    def test_mapping_file_created(self) -> None:
        """
        Test that mapping file is created on disk.

        Arrange: Create recordings set
        Act: Call load_or_create_output_mapping
        Assert: JSON file exists
        """
        # Arrange
        recordings = {Path("/data/rec1.vrs")}

        # Act
        load_or_create_output_mapping(self._output_dir, recordings)

        # Assert
        mapping_path = self._output_dir / _VRS_TO_MULTI_SLAM_JSON
        self.assertTrue(mapping_path.exists())

    def test_load_existing_mapping(self) -> None:
        """
        Test loading an existing mapping file.

        Arrange: Create a mapping file
        Act: Call load_or_create_output_mapping
        Assert: Existing mapping is returned
        """
        # Arrange
        mapping_path = self._output_dir / _VRS_TO_MULTI_SLAM_JSON
        existing_mapping = {"/data/rec1.vrs": "output_1"}
        with open(mapping_path, "w") as fp:
            json.dump(existing_mapping, fp)
        recordings = {Path("/data/rec1.vrs")}

        # Act
        mapping = load_or_create_output_mapping(self._output_dir, recordings)

        # Assert
        self.assertEqual(mapping[Path("/data/rec1.vrs")], "output_1")


class TestDeviceConsistencyCheck(unittest.TestCase):
    """Tests for device consistency validation."""

    def test_consistent_gen1_devices(self) -> None:
        """
        Test that all Gen1 devices are consistent.

        Arrange: Create recordings with Gen1 devices
        Act: Check consistency
        Assert: No error returned
        """
        # Arrange
        devices = {
            Path("/data/rec1.vrs"): MpsAriaDevice.ARIA_GEN1,
            Path("/data/rec2.vrs"): MpsAriaDevice.ARIA_GEN1,
        }

        # Act
        result = check_device_consistency(devices)

        # Assert
        self.assertIsNone(result)

    def test_consistent_gen2_devices(self) -> None:
        """
        Test that all Gen2 devices are consistent.

        Arrange: Create recordings with Gen2 devices
        Act: Check consistency
        Assert: No error returned
        """
        # Arrange
        devices = {
            Path("/data/rec1.vrs"): MpsAriaDevice.ARIA_GEN2,
            Path("/data/rec2.vrs"): MpsAriaDevice.ARIA_GEN2,
        }

        # Act
        result = check_device_consistency(devices)

        # Assert
        self.assertIsNone(result)

    def test_mixed_devices_returns_error(self) -> None:
        """
        Test that mixed Gen1/Gen2 devices return error.

        Arrange: Create recordings with mixed devices
        Act: Check consistency
        Assert: Error code is returned
        """
        # Arrange
        devices = {
            Path("/data/rec1.vrs"): MpsAriaDevice.ARIA_GEN1,
            Path("/data/rec2.vrs"): MpsAriaDevice.ARIA_GEN2,
        }

        # Act
        result = check_device_consistency(devices)

        # Assert
        self.assertEqual(result, ErrorCode.MIXED_DEVICE_GENERATION_FAILURE)

    def test_single_device_is_consistent(self) -> None:
        """
        Test that single device is always consistent.

        Arrange: Create single recording
        Act: Check consistency
        Assert: No error returned
        """
        # Arrange
        devices = {Path("/data/rec1.vrs"): MpsAriaDevice.ARIA_GEN1}

        # Act
        result = check_device_consistency(devices)

        # Assert
        self.assertIsNone(result)


class TestMultiErrorCodes(unittest.TestCase):
    """Tests for multi-recording specific error codes."""

    def test_input_output_mismatch_error(self) -> None:
        """
        Test INPUT_OUTPUT_MISMATCH_FAILURE error code.

        Arrange: No setup needed
        Act: Access error code
        Assert: Code has expected value
        """
        # Arrange - none needed

        # Act
        result = ErrorCode.INPUT_OUTPUT_MISMATCH_FAILURE

        # Assert
        self.assertEqual(result, 108)

    def test_non_empty_output_dir_error(self) -> None:
        """
        Test NON_EMPTY_OUTPUT_DIR_FAILURE error code.

        Arrange: No setup needed
        Act: Access error code
        Assert: Code has expected value
        """
        # Arrange - none needed

        # Act
        result = ErrorCode.NON_EMPTY_OUTPUT_DIR_FAILURE

        # Assert
        self.assertEqual(result, 109)

    def test_duplicate_recording_error(self) -> None:
        """
        Test DUPLICATE_RECORDING_FAILURE error code.

        Arrange: No setup needed
        Act: Access error code
        Assert: Code has expected value
        """
        # Arrange - none needed

        # Act
        result = ErrorCode.DUPLICATE_RECORDING_FAILURE

        # Assert
        self.assertEqual(result, 110)

    def test_something_else_failure(self) -> None:
        """
        Test SOMETHING_ELSE_FAILURE as fallback error.

        Arrange: No setup needed
        Act: Access error code
        Assert: Code has expected value
        """
        # Arrange - none needed

        # Act
        result = ErrorCode.SOMETHING_ELSE_FAILURE

        # Assert
        self.assertEqual(result, 999)


class TestMultiModelState(unittest.TestCase):
    """Tests for model state in multi-recording context."""

    def test_created_status_for_new_model(self) -> None:
        """
        Test that new model has CREATED status.

        Arrange: Create ModelState with defaults
        Act: Check status
        Assert: Status is CREATED
        """
        # Arrange
        state = ModelState()

        # Act
        result = state.status

        # Assert
        self.assertEqual(result, DisplayStatus.CREATED)

    def test_error_status_includes_error_code(self) -> None:
        """
        Test that error state includes error code.

        Arrange: Create ModelState with error
        Act: Check error_code
        Assert: Error code is set
        """
        # Arrange
        state = ModelState(
            status=DisplayStatus.ERROR,
            error_code=str(ErrorCode.SOMETHING_ELSE_FAILURE),
        )

        # Act
        result = state.error_code

        # Assert
        self.assertEqual(result, "999")


class TestConstants(unittest.TestCase):
    """Tests for module constants."""

    def test_vrs_to_multi_slam_json_constant(self) -> None:
        """
        Test VRS_TO_MULTI_SLAM_JSON filename constant.

        Arrange: No setup needed
        Act: Check constant
        Assert: Value is correct
        """
        # Arrange - none needed

        # Act
        result = _VRS_TO_MULTI_SLAM_JSON

        # Assert
        self.assertEqual(result, "vrs_to_multi_slam.json")

    def test_slam_constant(self) -> None:
        """
        Test SLAM directory name constant.

        Arrange: No setup needed
        Act: Check constant
        Assert: Value is "slam"
        """
        # Arrange - none needed

        # Act
        result = _SLAM

        # Assert
        self.assertEqual(result, "slam")


if __name__ == "__main__":
    unittest.main()
