"""Knowledge backend adapter protocol and built-in implementations.

Defines a standard interface for knowledge base backends so the kanban
framework can switch between different storage engines (SQLite FTS5,
LightRAG, KAG, etc.) without changing agent prompts or CLI commands.
"""

from __future__ import annotations
from typing import Protocol, runtime_checkable


@runtime_checkable
class KnowledgeBackend(Protocol):
    """Protocol that all knowledge backend adapters must implement.

    Returns list[dict] for all search methods so backends can use
    any storage engine — SQLite, Qdrant, Neo4j, plain files, etc.
    """

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        """Full-text keyword search. Returns [{id, title, content, score, ...}]."""
        ...

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        """Semantic (vector embedding) search."""
        ...

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        """Hybrid search combining keyword and semantic results."""
        ...

    def add_entry(self, **kwargs) -> dict:
        """Add a knowledge entry. Returns the created entry dict."""
        ...

    def list_entries(
        self, domain: str | None = None, category: str | None = None,
        status: str = "active", limit: int = 50, offset: int = 0,
    ) -> list[dict]:
        """List entries with optional filters."""
        ...

    def get_entry(self, entry_id: str) -> dict | None:
        """Get a single entry by ID, or None if not found."""
        ...


class BuiltinBackend:
    """Adapter wrapping the existing KnowledgeManager's storage methods.

    This is the default backend. It delegates to KnowledgeManager's
    internal methods so existing knowledge.db data is preserved unchanged.
    """

    def __init__(self, knowledge_manager):
        self._km = knowledge_manager

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        return self._km._search_fts(keyword, limit=limit)

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        return self._km._search_semantic(query, limit=limit)

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        return self._km._search_hybrid(keyword, limit=limit)

    def add_entry(self, **kwargs) -> dict:
        return self._km._add_entry_internal(**kwargs)

    def list_entries(
        self, domain: str | None = None, category: str | None = None,
        status: str = "active", limit: int = 50, offset: int = 0,
    ) -> list[dict]:
        return self._km._list_entries_internal(
            domain=domain, category=category, status=status,
            limit=limit, offset=offset,
        )

    def get_entry(self, entry_id: str) -> dict | None:
        return self._km._get_entry_internal(entry_id)


class MemoryBackend:
    """In-memory dict backend for testing and protocol validation.

    Zero dependencies, zero persistence. Proves the middleware abstraction
    works by demonstrating that any backend with 6 methods is pluggable.
    """

    def __init__(self):
        self._entries: dict[str, dict] = {}

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        kw = keyword.lower()
        results = []
        for e in self._entries.values():
            if kw in e.get("title", "").lower() or kw in e.get("content", "").lower():
                e["score"] = 0.5
                results.append(e)
        return results[:limit]

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        return self.search(query, limit=limit)

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        return self.search(keyword, limit=limit)

    def add_entry(self, **kwargs) -> dict:
        eid = kwargs.get("id", str(len(self._entries) + 1))
        self._entries[eid] = dict(kwargs)
        return self._entries[eid]

    def list_entries(self, domain=None, category=None, status="active",
                     limit=50, offset=0) -> list[dict]:
        results = list(self._entries.values())
        if domain:
            results = [e for e in results if e.get("domain") == domain]
        if category:
            results = [e for e in results if e.get("category") == category]
        return results[offset:offset + limit]

    def get_entry(self, entry_id: str) -> dict | None:
        return self._entries.get(entry_id)


class ChromaDBBackend:
    """Pure ChromaDB vector backend — demonstrates alternative retrieval.

    Uses ChromaDB for all search (semantic + keyword via metadata filtering).
    No SQLite FTS5 dependency. Shows that the same kanban entries can be
    searched with different retrieval strategies.
    """

    def __init__(self, knowledge_manager):
        self._km = knowledge_manager  # reuse existing ChromaDB connection + embedding

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        return self._km._search_fts(keyword, limit=limit)

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        return self._km._search_semantic(query, limit=limit)

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        # ChromaDB-first: semantic with metadata fallback
        results = self.search_semantic(keyword, limit=limit * 2)
        if not results:
            results = self.search(keyword, limit=limit)
        return results[:limit]

    def add_entry(self, **kwargs) -> dict:
        return self._km._add_entry_internal(**kwargs)

    def list_entries(self, domain=None, category=None, status="active",
                     limit=50, offset=0) -> list[dict]:
        return self._km._list_entries_internal(
            domain=domain, category=category, status=status,
            limit=limit, offset=offset)

    def get_entry(self, entry_id: str) -> dict | None:
        return self._km._get_entry_internal(entry_id)


# Registry of available backends
BACKEND_REGISTRY = {
    "builtin": BuiltinBackend,
    "memory": MemoryBackend,
    "chromadb": ChromaDBBackend,
}


def resolve_backend(name: str, knowledge_manager):
    """Resolve a backend name to an instance. Falls back to builtin."""
    cls = BACKEND_REGISTRY.get(name)
    if cls is None:
        import warnings
        warnings.warn(f"Unknown knowledge backend '{name}', falling back to builtin")
        cls = BuiltinBackend
    if cls is MemoryBackend:
        return cls()
    return cls(knowledge_manager)
