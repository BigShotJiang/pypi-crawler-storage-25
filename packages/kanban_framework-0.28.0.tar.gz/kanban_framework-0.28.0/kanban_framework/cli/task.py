from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
from kanban_framework.infra.filesystem import Filesystem
from kanban_framework.infra.config import Config
from kanban_framework.domain.task import TaskManager, TaskNotFoundError
from kanban_framework.domain.scanner import scan_project, ScanReport, generate_default_test_profile
from kanban_framework.infra.scheduler import Scheduler


def _resolve() -> tuple[Filesystem, Config, TaskManager]:
    root = Filesystem.find_project_root()
    fs = Filesystem(root=root)
    cfg = Config(fs)
    return fs, cfg, TaskManager(fs, cfg)


def _serialize_report(report: ScanReport) -> dict:
    return {
        "project_root": report.project_root,
        "language": report.language,
        "has_kanban": report.has_kanban,
        "agent_conflicts": [
            {
                "role": c.role,
                "kanban_agent": c.kanban_agent,
                "project_file": c.project_agent_file,
                "action": c.action,
                "description": c.description,
            }
            for c in report.agent_conflicts
        ],
        "existing_skills": report.existing_skills,
        "infrastructure_gaps": [
            {
                "category": g.category,
                "tool": g.tool,
                "detected": g.detected,
                "suggestion": g.suggestion,
            }
            for g in report.infrastructure_gaps
        ],
        "skill_gaps": [
            {
                "skill_name": g.skill_name,
                "required_by": g.required_by,
                "suggestion": g.suggestion,
            }
            for g in report.skill_gaps
        ],
        "recommendations": report.recommendations,
    }


def _check_kb_deps() -> dict:
    """Check knowledge base dependency availability."""
    missing = []
    available = []
    try:
        import jieba
        available.append("jieba (中文分词)")
    except ImportError:
        missing.append("jieba (中文分词)")
    try:
        import chromadb
        available.append("chromadb (语义搜索)")
    except ImportError:
        missing.append("chromadb (语义搜索)")
    try:
        from fastembed import TextEmbedding
        available.append("fastembed (向量嵌入)")
    except ImportError:
        missing.append("fastembed (向量嵌入)")
    # CodeBurn (token analytics)
    try:
        import shutil
        cb = shutil.which("codeburn") or shutil.which("npx")
        if cb:
            available.append("codeburn (token 分析)")
        else:
            missing.append("codeburn (token 分析)")
    except Exception:
        missing.append("codeburn (token 分析)")
    return {
        "available": available,
        "missing": missing,
        "status": "ready" if not missing else "incomplete",
        "install_hint": _install_hint(missing) if missing else None,
    }


def _install_hint(missing: list[str]) -> str:
    if "codeburn" in " ".join(missing):
        return "npm install -g codeburn"
    return "pip install kanban-framework"


def cmd_init(args: list[str]) -> dict:
    clean_orphaned = "--clean-orphaned" in args
    apply_updates = "--apply" in args

    fs, _, _ = _resolve()
    root = Filesystem.find_project_root()

    # Ensure .kanban/ directory structure exists (fix #80)
    required_dirs = [
        fs.kanban_dir,
        fs.kanban_dir / "tasks",
        fs.kanban_dir / "archive",
        fs.kanban_dir / "inbox",
        fs.kanban_dir / "reports",
        fs.kanban_dir / "dashboard",
        fs.kanban_dir / "skills" / "evolved",
    ]
    created = []
    for d in required_dirs:
        if not d.exists():
            d.mkdir(parents=True)
            created.append(str(d.relative_to(root)))

    # Sync skill files to .claude/skills/kanban/ (SKILL.md, agents, rules, references)
    from kanban_framework.infra.filesystem import Filesystem as FS
    skill_src = FS.find_skill_dir()
    skill_dst = root / ".claude" / "skills" / "kanban"
    updated: list[str] = []
    added: list[str] = []
    stale: list[str] = []
    pending_updates: list[str] = []

    def _sync_file(src: Path, dst: Path) -> None:
        rel = str(dst.relative_to(root))
        if not dst.exists():
            fs.ensure_dir(dst.parent)
            dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
            added.append(rel)
        elif dst.read_text(encoding="utf-8") != src.read_text(encoding="utf-8"):
            if apply_updates:
                dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
                updated.append(rel)
            else:
                pending_updates.append(rel)

    def _sync_dir(src_dir: Path, dst_dir: Path) -> None:
        if not dst_dir.exists():
            import shutil
            shutil.copytree(str(src_dir), str(dst_dir))
            added.append(str(dst_dir.relative_to(root)))
            return
        for src_file in sorted(src_dir.rglob("*")):
            if src_file.is_file():
                rel_p = src_file.relative_to(src_dir)
                dst_file = dst_dir / rel_p
                _sync_file(src_file, dst_file)
        # Detect stale files (exist in dst but not in src)
        for dst_file in sorted(dst_dir.rglob("*")):
            if dst_file.is_file():
                rel_p = dst_file.relative_to(dst_dir)
                if not (src_dir / rel_p).exists():
                    stale.append(str(dst_file.relative_to(root)))

    for sub in ["SKILL.md", "agents", "rules", "references", "versions"]:
        src = skill_src / sub
        dst = skill_dst / sub
        if src.is_dir():
            _sync_dir(src, dst)
        elif src.is_file():
            _sync_file(src, dst)

    created = added + updated

    # Detect stale symlinks from .claude/agents/ and .claude/rules/
    # (created by older init versions — waste context in non-kanban sessions)
    orphaned_links: list[str] = []
    for sub_dir, sub_skill in [("agents", "agents"), ("rules", "rules")]:
        claude_dir = root / ".claude" / sub_dir
        skill_sub = skill_dst / sub_skill
        if claude_dir.is_dir() and skill_sub.is_dir():
            # Match against actual skill files (not just kanban- prefix)
            known_files = {f.name for f in skill_sub.glob("*.md")}
            for link in sorted(claude_dir.glob("*.md")):
                if link.is_symlink() and link.name in known_files:
                    if clean_orphaned:
                        link.unlink()
                    else:
                        orphaned_links.append(str(link.relative_to(root)))

    # Ensure config.json exists
    config_file = fs.config_file()
    if not fs.file_exists(config_file):
        import sys
        python_bin = sys.executable
        fs.write_json(config_file, {
            "output_dir": "src",
            "max_iterations": 6,
            "pass_threshold": 8.0,
            "python_bin": python_bin,
        })
        created.append(str(config_file.relative_to(root)))

    # Ensure workflow.json exists (use embedded default, no file dependency)
    workflow_file = fs.workflow_file()
    if not fs.file_exists(workflow_file):
        from kanban_framework.infra.consts import DEFAULT_WORKFLOW
        template = json.loads(DEFAULT_WORKFLOW)
        fs.write_json(workflow_file, template)
        created.append(str(workflow_file.relative_to(root)))

    # Generate test_profile.md if not exists
    test_profile_path = fs.kanban_dir / "test_profile.md"
    if not fs.file_exists(test_profile_path):
        lang = "python"  # default before scan
        cfg = fs.read_json(config_file) if fs.file_exists(config_file) else {}
        out_dir = cfg.get("output_dir", "src")
        content = generate_default_test_profile(lang, out_dir, root)
        test_profile_path.write_text(content, encoding="utf-8")
        created.append(str(test_profile_path.relative_to(root)))

    report = None
    scan_error = None
    try:
        report = scan_project(root)
    except Exception as e:
        scan_error = str(e)

    # Read output_dir from config (may have just been created)
    config = {}
    if fs.file_exists(config_file):
        config = fs.read_json(config_file)
    output_dir = config.get("output_dir", "src")

    # Persist detected language to config
    if report is not None:
        current_lang = config.get("language", "unknown")
        detected_lang = report.language
        if current_lang != detected_lang:
            config["language"] = detected_lang
            fs.write_json(config_file, config)

    result = {
        "message": "kanban env ready",
        "kanban_dir": str(fs.kanban_dir),
        "created": created,
        "sync": {
            "added": added,
            "updated": updated,
            "stale": stale,
            "pending_updates": pending_updates,
        },
        "orphaned_links": orphaned_links,
        "language": report.language if report else "unknown",
    }
    if stale:
        result["message"] += f" ({len(stale)} stale files detected, review before removing)"
    if pending_updates:
        result["message"] += f" ({len(pending_updates)} files have updates — review and run kanban init --apply)"

    # Check if pip install is needed (npx users may not have pip package)
    try:
        import kanban_framework
        core_file = getattr(core, "__file__", "")
        if core_file and "site-packages" not in core_file and ".claude/skills" in core_file:
            result["pip_warning"] = (
                "检测到 npx 安装（技能文件在 .claude/skills/），"
                "但 kanban-framework pip 包未找到。"
                "运行: pip install kanban-framework"
            )
    except Exception:
        pass

    # Check if output_dir is in .gitignore
    gitignore_path = os.path.join(str(root), ".gitignore")
    if os.path.exists(gitignore_path):
        with open(gitignore_path, encoding="utf-8") as f:
            gitignore_content = f.read()
        for line in gitignore_content.splitlines():
            line = line.strip()
            if line in (f"{output_dir}/", output_dir, f"/{output_dir}/", f"/{output_dir}"):
                result["gitignore_warning"] = (
                    f"output_dir '{output_dir}' is in .gitignore. "
                    f"Use 'git add -f' to add files in that directory."
                )
                break

    # Detect E2E test recommendation for orchestrator display
    if report is not None:
        from kanban_framework.domain.scanner import detect_e2e_recommendation
        e2e_rec = detect_e2e_recommendation(report.language, root)
        result["test_strategy"] = {
            "e2e_enabled": True,
            "e2e_tool": e2e_rec["e2e_tool"],
            "e2e_target": e2e_rec["test_target"],
        }

    if report is not None:
        result["scan"] = _serialize_report(report)
    else:
        result["scan"] = {
            "error": scan_error or "scan failed",
            "recommendations": [],
        }

    # Check if .kanban/ is globally gitignored (blocks phase checkpoints)
    gitignore_path = root / ".gitignore"
    if gitignore_path.exists():
        lines = gitignore_path.read_text(encoding="utf-8").splitlines()
        for line in lines:
            if line.strip() == ".kanban/":
                result["gitignore_warning"] = (
                    ".gitignore 中 '.kanban/' 排除了整个目录，task 数据无法 git 追踪。"
                    "建议改为只排除运行时目录: .kanban/dashboard/ .kanban/reports/ .kanban/skills/"
                )
                break

    # Suggest SessionStart hook for auto kanban context
    settings_path = root / ".claude" / "settings.json"
    hook_configured = False
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
            hooks = settings.get("hooks", {})
            for h in hooks.get("SessionStart", []):
                if "kanban hook" in h.get("command", ""):
                    hook_configured = True
                    break
        except Exception:
            pass
    if not hook_configured:
        result["hook_suggestion"] = {
            "message": "建议配置 SessionStart hook，在每次会话启动时自动注入 kanban 任务上下文",
            "command": 'kanban hook install',
            "description": "运行后 .claude/settings.json 会自动添加 hook，之后每次新会话模型都能看到当前任务状态",
        }

    # Check knowledge base dependencies (includes codeburn)
    result["kb_deps"] = _check_kb_deps()

    return result


def cmd_install_codeburn(args: list[str]) -> dict:
    """Install CodeBurn globally via npm."""
    import subprocess, shutil
    if shutil.which("codeburn"):
        return {"installed": True, "message": "codeburn already installed"}
    try:
        result = subprocess.run(
            ["npm", "install", "-g", "codeburn"],
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120
        )
        if result.returncode == 0:
            return {"installed": True, "message": "codeburn installed successfully"}
        return {"installed": False, "error": result.stderr.strip()}
    except Exception as e:
        return {"installed": False, "error": str(e)}


def cmd_scan(args: list[str]) -> dict:
    """Explicit scan command for debugging/testing."""
    root = Filesystem.find_project_root()
    report = scan_project(root)
    return _serialize_report(report)


def cmd_create(args: list[str]) -> dict:
    from kanban_framework.types import AutoMode

    # Scan for --control-mode and legacy --mode manual before argparse
    control_mode = None
    filtered_args: list[str] = []
    skip_next = False
    for i, arg in enumerate(args):
        if skip_next:
            skip_next = False
            continue
        if arg == "--control-mode" and i + 1 < len(args):
            value = args[i + 1]
            if value in ("auto", "semi", "manual"):
                control_mode = value
            skip_next = True
            continue
        if arg == "--mode" and i + 1 < len(args):
            if args[i + 1] == "manual":
                control_mode = "manual"
                skip_next = True
                continue
        filtered_args.append(arg)

    parser = argparse.ArgumentParser(prog="kanban create", add_help=False)
    parser.add_argument("title", nargs="*", default=[], help="Task title")
    parser.add_argument("--desc", nargs="*", default=[], help="Task description")
    parser.add_argument("--mode", type=str, default=None, choices=["full", "lightweight", "custom"],
                        help="Task mode: full, lightweight, or custom")
    parser.add_argument("--lightweight", action="store_true", default=False,
                        help="Shorthand for --mode lightweight")
    parser.add_argument("--auto-mode", nargs="*", default=[], dest="auto_mode",
                        help="Auto-mode flags: all, brainstorm, iteration, lightweight, archive, worktree")
    parser.add_argument("--priority", type=int, default=5, dest="priority",
                        help="Task priority (0-10, default 5)")
    parser.add_argument("--test-level", type=str, default=None,
                        choices=["full", "quick", "manual"],
                        help="Test verification level: full (test_profile.md), quick (basic tests), manual (verify runs)")
    parser.add_argument("--test-cmd", type=str, default=None, dest="test_cmd",
                        help="Test command (e.g. 'pytest tests/ -v')")
    parser.add_argument("--test-framework", type=str, default=None, dest="test_framework",
                        help="Test framework (e.g. pytest, unittest, jest)")
    parser.add_argument("--coverage", type=str, default=None,
                        help="Coverage target (e.g. '80%')")
    parser.add_argument("--draft", action="store_true", default=False,
                        help="Create as draft placeholder task")

    parsed = parser.parse_args(filtered_args)
    title = " ".join(parsed.title) if parsed.title else "Untitled"
    desc = " ".join(parsed.desc) if parsed.desc else ""
    auto_mode_flags = parsed.auto_mode

    # ── Mode resolution ──
    from kanban_framework.domain.assessment import assess_task
    ai = assess_task(title, desc)

    task_mode = parsed.mode
    is_lightweight = parsed.lightweight
    user_specified_mode = bool(task_mode or is_lightweight)

    if task_mode == "lightweight" or is_lightweight:
        task_mode = "lightweight"
        is_lightweight = True
    # User didn't specify → auto-detect with confirmation prompt
    if task_mode is None:
        task_mode = ai["recommended_mode"]
        is_lightweight = (task_mode == "lightweight")

    # Parse auto_mode flags
    auto_mode = AutoMode()
    if auto_mode_flags:
        if "all" in auto_mode_flags:
            auto_mode = AutoMode(
                auto_brainstorm=True,
                auto_iteration=True,
                auto_lightweight=True,
                auto_archive=True,
                auto_worktree=True,
            )
        else:
            for flag in auto_mode_flags:
                if flag == "brainstorm":
                    auto_mode.auto_brainstorm = True
                elif flag == "iteration":
                    auto_mode.auto_iteration = True
                elif flag == "lightweight":
                    auto_mode.auto_lightweight = True
                elif flag == "archive":
                    auto_mode.auto_archive = True
                elif flag == "worktree":
                    auto_mode.auto_worktree = True

    # ── Test config ──
    test_config = None
    test_level = parsed.test_level
    # Default test level based on mode
    if test_level is None:
        test_level = "quick" if (is_lightweight or task_mode == "lightweight") else "full"

    if parsed.test_cmd or parsed.test_framework or parsed.coverage or test_level != "full":
        test_config = {
            "level": test_level,
        }
        if parsed.test_cmd:
            test_config["command"] = parsed.test_cmd
        if parsed.test_framework:
            test_config["framework"] = parsed.test_framework
        if parsed.coverage:
            test_config["coverage"] = parsed.coverage

    _, _, tm = _resolve()
    priority = max(0, min(10, parsed.priority))

    # Recommend worktree based on task characteristics
    recommendation = _recommend_worktree(title, desc)

    if parsed.draft:
        task = tm.create(title, desc, draft=True)
        tm.update(task.id, priority=priority)
        return {
            "id": task.id,
            "title": task.title,
            "phase": None,
            "status": "draft",
            "auto_mode": None,
            "recommendation": {
                "use_worktree": False,
                "use_lightweight": True,
                "reason": "draft 任务暂不需要隔离工作区，promote 时重新评估",
            },
            "message": f"Draft task {task.id} created. Add requirements via inbox, then promote when ready.",
        }

    # Non-draft: existing logic
    task = tm.create(title, desc)
    update_kwargs: dict = {"phase": "plan", "status": "in_progress",
                            "auto_mode": auto_mode, "priority": priority}
    if is_lightweight:
        update_kwargs["lightweight"] = True
    if task_mode:
        update_kwargs["mode"] = task_mode
    if test_config:
        update_kwargs["test_config"] = test_config
    tm.update(task.id, **update_kwargs)

    if control_mode:
        tm.update(task.id, control_mode=control_mode)

    recommended_mode = "lightweight" if (is_lightweight or recommendation["use_lightweight"]) else "full"
    mode_msg = f"Mode: {recommended_mode}" if task_mode else f"Select mode (full/lightweight/custom) before running"

    return {
        "id": task.id,
        "title": task.title,
        "phase": "plan",
        "status": "in_progress",
        "mode": task_mode or "full",
        "lightweight": is_lightweight,
        "control_mode": control_mode or "semi",
        "assessment": ai,
        "user_specified_mode": user_specified_mode,
        "test_config": test_config,
        "auto_mode": {
            "auto_brainstorm": auto_mode.auto_brainstorm,
            "auto_iteration": auto_mode.auto_iteration,
            "auto_lightweight": auto_mode.auto_lightweight,
            "auto_archive": auto_mode.auto_archive,
            "auto_worktree": auto_mode.auto_worktree,
        },
        "recommendation": recommendation,
        "mode_options": {
            "available": ["full", "lightweight", "custom"],
            "recommended": recommended_mode,
            "custom_phases": [p.value for p in Scheduler.PHASE_ORDER],
            "custom_evaluate_agents": Scheduler.eval_roles(),
        },
        "message": f"Task {task.id} created. {mode_msg}.",
    }


def _recommend_worktree(title: str, desc: str) -> dict:
    """Recommend whether to use git worktree based on task characteristics."""
    text = f"{title} {desc}".lower()

    # Heavy indicators → recommend worktree
    heavy_kw = ["游戏", "game", "web", "dashboard", "前端", "后端", "数据库", "database",
                "重构", "refactor", "迁移", "migration", "多模块", "multi-module",
                "完整项目", "full project", "系统", "system"]
    # Light indicators → recommend lightweight
    light_kw = ["脚本", "script", "工具函数", "utility", "单文件", "single file",
                "修复", "fix", "补丁", "patch", "文档", "doc", "配置", "config"]

    heavy_score = sum(1 for kw in heavy_kw if kw in text)
    light_score = sum(1 for kw in light_kw if kw in text)

    if heavy_score > light_score:
        return {
            "use_worktree": True,
            "use_lightweight": False,
            "reason": f"检测到复杂任务特征（{'/'.join(kw for kw in heavy_kw if kw in text)[:60]}），建议使用 git worktree 隔离开发环境",
        }
    elif light_score > heavy_score:
        return {
            "use_worktree": False,
            "use_lightweight": True,
            "reason": f"检测到简单任务特征（{'/'.join(kw for kw in light_kw if kw in text)[:60]}），轻量模式即可，无需 worktree",
        }
    return {
        "use_worktree": False,
        "use_lightweight": False,
        "reason": "无法自动判断复杂度，建议手动选择是否使用 worktree",
    }


def cmd_status(args: list[str]) -> dict:
    _, _, tm = _resolve()
    return tm.status()


def cmd_show(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id required"}
    _, _, tm = _resolve()
    task = tm.show(args[0])
    return {
        "id": task.id, "title": task.title,
        "description": task.description,
        "status": task.status.value, "phase": task.phase.value,
        "iteration": task.iteration, "priority": task.priority,
    }


def cmd_clean(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id or --all required"}
    fs, _, tm = _resolve()

    if "--all" in args:
        cleaned = []
        for f in sorted(fs.kanban_dir.glob("archive/TASK-*.json")):
            task_id = f.stem
            f.unlink()
            cleaned.append(task_id)
        return {"cleaned": cleaned, "count": len(cleaned)}

    task_id = args[0]
    tm.delete(task_id)
    return {"message": f"cleaned {task_id}"}


def cmd_promote(args: list[str]) -> dict:
    if not args:
        return {"error": "task_id required"}
    _, _, tm = _resolve()
    task_id = args[0]
    task = tm.show(task_id)
    if task.status.value != "draft":
        return {"error": f"Task {task_id} is not in draft status"}

    # Read analysis for suggested phase
    import json
    task_dir = tm._fs.task_dir(task_id)
    analysis_path = task_dir / "inbox_analysis.json"
    suggested_phase = "plan"
    if analysis_path.is_file():
        analysis = json.loads(analysis_path.read_text(encoding="utf-8"))
        suggested_phase = analysis.get("suggested_phase", "plan")

    tm.update(task_id, status="pending", phase=suggested_phase)
    tm.update(task_id, status="in_progress")
    return {
        "task_id": task_id,
        "promoted": True,
        "phase": suggested_phase,
        "message": f"Task {task_id} promoted from draft to {suggested_phase} phase",
    }


def cmd_task(args: list[str]) -> dict:
    """Dispatch: kanban task <subcommand>"""
    if not args:
        return {"error": "subcommand required: edit"}
    sub = args[0]
    if sub == "edit":
        return _cmd_task_edit(args[1:])
    return {"error": f"unknown task subcommand: {sub}"}


def _cmd_task_edit(args: list[str]) -> dict:
    parser = argparse.ArgumentParser(prog="kanban task edit", add_help=False)
    parser.add_argument("task_id")
    parser.add_argument("--mode", type=str, default=None, choices=["full", "lightweight", "custom"])
    parser.add_argument("--lightweight", action="store_true", default=False)
    parser.add_argument("--priority", type=int, default=None)
    parser.add_argument("--auto-mode", type=str, default=None,
                        help="Auto-mode flags: all, brainstorm, iteration, lightweight, archive, worktree (comma-separated), or 'none' to disable all")
    parser.add_argument("--control-mode", type=str, default=None, choices=["auto", "semi", "manual"],
                        help="Control mode: auto (full auto), semi (default, user confirms at gates), manual (user drives each step)")
    try:
        parsed = parser.parse_args(args)
    except SystemExit:
        return {"error": "invalid arguments, usage: kanban task edit <task_id> [--mode full|lightweight|custom] [--lightweight] [--priority N] [--auto-mode all|brainstorm,iteration,...] [--control-mode auto|semi|manual]"}

    _, _, tm = _resolve()
    task = tm.show(parsed.task_id)

    updates: dict = {}
    mode = parsed.mode
    if parsed.lightweight:
        mode = "lightweight"
        updates["lightweight"] = True
    if mode:
        updates["mode"] = mode
        if mode == "lightweight":
            updates["lightweight"] = True
        elif mode == "full":
            updates["lightweight"] = False
    if parsed.priority is not None:
        updates["priority"] = max(0, min(10, parsed.priority))
    if parsed.control_mode:
        updates["control_mode"] = parsed.control_mode

    if parsed.auto_mode is not None:
        from kanban_framework.types import AutoMode
        flags = [f.strip().lower() for f in parsed.auto_mode.split(",")]
        if "all" in flags:
            updates["auto_mode"] = AutoMode(
                auto_brainstorm=True, auto_iteration=True,
                auto_lightweight=True, auto_archive=True, auto_worktree=True,
            )
        elif "none" in flags:
            updates["auto_mode"] = AutoMode()
        else:
            am = task.auto_mode
            for f in flags:
                if f == "brainstorm":
                    am.auto_brainstorm = True
                elif f == "iteration":
                    am.auto_iteration = True
                elif f == "lightweight":
                    am.auto_lightweight = True
                elif f == "archive":
                    am.auto_archive = True
                elif f == "worktree":
                    am.auto_worktree = True
            updates["auto_mode"] = am

    if not updates:
        return {"error": "no changes specified (--mode, --lightweight, --priority, --auto-mode, --control-mode)"}

    tm.update(parsed.task_id, **updates)
    result = {
        "task_id": parsed.task_id,
        "updated": list(updates.keys()),
        "mode": mode or task.mode,
        "lightweight": updates.get("lightweight", task.lightweight),
        "control_mode": updates.get("control_mode", task.control_mode.value if task.control_mode else "semi"),
        "message": f"Task {parsed.task_id} updated",
    }
    if "auto_mode" in updates:
        am = updates["auto_mode"]
        result["auto_mode"] = {
            "auto_brainstorm": am.auto_brainstorm,
            "auto_iteration": am.auto_iteration,
            "auto_lightweight": am.auto_lightweight,
            "auto_archive": am.auto_archive,
            "auto_worktree": am.auto_worktree,
        }
    return result
