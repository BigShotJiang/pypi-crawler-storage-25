# redatlas

Official Python SDK for the RED Atlas External API.

Use it to authenticate with your RED Atlas API key and call the public data and reports endpoints.

## API Docs

For endpoint behavior, supported parameters, and response details, see the official API documentation:

- `https://api.atlas.red/es/docs`

## SDKs

- Python: `pip install redatlas`

## Install

```bash
pip install redatlas
```

## Quickstart

```python
from redatlas import RedAtlasClient

client = RedAtlasClient(
    api_key="ra_live_...",
)

records = client.data.data_list(market="col", entity_type="listings", limit=3)
print(records.meta.limit)
```

## Authentication

The SDK is intended to be used with your RED Atlas API key.

```python
from redatlas import RedAtlasClient

client = RedAtlasClient(api_key="ra_live_...")
records = client.data.data_list(market="col", entity_type="listings", limit=3)

print(records)
```

## Examples

```python
from redatlas import RedAtlasClient

client = RedAtlasClient(api_key="ra_live_...")

market = client.data.data_market(market="col")
records = client.data.data_list(market="col", entity_type="listings", limit=3)
report = client.reports.reports_get_public("rpt_public_123")

print(market.data.available_entities)
print(len(records.data))
print(report.data.id)
```

## Notes

- The public entrypoint is `RedAtlasClient`
- Standard usage is `RedAtlasClient(api_key="ra_live_...")`
- API parameters and endpoint semantics are documented at `https://api.atlas.red/es/docs`
- The default API host is the production RED Atlas API
- Integration tests in this repo verify that `RedAtlasClient` forwards generated API calls to the expected endpoints with the expected params

## Endpoints

For full details on parameters, request bodies, and responses, see the [API documentation](https://api.atlas.red/es/docs).

| Resource | Method | Endpoint |
| --- | --- | --- |
| Data | `client.data.data_market()` | `GET /v1/data/{market}` |
| Data | `client.data.data_list()` | `GET /v1/data/{market}/{entityType}` |
| Data | `client.data.data_get()` | `GET /v1/data/{market}/{entityType}/{id}` |
| Reports | `client.reports.reports_list()` | `GET /v1/reports` |
| Reports | `client.reports.reports_create()` | `POST /v1/reports` |
| Reports | `client.reports.reports_create_avm()` | `POST /v1/reports/avm` |
| Reports | `client.reports.reports_create_comparables()` | `POST /v1/reports/comparables` |
| Reports | `client.reports.reports_get()` | `GET /v1/reports/{id}` |
| Reports | `client.reports.reports_get_public()` | `GET /v1/reports/public/{reportId}` |
| Reports | `client.reports.reports_get_white_label()` | `GET /v1/reports/white-label` |
| Reports | `client.reports.reports_update_white_label()` | `PUT /v1/reports/white-label` |
