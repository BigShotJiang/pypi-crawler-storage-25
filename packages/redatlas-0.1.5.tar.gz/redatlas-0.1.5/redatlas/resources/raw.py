from ..api.data_api import DataApi
from ..api.reports_api import ReportsApi
from ..api_client import ApiClient


class RawApis:
    def __init__(self, api_client: ApiClient) -> None:
        self.data = DataApi(api_client)
        self.reports = ReportsApi(api_client)

        # Keep the rest of the generated API groups disabled in the wrapper for now.
        # self.health = HealthApi(api_client)
        # self.plans = PlansApi(api_client)
        # self.auth = AuthApi(api_client)
        # self.usage = UsageApi(api_client)
        # self.keys = APIKeysApi(api_client)
        # self.team = TeamApi(api_client)
        # self.notifications = NotificationsApi(api_client)
        # self.billing = BillingApi(api_client)
        # self.changelog = ChangelogApi(api_client)
