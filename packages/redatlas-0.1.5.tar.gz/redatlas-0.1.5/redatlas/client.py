from __future__ import annotations

import os
from typing import Optional

from .api.data_api import DataApi
from .api.reports_api import ReportsApi
from .api_client import ApiClient
from .configuration import Configuration
from .resources import RawApis


class RedAtlasClient:
    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        access_token: Optional[str] = None,
        refresh_token: Optional[str] = None,
        admin_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> None:
        bearer_token = access_token or api_key
        api_key_config: dict[str, str] = {}
        if refresh_token:
            api_key_config["cookieAuth"] = f"apiRefreshToken={refresh_token}"
        if admin_key:
            api_key_config["adminKeyAuth"] = admin_key

        resolved_base_url = base_url or os.getenv("RED_ATLAS_BASE_URL") or "https://api.atlas.red/external-api"
        self.configuration = Configuration(host=resolved_base_url, access_token=bearer_token, api_key=api_key_config or None)
        self.api_client = ApiClient(self.configuration)

        if timeout is not None:
            self.api_client.rest_client.pool_manager.connection_pool_kw["timeout"] = timeout

        self._raw: RawApis | None = None
        self._data: DataApi | None = None
        self._reports: ReportsApi | None = None

        # Keep the rest of the generated API groups disabled in the wrapper for now.
        # self._health: HealthApi | None = None
        # self._plans: PlansApi | None = None
        # self._auth: AuthApi | None = None
        # self._usage: UsageApi | None = None
        # self._keys: APIKeysApi | None = None
        # self._team: TeamApi | None = None
        # self._notifications: NotificationsApi | None = None
        # self._billing: BillingApi | None = None
        # self._changelog: ChangelogApi | None = None

    @property
    def raw(self) -> RawApis:
        if self._raw is None:
            self._raw = RawApis(self.api_client)
        return self._raw

    @property
    def data(self) -> DataApi:
        if self._data is None:
            self._data = self.raw.data
        return self._data

    @property
    def reports(self) -> ReportsApi:
        if self._reports is None:
            self._reports = self.raw.reports
        return self._reports

    # Keep the rest of the API groups commented so they can be re-enabled later.
    #
    # @property
    # def health(self) -> HealthApi:
    #     if self._health is None:
    #         self._health = self.raw.health
    #     return self._health
    #
    # @property
    # def plans(self) -> PlansApi:
    #     if self._plans is None:
    #         self._plans = self.raw.plans
    #     return self._plans
    #
    # @property
    # def auth(self) -> AuthApi:
    #     if self._auth is None:
    #         self._auth = self.raw.auth
    #     return self._auth
    #
    # @property
    # def usage(self) -> UsageApi:
    #     if self._usage is None:
    #         self._usage = self.raw.usage
    #     return self._usage
    #
    # @property
    # def keys(self) -> APIKeysApi:
    #     if self._keys is None:
    #         self._keys = self.raw.keys
    #     return self._keys
    #
    # @property
    # def team(self) -> TeamApi:
    #     if self._team is None:
    #         self._team = self.raw.team
    #     return self._team
    #
    # @property
    # def notifications(self) -> NotificationsApi:
    #     if self._notifications is None:
    #         self._notifications = self.raw.notifications
    #     return self._notifications
    #
    # @property
    # def billing(self) -> BillingApi:
    #     if self._billing is None:
    #         self._billing = self.raw.billing
    #     return self._billing
    #
    # @property
    # def changelog(self) -> ChangelogApi:
    #     if self._changelog is None:
    #         self._changelog = self.raw.changelog
    #     return self._changelog

    def close(self) -> None:
        pool_manager = getattr(self.api_client.rest_client, "pool_manager", None)
        if pool_manager is not None and hasattr(pool_manager, "clear"):
            pool_manager.clear()

    def __enter__(self) -> "RedAtlasClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
