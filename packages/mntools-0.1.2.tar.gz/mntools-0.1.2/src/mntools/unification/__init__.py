"""The unification module contains data structures to store 'unified models', where compounds, reactions,
and compartments are identified across models or compartments.
"""
