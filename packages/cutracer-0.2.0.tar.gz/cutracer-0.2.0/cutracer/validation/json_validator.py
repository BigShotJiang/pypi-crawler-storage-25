# Copyright (c) Meta Platforms, Inc. and affiliates.

"""
JSON validator for CUTracer NDJSON trace files.

This module provides functions to validate NDJSON trace files produced by
CUTracer for syntax correctness and schema compliance. Supports both
uncompressed (.ndjson) and Zstd-compressed (.ndjson.zst) files.
"""

from pathlib import Path
from typing import Any, Dict, List, Tuple, Union

import jsonschema
from tritonparse._json_compat import JSONDecodeError, loads

from .compression import detect_compression, open_trace_file
from .schema_loader import SCHEMAS_BY_TYPE


class JsonValidationError(Exception):
    """Exception raised for JSON validation errors."""

    pass


def validate_json_syntax(
    filepath: Union[str, Path],
) -> Tuple[int, List[str]]:
    """
    Validate JSON syntax line-by-line for NDJSON file.

    Supports both uncompressed (.ndjson) and Zstd-compressed (.ndjson.zst) files.

    Args:
        filepath: Path to NDJSON trace file

    Returns:
        Tuple of (valid_count, errors) where:
            - valid_count: Number of valid JSON lines parsed
            - errors: List of error messages with line numbers

    Raises:
        FileNotFoundError: If file does not exist
    """
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    valid_count = 0
    errors: List[str] = []

    try:
        with open_trace_file(filepath, encoding_errors="replace") as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue

                try:
                    loads(line)
                    valid_count += 1
                except JSONDecodeError as e:
                    errors.append(f"Line {line_num}: JSON decode error - {e.msg}")

    except Exception as e:
        errors.append(f"File reading error: {str(e)}")

    return valid_count, errors


def validate_json_schema(
    filepath: Union[str, Path],
    message_type: str = "reg_trace",
    max_errors: int = 10,
    allow_mixed_types: bool = False,
) -> bool:
    """
    Validate JSON schema against TraceRecord definition.

    Supports both uncompressed (.ndjson) and Zstd-compressed (.ndjson.zst) files.

    Args:
        filepath: Path to NDJSON trace file
        message_type: Expected message type (default: "reg_trace")
        max_errors: Maximum number of schema errors to collect (default: 10)
        allow_mixed_types: If True, validate each record against its own schema
                          based on the 'type' field. If False, all records must
                          match the specified message_type. (default: False)

    Returns:
        True if all records pass schema validation

    Raises:
        JsonValidationError: If schema validation fails (includes detailed errors)
        FileNotFoundError: If file does not exist
        ValueError: If message_type is not recognized
    """
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    if message_type not in SCHEMAS_BY_TYPE:
        valid_types = ", ".join(SCHEMAS_BY_TYPE.keys())
        raise ValueError(
            f"Unknown message type: {message_type}. Valid types: {valid_types}"
        )

    # Pre-create validators for all types if allowing mixed types
    validators = {
        msg_type: jsonschema.Draft7Validator(schema)
        for msg_type, schema in SCHEMAS_BY_TYPE.items()
    }
    default_validator = validators[message_type]

    errors: List[str] = []
    line_num = 0

    try:
        with open_trace_file(filepath, encoding_errors="replace") as f:
            for line_num, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue

                try:
                    record = loads(line)
                except JSONDecodeError as e:
                    errors.append(f"Line {line_num}: JSON syntax error - {e.msg}")
                    if len(errors) >= max_errors:
                        break
                    continue

                # Get the record's type
                record_type = record.get("type", "")

                if allow_mixed_types:
                    # Validate against the appropriate schema for this record's type
                    if record_type not in SCHEMAS_BY_TYPE:
                        errors.append(
                            f"Line {line_num}: Unknown message type '{record_type}'"
                        )
                        if len(errors) >= max_errors:
                            break
                        continue
                    validator = validators[record_type]
                else:
                    # Check if type field matches expected type
                    if record_type != message_type:
                        errors.append(
                            f"Line {line_num}: Expected type '{message_type}', "
                            f"got '{record_type}'"
                        )
                        if len(errors) >= max_errors:
                            break
                        continue
                    validator = default_validator

                # Validate against schema
                validation_errors = list(validator.iter_errors(record))
                if validation_errors:
                    for error in validation_errors[
                        :3
                    ]:  # Show first 3 errors per record
                        field_path = ".".join(str(p) for p in error.path)
                        errors.append(
                            f"Line {line_num}: Schema error at '{field_path}': "
                            f"{error.message}"
                        )
                    if len(errors) >= max_errors:
                        break

    except Exception as e:
        errors.append(f"File reading error: {str(e)}")

    if errors:
        error_summary = "\n".join(errors)
        if len(errors) >= max_errors:
            error_summary += f"\n... (showing first {max_errors} errors)"
        raise JsonValidationError(f"Schema validation failed:\n{error_summary}")

    return True


def validate_json_trace(filepath: Union[str, Path]) -> Dict[str, Any]:
    """
    Complete validation of NDJSON trace file.

    Performs both syntax and schema validation, with auto-detection of
    message type from the first record. Supports both uncompressed (.ndjson)
    and Zstd-compressed (.ndjson.zst) files.

    Args:
        filepath: Path to NDJSON trace file

    Returns:
        Dictionary containing:
            - valid: bool - Whether validation passed
            - record_count: int - Number of valid records
            - file_size: int - File size in bytes (compressed size for .zst files)
            - compression: str - Compression type ("zstd" or "none")
            - message_type: str - Detected message type
            - errors: List[str] - Error messages (empty if valid)

    Raises:
        FileNotFoundError: If file does not exist
    """
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    compression = detect_compression(filepath)

    result: Dict[str, Any] = {
        "valid": False,
        "record_count": 0,
        "file_size": filepath.stat().st_size,
        "compression": compression,
        "message_type": None,
        "errors": [],
    }

    # Step 1: Validate syntax
    try:
        valid_count, syntax_errors = validate_json_syntax(filepath)
        result["record_count"] = valid_count

        if syntax_errors:
            result["errors"].extend(syntax_errors)
            return result

        if valid_count == 0:
            result["errors"].append("No valid JSON records found in file")
            return result

    except Exception as e:
        result["errors"].append(f"Syntax validation error: {str(e)}")
        return result

    # Step 2: Auto-detect message type from first non-metadata record
    # kernel_metadata lines are header records (not trace data), so we skip
    # them when detecting the dominant message type and exclude them from
    # record_count to keep parity with text mode (which has no metadata line).
    try:
        metadata_count = 0
        with open_trace_file(filepath, encoding_errors="replace") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                record = loads(line)
                message_type = record.get("type")
                if message_type == "kernel_metadata":
                    metadata_count += 1
                    continue
                if message_type not in SCHEMAS_BY_TYPE:
                    result["errors"].append(
                        f"Unknown message type in file: {message_type}"
                    )
                    return result
                result["message_type"] = message_type
                break
        result["record_count"] -= metadata_count
    except Exception as e:
        result["errors"].append(f"Failed to detect message type: {str(e)}")
        return result

    # Step 3: Validate schema (allow mixed types since trace files often contain multiple record types)
    try:
        validate_json_schema(
            filepath, message_type=result["message_type"], allow_mixed_types=True
        )
        result["valid"] = True
    except JsonValidationError as e:
        result["errors"].append(str(e))
    except Exception as e:
        result["errors"].append(f"Schema validation error: {str(e)}")

    return result
