"""MCP tool registration."""
from __future__ import annotations

from .client import BrowserClient
from . import tools as t


def register(mcp, config: dict) -> None:
    c = BrowserClient(config)

    @mcp.tool()
    async def navigate(url: str, wait_until: str = "domcontentloaded") -> str:
        """Navigate to a URL"""
        return await t.navigate(c, url, wait_until)

    @mcp.tool()
    async def current_url() -> str:
        """Get the current page URL"""
        return await t.current_url(c)

    @mcp.tool()
    async def go_back() -> str:
        """Navigate back in browser history"""
        return await t.go_back(c)

    @mcp.tool()
    async def go_forward() -> str:
        """Navigate forward in browser history"""
        return await t.go_forward(c)

    @mcp.tool()
    async def reload() -> str:
        """Reload the current page"""
        return await t.reload(c)

    @mcp.tool()
    async def get_title() -> str:
        """Get the page title"""
        return await t.get_title(c)

    @mcp.tool()
    async def get_text(selector: str) -> str:
        """Get visible text of an element"""
        return await t.get_text(c, selector)

    @mcp.tool()
    async def get_all_texts(selector: str) -> str:
        """Get visible text of all matching elements"""
        return await t.get_all_texts(c, selector)

    @mcp.tool()
    async def get_page_content(max_length: int = 10000) -> str:
        """Get all visible text on the page"""
        return await t.get_page_content(c, max_length)

    @mcp.tool()
    async def get_html(selector: str = "body") -> str:
        """Get inner HTML of an element"""
        return await t.get_html(c, selector)

    @mcp.tool()
    async def get_links() -> str:
        """Get all links on the page"""
        return await t.get_links(c)

    @mcp.tool()
    async def get_attribute(selector: str, attribute: str) -> str:
        """Get an attribute value from an element"""
        return await t.get_attribute(c, selector, attribute)

    @mcp.tool()
    async def get_aria_snapshot(selector: str = "body") -> str:
        """Get ARIA accessibility tree as YAML — ideal for LLM navigation"""
        return await t.get_aria_snapshot(c, selector)

    @mcp.tool()
    async def get_console_messages() -> str:
        """Get recent console messages from the page"""
        return await t.get_console_messages(c)

    @mcp.tool()
    async def get_page_requests() -> str:
        """Get recent network requests made by the page"""
        return await t.get_page_requests(c)

    @mcp.tool()
    async def click(selector: str) -> str:
        """Click an element"""
        return await t.click(c, selector)

    @mcp.tool()
    async def double_click(selector: str) -> str:
        """Double-click an element"""
        return await t.double_click(c, selector)

    @mcp.tool()
    async def right_click(selector: str) -> str:
        """Right-click an element"""
        return await t.right_click(c, selector)

    @mcp.tool()
    async def fill(selector: str, text: str) -> str:
        """Fill an input field"""
        return await t.fill(c, selector, text)

    @mcp.tool()
    async def type_text(selector: str, text: str, delay: int = 50) -> str:
        """Type text character by character (for autocomplete)"""
        return await t.type_text(c, selector, text, delay)

    @mcp.tool()
    async def press(key: str, selector: str = "") -> str:
        """Press a key — on element if selector given, else globally"""
        return await t.press(c, key, selector)

    @mcp.tool()
    async def select_option(selector: str, value: str) -> str:
        """Select a dropdown option by value"""
        return await t.select_option(c, selector, value)

    @mcp.tool()
    async def select_option_by_text(selector: str, text: str) -> str:
        """Select a dropdown option by visible text"""
        return await t.select_option_by_text(c, selector, text)

    @mcp.tool()
    async def check(selector: str) -> str:
        """Check a checkbox"""
        return await t.check(c, selector)

    @mcp.tool()
    async def uncheck(selector: str) -> str:
        """Uncheck a checkbox"""
        return await t.uncheck(c, selector)

    @mcp.tool()
    async def hover(selector: str) -> str:
        """Hover over an element"""
        return await t.hover(c, selector)

    @mcp.tool()
    async def focus(selector: str) -> str:
        """Focus an element"""
        return await t.focus(c, selector)

    @mcp.tool()
    async def clear(selector: str) -> str:
        """Clear an input field"""
        return await t.clear(c, selector)

    @mcp.tool()
    async def drag_and_drop(source: str, target: str) -> str:
        """Drag element from source to target"""
        return await t.drag_and_drop(c, source, target)

    @mcp.tool()
    async def upload_file(selector: str, path: str) -> str:
        """Upload a file to a file input"""
        return await t.upload_file(c, selector, path)

    @mcp.tool()
    async def wait_for_download(trigger_selector: str = "") -> str:
        """Click trigger and wait for file download"""
        return await t.wait_for_download(c, trigger_selector)

    @mcp.tool()
    async def accept_dialog() -> str:
        """Accept the next browser dialog"""
        return await t.accept_dialog(c)

    @mcp.tool()
    async def dismiss_dialog() -> str:
        """Dismiss the next browser dialog"""
        return await t.dismiss_dialog(c)

    @mcp.tool()
    async def screenshot(path: str = "", full_page: bool = False) -> str:
        """Take a screenshot — returns base64 if no path given"""
        return await t.screenshot(c, path, full_page)

    @mcp.tool()
    async def screenshot_element(selector: str, path: str = "") -> str:
        """Take a screenshot of a specific element"""
        return await t.screenshot_element(c, selector, path)

    @mcp.tool()
    async def wait_for(selector: str, timeout: int = 10000) -> str:
        """Wait for an element to appear"""
        return await t.wait_for(c, selector, timeout)

    @mcp.tool()
    async def wait_for_hidden(selector: str, timeout: int = 10000) -> str:
        """Wait for an element to disappear"""
        return await t.wait_for_hidden(c, selector, timeout)

    @mcp.tool()
    async def wait_for_url(url_pattern: str, timeout: int = 10000) -> str:
        """Wait for URL to match a pattern"""
        return await t.wait_for_url(c, url_pattern, timeout)

    @mcp.tool()
    async def set_viewport(width: int, height: int) -> str:
        """Set browser viewport size"""
        return await t.set_viewport(c, width, height)

    @mcp.tool()
    async def scroll_to(selector: str) -> str:
        """Scroll element into view"""
        return await t.scroll_to(c, selector)

    @mcp.tool()
    async def scroll_page(direction: str = "down", amount: int = 500) -> str:
        """Scroll page — direction: up/down/top/bottom"""
        return await t.scroll_page(c, direction, amount)

    @mcp.tool()
    async def set_headless(headless: bool) -> str:
        """Switch between headless and headed mode"""
        return await t.set_headless(c, headless)

    @mcp.tool()
    async def set_browser(browser_type: str) -> str:
        """Switch browser: chromium, firefox, or webkit"""
        return await t.set_browser(c, browser_type)

    @mcp.tool()
    async def start_recording(path: str = "recording.webm") -> str:
        """Start video recording"""
        return await t.start_recording(c, path)

    @mcp.tool()
    async def stop_recording() -> str:
        """Stop video recording and save"""
        return await t.stop_recording(c)

    @mcp.tool()
    async def recording_show_actions(position: str = "top-right") -> str:
        """Annotate recording with action highlights"""
        return await t.recording_show_actions(c, position)

    @mcp.tool()
    async def new_tab() -> str:
        """Open a new browser tab"""
        return await t.new_tab(c)

    @mcp.tool()
    async def list_tabs() -> str:
        """List all open tabs"""
        return await t.list_tabs(c)

    @mcp.tool()
    async def switch_tab(tab_id: int) -> str:
        """Switch to a tab by ID"""
        return await t.switch_tab(c, tab_id)

    @mcp.tool()
    async def close_tab(tab_id: int) -> str:
        """Close a tab by ID"""
        return await t.close_tab(c, tab_id)

    @mcp.tool()
    async def switch_to_frame(selector: str) -> str:
        """Switch context to an iFrame"""
        return await t.switch_to_frame(c, selector)

    @mcp.tool()
    async def switch_to_main() -> str:
        """Switch back to main frame"""
        return await t.switch_to_main(c)

    @mcp.tool()
    async def get_cookies() -> str:
        """Get all cookies"""
        return await t.get_cookies(c)

    @mcp.tool()
    async def set_cookie(name: str, value: str, domain: str = "", path: str = "/") -> str:
        """Set a cookie"""
        return await t.set_cookie(c, name, value, domain, path)

    @mcp.tool()
    async def clear_cookies() -> str:
        """Clear all cookies"""
        return await t.clear_cookies(c)

    @mcp.tool()
    async def get_local_storage(key: str = "") -> str:
        """Get localStorage — all items or a specific key"""
        return await t.get_local_storage(c, key)

    @mcp.tool()
    async def set_local_storage(key: str, value: str) -> str:
        """Set a localStorage item"""
        return await t.set_local_storage(c, key, value)

    @mcp.tool()
    async def clear_storage() -> str:
        """Clear localStorage and sessionStorage"""
        return await t.clear_storage(c)

    @mcp.tool()
    async def mock_route(
        url_pattern: str,
        status: int = 200,
        body: str = "{}",
        content_type: str = "application/json",
    ) -> str:
        """Mock network requests matching url_pattern"""
        return await t.mock_route(c, url_pattern, status, body, content_type)

    @mcp.tool()
    async def clear_route(url_pattern: str) -> str:
        """Remove a route mock"""
        return await t.clear_route(c, url_pattern)

    @mcp.tool()
    async def abort_route(url_pattern: str) -> str:
        """Block requests matching url_pattern"""
        return await t.abort_route(c, url_pattern)

    @mcp.tool()
    async def wait_for_response(url_pattern: str, timeout: int = 10000) -> str:
        """Wait for a network response"""
        return await t.wait_for_response(c, url_pattern, timeout)

    @mcp.tool()
    async def execute_script(code: str) -> str:
        """Execute JavaScript in the page context"""
        return await t.execute_script(c, code)

    @mcp.tool()
    async def find_by_role(role: str, name: str = "") -> str:
        """Find element by ARIA role"""
        return await t.find_by_role(c, role, name)

    @mcp.tool()
    async def find_by_text(text: str, exact: bool = False) -> str:
        """Find element by visible text"""
        return await t.find_by_text(c, text, exact)

    @mcp.tool()
    async def find_by_label(label: str) -> str:
        """Find form element by label"""
        return await t.find_by_label(c, label)

    @mcp.tool()
    async def find_by_placeholder(placeholder: str) -> str:
        """Find input by placeholder"""
        return await t.find_by_placeholder(c, placeholder)

    @mcp.tool()
    async def find_by_test_id(test_id: str) -> str:
        """Find element by data-testid"""
        return await t.find_by_test_id(c, test_id)

    @mcp.tool()
    async def click_by_role(role: str, name: str = "") -> str:
        """Click element by ARIA role"""
        return await t.click_by_role(c, role, name)

    @mcp.tool()
    async def click_by_text(text: str) -> str:
        """Click element by visible text"""
        return await t.click_by_text(c, text)

    @mcp.tool()
    async def fill_by_label(label: str, value: str) -> str:
        """Fill input found by its label"""
        return await t.fill_by_label(c, label, value)

    @mcp.tool()
    async def describe_element(selector: str) -> str:
        """Get ARIA role, text, and attributes of an element"""
        return await t.describe_element(c, selector)

    @mcp.tool()
    async def find_interactive_elements() -> str:
        """List all clickable and fillable elements on the page"""
        return await t.find_interactive_elements(c)
