"""Playwright MCP plugin — navigation, interaction, content, and more."""
from .client import BrowserClient, ToolError
from .register import register

__all__ = ["BrowserClient", "ToolError", "register"]
