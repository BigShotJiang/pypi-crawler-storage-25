# Changelog

## [2.0.1] — 2026-05-20

- Extracted from uc-mcp-tools monorepo into standalone package
- Fixed frames.py: frame state in BrowserClient, no monkey-patching
- Removed dead code (accepted list in accept_dialog)
- Removed decorative separator comments
- ruff clean, 31 tests green

## [2.0.0] — 2026-05-20

Full rewrite — 61 tools across 10 categories:

### New
- Multi-tab: new_tab, list_tabs, switch_tab, close_tab
- iFrames: switch_to_frame, switch_to_main
- Storage: cookies (get/set/clear), localStorage (get/set/clear)
- Network: mock_route, clear_route, abort_route, wait_for_response
- Recording: start_recording, stop_recording, recording_show_actions (page.screencast API)
- Script: execute_script
- Interaction: double_click, right_click, drag_and_drop, upload_file, wait_for_download, accept_dialog, dismiss_dialog
- Content: get_aria_snapshot, get_console_messages, get_page_requests

### Changed
- page.type() → locator.press_sequentially() (deprecated API removed)
- screenshot path="" returns base64, no default filename
- go_back/go_forward raise ToolError when no history
- BrowserClient: multi-tab capable
- ToolError exception instead of "Error: ..." string returns

## [1.0.2] — 2025

- Initial stable release (monorepo)
