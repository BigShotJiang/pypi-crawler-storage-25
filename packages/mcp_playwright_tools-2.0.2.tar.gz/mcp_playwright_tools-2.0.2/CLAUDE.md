# CLAUDE.md — uc-mcp-playwright

## Projekt

MCP-Server für Browser-Automatisierung mit Playwright.
Standalone-Paket, Teil der uc-mcp-tools Familie.

## Struktur

```
src/mcp_playwright_tools/
  __init__.py              main() entry point
  playwright/
    client.py              BrowserClient (Multi-Tab)
    register.py            MCP tool registration
    tools/
      navigation.py
      content.py
      interaction.py
      browser.py           screenshots, viewport, recording
      tabs.py
      frames.py
      storage.py
      network.py
      script.py
      locators.py
tests/
  conftest.py
  test_navigation.py
  test_content.py
  test_locators.py
  test_client.py
```

## Entwicklung

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
playwright install chromium
pytest tests/ -q
ruff check src/ tests/
```

## Konventionen

- ruff clean vor jedem Commit
- Tests grün vor jedem Commit
- Keine deprecated Playwright APIs
- ToolError statt String-Returns bei Fehlern
- Einzeilige Commit-Messages, Details in CHANGELOG.md
- Interne Dokumente: Deutsch, öffentliche Artefakte: Englisch
