"""
docpluck.extract_structured — top-level structured PDF extraction.

Per [LESSONS L-006](../LESSONS.md#l-006), this module is pdfplumber-free.
Tables come from Camelot stream flavor; figures and captions are detected
purely from the pdftotext text channel via the regexes in
``docpluck.tables.captions``.

Pipeline:
    1. ``extract_pdf`` → linear pdftotext text + page count.
    2. ``find_caption_matches`` → "Table N" / "Figure N" caption lines on
       each page.
    3. ``extract_tables_camelot`` → cell-bearing tables from each page.
    4. Match each Camelot table to its same-page caption (label, caption text).
    5. Build :class:`Figure` dicts from caption matches that don't pair with
       any table.
    6. Optional placeholder mode replaces caption lines with
       ``[Label: caption]`` markers.
"""

from __future__ import annotations

import os
import re
from typing import Literal, Optional, TypedDict

from .extract import extract_pdf, count_pages
from .figures import Figure
from .tables import Cell, Table
from .tables.camelot_extract import extract_tables_camelot
from .tables.captions import CaptionMatch, find_caption_matches
from .tables.render import cells_to_html


TABLE_EXTRACTION_VERSION = "2.1.0"  # v2.1.0: cell-cleaning pipeline ported from splice spike (multi-row header detection, continuation merging, leader-dot strip, mash-split, group separators, sig-marker attach)

TableTextMode = Literal["raw", "placeholder"]


class StructuredResult(TypedDict):
    text: str
    method: str
    page_count: int
    tables: list[Table]
    figures: list[Figure]
    table_extraction_version: str


def extract_pdf_structured(
    pdf_bytes: bytes,
    *,
    thorough: bool = False,
    table_text_mode: TableTextMode = "raw",
) -> StructuredResult:
    """Extract text + structured tables + figures from a PDF.

    Args:
        pdf_bytes: Raw PDF bytes.
        thorough: Currently unused — Camelot scans every page by default.
            Retained for backwards-compatible call signature.
        table_text_mode: ``"raw"`` (default; text identical to ``extract_pdf``)
            or ``"placeholder"`` (caption lines for tables/figures are replaced
            with ``[Label: caption]`` markers).

    Returns:
        StructuredResult dict.
    """
    raw_text, base_method = extract_pdf(pdf_bytes)
    page_count = count_pages(pdf_bytes)

    if raw_text.startswith("ERROR:"):
        return {
            "text": raw_text,
            "method": base_method,
            "page_count": page_count,
            "tables": [],
            "figures": [],
            "table_extraction_version": TABLE_EXTRACTION_VERSION,
        }

    method_pieces = [base_method]
    if thorough:
        method_pieces.append("thorough")
    # Preprocess: pdftotext sometimes splits captions like "Table 1: X" into
    # "T\n\n1: X". Join these so the caption regex matches consistently.
    # We work on a SHADOW string for caption detection only — raw_text returned
    # to callers is unmodified.
    rejoined = _join_split_captions(raw_text)
    page_offsets = _page_offsets(rejoined)
    captions_all = find_caption_matches(rejoined, page_offsets)
    # Dedupe by (kind, number): keep only the first occurrence — body-text
    # references like "see Table 1" can otherwise duplicate captions.
    seen_keys: set[tuple[str, int]] = set()
    captions: list[CaptionMatch] = []
    for c in captions_all:
        key = (c.kind, c.number)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        captions.append(c)
    # The captions' char_start/char_end refer to `rejoined`, not raw_text. For
    # placeholder mode we need positions in raw_text — build a translation map.
    # Since the rejoin only deletes whitespace runs, char positions in rejoined
    # are <= positions in raw_text. We translate by re-finding the caption line
    # in raw_text on demand.

    tables: list[Table] = []
    figures: list[Figure] = []

    # v2.3.0 Bug 4 fix: build a fast lookup from caption to the char_start
    # of the next caption (any kind) so _extract_caption_text can bound
    # the caption snippet at the next-caption boundary. Prevents the
    # gratitude-paper Figure 1 caption from concatenating Figure 2's
    # caption and the results-section F-stat prose.
    sorted_caps = sorted(captions, key=lambda c: c.char_start)
    next_boundary_by_id: dict[int, Optional[int]] = {}
    for i, c in enumerate(sorted_caps):
        nb = sorted_caps[i + 1].char_start if i + 1 < len(sorted_caps) else None
        next_boundary_by_id[id(c)] = nb

    # ---- Tables (Camelot) ----
    camelot_disabled = os.environ.get("DOCPLUCK_DISABLE_CAMELOT", "0") == "1"
    camelot_tables: list[Table] = []
    if not camelot_disabled:
        try:
            camelot_tables = extract_tables_camelot(pdf_bytes)
            if camelot_tables:
                method_pieces.append("camelot_stream")
        except Exception:
            method_pieces.append("camelot_failed")
            camelot_tables = []

    # Match Camelot tables to "Table N" caption lines on the same page.
    used_caption_ids: set[int] = set()
    table_captions = [c for c in captions if c.kind == "table"]

    # Filter Camelot's output to tables that have a same-page caption.
    # This anchors detection to caption signal (matching the pre-pdfplumber-removal
    # behavior of docpluck) and drops false-positive Camelot detections like
    # bibliographies or address blocks. Tables without captions are rare in APA
    # corpus and the existing tests are calibrated against caption-anchored counts.
    pages_with_table_caption = {c.page for c in table_captions}
    for ct in camelot_tables:
        if (ct.get("page") or 0) not in pages_with_table_caption:
            continue
        match = _find_caption_for_table(ct, table_captions, raw_text, used_caption_ids)
        if match is not None:
            used_caption_ids.add(id(match))
            ct["label"] = match.label
            ct["caption"] = _extract_caption_text(
                rejoined, match, next_boundary_by_id.get(id(match))
            )
            tables.append(ct)

    # If a table caption had no Camelot match, emit an "isolated" Table dict so
    # downstream consumers still see something at that page.
    for cap in table_captions:
        if id(cap) in used_caption_ids:
            continue
        tables.append(
            _isolated_table_from_caption(
                cap, rejoined, next_boundary_by_id.get(id(cap))
            )
        )

    # ---- Figures ----
    for cap in captions:
        if cap.kind != "figure":
            continue
        figures.append(
            _figure_from_caption(cap, rejoined, next_boundary_by_id.get(id(cap)))
        )

    # ---- Placeholder mode ----
    text_out = (
        _apply_placeholder(raw_text, captions)
        if table_text_mode == "placeholder"
        else raw_text
    )

    # Sort tables/figures by page for stable output.
    tables.sort(key=lambda t: (t.get("page") or 0, t.get("label") or ""))
    figures.sort(key=lambda f: (f.get("page") or 0, f.get("label") or ""))

    return {
        "text": text_out,
        "method": "+".join(method_pieces),
        "page_count": page_count,
        "tables": tables,
        "figures": figures,
        "table_extraction_version": TABLE_EXTRACTION_VERSION,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _page_offsets(raw_text: str) -> list[int]:
    """Char offset where each 1-indexed page starts in raw_text. raw_text uses
    ``\\f`` (form feed) as page separator (pdftotext default)."""
    offsets = [0]
    for i, ch in enumerate(raw_text):
        if ch == "\f":
            offsets.append(i + 1)
    return offsets


_SPLIT_CAPTION_RE = re.compile(
    r"^(T|Table|Fig\.?|Figure)\s*\n\s*\n\s*(\d+(?:\.\d+)?)([\s.:\-—–]+)",
    re.MULTILINE | re.IGNORECASE,
)
_T_PREFIX_RE = re.compile(
    r"^T\s+(\d+(?:\.\d+)?)([\s.:\-—–])",
    re.MULTILINE,
)
_FIG_PREFIX_RE = re.compile(
    r"^Fig\.?\s+(\d+(?:\.\d+)?)([\s.:\-—–])",
    re.MULTILINE | re.IGNORECASE,
)


def _join_split_captions(text: str) -> str:
    """Rejoin captions pdftotext split across paragraphs.

    Patterns:
      - "T\\n\\n1: foo" → "Table 1: foo"
      - "Fig.\\n\\n2: bar" → "Figure 2: bar"
      - bare "T 1:" prefix → "Table 1:" (after the rejoin above)
    """
    text = _SPLIT_CAPTION_RE.sub(r"\1 \2\3", text)
    text = _T_PREFIX_RE.sub(r"Table \1\2", text)
    text = _FIG_PREFIX_RE.sub(r"Figure \1\2", text)
    return text


def _find_caption_for_table(
    camelot_table: Table,
    captions: list[CaptionMatch],
    raw_text: str,
    used_caption_ids: set[int],
) -> Optional[CaptionMatch]:
    """Pick the best ``Table N:`` caption on the same page as the camelot table.

    Strategy: among unused captions on the same page, prefer the one whose
    caption-line tokens appear most densely in the table's raw_text. If no
    captions are on the same page, return None.
    """
    page = camelot_table.get("page") or 0
    same_page = [c for c in captions if c.page == page and id(c) not in used_caption_ids]
    if not same_page:
        return None
    if len(same_page) == 1:
        return same_page[0]
    # Score each caption by token overlap with the camelot table content
    table_text = (camelot_table.get("raw_text") or "").lower()
    table_tokens = set(re.findall(r"[a-z]{3,}|\d+(?:\.\d+)?", table_text))
    best: Optional[tuple[int, int, CaptionMatch]] = None
    for c in same_page:
        cap_tokens = set(re.findall(r"[a-z]{3,}|\d+(?:\.\d+)?", c.line_text.lower()))
        score = len(cap_tokens & table_tokens)
        candidate = (-score, c.char_start, c)
        if best is None or candidate < best:
            best = candidate
    if best is None:
        return None
    return best[2]


def _extract_caption_text(
    raw_text: str,
    cap: CaptionMatch,
    next_boundary: Optional[int] = None,
) -> str:
    """Pull the full caption (label + description) starting at the caption line.

    Captions are often line-wrapped by pdftotext, so a single ``\\n\\n``
    boundary can sit MID-SENTENCE. Walk past such breaks until we find one
    where the preceding text ends with a real sentence terminator
    (``.``/``!``/``?``) or we hit a hard cap.

    v2.3.0 Bug 4 fix (handoff 2026-05-11): caller may pass
    ``next_boundary`` — the char position of the next caption / next
    section heading — to cap extraction. Without it, a caption that
    didn't end in a sentence terminator would greedily extend into the
    next figure's caption or unrelated body prose (the gratitude-paper
    Figure 1 / Figure 2 / F-stat-prose concatenation bug). The
    effective hard cap is ``min(cap.char_end + 800, next_boundary,
    len(raw_text))``.
    """
    start = cap.char_start
    # Hard cap — never read more than 800 chars from caption start. The
    # 800 figure is the handoff's "guard against runaway captions" upper
    # bound; before v2.3.0 this was 600, but raising it to 800 with the
    # next_boundary cap is strictly safer since next_boundary now bounds
    # the typical case.
    hard_end = min(cap.char_end + 800, len(raw_text))
    if next_boundary is not None and next_boundary > cap.char_end:
        hard_end = min(hard_end, next_boundary)
    pos = cap.char_end
    while pos < hard_end:
        nxt = raw_text.find("\n\n", pos)
        if nxt == -1 or nxt >= hard_end:
            break
        # Check the text just before this paragraph break.
        prev = raw_text[max(start, nxt - 40):nxt].rstrip()
        # If it ends with a sentence terminator OR is empty/very short, stop.
        if not prev or len(prev.split()) < 2:
            hard_end = nxt
            break
        if re.search(r"[.!?][\"'\)\]]?$", prev):
            hard_end = nxt
            break
        # Otherwise the caption continues — skip past this break and keep going.
        pos = nxt + 2
    snippet = raw_text[start:hard_end].replace("\n", " ").strip()
    # v2.3.0 soft-hyphen rejoin (per `docs/HANDOFF_2026-05-11_visual_review_findings.md`
    # "Soft-hyphen artifacts in captions" — chen.pdf showed `Sup­ plementary`).
    # Captions don't flow through ``normalize_text``, so apply the same
    # rejoin here. ``­`` followed by any whitespace = word-wrap artifact
    # → drop both. Orphan ``­`` is also invisible by Unicode and gets
    # dropped.
    snippet = re.sub("­\\s+", "", snippet)
    snippet = snippet.replace("­", "")
    # Collapse runs of any whitespace (including U+2002 EN SPACE, etc.) to a
    # single space; many APA PDFs use unusual spaces between label and caption.
    snippet = re.sub(r"\s+", " ", snippet)
    # Strip leading orphan punctuation that can occur when the rejoin produced
    # a partial caption (e.g., "Table 1. : Studies 1b and 3...").
    snippet = re.sub(r"^[\s.:\-—–]+", "", snippet)
    # Re-prefix the label if stripping ate it.
    if cap.label and not snippet.startswith(cap.label):
        snippet = f"{cap.label}. {snippet}".strip()
    # v2.4.4: trim chart-data appendage from figure captions (axis-tick
    # sequences, raw bar-chart values pdftotext joined inline into the
    # caption paragraph). For tables the appendage is usually the next-
    # row continuation so skip — the caption hard-cap at 400 below
    # bounds it.
    if cap.kind == "figure":
        snippet = _trim_caption_at_chart_data(snippet)
    if len(snippet) > 400:
        snippet = snippet[:400].rsplit(" ", 1)[0] + "…"
    return snippet


# v2.4.4: shared chart-data trim, duplicated logic from
# ``docpluck.figures.detect._trim_caption_at_chart_data`` so this module
# doesn't import from ``figures.detect`` (which has its own layout-channel
# dependencies). Two signatures of pdftotext-joined chart data:
#   1. Run of 6+ consecutive digits — flowchart counts, row IDs.
#   2. Run of 5+ short (1–4 digit) numeric tokens separated only by
#      whitespace — axis-tick label sequences.
_CHART_DATA_DIGIT_RUN_RE_STRUCT = re.compile(r"\b\d{6,}\b")
_CHART_DATA_TICK_RUN_RE_STRUCT = re.compile(r"(?:\b\d{1,4}\b[ \t]+){5,}")


def _trim_caption_at_chart_data(caption: str) -> str:
    """Truncate a caption when it transitions from prose to chart-data.

    Conservative: only fires when caption ≥ 150 chars AND the surviving
    trimmed text is ≥ 40 chars. The two regex signatures catch
    complementary chart-data patterns (large counts and small axis-tick
    sequences); the earlier match wins.
    """
    if not caption or len(caption) < 150:
        return caption
    candidates: list[int] = []
    m1 = _CHART_DATA_DIGIT_RUN_RE_STRUCT.search(caption)
    if m1 is not None:
        candidates.append(m1.start())
    m2 = _CHART_DATA_TICK_RUN_RE_STRUCT.search(caption)
    if m2 is not None:
        candidates.append(m2.start())
    if not candidates:
        return caption
    cut = min(candidates)
    while cut > 0 and not caption[cut - 1].isspace():
        cut -= 1
    trimmed = caption[:cut].rstrip(" ,;:")
    if len(trimmed) < 40:
        return caption
    return trimmed


def _isolated_table_from_caption(
    cap: CaptionMatch,
    raw_text: str,
    next_boundary: Optional[int] = None,
) -> Table:
    """Build an isolated (cellless) Table dict for a caption with no Camelot match.

    v2.4.12: populate ``raw_text`` with the body text following the caption.
    pdftotext linearizes table cells into the body as a vertical run of
    short lines (column headers, then values, then more rows). Even
    though we can't reconstruct the grid (Camelot failed and we run in
    pdfplumber-free mode here), surfacing the raw cell content under the
    caption is much better than the previous "no cells or raw text
    extracted" banner — the user sees the table's information, just as
    a flat list rather than a structured grid.
    """
    cap_text = _extract_caption_text(raw_text, cap, next_boundary)
    body_text = _extract_table_body_text(raw_text, cap, next_boundary)
    return {
        "id": f"t{cap.number}",
        "label": cap.label,
        "page": cap.page,
        "bbox": (0.0, 0.0, 0.0, 0.0),
        "caption": cap_text,
        "footnote": None,
        "kind": "isolated",
        "rendering": "isolated",
        "confidence": None,
        "n_rows": None,
        "n_cols": None,
        "header_rows": None,
        "cells": [],
        "html": None,
        "raw_text": body_text,
    }


# Common English stopwords used by `_line_is_body_prose` to discriminate
# table cells (mostly noun fragments / numbers / short labels) from running
# body prose (rich in articles, prepositions, conjunctions). Kept small and
# stable — the goal is signal, not coverage.
_BODY_PROSE_STOPWORDS = frozenset({
    "the", "of", "and", "in", "to", "that", "this", "with", "as", "for",
    "we", "was", "were", "be", "is", "are", "an", "by", "on", "from",
    "their", "have", "has", "had", "but", "not", "or", "which", "these",
    "our", "its", "than", "at", "such", "between", "would", "could",
    "however", "therefore", "thus", "while", "when",
})


def _line_is_body_prose(line: str) -> bool:
    """True if ``line`` looks like body prose rather than table cell content.

    Table cells from pdftotext linearization are typically short fragments
    (column header, numeric value, "Mean (SD)"). Table notes start with
    ``Note:`` or ``Notes:``. Body prose paragraphs that bleed past the
    table boundary are long, sentence-shaped, and stopword-dense.

    Guarded against measurement-scale items (e.g. ``"The offender has
    apologised?" (1 = Strongly disagree to 5 = Strongly agree) (Source:
    McCullough et al., 1997)``) which can be quite long but ARE table
    cells in instrument-description tables.
    """
    s = line.strip()
    if len(s) < 80:
        return False
    # Table notes / footnotes are legitimate trailing content.
    if re.match(r"^(Note[s.:]?\s|a\s*Note\b)", s):
        return False
    # Strong "this is a table cell" signals — keep:
    #   - measurement-scale anchor like "(1 = ... to 5 = ...)"
    #   - parenthetical source attribution "(Source: ...)"
    #   - quoted instrument items (curly or straight double quotes
    #     enclosing 8+ chars — survey prompts, condition descriptions)
    if re.search(r"\(\d+\s*=", s):
        return False
    if re.search(r"\(Source[:\s]", s, re.IGNORECASE):
        return False
    # Quoted instrument items: keep only when DOUBLE-quoted content is
    # substantial (multiple runs OR ≥40 chars total). Use double-quote
    # delimiters only — single curly quotes (‘ ’) double as apostrophes
    # in academic text and a too-loose pattern would match across whole
    # paragraphs (e.g. "Kruger‘s (1999) findings, ... section in the OSF"
    # — 400 chars of body prose between an apostrophe and a quote-mark).
    # Cap each run at 160 chars so a stray unmatched double-quote can't
    # eat a runaway sentence either.
    quoted_runs = re.findall(r"[“”\"](.{4,160}?)[“”\"]", s)
    if quoted_runs and (
        len(quoted_runs) >= 2 or sum(len(q) for q in quoted_runs) >= 40
    ):
        return False
    words = re.findall(r"[A-Za-z']+", s.lower())
    if len(words) < 12:
        return False
    stopwords_hit = sum(1 for w in words if w in _BODY_PROSE_STOPWORDS)
    return stopwords_hit >= 4


def _extract_table_body_text(
    raw_text: str,
    cap: CaptionMatch,
    next_boundary: Optional[int] = None,
) -> str:
    """Pull the text following a Table caption (intended for use when
    Camelot failed to extract cells). Returns the cell content as a flat
    string — column headers, values, group labels, etc., all linearized
    by pdftotext.

    Bounds (v2.4.14 — tightened to stop body-prose bleed; handoff
    2026-05-13 Defect B):
      * Start at the end of the caption's snippet.
      * Walk line-by-line and STOP at the first of:
          - form-feed (``\\x0c`` page boundary),
          - a body-prose-looking line (``_line_is_body_prose``),
          - 1500 chars from body_start (hard cap, down from 3000),
          - ``next_boundary`` (next caption).
      * Trim trailing heading-like short lines (they're part of the next
        section, not this table).

    Both poppler (single ``\\n`` paragraph breaks) and Xpdf (``\\n\\n``)
    text channels are supported: the line-by-line walk doesn't depend on
    paragraph delimiters being doubled.
    """
    # Walk past the caption's tail to find body_start. The caption sentence
    # may continue across one or more wrapped lines; stop at the first
    # paragraph-break following a sentence terminator.
    pos = cap.char_end
    cap_tail_end = min(cap.char_end + 800, len(raw_text))
    if next_boundary is not None and next_boundary > cap.char_end:
        cap_tail_end = min(cap_tail_end, next_boundary)
    while pos < cap_tail_end:
        # Prefer \n\n (Xpdf paragraph break) when present, otherwise treat
        # a single \n as a candidate break (poppler).
        nxt2 = raw_text.find("\n\n", pos)
        nxt1 = raw_text.find("\n", pos)
        if nxt2 != -1 and nxt2 < cap_tail_end:
            nxt = nxt2
            step = 2
        elif nxt1 != -1 and nxt1 < cap_tail_end:
            nxt = nxt1
            step = 1
        else:
            pos = cap_tail_end
            break
        prev = raw_text[max(cap.char_start, nxt - 40):nxt].rstrip()
        if not prev or len(prev.split()) < 2 or re.search(
            r"[.!?][\"'\)\]]?$", prev
        ):
            pos = nxt + step
            break
        pos = nxt + step
    body_start = pos
    body_end_hard = min(body_start + 1500, len(raw_text))
    if next_boundary is not None and next_boundary > body_start:
        body_end_hard = min(body_end_hard, next_boundary)
    region = raw_text[body_start:body_end_hard]

    # Hard stop at page boundary — table cell flow doesn't survive a
    # form-feed in pdftotext output; whatever's on the next page is
    # the next page's running header / body, not this table's cells.
    ff = region.find("\x0c")
    if ff != -1:
        region = region[:ff]

    # Line-by-line walk; stop at first body-prose-looking line.
    kept: list[str] = []
    for ln in region.split("\n"):
        if _line_is_body_prose(ln):
            break
        kept.append(ln)

    # Trim trailing heading-like short lines that don't belong to this table
    # (the start of the next section). Two patterns are trimmed:
    #   * Title-Case headings without a sentence terminator
    #     (e.g. "Experimental design", "Discussion")
    #   * Numbered section headings like "3.2.3 H2: Relationship ..."
    #     even when they end with a period (their structure betrays them).
    while kept:
        last = kept[-1].strip()
        if not last:
            kept.pop()
            continue
        is_numbered_heading = bool(
            re.match(r"^\d+(?:\.\d+){1,3}\s+[A-Z]", last)
        ) and len(last) < 200
        is_titlecase_heading = (
            10 < len(last) < 50
            and not last.endswith((".", "!", "?", ":"))
            and last[0].isupper()
            and not last[0].isdigit()
            and len(last.split()) <= 6
        )
        if is_numbered_heading or is_titlecase_heading:
            kept.pop()
            continue
        break

    snippet = "\n".join(kept)
    snippet = snippet.replace("\x0c", "")
    snippet = re.sub(r"­\s+", "", snippet)
    snippet = snippet.replace("­", "")
    cleaned_lines: list[str] = []
    for ln in snippet.split("\n"):
        s = re.sub(r"[ \t]+", " ", ln).strip()
        if s:
            cleaned_lines.append(s)
    return "\n".join(cleaned_lines).strip()


def _figure_from_caption(
    cap: CaptionMatch,
    raw_text: str,
    next_boundary: Optional[int] = None,
) -> Figure:
    """Build a Figure dict from a caption match. bbox is unknown (zeros)."""
    return {
        "id": f"f{cap.number}",
        "label": cap.label,
        "page": cap.page,
        "bbox": (0.0, 0.0, 0.0, 0.0),
        "caption": _extract_caption_text(raw_text, cap, next_boundary),
    }


def _apply_placeholder(raw_text: str, captions: list[CaptionMatch]) -> str:
    """Replace each caption's line with ``[Label: caption]`` marker.

    Without pdfplumber we don't know the exact bbox of the table region; we
    mark only the caption line itself. The marker is shorter than the caption
    line so total text length doesn't grow.
    """
    if not captions:
        return raw_text
    items = sorted(
        ((c.char_start, c.char_end, c) for c in captions),
        key=lambda item: item[0],
        reverse=True,
    )
    # v2.3.0 Bug 4: bound each caption's snippet at the next caption's start.
    by_start = sorted(captions, key=lambda c: c.char_start)
    next_boundary_by_id: dict[int, Optional[int]] = {}
    for i, c in enumerate(by_start):
        next_boundary_by_id[id(c)] = (
            by_start[i + 1].char_start if i + 1 < len(by_start) else None
        )
    out = raw_text
    for start, end, cap in items:
        snippet = _extract_caption_text(raw_text, cap, next_boundary_by_id.get(id(cap)))
        # Build "[Label: caption]" marker. Use the snippet (already cleaned).
        if cap.label and cap.label in snippet:
            desc = snippet[len(cap.label):].lstrip(" .:—–-,")
        else:
            desc = snippet
        marker = f"[{cap.label}: {desc[:120]}]" if desc else f"[{cap.label}]"
        out = out[:start] + marker + out[end:]
    return out


__all__ = [
    "TABLE_EXTRACTION_VERSION",
    "TableTextMode",
    "StructuredResult",
    "extract_pdf_structured",
]
