import typer
import sys
from . import to_extended, to_ascii

app = typer.Typer(add_completion=False)

@app.command()
def main(text: str):
    """Toggle text between ASCII and Extended ASCII."""
    if any(ord(c) >= 128 for c in text):
        print(to_ascii(text))
    else:
        print(to_extended(text))

def entry_point():
    if len(sys.argv) == 1:
        app(["--help"])
    else:
        app()

if __name__ == "__main__":
    entry_point()
