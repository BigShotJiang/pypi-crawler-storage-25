def to_extended(text):
    return "".join(chr(ord(c) | 0x80) if ord(c) < 128 else c for c in text)

def to_ascii(text):
    return "".join(chr(ord(c) & 0x7F) if 128 <= ord(c) < 256 else c for c in text)

def to_extended_unsafe(text):
    return "".join(chr(ord(c) | 0x80) for c in text)

def to_ascii_unsafe(text):
    return "".join(chr(ord(c) & 0x7F) for c in text)