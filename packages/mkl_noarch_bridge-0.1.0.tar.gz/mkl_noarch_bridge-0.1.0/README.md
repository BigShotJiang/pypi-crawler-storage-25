# mkl-noarch-bridge

A utility metapackage designed to solve the "noarch dependency" problem in the Conda ecosystem.

## Purpose

`noarch: python` packages cannot use platform selectors (like `#[x86_64]`). This package acts as a bridge:

- **On x86_64:** It pulls in `mkl`, `mkl-service`, and `sparse_dot_mkl`.
- **On ARM/others:** It installs as an empty package with no dependencies.

## Usage

Add `mkl-noarch-bridge` to your `meta.yaml` requirements to get MKL-accelerated sparse math on `x86_64` hardware while remaining a `noarch` package.

