"""In-memory repository for tests and local development."""

from __future__ import annotations

from memnon.types import IngestCursor, Observation, ObservationLevel, PeerRef, RepresentationKind


class InMemoryRepository:
    def __init__(self) -> None:
        self._observations: dict[str, Observation] = {}
        self._cursors: dict[tuple[str, str, str, str], IngestCursor] = {}
        self._representations: dict[tuple[str, str, str, str, str], tuple[str, int]] = {}

    async def ensure_schema(self) -> None:
        return None

    async def ensure_tables(self) -> None:
        return None

    async def write_observations(self, observations: list[Observation]) -> None:
        for observation in observations:
            self._observations[observation.id] = observation

    async def get_observation(self, observation_id: str) -> Observation | None:
        return self._observations.get(observation_id)

    async def list_observations(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        session_id: str | None = None,
        level: ObservationLevel | None = None,
        limit: int = 200,
    ) -> list[Observation]:
        matches = [
            observation
            for observation in self._observations.values()
            if observation.workspace_id == workspace_id
            and observation.owner.id == owner.id
            and observation.owner.kind == owner.kind
            and observation.subject.id == subject.id
            and observation.subject.kind == subject.kind
            and (session_id is None or observation.session_id == session_id)
            and (level is None or observation.level == level)
        ]
        matches.sort(key=lambda observation: observation.created_at, reverse=True)
        return matches[:limit]

    async def delete_observations(self, observation_ids: list[str]) -> None:
        for observation_id in observation_ids:
            self._observations.pop(observation_id, None)

    async def get_ingest_cursor(
        self,
        *,
        workspace_id: str,
        session_id: str,
        owner: PeerRef,
        subject: PeerRef,
    ) -> IngestCursor | None:
        return self._cursors.get(_cursor_key(workspace_id, session_id, owner, subject))

    async def upsert_ingest_cursor(self, cursor: IngestCursor) -> None:
        self._cursors[_cursor_key(cursor.workspace_id, cursor.session_id, cursor.owner, cursor.subject)] = cursor

    async def save_representation(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
        content: str,
        observation_count: int,
    ) -> None:
        self._representations[_representation_key(workspace_id, owner, subject, kind)] = (content, observation_count)

    async def get_representation(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
    ) -> tuple[str | None, int]:
        return self._representations.get(_representation_key(workspace_id, owner, subject, kind), (None, 0))

    async def list_collections(
        self,
        *,
        workspace_id: str,
        owner: PeerRef | None = None,
    ) -> list[tuple[PeerRef, PeerRef]]:
        seen: set[tuple[str, str, str, str]] = set()
        collections: list[tuple[PeerRef, PeerRef]] = []
        for observation in self._observations.values():
            if observation.workspace_id != workspace_id:
                continue
            if owner is not None and (observation.owner.id != owner.id or observation.owner.kind != owner.kind):
                continue
            key = (
                observation.owner.kind.value,
                observation.owner.id,
                observation.subject.kind.value,
                observation.subject.id,
            )
            if key not in seen:
                seen.add(key)
                collections.append((observation.owner, observation.subject))
        return collections


def _cursor_key(workspace_id: str, session_id: str, owner: PeerRef, subject: PeerRef) -> tuple[str, str, str, str]:
    return (workspace_id, session_id, f"{owner.kind.value}:{owner.id}", f"{subject.kind.value}:{subject.id}")


def _representation_key(
    workspace_id: str,
    owner: PeerRef,
    subject: PeerRef,
    kind: RepresentationKind,
) -> tuple[str, str, str, str, str]:
    return (workspace_id, owner.kind.value, owner.id, f"{subject.kind.value}:{subject.id}", kind.value)

