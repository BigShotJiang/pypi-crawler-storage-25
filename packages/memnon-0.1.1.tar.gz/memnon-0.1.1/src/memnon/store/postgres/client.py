"""Postgres-backed runtime repository."""

from __future__ import annotations

from datetime import UTC, datetime

try:
    from sqlalchemy import delete, desc, distinct, select
    from sqlalchemy.dialects.postgresql import insert
    from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
except ImportError as exc:  # pragma: no cover
    raise ImportError("Install memnon[postgres] to use the Postgres memory store.") from exc

from memnon.store.postgres.schema import (
    create_runtime_tables,
    ensure_runtime_indexes,
    ensure_runtime_schema,
)
from memnon.store.postgres.tables import memory_ingest_cursors, memory_observations, memory_representations
from memnon.types import (
    IngestCursor,
    Observation,
    ObservationAttributes,
    ObservationLevel,
    PeerRef,
    RepresentationKind,
)


class PostgresMemoryRepository:
    def __init__(self, *, database_url: str | None = None, engine: AsyncEngine | None = None) -> None:
        if engine is None and database_url is None:
            raise ValueError("database_url or engine is required")
        self._engine = engine or create_async_engine(database_url or "")
        self._session_factory = async_sessionmaker(self._engine, class_=AsyncSession, expire_on_commit=False)

    async def ensure_schema(self) -> None:
        async with self._engine.begin() as connection:
            await ensure_runtime_schema(connection)

    async def ensure_tables(self) -> None:
        async with self._engine.begin() as connection:
            await ensure_runtime_schema(connection)
            await connection.run_sync(create_runtime_tables)
            await ensure_runtime_indexes(connection)

    async def close(self) -> None:
        await self._engine.dispose()

    async def write_observations(self, observations: list[Observation]) -> None:
        if not observations:
            return
        rows = [_observation_to_row(observation) for observation in observations]
        async with self._session_factory() as session:
            await session.execute(insert(memory_observations), rows)
            await session.commit()

    async def get_observation(self, observation_id: str) -> Observation | None:
        async with self._session_factory() as session:
            row = (
                (await session.execute(select(memory_observations).where(memory_observations.c.id == observation_id)))
                .mappings()
                .first()
            )
        return _row_to_observation(row) if row is not None else None

    async def list_observations(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        session_id: str | None = None,
        level: ObservationLevel | None = None,
        limit: int = 200,
    ) -> list[Observation]:
        query = select(memory_observations).where(
            memory_observations.c.workspace_id == workspace_id,
            memory_observations.c.owner_peer_id == owner.id,
            memory_observations.c.owner_peer_kind == owner.kind.value,
            memory_observations.c.subject_peer_id == subject.id,
            memory_observations.c.subject_peer_kind == subject.kind.value,
        )
        if session_id is not None:
            query = query.where(memory_observations.c.session_id == session_id)
        if level is not None:
            query = query.where(memory_observations.c.level == level.value)
        query = query.order_by(desc(memory_observations.c.created_at)).limit(limit)
        async with self._session_factory() as session:
            rows = (await session.execute(query)).mappings().all()
        return [_row_to_observation(row) for row in rows]

    async def delete_observations(self, observation_ids: list[str]) -> None:
        if not observation_ids:
            return
        async with self._session_factory() as session:
            await session.execute(delete(memory_observations).where(memory_observations.c.id.in_(observation_ids)))
            await session.commit()

    async def get_ingest_cursor(
        self,
        *,
        workspace_id: str,
        session_id: str,
        owner: PeerRef,
        subject: PeerRef,
    ) -> IngestCursor | None:
        query = select(memory_ingest_cursors).where(
            memory_ingest_cursors.c.workspace_id == workspace_id,
            memory_ingest_cursors.c.session_id == session_id,
            memory_ingest_cursors.c.owner_peer_id == owner.id,
            memory_ingest_cursors.c.owner_peer_kind == owner.kind.value,
            memory_ingest_cursors.c.subject_peer_id == subject.id,
            memory_ingest_cursors.c.subject_peer_kind == subject.kind.value,
        )
        async with self._session_factory() as session:
            row = (await session.execute(query)).mappings().first()
        if row is None:
            return None
        return IngestCursor(
            workspace_id=row["workspace_id"],
            session_id=row["session_id"],
            owner=PeerRef(id=row["owner_peer_id"], kind=row["owner_peer_kind"]),
            subject=PeerRef(id=row["subject_peer_id"], kind=row["subject_peer_kind"]),
            content_fingerprint=row["content_fingerprint"],
            source_cursor=row["source_cursor"],
            imported_message_keys=list(row["imported_message_keys"]),
            ingested_at=row["ingested_at"],
        )

    async def upsert_ingest_cursor(self, cursor: IngestCursor) -> None:
        statement = insert(memory_ingest_cursors).values(
            workspace_id=cursor.workspace_id,
            session_id=cursor.session_id,
            owner_peer_id=cursor.owner.id,
            owner_peer_kind=cursor.owner.kind.value,
            subject_peer_id=cursor.subject.id,
            subject_peer_kind=cursor.subject.kind.value,
            content_fingerprint=cursor.content_fingerprint,
            source_cursor=cursor.source_cursor,
            imported_message_keys=cursor.imported_message_keys,
            ingested_at=cursor.ingested_at,
        )
        statement = statement.on_conflict_do_update(
            index_elements=[
                memory_ingest_cursors.c.workspace_id,
                memory_ingest_cursors.c.session_id,
                memory_ingest_cursors.c.owner_peer_id,
                memory_ingest_cursors.c.subject_peer_id,
            ],
            set_={
                "content_fingerprint": cursor.content_fingerprint,
                "source_cursor": cursor.source_cursor,
                "imported_message_keys": cursor.imported_message_keys,
                "ingested_at": cursor.ingested_at,
            },
        )
        async with self._session_factory() as session:
            await session.execute(statement)
            await session.commit()

    async def save_representation(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
        content: str,
        observation_count: int,
    ) -> None:
        now = datetime.now(UTC)
        statement = insert(memory_representations).values(
            workspace_id=workspace_id,
            owner_peer_id=owner.id,
            owner_peer_kind=owner.kind.value,
            subject_peer_id=subject.id,
            subject_peer_kind=subject.kind.value,
            kind=kind.value,
            content=content,
            observation_count=observation_count,
            updated_at=now,
        )
        statement = statement.on_conflict_do_update(
            index_elements=[
                memory_representations.c.workspace_id,
                memory_representations.c.owner_peer_id,
                memory_representations.c.subject_peer_id,
                memory_representations.c.kind,
            ],
            set_={"content": content, "observation_count": observation_count, "updated_at": now},
        )
        async with self._session_factory() as session:
            await session.execute(statement)
            await session.commit()

    async def get_representation(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
    ) -> tuple[str | None, int]:
        query = select(memory_representations.c.content, memory_representations.c.observation_count).where(
            memory_representations.c.workspace_id == workspace_id,
            memory_representations.c.owner_peer_id == owner.id,
            memory_representations.c.owner_peer_kind == owner.kind.value,
            memory_representations.c.subject_peer_id == subject.id,
            memory_representations.c.subject_peer_kind == subject.kind.value,
            memory_representations.c.kind == kind.value,
        )
        async with self._session_factory() as session:
            row = (await session.execute(query)).first()
        return (str(row[0]), int(row[1] or 0)) if row is not None else (None, 0)

    async def list_collections(
        self,
        *,
        workspace_id: str,
        owner: PeerRef | None = None,
    ) -> list[tuple[PeerRef, PeerRef]]:
        query = select(
            distinct(memory_observations.c.owner_peer_kind),
            memory_observations.c.owner_peer_id,
            memory_observations.c.subject_peer_kind,
            memory_observations.c.subject_peer_id,
        ).where(memory_observations.c.workspace_id == workspace_id)
        if owner is not None:
            query = query.where(
                memory_observations.c.owner_peer_id == owner.id,
                memory_observations.c.owner_peer_kind == owner.kind.value,
            )
        async with self._session_factory() as session:
            rows = (await session.execute(query)).all()
        return [(PeerRef(id=row[1], kind=row[0]), PeerRef(id=row[3], kind=row[2])) for row in rows]


def _observation_to_row(observation: Observation) -> dict[str, object]:
    return {
        "id": observation.id,
        "workspace_id": observation.workspace_id,
        "owner_peer_id": observation.owner.id,
        "owner_peer_kind": observation.owner.kind.value,
        "subject_peer_id": observation.subject.id,
        "subject_peer_kind": observation.subject.kind.value,
        "session_id": observation.session_id,
        "level": observation.level.value,
        "content": observation.content,
        "embedding": observation.embedding,
        "source_message_keys": observation.source_message_keys,
        "attributes": observation.attributes.model_dump(),
        "created_at": observation.created_at,
    }


def _row_to_observation(row) -> Observation:
    return Observation(
        id=row["id"],
        workspace_id=row["workspace_id"],
        owner=PeerRef(id=row["owner_peer_id"], kind=row["owner_peer_kind"]),
        subject=PeerRef(id=row["subject_peer_id"], kind=row["subject_peer_kind"]),
        session_id=row["session_id"],
        level=row["level"],
        content=row["content"],
        embedding=list(row["embedding"]) if row["embedding"] is not None else None,
        source_message_keys=list(row["source_message_keys"]),
        attributes=ObservationAttributes.model_validate(row["attributes"]),
        created_at=row["created_at"],
    )
