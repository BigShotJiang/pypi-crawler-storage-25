"""Runtime-owned Postgres table definitions."""

from __future__ import annotations

try:
    from pgvector.sqlalchemy import Vector
    from sqlalchemy import Column, DateTime, Integer, MetaData, String, Table, Text
    from sqlalchemy.dialects.postgresql import JSONB
except ImportError as exc:  # pragma: no cover
    raise ImportError("Install memnon[postgres] to use the Postgres memory store.") from exc

RUNTIME_SCHEMA = "memory_runtime"
EMBEDDING_DIMENSION = 1536

runtime_metadata = MetaData(schema=RUNTIME_SCHEMA)

memory_observations = Table(
    "memory_observations",
    runtime_metadata,
    Column("id", String, primary_key=True),
    Column("workspace_id", String, nullable=False, index=True),
    Column("owner_peer_id", String, nullable=False, index=True),
    Column("owner_peer_kind", String, nullable=False),
    Column("subject_peer_id", String, nullable=False, index=True),
    Column("subject_peer_kind", String, nullable=False),
    Column("session_id", String, nullable=False, index=True),
    Column("level", String, nullable=False),
    Column("content", Text, nullable=False),
    Column("embedding", Vector(EMBEDDING_DIMENSION), nullable=True),
    Column("source_message_keys", JSONB, nullable=False),
    Column("attributes", JSONB, nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False),
)

memory_ingest_cursors = Table(
    "memory_ingest_cursors",
    runtime_metadata,
    Column("workspace_id", String, primary_key=True),
    Column("session_id", String, primary_key=True),
    Column("owner_peer_id", String, primary_key=True),
    Column("owner_peer_kind", String, nullable=False),
    Column("subject_peer_id", String, primary_key=True),
    Column("subject_peer_kind", String, nullable=False),
    Column("content_fingerprint", String, nullable=False),
    Column("source_cursor", String, nullable=True),
    Column("imported_message_keys", JSONB, nullable=False),
    Column("ingested_at", DateTime(timezone=True), nullable=False),
)

memory_representations = Table(
    "memory_representations",
    runtime_metadata,
    Column("workspace_id", String, primary_key=True),
    Column("owner_peer_id", String, primary_key=True),
    Column("owner_peer_kind", String, nullable=False),
    Column("subject_peer_id", String, primary_key=True),
    Column("subject_peer_kind", String, nullable=False),
    Column("kind", String, primary_key=True),
    Column("content", Text, nullable=False),
    Column("observation_count", Integer, nullable=False),
    Column("updated_at", DateTime(timezone=True), nullable=False),
)

