"""Schema and index helpers for Postgres storage."""

from __future__ import annotations

from memnon.store.postgres.tables import RUNTIME_SCHEMA, runtime_metadata

try:
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import AsyncConnection
except ImportError as exc:  # pragma: no cover
    raise ImportError("Install memnon[postgres] to use the Postgres memory store.") from exc


async def ensure_runtime_schema(connection: AsyncConnection) -> None:
    await connection.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
    await connection.execute(text(f"CREATE SCHEMA IF NOT EXISTS {RUNTIME_SCHEMA}"))


async def ensure_runtime_indexes(connection: AsyncConnection) -> None:
    await connection.execute(
        text(
            f"""
            CREATE INDEX IF NOT EXISTS ix_memory_observations_owner_subject_created
            ON {RUNTIME_SCHEMA}.memory_observations
            (workspace_id, owner_peer_kind, owner_peer_id, subject_peer_kind, subject_peer_id, created_at DESC)
            """
        )
    )
    await connection.execute(
        text(
            f"""
            CREATE INDEX IF NOT EXISTS ix_memory_observations_session
            ON {RUNTIME_SCHEMA}.memory_observations (workspace_id, session_id)
            """
        )
    )
    await connection.execute(
        text(
            f"""
            CREATE INDEX IF NOT EXISTS ix_memory_observations_embedding_hnsw
            ON {RUNTIME_SCHEMA}.memory_observations USING hnsw (embedding vector_cosine_ops)
            """
        )
    )
    await connection.execute(
        text(
            f"""
            CREATE INDEX IF NOT EXISTS ix_memory_observations_content_tsv
            ON {RUNTIME_SCHEMA}.memory_observations USING gin (to_tsvector('english', content))
            """
        )
    )


def create_runtime_tables(sync_connection) -> None:
    runtime_metadata.create_all(sync_connection)

