"""Model helpers for optional Pydantic AI integrations."""

from __future__ import annotations

import os
from typing import Any

DEFAULT_OPENROUTER_MODEL = "openrouter/free"
OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"


def resolve_pydantic_ai_model(model: str | Any) -> str | Any:
    """Resolve Memnon's model shortcut strings into Pydantic AI model objects.

    Plain strings are returned unchanged so users can keep using Pydantic AI's
    native model names. Strings prefixed with ``openrouter:`` are mapped to an
    OpenAI-compatible Pydantic AI model configured for OpenRouter.
    """

    if not isinstance(model, str):
        return model
    if model == "openrouter":
        return create_openrouter_model()
    if model.startswith("openrouter:"):
        model_name = model.removeprefix("openrouter:") or DEFAULT_OPENROUTER_MODEL
        return create_openrouter_model(model_name=model_name)
    return model


def create_openrouter_model(
    *,
    model_name: str = DEFAULT_OPENROUTER_MODEL,
    api_key: str | None = None,
    base_url: str = OPENROUTER_BASE_URL,
) -> Any:
    """Create a Pydantic AI OpenAI-compatible model for OpenRouter."""

    resolved_key = api_key or os.environ.get("MEMNON_OPENROUTER_API_KEY") or os.environ.get("OPENROUTER_API_KEY")
    if not resolved_key:
        raise RuntimeError("Set OPENROUTER_API_KEY or MEMNON_OPENROUTER_API_KEY to use openrouter: models.")
    try:
        from pydantic_ai.models.openai import OpenAIChatModel
        from pydantic_ai.providers.openai import OpenAIProvider
    except ImportError as exc:  # pragma: no cover
        raise ImportError("Install memnon[pydantic-ai] to use OpenRouter models.") from exc
    return OpenAIChatModel(model_name, provider=OpenAIProvider(base_url=base_url, api_key=resolved_key))


__all__ = ["DEFAULT_OPENROUTER_MODEL", "OPENROUTER_BASE_URL", "create_openrouter_model", "resolve_pydantic_ai_model"]
