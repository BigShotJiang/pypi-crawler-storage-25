"""Optional framework adapters."""

