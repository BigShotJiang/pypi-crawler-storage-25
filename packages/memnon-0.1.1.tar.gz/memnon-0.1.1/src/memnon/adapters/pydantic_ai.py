"""Pydantic AI reasoning and session conversion adapters."""

from __future__ import annotations

from datetime import UTC, datetime
from textwrap import dedent
from typing import Any

from pydantic import BaseModel, Field

from memnon.engine import format_session_messages
from memnon.prompts import (
    AGENT_DERIVER_SYSTEM,
    DEDUCTION_SYSTEM,
    DERIVER_PROMPT,
    INDUCTION_SYSTEM,
    PAIRWISE_DERIVER_SYSTEM,
    REPRESENTATION_SYSTEM_BY_KIND,
    REPRESENTATION_USER_FRAMING,
    USER_DERIVER_SYSTEM,
)
from memnon.protocols import ReasoningBackend
from memnon.types import (
    MemoryMessage,
    MessageRole,
    Observation,
    ObservationAttributes,
    ObservationDraft,
    ObservationLevel,
    PeerKind,
    PeerRef,
    RepresentationKind,
    SessionEnvelope,
)


class FactList(BaseModel):
    facts: list[str] = Field(default_factory=list)


class DeductionItem(BaseModel):
    content: str
    premise_observation_ids: list[str] = Field(default_factory=list)


class ContradictionItem(BaseModel):
    content: str
    conflicting_observation_ids: list[str] = Field(default_factory=list)


class DeductionOutput(BaseModel):
    deductions: list[DeductionItem] = Field(default_factory=list)
    contradictions: list[ContradictionItem] = Field(default_factory=list)
    stale_observation_ids: list[str] = Field(default_factory=list)


class PatternItem(BaseModel):
    content: str
    pattern_type: str = "pattern"
    confidence: float | None = None


class InductionOutput(BaseModel):
    patterns: list[PatternItem] = Field(default_factory=list)


class RepresentationOutput(BaseModel):
    content: str = ""


class PydanticAIReasoningBackend(ReasoningBackend):
    """Reasoning backend using Pydantic AI structured output."""

    def __init__(self, *, model: Any) -> None:
        self._model = model

    async def extract_observations(
        self,
        *,
        session: SessionEnvelope,
        owner: PeerRef,
        subject: PeerRef,
    ) -> list[ObservationDraft]:
        messages = format_session_messages(session)
        if not messages.strip():
            return []
        prompt = DERIVER_PROMPT.format(
            owner_kind=owner.kind.value,
            owner_id=owner.id,
            subject_kind=subject.kind.value,
            subject_id=subject.id,
            messages=messages,
        )
        result = await self._run_structured(
            prompt=prompt,
            instructions=[_choose_deriver_system(owner, subject)],
            output_type=FactList,
        )
        message_ids = [message.id for message in session.messages]
        return [
            ObservationDraft(
                owner=owner,
                subject=subject,
                session_id=session.session_id,
                level=ObservationLevel.EXPLICIT,
                content=fact.strip(),
                source_message_keys=message_ids,
            )
            for fact in result.facts
            if fact.strip()
        ]

    async def deduce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> tuple[list[ObservationDraft], list[str]]:
        if len(observations) < 2:
            return [], []
        output = await self._run_structured(
            prompt=_observations_prompt(owner=owner, subject=subject, observations=observations),
            instructions=[DEDUCTION_SYSTEM],
            output_type=DeductionOutput,
        )
        drafts: list[ObservationDraft] = []
        for item in output.deductions:
            drafts.append(
                ObservationDraft(
                    owner=owner,
                    subject=subject,
                    session_id=observations[-1].session_id,
                    level=ObservationLevel.DEDUCTIVE,
                    content=item.content,
                    attributes=ObservationAttributes(premise_observation_ids=item.premise_observation_ids),
                )
            )
        for item in output.contradictions:
            drafts.append(
                ObservationDraft(
                    owner=owner,
                    subject=subject,
                    session_id=observations[-1].session_id,
                    level=ObservationLevel.CONTRADICTION,
                    content=item.content,
                    attributes=ObservationAttributes(conflicting_observation_ids=item.conflicting_observation_ids),
                )
            )
        return drafts, output.stale_observation_ids

    async def induce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> list[ObservationDraft]:
        if len(observations) < 3:
            return []
        output = await self._run_structured(
            prompt=_observations_prompt(owner=owner, subject=subject, observations=observations),
            instructions=[INDUCTION_SYSTEM],
            output_type=InductionOutput,
        )
        return [
            ObservationDraft(
                owner=owner,
                subject=subject,
                session_id=observations[-1].session_id,
                level=ObservationLevel.INDUCTIVE,
                content=item.content,
                attributes=ObservationAttributes(confidence=item.confidence, pattern_type=item.pattern_type),
            )
            for item in output.patterns
            if item.content.strip()
        ]

    async def build_representation(
        self,
        *,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
        observations: list[Observation],
    ) -> str:
        output = await self._run_structured(
            prompt=dedent(
                f"""\
                Build a {kind.value} for:
                owner={owner.kind.value}:{owner.id}
                subject={subject.kind.value}:{subject.id}

                {REPRESENTATION_USER_FRAMING[kind]}

                Observations:
                {_render_observations(observations)}
                """
            ),
            instructions=[REPRESENTATION_SYSTEM_BY_KIND[kind]],
            output_type=RepresentationOutput,
        )
        return output.content.strip()

    async def _run_structured(self, *, prompt: str, instructions: list[str], output_type: type[BaseModel]) -> Any:
        try:
            from pydantic_ai import Agent
        except ImportError as exc:  # pragma: no cover
            raise ImportError("Install memnon[pydantic-ai] to use PydanticAIReasoningBackend.") from exc

        agent = Agent(self._model, output_type=output_type, instructions=instructions)
        result = await agent.run(prompt)
        return result.output


def pydantic_ai_messages_to_session_envelope(
    *,
    workspace_id: str,
    session_id: str,
    source_id: str,
    messages: list[Any],
    peers: list[PeerRef],
    user_peer_id: str | None = None,
    assistant_peer_id: str | None = None,
    source_cursor: str | None = None,
    compacted_summary: str | None = None,
) -> SessionEnvelope:
    converted: list[MemoryMessage] = []
    resolved_user = user_peer_id or _first_peer(peers, {PeerKind.USER, PeerKind.CHANNEL_USER})
    resolved_assistant = assistant_peer_id or _first_peer(peers, {PeerKind.AGENT})
    for raw_index, message in enumerate(messages):
        timestamp = _message_timestamp(message)
        for part_index, part in enumerate(getattr(message, "parts", []) or []):
            class_name = type(part).__name__
            if "UserPromptPart" in class_name:
                _append_part(
                    converted,
                    session_id=session_id,
                    raw_index=raw_index,
                    part_index=part_index,
                    peer_id=resolved_user,
                    role=MessageRole.USER,
                    content=_extract_text(getattr(part, "content", "")),
                    timestamp=timestamp,
                )
            elif "TextPart" in class_name:
                _append_part(
                    converted,
                    session_id=session_id,
                    raw_index=raw_index,
                    part_index=part_index,
                    peer_id=resolved_assistant,
                    role=MessageRole.ASSISTANT,
                    content=getattr(part, "content", ""),
                    timestamp=timestamp,
                )
            elif "ToolCallPart" in class_name:
                args = part.args_as_json_str() if hasattr(part, "args_as_json_str") else str(getattr(part, "args", ""))
                _append_part(
                    converted,
                    session_id=session_id,
                    raw_index=raw_index,
                    part_index=part_index,
                    peer_id=resolved_assistant,
                    role=MessageRole.TOOL_CALL,
                    content=args,
                    timestamp=timestamp,
                    tool_name=getattr(part, "tool_name", None),
                )
            elif "ToolReturnPart" in class_name:
                _append_part(
                    converted,
                    session_id=session_id,
                    raw_index=raw_index,
                    part_index=part_index,
                    peer_id=resolved_assistant,
                    role=MessageRole.TOOL_RESULT,
                    content=str(getattr(part, "content", "")),
                    timestamp=timestamp,
                    tool_name=getattr(part, "tool_name", None),
                )
    return SessionEnvelope(
        workspace_id=workspace_id,
        session_id=session_id,
        source_id=source_id,
        peers=peers,
        messages=converted,
        source_updated_at=converted[-1].timestamp if converted else datetime.now(UTC),
        source_cursor=source_cursor,
        compacted_summary=compacted_summary,
    )


def _choose_deriver_system(owner: PeerRef, subject: PeerRef) -> str:
    if owner == subject and owner.kind == PeerKind.AGENT:
        return AGENT_DERIVER_SYSTEM
    if owner == subject:
        return USER_DERIVER_SYSTEM
    return PAIRWISE_DERIVER_SYSTEM


def _observations_prompt(*, owner: PeerRef, subject: PeerRef, observations: list[Observation]) -> str:
    return dedent(
        f"""\
        Owner: {owner.kind.value}:{owner.id}
        Subject: {subject.kind.value}:{subject.id}

        Observations:
        {_render_observations(observations)}
        """
    )


def _render_observations(observations: list[Observation]) -> str:
    return "\n".join(
        f"[{observation.id}] ({observation.level.value}) {observation.content}"
        for observation in observations
    )


def _message_timestamp(message: Any) -> datetime:
    timestamp = getattr(message, "timestamp", None)
    return timestamp if isinstance(timestamp, datetime) else datetime.now(UTC)


def _extract_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif hasattr(item, "content"):
                parts.append(str(item.content))
            elif hasattr(item, "text"):
                parts.append(str(item.text))
        return "\n".join(parts)
    return str(content)


def _first_peer(peers: list[PeerRef], kinds: set[PeerKind]) -> str | None:
    for peer in peers:
        if peer.kind in kinds:
            return peer.id
    return None


def _append_part(
    messages: list[MemoryMessage],
    *,
    session_id: str,
    raw_index: int,
    part_index: int,
    peer_id: str | None,
    role: MessageRole,
    content: str,
    timestamp: datetime,
    tool_name: str | None = None,
) -> None:
    normalized = content.strip()
    if not peer_id or not normalized:
        return
    messages.append(
        MemoryMessage(
            id=f"{session_id}:{raw_index}:{part_index}:{role.value}",
            peer_id=peer_id,
            role=role,
            content=normalized,
            timestamp=timestamp,
            tool_name=tool_name,
            token_estimate=max(1, len(normalized) // 4),
        )
    )
