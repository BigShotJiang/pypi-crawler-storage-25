"""Public runtime orchestrator."""

from __future__ import annotations

import asyncio
import hashlib
from time import perf_counter

from memnon.clamping import ClampConfig, clamp_session, rank_sessions
from memnon.engine import MemoryEngine
from memnon.protocols import EmbedderProtocol, RuntimeRepository, SearchBackend
from memnon.representations import RepresentationService
from memnon.types import (
    ConsolidateRequest,
    ConsolidateResult,
    IngestCursor,
    IngestResult,
    InitializeMode,
    InitializeRequest,
    InitializeResult,
    Observation,
    ObservationDraft,
    PeerKind,
    PeerRef,
    PromptMemoryRequest,
    PromptMemoryResult,
    RepresentationKind,
    RepresentationRefreshRequest,
    RepresentationRequest,
    RepresentationResult,
    SearchRequest,
    SearchResultBundle,
    SessionEnvelope,
)


class MemoryRuntime:
    def __init__(
        self,
        *,
        repository: RuntimeRepository,
        search_backend: SearchBackend,
        engine: MemoryEngine,
        representation_service: RepresentationService,
        embedder: EmbedderProtocol,
    ) -> None:
        self._repository = repository
        self._search_backend = search_backend
        self._engine = engine
        self._representation_service = representation_service
        self._embedder = embedder
        self._ready = False

    async def ensure_ready(self) -> None:
        if self._ready:
            return
        await self._repository.ensure_schema()
        await self._repository.ensure_tables()
        self._ready = True

    async def aclose(self) -> None:
        close = getattr(self._repository, "close", None)
        if close is not None:
            await close()

    async def initialize(self, request: InitializeRequest) -> InitializeResult:
        await self.ensure_ready()
        started = perf_counter()
        clamp_config = ClampConfig(
            target_tokens_per_session=request.target_tokens_per_session,
            max_tool_call_chars=request.max_tool_call_chars,
        )
        sessions = rank_sessions(
            request.sessions,
            max_sessions=request.max_sessions,
            prefer_live=request.prefer_live_sessions,
            prefer_compacted=request.prefer_compacted_sessions,
        )
        semaphore = asyncio.Semaphore(5)

        async def _bounded(session: SessionEnvelope) -> IngestResult:
            async with semaphore:
                return await self._ingest_session_for_targets(
                    workspace_id=request.workspace_id,
                    session=session,
                    targets=request.targets,
                    clamp_config=clamp_config,
                    mode=request.mode,
                    prefer_compacted=request.prefer_compacted_sessions,
                )

        ingest_results = await asyncio.gather(*(_bounded(session) for session in sessions), return_exceptions=True)
        result = InitializeResult()
        first_error: BaseException | None = None
        for ingest_result in ingest_results:
            if isinstance(ingest_result, BaseException):
                result.sessions_failed += 1
                if first_error is None:
                    first_error = ingest_result
                continue
            if ingest_result.already_processed:
                result.sessions_skipped += 1
            else:
                result.sessions_processed += 1
                result.observations_created += ingest_result.observations_created
        if first_error is not None:
            raise first_error
        for target in request.targets:
            representation = await self._representation_service.build(
                RepresentationRequest(
                    workspace_id=request.workspace_id,
                    owner=target,
                    kind=_default_representation_kind(target),
                )
            )
            if representation.content:
                result.representations_built += 1
        result.timing_ms = (perf_counter() - started) * 1000
        return result

    async def ingest_sessions(self, sessions: list[SessionEnvelope]) -> list[IngestResult]:
        await self.ensure_ready()
        results: list[IngestResult] = []
        for session in sessions:
            targets = [peer for peer in session.peers if peer.observe_me]
            results.append(
                await self._ingest_session_for_targets(
                    workspace_id=session.workspace_id,
                    session=session,
                    targets=targets,
                    clamp_config=ClampConfig(),
                    mode=InitializeMode.REFRESH,
                    prefer_compacted=True,
                )
            )
        return results

    async def search(self, request: SearchRequest) -> SearchResultBundle:
        await self.ensure_ready()
        query_embedding = await self._embedder.embed(request.query)
        hits = await self._search_backend.search(
            workspace_id=request.workspace_id,
            owner=request.owner,
            subject=request.subject,
            query=request.query,
            query_embedding=query_embedding,
            limit=20,
            current_session_id=request.current_session_id,
        )
        sections: list[str] = []
        used_tokens = 0
        representation_included = False
        if request.include_representation:
            representation = await self._representation_service.build(
                RepresentationRequest(
                    workspace_id=request.workspace_id,
                    owner=request.owner,
                    subject=request.subject,
                    kind=_representation_kind_for_pair(request.owner, request.subject),
                )
            )
            rep_tokens = max(1, len(representation.content) // 4)
            if representation.content and rep_tokens <= request.token_budget:
                sections.append(representation.content)
                used_tokens += rep_tokens
                representation_included = True
        observations_used = 0
        lines: list[str] = []
        for hit in hits:
            line = f"- ({hit.level.value}) {hit.content}"
            line_tokens = max(1, len(line) // 4)
            if used_tokens + line_tokens > request.token_budget:
                break
            lines.append(line)
            used_tokens += line_tokens
            observations_used += 1
        if lines:
            sections.append("\n".join(lines))
        return SearchResultBundle(
            context="\n\n".join(section for section in sections if section.strip()),
            observations_used=observations_used,
            token_count=used_tokens,
            representation_included=representation_included,
        )

    async def build_prompt_memory(self, request: PromptMemoryRequest) -> PromptMemoryResult:
        result = await self.search(
            SearchRequest(
                workspace_id=request.workspace_id,
                owner=request.owner,
                subject=request.subject,
                current_session_id=request.current_session_id,
                query=request.query,
                token_budget=request.token_budget,
                include_representation=request.include_representation,
            )
        )
        return PromptMemoryResult(**result.model_dump())

    async def get_representation(self, request: RepresentationRequest) -> RepresentationResult:
        await self.ensure_ready()
        return await self._representation_service.build(request)

    async def refresh_representations(self, request: RepresentationRefreshRequest) -> int:
        await self.ensure_ready()
        owners = request.owners or []
        refreshed = 0
        for owner in owners:
            result = await self._representation_service.build(
                RepresentationRequest(
                    workspace_id=request.workspace_id,
                    owner=owner,
                    kind=_default_representation_kind(owner),
                )
            )
            if result.content:
                refreshed += 1
        return refreshed

    async def consolidate(self, request: ConsolidateRequest) -> ConsolidateResult:
        await self.ensure_ready()
        started = perf_counter()
        collections = await self._repository.list_collections(workspace_id=request.workspace_id, owner=request.owner)
        result = ConsolidateResult()
        for owner, subject in collections:
            if request.subject is not None and (
                subject.id != request.subject.id or subject.kind != request.subject.kind
            ):
                continue
            observations = await self._repository.list_observations(
                workspace_id=request.workspace_id,
                owner=owner,
                subject=subject,
                session_id=request.session_id,
                limit=200,
            )
            if not observations:
                continue
            deductions, stale_ids = await self._engine.deduce(
                workspace_id=request.workspace_id,
                owner=owner,
                subject=subject,
                observations=observations,
            )
            patterns = await self._engine.induce(
                workspace_id=request.workspace_id,
                owner=owner,
                subject=subject,
                observations=observations,
            )
            new_observations = await self._drafts_to_observations(
                workspace_id=request.workspace_id,
                drafts=[*deductions, *patterns],
            )
            if stale_ids:
                await self._repository.delete_observations(stale_ids)
                await self._search_backend.remove(stale_ids)
                result.stale_removed += len(stale_ids)
            if new_observations:
                await self._repository.write_observations(new_observations)
                await self._search_backend.index(new_observations)
            result.deductions_created += sum(
                1 for observation in new_observations if observation.level.value == "deductive"
            )
            result.contradictions_found += sum(
                1 for observation in new_observations if observation.level.value == "contradiction"
            )
            result.patterns_found += sum(
                1 for observation in new_observations if observation.level.value == "inductive"
            )
        result.timing_ms = (perf_counter() - started) * 1000
        return result

    async def _ingest_session_for_targets(
        self,
        *,
        workspace_id: str,
        session: SessionEnvelope,
        targets: list[PeerRef],
        clamp_config: ClampConfig,
        mode: InitializeMode,
        prefer_compacted: bool,
    ) -> IngestResult:
        started = perf_counter()
        clamped_session, _stats = clamp_session(session, clamp_config, prefer_compacted=prefer_compacted)
        observations_to_write: list[Observation] = []
        cursor_updated = False
        any_processed = False
        fingerprint = _content_fingerprint(clamped_session)
        for owner, subject in _build_owner_subject_pairs(clamped_session, targets):
            cursor = await self._repository.get_ingest_cursor(
                workspace_id=workspace_id,
                session_id=clamped_session.session_id,
                owner=owner,
                subject=subject,
            )
            if (
                mode != InitializeMode.BACKFILL
                and cursor is not None
                and cursor.content_fingerprint == fingerprint
                and cursor.source_cursor == clamped_session.source_cursor
            ):
                continue
            outcome = await self._engine.extract_observations(session=clamped_session, owner=owner, subject=subject)
            observations_to_write.extend(
                await self._drafts_to_observations(workspace_id=workspace_id, drafts=outcome.observations)
            )
            await self._repository.upsert_ingest_cursor(
                IngestCursor(
                    workspace_id=workspace_id,
                    session_id=clamped_session.session_id,
                    owner=owner,
                    subject=subject,
                    content_fingerprint=fingerprint,
                    source_cursor=clamped_session.source_cursor,
                    imported_message_keys=[message.id for message in clamped_session.messages],
                )
            )
            cursor_updated = True
            any_processed = True
        if observations_to_write:
            await self._repository.write_observations(observations_to_write)
            await self._search_backend.index(observations_to_write)
        return IngestResult(
            session_id=session.session_id,
            observations_created=len(observations_to_write),
            already_processed=not any_processed,
            cursor_updated=cursor_updated,
            timing_ms=(perf_counter() - started) * 1000,
        )

    async def _drafts_to_observations(self, *, workspace_id: str, drafts: list[ObservationDraft]) -> list[Observation]:
        observations: list[Observation] = []
        for draft in drafts:
            observations.append(
                Observation(
                    workspace_id=workspace_id,
                    owner=draft.owner,
                    subject=draft.subject,
                    session_id=draft.session_id,
                    level=draft.level,
                    content=draft.content,
                    embedding=await self._embedder.embed(draft.content),
                    source_message_keys=draft.source_message_keys,
                    attributes=draft.attributes,
                )
            )
        return observations


def _content_fingerprint(session: SessionEnvelope) -> str:
    parts: list[str] = [session.session_id, session.source_cursor or ""]
    for message in session.messages:
        parts.append(
            "|".join(
                [
                    message.id,
                    message.peer_id,
                    message.role.value,
                    message.tool_name or "",
                    message.content,
                ]
            )
        )
    return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()


def _build_owner_subject_pairs(session: SessionEnvelope, targets: list[PeerRef]) -> list[tuple[PeerRef, PeerRef]]:
    available_peers = {peer.id: peer for peer in session.peers}
    pairs: list[tuple[PeerRef, PeerRef]] = []
    seen: set[tuple[str, str, str, str]] = set()
    for target in targets:
        owner = available_peers.get(target.id)
        if owner is None:
            continue
        key = (owner.kind.value, owner.id, owner.kind.value, owner.id)
        if key not in seen:
            pairs.append((owner, owner))
            seen.add(key)
        if owner.kind != PeerKind.AGENT:
            continue
        for subject in session.peers:
            if subject.id == owner.id or not subject.observe_me:
                continue
            pair_key = (owner.kind.value, owner.id, subject.kind.value, subject.id)
            if pair_key not in seen:
                pairs.append((owner, subject))
                seen.add(pair_key)
    return pairs


def _default_representation_kind(peer: PeerRef) -> RepresentationKind:
    if peer.kind == PeerKind.AGENT:
        return RepresentationKind.AGENT_OPERATING_PROFILE
    return RepresentationKind.USER_PROFILE


def _representation_kind_for_pair(owner: PeerRef, subject: PeerRef) -> RepresentationKind:
    if owner != subject:
        return RepresentationKind.PAIRWISE_VIEW
    return _default_representation_kind(owner)
