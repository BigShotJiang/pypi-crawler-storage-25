"""Representation building and caching."""

from __future__ import annotations

from memnon.engine import MemoryEngine
from memnon.protocols import RuntimeRepository
from memnon.types import (
    Observation,
    ObservationLevel,
    PeerRef,
    RepresentationKind,
    RepresentationRequest,
    RepresentationResult,
)


def _fallback_representation(
    *,
    owner: PeerRef,
    subject: PeerRef,
    kind: RepresentationKind,
    observations: list[Observation],
) -> str:
    header = f"{kind.value} for {owner.kind.value}:{owner.id} about {subject.kind.value}:{subject.id}"
    lines = [header]
    for observation in observations[:20]:
        lines.append(f"- ({observation.level.value}) {observation.content}")
    if len(lines) == 1:
        lines.append("- No observations available.")
    return "\n".join(lines)


def _prepare_observations(observations: list[Observation]) -> list[Observation]:
    prioritized = [
        observation
        for observation in observations
        if observation.level in {ObservationLevel.EXPLICIT, ObservationLevel.INDUCTIVE}
    ]
    if not prioritized:
        prioritized = [
            observation
            for observation in observations
            if observation.level != ObservationLevel.CONTRADICTION
        ]
    if not prioritized:
        prioritized = observations
    selected: list[Observation] = []
    seen_content: set[str] = set()
    for observation in prioritized:
        key = observation.content.strip().lower()
        if not key or key in seen_content:
            continue
        seen_content.add(key)
        selected.append(observation)
        if len(selected) >= 120:
            break
    return selected


class RepresentationService:
    def __init__(self, *, repository: RuntimeRepository, engine: MemoryEngine) -> None:
        self._repository = repository
        self._engine = engine

    async def build(self, request: RepresentationRequest) -> RepresentationResult:
        cached_content, cached_count = await self._repository.get_representation(
            workspace_id=request.workspace_id,
            owner=request.owner,
            subject=request.subject,
            kind=request.kind,
        )
        observations = await self._repository.list_observations(
            workspace_id=request.workspace_id,
            owner=request.owner,
            subject=request.subject,
            limit=200,
        )
        prepared = _prepare_observations(observations)
        if cached_content is not None and cached_count == len(prepared):
            return RepresentationResult(
                content=cached_content,
                kind=request.kind,
                observation_count=len(prepared),
                cached=True,
            )
        if prepared:
            content = await self._engine.build_representation(
                owner=request.owner,
                subject=request.subject,
                kind=request.kind,
                observations=prepared,
            )
        else:
            content = _fallback_representation(
                owner=request.owner,
                subject=request.subject,
                kind=request.kind,
                observations=prepared,
            )
        await self._repository.save_representation(
            workspace_id=request.workspace_id,
            owner=request.owner,
            subject=request.subject,
            kind=request.kind,
            content=content,
            observation_count=len(prepared),
        )
        return RepresentationResult(
            content=content,
            kind=request.kind,
            observation_count=len(prepared),
            cached=False,
        )
