"""Memnon command line interface."""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Annotated

import typer
from pydantic import ValidationError
from rich.console import Console
from rich.table import Table

from memnon.factory import create_memory_runtime
from memnon.types import (
    InitializeMode,
    InitializeRequest,
    PeerKind,
    PeerRef,
    RepresentationKind,
    RepresentationRequest,
    SearchRequest,
    SessionEnvelope,
)

app = typer.Typer(no_args_is_help=True, help="Memnon agent memory runtime")
schema_app = typer.Typer(no_args_is_help=True, help="Postgres schema commands")
ingest_app = typer.Typer(no_args_is_help=True, help="Ingest memory source data")
representation_app = typer.Typer(no_args_is_help=True, help="Representation commands")
app.add_typer(schema_app, name="schema")
app.add_typer(ingest_app, name="ingest")
app.add_typer(representation_app, name="representation")

console = Console()


@schema_app.command("init")
def schema_init(
    database_url: Annotated[
        str | None,
        typer.Option("--database-url", "-d", envvar="MEMNON_DATABASE_URL", help="SQLAlchemy async Postgres URL"),
    ] = None,
) -> None:
    """Create Memnon's Postgres schema, tables, and indexes."""
    runtime = _postgres_runtime(database_url)
    asyncio.run(_ensure_ready_and_close(runtime))
    console.print("[green]Memnon schema is ready.[/green]")


@ingest_app.command("session")
def ingest_session(
    path: Annotated[Path, typer.Argument(help="Path to a SessionEnvelope JSON file")],
    database_url: Annotated[
        str | None,
        typer.Option("--database-url", "-d", envvar="MEMNON_DATABASE_URL", help="SQLAlchemy async Postgres URL"),
    ] = None,
    model: Annotated[
        str | None,
        typer.Option("--model", "-m", envvar="MEMNON_MODEL", help="Optional Pydantic AI model for reasoning"),
    ] = None,
    target: Annotated[
        list[str] | None,
        typer.Option("--target", "-t", help="Peer to ingest, e.g. user:user-1. May be repeated."),
    ] = None,
    mode: Annotated[
        InitializeMode,
        typer.Option("--mode", help="Initialize mode: bootstrap, refresh, or backfill"),
    ] = InitializeMode.REFRESH,
) -> None:
    """Ingest a normalized SessionEnvelope JSON document."""
    session = _load_session(path)
    targets = (
        [_parse_peer_ref(item) for item in target]
        if target
        else [peer for peer in session.peers if peer.observe_me]
    )
    runtime = _postgres_runtime(database_url, model=model)
    result = asyncio.run(
        _initialize_and_close(
            runtime,
            InitializeRequest(
                workspace_id=session.workspace_id,
                targets=targets,
                sessions=[session],
                mode=mode,
            ),
        )
    )
    table = Table("Metric", "Value")
    table.add_row("sessions_processed", str(result.sessions_processed))
    table.add_row("sessions_skipped", str(result.sessions_skipped))
    table.add_row("observations_created", str(result.observations_created))
    table.add_row("representations_built", str(result.representations_built))
    console.print(table)


@app.command("search")
def search(
    query: Annotated[str, typer.Argument(help="Search query")],
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace id")],
    owner: Annotated[str, typer.Option("--owner", "-o", help="Owner peer, e.g. user:user-1")],
    subject: Annotated[
        str | None,
        typer.Option("--subject", "-s", help="Subject peer, e.g. agent:agent-1. Defaults to owner."),
    ] = None,
    database_url: Annotated[
        str | None,
        typer.Option("--database-url", "-d", envvar="MEMNON_DATABASE_URL", help="SQLAlchemy async Postgres URL"),
    ] = None,
    token_budget: Annotated[int, typer.Option("--token-budget", help="Prompt memory token budget")] = 2000,
    include_representation: Annotated[
        bool,
        typer.Option("--representation/--no-representation", help="Include cached profile context"),
    ] = True,
) -> None:
    """Search observations and print prompt-ready memory context."""
    owner_ref = _parse_peer_ref(owner)
    subject_ref = _parse_peer_ref(subject) if subject else owner_ref
    runtime = _postgres_runtime(database_url)
    result = asyncio.run(
        _search_and_close(
            runtime,
            SearchRequest(
                workspace_id=workspace,
                owner=owner_ref,
                subject=subject_ref,
                query=query,
                token_budget=token_budget,
                include_representation=include_representation,
            ),
        )
    )
    if result.context.strip():
        console.print(result.context)
    else:
        console.print("[yellow]No memory context matched.[/yellow]")


@representation_app.command("get")
def representation_get(
    workspace: Annotated[str, typer.Option("--workspace", "-w", help="Workspace id")],
    owner: Annotated[str, typer.Option("--owner", "-o", help="Owner peer, e.g. user:user-1")],
    subject: Annotated[
        str | None,
        typer.Option("--subject", "-s", help="Subject peer. Defaults to owner."),
    ] = None,
    kind: Annotated[
        RepresentationKind,
        typer.Option("--kind", help="Representation kind"),
    ] = RepresentationKind.USER_PROFILE,
    database_url: Annotated[
        str | None,
        typer.Option("--database-url", "-d", envvar="MEMNON_DATABASE_URL", help="SQLAlchemy async Postgres URL"),
    ] = None,
    model: Annotated[
        str | None,
        typer.Option("--model", "-m", envvar="MEMNON_MODEL", help="Optional Pydantic AI model for representation"),
    ] = None,
) -> None:
    """Build or fetch a cached representation."""
    owner_ref = _parse_peer_ref(owner)
    subject_ref = _parse_peer_ref(subject) if subject else owner_ref
    runtime = _postgres_runtime(database_url, model=model)
    result = asyncio.run(
        _representation_and_close(
            runtime,
            RepresentationRequest(
                workspace_id=workspace,
                owner=owner_ref,
                subject=subject_ref,
                kind=kind,
            ),
        )
    )
    console.print(result.content)


def _postgres_runtime(database_url: str | None, *, model: str | None = None):
    resolved = database_url or os.environ.get("MEMNON_DATABASE_URL")
    if not resolved:
        console.print("[red]Missing database URL. Set MEMNON_DATABASE_URL or pass --database-url.[/red]")
        raise typer.Exit(2)
    resolved_model = model or os.environ.get("MEMNON_MODEL")
    if not resolved_model:
        return create_memory_runtime(mode="postgres", database_url=resolved)
    try:
        from memnon.adapters.models import resolve_pydantic_ai_model
        from memnon.adapters.pydantic_ai import PydanticAIReasoningBackend
    except ImportError as exc:
        console.print("[red]Install memnon[pydantic-ai] to use MEMNON_MODEL.[/red]")
        raise typer.Exit(2) from exc
    return create_memory_runtime(
        mode="postgres",
        database_url=resolved,
        reasoning_backend=PydanticAIReasoningBackend(model=resolve_pydantic_ai_model(resolved_model)),
    )


async def _ensure_ready_and_close(runtime) -> None:
    try:
        await runtime.ensure_ready()
    finally:
        await runtime.aclose()


async def _initialize_and_close(runtime, request: InitializeRequest):
    try:
        return await runtime.initialize(request)
    finally:
        await runtime.aclose()


async def _search_and_close(runtime, request: SearchRequest):
    try:
        return await runtime.search(request)
    finally:
        await runtime.aclose()


async def _representation_and_close(runtime, request: RepresentationRequest):
    try:
        return await runtime.get_representation(request)
    finally:
        await runtime.aclose()


def _load_session(path: Path) -> SessionEnvelope:
    try:
        payload = json.loads(path.read_text())
        return SessionEnvelope.model_validate(payload)
    except FileNotFoundError:
        console.print(f"[red]Session file not found: {path}[/red]")
        raise typer.Exit(2) from None
    except (json.JSONDecodeError, ValidationError) as exc:
        console.print(f"[red]Invalid SessionEnvelope JSON: {exc}[/red]")
        raise typer.Exit(2) from exc


def _parse_peer_ref(value: str | None) -> PeerRef:
    if not value or ":" not in value:
        console.print("[red]Peer refs must use '<kind>:<id>', e.g. user:user-1.[/red]")
        raise typer.Exit(2)
    kind, peer_id = value.split(":", 1)
    try:
        return PeerRef(id=peer_id, kind=PeerKind(kind))
    except ValueError as exc:
        valid = ", ".join(kind.value for kind in PeerKind)
        console.print(f"[red]Invalid peer kind '{kind}'. Expected one of: {valid}.[/red]")
        raise typer.Exit(2) from exc


__all__ = ["app"]
