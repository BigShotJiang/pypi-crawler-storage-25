"""Prompt templates for reasoning adapters."""

from __future__ import annotations

from textwrap import dedent

from memnon.types import RepresentationKind

USER_DERIVER_SYSTEM = dedent(
    """\
    You extract explicit atomic facts about a human user from a conversation.
    Each fact must be a self-contained sentence that remains useful across
    future conversations. Focus on identity, durable context, preferences,
    constraints, goals, and working style. Do not infer.
    """
)

AGENT_DERIVER_SYSTEM = dedent(
    """\
    You extract explicit atomic facts about an agent's operating behavior from
    a conversation. Each fact must be a short directive the agent should follow
    in future sessions. Focus on tool rules, self-corrections, mistakes to
    avoid, formatting rules, and durable operating constraints.
    """
)

PAIRWISE_DERIVER_SYSTEM = dedent(
    """\
    You extract explicit durable facts from a conversation that belong in the
    owner's memory space about the subject. Focus on stable preferences,
    recurring instructions, and durable interpersonal context.
    """
)

DERIVER_PROMPT = dedent(
    """\
    Extract explicit atomic facts from these messages.

    You are extracting facts for owner={owner_kind}:{owner_id}
    about subject={subject_kind}:{subject_id}.

    Return a JSON object with a single field `facts`, a list of strings.

    Messages:
    {messages}
    """
)

DEDUCTION_SYSTEM = dedent(
    """\
    Given stored observations, derive logical implications, contradictions, and
    stale observations. Return JSON with `deductions`, `contradictions`, and
    `stale_observation_ids`.
    """
)

INDUCTION_SYSTEM = dedent(
    """\
    Given stored observations, find recurring durable patterns. Return JSON
    with `patterns`, each with `content`, `pattern_type`, and `confidence`.
    """
)

USER_PROFILE_REPR_SYSTEM = dedent(
    """\
    Build a concise user profile from durable observations. Group related facts
    under clear headings and omit one-off task details.
    """
)

AGENT_PROFILE_REPR_SYSTEM = dedent(
    """\
    Build a concise operating profile for an AI agent. Write entries as
    actionable directives, grouped under clear headings. Omit task-specific
    details that do not generalize.
    """
)

PAIRWISE_REPR_SYSTEM = dedent(
    """\
    Build a concise relationship view from stored observations. Focus on stable
    preferences, recurring expectations, and durable interpersonal context.
    """
)

REPRESENTATION_SYSTEM_BY_KIND: dict[RepresentationKind, str] = {
    RepresentationKind.USER_PROFILE: USER_PROFILE_REPR_SYSTEM,
    RepresentationKind.AGENT_OPERATING_PROFILE: AGENT_PROFILE_REPR_SYSTEM,
    RepresentationKind.PAIRWISE_VIEW: PAIRWISE_REPR_SYSTEM,
}

REPRESENTATION_USER_FRAMING: dict[RepresentationKind, str] = {
    RepresentationKind.USER_PROFILE: "This profile will be injected into an agent prompt.",
    RepresentationKind.AGENT_OPERATING_PROFILE: "This profile will be injected into the agent's own instructions.",
    RepresentationKind.PAIRWISE_VIEW: "This view captures durable context between the owner and subject.",
}

