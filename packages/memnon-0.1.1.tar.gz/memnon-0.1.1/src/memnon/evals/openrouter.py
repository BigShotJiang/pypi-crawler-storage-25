"""OpenRouter-backed memory smoke eval helpers."""

from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel
from pydantic_evals import Case, Dataset
from pydantic_evals.evaluators import Evaluator, EvaluatorContext

from memnon import MemoryMessage, MessageRole, PeerKind, PeerRef, SessionEnvelope
from memnon.adapters.models import DEFAULT_OPENROUTER_MODEL, resolve_pydantic_ai_model
from memnon.adapters.pydantic_ai import PydanticAIReasoningBackend
from memnon.factory import create_memory_runtime
from memnon.types import InitializeRequest, RepresentationRequest, SearchRequest


class MemoryEvalInput(BaseModel):
    user_text: str
    query: str
    expected_terms: list[str]


class MemoryEvalOutput(BaseModel):
    observations_created: int
    representations_built: int
    search_context: str
    profile: str


@dataclass
class MemorySignalEvaluator(Evaluator[MemoryEvalInput, MemoryEvalOutput, Any]):
    def evaluate(self, ctx: EvaluatorContext[MemoryEvalInput, MemoryEvalOutput, Any]) -> dict[str, bool | int]:
        combined = f"{ctx.output.search_context}\n{ctx.output.profile}".lower()
        return {
            "created_observations": ctx.output.observations_created > 0,
            "built_profile": ctx.output.representations_built > 0 and bool(ctx.output.profile.strip()),
            "search_returned_context": bool(ctx.output.search_context.strip()),
            "matched_expected_terms": sum(term.lower() in combined for term in ctx.inputs.expected_terms),
        }


async def run_memory_case(inputs: MemoryEvalInput, *, model: str | None = None) -> MemoryEvalOutput:
    user = PeerRef(id="user-openrouter", kind=PeerKind.USER)
    agent = PeerRef(id="agent-memnon", kind=PeerKind.AGENT, observe_others=True)
    session = SessionEnvelope(
        workspace_id="bench-openrouter",
        session_id="thread-openrouter-1",
        source_id="bench",
        peers=[user, agent],
        messages=[
            MemoryMessage(
                id="thread-openrouter-1:m1",
                peer_id=user.id,
                role=MessageRole.USER,
                content=inputs.user_text,
                timestamp=datetime.now(UTC),
            )
        ],
        source_cursor="1",
    )
    resolved_model = model or os.environ.get("MEMNON_OPENROUTER_MODEL") or DEFAULT_OPENROUTER_MODEL
    backend = PydanticAIReasoningBackend(model=resolve_pydantic_ai_model(f"openrouter:{resolved_model}"))
    runtime = create_memory_runtime(mode="test", reasoning_backend=backend)
    try:
        initialized = await runtime.initialize(
            InitializeRequest(workspace_id=session.workspace_id, targets=[user], sessions=[session])
        )
        searched = await runtime.search(
            SearchRequest(workspace_id=session.workspace_id, owner=user, query=inputs.query, token_budget=600)
        )
        profile = await runtime.get_representation(
            RepresentationRequest(workspace_id=session.workspace_id, owner=user)
        )
        return MemoryEvalOutput(
            observations_created=initialized.observations_created,
            representations_built=initialized.representations_built,
            search_context=searched.context,
            profile=profile.content,
        )
    finally:
        await runtime.aclose()


def build_dataset() -> Dataset[MemoryEvalInput, MemoryEvalOutput, Any]:
    return Dataset(
        name="memnon-openrouter-smoke",
        cases=[
            Case(
                name="preference-recall-and-profile",
                inputs=MemoryEvalInput(
                    user_text=(
                        "For future planning chats, remember that I prefer short bullet summaries, "
                        "risk notes first, and concrete next actions at the end."
                    ),
                    query="How should I format planning updates for this user?",
                    expected_terms=["bullet", "risk", "next"],
                ),
            )
        ],
        evaluators=[MemorySignalEvaluator()],
    )


__all__ = [
    "MemoryEvalInput",
    "MemoryEvalOutput",
    "MemorySignalEvaluator",
    "build_dataset",
    "run_memory_case",
]
