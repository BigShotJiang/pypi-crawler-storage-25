"""Optional Memnon eval helpers."""
