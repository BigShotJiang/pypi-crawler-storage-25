"""Hybrid retrieval using reciprocal rank fusion."""

from __future__ import annotations

from typing import Protocol

from memnon.types import PeerRef, SearchHit


class SearchLeg(Protocol):
    async def search(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        query: str,
        query_embedding: list[float],
        limit: int,
        current_session_id: str | None = None,
    ) -> list[SearchHit]: ...


class HybridSearch:
    def __init__(
        self,
        *,
        vector_leg: SearchLeg,
        lexical_leg: SearchLeg,
        vector_weight: float = 0.6,
        lexical_weight: float = 0.4,
        rrf_k: int = 60,
    ) -> None:
        self._vector_leg = vector_leg
        self._lexical_leg = lexical_leg
        self._vector_weight = vector_weight
        self._lexical_weight = lexical_weight
        self._rrf_k = rrf_k

    async def index(self, observations: list[object]) -> None:
        return None

    async def remove(self, observation_ids: list[str]) -> None:
        return None

    async def search(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        query: str,
        query_embedding: list[float],
        limit: int = 20,
        current_session_id: str | None = None,
    ) -> list[SearchHit]:
        vector_hits = await self._vector_leg.search(
            workspace_id=workspace_id,
            owner=owner,
            subject=subject,
            query=query,
            query_embedding=query_embedding,
            limit=limit,
            current_session_id=current_session_id,
        )
        lexical_hits = await self._lexical_leg.search(
            workspace_id=workspace_id,
            owner=owner,
            subject=subject,
            query=query,
            query_embedding=query_embedding,
            limit=limit,
            current_session_id=current_session_id,
        )
        scores: dict[str, float] = {}
        lookup: dict[str, SearchHit] = {}
        for rank, hit in enumerate(vector_hits, start=1):
            scores[hit.observation_id] = scores.get(hit.observation_id, 0.0) + self._vector_weight / (
                self._rrf_k + rank
            )
            lookup[hit.observation_id] = hit
        for rank, hit in enumerate(lexical_hits, start=1):
            scores[hit.observation_id] = scores.get(hit.observation_id, 0.0) + self._lexical_weight / (
                self._rrf_k + rank
            )
            lookup[hit.observation_id] = hit
        if current_session_id:
            for observation_id, hit in lookup.items():
                if hit.session_id == current_session_id:
                    scores[observation_id] = scores.get(observation_id, 0.0) + 0.01
        ordered_ids = sorted(scores, key=lambda observation_id: scores[observation_id], reverse=True)
        return [
            lookup[observation_id].model_copy(update={"score": scores[observation_id]})
            for observation_id in ordered_ids[:limit]
        ]
