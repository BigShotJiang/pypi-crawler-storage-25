"""In-memory search backend for tests and local development."""

from __future__ import annotations

import math
import re

from memnon.search.hybrid import HybridSearch
from memnon.types import Observation, PeerRef, SearchHit


def _tokenize(text: str) -> list[str]:
    return [token for token in re.split(r"[^a-zA-Z0-9_]+", text.lower()) if token]


def _cosine_similarity(left: list[float], right: list[float]) -> float:
    if not left or not right:
        return 0.0
    dot = sum(a * b for a, b in zip(left, right, strict=False))
    left_norm = math.sqrt(sum(value * value for value in left))
    right_norm = math.sqrt(sum(value * value for value in right))
    if left_norm == 0.0 or right_norm == 0.0:
        return 0.0
    return dot / (left_norm * right_norm)


class MemoryVectorLeg:
    def __init__(self) -> None:
        self._observations: dict[str, Observation] = {}

    async def index(self, observations: list[Observation]) -> None:
        for observation in observations:
            self._observations[observation.id] = observation

    async def remove(self, observation_ids: list[str]) -> None:
        for observation_id in observation_ids:
            self._observations.pop(observation_id, None)

    async def search(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        query: str,
        query_embedding: list[float],
        limit: int,
        current_session_id: str | None = None,
    ) -> list[SearchHit]:
        hits: list[SearchHit] = []
        for observation in self._observations.values():
            if not _matches(observation, workspace_id=workspace_id, owner=owner, subject=subject):
                continue
            score = _cosine_similarity(query_embedding, observation.embedding or [])
            if score > 0.0:
                hits.append(_hit(observation, score))
        hits.sort(key=lambda hit: hit.score, reverse=True)
        return hits[:limit]


class MemoryLexicalLeg:
    def __init__(self) -> None:
        self._observations: dict[str, Observation] = {}

    async def index(self, observations: list[Observation]) -> None:
        for observation in observations:
            self._observations[observation.id] = observation

    async def remove(self, observation_ids: list[str]) -> None:
        for observation_id in observation_ids:
            self._observations.pop(observation_id, None)

    async def search(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        query: str,
        query_embedding: list[float],
        limit: int,
        current_session_id: str | None = None,
    ) -> list[SearchHit]:
        query_tokens = set(_tokenize(query))
        hits: list[SearchHit] = []
        for observation in self._observations.values():
            if not _matches(observation, workspace_id=workspace_id, owner=owner, subject=subject):
                continue
            overlap = len(query_tokens & set(_tokenize(observation.content)))
            if overlap:
                hits.append(_hit(observation, overlap / max(1, len(query_tokens))))
        hits.sort(key=lambda hit: hit.score, reverse=True)
        return hits[:limit]


class InMemorySearch:
    def __init__(self) -> None:
        self._vector_leg = MemoryVectorLeg()
        self._lexical_leg = MemoryLexicalLeg()
        self._hybrid = HybridSearch(vector_leg=self._vector_leg, lexical_leg=self._lexical_leg)

    async def index(self, observations: list[Observation]) -> None:
        await self._vector_leg.index(observations)
        await self._lexical_leg.index(observations)

    async def remove(self, observation_ids: list[str]) -> None:
        await self._vector_leg.remove(observation_ids)
        await self._lexical_leg.remove(observation_ids)

    async def search(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        query: str,
        query_embedding: list[float],
        limit: int = 20,
        current_session_id: str | None = None,
    ) -> list[SearchHit]:
        return await self._hybrid.search(
            workspace_id=workspace_id,
            owner=owner,
            subject=subject,
            query=query,
            query_embedding=query_embedding,
            limit=limit,
            current_session_id=current_session_id,
        )


def _matches(observation: Observation, *, workspace_id: str, owner: PeerRef, subject: PeerRef) -> bool:
    return (
        observation.workspace_id == workspace_id
        and observation.owner.id == owner.id
        and observation.owner.kind == owner.kind
        and observation.subject.id == subject.id
        and observation.subject.kind == subject.kind
    )


def _hit(observation: Observation, score: float) -> SearchHit:
    return SearchHit(
        observation_id=observation.id,
        content=observation.content,
        level=observation.level,
        score=score,
        session_id=observation.session_id,
    )

