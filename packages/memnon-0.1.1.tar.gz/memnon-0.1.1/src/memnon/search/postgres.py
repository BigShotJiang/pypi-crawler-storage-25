"""Postgres vector and lexical search backends."""

from __future__ import annotations

try:
    from sqlalchemy import func, select
    from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
except ImportError as exc:  # pragma: no cover
    raise ImportError("Install memnon[postgres] to use Postgres search.") from exc

from memnon.search.hybrid import HybridSearch
from memnon.store.postgres.tables import memory_observations
from memnon.types import PeerRef, SearchHit


class PostgresVectorLeg:
    def __init__(self, *, database_url: str | None = None, engine: AsyncEngine | None = None) -> None:
        if engine is None and database_url is None:
            raise ValueError("database_url or engine is required")
        self._engine = engine or create_async_engine(database_url or "")
        self._session_factory = async_sessionmaker(self._engine, class_=AsyncSession, expire_on_commit=False)

    async def search(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        query: str,
        query_embedding: list[float],
        limit: int,
        current_session_id: str | None = None,
    ) -> list[SearchHit]:
        if not query_embedding:
            return []
        distance = memory_observations.c.embedding.cosine_distance(query_embedding)
        statement = (
            select(
                memory_observations.c.id,
                memory_observations.c.content,
                memory_observations.c.level,
                memory_observations.c.session_id,
                distance.label("distance"),
            )
            .where(
                memory_observations.c.workspace_id == workspace_id,
                memory_observations.c.owner_peer_id == owner.id,
                memory_observations.c.owner_peer_kind == owner.kind.value,
                memory_observations.c.subject_peer_id == subject.id,
                memory_observations.c.subject_peer_kind == subject.kind.value,
                memory_observations.c.embedding.is_not(None),
            )
            .order_by(distance.asc())
            .limit(limit)
        )
        async with self._session_factory() as session:
            rows = (await session.execute(statement)).all()
        return [
            SearchHit(
                observation_id=row[0],
                content=row[1],
                level=row[2],
                score=1.0 - float(row[4]),
                session_id=row[3],
            )
            for row in rows
        ]


class PostgresLexicalLeg:
    def __init__(self, *, database_url: str | None = None, engine: AsyncEngine | None = None) -> None:
        if engine is None and database_url is None:
            raise ValueError("database_url or engine is required")
        self._engine = engine or create_async_engine(database_url or "")
        self._session_factory = async_sessionmaker(self._engine, class_=AsyncSession, expire_on_commit=False)

    async def search(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        query: str,
        query_embedding: list[float],
        limit: int,
        current_session_id: str | None = None,
    ) -> list[SearchHit]:
        ts_query = func.websearch_to_tsquery("english", query)
        rank = func.ts_rank_cd(func.to_tsvector("english", memory_observations.c.content), ts_query)
        statement = (
            select(
                memory_observations.c.id,
                memory_observations.c.content,
                memory_observations.c.level,
                memory_observations.c.session_id,
                rank.label("rank"),
            )
            .where(
                memory_observations.c.workspace_id == workspace_id,
                memory_observations.c.owner_peer_id == owner.id,
                memory_observations.c.owner_peer_kind == owner.kind.value,
                memory_observations.c.subject_peer_id == subject.id,
                memory_observations.c.subject_peer_kind == subject.kind.value,
                rank > 0,
            )
            .order_by(rank.desc())
            .limit(limit)
        )
        async with self._session_factory() as session:
            rows = (await session.execute(statement)).all()
        return [
            SearchHit(
                observation_id=row[0],
                content=row[1],
                level=row[2],
                score=float(row[4]),
                session_id=row[3],
            )
            for row in rows
        ]


class PostgresHybridSearch(HybridSearch):
    def __init__(self, *, database_url: str | None = None, engine: AsyncEngine | None = None) -> None:
        super().__init__(
            vector_leg=PostgresVectorLeg(database_url=database_url, engine=engine),
            lexical_leg=PostgresLexicalLeg(database_url=database_url, engine=engine),
        )

