"""Reasoning engine wrappers and deterministic test implementations."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from time import perf_counter

from memnon.protocols import EmbedderProtocol, ReasoningBackend
from memnon.types import (
    MemoryMessage,
    MessageRole,
    Observation,
    ObservationAttributes,
    ObservationDraft,
    ObservationLevel,
    PeerKind,
    PeerRef,
    RepresentationKind,
    SessionEnvelope,
)


def format_session_messages(session: SessionEnvelope) -> str:
    lines: list[str] = []
    for message in session.messages:
        prefix = message.role.value
        if message.role in {MessageRole.TOOL_CALL, MessageRole.TOOL_RESULT}:
            prefix = f"{message.role.value}:{message.tool_name or 'unknown'}"
        lines.append(f"[{prefix}] {message.peer_id}: {message.content}")
    return "\n".join(lines)


class DeterministicEmbedder(EmbedderProtocol):
    def __init__(self, *, dimensions: int = 16) -> None:
        self._dimensions = dimensions

    async def embed(self, text: str) -> list[float]:
        vector = [0.0 for _ in range(self._dimensions)]
        for token in re.findall(r"[a-zA-Z0-9_]+", text.lower()):
            digest = hashlib.sha256(token.encode("utf-8")).digest()
            for index in range(self._dimensions):
                vector[index] += digest[index] / 255.0
        return vector


class DeterministicReasoningBackend(ReasoningBackend):
    _PAIRWISE_HINTS = (
        "prefer",
        "prefers",
        "need",
        "needs",
        "want",
        "wants",
        "always",
        "timezone",
        "format",
        "summary",
        "risk",
        "next step",
    )

    async def extract_observations(
        self,
        *,
        session: SessionEnvelope,
        owner: PeerRef,
        subject: PeerRef,
    ) -> list[ObservationDraft]:
        drafts: list[ObservationDraft] = []
        for message in session.messages:
            if message.role == MessageRole.SYSTEM:
                relevant = True
            else:
                relevant = message.peer_id == subject.id
            if not relevant:
                continue
            for sentence in _split_sentences(message):
                lowered = sentence.lower()
                if owner == subject and owner.kind == PeerKind.AGENT and not (
                    "must " in lowered or "should " in lowered or "always " in lowered
                ):
                    continue
                if owner != subject and not any(hint in lowered for hint in self._PAIRWISE_HINTS):
                    continue
                drafts.append(
                    ObservationDraft(
                        owner=owner,
                        subject=subject,
                        session_id=session.session_id,
                        level=ObservationLevel.EXPLICIT,
                        content=sentence,
                        source_message_keys=[message.id],
                    )
                )
        return drafts

    async def deduce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> tuple[list[ObservationDraft], list[str]]:
        return [], []

    async def induce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> list[ObservationDraft]:
        if owner == subject and owner.kind == PeerKind.USER and len(observations) >= 2:
            return [
                ObservationDraft(
                    owner=owner,
                    subject=subject,
                    session_id=observations[-1].session_id,
                    level=ObservationLevel.INDUCTIVE,
                    content="User has recurring stable preferences across sessions.",
                    attributes=ObservationAttributes(confidence=0.5, pattern_type="preference"),
                )
            ]
        return []

    async def build_representation(
        self,
        *,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
        observations: list[Observation],
    ) -> str:
        header = f"{kind.value} for {owner.kind.value}:{owner.id} about {subject.kind.value}:{subject.id}"
        lines = [header]
        for observation in observations[:20]:
            lines.append(f"- ({observation.level.value}) {observation.content}")
        if len(lines) == 1:
            lines.append("- No observations available.")
        return "\n".join(lines)


@dataclass(slots=True)
class ExtractionOutcome:
    observations: list[ObservationDraft]
    latency_ms: float


class MemoryEngine:
    def __init__(self, reasoning_backend: ReasoningBackend) -> None:
        self._reasoning_backend = reasoning_backend

    async def extract_observations(
        self,
        *,
        session: SessionEnvelope,
        owner: PeerRef,
        subject: PeerRef,
    ) -> ExtractionOutcome:
        started = perf_counter()
        observations = await self._reasoning_backend.extract_observations(
            session=session,
            owner=owner,
            subject=subject,
        )
        return ExtractionOutcome(observations=observations, latency_ms=(perf_counter() - started) * 1000)

    async def deduce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> tuple[list[ObservationDraft], list[str]]:
        return await self._reasoning_backend.deduce(
            workspace_id=workspace_id,
            owner=owner,
            subject=subject,
            observations=observations,
        )

    async def induce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> list[ObservationDraft]:
        return await self._reasoning_backend.induce(
            workspace_id=workspace_id,
            owner=owner,
            subject=subject,
            observations=observations,
        )

    async def build_representation(
        self,
        *,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
        observations: list[Observation],
    ) -> str:
        return await self._reasoning_backend.build_representation(
            owner=owner,
            subject=subject,
            kind=kind,
            observations=observations,
        )


def _split_sentences(message: MemoryMessage) -> list[str]:
    return [part.strip() for part in re.split(r"[.\n]+", message.content) if part.strip()]

