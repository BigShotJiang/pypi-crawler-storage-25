"""Factory helpers for creating memory runtimes."""

from __future__ import annotations

from memnon.engine import DeterministicEmbedder, DeterministicReasoningBackend, MemoryEngine
from memnon.protocols import EmbedderProtocol, ReasoningBackend
from memnon.representations import RepresentationService
from memnon.runtime import MemoryRuntime
from memnon.search.memory import InMemorySearch
from memnon.store.memory import InMemoryRepository


def create_memory_runtime(
    *,
    mode: str = "test",
    repository: object | None = None,
    search_backend: object | None = None,
    reasoning_backend: ReasoningBackend | None = None,
    embedder: EmbedderProtocol | None = None,
    database_url: str | None = None,
) -> MemoryRuntime:
    if mode == "postgres":
        from memnon.search.postgres import PostgresHybridSearch
        from memnon.store.postgres import PostgresMemoryRepository

        resolved_repository = repository or PostgresMemoryRepository(database_url=database_url)
        resolved_search = search_backend or PostgresHybridSearch(database_url=database_url)
        resolved_embedder = embedder or DeterministicEmbedder(dimensions=1536)
    elif mode == "test":
        resolved_repository = repository or InMemoryRepository()
        resolved_search = search_backend or InMemorySearch()
        resolved_embedder = embedder or DeterministicEmbedder()
    else:
        raise ValueError("mode must be 'test' or 'postgres'")

    engine = MemoryEngine(reasoning_backend or DeterministicReasoningBackend())
    representations = RepresentationService(repository=resolved_repository, engine=engine)
    return MemoryRuntime(
        repository=resolved_repository,
        search_backend=resolved_search,
        engine=engine,
        representation_service=representations,
        embedder=resolved_embedder,
    )
