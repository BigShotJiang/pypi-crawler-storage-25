"""Public data models for the Memnon memory runtime."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from uuid import uuid4

from pydantic import BaseModel, Field, model_validator


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _new_observation_id() -> str:
    return uuid4().hex


class PeerKind(StrEnum):
    USER = "user"
    AGENT = "agent"
    TASK = "task"
    CHANNEL_USER = "channel_user"
    OTHER = "other"


class MessageRole(StrEnum):
    USER = "user"
    ASSISTANT = "assistant"
    TOOL_CALL = "tool_call"
    TOOL_RESULT = "tool_result"
    SYSTEM = "system"


class ObservationLevel(StrEnum):
    EXPLICIT = "explicit"
    DEDUCTIVE = "deductive"
    INDUCTIVE = "inductive"
    CONTRADICTION = "contradiction"


class RepresentationKind(StrEnum):
    USER_PROFILE = "user_profile"
    AGENT_OPERATING_PROFILE = "agent_operating_profile"
    PAIRWISE_VIEW = "pairwise_view"


class InitializeMode(StrEnum):
    BOOTSTRAP = "bootstrap"
    REFRESH = "refresh"
    BACKFILL = "backfill"


class PeerRef(BaseModel):
    id: str
    kind: PeerKind
    observe_me: bool = True
    observe_others: bool = False


class MemoryMessage(BaseModel):
    id: str
    peer_id: str
    role: MessageRole
    content: str
    tool_name: str | None = None
    timestamp: datetime = Field(default_factory=_utc_now)
    token_estimate: int = 0


class SessionEnvelope(BaseModel):
    workspace_id: str
    session_id: str
    source_id: str
    session_kind: str = "thread"
    tags: list[str] = Field(default_factory=list)
    peers: list[PeerRef]
    messages: list[MemoryMessage]
    is_live: bool = False
    source_updated_at: datetime | None = None
    source_cursor: str | None = None
    compacted_summary: str | None = None


class ObservationAttributes(BaseModel):
    confidence: float | None = None
    premise_observation_ids: list[str] = Field(default_factory=list)
    conflicting_observation_ids: list[str] = Field(default_factory=list)
    pattern_type: str | None = None


class ObservationDraft(BaseModel):
    owner: PeerRef
    subject: PeerRef
    session_id: str
    level: ObservationLevel
    content: str
    source_message_keys: list[str] = Field(default_factory=list)
    attributes: ObservationAttributes = Field(default_factory=ObservationAttributes)


class Observation(BaseModel):
    id: str = Field(default_factory=_new_observation_id)
    workspace_id: str
    owner: PeerRef
    subject: PeerRef
    session_id: str
    level: ObservationLevel
    content: str
    embedding: list[float] | None = None
    source_message_keys: list[str] = Field(default_factory=list)
    attributes: ObservationAttributes = Field(default_factory=ObservationAttributes)
    created_at: datetime = Field(default_factory=_utc_now)


class SearchHit(BaseModel):
    observation_id: str
    content: str
    level: ObservationLevel
    score: float
    session_id: str


class ClampConfig(BaseModel):
    target_tokens_per_session: int = 12000
    max_tool_call_chars: int = 1200


class ClampStats(BaseModel):
    original_tokens: int = 0
    clamped_tokens: int = 0
    tool_calls_truncated: int = 0
    messages_dropped: int = 0
    used_compacted_summary: bool = False


class InitializeRequest(BaseModel):
    workspace_id: str
    targets: list[PeerRef]
    sessions: list[SessionEnvelope]
    mode: InitializeMode = InitializeMode.BOOTSTRAP
    max_sessions: int = 50
    target_tokens_per_session: int = 12000
    max_tool_call_chars: int = 1200
    prefer_live_sessions: bool = True
    prefer_compacted_sessions: bool = True


class InitializeResult(BaseModel):
    sessions_processed: int = 0
    sessions_skipped: int = 0
    sessions_failed: int = 0
    observations_created: int = 0
    representations_built: int = 0
    timing_ms: float = 0.0
    llm_calls: int = 0
    estimated_cost_usd: float = 0.0


class IngestResult(BaseModel):
    session_id: str
    observations_created: int = 0
    already_processed: bool = False
    cursor_updated: bool = False
    timing_ms: float = 0.0


class PromptMemoryRequest(BaseModel):
    workspace_id: str
    owner: PeerRef
    subject: PeerRef | None = None
    current_session_id: str | None = None
    query: str
    token_budget: int = 2000
    include_representation: bool = True
    include_recent_session_context: bool = True

    @model_validator(mode="after")
    def default_subject(self) -> PromptMemoryRequest:
        if self.subject is None:
            self.subject = self.owner
        return self


class PromptMemoryResult(BaseModel):
    context: str
    observations_used: int = 0
    token_count: int = 0
    representation_included: bool = False


class SearchRequest(BaseModel):
    workspace_id: str
    owner: PeerRef
    subject: PeerRef | None = None
    current_session_id: str | None = None
    query: str
    token_budget: int = 2000
    include_representation: bool = True

    @model_validator(mode="after")
    def default_subject(self) -> SearchRequest:
        if self.subject is None:
            self.subject = self.owner
        return self


class SearchResultBundle(BaseModel):
    context: str
    observations_used: int = 0
    token_count: int = 0
    representation_included: bool = False


class RepresentationRequest(BaseModel):
    workspace_id: str
    owner: PeerRef
    subject: PeerRef | None = None
    kind: RepresentationKind = RepresentationKind.USER_PROFILE

    @model_validator(mode="after")
    def default_subject(self) -> RepresentationRequest:
        if self.subject is None:
            self.subject = self.owner
        return self


class RepresentationResult(BaseModel):
    content: str
    kind: RepresentationKind
    observation_count: int = 0
    cached: bool = False


class RepresentationRefreshRequest(BaseModel):
    workspace_id: str
    owners: list[PeerRef] | None = None


class ConsolidateRequest(BaseModel):
    workspace_id: str
    owner: PeerRef | None = None
    subject: PeerRef | None = None
    session_id: str | None = None


class ConsolidateResult(BaseModel):
    deductions_created: int = 0
    contradictions_found: int = 0
    stale_removed: int = 0
    patterns_found: int = 0
    timing_ms: float = 0.0


class IngestCursor(BaseModel):
    workspace_id: str
    session_id: str
    owner: PeerRef
    subject: PeerRef
    content_fingerprint: str
    source_cursor: str | None = None
    imported_message_keys: list[str] = Field(default_factory=list)
    ingested_at: datetime = Field(default_factory=_utc_now)
