"""Pure utilities for ranking and clamping sessions before extraction."""

from __future__ import annotations

from memnon.types import ClampConfig, ClampStats, MemoryMessage, MessageRole, SessionEnvelope


def estimate_message_tokens(message: MemoryMessage) -> int:
    if message.token_estimate > 0:
        return message.token_estimate
    return max(1, len(message.content) // 4)


def estimate_session_tokens(session: SessionEnvelope) -> int:
    return sum(estimate_message_tokens(message) for message in session.messages)


def clamp_session(
    session: SessionEnvelope,
    config: ClampConfig,
    *,
    prefer_compacted: bool = True,
) -> tuple[SessionEnvelope, ClampStats]:
    original_tokens = estimate_session_tokens(session)
    if prefer_compacted and session.compacted_summary:
        summary_message = MemoryMessage(
            id=f"{session.session_id}:summary",
            peer_id="system",
            role=MessageRole.SYSTEM,
            content=session.compacted_summary,
            timestamp=session.source_updated_at,
            token_estimate=max(1, len(session.compacted_summary) // 4),
        )
        clamped = session.model_copy(update={"messages": [summary_message]})
        return clamped, ClampStats(
            original_tokens=original_tokens,
            clamped_tokens=estimate_session_tokens(clamped),
            messages_dropped=max(0, len(session.messages) - 1),
            used_compacted_summary=True,
        )

    tool_calls_truncated = 0
    messages_dropped = 0
    clamped_messages: list[MemoryMessage] = []
    for message in session.messages:
        if message.role in {MessageRole.TOOL_CALL, MessageRole.TOOL_RESULT}:
            truncated = message.content[: config.max_tool_call_chars]
            if truncated != message.content:
                tool_calls_truncated += 1
            clamped_messages.append(
                message.model_copy(
                    update={
                        "content": truncated,
                        "token_estimate": max(1, len(truncated) // 4),
                    }
                )
            )
        else:
            clamped_messages.append(message)

    while True:
        clamped = session.model_copy(update={"messages": clamped_messages})
        clamped_tokens = estimate_session_tokens(clamped)
        if clamped_tokens <= config.target_tokens_per_session or len(clamped_messages) <= 2:
            return clamped, ClampStats(
                original_tokens=original_tokens,
                clamped_tokens=clamped_tokens,
                tool_calls_truncated=tool_calls_truncated,
                messages_dropped=messages_dropped,
            )
        middle_index = len(clamped_messages) // 2
        clamped_messages.pop(middle_index)
        messages_dropped += 1


def rank_sessions(
    sessions: list[SessionEnvelope],
    *,
    max_sessions: int,
    prefer_live: bool,
    prefer_compacted: bool,
) -> list[SessionEnvelope]:
    def sort_key(session: SessionEnvelope) -> tuple[int, int, float, int]:
        live_rank = 0 if prefer_live and session.is_live else 1
        compacted_rank = 0 if prefer_compacted and session.compacted_summary else 1
        updated_at = session.source_updated_at.timestamp() if session.source_updated_at else 0.0
        return (live_rank, compacted_rank, -updated_at, -len(session.messages))

    return sorted(sessions, key=sort_key)[:max_sessions]

