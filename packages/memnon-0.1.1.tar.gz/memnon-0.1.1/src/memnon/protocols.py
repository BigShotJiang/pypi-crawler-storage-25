"""Runtime extension protocols."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from memnon.types import (
    IngestCursor,
    Observation,
    ObservationDraft,
    ObservationLevel,
    PeerRef,
    RepresentationKind,
    SearchHit,
    SessionEnvelope,
)


@runtime_checkable
class EmbedderProtocol(Protocol):
    async def embed(self, text: str) -> list[float]: ...


@runtime_checkable
class ReasoningBackend(Protocol):
    async def extract_observations(
        self,
        *,
        session: SessionEnvelope,
        owner: PeerRef,
        subject: PeerRef,
    ) -> list[ObservationDraft]: ...

    async def deduce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> tuple[list[ObservationDraft], list[str]]: ...

    async def induce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> list[ObservationDraft]: ...

    async def build_representation(
        self,
        *,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
        observations: list[Observation],
    ) -> str: ...


@runtime_checkable
class RuntimeRepository(Protocol):
    async def ensure_schema(self) -> None: ...
    async def ensure_tables(self) -> None: ...
    async def write_observations(self, observations: list[Observation]) -> None: ...
    async def get_observation(self, observation_id: str) -> Observation | None: ...

    async def list_observations(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        session_id: str | None = None,
        level: ObservationLevel | None = None,
        limit: int = 200,
    ) -> list[Observation]: ...

    async def delete_observations(self, observation_ids: list[str]) -> None: ...

    async def get_ingest_cursor(
        self,
        *,
        workspace_id: str,
        session_id: str,
        owner: PeerRef,
        subject: PeerRef,
    ) -> IngestCursor | None: ...

    async def upsert_ingest_cursor(self, cursor: IngestCursor) -> None: ...

    async def save_representation(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
        content: str,
        observation_count: int,
    ) -> None: ...

    async def get_representation(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        kind: RepresentationKind,
    ) -> tuple[str | None, int]: ...

    async def list_collections(
        self,
        *,
        workspace_id: str,
        owner: PeerRef | None = None,
    ) -> list[tuple[PeerRef, PeerRef]]: ...


@runtime_checkable
class SearchBackend(Protocol):
    async def index(self, observations: list[Observation]) -> None: ...
    async def remove(self, observation_ids: list[str]) -> None: ...

    async def search(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        query: str,
        query_embedding: list[float],
        limit: int = 20,
        current_session_id: str | None = None,
    ) -> list[SearchHit]: ...

