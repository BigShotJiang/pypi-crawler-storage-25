"""OpenRouter smoke benchmark for Memnon memory quality.

Run with:

    OPENROUTER_API_KEY=... uv run --extra all python benchmarks/openrouter_memory_eval.py

The script uses Pydantic Evals to exercise the full in-memory runtime path with
a real Pydantic AI model: observation extraction, search, and profile creation.
"""

from __future__ import annotations

import argparse
import asyncio
import os

from memnon.adapters.models import DEFAULT_OPENROUTER_MODEL
from memnon.evals.openrouter import MemoryEvalInput, MemoryEvalOutput, build_dataset, run_memory_case


async def _task(inputs: MemoryEvalInput, *, model: str) -> MemoryEvalOutput:
    return await run_memory_case(inputs, model=model)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Memnon's OpenRouter memory smoke eval.")
    parser.add_argument(
        "--model",
        default=os.environ.get("MEMNON_MODEL", DEFAULT_OPENROUTER_MODEL).removeprefix("openrouter:"),
        help="OpenRouter model id. Defaults to MEMNON_MODEL or openrouter/free.",
    )
    args = parser.parse_args()
    if not os.environ.get("OPENROUTER_API_KEY") and not os.environ.get("MEMNON_OPENROUTER_API_KEY"):
        raise SystemExit("Set OPENROUTER_API_KEY or MEMNON_OPENROUTER_API_KEY before running this eval.")

    dataset = build_dataset()
    report = dataset.evaluate_sync(lambda inputs: asyncio.run(_task(inputs, model=args.model)), progress=False)
    report.print(include_input=True, include_output=True)


if __name__ == "__main__":
    main()
