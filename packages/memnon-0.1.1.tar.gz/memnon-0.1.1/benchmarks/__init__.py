"""Memnon benchmark and eval scripts."""
