from __future__ import annotations

import pytest

from memnon.adapters.models import create_openrouter_model, resolve_pydantic_ai_model


def test_plain_pydantic_ai_model_string_is_unchanged() -> None:
    assert resolve_pydantic_ai_model("openai:gpt-4o-mini") == "openai:gpt-4o-mini"


def test_openrouter_model_requires_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    monkeypatch.delenv("MEMNON_OPENROUTER_API_KEY", raising=False)

    with pytest.raises(RuntimeError, match="OPENROUTER_API_KEY"):
        create_openrouter_model(model_name="google/gemini-2.5-flash-lite")


def test_openrouter_model_can_be_resolved_without_network(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENROUTER_API_KEY", "test-key")

    model = resolve_pydantic_ai_model("openrouter:openrouter/free")

    assert type(model).__name__ == "OpenAIChatModel"
