from __future__ import annotations

import asyncio
import os

import pytest

pytestmark = pytest.mark.integration


@pytest.mark.skipif(not os.environ.get("MEMNON_TEST_DATABASE_URL"), reason="MEMNON_TEST_DATABASE_URL is not set")
def test_postgres_repository_search_and_cli_schema_contract() -> None:
    from typer.testing import CliRunner

    from memnon.cli import app

    database_url = os.environ["MEMNON_TEST_DATABASE_URL"]
    asyncio.run(_drop_memnon_schema(database_url))

    cli_result = CliRunner().invoke(app, ["schema", "init"], env={"MEMNON_DATABASE_URL": database_url})
    assert cli_result.exit_code == 0, cli_result.output

    asyncio.run(_run_postgres_repository_search_contract(database_url))


async def _drop_memnon_schema(database_url: str) -> None:
    from sqlalchemy import text
    from sqlalchemy.ext.asyncio import create_async_engine

    engine = create_async_engine(database_url)
    async with engine.begin() as connection:
        await connection.execute(text("DROP SCHEMA IF EXISTS memory_runtime CASCADE"))
    await engine.dispose()


async def _run_postgres_repository_search_contract(database_url: str) -> None:
    from memnon.search.postgres import PostgresHybridSearch
    from memnon.store.postgres import PostgresMemoryRepository
    from memnon.types import IngestCursor, Observation, ObservationLevel, PeerKind, PeerRef, RepresentationKind

    repo = PostgresMemoryRepository(database_url=database_url)
    await repo.ensure_tables()
    owner = PeerRef(id="user-pg", kind=PeerKind.USER)
    observation = Observation(
        workspace_id="ws-pg",
        owner=owner,
        subject=owner,
        session_id="thread-pg",
        level=ObservationLevel.EXPLICIT,
        content="User prefers concise Postgres summaries.",
        embedding=[0.1] * 1536,
    )
    await repo.write_observations([observation])
    stored = await repo.get_observation(observation.id)
    assert stored is not None
    assert stored.id == observation.id
    assert stored.content == observation.content
    listed = await repo.list_observations(workspace_id="ws-pg", owner=owner, subject=owner)
    assert [item.id for item in listed] == [observation.id]

    await repo.upsert_ingest_cursor(
        IngestCursor(
            workspace_id="ws-pg",
            session_id="thread-pg",
            owner=owner,
            subject=owner,
            content_fingerprint="fingerprint",
            imported_message_keys=["m1"],
        )
    )
    cursor = await repo.get_ingest_cursor(
        workspace_id="ws-pg",
        session_id="thread-pg",
        owner=owner,
        subject=owner,
    )
    assert cursor is not None
    assert cursor.content_fingerprint == "fingerprint"

    await repo.save_representation(
        workspace_id="ws-pg",
        owner=owner,
        subject=owner,
        kind=RepresentationKind.USER_PROFILE,
        content="profile",
        observation_count=1,
    )
    assert await repo.get_representation(
        workspace_id="ws-pg",
        owner=owner,
        subject=owner,
        kind=RepresentationKind.USER_PROFILE,
    ) == ("profile", 1)

    search = PostgresHybridSearch(database_url=database_url)
    hits = await search.search(
        workspace_id="ws-pg",
        owner=owner,
        subject=owner,
        query="concise summaries",
        query_embedding=[0.1] * 1536,
        limit=5,
    )
    assert hits
    assert hits[0].observation_id == observation.id
    await repo.close()
