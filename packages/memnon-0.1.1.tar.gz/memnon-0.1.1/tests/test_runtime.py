from __future__ import annotations

from datetime import UTC, datetime

from memnon import MemoryMessage, MessageRole, PeerKind, PeerRef, SessionEnvelope
from memnon.engine import DeterministicReasoningBackend
from memnon.factory import create_memory_runtime
from memnon.types import (
    ConsolidateRequest,
    InitializeRequest,
    Observation,
    ObservationDraft,
    ObservationLevel,
    SearchRequest,
)


def _session(session_id: str = "thread-1", content: str = "I prefer short bullet summaries.") -> SessionEnvelope:
    user = PeerRef(id="user-1", kind=PeerKind.USER)
    agent = PeerRef(id="agent-1", kind=PeerKind.AGENT, observe_others=True)
    return SessionEnvelope(
        workspace_id="ws-1",
        session_id=session_id,
        source_id=session_id,
        peers=[user, agent],
        messages=[
            MemoryMessage(
                id=f"{session_id}:m1",
                peer_id="user-1",
                role=MessageRole.USER,
                content=content,
                timestamp=datetime.now(UTC),
            )
        ],
        source_cursor="1",
    )


async def test_initialize_creates_observations_and_repeated_ingest_skips() -> None:
    runtime = create_memory_runtime(mode="test")
    user = PeerRef(id="user-1", kind=PeerKind.USER)
    session = _session()

    first = await runtime.initialize(InitializeRequest(workspace_id="ws-1", targets=[user], sessions=[session]))
    second = await runtime.initialize(InitializeRequest(workspace_id="ws-1", targets=[user], sessions=[session]))

    assert first.sessions_processed == 1
    assert first.observations_created == 1
    assert second.sessions_skipped == 1
    assert second.observations_created == 0


async def test_search_returns_budgeted_prompt_context() -> None:
    runtime = create_memory_runtime(mode="test")
    user = PeerRef(id="user-1", kind=PeerKind.USER)
    await runtime.initialize(InitializeRequest(workspace_id="ws-1", targets=[user], sessions=[_session()]))

    result = await runtime.search(
        SearchRequest(workspace_id="ws-1", owner=user, query="short summaries", token_budget=200)
    )

    assert "short bullet summaries" in result.context
    assert result.observations_used >= 1
    assert result.representation_included is True


async def test_representation_cache_refreshes_when_observation_count_changes() -> None:
    runtime = create_memory_runtime(mode="test")
    user = PeerRef(id="user-1", kind=PeerKind.USER)
    await runtime.initialize(InitializeRequest(workspace_id="ws-1", targets=[user], sessions=[_session()]))

    first = await runtime.get_representation(
        __import__("memnon").RepresentationRequest(workspace_id="ws-1", owner=user)
    )
    second = await runtime.get_representation(
        __import__("memnon").RepresentationRequest(workspace_id="ws-1", owner=user)
    )
    await runtime.initialize(
        InitializeRequest(
            workspace_id="ws-1",
            targets=[user],
            sessions=[_session(session_id="thread-2", content="I prefer risk notes at the top.")],
        )
    )
    third = await runtime.get_representation(
        __import__("memnon").RepresentationRequest(workspace_id="ws-1", owner=user)
    )

    assert first.cached is True  # initialize already built it once
    assert second.cached is True
    assert third.cached is True
    assert third.observation_count == 2
    assert "risk notes" in third.content


class ConsolidatingBackend(DeterministicReasoningBackend):
    async def deduce(
        self,
        *,
        workspace_id: str,
        owner: PeerRef,
        subject: PeerRef,
        observations: list[Observation],
    ) -> tuple[list[ObservationDraft], list[str]]:
        return [
            ObservationDraft(
                owner=owner,
                subject=subject,
                session_id=observations[-1].session_id,
                level=ObservationLevel.DEDUCTIVE,
                content="User likes concise operational summaries.",
            )
        ], [observations[0].id]


async def test_consolidation_adds_derived_observations_and_removes_stale() -> None:
    runtime = create_memory_runtime(mode="test", reasoning_backend=ConsolidatingBackend())
    user = PeerRef(id="user-1", kind=PeerKind.USER)
    await runtime.initialize(InitializeRequest(workspace_id="ws-1", targets=[user], sessions=[_session()]))

    result = await runtime.consolidate(ConsolidateRequest(workspace_id="ws-1", owner=user))
    search = await runtime.search(SearchRequest(workspace_id="ws-1", owner=user, query="concise summaries"))

    assert result.deductions_created == 1
    assert result.stale_removed == 1
    assert "concise operational summaries" in search.context
