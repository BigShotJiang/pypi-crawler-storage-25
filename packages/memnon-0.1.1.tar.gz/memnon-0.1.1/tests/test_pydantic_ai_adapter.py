from __future__ import annotations

from datetime import UTC, datetime

from memnon import PeerKind, PeerRef
from memnon.adapters.pydantic_ai import FactList, PydanticAIReasoningBackend, pydantic_ai_messages_to_session_envelope


class FakeBackend(PydanticAIReasoningBackend):
    async def _run_structured(self, *, prompt: str, instructions: list[str], output_type: type) -> object:
        return FactList(facts=["User prefers concise summaries."])


async def test_pydantic_ai_reasoning_adapter_maps_fact_output_to_drafts() -> None:
    user = PeerRef(id="user-1", kind=PeerKind.USER)
    session = pydantic_ai_messages_to_session_envelope(
        workspace_id="ws",
        session_id="thread",
        source_id="thread",
        peers=[user],
        messages=[_Message([_UserPromptPart("Please keep summaries concise.")])],
    )
    backend = FakeBackend(model="test")

    drafts = await backend.extract_observations(session=session, owner=user, subject=user)

    assert len(drafts) == 1
    assert drafts[0].content == "User prefers concise summaries."
    assert drafts[0].owner == user


def test_pydantic_ai_session_converter_handles_common_parts() -> None:
    user = PeerRef(id="user-1", kind=PeerKind.USER)
    agent = PeerRef(id="agent-1", kind=PeerKind.AGENT)
    session = pydantic_ai_messages_to_session_envelope(
        workspace_id="ws",
        session_id="thread",
        source_id="thread",
        peers=[user, agent],
        messages=[
            _Message([_UserPromptPart("hello")]),
            _Message([_TextPart("hi"), _ToolCallPart("search", {"q": "x"})]),
            _Message([_ToolReturnPart("search", "result")]),
        ],
    )

    assert [message.role.value for message in session.messages] == ["user", "assistant", "tool_call", "tool_result"]
    assert session.messages[2].tool_name == "search"


class _Message:
    def __init__(self, parts: list[object]) -> None:
        self.parts = parts
        self.timestamp = datetime.now(UTC)


class _UserPromptPart:
    def __init__(self, content: str) -> None:
        self.content = content


class _TextPart:
    def __init__(self, content: str) -> None:
        self.content = content


class _ToolCallPart:
    def __init__(self, tool_name: str, args: dict[str, str]) -> None:
        self.tool_name = tool_name
        self.args = args

    def args_as_json_str(self) -> str:
        return '{"q":"x"}'


class _ToolReturnPart:
    def __init__(self, tool_name: str, content: str) -> None:
        self.tool_name = tool_name
        self.content = content
