from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from memnon.cli import app

runner = CliRunner()


def test_cli_help() -> None:
    result = runner.invoke(app, ["--help"])

    assert result.exit_code == 0
    assert "Memnon agent memory runtime" in result.output


def test_search_requires_database_url() -> None:
    result = runner.invoke(app, ["search", "query", "--workspace", "ws", "--owner", "user:user-1"], env={})

    assert result.exit_code == 2
    assert "Missing database URL" in result.output


def test_invalid_peer_ref_returns_cli_error() -> None:
    result = runner.invoke(
        app,
        [
            "search",
            "query",
            "--workspace",
            "ws",
            "--owner",
            "not-a-peer",
            "--database-url",
            "postgresql+asyncpg://localhost/db",
        ],
    )

    assert result.exit_code == 2
    assert "Peer refs must use" in result.output


def test_schema_init_uses_runtime(monkeypatch) -> None:
    calls: list[str] = []

    class FakeRuntime:
        async def ensure_ready(self) -> None:
            calls.append("ready")

        async def aclose(self) -> None:
            calls.append("close")

    def fake_create_memory_runtime(**kwargs):
        assert kwargs["mode"] == "postgres"
        assert kwargs["database_url"] == "postgresql+asyncpg://localhost/db"
        return FakeRuntime()

    monkeypatch.setattr("memnon.cli.create_memory_runtime", fake_create_memory_runtime)

    result = runner.invoke(app, ["schema", "init"], env={"MEMNON_DATABASE_URL": "postgresql+asyncpg://localhost/db"})

    assert result.exit_code == 0
    assert calls == ["ready", "close"]


def test_ingest_session_reads_envelope_and_targets(monkeypatch, tmp_path: Path) -> None:
    session_path = tmp_path / "session.json"
    session_path.write_text(
        """
        {
          "workspace_id": "ws",
          "session_id": "thread",
          "source_id": "thread",
          "peers": [{"id": "user-1", "kind": "user"}],
          "messages": [
            {
              "id": "m1",
              "peer_id": "user-1",
              "role": "user",
              "content": "I prefer bullets.",
              "timestamp": "2026-04-30T12:00:00Z"
            }
          ]
        }
        """
    )
    captured_targets: list[str] = []

    class Result:
        sessions_processed = 1
        sessions_skipped = 0
        observations_created = 1
        representations_built = 1

    class FakeRuntime:
        async def initialize(self, request):
            captured_targets.extend(f"{target.kind.value}:{target.id}" for target in request.targets)
            return Result()

        async def aclose(self) -> None:
            return None

    monkeypatch.setattr("memnon.cli.create_memory_runtime", lambda **kwargs: FakeRuntime())

    result = runner.invoke(
        app,
        ["ingest", "session", str(session_path), "--target", "user:user-1"],
        env={"MEMNON_DATABASE_URL": "postgresql+asyncpg://localhost/db"},
    )

    assert result.exit_code == 0
    assert captured_targets == ["user:user-1"]
    assert "observations_created" in result.output
