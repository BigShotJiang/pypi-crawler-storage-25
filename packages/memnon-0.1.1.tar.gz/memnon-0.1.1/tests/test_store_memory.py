from __future__ import annotations

from memnon import PeerKind, PeerRef
from memnon.store.memory import InMemoryRepository
from memnon.types import IngestCursor, Observation, ObservationLevel, RepresentationKind


async def test_in_memory_repository_contract() -> None:
    repo = InMemoryRepository()
    owner = PeerRef(id="user-1", kind=PeerKind.USER)
    observation = Observation(
        workspace_id="ws",
        owner=owner,
        subject=owner,
        session_id="thread",
        level=ObservationLevel.EXPLICIT,
        content="User prefers bullets.",
    )

    await repo.write_observations([observation])
    await repo.upsert_ingest_cursor(
        IngestCursor(
            workspace_id="ws",
            session_id="thread",
            owner=owner,
            subject=owner,
            content_fingerprint="abc",
        )
    )
    await repo.save_representation(
        workspace_id="ws",
        owner=owner,
        subject=owner,
        kind=RepresentationKind.USER_PROFILE,
        content="profile",
        observation_count=1,
    )

    assert await repo.get_observation(observation.id) == observation
    assert len(await repo.list_observations(workspace_id="ws", owner=owner, subject=owner)) == 1
    assert (
        await repo.get_ingest_cursor(workspace_id="ws", session_id="thread", owner=owner, subject=owner)
    ) is not None
    assert await repo.get_representation(
        workspace_id="ws",
        owner=owner,
        subject=owner,
        kind=RepresentationKind.USER_PROFILE,
    ) == ("profile", 1)
    assert await repo.list_collections(workspace_id="ws") == [(owner, owner)]
