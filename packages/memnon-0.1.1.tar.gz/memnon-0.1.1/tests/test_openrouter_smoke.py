from __future__ import annotations

import os

import pytest

from memnon.adapters.models import DEFAULT_OPENROUTER_MODEL
from memnon.evals.openrouter import MemoryEvalInput, run_memory_case


@pytest.mark.llm
@pytest.mark.skipif(
    not (os.environ.get("OPENROUTER_API_KEY") or os.environ.get("MEMNON_OPENROUTER_API_KEY")),
    reason="OPENROUTER_API_KEY or MEMNON_OPENROUTER_API_KEY is required",
)
async def test_openrouter_ingests_searches_and_builds_profile() -> None:
    result = await run_memory_case(
        MemoryEvalInput(
            user_text=(
                "Remember that I like concise planning updates with risk notes first "
                "and exactly three bullet points."
            ),
            query="What update format does this user prefer?",
            expected_terms=["risk", "bullet", "concise"],
        ),
        model=os.environ.get("MEMNON_OPENROUTER_MODEL", DEFAULT_OPENROUTER_MODEL),
    )

    combined = f"{result.search_context}\n{result.profile}".lower()
    assert result.observations_created > 0
    assert result.representations_built > 0
    assert "risk" in combined
    assert "bullet" in combined
