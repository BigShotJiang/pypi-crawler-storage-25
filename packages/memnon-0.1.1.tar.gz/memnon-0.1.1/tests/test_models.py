from __future__ import annotations

from memnon import PeerKind, PeerRef
from memnon.types import PromptMemoryRequest, RepresentationRequest, SearchRequest


def test_request_models_default_subject_to_owner() -> None:
    owner = PeerRef(id="user-1", kind=PeerKind.USER)

    assert SearchRequest(workspace_id="ws", owner=owner, query="prefs").subject == owner
    assert PromptMemoryRequest(workspace_id="ws", owner=owner, query="prefs").subject == owner
    assert RepresentationRequest(workspace_id="ws", owner=owner).subject == owner


def test_peer_ref_accepts_string_enum_values() -> None:
    peer = PeerRef(id="agent-1", kind="agent")

    assert peer.kind == PeerKind.AGENT

