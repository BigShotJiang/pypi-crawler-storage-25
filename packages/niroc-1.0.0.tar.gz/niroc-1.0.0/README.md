# ⚡ NiroC — AI Code Transformer

Transform your code with a single function call.

```python
from niroc import NiroC
NiroC("Make a Tetris game")
```

Run your file → NiroC calls AI → rewrites your file → restarts it. Magic.

## Install

```bash
pip install niroc
```

## Usage

### In Python code

```python
from niroc import NiroC

# At the top of your file — NiroC rewrites everything below
NiroC("Make a Snake game with pygame")
```

```python
from niroc import NiroC

NiroC("Add a REST API with FastAPI for a todo app")
```

```python
from niroc import NiroC

NiroC("Optimize this bubble sort to use quicksort")
```

### From command line

```bash
niroc "Make a Tetris game" game.py
niroc "Add dark mode" app.py --no-restart
niroc "Add login form with JWT" --file=app.py
```

## How it works

1. You call `NiroC("your task")` anywhere in your code
2. NiroC reads the current file
3. Sends it to AI (Pollinations / OpenRouter — **free, no API key needed**)
4. AI generates new complete code
5. NiroC **overwrites your file** with the new code
6. Restarts the file automatically

## Configuration

```python
from niroc import NiroC, set_config

# Optional: use your OpenRouter key for better models
set_config(api_key="sk-or-...")

# Don't auto-restart
set_config(auto_restart=False)

# Disable backup
set_config(backup=False)

# Silent mode
set_config(verbose=False)

NiroC("Make a calculator app")
```

## Examples

```python
# game.py
from niroc import NiroC
NiroC("Make a fully working Tetris game using pygame")
```

```python
# api.py
from niroc import NiroC
NiroC("Create a FastAPI REST API with CRUD for a blog")
```

```python
# sort.py
from niroc import NiroC
NiroC("Implement merge sort with step-by-step visualization")
```

## Notes

- Creates a `.niroc_backup` file before overwriting (disable with `set_config(backup=False)`)
- Works with Python, JavaScript, TypeScript, Ruby, Go, Rust, Java, C/C++
- **Zero dependencies** — only Python stdlib
- Free AI providers used by default (Pollinations AI)

## License

MIT
