from setuptools import setup, find_packages
import os

# Read README
here = os.path.abspath(os.path.dirname(__file__))
try:
    with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "NiroC — AI-powered code transformer"

setup(
    name="niroc",
    version="1.0.0",
    author="AuraCode",
    author_email="niro@auracode.dev",
    description="Transform your code with AI using NiroC('your task')",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/auracode/niroc",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[],          # zero dependencies — only stdlib!
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="ai code-generation nlp transformer niro auracode",
    entry_points={
        "console_scripts": [
            "niroc=niroc.cli:main",
        ],
    },
)
