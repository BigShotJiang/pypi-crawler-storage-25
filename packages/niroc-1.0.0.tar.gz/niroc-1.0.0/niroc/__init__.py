"""
NiroC — AI-powered code transformer
Transforms your running code using natural language commands.

Usage:
    from niroc import NiroC
    NiroC("Make a Tetris game")
"""

from .core import NiroC, NiroCConfig, set_config

__version__ = "1.0.0"
__author__  = "AuraCode / Niro AI"
__all__     = ["NiroC", "NiroCConfig", "set_config"]
