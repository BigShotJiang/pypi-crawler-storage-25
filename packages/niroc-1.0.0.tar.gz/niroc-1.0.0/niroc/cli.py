"""
NiroC CLI — transform any file from the command line.

Usage:
    niroc "Make a Tetris game" myfile.py
    niroc "Add dark mode" app.js
    niroc "Optimize sorting" --file=sort.py
"""

import sys
import os
import argparse


def main():
    parser = argparse.ArgumentParser(
        prog="niroc",
        description="⚡ NiroC — Transform code with AI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  niroc "Make a Tetris game" game.py
  niroc "Add login form" app.py --no-restart
  niroc "Optimize this" sort.py --backup
  niroc "Add dark mode" --file=app.js
        """,
    )
    parser.add_argument("task",          help="What to build/change (natural language)")
    parser.add_argument("file",          nargs="?", help="File to transform")
    parser.add_argument("--file",        dest="file_opt", help="File to transform (alternative)")
    parser.add_argument("--no-restart",  action="store_true", help="Don't restart after rewrite")
    parser.add_argument("--no-backup",   action="store_true", help="Don't create backup")
    parser.add_argument("--quiet",       action="store_true", help="Suppress output")
    parser.add_argument("--api-key",     default="",          help="OpenRouter API key")
    parser.add_argument("--version",     action="version",    version="NiroC 1.0.0")

    args = parser.parse_args()

    target_file = args.file or args.file_opt
    if not target_file:
        parser.error("Please specify a file to transform")

    target_file = os.path.abspath(target_file)
    if not os.path.isfile(target_file):
        print(f"Error: File not found: {target_file}", file=sys.stderr)
        sys.exit(1)

    # Configure
    from niroc import set_config
    set_config(
        auto_restart = not args.no_restart,
        backup       = not args.no_backup,
        verbose      = not args.quiet,
        api_key      = args.api_key,
    )

    # Run
    from niroc.core import NiroC
    NiroC(args.task, file=target_file)


if __name__ == "__main__":
    main()
