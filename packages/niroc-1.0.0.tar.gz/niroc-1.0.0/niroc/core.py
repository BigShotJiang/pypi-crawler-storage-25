"""
NiroC Core Engine
─────────────────
Intercepts NiroC("...") calls at runtime, sends the task to AI,
rewrites the calling file with the generated code, then re-executes it.
"""

import os
import sys
import inspect
import urllib.request
import urllib.error
import json
import re
import time
from dataclasses import dataclass, field
from typing import Optional


# ─── Configuration ────────────────────────────────────────────────────────────

@dataclass
class NiroCConfig:
    """Global NiroC configuration."""
    providers: list = field(default_factory=lambda: [
        "pollinations_text",
        "pollinations_openai",
        "openrouter_llama",
        "openrouter_mistral",
    ])
    api_key:      str  = ""
    verbose:      bool = True
    backup:       bool = True
    timeout:      int  = 90
    auto_restart: bool = True


_config = NiroCConfig()


def set_config(**kwargs):
    """Update global NiroC configuration."""
    for k, v in kwargs.items():
        if hasattr(_config, k):
            setattr(_config, k, v)
        else:
            raise ValueError(f"Unknown config key: {k}")


# ─── Logging ──────────────────────────────────────────────────────────────────

CYAN   = "\033[96m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
RESET  = "\033[0m"

def _log(msg, color=CYAN, prefix="NiroC"):
    if _config.verbose:
        print(f"{color}{BOLD}[{prefix}]{RESET} {color}{msg}{RESET}", flush=True)

def _log_dim(msg):
    if _config.verbose:
        print(f"{DIM}       {msg}{RESET}", flush=True)


# ─── HTTP helper ──────────────────────────────────────────────────────────────

def _http_post(url, payload, headers, timeout):
    data = json.dumps(payload).encode("utf-8")
    req  = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))

def _http_get(url, timeout):
    req = urllib.request.Request(url, headers={"User-Agent": "NiroC/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8")


# ─── Provider: Pollinations text endpoint (GET, no auth) ─────────────────────
# https://text.pollinations.ai/{prompt}?model=openai&system={system}

def _call_pollinations_text(messages, timeout):
    """
    Pollinations simple text API — GET request, completely free.
    https://text.pollinations.ai/
    """
    import urllib.parse

    # Build a single prompt from messages
    system = next((m["content"] for m in messages if m["role"] == "system"), "")
    user   = next((m["content"] for m in messages if m["role"] == "user"),   "")

    prompt = urllib.parse.quote(user[:1000])
    sys_q  = urllib.parse.quote(system[:500])
    url    = f"https://text.pollinations.ai/{prompt}?model=openai&system={sys_q}&seed={int(time.time())%9999}"

    text = _http_get(url, timeout)
    if not text or len(text) < 10:
        raise ValueError("Empty response")
    return text


# ─── Provider: Pollinations OpenAI-compatible POST ───────────────────────────

def _call_pollinations_openai(messages, timeout):
    """
    Pollinations OpenAI-compatible endpoint.
    https://text.pollinations.ai/openai  (POST)
    """
    url = "https://text.pollinations.ai/openai"
    payload = {
        "model": "openai",
        "messages": messages,
        "temperature": 0.3,
        "max_tokens": 8192,
        "private": True,
        "seed": int(time.time()) % 99999,
    }
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "NiroC/1.0",
        "Origin": "https://niroc.dev",
    }
    data    = _http_post(url, payload, headers, timeout)
    content = data["choices"][0]["message"]["content"]
    if not content:
        raise ValueError("Empty response")
    return content


# ─── Provider: OpenRouter (free models, no key needed for some) ──────────────

def _call_openrouter(model, messages, api_key, timeout):
    url = "https://openrouter.ai/api/v1/chat/completions"
    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.3,
        "max_tokens": 8192,
    }
    headers = {
        "Content-Type": "application/json",
        "HTTP-Referer": "https://niroc.dev",
        "X-Title": "NiroC",
        "User-Agent": "NiroC/1.0",
    }
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    data    = _http_post(url, payload, headers, timeout)
    content = data["choices"][0]["message"]["content"]
    if not content:
        raise ValueError("Empty response")
    return content


# ─── Provider: Hugging Face Inference API (free tier) ────────────────────────

def _call_huggingface(messages, timeout):
    """
    HuggingFace free inference API — no key needed for public models.
    """
    # Convert messages to a single prompt
    prompt = ""
    for m in messages:
        role = m["role"]
        if role == "system":
            prompt += f"<s>[INST] <<SYS>>\n{m['content']}\n<</SYS>>\n\n"
        elif role == "user":
            prompt += f"{m['content']} [/INST]"
        elif role == "assistant":
            prompt += f" {m['content']} </s><s>[INST] "

    url = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.3"
    payload = {
        "inputs": prompt,
        "parameters": {
            "max_new_tokens": 2048,
            "temperature": 0.3,
            "return_full_text": False,
        },
    }
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "NiroC/1.0",
    }
    data = _http_post(url, payload, headers, timeout)
    if isinstance(data, list):
        text = data[0].get("generated_text", "")
    else:
        text = data.get("generated_text", "")
    if not text:
        raise ValueError("Empty response")
    return text


# ─── Provider map ─────────────────────────────────────────────────────────────

def _get_provider_fn(name):
    return {
        "pollinations_text":   lambda msgs, t: _call_pollinations_text(msgs, t),
        "pollinations_openai": lambda msgs, t: _call_pollinations_openai(msgs, t),
        "openrouter_llama":    lambda msgs, t: _call_openrouter(
            "meta-llama/llama-3.1-8b-instruct:free", msgs, _config.api_key, t),
        "openrouter_mistral":  lambda msgs, t: _call_openrouter(
            "mistralai/mistral-7b-instruct:free", msgs, _config.api_key, t),
        "openrouter_qwen":     lambda msgs, t: _call_openrouter(
            "qwen/qwen3-235b-a22b:free", msgs, _config.api_key, t),
        "huggingface":         lambda msgs, t: _call_huggingface(msgs, t),
    }.get(name)


def _call_ai(messages):
    """Try providers in order, return first successful response."""
    errors = []
    for name in _config.providers:
        fn = _get_provider_fn(name)
        if not fn:
            continue
        try:
            _log_dim(f"Trying {name}...")
            result = fn(messages, _config.timeout)
            _log_dim(f"✓ Success with {name}")
            return result
        except Exception as e:
            _log_dim(f"✗ {name}: {e}")
            errors.append(f"{name}: {e}")

    raise RuntimeError(
        "All AI providers failed:\n" + "\n".join(f"  • {e}" for e in errors)
    )


# ─── Code extraction ──────────────────────────────────────────────────────────

def _extract_code(ai_response, language="python"):
    """Extract code block from AI response."""
    # Try ```language ... ```
    patterns = [
        rf"```{re.escape(language)}\s*\n(.*?)```",
        r"```\w*\s*\n(.*?)```",
        r"```(.*?)```",
    ]
    for pat in patterns:
        m = re.search(pat, ai_response, re.DOTALL | re.IGNORECASE)
        if m:
            code = m.group(1).strip()
            if len(code) > 20:
                return code

    # No fenced block — check if response itself looks like code
    code_keywords = ["def ", "class ", "import ", "print(", "if __name__",
                     "function ", "const ", "let ", "var ", "fn ", "func "]
    if any(kw in ai_response for kw in code_keywords):
        # Strip any leading explanation lines
        lines = ai_response.strip().splitlines()
        start = 0
        for i, line in enumerate(lines):
            if any(kw in line for kw in code_keywords):
                start = i
                break
        return "\n".join(lines[start:]).strip()

    raise ValueError("Could not extract code from AI response")


# ─── System prompt ────────────────────────────────────────────────────────────

def _detect_language(filename):
    ext = os.path.splitext(filename)[1].lower()
    return {
        ".py": "Python", ".js": "JavaScript", ".mjs": "JavaScript",
        ".ts": "TypeScript", ".tsx": "TypeScript",
        ".rb": "Ruby", ".go": "Go", ".rs": "Rust",
        ".java": "Java", ".cpp": "C++", ".c": "C",
        ".cs": "C#", ".php": "PHP", ".swift": "Swift",
    }.get(ext, "Python")


def _build_messages(task, current_code, filename):
    lang     = _detect_language(filename)
    lang_low = lang.lower().replace("#", "sharp").replace("+", "p")

    system = (
        f"You are NiroC — an expert AI code generator.\n"
        f"TASK: {task}\n"
        f"LANGUAGE: {lang}\n"
        f"FILE: {filename}\n\n"
        f"RULES:\n"
        f"1. Return ONLY the complete, runnable {lang} code\n"
        f"2. Wrap it in a ```{lang_low} code block\n"
        f"3. Include ALL necessary imports\n"
        f"4. No explanations outside the code block\n"
        f"5. The code must fully accomplish the task\n"
        f"6. Add helpful comments inside the code\n\n"
        f"CURRENT CODE (context):\n```{lang_low}\n{current_code[:2000]}\n```\n\n"
        f"Generate the complete new code now:"
    )
    return [
        {"role": "system", "content": system},
        {"role": "user",   "content": f"Transform this {lang} code to: {task}"},
    ]


# ─── File helpers ─────────────────────────────────────────────────────────────

def _backup(filepath):
    path = filepath + ".niroc_backup"
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path

def _write(filepath, code):
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(code)

def _read(filepath):
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""


# ─── Main NiroC ───────────────────────────────────────────────────────────────

def NiroC(task: str, file: Optional[str] = None, restart: Optional[bool] = None):
    """
    Transform the calling file using AI.

    Args:
        task:    What to build or change (natural language).
        file:    File to transform. Auto-detected from call stack if None.
        restart: Restart after rewrite. Uses config default if None.

    Examples:
        NiroC("Make a Tetris game")
        NiroC("Add a login form with validation")
        NiroC("Optimize this sorting algorithm")
        NiroC("Create a REST API with FastAPI")
    """
    should_restart = restart if restart is not None else _config.auto_restart

    # ── Detect calling file ───────────────────────────────────────────────────
    if file is None:
        frame = inspect.stack()[1]
        file  = os.path.abspath(frame.filename)

    if not os.path.isfile(file):
        _log(f"File not found: {file}", RED, "ERROR")
        return

    filename     = os.path.basename(file)
    current_code = _read(file)
    lang         = _detect_language(filename)
    lang_low     = lang.lower().replace("#", "sharp").replace("+", "p")

    # ── Banner ────────────────────────────────────────────────────────────────
    print()
    print(f"{CYAN}{BOLD}{'─'*58}{RESET}")
    print(f"{CYAN}{BOLD}  ⚡ NiroC v1.0  —  AI Code Transformer{RESET}")
    print(f"{CYAN}{BOLD}{'─'*58}{RESET}")
    _log(f"Task   : {task}")
    _log(f"File   : {filename}  ({lang})")
    _log(f"Lines  : {len(current_code.splitlines())}")
    print(f"{CYAN}{'─'*58}{RESET}")
    print()

    # ── Backup ────────────────────────────────────────────────────────────────
    if _config.backup:
        bp = _backup(file)
        _log_dim(f"Backup → {os.path.basename(bp)}")

    # ── Call AI ───────────────────────────────────────────────────────────────
    _log("Sending to Niro AI...", YELLOW)
    t0 = time.time()

    try:
        messages    = _build_messages(task, current_code, filename)
        ai_response = _call_ai(messages)
    except Exception as e:
        _log(f"AI failed: {e}", RED, "ERROR")
        print()
        return

    elapsed = time.time() - t0
    _log(f"AI responded in {elapsed:.1f}s ✓", GREEN)

    # ── Extract code ──────────────────────────────────────────────────────────
    try:
        new_code = _extract_code(ai_response, lang_low)
    except ValueError:
        _log("No code block found — using raw response", YELLOW)
        new_code = ai_response.strip()

    if len(new_code) < 10:
        _log("AI returned empty code", RED, "ERROR")
        return

    # ── Stats ─────────────────────────────────────────────────────────────────
    old_n = len(current_code.splitlines())
    new_n = len(new_code.splitlines())
    diff  = new_n - old_n
    sign  = "+" if diff >= 0 else ""
    _log(f"Code   : {old_n} → {new_n} lines ({sign}{diff})", GREEN)

    # ── Write ─────────────────────────────────────────────────────────────────
    _write(file, new_code)
    _log(f"✓ Rewritten: {filename}", GREEN)

    # ── Preview ───────────────────────────────────────────────────────────────
    preview = new_code.splitlines()[:10]
    print()
    print(f"{DIM}  ┌─ Preview ({'first 10 lines'}) {'─'*30}{RESET}")
    for i, line in enumerate(preview, 1):
        print(f"{DIM}  │ {i:3d}  {line}{RESET}")
    if new_n > 10:
        print(f"{DIM}  │      ... ({new_n - 10} more lines){RESET}")
    print(f"{DIM}  └{'─'*44}{RESET}")
    print()

    # ── Restart ───────────────────────────────────────────────────────────────
    if should_restart:
        _log(f"Restarting {filename}...", CYAN)
        print(f"{CYAN}{'─'*58}{RESET}")
        print()
        os.execv(sys.executable, [sys.executable, file] + sys.argv[1:])
    else:
        print(f"{GREEN}{BOLD}  ✓ Done! Run the file again to see the changes.{RESET}")
        print(f"{CYAN}{'─'*58}{RESET}")
        print()
