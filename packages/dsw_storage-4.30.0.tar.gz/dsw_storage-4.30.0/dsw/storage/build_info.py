# Generated file
# - do not overwrite
# - do not include in git
from collections import namedtuple

BuildInfo = namedtuple(
    'BuildInfo',
    ['version', 'built_at', 'sha', 'branch', 'tag'],
)

BUILD_INFO = BuildInfo(
    version='v4.30.0~9c183b5',
    built_at='2026-05-05 06:13:20Z',
    sha='9c183b5721d0d4f2efcd67b4045386236013f23c',
    branch='HEAD',
    tag='v4.30.0',
)
