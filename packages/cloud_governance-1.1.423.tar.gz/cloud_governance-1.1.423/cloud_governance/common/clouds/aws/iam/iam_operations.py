import os

import boto3

from cloud_governance.common.clouds.aws.utils.common_methods import get_boto3_client
from cloud_governance.common.clouds.aws.utils.utils import Utils
from cloud_governance.common.logger.init_logger import logger
from datetime import datetime, timezone


class IAMOperations:

    ACCESS_KEY_LABEL_MAP = {"access key 1": 0, "access key 2": 1}
    EXCLUDED_PROPAGATION_TAGS = {'cost-center'}

    def __init__(self, iam_client=None):
        self.iam_client = iam_client if iam_client else get_boto3_client('iam')
        self.utils = Utils()
        self.__sts_client = boto3.client('sts')

    @property
    def get_iam_client(self):
        return self.iam_client

    def get_user_tags(self, username: str):
        """
        This method return tags from the iam resources
        @param username:
        @return:
        """
        try:
            user = self.iam_client.get_user(UserName=username)['User']
            if user.get('Tags'):
                return [tag for tag in user.get('Tags')
                        if tag.get('Key', '').lower() not in self.EXCLUDED_PROPAGATION_TAGS]
            else:
                return []
        except:
            return []

    def get_roles(self):
        """
        This method returns all roles
        @return:
        """
        return self.utils.get_details_resource_list(func_name=self.iam_client.list_roles, input_tag='Roles',
                                                    check_tag='Marker')

    def get_users(self):
        """
        This method returns all users
        @return:
        """
        return self.utils.get_details_resource_list(self.iam_client.list_users, input_tag='Users', check_tag='Marker')

    def get_account_alias_cloud_name(self):
        """
        This method returns the aws account alias and cloud name
        @return:
        """
        try:
            account_alias = self.iam_client.list_account_aliases()['AccountAliases']
            if account_alias:
                return account_alias[0].upper(), 'AwsCloud'.upper()
        except:
            return os.environ.get('account', '').upper(), 'AwsCloud'.upper()

    def get_iam_users_list(self):
        """
        This method return the IAM users list
        :return:
        """
        iam_users = []
        users = self.get_users()
        for user in users:
            iam_users.append(user.get('UserName'))
        return iam_users

    def get_aws_account_id_name(self):
        """
        This method returns the aws account_id
        :return:
        """
        response = self.__sts_client.get_caller_identity()
        account_id = response['Account']
        return account_id

    def get_role(self, role_name: str):
        """
        This method returns the iam role data
        :param role_name:
        :return:
        """
        role_data = {}
        try:
            role_data = self.iam_client.get_role(RoleName=role_name).get('Role')
        except Exception as err:
            logger.error(err)
        return role_data

    def list_inline_role_policies(self, role_name: str):
        """
        This method returns the iam role inline policies
        :param role_name:
        :return:
        """
        role_policies = []
        try:
            role_policies = self.iam_client.list_role_policies(RoleName=role_name).get('PolicyNames', [])
        except Exception as err:
            logger.error(err)
        return role_policies

    def list_attached_role_policies(self, role_name: str):
        """
        This method returns the iam role attached policies
        :param role_name:
        :return:
        """
        attached_policies = []
        try:
            attached_policies = self.iam_client.list_attached_role_policies(RoleName=role_name).get('AttachedPolicies',
                                                                                                    [])
        except Exception as err:
            logger.error(err)
        return attached_policies

    def delete_role(self, role_name: str):
        """
        This method deletes the iam role
        :param role_name:
        :return:
        """
        try:
            self.iam_client.delete_role(RoleName=role_name)
            return True
        except Exception as err:
            raise err

    def tag_role(self, role_name: str, tags: list):
        """
        This method tags the iam role
        :param role_name:
        :param tags:
        :return:
        """
        try:
            self.iam_client.tag_role(RoleName=role_name, Tags=tags)
            return True
        except Exception as err:
            raise err

    def untag_role(self, role_name: str, tags: list):
        """
        This method untags the iam role
        :param role_name:
        :param tags:
        :return:
        """
        try:
            self.iam_client.untag_role(RoleName=role_name,
                                       TagKeys=[key for tag in tags for key, _ in tag.items() if key == 'Key'])
            return True
        except Exception as err:
            raise err

    def tag_user(self, user_name: str, tags: list):
        """
        This method tags the IAM user.
        :param user_name: The name of the IAM user to tag.
        :param tags: A list of tags to associate with the user.
        :return: True if tagging is successful, otherwise raises an exception.
        """
        try:
            self.iam_client.tag_user(UserName=user_name, Tags=tags)
            return True
        except Exception as err:
            raise err

    def untag_user(self, user_name: str, tag_keys: list):
        """
        Removes the given tag keys from the IAM user.
        :param user_name: The name of the IAM user.
        :param tag_keys: List of tag key names to remove (e.g. ['UnusedAccessKey1InactiveDate']).
        """
        if not tag_keys:
            return
        try:
            self.iam_client.untag_user(UserName=user_name, TagKeys=tag_keys)
            logger.info(f"Untagged user '{user_name}': {tag_keys}")
        except Exception as err:
            logger.error(f"Failed to untag user '{user_name}': {err}")
            raise err

    def delete_user_access_key(
        self,
        username: str,
        access_key_label: str,
        remove_inactive_tag: bool = True,
        access_key_id: str = None,
    ):
        """
        Deletes the specified access key for the given IAM user. Optionally removes the
        UnusedAccessKeyNInactiveDate tag (only when this policy had set it by deactivating the key).
        :param username: IAM user name.
        :param access_key_label: "Access key 1" or "Access key 2" (case-insensitive).
        :param remove_inactive_tag: If True, remove UnusedAccessKeyNInactiveDate after delete.
            Set False when the key was not deactivated by this policy (e.g. manually deactivated).
        :param access_key_id: Optional. When provided, delete this key by ID instead of resolving by
            label.
        """
        access_key_label_lower = (access_key_label or '').lower()
        if not access_key_label_lower or 'access key' not in access_key_label_lower:
            logger.warning("Invalid access key label for deletion.")
            return
        key_num = access_key_label_lower.split()[-1]
        inactive_tag_key = f"UnusedAccessKey{key_num}InactiveDate"

        if not access_key_id:
            try:
                access_keys = self.iam_client.list_access_keys(UserName=username)['AccessKeyMetadata']
            except Exception as e:
                logger.error(f"Failed to list access keys for user '{username}': {e}")
                raise
            access_keys.sort(key=lambda k: k['CreateDate'])
            idx = self.ACCESS_KEY_LABEL_MAP.get(access_key_label_lower)
            if idx is None or idx >= len(access_keys):
                logger.warning(f"Access key label '{access_key_label}' not found for user '{username}'")
                return
            access_key_id = access_keys[idx]['AccessKeyId']

        try:
            self.iam_client.delete_access_key(UserName=username, AccessKeyId=access_key_id)
            logger.info(f"Deleted access key '{access_key_id}' for user '{username}'")
        except Exception as e:
            logger.error(f"Failed to delete access key '{access_key_id}' for user '{username}': {e}")
            raise
        tag_keys_to_remove = [access_key_id]
        if remove_inactive_tag:
            tag_keys_to_remove.append(inactive_tag_key)
        self.untag_user(username, tag_keys_to_remove)

    def get_iam_users_access_keys(self):
        """
        Retrieves IAM users and summarizes:
            - Access key status (active/inactive)
            - Access key age in days
            - Access key last used in days (or "N/A" if never used)
            - Tags (as a list of dictionaries)
            - Most recent key usage: last_activity_days
            - IAM client region (global context, since IAM is non-regional)
            - IAM user unique ID: ResourceId

        Returns:
            dict: {
                "username": {
                    "Access key 1": [status, age_days, last_used_days],
                    "Access key 2": [...],
                    "last_activity_days": int or "N/A",
                    "tags": [{"Key": "tag_key", "Value": "tag_value"}, ...],
                    "region": "us-east-1",
                    "ResourceId": "AIDAEXAMPLEUSERID"
                },
                ...
            }
        """
        result = {}
        now = datetime.now(timezone.utc)
        region_name = self.iam_client.meta.region_name or "global"

        paginator = self.iam_client.get_paginator('list_users')
        for page in paginator.paginate():
            for user in page['Users']:
                username = user['UserName']
                result[username] = {}
                access_keys = self.iam_client.list_access_keys(UserName=username)['AccessKeyMetadata']
                access_keys = sorted(access_keys, key=lambda k: k['CreateDate'])
                for idx, key in enumerate(access_keys, start=1):
                    label = f"Access key {idx}"
                    status = key['Status'].lower()
                    age_days = (now - key['CreateDate']).days

                    # Get access key last used
                    try:
                        response = self.iam_client.get_access_key_last_used(AccessKeyId=key['AccessKeyId'])
                        last_used_date = response.get('AccessKeyLastUsed', {}).get('LastUsedDate')
                        if last_used_date:
                            last_used_days = (now - last_used_date).days
                        else:
                            # when no last used date is available, get the age of the key
                            last_used_days = age_days
                    except Exception:
                        # Set None in case of error to avoid deletion, not "N/A" because it will take age time
                        logger.error(f"Failed to get last used date for access key")
                        last_used_days = None

                    result[username][label] = {
                        'label': label,
                        'status': status,
                        'age_days': age_days,
                        'last_activity_days': last_used_days,
                        'access_key_id': key['AccessKeyId'],
                    }

                # Tags as list of dicts
                try:
                    tag_response = self.iam_client.list_user_tags(UserName=username)
                    tags = tag_response.get('Tags', [])
                except Exception:
                    tags = []

                result[username]["tags"] = tags
                result[username]["region"] = region_name
                result[username]["ResourceId"] = user.get('UserId')  # <-- Unique ID

        return result

    def has_active_access_keys(self, username: str, access_key_label: str = None) -> bool:
        """
        Checks if the given IAM user has any active access keys.
        Optionally filters by access key label ("Access Key 1" or "Access Key 2").

        Args:
            username (str): IAM user name
            access_key_label (str): Label to filter access keys ("Access Key 1"/"Access Key 2")

        Returns:
            bool: True if any access key is active (and matches the label if provided), False otherwise
        """
        try:
            keys = self.iam_client.list_access_keys(UserName=username)['AccessKeyMetadata']
        except Exception as e:
            logger.error(f"Failed to list access keys for user '{username}': {e}")
            return False

        # Sort keys by CreateDate ascending (oldest first)
        keys.sort(key=lambda k: k['CreateDate'])

        if access_key_label:
            idx = self.ACCESS_KEY_LABEL_MAP.get(access_key_label.lower())
            if idx is None or idx >= len(keys):
                return False
            return keys[idx].get('Status') == 'Active'

        return any(k.get('Status') == 'Active' for k in keys)

    def deactivate_user_access_key(self, username: str, **kwargs):
        """
        Deactivates the specified access key for the given IAM user.

        Args:
            username (str): IAM user name
            access_key_label (str): Access Key 1 or Access Key 2 (case-insensitive)
        """
        access_key_label = kwargs.get('access_key_label', '').lower()
        if not access_key_label:
            logger.warning("No access key label provided for deactivation.")
            return

        try:
            access_keys = self.iam_client.list_access_keys(UserName=username)['AccessKeyMetadata']
        except Exception as e:
            logger.error(f"Failed to list access keys for user '{username}': {e}")
            return

        # Sort keys by CreateDate ascending (oldest first) for consistent indexing
        access_keys.sort(key=lambda k: k['CreateDate'])

        idx = self.ACCESS_KEY_LABEL_MAP.get(access_key_label)
        if idx is None or idx >= len(access_keys):
            logger.warning(f"Access key label '{access_key_label}' not found for user '{username}'")
            return

        key_to_deactivate = access_keys[idx]
        access_key_id = key_to_deactivate['AccessKeyId']
        current_status = key_to_deactivate['Status'].lower()

        if current_status == 'active':
            try:
                self.iam_client.update_access_key(
                    UserName=username,
                    AccessKeyId=access_key_id,
                    Status='Inactive'
                )
                logger.info(f"Access key '{access_key_id}' deactivated for user '{username}'")
                # Tag the user so we only delete keys we deactivated (after DELETE_ACCESS_KEY_DAYS)
                key_num = access_key_label.split()[-1]
                inactive_tag_key = f"UnusedAccessKey{key_num}InactiveDate"
                inactive_date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
                self.tag_user(username, [{'Key': inactive_tag_key, 'Value': inactive_date}])
            except Exception as e:
                logger.error(f"Failed to deactivate access key '{access_key_id}' for user '{username}': {e}")
        else:
            logger.info(f"Access key '{access_key_id}' is already inactive for user '{username}'")

        logger.info(f"Access key deactivation processed for user '{username}'.")

    def get_instance_profiles_for_role(self, role_name: str):
        """
        This method returns instance profiles associated with a given IAM role.
        :param role_name: The name of the IAM role.
        :return: A list of instance profiles.
        """
        instance_profiles = []
        try:
            # list_instance_profiles_for_role is paginated, use Utils to handle pagination
            instance_profiles = self.utils.get_details_resource_list(
                func_name=self.iam_client.list_instance_profiles_for_role,
                input_tag='InstanceProfiles',
                check_tag='Marker',
                RoleName=role_name
            )
        except Exception as err:
            logger.error(f"Failed to list instance profiles for role '{role_name}': {err}")
        return instance_profiles

    def remove_role_from_instance_profiles(self, role_name: str):
        """
        This method removes the specified IAM role from all associated instance profiles.
        :param role_name: The name of the role to remove.
        :return: True if removal from all profiles is successful, False otherwise.
        """
        instance_profiles = self.get_instance_profiles_for_role(role_name=role_name)
        if not instance_profiles:
            return True

        success = True
        for ip in instance_profiles:
            instance_profile_name = ip.get('InstanceProfileName')
            try:
                self.iam_client.remove_role_from_instance_profile(
                    InstanceProfileName=instance_profile_name,
                    RoleName=role_name
                )
                logger.info(f"Successfully removed role '{role_name}' from instance profile '{instance_profile_name}'")
            except Exception as err:
                logger.error(
                    f"Failed to remove role '{role_name}' from instance profile '{instance_profile_name}': {err}")
                success = False
        return success
