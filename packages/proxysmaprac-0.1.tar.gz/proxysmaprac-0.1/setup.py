from setuptools import setup, find_packages

setup(
    name="ProxySmaPrac",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "numpy",
        "matplotlib",
        "seaborn",
        "scikit-learn",
        "textblob",
        "nltk",
        "networkx"
    ],
    author="ProxySmaPrac",
    description="Social Media Analysis Practical Scripts (Auto Execution)",
)