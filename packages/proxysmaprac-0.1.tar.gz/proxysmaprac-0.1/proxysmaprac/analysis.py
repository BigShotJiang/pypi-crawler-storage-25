#prac 1


import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import nltk
from nltk.corpus import stopwords
import string

# 1. Load and Inspect
df = pd.read_csv('sentimentdataset.csv')
df = df.dropna(subset=['Text'])

# 2. Clean (Common Steps 4 & 9)
stop_words = list(set(stopwords.words('english')))

# 3. Vectorization (The sklearn way)
# This replaces the gensim Dictionary and Corpus
vectorizer = CountVectorizer(stop_words=stop_words, max_features=1000)
data_vectorized = vectorizer.fit_transform(df['Text'])

# 4. Apply LDA Method (Step 10 & 16)
# n_components is the same as num_topics
lda_model = LatentDirichletAllocation(n_components=3, random_state=42)
lda_model.fit(data_vectorized)

# 5. Show Topics (Step 17)
words = vectorizer.get_feature_names_out()
for i, topic in enumerate(lda_model.components_):
    # Get top 10 words for each topic
    top_words_idx = topic.argsort()[-10:]
    top_words = [words[j] for j in top_words_idx]
    print(f"Topic {i}: {', '.join(top_words)}")

# 6. Interpret (Step 12)
print("\nInterpretation: Topics represent the most frequent word clusters found in the dataset.")

# import pandas as pd
# import gensim
# from gensim import corpora
# import nltk
# from nltk.corpus import stopwords
# import string
#
# df = pd.read_csv('sentimentdataset.csv')
# df = df.dropna(subset=['Text'])
#
# stop_words = set(stopwords.words('english'))
#
#
# def clean_text(text):
#     text = text.lower().translate(str.maketrans('', '', string.punctuation))
#     return [word for word in text.split() if word not in stop_words]
#
#
# df['cleaned_text'] = df['Text'].apply(clean_text)
#
#
# dictionary = corpora.Dictionary(df['cleaned_text'])
# corpus = [dictionary.doc2bow(text) for text in df['cleaned_text']]
#
# lda = gensim.models.LdaModel(corpus=corpus, id2word=dictionary, num_topics = 3, passes=10)
#
# for i, topic in lda.print_topics(-1):
#     print(f"Topic {i}: {topic}")



#prac2

import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load CSV
df = pd.read_csv('sentimentdataset.csv')

# 2. Inspect (Required by Common Step 3)
print(df.info())
print(df.head())

# 3. Clean (Step 4 & 19)
df['Country'] = df['Country'].str.strip()
df_clean = df.dropna(subset=['Country'])

# 4. Apply method (Step 5 & 20)
location_counts = df_clean['Country'].value_counts().head(10)

# 5. Visualize (Step 6 & 21)
# plt.figure(figsize=(12, 6))
# Note: Assigning x to hue and setting legend=False avoids the DepreciationWarning
sns.barplot(x=location_counts.values, y=location_counts.index, hue=location_counts.index, palette='viridis', legend=False)

plt.title('Top 10 Most Prevalent Locations')
plt.xlabel('Number of Tweets/Posts')
plt.ylabel('Country')
plt.show()

# 6. Interpret (Required by Step 7 & 12)
print("Interpretation: The analysis shows that the most prevalent location is", location_counts.idxmax(),
      "with", location_counts.max(), "posts. This helps identify the primary geographical audience.")


#prac3
import pandas as pd
import matplotlib.pyplot as plt

# 1. Load CSV
df = pd.read_csv('sentimentdataset.csv')

# 2. Inspect & Clean (as per common steps)
# print(df['Timestamp'].head())

# 3. Convert 'Timestamp' column to datetime objects
df['Timestamp'] = pd.to_datetime(df['Timestamp'])

# 4. Apply Method: Group by Date
# We use .dt.date to ignore the hours/minutes and focus on the day
df['Date'] = df['Timestamp'].dt.date
trend_data = df.groupby('Date').size()

# 5. Visualize (Line graph for trends)
plt.figure(figsize=(12, 6))
trend_data.plot(kind='line', marker='o', color='teal', linestyle='-')

# 6. Formatting
plt.title('Social Media Activity Trend Analysis')
plt.xlabel('Date')
plt.ylabel('Number of Posts')
plt.grid(True, linestyle='--', alpha=0.7)
# plt.xticks(rotation=45) # Rotate dates for better visibility
plt.tight_layout()
plt.show()

print("Activity counts per date:")
print(trend_data.tail())


#prac 4

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load CSV
df = pd.read_csv('sentimentdataset.csv')

# 2. Clean and Extract
# Drop nulls and convert to string
df_hashtags = df.dropna(subset=['Hashtags'])
all_hashtags = []

# Loop through the column and split the hashtags
for row in df_hashtags['Hashtags']:
    # Clean the string and split by space (or comma depending on your data)
    tags = str(row).strip().split()
    all_hashtags.extend(tags)

# 3. Apply Method: Count Frequency
# Convert list to Series to use value_counts
hashtag_series = pd.Series(all_hashtags)
top_hashtags = hashtag_series.value_counts().head(10)

# 4. Visualize
plt.figure(figsize=(12, 6))
sns.barplot(x=top_hashtags.values, y=top_hashtags.index, hue=top_hashtags.index, palette='coolwarm', legend=False)

# 5. Formatting
plt.title('Top 10 Most Popular Hashtags')
plt.xlabel('Frequency')
plt.ylabel('Hashtag')
plt.show()

# 6. Interpret
print("Top 10 Hashtags:")
print(top_hashtags)


# If hastags are messy
import re
# Alternative extraction using RegEx
all_hashtags = []
for row in df_hashtags['Text']: # Extracting directly from text if Hashtag column is messy
    tags = re.findall(r"#(\w+)", str(row))
    all_hashtags.extend(tags)

#prac 5
import pandas as pd
from textblob import TextBlob
from collections import Counter
import matplotlib.pyplot as plt
import seaborn as sns
import nltk
from nltk.corpus import stopwords
import string

# 1. Load and Clean
df = pd.read_csv('sentimentdataset.csv')
df = df.dropna(subset=['Text'])
x
# 2. Sentiment Analysis (using TextBlob)
def get_sentiment(text):
    analysis = TextBlob(text)
    # Polarity is a float between -1 (negative) and 1 (positive)
    if analysis.sentiment.polarity > 0:
        return 'Positive'
    elif analysis.sentiment.polarity < 0:
        return 'Negative'
    else:
        return 'Neutral'

df['Sentiment_Type'] = df['Text'].apply(get_sentiment)

# 3. Keyword Analysis [cite: 34, 35]
stop_words = set(stopwords.words('english'))
all_words = []

for text in df['Text']:
    # Clean and tokenize
    words = text.lower().translate(str.maketrans('', '', string.punctuation)).split()
    # Remove stopwords [cite: 35]
    filtered_words = [w for w in words if w not in stop_words and len(w) > 3]
    all_words.extend(filtered_words)

word_freq = Counter(all_words).most_common(10)
words_df = pd.DataFrame(word_freq, columns=['Word', 'Count'])

# 4. Visualize Sentiment [cite: 11]
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
sns.countplot(x='Sentiment_Type', data=df, palette='viridis')
plt.title('Sentiment Classification')

# 5. Visualize Keywords [cite: 11]
plt.subplot(1, 2, 2)
sns.barplot(x='Count', y='Word', data=words_df, palette='magma')
plt.title('Top 10 Keywords')

plt.tight_layout()
plt.show()

# 6. Interpret [cite: 12]
print("Sentiment Distribution:\n", df['Sentiment_Type'].value_counts())


#prac6
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load CSV
df = pd.read_csv('sentimentdataset.csv')

# 2. Clean (Ensure numbers are numeric)
df['Likes'] = pd.to_numeric(df['Likes'], errors='coerce')
df['Retweets'] = pd.to_numeric(df['Retweets'], errors='coerce')
df = df.dropna(subset=['Likes', 'Retweets'])

# 3. Apply Method: Calculate Total Engagement
df['Total_Engagement'] = df['Likes'] + df['Retweets']

# 4. Group by Category (Let's use 'Platform' or 'Sentiment')
# Here we check which platform gets the most engagement
platform_engagement = df.groupby('Platform')['Total_Engagement'].sum().sort_values(ascending=False)

# 5. Visualize
plt.figure(figsize=(10, 6))
platform_engagement.plot(kind='bar', color='skyblue')

# 6. Formatting
plt.title('User Engagement Analysis by Platform')
plt.xlabel('Platform')
plt.ylabel('Total Likes + Retweets')
plt.xticks(rotation=45)
plt.show()

# 7. Interpret
print("Engagement by Platform:")
print(platform_engagement)
print(f"\nThe most engaging platform is: {platform_engagement.idxmax()}")

#prac7
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load CSV
df = pd.read_csv('sentimentdataset.csv')

# 2. Inspect (Common Steps 3 & 4)
print("Dataset Shape:", df.shape)
print("\nMissing Values:\n", df.isnull().sum())
print("\nSummary Statistics:\n", df.describe())

# 3. Clean numeric columns for plotting
df['Likes'] = pd.to_numeric(df['Likes'], errors='coerce')
df['Retweets'] = pd.to_numeric(df['Retweets'], errors='coerce')

# 4. Visualize (Step 6)
plt.figure(figsize=(15, 5))

# Plot 1: Distribution of Likes (Histogram)
plt.subplot(1, 3, 1)
sns.histplot(df['Likes'].dropna(), bins=20, kde=True, color='blue')
plt.title('Distribution of Likes')

# Plot 2: Sentiment Distribution (Countplot)
plt.subplot(1, 3, 2)
sns.countplot(x='Platform', data=df, palette='Set2')
plt.xticks(rotation=45)
plt.title('Posts per Platform')

# Plot 3: Correlation Heatmap
plt.subplot(1, 3, 3)
numeric_df = df[['Likes', 'Retweets']].dropna()
sns.heatmap(numeric_df.corr(), annot=True, cmap='coolwarm')
plt.title('Correlation Heatmap')
plt.tight_layout()
plt.show()

# 5. Interpret
print("\nInterpretation: The heatmap shows the strength of the relationship between Likes and Retweets.")

#prac8
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from textblob import TextBlob

# 1. Load and Inspect
df = pd.read_csv('sentimentdataset.csv')

# 2. Filter (Step 8 Logic)
# Let's analyze activity related to "Google"
brand_name = "Happiness"
brand_df = df[df['Text'].str.contains(brand_name, case=False, na=False)].copy()

# 3. Apply Sentiment Method
def get_sentiment(text):
    score = TextBlob(text).sentiment.polarity
    return 'Positive' if score > 0 else ('Negative' if score < 0 else 'Neutral')

brand_df['Sentiment'] = brand_df['Text'].apply(get_sentiment)

# 4. Visualize (Step 6)
plt.figure(figsize=(10, 5))

# Plot Sentiment for the Brand
plt.subplot(1, 2, 1)
sns.countplot(x='Sentiment', data=brand_df, palette='viridis')
plt.title(f'Sentiment for {brand_name}')

# Plot Engagement for the Brand
plt.subplot(1, 2, 2)
brand_df['Likes'] = pd.to_numeric(brand_df['Likes'], errors='coerce')
sns.boxplot(y=brand_df['Likes'], color='orange')
plt.title(f'{brand_name} Likes Distribution')

plt.tight_layout()
plt.show()

# 5. Interpret
print(f"Total posts mentioning {brand_name}: {len(brand_df)}")
print(brand_df['Sentiment'].value_counts())

#prac9
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load CSV
df = pd.read_csv('sentimentdataset.csv')
df['Likes'] = pd.to_numeric(df['Likes'], errors='coerce')

# 2. Filter for two "Competitors" (Step 48)
comp1_name = "Joy"
comp2_name = "Anger"

comp1_df = df[df['Text'].str.contains(comp1_name, case=False, na=False)].copy()
comp2_df = df[df['Text'].str.contains(comp2_name, case=False, na=False)].copy()

# 3. Compare Engagement (Step 49)
avg_likes = {
    comp1_name: comp1_df['Likes'].mean(),
    comp2_name: comp2_df['Likes'].mean()
}

# 4. Visualize (Step 11 & 49)
plt.figure(figsize=(8, 6))
sns.barplot(x=list(avg_likes.keys()), y=list(avg_likes.values()), palette='cool')

# 5. Formatting
plt.title(f'Competitor Analysis: {comp1_name} vs {comp2_name}')
plt.ylabel('Average Likes')
plt.show()

# 6. Interpret
print(f"Average Engagement - {comp1_name}: {avg_likes[comp1_name]:.2f}")
print(f"Average Engagement - {comp2_name}: {avg_likes[comp2_name]:.2f}")

#prac10

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import networkx as nx

# 1. Load CSV
df = pd.read_csv('sentimentdataset.csv')

# --- PART A: K-Means Clustering (Steps 54-57) ---
# Select features: Likes and Retweets
df['Likes'] = pd.to_numeric(df['Likes'], errors='coerce')
df['Retweets'] = pd.to_numeric(df['Retweets'], errors='coerce')
X = df[['Likes', 'Retweets']].dropna()

# Standardize data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Apply KMeans
kmeans = KMeans(n_clusters=3, random_state=42)
df.loc[X.index, 'Cluster'] = kmeans.fit_predict(X_scaled)

# Visualize Clusters
plt.figure(figsize=(8, 5))
plt.scatter(X['Likes'], X['Retweets'], c=df.loc[X.index, 'Cluster'], cmap='viridis')
plt.title('User Engagement Clusters (K-Means)')
plt.xlabel('Likes')
plt.ylabel('Retweets')
plt.show()

# --- PART B: Girvan-Newman / NetworkX (Steps 51-53) ---
# Simulating a small network of Platforms and Countries
G = nx.Graph()
for _, row in df.head(20).iterrows():
    G.add_edge(row['Platform'], row['Country'])

plt.figure(figsize=(10, 8))
nx.draw(G, with_labels=True, node_color='skyblue', node_size=2000, edge_color='gray')
plt.title('Social Network Graph: Platform-Country Connections')
plt.show()

# 7. Interpret
print("K-Means Cluster Centers:\n", kmeans.cluster_centers_)