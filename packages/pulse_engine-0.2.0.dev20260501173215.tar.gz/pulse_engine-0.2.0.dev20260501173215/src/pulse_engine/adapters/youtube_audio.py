"""YouTube audio download and Whisper transcription adapter."""

from __future__ import annotations

import asyncio
import glob
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import structlog

from pulse_engine.secrets import fetch_secret

from .models import TranscriptSegment, VideoAudio, VideoResult

logger = structlog.get_logger(__name__)

_WHISPER_MAX_BYTES = 24 * 1024 * 1024  # stay under Whisper's 25 MB hard limit
_WHISPER_CHUNK_SECS = 10 * 60  # split large files into 10-min chunks

# Default yt-dlp player clients. "tv_embedded" returns audio-only streams for
# age-restricted videos when cookies are provided. Override via YT_DLP_PLAYER_CLIENTS.
_DEFAULT_PLAYER_CLIENTS = ["tv_embedded", "web"]


def _build_yt_dlp_opts(
    output_template: str,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build yt-dlp option dict, merging env defaults with caller overrides."""
    raw_clients = os.environ.get("YT_DLP_PLAYER_CLIENTS", "").strip()
    clients: list[str] = (
        [c.strip() for c in raw_clients.split(",") if c.strip()]
        if raw_clients
        else _DEFAULT_PLAYER_CLIENTS
    )

    opts: dict[str, Any] = {
        "format": "bestaudio/best",
        "outtmpl": output_template,
        "postprocessors": [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "64",
            }
        ],
        "quiet": True,
        "no_warnings": True,
        "extractor_args": {
            "youtube": {
                "player_client": clients,
            }
        },
    }

    if not extra:
        return opts

    override = dict(extra)
    # cookies_content is handled separately — materialised to a temp file.
    override.pop("cookies_content", None)
    ea = override.pop("extractor_args", None)
    opts.update(override)
    if isinstance(ea, dict):
        existing = opts.get("extractor_args") or {}
        merged: dict[str, Any] = {**existing}
        for k, v in ea.items():
            if isinstance(v, dict) and isinstance(merged.get(k), dict):
                merged[k] = {**merged[k], **v}
            else:
                merged[k] = v
        opts["extractor_args"] = merged

    return opts


class YouTubeAudioAdapter:
    """Downloads audio from YouTube and transcribes via OpenAI Whisper.

    Mirrors the ``DigitalNewsAdapter`` interface: construct with credentials,
    call ``fetch()`` for a single video or ``fetch_many()`` for a batch.

    Usage::

        adapter = YouTubeAudioAdapter(openai_api_key="sk-...")
        audio = await adapter.fetch("dQw4w9WgXcQ", language="en")

        results = await adapter.fetch_many(
            ["id1", "id2", "id3"],
            language="hi",
            concurrency=3,
        )

    Environment variables:
        - ``YT_DLP_PLAYER_CLIENTS``    — comma-separated yt-dlp client list
        - ``YT_DLP_COOKIES_SECRET_ID`` — Secrets Manager secret name/ARN for cookies.txt
        - ``AWS_REGION``               — region for Secrets Manager (default: us-east-1)
    """

    def __init__(
        self,
        openai_api_key: str,
        yt_dlp_opts: dict[str, Any] | None = None,
    ) -> None:
        self._openai_api_key = openai_api_key
        self._yt_dlp_opts = yt_dlp_opts or {}
        self._cookies_secret_id: str = os.environ.get(
            "YT_DLP_COOKIES_SECRET_ID", ""
        ).strip()
        self._aws_region: str = os.environ.get("AWS_REGION", "us-east-1").strip()
        self._cookies_cache: str | None = None  # lazily populated

    async def fetch(self, video_id: str, language: str = "en") -> VideoAudio:
        """Download and transcribe a single video. Raises on failure."""
        url = f"https://www.youtube.com/watch?v={video_id}"
        logger.info("youtube_audio_fetch_started", video_id=video_id, language=language)

        with tempfile.TemporaryDirectory() as tmp_dir:
            audio_path = await self._download_audio(url, tmp_dir)
            if audio_path is None:
                raise RuntimeError(f"Audio download failed for {video_id}")
            transcript, segments = await self._transcribe(audio_path, language=language)

        logger.info(
            "youtube_audio_fetch_completed",
            video_id=video_id,
            segments=len(segments),
            chars=len(transcript),
        )
        return VideoAudio(transcript=transcript, language=language, segments=segments)

    async def fetch_many(
        self,
        video_ids: list[str],
        language: str = "en",
        concurrency: int = 3,
    ) -> list[VideoResult]:
        """Transcribe multiple videos concurrently, preserving input order."""
        if not video_ids:
            return []

        semaphore = asyncio.Semaphore(concurrency)

        async def _guarded(vid: str) -> VideoResult:
            async with semaphore:
                try:
                    audio = await self.fetch(vid, language=language)
                    return VideoResult(video_id=vid, audio=audio, error=None)
                except Exception as exc:
                    logger.warning(
                        "youtube_audio_fetch_failed", video_id=vid, error=str(exc)
                    )
                    return VideoResult(video_id=vid, audio=None, error=str(exc))

        tasks = [_guarded(vid) for vid in video_ids]
        return list(await asyncio.gather(*tasks))

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _resolve_cookies(self) -> str:
        """Return cookies.txt content, fetching from Secrets Manager if configured.

        Result is cached after the first successful fetch so subsequent videos
        in the same adapter instance don't make redundant API calls.
        """
        if self._cookies_cache is not None:
            return self._cookies_cache

        if not self._cookies_secret_id:
            self._cookies_cache = ""
            return ""

        logger.debug(
            "youtube_cookies_fetching_secret",
            secret_id=self._cookies_secret_id,
            region=self._aws_region,
        )
        import json as _json

        raw = await fetch_secret(self._cookies_secret_id, self._aws_region)
        # Secret may be stored as {"YT_DLP_COOKIES_SECRET_ID": "<netscape txt>"}
        try:
            parsed = _json.loads(raw)
            if isinstance(parsed, dict):
                for v in parsed.values():
                    if isinstance(v, str):
                        raw = v
                        break
        except ValueError:
            pass
        cookies = raw
        self._cookies_cache = cookies
        logger.info(
            "youtube_cookies_loaded_from_secrets_manager",
            secret_id=self._cookies_secret_id,
            chars=len(cookies),
        )
        return cookies

    async def _download_audio(self, url: str, output_dir: str) -> Path | None:
        """Download audio from a YouTube URL to *output_dir* via yt-dlp."""
        try:
            import yt_dlp
        except ImportError:
            logger.warning("yt_dlp_not_installed", url=url)
            return None

        output_template = str(Path(output_dir) / "%(id)s.%(ext)s")
        ydl_opts = _build_yt_dlp_opts(output_template, extra=self._yt_dlp_opts)

        # Resolve cookies (priority: Secrets Manager > env var).
        cookies_content = await self._resolve_cookies()
        if cookies_content and "cookiefile" not in ydl_opts:
            cookies_path = Path(output_dir) / "cookies.txt"
            cookies_path.write_text(cookies_content, encoding="utf-8")
            try:
                os.chmod(cookies_path, 0o600)
            except OSError:
                pass
            ydl_opts["cookiefile"] = str(cookies_path)

        def _download() -> Path | None:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                candidate = Path(output_dir) / f"{info.get('id', '')}.mp3"
                return candidate if candidate.exists() else None

        try:
            return await asyncio.to_thread(_download)
        except Exception:
            logger.warning("youtube_audio_download_failed", url=url, exc_info=True)
            return None

    async def _transcribe(
        self, audio_path: Path, language: str
    ) -> tuple[str, list[TranscriptSegment]]:
        """Send audio to Whisper, returning (full_text, segments).

        Large files (>24 MB) are split into 10-minute chunks via ffmpeg and
        stitched back together with adjusted timestamps.
        """
        # Empty language string signals Whisper auto-detect.
        whisper_language = "" if language.lower() == "auto" else language

        try:
            from openai import AsyncOpenAI

            client = AsyncOpenAI(api_key=self._openai_api_key)

            def _transcribe_file(path: Path, offset: float) -> list[TranscriptSegment]:
                import asyncio as _asyncio

                loop = _asyncio.new_event_loop()
                try:
                    with open(path, "rb") as fobj:
                        kwargs: dict[str, Any] = {
                            "model": "whisper-1",
                            "file": fobj,
                            "response_format": "verbose_json",
                            "timestamp_granularities": ["segment"],
                        }
                        if whisper_language:
                            kwargs["language"] = whisper_language
                        resp = loop.run_until_complete(
                            client.audio.transcriptions.create(**kwargs)
                        )
                finally:
                    loop.close()

                raw = getattr(resp, "segments", None) or []
                return [
                    TranscriptSegment(
                        start=float(
                            s.get("start", 0) if isinstance(s, dict) else s.start
                        )
                        + offset,
                        end=float(s.get("end", 0) if isinstance(s, dict) else s.end)
                        + offset,
                        text=(
                            s.get("text", "") if isinstance(s, dict) else s.text
                        ).strip(),
                    )
                    for s in raw
                ]

            file_size = audio_path.stat().st_size

            if file_size <= _WHISPER_MAX_BYTES:
                segments = await asyncio.to_thread(_transcribe_file, audio_path, 0.0)
            else:
                logger.info(
                    "youtube_whisper_splitting_large_file",
                    size_mb=round(file_size / (1024 * 1024), 1),
                )

                def _split_and_transcribe() -> list[TranscriptSegment]:
                    with tempfile.TemporaryDirectory(prefix="whisper_chunks_") as td:
                        chunk_pattern = os.path.join(td, "chunk_%04d.mp3")
                        subprocess.run(
                            [
                                "ffmpeg",
                                "-i",
                                str(audio_path),
                                "-f",
                                "segment",
                                "-segment_time",
                                str(_WHISPER_CHUNK_SECS),
                                "-c",
                                "copy",
                                "-reset_timestamps",
                                "1",
                                chunk_pattern,
                            ],
                            check=True,
                            capture_output=True,
                        )
                        chunk_files = sorted(glob.glob(os.path.join(td, "chunk_*.mp3")))
                        all_segs: list[TranscriptSegment] = []
                        offset = 0.0
                        for chunk_path in chunk_files:
                            segs = _transcribe_file(Path(chunk_path), offset)
                            if segs:
                                offset = segs[-1].end
                            all_segs.extend(segs)
                    return all_segs

                segments = await asyncio.to_thread(_split_and_transcribe)

            full_text = " ".join(s.text for s in segments)
            return full_text, segments

        except Exception:
            logger.warning(
                "youtube_whisper_transcription_failed",
                audio_path=str(audio_path),
                exc_info=True,
            )
            return "", []
