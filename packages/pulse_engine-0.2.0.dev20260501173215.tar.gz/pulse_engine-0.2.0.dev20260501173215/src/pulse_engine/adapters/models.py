"""Data models for digital news, speech, YouTube, and Twitter adapters."""

from dataclasses import dataclass, field
from datetime import datetime

# ---------------------------------------------------------------------------
# Digital news models
# ---------------------------------------------------------------------------


@dataclass
class NewsArticleMetadata:
    url: str
    title: str | None
    publication_name: str | None
    language: str | None
    publication_date: datetime | None
    keywords: list[str]


@dataclass
class ArticleContent:
    title: str
    content: str


@dataclass
class ArticleResult:
    url: str
    content: ArticleContent | None
    error: str | None


# ---------------------------------------------------------------------------
# Speech models
# ---------------------------------------------------------------------------


@dataclass
class SpeechMetadata:
    url: str
    title: str | None
    speaker: str | None
    speech_date: datetime | None
    pdf_url: str | None
    youtube_url: str | None
    language: str | None


@dataclass
class SpeechContent:
    text: str
    language: str
    pdf_url: str | None


@dataclass
class SpeechResult:
    url: str
    content: SpeechContent | None
    error: str | None


# ---------------------------------------------------------------------------
# Twitter models
# ---------------------------------------------------------------------------


@dataclass
class TweetMetadata:
    tweet_id: str
    url: str
    text: str
    screen_name: str
    created_at: datetime
    language: str
    hashtags: list[str]
    embedded_urls: list[str]
    views: int
    retweet_count: int
    like_count: int
    reply_count: int
    has_images: bool
    has_videos: bool


@dataclass
class TwitterUserResult:
    screen_name: str
    tweets: list[TweetMetadata]
    error: str | None


# ---------------------------------------------------------------------------
# YouTube models
# ---------------------------------------------------------------------------


@dataclass
class VideoMetadata:
    video_id: str
    url: str
    title: str
    channel_id: str
    channel_name: str
    published_at: datetime
    description: str
    tags: list[str]
    duration_seconds: int
    view_count: str | None
    like_count: str | None
    comment_count: str | None


@dataclass
class TranscriptSegment:
    start: float
    end: float
    text: str


@dataclass
class VideoAudio:
    transcript: str
    language: str
    segments: list[TranscriptSegment] = field(default_factory=list)


@dataclass
class VideoResult:
    video_id: str
    audio: VideoAudio | None
    error: str | None
