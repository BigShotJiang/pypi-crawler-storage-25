"""Pulse Engine adapters — digital news, YouTube, speech, and Twitter."""

from .digital_news import DigitalNewsAdapter
from .digital_news_metadata import DigitalNewsMetadataAdapter
from .exceptions import SitemapDiscoveryError
from .models import (
    ArticleContent,
    ArticleResult,
    NewsArticleMetadata,
    SpeechContent,
    SpeechMetadata,
    SpeechResult,
    TranscriptSegment,
    TweetMetadata,
    TwitterUserResult,
    VideoAudio,
    VideoMetadata,
    VideoResult,
)
from .speech_content import SpeechContentAdapter
from .speech_metadata import SpeechMetadataAdapter
from .twitter import TwitterAdapter
from .youtube_audio import YouTubeAudioAdapter
from .youtube_metadata import YouTubeMetadataAdapter

__all__ = [
    # Digital news
    "DigitalNewsMetadataAdapter",
    "DigitalNewsAdapter",
    "NewsArticleMetadata",
    "ArticleContent",
    "ArticleResult",
    "SitemapDiscoveryError",
    # YouTube
    "YouTubeMetadataAdapter",
    "YouTubeAudioAdapter",
    "VideoMetadata",
    "VideoAudio",
    "VideoResult",
    "TranscriptSegment",
    # Speeches
    "SpeechMetadataAdapter",
    "SpeechContentAdapter",
    "SpeechMetadata",
    "SpeechContent",
    "SpeechResult",
    # Twitter
    "TwitterAdapter",
    "TweetMetadata",
    "TwitterUserResult",
]
