from __future__ import annotations

import base64
from typing import Any

import httpx

from pulse_engine.pipeline.schemas import PipelineConfig, SecretRef
from pulse_engine.pipeline.translators.base import BaseTranslator


class PrefectTranslator(BaseTranslator):
    """Translates a PipelineConfig into a Prefect flow run submission."""

    FLOW_ENTRYPOINT = "pulse_engine.runners.prefect_pipeline_flow:pipeline_flow"

    def __init__(
        self,
        prefect_api_url: str,
        prefect_api_key: str,
        work_pool_name: str,
        engine_image: str = "",
        http_client: httpx.AsyncClient | None = None,
    ) -> None:
        self._api_url = prefect_api_url.rstrip("/")
        self._api_key = prefect_api_key
        self._work_pool_name = work_pool_name
        self._engine_image = engine_image
        self._client = http_client

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        auth_header = base64.b64encode(f":{self._api_key}".encode()).decode()
        return httpx.AsyncClient(
            headers={"Authorization": f"Basic {auth_header}"},
            timeout=30.0,
        )

    def _serialize_dag(self, config: PipelineConfig) -> list[dict[str, Any]]:
        """Serialize v2 DAG into a JSON-friendly list for Prefect flow parameters."""
        module_map = {m.name: m for m in config.modules}
        steps = []
        for s in config.dag:
            module = module_map[s.module]
            step_dict: dict[str, Any] = {
                "step": s.step,
                "module": s.module,
                "module_type": module.module,
                "retries": module.retries,
                "retry_delay": module.retry_delay,
                "timeout": module.timeout,
                "max_concurrency": module.max_concurrency,
                "args": module.args,
                "env": {
                    k: v.model_dump() if isinstance(v, SecretRef) else v
                    for k, v in module.env.items()
                },
                "resources": module.resources.model_dump(),
            }
            if s.for_each is not None:
                step_dict["for_each"] = s.for_each
            if s.collect_from is not None:
                step_dict["collect_from"] = (
                    [s.collect_from]
                    if isinstance(s.collect_from, str)
                    else list(s.collect_from)
                )
            if s.when is not None:
                step_dict["when"] = s.when
            steps.append(step_dict)
        return steps

    async def _ensure_deployment(
        self, client: httpx.AsyncClient, pipeline_name: str
    ) -> str:
        """Create or update the Prefect deployment for this pipeline.

        Returns the deployment ID.
        """
        deployment_name = self._get_deployment_name(pipeline_name)

        # Get or create the flow (idempotent — Prefect returns existing if name matches)
        flow_resp = await client.post(
            f"{self._api_url}/flows/",
            json={"name": deployment_name},
        )
        flow_resp.raise_for_status()
        flow_id = str(flow_resp.json()["id"])

        # Upsert deployment
        deploy_resp = await client.post(
            f"{self._api_url}/deployments/",
            json={
                "name": deployment_name,
                "flow_id": flow_id,
                "entrypoint": self.FLOW_ENTRYPOINT,
                "work_pool_name": self._work_pool_name,
                "job_variables": {"image": self._engine_image},
            },
        )
        deploy_resp.raise_for_status()
        return str(deploy_resp.json()["id"])

    async def submit(
        self,
        pipeline_run_id: str,
        parsed_config: PipelineConfig,
        module_images: dict[str, str],
        input_data: list[dict[str, Any]],
        global_config: dict[str, Any],
        tenant_id: str,
        pulse_engine_url: str,
        pulse_api_token: str,
    ) -> str:
        """Submit a pipeline as a Prefect flow run, upserting the deployment first."""
        client = self._get_client()

        parameters = {
            "pipeline_run_id": pipeline_run_id,
            "tenant_id": tenant_id,
            "dag": self._serialize_dag(parsed_config),
            "module_images": module_images,
            "global_config": global_config,
            "pulse_engine_url": pulse_engine_url,
            "pulse_api_token": pulse_api_token,
            # input_data intentionally excluded — v2 root steps use module.args
        }

        body = {
            "parameters": parameters,
            "state": {"type": "SCHEDULED"},
            "tags": [f"product:{parsed_config.name}", f"pipeline:{pipeline_run_id}"],
        }

        try:
            deployment_id = await self._ensure_deployment(client, parsed_config.name)

            response = await client.post(
                f"{self._api_url}/deployments/{deployment_id}/create_flow_run",
                json=body,
            )
            response.raise_for_status()
            data = response.json()
            return str(data["id"])
        finally:
            if self._client is None:
                await client.aclose()

    async def _resolve_deployment_id(
        self, client: httpx.AsyncClient, deployment_name: str
    ) -> str:
        """Look up a Prefect deployment ID by name."""
        response = await client.post(
            f"{self._api_url}/deployments/filter",
            json={
                "deployments": {"name": {"any_": [deployment_name]}},
                "limit": 1,
            },
        )
        response.raise_for_status()
        deployments = response.json()
        if not deployments:
            raise RuntimeError(
                f"Prefect deployment '{deployment_name}' not found. "
                f"Create it first with: prefect deployment build ..."
            )
        return str(deployments[0]["id"])

    def _get_deployment_name(self, pipeline_name: str) -> str:
        """Deployment name for the generic pipeline flow."""
        return f"pulse-pipeline-{pipeline_name}"
