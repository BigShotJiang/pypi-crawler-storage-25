from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


class SecretRef(BaseModel):
    from_secret: str  # AWS Secrets Manager ARN or name


class ResourceConfig(BaseModel):
    cpu: int = Field(default=256, gt=0, description="ECS CPU units (256 = 0.25 vCPU)")
    memory: int = Field(default=512, gt=0, description="MB")
    storage: int | None = Field(
        default=None, gt=0, description="GB ephemeral storage (ECS only)"
    )


class ModuleConfig(BaseModel):
    name: str
    module: str  # module type → MODULE_NAME env var in container
    retries: int = Field(default=0, ge=0)
    retry_delay: int = Field(default=0, ge=0, description="Seconds between retries")
    timeout: int = Field(
        default=3600, gt=0, description="Seconds before container killed"
    )
    max_concurrency: int | None = Field(
        default=None, gt=0, description="Max parallel fan-out tasks (None = unlimited)"
    )
    resources: ResourceConfig = Field(default_factory=ResourceConfig)
    args: dict[str, Any] = Field(default_factory=dict)
    env: dict[str, str | SecretRef] = Field(default_factory=dict)


class StepConfig(BaseModel):
    step: str
    module: str  # references ModuleConfig.name
    for_each: str | None = None  # expression: $args.X, $steps.S.output[.F], $collect.F
    collect_from: str | list[str] | None = None  # step name(s) to collect from
    when: str | None = None  # deferred v2.1 — stored but not evaluated


class InfraConfig(BaseModel):
    orchestrator: Literal["prefect", "airflow"] = "prefect"
    default_compute: Literal["ecs", "lambda"] = "ecs"
    schedule: str | None = None  # cron string — stored, not wired to scheduler in v2.0


class PipelineConfig(BaseModel):
    name: str
    version: str = "2.0"
    infra: InfraConfig = Field(default_factory=InfraConfig)
    modules: list[ModuleConfig]
    dag: list[StepConfig]
    config: dict[str, Any] = Field(default_factory=dict)

    @field_validator("version")
    @classmethod
    def validate_version(cls, v: str) -> str:
        if v != "2.0":
            raise ValueError(
                f"Unsupported pipeline version {v!r}. Only '2.0' supported."
            )
        return v


# ---------------------------------------------------------------------------
# API Request / Response Schemas  (unchanged from v1)
# ---------------------------------------------------------------------------


class ModuleImageDef(BaseModel):
    image: str


class TriggerPayload(BaseModel):
    product: str
    orchestrator: Literal["prefect", "airflow"]
    input: list[dict[str, Any]] = Field(default_factory=list)
    config: dict[str, Any] = Field(default_factory=dict)


class PipelineRunStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"
    cancelled = "cancelled"
    submission_failed = "submission_failed"


class StepStatus(BaseModel):
    step: str
    module: str
    status: str
    fan_out_count: int | None = None
    completed_count: int | None = None
    failed_count: int | None = None
    started_at: datetime | None = None


class PipelineStatusResponse(BaseModel):
    run_id: str
    product: str
    orchestrator: str
    status: PipelineRunStatus
    started_at: datetime | None = None
    steps: list[StepStatus] = Field(default_factory=list)


class TriggerResponse(BaseModel):
    run_id: str


class RegisterModulesRequest(BaseModel):
    product: str
    modules: dict[str, ModuleImageDef]


class RegisterModulesResponse(BaseModel):
    product: str
    modules: dict[str, dict[str, str]]


class PipelineRunListResponse(BaseModel):
    items: list[PipelineStatusResponse]
    total: int
    limit: int
    offset: int
