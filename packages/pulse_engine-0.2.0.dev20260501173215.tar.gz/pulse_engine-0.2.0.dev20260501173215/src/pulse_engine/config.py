from functools import lru_cache

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_env: str = "development"
    app_version: str = "0.1.0"
    debug: bool = False
    log_level: str = "INFO"

    # AWS core credentials
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_region: str = "ap-south-1"
    cognito_user_pool_id: str = ""
    cognito_app_client_id: str = ""
    cognito_app_client_secret: str = ""

    # OpenSearch (hosted AWS)
    opensearch_url: str = ""
    opensearch_username: str = ""
    opensearch_password: str = ""
    opensearch_use_ssl: bool = True
    opensearch_verify_certs: bool = True
    opensearch_index_prefix: str = "pulse_kb"

    # Prefect
    prefect_api_url: str = ""
    prefect_database_url: str = ""

    # Athena (separate credentials — product specifies which database)
    athena_aws_access_key_id: str = ""
    athena_aws_secret_access_key: str = ""
    athena_output_location: str = ""
    athena_workgroup: str = "primary"
    athena_query_timeout_seconds: int = 60
    embedding_dimension: int = 1536

    # Database (app)
    database_url: str = ""

    # Redis / Celery
    redis_url: str = "redis://localhost:6379/0"
    celery_broker_url: str = ""  # defaults to redis_url if empty
    celery_result_backend: str = ""  # defaults to redis_url if empty

    # Orchestrator
    pulse_orchestrator_backend: str = "none"
    prefect_api_key: str = ""

    # Prefect ECS backend
    prefect_ecs_work_pool_name: str = "products-worker-pool"
    # ECR image used to run pipeline_flow in ECS work pool
    prefect_engine_image: str = ""
    # Override compute backend for all pipeline steps ("ecs", "local", etc.)
    pipeline_default_compute: str = ""

    # Prefect Lambda backend
    prefect_lambda_work_pool_name: str = "lambda-worker-pool"
    prefect_lambda_function_name_template: str = "{product}-{stage}"

    # Prefect Kubernetes backend
    prefect_k8s_work_pool_name: str = "k8s-worker-pool"
    prefect_k8s_namespace: str = "pulse-jobs"
    prefect_k8s_default_cpu: str = "500m"
    prefect_k8s_default_memory: str = "1Gi"
    pulse_max_concurrent_jobs_per_tenant: int = 10
    pulse_embedding_model: str = "text-embedding-3-small"
    pulse_embedding_provider: str = "openai"
    pulse_openai_embedding_model: str = "text-embedding-3-small"
    pulse_openai_api_key: str = ""  # falls back to pulse_llm_api_key

    # LLM
    pulse_llm_provider: str = "openai"
    pulse_llm_model: str = "gpt-4o-mini"
    pulse_llm_api_key: str = ""
    pulse_llm_temperature: float = 0.0
    pulse_default_chunk_size: int = 512
    pulse_default_chunk_strategy: str = "token_count"
    pulse_job_callback_timeout: int = 10
    pulse_dedup_similarity_threshold: float = 0.95

    # Pipeline separation
    pulse_engine_url: str = ""  # public URL containers use to call back
    pulse_job_token_secret: str = ""  # HMAC secret for job-scoped JWTs
    pulse_s3_bucket: str = ""  # S3 bucket for inter-stage data
    pulse_chain_grace_period_seconds: int = (
        300  # seconds before auto-triggering next stage
    )

    # Pipeline infrastructure — populated from Terraform outputs
    pipeline_task_definition: str = "pulse-pipeline-step"  # ECS task def family
    pipeline_cluster_name: str = ""  # ECS cluster for pipeline steps
    pipeline_execution_role_arn: str = ""  # ECS task execution role
    pipeline_task_role_arn: str = ""  # ECS task role (S3, Lambda, ECS perms)
    pipeline_log_group: str = ""  # CloudWatch log group for ECS steps
    pipeline_subnets: str = ""  # comma-separated private subnet IDs
    pipeline_security_groups: str = ""  # comma-separated security group IDs
    lambda_execution_role_arn: str = ""  # Lambda execution role
    lambda_subnets: str = ""  # comma-separated subnet IDs for Lambda VPC
    lambda_security_groups: str = ""  # comma-separated SG IDs for Lambda
    lambda_log_group: str = ""  # CloudWatch log group for Lambda steps

    # Local dev auth bypass — set this to use MockTokenVerifier instead of Cognito
    mock_jwt_secret: str = ""

    mcp_transport: str = "sse"
    mcp_sse_host: str = "127.0.0.1"
    mcp_sse_port: int = 8001

    @property
    def effective_celery_broker_url(self) -> str:
        return self.celery_broker_url or self.redis_url

    @property
    def effective_celery_result_backend(self) -> str:
        return self.celery_result_backend or self.redis_url

    @property
    def cognito_jwks_url(self) -> str:
        return (
            f"https://cognito-idp.{self.aws_region}.amazonaws.com/"
            f"{self.cognito_user_pool_id}/.well-known/jwks.json"
        )

    @property
    def cognito_issuer(self) -> str:
        return (
            f"https://cognito-idp.{self.aws_region}.amazonaws.com/"
            f"{self.cognito_user_pool_id}"
        )

    @property
    def pipeline_subnet_list(self) -> list[str]:
        return [s.strip() for s in self.pipeline_subnets.split(",") if s.strip()]

    @property
    def pipeline_sg_list(self) -> list[str]:
        return [
            s.strip() for s in self.pipeline_security_groups.split(",") if s.strip()
        ]

    @property
    def lambda_subnet_list(self) -> list[str]:
        return [s.strip() for s in self.lambda_subnets.split(",") if s.strip()]

    @property
    def lambda_sg_list(self) -> list[str]:
        return [s.strip() for s in self.lambda_security_groups.split(",") if s.strip()]

    model_config = {"env_file": ".env", "extra": "ignore"}


@lru_cache
def get_settings() -> Settings:
    return Settings()
