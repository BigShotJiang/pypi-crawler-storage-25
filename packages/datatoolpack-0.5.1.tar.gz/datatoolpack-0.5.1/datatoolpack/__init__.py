from .client import AutoDataClient, AutoDataError

__version__ = "0.5.1"
__all__ = ["AutoDataClient", "AutoDataError", "__version__"]
