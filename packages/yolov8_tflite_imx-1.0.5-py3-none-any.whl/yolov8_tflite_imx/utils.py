"""
Shared utilities for YOLOv8 TFLite inference.
"""

import cv2
import numpy as np

DEFAULT_NPU_DELEGATE = "/usr/lib/libvx_delegate.so"


# ─── Model loading ─────────────────────────────────────────────────────────────

def load_interpreter(model_path: str, delegate_path: str = None):
    """
    Load a TFLite interpreter with an optional NPU delegate.

    Args:
        model_path:    Path to the .tflite model file.
        delegate_path: Path to the delegate .so (e.g. libvx_delegate.so).
                       Pass None to use CPU only.

    Returns:
        interp, input_details[0], output_details (list), input_size,
        (in_scale, in_zp), in_dtype
    """
    try:
        from tflite_runtime.interpreter import Interpreter, load_delegate
    except ImportError:
        try:
            from tensorflow.lite.python.interpreter import Interpreter, load_delegate
        except ImportError:
            raise ImportError(
                "Neither tflite_runtime nor tensorflow found.\n"
                "Install with:  pip install tflite-runtime"
            )

    delegates = []
    if delegate_path:
        try:
            print(f"[Delegate] Loading: {delegate_path}")
            delegates.append(load_delegate(delegate_path))
            print("[Delegate] NPU delegate loaded successfully.")
        except Exception as exc:
            print(f"[Delegate] WARNING: {exc}")
            print("[Delegate] Falling back to CPU.")

    interp = Interpreter(
        model_path=model_path,
        experimental_delegates=delegates if delegates else None,
    )
    interp.allocate_tensors()

    inp      = interp.get_input_details()[0]
    out_dets = interp.get_output_details()

    in_scale, in_zp = inp["quantization"]
    input_size       = inp["shape"][1]   # e.g. 640
    in_dtype         = inp["dtype"]

    backend = f"NPU ({delegate_path})" if delegates else "CPU"
    print(f"[Model] Backend : {backend}")
    print(f"[Model] Input   dtype={in_dtype.__name__}  shape={inp['shape']}  "
          f"quant=({in_scale:.6f}, {in_zp})")

    return interp, inp, out_dets, input_size, (in_scale, in_zp), in_dtype


# ─── Pre-processing ────────────────────────────────────────────────────────────

def letterbox(img, size=640):
    """
    Resize while keeping aspect ratio, then pad to a square.

    Returns:
        img       : padded image (size x size)
        pad_info  : (pad_left, pad_top, scale)
    """
    h, w = img.shape[:2]
    scale = size / max(h, w)
    nh, nw = int(round(h * scale)), int(round(w * scale))
    img = cv2.resize(img, (nw, nh), interpolation=cv2.INTER_LINEAR)
    pl = (size - nw) // 2
    pt = (size - nh) // 2
    img = cv2.copyMakeBorder(
        img, pt, size - nh - pt, pl, size - nw - pl,
        cv2.BORDER_CONSTANT, value=(114, 114, 114),
    )
    return img, (pl, pt, scale)


def preprocess(frame, input_size, in_dtype, in_scale, in_zp):
    """
    BGR frame  →  quantised tensor  (1, H, W, 3).

    Returns:
        tensor   : numpy array ready for set_tensor()
        pad_info : (pad_left, pad_top, scale)
    """
    img, pad_info = letterbox(frame, input_size)
    rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    if in_dtype == np.int8:
        tensor = (rgb.astype(np.float32) / 255.0 / in_scale + in_zp).clip(-128, 127).astype(np.int8)
    elif in_dtype == np.uint8:
        tensor = (rgb.astype(np.float32) / 255.0 / in_scale + in_zp).clip(0, 255).astype(np.uint8)
    else:
        tensor = rgb.astype(np.float32) / 255.0

    return np.expand_dims(tensor, 0), pad_info


def dequantize(tensor, scale, zp):
    """INT8 / UINT8 tensor  →  float32."""
    return (tensor.astype(np.float32) - zp) * scale


# ─── Camera helpers ───────────────────────────────────────────────────────────

def open_camera(cam_id: int, width: int = 1280, height: int = 720, use_gst: bool = True):
    """
    Open a camera, trying GStreamer pipelines first, then V4L2, then default.

    Returns:
        cv2.VideoCapture object (already opened), or raises RuntimeError.
    """
    if use_gst:
        pipelines = [
            (f"v4l2src device=/dev/video{cam_id} ! "
             f"video/x-raw,width={width},height={height},framerate=30/1 ! "
             f"videoconvert ! video/x-raw,format=BGR ! appsink drop=1"),

            (f"v4l2src device=/dev/video{cam_id} ! "
             f"video/x-raw,width={width},height={height} ! "
             f"imxvideoconvert_g2d ! video/x-raw,format=BGR ! appsink drop=1"),

            (f"v4l2src device=/dev/video{cam_id} ! "
             f"videoconvert ! videoscale ! "
             f"video/x-raw,width={width},height={height},format=BGR ! appsink drop=1"),

            (f"v4l2src device=/dev/video{cam_id} ! "
             f"video/x-raw,width=640,height=480 ! "
             f"videoconvert ! video/x-raw,format=BGR ! appsink drop=1"),
        ]

        for i, pl in enumerate(pipelines, 1):
            print(f"[Camera] Trying GStreamer pipeline {i} …")
            cap = cv2.VideoCapture(pl, cv2.CAP_GSTREAMER)
            if cap.isOpened():
                ret, frame = cap.read()
                if ret and frame is not None:
                    print(f"[Camera] GStreamer pipeline {i} succeeded.")
                    return cap
            cap.release()

        print("[Camera] All GStreamer pipelines failed, trying V4L2 …")

    # V4L2 fallback
    cap = cv2.VideoCapture(cam_id, cv2.CAP_V4L2)
    if cap.isOpened():
        cap.set(cv2.CAP_PROP_FRAME_WIDTH,  width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        ret, frame = cap.read()
        if ret and frame is not None:
            print("[Camera] V4L2 backend succeeded.")
            return cap
        cap.release()

    # Last resort
    cap = cv2.VideoCapture(cam_id)
    if cap.isOpened():
        cap.set(cv2.CAP_PROP_FRAME_WIDTH,  width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        print("[Camera] Default backend opened (may be unstable).")
        return cap

    raise RuntimeError(
        f"Cannot open camera {cam_id}. "
        "Check available devices with:  v4l2-ctl --list-devices"
    )
