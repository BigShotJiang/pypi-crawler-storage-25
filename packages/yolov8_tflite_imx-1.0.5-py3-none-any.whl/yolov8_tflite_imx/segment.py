"""
YOLOv8n-Seg Instance Segmentation — INT8 TFLite inference.
CLI entry-point: segment
"""

import argparse
import time

import cv2
import numpy as np

from .models import get_model_path
from .utils import (
    DEFAULT_NPU_DELEGATE, load_interpreter, preprocess, dequantize, open_camera,
)
from .detect import COCO_CLASSES, COLORS   # reuse detection labels/colours

MASK_ALPHA = 0.45


# ─── Model loading (two outputs) ──────────────────────────────────────────────

def load_seg_model(model_path, delegate_path=None):
    interp, inp, out_dets, input_size, (in_sc, in_zp), in_dtype = \
        load_interpreter(model_path, delegate_path)

    det_out = proto_out = None
    for o in out_dets:
        if len(o["shape"]) == 3:    # (1, 116, 8400)
            det_out = o
        elif len(o["shape"]) == 4:  # (1, 160, 160, 32)
            proto_out = o

    assert det_out   is not None, "Detection output (1,116,8400) not found!"
    assert proto_out is not None, "Prototype output (1,160,160,32) not found!"

    print(f"[Model] det   dtype={det_out['dtype'].__name__}   shape={det_out['shape']}  "
          f"quant={det_out['quantization']}")
    print(f"[Model] proto dtype={proto_out['dtype'].__name__}  shape={proto_out['shape']}  "
          f"quant={proto_out['quantization']}")

    return interp, inp, det_out, proto_out, input_size, (in_sc, in_zp), in_dtype


# ─── Post-processing ──────────────────────────────────────────────────────────

def postprocess(raw_det, raw_proto, pad_info, orig_shape,
                det_scale, det_zp, proto_scale, proto_zp,
                conf_thr=0.25, iou_thr=0.45, input_size=640, mask_thr=0.5):

    det   = dequantize(raw_det[0],   det_scale,   det_zp)    # (116, 8400)
    proto = dequantize(raw_proto[0], proto_scale, proto_zp)  # (160, 160, 32)

    boxes_xywh   = det[:4,   :].T * input_size   # (8400, 4)
    class_scores = det[4:84, :].T                # (8400, 80)
    mask_coefs   = det[84:,  :].T                # (8400, 32)

    scores    = class_scores.max(axis=1)
    class_ids = class_scores.argmax(axis=1)

    mask = scores >= conf_thr
    if mask.sum() == 0:
        return [], [], [], []

    boxes_xywh = boxes_xywh[mask]
    scores     = scores[mask]
    class_ids  = class_ids[mask]
    mask_coefs = mask_coefs[mask]

    x1 = boxes_xywh[:, 0] - boxes_xywh[:, 2] / 2
    y1 = boxes_xywh[:, 1] - boxes_xywh[:, 3] / 2
    x2 = boxes_xywh[:, 0] + boxes_xywh[:, 2] / 2
    y2 = boxes_xywh[:, 1] + boxes_xywh[:, 3] / 2
    boxes_xyxy = np.stack([x1, y1, x2, y2], axis=1)

    keep = []
    for cid in np.unique(class_ids):
        m   = class_ids == cid
        idx = np.where(m)[0]
        b, s = boxes_xyxy[m], scores[m]
        xywh = [[bx[0], bx[1], bx[2]-bx[0], bx[3]-bx[1]] for bx in b]
        nms  = cv2.dnn.NMSBoxes(xywh, s.tolist(), conf_thr, iou_thr)
        if len(nms) > 0:
            keep.extend(idx[nms.flatten()])

    keep       = np.array(keep)
    boxes_xyxy = boxes_xyxy[keep]
    scores     = scores[keep]
    class_ids  = class_ids[keep]
    mask_coefs = mask_coefs[keep]

    pl, pt, scale = pad_info
    oh, ow = orig_shape[:2]
    boxes_orig = boxes_xyxy.copy()
    boxes_orig[:, [0, 2]] = ((boxes_xyxy[:, [0, 2]] - pl) / scale).clip(0, ow)
    boxes_orig[:, [1, 3]] = ((boxes_xyxy[:, [1, 3]] - pt) / scale).clip(0, oh)

    proto_flat  = proto.reshape(-1, 32)
    mask_logits = (mask_coefs @ proto_flat.T).reshape(-1, 160, 160)
    masks_bin   = (1 / (1 + np.exp(-mask_logits))) > mask_thr

    px_scale    = 160 / input_size
    final_masks = []
    for i, m in enumerate(masks_bin):
        px1, py1 = int(boxes_xyxy[i, 0] * px_scale), int(boxes_xyxy[i, 1] * px_scale)
        px2, py2 = int(boxes_xyxy[i, 2] * px_scale), int(boxes_xyxy[i, 3] * px_scale)
        cropped  = m.astype(np.uint8)
        crop_m   = np.zeros_like(cropped)
        crop_m[py1:py2, px1:px2] = cropped[py1:py2, px1:px2]
        mask_full = cv2.resize(crop_m.astype(np.float32), (ow, oh), interpolation=cv2.INTER_LINEAR)
        final_masks.append((mask_full > 0.5).astype(np.uint8))

    return boxes_orig.tolist(), scores.tolist(), class_ids.tolist(), final_masks


# ─── Drawing ──────────────────────────────────────────────────────────────────

def draw(frame, boxes, scores, class_ids, masks, fps, backend):
    overlay = frame.copy()
    for box, score, cid, mask in zip(boxes, scores, class_ids, masks):
        color = COLORS[cid % len(COLORS)].tolist()
        overlay[mask == 1] = color
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(frame, contours, -1, color, 2)
        x1, y1, x2, y2 = map(int, box)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        label = f"{COCO_CLASSES[cid]} {score:.2f}"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(frame, (x1, y1 - th - 6), (x1 + tw + 2, y1), color, -1)
        cv2.putText(frame, label, (x1 + 1, y1 - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)

    frame = cv2.addWeighted(overlay, MASK_ALPHA, frame, 1 - MASK_ALPHA, 0)
    cv2.putText(frame, f"FPS: {fps:.1f}", (10, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Objects: {len(boxes)}", (10, 58),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Backend: {backend}", (10, 88),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2, cv2.LINE_AA)
    return frame


# ─── Main loop ────────────────────────────────────────────────────────────────

def run(model_path, cam_id=0, conf_thr=0.25, iou_thr=0.45,
        delegate_path=None, use_gst=True):

    interp, inp, det_out, proto_out, input_size, (in_sc, in_zp), in_dtype = \
        load_seg_model(model_path, delegate_path)

    det_sc,   det_zp   = det_out["quantization"]
    proto_sc, proto_zp = proto_out["quantization"]
    backend             = "NPU" if delegate_path else "CPU"

    cap = open_camera(cam_id, use_gst=use_gst)
    print(f"\n[Camera] opened (id={cam_id})  |  q/ESC quit  |  s save frame\n")

    fps_avg, alpha = 0.0, 0.1

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        t0 = time.perf_counter()
        tensor, pad_info = preprocess(frame, input_size, in_dtype, in_sc, in_zp)
        interp.set_tensor(inp["index"], tensor)
        interp.invoke()
        raw_det   = interp.get_tensor(det_out["index"])
        raw_proto = interp.get_tensor(proto_out["index"])
        boxes, scores, class_ids, masks = postprocess(
            raw_det, raw_proto, pad_info, frame.shape,
            det_sc, det_zp, proto_sc, proto_zp,
            conf_thr, iou_thr, input_size,
        )
        t1 = time.perf_counter()

        fps_inst = 1.0 / (t1 - t0)
        fps_avg  = fps_inst if fps_avg == 0 else alpha * fps_inst + (1 - alpha) * fps_avg
        frame    = draw(frame, boxes, scores, class_ids, masks, fps_avg, backend)
        cv2.imshow("YOLOv8n-Seg INT8", frame)

        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break
        if key == ord("s"):
            cv2.imwrite("capture_seg.jpg", frame)
            print("[Saved] capture_seg.jpg")

    cap.release()
    cv2.destroyAllWindows()


# ─── CLI entry-point ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="YOLOv8n-Seg — INT8 TFLite (CPU / NPU)")
    parser.add_argument("--model",    default=None,
                        help="Path to .tflite model (auto-download if omitted)")
    parser.add_argument("--cam",      type=int,   default=0)
    parser.add_argument("--conf",     type=float, default=0.25)
    parser.add_argument("--iou",      type=float, default=0.45)
    parser.add_argument("--npu",      action="store_true")
    parser.add_argument("--delegate", type=str,   default=None)
    parser.add_argument("--no-gst",   action="store_true")
    args = parser.parse_args()

    model_path = args.model or str(get_model_path("segment"))
    delegate   = args.delegate or (DEFAULT_NPU_DELEGATE if args.npu else None)
    run(model_path, args.cam, args.conf, args.iou, delegate, use_gst=not args.no_gst)


if __name__ == "__main__":
    main()
