"""
Model registry and on-demand downloader.
Downloads models from the GitHub Release ZIP archive.
"""

import hashlib
import io
import sys
import urllib.request
import zipfile
from pathlib import Path

# ── Where models are saved (inside the installed package) ─────────────────────
MODELS_DIR = Path(__file__).parent

# ── GitHub Release ZIP URL ────────────────────────────────────────────────────
# Repo    : https://github.com/adarshkv159/yolov8n_tflite
# Release : https://github.com/adarshkv159/yolov8n_tflite/releases/tag/v1.0.0
_ZIP_URL = "https://github.com/adarshkv159/yolov8n_tflite/archive/refs/tags/v1.0.0.zip"

# ── Model registry ────────────────────────────────────────────────────────────
# filename : exact filename inside the ZIP
REGISTRY: dict[str, dict] = {
    "detect": {
        "filename": "yolov8n_full_integer_quant.tflite",
        "md5":      None,
    },
    "pose": {
        "filename": "yolov8n-pose_full_integer_quant.tflite",
        "md5":      None,
    },
    "obb": {
        "filename": "yolov8n-obb_full_integer_quant.tflite",
        "md5":      None,
    },
    "segment": {
        "filename": "yolov8n-seg_full_integer_quant.tflite",
        "md5":      None,
    },
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _md5(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _progress_hook(block_num, block_size, total_size):
    downloaded = block_num * block_size
    if total_size > 0:
        pct = min(downloaded / total_size * 100, 100)
        bar = int(pct // 2)
        sys.stdout.write(
            f"\r  [{'#' * bar}{'.' * (50 - bar)}] {pct:5.1f}%  "
            f"({downloaded/1e6:.1f} / {total_size/1e6:.1f} MB)"
        )
        sys.stdout.flush()
        if downloaded >= total_size:
            print()
    else:
        sys.stdout.write(f"\r  Downloaded {downloaded/1e6:.1f} MB ...")
        sys.stdout.flush()


def _download_all_models():
    """Download the release ZIP and extract all .tflite files."""
    print(f"[Models] Downloading release archive ...")
    print(f"         from: {_ZIP_URL}")

    tmp_zip = MODELS_DIR / "_release.zip"
    try:
        urllib.request.urlretrieve(_ZIP_URL, tmp_zip, reporthook=_progress_hook)
    except Exception as exc:
        if tmp_zip.exists():
            tmp_zip.unlink()
        raise RuntimeError(
            f"Failed to download release ZIP.\n"
            f"  URL  : {_ZIP_URL}\n"
            f"  Error: {exc}"
        ) from exc

    print("[Models] Extracting .tflite files ...")
    with zipfile.ZipFile(tmp_zip) as zf:
        # List all files in zip for debugging
        all_files = zf.namelist()
        tflite_files = [f for f in all_files if f.endswith(".tflite")]

        if not tflite_files:
            tmp_zip.unlink()
            raise RuntimeError(
                f"No .tflite files found in the ZIP!\n"
                f"Files in ZIP: {all_files[:20]}"
            )

        for zpath in tflite_files:
            fname = Path(zpath).name
            dest  = MODELS_DIR / fname
            print(f"  Extracting: {fname}")
            data = zf.read(zpath)
            dest.write_bytes(data)

    tmp_zip.unlink()
    print("[Models] All models extracted successfully.")


def get_model_path(key: str) -> Path:
    """
    Return the local path to a model, downloading it first if needed.

    Args:
        key: one of 'detect', 'pose', 'obb', 'segment'

    Returns:
        pathlib.Path to the .tflite file
    """
    if key not in REGISTRY:
        raise KeyError(f"Unknown model key '{key}'. Choose from: {list(REGISTRY)}")

    entry    = REGISTRY[key]
    dest     = MODELS_DIR / entry["filename"]
    expected = entry["md5"]

    # Already present — optionally verify checksum
    if dest.exists():
        if expected and _md5(dest) != expected:
            print(f"[Models] Checksum mismatch for {dest.name}, re-downloading ...")
            dest.unlink()
        else:
            return dest

    # Download the full ZIP and extract all models at once
    _download_all_models()

    if not dest.exists():
        raise RuntimeError(
            f"Model file '{entry['filename']}' not found in the release ZIP.\n"
            f"Expected path: {dest}\n"
            f"Check that the filename matches exactly what is inside the ZIP."
        )

    if expected and _md5(dest) != expected:
        dest.unlink()
        raise RuntimeError(f"Checksum mismatch for {dest.name}.")

    print(f"[Models] Ready -> {dest}")
    return dest
