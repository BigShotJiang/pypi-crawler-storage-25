"""
YOLOv8n-Pose — INT8 TFLite inference.
CLI entry-point: pose
"""

import argparse
import time

import cv2
import numpy as np

from .models import get_model_path
from .utils import (
    DEFAULT_NPU_DELEGATE, load_interpreter, preprocess, dequantize, open_camera,
)

# COCO skeleton edges
EDGES = [
    (0, 1), (0, 2), (1, 3), (2, 4), (5, 6), (5, 7), (7, 9),
    (6, 8), (8, 10), (11, 12), (5, 11), (6, 12), (11, 13),
    (13, 15), (12, 14), (14, 16),
]


# ─── Post-processing ──────────────────────────────────────────────────────────

def postprocess(raw_out, pad_info, out_scale, out_zp,
                conf_thr, iou_thr, input_size=640):
    """
    raw_out : (1, 56, 8400) int8
              4 box + 1 conf + 51 (17 kpts × 3)
    Returns : boxes [l,t,w,h], scores, kpts list
    """
    out = dequantize(raw_out[0], out_scale, out_zp).T   # (8400, 56)

    boxes_xywh = out[:, 0:4] * input_size
    scores     = out[:, 4]
    kpts_raw   = out[:, 5:]

    kpts_x    = kpts_raw[:, 0::3] * input_size
    kpts_y    = kpts_raw[:, 1::3] * input_size
    kpts_conf = kpts_raw[:, 2::3]
    kpts      = np.stack((kpts_x, kpts_y, kpts_conf), axis=-1)   # (8400, 17, 3)

    mask       = scores >= conf_thr
    boxes_xywh = boxes_xywh[mask]
    scores     = scores[mask]
    kpts       = kpts[mask]

    if len(scores) == 0:
        return [], [], []

    boxes_ltwh = boxes_xywh.copy()
    boxes_ltwh[:, 0] -= boxes_xywh[:, 2] / 2
    boxes_ltwh[:, 1] -= boxes_xywh[:, 3] / 2

    indices = cv2.dnn.NMSBoxes(boxes_ltwh.tolist(), scores.tolist(), conf_thr, iou_thr)
    if len(indices) == 0:
        return [], [], []
    indices = indices.flatten()

    pl, pt, scale = pad_info
    final_boxes, final_kpts = [], []

    for i in indices:
        l, t, w, h = boxes_ltwh[i]
        final_boxes.append([
            int((l - pl) / scale),
            int((t - pt) / scale),
            int(w / scale),
            int(h / scale),
        ])
        orig_kpt = []
        for kx, ky, kc in kpts[i]:
            orig_kpt.append([int((kx - pl) / scale), int((ky - pt) / scale), float(kc)])
        final_kpts.append(orig_kpt)

    return final_boxes, scores[indices].tolist(), final_kpts


# ─── Drawing ──────────────────────────────────────────────────────────────────

def draw(frame, boxes, scores, kpts_list, fps, backend):
    for box, score, kpts in zip(boxes, scores, kpts_list):
        l, t, w, h = box
        cv2.rectangle(frame, (l, t), (l + w, t + h), (0, 255, 0), 2)
        label = f"Person {score:.2f}"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(frame, (l, t - th - 6), (l + tw + 2, t), (0, 255, 0), -1)
        cv2.putText(frame, label, (l + 1, t - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 0, 0), 1, cv2.LINE_AA)
        for kx, ky, kc in kpts:
            if kc > 0.5:
                cv2.circle(frame, (kx, ky), 4, (0, 0, 255), -1)
        for p1, p2 in EDGES:
            x1, y1, c1 = kpts[p1]
            x2, y2, c2 = kpts[p2]
            if c1 > 0.5 and c2 > 0.5:
                cv2.line(frame, (x1, y1), (x2, y2), (255, 100, 0), 2)

    cv2.putText(frame, f"FPS: {fps:.1f}", (10, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Persons: {len(boxes)}", (10, 58),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Backend: {backend}", (10, 88),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2, cv2.LINE_AA)
    return frame


# ─── Main loop ────────────────────────────────────────────────────────────────

def run(model_path, cam_id=0, conf_thr=0.45, iou_thr=0.45,
        delegate_path=None, use_gst=True):

    interp, inp, out_dets, input_size, (in_sc, in_zp), in_dtype = \
        load_interpreter(model_path, delegate_path)

    out          = out_dets[0]
    out_sc, out_zp = out["quantization"]
    backend      = "NPU" if delegate_path else "CPU"

    cap = open_camera(cam_id, use_gst=use_gst)
    print(f"\n[Camera] opened (id={cam_id})  |  q/ESC quit  |  s save frame\n")

    fps_avg, alpha = 0.0, 0.1

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        t0 = time.perf_counter()
        tensor, pad_info = preprocess(frame, input_size, in_dtype, in_sc, in_zp)
        interp.set_tensor(inp["index"], tensor)
        interp.invoke()
        raw_out = interp.get_tensor(out["index"])
        boxes, scores, kpts = postprocess(
            raw_out, pad_info, out_sc, out_zp, conf_thr, iou_thr, input_size,
        )
        t1 = time.perf_counter()

        fps_inst = 1.0 / (t1 - t0)
        fps_avg  = fps_inst if fps_avg == 0 else alpha * fps_inst + (1 - alpha) * fps_avg
        frame    = draw(frame, boxes, scores, kpts, fps_avg, backend)
        cv2.imshow("YOLOv8n-Pose INT8", frame)

        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break
        if key == ord("s"):
            cv2.imwrite("capture_pose.jpg", frame)
            print("[Saved] capture_pose.jpg")

    cap.release()
    cv2.destroyAllWindows()


# ─── CLI entry-point ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="YOLOv8n-Pose — INT8 TFLite (CPU / NPU)")
    parser.add_argument("--model",    default=None,
                        help="Path to .tflite model (auto-download if omitted)")
    parser.add_argument("--cam",      type=int,   default=0)
    parser.add_argument("--conf",     type=float, default=0.45)
    parser.add_argument("--iou",      type=float, default=0.45)
    parser.add_argument("--npu",      action="store_true")
    parser.add_argument("--delegate", type=str,   default=None)
    parser.add_argument("--no-gst",   action="store_true")
    args = parser.parse_args()

    model_path = args.model or str(get_model_path("pose"))
    delegate   = args.delegate or (DEFAULT_NPU_DELEGATE if args.npu else None)
    run(model_path, args.cam, args.conf, args.iou, delegate, use_gst=not args.no_gst)


if __name__ == "__main__":
    main()
