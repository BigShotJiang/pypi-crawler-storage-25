"""
Model registry and on-demand downloader.
Downloads models from the GitHub Release ZIP archive.
"""

import hashlib
import sys
import urllib.request
import zipfile
from pathlib import Path

# ── Where models are saved (inside the installed package) ─────────────────────
MODELS_DIR = Path(__file__).parent

# ── GitHub Release ZIP URL ────────────────────────────────────────────────────
_ZIP_URL = "https://github.com/adarshkv159/yolov8n_tflite/archive/refs/tags/v1.0.0.zip"

# ── Model registry ────────────────────────────────────────────────────────────
# filename : exact filename inside the ZIP (confirmed from extraction output)
REGISTRY: dict[str, dict] = {
    "detect": {
        "filename": "yolov8n_object_detection_full_integer_quant.tflite",  # fixed
        "md5":      None,
    },
    "pose": {
        "filename": "yolov8n-pose_full_integer_quant.tflite",
        "md5":      None,
    },
    "obb": {
        "filename": "yolov8n-obb_full_integer_quant.tflite",
        "md5":      None,
    },
    "segment": {
        "filename": "yolov8n-seg_full_integer_quant.tflite",
        "md5":      None,
    },
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _md5(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _progress_hook(block_num, block_size, total_size):
    downloaded = block_num * block_size
    if total_size > 0:
        pct = min(downloaded / total_size * 100, 100)
        bar = int(pct // 2)
        sys.stdout.write(
            f"\r  [{'#' * bar}{'.' * (50 - bar)}] {pct:5.1f}%  "
            f"({downloaded/1e6:.1f} / {total_size/1e6:.1f} MB)"
        )
        sys.stdout.flush()
        if downloaded >= total_size:
            print()
    else:
        sys.stdout.write(f"\r  Downloaded {downloaded/1e6:.1f} MB ...")
        sys.stdout.flush()


def _download_all_models():
    """Download the release ZIP and extract all .tflite files."""
    print(f"[Models] Downloading release archive ...")
    print(f"         from: {_ZIP_URL}")

    tmp_zip = MODELS_DIR / "_release.zip"
    try:
        urllib.request.urlretrieve(_ZIP_URL, tmp_zip, reporthook=_progress_hook)
    except Exception as exc:
        if tmp_zip.exists():
            tmp_zip.unlink()
        raise RuntimeError(
            f"Failed to download release ZIP.\n"
            f"  URL  : {_ZIP_URL}\n"
            f"  Error: {exc}"
        ) from exc

    print("[Models] Extracting .tflite files ...")
    with zipfile.ZipFile(tmp_zip) as zf:
        tflite_files = [f for f in zf.namelist() if f.endswith(".tflite")]
        for zpath in tflite_files:
            fname = Path(zpath).name
            dest  = MODELS_DIR / fname
            print(f"  Extracting: {fname}")
            dest.write_bytes(zf.read(zpath))

    tmp_zip.unlink()
    print("[Models] All models extracted successfully.")


def get_model_path(key: str) -> Path:
    """
    Return the local path to a model, downloading it first if needed.

    Args:
        key: one of 'detect', 'pose', 'obb', 'segment'

    Returns:
        pathlib.Path to the .tflite file
    """
    if key not in REGISTRY:
        raise KeyError(f"Unknown model key '{key}'. Choose from: {list(REGISTRY)}")

    entry    = REGISTRY[key]
    dest     = MODELS_DIR / entry["filename"]
    expected = entry["md5"]

    # Already present — optionally verify checksum
    if dest.exists():
        if expected and _md5(dest) != expected:
            print(f"[Models] Checksum mismatch for {dest.name}, re-downloading ...")
            dest.unlink()
        else:
            return dest

    # Download ZIP and extract all models
    _download_all_models()

    if not dest.exists():
        raise RuntimeError(
            f"Model '{entry['filename']}' not found in ZIP.\n"
            f"Expected: {dest}"
        )

    print(f"[Models] Ready -> {dest}")
    return dest
