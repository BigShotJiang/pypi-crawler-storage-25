"""
YOLOv8n-OBB Oriented Bounding Box — INT8 TFLite inference.
CLI entry-point: obb
"""

import argparse
import math
import time

import cv2
import numpy as np

from .models import get_model_path
from .utils import (
    DEFAULT_NPU_DELEGATE, load_interpreter, preprocess, dequantize, open_camera,
)

OBB_CLASSES = [
    "plane", "ship", "storage tank", "baseball diamond", "tennis court",
    "basketball court", "ground track field", "harbor", "bridge",
    "large vehicle", "small vehicle", "helicopter", "roundabout",
    "soccer ball field", "swimming pool",
]

np.random.seed(42)
COLORS = np.random.randint(0, 255, size=(len(OBB_CLASSES), 3), dtype=np.uint8)


# ─── Post-processing ──────────────────────────────────────────────────────────

def postprocess(raw_out, pad_info, orig_shape, out_scale, out_zp,
                conf_thr, iou_thr, input_size=640):
    """
    raw_out : (1, 20, 8400) int8  →  4 box + 15 classes + 1 angle
    Returns : rotated_boxes, scores, class_ids
    """
    out = dequantize(raw_out[0], out_scale, out_zp)   # (20, 8400)

    boxes_xywh   = out[0:4,  :].T * input_size        # (8400, 4)
    class_scores = out[4:-1, :].T                     # (8400, 15)
    angles_rad   = out[-1,   :]                       # (8400,)

    scores    = class_scores.max(axis=1)
    class_ids = class_scores.argmax(axis=1)

    mask = scores >= conf_thr
    boxes_xywh = boxes_xywh[mask]
    scores     = scores[mask]
    class_ids  = class_ids[mask]
    angles_rad = angles_rad[mask]

    if len(scores) == 0:
        return [], [], []

    pl, pt, scale = pad_info
    rotated_boxes = []
    for i in range(len(boxes_xywh)):
        cx, cy, w, h = boxes_xywh[i]
        rotated_boxes.append((
            ((cx - pl) / scale, (cy - pt) / scale),
            (w / scale,         h / scale),
            math.degrees(angles_rad[i]),
        ))

    keep = []
    for cid in np.unique(class_ids):
        m   = class_ids == cid
        idx = np.where(m)[0]
        nms = cv2.dnn.NMSBoxesRotated(
            [rotated_boxes[i] for i in idx],
            scores[m].tolist(), conf_thr, iou_thr,
        )
        if len(nms) > 0:
            keep.extend(idx[nms.flatten()])

    return [rotated_boxes[i] for i in keep], scores[keep].tolist(), class_ids[keep].tolist()


# ─── Drawing ──────────────────────────────────────────────────────────────────

def draw(frame, boxes, scores, class_ids, fps, backend):
    for box, score, cid in zip(boxes, scores, class_ids):
        corners = np.int32(cv2.boxPoints(box))
        color   = COLORS[cid % len(COLORS)].tolist()
        label   = f"{OBB_CLASSES[cid] if cid < len(OBB_CLASSES) else cid} {score:.2f}"
        cv2.drawContours(frame, [corners], 0, color, 2)
        top = corners[np.argmin(corners[:, 1])]
        tx, ty = top
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(frame, (tx, ty - th - 6), (tx + tw + 2, ty), color, -1)
        cv2.putText(frame, label, (tx + 1, ty - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)

    cv2.putText(frame, f"FPS: {fps:.1f}", (10, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Objects: {len(boxes)}", (10, 58),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Backend: {backend}", (10, 88),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2, cv2.LINE_AA)
    return frame


# ─── Main loop ────────────────────────────────────────────────────────────────

def run(model_path, cam_id=0, conf_thr=0.45, iou_thr=0.45,
        delegate_path=None, use_gst=True):

    interp, inp, out_dets, input_size, (in_sc, in_zp), in_dtype = \
        load_interpreter(model_path, delegate_path)

    out          = out_dets[0]
    out_sc, out_zp = out["quantization"]
    backend      = "NPU" if delegate_path else "CPU"

    cap = open_camera(cam_id, use_gst=use_gst)
    print(f"\n[Camera] opened (id={cam_id})  |  q/ESC quit  |  s save frame\n")

    fps_avg, alpha = 0.0, 0.1

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        t0 = time.perf_counter()
        tensor, pad_info = preprocess(frame, input_size, in_dtype, in_sc, in_zp)
        interp.set_tensor(inp["index"], tensor)
        interp.invoke()
        raw_out = interp.get_tensor(out["index"])
        boxes, scores, class_ids = postprocess(
            raw_out, pad_info, frame.shape, out_sc, out_zp,
            conf_thr, iou_thr, input_size,
        )
        t1 = time.perf_counter()

        fps_inst = 1.0 / (t1 - t0)
        fps_avg  = fps_inst if fps_avg == 0 else alpha * fps_inst + (1 - alpha) * fps_avg
        frame    = draw(frame, boxes, scores, class_ids, fps_avg, backend)
        cv2.imshow("YOLOv8n-OBB INT8", frame)

        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break
        if key == ord("s"):
            cv2.imwrite("capture_obb.jpg", frame)
            print("[Saved] capture_obb.jpg")

    cap.release()
    cv2.destroyAllWindows()


# ─── CLI entry-point ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="YOLOv8n-OBB — INT8 TFLite (CPU / NPU)")
    parser.add_argument("--model",    default=None,
                        help="Path to .tflite model (auto-download if omitted)")
    parser.add_argument("--cam",      type=int,   default=0)
    parser.add_argument("--conf",     type=float, default=0.45)
    parser.add_argument("--iou",      type=float, default=0.45)
    parser.add_argument("--npu",      action="store_true")
    parser.add_argument("--delegate", type=str,   default=None)
    parser.add_argument("--no-gst",   action="store_true")
    args = parser.parse_args()

    model_path = args.model or str(get_model_path("obb"))
    delegate   = args.delegate or (DEFAULT_NPU_DELEGATE if args.npu else None)
    run(model_path, args.cam, args.conf, args.iou, delegate, use_gst=not args.no_gst)


if __name__ == "__main__":
    main()
