"""
CLI entry-point: download-models

Pre-downloads all YOLOv8 TFLite models to the package's models/ directory.
Run this once after installing the package:

    download-models
"""

from .models import REGISTRY, get_model_path


def main():
    print("=" * 60)
    print("  YOLOv8 TFLite Model Downloader")
    print("=" * 60)
    print()

    failed = []
    for key in REGISTRY:
        print(f"── {key} ──────────────────────────────────────")
        try:
            path = get_model_path(key)
            size_mb = path.stat().st_size / 1e6
            print(f"   ✓ {path.name}  ({size_mb:.1f} MB)")
        except Exception as exc:
            print(f"   ✗ FAILED: {exc}")
            failed.append(key)
        print()

    print("=" * 60)
    if failed:
        print(f"  ✗ {len(failed)} model(s) failed: {failed}")
        print("  Pass --model /path/to/model.tflite to use local files.")
    else:
        print(f"  ✓ All {len(REGISTRY)} models downloaded successfully.")
    print("=" * 60)


if __name__ == "__main__":
    main()
