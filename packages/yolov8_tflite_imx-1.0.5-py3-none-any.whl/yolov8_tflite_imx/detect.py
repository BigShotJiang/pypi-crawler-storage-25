"""
YOLOv8n Object Detection — INT8 TFLite inference.
CLI entry-point: detect
"""

import argparse
import time
import math

import cv2
import numpy as np

from .utils import (
    DEFAULT_NPU_DELEGATE, load_interpreter, preprocess, dequantize, open_camera,
)
from .models import get_model_path

# ─── COCO 80 classes ──────────────────────────────────────────────────────────

COCO_CLASSES = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra",
    "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
    "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup",
    "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
    "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse",
    "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
    "refrigerator", "book", "clock", "vase", "scissors", "teddy bear",
    "hair drier", "toothbrush",
]

np.random.seed(42)
COLORS = np.random.randint(0, 255, size=(len(COCO_CLASSES), 3), dtype=np.uint8)


# ─── Post-processing ──────────────────────────────────────────────────────────

def postprocess(raw_out, pad_info, orig_shape, out_scale, out_zp,
                conf_thr, iou_thr, input_size=640):
    """
    raw_out : (1, 84, 8400) int8
    Returns : boxes (xyxy in orig coords), scores, class_ids
    """
    out = dequantize(raw_out[0], out_scale, out_zp)    # (84, 8400)

    boxes_xywh   = out[:4, :].T * input_size           # (8400, 4)
    class_scores = out[4:, :].T                        # (8400, 80)

    scores    = class_scores.max(axis=1)
    class_ids = class_scores.argmax(axis=1)

    mask = scores >= conf_thr
    boxes_xywh = boxes_xywh[mask]
    scores     = scores[mask]
    class_ids  = class_ids[mask]

    if len(scores) == 0:
        return [], [], []

    x1 = boxes_xywh[:, 0] - boxes_xywh[:, 2] / 2
    y1 = boxes_xywh[:, 1] - boxes_xywh[:, 3] / 2
    x2 = boxes_xywh[:, 0] + boxes_xywh[:, 2] / 2
    y2 = boxes_xywh[:, 1] + boxes_xywh[:, 3] / 2

    pl, pt, scale = pad_info
    oh, ow = orig_shape[:2]
    x1 = ((x1 - pl) / scale).clip(0, ow)
    y1 = ((y1 - pt) / scale).clip(0, oh)
    x2 = ((x2 - pl) / scale).clip(0, ow)
    y2 = ((y2 - pt) / scale).clip(0, oh)

    boxes_xyxy = np.stack([x1, y1, x2, y2], axis=1)

    keep = []
    for cid in np.unique(class_ids):
        m   = class_ids == cid
        idx = np.where(m)[0]
        b, s = boxes_xyxy[m], scores[m]
        xywh = [[bx[0], bx[1], bx[2] - bx[0], bx[3] - bx[1]] for bx in b]
        nms  = cv2.dnn.NMSBoxes(xywh, s.tolist(), conf_thr, iou_thr)
        if len(nms) > 0:
            keep.extend(idx[nms.flatten()])

    return boxes_xyxy[keep].tolist(), scores[keep].tolist(), class_ids[keep].tolist()


# ─── Drawing ──────────────────────────────────────────────────────────────────

def draw(frame, boxes, scores, class_ids, fps, backend):
    for box, score, cid in zip(boxes, scores, class_ids):
        x1, y1, x2, y2 = map(int, box)
        color = COLORS[cid % len(COLORS)].tolist()
        label = f"{COCO_CLASSES[cid]} {score:.2f}"
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.55, 1)
        cv2.rectangle(frame, (x1, y1 - th - 6), (x1 + tw + 2, y1), color, -1)
        cv2.putText(frame, label, (x1 + 1, y1 - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1, cv2.LINE_AA)

    cv2.putText(frame, f"FPS: {fps:.1f}", (10, 28),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Objects: {len(boxes)}", (10, 58),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)
    cv2.putText(frame, f"Backend: {backend}", (10, 88),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2, cv2.LINE_AA)
    return frame


# ─── Main loop ────────────────────────────────────────────────────────────────

def run(model_path, cam_id=0, conf_thr=0.25, iou_thr=0.45,
        delegate_path=None, use_gst=True):

    interp, inp, out_dets, input_size, (in_sc, in_zp), in_dtype = \
        load_interpreter(model_path, delegate_path)

    out      = out_dets[0]
    out_sc, out_zp = out["quantization"]
    backend  = "NPU" if delegate_path else "CPU"

    cap = open_camera(cam_id, use_gst=use_gst)
    print(f"\n[Camera] opened (id={cam_id})  |  q/ESC quit  |  s save frame\n")

    fps_avg, alpha = 0.0, 0.1

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        t0 = time.perf_counter()
        tensor, pad_info = preprocess(frame, input_size, in_dtype, in_sc, in_zp)
        interp.set_tensor(inp["index"], tensor)
        interp.invoke()
        raw_out = interp.get_tensor(out["index"])
        boxes, scores, class_ids = postprocess(
            raw_out, pad_info, frame.shape, out_sc, out_zp,
            conf_thr, iou_thr, input_size,
        )
        t1 = time.perf_counter()

        fps_inst = 1.0 / (t1 - t0)
        fps_avg  = fps_inst if fps_avg == 0 else alpha * fps_inst + (1 - alpha) * fps_avg
        frame    = draw(frame, boxes, scores, class_ids, fps_avg, backend)
        cv2.imshow("YOLOv8n Detection INT8", frame)

        key = cv2.waitKey(1) & 0xFF
        if key in (ord("q"), 27):
            break
        if key == ord("s"):
            cv2.imwrite("capture_detect.jpg", frame)
            print("[Saved] capture_detect.jpg")

    cap.release()
    cv2.destroyAllWindows()


# ─── CLI entry-point ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="YOLOv8n Detection — INT8 TFLite (CPU / NPU)",
    )
    parser.add_argument("--model",    default=None,
                        help="Path to .tflite model (auto-download if omitted)")
    parser.add_argument("--cam",      type=int,   default=0)
    parser.add_argument("--conf",     type=float, default=0.25)
    parser.add_argument("--iou",      type=float, default=0.45)
    parser.add_argument("--npu",      action="store_true",
                        help=f"Enable NPU via {DEFAULT_NPU_DELEGATE}")
    parser.add_argument("--delegate", type=str,   default=None,
                        help="Custom delegate .so path (overrides --npu)")
    parser.add_argument("--no-gst",   action="store_true",
                        help="Disable GStreamer, use V4L2 directly")
    args = parser.parse_args()

    model_path = args.model or str(get_model_path("detect"))
    delegate   = args.delegate or (DEFAULT_NPU_DELEGATE if args.npu else None)
    run(model_path, args.cam, args.conf, args.iou, delegate, use_gst=not args.no_gst)


if __name__ == "__main__":
    main()
