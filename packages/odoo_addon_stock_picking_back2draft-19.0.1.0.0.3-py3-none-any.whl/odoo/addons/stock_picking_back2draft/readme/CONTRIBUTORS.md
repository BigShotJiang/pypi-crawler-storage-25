- Lorenzo Battistini \<<lorenzo.battistini@agilebg.com>\>
- Iván Montagud \<<ivan@studio73.es>\>
- Pimolnat Suntian \<<pimolnats@ecosoft.co.th>\>
- David Montull Guasch \<<david.montull@bt-group.com>\>
- Marwan Behillil \<<marwan@riluxa.com>\>
- [Heliconia Solutions Pvt. Ltd.](https://www.heliconia.io)
  - Bhavesh Heliconia

