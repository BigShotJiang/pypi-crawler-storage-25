# © 2016 Lorenzo Battistini - Agile Business Group
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from odoo import models
from odoo.exceptions import UserError


class StockMove(models.Model):
    _inherit = "stock.move"

    def action_back_to_draft(self):
        if self.filtered(lambda m: m.state != "cancel"):
            raise UserError(self.env._("You can set back to draft only canceled moves"))
        self.write({"state": "draft"})
