import csv
import io

from xlcompress._native import compress, compress_grid, list_sheets, SheetResult


def compress_to_string(source, **kwargs):
    """Compress and return all sheets as a single string for LLM prompts."""
    results = compress(source, **kwargs)
    parts = []
    for r in results:
        parts.append(f"--- Sheet: {r.name} ---\n\n{r.compressed}")
    return "\n\n".join(parts)


def compress_csv(source, *, name="Sheet1", delimiter=",", **kwargs):
    """Compress CSV data.

    Args:
        source: file path (str), string content, or file-like object
        name: sheet name for the result
        delimiter: CSV delimiter character
        **kwargs: passed to compress_grid (mode, structural, structural_k)
    """
    if isinstance(source, str) and ("\n" in source or "\r" in source):
        text = source
    elif isinstance(source, str):
        with open(source, "r") as f:
            text = f.read()
    elif hasattr(source, "read"):
        text = source.read()
    else:
        raise TypeError("source must be a file path, CSV string, or file-like object")

    reader = csv.reader(io.StringIO(text), delimiter=delimiter)
    grid = [row for row in reader if any(cell.strip() for cell in row)]
    if not grid:
        raise ValueError("Empty CSV data")

    return compress_grid(grid, name=name, **kwargs)


def compress_text(text, *, name="Sheet1", delimiter="\t", **kwargs):
    """Compress tab-delimited or other delimited text.

    Args:
        text: string of delimited text (e.g. pasted from a spreadsheet)
        name: sheet name for the result
        delimiter: column delimiter (default: tab)
        **kwargs: passed to compress_grid (mode, structural, structural_k)
    """
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    return compress_csv(text, name=name, delimiter=delimiter, **kwargs)


__all__ = [
    "compress",
    "compress_to_string",
    "compress_csv",
    "compress_text",
    "compress_grid",
    "list_sheets",
    "SheetResult",
]
