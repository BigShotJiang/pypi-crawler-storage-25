"""
Jupyter 노트북 조작을 위한 LangChain 호환 도구 모음.

NotebookContextManager를 래핑하여 LangChain Agent에서 사용 가능한
LangChain BaseTool 인터페이스를 제공합니다.
"""

from __future__ import annotations

import ast
import json
import re
import subprocess
from pathlib import Path
from typing import Any, Optional

from langchain_core.tools import BaseTool, tool

from ..tools.context import NotebookContextManager

# enterprise_tables 접근 제한 키워드 (모듈 레벨 1회 컴파일)
_ENTERPRISE_KEYWORDS = re.compile(
    r"전사|처리계|정보계|채널계|엔터프라이즈|enterprise|레거시|idc"
    r"|adw|bcv|cms|dpweb|m포인트몰|빅쿼리|bq|bigquery"
    r"|원천|dw|메타샵|meta샵|meta#",
    re.IGNORECASE,
)

# 사용자 원본 메시지 (enterprise 키워드 체크용 — stream_response에서 설정)
_last_user_message: str = ""


def set_last_user_message(msg: str) -> None:
    """사용자 원본 메시지 저장 (rag_chat_agent에서 호출)."""
    global _last_user_message
    _last_user_message = msg


def create_jupyter_cell_tool(context: NotebookContextManager) -> BaseTool:
    """
    Jupyter 셀 조작용 LangChain 도구를 생성합니다.

    Args:
        context: 노트북 상태 접근을 위한 NotebookContextManager

    Returns:
        셀 조작용 LangChain BaseTool
    """

    @tool
    def jupyter_cell(
        code: Optional[str] = None,
        description: Optional[str] = None,
        execution_result: Optional[dict] = None,
    ) -> str:
        """Jupyter 노트북에 코드 셀을 생성하고 실행합니다.

        Args:
            code: 실행할 Python 코드
            description: 코드 설명 (선택)
            execution_result: 프론트엔드에서 전달된 실행 결과 (HITL edit decision 경유)

        Returns:
            연산 결과가 담긴 JSON 문자열
        """
        # 마크다운 펜스 정리
        cleaned_code = (code or "").strip()
        if cleaned_code.startswith("```python"):
            cleaned_code = cleaned_code[9:]
        elif cleaned_code.startswith("```"):
            cleaned_code = cleaned_code[3:]
        if cleaned_code.endswith("```"):
            cleaned_code = cleaned_code[:-3]
        cleaned_code = cleaned_code.strip()

        response = {
            "tool": "jupyter_cell",
            "parameters": {"code": cleaned_code, "description": description},
            "status": "pending_execution",
            "message": "Code cell queued for execution",
        }
        if execution_result is not None:
            response["execution_result"] = execution_result
            response["status"] = "complete"
            response["message"] = "Code cell executed with client-reported results"
        return json.dumps(response)

    return jupyter_cell


def create_jupyter_markdown_tool(context: NotebookContextManager) -> BaseTool:
    """
    Jupyter 마크다운 셀 조작용 LangChain 도구를 생성합니다.

    Args:
        context: 노트북 상태 접근을 위한 NotebookContextManager

    Returns:
        마크다운 조작용 LangChain BaseTool
    """

    @tool
    def jupyter_markdown(
        operation: str,
        content: str,
        cell_index: Optional[int] = None,
        insert_after: Optional[int] = None,
    ) -> str:
        """
        Jupyter 노트북에서 마크다운 셀을 생성하거나 수정합니다.

        문서화, 설명, 헤더 추가에 사용합니다.

        Args:
            operation: 수행할 연산 (CREATE 또는 UPDATE)
            content: 마크다운 내용
            cell_index: 셀 인덱스 (UPDATE용)
            insert_after: 이 인덱스 뒤에 새 셀 삽입 (CREATE용)

        Returns:
            연산 결과가 담긴 JSON 문자열
        """
        # HITL 모드: 실제 마크다운 셀 추가는 프론트엔드에서 처리됨.
        return json.dumps(
            {
                "success": True,
                "message": "마크다운 셀이 노트북에 추가되었습니다.",
            }
        )

    return jupyter_markdown


def create_notebook_info_tool(context: NotebookContextManager) -> BaseTool:
    """
    노트북 정보 조회용 LangChain 도구를 생성합니다.

    Args:
        context: 노트북 상태 접근을 위한 NotebookContextManager

    Returns:
        노트북 정보 조회용 LangChain BaseTool
    """

    @tool
    def notebook_info() -> str:
        """
        현재 Jupyter 노트북의 정보를 가져옵니다.

        경로, 셀 개수, 커널 정보를 포함한 요약을 반환합니다.

        Returns:
            노트북 요약이 담긴 JSON 문자열
        """
        # NotebookContextManager가 설정되어 있으면 요약 반환, 아니면 기본값
        if context.current_notebook:
            try:
                summary = context.get_summary()
                return json.dumps({"success": True, "data": summary})
            except Exception as e:
                return json.dumps({"success": False, "error": str(e)})
        return json.dumps(
            {
                "success": True,
                "data": {
                    "path": "unknown",
                    "cell_count": 0,
                    "kernel_name": "python3",
                },
            }
        )

    return notebook_info


# =============================================================================
# 파일 도구
# =============================================================================


def create_file_read_tool(workspace_root: str) -> BaseTool:
    """
    파일 내용 읽기용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 파일 작업의 루트 디렉토리

    Returns:
        파일 읽기용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def file_read(path: str, encoding: str = "utf-8") -> str:
        """
        파일 내용을 읽습니다.

        파일 내용을 텍스트로 반환합니다. 바이너리 파일은 오류를 반환합니다.

        Args:
            path: 읽을 파일 경로 (워크스페이스 기준 상대 경로)
            encoding: 파일 인코딩 (기본값: utf-8)

        Returns:
            파일 내용 또는 오류가 담긴 JSON 문자열
        """
        if not path:
            return json.dumps({"success": False, "error": "경로가 필요합니다"})

        try:
            file_path = base_path / path
            if not file_path.exists():
                return json.dumps(
                    {"success": False, "error": f"파일을 찾을 수 없음: {path}"}
                )

            if not file_path.is_file():
                return json.dumps({"success": False, "error": f"파일이 아님: {path}"})

            content = file_path.read_text(encoding=encoding)
            return json.dumps(
                {
                    "success": True,
                    "data": {"content": content, "path": str(path)},
                    "metadata": {"size": len(content), "encoding": encoding},
                }
            )

        except UnicodeDecodeError:
            return json.dumps(
                {"success": False, "error": f"텍스트로 읽을 수 없는 파일: {path}"}
            )
        except Exception as e:
            return json.dumps({"success": False, "error": f"파일 읽기 오류: {e}"})

    return file_read


def create_file_write_tool(workspace_root: str) -> BaseTool:
    """
    파일 내용 쓰기용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 파일 작업의 루트 디렉토리

    Returns:
        파일 쓰기용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def file_write(path: str, content: str, append: bool = False) -> str:
        """
        파일에 내용을 씁니다.

        파일이 없으면 생성합니다. 필요시 상위 디렉토리도 생성합니다.
        Python 파일(.py)은 자동으로 ruff check --fix와 ruff format을 실행합니다.

        경고: 이 도구는 파일을 수정할 수 있습니다. HITL 승인이 필요합니다.

        Args:
            path: 쓸 파일 경로 (워크스페이스 기준 상대 경로)
            content: 쓸 내용
            append: 덮어쓰기 대신 추가 (기본값: False)

        Returns:
            연산 결과가 담긴 JSON 문자열
        """
        if not path:
            return json.dumps({"success": False, "error": "경로가 필요합니다"})

        try:
            file_path = base_path / path

            # 필요시 상위 디렉토리 생성
            file_path.parent.mkdir(parents=True, exist_ok=True)

            mode = "a" if append else "w"
            with open(file_path, mode, encoding="utf-8") as f:
                f.write(content)

            result = {
                "success": True,
                "data": {
                    "path": str(path),
                    "operation": "append" if append else "write",
                },
                "metadata": {"size": len(content)},
            }

            # Python 파일은 자동으로 ruff 실행
            if path.endswith(".py"):
                try:
                    ruff_fix = subprocess.run(
                        ["ruff", "check", "--fix", str(file_path)],
                        capture_output=True,
                        timeout=30,
                    )
                    ruff_fmt = subprocess.run(
                        ["ruff", "format", str(file_path)],
                        capture_output=True,
                        timeout=30,
                    )
                    result["metadata"]["ruff_applied"] = True
                    result["metadata"]["ruff_fix_returncode"] = ruff_fix.returncode
                    result["metadata"]["ruff_format_returncode"] = ruff_fmt.returncode
                except FileNotFoundError:
                    result["metadata"]["ruff_applied"] = False
                    result["metadata"]["ruff_note"] = "ruff가 설치되지 않음"
                except subprocess.TimeoutExpired:
                    result["metadata"]["ruff_applied"] = False
                    result["metadata"]["ruff_note"] = "ruff 시간 초과"

            return json.dumps(result)

        except Exception as e:
            return json.dumps({"success": False, "error": f"파일 쓰기 오류: {e}"})

    return file_write


def create_file_list_tool(workspace_root: str) -> BaseTool:
    """
    디렉토리 목록 조회용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 파일 작업의 루트 디렉토리

    Returns:
        디렉토리 목록 조회용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def file_list(
        path: str = ".", recursive: bool = False, pattern: Optional[str] = None
    ) -> str:
        """
        경로의 파일과 디렉토리를 나열합니다.

        파일/디렉토리 이름과 타입 목록을 반환합니다.

        Args:
            path: 나열할 디렉토리 경로 (워크스페이스 기준 상대 경로, 기본값: ".")
            recursive: 재귀적으로 나열 (기본값: False)
            pattern: 파일 필터링용 글롭 패턴 (예: '*.py')

        Returns:
            항목 목록이 담긴 JSON 문자열
        """
        try:
            dir_path = base_path / path
            if not dir_path.exists():
                return json.dumps(
                    {"success": False, "error": f"경로를 찾을 수 없음: {path}"}
                )

            if not dir_path.is_dir():
                return json.dumps(
                    {"success": False, "error": f"디렉토리가 아님: {path}"}
                )

            entries = []

            if pattern:
                files = dir_path.rglob(pattern) if recursive else dir_path.glob(pattern)
            else:
                files = dir_path.rglob("*") if recursive else dir_path.iterdir()

            for entry in files:
                try:
                    rel_path = entry.relative_to(base_path)
                    entries.append(
                        {
                            "name": entry.name,
                            "path": str(rel_path),
                            "type": "directory" if entry.is_dir() else "file",
                            "size": entry.stat().st_size if entry.is_file() else None,
                        }
                    )
                except ValueError:
                    # base_path 외부 항목은 건너뜀
                    pass

            return json.dumps(
                {
                    "success": True,
                    "data": {"entries": entries, "path": str(path)},
                    "metadata": {"count": len(entries)},
                }
            )

        except Exception as e:
            return json.dumps(
                {"success": False, "error": f"디렉토리 목록 조회 오류: {e}"}
            )

    return file_list


# =============================================================================
# 검색 도구
# =============================================================================


def create_search_code_tool(workspace_root: str) -> BaseTool:
    """
    코드 검색용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 검색 작업의 루트 디렉토리

    Returns:
        코드 검색용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def search_code(
        pattern: str,
        path: str = ".",
        file_pattern: str = "*",
        max_results: int = 50,
        case_sensitive: bool = True,
    ) -> str:
        """
        코드 파일에서 패턴을 검색합니다.

        정규식 패턴을 사용하여 파일들에서 일치 항목을 찾습니다.
        파일 경로와 줄 번호가 포함된 일치하는 줄을 반환합니다.

        Args:
            pattern: 검색할 정규식 패턴
            path: 검색할 디렉토리 (워크스페이스 기준 상대 경로, 기본값: ".")
            file_pattern: 검색할 파일의 글롭 패턴 (예: '*.py')
            max_results: 반환할 최대 결과 수 (기본값: 50)
            case_sensitive: 대소문자 구분 검색 (기본값: True)

        Returns:
            일치하는 줄이 담긴 JSON 문자열
        """
        if not pattern:
            return json.dumps({"success": False, "error": "패턴이 필요합니다"})

        try:
            flags = 0 if case_sensitive else re.IGNORECASE
            regex = re.compile(pattern, flags)
        except re.error as e:
            return json.dumps({"success": False, "error": f"잘못된 정규식 패턴: {e}"})

        search_path = base_path / path
        if not search_path.exists():
            return json.dumps(
                {"success": False, "error": f"경로를 찾을 수 없음: {path}"}
            )

        results = []
        try:
            for file_path in search_path.rglob(file_pattern):
                if not file_path.is_file():
                    continue

                # 숨김 디렉토리와 일반적인 비코드 디렉토리 건너뛰기
                if any(
                    part.startswith(".")
                    or part in ("node_modules", "__pycache__", "venv", ".venv")
                    for part in file_path.parts
                ):
                    continue

                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    for line_num, line in enumerate(content.splitlines(), 1):
                        if regex.search(line):
                            rel_path = file_path.relative_to(base_path)
                            results.append(
                                {
                                    "file": str(rel_path),
                                    "line": line_num,
                                    "content": line.strip()[:200],  # 긴 줄은 잘라냄
                                }
                            )

                            if len(results) >= max_results:
                                break
                except Exception:
                    # 읽을 수 없는 파일은 건너뜀
                    continue

                if len(results) >= max_results:
                    break

            return json.dumps(
                {
                    "success": True,
                    "data": {"matches": results, "pattern": pattern},
                    "metadata": {
                        "count": len(results),
                        "truncated": len(results) >= max_results,
                    },
                }
            )

        except Exception as e:
            return json.dumps({"success": False, "error": f"검색 오류: {e}"})

    return search_code


# =============================================================================
# LSP 도구 (Grep 기반 대체 구현)
# =============================================================================


def create_diagnostics_tool(workspace_root: str) -> BaseTool:
    """
    코드 진단용 LangChain 도구를 생성합니다.

    정적 분석 도구(ruff, mypy)가 있으면 사용하고,
    없으면 기본 패턴 기반 진단을 제공하는 Python 기반 구현입니다.

    Args:
        workspace_root: 분석의 루트 디렉토리

    Returns:
        진단용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def diagnostics(
        path: Optional[str] = None, severity_filter: Optional[str] = None
    ) -> str:
        """
        파일 또는 전체 프로젝트의 코드 진단(오류, 경고)을 가져옵니다.

        Python 파일의 문제를 탐지하기 위해 ruff를 실행합니다.
        ruff가 없으면 기본 패턴 기반 검사로 대체합니다.

        이 도구의 용도:
        - 코드 실행 전 문법 오류 확인
        - Python 파일의 타입 오류 및 린트 문제 찾기
        - 사용하지 않는 import나 변수 식별

        Args:
            path: 선택적 파일 경로. 미지정시 프로젝트 루트 검사.
            severity_filter: 선택적 필터 ('error', 'warning')

        Returns:
            진단 결과가 담긴 JSON 문자열
        """
        target = base_path / path if path else base_path
        results = []

        try:
            # Python 진단을 위해 ruff 실행 시도
            if target.is_file() and target.suffix == ".py":
                ruff_target = str(target)
            elif target.is_dir():
                ruff_target = str(target)
            else:
                return json.dumps(
                    {
                        "success": True,
                        "data": {
                            "diagnostics": [],
                            "message": "분석할 Python 파일 없음",
                        },
                    }
                )

            try:
                ruff_result = subprocess.run(
                    ["ruff", "check", "--output-format=json", ruff_target],
                    capture_output=True,
                    timeout=60,
                    cwd=str(base_path),
                )

                if ruff_result.stdout:
                    ruff_diagnostics = json.loads(ruff_result.stdout.decode("utf-8"))
                    for diag in ruff_diagnostics:
                        severity = (
                            "error"
                            if diag.get("code", "").startswith("E")
                            else "warning"
                        )
                        if severity_filter and severity != severity_filter:
                            continue

                        results.append(
                            {
                                "file": diag.get("filename", ""),
                                "line": diag.get("location", {}).get("row", 0),
                                "character": diag.get("location", {}).get("column", 0),
                                "severity": severity,
                                "code": diag.get("code", ""),
                                "message": diag.get("message", ""),
                                "source": "ruff",
                            }
                        )

            except FileNotFoundError:
                # Ruff 미설치 - 기본 피드백 제공
                return json.dumps(
                    {
                        "success": True,
                        "data": {
                            "diagnostics": [],
                            "message": "ruff가 설치되지 않음. 설치: pip install ruff",
                        },
                        "metadata": {"tool_available": False},
                    }
                )
            except subprocess.TimeoutExpired:
                return json.dumps({"success": False, "error": "진단 검사 시간 초과"})

            # 심각도순 정렬 (오류 우선)
            results.sort(
                key=lambda x: (
                    0 if x["severity"] == "error" else 1,
                    x["file"],
                    x["line"],
                )
            )

            # 개수 계산
            errors = sum(1 for r in results if r["severity"] == "error")
            warnings = sum(1 for r in results if r["severity"] == "warning")

            return json.dumps(
                {
                    "success": True,
                    "data": {
                        "diagnostics": results[:50],  # 50개로 제한
                        "summary": {
                            "errors": errors,
                            "warnings": warnings,
                            "total": len(results),
                        },
                    },
                    "metadata": {
                        "truncated": len(results) > 50,
                        "tool_available": True,
                    },
                }
            )

        except Exception as e:
            return json.dumps({"success": False, "error": f"진단 조회 오류: {e}"})

    return diagnostics


def _find_ast_references(source: str, symbol: str) -> list[tuple[int, int, str]]:
    """AST를 사용해 Python 소스에서 심볼의 실제 코드 참조를 찾습니다.

    문자열/주석 내 false positive를 제거하고 실제 코드 참조만 반환합니다.

    Returns:
        (line, col, preview) 튜플 리스트
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []

    lines = source.splitlines()
    refs: list[tuple[int, int, str]] = []

    for node in ast.walk(tree):
        matched = False
        line = 0
        col = 0

        if isinstance(node, ast.Name) and node.id == symbol:
            matched, line, col = True, node.lineno, node.col_offset
        elif isinstance(node, ast.Attribute) and node.attr == symbol:
            matched, line, col = True, node.lineno, node.col_offset
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == symbol:
                matched, line, col = True, node.lineno, node.col_offset
        elif isinstance(node, ast.ClassDef) and node.name == symbol:
            matched, line, col = True, node.lineno, node.col_offset
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == symbol or (alias.asname and alias.asname == symbol):
                    matched, line, col = True, node.lineno, node.col_offset
                    break
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == symbol or (alias.asname and alias.asname == symbol):
                    matched, line, col = True, node.lineno, node.col_offset
                    break

        if matched and line > 0:
            preview = lines[line - 1].strip()[:80] if line <= len(lines) else ""
            refs.append((line, col, preview))

    return refs


_REFERENCES_MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
_REFERENCES_SKIP_DIRS = frozenset(
    {"__pycache__", ".git", "node_modules", ".venv", "venv", ".tox", ".mypy_cache"}
)


def create_references_tool(workspace_root: str) -> BaseTool:
    """
    심볼 참조 찾기용 LangChain 도구를 생성합니다.

    Python 파일은 AST 기반으로 실제 코드 참조만 찾고,
    비-Python 파일은 grep fallback을 사용합니다.

    Args:
        workspace_root: 검색 작업의 루트 디렉토리

    Returns:
        참조 찾기용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def references(
        symbol: str,
        path: Optional[str] = None,
        file_pattern: str = "*.py",
    ) -> str:
        """
        코드베이스 전체에서 심볼의 모든 참조를 찾습니다.

        Python 파일은 AST 분석으로 실제 코드 참조만 정확하게 찾습니다.
        (문자열/주석 내 false positive 제거)
        비-Python 파일은 grep 기반 검색을 사용합니다.

        다음 용도로 유용합니다:
        - 이름 변경/삭제 전 함수/클래스 사용 여부 확인
        - 코드 전체에서 변수가 어떻게 사용되는지 이해
        - 리팩토링 전 모든 사용 위치 찾기

        Args:
            symbol: 찾을 심볼 이름 (함수, 클래스, 변수)
            path: 검색할 선택적 하위 디렉토리 (기본값: 전체 워크스페이스)
            file_pattern: 검색할 파일의 글롭 패턴 (기본값: '*.py')

        Returns:
            참조 위치 목록이 담긴 JSON 문자열
        """
        if not symbol:
            return json.dumps({"success": False, "error": "심볼 이름이 필요합니다"})

        search_path = base_path / path if path else base_path
        if not search_path.exists():
            return json.dumps(
                {
                    "success": False,
                    "error": f"경로를 찾을 수 없음: {path or workspace_root}",
                }
            )

        results: list[dict] = []
        by_file: dict[str, list[dict]] = {}
        use_ast = file_pattern == "*.py"

        try:
            for file_path in search_path.rglob(file_pattern):
                if not file_path.is_file():
                    continue

                # 숨김 디렉토리와 일반적인 비코드 디렉토리 건너뛰기
                if any(
                    part.startswith(".") or part in _REFERENCES_SKIP_DIRS
                    for part in file_path.parts
                ):
                    continue

                # 대용량 파일 건너뛰기
                try:
                    if file_path.stat().st_size > _REFERENCES_MAX_FILE_SIZE:
                        continue
                except OSError:
                    continue

                try:
                    content = file_path.read_text(encoding="utf-8", errors="ignore")
                    rel_path = str(file_path.relative_to(base_path))

                    if use_ast:
                        # AST 기반: 실제 코드 참조만 매칭
                        for line_num, col, preview in _find_ast_references(
                            content, symbol
                        ):
                            ref = {
                                "file": rel_path,
                                "line": line_num,
                                "character": col,
                                "preview": preview,
                            }
                            results.append(ref)
                            by_file.setdefault(rel_path, []).append(ref)
                    else:
                        # grep fallback: 비-Python 파일
                        escaped_symbol = re.escape(symbol)
                        pattern = re.compile(rf"\b{escaped_symbol}\b")
                        for line_num, line in enumerate(content.splitlines(), 1):
                            for match in pattern.finditer(line):
                                ref = {
                                    "file": rel_path,
                                    "line": line_num,
                                    "character": match.start(),
                                    "preview": line.strip()[:80],
                                }
                                results.append(ref)
                                by_file.setdefault(rel_path, []).append(ref)

                except Exception:
                    continue

            # 파일과 줄 기준 정렬
            results.sort(key=lambda x: (x["file"], x["line"]))

            return json.dumps(
                {
                    "success": True,
                    "data": {
                        "references": results[:100],  # 100개로 제한
                        "by_file": {f: len(refs) for f, refs in by_file.items()},
                        "symbol": symbol,
                    },
                    "metadata": {
                        "count": len(results),
                        "file_count": len(by_file),
                        "truncated": len(results) > 100,
                        "method": "ast" if use_ast else "grep",
                    },
                }
            )

        except Exception as e:
            return json.dumps({"success": False, "error": f"참조 찾기 오류: {e}"})

    return references


# =============================================================================
# 보안 스캔 도구
# =============================================================================


def create_security_scan_tool(workspace_root: str) -> BaseTool:
    """
    보안 취약점 스캔용 LangChain 도구를 생성합니다.

    bandit, semgrep, pip-audit, detect-secrets, 커스텀 우회 패턴 스캐너를
    통합하여 코드 레벨 보안 취약점을 검사합니다.

    Args:
        workspace_root: 스캔의 루트 디렉토리

    Returns:
        보안 스캔용 LangChain BaseTool
    """
    base_path = Path(workspace_root)

    @tool
    def security_scan(
        target_path: Optional[str] = None,
        scan_type: str = "all",
        severity_filter: str = "medium",
        semgrep_ruleset: str = "p/owasp-top-ten",
    ) -> str:
        """
        보안 취약점 스캔을 실행합니다.

        여러 보안 스캐너를 통합하여 코드의 보안 취약점을 검사합니다:
        - bandit: Python SAST (정적 분석)
        - semgrep: 패턴 기반 SAST
        - pip-audit: 의존성 취약점
        - detect-secrets: 시크릿/크리덴셜 탐지
        - custom evasion: 우회 패턴 탐지 (base64 인코딩, 변수명 난독화 등)

        이 도구의 용도:
        - 코드 보안 취약점 검사 (SQL 인젝션, 하드코딩된 크리덴셜 등)
        - 의존성 패키지 CVE 취약점 확인
        - 시크릿/API 키 노출 탐지
        - 보안 도구 우회 패턴 탐지

        Args:
            target_path: 스캔 대상 파일/디렉토리 경로 (기본: 워크스페이스 전체)
            scan_type: 스캔 유형 - "all", "sast", "bandit", "semgrep",
                       "dependencies", "secrets", "evasion", "pii"
            severity_filter: 최소 심각도 - "low", "medium" (기본), "high", "critical"
            semgrep_ruleset: semgrep 규칙셋 (기본: "p/owasp-top-ten")

        Returns:
            보안 스캔 결과가 담긴 JSON 문자열
        """
        from ..tools.security_tools import (
            finding_to_dict,
            run_bandit,
            run_custom_pattern_scan,
            run_detect_secrets,
            run_pii_scan,
            run_pip_audit,
            run_semgrep,
        )

        target = str(base_path / target_path) if target_path else str(base_path)

        all_findings = []
        scanners_used = []
        scanners_unavailable = []

        try:
            # --- SAST 스캐너 ---
            if scan_type in ("all", "sast", "bandit"):
                results = run_bandit(target, str(base_path), severity_filter)
                if results:
                    all_findings.extend(results)
                    scanners_used.append("bandit")
                elif scan_type == "bandit":
                    scanners_unavailable.append("bandit")
                else:
                    # bandit이 결과 없으면 미설치 가능성 체크
                    try:
                        subprocess.run(
                            ["bandit", "--version"],
                            capture_output=True,
                            timeout=10,
                        )
                        scanners_used.append("bandit")
                    except FileNotFoundError:
                        scanners_unavailable.append("bandit")

            if scan_type in ("all", "sast", "semgrep"):
                results = run_semgrep(target, str(base_path), semgrep_ruleset)
                if results:
                    all_findings.extend(results)
                    scanners_used.append("semgrep")
                else:
                    try:
                        subprocess.run(
                            ["semgrep", "--version"],
                            capture_output=True,
                            timeout=10,
                        )
                        scanners_used.append("semgrep")
                    except FileNotFoundError:
                        scanners_unavailable.append("semgrep")

            # --- 의존성 스캐너 ---
            if scan_type in ("all", "dependencies"):
                results = run_pip_audit(str(base_path))
                if results:
                    all_findings.extend(results)
                    scanners_used.append("pip-audit")
                else:
                    try:
                        subprocess.run(
                            ["pip-audit", "--version"],
                            capture_output=True,
                            timeout=10,
                        )
                        scanners_used.append("pip-audit")
                    except FileNotFoundError:
                        scanners_unavailable.append("pip-audit")

            # --- 시크릿 스캐너 ---
            if scan_type in ("all", "secrets"):
                results = run_detect_secrets(target, str(base_path))
                if results:
                    all_findings.extend(results)
                    scanners_used.append("detect-secrets")
                else:
                    try:
                        subprocess.run(
                            ["detect-secrets", "--version"],
                            capture_output=True,
                            timeout=10,
                        )
                        scanners_used.append("detect-secrets")
                    except FileNotFoundError:
                        scanners_unavailable.append("detect-secrets")

            # --- 커스텀 우회 패턴 스캐너 (항상 실행 가능) ---
            if scan_type in ("all", "sast", "evasion"):
                results = run_custom_pattern_scan(target, str(base_path))
                if results:
                    all_findings.extend(results)
                scanners_used.append("custom-evasion")

            # --- 개인정보(PII) 패턴 스캐너 (항상 실행 가능) ---
            if scan_type in ("all", "pii"):
                results = run_pii_scan(target, str(base_path))
                if results:
                    all_findings.extend(results)
                scanners_used.append("custom-pii")

            # --- 심각도 필터링 ---
            severity_order = {
                "critical": 0,
                "high": 1,
                "medium": 2,
                "low": 3,
                "info": 4,
            }
            min_sev = severity_order.get(severity_filter, 2)
            filtered = [
                f for f in all_findings if severity_order.get(f.severity, 4) <= min_sev
            ]

            # 심각도 내림차순 정렬
            filtered.sort(key=lambda f: severity_order.get(f.severity, 4))

            # 최대 100개로 제한
            truncated = len(filtered) > 100
            filtered = filtered[:100]

            # --- 요약 생성 ---
            by_severity = {}
            for sev in ("critical", "high", "medium", "low", "info"):
                count = sum(1 for f in filtered if f.severity == sev)
                if count > 0:
                    by_severity[sev] = count

            by_scanner: dict[str, int] = {}
            for f in filtered:
                by_scanner[f.scanner] = by_scanner.get(f.scanner, 0) + 1

            owasp_ids = sorted({f.owasp_id for f in filtered if f.owasp_id})

            return json.dumps(
                {
                    "success": True,
                    "data": {
                        "findings": [finding_to_dict(f) for f in filtered],
                        "summary": {
                            "total": len(filtered),
                            **by_severity,
                            "by_scanner": by_scanner,
                            "owasp_coverage": owasp_ids,
                        },
                        "scanners_used": scanners_used,
                        "scanners_unavailable": scanners_unavailable,
                    },
                    "metadata": {"truncated": truncated},
                }
            )

        except Exception as e:
            return json.dumps({"success": False, "error": f"보안 스캔 오류: {e}"})

    return security_scan


# =============================================================================
# 파일 검색 도구 (fuzzy)
# =============================================================================


def create_file_find_tool(workspace_root: str) -> BaseTool:
    """
    Fuzzy 파일 검색용 LangChain 도구를 생성합니다.

    Args:
        workspace_root: 검색의 루트 디렉토리

    Returns:
        파일 검색용 LangChain BaseTool
    """
    from ..tools.file_finder import FileIndex

    _index = FileIndex(workspace_root)

    @tool
    def file_find(
        query: str,
        path: str = ".",
        file_pattern: Optional[str] = None,
        max_results: int = 20,
    ) -> str:
        """Find files by name using fuzzy matching.

        Use when you need to locate files by partial or approximate name.
        Unlike glob_search (exact glob patterns), this finds files even with
        typos or partial names.

        Examples:
            file_find(query="auth") → finds auth.py, authentication.ts, ...
            file_find(query="main.py") → finds main.py, main_app.py, ...
            file_find(query="config", file_pattern="*.yaml") → YAML configs only
            file_find(query="src/hand") → files matching "hand" under src/

        Args:
            query: Filename or partial name to search for (e.g., "auth", "main.py")
            path: Directory to search in (relative to workspace, default ".")
            file_pattern: Optional extension filter (e.g., "*.py", "*.ts")
            max_results: Maximum number of results (default 20)

        Returns:
            JSON with ranked matches [{path, score, type}, ...]
        """
        if not query:
            return json.dumps({"success": False, "error": "query is required"})

        try:
            # Determine supported extensions from file_pattern
            supported_exts: set[str] | None = None
            if file_pattern:
                # Extract extension from glob pattern like "*.py"
                if file_pattern.startswith("*."):
                    supported_exts = {"." + file_pattern[2:]}

            # If path is not ".", create a sub-index for that directory
            search_index = _index
            if path and path != ".":
                base = Path(workspace_root) / path
                if not base.is_dir():
                    return json.dumps(
                        {"success": False, "error": f"Directory not found: {path}"}
                    )
                search_index = FileIndex(str(base))

            results = search_index.fuzzy_search(
                query=query,
                max_results=max_results,
                supported_exts=supported_exts,
            )

            # Prepend path prefix for sub-directory searches
            if path and path != ".":
                for r in results:
                    r["path"] = str(Path(path) / r["path"])

            return json.dumps(
                {
                    "success": True,
                    "data": results,
                    "metadata": {
                        "query": query,
                        "total": len(results),
                    },
                }
            )
        except Exception as e:
            return json.dumps({"success": False, "error": f"파일 검색 오류: {e}"})

    return file_find


def create_rag_search_tool() -> BaseTool:
    """
    RAG 검색용 LangChain 도구를 생성합니다.

    4개 컬렉션(enterprise_tables, bdp_tables, guide_docs, ds_guide_docs)에서 벡터 검색.

    Returns:
        RAG 검색용 LangChain BaseTool
    """

    @tool
    def rag_search(
        query: str,
        collection: Optional[str] = None,
        top_k: int = 5,
    ) -> str:
        """Search the RAG knowledge base for relevant information.

        Searches across enterprise tables, BDP tables, guide documents, and DS guide documents.
        Use this tool to find table metadata, column definitions, or guide content.

        Args:
            query: 검색 쿼리 (예: "카드 거래 테이블", "BDP 데이터 조회 방법")
            collection: 특정 컬렉션만 검색 ("enterprise_tables", "bdp_tables", "guide_docs", "ds_guide_docs"). None이면 전체.
            top_k: 반환할 최대 결과 수 (기본 5)

        Returns:
            JSON with search results [{collection, score, payload}, ...]
        """
        import asyncio

        try:
            from ..handlers.rag_admin_handler import _ensure_manager

            mgr = _ensure_manager()
            # sync wrapper for async method
            loop = asyncio.get_event_loop()
            if loop.is_running():
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor() as pool:
                    results = pool.submit(
                        asyncio.run,
                        mgr.search_test(
                            query=query, collection=collection, top_k=top_k
                        ),
                    ).result()
            else:
                results = asyncio.run(
                    mgr.search_test(query=query, collection=collection, top_k=top_k)
                )

            if not results:
                return json.dumps(
                    {"success": True, "results": [], "message": "검색 결과 없음"}
                )

            # payload에서 _embed_text 제거 (검색용으로만 사용, LLM에겐 구조화된 payload 제공)
            for r in results:
                r.get("payload", {}).pop("_embed_text", None)

            return json.dumps(
                {"success": True, "results": results, "total": len(results)},
                ensure_ascii=False,
            )
        except ImportError:
            return json.dumps(
                {
                    "success": False,
                    "error": "RAG 시스템이 초기화되지 않았습니다. qdrant-client를 설치하세요.",
                }
            )
        except Exception as e:
            return json.dumps({"success": False, "error": f"RAG 검색 오류: {e}"})

    return rag_search


def create_enhanced_rag_search_tool() -> BaseTool:
    """배치 쿼리 + Qdrant pre-filtering 지원 RAG 검색 도구 (chat mode 전용).

    Returns:
        RAG 검색용 LangChain BaseTool
    """

    @tool
    async def rag_search(queries: Any, top_k: int = 5) -> str:  # noqa: C901
        """RAG 지식 베이스에서 정보를 검색합니다.

        ## 사용 가능한 컬렉션

        1. **enterprise_tables** — 전사 엔터프라이즈 테이블 메타데이터
           - payload: table_name, korean_name, db_name, columns[{col_name, col_korean_name, col_type, pk}]
           - 내용: 테이블명, 한글명, DB명, 컬럼 정보 등
           - 필터 가능: table_name, korean_name, db_name

        2. **bdp_tables** — BDP 빅데이터플랫폼 테이블 메타데이터
           - payload: table_id, table_name, korean_name, storage_format, update_cycle, domain, owner_team, columns[...]
           - 예시: 카드/여신/수신 도메인 테이블, 일/월 배치 적재
           - 필터 가능: table_name, korean_name, domain, owner_team, storage_format, update_cycle

        3. **guide_docs** — BDP/플랫폼 업무 가이드 + bdpengine API 레퍼런스
           - payload: content, summary, source(파일명), title, section
           - 포함: BDP 아키텍처, S3/Athena/EMR/SageMaker 가이드, bdpengine 함수(S3, MinIO, Spark, Athena)
           - bdpengine: BDP 핵심 Python 패키지 (from bdpengine.functions import *). S3 파일관리, MinIO, Spark Job, Athena 쿼리 통합 인터페이스
           - 필터 가능: source(파일명), title, section

        4. **ds_guide_docs** — 데이터사이언스 기술 가이드
           - payload: content, summary, source(파일명), title, section
           - 포함: Pandas, PySpark, Dask, LightGBM 사용법/최적화
           - 필터 가능: source(파일명), title, section

        5. **codebase** — 사용자 코드베이스 (로컬 인덱싱)
           - payload: content, file_path, symbol_name, symbol_type, line_start, line_end, language
           - 내용: 함수/클래스/메서드 단위 코드 블록
           - 필터 불필요 (자연어 검색만 사용)

        ## queries 형식

        JSON 배열 문자열. 여러 쿼리를 보내면 병렬 처리.

        각 요소: {"query": "...", "collection": "...", "match_text": ["검색어1", "검색어2"]}
        - match_text (선택): 텍스트 인덱스 보조 검색어 리스트. 인덱스된 전체 필드에 OR 조건으로 자동 매칭.
          벡터 검색과 병합하여 매칭 결과를 우선 포함합니다.

        예시:
        [{"query": "카드 거래 테이블", "collection": "enterprise_tables"}]
        [{"query": "S3 파일 업로드", "collection": "guide_docs"}, {"query": "고객 테이블", "collection": "bdp_tables"}]
        [{"query": "카드매출 스키마", "collection": "bdp_tables", "match_text": ["card_pchs", "카드매출"]}]

        Args:
            queries: JSON 배열 문자열. 각 요소: {query: str, collection?: str, match_text?: list}
            top_k: 쿼리당 최대 결과 수 (기본 5)

        Returns:
            JSON. "테이블 검색 결과"와 "가이드 검색 결과"로 그룹핑.
        """
        import asyncio

        # queries가 list/dict(이미 파싱됨), str(JSON), str(repr), str(double-encoded) 모두 처리
        parsed = queries
        if isinstance(parsed, str):
            try:
                parsed = json.loads(parsed)
            except (json.JSONDecodeError, TypeError):
                # Python repr 형식 (single quotes) 처리
                try:
                    import ast as _ast

                    parsed = _ast.literal_eval(parsed)
                except Exception:
                    parsed = None
        if isinstance(parsed, str):
            # double-encoded: json.loads 결과가 또 string인 경우
            try:
                parsed = json.loads(parsed)
            except (json.JSONDecodeError, TypeError):
                parsed = None
        if isinstance(parsed, dict):
            parsed = [parsed]

        if not isinstance(parsed, list) or not parsed:
            return json.dumps(
                {
                    "success": False,
                    "error": f"queries 파싱 실패 (list 변환 불가): {str(queries)[:200]}",
                },
                ensure_ascii=False,
            )

        try:
            from hdsp_agent_core.services.rag_collections import get_manager

            mgr = get_manager()
            if mgr is None:
                return json.dumps(
                    {"success": False, "error": "RAG 매니저가 초기화되지 않았습니다."},
                    ensure_ascii=False,
                )

            # async tool이므로 직접 await 가능 (데드락 없음)
            tasks = []
            code_queries = []  # codebase는 별도 로컬 Qdrant
            regular_queries = []

            _seen_queries: set = set()  # (query, collection) 중복 제거

            for i, q in enumerate(parsed):
                query_text = q.get("query", "") if isinstance(q, dict) else str(q)
                collection = q.get("collection") if isinstance(q, dict) else None
                raw_mt = q.get("match_text") if isinstance(q, dict) else None
                match_text = (
                    raw_mt
                    if isinstance(raw_mt, list)
                    else [raw_mt]
                    if isinstance(raw_mt, str)
                    else None
                )

                # enterprise_tables → 사용자 원본 메시지에 키워드 없으면 bdp_tables로 변환
                if collection == "enterprise_tables":
                    _check_text = f"{_last_user_message} {query_text}"
                    if not _ENTERPRISE_KEYWORDS.search(_check_text):
                        print(
                            f"[RAG] enterprise_tables → bdp_tables (no keyword): {query_text[:80]}",
                            flush=True,
                        )
                        collection = "bdp_tables"

                # 동일 (query, collection) 중복 스킵
                dedup_key = (query_text.lower().strip(), collection)
                if dedup_key in _seen_queries:
                    print(
                        f"[RAG] skipping duplicate query: {query_text[:80]} → {collection}",
                        flush=True,
                    )
                    continue
                _seen_queries.add(dedup_key)

                if collection == "codebase":
                    code_queries.append((i, query_text))
                else:
                    # 테이블 컬렉션은 top_k=3 (컬럼 정보가 커서 토큰 절약)
                    effective_top_k = (
                        3
                        if collection in ("enterprise_tables", "bdp_tables")
                        else top_k
                    )
                    # match_text는 테이블 컬렉션에서만 사용
                    effective_mt = (
                        match_text
                        if collection in ("enterprise_tables", "bdp_tables")
                        else None
                    )
                    regular_queries.append(i)
                    tasks.append(
                        mgr.search_with_filter(
                            query=query_text,
                            collection=collection,
                            top_k=effective_top_k,
                            match_text=effective_mt,
                        )
                    )

            # codebase 로컬 검색 (싱글턴 인덱서 재사용)
            code_results_map: dict = {}
            if code_queries:
                try:
                    from jupyter_ext.handlers.rag_admin_handler import (
                        _ensure_code_indexer,
                    )

                    indexer = _ensure_code_indexer()
                    for idx, query_text in code_queries:
                        code_hits = await indexer.search(query=query_text, top_k=top_k)
                        code_results_map[idx] = code_hits
                except Exception as e:
                    print(f"[RAG] codebase error: {e}", flush=True)

            all_results = await asyncio.gather(*tasks, return_exceptions=True)

            # 결과 그룹핑
            table_results = []
            guide_results = []
            code_results = []

            # codebase 결과 추가
            for idx, hits in code_results_map.items():
                for r in hits:
                    r["collection"] = "codebase"
                    r["_query"] = (
                        parsed[idx].get("query", "")
                        if isinstance(parsed[idx], dict)
                        else ""
                    )
                    code_results.append(r)

            for ri, result in enumerate(all_results):
                if isinstance(result, Exception):
                    print(f"[RAG] search error for query {ri}: {result}", flush=True)
                    continue
                orig_idx = regular_queries[ri]
                query_info = parsed[orig_idx] if orig_idx < len(parsed) else {}
                query_text = (
                    query_info.get("query", "") if isinstance(query_info, dict) else ""
                )
                for r in result:
                    r["_query"] = query_text
                    col = r.get("collection", "")
                    if col in ("enterprise_tables", "bdp_tables"):
                        table_results.append(r)
                    else:
                        guide_results.append(r)

            # LLM에 불필요한 키 제거 + columns를 header+rows로 압축 (토큰 절약)
            _STRIP_KEYS = {"id", "_group_key", "_chunk"}
            for r in table_results + guide_results + code_results:
                for k in _STRIP_KEYS:
                    r.pop(k, None)
                p = r.get("payload")
                if isinstance(p, dict):
                    for k in _STRIP_KEYS:
                        p.pop(k, None)
                    # columns: [{key:val,...},...] → col_headers + columns [[val,...],...]
                    # col_headers를 columns 앞에 배치 (LLM이 헤더를 먼저 읽도록)
                    cols = p.get("columns")
                    if cols and isinstance(cols, list) and isinstance(cols[0], dict):
                        headers = list(cols[0].keys())
                        rows = [[c.get(h, "") for h in headers] for c in cols]
                        del p["columns"]
                        p["col_headers"] = headers
                        p["columns"] = rows

            # _warnings 수집 (match_text fallback 등)
            warnings: list = []
            for r in table_results + guide_results + code_results:
                for w in r.pop("_warnings", []):
                    if w not in warnings:
                        warnings.append(w)

            output = {"success": True}
            if warnings:
                output["warnings"] = warnings
            if table_results:
                output["테이블 검색 결과"] = table_results
            if code_results:
                output["코드 검색 결과"] = code_results
            if guide_results:
                output["가이드 검색 결과"] = guide_results
            if not table_results and not guide_results and not code_results:
                output["message"] = "검색 결과 없음"
                output["results"] = []
            output["total"] = (
                len(table_results) + len(guide_results) + len(code_results)
            )

            return json.dumps(output, ensure_ascii=False, default=str)

        except Exception as e:
            return json.dumps(
                {"success": False, "error": f"RAG 검색 오류: {e}"},
                ensure_ascii=False,
            )

    return rag_search


def create_get_table_columns_tool() -> BaseTool:
    """테이블 컬럼 목록 조회 도구.

    Returns:
        LangChain BaseTool
    """

    @tool
    async def get_table_columns(
        table_name: str,
        collection: str = "bdp_tables",
        start_index: int = 0,
    ) -> str:
        """테이블의 컬럼 목록을 조회합니다.

        rag_search 결과에서 컬럼이 축약된 경우 이 도구로 전체 컬럼을 확인합니다.

        Args:
            table_name: 테이블 이름 (정확한 이름 또는 부분 매칭)
            collection: 컬렉션 이름 (enterprise_tables 또는 bdp_tables, 기본: bdp_tables)
            start_index: 컬럼 목록 시작 인덱스 (페이징용, 기본 0)

        Returns:
            JSON. table_name, collection, total_columns, start_index, columns, next_index, has_more
        """
        _MAX_COLUMNS = 100
        _ALLOWED = ("enterprise_tables", "bdp_tables")

        if collection not in _ALLOWED:
            return json.dumps(
                {
                    "success": False,
                    "error": f"collection은 {_ALLOWED} 중 하나여야 합니다.",
                },
                ensure_ascii=False,
            )

        # enterprise_tables 접근 제한: 사용자 원본 메시지에 키워드 없으면 bdp_tables로 변환
        if collection == "enterprise_tables":
            _check_text = f"{_last_user_message} {table_name}"
            if not _ENTERPRISE_KEYWORDS.search(_check_text):
                print(
                    f"[RAG] get_table_columns: enterprise → bdp (no keyword): {table_name}",
                    flush=True,
                )
                collection = "bdp_tables"

        try:
            from hdsp_agent_core.services.rag_collections import get_manager

            mgr = get_manager()
            if mgr is None:
                return json.dumps(
                    {"success": False, "error": "RAG 매니저가 초기화되지 않았습니다."},
                    ensure_ascii=False,
                )

            client = mgr._client

            # MatchText → MatchValue fallback으로 테이블 포인트 검색
            matched_points: list = []
            resolved_table_name = None
            try:
                from qdrant_client.models import (
                    FieldCondition,
                    Filter,
                    MatchText,
                    MatchValue,
                )

                # 테이블명 필드: table_name 또는 테이블명 (매핑 설정에 따라 다름)
                _TABLE_NAME_FIELDS = ["table_name", "테이블명"]

                # 1) MatchText로 검색 (text index가 있는 필드에서)
                mt_conditions = [
                    FieldCondition(key=f, match=MatchText(text=table_name.lower()))
                    for f in _TABLE_NAME_FIELDS
                ]
                mt_filter = Filter(should=mt_conditions)
                scroll_result = client.scroll(
                    collection_name=collection,
                    scroll_filter=mt_filter,
                    limit=100,
                    with_payload=True,
                    with_vectors=False,
                )
                points = scroll_result[0] if scroll_result else []

                if points:
                    # exact match 테이블명 결정 (대소문자 무시)
                    for pt in points:
                        for f in _TABLE_NAME_FIELDS:
                            pt_name = (pt.payload or {}).get(f, "")
                            if pt_name and pt_name.lower() == table_name.lower():
                                resolved_table_name = pt_name
                                break
                        if resolved_table_name:
                            break
                    if resolved_table_name is None:
                        for f in _TABLE_NAME_FIELDS:
                            v = (points[0].payload or {}).get(f, "")
                            if v:
                                resolved_table_name = v
                                break

                # 2) MatchText 실패 시 MatchValue fallback
                if not points:
                    for f in _TABLE_NAME_FIELDS:
                        for mv_val in (table_name, table_name.lower()):
                            mv_filter = Filter(
                                must=[
                                    FieldCondition(
                                        key=f,
                                        match=MatchValue(value=mv_val),
                                    )
                                ]
                            )
                            scroll_result = client.scroll(
                                collection_name=collection,
                                scroll_filter=mv_filter,
                                limit=100,
                                with_payload=True,
                                with_vectors=False,
                            )
                            points = scroll_result[0] if scroll_result else []
                            if points:
                                resolved_table_name = mv_val
                                break
                        if points:
                            break

                # 같은 테이블의 모든 청크 수집
                resolved_lower = (resolved_table_name or "").lower()
                matched_points = [
                    pt
                    for pt in points
                    if pt.payload
                    and any(
                        (pt.payload.get(f) or "").lower() == resolved_lower
                        for f in _TABLE_NAME_FIELDS
                    )
                ]
                print(
                    f"[RAG] get_table_columns: {table_name} → "
                    f"resolved={resolved_table_name}, points={len(matched_points)}",
                    flush=True,
                )
            except Exception as e:
                print(
                    f"[RAG] get_table_columns search error: {e}",
                    flush=True,
                )

            if not matched_points:
                return json.dumps(
                    {
                        "success": False,
                        "error": f"테이블 '{table_name}'을(를) {collection}에서 찾을 수 없습니다.",
                    },
                    ensure_ascii=False,
                )

            # 청크 순서대로 정렬 후 컬럼 합치기
            def _chunk_sort_key(pt):
                chunk = (pt.payload or {}).get("_chunk", "1/1")
                try:
                    return int(str(chunk).split("/")[0])
                except (ValueError, IndexError):
                    return 0

            matched_points.sort(key=_chunk_sort_key)
            found_table_name = resolved_table_name or table_name
            columns: list = []
            for pt in matched_points:
                pt_cols = (pt.payload or {}).get("columns", [])
                if isinstance(pt_cols, list):
                    columns.extend(pt_cols)

            # columns 포맷팅
            total = len(columns) if isinstance(columns, list) else 0
            if start_index < 0:
                start_index = 0

            sliced = (
                columns[start_index : start_index + _MAX_COLUMNS]
                if isinstance(columns, list)
                else []
            )
            end_index = start_index + len(sliced)
            has_more = end_index < total

            # col_headers + rows 형태로 압축 (토큰 절약)
            col_headers: list = []
            formatted_rows: list = []
            for idx, col in enumerate(sliced):
                if isinstance(col, dict):
                    if not col_headers:
                        col_headers = list(col.keys())
                    formatted_rows.append([col.get(h, "") for h in col_headers])
                elif isinstance(col, list):
                    formatted_rows.append(col)
                else:
                    formatted_rows.append([str(col)])

            result: dict = {
                "success": True,
                "table_name": found_table_name,
                "collection": collection,
                "total_columns": total,
                "start_index": start_index,
                "next_index": end_index if has_more else None,
                "has_more": has_more,
            }
            if col_headers:
                result["col_headers"] = col_headers
            result["columns"] = formatted_rows
            return json.dumps(result, ensure_ascii=False, default=str)

        except Exception as e:
            return json.dumps(
                {"success": False, "error": f"컬럼 조회 오류: {e}"},
                ensure_ascii=False,
            )

    return get_table_columns


# ---------------------------------------------------------------------------
# Data Skill — 동적 필터 가이드 + 확장 도구 디스커버리
# ---------------------------------------------------------------------------

# 모듈 레벨 캐시: 최초 1회 Qdrant 조회 후 재사용
_table_skill_cache: Optional[str] = None

_EXCLUDED_PAYLOAD_KEYS = {
    "content",
    "_embed_text",
    "summary",
    "columns",
    "embedding_text",
}
_MAX_SAMPLE_VALUES = 10


def _build_filter_guide() -> str:
    """Qdrant에서 테이블 컬렉션의 payload 키와 샘플 값을 조회."""
    global _table_skill_cache
    if _table_skill_cache is not None:
        return _table_skill_cache

    try:
        from hdsp_agent_core.services.rag_collections import (
            COLLECTION_BDP,
            COLLECTION_ENTERPRISE,
            get_manager,
        )

        mgr = get_manager()
        if mgr is None:
            return "(RAG 매니저 미초기화)"

        client = mgr._client
        existing = {c.name for c in client.get_collections().collections}

        # 테이블 컬렉션만 조회 (guide는 pre-filtering 불필요)
        table_collections = [COLLECTION_ENTERPRISE, COLLECTION_BDP]
        lines: list[str] = []

        for col_name in table_collections:
            if col_name not in existing:
                continue

            try:
                scroll_result = client.scroll(
                    collection_name=col_name,
                    limit=30,
                    with_payload=True,
                    with_vectors=False,
                )
                points = scroll_result[0] if scroll_result else []
            except Exception:
                continue

            if not points:
                continue

            # payload 키별 unique 값 수집
            key_values: dict[str, set] = {}
            for pt in points:
                if not pt.payload:
                    continue
                for k, v in pt.payload.items():
                    if k in _EXCLUDED_PAYLOAD_KEYS:
                        continue
                    if isinstance(v, (list, dict)):
                        continue
                    if k not in key_values:
                        key_values[k] = set()
                    key_values[k].add(str(v))

            if not key_values:
                continue

            lines.append(f"\n**{col_name}** 필터 가능 필드:")
            for key, values in sorted(key_values.items()):
                sample = sorted(values)[:_MAX_SAMPLE_VALUES]
                sample_str = ", ".join(f'"{v}"' for v in sample)
                suffix = " ..." if len(values) > _MAX_SAMPLE_VALUES else ""
                lines.append(f"  - `{key}`: {sample_str}{suffix}")

            # MatchText 검색 가능 필드 (text index가 있는 필드)
            try:
                col_info = client.get_collection(col_name)
                text_fields = [
                    field_name
                    for field_name, schema in (col_info.payload_schema or {}).items()
                    if schema.data_type == "text"
                    or getattr(schema, "lookup", None) == "text"
                    or "text" in str(getattr(schema, "params", "")).lower()
                ]
                if text_fields:
                    lines.append(f"\n**{col_name}** MatchText 검색 가능 필드:")
                    for f in sorted(text_fields):
                        lines.append(f"  - `{f}`")
            except Exception:
                pass

        result = "\n".join(lines) if lines else "(테이블 컬렉션 없음)"
        _table_skill_cache = result
        print(f"[RAG] data_skill cache built ({len(result)} chars)", flush=True)
        return result

    except Exception as e:
        print(f"[RAG] data_skill build failed: {e}", flush=True)
        return f"(스키마 조회 실패: {e})"


def create_load_skills_tool() -> BaseTool:
    """스킬 로드 도구. skills/ 디렉토리의 md 파일을 이름으로 로드.

    Returns:
        LangChain BaseTool
    """

    # 사용 가능한 스킬 목록을 skills/ 디렉토리에서 동적 생성
    _skill_dir = Path(__file__).parent / "skills"
    _available = sorted(p.stem for p in _skill_dir.glob("*.md"))
    _skill_list = ", ".join(_available) if _available else "(없음)"

    @tool
    def load_skills(names: str) -> str:
        """스킬을 로드합니다. 쉼표로 구분하여 여러 스킬을 한번에 로드 가능.

        Args:
            names: 스킬 이름 (쉼표 구분). 예: "table_filter,athena_sql"

        Returns:
            로드된 스킬 내용.
        """
        skill_dir = _skill_dir
        skill_names = [n.strip() for n in names.split(",") if n.strip()]
        results: list[str] = []

        for name in skill_names:
            md_path = skill_dir / f"{name}.md"
            try:
                template = md_path.read_text(encoding="utf-8")
            except FileNotFoundError:
                results.append(f"[스킬 '{name}' 없음]")
                continue

            # 동적 플레이스홀더 치환
            if "{filter_guide}" in template:
                template = template.replace("{filter_guide}", _build_filter_guide())

            results.append(template)

        output = "\n\n---\n\n".join(results)
        print(f"[RAG] load_skills({names}): {len(results)} loaded", flush=True)
        return output

    # tool description에 사용 가능한 스킬 목록 동적 추가
    load_skills.description = (
        f"스킬을 로드합니다. 쉼표로 구분하여 여러 스킬을 한번에 로드 가능. "
        f"사용 가능: {_skill_list}"
    )
    return load_skills
