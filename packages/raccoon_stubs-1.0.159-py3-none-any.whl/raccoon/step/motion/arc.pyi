from __future__ import annotations
import math as math
import raccoon.motion
from raccoon.motion import ArcMotion
from raccoon.motion import ArcMotionConfig
import raccoon.step.annotation
from raccoon.step.annotation import dsl
from raccoon.step.annotation import dsl_step
import raccoon.step.model
from raccoon.step.model import SimulationStep
from raccoon.step.model import SimulationStepDelta
import raccoon.step.motion.motion_step
from raccoon.step.motion.motion_step import MotionStep
import typing
__all__: list[str] = ['Arc', 'ArcMotion', 'ArcMotionConfig', 'DriveArc', 'DriveArcLeft', 'DriveArcRight', 'MotionStep', 'SimulationStep', 'SimulationStepDelta', 'StrafeArc', 'StrafeArcLeft', 'StrafeArcRight', 'dsl', 'dsl_step', 'math']
class Arc(raccoon.step.motion.motion_step.MotionStep):
    """
    Step wrapper around the native `ArcMotion` controller.
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'Arc'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, config: raccoon.motion.ArcMotionConfig):
        ...
    def _generate_signature(self) -> str:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        ...
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        ...
    def to_simulation_step(self) -> raccoon.step.model.SimulationStep:
        ...
class DriveArc(Arc):
    """
    Drive along a circular arc with explicit direction (internal use only).
    
    Positive degrees = counter-clockwise (left), negative = clockwise (right).
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DriveArc'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, radius_cm: float, degrees: float, speed: float = 1.0) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class DriveArcLeft(Arc):
    """
    Drive along a circular arc curving to the left.
    
    The robot drives forward while simultaneously turning counter-clockwise,
    tracing a circular arc of the given radius. The motion completes when
    the robot has turned by the specified number of degrees.
    
    Args:
        radius_cm: Turning radius in centimeters (center of arc to robot center).
        degrees: Arc angle in degrees (how much the robot turns).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A DriveArcLeft step configured for a left (CCW) arc.
    
    Example::
    
        from raccoon.step.motion import drive_arc_left
    
        # Quarter-circle left with 30 cm radius
        drive_arc_left(radius_cm=30, degrees=90)
    
        # Gentle wide arc at half speed
        drive_arc_left(radius_cm=50, degrees=45, speed=0.5)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='DriveArcLeft', tags=('motion', 'arc'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DriveArcLeft'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'arc')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'arc')
    def __init__(self, radius_cm: float, degrees: float, speed: float = 1.0) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class DriveArcRight(Arc):
    """
    Drive along a circular arc curving to the right.
    
    The robot drives forward while simultaneously turning clockwise,
    tracing a circular arc of the given radius. The motion completes when
    the robot has turned by the specified number of degrees.
    
    Args:
        radius_cm: Turning radius in centimeters (center of arc to robot center).
        degrees: Arc angle in degrees (how much the robot turns).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A DriveArcRight step configured for a right (CW) arc.
    
    Example::
    
        from raccoon.step.motion import drive_arc_right
    
        # Quarter-circle right with 30 cm radius
        drive_arc_right(radius_cm=30, degrees=90)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='DriveArcRight', tags=('motion', 'arc'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DriveArcRight'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'arc')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'arc')
    def __init__(self, radius_cm: float, degrees: float, speed: float = 1.0) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class StrafeArc(Arc):
    """
    Strafe along a circular arc with explicit direction (internal use only).
    
    Positive degrees = counter-clockwise (left), negative = clockwise (right).
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name=None, tags=())
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StrafeArc'
    __dsl_tags__: typing.ClassVar[tuple] = tuple()
    def __init__(self, radius_cm: float, degrees: float, speed: float = 1.0) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class StrafeArcLeft(Arc):
    """
    Strafe along a circular arc curving to the left.
    
    The robot strafes laterally (to the right) while simultaneously turning
    counter-clockwise, tracing a circular arc of the given radius. The motion
    completes when the robot has turned by the specified number of degrees.
    
    Internally uses a profiled PID on heading and derives the lateral velocity
    from the angular velocity command: ``vy = |omega| * radius``. This produces
    coordinated acceleration along the arc.
    
    Prerequisites:
        Requires a mecanum or omni-wheel drivetrain capable of lateral motion.
    
    Args:
        radius_cm: Turning radius in centimeters (center of arc to robot center).
        degrees: Arc angle in degrees (how much the robot turns).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A StrafeArcLeft step configured for a left (CCW) strafe arc.
    
    Example::
    
        from raccoon.step.motion import strafe_arc_left
    
        # Quarter-circle strafe arc to the left with 30 cm radius
        strafe_arc_left(radius_cm=30, degrees=90)
    
        # Gentle wide strafe arc at half speed
        strafe_arc_left(radius_cm=50, degrees=45, speed=0.5)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='StrafeArcLeft', tags=('motion', 'strafe', 'arc'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StrafeArcLeft'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'strafe', 'arc')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'strafe', 'arc')
    def __init__(self, radius_cm: float, degrees: float, speed: float = 1.0) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class StrafeArcRight(Arc):
    """
    Strafe along a circular arc curving to the right.
    
    The robot strafes laterally (to the left) while simultaneously turning
    clockwise, tracing a circular arc of the given radius. The motion
    completes when the robot has turned by the specified number of degrees.
    
    Internally uses a profiled PID on heading and derives the lateral velocity
    from the angular velocity command: ``vy = |omega| * radius``. This produces
    coordinated acceleration along the arc.
    
    Prerequisites:
        Requires a mecanum or omni-wheel drivetrain capable of lateral motion.
    
    Args:
        radius_cm: Turning radius in centimeters (center of arc to robot center).
        degrees: Arc angle in degrees (how much the robot turns).
        speed: Fraction of max speed, 0.0 to 1.0 (default 1.0).
    
    Returns:
        A StrafeArcRight step configured for a right (CW) strafe arc.
    
    Example::
    
        from raccoon.step.motion import strafe_arc_right
    
        # Quarter-circle strafe arc to the right with 30 cm radius
        strafe_arc_right(radius_cm=30, degrees=90)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='StrafeArcRight', tags=('motion', 'strafe', 'arc'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StrafeArcRight'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'strafe', 'arc')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'strafe', 'arc')
    def __init__(self, radius_cm: float, degrees: float, speed: float = 1.0) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
