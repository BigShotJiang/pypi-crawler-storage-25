"""
Auto-generated step builders and DSL functions — DO NOT EDIT.

Source: at_heading.py
"""
from __future__ import annotations
from raccoon.step.annotation import dsl
from raccoon.step.condition import StopCondition
from raccoon.step.motion.at_heading import HeadingOrigin
from raccoon.step.motion.at_heading import WaitUntilDegrees
import raccoon.step.step_builder
from raccoon.step.step_builder import StepBuilder
__all__: list = ['WaitUntilDegreesBuilder', 'wait_until_degrees']
class WaitUntilDegreesBuilder(raccoon.step.step_builder.StepBuilder):
    """
    Builder for WaitUntilDegrees. Auto-generated — do not edit.
    """
    def __init__(self):
        ...
    def _build(self):
        ...
    def degrees(self, value: float):
        ...
    def origin(self, value: HeadingOrigin):
        ...
def wait_until_degrees(degrees: float = ..., origin: HeadingOrigin = ...):
    """
    
    Wait until the robot has turned at least the given number of degrees.
    
    Polls heading at 100 Hz and compares the angular distance from the
    chosen origin against the threshold.  Designed to run inside a
    ``parallel()`` branch alongside a turn step, enabling actions to trigger
    at specific angles during a turn.
    
    The origin (zero point) is controlled by the ``origin`` parameter — see
    :class:`HeadingOrigin` for the three available modes.
    
    Args:
        degrees: Heading-change threshold in degrees (always positive).
        origin: Which reference point to count degrees from. Defaults to ``HeadingOrigin.STEP_START``.
    
    Returns:
        A WaitUntilDegreesBuilder (chainable via ``.degrees()``, ``.origin()``, ``.on_anomaly()``, ``.skip_timing()``).
    
    Example::
    
        from raccoon.step import parallel, seq
        from raccoon.step.motion import turn_left, wait_until_degrees, HeadingOrigin
        from raccoon.step.servo import servo
    
        # Default: fires 45° after this step starts executing
        parallel([
            turn_left(90),
            seq([wait_until_degrees(45), servo(claw, 90)]),
        ])
    
        # TURN_START: fires at 45° from the turn's own start
        parallel([
            turn_left(90),
            seq([prepare_arm(), wait_until_degrees(45, origin=HeadingOrigin.TURN_START), servo(claw, 90)]),
        ])
    
        # HEADING_REFERENCE: fires at 45° from the global reference
        parallel([
            turn_left(90),
            seq([wait_until_degrees(45, origin=HeadingOrigin.HEADING_REFERENCE), servo(claw, 90)]),
        ])
    """
_UNSET: object  # value = <object object>
