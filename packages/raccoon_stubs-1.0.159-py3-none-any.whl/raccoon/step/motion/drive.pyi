from __future__ import annotations
import math as math
import raccoon.motion
from raccoon.motion import LinearAxis
from raccoon.motion import LinearMotion
from raccoon.motion import LinearMotionConfig
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
import raccoon.step.condition
from raccoon.step.condition import StopCondition
import raccoon.step.motion.motion_step
from raccoon.step.motion.motion_step import MotionStep
import typing
__all__: list[str] = ['DriveBackward', 'DriveForward', 'LinearAxis', 'LinearMotion', 'LinearMotionConfig', 'MotionStep', 'StopCondition', 'StrafeLeft', 'StrafeRight', 'dsl_step', 'math']
class DriveBackward(_ConditionalDrive):
    """
    Drive backward with distance or condition-based termination.
    
    Identical to ``drive_forward()`` but in reverse. Uses profiled PID
    motion control while maintaining heading via IMU feedback. Supports
    the same ``heading`` parameter for absolute heading hold.
    
    Requires ``calibrate_distance()`` for distance-based mode.
    Requires ``mark_heading_reference()`` when using ``heading``.
    
    Args:
        heading: Absolute heading in degrees from the heading reference
            to hold during this drive. ``None`` (default) holds the
            heading at the start of the drive (relative mode).
    
    Example::
    
        drive_backward(20)
        drive_backward(20, heading=0)                # hold 0° absolute
        drive_backward(speed=0.5).until(on_white(s))
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='DriveBackward', tags=('motion', 'drive'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DriveBackward'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'drive')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'drive')
    _axis: typing.ClassVar[raccoon.motion.LinearAxis]  # value = <LinearAxis.Forward: 0>
    _sign: typing.ClassVar[float] = -1.0
    def __init__(self, cm: float = None, speed: float = 1.0, until: raccoon.step.condition.StopCondition = None, heading: float = None):
        ...
class DriveForward(_ConditionalDrive):
    """
    Drive forward with distance or condition-based termination.
    
    Uses profiled PID motion control with a trapezoidal velocity profile.
    The robot accelerates, cruises, and decelerates while maintaining
    heading via IMU feedback. When ``heading`` is given, the controller
    holds that absolute heading (degrees from heading reference) instead
    of the heading at start, preventing drift accumulation across
    consecutive drives.
    
    Requires ``calibrate_distance()`` for distance-based mode.
    Requires ``mark_heading_reference()`` when using ``heading``.
    
    Args:
        heading: Absolute heading in degrees from the heading reference
            to hold during this drive. ``None`` (default) holds the
            heading at the start of the drive (relative mode).
    
    Example::
    
        drive_forward(25)                            # 25 cm, relative heading
        drive_forward(25, heading=90)                # hold 90° absolute
        drive_forward(speed=0.8).until(on_black(s))  # until sensor
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='DriveForward', tags=('motion', 'drive'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'DriveForward'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'drive')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'drive')
    _axis: typing.ClassVar[raccoon.motion.LinearAxis]  # value = <LinearAxis.Forward: 0>
    _sign: typing.ClassVar[float] = 1.0
    def __init__(self, cm: float = None, speed: float = 1.0, until: raccoon.step.condition.StopCondition = None, heading: float = None):
        ...
class StrafeLeft(_ConditionalDrive):
    """
    Strafe left with distance or condition-based termination.
    
    Requires a mecanum or omni-wheel drivetrain. The robot moves
    laterally to the left while maintaining heading via IMU feedback.
    Supports the same ``heading`` parameter for absolute heading hold.
    
    Requires ``mark_heading_reference()`` when using ``heading``.
    
    Args:
        heading: Absolute heading in degrees from the heading reference
            to hold during this strafe. ``None`` (default) holds the
            heading at the start of the strafe (relative mode).
    
    Example::
    
        strafe_left(15)
        strafe_left(15, heading=90)                  # hold 90° absolute
        strafe_left(speed=0.6).until(on_black(s))
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='StrafeLeft', tags=('motion', 'strafe'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StrafeLeft'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'strafe')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'strafe')
    _axis: typing.ClassVar[raccoon.motion.LinearAxis]  # value = <LinearAxis.Lateral: 1>
    _sign: typing.ClassVar[float] = -1.0
    def __init__(self, cm: float = None, speed: float = 1.0, until: raccoon.step.condition.StopCondition = None, heading: float = None):
        ...
class StrafeRight(_ConditionalDrive):
    """
    Strafe right with distance or condition-based termination.
    
    Requires a mecanum or omni-wheel drivetrain. The robot moves
    laterally to the right while maintaining heading via IMU feedback.
    Supports the same ``heading`` parameter for absolute heading hold.
    
    Requires ``mark_heading_reference()`` when using ``heading``.
    
    Args:
        heading: Absolute heading in degrees from the heading reference
            to hold during this strafe. ``None`` (default) holds the
            heading at the start of the strafe (relative mode).
    
    Example::
    
        strafe_right(15)
        strafe_right(15, heading=0)                  # hold 0° absolute
        strafe_right(speed=0.6).until(on_black(s))
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='StrafeRight', tags=('motion', 'strafe'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StrafeRight'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('motion', 'strafe')
    __dsl_tags__: typing.ClassVar[tuple] = ('motion', 'strafe')
    _axis: typing.ClassVar[raccoon.motion.LinearAxis]  # value = <LinearAxis.Lateral: 1>
    _sign: typing.ClassVar[float] = 1.0
    def __init__(self, cm: float = None, speed: float = 1.0, until: raccoon.step.condition.StopCondition = None, heading: float = None):
        ...
class _ConditionalDrive(raccoon.step.motion.motion_step.MotionStep):
    """
    Base for directional drive steps with optional stop conditions.
    
    Always uses profiled LinearMotion. When no distance is given,
    a large sentinel distance (100 m) is used so the motion provider
    handles velocity/heading control and the condition triggers the stop.
    """
    _SENTINEL_DISTANCE_M: typing.ClassVar[float] = 100.0
    _axis: typing.ClassVar[raccoon.motion.LinearAxis]  # value = <LinearAxis.Forward: 0>
    _sign: typing.ClassVar[float] = 1.0
    def __init__(self, cm: float = None, speed: float = 1.0, until: raccoon.step.condition.StopCondition = None, heading: float = None):
        ...
    def _generate_signature(self) -> str:
        ...
    def on_start(self, robot: GenericRobot) -> None:
        ...
    def on_update(self, robot: GenericRobot, dt: float) -> bool:
        ...
def _drive_forward_uncalibrated(cm: float, speed: float = 1.0) -> DriveForward:
    """
    Internal: drive forward without calibration check.
    
    Used by ``calibrate_distance()`` to perform the calibration drive
    before calibration data exists.
    """
