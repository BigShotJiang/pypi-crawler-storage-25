"""
Setup-timer control steps.

Lets a :class:`SetupMission` pause and (re)start the setup-phase
countdown that is displayed in the UI.  Useful when you want to start
the program, idle for a bit, and only begin the real setup timer once
you are physically ready.

Outside of a SetupMission — i.e. when there is no active setup-timer —
both steps are no-ops.
"""
from __future__ import annotations
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
import raccoon.step.base
from raccoon.step.base import Step
import typing
__all__: list[str] = ['PauseSetupTimer', 'ResumeSetupTimer', 'StartSetupTimer', 'Step', 'dsl_step']
class PauseSetupTimer(raccoon.step.base.Step):
    """
    Freeze the setup-phase countdown at its current value.
    
    Stops the remaining-time clock displayed at the top of every setup
    UI screen.  Elapsed time really stops advancing — a later
    :func:`start_setup_timer` (or :func:`resume_setup_timer`) picks up
    from where this step left the clock.
    
    No-op when used outside a SetupMission.
    
    Example::
    
        from raccoon.step.setup_timer import pause_setup_timer, start_setup_timer
    
        # As the very first step of the setup sequence: idle until the
        # operator is ready, then kick off the real setup timer.
        sequence(
            pause_setup_timer(),
            wait_for_button(),
            start_setup_timer(),
            calibrate_deadzone(),
            ...
        )
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='PauseSetupTimer', tags=('timing', 'setup'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'PauseSetupTimer'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('timing', 'setup')
    __dsl_tags__: typing.ClassVar[tuple] = ('timing', 'setup')
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class ResumeSetupTimer(raccoon.step.base.Step):
    """
    Resume a paused setup-phase countdown without resetting it.
    
    Unlike :func:`start_setup_timer`, this preserves the elapsed time
    so the countdown continues from wherever it was frozen.
    
    No-op when used outside a SetupMission, or when the timer is
    already running.
    
    Example::
    
        from raccoon.step.setup_timer import pause_setup_timer, resume_setup_timer
    
        sequence(
            pause_setup_timer(),
            wait_for_button(),
            resume_setup_timer(),   # continue from the frozen value
        )
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='ResumeSetupTimer', tags=('timing', 'setup'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'ResumeSetupTimer'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('timing', 'setup')
    __dsl_tags__: typing.ClassVar[tuple] = ('timing', 'setup')
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
class StartSetupTimer(raccoon.step.base.Step):
    """
    Start (or restart) the setup-phase countdown from full duration.
    
    Resets the elapsed time to zero and unpauses the timer, so the
    operator gets the full :attr:`SetupMission.setup_time` from the
    moment this step runs.  Combine with :func:`pause_setup_timer` at
    the top of the setup sequence to defer the countdown until you are
    ready.
    
    No-op when used outside a SetupMission.
    
    Example::
    
        from raccoon.step.setup_timer import pause_setup_timer, start_setup_timer
    
        sequence(
            pause_setup_timer(),
            wait_for_button(),       # idle here — timer stays frozen
            start_setup_timer(),     # full setup_time begins now
            calibrate_deadzone(),
        )
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='StartSetupTimer', tags=('timing', 'setup'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'StartSetupTimer'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('timing', 'setup')
    __dsl_tags__: typing.ClassVar[tuple] = ('timing', 'setup')
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
