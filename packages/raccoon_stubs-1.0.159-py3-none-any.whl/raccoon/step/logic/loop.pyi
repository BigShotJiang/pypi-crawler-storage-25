from __future__ import annotations
import _contextvars
import raccoon.step.annotation
from raccoon.step.annotation import dsl_step
import raccoon.step.base
from raccoon.step.base import Step
import raccoon.step.model
from raccoon.step.model import StepProtocol
import typing
from typing import Any
__all__: list[str] = ['Any', 'LoopFor', 'LoopForever', 'Step', 'StepProtocol', 'dsl_step']
class LoopFor(raccoon.step.base.Step):
    """
    Repeat a step a fixed number of times.
    
    Wraps the given step in a counted loop. Each iteration awaits the
    child step to completion before starting the next. After all
    iterations complete, the step finishes normally.
    
    Args:
        step: The step to execute repeatedly. Must satisfy ``StepProtocol``.
        iterations: Number of times to run the step. Must be a positive
            integer.
    
    Example::
    
        from raccoon.step.logic import loop_for
    
        # Drive forward and back 3 times
        loop_for(seq([drive_forward(20), drive_backward(20)]), iterations=3)
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='LoopFor', tags=('control', 'loop'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'LoopFor'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('control', 'loop')
    __dsl_tags__: typing.ClassVar[tuple] = ('control', 'loop')
    _composite: typing.ClassVar[bool] = True
    def __init__(self, step: raccoon.step.model.StepProtocol, iterations: int):
        ...
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
    def collected_resources(self) -> frozenset[str]:
        ...
class LoopForever(raccoon.step.base.Step):
    """
    Repeat a step indefinitely until externally cancelled.
    
    Wraps the given step in an infinite loop. Each iteration awaits the
    child step to completion before starting the next. The loop only
    terminates when the enclosing context cancels it (e.g. via
    ``do_while_active`` or ``do_until_checkpoint``).
    
    Args:
        step: The step to execute repeatedly. Must satisfy ``StepProtocol``.
    
    Example::
    
        from raccoon.step.logic import loop_forever
        from raccoon.step.timing import do_until_checkpoint
    
        # Continuously toggle a motor on and off until T=30s
        toggle = seq([
            motor_power(robot.motor(0), 100),
            wait(0.5),
            motor_off(robot.motor(0)),
            wait(0.5),
        ])
        do_until_checkpoint(30.0, loop_forever(toggle))
    """
    __dsl__: typing.ClassVar[raccoon.step.annotation.DslMeta]  # value = DslMeta(hidden=True, name='LoopForever', tags=('control', 'loop'))
    __dsl_hidden__: typing.ClassVar[bool] = True
    __dsl_name__: typing.ClassVar[str] = 'LoopForever'
    __dsl_step__: typing.ClassVar[bool] = True
    __dsl_step_tags__: typing.ClassVar[tuple] = ('control', 'loop')
    __dsl_tags__: typing.ClassVar[tuple] = ('control', 'loop')
    _composite: typing.ClassVar[bool] = True
    def __init__(self, step: raccoon.step.model.StepProtocol):
        ...
    def _execute_step(self, robot: GenericRobot) -> None:
        ...
    def _generate_signature(self) -> str:
        ...
    def collected_resources(self) -> frozenset[str]:
        ...
_step_path: _contextvars.ContextVar  # value = <ContextVar name='step_path' default=[] at 0xe3e897016980>
