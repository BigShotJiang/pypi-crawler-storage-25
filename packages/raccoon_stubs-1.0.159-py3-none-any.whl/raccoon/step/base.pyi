from __future__ import annotations
import _contextvars
from abc import abstractmethod
import asyncio as asyncio
import contextvars as contextvars
import raccoon.class_name_logger
from raccoon.class_name_logger import ClassNameLogger
import raccoon.step.model
from raccoon.step.model import SimulationStep
from raccoon.step.model import SimulationStepDelta
from raccoon.step.resource import get_resource_manager
from raccoon.timing.tracker import StepTimingTracker
import time as time
import typing
from typing import Any
__all__: list[str] = ['Any', 'ClassNameLogger', 'SimulationStep', 'SimulationStepDelta', 'Step', 'StepAnomalyCallback', 'StepTimingTracker', 'abstractmethod', 'asyncio', 'contextvars', 'get_resource_manager', 'time']
class Step(raccoon.class_name_logger.ClassNameLogger):
    """
    Base async action executed by missions and higher-level step combinators.
    """
    _composite: typing.ClassVar[bool] = False
    @staticmethod
    def _push_path(segment: str) -> _contextvars.Token[typing.List[str]]:
        ...
    def __init__(self) -> None:
        ...
    def _anomaly_watchdog(self, upper_bound: float, start_time: float, robot: GenericRobot) -> None:
        """
        Sleep until upper_bound elapsed, then fire the anomaly callback.
        
        Runs as a background task alongside ``_execute_step``.  Cancelled
        automatically when the step finishes in time.
        """
    def _execute_step(self, robot: GenericRobot) -> None:
        """
        Actual step logic implemented by subclasses.
        """
    def _generate_signature(self) -> str:
        """
        
        Return the timing/simulation identity for this step instance.
        
        Override in subclasses when constructor parameters materially change
        runtime behavior and should not share the same timing baseline.
        """
    def collected_resources(self) -> frozenset[str]:
        """
        Return all resources this step *and its children* require.
        
        Used by ``validate_no_overlap`` for static conflict detection at
        construction time.  Leaf steps don't need to override this — the
        default delegates to ``required_resources``.  Composite steps
        override to union their children's collected resources.
        """
    def required_resources(self) -> frozenset[str]:
        """
        Return the hardware resources this step requires exclusive access to.
        
        For leaf steps (drive, motor, servo), return the resources this step
        directly uses.  Composite steps override ``collected_resources``
        instead to include children — ``required_resources`` stays empty for
        composites because they don't touch hardware themselves.
        """
    def resolve(self) -> Step:
        """
        Return the concrete Step that should actually execute.
        
        Default returns ``self``. ``StepBuilder`` overrides this to call
        ``_build()`` so that fluent-DSL builders are converted into the
        underlying Step at composite-construction time. Composite steps
        call ``resolve()`` on their children before storing them so that
        ``validate_no_overlap`` and ``collected_resources`` see the real
        resource sets, not empty builder placeholders.
        """
    def run_step(self, robot: GenericRobot) -> None:
        """
        
        Execute the step with logging and optional timing instrumentation.
        
        When a per-step ``_anomaly_callback`` is set and a timing baseline
        exists, a background watchdog fires the callback as soon as the
        elapsed time exceeds the anomaly upper bound — even while the step
        is still running.
        """
    def to_simulation_step(self) -> raccoon.step.model.SimulationStep:
        """
        
        Convert this step to a simulation-friendly summary.
        
        The default implementation uses timing history only when it can query
        the tracker synchronously; otherwise it returns conservative defaults.
        Override in subclasses that know their motion delta or exact duration.
        """
StepAnomalyCallback: typing._CallableGenericAlias  # value = typing.Callable[[ForwardRef('Step'), ForwardRef('GenericRobot')], typing.Awaitable[typing.Any]]
_in_background: _contextvars.ContextVar  # value = <ContextVar name='_in_background' default=False at 0xe3e895ec1fd0>
_step_path: _contextvars.ContextVar  # value = <ContextVar name='step_path' default=[] at 0xe3e897016980>
