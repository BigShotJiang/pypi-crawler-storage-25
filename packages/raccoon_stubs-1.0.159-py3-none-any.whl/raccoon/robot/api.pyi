from __future__ import annotations
import abc
from abc import ABC
from abc import abstractmethod
import asyncio as asyncio
import raccoon.class_name_logger
from raccoon.class_name_logger import ClassNameLogger
from raccoon.foundation import initialize_timer
from raccoon.hal import AnalogSensor
from raccoon.hal import DigitalSensor
import raccoon.motion
from raccoon.motion import UnifiedMotionPidConfig
import raccoon.robot.geometry
from raccoon.robot.geometry import RobotGeometry
from raccoon.robot.service import RobotService
import raccoon.timing.synchronizer
from raccoon.timing.synchronizer import Synchronizer
import typing
from typing import Any
from typing import Protocol
from typing import TypeVar
from typing import runtime_checkable
__all__: list[str] = ['ABC', 'AnalogSensor', 'Any', 'ClassNameLogger', 'DigitalSensor', 'GenericRobot', 'Protocol', 'RobotDefinitionsProtocol', 'RobotGeometry', 'RobotService', 'Synchronizer', 'TypeVar', 'UnifiedMotionPidConfig', 'abstractmethod', 'asyncio', 'initialize_timer', 'runtime_checkable']
class GenericRobot(abc.ABC, raccoon.robot.geometry.RobotGeometry, raccoon.class_name_logger.ClassNameLogger):
    """
    
    Abstract base class for all robots.
    
    Subclasses must implement:
        - defs: Hardware definitions (motors, servos, etc.)
        - drive: Drive system for chassis control
        - odometry: Odometry system for position tracking
    
    Optional attributes:
        - missions: List of missions to execute
        - setup_mission: Mission to run before main missions
        - shutdown_mission: Mission to run after all missions complete
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset({'defs', 'odometry', 'drive', 'shutdown_in'})
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    @staticmethod
    def _get_skip_mission_indices() -> set:
        """
        Return mission order indices to skip, from LIBSTP_SKIP_MISSIONS env var.
        """
    def __init__(self) -> None:
        """
        Initialize the robot and log configuration status.
        """
    def _drain_background_tasks(self) -> None:
        """
        Cancel all remaining background tasks and await their cleanup.
        """
    def _pre_start_gate(self) -> None:
        """
        Wait for light or button press before starting main missions.
        
        Override this method in a subclass to customize pre-start behavior.
        """
    def _preload_missions(self, missions: typing.List[ForwardRef('MissionProtocol')], setup_mission: typing.Optional[ForwardRef('MissionProtocol')], shutdown_mission: typing.Optional[ForwardRef('MissionProtocol')]) -> None:
        """
        Build mission sequences early to validate step construction.
        """
    def _run_main_missions(self, missions: typing.List[ForwardRef('MissionProtocol')]) -> None:
        """
        Execute main missions sequentially with per-mission watchdogs.
        """
    def _run_missions(self) -> None:
        """
        Internal mission execution loop.
        """
    def _warn_leaked_background_tasks(self, mission: MissionProtocol) -> None:
        """
        Warn if background tasks from a mission are still running.
        """
    def _warn_leaked_watchdogs(self, mission: MissionProtocol) -> None:
        """
        Warn if user watchdogs from a mission are still armed at its end.
        """
    def get_service(self, cls: typing.Type[~_S]) -> ~_S:
        """
        Get or create a cached service instance.
        
        Services are lazily instantiated on first access and reused for
        subsequent calls with the same class.
        """
    def start(self) -> None:
        """
        
        Start executing the robot's missions.
        
        Runs setup_mission (if present), then all missions in order,
        then shutdown_mission (if present).
        
        Note: This method blocks until all missions complete.
        For non-blocking execution, use start_async() instead.
        """
    def start_async(self) -> None:
        """
        
        Async version of start() for use in existing event loops.
        
        Useful for testing or integration with other async code.
        """
    @property
    def defs(self) -> RobotDefinitionsProtocol:
        """
        Hardware definitions (motors, servos, sensors).
        """
    @property
    def drive(self) -> Drive:
        """
        Drive system for chassis velocity control.
        """
    @property
    def missions(self) -> typing.List[ForwardRef('MissionProtocol')]:
        """
        List of missions to execute. Override to provide missions.
        """
    @property
    def motion_pid_config(self) -> raccoon.motion.UnifiedMotionPidConfig:
        """
        Unified PID configuration for all motion primitives. Override to customize.
        """
    @property
    def odometry(self) -> Odometry:
        """
        Odometry system for position tracking.
        """
    @property
    def setup_mission(self) -> typing.Optional[ForwardRef('SetupMission')]:
        """
        Optional setup mission to run before main missions.
        
        Must be a ``SetupMission`` instance (not a plain ``Mission``).
        """
    @property
    def shutdown_in(self) -> float:
        """
        Maximum runtime in seconds for main missions. MUST be specified.
        """
    @property
    def shutdown_mission(self) -> typing.Optional[ForwardRef('MissionProtocol')]:
        """
        Optional mission to run after all missions complete.
        """
    @property
    def synchronizer(self) -> raccoon.timing.synchronizer.Synchronizer:
        """
        Synchronizer for coordinating async tasks.
        """
    @property
    def table_map(self) -> typing.Optional[ForwardRef('TableMap')]:
        """
        Table map with field line/wall geometry. ``None`` if not configured.
        """
class RobotDefinitionsProtocol(typing.Protocol):
    """
    
    Protocol defining the structure of robot hardware definitions.
    
    Implementations should define motor and servo attributes as class variables.
    Example:
        class MyDefs:
            left_motor = Motor(port=0, ...)
            right_motor = Motor(port=1, ...)
            arm_servo = Servo(port=0, ...)
    
    Drive motors are accessed via robot.drive.get_motors() instead of defs.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __non_callable_proto_members__: typing.ClassVar[set] = {'wait_for_light_sensor', 'wait_for_light_drop_fraction', 'button', 'analog_sensors', 'wait_for_light_mode'}
    __parameters__: typing.ClassVar[tuple] = tuple()
    __protocol_attrs__: typing.ClassVar[set] = {'wait_for_light_sensor', 'wait_for_light_drop_fraction', 'button', 'analog_sensors', 'wait_for_light_mode'}
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _is_protocol: typing.ClassVar[bool] = True
    _is_runtime_protocol: typing.ClassVar[bool] = True
    @classmethod
    def __subclasshook__(cls, other):
        ...
    def __init__(self, *args, **kwargs):
        ...
_S: typing.TypeVar  # value = ~_S
