"""

UIScreen - Base class for self-contained UI screens.

Each screen handles its own events and state.
The UIStep orchestrates which screens to show.
"""
from __future__ import annotations
import abc
from abc import ABC
from abc import abstractmethod
import raccoon.class_name_logger
from raccoon.class_name_logger import ClassNameLogger
from raccoon.ui.widgets import Widget
import typing
from typing import Any
from typing import Generic
from typing import TypeVar
__all__: list[str] = ['ABC', 'Any', 'ClassNameLogger', 'Generic', 'T', 'TypeVar', 'UIScreen', 'Widget', 'abstractmethod']
class UIScreen(abc.ABC, typing.Generic, raccoon.class_name_logger.ClassNameLogger):
    """
    
    A self-contained screen with its own layout and event handlers.
    
    Subclass this to create reusable screen components. The screen
    runs until close() is called, then returns a result to the Step.
    
    Example:
        class ConfirmScreen(UIScreen[bool]):
            title = "Confirm"
    
            def __init__(self, message: str):
                super().__init__()
                self.message = message
    
            def build(self) -> Widget:
                return Center(children=[
                    Text(self.message, size="large"),
                    Row(children=[
                        Button("no", "Cancel", style="secondary"),
                        Button("yes", "Confirm", style="success"),
                    ]),
                ])
    
            @on_click("yes")
            async def on_yes(self):
                self.close(True)
    
            @on_click("no")
            async def on_no(self):
                self.close(False)
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset({'build'})
    __orig_bases__: typing.ClassVar[tuple]  # value = (abc.ABC, typing.Generic[~T], raccoon.class_name_logger.ClassNameLogger)
    __parameters__: typing.ClassVar[tuple]  # value = (~T)
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _primary_button_id = None
    title: typing.ClassVar[str] = 'Screen'
    def __init__(self):
        ...
    def _dispatch_event(self, event: dict) -> None:
        """
        Dispatch an event to the appropriate handler.
        """
    def _to_dict(self, setup_timer: dict | None = None) -> dict:
        """
        Serialize screen to JSON for LCM.
        
        Args:
            setup_timer: Pre-built ``{"seconds": N, "paused": bool}`` dict
                computed by ``UIStep._render_screen`` from the active
                ``_SetupTimerState``.  ``None`` means no timer is shown.
        """
    def build(self) -> Widget:
        """
        
        Build the screen layout.
        
        Called on every render. Return a Widget tree describing
        what to display.
        """
    def close(self, result: T = None) -> None:
        """
        
        Close this screen and return to the Step.
        
        Args:
            result: The value to return to the Step. Type should match
                   the Generic type parameter.
        """
    def get_value(self, widget_id: str, default: typing.Any = None) -> typing.Any:
        """
        
        Get the current value of an input widget.
        
        Args:
            widget_id: The ID of the input widget
            default: Value to return if widget not found
        
        Returns:
            The current value of the widget
        """
    def read_sensor(self, port: int, sensor_type: str = 'analog') -> float:
        """
        
        Read a sensor value.
        
        Args:
            port: The sensor port number
            sensor_type: "analog" or "digital"
        
        Returns:
            The sensor reading
        """
    def refresh(self) -> None:
        """
        
        Re-render this screen.
        
        Call this after changing state that affects the UI.
        """
    def set_value(self, widget_id: str, value: typing.Any) -> None:
        """
        
        Set the value of an input widget.
        
        Args:
            widget_id: The ID of the input widget
            value: The new value
        """
    @property
    def is_closed(self) -> bool:
        """
        Check if screen is closed.
        """
    @property
    def robot(self):
        """
        Access the robot instance.
        """
T: typing.TypeVar  # value = ~T
