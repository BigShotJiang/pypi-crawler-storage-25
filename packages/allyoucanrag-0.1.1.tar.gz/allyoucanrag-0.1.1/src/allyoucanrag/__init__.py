"""allyoucanrag package."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .config import AppConfig, ConfigStatus, apply_api_keys, get_config_status, load_app_config, save_app_config
from .paths import RuntimePaths, resolve_path, resolve_runtime_paths

if TYPE_CHECKING:
	from .document_manager import DocumentManager
	from .rag_system import DualVectorStoreRAG

__all__ = [
	"__author__",
	"__author_email__",
	"__title__",
	"__version__",
	"AppConfig",
	"ConfigStatus",
	"DocumentManager",
	"DualVectorStoreRAG",
	"RuntimePaths",
	"apply_api_keys",
	"get_config_status",
	"load_app_config",
	"resolve_path",
	"resolve_runtime_paths",
	"save_app_config",
]

__title__ = "allyoucanRAG"
__author__ = "Yibo Qiao"
__author_email__ = "qiaoy33@mcmaster.ca"
__version__ = "0.1.1"


def __getattr__(name: str) -> Any:
	if name == "DocumentManager":
		from .document_manager import DocumentManager

		return DocumentManager
	if name == "DualVectorStoreRAG":
		from .rag_system import DualVectorStoreRAG

		return DualVectorStoreRAG
	raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

