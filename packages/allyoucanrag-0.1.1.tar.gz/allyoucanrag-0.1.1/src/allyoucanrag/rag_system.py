"""RAG 系统核心模块。"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import List, Optional, Tuple

from langchain_chroma import Chroma
from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    UnstructuredFileLoader,
    UnstructuredPDFLoader,
)
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

from .paths import PathLike, RuntimePaths, resolve_path, resolve_runtime_paths
from .utils import SUPPORTED_DOCUMENT_EXTENSIONS

logger = logging.getLogger(__name__)
logger.addHandler(logging.NullHandler())

# Some course PDFs are structurally imperfect. PyPDF logs a large number of
# non-fatal parser warnings for these files, which would otherwise flood the
# Streamlit console during indexing.
logging.getLogger("pypdf").setLevel(logging.ERROR)


def _load_documents_for_path(file_path: str) -> Tuple[List[Document], str]:
    """Load one supported document file into LangChain documents."""
    file_extension = Path(file_path).suffix.lower()

    if file_extension == ".pdf":
        try:
            return PyPDFLoader(file_path).load(), "PyPDFLoader"
        except Exception:
            return UnstructuredPDFLoader(file_path).load(), "UnstructuredPDFLoader"

    if file_extension in {".txt", ".md"}:
        return TextLoader(file_path, autodetect_encoding=True).load(), "TextLoader"

    if file_extension in {".doc", ".docx", ".rtf"}:
        return UnstructuredFileLoader(file_path, mode="single").load(), "UnstructuredFileLoader"

    raise ValueError(f"Unsupported document format: {file_extension}")


def loadAndIndexFiles(
    file_paths: List[str | Path],
    chunk_size: int = 1000,
    chunk_overlap: int = 200,
    source_type: str = "base",
    additional_metadata: Optional[dict] = None,
) -> Tuple[List[Document], int]:
    """
    通用文档加载和索引函数

    用于加载支持的文本文档、分割文本并返回文档片段
    这个函数被基础向量库和用户向量库共同使用

    Args:
        file_paths: PDF 文件路径列表
        chunk_size: 文本块大小
        chunk_overlap: 文本块重叠大小
        source_type: 文档来源类型 ("base" 或 "user")
        additional_metadata: 额外的元数据（用于用户上传文档）

    Returns:
        (文档片段列表, 原始文档数量)
    """
    all_docs = []

    for file_path in file_paths:
        file_path = str(file_path)
        loader_used = "PyPDFLoader/UnstructuredPDFLoader"
        try:
            docs, loader_used = _load_documents_for_path(file_path)

            for doc in docs:
                doc.metadata["source_type"] = source_type
                if additional_metadata:
                    doc.metadata.update(additional_metadata)

            all_docs.extend(docs)

        except Exception as error:
            logger.error("%s failed to load %s: %s", loader_used, file_path, error)
            continue

    if not all_docs:
        return [], 0

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
    )
    splits = text_splitter.split_documents(all_docs)

    return splits, len(all_docs)


class DualVectorStoreRAG:
    """双向量库 RAG 系统"""

    def __init__(
        self,
        base_persist_dir: PathLike | None = None,
        user_persist_dir: PathLike | None = None,
        base_docs_dir: PathLike | None = None,
        runtime_paths: RuntimePaths | None = None,
        embedding_batch_size: int = 32,
        embedding_request_timeout: float = 120.0,
        embedding_max_retries: int = 6,
        vectorstore_batch_size: int = 8,
    ):
        """
        初始化双向量库 RAG 系统

        Args:
            base_persist_dir: 基础向量库持久化目录
            user_persist_dir: 用户向量库持久化目录
            base_docs_dir: 基础文档目录
            embedding_batch_size: 单次 embedding 请求的文本批大小
            embedding_request_timeout: 单次 embedding 请求超时时间（秒）
            embedding_max_retries: embedding 请求最大重试次数
            vectorstore_batch_size: 单次写入向量库的文档切片数
        """
        resolved_paths = runtime_paths or resolve_runtime_paths(base_docs_dir=base_docs_dir)

        self.runtime_paths = resolved_paths
        self.base_persist_dir = resolve_path(base_persist_dir, resolved_paths.base_dir) or resolved_paths.base_vector_dir
        self.user_persist_dir = resolve_path(user_persist_dir, resolved_paths.base_dir) or resolved_paths.user_vector_dir
        self.base_docs_dir = resolve_path(base_docs_dir, resolved_paths.base_dir) or resolved_paths.base_docs_dir

        self.base_persist_dir.mkdir(parents=True, exist_ok=True)
        self.user_persist_dir.mkdir(parents=True, exist_ok=True)

        self.embedding_function = OpenAIEmbeddings(
            chunk_size=embedding_batch_size,
            request_timeout=embedding_request_timeout,
            max_retries=embedding_max_retries,
        )
        self.vectorstore_batch_size = max(1, vectorstore_batch_size)

        self.base_vectorstore = None
        self.user_vectorstore = None
        self.base_doc_count = 0

    def _add_documents_in_batches(self, vectorstore: Chroma, documents: List[Document]) -> None:
        """Add documents to a vector store in small batches to reduce embedding timeouts."""
        total_documents = len(documents)

        for start_index in range(0, total_documents, self.vectorstore_batch_size):
            end_index = min(start_index + self.vectorstore_batch_size, total_documents)
            batch = documents[start_index:end_index]
            logger.info(
                "Adding vector batch %s-%s of %s",
                start_index + 1,
                end_index,
                total_documents,
            )
            vectorstore.add_documents(batch)

    def initialize_base_vectorstore(self) -> int:
        """
        初始化或加载基础向量库

        Returns:
            加载的文档数量
        """
        if self.base_persist_dir.exists() and any(self.base_persist_dir.iterdir()):
            try:
                self.base_vectorstore = Chroma(
                    persist_directory=str(self.base_persist_dir),
                    embedding_function=self.embedding_function,
                )
                try:
                    collection = self.base_vectorstore._collection
                    self.base_doc_count = collection.count()
                except Exception:
                    self.base_doc_count = 0

                return self.base_doc_count
            except Exception as error:
                logger.warning("Failed to load base vector store from %s, recreating: %s", self.base_persist_dir, error)

        if not self.base_docs_dir.exists():
            logger.warning("Base documents directory does not exist: %s", self.base_docs_dir)
            return 0

        supported_files = []
        for root, _, files in os.walk(self.base_docs_dir):
            for file_name in files:
                if Path(file_name).suffix.lower() in SUPPORTED_DOCUMENT_EXTENSIONS:
                    supported_files.append(os.path.join(root, file_name))

        if not supported_files:
            logger.warning("No supported text documents found in %s", self.base_docs_dir)
            return 0

        splits, doc_count = loadAndIndexFiles(
            file_paths=supported_files,
            source_type="base",
        )

        if not splits:
            logger.error("Failed to load any base documents from %s", self.base_docs_dir)
            return 0

        self.base_vectorstore = Chroma(
            persist_directory=str(self.base_persist_dir),
            embedding_function=self.embedding_function,
        )
        self._add_documents_in_batches(self.base_vectorstore, splits)

        self.base_doc_count = doc_count
        return doc_count

    def initialize_user_vectorstore(self):
        """Initialize or load the user vector store"""
        self.user_vectorstore = Chroma(
            persist_directory=str(self.user_persist_dir),
            embedding_function=self.embedding_function,
        )

    def add_user_document(
        self,
        file_path: str,
        original_filename: str,
        upload_time: str,
        file_size: int,
    ) -> Tuple[bool, str, int]:
        """
        Add a user-uploaded document to the user vector store

        Args:
            file_path: File path
            original_filename: Original file name
            upload_time: Upload time
            file_size: File size

        Returns:
            (success, message, number of added text chunks)
        """
        try:
            additional_metadata = {
                "original_filename": original_filename,
                "upload_time": upload_time,
                "file_size": file_size,
            }

            splits, _ = loadAndIndexFiles(
                file_paths=[file_path],
                source_type="user",
                additional_metadata=additional_metadata,
            )

            if not splits:
                return False, "❌ Document processing failed: no content extracted", 0

            if self.user_vectorstore is None:
                self.initialize_user_vectorstore()

            self._add_documents_in_batches(self.user_vectorstore, splits)

            return True, f"✅ Successfully indexed document, added {len(splits)} text chunks", len(splits)

        except Exception as error:
            return False, f"❌ Error indexing document: {str(error)}", 0

    def remove_user_document(self, original_filename: str) -> Tuple[bool, str]:
        """
        Remove a document from the user vector store

        Args:
            original_filename: Original file name

        Returns:
            (success, message)
        """
        try:
            if self.user_vectorstore is None:
                return True, "User vector store is empty"

            collection = self.user_vectorstore._collection
            results = collection.get(where={"original_filename": original_filename})

            if results and "ids" in results and results["ids"]:
                collection.delete(ids=results["ids"])
                return True, f"✅ Successfully deleted {len(results['ids'])} text chunks from the vector store"
            return True, "No relevant content found in the vector store"

        except Exception as error:
            return False, f"⚠️ Error deleting from vector store: {str(error)}"

    def create_rag_chain(self, k: int = 3):
        """
        Create RAG retrieval chain

        Args:
            k: Number of documents to retrieve

        Returns:
            RAG chain
        """

        def hybrid_retrieve(query: str) -> List[Document]:
            """Retrieve relevant documents from both vector stores"""
            all_docs = []

            if self.base_vectorstore:
                try:
                    base_docs = self.base_vectorstore.similarity_search(query, k=k)
                    all_docs.extend(base_docs)
                except Exception as error:
                    logger.warning("Base vector store retrieval failed: %s", error)

            if self.user_vectorstore:
                try:
                    collection = self.user_vectorstore._collection
                    if collection.count() > 0:
                        user_docs = self.user_vectorstore.similarity_search(query, k=10)
                        all_docs.extend(user_docs)
                except Exception:
                    pass

            return all_docs[: k + 10]

        def format_docs_with_source(docs: List[Document]) -> str:
            """Format documents and mark source"""
            parts = []
            for index, doc in enumerate(docs, 1):
                src = doc.metadata.get("source", "unknown_source")
                src_type = doc.metadata.get("source_type", "base")
                page = doc.metadata.get("page_label", doc.metadata.get("page", "unknown_page"))

                if src_type == "user":
                    emoji = "📄"
                    original_name = doc.metadata.get("original_filename", "Unknown")
                    upload_time = doc.metadata.get("upload_time", "Unknown")
                    header = f"{emoji} [{index}] User Document: {original_name} (Uploaded on {upload_time}, p.{page})"
                else:
                    emoji = "📘"
                    header = f"{emoji} [{index}] Course Material: {os.path.basename(src)}, p.{page}"

                text = (doc.page_content or "").strip()
                parts.append(f"{header}\n{text}")

            return "\n\n".join(parts)

        prompt_template = """You are a helpful assistant.
            Answer the question using ONLY the Context below.
            If the answer is not in the Context, say \"I don't know based on the provided context.\"

            Context:
            {context}

            Question:
            {question}
            """
        prompt = ChatPromptTemplate.from_template(prompt_template)
        llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0)

        rag_chain = (
            {
                "context": RunnableLambda(hybrid_retrieve) | RunnableLambda(format_docs_with_source),
                "question": RunnablePassthrough(),
            }
            | prompt
            | llm
        )

        return rag_chain