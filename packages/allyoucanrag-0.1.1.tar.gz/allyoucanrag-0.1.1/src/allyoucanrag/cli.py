"""Interactive CLI entrypoint for allyoucanRAG."""

from __future__ import annotations

import argparse
import getpass
from pathlib import Path
from typing import Sequence

from . import __author__, __author_email__, __title__, __version__
from .config import ConfigurationError, apply_api_keys, get_config_status, load_app_config, save_app_config
from .document_manager import DocumentManager
from .paths import resolve_runtime_paths
from .rag_system import DualVectorStoreRAG
from .utils import SUPPORTED_DOCUMENT_EXTENSIONS, safe_remove_file


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="allyoucanrag", description="Interactive CLI for allyoucanRAG.")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("start", help="Start the interactive allyoucanRAG CLI.")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    if args.command == "start":
        return run_cli()

    parser.print_help()
    return 0


def run_cli() -> int:
    runtime_paths = resolve_runtime_paths()
    state: dict[str, object] = {
        "rag_system": None,
        "doc_manager": None,
        "base_ready": False,
    }

    _print_banner(runtime_paths.base_dir)

    while True:
        status = get_config_status(config_path=runtime_paths.config_path)
        _print_menu(status, runtime_paths.config_path)
        choice = input("Select an option [1-3] or q to quit: ").strip().lower()

        if choice == "q":
            print("Exiting allyoucanRAG.")
            return 0

        if choice == "1":
            _handle_update_api_keys(runtime_paths.config_path)
            state["rag_system"] = None
            state["base_ready"] = False
            continue

        if choice in {"2", "3"} and not status.ready_for_cli:
            print("\nOptions 2 and 3 are unavailable until both OpenAI and LangChain API keys are configured.\n")
            continue

        if choice == "2":
            _handle_upload_documents(state)
            continue

        if choice == "3":
            _handle_question(state)
            continue

        print("\nInvalid choice. Please select 1, 2, 3, or q.\n")


def _print_banner(base_dir: Path) -> None:
    print()
    print(f"{__title__} v{__version__}")
    print(f"Author: {__author__}")
    print(f"Author email: {__author_email__}")
    print(f"Runtime base: {base_dir}")
    print("-" * 60)


def _print_menu(status, config_path: Path) -> None:
    print()
    print("Available actions")
    print("1. Update API key")

    availability_note = "" if status.ready_for_cli else " [Unavailable until both API keys are set]"
    print(f"2. Upload document{availability_note}")
    print(f"3. Ask the knowledge base{availability_note}")
    print("q. Quit")
    print()
    print(f"Config file: {config_path}")
    print(f"OpenAI key configured: {'yes' if status.openai_api_key_configured else 'no'}")
    print(f"LangChain key configured: {'yes' if status.langchain_api_key_configured else 'no'}")
    if status.source:
        print(f"Current config source: {status.source}")
    print()


def _handle_update_api_keys(config_path: Path) -> None:
    print()
    print("Update API keys")
    print("Press Enter to keep an existing value if one is already configured.")

    existing_config = None
    try:
        existing_config = load_app_config(config_path=config_path)
    except ConfigurationError:
        existing_config = None

    openai_prompt = "OpenAI API key"
    if existing_config and existing_config.openai_api_key:
        openai_prompt += " [configured]"

    langchain_prompt = "LangChain API key"
    if existing_config and existing_config.langchain_api_key:
        langchain_prompt += " [configured]"

    openai_input = getpass.getpass(f"{openai_prompt}: ").strip()
    langchain_input = getpass.getpass(f"{langchain_prompt}: ").strip()

    resolved_openai = openai_input or (existing_config.openai_api_key if existing_config else "")
    resolved_langchain = langchain_input or (existing_config.langchain_api_key if existing_config and existing_config.langchain_api_key else "")

    try:
        saved_config_path = save_app_config(
            openai_api_key=resolved_openai,
            langchain_api_key=resolved_langchain,
            config_path=config_path,
        )
    except ConfigurationError as error:
        print(f"\n{error}\n")
        return

    print(f"\nAPI keys updated in {saved_config_path}.\n")


def _handle_upload_documents(state: dict[str, object]) -> None:
    selected_files = _select_files()
    if not selected_files:
        print("\nNo files selected.\n")
        return

    rag_system = _ensure_rag_system(state, initialize_base=False)
    doc_manager = _ensure_document_manager(state)

    for file_path in selected_files:
        print()
        print(f"Uploading {file_path.name}...")
        success, message, metadata = doc_manager.upload_file_path(file_path)
        print(message)
        if not success or metadata is None:
            continue

        print("Indexing document...")
        index_success, index_message, _ = rag_system.add_user_document(
            file_path=metadata["filepath"],
            original_filename=metadata["original_filename"],
            upload_time=metadata["upload_time"],
            file_size=metadata["size"],
        )
        print(index_message)
        if not index_success:
            safe_remove_file(metadata["filepath"])
            continue

        save_success, save_error = doc_manager.save_document_metadata(metadata)
        if not save_success:
            print(f"Failed to save metadata: {save_error}")
            continue

        print(f"Document ready: {metadata['original_filename']}")

    print()


def _handle_question(state: dict[str, object]) -> None:
    rag_system = _ensure_rag_system(state, initialize_base=True)
    question = input("\nEnter your question: ").strip()
    if not question:
        print("\nQuestion cannot be empty.\n")
        return

    print("\nSearching knowledge base and generating answer...")
    rag_chain = rag_system.create_rag_chain()
    result = rag_chain.invoke(question)
    answer = getattr(result, "content", str(result))
    print()
    print("Answer")
    print("-" * 60)
    print(answer)
    print("-" * 60)
    print()


def _ensure_rag_system(state: dict[str, object], *, initialize_base: bool) -> DualVectorStoreRAG:
    rag_system = state.get("rag_system")
    if isinstance(rag_system, DualVectorStoreRAG):
        if initialize_base and not bool(state.get("base_ready")):
            rag_system.initialize_base_vectorstore()
            state["base_ready"] = True
        return rag_system

    config = load_app_config()
    apply_api_keys(config)

    rag_system = DualVectorStoreRAG()
    rag_system.initialize_user_vectorstore()
    if initialize_base:
        rag_system.initialize_base_vectorstore()
        state["base_ready"] = True
    else:
        state["base_ready"] = False

    state["rag_system"] = rag_system
    return rag_system


def _ensure_document_manager(state: dict[str, object]) -> DocumentManager:
    doc_manager = state.get("doc_manager")
    if isinstance(doc_manager, DocumentManager):
        return doc_manager

    doc_manager = DocumentManager()
    state["doc_manager"] = doc_manager
    return doc_manager


def _select_files() -> list[Path]:
    file_type_pattern = " ".join(f"*{extension}" for extension in SUPPORTED_DOCUMENT_EXTENSIONS)

    try:
        from tkinter import Tk, filedialog

        root = Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected = filedialog.askopenfilenames(
            title="Select documents for allyoucanRAG",
            filetypes=[
                ("Supported documents", file_type_pattern),
                ("All files", "*.*"),
            ],
        )
        root.destroy()
        return [Path(item) for item in selected]
    except Exception:
        manual_input = input(
            "File chooser unavailable. Enter one or more file paths separated by commas: "
        ).strip()
        if not manual_input:
            return []
        return [Path(item.strip().strip('"')) for item in manual_input.split(",") if item.strip()]