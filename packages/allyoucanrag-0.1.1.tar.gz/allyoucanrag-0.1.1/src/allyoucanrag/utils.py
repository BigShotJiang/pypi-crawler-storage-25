"""工具函数模块。"""

import hashlib
import logging
import os
from pathlib import Path
from datetime import datetime
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

SUPPORTED_DOCUMENT_EXTENSIONS = (".pdf", ".txt", ".md", ".doc", ".docx", ".rtf")


def generate_unique_filename(original_filename: str) -> str:
    """
    生成唯一的文件名，避免冲突

    策略：timestamp_hash_original_name.ext

    Args:
        original_filename: 原始文件名

    Returns:
        唯一的文件名
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name_hash = hashlib.md5(original_filename.encode()).hexdigest()[:8]

    name, ext = os.path.splitext(original_filename)
    safe_name = "".join(c for c in name if c.isalnum() or c in ("_", "-"))[:50]

    return f"{timestamp}_{name_hash}_{safe_name}{ext}"


def calculate_file_hash(file_content: bytes) -> str:
    """
    计算文件内容的 SHA256 哈希值，用于去重

    Args:
        file_content: 文件内容（字节）

    Returns:
        SHA256 哈希值（十六进制字符串）
    """
    return hashlib.sha256(file_content).hexdigest()


def validate_pdf_file(uploaded_file, max_size_mb: int = 50) -> Tuple[bool, Optional[str]]:
    """
    验证上传的 PDF 文件

    Args:
        uploaded_file: Streamlit UploadedFile 对象
        max_size_mb: 最大文件大小（MB）

    Returns:
        (是否有效, 错误信息)
    """
    if uploaded_file.type != "application/pdf":
        return False, "❌ Invalid file format! Please upload a PDF file."

    file_size_mb = uploaded_file.size / (1024 * 1024)
    if file_size_mb > max_size_mb:
        return False, f"❌ File too large! File size is {file_size_mb:.2f}MB, maximum allowed is {max_size_mb}MB."

    if not uploaded_file.name:
        return False, "❌ Invalid file name!"

    try:
        file_content = uploaded_file.getvalue()
        if not file_content.startswith(b"%PDF"):
            return False, "❌ Invalid file content! This is not a valid PDF file."
    except Exception as error:
        return False, f"❌ Unable to read file content: {str(error)}"

    return True, None


def validate_document_path(filepath: str | Path, max_size_mb: int = 50) -> Tuple[bool, Optional[str]]:
    """Validate a local document path for CLI-based ingestion."""
    path = Path(filepath)

    if not path.exists() or not path.is_file():
        return False, "❌ File does not exist."

    if path.suffix.lower() not in SUPPORTED_DOCUMENT_EXTENSIONS:
        supported = ", ".join(SUPPORTED_DOCUMENT_EXTENSIONS)
        return False, f"❌ Unsupported file format. Supported formats: {supported}"

    file_size_mb = path.stat().st_size / (1024 * 1024)
    if file_size_mb > max_size_mb:
        return False, f"❌ File too large! File size is {file_size_mb:.2f}MB, maximum allowed is {max_size_mb}MB."

    if path.suffix.lower() == ".pdf":
        try:
            with path.open("rb") as file_obj:
                if not file_obj.read(4).startswith(b"%PDF"):
                    return False, "❌ Invalid file content! This is not a valid PDF file."
        except Exception as error:
            return False, f"❌ Unable to read file content: {str(error)}"

    return True, None


def format_file_size(size_bytes: int) -> str:
    """
    Format file size to a human-readable format

    Args:
        size_bytes: File size in bytes

    Returns:
        Formatted string (e.g., "1.23 MB")
    """
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} TB"


def get_directory_size(directory: str | Path) -> int:
    """
    Calculate the total size of a directory

    Args:
        directory: Directory path

    Returns:
        Directory size in bytes
    """
    total_size = 0
    try:
        for dirpath, _, filenames in os.walk(directory):
            for filename in filenames:
                filepath = os.path.join(dirpath, filename)
                if os.path.exists(filepath):
                    total_size += os.path.getsize(filepath)
    except Exception as error:
        logger.warning("Unable to calculate directory size for %s: %s", directory, error)
    return total_size


def safe_remove_file(filepath: str | Path) -> Tuple[bool, Optional[str]]:
    """
    Safely remove a file

    Args:
        filepath: File path

    Returns:
        (Success, Error message)
    """
    try:
        path = Path(filepath)
        if path.exists():
            path.unlink()
            return True, None
        return False, "File does not exist"
    except Exception as error:
        return False, f"Failed to delete file: {str(error)}"
