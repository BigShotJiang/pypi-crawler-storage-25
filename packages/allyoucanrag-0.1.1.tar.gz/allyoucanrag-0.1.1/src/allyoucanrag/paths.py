"""Runtime path helpers for the MAC Academy QA System package."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

PathLike = str | os.PathLike[str]


def resolve_path(path_value: PathLike | None, base_dir: Path) -> Path | None:
    """Resolve an optional path against a base directory."""
    if path_value is None:
        return None

    path = Path(path_value)
    if path.is_absolute():
        return path.resolve()
    return (base_dir / path).resolve()


@dataclass(frozen=True)
class RuntimePaths:
    """Resolved runtime directories and files."""

    base_dir: Path
    config_path: Path
    upload_dir: Path
    metadata_file: Path
    chroma_dir: Path
    base_vector_dir: Path
    user_vector_dir: Path
    base_docs_dir: Path


def resolve_runtime_paths(
    base_dir: PathLike | None = None,
    *,
    config_file_name: str = "config.json",
    upload_dir: PathLike | None = None,
    metadata_file_name: str = "document_metadata.json",
    chroma_dir: PathLike | None = None,
    base_docs_dir: PathLike | None = None,
) -> RuntimePaths:
    """Build the package runtime path set from a configurable base directory."""
    resolved_base_dir = Path(base_dir or os.getenv("MAC_ACADEMY_QA_HOME") or Path.cwd()).resolve()
    resolved_upload_dir = resolve_path(upload_dir or "UserUploads", resolved_base_dir)
    resolved_chroma_dir = resolve_path(chroma_dir or "chroma_db", resolved_base_dir)
    resolved_base_docs_dir = resolve_path(base_docs_dir or "CourseMaterials", resolved_base_dir)
    resolved_config_path = resolve_path(config_file_name, resolved_base_dir)

    return RuntimePaths(
        base_dir=resolved_base_dir,
        config_path=resolved_config_path,
        upload_dir=resolved_upload_dir,
        metadata_file=resolved_upload_dir / metadata_file_name,
        chroma_dir=resolved_chroma_dir,
        base_vector_dir=resolved_chroma_dir / "base",
        user_vector_dir=resolved_chroma_dir / "user",
        base_docs_dir=resolved_base_docs_dir,
    )
