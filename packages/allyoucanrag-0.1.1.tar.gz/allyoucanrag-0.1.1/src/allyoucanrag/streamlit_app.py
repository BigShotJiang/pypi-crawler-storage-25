"""Packaged Streamlit application entrypoint."""

from __future__ import annotations

from datetime import datetime

import streamlit as st

from .batch_upload_helper import (
    generate_batch_id,
    get_batch_progress,
    get_batch_summary,
    get_failed_files,
    get_file_key,
    initialize_batch_state,
    should_process_file,
    update_file_status,
)
from .config import apply_api_keys, load_app_config
from .document_manager import DocumentManager
from .exceptions import ConfigurationError
from .paths import RuntimePaths, resolve_runtime_paths
from .rag_system import DualVectorStoreRAG
from .utils import format_file_size, get_directory_size, safe_remove_file


def _get_streamlit_secrets() -> dict[str, object]:
    """Return Streamlit secrets when configured, otherwise fall back to an empty mapping."""
    try:
        return dict(st.secrets)
    except Exception:
        return {}


def load_config(runtime_paths: RuntimePaths) -> dict[str, object]:
    """Load and apply app configuration."""
    config = load_app_config(
        config_path=runtime_paths.config_path,
        secrets=_get_streamlit_secrets(),
    )
    apply_api_keys(config)
    return {
        "source": config.source,
        "langsmith_enabled": config.langsmith_enabled,
    }


@st.cache_resource
def initialize_rag_system(runtime_paths: RuntimePaths):
    """Initialize the dual vector store RAG system (base store cached)."""
    rag = DualVectorStoreRAG(
        base_persist_dir=runtime_paths.base_vector_dir,
        user_persist_dir=runtime_paths.user_vector_dir,
        base_docs_dir=runtime_paths.base_docs_dir,
        runtime_paths=runtime_paths,
    )

    with st.spinner("📚 Initializing base knowledge store..."):
        base_doc_count = rag.initialize_base_vectorstore()

    rag.initialize_user_vectorstore()

    return rag, base_doc_count


def get_document_manager(runtime_paths: RuntimePaths):
    """Get the document manager instance."""
    if "doc_manager" not in st.session_state:
        st.session_state.doc_manager = DocumentManager(runtime_paths=runtime_paths)
    return st.session_state.doc_manager


def main():
    """Run the packaged Streamlit application."""
    st.set_page_config(
        page_title="MAC-AcademicQA",
        page_icon="🎓",
        layout="wide",
        initial_sidebar_state="expanded",
    )

    runtime_paths = resolve_runtime_paths()

    st.title("📑 McMaster Academic Knowledge QA System V1.0")
    st.markdown("Based on default and user uploaded course materials and RAG. \n First launch may cause a few minutes.")

    try:
        config = load_config(runtime_paths)

        rag_system, base_doc_count = initialize_rag_system(runtime_paths)
        st.success(f"✌️ System All Set!  {base_doc_count} default docs loaded!")

        doc_manager = get_document_manager(runtime_paths)

        if "qa_history" not in st.session_state:
            st.session_state.qa_history = []
        if "show_doc_manager" not in st.session_state:
            st.session_state.show_doc_manager = False

        st.markdown("---")
        st.markdown("### 🛜 Upload Your Documents Here")

        col1, col2 = st.columns([3, 1])

        with col1:
            uploaded_files = st.file_uploader(
                "Upload your PDF files to library (batch uploading available)",
                type=["pdf"],
                accept_multiple_files=True,
                help="PDF files only, allowed to select multiple files with a 50 MB size limit for each one.",
                key="pdf_uploader",
            )

        with col2:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("Manage Uploaded Docs", use_container_width=True):
                st.session_state.show_doc_manager = not st.session_state.show_doc_manager

        if uploaded_files is not None and len(uploaded_files) > 0:
            current_batch_id = generate_batch_id(uploaded_files)

            if "batch_upload_state" not in st.session_state:
                st.session_state.batch_upload_state = None

            if (
                st.session_state.batch_upload_state is None
                or st.session_state.batch_upload_state["batch_id"] != current_batch_id
            ):
                st.session_state.batch_upload_state = initialize_batch_state(uploaded_files, current_batch_id)

            batch_state = st.session_state.batch_upload_state

            if len(uploaded_files) > 1:
                st.info(f"📦 {len(uploaded_files)} files selected")

            progress = get_batch_progress(batch_state)
            if progress > 0:
                st.progress(progress, text=get_batch_summary(batch_state))

            files_to_process = []
            for file in uploaded_files:
                file_key = get_file_key(file)
                if should_process_file(batch_state, file_key):
                    files_to_process.append((file, file_key))

            if files_to_process:
                for file, file_key in files_to_process:
                    file_info = batch_state["files"][file_key]

                    update_file_status(batch_state, file_key, "processing")

                    with st.status(f"📥 Processing: {file_info['filename']}", expanded=True) as status:
                        try:
                            st.write("Validating file format and size...")
                            success, message, metadata = doc_manager.upload_document(file)

                            if not success:
                                status.update(label=f"❌ {file_info['filename']} Upload Failed", state="error")
                                update_file_status(batch_state, file_key, "failed", error=message)
                                st.error(f"❌ {message}")
                                continue

                            st.write("✅ File saved successfully")

                            st.write("🔢 Vectorizing document...")
                            index_success, index_message, _ = rag_system.add_user_document(
                                file_path=metadata["filepath"],
                                original_filename=metadata["original_filename"],
                                upload_time=metadata["upload_time"],
                                file_size=metadata["size"],
                            )

                            if not index_success:
                                status.update(label=f"❌ {file_info['filename']} Indexing Failed", state="error")
                                st.error(index_message)
                                st.warning("Cleaning up saved file...")

                                file_success, _ = safe_remove_file(metadata["filepath"])
                                if file_success:
                                    st.info("✅ Failed upload cleaned up")

                                update_file_status(batch_state, file_key, "failed", error=index_message)
                                continue

                            save_success, save_error = doc_manager.save_document_metadata(metadata)

                            if not save_success:
                                status.update(label=f"⚠️ {file_info['filename']} Metadata Save Failed", state="error")
                                st.error(f"❌ {save_error}")
                                st.warning("Document indexed but metadata not saved, may cause duplicate upload detection failure")
                                update_file_status(batch_state, file_key, "failed", error=save_error)
                                continue

                            status.update(label=f"✅ {file_info['filename']} Processing Complete", state="complete")
                            st.success(f"🎉 {metadata['original_filename']} successfully added to the knowledge base!")
                            st.info(index_message)

                            update_file_status(batch_state, file_key, "success")

                        except Exception as error:
                            status.update(label=f"❌ {file_info['filename']} Processing Error", state="error")
                            error_msg = f"Error occurred while processing the file: {str(error)}"
                            st.error(error_msg)
                            update_file_status(batch_state, file_key, "failed", error=error_msg)

                    if batch_state["completed_files"] < batch_state["total_files"]:
                        st.rerun()

            if batch_state["overall_status"] == "completed":
                st.markdown("---")

                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("✅ Succeeded!", batch_state["success_count"])
                with col2:
                    st.metric("❌ Failed", batch_state["failed_count"])
                with col3:
                    st.metric("📊 Total", batch_state["total_files"])

                if batch_state["failed_count"] > 0:
                    with st.expander("View Failed Files", expanded=False):
                        for failed_key, failed_info in batch_state["files"].items():
                            if failed_info["status"] == "failed":
                                st.error(f"**{failed_info['filename']}**: {failed_info['error']}")

                    if st.button("🔄 Retry Failed Files"):
                        failed_keys = get_failed_files(batch_state)
                        for failed_key in failed_keys:
                            batch_state["files"][failed_key]["status"] = "pending"
                            batch_state["files"][failed_key]["error"] = None

                        batch_state["overall_status"] = "processing"
                        batch_state["failed_count"] = 0
                        batch_state["completed_files"] -= len(failed_keys)
                        st.rerun()

                if batch_state["success_count"] > 0:
                    st.success(f"🎊 Batch upload completed! Successfully processed {batch_state['success_count']} files")

        if st.session_state.show_doc_manager:
            with st.expander("📚 Uploaded Document Management", expanded=True):
                documents = doc_manager.list_documents()

                if not documents:
                    st.info("📭 No documents uploaded yet")
                else:
                    st.caption(f"Total {len(documents)} documents")

                    for doc in documents:
                        col1, col2, col3, col4 = st.columns([3, 2, 2, 1])

                        with col1:
                            st.markdown(f"**📄 {doc['original_filename']}**")

                        with col2:
                            st.text(f"📦 {doc['size_formatted']}")

                        with col3:
                            st.text(f"🕐 {doc['upload_time']}")

                        with col4:
                            if st.button("🗑️", key=f"del_{doc['file_id']}", help="Delete"):
                                file_success, file_message = doc_manager.delete_document(doc["file_id"])
                                vec_success, vec_message = rag_system.remove_user_document(doc["original_filename"])

                                if file_success:
                                    st.success(file_message)
                                    if vec_success:
                                        st.info(vec_message)
                                    else:
                                        st.warning(vec_message)
                                    st.rerun()
                                else:
                                    st.error(file_message)

                        st.markdown("---")

        st.markdown("---")
        st.markdown("### 🙋 Question")

        question = st.text_area(
            "Please enter your question here: \n (**Note: The system currently answers questions only based on materials in the database, it'll answer *I don't know based on the provided context.* if it failed to find answer from the docs.**)",
            placeholder="Can you list some of the hyperparameters in the FFN?",
            height=100,
            key="question_input",
        )

        col1, col2, _ = st.columns([1, 1, 4])
        with col1:
            ask_button = st.button("Shoot", type="primary", use_container_width=True)
        with col2:
            if st.button("Clean The History", use_container_width=True):
                st.session_state.qa_history = []
                st.rerun()

        if ask_button and question.strip():
            with st.spinner("(ー_ーゞ thinking~~~"):
                try:
                    rag_chain = rag_system.create_rag_chain(k=3)
                    response = rag_chain.invoke(question)

                    qa_entry = {
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "question": question.strip(),
                        "answer": response.content,
                    }
                    st.session_state.qa_history.append(qa_entry)

                    st.markdown("### Answer")
                    st.info(response.content)

                except Exception as error:
                    st.error(f"😭 Get an error: {str(error)}")

        elif ask_button:
            st.warning("🤔 Got nothing to ask yet?")

        if st.session_state.qa_history:
            st.markdown("---")
            st.markdown("## QA History")
            st.caption(f"You got {len(st.session_state.qa_history)} histories in total.")

            for idx, qa in enumerate(reversed(st.session_state.qa_history), 1):
                with st.expander(
                    f"🕐 {qa['timestamp']} - Question #{len(st.session_state.qa_history) - idx + 1}",
                    expanded=(idx == 1),
                ):
                    st.markdown("**Question:**")
                    st.write(qa["question"])
                    st.markdown("**Answer:**")
                    st.info(qa["answer"])

        with st.sidebar:
            st.header("About")
            st.markdown(
                """
            This is a academic QA system on the strength of RAG.

            **Highlights:**
            - Supports users to upload custom docs.
            - Load, analyze and process pdf type of docs.
            - Performs semantic retrieval to identify the most relevant content chunks.
            - Generates accurate answers using OpenAI GPT-3.5 within a RAG pipeline.
            - Implements a LangChain-based Retrieval-Augmented Generation workflow.
            - Restricts responses only based on course materials to minimize hallucinations.
            - Automatically stores QA history for session continuity.
            - Clearly distinguishes content sources (default vs. user-uploaded).

            **Guide:**
            1. Upload your PDF docs (if you'd like to ask questions related to them).
            2. Enter your question in the input field.
            3. Click the “Shoot” button.
            4. Wait for the answer.
            5. Previous questions and answers will be automatically saved below.
            6. Click “Manage Uploaded Docs” to view or remove uploaded files.

            **Sample Questions:**
            - Can you list some of the hyperparameters in the FFN?
            - What is backpropagation?
            - Explain gradient descent
            """
            )

            st.divider()

            st.header("🧑‍💻 Tech Stack:")
            st.markdown(
                """
            - **Front End**: Streamlit by Codegen
            - **LLM**: OpenAI GPT-3.5
            - **Vector Database**: Chroma (Locally Persistence)
            - **Framework**: LangChain
            - **Docs Processing**: PyPDF
            - **Architecture**: Double Vector Database (Default + User)
            """
            )

            st.divider()

            try:
                if runtime_paths.upload_dir.exists():
                    total_size = get_directory_size(runtime_paths.upload_dir)
                    st.metric(label="📊 Data Uploaded", value=format_file_size(total_size))
            except Exception:
                pass

            st.markdown("---")
            st.caption(f"Config source: {config['source']}")
            st.caption("🔔 Note: Initial document loading and vectorization may take a few moments on first use.")

    except ConfigurationError:
        st.error(
            """
        ❌ OpenAI API Key not found!

        Please configure it using one of the following methods:

        **1. Streamlit Cloud Deployment (Recommended):**
        - Add Secrets in Streamlit Cloud settings
        - Format: `OPENAI_API_KEY = "your-key-here"`

        **2. Local Environment Variable:**
        ```bash
        export OPENAI_API_KEY="your-key-here"
        ```

        **3. Local config.json File:**
        ```json
        {
          "OpenAIAPIKey": "your-key-here"
        }
        ```
        """
        )
        st.stop()
    except Exception as error:
        st.error(f"❌ System Error: {str(error)}")
        st.info(
            f"""
        Please check:
        - OpenAI API Key is correct
        - There are PDF files in the base documents directory: {runtime_paths.base_docs_dir}
        - Network connection is stable
        """
        )
