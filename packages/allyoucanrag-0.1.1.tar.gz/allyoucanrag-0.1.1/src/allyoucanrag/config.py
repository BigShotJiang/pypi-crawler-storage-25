"""Configuration helpers for the MAC Academy QA System package."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .exceptions import ConfigurationError
from .paths import PathLike, resolve_path, resolve_runtime_paths


@dataclass(frozen=True)
class AppConfig:
    """Resolved application configuration."""

    openai_api_key: str
    langchain_api_key: str | None = None
    source: str = "environment"
    config_path: Path | None = None

    @property
    def langsmith_enabled(self) -> bool:
        return bool(self.langchain_api_key)


@dataclass(frozen=True)
class ConfigStatus:
    """Configuration presence summary used by interactive clients."""

    openai_api_key_configured: bool
    langchain_api_key_configured: bool
    source: str = ""
    config_path: Path | None = None

    @property
    def ready_for_cli(self) -> bool:
        return self.openai_api_key_configured and self.langchain_api_key_configured


def _load_json_config(config_path: Path) -> dict[str, Any]:
    if not config_path.exists():
        return {}

    with config_path.open("r", encoding="utf-8") as file_obj:
        return json.load(file_obj)


def get_config_status(
    config_path: PathLike | None = None,
    *,
    environ: Mapping[str, str] | None = None,
    secrets: Mapping[str, Any] | None = None,
) -> ConfigStatus:
    """Inspect whether required API keys are currently configured."""
    env = environ if environ is not None else os.environ
    runtime_paths = resolve_runtime_paths()
    resolved_config_path = resolve_path(config_path, runtime_paths.base_dir) or runtime_paths.config_path
    file_config = _load_json_config(resolved_config_path)
    secret_values = secrets or {}

    openai_configured = bool(
        secret_values.get("OPENAI_API_KEY")
        or env.get("OPENAI_API_KEY")
        or file_config.get("OpenAIAPIKey")
    )
    langchain_configured = bool(
        secret_values.get("LANGCHAIN_API_KEY")
        or env.get("LANGCHAIN_API_KEY")
        or file_config.get("LangChainAPIKey")
    )

    if secret_values.get("OPENAI_API_KEY") or secret_values.get("LANGCHAIN_API_KEY"):
        source = "streamlit-secrets"
    elif env.get("OPENAI_API_KEY") or env.get("LANGCHAIN_API_KEY"):
        source = "environment"
    elif resolved_config_path.exists():
        source = str(resolved_config_path)
    else:
        source = ""

    return ConfigStatus(
        openai_api_key_configured=openai_configured,
        langchain_api_key_configured=langchain_configured,
        source=source,
        config_path=resolved_config_path if resolved_config_path.exists() else resolved_config_path,
    )


def load_app_config(
    config_path: PathLike | None = None,
    *,
    environ: Mapping[str, str] | None = None,
    secrets: Mapping[str, Any] | None = None,
) -> AppConfig:
    """Load API configuration from secrets, environment variables, or config.json."""
    env = environ if environ is not None else os.environ
    runtime_paths = resolve_runtime_paths()
    resolved_config_path = resolve_path(config_path, runtime_paths.base_dir) or runtime_paths.config_path
    file_config = _load_json_config(resolved_config_path)
    secret_values = secrets or {}

    openai_api_key = None
    source = ""

    if secret_values.get("OPENAI_API_KEY"):
        openai_api_key = secret_values["OPENAI_API_KEY"]
        source = "streamlit-secrets"
    elif env.get("OPENAI_API_KEY"):
        openai_api_key = env["OPENAI_API_KEY"]
        source = "environment"
    else:
        openai_api_key = file_config.get("OpenAIAPIKey")
        if openai_api_key:
            source = str(resolved_config_path)

    if not openai_api_key:
        raise ConfigurationError("OpenAI API key not found in secrets, environment variables, or config file.")

    langchain_api_key = None
    if secret_values.get("LANGCHAIN_API_KEY"):
        langchain_api_key = secret_values["LANGCHAIN_API_KEY"]
    elif env.get("LANGCHAIN_API_KEY"):
        langchain_api_key = env["LANGCHAIN_API_KEY"]
    else:
        langchain_api_key = file_config.get("LangChainAPIKey")

    return AppConfig(
        openai_api_key=openai_api_key,
        langchain_api_key=langchain_api_key,
        source=source,
        config_path=resolved_config_path if resolved_config_path.exists() else None,
    )


def save_app_config(
    openai_api_key: str,
    langchain_api_key: str,
    config_path: PathLike | None = None,
) -> Path:
    """Persist API keys to the runtime config.json file."""
    normalized_openai_key = openai_api_key.strip()
    normalized_langchain_key = langchain_api_key.strip()

    if not normalized_openai_key:
        raise ConfigurationError("OpenAI API key cannot be empty.")
    if not normalized_langchain_key:
        raise ConfigurationError("LangChain API key cannot be empty.")

    runtime_paths = resolve_runtime_paths()
    resolved_config_path = resolve_path(config_path, runtime_paths.base_dir) or runtime_paths.config_path
    existing_config = _load_json_config(resolved_config_path)
    existing_config["OpenAIAPIKey"] = normalized_openai_key
    existing_config["LangChainAPIKey"] = normalized_langchain_key

    resolved_config_path.parent.mkdir(parents=True, exist_ok=True)
    with resolved_config_path.open("w", encoding="utf-8") as file_obj:
        json.dump(existing_config, file_obj, ensure_ascii=False, indent=2)

    return resolved_config_path


def apply_api_keys(config: AppConfig, *, environ: dict[str, str] | None = None) -> None:
    """Apply resolved API keys to the target environment mapping."""
    target_env = environ if environ is not None else os.environ
    target_env["OPENAI_API_KEY"] = config.openai_api_key

    if config.langchain_api_key:
        target_env["LANGCHAIN_TRACING_V2"] = "true"
        target_env["LANGCHAIN_ENDPOINT"] = "https://api.smith.langchain.com"
        target_env["LANGCHAIN_API_KEY"] = config.langchain_api_key
