"""文档管理模块。"""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .exceptions import DocumentProcessingError
from .paths import PathLike, RuntimePaths, resolve_path, resolve_runtime_paths
from .utils import (
    calculate_file_hash,
    format_file_size,
    generate_unique_filename,
    safe_remove_file,
    validate_document_path,
    validate_pdf_file,
)

logger = logging.getLogger(__name__)


class DocumentManager:
    """文档管理器类"""

    def __init__(
        self,
        upload_dir: PathLike | None = None,
        metadata_file: str = "document_metadata.json",
        runtime_paths: RuntimePaths | None = None,
    ):
        """
        初始化文档管理器

        Args:
            upload_dir: 上传文件存储目录
            metadata_file: 元数据文件名
        """
        resolved_paths = runtime_paths or resolve_runtime_paths(
            upload_dir=upload_dir,
            metadata_file_name=metadata_file,
        )

        self.runtime_paths = resolved_paths
        self.upload_dir = resolve_path(upload_dir, resolved_paths.base_dir) or resolved_paths.upload_dir
        self.metadata_file = self.upload_dir / metadata_file
        self._ensure_directory_exists()

    def _ensure_directory_exists(self):
        """确保上传目录存在"""
        self.upload_dir.mkdir(parents=True, exist_ok=True)

    def _load_metadata(self) -> Dict[str, Dict]:
        """
        加载文档元数据

        Returns:
            文档元数据字典 {file_id: metadata}
        """
        if self.metadata_file.exists():
            try:
                with self.metadata_file.open("r", encoding="utf-8") as file_obj:
                    return json.load(file_obj)
            except Exception as error:
                logger.warning("Unable to load metadata from %s: %s", self.metadata_file, error)
                return {}
        return {}

    def _save_metadata(self, metadata: Dict[str, Dict]):
        """
        保存文档元数据

        Args:
            metadata: 文档元数据字典
        """
        try:
            with self.metadata_file.open("w", encoding="utf-8") as file_obj:
                json.dump(metadata, file_obj, ensure_ascii=False, indent=2)
        except Exception as error:
            raise DocumentProcessingError(f"Unable to save metadata: {error}") from error

    def check_duplicate(self, file_content: bytes) -> Optional[Dict]:
        """
        检查文件是否已存在（通过哈希值）

        注意：元数据只在文件成功索引后才保存，所以这里检查的都是已索引的文件

        Args:
            file_content: 文件内容

        Returns:
            如果存在重复，返回已存在文件的元数据；否则返回 None
        """
        file_hash = calculate_file_hash(file_content)
        metadata = self._load_metadata()

        for _, meta in metadata.items():
            if meta.get("hash") == file_hash:
                return meta
        return None

    def upload_document(self, uploaded_file) -> Tuple[bool, Optional[str], Optional[Dict]]:
        """
        上传并保存文档（只保存文件，不保存元数据）

        元数据将在文档成功索引后通过 save_document_metadata() 保存

        Args:
            uploaded_file: Streamlit UploadedFile 对象

        Returns:
            (是否成功, 错误信息/成功信息, 临时元数据字典)
        """
        is_valid, error_msg = validate_pdf_file(uploaded_file)
        if not is_valid:
            return False, error_msg, None

        try:
            file_content = uploaded_file.getvalue()
        except Exception as error:
            return False, f"❌ Unable to read file: {str(error)}", None

        return self._store_document_bytes(uploaded_file.name, file_content)

    def upload_file_path(self, file_path: PathLike) -> Tuple[bool, Optional[str], Optional[Dict]]:
        """Upload a local file path for CLI-based indexing."""
        path = Path(file_path)
        is_valid, error_msg = validate_document_path(path)
        if not is_valid:
            return False, error_msg, None

        try:
            file_content = path.read_bytes()
        except Exception as error:
            return False, f"❌ Unable to read file: {str(error)}", None

        return self._store_document_bytes(path.name, file_content)

    def _store_document_bytes(self, original_filename: str, file_content: bytes) -> Tuple[bool, Optional[str], Optional[Dict]]:
        duplicate = self.check_duplicate(file_content)
        if duplicate:
            return False, f"⚠️ File already exists!\nFilename: {duplicate['original_filename']}\nUpload time: {duplicate['upload_time']}", None

        unique_filename = generate_unique_filename(original_filename)
        filepath = self.upload_dir / unique_filename

        try:
            with filepath.open("wb") as file_obj:
                file_obj.write(file_content)
        except Exception as error:
            return False, f"❌ Failed to save file: {str(error)}", None

        file_hash = calculate_file_hash(file_content)
        temp_metadata = {
            "file_id": unique_filename,
            "original_filename": original_filename,
            "filepath": str(filepath),
            "size": len(file_content),
            "size_formatted": format_file_size(len(file_content)),
            "hash": file_hash,
            "upload_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

        return True, f"✅ File uploaded successfully: {original_filename}", temp_metadata

    def delete_document(self, file_id: str) -> Tuple[bool, Optional[str]]:
        """
        删除文档及其元数据

        Args:
            file_id: 文件ID（唯一文件名）

        Returns:
            (是否成功, 错误信息/成功信息)
        """
        all_metadata = self._load_metadata()

        if file_id not in all_metadata:
            return False, "❌ Document not found!"

        filepath = Path(all_metadata[file_id]["filepath"])
        success, error = safe_remove_file(filepath)

        if not success:
            return False, f"❌ Failed to delete file: {error}"

        original_name = all_metadata[file_id]["original_filename"]
        del all_metadata[file_id]
        try:
            self._save_metadata(all_metadata)
        except DocumentProcessingError as error:
            return False, f"❌ {error}"

        return True, f"✅ Document deleted successfully: {original_name}"

    def list_documents(self) -> List[Dict]:
        """
        列出所有已上传的文档

        Returns:
            文档列表（按上传时间倒序）
        """
        all_metadata = self._load_metadata()
        documents = list(all_metadata.values())
        documents.sort(key=lambda item: item.get("upload_time", ""), reverse=True)
        return documents

    def save_document_metadata(self, metadata: Dict) -> Tuple[bool, Optional[str]]:
        """
        保存文档元数据到持久化存储

        应该在文档成功索引后调用此方法

        Args:
            metadata: 文档元数据字典

        Returns:
            (是否成功, 错误信息)
        """
        try:
            all_metadata = self._load_metadata()
            file_id = metadata["file_id"]
            all_metadata[file_id] = metadata
            self._save_metadata(all_metadata)
            return True, None
        except Exception as error:
            return False, f"Failed to save metadata: {str(error)}"

    def mark_as_indexed(self, file_id: str):
        """
        标记文档为已索引（已废弃，使用 save_document_metadata 代替）

        Args:
            file_id: 文件ID
        """
        all_metadata = self._load_metadata()
        if file_id in all_metadata:
            all_metadata[file_id]["indexed"] = True
            self._save_metadata(all_metadata)

    def get_document_metadata(self, file_id: str) -> Optional[Dict]:
        """
        获取指定文档的元数据

        Args:
            file_id: 文件ID

        Returns:
            文档元数据，如果不存在返回 None
        """
        all_metadata = self._load_metadata()
        return all_metadata.get(file_id)
