"""Package-specific exceptions."""


class MacAcademyQAError(Exception):
    """Base package exception."""


class ConfigurationError(MacAcademyQAError):
    """Raised when required configuration is missing or invalid."""


class DocumentProcessingError(MacAcademyQAError):
    """Raised when a document cannot be loaded or indexed."""
