#!/usr/bin/env bash
# Build Tailwind CSS for datagrowth_common.ui.
# Produces src/datagrowth_common/ui/static/css/tailwind.compiled.css.
set -euo pipefail
cd "$(dirname "$0")/.."

npx --yes tailwindcss@3 \
  --minify \
  --input  src/datagrowth_common/ui/static/css/_tailwind.source.css \
  --output src/datagrowth_common/ui/static/css/tailwind.compiled.css \
  --config tailwind.config.js
