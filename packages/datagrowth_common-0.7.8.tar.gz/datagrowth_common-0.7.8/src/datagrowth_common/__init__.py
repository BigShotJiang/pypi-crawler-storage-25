"""datagrowth-common — utilidades compartidas entre apps Datagrowth.

v0.7.x (mayo 2026):
- Nuevo módulo `datagrowth_common.migrations` con `apply_migrations(dir)`.
  Las apps generadas lo invocan en el lifespan para aplicar `migrations/*.sql`
  contra su Postgres (idempotente, tracking en `dg_internal._dg_applied_migrations`).
  Habilita despliegues a clientes en VPS distintos al del control plane.
- Nueva optional dep `[postgres]` con `psycopg[binary]>=3.2`.

v0.5.0 — v0.6.x:
- Nuevo módulo `datagrowth_common.users` con `make_users_router`,
  `PermissionCatalog`, `make_require_permission`, `bootstrap_roles` y audit log.
  Migración `001_users_rbac.sql` empaquetada en el wheel.
- Template del repo adopta el panel RBAC nuevo: gestión multi-rol, permisos
  por catálogo, audit log y endpoint `POST /admin/users/{id}/password/set`.

v0.3.1 — v0.4.x:
- Subpaquete `datagrowth_common.ui`: Jinja2 partials (`dg/...`), tokens CSS
  light/dark, Tailwind precompilado y JS de theme/toasts/htmx-events.
  `register_ui(app, jinja_env, mount_path)` cablea todo en una FastAPI host app.
- `tailwind-preset.cjs` empaquetado en el wheel para que apps con Tailwind
  local compartan tokens y safelist con el paquete.

v0.3.0 (BREAKING):
- Eliminados `datagrowth_common.authentik` y `datagrowth_common.auth_fastapi`
  (forward-auth Authentik). Importarlos lanza `ImportError`.
- `datagrowth_common.auth.local` → `datagrowth_common.auth.session_hmac`.
  Eliminada la integración Authentik OIDC. `auth.local` queda como alias
  deprecated (DeprecationWarning); se eliminará en v0.4.0.
- Modelo único de auth: Supabase Auth (cookie JWT en `auth.session` +
  endpoints en `auth.router` + verify en `auth.supabase`).

Ver CHANGELOG.md para la guía de migración completa.
"""
from .auth.supabase import (
    SupabaseUser,
    SupabaseUserDep,
    require_role,
    require_supabase_jwt,
    verify_supabase_jwt,
)
from .auth.session import (
    ACCESS_COOKIE,
    REFRESH_COOKIE,
    SessionTokens,
    SessionUserDep,
    clear_session,
    get_session_tokens,
    refresh_session_tokens,
    require_session,
    set_session,
)
from .auth.router import auth_router, make_auth_router
from .api.users import users_router
from .result import Result, ok, err
from .logger import get_logger, setup_logging
from .migrations import apply_migrations
from .ui import UI_VERSION, register_ui

__version__ = "0.7.8"

__all__ = [
    # supabase auth (JWT)
    "SupabaseUser",
    "SupabaseUserDep",
    "require_role",
    "require_supabase_jwt",
    "verify_supabase_jwt",
    "users_router",
    # session (cookie httpOnly server-rendered)
    "ACCESS_COOKIE",
    "REFRESH_COOKIE",
    "SessionTokens",
    "SessionUserDep",
    "set_session",
    "clear_session",
    "get_session_tokens",
    "refresh_session_tokens",
    "require_session",
    # auth router (login + OAuth + refresh + logout)
    "auth_router",
    "make_auth_router",
    # core
    "Result",
    "ok",
    "err",
    "get_logger",
    "setup_logging",
    # migrations (auto-aplicadas en lifespan de la app generada)
    "apply_migrations",
    # ui (datagrowth_common.ui)
    "register_ui",
    "UI_VERSION",
    "__version__",
]
