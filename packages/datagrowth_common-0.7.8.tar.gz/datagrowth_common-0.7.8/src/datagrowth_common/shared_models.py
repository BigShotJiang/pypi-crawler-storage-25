"""Modelos compartidos entre apps Datagrowth."""
from __future__ import annotations
from datetime import datetime
from typing import Optional
from pydantic import BaseModel


class ClientRead(BaseModel):
    id: str
    name: str
    slug: str
    hubspot_id: Optional[str] = None
    created_at: datetime


class ProjectRead(BaseModel):
    id: str
    client_id: str
    name: str
    slug: str
    created_at: datetime


class ContactRead(BaseModel):
    """Contacto/lead de un cliente (esquema shared)."""

    id: str
    client_id: str
    email: str
    name: Optional[str] = None
    phone: Optional[str] = None
    hubspot_id: Optional[str] = None
    created_at: datetime
