"""Patron de error de Datagrowth: devuelve el error como valor en vez de lanzarlo."""
from typing import TypeVar

T = TypeVar("T")

type Result[T] = tuple[T | None, Exception | None]


def ok(value: T) -> "Result[T]":
    return value, None


def err(exc: Exception) -> "Result[None]":
    return None, exc
