"""Cliente Supabase para Datagrowth.

Dos sabores:
- `get_supabase_client()` → anon/publishable key (para queries con RLS).
- `get_supabase_admin_client()` → service_role key (Admin API: auth.admin.*).

El admin client NUNCA debe exponerse al frontend.
"""
from __future__ import annotations
import os
from typing import Any


def _create(url: str, key: str, schema: str) -> Any:
    try:
        from supabase import create_client, Client  # type: ignore[import]
    except ImportError as e:
        raise ImportError(
            "supabase no esta instalado. Ejecuta: pip install datagrowth-common[supabase]"
        ) from e

    client: Client = create_client(url, key)
    if schema != "public":
        client.schema(schema)
    return client


def get_supabase_client(schema: str = "public") -> Any:
    """Cliente Supabase con anon/publishable key.

    Requiere SUPABASE_URL y SUPABASE_KEY en el entorno.
    """
    return _create(os.environ["SUPABASE_URL"], os.environ["SUPABASE_KEY"], schema)


def get_supabase_admin_client(schema: str = "public") -> Any:
    """Cliente Supabase con service_role key (Admin API).

    Requiere SUPABASE_URL y SUPABASE_SERVICE_ROLE_KEY. NO usar desde frontend
    ni exponer al usuario; service_role salta la RLS por completo.
    """
    return _create(
        os.environ["SUPABASE_URL"],
        os.environ["SUPABASE_SERVICE_ROLE_KEY"],
        schema,
    )
