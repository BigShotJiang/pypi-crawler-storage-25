"""Datagrowth Common UI: Jinja2 partials + CSS + JS for Datagrowth apps."""
from datagrowth_common.ui.loader import UI_VERSION, register_ui

__all__ = ["register_ui", "UI_VERSION"]
