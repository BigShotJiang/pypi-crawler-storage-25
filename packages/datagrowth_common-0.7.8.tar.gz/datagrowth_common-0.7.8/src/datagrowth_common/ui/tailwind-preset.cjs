/**
 * Tailwind preset compartido del ecosistema Datagrowth.
 *
 * Los consumidores que compilan Tailwind localmente (ej. `app-backend` con
 * clases JIT propias como `shadow-card`, `ring-brand-lime`) deben usar
 * este preset para mantener una única fuente de verdad de tokens y
 * para incluir las variantes responsive que `dg/...` necesita.
 *
 * El preset viaja DENTRO del wheel pip `datagrowth-common` (PyPI), bajo
 * `datagrowth_common/ui/tailwind-preset.cjs`. PyPI es la única fuente de
 * verdad: ni paquete npm separado, ni dep github en `package.json`. El
 * consumidor pip-instala el paquete (que ya hace para `register_ui`,
 * auth, helpers, etc.) y resuelve la ruta del fichero hacia su
 * `tailwind.config.js`.
 *
 * Uso (consumidor con `.venv` o equivalente):
 *
 *   const path = require("path");
 *   const { execSync } = require("child_process");
 *   const presetPath = execSync(
 *     'python -c "import datagrowth_common.ui as m, os; ' +
 *     'print(os.path.join(os.path.dirname(m.__file__), ' +
 *     "'tailwind-preset.cjs'))\""
 *   ).toString().trim();
 *
 *   module.exports = {
 *     presets: [require(presetPath)],
 *     content: ["./src/templates/**\/*.html"],
 *   };
 *
 * En contenedores multi-stage (frontend-build de node sin python), el
 * stage Python que ya pip-instala el paquete debe `COPY` el fichero a
 * una ruta vendored en el stage de node.
 *
 * El preset NO declara `content` ni `darkMode`: cada consumidor define
 * su scope de templates. La `safelist` aquí cubre las variantes
 * responsive usadas por los layouts del paquete (`dg/layouts/*.html`)
 * que de otro modo serían pisadas por la `.hidden`/`.block` que cada
 * consumidor regenera en su propio Tailwind local (cargado DESPUÉS del
 * `tailwind.compiled.css` del paquete → cascada CSS gana el consumidor).
 *
 * Bug que motivó el preset (2026-05-12 app-backend):
 *   <aside class="hidden md:flex"> en sidebar_shell.html quedaba
 *   permanentemente `display:none` porque el `app.css` local del
 *   backend redefinía `.hidden` (sin emitir `.md:flex`) y al cargarse
 *   después ganaba la cascada.
 */
/** @type {Partial<import('tailwindcss').Config>} */
module.exports = {
  safelist: [
    'sm:block',
    'sm:inline-flex',
    'md:flex',
    'md:grid-cols-2',
    'md:px-6',
    'lg:grid-cols-3',
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          lime:    '#b5ff82',
          'lime-50':  '#f4ffe8',
          'lime-100': '#e5ffc9',
          'lime-200': '#ccff99',
          'lime-300': '#b5ff82',
          'lime-400': '#9eea6a',
          'lime-500': '#84d44f',
          'lime-600': '#65b033',
          'lime-700': '#4a8a20',
          'lime-800': '#316010',
          'lime-900': '#1a3505',
          dark:    '#263b4a',
          'dark-50':  '#f0f4f7',
          'dark-100': '#d8e3ec',
          'dark-200': '#b0c6d8',
          'dark-300': '#7ea5be',
          'dark-400': '#4e84a4',
          'dark-500': '#2e647e',
          'dark-600': '#263b4a',
          'dark-700': '#1e2e3b',
          'dark-800': '#16212a',
          'dark-900': '#0c141a',
          muted:   '#bab8d0',
          'muted-50':  '#f5f5fb',
          'muted-100': '#e8e7f5',
          'muted-200': '#d2d0ea',
          'muted-300': '#bab8d0',
          'muted-400': '#9e9bbf',
          'muted-500': '#807daa',
          'muted-600': '#625f8e',
        },
        semantic: {
          success: '#16a34a',
          'success-bg': '#dcfce7',
          warning: '#d97706',
          'warning-bg': '#fef3c7',
          danger:  '#dc2626',
          'danger-bg': '#fee2e2',
          info:    '#2563eb',
          'info-bg': '#dbeafe',
        },
        surface:        'var(--color-surface)',
        'surface-subtle': 'var(--color-surface-subtle)',
        panel:          'var(--color-panel)',
        border:         'var(--color-border)',
        fg: {
          DEFAULT: 'var(--color-text-primary)',
          muted:   'var(--color-text-muted)',
        },
        link: {
          DEFAULT: 'var(--color-link)',
          hover:   'var(--color-link-hover)',
        },
      },
      fontFamily: {
        sans: ['"DM Sans"', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', '"Cascadia Code"', 'ui-monospace', 'Consolas', 'monospace'],
      },
      borderRadius: {
        sm:     '0.375rem',
        md:     '0.5rem',
        lg:     '0.75rem',
        xl:     '1rem',
        pill:   '9999px',
        button: '0.5rem',
        card:   '1rem',
      },
      boxShadow: {
        card:         '0 1px 3px 0 rgb(0 0 0 / 0.06), 0 1px 2px -1px rgb(0 0 0 / 0.04)',
        'card-hover': '0 4px 12px 0 rgb(0 0 0 / 0.10), 0 2px 4px -1px rgb(0 0 0 / 0.06)',
        popover:      '0 4px 16px 0 rgb(0 0 0 / 0.12), 0 2px 6px -2px rgb(0 0 0 / 0.08)',
        modal:        '0 20px 60px 0 rgb(0 0 0 / 0.25), 0 8px 24px -6px rgb(0 0 0 / 0.12)',
      },
      spacing: {
        18: '4.5rem',
        22: '5.5rem',
      },
    },
  },
};
