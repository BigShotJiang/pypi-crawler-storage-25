"""UI registration helper for Datagrowth apps.

Mounts the package's static assets at ``mount_path`` and appends a
``PackageLoader`` to the host Jinja Environment so templates under
``dg/...`` become resolvable from the host app.
"""
from __future__ import annotations

from importlib.resources import as_file, files

import structlog
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from jinja2 import ChoiceLoader, Environment, PackageLoader

UI_VERSION = "0.3.5"

logger = structlog.get_logger(__name__)


def register_ui(
    app: FastAPI,
    *,
    jinja_env: Environment,
    mount_path: str = "/static/dg-common",
) -> tuple[None, Exception | None]:
    """Attach datagrowth_common.ui templates and static files to a FastAPI app.

    Returns ``(None, None)`` on success and ``(None, Exception)`` on failure.
    Caller MUST inspect the error — invariant #1 (error as value).
    """
    try:
        if not isinstance(jinja_env.loader, ChoiceLoader):
            return None, RuntimeError(
                "jinja_env.loader must be ChoiceLoader to append ui templates"
            )
        jinja_env.loader.loaders.append(
            PackageLoader("datagrowth_common.ui", "templates")
        )
        static_traversable = files("datagrowth_common.ui").joinpath("static")
        with as_file(static_traversable) as static_root:
            app.mount(
                mount_path,
                StaticFiles(directory=str(static_root)),
                name="dg-common-static",
            )
        logger.info(
            "ui_registered",
            mount_path=mount_path,
            version=UI_VERSION,
        )
        return None, None
    except Exception as exc:
        logger.error("ui_registration_failed", error=str(exc))
        return None, exc
