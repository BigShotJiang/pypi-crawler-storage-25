// Auto-dismiss para elementos [data-toast].
(function () {
  "use strict";

  function scheduleDismiss(root) {
    (root || document).querySelectorAll("[data-toast]").forEach(function (el) {
      if (el.dataset.dgScheduled === "1") return;
      el.dataset.dgScheduled = "1";
      var ms = parseInt(el.dataset.dismissAfter || "5000", 10);
      if (!isFinite(ms) || ms <= 0) return;
      setTimeout(function () {
        el.classList.add("opacity-0");
        setTimeout(function () { el.remove(); }, 200);
      }, ms);
    });
  }

  document.addEventListener("DOMContentLoaded", function () { scheduleDismiss(document); });
  document.body && document.body.addEventListener("htmx:afterSwap", function (ev) {
    scheduleDismiss(ev.detail && ev.detail.target ? ev.detail.target : document);
  });
})();
