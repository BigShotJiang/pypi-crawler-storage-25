// HTMX wiring + modal helpers + ⌘K command palette.
(function () {
  "use strict";

  window.openModal = function (id) {
    var el = document.getElementById(id);
    if (!el) return;
    el.classList.remove("hidden");
    var input = el.querySelector("input,select,textarea,button");
    if (input) try { input.focus(); } catch (_) { /* noop */ }
  };

  window.closeModal = function (id) {
    var el = document.getElementById(id);
    if (el) el.classList.add("hidden");
  };

  function isPaletteOpen() {
    var el = document.getElementById("dg-command-palette");
    return el && !el.classList.contains("hidden");
  }

  document.addEventListener("keydown", function (ev) {
    var meta = ev.metaKey || ev.ctrlKey;
    if (meta && ev.key && ev.key.toLowerCase() === "k") {
      ev.preventDefault();
      if (isPaletteOpen()) window.closeModal("dg-command-palette");
      else window.openModal("dg-command-palette");
      return;
    }
    if (ev.key === "Escape") {
      document.querySelectorAll('[role="dialog"]:not(.hidden)').forEach(function (el) {
        el.classList.add("hidden");
      });
    }
  });

  document.body && document.body.addEventListener("htmx:responseError", function (ev) {
    var region = document.getElementById("dg-toasts");
    if (!region) return;
    var msg = "Error " + (ev.detail.xhr ? ev.detail.xhr.status : "");
    var tpl = document.createElement("div");
    tpl.setAttribute("role", "status");
    tpl.setAttribute("data-toast", "");
    tpl.setAttribute("data-dismiss-after", "5000");
    tpl.className = "dg-toast dg-toast-danger px-4 py-3 rounded-lg shadow-popover text-sm bg-panel text-slate-900 border border-border";
    tpl.textContent = msg.trim();
    region.appendChild(tpl);
    if (window.dispatchEvent) window.dispatchEvent(new CustomEvent("dg:toast"));
  });
})();
