// Theme toggle compatible con [data-theme="light"|"dark"].
// Persistencia en localStorage["dg-theme"]. Si no hay preferencia,
// usa prefers-color-scheme.
//
// El FOUC se previene desde un <script> inline en <head> del layout
// (dg/layouts/sidebar_shell.html) que ejecuta applyTheme antes del
// parse del <body>. Este fichero define el resto del API y los
// listeners (toggle, sync entre pestañas).
(function () {
  "use strict";

  var STORAGE_KEY = "dg-theme";

  function readStored() {
    try {
      return localStorage.getItem(STORAGE_KEY);
    } catch (_) {
      return null;
    }
  }

  function resolveInitial() {
    var stored = readStored();
    if (stored === "light" || stored === "dark") return stored;
    if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
      return "dark";
    }
    return "light";
  }

  function applyTheme(theme) {
    var t = theme === "dark" ? "dark" : "light";
    document.documentElement.dataset.theme = t;
    document.querySelectorAll("[data-theme-icon]").forEach(function (el) {
      el.classList.toggle("hidden", el.dataset.themeIcon !== t);
    });
    // Anuncia el estado actual a tecnologías asistivas en el botón.
    document.querySelectorAll("[data-theme-toggle]").forEach(function (btn) {
      btn.setAttribute("aria-pressed", t === "dark" ? "true" : "false");
      btn.setAttribute(
        "aria-label",
        t === "dark" ? "Cambiar a tema claro" : "Cambiar a tema oscuro"
      );
    });
  }

  window.setTheme = function (theme) {
    applyTheme(theme);
    try {
      localStorage.setItem(STORAGE_KEY, theme === "dark" ? "dark" : "light");
    } catch (_) {
      /* storage no disponible */
    }
  };

  window.toggleTheme = function () {
    var current = document.documentElement.dataset.theme === "dark" ? "dark" : "light";
    window.setTheme(current === "dark" ? "light" : "dark");
  };

  // Sync entre pestañas: si el usuario cambia el tema en otra pestaña,
  // refleja el cambio aquí sin recargar.
  window.addEventListener("storage", function (event) {
    if (event.key !== STORAGE_KEY) return;
    if (event.newValue === "light" || event.newValue === "dark") {
      applyTheme(event.newValue);
    }
  });

  // Aplica el tema resuelto + sincroniza icons/aria-pressed con el
  // valor inyectado por el script inline del <head>.
  applyTheme(resolveInitial());
})();
