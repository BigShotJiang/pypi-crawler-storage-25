"""Aplicacion idempotente de migrations SQL al Postgres de la app.

Pensado para correr en el lifespan de FastAPI. La app se despliega en
Easypanel (red docker compartida con su Supabase) y al arrancar aplica
los `migrations/*.sql` que vienen en el repo. Idempotente: registra los
archivos aplicados en `dg_internal._dg_applied_migrations`, asi un
reinicio de container no los vuelve a ejecutar.

Si una migracion falla, el caller debe `raise` (deja morir el lifespan)
para que Easypanel marque el container como crash loop. El control plane
detecta el fallo via polling del healthcheck publico.

NO se usa SQLAlchemy aqui: queremos transacciones explicitas y control
fino del orden de aplicacion. Se conecta con `psycopg` async directo.
`psycopg` es import lazy: si no esta instalado se devuelve err con un
mensaje claro (la app no podria correr sin el de todos modos, pero el
caller decide como reaccionar).
"""

from __future__ import annotations

import os
from pathlib import Path
from urllib.parse import quote_plus

from .logger import get_logger
from .result import Result, err, ok

log = get_logger(__name__)

_BOOTSTRAP_SQL = """
CREATE SCHEMA IF NOT EXISTS dg_internal;
CREATE TABLE IF NOT EXISTS dg_internal._dg_applied_migrations (
    filename   TEXT PRIMARY KEY,
    applied_at TIMESTAMP NOT NULL DEFAULT NOW()
);
"""

# Clave fija para `pg_advisory_lock`: bloquea la sesión hasta soltar
# (no se libera al commit). Garantiza que dos procesos uvicorn workers
# arrancando en paralelo no apliquen migrations a la vez: el primero
# adquiere el lock, el segundo se queda bloqueado en la llamada hasta
# que el primero termine; cuando entra, ya ve la tabla de control llena
# y skip-ea todo. Sin esto, dos workers leen `_already_applied` vacío y
# ambos intentan `CREATE TYPE`, lo que rompe el segundo con
# `duplicate key ... pg_type_typname_nsp_index`.
# El número es arbitrario pero estable entre versiones (`bigint` PG, int64).
_MIGRATION_LOCK_KEY = 7235379040502194516  # ascii hex: "DGMIGRAT"


async def apply_migrations(
    migrations_dir: Path,
    *,
    db_url: str | None = None,
) -> Result[list[str]]:
    """Aplica todos los `*.sql` en orden lexicografico, salta los aplicados.

    Si `db_url` es None, se resuelve desde env vars (mismo patron que
    `template/src/db.py`):
      - `DG_DATABASE_URL` (si esta puesta, se usa tal cual con prefijo
        `postgresql://` para `psycopg.connect`).
      - O bien `POSTGRES_PASSWORD + DG_SUPABASE_DB_HOST` (+ port/user/db).

    Diseno:
      - `dg_internal._dg_applied_migrations` aisla el tracking en su
        propio schema para no chocar con el schema de negocio.
      - Cada archivo se ejecuta en su propia transaccion: si falla el
        archivo 3, los 1-2 ya estan marcados aplicados y un re-arranque
        empezara por el 3.
      - El logger NO incluye el contenido SQL ni la connection string.

    Devuelve lista de archivos aplicados EN ESTA CORRIDA (los ya
    aplicados previamente no aparecen en la lista pero tampoco son un
    error).
    """
    if not migrations_dir.exists() or not migrations_dir.is_dir():
        log.info("migrations_dir_missing", path=str(migrations_dir))
        return ok([])

    files = sorted(p for p in migrations_dir.glob("*.sql") if p.is_file())
    if not files:
        return ok([])

    resolved_url, url_err = _resolve_db_url(db_url)
    if url_err is not None or resolved_url is None:
        return err(url_err or RuntimeError("db-url-resolve-failed"))

    try:
        import psycopg
    except ImportError:
        return err(RuntimeError("psycopg-not-installed"))

    applied: list[str] = []
    try:
        async with await psycopg.AsyncConnection.connect(
            resolved_url, autocommit=False,
        ) as conn:
            # `pg_advisory_lock` session-level: bloquea hasta soltar (no
            # se libera al commit). Cualquier otro worker que llegue
            # hasta aquí espera. Lo hacemos en su propia transacción
            # para que sea inmediatamente visible al resto del bloque.
            async with conn.transaction():
                await conn.execute(
                    "SELECT pg_advisory_lock(%s)",
                    (_MIGRATION_LOCK_KEY,),
                )
            try:
                async with conn.transaction():
                    await conn.execute(_BOOTSTRAP_SQL)

                done_set = await _already_applied(conn)
                for path in files:
                    if path.name in done_set:
                        continue
                    sql = path.read_text(encoding="utf-8")
                    try:
                        async with conn.transaction():
                            await conn.execute(sql)
                            await conn.execute(
                                "INSERT INTO dg_internal._dg_applied_migrations "
                                "(filename) VALUES (%s)",
                                (path.name,),
                            )
                    except Exception as exc:
                        log.error(
                            "migration_failed",
                            file=path.name, error=str(exc)[:300],
                        )
                        return err(RuntimeError(f"migration-{path.name}:{exc}"))
                    applied.append(path.name)
                    log.info("migration_applied", file=path.name)
            finally:
                # Liberar el lock explícitamente. Al cerrar la conn
                # también se libera, pero ser explícito ayuda a
                # diagnosticar deadlocks si alguna app reusa la conn.
                try:
                    async with conn.transaction():
                        await conn.execute(
                            "SELECT pg_advisory_unlock(%s)",
                            (_MIGRATION_LOCK_KEY,),
                        )
                except Exception:
                    pass
    except Exception as exc:
        return err(exc)

    return ok(applied)


def _resolve_db_url(db_url: str | None) -> Result[str]:
    """Devuelve `db_url` si se pasa; si no, lo construye desde env vars."""
    if db_url:
        url = db_url.strip()
        # `psycopg.connect` admite `postgresql://`. Si viene con prefijo
        # SQLAlchemy `postgresql+psycopg://`, normalizar.
        if url.startswith("postgresql+psycopg://"):
            url = "postgresql://" + url[len("postgresql+psycopg://"):]
        return ok(url)

    explicit = (os.getenv("DG_DATABASE_URL") or "").strip()
    if explicit:
        if explicit.startswith("postgresql+psycopg://"):
            explicit = "postgresql://" + explicit[len("postgresql+psycopg://"):]
        return ok(explicit)

    password = (os.getenv("POSTGRES_PASSWORD") or "").strip()
    host = (os.getenv("DG_SUPABASE_DB_HOST") or "").strip()
    if not (password and host):
        return err(RuntimeError(
            "migrations:db-url-not-configured "
            "(set DG_DATABASE_URL or POSTGRES_PASSWORD + DG_SUPABASE_DB_HOST)",
        ))
    port = os.getenv("DG_SUPABASE_DB_PORT", "5432")
    user = os.getenv("DG_SUPABASE_DB_USER", "postgres")
    name = os.getenv("DG_SUPABASE_DB_NAME", "postgres")
    return ok(
        f"postgresql://{user}:{quote_plus(password)}@{host}:{port}/{name}",
    )


async def _already_applied(conn) -> set[str]:  # noqa: ANN001 — psycopg conn
    cur = await conn.execute(
        "SELECT filename FROM dg_internal._dg_applied_migrations",
    )
    rows = await cur.fetchall()
    return {r[0] for r in rows}


__all__ = ["apply_migrations"]
