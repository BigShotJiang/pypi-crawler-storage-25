"""Verificador de actualizaciones para apps Datagrowth self-hosted."""
from __future__ import annotations
import os
from typing import Callable
import httpx


async def check_for_updates(
    app_slug: str | None = None,
    tenant_slug: str | None = None,
    current_version: str | None = None,
    backend_url: str | None = None,
) -> dict | None:
    """Consulta el backend para ver si hay una version mas nueva disponible.

    Devuelve el payload del manifest si hay actualizacion, None si ya es la ultima.
    No lanza excepciones — devuelve None si el backend no esta disponible.
    """
    _slug = app_slug or os.getenv("DG_APP_SLUG")
    _tenant = tenant_slug or os.getenv("DG_TENANT_SLUG")
    _version = current_version or os.getenv("DG_APP_VERSION", "0.0.0")
    _url = backend_url or os.getenv("DG_RELEASES_URL", "https://backend.dev.datagrowth.es")

    if not _slug or not _tenant:
        return None

    manifest_url = f"{_url}/public/releases/{_slug}/{_tenant}/manifest.json"
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(manifest_url, params={"current_version": _version})
            if r.status_code != 200:
                return None
            data = r.json()
            if data.get("latest") == _version:
                return None
            return data
    except Exception:  # noqa: BLE001
        return None


async def run_periodic_check(
    notify_fn: Callable[[dict], None],
    **kwargs: str,
) -> None:
    """Comprueba si hay actualizaciones y llama notify_fn si las hay."""
    update = await check_for_updates(**kwargs)
    if update:
        notify_fn(update)
