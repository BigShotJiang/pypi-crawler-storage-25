"""API helpers compartidos: respuesta estandar y paginacion.

Para `users_router` (CRUD sobre Supabase Admin API), importar
explicitamente: `from datagrowth_common.api.users import users_router`.
Se evita re-exportarlo aqui para no forzar el import de
`auth.supabase` cuando un consumidor solo necesita helpers genericos.
"""
from .errors import ApiResponse, ErrorBody, ErrorCode, err_response, ok_response
from .pagination import PageMeta, Paginated, paginate_params

__all__ = [
    "ApiResponse",
    "ErrorBody",
    "ErrorCode",
    "err_response",
    "ok_response",
    "PageMeta",
    "Paginated",
    "paginate_params",
]
