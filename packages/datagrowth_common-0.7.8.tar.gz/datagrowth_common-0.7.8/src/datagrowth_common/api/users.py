"""Router CRUD de usuarios sobre Supabase Admin API.

Para usar: `app.include_router(users_router)`. La app debe definir las
variables de entorno `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` y
`SUPABASE_JWT_SECRET`.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, EmailStr, Field

from ..auth.supabase import (
    SupabaseUser,
    SupabaseUserDep,
    require_role,
)
from ..auth import supabase_admin
from ..api.pagination import Paginated, paginate_params
from .errors import (
    ApiResponse,
    ErrorCode,
    err_response,
    ok_response,
)


users_router = APIRouter(prefix="/api/users", tags=["users"])


class InviteBody(BaseModel):
    email: EmailStr = Field(..., max_length=254)
    role: str = Field(default="user", min_length=1, max_length=50)
    redirect_to: str | None = Field(default=None, max_length=2048)


_AdminUser = Depends(require_role("admin"))


@users_router.get("/me", response_model=ApiResponse[SupabaseUser])
async def get_me(user: SupabaseUserDep) -> ApiResponse[SupabaseUser]:
    return ok_response(user)


@users_router.get("", response_model=ApiResponse[Paginated[SupabaseUser]])
async def list_users(
    _admin: SupabaseUser = _AdminUser,
    limit: int | None = Query(default=None, ge=1, le=100),
    offset: int | None = Query(default=None, ge=0),
) -> ApiResponse[Paginated[SupabaseUser]]:
    safe_limit, safe_offset = paginate_params(limit, offset)
    page, exc = await supabase_admin.list_users(limit=safe_limit, offset=safe_offset)
    if exc is not None or page is None:
        return err_response(ErrorCode.INTERNAL_ERROR, "list-users-failed")
    return ok_response(page)


@users_router.post(
    "/invite", response_model=ApiResponse[SupabaseUser], status_code=201,
)
async def invite_user(
    body: InviteBody, _admin: SupabaseUser = _AdminUser,
) -> ApiResponse[SupabaseUser]:
    user, exc = await supabase_admin.invite_user_by_email(
        body.email, role=body.role, redirect_to=body.redirect_to,
    )
    if exc is not None or user is None:
        return err_response(ErrorCode.INTERNAL_ERROR, "invite-failed")
    return ok_response(user)


@users_router.delete("/{user_id}", response_model=ApiResponse[dict])
async def delete_user(
    user_id: str, _admin: SupabaseUser = _AdminUser,
) -> ApiResponse[dict]:
    _, exc = await supabase_admin.delete_user(user_id)
    if exc is not None:
        return err_response(ErrorCode.INTERNAL_ERROR, "delete-failed")
    return ok_response({"deleted": user_id})
