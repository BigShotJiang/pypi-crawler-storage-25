"""Paginacion estandar `limit/offset`.

Las queries siempre van con LIMIT (regla de rendimiento §3 del proyecto).
Este modulo expone `paginate_params` para validar/clip de query params y
`Paginated[T]` como envolvente de respuesta.
"""
from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")

DEFAULT_LIMIT = 20
MAX_LIMIT = 100


class PageMeta(BaseModel):
    total: int = Field(ge=0)
    limit: int = Field(ge=1, le=MAX_LIMIT)
    offset: int = Field(ge=0)
    has_more: bool


class Paginated(BaseModel, Generic[T]):
    data: list[T]
    meta: PageMeta


def paginate_params(
    limit: int | None = None,
    offset: int | None = None,
) -> tuple[int, int]:
    """Valida y clipea limit/offset. Devuelve `(limit_safe, offset_safe)`.

    `None` se trata como "no especificado" → default. Cualquier entero
    fuera de rango se clipea (limit a [1, MAX_LIMIT], offset a [0, ∞)).
    """
    raw_limit = DEFAULT_LIMIT if limit is None else int(limit)
    raw_offset = 0 if offset is None else int(offset)
    safe_limit = max(1, min(raw_limit, MAX_LIMIT))
    safe_offset = max(0, raw_offset)
    return safe_limit, safe_offset


def build_meta(total: int, limit: int, offset: int) -> PageMeta:
    return PageMeta(
        total=total, limit=limit, offset=offset,
        has_more=offset + limit < total,
    )
