"""Respuesta estandar `ApiResponse` y catalogo de errores.

Codigo y mensaje van siempre en `error`. Los handlers nunca lanzan
excepciones a traves de la frontera HTTP: devuelven `ApiResponse` con
`error` poblado o `data` poblado, exclusivo.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field, model_validator

T = TypeVar("T")


class ErrorCode(str, Enum):
    NOT_FOUND = "NOT_FOUND"
    VALIDATION_ERROR = "VALIDATION_ERROR"
    UNAUTHORIZED = "UNAUTHORIZED"
    FORBIDDEN = "FORBIDDEN"
    RATE_LIMITED = "RATE_LIMITED"
    CONFLICT = "CONFLICT"
    INTERNAL_ERROR = "INTERNAL_ERROR"


class ErrorBody(BaseModel):
    code: ErrorCode
    message: str
    details: dict[str, Any] | None = None


class ApiResponse(BaseModel, Generic[T]):
    data: T | None = None
    error: ErrorBody | None = None
    meta: dict[str, Any] | None = Field(default=None)

    @model_validator(mode="after")
    def _xor_data_error(self) -> "ApiResponse[T]":
        if (self.data is None) == (self.error is None):
            raise ValueError("ApiResponse requires exactly one of data|error")
        return self


def ok_response(data: T, meta: dict[str, Any] | None = None) -> ApiResponse[T]:
    return ApiResponse[T](data=data, meta=meta)


def err_response(
    code: ErrorCode, message: str, details: dict[str, Any] | None = None,
) -> ApiResponse[Any]:
    return ApiResponse[Any](error=ErrorBody(code=code, message=message, details=details))


HTTP_STATUS_FOR_CODE: dict[ErrorCode, int] = {
    ErrorCode.NOT_FOUND: 404,
    ErrorCode.VALIDATION_ERROR: 422,
    ErrorCode.UNAUTHORIZED: 401,
    ErrorCode.FORBIDDEN: 403,
    ErrorCode.RATE_LIMITED: 429,
    ErrorCode.CONFLICT: 409,
    ErrorCode.INTERNAL_ERROR: 500,
}
