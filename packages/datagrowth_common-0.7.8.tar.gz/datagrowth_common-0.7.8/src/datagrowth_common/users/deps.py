"""Dependency factory `make_require_permission`.

Cachea los permisos efectivos del usuario en `request.state` durante el
request (no entre requests) para evitar repetir la query si una ruta
declara la dep mas de una vez.
"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

from fastapi import Depends, HTTPException, Request, status

from ..api.errors import ErrorCode
from ..auth.supabase import SupabaseUser
from .permissions import PermissionCatalog
from .repository import DbProtocol, effective_permissions


def make_require_permission(
    permission: str,
    *,
    catalog: PermissionCatalog,
    actor_dep: Callable[..., SupabaseUser],
    db_dep: Callable[..., DbProtocol],
    schema: str = "",
) -> Callable[..., SupabaseUser]:
    """Factory: devuelve una FastAPI dep que exige `permission`.

    Deniega 403 por defecto. Cachea el set de permisos por request.
    """
    if permission not in catalog.keys():
        raise ValueError(f"permission-not-in-catalog: {permission!r}")

    def _dep(
        request: Request,
        user: SupabaseUser = Depends(actor_dep),
        db: DbProtocol = Depends(db_dep),
    ) -> SupabaseUser:
        cache_attr = "_dg_perms_cache"
        cached: dict[str, set[str]] = getattr(request.state, cache_attr, {})
        perms = cached.get(user.id)
        if perms is None:
            result, exc = effective_permissions(db, user.id, schema=schema)
            if exc is not None or result is None:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail={
                        "code": ErrorCode.INTERNAL_ERROR.value,
                        "message": "permissions-lookup-failed",
                    },
                )
            perms = result
            cached[user.id] = perms
            setattr(request.state, cache_attr, cached)

        if permission not in perms:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "code": ErrorCode.FORBIDDEN.value,
                    "message": f"missing-permission:{permission}",
                },
            )
        return user

    return _dep


__all__ = ["make_require_permission"]
