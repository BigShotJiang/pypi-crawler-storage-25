"""Modulo de gestion de usuarios + RBAC reutilizable.

Vease `datagrowth_common.users.router.make_users_router` para el contrato
publico. La migracion SQL esta en `migrations/001_users_rbac.sql`.
"""
from .audit import (
    ACTION_CREATE_PASSWORD,
    ACTION_DELETE,
    ACTION_INVITE,
    ACTION_PASSWORD_RESET_SENT,
    ACTION_ROLE_CREATED,
    ACTION_ROLE_DELETED,
    ACTION_ROLE_GRANT,
    ACTION_ROLE_PERMISSIONS_UPDATED,
    ACTION_ROLE_REVOKE,
    log_audit,
)
from .bootstrap import bootstrap_roles
from .deps import make_require_permission
from .models import (
    AuditEntry,
    Role,
    RoleWithPermissions,
    UserListItem,
    UserRoleAssignment,
)
from .permissions import PermissionCatalog
from .repository import (
    DbProtocol,
    effective_permissions,
    list_user_roles,
    list_user_roles_bulk,
    set_user_roles,
)
from .router import make_users_router


__all__ = [
    "ACTION_CREATE_PASSWORD",
    "ACTION_DELETE",
    "ACTION_INVITE",
    "ACTION_PASSWORD_RESET_SENT",
    "ACTION_ROLE_CREATED",
    "ACTION_ROLE_DELETED",
    "ACTION_ROLE_GRANT",
    "ACTION_ROLE_PERMISSIONS_UPDATED",
    "ACTION_ROLE_REVOKE",
    "AuditEntry",
    "DbProtocol",
    "PermissionCatalog",
    "Role",
    "RoleWithPermissions",
    "UserListItem",
    "UserRoleAssignment",
    "bootstrap_roles",
    "effective_permissions",
    "list_user_roles",
    "list_user_roles_bulk",
    "log_audit",
    "make_require_permission",
    "make_users_router",
    "set_user_roles",
]
