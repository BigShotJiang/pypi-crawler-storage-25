"""Factory `make_users_router` para montar el panel de usuarios en una app.

Uso:

    from datagrowth_common.users import PermissionCatalog, make_users_router

    CATALOG = PermissionCatalog({"users.manage": "Gestionar usuarios", ...})

    app.include_router(make_users_router(
        catalog=CATALOG,
        require_permission_dep=require_permission(CATALOG, "users.manage", db_dep),
        actor_dep=require_supabase_jwt,
        db_dep=get_db_session,
        mount_prefix="/admin/users",
        schema="backend",            # control plane usa schema 'backend'
        templates=jinja_templates,   # Jinja2Templates con dg/admin/users_panel.html
    ))

Toda mutacion + audit van en la misma transaccion. El router hace
`db.commit()` al final del handler; si algo falla, llama `db.rollback()`.
"""
from __future__ import annotations

from collections.abc import Callable
from typing import Any

import re as _re

from fastapi import APIRouter, Depends, Form, HTTPException, Query, Request, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, EmailStr, Field, field_validator

from ..api.errors import (
    ApiResponse,
    ErrorBody,
    ErrorCode,
    err_response,
    ok_response,
)
from ..auth.supabase import SupabaseUser
from . import service
from .models import AuditEntry, Role, RoleWithPermissions, UserListItem
from .permissions import PermissionCatalog
from .repository import DbProtocol


# ---------------------------------------------------------------------------
# Bodies
# ---------------------------------------------------------------------------


_SLUG_PATTERN = r"^[a-z][a-z0-9_-]{0,63}$"
# Pydantic v2 usa regex Rust (sin look-ahead); validamos password con un
# field_validator que comprueba longitud + mayuscula + digito.
_PASSWORD_RE_UPPER = _re.compile(r"[A-Z]")
_PASSWORD_RE_DIGIT = _re.compile(r"\d")


def _check_password(value: str) -> str:
    if not (8 <= len(value) <= 128):
        raise ValueError("password-length-8-128")
    if not _PASSWORD_RE_UPPER.search(value):
        raise ValueError("password-missing-uppercase")
    if not _PASSWORD_RE_DIGIT.search(value):
        raise ValueError("password-missing-digit")
    return value


class InviteBody(BaseModel):
    email: EmailStr = Field(..., max_length=254)
    role_slugs: list[str] = Field(default_factory=list, max_length=32)
    redirect_to: str | None = Field(default=None, max_length=2048)


class CreatePasswordBody(BaseModel):
    email: EmailStr = Field(..., max_length=254)
    password: str = Field(..., min_length=8, max_length=128)
    role_slugs: list[str] = Field(default_factory=list, max_length=32)

    @field_validator("password")
    @classmethod
    def _validate_password(cls, value: str) -> str:
        return _check_password(value)


class UpdateRolesBody(BaseModel):
    role_slugs: list[str] = Field(default_factory=list, max_length=32)


class CreateRoleBody(BaseModel):
    slug: str = Field(..., pattern=_SLUG_PATTERN, max_length=64)
    label: str = Field(..., min_length=1, max_length=120)
    permissions: list[str] = Field(default_factory=list, max_length=128)


class UpdateRolePermissionsBody(BaseModel):
    permissions: list[str] = Field(default_factory=list, max_length=128)


class SetPasswordBody(BaseModel):
    password: str = Field(..., min_length=8, max_length=128)

    @field_validator("password")
    @classmethod
    def _validate_password(cls, value: str) -> str:
        return _check_password(value)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _internal(message: str, details: dict[str, Any] | None = None) -> ApiResponse[Any]:
    return err_response(ErrorCode.INTERNAL_ERROR, message, details)


def _commit_or_rollback(db: Any, ok_value: Any) -> ApiResponse[Any]:
    """Commit la transaccion del handler; si falla, rollback."""
    try:
        db.commit()
    except Exception as exc:
        if hasattr(db, "rollback"):
            db.rollback()
        return _internal("commit-failed", {"reason": str(exc)})
    return ok_response(ok_value)


def _rollback(db: Any) -> None:
    if hasattr(db, "rollback"):
        try:
            db.rollback()
        except Exception:  # noqa: BLE001 — best-effort
            pass


def _exc_to_response(exc: Exception) -> ApiResponse[Any]:
    msg = str(exc)
    if msg in {"role-in-use", "role-is-system"}:
        return err_response(ErrorCode.CONFLICT, msg)
    if msg == "role-not-found":
        return err_response(ErrorCode.NOT_FOUND, msg)
    if msg.startswith("unknown-permissions"):
        return err_response(ErrorCode.VALIDATION_ERROR, msg)
    return _internal(msg or "unknown-error")


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def make_users_router(
    *,
    catalog: PermissionCatalog,
    require_permission_dep: Callable[..., SupabaseUser],
    actor_dep: Callable[..., SupabaseUser],
    db_dep: Callable[..., DbProtocol],
    mount_prefix: str = "/admin/users",
    schema: str = "",
    templates: Any = None,
    template_name: str = "dg/admin/users_panel.html",
    audit_enabled: bool = True,
) -> APIRouter:
    """Construye el router. Los deps `require_permission_dep`, `actor_dep` y
    `db_dep` los proporciona la app host.

    `require_permission_dep` se usa para todas las rutas (asume `users.manage`
    o equivalente). `actor_dep` extrae el `SupabaseUser` actual para audit y
    `granted_by`.
    """
    router = APIRouter(prefix=mount_prefix, tags=["users"])

    Dep = Depends  # alias para brevedad

    # ----- HTML page --------------------------------------------------------

    @router.get("", response_class=HTMLResponse)
    def panel_page(
        request: Request,
        _user: SupabaseUser = Dep(require_permission_dep),
    ) -> HTMLResponse:
        if templates is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="templates-not-configured",
            )
        return templates.TemplateResponse(
            request,
            template_name,
            {
                "mount_prefix": mount_prefix,
                "catalog": catalog.labels(),
            },
        )

    # ----- Listado ----------------------------------------------------------

    @router.get("/data", response_model=ApiResponse[dict])
    async def list_users(
        limit: int = Query(default=20, ge=1, le=100),
        offset: int = Query(default=0, ge=0),
        db: DbProtocol = Dep(db_dep),
        _user: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[dict]:
        result, exc = await service.list_users_combined(
            db, limit=limit, offset=offset, schema=schema,
        )
        if exc is not None or result is None:
            return _exc_to_response(exc or RuntimeError("list-failed"))
        items, total = result
        return ok_response({
            "users": [i.model_dump(mode="json") for i in items],
            "limit": limit, "offset": offset, "total": total,
        })

    # ----- Crear ------------------------------------------------------------

    @router.post("/invite", response_model=ApiResponse[SupabaseUser], status_code=201)
    async def invite(
        body: InviteBody,
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[SupabaseUser]:
        user, exc = await service.invite_user(
            db, actor=actor, email=body.email,
            role_slugs=body.role_slugs, redirect_to=body.redirect_to,
            schema=schema,
        )
        if exc is not None or user is None:
            _rollback(db)
            return _exc_to_response(exc or RuntimeError("invite-failed"))
        return _commit_or_rollback(db, user)

    @router.post("/create", response_model=ApiResponse[SupabaseUser], status_code=201)
    async def create_with_password(
        body: CreatePasswordBody,
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[SupabaseUser]:
        user, exc = await service.create_user_password(
            db, actor=actor, email=body.email, password=body.password,
            role_slugs=body.role_slugs, schema=schema,
        )
        if exc is not None or user is None:
            _rollback(db)
            return _exc_to_response(exc or RuntimeError("create-failed"))
        return _commit_or_rollback(db, user)

    # ----- Modificar --------------------------------------------------------

    @router.patch("/{user_id}/roles", response_model=ApiResponse[dict])
    def update_roles(
        user_id: str,
        body: UpdateRolesBody,
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[dict]:
        diff, exc = service.update_user_roles(
            db, actor=actor, target_user_id=user_id,
            role_slugs=body.role_slugs, schema=schema,
        )
        if exc is not None or diff is None:
            _rollback(db)
            return _exc_to_response(exc or RuntimeError("update-failed"))
        granted, revoked = diff
        return _commit_or_rollback(db, {
            "granted": sorted(granted), "revoked": sorted(revoked),
        })

    @router.post("/{user_id}/password/reset", response_model=ApiResponse[dict])
    async def password_reset(
        user_id: str,
        email: str = Form(..., max_length=254),
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[dict]:
        _, exc = await service.send_password_reset(
            db, actor=actor, target_user_id=user_id, email=email,
            schema=schema,
        )
        if exc is not None:
            _rollback(db)
            return _exc_to_response(exc)
        return _commit_or_rollback(db, {"sent": True})

    @router.post("/{user_id}/password/set", response_model=ApiResponse[dict])
    async def password_set(
        user_id: str,
        body: SetPasswordBody,
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[dict]:
        _, exc = await service.set_user_password(
            db, actor=actor, target_user_id=user_id, password=body.password,
            schema=schema,
        )
        if exc is not None:
            _rollback(db)
            return _exc_to_response(exc)
        return _commit_or_rollback(db, {"set": True})

    @router.delete("/{user_id}", response_model=ApiResponse[dict])
    async def delete_user_endpoint(
        user_id: str,
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[dict]:
        _, exc = await service.delete_user(
            db, actor=actor, target_user_id=user_id, schema=schema,
        )
        if exc is not None:
            _rollback(db)
            return _exc_to_response(exc)
        return _commit_or_rollback(db, {"deleted": user_id})

    # ----- Permisos efectivos ----------------------------------------------

    @router.get("/{user_id}/effective-permissions", response_model=ApiResponse[dict])
    def effective(
        user_id: str,
        db: DbProtocol = Dep(db_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[dict]:
        perms, exc = service.effective_permissions_for(db, user_id, schema=schema)
        if exc is not None or perms is None:
            return _exc_to_response(exc or RuntimeError("effective-failed"))
        return ok_response({
            "user_id": user_id,
            "permissions": [
                {"key": p, "label": catalog.label(p)} for p in sorted(perms)
            ],
        })

    # ----- Roles ------------------------------------------------------------

    @router.get("/roles", response_model=ApiResponse[list[RoleWithPermissions]])
    def list_roles(
        db: DbProtocol = Dep(db_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[list[RoleWithPermissions]]:
        roles, exc = service.list_roles(db, schema=schema)
        if exc is not None or roles is None:
            return _exc_to_response(exc or RuntimeError("list-roles-failed"))
        return ok_response(roles)

    @router.post("/roles", response_model=ApiResponse[RoleWithPermissions], status_code=201)
    def create_role(
        body: CreateRoleBody,
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[RoleWithPermissions]:
        role, exc = service.create_role(
            db,
            actor=actor,
            role=Role(slug=body.slug, label=body.label, is_system=False),
            permissions=body.permissions,
            catalog=catalog,
            schema=schema,
        )
        if exc is not None or role is None:
            _rollback(db)
            return _exc_to_response(exc or RuntimeError("create-role-failed"))
        return _commit_or_rollback(db, role)

    @router.patch("/roles/{slug}/permissions",
                  response_model=ApiResponse[RoleWithPermissions])
    def update_role_perms(
        slug: str,
        body: UpdateRolePermissionsBody,
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[RoleWithPermissions]:
        role, exc = service.update_role_permissions(
            db, actor=actor, slug=slug, permissions=body.permissions,
            catalog=catalog, schema=schema,
        )
        if exc is not None or role is None:
            _rollback(db)
            return _exc_to_response(exc or RuntimeError("update-role-perms-failed"))
        return _commit_or_rollback(db, role)

    @router.delete("/roles/{slug}", response_model=ApiResponse[dict])
    def delete_role_endpoint(
        slug: str,
        db: DbProtocol = Dep(db_dep),
        actor: SupabaseUser = Dep(actor_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[dict]:
        _, exc = service.delete_role(db, actor=actor, slug=slug, schema=schema)
        if exc is not None:
            _rollback(db)
            return _exc_to_response(exc)
        return _commit_or_rollback(db, {"deleted": slug})

    # ----- Audit ------------------------------------------------------------

    @router.get("/audit", response_model=ApiResponse[dict])
    def list_audit(
        target_user_id: str | None = Query(default=None, max_length=64),
        actor_id: str | None = Query(default=None, max_length=64),
        action: str | None = Query(default=None, max_length=64),
        limit: int = Query(default=20, ge=1, le=100),
        offset: int = Query(default=0, ge=0),
        db: DbProtocol = Dep(db_dep),
        _admin: SupabaseUser = Dep(require_permission_dep),
    ) -> ApiResponse[dict]:
        result, exc = service.list_audit(
            db,
            target_user_id=target_user_id, actor_id=actor_id, action=action,
            limit=limit, offset=offset, schema=schema,
        )
        if exc is not None or result is None:
            return _exc_to_response(exc or RuntimeError("list-audit-failed"))
        entries, total = result
        return ok_response({
            "entries": [e.model_dump(mode="json") for e in entries],
            "limit": limit, "offset": offset, "total": total,
        })

    return router


__all__ = ["make_users_router"]
