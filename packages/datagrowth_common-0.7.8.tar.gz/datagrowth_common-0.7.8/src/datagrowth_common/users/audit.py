"""Helper de audit log: una llamada con la accion canonica + metadata."""
from __future__ import annotations

from typing import Any

from ..result import Result
from .models import AuditEntry
from .repository import DbProtocol, insert_audit


# Acciones canonicas (lista cerrada para que el UI las renderice consistentemente).
ACTION_INVITE = "invite"
ACTION_CREATE_PASSWORD = "create_password"
ACTION_ROLE_GRANT = "role_grant"
ACTION_ROLE_REVOKE = "role_revoke"
ACTION_PASSWORD_RESET_SENT = "password_reset_sent"
ACTION_PASSWORD_SET = "password_set"
ACTION_DELETE = "delete"
ACTION_ROLE_CREATED = "role_created"
ACTION_ROLE_DELETED = "role_deleted"
ACTION_ROLE_PERMISSIONS_UPDATED = "role_permissions_updated"


def log_audit(
    db: DbProtocol,
    *,
    actor_id: str | None,
    target_user_id: str,
    action: str,
    metadata: dict[str, Any] | None = None,
    schema: str = "",
) -> Result[None]:
    """Inserta una entrada de audit en la misma transaccion del caller."""
    return insert_audit(
        db,
        AuditEntry(
            actor_id=actor_id,
            target_user_id=target_user_id,
            action=action,
            metadata=metadata or {},
        ),
        schema=schema,
    )
