-- Datagrowth users/RBAC: roles, asignaciones de usuarios, asignaciones de
-- permisos a roles, y audit log. El catálogo de permisos vive en el código
-- de la app (PermissionCatalog), por eso no hay tabla `permission`.
--
-- Las apps cliente aplican esta migración tal cual sobre el schema
-- por defecto (público). El control plane la aplica dentro del schema
-- `backend` (ver app-backend/infra/migrations/v43_users_rbac.sql).

create table if not exists role (
    slug         text primary key,
    label        text not null,
    is_system    boolean not null default false,
    created_at   timestamptz not null default now()
);

create table if not exists user_role (
    user_id      uuid not null,
    role_slug    text not null references role(slug) on delete cascade,
    granted_by   uuid,
    granted_at   timestamptz not null default now(),
    primary key (user_id, role_slug)
);
create index if not exists user_role_role_slug_idx on user_role (role_slug);

create table if not exists role_permission (
    role_slug    text not null references role(slug) on delete cascade,
    permission   text not null,
    primary key (role_slug, permission)
);

create table if not exists user_audit_log (
    id              bigserial primary key,
    actor_id        uuid,
    target_user_id  uuid not null,
    action          text not null,
    metadata        jsonb not null default '{}'::jsonb,
    created_at      timestamptz not null default now()
);
create index if not exists user_audit_log_target_idx
    on user_audit_log (target_user_id, created_at desc);
create index if not exists user_audit_log_created_idx
    on user_audit_log (created_at desc);
