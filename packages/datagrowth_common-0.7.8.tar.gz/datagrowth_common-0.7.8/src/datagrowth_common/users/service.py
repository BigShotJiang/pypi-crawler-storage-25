"""Operaciones de alto nivel: combinan Supabase Admin API + tablas locales.

Cada operacion mutadora hace su trabajo + escribe audit en la misma sesion
DB. Si la mutacion DB falla, la transaccion del caller se debe revertir
(el caller es responsable del commit/rollback).

Importante: el caller hace `db.commit()`. Esto es deliberado: el router
agrupa el flujo (mutacion + audit) en una transaccion atomica.
"""
from __future__ import annotations

from typing import Any

from ..auth import supabase_admin
from ..auth.supabase import SupabaseUser
from ..result import Result, err, ok
from . import audit as audit_mod
from .permissions import PermissionCatalog
from .repository import (
    DbProtocol,
    delete_role as repo_delete_role,
    delete_user_assignments,
    effective_permissions as repo_effective_permissions,
    get_role as repo_get_role,
    list_audit as repo_list_audit,
    list_roles as repo_list_roles,
    list_user_roles_bulk,
    set_role_permissions,
    set_user_roles,
    upsert_role,
)
from .models import AuditEntry, Role, RoleWithPermissions, UserListItem


# ---------------------------------------------------------------------------
# Listado combinado
# ---------------------------------------------------------------------------


async def list_users_combined(
    db: DbProtocol,
    *,
    limit: int = 20,
    offset: int = 0,
    schema: str = "",
) -> Result[tuple[list[UserListItem], int]]:
    """Lista usuarios de Supabase + sus roles desde BD local. Sin N+1."""
    page, exc = await supabase_admin.list_users(limit=limit, offset=offset)
    if exc is not None or page is None:
        return err(exc or RuntimeError("list-users-failed"))

    users = page.data
    user_ids = [u.id for u in users]
    roles_map, exc = list_user_roles_bulk(db, user_ids, schema=schema)
    if exc is not None or roles_map is None:
        return err(exc or RuntimeError("list-user-roles-bulk-failed"))

    items = [
        UserListItem(
            id=u.id,
            email=u.email,
            role_slugs=roles_map.get(u.id, []),
            # last_sign_in_at / created_at vienen del raw, no estan en SupabaseUser
            # (extender SupabaseUser implicaria romper compat; lo dejamos en
            # otra pasada si se necesita).
        )
        for u in users
    ]
    return ok((items, page.meta.total))


# ---------------------------------------------------------------------------
# Crear usuarios
# ---------------------------------------------------------------------------


async def _compensate_supabase_create(user_id: str) -> None:
    """Best-effort: borra el usuario recien creado en Supabase si la BD falla.

    No es atomico: si el delete tambien falla, queda huerfano. En ese caso
    el siguiente intento de invitar al mismo email dara error "already
    exists" y un admin debera borrarlo a mano desde Supabase. Logueamos
    el outcome para que sea trazable.
    """
    from ..logger import get_logger

    _, exc = await supabase_admin.delete_user(user_id)
    log = get_logger(__name__)
    if exc is not None:
        log.error(
            "supabase_compensation_failed",
            user_id=user_id, error=str(exc),
        )
    else:
        log.warning("supabase_user_rolled_back", user_id=user_id)


async def invite_user(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    email: str,
    role_slugs: list[str],
    redirect_to: str | None = None,
    schema: str = "",
) -> Result[SupabaseUser]:
    """No atomico: Supabase crea el usuario antes de tocar la BD. Si la BD
    falla, intentamos `_compensate_supabase_create` (best-effort)."""
    user, exc = await supabase_admin.invite_user_by_email(
        email, redirect_to=redirect_to,
    )
    if exc is not None or user is None:
        return err(exc or RuntimeError("invite-failed"))

    _, exc = set_user_roles(
        db, user.id, role_slugs, granted_by=actor.id, schema=schema,
    )
    if exc is not None:
        await _compensate_supabase_create(user.id)
        return err(exc)

    _, exc = audit_mod.log_audit(
        db,
        actor_id=actor.id,
        target_user_id=user.id,
        action=audit_mod.ACTION_INVITE,
        metadata={"email": email, "roles": sorted(role_slugs)},
        schema=schema,
    )
    if exc is not None:
        await _compensate_supabase_create(user.id)
        return err(exc)
    return ok(user)


async def create_user_password(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    email: str,
    password: str,
    role_slugs: list[str],
    schema: str = "",
) -> Result[SupabaseUser]:
    """No atomico: ver nota en `invite_user`."""
    user, exc = await supabase_admin.create_user_with_password(
        email, password, email_confirm=True,
    )
    if exc is not None or user is None:
        return err(exc or RuntimeError("create-failed"))

    _, exc = set_user_roles(
        db, user.id, role_slugs, granted_by=actor.id, schema=schema,
    )
    if exc is not None:
        await _compensate_supabase_create(user.id)
        return err(exc)

    _, exc = audit_mod.log_audit(
        db,
        actor_id=actor.id,
        target_user_id=user.id,
        action=audit_mod.ACTION_CREATE_PASSWORD,
        metadata={"email": email, "roles": sorted(role_slugs)},
        schema=schema,
    )
    if exc is not None:
        await _compensate_supabase_create(user.id)
        return err(exc)
    return ok(user)


# ---------------------------------------------------------------------------
# Modificar usuarios
# ---------------------------------------------------------------------------


def update_user_roles(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    target_user_id: str,
    role_slugs: list[str],
    schema: str = "",
) -> Result[tuple[set[str], set[str]]]:
    diff, exc = set_user_roles(
        db, target_user_id, role_slugs, granted_by=actor.id, schema=schema,
    )
    if exc is not None or diff is None:
        return err(exc or RuntimeError("set-user-roles-failed"))
    granted, revoked = diff
    for slug in sorted(granted):
        _, exc = audit_mod.log_audit(
            db, actor_id=actor.id, target_user_id=target_user_id,
            action=audit_mod.ACTION_ROLE_GRANT, metadata={"role": slug},
            schema=schema,
        )
        if exc is not None:
            return err(exc)
    for slug in sorted(revoked):
        _, exc = audit_mod.log_audit(
            db, actor_id=actor.id, target_user_id=target_user_id,
            action=audit_mod.ACTION_ROLE_REVOKE, metadata={"role": slug},
            schema=schema,
        )
        if exc is not None:
            return err(exc)
    return ok(diff)


async def send_password_reset(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    target_user_id: str,
    email: str,
    redirect_to: str | None = None,
    schema: str = "",
) -> Result[None]:
    _, exc = await supabase_admin.send_password_reset(email, redirect_to=redirect_to)
    if exc is not None:
        return err(exc)
    _, exc = audit_mod.log_audit(
        db,
        actor_id=actor.id,
        target_user_id=target_user_id,
        action=audit_mod.ACTION_PASSWORD_RESET_SENT,
        metadata={"email": email},
        schema=schema,
    )
    if exc is not None:
        return err(exc)
    return ok(None)


async def set_user_password(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    target_user_id: str,
    password: str,
    schema: str = "",
) -> Result[None]:
    """Fija contrasena server-side a un usuario existente. Audit log incluido.

    No envia email al usuario; el admin se la entrega por canal seguro.
    """
    _, exc = await supabase_admin.set_user_password(target_user_id, password)
    if exc is not None:
        return err(exc)
    _, exc = audit_mod.log_audit(
        db,
        actor_id=actor.id,
        target_user_id=target_user_id,
        action=audit_mod.ACTION_PASSWORD_SET,
        schema=schema,
    )
    if exc is not None:
        return err(exc)
    return ok(None)


async def delete_user(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    target_user_id: str,
    schema: str = "",
) -> Result[None]:
    _, exc = await supabase_admin.delete_user(target_user_id)
    if exc is not None:
        return err(exc)
    _, exc = delete_user_assignments(db, target_user_id, schema=schema)
    if exc is not None:
        return err(exc)
    _, exc = audit_mod.log_audit(
        db, actor_id=actor.id, target_user_id=target_user_id,
        action=audit_mod.ACTION_DELETE, schema=schema,
    )
    if exc is not None:
        return err(exc)
    return ok(None)


# ---------------------------------------------------------------------------
# Roles
# ---------------------------------------------------------------------------


def list_roles(db: DbProtocol, *, schema: str = "") -> Result[list[RoleWithPermissions]]:
    return repo_list_roles(db, schema=schema)


def create_role(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    role: Role,
    permissions: list[str],
    catalog: PermissionCatalog,
    schema: str = "",
) -> Result[RoleWithPermissions]:
    known, unknown = catalog.validate(permissions)
    if unknown:
        return err(ValueError(f"unknown-permissions: {sorted(unknown)}"))
    _, exc = upsert_role(db, role, schema=schema)
    if exc is not None:
        return err(exc)
    _, exc = set_role_permissions(db, role.slug, known, schema=schema)
    if exc is not None:
        return err(exc)
    _, exc = audit_mod.log_audit(
        db,
        actor_id=actor.id,
        target_user_id=actor.id,  # no hay "target user" en cambios de rol
        action=audit_mod.ACTION_ROLE_CREATED,
        metadata={"role": role.slug, "permissions": sorted(known)},
        schema=schema,
    )
    if exc is not None:
        return err(exc)

    full, exc = repo_get_role(db, role.slug, schema=schema)
    if exc is not None or full is None:
        return err(exc or RuntimeError("role-disappeared-after-create"))
    return ok(full)


def update_role_permissions(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    slug: str,
    permissions: list[str],
    catalog: PermissionCatalog,
    schema: str = "",
) -> Result[RoleWithPermissions]:
    known, unknown = catalog.validate(permissions)
    if unknown:
        return err(ValueError(f"unknown-permissions: {sorted(unknown)}"))
    _, exc = set_role_permissions(db, slug, known, schema=schema)
    if exc is not None:
        return err(exc)
    _, exc = audit_mod.log_audit(
        db, actor_id=actor.id, target_user_id=actor.id,
        action=audit_mod.ACTION_ROLE_PERMISSIONS_UPDATED,
        metadata={"role": slug, "permissions": sorted(known)},
        schema=schema,
    )
    if exc is not None:
        return err(exc)
    full, exc = repo_get_role(db, slug, schema=schema)
    if exc is not None or full is None:
        return err(exc or RuntimeError("role-not-found"))
    return ok(full)


def delete_role(
    db: DbProtocol,
    *,
    actor: SupabaseUser,
    slug: str,
    schema: str = "",
) -> Result[None]:
    role, exc = repo_get_role(db, slug, schema=schema)
    if exc is not None:
        return err(exc)
    if role is None:
        return err(ValueError("role-not-found"))
    if role.is_system:
        return err(ValueError("role-is-system"))
    _, exc = repo_delete_role(db, slug, schema=schema)
    if exc is not None:
        return err(exc)
    _, exc = audit_mod.log_audit(
        db, actor_id=actor.id, target_user_id=actor.id,
        action=audit_mod.ACTION_ROLE_DELETED,
        metadata={"role": slug}, schema=schema,
    )
    if exc is not None:
        return err(exc)
    return ok(None)


# ---------------------------------------------------------------------------
# Permisos efectivos
# ---------------------------------------------------------------------------


def effective_permissions_for(
    db: DbProtocol, user_id: str, *, schema: str = "",
) -> Result[set[str]]:
    return repo_effective_permissions(db, user_id, schema=schema)


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------


def list_audit(
    db: DbProtocol,
    *,
    target_user_id: str | None = None,
    actor_id: str | None = None,
    action: str | None = None,
    limit: int = 20,
    offset: int = 0,
    schema: str = "",
) -> Result[tuple[list[AuditEntry], int]]:
    return repo_list_audit(
        db,
        target_user_id=target_user_id, actor_id=actor_id, action=action,
        limit=limit, offset=offset, schema=schema,
    )
