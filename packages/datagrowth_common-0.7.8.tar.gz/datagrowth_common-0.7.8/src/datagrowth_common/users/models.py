"""Modelos Pydantic para la capa de usuarios/RBAC.

La libreria NO depende de SQLAlchemy/SQLModel para mantenerse delgada.
La capa de persistencia (repository) recibe una conexion DB-API compatible
(`psycopg.Connection` o un objeto SQLModel `Session` adaptado mediante
`DbProtocol`), y devuelve estos modelos.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


_SLUG_PATTERN = r"^[a-z][a-z0-9_-]{0,63}$"


class Role(BaseModel):
    slug: str = Field(..., pattern=_SLUG_PATTERN, max_length=64)
    label: str = Field(..., min_length=1, max_length=120)
    is_system: bool = False
    created_at: datetime | None = None


class RoleWithPermissions(Role):
    permissions: list[str] = Field(default_factory=list)


class UserRoleAssignment(BaseModel):
    user_id: str
    role_slug: str
    granted_by: str | None = None
    granted_at: datetime | None = None


class AuditEntry(BaseModel):
    id: int | None = None
    actor_id: str | None = None
    target_user_id: str
    action: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime | None = None


class UserListItem(BaseModel):
    """Vista combinada de Supabase Auth + asignaciones locales."""

    id: str
    email: str | None = None
    last_sign_in_at: datetime | None = None
    email_confirmed_at: datetime | None = None
    created_at: datetime | None = None
    role_slugs: list[str] = Field(default_factory=list)
