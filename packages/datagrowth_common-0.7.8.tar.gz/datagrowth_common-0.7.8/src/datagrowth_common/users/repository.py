"""Acceso a tablas `role`, `user_role`, `role_permission`, `user_audit_log`.

Usa SQLAlchemy `text()` con bind params nombrados (`:name`). Funciona con
`sqlmodel.Session`, `sqlalchemy.orm.Session` o `sqlalchemy.Connection`. Las
queries son siempre parametrizadas (regla de seguridad: nunca concatenar
input del usuario).

El nombre del schema (`schema`) se cuelga delante del nombre de tabla y se
valida contra una whitelist regex porque SQL no permite parametrizar
identificadores. Sin el chequeo seria una via de SQL injection.
"""
from __future__ import annotations

import json
import re
from collections.abc import Iterable, Sequence
from typing import Any, Protocol

from ..result import Result, err, ok
from .models import (
    AuditEntry,
    Role,
    RoleWithPermissions,
)


_IDENT_RE = re.compile(r"^[a-z_][a-z0-9_]{0,62}$")


def _ident(schema: str, table: str) -> str:
    """Compone `schema.table` validando ambos identificadores."""
    if not _IDENT_RE.match(table):
        raise ValueError(f"invalid-table-name: {table!r}")
    if not schema:
        return table
    if not _IDENT_RE.match(schema):
        raise ValueError(f"invalid-schema-name: {schema!r}")
    return f"{schema}.{table}"


class DbProtocol(Protocol):
    """Conexion SQLAlchemy (Session/Connection) que expone `execute`."""

    def execute(self, clause: Any, params: Any | None = ...) -> Any: ...


def _exec(db: DbProtocol, sql: str, params: dict[str, Any] | None = None) -> Any:
    from sqlalchemy import text

    return db.execute(text(sql), params or {})


# ---------------------------------------------------------------------------
# Roles
# ---------------------------------------------------------------------------


def list_roles(db: DbProtocol, *, schema: str = "") -> Result[list[RoleWithPermissions]]:
    try:
        t_role = _ident(schema, "role")
        t_rp = _ident(schema, "role_permission")
        role_rows = list(_exec(
            db,
            f"select slug, label, is_system, created_at from {t_role} order by slug",
        ))
        perm_rows = list(_exec(
            db, f"select role_slug, permission from {t_rp}",
        ))
    except Exception as exc:
        return err(exc)

    by_role: dict[str, list[str]] = {}
    for slug, permission in perm_rows:
        by_role.setdefault(slug, []).append(permission)

    out = [
        RoleWithPermissions(
            slug=slug, label=label, is_system=is_system, created_at=created_at,
            permissions=sorted(by_role.get(slug, [])),
        )
        for slug, label, is_system, created_at in role_rows
    ]
    return ok(out)


def get_role(db: DbProtocol, slug: str, *, schema: str = "") -> Result[RoleWithPermissions | None]:
    try:
        t_role = _ident(schema, "role")
        t_rp = _ident(schema, "role_permission")
        row = _exec(
            db,
            f"select slug, label, is_system, created_at from {t_role} where slug = :slug",
            {"slug": slug},
        ).first()
        if row is None:
            return ok(None)
        perms = [
            r[0] for r in _exec(
                db,
                f"select permission from {t_rp} where role_slug = :slug",
                {"slug": slug},
            )
        ]
    except Exception as exc:
        return err(exc)
    return ok(RoleWithPermissions(
        slug=row[0], label=row[1], is_system=row[2], created_at=row[3],
        permissions=sorted(perms),
    ))


def upsert_role(db: DbProtocol, role: Role, *, schema: str = "") -> Result[None]:
    try:
        t = _ident(schema, "role")
        _exec(
            db,
            f"insert into {t} (slug, label, is_system) values (:slug, :label, :is_system) "
            f"on conflict (slug) do update set label = excluded.label, "
            f"is_system = excluded.is_system",
            {"slug": role.slug, "label": role.label, "is_system": role.is_system},
        )
    except Exception as exc:
        return err(exc)
    return ok(None)


def delete_role(db: DbProtocol, slug: str, *, schema: str = "") -> Result[None]:
    try:
        t_role = _ident(schema, "role")
        t_ur = _ident(schema, "user_role")
        in_use = (_exec(
            db,
            f"select count(*) from {t_ur} where role_slug = :slug",
            {"slug": slug},
        ).first() or (0,))[0]
        if in_use:
            return err(ValueError("role-in-use"))
        _exec(db, f"delete from {t_role} where slug = :slug", {"slug": slug})
    except Exception as exc:
        return err(exc)
    return ok(None)


# ---------------------------------------------------------------------------
# Permisos por rol
# ---------------------------------------------------------------------------


def set_role_permissions(
    db: DbProtocol, slug: str, permissions: Iterable[str], *, schema: str = "",
) -> Result[None]:
    try:
        t = _ident(schema, "role_permission")
        _exec(db, f"delete from {t} where role_slug = :slug", {"slug": slug})
        for perm in sorted(set(permissions)):
            _exec(
                db,
                f"insert into {t} (role_slug, permission) values (:slug, :perm)",
                {"slug": slug, "perm": perm},
            )
    except Exception as exc:
        return err(exc)
    return ok(None)


def prune_unknown_permissions(
    db: DbProtocol, known: Iterable[str], *, schema: str = "",
) -> Result[int]:
    """Elimina filas `role_permission.permission` que ya no estan en el catalogo.

    Catalog vacio es un error: "borrar todo" nunca es la operacion correcta
    en produccion (si el catalogo se vacia por bug de import, se cargarian
    los datos). Para resetear permisos hay que pasar el catalogo al menos
    con un permiso y luego borrar a mano.
    """
    valid = list(known)
    if not valid:
        return err(ValueError("empty-catalog-refusing-to-prune"))
    try:
        from sqlalchemy import bindparam, text

        t = _ident(schema, "role_permission")
        stmt = text(
            f"delete from {t} where permission not in :perms"
        ).bindparams(bindparam("perms", expanding=True))
        result = db.execute(stmt, {"perms": valid})
        deleted = getattr(result, "rowcount", 0) or 0
    except Exception as exc:
        return err(exc)
    return ok(int(deleted))


# ---------------------------------------------------------------------------
# Usuario ↔ rol
# ---------------------------------------------------------------------------


def list_user_roles(db: DbProtocol, user_id: str, *, schema: str = "") -> Result[list[str]]:
    try:
        t = _ident(schema, "user_role")
        rows = _exec(
            db,
            f"select role_slug from {t} where user_id = :uid order by role_slug",
            {"uid": user_id},
        )
        return ok([r[0] for r in rows])
    except Exception as exc:
        return err(exc)


def list_user_roles_bulk(
    db: DbProtocol, user_ids: Sequence[str], *, schema: str = "",
) -> Result[dict[str, list[str]]]:
    """Sin N+1: una query devuelve roles para todos los user_ids."""
    if not user_ids:
        return ok({})
    try:
        from sqlalchemy import bindparam, text

        t = _ident(schema, "user_role")
        stmt = text(
            f"select user_id, role_slug from {t} "
            f"where user_id in :uids order by user_id, role_slug"
        ).bindparams(bindparam("uids", expanding=True))
        rows = db.execute(stmt, {"uids": list(user_ids)}).fetchall()
    except Exception as exc:
        return err(exc)
    out: dict[str, list[str]] = {str(uid): [] for uid in user_ids}
    for uid, slug in rows:
        out.setdefault(str(uid), []).append(slug)
    return ok(out)


def set_user_roles(
    db: DbProtocol, user_id: str, role_slugs: Iterable[str],
    *, granted_by: str | None = None, schema: str = "",
) -> Result[tuple[set[str], set[str]]]:
    """Sincroniza asignaciones a `role_slugs`. Devuelve `(granted, revoked)`.

    No comprueba existencia de roles — la FK on insert lo hace.
    """
    try:
        t = _ident(schema, "user_role")
        target = set(role_slugs)
        current, exc = list_user_roles(db, user_id, schema=schema)
        if exc is not None or current is None:
            return err(exc or RuntimeError("list_user_roles-empty"))
        current_set = set(current)
        to_grant = target - current_set
        to_revoke = current_set - target
        for slug in sorted(to_revoke):
            _exec(
                db,
                f"delete from {t} where user_id = :uid and role_slug = :slug",
                {"uid": user_id, "slug": slug},
            )
        for slug in sorted(to_grant):
            _exec(
                db,
                f"insert into {t} (user_id, role_slug, granted_by) "
                f"values (:uid, :slug, :by)",
                {"uid": user_id, "slug": slug, "by": granted_by},
            )
    except Exception as exc:
        return err(exc)
    return ok((to_grant, to_revoke))


def delete_user_assignments(
    db: DbProtocol, user_id: str, *, schema: str = "",
) -> Result[None]:
    try:
        t = _ident(schema, "user_role")
        _exec(db, f"delete from {t} where user_id = :uid", {"uid": user_id})
    except Exception as exc:
        return err(exc)
    return ok(None)


# ---------------------------------------------------------------------------
# Permisos efectivos
# ---------------------------------------------------------------------------


def effective_permissions(
    db: DbProtocol, user_id: str, *, schema: str = "",
) -> Result[set[str]]:
    """Una sola query, sin N+1."""
    try:
        t_ur = _ident(schema, "user_role")
        t_rp = _ident(schema, "role_permission")
        rows = _exec(
            db,
            f"select distinct rp.permission from {t_rp} rp "
            f"join {t_ur} ur on ur.role_slug = rp.role_slug "
            f"where ur.user_id = :uid",
            {"uid": user_id},
        )
        return ok({r[0] for r in rows})
    except Exception as exc:
        return err(exc)


# ---------------------------------------------------------------------------
# Audit log
# ---------------------------------------------------------------------------


def insert_audit(
    db: DbProtocol, entry: AuditEntry, *, schema: str = "",
) -> Result[None]:
    try:
        t = _ident(schema, "user_audit_log")
        _exec(
            db,
            f"insert into {t} (actor_id, target_user_id, action, metadata) "
            f"values (:actor, :target, :action, cast(:meta as jsonb))",
            {
                "actor": entry.actor_id,
                "target": entry.target_user_id,
                "action": entry.action,
                "meta": json.dumps(entry.metadata, default=str),
            },
        )
    except Exception as exc:
        return err(exc)
    return ok(None)


def list_audit(
    db: DbProtocol,
    *,
    target_user_id: str | None = None,
    actor_id: str | None = None,
    action: str | None = None,
    limit: int = 20,
    offset: int = 0,
    schema: str = "",
) -> Result[tuple[list[AuditEntry], int]]:
    try:
        t = _ident(schema, "user_audit_log")
        where: list[str] = []
        params: dict[str, Any] = {}
        if target_user_id:
            where.append("target_user_id = :target")
            params["target"] = target_user_id
        if actor_id:
            where.append("actor_id = :actor")
            params["actor"] = actor_id
        if action:
            where.append("action = :action")
            params["action"] = action
        where_sql = (" where " + " and ".join(where)) if where else ""

        total = int((_exec(
            db, f"select count(*) from {t}{where_sql}", params,
        ).first() or (0,))[0])

        rows = _exec(
            db,
            f"select id, actor_id, target_user_id, action, metadata, created_at "
            f"from {t}{where_sql} order by created_at desc, id desc "
            f"limit :limit offset :offset",
            {**params, "limit": limit, "offset": offset},
        ).fetchall()
    except Exception as exc:
        return err(exc)

    entries = [
        AuditEntry(
            id=r[0],
            actor_id=str(r[1]) if r[1] else None,
            target_user_id=str(r[2]),
            action=r[3],
            metadata=r[4] if isinstance(r[4], dict) else {},
            created_at=r[5],
        )
        for r in rows
    ]
    return ok((entries, total))


__all__ = [
    "DbProtocol",
    "delete_role",
    "delete_user_assignments",
    "effective_permissions",
    "get_role",
    "insert_audit",
    "list_audit",
    "list_roles",
    "list_user_roles",
    "list_user_roles_bulk",
    "prune_unknown_permissions",
    "set_role_permissions",
    "set_user_roles",
    "upsert_role",
]
