"""Catalogo de permisos declarado en codigo por cada app.

Los permisos son strings opacos (`runs.read`, `clients.write`, etc.). La BD
solo guarda asignaciones (`role_permission`); el catalogo nunca se persiste,
para no obligar a una migracion cada vez que se anade un permiso. La app
declara su catalogo en codigo y se lo pasa al router de usuarios.
"""
from __future__ import annotations

import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass

_PERMISSION_RE = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$")


@dataclass(frozen=True)
class PermissionCatalog:
    """Catalogo inmutable de permisos validos para una app.

    Construye con `PermissionCatalog({"runs.read": "Ver runs", ...})`. Las
    claves deben matchear `[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+` (recurso.accion).
    """

    _labels: Mapping[str, str]

    def __init__(self, labels: Mapping[str, str]) -> None:
        for key in labels:
            if not _PERMISSION_RE.match(key):
                raise ValueError(f"invalid-permission-key: {key!r}")
        object.__setattr__(self, "_labels", dict(labels))

    def keys(self) -> frozenset[str]:
        return frozenset(self._labels.keys())

    def label(self, key: str) -> str:
        return self._labels.get(key, key)

    def labels(self) -> dict[str, str]:
        return dict(self._labels)

    def validate(self, perms: Iterable[str]) -> tuple[set[str], set[str]]:
        """Particiona `perms` en `(conocidos, desconocidos)` segun el catalogo."""
        known: set[str] = set()
        unknown: set[str] = set()
        valid = self.keys()
        for p in perms:
            (known if p in valid else unknown).add(p)
        return known, unknown
