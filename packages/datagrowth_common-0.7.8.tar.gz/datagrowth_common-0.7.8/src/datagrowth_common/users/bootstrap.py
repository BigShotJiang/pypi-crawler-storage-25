"""Bootstrap idempotente de roles del sistema + limpieza de permisos huerfanos.

Se llama una vez al startup de cada app. Idempotente: re-ejecutar no rompe
nada. Limpia `role_permission` de permisos que ya no existen en el catalogo.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping

from ..result import Result, err, ok
from .models import Role
from .permissions import PermissionCatalog
from .repository import (
    DbProtocol,
    prune_unknown_permissions,
    set_role_permissions,
    upsert_role,
)


SystemRoleSpec = Mapping[str, object]
"""{"label": "Admin", "permissions": iterable[str]}"""


def bootstrap_roles(
    db: DbProtocol,
    *,
    system_roles: Mapping[str, SystemRoleSpec],
    catalog: PermissionCatalog,
    schema: str = "",
) -> Result[None]:
    """Crea/actualiza roles del sistema con sus permisos. Idempotente."""
    valid = catalog.keys()
    for slug, spec in system_roles.items():
        label = str(spec.get("label", slug.title()))
        raw_perms: Iterable[str] = spec.get("permissions", [])  # type: ignore[assignment]
        perms = [p for p in raw_perms if p in valid]
        unknown = set(raw_perms) - set(perms)
        if unknown:
            return err(ValueError(
                f"system-role {slug!r} declares unknown permissions: {sorted(unknown)}"
            ))

        _, exc = upsert_role(
            db,
            Role(slug=slug, label=label, is_system=True),
            schema=schema,
        )
        if exc is not None:
            return err(exc)
        _, exc = set_role_permissions(db, slug, perms, schema=schema)
        if exc is not None:
            return err(exc)

    _, exc = prune_unknown_permissions(db, valid, schema=schema)
    if exc is not None:
        return err(exc)
    return ok(None)
