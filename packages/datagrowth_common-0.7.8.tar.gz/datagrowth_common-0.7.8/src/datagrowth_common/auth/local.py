"""DEPRECATED alias: `datagrowth_common.auth.local` → `auth.session_hmac`.

En v0.3.0 el archivo se renombró a `session_hmac.py` y se eliminó toda la
integración con Authentik (OIDC, magic link, password reset, register).
Solo se conserva la cookie HMAC de sesión propia.

Importar desde aquí emite `DeprecationWarning`. Se eliminará en v0.4.0.
"""
from __future__ import annotations

import warnings

warnings.warn(
    "datagrowth_common.auth.local is deprecated since v0.3.0; "
    "use datagrowth_common.auth.session_hmac instead. "
    "Authentik OIDC helpers (password_login, refresh_token, userinfo, "
    "start_oidc, oidc_callback, register_local, magic_link_request, "
    "password_reset, TokenPair, OidcStart) were removed; use "
    "datagrowth_common.auth.router + datagrowth_common.auth.supabase.",
    DeprecationWarning,
    stacklevel=2,
)

from .session_hmac import (  # noqa: E402,F401
    SessionCookie,
    SessionDep,
    SessionUser,
    clear_session_cookie,
    decode_session,
    encode_session,
    make_session,
    require_group,
    require_session,
    set_session_cookie,
)

__all__ = [
    "SessionCookie",
    "SessionDep",
    "SessionUser",
    "clear_session_cookie",
    "decode_session",
    "encode_session",
    "make_session",
    "require_group",
    "require_session",
    "set_session_cookie",
]
