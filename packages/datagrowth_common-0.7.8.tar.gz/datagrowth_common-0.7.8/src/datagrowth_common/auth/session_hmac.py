"""Cookie de sesion firmada con HMAC (legacy interno, sin dependencia externa).

A diferencia de `auth.session` (que guarda el JWT de Supabase en la cookie),
este modulo firma un payload propio con HMAC-SHA256 y `DG_SESSION_SECRET`.
Se mantiene como fallback para apps internas que no usan Supabase Auth y
para los tests que cubren el round-trip de cookie. Toda la integracion
contra Authentik (OIDC, magic link, password reset) se elimino en v0.3.0;
el flujo de auth real vive en `auth.session` + `auth.router` (Supabase).

Variables de entorno requeridas:
- DG_SESSION_SECRET     — secreto HMAC para firmar la cookie (>=32 bytes).
- DG_SESSION_COOKIE     — opcional, default `dg_session`.
- DG_SESSION_TTL_SEC    — opcional, default 86400 (24h).

Las funciones publicas devuelven `Result[T]` (patron de error del proyecto)
para no lanzar excepciones a traves de la frontera de modulo.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import time
from typing import Annotated

from fastapi import Cookie, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, Field

from ..result import Result, err, ok

_DEFAULT_COOKIE = "dg_session"
_DEFAULT_TTL = 86400


# ── Modelos ───────────────────────────────────────────────────────────────


class SessionUser(BaseModel):
    user_id: str
    email: str
    groups: list[str] = Field(default_factory=list)
    issued_at: int
    expires_at: int


# ── Cookie firmada (HMAC) ─────────────────────────────────────────────────


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    pad = "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(data + pad)


def _sign(payload: bytes, secret: bytes) -> str:
    return _b64url_encode(hmac.new(secret, payload, hashlib.sha256).digest())


def _get_secret() -> bytes:
    secret = os.getenv("DG_SESSION_SECRET", "")
    if len(secret) < 32:
        # No leak: mensaje generico. La validacion concreta vive en boot.
        raise RuntimeError("DG_SESSION_SECRET missing or too short")
    return secret.encode("utf-8")


def encode_session(user: SessionUser) -> Result[str]:
    """Serializa `user` a `payload.signature` (cookie value)."""
    try:
        secret = _get_secret()
        body = user.model_dump_json().encode("utf-8")
        body_b64 = _b64url_encode(body)
        sig = _sign(body_b64.encode("ascii"), secret)
        return ok(f"{body_b64}.{sig}")
    except Exception as e:  # pragma: no cover — boot-time misconfig
        return err(e)


def decode_session(value: str) -> Result[SessionUser]:
    """Valida firma + expiracion. No lanza, devuelve Result."""
    try:
        body_b64, sig = value.split(".", 1)
    except ValueError:
        return err(ValueError("malformed-session-cookie"))
    try:
        secret = _get_secret()
        expected = _sign(body_b64.encode("ascii"), secret)
        if not hmac.compare_digest(sig, expected):
            return err(ValueError("invalid-session-signature"))
        body = json.loads(_b64url_decode(body_b64))
        user = SessionUser.model_validate(body)
        if user.expires_at < int(time.time()):
            return err(ValueError("session-expired"))
        return ok(user)
    except Exception as e:
        return err(e)


def set_session_cookie(
    response: Response, user: SessionUser, *,
    cookie_name: str | None = None, secure: bool = True,
) -> Result[None]:
    value, exc = encode_session(user)
    if exc or value is None:
        return err(exc or RuntimeError("encode-failed"))
    response.set_cookie(
        key=cookie_name or os.getenv("DG_SESSION_COOKIE", _DEFAULT_COOKIE),
        value=value,
        httponly=True, secure=secure, samesite="lax",
        max_age=user.expires_at - user.issued_at,
        path="/",
    )
    return ok(None)


def clear_session_cookie(response: Response, *, cookie_name: str | None = None) -> None:
    response.delete_cookie(
        key=cookie_name or os.getenv("DG_SESSION_COOKIE", _DEFAULT_COOKIE),
        path="/",
    )


def make_session(user_id: str, email: str, groups: list[str]) -> SessionUser:
    now = int(time.time())
    ttl = int(os.getenv("DG_SESSION_TTL_SEC", str(_DEFAULT_TTL)))
    return SessionUser(
        user_id=user_id, email=email, groups=groups,
        issued_at=now, expires_at=now + ttl,
    )


# ── FastAPI dependency ──────────────────────────────────────────────────


def _cookie_name() -> str:
    return os.getenv("DG_SESSION_COOKIE", _DEFAULT_COOKIE)


async def require_session(request: Request) -> SessionUser:
    """Dependency: lee cookie, valida HMAC + exp. Lanza 401 si falla.

    La excepcion HTTPException es interna a FastAPI (no cruza frontera de
    modulo: el framework la traduce a respuesta).
    """
    raw = request.cookies.get(_cookie_name())
    if not raw:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="no-session")
    user, exc = decode_session(raw)
    if exc or user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid-session",
        )
    return user


def require_group(group: str):
    """Factory de dependency: exige que la sesion contenga `group`."""

    async def _dep(user: Annotated[SessionUser, Depends(require_session)]) -> SessionUser:
        if group not in user.groups:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail=f"missing-group:{group}",
            )
        return user

    return _dep


# Aliases tipados de inyeccion (ergonomia)
SessionDep = Annotated[SessionUser, Depends(require_session)]
SessionCookie = Annotated[str | None, Cookie(alias=_DEFAULT_COOKIE)]


__all__ = [
    "SessionUser",
    "encode_session",
    "decode_session",
    "set_session_cookie",
    "clear_session_cookie",
    "make_session",
    "require_session",
    "require_group",
    "SessionDep",
    "SessionCookie",
]
