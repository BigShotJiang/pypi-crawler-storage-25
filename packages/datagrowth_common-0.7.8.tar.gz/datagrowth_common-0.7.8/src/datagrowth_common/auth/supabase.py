"""Validacion de JWT firmado por Supabase Auth.

Patron: la app valida el JWT que Supabase devuelve al usuario tras login y
extrae claims (sub, email, role). Nunca persiste passwords; Supabase Auth
es la fuente de verdad de usuarios para cada app.

Variables de entorno requeridas:
- SUPABASE_JWT_SECRET — secreto HS256 emitido por Supabase (Project Settings → API).
- SUPABASE_JWT_AUDIENCE — opcional, default `authenticated`.

Las funciones publicas devuelven `Result[T]` para no lanzar a traves de la
frontera de modulo. La FastAPI dep si lanza `HTTPException` (frontera HTTP).
"""
from __future__ import annotations

import os
from typing import Annotated, Any

from fastapi import Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

from ..api.errors import ErrorCode
from ..result import Result, err, ok

_DEFAULT_AUDIENCE = "authenticated"


class SupabaseUser(BaseModel):
    """Claims utiles del JWT de Supabase Auth."""

    id: str  # `sub` del JWT (uuid del usuario en auth.users)
    email: str | None = None
    role: str = "user"  # leido de `app_metadata.role` o claim `role`
    aud: str = _DEFAULT_AUDIENCE
    app_metadata: dict[str, Any] = Field(default_factory=dict)
    user_metadata: dict[str, Any] = Field(default_factory=dict)


def _get_jwt_secret() -> str:
    secret = (os.getenv("SUPABASE_JWT_SECRET") or "").strip()
    if not secret:
        raise RuntimeError("SUPABASE_JWT_SECRET missing")
    return secret


def _get_audience() -> str:
    """Devuelve la audience configurada o el default Supabase.

    Trata cualquier valor vacío/whitespace como "no configurado".
    `os.getenv("X", D)` devuelve D solo si la var NO existe; si la
    var está definida pero vacía, devuelve `""`. Easypanel
    materializa `SUPABASE_JWT_AUDIENCE=` (vacío) cuando el operador
    no la rellena, lo que rompe `jwt.decode(audience="")` con
    "Audience doesn't match" aunque el JWT del Supabase tenga el
    claim `aud:"authenticated"` correcto.
    """
    raw = (os.getenv("SUPABASE_JWT_AUDIENCE") or "").strip()
    return raw or _DEFAULT_AUDIENCE


def _claims_to_user(claims: dict[str, Any]) -> SupabaseUser:
    app_meta = claims.get("app_metadata") or {}
    user_meta = claims.get("user_metadata") or {}
    role = (
        app_meta.get("role")
        or claims.get("role")
        or "user"
    )
    return SupabaseUser(
        id=str(claims.get("sub", "")),
        email=claims.get("email"),
        role=str(role),
        aud=str(claims.get("aud", _DEFAULT_AUDIENCE)),
        app_metadata=app_meta if isinstance(app_meta, dict) else {},
        user_metadata=user_meta if isinstance(user_meta, dict) else {},
    )


def verify_supabase_jwt(
    token: str,
    *,
    jwt_secret: str | None = None,
    audience: str | None = None,
) -> Result[SupabaseUser]:
    """Valida firma HS256 + `exp` + `aud` y devuelve `SupabaseUser`.

    `jwt_secret` y `audience` permiten override en tests; en produccion
    se leen de env (`SUPABASE_JWT_SECRET`, `SUPABASE_JWT_AUDIENCE`).
    """
    try:
        import jwt  # type: ignore[import]
    except ImportError as exc:
        return err(ImportError(
            "pyjwt no esta instalado. Ejecuta: pip install datagrowth-common[supabase]"
        ))

    if not token:
        return err(ValueError("missing-token"))
    try:
        secret = jwt_secret if jwt_secret is not None else _get_jwt_secret()
        aud = audience if audience is not None else _get_audience()
        claims = jwt.decode(
            token,
            secret,
            algorithms=["HS256"],
            audience=aud,
            options={"require": ["exp", "sub"]},
        )
    except Exception as exc:  # ExpiredSignatureError, InvalidAudienceError, etc.
        return err(exc)

    if "sub" not in claims:
        return err(ValueError("missing-sub-claim"))
    return ok(_claims_to_user(claims))


def _extract_bearer(request: Request) -> str | None:
    header = request.headers.get("authorization") or request.headers.get("Authorization")
    if not header or not header.lower().startswith("bearer "):
        return None
    return header[7:].strip() or None


def require_supabase_jwt(request: Request) -> SupabaseUser:
    """FastAPI dep: extrae `Authorization: Bearer <token>` y valida JWT."""
    token = _extract_bearer(request)
    if token is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": ErrorCode.UNAUTHORIZED.value, "message": "missing-bearer-token"},
        )
    user, exc = verify_supabase_jwt(token)
    if exc is not None or user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": ErrorCode.UNAUTHORIZED.value, "message": "invalid-token"},
        )
    return user


SupabaseUserDep = Annotated[SupabaseUser, Depends(require_supabase_jwt)]


def require_role(role: str):
    """Factory de dep: usuario debe tener `app_metadata.role == role`."""

    def _dep(user: SupabaseUserDep) -> SupabaseUser:
        if user.role != role:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"code": ErrorCode.FORBIDDEN.value, "message": "insufficient-role"},
            )
        return user

    return _dep
