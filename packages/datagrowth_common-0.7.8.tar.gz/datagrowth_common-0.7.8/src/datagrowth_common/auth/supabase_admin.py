"""Wrappers de Supabase Admin API con patron `Result`.

El SDK `supabase-py` expone metodos sincronos. Aqui los envolvemos en
`asyncio.to_thread` para no bloquear el event loop de FastAPI.

Requiere SUPABASE_URL + SUPABASE_SERVICE_ROLE_KEY en el entorno (la
service_role key salta la RLS — NO exponer al frontend).
"""
from __future__ import annotations

import asyncio
from typing import Any

from ..api.pagination import Paginated, build_meta
from ..result import Result, err, ok
from ..supabase import get_supabase_admin_client
from .supabase import SupabaseUser


def _user_dict_to_supabase_user(payload: Any) -> SupabaseUser:
    """Mapea un objeto User de supabase-py a `SupabaseUser`."""
    if isinstance(payload, dict):
        data = payload
    else:
        data = getattr(payload, "model_dump", lambda: payload.__dict__)()

    app_meta = data.get("app_metadata") or {}
    user_meta = data.get("user_metadata") or {}
    role = (app_meta.get("role") if isinstance(app_meta, dict) else None) or "user"
    return SupabaseUser(
        id=str(data.get("id", "")),
        email=data.get("email"),
        role=str(role),
        aud=str(data.get("aud", "authenticated")),
        app_metadata=app_meta if isinstance(app_meta, dict) else {},
        user_metadata=user_meta if isinstance(user_meta, dict) else {},
    )


async def list_users(
    *, limit: int = 20, offset: int = 0,
) -> Result[Paginated[SupabaseUser]]:
    """Lista paginada de usuarios via Supabase Admin API.

    `limit` y `offset` se traducen a `per_page`/`page` (Supabase usa pagina 1-based).
    """
    try:
        client = get_supabase_admin_client()
        per_page = max(1, min(int(limit), 100))
        page = (max(0, int(offset)) // per_page) + 1
        result = await asyncio.to_thread(
            client.auth.admin.list_users, page=page, per_page=per_page,
        )
    except Exception as exc:
        return err(exc)

    raw_users = result if isinstance(result, list) else getattr(result, "users", [])
    users = [_user_dict_to_supabase_user(u) for u in raw_users]
    total = getattr(result, "total", None) or len(users) + offset
    return ok(Paginated[SupabaseUser](
        data=users,
        meta=build_meta(total=int(total), limit=per_page, offset=offset),
    ))


async def invite_user_by_email(
    email: str,
    *,
    role: str = "user",
    redirect_to: str | None = None,
) -> Result[SupabaseUser]:
    """Envia email de invitacion. El rol se persiste en `app_metadata.role`."""
    try:
        client = get_supabase_admin_client()
        options: dict[str, Any] = {"data": {"role": role}}
        if redirect_to:
            options["redirect_to"] = redirect_to
        result = await asyncio.to_thread(
            client.auth.admin.invite_user_by_email, email, options,
        )
    except Exception as exc:
        return err(exc)

    user_payload = getattr(result, "user", result)
    return ok(_user_dict_to_supabase_user(user_payload))


async def delete_user(user_id: str) -> Result[None]:
    try:
        client = get_supabase_admin_client()
        await asyncio.to_thread(client.auth.admin.delete_user, user_id)
    except Exception as exc:
        return err(exc)
    return ok(None)


async def update_user_role(user_id: str, role: str) -> Result[SupabaseUser]:
    """Escribe `app_metadata.role` (admin-only). Patrones de email/password no se tocan."""
    try:
        client = get_supabase_admin_client()
        result = await asyncio.to_thread(
            client.auth.admin.update_user_by_id,
            user_id,
            {"app_metadata": {"role": role}},
        )
    except Exception as exc:
        return err(exc)

    user_payload = getattr(result, "user", result)
    return ok(_user_dict_to_supabase_user(user_payload))


# ---------------------------------------------------------------------------
# v0.2.2 — helpers para flujos de gestión completos desde paneles admin
# ---------------------------------------------------------------------------


async def create_user_with_password(
    email: str,
    password: str,
    *,
    role: str = "user",
    email_confirm: bool = True,
) -> Result[SupabaseUser]:
    """Crea un usuario con contraseña fija (admin lo entrega en mano).

    `email_confirm=True` salta el flujo de verificación: el usuario puede
    entrar inmediatamente con la contraseña sin recibir email. Se persiste
    el rol en `app_metadata.role` (mismo patrón que `invite_user_by_email`).
    """
    try:
        client = get_supabase_admin_client()
        payload: dict[str, Any] = {
            "email": email,
            "password": password,
            "email_confirm": email_confirm,
            "app_metadata": {"role": role},
        }
        result = await asyncio.to_thread(client.auth.admin.create_user, payload)
    except Exception as exc:
        return err(exc)

    user_payload = getattr(result, "user", result)
    return ok(_user_dict_to_supabase_user(user_payload))


async def set_user_password(
    user_id: str, password: str,
) -> Result[None]:
    """Fija la contrasena de un usuario existente server-side, sin email.

    Util cuando un admin necesita entregar credenciales en mano (cliente sin
    email accesible). Side-effect: la contrasena anterior queda invalidada.
    """
    try:
        client = get_supabase_admin_client()
        await asyncio.to_thread(
            client.auth.admin.update_user_by_id,
            user_id,
            {"password": password},
        )
    except Exception as exc:
        return err(exc)
    return ok(None)


async def send_password_reset(
    email: str, *, redirect_to: str | None = None,
) -> Result[None]:
    """Genera un link de recuperación; Supabase envía el email por su cuenta.

    Usa `auth.admin.generate_link({type: "recovery"})` que dispara el email
    con la plantilla de recovery configurada en el dashboard. El backend NO
    ve ni propaga el link de reset (la plantilla incluye el `confirmation_url`).
    """
    try:
        client = get_supabase_admin_client()
        payload: dict[str, Any] = {"type": "recovery", "email": email}
        if redirect_to:
            payload["options"] = {"redirect_to": redirect_to}
        await asyncio.to_thread(client.auth.admin.generate_link, payload)
    except Exception as exc:
        return err(exc)
    return ok(None)
