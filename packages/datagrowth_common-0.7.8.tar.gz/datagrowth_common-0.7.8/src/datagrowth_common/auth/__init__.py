"""Helpers de autenticacion para apps Datagrowth (Supabase Auth).

- `supabase`: validacion de JWT firmado por Supabase Auth.
- `supabase_admin`: wrappers async sobre Supabase Admin API (list/invite/delete users).
- `session`: cookie httpOnly server-rendered (`set_session`, `clear_session`,
  `require_session`, `refresh_session_tokens`). Usar en apps Jinja+HTMX.
- `router`: `make_auth_router()` / `auth_router` con endpoints de login propio +
  OAuth + refresh + logout, reutilizable entre el backend interno y las apps cliente.
- `session_hmac`: cookie de sesion firmada con HMAC propio. Solo para apps
  internas que NO usan Supabase Auth (fallback). En v0.2.x se llamaba `local`.

`local` se mantiene como alias deprecated de `session_hmac` (DeprecationWarning).
Eliminado en v0.4.0.
"""
from . import router, session, session_hmac, supabase, supabase_admin

__all__ = ["router", "session", "session_hmac", "supabase", "supabase_admin"]
