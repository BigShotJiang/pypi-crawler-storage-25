"""Router de autenticacion reutilizable: login propio + OAuth + refresh + logout.

La pagina HTML de `/login` la sirve la propia app (cada una con su branding);
este router solo expone los endpoints API y el OAuth callback.

Uso (en `src/main.py` de la app):

    from fastapi.templating import Jinja2Templates
    from datagrowth_common.auth.router import make_auth_router

    auth_router = make_auth_router(post_login_redirect="/")
    app.include_router(auth_router)

Endpoints expuestos:
    POST /auth/password                  -> form email+password, set cookie
    POST /auth/register                  -> sign-up (si AUTH_REGISTRATION=open)
    POST /auth/magic-link/request        -> sign_in_with_otp(email)
    POST /auth/password/reset            -> reset_password_for_email
    GET  /auth/oauth/{provider}/start    -> redirige a Supabase OAuth
    GET  /auth/oauth/{provider}/callback -> exchange code -> set cookie
    POST /auth/refresh                   -> refresca tokens si la cookie caduco
    POST /logout                         -> borra cookie y redirige
    GET  /api/me                         -> SupabaseUser actual (json)

Requiere las envvars:
    SUPABASE_URL, SUPABASE_KEY, SUPABASE_JWT_SECRET (+ optional AUTH_*).
"""
from __future__ import annotations

import os
from typing import Annotated, Any

from fastapi import APIRouter, Form, Query, Request, Response, status
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, EmailStr, Field

from ..api.errors import (
    ApiResponse,
    ErrorCode,
    err_response,
    ok_response,
)
from .session import (
    SessionUserDep,
    clear_session,
    get_session_tokens,
    refresh_session_tokens,
    set_session,
)
from .supabase import SupabaseUser


def _registration_open() -> bool:
    return os.getenv("AUTH_REGISTRATION", "invite_only") == "open"


def _magic_link_enabled() -> bool:
    return os.getenv("AUTH_MAGIC_LINK", "false").lower() == "true"


def _redirect_base() -> str:
    """URL publica de la app, para construir redirect_to del OAuth callback."""
    return os.getenv("DG_APP_URL", "").rstrip("/")


def _session_from_supabase(result: Any) -> dict[str, Any]:
    session = getattr(result, "session", None)
    if session is None:
        return {}
    return {
        "access_token": getattr(session, "access_token", ""),
        "refresh_token": getattr(session, "refresh_token", ""),
    }


class _RefreshBody(BaseModel):
    pass  # refresh lee de cookie, no de body


def make_auth_router(
    *,
    prefix: str = "",
    post_login_redirect: str = "/",
    post_logout_redirect: str = "/login",
    oauth_callback_path_prefix: str = "/auth/oauth",
) -> APIRouter:
    """Construye el APIRouter de auth con redirects configurables.

    El router NO sirve `/login` HTML — eso vive en la app (template propio).
    """
    router = APIRouter(prefix=prefix, tags=["auth"])

    # ── Password (Supabase email/password) ─────────────────────────────

    @router.post("/auth/password", response_class=RedirectResponse)
    async def auth_password(
        email: Annotated[str, Form(min_length=3, max_length=254)],
        password: Annotated[str, Form(min_length=8, max_length=200)],
    ) -> RedirectResponse:
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            result = client.auth.sign_in_with_password(
                {"email": email, "password": password},
            )
        except Exception:
            return RedirectResponse("/login?error=invalid-credentials", status_code=303)
        tokens = _session_from_supabase(result)
        if not tokens.get("access_token"):
            return RedirectResponse("/login?error=invalid-credentials", status_code=303)
        redir = RedirectResponse(post_login_redirect, status_code=303)
        set_session(
            redir,
            access_token=tokens["access_token"],
            refresh_token=tokens.get("refresh_token"),
        )
        return redir

    # ── Register (sign-up) ────────────────────────────────────────────

    @router.post("/auth/register", response_model=ApiResponse)
    async def auth_register(
        email: Annotated[str, Form(min_length=3, max_length=254)],
        password: Annotated[str, Form(min_length=8, max_length=200)],
        name: Annotated[str, Form(min_length=1, max_length=120)] = "",
    ) -> ApiResponse:
        if not _registration_open():
            return err_response(ErrorCode.FORBIDDEN, "registration-closed")
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            client.auth.sign_up({
                "email": email, "password": password,
                "options": {"data": {"name": name}} if name else {},
            })
        except Exception:
            return err_response(ErrorCode.CONFLICT, "register-failed")
        return ok_response({"created": True, "email": email})

    # ── Magic link (OTP via email) ────────────────────────────────────

    @router.post("/auth/magic-link/request", response_model=ApiResponse)
    async def auth_magic_link(
        email: Annotated[str, Form(min_length=3, max_length=254)],
    ) -> ApiResponse:
        if not _magic_link_enabled():
            return err_response(ErrorCode.FORBIDDEN, "magic-link-disabled")
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            client.auth.sign_in_with_otp({"email": email})
        except Exception:
            return err_response(ErrorCode.INTERNAL_ERROR, "magic-link-failed")
        return ok_response({"sent": True})

    # ── Password reset ────────────────────────────────────────────────

    @router.post("/auth/password/reset", response_model=ApiResponse)
    async def auth_password_reset(
        email: Annotated[str, Form(min_length=3, max_length=254)],
    ) -> ApiResponse:
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            client.auth.reset_password_for_email(email)
        except Exception:
            return err_response(ErrorCode.INTERNAL_ERROR, "reset-failed")
        return ok_response({"sent": True})

    # ── OAuth (Microsoft/Google/etc. via Supabase) ───────────────────

    @router.get(f"{oauth_callback_path_prefix}/{{provider}}/start")
    async def auth_oauth_start(
        provider: str, request: Request,
    ) -> RedirectResponse:
        """Redirige al consent de Supabase para el provider OAuth indicado."""
        base = _redirect_base() or str(request.base_url).rstrip("/")
        callback = f"{base}{oauth_callback_path_prefix}/{provider}/callback"
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            result = client.auth.sign_in_with_oauth({
                "provider": provider,
                "options": {"redirect_to": callback},
            })
            url = getattr(result, "url", None)
        except Exception:
            return RedirectResponse(url="/login?error=oauth-start", status_code=303)
        if not url:
            return RedirectResponse(url="/login?error=oauth-start", status_code=303)
        return RedirectResponse(url=str(url), status_code=303)

    @router.get(f"{oauth_callback_path_prefix}/{{provider}}/callback")
    async def auth_oauth_callback(
        provider: str,
        code: Annotated[str, Query(min_length=1, max_length=2048)],
    ) -> RedirectResponse:
        """Canjea el `?code=` por session JWT y guarda cookies."""
        try:
            from ..supabase import get_supabase_client
            client = get_supabase_client()
            result = client.auth.exchange_code_for_session({"auth_code": code})
        except Exception:
            return RedirectResponse(url="/login?error=oauth-exchange", status_code=303)
        tokens = _session_from_supabase(result)
        if not tokens.get("access_token"):
            return RedirectResponse(url="/login?error=oauth-exchange", status_code=303)
        redir = RedirectResponse(post_login_redirect, status_code=303)
        set_session(
            redir,
            access_token=tokens["access_token"],
            refresh_token=tokens.get("refresh_token"),
        )
        return redir

    # ── Refresh ───────────────────────────────────────────────────────

    @router.post("/auth/refresh", response_model=ApiResponse)
    async def auth_refresh(
        request: Request, response: Response,
    ) -> ApiResponse:
        tokens = get_session_tokens(request)
        if tokens is None or not tokens.refresh_token:
            return err_response(ErrorCode.UNAUTHORIZED, "no-refresh-token")
        new_tokens, exc = await refresh_session_tokens(tokens.refresh_token)
        if exc is not None or new_tokens is None:
            return err_response(ErrorCode.UNAUTHORIZED, "refresh-failed")
        set_session(
            response,
            access_token=new_tokens["access_token"],
            refresh_token=new_tokens.get("refresh_token"),
        )
        return ok_response({"refreshed": True})

    # ── Logout ────────────────────────────────────────────────────────

    @router.post("/logout", response_class=RedirectResponse)
    async def logout() -> RedirectResponse:
        redir = RedirectResponse(post_logout_redirect, status_code=303)
        clear_session(redir)
        return redir

    # ── Identity ──────────────────────────────────────────────────────

    @router.get("/api/me", response_model=ApiResponse[SupabaseUser])
    async def me(user: SessionUserDep) -> ApiResponse[SupabaseUser]:
        return ok_response(user)

    return router


# Router por defecto con redirects estandar (post_login → "/").
auth_router = make_auth_router()
