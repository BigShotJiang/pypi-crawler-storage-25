"""Sesion server-rendered: cookie httpOnly que guarda el JWT de Supabase Auth.

Pensado para apps Jinja+HTMX (backend interno de Datagrowth y apps cliente
generadas por el pipeline). El cliente NO maneja JWTs en JS: el backend lee
la cookie en cada request y valida con `verify_supabase_jwt`.

Dos cookies:
- `dg_session`        → access_token (JWT HS256). Se valida en cada request.
- `dg_session_refresh`→ refresh_token. Se usa cuando el access_token caduca.

Ambas son `httpOnly`, `Secure`, `SameSite=Lax`, `Path=/`. El TTL de la cookie
en el navegador no es la fuente de verdad — la fuente es `exp` dentro del JWT.
La cookie se pone con un TTL alto (90 dias) y la sesion termina cuando el
access_token caduca y el refresh_token tampoco vale.

Las funciones publicas devuelven `Result[T]` (patron de error) salvo las
FastAPI deps, que lanzan `HTTPException` (frontera HTTP).
"""
from __future__ import annotations

import os
from typing import Annotated, Any

from fastapi import Depends, HTTPException, Request, Response, status
from pydantic import BaseModel

from ..api.errors import ErrorCode
from ..result import Result, err, ok
from .supabase import SupabaseUser, verify_supabase_jwt

ACCESS_COOKIE = "dg_session"
REFRESH_COOKIE = "dg_session_refresh"
_DEFAULT_MAX_AGE = 60 * 60 * 24 * 90  # 90 dias en el navegador


class SessionTokens(BaseModel):
    access_token: str
    refresh_token: str | None = None


def _cookies_secure() -> bool:
    """`False` solo en development local (DG_ENV=development y sin TLS)."""
    return os.getenv("DG_ENV", "production").lower() != "development"


def set_session(
    response: Response,
    *,
    access_token: str,
    refresh_token: str | None = None,
    max_age: int = _DEFAULT_MAX_AGE,
) -> None:
    """Escribe ambas cookies httpOnly.

    `max_age` aplica al stored TTL del navegador; la validez real la dicta
    el `exp` del JWT (lo comprueba `verify_supabase_jwt` en cada request).
    """
    secure = _cookies_secure()
    response.set_cookie(
        ACCESS_COOKIE, access_token,
        httponly=True, secure=secure, samesite="lax",
        max_age=max_age, path="/",
    )
    if refresh_token:
        response.set_cookie(
            REFRESH_COOKIE, refresh_token,
            httponly=True, secure=secure, samesite="lax",
            max_age=max_age, path="/",
        )


def clear_session(response: Response) -> None:
    """Borra ambas cookies (logout)."""
    response.delete_cookie(ACCESS_COOKIE, path="/")
    response.delete_cookie(REFRESH_COOKIE, path="/")


def get_session_tokens(request: Request) -> SessionTokens | None:
    """Lee ambas cookies del request. `None` si no hay access_token."""
    access = request.cookies.get(ACCESS_COOKIE)
    if not access:
        return None
    return SessionTokens(
        access_token=access,
        refresh_token=request.cookies.get(REFRESH_COOKIE),
    )


def require_session(request: Request) -> SupabaseUser:
    """FastAPI dep: lee cookie `dg_session` y valida JWT Supabase.

    NO refresca aqui — el refresh es un side effect que necesita escribir
    en la response, asi que vive en el endpoint `/auth/refresh` o en un
    middleware. Si el access_token caduca, esta dep devuelve 401 y el
    cliente debe llamar a `/auth/refresh` o re-loguearse.
    """
    tokens = get_session_tokens(request)
    if tokens is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": ErrorCode.UNAUTHORIZED.value, "message": "no-session"},
        )
    user, exc = verify_supabase_jwt(tokens.access_token)
    if exc is not None or user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"code": ErrorCode.UNAUTHORIZED.value, "message": "invalid-session"},
        )
    return user


SessionUserDep = Annotated[SupabaseUser, Depends(require_session)]


# ── Refresh ──────────────────────────────────────────────────────────────


async def refresh_session_tokens(
    refresh_token: str,
) -> Result[dict[str, Any]]:
    """Llama a Supabase Auth para canjear refresh_token por nuevos tokens.

    Devuelve el dict `{"access_token", "refresh_token", "expires_in"}` o un
    error si el refresh_token no vale.
    """
    try:
        from ..supabase import get_supabase_client
        client = get_supabase_client()
        result = client.auth.refresh_session(refresh_token)
    except Exception as exc:
        return err(exc)
    session = getattr(result, "session", None)
    if session is None:
        return err(RuntimeError("no-session-in-refresh-response"))
    return ok({
        "access_token": getattr(session, "access_token", ""),
        "refresh_token": getattr(session, "refresh_token", ""),
        "expires_in": getattr(session, "expires_in", None),
    })
