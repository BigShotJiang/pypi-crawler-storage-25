"""Fixtures pytest reutilizables.

Importables desde tests de cualquier app que use `datagrowth_common`:

    from datagrowth_common.testing import session_secret, signed_session_cookie
"""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from ..auth.session_hmac import SessionUser, encode_session, make_session


@pytest.fixture
def session_secret(monkeypatch: pytest.MonkeyPatch) -> str:
    """Setea DG_SESSION_SECRET para tests. Devuelve el secret usado."""
    secret = "x" * 48
    monkeypatch.setenv("DG_SESSION_SECRET", secret)
    return secret


@pytest.fixture
def signed_session_cookie(session_secret: str) -> tuple[SessionUser, str]:
    """Devuelve `(user, cookie_value)` con sesion valida 24h."""
    user = make_session("user-1", "u@example.com", ["acme-users"])
    value, exc = encode_session(user)
    assert exc is None and value is not None
    return user, value


def mock_supabase_client() -> MagicMock:
    """Mock minimo del client Supabase (chainable .table().select().eq().execute())."""
    client = MagicMock()
    table = MagicMock()
    chain = MagicMock()
    chain.execute.return_value = MagicMock(data=[], count=0)
    chain.eq.return_value = chain
    chain.limit.return_value = chain
    chain.range.return_value = chain
    chain.order.return_value = chain
    table.select.return_value = chain
    table.insert.return_value = chain
    table.update.return_value = chain
    table.delete.return_value = chain
    client.table.return_value = table
    return client
