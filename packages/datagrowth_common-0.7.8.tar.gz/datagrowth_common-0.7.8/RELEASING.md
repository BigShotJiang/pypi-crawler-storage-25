# Release de datagrowth-common

## Pre-requisitos (una sola vez)

1. Configurar **trusted publishing** en PyPI (`https://pypi.org/manage/account/publishing/`):
   - Owner: `Datagrowth`
   - Repository: `datagrowth-common`
   - Workflow: `release.yml`
   - Environment: (vacio)

   No hace falta `PYPI_TOKEN` con trusted publishing. Si por algun motivo
   no se puede usar trusted publishing, alternativa:
   `gh secret set PYPI_TOKEN --body "<token>"` y cambiar el step de publish a
   usar `password: ${{ secrets.PYPI_TOKEN }}`.

2. Permisos en el repo:
   - Settings → Actions → General → Workflow permissions: Read & Write.
   - Branch protection en `main`: requerir PR reviews.

## Release de una version

```bash
# 1. Bump version en pyproject.toml + src/datagrowth_common/__init__.py (__version__).
# 2. Actualizar CHANGELOG.md con los cambios.
# 3. Commit + push a main.
git tag -a v0.2.0 -m "Release 0.2.0: api helpers + auth.local (cookie HMAC + OIDC)"
git push origin v0.2.0
# 4. El workflow .github/workflows/release.yml se dispara automaticamente.
```

## Validacion local antes de tag

```bash
pip install -e ".[dev]"
pytest -q
python -m build
twine check dist/*
```

## Rollback

```bash
# Si el release falla a medias (PyPI parcial), no se puede sobreescribir
# la misma version en PyPI. Bump a 0.2.1 con el fix y re-tag.
git tag -d v0.2.0
git push --delete origin v0.2.0  # solo si NO llego a publicar a PyPI
```

## Consumidores

- `app-backend`: `pyproject.toml` apunta a `datagrowth-common==0.2.*`.
- Skeleton `app-fastapi-supabase`: `pyproject.toml` declara `datagrowth-common==0.2.*`.
- Apps generadas heredan la version del skeleton.
