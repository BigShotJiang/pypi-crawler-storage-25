"""Parsed test YAML file produced by ``scai test seed``."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from .step_types import StepBasedValidation
from .validation_steps import ValidationSteps


@dataclass
class TestFile:
    """A parsed test YAML file produced by ``scai test seed``."""

    file_path: str
    """Absolute path to the YAML file on disk."""

    source: ValidationSteps
    """Source-side execution steps (used by capture)."""

    test_cases: list[list[Any]]
    """List of test cases; each is an array of positional values."""

    target: Optional[ValidationSteps] = None
    """Target-side execution steps (used by validate). Optional."""

    code_unit_name: str = ""
    """Code unit name (procedure or function) resolved from the CUR or artifacts path."""

    parameter_names: list[str] = field(default_factory=list)
    """Parameter names extracted from the source ``run`` template."""

    modifies_data: Optional[bool] = None
    """Override flag indicating this procedure modifies data."""

    affected_tables: Optional[list[str]] = None
    """Override list of affected tables."""

    pk_columns_by_table: dict[str, list[str]] = field(default_factory=dict)
    """Primary key columns per affected table (keyed by SCHEMA.TABLE FQN).

    Populated from CUR ``signature.columns[].isPrimaryKey`` during enrichment.
    Used by ``_resolve_table_configs`` to enable the PK_DIFF delta strategy.
    """

    read_tables: Optional[list[str]] = None
    """Tables this procedure reads from (from CUR dependency closure)."""

    source_checksum: Optional[str] = None
    """BLAKE3 checksum of the source procedure file, computed at test-run time."""

    converted_checksum: Optional[str] = None
    """BLAKE3 checksum of the converted procedure file, computed at test-run time."""

    target_database: Optional[str] = None
    """Target database from CUR (used for clone isolation during validation)."""

    step_validation: Optional[StepBasedValidation] = None
    """Step-based validation definition (v2 schema).

    When set, this file uses the new ``validation.steps`` list format
    instead of the v1 ``source``/``target`` blocks.  The ``source`` field
    is set to a sentinel ``ValidationSteps(run="<step-based>")`` so that
    downstream code which assumes ``source`` is always present does not
    break.  SNOW-3280023 will add runner logic to check this field and
    route to step-based execution.
    """
