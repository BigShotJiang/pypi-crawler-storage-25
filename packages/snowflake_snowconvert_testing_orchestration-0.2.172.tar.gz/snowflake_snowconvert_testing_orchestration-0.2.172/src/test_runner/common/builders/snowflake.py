"""Snowflake dialect SQL builder for step-based execution.

Produces a ``BEGIN ... END`` scripting block with temporary tables for
validated steps, plus post-block ``SELECT * FROM _step_N`` statements
to retrieve results.
"""

from __future__ import annotations

from typing import Any

from ..models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    Step,
    TableStep,
    ValidateCursor,
    ValidateEntry,
    ValidateQuery,
    ValidateResult,
    ValidateSkip,
    ValidateTable,
)
from .common import (
    ensure_semicolon,
    format_snowflake_literal,
    substitute_placeholders,
    substitute_raw_placeholders,
)
from .models import SnowflakeBuiltSQL
from ..models.capture_result import StepOrigin


def _is_call(sql: str) -> bool:
    """Check if a SQL string is a CALL statement."""
    return sql.strip().upper().startswith("CALL ")


def build_snowflake_sql(
    steps: list[Step],
    test_case: list[Any],
) -> SnowflakeBuiltSQL:
    """Build a Snowflake BEGIN/END block from step-based definitions.

    Parameters
    ----------
    steps
        Parsed step objects from ``StepBasedValidation.steps``.
    test_case
        A single test-case value array.
    """
    block_lines: list[str] = []
    result_stmts: list[str] = []
    validated: list[int] = []
    origins: list[StepOrigin] = []

    for i, step in enumerate(steps):
        if isinstance(step.validate, list):
            _build_validate_list_step(
                step, i, test_case,
                block_lines, result_stmts, validated, origins,
            )
        else:
            _build_step(
                step, i, test_case,
                block_lines, result_stmts, validated, origins,
            )

    main_sql = "BEGIN\n" + "".join(block_lines) + "END;\n"

    return SnowflakeBuiltSQL(
        main_sql=main_sql,
        result_stmts=result_stmts,
        validated_step_indices=validated,
        result_step_origins=origins,
    )


def _build_step(
    step: Step,
    index: int,
    test_case: list[Any],
    block_lines: list[str],
    result_stmts: list[str],
    validated: list[int],
    origins: list[StepOrigin],
) -> None:
    """Emit SQL for a single step into the block."""
    prev_len = len(result_stmts)
    if isinstance(step, QueryStep):
        _build_query_step(step, index, test_case,
                          block_lines, result_stmts, validated)
    elif isinstance(step, ParamStep):
        _build_param_step(step, index, block_lines, result_stmts, validated)
    elif isinstance(step, TableStep):
        _build_table_step(step, index, test_case,
                          block_lines, result_stmts, validated)
    elif isinstance(step, CursorStep):
        _build_cursor_step(step, index, test_case,
                           block_lines, result_stmts, validated)
    else:
        raise TypeError(f"Step {index}: unexpected step type {type(step).__name__}")
    # Each result_stmt added by the sub-helper is a simple validate: true step.
    for _ in range(len(result_stmts) - prev_len):
        origins.append(StepOrigin(step_index=index))


def _build_query_step(
    step: QueryStep,
    index: int,
    test_case: list[Any],
    block_lines: list[str],
    result_stmts: list[str],
    validated: list[int],
) -> None:
    if step.target_query is None:
        return
    sql = substitute_placeholders(step.target_query, test_case, format_snowflake_literal)

    if step.validate is False:
        block_lines.append(f"  {ensure_semicolon(sql)}\n")
        return

    if _is_call(sql):
        clean = sql.rstrip().rstrip(";")
        block_lines.append(f"  {clean};\n")
        block_lines.append(
            f"  CREATE OR REPLACE TEMPORARY TABLE _step_{index} AS\n"
            f"    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
        )
    else:
        clean = sql.rstrip().rstrip(";")
        block_lines.append(
            f"  CREATE OR REPLACE TEMPORARY TABLE _step_{index} AS\n    {clean};\n"
        )
    result_stmts.append(f"SELECT * FROM _step_{index}")
    validated.append(index)


def _build_param_step(
    step: ParamStep,
    index: int,
    block_lines: list[str],
    result_stmts: list[str],
    validated: list[int],
) -> None:
    if not step.target_params:
        return
    if step.validate is False:
        raise ValueError(
            f"Step {index}: ParamStep does not support validate: false"
        )
    columns = ", ".join(
        f":{p} AS \"{p}\"" for p in step.target_params
    )
    block_lines.append(
        f"  CREATE OR REPLACE TEMPORARY TABLE _step_{index} AS\n"
        f"    SELECT {columns};\n"
    )
    result_stmts.append(f"SELECT * FROM _step_{index}")
    validated.append(index)


def _build_identifier_step(
    identifier: str,
    step_type_name: str,
    index: int,
    test_case: list[Any],
    block_lines: list[str],
    result_stmts: list[str],
    validated: list[int],
    validate: object,
) -> None:
    """Shared logic for TableStep and CursorStep — both resolve an identifier
    and capture ``SELECT * FROM IDENTIFIER(...)`` into a temp table."""
    if validate is False:
        raise ValueError(
            f"Step {index}: {step_type_name} does not support validate: false"
        )
    resolved = substitute_raw_placeholders(identifier, test_case)
    block_lines.append(
        f"  CREATE OR REPLACE TEMPORARY TABLE _step_{index} AS\n"
        f"    SELECT * FROM IDENTIFIER('{resolved}');\n"
    )
    result_stmts.append(f"SELECT * FROM _step_{index}")
    validated.append(index)


def _build_table_step(
    step: TableStep,
    index: int,
    test_case: list[Any],
    block_lines: list[str],
    result_stmts: list[str],
    validated: list[int],
) -> None:
    if step.target_table is None:
        return
    _build_identifier_step(
        step.target_table, "TableStep", index, test_case,
        block_lines, result_stmts, validated, step.validate,
    )


def _build_cursor_step(
    step: CursorStep,
    index: int,
    test_case: list[Any],
    block_lines: list[str],
    result_stmts: list[str],
    validated: list[int],
) -> None:
    if step.target_cursor is None:
        return
    _build_identifier_step(
        step.target_cursor, "CursorStep", index, test_case,
        block_lines, result_stmts, validated, step.validate,
    )


# ---------------------------------------------------------------------------
# validate: [list] handling
# ---------------------------------------------------------------------------

def _build_validate_list_step(
    step: Step,
    index: int,
    test_case: list[Any],
    block_lines: list[str],
    result_stmts: list[str],
    validated: list[int],
    origins: list[StepOrigin],
) -> None:
    """Handle a step with ``validate: [list]`` (multi-result-set mapping)."""
    if not isinstance(step, QueryStep) or step.target_query is None:
        return

    entries: list[ValidateEntry] = step.validate  # type: ignore[assignment]
    sql = substitute_placeholders(step.target_query, test_case, format_snowflake_literal)

    has_result_entry = any(isinstance(e, ValidateResult) for e in entries)

    if has_result_entry:
        if _is_call(sql):
            clean = sql.rstrip().rstrip(";")
            block_lines.append(f"  {clean};\n")
            block_lines.append(
                f"  CREATE OR REPLACE TEMPORARY TABLE _rs_{index} AS\n"
                f"    SELECT * FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()));\n"
            )
        else:
            clean = sql.rstrip().rstrip(";")
            block_lines.append(
                f"  CREATE OR REPLACE TEMPORARY TABLE _rs_{index} AS\n    {clean};\n"
            )
    else:
        block_lines.append(f"  {ensure_semicolon(sql)}\n")

    for entry_idx, entry in enumerate(entries):
        table_name = f"_step_{index}_v{entry_idx}"
        prev_len = len(result_stmts)
        _build_validate_entry(
            entry, table_name, index, test_case,
            block_lines, result_stmts,
        )
        if len(result_stmts) > prev_len:
            origins.append(StepOrigin(step_index=index, validate_entry=entry_idx))

    validated.append(index)


def _build_validate_entry(
    entry: ValidateEntry,
    table_name: str,
    step_index: int,
    test_case: list[Any],
    block_lines: list[str],
    result_stmts: list[str],
) -> None:
    """Emit SQL for a single validate list entry."""
    if isinstance(entry, ValidateSkip):
        return

    if isinstance(entry, ValidateResult):
        block_lines.append(
            f"  CREATE OR REPLACE TEMPORARY TABLE {table_name} AS\n"
            f"    SELECT * FROM _rs_{step_index};\n"
        )
        result_stmts.append(f"SELECT * FROM {table_name}")

    elif isinstance(entry, ValidateTable):
        table = substitute_raw_placeholders(entry.table, test_case)
        block_lines.append(
            f"  CREATE OR REPLACE TEMPORARY TABLE {table_name} AS\n"
            f"    SELECT * FROM IDENTIFIER('{table}');\n"
        )
        result_stmts.append(f"SELECT * FROM {table_name}")

    elif isinstance(entry, ValidateCursor):
        cursor = substitute_raw_placeholders(entry.cursor, test_case)
        block_lines.append(
            f"  CREATE OR REPLACE TEMPORARY TABLE {table_name} AS\n"
            f"    SELECT * FROM IDENTIFIER('{cursor}');\n"
        )
        result_stmts.append(f"SELECT * FROM {table_name}")

    elif isinstance(entry, ValidateQuery):
        query = substitute_placeholders(entry.target_query, test_case, format_snowflake_literal)
        clean = query.rstrip().rstrip(";")
        block_lines.append(
            f"  CREATE OR REPLACE TEMPORARY TABLE {table_name} AS\n"
            f"    {clean};\n"
        )
        result_stmts.append(f"SELECT * FROM {table_name}")
