"""Output models for dialect-specific SQL builders."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from test_runner.common.models.capture_result import StepOrigin


class BuiltSQL(Protocol):
    """Common interface shared by all dialect-specific builder outputs."""

    validated_step_indices: list[int]


@dataclass
class SqlServerBuiltSQL:
    """SQL Server builder output — single batch with boundary markers."""

    main_sql: str
    validated_step_indices: list[int]


@dataclass
class SnowflakeBuiltSQL:
    """Snowflake builder output — BEGIN/END block + post-block result reads."""

    main_sql: str
    result_stmts: list[str]
    validated_step_indices: list[int]
    result_step_origins: list[StepOrigin] = field(default_factory=list)
    """Parallel to ``result_stmts`` — maps each fetch to its originating step."""


@dataclass
class RedshiftBuiltSQL:
    """Redshift builder output — individual statements keyed by step index.

    ParamSteps are absent from ``main_sql`` — the executor checks the step
    type for validated indices with no SQL entry and extracts INOUT params
    from the previous CALL result.
    """

    main_sql: dict[int, str] = field(default_factory=dict)
    validated_step_indices: list[int] = field(default_factory=list)
