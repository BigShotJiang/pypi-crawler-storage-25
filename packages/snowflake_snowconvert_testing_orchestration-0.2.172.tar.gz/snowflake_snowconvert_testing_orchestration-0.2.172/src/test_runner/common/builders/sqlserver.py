"""SQL Server dialect SQL builder for step-based execution.

Produces a single batch string with boundary markers between steps.
All steps are concatenated into one ``cursor.execute()`` call.
The executor uses ``cursor.nextset()`` to split results by boundary markers.
"""

from __future__ import annotations

from typing import Any

from ..models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    Step,
    TableStep,
)
from .common import format_sqlserver_literal, substitute_placeholders, substitute_raw_placeholders
from .models import SqlServerBuiltSQL


def _boundary_marker(index: int) -> str:
    return f"SELECT '__STEP_{index}__' AS _boundary;\n"


def _strip_at(name: str) -> str:
    """Strip leading ``@`` from a parameter name for use as a column alias."""
    return name.lstrip("@")


def build_sqlserver_sql(
    steps: list[Step],
    test_case: list[Any],
) -> SqlServerBuiltSQL:
    """Build a single SQL Server batch from step-based definitions.

    Parameters
    ----------
    steps
        Parsed step objects from ``StepBasedValidation.steps``.
    test_case
        A single test-case value array (e.g. ``[1001, "active"]``).
    """
    parts: list[str] = []
    validated: list[int] = []

    for i, step in enumerate(steps):
        sql = _build_step_sql(step, i, test_case)
        if sql is None:
            # One-sided target-only step — skip entirely.
            continue
        parts.append(_boundary_marker(i))
        parts.append(sql)
        if step.validate is not False:
            validated.append(i)

    return SqlServerBuiltSQL(
        main_sql="".join(parts),
        validated_step_indices=validated,
    )


def _build_step_sql(
    step: Step,
    index: int,
    test_case: list[Any],
) -> str | None:
    """Return SQL for a single step, or ``None`` if the step should be skipped."""
    if isinstance(step, QueryStep):
        if step.source_query is None:
            return None
        return substitute_placeholders(step.source_query, test_case, format_sqlserver_literal) + "\n"

    if isinstance(step, ParamStep):
        if not step.source_params:
            return None
        if step.validate is False:
            raise ValueError(
                f"Step {index}: ParamStep does not support validate: false"
            )
        columns = ", ".join(
            f"@{_strip_at(p)} AS [{_strip_at(p)}]" for p in step.source_params
        )
        return f"SELECT {columns};\n"

    if isinstance(step, TableStep):
        if step.source_table is None:
            return None
        if step.validate is False:
            raise ValueError(
                f"Step {index}: TableStep does not support validate: false"
            )
        table = substitute_raw_placeholders(step.source_table, test_case)
        return f"SELECT * FROM {table};\n"

    if isinstance(step, CursorStep):
        raise ValueError(
            f"Step {index}: CursorStep is not supported for SQL Server"
        )

    raise TypeError(f"Step {index}: unexpected step type {type(step).__name__}")
