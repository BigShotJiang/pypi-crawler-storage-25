"""
Upload baseline files to a Snowflake stage.

Uses ``ConnectorSnowflake`` from ``snowflake-data-validation`` to PUT local
baseline JSON files into an internal stage.
"""

from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase

from test_runner.validate.results_writer import create_validation_schema

LOGGER = logging.getLogger(__name__)


class StageUploader:
    """Uploads files to a Snowflake internal stage.

    Args:
        connector: Snowflake connector instance.
        stage: Stage reference (e.g., "@MYDB.MYSCHEMA.BASELINES").
        database: Database name for validation schema creation.
        max_workers: Maximum number of parallel workers for uploads (default: 4).

    Usage::

        uploader = StageUploader(connector, "@MYDB.MYSCHEMA.BASELINES")
        uploader.upload_file(Path("baselines/case_000.json"))
        uploader.close()
    """

    def __init__(
        self,
        connector: ConnectorBase,
        stage: str,
        database: str = "",
        max_workers: int = 4,
    ) -> None:
        self._connector = connector
        self._stage = stage.rstrip("/")
        self._database = database
        self._max_workers = max_workers

    @property
    def connector(self) -> ConnectorBase:
        return self._connector

    def close(self) -> None:
        self._connector.close()

    def __enter__(self) -> StageUploader:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.close()

    # -- upload --------------------------------------------------------------

    def upload_file(self, local_path: Path, stage_subpath: str = "") -> None:
        """PUT a single file to the stage."""
        target = self._stage
        if stage_subpath:
            target = f"{target}/{stage_subpath.strip('/')}"

        put_sql = f"PUT 'file://{local_path}' '{target}/' AUTO_COMPRESS=FALSE OVERWRITE=TRUE PARALLEL=10"
        self._connector.execute_statement(put_sql)

    def upload_directory(self, local_dir: Path, stage_subpath: str = "") -> int:
        """PUT all ``*.json`` files under *local_dir* to the stage.

        Ensures the validation schema exists first, preserves the relative
        directory structure (procedure subdirectories), and returns
        the number of files uploaded.

        Uses parallel uploads for maximum throughput:
        - PARALLEL=10 on each PUT command for intra-command parallelism
        - ThreadPoolExecutor to upload multiple procedures concurrently

        The local_dir is typically a date-specific directory like:
          .scai/baselines/20260407/
        which contains procedure subdirectories:
          .scai/baselines/20260407/procedure_name/case_*.json
        """
        if self._database:
            try:
                create_validation_schema(self._connector, self._database)
            except Exception:
                pass

        local_base = Path(local_dir)

        # Find all procedure directories under the local_dir
        proc_dirs = [p for p in local_base.iterdir() if p.is_dir()]

        if not proc_dirs:
            LOGGER.warning("No procedure directories found in %s", local_base)
            return 0

        def upload_procedure(proc_dir: Path) -> int:
            """Upload a single procedure directory to the stage."""
            # Build target path preserving procedure hierarchy
            # stage_subpath already contains the date folder (e.g., "20260407")
            target = self._stage
            if stage_subpath:
                target = f"{target}/{stage_subpath.strip('/')}"
            target = f"{target}/{proc_dir.name}"

            put_sql = f"PUT 'file://{proc_dir}/*.json' '{target}/' AUTO_COMPRESS=FALSE OVERWRITE=TRUE PARALLEL=10"
            self._connector.execute_statement(put_sql)

            # Count files in this procedure directory
            return sum(1 for _ in proc_dir.glob("*.json"))

        # Upload procedures in parallel using thread pool
        # Use min(max_workers, proc_count) to avoid creating unnecessary threads
        max_workers = min(self._max_workers, len(proc_dirs))
        total_count = 0

        LOGGER.info("Uploading %d procedures with %d parallel workers", len(proc_dirs), max_workers)

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all upload tasks
            future_to_proc = {
                executor.submit(upload_procedure, proc_dir): proc_dir
                for proc_dir in sorted(proc_dirs)
            }

            # Collect results as they complete
            for future in as_completed(future_to_proc):
                proc_dir = future_to_proc[future]
                try:
                    count = future.result()
                    total_count += count
                    LOGGER.debug("Uploaded %d files from %s", count, proc_dir.name)
                except Exception as exc:
                    LOGGER.error("Failed to upload %s: %s", proc_dir.name, exc)

        LOGGER.info("Uploaded %d files across %d procedures", total_count, len(proc_dirs))
        return total_count
