"""
Capture runner -- orchestrates the full baseline-capture pipeline.

1. Resolve the source executor factory from the injected registry
2. Discover test YAML files from ``artifacts/**/test/*.yml``
3. For each test file / test case:
   a. Render the SQL template with dialect-specific literal formatting
   b. Execute on the source database
   c. Save baseline JSON to disk
4. Optionally upload baselines to a Snowflake stage
5. Insert baseline metadata into VALIDATION.BASELINE_METADATA table for fast validation lookups
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase

from test_runner.common.baseline import write_baseline
from test_runner.common.config import ReplayConfiguration, TestRunnerConfig
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import DatabaseExecutor, DatabaseExecutorFactory
from test_runner.common.dependency_classifier import enrich_test_files
from test_runner.common.discovery import discover_test_files, filter_test_files
from test_runner.common.models import BaselineData, TestCaseStats, TestFile, ValidationSteps
from test_runner.common.builders import build_source_sql
from test_runner.common.template import (
    build_parameters,
    render_capture_sql,
    render_output_fetch_statements,
)
from test_runner.replay.capture_handler import capture_deltas
from test_runner.parallel.partitioner import partition_cases
from test_runner.parallel.executor import ParallelExecutor
from .stage_uploader import StageUploader

LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Console output helpers
# ---------------------------------------------------------------------------

_SEPARATOR = "\u2550" * 60


def _print_header(dialect: str, baseline_dir: str | Path, stage: str = "") -> None:
    print(f"\n{_SEPARATOR}")
    print(f"  CAPTURING BASELINES FROM {dialect.upper()}")
    if stage:
        print(f"  Stage:  {stage}")
    print(f"  Output: {baseline_dir}")
    print(f"{_SEPARATOR}\n")


def _print_case_result(procedure: str, case_idx: int, result: BaselineData) -> None:
    icon = "\u2705" if result.success else "\u274c"
    if result.success:
        parts: list[str] = []
        if result.output_params:
            n = len(result.output_params)
            parts.append(f"{n} output param{'s' if n != 1 else ''}")
        if result.row_counts:
            if len(result.row_counts) == 1:
                parts.append(f"{result.row_counts[0]} rows")
            else:
                total = sum(result.row_counts)
                parts.append(f"{total} rows ({len(result.row_counts)} sets)")
        suffix = ", ".join(parts) if parts else "0 rows"
    else:
        suffix = f"ERROR: {result.error}"
    print(f"{icon} {procedure} (case {case_idx + 1}) -> {suffix}")


def _print_summary(stats: TestCaseStats) -> None:
    print(f"\n{_SEPARATOR}")
    print(f"  CAPTURED {stats.total} BASELINES")
    if stats.failed:
        print(f"  {stats.succeeded} succeeded, {stats.failed} failed")
    print(f"{_SEPARATOR}\n")


# ---------------------------------------------------------------------------
# Baseline metadata table helper
# ---------------------------------------------------------------------------

def _insert_baseline_metadata(
    connector: ConnectorBase,
    database: str,
    baseline_dir: Path,
    date_folder: str,
) -> int:
    """Insert baseline metadata into VALIDATION.BASELINE_METADATA table.

    Reads baseline JSON files from disk and extracts metadata fields
    (procedure, params_hash, success, error, row_counts, table_deltas, etc.)
    to populate a table for fast validation lookups.

    Returns the number of metadata records inserted.
    """
    schema = f"{database}.VALIDATION"
    table_name = f"{schema}.BASELINE_METADATA"

    # Create table if not exists
    create_table_sql = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        procedure VARCHAR,
        params_hash VARCHAR,
        parameters VARIANT,
        captured_at TIMESTAMP_NTZ,
        success BOOLEAN,
        error VARCHAR,
        row_counts ARRAY,
        table_deltas VARIANT,
        column_metadata VARIANT,
        output_params VARIANT,
        output_param_types VARIANT,
        PRIMARY KEY (procedure, params_hash)
    )
    """
    cursor = connector.connection.cursor()
    try:
        cursor.execute(create_table_sql)
    finally:
        cursor.close()

    # Read baseline JSON files from date directory
    date_dir = baseline_dir / date_folder
    if not date_dir.exists():
        LOGGER.warning("Baseline directory not found: %s", date_dir)
        return 0

    baselines_metadata: list[dict[str, Any]] = []

    # Walk through procedure subdirectories
    for proc_dir in date_dir.iterdir():
        if not proc_dir.is_dir():
            continue

        # Read all baseline JSON files in this procedure directory
        for baseline_file in proc_dir.glob("*.json"):
            try:
                with open(baseline_file, "r") as f:
                    baseline = json.load(f)

                # Extract metadata fields
                metadata = {
                    "procedure": baseline.get("procedure", ""),
                    "params_hash": baseline.get("params_hash", ""),
                    "parameters": json.dumps(baseline.get("parameters", {})),
                    "captured_at": baseline.get("captured_at", ""),
                    "success": baseline.get("success", False),
                    "error": baseline.get("error"),
                    "row_counts": json.dumps(baseline.get("row_counts", [])),
                    "table_deltas": json.dumps(baseline.get("table_deltas")) if baseline.get("table_deltas") else None,
                    "column_metadata": json.dumps(baseline.get("column_metadata")) if baseline.get("column_metadata") else None,
                    "output_params": json.dumps(baseline.get("output_params")) if baseline.get("output_params") else None,
                    "output_param_types": json.dumps(baseline.get("output_param_types")) if baseline.get("output_param_types") else None,
                }
                baselines_metadata.append(metadata)
            except Exception as e:
                LOGGER.warning("Failed to read baseline %s: %s", baseline_file, e)

    if not baselines_metadata:
        LOGGER.info("No baseline metadata to insert")
        return 0

    # Batch insert metadata using MERGE to handle duplicates
    LOGGER.info("Inserting %d baseline metadata records into %s", len(baselines_metadata), table_name)

    cursor = connector.connection.cursor()
    try:
        # Create temp table for staging
        temp_table = f"{schema}.BASELINE_METADATA_TEMP_{int(time.time() * 1000)}"
        cursor.execute(f"""
            CREATE TEMPORARY TABLE {temp_table} LIKE {table_name}
        """)

        # Insert into temp table
        insert_sql = f"""
            INSERT INTO {temp_table}
            (procedure, params_hash, parameters, captured_at, success, error,
             row_counts, table_deltas, column_metadata, output_params, output_param_types)
            VALUES (?, ?, PARSE_JSON(?), ?, ?, ?, PARSE_JSON(?), PARSE_JSON(?), PARSE_JSON(?), PARSE_JSON(?), PARSE_JSON(?))
        """

        batch_data = [
            (
                m["procedure"], m["params_hash"], m["parameters"], m["captured_at"],
                m["success"], m["error"], m["row_counts"], m["table_deltas"],
                m["column_metadata"], m["output_params"], m["output_param_types"]
            )
            for m in baselines_metadata
        ]

        cursor.executemany(insert_sql, batch_data)

        # Merge from temp to main table
        merge_sql = f"""
            MERGE INTO {table_name} AS target
            USING {temp_table} AS source
            ON target.procedure = source.procedure AND target.params_hash = source.params_hash
            WHEN MATCHED THEN UPDATE SET
                parameters = source.parameters,
                captured_at = source.captured_at,
                success = source.success,
                error = source.error,
                row_counts = source.row_counts,
                table_deltas = source.table_deltas,
                column_metadata = source.column_metadata,
                output_params = source.output_params,
                output_param_types = source.output_param_types
            WHEN NOT MATCHED THEN INSERT
                (procedure, params_hash, parameters, captured_at, success, error,
                 row_counts, table_deltas, column_metadata, output_params, output_param_types)
            VALUES
                (source.procedure, source.params_hash, source.parameters, source.captured_at,
                 source.success, source.error, source.row_counts, source.table_deltas,
                 source.column_metadata, source.output_params, source.output_param_types)
        """
        cursor.execute(merge_sql)

        LOGGER.info("Successfully inserted/updated %d baseline metadata records", len(baselines_metadata))
        return len(baselines_metadata)
    finally:
        cursor.close()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_capture(
    config: TestRunnerConfig,
    factory_registry: dict[DatabaseDialect, DatabaseExecutorFactory],
    project_root: str | Path,
    baseline_dir: Optional[str | Path] = None,
    snowflake_connection: Optional[str] = None,
    workers: int = 1,
    where: str | None = None,
    include_dependencies: bool = False,
    upload_workers: int | None = None,
) -> TestCaseStats:
    """Execute the full capture pipeline.

    Baselines are always written to disk.  When a Snowflake connection is
    available they are also uploaded to the implicit internal stage
    ``@{validation_database}.VALIDATION.BASELINES`` and materialized
    into the ``BASELINE_ROWS`` table.

    Args:
        config: Loaded test runner configuration.
        factory_registry: Dialect -> factory mapping (injected).
        project_root: Path to the SCAI project root.
        baseline_dir: Override directory for baseline files.
        snowflake_connection: Snowflake connection name for stage upload.
        workers: Number of parallel workers for test execution.
        where: Filter expression for test selection.
        include_dependencies: Include test dependencies.
        upload_workers: Number of parallel workers for stage uploads (defaults to max(workers, 4)).

    Returns:
        :class:`TestCaseStats` with totals and the list of written baseline paths.
    """
    project_root = Path(project_root)
    if upload_workers is None:
        upload_workers = max(workers, 4)

    # -- resolve factory from registry ---------------------------------------
    factory = factory_registry.get(config.source_dialect)
    if factory is None:
        raise ValueError(
            f"No executor factory for dialect '{config.source_dialect.value}'."
        )

    # -- create executor via factory -----------------------------------------
    if not config.source_connection_raw:
        raise ValueError(
            "Capture requires a source connection. Configure a default in "
            "~/.snowflake/snowct/<dialect>.toml or pass --source-connection."
        )
    source_config = factory.build_config(config.source_connection_raw)
    factory.executor = factory.create_executor(source_config)

    factory.format_literal = factory.create_literal_formatter().format_literal

    # -- baseline directory --------------------------------------------------
    # When no override is given, baselines are written per-object next to
    # their test YAML files:  artifacts/**/{name}/baselines/
    # When an explicit override is given, all baselines go to that single dir.
    baseline_dir_override: Optional[Path] = Path(baseline_dir) if baseline_dir is not None else None

    output_display = (
        str(baseline_dir_override)
        if baseline_dir_override is not None
        else f"{project_root / 'artifacts'}/**/baselines"
    )

    capture_date = datetime.now(timezone.utc)

    # -- discover test files -------------------------------------------------
    test_files = discover_test_files(project_root, config.selectors)
    test_files = filter_test_files(test_files, project_root, where, include_dependencies)
    if not test_files:
        print("No test files found in artifacts/**/test/*.yml")
        return TestCaseStats()

    enrich_test_files(test_files, project_root)

    # -- stage uploader (uses provided stage or implicit default) --------------
    uploader: Optional[StageUploader] = None
    stage = f"@{config.validation_database}.VALIDATION.BASELINES"
    sf_factory = factory_registry.get(DatabaseDialect.SNOWFLAKE)
    if sf_factory is not None:
        target_raw = dict(config.target_connection_raw) if config.target_connection_raw else {}
        if snowflake_connection:
            target_raw["name"] = snowflake_connection
        if target_raw.get("name"):
            target_raw.setdefault("mode", "name")
            sf_config = sf_factory.build_config(target_raw)
            sf_executor = sf_factory.create_executor(sf_config)
            if sf_executor.connector is not None:
                uploader = StageUploader(
                    sf_executor.connector,
                    stage,
                    config.validation_database,
                    max_workers=upload_workers,
                )
            else:
                sf_executor.close()

    # -- run -----------------------------------------------------------------
    stats = TestCaseStats()
    start_time = time.perf_counter()

    _print_header(factory.dialect.value, output_display, stage if uploader else "")

    # -- capture phase -------------------------------------------------------
    capture_start = time.perf_counter()
    try:
        if workers > 1:
            _run_parallel_capture(
                test_files=test_files,
                factory=factory,
                source_config=source_config,
                baseline_dir=baseline_dir_override,
                capture_date=capture_date,
                stats=stats,
                replay_cfg=config.replay_configuration,
                workers=workers,
            )
        else:
            for test_file in test_files:
                effective_baseline_dir = (
                    baseline_dir_override
                    if baseline_dir_override is not None
                    else Path(test_file.file_path).parent.parent / "baselines"
                )
                _capture_test_file(
                    test_file=test_file,
                    factory=factory,
                    baseline_dir=effective_baseline_dir,
                    capture_date=capture_date,
                    stats=stats,
                    replay_cfg=config.replay_configuration,
                )
    finally:
        factory.executor.close()

    capture_duration = time.perf_counter() - capture_start
    LOGGER.info("Capture phase completed in %.2f seconds", capture_duration)

    # -- stage upload -----------------------------------------------------------
    upload_duration = 0.0
    if uploader is not None:
        upload_start = time.perf_counter()
        try:
            date_folder = capture_date.strftime("%Y%m%d")
            if baseline_dir_override is not None:
                upload_root = baseline_dir_override / date_folder
                if upload_root.exists():
                    count = uploader.upload_directory(upload_root, date_folder)
                    print(f"\nUploaded {count} baselines to {stage}")
                    try:
                        metadata_count = _insert_baseline_metadata(
                            uploader.connector,
                            config.validation_database,
                            baseline_dir_override,
                            date_folder,
                        )
                        LOGGER.info("Inserted %d baseline metadata records", metadata_count)
                    except Exception as e:
                        LOGGER.error("Failed to insert baseline metadata: %s", e)
                        print(f"Warning: Failed to insert baseline metadata: {e}")
            else:
                total = 0
                for upload_root in sorted(
                    (project_root / "artifacts").glob(f"**/baselines/{date_folder}")
                ):
                    if upload_root.is_dir():
                        total += uploader.upload_directory(upload_root, date_folder)
                        try:
                            metadata_count = _insert_baseline_metadata(
                                uploader.connector,
                                config.validation_database,
                                upload_root.parent,
                                date_folder,
                            )
                            LOGGER.info("Inserted %d baseline metadata records", metadata_count)
                        except Exception as e:
                            LOGGER.error("Failed to insert baseline metadata: %s", e)
                            print(f"Warning: Failed to insert baseline metadata: {e}")
                if total:
                    print(f"\nUploaded {total} baselines to {stage}")
        finally:
            uploader.close()
        upload_duration = time.perf_counter() - upload_start
        LOGGER.info("Upload phase completed in %.2f seconds", upload_duration)

    total_duration = time.perf_counter() - start_time
    LOGGER.info("Total runtime: %.2f seconds (capture: %.2f, upload: %.2f)",
                total_duration, capture_duration, upload_duration)

    _print_summary(stats)
    return stats


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------


@dataclass
class _CaptureResult:
    """Result of capturing a single test case (for parallel aggregation)."""
    success: bool
    baseline_path: str


def _run_parallel_capture(
    test_files: list[TestFile],
    factory: DatabaseExecutorFactory,
    source_config: Any,
    baseline_dir: Optional[Path],
    capture_date: datetime,
    stats: TestCaseStats,
    replay_cfg: ReplayConfiguration | None,
    workers: int,
) -> None:
    """Partition test cases and run read-only captures in parallel.

    DML cases are executed sequentially using the existing
    ``_capture_test_file`` function.
    """
    dialect = factory.dialect.value
    dialect_enum = factory.dialect
    format_literal = factory.format_literal

    read_only_cases, dml_cases = partition_cases(test_files)
    LOGGER.info(
        "[parallel] %d read-only cases, %d DML cases, %d workers",
        len(read_only_cases), len(dml_cases), workers,
    )

    # -- Read-only cases in parallel ------------------------------------------
    if read_only_cases:
        if source_config is None:
            raise RuntimeError(
                "Parallel capture requires a source factory and config."
            )

        def _worker_capture(
            thread_executor: DatabaseExecutor,
            test_file: TestFile,
            case_idx: int,
            test_case: list[Any],
        ) -> _CaptureResult:
            if test_file.step_validation is not None:
                built = build_source_sql(
                    dialect_enum, test_file.step_validation.steps, test_case,
                )
                result = thread_executor.execute_steps(built, test_file.step_validation.steps)
            else:
                sql: str = render_capture_sql(test_file.source, test_case, dialect, format_literal)
                fetch_stmts: list[str] = render_output_fetch_statements(test_file.source, test_case, dialect)
                rendered_steps = ValidationSteps(
                    run=test_file.source.run,
                    pre_execute=test_file.source.pre_execute,
                    output_parameters=test_file.source.output_parameters,
                    output_tables=test_file.source.output_tables,
                    output_cursors=test_file.source.output_cursors,
                )

                result = thread_executor.execute(
                    sql, steps=rendered_steps, fetch_stmts=fetch_stmts or None,
                )

            parameters = build_parameters(test_file.parameter_names, test_case)
            baseline = BaselineData.from_capture(
                procedure=test_file.code_unit_name,
                parameters=parameters,
                result=result,
            )

            effective_baseline_dir = (
                baseline_dir
                if baseline_dir is not None
                else Path(test_file.file_path).parent.parent / "baselines"
            )
            path = write_baseline(baseline, effective_baseline_dir, case_idx, capture_date)
            _print_case_result(test_file.code_unit_name, case_idx, baseline)

            return _CaptureResult(success=result.success, baseline_path=str(path))

        par = ParallelExecutor(max_workers=workers)
        read_only_results = par.execute_with_factory(
            read_only_cases, factory, source_config, _worker_capture,
        )

        for capture_result in read_only_results:
            stats.total += 1
            if capture_result.success:
                stats.succeeded += 1
            else:
                stats.failed += 1
            stats.baseline_files.append(capture_result.baseline_path)

    # -- DML cases sequentially (grouped by test file) -------------------------
    # Group DML cases back by test file to use existing _capture_test_file.
    executed_tests_with_dml: set[str] = set()
    for test_file, _case_idx, _test_case in dml_cases:
        if test_file.file_path in executed_tests_with_dml:
            continue
        executed_tests_with_dml.add(test_file.file_path)
        effective_baseline_dir = (
            baseline_dir
            if baseline_dir is not None
            else Path(test_file.file_path).parent.parent / "baselines"
        )
        _capture_test_file(
            test_file=test_file,
            factory=factory,
            baseline_dir=effective_baseline_dir,
            capture_date=capture_date,
            stats=stats,
            replay_cfg=replay_cfg,
        )


def _capture_test_file(
    test_file: TestFile,
    factory: DatabaseExecutorFactory,
    baseline_dir: Path,
    capture_date: datetime,
    stats: TestCaseStats,
    replay_cfg: ReplayConfiguration | None = None,
) -> None:
    """Capture all test cases for a single test file."""
    executor = factory.executor
    dialect = factory.dialect.value
    dialect_enum = factory.dialect

    # Step-based files use builders + execute_steps exclusively.
    if test_file.step_validation is not None:
        for case_idx, test_case in enumerate(test_file.step_validation.test_cases):
            parameters = build_parameters(test_file.parameter_names, test_case)
            built = build_source_sql(dialect_enum, test_file.step_validation.steps, test_case)

            is_dml = (
                replay_cfg is not None
                and test_file.modifies_data is True
                and bool(test_file.affected_tables)
            )
            table_deltas: dict[str, dict] = {}
            column_metadata: dict[str, dict[str, list[str]]] = {}

            if is_dml:
                connection = getattr(executor, "connection", None)
                if connection is None and executor.connector is not None:
                    connection = executor.connector.connection

                if connection is not None:
                    effective_replay_cfg = replay_cfg or ReplayConfiguration()

                    def _exec():
                        return executor.execute_steps(built, test_file.step_validation.steps)

                    try:
                        result, table_deltas, column_metadata = capture_deltas(
                            connection=connection,
                            affected_tables=test_file.affected_tables or [],
                            replay_cfg=effective_replay_cfg,
                            execute_fn=_exec,
                            executor_factory=factory,
                            code_unit_name=test_file.code_unit_name,
                        )
                    except Exception as exc:
                        LOGGER.error(
                            "Delta capture failed for %s (case %d): %s — skipping case",
                            test_file.code_unit_name, case_idx, exc,
                        )
                        stats.total += 1
                        stats.failed += 1
                        continue
                else:
                    result = executor.execute_steps(built, test_file.step_validation.steps)
            else:
                result = executor.execute_steps(built, test_file.step_validation.steps)

            baseline = BaselineData.from_capture(
                procedure=test_file.code_unit_name,
                parameters=parameters,
                result=result,
            )
            if table_deltas:
                baseline.table_deltas = table_deltas
            if column_metadata:
                baseline.column_metadata = column_metadata

            path = write_baseline(baseline, baseline_dir, case_idx, capture_date)
            stats.total += 1
            if result.success:
                stats.succeeded += 1
            else:
                stats.failed += 1
            stats.baseline_files.append(str(path))
            _print_case_result(test_file.code_unit_name, case_idx, baseline)
        return

    outputs = test_file.source.output_parameters
    is_dml = (
        replay_cfg is not None
        and test_file.modifies_data is True
        and bool(test_file.affected_tables)
    )
    effective_replay_cfg = replay_cfg or ReplayConfiguration()

    for case_idx, test_case in enumerate(test_file.test_cases):
        sql = render_capture_sql(test_file.source, test_case, dialect, factory.format_literal)

        fetch_stmts = render_output_fetch_statements(
            test_file.source, test_case, dialect,
        )

        rendered_steps = ValidationSteps(
            run=test_file.source.run,
            pre_execute=test_file.source.pre_execute,
            output_parameters=outputs,
            output_tables=test_file.source.output_tables,
            output_cursors=test_file.source.output_cursors,
        )

        parameters = build_parameters(test_file.parameter_names, test_case)
        table_deltas: dict[str, dict] = {}
        column_metadata: dict[str, dict[str, list[str]]] = {}

        if is_dml:
            connection = getattr(executor, "connection", None)
            if connection is None and executor.connector is not None:
                connection = executor.connector.connection

            if connection is not None:
                def _exec():
                    return executor.execute(
                        sql, steps=rendered_steps,
                        fetch_stmts=fetch_stmts or None,
                    )

                try:
                    result, table_deltas, column_metadata = capture_deltas(
                        connection=connection,
                        affected_tables=test_file.affected_tables or [],
                        replay_cfg=effective_replay_cfg,
                        execute_fn=_exec,
                        executor_factory=factory,
                        code_unit_name=test_file.code_unit_name,
                        pk_columns_by_table=test_file.pk_columns_by_table,
                    )
                except Exception as exc:
                    LOGGER.error(
                        "Delta capture failed for %s (case %d): %s — skipping case to preserve source integrity",
                        test_file.code_unit_name, case_idx, exc,
                    )
                    stats.total += 1
                    stats.failed += 1
                    continue
            else:
                LOGGER.warning(
                    "Cannot capture deltas for %s: no raw connection available",
                    test_file.code_unit_name,
                )
                result = executor.execute(
                    sql, steps=rendered_steps, fetch_stmts=fetch_stmts or None,
                )
        else:
            result = executor.execute(
                sql, steps=rendered_steps, fetch_stmts=fetch_stmts or None,
            )

        baseline = BaselineData.from_capture(
            procedure=test_file.code_unit_name,
            parameters=parameters,
            result=result,
        )
        if table_deltas:
            baseline.table_deltas = table_deltas
        if column_metadata:
            baseline.column_metadata = column_metadata

        path = write_baseline(baseline, baseline_dir, case_idx, capture_date)

        stats.total += 1
        if result.success:
            stats.succeeded += 1
        else:
            stats.failed += 1
        stats.baseline_files.append(str(path))

        _print_case_result(test_file.code_unit_name, case_idx, baseline)
