"""
Validate runner -- orchestrates the full validation pipeline.

1. Resolve Snowflake executor from the injected registry
2. Discover test YAML files and filter to those with ``target`` steps
3. Load baselines from ``VALIDATION.BASELINE_ROWS`` table (stage-first)
4. For each YAML test case: materialize baseline + actual into temp tables,
   compare via the data-validation framework's Snowflake-native validators
5. Write results to ``VALIDATION.RESULTS``
"""

from __future__ import annotations

import dataclasses
import logging
import re
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase

from test_runner.common.baseline import compute_params_hash
from test_runner.common.config import TestRunnerConfig
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import DatabaseExecutor, DatabaseExecutorFactory
from test_runner.common.dependency_classifier import enrich_test_files
from test_runner.common.discovery import discover_test_files, filter_test_files
from test_runner.common.models import (
    MAX_DETAIL_LENGTH,
    MAX_SUMMARY_LENGTH,
    BaselineData,
    ComparisonResult,
    TestFile,
    ValidationCaseResult,
    ValidationDifference,
    ValidationStats,
    ValidationSteps,
    truncate,
)
from test_runner.common.template import (
    build_parameters,
    render_output_fetch_statements,
    render_validate_outputs_sql,
    render_validate_resultset_sql,
)
from test_runner.common.builders import build_snowflake_sql

from .baseline_loader import create_baseline_loader
from .comparator import compare_results, errors_match
from .deploy import deploy_snowpark_validator
from .results_writer import write_results_batch, write_results_local
from .transient_table_manager import (
    fetch_baseline_rows_batch,
    fetch_baseline_output_rows_batch,
)
from test_runner.replay.validate_handler import validate_deltas
from test_runner.replay.isolation import SnowflakeCloneIsolation
from test_runner.parallel.partitioner import partition_cases
from test_runner.parallel.executor import ParallelExecutor

LOGGER = logging.getLogger(__name__)


def _rewrite_database(sql: str, original_db: str, clone_db: str) -> str:
    """Case-insensitive replacement of the database prefix in SQL.

    Rewrites ``CALL WideWorldImporters.Schema.Proc(...)`` to
    ``CALL CLONE_DB.Schema.Proc(...)`` so that ``EXECUTE AS OWNER``
    procedures run inside the clone, resolving unqualified table
    references to the clone's schemas.
    """
    return re.sub(
        r"(?<!\.)" + re.escape(original_db) + r"(?=\.)",
        clone_db,
        sql,
        flags=re.IGNORECASE,
    )


# ---------------------------------------------------------------------------
# Console output
# ---------------------------------------------------------------------------

_SEP = "\u2550" * 60


def _print_header(source: str) -> None:
    print(f"\n{_SEP}")
    print("  VALIDATING SNOWFLAKE AGAINST BASELINES")
    print(f"  Baseline source: {source}")
    print(f"{_SEP}\n")


def _print_case(
    procedure: str,
    status: str,
    match_type: str,
    error: str,
    differences: list[ValidationDifference | str] | None = None,
) -> None:
    icon = "\u2705" if status == "PASS" else "\u274c"
    detail = match_type
    if error:
        detail = f"{match_type}: {truncate(error, MAX_SUMMARY_LENGTH)}"
    print(f"{icon} {status} {procedure} -- {detail}")
    if status != "PASS" and differences:
        for i, diff in enumerate(differences[:5]):
            if isinstance(diff, ValidationDifference):
                print(f"    [{i}] level={diff.level}  type={diff.type}  detail={truncate(diff.detail, MAX_DETAIL_LENGTH)}")
            else:
                print(f"    [{i}] {truncate(str(diff), MAX_DETAIL_LENGTH)}")


def _print_summary(stats: ValidationStats) -> None:
    print(f"\n{_SEP}")
    print(f"  SUMMARY: {stats.total} test cases")
    print(f"  Passed: {stats.passed}  Failed: {stats.failed}  Errors: {stats.errors}")
    if stats.no_baseline:
        print(f"  No baseline: {stats.no_baseline}")
    print(f"{_SEP}\n")


def update_result_statistics(result: ValidationCaseResult, stats: ValidationStats) -> None:
    """Update *stats* counters from a single validation result."""
    stats.total += 1
    if result.status == "PASS":
        stats.passed += 1
    elif result.status == "NO_BASELINE":
        stats.no_baseline += 1
    elif result.status == "ERROR":
        stats.errors += 1
    else:
        stats.failed += 1


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_validate(
    config: TestRunnerConfig,
    factory_registry: dict[DatabaseDialect, DatabaseExecutorFactory],
    project_root: str | Path,
    snowflake_connection: Optional[str] = None,
    baseline_dir: Optional[str | Path] = None,
    baseline_stage: Optional[str] = None,
    where: str | None = None,
    include_dependencies: bool = False,
    create_schema: bool = False,
    output_dir: Optional[str | Path] = None,
    dump_baseline_and_actual: bool = False,
    workers: int = 1,
) -> ValidationStats:
    """Execute the full validation pipeline.

    Baselines are loaded from the ``BASELINE_ROWS`` table first; if empty, falls
    back to the implicit stage ``@{database}.VALIDATION.BASELINES``.
    *dump_baseline_and_actual* requires *output_dir* and writes per-case row dumps.
    """
    project_root = Path(project_root)

    sf_factory = factory_registry.get(DatabaseDialect.SNOWFLAKE)
    if sf_factory is None:
        raise ValueError("No executor factory registered for Snowflake.")

    target_raw = dict(config.target_connection_raw)
    if snowflake_connection:
        target_raw["name"] = snowflake_connection
    if not target_raw.get("name"):
        raise ValueError(
            "Validate requires a Snowflake connection. Configure a default in "
            "~/.snowflake/config.toml or pass --connection."
        )
    target_raw.setdefault("mode", "name")
    sf_config = sf_factory.build_config(target_raw)
    executor = sf_factory.create_executor(sf_config)
    sf_factory.executor = executor

    connector = executor.connector
    if connector is None:
        raise ValueError(
            "Validate requires a Snowflake connector. "
            "The executor must provide a connector property."
        )

    try:
        if create_schema:
            deploy_snowpark_validator(connector, config.validation_database)

        test_files = discover_test_files(project_root, config.selectors)
        test_files = [tf for tf in test_files if tf.target is not None or tf.step_validation is not None]
        test_files = filter_test_files(test_files, project_root, where, include_dependencies)

        enrich_test_files(test_files, project_root)

        if not test_files:
            print("No test YAML files with target steps found.")
            return ValidationStats()

        # Keep two-part procedure calls (schema.procedure) resolving to the
        # procedure database when validation objects live in a separate database.
        execution_database = next(
            (tf.target_database for tf in test_files if tf.target_database),
            config.validation_database,
        )
        cursor = connector.connection.cursor()
        try:
            cursor.execute(f"USE DATABASE {execution_database}")
        finally:
            cursor.close()

        LOGGER.info("Validation configuration: validation_database=%s, execution_database=%s",
                    config.validation_database, execution_database)

        # Extract unique procedure names from test files for path-based filtering
        procedure_names = set()
        for test_file in test_files:
            if test_file.code_unit_name:
                procedure_names.add(test_file.code_unit_name)

        LOGGER.info("Extracted %d unique procedures from test files", len(procedure_names))

        start_time = time.perf_counter()
        loader = create_baseline_loader(
            connector=connector,
            database=config.validation_database,
            baseline_dir=Path(baseline_dir) if baseline_dir else None,
            baseline_stage=baseline_stage,
            project_root=project_root,
            procedures=list(procedure_names) if procedure_names else None,
        )
        baselines = loader.load()
        baseline_load_duration = time.perf_counter() - start_time
        LOGGER.info("Baseline load completed in %.2f seconds (%d entries, source=%s)",
                    baseline_load_duration, len(baselines), loader.source_label)
        baseline_index: dict[tuple[str, str], BaselineData] = {
            (bl.procedure, bl.params_hash): bl for bl in baselines
        }

        _print_header(loader.source_label)

        stats = ValidationStats()
        all_results: list[ValidationCaseResult] = []
        format_literal = sf_factory.create_literal_formatter().format_literal

        procedure_db = next(
            (tf.target_database for tf in test_files if tf.target_database),
            None,
        )
        clone_source_db = (procedure_db or config.validation_database or "").upper()

        # -- batch-load baseline rows upfront ------------------------------------
        # Collect all (procedure, params_hash) pairs from test cases to batch-fetch
        # baseline rows in one query instead of N separate queries (2.7s each).
        baseline_rows_cache: dict[str, tuple[list[dict], dict[str, str]]] = {}
        baseline_output_cache: dict[str, tuple[list[dict], dict[str, str]]] = {}

        params_hashes_by_proc: dict[str, set[str]] = defaultdict(set)
        for test_file in test_files:
            procedure = test_file.code_unit_name
            if not procedure:
                continue

            for test_case in test_file.test_cases:
                parameters = build_parameters(test_file.parameter_names, test_case)
                params_hash = compute_params_hash(parameters)
                params_hashes_by_proc[procedure].add(params_hash)

        # Batch-fetch baseline rows for each procedure
        if connector and params_hashes_by_proc:
            t_batch = time.monotonic()
            total_hashes = sum(len(hashes) for hashes in params_hashes_by_proc.values())
            LOGGER.info("Batch-loading baseline rows for %d test cases across %d procedures",
                       total_hashes, len(params_hashes_by_proc))

            for procedure, hashes in params_hashes_by_proc.items():
                hash_list = list(hashes)
                try:
                    # Fetch result set rows
                    proc_cache = fetch_baseline_rows_batch(
                        connector,
                        config.validation_database,
                        hash_list,
                        procedure=procedure,
                    )
                    baseline_rows_cache.update(proc_cache)

                    # Fetch output parameter rows
                    output_cache = fetch_baseline_output_rows_batch(
                        connector,
                        config.validation_database,
                        hash_list,
                        procedure=procedure,
                    )
                    baseline_output_cache.update(output_cache)
                except Exception as exc:
                    LOGGER.warning("Failed to batch-load baseline rows for %s: %s", procedure, exc)

            LOGGER.info("[timing] batch-load baseline rows: %.3fs  (%d cached)",
                       time.monotonic() - t_batch, len(baseline_rows_cache))

        # -- validation execution phase ------------------------------------------
        validation_exec_start = time.perf_counter()
        if workers > 1:
            all_results = _run_parallel_validate(
                test_files=test_files,
                baseline_index=baseline_index,
                connector=connector,
                sf_factory=sf_factory,
                sf_config=sf_config,
                format_literal=format_literal,
                config=config,
                dump_baseline_and_actual=dump_baseline_and_actual,
                workers=workers,
                baseline_rows_cache=baseline_rows_cache,
                baseline_output_cache=baseline_output_cache,
            )
            for result in all_results:
                update_result_statistics(result, stats)
                _print_case(
                    result.procedure, result.status,
                    result.match_type, result.error,
                    differences=result.differences or None,
                )
        else:
            # Check if any test files modify data - only create clone if needed
            has_dml = any(tf.modifies_data for tf in test_files)
            run_isolation: SnowflakeCloneIsolation | None = None

            if clone_source_db and has_dml:
                LOGGER.info("Creating run-level clone (DML procedures detected)")
                run_isolation = SnowflakeCloneIsolation(clone_source_db)
                t_clone = time.monotonic()
                run_isolation.setup(connector.connection)
                LOGGER.info(
                    "[timing] run-level clone setup: %.3fs -> %s",
                    time.monotonic() - t_clone, run_isolation.clone_database,
                )
            elif clone_source_db and not has_dml:
                LOGGER.info("Skipping run-level clone (all procedures are read-only)")
            else:
                LOGGER.debug("No clone setup (no source database configured)")

            try:
                for test_file in test_files:
                    for case_idx, test_case in enumerate(test_file.test_cases):
                        t_case = time.monotonic()
                        result = _validate_case(
                            test_file=test_file,
                            test_case=test_case,
                            baseline_index=baseline_index,
                            connector=connector,
                            executor=executor,
                            format_literal=format_literal,
                            config=config,
                            dump_baseline_and_actual=dump_baseline_and_actual,
                            run_isolation=run_isolation,
                            executor_factory=sf_factory,
                            baseline_rows_cache=baseline_rows_cache,
                            baseline_output_cache=baseline_output_cache,
                        )
                        LOGGER.info("[timing] case %s (%s): %.3fs  status=%s",
                                    result.procedure, result.params_hash,
                                    time.monotonic() - t_case, result.status)
                        all_results.append(result)
                        update_result_statistics(result, stats)
                        _print_case(
                            result.procedure, result.status,
                            result.match_type, result.error,
                            differences=result.differences or None,
                        )
            finally:
                if run_isolation is not None:
                    run_isolation.teardown(connector.connection)

        validation_exec_duration = time.perf_counter() - validation_exec_start
        LOGGER.info("Validation execution completed in %.2f seconds", validation_exec_duration)

        # -- results writing phase -----------------------------------------------
        results_write_start = time.perf_counter()
        if all_results:
            result_dicts = [r.to_dict() for r in all_results]
            # Write local output first -- it pops _baseline_rows/_actual_rows from
            # each result dict and saves them as separate files.  write_results_batch
            # must run afterwards so the Snowflake insert never sees those keys.
            if output_dir:
                try:
                    write_results_local(result_dicts, Path(output_dir))
                except Exception as exc:
                    print(f"Warning: failed to write local results to {output_dir}: {exc}")

            t_write = time.monotonic()
            try:
                write_results_batch(connector, result_dicts, config.validation_database)
                LOGGER.info("[timing] write_results_batch: %.3fs", time.monotonic() - t_write)
            except Exception as exc:
                print(f"Warning: failed to write results to VALIDATION.RESULTS: {exc}")

        results_write_duration = time.perf_counter() - results_write_start if all_results else 0.0
        LOGGER.info("Results writing completed in %.2f seconds", results_write_duration)

        total_duration = time.perf_counter() - start_time
        LOGGER.info("Total runtime: %.2f seconds (baseline_load: %.2f, validation: %.2f, results_write: %.2f)",
                    total_duration, baseline_load_duration, validation_exec_duration, results_write_duration)

        _print_summary(stats)
        return stats

    finally:
        executor.close()


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _run_parallel_validate(
    test_files: list[TestFile],
    baseline_index: dict[tuple[str, str], BaselineData],
    connector: ConnectorBase,
    sf_factory: DatabaseExecutorFactory,
    sf_config: Any,
    format_literal: Callable[[Any], str],
    config: TestRunnerConfig,
    dump_baseline_and_actual: bool,
    workers: int,
    baseline_rows_cache: dict[str, tuple[list[dict], dict[str, str]]] | None = None,
    baseline_output_cache: dict[str, tuple[list[dict], dict[str, str]]] | None = None,
) -> list[ValidationCaseResult]:
    """Partition test cases and run read-only cases in parallel.

    DML cases fall back to sequential execution with a run-level
    zero-copy clone for isolation.
    """
    read_only_cases, dml_cases = partition_cases(test_files)
    LOGGER.info(
        "[parallel] %d read-only cases, %d DML cases, %d workers",
        len(read_only_cases), len(dml_cases), workers,
    )

    all_results: list[ValidationCaseResult] = []

    # -- Read-only cases in parallel ------------------------------------------
    if read_only_cases:
        if sf_config is None:
            raise RuntimeError(
                "Parallel mode requires a Snowflake connection config "
                "(not a connection_override)."
            )

        def _worker_validate(
            thread_executor: DatabaseExecutor,
            test_file: TestFile,
            case_idx: int,
            test_case: list[Any],
        ) -> ValidationCaseResult:
            t_case = time.monotonic()
            try:
                result = _validate_case(
                    test_file=test_file,
                    test_case=test_case,
                    baseline_index=baseline_index,
                    connector=thread_executor.connector,
                    executor=thread_executor,
                    format_literal=format_literal,
                    config=config,
                    dump_baseline_and_actual=dump_baseline_and_actual,
                    baseline_rows_cache=baseline_rows_cache,
                    baseline_output_cache=baseline_output_cache,
                )
            except Exception as exc:
                LOGGER.error(
                    "Worker exception for %s: %s", test_file.code_unit_name, exc,
                )
                parameters = build_parameters(test_file.parameter_names, test_case)
                result = ValidationCaseResult(
                    procedure=test_file.code_unit_name,
                    params_hash=compute_params_hash(parameters),
                    params=parameters,
                    status="ERROR",
                    error=str(exc),
                    metadata={"worker_exception": True},
                    executed_at=datetime.now(timezone.utc).isoformat(),
                )
            LOGGER.info(
                "[timing] case %s (%s): %.3fs  status=%s  [parallel-ro]",
                result.procedure, result.params_hash,
                time.monotonic() - t_case, result.status,
            )
            return result

        par = ParallelExecutor(max_workers=workers)
        ro_results = par.execute_with_factory(
            read_only_cases, sf_factory, sf_config, _worker_validate,
        )
        all_results.extend(ro_results)

    # -- DML cases sequentially with run-level clone --------------------------
    if dml_cases:
        procedure_db = next(
            (tf.target_database for tf in test_files if tf.target_database),
            None,
        )
        clone_source_db = (procedure_db or config.validation_database or "").upper()
        run_isolation: SnowflakeCloneIsolation | None = None
        if clone_source_db:
            run_isolation = SnowflakeCloneIsolation(clone_source_db)
            t_clone = time.monotonic()
            run_isolation.setup(connector.connection)
            LOGGER.info(
                "[timing] DML run-level clone setup: %.3fs -> %s",
                time.monotonic() - t_clone, run_isolation.clone_database,
            )

        try:
            for test_file, case_idx, test_case in dml_cases:
                t_case = time.monotonic()
                result = _validate_case(
                    test_file=test_file,
                    test_case=test_case,
                    baseline_index=baseline_index,
                    connector=connector,
                    executor=sf_factory.executor,
                    format_literal=format_literal,
                    config=config,
                    dump_baseline_and_actual=dump_baseline_and_actual,
                    run_isolation=run_isolation,
                    executor_factory=sf_factory,
                    baseline_rows_cache=baseline_rows_cache,
                    baseline_output_cache=baseline_output_cache,
                )
                LOGGER.info(
                    "[timing] case %s (%s): %.3fs  status=%s  [sequential-dml]",
                    result.procedure, result.params_hash,
                    time.monotonic() - t_case, result.status,
                )
                all_results.append(result)
        finally:
            if run_isolation is not None:
                run_isolation.teardown(connector.connection)

    return all_results


@dataclass
class _ImplicitReturnCheck:
    """Result of checking whether a Snowflake CALL returned only the
    implicit procedure return value."""
    is_implicit: bool
    row_count: int = 0
    col_names: list[str] | None = None
    error: str | None = None


def _has_baseline_resultset(baseline: BaselineData) -> bool:
    """True when the baseline contains at least one non-empty result set or row count.

    Used by ``_validate_case`` to distinguish DML procedures (no baseline
    result sets, only table_deltas) from read-only procedures.
    """
    has_nonempty_results = (
        baseline.result_sets
        and any(rs for rs in baseline.result_sets)
    )
    has_nonzero_counts = (
        baseline.row_counts
        and any(c > 0 for c in baseline.row_counts)
    )
    return bool(has_nonempty_results or has_nonzero_counts)


def _is_implicit_return(col_names: list[str], row_count: int, procedure: str) -> bool:
    """True when the result set looks like Snowflake's implicit CALL return.

    Snowflake SQL Script procedures always return a single-row,
    single-column result set where the column is named after the
    procedure's short name (uppercased).  When the CALL is wrapped
    in a ``BEGIN … END`` scripting block (e.g. because ``pre_execute``
    contains LET declarations), the column is ``ANONYMOUS BLOCK``
    instead.
    """
    if row_count != 1 or len(col_names) != 1:
        return False
    col = col_names[0].upper()
    short_name = procedure.rsplit(".", 1)[-1].upper()
    return col == short_name or col == "ANONYMOUS BLOCK"


def _execute_and_check_implicit_return(
    connector: ConnectorBase,
    rendered_sql: str,
    procedure: str,
) -> _ImplicitReturnCheck:
    """Execute the CALL and determine if the result is just the implicit
    Snowflake procedure return value.

    The caller is responsible for isolation (typically by rewriting
    *rendered_sql* to target a zero-copy clone database so that DML
    side effects from ``EXECUTE AS OWNER`` procedures never touch the
    original database).
    """
    cursor = connector.connection.cursor()
    try:
        cursor.execute(rendered_sql)
        col_names = [d[0] for d in cursor.description] if cursor.description else []
        rows = cursor.fetchall() or []
        row_count = len(rows)

        implicit = _is_implicit_return(col_names, row_count, procedure)
        return _ImplicitReturnCheck(
            is_implicit=implicit,
            row_count=row_count,
            col_names=col_names,
        )
    except Exception as exc:
        return _ImplicitReturnCheck(
            is_implicit=False,
            error=str(exc),
        )
    finally:
        cursor.close()


# ---------------------------------------------------------------------------
# Internal: validate a single test case
# ---------------------------------------------------------------------------

def _validate_case(
    test_file: TestFile,
    test_case: list[Any],
    baseline_index: dict[tuple[str, str], BaselineData],
    connector: ConnectorBase,
    executor: DatabaseExecutor,
    format_literal: Callable[[Any], str],
    config: TestRunnerConfig,
    dump_baseline_and_actual: bool = False,
    run_isolation: SnowflakeCloneIsolation | None = None,
    executor_factory: DatabaseExecutorFactory | None = None,
    baseline_rows_cache: dict[str, tuple[list[dict], dict[str, str]]] | None = None,
    baseline_output_cache: dict[str, tuple[list[dict], dict[str, str]]] | None = None,
) -> ValidationCaseResult:
    """Validate one test case from a YAML file against its baseline.

    When *run_isolation* is provided (the normal production path), all
    procedure executions target the run-level clone database and affected
    tables are reverted via fast table-level clones before each execution.
    When ``None`` (unit-test fallback), SQL is executed as-is.
    """
    parameters = build_parameters(test_file.parameter_names, test_case)
    params_hash = compute_params_hash(parameters)
    procedure = test_file.code_unit_name

    result = ValidationCaseResult(
        procedure=procedure,
        params_hash=params_hash,
        params=parameters,
        status="",
        metadata={
            "modifies_data": test_file.modifies_data,
            "affected_tables": test_file.affected_tables,
            "source_checksum": test_file.source_checksum,
            "converted_checksum": test_file.converted_checksum,
        },
        executed_at=datetime.now(timezone.utc).isoformat(),
    )

    baseline = baseline_index.get((procedure, params_hash))
    if baseline is None:
        result.status = "NO_BASELINE"
        result.error = f"No baseline found for {procedure} (params_hash={params_hash})"
        return result

    # Step-based test files route to a dedicated handler.
    if test_file.step_validation is not None:
        return _validate_step_based_case(
            test_file=test_file,
            test_case=test_case,
            baseline=baseline,
            result=result,
            connector=connector,
            executor=executor,
            format_literal=format_literal,
            config=config,
            dump_baseline_and_actual=dump_baseline_and_actual,
            run_isolation=run_isolation,
            executor_factory=executor_factory,
        )

    assert test_file.target is not None
    target_sql = render_validate_resultset_sql(
        test_file.target, test_case, format_literal,
    )

    fetch_stmts = render_output_fetch_statements(
        test_file.target, test_case, "snowflake",
    )

    rendered_steps = ValidationSteps(
        run=test_file.target.run,
        pre_execute=test_file.target.pre_execute,
        output_parameters=test_file.target.output_parameters,
        output_tables=test_file.target.output_tables,
    )

    outputs_sql: str | None = None
    if test_file.target.output_parameters:
        outputs_sql = render_validate_outputs_sql(
            test_file.target, test_case, format_literal,
        )

    procedure_db = (test_file.target_database or config.validation_database or "").upper()
    has_deltas = bool(baseline.table_deltas)
    replay_cfg = config.replay_configuration

    no_baseline_resultset = (
        not _has_baseline_resultset(baseline)
        and not outputs_sql
    )

    # --- Clone and table-revert helpers --------------------------------
    clone_db = run_isolation.clone_database if run_isolation else None

    def _schema_table(fqn: str) -> str:
        """Normalise to SCHEMA.TABLE, stripping any leading DATABASE prefix."""
        parts = fqn.upper().split(".")
        return ".".join(parts[-2:]) if len(parts) >= 2 else fqn.upper()

    revert_fqns: set[str] = set()
    if baseline.table_deltas:
        revert_fqns.update(_schema_table(k) for k in baseline.table_deltas)
    if test_file.affected_tables:
        revert_fqns.update(_schema_table(t) for t in test_file.affected_tables)
    _revert_list = sorted(revert_fqns)

    def _revert() -> None:
        """Reset affected tables in the clone and switch the session to the
        clone database so ``EXECUTE AS CALLER`` procedures resolve
        unqualified table references against the clone."""
        if run_isolation and _revert_list:
            run_isolation.revert_tables(connector.connection, _revert_list)
        if clone_db:
            cur = connector.connection.cursor()
            try:
                cur.execute(f"USE DATABASE {clone_db}")
            finally:
                cur.close()

    def _to_clone(sql: str) -> str:
        """Rewrite SQL to target the clone database."""
        if clone_db and procedure_db:
            return _rewrite_database(sql, procedure_db, clone_db)
        return sql

    # ------------------------------------------------------------------
    # Error baselines
    # ------------------------------------------------------------------
    if not baseline.success:
        _revert()
        clone_sql = _to_clone(target_sql)
        capture_result = executor.execute(clone_sql, steps=rendered_steps)

        if not capture_result.success:
            if errors_match(baseline.error or "", capture_result.error or ""):
                result.status = "PASS"
                result.match_type = "error_match"
            else:
                result.status = "FAIL"
                result.match_type = "error_mismatch"
                result.error = (
                    f"Baseline: {truncate(baseline.error or '', MAX_SUMMARY_LENGTH)}, "
                    f"Actual: {truncate(capture_result.error or '', MAX_SUMMARY_LENGTH)}"
                )
        else:
            result.status = "FAIL"
            result.error = f"Baseline errored: {truncate(baseline.error or '', MAX_SUMMARY_LENGTH)}"
        return result

    # ------------------------------------------------------------------
    # No baseline result sets — implicit-return check, then optional
    # delta validation.
    # ------------------------------------------------------------------
    if no_baseline_resultset:
        _revert()
        clone_sql = _to_clone(target_sql)
        implicit = _execute_and_check_implicit_return(
            connector, clone_sql, procedure,
        )


        if implicit.error:
            result.status = "FAIL"
            result.match_type = "error"
            result.match_level = "in_memory"
            result.error = truncate(implicit.error, MAX_SUMMARY_LENGTH)
            result.differences = [
                ValidationDifference(type="ERROR", detail=truncate(implicit.error, MAX_DETAIL_LENGTH)),
            ]
            return result
        elif not implicit.is_implicit:
            result.status = "FAIL"
            result.match_type = "unexpected_resultset"
            result.match_level = "in_memory"
            detail = (
                f"Baseline has no result sets but Snowflake returned "
                f"{implicit.row_count} row(s) with columns {implicit.col_names}"
            )
            result.error = detail
            result.differences = [detail]
            return result

        check_deltas = has_deltas or (
            test_file.modifies_data is True
            and bool(test_file.affected_tables)
        )
        LOGGER.info(
            "Snowflake returned only the implicit procedure return "
            "for %s (no baseline result sets); %s.",
            procedure,
            "proceeding to delta validation" if check_deltas else "skipping comparison",
        )
        result.status = "PASS"
        result.match_type = "no_resultset"
        result.match_level = "skipped"

        if check_deltas:
            try:
                _revert()

                def _exec_on_sf(database_override: str | None = None) -> None:
                    sql = _to_clone(target_sql)
                    if database_override and procedure_db:
                        sql = _rewrite_database(target_sql, procedure_db, database_override)
                    capture = executor.execute(sql, steps=rendered_steps)
                    if not capture.success:
                        raise RuntimeError(
                            f"Procedure execution failed during delta validation: "
                            f"{capture.error}"
                        )

                delta_result = validate_deltas(
                    connection=connector.connection,
                    baseline=baseline,
                    replay_cfg=replay_cfg,
                    execute_fn=_exec_on_sf,
                    database=procedure_db,
                    procedure=procedure,
                    params_hash=params_hash,
                    affected_tables=test_file.affected_tables,
                    clone_db=clone_db,
                    executor_factory=executor_factory,
                    pk_columns_by_table=test_file.pk_columns_by_table,
                )

                if not delta_result.match:
                    result.status = "FAIL"
                    result.match_type = delta_result.match_type
                    detail_summary = "; ".join(
                        f"{t}: {len(d.get('differences', []))} diff(s)"
                        for t, d in delta_result.details.items()
                        if not d.get("match", True)
                    )
                    result.error = f"Delta mismatch: {detail_summary}"
                elif result.status == "PASS":
                    result.match_type = "delta_match"

                result.metadata["delta_comparison"] = delta_result.to_dict()
            except Exception as exc:
                LOGGER.error(
                    "Delta validation failed for %s: %s", procedure, exc,
                )
                result.status = "FAIL"
                result.match_type = "delta_error"
                result.error = f"Delta validation failed: {exc}"
                result.metadata["delta_validation_error"] = str(exc)

        return result

    # ------------------------------------------------------------------
    # Procedure WITH result sets — RS comparison + optional delta
    # ------------------------------------------------------------------
    outputs_only = bool(not baseline.row_counts and outputs_sql)

    _revert()
    clone_sql = _to_clone(target_sql)
    clone_outputs_sql = _to_clone(outputs_sql) if outputs_sql else None

    comparison = compare_results(
        config=config,
        connector=connector,
        rendered_sql=clone_sql,
        params_hash=params_hash,
        code_unit_name=procedure,
        baseline=baseline,
        dump_baseline_and_actual=dump_baseline_and_actual,
        fetch_stmts=fetch_stmts or None,
        outputs_sql=clone_outputs_sql,
        outputs_only=outputs_only,
        baseline_rows_cache=baseline_rows_cache,
        baseline_output_cache=baseline_output_cache,
    )

    result.status = "PASS" if comparison.match else "FAIL"
    result.match_type = comparison.match_type
    result.match_level = comparison.match_level
    result.differences = list(comparison.differences[:5])

    if comparison.in_memory_diff is not None:
        result.in_memory_diff = comparison.in_memory_diff

    if comparison.baseline_rows is not None:
        result.baseline_rows = comparison.baseline_rows
    if comparison.actual_rows is not None:
        result.actual_rows = comparison.actual_rows

    if not comparison.match and comparison.differences:
        first = comparison.differences[0]
        if isinstance(first, ValidationDifference):
            result.error = first.detail
        else:
            result.error = str(first)

    # Delta validation reuses a fresh clone (RS clone was dropped).
    # When modifies_data is True we always validate deltas — even if the
    # source baseline has none — to catch erroneous Snowflake mutations.
    check_for_unexpected_mutations = (
        test_file.modifies_data is True
        and bool(test_file.affected_tables)
        and not has_deltas
    )
    if has_deltas or check_for_unexpected_mutations:
        try:
            _revert()

            def _exec_on_sf(database_override: str | None = None) -> None:
                sql = _to_clone(target_sql)
                if database_override and procedure_db:
                    sql = _rewrite_database(target_sql, procedure_db, database_override)
                capture = executor.execute(sql, steps=rendered_steps)
                if not capture.success:
                    raise RuntimeError(
                        f"Procedure execution failed during delta validation: "
                        f"{capture.error}"
                    )

            delta_result = validate_deltas(
                connection=connector.connection,
                baseline=baseline,
                replay_cfg=replay_cfg,
                execute_fn=_exec_on_sf,
                database=procedure_db,
                procedure=procedure,
                params_hash=params_hash,
                affected_tables=test_file.affected_tables,
                clone_db=clone_db,
                executor_factory=executor_factory,
                pk_columns_by_table=test_file.pk_columns_by_table,
            )

            if not delta_result.match:
                result.status = "FAIL"
                result.match_type = delta_result.match_type
                detail_summary = "; ".join(
                    f"{t}: {len(d.get('differences', []))} diff(s)"
                    for t, d in delta_result.details.items()
                    if not d.get("match", True)
                )
                result.error = f"Delta mismatch: {detail_summary}"
            elif result.status == "PASS":
                result.match_type = "result_and_delta_match"

            result.metadata["delta_comparison"] = delta_result.to_dict()
        except Exception as exc:
            LOGGER.error(
                "Delta validation failed for %s: %s", procedure, exc,
            )
            result.status = "FAIL"
            result.match_type = "delta_error"
            result.error = f"Delta validation failed: {exc}"
            result.metadata["delta_validation_error"] = str(exc)

    return result


# ---------------------------------------------------------------------------
# Step-based validation
# ---------------------------------------------------------------------------


def _validate_step_based_case(
    test_file: TestFile,
    test_case: list[Any],
    baseline: BaselineData,
    result: ValidationCaseResult,
    connector: ConnectorBase,
    executor: DatabaseExecutor,
    format_literal: Callable[[Any], str],
    config: TestRunnerConfig,
    dump_baseline_and_actual: bool = False,
    run_isolation: SnowflakeCloneIsolation | None = None,
    executor_factory: DatabaseExecutorFactory | None = None,
) -> ValidationCaseResult:
    """Validate a step-based test case against its baseline."""
    assert test_file.step_validation is not None
    steps = test_file.step_validation.steps
    procedure = result.procedure
    params_hash = result.params_hash

    procedure_db = (test_file.target_database or config.validation_database or "").upper()
    clone_db = run_isolation.clone_database if run_isolation else None
    replay_cfg = config.replay_configuration

    def _schema_table(fqn: str) -> str:
        parts = fqn.upper().split(".")
        return ".".join(parts[-2:]) if len(parts) >= 2 else fqn.upper()

    revert_fqns: set[str] = set()
    if baseline.table_deltas:
        revert_fqns.update(_schema_table(k) for k in baseline.table_deltas)
    if test_file.affected_tables:
        revert_fqns.update(_schema_table(t) for t in test_file.affected_tables)
    _revert_list = sorted(revert_fqns)

    def _revert() -> None:
        if run_isolation and _revert_list:
            run_isolation.revert_tables(connector.connection, _revert_list)
        if clone_db:
            cur = connector.connection.cursor()
            try:
                cur.execute(f"USE DATABASE {clone_db}")
            finally:
                cur.close()

    def _to_clone(sql: str) -> str:
        if clone_db and procedure_db:
            return _rewrite_database(sql, procedure_db, clone_db)
        return sql

    built = build_snowflake_sql(steps, test_case)

    # ------------------------------------------------------------------
    # Error baselines
    # ------------------------------------------------------------------
    if not baseline.success:
        _revert()
        clone_main = _to_clone(built.main_sql)
        # Execute the scripting block directly rather than through
        # execute_steps() — if the procedure errors, the block raises
        # and we capture the raw error.  execute_steps() would mask
        # the real error with "Object '_step_N' does not exist" when
        # the block fails before creating temp tables.
        try:
            executor.execute_statement(clone_main)
        except Exception as exc:
            actual_error = str(exc)
            if errors_match(baseline.error or "", actual_error):
                result.status = "PASS"
                result.match_type = "error_match"
            else:
                result.status = "FAIL"
                result.match_type = "error_mismatch"
                result.error = (
                    f"Baseline: {truncate(baseline.error or '', MAX_SUMMARY_LENGTH)}, "
                    f"Actual: {truncate(actual_error, MAX_SUMMARY_LENGTH)}"
                )
            return result

        # Block succeeded — baseline errored but actual didn't
        result.status = "FAIL"
        result.error = f"Baseline errored: {truncate(baseline.error or '', MAX_SUMMARY_LENGTH)}"
        return result

    # ------------------------------------------------------------------
    # Normal flow: execute scripting block once, compare each step
    # ------------------------------------------------------------------
    _revert()
    clone_main = _to_clone(built.main_sql)

    # Execute the scripting block — creates _step_N temp tables.
    # All subsequent compare_results() calls use the same
    # connector.connection, so temp tables persist.
    try:
        executor.execute_statement(clone_main)
    except Exception as exc:
        result.status = "FAIL"
        result.match_type = "error"
        result.error = f"Step execution failed: {truncate(str(exc), MAX_SUMMARY_LENGTH)}"
        result.differences = [
            ValidationDifference(type="ERROR", detail=truncate(str(exc), MAX_DETAIL_LENGTH)),
        ]
        return result

    step_results: list[ComparisonResult] = []
    for i, stmt in enumerate(built.result_stmts):
        comparison = compare_results(
            config=config,
            connector=connector,
            rendered_sql=stmt,
            params_hash=params_hash,
            code_unit_name=f"{procedure}__step_{i}",
            baseline=baseline,
            dump_baseline_and_actual=dump_baseline_and_actual,
            result_set_index=i,
            baseline_procedure=procedure,
            baseline_rows_cache=baseline_rows_cache,
            baseline_output_cache=baseline_output_cache,
        )
        step_results.append(comparison)

    merged = _merge_step_comparisons(step_results)

    result.status = "PASS" if merged.match else "FAIL"
    result.match_type = merged.match_type
    result.match_level = merged.match_level
    result.differences = list(merged.differences[:10])

    if dump_baseline_and_actual:
        all_baseline: list[dict] = []
        all_actual: list[dict] = []
        all_in_memory: list[dict] = []
        for i, sr in enumerate(step_results):
            if sr.baseline_rows is not None:
                all_baseline.extend(
                    {**row, "_step": i} for row in sr.baseline_rows
                )
            if sr.actual_rows is not None:
                all_actual.extend(
                    {**row, "_step": i} for row in sr.actual_rows
                )
            if sr.in_memory_diff is not None:
                all_in_memory.append({"step": i, **sr.in_memory_diff})
        if all_baseline:
            result.baseline_rows = all_baseline
        if all_actual:
            result.actual_rows = all_actual
        if all_in_memory:
            result.in_memory_diff = {"steps": all_in_memory}

    if not merged.match and merged.differences:
        first = merged.differences[0]
        if isinstance(first, ValidationDifference):
            result.error = first.detail
        else:
            result.error = str(first)

    # ------------------------------------------------------------------
    # Delta validation for step-based DML procedures
    # ------------------------------------------------------------------
    has_deltas = bool(baseline.table_deltas)
    check_for_unexpected_mutations = (
        test_file.modifies_data is True
        and bool(test_file.affected_tables)
        and not has_deltas
    )
    if has_deltas or check_for_unexpected_mutations:
        try:
            _revert()

            def _exec_on_sf(database_override: str | None = None) -> None:
                sql = _to_clone(built.main_sql)
                if database_override and procedure_db:
                    sql = _rewrite_database(built.main_sql, procedure_db, database_override)
                clone_built = dataclasses.replace(built, main_sql=sql)
                capture = executor.execute_steps(clone_built, steps)
                if not capture.success:
                    raise RuntimeError(
                        f"Procedure execution failed during delta validation: {capture.error}"
                    )

            delta_result = validate_deltas(
                connection=connector.connection,
                baseline=baseline,
                replay_cfg=replay_cfg,
                execute_fn=_exec_on_sf,
                database=procedure_db,
                procedure=procedure,
                params_hash=params_hash,
                affected_tables=test_file.affected_tables,
                clone_db=clone_db,
                executor_factory=executor_factory,
            )

            if not delta_result.match:
                result.status = "FAIL"
                result.match_type = delta_result.match_type
                detail_summary = "; ".join(
                    f"{t}: {len(d.get('differences', []))} diff(s)"
                    for t, d in delta_result.details.items()
                    if not d.get("match", True)
                )
                result.error = f"Delta mismatch: {detail_summary}"
            elif result.status == "PASS":
                result.match_type = "result_and_delta_match"

            result.metadata["delta_comparison"] = delta_result.to_dict()
        except Exception as exc:
            LOGGER.error(
                "Delta validation failed for %s: %s", procedure, exc,
            )
            result.status = "FAIL"
            result.match_type = "delta_error"
            result.error = f"Delta validation failed: {exc}"
            result.metadata["delta_validation_error"] = str(exc)

    return result


def _merge_step_comparisons(
    step_results: list[ComparisonResult],
) -> ComparisonResult:
    """Merge per-step ``ComparisonResult`` objects into one.

    - All match → ``ComparisonResult(match=True, ...)``
    - Any fail → ``ComparisonResult(match=False, ...)`` with step-prefixed diffs
    """
    if not step_results:
        LOGGER.warning(
            "Step-based test has zero validated steps — returning PASS by default. "
            "This may indicate a configuration mistake in the YAML."
        )
        return ComparisonResult(match=True, match_type="no_data")

    # Determine the deepest match_level across all steps.
    _LEVEL_DEPTH = {"": 0, "schema_validation": 1, "metrics_validation": 2, "row_validation": 3, "in_memory": 3}
    deepest_level = ""
    for sr in step_results:
        if _LEVEL_DEPTH.get(sr.match_level, 0) > _LEVEL_DEPTH.get(deepest_level, 0):
            deepest_level = sr.match_level

    all_match = all(sr.match for sr in step_results)
    if all_match:
        return ComparisonResult(
            match=True,
            match_type="data_match",
            match_level=deepest_level,
        )

    # Collect diffs from failing steps, prefixed with step index.
    collected_diffs: list[ValidationDifference | str] = []
    first_failing: ComparisonResult | None = None
    for i, sr in enumerate(step_results):
        if not sr.match:
            if first_failing is None:
                first_failing = sr
            for diff in sr.differences:
                if isinstance(diff, ValidationDifference):
                    collected_diffs.append(ValidationDifference(
                        level=diff.level,
                        type=diff.type,
                        detail=f"step_{i}: {diff.detail}",
                        source=diff.source,
                    ))
                else:
                    collected_diffs.append(f"step_{i}: {diff}")

    assert first_failing is not None
    return ComparisonResult(
        match=False,
        match_type=first_failing.match_type,
        match_level=deepest_level,
        differences=collected_diffs,
    )
