"""Replay capture handler — delta capture for DML procedures.

Integrates with the capture runner to capture table deltas when
``test_file.modifies_data`` is ``True``.  The procedure is executed
exactly once, inside a ``BEGIN`` / ``ROLLBACK`` boundary:

1. Begin transaction (isolation)
2. Snapshot affected tables (before)
3. Execute the procedure
4. Snapshot affected tables (after)
5. Rollback transaction (undo all side effects)
6. Compute deltas (before vs after)
7. Return execution result + deltas

The caller (capture runner) owns the executor and connection lifecycle.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from ..common.config import ReplayConfiguration
from ..common.database_executor import DatabaseExecutorFactory
from .delta_capture import (
    build_two_pass_delta,
    compute_changed_pks,
    compute_table_delta,
    get_column_names,
    snapshot_table,
    snapshot_table_hashed,
    snapshot_table_selective,
    snapshot_table_with_hash,
)
from .models import DeltaStrategy, RowDict, TableConfig, delta_total_changes, make_delta
from .source_introspector import ColumnMetadata, SourceIntrospector

logger = logging.getLogger(__name__)


def capture_deltas(
    connection: Any,
    affected_tables: list[str],
    replay_cfg: ReplayConfiguration,
    execute_fn: Callable[[], Any],
    executor_factory: DatabaseExecutorFactory,
    code_unit_name: str = "",
    pk_columns_by_table: dict[str, list[str]] | None = None,
) -> tuple[Any, dict[str, dict], ColumnMetadata]:
    """Execute a DML procedure inside a transaction and capture deltas.

    The sproc is executed exactly once, inside a ``BEGIN`` / ``ROLLBACK``
    boundary.  Both the execution result (return value of *execute_fn*)
    and the table deltas are captured from the same run.

    Tables exceeding ``replay_cfg.large_table_threshold`` rows are skipped
    to avoid expensive full-table snapshots.

    Args:
        connection: Raw database connection (must support ``.cursor()``).
        affected_tables: ``SCHEMA.TABLE`` names this procedure modifies
            (from the Code Unit Registry).
        replay_cfg: Replay configuration with size thresholds.
        execute_fn: A zero-arg callable that executes the procedure on
            *connection* and **returns** the execution result.
        executor_factory: The dialect's executor factory, used to derive
            the dialect string and create the appropriate isolation provider.
        code_unit_name: Used only for log messages.

    Returns:
        ``(result, table_deltas, column_metadata)`` where *result* is
        whatever *execute_fn* returned, *table_deltas* maps FQN table
        names to delta dicts, and *column_metadata* contains
        platform-managed column info from introspection.
    """
    if not affected_tables:
        return execute_fn(), {}, {}

    introspector = executor_factory.create_introspector()
    table_configs = _resolve_table_configs(
        affected_tables, introspector, pk_columns_by_table or {},
    )

    tables_without_pk = [tc for tc in table_configs if not tc.primary_key_columns]
    if tables_without_pk:
        discovered_pks = introspector.introspect_primary_keys(
            connection, tables_without_pk,
        )
        for tc in tables_without_pk:
            pk_cols = discovered_pks.get(tc.fqn, [])
            if pk_cols:
                tc.primary_key_columns = pk_cols
                logger.info(
                    "Discovered PK for %s via runtime introspection: %s",
                    tc.fqn, pk_cols,
                )

    col_metadata = introspector.introspect_columns(connection, table_configs)
    isolation = executor_factory.create_isolation()
    deltas: dict[str, dict] = {}
    result: Any = None

    try:
        isolation.setup(connection)

        # Filter out tables that exceed the large-table threshold to
        # avoid expensive SELECT * snapshots.
        # TODO: reuse before-snapshots across test cases for the same
        # procedure to avoid redundant SELECT * on the same table.
        eligible_configs: list[TableConfig] = []
        for tc in table_configs:
            row_count = _get_row_count(connection, tc.schema_name, tc.table_name)
            tc.estimated_row_count = row_count
            if row_count > replay_cfg.large_table_threshold:
                logger.warning(
                    "Skipping delta capture for %s: %d rows exceeds "
                    "large_table_threshold (%d)",
                    tc.fqn, row_count, replay_cfg.large_table_threshold,
                )
                continue
            eligible_configs.append(tc)

        if eligible_configs:
            isolation.backup_tables(connection, eligible_configs)

        before_snapshots: dict[str, list[dict[str, Any]]] = {}
        before_hash_indices: dict[str, dict[tuple, str]] = {}
        two_pass_exprs: dict[str, str] = {}

        for tc in eligible_configs:
            hash_expr = _prepare_two_pass(
                connection, tc, introspector, replay_cfg,
            )

            if hash_expr is not None:
                rows, hash_idx = snapshot_table_with_hash(
                    connection, tc.schema_name, tc.table_name,
                    tc.primary_key_columns, hash_expr,
                )
                before_snapshots[tc.fqn] = rows
                before_hash_indices[tc.fqn] = hash_idx
                two_pass_exprs[tc.fqn] = hash_expr
                logger.debug(
                    "Before snapshot for %s: %d rows (two-pass)",
                    tc.fqn, len(rows),
                )
            else:
                before_snapshots[tc.fqn] = snapshot_table(
                    connection, tc.schema_name, tc.table_name,
                )
                logger.debug(
                    "Before snapshot for %s: %d rows",
                    tc.fqn, len(before_snapshots[tc.fqn]),
                )

            if tc.primary_key_columns and not _pk_values_unique(
                before_snapshots[tc.fqn], tc.primary_key_columns,
            ):
                logger.warning(
                    "PK columns %s for %s have duplicate values in "
                    "snapshot data (advisory PK?); falling back to "
                    "non-PK strategy",
                    tc.primary_key_columns, tc.fqn,
                )
                tc.primary_key_columns = []
                two_pass_exprs.pop(tc.fqn, None)
                before_hash_indices.pop(tc.fqn, None)

        result = execute_fn()
        exec_success = getattr(result, "success", None)
        exec_error = getattr(result, "error", None)
        logger.debug(
            "[delta] %s: procedure executed, success=%s, error=%s",
            code_unit_name, exec_success, exec_error,
        )

        for tc in eligible_configs:
            before = before_snapshots[tc.fqn]

            if tc.fqn in two_pass_exprs:
                delta = _two_pass_after(
                    connection, tc, before,
                    before_hash_indices[tc.fqn],
                    two_pass_exprs[tc.fqn],
                    replay_cfg, code_unit_name,
                )
            else:
                after = snapshot_table(
                    connection, tc.schema_name, tc.table_name,
                )
                logger.debug(
                    "After snapshot for %s: %d rows (before: %d rows)",
                    tc.fqn, len(after), len(before),
                )

                if before == after:
                    logger.info(
                        "[delta] %s: snapshots for %s are IDENTICAL "
                        "(%d rows) — procedure may not have modified "
                        "visible data within the transaction",
                        code_unit_name, tc.fqn, len(before),
                    )

                tc.estimated_row_count = max(len(before), len(after))
                delta = compute_table_delta(before, after, tc, replay_cfg)

            if tc.primary_key_columns:
                delta["pk_columns"] = tc.primary_key_columns
            changes = delta_total_changes(delta)
            logger.debug(
                "[delta] %s: table %s delta_total_changes=%d "
                "(inserts=%d, deletes=%d, updates=%d)",
                code_unit_name, tc.fqn, changes,
                len(delta.get("inserts", [])),
                len(delta.get("deletes", [])),
                len(delta.get("updates", [])),
            )
            if changes > 0:
                deltas[tc.fqn] = delta
            elif tc.fqn in two_pass_exprs:
                logger.info(
                    "[delta] %s: two-pass for %s produced zero changes "
                    "— procedure may not have modified visible data "
                    "within the transaction",
                    code_unit_name, tc.fqn,
                )

    finally:
        isolation.teardown(connection)

    if deltas:
        logger.info(
            "Captured deltas for %s: %d table(s) with changes",
            code_unit_name, len(deltas),
        )
    else:
        logger.info(
            "No table mutations detected for %s", code_unit_name,
        )

    return result, deltas, col_metadata


def _pk_values_unique(rows: list[RowDict], pk_columns: list[str]) -> bool:
    """Return ``True`` if *pk_columns* form a unique key across *rows*.

    Used to validate advisory PKs (e.g. Redshift, where PK constraints
    are informational and not enforced).  When duplicates exist, the
    caller should clear the PK columns so the table falls through to
    a non-PK strategy.
    """
    if not rows or not pk_columns:
        return True
    seen: set[tuple] = set()
    for row in rows:
        key = tuple(row.get(col) for col in pk_columns)
        if key in seen:
            return False
        seen.add(key)
    return True


def _prepare_two_pass(
    connection: Any,
    table_cfg: TableConfig,
    introspector: SourceIntrospector,
    replay_cfg: ReplayConfiguration,
) -> str | None:
    """Return the hash expression if *table_cfg* qualifies for two-pass.

    Qualification requires: PK columns present, dialect supports hash
    expressions, and column count at or above
    ``two_pass_column_threshold``.

    Returns ``None`` when the table should use one-pass.
    """
    if not table_cfg.primary_key_columns:
        return None

    if introspector.hash_row_expression(["_probe_"]) is None:
        return None

    col_names = get_column_names(
        connection, table_cfg.schema_name, table_cfg.table_name,
    )
    if len(col_names) < replay_cfg.two_pass_column_threshold:
        return None

    pk_set = {c.upper() for c in table_cfg.primary_key_columns}
    non_pk = sorted(c for c in col_names if c not in pk_set)
    if not non_pk:
        return None

    return introspector.hash_row_expression(non_pk)


def _two_pass_after(
    connection: Any,
    table_cfg: TableConfig,
    before_rows: list[RowDict],
    before_hash_index: dict[tuple, str],
    hash_expression: str,
    replay_cfg: ReplayConfiguration,
    code_unit_name: str,
) -> dict[str, Any]:
    """Execute the after-snapshot phase using two-pass fetch.

    Compares before/after hashes to identify changed PKs, then
    selectively fetches only those rows.  Falls back to full
    ``SELECT *`` when more than 50 % of rows changed.
    """
    after_hash_index = snapshot_table_hashed(
        connection, table_cfg.schema_name, table_cfg.table_name,
        table_cfg.primary_key_columns, hash_expression,
    )

    inserted, deleted, updated = compute_changed_pks(
        before_hash_index, after_hash_index,
    )

    total_changed = len(inserted) + len(deleted) + len(updated)
    total_rows = max(len(before_hash_index), len(after_hash_index))
    table_cfg.estimated_row_count = total_rows

    if total_changed == 0:
        logger.info(
            "[delta] %s: two-pass shows %s unchanged (%d rows)",
            code_unit_name, table_cfg.fqn, total_rows,
        )
        table_cfg.strategy = DeltaStrategy.PK_DIFF
        return make_delta(table_cfg.fqn, DeltaStrategy.PK_DIFF)

    if total_rows > 0 and total_changed > total_rows * replay_cfg.two_pass_fallback_ratio:
        logger.info(
            "[delta] %s: two-pass for %s: %d/%d rows changed; "
            "falling back to full after-snapshot",
            code_unit_name, table_cfg.fqn, total_changed, total_rows,
        )
        after = snapshot_table(
            connection, table_cfg.schema_name, table_cfg.table_name,
        )
        return compute_table_delta(before_rows, after, table_cfg, replay_cfg)

    pks_to_fetch = inserted + updated
    after_selective = snapshot_table_selective(
        connection, table_cfg.schema_name, table_cfg.table_name,
        table_cfg.primary_key_columns, pks_to_fetch,
    )

    logger.info(
        "[delta] %s: two-pass for %s: selectively fetched %d/%d rows "
        "(inserts=%d, deletes=%d, updates=%d)",
        code_unit_name, table_cfg.fqn, len(after_selective), total_rows,
        len(inserted), len(deleted), len(updated),
    )

    table_cfg.strategy = DeltaStrategy.PK_DIFF
    delta = build_two_pass_delta(
        before_rows, after_selective, table_cfg.primary_key_columns,
        inserted, deleted, updated, table_cfg,
    )
    delta.setdefault("metadata", {})["two_pass"] = True
    return delta


def _get_row_count(connection: Any, schema: str, table: str) -> int:
    """Return the row count for a table via ``SELECT COUNT(*)``.

    Falls back to 0 on error so that callers can still proceed.
    """
    cursor = connection.cursor()
    try:
        cursor.execute(f'SELECT COUNT(*) FROM "{schema}"."{table}"')
        row = cursor.fetchone()
        return int(row[0]) if row else 0
    except Exception as exc:
        logger.warning("Could not get row count for %s.%s: %s", schema, table, exc)
        return 0
    finally:
        cursor.close()


def _resolve_table_configs(
    affected_tables: list[str],
    introspector: SourceIntrospector,
    pk_columns_by_table: dict[str, list[str]] | None = None,
) -> list[TableConfig]:
    """Parse ``SCHEMA.TABLE`` strings into :class:`TableConfig` objects.

    Identifier casing is delegated to *introspector.normalize_case* so
    each source platform gets its native convention (SQL Server preserves
    original, Redshift lowercases, Snowflake uppercases).

    When *pk_columns_by_table* is provided (from CUR enrichment), the
    matching PK columns are set on each :class:`TableConfig`, enabling
    the ``PK_DIFF`` delta strategy.

    Raises :class:`ValueError` for names with 4+ dot-separated parts,
    which likely indicate un-escaped dotted identifiers
    (e.g. ``GoldDb.md.[md.doctors]``).
    """
    pk_lookup: dict[str, list[str]] = {
        _to_schema_table(k): v for k, v in (pk_columns_by_table or {}).items()
    }
    configs: list[TableConfig] = []
    for fqn in affected_tables:
        parts = fqn.split(".")
        if len(parts) == 2:
            schema, table = parts
        elif len(parts) == 3:
            _, schema, table = parts
        elif len(parts) >= 4:
            raise ValueError(
                f"Table name '{fqn}' has {len(parts)} dot-separated parts; "
                f"this likely indicates an un-escaped dotted identifier "
                f"(e.g. [schema.with.dots]). Only 2-part (SCHEMA.TABLE) "
                f"and 3-part (DB.SCHEMA.TABLE) names are supported."
            )
        else:
            schema, table = "", fqn

        pk_cols = pk_lookup.get(f"{schema}.{table}", [])
        configs.append(TableConfig(
            schema_name=introspector.normalize_case(schema),
            table_name=introspector.normalize_case(table),
            primary_key_columns=pk_cols,
        ))
    return configs


def _to_schema_table(fqn: str) -> str:
    """Strip a table FQN to its last two dot-separated parts (``SCHEMA.TABLE``).

    Ensures PK lookup keys are normalized regardless of whether
    ``_format_name`` produced a 2-part or 3-part name.
    """
    parts = fqn.split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else fqn
