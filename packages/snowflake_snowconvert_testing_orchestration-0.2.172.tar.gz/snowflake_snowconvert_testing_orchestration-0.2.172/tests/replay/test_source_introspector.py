"""Tests for replay.source_introspector."""

from __future__ import annotations

from unittest.mock import MagicMock

from test_runner.replay.models import TableConfig
from test_runner.replay.source_introspector import (
    DefaultIntrospector,
    RedshiftIntrospector,
    SqlServerIntrospector,
    TeradataIntrospector,
)


# ---------------------------------------------------------------------------
# normalize_case
# ---------------------------------------------------------------------------


class TestNormalizeCase:
    def test_sqlserver_preserves_case(self):
        introspector = SqlServerIntrospector()
        assert introspector.normalize_case("Warehouse") == "Warehouse"

    def test_redshift_lowercases(self):
        introspector = RedshiftIntrospector()
        assert introspector.normalize_case("Public") == "public"
        assert introspector.normalize_case("USERS") == "users"

    def test_teradata_uppercases(self):
        introspector = TeradataIntrospector()
        assert introspector.normalize_case("mydb") == "MYDB"
        assert introspector.normalize_case("Orders") == "ORDERS"

    def test_default_uppercases(self):
        introspector = DefaultIntrospector()
        assert introspector.normalize_case("public") == "PUBLIC"
        assert introspector.normalize_case("Users") == "USERS"


# ---------------------------------------------------------------------------
# SqlServerIntrospector.introspect_columns
# ---------------------------------------------------------------------------


class TestSqlServerIntrospectColumns:
    def _make_connection(self, rows: list[tuple]) -> MagicMock:
        conn = MagicMock()
        cursor = MagicMock()
        cursor.fetchall.return_value = rows
        conn.cursor.return_value = cursor
        return conn

    def test_temporal_columns_detected(self):
        rows = [
            ("Warehouse", "Colors", "ValidFrom", 1, False, False),
            ("Warehouse", "Colors", "ValidTo", 2, False, False),
        ]
        conn = self._make_connection(rows)
        introspector = SqlServerIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="Warehouse", table_name="Colors")],
        )

        assert "WAREHOUSE.COLORS" in result
        managed = result["WAREHOUSE.COLORS"]["platform_managed_columns"]
        assert "VALIDFROM" in managed
        assert "VALIDTO" in managed

    def test_identity_columns_detected(self):
        rows = [
            ("Warehouse", "Colors", "ColorID", 0, True, False),
        ]
        conn = self._make_connection(rows)
        introspector = SqlServerIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="Warehouse", table_name="Colors")],
        )

        assert "WAREHOUSE.COLORS" in result
        assert "COLORID" in result["WAREHOUSE.COLORS"]["identity_columns"]
        assert "COLORID" not in result["WAREHOUSE.COLORS"]["platform_managed_columns"]

    def test_computed_columns_detected(self):
        rows = [
            ("dbo", "Orders", "TotalWithTax", 0, False, True),
        ]
        conn = self._make_connection(rows)
        introspector = SqlServerIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="dbo", table_name="Orders")],
        )

        assert "DBO.ORDERS" in result
        assert "TOTALWITHTAX" in result["DBO.ORDERS"]["platform_managed_columns"]

    def test_empty_configs_returns_empty(self):
        conn = MagicMock()
        introspector = SqlServerIntrospector()
        result = introspector.introspect_columns(conn, [])
        assert result == {}

    def test_query_failure_returns_empty(self):
        conn = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = Exception("connection lost")
        conn.cursor.return_value = cursor
        introspector = SqlServerIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="dbo", table_name="Foo")],
        )
        assert result == {}

    def test_mixed_column_types(self):
        rows = [
            ("Warehouse", "Colors", "ColorID", 0, True, False),
            ("Warehouse", "Colors", "ValidFrom", 1, False, False),
            ("Warehouse", "Colors", "ValidTo", 2, False, False),
            ("Warehouse", "Colors", "FullName", 0, False, True),
        ]
        conn = self._make_connection(rows)
        introspector = SqlServerIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="Warehouse", table_name="Colors")],
        )

        entry = result["WAREHOUSE.COLORS"]
        assert sorted(entry["platform_managed_columns"]) == [
            "FULLNAME", "VALIDFROM", "VALIDTO",
        ]
        assert entry["identity_columns"] == ["COLORID"]


# ---------------------------------------------------------------------------
# RedshiftIntrospector.introspect_columns
# ---------------------------------------------------------------------------


class TestRedshiftIntrospectColumns:
    def _make_connection(self, rows: list[tuple]) -> MagicMock:
        conn = MagicMock()
        cursor = MagicMock()
        cursor.fetchall.return_value = rows
        conn.cursor.return_value = cursor
        return conn

    def test_identity_columns_detected(self):
        rows = [
            ("public", "users", "user_id", "\"identity\"(100, 0, '1,1'::text)"),
        ]
        conn = self._make_connection(rows)
        introspector = RedshiftIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="public", table_name="users")],
        )

        assert "PUBLIC.USERS" in result
        assert "USER_ID" in result["PUBLIC.USERS"]["identity_columns"]
        assert "USER_ID" in result["PUBLIC.USERS"]["platform_managed_columns"]

    def test_multiple_tables(self):
        rows = [
            ("public", "users", "user_id", "\"identity\"(1, 0, '1,1'::text)"),
            ("staging", "events", "event_id", "\"identity\"(1, 0, '1,1'::text)"),
        ]
        conn = self._make_connection(rows)
        introspector = RedshiftIntrospector()

        result = introspector.introspect_columns(
            conn, [
                TableConfig(schema_name="public", table_name="users"),
                TableConfig(schema_name="staging", table_name="events"),
            ],
        )

        assert "PUBLIC.USERS" in result
        assert "STAGING.EVENTS" in result

    def test_empty_configs_returns_empty(self):
        conn = MagicMock()
        introspector = RedshiftIntrospector()
        result = introspector.introspect_columns(conn, [])
        assert result == {}

    def test_no_identity_columns_returns_empty(self):
        conn = self._make_connection([])
        introspector = RedshiftIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="public", table_name="users")],
        )
        assert result == {}

    def test_query_failure_returns_empty(self):
        conn = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = Exception("connection lost")
        conn.cursor.return_value = cursor
        introspector = RedshiftIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="public", table_name="users")],
        )
        assert result == {}


# ---------------------------------------------------------------------------
# TeradataIntrospector.introspect_columns
# ---------------------------------------------------------------------------


class TestTeradataIntrospectColumns:
    def _make_connection(self, rows: list[tuple]) -> MagicMock:
        conn = MagicMock()
        cursor = MagicMock()
        cursor.fetchall.return_value = rows
        conn.cursor.return_value = cursor
        return conn

    def test_identity_generated_always_detected(self):
        rows = [
            ("mydb     ", "orders   ", "order_id ", "GA"),
        ]
        conn = self._make_connection(rows)
        introspector = TeradataIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="mydb", table_name="orders")],
        )

        assert "MYDB.ORDERS" in result
        assert "ORDER_ID" in result["MYDB.ORDERS"]["identity_columns"]
        assert "ORDER_ID" in result["MYDB.ORDERS"]["platform_managed_columns"]

    def test_identity_generated_by_default_detected(self):
        rows = [
            ("mydb", "events", "event_id", "GD"),
        ]
        conn = self._make_connection(rows)
        introspector = TeradataIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="mydb", table_name="events")],
        )

        assert "MYDB.EVENTS" in result
        assert "EVENT_ID" in result["MYDB.EVENTS"]["identity_columns"]
        assert "EVENT_ID" in result["MYDB.EVENTS"]["platform_managed_columns"]

    def test_multiple_tables(self):
        rows = [
            ("mydb", "orders", "order_id", "GA"),
            ("staging", "events", "event_id", "GD"),
        ]
        conn = self._make_connection(rows)
        introspector = TeradataIntrospector()

        result = introspector.introspect_columns(
            conn, [
                TableConfig(schema_name="mydb", table_name="orders"),
                TableConfig(schema_name="staging", table_name="events"),
            ],
        )

        assert "MYDB.ORDERS" in result
        assert "STAGING.EVENTS" in result

    def test_empty_configs_returns_empty(self):
        conn = MagicMock()
        introspector = TeradataIntrospector()
        result = introspector.introspect_columns(conn, [])
        assert result == {}

    def test_no_identity_columns_returns_empty(self):
        conn = self._make_connection([])
        introspector = TeradataIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="mydb", table_name="orders")],
        )
        assert result == {}

    def test_query_failure_returns_empty(self):
        conn = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = Exception("connection lost")
        conn.cursor.return_value = cursor
        introspector = TeradataIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="mydb", table_name="orders")],
        )
        assert result == {}

    def test_strips_padded_values(self):
        rows = [
            ("  mydb   ", "  orders  ", "  order_id  ", "GA"),
        ]
        conn = self._make_connection(rows)
        introspector = TeradataIntrospector()

        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="mydb", table_name="orders")],
        )

        assert "MYDB.ORDERS" in result
        assert "ORDER_ID" in result["MYDB.ORDERS"]["identity_columns"]


# ---------------------------------------------------------------------------
# DefaultIntrospector.introspect_columns
# ---------------------------------------------------------------------------


class TestDefaultIntrospectColumns:
    def test_always_returns_empty(self):
        conn = MagicMock()
        introspector = DefaultIntrospector()
        result = introspector.introspect_columns(
            conn, [TableConfig(schema_name="dbo", table_name="Foo")],
        )
        assert result == {}


# ---------------------------------------------------------------------------
# introspect_primary_keys — helpers
# ---------------------------------------------------------------------------

def _make_pk_connection(rows: list[tuple]) -> MagicMock:
    conn = MagicMock()
    cursor = MagicMock()
    cursor.fetchall.return_value = rows
    conn.cursor.return_value = cursor
    return conn


# ---------------------------------------------------------------------------
# SqlServerIntrospector.introspect_primary_keys
# ---------------------------------------------------------------------------


class TestSqlServerIntrospectPrimaryKeys:
    def test_single_column_pk(self):
        rows = [("Warehouse", "Colors", "ColorID", 1)]
        conn = _make_pk_connection(rows)
        result = SqlServerIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="Warehouse", table_name="Colors")],
        )
        assert result == {"WAREHOUSE.COLORS": ["COLORID"]}

    def test_composite_pk_preserves_ordinal(self):
        rows = [
            ("dbo", "OrderLines", "OrderID", 1),
            ("dbo", "OrderLines", "LineNumber", 2),
        ]
        conn = _make_pk_connection(rows)
        result = SqlServerIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="dbo", table_name="OrderLines")],
        )
        assert result == {"DBO.ORDERLINES": ["ORDERID", "LINENUMBER"]}

    def test_multiple_tables(self):
        rows = [
            ("dbo", "Colors", "ColorID", 1),
            ("dbo", "Orders", "OrderID", 1),
        ]
        conn = _make_pk_connection(rows)
        result = SqlServerIntrospector().introspect_primary_keys(
            conn, [
                TableConfig(schema_name="dbo", table_name="Colors"),
                TableConfig(schema_name="dbo", table_name="Orders"),
            ],
        )
        assert "DBO.COLORS" in result
        assert "DBO.ORDERS" in result

    def test_empty_configs_returns_empty(self):
        conn = MagicMock()
        assert SqlServerIntrospector().introspect_primary_keys(conn, []) == {}

    def test_no_pks_returns_empty(self):
        conn = _make_pk_connection([])
        result = SqlServerIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="dbo", table_name="NoPK")],
        )
        assert result == {}

    def test_query_failure_returns_empty(self):
        conn = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = Exception("connection lost")
        conn.cursor.return_value = cursor
        result = SqlServerIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="dbo", table_name="T")],
        )
        assert result == {}


# ---------------------------------------------------------------------------
# RedshiftIntrospector.introspect_primary_keys
# ---------------------------------------------------------------------------


class TestRedshiftIntrospectPrimaryKeys:
    def test_single_column_pk(self):
        rows = [("public", "users", "user_id", 1)]
        conn = _make_pk_connection(rows)
        result = RedshiftIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="public", table_name="users")],
        )
        assert result == {"PUBLIC.USERS": ["USER_ID"]}

    def test_composite_pk_preserves_ordinal(self):
        rows = [
            ("public", "order_lines", "order_id", 1),
            ("public", "order_lines", "line_number", 2),
        ]
        conn = _make_pk_connection(rows)
        result = RedshiftIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="public", table_name="order_lines")],
        )
        assert result == {"PUBLIC.ORDER_LINES": ["ORDER_ID", "LINE_NUMBER"]}

    def test_empty_configs_returns_empty(self):
        conn = MagicMock()
        assert RedshiftIntrospector().introspect_primary_keys(conn, []) == {}

    def test_no_pks_returns_empty(self):
        conn = _make_pk_connection([])
        result = RedshiftIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="public", table_name="nopk")],
        )
        assert result == {}

    def test_query_failure_returns_empty(self):
        conn = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = Exception("connection lost")
        conn.cursor.return_value = cursor
        result = RedshiftIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="public", table_name="t")],
        )
        assert result == {}


# ---------------------------------------------------------------------------
# TeradataIntrospector.introspect_primary_keys
# ---------------------------------------------------------------------------


class TestTeradataIntrospectPrimaryKeys:
    def test_single_column_pk(self):
        rows = [("mydb     ", "orders   ", "order_id ", 1)]
        conn = _make_pk_connection(rows)
        result = TeradataIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="mydb", table_name="orders")],
        )
        assert result == {"MYDB.ORDERS": ["ORDER_ID"]}

    def test_strips_padded_values(self):
        rows = [("  mydb  ", "  orders  ", "  pk_col  ", 1)]
        conn = _make_pk_connection(rows)
        result = TeradataIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="mydb", table_name="orders")],
        )
        assert result == {"MYDB.ORDERS": ["PK_COL"]}

    def test_composite_pk_preserves_ordinal(self):
        rows = [
            ("mydb", "order_lines", "order_id", 1),
            ("mydb", "order_lines", "line_num", 2),
        ]
        conn = _make_pk_connection(rows)
        result = TeradataIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="mydb", table_name="order_lines")],
        )
        assert result == {"MYDB.ORDER_LINES": ["ORDER_ID", "LINE_NUM"]}

    def test_empty_configs_returns_empty(self):
        conn = MagicMock()
        assert TeradataIntrospector().introspect_primary_keys(conn, []) == {}

    def test_no_pks_returns_empty(self):
        conn = _make_pk_connection([])
        result = TeradataIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="mydb", table_name="orders")],
        )
        assert result == {}

    def test_query_failure_returns_empty(self):
        conn = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = Exception("connection lost")
        conn.cursor.return_value = cursor
        result = TeradataIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="mydb", table_name="t")],
        )
        assert result == {}

    def test_cursor_creation_failure_returns_empty(self):
        conn = MagicMock()
        conn.cursor.side_effect = Exception("no cursor")
        result = TeradataIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="mydb", table_name="t")],
        )
        assert result == {}


# ---------------------------------------------------------------------------
# DefaultIntrospector.introspect_primary_keys
# ---------------------------------------------------------------------------


class TestDefaultIntrospectPrimaryKeys:
    def test_always_returns_empty(self):
        conn = MagicMock()
        result = DefaultIntrospector().introspect_primary_keys(
            conn, [TableConfig(schema_name="dbo", table_name="Foo")],
        )
        assert result == {}


# ---------------------------------------------------------------------------
# hash_row_expression
# ---------------------------------------------------------------------------


class TestSqlServerHashRowExpression:
    def test_single_column(self):
        expr = SqlServerIntrospector().hash_row_expression(["NAME"])
        assert "HASHBYTES('SHA2_256'" in expr
        assert '"NAME"' in expr

    def test_multi_column_includes_separator(self):
        expr = SqlServerIntrospector().hash_row_expression(["A", "B"])
        assert "CHAR(31)" in expr
        assert '"A"' in expr
        assert '"B"' in expr

    def test_null_safe_encoding(self):
        expr = SqlServerIntrospector().hash_row_expression(["COL"])
        assert "CHAR(0)" in expr
        assert "CHAR(1)" in expr
        assert "NVARCHAR(MAX)" in expr

    def test_empty_columns_returns_none(self):
        assert SqlServerIntrospector().hash_row_expression([]) is None

    def test_null_and_literal_null_are_distinguished_by_contract(self):
        expr = SqlServerIntrospector().hash_row_expression(["COL"])
        # Contract: do not collapse SQL NULL to literal text tokens.
        assert "COALESCE" not in expr
        assert "'NULL'" not in expr
        assert "CHAR(0)" in expr
        assert "CHAR(1)" in expr

    def test_uses_non_printable_separator_not_pipe(self):
        expr = SqlServerIntrospector().hash_row_expression(["A", "B", "C"])
        # Contract: avoid printable delimiters that can appear in values.
        assert "CHAR(31)" in expr
        assert "|" not in expr


class TestRedshiftHashRowExpression:
    def test_single_column(self):
        expr = RedshiftIntrospector().hash_row_expression(["name"])
        assert "MD5(" in expr
        assert '"name"' in expr

    def test_multi_column_includes_separator(self):
        expr = RedshiftIntrospector().hash_row_expression(["a", "b"])
        assert "CHR(31)" in expr
        assert '"a"' in expr
        assert '"b"' in expr

    def test_null_safe_encoding(self):
        expr = RedshiftIntrospector().hash_row_expression(["col"])
        assert "CHR(0)" in expr
        assert "CHR(1)" in expr

    def test_empty_columns_returns_none(self):
        assert RedshiftIntrospector().hash_row_expression([]) is None

    def test_null_and_literal_null_are_distinguished_by_contract(self):
        expr = RedshiftIntrospector().hash_row_expression(["col"])
        assert "COALESCE" not in expr
        assert "'NULL'" not in expr
        assert "CHR(0)" in expr
        assert "CHR(1)" in expr

    def test_uses_non_printable_separator_not_pipe_literal(self):
        expr = RedshiftIntrospector().hash_row_expression(["a", "b", "c"])
        assert "CHR(31)" in expr

    def test_varchar_cast_uses_max_length_to_avoid_truncation(self):
        expr = RedshiftIntrospector().hash_row_expression(["col"])
        assert "VARCHAR(65535)" in expr


class TestTeradataHashRowExpression:
    def test_returns_none(self):
        assert TeradataIntrospector().hash_row_expression(["COL"]) is None


class TestDefaultHashRowExpression:
    def test_returns_none(self):
        assert DefaultIntrospector().hash_row_expression(["COL"]) is None
