"""Tests for replay.delta_capture — snapshot_table and compute_table_delta.

Uses fake connection objects (not patches) to exercise the real
cursor-handling logic in snapshot_table, including column uppercasing,
hex encoding of bytes, and database-qualified SQL generation.

compute_table_delta is tested through the full chain:
snapshot data -> select_strategy -> FullSnapshotStrategy.compute_delta.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from test_runner.common.config import ReplayConfiguration
from test_runner.replay.delta_capture import (
    _build_pk_where,
    _sql_literal,
    build_two_pass_delta,
    compute_changed_pks,
    compute_table_delta,
    get_column_names,
    select_strategy,
    snapshot_table,
    snapshot_table_hashed,
    snapshot_table_selective,
    snapshot_table_with_hash,
)
from test_runner.replay.models import DeltaStrategy, TableConfig


# ---------------------------------------------------------------------------
# Helpers — fake connection that returns canned cursor data
# ---------------------------------------------------------------------------

def _fake_connection(description, rows):
    """Build a mock connection whose cursor returns *description* and *rows*.

    *description* is a list of (col_name, ...) tuples matching DB-API spec.
    *rows* is a list of tuples matching the column order.
    """
    conn = MagicMock()
    cursor = MagicMock()
    cursor.description = description
    cursor.fetchall.return_value = rows
    conn.cursor.return_value = cursor
    return conn, cursor


# ---------------------------------------------------------------------------
# snapshot_table
# ---------------------------------------------------------------------------

class TestSnapshotTable:

    def test_returns_rows_with_uppercased_column_names(self):
        conn, cursor = _fake_connection(
            description=[("color",), ("id",)],
            rows=[("Blue", 1), ("Red", 2)],
        )

        result = snapshot_table(conn, "dbo", "Colors")

        assert len(result) == 2
        assert result[0] == {"COLOR": "Blue", "ID": 1}
        assert result[1] == {"COLOR": "Red", "ID": 2}

    @pytest.mark.parametrize("database, expected_fragment, min_quotes", [
        (None, '"Warehouse"."Colors"', 4),
        ("CLONE_DB", '"CLONE_DB"."Warehouse"."Colors"', 6),
    ], ids=["two_part", "three_part"])
    def test_generates_qualified_sql(self, database, expected_fragment, min_quotes):
        conn, cursor = _fake_connection(
            description=[("id",)],
            rows=[(1,)],
        )

        snapshot_table(conn, "Warehouse", "Colors", database=database)

        sql = cursor.execute.call_args[0][0]
        assert expected_fragment in sql
        assert sql.count('"') >= min_quotes

    @pytest.mark.parametrize("binary_val, expected_hex", [
        (b"\x01\x02\x03", "010203"),
        (bytearray(b"\xff\x00"), "ff00"),
    ], ids=["bytes", "bytearray"])
    def test_hex_encodes_binary_columns(self, binary_val, expected_hex):
        conn, _ = _fake_connection(
            description=[("data",)],
            rows=[(binary_val,)],
        )

        result = snapshot_table(conn, "dbo", "T")

        assert result[0]["DATA"] == expected_hex

    def test_empty_table_returns_empty_list(self):
        conn, _ = _fake_connection(
            description=[("id",)],
            rows=[],
        )

        result = snapshot_table(conn, "dbo", "EmptyTable")

        assert result == []

    def test_cursor_is_always_closed(self):
        conn, cursor = _fake_connection(
            description=[("id",)],
            rows=[(1,)],
        )

        snapshot_table(conn, "dbo", "T")

        cursor.close.assert_called_once()

    def test_cursor_closed_even_on_error(self):
        conn = MagicMock()
        cursor = MagicMock()
        cursor.execute.side_effect = RuntimeError("connection lost")
        conn.cursor.return_value = cursor

        with pytest.raises(RuntimeError, match="connection lost"):
            snapshot_table(conn, "dbo", "T")

        cursor.close.assert_called_once()

    def test_preserves_none_values(self):
        conn, _ = _fake_connection(
            description=[("name",), ("age",)],
            rows=[("Alice", None)],
        )

        result = snapshot_table(conn, "dbo", "People")

        assert result[0]["NAME"] == "Alice"
        assert result[0]["AGE"] is None


# ---------------------------------------------------------------------------
# compute_table_delta — full chain through FullSnapshotStrategy
# ---------------------------------------------------------------------------

class TestComputeTableDelta:
    def _make_cfg(self, schema="S", table="T", ignore=None):
        return TableConfig(
            schema_name=schema,
            table_name=table,
            ignore_columns=ignore or [],
        )

    def test_detects_insert(self):
        before: list[dict] = []
        after = [{"COLOR": "Blue", "ID": 1}]
        cfg = self._make_cfg()
        replay_cfg = ReplayConfiguration()

        delta = compute_table_delta(before, after, cfg, replay_cfg)

        assert delta["inserts"] == [{"COLOR": "Blue", "ID": 1}]
        assert delta["deletes"] == []
        assert cfg.strategy == DeltaStrategy.FULL_SNAPSHOT

    def test_detects_delete(self):
        before = [{"COLOR": "Blue", "ID": 1}]
        after: list[dict] = []
        cfg = self._make_cfg()
        replay_cfg = ReplayConfiguration()

        delta = compute_table_delta(before, after, cfg, replay_cfg)

        assert delta["deletes"] == [{"COLOR": "Blue", "ID": 1}]
        assert delta["inserts"] == []

    def test_no_changes_returns_empty(self):
        rows = [{"COLOR": "Blue", "ID": 1}]
        cfg = self._make_cfg()
        replay_cfg = ReplayConfiguration()

        delta = compute_table_delta(rows, list(rows), cfg, replay_cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_sets_strategy_on_table_config(self):
        cfg = self._make_cfg()
        replay_cfg = ReplayConfiguration()

        compute_table_delta([], [], cfg, replay_cfg)

        assert cfg.strategy == DeltaStrategy.FULL_SNAPSHOT

    def test_ignore_columns_flow_through(self):
        before = [{"COLOR": "Blue", "VALIDFROM": "old"}]
        after = [{"COLOR": "Blue", "VALIDFROM": "new"}]
        cfg = self._make_cfg(ignore=["VALIDFROM"])
        replay_cfg = ReplayConfiguration()

        delta = compute_table_delta(before, after, cfg, replay_cfg)

        assert delta["inserts"] == []
        assert delta["deletes"] == []

    def test_delta_has_canonical_shape(self):
        cfg = self._make_cfg()
        replay_cfg = ReplayConfiguration()

        delta = compute_table_delta([], [], cfg, replay_cfg)

        assert "table" in delta
        assert "strategy_used" in delta
        assert "inserts" in delta
        assert "deletes" in delta
        assert "updates" in delta
        assert delta["strategy_used"] == "full_snapshot"


# ---------------------------------------------------------------------------
# get_column_names
# ---------------------------------------------------------------------------


class TestGetColumnNames:

    def test_returns_uppercased_column_names(self):
        conn, cursor = _fake_connection(
            description=[("color",), ("id",)],
            rows=[],
        )
        result = get_column_names(conn, "dbo", "Colors")
        assert result == ["COLOR", "ID"]
        sql = cursor.execute.call_args[0][0]
        assert "WHERE 1=0" in sql

    def test_cursor_always_closed(self):
        conn, cursor = _fake_connection(
            description=[("x",)], rows=[],
        )
        get_column_names(conn, "s", "t")
        cursor.close.assert_called_once()


# ---------------------------------------------------------------------------
# Two-pass snapshot functions
# ---------------------------------------------------------------------------


class TestSnapshotTableWithHash:

    def test_returns_rows_and_hash_index(self):
        conn, _ = _fake_connection(
            description=[("id",), ("name",), ("__ROW_HASH__",)],
            rows=[(1, "Blue", "abc123"), (2, "Red", "def456")],
        )
        rows, hash_idx = snapshot_table_with_hash(
            conn, "dbo", "Colors", ["ID"], "SHA256(..)",
        )

        assert len(rows) == 2
        assert rows[0] == {"ID": 1, "NAME": "Blue"}
        assert rows[1] == {"ID": 2, "NAME": "Red"}
        assert "__ROW_HASH__" not in rows[0]
        assert hash_idx[(1,)] == "abc123"
        assert hash_idx[(2,)] == "def456"

    def test_hex_encodes_binary_hash(self):
        conn, _ = _fake_connection(
            description=[("id",), ("__ROW_HASH__",)],
            rows=[(1, b"\xab\xcd")],
        )
        rows, hash_idx = snapshot_table_with_hash(
            conn, "dbo", "T", ["ID"], "HASHBYTES(..)",
        )
        assert rows[0] == {"ID": 1}
        assert hash_idx[(1,)] == "abcd"

    def test_empty_table(self):
        conn, _ = _fake_connection(
            description=[("id",), ("__ROW_HASH__",)],
            rows=[],
        )
        rows, hash_idx = snapshot_table_with_hash(
            conn, "dbo", "T", ["ID"], "SHA256(..)",
        )
        assert rows == []
        assert hash_idx == {}

    def test_composite_pk(self):
        conn, _ = _fake_connection(
            description=[("a",), ("b",), ("val",), ("__ROW_HASH__",)],
            rows=[(1, "x", "data", "h1")],
        )
        rows, hash_idx = snapshot_table_with_hash(
            conn, "dbo", "T", ["A", "B"], "SHA256(..)",
        )
        assert hash_idx[(1, "x")] == "h1"
        assert rows[0] == {"A": 1, "B": "x", "VAL": "data"}


class TestSnapshotTableHashed:

    def test_returns_hash_index(self):
        conn, _ = _fake_connection(
            description=[("id",), ("__ROW_HASH__",)],
            rows=[(1, "abc"), (2, "def")],
        )
        result = snapshot_table_hashed(
            conn, "dbo", "T", ["ID"], "SHA256(..)",
        )
        assert result == {(1,): "abc", (2,): "def"}

    def test_binary_hash_hex_encoded(self):
        conn, _ = _fake_connection(
            description=[("id",), ("__ROW_HASH__",)],
            rows=[(1, b"\xff\x00")],
        )
        result = snapshot_table_hashed(
            conn, "dbo", "T", ["ID"], "HASHBYTES(..)",
        )
        assert result == {(1,): "ff00"}

    def test_sql_selects_pk_and_hash_only(self):
        conn, cursor = _fake_connection(
            description=[("id",), ("__ROW_HASH__",)],
            rows=[],
        )
        snapshot_table_hashed(conn, "dbo", "T", ["ID"], "MY_HASH(..)")
        sql = cursor.execute.call_args[0][0]
        assert '"ID"' in sql
        assert "MY_HASH(..)" in sql
        assert "__ROW_HASH__" in sql


class TestSnapshotTableSelective:

    def test_fetches_specific_pks(self):
        conn, cursor = _fake_connection(
            description=[("id",), ("name",)],
            rows=[(1, "Blue"), (3, "Green")],
        )
        result = snapshot_table_selective(
            conn, "dbo", "T", ["ID"], [(1,), (3,)],
        )
        assert len(result) == 2
        assert result[0] == {"ID": 1, "NAME": "Blue"}
        sql = cursor.execute.call_args[0][0]
        assert '"ID" IN' in sql

    def test_empty_pk_values_returns_empty(self):
        conn = MagicMock()
        result = snapshot_table_selective(
            conn, "dbo", "T", ["ID"], [],
        )
        assert result == []
        conn.cursor.assert_not_called()

    def test_composite_pk_where_clause(self):
        conn, cursor = _fake_connection(
            description=[("a",), ("b",), ("val",)],
            rows=[(1, "x", "data")],
        )
        snapshot_table_selective(
            conn, "dbo", "T", ["A", "B"], [(1, "x")],
        )
        sql = cursor.execute.call_args[0][0]
        assert '"A" = 1' in sql
        assert '"B" = ' in sql


# ---------------------------------------------------------------------------
# compute_changed_pks
# ---------------------------------------------------------------------------


class TestComputeChangedPks:

    def test_inserts_deletes_updates(self):
        before = {(1,): "aaa", (2,): "bbb", (3,): "ccc"}
        after = {(2,): "bbb", (3,): "xxx", (4,): "ddd"}
        inserted, deleted, updated = compute_changed_pks(before, after)
        assert inserted == [(4,)]
        assert deleted == [(1,)]
        assert updated == [(3,)]

    def test_no_changes(self):
        hashes = {(1,): "a", (2,): "b"}
        inserted, deleted, updated = compute_changed_pks(hashes, dict(hashes))
        assert inserted == []
        assert deleted == []
        assert updated == []

    def test_all_new(self):
        inserted, deleted, updated = compute_changed_pks(
            {}, {(1,): "a", (2,): "b"},
        )
        assert inserted == [(1,), (2,)]
        assert deleted == []
        assert updated == []

    def test_all_deleted(self):
        inserted, deleted, updated = compute_changed_pks(
            {(1,): "a", (2,): "b"}, {},
        )
        assert inserted == []
        assert deleted == [(1,), (2,)]
        assert updated == []

    def test_empty_both_sides(self):
        inserted, deleted, updated = compute_changed_pks({}, {})
        assert inserted == []
        assert deleted == []
        assert updated == []

    def test_null_and_empty_string_hashes_count_as_update(self):
        # Edge case: NULL vs empty string must not hash identically.
        before = {(1,): "hash_for_null"}
        after = {(1,): "hash_for_empty"}
        inserted, deleted, updated = compute_changed_pks(before, after)
        assert inserted == []
        assert deleted == []
        assert updated == [(1,)]


# ---------------------------------------------------------------------------
# build_two_pass_delta
# ---------------------------------------------------------------------------


class TestBuildTwoPassDelta:

    def _cfg(self, schema="S", table="T"):
        return TableConfig(schema_name=schema, table_name=table)

    def test_inserts(self):
        before: list[dict] = [{"ID": 1, "NAME": "Old"}]
        after_sel = [{"ID": 2, "NAME": "New"}]
        delta = build_two_pass_delta(
            before, after_sel, ["ID"],
            inserted_pks=[(2,)], deleted_pks=[], updated_pks=[],
            table_cfg=self._cfg(),
        )
        assert delta["strategy_used"] == "pk_diff"
        assert delta["inserts"] == [{"ID": 2, "NAME": "New"}]
        assert delta["deletes"] == []
        assert delta["updates"] == []

    def test_deletes(self):
        before = [{"ID": 1, "NAME": "Gone"}]
        delta = build_two_pass_delta(
            before, [], ["ID"],
            inserted_pks=[], deleted_pks=[(1,)], updated_pks=[],
            table_cfg=self._cfg(),
        )
        assert delta["deletes"] == [{"ID": 1, "NAME": "Gone"}]

    def test_updates(self):
        before = [{"ID": 1, "NAME": "Old", "COLOR": "Blue"}]
        after_sel = [{"ID": 1, "NAME": "New", "COLOR": "Blue"}]
        delta = build_two_pass_delta(
            before, after_sel, ["ID"],
            inserted_pks=[], deleted_pks=[], updated_pks=[(1,)],
            table_cfg=self._cfg(),
        )
        assert len(delta["updates"]) == 1
        upd = delta["updates"][0]
        assert upd["key"] == {"ID": 1}
        assert upd["before"]["NAME"] == "Old"
        assert upd["after"]["NAME"] == "New"
        assert "NAME" in upd["changed_columns"]
        assert "COLOR" not in upd["changed_columns"]

    def test_mixed_operations(self):
        before = [
            {"ID": 1, "VAL": "a"},
            {"ID": 2, "VAL": "b"},
        ]
        after_sel = [
            {"ID": 2, "VAL": "B"},
            {"ID": 3, "VAL": "c"},
        ]
        delta = build_two_pass_delta(
            before, after_sel, ["ID"],
            inserted_pks=[(3,)], deleted_pks=[(1,)], updated_pks=[(2,)],
            table_cfg=self._cfg(),
        )
        assert len(delta["inserts"]) == 1
        assert len(delta["deletes"]) == 1
        assert len(delta["updates"]) == 1


# ---------------------------------------------------------------------------
# _sql_literal / _build_pk_where
# ---------------------------------------------------------------------------


class TestSqlLiteral:

    @pytest.mark.parametrize("val, expected", [
        (None, "NULL"),
        (42, "42"),
        (3.14, "3.14"),
        ("hello", "'hello'"),
        ("NULL", "'NULL'"),
        ("", "''"),
        ("A|B", "'A|B'"),
        ("it's", "'it''s'"),
        (True, "1"),
        (False, "0"),
        (b"\xab", "0xab"),
    ], ids=[
        "none", "int", "float", "str", "literal_null", "empty_str",
        "str_delimiter", "str_quote", "true", "false", "bytes",
    ])
    def test_values(self, val, expected):
        assert _sql_literal(val) == expected

    def test_datetime(self):
        import datetime
        dt = datetime.datetime(2025, 3, 15, 10, 30, 0)
        assert _sql_literal(dt) == "'2025-03-15T10:30:00'"

    def test_date(self):
        import datetime
        d = datetime.date(2025, 3, 15)
        assert _sql_literal(d) == "'2025-03-15'"

    def test_decimal(self):
        import decimal
        assert _sql_literal(decimal.Decimal("123.45")) == "123.45"

    def test_uuid(self):
        import uuid
        u = uuid.UUID("12345678-1234-5678-1234-567812345678")
        assert _sql_literal(u) == "'12345678-1234-5678-1234-567812345678'"


class TestBuildPkWhere:

    def test_single_pk_in_clause(self):
        result = _build_pk_where(["ID"], [(1,), (2,), (3,)])
        assert '"ID" IN (1, 2, 3)' == result

    def test_composite_pk_or_clauses(self):
        result = _build_pk_where(["A", "B"], [(1, "x"), (2, "y")])
        assert '("A" = 1 AND "B" = \'x\')' in result
        assert '("A" = 2 AND "B" = \'y\')' in result
        assert " OR " in result
