"""Tests for Redshift-specific side-effects capture workflow.

Verifies that ``capture_deltas`` works correctly with Redshift dialect:
- Uses ``RedshiftIntrospector`` for column introspection and identifier casing
- Lowercases table names (Redshift convention)
- Captures deltas via before/after snapshots within TransactionIsolation
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from test_runner.common.config import ReplayConfiguration
from test_runner.common.models import BaselineData
from test_runner.replay.capture_handler import (
    _resolve_table_configs,
    capture_deltas,
)
from test_runner.replay.source_introspector import (
    RedshiftIntrospector,
    SqlServerIntrospector,
)
from test_runner.validate.runner import _has_baseline_resultset


class TestResolveTableConfigsRedshift:
    """Verify identifier casing with RedshiftIntrospector."""

    def test_two_part_names_lowercased(self):
        introspector = RedshiftIntrospector()
        configs = _resolve_table_configs(["Public.Users"], introspector)

        assert configs[0].schema_name == "public"
        assert configs[0].table_name == "users"

    def test_three_part_names_lowercased(self):
        introspector = RedshiftIntrospector()
        configs = _resolve_table_configs(
            ["ecommerce_db.Public.Customer_Reviews"], introspector,
        )

        assert configs[0].schema_name == "public"
        assert configs[0].table_name == "customer_reviews"

    def test_sqlserver_preserves_case(self):
        introspector = SqlServerIntrospector()
        configs = _resolve_table_configs(["Warehouse.Colors"], introspector)

        assert configs[0].schema_name == "Warehouse"
        assert configs[0].table_name == "Colors"


class TestResolveTableConfigsPkColumns:
    """Verify _resolve_table_configs populates primary_key_columns from pk_columns_by_table."""

    def test_pk_columns_set_when_fqn_matches(self):
        introspector = SqlServerIntrospector()
        pk_map = {"dbo.Orders": ["OrderId", "LineId"]}

        configs = _resolve_table_configs(["dbo.Orders"], introspector, pk_map)

        assert configs[0].primary_key_columns == ["OrderId", "LineId"]

    def test_three_part_pk_key_matches_two_part_fqn(self):
        """PK map keyed by DB.SCHEMA.TABLE must match 2-part affected_table."""
        introspector = SqlServerIntrospector()
        pk_map = {"SrcDB.dbo.Orders": ["OrderId"]}

        configs = _resolve_table_configs(["dbo.Orders"], introspector, pk_map)

        assert configs[0].primary_key_columns == ["OrderId"]

    def test_two_part_pk_key_matches_three_part_fqn(self):
        """PK map keyed by SCHEMA.TABLE must match 3-part affected_table."""
        introspector = SqlServerIntrospector()
        pk_map = {"dbo.Orders": ["OrderId"]}

        configs = _resolve_table_configs(["SrcDB.dbo.Orders"], introspector, pk_map)

        assert configs[0].primary_key_columns == ["OrderId"]

    def test_pk_columns_empty_when_no_match(self):
        introspector = SqlServerIntrospector()
        pk_map = {"dbo.Products": ["ProductId"]}

        configs = _resolve_table_configs(["dbo.Orders"], introspector, pk_map)

        assert configs[0].primary_key_columns == []

    def test_pk_columns_empty_when_map_omitted(self):
        introspector = SqlServerIntrospector()

        configs = _resolve_table_configs(["dbo.Orders"], introspector)

        assert configs[0].primary_key_columns == []

    def test_pk_columns_with_three_part_name(self):
        introspector = RedshiftIntrospector()
        pk_map = {"mydb.public.events": ["event_id"]}

        configs = _resolve_table_configs(
            ["mydb.public.events"], introspector, pk_map,
        )

        assert configs[0].primary_key_columns == ["event_id"]
        assert configs[0].schema_name == "public"


class TestCaptureDeltasRedshift:
    """Integration test for capture_deltas with Redshift dialect."""

    def _make_connection(self, before_rows, after_rows, count=None):
        conn = MagicMock()
        cursors = []

        # Cursor for TransactionIsolation setup (BEGIN TRANSACTION)
        iso_cursor = MagicMock()
        cursors.append(iso_cursor)

        # Cursor for row count
        count_cursor = MagicMock()
        count_cursor.fetchone.return_value = (count or len(before_rows),)
        cursors.append(count_cursor)

        # Cursor for before snapshot
        before_cursor = MagicMock()
        before_cursor.description = [(k,) for k in before_rows[0]] if before_rows else []
        before_cursor.fetchall.return_value = [
            tuple(r.values()) for r in before_rows
        ] if before_rows else []
        cursors.append(before_cursor)

        # Cursor for after snapshot
        after_cursor = MagicMock()
        after_cursor.description = [(k,) for k in after_rows[0]] if after_rows else []
        after_cursor.fetchall.return_value = [
            tuple(r.values()) for r in after_rows
        ] if after_rows else []
        cursors.append(after_cursor)

        # Cursor for TransactionIsolation teardown (ROLLBACK)
        teardown_cursor = MagicMock()
        cursors.append(teardown_cursor)

        conn.cursor.side_effect = cursors
        conn.autocommit = True
        return conn

    def test_redshift_uses_lowercase_table_names(self):
        """When dialect is 'redshift', table names must be lowercased.

        Uses the real snapshot_table → compute_table_delta chain with
        fake cursors — no patches on inner functions.
        Cursor sequence: pk_introspect, col_introspect, iso_setup,
        count, before, after, iso_teardown.
        """
        from test_runner.capture.sources.redshift import RedshiftExecutorFactory
        factory = RedshiftExecutorFactory()

        conn = MagicMock()
        conn.autocommit = True

        pk_cursor = MagicMock()
        pk_cursor.fetchall.return_value = []

        introspect_cursor = MagicMock()
        introspect_cursor.fetchall.return_value = []

        iso_setup = MagicMock()

        count_cursor = MagicMock()
        count_cursor.fetchone.return_value = (0,)

        before_cursor = MagicMock()
        before_cursor.description = [("color",)]
        before_cursor.fetchall.return_value = []

        after_cursor = MagicMock()
        after_cursor.description = [("color",)]
        after_cursor.fetchall.return_value = [("Blue",)]

        iso_teardown = MagicMock()
        conn.cursor.side_effect = [
            pk_cursor, introspect_cursor, iso_setup,
            count_cursor, before_cursor,
            after_cursor, iso_teardown,
        ]

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["ecommerce_db.Public.Customer_Reviews"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: "ok",
            executor_factory=factory,
            code_unit_name="test_proc",
        )

        assert "public.customer_reviews" in deltas
        assert deltas["public.customer_reviews"]["inserts"] == [{"COLOR": "Blue"}]

    def test_redshift_introspects_columns(self):
        """Redshift dialect introspects identity columns from information_schema.

        Uses fake cursors that satisfy RedshiftIntrospector's query protocol:
        1. introspect_primary_keys cursor
        2. introspect_columns cursor → returns identity column rows
        3. row-count cursor
        4. before snapshot cursor
        5. after snapshot cursor
        """
        from test_runner.capture.sources.redshift import RedshiftExecutorFactory
        factory = RedshiftExecutorFactory()

        conn = MagicMock()
        conn.autocommit = True

        pk_cursor = MagicMock()
        pk_cursor.fetchall.return_value = []

        introspect_cursor = MagicMock()
        introspect_cursor.fetchall.return_value = [
            ("public", "customer_reviews", "review_id", '"identity"(1,0)')
        ]

        count_cursor = MagicMock()
        count_cursor.fetchone.return_value = (0,)

        before_cursor = MagicMock()
        before_cursor.description = [("id",)]
        before_cursor.fetchall.return_value = []

        after_cursor = MagicMock()
        after_cursor.description = [("id",)]
        after_cursor.fetchall.return_value = []

        iso_setup = MagicMock()
        iso_teardown = MagicMock()
        conn.cursor.side_effect = [
            pk_cursor, introspect_cursor, iso_setup,
            count_cursor, before_cursor,
            after_cursor, iso_teardown,
        ]

        _, _, col_metadata = capture_deltas(
            connection=conn,
            affected_tables=["public.customer_reviews"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=factory,
            code_unit_name="test_proc",
        )

        assert col_metadata["PUBLIC.CUSTOMER_REVIEWS"]["identity_columns"] == ["REVIEW_ID"]
        assert "REVIEW_ID" in col_metadata["PUBLIC.CUSTOMER_REVIEWS"]["platform_managed_columns"]

    def test_empty_affected_tables_skips_delta_capture(self):
        """With no affected_tables, capture_deltas should just call execute_fn."""
        conn = MagicMock()
        exec_result = MagicMock()
        
        from test_runner.capture.sources.redshift import RedshiftExecutorFactory
        factory = RedshiftExecutorFactory()

        result, deltas, col_meta = capture_deltas(
            connection=conn,
            affected_tables=[],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: exec_result,
            executor_factory=factory,
        )

        assert result is exec_result
        assert deltas == {}
        assert col_meta == {}


class TestHasBaselineResultset:
    """Verify _has_baseline_resultset correctly classifies DML vs data baselines.

    These tests call the extracted production function directly instead
    of duplicating the boolean logic inline.  Covers the Redshift DML
    false-positive fix (empty result_sets=[[]], row_counts=[0]).
    """

    def _bl(self, **overrides) -> BaselineData:
        defaults = dict(
            procedure="p", parameters={}, captured_at="t",
            result_sets=[], row_counts=[], success=True,
        )
        defaults.update(overrides)
        return BaselineData(**defaults)

    @pytest.mark.parametrize("result_sets, row_counts, expected", [
        ([[]], [0], False),
        ([], [], False),
        (None, None, False),
        ([[{"Id": 1}]], [1], True),
        ([[], [{"Id": 1}]], [0, 1], True),
    ], ids=[
        "empty_inner_list_is_no_baseline",
        "empty_outer_lists_is_no_baseline",
        "none_lists_is_no_baseline",
        "populated_result_is_baseline",
        "mixed_result_sets_with_data_is_baseline",
    ])
    def test_has_baseline_resultset(self, result_sets, row_counts, expected):
        bl = self._bl(result_sets=result_sets, row_counts=row_counts)
        assert _has_baseline_resultset(bl) is expected
