"""Integration tests for capture_handler.capture_deltas.

Exercises the full chain: _get_row_count → snapshot_table →
compute_table_delta using fake connection objects.  No patches on
inner functions — only the outermost DB boundary (the connection)
and executor_factory infrastructure are faked.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

import pytest

from test_runner.common.config import ReplayConfiguration
from test_runner.replay.capture_handler import _pk_values_unique, capture_deltas
from test_runner.replay.source_introspector import DefaultIntrospector


# ---------------------------------------------------------------------------
# Fake DB boundary objects
# ---------------------------------------------------------------------------

class _FakeCursor:
    """Minimal DB-API cursor returning canned data."""

    def __init__(
        self,
        *,
        description=None,
        rows=None,
        fetchone_result=None,
        execute_error=None,
    ):
        self.description = description
        self._rows = rows or []
        self._fetchone = fetchone_result
        self._execute_error = execute_error
        self.executed: list[str] = []
        self._closed = False

    def execute(self, sql: str) -> None:
        if self._execute_error:
            raise self._execute_error
        self.executed.append(sql)

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._fetchone

    def close(self) -> None:
        self._closed = True


def _count_cursor(row_count: int) -> _FakeCursor:
    """Cursor for _get_row_count: returns a single (count,) row."""
    return _FakeCursor(fetchone_result=(row_count,))


def _snapshot_cursor(description, rows) -> _FakeCursor:
    """Cursor for snapshot_table: column description + rows."""
    return _FakeCursor(description=description, rows=rows)


class _FakeConnection:
    """Returns pre-built cursors in FIFO order."""

    def __init__(self, cursors: list[_FakeCursor]):
        self._cursors = list(cursors)
        self._idx = 0

    def cursor(self) -> _FakeCursor:
        c = self._cursors[self._idx]
        self._idx += 1
        return c


def _mock_executor_factory():
    """Factory that returns DefaultIntrospector + no-op mock isolation.

    DefaultIntrospector uppercases identifiers and returns empty
    column metadata (no DB calls needed).  Isolation is an
    infrastructure boundary, so mocking it is justified.
    """
    factory = MagicMock()
    factory.create_introspector.return_value = DefaultIntrospector()
    factory.create_isolation.return_value = MagicMock()
    return factory


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestCaptureDeltasIntegration:

    def test_full_chain_produces_deltas(self):
        """Before=empty, after=1 row → delta with 1 insert."""
        count_c = _count_cursor(5)
        before_c = _snapshot_cursor([("color",)], [])
        after_c = _snapshot_cursor([("color",)], [("Blue",)])
        conn = _FakeConnection([count_c, before_c, after_c])

        result, deltas, col_meta = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: "exec_result",
            executor_factory=_mock_executor_factory(),
        )

        assert result == "exec_result"
        assert deltas["DBO.COLORS"]["inserts"] == [{"COLOR": "Blue"}]
        assert deltas["DBO.COLORS"]["deletes"] == []
        assert count_c.executed == ['SELECT COUNT(*) FROM "DBO"."COLORS"']
        assert before_c.executed == ['SELECT * FROM "DBO"."COLORS"']
        assert after_c.executed == ['SELECT * FROM "DBO"."COLORS"']

    def test_no_changes_produces_empty_deltas(self):
        """Same before and after → delta_total_changes == 0 → excluded."""
        conn = _FakeConnection([
            _count_cursor(1),
            _snapshot_cursor([("color",)], [("Blue",)]),
            _snapshot_cursor([("color",)], [("Blue",)]),
        ])

        result, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: "ok",
            executor_factory=_mock_executor_factory(),
        )

        assert deltas == {}

    def test_empty_affected_tables_skips_capture(self):
        """No affected tables → execute_fn called directly, no snapshots."""
        conn = _FakeConnection([])

        result, deltas, col_meta = capture_deltas(
            connection=conn,
            affected_tables=[],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: "direct",
            executor_factory=_mock_executor_factory(),
        )

        assert result == "direct"
        assert deltas == {}
        assert col_meta == {}

    def test_large_table_skipped(self):
        """Row count exceeding large_table_threshold → table excluded.

        execute_fn must still be called even when all tables are skipped.
        """
        conn = _FakeConnection([
            _count_cursor(20_000_000),
        ])
        cfg = ReplayConfiguration()
        cfg.large_table_threshold = 10_000_000

        result, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.BigTable"],
            replay_cfg=cfg,
            execute_fn=lambda: "ok",
            executor_factory=_mock_executor_factory(),
        )

        assert result == "ok"
        assert deltas == {}

    def test_multiple_tables_each_get_own_delta(self):
        """Two affected tables → both captured independently.

        Cursor order: count(Colors), count(Orders), before(Colors),
        before(Orders), after(Colors), after(Orders).  SQL assertions
        verify each cursor received the expected query.
        """
        cnt_colors = _count_cursor(2)
        cnt_orders = _count_cursor(1)
        bef_colors = _snapshot_cursor([("color",)], [])
        bef_orders = _snapshot_cursor([("id",)], [])
        aft_colors = _snapshot_cursor([("color",)], [("Blue",)])
        aft_orders = _snapshot_cursor([("id",)], [(1,)])
        conn = _FakeConnection([
            cnt_colors, cnt_orders,
            bef_colors, bef_orders,
            aft_colors, aft_orders,
        ])

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors", "dbo.Orders"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=_mock_executor_factory(),
        )

        assert deltas["DBO.COLORS"]["inserts"] == [{"COLOR": "Blue"}]
        assert deltas["DBO.ORDERS"]["inserts"] == [{"ID": 1}]
        assert cnt_colors.executed == ['SELECT COUNT(*) FROM "DBO"."COLORS"']
        assert cnt_orders.executed == ['SELECT COUNT(*) FROM "DBO"."ORDERS"']
        assert bef_colors.executed == ['SELECT * FROM "DBO"."COLORS"']
        assert aft_orders.executed == ['SELECT * FROM "DBO"."ORDERS"']

    def test_get_row_count_failure_falls_back_to_zero(self):
        """Cursor error during COUNT(*) → fallback to 0, table still captured."""
        conn = _FakeConnection([
            _FakeCursor(execute_error=RuntimeError("connection reset")),
            _snapshot_cursor([("id",)], []),
            _snapshot_cursor([("id",)], [(1,)]),
        ])

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.T"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=_mock_executor_factory(),
        )

        assert "DBO.T" in deltas
        assert deltas["DBO.T"]["inserts"] == [{"ID": 1}]

    def test_4_part_table_name_raises_value_error(self):
        """Names with 4+ dot-parts indicate un-escaped identifiers → ValueError."""
        conn = _FakeConnection([])

        with pytest.raises(ValueError, match="4 dot-separated parts"):
            capture_deltas(
                connection=conn,
                affected_tables=["db.schema.table.extra"],
                replay_cfg=ReplayConfiguration(),
                execute_fn=lambda: None,
                executor_factory=_mock_executor_factory(),
            )

    def test_isolation_setup_and_teardown_bracket_execution(self):
        """Isolation provider's setup/teardown wrap the capture cycle.

        Isolation is an infrastructure boundary — mocking it is justified
        because we are testing the capture orchestration, not the isolation
        SQL.  We verify the call order (setup before snapshots, teardown
        after) via a recording list.
        """
        call_order: list[str] = []
        factory = _mock_executor_factory()
        mock_iso = factory.create_isolation.return_value
        mock_iso.setup.side_effect = lambda c: call_order.append("setup")
        mock_iso.teardown.side_effect = lambda c: call_order.append("teardown")

        conn = _FakeConnection([
            _count_cursor(1),
            _snapshot_cursor([("id",)], []),
            _snapshot_cursor([("id",)], []),
        ])

        capture_deltas(
            connection=conn,
            affected_tables=["dbo.T"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: call_order.append("execute"),
            executor_factory=factory,
        )

        assert call_order == ["setup", "execute", "teardown"]


# ---------------------------------------------------------------------------
# PK uniqueness validation
# ---------------------------------------------------------------------------


class TestPkValuesUnique:

    @pytest.mark.parametrize("rows, pk_columns, expected", [
        ([], ["ID"], True),
        ([{"ID": 1}, {"ID": 2}], ["ID"], True),
        ([{"ID": 1}, {"ID": 1}], ["ID"], False),
        ([{"A": 1, "B": 1}, {"A": 1, "B": 2}], ["A", "B"], True),
        ([{"A": 1, "B": 1}, {"A": 1, "B": 1}], ["A", "B"], False),
        ([{"ID": None}, {"ID": None}], ["ID"], False),
        ([{"ID": 1}], [], True),
    ], ids=[
        "empty_rows",
        "unique_single_pk",
        "duplicate_single_pk",
        "unique_composite_pk",
        "duplicate_composite_pk",
        "duplicate_nulls",
        "no_pk_columns",
    ])
    def test_pk_uniqueness(self, rows, pk_columns, expected):
        assert _pk_values_unique(rows, pk_columns) is expected


# ---------------------------------------------------------------------------
# PK discovery integration
# ---------------------------------------------------------------------------


class _PkAwareIntrospector(DefaultIntrospector):
    """DefaultIntrospector that also returns canned PK data."""

    def __init__(self, pk_map: dict[str, list[str]]):
        self._pk_map = pk_map

    def introspect_primary_keys(self, connection, table_configs):
        return {
            fqn: cols
            for fqn, cols in self._pk_map.items()
            if any(tc.fqn == fqn for tc in table_configs)
        }


def _mock_executor_factory_with_pks(pk_map: dict[str, list[str]]):
    factory = MagicMock()
    factory.create_introspector.return_value = _PkAwareIntrospector(pk_map)
    factory.create_isolation.return_value = MagicMock()
    return factory


class TestPkDiscoveryIntegration:

    def test_discovered_pk_persisted_in_delta(self):
        """When introspector discovers PKs, they appear in delta['pk_columns']."""
        conn = _FakeConnection([
            _count_cursor(3),
            _snapshot_cursor([("id",), ("name",)], []),
            _snapshot_cursor([("id",), ("name",)], [(1, "Blue")]),
        ])
        factory = _mock_executor_factory_with_pks({"DBO.COLORS": ["ID"]})

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=factory,
        )

        assert "DBO.COLORS" in deltas
        assert deltas["DBO.COLORS"]["pk_columns"] == ["ID"]

    def test_cur_pks_take_precedence_over_introspection(self):
        """CUR-supplied PKs should prevent introspection from running."""
        conn = _FakeConnection([
            _count_cursor(3),
            _snapshot_cursor([("color_id",), ("name",)], []),
            _snapshot_cursor([("color_id",), ("name",)], [(1, "Blue")]),
        ])
        factory = _mock_executor_factory_with_pks(
            {"DBO.COLORS": ["INTROSPECTED_COL"]},
        )

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=factory,
            pk_columns_by_table={"dbo.Colors": ["COLOR_ID"]},
        )

        assert deltas["DBO.COLORS"]["pk_columns"] == ["COLOR_ID"]

    def test_no_pk_discovered_no_pk_columns_key(self):
        """Tables without PKs (CUR or introspected) get no pk_columns key."""
        conn = _FakeConnection([
            _count_cursor(3),
            _snapshot_cursor([("name",)], []),
            _snapshot_cursor([("name",)], [("Blue",)]),
        ])
        factory = _mock_executor_factory_with_pks({})

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=factory,
        )

        assert "pk_columns" not in deltas["DBO.COLORS"]

    def test_discovered_pk_enables_pk_diff_strategy(self):
        """When introspection finds PKs, the strategy should be PK_DIFF."""
        conn = _FakeConnection([
            _count_cursor(3),
            _snapshot_cursor([("id",), ("name",)], [(1, "Red")]),
            _snapshot_cursor([("id",), ("name",)], [(1, "Red"), (2, "Blue")]),
        ])
        factory = _mock_executor_factory_with_pks({"DBO.COLORS": ["ID"]})

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=factory,
        )

        assert deltas["DBO.COLORS"]["strategy_used"] == "pk_diff"

    def test_mixed_tables_some_with_pks_some_without(self):
        """Introspection only runs for tables lacking CUR PKs."""
        conn = _FakeConnection([
            _count_cursor(2),
            _count_cursor(2),
            _snapshot_cursor([("id",), ("name",)], []),
            _snapshot_cursor([("val",)], []),
            _snapshot_cursor([("id",), ("name",)], [(1, "X")]),
            _snapshot_cursor([("val",)], [("Y",)]),
        ])
        factory = _mock_executor_factory_with_pks(
            {"DBO.NOPK": []},
        )

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.WithPK", "dbo.NoPK"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=factory,
            pk_columns_by_table={"dbo.WithPK": ["ID"]},
        )

        assert deltas["DBO.WITHPK"]["pk_columns"] == ["ID"]
        assert "pk_columns" not in deltas["DBO.NOPK"]

    def test_advisory_pk_with_duplicates_falls_back(self):
        """When discovered PK columns have duplicate values (advisory PK),
        the PK should be cleared and a non-PK strategy used instead.
        """
        conn = _FakeConnection([
            _count_cursor(3),
            _snapshot_cursor(
                [("id",), ("name",)],
                [(1, "Red"), (1, "Blue"), (2, "Green")],
            ),
            _snapshot_cursor(
                [("id",), ("name",)],
                [(1, "Red"), (1, "Blue"), (2, "Green"), (3, "Yellow")],
            ),
        ])
        factory = _mock_executor_factory_with_pks({"DBO.COLORS": ["ID"]})

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=factory,
        )

        assert deltas["DBO.COLORS"]["strategy_used"] == "full_snapshot"
        assert "pk_columns" not in deltas["DBO.COLORS"]

    def test_unique_pk_values_pass_validation(self):
        """When discovered PK columns have unique values, PK_DIFF is used."""
        conn = _FakeConnection([
            _count_cursor(3),
            _snapshot_cursor(
                [("id",), ("name",)],
                [(1, "Red"), (2, "Blue")],
            ),
            _snapshot_cursor(
                [("id",), ("name",)],
                [(1, "Red"), (2, "Blue"), (3, "Green")],
            ),
        ])
        factory = _mock_executor_factory_with_pks({"DBO.COLORS": ["ID"]})

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(),
            execute_fn=lambda: None,
            executor_factory=factory,
        )

        assert deltas["DBO.COLORS"]["strategy_used"] == "pk_diff"
        assert deltas["DBO.COLORS"]["pk_columns"] == ["ID"]


# ---------------------------------------------------------------------------
# Two-pass fetch integration
# ---------------------------------------------------------------------------


class _TwoPassIntrospector(DefaultIntrospector):
    """DefaultIntrospector that also supports hash_row_expression."""

    def __init__(self, pk_map: dict[str, list[str]] | None = None):
        self._pk_map = pk_map or {}

    def introspect_primary_keys(self, connection, table_configs):
        return {
            fqn: cols
            for fqn, cols in self._pk_map.items()
            if any(tc.fqn == fqn for tc in table_configs)
        }

    def hash_row_expression(self, columns):
        if not columns:
            return None
        col_list = ", ".join(f'"{c}"' for c in columns)
        return f"SHA256({col_list})"


def _mock_two_pass_factory(pk_map=None):
    factory = MagicMock()
    factory.create_introspector.return_value = _TwoPassIntrospector(pk_map)
    factory.create_isolation.return_value = MagicMock()
    return factory


def _col_names_cursor(columns: list[str]) -> _FakeCursor:
    """Cursor for get_column_names: description only, no rows."""
    return _FakeCursor(
        description=[(c,) for c in columns],
        rows=[],
    )


def _hash_snapshot_cursor(description, rows) -> _FakeCursor:
    """Cursor for snapshot_table_with_hash or snapshot_table_hashed."""
    return _FakeCursor(description=description, rows=rows)


class TestTwoPassCaptureIntegration:

    def test_two_pass_detects_insert(self):
        """Wide table with PK → two-pass after.

        Cursor sequence:
        1. COUNT(*)
        2. get_column_names (SELECT * WHERE 1=0)
        3. snapshot_table_with_hash (before, full + hash)
        4. snapshot_table_hashed (after, pk + hash only)
        5. snapshot_table_selective (after, changed rows)
        """
        # Generate 25 columns to exceed threshold of 20
        cols = ["ID"] + [f"C{i}" for i in range(24)]
        col_desc = [(c,) for c in cols]
        hash_col_desc = col_desc + [("__ROW_HASH__",)]

        before_row = tuple([1] + list(range(24)))
        before_with_hash = before_row + ("hash_old",)

        conn = _FakeConnection([
            _count_cursor(5),
            _col_names_cursor(cols),
            _hash_snapshot_cursor(
                hash_col_desc,
                [before_with_hash],
            ),
            _hash_snapshot_cursor(
                [("ID",), ("__ROW_HASH__",)],
                [(1, "hash_old"), (2, "hash_new")],
            ),
            _snapshot_cursor(
                col_desc,
                [tuple([2] + list(range(100, 124)))],
            ),
        ])

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.T"],
            replay_cfg=ReplayConfiguration(two_pass_column_threshold=20),
            execute_fn=lambda: None,
            executor_factory=_mock_two_pass_factory(),
            pk_columns_by_table={"dbo.T": ["ID"]},
        )

        assert "DBO.T" in deltas
        assert deltas["DBO.T"]["strategy_used"] == "pk_diff"
        assert len(deltas["DBO.T"]["inserts"]) == 1
        assert deltas["DBO.T"]["inserts"][0]["ID"] == 2
        assert deltas["DBO.T"].get("metadata", {}).get("two_pass") is True

    def test_two_pass_detects_delete(self):
        cols = ["ID"] + [f"C{i}" for i in range(24)]
        col_desc = [(c,) for c in cols]
        hash_col_desc = col_desc + [("__ROW_HASH__",)]

        before_row_1 = tuple([1] + list(range(24)))
        before_row_2 = tuple([2] + list(range(100, 124)))

        conn = _FakeConnection([
            _count_cursor(5),
            _col_names_cursor(cols),
            _hash_snapshot_cursor(
                hash_col_desc,
                [before_row_1 + ("h1",), before_row_2 + ("h2",)],
            ),
            _hash_snapshot_cursor(
                [("ID",), ("__ROW_HASH__",)],
                [(1, "h1")],
            ),
            # No selective fetch for deletes (only inserts+updates)
        ])

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.T"],
            replay_cfg=ReplayConfiguration(two_pass_column_threshold=20),
            execute_fn=lambda: None,
            executor_factory=_mock_two_pass_factory(),
            pk_columns_by_table={"dbo.T": ["ID"]},
        )

        assert len(deltas["DBO.T"]["deletes"]) == 1
        assert deltas["DBO.T"]["deletes"][0]["ID"] == 2

    def test_two_pass_no_changes_skipped(self):
        """When hashes are identical, no selective fetch and no delta."""
        cols = ["ID"] + [f"C{i}" for i in range(24)]
        col_desc = [(c,) for c in cols]
        hash_col_desc = col_desc + [("__ROW_HASH__",)]

        before_row = tuple([1] + list(range(24)))

        conn = _FakeConnection([
            _count_cursor(5),
            _col_names_cursor(cols),
            _hash_snapshot_cursor(
                hash_col_desc,
                [before_row + ("same_hash",)],
            ),
            _hash_snapshot_cursor(
                [("ID",), ("__ROW_HASH__",)],
                [(1, "same_hash")],
            ),
        ])

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.T"],
            replay_cfg=ReplayConfiguration(two_pass_column_threshold=20),
            execute_fn=lambda: None,
            executor_factory=_mock_two_pass_factory(),
            pk_columns_by_table={"dbo.T": ["ID"]},
        )

        assert deltas == {}

    def test_narrow_table_uses_one_pass(self):
        """Table with < threshold columns uses regular one-pass."""
        conn = _FakeConnection([
            _count_cursor(5),
            _col_names_cursor(["ID", "NAME"]),
            _snapshot_cursor([("id",), ("name",)], []),
            _snapshot_cursor([("id",), ("name",)], [(1, "Blue")]),
        ])

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Colors"],
            replay_cfg=ReplayConfiguration(two_pass_column_threshold=20),
            execute_fn=lambda: None,
            executor_factory=_mock_two_pass_factory(),
            pk_columns_by_table={"dbo.Colors": ["ID"]},
        )

        assert deltas["DBO.COLORS"]["inserts"] == [{"ID": 1, "NAME": "Blue"}]

    def test_no_pk_uses_one_pass(self):
        """Table without PKs always uses one-pass regardless of width."""
        cols = ["V" + str(i) for i in range(25)]
        col_desc = [(c,) for c in cols]

        conn = _FakeConnection([
            _count_cursor(5),
            _snapshot_cursor(col_desc, []),
            _snapshot_cursor(col_desc, [tuple(range(25))]),
        ])

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.Wide"],
            replay_cfg=ReplayConfiguration(two_pass_column_threshold=20),
            execute_fn=lambda: None,
            executor_factory=_mock_two_pass_factory(),
        )

        assert deltas["DBO.WIDE"]["strategy_used"] == "full_snapshot"

    def test_two_pass_fallback_on_many_changes(self):
        """When >50% of rows changed, fall back to full after-snapshot."""
        cols = ["ID"] + [f"C{i}" for i in range(24)]
        col_desc = [(c,) for c in cols]
        hash_col_desc = col_desc + [("__ROW_HASH__",)]

        before_rows = [
            tuple([i] + list(range(i * 100, i * 100 + 24))) + (f"h{i}",)
            for i in range(1, 4)
        ]

        conn = _FakeConnection([
            _count_cursor(3),
            _col_names_cursor(cols),
            _hash_snapshot_cursor(hash_col_desc, before_rows),
            _hash_snapshot_cursor(
                [("ID",), ("__ROW_HASH__",)],
                [(1, "changed1"), (2, "changed2"), (3, "changed3")],
            ),
            _snapshot_cursor(
                col_desc,
                [tuple([i] + list(range(i * 200, i * 200 + 24))) for i in range(1, 4)],
            ),
        ])

        _, deltas, _ = capture_deltas(
            connection=conn,
            affected_tables=["dbo.T"],
            replay_cfg=ReplayConfiguration(two_pass_column_threshold=20),
            execute_fn=lambda: None,
            executor_factory=_mock_two_pass_factory(),
            pk_columns_by_table={"dbo.T": ["ID"]},
        )

        assert "DBO.T" in deltas
        assert deltas["DBO.T"].get("metadata", {}).get("two_pass") is not True
