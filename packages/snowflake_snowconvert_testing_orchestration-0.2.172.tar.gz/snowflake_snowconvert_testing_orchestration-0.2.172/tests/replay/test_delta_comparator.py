"""Tests for replay.delta_comparator — comparison logic and ignore_columns."""

from __future__ import annotations

import polars as pl
import pytest

from test_runner.replay.delta_comparator import (
    _align_datetime_columns,
    _sortable,
    _strip_columns,
    compare_table_deltas,
)


class TestStripColumns:
    def test_strips_matching_columns(self):
        rows = [{"A": 1, "B": 2, "C": 3}]
        result = _strip_columns(rows, {"B"})
        assert result == [{"A": 1, "C": 3}]

    def test_case_insensitive(self):
        rows = [{"ValidFrom": "2024-01-01", "Name": "x"}]
        result = _strip_columns(rows, {"VALIDFROM"})
        assert result == [{"Name": "x"}]

    def test_empty_ignore_returns_original(self):
        rows = [{"A": 1}]
        assert _strip_columns(rows, set()) is rows

    def test_empty_rows_returns_original(self):
        assert _strip_columns([], {"A"}) == []

    def test_multiple_rows(self):
        rows = [
            {"A": 1, "B": 2, "C": 3},
            {"A": 4, "B": 5, "C": 6},
        ]
        result = _strip_columns(rows, {"B", "C"})
        assert result == [{"A": 1}, {"A": 4}]


class TestCompareTableDeltasIgnoreColumns:
    """Verify that ignore_columns strips columns before comparison."""

    def test_match_when_only_ignored_columns_differ(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01", "VALIDTO": "9999-12-31"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2026-03-11", "VALIDTO": "2099-01-01"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            ignore_columns=["VALIDFROM", "VALIDTO"],
        )
        assert result["match"] is True

    def test_mismatch_on_non_ignored_column(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Red", "VALIDFROM": "2026-03-11"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is False

    def test_no_ignore_columns_compares_everything(self):
        baseline = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2024-01-01"}],
            "deletes": [],
            "updates": [],
        }
        actual = {
            "inserts": [{"COLOR": "Blue", "VALIDFROM": "2026-03-11"}],
            "deletes": [],
            "updates": [],
        }

        result = compare_table_deltas(baseline, actual, "S.T")
        assert result["match"] is False

    def test_ignore_columns_applied_to_deletes(self):
        baseline = {
            "inserts": [],
            "deletes": [{"NAME": "X", "VALIDFROM": "old"}],
            "updates": [],
        }
        actual = {
            "inserts": [],
            "deletes": [{"NAME": "X", "VALIDFROM": "new"}],
            "updates": [],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is True

    def test_ignore_columns_applied_to_updates(self):
        baseline = {
            "inserts": [],
            "deletes": [],
            "updates": [{"after": {"NAME": "X", "VALIDFROM": "old"}}],
        }
        actual = {
            "inserts": [],
            "deletes": [],
            "updates": [{"after": {"NAME": "X", "VALIDFROM": "new"}}],
        }

        result = compare_table_deltas(
            baseline, actual, "S.T",
            ignore_columns=["VALIDFROM"],
        )
        assert result["match"] is True


# ---------------------------------------------------------------------------
# Count mismatch detection
# ---------------------------------------------------------------------------

class TestCompareTableDeltasCountMismatches:
    """Each mutation category detects count mismatches independently."""

    @pytest.mark.parametrize("category, diff_type", [
        ("inserts", "insert_count_mismatch"),
        ("deletes", "delete_count_mismatch"),
        ("updates", "update_count_mismatch"),
    ], ids=["inserts", "deletes", "updates"])
    def test_count_mismatch_detected(self, category, diff_type):
        baseline = {"inserts": [], "deletes": [], "updates": []}
        actual = {"inserts": [], "deletes": [], "updates": []}
        baseline[category] = [{"ID": 1}]
        actual[category] = [{"ID": 1}, {"ID": 2}]

        result = compare_table_deltas(baseline, actual, "S.T")

        assert result["match"] is False
        assert any(d["type"] == diff_type for d in result["differences"])
        mismatch = next(d for d in result["differences"] if d["type"] == diff_type)
        assert mismatch["baseline"] == 1
        assert mismatch["actual"] == 2

    def test_count_mismatch_short_circuits_before_content_comparison(self):
        """When counts differ, no content comparison is attempted."""
        baseline = {"inserts": [{"X": 1}], "deletes": [], "updates": []}
        actual = {"inserts": [{"X": 1}, {"X": 2}], "deletes": [], "updates": []}

        result = compare_table_deltas(baseline, actual, "S.T")

        assert result["match"] is False
        assert len(result["differences"]) == 1
        assert result["differences"][0]["type"] == "insert_count_mismatch"


# ---------------------------------------------------------------------------
# Content comparison via SDV
# ---------------------------------------------------------------------------

class TestCompareTableDeltasContent:
    """Content-level comparison using SDV validate_cell."""

    def test_insert_content_mismatch_detected(self):
        """Same count, different values → insert_content_mismatch."""
        baseline = {"inserts": [{"COLOR": "Blue"}], "deletes": [], "updates": []}
        actual = {"inserts": [{"COLOR": "Red"}], "deletes": [], "updates": []}

        result = compare_table_deltas(baseline, actual, "S.T")

        assert result["match"] is False
        assert any(
            d["type"] == "insert_content_mismatch"
            for d in result["differences"]
        )

    def test_delete_content_mismatch_detected(self):
        """Same count, different delete values → delete_content_mismatch."""
        baseline = {"inserts": [], "deletes": [{"ID": 1}], "updates": []}
        actual = {"inserts": [], "deletes": [{"ID": 2}], "updates": []}

        result = compare_table_deltas(baseline, actual, "S.T")

        assert result["match"] is False
        assert any(
            d["type"] == "delete_content_mismatch"
            for d in result["differences"]
        )

    def test_update_after_rows_compared(self):
        """Updates are compared by their 'after' rows."""
        baseline = {
            "inserts": [], "deletes": [],
            "updates": [{"after": {"NAME": "Alice"}}],
        }
        actual = {
            "inserts": [], "deletes": [],
            "updates": [{"after": {"NAME": "Bob"}}],
        }

        result = compare_table_deltas(baseline, actual, "S.T")

        assert result["match"] is False
        assert any(
            d["type"] == "update_content_mismatch"
            for d in result["differences"]
        )

    def test_empty_both_sides_match(self):
        """No rows on either side → match."""
        baseline = {"inserts": [], "deletes": [], "updates": []}
        actual = {"inserts": [], "deletes": [], "updates": []}

        result = compare_table_deltas(baseline, actual, "S.T")

        assert result["match"] is True
        assert result["differences"] == []

    def test_matching_content_with_different_row_order(self):
        """SDV comparison is order-independent (both sides sorted first)."""
        baseline = {
            "inserts": [{"ID": 2, "NAME": "B"}, {"ID": 1, "NAME": "A"}],
            "deletes": [], "updates": [],
        }
        actual = {
            "inserts": [{"ID": 1, "NAME": "A"}, {"ID": 2, "NAME": "B"}],
            "deletes": [], "updates": [],
        }

        result = compare_table_deltas(baseline, actual, "S.T")

        assert result["match"] is True


# ---------------------------------------------------------------------------
# _sortable helper
# ---------------------------------------------------------------------------

class TestSortable:
    """_sortable casts Object dtype columns to Utf8 so Polars can sort.

    In modern Polars, bytes values produce Binary (sortable natively), so
    the Object branch is rarely hit.  These tests verify both the no-op
    path and the Binary passthrough.
    """

    def test_binary_columns_pass_through_unchanged(self):
        """bytes values become Binary in Polars, which is already sortable."""
        df = pl.DataFrame({"A": [b"hello", b"world"]})
        assert df["A"].dtype == pl.Binary

        result = _sortable(df)

        assert result["A"].dtype == pl.Binary
        assert result["A"].to_list() == [b"hello", b"world"]

    def test_non_object_columns_unchanged(self):
        df = pl.DataFrame({"X": [1, 2], "Y": ["a", "b"]})

        result = _sortable(df)

        assert result["X"].dtype == df["X"].dtype
        assert result["Y"].dtype == df["Y"].dtype

    def test_no_object_columns_returns_same_frame(self):
        df = pl.DataFrame({"X": [1, 2]})

        result = _sortable(df)

        assert result.equals(df)

    def test_empty_dataframe_returns_unchanged(self):
        df = pl.DataFrame({"X": pl.Series([], dtype=pl.Int64)})

        result = _sortable(df)

        assert result.shape == (0, 1)


# ---------------------------------------------------------------------------
# _align_datetime_columns helper
# ---------------------------------------------------------------------------

class TestAlignDatetimeColumns:
    """_align_datetime_columns casts Utf8 datetime strings to Datetime
    when the other DataFrame has a Datetime column."""

    def test_baseline_string_cast_to_datetime(self):
        from datetime import datetime
        baseline = pl.DataFrame({"TS": ["2026-01-10 08:00:00"]})
        actual = pl.DataFrame({"TS": [datetime(2026, 1, 10, 8, 0, 0)]})

        b, a = _align_datetime_columns(baseline, actual)

        assert isinstance(b["TS"].dtype, pl.Datetime)
        assert b["TS"][0] == a["TS"][0]

    def test_actual_string_cast_to_datetime(self):
        from datetime import datetime
        baseline = pl.DataFrame({"TS": [datetime(2026, 1, 10, 8, 0, 0)]})
        actual = pl.DataFrame({"TS": ["2026-01-10 08:00:00"]})

        b, a = _align_datetime_columns(baseline, actual)

        assert isinstance(a["TS"].dtype, pl.Datetime)
        assert b["TS"][0] == a["TS"][0]

    def test_matching_datetime_types_unchanged(self):
        from datetime import datetime
        baseline = pl.DataFrame({"TS": [datetime(2026, 1, 1)]})
        actual = pl.DataFrame({"TS": [datetime(2026, 1, 2)]})

        b, a = _align_datetime_columns(baseline, actual)

        assert isinstance(b["TS"].dtype, pl.Datetime)
        assert isinstance(a["TS"].dtype, pl.Datetime)

    def test_non_datetime_columns_unchanged(self):
        baseline = pl.DataFrame({"ID": [1], "NAME": ["Alice"]})
        actual = pl.DataFrame({"ID": [1], "NAME": ["Alice"]})

        b, a = _align_datetime_columns(baseline, actual)

        assert b["ID"].dtype == pl.Int64
        assert b["NAME"].dtype == pl.Utf8

    def test_unparseable_string_stays_as_string(self):
        from datetime import datetime
        baseline = pl.DataFrame({"TS": ["not-a-date"]})
        actual = pl.DataFrame({"TS": [datetime(2026, 1, 1)]})

        b, a = _align_datetime_columns(baseline, actual)

        assert b["TS"].dtype == pl.Utf8

    def test_only_shared_columns_processed(self):
        from datetime import datetime
        baseline = pl.DataFrame({"TS": ["2026-01-10 08:00:00"], "X": ["foo"]})
        actual = pl.DataFrame({"TS": [datetime(2026, 1, 10, 8, 0, 0)], "Y": [1]})

        b, a = _align_datetime_columns(baseline, actual)

        assert isinstance(b["TS"].dtype, pl.Datetime)
        assert b["X"].dtype == pl.Utf8
        assert a["Y"].dtype == pl.Int64

    def test_iso_format_string_parsed(self):
        from datetime import datetime
        baseline = pl.DataFrame({"TS": ["2026-04-09T12:30:00"]})
        actual = pl.DataFrame({"TS": [datetime(2026, 4, 9, 12, 30, 0)]})

        b, a = _align_datetime_columns(baseline, actual)

        assert isinstance(b["TS"].dtype, pl.Datetime)

    def test_tz_aware_iso_string_parsed(self):
        from datetime import datetime, timezone
        baseline = pl.DataFrame({"TS": ["2026-01-10T08:00:00+00:00"]})
        actual = pl.DataFrame({"TS": [datetime(2026, 1, 10, 8, 0, 0, tzinfo=timezone.utc)]})

        b, a = _align_datetime_columns(baseline, actual)

        assert isinstance(b["TS"].dtype, pl.Datetime)
