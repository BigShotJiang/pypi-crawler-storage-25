"""Tests for the SQL Server step-based SQL builder."""

from __future__ import annotations

import pytest

from test_runner.common.builders.sqlserver import build_sqlserver_sql
from test_runner.common.models.step_types import (
    CursorStep,
    ParamStep,
    QueryStep,
    TableStep,
    ValidateSkip,
    ValidateTable,
)


class TestSimpleProcedure:
    """Example 1a: simple procedure call."""

    def test_single_query_step(self):
        steps = [
            QueryStep(
                source_query="EXECUTE [Reports].[GetSalesByCategory] @StartDate = {0}, @EndDate = {1}",
                target_query="CALL Reports.GetSalesByCategory({0}, {1})",
            ),
        ]
        result = build_sqlserver_sql(steps, ["2025-02-05", "2026-02-05"])

        assert result.main_sql == (
            "SELECT '__STEP_0__' AS _boundary;\n"
            "EXECUTE [Reports].[GetSalesByCategory] @StartDate = '2025-02-05', @EndDate = '2026-02-05'\n"
        )
        assert result.validated_step_indices == [0]


class TestOutputParameters:
    """Example 2a: DECLARE + OUTPUT parameters."""

    def test_declare_then_exec_then_params(self):
        steps = [
            QueryStep(
                source_query="DECLARE @productName VARCHAR(100) = {1}; DECLARE @unitPrice DECIMAL(38,18) = {2}",
                target_query="LET PRODUCTNAME VARCHAR := {1}; LET UNITPRICE DECIMAL := {2}",
                validate=False,
            ),
            QueryStep(
                source_query="EXECUTE dbo.GetProductDetails @productId = {0}, @productName = @productName OUTPUT, @unitPrice = @unitPrice OUTPUT",
                target_query="CALL DBO.GETPRODUCTDETAILS({0}, :PRODUCTNAME, :UNITPRICE)",
            ),
            ParamStep(
                source_params=["@productName", "@unitPrice"],
                target_params=["PRODUCTNAME", "UNITPRICE"],
            ),
        ]
        result = build_sqlserver_sql(steps, [3, "", 0])

        assert result.main_sql == (
            "SELECT '__STEP_0__' AS _boundary;\n"
            "DECLARE @productName VARCHAR(100) = ''; DECLARE @unitPrice DECIMAL(38,18) = 0\n"
            "SELECT '__STEP_1__' AS _boundary;\n"
            "EXECUTE dbo.GetProductDetails @productId = 3, @productName = @productName OUTPUT, @unitPrice = @unitPrice OUTPUT\n"
            "SELECT '__STEP_2__' AS _boundary;\n"
            "SELECT @productName AS [productName], @unitPrice AS [unitPrice];\n"
        )
        assert result.validated_step_indices == [1, 2]


class TestOutputParamsAndTable:
    """Example 3a: output params + temp table."""

    def test_declare_exec_params_table(self):
        steps = [
            QueryStep(
                source_query="DECLARE @name VARCHAR(100) = {1}",
                target_query="LET NAME VARCHAR := {1}",
                validate=False,
            ),
            QueryStep(
                source_query="EXECUTE dbo.GetProduct @id = {0}, @name = @name OUTPUT",
                target_query="CALL DBO.GETPRODUCT({0}, :NAME)",
            ),
            ParamStep(
                source_params=["@name"],
                target_params=["NAME"],
            ),
            TableStep(source_table="#TempResults", target_table="#TempResults"),
        ]
        result = build_sqlserver_sql(steps, [3, ""])

        assert result.main_sql == (
            "SELECT '__STEP_0__' AS _boundary;\n"
            "DECLARE @name VARCHAR(100) = ''\n"
            "SELECT '__STEP_1__' AS _boundary;\n"
            "EXECUTE dbo.GetProduct @id = 3, @name = @name OUTPUT\n"
            "SELECT '__STEP_2__' AS _boundary;\n"
            "SELECT @name AS [name];\n"
            "SELECT '__STEP_3__' AS _boundary;\n"
            "SELECT * FROM #TempResults;\n"
        )
        assert result.validated_step_indices == [1, 2, 3]


class TestCustomValidationQueries:
    """Example 5a: custom queries + temp table."""

    def test_multiple_validated_steps(self):
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.ProcessOrders @region = {0}",
                target_query="CALL DBO.PROCESSORDERS({0})",
            ),
            TableStep(source_table="#OrderSummary", target_table="#OrderSummary"),
            QueryStep(
                source_query="SELECT COUNT(*) AS total FROM orders WHERE region = {0}",
                target_query="SELECT COUNT(*) AS total FROM orders WHERE region = {0}",
            ),
            QueryStep(
                source_query="SELECT TOP 5 product_name, quantity FROM #OrderSummary ORDER BY quantity DESC",
                target_query="SELECT product_name, quantity FROM IDENTIFIER('#OrderSummary') ORDER BY quantity DESC LIMIT 5",
            ),
        ]
        result = build_sqlserver_sql(steps, ["West"])

        assert result.main_sql == (
            "SELECT '__STEP_0__' AS _boundary;\n"
            "EXECUTE dbo.ProcessOrders @region = 'West'\n"
            "SELECT '__STEP_1__' AS _boundary;\n"
            "SELECT * FROM #OrderSummary;\n"
            "SELECT '__STEP_2__' AS _boundary;\n"
            "SELECT COUNT(*) AS total FROM orders WHERE region = 'West'\n"
            "SELECT '__STEP_3__' AS _boundary;\n"
            "SELECT TOP 5 product_name, quantity FROM #OrderSummary ORDER BY quantity DESC\n"
        )
        assert result.validated_step_indices == [0, 1, 2, 3]


class TestDmlProcedure:
    """Example 6a: DML with validate: false on CALL."""

    def test_validate_false_not_in_indices(self):
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.InsertColor @ColorName = {0}",
                target_query="CALL INSERTCOLOR({0})",
                validate=False,
            ),
            QueryStep(
                source_query="SELECT * FROM Colors WHERE ColorName = {0}",
                target_query="SELECT * FROM Colors WHERE ColorName = {0}",
            ),
        ]
        result = build_sqlserver_sql(steps, ["Crimson"])

        assert result.main_sql == (
            "SELECT '__STEP_0__' AS _boundary;\n"
            "EXECUTE dbo.InsertColor @ColorName = 'Crimson'\n"
            "SELECT '__STEP_1__' AS _boundary;\n"
            "SELECT * FROM Colors WHERE ColorName = 'Crimson'\n"
        )
        assert result.validated_step_indices == [1]


class TestMultiResultSet:
    """Example 7: validate: [list]."""

    def test_validate_list_in_indices(self):
        steps = [
            QueryStep(
                source_query="EXECUTE dbo.Dashboard @region = {0}",
                target_query="CALL DASHBOARD({0})",
                validate=[
                    ValidateTable(table="#Orders"),
                    ValidateSkip(),
                    ValidateTable(table="#Summary"),
                ],
            ),
        ]
        result = build_sqlserver_sql(steps, ["West"])

        assert result.main_sql == (
            "SELECT '__STEP_0__' AS _boundary;\n"
            "EXECUTE dbo.Dashboard @region = 'West'\n"
        )
        assert result.validated_step_indices == [0]


class TestOneSidedSteps:
    def test_target_only_step_skipped(self):
        steps = [
            QueryStep(target_query="LET X VARCHAR := {0}", validate=False),
            QueryStep(
                source_query="EXEC P @id = {0}",
                target_query="CALL P({0})",
            ),
        ]
        result = build_sqlserver_sql(steps, [1])

        assert result.main_sql == (
            "SELECT '__STEP_1__' AS _boundary;\n"
            "EXEC P @id = 1\n"
        )
        assert result.validated_step_indices == [1]

    def test_param_step_source_only(self):
        steps = [
            ParamStep(target_params=["X"]),
        ]
        result = build_sqlserver_sql(steps, [])
        assert result.main_sql == ""
        assert result.validated_step_indices == []


class TestCursorStepRaises:
    def test_cursor_step_raises(self):
        steps = [CursorStep(source_cursor="mycursor", target_cursor="mycursor")]
        with pytest.raises(ValueError, match="CursorStep is not supported for SQL Server"):
            build_sqlserver_sql(steps, [])


class TestValidateFalseOnShorthands:
    @pytest.mark.parametrize(
        "step",
        [
            ParamStep(source_params=["@x"], validate=False),
            TableStep(source_table="#Temp", validate=False),
        ],
        ids=["ParamStep", "TableStep"],
    )
    def test_validate_false_raises(self, step):
        with pytest.raises(ValueError, match="does not support validate: false"):
            build_sqlserver_sql([step], [])
