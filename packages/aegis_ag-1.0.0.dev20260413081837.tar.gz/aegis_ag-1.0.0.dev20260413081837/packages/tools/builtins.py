"""Curated built-in tool catalog and registration for Aegis."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace
from pathlib import Path
from typing import Any

from .handlers_continuity import (
    normalize_companion_request,
    run_companion_action,
    run_cron_action,
    run_goal_action,
    run_mcp_action,
    run_memory_action,
    run_skill_action,
    run_todo_action,
)
from .handlers_network import (
    run_browser_action,
    run_clarify,
    run_message_send,
    run_web_read,
    run_web_search,
)
from .handlers_workspace import (
    run_code_execute,
    run_file_patch,
    run_file_read,
    run_file_search,
    run_file_write,
    run_process_action,
    run_terminal_exec,
)
from .runtime import ToolAvailability, ToolDefinition, ToolRuntime, ToolSideEffectMetadata
from .surfaces import BuiltinToolDependencies

_BUILTIN_VERSION = "2.0.0"
_BUILTIN_TOOL_ORDER = (
    "terminal",
    "process",
    "file",
    "web",
    "browser",
    "clarify",
    "cron",
    "code_execution",
    "memory",
    "messaging",
    "todo",
    "continuity-native",
)


def register_builtin_tools(
    runtime: ToolRuntime,
    *,
    enabled_overrides: Mapping[str, bool],
    dependencies: BuiltinToolDependencies,
) -> None:
    for definition in builtin_tool_definitions(enabled_overrides, dependencies=dependencies):
        runtime.register_tool(
            definition,
            handler=_handler_for_tool(definition, runtime=runtime, dependencies=dependencies),
        )


def builtin_tool_definitions(
    enabled_overrides: Mapping[str, bool],
    *,
    dependencies: BuiltinToolDependencies | None = None,
) -> tuple[ToolDefinition, ...]:
    browser_reason = None
    if dependencies is None or dependencies.browser_backend is None:
        browser_reason = "Browser tools require a configured Playwright-compatible browser backend."
    message_reason = None
    if dependencies is None or dependencies.message_delivery is None:
        message_reason = "Messaging tools require a configured outbound delivery target."
    cron_reason = None
    if dependencies is None or dependencies.cron_runtime is None:
        cron_reason = "Cron management is not configured on this Aegis surface."
    companion_reason = None
    if dependencies is None or dependencies.companion_management is None:
        companion_reason = "Companion management is not configured on this Aegis surface."
    skill_reason = None
    if dependencies is None or dependencies.skill_management is None:
        skill_reason = "Skill management is not configured on this Aegis surface."
    mcp_reason = None
    if dependencies is None or dependencies.mcp_management is None:
        mcp_reason = "MCP management is not configured on this Aegis surface."
    goal_reason = None
    if dependencies is None or dependencies.goal_management is None:
        goal_reason = "Goal management is not configured on this Aegis surface."
    memory_reason = None
    if dependencies is None or dependencies.memory_management is None:
        memory_reason = "Memory management is not configured on this Aegis surface."

    definitions = (
        _builtin_tool(
            tool_id="tool.terminal.exec",
            display_name="Terminal Exec",
            family="terminal",
            backend="subprocess",
            description="Run one bounded terminal command in the current workspace.",
            schema=_object_schema(
                required=("command",),
                properties={
                    "command": {"type": "string"},
                    "cwd": {"type": "string"},
                    "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120},
                    "background": {"type": "boolean"},
                    "env": {"type": "object"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("terminal", "workspace"),
                notes="Runs a workspace command or starts a background process.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.process.manage",
            display_name="Process Manager",
            family="process",
            backend="subprocess",
            description="List, poll, wait on, write to, or kill background processes started through Aegis.",
            schema=_object_schema(
                required=("action",),
                properties={
                    "action": {"type": "string"},
                    "process_id": {"type": "string"},
                    "input": {"type": "string"},
                    "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 120},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("process", "terminal"),
                notes="Operates on background processes created by tool.terminal.exec.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.file.read",
            display_name="File Read",
            family="file",
            backend="filesystem",
            description="Read a workspace file, optionally sliced by line range.",
            schema=_object_schema(
                required=("path",),
                properties={
                    "path": {"type": "string"},
                    "start_line": {"type": "integer", "minimum": 1},
                    "end_line": {"type": "integer", "minimum": 1},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="low",
                approval_class="standard",
                reads_state=True,
                categories=("file", "read"),
                notes="Reads text from a workspace file.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.file.write",
            display_name="File Write",
            family="file",
            backend="filesystem",
            description="Write or append text to a workspace file.",
            schema=_object_schema(
                required=("path", "content"),
                properties={
                    "path": {"type": "string"},
                    "content": {"type": "string"},
                    "mode": {"type": "string", "enum": ["overwrite", "append"]},
                    "create_parents": {"type": "boolean"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("file", "write"),
                notes="Writes text to a workspace file.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.file.patch",
            display_name="File Patch",
            family="file",
            backend="filesystem",
            description="Patch a workspace file by replacing matching text.",
            schema=_object_schema(
                required=("path", "search", "replace"),
                properties={
                    "path": {"type": "string"},
                    "search": {"type": "string"},
                    "replace": {"type": "string"},
                    "replace_all": {"type": "boolean"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("file", "patch"),
                notes="Applies bounded text replacements to a workspace file.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.file.search",
            display_name="File Search",
            family="file",
            backend="rg",
            description="Search workspace files for matching text with ripgrep.",
            schema=_object_schema(
                required=("query",),
                properties={
                    "query": {"type": "string"},
                    "path": {"type": "string"},
                    "glob": {"type": "string"},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 200},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="low",
                approval_class="standard",
                reads_state=True,
                categories=("file", "search"),
                notes="Fast workspace search for code and notes.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.web.search",
            display_name="Web Search",
            family="web",
            backend="duckduckgo",
            description="Search the public web and summarize the most relevant results.",
            schema=_object_schema(
                required=("query",),
                properties={
                    "query": {"type": "string"},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 8},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                touches_network=True,
                categories=("web", "search"),
                notes="Uses lightweight public web search with direct-result fallback.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.web.read",
            display_name="Web Read",
            family="web",
            backend="urllib",
            description="Read a specific public URL and extract a text-first summary.",
            schema=_object_schema(
                required=("url",),
                properties={"url": {"type": "string"}},
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                touches_network=True,
                categories=("web", "read"),
                notes="Fetches a public page and returns readable text.",
            ),
        ),
        *_browser_tool_definitions(reason=browser_reason),
        _builtin_tool(
            tool_id="tool.clarify",
            display_name="Clarify",
            family="clarify",
            backend="surface-clarify",
            description="Ask the user for clarification with an open question or a bounded choice list.",
            schema=_object_schema(
                required=("question",),
                properties={
                    "question": {"type": "string"},
                    "mode": {"type": "string", "enum": ["open", "choice"]},
                    "choices": {"type": ["array", "string"]},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="low",
                approval_class="none",
                reads_state=True,
                categories=("clarify", "interaction"),
                notes="Returns a structured clarification request when the next step is ambiguous.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.cron.manage",
            display_name="Cron Manager",
            family="cron",
            backend="cron-runtime",
            description="Create, inspect, pause, resume, remove, and list built-in scheduled jobs.",
            schema=_object_schema(
                required=("action",),
                properties={
                    "action": {"type": "string"},
                    "job_id": {"type": "string"},
                    "name": {"type": "string"},
                    "schedule": {"type": "string"},
                    "job_kind": {"type": "string"},
                    "message": {"type": "string"},
                    "query": {"type": "string"},
                    "prompt": {"type": "string"},
                    "profile_id": {"type": "string"},
                    "clone_id": {"type": "string"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("cron", "automation"),
                notes="Govern recurring jobs for the active Aegis surface.",
            ),
            availability=_availability(cron_reason is None, cron_reason),
        ),
        _builtin_tool(
            tool_id="tool.code.execute",
            display_name="Code Execute",
            family="code_execution",
            backend="python-sandbox",
            description="Run a restricted Python snippet and optionally call a small allowlist of Aegis tools.",
            schema=_object_schema(
                required=("code",),
                properties={
                    "code": {"type": "string"},
                    "timeout_seconds": {"type": "integer", "minimum": 1, "maximum": 30},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                reads_state=True,
                writes_state=False,
                categories=("code", "python"),
                notes="Restricted Python without imports or ambient network access.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.memory.manage",
            display_name="Memory Manager",
            family="memory",
            backend="memory-runtime",
            description="List, inspect, search, correct, delete, pin, unpin, or inspect lineage for durable memories.",
            schema=_object_schema(
                required=("action",),
                properties={
                    "action": {"type": "string"},
                    "memory_id": {"type": "string"},
                    "query": {"type": "string"},
                    "content": {"type": "string"},
                    "reason": {"type": "string"},
                    "limit": {"type": "integer"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                categories=("memory", "governance"),
                notes="Govern durable memory with explicit lineage and protection semantics.",
            ),
            availability=_availability(memory_reason is None, memory_reason),
        ),
        _builtin_tool(
            tool_id="tool.message.send",
            display_name="Message Send",
            family="messaging",
            backend="delivery",
            description="Send an outbound message to a configured delivery target.",
            schema=_object_schema(
                required=("body",),
                properties={
                    "body": {"type": "string"},
                    "target": {"type": "string"},
                    "metadata": {"type": "object"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="high",
                approval_class="strict",
                writes_state=True,
                reads_state=True,
                touches_network=True,
                categories=("message", "delivery"),
                notes="Only available when the current surface has an outbound delivery target.",
            ),
            availability=_availability(message_reason is None, message_reason),
        ),
        _builtin_tool(
            tool_id="tool.todo.manage",
            display_name="Todo Manager",
            family="todo",
            backend="session-todo",
            description="Manage a session-scoped todo scratchpad and optionally promote items into durable goals.",
            schema=_object_schema(
                required=("action",),
                properties={
                    "action": {"type": "string"},
                    "item_id": {"type": "string"},
                    "title": {"type": "string"},
                    "status": {"type": "string"},
                    "notes": {"type": "string"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("todo", "scratchpad"),
                notes="Tracks short-horizon execution decomposition separately from durable goals.",
            ),
        ),
        _builtin_tool(
            tool_id="tool.companion.manage",
            display_name="Companion Manager",
            family="continuity-native",
            backend="companion-runtime",
            description=(
                "Inspect or persist the active clone's CLONE.md and FRIEND.md state. "
                "Canonical call shape: action=inspect|set|append|clear with target=clone|friend."
            ),
            schema=_object_schema(
                required=("action",),
                properties={
                    "action": {"type": "string", "enum": ["inspect", "set", "append", "clear"]},
                    "target": {"type": "string", "enum": ["clone", "friend"]},
                    "text": {"type": "string"},
                    "fields": {"type": "object"},
                    "profile_id": {"type": "string"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("companion", "identity"),
                notes="Keeps clone charter and friend profile durable across turns.",
            ),
            availability=_availability(companion_reason is None, companion_reason),
        ),
        _builtin_tool(
            tool_id="tool.goal.manage",
            display_name="Goal Manager",
            family="continuity-native",
            backend="planning-runtime",
            description="Inspect, create, focus, update, or delete durable goals and sub-goals in the current goal graph.",
            schema=_object_schema(
                properties={
                    "action": {"type": "string"},
                    "goal_id": {"type": "string"},
                    "title": {"type": "string"},
                    "status": {"type": "string"},
                    "priority": {"type": "string"},
                    "owner": {"type": "string"},
                    "parent_goal_id": {"type": "string"},
                    "dependency_refs": {"type": ["string", "array"]},
                    "evidence_refs": {"type": ["string", "array"]},
                    "related_memory_ids": {"type": ["string", "array"]},
                    "review_checkpoint": {"type": "string"},
                    "deadline": {"type": "string"},
                    "time_sensitivity": {"type": "string"},
                    "reason": {"type": "string"},
                    "activate": {"type": ["boolean", "string"]},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("goal", "state"),
                notes="Maintains the durable goal graph instead of leaving goals implicit in chat.",
            ),
            availability=_availability(goal_reason is None, goal_reason),
        ),
        _builtin_tool(
            tool_id="tool.skill.manage",
            display_name="Skill Manager",
            family="continuity-native",
            backend="skill-runtime",
            description="Search, inspect, install, toggle, and author skills for the active Aegis surface.",
            schema=_object_schema(
                required=("action",),
                properties={
                    "action": {"type": "string"},
                    "query": {"type": "string"},
                    "reference": {"type": "string"},
                    "skill_id": {"type": "string"},
                    "limit": {"type": "integer"},
                    "display_name": {"type": "string"},
                    "summary": {"type": "string"},
                    "instruction_text": {"type": "string"},
                    "category": {"type": "string"},
                    "install": {"type": "boolean"},
                    "overwrite": {"type": "boolean"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("skill", "experience"),
                notes="Govern procedural guidance for the active clone.",
            ),
            availability=_availability(skill_reason is None, skill_reason),
        ),
        _builtin_tool(
            tool_id="tool.mcp.manage",
            display_name="MCP Manager",
            family="continuity-native",
            backend="mcp-runtime",
            description="Search the MCP registry, inspect servers, install servers for this clone, and toggle configured servers.",
            schema=_object_schema(
                required=("action",),
                properties={
                    "action": {"type": "string"},
                    "query": {"type": "string"},
                    "reference": {"type": "string"},
                    "server_id": {"type": "string"},
                    "limit": {"type": "integer"},
                },
            ),
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                writes_state=True,
                reads_state=True,
                categories=("mcp", "capability"),
                notes="Govern external capability bridges without leaving the Aegis session.",
            ),
            availability=_availability(mcp_reason is None, mcp_reason),
        ),
    )
    return tuple(
        replace(definition, enabled=enabled_overrides.get(definition.tool_id, definition.enabled))
        for definition in definitions
    )


def render_builtin_tool_reference_markdown() -> str:
    grouped = _group_builtin_tools(_docs_builtin_tool_definitions())
    lines: list[str] = []
    for family in _BUILTIN_TOOL_ORDER:
        tools = grouped.get(family, ())
        if not tools:
            continue
        lines.append(f"### {family}")
        for tool in tools:
            note = ""
            if not tool.available and tool.availability.reason:
                note = f" ({tool.availability.reason})"
            lines.append(f"- `{tool.tool_id}`{note}")
        lines.append("")
    return "\n".join(lines).rstrip()


def render_builtin_tool_summary_markdown() -> str:
    grouped = _group_builtin_tools(_docs_builtin_tool_definitions())
    lines: list[str] = []
    for family in _BUILTIN_TOOL_ORDER:
        tools = grouped.get(family, ())
        if not tools:
            continue
        tool_ids = ", ".join(f"`{tool.tool_id}`" for tool in tools)
        lines.append(f"- `{family}`: {tool_ids}")
    return "\n".join(lines)


def _browser_tool_definitions(*, reason: str | None) -> tuple[ToolDefinition, ...]:
    browser_availability = _availability(reason is None, reason)
    return tuple(
        _builtin_tool(
            tool_id=tool_id,
            display_name=display_name,
            family="browser",
            backend="playwright-bridge",
            description=description,
            schema=schema,
            side_effects=ToolSideEffectMetadata(
                risk_class="medium",
                approval_class="standard",
                reads_state=True,
                writes_state=tool_id not in {"tool.browser.snapshot", "tool.browser.images", "tool.browser.vision", "tool.browser.console"},
                touches_network=True,
                categories=("browser", action),
                notes="Backed by a Playwright-compatible browser bridge when configured.",
            ),
            availability=browser_availability,
        )
        for tool_id, display_name, action, description, schema in (
            (
                "tool.browser.navigate",
                "Browser Navigate",
                "navigate",
                "Navigate the active browser session to a URL.",
                _object_schema(required=("url",), properties={"url": {"type": "string"}}),
            ),
            (
                "tool.browser.snapshot",
                "Browser Snapshot",
                "snapshot",
                "Capture a text snapshot of the active browser page.",
                _object_schema(properties={}),
            ),
            (
                "tool.browser.click",
                "Browser Click",
                "click",
                "Click an element in the active browser page.",
                _object_schema(required=("selector",), properties={"selector": {"type": "string"}}),
            ),
            (
                "tool.browser.type",
                "Browser Type",
                "type",
                "Type text into a browser element.",
                _object_schema(
                    required=("selector", "text"),
                    properties={"selector": {"type": "string"}, "text": {"type": "string"}},
                ),
            ),
            (
                "tool.browser.scroll",
                "Browser Scroll",
                "scroll",
                "Scroll the active page.",
                _object_schema(properties={"amount": {"type": "integer"}}),
            ),
            (
                "tool.browser.back",
                "Browser Back",
                "back",
                "Navigate backward in the active browser history.",
                _object_schema(properties={}),
            ),
            (
                "tool.browser.press",
                "Browser Press",
                "press",
                "Press a keyboard key in the active browser page.",
                _object_schema(required=("key",), properties={"key": {"type": "string"}}),
            ),
            (
                "tool.browser.images",
                "Browser Images",
                "images",
                "List image resources or capture image metadata from the current page.",
                _object_schema(properties={}),
            ),
            (
                "tool.browser.vision",
                "Browser Vision",
                "vision",
                "Run a vision-style inspection over the current browser page.",
                _object_schema(properties={"prompt": {"type": "string"}}),
            ),
            (
                "tool.browser.console",
                "Browser Console",
                "console",
                "Inspect recent console output from the active browser page.",
                _object_schema(properties={}),
            ),
        )
    )


def _docs_builtin_tool_definitions() -> tuple[ToolDefinition, ...]:
    return builtin_tool_definitions(
        {},
        dependencies=BuiltinToolDependencies(
            cwd=Path("/tmp"),
            cron_runtime=object(),  # type: ignore[arg-type]
            companion_management=object(),  # type: ignore[arg-type]
            skill_management=object(),  # type: ignore[arg-type]
            mcp_management=object(),  # type: ignore[arg-type]
            goal_management=object(),  # type: ignore[arg-type]
            memory_management=object(),  # type: ignore[arg-type]
        ),
    )


def _builtin_tool(
    *,
    tool_id: str,
    display_name: str,
    family: str,
    backend: str,
    description: str,
    schema: Mapping[str, Any],
    side_effects: ToolSideEffectMetadata,
    availability: ToolAvailability | None = None,
) -> ToolDefinition:
    return ToolDefinition(
        tool_id=tool_id,
        display_name=display_name,
        version=_BUILTIN_VERSION,
        description=description,
        schema=schema,
        side_effects=side_effects,
        family=family,
        audience="both",
        availability=availability or ToolAvailability(),
        backend=backend,
        metadata={"kind": "built-in"},
    )


def _availability(is_available: bool, reason: str | None) -> ToolAvailability:
    return ToolAvailability(is_available=is_available, reason=None if is_available else reason)


def _object_schema(
    *,
    properties: Mapping[str, Any],
    required: tuple[str, ...] = (),
) -> Mapping[str, Any]:
    schema: dict[str, Any] = {
        "type": "object",
        "properties": dict(properties),
    }
    if required:
        schema["required"] = list(required)
    return schema


def _group_builtin_tools(definitions: tuple[ToolDefinition, ...]) -> dict[str, tuple[ToolDefinition, ...]]:
    grouped: dict[str, list[ToolDefinition]] = {}
    for definition in definitions:
        grouped.setdefault(definition.family, []).append(definition)
    return {family: tuple(items) for family, items in grouped.items()}


def _handler_for_tool(
    definition: ToolDefinition,
    *,
    runtime: ToolRuntime,
    dependencies: BuiltinToolDependencies,
):
    tool_id = definition.tool_id
    if tool_id == "tool.terminal.exec":
        return lambda invocation: run_terminal_exec(invocation, dependencies=dependencies)
    if tool_id == "tool.process.manage":
        return lambda invocation: run_process_action(invocation, manager=dependencies.process_manager)
    if tool_id == "tool.file.read":
        return lambda invocation: run_file_read(invocation, cwd=dependencies.cwd)
    if tool_id == "tool.file.write":
        return lambda invocation: run_file_write(invocation, cwd=dependencies.cwd)
    if tool_id == "tool.file.patch":
        return lambda invocation: run_file_patch(invocation, cwd=dependencies.cwd)
    if tool_id == "tool.file.search":
        return lambda invocation: run_file_search(invocation, cwd=dependencies.cwd)
    if tool_id == "tool.web.search":
        return lambda invocation: run_web_search(invocation, user_agent=dependencies.web_user_agent)
    if tool_id == "tool.web.read":
        return lambda invocation: run_web_read(invocation, user_agent=dependencies.web_user_agent)
    if tool_id.startswith("tool.browser."):
        return lambda invocation: run_browser_action(invocation, backend=dependencies.browser_backend)
    if tool_id == "tool.clarify":
        return lambda invocation: run_clarify(invocation, surface=dependencies.clarify_surface)
    if tool_id == "tool.cron.manage":
        return lambda invocation: run_cron_action(invocation, runtime=dependencies.cron_runtime)
    if tool_id == "tool.code.execute":
        return lambda invocation: run_code_execute(
            invocation,
            runtime=runtime,
            allowlist=dependencies.code_tool_allowlist,
        )
    if tool_id == "tool.memory.manage":
        return lambda invocation: run_memory_action(invocation, surface=dependencies.memory_management)
    if tool_id == "tool.message.send":
        return lambda invocation: run_message_send(invocation, surface=dependencies.message_delivery)
    if tool_id == "tool.todo.manage":
        return lambda invocation: run_todo_action(
            invocation,
            store=dependencies.todo_store,
            goal_surface=dependencies.goal_management,
        )
    if tool_id == "tool.companion.manage":
        return lambda invocation: run_companion_action(invocation, surface=dependencies.companion_management)
    if tool_id == "tool.goal.manage":
        return lambda invocation: run_goal_action(invocation, surface=dependencies.goal_management)
    if tool_id == "tool.skill.manage":
        return lambda invocation: run_skill_action(invocation, surface=dependencies.skill_management)
    if tool_id == "tool.mcp.manage":
        return lambda invocation: run_mcp_action(invocation, surface=dependencies.mcp_management)
    return None


__all__ = [
    "BuiltinToolDependencies",
    "builtin_tool_definitions",
    "normalize_companion_request",
    "register_builtin_tools",
    "render_builtin_tool_reference_markdown",
    "render_builtin_tool_summary_markdown",
]
