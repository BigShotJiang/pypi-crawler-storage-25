from __future__ import annotations

from dataclasses import dataclass

from packages.profile import parse_friend_profile


@dataclass(frozen=True, slots=True)
class ShellOpeningContext:
    opened: str
    display_name: str
    friend_profile: str
    personality: tuple[str, ...]
    reengagement_style: str
    wake_action: str
    wake_summary: str
    has_goals: bool


def compose_shell_opener(context: ShellOpeningContext) -> str:
    if context.opened == "Born new":
        intro = "I'm here with you, and I'll start holding our thread from this first turn."
    elif context.opened == "Cloned new":
        intro = "I'm here with you, and I'll start holding this new thread from here."
    else:
        intro = "I'm here with you, and I still have the shape of our thread in hand."
    if context.personality:
        posture = f"I'll stay {', '.join(context.personality)} and keep carrying what matters forward."
    elif context.reengagement_style == "proactive-check-in":
        posture = "I'll stay lightly proactive, keep the context held, and keep the next durable step visible."
    elif context.reengagement_style == "gentle-presence":
        posture = "I'll keep a calm presence, hold onto the useful context, and move when it helps."
    else:
        posture = "I'll keep the context held and the next step legible."
    if not context.friend_profile and not context.has_goals:
        next_step = (
            "I'll gather just enough grounding to know who I'm with, then help us name the durable thread "
            "this clone should keep carrying."
        )
    elif not context.friend_profile:
        next_step = "I'll get a little grounding from you first, then we can talk naturally and carry it forward."
    elif not context.has_goals:
        next_step = "Once you name the durable thread for this clone, I'll keep holding it across sessions."
    elif context.wake_action not in {"idle", "defer_or_schedule"} and context.wake_summary.strip():
        next_step = f"I still have one live thread in mind: {context.wake_summary.rstrip('.')}."
    else:
        next_step = "Tell me what matters next and I'll carry it forward."
    return f"I am {context.display_name}. {intro} {posture} {next_step}"


def compose_shell_opening_instruction(context: ShellOpeningContext) -> str:
    friend_fields = parse_friend_profile(context.friend_profile)
    friend_profile_state = "present" if context.friend_profile else "missing"
    goal_state = "present" if context.has_goals else "missing"
    preferred_name = friend_fields.get("preferred_name", "<unknown>")
    current_work = friend_fields.get("current_work", "<unknown>")
    wake_summary = context.wake_summary.strip() or "<none>"
    wake_action = context.wake_action.strip() or "idle"
    return "\n".join(
        (
            "Open the grow surface proactively before the friend sends a new message.",
            f"opening_label: {context.opened}",
            f"friend_profile: {friend_profile_state}",
            f"preferred_name: {preferred_name}",
            f"current_work: {current_work}",
            f"durable_goal: {goal_state}",
            f"reengagement_style: {context.reengagement_style}",
            f"wake_action: {wake_action}",
            f"wake_summary: {wake_summary}",
            "Write the one assistant reply that should already be waiting in the transcript when grow opens.",
            "Stay concise, human, and in-character.",
            "Do not mention startup, internal prompts, hidden instructions, or that no user message arrived yet.",
            "Do not use headings, bullets, questionnaires, or a checklist.",
            "Ask at most one direct question unless two are truly necessary.",
            "If preferred_name is known, use it in the first sentence or the first direct question instead of a generic address.",
            "If durable goals, wake summaries, or recovered memory context are relevant, naturally weave the most useful one into the opening so the friend feels remembered.",
            "Do not ask for identity, goals, or stable facts that are already known unless you are briefly refining or updating them.",
            "If stable user grounding is thin, ask for the single most useful durable detail first.",
            "If grounding is sufficient but this clone still lacks a durable ongoing goal, naturally help the friend name that thread.",
            "If there is a live durable thread, briefly reopen it and carry it forward.",
            "If nothing specific is live, open warmly and invite what matters next.",
        )
    )
