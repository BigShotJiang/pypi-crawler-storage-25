"""
Unit tests for the multiplexer abstraction.

SPEC-COACH-ORCH-0003: auto-detect cmux (preferred), zellij, or tmux (fallback).

Run: PYTHONPATH=src python3 -m pytest -q src/atdd/coach/commands/tests/test_multiplexer.py -v
"""
from __future__ import annotations

import subprocess
from unittest.mock import patch, MagicMock

import pytest

from atdd.coach.utils.multiplexer import (
    CmuxBackend,
    MultiplexerError,
    TmuxBackend,
    ZellijBackend,
    detect_multiplexer,
    get_multiplexer,
)

pytestmark = [pytest.mark.platform]


# ---------------------------------------------------------------------------
# detect_multiplexer / get_multiplexer
# ---------------------------------------------------------------------------


def _fake_run_success(*args, **kwargs):
    return subprocess.CompletedProcess(args=args[0], returncode=0, stdout="v1", stderr="")


def test_detect_prefers_cmux_when_available():
    with patch("atdd.coach.utils.multiplexer.shutil.which", side_effect=lambda b: f"/bin/{b}"), \
         patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=_fake_run_success):
        assert detect_multiplexer() == "cmux"


def test_detect_prefers_zellij_over_tmux_when_cmux_missing():
    def which(binary):
        return None if binary == "cmux" else f"/bin/{binary}"

    with patch("atdd.coach.utils.multiplexer.shutil.which", side_effect=which), \
         patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=_fake_run_success):
        assert detect_multiplexer() == "zellij"


def test_detect_falls_back_to_tmux_when_cmux_and_zellij_missing():
    def which(binary):
        return "/bin/tmux" if binary == "tmux" else None

    with patch("atdd.coach.utils.multiplexer.shutil.which", side_effect=which), \
         patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=_fake_run_success):
        assert detect_multiplexer() == "tmux"


def test_detect_returns_none_when_neither_available():
    with patch("atdd.coach.utils.multiplexer.shutil.which", return_value=None):
        assert detect_multiplexer() is None


def test_get_multiplexer_with_cmux_preferred():
    backend = get_multiplexer(preferred="cmux")
    assert isinstance(backend, CmuxBackend)
    assert backend.name == "cmux"


def test_get_multiplexer_with_tmux_preferred():
    backend = get_multiplexer(preferred="tmux")
    assert isinstance(backend, TmuxBackend)
    assert backend.name == "tmux"


def test_get_multiplexer_with_zellij_preferred():
    backend = get_multiplexer(preferred="zellij")
    assert isinstance(backend, ZellijBackend)
    assert backend.name == "zellij"


def test_get_multiplexer_raises_when_none_detected():
    with patch("atdd.coach.utils.multiplexer.detect_multiplexer", return_value=None):
        with pytest.raises(MultiplexerError, match="No multiplexer available"):
            get_multiplexer()


# ---------------------------------------------------------------------------
# CmuxBackend operations (mocked subprocess)
# ---------------------------------------------------------------------------


def _make_result(stdout: str = "", returncode: int = 0):
    return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr="")


def test_cmux_new_workspace_invokes_correct_command():
    backend = CmuxBackend()
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return _make_result(stdout="workspace:5\n")

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        ref = backend.new_workspace("/tmp/wt", "claude", name="issue-257")

    assert ref == "workspace:5"
    assert captured["cmd"][:2] == ["cmux", "new-workspace"]
    assert "--cwd" in captured["cmd"]
    assert "/tmp/wt" in captured["cmd"]
    assert "--command" in captured["cmd"]
    assert "claude" in captured["cmd"]
    assert "issue-257" in captured["cmd"]


def test_cmux_read_screen_returns_stdout():
    backend = CmuxBackend()
    with patch(
        "atdd.coach.utils.multiplexer.subprocess.run",
        return_value=_make_result(stdout="line1\nline2\n"),
    ):
        out = backend.read_screen("workspace:1", lines=10)
    assert out == "line1\nline2\n"


def test_cmux_list_workspaces_parses_lines():
    backend = CmuxBackend()
    with patch(
        "atdd.coach.utils.multiplexer.subprocess.run",
        return_value=_make_result(stdout="workspace:1\nworkspace:2\n\n"),
    ):
        assert backend.list_workspaces() == ["workspace:1", "workspace:2"]


def test_cmux_send_and_close_invoke_cmux_cli():
    backend = CmuxBackend()
    calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.send("workspace:1", "hello")
        backend.send_key("workspace:1", "Enter")
        backend.close("workspace:1")

    assert calls[0][:3] == ["cmux", "send", "--workspace"]
    assert calls[1][:3] == ["cmux", "send-key", "--workspace"]
    assert calls[2][:3] == ["cmux", "close-workspace", "--workspace"]


def test_cmux_missing_binary_raises_multiplexer_error():
    backend = CmuxBackend()
    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=FileNotFoundError):
        with pytest.raises(MultiplexerError, match="binary not found"):
            backend.read_screen("workspace:1")


# ---------------------------------------------------------------------------
# TmuxBackend operations
# ---------------------------------------------------------------------------


def test_tmux_new_workspace_uses_new_session():
    backend = TmuxBackend()
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        ref = backend.new_workspace("/tmp/wt", "claude", name="sess1")

    assert ref == "sess1"
    assert captured["cmd"][:3] == ["tmux", "new-session", "-d"]
    assert "sess1" in captured["cmd"]
    assert "/tmp/wt" in captured["cmd"]


def test_tmux_read_screen_uses_capture_pane():
    backend = TmuxBackend()
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return _make_result(stdout="screen contents")

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        out = backend.read_screen("sess1", lines=25)

    assert out == "screen contents"
    assert captured["cmd"][:2] == ["tmux", "capture-pane"]
    assert "-p" in captured["cmd"]
    assert "-25" in captured["cmd"]


def test_tmux_list_workspaces_parses_sessions():
    backend = TmuxBackend()
    with patch(
        "atdd.coach.utils.multiplexer.subprocess.run",
        return_value=_make_result(stdout="sess1\nsess2\n"),
    ):
        assert backend.list_workspaces() == ["sess1", "sess2"]


def test_tmux_close_uses_kill_session():
    backend = TmuxBackend()
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.close("sess1")

    assert captured["cmd"][:2] == ["tmux", "kill-session"]
    assert "sess1" in captured["cmd"]


# ---------------------------------------------------------------------------
# ZellijBackend operations
# ---------------------------------------------------------------------------


def test_zellij_new_workspace_uses_attach_create_background():
    backend = ZellijBackend()
    calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        ref = backend.new_workspace("/tmp/wt", "claude", name="sess1")

    assert ref == "sess1"
    # First call creates the detached session with cwd
    assert calls[0][:4] == ["zellij", "attach", "--create-background", "sess1"]
    assert "options" in calls[0]
    assert "--default-cwd" in calls[0]
    assert "/tmp/wt" in calls[0]
    # Subsequent calls send the command + Enter via action subcommands
    assert calls[1][:3] == ["zellij", "action", "write-chars"]
    assert "claude" in calls[1]
    assert calls[2][:3] == ["zellij", "action", "send-keys"]
    assert "Enter" in calls[2]


def test_zellij_new_workspace_skips_send_when_command_empty():
    backend = ZellijBackend()
    calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.new_workspace("/tmp/wt", "", name="sess1")

    assert len(calls) == 1
    assert calls[0][:4] == ["zellij", "attach", "--create-background", "sess1"]


def test_zellij_read_screen_uses_dump_screen_full_with_session_env():
    backend = ZellijBackend()
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        captured["env"] = kwargs.get("env", {})
        return _make_result(stdout="line1\nline2\nline3\nline4\n")

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        out = backend.read_screen("sess1", lines=2)

    assert captured["cmd"][:3] == ["zellij", "action", "dump-screen"]
    assert "--full" in captured["cmd"]
    assert captured["env"].get("ZELLIJ_SESSION_NAME") == "sess1"
    # lines=2 should return only the last two non-empty lines
    assert out.splitlines()[-2:] == ["line3", "line4"]


def test_zellij_send_uses_write_chars_with_session_env():
    backend = ZellijBackend()
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        captured["env"] = kwargs.get("env", {})
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.send("sess1", "hello world")

    assert captured["cmd"][:3] == ["zellij", "action", "write-chars"]
    assert "hello world" in captured["cmd"]
    assert captured["env"].get("ZELLIJ_SESSION_NAME") == "sess1"


def test_zellij_send_key_uses_send_keys_with_session_env():
    backend = ZellijBackend()
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        captured["env"] = kwargs.get("env", {})
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.send_key("sess1", "Enter")

    assert captured["cmd"][:3] == ["zellij", "action", "send-keys"]
    assert "Enter" in captured["cmd"]
    assert captured["env"].get("ZELLIJ_SESSION_NAME") == "sess1"


def test_zellij_list_workspaces_parses_short_session_names():
    backend = ZellijBackend()
    with patch(
        "atdd.coach.utils.multiplexer.subprocess.run",
        return_value=_make_result(stdout="sess1\nsess2\n\n"),
    ):
        assert backend.list_workspaces() == ["sess1", "sess2"]


def test_zellij_close_uses_delete_session_force():
    backend = ZellijBackend()
    captured = {}

    def fake_run(cmd, **kwargs):
        captured["cmd"] = cmd
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.close("sess1")

    assert captured["cmd"][:2] == ["zellij", "delete-session"]
    assert "--force" in captured["cmd"]
    assert "sess1" in captured["cmd"]


def test_zellij_missing_binary_raises_multiplexer_error():
    backend = ZellijBackend()
    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=FileNotFoundError):
        with pytest.raises(MultiplexerError, match="binary not found"):
            backend.read_screen("sess1")


# ---------------------------------------------------------------------------
# Surface (pane mode) — abstract contract + cmux dispatch
# wmbt:govern-lifecycle:D014, D015
# ---------------------------------------------------------------------------


def test_new_surface_contract_declared_on_abstract_base():
    """D014-AC-UNIT-001: new_surface is declared on the abstract base alongside new_workspace."""
    from atdd.coach.utils.multiplexer import MultiplexerBackend

    assert hasattr(MultiplexerBackend, "new_surface")
    assert hasattr(MultiplexerBackend, "new_workspace")
    # new_workspace signature unchanged: (cwd, command, name=None)
    import inspect
    ws_params = inspect.signature(MultiplexerBackend.new_workspace).parameters
    assert "cwd" in ws_params
    assert "command" in ws_params
    assert "name" in ws_params


def test_zellij_new_surface_raises_not_implemented():
    """D014-AC-UNIT-001: backends without pane semantics raise NotImplementedError."""
    backend = ZellijBackend()
    with pytest.raises(NotImplementedError):
        backend.new_surface(cwd="/tmp/wt", command="echo hi")


def test_tmux_new_surface_raises_not_implemented():
    """D014-AC-UNIT-001: tmux backend raises NotImplementedError for new_surface."""
    backend = TmuxBackend()
    with pytest.raises(NotImplementedError):
        backend.new_surface(cwd="/tmp/wt", command="echo hi")


def test_cmux_new_surface_creates_pane_then_surface_then_seeds():
    """D015-AC-UNIT-002: pane_ref=None → cmux new-pane → cmux new-surface → seed cwd+command via surface.send_text.

    Returned ref has the surface:* prefix.
    """
    backend = CmuxBackend()
    calls: list[list[str]] = []
    outputs = iter(["pane:42\n", "surface:99\n", ""])

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        try:
            stdout = next(outputs)
        except StopIteration:
            stdout = ""
        return _make_result(stdout=stdout)

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        ref = backend.new_surface(
            workspace_ref="workspace:17",
            pane_ref=None,
            cwd="/x",
            command="echo y",
            name="issue-340",
        )

    assert ref == "surface:99"
    # Call 0 — cmux new-pane with the workspace ref
    assert calls[0][:2] == ["cmux", "new-pane"]
    assert "workspace:17" in calls[0]
    # Call 1 — cmux new-surface with the freshly-created pane ref
    assert calls[1][:2] == ["cmux", "new-surface"]
    assert "pane:42" in calls[1]
    # Call 2 — cmux rpc surface.send_text seeding cwd + command together
    assert calls[2][:3] == ["cmux", "rpc", "surface.send_text"]
    seeded = next(arg for arg in calls[2] if "echo y" in arg)
    assert seeded == "cd /x && echo y\n"
    assert "surface:99" in calls[2]


def test_cmux_new_surface_with_existing_pane_skips_new_pane():
    """When a caller passes pane_ref, the backend skips cmux new-pane."""
    backend = CmuxBackend()
    calls: list[list[str]] = []
    outputs = iter(["surface:100\n", ""])

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        try:
            stdout = next(outputs)
        except StopIteration:
            stdout = ""
        return _make_result(stdout=stdout)

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        ref = backend.new_surface(
            workspace_ref="workspace:17",
            pane_ref="pane:23",
            cwd="/y",
            command="claude",
        )

    assert ref == "surface:100"
    assert calls[0][:2] == ["cmux", "new-surface"]
    assert "pane:23" in calls[0]
    # No cmux new-pane call
    assert all(c[:2] != ["cmux", "new-pane"] for c in calls)


def test_cmux_read_screen_dispatches_by_ref_prefix():
    """D015-AC-UNIT-001: workspace:* → cmux read-screen --workspace; surface:* → cmux rpc surface.read_text."""
    backend = CmuxBackend()
    calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return _make_result(stdout="line1\nline2\n")

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.read_screen("workspace:5", lines=10)
        backend.read_screen("surface:31", lines=10)

    assert calls[0][:2] == ["cmux", "read-screen"]
    assert "--workspace" in calls[0]
    assert "workspace:5" in calls[0]

    assert calls[1][:3] == ["cmux", "rpc", "surface.read_text"]
    assert "surface:31" in calls[1]


def test_cmux_send_dispatches_by_ref_prefix():
    """D015-AC-UNIT-001: workspace:* → cmux send --workspace; surface:* → cmux rpc surface.send_text."""
    backend = CmuxBackend()
    calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.send("workspace:5", "hello")
        backend.send("surface:31", "hi")

    assert calls[0][:3] == ["cmux", "send", "--workspace"]
    assert "hello" in calls[0]
    assert calls[1][:3] == ["cmux", "rpc", "surface.send_text"]
    assert "surface:31" in calls[1]
    assert "hi" in calls[1]


def test_cmux_send_key_dispatches_by_ref_prefix():
    """workspace:* → cmux send-key --workspace; surface:* → cmux rpc surface.send_key."""
    backend = CmuxBackend()
    calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.send_key("workspace:5", "Enter")
        backend.send_key("surface:31", "Enter")

    assert calls[0][:3] == ["cmux", "send-key", "--workspace"]
    assert calls[1][:3] == ["cmux", "rpc", "surface.send_key"]
    assert "surface:31" in calls[1]


def test_cmux_close_dispatches_by_ref_prefix():
    """D015-AC-UNIT-001: workspace:* → cmux close-workspace; surface:* → cmux close-surface."""
    backend = CmuxBackend()
    calls: list[list[str]] = []

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        return _make_result()

    with patch("atdd.coach.utils.multiplexer.subprocess.run", side_effect=fake_run):
        backend.close("workspace:5")
        backend.close("surface:31")

    assert calls[0][:2] == ["cmux", "close-workspace"]
    assert "workspace:5" in calls[0]
    assert calls[1][:2] == ["cmux", "close-surface"]
    assert "surface:31" in calls[1]
