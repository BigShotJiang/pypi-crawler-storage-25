# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-04-10

### Added

- Initial package skeleton following modern Python packaging standards (PEP 517/518/621).
- `src/` layout with `epitk` package.
- `py.typed` marker for PEP 561 compliance.
- `pyproject.toml` with `hatchling` build backend.
- CI workflow for testing and publishing to PyPI.

[Unreleased]: https://github.com/mt1022/epitk/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/mt1022/epitk/releases/tag/v0.1.0
