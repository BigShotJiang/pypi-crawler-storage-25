#!/usr/bin/env python3
"""Create a list of things to hang in the place with all the stuff (e.g. a bike shed)."""
import importlib.resources
import json

import logging
import pathlib

import argparse
import os.path
import typst
from typing import cast, Union, Literal
import treelib

from .box import BoxedThing
from . import inventory_io, labelprinter_typst, thingtemplate_typst


def add_arg_parsers(subparsers):
    """Make a command-line argument parser as a child of parent_parser.

    Supply information from command-line arguments.

    Args:
        subparsers: list of subparsers to add to. Type is private to argparse module.
    """
    parser = subparsers.add_parser(
        "label",
        description="""Create lists and signs for things in the inventory.

        The output directory is created. If the output files are
        not directly in the output directory, the directories
        where the output files are supposed to land must exist.

        Output files overwrite existing files.
        """,
    )

    parser.set_defaults(func=generate_labels)

    parser_single_label = subparsers.add_parser(
        "single_label", description="Create a single label as svg."
    )
    parser_single_label.add_argument(
        "thing_id",
        help="Thing id of the thing the label is for. "
        "This is the directory name of the thing.",
    )
    parser_single_label.set_defaults(func=generate_single_label_svg)


def get_thing_list_data(things: inventory_io.Inventory) -> dict[str, str]:
    """Get list[dict] representation of thing list.

    Returns:
        list of dicts. Each dict has "name" and "id", most have "where",
        many have "name_alt".
    """
    # each item can appear several times since alternative names
    # might not be unique: things can be similar.
    # so for every thing we need a list of lines
    lines: dict[str, list[dict[str, str | None]]] = {}

    def add_line(front_name: str, new_line: dict[str, str | None]):
        if "where" in new_line and not new_line["where"]:
            del new_line["where"]
        if front_name in lines:
            lines[front_name].append(new_line)
        else:
            lines[front_name] = [new_line]

    for thing in things:
        if thing.get("category", False):
            continue
        for name in thing.get("name", {}).values():
            add_line(
                name,
                {
                    "name": name,
                    "id": things.get_id(thing),
                    "where": thing.where if thing.location else None,
                },
            )
        for lang, names_alt in thing.get("name_alt", {}).items():
            logging.debug("f{(lang, names_alt)=}")
            for name_alt in names_alt:
                add_line(
                    name_alt,
                    {
                        "name_alt": name_alt,
                        "name": thing.get(
                            ("name", lang), thing.best("name", backup="")
                        ),
                        "id": things.get_id(thing),
                        "where": thing.where if thing.location else None,
                    },
                )
    return {
        "title": things.schema.name,
        "data": json.dumps(
            [
                line
                for name in sorted(list(lines.keys()), key=str.lower)
                for line in lines[name]
            ]
        ),
    }


def get_tree(things: inventory_io.Inventory) -> str:
    """Create a simple tree structure visualizing the things."""
    tree = treelib.Tree()
    nodes = []
    tree.create_node("Fahrrad", "fahrrad-0")
    for thing in things:
        name = str(thing.best("name", backup="?"))
        parents = cast(tuple, thing.get("part_of", ["fahrrad"]))
        for instance_nr, parent in enumerate(parents):
            node_id = f"{things.get_id(thing)}-{instance_nr}"
            # doesn't work well with categories that appear several times, whatever:
            parent = parent + "-0"
            nodes.append((name, node_id, parent))
    delayed_nodes = []
    inserted_node = True  # save if in previous run,
    # some node got removed from the list of all nodes
    while inserted_node:
        logging.debug("Start insertion walkthrough")
        inserted_node = False
        for node in nodes:
            try:
                tree.create_node(node[0], node[1], node[2])
            except treelib.exceptions.NodeIDAbsentError:
                delayed_nodes.append(node)
            except treelib.exceptions.DuplicatedNodeIdError as e:
                logging.error(f"{node[1]} twice: {e}")
                inserted_node = True
            else:
                inserted_node = True
        nodes = delayed_nodes
        delayed_nodes = []
    if len(nodes) > 0:
        logging.error("Remaining nodes:" + ", ".join((str(node) for node in nodes)))
    return tree.show(stdout=False)


def create_listpdf(
    data: dict[str, str],
    out: Union[
        Literal["svg"],
        Literal["pdf"],
        Literal["html"],
        Literal["png"],
        pathlib.Path,
    ] = "pdf",
):
    """Create a file that can be printed that lists all things.

    Args:
        data: dict of line infos
        out: path to created file or format
    """
    with importlib.resources.as_file(
        importlib.resources.files(thingtemplate_typst)
    ) as template_dir:
        try:
            output, warnings = typst.compile_with_warnings(
                input=template_dir / "thinglist.typ",
                output=out,
                format=(
                    out.suffix.lstrip(".")
                    if isinstance(out, pathlib.Path)
                    and out.suffix.lstrip(".") in ["pdf", "html", "svg", "png"]
                    else None
                ),
                sys_inputs=data,
            )
        except typst.TypstError as compile_error:
            logging.getLogger("thing list").error(f"Typst error: {compile_error}")
            raise
        finally:
            logging.info(
                f"Tried to create file {out if isinstance(out, pathlib.Path) else None} "
                f"with format {
                    out.suffix
                    if isinstance(out, pathlib.Path)
                       and out.suffix.lstrip(".") in ["pdf", "html", "svg", "png"]
                    else None}"
                f" and data {data}"
            )
        if warnings:
            logging.getLogger("thing list").warning(
                f"Typst raised these warnings: {warnings}."
            )
    return output


def generate_labels(options: argparse.Namespace):
    """Create lists and labels based on command-line options.

    Args:
        options: command line options given
    """
    os.makedirs(options.output_dir, exist_ok=True)
    logging.basicConfig(
        filename=options.output_dir / options.logfile,
        level=logging.DEBUG,
        filemode="w",
    )
    all_things: inventory_io.Inventory = inventory_io.Inventory.from_json_files(
        options.dataDirectory
    )
    logging.info("Create thing list")
    with open(
        options.output_dir / options.output_tree,
        mode="w",
        encoding="UTF-8",
    ) as treefile:
        logging.info("Start creating tree view.")
        treefile.write(get_tree(all_things))

    logging.getLogger("generateLabels").info("Start creating thing list.")
    create_listpdf(
        get_thing_list_data(all_things),
        options.output_dir / options.output_list,
    )

    logging.info("Start creating label pdf.")
    labelprinter_typst.LabelPrinter().create_labels(
        all_things, options.output_dir / options.output_labels
    )


def generate_single_label_svg(options: argparse.Namespace):
    """Generate sign for a single thing, given by options.thing_id.

    Args:
        options: command line options given
    """
    logging.basicConfig(
        filename=os.path.join(options.output_dir, options.logfile),
        level=logging.DEBUG,
        filemode="w",
    )
    logging.info("Create thing sign")
    all_things = inventory_io.Inventory.from_json_files(options.dataDirectory)
    logging.info("Start creating sign svg.")
    try:
        thing = all_things.get_by_id(options.thing_id)
    except KeyError as id_not_found:
        print("key error:")
        print(id_not_found)
        possible_things = list(all_things.get_by_best("name", options.thing_id))
        if len(possible_things) == 1:
            thing = possible_things[0]
            message = f"Found {thing.best("name")} ({all_things.get_id(thing)}) to print label."
            logging.info(message)
        else:
            error_message = (
                f"No thing with the id {options.thing_id} and no or multiple things "
                f"with this name. Do not do anything."
            )
            logging.error(error_message)
            print(error_message)
            return
    label_printer = labelprinter_typst.LabelPrinter()
    svg_path = options.output_dir / f"{all_things.get_id(thing)}" "{n}.svg"
    label_printer.create_label(thing, svg_path)
    svg_path = pathlib.Path(str(svg_path).replace("{n}", "1"))
    if svg_path.is_file():
        print(
            f"sign svg created for {thing.best('name', backup="?")} "
            f"({options.thing_id}): find it at {svg_path}"
        )
    else:
        print(
            f"Error at creating sign for {thing.best('name', backup="?")} "
            f"({options.thing_id}). Path should have been {svg_path}. Maybe log contains an error info."
        )
