// This file renders one label.

/// Get length of longest word in a text
/// -> length
#let longest_word_length(
  /// font size for which length is calculated
  /// -> length
  font_size,
  /// text in which the longest word is searched for
  /// -> str
  body,
) = {
  let min_text_width = 0pt
  for word in body.split(regex("[- ]")) {
    min_text_width = calc.max(
      min_text_width,
      measure(text(size: font_size, word)).width,
    )
  }
  return min_text_width
}


/// Scale text to maximum size within outer container
/// To reduce the number of cases of text overflow, the longest
/// word in the text is used as a limit in regard of the width.
/// This does not catch all cases because several words can together
/// be too long for the width but it can handle some obvious cases.
/// In all other cases a font size must be explicitly told via the font_size argument.
/// -> block
#let resize_text(
  /// distance between lines in relation to font size
  /// -> float
  leading_factor: 0.1,
  /// try out font sizes in this step. Smaller is more exact but takes more computation
  /// -> length
  step: 0.1pt,
  /// maximum height of the container. If relative, it's relative to outer container
  /// max_width is always 100%
  /// -> length
  max_height: 100%,
  /// Minimum font size. If with this font size the maximum height or width are exceeded, it is still used.
  /// -> length
  min_font_size: 0.9pt,
  /// Fixed font size. Ignored if not given or < 0 (usual use case).
  /// In case you know that the resize algorithm is crap for these inputs,
  /// you can still use this function to apply the other modification (leading mainly)
  font_size: -1pt,
  /// content to be maximised. Only tested with str
  /// -> str
  body,
) = layout(size => {
  let try_font_size = font_size
  if font_size < 0pt {
    try_font_size = min_font_size
    let height = 1pt
    let max_height = size.height * max_height
    let min_text_width = 0pt

    while height <= max_height and min_text_width <= size.width {
      try_font_size = try_font_size + step
      height = measure(
        block(width: size.width, text(size: try_font_size, par(
          leading: try_font_size * leading_factor,
          body,
        ))),
      ).height
      min_text_width = longest_word_length(try_font_size, body)
    }
    try_font_size = try_font_size - step
  }

  block(
    //height: height,
    width: 100%,
    text(
      size: try_font_size,
      par(leading: try_font_size * leading_factor, body),
    ),
  )
})

/// Insert an image, turn it by 90° if necessary to make it bigger in the available space
/// -> block
#let maxed_image(
  /// path the image
  /// -> str
  image_path: "dummyImage.jpg",
) = block(width: 100%, height: 1fr, layout(size => {
  let image_size = measure(image(image_path))
  if (size.width < size.height) == (image_size.width < image_size.height) {
    image(width: 100%, height: 100%, fit: "contain", image_path)
  } else {
    // todo: the rotated images are left-aligned even though they should
    // be centered as the other ones as well
    rotate(90deg, reflow: true, image(width: 100%, height: 100%, fit: "contain", image_path))
  }
}))

/// Create a label with two titles in two languages, a location
/// and an image filling the remaining height.
/// The texts have a minimum font size and a height (usually percentage of label height).
/// The maximum of both is used
#let thing_label(
  /// a dictionary from which the following keys are used:
  /// width: width of the label
  /// spacing: space between elements and between elements and border, default 2%
  /// height: height of the label
  /// name_1: Title in first language
  /// name_1_height: height of first title. By default 25%.
  /// name_1_min_font_size: minimum font size of first title. By default 10pt
  /// name_1_font_size: if given, use this font size instead of maximizing it
  ///                   intended for labels where maximising algorithm creates havoc
  /// lang_1: language code ISO 639-1/2/3 language code for first title. Might influence typesetting it a tiny bit
  /// name_2: Title in second language
  /// name_2_height: height of first title. By default 18%
  /// name_2_min_font_size: minimum font size of second title. By default 10pt
  /// name_2_font_size: if given, use this font size instead of maximizing it
  ///                   intended for labels where maximising algorithm creates havoc
  /// lang_2: language code ISO 639-1/2/3 language code for second title. Might influence typesetting it a tiny bit
  /// image: path to image. Relative to this file or starting with /, relative to project root
  /// where: where the displayed thing is located
  /// where_height: height of the location text.
  /// where_min_font_size: minimum font size for the location, by default 8pt
  /// where_font_size: if given, use this font size instead of maximizing it
  ///                  intended for labels where maximising algorithm creates havoc
  params,
) = [
  #let spacing = eval(params.at("spacing", default: "2%"))

  #if "where" not in params {
    params.insert("where", "Orkus")
  }

  #let (name_1_height, name_2_height) = if "name_1" in params {
    if "name_2" in params {
      ("25%", "18%")
    } else {
      ("35%", "0pt")
    }
  } else {
    if "name_2" in params {
      ("0pt", "35%")
    } else {
      params.insert("name_1", "Deugscher Name fehlt")
      params.insert("name_2", "English name missing")
      ("25%", "18%")
    }
  }
  #let name_1_height = eval(params.at("name_1_height", default: name_1_height))
  #let name_2_height = eval(params.at("name_2_height", default: name_2_height))

  #block(
    stroke: 1pt,
    height: eval(params.at("height", default: "5cm")),
    width: eval(params.at("width", default: "4cm")),
    inset: spacing,
  )[
    #set align(center + horizon)
    #set block(spacing: spacing)
    #set text(top-edge: "cap-height", bottom-edge: "bounds")

    #if name_1_height != 0pt {
      set text(lang: params.at("lang_1", default: "de"))
      resize_text(
        max_height: name_1_height,
        min_font_size: eval(params.at("name_1_min_font_size", default: "10pt")),
        font_size: eval(params.at("name_1_font_size", default: "-1pt")),
        params.at("name_1", default: "Deutscher Name fehlt"),
      )
    }

    #if name_2_height != 0pt {
      set text(lang: params.at("lang_2", default: "en"))
      resize_text(
        max_height: name_2_height,
        min_font_size: eval(params.at("name_2_min_font_size", default: "10pt")),
        font_size: eval(params.at("name_2_font_size", default: "-1pt")),
        params.at("name_2", default: "English name missing"),
      )
    }

    #maxed_image(image_path: params.at("image", default: "dummyImage.jpg"))
    #set text(lang: params.at("lang_1", default: "de"))
    #align(right, resize_text(
      max_height: eval(params.at("where_height", default: "5%")),
      min_font_size: eval(params.at("where_min_font_size", default: "6pt")),
      font_size: eval(params.at("where_font_size", default: "-1pt")),
      params.where,
    ))
  ]
]

#set text(font: "Atkinson Hyperlegible")
#if "data" in sys.inputs {
  // assume many labels shoud be printed
  set page(margin: 0.5cm, paper: "a4")
  let data = json(bytes(sys.inputs.data))

  for label_info in data {
    box(inset: 1mm, thing_label(label_info))
  }
} else {
  set page(
    margin: 0pt,
    height: auto,
    width: auto,
  )
  thing_label(sys.inputs)
}
