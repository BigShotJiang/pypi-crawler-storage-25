#let data = json(bytes(sys.inputs.data))
#set page(
  margin: (bottom: 1.5cm, rest: 0.5cm),
  numbering: "1",
  paper: sys.inputs.at("paper", default: "a4"),
)
#columns(eval(sys.inputs.at("columns", default: "2")), gutter: 0.3cm, [
  #heading(sys.inputs.at("title", default: "Fahrradteile"))
  #for line in data {
    if "name_alt" in line {
      list.item(
        [*#line.at("name_alt")* #sym.arrow.r #line.at("name") #if "where" in line [@ #line.where]],
      )
    } else {
      list.item([*#line.name* #if "where" in line [@ #line.where]])
    }
  }
])
