"""Antigravity conversation exporter — uses antigravity-history API directly."""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from urllib.parse import unquote

logger = logging.getLogger("collector.antigravity_export")

# Cache: cascade_id → content_hash
_last_hashes: dict[str, str] = {}


def _step_to_jsonl_line(step: dict, cascade_id: str, fallback_ts: str) -> dict | None:
    """Convert an Antigravity trajectory step to a Claude Code-compatible JSONL message."""
    step_type = step.get("type", "")
    # Extract per-step timestamp from metadata
    ts = step.get("metadata", {}).get("createdAt", "") or fallback_ts

    if step_type == "CORTEX_STEP_TYPE_USER_INPUT":
        text = step.get("userInput", {}).get("userResponse", "")
        if text:
            return {
                "type": "user",
                "message": {"role": "user", "content": text},
                "timestamp": ts,
                "cwd": "",
            }

    elif step_type == "CORTEX_STEP_TYPE_PLANNER_RESPONSE":
        text = step.get("plannerResponse", {}).get("response", "")
        if text:
            return {
                "type": "assistant",
                "message": {"role": "assistant", "content": [{"type": "text", "text": text}]},
                "timestamp": ts,
            }

    elif step_type == "CORTEX_STEP_TYPE_RUN_COMMAND":
        payload = step.get("runCommand", {})
        command = payload.get("command") or payload.get("commandLine") or ""
        output = payload.get("renderedOutput", {})
        output_text = output.get("full", "") if isinstance(output, dict) else str(output or "")
        if command:
            return {
                "type": "tool",
                "role": "tool",
                "tool_name": "run_command",
                "tool_input": command,
                "content": output_text[:2000],
                "timestamp": ts,
            }

    elif step_type == "CORTEX_STEP_TYPE_VIEW_FILE":
        payload = step.get("viewFile", {})
        path = payload.get("absolutePath") or payload.get("absolutePathUri") or ""
        if path:
            return {
                "type": "tool",
                "role": "tool",
                "tool_name": "view_file",
                "tool_input": path,
                "content": f"[Viewed: {path}]",
                "timestamp": ts,
            }

    elif step_type == "CORTEX_STEP_TYPE_CODE_ACTION":
        payload = step.get("codeAction", step.get("codeEdit", {}))
        file_path = payload.get("absolutePath") or payload.get("absolutePathUri") or ""
        description = payload.get("description") or payload.get("summary") or ""
        diff = payload.get("diff") or payload.get("rawDiff") or ""
        content_parts = []
        if description:
            content_parts.append(description)
        if diff:
            content_parts.append(f"```diff\n{diff[:1500]}\n```")
        if not content_parts:
            content_parts.append(f"[Code edit: {file_path}]")
        return {
            "type": "tool",
            "role": "tool",
            "tool_name": "code_edit",
            "tool_input": file_path,
            "content": "\n".join(content_parts),
            "timestamp": ts,
        }

    elif step_type == "CORTEX_STEP_TYPE_NOTIFY_USER":
        payload = step.get("notifyUser", {})
        text = payload.get("message") or payload.get("text") or ""
        if text:
            return {
                "type": "assistant",
                "message": {"role": "assistant", "content": [{"type": "text", "text": text}]},
                "timestamp": ts,
            }

    elif step_type == "CORTEX_STEP_TYPE_LIST_DIRECTORY":
        payload = step.get("listDirectory", step.get("listDir", {}))
        path = payload.get("directoryPath") or payload.get("absolutePathUri") or ""
        if path:
            return {
                "type": "tool",
                "role": "tool",
                "tool_name": "list_dir",
                "tool_input": path,
                "content": f"[Listed: {path}]",
                "timestamp": ts,
            }

    elif step_type == "CORTEX_STEP_TYPE_GREP_SEARCH":
        payload = step.get("grepSearch", step.get("search", {}))
        query = payload.get("query") or payload.get("pattern") or ""
        if query:
            return {
                "type": "tool",
                "role": "tool",
                "tool_name": "grep_search",
                "tool_input": query,
                "content": f"[Search: {query}]",
                "timestamp": ts,
            }

    elif step_type == "CORTEX_STEP_TYPE_FIND":
        payload = step.get("find", {})
        pattern = payload.get("pattern") or payload.get("query") or ""
        if pattern:
            return {
                "type": "tool",
                "role": "tool",
                "tool_name": "find",
                "tool_input": pattern,
                "content": f"[Find: {pattern}]",
                "timestamp": ts,
            }

    elif step_type == "CORTEX_STEP_TYPE_COMMAND_STATUS":
        payload = step.get("commandStatus", {})
        text = payload.get("output") or payload.get("status") or ""
        if text:
            return {
                "type": "tool",
                "role": "tool",
                "tool_name": "command_status",
                "tool_input": "",
                "content": text[:2000],
                "timestamp": ts,
            }

    elif step_type == "CORTEX_STEP_TYPE_ERROR_MESSAGE":
        payload = step.get("errorMessage", {})
        text = payload.get("shortError") or payload.get("text") or ""
        if text:
            return {
                "type": "system",
                "message": {"role": "system", "content": text},
                "timestamp": ts,
            }

    # Skip: TASK_BOUNDARY, CHECKPOINT, CONVERSATION_HISTORY, EPHEMERAL_MESSAGE
    return None


def export_conversations() -> list[dict]:
    """Export Antigravity conversations as JSONL (compatible with conversation parser).

    Requires: pip install antigravity-history
    Requires: Antigravity IDE to be running

    Returns list of changed conversations with JSONL content.
    """
    try:
        from antigravity_history.discovery import discover_language_servers, find_all_endpoints
        from antigravity_history.api import get_all_trajectories, call_api
    except ImportError:
        logger.debug("antigravity-history not installed, skipping")
        return []

    try:
        servers = discover_language_servers()
        if not servers:
            return []
        endpoints = find_all_endpoints(servers)
        if not endpoints:
            return []
    except Exception as e:
        logger.debug("Antigravity discovery failed: %s", e)
        return []

    conversations = []

    for ep in endpoints:
        # Layer 1: Get summaries from live API (recent conversations)
        try:
            summaries = get_all_trajectories(ep["port"], ep["csrf"])
        except Exception:
            summaries = {}

        # Layer 2: Scan .pb files for ALL cascade IDs, then fetch individually
        import re
        import platform
        home = Path.home()
        if platform.system() == "Windows":
            import os
            appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
            gemini_root = appdata / ".gemini" if (appdata / ".gemini").exists() else home / ".gemini"
        else:
            gemini_root = home / ".gemini"
        conv_root = gemini_root / "antigravity" / "conversations"

        uuid_re = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
        pb_count = 0
        fetched = 0
        if conv_root.exists():
            from antigravity_history.api import call_api
            for pb_file in conv_root.glob("*.pb"):
                cid = pb_file.stem
                if uuid_re.match(cid) and cid not in summaries:
                    pb_count += 1
                    try:
                        payload = call_api(ep["port"], ep["csrf"], "GetCascadeTrajectory", {"cascadeId": cid}, timeout=15)
                        if payload:
                            traj = payload.get("trajectory", payload)
                            if traj.get("summary") or traj.get("cascadeId"):
                                summaries[cid] = {
                                    "summary": traj.get("summary", cid[:8]),
                                    "stepCount": traj.get("stepCount") or len(traj.get("steps", [])),
                                    "lastModifiedTime": traj.get("lastModifiedTime", ""),
                                    "createdTime": traj.get("createdAt", traj.get("createdTime", "")),
                                    "status": traj.get("status", ""),
                                    "workspaces": traj.get("workspaces", []),
                                }
                                fetched += 1
                    except Exception as e:
                        logger.debug("Failed to fetch cascade %s: %s", cid[:8], e)
        if pb_count > 0:
            logger.info("Scanned %d .pb files, fetched %d additional conversations", pb_count, fetched)

        for cascade_id, info in summaries.items():
            title = info.get("summary", cascade_id[:8])
            step_count = info.get("stepCount", 0)
            last_modified = info.get("lastModifiedTime", "")
            created = info.get("createdTime", "")

            # Extract workspace
            workspace = ""
            workspaces = info.get("workspaces", [])
            if workspaces and isinstance(workspaces[0], dict):
                workspace = workspaces[0].get("workspaceFolderAbsoluteUri", "")

            # Incremental: skip unchanged (v2 = format version, forces re-export on format change)
            summary_key = f"v4:{cascade_id}:{step_count}:{last_modified}"
            content_hash = hashlib.sha256(summary_key.encode()).hexdigest()[:16]
            if _last_hashes.get(cascade_id) == content_hash:
                continue
            _last_hashes[cascade_id] = content_hash

            # Resolve workspace to cwd path
            cwd = ""
            if workspace:
                cwd = unquote(workspace).replace("\\", "/")
                if cwd.startswith("file:///"):
                    cwd = cwd[7:] if cwd[8:9] != ":" else cwd[8:]

            # Build JSONL content — fetch all steps
            jsonl_lines = []

            # First line: session metadata (like Codex format)
            jsonl_lines.append(json.dumps({
                "type": "session_meta",
                "timestamp": created,
                "payload": {
                    "id": cascade_id,
                    "timestamp": created,
                    "cwd": cwd,
                    "originator": "Antigravity",
                    "model_provider": "google",
                    "title": title,
                    "step_count": step_count,
                    "status": info.get("status", ""),
                },
            }, ensure_ascii=False))

            try:
                # Use verbosity=1 (DEBUG) to get all steps without pagination
                # This is the same approach as antigravity-trajectory-extractor
                steps_response = call_api(
                    ep["port"], ep["csrf"], "GetCascadeTrajectorySteps",
                    {"cascadeId": cascade_id, "verbosity": 1},
                    timeout=60,
                )
                steps = (steps_response or {}).get("steps", []) if steps_response else []
                for step in steps:
                    msg = _step_to_jsonl_line(step, cascade_id, last_modified)
                    if msg:
                        if msg["type"] == "user" and cwd and not msg.get("cwd"):
                            msg["cwd"] = cwd
                        jsonl_lines.append(json.dumps(msg, ensure_ascii=False))
            except Exception as e:
                logger.debug("Failed to fetch steps for %s: %s", cascade_id, e)

            content = "\n".join(jsonl_lines)

            # Project name from workspace
            project_name = cwd.rstrip("/").split("/")[-1] if cwd else None

            conversations.append({
                "title": title,
                "cascade_id": cascade_id,
                "workspace": workspace,
                "project_name": project_name,
                "size": len(content),
                "content": content,
                "content_hash": content_hash,
            })

    if conversations:
        logger.info("Exported %d changed Antigravity conversations", len(conversations))
    return conversations
