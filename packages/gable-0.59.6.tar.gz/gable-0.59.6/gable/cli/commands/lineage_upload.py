import json
import os
import re

import click
from click.core import Context as ClickContext
from loguru import logger
from pydantic import ValidationError

from gable.api.client import GableAPIClient
from gable.cli.helpers.lineage_api import upload_sca_results_via_api
from gable.cli.helpers.npm import prepare_npm_environment
from gable.cli.helpers.sca_run import DuplicateStartRunConflict, start_sca_run
from gable.cli.options import global_options
from gable.common_types import LineageDataFile
from gable.openapi import (
    CollectionMechanism,
    CrossServiceDataStore,
    CrossServiceEdge,
    StaticAnalysisDataFlowPath,
    Type,
)

SELECTED_OVERRIDE_PAYLOADS = [
    "AMPCreditPolicyRulesCompletedEventHandler",
    "NcinoEventHandlerV4",
    "PersonalDateTimeEventHandler",
    "AcsDdsEventHandlerV4",
    "CaptureServiceEventHandler",
    "SpendApprovalOverridesVerifiedEventHandlerV4",
    "ProcessAppEventHandler",
    "ApplicationModelScoresHandlerV4",
]


def get_lineage_schema(upload_type: Type | None):
    if upload_type == Type.DATA_STORE:
        return CrossServiceDataStore
    elif upload_type == Type.EDGE:
        return CrossServiceEdge
    return LineageDataFile


def collect_selected_override_paths(
    override_lineage: LineageDataFile,
) -> dict[str, StaticAnalysisDataFlowPath]:
    selected_override_paths_by_payload: dict[str, StaticAnalysisDataFlowPath] = {}
    duplicate_counts: dict[str, int] = {}

    for path in override_lineage.paths:
        payload_name = path.payload_name
        if payload_name not in SELECTED_OVERRIDE_PAYLOADS:
            continue

        if payload_name in selected_override_paths_by_payload:
            duplicate_counts[payload_name] = duplicate_counts.get(payload_name, 1) + 1
            continue

        selected_override_paths_by_payload[payload_name] = path

    if duplicate_counts:
        logger.warning(
            "Expected exactly one prime override path per selected payload, but found duplicates for {}. "
            "Proceeding with the first prime path for each payload.",
            duplicate_counts,
        )

    return selected_override_paths_by_payload


def apply_override_lineage_data(
    result_lineage: LineageDataFile,
    override_lineage: LineageDataFile,
) -> LineageDataFile:
    selected_override_paths_by_payload = collect_selected_override_paths(
        override_lineage
    )

    result_paths_without_selected_payloads = [
        path
        for path in result_lineage.paths
        if path.payload_name not in SELECTED_OVERRIDE_PAYLOADS
    ]
    selected_override_paths = [
        selected_override_paths_by_payload[payload_name].model_copy(deep=True)
        for payload_name in SELECTED_OVERRIDE_PAYLOADS
        if payload_name in selected_override_paths_by_payload
    ]

    result_lineage.paths = (
        result_paths_without_selected_payloads + selected_override_paths
    )
    return result_lineage


@click.command(
    add_help_option=False,
    name="upload",
    epilog="""Example:
    gable lineage upload --project-root ./path/to/project""",
)
@global_options(add_endpoint_options=False)
@click.option(
    "--project-root",
    help="The root directory of the project that will be analyzed.",
    type=click.Path(exists=True),
    required=True,
)
@click.option(
    "--results-file",
    help="The path to the results file.",
    type=click.Path(exists=True),
    required=True,
)
@click.option(
    "--override-file",
    help=(
        "Optional LineageDataFile JSON used to replace/add selected payload "
        "paths in the result file before upload."
    ),
    type=click.Path(exists=True),
    required=False,
)
@click.option(
    "--namespace",
    envvar="GABLE_NAMESPACE",
    type=str,
    callback=lambda ctx, _param, value: (
        value
        if value is None or re.fullmatch(r"[a-zA-Z0-9_.\-]+", value)
        else ctx.fail(
            f"Invalid namespace '{value}'. Must only contain alphanumeric characters, underscores, hyphens, and dots."
        )
    ),
    help="INTERNAL: select the namespace you want lineage results to be associated with.",
    required=True,
)
@click.pass_context
def lineage_upload(
    ctx: ClickContext,
    project_root: str,
    results_file: str,
    override_file: str | None,
    namespace: str | None,
):
    """
    Upload lineage data to Gable.
    """
    client: GableAPIClient = ctx.obj.client
    override_lineage_obj = None

    with open(results_file, "r") as f:
        results = json.load(f)

    upload_type = results.get("type")

    if override_file and upload_type not in (None, Type.CODE):
        raise click.ClickException(
            "--override-file is only supported for CODE lineage uploads."
        )

    if override_file:
        with open(override_file, "r") as f:
            override_results = json.load(f)
        try:
            override_lineage_obj = LineageDataFile.model_validate(override_results)
        except ValidationError as e:
            logger.debug(f"Invalid override file: {e}")
            raise click.ClickException(f"Invalid override file: {e}")

    try:
        metadata = results.get("metadata", None)
        user_job_trigger = (
            None if metadata is None else metadata.get("job_trigger", None)
        )
        LineageFile = get_lineage_schema(upload_type)
        lineage_obj = LineageFile.model_validate(results)

        if override_lineage_obj:
            if not isinstance(lineage_obj, LineageDataFile):
                raise click.ClickException(
                    "--override-file is only supported for CODE lineage uploads."
                )
            lineage_obj = apply_override_lineage_data(lineage_obj, override_lineage_obj)

    except ValidationError as e:
        logger.debug(f"Invalid results file: {e}")
        raise click.ClickException(f"Invalid results file: {e}")

    prepare_npm_environment(client)
    external_component_id = getattr(lineage_obj, "external_component_id", None)
    repo_name = getattr(lineage_obj, "name", None)

    env_mechanism = os.environ.get("GABLE_COLLECTION_MECHANISM")
    collection_mechanism = CollectionMechanism(env_mechanism) if env_mechanism else None

    try:
        run_id, _ = start_sca_run(
            client=client,
            project_root=project_root,
            action="upload",
            output=None,
            include_unchanged_assets=None,
            external_component_id=external_component_id,
            upload_type=upload_type,
            repo_name=repo_name,
            namespace=namespace,
            user_job_trigger=user_job_trigger,
            collection_mechanism=collection_mechanism,
        )
    except DuplicateStartRunConflict as err:
        logger.warning(str(err))
        click.echo(
            f"{err}. Skipping upload because this run was already started. Exiting successfully."
        )
        return

    upload_sca_results_via_api(client, run_id, lineage_obj)

    click.echo(
        f"Uploaded lineage data from {results_file} to Gable with run ID: {run_id}"
    )
