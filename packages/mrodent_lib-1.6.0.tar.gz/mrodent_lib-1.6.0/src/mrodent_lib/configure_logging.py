import logging

logging.basicConfig(format='%(asctime)s.%(msecs)03d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
        datefmt='%H:%M:%S', level=logging.DEBUG)
basic_logger = logging.getLogger('BASIC')
basic_logger.info(f'start {__file__}')

import sys, colorlog, pathlib
import logging
import logging.handlers
from queue import Queue

# 2026-05-09 you can't use "src.constants_lib" here, not sure why TODO
from .constants_lib import PROJECT_NAME, STANDARD_LOGGING_LOCATION

# Global reference to stop the listener on exit
_listener = None

def configure_logging(*args, maxBytes=1024 * 1024):
    global _listener

    # Detect if we are running under pytest
    is_pytest = "pytest" in sys.modules
    # --- Argument Handling (Your original logic) ---
    if len(args) > 1:
        raise Exception(f'configure_logging func was passed with too many args: {args}')
    logger_name = args[0] if len(args) == 1 and isinstance(args[0], str) else PROJECT_NAME
    # Validation for non-string args
    if len(args) == 1 and not isinstance(args[0], str):
         raise Exception(f'configure_logging func was passed with non-str arg: {args[0]}')

    # --- Directory Setup ---
    log_file_path = STANDARD_LOGGING_LOCATION.joinpath(logger_name, EnhancedCRFHFormatter.LOG_FILENAME)
    try:
        log_file_path.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        # Keeping your prominent warning logic
        print(f'WARNING. Failed to create logging path: {log_file_path.parent}')
        raise e
    # --- 1. The "Real" Handlers (The Consumers) ---
    # These will live inside the QueueListener on a background thread.
    # A. File Handler (Replaces ConcurrentRotatingFileHandler)
    file_handler = logging.handlers.RotatingFileHandler(
        log_file_path, 'a', maxBytes, 10, 'utf-8'
    )
    file_handler.setFormatter(EnhancedCRFHFormatter(
        '%(asctime)s - [%(name)s] - %(levelname)s %(module)s [%(pathname)s %(lineno)d]:\n%(message)s',
        max_length=10000
    ))
    # B. Stream Handler (CLI)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(EnhancedColourFormatter(
        '%(log_color)s%(asctime)s %(levelname)s %(module)s [%(pathname)s %(lineno)d]:\n%(message)s',
        log_colors={
            'DEBUG':    'white',
            'INFO':     'white',
            'WARNING':  'fg_bold_yellow',
            'ERROR':    'fg_bold_red',
            'CRITICAL': 'fg_bold_red,bg_white',
        }, 
        datefmt='%a %H:%M:%S',
        max_length=1000
    ))

    # --- 2. The Queue Mechanism ---
    log_queue = Queue(-1)  # Infinite size queue
    # Create the Listener to handle the background work
    # It takes our two "real" handlers and manages them.
    _listener = logging.handlers.QueueListener(
        log_queue, stream_handler, file_handler, respect_handler_level=True
    )
    _listener.start()
    # --- 3. The "Virtual" Handler (The Producer) ---
    # This is what the main app uses. It just pushes to the queue.
    logger = logging.getLogger(logger_name)
    # Clear existing handlers to prevent duplicates on re-config
    if logger.hasHandlers():
        logger.handlers.clear()
    logger.addHandler(logging.handlers.QueueHandler(log_queue))
    if is_pytest:
        # HACK: If in pytest, we temporarily allow propagation 
        # so pytest's 'caplog' can actually see the messages.
        logger.propagate = True
    else:
        logger.propagate = False    
    logger.setLevel(logging.INFO)
    return logger

def stop_logging():
    global _listener
    if _listener:
        _listener.stop()

# --- Custom Formatter Classes (Preserved exactly as they were) ---
class BasicEnhancedFormatter(logging.Formatter):
    def __init__(self, *args, max_length=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.default_msec_format = '%s.%03d'
        self.max_length = max_length

    def format(self, record):
        # Store original message to avoid permanently truncating it for other handlers
        orig_msg = record.msg
        # If the message is a string and exceeds max_length, truncate it
        if self.max_length and isinstance(record.msg, str) and len(record.msg) > self.max_length:
            record.msg = record.msg[:self.max_length] + '\n...\n'
        # Call the standard format logic
        result = super().format(record)
        # RESTORE the original message so the next handler gets the full text
        record.msg = orig_msg
        return result        

class EnhancedColourFormatter(colorlog.ColoredFormatter, BasicEnhancedFormatter):
    def __init__(self, *args, max_length=None, **kwargs):
        # We need to handle both parent inits
        super().__init__(*args, **kwargs)
        self.max_length = max_length

    def formatTime(self, record, datefmt=None):
        return_val = super().formatTime(record, datefmt=datefmt)
        return f'{return_val}.{int(record.msecs):03}'

class EnhancedCRFHFormatter(BasicEnhancedFormatter):
    LOG_FILENAME = 'rotator_fh.log'
    _LINE_OF_EQUALS = 120 * '='

    def formatMessage(self, record: logging.LogRecord):
        # relative path logic
        record_path = pathlib.Path(record.pathname)
        cwd_path = pathlib.Path.cwd()
        if record_path.is_relative_to(cwd_path):
            record.pathname = str(record_path.relative_to(cwd_path))
        formatted_msg = super().formatMessage(record)
        return f'{EnhancedCRFHFormatter._LINE_OF_EQUALS}\n{formatted_msg}\n{EnhancedCRFHFormatter._LINE_OF_EQUALS}'
    

