import logging
logging.basicConfig(format='%(asctime)s.%(msecs)03d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
    datefmt='%H:%M:%S', level=logging.DEBUG)
basic_logger = logging.getLogger('BASIC')
basic_logger.info(f'start {__file__}')

import pathlib, os, sys, re

DATA_STRING = 'data'
DELETE_STRING = 'delete'
GET_STRING = 'get'
HEAD_STRING = 'head'
HEADERS_STRING = 'headers'
JSON_STRING = 'json'
OPTIONS_STRING = 'options'
PATCH_STRING = 'patch'
POST_STRING = 'post'
PROJECT_STRING = 'project'
PUT_STRING = 'put'
TIMEOUT_STRING = 'timeout'
VERSION_STRING = 'version'

IS_LINUX = None
if sys.platform.lower().startswith('lin'):
    IS_LINUX = True
elif sys.platform.lower().startswith('win'):
    IS_LINUX = False
else:
    basic_logger.error(f'FATAL. Unknown operating system: |{sys.platform}|')
    sys.exit()

parent_dir_name = pathlib.Path(__file__).parent.name # mrodent_lib
PART2_NAME = 'PART2'
PART2_VAL = os.environ.get(PART2_NAME)
if PART2_VAL == None:
    basic_logger.error(f'FATAL. Environment variable |{PART2_NAME}| not set')
    sys.exit()
# 2026-02-26 this is kind of vital due to the way a "root dir" is made in W10 and Linux
PART2_PATH = pathlib.Path('/', PART2_VAL) if IS_LINUX else pathlib.Path(PART2_VAL, '/')  

cwd_parts = pathlib.Path.cwd().parts
IS_PRODUCTION = None
if re.match('.*workspace.*', cwd_parts[-2].lower()):
    IS_PRODUCTION = False
elif cwd_parts[-2].lower() == 'operative':
    IS_PRODUCTION = True
if IS_PRODUCTION is None:
    basic_logger.error(f'FATAL. CWD is {cwd_parts}: this indicates neither a production run nor a dev run')
    sys.exit()

PROJECT_NAME = cwd_parts[-1]

logging_directory_str = f'{"ephem" if IS_PRODUCTION else "temp"}' 
if IS_LINUX:
    STANDARD_LOGGING_LOCATION = pathlib.Path(PART2_VAL, logging_directory_str, 'logging')
else:
    STANDARD_LOGGING_LOCATION = pathlib.Path(PART2_VAL, '/', logging_directory_str, 'logging')

basic_logger.info(f"""
IS_LINUX {IS_LINUX}
PART2_PATH {PART2_PATH}
IS_PRODUCTION {IS_PRODUCTION}
PROJECT_NAME {PROJECT_NAME}
STANDARD_LOGGING_LOCATION {STANDARD_LOGGING_LOCATION}""")

