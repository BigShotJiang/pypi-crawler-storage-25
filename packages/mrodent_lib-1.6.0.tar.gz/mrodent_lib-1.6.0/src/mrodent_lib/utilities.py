import logging

logging.basicConfig(format='%(asctime)s.%(msecs)03d %(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
        datefmt='%H:%M:%S', level=logging.DEBUG)
basic_logger = logging.getLogger('BASIC')
basic_logger.info(f'start {__file__}')

import requests, json
from pydantic import ValidationError, BaseModel, AnyHttpUrl, validate_call
from typing import Type, Optional

from mrodent_lib.constants_lib import PROJECT_NAME, TIMEOUT_STRING, GET_STRING, POST_STRING, JSON_STRING,\
    PUT_STRING, PATCH_STRING, DELETE_STRING, HEAD_STRING, OPTIONS_STRING, DATA_STRING, HEADERS_STRING

logger = logging.getLogger(PROJECT_NAME)

def do_request(method, url, base_model_class=None, **kwargs):
    try:
        return inner_do_request(method, url, base_model_class, **kwargs)
    except Exception as e:
        # an exception raised by Request.raise_for_status() often has a reference to the Response which
        # will usually give more detailed info on what went wrong
        exception_response_str = ''
        if isinstance(e, requests.exceptions.HTTPError):
            if hasattr(e, 'response'):
                try:
                    exception_response_str = json.dumps(e.response.json(), indent=2)
                except json.JSONDecodeError:
                    if hasattr(e.response, 'text'):
                        exception_response_str = e.response.text
        if exception_response_str != '':
            exception_response_str = f'reponse details:\n{exception_response_str}\n\n'
        kwarg_info_str = ''
        for kwarg_arg, value in kwargs.items():
            if kwarg_arg in kwargs:
                # NB "data" is a string; "json" and "headers" are dicts
                if kwarg_arg == DATA_STRING:
                    # NB
                    kwarg_dict = json.loads(kwargs[DATA_STRING])
                    kwarg_info_str += f'{DATA_STRING}:\n{json.dumps(kwarg_dict, indent=2)}'
                elif kwarg_arg == JSON_STRING or kwarg_arg == HEAD_STRING:
                    kwarg_info_str += f'{kwarg_arg}:\n{json.dumps(value, indent=2)}'
                else:
                    kwarg_info_str += f'{kwarg_arg}:\n|{str(value)}|' 
                """
2026-05-22 NB if the logger's formatters have been configured to truncate (e.g. 1000 characters at the console or
10000 to the file log), then very often this "kwargs info" string will get truncated at the console ... so consult file log         
                """
        if kwarg_info_str != '':
            kwarg_info_str = '- kwargs were:\n' + kwarg_info_str + '\n\n'
        msg = 'do_request(..) error\n- args were:\n'
        if isinstance(e, ValidationError):
            msg += f"""method: {method} type {type(method)}
url: {url} type {type(url)}
base_model_class: {base_model_class} type {type(base_model_class)}\n\n"""
        else:
            # there is no point saying what the types are in this case, as the params passed their validation
            msg += f'method: {method}\nurl: {url}\n\n'
        msg += f'{e}\n\n{exception_response_str}{kwarg_info_str}'
        logger.error(msg, stack_info=True) # show the stack leading UP TO the call to do_request(..)
        return False, e

@validate_call
def inner_do_request(method: str, url: AnyHttpUrl, base_model_class: Optional[Type[BaseModel]], **kwargs):
    VALID_HTTP_METHODS = {GET_STRING, POST_STRING, PUT_STRING, PATCH_STRING, DELETE_STRING, HEAD_STRING, OPTIONS_STRING}
    DEFAULT_TIMEOUT = 60 # 60 seconds
    if method.lower() not in VALID_HTTP_METHODS:
        raise ValueError(f'illegal request method "{method}", must be one of {VALID_HTTP_METHODS}')
    kwargs.setdefault(TIMEOUT_STRING, DEFAULT_TIMEOUT)       
    response = requests.request(method, str(url), **kwargs)
    response.raise_for_status()
    if base_model_class != None:
        try:
            base_model_class.model_validate(response.json())
        except json.JSONDecodeError:
            """
2026-05-22 NB the fact that a base_model_class was supplied as a 3rd parameter must mean that the user
is expecting a Response which can call json() without raising JSONDecodeError ... so such an exception here
represents an error condition            
            """
            raise Exception(f'expected JSON but got (non-JSON) response.text:\n|{response.text}|')
    return True, response


