from setuptools import setup, find_packages

setup(
    name="nubialox",
    version="1.0.0",
    packages=find_packages(),
    description="Nubialox Game Engine 1.00",
    author="Alessandro",
    author_email="",
    url="https://pypi.org/project/nubialox/",
    license="MIT",
    install_requires=[],
    python_requires=">=3.8",
)
