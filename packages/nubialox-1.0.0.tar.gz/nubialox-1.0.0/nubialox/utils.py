def key_pressed(key):
    return False  # placeholder
