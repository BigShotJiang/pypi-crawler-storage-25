import uuid

class Entity:
    def __init__(self, name, x=0, y=0, z=0, data=None):
        self.id = str(uuid.uuid4())
        self.name = name
        self.x = x
        self.y = y
        self.z = z
        self.data = data or {}
