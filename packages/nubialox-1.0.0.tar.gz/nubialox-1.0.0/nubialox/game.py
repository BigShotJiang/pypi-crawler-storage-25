import time
import sys
from .entity import Entity

class Game:
    def __init__(self, name):
        self.name = name
        self.entities = []
        self.running = False

        # Host mode
        self.is_host = "--host" in sys.argv
        self.max_players = 1

        if "--max" in sys.argv:
            try:
                self.max_players = int(sys.argv[sys.argv.index("--max") + 1])
            except:
                pass

        self._start_callback = None
        self._update_callback = None

    def on_start(self, func):
        self._start_callback = func
        return func

    def on_update(self, func):
        self._update_callback = func
        return func

    def create_entity(self, name, x=0, y=0, z=0, data=None):
        e = Entity(name, x, y, z, data)
        self.entities.append(e)
        return e

    def run(self):
        print(f"[NUBIALOX] Avvio gioco: {self.name}")
        self.running = True

        if self._start_callback:
            self._start_callback()

        last = time.time()

        while self.running:
            now = time.time()
            dt = now - last
            last = now

            if self._update_callback:
                self._update_callback(dt)

            time.sleep(0.016)  # ~60 FPS
