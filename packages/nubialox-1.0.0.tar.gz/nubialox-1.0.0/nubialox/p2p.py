import socket
import json
import time
import threading
import uuid

P2P_PORT = 50555
P2P_BUFFER = 8192

class P2P:
    def __init__(self):
        self.peer_id = str(uuid.uuid4())
        self.peers = {}

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind(("0.0.0.0", P2P_PORT))

        threading.Thread(target=self.listen, daemon=True).start()
        threading.Thread(target=self.broadcast, daemon=True).start()

    def broadcast(self):
        while True:
            packet = {"type": "HELLO", "peer_id": self.peer_id}
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            self.sock.sendto(json.dumps(packet).encode(), ("255.255.255.255", P2P_PORT))
            time.sleep(3)

    def listen(self):
        while True:
            try:
                data, addr = self.sock.recvfrom(P2P_BUFFER)
                packet = json.loads(data.decode())
                if packet.get("type") == "HELLO":
                    pid = packet["peer_id"]
                    if pid != self.peer_id:
                        self.peers[pid] = addr[0]
            except:
                pass

    def send(self, peer_id, text):
        if peer_id not in self.peers:
            return
        packet = {"type": "TEXT", "from": self.peer_id, "text": text}
        self.sock.sendto(json.dumps(packet).encode(), (self.peers[peer_id], P2P_PORT))
