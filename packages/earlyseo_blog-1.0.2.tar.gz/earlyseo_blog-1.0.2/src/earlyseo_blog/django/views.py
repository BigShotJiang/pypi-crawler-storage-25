"""
Django views for EarlySEO blog.

Drop-in views for ``/blog/`` listing and ``/blog/<slug>/`` detail pages.

Usage in ``urls.py``::

    from earlyseo_blog.django.views import blog_list, blog_detail

    urlpatterns = [
        path("blog/", blog_list, name="blog_list"),
        path("blog/<slug:slug>/", blog_detail, name="blog_detail"),
    ]
"""

from __future__ import annotations

from html import escape as _esc

from django.conf import settings
from django.http import Http404, HttpRequest, HttpResponse
from django.template.loader import render_to_string, select_template
from django.utils.safestring import mark_safe

from earlyseo_blog.client import EarlySeoClient
from earlyseo_blog.css import ARTICLE_CSS, BLOG_CSS


def _get_site_id() -> str:
    site_id = getattr(settings, "EARLYSEO_SITE_ID", "")
    if not site_id:
        raise ValueError(
            "EARLYSEO_SITE_ID must be set in Django settings"
        )
    return site_id


def _get_client() -> EarlySeoClient:
    cdn = getattr(settings, "EARLYSEO_CDN_BASE_URL", None)
    kwargs = {"site_id": _get_site_id()}
    if cdn:
        kwargs["cdn_base_url"] = cdn
    return EarlySeoClient(**kwargs)


def blog_list(request: HttpRequest) -> HttpResponse:
    """Paginated blog listing view."""
    page = int(request.GET.get("page", "1"))
    if page < 1:
        page = 1

    client = _get_client()
    data = client.get_list_page(page)

    template_names = [
        "earlyseo/blog_list.html",
        "earlyseo_blog/blog_list.html",
    ]

    try:
        template = select_template(template_names)
    except Exception:
        # Fallback: render built-in HTML
        return HttpResponse(_render_list_fallback(data, page))

    context = {
        "page_data": data,
        "articles": data.articles if data else [],
        "current_page": page,
        "total_pages": data.total_pages if data else 0,
        "total_articles": data.total_articles if data else 0,
        "article_css": mark_safe(ARTICLE_CSS),
        "blog_css": mark_safe(BLOG_CSS),
        "has_previous": page > 1,
        "has_next": data and page < data.total_pages,
        "previous_page": page - 1,
        "next_page": page + 1,
    }
    return HttpResponse(template.render(context, request))


def blog_detail(request: HttpRequest, slug: str) -> HttpResponse:
    """Article detail view."""
    client = _get_client()
    article = client.get_article(slug)

    if not article:
        raise Http404("Article not found")

    template_names = [
        "earlyseo/blog_detail.html",
        "earlyseo_blog/blog_detail.html",
    ]

    try:
        template = select_template(template_names)
    except Exception:
        return HttpResponse(_render_detail_fallback(article))

    context = {
        "article": article,
        "article_css": mark_safe(ARTICLE_CSS),
        "blog_css": mark_safe(BLOG_CSS),
        "content_html": mark_safe(article.content_html),
        "content_raw_html": mark_safe(article.content_raw_html),
    }
    return HttpResponse(template.render(context, request))


# ── Fallback HTML renderers (no template needed) ─────────────────────────


def _render_list_fallback(data, page: int) -> str:
    if not data or not data.articles:
        return f"""<!DOCTYPE html>
<html><head><title>Blog</title><style>{BLOG_CSS}</style></head>
<body><div class="earlyseo-blog">
<div class="earlyseo-blog-header"><h1>Blog</h1></div>
<div class="earlyseo-blog-empty">No articles yet. Check back soon!</div>
</div></body></html>"""

    cards = []
    for a in data.articles:
        title = _esc(a.title)
        desc = _esc(a.meta_description)
        alt = _esc(a.image_alt or a.title)
        img = f'<img class="earlyseo-blog-card-image" src="{_esc(a.image_url)}" alt="{alt}" loading="lazy">' if a.image_url else ""
        tags = "".join(f'<span class="earlyseo-blog-tag">{_esc(t)}</span>' for t in a.tags[:3])
        cards.append(f"""<article class="earlyseo-blog-card"><a href="/blog/{_esc(a.slug)}/">
{img}<div class="earlyseo-blog-card-body">
<h2 class="earlyseo-blog-card-title">{title}</h2>
<p class="earlyseo-blog-card-desc">{desc}</p>
<div class="earlyseo-blog-card-meta"><time>{_esc(a.created_at[:10])}</time>{tags}</div>
</div></a></article>""")

    prev_btn = f'<a href="?page={page - 1}"><button>&larr; Previous</button></a>' if page > 1 else '<button disabled>&larr; Previous</button>'
    next_btn = f'<a href="?page={page + 1}"><button>Next &rarr;</button></a>' if page < data.total_pages else '<button disabled>Next &rarr;</button>'
    pagination = f'<div class="earlyseo-blog-pagination">{prev_btn}<span>Page {page} of {data.total_pages}</span>{next_btn}</div>' if data.total_pages > 1 else ""

    return f"""<!DOCTYPE html>
<html><head><title>Blog</title><style>{ARTICLE_CSS}\n{BLOG_CSS}</style></head>
<body><div class="earlyseo-blog">
<div class="earlyseo-blog-header"><h1>Blog</h1>
<p style="opacity:0.6;font-size:0.9rem">{data.total_articles} article{'s' if data.total_articles != 1 else ''}</p></div>
<div class="earlyseo-blog-grid">{"".join(cards)}</div>
{pagination}</div></body></html>"""


def _render_detail_fallback(article) -> str:
    title = _esc(article.title)
    desc = _esc(article.meta_description)
    alt = _esc(article.image_alt or article.title)
    img = f'<img class="earlyseo-blog-post-image" src="{_esc(article.image_url)}" alt="{alt}">' if article.image_url else ""
    tags = "".join(f'<span class="earlyseo-blog-tag">{_esc(t)}</span>' for t in article.tags)

    return f"""<!DOCTYPE html>
<html><head>
<title>{title}</title>
<meta name="description" content="{desc}">
<style>{ARTICLE_CSS}\n{BLOG_CSS}</style>
</head><body>
<div class="earlyseo-blog-post">
<nav style="margin-bottom:1.5rem"><a href="/blog/" style="font-size:0.9rem;opacity:0.6">&larr; Go back</a></nav>
<header class="earlyseo-blog-post-header">
<h1>{title}</h1>
<div class="earlyseo-blog-post-meta"><time>{_esc(article.created_at[:10])}</time>{tags}</div>
</header>
{img}
{article.content_html}
</div></body></html>"""
