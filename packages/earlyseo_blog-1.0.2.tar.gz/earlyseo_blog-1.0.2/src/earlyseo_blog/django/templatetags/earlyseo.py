"""
Django template tags for EarlySEO.

Usage in templates::

    {% load earlyseo %}

    {% earlyseo_styles %}
    {% earlyseo_article article %}
"""

from django import template
from django.utils.safestring import mark_safe

from earlyseo_blog.css import ARTICLE_CSS, BLOG_CSS

register = template.Library()


@register.simple_tag
def earlyseo_styles():
    """Render a ``<style>`` tag with article + blog CSS."""
    return mark_safe(f"<style>{ARTICLE_CSS}\n{BLOG_CSS}</style>")


@register.simple_tag
def earlyseo_article_css():
    """Render a ``<style>`` tag with article CSS only."""
    return mark_safe(f"<style>{ARTICLE_CSS}</style>")


@register.simple_tag
def earlyseo_article(article, mode="styled"):
    """
    Render an article's HTML content.

    Args:
        article: An ``Article`` model instance.
        mode: ``"styled"`` (default) or ``"raw"``.
    """
    html = article.content_html if mode == "styled" else article.content_raw_html
    return mark_safe(html)
