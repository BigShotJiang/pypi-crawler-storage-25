"""
Django URL patterns for EarlySEO blog.

Include in your root ``urls.py``::

    from django.urls import path, include

    urlpatterns = [
        path("blog/", include("earlyseo_blog.django.urls")),
    ]
"""

from django.urls import path

from earlyseo_blog.django.views import blog_detail, blog_list

app_name = "earlyseo_blog"

urlpatterns = [
    path("", blog_list, name="blog_list"),
    path("<slug:slug>/", blog_detail, name="blog_detail"),
]
