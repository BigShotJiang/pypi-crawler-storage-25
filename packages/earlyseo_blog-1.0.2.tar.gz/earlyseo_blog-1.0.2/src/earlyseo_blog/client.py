"""
Thin read-only client that fetches pre-built article data from EarlySEO.

Supports both synchronous and asynchronous usage via ``httpx``.
"""

from __future__ import annotations

import re
from typing import Optional, TypeVar

import httpx

from earlyseo_blog.models import Article, ArticleListPage, Manifest

DEFAULT_CDN_BASE_URL = "https://media.earlyseo.com"

_SAFE_SLUG_RE = re.compile(r"[^a-zA-Z0-9_-]")

T = TypeVar("T")


class EarlySeoClient:
    """Synchronous CDN client for EarlySEO blog content."""

    def __init__(
        self,
        site_id: str,
        *,
        cdn_base_url: str = DEFAULT_CDN_BASE_URL,
        timeout: float = 10.0,
    ) -> None:
        self.site_id = site_id
        self._base_url = cdn_base_url.rstrip("/")
        self._client = httpx.Client(
            timeout=timeout,
            headers={"Accept": "application/json"},
        )

    # ── URL builders ──────────────────────────────────────────────────────

    def manifest_url(self) -> str:
        return f"{self._base_url}/site/{self.site_id}/manifest.json"

    def list_page_url(self, page: int) -> str:
        return f"{self._base_url}/site/{self.site_id}/articles/page-{page}.json"

    def article_url(self, slug: str) -> str:
        safe = _SAFE_SLUG_RE.sub("-", slug)
        return f"{self._base_url}/site/{self.site_id}/article/{safe}.json"

    # ── Data fetchers ─────────────────────────────────────────────────────

    def get_manifest(self) -> Optional[Manifest]:
        """Fetch the site manifest. Returns ``None`` on 404."""
        data = self._fetch_json(self.manifest_url())
        return Manifest.model_validate(data) if data is not None else None

    def get_list_page(self, page: int) -> Optional[ArticleListPage]:
        """Fetch a paginated article list page (1-indexed). Returns ``None`` on 404."""
        if page < 1:
            return None
        data = self._fetch_json(self.list_page_url(page))
        return ArticleListPage.model_validate(data) if data is not None else None

    def get_article(self, slug: str) -> Optional[Article]:
        """Fetch a single article by slug. Returns ``None`` on 404."""
        data = self._fetch_json(self.article_url(slug))
        return Article.model_validate(data) if data is not None else None

    # ── Internal ──────────────────────────────────────────────────────────

    def _fetch_json(self, url: str) -> Optional[dict]:
        resp = self._client.get(url)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "EarlySeoClient":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncEarlySeoClient:
    """Asynchronous CDN client for EarlySEO blog content."""

    def __init__(
        self,
        site_id: str,
        *,
        cdn_base_url: str = DEFAULT_CDN_BASE_URL,
        timeout: float = 10.0,
    ) -> None:
        self.site_id = site_id
        self._base_url = cdn_base_url.rstrip("/")
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers={"Accept": "application/json"},
        )

    # ── URL builders ──────────────────────────────────────────────────────

    def manifest_url(self) -> str:
        return f"{self._base_url}/site/{self.site_id}/manifest.json"

    def list_page_url(self, page: int) -> str:
        return f"{self._base_url}/site/{self.site_id}/articles/page-{page}.json"

    def article_url(self, slug: str) -> str:
        safe = _SAFE_SLUG_RE.sub("-", slug)
        return f"{self._base_url}/site/{self.site_id}/article/{safe}.json"

    # ── Data fetchers ─────────────────────────────────────────────────────

    async def get_manifest(self) -> Optional[Manifest]:
        data = await self._fetch_json(self.manifest_url())
        return Manifest.model_validate(data) if data is not None else None

    async def get_list_page(self, page: int) -> Optional[ArticleListPage]:
        if page < 1:
            return None
        data = await self._fetch_json(self.list_page_url(page))
        return ArticleListPage.model_validate(data) if data is not None else None

    async def get_article(self, slug: str) -> Optional[Article]:
        data = await self._fetch_json(self.article_url(slug))
        return Article.model_validate(data) if data is not None else None

    # ── Internal ──────────────────────────────────────────────────────────

    async def _fetch_json(self, url: str) -> Optional[dict]:
        resp = await self._client.get(url)
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncEarlySeoClient":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
