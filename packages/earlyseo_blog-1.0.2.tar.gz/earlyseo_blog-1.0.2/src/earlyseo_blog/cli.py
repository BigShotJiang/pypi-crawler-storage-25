"""
CLI for scaffolding EarlySEO blog integration into Django / Flask projects.

Entry-point: ``earlyseo-blog`` (defined in pyproject.toml).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

# ── helpers ───────────────────────────────────────────────────────────────────

cwd = Path.cwd()


def _ask(question: str) -> str:
    try:
        return input(question).strip()
    except (EOFError, KeyboardInterrupt):
        print()
        sys.exit(1)


def _write_safe(rel_path: str, content: str) -> bool:
    full = cwd / rel_path
    if full.exists():
        answer = _ask(f"  ⚠  {rel_path} already exists. Overwrite? (y/N) ")
        if answer.lower() != "y":
            print(f"  ⏭  Skipped {rel_path}")
            return False
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_text(content, encoding="utf-8")
    print(f"  ✅ Created {rel_path}")
    return True


# ── detection ─────────────────────────────────────────────────────────────────


def _is_django() -> bool:
    return (cwd / "manage.py").exists()


def _is_flask() -> bool:
    return (cwd / "app.py").exists() or (cwd / "wsgi.py").exists()


# ── Django templates ──────────────────────────────────────────────────────────


_DJANGO_URLS_SNIPPET = """\
# blog/urls.py  — EarlySEO blog routes
from earlyseo_blog.django.urls import urlpatterns as earlyseo_urls  # noqa: F401

# Add to your root urls.py:
#   path("blog/", include("earlyseo_blog.django.urls")),
"""

_DJANGO_SETTINGS_SNIPPET = """\
# Add to INSTALLED_APPS in settings.py:
#   "earlyseo_blog.django",
#
# Add to settings.py:
#   EARLYSEO_SITE_ID = "{site_id}"
"""

_DJANGO_TEMPLATE_LIST = """\
{{% extends "base.html" %}}
{{% load earlyseo %}}

{{% block extra_head %}}{{% earlyseo_styles %}}{{% endblock %}}

{{% block content %}}
<div class="earlyseo-blog">
  <div class="earlyseo-blog-header"><h1>Blog</h1></div>
  <div class="earlyseo-blog-grid">
    {{% for article in articles %}}
    <article class="earlyseo-blog-card">
      <a href="{{% url 'earlyseo_blog:blog_detail' slug=article.slug %}}">
        {{% if article.image_url %}}
        <img class="earlyseo-blog-card-image" src="{{{{ article.image_url }}}}"
             alt="{{{{ article.image_alt|default:article.title }}}}" loading="lazy">
        {{% endif %}}
        <div class="earlyseo-blog-card-body">
          <h2 class="earlyseo-blog-card-title">{{{{ article.title }}}}</h2>
          <p class="earlyseo-blog-card-desc">{{{{ article.meta_description }}}}</p>
        </div>
      </a>
    </article>
    {{% endfor %}}
  </div>
</div>
{{% endblock %}}
"""

_DJANGO_TEMPLATE_DETAIL = """\
{{% extends "base.html" %}}
{{% load earlyseo %}}

{{% block extra_head %}}{{% earlyseo_styles %}}{{% endblock %}}

{{% block content %}}
<div class="earlyseo-blog-post">
  <nav style="margin-bottom:1.5rem">
    <a href="{{% url 'earlyseo_blog:blog_list' %}}" style="font-size:0.9rem;opacity:0.6">&larr; Go back</a>
  </nav>
  {{% earlyseo_article article %}}
</div>
{{% endblock %}}
"""


# ── Flask templates ───────────────────────────────────────────────────────────


_FLASK_APP_SNIPPET = """\
# Add to your Flask app:
#
#   from earlyseo_blog.flask.views import create_blog_blueprint
#   app.config["EARLYSEO_SITE_ID"] = "{site_id}"
#   app.register_blueprint(create_blog_blueprint(), url_prefix="/blog")
"""

_FLASK_TEMPLATE_LIST = """\
{% extends "base.html" %}

{% block head %}
<style>{{ article_css }}
{{ blog_css }}</style>
{% endblock %}

{% block content %}
<div class="earlyseo-blog">
  <div class="earlyseo-blog-header"><h1>Blog</h1></div>
  <div class="earlyseo-blog-grid">
    {% for a in articles %}
    <article class="earlyseo-blog-card">
      <a href="{{ url_for('.blog_detail', slug=a.slug) }}">
        {% if a.image_url %}
        <img class="earlyseo-blog-card-image" src="{{ a.image_url }}"
             alt="{{ a.image_alt or a.title }}" loading="lazy">
        {% endif %}
        <div class="earlyseo-blog-card-body">
          <h2 class="earlyseo-blog-card-title">{{ a.title }}</h2>
          <p class="earlyseo-blog-card-desc">{{ a.meta_description }}</p>
        </div>
      </a>
    </article>
    {% endfor %}
  </div>
</div>
{% endblock %}
"""

_FLASK_TEMPLATE_DETAIL = """\
{% extends "base.html" %}

{% block head %}
<style>{{ article_css }}
{{ blog_css }}</style>
{% endblock %}

{% block content %}
<div class="earlyseo-blog-post">
  <nav style="margin-bottom:1.5rem">
    <a href="{{ url_for('.blog_list') }}" style="font-size:0.9rem;opacity:0.6">&larr; Go back</a>
  </nav>
  <header class="earlyseo-blog-post-header">
    <h1>{{ article.title }}</h1>
  </header>
  {% if article.image_url %}
  <img class="earlyseo-blog-post-image" src="{{ article.image_url }}"
       alt="{{ article.image_alt or article.title }}">
  {% endif %}
  {{ content_html }}
</div>
{% endblock %}
"""


# ── env file helper ──────────────────────────────────────────────────────────


def _write_env(site_id: str) -> None:
    env_path = cwd / ".env"
    key = "EARLYSEO_SITE_ID"
    if env_path.exists():
        text = env_path.read_text(encoding="utf-8")
        if key in text:
            print(f"  ⏭  Skipped .env ({key} already set)")
            return
        with open(env_path, "a", encoding="utf-8") as f:
            f.write(f"\n# EarlySEO Blog SDK\n{key}={site_id}\n")
        print(f"  ✅ Added {key} to .env")
    else:
        env_path.write_text(
            f"# EarlySEO Blog SDK\n{key}={site_id}\n", encoding="utf-8"
        )
        print("  ✅ Created .env")


# ── scaffolders ──────────────────────────────────────────────────────────────


def _scaffold_django(site_id: str) -> None:
    print("  ✓ Django project detected (manage.py)")
    print()

    _write_safe("earlyseo_setup.txt", _DJANGO_SETTINGS_SNIPPET.format(site_id=site_id))
    _write_safe(
        "templates/earlyseo/blog_list.html",
        _DJANGO_TEMPLATE_LIST.format(site_id=site_id),
    )
    _write_safe(
        "templates/earlyseo/blog_detail.html",
        _DJANGO_TEMPLATE_DETAIL.format(site_id=site_id),
    )
    _write_env(site_id)


def _scaffold_flask(site_id: str) -> None:
    print("  ✓ Flask project detected")
    print()

    _write_safe("earlyseo_setup.txt", _FLASK_APP_SNIPPET.format(site_id=site_id))
    _write_safe(
        "templates/earlyseo/blog_list.html",
        _FLASK_TEMPLATE_LIST,
    )
    _write_safe(
        "templates/earlyseo/blog_detail.html",
        _FLASK_TEMPLATE_DETAIL,
    )
    _write_env(site_id)


# ── main ─────────────────────────────────────────────────────────────────────


def main() -> None:
    print()
    print("  earlyseo-blog — Blog Setup")
    print("  ──────────────────────────")
    print()

    is_django = _is_django()
    is_flask = _is_flask()

    if not is_django and not is_flask:
        print("  ❌ Could not detect a Django or Flask project.")
        print("     (Looked for manage.py, app.py, or wsgi.py)")
        print()
        print("  Run this command from the root of your Python web project.")
        print()
        print("  Docs: https://app.earlyseo.com/docs/python-sdk")
        print()
        sys.exit(1)

    # Ask for site ID
    site_id = os.environ.get("EARLYSEO_SITE_ID", "")
    if site_id:
        print(f"  ✓ Found EARLYSEO_SITE_ID from environment: {site_id}")
    else:
        site_id = _ask("  Enter your EarlySEO Site ID: ")
        if not site_id:
            print(
                "  ❌ Site ID is required. "
                "Find it in your EarlySEO dashboard → Integrations → SDK."
            )
            print()
            sys.exit(1)
    print()

    if is_django:
        _scaffold_django(site_id)
    else:
        _scaffold_flask(site_id)

    print()
    print("  ✓ Setup complete! Your blog is ready at /blog")
    print()
    if is_django:
        print("  Next steps:")
        print('    1. Add "earlyseo_blog.django" to INSTALLED_APPS')
        print(f'    2. Add EARLYSEO_SITE_ID = "{site_id}" to settings.py')
        print('    3. Include URLs: path("blog/", include("earlyseo_blog.django.urls"))')
        print("    4. Run: python manage.py runserver")
        print("    5. Visit: http://localhost:8000/blog")
    else:
        print("  Next steps:")
        print("    1. Register the blueprint in your Flask app (see earlyseo_setup.txt)")
        print("    2. Run your Flask dev server")
        print("    3. Visit: http://localhost:5000/blog")
    print()
    print("  Docs: https://app.earlyseo.com/docs/python-sdk")
    print()


if __name__ == "__main__":
    main()
