"""
Flask blueprint for EarlySEO blog.

Usage::

    from flask import Flask
    from earlyseo_blog.flask.views import create_blog_blueprint

    app = Flask(__name__)
    app.config["EARLYSEO_SITE_ID"] = "your-site-id"

    blog_bp = create_blog_blueprint()
    app.register_blueprint(blog_bp, url_prefix="/blog")
"""

from __future__ import annotations

from flask import Blueprint, abort, current_app, render_template, render_template_string, request
from jinja2 import TemplateNotFound
from markupsafe import Markup

from earlyseo_blog.client import EarlySeoClient
from earlyseo_blog.css import ARTICLE_CSS, BLOG_CSS


def _get_client() -> EarlySeoClient:
    site_id = current_app.config.get("EARLYSEO_SITE_ID", "")
    if not site_id:
        raise ValueError("EARLYSEO_SITE_ID must be set in Flask app config")
    cdn = current_app.config.get("EARLYSEO_CDN_BASE_URL")
    kwargs = {"site_id": site_id}
    if cdn:
        kwargs["cdn_base_url"] = cdn
    return EarlySeoClient(**kwargs)


# ── Jinja2 fallback templates ────────────────────────────────────────────

_LIST_TEMPLATE = """\
<!DOCTYPE html>
<html><head><title>Blog</title><style>{{ article_css }}
{{ blog_css }}</style></head>
<body><div class="earlyseo-blog">
<div class="earlyseo-blog-header"><h1>Blog</h1>
{% if total_articles %}<p style="opacity:0.6;font-size:0.9rem">{{ total_articles }} article{{ 's' if total_articles != 1 else '' }}</p>{% endif %}
</div>
{% if articles %}
<div class="earlyseo-blog-grid">
{% for a in articles %}
<article class="earlyseo-blog-card"><a href="{{ url_for('.blog_detail', slug=a.slug) }}">
{% if a.image_url %}<img class="earlyseo-blog-card-image" src="{{ a.image_url }}" alt="{{ a.image_alt or a.title }}" loading="lazy">{% endif %}
<div class="earlyseo-blog-card-body">
<h2 class="earlyseo-blog-card-title">{{ a.title }}</h2>
<p class="earlyseo-blog-card-desc">{{ a.meta_description }}</p>
<div class="earlyseo-blog-card-meta"><time>{{ a.created_at[:10] }}</time>
{% for tag in a.tags[:3] %}<span class="earlyseo-blog-tag">{{ tag }}</span>{% endfor %}
</div></div></a></article>
{% endfor %}
</div>
{% if total_pages > 1 %}
<div class="earlyseo-blog-pagination">
{% if has_previous %}<a href="?page={{ previous_page }}"><button>&larr; Previous</button></a>{% else %}<button disabled>&larr; Previous</button>{% endif %}
<span style="padding:0.5rem 0.75rem;font-size:0.85rem;opacity:0.6">Page {{ current_page }} of {{ total_pages }}</span>
{% if has_next %}<a href="?page={{ next_page }}"><button>Next &rarr;</button></a>{% else %}<button disabled>Next &rarr;</button>{% endif %}
</div>
{% endif %}
{% else %}
<div class="earlyseo-blog-empty">No articles yet. Check back soon!</div>
{% endif %}
</div></body></html>
"""

_DETAIL_TEMPLATE = """\
<!DOCTYPE html>
<html><head>
<title>{{ article.title }}</title>
<meta name="description" content="{{ article.meta_description }}">
<style>{{ article_css }}
{{ blog_css }}</style>
</head><body>
<div class="earlyseo-blog-post">
<nav style="margin-bottom:1.5rem"><a href="{{ url_for('.blog_list') }}" style="font-size:0.9rem;opacity:0.6">&larr; Go back</a></nav>
<header class="earlyseo-blog-post-header">
<h1>{{ article.title }}</h1>
<div class="earlyseo-blog-post-meta"><time>{{ article.created_at[:10] }}</time>
{% for tag in article.tags %}<span class="earlyseo-blog-tag">{{ tag }}</span>{% endfor %}
</div></header>
{% if article.image_url %}<img class="earlyseo-blog-post-image" src="{{ article.image_url }}" alt="{{ article.image_alt or article.title }}">{% endif %}
{{ content_html }}
</div></body></html>
"""


def create_blog_blueprint(
    name: str = "earlyseo_blog",
    template_folder: str | None = None,
) -> Blueprint:
    """
    Create a Flask Blueprint with /blog list and /blog/<slug> detail routes.

    Override templates by placing ``earlyseo/blog_list.html`` and
    ``earlyseo/blog_detail.html`` in your app's templates folder.
    """
    bp = Blueprint(
        name,
        __name__,
        template_folder=template_folder,
    )

    @bp.route("/")
    def blog_list():
        page = int(request.args.get("page", 1))
        if page < 1:
            page = 1

        client = _get_client()
        data = client.get_list_page(page)

        ctx = {
            "page_data": data,
            "articles": data.articles if data else [],
            "current_page": page,
            "total_pages": data.total_pages if data else 0,
            "total_articles": data.total_articles if data else 0,
            "article_css": Markup(ARTICLE_CSS),
            "blog_css": Markup(BLOG_CSS),
            "has_previous": page > 1,
            "has_next": data is not None and page < data.total_pages,
            "previous_page": page - 1,
            "next_page": page + 1,
        }

        try:
            return render_template("earlyseo/blog_list.html", **ctx)
        except TemplateNotFound:
            return render_template_string(_LIST_TEMPLATE, **ctx)

    @bp.route("/<slug>/")
    def blog_detail(slug: str):
        client = _get_client()
        article = client.get_article(slug)
        if not article:
            abort(404)

        ctx = {
            "article": article,
            "article_css": Markup(ARTICLE_CSS),
            "blog_css": Markup(BLOG_CSS),
            "content_html": Markup(article.content_html),
        }

        try:
            return render_template("earlyseo/blog_detail.html", **ctx)
        except TemplateNotFound:
            return render_template_string(_DETAIL_TEMPLATE, **ctx)

    return bp
