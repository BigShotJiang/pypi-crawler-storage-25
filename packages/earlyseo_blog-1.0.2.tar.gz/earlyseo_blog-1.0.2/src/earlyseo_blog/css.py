"""
CSS constants for EarlySEO article styling.

These mirror the JavaScript ``@earlyseo/blog/css`` exports exactly,
so articles render identically in Python-powered templates.
"""

ARTICLE_CSS = """\
.earlyseo-article {
  color: var(--earlyseo-text-color, inherit);
  font-size: 16px;
  line-height: 1.75;
  word-wrap: break-word;
  font-family: var(--earlyseo-font-family, inherit);
}
.earlyseo-article > :first-child { margin-top: 0; }
.earlyseo-article > :last-child { margin-bottom: 0; }
.earlyseo-article h1,.earlyseo-article h2,.earlyseo-article h3,.earlyseo-article h4,.earlyseo-article h5,.earlyseo-article h6 {
  margin-top: 1.6em; margin-bottom: 0.6em; font-weight: 700; line-height: 1.3;
  color: var(--earlyseo-heading-color, inherit);
}
.earlyseo-article h1 { font-size: 2rem; }
.earlyseo-article h2 { font-size: 1.5rem; padding-bottom: 0.25rem; border-bottom: 1px solid var(--earlyseo-border-color, rgba(128,128,128,0.2)); }
.earlyseo-article h3 { font-size: 1.25rem; }
.earlyseo-article h4 { font-size: 1.05rem; }
.earlyseo-article p,.earlyseo-article ul,.earlyseo-article ol,.earlyseo-article dl,.earlyseo-article table,.earlyseo-article blockquote,.earlyseo-article pre,.earlyseo-article figure {
  margin-top: 0; margin-bottom: 1rem;
}
.earlyseo-article a { color: var(--earlyseo-link-color, inherit); text-decoration: underline; text-underline-offset: 2px; }
.earlyseo-article a:hover { text-decoration-thickness: 2px; }
.earlyseo-article ul,.earlyseo-article ol { padding-left: 1.5rem; }
.earlyseo-article li + li { margin-top: 0.3rem; }
.earlyseo-article li > p { margin-bottom: 0.4rem; }
.earlyseo-article blockquote { margin-left: 0; padding: 0.25rem 1rem; color: var(--earlyseo-muted-color, inherit); opacity: 0.75; border-left: 4px solid var(--earlyseo-border-color, rgba(128,128,128,0.2)); }
.earlyseo-article blockquote > * { opacity: 1; }
.earlyseo-article code { padding: 0.12rem 0.35rem; border-radius: 0.375rem; background: var(--earlyseo-code-bg, rgba(128,128,128,0.1)); font-size: 0.88em; font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace; }
.earlyseo-article pre { overflow: auto; padding: 1rem; border-radius: 0.75rem; background: var(--earlyseo-pre-bg, rgba(128,128,128,0.06)); border: 1px solid var(--earlyseo-border-color, rgba(128,128,128,0.2)); }
.earlyseo-article pre code { background: transparent; padding: 0; border-radius: 0; font-size: 0.9em; line-height: 1.55; }
.earlyseo-article table { display: table; width: 100%; overflow-x: auto; border-collapse: collapse; }
.earlyseo-article th,.earlyseo-article td { padding: 0.55rem 0.75rem; border: 1px solid var(--earlyseo-border-color, rgba(128,128,128,0.2)); text-align: left; }
.earlyseo-article th { font-weight: 600; background: var(--earlyseo-th-bg, rgba(128,128,128,0.1)); }
.earlyseo-article img { max-width: 100%; height: auto; border-radius: 0.75rem; }
.earlyseo-article hr { margin: 1.5rem 0; border: 0; border-top: 1px solid var(--earlyseo-border-color, rgba(128,128,128,0.2)); }
.earlyseo-article .task-list-item { list-style: none; }
.earlyseo-article input[type="checkbox"] { margin-right: 0.45rem; }"""

BLOG_CSS = """\
.earlyseo-blog {
  max-width: var(--earlyseo-blog-max-width, 72rem);
  margin: 0 auto;
  padding: var(--earlyseo-blog-padding, 2rem 1rem);
  font-family: var(--earlyseo-font-family, inherit);
  color: var(--earlyseo-text-color, inherit);
}
.earlyseo-blog-header { margin-bottom: 2rem; }
.earlyseo-blog-header h1 { font-size: 2rem; font-weight: 700; margin: 0 0 0.5rem; }
.earlyseo-blog-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(min(100%, 320px), 1fr));
  gap: 2rem;
}
.earlyseo-blog-card {
  display: flex; flex-direction: column; border-radius: 0.75rem; overflow: hidden;
  border: 1px solid var(--earlyseo-border-color, rgba(128,128,128,0.2));
  transition: box-shadow 0.15s;
}
.earlyseo-blog-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
.earlyseo-blog-card a { text-decoration: none; color: inherit; display: flex; flex-direction: column; height: 100%; }
.earlyseo-blog-card-image { width: 100%; aspect-ratio: 16/9; object-fit: cover; }
.earlyseo-blog-card-body { padding: 1rem 1.25rem; flex: 1; display: flex; flex-direction: column; }
.earlyseo-blog-card-title { font-size: 1.15rem; font-weight: 600; margin: 0 0 0.5rem; line-height: 1.3; }
.earlyseo-blog-card-desc {
  font-size: 0.9rem; opacity: 0.7; margin: 0 0 0.75rem; flex: 1;
  display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;
}
.earlyseo-blog-card-meta { display: flex; gap: 0.5rem; flex-wrap: wrap; font-size: 0.8rem; opacity: 0.5; }
.earlyseo-blog-tag { display: inline-block; padding: 0.15rem 0.5rem; border-radius: 9999px; background: var(--earlyseo-tag-bg, rgba(128,128,128,0.1)); font-size: 0.75rem; }
.earlyseo-blog-post {
  max-width: var(--earlyseo-post-max-width, 48rem);
  margin: 0 auto;
  padding: var(--earlyseo-blog-padding, 2rem 1rem);
}
.earlyseo-blog-post-header { margin-bottom: 2rem; }
.earlyseo-blog-post-header h1 { font-size: 2.25rem; font-weight: 700; margin: 0 0 0.75rem; line-height: 1.2; }
.earlyseo-blog-post-meta { display: flex; gap: 1rem; flex-wrap: wrap; font-size: 0.85rem; opacity: 0.6; }
.earlyseo-blog-post-image { width: 100%; border-radius: 0.75rem; margin-bottom: 2rem; }
.earlyseo-blog-empty { text-align: center; padding: 4rem 1rem; opacity: 0.5; }
.earlyseo-blog-pagination { display: flex; justify-content: center; gap: 0.5rem; margin-top: 2rem; }
.earlyseo-blog-pagination button {
  padding: 0.5rem 1rem; border: 1px solid var(--earlyseo-border-color, rgba(128,128,128,0.2));
  border-radius: 0.375rem; background: transparent; cursor: pointer; font-size: 0.85rem;
}
.earlyseo-blog-pagination button:disabled { opacity: 0.3; cursor: not-allowed; }"""
