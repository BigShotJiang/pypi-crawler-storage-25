"""Pydantic models for EarlySEO CDN JSON schemas."""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class Manifest(BaseModel):
    """Top-level manifest at ``/site/{siteId}/manifest.json``."""

    schema_version: int = Field(alias="schemaVersion", default=1)
    version: int
    total_articles: int = Field(alias="totalArticles")
    total_pages: int = Field(alias="totalPages")
    page_size: int = Field(alias="pageSize")
    updated_at: str = Field(alias="updatedAt")
    featured_slugs: List[str] = Field(alias="featuredSlugs", default_factory=list)

    model_config = {"populate_by_name": True}


class ArticleListItem(BaseModel):
    """A single article entry in a paginated list page."""

    title: str
    slug: str
    image_url: Optional[str] = Field(alias="imageUrl", default=None)
    image_alt: Optional[str] = Field(alias="imageAlt", default=None)
    meta_description: str = Field(alias="metaDescription")
    created_at: str = Field(alias="createdAt")
    tags: List[str] = Field(default_factory=list)

    model_config = {"populate_by_name": True}


class ArticleListPage(BaseModel):
    """Paginated list page at ``/site/{siteId}/articles/page-{n}.json``."""

    page: int
    total_pages: int = Field(alias="totalPages")
    total_articles: int = Field(alias="totalArticles")
    version: int
    articles: List[ArticleListItem]

    model_config = {"populate_by_name": True}


class Article(BaseModel):
    """Full article JSON at ``/site/{siteId}/article/{slug}.json``."""

    id: str
    title: str
    slug: str
    content_html: str = Field(alias="contentHtml")
    content_raw_html: str = Field(alias="contentRawHtml")
    content_css: str = Field(alias="contentCss")
    meta_description: str = Field(alias="metaDescription")
    created_at: str = Field(alias="createdAt")
    updated_at: str = Field(alias="updatedAt")
    image_url: Optional[str] = Field(alias="imageUrl", default=None)
    image_alt: Optional[str] = Field(alias="imageAlt", default=None)
    tags: List[str] = Field(default_factory=list)
    summary: Optional[str] = None
    canonical_url: Optional[str] = Field(alias="canonicalUrl", default=None)
    version: int

    model_config = {"populate_by_name": True}
