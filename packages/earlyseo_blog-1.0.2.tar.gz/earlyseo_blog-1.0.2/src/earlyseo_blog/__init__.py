"""
earlyseo-blog — Drop-in blog integration for Python web frameworks.

Articles are served from the EarlySEO CDN. No database, no webhooks,
no storage config — just add your site ID and go.
"""

from earlyseo_blog.models import (
    Manifest,
    ArticleListItem,
    ArticleListPage,
    Article,
)
from earlyseo_blog.client import AsyncEarlySeoClient, EarlySeoClient
from earlyseo_blog.css import ARTICLE_CSS, BLOG_CSS

__version__ = "1.0.0"
__all__ = [
    "EarlySeoClient",
    "AsyncEarlySeoClient",
    "Manifest",
    "ArticleListItem",
    "ArticleListPage",
    "Article",
    "ARTICLE_CSS",
    "BLOG_CSS",
]
