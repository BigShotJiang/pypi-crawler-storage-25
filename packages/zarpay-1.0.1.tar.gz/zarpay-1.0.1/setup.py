from setuptools import setup, find_packages

setup(
    name="zarpay",
    version="1.0.1",
    description="Official Python SDK for the ZarPay payment gateway",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="ZarPay",
    author_email="support@zarpay.pk",
    url="https://github.com/zarpay/zarpay-python",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=["requests>=2.20.0"],
    keywords=["zarpay", "payments", "jazzcash", "easypaisa", "pakistan"],
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
