# ZarPay Python SDK

Official Python SDK for the [ZarPay](https://zarpay.pk) payment gateway.

## Installation

```bash
pip install zarpay
```

## Quick Start

```python
from zarpay import ZarPay

client = ZarPay("sk_sandbox_xxxxxxxxxxxxx")

payment = client.payments.create(
    merchant_order_id="ORD-123",
    amount=1500,
    channel_id=1,
    customer_phone="03001234567",
)

print(payment["data"]["status"])  # 'completed' | 'processing' | 'failed'
```

## Usage

### List Available Channels

```python
channels = client.channels.list()

for ch in channels["data"]["channels"]:
    print(f"{ch['id']}: {ch['wallet_type']}")
```

### Create a Payment

```python
payment = client.payments.create(
    merchant_order_id="ORD-456",
    amount=2500,
    channel_id=1,
    customer_phone="03001234567",
    metadata={"customer_name": "Ahmed Khan"},
    idempotency_key="unique-key-456",
)

if payment["success"]:
    print("Payment completed:", payment["data"]["zarpay_id"])
else:
    print("Payment failed:", payment["data"]["failure_reason"])
```

### Get Payment Status

```python
# By ZarPay ID
payment = client.payments.get("ZP_abc123def456")

# By your order ID
payment = client.payments.get_by_order_id("ORD-456")
```

### Verify Webhooks

```python
from zarpay import verify_webhook

# In your webhook handler (e.g. Flask/Django)
def webhook_handler(request):
    try:
        event = verify_webhook(
            raw_body=request.body,
            signature_header=request.headers["X-ZarPay-Signature"],
            secret="whsec_your_webhook_secret",
        )

        if event["event"] == "payment.completed":
            # Fulfill the order
            pass
        elif event["event"] == "payment.failed":
            # Notify customer
            pass

        return HttpResponse(status=200)
    except ValueError:
        return HttpResponse(status=400)
```

### Error Handling

```python
from zarpay import ZarPay, ZarPayAPIError

try:
    payment = client.payments.create(...)
except ZarPayAPIError as e:
    print(e.status_code)  # 400, 401, 409, etc.
    print(e.error)        # Human-readable error message
```

### Configuration

```python
client = ZarPay(
    "sk_sandbox_xxx",
    base_url="http://localhost:3000/api/v1",  # local development
    timeout=60,                                # seconds
)
```

## License

MIT
