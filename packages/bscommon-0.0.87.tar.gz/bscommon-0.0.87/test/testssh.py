import os
import sys
scriptDir = os.path.dirname(__file__)+os.sep
rootDir=scriptDir+".."+os.sep
sys.path.append(rootDir)
from src.bscommon import Com
from src.bscommon import Ssh
from src.bscommon import SysTask
sys.path.remove(rootDir)


def RunAction(ssh,config,args):
    print("ssh连接成功")
    ssh.run("set -euo pipefail")
    ssh.run("ls -l /bs/nginx/1")
    print(ssh.exist("/bs/nginx"))

Ssh.RunAction(RunAction,scriptDir,"host")

