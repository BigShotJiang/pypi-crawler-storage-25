# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

import io
from abc import ABC, abstractmethod
from collections import defaultdict
from typing import Dict, List, Literal, Mapping, Optional, Sequence, Tuple, Union

import ipyvuetify as v
import ipywidgets as w
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pandas.api.types import is_datetime64_any_dtype, is_numeric_dtype

from cobalt.cobalt_types import ColumnDataType, GroupType
from cobalt.coloring.color_range import ColorRange
from cobalt.coloring.color_spec import (
    CategoricalColoringSpec,
    ColorMapOptions,
    GraphColoringSpec,
    NoColoringSpec,
    NodeSizeColoringSpec,
    NumericColoringSpec,
    TimestampColoringSpec,
)
from cobalt.coloring.histogram_dialog import HistogramDialog
from cobalt.config import handle_cb_exceptions
from cobalt.repositories.run_repository import GroupResultsCollection
from cobalt.schema.dataset import CobaltDataset, CobaltDataSubset
from cobalt.schema.dataset_collection import DatasetCollection
from cobalt.state import State
from cobalt.styles import DEFAULT_COLORING_LEGEND_STYLES
from cobalt.ui_utils import with_tooltip
from cobalt.visualization import EmbeddingVisualization
from cobalt.widgets import Button, SearchableSelect, Select


def build_select_list(options: Sequence[str]) -> Sequence[Mapping[str, str]]:
    return [{"text": cmap_value} for cmap_value in options]


def get_categorical_colormap_options() -> Sequence[Mapping[str, str]]:
    """Get categorical colormap options including custom registered ones."""
    return build_select_list(ColorMapOptions.get_categorical_options())


def get_drift_colormap_options() -> Sequence[Mapping[str, str]]:
    """Get numerical colormap options including custom registered ones."""
    return build_select_list(ColorMapOptions.get_drift_score_options())


def get_numerical_colormap_options() -> Sequence[Mapping[str, str]]:
    """Get numerical colormap options including custom registered ones."""
    return build_select_list(ColorMapOptions.get_numerical_options())


def get_combined_colormap_options() -> Sequence[Mapping[str, Union[str, bool]]]:
    """Get combined colormap options including custom registered ones."""
    return [
        {"header": "Continuous"},
        *get_numerical_colormap_options(),
        {"divider": True},
        {"header": "Categorical"},
        *get_categorical_colormap_options(),
    ]


class ColoringOption(ABC):
    @abstractmethod
    def get_color_spec(
        self, subset: CobaltDataSubset, config: dict
    ) -> GraphColoringSpec:
        pass

    @abstractmethod
    def get_histogram(self, subset: CobaltDataSubset) -> Optional[str]:
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Name to display for this coloring option."""

    @property
    @abstractmethod
    def cmap_options(
        self,
    ) -> Tuple[Sequence[Mapping[str, Union[str, bool]]], Optional[str]]:
        pass

    @property
    @abstractmethod
    def allow_color_range(self) -> bool:
        pass

    @abstractmethod
    def is_valid_for_dataset(self, dataset: CobaltDataset) -> bool:
        """Check if this coloring option is valid for the given dataset."""


class ColumnColoringOption(ColoringOption):
    def __init__(
        self,
        dataset_collection: DatasetCollection,
        column: str,
        dataset_name: Optional[str] = None,
    ):
        """Initialize ColumnColoringOption.

        Args:
            dataset_collection: DatasetCollection containing the datasets
            column: Column name to use for coloring
            dataset_name: Name of dataset containing the column. If None and
                dataset_collection is a CobaltDataset, uses that dataset.
        """
        self.dataset_collection = dataset_collection
        self.dataset_name = dataset_name or dataset_collection.primary.name
        self.dataset = dataset_collection.datasets[self.dataset_name]

        self.column = column
        self.column_type = self.dataset.metadata.data_types[column]

    def _get_aggregation_for_colormap(
        self, color_map_name: str
    ) -> Literal["mean", "mode"]:
        """Determine linked dataset aggregation method.

        Returns:
            'mean' for numerical or datetime columns with continuous colormaps
            'mode' for categorical columns or categorical colormaps
        """
        if color_map_name in ColorMapOptions.get_categorical_options():
            return "mode"
        elif self.column_type.col_type in (
            ColumnDataType.numerical,
            ColumnDataType.datetime,
        ):
            return "mean"
        else:  # this should happen rarely
            return "mode"

    def is_valid_for_dataset(self, dataset: CobaltDataset) -> bool:
        """Check if this coloring option is valid for the given dataset.

        Returns True if the column is in the dataset, or there is a link from
        the dataset to the dataset containing the column.
        """
        if dataset.name == self.dataset_name:
            return True

        link = self.dataset_collection.get_link(dataset.name, self.dataset_name)
        return link is not None

    def get_color_spec(
        self, subset: CobaltDataSubset, config: dict
    ) -> GraphColoringSpec:
        # TODO: better way to handle config
        # TODO: type checking of color map name?

        source_dataset = subset.source_dataset
        color_map_name = config.pop("color_map_name")

        if source_dataset.name != self.dataset_name:
            link = self.dataset_collection.get_link(
                source_dataset.name, self.dataset_name
            )

            if link is None:
                raise ValueError(
                    f"No link found from {source_dataset.name} to {self.dataset_name}"
                )

            column_values = self.dataset.select_col(self.column)
            aggregation = self._get_aggregation_for_colormap(color_map_name)
            np_vals = column_values.to_numpy()
            aggregated = link.push_values_to_left(np_vals, agg_fn=aggregation)[
                subset.indices
            ]

            if is_datetime64_any_dtype(column_values.dtype):
                # Ensure timestamp dtype is preserved for TimestampColoringSpec.
                f = pd.Series(pd.to_datetime(aggregated), name=self.name)
            else:
                f = pd.Series(aggregated, name=self.name)
        else:
            f = subset.select_col(self.column)

        if is_datetime64_any_dtype(f.dtype):
            config.pop("range_type", None)
            return TimestampColoringSpec(f, color_map_name, **config)
        if color_map_name in ColorMapOptions.get_categorical_options():
            config.pop("range_type", None)
            return CategoricalColoringSpec(f, color_map_name, **config)
        else:
            return NumericColoringSpec(f, color_map_name, **config)

    def get_histogram(self, subset: CobaltDataSubset) -> Optional[str]:
        source_dataset = subset.source_dataset

        if source_dataset.name != self.dataset_name:
            link = self.dataset_collection.get_link(
                source_dataset.name, self.dataset_name
            )
            if link is None:
                return None

            column_values = self.dataset.select_col(self.column)

            if not is_numeric_dtype(column_values.dtype):
                return None

            aggregated = link.push_values_to_left(
                column_values.to_numpy(), agg_fn="mean"
            )
            data = pd.Series(aggregated[subset.indices])
        else:
            data = subset.select_col(self.column)

        if is_numeric_dtype(data.dtype):
            return create_histogram_svg(data.astype(float))
        return None

    @property
    def name(self) -> str:
        return self.column

    @property
    def cmap_options(self):
        # TODO: use precomputed dataset metadata
        data = self.dataset.select_col(self.column)
        if is_numeric_dtype(data.dtype):
            options_data = get_combined_colormap_options()
        elif is_datetime64_any_dtype(data.dtype):
            options_data = get_numerical_colormap_options()
        elif isinstance(data.dtype, pd.api.types.CategoricalDtype):
            options_data = get_categorical_colormap_options()
        else:
            options_data = build_select_list(ColorMapOptions.UNKNOWN)

        if options_data and "header" in options_data[0]:
            default_selection = str(options_data[1]["text"])
        elif options_data:
            default_selection = str(options_data[0]["text"])
        else:
            default_selection = None

        return options_data, default_selection

    @property
    def allow_color_range(self) -> bool:
        return True


class NoColoringOption(ColoringOption):
    def get_color_spec(
        self, subset: CobaltDataSubset, config: dict
    ) -> GraphColoringSpec:
        return NoColoringSpec()

    def get_histogram(self, subset: CobaltDataSubset) -> Optional[str]:
        return None

    @property
    def name(self) -> str:
        return NO_COLORING_OPTION

    @property
    def cmap_options(self):
        return [], None

    @property
    def allow_color_range(self) -> bool:
        return False

    def is_valid_for_dataset(self, dataset: CobaltDataset) -> bool:
        """No coloring is always valid."""
        return True


class NodeSizeColoringOption(ColoringOption):
    def get_color_spec(self, subset: CobaltDataSubset, config: dict):
        return NodeSizeColoringSpec(
            config["color_map_name"],
            config["cmap_range"],
            scale=config.get("scale", "linear"),
        )

    def get_histogram(self, subset: CobaltDataSubset) -> Optional[str]:
        return None

    @property
    def name(self) -> str:
        return "Node size"

    @property
    def cmap_options(self):
        options_data = get_numerical_colormap_options()
        default_selection = str(options_data[0]["text"])

        return options_data, default_selection

    @property
    def allow_color_range(self) -> bool:
        return False

    def is_valid_for_dataset(self, dataset: CobaltDataset) -> bool:
        """Coloring by node size is always valid."""
        return True


class DriftScoreColoringOption(ColoringOption):
    def __init__(
        self,
        baseline: CobaltDataSubset,
        comparison: CobaltDataSubset,
        baseline_name: str,
        comparison_name: str,
    ):
        self.baseline = baseline
        self.comparison = comparison
        self.baseline_name = baseline_name
        self.comparison_name = comparison_name

    def get_color_spec(
        self, subset: CobaltDataSubset, config: dict
    ) -> GraphColoringSpec:
        # TODO: restore graph smoothing? not sure it's worth the complexity
        f = np.zeros(len(subset))
        # intersect will raise ValueError if datasets differ, but this should be
        # prevented by is_valid_for_dataset check. Add defensive check just in case.
        try:
            f -= subset.intersect(self.baseline).as_mask_on(subset)
            f += subset.intersect(self.comparison).as_mask_on(subset)
        except ValueError:
            # If datasets don't match, return zero coloring
            pass
        f_series = pd.Series(f, name=self.name)
        config.pop("cmap_range", None)
        config.pop("range_type", None)

        spec = NumericColoringSpec(
            f_series,
            cmap_range=(-1, 1),
            node_label_gen=get_node_drift_score_labeler(f),
            **config,
        )
        return spec

    def get_histogram(self, subset: CobaltDataSubset) -> Optional[str]:
        return None

    @property
    def name(self) -> str:
        return f"{self.baseline_name} vs {self.comparison_name}"

    @property
    def cmap_options(self):
        options_data = get_drift_colormap_options()
        drift_options = ColorMapOptions.get_drift_score_options()
        default = drift_options[0] if drift_options else "viridis"

        return options_data, default

    @property
    def allow_color_range(self) -> bool:
        return False

    def is_valid_for_dataset(self, dataset: CobaltDataset) -> bool:
        """Valid if both baseline and comparison are from this dataset."""
        return (
            self.baseline.source_dataset is dataset
            and self.comparison.source_dataset is dataset
        )


class GroupResultsCollectionColoringOption(ColoringOption):
    def __init__(self, results: GroupResultsCollection):
        self.results = results
        dataset = self.results.source_data.source_dataset
        f = np.full(len(dataset), "no group", dtype=object)
        for group in self.results.groups:
            f[group.subset.indices] = group.name
        self.f = f

    def get_color_spec(
        self, subset: CobaltDataSubset, config: dict
    ) -> GraphColoringSpec:
        f = self.f[subset.indices]
        f_series = pd.Series(f, name=self.name, dtype="category")
        config.pop("cmap_range", None)
        config.pop("range_type", None)
        color_map_name = config.pop("color_map_name")
        spec = CategoricalColoringSpec(
            f_series,
            color_map_name,
            **config,
        )
        return spec

    def get_histogram(self, subset: CobaltDataSubset) -> Optional[str]:
        return None

    @property
    def name(self) -> str:
        return f"{self.results.name}"

    @property
    def cmap_options(self):
        options_data = get_categorical_colormap_options()
        categorical_options = ColorMapOptions.get_categorical_options()
        default = categorical_options[0] if categorical_options else "tab10"

        return options_data, default

    @property
    def allow_color_range(self) -> bool:
        return True

    def is_valid_for_dataset(self, dataset: CobaltDataset) -> bool:
        return self.results.source_data.source_dataset is dataset


# TODO: correctly validate dataset
class MetricColoringOption(ColoringOption):
    def __init__(self, metric, model_name: str):
        self.metric = metric
        self.model_name = model_name

    def get_color_spec(
        self, subset: CobaltDataSubset, config: dict
    ) -> GraphColoringSpec:
        f = self.metric.calculate(subset).get(self.metric.get_key())
        f.name = self.name
        numerical_options = ColorMapOptions.get_numerical_options()
        default_cmap = numerical_options[0] if numerical_options else "viridis"
        color_map_name = config.pop("color_map_name", default_cmap)
        config.pop("repeat_colors", None)

        spec = NumericColoringSpec(f, color_map_name=color_map_name, **config)
        return spec

    def get_histogram(self, subset: CobaltDataSubset) -> Optional[str]:
        return None

    @property
    def name(self) -> str:
        return f"{self.model_name}_{self.metric.get_key()}"

    @property
    def cmap_options(self):
        options_data = get_numerical_colormap_options()
        numerical_options = ColorMapOptions.get_numerical_options()
        default = numerical_options[0] if numerical_options else "viridis"

        return options_data, default

    @property
    def allow_color_range(self) -> bool:
        return True

    def is_valid_for_dataset(self, dataset: CobaltDataset) -> bool:
        return self.model_name in [m.name for m in dataset.models]


NO_COLORING_OPTION = "No coloring"


def create_histogram_svg(column_data: pd.Series) -> str:
    fig, ax = plt.subplots()
    ax.hist(column_data, bins=20)

    # Convert to SVG
    output = io.BytesIO()
    plt.savefig(output, format="svg", bbox_inches="tight")
    plt.close(fig)
    output.seek(0)
    svg_data = output.getvalue().decode("utf-8")

    return svg_data


def get_coloring_options(
    state: State,
    extra_metadata_columns: Optional[List[str]],
    extra_data_columns: Optional[List[str]],
    enable_drift_score: bool,
) -> Dict[str, List[ColoringOption]]:
    """Populate the collection of coloring options for this dataset.

    Returns a dict of lists by category.
    """
    coloring_options: Dict[str, List[ColoringOption]] = defaultdict(list)
    coloring_options["Coloring options"] = [
        NoColoringOption(),
        NodeSizeColoringOption(),
    ]
    if enable_drift_score:
        coloring_options["Drift score"] = [
            DriftScoreColoringOption(split_1, split_2, split_name_1, split_name_2)
            for (split_name_1, split_1), (
                split_name_2,
                split_2,
            ) in state.split.comparable_subset_pairs
        ]

    dataset_collection = state.dataset_collection
    primary_name = state.dataset.name

    def add_dataset_options(
        dataset, dataset_name, is_primary=True, is_only_dataset=False
    ):
        prefix = "" if is_only_dataset else f"{dataset_name}: "
        column_types = dataset.metadata.data_types

        for model in dataset.models:
            # Performance metrics
            metrics = model.evaluation_metrics
            category = (
                f"{prefix}Performance metrics" if prefix else "Performance metrics"
            )
            coloring_options[category].extend(
                [
                    MetricColoringOption(metrics[metric], model.name)
                    for metric in metrics
                ]
            )

            # Outcome columns
            category = f"{prefix}Outcome" if prefix else "Outcome"
            coloring_options[category].extend(
                [
                    ColumnColoringOption(dataset_collection, col, dataset_name)
                    for col in model.outcome_columns
                ]
            )

            # Prediction columns
            category = f"{prefix}Prediction" if prefix else "Prediction"
            coloring_options[category].extend(
                [
                    ColumnColoringOption(dataset_collection, col, dataset_name)
                    for col in model.prediction_columns
                ]
            )

        # Timestamp columns
        if dataset.metadata.timestamp_columns:
            category = f"{prefix}Timestamp" if prefix else "Timestamp"
            coloring_options[category].extend(
                [
                    ColumnColoringOption(dataset_collection, col, dataset_name)
                    for col in dataset.metadata.timestamp_columns
                ]
            )

        # Metadata columns (only for primary dataset)
        if is_primary and extra_metadata_columns:
            coloring_options["Metadata"].extend(
                [
                    ColumnColoringOption(dataset_collection, col, dataset_name)
                    for col in extra_metadata_columns
                    if column_types[col].is_categorical
                    or column_types[col].col_type == ColumnDataType.numerical
                ]
            )

        # Data columns (only for primary dataset)
        if is_primary and extra_data_columns:
            coloring_options[f"{prefix}Data columns"] = [
                ColumnColoringOption(dataset_collection, col, dataset_name)
                for col in extra_data_columns
                if column_types[col].is_categorical
                or column_types[col].col_type == ColumnDataType.numerical
            ]

        # All other columns (for linked datasets)
        if not is_primary:
            category = f"{prefix}Data columns"
            for col_name, col_type in column_types.items():
                if (
                    col_type.is_categorical
                    or col_type.col_type == ColumnDataType.numerical
                ):
                    option = ColumnColoringOption(
                        dataset_collection, col_name, dataset_name
                    )
                    coloring_options[category].append(option)

    if len(dataset_collection.datasets) == 1:
        add_dataset_options(
            state.dataset, primary_name, is_primary=True, is_only_dataset=True
        )
    else:
        # Add options from the primary dataset
        add_dataset_options(state.dataset, primary_name, is_primary=True)

        # Add columns from linked datasets
        for dataset_name, dataset in dataset_collection.datasets.items():
            if dataset_name == primary_name:
                continue  # Already added above

            # Check if this dataset is linked to the primary
            # if dataset_collection.get_link(primary_name, dataset_name) is not None:
            add_dataset_options(dataset, dataset_name, is_primary=False)

    clusters = state.run_repo.get_runs(group_type=GroupType.cluster, run_visible=True)
    if clusters:
        coloring_options["Clustering results"] = [
            GroupResultsCollectionColoringOption(run) for run in clusters.values()
        ]

    coloring_options = defaultdict(
        list,
        {cat: options for cat, options in coloring_options.items() if len(options) > 0},
    )

    return coloring_options


def get_name_to_options_dict(
    coloring_options: Dict[str, List[ColoringOption]],
) -> Dict[str, ColoringOption]:
    name_to_options_dict: Dict[str, ColoringOption] = {}
    for options in coloring_options.values():
        for option in options:
            name_to_options_dict[option.name] = option

    return name_to_options_dict


def build_vuetify_options_list(
    coloring_options: Dict[str, List[ColoringOption]],
) -> Tuple[
    List[Dict[str, Union[str, bool, int]]],
    Dict[int, ColoringOption],
    Dict[str, Union[str, int]],
]:
    coloring_options_data: List[Dict[str, Union[str, int, bool]]] = []
    initial_option = get_initial_coloring_option(coloring_options)

    id_to_options_dict: Dict[int, ColoringOption] = {}
    current_id = 0
    initial_selection = {"text": "", "id": 0}
    for header, options in coloring_options.items():
        if len(options) > 0:
            coloring_options_data.append({"header": header})
            for option in options:
                selection = {"text": option.name, "id": current_id}
                if option == initial_option:
                    initial_selection = selection
                coloring_options_data.append(selection)
                id_to_options_dict[current_id] = option
                current_id += 1
            coloring_options_data.append({"divider": True})

    return coloring_options_data, id_to_options_dict, initial_selection


def get_initial_coloring_option(
    coloring_options: Dict[str, List[ColoringOption]],
) -> ColoringOption:
    """Chooses the default coloring option for the graph."""
    # model performance metric
    if coloring_options["Performance metrics"]:
        # The first entry section will be an error metric
        return coloring_options["Performance metrics"][0]
    # model predictions
    if coloring_options["Prediction"]:
        return coloring_options["Prediction"][0]
    # model ground truth
    if coloring_options["Outcome"]:
        return coloring_options["Outcome"][0]
    # drift score
    if coloring_options["Drift score"]:
        return coloring_options["Drift score"][0]
    # autogroup clusters
    if coloring_options["Clustering results"]:
        return coloring_options["Clustering results"][0]
    # first nontrivial coloring option
    for opts in coloring_options.values():
        if opts and opts[0].name != NO_COLORING_OPTION:
            return opts[0]

    # if all else fails
    return NoColoringOption()


class ColoringConfig(v.Flex):
    def __init__(
        self,
        visualization: EmbeddingVisualization,
        extra_data_columns: Optional[List[str]] = None,
        extra_metadata_columns: Optional[List[str]] = None,
        enable_drift_score: bool = False,
        **kwargs,
    ):
        super().__init__(class_="d-flex", style_="max-width: 160px", **kwargs)

        self.connector = visualization.selection_manager
        self.dataset = visualization.state.dataset
        self.visualization = visualization
        state = visualization.state

        coloring_options = get_coloring_options(
            state, extra_metadata_columns, extra_data_columns, enable_drift_score
        )

        coloring_options_data, self.coloring_options_dict, initial_option = (
            build_vuetify_options_list(coloring_options)
        )

        saved_selection = state.coloring_menu.get("selector_dropdown_value")
        if saved_selection:
            initial_option = saved_selection

        self.selector_dropdown = SearchableSelect(
            label="Color by",
            items=coloring_options_data,
            v_model=initial_option,
            class_="mt-2",
            return_object=True,
        )
        self.selector_dropdown.on_event("change", self.on_selector_dropdown_change)

        cmap_options_data, v_model = self.get_cmap_options(
            self.selector_dropdown.v_model
        )
        self.selector_cmap = Select(
            label="Color map", items=cmap_options_data, v_model=v_model
        )
        self.selector_cmap.on_event("change", self.apply_coloring)

        self.color_range_ui = ColorRange(
            value_changed_callback=self.apply_coloring,
            color_by=self.selector_dropdown.v_model,
        )
        self.color_range_ui.hide()

        self.repeat_colors_checkbox = v.Checkbox(
            label="Repeat colors",
            v_model=False,
            dense=True,
            hide_details=True,
            class_="ma-0 pa-0",
        )

        self.repeat_colors_checkbox.hide()
        self.repeat_colors_checkbox.on_event("change", self.apply_coloring)

        color_by_btn = v.Html(
            tag="div",
            children=[
                with_tooltip(
                    Button(
                        class_="pa-0",
                        v_on="props.on",
                        height="40px",
                        min_width="40px",
                        children=[
                            v.Icon(
                                children=["mdi-palette"],
                                style_=":hover { color: rgba(41, 98, 255, 1); }",
                            )
                        ],
                    ),
                    "Graph Coloring",
                )
            ],
        )

        self.coloring_popup = v.Menu(
            top=False,
            left=True,
            attach=True,
            close_on_content_click=False,
            offset_y=True,
            v_slots=[
                {
                    "name": "activator",
                    "variable": "props",
                    "children": color_by_btn,
                },
            ],
            children=[
                v.Card(
                    class_="d-flex flex-column pa-3",
                    width="288",
                    children=[
                        self.selector_dropdown,
                        self.selector_cmap,
                        self.color_range_ui,
                        self.repeat_colors_checkbox,
                    ],
                    style_="gap: 12px;",
                )
            ],
            style_="z-index: 12;",
        )

        self.legend = v.Flex(
            class_="flex-grow-0 overflow-x-hidden",
            style_=DEFAULT_COLORING_LEGEND_STYLES,
        )

        self.color_histogram_dialog = HistogramDialog(
            v_model=False,
            max_width="800px",
            children=[],
            on_close=self.close_color_histogram_dialog,
        )

        self.color_histogram_btn = Button(
            class_="pa-0 d-none",
            height="40px",
            min_width="40px",
            children=[v.Icon(children=["mdi-chart-histogram"])],
        )
        self.color_histogram_btn.on_event("click", self.open_color_histogram_dialog)
        self.color_histogram_btn_with_tooltip = with_tooltip(
            self.color_histogram_btn, "Color Histogram"
        )

        self.widgets = [
            v.Flex(
                class_="d-flex flex-column align-end justify-end",
                children=[
                    v.Html(
                        tag="div",
                        class_="d-flex justify-end",
                        children=[
                            self.color_histogram_btn_with_tooltip,
                            self.coloring_popup,
                        ],
                        style_="gap: 6px",
                    ),
                    self.legend,
                    self.color_histogram_dialog,
                ],
                style_="gap: 6px",
            ),
        ]

        self.children = self.widgets

        # Track the current source dataset
        self.current_source_dataset = None

        self.update_cmap_options()
        self.apply_coloring()
        self.visualization.on_graph_update(self._on_graph_update)

    def on_selector_dropdown_change(self, *_):
        self.update_cmap_options()
        self.color_range_ui.reset()
        self.color_range_ui.is_auto = True
        self.color_range_ui.auto_checkbox.v_model = True
        self.apply_coloring()
        self.visualization.state.coloring_menu["selector_dropdown_value"] = (
            self.selector_dropdown.v_model
        )

    @handle_cb_exceptions
    def update_cmap_options(self, *_):
        new_options, v_model = self.get_cmap_options(self.selector_dropdown.v_model)
        self.selector_cmap.items = new_options
        if new_options:
            self.selector_cmap.v_model = v_model

    def get_cmap_options(self, selection: Dict[str, Union[str, int]]):
        if selection:
            coloring_option = self.coloring_options_dict[selection["id"]]
        else:
            coloring_option = self.coloring_options_dict[0]

        options_data, default_selection = coloring_option.cmap_options

        previous_selected_column = self.visualization.state.coloring_menu.get(
            "selector_dropdown_value"
        )
        if previous_selected_column == selection:
            v_model = self.visualization.state.coloring_menu.get("selector_cmap_value")
        else:
            v_model = default_selection

        return options_data, v_model

    @handle_cb_exceptions
    def _on_graph_update(self, *_):
        """Handle graph updates by validating coloring options and applying coloring."""
        if (
            not hasattr(self.visualization, "source_data")
            or self.visualization.source_data is None
        ):
            return

        source_dataset = self.visualization.source_data.source_dataset

        # if source dataset changed
        if self.current_source_dataset != source_dataset:
            self.current_source_dataset = source_dataset
            self._update_coloring_options_availability()

            # check if current option is still valid
            current_option = self.selector_dropdown.v_model
            current_option_id = current_option["id"]
            if current_option_id in self.coloring_options_dict:
                coloring_option = self.coloring_options_dict[current_option_id]
                if not coloring_option.is_valid_for_dataset(source_dataset):
                    # current option is invalid, switch to first valid option
                    self._select_first_valid_option()

        self.apply_coloring()

    def _update_coloring_options_availability(self):
        """Update the disabled state of coloring options based on current source dataset."""
        if self.current_source_dataset is None:
            return

        new_items = []
        for item in self.selector_dropdown.items:
            if "header" in item or "divider" in item:
                new_items.append(item)
            elif "text" in item:
                option_name = item["text"]
                option_id = item["id"]
                if option_id in self.coloring_options_dict:
                    coloring_option = self.coloring_options_dict[option_id]
                    is_valid = coloring_option.is_valid_for_dataset(
                        self.current_source_dataset
                    )
                    new_item = {"text": option_name, "id": option_id}
                    if not is_valid:
                        new_item["disabled"] = True
                    new_items.append(new_item)
                else:
                    new_items.append(item)

        self.selector_dropdown.items = new_items

    def _select_first_valid_option(self):
        """Select the first valid (enabled) coloring option."""
        no_coloring_option = None
        for item in self.selector_dropdown.items:
            if "text" in item and not item.get("disabled", False):
                if item["text"] != NO_COLORING_OPTION:
                    self.selector_dropdown.v_model = item
                    self.on_selector_dropdown_change()
                    return
                else:
                    no_coloring_option = item

        # Fallback to "No coloring" if nothing else is valid
        if no_coloring_option:
            self.selector_dropdown.v_model = no_coloring_option
            self.on_selector_dropdown_change()

    @handle_cb_exceptions
    def apply_coloring(self, *_):
        if (
            not hasattr(self.visualization, "source_data")
            or self.visualization.source_data is None
        ):
            return

        option = self.selector_dropdown.v_model
        if not isinstance(option, dict):
            # this happens when user clears the autocomplete search
            return

        option_id = option["id"]
        coloring_option = self.coloring_options_dict[option_id]

        source_data = self.visualization.source_data

        color_map_name = self.selector_cmap.v_model
        if not color_map_name:
            color_map_name = coloring_option.cmap_options[1]
            self.selector_cmap.v_model = color_map_name
        color_map_range = self.color_range_ui.get_coloring_range()
        range_type = "absolute" if color_map_range is not None else "auto"
        config = {
            "color_map_name": color_map_name,
            "cmap_range": color_map_range,
            "range_type": range_type,
        }
        if color_map_name in ColorMapOptions.get_categorical_options():
            config["repeat_colors"] = self.repeat_colors_checkbox.v_model

        color_spec = coloring_option.get_color_spec(source_data, config)
        self.visualization.landscape.set_coloring_spec(color_spec)

        if not coloring_option.allow_color_range:
            self.color_range_ui.hide()
        else:
            self.update_color_range_ui(color_spec)

        self.legend.children = [self.visualization.landscape.legend_box]

        self.plot_feature_histogram(coloring_option, source_data)

        self.visualization.state.coloring_menu["selector_cmap_value"] = (
            self.selector_cmap.v_model
        )

    def plot_feature_histogram(
        self, coloring_option: ColoringOption, source_data: CobaltDataSubset
    ):
        hist = coloring_option.get_histogram(source_data)
        if not hist:
            self.color_histogram_dialog.children = []
            self.color_histogram_btn.class_list.add("d-none")
        else:
            image_widget = w.HTML(value=f"<div>{hist}</div>")

            self.color_histogram_dialog.add_histogram(
                title=f"Histogram for {coloring_option.name}", histogram=image_widget
            )
            self.color_histogram_btn.class_list.remove("d-none")

    # TODO: factor this into ColoringOption?
    def update_color_range_ui(self, coloring_config: GraphColoringSpec):
        if isinstance(coloring_config, NumericColoringSpec):
            if self.color_range_ui.default_cmap_range is None:
                self.color_range_ui.set_default_range(
                    (coloring_config.min_val, coloring_config.max_val),
                )
                self.color_range_ui.set_boundaries_range(
                    (coloring_config.lower_bound, coloring_config.upper_bound)
                )
            elif self.color_range_ui.color_by != self.selector_dropdown.v_model:
                self.color_range_ui.set_default_range(
                    (coloring_config.min_val, coloring_config.max_val),
                )
                self.color_range_ui.set_boundaries_range(
                    (coloring_config.lower_bound, coloring_config.upper_bound)
                )
                self.color_range_ui.color_by = self.selector_dropdown.v_model
            self.color_range_ui.show()
        else:
            self.color_range_ui.hide()

        if isinstance(coloring_config, CategoricalColoringSpec):
            self.repeat_colors_checkbox.show()
        else:
            self.repeat_colors_checkbox.hide()

    def open_color_histogram_dialog(self, *_):
        self.color_histogram_dialog.v_model = True

    def close_color_histogram_dialog(self, *_):
        self.color_histogram_dialog.v_model = False

    def refresh_layout(self, *_):
        widgets = [*self.widgets]
        self.children = widgets


def get_node_drift_score_labeler(raw_drift_labels: np.ndarray):
    def node_drift_score_label(u: np.ndarray, f_vals: pd.Series, node_val: float):
        f = raw_drift_labels[u]
        production = np.sum(f == 1)
        baseline = np.sum(f == -1)
        label = f"{len(u)} points, {baseline} baseline, {production} comparison"
        return label

    return node_drift_score_label
