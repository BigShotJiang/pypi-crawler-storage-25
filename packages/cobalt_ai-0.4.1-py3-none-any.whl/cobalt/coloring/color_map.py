# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from typing import Callable, Dict, List, Mapping, Optional, Tuple

import matplotlib
import numpy as np
from matplotlib.colors import Colormap, LinearSegmentedColormap, Normalize

red_blue_colormap = [
    (0, (5, 10, 172)),
    (0.35, (106, 137, 247)),
    (0.5, (190, 190, 190)),
    (0.6, (220, 170, 132)),
    (0.7, (230, 145, 90)),
    (1, (178, 10, 28)),
]


def rgb_tuples_to_mpl_colormap(
    colordata: List[Tuple[float, Tuple[int, int, int]]], name: str, N: int = 256
):
    cdict = {
        "red": [(x, cval[0] / 255, cval[0] / 255) for x, cval in colordata],
        "green": [(x, cval[1] / 255, cval[1] / 255) for x, cval in colordata],
        "blue": [(x, cval[2] / 255, cval[2] / 255) for x, cval in colordata],
    }

    cmap = LinearSegmentedColormap(name, segmentdata=cdict, N=N)
    return cmap


def hex_array_to_rgb(colors: str):
    hr, hg, hb = colors[1:3], colors[3:5], colors[5:7]
    r, g, b = (int(c, 16) for c in (hr, hg, hb))
    return r, g, b


def rgb_to_hex_array(colors: np.ndarray):
    colors = np.round(colors * 255).astype(np.int32)
    out_vals = [
        f"#{colors[i,0]:02x}{colors[i,1]:02x}{colors[i,2]:02x}"
        for i in range(colors.shape[0])
    ]
    return out_vals


class ColorMap:
    """Converts a list or array of numeric values into a list of HTML color strings."""

    def __init__(self, mapname: str = "viridis", normalize: Optional[Callable] = None):
        """Set up the ColorMap.

        Args:
            mapname: name of the matplotlib colormap that should be used
            normalize: a function that normalizes numpy arrays. If omitted, scales
                the array to range from 0 to 1.
        """
        registered_maps = ColorMap.registered_color_maps()

        if mapname in registered_maps:
            self.cmap = registered_maps[mapname]
        else:
            self.cmap = matplotlib.colormaps[mapname]
        self.normalize = normalize

    def __call__(self, f) -> List[str]:
        f = np.array(f)
        norm = self.normalize if self.normalize else Normalize()
        node_colors = self.cmap(norm(f))
        hex_node_colors = rgb_to_hex_array(node_colors)
        return hex_node_colors

    @staticmethod
    def custom_gradient(color1: tuple, color2: tuple):
        colors = [color1, color2]
        cm = LinearSegmentedColormap.from_list("Custom", colors, N=20)
        return cm

    @staticmethod
    def registered_color_maps() -> Mapping[str, Colormap]:
        """Get all registered custom colormaps.

        This includes both the default custom colormaps and any colormaps
        registered via cobalt.settings.register_colormap().
        """
        from cobalt.config import settings

        base_maps: Dict[str, Colormap] = {
            "blue-red": rgb_tuples_to_mpl_colormap(red_blue_colormap, "blue-red"),
            "black-red-gradient": ColorMap.custom_gradient((0, 0, 0), (1, 0, 0)),
        }

        # Merge with user-registered colormaps
        base_maps.update(settings._get_custom_colormap_objects())

        return base_maps
