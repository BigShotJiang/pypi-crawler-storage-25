# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from dataclasses import dataclass
from typing import Dict

from cobalt.schema.dataset import CobaltDataSubset
from cobalt.schema.graph import HierarchicalCobaltGraph
from cobalt.serialization import SerializableMixin


@dataclass
class GraphRepositoryEntry(SerializableMixin):
    """Repository entry for a graph with its landscape visualization parameters.

    Stores the HierarchicalCobaltGraph and parameters needed to construct a MultiResolutionLandscape
    widget. The actual widget is created on-demand by the UI layer.
    """

    cobalt_graph: HierarchicalCobaltGraph
    landscape_params: dict

    _serialization_version = 2

    def __data_dict__(self):
        return {
            "cobalt_graph": self.cobalt_graph,
            "landscape_params": self.landscape_params,
        }

    @classmethod
    def __from_serializable_dict__(cls, d: dict):
        data = d["__data__"]
        if "cobalt_graph" in data:
            cobalt_graph = data["cobalt_graph"]
        elif "subset" in data and "graph" in data:
            # backward compatibility for graphs saved before HierarchicalCobaltGraph
            graph = data["graph"]
            subset = data["subset"]
            cobalt_graph = HierarchicalCobaltGraph(
                "name", graph, subset, getattr(graph, "params", {})
            )
        else:
            raise ValueError("Could not deserialize GraphRepositoryEntry")
        landscape_params = data.get(
            "landscape_params",
            {
                "init_max_nodes": 500,
                "init_max_degree": 15.0,
            },
        )
        # Reconstruct the landscape from the HierarchicalCobaltGraph
        return cls(cobalt_graph=cobalt_graph, landscape_params=landscape_params)


class GraphRepository(SerializableMixin):
    _serialization_version = 2

    def __init__(self) -> None:
        self.graphs: Dict[str, GraphRepositoryEntry] = {}

    def add_graph(
        self,
        cobalt_graph: HierarchicalCobaltGraph,
        landscape_params: dict,
        graph_name: str,
    ):
        """Add a graph to the repository.

        Args:
            cobalt_graph: The HierarchicalCobaltGraph instance containing metadata
            landscape_params: Parameters for constructing MultiResolutionLandscape
            graph_name: Name to store the graph under

        Raises:
            ValueError: If graph_name doesn't match cobalt_graph.name
        """
        if cobalt_graph.name != graph_name:
            raise ValueError(
                f"Graph name mismatch: HierarchicalCobaltGraph.name='{cobalt_graph.name}' "
                f"but graph_name='{graph_name}'"
            )
        self.graphs[graph_name] = GraphRepositoryEntry(
            cobalt_graph=cobalt_graph, landscape_params=landscape_params
        )

    def update_graph(
        self,
        cobalt_graph: HierarchicalCobaltGraph,
        landscape_params: dict,
        graph_name: str,
    ):
        """Update an existing graph in the repository.

        Args:
            cobalt_graph: The HierarchicalCobaltGraph instance containing metadata
            landscape_params: Parameters for constructing MultiResolutionLandscape
            graph_name: Name of the graph to update

        Raises:
            ValueError: If graph_name doesn't match cobalt_graph.name
        """
        if cobalt_graph.name != graph_name:
            raise ValueError(
                f"Graph name mismatch: HierarchicalCobaltGraph.name='{cobalt_graph.name}' "
                f"but graph_name='{graph_name}'"
            )
        self.graphs[graph_name] = GraphRepositoryEntry(
            cobalt_graph=cobalt_graph, landscape_params=landscape_params
        )

    def get_graph_entry(self, graph_name: str) -> GraphRepositoryEntry:
        """Get the full graph repository entry (CobaltGraph + landscape_params)."""
        return self.graphs[graph_name]

    def get_graphs(self) -> Dict[str, GraphRepositoryEntry]:
        """Get all graph repository entries."""
        return dict(self.graphs)

    def get_cobalt_graph(self, graph_name: str) -> HierarchicalCobaltGraph:
        """Get the HierarchicalCobaltGraph instance for a named graph."""
        return self.graphs[graph_name].cobalt_graph

    def get_cobalt_graphs(self) -> Dict[str, HierarchicalCobaltGraph]:
        """Get all HierarchicalCobaltGraph instances."""
        return {name: entry.cobalt_graph for name, entry in self.graphs.items()}

    def get_graphs_with_source_data(
        self, source_data: CobaltDataSubset
    ) -> Dict[str, GraphRepositoryEntry]:
        """Get all graphs built from a specific subset."""
        return {
            name: entry
            for name, entry in self.graphs.items()
            if entry.cobalt_graph.subset == source_data
        }

    def __data_dict__(self):
        return {"graphs": self.graphs}

    @classmethod
    def __from_serializable_dict__(cls, d: dict):
        data = d["__data__"]
        inst = GraphRepository()
        inst.graphs = data["graphs"]
        # set name based on key in dict
        for name, graph in inst.graphs.items():
            graph.name = name
        return inst
