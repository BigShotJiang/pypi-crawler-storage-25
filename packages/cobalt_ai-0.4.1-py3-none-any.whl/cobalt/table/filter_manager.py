"""Manager for table-specific filter state."""

from __future__ import annotations

from typing import Iterable, List, Optional

import pandas as pd

from cobalt.schema.metadata import DatasetMetadata
from cobalt.table.data_filters import DataExplorerFilters, DataFilter, apply_filters_df


class TableFilterManager:
    """Encapsulates the ephemeral filter state used by table widgets."""

    def __init__(self, metadata: DatasetMetadata):
        self._metadata = metadata
        self._filters = DataExplorerFilters()

    @property
    def filters(self) -> List[DataFilter]:
        return list(self._filters.filters)

    def add_filter(self, column: str, op: str, value) -> Optional[DataFilter]:
        columns_metadata = self._metadata.data_types
        column_metadata = columns_metadata.get(column)
        if not column_metadata:
            return None
        data_filter = DataFilter(column=column_metadata, op=op, value=value)
        self._filters.add_filter(data_filter=data_filter)
        return data_filter

    def extend(self, filters: Iterable[DataFilter]) -> None:
        for data_filter in filters:
            self._filters.add_filter(data_filter)

    def remove_filter(self, data_filter: DataFilter) -> None:
        self._filters.remove_filter(data_filter)

    def clear(self) -> None:
        self._filters.clear()

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        return apply_filters_df(df, self._filters)

    def active_count(self) -> int:
        return len(self._filters.filters)

    def has_filters(self) -> bool:
        return self.active_count() > 0

    def update_metadata(self, metadata: DatasetMetadata) -> None:
        self._metadata = metadata
