# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.
import importlib.util
import inspect
import json
import logging
import os
import sys
from datetime import date, datetime
from enum import Enum
from functools import wraps
from typing import (
    TYPE_CHECKING,
    Callable,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Tuple,
    Union,
)

import ipynbname
from dotenv import load_dotenv
from IPython.display import Javascript, clear_output, display
from mapper.exceptions import LicenseError
from mapper.license import check_license_manually

if TYPE_CHECKING:
    import matplotlib.colors

load_dotenv()

current_folder = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.split(current_folder)[0]  # path to the root folder of the project

# Path to logs folder.
# Can be set as environment variable or in `.env` file.
# If path is relative - `logs` folder will be created in the current directory.
# If path is absolute - `logs` folder will be created on absolute path.
# If path is not set - `logs` folder will be created in the default location `~/.config/cobalt/logs`
COBALT_LOGS_FOLDER_PATH = os.getenv("COBALT_LOGS_FOLDER_PATH")

if COBALT_LOGS_FOLDER_PATH is None:
    LOGS_FOLDER = os.path.join(os.path.expanduser("~"), ".config", "cobalt", "logs")
else:
    LOGS_FOLDER = os.path.join(os.path.abspath(COBALT_LOGS_FOLDER_PATH), "logs")

if not os.path.isdir(LOGS_FOLDER):
    os.makedirs(LOGS_FOLDER)

try:
    LOG_FILENAME = os.path.join(LOGS_FOLDER, f"{ipynbname.name()}_{date.today()}.out")
except (FileNotFoundError, IndexError, AttributeError):
    # during tests, ipynbname.name() raises FileNotFoundError because no notebook is running
    # it now raises AttributeError because it tries to access get_ipython().user_ns
    # in nbconvert, it raises IndexError because it does string processing on an ill-formed kernelid
    LOG_FILENAME = os.path.join(
        LOGS_FOLDER, f"cobalt_{datetime.now().isoformat(timespec='microseconds')}.out"
    )

HAS_ORJSON = importlib.util.find_spec("orjson") is not None


def is_vscode():
    # Check for VS Code environment variables
    if "VSCODE_PID" in os.environ or "VSCODE_CWD" in os.environ:
        return True

    # Check if the Jupyter front-end is VS Code by inspecting IPython configuration
    try:
        ip = get_ipython()  # noqa: F821
        if ip is not None:
            config = ip.config
            # Look for VS Code-specific configurations in the IPython configuration
            if "vscode" in str(config).lower():
                return True
    except Exception:
        pass

    # Check for loaded VS Code-specific modules in sys.modules
    vscode_modules = ["vscode", "vscode_notebooks"]
    for module in vscode_modules:
        if module in sys.modules:
            return True

    # Check if the Jupyter kernel's metadata contains any VS Code-specific information
    try:
        kernel_file = os.path.join(
            os.path.expanduser("~"),
            ".local",
            "share",
            "jupyter",
            "runtime",
            "kernel-*.json",
        )
        with open(kernel_file) as f:
            kernel_data = json.load(f)
            if "vscode" in str(kernel_data).lower():
                return True
    except Exception:
        pass

    return False


def is_colab_environment() -> bool:
    """Check if the package is running in Google Colab."""
    try:
        module = get_ipython().__module__
        is_colab = module == "google.colab._shell"
    except NameError:
        is_colab = False
    return is_colab


def setup_colab_widget_environment():
    print(
        "Colab environment detected. Enabling custom ipywidgets. "
        "This is required to use the Cobalt UI."
    )
    print("To disable, run:")
    print()
    print("    from google.colab import output")
    print("    output.disable_custom_widget_manager()")
    from google.colab import output

    output.enable_custom_widget_manager()


def setup_debug_logger(name="cobalt_debug"):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    file_handler = logging.FileHandler(os.path.join(LOGS_FOLDER, f"{name}.log"), "w")
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    )
    file_handler.setLevel(logging.DEBUG)
    logger.addHandler(file_handler)
    return logger


def get_logger():
    logger = logging.getLogger("cobalt")
    if not logger.handlers:
        logger.propagate = 0
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        )
        logger.handlers.clear()
        logger.addHandler(handler)
        logging.addLevelName(
            logging.ERROR, f"\033[1;41m{logging.getLevelName(logging.ERROR)}\033[1;0m"
        )
        logger.setLevel(logging.INFO)
    return logger


def get_file_logger():
    logger = logging.getLogger("cobalt_file")
    if not logger.handlers:
        logger.propagate = 0
        handler = logging.FileHandler(LOG_FILENAME)
        handler.setFormatter(
            logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        )
        logger.handlers.clear()
        logger.addHandler(handler)
        logger.setLevel(logging.ERROR)
    return logger


class Notification(str, Enum):
    INFO = "info"
    ERROR = "error"
    WARNING = "warning"
    DEBUG = "debug"


def notify(msg, notification_type=Notification.ERROR):
    """Notifies the user about an error/warning/info without stopping the app.

    Produces log messages, which are stored in a separate log file.
    """
    logger = get_logger()
    map_log_level = {
        "error": logger.error,
        "info": logger.info,
        "warning": logger.warning,
        "debug": logger.debug,
    }

    map_log_level[notification_type](msg)


def notify_and_stop(msg):
    """Notify the user about a custom error and stop the app."""
    notify(msg)
    sys.exit(1)


def notify_callback_error(cb_name):
    msg = (
        f"Something went wrong while executing <{cb_name}> callback. "
        f"Please check the logs for more details: {LOG_FILENAME}"
    )
    logger = get_file_logger()
    logger.exception(f"Something went wrong while executing <{cb_name}> callback.")
    notify(msg)


def inspect_function(func: Callable, args, kwargs):
    """Get fuction params by type and log them."""
    try:
        function_path = f"{func.__module__}.{func.__name__}"

        message = f"Calling {function_path} with "
        if args:
            args_names = list(inspect.signature(func).parameters.keys())
            if "args" in args_names:
                args_names.remove("args")
            if "kwargs" in args_names:
                args_names.remove("kwargs")
            args_info = []
            for i, arg in enumerate(args):
                if i < len(args_names):
                    args_info.append(f"{args_names[i]}: {type(arg).__name__}")
                else:
                    args_info.append(f"{type(arg).__name__}")

            args_str = ", ".join(args_info)

            message = message + "args: " + args_str + " "
        if kwargs:
            kwargs_str = ", ".join(
                [f"{key}: {type(value)}" for key, value in kwargs.items()]
            )
            message = message + "kwargs: " + kwargs_str + " "

        message += "."
        debug_logger.info(message)
    except Exception as e:
        notify(f"Cannot parse function arguments {func.__name__} {e}")


class StopExecution(Exception):
    def _render_traceback_(self):
        return []


def _handle_cb_exceptions(func):
    """Decorator to handle exceptions in callbacks.

    When an exception is raised, shows a generic error message to the user and
    writes a traceback to a log file.
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if isinstance(e, LicenseError):
                message = e.args[0] if e.args else "Unknown License Error"
                show_license_exception(message)
                raise StopExecution from None
            else:
                notify_callback_error(func.__name__)

    return wrapper


def _handle_cb_exceptions_with_debugger(func):
    """Decorator to handle exceptions in callbacks.

    When an exception is raised, shows a generic error message to the user and
    writes a traceback to a log file.
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            inspect_function(func, args, kwargs)
            result = func(*args, **kwargs)
            debug_logger.info(f"{func.__name__} completed successfully.")
            return result
        except Exception:
            notify_callback_error(func.__name__)

    return wrapper


def show_license_exception(msg):
    import ipyvuetify as v
    import ipywidgets as widgets

    popup = widgets.Output()

    def show_message(message):
        with popup:
            # Clear previous content
            clear_output()
            # Display the message
            if is_colab_environment():
                from ipyvue import Html

                display(Html(tag="div", style_="display: none"))
            close_button = v.Btn(
                children=["Close"],
                density="compact",
                text=True,
                class_="mx-1",
            )
            close_button.on_event("click", close_message)
            display(
                v.Card(
                    children=[
                        v.CardTitle(children=["License key error"]),
                        v.CardText(children=[message]),
                        close_button,
                    ],
                    width="500",
                )
            )

    def close_message(*_):
        with popup:
            clear_output()

    show_message(msg)
    display(popup)


def check_license():
    """Check the configured license key and print the result."""
    check_license_manually()


def trivial_wrapper(func):
    """Wrapper that behaves like real decorators but doesn't catch exceptions."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wrapper


if os.getenv("DEBUG", "0") == "1":
    handle_cb_exceptions = _handle_cb_exceptions_with_debugger
elif os.getenv("RAISE_CB_EXC", "0") == "1":
    handle_cb_exceptions = trivial_wrapper
else:
    handle_cb_exceptions = _handle_cb_exceptions

USE_EXPERIMENTAL = os.getenv("USE_EXPERIMENTAL", "0") == "1"


CONFIG_WIDTH = 300
MAX_DRIFT_BINS = 1000

debug_logger = setup_debug_logger()
CONFIG_FILE_PATH = os.path.join(
    os.path.expanduser("~"), ".config", "cobalt", "cobalt.json"
)

REGISTER_API_URL = os.getenv(
    "COBALT_REGISTER_API_URL", "https://api.cobalt.bluelightai.com"
)

LAMBDA_VERSION = 4


def load_config():
    """Load the configuration from the JSON file, or.

    return a default structure if file does not exist.
    """
    if not os.path.exists(CONFIG_FILE_PATH):
        return {"api_keys": {}, "license_key": "", "config": {}}

    with open(CONFIG_FILE_PATH) as config_file:
        return json.load(config_file)


def save_config(config):
    """Save the configuration back to the JSON file or.

    create a new one.
    """
    directory = os.path.dirname(CONFIG_FILE_PATH)
    os.makedirs(directory, exist_ok=True)

    with open(CONFIG_FILE_PATH, "w") as config_file:
        json.dump(config, config_file, indent=4)


def console_log(message: str):
    """Log a Python message to the browser's console."""
    js_code = f'console.log("{message}");'
    display(Javascript(js_code))


class settings:
    """Settings that affect global behavior."""

    graph_use_rich_node_labels: bool = False
    """Default node hover label format for graphs.

    Setting this to True will allow for the use of larger, more expressive node labels.

    Note that to be applied, this setting must be changed before the graph is created.
    """

    graph_highlight_edges_on_hover: bool = False
    """Whether to highlight edges incident to the hovered node.

    Note that to be applied, this setting must be changed before the graph is created.
    """

    graph_decay_node_repulsion: bool = True
    """Whether to decay repulsive forces between nodes beyond a certain distance.

    Note that to be applied, this setting must be changed before the graph is created.
    """

    graph_prevent_node_overlaps: bool = True
    """Whether to prevent nodes in the graph from overlapping.

    This tends to produce more readable graphs, but the layout may be less responsive.

    Note that to be applied, this setting must be changed before the graph is created.
    """

    graph_layout_singletons_separately: bool = False
    """Whether to lay out singleton nodes in the graph separately from all other components.

    Note that to be applied, this setting must be changed before the graph is created.
    """

    # don't base64 encode more than 5MB worth of images in colab
    table_max_base64_total_size: int = (
        5_000_000 if is_colab_environment() else 20_000_000
    )
    """The maximum amount of image data to base64 encode in the table data payload."""

    # Colormap registry (class variables)
    _custom_categorical_colormaps: ClassVar[List[str]] = []
    _custom_numerical_colormaps: ClassVar[List[str]] = []
    _custom_colormap_objects: ClassVar[Dict[str, "matplotlib.colors.Colormap"]] = {}
    _custom_colormap_n_categories: ClassVar[Dict[str, int]] = {}

    @classmethod
    def register_colormap(
        cls,
        colormap: Union[str, "matplotlib.colors.Colormap"],
        name: Optional[str] = None,
        category: Literal["numerical", "categorical"] = "numerical",
        n_categories: Optional[int] = None,
    ):
        """Register a colormap to be available in the Cobalt UI.

        This function allows you to add matplotlib colormaps (either built-in or custom)
        to the Cobalt coloring options. You can pass either:
        - A string name of a matplotlib built-in colormap (e.g., "rainbow", "coolwarm")
        - A matplotlib colormap object (e.g., from LinearSegmentedColormap or ListedColormap)

        Args:
            colormap: Either a string name of a matplotlib colormap, or a matplotlib
                colormap object (Colormap instance from matplotlib.colors).
            name: The name to use for the colormap in the UI. Required if colormap is
                an object. If colormap is a string, this parameter is ignored and the
                string is used as the name.
            category: Either "numerical" or "categorical" to specify which type of
                data the colormap is designed for. Defaults to "numerical".
            n_categories: For categorical colormaps, the number of distinct categories
                the colormap supports. If not provided, will attempt to infer from the
                colormap's .N property (for colormap objects) or default to 10.

        Examples:
            >>> from cobalt import settings
            >>> from matplotlib.colors import LinearSegmentedColormap, ListedColormap
            >>>
            >>> # Register a built-in matplotlib colormap
            >>> settings.register_colormap("rainbow", category="numerical")
            >>> settings.register_colormap("coolwarm", category="numerical")
            >>>
            >>> # Register a custom gradient colormap
            >>> custom_gradient = LinearSegmentedColormap.from_list(
            ...     colors=[(0, 0, 0), (1, 0, 0)],
            ...     N=256
            ... )
            >>> settings.register_colormap(
            ...     custom_gradient, name="black-to-red", category="numerical"
            >>> )
            >>>
            >>> # Register a custom categorical colormap
            >>> custom_categorical = ListedColormap(
            ...     ["#FF6B6B", "#4ECDC4", "#45B7D1"],
            ... )
            >>> settings.register_colormap(
            ...     custom_categorical,
            ...     name="custom-categorical",
            ...     category="categorical",
            ...     n_categories=3
            >>> )
            >>>
            >>> # Registered colormaps will now be available in any Workspace UI created after this
        """
        if category not in ("numerical", "categorical"):
            raise ValueError(
                f"category must be 'numerical' or 'categorical', got {category}"
            )

        if isinstance(colormap, str):
            import matplotlib.pyplot as plt

            try:
                cmap_obj = plt.get_cmap(colormap)
            except ValueError as e:
                raise ValueError(
                    f"Colormap '{colormap}' not found in matplotlib's colormap library. "
                    f"Available colormaps can be listed with matplotlib.pyplot.colormaps(). "
                ) from e
            cmap_name = colormap
        else:
            cmap_obj = colormap
            if name is None:
                raise ValueError(
                    "When registering a colormap object, you must provide a 'name' parameter"
                )
            cmap_name = name
            # Store the colormap object for later retrieval
            cls._custom_colormap_objects[cmap_name] = colormap

        if category == "numerical":
            if cmap_name not in cls._custom_numerical_colormaps:
                cls._custom_numerical_colormaps.append(cmap_name)
        else:  # categorical
            if cmap_name not in cls._custom_categorical_colormaps:
                cls._custom_categorical_colormaps.append(cmap_name)

            # Try to infer n_categories if not provided
            if n_categories is None:
                # cap at 10 as a reasonable maximum if they pass in a continuous colormap
                n_categories = min(cmap_obj.N, 10) if hasattr(cmap_obj, "N") else 10

            cls._custom_colormap_n_categories[cmap_name] = n_categories

    @classmethod
    def _get_custom_numerical_colormaps(cls) -> Tuple[str, ...]:
        """Get the tuple of registered custom numerical colormaps."""
        return tuple(cls._custom_numerical_colormaps)

    @classmethod
    def _get_custom_categorical_colormaps(cls) -> Tuple[str, ...]:
        """Get the tuple of registered custom categorical colormaps."""
        return tuple(cls._custom_categorical_colormaps)

    @classmethod
    def _get_custom_colormap_objects(cls) -> Dict[str, "matplotlib.colors.Colormap"]:
        """Get the dictionary of registered custom colormap objects."""
        return cls._custom_colormap_objects.copy()

    @classmethod
    def _get_custom_colormap_n_categories(cls) -> Dict[str, int]:
        """Get the dictionary of n_categories for registered custom categorical colormaps."""
        return cls._custom_colormap_n_categories.copy()
