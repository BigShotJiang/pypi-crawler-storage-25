# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from typing import Any, Callable, Dict, List, Literal, Optional, Tuple, Union

import numpy as np
from mapper.cluster_tree import ClusterNode, ClusterTree
from mapper.clustering_scores import (
    make_local_negative_modularity_score_fn,
    make_local_score_fn,
    make_masked_negative_modularity_score_fn,
    scaled_gini_impurity,
    scaled_sample_entropy,
)
from mapper.flat_cluster import (
    optimize_cluster_score_dynamic_programming,
    optimize_cluster_score_top_down,
)

from cobalt.schema import CobaltDataSubset, HierarchicalCobaltGraph

# TODO: prune graph and redo clustering?
# TOOD: binned or differential entropy for continuous values?


def scaled_std(x: np.ndarray) -> float:
    return len(x) * np.std(x)


def scaled_mad(x: np.ndarray) -> float:
    return np.sum(np.abs(x - np.mean(x)))


def autogroup_modularity(
    graph: HierarchicalCobaltGraph,
    subset: Optional[CobaltDataSubset] = None,
    min_group_size: int = 1,
    max_group_size: int = np.inf,
    min_n_groups: int = 1,
    max_n_groups: int = 100,
    r: float = 0,
    algorithm: Literal["greedy", "global"] = "global",
    steer_vals: Optional[np.ndarray] = None,
    steer_objective: Union[
        Literal["std", "absolute_deviation", "entropy", "gini"],
        Callable[[np.ndarray], float],
    ] = "std",
    steer_weight: float = 1.0,
) -> Tuple[List[CobaltDataSubset], Dict[str, Any]]:
    """Find well-connected sets of nodes in a Mapper graph.

    Tries to maximize the modularity of the clustering for the graph, subject to
    constraints on the number of clusters and the cluster size.

    The modularity of a clustering, roughly speaking, measures how many edges in
    a graph stay inside of each cluster compared with what would happen in a
    completely random graph. Values closer to 1 indicate a better clustering,
    while values closer to 0 indicate that the clustering is not much different
    from random.

    Args:
        graph: A `HierarchicalCobaltGraph` built on the data to cluster.
        subset: An optional CobaltDataSubset containing a subset of the graph's data
            to run the clustering algorithm on. If None, runs the algorithm on
            all data points in the graph.
        min_group_size: The minimum size of a group to be returned.
        max_group_size: The maximum size of a group to be returned.
        min_n_groups: The minimum number of groups to return.
        max_n_groups: The maximum number of groups to return.
        r: A parameter controlling resolution. Higher values result in smaller clusters.
        algorithm: Which algorithm to use to try to find an optimal partition.
            If "greedy", uses an algorithm that greedily splits clusters until no
            improvement can be found. If "global", uses a slower method that finds
            the clustering that maximizes modularity.
        steer_vals: An optional array of values for each data point in the graph
            (or subset). If provided, this will be used to steer the clustering
            algorithm based on an auxiliary objective function.
        steer_objective: The objective function to use for steering. The
            clustering will attempt to minimize the sum of values of this function
            across clusters. May be a function accepting a Numpy array and returning
            a float, or one of:
                - "std": standard deviation of steer_vals, scaled by the cluster size
                - "absolute_deviation": sum of absolute differences between
                    steer_vals and mean(steer_vals)
                - "entropy": categorical entropy of steer_vals, scaled by the cluster size
                - "gini": quadratic Gini impurity score, scaled by the cluster size
        steer_weight: A parameter controlling the tradeoff between cluster
            modularity and the auxiliary objective function. A value of 0 means no
            weight is put on the auxiliary objective.

    Returns:
        A list of the discovered groups and a dictionary containing
        values of parameters that were used in the process.
    """
    hierarchical_graph = graph._graph
    graph_data = graph.subset

    if subset is None:
        subset = graph_data

    if subset == graph_data:
        # TODO: go down to a level with all nodes at most as large as min_group_size
        cluster_tree = ClusterTree.from_graph_with_constraints(
            hierarchical_graph, max_n_clusters=len(subset) / min_group_size
        )
        modularity_score = make_local_negative_modularity_score_fn(
            hierarchical_graph.base_graph, modularity_r=r
        )
    else:
        try:
            subset_mask = subset.as_mask_on(graph_data)
        except ValueError:
            raise ValueError("subset must be a subset of graph_data.") from None
        subset_graph_indices = np.flatnonzero(subset_mask)

        cluster_tree = ClusterTree.from_subgraph_with_constraints(
            hierarchical_graph,
            subset_graph_indices,
            max_n_clusters=len(subset) / min_group_size,
        )
        modularity_score = make_masked_negative_modularity_score_fn(
            hierarchical_graph.base_graph, subset_mask, r=r
        )

    local_score_fns = [modularity_score]
    if steer_vals is not None:
        if callable(steer_objective):
            base_score_fn = steer_objective
        if steer_objective == "std":
            base_score_fn = scaled_std
        elif steer_objective == "absolute_deviation":
            base_score_fn = scaled_mad
        elif steer_objective == "entropy":
            base_score_fn = scaled_sample_entropy
        else:
            base_score_fn = scaled_gini_impurity

        local_score_fn = make_local_score_fn(steer_vals, base_score_fn)

        def scaled_local_score_fn(x: ClusterNode) -> Tuple[float, float]:
            score, score_diff = local_score_fn(x)
            return steer_weight * score, steer_weight * score_diff

        local_score_fns.append(scaled_local_score_fn)

    if algorithm == "greedy":
        modularity_clusters = optimize_cluster_score_top_down(
            cluster_tree,
            local_score_fns=local_score_fns,
            min_cluster_size=min_group_size,
            max_cluster_size=max_group_size,
            max_n_clusters=max_n_groups,
            min_n_clusters=min_n_groups,
        )
    else:
        modularity_clusters = optimize_cluster_score_dynamic_programming(
            cluster_tree,
            local_score_fns=local_score_fns,
            min_cluster_size=min_group_size,
            max_cluster_size=max_group_size,
            max_n_clusters=max_n_groups,
            min_n_clusters=min_n_groups,
        )

    groups = [graph_data.subset(indices) for indices in modularity_clusters]

    params = {
        "graph_data": graph_data,
        "graph": graph,
        "min_clusters": min_n_groups,
        "max_clusters": max_n_groups,
        "min_size": min_group_size,
    }

    return groups, params
