from __future__ import annotations

from typing import TYPE_CHECKING, List, Literal, Optional, Union

from cobalt.api_wrapper import get_default_api_client
from cobalt.schema.dataset import CobaltDataSubset

if TYPE_CHECKING:
    from cobalt.schema.group import GroupMetadata

# ruff: noqa: E501
task_desc = """You are a meticulous machine learning researcher analyzing a dataset of texts. Your goal is to identify a property that distinguishes two groups of texts from one another.

You will be given a sample of texts from Group A, and a sample of texts from Group B, and will need to identify a property that is present in the texts from Group A but not present in the texts from Group B.

"""

keyword_desc = """You are also given a list of key terms that are more prevalent in Group A than in Group B.

"""

groups_fmt = """Group A:
--------
{positive_samples}
--------

Group B:
--------
{negative_samples}
--------

"""

keywords_fmt = """Key Terms for Group A:
--------
{keywords}
--------

"""

task_rules = """Rules about the property you identify:
- The property you identify should be present in all or nearly all of the texts from Group A, and not present at all in the texts from Group B. Do not select a property that also occurs in Group B.
- Keep the descriptions as brief and simple as possible while still accurately describing the property. For instance, say "discusses American football" instead of "discusses concepts associated with American football, including teams, players, scores, and games". Avoid extending the description with unnecessary examples.
- However, make sure that the description is as precise as possible. If all texts in both groups talk about electronic components, but Group A specifically mentions only passive components like resistors,  capacitors, or inductors, say "mentions passive electronic components" instead of "mentions electronic components".
- The property should be worded as the completion of a sentence beginning "Each text in Group A". For instance, say "uses florid metaphorical language to describe common situations" instead of "The texts in Group A use metaphorical language to describe common situations".

Do not output anything besides the description. Please suggest exactly one description.

Your description follows: "Each document in Group A
"""


def build_prompt_for_group_comparison(
    group: GroupMetadata,
    reference_subset: CobaltDataSubset,
    column: str,
    n_samples: int = 10,
    seed: int = 5,
    sample_length: int = 250,
    use_keywords: bool = True,
):
    positive_subset = group.subset.sample(n_samples, seed)
    negative_subset = reference_subset.sample(n_samples, seed)
    positive_texts = positive_subset.select_col(column)
    negative_texts = negative_subset.select_col(column)
    positive_samples = "\n\n".join(
        f'"{sample[:sample_length]}"' for sample in positive_texts
    )
    negative_samples = "\n\n".join(
        f'"{sample[:sample_length]}"' for sample in negative_texts
    )
    groups_segment = groups_fmt.format(
        positive_samples=positive_samples, negative_samples=negative_samples
    )

    if use_keywords and group.keywords[column]:
        keywords = group.keywords[column].get_keyword_string(
            n_keywords=10, min_match_rate=0.3
        )
        prompt = (
            task_desc
            + keyword_desc
            + groups_segment
            + keywords_fmt.format(keywords=keywords)
            + task_rules
        )
    else:
        prompt = task_desc + groups_segment + task_rules
    return prompt


def parse_descriptions(response):
    descriptions = []
    for choice in response.choices:
        description = choice.message.content.strip()
        if description.startswith("- "):
            description = description[2:]
        if description.startswith('"-'):
            description = description[2:]
        if description.startswith('" -'):
            description = description[3:]
        if description.lower().startswith("each document in group a "):
            description = description[len("each document in group a ") :]
        description = description.strip('"').strip().strip(".")
        descriptions.append(description)
    return descriptions


def compare_groups_prompted(
    group: GroupMetadata,
    reference_subset: Union[CobaltDataSubset, Literal["rest"]],
    column: str,
    n_samples: int = 10,
    max_sample_length: int = 250,
    model: Optional[str] = None,
    seed: int = 5,
    n_responses: int = 1,
    n_prompts: int = 1,
) -> List[str]:
    if reference_subset == "rest":
        reference_subset = group.subset.complement()

    prompts = [
        build_prompt_for_group_comparison(
            group,
            reference_subset,
            column,
            n_samples,
            sample_length=max_sample_length,
            seed=seed + i,
        )
        for i in range(n_prompts)
    ]

    client = get_default_api_client()
    responses = client.parallel_prompt(
        messages=[[{"role": "user", "content": prompt}] for prompt in prompts],
        model=model,
        timeout=15,
        temperature=0.7,
        n=n_responses,
    )
    descriptions = []
    for response in responses:
        descriptions.extend(parse_descriptions(response))
    return descriptions
