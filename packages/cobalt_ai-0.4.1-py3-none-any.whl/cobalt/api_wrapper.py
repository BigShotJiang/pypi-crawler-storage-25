import concurrent.futures
import getpass
import os
from typing import TYPE_CHECKING, ClassVar, Dict, List, Optional, Type, Union, cast

from cobalt.config import is_vscode, load_config, save_config

if TYPE_CHECKING:
    import openai


class _SessionDefaults:
    """Namespace for session-level defaults (not persisted across sessions)."""

    default_provider: ClassVar[Optional[str]] = None
    provider_default_models: ClassVar[Dict[str, str]] = {}  # provider -> model mapping

    @classmethod
    def reset(cls) -> None:
        """Reset all session defaults to their initial state."""
        cls.default_provider = None
        cls.provider_default_models = {}


class AnyAPIWrapper:
    """Base class for API wrappers.

    Provides common functionality for API clients that support prompt-based
    interactions with language models.
    """

    def __init__(self, api_key: Optional[str] = None):
        """Initialize the API wrapper.

        Args:
            api_key: Authentication key for the API.

        Raises:
            ValueError: If api_key is not provided.
        """
        if not api_key:
            raise ValueError("API key is required")
        self.api_key = api_key

    @property
    def name(self) -> str:
        """Return the name of this wrapper."""
        return "API Wrapper"

    def __repr__(self) -> str:
        return self.name

    def prompt(
        self,
        messages: List[Dict],
        model: Optional[str] = None,
        **kwargs,
    ):
        """Send a prompt to the API and return the response.

        Subclasses must implement this method.

        Args:
            messages: List of message dictionaries with 'role' and 'content'.
            model: Model name to use for generation.
            **kwargs: Additional arguments to pass to the API.

        Raises:
            NotImplementedError: If not implemented by subclass.
        """
        raise NotImplementedError("Subclasses must implement prompt()")

    def parallel_prompt(
        self,
        messages: List[List[Dict]],
        model: Optional[str] = None,
        **kwargs,
    ):
        """Send multiple prompts in parallel.

        Subclasses must implement this method.

        Args:
            messages: List of message lists.
            model: Model name to use for generation.
            **kwargs: Additional arguments to pass to the API.

        Raises:
            NotImplementedError: If not implemented by subclass.
        """
        raise NotImplementedError("Subclasses must implement parallel_prompt()")

    @classmethod
    def validate_api_key(cls, api_key: str) -> bool:
        """Validate an API key.

        Default implementation returns True (no validation).
        Subclasses can override to implement provider-specific validation.

        Args:
            api_key: The API key to validate.

        Returns:
            True if the key is valid, False otherwise.
        """
        return True


class OpenAIWrapper(AnyAPIWrapper):
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        super().__init__(api_key)
        self.base_url = base_url or "https://api.openai.com/v1"
        self.raw_client = self._get_raw_client()

    @property
    def name(self) -> str:
        return "OpenAI API Wrapper"

    def __repr__(self) -> str:
        return self.name

    @classmethod
    def validate_api_key(cls, api_key: str) -> bool:
        """Validate an OpenAI API key.

        Args:
            api_key: The API key to validate.

        Returns:
            True if the key is valid, False otherwise.
        """
        try:
            from openai import AuthenticationError, OpenAI

            client = OpenAI(api_key=api_key)
            client.models.list()
            return True
        except AuthenticationError:
            return False

    def _get_raw_client(self):
        try:
            from openai import OpenAI

        except ImportError:
            raise ImportError(
                "The OpenAI API package must be installed to use LLM-backed functionality. "
                "Run `pip install openai` and make sure your API key is configured "
                "by running cobalt.setup_api_client()."
            ) from None

        try:
            client = OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                timeout=60.0,  # Set reasonable default timeout for client
            )
        except Exception as e:
            raise ValueError(f"Error while initializing OpenAI client: {e}") from e
        else:
            return client

    def prompt(
        self,
        messages: List[Dict],
        model: Optional[str] = None,
        max_retries: int = 5,
        **kwargs,
    ) -> "openai.types.Completion":
        """Creates a model response for the given chat conversation.

        Uses exponential backoff to avoid overloading the API.

        Args:
            messages: The messages to send to the model.
            model: The model to use. If None, uses the configured default model.
                List of models: https://platform.openai.com/docs/models#model-endpoint-compatibility
            max_retries: The maximum number of API retries to make before failing.
            timeout: The timeout for the request in seconds.
            kwargs: Will be passed to the OpenAI SDK call.

        Returns:
            A string containing the conversation response.
        """
        if model is None:
            model = get_default_api_model("openai")
            if model is None:
                raise ValueError(
                    "No model specified and no default configured. "
                    "Please configure a default model with "
                    "set_default_api_model('model', 'openai', persistent=True) or "
                    "pass a model parameter."
                )

        completion = self.raw_client.with_options(
            max_retries=max_retries
        ).chat.completions.create(
            model=model,
            messages=messages,
            **kwargs,
        )
        return completion

    def parallel_prompt(
        self,
        messages: List[List[Dict]],
        model: Optional[str] = None,
        max_retries: int = 5,
        **kwargs,
    ) -> List["openai.types.Completion"]:
        if model is None:
            model = get_default_api_model("openai")
            if model is None:
                raise ValueError(
                    "No model specified and no default configured. "
                    "Please configure a default model with "
                    "set_default_api_model('model', 'openai', persistent=True) or "
                    "pass a model parameter."
                )

        if len(messages) == 1:
            return [
                self.prompt(
                    messages=messages[0],
                    model=model,
                    max_retries=max_retries,
                    **kwargs,
                )
            ]

        results = []
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [
                executor.submit(
                    self.prompt,
                    messages=message,
                    model=model,
                    max_retries=max_retries,
                    **kwargs,
                )
                for message in messages
            ]
            for idx, future in enumerate(futures):
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    raise RuntimeError(
                        f"Error occurred for task {idx} in parallel_prompt()."
                    ) from e
        return results


class CustomOpenAICompatibleWrapper(OpenAIWrapper):
    """Wrapper for custom OpenAI-compatible API providers.

    This allows using any server that implements the OpenAI chat completions API
    by specifying a custom base URL.
    """

    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        if not base_url:
            raise ValueError(
                "base_url is required for custom OpenAI-compatible providers"
            )
        super().__init__(api_key=api_key, base_url=base_url)

    @property
    def name(self) -> str:
        return f"Custom OpenAI-Compatible API (URL: {self.base_url})"

    def __repr__(self) -> str:
        return self.name

    @classmethod
    def validate_api_key(cls, api_key: str) -> bool:
        """Validate a custom provider API key.

        For custom providers, we cannot reliably determine if a key is valid
        for arbitrary providers, so we only enforce that the key is non-empty.

        Args:
            api_key: The API key to validate.

        Returns:
            True if the key is non-empty (after stripping whitespace),
            otherwise False.
        """
        return bool(api_key and api_key.strip())

    def prompt(
        self,
        messages: List[Dict],
        model: Optional[str] = None,
        max_retries: int = 5,
        **kwargs,
    ) -> "openai.types.Completion":
        """Creates a model response for the given chat conversation.

        If model is not specified, uses the configured default_model.

        Args:
            messages: The messages to send to the model.
            model: The model to use. If None, uses provider-level default.
            max_retries: The maximum number of API retries to make before failing.
            timeout: The timeout for the request in seconds.
            kwargs: Will be passed to the OpenAI SDK call.

        Returns:
            A string containing the conversation response.
        """
        if model is None:
            model = get_default_api_model("custom")
            if model is None:
                raise ValueError(
                    "No model specified and no default configured. "
                    "Please configure a default model with "
                    "set_default_api_model('model', 'custom', persistent=True), set "
                    "a default during setup_api_client(), or pass a model parameter."
                )

        return super().prompt(
            messages=messages,
            model=model,
            max_retries=max_retries,
            **kwargs,
        )

    def parallel_prompt(
        self,
        messages: List[List[Dict]],
        model: Optional[str] = None,
        max_retries: int = 5,
        **kwargs,
    ) -> List["openai.types.Completion"]:
        """Execute multiple prompts in parallel.

        If model is not specified, uses the configured default_model.

        Args:
            messages: List of message lists to send to the model.
            model: The model to use. If None, uses provider-level default.
            max_retries: The maximum number of API retries to make before failing.
            timeout: The timeout for the request in seconds.
            kwargs: Will be passed to the OpenAI SDK call.

        Returns:
            List of completion responses.
        """
        if model is None:
            model = get_default_api_model("custom")
            if model is None:
                raise ValueError(
                    "No model specified and no default configured. "
                    "Please configure a default model with "
                    "set_default_api_model('model', 'custom', persistent=True), set "
                    "a default during setup_api_client(), or pass a model parameter."
                )

        return super().parallel_prompt(
            messages=messages,
            model=model,
            max_retries=max_retries,
            **kwargs,
        )


def set_default_api_provider(provider: str, persistent: bool = False) -> None:
    """Set the default API provider.

    Args:
        provider: The API provider name (e.g., 'openai', 'custom').
        persistent: If True, saves to config file. If False, session-only.

    Example:
        >>> set_default_api_provider('custom', persistent=True)
        >>> set_default_api_provider('openai')  # session-only
    """
    if provider not in API_CLIENT_MAP:
        raise ValueError(
            f"Unknown provider '{provider}'. "
            f"Valid options: {list(API_CLIENT_MAP.keys())}"
        )

    if persistent:
        config = load_config()
        config["default_provider"] = provider
        save_config(config)

    _SessionDefaults.default_provider = provider


def set_default_api_model(
    model: str, provider: str = "openai", persistent: bool = False
) -> None:
    """Set the default model name for a specific API provider.

    Args:
        model: The model name (e.g., 'gpt-4.1', 'gemma3:1b').
        provider: The API provider name (e.g., 'openai', 'custom').
        persistent: If True, saves to config file. If False, session-only.

    Example:
        >>> set_default_api_model('gpt-4.1-mini', 'openai', persistent=True)
        >>> set_default_api_model('llama3:8b', 'custom')  # session-only
    """
    if provider not in API_CLIENT_MAP:
        raise ValueError(
            f"Unknown provider '{provider}'. "
            f"Valid options: {list(API_CLIENT_MAP.keys())}"
        )

    if persistent:
        config = load_config()
        if "provider_default_models" not in config:
            config["provider_default_models"] = {}
        config["provider_default_models"][provider] = model
        save_config(config)

    _SessionDefaults.provider_default_models[provider] = model


def get_default_api_provider() -> Optional[str]:
    """Get the current default API provider.

    Checks session default first, then persistent config.

    Returns:
        The default provider name, or None if not configured.
    """
    if _SessionDefaults.default_provider is not None:
        return _SessionDefaults.default_provider

    config = load_config()
    return config.get("default_provider")


def get_default_api_model(provider: str = "openai") -> Optional[str]:
    """Get the current default model name for a specific API provider.

    Checks in order: environment variable, session default, persistent config,
    provider's built-in default.

    Args:
        provider: The API provider name (e.g., 'openai', 'custom').

    Returns:
        The default model name, or None if not configured.
    """
    # Check environment variable first (if provider has one configured)
    provider_config = API_CLIENT_MAP.get(provider)
    if provider_config:
        env_var_name = provider_config.get("default_model_env_var")
        if env_var_name:
            env_value = os.getenv(cast(str, env_var_name))
            if env_value:
                return env_value

    # Check session default
    if provider in _SessionDefaults.provider_default_models:
        return _SessionDefaults.provider_default_models[provider]

    # Check persistent config
    config = load_config()
    provider_defaults = config.get("provider_default_models", {})
    configured_default = provider_defaults.get(provider)
    if configured_default:
        return configured_default

    # Fall back to provider's built-in default (can be None)
    if provider_config:
        return cast(Optional[str], provider_config.get("default_model"))

    return None


def get_default_api_client() -> AnyAPIWrapper:
    """Get an API client using the configured default provider.

    If no default provider is configured, uses 'openai'.

    Returns:
        An initialized API client wrapper.

    Example:
        >>> set_default_api_provider('custom')
        >>> client = get_default_api_client()
        >>> client.prompt([{"role": "user", "content": "Hello"}])
    """
    provider = get_default_api_provider() or "openai"
    return get_api_client(provider)


API_CLIENT_MAP = {
    "openai": {
        "cls": OpenAIWrapper,
        "env_var_name": "OPENAI_API_KEY",
        "default_model_env_var": "OPENAI_DEFAULT_MODEL",
        "default_model": "gpt-5-mini",  # Built-in fallback default
    },
    "custom": {
        "cls": CustomOpenAICompatibleWrapper,
        "env_var_name": "CUSTOM_OPENAI_API_KEY",
        "base_url_env_var": "CUSTOM_OPENAI_BASE_URL",
        "default_model_env_var": "CUSTOM_OPENAI_DEFAULT_MODEL",
        "default_model": None,  # Must be configured by user
        "requires_base_url": True,
    },
}


def setup_api_client():
    """Set up the API client by updating or adding the API key to the JSON config file."""
    config = load_config()
    if is_vscode():
        print(
            "Please enter your API configuration in the input field at the top of the window \u2191"
        )

    api_name = input(
        f"Choose API client type from the list: {list(API_CLIENT_MAP.keys())}: "
    ).strip()
    if not api_name:
        api_name = next(iter(API_CLIENT_MAP.keys()))
    api_client_config = API_CLIENT_MAP.get(api_name)

    if not api_client_config:
        raise ValueError(
            f"Unrecognized API client name. Valid names are: {list(API_CLIENT_MAP.keys())}"
        )

    try:
        import openai  # noqa: F401
    except ImportError:
        print("OpenAI API not installed. Run `pip install openai` before proceeding.")

    valid = False
    api_client_env_name = cast(str, api_client_config["env_var_name"])
    requires_base_url = api_client_config.get("requires_base_url", False)
    built_in_default = api_client_config.get("default_model")

    # Get base URL if required
    base_url = None
    default_model = None

    if requires_base_url:
        base_url = input(
            f"Enter the base URL for {api_name} "
            "(should be OpenAI-compatible, e.g. https://api.example.com/v1): "
        ).strip()
        if not base_url:
            raise ValueError("Base URL is required for custom providers")

    # Ask about default model configuration
    if built_in_default:
        # Provider has a built-in default
        set_custom_default = (
            input(
                f"Do you want to set a custom default model for {api_name}? "
                f"(built-in default: {built_in_default}) (yes/no): "
            )
            .strip()
            .lower()
        )
        if set_custom_default.startswith("y"):
            default_model = input("Enter the default model name: ").strip() or None
    else:
        # Provider requires user to set a default
        default_model = (
            input(
                f"Enter the default model name for {api_name} "
                f"(e.g., llama3:8b, gemma3:1b): "
            ).strip()
            or None
        )

    if api_name != get_default_api_provider():
        set_provider_as_default = (
            input("Do you want to make this provider the default? (yes/no)")
            .strip()
            .lower()
            .startswith("y")
        )
        if set_provider_as_default:
            set_default_api_provider(api_name, persistent=True)

    while not valid:
        api_key = getpass.getpass(f"Enter your valid API KEY for {api_name}: ").strip()

        # Get the wrapper class and validate the key
        api_client_cls = cast(
            Type[Union[OpenAIWrapper, CustomOpenAICompatibleWrapper]],
            api_client_config["cls"],
        )
        if api_client_cls.validate_api_key(api_key):
            print("API token is valid")
            valid = True
        else:
            print("API token is invalid")

    # Initialize api_base_urls and provider_default_models sections if they don't exist
    if "api_base_urls" not in config:
        config["api_base_urls"] = {}
    if "provider_default_models" not in config:
        config["provider_default_models"] = {}

    # Check if the API key already exists in the config
    if api_client_env_name in config["api_keys"]:
        overwrite = (
            input(
                f"API key for {api_name} already exists. Do you want to overwrite it? (yes/no): "
            )
            .strip()
            .lower()
        )
        if overwrite.startswith("y"):
            config["api_keys"][api_client_env_name] = api_key
            if base_url:
                config["api_base_urls"][api_client_env_name] = base_url
            if default_model:
                config["provider_default_models"][api_name] = default_model
            print(f"API key for {api_name} was updated.")
        else:
            print(f"API key for {api_name} was not updated.")
    else:
        # Add new API key to the config
        config["api_keys"][api_client_env_name] = api_key
        if base_url:
            config["api_base_urls"][api_client_env_name] = base_url
        if default_model:
            config["provider_default_models"][api_name] = default_model
        print(f"API key for {api_name} saved.")

    # Save the updated config back to the JSON file
    save_config(config)


def get_api_client(
    api_name: str = "openai",
) -> Union[OpenAIWrapper, CustomOpenAICompatibleWrapper]:
    """Get the API client by loading the API key from JSON config or env variables."""
    config = load_config()  # Load existing config from JSON

    api_client_config = API_CLIENT_MAP.get(api_name)
    if not api_client_config:
        raise ValueError(
            f"Unrecognized API client type {api_name} requested. "
            f"Valid names are: {list(API_CLIENT_MAP.keys())}"
        )

    api_client_cls: Type[Union[OpenAIWrapper, CustomOpenAICompatibleWrapper]] = cast(
        Type[Union[OpenAIWrapper, CustomOpenAICompatibleWrapper]],
        api_client_config["cls"],
    )
    api_client_env_name: str = cast(str, api_client_config["env_var_name"])
    requires_base_url: bool = cast(
        bool, api_client_config.get("requires_base_url", False)
    )

    # Try to get the API key from the JSON config first
    api_key = config["api_keys"].get(api_client_env_name)

    # Check if the API key is set in the environment variables
    api_key_from_env = os.getenv(api_client_env_name)
    if not api_key and not api_key_from_env:
        raise ValueError(
            "To use LLM-backed functionality, you need to configure your API key first. "
            "Please run cobalt.setup_api_client() "
            f"or set the {api_client_env_name} environment variable."
        )

    # If the environment variable is set, it overrides the config file key
    if api_key_from_env:
        api_key = api_key_from_env

    # Handle base URL for custom providers
    if requires_base_url:
        base_url_env_var = cast(
            Optional[str], api_client_config.get("base_url_env_var")
        )

        # Try to get base URL from config
        base_url = config.get("api_base_urls", {}).get(api_client_env_name)
        # Environment variable overrides config
        base_url_from_env = os.getenv(base_url_env_var) if base_url_env_var else None
        if base_url_from_env:
            base_url = base_url_from_env

        if not base_url:
            raise ValueError(
                f"Base URL is required for {api_name}. "
                "Please run cobalt.setup_api_client() "
                f"or set the {base_url_env_var} environment variable."
            )

        # If base URL is required, we're creating CustomOpenAICompatibleWrapper
        # Note: default model is retrieved via get_default_api_model() in prompt methods
        custom_cls = cast(Type[CustomOpenAICompatibleWrapper], api_client_cls)
        return custom_cls(api_key=api_key, base_url=base_url)

    return api_client_cls(api_key=api_key)
