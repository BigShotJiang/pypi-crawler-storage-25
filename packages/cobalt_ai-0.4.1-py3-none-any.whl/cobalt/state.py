# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from __future__ import annotations

from typing import Dict, Literal, Optional, Union
from uuid import uuid4

from cobalt.cobalt_types import GroupType
from cobalt.config import get_logger, handle_cb_exceptions
from cobalt.event_bus import EventBusController, GraphEvent, GroupEvent
from cobalt.repositories.graph_repository import GraphRepository, GraphRepositoryEntry
from cobalt.repositories.groups_repository import GroupRepository
from cobalt.repositories.run_repository import (
    GroupResultsCollection,
    GroupResultsCollectionRepository,
)
from cobalt.schema import CobaltDataset, CobaltDataSubset, DatasetSplit
from cobalt.schema.dataset_collection import DatasetCollection
from cobalt.schema.group import GroupMetadata
from cobalt.schema.metadata import collect_columns_metadata

logger = get_logger()


class State:
    def __init__(self, dataset: CobaltDataset, split: DatasetSplit, workspace_id=None):
        # Always create a DatasetCollection with primary dataset and split
        self.dataset_collection = DatasetCollection(dataset, split)
        self.workspace_id = workspace_id
        self.group_repo: GroupRepository = GroupRepository()
        self.graph_repo: GraphRepository = GraphRepository()
        self.run_repo: GroupResultsCollectionRepository = (
            GroupResultsCollectionRepository()
        )
        self.graph_event_bus = EventBusController.get_graph_event_bus(self.workspace_id)
        self.group_event_bus = EventBusController.get_group_event_bus(self.workspace_id)
        self.run_event_bus = EventBusController.get_run_event_bus(self.workspace_id)
        self.dataset_event_bus = EventBusController.get_dataset_event_bus(
            self.workspace_id
        )
        # for compatibility, we'll get rid of this once we've replaced the drift
        # plot and drift score coloring
        self.workspace_id = workspace_id if workspace_id else uuid4()

        self.metrics_data: Dict = {
            "all": {},
            "graph": {},
            "groups": {},
            "failure_groups": {},
        }
        self.coloring_menu: Dict = {
            "selector_dropdown_value": None,
            "selector_cmap_value": None,
        }

    @property
    def dataset(self) -> CobaltDataset:
        """Return the primary dataset for backward compatibility."""
        return self.dataset_collection.primary

    @property
    def split(self) -> DatasetSplit:
        """Return the primary dataset's split for backward compatibility."""
        primary_name = self.dataset_collection.primary.name
        return self.dataset_collection.splits[primary_name]

    # GroupsRepository
    def get_groups_info(self):
        return self.group_repo.get_groups_info()

    def add_group(
        self,
        group: CobaltDataSubset,
        group_name: str,
        compute_stats: bool = True,
        description: Optional[str] = None,
        metadata: Optional[GroupMetadata] = None,
        notify=True,
    ):
        if metadata:
            self.group_repo.add_group(group, group_name, metadata)
        else:
            metadata = GroupMetadata(group, group_name, description=description)
            if compute_stats:
                metadata.compute_comparison_stats(
                    "rest", set_description_string=description is None
                )
                metadata.compute_feature_bounds()
                if self.dataset.model:
                    metadata.add_model_data_histograms(self.dataset.model)
                    metadata.metrics = self.dataset.model.overall_performance_metrics(
                        group
                    )
            self.group_repo.add_group(group, group_name, metadata)
        if notify:
            event = GroupEvent(
                event_type="added",
                group_name=group_name,
                workspace_id=str(self.workspace_id),
            )
            self.group_event_bus.run_all(event)

    def add_groups(self, groups):
        self.group_repo.add_groups(groups)
        # Pass generic event since we don't know which specific group
        event = GroupEvent(
            event_type="added",
            group_name="multiple",
            workspace_id=str(self.workspace_id),
        )
        self.group_event_bus.run_all(event)

    def rename_group(self, new_name: str, old_name: str, notify=True):
        self.group_repo.rename_group(new_name=new_name, old_name=old_name)
        if notify:
            event = GroupEvent(
                event_type="renamed",
                group_name=new_name,
                workspace_id=str(self.workspace_id),
                old_name=old_name,
            )
            self.group_event_bus.run_all(event)

    def get_group(self, group_name: str):
        return self.group_repo.get_group(group_name)

    def get_group_metadata(self, group_name: str):
        return self.group_repo.get_group_metadata(group_name)

    def get_groups(self):
        return self.group_repo.get_groups()

    def get_groups_metadata(self):
        return self.group_repo.get_groups_metadata()

    def delete_group(self, group_name: str, notify=True):
        self.group_repo.delete_group(group_name)
        if notify:
            event = GroupEvent(
                event_type="deleted",
                group_name=group_name,
                workspace_id=str(self.workspace_id),
            )
            self.group_event_bus.run_all(event)

    def is_group_name_unique(self, group_name: str):
        return self.group_repo.is_group_name_unique(group_name)

    def has_name_among_failure_groups(self, group_name: str):
        """Check problem group unique name in the specific run."""
        # TODO: remove group_type argument when we can show multiple group types
        visible_runs = self.run_repo.get_runs(
            group_type=GroupType.failure, run_visible=True
        )
        result = False
        for run_name in visible_runs:
            result = result and not self.run_repo.is_name_unique_problem_groups(
                run_name, group_name
            )
        return result

    def add_graph(self, graph, graph_name: str):
        """Updates an entry in the graph repository and triggers listeners.

        Args:
            graph: A dict with 'cobalt_graph' and 'landscape_params' keys
            graph_name: Name for the graph
        """
        cobalt_graph = graph["cobalt_graph"]
        landscape_params = graph["landscape_params"]
        self.graph_repo.add_graph(
            cobalt_graph=cobalt_graph,
            landscape_params=landscape_params,
            graph_name=graph_name,
        )
        event = GraphEvent(
            event_type="added",
            graph_name=graph_name,
            workspace_id=str(self.workspace_id),
        )
        self.graph_event_bus.run_all(event)

    def get_graphs(self):
        return self.graph_repo.get_graphs()

    def get_graph_entry(self, graph_name: str) -> GraphRepositoryEntry:
        return self.graph_repo.get_graph_entry(graph_name=graph_name)

    def update_graph(self, graph, graph_name: str):
        """Updates an entry in the graph repository and triggers listeners.

        Args:
            graph: A dict with 'cobalt_graph' and 'landscape_params' keys
            graph_name: Name for the graph
        """
        cobalt_graph = graph["cobalt_graph"]
        landscape_params = graph["landscape_params"]
        self.graph_repo.update_graph(
            cobalt_graph=cobalt_graph,
            landscape_params=landscape_params,
            graph_name=graph_name,
        )
        event = GraphEvent(
            event_type="updated",
            graph_name=graph_name,
            workspace_id=str(self.workspace_id),
        )
        self.graph_event_bus.run_all(event)

    def add_run(self, run: GroupResultsCollection):
        self.run_repo.add_run(run)

    def collect_metrics_for_current_run(self, run: GroupResultsCollection):
        for fg in run.groups:
            self.collect_metrics(
                field="failure_groups", group_id=fg.name, dataset=fg.subset
            )

    @handle_cb_exceptions
    def collect_metrics(
        self,
        dataset: Union[CobaltDataset, CobaltDataSubset],
        field: Literal["all", "graph", "groups", "failure_groups"],
        group_id: Optional[str] = None,
    ):
        """Calculate metrics for given group or whole dataset."""
        # Check that dataset.model is setup
        model = dataset.model
        # Work around B018 linter error
        if not model:
            return

        if model.outcome_column is None or model.prediction_column is None:
            self.metrics_data[field] = {}
            return

        result = dataset.overall_model_performance_scores(model_index=0)
        if group_id:
            self.metrics_data[field][group_id] = result
        else:
            self.metrics_data[field] = result

        return result

    @property
    def metadata(self):
        return self.dataset.metadata

    def get_subset(
        self, subset: Union[str, CobaltDataSubset, CobaltDataset]
    ) -> CobaltDataSubset:
        if isinstance(subset, str):
            return self.split.get(subset, None) or self.get_group(subset)
        elif isinstance(subset, CobaltDataset):
            return subset.as_subset()
        else:
            return subset

    def update_column_metadata(self, categorical_max_unique_count=10):
        self.dataset.metadata.data_types = collect_columns_metadata(
            self.dataset.df, categorical_max_unique_count
        )
