from __future__ import annotations

from typing import Any, Dict, Literal, Optional, Tuple, Union, overload

import numpy as np
import pandas as pd
import scipy.sparse as sp

from cobalt.schema.dataset import CobaltDataset, CobaltDataSubset
from cobalt.serialization import SerializableWithDatasetsMixin

AggFnName = Literal["mean", "sum", "max", "min", "count", "nunique", "mode"]


def _get_valid_mask(values: np.ndarray) -> np.ndarray:
    """Return boolean mask for non-missing values across dtypes."""
    if np.issubdtype(values.dtype, np.datetime64):
        return ~np.isnat(values.astype("datetime64[ns]"))
    if np.issubdtype(values.dtype, np.number):
        return ~np.isnan(values.astype("float64", copy=False))
    return pd.notna(values)


def _filter_missing_values(values: np.ndarray) -> np.ndarray:
    """Filter out missing values (NaN/NaT/None) from an array."""
    return values[_get_valid_mask(values)]


def _get_numeric_safe_values_and_mask(
    values: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """Return numeric float values with missing replaced by 0 and a valid mask."""
    numeric_values = values.astype("float64", copy=False)
    valid_mask = ~np.isnan(numeric_values)
    safe_values = np.where(valid_mask, numeric_values, 0.0)
    return safe_values, valid_mask


def _aggregate_via_links(
    link_mtx: sp.csr_array,
    values: np.ndarray,
    agg_fn: AggFnName,
    ignore_missing: bool = True,
) -> np.ndarray:
    """Aggregate values through a link matrix.

    Args:
        link_mtx: Sparse matrix where link_mtx[i,j] represents link from row i to value j
        values: Array of values to aggregate (length = link_mtx.shape[1])
        agg_fn: Aggregation function - 'mean', 'sum', 'max', 'min', 'count', 'nunique', or 'mode'
        ignore_missing: If True, aggregation ignores missing values (NaN/NaT)
            where applicable. If False, missing values can propagate depending
            on the aggregation function.

    Returns:
        Aggregated values (length = link_mtx.shape[0])
    """
    n_rows = link_mtx.shape[0]

    if agg_fn == "sum":
        if ignore_missing and np.issubdtype(values.dtype, np.number):
            safe_values, _ = _get_numeric_safe_values_and_mask(values)
            return link_mtx.dot(safe_values)
        return link_mtx.dot(values)
    elif agg_fn == "count":
        if ignore_missing:
            valid_mask = _get_valid_mask(values)
            return link_mtx.dot(valid_mask.astype("float64"))
        return link_mtx.dot(np.ones(len(values)))
    elif agg_fn == "mean":
        if np.issubdtype(values.dtype, np.datetime64):
            # Datetime mean is computed in nanoseconds and converted back.
            values_ns = values.astype("datetime64[ns]")
            valid_mask = ~np.isnat(values_ns)
            ns_values = values_ns.astype("int64").astype("float64")

            if ignore_missing:
                ns_values = np.where(valid_mask, ns_values, 0.0)
                counts = link_mtx.dot(valid_mask.astype("float64"))
            else:
                ns_values = np.where(valid_mask, ns_values, np.nan)
                counts = link_mtx.dot(np.ones(len(values_ns), dtype="float64"))

            sums = link_mtx.dot(ns_values)
            mean_ns = np.divide(
                sums,
                counts,
                out=np.full(n_rows, np.nan, dtype="float64"),
                where=counts > 0,
            )
            return pd.to_datetime(mean_ns, unit="ns", errors="coerce").to_numpy(
                dtype="datetime64[ns]"
            )

        if ignore_missing and np.issubdtype(values.dtype, np.number):
            safe_values, valid_mask = _get_numeric_safe_values_and_mask(values)
            sums = link_mtx.dot(safe_values)
            counts = link_mtx.dot(valid_mask.astype("float64"))
            return np.divide(
                sums,
                counts,
                out=np.zeros_like(sums, dtype="float64"),
                where=counts > 0,
            )

        sums = link_mtx.dot(values)
        counts = link_mtx.dot(np.ones(len(values)))
        return np.divide(sums, counts, out=np.zeros_like(sums), where=counts > 0)
    elif agg_fn == "max":
        if np.issubdtype(values.dtype, np.datetime64):
            result = np.full(n_rows, np.datetime64("NaT"), dtype="datetime64[ns]")
        elif np.issubdtype(values.dtype, np.number):
            result = np.full(n_rows, -np.inf, dtype=np.float64)
        else:
            result = np.full(n_rows, np.nan, dtype=object)

        # using CSR structure directly because it's significantly faster
        # TODO: numba implementation
        for i in range(n_rows):
            start = link_mtx.indptr[i]
            end = link_mtx.indptr[i + 1]
            if start < end:
                linked = link_mtx.indices[start:end]
                linked_vals = values[linked]
                if ignore_missing:
                    linked_vals = _filter_missing_values(linked_vals)
                if len(linked_vals) > 0:
                    result[i] = linked_vals.max()
        return result
    elif agg_fn == "min":
        if np.issubdtype(values.dtype, np.datetime64):
            result = np.full(n_rows, np.datetime64("NaT"), dtype="datetime64[ns]")
        elif np.issubdtype(values.dtype, np.number):
            result = np.full(n_rows, np.inf, dtype=np.float64)
        else:
            result = np.full(n_rows, np.nan, dtype=object)

        for i in range(n_rows):
            start = link_mtx.indptr[i]
            end = link_mtx.indptr[i + 1]
            if start < end:
                linked = link_mtx.indices[start:end]
                linked_vals = values[linked]
                if ignore_missing:
                    linked_vals = _filter_missing_values(linked_vals)
                if len(linked_vals) > 0:
                    result[i] = linked_vals.min()
        return result
    elif agg_fn == "nunique":
        result = np.zeros(n_rows, dtype=int)
        for i in range(n_rows):
            start = link_mtx.indptr[i]
            end = link_mtx.indptr[i + 1]
            if start < end:
                linked = link_mtx.indices[start:end]
                linked_vals = values[linked]
                if ignore_missing:
                    linked_vals = _filter_missing_values(linked_vals)
                result[i] = len(np.unique(linked_vals))
        return result
    elif agg_fn == "mode":
        # numpy string dtypes aren't really nullable, and we don't use them
        dtype = object if values.dtype.kind in ("U", "S") else values.dtype
        result = np.full(n_rows, np.nan, dtype=dtype)
        for i in range(n_rows):
            start = link_mtx.indptr[i]
            end = link_mtx.indptr[i + 1]
            if start < end:
                linked = link_mtx.indices[start:end]
                linked_vals = values[linked]
                if ignore_missing:
                    linked_vals = _filter_missing_values(linked_vals)

                if len(linked_vals) > 0:
                    unique_vals, counts = np.unique(linked_vals, return_counts=True)
                    result[i] = unique_vals[counts.argmax()]
        return result
    else:
        raise ValueError(f"Unknown aggregation function: {agg_fn}")


class DatasetLink(SerializableWithDatasetsMixin):
    def __init__(
        self,
        left_ds: CobaltDataset,
        right_ds: CobaltDataset,
        link_mtx: sp.csr_array,
    ):
        self.left_ds = left_ds
        self.right_ds = right_ds
        self.link_mtx = link_mtx
        self._link_mtx_T: Optional[sp.csr_array] = None

    @property
    def link_mtx_T(self) -> sp.csr_array:
        """Lazily computed and cached transpose of link matrix."""
        if self._link_mtx_T is None:
            self._link_mtx_T = self.link_mtx.T.tocsr()
        return self._link_mtx_T

    def transpose(self) -> DatasetLink:
        """Return a new link with left and right datasets swapped.

        Returns:
            DatasetLink with left_ds and right_ds swapped, and transposed link matrix
        """
        return DatasetLink(
            left_ds=self.right_ds,
            right_ds=self.left_ds,
            link_mtx=self.link_mtx_T,
        )

    @staticmethod
    def from_scalar_columns(
        left_ds: CobaltDataset, right_ds: CobaltDataset, link_columns: Tuple[str, str]
    ):
        """Create link by joining on scalar column values.

        Args:
            left_ds: Left dataset
            right_ds: Right dataset
            link_columns: Tuple of (left_column, right_column) to join on

        Returns:
            DatasetLink where rows are linked if their column values match
        """
        left_link, right_link = link_columns
        left_key = left_ds.df[left_link]
        right_key = right_ds.df[right_link]

        left_df = pd.DataFrame({"id": np.arange(len(left_ds)), "key": left_key})
        right_df = pd.DataFrame({"id": np.arange(len(right_ds)), "key": right_key})
        merge_df = left_df.merge(right_df, on="key", how="inner")
        link_mtx = sp.coo_array(
            (
                np.ones(len(merge_df), dtype=np.float32),
                (merge_df["id_x"].to_numpy(), merge_df["id_y"].to_numpy()),
            ),
            shape=(len(left_ds), len(right_ds)),
        )
        return DatasetLink(left_ds, right_ds, link_mtx.tocsr())

    @staticmethod
    def from_columns_with_lists(
        left_ds: CobaltDataset, right_ds: CobaltDataset, link_columns: Tuple[str, str]
    ):
        """Create link where left column contains lists referencing right column values.

        Args:
            left_ds: Left dataset with column containing lists
            right_ds: Right dataset with column containing scalar values
            link_columns: Tuple of (left_column, right_column) where left_column
                contains lists of values that reference right_column values

        Returns:
            DatasetLink where left row i links to right row j if
            right_ds[right_column].iloc[j] is in left_ds[left_column].iloc[i]
        """
        left_link, right_link = link_columns
        left_col = left_ds.df[left_link]
        right_col = right_ds.df[right_link]

        # mapping from right values to their row indices
        right_value_to_indices: Dict[Any, list] = {}
        for idx, val in enumerate(right_col):
            if pd.notna(val):
                if val not in right_value_to_indices:
                    right_value_to_indices[val] = []
                right_value_to_indices[val].append(idx)

        # build sparse matrix in COO format
        rows = []
        cols = []
        for left_idx, values in enumerate(left_col):
            if values is None or (
                not isinstance(values, (list, tuple, np.ndarray)) and pd.isna(values)
            ):
                continue
            # handle both list and array types
            values_list = (
                values if isinstance(values, (list, tuple, np.ndarray)) else [values]
            )

            for val in values_list:
                if pd.notna(val) and val in right_value_to_indices:
                    for right_idx in right_value_to_indices[val]:
                        rows.append(left_idx)
                        cols.append(right_idx)

        link_mtx = sp.coo_array(
            (np.ones(len(rows), dtype=np.float32), (rows, cols)),
            shape=(len(left_ds), len(right_ds)),
        )
        return DatasetLink(left_ds, right_ds, link_mtx.tocsr())

    @staticmethod
    def _column_contains_lists(series: pd.Series) -> bool:
        """Check if a pandas Series contains list-like values.

        Args:
            series: Pandas Series to check

        Returns:
            True if any value in the series is a list, tuple, or array
        """
        if series.dtype != object:
            return False

        return any(isinstance(val, (list, tuple, np.ndarray)) for val in series)

    @staticmethod
    def from_columns(
        left_ds: CobaltDataset, right_ds: CobaltDataset, link_columns: Tuple[str, str]
    ):
        """Create link with automatic detection of scalar vs list-based linking.

        Automatically detects whether columns contain scalar values or lists,
        and uses the appropriate linking method. Supports lists in either the
        left or right column.

        Args:
            left_ds: Left dataset
            right_ds: Right dataset
            link_columns: Tuple of (left_column, right_column) to link on

        Returns:
            DatasetLink created using either from_scalar_columns (for scalar-scalar),
            from_columns_with_lists (for list-scalar), or the transposed
            version (for scalar-list)
        """
        left_link, right_link = link_columns
        left_col = left_ds.df[left_link]
        right_col = right_ds.df[right_link]

        left_has_lists = DatasetLink._column_contains_lists(left_col)
        right_has_lists = DatasetLink._column_contains_lists(right_col)

        if left_has_lists and right_has_lists:
            raise ValueError(
                "Both columns contain lists. Only one column can contain lists."
            )
        elif left_has_lists:
            return DatasetLink.from_columns_with_lists(left_ds, right_ds, link_columns)
        elif right_has_lists:
            swapped_link = DatasetLink.from_columns_with_lists(
                right_ds, left_ds, (right_link, left_link)
            )
            return swapped_link.transpose()
        else:
            return DatasetLink.from_scalar_columns(left_ds, right_ds, link_columns)

    def push_subset_to_left(self, subset: CobaltDataSubset) -> CobaltDataSubset:
        """Find all left dataset rows linked to any row in the subset."""
        if subset.source_dataset is not self.right_ds:
            raise ValueError("Not a subset of self.right_ds")

        # Create indicator vector for subset rows
        right_indicator = np.zeros(len(self.right_ds), dtype=bool)
        right_indicator[subset.indices] = True

        # Matrix-vector product: each left row gets 1 if linked to any subset row
        left_indicator = self.link_mtx.dot(right_indicator) > 0
        left_indices = np.flatnonzero(left_indicator)

        return self.left_ds.subset(left_indices)

    def push_subset_to_right(self, subset: CobaltDataSubset) -> CobaltDataSubset:
        """Find all right dataset rows linked to any row in the subset."""
        if subset.source_dataset is not self.left_ds:
            raise ValueError("Not a subset of self.left_ds")

        # Create indicator vector for subset rows
        left_indicator = np.zeros(len(self.left_ds), dtype=bool)
        left_indicator[subset.indices] = True

        # Transpose matrix-vector product: each right row gets 1 if linked to any subset row
        right_indicator = self.link_mtx_T.dot(left_indicator) > 0
        right_indices = np.flatnonzero(right_indicator)

        return self.right_ds.subset(right_indices)

    @overload
    def push_values_to_left(
        self,
        values: pd.Series,
        agg_fn: AggFnName = "mean",
        ignore_missing: bool = True,
    ) -> pd.Series: ...

    @overload
    def push_values_to_left(
        self,
        values: np.ndarray,
        agg_fn: AggFnName = "mean",
        ignore_missing: bool = True,
    ) -> np.ndarray: ...

    def push_values_to_left(
        self,
        values: Union[pd.Series, np.ndarray],
        agg_fn: AggFnName = "mean",
        ignore_missing: bool = True,
    ) -> Union[pd.Series, np.ndarray]:
        """Aggregate values from right dataset to left dataset via links.

        Args:
            values: Per-row values from right dataset
            agg_fn: Aggregation function - 'mean', 'sum', 'max', 'min', 'count',
                'nunique', or 'mode'
            ignore_missing: If True, aggregation ignores missing values (NaN/NaT)
                where applicable.

        Returns:
            Aggregated values for left dataset rows (same type as input)
        """
        if len(values) != len(self.right_ds):
            raise ValueError("Wrong number of values for self.right_ds")

        series_name = None
        if isinstance(values, pd.Series):
            series_name = values.name
            values_array = values.to_numpy()
        else:
            values_array = values

        result = _aggregate_via_links(
            self.link_mtx,
            values_array,
            agg_fn,
            ignore_missing=ignore_missing,
        )

        if series_name is not None:
            return pd.Series(result, name=series_name)
        return result

    @overload
    def push_values_to_right(
        self,
        values: pd.Series,
        agg_fn: AggFnName = "mean",
        ignore_missing: bool = True,
    ) -> pd.Series: ...

    @overload
    def push_values_to_right(
        self,
        values: np.ndarray,
        agg_fn: AggFnName = "mean",
        ignore_missing: bool = True,
    ) -> np.ndarray: ...

    def push_values_to_right(
        self,
        values: Union[pd.Series, np.ndarray],
        agg_fn: AggFnName = "mean",
        ignore_missing: bool = True,
    ) -> Union[pd.Series, np.ndarray]:
        """Aggregate values from left dataset to right dataset via links.

        Args:
            values: Per-row values from left dataset
            agg_fn: Aggregation function - 'mean', 'sum', 'max', 'min', 'count',
                'nunique', or 'mode'
            ignore_missing: If True, aggregation ignores missing values (NaN/NaT)
                where applicable.

        Returns:
            Aggregated values for right dataset rows (same type as input)
        """
        if len(values) != len(self.left_ds):
            raise ValueError("Wrong number of values for self.left_ds")

        series_name = None
        if isinstance(values, pd.Series):
            series_name = values.name
            values_array = values.to_numpy()
        else:
            values_array = values

        result = _aggregate_via_links(
            self.link_mtx_T,
            values_array,
            agg_fn,
            ignore_missing=ignore_missing,
        )

        if series_name is not None:
            return pd.Series(result, name=series_name)
        return result

    # serialization functionality
    _serialization_version = 1

    def __data_dict__(self) -> dict:
        return {
            "left_ds": self.left_ds.name,
            "right_ds": self.right_ds.name,
            "link_mtx": self.link_mtx,
        }

    @classmethod
    def __from_serializable_dict__(
        cls, d: dict, datasets: Dict[str, CobaltDataset]
    ) -> DatasetLink:
        data = d["__data__"]
        left_ds = datasets[data["left_ds"]]
        right_ds = datasets[data["right_ds"]]
        link_mtx = data["link_mtx"]
        return DatasetLink(left_ds, right_ds, link_mtx)
