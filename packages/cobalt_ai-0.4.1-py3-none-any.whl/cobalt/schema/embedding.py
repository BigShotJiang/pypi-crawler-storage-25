# Copyright (C) 2023-2025 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from __future__ import annotations

import re
import warnings
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, List, Literal, Optional, Sequence, Union

import numpy as np
import pandas as pd
from mapper import Metric

from cobalt.serialization import (
    DictConstructibleMixin,
    SerializableMixin,
)

if TYPE_CHECKING:
    from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor

    from cobalt.schema.dataset import DatasetBase


# Pulled these back in from the now-deprecated `generate_tab_embeddings` for RF embedding support
def _transform_obj_to_cat_codes(data: pd.DataFrame) -> pd.DataFrame:
    """Transform object columns to category codes for RF training."""
    data = data.copy()
    for col in data.columns:
        if data[col].dtype == "object":
            data[col] = data[col].astype("category").cat.codes
    return data


def _get_labels_for_unsupervised_task(df: pd.DataFrame):
    """Create synthetic labels for unsupervised RF training.

    Creates a binary classification task by labeling original data as 0
    and synthetic data (sampled independently per column) as 1.
    """
    LABEL = "label"
    df_c = df.copy()
    df_c[LABEL] = 0
    df_c = df_c.sample(frac=0.5)
    sampled_df = df.apply(lambda x: x.sample(n=df_c.shape[0], ignore_index=True))
    sampled_df[LABEL] = 1
    new_df = pd.concat([df_c, sampled_df])
    return new_df.drop(LABEL, axis=1), new_df[LABEL]


class Embedding(ABC):
    """Encapsulates metadata about a dataset embedding."""

    def __init__(self, name=None) -> None:
        self._name = name

    @property
    def name(self):
        if self._name is not None:
            return self._name
        else:
            return str(self)

    @property
    @abstractmethod
    def dimension(self) -> int:
        """The dimension of the embedding."""

    @abstractmethod
    def get(self, dataset: DatasetBase) -> np.ndarray:
        """Get the values of this embedding for a dataset."""

    @property
    def distance_metrics(self) -> Sequence[Union[str, Metric]]:
        """Suggested distance metrics for use with this embedding."""
        warnings.warn(
            "Embedding.distance_metrics is deprecated; "
            "use default_distance_metrics or admissible_distance_metrics instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.get_available_distance_metrics()

    @property
    @abstractmethod
    def default_distance_metric(self) -> Union[str, Metric]:
        """Default distance metric to use with this embedding."""

    @property
    def admissible_distance_metrics(self) -> Sequence[Union[str, Metric]]:
        """Distance metrics that are reasonable to use with this embedding.

        Other distance metrics may still be useful, but these are metrics that
        are known to make sense for the data.
        """
        return self.get_available_distance_metrics()

    @abstractmethod
    def get_available_distance_metrics(self) -> Sequence[Union[str, Metric]]:
        """Return the list of distance metrics that could be used."""

    def __repr__(self):
        if self._name is not None:
            return f'Embedding(dim={self.dimension}, name="{self.name}")'
        return f"Embedding(dim={self.dimension})"


class ColumnEmbedding(Embedding, DictConstructibleMixin, SerializableMixin):
    """Represents an embedding as a column range.

    Attributes:
        columns: List of strings naming the columns to include in this
            embedding.
    """

    _serialization_version = 1

    def __init__(
        self, columns: List[str], metric: Union[str, Metric], name=None
    ) -> None:
        self._metric = metric
        self.columns = columns
        super().__init__(name)

    def get(self, dataset: DatasetBase) -> np.ndarray:
        """Return a np.ndarray of the embedding rows at specified indices.

        Only columns specified in the `columns` attribute are included.

        Args:
            dataset: Data(sub)set for which to get the embedding values.

        Returns:
            The np.ndarray containing the embedding values for the rows in the given dataset.
        """
        if not hasattr(dataset, "df"):
            raise ValueError(
                "Embedding.get() takes the requested dataset or subset as its argument, "
                "not a list of indices."
            )
        selected_col_data = dataset.df[self.columns]

        return selected_col_data.to_numpy()

    def get_available_distance_metrics(self) -> Sequence[Union[str, Metric]]:
        warnings.warn(
            "Embedding.get_available_distance_metrics() is deprecated; "
            "use default_distance_metrics or admissible_distance_metrics instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return [self._metric]

    @property
    def default_distance_metric(self) -> Union[str, Metric]:
        return self._metric

    @property
    def metric(self) -> Union[str, Metric]:
        warnings.warn(
            "ColumnEmbedding.metric is deprecated; "
            "use default_distance_metrics or admissible_distance_metrics instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._metric

    @property
    def admissible_distance_metrics(self) -> List[Union[str, Metric]]:
        return [self._metric]

    @property
    def dimension(self) -> int:
        return len(self.columns)

    def __eq__(self, other) -> bool:
        if not isinstance(other, ColumnEmbedding):
            return NotImplemented

        return all(
            [
                self.columns == other.columns,
                self._metric == other._metric,
                self.name == other.name,
            ]
        )

    def __data_dict__(self) -> dict:
        return {
            "columns": self.columns,
            "metric": self._metric,
            "name": self.name,
        }


# TODO: add support for multiple admissible metrics
class ArrayEmbedding(Embedding, DictConstructibleMixin, SerializableMixin):
    """An embedding stored in an array associated with a Dataset.

    Attributes:
        array_name: The name of the array in the dataset storing the embedding values
    """

    _serialization_version = 1

    def __init__(
        self,
        array_name: str,
        dimension: int,
        metric: Union[str, Metric],
        name: Optional[str] = None,
    ) -> None:
        self._metric = metric
        self._dimension = dimension
        self.array_name = array_name
        super().__init__(name)

    @property
    def dimension(self) -> int:
        """The dimension of the embedding."""
        return self._dimension

    def get(self, dataset: DatasetBase) -> np.ndarray:
        """Return a np.ndarray of the embedding rows at specified indices.

        Args:
            dataset: Data(sub)set for which to get the embedding values.

        Returns:
            The np.ndarray containing the embedding values for the rows in the given dataset.
        """
        if not hasattr(dataset, "get_array"):
            raise ValueError(
                "Embedding.get() takes the requested dataset or subset as its argument, "
                "not a list of indices."
            )
        return dataset.get_array(self.array_name)

    def get_available_distance_metrics(self) -> List[str]:
        warnings.warn(
            "Embedding.get_available_distance_metrics() is deprecated; "
            "use default_distance_metrics or admissible_distance_metrics instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return [self._metric]

    @property
    def metric(self) -> Union[str, Metric]:
        warnings.warn(
            "ArrayEmbedding.metric is deprecated; "
            "use default_distance_metrics or admissible_distance_metrics instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self._metric

    @property
    def default_distance_metric(self) -> Union[str, Metric]:
        return self._metric

    @property
    def admissible_distance_metrics(self) -> List[Union[str, Metric]]:
        return [self._metric]

    def __eq__(self, other) -> bool:
        if not isinstance(other, ArrayEmbedding):
            return NotImplemented

        return all(
            [
                self.array_name == other.array_name,
                self.dimension == other.dimension,
                self._metric == other._metric,
                self.name == other.name,
            ]
        )

    def __data_dict__(self) -> dict:
        return {
            "array_name": self.array_name,
            "dimension": self.dimension,
            "metric": self._metric,
            "name": self.name,
        }


class TextEmbedding(ArrayEmbedding, DictConstructibleMixin, SerializableMixin):

    _serialization_version = 1

    def __init__(
        self,
        array_name: str,
        dimension: int,
        metric: Union[str, Metric],
        name: Optional[str] = None,
        embedding_model: Optional[str] = None,
        source_column: Optional[str] = None,
    ) -> None:
        self.embedding_model = embedding_model
        self.source_column = source_column
        if name is None and source_column is not None and embedding_model is not None:
            name = f"{source_column}_{embedding_model}"
        super().__init__(array_name, dimension, metric, name)

    def __eq__(self, other) -> bool:
        if not isinstance(other, TextEmbedding):
            return NotImplemented

        return all(
            [
                self.array_name == other.array_name,
                self.dimension == other.dimension,
                self._metric == other._metric,
                self.name == other.name,
                self.embedding_model == other.embedding_model,
                self.source_column == other.source_column,
            ]
        )

    def __data_dict__(self) -> dict:
        return {
            "array_name": self.array_name,
            "dimension": self.dimension,
            "metric": self._metric,
            "name": self.name,
            "embedding_model": self.embedding_model,
            "source_column": self.source_column,
        }


class ScaledEmbedding(Embedding, DictConstructibleMixin, SerializableMixin):
    """An embedding that lazily computes scaled values from a source embedding.

    This embedding wraps a continuous numeric embedding (ColumnEmbedding or
    ArrayEmbedding) and applies scaling (standardization or robust/IQR scaling)
    on demand. It does not store the scaled array directly, providing memory
    savings and avoiding redundant data during serialization.

    Scaling parameters (mean/std or median/IQR) are computed from the full
    source dataset to ensure consistency when working with subsets.

    Note:
        This class is intended for continuous numeric embeddings only.
        It should NOT be used with discrete embeddings like RandomForestEmbedding,
        which use Hamming distance on integer leaf indices.

    Attributes:
        source_embedding_name: Name of the source embedding to scale.
        scaling: The scaling method ('standardize' or 'robust').
    """

    _serialization_version = 1

    # Valid scaling methods
    SCALING_METHODS = ("standardize", "robust")

    def __init__(
        self,
        source_embedding_name: str,
        scaling: Literal["standardize", "robust"],
        dimension: int,
        metric: Union[str, Metric] = "euclidean",
        name: Optional[str] = None,
    ) -> None:
        """Initialize a ScaledEmbedding.

        Args:
            source_embedding_name: Name of the source embedding to scale.
            scaling: Scaling method - 'standardize' (zero mean, unit variance)
                or 'robust' (median centering, IQR scaling).
            dimension: The dimension of the embedding.
            metric: Distance metric for the scaled embedding.
            name: Optional name for this embedding.
        """
        if scaling not in self.SCALING_METHODS:
            raise ValueError(
                f"Unknown scaling method '{scaling}'. "
                f"Must be one of {self.SCALING_METHODS}."
            )
        self.scaling = scaling
        self.source_embedding_name = source_embedding_name
        self._dimension = dimension
        self._metric = metric
        # Cache for scaling parameters (computed on first use)
        self._center: Optional[np.ndarray] = None
        self._scale: Optional[np.ndarray] = None
        super().__init__(name)

    @property
    def dimension(self) -> int:
        """The dimension of the embedding."""
        return self._dimension

    @property
    def default_distance_metric(self) -> Union[str, Metric]:
        """Default distance metric to use with this embedding."""
        return self._metric

    @property
    def admissible_distance_metrics(self) -> List[Union[str, Metric]]:
        """Distance metrics that are reasonable to use with this embedding."""
        return [self._metric]

    def get_available_distance_metrics(self) -> List[Union[str, Metric]]:
        """Return the list of distance metrics that could be used."""
        warnings.warn(
            "Embedding.get_available_distance_metrics() is deprecated; "
            "use default_distance_metrics or admissible_distance_metrics instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return [self._metric]

    def _get_source_embedding(self, dataset: DatasetBase) -> Embedding:
        """Get the source embedding from the dataset.

        Args:
            dataset: The dataset containing the source embedding.

        Returns:
            The source embedding object.

        Raises:
            ValueError: If the source embedding cannot be found.
        """
        # Navigate to the source dataset if we have a subset
        source_dataset = getattr(dataset, "source_dataset", dataset)

        if hasattr(source_dataset, "get_embedding_metadata_by_name"):
            return source_dataset.get_embedding_metadata_by_name(
                self.source_embedding_name
            )
        raise ValueError(
            f"Cannot find source embedding '{self.source_embedding_name}' in dataset."
        )

    def _compute_scaled(self, X: np.ndarray) -> np.ndarray:
        """Compute scaled values from raw embedding data.

        Scaling parameters are cached on first use for efficiency.

        Args:
            X: Raw embedding array of shape (n_samples, n_features).

        Returns:
            Scaled array of same shape.
        """
        # Compute and cache scaling parameters if not already cached
        if self._center is None or self._scale is None:
            if self.scaling == "standardize":
                self._center = X.mean(axis=0)
                self._scale = X.std(axis=0)
                self._scale[self._scale == 0] = 1.0
            elif self.scaling == "robust":
                self._center = np.median(X, axis=0)
                q1 = np.percentile(X, 25, axis=0)
                q3 = np.percentile(X, 75, axis=0)
                self._scale = q3 - q1
                self._scale[self._scale == 0] = 1.0

        # Apply cached scaling
        X = X.astype(float, copy=True)
        return (X - self._center) / self._scale

    def get(self, dataset: DatasetBase) -> np.ndarray:
        """Get the scaled embedding values for a dataset.

        Scaling parameters (mean/std or median/IQR) are computed from the full
        source dataset to ensure consistency across subsets.

        Args:
            dataset: Data(sub)set for which to get the embedding values.

        Returns:
            The scaled embedding array.

        Raises:
            TypeError: If the source embedding is a RandomForestEmbedding.
        """
        source_embedding = self._get_source_embedding(dataset)

        # Prevent scaling of discrete embeddings (RF uses Hamming distance on leaf indices)
        if isinstance(source_embedding, RandomForestEmbedding):
            raise TypeError(
                f"Cannot scale RandomForestEmbedding '{source_embedding.name}'. "
                "RF embeddings use discrete leaf indices with Hamming distance."
            )

        # Get full dataset for computing scaling parameters
        source_dataset = getattr(dataset, "source_dataset", dataset)

        # Compute scaling from full dataset for consistency across subsets
        X_full = source_embedding.get(source_dataset)
        X_scaled_full = self._compute_scaled(X_full)

        # If working with a subset, extract the relevant rows
        if hasattr(dataset, "indices"):
            return X_scaled_full[dataset.indices]
        return X_scaled_full

    def __eq__(self, other) -> bool:
        if not isinstance(other, ScaledEmbedding):
            return NotImplemented

        return all(
            [
                self.source_embedding_name == other.source_embedding_name,
                self.scaling == other.scaling,
                self.dimension == other.dimension,
                self._metric == other._metric,
                self.name == other.name,
            ]
        )

    def __repr__(self) -> str:
        return (
            f"ScaledEmbedding(source='{self.source_embedding_name}', "
            f"scaling='{self.scaling}', dim={self.dimension}, name='{self.name}')"
        )

    def __data_dict__(self) -> dict:
        return {
            "source_embedding_name": self.source_embedding_name,
            "scaling": self.scaling,
            "dimension": self.dimension,
            "metric": self._metric,
            "name": self.name,
        }

    @classmethod
    def __from_serializable_dict__(cls, d: dict) -> ScaledEmbedding:
        if (cls_name := d.pop("__class__", None)) != cls.__name__:
            raise ValueError(f"Incorrect serialized object type {cls_name}.")
        if (ser_version := d.pop("__version__", None)) != cls._serialization_version:
            raise ValueError(
                f"Incorrect serialization version {ser_version}. "
                f"Expected {cls._serialization_version}."
            )
        return cls(**d["__data__"])


class RandomForestEmbedding(Embedding, DictConstructibleMixin, SerializableMixin):
    """An embedding computed using Random Forest leaf node assignments.

    This embedding wraps a source embedding and applies a Random Forest model
    to generate leaf node indices as features. The RF can be trained in either
    supervised mode (with an outcome column) or unsupervised mode (using a
    synthetic classification task).

    The trained model can optionally be stored to enable embedding new data.

    Attributes:
        source_embedding_name: Name of the source embedding used as RF input.
        outcome_column: Name of the target column (None for unsupervised).
        n_estimators: Number of trees in the forest.
        max_depth: Maximum depth of each tree.
        supervised: Whether the RF was trained with supervision.
    """

    _serialization_version = 1

    def __init__(
        self,
        source_embedding_name: str,
        dimension: int,
        outcome_column: Optional[str] = None,
        n_estimators: int = 50,
        max_depth: int = 7,
        max_samples: float = 0.25,
        random_state: Optional[int] = None,
        name: Optional[str] = None,
        model: Optional[RandomForestClassifier | RandomForestRegressor] = None,
    ) -> None:
        """Initialize a RandomForestEmbedding.

        Args:
            source_embedding_name: Name of the source embedding to use as input.
            dimension: The dimension of the embedding (number of trees).
            outcome_column: Target column name for supervised training. If None,
                uses unsupervised mode with synthetic labels.
            n_estimators: Number of trees in the forest.
            max_depth: Maximum depth of each tree.
            max_samples: Fraction of samples to use for each tree.
            random_state: Random seed for reproducibility.
            name: Optional name for this embedding.
            model: Optional pre-trained RandomForest model. If provided, can be
                used to embed new data via `embed()`.

        Note:
            The metric is always Hamming distance for RF embeddings since
            leaf node indices are discrete integer values.
        """
        self.source_embedding_name = source_embedding_name
        self._dimension = dimension
        self.outcome_column = outcome_column
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.max_samples = max_samples
        self.random_state = random_state
        self._metric = "hamming"  # Always use Hamming
        self._model = model
        super().__init__(name)

    @property
    def dimension(self) -> int:
        """The dimension of the embedding (number of trees)."""
        return self._dimension

    @property
    def default_distance_metric(self) -> str:
        """Default distance metric (hamming for RF leaf indices)."""
        return self._metric

    @property
    def admissible_distance_metrics(self) -> List[str]:
        """Distance metrics that are reasonable for RF embeddings."""
        return ["hamming"]

    def get_available_distance_metrics(self) -> List[str]:
        """Return the list of distance metrics that could be used."""
        warnings.warn(
            "Embedding.get_available_distance_metrics() is deprecated; "
            "use default_distance_metrics or admissible_distance_metrics instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return ["hamming"]

    @property
    def supervised(self) -> bool:
        """Whether the RF was trained with supervision."""
        return self.outcome_column is not None

    @property
    def model(self) -> Optional[RandomForestClassifier | RandomForestRegressor]:
        """The trained RandomForest model, if stored."""
        return self._model

    def has_model(self) -> bool:
        """Check if a trained model is available."""
        return self._model is not None

    def _get_source_embedding(self, dataset: DatasetBase) -> Embedding:
        """Get the source embedding from the dataset."""
        source_dataset = getattr(dataset, "source_dataset", dataset)

        if hasattr(source_dataset, "get_embedding_metadata_by_name"):
            return source_dataset.get_embedding_metadata_by_name(
                self.source_embedding_name
            )
        raise ValueError(
            f"Cannot find source embedding '{self.source_embedding_name}' in dataset."
        )

    def embed(self, X: np.ndarray) -> np.ndarray:
        """Embed new data using the stored model.

        Args:
            X: Input array of shape (n_samples, n_features).

        Returns:
            Leaf node indices array of shape (n_samples, n_estimators).

        Raises:
            ValueError: If no model is stored.
        """
        if self._model is None:
            raise ValueError(
                "No model stored. Either pass model= at construction time, "
                "or use get() with the original dataset."
            )
        return self._model.apply(X)

    def get(self, dataset: DatasetBase) -> np.ndarray:
        """Get the RF embedding values for a dataset.

        First checks for a pre-computed embedding array in the dataset.
        If not found and a model is stored, computes embeddings on the fly.

        Args:
            dataset: Data(sub)set for which to get the embedding values.

        Returns:
            The RF embedding array of shape (n_samples, n_estimators).
        """
        # First, try to look up a stored array to avoid recomputation
        if hasattr(dataset, "get_array"):
            array_name = self.name or self.source_embedding_name + "_rf"
            try:
                # dataset.get_array handles subsetting internally
                return dataset.get_array(array_name)
            except KeyError:
                pass

        # If no stored array, compute using the model if available
        if self._model is not None:
            if self.source_embedding_name == "__all_columns__":
                # Use all columns from the dataset's dataframe
                df = dataset.df.copy()
                if self.outcome_column is not None:
                    df = df.drop(columns=[self.outcome_column], errors="ignore")
                df = _transform_obj_to_cat_codes(df)
                return self._model.apply(df.values)
            else:
                source_embedding = self._get_source_embedding(dataset)
                X = source_embedding.get(dataset)
                return self._model.apply(X)

        raise ValueError(
            f"No model stored and no pre-computed array found for '{self.name}'. "
            "Train and store a model, or pre-compute the embedding array."
        )

    def __eq__(self, other) -> bool:
        if not isinstance(other, RandomForestEmbedding):
            return NotImplemented

        return all(
            [
                self.source_embedding_name == other.source_embedding_name,
                self.dimension == other.dimension,
                self.outcome_column == other.outcome_column,
                self.n_estimators == other.n_estimators,
                self.max_depth == other.max_depth,
                self.max_samples == other.max_samples,
                self._metric == other._metric,
                self.name == other.name,
            ]
        )

    def __repr__(self) -> str:
        mode = "supervised" if self.supervised else "unsupervised"
        has_model = "with model" if self.has_model() else "no model"
        return (
            f"RandomForestEmbedding(source='{self.source_embedding_name}', "
            f"dim={self.dimension}, {mode}, {has_model}, name='{self.name}')"
        )

    def __data_dict__(self) -> dict:
        return {
            "source_embedding_name": self.source_embedding_name,
            "dimension": self.dimension,
            "outcome_column": self.outcome_column,
            "n_estimators": self.n_estimators,
            "max_depth": self.max_depth,
            "max_samples": self.max_samples,
            "random_state": self.random_state,
            "name": self.name,
            # Note: model is not serialized by default (can be large)
            # Note: metric is always "hamming" for RF embeddings
        }

    @classmethod
    def __from_serializable_dict__(cls, d: dict) -> RandomForestEmbedding:
        if (cls_name := d.pop("__class__", None)) != cls.__name__:
            raise ValueError(f"Incorrect serialized object type {cls_name}.")
        if (ser_version := d.pop("__version__", None)) != cls._serialization_version:
            raise ValueError(
                f"Incorrect serialization version {ser_version}. "
                f"Expected {cls._serialization_version}."
            )
        return cls(**d["__data__"])

    def with_model(
        self, model: RandomForestClassifier | RandomForestRegressor
    ) -> RandomForestEmbedding:
        """Return a copy of this embedding with the given model attached.

        Args:
            model: A trained RandomForest model (Classifier or Regressor).

        Returns:
            A new RandomForestEmbedding with the model stored.
        """
        return RandomForestEmbedding(
            source_embedding_name=self.source_embedding_name,
            dimension=self.dimension,
            outcome_column=self.outcome_column,
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            max_samples=self.max_samples,
            random_state=self.random_state,
            name=self.name,
            model=model,
        )


class EmbeddingManager:
    """Manages embedding logic."""

    def __init__(self, embeddings: List[Embedding]):
        self._embeddings = embeddings if embeddings else []
        self.validate_embeddings(self._embeddings)
        self._embedding_name_to_index = {
            emb.name: i for i, emb in enumerate(self._embeddings)
        }

    def validate_embeddings(self, embeddings):
        self._validate_embedding_names(embeddings)

    @staticmethod
    def _validate_embedding_names(embeddings: List[Embedding]):
        unique_set = {emb.name for emb in embeddings}
        if len(unique_set) < len(embeddings):
            raise Exception("Embeddings have non-unique names.")

    def map_name_to_embedding(self, name):
        index = self._embedding_name_to_index[name]
        return self._embeddings[index]

    def add_embedding(self, embedding: Embedding):
        if embedding.name in self._embedding_name_to_index:
            raise Exception(f"Name {embedding.name!r} already used")

        self._embeddings.append(embedding)
        self._embedding_name_to_index[embedding.name] = len(self._embeddings) - 1

    def get_embedding_array_by_name(self, name: str, indices=None):
        if indices is None:
            return self.map_name_to_embedding(name).get()
        return self.map_name_to_embedding(name).get(indices)

    def embedding_names(self) -> List[str]:
        return [emb.name for emb in self._embeddings]

    def get_new_embedding_name(self) -> str:
        names = self.embedding_names()
        matches = [re.match(r"embedding_(\d+)", name) for name in names]
        numbers = [int(m.group(1)) for m in matches if m is not None]
        number = max(numbers) + 1 if numbers else 1
        return f"embedding_{number}"

    @property
    def embedding_metadata(self):
        return self._embeddings.copy()


INITIAL_EMBEDDING_INDEX = 0
