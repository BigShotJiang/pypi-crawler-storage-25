# Copyright (C) 2023-2026 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from __future__ import annotations

from typing import Dict, FrozenSet, List, Optional, Tuple, Union

import scipy.sparse as sp

from cobalt.schema.dataset import CobaltDataset, CobaltDataSubset
from cobalt.schema.link import DatasetLink
from cobalt.schema.split import DatasetSplit
from cobalt.serialization import SerializableWithDatasetsMixin


class DatasetCollection(SerializableWithDatasetsMixin):
    """Manages multiple related datasets with links between them.

    Also manages DatasetSplits associated with each CobaltDataset.

    Enforces:
    - At most one link between any two datasets
    - Dataset names are synchronized with CobaltDataset.name
    - Each dataset has its own (possibly trivial) DatasetSplit
    """

    def __init__(
        self,
        primary_dataset: CobaltDataset,
        primary_split: Optional[DatasetSplit] = None,
    ):
        """Initialize with a primary dataset.

        Args:
            primary_dataset: The primary dataset for the collection
            primary_split: Optional split for the primary dataset
        """
        self.primary = primary_dataset  # backward compatibility
        self.datasets: Dict[str, CobaltDataset] = {}
        # links are labeled by frozenset pairs of names so we only store one direction for each link
        self.links: Dict[FrozenSet[str], DatasetLink] = {}
        # indexed by dataset name
        self.splits: Dict[str, DatasetSplit] = {}

        primary_name = primary_dataset.name or "primary"
        primary_dataset.name = primary_name  # Ensure name is set
        self.datasets[primary_name] = primary_dataset

        if primary_split is None:
            primary_split = DatasetSplit(primary_dataset)
        self.splits[primary_name] = primary_split

    def add_dataset(
        self,
        dataset: CobaltDataset,
        name: Optional[str] = None,
        split: Optional[DatasetSplit] = None,
    ):
        """Add a dataset to the collection.

        Args:
            dataset: The dataset to add
            name: Optional name override. If not provided, uses dataset.name
            split: Optional DatasetSplit for this dataset. If not provided, creates default split.

        Raises:
            ValueError: If name already exists or is None/empty
        """
        if name is None:
            name = dataset.name
        if not name:
            raise ValueError("Dataset must have a name")
        if name in self.datasets:
            raise ValueError(f"Dataset with name '{name}' already exists")

        if split is None:
            split = DatasetSplit(dataset)
        elif split.dataset is not dataset:
            raise ValueError("Split must be for the provided dataset")

        # synchronize name
        dataset.name = name
        self.datasets[name] = dataset

        self.splits[name] = split

    def add_link(
        self,
        link: Union[DatasetLink, sp.csr_array],
        left_name: Optional[str] = None,
        right_name: Optional[str] = None,
    ):
        """Add a link between two datasets.

        Enforces that at most one link exists between any pair of datasets.

        Args:
            link: DatasetLink or sparse link_mtx
            left_name: Name of left dataset
            right_name: Name of right dataset

        Raises:
            ValueError: If datasets not found or link already exists
        """
        if not isinstance(link, DatasetLink) and (
            left_name is None or right_name is None
        ):
            raise ValueError(
                "left_name and right_name must be provided when a link matrix "
                "is passed instead of a DatasetLink"
            )
        if left_name is None:
            left_name = link.left_ds.name
        if right_name is None:
            right_name = link.right_ds.name

        if left_name not in self.datasets:
            raise ValueError(f"Dataset '{left_name}' not in collection")
        if right_name not in self.datasets:
            raise ValueError(f"Dataset '{right_name}' not in collection")

        # verify link matches datasets
        left_ds = self.datasets[left_name]
        right_ds = self.datasets[right_name]
        if link.left_ds is not left_ds or link.right_ds is not right_ds:
            raise ValueError("Link datasets don't match provided names")

        # check for existing link
        key = frozenset([left_name, right_name])
        if key in self.links:
            raise ValueError(
                f"Link already exists between '{left_name}' and '{right_name}'"
            )

        self.links[key] = link

    def get_link(self, from_ds: str, to_ds: str) -> Optional[DatasetLink]:
        """Get link between two datasets (direction-aware).

        Returns the link oriented correctly: if link is stored as A -> B
        and you request B -> A, returns the transposed link.

        Args:
            from_ds: Source dataset name
            to_ds: Target dataset name

        Returns:
            DatasetLink oriented from from_ds to to_ds, or None if no link exists
        """
        if from_ds not in self.datasets or to_ds not in self.datasets:
            return None

        key = frozenset([from_ds, to_ds])
        link = self.links.get(key)

        if link is None:
            return None

        if link.left_ds == self.datasets[from_ds]:
            return link
        else:
            return link.transpose()

    def get_links_for_dataset(self, dataset_name: str) -> List[Tuple[str, DatasetLink]]:
        """Get all links involving a dataset.

        Args:
            dataset_name: Name of the dataset

        Returns:
            List of (other_dataset_name, link) tuples where link is oriented
            from dataset_name to other_dataset_name
        """
        if dataset_name not in self.datasets:
            return []

        result = []
        for key, link in self.links.items():
            names = list(key)
            if dataset_name in names:
                other_name = names[0] if names[1] == dataset_name else names[1]

                if link.left_ds is self.datasets[dataset_name]:
                    result.append((other_name, link))
                else:
                    result.append((other_name, link.transpose()))

        return result

    def translate_subset(
        self, subset: CobaltDataSubset, to_dataset_name: str
    ) -> CobaltDataSubset:
        """Translate a subset from one dataset to another via links.

        Args:
            subset: Subset to translate
            to_dataset_name: Name of target dataset

        Returns:
            Subset of the target dataset

        Raises:
            ValueError: If datasets not found or no link exists
        """
        from_dataset_name = self._find_dataset_name(subset.source_dataset)
        link = self.get_link(from_dataset_name, to_dataset_name)

        if link is None:
            raise ValueError(
                f"No link from '{from_dataset_name}' to '{to_dataset_name}'"
            )

        # link is oriented subset source -> target
        return link.push_subset_to_right(subset)

    def get_split(self, dataset_name: str) -> Optional[DatasetSplit]:
        """Get the split for a dataset.

        Args:
            dataset_name: Name of the dataset

        Returns:
            DatasetSplit for the dataset, or None if not found
        """
        return self.splits.get(dataset_name)

    def _find_dataset_name(self, dataset: CobaltDataset) -> str:
        """Find the name of a dataset in the collection.

        Args:
            dataset: Dataset to find

        Returns:
            Name of the dataset

        Raises:
            ValueError: If dataset not found
        """
        for name, ds in self.datasets.items():
            if ds is dataset:
                return name
        raise ValueError("Dataset not found in collection")

    # Serialization support
    _serialization_version = 1

    def __data_dict__(self) -> dict:
        return {
            "dataset_names": list(self.datasets.keys()),
            "links": list(self.links.values()),
            # splits are already a dict, but we'll forget the source dataset attribute
            "splits": dict(self.splits),
        }

    @classmethod
    def __from_serializable_dict__(
        cls, d: dict, datasets: Dict[str, CobaltDataset]
    ) -> DatasetCollection:
        data = d["__data__"]
        dataset_names = data["dataset_names"]

        # Get primary dataset (first in list)
        if not dataset_names:
            raise ValueError("No datasets in serialized DatasetCollection")

        primary_name = dataset_names[0]
        if primary_name not in datasets:
            raise ValueError(f"Primary dataset '{primary_name}' not found")

        primary_dataset = datasets[primary_name]

        splits_data = data["splits"]
        primary_split_dict = splits_data.get(primary_name, {})
        primary_split = DatasetSplit(primary_dataset, primary_split_dict)

        collection = cls(primary_dataset, primary_split)

        for name in dataset_names[1:]:
            if name not in datasets:
                raise ValueError(f"Dataset '{name}' not found")

            dataset = datasets[name]
            split_dict = splits_data.get(name, {})
            split = DatasetSplit(dataset, split_dict)
            collection.add_dataset(dataset, name, split)

        links_data = data.get("links", [])
        for link in links_data:
            collection.add_link(link)

        return collection
