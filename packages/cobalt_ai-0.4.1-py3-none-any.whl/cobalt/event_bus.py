# Copyright (C) 2023-2026 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

import inspect
from dataclasses import dataclass
from typing import (
    Any,
    Callable,
    ClassVar,
    Dict,
    Generic,
    Literal,
    Optional,
    TypeVar,
    Union,
)
from uuid import uuid4


@dataclass
class GraphEvent:
    """Details about a graph-related event."""

    event_type: Literal["added", "updated", "deleted"]
    graph_name: str
    workspace_id: str


@dataclass
class GroupEvent:
    """Details about a group-related event."""

    event_type: Literal["added", "updated", "deleted", "renamed"]
    group_name: str
    workspace_id: str
    old_name: Optional[str] = None  # For rename events


@dataclass
class RunEvent:
    """Details about a run-related event."""

    event_type: Literal["added", "updated", "deleted"]
    run_name: str
    workspace_id: str


@dataclass
class DatasetEvent:
    """Details about a dataset-related event."""

    event_type: Literal["updated", "metadata_changed"]
    workspace_id: str
    dataset_name: Optional[str] = None


EventType = TypeVar("EventType", GraphEvent, GroupEvent, RunEvent, DatasetEvent)


class EventBus(Generic[EventType]):
    def __init__(self):
        self.callbacks: Dict[str, Callable] = {}

    def add_callback(
        self, callback: Union[Callable[[Optional[EventType]], Any], Callable[[], Any]]
    ):
        """Add a callback (callable object) by name."""
        if callable(callback):
            name = getattr(callback, "__name__", "") + str(uuid4())
            self.callbacks[name] = callback
            return name
        else:
            raise ValueError("Callback must be callable")

    def remove_callback(self, name: str):
        """Remove a callback by name."""
        if name in self.callbacks:
            del self.callbacks[name]

    def run_all(self, event: Optional[EventType] = None):
        """Execute all callbacks, passing event details to those that accept them.

        Args:
            event: Optional event details to pass to callbacks that accept them.
                   Callbacks are introspected to determine if they accept parameters.
        """
        for callback in self.callbacks.values():
            # only send event if callback accepts a parameter
            sig = inspect.signature(callback)
            if len(sig.parameters) > 0 and event is not None:
                callback(event)
            else:
                callback()


class GraphEventBus(EventBus[GraphEvent]):
    pass


class GroupEventBus(EventBus[GroupEvent]):
    pass


class RunEventBus(EventBus[RunEvent]):
    pass


class DatasetEventBus(EventBus[DatasetEvent]):
    pass


class EventBusController:
    groups: ClassVar[Dict[str, GroupEventBus]] = {}
    graphs: ClassVar[Dict[str, GraphEventBus]] = {}
    runs: ClassVar[Dict[str, RunEventBus]] = {}
    datasets: ClassVar[Dict[str, DatasetEventBus]] = {}

    @classmethod
    def get_graph_event_bus(cls, workspace_id) -> GraphEventBus:
        if workspace_id not in cls.graphs:
            cls.graphs[workspace_id] = GraphEventBus()
        return cls.graphs[workspace_id]

    @classmethod
    def get_group_event_bus(cls, workspace_id) -> GroupEventBus:
        if workspace_id not in cls.groups:
            cls.groups[workspace_id] = GroupEventBus()
        return cls.groups[workspace_id]

    @classmethod
    def get_run_event_bus(cls, workspace_id) -> RunEventBus:
        if workspace_id not in cls.runs:
            cls.runs[workspace_id] = RunEventBus()
        return cls.runs[workspace_id]

    @classmethod
    def get_dataset_event_bus(cls, workspace_id) -> DatasetEventBus:
        if workspace_id not in cls.datasets:
            cls.datasets[workspace_id] = DatasetEventBus()
        return cls.datasets[workspace_id]
