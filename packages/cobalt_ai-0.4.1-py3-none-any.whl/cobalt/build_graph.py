# Copyright (C) 2023-2024 BlueLightAI, Inc. All Rights Reserved.
#
# Any use, distribution, or modification of this software is subject to the
# terms of the BlueLightAI Software License Agreement.

from collections import defaultdict
from dataclasses import asdict, dataclass, field
from typing import Callable, List, Literal, Optional, Sequence, Tuple, Union

import numpy as np
import scipy.sparse as sp
from mapper import Metric
from mapper.cluster_tree import ClusterTree
from mapper.clustering_scores import make_local_negative_modularity_score_fn
from mapper.config import DEFAULT_KNN_SEED
from mapper.datagraph import HierarchicalDataGraph
from mapper.flat_cluster import optimize_cluster_score_top_down
from mapper.interface import (
    build_base_datagraph_from_knn_graph,
    build_base_datagraph_from_raw_data,
    build_base_graph_auto,
    build_hierarchical_graph_from_base,
    build_knn_graph,
    build_partitions_and_pruning_from_filters,
    get_metric,
)
from mapper.neighborgraph import KNNGraph
from scipy.sparse.csgraph import laplacian
from scipy.sparse.linalg import eigsh

from cobalt import schema
from cobalt.config import handle_cb_exceptions
from cobalt.schema.embedding import ArrayEmbedding, ColumnEmbedding
from cobalt.schema.graph import HierarchicalCobaltGraph


@dataclass
class FilterSpec:
    """A set of parameters for a filter on a graph.

    Separates the dataset into n_bins bins, based on the values of f_vals for
    each data point. Data points within each bin are clustered to form nodes,
    and are linked together if they are in nearby bins.
    """

    f_vals: np.ndarray
    """An array of values, one for each data point."""
    n_bins: int = 10
    """The number of bins to separate the dataset into."""
    bin_method: Literal["rng", "uni"] = "rng"
    """Either "rng" or "uni". If "rng", the bins will have equal width;
    if "uni" they will have equal numbers of data points."""
    pruning_method: Literal["bin", "pct"] = "bin"
    """Either "bin" or "pct". If "bin", will only allow edges
    between nodes from nearby bins. If "pct", will only allow edges between
    nodes whose percentile difference for f_vals is within the given
    threshold.
    """
    pruning_threshold: Union[int, float] = 1
    """The maximum distance two nodes can be apart while still being connected."""
    smoothing_ratio: float = 0.0
    """How much to smooth f_vals on the graph before creating bins.

    :meta private:
    """


@dataclass
class NeighborParams:
    M: Optional[int] = None
    """The number of nearest neighbors to compute for each data point."""

    deduplicate: bool = False
    """Whether to deduplicate the data points before computing nearest neighbors."""
    strict_partition: Optional[np.ndarray] = None
    """An array assigning a partition id to each data point.

    The data will be split into these partitions before building the graph,
    and an independent graph will be built on each subset.
    """

    backend: Literal["nndescent", "exact"] = "nndescent"
    """Method to use to compute nearest neighbors.

    The default "nndescent" is an efficient approximate algorithm. In some
    situations "exact" may provide significantly higher-quality results at the
    expense of more computation (for large datasets).
    """
    seed: Optional[int] = None
    """Random seed to use for the "nndescent" backend.

    Has a fixed default for reproducibility.
    """

    max_dist: float = np.inf
    """The maximum raw distance between data points for which an edge will be included.

    This is an exclusive bound: points at distance max_dist will not have an
    edge between them.
    """

    K: Optional[int] = None
    """The number of mutual nearest neighbors to keep for each data point."""
    min_nbrs: Optional[int] = None
    """The minimum number of neighbors to keep for each data point."""

    normalize_method: Literal["none", "kth_neighbor", "neighborhood_weight"] = (
        "neighborhood_weight"
    )
    """The method used to normalize distances within each neighborhood.

    If "kth_neighbor", will scale the distance to the kth nearest neighbor to 1.
    If "neighborhood_weight", will scale distances so that the sum of weights to
    all neighbors is equal to a target. If "none", no normalization will be applied.

    :meta private:
    """
    normalize_target: Union[Literal["log", "sqrt"], float] = "log"
    """Target value for normalize_method="neighborhood_weight".

    The "log" and "sqrt" options apply these functions to the size of the
    neighborhood to determine the target.

    :meta private:
    """
    normalize_kth_neighbor_idx: Optional[int] = None
    """Value of k to use when normalize_method="kth_neighbor".

    If not provided, defaults to K.

    :meta private:
    """
    affinity: Literal["slpi", "exponential", "expinv", "gaussian"] = "slpi"
    """The function used to convert normalized distances to edge weights."""


@dataclass
class ClusteringParams:
    allow_multiple_merges_per_node: bool = False
    """Whether to allow merging sets of more than two nodes together in a single clustering step.

    The default setting is for backwards compatibility; we recommend setting
    this to True.
    """
    filter_levels_per_component: bool = False
    """Whether to take into account the number of graph components when selecting the output levels.

    After the initial clustering is done, levels are filtered out to ensure a
    certain rate of decrease in the number of nodes per level. When this setting
    is True, the filtering is done to ensure a certain rate of decrease in the
    number of nodes per component per level. This increases the quality of the
    levels for graphs with many small components.

    The default setting is for backwards compatibility; we recommend setting
    this to True.
    """
    num_threads: int = 1
    """Number of threads to use in the node merge step."""
    max_height: int = 1000
    """Maximum number of steps to take while clustering the graph.

    If the top level graph has too many nodes, you can try increasing this.
    """
    max_cluster_growth_rate: float = 2.0
    """How quickly the largest clusters can grow at each clustering step.

    :meta private:
    """
    min_affinity_ratio: float = 0.8
    """Fraction of the maximum weight an edge must be to be considered for merging.

    :meta private:
    """
    min_n_clusters_ratio: float = 0.85
    """Minimum ratio between the number of clusters in adjacent levels.

    The number of nodes in a level must decrease at least this rapidly.

    :meta private:
    """


@dataclass
class GraphSpec:
    """A set of parameters for creating a graph."""

    X: Union[np.ndarray, sp.csr_array]
    """The source data. Shape (n_points, n_dims)."""
    metric: Union[str, Metric]
    """The distance metric to use to create the graph.

    May be given as a name, or as a Metric object (e.g. a CombinedMetric or a
    CustomMetric).
    """
    filters: Sequence[FilterSpec] = ()
    """A (possibly empty) list of FilterSpec objects that describe
    filter functions to apply to the graph.

    These may be provided as dicts that will be used to construct FilterSpec
    objects.
    """
    neighbor_params: Optional[NeighborParams] = None
    """Parameters determining how the underlying neighbor graph is constructed from the embedding.

    May be provided as a dict that will be used to construct a
    NeighborParams object.

    """
    clustering_params: ClusteringParams = field(default_factory=ClusteringParams)
    """Parameters affecting the hierarchical clustering of data points
    that produces the multiresolution graph.

    May be provided as a dict that will be used to construct a ClusteringParams
    object.
    """

    M: Optional[int] = None
    """The number of nearest neighbors to compute for each data point.

    If not provided, this will be chosen automatically. It is preferred to
    specify this parameter as part of neighbor_params.
    """
    K: Optional[int] = None
    """The number of mutual nearest neighbors to keep for each data point.

    If not provided, this will be chosen automatically. It is preferred to
    specify this parameter as part of neighbor_params.
    """
    min_nbrs: Optional[int] = None
    """The minimum number of neighbors to keep for each data point.

    If not provided, this will be chosen automatically. It is preferred to
    specify this parameter as part of neighbor_params.
    """
    affinity: Literal["slpi", "exponential", "expinv", "gaussian"] = "slpi"
    """The function to convert normalized distances into weights.

    It is preferred to specify this parameter as part of neighbor_params.
    """
    L_coarseness: int = 20
    """The number of neighbors to keep for each data point when
    clustering data points into graph nodes.
    """
    L_connectivity: int = 20
    """The number of neighbors to keep for each data point when
    connecting nodes in the graph.
    """

    def __post_init__(self):
        if self.neighbor_params is not None:
            if not isinstance(self.neighbor_params, NeighborParams):
                self.neighbor_params = NeighborParams(**self.neighbor_params)
            self.M = self.neighbor_params.M
            self.K = self.neighbor_params.K
            self.min_nbrs = self.neighbor_params.min_nbrs
        else:
            self.neighbor_params = NeighborParams(
                M=self.M,
                K=self.K,
                min_nbrs=self.min_nbrs,
                affinity=self.affinity,
            )

        # allow specifying filters as dicts
        self.filters = [
            FilterSpec(**f) if not isinstance(f, FilterSpec) else f
            for f in self.filters
        ]

        # allow specifying clustering_params as a dict
        if self.clustering_params is not None and not isinstance(
            self.clustering_params, ClusteringParams
        ):
            self.clustering_params = ClusteringParams(**self.clustering_params)

    def _get_neighbor_params(self) -> NeighborParams:
        if self.neighbor_params is not None:
            return self.neighbor_params
        return NeighborParams(
            metric=self.metric,
            M=self.M,
            K=self.K,
            min_nbrs=self.min_nbrs,
            affinity=self.affinity,
        )


class GraphBuilder:
    def __init__(self, state):
        self.state = state

    @staticmethod
    @handle_cb_exceptions
    def mapper_graph_from_spec(
        params: GraphSpec,
        knn_graph: Optional[KNNGraph] = None,
        node_membership: Optional[np.ndarray] = None,
    ) -> HierarchicalDataGraph:
        """Construct a Mapper graph with the given parameters.

        Chooses some parameters automatically if not provided.

        Will use pre-computed KNN graph if passed along with params.
        """
        neighbor_params = params._get_neighbor_params()
        if (
            neighbor_params.M is None
            or neighbor_params.K is None
            or neighbor_params.min_nbrs is None
        ):
            base_graph = build_base_graph_auto(
                params.X,
                params.metric,
                max_neighbors=neighbor_params.M or 50,
                affinity=neighbor_params.affinity,
                strict_partition=neighbor_params.strict_partition,
                deduplicate=neighbor_params.deduplicate,
                backend=neighbor_params.backend,
                seed=neighbor_params.seed or DEFAULT_KNN_SEED,
                max_dist=neighbor_params.max_dist,
                normalize_method=neighbor_params.normalize_method,
                normalize_target=neighbor_params.normalize_target,
                normalize_kth_neighbor_idx=neighbor_params.normalize_kth_neighbor_idx,
            )
        else:
            if knn_graph is not None and node_membership is not None:
                base_graph = build_base_datagraph_from_knn_graph(
                    knn_graph=knn_graph,
                    node_membership=node_membership,
                    metric=params.metric,
                    M=neighbor_params.M,
                    K=neighbor_params.K,
                    min_nbrs=neighbor_params.min_nbrs,
                    affinity=neighbor_params.affinity,
                    strict_partition=neighbor_params.strict_partition,
                    deduplicate=neighbor_params.deduplicate,
                    backend=neighbor_params.backend,
                    seed=neighbor_params.seed or DEFAULT_KNN_SEED,
                    max_dist=neighbor_params.max_dist,
                    normalize_method=neighbor_params.normalize_method,
                    normalize_target=neighbor_params.normalize_target,
                    normalize_kth_neighbor_idx=neighbor_params.normalize_kth_neighbor_idx,
                )
            else:
                base_graph = build_base_datagraph_from_raw_data(
                    params.X,
                    metric=params.metric,
                    M=neighbor_params.M,
                    K=neighbor_params.K,
                    min_nbrs=neighbor_params.min_nbrs,
                    affinity=neighbor_params.affinity,
                    strict_partition=neighbor_params.strict_partition,
                    deduplicate=neighbor_params.deduplicate,
                    backend=neighbor_params.backend,
                    seed=neighbor_params.seed or DEFAULT_KNN_SEED,
                    max_dist=neighbor_params.max_dist,
                    normalize_method=neighbor_params.normalize_method,
                    normalize_target=neighbor_params.normalize_target,
                    normalize_kth_neighbor_idx=neighbor_params.normalize_kth_neighbor_idx,
                )

        filters = [asdict(spec) for spec in params.filters]
        partitions, pruning_predicates = build_partitions_and_pruning_from_filters(
            filters, base_graph
        )

        g = build_hierarchical_graph_from_base(
            base_graph,
            clustering_params=asdict(params.clustering_params),
            data_partitions=partitions,
            cluster_pruning=pruning_predicates,  # not totally backwards compatible but good
            partition_graph_pruning=pruning_predicates,
            L_coarseness=params.L_coarseness,
            L_connectivity=params.L_connectivity,
        )

        return g

    def new_graph(
        self,
        subset: schema.CobaltDataSubset,
        embedding: schema.Embedding,
        name: Optional[str] = None,
        metric: Optional[Union[str, Metric]] = None,
        grid_search: bool = False,
        **kwargs,
    ) -> HierarchicalCobaltGraph:
        """Create a new graph from a specified subset.

        Args:
            subset: The subset of the dataset to include in the graph.
            embedding: The embedding to use to generate the graph.
            name: The name for the graph. If not provided, a name will be
                generated based on the embedding name.
            metric: The distance metric to use when constructing the graph. If none
                is provided, will use the metric specified by the embedding.
            grid_search: If True, perform a grid search over graph parameters to
                select the best graph according to scorer. Default is False.
            **kwargs: Any additional keyword parameters will be interpreted as parameters to
                construct a `GraphSpec` object.
                Special options for grid_search:
                - param_grid, scorer, subsample_max_size, random_state, reverse
                - embedding_search_mode: one of
                    'given' (default): only use the passed embedding
                    'all': all existing embeddings in the dataset
                    'given_plus_generated': passed embedding plus auto-generated
                       scaled + random forest embeddings derived from it.
                       NOTE: This mode permanently adds the generated embeddings
                       (scaled_standardize, scaled_robust, rf) to the dataset,
                       even if they are not selected as the best embedding.

        Returns:
            HierarchicalCobaltGraph: The created graph with metadata.
        """
        if len(subset) < 2:
            raise ValueError(
                "Subset for graph construction must contain at least two elements."
            )

        # Generate a default name if not provided
        if name is None:
            name = f"graph_{embedding.name}"

        base_X = embedding.get(subset)
        base_embedding_metadata = embedding

        # Pop grid search options from kwargs so they don't get passed to GraphSpec
        param_grid = kwargs.pop("param_grid", None)
        scorer = kwargs.pop("scorer", "spectral_score")
        subsample_max_size = kwargs.pop("subsample_max_size", 1000)
        random_state = kwargs.pop("random_state", 42)
        reverse = kwargs.pop("reverse", True)
        embedding_search_mode = kwargs.pop("embedding_search_mode", "given")

        if not grid_search:
            if metric is None:
                metric = base_embedding_metadata.default_distance_metric
            g = self.mapper_graph_from_spec(GraphSpec(base_X, metric, **kwargs))
            params = {"metric": metric, **kwargs}
            return HierarchicalCobaltGraph(
                name=name,
                graph=g,
                subset=subset,
                params=params,
                embedding=base_embedding_metadata,
            )

        # Remaining kwargs are GraphSpec overrides applied only to final graph
        graph_spec_overrides = kwargs

        dataset = subset.source_dataset

        # Determine embedding candidates
        if embedding_search_mode == "all":
            embedding_candidates = dataset.embedding_metadata
        elif embedding_search_mode == "given_plus_generated":
            embedding_candidates = [base_embedding_metadata]

            if isinstance(base_embedding_metadata, (ColumnEmbedding, ArrayEmbedding)):
                generated_names = []
                base_name = base_embedding_metadata.name

                # Scaled embeddings (standardize & robust)
                for scaling in ("standardize", "robust"):
                    scaled_name = f"{base_name}_scaled_{scaling}_auto"
                    if scaled_name not in dataset.embedding_names:
                        dataset.add_scaled_embedding(
                            base_embedding_metadata,
                            scaling=scaling,
                            embedding_name=scaled_name,
                        )
                        generated_names.append(scaled_name)

                # RF embedding (unsupervised)
                rf_name = f"{base_name}_rf_auto"
                if rf_name not in dataset.embedding_names:
                    dataset.add_rf_embedding(
                        source_embedding=base_embedding_metadata,
                        embedding_name=rf_name,
                    )
                    generated_names.append(rf_name)

                for n in generated_names:
                    embedding_candidates.append(
                        dataset.get_embedding_metadata_by_name(n)
                    )

        else:  # 'given'
            embedding_candidates = [base_embedding_metadata]

        if not embedding_candidates:
            raise ValueError("No embeddings available for grid search.")

        all_scored_entries = []
        for emb in embedding_candidates:
            X_emb = emb.get(subset)
            local_metric = metric if metric is not None else emb.default_distance_metric
            scored = build_and_score_graphs(
                X_emb,
                local_metric,
                param_grid=param_grid,
                scorer=scorer,
                subsample_max_size=subsample_max_size,
                random_state=random_state,
                reverse=reverse,
            )
            # Annotate each scored entry with embedding metadata
            for entry in scored:
                entry["embedding_name"] = emb.name
                entry["embedding_obj"] = emb
                all_scored_entries.append(entry)

        if not all_scored_entries:
            raise ValueError("No candidate graphs were generated across embeddings.")

        best = sorted(all_scored_entries, key=lambda x: x["score"], reverse=reverse)[0]
        selected_params = dict(best["params"])
        selected_embedding = best["embedding_obj"]
        selected_metric = (
            metric if metric is not None else selected_embedding.default_distance_metric
        )

        X_full = selected_embedding.get(subset)
        final_graph = self.mapper_graph_from_spec(
            GraphSpec(
                X_full,
                selected_metric,
                **graph_spec_overrides,
                **selected_params,  # selected params override any overrides with same keys
            )
        )

        # Build params dict with grid search details
        params = {
            "metric": selected_metric,
            **graph_spec_overrides,
            "grid_search_details": {
                "selected_params": selected_params,
                "score": best["score"],
                "selected_embedding_name": selected_embedding.name,
                "embedding_search_mode": embedding_search_mode,
                "scorer": scorer,
                "reverse": reverse,
                "subsample_graph": best["graph"],
                "subsample_score_details": {
                    k: v
                    for k, v in best.items()
                    if k not in ("params", "graph", "embedding_obj")
                },
                "all_scores": all_scored_entries,
            },
        }

        return HierarchicalCobaltGraph(
            name=name,
            graph=final_graph,
            subset=subset,
            params=params,
            embedding=selected_embedding,
        )

    def get_subset(
        self, subset: Union[str, schema.CobaltDataSubset]
    ) -> schema.CobaltDataSubset:
        return self.state.get_subset(subset)

    @staticmethod
    def get_embedding(
        subset: schema.CobaltDataSubset, embedding: Union[int, str, schema.Embedding]
    ) -> Tuple[np.ndarray, schema.Embedding]:
        X, embedding_metadata = subset.get_graph_inputs(embedding)
        return X, embedding_metadata


def generate_param_grid(
    K_values: Optional[List[int]] = None,
    M_values: Optional[List[int]] = None,
    min_nbrs_values: Optional[List[int]] = None,
    affinity_values: Optional[List[str]] = None,
) -> List[dict]:
    """Generate set of parameters for grid search.

    Returns a list of parameter dicts for K, M, min_nbrs, and affinity,
    suitable for build_graph_candidates(). Only returns combinations
    with min_nbrs <= K <= M.
    """
    if K_values is None:
        K_values = [5, 10, 15]
    if M_values is None:
        M_values = [10, 20, 30]
    if min_nbrs_values is None:
        min_nbrs_values = [2, 5, 10]
    if affinity_values is None:
        affinity_values = ["slpi", "exponential", "expinv"]

    if not K_values or not M_values or not min_nbrs_values or not affinity_values:
        raise ValueError("Specified parameter lists must be non-empty.")

    grid = []
    for K in K_values:
        for M in M_values:
            for min_nbrs in min_nbrs_values:
                if min_nbrs <= K <= M:
                    for affinity in affinity_values:
                        grid.append(
                            {"K": K, "M": M, "min_nbrs": min_nbrs, "affinity": affinity}
                        )
    return grid


def _build_single_candidate(
    X_sub: np.ndarray,
    metric: str,
    params: dict,
    knn_graph: Optional[KNNGraph] = None,
    node_membership: Optional[np.ndarray] = None,
) -> Optional[Tuple[dict, "HierarchicalDataGraph"]]:
    """Build single candidate graph with optional precomputed KNN graph."""
    spec = GraphSpec(X_sub, metric, **params)
    g = GraphBuilder.mapper_graph_from_spec(
        spec, knn_graph=knn_graph, node_membership=node_membership
    )
    if g is not None:
        return (params, g)
    return None


def build_graph_candidates(
    X: np.ndarray,
    metric: str,
    param_grid: Optional[List[dict]] = None,
    subsample_max_size: int = 1000,
    random_state: int = 42,
) -> List[Tuple[dict, HierarchicalDataGraph]]:
    """Build the candidate graphs for a given or default parameter grid.

    Builds multiple HierarchicalDataGraph candidates with parameters specified in
    param_grid. If not supplied, generate a default param_grid.

    If N is larger than subsample_max_size, subsample to subsample_max_size.
    Returns a list of (params, HierarchicalDataGraph) tuples.

    If param_grid is an empty list, returns an empty list of candidates.

    NOTE: Omits null (None) graphs, which will be returned if the methods in
    mapper.interface fail, for example if M >= X.shape[0]. # TODO: handle differently?
    """
    n = X.shape[0]
    if n > subsample_max_size:
        rng = np.random.default_rng(random_state)
        idx = rng.choice(n, subsample_max_size, replace=False)
        X_sub = X[idx]
    else:
        X_sub = X

    if param_grid is None:
        param_grid = generate_param_grid()
    elif param_grid == []:
        return []

    candidates = []

    # Group param_grid by M vals
    m_to_params = defaultdict(list)
    for params in param_grid:
        m_to_params[params["M"]].append(params)

    # Store KNN graph for each M
    # Compute once for max M, then truncate
    knn_graphs = {}
    max_M = max(m_to_params.keys())
    metric_obj = get_metric(metric)
    knn_graph_full, node_membership = build_knn_graph(X_sub, metric_obj, max_M)
    knn_graphs[max_M] = knn_graph_full

    for M in m_to_params:
        if max_M == M:
            continue
        knn_graphs[M] = knn_graph_full.truncated(M)

    for M, params_list in m_to_params.items():
        knn_graph = knn_graphs[M]
        for params in params_list:
            result = _build_single_candidate(
                X_sub,
                metric,
                params,
                knn_graph,
                node_membership,
            )
            if result is not None:
                candidates.append(result)

    return candidates


def graph_quality_score_spectral(
    graph: HierarchicalDataGraph,
    alpha: float = 1.0,
    beta: float = 1.0,
    gamma: float = 1.0,
    delta: float = 1.0,
    normed: bool = True,
) -> dict:
    """Compute a graph quality score using spectral features.

    Includes connectivity, spectral gap, number of connected components, and hubness.

    Returns a dict with 'score' plus other computed features.
    """
    A_csr = graph.base_graph.csr_graph.get_adjacency_matrix()
    L_csr = laplacian(A_csr, normed=normed)
    num_nodes = A_csr.shape[0]
    if num_nodes < 3:
        raise ValueError(
            "Graph must have at least 3 nodes to compute spectral features."
        )

    k_small = min(10, num_nodes - 1)
    eigvals_small = eigsh(L_csr, k=k_small, which="SM", return_eigenvectors=False)
    eigvals_small = np.sort(eigvals_small)

    eigvals_large = eigsh(L_csr, k=1, which="LA", return_eigenvectors=False)

    # Spectral features
    lambda_0 = eigvals_small[0]  # noqa: F841
    lambda_1 = eigvals_small[1] if len(eigvals_small) > 1 else 0  # Connectivity
    lambda_2 = eigvals_small[2] if len(eigvals_small) > 2 else lambda_1
    spectral_gap = lambda_2 - lambda_1  # Separability of partitions
    lambda_max = eigvals_large[0]  # Hub structures

    # Number of connected components
    # TODO: if more than k_small, we won't know
    tol = 1e-5
    num_components = np.sum(np.isclose(eigvals_small, 0, atol=tol))

    # TODO: in visual tests, these don't always behave the way I expect
    score = (
        -alpha * lambda_1
        + beta * spectral_gap
        + -gamma * num_components
        + -delta * lambda_max
    )

    return {
        "score": score,
        "lambda_1": lambda_1,
        "spectral_gap": spectral_gap,
        "num_components": num_components,
        "lambda_max": lambda_max,
    }


def graph_quality_score_modularity(
    graph: HierarchicalDataGraph,
    min_group_size: int = 1,
    max_group_size: float = np.inf,
    min_n_groups: int = 1,
    max_n_groups: int = 100,
    modularity_r: float = 0,
    partition: Optional[np.ndarray] = None,
) -> dict:
    """Compute a graph quality score using partition modularity.

    Partition is computed using mapper.flat_cluster.optimize_cluster_score_top_down.

    Returns a dict with 'score' (modularity) and 'partition' array.
    """
    n_nodes = graph.base_graph.csr_graph.n_nodes

    if partition is None:
        cluster_tree = ClusterTree.from_graph_with_constraints(
            graph, max_n_clusters=n_nodes / min_group_size
        )
        modularity_score_fn = make_local_negative_modularity_score_fn(
            graph.base_graph, modularity_r=modularity_r
        )
        clusters = optimize_cluster_score_top_down(
            cluster_tree,
            local_score_fns=[modularity_score_fn],
            min_cluster_size=min_group_size,
            max_cluster_size=max_group_size,
            max_n_clusters=max_n_groups,
            min_n_clusters=min_n_groups,
        )

        # Convert clusters to a partition array
        partition = np.empty(n_nodes, dtype=np.int32)
        for label, node_indices in enumerate(clusters):
            partition[node_indices] = label

    if len(partition) != n_nodes:
        raise ValueError(
            f"Partition length {len(partition)} does not match number of nodes in graph: {n_nodes}."
        )
    modularity = graph.base_graph.csr_graph.partition_modularity(partition)
    return {"score": modularity, "partition": partition}


SCORING_FUNCTIONS = {
    "spectral_score": graph_quality_score_spectral,
    "modularity_score": graph_quality_score_modularity,
}


def score_and_sort_graph_candidates(
    candidates: List[Tuple[dict, HierarchicalDataGraph]],
    scorer: Union[str, Callable] = "spectral_score",
    reverse: bool = True,
) -> List[dict]:
    """Helper function to score and sort a list of graph candidates.

    Given a list of (params, graph) tuples and a scoring function,
    return a sorted list (best first) of dicts with score, params,
    graph, and other details.
    """
    if isinstance(scorer, str):
        if scorer not in SCORING_FUNCTIONS:
            raise ValueError(
                f"Unknown scoring function: {scorer}. Options: {list(SCORING_FUNCTIONS.keys())}"
            )
        scoring_fn = SCORING_FUNCTIONS[scorer]
    elif callable(scorer):
        scoring_fn = scorer
    else:
        raise TypeError("scorer must be a string key or a callable.")

    scores = []
    for params, graph in candidates:
        score_dict = scoring_fn(graph)
        score_dict["params"] = params
        score_dict["graph"] = graph
        if "score" not in score_dict:
            raise ValueError(
                f"Scoring function {scoring_fn} did not return a 'score' key."
            )
        scores.append(score_dict)
    return sorted(scores, key=lambda x: x["score"], reverse=reverse)


def build_and_score_graphs(
    X: np.ndarray,
    metric: str,
    param_grid: Optional[List[dict]] = None,
    scorer: str = "spectral_score",
    subsample_max_size: int = 1000,
    random_state: int = 42,
    reverse: bool = True,
) -> List[dict]:
    """Helper function for building and scoring graph candidates."""
    candidates = build_graph_candidates(
        X,
        metric,
        param_grid=param_grid,
        subsample_max_size=subsample_max_size,
        random_state=random_state,
    )
    return score_and_sort_graph_candidates(candidates, scorer=scorer, reverse=reverse)


def build_best_graph(
    X: np.ndarray,
    metric: str,
    param_grid: Optional[List[dict]] = None,
    scorer: str = "spectral_score",
    subsample_max_size: int = 1000,
    random_state: int = 42,
    reverse: bool = True,
    return_details: bool = False,
) -> Union[HierarchicalDataGraph, Tuple[HierarchicalDataGraph, dict]]:
    """Return the best graph, built using all data, based on grid search + scoring.

    Runs a parameter grid search (optionally on a subsample) to pick the best
    parameter set, then rebuilds and returns a single HierarchicalDataGraph
    using the full original data.

    Args:
        X: Full data array.
        metric: Distance metric name.
        param_grid: Optional list of param dicts (K, M, min_nbrs, affinity). If None,
        uses generate_param_grid().
        scorer: Key for SCORING_FUNCTIONS or a callable.
        subsample_max_size: Max size for scoring phase subsampling.
        random_state: RNG seed for subsampling.
        reverse: If True (default) higher score is better; passed through to sorting.
        return_details: If True, also return a dict with metadata (chosen params, scores, etc.).

    Returns:
        HierarchicalDataGraph or (HierarchicalDataGraph, details_dict) if return_details=True.
    """
    scored = build_and_score_graphs(
        X,
        metric,
        param_grid=param_grid,
        scorer=scorer,
        subsample_max_size=subsample_max_size,
        random_state=random_state,
        reverse=reverse,
    )
    if not scored:
        raise ValueError(
            "No candidate graphs were generated (empty param_grid or invalid combinations)."
        )

    best = scored[0]
    best_params = dict(best["params"])

    final_graph = GraphBuilder.mapper_graph_from_spec(
        GraphSpec(X, metric, **best_params)
    )

    if not return_details:
        return final_graph

    # Remove full graph objects from scored list copies if user wants lightweight details.
    details = {
        "selected_params": best["params"],
        "score": best["score"],
        "scorer": scorer,
        "reverse": reverse,
        "subsample_graph": best["graph"],
        "subsample_score_details": {
            k: v for k, v in best.items() if k not in ("params", "graph")
        },
        "all_scores": scored,  # contains each scored dict including its 'graph'
    }
    return final_graph, details
