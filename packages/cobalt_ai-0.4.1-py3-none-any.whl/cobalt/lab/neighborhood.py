import numpy as np
import scipy.sparse as sp

from cobalt.schema.dataset import CobaltDataSubset
from cobalt.schema.graph import HierarchicalCobaltGraph


def get_group_neighborhood(
    group: CobaltDataSubset,
    graph: HierarchicalCobaltGraph,
    nbhd_size_ratio: float = 2,
    mass_thresh: float = 0.1,
    max_diff_iter: int = 100,
    diffusion_ratio: float = 0.5,
) -> CobaltDataSubset:
    """Finds a neighborhood of points around ``group`` in ``graph``.

    Works by diffusing a probability mass from the group into the graph until
    the mass on the original group has decayed to ``mass_thresh`` times the
    original mass. Then a neighborhood of the target size is selected by
    ordering these points by weight.

    Args:
        group: The group whose neighbors will be found.
        graph: The HierarchicalCobaltGraph that will define the neighbors. This graph should
            be built on a subset containing ``group``.
        nbhd_size_ratio: Target ratio of neighborhood size to group size.
        mass_thresh: Mass threshold for diffusion.
        max_diff_iter: Maximum number of diffusion iterations.
        diffusion_ratio: Fraction of local mass that diffuses to neighbors in a
            diffusion step.

    Returns:
        A CobaltDataSubset containing the neighborhood.
    """
    source_data = graph.subset

    csr_g = graph.base_graph.csr_graph
    # TODO: add support for base graphs with non-singleton nodes

    A = csr_g.get_adjacency_matrix(weight_attr="distance")
    A.data = np.exp(-A.data)
    # this makes A column stochastic
    A = A @ sp.diags(1 / np.maximum(A.sum(axis=0), 1e-9))
    A = A.tocsr()

    if len(source_data) != csr_g.n_nodes:
        raise ValueError(
            "Number of nodes in graph does not match number of data points in source data subset."
        )

    subset_mask = group.as_mask_on(source_data).astype(np.float32)
    subset_ind = np.flatnonzero(subset_mask)
    dist = subset_mask.copy()
    orig_mass = len(group)
    for _ in range(max_diff_iter):
        dist = (diffusion_ratio * A @ dist) + (1 - diffusion_ratio) * dist
        new_mass = np.sum(dist[subset_ind])
        if new_mass < mass_thresh * orig_mass:
            break

    thresh_min = dist.min()
    thresh_max = dist.max()
    target_n_points = int(len(group) * nbhd_size_ratio)

    n_bisect_iter = 15
    for _ in range(n_bisect_iter):
        thresh = (thresh_max + thresh_min) / 2
        n_points = np.sum(dist > thresh)
        if n_points < target_n_points:
            thresh_max = thresh
        else:
            thresh_min = thresh

    expanded_subset = source_data.mask(dist > thresh)
    return expanded_subset
