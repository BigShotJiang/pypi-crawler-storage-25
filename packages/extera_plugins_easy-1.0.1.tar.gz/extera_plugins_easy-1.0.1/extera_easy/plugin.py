import traceback
import threading
import random
from typing import Any, List, Callable, Optional

from java.util import ArrayList

from base_plugin import BasePlugin, HookResult, HookStrategy, MenuItemData, MenuItemType
from client_utils import send_request, RequestCallback, get_messages_controller, get_last_fragment, get_account_instance, get_user_config
from android_utils import run_on_ui_thread, log
from ui.alert import AlertDialogBuilder
from ui.bulletin import BulletinHelper
from org.telegram.tgnet import TLRPC
from org.telegram.messenger import NotificationCenter
from android.widget import Toast

from .utils import (
    java_len, make_runnable, make_click_listener,
    ChatUtils, MessageBuilder, InputMediaBuilder,
    SequentialWorker, NotificationListener, UpdateChecker,
    DialogBuilder
)


# =============================================================================
# КОНТЕКСТЫ ДЛЯ ДЕКОРАТОРОВ
# =============================================================================

class CommandContext:
    def __init__(self, account, params, text, args, raw_args):
        self.account = account
        self.params = params
        self.text = text
        self.args = args
        self.raw_args = raw_args
        self.chat_id = ChatUtils.dialog_id_from_peer(getattr(params, 'peer', None))


class MessageContext:
    def __init__(self, msg, account):
        self.msg = msg
        self.message_object = msg
        self.message_owner = getattr(msg, 'messageOwner', None)
        self.account = account
        self.chat_id = ChatUtils.dialog_id_from_peer(getattr(self.message_owner, 'peer_id', None))


# =============================================================================
# EASY PLUGIN MIXIN
# =============================================================================

class EasyPlugin:
    """
    Mixin с сахаром для exteraGram.
    Не наследуется от BasePlugin — подмешивается в класс плагина.
    
    Пример:
        class MyPlugin(BasePlugin, EasyPlugin):
            def __init__(self):
                BasePlugin.__init__(self)
                EasyPlugin.__init__(self)
            
            def on_plugin_load(self):
                BasePlugin.on_plugin_load(self)
                EasyPlugin.on_plugin_load(self)
    """
    
    # --- Инициализация ---
    
    def __init__(self):
        self._workers: List[SequentialWorker] = []
        self._listeners: List[NotificationListener] = []
        self._send_message_handlers: List[tuple] = []
        self._command_handlers: List[tuple] = []
        self._message_listeners: List[dict] = []
        self._decorated_registered = False

    def on_plugin_load(self):
        """
        Вызывай явно из своего плагина:
            EasyPlugin.on_plugin_load(self)
        """
        if not self._decorated_registered:
            self._register_decorated_handlers()
            self._decorated_registered = True

    def _register_decorated_handlers(self):
        """Сканирует методы класса на декораторы."""
        for attr_name in dir(self):
            if attr_name.startswith('_'):
                continue
            method = getattr(self, attr_name, None)
            if not callable(method):
                continue
            
            cmd_info = getattr(method, '_extera_command', None)
            if cmd_info:
                self._register_command_handler(method, cmd_info)
            
            hook_info = getattr(method, '_extera_hook', None)
            if hook_info:
                self._register_decorated_hook(method, hook_info)

        if self._command_handlers or self._send_message_handlers:
            self.add_on_send_message_hook(priority=0)
        
        for info in self._message_listeners:
            self._setup_message_listener(info)

    def _register_command_handler(self, method, info):
        name = info['name']
        priority = info['priority']
        
        def handler(account, params):
            text = getattr(params, 'message', '') or ''
            if not isinstance(text, str):
                return None
            stripped = text.strip()
            if not stripped.startswith(name):
                return None
            
            parts = stripped.split(' ', 1)
            args_str = parts[1] if len(parts) > 1 else ''
            args = [a.strip() for a in args_str.split() if a.strip()]
            
            ctx = CommandContext(account=account, params=params, text=text, args=args, raw_args=args_str)
            
            try:
                result = method(self, ctx)
                if isinstance(result, str):
                    params.message = result
                    return HookResult(strategy=HookStrategy.MODIFY, params=params)
                elif isinstance(result, HookResult):
                    return result
                return HookResult()
            except Exception:
                log(f"[{self.__class__.__name__}] command '{name}' error: {traceback.format_exc()}")
                return HookResult()
        
        self._command_handlers.append((priority, handler))

    def _register_decorated_hook(self, method, info):
        htype = info['type']
        flt = info.get('filter')
        
        if htype == 'send_message':
            priority = info['priority']
            
            def handler(account, params):
                if flt and not flt(params):
                    return None
                try:
                    result = method(self, account, params)
                    if isinstance(result, str):
                        params.message = result
                        return HookResult(strategy=HookStrategy.MODIFY, params=params)
                    elif isinstance(result, HookResult):
                        return result
                    return HookResult()
                except Exception:
                    log(f"[{self.__class__.__name__}] on_send_message error: {traceback.format_exc()}")
                    return HookResult()
            
            self._send_message_handlers.append((priority, handler))
        
        elif htype == 'message':
            self._message_listeners.append({
                '_method': method,
                '_filter': flt,
            })

    def _setup_message_listener(self, info):
        method = info['_method']
        flt = info['_filter']
        
        def callback(id, account, args):
            messages = args[1]
            for i in range(messages.size()):
                msg = messages.get(i)
                if flt and not flt(msg):
                    continue
                try:
                    ctx = MessageContext(msg=msg, account=account)
                    method(self, ctx)
                except Exception:
                    log(f"[{self.__class__.__name__}] on_message error: {traceback.format_exc()}")
        
        self.listen_notification(NotificationCenter.didReceiveNewMessages, callback)

    def on_send_message_hook(self, account, params):
        all_handlers = self._command_handlers + self._send_message_handlers
        all_handlers.sort(key=lambda x: x[0])
        
        for _, handler in all_handlers:
            result = handler(account, params)
            if result is None:
                continue
            if isinstance(result, str):
                params.message = result
                return HookResult(strategy=HookStrategy.MODIFY, params=params)
            if isinstance(result, HookResult):
                if result.strategy == HookStrategy.MODIFY_FINAL:
                    return result
                if result.strategy == HookStrategy.CANCEL:
                    return result
                if result.strategy == HookStrategy.MODIFY:
                    params = result.params
                    continue
        return HookResult()

    # --- Отправка сообщений ---
    
    def send_text(self, chat_id: int, text: str, reply_to: int = 0,
                  entities: Any = None, silent: bool = False) -> None:
        try:
            req = TLRPC.TL_messages_sendMessage()
            req.peer = ChatUtils.get_input_peer(chat_id)
            req.message = text
            req.random_id = random.getrandbits(63)
            if silent:
                req.flags |= 128
            if reply_to > 0:
                req.reply_to = TLRPC.TL_inputReplyToMessage()
                req.reply_to.reply_to_msg_id = reply_to
                req.flags |= 1
            if entities and not entities.isEmpty():
                req.entities = entities
                req.flags |= 8
            send_request(req, RequestCallback(lambda r, e: None))
        except Exception:
            log(f"[{self.__class__.__name__}] send_text error: {traceback.format_exc()}")

    def send_media(self, chat_id: int, input_media: Any, caption: str = "",
                   reply_to: int = 0, entities: Any = None) -> None:
        try:
            req = TLRPC.TL_messages_sendMedia()
            req.peer = ChatUtils.get_input_peer(chat_id)
            req.media = input_media
            req.message = caption
            req.random_id = random.getrandbits(63)
            if reply_to > 0:
                req.reply_to = TLRPC.TL_inputReplyToMessage()
                req.reply_to.reply_to_msg_id = reply_to
                req.flags |= 1
            if entities and not entities.isEmpty():
                req.entities = entities
                req.flags |= 8
            send_request(req, RequestCallback(lambda r, e: None))
        except Exception:
            log(f"[{self.__class__.__name__}] send_media error: {traceback.format_exc()}")

    def forward_message(self, msg_obj: Any, to_chat_id: int, drop_author: bool = True) -> None:
        try:
            req = TLRPC.TL_messages_forwardMessages()
            req.from_peer = ChatUtils.get_input_peer(msg_obj.messageOwner.peer_id)
            req.to_peer = ChatUtils.get_input_peer(to_chat_id)
            req.id = ArrayList()
            req.id.add(msg_obj.messageOwner.id)
            req.random_id = ArrayList()
            req.random_id.add(random.getrandbits(63))
            req.drop_author = drop_author
            req.flags |= 8 if drop_author else 0
            send_request(req, RequestCallback(lambda r, e: None))
        except Exception:
            log(f"[{self.__class__.__name__}] forward_message error: {traceback.format_exc()}")

    def delete_message(self, chat_id: int, message_id: int) -> None:
        try:
            id_list = ArrayList()
            id_list.add(message_id)
            channel_id = 0
            if str(chat_id).startswith("-100"):
                channel_id = int(str(chat_id)[4:])
            get_messages_controller().deleteMessages(
                id_list, None, None, chat_id, 0, True, channel_id
            )
        except Exception:
            log(f"[{self.__class__.__name__}] delete_message error: {traceback.format_exc()}")

    # --- UI-хелперы ---
    
    def show_toast(self, message: str) -> None:
        act = self._get_activity()
        if act:
            run_on_ui_thread(lambda: Toast.makeText(act, message, Toast.LENGTH_SHORT).show())

    def show_bulletin_info(self, message: str) -> None:
        BulletinHelper.show_info(message, get_last_fragment())

    def show_bulletin_error(self, message: str) -> None:
        BulletinHelper.show_error(message, get_last_fragment())

    def show_dialog(self, title: str, message: str = "",
                    positive_text: str = "OK", positive_callback: Callable = None,
                    negative_text: str = None, negative_callback: Callable = None) -> None:
        act = self._get_activity()
        if not act:
            return
        builder = AlertDialogBuilder(act)
        builder.set_title(title)
        if message:
            builder.set_message(message)
        if positive_text:
            builder.set_positive_button(
                positive_text, lambda b, w: positive_callback() if positive_callback else None
            )
        if negative_text:
            builder.set_negative_button(
                negative_text, lambda b, w: negative_callback() if negative_callback else None
            )
        run_on_ui_thread(builder.show)

    # --- Меню ---
    
    def add_chat_menu(self, text: str, on_click: Callable, icon: str = "msg_forward") -> None:
        self.add_menu_item(
            MenuItemData(
                menu_type=MenuItemType.CHAT_ACTION_MENU,
                text=text,
                on_click=on_click,
                icon=icon,
            )
        )

    def add_drawer_menu(self, text: str, on_click: Callable, icon: str = "msg_settings") -> None:
        self.add_menu_item(
            MenuItemData(
                menu_type=MenuItemType.DRAWER_MENU,
                text=text,
                on_click=on_click,
                icon=icon,
            )
        )

    # --- Нотификации ---
    
    def listen_notification(self, notification_id: int, callback: Callable) -> NotificationListener:
        listener = NotificationListener(callback, notification_id)
        account = get_account_instance()
        if account:
            account.getNotificationCenter().addObserver(listener, notification_id)
        self._listeners.append(listener)
        return listener

    def unlisten_notification(self, listener: NotificationListener) -> None:
        account = get_account_instance()
        if account:
            account.getNotificationCenter().removeObserver(listener, listener.notification_id)
        if listener in self._listeners:
            self._listeners.remove(listener)

    # --- Воркеры ---
    
    def create_worker(self, delay: float = 0.0) -> SequentialWorker:
        worker = SequentialWorker(delay=delay)
        worker.start()
        self._workers.append(worker)
        return worker

    # --- Типизированные настройки ---
    
    @property
    def my_id(self) -> int:
        return get_user_config().getClientUserId()

    def get_int(self, key: str, default: int = 0) -> int:
        return int(self.get_setting(key, str(default)))

    def get_float(self, key: str, default: float = 0.0) -> float:
        return float(self.get_setting(key, str(default)))

    def get_bool(self, key: str, default: bool = False) -> bool:
        return self.get_setting(key, str(default).lower()).lower() in ("true", "1", "yes", "on")

    def get_json(self, key: str, default: Any = None) -> Any:
        import json
        try:
            return json.loads(self.get_setting(key, "{}"))
        except Exception:
            return default if default is not None else {}

    def set_json(self, key: str, value: Any) -> None:
        import json
        self.set_setting(key, json.dumps(value))

    # --- Внутреннее ---
    
    def _get_activity(self):
        f = get_last_fragment()
        return f.getParentActivity() if f else None

    def on_plugin_unload(self):
        """Вызывай явно из своего плагина перед super().on_plugin_unload()"""
        for worker in self._workers:
            worker.stop()
        self._workers.clear()
        for listener in list(self._listeners):
            self.unlisten_notification(listener)