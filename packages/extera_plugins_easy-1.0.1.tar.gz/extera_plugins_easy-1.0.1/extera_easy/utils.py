import traceback
import threading
import time
import json
import random
from typing import Any, Callable, List, Optional, Tuple

from java.chaquopy import dynamic_proxy
from java.lang import Runnable, String as JavaString
from java.util import ArrayList

from android_utils import run_on_ui_thread, log
from client_utils import get_messages_controller, get_user_config, send_request, RequestCallback
from org.telegram.tgnet import TLRPC
from org.telegram.messenger import NotificationCenter, AndroidUtilities, Utilities
from android.view import View, ViewGroup
from android.widget import LinearLayout, EditText as AndroidEditText, TextView, CheckBox, ScrollView, Toast
from android.text import InputType
from android.util import TypedValue
from android.content import Context
from org.telegram.ui.ActionBar import Theme
from java.net import URL, HttpURLConnection
from java.io import File, FileOutputStream
from java.util import Scanner


def java_len(text: str) -> int:
    if not text:
        return 0
    return JavaString(text).length()


def make_runnable(func: Callable) -> Runnable:
    class R(dynamic_proxy(Runnable)):
        def run(self):
            try:
                func()
            except Exception:
                log(f"[extera_easy] {traceback.format_exc()}")
    return R()


def make_click_listener(func: Callable[[Any], None]):
    class L(dynamic_proxy(View.OnClickListener)):
        def onClick(self, view):
            try:
                func(view)
            except Exception:
                log(f"[extera_easy] {traceback.format_exc()}")
    return L()


class ChatUtils:
    @staticmethod
    def dialog_id_from_peer(peer) -> int:
        if not peer:
            return 0
        if isinstance(peer, TLRPC.TL_peerChannel):
            return -peer.channel_id
        if isinstance(peer, TLRPC.TL_peerChat):
            return -peer.chat_id
        if isinstance(peer, TLRPC.TL_peerUser):
            return peer.user_id
        return 0

    @staticmethod
    def get_entity(dialog_id: int):
        if not isinstance(dialog_id, int):
            try:
                dialog_id = int(dialog_id)
            except (ValueError, TypeError):
                return None
        c = get_messages_controller()
        if dialog_id > 0:
            return c.getUser(dialog_id)
        return c.getChat(abs(dialog_id))

    @staticmethod
    def get_entity_name(entity) -> str:
        if not entity:
            return "Unknown"
        if hasattr(entity, "title"):
            return entity.title
        if hasattr(entity, "first_name"):
            name = f"{entity.first_name or ''} {entity.last_name or ''}".strip()
            return name if name else f"ID: {entity.id}"
        return f"ID: {getattr(entity, 'id', 'N/A')}"

    @staticmethod
    def get_chat_name(dialog_id: int) -> str:
        return ChatUtils.get_entity_name(ChatUtils.get_entity(dialog_id))

    @staticmethod
    def get_input_peer(dialog_id: int):
        return get_messages_controller().getInputPeer(dialog_id)

    @staticmethod
    def resolve_username(username: str, callback: Callable):
        clean = username.replace("@", "").split("/")[-1].strip()
        if not clean:
            callback(None, None)
            return

        def on_resolve(response, error):
            if error or not response:
                callback(None, None)
                return
            entity = None
            if hasattr(response, "chats") and response.chats and not response.chats.isEmpty():
                entity = response.chats.get(0)
                get_messages_controller().putChats(response.chats, False)
            elif hasattr(response, "users") and response.users and not response.users.isEmpty():
                entity = response.users.get(0)
                get_messages_controller().putUsers(response.users, False)

            if entity:
                did = entity.id if isinstance(entity, TLRPC.TL_user) else -entity.id
                callback(did, ChatUtils.get_entity_name(entity))
            else:
                callback(None, None)

        try:
            req = TLRPC.TL_contacts_resolveUsername()
            req.username = clean
            send_request(req, RequestCallback(on_resolve))
        except Exception:
            log(f"[extera_easy] resolve_username: {traceback.format_exc()}")
            callback(None, None)


class MessageBuilder:
    def __init__(self):
        self._text = ""
        self._entities = ArrayList()

    def _add_entity(self, offset: int, length: int, entity_class, **kwargs):
        entity = entity_class()
        entity.offset = offset
        entity.length = length
        for key, value in kwargs.items():
            if hasattr(entity, key):
                setattr(entity, key, value)
        self._entities.add(entity)
        return self

    def append(self, text: str, entity_class=None, **kwargs) -> "MessageBuilder":
        offset = java_len(self._text)
        self._text += text
        if entity_class:
            self._add_entity(offset, java_len(text), entity_class, **kwargs)
        return self

    def plain(self, text: str) -> "MessageBuilder":
        return self.append(text)

    def bold(self, text: str) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntityBold)

    def italic(self, text: str) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntityItalic)

    def code(self, text: str) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntityCode)

    def pre(self, text: str) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntityPre)

    def spoiler(self, text: str) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntitySpoiler)

    def strikethrough(self, text: str) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntityStrike)

    def underline(self, text: str) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntityUnderline)

    def link(self, text: str, url: str) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntityTextUrl, url=url)

    def mention_user(self, text: str, user_id: int) -> "MessageBuilder":
        return self.append(text, TLRPC.TL_messageEntityMentionName, user_id=user_id)

    def build(self) -> Tuple[str, Any]:
        return self._text, self._entities


class InputMediaBuilder:
    @staticmethod
    def from_message(message_object) -> Optional[Any]:
        media = getattr(message_object.messageOwner, "media", None)
        if not media:
            return None
        try:
            if isinstance(media, TLRPC.TL_messageMediaPhoto) and hasattr(media, "photo"):
                photo = media.photo
                inp = TLRPC.TL_inputMediaPhoto()
                inp.id = TLRPC.TL_inputPhoto()
                inp.id.id = photo.id
                inp.id.access_hash = photo.access_hash
                inp.id.file_reference = photo.file_reference or bytearray(0)
                return inp
            if isinstance(media, TLRPC.TL_messageMediaDocument) and hasattr(media, "document"):
                doc = media.document
                inp = TLRPC.TL_inputMediaDocument()
                inp.id = TLRPC.TL_inputDocument()
                inp.id.id = doc.id
                inp.id.access_hash = doc.access_hash
                inp.id.file_reference = doc.file_reference or bytearray(0)
                return inp
        except Exception:
            log(f"[extera_easy] InputMediaBuilder: {traceback.format_exc()}")
        return None


class SequentialWorker:
    def __init__(self, delay: float = 0.0):
        self.delay = delay
        self._queue = []
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = None
        self._running = False

    def start(self):
        if self._running:
            return
        self._running = True
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop)
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._stop.set()
        self._running = False
        if self._thread:
            self._thread.join(timeout=2)

    def _loop(self):
        while not self._stop.is_set():
            task = None
            with self._lock:
                if self._queue:
                    task = self._queue.pop(0)
            if task:
                try:
                    task()
                except Exception:
                    log(f"[extera_easy] SequentialWorker: {traceback.format_exc()}")
                if self.delay > 0:
                    time.sleep(self.delay)
            else:
                time.sleep(0.1)

    def submit(self, task: Callable):
        with self._lock:
            self._queue.append(task)


class NotificationListener(dynamic_proxy(NotificationCenter.NotificationCenterDelegate)):
    def __init__(self, callback: Callable, notification_id: int):
        super().__init__()
        self.callback = callback
        self.notification_id = notification_id

    def didReceivedNotification(self, id, account, args):
        if id == self.notification_id:
            try:
                self.callback(id, account, args)
            except Exception:
                log(f"[extera_easy] NotificationListener: {traceback.format_exc()}")


class UpdateChecker:
    def __init__(self, owner: str, repo: str, current_version: str, asset_suffix: str = ".py"):
        self.owner = owner
        self.repo = repo
        self.current_version = current_version
        self.asset_suffix = asset_suffix

    def check(self, callback: Callable, manual: bool = False):
        def do_check():
            try:
                api_url = URL(f"https://api.github.com/repos/{self.owner}/{self.repo}/releases/latest")
                conn = api_url.openConnection()
                conn.setRequestMethod("GET")
                conn.connect()

                if conn.getResponseCode() == HttpURLConnection.HTTP_OK:
                    stream = conn.getInputStream()
                    scanner = Scanner(stream, "UTF-8").useDelimiter("\\A")
                    response = scanner.next() if scanner.hasNext() else ""
                    scanner.close()

                    data = json.loads(response)
                    latest = data.get("tag_name", "0.0.0").lstrip("v")
                    current = self.current_version.split("-")[0]

                    latest_t = tuple(map(int, latest.split(".")))
                    current_t = tuple(map(int, current.split(".")))

                    if latest_t > current_t:
                        changelog = data.get("body", "No changelog.")
                        download_url = None
                        for asset in data.get("assets", []):
                            if asset.get("name", "").endswith(self.asset_suffix):
                                download_url = asset.get("browser_download_url")
                                break
                        callback(True, latest, changelog, download_url)
                    else:
                        callback(False, current, "", None)
                else:
                    callback(False, "", f"HTTP {conn.getResponseCode()}", None)
            except Exception:
                log(f"[extera_easy] UpdateChecker: {traceback.format_exc()}")
                callback(False, "", "Check failed", None)

        threading.Thread(target=do_check).start()

    def download_and_install(self, url: str, version: str, callback: Callable):
        def do_download():
            try:
                conn = URL(url).openConnection()
                conn.connect()
                if conn.getResponseCode() == HttpURLConnection.HTTP_OK:
                    from com.exteragram.messenger.plugins import PluginsController
                    controller = PluginsController.getInstance()
                    cache_dir = File(controller.pluginsDir, ".cache")
                    cache_dir.mkdirs()
                    temp = File(cache_dir, f"update_{version}.py")

                    inp = conn.getInputStream()
                    out = FileOutputStream(temp)
                    buf = bytearray(4096)
                    while True:
                        n = inp.read(buf)
                        if n == -1:
                            break
                        out.write(buf, 0, n)
                    out.close()
                    inp.close()

                    class InstallCb(dynamic_proxy(Utilities.Callback)):
                        def __init__(self, cb):
                            super().__init__()
                            self.cb = cb
                        def run(self, arg):
                            self.cb(arg)

                    controller.loadPluginFromFile(temp.getAbsolutePath(), InstallCb(callback))
                    if temp.exists():
                        temp.delete()
                else:
                    callback("Download failed")
            except Exception:
                callback(traceback.format_exc())

        threading.Thread(target=do_download).start()


class DialogBuilder:
    def __init__(self, title: str):
        self.title = title
        self.message = ""
        self._view = None
        self._inputs = []
        self._buttons = []
        self._activity = None

    def _get_activity(self):
        if self._activity is None:
            f = get_last_fragment()
            if f:
                self._activity = f.getParentActivity()
        return self._activity

    def set_message(self, message: str) -> "DialogBuilder":
        self.message = message
        return self

    def add_input(self, hint: str = "", default: str = "", multiline: bool = False, password: bool = False) -> "DialogBuilder":
        act = self._get_activity()
        if not act:
            return self
        if self._view is None:
            self._view = self._create_container(act)

        edit = AndroidEditText(act)
        edit.setHint(hint)
        edit.setText(default)
        itype = InputType.TYPE_CLASS_TEXT
        if multiline:
            itype |= InputType.TYPE_TEXT_FLAG_MULTI_LINE
        if password:
            itype |= InputType.TYPE_TEXT_VARIATION_PASSWORD
        edit.setInputType(itype)
        edit.setTextColor(Theme.getColor(Theme.key_dialogTextBlack))
        edit.setHintTextColor(Theme.getColor(Theme.key_dialogTextHint))
        self._view.addView(edit, self._wrap_params())
        self._inputs.append(edit)
        return self

    def add_checkbox(self, text: str, default: bool = False) -> "DialogBuilder":
        act = self._get_activity()
        if not act:
            return self
        if self._view is None:
            self._view = self._create_container(act)
        cb = CheckBox(act)
        cb.setText(text)
        cb.setChecked(default)
        cb.setTextColor(Theme.getColor(Theme.key_dialogTextBlack))
        self._view.addView(cb, self._wrap_params())
        self._inputs.append(cb)
        return self

    def add_button(self, text: str, callback: Callable = None, is_positive: bool = True) -> "DialogBuilder":
        self._buttons.append((text, callback, is_positive))
        return self

    def _create_container(self, activity):
        layout = LinearLayout(activity)
        layout.setOrientation(LinearLayout.VERTICAL)
        dp20 = AndroidUtilities.dp(20)
        layout.setPadding(dp20, AndroidUtilities.dp(10), dp20, AndroidUtilities.dp(10))
        return layout

    def _wrap_params(self):
        return LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
        )

    def show(self):
        act = self._get_activity()
        if not act:
            return

        builder = AlertDialogBuilder(act)
        builder.set_title(self.title)
        if self.message:
            builder.set_message(self.message)
        if self._view:
            scroller = ScrollView(act)
            scroller.addView(self._view)
            builder.set_view(scroller)

        for text, callback, is_pos in self._buttons:
            if is_pos:
                builder.set_positive_button(text, lambda b, w: callback() if callback else None)
            else:
                builder.set_negative_button(text, lambda b, w: callback() if callback else None)

        run_on_ui_thread(builder.show)

    def get_input_values(self) -> List[Any]:
        result = []
        for widget in self._inputs:
            if isinstance(widget, AndroidEditText):
                result.append(widget.getText().toString())
            elif isinstance(widget, CheckBox):
                result.append(widget.isChecked())
            else:
                result.append(None)
        return result