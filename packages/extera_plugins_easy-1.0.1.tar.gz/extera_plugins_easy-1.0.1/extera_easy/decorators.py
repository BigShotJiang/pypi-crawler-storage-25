import functools
from typing import Callable, Optional


def command(name: str, description: str = "", priority: int = 0):
    """
    Декоратор для команд в исходящих сообщениях.
    Пример: @command(".hello")
    
    Метод получает CommandContext:
        ctx.text      — полный текст сообщения
        ctx.args      — список аргументов после команды
        ctx.raw_args  — строка аргументов как есть
        ctx.params    — оригинальные params от SDK
        ctx.account   — номер аккаунта
        ctx.chat_id   — ID чата (из params.peer)
    
    Если метод вернёт:
        str        — текст заменит сообщение (MODIFY)
        HookResult — стандартный результат хука
        None/другое — ничего не делать
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, ctx):
            return func(self, ctx)
        wrapper._extera_command = {
            'name': name,
            'description': description,
            'priority': priority,
        }
        return wrapper
    return decorator


def on_send_message(priority: int = 0, filter=None):
    """
    Декоратор для перехвата исходящих сообщений.
    Метод получает (account, params) как в SDK.
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            return func(self, *args, **kwargs)
        wrapper._extera_hook = {
            'type': 'send_message',
            'priority': priority,
            'filter': filter,
        }
        return wrapper
    return decorator


def on_message(priority: int = 0, filter=None):
    """
    Декоратор для входящих сообщений (через NotificationCenter).
    Метод получает MessageContext:
        ctx.msg            — MessageObject
        ctx.message_owner  — msg.messageOwner
        ctx.account        — номер аккаунта
        ctx.chat_id        — ID чата
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            return func(self, *args, **kwargs)
        wrapper._extera_hook = {
            'type': 'message',
            'priority': priority,
            'filter': filter,
        }
        return wrapper
    return decorator