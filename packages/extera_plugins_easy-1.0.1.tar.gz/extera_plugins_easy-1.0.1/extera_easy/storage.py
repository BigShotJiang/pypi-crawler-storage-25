from dataclasses import dataclass, fields, asdict
from typing import Any, Dict, Optional, Type, TypeVar

T = TypeVar('T', bound='StoredModel')

@dataclass
class StoredModel:
    @classmethod
    def load(cls: Type[T], plugin, key: str, item_id: str) -> Optional[T]:
        all_data = plugin.get_json(key, {})
        if item_id not in all_data:
            return None
        data = all_data[item_id]
        field_names = {f.name for f in fields(cls)}
        filtered = {k: v for k, v in data.items() if k in field_names}
        try:
            return cls(**filtered)
        except Exception:
            return None

    @classmethod
    def load_all(cls: Type[T], plugin, key: str) -> Dict[str, T]:
        all_data = plugin.get_json(key, {})
        field_names = {f.name for f in fields(cls)}
        result = {}
        for k, v in all_data.items():
            filtered = {kk: vv for kk, vv in v.items() if kk in field_names}
            try:
                result[k] = cls(**filtered)
            except Exception:
                continue
        return result

    def save(self, plugin, key: str, item_id: str):
        all_data = plugin.get_json(key, {})
        all_data[item_id] = asdict(self)
        plugin.set_json(key, all_data)

    @classmethod
    def delete(cls, plugin, key: str, item_id: str):
        all_data = plugin.get_json(key, {})
        if item_id in all_data:
            del all_data[item_id]
            plugin.set_json(key, all_data)