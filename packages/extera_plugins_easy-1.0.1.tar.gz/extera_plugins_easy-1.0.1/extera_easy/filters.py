from typing import Any


class Filter:
    """Базовый класс фильтра с поддержкой &, |, ~."""
    
    def __call__(self, obj) -> bool:
        raise NotImplementedError
    
    def __and__(self, other):
        return _AndFilter(self, other)
    
    def __or__(self, other):
        return _OrFilter(self, other)
    
    def __invert__(self):
        return _NotFilter(self)


class _AndFilter(Filter):
    def __init__(self, a, b):
        self.a = a
        self.b = b
    def __call__(self, obj):
        return self.a(obj) and self.b(obj)


class _OrFilter(Filter):
    def __init__(self, a, b):
        self.a = a
        self.b = b
    def __call__(self, obj):
        return self.a(obj) or self.b(obj)


class _NotFilter(Filter):
    def __init__(self, f):
        self.f = f
    def __call__(self, obj):
        return not self.f(obj)


# --- Утилиты для извлечения данных из MessageObject / params ---

def _get_text(obj: Any) -> str:
    if hasattr(obj, 'message') and isinstance(obj.message, str):
        return obj.message
    if hasattr(obj, 'messageOwner') and hasattr(obj.messageOwner, 'message'):
        return obj.messageOwner.message or ''
    return ''

def _get_media(obj: Any) -> Any:
    if hasattr(obj, 'media'):
        return obj.media
    if hasattr(obj, 'messageOwner') and hasattr(obj.messageOwner, 'media'):
        return obj.messageOwner.media
    return None

def _is_photo(obj: Any) -> bool:
    if hasattr(obj, 'isPhoto'):
        return obj.isPhoto()
    media = _get_media(obj)
    if media and hasattr(media, 'photo') and not hasattr(media, 'document'):
        return True
    return False

def _is_video(obj: Any) -> bool:
    if hasattr(obj, 'isVideo'):
        return obj.isVideo()
    media = _get_media(obj)
    if media and hasattr(media, 'document'):
        doc = media.document
        if hasattr(doc, 'mime_type') and doc.mime_type and doc.mime_type.startswith('video/'):
            return True
    return False

def _is_document(obj: Any) -> bool:
    if hasattr(obj, 'isDocument'):
        return obj.isDocument()
    media = _get_media(obj)
    return bool(media and hasattr(media, 'document'))

def _is_sticker(obj: Any) -> bool:
    if hasattr(obj, 'isSticker'):
        return obj.isSticker()
    media = _get_media(obj)
    if media and hasattr(media, 'document'):
        doc = media.document
        if hasattr(doc, 'attributes'):
            for i in range(doc.attributes.size()):
                attr = doc.attributes.get(i)
                if hasattr(attr, 'stickerset'):
                    return True
    return False

def _is_voice(obj: Any) -> bool:
    if hasattr(obj, 'isVoice'):
        return obj.isVoice()
    media = _get_media(obj)
    if media and hasattr(media, 'document'):
        doc = media.document
        if hasattr(doc, 'mime_type') and doc.mime_type and 'audio/ogg' in doc.mime_type:
            return True
    return False

def _is_gif(obj: Any) -> bool:
    if hasattr(obj, 'isGif'):
        return obj.isGif()
    media = _get_media(obj)
    if media and hasattr(media, 'document'):
        doc = media.document
        if hasattr(doc, 'mime_type') and doc.mime_type and doc.mime_type == 'video/mp4':
            # Это приближённая проверка, точная требует атрибутов
            return True
    return False

def _is_outgoing(obj: Any) -> bool:
    if hasattr(obj, 'out'):
        return obj.out
    if hasattr(obj, 'messageOwner') and hasattr(obj.messageOwner, 'out'):
        return obj.messageOwner.out
    return False

def _is_bot(obj: Any) -> bool:
    from_id = None
    if hasattr(obj, 'from_id'):
        from_id = obj.from_id
    elif hasattr(obj, 'messageOwner') and hasattr(obj.messageOwner, 'from_id'):
        from_id = obj.messageOwner.from_id
    
    if from_id and hasattr(from_id, 'user_id'):
        from extera_easy.utils import ChatUtils
        entity = ChatUtils.get_entity(from_id.user_id)
        return entity and getattr(entity, 'bot', False)
    return False

def _is_private(obj: Any) -> bool:
    cid = 0
    if hasattr(obj, 'peer_id'):
        cid = obj.peer_id
    elif hasattr(obj, 'messageOwner') and hasattr(obj.messageOwner, 'peer_id'):
        cid = obj.messageOwner.peer_id
    if hasattr(cid, 'user_id'):
        return True
    return False

def _is_group(obj: Any) -> bool:
    cid = None
    if hasattr(obj, 'peer_id'):
        cid = obj.peer_id
    elif hasattr(obj, 'messageOwner') and hasattr(obj.messageOwner, 'peer_id'):
        cid = obj.messageOwner.peer_id
    if hasattr(cid, 'chat_id'):
        return True
    if hasattr(cid, 'channel_id'):
        # Проверим, не супергруппа ли это
        from extera_easy.utils import ChatUtils
        did = ChatUtils.dialog_id_from_peer(cid)
        ent = ChatUtils.get_entity(did)
        if ent and getattr(ent, 'megagroup', False):
            return True
    return False

def _is_channel(obj: Any) -> bool:
    cid = None
    if hasattr(obj, 'peer_id'):
        cid = obj.peer_id
    elif hasattr(obj, 'messageOwner') and hasattr(obj.messageOwner, 'peer_id'):
        cid = obj.messageOwner.peer_id
    if hasattr(cid, 'channel_id'):
        from extera_easy.utils import ChatUtils
        did = ChatUtils.dialog_id_from_peer(cid)
        ent = ChatUtils.get_entity(did)
        if ent and not getattr(ent, 'megagroup', False):
            return True
    return False


# --- Предустановленные фильтры ---

class _Text(Filter):
    def __call__(self, obj):
        return bool(_get_text(obj)) and not _is_photo(obj) and not _is_video(obj) and not _is_document(obj)

class _Photo(Filter):
    def __call__(self, obj):
        return _is_photo(obj)

class _Video(Filter):
    def __call__(self, obj):
        return _is_video(obj)

class _Document(Filter):
    def __call__(self, obj):
        return _is_document(obj)

class _Sticker(Filter):
    def __call__(self, obj):
        return _is_sticker(obj)

class _Voice(Filter):
    def __call__(self, obj):
        return _is_voice(obj)

class _Gif(Filter):
    def __call__(self, obj):
        return _is_gif(obj)

class _Bot(Filter):
    def __call__(self, obj):
        return _is_bot(obj)

class _Outgoing(Filter):
    def __call__(self, obj):
        return _is_outgoing(obj)

class _Incoming(Filter):
    def __call__(self, obj):
        return not _is_outgoing(obj)

class _Private(Filter):
    def __call__(self, obj):
        return _is_private(obj)

class _Group(Filter):
    def __call__(self, obj):
        return _is_group(obj)

class _Channel(Filter):
    def __call__(self, obj):
        return _is_channel(obj)

class _Any(Filter):
    def __call__(self, obj):
        return True


class _Filters:
    text = _Text()
    photo = _Photo()
    video = _Video()
    document = _Document()
    sticker = _Sticker()
    voice = _Voice()
    gif = _Gif()
    bot = _Bot()
    outgoing = _Outgoing()
    incoming = _Incoming()
    private = _Private()
    group = _Group()
    channel = _Channel()
    all = _Any()

filters = _Filters()