from dataclasses import dataclass, fields, field
from typing import Any, List

class SettingField:
    def __init__(self, title: str, default=None, subtext: str = "", icon: str = None,
                 choices: list = None, multiline: bool = False, min_val=None, max_val=None,
                 section: str = None):
        self.title = title
        self.default = default
        self.subtext = subtext
        self.icon = icon
        self.choices = choices
        self.multiline = multiline
        self.min_val = min_val
        self.max_val = max_val
        self.section = section

def SF(title: str, default=None, **kwargs):
    sf = SettingField(title, default, **kwargs)
    return field(default=default, metadata={'sf': sf})

@dataclass
class SettingsDataclass:
    @classmethod
    def load(cls, plugin):
        inst = cls()
        for f in fields(inst):
            sf = f.metadata.get('sf')
            if sf is None:
                continue
            key = f.name
            type_ = f.type
            raw = plugin.get_setting(key)
            if raw is None:
                setattr(inst, key, sf.default)
                continue
            try:
                if type_ == bool:
                    val = str(raw).lower() in ('true', '1', 'yes', 'on')
                elif type_ == int:
                    val = int(raw)
                elif type_ == float:
                    val = float(raw)
                else:
                    val = raw
                setattr(inst, key, val)
            except Exception:
                setattr(inst, key, sf.default)
        return inst

    def save(self, plugin):
        for f in fields(self):
            sf = f.metadata.get('sf')
            if sf is None:
                continue
            val = getattr(self, f.name)
            if isinstance(val, bool):
                val = 'true' if val else 'false'
            plugin.set_setting(f.name, str(val))

    def build_ui(self) -> List[Any]:
        from ui.settings import Header, Switch, Input, Selector, EditText, Divider
        result = []
        current_section = None

        for f in fields(self):
            sf = f.metadata.get('sf')
            if sf is None:
                continue

            section = sf.section
            if section and section != current_section:
                if result:
                    result.append(Divider())
                result.append(Header(text=section))
                current_section = section

            val = getattr(self, f.name)
            key = f.name

            if f.type == bool:
                result.append(Switch(
                    key=key, text=sf.title, default=val,
                    subtext=sf.subtext, icon=sf.icon
                ))
            elif sf.choices:
                default_idx = sf.choices.index(val) if val in sf.choices else 0
                result.append(Selector(
                    key=key, text=sf.title, items=sf.choices,
                    default=default_idx, subtext=sf.subtext, icon=sf.icon
                ))
            elif sf.multiline:
                result.append(EditText(
                    key=key, hint=sf.title, default=str(val),
                    multiline=True, max_length=4000
                ))
            else:
                result.append(Input(
                    key=key, text=sf.title, default=str(val),
                    subtext=sf.subtext, icon=sf.icon
                ))

        return result