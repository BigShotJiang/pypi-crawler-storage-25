"""Contract tests for the stable project, test-case, script, and bulk API surface."""

import sys
import types

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool


def _install_celery_stub() -> None:
    if "celery" in sys.modules:
        return

    celery_module = types.ModuleType("celery")

    class _Conf:
        def update(self, *args, **kwargs):
            return None

    class Celery:
        def __init__(self, *args, **kwargs):
            self.conf = _Conf()

        def task(self, *decorator_args, **decorator_kwargs):
            def decorator(func):
                def delay(*args, **kwargs):
                    return None

                func.delay = delay
                return func

            if decorator_args and callable(decorator_args[0]) and len(decorator_args) == 1 and not decorator_kwargs:
                return decorator(decorator_args[0])
            return decorator

    def shared_task(*decorator_args, **decorator_kwargs):
        def decorator(func):
            def delay(*args, **kwargs):
                return None

            func.delay = delay
            return func

        if decorator_args and callable(decorator_args[0]) and len(decorator_args) == 1 and not decorator_kwargs:
            return decorator(decorator_args[0])
        return decorator

    celery_module.Celery = Celery
    celery_module.shared_task = shared_task
    sys.modules["celery"] = celery_module


_install_celery_stub()

import app.models.api_key  # noqa: F401
import app.models.bulk_job  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.membership  # noqa: F401
import app.models.project  # noqa: F401
import app.models.script_run  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.user  # noqa: F401

from app.database import Base, get_db
from app.main import app as fastapi_app


TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


@pytest.fixture(autouse=True)
def setup_db():
    Base.metadata.create_all(bind=engine)
    fastapi_app.dependency_overrides[get_db] = override_get_db
    try:
        yield
    finally:
        fastapi_app.dependency_overrides.clear()
        Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def client():
    return TestClient(fastapi_app)


def _register_and_login(client: TestClient, email: str, password: str = "TestPassword123!") -> dict[str, str]:
    register_resp = client.post("/api/v1/auth/register", json={"email": email, "password": password})
    assert register_resp.status_code == 201

    login_resp = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert login_resp.status_code == 200
    return {"Authorization": f"Bearer {login_resp.json()['access_token']}"}


def _create_project(client: TestClient, headers: dict[str, str]) -> dict:
    resp = client.post(
        "/api/v1/projects/",
        headers=headers,
        json={
            "name": "Contract Project",
            "aut_base_url": "https://example.com",
            "default_framework": "playwright_python",
            "selector_preference": "role",
        },
    )
    assert resp.status_code == 201
    return resp.json()


def _create_test_case(client: TestClient, project_id: int, headers: dict[str, str]) -> dict:
    resp = client.post(
        f"/api/v1/projects/{project_id}/test-cases/",
        headers=headers,
        json={
            "title": "Contract TC",
            "format": "step_based",
            "content": "Step 1: open the app",
        },
    )
    assert resp.status_code == 201
    return resp.json()


def test_openapi_documents_stable_project_test_case_script_and_bulk_surface():
    openapi = fastapi_app.openapi()
    paths = openapi["paths"]

    expected_paths = [
        "/api/v1/projects/",
        "/api/v1/projects/{project_id}",
        "/api/v1/projects/{project_id}/test-cases/",
        "/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/",
        "/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/generate",
        "/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}",
        "/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/runs",
        "/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/refactor",
        "/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/{script_id}/version-history",
        "/api/v1/projects/{project_id}/scripts/bulk-generate",
        "/api/v1/projects/{project_id}/scripts/bulk-run",
        "/api/v1/projects/{project_id}/scripts/bulk-jobs/{job_id}",
    ]

    for path in expected_paths:
        assert path in paths

    assert paths["/api/v1/projects/"]["get"]["responses"]["200"]
    assert paths["/api/v1/projects/"]["post"]["responses"]["201"]
    assert paths["/api/v1/projects/{project_id}/test-cases/"]["post"]["responses"]["201"]
    assert paths["/api/v1/projects/{project_id}/test-cases/{tc_id}/scripts/generate"]["post"]["responses"]["202"]
    assert paths["/api/v1/projects/{project_id}/scripts/bulk-generate"]["post"]["responses"]["202"]
    assert paths["/api/v1/projects/{project_id}/scripts/bulk-run"]["post"]["responses"]["202"]


def test_stable_project_test_case_script_and_bulk_contract(client: TestClient, monkeypatch):
    headers = _register_and_login(client, "contract-owner@example.com")
    project = _create_project(client, headers)
    test_case = _create_test_case(client, project["id"], headers)

    monkeypatch.setattr("app.routers.scripts.process_script_generation_job.delay", lambda *args, **kwargs: None)
    monkeypatch.setattr("app.routers.bulk_jobs.process_bulk_generation_job.delay", lambda *args, **kwargs: None)
    monkeypatch.setattr("app.routers.bulk_jobs.process_bulk_execution_job.delay", lambda *args, **kwargs: None)

    project_list = client.get("/api/v1/projects/")
    assert project_list.status_code == 200
    assert project_list.json()[0]["id"] == project["id"]
    assert project_list.json()[0]["name"] == "Contract Project"

    tc_list = client.get(f"/api/v1/projects/{project['id']}/test-cases/", headers=headers)
    assert tc_list.status_code == 200
    assert tc_list.json()[0]["id"] == test_case["id"]
    assert tc_list.json()[0]["title"] == "Contract TC"

    script_generate = client.post(
        f"/api/v1/projects/{project['id']}/test-cases/{test_case['id']}/scripts/generate",
        headers=headers,
        json={"llm_provider": "openai", "framework": "playwright_python"},
    )
    assert script_generate.status_code == 202
    generated = script_generate.json()
    assert generated["project_id"] == project["id"]
    assert generated["test_case_id"] == test_case["id"]
    assert generated["status"] == "pending"

    script_list = client.get(
        f"/api/v1/projects/{project['id']}/test-cases/{test_case['id']}/scripts/",
        headers=headers,
    )
    assert script_list.status_code == 200
    assert len(script_list.json()) == 1
    assert script_list.json()[0]["id"] == generated["id"]
    assert script_list.json()[0]["status"] == "pending"

    script_detail = client.get(
        f"/api/v1/projects/{project['id']}/test-cases/{test_case['id']}/scripts/{generated['id']}",
        headers=headers,
    )
    assert script_detail.status_code == 200
    assert script_detail.json()["id"] == generated["id"]
    assert script_detail.json()["project_id"] == project["id"]

    bulk_generate = client.post(
        f"/api/v1/projects/{project['id']}/scripts/bulk-generate",
        headers=headers,
        json={"test_case_ids": [test_case["id"]], "framework": "playwright_python", "llm_provider": "openai"},
    )
    assert bulk_generate.status_code == 202
    bulk_generate_payload = bulk_generate.json()
    assert bulk_generate_payload["project_id"] == project["id"]
    assert bulk_generate_payload["kind"] == "generate"
    assert bulk_generate_payload["status"] == "pending"
    assert len(bulk_generate_payload["items"]) == 1
    assert bulk_generate_payload["items"][0]["test_case_id"] == test_case["id"]

    bulk_job = client.get(
        f"/api/v1/projects/{project['id']}/scripts/bulk-jobs/{bulk_generate_payload['id']}",
        headers=headers,
    )
    assert bulk_job.status_code == 200
    assert bulk_job.json()["id"] == bulk_generate_payload["id"]
    assert bulk_job.json()["kind"] == "generate"

    bulk_run = client.post(
        f"/api/v1/projects/{project['id']}/scripts/bulk-run",
        headers=headers,
        json={"test_case_ids": [test_case["id"]]},
    )
    assert bulk_run.status_code == 202
    bulk_run_payload = bulk_run.json()
    assert bulk_run_payload["project_id"] == project["id"]
    assert bulk_run_payload["kind"] == "run"
    assert bulk_run_payload["status"] == "pending"
    assert bulk_run_payload["items"][0]["test_case_id"] == test_case["id"]