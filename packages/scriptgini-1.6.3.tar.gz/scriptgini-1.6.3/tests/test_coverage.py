"""
Tests for:
- app/database.py      (get_db generator)
- app/llm/provider.py  (all 5 providers + unknown provider error)
- app/agents/script_gini_agent.py (all nodes, error paths, run_agent)
- app/routers/projects.py  (404 paths)
- app/routers/test_cases.py (all CRUD + 404 paths)
- app/routers/scripts.py   (generate, list, get, delete + 404 paths)
"""
import json
import subprocess
import tempfile
from pathlib import Path
import pytest
from unittest.mock import MagicMock, patch, PropertyMock
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

import app.models.project  # noqa: F401
import app.models.test_case  # noqa: F401
import app.models.generated_script  # noqa: F401
import app.models.script_run  # noqa: F401
import app.models.bulk_job  # noqa: F401

from alembic.config import Config as AlembicConfig
from alembic import command as alembic_command

from app.main import app as fastapi_app
from app.database import Base, get_db

# ── Shared in-memory engine ──────────────────────────────────────────────────
TEST_DATABASE_URL = "sqlite:///:memory:"
engine = create_engine(
    TEST_DATABASE_URL,
    connect_args={"check_same_thread": False},
    poolclass=StaticPool,
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
# expire_on_commit=False keeps attributes accessible after session.close()
# (needed when passing ORM objects to background tasks)
TestingSessionLocalNoExpire = sessionmaker(autocommit=False, autoflush=False, bind=engine, expire_on_commit=False)


def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


def _run_alembic_upgrade():
    """Run alembic upgrade head against the shared in-memory engine."""
    cfg = AlembicConfig("alembic.ini")
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        alembic_command.upgrade(cfg, "head")
def _run_alembic_downgrade():
    """Run alembic downgrade base to fully reset the in-memory engine."""
    cfg = AlembicConfig("alembic.ini")
    with engine.begin() as conn:
        cfg.attributes["connection"] = conn
        alembic_command.downgrade(cfg, "base")




@pytest.fixture(autouse=True)
def setup_db():
    _run_alembic_upgrade()
    yield
    _run_alembic_downgrade()
    engine.dispose()


@pytest.fixture()
def client():
    fastapi_app.dependency_overrides[get_db] = override_get_db
    with TestClient(fastapi_app) as c:
        yield c
    fastapi_app.dependency_overrides.clear()


# ── Helpers ──────────────────────────────────────────────────────────────────

def _make_project(client, **kwargs):
    payload = {"name": "Test Project", "aut_base_url": "https://example.com", **kwargs}
    return client.post("/api/v1/projects/", json=payload).json()


def _make_tc(client, project_id, **kwargs):
    payload = {"title": "TC-001", "format": "step_based", "content": "Step 1: ...", **kwargs}
    return client.post(f"/api/v1/projects/{project_id}/test-cases/", json=payload).json()


# ════════════════════════════════════════════════════════════════════════════
# database.py — get_db
# ════════════════════════════════════════════════════════════════════════════

def test_get_db_yields_and_closes():
    from app.database import get_db as real_get_db
    gen = real_get_db()
    db = next(gen)
    assert db is not None
    try:
        next(gen)
    except StopIteration:
        pass


# ════════════════════════════════════════════════════════════════════════════
# llm/provider.py
# ════════════════════════════════════════════════════════════════════════════

class TestGetLlm:
    def test_openai_provider(self):
        mock_llm = MagicMock()
        with patch("app.llm.provider._openai", return_value=mock_llm) as m:
            from app.llm.provider import get_llm
            result = get_llm("openai", model="gpt-4o")
            m.assert_called_once_with("gpt-4o", 0.1)
            assert result is mock_llm

    def test_ollama_provider(self):
        mock_llm = MagicMock()
        with patch("app.llm.provider._ollama", return_value=mock_llm) as m:
            from app.llm.provider import get_llm
            result = get_llm("ollama", model="llama3")
            m.assert_called_once_with("llama3", 0.1)
            assert result is mock_llm

    def test_openrouter_provider(self):
        mock_llm = MagicMock()
        with patch("app.llm.provider._openrouter", return_value=mock_llm) as m:
            from app.llm.provider import get_llm
            result = get_llm("openrouter", model="openai/gpt-4o")
            m.assert_called_once_with("openai/gpt-4o", 0.1)
            assert result is mock_llm

    def test_gemini_provider(self):
        mock_llm = MagicMock()
        with patch("app.llm.provider._gemini", return_value=mock_llm) as m:
            from app.llm.provider import get_llm
            result = get_llm("gemini", model="gemini-1.5-pro")
            m.assert_called_once_with("gemini-1.5-pro", 0.1)
            assert result is mock_llm

    def test_bedrock_provider(self):
        mock_llm = MagicMock()
        with patch("app.llm.provider._bedrock", return_value=mock_llm) as m:
            from app.llm.provider import get_llm
            result = get_llm("bedrock", model="anthropic.claude-3-5-sonnet-20241022-v2:0")
            m.assert_called_once()
            assert result is mock_llm

    def test_unknown_provider_raises(self):
        from app.llm.provider import get_llm
        with pytest.raises(ValueError, match="Unknown LLM provider"):
            get_llm("unknown_xyz")  # type: ignore

    def test_defaults_to_settings_provider(self):
        mock_llm = MagicMock()
        with patch("app.llm.provider._openrouter", return_value=mock_llm):
            with patch("app.llm.provider.settings") as mock_settings:
                mock_settings.DEFAULT_LLM_PROVIDER = "openrouter"
                mock_settings.OPENROUTER_MODEL = "openai/gpt-4o"
                from app.llm.provider import get_llm
                result = get_llm()
                assert result is mock_llm

    def test_openai_factory_instantiates(self):
        mock_cls = MagicMock()
        with patch.dict("sys.modules", {"langchain_openai": MagicMock(ChatOpenAI=mock_cls)}):
            from app.llm import provider as p
            import importlib
            importlib.reload(p)
            p._openai("gpt-4o", 0.1)

    def test_ollama_factory_instantiates(self):
        mock_cls = MagicMock()
        with patch.dict("sys.modules", {"langchain_ollama": MagicMock(ChatOllama=mock_cls)}):
            from app.llm import provider as p
            import importlib
            importlib.reload(p)
            p._ollama("llama3", 0.1)

    def test_openrouter_factory_instantiates(self):
        mock_cls = MagicMock()
        with patch.dict("sys.modules", {"langchain_openai": MagicMock(ChatOpenAI=mock_cls)}):
            from app.llm import provider as p
            import importlib
            importlib.reload(p)
            p._openrouter("openai/gpt-4o", 0.1)

    def test_gemini_factory_instantiates(self):
        mock_cls = MagicMock()
        with patch.dict("sys.modules", {
            "langchain_google_genai": MagicMock(ChatGoogleGenerativeAI=mock_cls)
        }):
            from app.llm import provider as p
            import importlib
            importlib.reload(p)
            p._gemini("gemini-1.5-pro", 0.1)

    def test_bedrock_factory_instantiates(self):
        mock_boto3 = MagicMock()
        mock_bedrock_cls = MagicMock()
        with patch.dict("sys.modules", {
            "boto3": mock_boto3,
            "langchain_aws": MagicMock(ChatBedrock=mock_bedrock_cls),
        }):
            from app.llm import provider as p
            import importlib
            importlib.reload(p)
            p._bedrock("anthropic.claude-3-5-sonnet-20241022-v2:0", 0.1)


# ════════════════════════════════════════════════════════════════════════════
# agents/script_gini_agent.py
# ════════════════════════════════════════════════════════════════════════════

def _make_base_state(**overrides):
    state = {
        "test_case_title": "TC-001",
        "test_case_content": "Step 1: go to /login",
        "preconditions": "user exists",
        "test_data_hints": "admin/admin",
        "aut_base_url": "https://example.com",
        "framework": "playwright_python",
        "auth_hints": "",
        "llm_provider": "openai",
        "llm_model": None,
        "business_intent": "",
        "actions": "",
        "assertions": "",
        "parsed_preconditions": "",
        "script": "",
        "error": None,
        "token_usage": 0,
    }
    state.update(overrides)
    return state


def _mock_llm_response(content: str, tokens: int = 10):
    mock_resp = MagicMock()
    mock_resp.content = content
    mock_resp.usage_metadata = {"total_tokens": tokens}
    mock_llm = MagicMock()
    mock_llm.invoke.return_value = mock_resp
    return mock_llm


class TestAgentNodes:
    def test_node_parse_intent_valid_json(self):
        from app.agents.script_gini_agent import node_parse_intent
        payload = {
            "business_intent": "test login",
            "preconditions": "user exists",
            "actions": ["navigate", "click"],
            "assertions": ["check dashboard"],
        }
        mock_llm = _mock_llm_response(json.dumps(payload), tokens=20)
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            result = node_parse_intent(_make_base_state())
        assert result["business_intent"] == "test login"
        assert result["token_usage"] == 20
        assert result["error"] is None

    def test_node_parse_intent_json_in_markdown_fence(self):
        from app.agents.script_gini_agent import node_parse_intent
        payload = {"business_intent": "login", "preconditions": "", "actions": [], "assertions": []}
        raw = f"```json\n{json.dumps(payload)}\n```"
        mock_llm = _mock_llm_response(raw)
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            result = node_parse_intent(_make_base_state())
        assert result["business_intent"] == "login"

    def test_node_parse_intent_plain_text_fallback(self):
        from app.agents.script_gini_agent import node_parse_intent
        mock_llm = _mock_llm_response("not valid json at all ~~~")
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            result = node_parse_intent(_make_base_state())
        assert result["business_intent"] == "not valid json at all ~~~"

    def test_node_parse_intent_non_list_actions(self):
        from app.agents.script_gini_agent import node_parse_intent
        payload = {"business_intent": "x", "preconditions": "", "actions": "click login", "assertions": "see dashboard"}
        mock_llm = _mock_llm_response(json.dumps(payload))
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            result = node_parse_intent(_make_base_state())
        assert result["actions"] == "click login"

    def test_node_parse_intent_llm_error(self):
        from app.agents.script_gini_agent import node_parse_intent
        with patch("app.agents.script_gini_agent.get_llm", side_effect=RuntimeError("LLM down")):
            result = node_parse_intent(_make_base_state())
        assert "LLM down" in result["error"]

    def test_node_generate_script_skips_on_error(self):
        from app.agents.script_gini_agent import node_generate_script
        result = node_generate_script(_make_base_state(error="previous error"))
        assert result == {}

    def test_node_generate_script_success(self):
        from app.agents.script_gini_agent import node_generate_script
        mock_llm = _mock_llm_response("# test script code", tokens=50)
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            result = node_generate_script(_make_base_state(business_intent="login test"))
        assert result["script"] == "# test script code"
        assert result["token_usage"] == 50

    def test_node_generate_script_non_playwright_uses_generic_prompt(self):
        from app.agents.script_gini_agent import node_generate_script
        mock_llm = _mock_llm_response("# selenium script", tokens=40)
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            result = node_generate_script(_make_base_state(framework="selenium_python", business_intent="login"))
        assert result["script"] == "# selenium script"
        assert result["token_usage"] == 40

    def test_node_generate_script_llm_error(self):
        from app.agents.script_gini_agent import node_generate_script
        with patch("app.agents.script_gini_agent.get_llm", side_effect=RuntimeError("timeout")):
            result = node_generate_script(_make_base_state())
        assert "timeout" in result["error"]

    def test_node_review_script_skips_when_no_script(self):
        from app.agents.script_gini_agent import node_review_script
        result = node_review_script(_make_base_state(script=""))
        assert result == {}

    def test_node_review_script_skips_on_error(self):
        from app.agents.script_gini_agent import node_review_script
        result = node_review_script(_make_base_state(script="code", error="boom"))
        assert result == {}

    def test_node_review_script_success(self):
        from app.agents.script_gini_agent import node_review_script
        mock_llm = _mock_llm_response("# reviewed script", tokens=30)
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            result = node_review_script(_make_base_state(script="# draft"))
        assert result["script"] == "# reviewed script"

    def test_node_review_script_llm_error(self):
        from app.agents.script_gini_agent import node_review_script
        with patch("app.agents.script_gini_agent.get_llm", side_effect=RuntimeError("oops")):
            result = node_review_script(_make_base_state(script="# draft"))
        assert "oops" in result["error"]

    def test_llm_invoke_no_usage_metadata(self):
        from app.agents.script_gini_agent import _llm_invoke
        mock_resp = MagicMock()
        mock_resp.content = "hello"
        del mock_resp.usage_metadata  # attribute absent
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = mock_resp
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            content, tokens = _llm_invoke(_make_base_state(), "sys", "human")
        assert content == "hello"
        assert tokens == 0

    def test_llm_invoke_usage_metadata_none(self):
        from app.agents.script_gini_agent import _llm_invoke
        mock_resp = MagicMock()
        mock_resp.content = "hi"
        mock_resp.usage_metadata = None
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = mock_resp
        with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
            content, tokens = _llm_invoke(_make_base_state(), "sys", "human")
        assert tokens == 0


class TestRunAgent:
    def test_run_agent_success(self):
        from app.agents.script_gini_agent import run_agent
        mock_graph = MagicMock()
        mock_graph.invoke.return_value = {
            "script": "# final script",
            "error": None,
            "token_usage": 100,
        }
        with patch("app.agents.script_gini_agent.get_agent", return_value=mock_graph):
            result = run_agent(
                test_case_title="Login",
                test_case_content="Step 1: navigate",
                aut_base_url="https://example.com",
            )
        assert result["script"] == "# final script"
        assert result["error"] is None
        assert result["token_usage"] == 100

    def test_run_agent_with_all_params(self):
        from app.agents.script_gini_agent import run_agent
        mock_graph = MagicMock()
        mock_graph.invoke.return_value = {"script": "", "error": "fail", "token_usage": 5}
        with patch("app.agents.script_gini_agent.get_agent", return_value=mock_graph):
            result = run_agent(
                test_case_title="T",
                test_case_content="content",
                preconditions="pre",
                test_data_hints="hint",
                aut_base_url="https://x.com",
                framework="selenium_python",
                auth_hints="admin/admin",
                llm_provider="ollama",
                llm_model="llama3",
            )
        assert result["error"] == "fail"

    def test_get_agent_singleton(self):
        from app.agents import script_gini_agent as ag
        ag._app = None  # reset singleton
        a1 = ag.get_agent()
        a2 = ag.get_agent()
        assert a1 is a2


# ════════════════════════════════════════════════════════════════════════════
# routers/projects.py — missing 404 branches
# ════════════════════════════════════════════════════════════════════════════

class TestProjectRouter404:
    def test_get_project_success(self, client):
        p = _make_project(client)
        resp = client.get(f"/api/v1/projects/{p['id']}")
        assert resp.status_code == 200
        assert resp.json()["id"] == p["id"]

    def test_update_project_not_found(self, client):
        resp = client.patch("/api/v1/projects/999", json={"name": "X"})
        assert resp.status_code == 404

    def test_delete_project_not_found(self, client):
        resp = client.delete("/api/v1/projects/999")
        assert resp.status_code == 404


# ════════════════════════════════════════════════════════════════════════════
# routers/test_cases.py
# ════════════════════════════════════════════════════════════════════════════

class TestTestCaseRouter:
    def test_list_tc_project_not_found(self, client):
        resp = client.get("/api/v1/projects/999/test-cases/")
        assert resp.status_code == 404

    def test_create_tc_project_not_found(self, client):
        resp = client.post("/api/v1/projects/999/test-cases/", json={
            "title": "X", "format": "step_based", "content": "..."
        })
        assert resp.status_code == 404

    def test_get_tc_success(self, client):
        p = _make_project(client)
        tc = _make_tc(client, p["id"])
        resp = client.get(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}")
        assert resp.status_code == 200
        assert resp.json()["title"] == "TC-001"

    def test_get_tc_not_found(self, client):
        p = _make_project(client)
        resp = client.get(f"/api/v1/projects/{p['id']}/test-cases/999")
        assert resp.status_code == 404

    def test_update_tc_success(self, client):
        p = _make_project(client)
        tc = _make_tc(client, p["id"])
        resp = client.patch(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}", json={"title": "Updated"})
        assert resp.status_code == 200
        assert resp.json()["title"] == "Updated"

    def test_update_tc_not_found(self, client):
        p = _make_project(client)
        resp = client.patch(f"/api/v1/projects/{p['id']}/test-cases/999", json={"title": "X"})
        assert resp.status_code == 404

    def test_delete_tc_success(self, client):
        p = _make_project(client)
        tc = _make_tc(client, p["id"])
        resp = client.delete(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}")
        assert resp.status_code == 204

    def test_delete_tc_not_found(self, client):
        p = _make_project(client)
        resp = client.delete(f"/api/v1/projects/{p['id']}/test-cases/999")
        assert resp.status_code == 404


# ════════════════════════════════════════════════════════════════════════════
# routers/scripts.py
# ════════════════════════════════════════════════════════════════════════════

class TestScriptsRouter:
    def _setup(self, client):
        p = _make_project(client)
        tc = _make_tc(client, p["id"])
        return p, tc

    def test_generate_script_202(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )
        assert resp.status_code == 202
        assert resp.json()["status"] == "pending"

    def test_generate_script_enqueue_failure(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        mock_task.delay.side_effect = RuntimeError("queue down")
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )
        assert resp.status_code == 503

    def test_generate_script_project_not_found(self, client):
        resp = client.post(
            "/api/v1/projects/999/test-cases/1/scripts/generate",
            json={"llm_provider": "openai"},
        )
        assert resp.status_code == 404

    def test_generate_script_tc_not_found(self, client):
        p = _make_project(client)
        resp = client.post(
            f"/api/v1/projects/{p['id']}/test-cases/999/scripts/generate",
            json={"llm_provider": "openai"},
        )
        assert resp.status_code == 404

    def test_list_scripts(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )
        resp = client.get(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/")
        assert resp.status_code == 200
        assert len(resp.json()) == 1

    def test_list_scripts_project_not_found(self, client):
        resp = client.get("/api/v1/projects/999/test-cases/1/scripts/")
        assert resp.status_code == 404

    def test_list_scripts_tc_not_found(self, client):
        p = _make_project(client)
        resp = client.get(f"/api/v1/projects/{p['id']}/test-cases/999/scripts/")
        assert resp.status_code == 404

    def test_get_script_success(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )
        sid = gen_resp.json()["id"]
        resp = client.get(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}")
        assert resp.status_code == 200

    def test_get_script_not_found(self, client):
        p, tc = self._setup(client)
        resp = client.get(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/999")
        assert resp.status_code == 404

    def test_delete_script_success(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )
        sid = gen_resp.json()["id"]
        resp = client.delete(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}")
        assert resp.status_code == 204

    def test_delete_script_not_found(self, client):
        p, tc = self._setup(client)
        resp = client.delete(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/999")
        assert resp.status_code == 404

    def test_run_script_success(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )

        sid = gen_resp.json()["id"]

        db = TestingSessionLocal()
        from app.models.generated_script import GeneratedScript, ScriptStatus

        script = db.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        script.status = ScriptStatus.completed
        script.script_content = "print('ok')"
        db.commit()
        db.close()

        mock_result = {
            "success": True,
            "exit_code": 0,
            "stdout": "ok\n",
            "stderr": "",
            "duration_seconds": 0.21,
            "command": "python generated_scenario.py",
        }

        with patch("app.routers.scripts._run_python_script", return_value=mock_result):
            resp = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/run")

        assert resp.status_code == 200
        assert resp.json()["success"] is True
        assert resp.json()["stdout"] == "ok\n"
        assert resp.json()["status"] == "completed"

        runs_resp = client.get(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/runs")
        assert runs_resp.status_code == 200
        assert len(runs_resp.json()) == 1
        assert runs_resp.json()[0]["exit_code"] == 0

    def test_run_script_not_ready(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )

        sid = gen_resp.json()["id"]
        resp = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/run")
        assert resp.status_code == 400
        assert resp.json()["error"]["message"] == "Script is not ready to run"

    def test_run_script_timeout_persists_history(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )

        sid = gen_resp.json()["id"]

        db = TestingSessionLocal()
        from app.models.generated_script import GeneratedScript, ScriptStatus

        script = db.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        script.status = ScriptStatus.completed
        script.script_content = "print('slow')"
        db.commit()
        db.close()

        timeout_exc = subprocess.TimeoutExpired(cmd="python generated_scenario.py", timeout=300)
        with patch("app.routers.scripts._run_python_script", side_effect=timeout_exc):
            resp = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/run")

        assert resp.status_code == 200
        assert resp.json()["status"] == "timed_out"
        assert resp.json()["success"] is False

        runs_resp = client.get(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/runs")
        assert runs_resp.status_code == 200
        assert runs_resp.json()[0]["status"] == "timed_out"

    def test_run_script_unsafe_script_persists_failed_history(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )

        sid = gen_resp.json()["id"]

        db = TestingSessionLocal()
        from app.models.generated_script import GeneratedScript, ScriptStatus

        script = db.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        script.status = ScriptStatus.completed
        script.script_content = "import subprocess\nprint('x')"
        db.commit()
        db.close()

        with patch("app.routers.scripts._run_python_script", side_effect=ValueError("Unsafe import detected: subprocess")):
            resp = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/run")

        assert resp.status_code == 200
        assert resp.json()["status"] == "failed"
        assert "Unsafe import detected" in resp.json()["stderr"]

    def test_run_generation_success(self, client):
        """Directly test the background task function with a mocked agent."""
        from app.routers.scripts import _run_generation
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.schemas.generated_script import GenerateScriptRequest

        db = TestingSessionLocalNoExpire()
        project = Project(name="P", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)

        tc = TestCase(project_id=project.id, title="T", format="step_based", content="...")
        db.add(tc)
        db.commit()
        db.refresh(tc)

        script = GeneratedScript(
            project_id=project.id, test_case_id=tc.id,
            framework="playwright_python", llm_provider="openai",
            llm_model="gpt-4o", status=ScriptStatus.pending,
        )
        db.add(script)
        db.commit()
        db.refresh(script)
        script_id = script.id
        db.close()

        request = GenerateScriptRequest(llm_provider="openai")
        mock_result = {"script": "# done", "error": None, "token_usage": 42}

        # SessionLocal is imported inside _run_generation, so patch at the source
        with patch("app.routers.scripts.run_agent", return_value=mock_result):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_generation(script_id, project, tc, request)

        verify_db = TestingSessionLocal()
        updated = verify_db.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
        assert updated.status == ScriptStatus.completed
        assert updated.script_content == "# done"
        verify_db.close()

    def test_run_generation_agent_failure(self, client):
        """Test background task when agent raises an exception."""
        from app.routers.scripts import _run_generation
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.schemas.generated_script import GenerateScriptRequest

        db = TestingSessionLocalNoExpire()
        project = Project(name="P2", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)

        tc = TestCase(project_id=project.id, title="T2", format="step_based", content="...")
        db.add(tc)
        db.commit()
        db.refresh(tc)

        script = GeneratedScript(
            project_id=project.id, test_case_id=tc.id,
            framework="playwright_python", llm_provider="openai",
            llm_model="gpt-4o", status=ScriptStatus.pending,
        )
        db.add(script)
        db.commit()
        db.refresh(script)
        script_id = script.id
        db.close()

        request = GenerateScriptRequest(llm_provider="openai")

        with patch("app.routers.scripts.run_agent", side_effect=RuntimeError("agent crashed")):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_generation(script_id, project, tc, request)

        verify_db = TestingSessionLocal()
        updated = verify_db.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
        assert updated.status == ScriptStatus.failed
        assert "agent crashed" in updated.error_message
        verify_db.close()

    def test_run_generation_script_not_found(self):
        """Test background task when script record is missing (no-op)."""
        from app.routers.scripts import _run_generation
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.schemas.generated_script import GenerateScriptRequest

        project = Project(name="P3", aut_base_url="https://x.com")
        tc = TestCase(project_id=1, title="T3", format="step_based", content="...")
        request = GenerateScriptRequest(llm_provider="openai")

        with patch("app.database.SessionLocal", TestingSessionLocal):
            # script_id=99999 doesn't exist — should return without error
            _run_generation(99999, project, tc, request)

    def test_generate_script_with_framework_override(self, client):
        p, tc = self._setup(client)
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "ollama", "framework": "selenium_python"},
            )
        assert resp.status_code == 202
        assert resp.json()["framework"] == "selenium_python"


class TestRunAnalyticsRouter:
    def test_get_run_analytics_project_not_found(self, client):
        resp = client.get("/api/v1/projects/999999/analytics/runs")
        assert resp.status_code == 404

    def test_get_run_analytics_empty(self, client):
        p = _make_project(client)
        resp = client.get(f"/api/v1/projects/{p['id']}/analytics/runs")
        assert resp.status_code == 200
        payload = resp.json()
        assert payload["project_id"] == p["id"]
        assert payload["total_runs"] == 0
        assert payload["success_runs"] == 0
        assert payload["failed_runs"] == 0
        assert payload["timed_out_runs"] == 0
        assert payload["success_rate"] == 0.0
        assert payload["average_duration_seconds"] == 0.0
        assert payload["recent_failures"] == []

    def test_get_run_analytics_with_data(self, client):
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.models.script_run import ScriptRun, ScriptRunStatus

        p = _make_project(client)
        tc = _make_tc(client, p["id"])

        db = TestingSessionLocal()
        script = GeneratedScript(
            project_id=p["id"],
            test_case_id=tc["id"],
            framework="playwright_python",
            llm_provider="openai",
            llm_model="gpt-4o",
            status=ScriptStatus.completed,
            script_content="print('x')",
        )
        db.add(script)
        db.commit()
        db.refresh(script)

        db.add_all([
            ScriptRun(
                script_id=script.id,
                project_id=p["id"],
                test_case_id=tc["id"],
                status=ScriptRunStatus.completed,
                success=True,
                exit_code=0,
                stdout="ok",
                stderr="",
                duration_seconds=1.2,
                command="python x.py",
            ),
            ScriptRun(
                script_id=script.id,
                project_id=p["id"],
                test_case_id=tc["id"],
                status=ScriptRunStatus.failed,
                success=False,
                exit_code=1,
                stdout="",
                stderr="boom" * 90,
                duration_seconds=2.4,
                command="python x.py",
            ),
            ScriptRun(
                script_id=script.id,
                project_id=p["id"],
                test_case_id=tc["id"],
                status=ScriptRunStatus.timed_out,
                success=False,
                exit_code=124,
                stdout="",
                stderr="timeout",
                duration_seconds=300.0,
                command="python x.py",
            ),
        ])
        db.commit()
        db.close()

        resp = client.get(f"/api/v1/projects/{p['id']}/analytics/runs")
        assert resp.status_code == 200
        payload = resp.json()
        assert payload["total_runs"] == 3
        assert payload["success_runs"] == 1
        assert payload["failed_runs"] == 1
        assert payload["timed_out_runs"] == 1
        assert payload["success_rate"] == pytest.approx(33.33, abs=0.01)
        assert payload["average_duration_seconds"] == pytest.approx(101.2, abs=0.01)
        assert len(payload["recent_failures"]) == 2
        assert payload["recent_failures"][0]["stderr_excerpt"]


class TestBulkJobsRouter:
    def _setup_project_with_cases(self, client):
        p = _make_project(client)
        tc1 = _make_tc(client, p["id"], title="TC-1")
        tc2 = _make_tc(client, p["id"], title="TC-2")
        return p, tc1, tc2

    def test_bulk_generate_accepted(self, client):
        p, _, _ = self._setup_project_with_cases(client)
        mock_task = MagicMock()
        with patch("app.routers.bulk_jobs.process_bulk_generation_job", mock_task):
            resp = client.post(
                f"/api/v1/projects/{p['id']}/scripts/bulk-generate",
                json={"llm_provider": "openai"},
            )
        assert resp.status_code == 202
        assert resp.json()["kind"] == "generate"
        assert resp.json()["total_items"] == 2

    def test_bulk_generate_enqueue_failure(self, client):
        p, _, _ = self._setup_project_with_cases(client)
        mock_task = MagicMock()
        mock_task.delay.side_effect = RuntimeError("queue down")
        with patch("app.routers.bulk_jobs.process_bulk_generation_job", mock_task):
            resp = client.post(
                f"/api/v1/projects/{p['id']}/scripts/bulk-generate",
                json={"llm_provider": "openai"},
            )
        assert resp.status_code == 503

    def test_bulk_generate_no_cases(self, client):
        p = _make_project(client)
        resp = client.post(
            f"/api/v1/projects/{p['id']}/scripts/bulk-generate",
            json={"llm_provider": "openai", "test_case_ids": [999]},
        )
        assert resp.status_code == 400

    def test_bulk_run_accepted(self, client):
        p, _, _ = self._setup_project_with_cases(client)
        mock_task = MagicMock()
        with patch("app.routers.bulk_jobs.process_bulk_execution_job", mock_task):
            resp = client.post(
                f"/api/v1/projects/{p['id']}/scripts/bulk-run",
                json={},
            )
        assert resp.status_code == 202
        assert resp.json()["kind"] == "run"

    def test_bulk_run_enqueue_failure(self, client):
        p, _, _ = self._setup_project_with_cases(client)
        mock_task = MagicMock()
        mock_task.delay.side_effect = RuntimeError("queue down")
        with patch("app.routers.bulk_jobs.process_bulk_execution_job", mock_task):
            resp = client.post(
                f"/api/v1/projects/{p['id']}/scripts/bulk-run",
                json={},
            )
        assert resp.status_code == 503

    def test_bulk_run_no_cases(self, client):
        p = _make_project(client)
        resp = client.post(
            f"/api/v1/projects/{p['id']}/scripts/bulk-run",
            json={"test_case_ids": [999]},
        )
        assert resp.status_code == 400

    def test_bulk_job_get_not_found(self, client):
        p = _make_project(client)
        resp = client.get(f"/api/v1/projects/{p['id']}/scripts/bulk-jobs/999")
        assert resp.status_code == 404

    def test_bulk_job_get_success(self, client):
        p, _, _ = self._setup_project_with_cases(client)
        mock_task = MagicMock()
        with patch("app.routers.bulk_jobs.process_bulk_generation_job", mock_task):
            create = client.post(
                f"/api/v1/projects/{p['id']}/scripts/bulk-generate",
                json={"llm_provider": "openai"},
            )
        job_id = create.json()["id"]
        resp = client.get(f"/api/v1/projects/{p['id']}/scripts/bulk-jobs/{job_id}")
        assert resp.status_code == 200
        assert len(resp.json()["items"]) == 2

    def test_run_bulk_generation_success(self):
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.bulk_job import BulkJob, BulkJobItem, BulkJobKind, BulkJobStatus
        from app.schemas.bulk_job import BulkGenerateRequest
        from app.routers.bulk_jobs import _run_bulk_generation

        db = TestingSessionLocal()
        project = Project(name="Bulk P", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)

        tc = TestCase(project_id=project.id, title="TC", format="step_based", content="x")
        db.add(tc)
        db.commit()
        db.refresh(tc)

        job = BulkJob(project_id=project.id, kind=BulkJobKind.generate, status=BulkJobStatus.pending)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id
        db.add(BulkJobItem(job_id=job.id, test_case_id=tc.id))
        db.commit()
        db.close()

        req = BulkGenerateRequest(llm_provider="openai")
        with patch("app.routers.bulk_jobs.run_agent", return_value={"script": "print('ok')", "error": None, "token_usage": 1}):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_bulk_generation(job_id, req)

        verify = TestingSessionLocal()
        from app.models.generated_script import GeneratedScript
        refreshed_job = verify.query(BulkJob).filter(BulkJob.id == job_id).first()
        assert refreshed_job.status in (BulkJobStatus.completed, BulkJobStatus.failed)
        assert verify.query(GeneratedScript).count() == 1
        verify.close()

    def test_run_bulk_generation_no_job(self):
        from app.schemas.bulk_job import BulkGenerateRequest
        from app.routers.bulk_jobs import _run_bulk_generation

        with patch("app.database.SessionLocal", TestingSessionLocal):
            _run_bulk_generation(99999, BulkGenerateRequest(llm_provider="openai"))

    def test_run_bulk_generation_missing_project(self):
        from app.models.bulk_job import BulkJob, BulkJobKind, BulkJobStatus
        from app.schemas.bulk_job import BulkGenerateRequest
        from app.routers.bulk_jobs import _run_bulk_generation

        db = TestingSessionLocal()
        job = BulkJob(project_id=99999, kind=BulkJobKind.generate, status=BulkJobStatus.pending)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id
        db.close()

        with patch("app.database.SessionLocal", TestingSessionLocal):
            _run_bulk_generation(job_id, BulkGenerateRequest(llm_provider="openai"))

        verify = TestingSessionLocal()
        refreshed = verify.query(BulkJob).filter(BulkJob.id == job_id).first()
        assert refreshed.status == BulkJobStatus.failed
        verify.close()

    def test_run_bulk_generation_item_missing_tc(self):
        from app.models.project import Project
        from app.models.bulk_job import BulkJob, BulkJobItem, BulkJobKind, BulkJobStatus, BulkJobItemStatus
        from app.schemas.bulk_job import BulkGenerateRequest
        from app.routers.bulk_jobs import _run_bulk_generation

        db = TestingSessionLocal()
        project = Project(name="Bulk Missing TC", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)

        job = BulkJob(project_id=project.id, kind=BulkJobKind.generate, status=BulkJobStatus.pending)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id
        item = BulkJobItem(job_id=job.id, test_case_id=99999)
        db.add(item)
        db.commit()
        item_id = item.id
        db.close()

        with patch("app.database.SessionLocal", TestingSessionLocal):
            _run_bulk_generation(job_id, BulkGenerateRequest(llm_provider="openai"))

        verify = TestingSessionLocal()
        refreshed_item = verify.query(BulkJobItem).filter(BulkJobItem.id == item_id).first()
        assert refreshed_item.status == BulkJobItemStatus.skipped
        verify.close()

    def test_run_bulk_generation_agent_exception(self):
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.bulk_job import BulkJob, BulkJobItem, BulkJobKind, BulkJobStatus, BulkJobItemStatus
        from app.schemas.bulk_job import BulkGenerateRequest
        from app.routers.bulk_jobs import _run_bulk_generation

        db = TestingSessionLocal()
        project = Project(name="Bulk Exception", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)
        tc = TestCase(project_id=project.id, title="TC", format="step_based", content="x")
        db.add(tc)
        db.commit()
        db.refresh(tc)

        job = BulkJob(project_id=project.id, kind=BulkJobKind.generate, status=BulkJobStatus.pending)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id
        item = BulkJobItem(job_id=job.id, test_case_id=tc.id)
        db.add(item)
        db.commit()
        item_id = item.id
        db.close()

        with patch("app.routers.bulk_jobs.run_agent", side_effect=RuntimeError("bulk boom")):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_bulk_generation(job_id, BulkGenerateRequest(llm_provider="openai"))

        verify = TestingSessionLocal()
        refreshed_item = verify.query(BulkJobItem).filter(BulkJobItem.id == item_id).first()
        assert refreshed_item.status == BulkJobItemStatus.failed
        assert "bulk boom" in refreshed_item.message
        verify.close()

    def test_run_bulk_execution_timeout(self):
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.models.bulk_job import BulkJob, BulkJobItem, BulkJobKind, BulkJobStatus, BulkJobItemStatus
        from app.schemas.bulk_job import BulkRunRequest
        from app.routers.bulk_jobs import _run_bulk_execution

        db = TestingSessionLocal()
        project = Project(name="Bulk Run P", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)

        tc = TestCase(project_id=project.id, title="TC", format="step_based", content="x")
        db.add(tc)
        db.commit()
        db.refresh(tc)

        script = GeneratedScript(
            project_id=project.id,
            test_case_id=tc.id,
            framework="playwright_python",
            llm_provider="openai",
            llm_model="gpt-4o",
            status=ScriptStatus.completed,
            script_content="print('ok')",
        )
        db.add(script)
        db.commit()
        db.refresh(script)

        job = BulkJob(project_id=project.id, kind=BulkJobKind.run, status=BulkJobStatus.pending)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id

        item = BulkJobItem(job_id=job.id, test_case_id=tc.id)
        db.add(item)
        db.commit()
        item_id = item.id
        db.close()

        with patch("app.routers.bulk_jobs._run_python_script", side_effect=subprocess.TimeoutExpired(cmd="x", timeout=5)):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_bulk_execution(job_id, BulkRunRequest())

        verify = TestingSessionLocal()
        refreshed_item = verify.query(BulkJobItem).filter(BulkJobItem.id == item_id).first()
        assert refreshed_item.status == BulkJobItemStatus.failed
        verify.close()

    def test_run_bulk_execution_unsafe_script(self):
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.models.bulk_job import BulkJob, BulkJobItem, BulkJobKind, BulkJobStatus, BulkJobItemStatus
        from app.models.script_run import ScriptRun, ScriptRunStatus
        from app.schemas.bulk_job import BulkRunRequest
        from app.routers.bulk_jobs import _run_bulk_execution

        db = TestingSessionLocal()
        project = Project(name="Bulk Unsafe", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)
        tc = TestCase(project_id=project.id, title="TC", format="step_based", content="x")
        db.add(tc)
        db.commit()
        db.refresh(tc)

        script = GeneratedScript(
            project_id=project.id,
            test_case_id=tc.id,
            framework="playwright_python",
            llm_provider="openai",
            llm_model="gpt-4o",
            status=ScriptStatus.completed,
            script_content="print('x')",
        )
        db.add(script)
        db.commit()

        job = BulkJob(project_id=project.id, kind=BulkJobKind.run, status=BulkJobStatus.pending)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id
        item = BulkJobItem(job_id=job.id, test_case_id=tc.id)
        db.add(item)
        db.commit()
        item_id = item.id
        db.close()

        with patch("app.routers.bulk_jobs._run_python_script", side_effect=ValueError("Unsafe import detected: subprocess")):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_bulk_execution(job_id, BulkRunRequest())

        verify = TestingSessionLocal()
        refreshed_item = verify.query(BulkJobItem).filter(BulkJobItem.id == item_id).first()
        assert refreshed_item.status == BulkJobItemStatus.failed
        assert "Unsafe import detected" in refreshed_item.message
        runs = verify.query(ScriptRun).all()
        assert len(runs) == 1
        assert runs[0].status == ScriptRunStatus.failed
        verify.close()

    def test_run_bulk_execution_no_job(self):
        from app.schemas.bulk_job import BulkRunRequest
        from app.routers.bulk_jobs import _run_bulk_execution

        with patch("app.database.SessionLocal", TestingSessionLocal):
            _run_bulk_execution(99999, BulkRunRequest())

    def test_run_bulk_execution_skips_missing_and_non_playwright(self):
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.models.bulk_job import BulkJob, BulkJobItem, BulkJobKind, BulkJobStatus, BulkJobItemStatus
        from app.schemas.bulk_job import BulkRunRequest
        from app.routers.bulk_jobs import _run_bulk_execution

        db = TestingSessionLocal()
        project = Project(name="Bulk Skip", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)

        tc_missing = TestCase(project_id=project.id, title="Missing", format="step_based", content="x")
        tc_non_pw = TestCase(project_id=project.id, title="Non PW", format="step_based", content="x")
        db.add_all([tc_missing, tc_non_pw])
        db.commit()
        db.refresh(tc_missing)
        db.refresh(tc_non_pw)

        non_pw_script = GeneratedScript(
            project_id=project.id,
            test_case_id=tc_non_pw.id,
            framework="selenium_python",
            llm_provider="openai",
            llm_model="gpt-4o",
            status=ScriptStatus.completed,
            script_content="print('x')",
        )
        db.add(non_pw_script)
        db.commit()

        job = BulkJob(project_id=project.id, kind=BulkJobKind.run, status=BulkJobStatus.pending)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id

        i1 = BulkJobItem(job_id=job.id, test_case_id=tc_missing.id)
        i2 = BulkJobItem(job_id=job.id, test_case_id=tc_non_pw.id)
        db.add_all([i1, i2])
        db.commit()
        i1_id = i1.id
        i2_id = i2.id
        db.close()

        with patch("app.database.SessionLocal", TestingSessionLocal):
            _run_bulk_execution(job_id, BulkRunRequest())

        verify = TestingSessionLocal()
        ri1 = verify.query(BulkJobItem).filter(BulkJobItem.id == i1_id).first()
        ri2 = verify.query(BulkJobItem).filter(BulkJobItem.id == i2_id).first()
        assert ri1.status == BulkJobItemStatus.skipped
        assert ri2.status == BulkJobItemStatus.skipped
        verify.close()

    def test_run_bulk_execution_failed_result(self):
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.models.bulk_job import BulkJob, BulkJobItem, BulkJobKind, BulkJobStatus, BulkJobItemStatus
        from app.schemas.bulk_job import BulkRunRequest
        from app.routers.bulk_jobs import _run_bulk_execution

        db = TestingSessionLocal()
        project = Project(name="Bulk Fail", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)
        tc = TestCase(project_id=project.id, title="TC", format="step_based", content="x")
        db.add(tc)
        db.commit()
        db.refresh(tc)

        script = GeneratedScript(
            project_id=project.id,
            test_case_id=tc.id,
            framework="playwright_python",
            llm_provider="openai",
            llm_model="gpt-4o",
            status=ScriptStatus.completed,
            script_content="print('x')",
        )
        db.add(script)
        db.commit()

        job = BulkJob(project_id=project.id, kind=BulkJobKind.run, status=BulkJobStatus.pending)
        db.add(job)
        db.commit()
        db.refresh(job)
        job_id = job.id
        item = BulkJobItem(job_id=job.id, test_case_id=tc.id)
        db.add(item)
        db.commit()
        item_id = item.id
        db.close()

        with patch("app.routers.bulk_jobs._run_python_script", return_value={
            "success": False,
            "exit_code": 1,
            "stdout": "",
            "stderr": "boom",
            "duration_seconds": 1.0,
            "command": "python x.py",
        }):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_bulk_execution(job_id, BulkRunRequest())

        verify = TestingSessionLocal()
        refreshed_item = verify.query(BulkJobItem).filter(BulkJobItem.id == item_id).first()
        assert refreshed_item.status == BulkJobItemStatus.failed
        verify.close()

    def test_run_script_non_playwright_rejected(self, client):

        class TestFinalMissingCoverage:
            """Final targeted tests for remaining 10 missing statements."""

            def test_bedrock_default_model_from_settings(self):
                """Cover provider.py:50 - bedrock default model."""
                from app.llm.provider import _default_model_for_provider, settings as prov_settings
        
                # Ensure we're calling the bedrock case
                original = prov_settings.BEDROCK_MODEL_ID
                try:
                    prov_settings.BEDROCK_MODEL_ID = "anthropic.claude-3-sonnet"
                    result = _default_model_for_provider("bedrock")
                    assert result == "anthropic.claude-3-sonnet"
                finally:
                    prov_settings.BEDROCK_MODEL_ID = original

            def test_gemini_not_found_error_in_agent(self):
                """Cover script_gini_agent.py:85 - Gemini model not found exception."""
                from app.agents.script_gini_agent import _llm_invoke
        
                mock_llm = MagicMock()
                mock_llm.invoke.side_effect = ValueError("API request failed with status 404: Model not_found not found for API version gemini-2.0-flash")
        
                state = {
                    "llm_provider": "gemini",
                    "llm_model": "invalid-model",
                }
        
                with patch("app.agents.script_gini_agent.get_llm", return_value=mock_llm):
                    with pytest.raises(ValueError, match="Gemini model was not found"):
                        _llm_invoke(state, "system prompt", "user message")

            def test_openai_key_check_in_provider_readiness(self):
                """Cover scripts.py line 96 - openai key check."""
                from app.routers.scripts import _provider_readiness
                from app.config import settings
        
                # Save original
                original_key = settings.OPENAI_API_KEY
                try:
                    settings.OPENAI_API_KEY = ""
                    ok, msg = _provider_readiness("openai")
                    assert ok is False
                    assert "OpenAI API key is missing" in msg
                finally:
                    settings.OPENAI_API_KEY = original_key

            def test_openrouter_key_check_in_provider_readiness(self):
                """Cover scripts.py line 101 - openrouter key check."""
                from app.routers.scripts import _provider_readiness
                from app.config import settings
        
                original_key = settings.OPENROUTER_API_KEY
                try:
                    settings.OPENROUTER_API_KEY = ""
                    ok, msg = _provider_readiness("openrouter")
                    assert ok is False
                    assert "OpenRouter API key is missing" in msg
                finally:
                    settings.OPENROUTER_API_KEY = original_key

            def test_gemini_key_check_in_provider_readiness(self):
                """Cover scripts.py line 106 - gemini key check."""
                from app.routers.scripts import _provider_readiness
                from app.config import settings
        
                original_key = settings.GOOGLE_API_KEY
                try:
                    settings.GOOGLE_API_KEY = ""
                    ok, msg = _provider_readiness("gemini")
                    assert ok is False
                    assert "Google API key is missing" in msg
                finally:
                    settings.GOOGLE_API_KEY = original_key

            def test_bedrock_region_check_in_provider_readiness(self):
                """Cover scripts.py line 116 - bedrock region check."""
                from app.routers.scripts import _provider_readiness
                from app.config import settings
        
                original_region = settings.AWS_REGION_NAME
                try:
                    settings.AWS_REGION_NAME = ""
                    ok, msg = _provider_readiness("bedrock")
                    assert ok is False
                    assert "AWS region is missing" in msg
                finally:
                    settings.AWS_REGION_NAME = original_region

            def test_unknown_provider_in_provider_readiness(self, client):
                """Cover scripts.py line 329 - unknown provider fallback."""
                from app.routers.scripts import _provider_readiness
        
                # Test with an unknown provider - should return False
                ok, msg = _provider_readiness("unknown_provider_xyz")  # type: ignore
                assert ok is False

            def test_fallback_ollama_exception_handling(self):
                """Cover scripts.py lines 369-371 - fallback exception handling."""
                from app.routers.scripts import _run_generation
                from app.models.project import Project
                from app.models.test_case import TestCase
                from app.models.generated_script import GeneratedScript, ScriptStatus
                from app.schemas.generated_script import GenerateScriptRequest
        
                # Setup: create project, test case, and script
                db = TestingSessionLocal()
                project = Project(name="Fallback Test", aut_base_url="https://example.com")
                db.add(project)
                db.commit()
                db.refresh(project)
        
                tc = TestCase(project_id=project.id, title="Fallback TC", format="step_based", content="...")
                db.add(tc)
                db.commit()
                db.refresh(tc)
        
                script = GeneratedScript(
                    project_id=project.id,
                    test_case_id=tc.id,
                    framework="playwright_python",
                    llm_provider="openai",
                    llm_model="gpt-4o",
                    status=ScriptStatus.pending,
                )
                db.add(script)
                db.commit()
                db.refresh(script)
                script_id = script.id
                db.close()
        
                request = GenerateScriptRequest(llm_provider="openai")
        
                # Mock: first call fails with connection error, fallback attempt raises exception
                def side_effect_run_agent(**kwargs):
                    provider = kwargs.get("llm_provider", "openai")
                    if provider == "openai":
                        return {"script": "", "error": "Connection refused", "token_usage": 0}
                    elif provider == "ollama":
                        raise RuntimeError("Ollama fallback exception occurred")
                    return {"script": "", "error": None, "token_usage": 0}
        
                with patch("app.routers.scripts.run_agent", side_effect=side_effect_run_agent):
                    with patch("app.database.SessionLocal", TestingSessionLocal):
                        _run_generation(script_id, project, tc, request)
        
                verify_db = TestingSessionLocal()
                updated_script = verify_db.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
                # The error message should contain both the connection error and the fallback exception
                assert "Ollama fallback exception" in updated_script.error_message
                verify_db.close()

            def test_gemini_fallback_not_successful(self):
                """Cover scripts.py lines around 329 - gemini fallback with error."""
                from app.routers.scripts import _run_generation
                from app.models.project import Project
                from app.models.test_case import TestCase
                from app.models.generated_script import GeneratedScript, ScriptStatus
                from app.schemas.generated_script import GenerateScriptRequest
        
                db = TestingSessionLocal()
                project = Project(name="Gemini FB Test", aut_base_url="https://example.com")
                db.add(project)
                db.commit()
                db.refresh(project)
        
                tc = TestCase(project_id=project.id, title="Gemini FB TC", format="step_based", content="...")
                db.add(tc)
                db.commit()
                db.refresh(tc)
        
                script = GeneratedScript(
                    project_id=project.id,
                    test_case_id=tc.id,
                    framework="playwright_python",
                    llm_provider="openai",
                    llm_model="gpt-4o",
                    status=ScriptStatus.pending,
                )
                db.add(script)
                db.commit()
                db.refresh(script)
                script_id = script.id
                db.close()
        
                request = GenerateScriptRequest(llm_provider="openai")
        
                # Mock: openai fails, then gemini fallback fails, then ollama succeeds
                def side_effect_run_agent(**kwargs):
                    provider = kwargs.get("llm_provider", "openai")
                    if provider == "openai":
                        return {"script": "", "error": "OpenAI connection timeout", "token_usage": 0}
                    elif provider == "gemini":
                        return {"script": "", "error": "Gemini API error", "token_usage": 0}
                    elif provider == "ollama":
                        return {"script": "# success", "error": None, "token_usage": 10}
                    return {"script": "", "error": None, "token_usage": 0}
        
                with patch("app.routers.scripts.run_agent", side_effect=side_effect_run_agent):
                    with patch("app.database.SessionLocal", TestingSessionLocal):
                        _run_generation(script_id, project, tc, request)
        
                verify_db = TestingSessionLocal()
                updated_script = verify_db.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
                # After gemini fails, ollama should succeed and provide the script
                assert updated_script.script_content == "# success"
                verify_db.close()
        p = _make_project(client)
        tc = _make_tc(client, p["id"])
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai", "framework": "selenium_python"},
            )

        sid = gen_resp.json()["id"]
        db = TestingSessionLocal()
        from app.models.generated_script import GeneratedScript, ScriptStatus
        script = db.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        script.status = ScriptStatus.completed
        script.script_content = "print('ok')"
        db.commit()
        db.close()

        resp = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/run")
        assert resp.status_code == 400

    def test_run_python_script_helper(self):
        from app.routers.scripts import _run_python_script

        mock_completed = MagicMock(returncode=0, stdout="done", stderr="")
        with patch("app.routers.scripts.subprocess.run", return_value=mock_completed):
            result = _run_python_script("print('ok')")
        assert result["success"] is True
        assert result["exit_code"] == 0

    def test_validate_script_safety_blocks_imports_and_builtin_calls(self):
        from app.routers.scripts import _validate_script_safety

        with pytest.raises(ValueError, match="Disallowed import detected: subprocess"):
            _validate_script_safety("import subprocess")

        with pytest.raises(ValueError, match="Disallowed import detected: socket"):
            _validate_script_safety("from socket import socket")

        with pytest.raises(ValueError, match="Unsafe builtin call detected: exec"):
            _validate_script_safety("exec('print(1)')")

    def test_validate_script_safety_blocks_runtime_breakout_vectors(self):
        from app.routers.scripts import _validate_script_safety

        with pytest.raises(ValueError, match="Disallowed import detected: os"):
            _validate_script_safety("import os\nos.system('whoami')")

        with pytest.raises(ValueError, match="Unsafe symbol usage detected: __builtins__"):
            _validate_script_safety("x = __builtins__")

        with pytest.raises(ValueError, match="Unsafe introspection token detected: __subclasses__"):
            _validate_script_safety("name = '__subclasses__'")

        with pytest.raises(ValueError, match="Unsafe runtime call detected: system"):
            _validate_script_safety("obj.system('echo hi')")

    def test_validate_script_safety_rejects_syntax_error(self):
        from app.routers.scripts import _validate_script_safety

        with pytest.raises(ValueError, match="Generated script has syntax issues"):
            _validate_script_safety("def bad(:\n    pass")

    def test_build_restricted_env_filters_variables(self):
        from app.routers.scripts import _build_restricted_env

        fake_env = {
            "PATH": "x",
            "SYSTEMROOT": "x",
            "PLAYWRIGHT_BROWSERS_PATH": "x",
            "PYTHONHOME": "x",
            "SECRET_TOKEN": "blocked",
        }
        with patch.dict("app.routers.scripts.os.environ", fake_env, clear=True):
            result = _build_restricted_env()

        assert "PATH" in result
        assert "SYSTEMROOT" in result
        assert "PLAYWRIGHT_BROWSERS_PATH" in result
        assert "PYTHONHOME" in result
        assert "SECRET_TOKEN" not in result


class TestAdditionalCoverageGaps:
    def test_runtime_llm_endpoint(self, client):
        with patch("app.main.get_llm_diagnostics", return_value={
            "provider": "openai",
            "model": "gpt-4o",
            "api_key_env": "OPENAI_API_KEY",
            "api_key_present": True,
            "api_key_masked": "<masked>",
        }):
            resp = client.get("/api/v1/runtime/llm")
        assert resp.status_code == 200
        payload = resp.json()
        assert payload["default_provider"] == "openai"
        assert payload["default_model"] == "gpt-4o"
        assert "openai" in payload["provider_diagnostics"]

    def test_provider_helpers_and_missing_keys(self):
        from app.llm import provider as p

        assert p._mask_secret("") == "<missing>"
        assert p._mask_secret("short") == "****"
        assert p._default_model_for_provider("bedrock") == p.settings.BEDROCK_MODEL_ID
        diag = p.get_llm_diagnostics("bedrock", None)
        assert diag["provider"] == "bedrock"

        mock_openai = MagicMock()
        with patch.dict("sys.modules", {"langchain_openai": MagicMock(ChatOpenAI=mock_openai)}):
            with patch.object(p.settings, "OPENAI_API_KEY", ""):
                p._openai("gpt-4o", 0.1)
        mock_openai.assert_called_once_with(
            model="gpt-4o",
            temperature=0.1,
            timeout=p.settings.LLM_REQUEST_TIMEOUT_SECONDS,
        )

        mock_openrouter = MagicMock()
        with patch.dict("sys.modules", {"langchain_openai": MagicMock(ChatOpenAI=mock_openrouter)}):
            with patch.object(p.settings, "OPENROUTER_API_KEY", ""):
                p._openrouter("openai/gpt-4o", 0.1)
        mock_openrouter.assert_called_once_with(
            model="openai/gpt-4o",
            temperature=0.1,
            base_url=p.settings.OPENROUTER_BASE_URL,
            timeout=p.settings.LLM_REQUEST_TIMEOUT_SECONDS,
            default_headers={
                "HTTP-Referer": "https://scriptgini.local",
                "X-Title": "ScriptGini",
            },
        )

        mock_gemini = MagicMock()
        with patch.dict("sys.modules", {
            "langchain_google_genai": MagicMock(ChatGoogleGenerativeAI=mock_gemini)
        }):
            with patch.object(p.settings, "GOOGLE_API_KEY", ""):
                p._gemini("gemini-2.5-flash", 0.1)
        mock_gemini.assert_called_once_with(model="gemini-2.5-flash", temperature=0.1)

    def test_agent_local_intent_branch(self):
        from app.agents import script_gini_agent as ag

        state = _make_base_state(
            test_case_title="",
            test_case_content=(
                "Precondition: user exists\n"
                "Given user is on login\n"
                "Step 1: Enter username\n"
                "When submit is clicked\n"
                "Expected: dashboard is visible\n"
                "Then user sees welcome"
            ),
            preconditions="base precondition",
        )
        local = ag._extract_local_intent(state)
        assert "Enter username" in local["actions"]
        assert "dashboard is visible" in local["assertions"]
        assert "base precondition" in local["parsed_preconditions"]

        with patch.object(ag.settings, "USE_LLM_INTENT_ANALYSIS", False):
            result = ag.node_parse_intent(state)
        assert result["business_intent"] == "Precondition: user exists"
        assert result["error"] is None

        # Trigger fallback action/assertion extraction branches.
        fallback_state = _make_base_state(
            test_case_title="Fallback Intent",
            test_case_content="Open page\nUser should be redirected",
        )
        local2 = ag._extract_local_intent(fallback_state)
        assert "Open page" in local2["actions"]
        assert "should" in local2["assertions"]

    def test_agent_timeout_and_review_skip_branches(self):
        from app.agents import script_gini_agent as ag

        # Cover ollama timeout message augmentation in node_generate_script.
        with patch("app.agents.script_gini_agent._llm_invoke", side_effect=RuntimeError("timeout while waiting")):
            result = ag.node_generate_script(_make_base_state(llm_provider="ollama", business_intent="x"))
        assert "Ollama timed out" in result["error"]

        # Cover ollama review skip branch.
        with patch.object(ag.settings, "SKIP_REVIEW_FOR_OLLAMA", True):
            skipped = ag.node_review_script(_make_base_state(script="print('x')", llm_provider="ollama"))
        assert skipped == {}

    def test_agent_llm_invoke_else_branch_runtime_error(self):
        from app.agents.script_gini_agent import _llm_invoke

        # max_attempts becomes 0 -> for/else branch runtime error path.
        with patch("app.agents.script_gini_agent.get_llm", return_value=MagicMock()):
            with patch("app.agents.script_gini_agent.settings.OLLAMA_TIMEOUT_RETRIES", -1):
                with pytest.raises(RuntimeError, match="LLM invocation failed unexpectedly"):
                    _llm_invoke(_make_base_state(llm_provider="ollama"), "sys", "human")

    def test_scripts_provider_readiness_and_helper_branches(self, client):
        from app.routers import scripts as sr

        assert sr._looks_like_connection_error(None) is False
        assert sr._looks_like_connection_error("API connection refused") is True
        assert sr._looks_like_connection_error("all good") is False

        mock_conn = MagicMock()
        mock_conn.__enter__.return_value = mock_conn
        mock_conn.__exit__.return_value = False
        with patch("app.routers.scripts.socket.create_connection", return_value=mock_conn):
            assert sr._is_ollama_reachable() is True

        with patch("app.routers.scripts.socket.create_connection", side_effect=OSError("down")):
            assert sr._is_ollama_reachable() is False

        with patch.object(sr.settings, "OPENAI_API_KEY", ""):
            ok, _ = sr._provider_readiness("openai")
            assert ok is False
        with patch.object(sr.settings, "OPENROUTER_API_KEY", ""):
            ok, _ = sr._provider_readiness("openrouter")
            assert ok is False
        with patch.object(sr.settings, "GOOGLE_API_KEY", ""):
            ok, _ = sr._provider_readiness("gemini")
            assert ok is False
        with patch.object(sr.settings, "AWS_REGION_NAME", ""):
            ok, _ = sr._provider_readiness("bedrock")
            assert ok is False
        ok, _ = sr._provider_readiness("bedrock")
        assert ok is True
        ok, _ = sr._provider_readiness("openaiish")  # type: ignore[arg-type]
        assert ok is False

        ok, msg = sr._provider_readiness("bedrock")
        assert isinstance(msg, str)
        assert ok is True

        p = _make_project(client)
        tc = _make_tc(client, p["id"])
        with patch("app.routers.scripts._is_ollama_reachable", return_value=True):
            ready = client.get(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/providers/ollama/ready")
        assert ready.status_code == 200
        assert ready.json()["ready"] is True

        assert sr._uses_pytest_playwright("def x(:\n") is False
        assert sr._uses_pytest_playwright("def helper():\n    return 1") is False
        assert sr._uses_pytest_playwright("def test_ui(page):\n    pass") is True

        cmd = sr._build_script_command(Path("x.py"), "def test_ui(page):\n    pass")
        assert "pytest" in cmd

    def test_run_agent_with_deadline_timeout_branch(self):
        from app.routers import scripts as sr

        def _slow_run_agent(**kwargs):
            import time
            time.sleep(0.03)
            return {"script": "x", "error": None, "token_usage": 0}

        with patch("app.routers.scripts.run_agent", side_effect=_slow_run_agent):
            with patch.object(sr.settings, "SCRIPT_GENERATION_TIMEOUT_SECONDS", 0.001):
                with pytest.raises(TimeoutError, match="Script generation exceeded"):
                    sr._run_agent_with_deadline(test_case_title="x")

    def test_run_generation_fallback_paths(self):
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.routers.scripts import _run_generation

        db = TestingSessionLocalNoExpire()
        project = Project(name="Fallback P", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)
        tc = TestCase(project_id=project.id, title="T", format="step_based", content="...")
        db.add(tc)
        db.commit()
        db.refresh(tc)
        script = GeneratedScript(
            project_id=project.id,
            test_case_id=tc.id,
            framework="playwright_python",
            llm_provider="gemini",
            llm_model="bad-model",
            status=ScriptStatus.pending,
        )
        db.add(script)
        db.commit()
        db.refresh(script)
        script_id = script.id
        db.close()

        # First error triggers gemini fallback success.
        first = {"script": "", "error": "model was not found", "token_usage": 0}
        second = {"script": "print('ok')", "error": None, "token_usage": 3}
        with patch("app.routers.scripts._run_agent_with_deadline", side_effect=[first, second]):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_generation(script_id, project.id, tc.id, {"llm_provider": "gemini", "llm_model": "bad-model"})

        verify = TestingSessionLocal()
        updated = verify.query(GeneratedScript).filter(GeneratedScript.id == script_id).first()
        assert updated.status == ScriptStatus.completed
        assert updated.llm_model == "gemini-flash-latest"
        verify.close()

    def test_run_generation_project_or_tc_missing_branch(self):
        from app.models.project import Project
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.routers.scripts import _run_generation

        db = TestingSessionLocalNoExpire()
        project = Project(name="Missing TC P", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)
        script = GeneratedScript(
            project_id=project.id,
            test_case_id=999999,
            framework="playwright_python",
            llm_provider="openai",
            llm_model="gpt-4o",
            status=ScriptStatus.pending,
        )
        db.add(script)
        db.commit()
        db.refresh(script)
        sid = script.id
        db.close()

        with patch("app.database.SessionLocal", TestingSessionLocal):
            _run_generation(sid, project.id, 999999, {"llm_provider": "openai"})

        verify = TestingSessionLocal()
        updated = verify.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        assert updated.status == ScriptStatus.failed
        assert updated.error_message == "Project or test case not found"
        verify.close()

    def test_run_generation_connection_fallback_and_export_paths(self, client):
        from app.models.generated_script import GeneratedScript, ScriptStatus

        p = _make_project(client)
        tc = _make_tc(client, p["id"])
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )
        sid = gen_resp.json()["id"]

        db = TestingSessionLocal()
        script = db.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        script.status = ScriptStatus.completed
        script.script_content = "print('ok')"
        db.commit()
        db.close()

        # Disabled export branch.
        with patch("app.routers.scripts.settings.AUTO_EXPORT_GIT_ENABLED", False):
            disabled = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/github-export")
        assert disabled.status_code == 400

        # Export exception and empty path branches.
        with patch("app.routers.scripts.settings.AUTO_EXPORT_GIT_ENABLED", True):
            with patch("app.routers.scripts.export_generated_script", side_effect=RuntimeError("boom")):
                failed = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/github-export")
            assert failed.status_code == 500

            with patch("app.routers.scripts.export_generated_script", return_value=None):
                empty = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/github-export")
            assert empty.status_code == 500

            with patch("app.routers.scripts.export_generated_script", return_value="generated-scripts/p/t.py"):
                ok = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/github-export")
            assert ok.status_code == 200
            assert ok.json()["exported"] is True

    def test_run_generation_connection_fallback_error_branches(self):
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.routers.scripts import _run_generation

        db = TestingSessionLocalNoExpire()
        project = Project(name="Conn Fallback P", aut_base_url="https://x.com")
        db.add(project)
        db.commit()
        db.refresh(project)
        tc = TestCase(project_id=project.id, title="T", format="step_based", content="...")
        db.add(tc)
        db.commit()
        db.refresh(tc)
        script = GeneratedScript(
            project_id=project.id,
            test_case_id=tc.id,
            framework="playwright_python",
            llm_provider="openai",
            llm_model="gpt-4o",
            status=ScriptStatus.pending,
        )
        db.add(script)
        db.commit()
        db.refresh(script)
        sid = script.id
        db.close()

        # Primary connection error + fallback returns error.
        first = {"script": "", "error": "connection refused", "token_usage": 0}
        second = {"script": "", "error": "fallback down", "token_usage": 0}
        with patch("app.routers.scripts._run_agent_with_deadline", side_effect=[first, second]):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_generation(sid, project.id, tc.id, {"llm_provider": "openai", "llm_model": None})

        verify = TestingSessionLocal()
        updated = verify.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        assert updated.status == ScriptStatus.failed
        assert "Ollama fallback failed" in (updated.error_message or "")
        verify.close()

        # Fallback throws exception branch.
        db2 = TestingSessionLocalNoExpire()
        script2 = db2.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        script2.status = ScriptStatus.pending
        db2.commit()
        db2.close()

        with patch("app.routers.scripts._run_agent_with_deadline", side_effect=[first, RuntimeError("fallback crash")]):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_generation(sid, project.id, tc.id, {"llm_provider": "openai", "llm_model": None})

        verify2 = TestingSessionLocal()
        updated2 = verify2.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        assert updated2.status == ScriptStatus.failed
        assert "Ollama fallback exception" in (updated2.error_message or "")
        verify2.close()

    def test_github_export_script_not_ready_branch(self, client):
        p = _make_project(client)
        tc = _make_tc(client, p["id"])
        mock_task = MagicMock()
        with patch("app.routers.scripts.process_script_generation_job", mock_task):
            gen_resp = client.post(
                f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/generate",
                json={"llm_provider": "openai"},
            )
        sid = gen_resp.json()["id"]

        resp = client.post(f"/api/v1/projects/{p['id']}/test-cases/{tc['id']}/scripts/{sid}/github-export")
        assert resp.status_code == 400

    def test_git_export_internal_functions(self):
        from app.services import git_export as ge

        assert ge._slugify("  Hello, World!  ") == "hello-world"
        assert ge._slugify("!!!") == "untitled"

        ok_cp = MagicMock(returncode=0, stdout="", stderr="")
        with patch("app.services.git_export.subprocess.run", return_value=ok_cp):
            cp = ge._git_run(["status"], cwd=Path("."))
        assert cp.returncode == 0

        bad_cp = MagicMock(returncode=1, stdout="", stderr="fatal")
        with patch("app.services.git_export.subprocess.run", return_value=bad_cp):
            with pytest.raises(RuntimeError, match="fatal"):
                ge._git_run(["status"], cwd=Path("."))

        with patch("app.services.git_export._git_run", return_value=MagicMock(stdout="M file.py\n")):
            assert ge._repo_has_changes(Path(".")) is True
        with patch("app.services.git_export._git_run", return_value=MagicMock(stdout="")):
            assert ge._repo_has_changes(Path(".")) is False

        with tempfile.TemporaryDirectory() as tmp:
            repo_dir = Path(tmp) / "repo"
            repo_dir.mkdir(parents=True, exist_ok=True)
            with patch.object(ge.settings, "AUTO_EXPORT_GIT_LOCAL_PATH", str(repo_dir)):
                with patch.object(ge.settings, "AUTO_EXPORT_GIT_REPO_URL", "https://example.com/repo.git"):
                    with patch.object(ge.settings, "AUTO_EXPORT_GIT_BRANCH", "main"):
                        calls = []

                        def _record_git(args, cwd):
                            calls.append(args)
                            return MagicMock(returncode=0, stdout="", stderr="")

                        # Clone flow when .git does not exist.
                        with patch("app.services.git_export._git_run", side_effect=_record_git):
                            resolved = ge._prepare_repo_checkout()
                        assert resolved == repo_dir
                        assert calls[0][0] == "clone"

                        # Existing repo flow.
                        (repo_dir / ".git").mkdir(exist_ok=True)
                        calls.clear()
                        with patch("app.services.git_export._git_run", side_effect=_record_git):
                            resolved2 = ge._prepare_repo_checkout()
                        assert resolved2 == repo_dir
                        assert [c[0] for c in calls] == ["remote", "fetch", "checkout", "pull"]

        # High-level export flow: disabled, missing URL, then success path.
        with patch.object(ge.settings, "AUTO_EXPORT_GIT_ENABLED", False):
            assert ge.export_generated_script(
                project_name="P",
                test_case_title="T",
                script_id=1,
                framework="playwright_python",
                llm_provider="openai",
                llm_model="gpt-4o",
                script_content="print('x')",
            ) is None

        with patch.object(ge.settings, "AUTO_EXPORT_GIT_ENABLED", True), patch.object(ge.settings, "AUTO_EXPORT_GIT_REPO_URL", ""):
            assert ge.export_generated_script(
                project_name="P",
                test_case_title="T",
                script_id=2,
                framework="playwright_python",
                llm_provider="openai",
                llm_model="gpt-4o",
                script_content="print('x')",
            ) is None

        with tempfile.TemporaryDirectory() as tmp2:
            repo = Path(tmp2) / "repo"
            repo.mkdir(parents=True, exist_ok=True)
            (repo / ".git").mkdir(exist_ok=True)

            with patch.object(ge.settings, "AUTO_EXPORT_GIT_ENABLED", True), \
                patch.object(ge.settings, "AUTO_EXPORT_GIT_REPO_URL", "https://example.com/repo.git"), \
                patch.object(ge.settings, "AUTO_EXPORT_GIT_BRANCH", "main"), \
                patch.object(ge.settings, "AUTO_EXPORT_GIT_USER_NAME", "ScriptGini"), \
                patch.object(ge.settings, "AUTO_EXPORT_GIT_USER_EMAIL", "scriptgini@local"), \
                patch("app.services.git_export._prepare_repo_checkout", return_value=repo), \
                patch("app.services.git_export._repo_has_changes", side_effect=[True]), \
                patch("app.services.git_export._git_run", return_value=MagicMock(returncode=0, stdout="", stderr="")):
                out = ge.export_generated_script(
                    project_name="Demo Project",
                    test_case_title="TC Login",
                    script_id=3,
                    framework="playwright_python",
                    llm_provider="openai",
                    llm_model="",
                    script_content="print('x')",
                )
            assert out.endswith(".py")

# ----------------------------------------------------------------------------
# Coverage Gap Tests (11 Missing Statements)
# ----------------------------------------------------------------------------

class TestFinalCoverageGaps:
    """Tests to reach 100% coverage - addressing 11 missing statements."""

    def test_gemini_default_model(self):
        """Cover provider default-model Gemini branch."""
        from app.llm import provider as pm

        with patch.object(pm.settings, "GEMINI_MODEL", "gemini-test-model"):
            assert pm._default_model_for_provider("gemini") == "gemini-test-model"

    def test_agent_gemini_error(self):
        """app/agents/script_gini_agent.py line 98: gemini model error."""
        from app.agents.script_gini_agent import _llm_invoke
        
        state = _make_base_state(llm_provider="gemini")
        with patch("app.agents.script_gini_agent.get_llm") as m:
            m_llm = MagicMock()
            m_llm.invoke.side_effect = Exception("not_found in response")
            m.return_value = m_llm
            try:
                _llm_invoke(state, "s", "h")
            except ValueError as e:
                assert "Gemini model" in str(e)

    def test_scripts_provider_success_and_ollama_unreachable_lines(self):
        """Cover provider readiness success branches and Ollama-unreachable branch."""
        from app.routers import scripts as sr

        with patch.object(sr.settings, "OPENAI_API_KEY", "key"):
            ok, msg = sr._provider_readiness("openai")
            assert ok is True
            assert "configured" in msg.lower()

        with patch.object(sr.settings, "OPENROUTER_API_KEY", "key"):
            ok, msg = sr._provider_readiness("openrouter")
            assert ok is True
            assert "configured" in msg.lower()

        with patch.object(sr.settings, "GOOGLE_API_KEY", "key"):
            ok, msg = sr._provider_readiness("gemini")
            assert ok is True
            assert "configured" in msg.lower()

        with patch("app.routers.scripts._is_ollama_reachable", return_value=False):
            ok, msg = sr._provider_readiness("ollama")
            assert ok is False
            assert "not reachable" in msg.lower()

    def test_scripts_line_329_gemini_fallback_failed(self):
        """Cover Gemini fallback-failed branch in _run_generation."""
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.routers.scripts import _run_generation

        db = TestingSessionLocalNoExpire()
        p = Project(name="Gemini Fallback", aut_base_url="https://x.com")
        db.add(p)
        db.commit()
        db.refresh(p)
        tc = TestCase(project_id=p.id, title="T", format="step_based", content="...")
        db.add(tc)
        db.commit()
        db.refresh(tc)
        s = GeneratedScript(project_id=p.id, test_case_id=tc.id, framework="playwright_python", llm_provider="gemini", llm_model="bad", status=ScriptStatus.pending)
        db.add(s)
        db.commit()
        db.refresh(s)
        sid = s.id
        db.close()

        first = {"script": "", "error": "model was not found", "token_usage": 0}
        second = {"script": "", "error": "still missing", "token_usage": 0}
        with patch("app.routers.scripts._run_agent_with_deadline", side_effect=[first, second]):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_generation(sid, p.id, tc.id, {"llm_provider": "gemini", "llm_model": "bad"})

        verify = TestingSessionLocal()
        updated = verify.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        assert updated.status == ScriptStatus.failed
        assert "Gemini fallback failed" in (updated.error_message or "")
        verify.close()

    def test_scripts_lines_369_371_ollama_success(self):
        """Cover Ollama fallback success branch that updates provider/model."""
        from app.models.project import Project
        from app.models.test_case import TestCase
        from app.models.generated_script import GeneratedScript, ScriptStatus
        from app.routers.scripts import _run_generation
        
        db = TestingSessionLocalNoExpire()
        p = Project(name="F369", aut_base_url="https://x.com")
        db.add(p)
        db.commit()
        db.refresh(p)
        tc = TestCase(project_id=p.id, title="T", format="step_based", content="...")
        db.add(tc)
        db.commit()
        db.refresh(tc)
        s = GeneratedScript(project_id=p.id, test_case_id=tc.id, framework="playwright_python", llm_provider="openai", llm_model="gpt-4", status=ScriptStatus.pending)
        db.add(s)
        db.commit()
        db.refresh(s)
        sid = s.id
        db.close()
        
        first = {"script": "", "error": "connection error", "token_usage": 0}
        second = {"script": "# ok", "error": None, "token_usage": 3}
        with patch("app.routers.scripts._run_agent_with_deadline", side_effect=[first, second]):
            with patch("app.database.SessionLocal", TestingSessionLocal):
                _run_generation(sid, p.id, tc.id, {"llm_provider": "openai"})

        v = TestingSessionLocal()
        u = v.query(GeneratedScript).filter(GeneratedScript.id == sid).first()
        assert u.status == ScriptStatus.completed
        assert u.llm_provider == "ollama"
        assert u.llm_model == ""
        assert u.script_content == "# ok"
        v.close()

    def test_git_export_line_55_no_changes(self):
        """app/services/git_export.py line 55: early return when no changes."""
        from app.services import git_export as ge
        from pathlib import Path as Pth
        
        with patch("app.services.git_export.settings.AUTO_EXPORT_GIT_ENABLED", True):
            with patch("app.services.git_export.settings.AUTO_EXPORT_GIT_REPO_URL", "https://test"):
                with patch("app.services.git_export._prepare_repo_checkout") as p1:
                    p1.return_value = Pth(tempfile.mkdtemp())
                    with patch("app.services.git_export._build_relative_script_path", return_value=Pth("x.py")):
                        with patch("app.services.git_export._git_run"):
                            with patch("app.services.git_export._repo_has_changes", return_value=False):
                                r = ge.export_generated_script(project_name="P", test_case_title="T", script_id=1, framework="pw", llm_provider="openai", llm_model="gpt", script_content="x")
                                assert r == "x.py"
