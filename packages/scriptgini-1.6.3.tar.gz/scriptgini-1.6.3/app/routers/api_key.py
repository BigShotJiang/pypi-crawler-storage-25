import logging

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.services import api_key as api_key_service
from app.services.auth_dependencies import get_current_user
from app.schemas.api_key import (
    APIKeyCreateRequest,
    APIKeyResponse,
    APIKeyRevealResponse,
    APIKeyUpdateRequest,
)
from app.models.api_key import APIKey

router = APIRouter(prefix="/auth/api-keys", tags=["auth"])
logger = logging.getLogger(__name__)


def _audit_api_key_event(
    event: str,
    actor_user_id: int,
    api_key_id: int | None,
    api_key_prefix: str | None,
    result: str,
) -> None:
    if not settings.SECURITY_AUDIT_LOG_ENABLED:
        return
    logger.info(
        "security_audit event=%s actor_user_id=%s api_key_id=%s api_key_prefix=%s result=%s",
        event,
        actor_user_id,
        api_key_id,
        api_key_prefix,
        result,
    )


@router.post("", response_model=APIKeyRevealResponse, status_code=status.HTTP_201_CREATED)
def create_api_key(
    request: APIKeyCreateRequest,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Create a new API key for the current user.
    
    **Important:** The secret key is only shown once. Store it securely!
    
    - **name**: A descriptive name for the API key (e.g., "CI/CD Pipeline")
    - **scopes**: List of allowed scopes (default: ["read"])
    - **expires_at**: Optional expiration datetime
    """
    api_key, full_secret = api_key_service.create_api_key(
        db,
        current_user.id,
        request.name,
        request.scopes,
        request.expires_at,
    )
    _audit_api_key_event("api_key_created", current_user.id, api_key.id, api_key.prefix, "success")
    
    return APIKeyRevealResponse(
        id=api_key.id,
        name=api_key.name,
        prefix=api_key.prefix,
        secret_key=full_secret,
        scopes=api_key.scopes,
        is_active=api_key.is_active,
        expires_at=api_key.expires_at,
        created_at=api_key.created_at,
    )


@router.get("", response_model=list[APIKeyResponse])
def list_api_keys(
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """List all API keys for the current user."""
    api_keys = api_key_service.get_user_api_keys(db, current_user.id)
    return api_keys


@router.get("/{key_id}", response_model=APIKeyResponse)
def get_api_key(
    key_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Get a specific API key by ID."""
    api_key = api_key_service.get_api_key_by_id(db, key_id)
    
    if not api_key:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found")
    
    # Check that the key belongs to the current user
    if api_key.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to access this API key")
    
    return api_key


@router.put("/{key_id}", response_model=APIKeyResponse)
def update_api_key(
    key_id: int,
    request: APIKeyUpdateRequest,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Update an API key."""
    existing_key = api_key_service.get_api_key_by_id(db, key_id)
    
    if not existing_key:
        _audit_api_key_event("api_key_revoked", current_user.id, key_id, None, "not_found")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found")
    
    # Check that the key belongs to the current user
    if existing_key.user_id != current_user.id:
        _audit_api_key_event("api_key_revoked", current_user.id, existing_key.id, existing_key.prefix, "forbidden")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to update this API key")
    
    api_key = api_key_service.update_api_key(
        db,
        key_id,
        request.name,
        request.scopes,
        request.expires_at,
    )
    
    return api_key


@router.delete("/{key_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_api_key(
    key_id: int,
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Delete/revoke an API key."""
    existing_key = api_key_service.get_api_key_by_id(db, key_id)
    
    if not existing_key:
        _audit_api_key_event("api_key_revoked", current_user.id, key_id, None, "not_found")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found")
    
    # Check that the key belongs to the current user
    if existing_key.user_id != current_user.id:
        _audit_api_key_event("api_key_revoked", current_user.id, existing_key.id, existing_key.prefix, "forbidden")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not authorized to delete this API key")
    
    api_key_service.revoke_api_key(db, key_id)
    _audit_api_key_event("api_key_revoked", current_user.id, existing_key.id, existing_key.prefix, "success")
    return None
