from __future__ import annotations

import json
import logging
import subprocess
import threading
from datetime import datetime, timezone
from pathlib import Path
import re

from app.config import settings

logger = logging.getLogger(__name__)
_export_lock = threading.Lock()


def export_generated_script(
    *,
    project_name: str,
    test_case_title: str,
    script_id: int,
    framework: str,
    llm_provider: str,
    llm_model: str,
    script_content: str,
) -> str | None:
    if not settings.AUTO_EXPORT_GIT_ENABLED:
        return None
    if not settings.AUTO_EXPORT_GIT_REPO_URL.strip():
        logger.warning("Automatic git export is enabled but AUTO_EXPORT_GIT_REPO_URL is empty.")
        return None

    with _export_lock:
        repo_dir = _prepare_repo_checkout()
        relative_script_path = _build_relative_script_path(project_name, test_case_title, script_id)
        absolute_script_path = repo_dir / relative_script_path
        absolute_script_path.parent.mkdir(parents=True, exist_ok=True)
        absolute_script_path.write_text(script_content, encoding="utf-8")

        metadata_path = absolute_script_path.with_suffix(".json")
        metadata = {
            "script_id": script_id,
            "project_name": project_name,
            "test_case_title": test_case_title,
            "framework": framework,
            "llm_provider": llm_provider,
            "llm_model": llm_model,
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "script_path": relative_script_path.as_posix(),
        }
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")

        _git_run(["add", relative_script_path.as_posix(), metadata_path.relative_to(repo_dir).as_posix()], cwd=repo_dir)
        if not _repo_has_changes(repo_dir):
            return relative_script_path.as_posix()

        commit_title = f"Add generated script {script_id} for {_slugify(test_case_title)}"
        commit_body = (
            f"Project: {project_name}\n"
            f"Test case: {test_case_title}\n"
            f"Framework: {framework}\n"
            f"Provider: {llm_provider}\n"
            f"Model: {llm_model or 'runtime default'}"
        )
        _git_run(
            [
                "-c",
                f"user.name={settings.AUTO_EXPORT_GIT_USER_NAME}",
                "-c",
                f"user.email={settings.AUTO_EXPORT_GIT_USER_EMAIL}",
                "commit",
                "-m",
                commit_title,
                "-m",
                commit_body,
            ],
            cwd=repo_dir,
        )
        _git_run(["push", "origin", settings.AUTO_EXPORT_GIT_BRANCH], cwd=repo_dir)
        logger.info(
            "Exported generated script to sandbox repo: path=%s branch=%s",
            relative_script_path.as_posix(),
            settings.AUTO_EXPORT_GIT_BRANCH,
        )
        return relative_script_path.as_posix()


def _prepare_repo_checkout() -> Path:
    repo_dir = Path(settings.AUTO_EXPORT_GIT_LOCAL_PATH).expanduser().resolve()
    repo_dir.parent.mkdir(parents=True, exist_ok=True)

    if not (repo_dir / ".git").exists():
        _git_run(
            [
                "clone",
                "--branch",
                settings.AUTO_EXPORT_GIT_BRANCH,
                "--single-branch",
                settings.AUTO_EXPORT_GIT_REPO_URL,
                str(repo_dir),
            ],
            cwd=repo_dir.parent,
        )
        return repo_dir

    _git_run(["remote", "set-url", "origin", settings.AUTO_EXPORT_GIT_REPO_URL], cwd=repo_dir)
    _git_run(["fetch", "origin", settings.AUTO_EXPORT_GIT_BRANCH], cwd=repo_dir)
    _git_run(["checkout", settings.AUTO_EXPORT_GIT_BRANCH], cwd=repo_dir)
    _git_run(["pull", "--ff-only", "origin", settings.AUTO_EXPORT_GIT_BRANCH], cwd=repo_dir)
    return repo_dir


def _build_relative_script_path(project_name: str, test_case_title: str, script_id: int) -> Path:
    return Path("generated-scripts") / _slugify(project_name) / f"{_slugify(test_case_title)}-{script_id}.py"


def _repo_has_changes(repo_dir: Path) -> bool:
    result = _git_run(["status", "--short"], cwd=repo_dir)
    return bool(result.stdout.strip())


def _git_run(args: list[str], *, cwd: Path) -> subprocess.CompletedProcess[str]:
    command = ["git", *args]
    result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or f"git command failed: {' '.join(command)}")
    return result


def _slugify(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower())
    collapsed = re.sub(r"-+", "-", normalized).strip("-")
    return collapsed or "untitled"