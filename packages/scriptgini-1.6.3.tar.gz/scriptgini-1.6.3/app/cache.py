"""
Redis cache utilities for storing frequently accessed data.

Usage:
    from app.cache import cache
    
    # Store value
    cache.set("key", "value", ttl=3600)
    
    # Get value
    value = cache.get("key")
    
    # Delete value
    cache.delete("key")
    
    # Use as decorator
    @cache.cached(ttl=300)
    def expensive_operation():
        return result
"""

import json
import redis
from typing import Any, Optional, Callable
from functools import wraps
from app.config import settings
import logging

logger = logging.getLogger(__name__)


class RedisCache:
    def __init__(self, redis_url: str):
        """Initialize Redis connection."""
        try:
            self.redis_client = redis.from_url(redis_url, decode_responses=True)
            # Test connection
            self.redis_client.ping()
            logger.info("Redis cache connected successfully")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
            self.redis_client = None

    def is_available(self) -> bool:
        """Check if Redis is available."""
        return self.redis_client is not None

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """
        Store a value in cache.
        
        Args:
            key: Cache key
            value: Value to store (will be JSON serialized if not string)
            ttl: Time to live in seconds (default: configured TTL)
        
        Returns:
            True if successful, False otherwise
        """
        if not self.is_available():
            return False

        try:
            ttl = ttl or settings.REDIS_CACHE_TTL_SECONDS
            
            if isinstance(value, str):
                self.redis_client.setex(key, ttl, value)
            else:
                self.redis_client.setex(key, ttl, json.dumps(value))
            
            return True
        except Exception as e:
            logger.error(f"Error setting cache key {key}: {e}")
            return False

    def get(self, key: str, default: Any = None) -> Any:
        """
        Retrieve a value from cache.
        
        Args:
            key: Cache key
            default: Default value if key not found or error
        
        Returns:
            Cached value or default
        """
        if not self.is_available():
            return default

        try:
            value = self.redis_client.get(key)
            if value is None:
                return default
            
            # Try to parse as JSON
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        except Exception as e:
            logger.error(f"Error getting cache key {key}: {e}")
            return default

    def delete(self, key: str) -> bool:
        """
        Delete a value from cache.
        
        Args:
            key: Cache key
        
        Returns:
            True if key was deleted, False otherwise
        """
        if not self.is_available():
            return False

        try:
            return bool(self.redis_client.delete(key))
        except Exception as e:
            logger.error(f"Error deleting cache key {key}: {e}")
            return False

    def clear_pattern(self, pattern: str) -> int:
        """
        Delete all keys matching a pattern.
        
        Args:
            pattern: Key pattern (e.g., "user:*", "script:123:*")
        
        Returns:
            Number of keys deleted
        """
        if not self.is_available():
            return 0

        try:
            keys = self.redis_client.keys(pattern)
            if keys:
                return self.redis_client.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Error clearing cache pattern {pattern}: {e}")
            return 0

    def cached(self, ttl: Optional[int] = None):
        """
        Decorator to cache function results.
        
        Usage:
            @cache.cached(ttl=300)
            def expensive_function(arg1, arg2):
                return result
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Generate cache key from function name and arguments
                cache_key = f"{func.__module__}:{func.__name__}:{args}:{kwargs}"
                cache_key = cache_key.replace(" ", "")  # Remove spaces
                
                # Try to get from cache
                cached_value = self.get(cache_key)
                if cached_value is not None:
                    logger.debug(f"Cache hit for {cache_key}")
                    return cached_value
                
                # Call function and cache result
                result = func(*args, **kwargs)
                self.set(cache_key, result, ttl=ttl)
                return result
            
            return wrapper
        return decorator

    def increment(self, key: str, amount: int = 1) -> Optional[int]:
        """Increment a counter."""
        if not self.is_available():
            return None
        
        try:
            return self.redis_client.incrby(key, amount)
        except Exception as e:
            logger.error(f"Error incrementing {key}: {e}")
            return None

    def get_ttl(self, key: str) -> Optional[int]:
        """Get remaining TTL in seconds (-1 if no expiry, -2 if doesn't exist)."""
        if not self.is_available():
            return None
        
        try:
            return self.redis_client.ttl(key)
        except Exception as e:
            logger.error(f"Error getting TTL for {key}: {e}")
            return None


# Initialize cache instance
cache = RedisCache(settings.REDIS_URL)
