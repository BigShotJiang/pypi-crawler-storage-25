# sigmorphon-vp

`sigmorphon-vp` contains dataset tools for morphological reinflection experiments.

It provides:

- dataset discovery and download helpers
- TSV parsing and merging
- typed `MorphDataset`, `MorphRow`, and batch utilities
- integration with `chartoken-vp`

Install:

```bash
pip install sigmorphon-vp
```
