"""Undisk MCP client — typed Python SDK for undo-first versioned file storage."""

from __future__ import annotations

import asyncio
import json
from typing import Any

import httpx

from ._version import __version__

# HTTP status codes that are safe to retry
_RETRIABLE_STATUS_CODES = frozenset({429, 500, 502, 503, 504})


class UndiskError(Exception):
    """Error returned by the Undisk MCP server."""

    def __init__(self, code: int, message: str, data: Any = None):
        super().__init__(message)
        self.code = code
        self.data = data

    def __repr__(self) -> str:
        return f"UndiskError(code={self.code}, message={str(self)!r})"


class McpToolResult:
    """Result from an MCP tool call."""

    def __init__(self, content: list[dict[str, Any]], is_error: bool = False):
        self.content = content
        self.is_error = is_error

    @property
    def text(self) -> str:
        """Extract text content from the result."""
        texts = [c.get("text", "") for c in self.content if c.get("type") == "text"]
        return "\n".join(texts)

    def __repr__(self) -> str:
        return f"McpToolResult(is_error={self.is_error}, text={self.text[:100]!r})"


class UndiskClient:
    """Typed async client for the Undisk MCP server.

    Usage::

        async with UndiskClient(api_key="your-key") as client:
            await client.initialize()
            result = await client.call_tool("list_files", {})
            print(result.text)
    """

    def __init__(
        self,
        api_key: str,
        endpoint: str = "https://mcp.undisk.app",
        *,
        max_retries: int = 3,
        retry_base_ms: int = 100,
        timeout: float = 60.0,
    ):
        self.endpoint = endpoint.rstrip("/")
        self.api_key = api_key
        self.max_retries = max_retries
        self.retry_base_ms = retry_base_ms
        self._session_id: str | None = None
        self._next_id = 1
        self._client = httpx.AsyncClient(
            base_url=f"{self.endpoint}/mcp",
            timeout=timeout,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
        )

    async def initialize(self) -> dict[str, Any]:
        """Initialize the MCP session."""
        result = await self._send_rpc("initialize", {
            "protocolVersion": "2025-03-26",
            "capabilities": {},
            "clientInfo": {"name": "undisk-mcp-python", "version": __version__},
        })
        await self._send_notification("notifications/initialized", {})
        return result

    async def list_tools(self) -> list[dict[str, Any]]:
        """List available tools from the server."""
        result = await self._send_rpc("tools/list", {})
        return result.get("tools", [])

    async def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> McpToolResult:
        """Call an MCP tool by name."""
        result = await self._send_rpc("tools/call", {
            "name": name,
            "arguments": arguments or {},
        })
        return McpToolResult(
            content=result.get("content", []),
            is_error=result.get("isError", False),
        )

    # ── Convenience methods for common tools ──

    async def read_file(self, path: str, **kwargs: Any) -> McpToolResult:
        """Read a file's content and metadata."""
        return await self.call_tool("read_file", {"path": path, **kwargs})

    async def write_file(self, path: str, content: str, **kwargs: Any) -> McpToolResult:
        """Write content to a file (creates an immutable version)."""
        return await self.call_tool("write_file", {"path": path, "content": content, **kwargs})

    async def create_file(self, path: str, content: str, **kwargs: Any) -> McpToolResult:
        """Create a new file (fails if path already exists)."""
        return await self.call_tool("create_file", {"path": path, "content": content, **kwargs})

    async def list_files(self, path: str = "/", **kwargs: Any) -> McpToolResult:
        """List files and directories in the workspace."""
        return await self.call_tool("list_files", {"path": path, **kwargs})

    async def delete_file(self, path: str, **kwargs: Any) -> McpToolResult:
        """Soft-delete a file or directory."""
        return await self.call_tool("delete_file", {"path": path, **kwargs})

    async def move_file(self, from_path: str, to_path: str, **kwargs: Any) -> McpToolResult:
        """Move or rename a file or directory."""
        return await self.call_tool("move_file", {"from_path": from_path, "to_path": to_path, **kwargs})

    async def search_files(self, pattern: str, **kwargs: Any) -> McpToolResult:
        """Search across all file contents in the workspace."""
        return await self.call_tool("search_files", {"pattern": pattern, **kwargs})

    async def list_versions(self, path: str, **kwargs: Any) -> McpToolResult:
        """Get the complete version history for a file."""
        return await self.call_tool("list_versions", {"path": path, **kwargs})

    async def restore_version(self, path: str, version_id: str, **kwargs: Any) -> McpToolResult:
        """Restore a file to a prior version."""
        return await self.call_tool("restore_version", {"path": path, "version_id": version_id, **kwargs})

    async def get_diff(self, path: str, from_version: str, to_version: str, **kwargs: Any) -> McpToolResult:
        """Compare two versions of a file."""
        return await self.call_tool("get_diff", {
            "path": path, "from_version": from_version, "to_version": to_version, **kwargs,
        })

    async def append_log(self, path: str, content: str, **kwargs: Any) -> McpToolResult:
        """Append log entries to a file."""
        return await self.call_tool("append_log", {"path": path, "content": content, **kwargs})

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> UndiskClient:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ── Private methods ──

    def _is_retriable(self, exc: Exception) -> bool:
        """Return True if the request should be retried for this exception."""
        if isinstance(exc, httpx.HTTPStatusError):
            return exc.response.status_code in _RETRIABLE_STATUS_CODES
        # Network errors and timeouts are always retriable
        return isinstance(exc, (httpx.ConnectError, httpx.TimeoutException))

    async def _send_rpc(self, method: str, params: dict[str, Any]) -> Any:
        req_id = self._next_id
        self._next_id += 1
        body = {"jsonrpc": "2.0", "id": req_id, "method": method, "params": params}
        response = await self._http_post(body)

        if not isinstance(response, dict):
            raise UndiskError(-32600, f"Invalid JSON-RPC response: expected object, got {type(response).__name__}")

        if "error" in response:
            err = response["error"]
            raise UndiskError(err.get("code", -1), err.get("message", "Unknown error"), err.get("data"))

        if "result" not in response:
            raise UndiskError(-32600, "Invalid JSON-RPC response: missing 'result' field")

        return response["result"]

    async def _send_notification(self, method: str, params: dict[str, Any]) -> None:
        body = {"jsonrpc": "2.0", "method": method, "params": params}
        await self._http_post(body, is_notification=True)

    async def _http_post(self, body: dict[str, Any], is_notification: bool = False) -> Any:
        headers: dict[str, str] = {}
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id

        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                response = await self._client.post("", json=body, headers=headers)
                sid = response.headers.get("Mcp-Session-Id")
                if sid:
                    self._session_id = sid

                if response.status_code >= 400:
                    raise httpx.HTTPStatusError(
                        f"HTTP {response.status_code}: {response.text[:200]}",
                        request=response.request,
                        response=response,
                    )

                if is_notification:
                    return {}

                try:
                    return response.json()
                except json.JSONDecodeError as exc:
                    raise UndiskError(-32700, f"Server returned invalid JSON: {response.text[:200]}") from exc

            except Exception as exc:
                last_exc = exc
                if attempt >= self.max_retries or not self._is_retriable(exc):
                    raise
                delay = self.retry_base_ms * (2 ** attempt) / 1000
                await asyncio.sleep(delay)

        raise last_exc  # pragma: no cover
