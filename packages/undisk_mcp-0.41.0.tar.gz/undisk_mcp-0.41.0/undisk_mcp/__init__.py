"""Undisk MCP — Python SDK for undo-first versioned file storage for AI agents."""

from ._version import __version__
from .client import McpToolResult, UndiskClient, UndiskError

__all__ = ["UndiskClient", "UndiskError", "McpToolResult", "__version__"]  # noqa: F822
