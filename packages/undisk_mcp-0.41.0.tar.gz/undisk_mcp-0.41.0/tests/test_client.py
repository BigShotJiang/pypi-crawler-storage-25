"""Tests for the Undisk MCP Python client."""

from __future__ import annotations

import json

import httpx
import pytest
import pytest_asyncio
import respx

from undisk_mcp import McpToolResult, UndiskClient, UndiskError, __version__


# ── Sync unit tests ──


def test_version():
    assert __version__ == "0.1.0"


def test_client_init():
    client = UndiskClient(api_key="test-key")
    assert client.endpoint == "https://mcp.undisk.app"
    assert client.api_key == "test-key"
    assert client.max_retries == 3


def test_client_custom_endpoint():
    client = UndiskClient(api_key="test-key", endpoint="https://custom.example.com/")
    assert client.endpoint == "https://custom.example.com"


def test_client_custom_options():
    client = UndiskClient(
        api_key="test-key",
        max_retries=5,
        retry_base_ms=200,
        timeout=30.0,
    )
    assert client.max_retries == 5
    assert client.retry_base_ms == 200


def test_error():
    err = UndiskError(code=-32600, message="Invalid request")
    assert err.code == -32600
    assert str(err) == "Invalid request"
    assert err.data is None


def test_error_with_data():
    err = UndiskError(code=-32600, message="Bad", data={"detail": "missing field"})
    assert err.data == {"detail": "missing field"}


def test_error_repr():
    err = UndiskError(code=-32600, message="Invalid request")
    assert "UndiskError" in repr(err)
    assert "-32600" in repr(err)


def test_tool_result_text():
    result = McpToolResult(
        content=[
            {"type": "text", "text": "hello"},
            {"type": "text", "text": "world"},
        ],
    )
    assert result.text == "hello\nworld"
    assert result.is_error is False


def test_tool_result_empty():
    result = McpToolResult(content=[])
    assert result.text == ""


def test_tool_result_non_text_content():
    """Non-text content items should be skipped by .text."""
    result = McpToolResult(content=[
        {"type": "image", "url": "https://example.com/img.png"},
        {"type": "text", "text": "caption"},
    ])
    assert result.text == "caption"


def test_tool_result_is_error():
    result = McpToolResult(content=[{"type": "text", "text": "oops"}], is_error=True)
    assert result.is_error is True
    assert "oops" in result.text


def test_tool_result_repr():
    result = McpToolResult(content=[{"type": "text", "text": "test"}])
    r = repr(result)
    assert "McpToolResult" in r
    assert "is_error=False" in r


# ── Async tests ──


def _jsonrpc_ok(result: dict, req_id: int = 1) -> httpx.Response:
    """Build a mock JSON-RPC success response."""
    return httpx.Response(200, json={"jsonrpc": "2.0", "id": req_id, "result": result})


def _jsonrpc_error(code: int, message: str, req_id: int = 1) -> httpx.Response:
    return httpx.Response(200, json={"jsonrpc": "2.0", "id": req_id, "error": {"code": code, "message": message}})


@pytest.mark.asyncio
async def test_context_manager_closes_client():
    """async with UndiskClient should close the httpx client on exit."""
    async with UndiskClient(api_key="k") as client:
        assert not client._client.is_closed
    assert client._client.is_closed


@pytest.mark.asyncio
@respx.mock
async def test_initialize_sends_rpc():
    route = respx.post("https://mcp.undisk.app/mcp/").mock(
        return_value=_jsonrpc_ok({
            "protocolVersion": "2025-03-26",
            "capabilities": {},
            "serverInfo": {"name": "undisk"},
        })
    )
    async with UndiskClient(api_key="k") as client:
        result = await client.initialize()
    assert result["protocolVersion"] == "2025-03-26"
    assert route.call_count == 2  # initialize + initialized notification


@pytest.mark.asyncio
@respx.mock
async def test_call_tool_returns_result():
    respx.post("https://mcp.undisk.app/mcp/").mock(
        return_value=_jsonrpc_ok({
            "content": [{"type": "text", "text": "hello"}],
            "isError": False,
        })
    )
    async with UndiskClient(api_key="k") as client:
        result = await client.call_tool("read_file", {"path": "a.txt"})
    assert result.text == "hello"
    assert result.is_error is False


@pytest.mark.asyncio
@respx.mock
async def test_jsonrpc_error_raises():
    respx.post("https://mcp.undisk.app/mcp/").mock(
        return_value=_jsonrpc_error(-32600, "Invalid request")
    )
    async with UndiskClient(api_key="k") as client:
        with pytest.raises(UndiskError, match="Invalid request") as exc_info:
            await client.call_tool("bad", {})
        assert exc_info.value.code == -32600


@pytest.mark.asyncio
@respx.mock
async def test_session_id_tracked():
    """Session ID from response header should be sent in subsequent requests."""
    respx.post("https://mcp.undisk.app/mcp/").mock(
        return_value=httpx.Response(
            200,
            json={"jsonrpc": "2.0", "id": 1, "result": {}},
            headers={"Mcp-Session-Id": "sess-123"},
        )
    )
    async with UndiskClient(api_key="k") as client:
        await client.call_tool("list_files", {})
        assert client._session_id == "sess-123"


@pytest.mark.asyncio
@respx.mock
async def test_http_4xx_not_retried():
    """4xx errors (except 429) should not be retried."""
    route = respx.post("https://mcp.undisk.app/mcp/").mock(
        return_value=httpx.Response(401, text="Unauthorized")
    )
    async with UndiskClient(api_key="k", max_retries=3) as client:
        with pytest.raises(httpx.HTTPStatusError):
            await client.call_tool("read_file", {"path": "x"})
    assert route.call_count == 1  # no retries for 401


@pytest.mark.asyncio
@respx.mock
async def test_http_429_retried():
    """429 Too Many Requests should be retried."""
    call_count = 0

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            return httpx.Response(429, text="Rate limited")
        return _jsonrpc_ok({"content": [], "isError": False})

    respx.post("https://mcp.undisk.app/mcp/").mock(side_effect=side_effect)
    async with UndiskClient(api_key="k", max_retries=3, retry_base_ms=1) as client:
        result = await client.call_tool("list_files", {})
    assert call_count == 3
    assert result.is_error is False


@pytest.mark.asyncio
@respx.mock
async def test_http_500_retried():
    """5xx errors should be retried."""
    call_count = 0

    def side_effect(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(500, text="Internal Server Error")
        return _jsonrpc_ok({"content": [{"type": "text", "text": "ok"}], "isError": False})

    respx.post("https://mcp.undisk.app/mcp/").mock(side_effect=side_effect)
    async with UndiskClient(api_key="k", max_retries=2, retry_base_ms=1) as client:
        result = await client.call_tool("list_files", {})
    assert call_count == 2
    assert result.text == "ok"


@pytest.mark.asyncio
@respx.mock
async def test_malformed_json_raises():
    """Non-JSON 200 responses should raise UndiskError."""
    respx.post("https://mcp.undisk.app/mcp/").mock(
        return_value=httpx.Response(200, text="not json")
    )
    async with UndiskClient(api_key="k") as client:
        with pytest.raises(UndiskError, match="invalid JSON"):
            await client.call_tool("list_files", {})


@pytest.mark.asyncio
@respx.mock
async def test_missing_result_field_raises():
    """JSON-RPC response without 'result' or 'error' should raise."""
    respx.post("https://mcp.undisk.app/mcp/").mock(
        return_value=httpx.Response(200, json={"jsonrpc": "2.0", "id": 1})
    )
    async with UndiskClient(api_key="k") as client:
        with pytest.raises(UndiskError, match="missing 'result'"):
            await client.call_tool("list_files", {})


@pytest.mark.asyncio
@respx.mock
async def test_convenience_write_file():
    respx.post("https://mcp.undisk.app/mcp/").mock(
        return_value=_jsonrpc_ok({"content": [{"type": "text", "text": "written"}], "isError": False})
    )
    async with UndiskClient(api_key="k") as client:
        result = await client.write_file("test.txt", "hello")
    assert result.text == "written"
