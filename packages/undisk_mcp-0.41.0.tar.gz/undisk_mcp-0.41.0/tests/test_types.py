"""Tests for auto-generated type definitions."""

from undisk_mcp.types import UndiskToolName


def test_tool_name_literal_contains_core_tools():
    """Verify the tool name literal includes known tools."""
    # UndiskToolName is a Literal type — we can check its args
    import typing
    args = typing.get_args(UndiskToolName)
    assert "read_file" in args
    assert "write_file" in args
    assert "list_files" in args
    assert "delete_file" in args
    assert "search_files" in args
    assert "restore_version" in args
    assert len(args) == 24


def test_typed_dict_classes_importable():
    """Verify TypedDict classes can be imported."""
    from undisk_mcp.types import (
        ReadFileInput,
        WriteFileInput,
        ListFilesInput,
        DeleteFileInput,
        SearchFilesInput,
        RestoreVersionInput,
    )
    # TypedDicts are types, not instances
    assert ReadFileInput is not None
    assert WriteFileInput is not None
