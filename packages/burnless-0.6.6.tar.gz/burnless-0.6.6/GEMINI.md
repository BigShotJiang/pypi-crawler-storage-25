# Gemini Instructions

Read `AGENTS.md` first.

Key points for this repository:

- `BURNLESS_FOR_LLMS.md` is a public root document and should remain in the
  repository root.
- Do not create temporary analysis files in the root directory.
- Put private notes, scratch output, logs, and generated agent state under
  `.burnless/`, `scratch/`, or another ignored location.
- Before suggesting a commit or release, run `scripts/public_git_check.sh`.
- Use Burnless vocabulary precisely: semantic capsule, compressed state
  representation, dense semantic summary, privacy-by-architecture.

