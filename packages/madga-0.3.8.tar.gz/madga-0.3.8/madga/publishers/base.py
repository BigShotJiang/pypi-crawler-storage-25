"""Publisher base class + registry."""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from madga.models import BroadcastJob, PublisherAccount, Site


@dataclass
class CredField:
    """Declarative credential field a Publisher requires.

    Drives the Channels page "Connect" form: each entry renders a
    labelled input (text by default, password when ``secret=True``).
    Used only for publishers that don't have a real OAuth flow yet —
    a developer pastes the token they got from the platform's
    developer console.
    """

    name: str
    label: str
    secret: bool = False
    placeholder: str = ""
    help_text: str = ""


@dataclass
class PublishResult:
    """Return value of ``Publisher.publish``.

    The worker collects this and writes the counts onto the BroadcastJob.
    Each error in ``errors`` is a dict like ``{"target": "<id>", "msg": "..."}``.
    """

    sent: int = 0
    failed: int = 0
    errors: list = field(default_factory=list)


class Publisher:
    """A destination MADGA can broadcast to.

    Subclass + register via ``@register_publisher`` to wire a new one.
    Subclasses must declare ``key``, ``label``, and override
    ``publish(job)``.

    Two flavors of publisher coexist:

    1. **Settings-driven** (legacy / dev): ``is_configured()`` returns
       True iff some env var is set. One global account per
       deployment. The built-in ``email_subscribers`` works this way.
    2. **Account-driven** (multi-tenant): ``credential_fields`` is
       non-empty, ``is_configured(site)`` returns True iff there's an
       active ``PublisherAccount`` for that Site. Each Site gets its
       own credentials, paused independently. This is the SaaS path
       (LinkedIn, X, Mastodon, Bluesky, etc.).
    """

    key: str = ""
    label: str = ""
    description: str = ""
    icon: str = ""  # studio icon name from madga_studio_tags

    # If non-empty, the publisher is treated as account-driven: the
    # Channels page renders a Connect form using these fields, and a
    # PublisherAccount must exist for a Site before is_configured(site)
    # returns True.
    credential_fields: list[CredField] = []

    # Character limit per post (for the per-channel composer's counter).
    # None = no client-side limit.
    char_limit: int | None = None

    # Whether ``publish(job)`` accepts a per-account split or always
    # publishes globally. Account-driven publishers default to True.
    multi_account: bool = False

    # OAuth 2.0 support. When True, the studio Connect button on the
    # Channels page redirects to ``oauth_authorize_url(...)`` instead
    # of rendering the manual credential form. Subclasses must
    # implement ``oauth_authorize_url`` and ``oauth_exchange`` and
    # declare their scopes/credentials.
    oauth_supported: bool = False
    oauth_scopes: list[str] = []

    # Step-by-step setup instructions surfaced in the studio's
    # "Needs setup" help drawer. Each step is a dict with:
    #   {"title": str, "body": str (markdown-light), "url": str | ""}
    # The studio renders them in order with copy-paste-friendly chunks.
    setup_instructions: list[dict] = []

    # Where to send the operator after they create their app — usually
    # the platform's developer console URL.
    setup_console_url: str = ""

    @property
    def has_handle_credential(self) -> bool:
        """True if 'handle' is part of ``credential_fields``.

        Used by the studio Connect form to avoid rendering a duplicate
        Handle input when the publisher's auth already includes one
        (Bluesky's app-password flow needs the handle as part of the
        credentials, not just as a display label).
        """
        return any(f.name == "handle" for f in self.credential_fields)

    # ---- OAuth contract (subclasses implement) -------------------------

    def oauth_client_credentials(self) -> tuple[str, str] | None:
        """Read ``(client_id, client_secret)`` from project settings.

        Convention: settings.MADGA_OAUTH = {"twitter": {"client_id":..., "client_secret":...}, ...}
        Returns None if not configured — caller renders a clear error.
        """
        from django.conf import settings
        conf = getattr(settings, "MADGA_OAUTH", {}) or {}
        creds = conf.get(self.key) or {}
        cid = creds.get("client_id")
        secret = creds.get("client_secret", "")
        if not cid:
            return None
        return cid, secret

    def oauth_authorize_url(self, redirect_uri: str, state: str, pkce_verifier: str) -> str:
        """Build the platform's OAuth consent URL.

        ``pkce_verifier`` is the high-entropy random string we'll send
        in the token exchange step; the URL needs its SHA-256 challenge.
        """
        raise NotImplementedError

    def oauth_exchange(self, code: str, redirect_uri: str, pkce_verifier: str) -> dict:
        """Exchange auth code for tokens.

        Return a dict with at minimum:
          {"credentials": {...}, "handle": "...", "display_name": "..."}
        The ``credentials`` dict is what gets stored via
        ``PublisherAccount.set_credentials``.
        """
        raise NotImplementedError

    def is_configured(self, site: "Site | None" = None) -> bool:
        """Return True if this publisher can actually run.

        Account-driven publishers (credential_fields OR oauth_supported)
        require at least one active ``PublisherAccount`` for the given
        Site. Settings-driven publishers ignore the site argument and
        check globals.
        """
        if self.credential_fields or self.oauth_supported:
            if site is None:
                return False
            from madga.models import PublisherAccount
            return PublisherAccount.objects.filter(
                site=site, publisher_key=self.key, is_active=True,
            ).exists()
        return True

    def estimate_targets(self, job: "BroadcastJob") -> int:
        """Return how many recipients ``publish(job)`` would attempt.

        Used by the studio drawer for the recipient count preview.
        """
        return 0

    def default_copy(self, job: "BroadcastJob") -> str:
        """Return the auto-generated text for this channel.

        Override to tweak per platform (e.g., X may want hashtags,
        LinkedIn longer body). Default: subject + url, truncated to
        ``char_limit``.
        """
        body = (job.subject or "").strip()
        url = (job.related_url or "").strip()
        text = f"{body}\n\n{url}".strip() if url else body
        if self.char_limit and len(text) > self.char_limit:
            # Keep room for the URL on the last line if present.
            ellipsis_sep = "…\n\n"  # 3 chars: "…" + "\n\n"
            if url and len(url) + len(ellipsis_sep) < self.char_limit:
                budget = self.char_limit - len(url) - len(ellipsis_sep)
                text = body[:budget].rstrip() + ellipsis_sep + url
            else:
                text = text[: self.char_limit - 1].rstrip() + "…"
        return text

    def publish(self, job: "BroadcastJob") -> PublishResult:
        """Actually send the broadcast. Must be implemented by subclasses."""
        raise NotImplementedError

    def test_connection(self, account: "PublisherAccount") -> tuple[bool, str]:
        """Verify a connected account's credentials work.

        Return ``(ok, message)`` — ``ok=True`` on a happy round-trip,
        ``ok=False`` with an actionable error message otherwise. Used
        by the studio's "Test connection" button on each channel card.

        Default for stub publishers: ensure required credential fields
        are present in the stored blob. Real publishers should override
        to hit the platform's "verify token" / "get account" endpoint.
        """
        creds = account.get_credentials()
        missing = [f.name for f in self.credential_fields if not creds.get(f.name)]
        if missing:
            return False, f"Missing credential fields: {', '.join(missing)}"
        return True, (
            f"Credentials look complete ({len(creds)} fields stored). "
            f"Real API verification lands in 0.3.5."
        )


_REGISTRY: dict[str, Publisher] = {}


def register_publisher(cls):
    """Decorator: register a Publisher subclass by its ``key``."""
    if not getattr(cls, "key", None):
        raise ValueError(f"{cls.__name__} must declare a non-empty `key` attribute.")
    instance = cls()
    _REGISTRY[cls.key] = instance
    return cls


def get_publisher(key: str) -> Publisher | None:
    return _REGISTRY.get(key)


def all_publishers(
    only_configured: bool = False,
    site: "Site | None" = None,
) -> list[Publisher]:
    """Return all registered publishers. Sorted by label for stable UI.

    Pass ``site`` together with ``only_configured=True`` to filter by
    *that Site's* connected accounts (the account-driven SaaS path).
    Otherwise account-driven publishers will be filtered out as
    "unconfigured" even when accounts exist for some other site.
    """
    items = list(_REGISTRY.values())
    if only_configured:
        items = [p for p in items if p.is_configured(site)]
    items.sort(key=lambda p: str(p.label or p.key))
    return items
