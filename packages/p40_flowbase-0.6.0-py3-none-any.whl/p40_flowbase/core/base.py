"""
MIT License

Copyright (c) 2025 Anton Tarasenko

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import asyncio
import pathlib
import shutil
import time
from abc import (
    ABC,
    abstractmethod,
)
from collections.abc import Sequence
from dataclasses import dataclass
from enum import (
    Enum,
    StrEnum,
)
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
)

from p40_flowbase.helpers.file_stats import (
    count_files,
    file_or_dir_size_bytes,
)
from p40_flowbase.logging import (
    logger,
    object_log_context,
)

if TYPE_CHECKING:
    from p40_flowbase.checks import BaseCheck


@dataclass(frozen=True)
class DataObjectVersion:
    """Version metadata for data objects.

    :ivar id: Short identifier for the version (e.g., "main", "v1", "test").
    :vartype id: str
    :ivar name: Human-readable name for the version.
    :vartype name: str
    :ivar description: Detailed description of what this version contains.
    :vartype description: str
    """

    id: str
    name: str
    description: str


def resolve_anchor_package(obj: "DataObject") -> str:
    """Return the anchor Python package for resource lookup.

    Honors a ``template_package`` ClassVar on the subclass when set;
    otherwise falls back to the top-level package of the subclass
    module (e.g. ``their_pkg`` for ``their_pkg.objects.foo.MyTable``).
    Used by both ``Table.make_via_sql_template`` and
    ``Document._render_template`` to anchor ``importlib.resources``
    lookups.
    """
    cls = type(obj)
    pkg: str | None = getattr(cls, "template_package", None)
    if pkg is not None:
        return pkg
    return cls.__module__.split(".")[0]


def format_summary(phase: str, kvs: dict[str, Any]) -> str:
    """Render a one-line summary in the project's pipe-`k=v` style.

    `path=...` is moved last (it's the longest field; trailing it keeps
    the head readable). Other key order is preserved as inserted.
    """
    path = kvs.pop("path", None)
    body = " ".join(f"{k}={v}" for k, v in kvs.items())
    if path is not None:
        body = f"{body} path={path}" if body else f"path={path}"
    return f"{phase}_summary | {body}"


class DataObject(ABC):
    """Base class for all data objects.

    Subclasses must define:
        - id: Unique identifier for the data object type.
        - description: Human-readable description.
        - make_format: Default format enum for the make() method.
        - supported_versions: Tuple of version enums.
        - _make(): Method to create the object in default format.

    Lifecycle logging
    -----------------
    Every ``make()`` / ``convert()`` / ``delete()`` call:

    1. Opens an ``object_log_context``: a per-object FileHandler at
       ``<local_dir>/<object_stem>.meta.log`` (append mode), filtered to
       only this object's records via a ``ContextVar``. Concurrent
       ``make()`` calls do not bleed into each other's files.
    2. Writes a single-line ``<phase>_summary | k=v ... path=<abs>``
       summary at the end. Subclasses contribute fields by overriding
       ``_make_summary`` / ``_convert_summary`` / ``_delete_summary``.
    3. On failure: logs the traceback via ``logger.exception(...)``
       (so it lands in the per-object log) and re-raises.
    """

    id: ClassVar[str]
    description: ClassVar[str]
    make_format: ClassVar[StrEnum]
    supported_versions: ClassVar[tuple[Enum, ...]] = ()
    #: Post-make checks; iterated by ``make`` / ``amake`` after the
    #: ``make_summary`` log line. See ``p40_flowbase.checks`` for built-ins.
    checks: ClassVar[tuple["BaseCheck", ...]] = ()
    version: Enum

    # Must be set by project config
    _local_data: ClassVar[str | None] = None

    def __init__(self, version: Enum):
        """Initialize a data object with a specific version.

        :param version: Version enum member from ``supported_versions``.
        :type version: Enum
        :raises ValueError: If ``version`` is not in ``supported_versions``.
        """
        if version not in self.supported_versions:
            raise ValueError(
                f"Version {version} not in supported_versions for {self.__class__.__name__}. "
                f"Supported versions: {[v.value.id for v in self.supported_versions]}"
            )
        self.version = version

    @classmethod
    def set_local_data(cls, path: str) -> None:
        """Set the base directory for data storage.

        Must be called before using any ``DataObject`` subclass.

        :param path: Directory where data objects will be stored.
        :type path: str
        """
        cls._local_data = path

    @property
    def local_data(self) -> str:
        """Return the base directory for data storage.

        :returns: Configured local data root.
        :rtype: str
        :raises RuntimeError: If ``local_data`` has not been set.
        """
        if self._local_data is None:
            raise RuntimeError(
                "local_data has not been set. "
                "Call DataObject.set_local_data(path) or set it via config."
            )
        return self._local_data

    @property
    def object_stem(self) -> str:
        """Return the object stem (id-version)."""
        return f"{self.id}-{self.version.value.id}"

    @property
    def local_dir(self) -> pathlib.Path:
        """Return the local directory path."""
        return pathlib.Path(self.local_data) / self.object_stem

    def path_to_format(self, fmt: StrEnum) -> pathlib.Path:
        """Return path for a given format.

        :param fmt: Format enum specifying the output format.
        :type fmt: StrEnum
        :returns: Path to the file or directory for this format.
        :rtype: pathlib.Path
        """
        return self.local_dir / f"{self.object_stem}.{fmt.value}"

    def exists(self) -> bool:
        """Check whether the master copy of this data object exists.

        :returns: ``True`` if the master copy file or directory exists.
        :rtype: bool
        """
        return self.path_to_format(self.make_format).exists()

    def _delete_format(self, fmt: StrEnum) -> None:
        """Delete a specific format of the object."""
        format_path = self.path_to_format(fmt)
        if format_path.exists():
            if format_path.is_dir():
                shutil.rmtree(format_path)
            else:
                format_path.unlink()
            logger.info(
                f"deleted_format | object={self.object_stem} fmt={fmt.value}"
            )

    def _convert_formats(self, formats_to_create: Sequence[StrEnum]) -> None:
        """Run each format's conversion method and log a per-format summary.

        :param formats_to_create: Format enums to materialize.
        :type formats_to_create: Sequence[StrEnum]
        :raises NotImplementedError: If a ``_convert_to_<fmt>`` method
            is not defined on the subclass.
        """
        for fmt in formats_to_create:
            if fmt == self.make_format:
                continue
            method_name = f"_convert_to_{fmt.value.replace('.', '_')}"
            if not hasattr(self, method_name):
                raise NotImplementedError(
                    f"Conversion method {method_name} not found for format '{fmt.value}'"
                )
            t0 = time.perf_counter()
            getattr(self, method_name)()
            dt = time.perf_counter() - t0
            fmt_path = self.path_to_format(fmt).resolve()
            kvs: dict[str, Any] = {
                "object": self.object_stem,
                "fmt": fmt.value,
                "dur_s": f"{dt:.3f}",
                "bytes": file_or_dir_size_bytes(fmt_path),
                **self._convert_summary(fmt),
                "path": str(fmt_path),
            }
            logger.info(format_summary("convert", kvs))

    @abstractmethod
    def _make(self) -> None:
        """Create and save the object in default format.

        Must be implemented by subclasses to create the actual data.
        """

    async def _amake(self) -> None:
        """Async hook for ``make()``.

        Default runs sync ``_make`` in a thread so it can be awaited from
        a running event loop (e.g. a Dagster asset). Subclasses that have
        an async-native build (``TableFromDB``) override this directly.
        """
        await asyncio.to_thread(self._make)

    # ---- Subclass hooks for the lifecycle summary lines ----------------

    def _make_summary(self) -> dict[str, Any]:
        """Subclass hook contributing ``k=v`` fields to the make_summary.

        Default empty. Overrides should return a small dict (e.g.
        ``{"rows": 100, "cols": 5}``) — these are merged into the
        summary line emitted at the end of ``make()``.
        """
        return {}

    def _convert_summary(self, fmt: StrEnum) -> dict[str, Any]:
        """Subclass hook for the convert_summary line. Default empty."""
        del fmt
        return {}

    def _delete_summary(self) -> dict[str, Any]:
        """Subclass hook for the delete_summary line. Default empty."""
        return {}

    # ---- Public lifecycle methods --------------------------------------

    def _check_make_preconditions(self, replace: bool) -> None:
        """Shared pre-check for ``make`` / ``amake``."""
        if self.exists() and not replace:
            raise FileExistsError(
                f"Object {self.object_stem} already exists in default format ({self.make_format.value}). "
                f"Use replace=True to overwrite."
            )
        if replace:
            self.delete()
        self.local_dir.mkdir(parents=True, exist_ok=True)

    def _emit_make_summary(self, dur_s: float) -> None:
        """Shared make_summary emission for ``make`` / ``amake``."""
        master_path = self.path_to_format(self.make_format).resolve()
        kvs: dict[str, Any] = {
            "object": self.object_stem,
            "fmt": self.make_format.value,
            "dur_s": f"{dur_s:.3f}",
            "bytes": file_or_dir_size_bytes(master_path),
            **self._make_summary(),
            "path": str(master_path),
        }
        logger.info(format_summary("make", kvs))

    def _run_checks(self) -> None:
        """Iterate ``self.checks`` synchronously; first failure raises.

        Used by sync ``make()``. Async-only checks raise
        ``NotImplementedError`` here; that propagates as a clear "use
        amake()" error.
        """
        for check in self.checks:
            logger.info(f"check_start | {check.name}")
            try:
                check.run(self)
            except Exception:
                logger.exception(f"check_failed | {check.name}")
                raise
            logger.info(f"check_ok | {check.name}")

    async def _arun_checks(self) -> None:
        """Iterate ``self.checks`` asynchronously; first failure raises.

        Used by ``amake()`` and ``RequestsDBMixin.make()``. Sync checks
        delegate to :meth:`BaseCheck.run` via the default ``arun``.
        """
        for check in self.checks:
            logger.info(f"check_start | {check.name}")
            try:
                await check.arun(self)
            except Exception:
                logger.exception(f"check_failed | {check.name}")
                raise
            logger.info(f"check_ok | {check.name}")

    def make(self, replace: bool = False) -> None:
        """Create the master copy of the object in the default format.

        :param replace: If ``True``, delete existing master copy and
            all format copies, then create the master copy anew. If
            ``False``, raise when the master copy already exists.
        :type replace: bool
        :raises FileExistsError: If master copy exists and
            ``replace=False``.
        """
        self._check_make_preconditions(replace)
        with object_log_context(
            object_stem=self.object_stem,
            local_dir=self.local_dir,
            phase="make",
        ):
            t0 = time.perf_counter()
            try:
                self._make()
            except Exception:
                logger.exception(f"make_failed | object={self.object_stem}")
                raise
            self._emit_make_summary(time.perf_counter() - t0)
            self._run_checks()

    async def amake(self, replace: bool = False) -> None:
        """Async lifecycle entry; mirrors ``make()`` but awaits ``_amake()``.

        Use this from async contexts (Dagster's running event loop, an
        async test harness, etc.) where calling ``make()`` would crash
        on its internal ``asyncio.run(_amake())`` for ``TableFromDB``
        and similar async-native subclasses. Opens the same per-object
        log context and emits the same ``make_summary`` line as ``make()``.

        :param replace: If ``True``, delete existing master copy and
            all format copies, then create the master copy anew. If
            ``False``, raise when the master copy already exists.
        :type replace: bool
        :raises FileExistsError: If master copy exists and
            ``replace=False``.
        """
        self._check_make_preconditions(replace)
        with object_log_context(
            object_stem=self.object_stem,
            local_dir=self.local_dir,
            phase="make",
        ):
            t0 = time.perf_counter()
            try:
                await self._amake()
            except Exception:
                logger.exception(f"make_failed | object={self.object_stem}")
                raise
            self._emit_make_summary(time.perf_counter() - t0)
            await self._arun_checks()

    def convert(self, fmt: StrEnum | None = None, replace: bool = False) -> None:
        """Create a copy of the object in a supported format using the master copy.

        :param fmt: Format to save. If ``None``, saves in all supported
            formats (excluding the default format).
        :type fmt: StrEnum | None
        :param replace: If ``True``, delete existing copy and recreate.
            If ``False``, raise when copy already exists.
        :type replace: bool
        :raises FileNotFoundError: If master copy doesn't exist.
        :raises FileExistsError: If a format copy exists and
            ``replace=False``.
        :raises ValueError: If ``fmt`` is not a supported format.
        """
        if not self.exists():
            raise FileNotFoundError(
                f"Master copy not found for {self.object_stem}. "
                f"Call make() first to create the master copy in {self.make_format.value} format."
            )

        format_class = type(self.make_format)

        if fmt is None:
            formats_to_create = [f for f in format_class if f != self.make_format]
        else:
            if not isinstance(fmt, format_class):
                raise TypeError(
                    f"Format '{fmt}' not supported. Supported formats: {list(format_class)}"
                )
            if fmt == self.make_format:
                return
            formats_to_create = [fmt]

        for fmt_enum in formats_to_create:
            format_path = self.path_to_format(fmt_enum)
            if format_path.exists() and not replace:
                raise FileExistsError(
                    f"Format '{fmt_enum.value}' already exists for {self.object_stem}. "
                    f"Use replace=True to overwrite."
                )
            if format_path.exists() and replace:
                self._delete_format(fmt_enum)

        with object_log_context(
            object_stem=self.object_stem,
            local_dir=self.local_dir,
            phase="convert",
        ):
            try:
                self._convert_formats(formats_to_create)
            except Exception:
                logger.exception(f"convert_failed | object={self.object_stem}")
                raise

    def delete(self) -> None:
        """Delete all on-disk data for this object.

        Idempotent: returns silently if nothing exists to delete.
        Logs a ``delete_summary`` line with file count + bytes BEFORE
        the rmtree so the per-object log captures the size that was
        reclaimed (the log file itself goes with the rmtree).
        """
        if not self.local_dir.exists():
            return

        # Compute stats up-front so the summary records what was reclaimed.
        files_n = count_files(self.local_dir)
        size_b = file_or_dir_size_bytes(self.local_dir)
        local_dir = self.local_dir.resolve()

        with object_log_context(
            object_stem=self.object_stem,
            local_dir=self.local_dir,
            phase="delete",
        ):
            kvs: dict[str, Any] = {
                "object": self.object_stem,
                "files": files_n,
                "bytes": size_b,
                **self._delete_summary(),
                "path": str(local_dir),
            }
            logger.info(format_summary("delete", kvs))
        # The handler is detached at this point; rmtree removes the log file too.
        shutil.rmtree(self.local_dir)
