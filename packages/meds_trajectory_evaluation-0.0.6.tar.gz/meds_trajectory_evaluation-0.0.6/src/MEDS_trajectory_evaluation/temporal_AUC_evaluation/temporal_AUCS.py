import logging
import math
from collections.abc import Callable, Collection
from datetime import timedelta

import polars as pl
import polars.selectors as cs
from meds import LabelSchema

logger = logging.getLogger(__name__)


def _reprefix_fntr(new_prefix: str) -> Callable[[str], str]:
    """Create a function that replaces the prefix of a string with a new prefix.

    This function is used to change the prefix of a string that starts with "*/" to a new prefix.

    Args:
        new_prefix: The new prefix to use.

    Returns:
        A function that takes a string and replaces its prefix with the new prefix, where prefix vs. suffix is
        determined by the first slash in the string.

    Examples:
        >>> fn = _reprefix_fntr("new_prefix")
        >>> fn("old_prefix/some/path")
        'new_prefix/some/path'
        >>> fn("another_prefix/foo")
        'new_prefix/foo'
        >>> fn("no_prefix")
        Traceback (most recent call last):
            ...
        ValueError: String 'no_prefix' does not have a valid prefix to replace.
    """

    def reprefix_fntr(s: str) -> str:
        """Replace the prefix of a string with a new prefix."""
        parts = s.split("/")
        if len(parts) < 2:
            raise ValueError(f"String '{s}' does not have a valid prefix to replace.")
        suffix = "/".join(parts[1:])
        return f"{new_prefix}/{suffix}"

    return reprefix_fntr


def df_AUC(df: pl.DataFrame) -> pl.DataFrame:
    """Given a DataFrame with sorted cols "true" and "false" containing lists of probabilities, compute AUC.

    This uses polars expressions and the probabilistic interpretation of AUC as the probability that a
    randomly chosen positive example has a higher score than a randomly chosen negative example to
    efficiently compute the AUC across many tasks at once.

    The input dataframe is structured with a collection of task index columns, followed by two columns: `true`
    and `false`, which contain lists of probabilities for the positive and negative classes, respectively.
    These can be full distributions or subsamples of the distributions, but _must_ be sorted in ascending
    order. A search algorithm is then used to determine where each positive sample would fit in the ordered
    set of negative samples to determine the number of correctly ordered pairs, which is divided by the total
    number of pairs to compute the AUC.

    This algorithm could be made even more efficient by leveraging the sorting of both columns to limit the
    search space of the search algorithm for each positive sample, but this is not implemented yet and may
    result in slowdowns due to the fact that it would limit parallelization.

    Arguments:
        df: A DataFrame with task row-index columns followed by sets of two columns "true/$task_col" and
            "false/$task_col" containing lists of probabilities for the positive and negative classes,
            respectively, for the task indexed by the given row and columq. The lists must be sorted in
            ascending order.

    Returns:
        A DataFrame with the same task index columns and a new column "AUC/$task_col" containing the computed
        AUC for each task row X column combination.

    Examples:
        >>> df = pl.DataFrame({
        ...     "task": ["task1", "task2"],
        ...     "true/A": [[0.1, 0.5, 0.8], [0.3, 0.5]],
        ...     "false/A": [[0.2, 0.3], [0.4, 0.9]],
        ...     "true/B": [[0.1, 0.34], [0.8, 0.9]],
        ...     "false/B": [[0.02, 0.3], [0.4, 0.5]],
        ... })

    In this example, the DataFrame `df` contains two task rows and columns with their respective true and
    false probabilities.
    Task 1.A has true probabilities of [0.1, 0.5, 0.8] and false probabilities of [0.2, 0.3], which results in
    four correctly ordered pairs (0.5 > 0.2, 0.5 > 0.3, 0.8 > 0.2, 0.8 > 0.3) out of a total of six pairs, for
    an AUC of 4/6 = 0.6667.
    Task 2.A has true probabilities of [0.3, 0.5] and false probabilities of [0.4, 0.9], which results in
    one correctly ordered pair (0.5 > 0.4) out of a total of four pairs, for an AUC of 1/4 = 0.25.
    Task 1.B has true probabilities of [0.1, 0.34] and false probabilities of [0.02, 0.3], which results in
    three correctly ordered pairs (0.34 > 0.02, 0.34 > 0.3, 0.1 > 0.02) out of a total of four pairs, for an
    AUC of 3/4 = 0.75.
    Task 2.B has true probabilities of [0.8, 0.9] and false probabilities of [0.4, 0.5], which results in an
    AUC of 1.0, since both true probabilities are greater than both false probabilities.

        >>> df_AUC(df)
        shape: (2, 3)
        ┌───────┬──────────┬───────┐
        │ task  ┆ AUC/A    ┆ AUC/B │
        │ ---   ┆ ---      ┆ ---   │
        │ str   ┆ f64      ┆ f64   │
        ╞═══════╪══════════╪═══════╡
        │ task1 ┆ 0.666667 ┆ 0.75  │
        │ task2 ┆ 0.25     ┆ 1.0   │
        └───────┴──────────┴───────┘

    Let's look at another example, where there are duplicates in the true and false distributions. In this
    example, Task 1 has true probabilities of [0.2, 0.2, 0.4, 0.6] and false probabilities of [0.1, 0.3, 0.3],
    which results in eight correctly ordered pairs:
        0.2 > 0.1, 0.2 > 0.1,
        0.4 > 0.1, 0.4 > 0.3, 0.4 > 0.3,
        0.6 > 0.1, 0.6 > 0.3, 0.6 > 0.3
    out of a total of twelve pairs, for an AUC of 8/12 = 0.6667.
    Task 2 has true probabilities of [0.8] and false probabilities of [0.1, 0.4, 0.4, 0.9], which results in
    three correctly ordered pairs (0.8 > 0.1, 0.8 > 0.4, 0.8 > 0.4) out of a total of four pairs, for an AUC
    of 3/4 = 0.75.

        >>> df = pl.DataFrame({
        ...     "task": ["task1", "task2"],
        ...     "true/A": [[0.2, 0.2, 0.4, 0.6], [0.8]],
        ...     "false/A": [[0.1, 0.3, 0.3], [0.1, 0.4, 0.4, 0.9]]
        ... })
        >>> df_AUC(df)
        shape: (2, 2)
        ┌───────┬──────────┐
        │ task  ┆ AUC/A    │
        │ ---   ┆ ---      │
        │ str   ┆ f64      │
        ╞═══════╪══════════╡
        │ task1 ┆ 0.666667 │
        │ task2 ┆ 0.75     │
        └───────┴──────────┘

    If we have an empty distribution, the AUC returned is `null`:

        >>> df_empty = pl.DataFrame({
        ...     "task": ["task1", "task2", "task3"],
        ...     "true/A": [[0.1, 0.5, 0.8], [], [0.3, 0.5]],
        ...     "false/A": [[0.2, 0.3], [0.4, 0.9], []]
        ... })
        >>> df_AUC(df_empty)
        shape: (3, 2)
        ┌───────┬──────────┐
        │ task  ┆ AUC/A    │
        │ ---   ┆ ---      │
        │ str   ┆ f64      │
        ╞═══════╪══════════╡
        │ task1 ┆ 0.666667 │
        │ task2 ┆ null     │
        │ task3 ┆ null     │
        └───────┴──────────┘

    Ties should contribute 1/2 an ordered pair to the AUC. In the example below, Task 1 has true probabilities
    of [0.2, 0.3, 0.5] and false probabilities of [0.2, 0.3, 0.3], which results in:
      * 4 correctly ordered pairs (0.3 > 0.2, 0.5 > 0.2, 0.5 > 0.3, 0.5 > 0.3)
      * 3 ties (0.2 == 0.2, 0.3 == 0.3, 0.3 == 0.3)
      * of a total of 9 pairs.
    This gives an AUC of (4 + 0.5 * 3) / 9 = 5.5 / 9 = 0.6111.
    Task 2 has true probabilities of [0.9] and false probabilities of [0.4, 0.9], which results in:
      * 1 correctly ordered pair (0.9 > 0.4)
      * 1 tie (0.9 == 0.9)
      * of a total of 2 pairs.
    This gives an AUC of (1 + 0.5 * 1) / 2 = 0.75.

        >>> df_ties = pl.DataFrame({
        ...     "task": ["task1", "task2"],
        ...     "true/A": [[0.2, 0.3, 0.5], [0.9]],
        ...     "false/A": [[0.2, 0.3, 0.3], [0.4, 0.9]]
        ... })
        >>> df_AUC(df_ties)
        shape: (2, 2)
        ┌───────┬──────────┐
        │ task  ┆ AUC/A    │
        │ ---   ┆ ---      │
        │ str   ┆ f64      │
        ╞═══════╪══════════╡
        │ task1 ┆ 0.611111 │
        │ task2 ┆ 0.75     │
        └───────┴──────────┘
    """

    tasks = [c.split("/")[1] for c in df.columns if c.startswith("true/")]
    ids = [c for c in df.columns if c.split("/")[0] not in {"true", "false"}]

    structs = [
        pl.struct(
            true=pl.col(f"true/{t}").cast(pl.List(pl.Float64)),
            false=pl.col(f"false/{t}").cast(pl.List(pl.Float64)),
        ).alias(f"dist/{t}")
        for t in tasks
    ]

    df = df.select(*ids, *structs).with_row_index("__idx")

    dists = cs.starts_with("dist/")
    # polars 1.31+ drops the parent selector name when applying `.struct.field(...)`; `.name.keep()`
    # restores the "dist/<task>" name so downstream `.name.map(_reprefix_fntr("AUC"))` can find it.
    T = dists.struct.field("true").name.keep()
    F = dists.struct.field("false").name.keep()

    num_pairs = T.list.len() * F.list.len()
    num_F_lt_T_pairs = F.list.explode().search_sorted(T.list.explode(), side="left").sum().over("__idx")
    num_F_lte_T_pairs = F.list.explode().search_sorted(T.list.explode(), side="right").sum().over("__idx")

    AUC = ((num_F_lt_T_pairs + num_F_lte_T_pairs) / 2) / num_pairs
    # polars 1.31+ derives the output name from the first `then(None)`, losing the AUC column name;
    # putting AUC in `then` preserves name inheritance into the subsequent `.name.map(...)`.
    AUC = pl.when(AUC.is_finite()).then(AUC).otherwise(None)

    return df.select(*ids, AUC.name.map(_reprefix_fntr("AUC")))


def _parse_resolution(resolution: str) -> timedelta:
    """Parse a simple duration specification.

    Args:
        resolution: String encoding of the resolution. Supported units are
            ``"d"`` (days), ``"h"`` (hours), ``"m"`` (minutes), and ``"s"``
            (seconds).

    Returns:
        The parsed duration.

    Examples:
        >>> _parse_resolution("5d")
        datetime.timedelta(days=5)
        >>> _parse_resolution("3h")
        datetime.timedelta(seconds=10800)
        >>> _parse_resolution("foo")
        Traceback (most recent call last):
            ...
        ValueError: Invalid resolution specification: 'foo'

    Note:
        Uses :func:`pytimeparse.timeparse.parse` under the hood to support a
        range of short duration strings.
    """

    from pytimeparse import parse

    seconds = parse(resolution)
    if seconds is None:
        raise ValueError(f"Invalid resolution specification: {resolution!r}")

    return timedelta(seconds=seconds)


def _collect_durations(df: pl.DataFrame) -> pl.Series:
    """Collect unique durations from ``tte`` columns.

    Args:
        df: DataFrame containing ``tte/`` or ``tte_pred/`` columns.

    Returns:
        A sorted series of the unique durations observed.

    Examples:
        >>> df = pl.DataFrame({
        ...     "tte/A": [timedelta(days=2), None],
        ...     "tte_pred/A": [[timedelta(days=1), timedelta(days=3)], []],
        ... })
        >>> _collect_durations(df)
        shape: (3,)
        Series: 'tte/A' [duration[μs]]
        [
            1d
            2d
            3d
        ]
        >>> _collect_durations(pl.DataFrame({"x": [1, 2]}))
        shape: (0,)
        Series: '' [duration[μs]]
        [
        ]
    """

    cols = df.select(cs.matches(r"^tte(?:_pred)?/"))
    if cols.width == 0:
        return pl.Series([], dtype=pl.Duration)

    series_list: list[pl.Series] = []
    for name in cols.columns:
        s = cols[name]
        if s.dtype == pl.List:
            series_list.append(s.explode())
        else:
            series_list.append(s)

    return pl.concat(series_list, how="vertical").drop_nulls().unique().sort()


def resolution_grid(ttes_df: pl.DataFrame, resolution: str) -> pl.Series:
    """Create a regularly spaced duration grid.

    Args:
        ttes_df: DataFrame containing ``tte`` information.
        resolution: Resolution string, e.g. ``"1d"`` or ``"12h"``.

    Returns:
        A series of durations spaced according to ``resolution``.

    Examples:
        >>> df = pl.DataFrame({
        ...     "tte/A": [timedelta(days=2), None, timedelta(days=5)],
        ...     "tte_pred/A": [[timedelta(days=1), timedelta(days=3)], [timedelta(days=4)], []],
        ... })
        >>> resolution_grid(df, "1d")
        shape: (5,)
        Series: '' [duration[μs]]
        [
            1d
            2d
            3d
            4d
            5d
        ]
        >>> resolution_grid(pl.DataFrame({"x": [1]}), "1d")
        shape: (0,)
        Series: '' [duration[μs]]
        [
        ]
    """

    delta = _parse_resolution(resolution)
    durations = _collect_durations(ttes_df)
    if durations.is_empty():
        return pl.Series([], dtype=pl.Duration)

    max_dur = durations.max()
    if max_dur is None:
        raise ValueError("No valid durations found in DataFrame")

    n = math.ceil(max_dur / delta)
    grid = [delta * i for i in range(1, n + 1)]
    return pl.Series(grid)


def random_grid(ttes_df: pl.DataFrame, n: int | None) -> pl.Series:
    """Sample ``n`` durations from observed change points.

    Args:
        ttes_df: DataFrame containing ``tte`` information.
        n: Number of samples to draw. If ``None`` all unique durations are
            returned.

    Returns:
        A series of durations sampled without replacement.

    Examples:
        >>> df = pl.DataFrame({
        ...     "tte/A": [timedelta(days=2), None, timedelta(days=5)],
        ...     "tte_pred/A": [[timedelta(days=1), timedelta(days=3)], [timedelta(days=4)], []],
        ... })
        >>> random_grid(df, None)
        shape: (5,)
        Series: 'tte/A' [duration[μs]]
        [
            1d
            2d
            3d
            4d
            5d
        ]
        >>> random_grid(df, 3)
        shape: (3,)
        Series: 'tte/A' [duration[μs]]
        [
            1d
            2d
            5d
        ]
        >>> random_grid(pl.DataFrame({"x": [1]}), None)
        shape: (0,)
        Series: '' [duration[μs]]
        [
        ]
    """

    durations = _collect_durations(ttes_df)
    if durations.is_empty():
        return pl.Series([], dtype=pl.Duration)

    if n is None:
        return durations

    n = min(n, len(durations))
    return durations.sample(n=n, seed=0, with_replacement=False).sort()


def get_grid(
    ttes_df: pl.DataFrame,
    grid: str | int | None | list[timedelta] = 10000,
) -> list[timedelta]:
    """Dispatch function that builds a duration grid from the polymorphic ``grid`` parameter.

    Args:
        ttes_df: DataFrame containing ``tte/`` and/or ``tte_pred/`` columns used to derive grid boundaries
            when ``grid`` is not an explicit list.
        grid: Specifies how to build the duration grid.  If a *string*, it is interpreted as a resolution
            (e.g. ``"1d"``) and a regular grid is created via :func:`resolution_grid`.  If an *int* or
            ``None``, that many change-point durations are sampled via :func:`random_grid` (``None`` returns
            all change-points).  If a *list* of :class:`~datetime.timedelta`, it is used verbatim after
            validation.

    Returns:
        A list (or Series) of durations to use as the evaluation grid.

    Raises:
        ValueError: If ``grid`` is a list containing non-timedelta elements.
    """

    match grid:
        case str() as resolution:
            return resolution_grid(ttes_df, resolution)
        case int() | None as n:
            return random_grid(ttes_df, n)
        case list() as seq:
            if not all(isinstance(x, timedelta) for x in seq):
                raise ValueError("All elements in the sequence must be of type 'timedelta'.")
            return seq


def add_labels_from_true_tte(
    df: pl.DataFrame,
    *,
    offset: timedelta = timedelta(0),
    offset_col: str | None = None,
    handle_censoring: bool = True,
    max_followup_col: str = "max_followup_time",
) -> pl.DataFrame:
    """Convert the true time-to-predicate values into a label for a given duration window.

    Given a dataframe with a set of columns prefaced with `tte/` containing the true time-to-predicate value
    and a column `duration` containing the duration for which the AUC should be computed, this function
    computes the label of whether or not the predicate occurred within the given duration. The output columns
    are named `label/<n>` for each `tte/<n>` column in the input.

    When censoring is handled (recommended for survival analysis), cases with insufficient follow-up time
    are labeled as `null` (censored) rather than `False`, preventing them from being treated as definitive
    negatives in AUC calculations.

    Arguments:
        df: A DataFrame with columns "tte/*" (a time-to-predicate value) and ``duration``
            (the duration for which the label should be computed).
        offset: A constant offset from the prediction time at which the evaluation window begins.
            Defaults to zero (evaluation starts at the prediction time).
        offset_col: If provided, the name of a column whose values are added to ``offset``
            on a per-row basis to produce a per-row evaluation window start.
        handle_censoring: If ``True`` (default), cases with insufficient follow-up time are labeled
            as ``None`` (censored) rather than ``False``. This requires the ``max_followup_col`` to
            be present in the DataFrame.
        max_followup_col: Name of the column containing maximum follow-up time for each row.
            Only used when ``handle_censoring`` is ``True``.

    Returns:
        A DataFrame with the same columns as the input except for `tte/*`, plus a new column "label/*"
        containing the labels for each row and tte column. When censoring is handled, labels can be
        ``True`` (event occurred within window), ``False`` (event didn't occur with adequate follow-up),
        or ``None`` (insufficient follow-up to determine outcome).

    Examples:
        >>> df = pl.DataFrame({
        ...     "subject_id": [1, 2, 3],
        ...     "prediction_time": [datetime(2021, 1, 1), datetime(2021, 1, 2), datetime(2021, 1, 3)],
        ...     "tte/A": [timedelta(days=5), timedelta(days=10), None],
        ...     "tte/B": [timedelta(days=2), timedelta(days=3), timedelta(days=15)],
        ...     "duration": [timedelta(days=7), timedelta(days=8), timedelta(days=8)]
        ... })
        >>> add_labels_from_true_tte(df)
        shape: (3, 5)
        ┌────────────┬─────────────────────┬──────────────┬─────────┬─────────┐
        │ subject_id ┆ prediction_time     ┆ duration     ┆ label/A ┆ label/B │
        │ ---        ┆ ---                 ┆ ---          ┆ ---     ┆ ---     │
        │ i64        ┆ datetime[μs]        ┆ duration[μs] ┆ bool    ┆ bool    │
        ╞════════════╪═════════════════════╪══════════════╪═════════╪═════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ 7d           ┆ true    ┆ true    │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ 8d           ┆ false   ┆ true    │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ 8d           ┆ false   ┆ false   │
        └────────────┴─────────────────────┴──────────────┴─────────┴─────────┘
        >>> add_labels_from_true_tte(df, offset=timedelta(days=3))
        shape: (3, 5)
        ┌────────────┬─────────────────────┬──────────────┬─────────┬─────────┐
        │ subject_id ┆ prediction_time     ┆ duration     ┆ label/A ┆ label/B │
        │ ---        ┆ ---                 ┆ ---          ┆ ---     ┆ ---     │
        │ i64        ┆ datetime[μs]        ┆ duration[μs] ┆ bool    ┆ bool    │
        ╞════════════╪═════════════════════╪══════════════╪═════════╪═════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ 7d           ┆ true    ┆ false   │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ 8d           ┆ true    ┆ false   │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ 8d           ┆ false   ┆ false   │
        └────────────┴─────────────────────┴──────────────┴─────────┴─────────┘

    Example with censoring handling (recommended for survival analysis):

        >>> df_with_followup = pl.DataFrame({
        ...     "subject_id": [1, 2, 3, 4],
        ...     "prediction_time": [
        ...         datetime(2021, 1, 1), datetime(2021, 1, 2),
        ...         datetime(2021, 1, 3), datetime(2021, 1, 4)
        ...     ],
        ...     "tte/A": [timedelta(days=5), timedelta(days=10), timedelta(days=3), None],
        ...     "tte/B": [timedelta(days=2), timedelta(days=3), timedelta(days=15), None],
        ...     "duration": [timedelta(days=7), timedelta(days=8), timedelta(days=8), timedelta(days=20)],
        ...     "max_followup_time": [
        ...         timedelta(days=10), timedelta(days=12),
        ...         timedelta(days=5), timedelta(days=15)
        ...     ]
        ... })
        >>> add_labels_from_true_tte(df_with_followup, handle_censoring=True)
        shape: (4, 6)
        ┌────────────┬─────────────────────┬──────────────┬───────────────────┬─────────┬─────────┐
        │ subject_id ┆ prediction_time     ┆ duration     ┆ max_followup_time ┆ label/A ┆ label/B │
        │ ---        ┆ ---                 ┆ ---          ┆ ---               ┆ ---     ┆ ---     │
        │ i64        ┆ datetime[μs]        ┆ duration[μs] ┆ duration[μs]      ┆ bool    ┆ bool    │
        ╞════════════╪═════════════════════╪══════════════╪═══════════════════╪═════════╪═════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ 7d           ┆ 10d               ┆ true    ┆ true    │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ 8d           ┆ 12d               ┆ false   ┆ true    │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ 8d           ┆ 5d                ┆ true    ┆ null    │
        │ 4          ┆ 2021-01-04 00:00:00 ┆ 20d          ┆ 15d               ┆ null    ┆ null    │
        └────────────┴─────────────────────┴──────────────┴───────────────────┴─────────┴─────────┘

    Note the censoring behavior:
    - Subject 1: Event A at 5d, evaluated at 7d → True (event occurred within window)
    - Subject 2: No event A, 12d follow-up, evaluated at 8d → False (adequate follow-up, no event)
    - Subject 3: Event A at 3d → True for A (event within window, regardless of follow-up).
      But event B at 15d is outside the 8d window and only 5d of follow-up → null for B (censored).
      Censoring is applied independently per task.
    - Subject 4: No events, 15d follow-up, evaluated at 20d → null (censored, insufficient follow-up)

        >>> add_labels_from_true_tte(df_with_followup, handle_censoring=False)  # Legacy behavior
        shape: (4, 6)
        ┌────────────┬─────────────────────┬──────────────┬───────────────────┬─────────┬─────────┐
        │ subject_id ┆ prediction_time     ┆ duration     ┆ max_followup_time ┆ label/A ┆ label/B │
        │ ---        ┆ ---                 ┆ ---          ┆ ---               ┆ ---     ┆ ---     │
        │ i64        ┆ datetime[μs]        ┆ duration[μs] ┆ duration[μs]      ┆ bool    ┆ bool    │
        ╞════════════╪═════════════════════╪══════════════╪═══════════════════╪═════════╪═════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ 7d           ┆ 10d               ┆ true    ┆ true    │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ 8d           ┆ 12d               ┆ false   ┆ true    │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ 8d           ┆ 5d                ┆ true    ┆ false   │
        │ 4          ┆ 2021-01-04 00:00:00 ┆ 20d          ┆ 15d               ┆ false   ┆ false   │
        └────────────┴─────────────────────┴──────────────┴───────────────────┴─────────┴─────────┘
    """

    tte_cols = cs.starts_with("tte/")

    start = pl.lit(offset)
    if offset_col is not None:
        start = start + pl.col(offset_col)

    if handle_censoring and max_followup_col in df.columns:
        # Censoring-aware labeling: 3-way classification
        # True: event occurred within window
        # False: event didn't occur AND we have sufficient follow-up
        # None: insufficient follow-up (censored)

        evaluation_window_end = start + pl.col("duration")

        label_expr = (
            pl.when(
                # Event occurred within evaluation window
                (tte_cols > start) & (tte_cols <= evaluation_window_end)
            )
            .then(True)
            .when(
                # Event didn't occur AND we have adequate follow-up to make determination
                tte_cols.is_null() & (pl.col(max_followup_col) >= evaluation_window_end)
            )
            .then(False)
            .when(
                # Event occurred outside window AND we have adequate follow-up
                # to know it didn't occur within window
                tte_cols.is_not_null()
                & (tte_cols > evaluation_window_end)
                & (pl.col(max_followup_col) >= evaluation_window_end)
            )
            .then(False)
            .otherwise(
                # Insufficient follow-up (censored cases)
                None
            )
            # polars 1.31+ names `when(...).then(...).otherwise(None)` as "literal"; `.name.keep()`
            # restores the "tte/<task>" name from the selector root before the prefix rewrite.
            .name.keep()
            .name.map(_reprefix_fntr("label"))
        )

    else:
        # Legacy behavior: treat all null TTEs as False (no censoring consideration)
        label_expr = (
            ((tte_cols > start) & (tte_cols <= start + pl.col("duration")))
            .fill_null(False)
            .name.map(_reprefix_fntr("label"))
        )

    return df.with_columns(label_expr).drop(tte_cols)


def add_probs_from_pred_ttes(
    df: pl.DataFrame,
    *,
    offset: timedelta = timedelta(0),
    offset_col: str | None = None,
) -> pl.DataFrame:
    """Convert the list of predicted time-to-predicate values into a probability distribution.

    Given a dataframe with a column `tte_pred` containing lists of predicted time-to-predicate values and a
    column `duration` containing the duration for which the AUC should be computed, this function computes
    the probability (proportion of sampled trajectories which satisfy) that the time-to-predicate is less than
    or equal to the duration for each trajectory.

    Arguments:
        df: A DataFrame with columns prefixed with ``tte_pred/`` (each a list of predicted
            time-to-predicate values) and ``duration``.
        offset: A constant offset from the prediction time at which the evaluation window begins.
            Defaults to zero.
        offset_col: If provided, the name of a column whose values are added to ``offset``
            on a per-row basis.

    Returns:
        A DataFrame with the same columns as the input except for `tte_pred/*`, plus new columns "prob/*"
        containing the computed probabilities for each row and tte_pred column.

    Examples:
        >>> df = pl.DataFrame({
        ...     "subject_id": [1, 2, 3],
        ...     "prediction_time": [datetime(2021, 1, 1), datetime(2021, 1, 2), datetime(2021, 1, 3)],
        ...     "tte_pred/A": [
        ...         [timedelta(days=5), timedelta(days=10), None],
        ...         [timedelta(days=7), timedelta(days=8)],
        ...         [timedelta(days=8), timedelta(days=9), timedelta(days=10)]
        ...     ],
        ...     "tte_pred/B": [
        ...         [timedelta(days=5), timedelta(days=1), timedelta(days=24)],
        ...         [timedelta(days=7), timedelta(days=2)],
        ...         [timedelta(days=80), timedelta(days=9), timedelta(days=10)]
        ...     ],
        ...     "duration": [timedelta(days=7), timedelta(days=8), timedelta(days=8)]
        ... })
        >>> add_probs_from_pred_ttes(df)
        shape: (3, 5)
        ┌────────────┬─────────────────────┬──────────────┬──────────┬──────────┐
        │ subject_id ┆ prediction_time     ┆ duration     ┆ prob/A   ┆ prob/B   │
        │ ---        ┆ ---                 ┆ ---          ┆ ---      ┆ ---      │
        │ i64        ┆ datetime[μs]        ┆ duration[μs] ┆ f64      ┆ f64      │
        ╞════════════╪═════════════════════╪══════════════╪══════════╪══════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ 7d           ┆ 0.333333 ┆ 0.666667 │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ 8d           ┆ 1.0      ┆ 1.0      │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ 8d           ┆ 0.333333 ┆ 0.0      │
        └────────────┴─────────────────────┴──────────────┴──────────┴──────────┘
        >>> add_probs_from_pred_ttes(df, offset=timedelta(days=3))
        shape: (3, 5)
        ┌────────────┬─────────────────────┬──────────────┬──────────┬──────────┐
        │ subject_id ┆ prediction_time     ┆ duration     ┆ prob/A   ┆ prob/B   │
        │ ---        ┆ ---                 ┆ ---          ┆ ---      ┆ ---      │
        │ i64        ┆ datetime[μs]        ┆ duration[μs] ┆ f64      ┆ f64      │
        ╞════════════╪═════════════════════╪══════════════╪══════════╪══════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ 7d           ┆ 0.666667 ┆ 0.333333 │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ 8d           ┆ 1.0      ┆ 0.5      │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ 8d           ┆ 1.0      ┆ 0.666667 │
        └────────────┴─────────────────────┴──────────────┴──────────┴──────────┘
    """

    tte_pred_cols = cs.starts_with("tte_pred/")

    sorted_lists = tte_pred_cols.list.sort(descending=False, nulls_last=True)

    offset_expr = pl.lit(offset)
    if offset_col is not None:
        offset_expr = offset_expr + pl.col(offset_col)

    upper = (
        sorted_lists.explode()
        .fill_null(pl.lit(timedelta.max))
        .search_sorted(offset_expr + pl.col("duration"), side="right")
    )
    lower = sorted_lists.explode().fill_null(pl.lit(timedelta.max)).search_sorted(offset_expr, side="left")

    num_trajectories_within_duration = upper - lower

    prob_expr = num_trajectories_within_duration / (tte_pred_cols.list.len())

    return (
        df.with_row_index("__idx")
        .with_columns(prob_expr.over("__idx").name.map(_reprefix_fntr("prob")))
        .drop("__idx", cs.starts_with("tte_pred/"))
    )


def temporal_aucs(
    true_tte: pl.DataFrame,
    pred_ttes: pl.DataFrame,
    duration_grid: str | int | None | list[timedelta] = 10000,
    AUC_dist_approx: int = -1,
    seed: int = 0,
    *,
    offset: timedelta = timedelta(0),
    exclude_history: bool | Collection[str] = False,
    handle_censoring: bool = True,
) -> pl.DataFrame:
    """Compute the AUC over different prediction windows for the first occurrence of a predicate.

    Parameters:
        true_tte: The true time-to-first-predicate, with columns "subject_id", "prediction_time", and "tte/*".
            The suffix of the tte column represents the task/predicate in question. A `null` value in any
            "tte/*" column indicates that that predicate did not occur.
        pred_ttes: The predicted time-to-first-predicate, with columns "subject_id", "prediction_time", and
            "tte/*", the latter being a list of observed time-to-predicate values for the different generated
            trajectories for each studied task. The set of tasks (suffixes of the "tte/*" columns) must be the
            same as the `true_tte` dataframe "tte/*" column suffixes. A `null` value in any "tte/*" column
            indicates that that predicate did not occur.
        duration_grid: The temporal resolution for the windowing grid within which the AUC should be
            computed. If a string, builds a regular grid at the specified resolution (e.g., "1d" for one day).
            If an integer, it samples that many time-points at random at which an event is observed in
            either the real or predicted data to use as the grid boundary points. If `None`, all change-points
            are used as grid boundary points. If a sequence of `timedelta` objects, these are used as the grid
            boundary points.
        AUC_dist_approx: If greater than 0, the number of samples to use for approximating the AUC
            distribution. If -1, the full distribution is used. This can be useful for large datasets to
            reduce the cost of computing the AUC, but may result in a less accurate estimate.
        seed: The random seed to use for sampling the AUC distribution if `AUC_dist_approx` is greater than 0.
        offset: Offset from the prediction time at which the evaluation window begins.
        exclude_history: If ``True`` or an iterable of task names, rows where the subject has a historical
            instance of the predicate prior to the prediction time are removed for the specified tasks.
        handle_censoring: If ``True`` (default), cases with insufficient follow-up time are excluded from
            AUC calculation to prevent bias from treating censored observations as definitive negatives.
            Requires ``true_tte`` to contain a ``max_followup_time`` column.

    Returns:
        A DataFrame with one row per duration in the grid and columns ``duration`` (the evaluation
        horizon) and ``AUC/<task>`` for each task/predicate, containing the computed AUROC at that
        horizon. Missing columns (e.g., when all labels at a horizon are the same class) are omitted
        with a logged warning.

    Examples:
        >>> duration_grid = [timedelta(days=1), timedelta(days=5), timedelta(days=10), timedelta(days=15)]

    We'll begin with a duration grid spanning 1, 5, 10, and 15 days. This means that we will output 4 AUCs per
    task:: one for a prediction window of 1 day, one for 5 days, one for 10 days, and one for 15 days. We'll
    construct a setting which has two tasks (A & B) with true labels of:
    - Task A:
      * Duration 1 day: subject 1 is False, subject 2 is False, subject 3 is False.
      * Duration 5 days: subject 1 is True, subject 2 is False, subject 3 is False.
      * Duration 10 days: subject 1 is True, subject 2 is True, subject 3 is False.
      * Duration 15 days: subject 1 is True, subject 2 is True, subject 3 is False.
    - Task B:
      * Duration 1 day: subject 1 is False, subject 2 is False, subject 3 is False.
      * Duration 5 days: subject 1 is False, subject 2 is True, subject 3 is False.
      * Duration 10 days: subject 1 is True, subject 2 is True, subject 3 is False.
      * Duration 15 days: subject 1 is True, subject 2 is True, subject 3 is True.

        >>> true_tte = pl.DataFrame({
        ...     "subject_id": [1, 2, 3],
        ...     "prediction_time": [datetime(2021, 1, 1), datetime(2021, 1, 2), datetime(2021, 1, 3)],
        ...     "tte/A": [timedelta(days=5), timedelta(days=10), None],
        ...     "tte/B": [timedelta(days=8), timedelta(days=2), timedelta(days=12)],
        ... })

    We'll also construct a set of predicted time-to-event values, which are lists of observed
    time-to-predicate values for the different generated trajectories. In this case, we have for task A:
      * Subject 1: 3 trajectories with TTEs of 3, 6, and 11 days, yielding...
        - 1 day: 0 True, 3 False, for a probability of 0/3 = 0.0
        - 5 days: 1 True, 2 False, for a probability of 1/3 = 0.3333
        - 10 days: 2 True, 1 False, for a probability of 2/3 = 0.6667
        - 15 days: 3 True, 0 False, for a probability of 1.0
      * Subject 2: 1 trajectory with a TTE of 11 days and one that never observes the predicate, yielding...
        - 1 day: 0 True, 3 False, for a probability of 0/3 = 0.0
        - 5 days: 0 True, 2 False, for a probability of 0/2 = 0.0
        - 10 days: 0 True, 2 False, for a probability of 0/2 = 0.0
        - 15 days: 1 True, 1 False, for a probability of 1/2 = 0.5
      * Subject 3: 1 trajectory with a TTE of 12 days, yielding...
        - 1 day: 0 True, 3 False, for a probability of 0/3 = 0.0
        - 5 days: 0 True, 1 False, for a probability of 0/1 = 0.0
        - 10 days: 0 True, 1 False, for a probability of 0/1 = 0.0
        - 15 days: 1 True, 0 False, for a probability of 1.0
    For task B, we have:
      * Subject 1: 3 trajectories with TTEs of 1, 5, and 24 days, yielding...
        - 1 day: 1 True, 2 False, for a probability of 1/3 = 0.3333
        - 5 days: 2 True, 1 False, for a probability of 2/3 = 0.6667
        - 10 days: 2 True, 1 False, for a probability of 2/3 = 0.6667
        - 15 days: 2 True, 1 False, for a probability of 2/3 = 0.6667
      * Subject 2: 3 trajectories with no occurrences, yielding uniform probabilities of 0.0 for all
        durations.
      * Subject 3: 2 trajectories with TTEs of 1 day and never observed, yielding uniform probabilities of 0.5
        for all durations.

        >>> pred_ttes = pl.DataFrame({
        ...     "subject_id": [1, 2, 3],
        ...     "prediction_time": [datetime(2021, 1, 1), datetime(2021, 1, 2), datetime(2021, 1, 3)],
        ...     "tte/A": [
        ...         [timedelta(days=3), timedelta(days=6), timedelta(days=11)],
        ...         [timedelta(days=11), None],
        ...         [timedelta(days=12)],
        ...     ],
        ...     "tte/B": [
        ...         [timedelta(days=1), timedelta(days=5), timedelta(days=24)],
        ...         [None, None, None],
        ...         [timedelta(days=1), None],
        ...     ],
        ... })

    This means that we have the following distributions and AUCs:
    - For task A:
      * Duration 1 day: (False, 0.0), (False, 0.0), (False, 0.0), for an AUC of null (no positive examples)
      * Duration 5 days: (True, 0.3333), (False, 0.0), (False, 0.0), for an AUC of 1.0
      * Duration 10 days: (True, 0.6667), (True, 0.0), (False, 0.0), for an AUC of 0.75
      * Duration 15 days: (True, 1.0), (True, 0.5), (False, 1.0), for an AUC of 0.25
    - For task B:
      * Duration 1 day: (False, 0.3333), (False, 0.0), (False, 0.5), for an AUC of null (no positive examples)
      * Duration 5 days: (False, 0.6667), (True, 0.0), (False, 0.5), for an AUC of 0.0
      * Duration 10 days: (True, 0.6667), (True, 0.0), (False, 0.5), for an AUC of 0.5
      * Duration 15 days: (True, 0.6667), (True, 0.0), (True, 0.5), for an AUC of null (no negative examples)

        >>> temporal_aucs(true_tte, pred_ttes, duration_grid)
        shape: (4, 3)
        ┌──────────────┬───────┬───────┐
        │ duration     ┆ AUC/A ┆ AUC/B │
        │ ---          ┆ ---   ┆ ---   │
        │ duration[μs] ┆ f64   ┆ f64   │
        ╞══════════════╪═══════╪═══════╡
        │ 1d           ┆ null  ┆ null  │
        │ 5d           ┆ 1.0   ┆ 0.0   │
        │ 10d          ┆ 0.75  ┆ 0.5   │
        │ 15d          ┆ 0.25  ┆ null  │
        └──────────────┴───────┴───────┘
        >>> temporal_aucs(true_tte, pred_ttes, duration_grid, offset=timedelta(days=2))
        shape: (4, 3)
        ┌──────────────┬───────┬───────┐
        │ duration     ┆ AUC/A ┆ AUC/B │
        │ ---          ┆ ---   ┆ ---   │
        │ duration[μs] ┆ f64   ┆ f64   │
        ╞══════════════╪═══════╪═══════╡
        │ 1d           ┆ null  ┆ null  │
        │ 5d           ┆ 1.0   ┆ null  │
        │ 10d          ┆ 0.25  ┆ 0.75  │
        │ 15d          ┆ 0.25  ┆ 0.75  │
        └──────────────┴───────┴───────┘
        >>> true_tte_hist = true_tte.with_columns([
        ...     pl.Series("history/A", [False, True, False]),
        ...     pl.Series("history/B", [False, False, True]),
        ... ])
        >>> temporal_aucs(
        ...     true_tte_hist,
        ...     pred_ttes,
        ...     [timedelta(days=5), timedelta(days=10)],
        ...     exclude_history=True,
        ... )
        shape: (2, 3)
        ┌──────────────┬───────┬───────┐
        │ duration     ┆ AUC/A ┆ AUC/B │
        │ ---          ┆ ---   ┆ ---   │
        │ duration[μs] ┆ f64   ┆ f64   │
        ╞══════════════╪═══════╪═══════╡
        │ 5d           ┆ 1.0   ┆ 0.0   │
        │ 10d          ┆ 1.0   ┆ null  │
        └──────────────┴───────┴───────┘

    When ``handle_censoring=True`` and ``max_followup_time`` is provided, subjects with
    insufficient follow-up for a given task are excluded from that task's AUC only —
    not from all tasks:

        >>> true_tte_cens = pl.DataFrame({
        ...     "subject_id": [1, 2, 3],
        ...     "prediction_time": [datetime(2021, 1, 1), datetime(2021, 1, 2), datetime(2021, 1, 3)],
        ...     "tte/A": [timedelta(days=5), None, timedelta(days=3)],
        ...     "tte/B": [timedelta(days=3), None, None],
        ...     "max_followup_time": [timedelta(days=20), timedelta(days=10), timedelta(days=4)],
        ... })
        >>> true_tte_cens
        shape: (3, 5)
        ┌────────────┬─────────────────────┬──────────────┬──────────────┬───────────────────┐
        │ subject_id ┆ prediction_time     ┆ tte/A        ┆ tte/B        ┆ max_followup_time │
        │ ---        ┆ ---                 ┆ ---          ┆ ---          ┆ ---               │
        │ i64        ┆ datetime[μs]        ┆ duration[μs] ┆ duration[μs] ┆ duration[μs]      │
        ╞════════════╪═════════════════════╪══════════════╪══════════════╪═══════════════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ 5d           ┆ 3d           ┆ 20d               │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ null         ┆ null         ┆ 10d               │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ 3d           ┆ null         ┆ 4d                │
        └────────────┴─────────────────────┴──────────────┴──────────────┴───────────────────┘
        >>> pred_ttes_cens = pl.DataFrame({
        ...     "subject_id": [1, 2, 3],
        ...     "prediction_time": [datetime(2021, 1, 1), datetime(2021, 1, 2), datetime(2021, 1, 3)],
        ...     "tte/A": [[timedelta(days=4)], [None], [None]],
        ...     "tte/B": [[timedelta(days=2)], [None], [None]],
        ... })
        >>> pred_ttes_cens
        shape: (3, 4)
        ┌────────────┬─────────────────────┬────────────────────┬────────────────────┐
        │ subject_id ┆ prediction_time     ┆ tte/A              ┆ tte/B              │
        │ ---        ┆ ---                 ┆ ---                ┆ ---                │
        │ i64        ┆ datetime[μs]        ┆ list[duration[μs]] ┆ list[duration[μs]] │
        ╞════════════╪═════════════════════╪════════════════════╪════════════════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ [4d]               ┆ [2d]               │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ [null]             ┆ [null]             │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ [null]             ┆ [null]             │
        └────────────┴─────────────────────┴────────────────────┴────────────────────┘

    Subject 3 has event A at 3d (within the 7d window → True for A, prob 0.0) but no event B
    with only 4d of follow-up (censored for B). Subject 3 should participate in task A's AUC
    but be excluded from task B's:

    - Task A (all 3 subjects): positives (sub1=1.0, sub3=0.0), negative (sub2=0.0).
      Pairs: (1.0, 0.0)→win, (0.0, 0.0)→tie. AUC = (1 + 0.5) / 2 = 0.75.
    - Task B (sub3 excluded): positive (sub1=1.0), negative (sub2=0.0). AUC = 1.0.

        >>> temporal_aucs(
        ...     true_tte_cens, pred_ttes_cens,
        ...     duration_grid=[timedelta(days=7)],
        ...     handle_censoring=True,
        ... )
        shape: (1, 3)
        ┌──────────────┬───────┬───────┐
        │ duration     ┆ AUC/A ┆ AUC/B │
        │ ---          ┆ ---   ┆ ---   │
        │ duration[μs] ┆ f64   ┆ f64   │
        ╞══════════════╪═══════╪═══════╡
        │ 7d           ┆ 0.75  ┆ 1.0   │
        └──────────────┴───────┴───────┘

    Censoring status can also vary by duration for the same subject. A subject with limited
    follow-up may be uncensored at short horizons but censored at longer ones:

        >>> true_tte_dur = pl.DataFrame({
        ...     "subject_id": [1, 2, 3],
        ...     "prediction_time": [datetime(2021, 1, 1), datetime(2021, 1, 2), datetime(2021, 1, 3)],
        ...     "tte/A": [timedelta(days=2), None, timedelta(days=2)],
        ...     "tte/B": [timedelta(days=1), None, None],
        ...     "max_followup_time": [timedelta(days=20), timedelta(days=20), timedelta(days=4)],
        ... })
        >>> true_tte_dur
        shape: (3, 5)
        ┌────────────┬─────────────────────┬──────────────┬──────────────┬───────────────────┐
        │ subject_id ┆ prediction_time     ┆ tte/A        ┆ tte/B        ┆ max_followup_time │
        │ ---        ┆ ---                 ┆ ---          ┆ ---          ┆ ---               │
        │ i64        ┆ datetime[μs]        ┆ duration[μs] ┆ duration[μs] ┆ duration[μs]      │
        ╞════════════╪═════════════════════╪══════════════╪══════════════╪═══════════════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ 2d           ┆ 1d           ┆ 20d               │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ null         ┆ null         ┆ 20d               │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ 2d           ┆ null         ┆ 4d                │
        └────────────┴─────────────────────┴──────────────┴──────────────┴───────────────────┘
        >>> pred_ttes_dur = pl.DataFrame({
        ...     "subject_id": [1, 2, 3],
        ...     "prediction_time": [datetime(2021, 1, 1), datetime(2021, 1, 2), datetime(2021, 1, 3)],
        ...     "tte/A": [[timedelta(days=1)], [None], [None]],
        ...     "tte/B": [[timedelta(days=1)], [None], [None]],
        ... })
        >>> pred_ttes_dur
        shape: (3, 4)
        ┌────────────┬─────────────────────┬────────────────────┬────────────────────┐
        │ subject_id ┆ prediction_time     ┆ tte/A              ┆ tte/B              │
        │ ---        ┆ ---                 ┆ ---                ┆ ---                │
        │ i64        ┆ datetime[μs]        ┆ list[duration[μs]] ┆ list[duration[μs]] │
        ╞════════════╪═════════════════════╪════════════════════╪════════════════════╡
        │ 1          ┆ 2021-01-01 00:00:00 ┆ [1d]               ┆ [1d]               │
        │ 2          ┆ 2021-01-02 00:00:00 ┆ [null]             ┆ [null]             │
        │ 3          ┆ 2021-01-03 00:00:00 ┆ [null]             ┆ [null]             │
        └────────────┴─────────────────────┴────────────────────┴────────────────────┘

    Subject 3 has event A at 2d and no event B, with only 4d of follow-up.
    At duration 3d, subject 3 is uncensored for both tasks (4d >= 3d follow-up), so all 3
    subjects contribute to both AUCs.
    At duration 10d, subject 3 is still uncensored for A (event at 2d is within window) but
    censored for B (no event, 4d < 10d), so subject 3 should still contribute to A's AUC.

    Predicted probabilities: sub1 = 1.0 (pred TTE within window), sub2 = 0.0, sub3 = 0.0
    (pred TTE is null → never occurs → prob 0.0).

    - Duration 3d, task A: positives (sub1=1.0, sub3=0.0), negative (sub2=0.0).
      Pairs: (1.0, 0.0)→win, (0.0, 0.0)→tie. AUC = (1 + 0.5) / 2 = 0.75.
    - Duration 3d, task B: positive (sub1=1.0), negatives (sub2=0.0, sub3=0.0).
      Pairs: (1.0, 0.0)→win, (1.0, 0.0)→win. AUC = 2 / 2 = 1.0.
    - Duration 10d, task A: same 3 subjects, same labels and probs → AUC = 0.75.
    - Duration 10d, task B: sub3 censored → positive (sub1=1.0), negative (sub2=0.0).
      Pairs: (1.0, 0.0)→win. AUC = 1 / 1 = 1.0.

        >>> temporal_aucs(
        ...     true_tte_dur, pred_ttes_dur,
        ...     duration_grid=[timedelta(days=3), timedelta(days=10)],
        ...     handle_censoring=True,
        ... )
        shape: (2, 3)
        ┌──────────────┬───────┬───────┐
        │ duration     ┆ AUC/A ┆ AUC/B │
        │ ---          ┆ ---   ┆ ---   │
        │ duration[μs] ┆ f64   ┆ f64   │
        ╞══════════════╪═══════╪═══════╡
        │ 3d           ┆ 0.75  ┆ 1.0   │
        │ 10d          ┆ 0.75  ┆ 1.0   │
        └──────────────┴───────┴───────┘
    """

    ids = [LabelSchema.subject_id_name, LabelSchema.prediction_time_name]

    tasks = [c.split("/")[1] for c in true_tte.columns if c.startswith("tte/")]
    # TODO(mmd): Error validation of the input dataframes to ensure they have the expected columns and types.

    joint = true_tte.join(pred_ttes, on=ids, how="left", maintain_order="left", coalesce=True, suffix="/pred")

    def name_remapper(n: str) -> str:
        if not (n.startswith("tte/") and n.endswith("/pred")):
            return n

        task_name = n.split("/")[1]
        return f"tte_pred/{task_name}"

    # Rename the columns to be tte/task_name and tte_pred/task_name
    joint = joint.rename(name_remapper)

    tte_cols = cs.starts_with("tte/")
    tte_pred_cols = cs.starts_with("tte_pred/")

    duration_grid = get_grid(joint.select(tte_cols | tte_pred_cols), duration_grid)

    with_duration = joint.with_columns(
        pl.lit(duration_grid).alias("duration"),
        pl.lit(offset).alias("offset"),
    ).explode("duration")
    with_labels = add_labels_from_true_tte(
        with_duration, offset_col="offset", handle_censoring=handle_censoring
    )
    with_probs = add_probs_from_pred_ttes(with_labels, offset_col="offset")

    if exclude_history:
        exclude_set = set(tasks) if exclude_history is True else set(exclude_history)
    else:
        exclude_set = set()

    dfs_by_task = []
    for task in tasks:
        df_task = with_probs

        # Filter out censored cases per-task: only exclude rows where *this* task's label is null
        if handle_censoring:
            df_task = df_task.filter(pl.col(f"label/{task}").is_not_null())

        if task in exclude_set and f"history/{task}" in df_task.columns:
            df_task = df_task.filter(~pl.col(f"history/{task}"))

        dfs_by_task.append(
            df_task.select(
                *ids,
                "duration",
                pl.lit(task).alias("task"),
                cs.ends_with(f"/{task}").name.map(lambda n: n.split("/")[0]),
            )
        )

    df = pl.concat(dfs_by_task, how="vertical")

    if AUC_dist_approx > 0:
        n_expr = pl.min_horizontal(pl.col("prob").len(), AUC_dist_approx)
        prob_dist_expr = pl.col("prob").sample(n=n_expr, seed=seed)
    else:
        prob_dist_expr = pl.col("prob")

    def resolve_pivot_col_names(n: str) -> str:
        if not (n.startswith("{") and n.endswith("}")):
            return n

        n = n[1:-1]
        label, task = n.split(",")
        task = task[1:-1]  # Remove the quotes around the task name
        return f"{label}/{task}"

    aucs = df_AUC(
        df.group_by("duration", "task", "label")
        .agg(prob_dist_expr.sort().name.keep())
        .pivot(on=["label", "task"], index="duration", values="prob", aggregate_function=None)
        .rename(resolve_pivot_col_names)
        .sort("duration", descending=False)
    )

    out_cols = [f"AUC/{task}" for task in tasks]

    included_cols = []
    for c in out_cols:
        if c not in aucs:
            logger.warning("Missing column %s", c)
        else:
            included_cols.append(c)

    return aucs.select("duration", *included_cols)  # re-order columns
