from __future__ import annotations

import asyncio
import datetime
import json
import re
import time
from typing import Any
from urllib.parse import urljoin, urlparse, urlunparse

import feedparser
from bs4 import BeautifulSoup
from curl_cffi.requests import AsyncSession as CurlAsyncSession
from curl_cffi.requests import RequestsError
from playwright.async_api import BrowserContext
from sqlalchemy import select

from feedray.config import logger
from feedray.db.models import Article, Image, ProcessingStatus, Source
from feedray.db.session import AsyncSessionFactory
from feedray.services.analysis import content_hash
from feedray.services.article_processing import ArticleProcessingPipeline

domain_last_accessed: dict[str, float] = {}
delay_manager_lock = asyncio.Lock()
DEFAULT_DELAY_SECONDS = 3

CURL_DEFAULT_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.google.com/",
}
BLOCK_KWS = re.compile(r"cookie|subscribe|enable|javascript|sign in|log in|robot|human|captcha", re.I)


def _pick_and_score_metadata(html_content: str, base_url: str) -> dict[str, Any] | None:
    soup = BeautifulSoup(html_content, "lxml")

    def get_meta(selector: str, attr: str = "content") -> str | None:
        tag = soup.select_one(selector)
        if not tag:
            return None
        content = tag.get(attr) or (tag.get_text() if tag.name == "title" else None)
        return content.strip() if content else None

    def score(description: str | None) -> int:
        if not description:
            return -1
        if BLOCK_KWS.search(description):
            return 0
        return len(description) if 100 < len(description) < 500 else 0

    title = (
        get_meta('meta[property="og:title"]')
        or get_meta('meta[name="twitter:title"]')
        or get_meta("title", attr="text")
    )
    descriptions = [
        get_meta('meta[property="og:description"]'),
        get_meta('meta[name="twitter:description"]'),
        get_meta('meta[name="description"]'),
    ]
    best_description = max(descriptions, key=score, default=None)
    image = get_meta('meta[property="og:image"]') or get_meta('meta[name="twitter:image"]')
    if image and not image.startswith(("http://", "https://")):
        image = urljoin(base_url, image)
    if title and best_description:
        return {"title": title, "description": best_description, "image_url": image}
    return None


class ArticleCrawler:
    def __init__(self, context: BrowserContext):
        self.playwright_context = context
        self.curl_session = CurlAsyncSession(
            impersonate="chrome110",
            headers=CURL_DEFAULT_HEADERS,
            timeout=15,
        )
        self.semaphore = asyncio.Semaphore(5)
        self.article_processing_pipeline = ArticleProcessingPipeline()

    @staticmethod
    def _get_canonical_url(url: str) -> str:
        if not url:
            return ""
        parsed = urlparse(url)
        return urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, "", parsed.fragment))

    async def _resolve_google_news_url(self, url: str) -> str | None:
        try:
            r1 = await self.curl_session.get(url)
            soup = BeautifulSoup(r1.content, "html.parser")
            data_p_val = soup.select_one("c-wiz[data-p]").get("data-p")
            obj = json.loads(data_p_val.replace("%.@.", '["garturlreq",'))
            payload = {"f.req": json.dumps([[["Fbv4je", json.dumps(obj[:-6] + obj[-2:]), "null", "generic"]]])}
            r2 = await self.curl_session.post(
                "https://news.google.com/_/DotsSplashUi/data/batchexecute",
                data=payload,
            )
            final_url = json.loads(json.loads(r2.text.replace(")]}'", ""))[0][2])[1]
            logger.info(f"Resolved Google URL -> {final_url}")
            return final_url
        except Exception as exc:
            logger.error(f"Failed to resolve Google News URL {url}: {exc}")
            return None

    async def _fetch_html_with_playwright(self, url: str) -> tuple[str | None, str | None]:
        page = None
        try:
            logger.info(f"Falling back to Playwright for: {url}")
            page = await self.playwright_context.new_page()
            await page.goto(url, wait_until="networkidle", timeout=45000)
            if BLOCK_KWS.search(await page.title()):
                logger.warning(f"Playwright fetch resulted in a block page for {url}")
                return None, None
            return await page.content(), page.url
        except Exception as exc:
            logger.error(f"Playwright fallback failed for {url}: {exc}")
            return None, None
        finally:
            if page:
                await page.close()

    async def _save_article(
        self,
        source: Source,
        *,
        url: str,
        title: str,
        description: str,
        published_at: datetime.datetime,
        image_url: str | None,
    ) -> None:
        article_id: int | None = None
        async with AsyncSessionFactory() as session:
            if (await session.execute(select(Article).where(Article.url == url))).scalar_one_or_none():
                return
            article = Article(
                source_id=source.id,
                url=url,
                title=title,
                cleaned_text=description,
                content_hash=content_hash(title, description),
                published_at=published_at,
                embedding_status=ProcessingStatus.PENDING,
                analysis_status=ProcessingStatus.PENDING,
                event_assignment_status=ProcessingStatus.PENDING,
            )
            session.add(article)
            await session.flush()
            article_id = article.id
            if image_url:
                session.add(Image(article_id=article.id, image_url=self._get_canonical_url(image_url)))
            await session.commit()
        if article_id is not None:
            await self.article_processing_pipeline.enqueue_article(article_id)
        logger.success(f"Saved article shell and queued AI processing: {title}")

    async def _process_direct_rss_entry(self, source: Source, entry: dict) -> None:
        url = self._get_canonical_url(entry.link)
        title = entry.title
        description = entry.get("description") or entry.get("summary")
        published_at = (
            datetime.datetime(*entry.published_parsed[:6], tzinfo=datetime.timezone.utc)
            if "published_parsed" in entry
            else datetime.datetime.now(datetime.timezone.utc)
        )
        image_url = entry.media_content[0].get("url") if "media_content" in entry and entry.media_content else None
        if not (url and title and description):
            logger.warning(f"Skipping direct RSS entry due to missing data: {title}")
            return
        await self._save_article(
            source,
            url=url,
            title=title,
            description=description,
            published_at=published_at,
            image_url=image_url,
        )

    async def _process_google_news_entry(self, source: Source, entry: dict, delay: int) -> None:
        resolved_url = await self._resolve_google_news_url(entry.link)
        if not resolved_url:
            return
        final_url = self._get_canonical_url(resolved_url)

        async with AsyncSessionFactory() as session:
            if (await session.execute(select(Article).where(Article.url == final_url))).scalar_one_or_none():
                return

        domain = urlparse(final_url).netloc
        async with delay_manager_lock:
            now = time.monotonic()
            last_accessed = domain_last_accessed.get(domain, 0)
            if (now - last_accessed) < delay:
                await asyncio.sleep(delay - (now - last_accessed))
            domain_last_accessed[domain] = time.monotonic()

        html_content = None
        try:
            response = await self.curl_session.get(final_url)
            response.raise_for_status()
            if "text/html" in response.headers.get("Content-Type", ""):
                soup_title = BeautifulSoup(response.content, "lxml").title
                if not (soup_title and BLOCK_KWS.search(soup_title.string or "")):
                    html_content = response.content.decode("utf-8", "ignore")
        except RequestsError:
            pass

        if not html_content:
            html_content, final_url_from_pw = await self._fetch_html_with_playwright(resolved_url)
            if final_url_from_pw:
                final_url = self._get_canonical_url(final_url_from_pw)

        if not html_content or not final_url:
            logger.error(f"Failed to fetch content for {entry.link} after all attempts.")
            return

        metadata = _pick_and_score_metadata(html_content, final_url)
        if not metadata:
            logger.warning(f"Could not extract sufficient metadata from {final_url}")
            return
        published_at = datetime.datetime(*entry.published_parsed[:6], tzinfo=datetime.timezone.utc)
        await self._save_article(
            source,
            url=final_url,
            title=metadata["title"],
            description=metadata["description"],
            published_at=published_at,
            image_url=metadata.get("image_url"),
        )

    async def crawl_source(self, source: Source, all_sources_config: dict) -> None:
        logger.info(f"Crawling source: {source.name} (Type: {source.source_type})")
        try:
            feed = feedparser.parse(source.url)
            if feed.bozo:
                logger.error(f"Failed to parse RSS feed for {source.name}: {feed.bozo_exception}")
                return
            delay = all_sources_config.get(source.name, {}).get("delay_seconds", DEFAULT_DELAY_SECONDS)
            for entry in feed.entries:
                async with self.semaphore:
                    if source.source_type == "DIRECT_RSS":
                        await self._process_direct_rss_entry(source, entry)
                    else:
                        await self._process_google_news_entry(source, entry, delay)
            async with AsyncSessionFactory() as session:
                source_to_update = await session.get(Source, source.id)
                if source_to_update:
                    source_to_update.last_crawled_at = datetime.datetime.now(datetime.timezone.utc)
                    source_to_update.crawl_success_count += 1
                    source_to_update.last_error = None
                    total = source_to_update.crawl_success_count + source_to_update.crawl_failure_count
                    source_to_update.reliability_score = round(100 * source_to_update.crawl_success_count / total)
                    await session.commit()
        except Exception as exc:
            logger.error(f"Failed to crawl source {source.name}: {exc}", exc_info=True)
            async with AsyncSessionFactory() as session:
                source_to_update = await session.get(Source, source.id)
                if source_to_update:
                    source_to_update.crawl_failure_count += 1
                    source_to_update.last_error = {"message": str(exc), "stage": "crawl_source"}
                    total = source_to_update.crawl_success_count + source_to_update.crawl_failure_count
                    source_to_update.reliability_score = round(100 * source_to_update.crawl_success_count / total)
                    await session.commit()
