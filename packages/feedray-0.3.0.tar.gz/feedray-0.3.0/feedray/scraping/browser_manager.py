from __future__ import annotations

from playwright.async_api import BrowserContext, async_playwright
from playwright_stealth import Stealth

from feedray.config import EXTENSIONS_DIR, HEADLESS_MODE, USER_DATA_DIR, logger


class BrowserManager:
    def __init__(self) -> None:
        self.playwright = None
        self.context = None

    async def __aenter__(self) -> BrowserContext:
        self.playwright = await async_playwright().start()
        chromium = self.playwright.chromium

        load_extensions_arg = ""
        if EXTENSIONS_DIR.exists() and EXTENSIONS_DIR.is_dir():
            extension_paths = [str(path.resolve()) for path in EXTENSIONS_DIR.iterdir() if path.is_dir()]
            if extension_paths:
                load_extensions_arg = ",".join(extension_paths)
                logger.info(f"Found {len(extension_paths)} extensions to load.")

        browser_args = []
        if load_extensions_arg:
            browser_args.extend(
                [
                    f"--disable-extensions-except={load_extensions_arg}",
                    f"--load-extension={load_extensions_arg}",
                ]
            )

        logger.info(f"Launching browser in {'Headless' if HEADLESS_MODE else 'Headed'} mode.")
        self.context = await chromium.launch_persistent_context(
            user_data_dir=USER_DATA_DIR,
            headless=HEADLESS_MODE,
            args=browser_args,
            slow_mo=500,
        )
        await Stealth().apply_stealth_async(self.context)
        return self.context

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        if self.context:
            await self.context.close()
        if self.playwright:
            await self.playwright.stop()
        logger.info("Browser context closed and Playwright stopped.")
