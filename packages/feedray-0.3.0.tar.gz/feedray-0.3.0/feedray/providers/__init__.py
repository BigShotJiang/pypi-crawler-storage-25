"""Model providers for chat and embeddings."""
