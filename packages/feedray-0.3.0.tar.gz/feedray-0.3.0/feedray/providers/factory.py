from __future__ import annotations

from feedray.config import AppSettings, SETTINGS
from feedray.providers.anthropic import AnthropicChatProvider
from feedray.providers.base import ChatProvider, EmbeddingProvider, ModelProviderConfig, ModelRole
from feedray.providers.gemini import GeminiChatProvider, GeminiEmbeddingProvider
from feedray.providers.local_huggingface import (
    LocalHuggingFaceChatProvider,
    LocalHuggingFaceEmbeddingProvider,
)
from feedray.providers.ollama import OllamaChatProvider, OllamaEmbeddingProvider
from feedray.providers.openai import OpenAIChatProvider, OpenAIEmbeddingProvider

SUPPORTED_PROVIDER_TYPES = {"ollama", "openai", "anthropic", "gemini", "local_huggingface"}


class UnsupportedProviderError(ValueError):
    pass


def build_embedding_provider(settings: AppSettings = SETTINGS) -> EmbeddingProvider | None:
    if not settings.has_embedding_provider:
        return None
    provider_type = settings.embedding_provider_type or ""
    if provider_type not in SUPPORTED_PROVIDER_TYPES:
        raise UnsupportedProviderError(f"Unsupported embedding provider type: {provider_type}")
    if provider_type == "anthropic":
        raise UnsupportedProviderError("Anthropic does not provide a native embedding API.")

    provider_config = ModelProviderConfig(
        role=ModelRole.EMBEDDING,
        provider_type=provider_type,
        model_name=settings.embedding_model_name or "",
        api_key=settings.embedding_api_key,
        base_url=settings.embedding_base_url,
    )
    if provider_type == "ollama":
        return OllamaEmbeddingProvider(provider_config)
    if provider_type == "openai":
        return OpenAIEmbeddingProvider(provider_config)
    if provider_type == "gemini":
        return GeminiEmbeddingProvider(provider_config)
    if provider_type == "local_huggingface":
        return LocalHuggingFaceEmbeddingProvider(provider_config)
    raise UnsupportedProviderError(f"Unsupported embedding provider type: {provider_type}")


def build_chat_provider(settings: AppSettings = SETTINGS) -> ChatProvider | None:
    if not settings.has_chat_provider:
        return None
    provider_type = settings.chat_provider_type or ""
    if provider_type not in SUPPORTED_PROVIDER_TYPES:
        raise UnsupportedProviderError(f"Unsupported chat provider type: {provider_type}")

    provider_config = ModelProviderConfig(
        role=ModelRole.CHAT,
        provider_type=provider_type,
        model_name=settings.chat_model_name or "",
        api_key=settings.chat_api_key,
        base_url=settings.chat_base_url,
    )
    if provider_type == "ollama":
        return OllamaChatProvider(provider_config)
    if provider_type == "openai":
        return OpenAIChatProvider(provider_config)
    if provider_type == "anthropic":
        return AnthropicChatProvider(provider_config)
    if provider_type == "gemini":
        return GeminiChatProvider(provider_config)
    if provider_type == "local_huggingface":
        return LocalHuggingFaceChatProvider(provider_config)
    raise UnsupportedProviderError(f"Unsupported chat provider type: {provider_type}")
