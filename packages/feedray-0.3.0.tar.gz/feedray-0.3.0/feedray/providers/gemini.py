from __future__ import annotations

from collections.abc import Sequence
from urllib.parse import urlencode

import httpx

from feedray.providers.base import ChatProvider, EmbeddingProvider, ModelProviderConfig

DEFAULT_GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"


class _GeminiProviderMixin:
    def __init__(self, config: ModelProviderConfig) -> None:
        self.config = config
        self.base_url = (config.base_url or DEFAULT_GEMINI_BASE_URL).rstrip("/")

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}?{urlencode({'key': self.config.api_key or ''})}"


class GeminiEmbeddingProvider(_GeminiProviderMixin, EmbeddingProvider):
    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        embeddings: list[list[float]] = []
        for text in texts:
            response = httpx.post(
                self._url(f"/models/{self.config.model_name}:embedContent"),
                json={"content": {"parts": [{"text": text}]}},
                headers={"Content-Type": "application/json"},
                timeout=60.0,
            )
            response.raise_for_status()
            embeddings.append(response.json().get("embedding", {}).get("values", []))
        return embeddings


class GeminiChatProvider(_GeminiProviderMixin, ChatProvider):
    def summarize(self, content: str) -> str:
        return self.complete(
            system_prompt="Summarize the provided news item in 500 characters or fewer.",
            user_prompt=content,
        )

    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        response = httpx.post(
            self._url(f"/models/{self.config.model_name}:generateContent"),
            json={
                "contents": [
                    {
                        "role": "user",
                        "parts": [{"text": f"{system_prompt}\n\n{user_prompt}"}],
                    }
                ]
            },
            headers={"Content-Type": "application/json"},
            timeout=60.0,
        )
        response.raise_for_status()
        for candidate in response.json().get("candidates", []):
            for part in candidate.get("content", {}).get("parts", []):
                text = part.get("text")
                if isinstance(text, str) and text.strip():
                    return text.strip()
        raise ValueError("Gemini response did not include text content.")
