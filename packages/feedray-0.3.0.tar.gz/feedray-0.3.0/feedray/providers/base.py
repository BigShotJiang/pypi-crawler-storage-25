from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Sequence
from dataclasses import dataclass
from enum import Enum


class ModelRole(str, Enum):
    EMBEDDING = "embedding"
    CHAT = "chat"


class ProviderType(str, Enum):
    OLLAMA = "ollama"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GEMINI = "gemini"
    LOCAL_HUGGINGFACE = "local_huggingface"


@dataclass(frozen=True)
class ModelProviderConfig:
    role: ModelRole
    provider_type: str
    model_name: str
    api_key: str | None = None
    base_url: str | None = None


class EmbeddingProvider(ABC):
    config: ModelProviderConfig

    @abstractmethod
    def embed(self, texts: Sequence[str]) -> list[list[float]]:
        """Return embeddings for the provided texts."""


class ChatProvider(ABC):
    config: ModelProviderConfig

    @abstractmethod
    def summarize(self, content: str) -> str:
        """Summarize content into a compact description."""

    @abstractmethod
    def complete(self, *, system_prompt: str, user_prompt: str) -> str:
        """Run a chat completion and return text output."""
