from __future__ import annotations

import datetime

import numpy as np
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from feedray.api import schemas
from feedray.api.security import Hasher
from feedray.db.models import (
    ActivityType,
    Article,
    EventArticle,
    EventCluster,
    EventSnapshot,
    User,
    UserActivity,
    UserEventActivity,
    UserInterest,
)


async def get_user_by_username(username: str, db: AsyncSession) -> User | None:
    return (await db.execute(select(User).where(User.username == username))).scalar_one_or_none()


async def get_user_by_email(email: str, db: AsyncSession) -> User | None:
    return (await db.execute(select(User).where(User.email == email))).scalar_one_or_none()


async def create_new_user(user: schemas.UserCreate, db: AsyncSession) -> User:
    new_user = User(
        username=user.username,
        email=user.email,
        hashed_password=Hasher.get_password_hash(user.password),
        is_active=True,
    )
    db.add(new_user)
    await db.commit()
    await db.refresh(new_user)
    return new_user


async def create_user_interest(
    db: AsyncSession, user_id: int, keyword: str, embedding: list[float]
) -> bool:
    existing = (
        await db.execute(select(UserInterest).where(UserInterest.user_id == user_id))
    ).scalar_one_or_none()
    if existing:
        existing.keyword = keyword
        existing.embedding_vector = embedding
    else:
        db.add(UserInterest(user_id=user_id, keyword=keyword, embedding_vector=embedding))
    await db.commit()
    return True


async def get_user_interests(db: AsyncSession, user_id: int) -> list[UserInterest]:
    return (await db.execute(select(UserInterest).where(UserInterest.user_id == user_id))).scalars().all()


async def create_user_activity(
    db: AsyncSession, user_id: int, activity: schemas.ActivityCreate
) -> UserActivity:
    new_activity = UserActivity(
        user_id=user_id,
        article_id=activity.article_id,
        activity_type=activity.activity_type,
    )
    db.add(new_activity)
    await db.commit()
    await db.refresh(new_activity)
    return new_activity


async def create_user_event_activity(
    db: AsyncSession, user_id: int, activity: schemas.EventActivityCreate
) -> UserEventActivity:
    new_activity = UserEventActivity(
        user_id=user_id,
        event_cluster_id=activity.event_cluster_id,
        activity_type=activity.activity_type,
    )
    db.add(new_activity)
    await db.commit()
    await db.refresh(new_activity)
    return new_activity


async def recalculate_user_profile_vector(db: AsyncSession, user_id: int) -> None:
    user = (
        await db.execute(
            select(User)
            .where(User.id == user_id)
            .options(selectinload(User.interests), selectinload(User.activities).selectinload(UserActivity.article))
        )
    ).scalar_one_or_none()
    if not user:
        return

    interest_vectors = [np.array(interest.embedding_vector) for interest in user.interests]
    if not interest_vectors:
        return
    base_vector = np.mean(interest_vectors, axis=0)

    now = datetime.datetime.now(datetime.timezone.utc)
    positive_vectors = []
    for activity in sorted(user.activities, key=lambda item: item.created_at, reverse=True)[:50]:
        if activity.activity_type in {ActivityType.CLICK_RECOMMENDATION, ActivityType.LIKE}:
            if activity.article and activity.article.embedding_vector is not None:
                days_since = (now - activity.created_at).total_seconds() / 86400.0
                decay_factor = np.exp(-0.1 * days_since)
                positive_vectors.append(np.array(activity.article.embedding_vector) * decay_factor)
    event_activities = (
        await db.execute(
            select(UserEventActivity)
            .where(UserEventActivity.user_id == user_id)
            .options(selectinload(UserEventActivity.event_cluster))
            .order_by(UserEventActivity.created_at.desc())
            .limit(50)
        )
    ).scalars().all()
    for activity in event_activities:
        if activity.activity_type in {ActivityType.CLICK_RECOMMENDATION, ActivityType.LIKE}:
            event = activity.event_cluster
            if event and event.centroid_vector is not None:
                days_since = (now - activity.created_at).total_seconds() / 86400.0
                decay_factor = np.exp(-0.1 * days_since)
                positive_vectors.append(np.array(event.centroid_vector) * decay_factor)

    if positive_vectors:
        final_vector = 0.6 * base_vector + 0.4 * np.mean(positive_vectors, axis=0)
    else:
        final_vector = base_vector

    norm = np.linalg.norm(final_vector)
    if norm > 0:
        final_vector = final_vector / norm
    user.profile_vector = final_vector.tolist()
    await db.commit()


def _vector_literal(vector: list[float]) -> str:
    return "[" + ",".join(str(float(value)) for value in vector) + "]"


async def list_articles(
    db: AsyncSession,
    *,
    min_importance: int | None = None,
    max_importance: int | None = None,
    entity: str | None = None,
    source_id: int | None = None,
    semantic_vector: list[float] | None = None,
    limit: int = 20,
    offset: int = 0,
) -> list:
    where = ["1=1"]
    params: dict = {"limit": limit, "offset": offset}
    if min_importance is not None:
        where.append("a.importance_score >= :min_importance")
        params["min_importance"] = min_importance
    if max_importance is not None:
        where.append("a.importance_score <= :max_importance")
        params["max_importance"] = max_importance
    if source_id is not None:
        where.append("a.source_id = :source_id")
        params["source_id"] = source_id
    if entity:
        where.append(
            """
            CAST(a.entities AS TEXT) ILIKE :entity
            """
        )
        params["entity"] = f"%{entity}%"

    similarity_expr = "NULL::float AS similarity"
    order_by = "COALESCE(a.importance_score, 0) DESC, a.published_at DESC NULLS LAST, a.discovered_at DESC"
    if semantic_vector:
        similarity_expr = "1 - (a.embedding_vector <=> :semantic_vector) AS similarity"
        where.append("a.embedding_vector IS NOT NULL")
        params["semantic_vector"] = _vector_literal(semantic_vector)
        order_by = "similarity DESC, COALESCE(a.importance_score, 0) DESC"

    query = text(
        f"""
        SELECT
            a.id, a.url, a.title, a.cleaned_text, a.source_id, a.published_at, a.discovered_at,
            a.importance_score, a.entities, a.topics, {similarity_expr}
        FROM articles a
        WHERE {" AND ".join(where)}
        ORDER BY {order_by}
        LIMIT :limit OFFSET :offset
        """
    )
    return (await db.execute(query, params)).mappings().all()


def _event_row(row) -> dict:
    item = dict(row)
    metadata = item.pop("metadata") or {}
    topic_counts = metadata.get("topic_counts") or {}
    item["topics"] = sorted(topic_counts.keys(), key=lambda topic: topic_counts[topic], reverse=True)[:3]
    item["metadata"] = metadata
    return item


async def list_events(
    db: AsyncSession,
    *,
    min_importance: int | None = None,
    status: str | None = None,
    entity: str | None = None,
    semantic_vector: list[float] | None = None,
    limit: int = 20,
    offset: int = 0,
) -> list[dict]:
    where = ["1=1"]
    params: dict = {"limit": limit, "offset": offset}
    if min_importance is not None:
        where.append("e.importance_score >= :min_importance")
        params["min_importance"] = min_importance
    if status:
        where.append("e.status = :status")
        params["status"] = status.lower()
    if entity:
        where.append("CAST(e.canonical_entities AS TEXT) ILIKE :entity")
        params["entity"] = f"%{entity}%"

    similarity_expr = "NULL::float AS similarity"
    order_by = "COALESCE(e.importance_score, 0) DESC, e.last_article_at DESC NULLS LAST, e.last_seen_at DESC"
    if semantic_vector:
        similarity_expr = "1 - (e.centroid_vector <=> :semantic_vector) AS similarity"
        where.append("e.centroid_vector IS NOT NULL")
        params["semantic_vector"] = _vector_literal(semantic_vector)
        order_by = "similarity DESC, COALESCE(e.importance_score, 0) DESC"

    query = text(
        f"""
        SELECT
            e.id, e.title, e.summary, e.status, e.event_type, e.importance_score,
            e.first_seen_at, e.last_seen_at, e.last_article_at, e.article_count, e.source_count,
            e.canonical_entities, e.metadata, {similarity_expr}
        FROM event_clusters e
        WHERE {" AND ".join(where)}
        ORDER BY {order_by}
        LIMIT :limit OFFSET :offset
        """
    )
    return [_event_row(row) for row in (await db.execute(query, params)).mappings().all()]


async def get_event(db: AsyncSession, event_id: int) -> dict | None:
    query = text(
        """
        SELECT
            e.id, e.title, e.summary, e.status, e.event_type, e.importance_score,
            e.first_seen_at, e.last_seen_at, e.last_article_at, e.article_count, e.source_count,
            e.canonical_entities, e.metadata, NULL::float AS similarity
        FROM event_clusters e
        WHERE e.id = :event_id
        """
    )
    row = (await db.execute(query, {"event_id": event_id})).mappings().one_or_none()
    return _event_row(row) if row else None


async def list_event_articles(db: AsyncSession, event_id: int) -> list:
    query = text(
        """
        SELECT
            a.id, a.url, a.title, a.cleaned_text, a.source_id, a.published_at, a.discovered_at,
            a.importance_score, a.entities, a.topics, ea.similarity_score AS similarity
        FROM event_articles ea
        JOIN articles a ON a.id = ea.article_id
        WHERE ea.event_cluster_id = :event_id
        ORDER BY ea.is_representative DESC, a.published_at DESC NULLS LAST, a.discovered_at DESC
        """
    )
    return (await db.execute(query, {"event_id": event_id})).mappings().all()


async def get_event_timeline(db: AsyncSession, event_id: int) -> list[EventSnapshot]:
    return (
        await db.execute(
            select(EventSnapshot)
            .where(EventSnapshot.event_cluster_id == event_id)
            .order_by(EventSnapshot.snapshot_at.asc())
        )
    ).scalars().all()


async def get_recommendations_for_user(
    db: AsyncSession,
    user_vector: list[float],
    *,
    min_importance: int | None = None,
    limit: int = 20,
) -> list:
    if user_vector is None:
        return []
    where = ["a.embedding_vector IS NOT NULL"]
    params = {"user_vector": _vector_literal(user_vector), "limit": limit}
    if min_importance is not None:
        where.append("a.importance_score >= :min_importance")
        params["min_importance"] = min_importance
    query = text(
        f"""
        SELECT
            a.id, a.url, a.title, a.cleaned_text, a.source_id, a.published_at, a.discovered_at,
            a.importance_score, a.entities,
            1 - (a.embedding_vector <=> :user_vector) AS similarity
        FROM articles a
        WHERE {" AND ".join(where)}
        ORDER BY similarity DESC, COALESCE(a.importance_score, 0) DESC
        LIMIT :limit
        """
    )
    return (await db.execute(query, params)).mappings().all()


async def get_event_recommendations_for_user(
    db: AsyncSession,
    user_id: int,
    user_vector: list[float],
    *,
    min_importance: int | None = None,
    limit: int = 20,
) -> list[dict]:
    if user_vector is None:
        return []
    where = ["e.centroid_vector IS NOT NULL", "e.status IN ('active', 'reactivated', 'quiet')"]
    params = {"user_id": user_id, "user_vector": _vector_literal(user_vector), "limit": limit}
    if min_importance is not None:
        where.append("e.importance_score >= :min_importance")
        params["min_importance"] = min_importance
    query = text(
        f"""
        SELECT
            e.id, e.title, e.summary, e.status, e.event_type, e.importance_score,
            e.first_seen_at, e.last_seen_at, e.last_article_at, e.article_count, e.source_count,
            e.canonical_entities, e.metadata,
            1 - (e.centroid_vector <=> :user_vector) AS similarity,
            COUNT(uea.id) AS user_activity_count
        FROM event_clusters e
        LEFT JOIN user_event_activities uea
          ON uea.event_cluster_id = e.id AND uea.user_id = :user_id
        WHERE {" AND ".join(where)}
        GROUP BY e.id
        ORDER BY
            similarity DESC,
            COUNT(uea.id) ASC,
            COALESCE(e.importance_score, 0) DESC,
            e.last_article_at DESC NULLS LAST
        LIMIT :limit
        """
    )
    return [_event_row(row) for row in (await db.execute(query, params)).mappings().all()]
