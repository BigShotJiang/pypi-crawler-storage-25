from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from feedray import __version__
from feedray.api.routers import activities, articles, authentication, events, interests, models, recommendations, users

app = FastAPI(
    title="Feedray API",
    description="Server-side news ingestion, AI analysis, semantic filtering, and recommendations.",
    version=__version__,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(authentication.router)
app.include_router(users.router)
app.include_router(interests.router)
app.include_router(activities.router)
app.include_router(recommendations.router)
app.include_router(articles.router)
app.include_router(events.router)
app.include_router(models.router)


@app.get("/", tags=["Root"])
async def read_root():
    return {"message": "Welcome to Feedray API."}
