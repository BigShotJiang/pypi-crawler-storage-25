from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.api import crud, schemas
from feedray.api.deps import get_current_user
from feedray.db.session import get_db_session

router = APIRouter(
    prefix="/recommendations",
    tags=["Recommendations"],
    dependencies=[Depends(get_current_user)],
)


@router.get("/", response_model=list[schemas.ArticleDisplay])
async def get_recommendations(
    current_username: str = Depends(get_current_user),
    db: AsyncSession = Depends(get_db_session),
    min_importance: int | None = Query(default=None, ge=1, le=10),
    limit: int = Query(default=20, ge=1, le=100),
):
    user = await crud.get_user_by_username(current_username, db)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if user.profile_vector is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User profile is not generated yet. Please set your interests first.",
        )
    return await crud.get_recommendations_for_user(
        db,
        user_vector=list(user.profile_vector),
        min_importance=min_importance,
        limit=limit,
    )


@router.get("/events", response_model=list[schemas.EventClusterDisplay])
async def get_event_recommendations(
    current_username: str = Depends(get_current_user),
    db: AsyncSession = Depends(get_db_session),
    min_importance: int | None = Query(default=None, ge=1, le=10),
    limit: int = Query(default=20, ge=1, le=100),
):
    user = await crud.get_user_by_username(current_username, db)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if user.profile_vector is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User profile is not generated yet. Please set your interests first.",
        )
    return await crud.get_event_recommendations_for_user(
        db,
        user_id=user.id,
        user_vector=list(user.profile_vector),
        min_importance=min_importance,
        limit=limit,
    )
