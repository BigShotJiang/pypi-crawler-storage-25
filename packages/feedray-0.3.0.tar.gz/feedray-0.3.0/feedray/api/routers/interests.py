from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.api import crud, schemas
from feedray.api.deps import get_current_user
from feedray.db.session import get_db_session
from feedray.services.model_runtime import embed_text

router = APIRouter(
    prefix="/users/me/interests",
    tags=["Interests"],
    dependencies=[Depends(get_current_user)],
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_or_update_interest(
    request: schemas.InterestCreate,
    current_username: str = Depends(get_current_user),
    db: AsyncSession = Depends(get_db_session),
):
    user = await crud.get_user_by_username(current_username, db)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    embedding = embed_text(request.keyword_text)
    if not embedding:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Could not generate embedding for the provided text.",
        )
    await crud.create_user_interest(db, user_id=user.id, keyword=request.keyword_text, embedding=embedding)
    await crud.recalculate_user_profile_vector(db, user_id=user.id)
    return {"message": "Interest updated and profile recalculated successfully."}


@router.get("/", response_model=list[schemas.InterestDisplay])
async def get_interests(
    current_username: str = Depends(get_current_user),
    db: AsyncSession = Depends(get_db_session),
):
    user = await crud.get_user_by_username(current_username, db)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return await crud.get_user_interests(db, user_id=user.id)
