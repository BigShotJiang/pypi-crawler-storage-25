from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.api import crud, schemas
from feedray.api.deps import get_current_user
from feedray.db.session import get_db_session

router = APIRouter(tags=["Users"], prefix="/users")


@router.get("/me", response_model=schemas.UserDisplay)
async def read_users_me(
    current_username: str = Depends(get_current_user),
    db: AsyncSession = Depends(get_db_session),
):
    user = await crud.get_user_by_username(current_username, db)
    if user is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    return user
