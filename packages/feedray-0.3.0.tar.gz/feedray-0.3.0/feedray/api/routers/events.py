from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.api import crud, schemas
from feedray.api.deps import get_current_user
from feedray.db.session import get_db_session
from feedray.services.model_runtime import embed_text

router = APIRouter(
    prefix="/events",
    tags=["Events"],
    dependencies=[Depends(get_current_user)],
)


@router.get("/", response_model=list[schemas.EventClusterDisplay])
async def list_events(
    db: AsyncSession = Depends(get_db_session),
    min_importance: int | None = Query(default=None, ge=1, le=10),
    status_filter: str | None = Query(default=None, alias="status"),
    entity: str | None = None,
    semantic_query: str | None = None,
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    semantic_vector = embed_text(semantic_query) if semantic_query else None
    return await crud.list_events(
        db,
        min_importance=min_importance,
        status=status_filter,
        entity=entity,
        semantic_vector=semantic_vector,
        limit=limit,
        offset=offset,
    )


@router.get("/{event_id}", response_model=schemas.EventClusterDetail)
async def get_event(event_id: int, db: AsyncSession = Depends(get_db_session)):
    event = await crud.get_event(db, event_id)
    if not event:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Event not found")
    return event


@router.get("/{event_id}/articles", response_model=list[schemas.ArticleDisplay])
async def list_event_articles(event_id: int, db: AsyncSession = Depends(get_db_session)):
    if not await crud.get_event(db, event_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Event not found")
    return await crud.list_event_articles(db, event_id)


@router.get("/{event_id}/timeline", response_model=list[schemas.EventSnapshotDisplay])
async def get_event_timeline(event_id: int, db: AsyncSession = Depends(get_db_session)):
    if not await crud.get_event(db, event_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Event not found")
    return await crud.get_event_timeline(db, event_id)
