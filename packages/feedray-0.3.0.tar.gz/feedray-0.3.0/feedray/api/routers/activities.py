from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.api import crud, schemas
from feedray.api.deps import get_current_user
from feedray.db.session import get_db_session

router = APIRouter(
    prefix="/activities",
    tags=["Activities"],
    dependencies=[Depends(get_current_user)],
)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def log_user_activity(
    request: schemas.ActivityCreate,
    current_username: str = Depends(get_current_user),
    db: AsyncSession = Depends(get_db_session),
):
    user = await crud.get_user_by_username(current_username, db)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    await crud.create_user_activity(db, user_id=user.id, activity=request)
    await crud.recalculate_user_profile_vector(db, user_id=user.id)
    return {"message": "Activity logged successfully."}


@router.post("/events", status_code=status.HTTP_201_CREATED)
async def log_user_event_activity(
    request: schemas.EventActivityCreate,
    current_username: str = Depends(get_current_user),
    db: AsyncSession = Depends(get_db_session),
):
    user = await crud.get_user_by_username(current_username, db)
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
    if not await crud.get_event(db, request.event_cluster_id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Event not found")
    await crud.create_user_event_activity(db, user_id=user.id, activity=request)
    await crud.recalculate_user_profile_vector(db, user_id=user.id)
    return {"message": "Event activity logged successfully."}
