from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.api import crud, schemas
from feedray.api.security import Hasher, create_access_token
from feedray.db.session import get_db_session

router = APIRouter(tags=["Authentication"], prefix="/auth")


@router.post("/register", response_model=schemas.UserDisplay)
async def register_user(request: schemas.UserCreate, db: AsyncSession = Depends(get_db_session)):
    user = await crud.get_user_by_username(request.username, db)
    if user:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already registered")
    existing_email = await crud.get_user_by_email(request.email, db)
    if existing_email:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")
    return await crud.create_new_user(user=request, db=db)


@router.post("/token", response_model=schemas.Token)
async def login_for_access_token(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db_session),
):
    user = await crud.get_user_by_username(form_data.username, db)
    if not user:
        user = await crud.get_user_by_email(form_data.username, db)
    if not user or not Hasher.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return {"access_token": create_access_token(data={"sub": user.username}), "token_type": "bearer"}
