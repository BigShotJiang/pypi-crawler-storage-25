from __future__ import annotations

from fastapi import APIRouter, Depends

from feedray.api.deps import get_current_user
from feedray.services.event_compression import event_compression_health_check
from feedray.services.model_runtime import model_health_check

router = APIRouter(
    prefix="/models",
    tags=["Models"],
    dependencies=[Depends(get_current_user)],
)


@router.get("/health")
async def get_models_health():
    result = model_health_check()
    result["event_compression"] = event_compression_health_check()
    return result
