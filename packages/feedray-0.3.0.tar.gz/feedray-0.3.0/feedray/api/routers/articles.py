from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.api import crud, schemas
from feedray.api.deps import get_current_user
from feedray.db.models import Article
from feedray.db.session import get_db_session
from feedray.services.model_runtime import embed_text

router = APIRouter(
    prefix="/articles",
    tags=["Articles"],
    dependencies=[Depends(get_current_user)],
)


@router.get("/", response_model=list[schemas.ArticleDisplay])
async def list_articles(
    db: AsyncSession = Depends(get_db_session),
    min_importance: int | None = Query(default=None, ge=1, le=10),
    max_importance: int | None = Query(default=None, ge=1, le=10),
    entity: str | None = None,
    source_id: int | None = None,
    semantic_query: str | None = None,
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    semantic_vector = embed_text(semantic_query) if semantic_query else None
    return await crud.list_articles(
        db,
        min_importance=min_importance,
        max_importance=max_importance,
        entity=entity,
        source_id=source_id,
        semantic_vector=semantic_vector,
        limit=limit,
        offset=offset,
    )


@router.get("/{article_id}", response_model=schemas.ArticleDetail)
async def get_article(article_id: int, db: AsyncSession = Depends(get_db_session)):
    article = (
        await db.execute(
            select(Article).where(Article.id == article_id)
        )
    ).scalar_one_or_none()
    if not article:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Article not found")

    return schemas.ArticleDetail.model_validate(article, from_attributes=True)
