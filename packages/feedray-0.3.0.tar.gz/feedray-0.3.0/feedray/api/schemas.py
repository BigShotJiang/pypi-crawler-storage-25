from __future__ import annotations

import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from feedray.db.models import ActivityType


class EntityDisplay(BaseModel):
    canonical_name: str
    entity_type: str
    aliases: list[str] = Field(default_factory=list)


class ArticleDisplay(BaseModel):
    id: int
    url: str
    title: str | None = None
    cleaned_text: str | None = None
    source_id: int | None = None
    published_at: datetime.datetime | None = None
    discovered_at: datetime.datetime | None = None
    similarity: float | None = None
    importance_score: int | None = None
    entities: list[EntityDisplay] = Field(default_factory=list)
    topics: list[str] = Field(default_factory=list)

    model_config = ConfigDict(from_attributes=True)


class ArticleDetail(ArticleDisplay):
    pass


class UserBase(BaseModel):
    username: str
    email: EmailStr


class UserCreate(UserBase):
    password: str


class UserDisplay(UserBase):
    id: int
    is_active: bool

    model_config = ConfigDict(from_attributes=True)


class Token(BaseModel):
    access_token: str
    token_type: str


class InterestCreate(BaseModel):
    keyword_text: str = Field(..., max_length=2048)


class InterestDisplay(BaseModel):
    id: int
    keyword: str

    model_config = ConfigDict(from_attributes=True)


class ActivityCreate(BaseModel):
    article_id: int
    activity_type: ActivityType


class EventActivityCreate(BaseModel):
    event_cluster_id: int
    activity_type: ActivityType


class EventClusterDisplay(BaseModel):
    id: int
    title: str
    summary: str | None = None
    status: str
    event_type: str
    importance_score: int | None = None
    first_seen_at: datetime.datetime | None = None
    last_seen_at: datetime.datetime | None = None
    last_article_at: datetime.datetime | None = None
    article_count: int = 0
    source_count: int = 0
    canonical_entities: list[EntityDisplay] = Field(default_factory=list)
    topics: list[str] = Field(default_factory=list)
    similarity: float | None = None

    model_config = ConfigDict(from_attributes=True)


class EventClusterDetail(EventClusterDisplay):
    metadata: dict = Field(default_factory=dict)


class EventSnapshotDisplay(BaseModel):
    id: int
    event_cluster_id: int
    snapshot_at: datetime.datetime | None = None
    window_start_at: datetime.datetime
    window_end_at: datetime.datetime
    summary: str
    key_developments: list[dict] = Field(default_factory=list)
    representative_article_ids: list[int] = Field(default_factory=list)
    importance_score: int | None = None

    model_config = ConfigDict(from_attributes=True)
