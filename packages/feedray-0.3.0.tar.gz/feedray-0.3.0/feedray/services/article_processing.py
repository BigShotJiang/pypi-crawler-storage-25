from __future__ import annotations

import datetime

from sqlalchemy import select

from feedray.config import (
    EMBEDDING_MODEL_NAME,
    EMBEDDING_PROVIDER_TYPE,
    PIPELINE_ANALYSIS_CONCURRENCY,
    PIPELINE_EMBEDDING_CONCURRENCY,
    PIPELINE_EVENT_ASSIGNMENT_CONCURRENCY,
    PIPELINE_QUEUE_MAXSIZE,
    logger,
)
from feedray.db.models import Article, ProcessingStatus
from feedray.db.session import AsyncSessionFactory
from feedray.services.analysis import NewsAnalysisService
from feedray.services.event_assignment import EventAssignmentService
from feedray.services.model_runtime import embed_text
from feedray.services.pipeline import AsyncArticlePipeline, StageConfig


class ArticleProcessingPipeline:
    def __init__(self) -> None:
        self.pipeline = AsyncArticlePipeline()
        self.analysis_service = NewsAnalysisService()
        self.assignment_service = EventAssignmentService()
        self._started = False
        self.pipeline.add_stage(
            StageConfig("embedding", maxsize=PIPELINE_QUEUE_MAXSIZE, concurrency=PIPELINE_EMBEDDING_CONCURRENCY),
            self._embed_article,
        )
        self.pipeline.add_stage(
            StageConfig("chat_analysis", maxsize=PIPELINE_QUEUE_MAXSIZE, concurrency=PIPELINE_ANALYSIS_CONCURRENCY),
            self._analyze_article,
        )
        self.pipeline.add_stage(
            StageConfig(
                "event_assignment",
                maxsize=PIPELINE_QUEUE_MAXSIZE,
                concurrency=PIPELINE_EVENT_ASSIGNMENT_CONCURRENCY,
            ),
            self._assign_article,
        )

    async def start(self) -> None:
        if self._started:
            return
        await self.pipeline.start()
        self._started = True

    async def stop(self) -> None:
        await self.pipeline.stop()
        self._started = False

    async def enqueue_article(self, article_id: int) -> None:
        await self.start()
        await self.pipeline.enqueue("embedding", article_id)

    def metrics_snapshot(self) -> dict[str, dict[str, int]]:
        return self.pipeline.metrics_snapshot()

    async def _embed_article(self, article_id: int) -> None:
        async with AsyncSessionFactory() as session:
            article = (await session.execute(select(Article).where(Article.id == article_id))).scalar_one_or_none()
            if not article:
                return
            if article.embedding_vector is None:
                embedding = embed_text(f"{article.title or ''}\n{article.cleaned_text or ''}")
                if embedding:
                    article.embedding_vector = embedding
                    article.embedding_provider = EMBEDDING_PROVIDER_TYPE
                    article.embedding_model = EMBEDDING_MODEL_NAME
                    article.embedded_at = datetime.datetime.now(datetime.timezone.utc)
                    article.embedding_status = ProcessingStatus.DONE
                    article.processing_error = None
                else:
                    article.embedding_status = ProcessingStatus.FAILED
                    article.processing_error = {"stage": "embedding", "message": "Embedding provider returned no vector."}
                await session.commit()
        await self.pipeline.enqueue("chat_analysis", article_id)

    async def _analyze_article(self, article_id: int) -> None:
        async with AsyncSessionFactory() as session:
            article = (await session.execute(select(Article).where(Article.id == article_id))).scalar_one_or_none()
            if article:
                await self.analysis_service.analyze_article(session, article)
        await self.pipeline.enqueue("event_assignment", article_id)

    async def _assign_article(self, article_id: int) -> None:
        async with AsyncSessionFactory() as session:
            article = (await session.execute(select(Article).where(Article.id == article_id))).scalar_one_or_none()
            if article:
                await self.assignment_service.assign_article(session, article)
                logger.info(f"Finished async article processing for article {article_id}.")
