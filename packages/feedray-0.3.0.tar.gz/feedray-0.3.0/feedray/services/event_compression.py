from __future__ import annotations

import datetime
import json
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from feedray.config import logger
from feedray.db.models import Article, EventArticle, EventCluster, EventSnapshot, EventStatus
from feedray.services.event_utils import centroid_vector
from feedray.services.model_runtime import get_chat_provider


@dataclass(slots=True)
class EventCompressionConfig:
    window_hours: int = 24
    representative_limit: int = 5


def _fallback_summary(cluster: EventCluster, articles: list[Article]) -> tuple[str, list[dict]]:
    titles = [article.title for article in articles if article.title]
    summary = cluster.summary or (titles[0] if titles else cluster.title)
    developments = [{"title": title} for title in titles[:5]]
    return summary[:2000], developments


class EventCompressionService:
    def __init__(self, config: EventCompressionConfig | None = None) -> None:
        self.config = config or EventCompressionConfig()
        self.chat_provider = get_chat_provider()

    async def compress_active_events(self, db: AsyncSession, *, limit: int | None = None) -> list[EventSnapshot]:
        query = (
            select(EventCluster)
            .where(EventCluster.status.in_([EventStatus.ACTIVE, EventStatus.REACTIVATED]))
            .order_by(EventCluster.last_article_at.desc().nullslast())
        )
        if limit:
            query = query.limit(limit)
        clusters = list((await db.execute(query)).scalars().all())
        snapshots: list[EventSnapshot] = []
        for cluster in clusters:
            snapshot = await self.create_snapshot(db, cluster)
            if snapshot:
                snapshots.append(snapshot)
        await db.commit()
        return snapshots

    async def create_snapshot(self, db: AsyncSession, cluster: EventCluster) -> EventSnapshot | None:
        window_end = datetime.datetime.now(datetime.timezone.utc)
        window_start = window_end - datetime.timedelta(hours=self.config.window_hours)
        rows = (
            await db.execute(
                select(EventArticle)
                .where(EventArticle.event_cluster_id == cluster.id)
                .options(selectinload(EventArticle.article))
                .order_by(EventArticle.created_at.desc())
            )
        ).scalars().all()
        articles = [
            row.article
            for row in rows
            if row.article
            and (row.article.published_at or row.article.discovered_at or window_end) >= window_start
        ][: self.config.representative_limit]
        if not articles:
            articles = [row.article for row in rows if row.article][: self.config.representative_limit]
        if not articles:
            return None

        summary, developments = self._summarize(cluster, articles)
        snapshot = EventSnapshot(
            event_cluster_id=cluster.id,
            window_start_at=window_start,
            window_end_at=window_end,
            summary=summary,
            key_developments=developments,
            representative_article_ids=[article.id for article in articles],
            centroid_vector=centroid_vector(articles) or cluster.centroid_vector,
            importance_score=cluster.importance_score,
        )
        db.add(snapshot)
        cluster.summary = summary
        cluster.last_seen_at = window_end
        return snapshot

    def _summarize(self, cluster: EventCluster, articles: list[Article]) -> tuple[str, list[dict]]:
        if self.chat_provider is None:
            return _fallback_summary(cluster, articles)
        prompt = {
            "event_title": cluster.title,
            "current_summary": cluster.summary,
            "articles": [
                {"id": article.id, "title": article.title, "text": (article.cleaned_text or "")[:1200]}
                for article in articles
            ],
        }
        try:
            raw = self.chat_provider.complete(
                system_prompt=(
                    "Return strict JSON with summary and key_developments. "
                    "Explain what changed, central entities, escalation/de-escalation/split/merge/continuation, "
                    "representative articles, and public importance change."
                ),
                user_prompt=json.dumps(prompt, ensure_ascii=False),
            )
            payload = json.loads(raw.strip().removeprefix("```json").removesuffix("```").strip())
            summary = str(payload.get("summary") or cluster.summary or cluster.title)[:2000]
            developments = payload.get("key_developments") if isinstance(payload.get("key_developments"), list) else []
            return summary, developments[:10]
        except Exception as exc:
            logger.warning(f"Event compression fallback for cluster {cluster.id}: {exc}")
            return _fallback_summary(cluster, articles)


async def archive_stale_events(
    db: AsyncSession,
    *,
    quiet_after_hours: int = 48,
    archive_after_hours: int = 168,
) -> dict[str, int]:
    now = datetime.datetime.now(datetime.timezone.utc)
    clusters = list((await db.execute(select(EventCluster))).scalars().all())
    counts = {"quiet": 0, "archived": 0}
    for cluster in clusters:
        new_status = lifecycle_status_for_event(
            cluster,
            now=now,
            quiet_after_hours=quiet_after_hours,
            archive_after_hours=archive_after_hours,
        )
        if new_status == EventStatus.QUIET and cluster.status != EventStatus.QUIET:
            cluster.status = new_status
            counts["quiet"] += 1
        if new_status == EventStatus.ARCHIVED and cluster.status != EventStatus.ARCHIVED:
            cluster.status = new_status
            counts["archived"] += 1
    await db.commit()
    return counts


def lifecycle_status_for_event(
    cluster: EventCluster,
    *,
    now: datetime.datetime,
    quiet_after_hours: int,
    archive_after_hours: int,
) -> EventStatus:
    last_article_at = cluster.last_article_at or cluster.last_seen_at or now
    if last_article_at.tzinfo is None:
        last_article_at = last_article_at.replace(tzinfo=datetime.timezone.utc)
    age_hours = (now - last_article_at).total_seconds() / 3600
    if cluster.status in {EventStatus.ACTIVE, EventStatus.REACTIVATED} and age_hours >= quiet_after_hours:
        return EventStatus.QUIET
    if cluster.status == EventStatus.QUIET and age_hours >= archive_after_hours:
        return EventStatus.ARCHIVED
    return cluster.status


def event_compression_health_check() -> dict:
    provider = get_chat_provider()
    if provider is None:
        return {"status": "skipped", "reason": "No chat provider configured; fallback summaries available."}
    try:
        preview = provider.complete(system_prompt="Return JSON.", user_prompt='{"ping":"event compression"}')
        return {"status": "success", "preview": preview[:160]}
    except Exception as exc:
        return {"status": "failed", "error": str(exc)}
