from __future__ import annotations

from functools import lru_cache

from feedray.config import SETTINGS
from feedray.providers.base import ChatProvider, EmbeddingProvider
from feedray.providers.factory import build_chat_provider, build_embedding_provider


@lru_cache(maxsize=1)
def get_embedding_provider() -> EmbeddingProvider | None:
    return build_embedding_provider(SETTINGS)


@lru_cache(maxsize=1)
def get_chat_provider() -> ChatProvider | None:
    return build_chat_provider(SETTINGS)


def normalize_embedding(embedding: list[float]) -> list[float]:
    if len(embedding) >= SETTINGS.embedding_vector_size:
        return embedding[: SETTINGS.embedding_vector_size]
    return embedding + [0.0] * (SETTINGS.embedding_vector_size - len(embedding))


def embed_text(text: str) -> list[float]:
    provider = get_embedding_provider()
    if provider is None or not text.strip():
        return []
    embeddings = provider.embed([text])
    if not embeddings:
        return []
    return normalize_embedding(embeddings[0])


def model_health_check(sample: str = "Feedray model health check.") -> dict:
    result: dict[str, dict] = {}
    embedding_provider = get_embedding_provider()
    if embedding_provider is None:
        result["embedding"] = {"status": "skipped", "reason": "Not configured."}
    else:
        try:
            embedding = embed_text(sample)
            result["embedding"] = {
                "status": "success",
                "provider": embedding_provider.config.provider_type,
                "model": embedding_provider.config.model_name,
                "dimensions": len(embedding),
            }
        except Exception as exc:
            result["embedding"] = {"status": "failed", "error": str(exc)}

    chat_provider = get_chat_provider()
    if chat_provider is None:
        result["chat"] = {"status": "skipped", "reason": "Not configured."}
    else:
        try:
            preview = chat_provider.summarize(sample)
            result["chat"] = {
                "status": "success",
                "provider": chat_provider.config.provider_type,
                "model": chat_provider.config.model_name,
                "preview": preview[:160],
            }
        except Exception as exc:
            result["chat"] = {"status": "failed", "error": str(exc)}
    return result
