from __future__ import annotations

from typing import Any

import numpy as np


def centroid_vector(items: list[Any]) -> list[float] | None:
    vectors = [np.array(item.embedding_vector, dtype=float) for item in items if item.embedding_vector is not None]
    if not vectors:
        return None
    return np.mean(vectors, axis=0).tolist()


def merge_entities(left: list[dict] | None, right: list[dict] | None) -> list[dict]:
    merged: dict[str, dict] = {}
    for item in (left or []) + (right or []):
        canonical_name = str(item.get("canonical_name") or "").strip()
        if not canonical_name:
            continue
        key = canonical_name.lower()
        current = merged.setdefault(
            key,
            {
                "canonical_name": canonical_name[:255],
                "entity_type": str(item.get("entity_type") or "OTHER").upper(),
                "aliases": [],
            },
        )
        aliases = set(current["aliases"])
        for alias in item.get("aliases") or []:
            alias_text = str(alias).strip()[:255]
            if alias_text:
                aliases.add(alias_text)
        current["aliases"] = sorted(aliases)[:10]
    return list(merged.values())[:30]
