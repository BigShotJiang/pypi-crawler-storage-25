from __future__ import annotations

import datetime
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.db.models import Article, EventArticle, EventAssignmentMethod, EventCluster, ProcessingStatus
from feedray.services.event_assignment import cosine_similarity
from feedray.services.event_utils import centroid_vector, merge_entities


@dataclass(slots=True)
class PendingPromotionConfig:
    window_hours: int = 48
    min_articles: int = 2
    similarity_threshold: float = 0.78


def _topic_counts(articles: list[Article]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for article in articles:
        for topic in article.topics or []:
            counts[topic] = counts.get(topic, 0) + 1
    return counts


def _shared_entity_names(articles: list[Article]) -> set[str]:
    counts: dict[str, int] = {}
    for article in articles:
        seen: set[str] = set()
        for entity in article.entities or []:
            if str(entity.get("entity_type") or "").upper() not in {"ORG", "GPE", "EVENT", "TOPIC"}:
                continue
            name = str(entity.get("canonical_name") or "").strip().lower()
            if name:
                seen.add(name)
        for name in seen:
            counts[name] = counts.get(name, 0) + 1
    return {name for name, count in counts.items() if count >= 2}


def _has_coherence(articles: list[Article]) -> bool:
    if _shared_entity_names(articles):
        return True
    return any(count >= 2 for count in _topic_counts(articles).values())


def cluster_pending_articles(
    articles: list[Article],
    *,
    min_articles: int = 2,
    similarity_threshold: float = 0.78,
) -> list[list[Article]]:
    unvisited = {article.id: article for article in articles if article.embedding_vector is not None}
    clusters: list[list[Article]] = []
    while unvisited:
        _, seed = unvisited.popitem()
        group = [seed]
        changed = True
        while changed:
            changed = False
            for article_id, candidate in list(unvisited.items()):
                if any(
                    cosine_similarity(candidate.embedding_vector, member.embedding_vector) >= similarity_threshold
                    for member in group
                ):
                    group.append(candidate)
                    del unvisited[article_id]
                    changed = True
        if len(group) >= min_articles and _has_coherence(group):
            clusters.append(sorted(group, key=lambda item: (item.published_at or item.discovered_at, item.id)))
    return clusters


class PendingEventPromotionService:
    def __init__(self, config: PendingPromotionConfig | None = None) -> None:
        self.config = config or PendingPromotionConfig()

    async def promote_recent_pending(self, db: AsyncSession) -> list[EventCluster]:
        cutoff = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(hours=self.config.window_hours)
        assigned_ids = select(EventArticle.article_id)
        query = (
            select(Article)
            .where(
                Article.event_assignment_status == ProcessingStatus.PENDING,
                Article.embedding_vector.is_not(None),
                Article.discovered_at >= cutoff,
                Article.id.not_in(assigned_ids),
            )
            .order_by(Article.discovered_at.asc())
        )
        articles = list((await db.execute(query)).scalars().all())
        promoted: list[EventCluster] = []
        for group in cluster_pending_articles(
            articles,
            min_articles=self.config.min_articles,
            similarity_threshold=self.config.similarity_threshold,
        ):
            cluster = self._build_cluster(group)
            db.add(cluster)
            await db.flush()
            for index, article in enumerate(group):
                db.add(
                    EventArticle(
                        event_cluster_id=cluster.id,
                        article_id=article.id,
                        similarity_score=1.0 if index == 0 else cosine_similarity(article.embedding_vector, cluster.centroid_vector),
                        entity_overlap_score=1.0 if _shared_entity_names(group) else 0.0,
                        time_decay_score=1.0,
                        assignment_method=EventAssignmentMethod.BATCH,
                        is_representative=index == 0,
                    )
                )
                article.event_assignment_status = ProcessingStatus.DONE
            promoted.append(cluster)
        await db.commit()
        return promoted

    @staticmethod
    def _build_cluster(articles: list[Article]) -> EventCluster:
        source_ids = sorted({article.source_id for article in articles})
        first = articles[0]
        last = articles[-1]
        all_entities: list[dict] = []
        for article in articles:
            all_entities = merge_entities(all_entities, article.entities)
        importance_scores = [article.importance_score for article in articles if article.importance_score is not None]
        return EventCluster(
            title=first.title or "Untitled event",
            summary=first.cleaned_text,
            centroid_vector=centroid_vector(articles),
            canonical_entities=all_entities,
            importance_score=max(importance_scores) if importance_scores else None,
            first_seen_at=first.discovered_at or datetime.datetime.now(datetime.timezone.utc),
            last_seen_at=datetime.datetime.now(datetime.timezone.utc),
            last_article_at=last.published_at or last.discovered_at,
            article_count=len(articles),
            source_count=len(source_ids),
            metadata_json={"source_ids": source_ids, "topic_counts": _topic_counts(articles)},
        )
