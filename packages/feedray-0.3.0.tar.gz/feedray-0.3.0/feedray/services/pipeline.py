from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from feedray import config
from feedray.config import logger


PipelineHandler = Callable[[Any], Awaitable[None]]


@dataclass(slots=True)
class StageConfig:
    name: str
    maxsize: int = 100
    concurrency: int = 1
    max_retries: int = 2


@dataclass(slots=True)
class StageMetrics:
    processed: int = 0
    failed: int = 0
    retried: int = 0
    dead_lettered: int = 0
    queued: int = 0


@dataclass(slots=True)
class PipelineItem:
    payload: Any
    attempts: int = 0
    error: str | None = None


@dataclass(slots=True)
class PipelineStage:
    config: StageConfig
    handler: PipelineHandler
    queue: asyncio.Queue[PipelineItem] = field(init=False)
    dead_letters: list[PipelineItem] = field(default_factory=list)
    metrics: StageMetrics = field(default_factory=StageMetrics)
    _workers: list[asyncio.Task] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.queue = asyncio.Queue(maxsize=self.config.maxsize)

    async def start(self) -> None:
        if self._workers:
            return
        for index in range(self.config.concurrency):
            self._workers.append(asyncio.create_task(self._worker(index), name=f"{self.config.name}-{index}"))

    async def stop(self) -> None:
        for worker in self._workers:
            worker.cancel()
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()

    async def enqueue(self, payload: Any) -> None:
        await self.queue.put(PipelineItem(payload=payload))
        self.metrics.queued = self.queue.qsize()

    async def join(self) -> None:
        await self.queue.join()
        self.metrics.queued = self.queue.qsize()

    def backlog(self) -> int:
        return self.queue.qsize()

    async def _worker(self, index: int) -> None:
        while True:
            item = await self.queue.get()
            try:
                await self.handler(item.payload)
                self.metrics.processed += 1
            except Exception as exc:
                item.attempts += 1
                item.error = str(exc)
                if item.attempts <= self.config.max_retries:
                    self.metrics.retried += 1
                    await self.queue.put(item)
                else:
                    self.metrics.failed += 1
                    self.metrics.dead_lettered += 1
                    self.dead_letters.append(item)
                    logger.error(f"Pipeline stage {self.config.name} dead-lettered item: {exc}")
            finally:
                self.queue.task_done()
                self.metrics.queued = self.queue.qsize()


class AsyncArticlePipeline:
    def __init__(self) -> None:
        self.stages: dict[str, PipelineStage] = {}

    def add_stage(self, config: StageConfig, handler: PipelineHandler) -> PipelineStage:
        stage = PipelineStage(config=config, handler=handler)
        self.stages[config.name] = stage
        return stage

    async def start(self) -> None:
        for stage in self.stages.values():
            await stage.start()

    async def stop(self) -> None:
        for stage in self.stages.values():
            await stage.stop()

    async def enqueue(self, stage_name: str, payload: Any) -> None:
        await self.stages[stage_name].enqueue(payload)

    async def drain(self) -> None:
        for stage in self.stages.values():
            await stage.join()

    def metrics_snapshot(self) -> dict[str, dict[str, int]]:
        return {
            name: {
                "processed": stage.metrics.processed,
                "failed": stage.metrics.failed,
                "retried": stage.metrics.retried,
                "dead_lettered": stage.metrics.dead_lettered,
                "queued": stage.backlog(),
            }
            for name, stage in self.stages.items()
        }


async def noop_handler(payload: Any) -> None:
    return None


def build_default_article_pipeline(handler_overrides: dict[str, PipelineHandler] | None = None) -> AsyncArticlePipeline:
    handlers = handler_overrides or {}
    pipeline = AsyncArticlePipeline()
    stage_configs = [
        StageConfig("feed_fetch", config.PIPELINE_QUEUE_MAXSIZE, config.PIPELINE_FEED_FETCH_CONCURRENCY),
        StageConfig("article_fetch", config.PIPELINE_QUEUE_MAXSIZE, config.PIPELINE_ARTICLE_FETCH_CONCURRENCY),
        StageConfig("persistence", config.PIPELINE_QUEUE_MAXSIZE, 1),
        StageConfig("embedding", config.PIPELINE_QUEUE_MAXSIZE, config.PIPELINE_EMBEDDING_CONCURRENCY),
        StageConfig("chat_analysis", config.PIPELINE_QUEUE_MAXSIZE, config.PIPELINE_ANALYSIS_CONCURRENCY),
        StageConfig("event_assignment", config.PIPELINE_QUEUE_MAXSIZE, config.PIPELINE_EVENT_ASSIGNMENT_CONCURRENCY),
        StageConfig("event_compression", config.PIPELINE_QUEUE_MAXSIZE, config.PIPELINE_EVENT_COMPRESSION_CONCURRENCY),
    ]
    for stage_config in stage_configs:
        pipeline.add_stage(stage_config, handlers.get(stage_config.name, noop_handler))
    return pipeline
