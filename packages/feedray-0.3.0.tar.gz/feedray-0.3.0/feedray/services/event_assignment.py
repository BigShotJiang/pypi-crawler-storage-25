from __future__ import annotations

import datetime
import math
from dataclasses import dataclass
from typing import Any

import numpy as np
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from feedray import config
from feedray.db.models import (
    Article,
    EventArticle,
    EventAssignmentMethod,
    EventCluster,
    EventStatus,
    EventType,
    ProcessingStatus,
)
from feedray.services.event_utils import merge_entities


ENTITY_MATCH_TYPES = {"ORG", "GPE", "LOC", "EVENT", "PERSON", "PRODUCT", "TOPIC"}


@dataclass(slots=True)
class EventAssignmentWeights:
    semantic: float = config.EVENT_SEMANTIC_WEIGHT
    entity: float = config.EVENT_ENTITY_WEIGHT
    topic: float = config.EVENT_TOPIC_WEIGHT
    time: float = config.EVENT_TIME_WEIGHT
    source_diversity_bonus: float = config.EVENT_SOURCE_DIVERSITY_BONUS


@dataclass(slots=True)
class EventAssignmentThresholds:
    strong: float = config.EVENT_STRONG_ASSIGNMENT_THRESHOLD
    weak: float = config.EVENT_WEAK_ASSIGNMENT_THRESHOLD


@dataclass(slots=True)
class EventAssignmentScore:
    total: float
    semantic_similarity: float
    entity_overlap: float
    topic_overlap: float
    time_decay: float
    source_diversity_bonus: float


def _as_float_vector(vector: Any) -> np.ndarray | None:
    if vector is None:
        return None
    values = np.array(vector, dtype=float)
    if values.size == 0:
        return None
    return values


def cosine_similarity(left: Any, right: Any) -> float:
    left_vector = _as_float_vector(left)
    right_vector = _as_float_vector(right)
    if left_vector is None or right_vector is None or left_vector.shape != right_vector.shape:
        return 0.0
    denominator = float(np.linalg.norm(left_vector) * np.linalg.norm(right_vector))
    if denominator == 0:
        return 0.0
    return max(0.0, min(1.0, float(np.dot(left_vector, right_vector) / denominator)))


def _entity_names(entities: list[dict] | None) -> set[str]:
    names: set[str] = set()
    for item in entities or []:
        entity_type = str(item.get("entity_type") or "OTHER").upper()
        if entity_type not in ENTITY_MATCH_TYPES:
            continue
        canonical_name = str(item.get("canonical_name") or "").strip().lower()
        if canonical_name:
            names.add(canonical_name)
        for alias in item.get("aliases") or []:
            alias_text = str(alias).strip().lower()
            if alias_text:
                names.add(alias_text)
    return names


def entity_overlap(article_entities: list[dict] | None, cluster_entities: list[dict] | None) -> float:
    article_names = _entity_names(article_entities)
    cluster_names = _entity_names(cluster_entities)
    if not article_names or not cluster_names:
        return 0.0
    return len(article_names & cluster_names) / len(article_names)


def topic_overlap(article_topics: list[str] | None, cluster_metadata: dict | None) -> float:
    article_topic_set = {str(topic).upper() for topic in article_topics or [] if topic}
    topic_counts = (cluster_metadata or {}).get("topic_counts") or {}
    cluster_topic_set = {str(topic).upper() for topic in topic_counts.keys()}
    if not article_topic_set or not cluster_topic_set:
        return 0.0
    return len(article_topic_set & cluster_topic_set) / len(article_topic_set)


def time_decay_score(
    last_article_at: datetime.datetime | None,
    *,
    now: datetime.datetime | None = None,
    half_life_days: float = config.EVENT_TIME_DECAY_HALF_LIFE_DAYS,
) -> float:
    if last_article_at is None:
        return 1.0
    current = now or datetime.datetime.now(datetime.timezone.utc)
    if last_article_at.tzinfo is None:
        last_article_at = last_article_at.replace(tzinfo=datetime.timezone.utc)
    days = max(0.0, (current - last_article_at).total_seconds() / 86400.0)
    if half_life_days <= 0:
        return 0.0
    return float(math.exp(-math.log(2) * days / half_life_days))


def score_article_for_cluster(
    article: Article,
    cluster: EventCluster,
    *,
    weights: EventAssignmentWeights | None = None,
    now: datetime.datetime | None = None,
) -> EventAssignmentScore:
    resolved_weights = weights or EventAssignmentWeights()
    semantic = cosine_similarity(article.embedding_vector, cluster.centroid_vector)
    entity = entity_overlap(article.entities, cluster.canonical_entities)
    topic = topic_overlap(article.topics, cluster.metadata_json)
    time_score = time_decay_score(cluster.last_article_at, now=now)
    source_ids = set((cluster.metadata_json or {}).get("source_ids") or [])
    diversity_bonus = resolved_weights.source_diversity_bonus if article.source_id not in source_ids else 0.0
    total = (
        semantic * resolved_weights.semantic
        + entity * resolved_weights.entity
        + topic * resolved_weights.topic
        + time_score * resolved_weights.time
        + diversity_bonus
    )
    return EventAssignmentScore(
        total=round(total, 6),
        semantic_similarity=round(semantic, 6),
        entity_overlap=round(entity, 6),
        topic_overlap=round(topic, 6),
        time_decay=round(time_score, 6),
        source_diversity_bonus=round(diversity_bonus, 6),
    )


def _update_cluster_metadata(cluster: EventCluster, article: Article) -> dict:
    metadata = dict(cluster.metadata_json or {})
    source_ids = set(metadata.get("source_ids") or [])
    source_ids.add(article.source_id)
    topic_counts = dict(metadata.get("topic_counts") or {})
    for topic in article.topics or []:
        topic_counts[topic] = int(topic_counts.get(topic, 0)) + 1
    metadata["source_ids"] = sorted(source_ids)
    metadata["topic_counts"] = topic_counts
    return metadata


def _derive_event_importance(cluster: EventCluster, article: Article) -> int | None:
    scores = [score for score in [cluster.importance_score, article.importance_score] if score is not None]
    if not scores:
        return None
    base = max(scores)
    diversity_boost = 1 if cluster.source_count >= 3 else 0
    duration_boost = 0
    if cluster.first_seen_at and cluster.last_article_at:
        first_seen = cluster.first_seen_at
        last_seen = cluster.last_article_at
        if first_seen.tzinfo is None:
            first_seen = first_seen.replace(tzinfo=datetime.timezone.utc)
        if last_seen.tzinfo is None:
            last_seen = last_seen.replace(tzinfo=datetime.timezone.utc)
        duration_boost = 1 if (last_seen - first_seen).total_seconds() >= 86400 else 0
    single_article_penalty = 1 if cluster.article_count <= 1 else 0
    return max(1, min(10, base + diversity_boost + duration_boost - single_article_penalty))


class EventAssignmentService:
    def __init__(
        self,
        *,
        weights: EventAssignmentWeights | None = None,
        thresholds: EventAssignmentThresholds | None = None,
        active_lookback_days: int = config.EVENT_ACTIVE_LOOKBACK_DAYS,
    ) -> None:
        self.weights = weights or EventAssignmentWeights()
        self.thresholds = thresholds or EventAssignmentThresholds()
        self.active_lookback_days = active_lookback_days

    async def assign_article(self, db: AsyncSession, article: Article, *, force: bool = False) -> EventArticle | None:
        existing = (
            await db.execute(select(EventArticle).where(EventArticle.article_id == article.id))
        ).scalar_one_or_none()
        if existing and not force:
            article.event_assignment_status = ProcessingStatus.DONE
            return existing
        if existing and force:
            await db.delete(existing)
            await db.flush()

        if article.embedding_vector is None:
            article.event_assignment_status = ProcessingStatus.PENDING
            article.processing_error = {"stage": "event_assignment", "message": "Article has no embedding."}
            await db.commit()
            return None

        clusters = await self._load_candidate_clusters(db)
        best_cluster: EventCluster | None = None
        best_score: EventAssignmentScore | None = None
        now = datetime.datetime.now(datetime.timezone.utc)
        for cluster in clusters:
            score = score_article_for_cluster(article, cluster, weights=self.weights, now=now)
            if best_score is None or score.total > best_score.total:
                best_cluster = cluster
                best_score = score

        if best_cluster is None or best_score is None or best_score.total < self.thresholds.weak:
            article.event_assignment_status = ProcessingStatus.PENDING
            article.processing_error = None
            await db.commit()
            return None

        event_article = EventArticle(
            event_cluster_id=best_cluster.id,
            article_id=article.id,
            similarity_score=best_score.total,
            entity_overlap_score=best_score.entity_overlap,
            time_decay_score=best_score.time_decay,
            assignment_method=EventAssignmentMethod.INCREMENTAL,
            is_representative=best_cluster.article_count == 0,
        )
        db.add(event_article)
        self._update_cluster(best_cluster, article, score=best_score, now=now)
        article.event_assignment_status = ProcessingStatus.DONE
        article.processing_error = None
        await db.commit()
        await db.refresh(event_article)
        return event_article

    async def _load_candidate_clusters(self, db: AsyncSession) -> list[EventCluster]:
        cutoff = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=self.active_lookback_days)
        query = select(EventCluster).where(
            EventCluster.status.in_([EventStatus.ACTIVE, EventStatus.REACTIVATED, EventStatus.QUIET, EventStatus.ARCHIVED]),
            (
                (EventCluster.last_article_at.is_(None))
                | (EventCluster.last_article_at >= cutoff)
                | (EventCluster.event_type == EventType.LONG_RUNNING)
                | (EventCluster.status.in_([EventStatus.QUIET, EventStatus.ARCHIVED]))
            ),
        )
        return list((await db.execute(query)).scalars().all())

    def _update_cluster(
        self,
        cluster: EventCluster,
        article: Article,
        *,
        score: EventAssignmentScore,
        now: datetime.datetime,
    ) -> None:
        article_count = max(0, cluster.article_count)
        if cluster.centroid_vector is None:
            cluster.centroid_vector = article.embedding_vector
        else:
            current = _as_float_vector(cluster.centroid_vector)
            incoming = _as_float_vector(article.embedding_vector)
            if current is not None and incoming is not None and current.shape == incoming.shape:
                cluster.centroid_vector = ((current * article_count + incoming) / (article_count + 1)).tolist()

        cluster.article_count = article_count + 1
        cluster.last_seen_at = now
        cluster.last_article_at = article.published_at or article.discovered_at or now
        cluster.canonical_entities = merge_entities(cluster.canonical_entities, article.entities)
        cluster.metadata_json = _update_cluster_metadata(cluster, article)
        cluster.source_count = len(cluster.metadata_json.get("source_ids") or [])
        cluster.importance_score = _derive_event_importance(cluster, article)
        cluster.summary = cluster.summary or article.cleaned_text
        if not cluster.title:
            cluster.title = article.title or f"Event {cluster.id}"
        if score.total >= self.thresholds.strong and cluster.status in {EventStatus.QUIET, EventStatus.ARCHIVED}:
            cluster.status = EventStatus.REACTIVATED
