"""Service layer for Feedray."""
