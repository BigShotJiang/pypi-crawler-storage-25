from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from feedray.config import logger
from feedray.db.models import Article, ProcessingStatus
from feedray.services.model_runtime import get_chat_provider

ENTITY_TYPES = {"PERSON", "ORG", "GPE", "LOC", "EVENT", "PRODUCT", "TOPIC", "OTHER"}
TOPIC_TAXONOMY = {
    "POLITICS",
    "WORLD",
    "ECONOMY",
    "BUSINESS",
    "TECH_SCIENCE",
    "HEALTH",
    "CLIMATE",
    "ENERGY",
    "LAW_SECURITY",
    "WAR_CONFLICT",
    "SOCIETY",
    "DISASTER",
    "CULTURE_ENTERTAINMENT",
    "SPORTS",
    "OTHER",
}

IMPORTANCE_RUBRIC = """
你是新闻重要性分析器。重要性不等于热度。请根据公共影响而不是传播热度评分。

五个核心维度：
1. 影响范围：影响多少人、多少地区、多少机构。
2. 影响深度：对生命、安全、经济、制度的影响有多大。
3. 持续时间：影响是几小时、几天，还是几年。
4. 不可逆性：是否造成难以挽回的后果。
5. 连锁反应：是否会引发更多重大事件。

10级：历史转折级，改变全球历史走向、国际秩序或文明进程，跨代际影响。
9级：全球系统性冲击级，全球范围显著冲击，影响国际市场、国家安全或跨国社会运行。
8级：国家命运级/多国重大危机级，对一个大国或多个国家造成深远影响。
7级：全国头条级，一个国家范围主流媒体重点报道，引发广泛讨论。
6级：高公共关注级，区域、行业或社会群体影响明显。
5级：主流新闻级，当天重要新闻，有公共意义但直接影响有限。
4级：关注圈层级，对特定圈层、行业、城市、兴趣群体有意义。
3级：一般新闻级，有报道价值但公共影响较弱。
2级：边角信息级，低影响、低持续性、很少引发讨论。
1级：噪音级，几乎没有公共意义、标题党、重复旧闻或低价值信息。

操作判断：
死伤、战争、制度、金融系统触及越深越高；影响越跨地区/跨国越高；
持续越久越高；不看这条新闻是否会严重影响理解世界，答案为是则偏高。
"""

ANALYSIS_SYSTEM_PROMPT = f"""
{IMPORTANCE_RUBRIC}

只返回严格 JSON，不要 Markdown，不要代码块。JSON schema：
{{
  "importance_score": 1,
  "topics": ["POLITICS"],
  "entities": [
    {{
      "canonical_name": "实体标准名",
      "entity_type": "PERSON|ORG|GPE|LOC|EVENT|PRODUCT|TOPIC|OTHER",
      "aliases": ["别名"]
    }}
  ]
}}

topics 必须从以下固定分类中选择 1 到 3 个：
POLITICS, WORLD, ECONOMY, BUSINESS, TECH_SCIENCE, HEALTH, CLIMATE, ENERGY,
LAW_SECURITY, WAR_CONFLICT, SOCIETY, DISASTER, CULTURE_ENTERTAINMENT, SPORTS, OTHER。
只有没有更具体分类适合时才使用 OTHER。
"""


def content_hash(title: str | None, body: str | None) -> str:
    normalized = f"{title or ''}\n{body or ''}".strip().encode("utf-8")
    return hashlib.sha256(normalized).hexdigest()


def _clamp_int(value: Any, minimum: int, maximum: int, default: int) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        parsed = default
    return max(minimum, min(maximum, parsed))


def parse_analysis_json(raw_text: str) -> dict[str, Any]:
    text = raw_text.strip()
    if not text:
        raise ValueError("Empty analysis response.")
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
    if not text.startswith("{"):
        match = re.search(r"\{.*\}", text, flags=re.S)
        if not match:
            raise ValueError("Analysis response did not contain a JSON object.")
        text = match.group(0)

    payload = json.loads(text)
    entities = payload.get("entities") or []
    if not isinstance(entities, list):
        entities = []
    topics = payload.get("topics") or []

    return {
        "importance_score": _clamp_int(payload.get("importance_score"), 1, 10, 1),
        "topics": _normalize_topics(topics),
        "entities": [_normalize_entity(item) for item in entities if isinstance(item, dict)],
    }


def _normalize_topics(raw_topics: Any) -> list[str]:
    if not isinstance(raw_topics, list):
        raw_topics = []
    topics: list[str] = []
    for item in raw_topics:
        topic = str(item or "").strip().upper()
        if topic in TOPIC_TAXONOMY and topic not in topics:
            topics.append(topic)
        if len(topics) == 3:
            break
    return topics or ["OTHER"]


def _normalize_entity(item: dict[str, Any]) -> dict[str, Any]:
    entity_type = str(item.get("entity_type") or "OTHER").upper()
    if entity_type not in ENTITY_TYPES:
        entity_type = "OTHER"
    aliases = item.get("aliases") or []
    if not isinstance(aliases, list):
        aliases = []
    return {
        "canonical_name": str(item.get("canonical_name") or "").strip()[:255],
        "entity_type": entity_type,
        "aliases": [str(alias).strip()[:255] for alias in aliases if str(alias).strip()],
    }


class NewsAnalysisService:
    def __init__(self) -> None:
        self.chat_provider = get_chat_provider()

    async def analyze_article(self, db: AsyncSession, article: Article, *, force: bool = False) -> Article:
        if article.importance_score is not None and article.entities and article.topics and not force:
            return article
        if self.chat_provider is None:
            logger.warning("No chat provider configured; skipping article analysis.")
            article.analysis_status = ProcessingStatus.FAILED
            article.processing_error = {"stage": "analysis", "message": "No chat provider configured."}
            await db.commit()
            return article

        article_text = self._article_prompt(article)
        try:
            raw = self.chat_provider.complete(
                system_prompt=ANALYSIS_SYSTEM_PROMPT,
                user_prompt=article_text,
            )
            parsed = parse_analysis_json(raw)
            article.importance_score = parsed["importance_score"]
            article.topics = parsed["topics"]
            article.entities = parsed["entities"]
            article.analysis_status = ProcessingStatus.DONE
            article.processing_error = None
        except Exception as exc:
            logger.error(f"Failed to analyze article {article.id}: {exc}")
            article.analysis_status = ProcessingStatus.FAILED
            article.processing_error = {"stage": "analysis", "message": str(exc)}
            await db.commit()
            return article

        await db.commit()
        await db.refresh(article)
        return article

    @staticmethod
    def _article_prompt(article: Article) -> str:
        return (
            f"标题：{article.title or ''}\n"
            f"发布时间：{article.published_at or ''}\n"
            f"正文/摘要：\n{article.cleaned_text or ''}"
        )[:12000]
