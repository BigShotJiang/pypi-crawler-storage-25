from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv
from dotenv import dotenv_values
from loguru import logger

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent


def _env_bool(name: str, default: bool, *, dotenv: dict[str, str | None] | None = None) -> bool:
    raw = os.getenv(name)
    if raw is None and dotenv is not None:
        value = dotenv.get(name)
        raw = value if isinstance(value, str) else None
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on", "t"}


def _env_value(name: str, dotenv: dict[str, str | None]) -> str | None:
    raw = os.getenv(name)
    if raw is not None:
        return raw
    value = dotenv.get(name)
    return value if isinstance(value, str) else None


@dataclass(slots=True)
class AppSettings:
    embedding_vector_size: int = 256
    embedding_provider_type: str | None = None
    embedding_model_name: str | None = None
    embedding_base_url: str | None = None
    embedding_api_key: str | None = None
    chat_provider_type: str | None = None
    chat_model_name: str | None = None
    chat_base_url: str | None = None
    chat_api_key: str | None = None

    @classmethod
    def from_env(cls, *, base_dir: Path | None = None) -> AppSettings:
        resolved_base_dir = (base_dir or BASE_DIR).resolve()
        dotenv = dotenv_values(resolved_base_dir / ".env")
        return cls(
            embedding_vector_size=int(
                _env_value("FEEDRAY_EMBEDDING_VECTOR_SIZE", dotenv) or "256"
            ),
            embedding_provider_type=_env_value("FEEDRAY_EMBEDDING_PROVIDER_TYPE", dotenv)
            or "ollama",
            embedding_model_name=_env_value("FEEDRAY_EMBEDDING_MODEL_NAME", dotenv)
            or _env_value("EMBEDDING_MODEL_NAME", dotenv)
            or "qwen3-embedding:4b",
            embedding_base_url=_env_value("FEEDRAY_EMBEDDING_BASE_URL", dotenv),
            embedding_api_key=_env_value("FEEDRAY_EMBEDDING_API_KEY", dotenv),
            chat_provider_type=_env_value("FEEDRAY_CHAT_PROVIDER_TYPE", dotenv),
            chat_model_name=_env_value("FEEDRAY_CHAT_MODEL_NAME", dotenv),
            chat_base_url=_env_value("FEEDRAY_CHAT_BASE_URL", dotenv),
            chat_api_key=_env_value("FEEDRAY_CHAT_API_KEY", dotenv),
        )

    @property
    def has_embedding_provider(self) -> bool:
        return bool(self.embedding_provider_type and self.embedding_model_name)

    @property
    def has_chat_provider(self) -> bool:
        return bool(self.chat_provider_type and self.chat_model_name)


SETTINGS = AppSettings.from_env(base_dir=BASE_DIR)

DB_USER = os.getenv("DB_USER", "admin")
DB_PASSWORD = os.getenv("DB_PASSWORD", "admin")
DB_HOST = os.getenv("DB_HOST", "localhost")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME", "mydatabase")
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    f"postgresql+asyncpg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}",
)

USER_DATA_DIR = BASE_DIR / "chrome_profile"
EXTENSIONS_DIR = BASE_DIR / "extensions"
HEADLESS_MODE = _env_bool("HEADLESS_MODE", False)

EMBEDDING_VECTOR_SIZE = SETTINGS.embedding_vector_size
EMBEDDING_PROVIDER_TYPE = SETTINGS.embedding_provider_type
EMBEDDING_MODEL_NAME = SETTINGS.embedding_model_name

CHAT_PROVIDER_TYPE = SETTINGS.chat_provider_type
CHAT_MODEL_NAME = SETTINGS.chat_model_name

JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "a_very_secret_key_that_should_be_changed")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "30"))

SOURCES_CONFIG_PATH = BASE_DIR / "sources_config.yml"
GOOGLE_NEWS_SOURCES_PATH = BASE_DIR / "sources.yml"
DIRECT_RSS_SOURCES_PATH = BASE_DIR / "rss_sources.yml"
DEFAULT_CRAWL_INTERVAL_MINUTES = int(os.getenv("FEEDRAY_DEFAULT_CRAWL_INTERVAL_MINUTES", "60"))

EVENT_SEMANTIC_WEIGHT = float(os.getenv("FEEDRAY_EVENT_SEMANTIC_WEIGHT", "0.65"))
EVENT_ENTITY_WEIGHT = float(os.getenv("FEEDRAY_EVENT_ENTITY_WEIGHT", "0.20"))
EVENT_TOPIC_WEIGHT = float(os.getenv("FEEDRAY_EVENT_TOPIC_WEIGHT", "0.10"))
EVENT_TIME_WEIGHT = float(os.getenv("FEEDRAY_EVENT_TIME_WEIGHT", "0.05"))
EVENT_SOURCE_DIVERSITY_BONUS = float(os.getenv("FEEDRAY_EVENT_SOURCE_DIVERSITY_BONUS", "0.05"))
EVENT_STRONG_ASSIGNMENT_THRESHOLD = float(os.getenv("FEEDRAY_EVENT_STRONG_ASSIGNMENT_THRESHOLD", "0.82"))
EVENT_WEAK_ASSIGNMENT_THRESHOLD = float(os.getenv("FEEDRAY_EVENT_WEAK_ASSIGNMENT_THRESHOLD", "0.72"))
EVENT_ACTIVE_LOOKBACK_DAYS = int(os.getenv("FEEDRAY_EVENT_ACTIVE_LOOKBACK_DAYS", "14"))
EVENT_TIME_DECAY_HALF_LIFE_DAYS = float(os.getenv("FEEDRAY_EVENT_TIME_DECAY_HALF_LIFE_DAYS", "7"))
PIPELINE_QUEUE_MAXSIZE = int(os.getenv("FEEDRAY_PIPELINE_QUEUE_MAXSIZE", "100"))
PIPELINE_FEED_FETCH_CONCURRENCY = int(os.getenv("FEEDRAY_PIPELINE_FEED_FETCH_CONCURRENCY", "3"))
PIPELINE_ARTICLE_FETCH_CONCURRENCY = int(os.getenv("FEEDRAY_PIPELINE_ARTICLE_FETCH_CONCURRENCY", "5"))
PIPELINE_EMBEDDING_CONCURRENCY = int(os.getenv("FEEDRAY_PIPELINE_EMBEDDING_CONCURRENCY", "2"))
PIPELINE_ANALYSIS_CONCURRENCY = int(os.getenv("FEEDRAY_PIPELINE_ANALYSIS_CONCURRENCY", "2"))
PIPELINE_EVENT_ASSIGNMENT_CONCURRENCY = int(os.getenv("FEEDRAY_PIPELINE_EVENT_ASSIGNMENT_CONCURRENCY", "1"))
PIPELINE_EVENT_COMPRESSION_CONCURRENCY = int(os.getenv("FEEDRAY_PIPELINE_EVENT_COMPRESSION_CONCURRENCY", "1"))

LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)
logger.remove()
logger.add(sys.stderr, level=os.getenv("LOG_LEVEL", "INFO"))
logger.add(
    LOG_DIR / "app.log",
    rotation="10 MB",
    retention="7 days",
    level="DEBUG",
    enqueue=_env_bool("LOG_ENQUEUE", False),
    backtrace=True,
    diagnose=True,
)
