from __future__ import annotations

import datetime
import enum

from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    Index,
    String,
    Text,
    func,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from feedray.config import EMBEDDING_VECTOR_SIZE


class Base(DeclarativeBase):
    pass


def _enum_values(enum_class: type[enum.Enum]) -> list[str]:
    return [item.value for item in enum_class]


class ActivityType(enum.Enum):
    CLICK_RECOMMENDATION = "click_recommendation"
    SAVE_FOR_LATER = "save_for_later"
    LIKE = "like"
    DISLIKE = "dislike"


class ProcessingStatus(enum.Enum):
    PENDING = "pending"
    DONE = "done"
    FAILED = "failed"


class EventStatus(enum.Enum):
    ACTIVE = "active"
    QUIET = "quiet"
    ARCHIVED = "archived"
    REACTIVATED = "reactivated"


class EventType(enum.Enum):
    BREAKING = "breaking"
    DEVELOPING = "developing"
    LONG_RUNNING = "long_running"
    TREND = "trend"


class EventAssignmentMethod(enum.Enum):
    INCREMENTAL = "incremental"
    BATCH = "batch"
    MANUAL = "manual"


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    username: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    profile_vector = mapped_column(Vector(EMBEDDING_VECTOR_SIZE), nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    interests: Mapped[list["UserInterest"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    activities: Mapped[list["UserActivity"]] = relationship(back_populates="user", cascade="all, delete-orphan")


class UserInterest(Base):
    __tablename__ = "user_interests"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    keyword: Mapped[str] = mapped_column(Text)
    embedding_vector = mapped_column(Vector(EMBEDDING_VECTOR_SIZE))
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    user: Mapped["User"] = relationship(back_populates="interests")


class UserActivity(Base):
    __tablename__ = "user_activities"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    article_id: Mapped[int] = mapped_column(ForeignKey("articles.id"), index=True)
    activity_type: Mapped[ActivityType] = mapped_column(Enum(ActivityType), nullable=False, index=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    user: Mapped["User"] = relationship(back_populates="activities")
    article: Mapped["Article"] = relationship(back_populates="user_activities")


class Source(Base):
    __tablename__ = "sources"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    url: Mapped[str] = mapped_column(Text, unique=True)
    source_type: Mapped[str] = mapped_column(String(50), default="GOOGLE_NEWS", index=True)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    last_crawled_at: Mapped[datetime.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    crawl_interval_seconds: Mapped[int] = mapped_column(Integer, default=300)
    reliability_score: Mapped[int] = mapped_column(Integer, default=100, nullable=False)
    crawl_success_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    crawl_failure_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    last_error: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    articles: Mapped[list["Article"]] = relationship(back_populates="source")


class Article(Base):
    __tablename__ = "articles"

    id: Mapped[int] = mapped_column(primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("sources.id"), index=True)
    url: Mapped[str] = mapped_column(Text, unique=True, index=True)
    title: Mapped[str | None] = mapped_column(Text, nullable=True)
    cleaned_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    content_hash: Mapped[str | None] = mapped_column(String(64), index=True, nullable=True)
    published_at: Mapped[datetime.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    discovered_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    embedding_vector = mapped_column(Vector(EMBEDDING_VECTOR_SIZE), nullable=True)
    embedding_provider: Mapped[str | None] = mapped_column(String(50), nullable=True)
    embedding_model: Mapped[str | None] = mapped_column(String(255), nullable=True)
    embedded_at: Mapped[datetime.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    entities: Mapped[list[dict]] = mapped_column(JSON, default=list)
    topics: Mapped[list[str]] = mapped_column(JSON, default=list)
    importance_score: Mapped[int | None] = mapped_column(Integer, index=True, nullable=True)
    embedding_status: Mapped[ProcessingStatus] = mapped_column(
        Enum(ProcessingStatus, values_callable=_enum_values),
        default=ProcessingStatus.PENDING,
        nullable=False,
        index=True,
    )
    analysis_status: Mapped[ProcessingStatus] = mapped_column(
        Enum(ProcessingStatus, values_callable=_enum_values),
        default=ProcessingStatus.PENDING,
        nullable=False,
        index=True,
    )
    event_assignment_status: Mapped[ProcessingStatus] = mapped_column(
        Enum(ProcessingStatus, values_callable=_enum_values),
        default=ProcessingStatus.PENDING,
        nullable=False,
        index=True,
    )
    processing_error: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    source: Mapped["Source"] = relationship(back_populates="articles")
    images: Mapped[list["Image"]] = relationship(back_populates="article", cascade="all, delete-orphan")
    user_activities: Mapped[list["UserActivity"]] = relationship(back_populates="article")
    event_articles: Mapped[list["EventArticle"]] = relationship(back_populates="article", cascade="all, delete-orphan")


class EventCluster(Base):
    __tablename__ = "event_clusters"
    __table_args__ = (
        Index("ix_event_clusters_status_last_article", "status", "last_article_at"),
        Index("ix_event_clusters_importance_last_article", "importance_score", "last_article_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(Text)
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[EventStatus] = mapped_column(
        Enum(EventStatus, values_callable=_enum_values), default=EventStatus.ACTIVE, nullable=False, index=True
    )
    event_type: Mapped[EventType] = mapped_column(
        Enum(EventType, values_callable=_enum_values), default=EventType.DEVELOPING, nullable=False, index=True
    )
    centroid_vector = mapped_column(Vector(EMBEDDING_VECTOR_SIZE), nullable=True)
    canonical_entities: Mapped[list[dict]] = mapped_column(JSON, default=list)
    importance_score: Mapped[int | None] = mapped_column(Integer, index=True, nullable=True)
    first_seen_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    last_seen_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    last_article_at: Mapped[datetime.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    article_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    source_count: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    metadata_json: Mapped[dict] = mapped_column("metadata", JSON, default=dict)

    event_articles: Mapped[list["EventArticle"]] = relationship(
        back_populates="event_cluster", cascade="all, delete-orphan"
    )
    snapshots: Mapped[list["EventSnapshot"]] = relationship(back_populates="event_cluster", cascade="all, delete-orphan")
    user_activities: Mapped[list["UserEventActivity"]] = relationship(
        back_populates="event_cluster", cascade="all, delete-orphan"
    )


class EventArticle(Base):
    __tablename__ = "event_articles"
    __table_args__ = (
        Index("ix_event_articles_cluster_representative", "event_cluster_id", "is_representative"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_cluster_id: Mapped[int] = mapped_column(ForeignKey("event_clusters.id"), index=True)
    article_id: Mapped[int] = mapped_column(ForeignKey("articles.id"), unique=True, index=True)
    similarity_score: Mapped[float | None] = mapped_column(nullable=True)
    entity_overlap_score: Mapped[float | None] = mapped_column(nullable=True)
    time_decay_score: Mapped[float | None] = mapped_column(nullable=True)
    assignment_method: Mapped[EventAssignmentMethod] = mapped_column(
        Enum(EventAssignmentMethod, values_callable=_enum_values),
        default=EventAssignmentMethod.INCREMENTAL,
        nullable=False,
        index=True,
    )
    is_representative: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    event_cluster: Mapped["EventCluster"] = relationship(back_populates="event_articles")
    article: Mapped["Article"] = relationship(back_populates="event_articles")


class EventSnapshot(Base):
    __tablename__ = "event_snapshots"
    __table_args__ = (
        Index("ix_event_snapshots_event_snapshot_at", "event_cluster_id", "snapshot_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    event_cluster_id: Mapped[int] = mapped_column(ForeignKey("event_clusters.id"), index=True)
    snapshot_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    window_start_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    window_end_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    summary: Mapped[str] = mapped_column(Text)
    key_developments: Mapped[list[dict]] = mapped_column(JSON, default=list)
    representative_article_ids: Mapped[list[int]] = mapped_column(JSON, default=list)
    centroid_vector = mapped_column(Vector(EMBEDDING_VECTOR_SIZE), nullable=True)
    importance_score: Mapped[int | None] = mapped_column(Integer, nullable=True)

    event_cluster: Mapped["EventCluster"] = relationship(back_populates="snapshots")


class EventLink(Base):
    __tablename__ = "event_links"

    id: Mapped[int] = mapped_column(primary_key=True)
    source_event_id: Mapped[int] = mapped_column(ForeignKey("event_clusters.id"), index=True)
    target_event_id: Mapped[int] = mapped_column(ForeignKey("event_clusters.id"), index=True)
    relation: Mapped[str] = mapped_column(String(50), index=True)
    strength_score: Mapped[float | None] = mapped_column(nullable=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class UserEventActivity(Base):
    __tablename__ = "user_event_activities"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    event_cluster_id: Mapped[int] = mapped_column(ForeignKey("event_clusters.id"), index=True)
    activity_type: Mapped[ActivityType] = mapped_column(Enum(ActivityType), nullable=False, index=True)
    created_at: Mapped[datetime.datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    user: Mapped["User"] = relationship()
    event_cluster: Mapped["EventCluster"] = relationship(back_populates="user_activities")


class Image(Base):
    __tablename__ = "images"

    id: Mapped[int] = mapped_column(primary_key=True)
    article_id: Mapped[int] = mapped_column(ForeignKey("articles.id"), index=True)
    image_url: Mapped[str] = mapped_column(Text)
    storage_path: Mapped[str | None] = mapped_column(Text, nullable=True)

    article: Mapped["Article"] = relationship(back_populates="images")
