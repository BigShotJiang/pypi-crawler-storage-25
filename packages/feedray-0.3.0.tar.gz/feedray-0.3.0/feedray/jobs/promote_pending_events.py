from __future__ import annotations

import argparse
import asyncio

from feedray.config import logger
from feedray.db.session import AsyncSessionFactory
from feedray.services.pending_events import PendingEventPromotionService, PendingPromotionConfig


async def run_promotion(*, window_hours: int, min_articles: int, similarity_threshold: float) -> None:
    service = PendingEventPromotionService(
        PendingPromotionConfig(
            window_hours=window_hours,
            min_articles=min_articles,
            similarity_threshold=similarity_threshold,
        )
    )
    async with AsyncSessionFactory() as session:
        clusters = await service.promote_recent_pending(session)
        logger.info(f"Promoted {len(clusters)} pending event clusters.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Promote coherent pending articles into Feedray event clusters.")
    parser.add_argument("--window-hours", type=int, default=48)
    parser.add_argument("--min-articles", type=int, default=2)
    parser.add_argument("--similarity-threshold", type=float, default=0.78)
    args = parser.parse_args()
    asyncio.run(
        run_promotion(
            window_hours=args.window_hours,
            min_articles=args.min_articles,
            similarity_threshold=args.similarity_threshold,
        )
    )


if __name__ == "__main__":
    main()
