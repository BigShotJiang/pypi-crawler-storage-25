from __future__ import annotations

import asyncio
from urllib.parse import quote_plus

import yaml
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from feedray.config import (
    DEFAULT_CRAWL_INTERVAL_MINUTES,
    DIRECT_RSS_SOURCES_PATH,
    GOOGLE_NEWS_SOURCES_PATH,
    SOURCES_CONFIG_PATH,
    logger,
)
from feedray.db.models import Source
from feedray.db.session import AsyncSessionFactory
from feedray.scraping.browser_manager import BrowserManager
from feedray.scraping.crawler import ArticleCrawler


def _normalize_google_news_domains(source_config: dict) -> list[str]:
    domains = source_config.get("domains")
    if domains is None and source_config.get("domain"):
        domains = [source_config["domain"]]
    if not isinstance(domains, list):
        return []
    return [str(domain).strip() for domain in domains if str(domain).strip()]


def build_google_news_query(source_config: dict) -> str:
    domains = _normalize_google_news_domains(source_config)
    when_window = str(source_config.get("when", "1h")).strip()
    extra_query = str(source_config.get("query", "")).strip()

    parts: list[str] = []
    if domains:
        site_terms = [f"site:{domain}" for domain in domains]
        parts.append(site_terms[0] if len(site_terms) == 1 else f"({' OR '.join(site_terms)})")
    if extra_query:
        parts.append(extra_query)
    if when_window:
        parts.append(f"when:{when_window}")
    return " ".join(parts)


def generate_google_news_url(source_config: dict, category_config: dict) -> str:
    if not category_config:
        return ""
    query = build_google_news_query(source_config)
    if not query:
        return ""
    return (
        f"https://news.google.com/rss/search?q={quote_plus(query)}"
        f"&hl={category_config['lang']}&gl={category_config['gl']}&ceid={category_config['ceid']}"
    )


async def sync_and_get_config(session: AsyncSession) -> dict:
    logger.info("Starting full source synchronization...")
    unified_config: dict = {}
    with open(SOURCES_CONFIG_PATH, encoding="utf-8") as handle:
        category_configs = yaml.safe_load(handle)
        all_categories = {
            **category_configs.get("Countries", {}),
            **category_configs.get("Organizations", {}),
        }

    if GOOGLE_NEWS_SOURCES_PATH.exists():
        with open(GOOGLE_NEWS_SOURCES_PATH, encoding="utf-8") as handle:
            sources_by_category = yaml.safe_load(handle)
        for category, sources in sources_by_category.items():
            if category not in all_categories:
                continue
            for item in sources:
                name = f"{item['name']} ({category})"
                url = generate_google_news_url(item, all_categories[category])
                if not url:
                    logger.warning(f"Skipping Google News source with empty query: {name}")
                    continue
                unified_config[name] = item
                interval = item.get("crawl_interval_minutes", DEFAULT_CRAWL_INTERVAL_MINUTES) * 60
                enabled = item.get("enabled", True)
                db_source = (
                    await session.execute(select(Source).where(Source.name == name))
                ).scalar_one_or_none()
                if db_source:
                    db_source.url = url
                    db_source.crawl_interval_seconds = interval
                    db_source.enabled = enabled
                    db_source.source_type = "GOOGLE_NEWS"
                elif enabled:
                    session.add(
                        Source(
                            name=name,
                            url=url,
                            crawl_interval_seconds=interval,
                            enabled=True,
                            source_type="GOOGLE_NEWS",
                        )
                    )

    if DIRECT_RSS_SOURCES_PATH.exists():
        with open(DIRECT_RSS_SOURCES_PATH, encoding="utf-8") as handle:
            sources_by_key = yaml.safe_load(handle)
        for sources in sources_by_key.values():
            for item in sources:
                name = item["name"]
                unified_config[name] = item
                interval = item.get("crawl_interval_minutes", DEFAULT_CRAWL_INTERVAL_MINUTES) * 60
                enabled = item.get("enabled", True)
                db_source = (
                    await session.execute(select(Source).where(Source.name == name))
                ).scalar_one_or_none()
                if db_source:
                    db_source.url = item["url"]
                    db_source.crawl_interval_seconds = interval
                    db_source.enabled = enabled
                    db_source.source_type = "DIRECT_RSS"
                elif enabled:
                    session.add(
                        Source(
                            name=name,
                            url=item["url"],
                            crawl_interval_seconds=interval,
                            enabled=True,
                            source_type="DIRECT_RSS",
                        )
                    )

    all_active_sources = set(unified_config.keys())
    db_source_names = set((await session.execute(select(Source.name))).scalars().all())
    obsolete_sources = db_source_names - all_active_sources
    if obsolete_sources:
        await session.execute(
            update(Source).where(Source.name.in_(obsolete_sources)).values(enabled=False)
        )
    await session.commit()
    return unified_config


class CrawlRunner:
    def __init__(self, browser_context) -> None:
        self.browser_context = browser_context
        self.all_sources_config: dict = {}

    def update_config(self, new_config: dict) -> None:
        self.all_sources_config = new_config

    async def crawl_for_interval(self, interval_seconds: int) -> None:
        async with AsyncSessionFactory() as session:
            sources_to_crawl = (
                await session.execute(
                    select(Source).where(
                        Source.enabled == True,
                        Source.crawl_interval_seconds == interval_seconds,
                    )
                )
            ).scalars().all()
        if not sources_to_crawl:
            logger.warning(f"No enabled sources found for {interval_seconds // 60} minutes.")
            return
        crawler = ArticleCrawler(context=self.browser_context)
        await asyncio.gather(
            *[crawler.crawl_source(source, self.all_sources_config) for source in sources_to_crawl]
        )


class SchedulerManager:
    def __init__(self, scheduler: AsyncIOScheduler, runner: CrawlRunner) -> None:
        self.scheduler = scheduler
        self.runner = runner

    async def sync_jobs(self) -> None:
        async with AsyncSessionFactory() as session:
            db_intervals = set(
                (
                    await session.execute(
                        select(Source.crawl_interval_seconds).where(Source.enabled == True).distinct()
                    )
                ).scalars().all()
            )
        scheduled_intervals = {int(job.id.split("_")[-1]) for job in self.scheduler.get_jobs()}
        for interval in db_intervals - scheduled_intervals:
            self.scheduler.add_job(
                self.runner.crawl_for_interval,
                "interval",
                seconds=interval,
                id=f"crawl_job_{interval}",
                args=[interval],
            )
        for interval in scheduled_intervals - db_intervals:
            job_id = f"crawl_job_{interval}"
            if self.scheduler.get_job(job_id):
                self.scheduler.remove_job(job_id)


async def main_orchestrator() -> None:
    scheduler = AsyncIOScheduler(timezone="UTC")
    async with BrowserManager() as context:
        runner = CrawlRunner(browser_context=context)
        manager = SchedulerManager(scheduler, runner)
        scheduler.start()
        try:
            while True:
                async with AsyncSessionFactory() as session:
                    latest_config = await sync_and_get_config(session)
                runner.update_config(latest_config)
                await manager.sync_jobs()
                await asyncio.sleep(300)
        except (KeyboardInterrupt, SystemExit):
            logger.info("Crawler orchestrator shutting down.")
            scheduler.shutdown()


def main() -> None:
    asyncio.run(main_orchestrator())


if __name__ == "__main__":
    main()
