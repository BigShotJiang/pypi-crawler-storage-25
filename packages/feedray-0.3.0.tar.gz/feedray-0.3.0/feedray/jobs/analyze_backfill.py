from __future__ import annotations

import argparse
import asyncio
import datetime

from sqlalchemy import select, text

from feedray.config import EMBEDDING_MODEL_NAME, EMBEDDING_PROVIDER_TYPE, logger
from feedray.db.models import Article, ProcessingStatus
from feedray.db.session import AsyncSessionFactory
from feedray.services.analysis import NewsAnalysisService, content_hash
from feedray.services.event_assignment import EventAssignmentService
from feedray.services.model_runtime import embed_text


async def run_backfill(*, force: bool, limit: int | None) -> None:
    analysis_service = NewsAnalysisService()
    event_assignment_service = EventAssignmentService()
    async with AsyncSessionFactory() as session:
        query = select(Article).order_by(Article.discovered_at.desc())
        if not force:
            query = query.where(
                (Article.importance_score.is_(None))
                | (Article.entities.is_(None))
                | text("entities::text = '[]'")
                | (Article.topics.is_(None))
                | text("topics::text = '[]'")
            )
        if limit:
            query = query.limit(limit)
        articles = (await session.execute(query)).scalars().all()

        for article in articles:
            if not article.content_hash:
                article.content_hash = content_hash(article.title, article.cleaned_text)
            if force or article.embedding_vector is None:
                embedding = embed_text(f"{article.title or ''}\n{article.cleaned_text or ''}")
                if embedding:
                    article.embedding_vector = embedding
                    article.embedding_provider = EMBEDDING_PROVIDER_TYPE
                    article.embedding_model = EMBEDDING_MODEL_NAME
                    article.embedded_at = datetime.datetime.now(datetime.timezone.utc)
                    article.embedding_status = ProcessingStatus.DONE
                else:
                    article.embedding_status = ProcessingStatus.PENDING
            await session.flush()
            await analysis_service.analyze_article(session, article, force=force)
            await event_assignment_service.assign_article(session, article, force=force)
            logger.info(f"Backfilled article {article.id}: {article.title}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Backfill Feedray article analysis.")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--force", action="store_true", help="Re-run analysis for all selected articles.")
    mode.add_argument("--missing-only", action="store_true", help="Only analyze articles without analysis.")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()
    asyncio.run(run_backfill(force=args.force, limit=args.limit))


if __name__ == "__main__":
    main()
