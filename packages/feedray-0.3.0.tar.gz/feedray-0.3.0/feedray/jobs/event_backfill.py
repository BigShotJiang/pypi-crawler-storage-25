from __future__ import annotations

import argparse
import asyncio

from sqlalchemy import select

from feedray.config import logger
from feedray.db.models import Article, EventArticle
from feedray.db.session import AsyncSessionFactory
from feedray.services.event_assignment import EventAssignmentService


async def run_backfill(*, force: bool, missing_only: bool, limit: int | None) -> None:
    assignment_service = EventAssignmentService()
    async with AsyncSessionFactory() as session:
        query = select(Article).where(Article.embedding_vector.is_not(None)).order_by(Article.discovered_at.desc())
        if missing_only:
            assigned_article_ids = select(EventArticle.article_id)
            query = query.where(Article.id.not_in(assigned_article_ids))
        if limit:
            query = query.limit(limit)

        articles = (await session.execute(query)).scalars().all()
        for article in articles:
            event_article = await assignment_service.assign_article(session, article, force=force)
            if event_article:
                logger.info(f"Assigned article {article.id} to event {event_article.event_cluster_id}.")
            else:
                logger.info(f"Article {article.id} remains pending for event assignment.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Backfill Feedray article-to-event assignments.")
    parser.add_argument("--force", action="store_true", help="Re-run assignment even when an article was assigned.")
    parser.add_argument("--missing-only", action="store_true", help="Only assign articles without event links.")
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()
    asyncio.run(run_backfill(force=args.force, missing_only=args.missing_only, limit=args.limit))


if __name__ == "__main__":
    main()
