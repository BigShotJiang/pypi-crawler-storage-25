from __future__ import annotations

import argparse
import asyncio

from feedray.config import logger
from feedray.db.session import AsyncSessionFactory
from feedray.services.event_compression import archive_stale_events


async def run_archive(*, quiet_after_hours: int, archive_after_hours: int) -> None:
    async with AsyncSessionFactory() as session:
        counts = await archive_stale_events(
            session,
            quiet_after_hours=quiet_after_hours,
            archive_after_hours=archive_after_hours,
        )
        logger.info(f"Event lifecycle update: {counts}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Move stale Feedray events to quiet or archived lifecycle states.")
    parser.add_argument("--quiet-after-hours", type=int, default=48)
    parser.add_argument("--archive-after-hours", type=int, default=168)
    args = parser.parse_args()
    asyncio.run(run_archive(quiet_after_hours=args.quiet_after_hours, archive_after_hours=args.archive_after_hours))


if __name__ == "__main__":
    main()
