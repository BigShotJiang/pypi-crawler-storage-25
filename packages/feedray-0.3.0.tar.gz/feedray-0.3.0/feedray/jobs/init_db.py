from __future__ import annotations

import asyncio

from sqlalchemy import text

from feedray.config import DB_NAME, logger
from feedray.db.models import Base
from feedray.db.session import async_engine


async def init_database() -> None:
    async with async_engine.begin() as conn:
        logger.info("Dropping all existing tables...")
        await conn.run_sync(Base.metadata.drop_all)
        logger.info("Creating pgvector extension...")
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        logger.info("Creating all tables...")
        await conn.run_sync(Base.metadata.create_all)
    logger.success("Database tables created successfully.")


def main() -> None:
    logger.info(f"Starting database initialization for '{DB_NAME}'...")
    asyncio.run(init_database())
    logger.info("Initialization complete. Run `python -m feedray.jobs.crawler` to start crawling.")


if __name__ == "__main__":
    main()
