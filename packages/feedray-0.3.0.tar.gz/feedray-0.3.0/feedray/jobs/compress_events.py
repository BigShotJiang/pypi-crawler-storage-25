from __future__ import annotations

import argparse
import asyncio

from feedray.config import logger
from feedray.db.session import AsyncSessionFactory
from feedray.services.event_compression import EventCompressionConfig, EventCompressionService


async def run_compression(*, window_hours: int, limit: int | None) -> None:
    service = EventCompressionService(EventCompressionConfig(window_hours=window_hours))
    async with AsyncSessionFactory() as session:
        snapshots = await service.compress_active_events(session, limit=limit)
        logger.info(f"Created {len(snapshots)} event snapshots.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Compress active Feedray events into snapshots.")
    parser.add_argument("--window-hours", type=int, default=24)
    parser.add_argument("--limit", type=int, default=None)
    args = parser.parse_args()
    asyncio.run(run_compression(window_hours=args.window_hours, limit=args.limit))


if __name__ == "__main__":
    main()
