import pytest

from feedray.config import AppSettings
from feedray.providers.factory import (
    UnsupportedProviderError,
    build_chat_provider,
    build_embedding_provider,
)


def test_factory_rejects_anthropic_embeddings() -> None:
    settings = AppSettings()
    settings.embedding_provider_type = "anthropic"
    settings.embedding_model_name = "claude-3-7-sonnet-latest"

    with pytest.raises(UnsupportedProviderError):
        build_embedding_provider(settings)


def test_factory_allows_supported_chat_provider_without_instantiation_errors() -> None:
    settings = AppSettings()
    settings.chat_provider_type = "anthropic"
    settings.chat_model_name = "claude-3-7-sonnet-latest"
    settings.chat_api_key = "dummy"

    provider = build_chat_provider(settings)
    assert provider is not None
