from feedray.db.models import Base


def test_analysis_tables_are_registered():
    assert "articles" in Base.metadata.tables
    article_columns = set(Base.metadata.tables["articles"].columns.keys())
    assert {
        "entities",
        "topics",
        "importance_score",
        "embedding_status",
        "analysis_status",
        "event_assignment_status",
        "processing_error",
    } <= article_columns


def test_event_tables_are_registered():
    assert "event_clusters" in Base.metadata.tables
    assert "event_articles" in Base.metadata.tables
    assert "event_snapshots" in Base.metadata.tables
    assert "event_links" in Base.metadata.tables
    assert "user_event_activities" in Base.metadata.tables
    cluster_columns = set(Base.metadata.tables["event_clusters"].columns.keys())
    article_columns = set(Base.metadata.tables["event_articles"].columns.keys())
    assert {
        "title",
        "summary",
        "status",
        "event_type",
        "centroid_vector",
        "canonical_entities",
        "importance_score",
        "metadata",
    } <= cluster_columns
    assert {
        "event_cluster_id",
        "article_id",
        "similarity_score",
        "entity_overlap_score",
        "time_decay_score",
        "assignment_method",
        "is_representative",
    } <= article_columns
    snapshot_columns = set(Base.metadata.tables["event_snapshots"].columns.keys())
    assert {
        "event_cluster_id",
        "snapshot_at",
        "window_start_at",
        "window_end_at",
        "summary",
        "key_developments",
        "representative_article_ids",
        "centroid_vector",
        "importance_score",
    } <= snapshot_columns


def test_source_reliability_columns_are_registered():
    source_columns = set(Base.metadata.tables["sources"].columns.keys())
    assert {
        "reliability_score",
        "crawl_success_count",
        "crawl_failure_count",
        "last_error",
    } <= source_columns
