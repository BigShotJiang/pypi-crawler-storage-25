from feedray.services.analysis import parse_analysis_json


def test_parse_analysis_json_clamps_scores_and_entities():
    payload = """
    {
      "importance_score": 11,
      "topics": ["business", "INVALID", "TECH_SCIENCE", "WORLD"],
      "entities": [
        {
          "canonical_name": "OpenAI",
          "entity_type": "ORG",
          "aliases": ["OA"]
        }
      ]
    }
    """

    result = parse_analysis_json(payload)

    assert result["importance_score"] == 10
    assert result["topics"] == ["BUSINESS", "TECH_SCIENCE", "WORLD"]
    assert result["entities"][0]["entity_type"] == "ORG"
    assert result["entities"][0]["canonical_name"] == "OpenAI"


def test_parse_analysis_json_extracts_json_from_wrapped_text():
    payload = 'model says:\n{"importance_score":3,"entities":[]}'

    result = parse_analysis_json(payload)

    assert result["importance_score"] == 3
    assert result["topics"] == ["OTHER"]
    assert result["entities"] == []
