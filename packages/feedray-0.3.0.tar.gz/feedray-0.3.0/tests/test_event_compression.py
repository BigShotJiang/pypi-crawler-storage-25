import datetime

from feedray.db.models import EventCluster, EventStatus
from feedray.services.event_compression import lifecycle_status_for_event


def test_lifecycle_moves_active_event_to_quiet_when_stale():
    now = datetime.datetime.now(datetime.timezone.utc)
    cluster = EventCluster(
        title="Old event",
        status=EventStatus.ACTIVE,
        last_article_at=now - datetime.timedelta(hours=72),
    )

    assert (
        lifecycle_status_for_event(
            cluster,
            now=now,
            quiet_after_hours=48,
            archive_after_hours=168,
        )
        == EventStatus.QUIET
    )


def test_lifecycle_archives_quiet_event_when_older_than_archive_window():
    now = datetime.datetime.now(datetime.timezone.utc)
    cluster = EventCluster(
        title="Very old event",
        status=EventStatus.QUIET,
        last_article_at=now - datetime.timedelta(hours=200),
    )

    assert (
        lifecycle_status_for_event(
            cluster,
            now=now,
            quiet_after_hours=48,
            archive_after_hours=168,
        )
        == EventStatus.ARCHIVED
    )
