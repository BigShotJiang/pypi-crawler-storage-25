import datetime

from feedray.db.models import Article, EventCluster
from feedray.services.event_assignment import (
    EventAssignmentWeights,
    entity_overlap,
    score_article_for_cluster,
    time_decay_score,
    topic_overlap,
)


def _article(**overrides):
    defaults = {
        "source_id": 2,
        "url": "https://example.com/a",
        "title": "Chip company announces AI accelerator",
        "embedding_vector": [1.0, 0.0, 0.0],
        "entities": [{"canonical_name": "Nvidia", "entity_type": "ORG", "aliases": ["NVDA"]}],
        "topics": ["TECH_SCIENCE", "BUSINESS"],
        "importance_score": 6,
    }
    defaults.update(overrides)
    return Article(**defaults)


def _cluster(**overrides):
    now = datetime.datetime.now(datetime.timezone.utc)
    defaults = {
        "title": "AI chip race",
        "centroid_vector": [0.95, 0.05, 0.0],
        "canonical_entities": [{"canonical_name": "Nvidia", "entity_type": "ORG", "aliases": []}],
        "metadata_json": {"topic_counts": {"TECH_SCIENCE": 3}, "source_ids": [1]},
        "last_article_at": now,
        "first_seen_at": now,
        "article_count": 3,
        "source_count": 1,
        "importance_score": 6,
    }
    defaults.update(overrides)
    return EventCluster(**defaults)


def test_entity_overlap_scores_shared_entities():
    assert entity_overlap(_article().entities, _cluster().canonical_entities) > 0


def test_topic_overlap_scores_shared_topics():
    assert topic_overlap(["TECH_SCIENCE", "BUSINESS"], {"topic_counts": {"TECH_SCIENCE": 2}}) == 0.5


def test_event_assignment_score_uses_semantic_entity_topic_and_source_bonus():
    score = score_article_for_cluster(_article(), _cluster(), weights=EventAssignmentWeights())

    assert score.total >= 0.72
    assert score.semantic_similarity > 0.99
    assert score.entity_overlap > 0
    assert score.topic_overlap == 0.5
    assert score.source_diversity_bonus > 0


def test_low_similarity_article_falls_below_pending_threshold():
    score = score_article_for_cluster(
        _article(embedding_vector=[0.0, 1.0, 0.0], entities=[], topics=["SPORTS"]),
        _cluster(metadata_json={"topic_counts": {"TECH_SCIENCE": 3}, "source_ids": [2]}),
    )

    assert score.total < 0.72


def test_old_cluster_time_decay_requires_stronger_match():
    recent = time_decay_score(datetime.datetime.now(datetime.timezone.utc))
    stale = time_decay_score(datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(days=30))

    assert stale < recent
