from feedray.jobs.crawler import build_google_news_query, generate_google_news_url


def test_build_google_news_query_supports_multiple_domains():
    query = build_google_news_query(
        {
            "domains": ["bbc.com", "bloomberg.com"],
            "when": "4h",
        }
    )

    assert query == "(site:bbc.com OR site:bloomberg.com) when:4h"


def test_generate_google_news_url_supports_legacy_single_domain():
    url = generate_google_news_url(
        {"domain": "bbc.com"},
        {"lang": "en", "gl": "US", "ceid": "US:en"},
    )

    assert "site%3Abbc.com+when%3A1h" in url
    assert "&hl=en&gl=US&ceid=US:en" in url


def test_generate_google_news_url_supports_grouped_domains_and_extra_query():
    url = generate_google_news_url(
        {
            "domains": ["bbc.com", "bloomberg.com"],
            "query": "AI",
            "when": "12h",
        },
        {"lang": "en", "gl": "GB", "ceid": "GB:en"},
    )

    assert "%28site%3Abbc.com+OR+site%3Abloomberg.com%29+AI+when%3A12h" in url
    assert "&hl=en&gl=GB&ceid=GB:en" in url
