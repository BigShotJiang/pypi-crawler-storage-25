import datetime

from feedray.db.models import Article
from feedray.services.pending_events import cluster_pending_articles


def _article(article_id, vector, *, entity="OpenAI", topic="TECH_SCIENCE"):
    return Article(
        id=article_id,
        source_id=article_id,
        url=f"https://example.com/{article_id}",
        title=f"Article {article_id}",
        embedding_vector=vector,
        entities=[{"canonical_name": entity, "entity_type": "ORG", "aliases": []}],
        topics=[topic],
        discovered_at=datetime.datetime.now(datetime.timezone.utc),
    )


def test_pending_articles_promote_coherent_group():
    clusters = cluster_pending_articles(
        [
            _article(1, [1.0, 0.0]),
            _article(2, [0.98, 0.02]),
            _article(3, [0.0, 1.0], entity="NBA", topic="SPORTS"),
        ],
        min_articles=2,
        similarity_threshold=0.9,
    )

    assert len(clusters) == 1
    assert [article.id for article in clusters[0]] == [1, 2]


def test_pending_articles_do_not_promote_isolated_articles():
    clusters = cluster_pending_articles(
        [
            _article(1, [1.0, 0.0], entity="OpenAI"),
            _article(2, [0.0, 1.0], entity="NBA", topic="SPORTS"),
        ],
        min_articles=2,
        similarity_threshold=0.9,
    )

    assert clusters == []
