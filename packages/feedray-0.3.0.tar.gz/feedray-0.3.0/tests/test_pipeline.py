import asyncio

import pytest

from feedray.services.pipeline import AsyncArticlePipeline, StageConfig, build_default_article_pipeline


@pytest.fixture
def anyio_backend():
    return "asyncio"


def test_default_pipeline_has_expected_stages():
    pipeline = build_default_article_pipeline()

    assert list(pipeline.stages.keys()) == [
        "feed_fetch",
        "article_fetch",
        "persistence",
        "embedding",
        "chat_analysis",
        "event_assignment",
        "event_compression",
    ]


@pytest.mark.anyio
async def test_pipeline_processes_items_and_reports_metrics():
    seen = []

    async def handler(payload):
        seen.append(payload)

    pipeline = AsyncArticlePipeline()
    pipeline.add_stage(StageConfig(name="analysis", maxsize=2, concurrency=2), handler)
    await pipeline.start()
    await pipeline.enqueue("analysis", "a")
    await pipeline.enqueue("analysis", "b")
    await pipeline.drain()
    await pipeline.stop()

    assert sorted(seen) == ["a", "b"]
    assert pipeline.metrics_snapshot()["analysis"]["processed"] == 2


@pytest.mark.anyio
async def test_pipeline_retries_then_dead_letters_failed_items():
    attempts = 0

    async def handler(payload):
        nonlocal attempts
        attempts += 1
        raise RuntimeError("boom")

    pipeline = AsyncArticlePipeline()
    stage = pipeline.add_stage(StageConfig(name="event_assignment", maxsize=2, concurrency=1, max_retries=1), handler)
    await pipeline.start()
    await pipeline.enqueue("event_assignment", {"article_id": 1})
    await asyncio.wait_for(pipeline.drain(), timeout=2)
    await pipeline.stop()

    metrics = pipeline.metrics_snapshot()["event_assignment"]
    assert attempts == 2
    assert metrics["retried"] == 1
    assert metrics["dead_lettered"] == 1
    assert len(stage.dead_letters) == 1
