from fastapi.testclient import TestClient

from feedray.api.app import app


def test_root_route():
    response = TestClient(app).get("/")

    assert response.status_code == 200
    assert response.json()["message"] == "Welcome to Feedray API."
