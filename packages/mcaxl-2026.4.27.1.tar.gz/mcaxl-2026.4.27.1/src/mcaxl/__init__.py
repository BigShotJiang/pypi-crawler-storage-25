"""mcaxl — read-only MCP server for CUCM 15 AXL."""

from .server import main

__all__ = ["main"]
