"""FastMCP server: read-only CUCM 15 AXL with route-plan focus.

Tool surface:
  - Foundational: axl_sql, axl_describe_table, axl_list_tables, axl_version,
    cache_stats, cache_clear
  - Route plan: route_partitions, route_calling_search_spaces, route_patterns,
    route_inspect_pattern, route_lists_and_groups, route_translation_chain,
    route_digit_discard_instructions

Prompts (schema-grounded via the sibling cisco-docs index):
  - route_plan_overview
  - investigate_pattern
  - audit_routing
  - cucm_sql_help
"""

from __future__ import annotations

import os
import sys
from importlib.metadata import version as _pkg_version
from pathlib import Path

from dotenv import load_dotenv
from fastmcp import FastMCP
from platformdirs import user_cache_dir

from . import route_plan
from .cache import AxlCache
from .client import AxlClient
from .docs_loader import DocsIndex
from .risport import RisPortClient


# ---- Module-level singletons, initialized in main() ----
_cache: AxlCache | None = None
_axl: AxlClient | None = None
_docs: DocsIndex | None = None
_ris: RisPortClient | None = None


mcp = FastMCP("CUCM AXL (read-only)")


def _client() -> AxlClient:
    if _axl is None:
        raise RuntimeError("AXL client not initialized — server bootstrap failed.")
    return _axl


# ====================================================================
# Foundational tools
# ====================================================================

@mcp.tool
def axl_version() -> dict:
    """Return CUCM cluster version. Sanity check that AXL is reachable.

    Cached for 1 hour — version doesn't change between cluster upgrades.
    """
    return _client().get_ccm_version()


@mcp.tool
def axl_sql(query: str) -> dict:
    """Execute a SELECT (or WITH CTE) against the CUCM Informix data dictionary.

    Read-only by structural guarantee: the server never exposes executeSQLUpdate
    or any add/update/remove AXL methods. Queries are also client-side validated
    to start with SELECT or WITH and to contain no write keywords.

    Args:
        query: A single SQL SELECT statement. Trailing semicolon optional.

    Returns:
        dict with row_count, rows (list of column→value dicts), and the
        cleaned query as it was sent. Includes _cache: hit|miss for diagnostics.
    """
    return _client().execute_sql_query(query)


@mcp.tool
def axl_list_tables(pattern: str | None = None) -> dict:
    """List Informix tables in the CUCM database.

    Args:
        pattern: Optional LIKE pattern (% wildcards). e.g. "route%" finds
            routelist, routegroup, routepartition, routefilter, etc.
    """
    return _client().list_informix_tables(pattern)


@mcp.tool
def axl_describe_table(table_name: str) -> dict:
    """Describe an Informix table's columns: name, type, length, nullability.

    Use this BEFORE writing axl_sql queries against an unfamiliar table.
    Combine with the cisco-docs MCP's search_docs("data dictionary <table>")
    for human-authored descriptions of what each column means.
    """
    return _client().describe_informix_table(table_name)


def _require_cache() -> AxlCache:
    """Hamilton review MINOR #7: tools that need the cache should raise
    consistently when it's missing — same shape as `_client()` for `_axl`.
    Pre-fix, cache tools returned `{"error": "..."}` while AXL tools raised
    RuntimeError; LLMs had to handle two patterns. Now: all tool failures
    raise RuntimeError uniformly.
    """
    if _cache is None:
        raise RuntimeError("Cache not initialized — server bootstrap failed.")
    return _cache


@mcp.tool
def cache_stats() -> dict:
    """Cache statistics: total entries, live entries, breakdown by method."""
    return _require_cache().stats()


@mcp.tool
def cache_clear(method_pattern: str | None = None) -> dict:
    """Clear cache entries for the current cluster.

    Args:
        method_pattern: Optional method-name pattern (% wildcards). If omitted,
            clears the entire cache. Use after a known config change to force
            fresh queries.
    """
    deleted = _require_cache().clear(method_pattern)
    return {"deleted_entries": deleted, "method_pattern": method_pattern}


@mcp.tool
def health() -> dict:
    """Server-state self-check: which globals are initialized?

    Useful when a tool call returns "not initialized" — surfaces which
    subsystem (cache, AXL client, docs index) actually failed at bootstrap.
    Also reports the AXL connection state from connection_status() so an
    operator can see whether a recent operational error has cleared.
    """
    info = {
        "cache": _cache is not None,
        "axl": _axl is not None,
        "docs": _docs is not None,
        "risport": _ris is not None,
    }
    if _axl is not None:
        info["axl_connection"] = _axl.connection_status()
    if _cache is not None:
        try:
            info["cache_cluster_id"] = _cache.cluster_id
        except AttributeError:
            pass
    return info


# ====================================================================
# Route plan tools
# ====================================================================

@mcp.tool
def route_partitions() -> dict:
    """All route partitions, with pattern count and CSS member count per partition.

    A partition groups together patterns (DNs, route patterns, translations) for
    access control. CSSs include partitions in a specific order; longest match
    in the first reachable partition wins.
    """
    return route_plan.list_partitions(_client())


@mcp.tool
def route_calling_search_spaces(name: str | None = None) -> dict:
    """Calling Search Spaces with their ordered partition lists.

    Args:
        name: Optional CSS name to fetch one specific CSS. If None, returns all.

    The order of partitions inside a CSS is the search order — CUCM walks the
    partitions top-down, longest-match within each, and routes via the first
    matching pattern.
    """
    return route_plan.list_calling_search_spaces(_client(), name)


@mcp.tool
def route_patterns(
    kind: str | None = None,
    partition: str | None = None,
    filter: str | None = None,
    limit: int = 500,
) -> dict:
    """The Route Plan Report — patterns with their transformations.

    Args:
        kind: Pattern kind filter. One of: directory_number, translation, route,
            conference, voicemail, hunt_pilot, call_pickup_group, park_code,
            directed_pickup, message_waiting, device_template. Default: all kinds.
        partition: Filter by partition name (exact match).
        filter: Substring match against the pattern text (e.g. "9.@" or "+1").
        limit: Max rows. Default 500.

    Each row includes calling/called party transformation masks, prefix digits,
    digit discard instructions — the full transformation profile.
    """
    return route_plan.list_patterns(
        _client(),
        kind=kind,
        partition=partition,
        filter_substring=filter,
        limit=limit,
    )


@mcp.tool
def route_inspect_pattern(pattern: str, partition: str | None = None) -> dict:
    """Deep dive on a single pattern.

    Returns:
      - The pattern row itself with all transformations
      - Reverse CSS lookup: which calling search spaces include this pattern's
        partition (i.e., which phones/devices can reach this pattern)
      - Routing target: route list or device this pattern points to

    Args:
        pattern: The pattern text (e.g. "9.@", "+1.[2-9]XX[2-9]XXXXXX", "1001").
        partition: Disambiguate when the same pattern exists in multiple partitions.
    """
    return route_plan.inspect_pattern(_client(), pattern, partition)


@mcp.tool
def route_lists_and_groups(name: str | None = None) -> dict:
    """Route lists with their ordered route groups and member devices.

    Route lists are how route patterns reach the outside world: a route pattern
    points to a route list, the route list contains an ordered list of route
    groups, and each route group contains an ordered list of devices (gateways,
    SIP trunks, etc.). Top-down with failover.

    Args:
        name: Optional route list name to fetch one specific list.
    """
    return route_plan.list_route_lists_and_groups(_client(), name)


@mcp.tool
def route_translation_chain(number: str, css_name: str | None = None) -> dict:
    """Find candidate patterns that might match a given number from a given CSS.

    Best-effort: literal/prefix matching only. CUCM's actual matcher evaluates
    wildcards (X, !, [0-9], etc.) and selects longest match. Use as a starting
    point for "where could this number be coming from?" investigations.

    Args:
        number: The number to test (e.g. "9123456789", "+15551234567", "1001").
        css_name: Restrict candidates to patterns in partitions reachable from
            this CSS. If None, considers all patterns.
    """
    return route_plan.translation_chain(_client(), number, css_name)


@mcp.tool
def route_digit_discard_instructions() -> dict:
    """List all Digit Discard Instructions (DDIs).

    DDIs are named rules like "PreDot" or "10-10-Dialing" that strip digits
    from called-party numbers before they leave the cluster. Patterns reference
    DDIs via fkdigitdiscardinstruction.
    """
    return route_plan.list_digit_discard_instructions(_client())


@mcp.tool
def route_device_pool_route_groups(device_pool_name: str | None = None) -> dict:
    """How each device pool resolves Local Route Group placeholders to actual gateways.

    Closes the loop on Local Route Group routing: when a route list step references
    a "named placeholder" route group with no static devices, this is where the
    actual gateway is resolved per-device-pool at call time.

    Args:
        device_pool_name: Optional. If given, return only that DP's mappings.
    """
    return route_plan.list_device_pool_route_groups(_client(), device_pool_name)


@mcp.tool
def route_devices_using_css(css_name: str, max_per_category: int = 50) -> dict:
    """Impact analysis: every reference to a CSS across the schema.

    Use before changing or removing a CSS to find all dependent devices, lines,
    translation patterns, route lists, voicemail pilots, etc. Cross-references
    the major fkcallingsearchspace* columns across the data dictionary.

    Args:
        css_name: The exact CSS name (case-sensitive).
        max_per_category: Max rows per category. Default 50. Each category
            with more than `max_per_category` references gets `truncated: true`
            so you know to either raise the limit or drill in via `axl_sql`.
    """
    return route_plan.find_devices_using_css(_client(), css_name, max_per_category)


@mcp.tool
def device_registration_status(
    device_class: str = "Phone",
    status: str = "Any",
    name_filter: str | None = None,
    page_size: int = 200,
) -> dict:
    """Real-time device registration status from CUCM RisPort70.

    Complementary to AXL: AXL tells us what's *configured*; RisPort tells
    us what's *currently registered*. The most audit-relevant cross-
    reference is "configured but unregistered" (likely orphan).

    Args:
        device_class: One of "Phone" (default), "Gateway", "H323", "CTI",
            "VoiceMail", "MediaResources", "HuntList", "SIPTrunk", "Any".
        status: One of "Any" (default), "Registered", "UnRegistered",
            "Rejected", "PartiallyRegistered", "Unknown".
        name_filter: Optional name (or wildcard `*` substring) to narrow
            the result. Maps to RisPort's SelectItems.
        page_size: Max devices per RisPort call. RisPort caps at 1000.
    """
    if _ris is None:
        raise RuntimeError("RisPort client not initialized — server bootstrap failed.")
    if name_filter:
        return _ris.select_cm_device(
            max_devices=page_size,
            device_class=device_class,
            status=status,
            name_filter=name_filter,
        )
    return _ris.select_all(
        device_class=device_class,
        status=status,
        page_size=page_size,
    )


@mcp.tool
def device_registration_summary() -> dict:
    """High-level cluster registration health: counts by status across
    all device classes that matter for audit work.

    Useful as a once-per-conversation orientation: "are most phones
    actually registered, or is something broken?"
    """
    if _ris is None:
        raise RuntimeError("RisPort client not initialized — server bootstrap failed.")
    summary = {}
    for cls in ("Phone", "Gateway", "H323", "SIPTrunk", "HuntList", "CTI"):
        try:
            r = _ris.select_all(device_class=cls, status="Any")
            summary[cls] = {
                "total_devices_found": r["total_devices_found"],
                "devices_returned": r["devices_returned"],
                "status_counts": r["status_counts"],
                "cm_nodes_seen": r["cm_nodes_seen"],
            }
        except Exception as e:
            summary[cls] = {"error": str(e)[:200]}
    return summary


@mcp.tool
def route_filters(name: str | None = None, include_members: bool = False) -> dict:
    """List route filters with their composition rules.

    Route filters compose with @-pattern (NANPA) route patterns to constrain
    which calls match — e.g., "AREA-CODE == 208" narrows a `9.@` pattern to
    in-state calls.

    Args:
        name: Optional. If given, return only the named filter.
        include_members: If True, include the (digit, operator, tag) member
            rules. Default False — the `clause` field already shows the
            human-readable rule, and member listings can be very large
            (hundreds of KB across all filters on a complex cluster).
    """
    return route_plan.list_route_filters(_client(), name, include_members)


# ====================================================================
# Prompts — schema-grounded conversation seeds
#
# Bodies live in `mcaxl.prompts.<name>`. The shims below are the
# FastMCP registration surface; FastMCP introspects each shim's signature
# to expose parameters to the LLM, so the parameter contract lives here.
# Each shim is a thin pass-through to the corresponding render() function.
# ====================================================================

from . import prompts as _prompts


@mcp.prompt
def route_plan_overview() -> str:
    """Snapshot of the cluster's routing setup, with schema reference embedded.

    Use this when starting a fresh route-plan audit conversation.
    """
    return _prompts.route_plan_overview.render(_docs)


@mcp.prompt
def investigate_pattern(pattern: str, partition: str | None = None) -> str:
    """Deep-dive seed for one specific pattern. Schema chunks embedded."""
    return _prompts.investigate_pattern.render(_docs, pattern, partition)


@mcp.prompt
def audit_routing(focus: str = "full") -> str:
    """Comprehensive routing audit walkthrough.

    Args:
        focus: One of "full", "translations", "css_partitions", "transformations",
            "route_lists". Tunes which schema chunks get embedded.
    """
    return _prompts.audit_routing.render(_docs, focus)


@mcp.prompt
def cucm_sql_help(question: str) -> str:
    """Catch-all prompt for arbitrary CUCM SQL questions. Includes schema chunks."""
    return _prompts.cucm_sql_help.render(_docs, question)


@mcp.prompt
def sip_trunk_report(name_filter: str | None = None) -> str:
    """Comprehensive SIP trunk inventory: profiles, destinations, route-group
    membership, and findings template.

    Args:
        name_filter: Optional substring to narrow inventory to specific
            trunks (case-sensitive LIKE). Omit to include all SIP trunks.
    """
    return _prompts.sip_trunk_report.render(_docs, name_filter)


@mcp.prompt
def phone_inventory_report(filter: str | None = None) -> str:
    """Phone fleet audit: counts by model/pool/CSS, anomaly findings,
    orphan-owner cross-check.

    Args:
        filter: Optional substring (matches device name OR description) to
            narrow the inventory. Omit to include all phones.
    """
    return _prompts.phone_inventory_report.render(_docs, filter)


@mcp.prompt
def user_audit(focus: str = "full") -> str:
    """End user + application user audit: roles, group memberships,
    security-relevant findings.

    Args:
        focus: One of "full", "admin", "inactive", "app_users". Tunes
            which checklist sections the report emphasizes; all queries
            still run for context.
    """
    return _prompts.user_audit.render(_docs, focus)


@mcp.prompt
def inbound_did_audit() -> str:
    """Inbound DID inventory: XFORM-Inbound-DNIS curated list, executed
    routing in Internal-PT, spam blocklist, orphan-target cross-check."""
    return _prompts.inbound_did_audit.render(_docs)


@mcp.prompt
def hunt_pilot_audit() -> str:
    """Hunt pilot audit: queue settings, distribution algorithms, line
    group membership, dead-pilot detection. Schema-aware (uses
    huntpilotqueue.fknumplan_pilot, the verified column name)."""
    return _prompts.hunt_pilot_audit.render(_docs)


@mcp.prompt
def whoami(userid: str | None = None) -> str:
    """Look up the role chain for a single user (defaults to the AXL
    service account). Surfaces access-control-group membership, attached
    function roles, and findings around misnamed groups or excess
    privileges.

    Args:
        userid: User identity to look up. If omitted, defaults to the
            value of the AXL_USER environment variable (the account this
            MCP server uses to talk to the cluster).
    """
    return _prompts.whoami.render(_docs, userid)


# ====================================================================
# Bootstrap
# ====================================================================

def _banner() -> None:
    try:
        v = _pkg_version("mcaxl")
    except Exception:
        v = "0.1.0"
    axl_url = os.environ.get("AXL_URL", "(unset)")
    print(f"[mcaxl] v{v} starting", file=sys.stderr, flush=True)
    print(f"[mcaxl] AXL_URL={axl_url}", file=sys.stderr, flush=True)


def main() -> None:
    global _cache, _axl, _docs, _ris

    # Load .env from the project directory (where the user runs uv from)
    cwd_env = Path.cwd() / ".env"
    if cwd_env.exists():
        load_dotenv(cwd_env)

    _banner()

    cache_dir = Path(
        os.environ.get("AXL_CACHE_DIR")
        or (Path(user_cache_dir("mcaxl")) / "responses")
    )
    cache_dir.mkdir(parents=True, exist_ok=True)
    ttl = int(os.environ.get("AXL_CACHE_TTL", "3600"))
    # Cluster-id derived from AXL_URL. Hash keeps the key compact and
    # avoids leaking the URL into log output where the cache key gets
    # printed. Hostname-only fallback when AXL_URL is unset (test mode).
    import hashlib
    axl_url_for_id = os.environ.get("AXL_URL", "no-axl-url-configured")
    cluster_id = hashlib.sha256(axl_url_for_id.encode()).hexdigest()[:12]
    _cache = AxlCache(
        cache_dir / "axl_responses.sqlite",
        default_ttl=ttl,
        cluster_id=cluster_id,
    )
    print(
        f"[mcaxl] cache: {_cache.db_path} "
        f"(ttl={ttl}s, cluster_id={cluster_id})",
        file=sys.stderr,
        flush=True,
    )

    _axl = AxlClient(_cache)
    _docs = DocsIndex.load()  # may be None; prompts handle gracefully
    _ris = RisPortClient()

    mcp.run()


if __name__ == "__main__":
    main()
