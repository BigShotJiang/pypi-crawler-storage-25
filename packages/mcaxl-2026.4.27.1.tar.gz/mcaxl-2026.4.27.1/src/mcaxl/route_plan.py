"""Route plan tools — focused on CUCM call routing audit.

The CUCM dial plan is centered on one table: `numplan`. Every "pattern"
(directory number, route pattern, translation pattern, hunt pilot, etc.) is
a row there, distinguished by `tkpatternusage`. Calling/called party
transformations and digit-discard instructions live as columns on the same
row, which is why the Route Plan Report is essentially a single query.

Access control is in `callingsearchspace` + `callingsearchspacemember` —
the latter is an ordered list (sortorder) of partitions inside each CSS.

Routing destinations: numplan → devicenumplanmap → device(tkclass='Route List')
                              → routelist → routegroup → routegroupdevicemap → device

Local Route Group resolution: route groups with no static members resolve
through devicepoolroutegroupmap, which maps a calling device's device pool
to the actual gateway-bearing route group. fkroutegroup_local is the named
placeholder; fkroutegroup is the actual destination group.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from .normalize import normalize_rows, normalize_row, normalize_bool

if TYPE_CHECKING:
    from .client import AxlClient


# Pattern type codes (numplan.tkpatternusage), verified against the
# typepatternusage table in CUCM 15. To inspect on a different
# cluster: SELECT enum, name FROM typepatternusage ORDER BY enum.
PATTERN_KINDS: dict[str, int] = {
    "call_park": 0,
    "conference": 1,
    "directory_number": 2,
    "translation": 3,
    "call_pickup_group": 4,
    "route": 5,
    "message_waiting": 6,
    "hunt_pilot": 7,
    "voicemail_port": 8,
    "device_template": 11,
    "directed_call_park": 12,
    "device_intercom": 13,
    "translation_intercom": 14,
    "translation_calling_party": 15,
    "called_party_xform": 20,
    "ils_learned_enterprise": 23,
    "ils_learned_e164": 24,
    "ils_learned_uri": 28,
}


def _esc(s: str) -> str:
    return s.replace("'", "''")


def list_partitions(client: "AxlClient") -> dict:
    """All route partitions with how many patterns and CSS members each has."""
    sql = """
    SELECT
      rp.name AS name,
      rp.description AS description,
      (SELECT COUNT(*) FROM numplan np WHERE np.fkroutepartition = rp.pkid) AS pattern_count,
      (SELECT COUNT(*) FROM callingsearchspacemember csm WHERE csm.fkroutepartition = rp.pkid) AS css_member_count
    FROM routepartition rp
    ORDER BY rp.name
    """
    result = client.execute_sql_query(sql)
    return {
        "partition_count": result["row_count"],
        "partitions": normalize_rows(result["rows"]),
    }


def list_calling_search_spaces(client: "AxlClient", name: str | None = None) -> dict:
    """Calling search spaces with their ordered partition list.

    If `name` is given, return only that CSS. Otherwise return all CSS
    grouped, with each one's partitions in sortorder.
    """
    where = f"WHERE css.name = '{_esc(name)}'" if name else ""
    sql = f"""
    SELECT
      css.name AS css_name,
      css.description AS css_description,
      rp.name AS partition_name,
      csm.sortorder AS sortorder
    FROM callingsearchspace css
    LEFT OUTER JOIN callingsearchspacemember csm ON csm.fkcallingsearchspace = css.pkid
    LEFT OUTER JOIN routepartition rp ON csm.fkroutepartition = rp.pkid
    {where}
    ORDER BY css.name, csm.sortorder
    """
    result = client.execute_sql_query(sql)

    grouped: dict[str, dict] = {}
    for row in result["rows"]:
        css = row.get("css_name")
        if not css:
            continue
        if css not in grouped:
            grouped[css] = {
                "name": css,
                "description": row.get("css_description"),
                "partitions": [],
            }
        if row.get("partition_name"):
            grouped[css]["partitions"].append({
                "name": row["partition_name"],
                "sortorder": row.get("sortorder"),
            })

    css_list = list(grouped.values())
    return {"css_count": len(css_list), "calling_search_spaces": css_list}


def list_patterns(
    client: "AxlClient",
    kind: str | None = None,
    partition: str | None = None,
    filter_substring: str | None = None,
    limit: int = 500,
) -> dict:
    """The Route Plan Report — patterns with their transformations.

    Args:
        kind: One of PATTERN_KINDS keys, or None for all. e.g. "route", "translation".
        partition: Filter by partition name.
        filter_substring: Substring match against pattern text (LIKE '%X%').
        limit: Max rows. Defaults to 500.
    """
    where_clauses = []
    if kind is not None:
        if kind not in PATTERN_KINDS:
            return {
                "error": f"Unknown kind {kind!r}. Valid: {sorted(PATTERN_KINDS)}",
            }
        where_clauses.append(f"np.tkpatternusage = {PATTERN_KINDS[kind]}")
    if partition:
        where_clauses.append(f"rp.name = '{_esc(partition)}'")
    if filter_substring:
        where_clauses.append(f"np.dnorpattern LIKE '%{_esc(filter_substring)}%'")

    where = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""

    sql = f"""
    SELECT FIRST {int(limit)}
      np.dnorpattern AS pattern,
      np.description AS description,
      tpu.name AS pattern_type,
      np.tkpatternusage AS pattern_type_code,
      rp.name AS partition_name,
      np.callingpartytransformationmask AS calling_party_xform_mask,
      np.calledpartytransformationmask AS called_party_xform_mask,
      np.prefixdigitsout AS prefix_digits_out,
      np.callingpartyprefixdigits AS calling_prefix_digits,
      ddi.name AS digit_discard_instructions,
      np.blockenable AS block_enabled,
      np.pkid AS pkid
    FROM numplan np
    LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
    LEFT OUTER JOIN typepatternusage tpu ON np.tkpatternusage = tpu.enum
    LEFT OUTER JOIN digitdiscardinstruction ddi ON np.fkdigitdiscardinstruction = ddi.pkid
    {where}
    ORDER BY rp.name, np.dnorpattern
    """
    result = client.execute_sql_query(sql)
    return {
        "pattern_count": result["row_count"],
        "filter": {"kind": kind, "partition": partition, "substring": filter_substring},
        "patterns": normalize_rows(result["rows"]),
    }


def inspect_pattern(
    client: "AxlClient",
    pattern: str,
    partition: str | None = None,
) -> dict:
    """Deep dive on one pattern — transforms, target, reverse CSS lookup."""
    where = f"np.dnorpattern = '{_esc(pattern)}'"
    if partition:
        where += f" AND rp.name = '{_esc(partition)}'"

    detail_sql = f"""
    SELECT
      np.dnorpattern AS pattern,
      np.description AS description,
      tpu.name AS pattern_type,
      rp.name AS partition_name,
      np.callingpartytransformationmask AS calling_party_xform_mask,
      np.calledpartytransformationmask AS called_party_xform_mask,
      np.prefixdigitsout AS prefix_digits_out,
      np.callingpartyprefixdigits AS calling_prefix_digits,
      ddi.name AS digit_discard_instructions,
      cssxlate.name AS css_for_translation,
      rf.name AS route_filter_name,
      rf.clause AS route_filter_clause,
      np.blockenable AS block_enabled,
      tprc.name AS release_cause,
      np.pkid AS pkid
    FROM numplan np
    LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
    LEFT OUTER JOIN typepatternusage tpu ON np.tkpatternusage = tpu.enum
    LEFT OUTER JOIN digitdiscardinstruction ddi ON np.fkdigitdiscardinstruction = ddi.pkid
    LEFT OUTER JOIN callingsearchspace cssxlate ON np.fkcallingsearchspace_translation = cssxlate.pkid
    LEFT OUTER JOIN routefilter rf ON np.fkroutefilter = rf.pkid
    LEFT OUTER JOIN typereleasecausevalue tprc ON np.tkreleasecausevalue = tprc.enum
    WHERE {where}
    """
    detail = client.execute_sql_query(detail_sql)
    if not detail["rows"]:
        return {"error": f"Pattern {pattern!r} not found" + (f" in partition {partition!r}" if partition else "")}
    if len(detail["rows"]) > 1 and not partition:
        return {
            "error": f"Multiple patterns named {pattern!r} in different partitions; specify partition.",
            "matches": [
                {"pattern": r["pattern"], "partition": r["partition_name"]}
                for r in detail["rows"]
            ],
        }

    row = normalize_row(detail["rows"][0])
    partition_name = row.get("partition_name")
    pattern_pkid = row.get("pkid")

    # Reverse CSS lookup: which calling search spaces include this pattern's partition?
    reachable_from = []
    if partition_name:
        css_sql = f"""
        SELECT css.name AS css_name, csm.sortorder AS sortorder
        FROM callingsearchspace css
        JOIN callingsearchspacemember csm ON csm.fkcallingsearchspace = css.pkid
        JOIN routepartition rp ON csm.fkroutepartition = rp.pkid
        WHERE rp.name = '{_esc(partition_name)}'
        ORDER BY css.name
        """
        css_result = client.execute_sql_query(css_sql)
        reachable_from = css_result["rows"]

    # Forward routing: where does this pattern actually route?
    destination = None
    route_list_chain = None
    if pattern_pkid:
        destination = resolve_pattern_destination(client, pattern_pkid)
        # If destination is a Route List, expand the route group / device chain
        if destination and destination.get("destination_class") == "Route List":
            chain = list_route_lists_and_groups(client, name=destination["destination_name"])
            if chain.get("route_lists"):
                route_list_chain = chain["route_lists"][0]

    return {
        "pattern": row,
        "reachable_from_css": reachable_from,
        "destination": destination,
        "route_list_chain": route_list_chain,
    }


def list_route_lists_and_groups(client: "AxlClient", name: str | None = None) -> dict:
    """Route lists with their ordered route groups and member gateways/trunks.

    Schema chain:
      device (tkclass='Route List')   → the "Route List" header
        ↳ routelist (fkdevice = ↑)    → list of route group steps (selectionorder)
        ↳ routegroup (fkroutegroup)   → the route group at this step
            ↳ routegroupdevicemap     → ordered (deviceselectionorder) gateways/trunks
            ↳ device (fkdevice = ↑)   → the actual gateway/trunk
    """
    where = f"AND rl_dev.name = '{_esc(name)}'" if name else ""
    sql = f"""
    SELECT
      rl_dev.name AS route_list_name,
      rl_dev.description AS route_list_description,
      rg.name AS route_group_name,
      rl.selectionorder AS group_order,
      gw.name AS device_name,
      rgdm.deviceselectionorder AS device_order,
      tc_gw.name AS device_class
    FROM device rl_dev
    JOIN typeclass tc_rl ON rl_dev.tkclass = tc_rl.enum
    LEFT OUTER JOIN routelist rl ON rl.fkdevice = rl_dev.pkid
    LEFT OUTER JOIN routegroup rg ON rl.fkroutegroup = rg.pkid
    LEFT OUTER JOIN routegroupdevicemap rgdm ON rgdm.fkroutegroup = rg.pkid
    LEFT OUTER JOIN device gw ON rgdm.fkdevice = gw.pkid
    LEFT OUTER JOIN typeclass tc_gw ON gw.tkclass = tc_gw.enum
    WHERE tc_rl.name = 'Route List' {where}
    ORDER BY rl_dev.name, rl.selectionorder, rgdm.deviceselectionorder
    """
    result = client.execute_sql_query(sql)

    grouped: dict[str, dict] = {}
    for row in result["rows"]:
        rl_name = row.get("route_list_name")
        if not rl_name:
            continue
        if rl_name not in grouped:
            grouped[rl_name] = {
                "name": rl_name,
                "description": row.get("route_list_description"),
                "route_groups": {},
            }
        rg_name = row.get("route_group_name")
        if rg_name:
            if rg_name not in grouped[rl_name]["route_groups"]:
                grouped[rl_name]["route_groups"][rg_name] = {
                    "name": rg_name,
                    "order_within_route_list": _to_int(row.get("group_order")),
                    "devices": [],
                }
            if row.get("device_name"):
                grouped[rl_name]["route_groups"][rg_name]["devices"].append({
                    "name": row["device_name"],
                    "class": row.get("device_class"),
                    "order_within_group": _to_int(row.get("device_order")),
                })

    out = []
    for rl in grouped.values():
        # Sort route groups by their order, and annotate empty groups —
        # which on CUCM usually means "uses device-pool-assigned local
        # route group" (CUCM's Standard Local Route Group feature)
        ordered_groups = sorted(
            rl["route_groups"].values(),
            key=lambda rg: rg.get("order_within_route_list") or 0,
        )
        for g in ordered_groups:
            if not g["devices"]:
                g["_note"] = (
                    "No static device members. Likely resolves to a Local "
                    "Route Group via the calling device's device pool at "
                    "call-time (CUCM Standard Local Route Group feature)."
                )
        rl["route_groups"] = ordered_groups
        out.append(rl)

    return {"route_list_count": len(out), "route_lists": out}


def _to_int(v: object) -> int | None:
    """Cast Informix string-encoded integers to int; passthrough None/non-numeric.

    Hamilton review MINOR #6: a non-numeric value from the cluster (data
    corruption, unexpected schema change, type drift across CUCM versions)
    used to silently become None — and downstream sort logic that defaulted
    None to 0 would jumble the failover order with no warning. We still
    return None on bad data (the caller's error path is unchanged), but we
    log the offending value to stderr so an operator notices something
    weird is happening at the data layer.

    None itself is a valid value (column not set in CUCM) and produces no
    warning — only genuinely-unparseable values trigger the log.
    """
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        import sys
        print(
            f"[mcaxl] _to_int: unexpected non-numeric value {v!r} "
            f"(type {type(v).__name__}); returning None",
            file=sys.stderr,
            flush=True,
        )
        return None


# ====================================================================
# Device Pool → Route Group resolution (Local Route Group feature)
# ====================================================================

def list_device_pool_route_groups(
    client: "AxlClient",
    device_pool_name: str | None = None,
) -> dict:
    """Show how each device pool resolves Local Route Group placeholders.

    CUCM's Standard Local Route Group feature lets a route list step reference
    a *named* route group (the "local placeholder" — e.g., "Primary PSTN Route
    Group"), and at call-time the calling phone's device pool determines which
    *actual* route group (with real gateways/trunks) gets used.

    Schema:
      devicepoolroutegroupmap.fkdevicepool       → which DP
      devicepoolroutegroupmap.fkroutegroup_local → named placeholder ref'd by route lists
      devicepoolroutegroupmap.fkroutegroup       → actual route group with gateways

    Args:
        device_pool_name: If given, return only that DP's mappings.
    """
    where = ""
    if device_pool_name:
        where = f"WHERE dp.name = '{_esc(device_pool_name)}'"
    sql = f"""
    SELECT
      dp.name AS device_pool,
      placeholder.name AS local_placeholder,
      target.name AS resolves_to_route_group
    FROM devicepoolroutegroupmap m
    JOIN devicepool dp ON m.fkdevicepool = dp.pkid
    LEFT OUTER JOIN routegroup placeholder ON m.fkroutegroup_local = placeholder.pkid
    LEFT OUTER JOIN routegroup target ON m.fkroutegroup = target.pkid
    {where}
    ORDER BY dp.name, placeholder.name
    """
    result = client.execute_sql_query(sql)
    grouped: dict[str, dict] = {}
    for row in result["rows"]:
        dp = row.get("device_pool")
        if not dp:
            continue
        if dp not in grouped:
            grouped[dp] = {"name": dp, "local_route_group_resolutions": []}
        grouped[dp]["local_route_group_resolutions"].append({
            "placeholder": row.get("local_placeholder"),
            "resolves_to": row.get("resolves_to_route_group"),
        })
    return {
        "device_pool_count": len(grouped),
        "device_pools": list(grouped.values()),
    }


# ====================================================================
# CSS impact analysis: which devices/lines/patterns reference this CSS
# ====================================================================

# CSS reference points: each entry maps a category label to a (table,
# column, sql) spec. The SQL returns rows with a common shape: `name`
# and `context` (partition for patterns, device class for devices, etc.),
# plus a `description` where the source table has one.
#
# Issue #1: previously we only enumerated a handful of device columns;
# trunks referencing CSSs via `fkcallingsearchspace_cgpntransform` and
# `_cdpntransform` produced false-zero impact analysis. The set below
# covers all 71 known fkcallingsearchspace_* columns from the CUCM 15
# schema; tests/test_css_impact.py:test_complete_schema_coverage_against_known_columns
# fires red if a future CUCM version adds a column we haven't added.
#
# Templates for the common cases follow; the dict is built from them.

def _device_query(suffix: str) -> dict:
    """Reference query for a `fkcallingsearchspace[_<suffix>]` column on `device`."""
    col = "fkcallingsearchspace" if not suffix else f"fkcallingsearchspace_{suffix}"
    return {
        "table": "device",
        "column": col,
        "sql": f"""
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM device d LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE d.{col} = '{{pkid}}'
        """,
    }


def _devicepool_query(suffix: str) -> dict:
    """Reference query for a fkcallingsearchspace_<suffix> column on devicepool.

    Phones / devices in a DP inherit these CSSs unless overridden. Audit-
    relevant: a CSS only assigned via DP inheritance was previously
    invisible (this is the gap the M1 caveat in today's audit reports
    explicitly called out, now closed).

    Note: `devicepool` has no `description` column (verified against CUCM
    15 schema 2026-04-26); the query selects only `name`.
    """
    col = f"fkcallingsearchspace_{suffix}"
    return {
        "table": "devicepool",
        "column": col,
        "sql": f"""
            SELECT name FROM devicepool WHERE {col} = '{{pkid}}'
        """,
    }


def _numplan_query(suffix: str) -> dict:
    """Reference query for a fkcallingsearchspace_<suffix> column on numplan.

    These are the line-level forwarding CSSs (CFA/CFB/CFNA/CFUR and their
    internal/personal variants), MWI, translation, etc. Hits one row per
    DN that has the CSS configured for that scenario.
    """
    col = f"fkcallingsearchspace_{suffix}"
    return {
        "table": "numplan",
        "column": col,
        "sql": f"""
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM numplan np LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE np.{col} = '{{pkid}}'
        """,
    }


_CSS_REFERENCE_QUERIES: dict[str, dict] = {
    # Line-level forwarding CSSs (call-forward variants on a DN)
    "line_call_forward_all_css": {
        "table": "numplan", "column": "fkcallingsearchspace_cfapt",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM numplan np LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE np.fkcallingsearchspace_cfapt = '{pkid}'
            ORDER BY rp.name, np.dnorpattern
        """,
    },
    "line_call_forward_busy_css": {
        "table": "numplan", "column": "fkcallingsearchspace_cfb",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM numplan np LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE np.fkcallingsearchspace_cfb = '{pkid}'
        """,
    },
    "line_call_forward_no_answer_css": {
        "table": "numplan", "column": "fkcallingsearchspace_cfna",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM numplan np LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE np.fkcallingsearchspace_cfna = '{pkid}'
        """,
    },
    "line_call_forward_unregistered_css": {
        "table": "numplan", "column": "fkcallingsearchspace_cfur",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM numplan np LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE np.fkcallingsearchspace_cfur = '{pkid}'
        """,
    },
    "translation_pattern_css": {
        "table": "numplan", "column": "fkcallingsearchspace_translation",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM numplan np LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE np.fkcallingsearchspace_translation = '{pkid}'
        """,
    },
    "line_shared_appearance_css": {
        "table": "numplan", "column": "fkcallingsearchspace_sharedlineappear",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM numplan np LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE np.fkcallingsearchspace_sharedlineappear = '{pkid}'
        """,
    },
    # Device-level CSS variants
    "device_reroute_css": {
        "table": "device", "column": "fkcallingsearchspace_reroute",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM device d LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE d.fkcallingsearchspace_reroute = '{pkid}'
        """,
    },
    "device_restrict_css": {
        "table": "device", "column": "fkcallingsearchspace_restrict",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM device d LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE d.fkcallingsearchspace_restrict = '{pkid}'
        """,
    },
    "device_refer_css": {
        "table": "device", "column": "fkcallingsearchspace_refer",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM device d LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE d.fkcallingsearchspace_refer = '{pkid}'
        """,
    },
    "device_rdn_transform_css": {
        "table": "device", "column": "fkcallingsearchspace_rdntransform",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM device d LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE d.fkcallingsearchspace_rdntransform = '{pkid}'
        """,
    },
    # Voicemail pilot — has directorynumber instead of name
    "voicemail_pilot_css": {
        "table": "voicemessagingpilot", "column": "fkcallingsearchspace",
        "sql": """
            SELECT directorynumber AS name, description
            FROM voicemessagingpilot
            WHERE fkcallingsearchspace = '{pkid}'
        """,
    },
    # Route lists — routelist is a join table; identify by the route-list device name
    "route_list_css": {
        "table": "routelist", "column": "fkcallingsearchspace",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM routelist rl JOIN device d ON rl.fkdevice = d.pkid
            LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE rl.fkcallingsearchspace = '{pkid}'
        """,
    },
    # PRIMARY device CSS — the field the GUI sets when you assign "Calling
    # Search Space" to a phone, gateway, or trunk. Not suffixed; spelled out
    # as fkcallingsearchspace (no _xxx). This is where most CSS assignments
    # actually live; missing it produced false-zero impact analyses.
    "device_primary_css": {
        "table": "device", "column": "fkcallingsearchspace",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM device d LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE d.fkcallingsearchspace = '{pkid}'
        """,
    },
    "device_cgpn_unknown_css": {
        "table": "device", "column": "fkcallingsearchspace_cgpnunknown",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM device d LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE d.fkcallingsearchspace_cgpnunknown = '{pkid}'
        """,
    },
    # Line-level CSS for phone-line monitoring (BLF, presence)
    "line_monitoring_css": {
        "table": "devicenumplanmap", "column": "fkcallingsearchspace_monitoring",
        "sql": """
            SELECT d.name AS name, np.dnorpattern AS context, d.description AS description
            FROM devicenumplanmap dnm
            JOIN device d ON dnm.fkdevice = d.pkid
            JOIN numplan np ON dnm.fknumplan = np.pkid
            WHERE dnm.fkcallingsearchspace_monitoring = '{pkid}'
        """,
    },
    # H.323 / SIP gateway called-party transformation CSSs
    "gateway_h323_called_xform_css": {
        "table": "h323device", "column": "fkcallingsearchspace_cntdpntransform",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM h323device h
            JOIN device d ON h.fkdevice = d.pkid
            LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE h.fkcallingsearchspace_cntdpntransform = '{pkid}'
        """,
    },
    "gateway_sip_called_xform_css": {
        "table": "sipdevice", "column": "fkcallingsearchspace_cntdpntransform",
        "sql": """
            SELECT d.name AS name, tc.name AS context, d.description AS description
            FROM sipdevice s
            JOIN device d ON s.fkdevice = d.pkid
            LEFT OUTER JOIN typeclass tc ON d.tkclass = tc.enum
            WHERE s.fkcallingsearchspace_cntdpntransform = '{pkid}'
        """,
    },
    # Hunt pilot queue CSSs (max-wait, no-agent, queue-full destinations)
    "huntpilot_max_wait_css": {
        "table": "huntpilotqueue", "column": "fkcallingsearchspace_maxwaittime",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM huntpilotqueue hpq
            JOIN numplan np ON hpq.fknumplan_pilot = np.pkid
            LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE hpq.fkcallingsearchspace_maxwaittime = '{pkid}'
        """,
    },
    "huntpilot_no_agent_css": {
        "table": "huntpilotqueue", "column": "fkcallingsearchspace_noagent",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM huntpilotqueue hpq
            JOIN numplan np ON hpq.fknumplan_pilot = np.pkid
            LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE hpq.fkcallingsearchspace_noagent = '{pkid}'
        """,
    },
    "huntpilot_queue_full_css": {
        "table": "huntpilotqueue", "column": "fkcallingsearchspace_pilotqueuefull",
        "sql": """
            SELECT np.dnorpattern AS name, rp.name AS context, np.description AS description
            FROM huntpilotqueue hpq
            JOIN numplan np ON hpq.fknumplan_pilot = np.pkid
            LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
            WHERE hpq.fkcallingsearchspace_pilotqueuefull = '{pkid}'
        """,
    },

    # ----------------------------------------------------------------
    # Issue #1 fix: comprehensive coverage of all fkcallingsearchspace_*
    # columns from the CUCM 15 schema. Categories below use the
    # _device_query / _devicepool_query / _numplan_query helpers above
    # for the bulk cases; the remaining tables use hand-written SQL.
    # ----------------------------------------------------------------

    # device — remaining 11 variants beyond the 6 already covered above
    "device_aar_css":              _device_query("aar"),
    "device_called_intl_css":      _device_query("calledintl"),
    "device_called_national_css":  _device_query("callednational"),
    "device_called_subscriber_css": _device_query("calledsubscriber"),
    "device_called_unknown_css":   _device_query("calledunknown"),
    "device_cdpn_xform_css":       _device_query("cdpntransform"),    # issue #1
    "device_cgpn_ingress_dn_css":  _device_query("cgpningressdn"),
    "device_cgpn_intl_css":        _device_query("cgpnintl"),
    "device_cgpn_national_css":    _device_query("cgpnnational"),
    "device_cgpn_subscriber_css":  _device_query("cgpnsubscriber"),
    "device_cgpn_xform_css":       _device_query("cgpntransform"),    # issue #1

    # devicepool — 17 variants. Phones inherit these CSSs from their DP
    # unless overridden. Important: a CSS only assigned via DP inheritance
    # was previously invisible (the M1 caveat in today's audit reports).
    "devicepool_aar_css":              _devicepool_query("aar"),
    "devicepool_adjunct_css":          _devicepool_query("adjunct"),
    "devicepool_autoregistration_css": _devicepool_query("autoregistration"),
    "devicepool_called_intl_css":      _devicepool_query("calledintl"),
    "devicepool_called_national_css":  _devicepool_query("callednational"),
    "devicepool_called_subscriber_css": _devicepool_query("calledsubscriber"),
    "devicepool_called_unknown_css":   _devicepool_query("calledunknown"),
    "devicepool_cdpn_xform_css":       _devicepool_query("cdpntransform"),
    "devicepool_cgpn_ingress_dn_css":  _devicepool_query("cgpningressdn"),
    "devicepool_cgpn_intl_css":        _devicepool_query("cgpnintl"),
    "devicepool_cgpn_national_css":    _devicepool_query("cgpnnational"),
    "devicepool_cgpn_subscriber_css":  _devicepool_query("cgpnsubscriber"),
    "devicepool_cgpn_xform_css":       _devicepool_query("cgpntransform"),
    "devicepool_cgpn_unknown_css":     _devicepool_query("cgpnunknown"),
    "devicepool_cntdpn_xform_css":     _devicepool_query("cntdpntransform"),
    "devicepool_mobility_css":         _devicepool_query("mobility"),
    "devicepool_rdn_transform_css":    _devicepool_query("rdntransform"),

    # numplan — remaining 13 forwarding/transformation variants
    "line_call_forward_busy_int_css":           _numplan_query("cfbint"),
    "line_call_forward_hr_css":                 _numplan_query("cfhr"),
    "line_call_forward_hr_int_css":             _numplan_query("cfhrint"),
    "line_call_forward_no_answer_int_css":      _numplan_query("cfnaint"),
    "line_call_forward_unregistered_int_css":   _numplan_query("cfurint"),
    "line_device_failure_css":                  _numplan_query("devicefailure"),
    "line_mwi_css":                             _numplan_query("mwi"),
    "line_personal_call_forward_css":           _numplan_query("pff"),
    "line_personal_call_forward_int_css":       _numplan_query("pffint"),
    "line_park_monitor_fwd_no_retrieve_css":    _numplan_query("pkmonfwdnoret"),
    "line_park_monitor_fwd_no_retrieve_int_css": _numplan_query("pkmonfwdnoretint"),
    "line_reroute_css":                         _numplan_query("reroute"),
    "line_revert_css":                          _numplan_query("revert"),

    # site — single primary CSS for site-level (SAF) call routing.
    # `site` has no name column; the human label comes from typesite.
    "site_css": {
        "table": "site", "column": "fkcallingsearchspace",
        "sql": """
            SELECT ts.name AS name, dp.name AS context, '' AS description
            FROM site s
            LEFT OUTER JOIN typesite ts ON s.tksite = ts.enum
            LEFT OUTER JOIN devicepool dp ON s.fkdevicepool = dp.pkid
            WHERE s.fkcallingsearchspace = '{pkid}'
        """,
    },

    # External call control profile — diversion/rerouting CSS
    # (`externalcallcontrolprofile` has no description column)
    "external_call_control_diversion_css": {
        "table": "externalcallcontrolprofile",
        "column": "fkcallingsearchspace_diversionrerouting",
        "sql": """
            SELECT name FROM externalcallcontrolprofile
            WHERE fkcallingsearchspace_diversionrerouting = '{pkid}'
        """,
    },

    # Recording profile — call recording CSS
    # (`recordingprofile` has no description column)
    "recording_call_recording_css": {
        "table": "recordingprofile",
        "column": "fkcallingsearchspace_callrecording",
        "sql": """
            SELECT name FROM recordingprofile
            WHERE fkcallingsearchspace_callrecording = '{pkid}'
        """,
    },

    # Usage profile — blocking CSS
    "usage_blocking_css": {
        "table": "usageprofile", "column": "fkcallingsearchspace_blocking",
        "sql": """
            SELECT name, description FROM usageprofile
            WHERE fkcallingsearchspace_blocking = '{pkid}'
        """,
    },

    # VIPR E.164 transformation profiles
    "vipre164_outgoing_cdpn_xform_css": {
        "table": "vipre164transformation",
        "column": "fkcallingsearchspace_outgoingcdpntranf",
        "sql": """
            SELECT name, description FROM vipre164transformation
            WHERE fkcallingsearchspace_outgoingcdpntranf = '{pkid}'
        """,
    },
    "vipre164_outgoing_cgpn_xform_css": {
        "table": "vipre164transformation",
        "column": "fkcallingsearchspace_outgoingcgpntranf",
        "sql": """
            SELECT name, description FROM vipre164transformation
            WHERE fkcallingsearchspace_outgoingcgpntranf = '{pkid}'
        """,
    },

    # Incoming transformation profile — 4 number-type variants
    "incoming_xform_intl_css": {
        "table": "incomingtransformationprofile",
        "column": "fkcallingsearchspace_intl",
        "sql": """
            SELECT name, description FROM incomingtransformationprofile
            WHERE fkcallingsearchspace_intl = '{pkid}'
        """,
    },
    "incoming_xform_national_css": {
        "table": "incomingtransformationprofile",
        "column": "fkcallingsearchspace_national",
        "sql": """
            SELECT name, description FROM incomingtransformationprofile
            WHERE fkcallingsearchspace_national = '{pkid}'
        """,
    },
    "incoming_xform_subscriber_css": {
        "table": "incomingtransformationprofile",
        "column": "fkcallingsearchspace_subscriber",
        "sql": """
            SELECT name, description FROM incomingtransformationprofile
            WHERE fkcallingsearchspace_subscriber = '{pkid}'
        """,
    },
    "incoming_xform_unknown_css": {
        "table": "incomingtransformationprofile",
        "column": "fkcallingsearchspace_unknown",
        "sql": """
            SELECT name, description FROM incomingtransformationprofile
            WHERE fkcallingsearchspace_unknown = '{pkid}'
        """,
    },
}


def find_devices_using_css(
    client: "AxlClient",
    css_name: str,
    max_per_category: int = 50,
) -> dict:
    """Impact analysis: enumerate every reference to this CSS across the schema.

    Useful before changing or removing a CSS — answers "what would break if
    I touched this CSS?" Cross-references the major schema tables that hold
    fkcallingsearchspace* columns.

    Args:
        css_name: The exact CSS name (case-sensitive).
        max_per_category: Max rows to return per reference category. Default 50.
            On heavily-referenced CSSs (e.g., Internal-CSS with hundreds of
            line-CFA references), the un-paginated response can exceed MCP
            response limits. Each truncated category includes a `truncated:
            true` flag so the LLM knows to drill in (call again with higher
            max, or use `axl_sql` directly for that specific table+column).

    Returns:
      references_by_category: each entry has:
        - rows: list of references, capped at max_per_category
        - returned_count: number of rows in this response
        - truncated: True if the underlying result has more rows than returned
        - table, column: which fk-column was queried
    """
    safe = _esc(css_name)
    css_lookup = client.execute_sql_query(
        f"SELECT pkid FROM callingsearchspace WHERE name = '{safe}'"
    )
    if not css_lookup["rows"]:
        return {"error": f"CSS {css_name!r} not found", "css_name": css_name}
    css_pkid = css_lookup["rows"][0]["pkid"]
    safe_pkid = _esc(css_pkid)

    # Trick: ask Informix for max+1 rows. If we get max+1 back, we know the
    # underlying result has MORE than max — set truncated=True and trim.
    # This avoids the cost of a separate COUNT(*) per category.
    fetch_n = max_per_category + 1

    grouped: dict[str, dict] = {}
    for label, spec in _CSS_REFERENCE_QUERIES.items():
        # Inject a FIRST limit into the SELECT — the queries all start with
        # `SELECT ` so a literal replacement is reliable here.
        base_sql = spec["sql"].format(pkid=safe_pkid).strip()
        if base_sql.upper().startswith("SELECT "):
            limited_sql = "SELECT FIRST " + str(fetch_n) + " " + base_sql[7:]
        else:
            limited_sql = base_sql

        try:
            result = client.execute_sql_query(limited_sql)
            rows = result["rows"]
            if not rows:
                continue
            truncated = len(rows) > max_per_category
            if truncated:
                rows = rows[:max_per_category]
            grouped[label] = {
                "table": spec["table"],
                "column": spec["column"],
                "returned_count": len(rows),
                "truncated": truncated,
                "rows": rows,
            }
        except Exception as e:
            grouped[label] = {
                "table": spec["table"],
                "column": spec["column"],
                "error": str(e)[:200],
            }

    total_returned = sum(c.get("returned_count", 0) for c in grouped.values())
    any_truncated = any(c.get("truncated") for c in grouped.values())
    # Hamilton review MAJOR #3: per-category errors must propagate to the
    # top-level summary, otherwise an LLM consuming `total_returned: 47`
    # has no way to know that 5 categories errored and the real count is
    # higher. "Software that understands itself reports its own degradation."
    error_categories = sorted(
        label for label, cat in grouped.items() if "error" in cat
    )
    complete = len(error_categories) == 0
    return {
        "css_name": css_name,
        "css_pkid": css_pkid,
        "total_returned": total_returned,
        "any_truncated": any_truncated,
        "complete": complete,
        "categories_with_errors": len(error_categories),
        "error_categories": error_categories,
        "max_per_category": max_per_category,
        "references_by_category": grouped,
    }


# ====================================================================
# Route Filters
# ====================================================================

def list_route_filters(
    client: "AxlClient",
    name: str | None = None,
    include_members: bool = False,
) -> dict:
    """List route filters with their composition rules.

    Route filters compose with @-pattern (NANPA) route patterns to constrain
    matches — e.g., a filter that matches only when AREA-CODE == 208 narrows
    a `9.@` pattern to in-state calls. The `clause` field contains the
    pre-rendered expression, which is usually enough for audit work.

    Args:
        name: If given, return only the named filter.
        include_members: If True, also fetch the (digit, operator, tag) member
            rules for each filter. Default False — the response can be very
            large (hundreds of KB on clusters with many international filters)
            and the `clause` field already shows the human-readable rule. Set
            True only when you need to programmatically reconstruct or modify
            the filter logic.
    """
    where = f"WHERE rf.name = '{_esc(name)}'" if name else ""
    # Member count is cheap to compute server-side and gives auditors a quick
    # signal for which filters are complex without paying for the full member
    # listing.
    sql = f"""
    SELECT
      rf.name AS filter_name,
      rf.clause AS clause,
      dp.name AS dial_plan,
      rf.pkid AS pkid,
      (SELECT COUNT(*) FROM routefiltermember rfm WHERE rfm.fkroutefilter = rf.pkid) AS member_count
    FROM routefilter rf
    LEFT OUTER JOIN dialplan dp ON rf.fkdialplan = dp.pkid
    {where}
    ORDER BY rf.name
    """
    result = client.execute_sql_query(sql)
    if not result["rows"]:
        return {"filter_count": 0, "route_filters": []}

    out = []
    for filt in result["rows"]:
        entry = {
            "name": filt.get("filter_name"),
            "clause": filt.get("clause"),
            "dial_plan": filt.get("dial_plan"),
            "member_count": _to_int(filt.get("member_count")),
        }
        if include_members:
            member_sql = f"""
            SELECT
              dpt.tag AS tag,
              op.name AS operator,
              rfm.digits AS digits,
              rfm.precedence AS precedence
            FROM routefiltermember rfm
            LEFT OUTER JOIN dialplantag dpt ON rfm.fkdialplantag = dpt.pkid
            LEFT OUTER JOIN typeoperator op ON rfm.tkoperator = op.enum
            WHERE rfm.fkroutefilter = '{_esc(filt["pkid"])}'
            ORDER BY rfm.precedence
            """
            members = client.execute_sql_query(member_sql)
            entry["members"] = members["rows"]
        out.append(entry)

    return {"filter_count": len(out), "route_filters": out}


# ====================================================================
# Wildcard pattern matcher (better translation_chain)
# ====================================================================

# Hamilton review MAJOR #4: bound the digit-count of `!` and `@` wildcards
# to prevent catastrophic regex backtracking on adjacent-quantifier patterns.
# CUCM dial strings are practically capped well below this; 50 is a generous
# upper bound that keeps the regex's complexity polynomial.
_MAX_BANG_DIGITS = 50


def _wildcard_to_regex(pattern: str) -> str:
    r"""Convert a CUCM dial-plan pattern to a Python regex.

    CUCM wildcards:
      X        any single digit (0-9)
      !        one or more digits (bounded — see _MAX_BANG_DIGITS)
      .        terminator separator (after-dot digits get discarded by PreDot DDI)
      [0-9]    character class
      *, #     literal special-keypad symbols
      \+       literal + (escaped in CUCM)
      @        NANPA route filter — represented as bounded \d{1,N} here

    Hamilton review MAJOR #4: an unclosed `[` (e.g., `[0-9` with no closing
    bracket) used to silently fall through to treating the bracket as a
    literal. That produced wrong matches with no warning. We now raise
    ValueError so the caller can surface the malformed pattern explicitly.
    """
    bounded_digits = "\\d{1," + str(_MAX_BANG_DIGITS) + "}"
    out = []
    i = 0
    while i < len(pattern):
        c = pattern[i]
        if c == "X":
            out.append(r"\d")
        elif c == "!":
            out.append(bounded_digits)
        elif c == "@":
            # NANPA — would normally apply a route filter; treat as "any digits"
            out.append(bounded_digits)
        elif c == ".":
            # Terminator separator — matches a literal dot if used in test;
            # but in pattern matching against a dialed number it has no
            # effect on what's matched. Treat as zero-width.
            pass
        elif c == "[":
            # Character class — copy through up to `]`. An unclosed bracket
            # is a malformed pattern; raise so the caller knows.
            j = pattern.find("]", i)
            if j == -1:
                raise ValueError(
                    f"Unclosed character-class bracket in pattern {pattern!r} "
                    f"at position {i}"
                )
            out.append(pattern[i:j + 1])
            i = j
        elif c == "\\" and i + 1 < len(pattern):
            # Escaped literal — keep as literal
            out.append(re.escape(pattern[i + 1]))
            i += 1
        else:
            out.append(re.escape(c))
        i += 1
    return "^" + "".join(out) + "$"


def _pattern_matches_number(pattern: str, number: str) -> bool:
    """Test whether a CUCM dial pattern matches a number string.

    Returns False on any compilation error (malformed pattern, unclosed
    bracket, etc.) so a single bad pattern doesn't crash the entire
    translation_chain query. The bad pattern is surfaced separately
    via the error reporting in the response.
    """
    try:
        regex = _wildcard_to_regex(pattern)
    except ValueError:
        return False
    try:
        return re.match(regex, number) is not None
    except re.error:
        return False


def resolve_pattern_destination(client: "AxlClient", pattern_pkid: str) -> dict | None:
    """Given a route pattern pkid, return its destination route list / device.

    Route patterns connect to their destination via `devicenumplanmap`:
    the route-list header device (device.tkclass='Route List') maps to the
    pattern (numplan with tkpatternusage=5) through this join table. Same
    table also connects phone lines, so we filter by tkclass to disambiguate.
    """
    sql = f"""
    SELECT
      d.name AS destination_name,
      d.description AS destination_description,
      tc.name AS destination_class,
      d.pkid AS destination_pkid
    FROM devicenumplanmap dnm
    JOIN device d ON dnm.fkdevice = d.pkid
    JOIN typeclass tc ON d.tkclass = tc.enum
    WHERE dnm.fknumplan = '{_esc(pattern_pkid)}'
      AND tc.name IN ('Route List', 'Gateway', 'SIP Trunk', 'H323 Gateway',
                      'Hunt List', 'CTI Route Point', 'Voicemail Port')
    """
    result = client.execute_sql_query(sql)
    return result["rows"][0] if result["rows"] else None


def list_digit_discard_instructions(client: "AxlClient") -> dict:
    """Digit Discard Instructions catalog."""
    sql = """
    SELECT
      ddi.name AS name,
      ddi.description AS description,
      ddi.pkid AS pkid
    FROM digitdiscardinstruction ddi
    ORDER BY ddi.name
    """
    result = client.execute_sql_query(sql)
    return {"ddi_count": result["row_count"], "digit_discard_instructions": result["rows"]}


def translation_chain(client: "AxlClient", number: str, css_name: str | None = None) -> dict:
    """Find dial patterns that match a number, with CUCM wildcard evaluation.

    Two-stage approach:
      1. SQL fetches all patterns reachable from the given CSS (or all
         patterns if no CSS specified). This filters by partition membership.
      2. Python evaluates each pattern's CUCM wildcards (X, !, [0-9], @, etc.)
         against the number to find true matches, then sorts by pattern length
         (longest match wins in CUCM).

    Caveats:
      - The @-wildcard matches "any digits" rather than applying a route filter.
        For accurate filter-aware matching, inspect the route filter via
        list_route_filters() and reason about it manually.
      - We don't model the dial-plan's interdigit timeout or T302 timer —
        every pattern is evaluated against the complete number.
      - For overlapping matches, longest-match-wins is approximated by sorting
         result by pattern length descending. CUCM's actual matcher uses pattern
        specificity (a sub-rule based on wildcard depth); for unambiguous
        patterns the two agree.
    """
    css_filter = ""
    if css_name:
        css_filter = f"""
          AND rp.pkid IN (
            SELECT csm.fkroutepartition
            FROM callingsearchspacemember csm
            JOIN callingsearchspace css ON csm.fkcallingsearchspace = css.pkid
            WHERE css.name = '{_esc(css_name)}'
          )
        """

    # Pull every pattern in scope; we filter in Python with wildcard logic.
    sql = f"""
    SELECT
      np.dnorpattern AS pattern,
      tpu.name AS pattern_type,
      rp.name AS partition_name,
      np.callingpartytransformationmask AS calling_party_xform_mask,
      np.calledpartytransformationmask AS called_party_xform_mask,
      np.prefixdigitsout AS prefix_digits_out,
      ddi.name AS digit_discard_instructions,
      rf.name AS route_filter,
      np.description AS description
    FROM numplan np
    LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
    LEFT OUTER JOIN typepatternusage tpu ON np.tkpatternusage = tpu.enum
    LEFT OUTER JOIN digitdiscardinstruction ddi ON np.fkdigitdiscardinstruction = ddi.pkid
    LEFT OUTER JOIN routefilter rf ON np.fkroutefilter = rf.pkid
    WHERE np.tkpatternusage IN (3, 5, 7)
      AND np.dnorpattern IS NOT NULL
      {css_filter}
    """
    result = client.execute_sql_query(sql)

    matches = []
    for row in result["rows"]:
        pattern = row.get("pattern") or ""
        if _pattern_matches_number(pattern, number):
            matches.append({**row, "_match_specificity": len(pattern)})

    # Longest-match-first (CUCM's specificity heuristic, simplified)
    matches.sort(key=lambda m: m["_match_specificity"], reverse=True)

    return {
        "number": number,
        "css_name": css_name,
        "candidates_evaluated": result["row_count"],
        "match_count": len(matches),
        "matches": matches,
        "_note": (
            "Wildcards evaluated: X, !, [0-9], @, \\+. "
            "@-pattern matches any digit string (route filter constraints not applied). "
            "Longest-match-wins is approximated by pattern length; CUCM uses pattern "
            "specificity (wildcard depth). For most clusters these agree."
        ),
    }
