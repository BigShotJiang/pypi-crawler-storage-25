"""RisPort70 — real-time device registration status.

CUCM's RisPort (Real-time Information Server Port) lives at
`/realtimeservice2/services/RISService70` and exposes a SOAP API for
querying the *runtime* state of devices: are phones currently
registered, what IP did they get, what's their status, etc.

This is **complementary to AXL**: AXL tells us what's CONFIGURED;
RisPort tells us what's HAPPENING right now. For audit purposes the
difference between "configured but never registered" (orphan) and
"actively registered" (live) is the highest-value cross-reference.

Why we ship our own RisPort wrapper alongside the AXL one rather than
deferring to a separate operations MCP server (`@calltelemetry/cisco-cucm-mcp`
covers operational debugging more thoroughly): the audit-narrative is
the use case here. `phone_inventory_report` becomes substantively more
valuable when it can join configured-phones with currently-registered
state in a single prompt, and that join lives most naturally in this
codebase.

SOAP envelope structure cribbed from cisco-cucm-mcp's TypeScript
implementation (MIT licensed) — namespaces and field names verified
against CUCM 15 RisPort70 docs.
"""

from __future__ import annotations

import os
import re
import sys
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

from requests import Session
from requests.adapters import HTTPAdapter
from requests.auth import HTTPBasicAuth
from urllib3.util.retry import Retry


# RisPort path on the CUCM publisher
_RIS_PATH = "/realtimeservice2/services/RISService70"

# SOAP namespaces. These match Cisco's published values for RisPort70.
_NS_SOAPENV = "http://schemas.xmlsoap.org/soap/envelope/"
_NS_RIS = "http://schemas.cisco.com/ast/soap"

# Status values RisPort returns for devices
DEVICE_STATUS_VALUES = (
    "Any", "Registered", "UnRegistered", "Rejected",
    "PartiallyRegistered", "Unknown",
)


def _escape_xml(s: str) -> str:
    """Minimal XML entity escape for values we inject into SOAP envelopes."""
    return (
        s.replace("&", "&amp;")
         .replace("<", "&lt;")
         .replace(">", "&gt;")
         .replace('"', "&quot;")
         .replace("'", "&apos;")
    )


def _build_select_envelope(
    state_info: str = "",
    max_devices: int = 200,
    device_class: str = "Phone",
    status: str = "Any",
    select_items: list[str] | None = None,
    select_by: str = "Name",
) -> str:
    """Build a `selectCmDevice` SOAP envelope.

    The structure is fragile — the CmSelectionCriteria child elements
    must appear in the order Cisco's WSDL expects, and missing fields
    are rejected. We err on the side of always including every field
    with sensible defaults.
    """
    items = select_items if select_items else ["*"]
    items_xml = "".join(
        f"<soap:item><soap:Item>{_escape_xml(i)}</soap:Item></soap:item>"
        for i in items
    )
    return (
        '<?xml version="1.0" encoding="utf-8"?>'
        f'<soapenv:Envelope xmlns:soapenv="{_NS_SOAPENV}" xmlns:soap="{_NS_RIS}">'
        "<soapenv:Header/>"
        "<soapenv:Body>"
        "<soap:selectCmDevice>"
        f"<soap:StateInfo>{_escape_xml(state_info)}</soap:StateInfo>"
        "<soap:CmSelectionCriteria>"
        f"<soap:MaxReturnedDevices>{int(max_devices)}</soap:MaxReturnedDevices>"
        f"<soap:DeviceClass>{_escape_xml(device_class)}</soap:DeviceClass>"
        "<soap:Model>255</soap:Model>"
        f"<soap:Status>{_escape_xml(status)}</soap:Status>"
        "<soap:NodeName></soap:NodeName>"
        f"<soap:SelectBy>{_escape_xml(select_by)}</soap:SelectBy>"
        f"<soap:SelectItems>{items_xml}</soap:SelectItems>"
        "<soap:Protocol>Any</soap:Protocol>"
        "<soap:DownloadStatus>Any</soap:DownloadStatus>"
        "</soap:CmSelectionCriteria>"
        "</soap:selectCmDevice>"
        "</soapenv:Body>"
        "</soapenv:Envelope>"
    )


def _extract_text(elem: ET.Element | None, tag: str) -> str:
    """Return the text of <tag> child of elem, or '' if missing.

    RisPort responses don't use namespaces consistently across CUCM
    versions; matching on local-name only is more robust than xpath
    against a fixed namespace.
    """
    if elem is None:
        return ""
    for child in elem:
        if child.tag.split("}")[-1] == tag:
            return (child.text or "").strip()
    return ""


def _extract_ip(elem: ET.Element | None) -> str:
    """Pull the IP string out of CUCM's nested IPAddress structure.

    CUCM 15 returns IPAddress as a nested struct:
      <IPAddress><item><IP>x.x.x.x</IP><IPAddrType>ipv4</IPAddrType></item></IPAddress>
    Older versions may return a flat string. We handle both.
    """
    if elem is None:
        return ""
    if elem.text and elem.text.strip():
        return elem.text.strip()
    for item_elem in elem:
        if item_elem.tag.split("}")[-1].lower() == "item":
            for ip_elem in item_elem:
                if ip_elem.tag.split("}")[-1] == "IP":
                    return (ip_elem.text or "").strip()
    return ""


def _parse_device(elem: ET.Element) -> dict:
    """Pull the audit-relevant fields out of a single CmDevice element."""
    ip_elem = None
    for child in elem:
        local = child.tag.split("}")[-1]
        if local in ("IPAddress", "IpAddress"):
            ip_elem = child
            break
    return {
        "name": _extract_text(elem, "Name"),
        "ip_address": _extract_ip(ip_elem),
        "description": _extract_text(elem, "Description"),
        "dir_number": _extract_text(elem, "DirNumber"),
        "status": _extract_text(elem, "Status"),
        "status_reason": _extract_text(elem, "StatusReason"),
        "protocol": _extract_text(elem, "Protocol"),
        "model": _extract_text(elem, "Model"),
        "active_load_id": _extract_text(elem, "ActiveLoadID"),
        "timestamp": _extract_text(elem, "TimeStamp"),
    }


def _parse_response(xml_text: str) -> dict:
    """Parse the selectCmDevice SOAP response into structured form.

    Returns:
      {
        "total_devices_found": int,
        "state_info": str (cursor for next page; empty = last),
        "cm_nodes": [
          {"name": str, "return_code": str, "devices": [...]}
        ],
      }
    """
    root = ET.fromstring(xml_text)
    # Walk to selectCmDeviceReturn regardless of namespacing quirks
    select_return = None
    for elem in root.iter():
        if elem.tag.split("}")[-1] == "selectCmDeviceReturn":
            select_return = elem
            break
    if select_return is None:
        # Check for SOAP fault
        for elem in root.iter():
            if elem.tag.split("}")[-1] == "Fault":
                fault_string = _extract_text(elem, "faultstring")
                raise RuntimeError(f"RisPort SOAP fault: {fault_string or 'unknown'}")
        raise RuntimeError("RisPort response missing selectCmDeviceReturn")

    # CUCM 15 wraps the data in an extra <SelectCmDeviceResult> element
    # inside <selectCmDeviceReturn>. Older versions exposed the fields
    # directly. Probe for the wrapper and descend if found.
    for child in select_return:
        if child.tag.split("}")[-1] == "SelectCmDeviceResult":
            select_return = child
            break

    total = _extract_text(select_return, "TotalDevicesFound")
    state_info = _extract_text(select_return, "StateInfo")

    nodes_out = []
    cm_nodes = None
    for child in select_return:
        if child.tag.split("}")[-1] == "CmNodes":
            cm_nodes = child
            break

    if cm_nodes is not None:
        for node_elem in cm_nodes:
            if node_elem.tag.split("}")[-1] != "item":
                continue
            node_name = _extract_text(node_elem, "Name")
            return_code = _extract_text(node_elem, "ReturnCode")
            devices: list[dict] = []
            for cm_devices_elem in node_elem:
                if cm_devices_elem.tag.split("}")[-1] != "CmDevices":
                    continue
                for dev_item in cm_devices_elem:
                    if dev_item.tag.split("}")[-1] == "item":
                        devices.append(_parse_device(dev_item))
            nodes_out.append({
                "name": node_name,
                "return_code": return_code,
                "devices": devices,
            })

    try:
        total_int = int(total)
    except (TypeError, ValueError):
        total_int = 0

    return {
        "total_devices_found": total_int,
        "state_info": state_info,
        "cm_nodes": nodes_out,
    }


class RisPortClient:
    """Lazy SOAP client for CUCM's RisPort70 service.

    Reuses AXL_URL / AXL_USER / AXL_PASS env vars (RisPort lives on the
    same host as AXL on standard CUCM deployments). Builds a separate
    `requests.Session` so the retry policy and TLS settings can be tuned
    independently if needed.
    """

    def __init__(self):
        self._session: Session | None = None
        self._url: str | None = None
        self._config_error: str | None = None
        self._last_error: str | None = None

    def _ensure_session(self) -> None:
        if self._session is not None:
            return
        if self._config_error is not None:
            raise RuntimeError(self._config_error)
        try:
            axl_url = os.environ["AXL_URL"]
            user = os.environ["AXL_USER"]
            password = os.environ["AXL_PASS"]
        except KeyError as e:
            self._config_error = (
                f"Missing required env var {e.args[0]} for RisPort. "
                f"Reuses AXL_URL/USER/PASS."
            )
            raise RuntimeError(self._config_error) from None

        verify_tls = os.environ.get("AXL_VERIFY_TLS", "false").lower() in (
            "1", "true", "yes"
        )

        # Derive RisPort URL from AXL host
        parsed = urlparse(axl_url)
        if not parsed.hostname:
            self._config_error = f"Could not parse AXL_URL host: {axl_url!r}"
            raise RuntimeError(self._config_error)
        port = parsed.port or 8443
        scheme = parsed.scheme or "https"
        self._url = f"{scheme}://{parsed.hostname}:{port}{_RIS_PATH}"

        session = Session()
        session.verify = verify_tls
        session.auth = HTTPBasicAuth(user, password)

        # Same retry policy as AXL — 503/502/504 with backoff
        max_retries = int(os.environ.get("AXL_RATE_LIMIT_RETRIES", "3"))
        if max_retries > 0:
            retry = Retry(
                total=max_retries,
                backoff_factor=1.0,
                status_forcelist=(502, 503, 504),
                allowed_methods=frozenset(["POST", "GET"]),
                raise_on_status=False,
                respect_retry_after_header=True,
            )
            adapter = HTTPAdapter(max_retries=retry)
            session.mount("https://", adapter)
            session.mount("http://", adapter)

        self._session = session
        print(
            f"[mcaxl] RisPort client ready: {self._url}",
            file=sys.stderr,
            flush=True,
        )

    def select_cm_device(
        self,
        max_devices: int = 200,
        device_class: str = "Phone",
        status: str = "Any",
        name_filter: str | None = None,
        state_info: str = "",
    ) -> dict:
        """Single-page selectCmDevice call. Returns up to max_devices rows.

        For full inventory, call `select_all` which auto-paginates via
        the `state_info` cursor.
        """
        # Validate before connecting — we want a clear error from bad input
        # whether or not env vars are set.
        if status not in DEVICE_STATUS_VALUES:
            raise ValueError(
                f"status must be one of {DEVICE_STATUS_VALUES}; got {status!r}"
            )
        self._ensure_session()

        select_items = [name_filter] if name_filter else ["*"]
        envelope = _build_select_envelope(
            state_info=state_info,
            max_devices=max_devices,
            device_class=device_class,
            status=status,
            select_items=select_items,
        )
        try:
            resp = self._session.post(
                self._url,
                data=envelope,
                headers={
                    "Content-Type": "text/xml; charset=utf-8",
                    "SOAPAction": '"selectCmDevice"',
                },
                timeout=30,
            )
            resp.raise_for_status()
            self._last_error = None
            return _parse_response(resp.text)
        except Exception as e:
            self._last_error = f"RisPort request failed: {e}"
            raise RuntimeError(self._last_error) from e

    def select_all(
        self,
        device_class: str = "Phone",
        status: str = "Any",
        page_size: int = 200,
        max_pages: int = 20,
    ) -> dict:
        """Auto-paginate through selectCmDevice using the StateInfo cursor.

        Walks pages until the cursor is empty OR max_pages reached. Returns
        a single dict with all devices flattened across pages, plus
        per-status counts and a `pages_walked` field for diagnostics.
        """
        all_devices: list[dict] = []
        nodes_seen: set[str] = set()
        state_info = ""
        pages = 0
        last_total = 0
        while pages < max_pages:
            page = self.select_cm_device(
                max_devices=page_size,
                device_class=device_class,
                status=status,
                state_info=state_info,
            )
            pages += 1
            last_total = page["total_devices_found"]
            for node in page["cm_nodes"]:
                nodes_seen.add(node["name"])
                all_devices.extend(node["devices"])
            next_cursor = page.get("state_info") or ""
            if not next_cursor or next_cursor == state_info:
                break
            state_info = next_cursor

        # Per-status breakdown
        status_counts: dict[str, int] = {}
        for d in all_devices:
            s = d.get("status") or "Unknown"
            status_counts[s] = status_counts.get(s, 0) + 1

        return {
            "device_class": device_class,
            "status_filter": status,
            "total_devices_found": last_total,
            "devices_returned": len(all_devices),
            "pages_walked": pages,
            "cm_nodes_seen": sorted(nodes_seen),
            "status_counts": status_counts,
            "devices": all_devices,
        }
