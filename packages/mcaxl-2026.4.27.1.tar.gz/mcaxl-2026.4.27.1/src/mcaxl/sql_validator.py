"""Defense-in-depth: ensure queries we send to executeSQLQuery are SELECT-only.

CUCM's AXL service rejects writes via executeSQLQuery server-side (writes go
through a separate executeSQLUpdate method that we never expose). This client-
side check exists to:
  1. Give the LLM a fast, clear error before a SOAP round-trip.
  2. Make read-only intent visible at the boundary, not implicit.
"""

from __future__ import annotations

import re


_COMMENT_BLOCK = re.compile(r"/\*.*?\*/", re.DOTALL)
_COMMENT_LINE = re.compile(r"--[^\n]*")
# Match Informix string literals: single-quoted, with '' as escaped quote.
_STRING_LITERAL = re.compile(r"'(?:''|[^'])*'", re.DOTALL)
_FORBIDDEN = {
    "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER",
    "TRUNCATE", "GRANT", "REVOKE", "MERGE", "REPLACE", "RENAME",
    "EXEC", "EXECUTE", "CALL", "ATTACH", "DETACH",
}
_WORD_RE = re.compile(r"\b([A-Za-z_]+)\b")


class SqlValidationError(ValueError):
    """Raised when a query is not a safe read-only SELECT/WITH."""


def validate_select(query: str) -> str:
    """Return the cleaned query, or raise SqlValidationError.

    Accepts SELECT and WITH (CTEs that ultimately return SELECT). Rejects
    anything else, and any query containing forbidden keywords as standalone
    tokens *outside* string literals and comments.

    Hamilton review CRITICAL #1: the output we return MUST preserve the input
    byte-for-byte (modulo trailing semicolon and outer whitespace). Earlier
    versions ran a non-literal-aware comment strip on the output, which would
    silently eat `--` and `/* */` markers that legitimately appeared inside
    string literals like `WHERE description = 'Smith -- old line'`. The query
    going to AXL must be exactly what the caller intended — comment stripping
    is an analysis-only operation, never a mutation of the wire query.
    """
    if not query or not query.strip():
        raise SqlValidationError("Query is empty.")

    # The query we'll send to AXL: original input, with only outer whitespace
    # and a single trailing semicolon trimmed. NO mutation of literals or
    # in-string comment markers.
    cleaned = query.strip().rstrip(";").strip()
    if not cleaned:
        raise SqlValidationError("Query is empty after trimming.")

    # Analysis-only copy: strip string literals AND comments (in either order
    # is safe here, since each strip uses its own regex on a non-AXL-bound
    # buffer). Order chosen: literals first, then comments, so that any
    # comment markers genuinely outside literals can be detected.
    for_analysis = _STRING_LITERAL.sub(" ", cleaned)
    for_analysis = _COMMENT_BLOCK.sub(" ", for_analysis)
    for_analysis = _COMMENT_LINE.sub(" ", for_analysis)

    if not for_analysis.strip():
        raise SqlValidationError("Query is empty after stripping comments.")

    upper_tokens = [t.upper() for t in _WORD_RE.findall(for_analysis)]
    if not upper_tokens:
        raise SqlValidationError("Query contains no SQL keywords.")

    first = upper_tokens[0]
    if first not in {"SELECT", "WITH"}:
        raise SqlValidationError(
            f"Only SELECT and WITH are permitted; query starts with {first!r}."
        )

    forbidden_hits = sorted(set(upper_tokens) & _FORBIDDEN)
    if forbidden_hits:
        raise SqlValidationError(
            f"Forbidden keyword(s) present: {', '.join(forbidden_hits)}. "
            f"This server is read-only."
        )

    return cleaned
