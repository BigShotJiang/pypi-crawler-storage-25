"""SQLite-backed TTL cache for AXL responses.

Keyed on (cluster_id, method_name, sorted_kwargs_json). Cache survives server
restarts, which makes exploratory audit sessions dramatically faster — the LLM
can re-run the same `listPhone` queries across conversations without paying
the SOAP round-trip every time.

Hamilton review CRITICAL #2: cache key now includes a `cluster_id` so that
the same on-disk database can hold entries from multiple clusters without
silently serving cluster A's data when bound to cluster B. Operators who
swap `AXL_URL` between test and prod no longer see cross-cluster contamination.
"""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any


# Split into TABLE_DDL (idempotent table creation) and INDEX_DDL (run AFTER
# any column-adding migration, so indexes that reference newer columns don't
# fail against legacy databases).
TABLE_DDL = """
CREATE TABLE IF NOT EXISTS axl_cache (
    cache_key   TEXT PRIMARY KEY,
    cluster_id  TEXT NOT NULL DEFAULT '',
    method      TEXT NOT NULL,
    args_json   TEXT NOT NULL,
    result_json TEXT NOT NULL,
    created_at  REAL NOT NULL,
    expires_at  REAL NOT NULL
);
"""

INDEX_DDL = """
CREATE INDEX IF NOT EXISTS axl_cache_method_idx ON axl_cache(method);
CREATE INDEX IF NOT EXISTS axl_cache_expires_idx ON axl_cache(expires_at);
CREATE INDEX IF NOT EXISTS axl_cache_cluster_idx ON axl_cache(cluster_id);
"""


class AxlCache:
    """SQLite TTL cache. Thread-safe via per-call connections."""

    def __init__(
        self,
        db_path: Path,
        default_ttl: int,
        cluster_id: str | None = None,
    ):
        self.db_path = db_path
        self.default_ttl = default_ttl
        # Empty string when unset — matches the column DEFAULT and keeps
        # SQL filtering simple. Pre-fix databases will have '' for legacy
        # entries, which is fine: a server now passing cluster_id="prod"
        # won't see them, which is the correct cautious behavior.
        self.cluster_id = cluster_id or ""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            # 1) Make sure table exists (no-op if already present)
            c.executescript(TABLE_DDL)
            # 2) Bring legacy schemas forward (adds cluster_id if missing)
            self._migrate(c)
            # 3) NOW create indexes — safe because all columns exist
            c.executescript(INDEX_DDL)

    @staticmethod
    def _migrate(c: sqlite3.Connection) -> None:
        """Bring pre-existing databases up to the current schema.

        `CREATE TABLE IF NOT EXISTS` is idempotent for table existence but
        does not add columns to an already-existing table. Pre-fix caches
        lack `cluster_id`; rather than failing the next INSERT with
        `no such column`, we add it here. Defaults to '' which makes the
        legacy entries belong to the "unknown cluster" — invisible to any
        new client passing an actual cluster_id, which is the cautious
        outcome.
        """
        cols = {row[1] for row in c.execute("PRAGMA table_info(axl_cache)").fetchall()}
        if "cluster_id" not in cols:
            c.execute(
                "ALTER TABLE axl_cache ADD COLUMN cluster_id TEXT NOT NULL DEFAULT ''"
            )

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, isolation_level=None)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        return conn

    def _make_key(self, method: str, kwargs: dict) -> str:
        # cluster_id prefix isolates entries by cluster identity. sort_keys
        # gives us a deterministic key regardless of dict order.
        return (
            f"{self.cluster_id}::{method}::"
            f"{json.dumps(kwargs, sort_keys=True, default=str)}"
        )

    def get(self, method: str, kwargs: dict) -> Any | None:
        if self.default_ttl <= 0:
            return None
        key = self._make_key(method, kwargs)
        now = time.time()
        with self._conn() as c:
            row = c.execute(
                "SELECT result_json FROM axl_cache WHERE cache_key = ? AND expires_at > ?",
                (key, now),
            ).fetchone()
        return json.loads(row[0]) if row else None

    def set(self, method: str, kwargs: dict, result: Any, ttl: int | None = None) -> None:
        if self.default_ttl <= 0 and ttl is None:
            return
        ttl = ttl if ttl is not None else self.default_ttl
        if ttl <= 0:
            return
        key = self._make_key(method, kwargs)
        now = time.time()
        with self._conn() as c:
            c.execute(
                """
                INSERT OR REPLACE INTO axl_cache
                  (cache_key, cluster_id, method, args_json, result_json,
                   created_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    key,
                    self.cluster_id,
                    method,
                    json.dumps(kwargs, sort_keys=True, default=str),
                    json.dumps(result, default=str),
                    now,
                    now + ttl,
                ),
            )

    def stats(self) -> dict:
        now = time.time()
        with self._conn() as c:
            # Entries scoped to THIS cluster_id. The on-disk file may also
            # contain entries from other clusters; those are intentionally
            # invisible here.
            total = c.execute(
                "SELECT COUNT(*) FROM axl_cache WHERE cluster_id = ?",
                (self.cluster_id,),
            ).fetchone()[0]
            live = c.execute(
                "SELECT COUNT(*) FROM axl_cache "
                "WHERE cluster_id = ? AND expires_at > ?",
                (self.cluster_id, now),
            ).fetchone()[0]
            by_method = {
                row[0]: row[1]
                for row in c.execute(
                    "SELECT method, COUNT(*) FROM axl_cache "
                    "WHERE cluster_id = ? AND expires_at > ? "
                    "GROUP BY method ORDER BY 2 DESC",
                    (self.cluster_id, now),
                ).fetchall()
            }
            # Diagnostic: how many entries from OTHER clusters live in the
            # same file. Useful for spotting an env-var swap that would
            # otherwise be invisible.
            foreign = c.execute(
                "SELECT COUNT(*) FROM axl_cache WHERE cluster_id != ?",
                (self.cluster_id,),
            ).fetchone()[0]
        return {
            "db_path": str(self.db_path),
            "cluster_id": self.cluster_id,
            "default_ttl_seconds": self.default_ttl,
            "total_entries": total,
            "live_entries": live,
            "expired_entries": total - live,
            "foreign_cluster_entries": foreign,
            "by_method": by_method,
        }

    def clear(self, method_pattern: str | None = None) -> int:
        # Only clears entries for THIS cluster — never touches a sibling
        # cluster's cached data even if it lives in the same file.
        with self._conn() as c:
            if method_pattern:
                cursor = c.execute(
                    "DELETE FROM axl_cache "
                    "WHERE cluster_id = ? AND method LIKE ?",
                    (self.cluster_id, method_pattern.replace("*", "%")),
                )
            else:
                cursor = c.execute(
                    "DELETE FROM axl_cache WHERE cluster_id = ?",
                    (self.cluster_id,),
                )
            return cursor.rowcount

    def purge_expired(self) -> int:
        # Purges expired entries across ALL clusters in this file.
        # Expired entries are never useful regardless of which cluster
        # they belong to, so per-cluster scoping isn't needed here.
        with self._conn() as c:
            cursor = c.execute("DELETE FROM axl_cache WHERE expires_at <= ?", (time.time(),))
            return cursor.rowcount
