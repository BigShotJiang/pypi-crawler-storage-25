"""Comprehensive SIP trunk inventory: profiles, destinations, route-group
membership, and findings template.

Implementation reference: `docs/query-patterns/sip-trunk-report.md`. The
query patterns embedded below are the validated forms from that doc;
update them in lockstep when the schema knowledge evolves.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import SIP_TRUNK_KEYWORDS, render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


def _esc(s: str) -> str:
    """Inline string-literal escape — same convention as route_plan._esc.
    Single quotes get doubled for Informix; everything else passes through.
    """
    return s.replace("'", "''")


def render(docs: "DocsIndex | None", name_filter: str | None = None) -> str:
    """Produce a SIP trunk inventory + findings prompt.

    Args:
        name_filter: If given, narrow the inventory to trunks whose name
            matches the substring (case-sensitive LIKE). Otherwise
            includes all trunks.
    """
    schema_block = render_schema_block(
        docs, SIP_TRUNK_KEYWORDS, max_chunks=4, max_chars_per_chunk=900
    )

    # Build the LIKE clause for the name filter, if provided. The filter
    # value is escaped for SQL safety, then wrapped in `%`-bookends for
    # substring matching against device.name.
    if name_filter:
        safe = _esc(name_filter)
        name_clause = f"\n  AND d.name LIKE '%{safe}%'"
        scope_note = f"narrowed to trunks matching `%{name_filter}%`"
    else:
        name_clause = ""
        scope_note = "all SIP trunks"

    return f"""# CUCM SIP Trunk Report — {scope_note}

Produce a comprehensive SIP trunk inventory: profiles, destinations,
downstream route-group membership, and a findings analysis. The queries
below are the validated forms from `docs/query-patterns/sip-trunk-report.md`.

## Step 1 — Trunk inventory (one row per trunk)

```sql
SELECT
  d.name                          AS trunk_name,
  d.description,
  sp.name                         AS sip_profile,
  css.name                        AS calling_search_space,
  dp.name                         AS device_pool,
  loc.name                        AS location,
  tsc.name                        AS preferred_codec,
  sd.requesturidomainname         AS sip_domain,
  sd.isanonymous                  AS anon_caller_id,
  sd.preferrouteheaderdestination AS prefer_route_header,
  sd.acceptinboundrdnis           AS accept_inbound_rdnis,
  sd.acceptoutboundrdnis          AS accept_outbound_rdnis
FROM device d
JOIN typeclass tc            ON d.tkclass = tc.enum
JOIN sipdevice sd            ON sd.fkdevice = d.pkid
LEFT JOIN sipprofile sp      ON d.fksipprofile = sp.pkid
LEFT JOIN callingsearchspace css ON d.fkcallingsearchspace = css.pkid
LEFT JOIN devicepool dp      ON d.fkdevicepool = dp.pkid
LEFT JOIN location loc       ON d.fklocation = loc.pkid
LEFT JOIN typesipcodec tsc   ON sd.tksipcodec = tsc.enum
WHERE tc.name = 'Trunk'{name_clause}
ORDER BY d.name;
```

Run via `axl_sql(query=<the SQL above>)`.

`anon_caller_id`, `prefer_route_header`, and the RDNIS flags return `'t'`
or `'f'` (Informix bool encoding). Render with that in mind.

## Step 2 — Destinations (one row per IP/port; trunks can have multiple)

```sql
SELECT
  d.name        AS trunk_name,
  std.address,
  std.port,
  std.sortorder
FROM siptrunkdestination std
JOIN sipdevice sd ON std.fksipdevice = sd.pkid
JOIN device d     ON sd.fkdevice = d.pkid{name_clause.replace("d.name LIKE", "d.name LIKE")}
ORDER BY d.name, std.sortorder;
```

`address` may be an IP literal *or* a DNS name (Expressway-C trunks often
use FQDNs). `port` defaults to 5060 (UDP/TCP) or 5061 (TLS).

## Step 3 — Route-group / route-list membership

Don't write raw SQL — use the existing tool:

```
route_lists_and_groups()
```

Filter the result for `route_groups[].devices[].class == "Trunk"` to find
the (trunk → route group → route list) triples. Note: route lists with
**route groups that have no static device members** resolve at call-time
via the calling phone's device-pool `fkroutegroup_local` mapping (CUCM
Standard Local Route Group feature). Trunks reachable only through Local
Route Groups won't appear in the static result — call
`route_device_pool_route_groups()` to enumerate those.

## Step 4 — Findings to call out

After the data is gathered, produce findings on each axis:

- **Single-point-of-failure trunks**: route groups with one trunk member
  where that group is the only path for a critical pattern (911,
  voicemail, fax). Cross-reference with `route_lists_and_groups()`.
- **Profile sprawl vs. consolidation**: are N trunks using N different
  SIP profiles, or do most share a small number? Sprawl = harder to
  audit transport/timing settings consistently.
- **CSS asymmetry**: PSTN-facing inbound trunks should typically have
  restrictive CSSs; internal-facing trunks (voicemail) should have
  permissive ones. Mismatches can cause one-way audio or routing failures.
- **Codec heterogeneity**: most clusters standardize on G.711 µ-law.
  Trunks advertising G.722 or G.729 first warrant explanation.
- **DNS-vs-IP destinations**: trunks using FQDNs depend on cluster DNS;
  flag if FQDN resolution adds an unsurfaced SPOF.
- **Security posture**: trunks using `Non Secure SIP Trunk Profile` for
  carrier-facing connections are typical for premise SIP carriers but
  worth documenting as a deliberate choice.
- **NULL primary CSS** on trunks is *not* automatically a finding —
  Expressway-C and InformaCast Fusion trunks legitimately have it
  (they don't originate generic outbound routing).

## Suggested follow-up calls

- `route_devices_using_css(css_name=<each unique trunk CSS>)` — what else
  uses the same CSS as a particular trunk? Identifies shared dependencies.
- `route_inspect_pattern(pattern, partition)` — for each route pattern
  that targets a trunk-bearing route list, walk the call path.
- `axl_sql("SELECT name, description FROM sipprofile")` — when multiple
  trunks share a SIP profile, look up the profile detail once.

## Reference: CUCM data dictionary (SIP trunk-related tables)

{schema_block}

Run the queries above, then produce a structured trunk-by-trunk report
followed by the findings analysis. Use markdown tables for the inventory
section; reserve prose for findings and recommendations.
"""
