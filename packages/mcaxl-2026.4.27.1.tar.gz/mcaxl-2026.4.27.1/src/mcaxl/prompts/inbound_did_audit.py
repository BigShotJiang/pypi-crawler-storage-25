"""Inbound DID inventory: XFORM-Inbound-DNIS, screening, executed routing."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


_KEYWORDS = [
    "translation pattern", "called party transformation", "DNIS",
    "inbound", "route pattern", "transformation mask", "PSTN",
]


def render(docs: "DocsIndex | None") -> str:
    """Inventory of every PSTN DID that *might* be presented to the cluster,
    cross-referenced against actual routing destinations.

    Pattern: turn the operator-curated XFORM-Inbound-DNIS list into a
    "presentable DID inventory" with destination cross-checks. Surfaces
    orphan target extensions, undocumented DIDs, and the silent-fallback
    catch-all hazard.
    """
    schema_block = render_schema_block(
        docs, _KEYWORDS, max_chunks=4, max_chars_per_chunk=900
    )

    return """# CUCM Inbound DID Audit

The cluster's inbound architecture has multiple transformation layers.
This audit reconstructs the full set of DIDs that "should" be presentable
and cross-checks them against actual routing destinations.

## Conceptual model (verify on this cluster)

Inbound calls usually traverse:

1. PSTN-facing trunk (typically `PSTN-Router-SIP-Trk` or similar) →
   trunk's primary CSS, e.g. `PSTN-Inbound-CSS`.
2. `PSTN-Inbound-PT` partition with a `!` translation that re-routes to
   `PSTN-Screen-CSS` for spam filtering.
3. `PSTN-Screen-PT` with operator-curated `block_enabled=true` translation
   patterns for spam blocking, plus a `!` / `\\+!` catch-all that
   re-routes via `Internal-CSS`.
4. `Internal-CSS` finds the destination — either a 10-digit route pattern
   in `Internal-PT` (typically routes to fax trunks) or a directory
   number after some upstream transformation.

The XFORM-Inbound-DNIS partition holds 100+ "Called Party Number
Transformation" patterns (`tkpatternusage = 20`) that map external DIDs
to internal extensions. **Whether they fire automatically depends on
the trunk's `fkcallingsearchspace_cntdpntransform` setting** — confirm
this with the operator or via:

```sql
SELECT d.name, sd.fkcallingsearchspace_cntdpntransform
FROM device d JOIN sipdevice sd ON sd.fkdevice = d.pkid
JOIN typeclass tc ON d.tkclass = tc.enum
WHERE tc.name = 'Trunk';
```

## Step 1 — Operator-curated DID inventory (XFORM-Inbound-DNIS)

```sql
SELECT
  np.dnorpattern AS inbound_did,
  np.calledpartytransformationmask AS xform_to,
  np.prefixdigitsout AS prefix_out,
  np.description
FROM numplan np
JOIN routepartition rp ON np.fkroutepartition = rp.pkid
WHERE rp.name = 'XFORM-Inbound-DNIS'
ORDER BY np.dnorpattern;
```

Categorize the result:

- **Pass-through 10-digit** (`xform_to IS NULL`, description "remain as 10-digit"):
  the DID is expected to match a corresponding route pattern in `Internal-PT`.
- **Block-translation to 4-digit** (`xform_to LIKE '7XXX'` or similar):
  rewrites last N digits to an internal extension range.
- **Specific renames** (literal `xform_to` like `7400`, `2523`):
  one-off DID-to-extension mappings, often legacy clinic numbers.
- **Wildcard ranges** (pattern contains `[N-M]`, `XXX`, `.`):
  efficient block mappings worth reviewing for bounds correctness.
- **Catch-all `!`**: dangerous silent fallback if present — flag it.

## Step 2 — Actually-executed routing (Internal-PT route patterns ≥7 digits)

```sql
SELECT np.dnorpattern, np.description, np.blockenable
FROM numplan np
JOIN routepartition rp ON np.fkroutepartition = rp.pkid
WHERE rp.name = 'Internal-PT'
  AND np.tkpatternusage = 5  -- Route pattern
  AND LENGTH(np.dnorpattern) >= 7
ORDER BY np.dnorpattern;
```

Cross-check:
- Every "remain as 10-digit" DID from Step 1 should have a matching
  10-digit route pattern here.
- Every route pattern here should have a known purpose (typically routes
  to a fax trunk or hunt list).

## Step 3 — Spam blocklist (operator-curated, audit-relevant)

```sql
SELECT np.dnorpattern, np.description
FROM numplan np
JOIN routepartition rp ON np.fkroutepartition = rp.pkid
WHERE rp.name = 'PSTN-Screen-PT' AND np.blockenable = 't'
ORDER BY np.dnorpattern;
```

Spam blocklists rotate every 30-60 days as campaigns shift. This is
informational, but persistently-stale entries (descriptions like
"Number spamming X's phone" from 1+ year ago) can be retired.

## Step 4 — Verify target extensions exist

For each unique target extension referenced in Step 1's renames, confirm
it actually exists as a real DN:

```sql
-- Replace '7400, 2523, 2532, ...' with the unique targets from Step 1
SELECT FIRST 50 np.dnorpattern, np.description, rp.name AS partition
FROM numplan np
JOIN routepartition rp ON np.fkroutepartition = rp.pkid
WHERE np.tkpatternusage = 2  -- Directory Number
  AND np.dnorpattern IN ('7400', '2523', '2532', '...')
ORDER BY np.dnorpattern;
```

A DID that translates to an extension that doesn't exist is a *broken*
inbound DID — calls succeed in the transformation step but fail at the
final DN lookup.

## Findings to call out

- **Orphan target extensions**: any DID that translates to a non-existent
  DN. High-severity audit finding — caller hears "number not found" or
  reorder.
- **`!` catch-all in XFORM-Inbound-DNIS**: silently rewrites unrecognized
  DIDs to their last 4 digits. Recommend documenting or removing — at
  minimum, surface the risk.
- **Old clinic / legacy DIDs**: if multiple DIDs forward to the same
  internal extension with descriptions referencing legacy locations,
  confirm the target is a hunt pilot or reception line, not a single
  user receiving misdirected calls.
- **Block-of-N pass-through declarations** (e.g., `20878594XX` declares
  100 DIDs): verify carrier allocation matches the block size. Excess
  declarations are harmless but noisy.
- **Spam blocklist hygiene**: > 6-month-old entries that are no longer
  active campaigns are cleanup candidates.
- **Stale block_enabled outbound DIDs** (`Internal-PT` route patterns
  with `blockenable = 't'`): confirm intentional. Single oddballs among
  many similar route patterns warrant a description annotation.

## Suggested follow-up calls

- `route_inspect_pattern(<DID>)` for any specific DID where the audit
  needs the full route trace (CSS reachability, destination chain).
- `axl_sql("SELECT * FROM numplan WHERE dnorpattern = '<target ext>'")`
  to verify each rewrite target exists.
- `route_devices_using_css('PSTN-Inbound-CSS')` to confirm the inbound
  trunk(s) using this CSS — should typically be just 1.

## Reference: CUCM data dictionary (translation patterns)

""" + schema_block + """

Run the queries above and produce a structured findings report. Group
by DID handling category (Step 1 categorization), then list orphan-
target findings and other hygiene issues. Don't enumerate all 100+
DIDs — group by exchange (208-XXX-) and call out exceptions.
"""
