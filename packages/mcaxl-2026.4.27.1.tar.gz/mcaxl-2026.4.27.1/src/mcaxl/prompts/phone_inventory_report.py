"""Phone inventory + audit findings: device pools, CSSs, owners, anomalies."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


_KEYWORDS = [
    "phone", "device", "device pool", "calling search space",
    "model", "owner", "extension mobility",
]


def _esc(s: str) -> str:
    return s.replace("'", "''")


def render(docs: "DocsIndex | None", filter: str | None = None) -> str:
    """Phone inventory: counts by class, distribution by pool/CSS/model,
    plus findings around orphans, drift, and naming anomalies.

    Args:
        filter: Optional substring (case-sensitive LIKE on `device.name`
            OR `device.description`) to narrow the inventory.
    """
    schema_block = render_schema_block(
        docs, _KEYWORDS, max_chunks=4, max_chars_per_chunk=900
    )

    if filter:
        safe = _esc(filter)
        name_clause = f"\n  AND (d.name LIKE '%{safe}%' OR d.description LIKE '%{safe}%')"
        scope_note = f"narrowed to phones matching `%{filter}%`"
    else:
        name_clause = ""
        scope_note = "all phones"

    return f"""# CUCM Phone Inventory — {scope_note}

Produce a phone inventory with audit-relevant groupings and findings.
The cluster typically has hundreds-to-thousands of phones; this prompt
asks for *aggregations and anomalies*, not a flat dump.

## Step 1 — Aggregate counts (always run first)

```sql
SELECT tm.name AS model, COUNT(*) AS phone_count
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
LEFT OUTER JOIN typemodel tm ON d.tkmodel = tm.enum
WHERE tc.name = 'Phone'{name_clause}
GROUP BY tm.name ORDER BY 2 DESC;
```

```sql
SELECT dp.name AS device_pool, COUNT(*) AS phone_count
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
LEFT OUTER JOIN devicepool dp ON d.fkdevicepool = dp.pkid
WHERE tc.name = 'Phone'{name_clause}
GROUP BY dp.name ORDER BY 2 DESC;
```

```sql
SELECT css.name AS css_name, COUNT(*) AS phone_count
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
LEFT OUTER JOIN callingsearchspace css ON d.fkcallingsearchspace = css.pkid
WHERE tc.name = 'Phone'{name_clause}
GROUP BY css.name ORDER BY 2 DESC;
```

These three give the shape of the fleet. The CSS one in particular is
audit-critical: most phones should land in a small number of CSSs
(typically `National-CSS` for outbound dialing on this kind of cluster).
*Outliers* in the CSS distribution warrant individual inspection.

## Step 2 — Anomaly queries (the audit-actionable findings)

### Phones with no description or auto-generated descriptions
```sql
SELECT FIRST 50 d.name, d.description, dp.name AS device_pool
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
LEFT OUTER JOIN devicepool dp ON d.fkdevicepool = dp.pkid
WHERE tc.name = 'Phone'{name_clause}
  AND (d.description IS NULL
       OR d.description = ''
       OR d.description = d.name
       OR d.description LIKE 'AN%' || SUBSTRING(d.name FROM 3) || '%')
ORDER BY d.name;
```

(Phones whose description matches or echoes their MAC address /
auto-generated name. Hospital deployments accumulate these as patient-
room or mobile carts that were quickly added without operator notes.)

### Phones with no associated owner
```sql
SELECT FIRST 50 d.name, d.description, dp.name AS device_pool
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
LEFT OUTER JOIN devicepool dp ON d.fkdevicepool = dp.pkid
WHERE tc.name = 'Phone'{name_clause}
  AND d.fkenduser IS NULL
ORDER BY d.name;
```

(Some unassigned phones are intentional — common areas, guest phones,
patient rooms. Operator should verify that the count matches expected
shared-use endpoints.)

### Phones in non-default CSS (where "default" means most-common)
After Step 1's CSS distribution query, identify the most common CSS,
then list phones NOT in it:

```sql
SELECT FIRST 50 d.name, d.description, css.name AS css_name
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
LEFT OUTER JOIN callingsearchspace css ON d.fkcallingsearchspace = css.pkid
WHERE tc.name = 'Phone'{name_clause}
  AND (css.name != '<MOST_COMMON_CSS>' OR css.name IS NULL)
ORDER BY css.name, d.name;
```

(Replace `<MOST_COMMON_CSS>` with the result from Step 1.)

### Phones with no primary CSS (NULL)
```sql
SELECT d.name, d.description, dp.name AS device_pool
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
LEFT OUTER JOIN devicepool dp ON d.fkdevicepool = dp.pkid
WHERE tc.name = 'Phone'{name_clause} AND d.fkcallingsearchspace IS NULL
ORDER BY d.name;
```

(NULL CSS means the phone inherits from device pool. Usually fine, but
worth confirming the count matches expectations — a sudden increase
indicates config drift.)

## Step 3 — Cross-reference with real-time registration (highest-leverage)

`device_registration_summary()` returns a cluster-wide breakdown by status
across all device classes. The audit-relevant question is: what fraction
of *configured* phones are *actually registered*?

```
device_registration_summary()
```

For drill-down on the unregistered population:

```
device_registration_status(device_class="Phone", status="UnRegistered")
```

This gives you the actual list of phones that have a config in CUCM but
are not currently registered. **A phone that's been "UnRegistered" for
weeks is the strongest orphan signal we can produce** — cleaner than
"no description" or "no owner" because registration state reflects
real-world usage, not just operator hygiene.

**Findings to surface from this cross-reference:**

- **Configured-but-never-registered phones**: the cluster has them
  configured, they've never come online. Often abandoned conference
  phones, decommissioned analog gateways, or templates that were
  cloned but never deployed. Strong candidates for deletion.
- **Registered but no description / no owner**: actively-used phones
  whose operator hygiene is weak. Hospitals accumulate these as
  "patient room 3142" or shared cordless phones; verify they're
  intentional shared-use endpoints rather than just untracked.
- **PartiallyRegistered**: a phone that's communicating with one CM
  node but not another. Indicates a real registration problem
  (firewall, version mismatch, certificate); flag for IT.
- **Status mismatch**: phone class says "Cisco 7841" but `model` field
  on the registered device says something different — could indicate a
  spoofing attempt or hardware swap without config update.

## Step 4 — Cross-reference with users (if owners exist)

For phones with an owner, list owner identities to spot stale
assignments (employee left, phone still tagged to them):

```sql
SELECT FIRST 50 d.name, d.description, eu.userid, eu.lastname, eu.status
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
JOIN enduser eu ON d.fkenduser = eu.pkid
WHERE tc.name = 'Phone'{name_clause}
ORDER BY d.name;
```

`enduser.status` of `0` = inactive; `1` = active. A phone owned by an
inactive user is a finding.

## Findings to call out

- **Naming hygiene gaps**: phones with auto-generated or empty descriptions.
  Recommend: operational follow-up to add room/owner/purpose notes.
- **CSS sprawl**: if more than ~3-5 CSSs are in regular use, justify each.
  Phones in single-purpose CSSs (e.g., `911CER-CSS` with only 9 devices)
  usually have specific reasons — document them.
- **Orphan owners**: phones owned by inactive users. Recommend reassignment
  or unassignment.
- **Model heterogeneity**: a wide spread of phone models indicates ongoing
  refresh or drift. Worth knowing for firmware/upgrade planning.
- **Devicepool concentration**: if 99%+ of phones are in one device pool,
  that's the pool that matters for any DP-related change. Flag it as a
  high-blast-radius asset.

## Suggested follow-up calls

- `route_devices_using_css(css_name=<each CSS from Step 1>)` to map the
  full impact of changing any phone-attached CSS.
- `axl_describe_table('device')` if the LLM needs additional columns
  (firmware load, MAC, security profile, etc.).
- `axl_sql("SELECT name FROM typemodel WHERE enum IN (...)")` to decode
  any unfamiliar model codes.

## Reference: CUCM data dictionary (devices)

{schema_block}

Run the queries above and produce a structured inventory report:
counts table, distribution tables, anomaly findings with severity, and
a recommendations section. Don't enumerate every phone — focus on
aggregates and exceptions.
"""
