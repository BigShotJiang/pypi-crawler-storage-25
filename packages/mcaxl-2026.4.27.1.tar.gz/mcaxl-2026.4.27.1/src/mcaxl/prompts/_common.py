"""Shared helpers and constants used by multiple prompts."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


# Keyword sets for pulling relevant doc chunks. Tuned per audit topic so
# prompt enrichment focuses on the right schema docs without burning tokens
# on irrelevant CLI-reference material.
ROUTE_KEYWORDS = [
    "route plan", "route pattern", "translation pattern",
    "calling search space", "partition", "transformation",
    "digit discard", "numplan", "routepartition",
]

AUDIT_KEYWORDS = {
    "full": ROUTE_KEYWORDS,
    "translations": [
        "translation pattern", "called party transformation",
        "calling party transformation", "digit discard",
    ],
    "css_partitions": [
        "calling search space", "partition", "css",
    ],
    "transformations": [
        "called party transformation", "calling party transformation",
        "transformation mask", "prefix digits",
    ],
    "route_lists": [
        "route list", "route group", "device pool", "local route group",
    ],
}

SIP_TRUNK_KEYWORDS = [
    "sip trunk", "sip device", "sipdevice", "siptrunkdestination",
    "sip profile", "trunk", "transport", "early offer",
]


def docs_or_empty_msg() -> str:
    """Fallback when the docs index isn't loaded — tells the LLM how to
    get equivalent info via the sibling cisco-docs MCP server."""
    return (
        "_The cisco-docs index is not loaded. Set CISCO_DOCS_INDEX_PATH or "
        "ensure `chunks.jsonl` + `index_meta.json` from the cisco-docs indexer. "
        "You can also use the sibling `cisco-docs` MCP server's `search_docs` "
        "tool for live semantic search._"
    )


def render_schema_block(
    docs: "DocsIndex | None",
    keywords: list[str],
    *,
    max_chunks: int = 5,
    max_chars_per_chunk: int = 1000,
) -> str:
    """Pull doc chunks for the given keywords and format them for embedding.

    Returns a `docs_or_empty_msg()` notice when docs is None.
    """
    if docs is None:
        return docs_or_empty_msg()
    chunks = docs.find(
        keywords,
        max_chunks=max_chunks,
        max_chars_per_chunk=max_chars_per_chunk,
    )
    return docs.format_chunks_for_prompt(chunks)
