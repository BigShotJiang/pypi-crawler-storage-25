"""Hunt pilot + line group + queue settings audit."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


_KEYWORDS = [
    "hunt pilot", "hunt list", "line group", "distribution algorithm",
    "queue", "rna", "ring no answer", "huntpilotqueue",
]


def render(docs: "DocsIndex | None") -> str:
    """Hunt pilot inventory and audit. Schema-aware (uses
    `huntpilotqueue.fknumplan_pilot`, NOT `fknumplan` — verified against
    CUCM 15 schema 2026-04-25)."""
    schema_block = render_schema_block(
        docs, _KEYWORDS, max_chunks=4, max_chars_per_chunk=900
    )

    return """# CUCM Hunt Pilot Audit

Hunt pilots distribute incoming calls across a group of phones (hunt
group) with configurable algorithms (top-down, longest-idle, broadcast,
etc.) and queue behavior. Misconfigured hunt pilots are a common source
of "calls disappear into the void" complaints.

## Schema (CUCM 15)

- `numplan` row with `tkpatternusage = 7` is a Hunt Pilot
- `huntpilotqueue` joins to numplan via `fknumplan_pilot` (NOT
  `fknumplan` — that's a common-mistake column name)
- `linegroup` defines the distribution algorithm and member-handling
- `linegroupnumplanmap` joins line groups to their member DNs
- A hunt pilot points to a "Route List" device (just like route
  patterns do) — that route list contains route groups containing
  line groups containing phones

## Step 1 — Hunt pilot inventory

```sql
SELECT
  np.dnorpattern AS hunt_pilot,
  rp.name AS partition,
  np.description,
  np.calledpartytransformationmask AS xform_called,
  np.callingpartytransformationmask AS xform_calling,
  np.pkid
FROM numplan np
JOIN routepartition rp ON np.fkroutepartition = rp.pkid
WHERE np.tkpatternusage = 7  -- Hunt Pilot
ORDER BY rp.name, np.dnorpattern;
```

Each hunt pilot is a "front door" pattern — what callers dial to reach
a group. The transformations columns matter: a hunt pilot may rewrite
the called party (e.g., normalize to a base-extension) before
distribution.

## Step 2 — Queue settings per hunt pilot

```sql
SELECT
  np.dnorpattern AS hunt_pilot,
  hpq.maxcallersinqueue,
  hpq.maxwaittimeinqueue,
  hpq.maxwaittimedestination AS overflow_dest,
  hpq.noagentdestination AS no_agent_dest,
  hpq.queuefulldestination AS queue_full_dest,
  css_max.name AS css_for_max_wait,
  css_no.name AS css_for_no_agent,
  css_full.name AS css_for_queue_full
FROM huntpilotqueue hpq
JOIN numplan np ON hpq.fknumplan_pilot = np.pkid
LEFT OUTER JOIN callingsearchspace css_max ON hpq.fkcallingsearchspace_maxwaittime = css_max.pkid
LEFT OUTER JOIN callingsearchspace css_no ON hpq.fkcallingsearchspace_noagent = css_no.pkid
LEFT OUTER JOIN callingsearchspace css_full ON hpq.fkcallingsearchspace_pilotqueuefull = css_full.pkid
ORDER BY np.dnorpattern;
```

Queue behavior is the most-misconfigured aspect of hunt pilots:
- `maxwaittimeinqueue = 0` means "no max" — callers can wait forever.
  Usually a misconfiguration; should be set to a sensible value
  (e.g., 30-300 seconds) with an overflow destination.
- `maxwaittimedestination` / `noagentdestination` /
  `queuefulldestination` define what happens when each condition
  triggers. NULL on any of these means "drop the call" — almost never
  the operator's intent.

## Step 3 — Line groups and their member DNs

```sql
SELECT
  lg.name AS line_group,
  ta.name AS distribution_algorithm,
  np.dnorpattern AS member_dn,
  rp.name AS member_partition,
  lgnpm.lineselectionorder AS sortorder
FROM linegroup lg
LEFT OUTER JOIN typedistributealgorithm ta ON lg.tkdistributealgorithm = ta.enum
LEFT OUTER JOIN linegroupnumplanmap lgnpm ON lgnpm.fklinegroup = lg.pkid
LEFT OUTER JOIN numplan np ON lgnpm.fknumplan = np.pkid
LEFT OUTER JOIN routepartition rp ON np.fkroutepartition = rp.pkid
ORDER BY lg.name, lgnpm.lineselectionorder;
```

Distribution algorithms (decoded via `typedistributealgorithm`):
- **Top Down** — first member always rings first; predictable but
  uneven load.
- **Circular** — round-robin starting after the last-rung member.
- **Longest Idle Time** — call goes to the member who hasn't rung in
  the longest time. Most common for fairness.
- **Broadcast** — every member rings simultaneously. Use sparingly;
  noisy.

## Step 4 — Hunt pilot → route list / line group destinations

The hunt pilot routes to a Route List that contains the actual line
group(s). Use the existing tool:

```
route_inspect_pattern(<hunt_pilot_dn>, <partition>)
```

This returns the destination chain. For each hunt pilot identified in
Step 1, run this to confirm:
- Destination is the expected route list / line group
- The line group's distribution algorithm matches operational intent
- Member DNs all exist and belong to active phones (cross-reference
  with `phone_inventory_report`)

## Step 5 — Hunt pilots with no line group destination (dead pilots)

```sql
-- Hunt pilots that don't appear in any line group routing
SELECT np.dnorpattern, rp.name AS partition, np.description
FROM numplan np
JOIN routepartition rp ON np.fkroutepartition = rp.pkid
WHERE np.tkpatternusage = 7
  AND NOT EXISTS (
    SELECT 1 FROM devicenumplanmap dnm
    JOIN device d ON dnm.fkdevice = d.pkid
    JOIN typeclass tc ON d.tkclass = tc.enum
    WHERE dnm.fknumplan = np.pkid AND tc.name = 'Route List'
  )
ORDER BY rp.name, np.dnorpattern;
```

A hunt pilot that doesn't route to a route list is functionally dead —
calls match the pilot pattern but have nowhere to go. Often vestigial
config.

## Findings to call out

### Queue misconfigurations
- **`maxwaittimeinqueue = 0`** without an explicit overflow rationale
  — callers can wait forever in queue.
- **NULL `maxwaittimedestination` / `noagentdestination` /
  `queuefulldestination`** — calls drop without going anywhere.
  Recommend explicit destinations (typically voicemail).
- **Mismatched CSSs** on the three queue destinations: the CSSs control
  whether the destination is reachable. If the CSS is overly restrictive,
  the overflow destination might not be reachable from the hunt pilot's
  context.

### Line group hygiene
- **Empty line groups** (no members in `linegroupnumplanmap`) — calls
  would never ring anywhere.
- **Line groups with one member** — fine, but check whether a hunt
  pilot is overkill (a direct DN may be simpler).
- **Members in an inactive partition** or pointing to a DN that's
  no longer assigned to any phone.

### Distribution algorithm clarity
- **Distribution = Broadcast** for a large group — operationally noisy;
  confirm with operator whether this is intentional.
- **Distribution = Top Down** with the same first member every time —
  load concentrates on one phone; operator may want longest-idle.

### Coverage gaps
- **Hunt pilots not pointing to a route list** (Step 5) — cleanup.
- **Hunt pilot description missing** — operationally opaque; recommend
  description annotations.

## Suggested follow-up calls

- `route_inspect_pattern(<pilot>, <partition>)` for each hunt pilot to
  trace its destination chain.
- `route_devices_using_css(<each unique queue-destination CSS>)` to
  understand the blast radius of the CSSs the queue uses.
- `axl_describe_table('huntpilotqueue')` if the audit needs additional
  queue-config columns (announcement, MoH source, etc.).

## Reference: CUCM data dictionary (hunt pilots, line groups)

""" + schema_block + """

Run the queries above and produce a structured findings report. Group
by hunt pilot; under each, list its queue config, line group(s), and
distribution algorithm; then list the audit findings with severity.
"""
