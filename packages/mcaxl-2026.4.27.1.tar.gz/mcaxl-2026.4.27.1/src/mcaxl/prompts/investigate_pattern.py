"""Deep-dive seed for one specific pattern. Schema chunks embedded."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


_KEYWORDS = ["numplan", "transformation", "translation pattern", "route pattern"]


def render(
    docs: "DocsIndex | None",
    pattern: str,
    partition: str | None = None,
) -> str:
    """Walk the user through a single pattern in detail."""
    schema_block = render_schema_block(
        docs, _KEYWORDS, max_chunks=4, max_chars_per_chunk=900
    )
    partition_clause = f" in partition `{partition}`" if partition else ""
    inspect_args = f"pattern={pattern!r}"
    if partition:
        inspect_args += f", partition={partition!r}"

    return f"""# Investigate Pattern: `{pattern}`{partition_clause}

Walk the user through this pattern in detail.

## Suggested calls

1. `route_inspect_pattern({inspect_args})`
   — pattern detail, transformations, target route list/device, reverse CSS lookup
2. `route_translation_chain(number=<sample number>)` — what other patterns
   would compete for matches if this pattern matched a real call
3. If it's a route pattern with a route list target, follow with
   `route_lists_and_groups(name=<route list name>)`

## What to report

- **Type**: directory number / route / translation / hunt pilot / etc.
- **Transformations applied**:
  - Called party transformation mask
  - Calling party transformation mask
  - Prefix digits
  - Digit discard instructions
- **Routing target**: where does the call ultimately go?
- **Who can reach it**: which CSSs include this pattern's partition? Which
  device-pool/phone classes use those CSSs?
- **Anything anomalous**: missing description, undocumented transformations,
  patterns that shadow each other, etc.

## Reference: CUCM data dictionary

{schema_block}
"""
