"""Snapshot of the cluster's routing setup, with schema reference embedded."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import ROUTE_KEYWORDS, render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


def render(docs: "DocsIndex | None") -> str:
    """Use this when starting a fresh route-plan audit conversation."""
    schema_block = render_schema_block(docs, ROUTE_KEYWORDS, max_chunks=5)

    return f"""# CUCM Route Plan Overview

You are auditing the routing configuration of a CUCM 15 cluster via the
`mcaxl` MCP server (read-only). Begin by gathering a high-level
snapshot, then drill in where anything looks wrong or surprising.

## Suggested first calls (in order)

1. `axl_version()` — confirm cluster reachability + version
2. `route_partitions()` — partition catalog with member counts
3. `route_calling_search_spaces()` — CSS list with ordered partitions
4. `route_patterns(kind="route")` — outbound route patterns
5. `route_patterns(kind="translation")` — translation patterns
6. `route_lists_and_groups()` — route list → route group → device chain
7. `route_digit_discard_instructions()` — DDI catalog

## What to look for in your initial summary

- **Partition sprawl**: > ~30 partitions usually indicates accumulated
  legacy config. Note any with zero patterns or zero CSS membership.
- **CSS-partition asymmetry**: partitions not reachable from any CSS are
  effectively dead.
- **Pattern density**: which partitions hold the bulk of route/translation
  patterns? That's where the dial plan logic lives.
- **Transformation patterns**: cgpn/cdpn masks and DDIs that look unusual
  or undocumented.
- **Route list depth**: route lists with one route group are fine; with many,
  understand the failover order.

## Reference: CUCM data dictionary (route plan)

{schema_block}

Now run the calls above and produce a written audit summary.
"""
