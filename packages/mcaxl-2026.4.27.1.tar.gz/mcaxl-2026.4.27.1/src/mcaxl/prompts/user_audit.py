"""End user + application user audit: roles, group memberships, security."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


_KEYWORDS = [
    "end user", "application user", "directory group", "function role",
    "role", "permission", "authentication", "ldap",
]

# Focus → rationale + which audit checklist sections to emphasize
_FOCUSES = {
    "full",
    "admin",       # users with admin/serviceability roles
    "inactive",    # users with status != active
    "app_users",   # service accounts
}


def render(docs: "DocsIndex | None", focus: str = "full") -> str:
    """User audit: end users + application users, role assignments,
    security-relevant findings.

    Args:
        focus: One of "full", "admin", "inactive", "app_users". Tunes
            which checklist sections the report emphasizes; all queries
            still run for context.
    """
    if focus not in _FOCUSES:
        focus = "full"
    schema_block = render_schema_block(
        docs, _KEYWORDS, max_chunks=4, max_chars_per_chunk=900
    )

    return f"""# CUCM User Audit — focus: `{focus}`

End users (`enduser`), application users (`applicationuser`), and their
role assignments via the dirgroup/functionrole join chain. Security and
operational hygiene findings.

## Step 1 — Headcounts

End users grouped by status:
```sql
SELECT status, COUNT(*) AS user_count FROM enduser GROUP BY status;
```

Application users (no status column — they're configuration objects, not
human accounts):
```sql
SELECT COUNT(*) AS app_user_count FROM applicationuser;
```

`enduser.status`: `1` = active, `0` = inactive.

(Informix's `UNION ALL` rejects mixed-type columns even with `CAST`,
so two separate queries is the simplest portable form.)

## Step 2 — End user inventory

```sql
SELECT FIRST 100
  eu.userid,
  eu.firstname,
  eu.lastname,
  eu.displayname,
  eu.status,
  eu.userrank,
  eu.islocaluser
FROM enduser eu
ORDER BY eu.lastname, eu.firstname;
```

`islocaluser` = `t` means CCM-local, `f` means LDAP-synced. Mixing both is
common (admins local, hospital staff LDAP-synced).
`userrank` is a 1-5 integer that gates access to features by rank;
elevated ranks (4-5) usually correspond to admin populations.

## Step 3 — Application users (service accounts)

```sql
SELECT au.name, au.userrank, au.isstandard
FROM applicationuser au
ORDER BY au.userrank DESC, au.name;
```

`isstandard = 't'` is a built-in account (Cisco-shipped); `f` is operator-
created. Operator-created application users with high userrank are the
audit-critical population (these are typically API-access service accounts).

## Step 4 — Role assignments

End users / app users → dirgroups → function roles:

```sql
-- End users with their group memberships
SELECT FIRST 200
  eu.userid,
  eu.lastname,
  dg.name AS dirgroup_name
FROM enduser eu
JOIN enduserdirgroupmap eudgm ON eudgm.fkenduser = eu.pkid
JOIN dirgroup dg ON eudgm.fkdirgroup = dg.pkid
WHERE dg.isstandard = 'f' OR dg.name LIKE '%Standard CCM%Admin%' OR dg.name LIKE '%Super%'
ORDER BY eu.userid, dg.name;
```

```sql
-- App users with their group memberships (always audit-relevant)
SELECT au.name AS app_user, dg.name AS dirgroup_name
FROM applicationuser au
JOIN applicationuserdirgroupmap audgm ON audgm.fkapplicationuser = au.pkid
JOIN dirgroup dg ON audgm.fkdirgroup = dg.pkid
ORDER BY au.name, dg.name;
```

```sql
-- Dirgroups → function roles (the actual permissions)
SELECT dg.name AS group_name, fr.name AS role_name, fr.description
FROM dirgroup dg
JOIN functionroledirgroupmap frdgm ON frdgm.fkdirgroup = dg.pkid
JOIN functionrole fr ON frdgm.fkfunctionrole = fr.pkid
WHERE dg.isstandard = 'f' OR dg.name LIKE '%Admin%' OR dg.name LIKE '%Super%'
ORDER BY dg.name, fr.name;
```

The audit question is: who has admin-grade role membership, and is each
assignment justified?

## Step 5 — Phone owners (cross-reference)

Phones tagged to inactive users:

```sql
SELECT FIRST 50
  d.name AS phone_name,
  d.description,
  eu.userid AS owner_userid,
  eu.lastname,
  eu.status AS owner_status
FROM device d
JOIN typeclass tc ON d.tkclass = tc.enum
JOIN enduser eu ON d.fkenduser = eu.pkid
WHERE tc.name = 'Phone' AND eu.status = '0'
ORDER BY eu.lastname, d.name;
```

A phone owned by an inactive user (departed employee, expired account)
is config drift — either reassign or unassign.

## Findings to call out

### Security-critical
- **Application users with admin/superuser group membership**: each one
  is an API key with elevated privileges. Document why each exists.
- **End users with `Standard CCM Super Users` or similar privileged
  group memberships**: these are the people who can write-modify the
  cluster. Confirm the population matches the documented admin team.
- **`islocaluser = 't'` accounts with admin privileges**: bypass LDAP/SSO,
  may have static passwords. High-priority security review.
- **Application users with default Cisco-shipped passwords**: these don't
  show in the schema (no plaintext access), but the existence of standard
  app users (e.g., `CCMAdministrator`, `CCMSysUser`) with operator-set
  passwords is worth a separate check via the GUI or a pen test.

### Operational hygiene
- **Inactive users (status = 0) still in groups**: cleanup candidates.
- **Phones owned by inactive users**: reassign or unassign.
- **Users with no group membership**: likely just have basic phone
  access; not a finding by itself but worth confirming if a sudden
  population appears.

### Drift indicators
- **End users created locally vs LDAP-synced ratio**: if local-user count
  has grown over time, indicates either an LDAP sync failure or
  out-of-band account creation.
- **Operator-created dirgroups (`isstandard = 'f'`)**: list and verify each
  has a documented purpose.

## Suggested follow-up calls

- For each app user with API/admin access, run
  `axl_sql("SELECT * FROM applicationuser WHERE name = '<name>'")` to
  inspect ACL flags (`acl*` columns).
- `axl_describe_table('enduser')` for additional fields (manager,
  department, etc. if LDAP populates them).
- `axl_sql("SELECT name, description FROM dirgroup ORDER BY isstandard, name")`
  to see all groups including standard Cisco-shipped ones.

## Reference: CUCM data dictionary (users + roles)

{schema_block}

Run the queries above and produce a structured findings report. The
focus parameter (`{focus}`) means: emphasize the corresponding section
in the writeup, but include all sections for context.
"""
