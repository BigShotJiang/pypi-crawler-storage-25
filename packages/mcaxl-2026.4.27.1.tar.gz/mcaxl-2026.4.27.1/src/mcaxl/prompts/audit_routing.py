"""Comprehensive routing audit walkthrough."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import AUDIT_KEYWORDS, ROUTE_KEYWORDS, render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


def render(docs: "DocsIndex | None", focus: str = "full") -> str:
    """Conduct a focused audit of the cluster's routing configuration.

    Args:
        focus: One of "full", "translations", "css_partitions",
            "transformations", "route_lists". Tunes which schema chunks
            get embedded.
    """
    keyword_set = AUDIT_KEYWORDS.get(focus, ROUTE_KEYWORDS)
    schema_block = render_schema_block(
        docs, keyword_set, max_chunks=6, max_chars_per_chunk=900
    )

    return f"""# CUCM Routing Audit — focus: `{focus}`

Conduct a focused audit of the cluster's routing configuration. Goal: produce
an actionable findings report — not just a description of the config.

## Audit checklist

### Partitions and access control
- [ ] Are there partitions with zero patterns? (legacy/orphaned)
- [ ] Are there partitions not referenced by any CSS? (unreachable)
- [ ] Does the partition naming convention reflect actual scope?

### Calling Search Spaces
- [ ] CSS-to-CSS comparison: any near-duplicates that differ only in order?
- [ ] CSSs that include partitions in surprising orders (longest-match implications)
- [ ] CSSs that are referenced by zero devices (use axl_sql against device table)

### Translation patterns
- [ ] What does each translation pattern actually transform? Any with no
  transformation that exist purely for partition routing?
- [ ] Calling-party transformations applied at translation: are they
  documented? Why is the calling number being rewritten?
- [ ] Translation chains: do any translations route into partitions where
  another translation will match again? (chains can be intentional but
  obscure caller-ID and routing logic)

### Route patterns
- [ ] Wildcard breadth: any `9.@` (NANPA at-sign) patterns? Are they intentional?
- [ ] Block patterns: which patterns have `block_enabled` set? What are they
  blocking and why?
- [ ] Patterns with no description — flag for documentation.

### Transformations (called party / calling party)
- [ ] Digit discard instructions: which DDIs are referenced? Are any DDIs
  defined but never used?
- [ ] Prefix-digits-out: any unusual prefixes (international, special service)?
- [ ] Calling-party masks that hide internal extensions on outbound calls.

### Route lists and groups
- [ ] Route lists with only one route group: simple, fine.
- [ ] Route lists with many: walk the failover order, confirm it's intentional.
- [ ] Route groups containing devices that are unregistered or disabled.

## Reference: CUCM data dictionary

{schema_block}

Run the relevant tool calls now and produce a structured findings report
with category headers, observation, severity (info/warning/error), and
recommended action where applicable.
"""
