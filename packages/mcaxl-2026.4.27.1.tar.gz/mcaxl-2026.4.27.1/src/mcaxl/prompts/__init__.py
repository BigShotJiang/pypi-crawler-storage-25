"""Schema-grounded conversation seeds for `mcaxl`.

Each module here defines a `render(docs, *args, **kwargs) -> str` function
that produces the prompt body. The `@mcp.prompt` registration shims live
in `server.py` — they're thin wrappers that pull the module-global `_docs`
and delegate. Keeping the rendering pure (no module globals, no FastMCP
imports here) makes prompts unit-testable in isolation and keeps each
prompt's content in its own file.

To add a new prompt:
1. Create `src/mcaxl/prompts/<name>.py` exporting a `render()`.
2. Re-export it below.
3. Add a thin `@mcp.prompt`-decorated shim in `server.py` that calls it.

Adding the shim is required because FastMCP introspects the *decorated*
function's signature to expose parameters to the LLM — the registration
shim is where the parameter contract lives.
"""

from . import (
    audit_routing,
    cucm_sql_help,
    hunt_pilot_audit,
    inbound_did_audit,
    investigate_pattern,
    phone_inventory_report,
    route_plan_overview,
    sip_trunk_report,
    user_audit,
    whoami,
)

__all__ = [
    "audit_routing",
    "cucm_sql_help",
    "hunt_pilot_audit",
    "inbound_did_audit",
    "investigate_pattern",
    "phone_inventory_report",
    "route_plan_overview",
    "sip_trunk_report",
    "user_audit",
    "whoami",
]
