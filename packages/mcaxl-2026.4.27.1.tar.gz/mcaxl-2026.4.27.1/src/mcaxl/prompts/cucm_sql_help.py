"""Catch-all prompt for arbitrary CUCM SQL questions. Includes schema chunks."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._common import render_schema_block

if TYPE_CHECKING:
    from ..docs_loader import DocsIndex


def render(docs: "DocsIndex | None", question: str) -> str:
    """Generate a SQL-help prompt seeded with chunks relevant to the question."""
    keywords = [w for w in question.lower().split() if len(w) > 3][:8]
    if keywords:
        schema_block = render_schema_block(
            docs, keywords, max_chunks=5, max_chars_per_chunk=900
        )
    else:
        # Question has no substantive keywords — fall back to a generic
        # data-dictionary primer rather than trying to embed nothing.
        schema_block = render_schema_block(
            docs,
            ["data dictionary", "informix", "schema"],
            max_chunks=3,
            max_chars_per_chunk=900,
        )

    return f"""# CUCM SQL Question

The user asks: **{question}**

## How to approach this

1. If you don't recognize the relevant tables, call `axl_list_tables(pattern=...)`
   with a substring guess (e.g., "route%", "device%", "user%").
2. Run `axl_describe_table(<table_name>)` for the candidate tables to see
   exact column names and types.
3. If the schema chunks below already answer the question, draft the SQL
   directly. If not, also invoke the `cisco-docs` MCP server's `search_docs`
   tool with a relevant query (e.g., search_docs("data dictionary table for X")).
4. Compose the SELECT, run it via `axl_sql(query=...)`.
5. Summarize the result for the user — counts, anomalies, and what you'd
   recommend doing about them.

## Possibly relevant schema chunks

{schema_block}

Now answer the question.
"""
