"""Resolve the AXLAPI WSDL for CUCM 15.

Resolution chain:
  1. AXL_WSDL_PATH env var (explicit override) — use it
  2. ~/.cache/mcaxl/wsdl/15.0/AXLAPI.wsdl — use cached copy
  3. Auto-extract `schema/15.0/` from a Cisco AXL Toolkit zip:
       - $AXL_WSDL_ZIP if set
       - ./axlsqltoolkit.zip in the current working directory
  4. Raise with a clear pointer to the AXL toolkit download in the CUCM admin UI

The full AXL toolkit ships as three files:
  AXLAPI.wsdl, AXLEnums.xsd, AXLSoap.xsd
all in the same directory. Zeep follows the schema imports from the WSDL.
"""

from __future__ import annotations

import os
import sys
import zipfile
from pathlib import Path

from platformdirs import user_cache_dir


WSDL_FILES = ("AXLAPI.wsdl", "AXLEnums.xsd", "AXLSoap.xsd")
WSDL_VERSION = "15.0"


def cache_wsdl_dir(version: str = WSDL_VERSION) -> Path:
    """Return ~/.cache/mcaxl/wsdl/<version>/."""
    return Path(user_cache_dir("mcaxl")) / "wsdl" / version


def _has_complete_wsdl(directory: Path) -> bool:
    return all((directory / fname).exists() for fname in WSDL_FILES)


def _try_extract_from_zip(version: str = WSDL_VERSION) -> Path | None:
    """Look for a Cisco AXL Toolkit zip and extract `schema/<version>/` from it.

    Search order:
      1. $AXL_WSDL_ZIP env var
      2. ./axlsqltoolkit.zip in current working directory

    Returns the cache directory path if successful, None if no zip found
    or extraction failed.
    """
    candidates: list[Path] = []
    if env_zip := os.environ.get("AXL_WSDL_ZIP"):
        candidates.append(Path(env_zip).expanduser())
    candidates.append(Path.cwd() / "axlsqltoolkit.zip")

    zip_path = next((p for p in candidates if p.exists() and p.is_file()), None)
    if zip_path is None:
        return None

    target = cache_wsdl_dir(version)
    target.mkdir(parents=True, exist_ok=True)

    print(
        f"[mcaxl] extracting AXL schema {version} from {zip_path}",
        file=sys.stderr,
        flush=True,
    )

    try:
        with zipfile.ZipFile(zip_path) as zf:
            extracted = []
            for fname in WSDL_FILES:
                member = f"schema/{version}/{fname}"
                if member not in zf.namelist():
                    print(
                        f"[mcaxl] zip missing member: {member}",
                        file=sys.stderr,
                        flush=True,
                    )
                    return None
                data = zf.read(member)
                (target / fname).write_bytes(data)
                extracted.append(fname)
        print(
            f"[mcaxl] extracted {len(extracted)} files into {target}",
            file=sys.stderr,
            flush=True,
        )
        return target
    except (zipfile.BadZipFile, OSError) as e:
        print(f"[mcaxl] zip extraction failed: {e}", file=sys.stderr, flush=True)
        return None


def resolve_wsdl_path() -> Path:
    """Return the path to AXLAPI.wsdl, or raise SystemExit with setup help."""
    explicit = os.environ.get("AXL_WSDL_PATH")
    if explicit:
        p = Path(explicit).expanduser().resolve()
        if not p.exists():
            raise SystemExit(f"AXL_WSDL_PATH points to nonexistent file: {p}")
        if p.is_dir():
            p = p / "AXLAPI.wsdl"
            if not p.exists():
                raise SystemExit(
                    f"AXL_WSDL_PATH is a directory but AXLAPI.wsdl is not inside it: {p.parent}"
                )
        if not _has_complete_wsdl(p.parent):
            missing = [f for f in WSDL_FILES if not (p.parent / f).exists()]
            print(
                f"[mcaxl] warning: WSDL dir missing {missing} alongside {p.name}; "
                f"zeep may fail to resolve schema imports.",
                file=sys.stderr,
                flush=True,
            )
        return p

    cache_dir = cache_wsdl_dir()
    if _has_complete_wsdl(cache_dir):
        return cache_dir / "AXLAPI.wsdl"

    # Auto-extract from a Cisco AXL Toolkit zip if present
    extracted = _try_extract_from_zip()
    if extracted and _has_complete_wsdl(extracted):
        return extracted / "AXLAPI.wsdl"

    _bootstrap_help(cache_dir)
    raise SystemExit(2)  # never reached; _bootstrap_help raises


def _bootstrap_help(cache_dir: Path) -> None:
    """Print setup instructions and exit. Never returns."""
    msg = [
        "",
        "AXL WSDL not found. To bootstrap, do one of:",
        "",
        "  Option A — drop axlsqltoolkit.zip into the project directory:",
        f"    cp /path/to/axlsqltoolkit.zip {Path.cwd()}/",
        "    # Auto-extracts schema/15.0/ on next launch",
        "",
        "  Option B — point at a zip elsewhere:",
        "    export AXL_WSDL_ZIP=/path/to/axlsqltoolkit.zip",
        "",
        "  Option C — explicit WSDL file path:",
        "    export AXL_WSDL_PATH=/path/to/schema/15.0/AXLAPI.wsdl",
        "",
        "  Option D — drop the three schema files into the cache:",
        f"    mkdir -p {cache_dir}",
        "    # Copy AXLAPI.wsdl, AXLEnums.xsd, AXLSoap.xsd into that directory",
        "",
        "To obtain the AXL toolkit:",
        "  1. Sign in to CUCM admin",
        "  2. Application > Plugins > Find > download 'Cisco AXL Toolkit'",
        "  3. Use the resulting axlsqltoolkit.zip with any option above",
        "",
    ]
    raise SystemExit("\n".join(msg))
