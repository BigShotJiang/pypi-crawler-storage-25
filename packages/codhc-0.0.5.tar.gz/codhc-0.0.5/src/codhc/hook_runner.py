from __future__ import annotations

import json
import shlex
import subprocess
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class HookResult:
    payload: dict[str, Any]
    stderr: str


def run_hook_command(*, command: list[str], stdin_text: str) -> HookResult:
    stop_hook_active = _parse_stop_hook_active(stdin_text)
    command_display = f"`{shlex.join(command)}`"
    completed = _run_subprocess(command)

    if completed.returncode == 0:
        return HookResult(
            payload={
                "continue": False,
            },
            stderr="",
        )

    if stop_hook_active:
        return HookResult(
            payload={
                "continue": False,
                "systemMessage": f"{command_display} failed after the Stop continuation pass.",
            },
            stderr=completed.output,
        )

    return HookResult(
        payload={
            "decision": "block",
            "reason": f"{command_display} failed. Inspect the command output, fix the issues, then stop again.",
        },
        stderr=completed.output,
    )


@dataclass(frozen=True)
class CommandResult:
    returncode: int
    output: str


def _parse_stop_hook_active(stdin_text: str) -> bool:
    if not stdin_text.strip():
        return False

    try:
        payload = json.loads(stdin_text)
    except json.JSONDecodeError:
        return False

    if not isinstance(payload, dict):
        return False

    return payload.get("stop_hook_active") is True


def _run_subprocess(command: list[str]) -> CommandResult:
    try:
        completed = subprocess.run(
            command,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            encoding="utf-8",
            errors="replace",
            text=True,
        )
    except FileNotFoundError as exc:
        missing = exc.filename or command[0]
        return CommandResult(returncode=127, output=f"{missing}: command not found\n")
    except OSError as exc:
        failed_command = exc.filename or command[0]
        error_message = exc.strerror or str(exc)
        return CommandResult(returncode=126, output=f"{failed_command}: {error_message}\n")

    return CommandResult(returncode=completed.returncode, output=completed.stdout)
