import json
import sys
from typing import TextIO

from codhc.hook_runner import run_hook_command


def run_cli(*, argv: list[str], stdin_text: str) -> tuple[int, str, str]:
    if not argv:
        return (2, "", "Usage: codhc <command> [args...]\n")

    result = run_hook_command(command=argv, stdin_text=stdin_text)
    return (0, f"{json.dumps(result.payload)}\n", result.stderr)


def read_stdin_text(stdin: TextIO) -> str:
    if stdin.isatty():
        return ""
    return stdin.read()


def main() -> None:
    exit_code, stdout_text, stderr_text = run_cli(argv=sys.argv[1:], stdin_text=read_stdin_text(sys.stdin))
    if stderr_text:
        sys.stderr.write(stderr_text)
    if stdout_text:
        sys.stdout.write(stdout_text)
    raise SystemExit(exit_code)
