# logging/tasks.py

import logging
import socket
from datetime import datetime

from django.conf import settings
from django.utils import timezone
from opensearchpy import OpenSearch

logger = logging.getLogger(__name__)

_client = None
_checked_indices = set()


def get_opensearch_config():
    required_settings = {
        "host": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_HOST", None),
        "port": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_PORT", None),
        "username": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_USERNAME", None),
        "password": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_PASSWORD", None),
        "index_name": getattr(settings, "PYKOLOFINANCE_OPENSEARCH_INDEX_NAME", None),
    }

    missing = [key for key, value in required_settings.items() if not value]

    if missing:
        logger.warning(
            "OpenSearch logging disabled. Missing settings: %s",
            ", ".join(missing),
        )
        return None

    return required_settings


def get_opensearch_index_name():
    base_index_name = getattr(
        settings,
        "PYKOLOFINANCE_OPENSEARCH_INDEX_NAME",
        None,
    )

    if not base_index_name:
        return None

    today = timezone.now().strftime("%Y.%m.%d")
    return f"{base_index_name}-{today}"


def get_opensearch_client():
    global _client

    if _client is not None:
        return _client

    config = get_opensearch_config()
    if not config:
        return None

    try:
        _client = OpenSearch(
            hosts=[
                {
                    "host": config["host"],
                    "port": config["port"],
                }
            ],
            http_auth=(
                config["username"],
                config["password"],
            ),
            use_ssl=True,
            verify_certs=False,
            ssl_show_warn=False,
            http_compress=True,
            timeout=3,
            max_retries=1,
            retry_on_timeout=False,
            pool_maxsize=20,
        )
        return _client

    except Exception:
        logger.exception("OpenSearch logging disabled. Failed to initialize client.")
        _client = None
        return None


def get_index_mapping():
    return {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0,
        },
        "mappings": {
            "dynamic": True,
            "date_detection": False,
            "numeric_detection": False,
            "dynamic_templates": [
                {
                    "body_strings_as_keyword": {
                        "path_match": "body.*",
                        "match_mapping_type": "string",
                        "mapping": {
                            "type": "keyword",
                            "ignore_above": 4096,
                        },
                    }
                },
                {
                    "body_longs_as_keyword": {
                        "path_match": "body.*",
                        "match_mapping_type": "long",
                        "mapping": {
                            "type": "keyword",
                        },
                    }
                },
                {
                    "body_doubles_as_keyword": {
                        "path_match": "body.*",
                        "match_mapping_type": "double",
                        "mapping": {
                            "type": "keyword",
                        },
                    }
                },
                {
                    "body_booleans_as_keyword": {
                        "path_match": "body.*",
                        "match_mapping_type": "boolean",
                        "mapping": {
                            "type": "keyword",
                        },
                    }
                },
            ],
            "properties": {
                "@timestamp": {"type": "date"},
                "level": {"type": "keyword"},
                "app_name": {"type": "keyword"},
                "environment": {"type": "keyword"},
                "method": {"type": "keyword"},
                "status_code": {"type": "integer"},
                "execution_time": {"type": "float"},
                "client_ip_address": {"type": "keyword"},
                "added_on": {"type": "keyword"},

                "email": {"type": "keyword", "null_value": "NULL"},
                "user_id": {"type": "keyword", "null_value": "NULL"},
                "fullname": {"type": "text"},
                "action_description": {"type": "text"},
                "action_function_call": {
                    "type": "keyword",
                    "null_value": "NULL",
                },

                "api": {
                    "type": "keyword",
                    "ignore_above": 4096,
                },

                "headers": {
                    "type": "object",
                    "enabled": False,
                },

                "body": {
                    "type": "object",
                    "dynamic": True,
                },

                "response": {
                    "type": "object",
                    "enabled": False,
                },

                "extra": {
                    "type": "object",
                    "enabled": False,
                },

                "error": {"type": "text"},
                "traceback": {"type": "text"},
                "hostname": {"type": "keyword"},
            },
        },
    }


def ensure_index_exists():
    client = get_opensearch_client()
    if client is None:
        return False

    index_name = get_opensearch_index_name()
    if not index_name:
        logger.warning("OpenSearch logging disabled. Missing index name.")
        return False

    if index_name in _checked_indices:
        return True

    try:
        if not client.indices.exists(index=index_name):
            client.indices.create(
                index=index_name,
                body=get_index_mapping(),
            )

        _checked_indices.add(index_name)
        return True

    except Exception:
        logger.exception("Failed to ensure OpenSearch index exists.")
        return False


def log_to_opensearch(log_data):
    client = get_opensearch_client()
    if client is None:
        return None

    index_name = get_opensearch_index_name()
    if not index_name:
        logger.warning("OpenSearch logging disabled. Missing index name.")
        return "missing index name"

    if not ensure_index_exists():
        return "index does not exist"

    try:
        log_data["@timestamp"] = datetime.utcnow().isoformat()
        log_data["hostname"] = socket.gethostname()

        response = client.index(
            index=index_name,
            body=log_data,
        )

        return response.get("_id")

    except Exception as e:
        logger.exception("Failed to send log to OpenSearch.")
        return str(e)