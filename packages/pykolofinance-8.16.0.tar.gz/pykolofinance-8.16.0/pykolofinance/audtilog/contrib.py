import re

import jwt
from django.conf import settings

DEFAULT_SENSITIVE_KEYS = [
    # Auth / Tokens
    'authorization',
    'token',
    'access',
    'refresh',
    'access_token',
    'refresh_token',
    'id_token',
    'jwt',
    'bearer',
    'secret',
    'secret_key',
    'api_key',
    'x-api-key',
    'x_api_key',
    'x-kms-key',
    'signature',
    'client_secret',
    'private_key',

    # Passwords / Pins
    'password',
    'old_password',
    'new_password',
    'confirm_password',
    'passcode',
    'pin',
    'tx_pin',
    'new_pin',
    'current_pin',
    'otp',
    'verification_code',
    'reset_code',

    # Identity / KYC
    'bvn',
    'nin',
    'dob',
    'date_of_birth',
    'mother_maiden_name',
    'passport_number',
    'drivers_license',
    'national_id',
    'tax_id',

    # Card / Payment Data
    'card_number',
    'full_card_number',
    'pan',
    'masked_pan',
    'cvv',
    'expiry',
    'expiry_date',
    'track1',
    'track2',
    'track_data',
    'emv',
    'icc_data',
    'crd_no',


    # Biometrics / Files
    'image',
    'photo',
    'face',
    'fingerprint',
    'selfie',
    'signature_image',
    'document',
    'file',

    # Session / Device

    'device_id',
    'device_token',
    'firebase_token',
    'fcm_token',

    # Django / CSRF
    'csrfmiddlewaretoken',
    'csrf_token',
    'x_csrf_token',
    'x_csrftoken',
    'csrftoken',

    # Cookies
    'cookie',
    'set-cookie',

    # Personal Info

    'address',

    # Misc
    'requestblob',
    'metadata',
    'key',
    'last_4_digits',
]


def normalize_key(key):
    return (
        str(key)
        .lower()
        .strip()
        .replace("_", "-")
    )


def get_sensitive_keys():
    sensitive_keys = {
        normalize_key(key)
        for key in DEFAULT_SENSITIVE_KEYS
    }

    setting_names = [
        "API_LOGGER_EXCLUDE_KEYS",
        "DRF_API_LOGGER_EXCLUDE_KEYS",
    ]

    for setting_name in setting_names:
        keys = getattr(settings, setting_name, None)

        if isinstance(keys, (list, tuple, set)):
            sensitive_keys.update(
                normalize_key(key)
                for key in keys
                if key
            )

    return sensitive_keys


SENSITIVE_KEYS = get_sensitive_keys()


def get_headers(request=None):
    """
    Get request headers.
    """

    regex = re.compile(r"^HTTP_")
    headers = {}

    for header, value in request.META.items():

        if not header.startswith("HTTP_"):
            continue

        key = regex.sub("", header)
        key = key.replace("_", "-")

        headers[key] = value

    return headers


def get_client_ip(request):
    try:
        x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")

        if x_forwarded_for:
            return x_forwarded_for.split(",")[0].strip()

        return request.META.get("REMOTE_ADDR", "")

    except Exception:
        return ""


def mask_sensitive_data(data, mask_api_parameters=True):
    mask_value = "***FILTERED***"

    if data in (None, "", {}, []):
        return data

    if isinstance(data, dict):

        masked_data = {}

        for key, value in data.items():

            normalized_key = normalize_key(key)

            if any(
                sensitive in normalized_key
                for sensitive in SENSITIVE_KEYS
            ):
                masked_data[key] = mask_value
            else:
                masked_data[key] = mask_sensitive_data(
                    value,
                    mask_api_parameters,
                )

        return masked_data

    if isinstance(data, list):
        return [
            mask_sensitive_data(item, mask_api_parameters)
            for item in data
        ]

    return data


def decode_jwt_token(request):
    try:
        auth_header = request.META.get("HTTP_AUTHORIZATION")

        if not auth_header:
            return None, None, None

        token = auth_header.split(" ")[1]

        decoded = jwt.decode(
            token,
            options={"verify_signature": False},
            algorithms=["HS256"],
        )

        email = decoded.get("email")
        user_id = decoded.get("user_id") or decoded.get("id")
        fullname = decoded.get("fullname") or decoded.get("name")

        return email, user_id, fullname

    except Exception:
        return None, None, None