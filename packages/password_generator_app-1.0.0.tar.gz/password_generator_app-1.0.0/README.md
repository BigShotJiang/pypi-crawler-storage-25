# Password Generator App

A clean and lightweight password generator built with **PySide6** and Python.  
The project provides both a graphical user interface and a command-line interface.

## Features

- Simple Material-style GUI
- Dark and light themes
- Accent color selection
- Password generation with configurable character groups
- Clipboard copy
- Persistent local settings stored beside the project
- CLI support for terminal-based use
- Small, readable UI with responsive spacing

## Screenshots

### CLI

![CLI screenshot](imgs/CLI.png)

### GUI

![GUI screenshot](imgs/GUI.png)

## Installation

### From source

```powershell
pip install -r requirements.txt
pip install -e .
```

### From PyPI

```powershell
pip install password-generator-app
```

## Run the application

The main command is `passgen`.  
The alias `password-generator` is also available after installation.

### From a local source checkout without installation

```powershell
$env:PYTHONPATH = "src"
python -m password_generator_app.cli gui
python -m password_generator_app.cli --length 32 --copy
```

### After installation

```powershell
passgen gui
passgen --length 32 --copy
password-generator gui
password-generator --length 32 --copy
```

### Direct module execution

```powershell
python -m password_generator_app.cli gui
python -m password_generator_app.cli --length 32 --copy
```

## GUI usage

Launch the graphical interface:

```powershell
passgen gui
```

Or:

```powershell
password-generator gui
```

The GUI allows you to:

- Generate secure passwords visually
- Configure character groups
- Set minimum character counts
- Switch between dark and light themes
- Customize accent colors
- Copy passwords directly to the clipboard

## CLI usage

Generate a password with default settings:

```powershell
passgen
```

Generate a password with a custom length and copy it to the clipboard:

```powershell
passgen --length 32 --copy
```

Show help:

```powershell
passgen -h
```

The same CLI commands can also be executed with:

```powershell
password-generator
```

## CLI options

- `--length`, `-l` — password length
- `--lowercase / --no-lowercase`
- `--uppercase / --no-uppercase`
- `--digits / --no-digits`
- `--punctuation / --no-punctuation`
- `--min-lowercase`
- `--min-uppercase`
- `--min-digits`
- `--min-punctuation`
- `--copy`, `-c` — copy the generated password to the clipboard

## Python API

You can also use the generator directly from Python code:

```python
from password_generator_app.core.password_generator import (
    PasswordGenerator,
    PasswordConfig,
)

config = PasswordConfig(
    length=18,
    include_lowercase=True,
    include_uppercase=True,
    include_digits=True,
    include_punctuation=True,
    min_lowercase=3,
    min_uppercase=3,
    min_digits=3,
    min_punctuation=3,
)

password = PasswordGenerator(config)

for _ in range(5):
    print(password.generate())
```

## Settings

The application stores its settings in the project directory as `settings.json`.

Saved values include:

- theme
- accent color
- window size
- password generation options

## Project Structure

```text
password_generator_app_v1/
├── imgs/
├── scripts/
│   ├── cleanup.ps1
│   ├── build.ps1
│   ├── rebuild.ps1
│   └── rebuild.bat
├── src/
│   └── password_generator_app/
├── tests/
├── CHANGELOG.md
├── LICENSE
├── MANIFEST.in
├── pyproject.toml
└── README.md
```

## Windows Batch Launcher

You can place `passgen.bat` inside your `commands` folder and update the project path in the file.  
After that, the app can be launched directly from the terminal without installing the package.

```powershell
passgen gui
passgen --length 32 --copy
password-generator gui
password-generator --length 32 --copy
```

## Running Tests

Install pytest:

```bash
pip install pytest
```

Run all tests:

```bash
pytest -v
```

The project includes:

- Core password generator tests
- Validation tests
- CLI tests

## Development Utilities

### Rebuild local package

Run the complete local development workflow:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\rebuild.ps1
```

Or:

```powershell
.\scripts\rebuild.bat
```

This process will:

- Clean the project
- Remove old local installations
- Run tests
- Build package distributions
- Validate distributions using Twine
- Reinstall the latest local build

## Author

Developed by Vahed MamGhaderi

## License

This project is licensed under the MIT License.

See the [LICENSE](LICENSE) file for details.
