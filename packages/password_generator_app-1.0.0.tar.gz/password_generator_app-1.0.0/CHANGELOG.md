# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog:
https://keepachangelog.com/en/1.1.0/

This project follows Semantic Versioning:
https://semver.org/

---

## [1.0.0] - 2026-05-24

### Added
- Modern Material-style graphical user interface built with PySide6
- Full command-line interface (CLI)
- `passgen` executable command support
- Password generation with configurable:
  - length
  - lowercase characters
  - uppercase characters
  - digits
  - punctuation symbols
- Clipboard copy support
- Password strength indicator
- Persistent local settings storage
- Light and dark theme support
- Accent color customization
- Settings reset functionality
- Cross-platform Python package structure
- PyPI-ready packaging configuration
- GitHub-ready project structure
- README screenshots and usage examples
- Batch launcher for Windows (`passgen.bat`)

### Improved
- Refactored application architecture using:
  - `core/`
  - `ui/`
  - `src/` package layout
- Improved UI sizing and spacing
- Improved theme consistency across widgets
- Improved button and textbox styling
- Improved CLI usability and argument handling
- Improved packaging metadata

### Fixed
- Fixed GUI theme rendering issues
- Fixed dark/light mode text color inconsistencies
- Fixed PySide6 icon compatibility issues
- Fixed `QProgressBar` import issues
- Fixed relative import execution problems
- Fixed CLI module discovery issues
- Fixed settings persistence bugs
- Fixed widget sizing inconsistencies
- Fixed multiple startup crashes

### Security
- Secure password generation using Python's `secrets` module
