from __future__ import annotations

from dataclasses import asdict

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QGuiApplication
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QColorDialog,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QStyle,
    QVBoxLayout,
    QWidget,
    QAbstractSpinBox,
)

from ..core.password_generator import PasswordConfig, PasswordGenerator
from ..core.settings import SettingsStore
from ..core.theme import ThemeManager
from .widgets import MaterialCard, IconToolButton, app_icon


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.settings = SettingsStore()
        self._loading = False
        self._theme = self.settings.ui.get("theme", "dark")
        self._accent = self.settings.ui.get("accent", "#2563eb")

        self.setWindowTitle("Password Generator")
        self.resize(self.settings.window.get("width", 470), 
                    self.settings.window.get("height", 500))
        self.setMinimumSize(400, 400)

        self._build_ui()
        self._load_state()
        self._bind_signals()
        self._apply_theme()
        QTimer.singleShot(0, self.generate_password)

    def _build_ui(self) -> None:
        central = QWidget(self)
        self.setCentralWidget(central)

        root = QVBoxLayout(central)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(10)

        top_bar = QFrame(self)
        top_bar.setObjectName("TopBar")
        top_layout = QVBoxLayout(top_bar)
        top_layout.setContentsMargins(12, 10, 12, 10)
        top_layout.setSpacing(4)

        header_row = QHBoxLayout()
        header_row.setSpacing(8)

        self.title_label = QLabel("Password Generator")
        self.title_label.setObjectName("TitleLabel")
        self.subtitle_label = QLabel("Simple, material-style password generator")
        self.subtitle_label.setObjectName("SubtitleLabel")

        header_row.addWidget(self.title_label)
        header_row.addStretch(1)

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Dark", "Light"])
        self.theme_combo.setFixedWidth(96)

        self.accent_button = IconToolButton(
            app_icon(self, QStyle.StandardPixmap.SP_FileDialogDetailedView),
            "Change accent color",
            self,
        )
        self.reset_button = IconToolButton(
            app_icon(self, QStyle.StandardPixmap.SP_BrowserReload),
            "Restore defaults",
            self,
        )

        header_row.addWidget(self.theme_combo)
        header_row.addWidget(self.accent_button)
        header_row.addWidget(self.reset_button)

        top_layout.addLayout(header_row)
        top_layout.addWidget(self.subtitle_label)
        root.addWidget(top_bar)

        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(10)

        # Result card
        self.result_card = MaterialCard()
        result_layout = self.result_card.layout
        result_title = QLabel("Generated password")
        result_title.setObjectName("SectionTitle")
        self.password_edit = QLineEdit()
        self.password_edit.setMinimumHeight(34)
        self.password_edit.setReadOnly(True)
        self.password_edit.setFont(QFont("Consolas", 11))

        button_row = QHBoxLayout()
        button_row.setSpacing(8)
        self.generate_button = QPushButton("Generate")
        self.generate_button.setMinimumHeight(32)
        self.copy_button = QPushButton("Copy")
        self.copy_button.setMinimumHeight(32)
        self.copy_button.setObjectName("SecondaryButton")
        button_row.addWidget(self.generate_button)
        button_row.addWidget(self.copy_button)

        self.strength_bar = QProgressBar()
        self.strength_bar.setRange(0, 100)
        self.strength_label = QLabel("Strength: -")

        result_layout.addWidget(result_title)
        result_layout.addWidget(self.password_edit)
        result_layout.addLayout(button_row)
        result_layout.addWidget(self.strength_bar)
        result_layout.addWidget(self.strength_label)

        # Options card
        self.options_card = MaterialCard()
        options_layout = self.options_card.layout
        options_title = QLabel("Password rules")
        options_title.setObjectName("SectionTitle")
        options_layout.addWidget(options_title)

        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(8)

        self.length_spin = QSpinBox()
        self.length_spin.setRange(4, 256)
        self.length_spin.setFixedHeight(32)

        self.lower_check = QCheckBox("Lowercase")
        self.upper_check = QCheckBox("Uppercase")
        self.digit_check = QCheckBox("Digits")
        self.punct_check = QCheckBox("Punctuation")

        self.min_lower_spin = self._make_spin()
        self.min_upper_spin = self._make_spin()
        self.min_digit_spin = self._make_spin()
        self.min_punct_spin = self._make_spin()

        grid.addWidget(QLabel("Length"), 0, 0)
        grid.addWidget(self.length_spin, 0, 1)

        grid.addWidget(self.lower_check, 1, 0)
        grid.addWidget(self.upper_check, 1, 1)

        grid.addWidget(self.digit_check, 2, 0)
        grid.addWidget(self.punct_check, 2, 1)

        grid.addWidget(QLabel("Min lowercase"), 3, 0)
        grid.addWidget(self.min_lower_spin, 3, 1)

        grid.addWidget(QLabel("Min uppercase"), 4, 0)
        grid.addWidget(self.min_upper_spin, 4, 1)

        grid.addWidget(QLabel("Min digits"), 5, 0)
        grid.addWidget(self.min_digit_spin, 5, 1)

        grid.addWidget(QLabel("Min punctuation"), 6, 0)
        grid.addWidget(self.min_punct_spin, 6, 1)

        options_layout.addLayout(grid)

        footer = QLabel("Developed by Vahed MamGhaderi")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        footer.setObjectName("SubtitleLabel")

        content_layout.addWidget(self.result_card)
        content_layout.addWidget(self.options_card)
        content_layout.addStretch(1)
        content_layout.addWidget(footer)
        scroll.setWidget(content)
        root.addWidget(scroll)

        self.setFont(QFont("Segoe UI", 9))

    def _make_spin(self) -> QSpinBox:
        spin = QSpinBox()
        spin.setRange(0, 256)
        spin.setFixedHeight(32)
        spin.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.UpDownArrows)
        return spin

    def _load_state(self) -> None:
        self._loading = True
        g = self.settings.generator
        self.length_spin.setValue(int(g.get("length", 20)))
        self.lower_check.setChecked(bool(g.get("include_lowercase", True)))
        self.upper_check.setChecked(bool(g.get("include_uppercase", True)))
        self.digit_check.setChecked(bool(g.get("include_digits", True)))
        self.punct_check.setChecked(bool(g.get("include_punctuation", True)))
        self.min_lower_spin.setValue(int(g.get("min_lowercase", 4)))
        self.min_upper_spin.setValue(int(g.get("min_uppercase", 4)))
        self.min_digit_spin.setValue(int(g.get("min_digits", 4)))
        self.min_punct_spin.setValue(int(g.get("min_punctuation", 4)))

        ui = self.settings.ui
        theme = str(ui.get("theme", "dark")).capitalize()
        self.theme_combo.setCurrentText(theme if theme in ("Dark", "Light") else "Dark")
        self._accent = str(ui.get("accent", "#2563eb"))

        self._sync_controls()
        self._loading = False

    def _bind_signals(self) -> None:
        self.generate_button.clicked.connect(self.generate_password)
        self.copy_button.clicked.connect(self.copy_password)
        self.theme_combo.currentTextChanged.connect(self._on_theme_changed)
        self.accent_button.clicked.connect(self.choose_accent)
        self.reset_button.clicked.connect(self.restore_defaults)

        for widget in (
            self.length_spin,
            self.min_lower_spin,
            self.min_upper_spin,
            self.min_digit_spin,
            self.min_punct_spin,
        ):
            widget.valueChanged.connect(self._on_generator_changed)

        for checkbox in (
            self.lower_check,
            self.upper_check,
            self.digit_check,
            self.punct_check,
        ):
            checkbox.toggled.connect(self._on_group_toggled)

    def _on_theme_changed(self, *_: object) -> None:
        if self._loading:
            return
        self._theme = self.theme_combo.currentText().lower()
        self.settings.update_ui(theme=self._theme, accent=self._accent)
        self._apply_theme()

    def choose_accent(self) -> None:
        color = QColorDialog.getColor(self.palette().highlight().color(), self, "Choose accent color")
        if not color.isValid():
            return
        self._accent = color.name()
        self.settings.update_ui(theme=self._theme, accent=self._accent)
        self._apply_theme()

    def _apply_theme(self) -> None:
        app = QApplication.instance()
        if app is None:
            return
        ThemeManager.apply(app, self._theme, self._accent)
        self.update()
        self.repaint()

    def _on_group_toggled(self, *_: object) -> None:
        if self._loading:
            return

        if not any((self.lower_check.isChecked(), self.upper_check.isChecked(), self.digit_check.isChecked(), self.punct_check.isChecked())):
            sender = self.sender()
            if isinstance(sender, QCheckBox):
                sender.blockSignals(True)
                sender.setChecked(True)
                sender.blockSignals(False)
            QMessageBox.information(self, "Character groups", "At least one character group must remain enabled.")
            return

        self._sync_controls()
        self._save_generator_state()

    def _on_generator_changed(self, *_: object) -> None:
        if self._loading:
            return
        self._sync_controls()
        self._save_generator_state()

    def _sync_controls(self) -> None:
        max_len = self.length_spin.value()
        for spin in (self.min_lower_spin, self.min_upper_spin, self.min_digit_spin, self.min_punct_spin):
            spin.setMaximum(max_len)

        pairs = (
            (self.lower_check, self.min_lower_spin, 4),
            (self.upper_check, self.min_upper_spin, 4),
            (self.digit_check, self.min_digit_spin, 4),
            (self.punct_check, self.min_punct_spin, 4),
        )

        for check, spin, default in pairs:
            enabled = check.isChecked()
            spin.setEnabled(enabled)
            if not enabled:
                spin.blockSignals(True)
                spin.setValue(0)
                spin.blockSignals(False)
            elif spin.value() == 0:
                spin.blockSignals(True)
                spin.setValue(min(default, max_len))
                spin.blockSignals(False)

        total = self.min_lower_spin.value() + self.min_upper_spin.value() + self.min_digit_spin.value() + self.min_punct_spin.value()
        if total > max_len:
            overflow = total - max_len
            for spin in (self.min_punct_spin, self.min_digit_spin, self.min_upper_spin, self.min_lower_spin):
                if overflow <= 0:
                    break
                dec = min(spin.value(), overflow)
                spin.blockSignals(True)
                spin.setValue(spin.value() - dec)
                spin.blockSignals(False)
                overflow -= dec

    def _collect_config(self) -> PasswordConfig:
        return PasswordConfig(
            length=self.length_spin.value(),
            include_lowercase=self.lower_check.isChecked(),
            include_uppercase=self.upper_check.isChecked(),
            include_digits=self.digit_check.isChecked(),
            include_punctuation=self.punct_check.isChecked(),
            min_lowercase=self.min_lower_spin.value(),
            min_uppercase=self.min_upper_spin.value(),
            min_digits=self.min_digit_spin.value(),
            min_punctuation=self.min_punct_spin.value(),
        )

    def _save_generator_state(self) -> None:
        config = self._collect_config()
        self.settings.update_generator(**asdict(config))
        self._update_strength()

    def generate_password(self) -> None:
        try:
            password = PasswordGenerator(self._collect_config()).generate()
        except Exception as exc:
            QMessageBox.warning(self, "Invalid settings", str(exc))
            return

        self.password_edit.setText(password)
        self._update_strength(password)

    def copy_password(self) -> None:
        text = self.password_edit.text().strip()
        if not text:
            QMessageBox.information(self, "Clipboard", "Generate a password first.")
            return
        QGuiApplication.clipboard().setText(text)
        QMessageBox.information(self, "Clipboard", "Password copied to clipboard.")

    def _update_strength(self, password: str | None = None) -> None:
        if password is None:
            password = self.password_edit.text()

        if not password:
            self.strength_bar.setValue(0)
            self.strength_label.setText("Strength: -")
            return

        groups = sum(
            int(v)
            for v in (
                self.lower_check.isChecked(),
                self.upper_check.isChecked(),
                self.digit_check.isChecked(),
                self.punct_check.isChecked(),
            )
        )
        score = min(100, len(password) * 4 + groups * 10)
        self.strength_bar.setValue(score)

        if score >= 80:
            level = "Very strong"
        elif score >= 60:
            level = "Strong"
        elif score >= 40:
            level = "Good"
        else:
            level = "Weak"
        self.strength_label.setText(f"Strength: {level} ({score}%)")

    def restore_defaults(self) -> None:
        if QMessageBox.question(self, "Restore defaults", "Restore all settings to default?") != QMessageBox.StandardButton.Yes:
            return
        self.settings.restore_defaults()
        self._loading = True
        self._load_state()
        self._loading = False
        self._apply_theme()
        self.generate_password()

    def closeEvent(self, event) -> None:
        self.settings.update_window(width=self.width(), height=self.height())
        self.settings.update_ui(theme=self._theme, accent=self._accent)
        self.settings.save()
        super().closeEvent(event)
