from __future__ import annotations

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QColor, QIcon
from PySide6.QtWidgets import QFrame, QGraphicsDropShadowEffect, QStyle, QToolButton, QWidget, QVBoxLayout


class MaterialCard(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("Card")
        effect = QGraphicsDropShadowEffect(self)
        effect.setBlurRadius(28)
        effect.setOffset(0, 8)
        effect.setColor(QColor(0, 0, 0, 35))
        self.setGraphicsEffect(effect)
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(18, 18, 18, 18)
        self.layout.setSpacing(14)


class IconToolButton(QToolButton):
    def __init__(self, icon: QIcon, tooltip: str = "", parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("IconToolButton")
        self.setIcon(icon)
        self.setToolTip(tooltip)
        self.setIconSize(QSize(16, 16))
        self.setAutoRaise(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(34, 34)


def app_icon(widget: QWidget, standard: QStyle.StandardPixmap) -> QIcon:
    return widget.style().standardIcon(standard)
