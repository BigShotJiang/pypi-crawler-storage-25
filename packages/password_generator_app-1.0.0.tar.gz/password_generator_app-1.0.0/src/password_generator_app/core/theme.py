from __future__ import annotations

from dataclasses import dataclass
from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication


@dataclass(frozen=True)
class ThemeSpec:
    name: str
    window_bg: str
    surface: str
    text: str
    muted: str
    border: str
    input_bg: str
    button_bg: str
    button_text: str
    secondary_bg: str
    secondary_text: str
    selection: str


LIGHT = ThemeSpec(
    name="Light",
    window_bg="#f4f7fb",
    surface="#ffffff",
    text="#1f2937",
    muted="#6b7280",
    border="#d8e0ea",
    input_bg="#ffffff",
    button_bg="#2563eb",
    button_text="#ffffff",
    secondary_bg="#eef2ff",
    secondary_text="#1f2937",
    selection="#dbeafe",
)

DARK = ThemeSpec(
    name="Dark",
    window_bg="#0f172a",
    surface="#111827",
    text="#e5e7eb",
    muted="#94a3b8",
    border="#334155",
    input_bg="#111827",
    button_bg="#60a5fa",
    button_text="#081120",
    secondary_bg="#1f2937",
    secondary_text="#e5e7eb",
    selection="#1e293b",
)


def build_stylesheet(spec: ThemeSpec, accent: str) -> str:
    template = """
QWidget {
    background: __WINDOW_BG__;
    color: __TEXT__;
    font-family: "Segoe UI";
    font-size: 10pt;
}

QMainWindow {
    background: __WINDOW_BG__;
}

QLabel {
    color: __TEXT__;
}

QLabel#TitleLabel {
    font-size: 16pt;
    font-weight: 700;
}

QLabel#SubtitleLabel {
    color: __MUTED__;
}

QFrame#TopBar, QFrame#Card {
    background: __SURFACE__;
    border: 1px solid __BORDER__;
    border-radius: 16px;
}

QLineEdit, QSpinBox, QComboBox {
    background: __INPUT_BG__;
    color: __TEXT__;
    border: 1px solid __BORDER__;
    border-radius: 10px;
    padding: 6px 10px;
    min-height: 32px;
    selection-background-color: __ACCENT__;
    selection-color: #ffffff;
}

QComboBox::drop-down {
    border: none;
    width: 22px;
}

QComboBox QAbstractItemView {
    background: __SURFACE__;
    color: __TEXT__;
    border: 1px solid __BORDER__;
    selection-background-color: __SELECTION__;
    selection-color: __TEXT__;
    outline: 0;
}

QCheckBox {
    spacing: 8px;
    color: __TEXT__;
}

QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 1px solid __BORDER__;
    background: __INPUT_BG__;
}

QCheckBox::indicator:checked {
    background: __ACCENT__;
    border: 1px solid __ACCENT__;
}

QPushButton {
    background: __BUTTON_BG__;
    color: __BUTTON_TEXT__;
    border: none;
    border-radius: 10px;
    padding: 6px 12px;
    min-height: 32px;
    font-weight: 600;
}

QPushButton:hover {
    background: __ACCENT__;
}

QPushButton#SecondaryButton {
    background: __SECONDARY_BG__;
    color: __SECONDARY_TEXT__;
    border: 1px solid __BORDER__;
}

QPushButton#SecondaryButton:hover {
    background: __SELECTION__;
}

QToolButton#IconToolButton {
    background: transparent;
    color: __TEXT__;
    border: 1px solid __BORDER__;
    border-radius: 8px;
    min-width: 32px;
    min-height: 32px;
    padding: 3px;
}

QToolButton#IconToolButton:hover {
    background: __SELECTION__;
    border: 1px solid __ACCENT__;
}

QProgressBar {
    background: __INPUT_BG__;
    color: __TEXT__;
    border: 1px solid __BORDER__;
    border-radius: 7px;
    text-align: center;
    min-height: 14px;
}

QProgressBar::chunk {
    background: __ACCENT__;
    border-radius: 7px;
}

QScrollArea {
    border: none;
    background: transparent;
}

QMenu {
    background: __SURFACE__;
    color: __TEXT__;
    border: 1px solid __BORDER__;
}

QMenu::item:selected {
    background: __SELECTION__;
}

QToolTip {
    background: __SURFACE__;
    color: __TEXT__;
    border: 1px solid __BORDER__;
}
"""
    return (
        template.replace("__WINDOW_BG__", spec.window_bg)
        .replace("__SURFACE__", spec.surface)
        .replace("__TEXT__", spec.text)
        .replace("__MUTED__", spec.muted)
        .replace("__BORDER__", spec.border)
        .replace("__INPUT_BG__", spec.input_bg)
        .replace("__BUTTON_BG__", spec.button_bg)
        .replace("__BUTTON_TEXT__", spec.button_text)
        .replace("__SECONDARY_BG__", spec.secondary_bg)
        .replace("__SECONDARY_TEXT__", spec.secondary_text)
        .replace("__SELECTION__", spec.selection)
        .replace("__ACCENT__", accent)
    )


def build_palette(spec: ThemeSpec, accent: str) -> QPalette:
    pal = QPalette()
    bg = QColor(spec.window_bg)
    surface = QColor(spec.surface)
    text = QColor(spec.text)
    muted = QColor(spec.muted)
    accent_q = QColor(accent)

    pal.setColor(QPalette.Window, bg)
    pal.setColor(QPalette.WindowText, text)
    pal.setColor(QPalette.Base, surface)
    pal.setColor(QPalette.AlternateBase, bg)
    pal.setColor(QPalette.ToolTipBase, surface)
    pal.setColor(QPalette.ToolTipText, text)
    pal.setColor(QPalette.Text, text)
    pal.setColor(QPalette.Button, surface)
    pal.setColor(QPalette.ButtonText, text)
    pal.setColor(QPalette.BrightText, QColor("#ffffff"))
    pal.setColor(QPalette.Highlight, accent_q)
    pal.setColor(QPalette.HighlightedText, QColor("#ffffff"))
    pal.setColor(QPalette.PlaceholderText, muted)
    return pal


class ThemeManager:
    THEMES = {"light": LIGHT, "dark": DARK}

    @classmethod
    def apply(cls, app: QApplication, theme_name: str, accent: str) -> ThemeSpec:
        spec = cls.THEMES.get(theme_name.strip().lower(), DARK)
        app.setPalette(build_palette(spec, accent))
        app.setStyleSheet(build_stylesheet(spec, accent))
        return spec
