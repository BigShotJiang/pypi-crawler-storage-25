from __future__ import annotations

from dataclasses import dataclass
import random
import string


@dataclass(slots=True)
class PasswordConfig:
    length: int = 20

    include_lowercase: bool = True
    include_uppercase: bool = True
    include_digits: bool = True
    include_punctuation: bool = True

    min_lowercase: int = 4
    min_uppercase: int = 4
    min_digits: int = 4
    min_punctuation: int = 4


class PasswordGenerator:
    LOWERCASE = string.ascii_lowercase
    UPPERCASE = string.ascii_uppercase
    DIGITS = string.digits
    PUNCTUATION = string.punctuation

    def __init__(self, config: PasswordConfig) -> None:
        self.config = config
        self._validate()

    def _validate(self) -> None:
        c = self.config
        if c.length < 1:
            raise ValueError("Password length must be at least 1.")

        if min(c.min_lowercase, c.min_uppercase, c.min_digits, c.min_punctuation) < 0:
            raise ValueError("Minimum counts cannot be negative.")

        if not (c.include_lowercase or c.include_uppercase or c.include_digits or c.include_punctuation):
            raise ValueError("At least one character group must be enabled.")

        if c.min_lowercase > 0 and not c.include_lowercase:
            raise ValueError("Lowercase minimum is set, but lowercase is disabled.")
        if c.min_uppercase > 0 and not c.include_uppercase:
            raise ValueError("Uppercase minimum is set, but uppercase is disabled.")
        if c.min_digits > 0 and not c.include_digits:
            raise ValueError("Digits minimum is set, but digits are disabled.")
        if c.min_punctuation > 0 and not c.include_punctuation:
            raise ValueError("Punctuation minimum is set, but punctuation is disabled.")

        total_min = c.min_lowercase + c.min_uppercase + c.min_digits + c.min_punctuation
        if total_min > c.length:
            raise ValueError("The sum of minimum required characters cannot exceed the password length.")

    def _allowed_chars(self) -> str:
        c = self.config
        parts: list[str] = []
        if c.include_lowercase:
            parts.append(self.LOWERCASE)
        if c.include_uppercase:
            parts.append(self.UPPERCASE)
        if c.include_digits:
            parts.append(self.DIGITS)
        if c.include_punctuation:
            parts.append(self.PUNCTUATION)
        chars = "".join(parts)
        if not chars:
            raise ValueError("No characters available for password generation.")
        return chars

    def generate(self) -> str:
        c = self.config
        rng = random.SystemRandom()
        allowed = self._allowed_chars()

        chars: list[str] = []
        if c.include_lowercase:
            chars.extend(rng.choice(self.LOWERCASE) for _ in range(c.min_lowercase))
        if c.include_uppercase:
            chars.extend(rng.choice(self.UPPERCASE) for _ in range(c.min_uppercase))
        if c.include_digits:
            chars.extend(rng.choice(self.DIGITS) for _ in range(c.min_digits))
        if c.include_punctuation:
            chars.extend(rng.choice(self.PUNCTUATION) for _ in range(c.min_punctuation))

        remaining = c.length - len(chars)
        chars.extend(rng.choice(allowed) for _ in range(remaining))
        rng.shuffle(chars)
        return "".join(chars)
