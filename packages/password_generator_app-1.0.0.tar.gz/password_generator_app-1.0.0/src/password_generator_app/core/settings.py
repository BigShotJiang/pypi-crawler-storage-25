from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict
import json
import os
from pathlib import Path
from typing import Any

from .password_generator import PasswordConfig

APP_NAME = "password_generator_app"
SETTINGS_FILENAME = "settings.json"


def _default_settings() -> dict[str, Any]:
    generator = asdict(PasswordConfig())
    return {
        "version": 1,
        "window": {"width": 470, "height": 500},
        "ui": {"theme": "dark", "accent": "#2563eb"},
        "generator": deepcopy(generator),
        "default_generator": deepcopy(generator),
        "default_ui": {"theme": "dark", "accent": "#2563eb"},
    }


def _is_writable_dir(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        test = path / ".write_test"
        test.write_text("ok", encoding="utf-8")
        test.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def settings_dir() -> Path:
    env = os.getenv("PASSGEN_HOME")
    if env:
        return Path(env)

    candidate = Path(__file__).resolve().parents[2]
    if _is_writable_dir(candidate):
        return candidate

    return Path.cwd() / APP_NAME


def settings_path() -> Path:
    return settings_dir() / SETTINGS_FILENAME


class SettingsStore:
    def __init__(self) -> None:
        self.path = settings_path()
        self.data = self._load()

    def _load(self) -> dict[str, Any]:
        defaults = _default_settings()
        if not self.path.exists():
            self._save(defaults)
            return defaults

        try:
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(loaded, dict):
                raise ValueError("Settings file must contain a JSON object.")
        except Exception:
            self._save(defaults)
            return defaults

        merged = deepcopy(defaults)
        self._deep_merge(merged, loaded)
        self._save(merged)
        return merged

    @staticmethod
    def _deep_merge(base: dict[str, Any], incoming: dict[str, Any]) -> None:
        for key, value in incoming.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                SettingsStore._deep_merge(base[key], value)
            else:
                base[key] = value

    def _save(self, data: dict[str, Any]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=4), encoding="utf-8")
        self.data = data

    def save(self) -> None:
        self._save(self.data)

    def restore_defaults(self) -> None:
        self._save(_default_settings())

    @property
    def generator(self) -> dict[str, Any]:
        return deepcopy(self.data["generator"])

    @property
    def ui(self) -> dict[str, Any]:
        return deepcopy(self.data["ui"])

    @property
    def window(self) -> dict[str, Any]:
        return deepcopy(self.data["window"])

    def update_generator(self, **kwargs: Any) -> None:
        self.data["generator"].update(kwargs)
        self.save()

    def update_ui(self, **kwargs: Any) -> None:
        self.data["ui"].update(kwargs)
        self.save()

    def update_window(self, **kwargs: Any) -> None:
        self.data["window"].update(kwargs)
        self.save()
