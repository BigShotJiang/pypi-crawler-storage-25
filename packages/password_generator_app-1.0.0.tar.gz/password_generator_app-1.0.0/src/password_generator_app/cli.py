from __future__ import annotations

import argparse
import sys

from PySide6.QtWidgets import QApplication

from .app import main as run_gui
from .core.password_generator import PasswordConfig, PasswordGenerator
from .core.console_color import Fore, Style

def _bool_opts(parser: argparse.ArgumentParser, name: str, default: bool, help_text: str) -> None:
    group = parser.add_mutually_exclusive_group()
    group.add_argument(f"--{name}", dest=name, action="store_true", help=help_text)
    group.add_argument(f"--no-{name}", dest=name, action="store_false", help=f"Disable {help_text.lower()}")
    parser.set_defaults(**{name: default})


def build_parser() -> argparse.ArgumentParser:
    example = f"\n \t{Fore.Bright_Green}passgen" + Style.Reset
    example += f"\n \t{Fore.Bright_Green}passgen -l 24 -c" + Style.Reset
    example += f"\n \t{Fore.Bright_Green}passgen --length 24 --min-lowercase 5 --min-uppercase 5 --min-digits 5 --min-punctuation 5 --copy" + Style.Reset
    example += f"\n \t{Fore.Bright_Green}passgen generate --length 24 --min-lowercase 5 --min-uppercase 5 --min-digits 5 --min-punctuation 5 --copy" + Style.Reset
    example += "\n      Or:\n"
    example += f"   {Fore.Bright_Green}\tpassgen gui"  + Style.Reset


    parser = argparse.ArgumentParser(
        prog="passgen",
        description="Password Generator (GUI and CLI)",
        usage=example,
    )
    parser.add_argument("command", nargs="?", choices=["gui", "generate"], help="Run the GUI or explicitly generate a password.")
    parser.add_argument("--length", "-l", type=int, default=20, help="Password length.")
    _bool_opts(parser, "lowercase", True, "Include lowercase letters")
    _bool_opts(parser, "uppercase", True, "Include uppercase letters")
    _bool_opts(parser, "digits", True, "Include digits")
    _bool_opts(parser, "punctuation", True, "Include punctuation")
    parser.add_argument("--min-lowercase", type=int, default=4, help="Minimum lowercase characters.")
    parser.add_argument("--min-uppercase", type=int, default=4, help="Minimum uppercase characters.")
    parser.add_argument("--min-digits", type=int, default=4, help="Minimum digit characters.")
    parser.add_argument("--min-punctuation", type=int, default=4, help="Minimum punctuation characters.")
    parser.add_argument("--copy", "-c", action="store_true", help="Copy the generated password to clipboard.")
    return parser


def generate_from_args(args: argparse.Namespace) -> str:
    cfg = PasswordConfig(
        length=args.length,
        include_lowercase=args.lowercase,
        include_uppercase=args.uppercase,
        include_digits=args.digits,
        include_punctuation=args.punctuation,
        min_lowercase=args.min_lowercase,
        min_uppercase=args.min_uppercase,
        min_digits=args.min_digits,
        min_punctuation=args.min_punctuation,
    )
    password = PasswordGenerator(cfg).generate()
    passwordFormat = Fore.Blue + f"   Generated Password ({len(password)} chars): " + Style.Underline  + Fore.Green + f"{password}"  + Style.Reset
    print(passwordFormat)
    if args.copy:
        app = QApplication.instance() or QApplication(sys.argv)
        app.clipboard().setText(password)
        print(Fore.Red + "   Copied to clipboard." + Style.Reset)
    return password

def print_suggest(argv: list[str] | None = None):
    len_arg = 0
    if argv is None:
        # args default to the system args
        len_arg = len(sys.argv[1:])
        
    else:
        # make sure that args are mutable
        len_arg = len(list(argv))
    
    if (len_arg == 0):
        suggestStr = f"   {Fore.Bright_Cyan}Example Usage: \n   \tpassgen --length 24 --min-lowercase 5 --min-uppercase 5 --min-digits 5 --min-punctuation 5 --copy" + Style.Reset
        suggestStr += "\n   Or:\n"
        suggestStr += f"   {Fore.Bright_Cyan}\tpassgen gui"  + Style.Reset

        print(suggestStr)


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "gui":
        return run_gui()

    generate_from_args(args)

    print_suggest(argv)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
