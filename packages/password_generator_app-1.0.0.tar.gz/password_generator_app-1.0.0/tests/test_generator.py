from password_generator_app.core.password_generator import (
    PasswordConfig,
    PasswordGenerator,
)


def make_password(config: PasswordConfig) -> str:
    return PasswordGenerator(config).generate()


def test_password_length():
    password = make_password(PasswordConfig(length=20))
    assert len(password) == 20


def test_contains_required_lowercase():
    password = make_password(
        PasswordConfig(
            length=20,
            min_lowercase=4,
        )
    )
    assert sum(1 for c in password if c.islower()) >= 4


def test_contains_required_uppercase():
    password = make_password(
        PasswordConfig(
            length=20,
            min_uppercase=4,
        )
    )
    assert sum(1 for c in password if c.isupper()) >= 4


def test_contains_required_digits():
    password = make_password(
        PasswordConfig(
            length=20,
            min_digits=4,
        )
    )
    assert sum(1 for c in password if c.isdigit()) >= 4


def test_contains_required_punctuation():
    password = make_password(
        PasswordConfig(
            length=20,
            min_punctuation=4,
        )
    )
    assert sum(1 for c in password if not c.isalnum()) >= 4


def test_password_randomness():
    config = PasswordConfig(length=20)
    password_1 = make_password(config)
    password_2 = make_password(config)
    assert password_1 != password_2


def test_only_digits():
    password = make_password(
        PasswordConfig(
            length=12,
            include_lowercase=False,
            include_uppercase=False,
            include_digits=True,
            include_punctuation=False,
            min_lowercase=0,
            min_uppercase=0,
            min_digits=12,
            min_punctuation=0,
        )
    )
    assert password.isdigit()


def test_only_uppercase():
    password = make_password(
        PasswordConfig(
            length=12,
            include_lowercase=False,
            include_uppercase=True,
            include_digits=False,
            include_punctuation=False,
            min_lowercase=0,
            min_uppercase=12,
            min_digits=0,
            min_punctuation=0,
        )
    )
    assert password.isupper()


def test_invalid_sum_of_minimums_raises():
    try:
        PasswordGenerator(
            PasswordConfig(
                length=5,
                min_lowercase=3,
                min_uppercase=3,
                min_digits=0,
                min_punctuation=0,
            )
        )
    except ValueError:
        assert True
    else:
        assert False


def test_disabled_group_with_minimum_raises():
    try:
        PasswordGenerator(
            PasswordConfig(
                length=12,
                include_lowercase=False,
                include_uppercase=True,
                include_digits=False,
                include_punctuation=False,
                min_lowercase=1,
                min_uppercase=12,
                min_digits=0,
                min_punctuation=0,
            )
        )
    except ValueError:
        assert True
    else:
        assert False
