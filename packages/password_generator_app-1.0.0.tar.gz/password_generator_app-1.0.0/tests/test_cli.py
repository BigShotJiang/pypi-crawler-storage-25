import os
import subprocess
import sys
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[1]
SRC_DIR = ROOT_DIR / "src"


def run_cli(*args: str) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(SRC_DIR)
    return subprocess.run(
        [sys.executable, "-m", "password_generator_app.cli", *args],
        capture_output=True,
        text=True,
        env=env,
    )


def test_cli_generates_password():
    result = run_cli("--length", "16")
    assert result.returncode == 0
    password = result.stdout.strip().splitlines()[-1]
    assert len(password) >= 16


def test_cli_help():
    result = run_cli("--help")
    assert result.returncode == 0
    assert "usage" in result.stdout.lower()
