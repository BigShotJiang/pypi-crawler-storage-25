from openinsider import OpenInsider
from openinsider.periphery.db import drop_tables


def main():
    open_insider = OpenInsider()

    print(open_insider.ticker.get_insider_trades(["AAPL", "TSLA"], force_update=False))


if __name__ == "__main__":
    main()
