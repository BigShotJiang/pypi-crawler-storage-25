- This project uses "uv" package manager.

  - To activate the environment use "source .venv/bin/activate".
  - To install packages use: "uv pip install package"
  - To run scripts: "python script.py"

- This is a package that interacts with "http://openinsider.com/", and it's multiple endpoints.
