from .modules.ticker import Ticker
from .modules.cluster_buys import ClusterBuys
from .modules.insider_purchases import InsiderPurchases
from .modules.insider_sales import InsiderSales
from .modules.insider_purchases_25k import InsiderPurchases25k
from .modules.ceo_cfo_purchases_25k import CeoCfoPurchases25k
from .modules.ceo_cfo_sales_100k import CeoCfoSales100k
from .modules.top_officer_purchases_week import TopOfficerPurchasesWeek
from .modules.screener import Screener


class OpenInsider:
    def __init__(self):
        self.ticker = Ticker()
        self.cluster_buys = ClusterBuys()
        self.insider_purchases = InsiderPurchases()
        self.insider_sales = InsiderSales()
        self.insider_purchases_25k = InsiderPurchases25k()
        self.ceo_cfo_purchases_25k = CeoCfoPurchases25k()
        self.ceo_cfo_sales_100k = CeoCfoSales100k()
        self.top_officer_purchases_week = TopOfficerPurchasesWeek()
        self.screener = Screener()
