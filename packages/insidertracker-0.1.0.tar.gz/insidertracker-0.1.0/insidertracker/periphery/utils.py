import datetime as dt
import re


def parse_datetime(value: str) -> dt.datetime | None:
    if not isinstance(value, str):
        return value
    value = value.strip()
    if not value:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(value, fmt).replace(tzinfo=dt.timezone.utc)
        except ValueError:
            continue
    return None


def parse_date(value: str) -> dt.date | None:
    if not isinstance(value, str):
        return value
    value = value.strip()
    if not value:
        return None
    try:
        return dt.datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        return None


def parse_percentage_value(value: str) -> float | None:
    if not isinstance(value, str):
        return value
    value = value.strip()
    if not value:
        return None
    negative = value.startswith("-")
    cleaned = value.replace("%", "").replace("-", "").strip()
    try:
        result = float(cleaned) / 100
        return -result if negative else result
    except ValueError:
        return None


def parse_dollar_value(value: str) -> float | None:
    if not isinstance(value, str):
        return value
    value = value.strip()
    if not value:
        return None
    negative = value.startswith("-")
    cleaned = re.sub(r"[$,]", "", value).replace("-", "")
    try:
        result = float(cleaned)
        return -result if negative else result
    except ValueError:
        return None
