import re
import requests
import polars as pl
from lxml import html


def scrape_table(
    url: str, params: dict = {}, timeout: int = 30, as_dataframe: bool = False
):
    response = requests.get(url, params=params, timeout=timeout)
    response.raise_for_status()

    tree = html.fromstring(response.text)
    tables = tree.xpath("//*[@id='tablewrapper']/table")

    if not tables:
        raise ValueError("Could not find screener table on the page.")

    table = tables[0]
    rows = table.xpath(".//tr")

    parsed_rows = []
    for row in rows:
        cells = row.xpath(".//th | .//td")
        values = [cell.text_content().strip() for cell in cells]
        if values:
            parsed_rows.append(values)

    if not parsed_rows:
        return pl.DataFrame() if as_dataframe else []

    headers = parsed_rows[0][1:]
    data = [row[1:] for row in parsed_rows[1:]]

    if as_dataframe:
        return pl.DataFrame(data, schema=headers, orient="row")

    return {
        "headers": headers,
        "rows": data,
        "url": response.url,
        "params": params,
    }


def get_screener_table(
    ticker: str = "",
    insider_name: str = "",
    price_min: float | str = "",
    price_max: float | str = "",
    market_cap_min_millions: float | str = "",
    market_cap_max_millions: float | str = "",
    filing_date_within_days: int = 730,
    filing_date_range_text: str = "",
    trade_date_within_days: int = 0,
    trade_date_range_text: str = "",
    filing_delay_min_days: int | str = "",
    filing_delay_max_days: int | str = "",
    days_ago: int | str = "",
    only_cluster_buys: int = 1,
    transaction_value_min_usd_thousands: float | int = 50,
    transaction_value_max_usd_thousands: float | int | str = "",
    one_day_price_change_min_pct: float | str = "",
    one_day_price_change_max_pct: float | str = "",
    sic_sector_code: int | str = -1,
    industry_group_code_min: int = 100,
    industry_group_code_max: int = 9999,
    group_by: int = 0,
    shares_traded_min: float | int | str = "",
    shares_traded_max: float | int | str = "",
    insider_holdings_min: float | int | str = "",
    insider_holdings_max: float | int | str = "",
    ownership_change_min_pct: float | str = "",
    ownership_change_max_pct: float | str = "",
    total_transaction_value_min_usd_thousands: float | int | str = "",
    total_transaction_value_max_usd_thousands: float | int | str = "",
    two_day_price_change_min_pct: float | str = "",
    two_day_price_change_max_pct: float | str = "",
    sort_column_index: int = 0,
    page_size: int = 100,
    page: int = 1,
    base_url: str = "http://openinsider.com/screener",
    as_dataframe: bool = True,
    timeout: int = 30,
):
    """
    Get the OpenInsider screener table.

    Parameter naming here is made human-readable, then translated into the
    shorter OpenInsider URL params internally.
    """

    params = {
        "s": ticker,
        "o": insider_name,
        "pl": price_min,
        "ph": price_max,
        "ll": market_cap_min_millions,
        "lh": market_cap_max_millions,
        "fd": filing_date_within_days,
        "fdr": filing_date_range_text,
        "td": trade_date_within_days,
        "tdr": trade_date_range_text,
        "fdlyl": filing_delay_min_days,
        "fdlyh": filing_delay_max_days,
        "daysago": days_ago,
        "xp": only_cluster_buys,
        "vl": transaction_value_min_usd_thousands,
        "vh": transaction_value_max_usd_thousands,
        "ocl": one_day_price_change_min_pct,
        "och": one_day_price_change_max_pct,
        "sic1": sic_sector_code,
        "sicl": industry_group_code_min,
        "sich": industry_group_code_max,
        "grp": group_by,
        "nfl": shares_traded_min,
        "nfh": shares_traded_max,
        "nil": insider_holdings_min,
        "nih": insider_holdings_max,
        "nol": ownership_change_min_pct,
        "noh": ownership_change_max_pct,
        "v2l": total_transaction_value_min_usd_thousands,
        "v2h": total_transaction_value_max_usd_thousands,
        "oc2l": two_day_price_change_min_pct,
        "oc2h": two_day_price_change_max_pct,
        "sortcol": sort_column_index,
        "cnt": page_size,
        "page": page,
    }

    response = requests.get(base_url, params=params, timeout=timeout)
    print(response.status_code)
    print(response.url)
    response.raise_for_status()

    tree = html.fromstring(response.text)
    tables = tree.xpath("//*[@id='tablewrapper']/table")

    if not tables:
        raise ValueError("Could not find screener table on the page.")

    table = tables[0]
    rows = table.xpath(".//tr")

    parsed_rows = []
    for row in rows:
        cells = row.xpath(".//th | .//td")
        values = [cell.text_content().strip() for cell in cells]
        if values:
            parsed_rows.append(values)

    if not parsed_rows:
        return pl.DataFrame() if as_dataframe else []

    headers = parsed_rows[0]
    data = parsed_rows[1:]

    if as_dataframe:
        return pl.DataFrame(data, schema=headers, orient="row")

    return {
        "headers": headers,
        "rows": data,
        "url": response.url,
        "params": params,
    }
