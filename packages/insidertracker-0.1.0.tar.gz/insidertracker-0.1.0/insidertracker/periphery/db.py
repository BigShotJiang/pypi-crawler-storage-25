import duckdb
from .config import get_db_path


def _init_tables(db_path: str = None) -> duckdb.DuckDBPyConnection:
    if db_path is None:
        db_path = str(get_db_path())
    conn = duckdb.connect(db_path)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS tickers (
            filing_date      TIMESTAMPTZ NOT NULL,
            trade_date       DATE        NOT NULL,
            ticker           VARCHAR     NOT NULL,
            insider_name     VARCHAR     NOT NULL,
            title            VARCHAR,
            trade_type       VARCHAR     NOT NULL,
            price            DOUBLE,
            quantity         DOUBLE,
            owned            DOUBLE,
            ownership_change DOUBLE,
            value            DOUBLE,
            PRIMARY KEY (filing_date, ticker, insider_name, trade_type)
        );

        CREATE TABLE IF NOT EXISTS cluster_buys (
            filing_date      TIMESTAMPTZ NOT NULL,
            trade_date       DATE        NOT NULL,
            ticker           VARCHAR     NOT NULL,
            company_name     VARCHAR,
            industry         VARCHAR,
            num_insiders     VARCHAR,
            trade_type       VARCHAR     NOT NULL,
            price            DOUBLE,
            quantity         DOUBLE,
            owned            DOUBLE,
            ownership_change DOUBLE,
            value            DOUBLE,
            PRIMARY KEY (filing_date, ticker, trade_type)
        );

        CREATE TABLE IF NOT EXISTS insider_purchases (
            filing_date      TIMESTAMPTZ NOT NULL,
            trade_date       DATE        NOT NULL,
            ticker           VARCHAR     NOT NULL,
            company_name     VARCHAR,
            insider_name     VARCHAR     NOT NULL,
            title            VARCHAR,
            trade_type       VARCHAR     NOT NULL,
            price            DOUBLE,
            quantity         DOUBLE,
            owned            DOUBLE,
            ownership_change DOUBLE,
            value            DOUBLE,
            PRIMARY KEY (filing_date, ticker, insider_name, trade_type)
        );

        CREATE TABLE IF NOT EXISTS insider_sales (
            filing_date      TIMESTAMPTZ NOT NULL,
            trade_date       DATE        NOT NULL,
            ticker           VARCHAR     NOT NULL,
            company_name     VARCHAR,
            insider_name     VARCHAR     NOT NULL,
            title            VARCHAR,
            trade_type       VARCHAR     NOT NULL,
            price            DOUBLE,
            quantity         DOUBLE,
            owned            DOUBLE,
            ownership_change DOUBLE,
            value            DOUBLE,
            PRIMARY KEY (filing_date, ticker, insider_name, trade_type)
        );

        CREATE TABLE IF NOT EXISTS insider_purchases_25k (
            filing_date      TIMESTAMPTZ NOT NULL,
            trade_date       DATE        NOT NULL,
            ticker           VARCHAR     NOT NULL,
            company_name     VARCHAR,
            insider_name     VARCHAR     NOT NULL,
            title            VARCHAR,
            trade_type       VARCHAR     NOT NULL,
            price            DOUBLE,
            quantity         DOUBLE,
            owned            DOUBLE,
            ownership_change DOUBLE,
            value            DOUBLE,
            PRIMARY KEY (filing_date, ticker, insider_name, trade_type)
        );

        CREATE TABLE IF NOT EXISTS ceo_cfo_purchases_25k (
            filing_date      TIMESTAMPTZ NOT NULL,
            trade_date       DATE        NOT NULL,
            ticker           VARCHAR     NOT NULL,
            company_name     VARCHAR,
            insider_name     VARCHAR     NOT NULL,
            title            VARCHAR,
            trade_type       VARCHAR     NOT NULL,
            price            DOUBLE,
            quantity         DOUBLE,
            owned            DOUBLE,
            ownership_change DOUBLE,
            value            DOUBLE,
            PRIMARY KEY (filing_date, ticker, insider_name, trade_type)
        );

        CREATE TABLE IF NOT EXISTS ceo_cfo_sales_100k (
            filing_date      TIMESTAMPTZ NOT NULL,
            trade_date       DATE        NOT NULL,
            ticker           VARCHAR     NOT NULL,
            company_name     VARCHAR,
            insider_name     VARCHAR     NOT NULL,
            title            VARCHAR,
            trade_type       VARCHAR     NOT NULL,
            price            DOUBLE,
            quantity         DOUBLE,
            owned            DOUBLE,
            ownership_change DOUBLE,
            value            DOUBLE,
            PRIMARY KEY (filing_date, ticker, insider_name, trade_type)
        );

        CREATE TABLE IF NOT EXISTS top_officer_purchases_week (
            filing_date      TIMESTAMPTZ NOT NULL,
            trade_date       DATE        NOT NULL,
            ticker           VARCHAR     NOT NULL,
            company_name     VARCHAR,
            insider_name     VARCHAR     NOT NULL,
            title            VARCHAR,
            trade_type       VARCHAR     NOT NULL,
            price            DOUBLE,
            quantity         DOUBLE,
            owned            DOUBLE,
            ownership_change DOUBLE,
            value            DOUBLE,
            PRIMARY KEY (filing_date, ticker, insider_name, trade_type)
        );
        """
    )
    return conn


def insert_data(df, db_cols: list, table_name: str, conn, pk_cols: list = None):
    if df.is_empty():
        return
    final_cols = [c for c in db_cols if c in df.columns]
    df = df.select(final_cols)
    col_names = ", ".join(final_cols)

    if pk_cols:
        pk_where = " AND ".join([f"existing.{c} = df.{c}" for c in pk_cols])
        conn.execute(
            f"""
            INSERT INTO {table_name} ({col_names})
            SELECT {col_names} FROM df
            WHERE NOT EXISTS (
                SELECT 1 FROM {table_name} existing
                WHERE {pk_where}
            )
        """
        )
    else:
        conn.execute(
            f"INSERT INTO {table_name} ({col_names}) SELECT {col_names} FROM df"
        )


def drop_tables(table_name: str):
    conn = _init_tables()
    conn.execute(f"DROP TABLE {table_name}")
    conn.commit()
    conn.close()
