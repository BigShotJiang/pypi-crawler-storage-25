import re
import polars as pl
import datetime as dt
from ..periphery.scraper import scrape_table
from ..periphery.db import _init_tables, insert_data
from ..periphery.utils import parse_dollar_value, parse_percentage_value
from ..periphery.static import BASE_URL

STANDARD_RENAME_MAP = {
    "Filing Date": "filing_date",
    "Trade Date": "trade_date",
    "Ticker": "ticker",
    "Company Name": "company_name",
    "Insider Name": "insider_name",
    "Title": "title",
    "Trade Type": "trade_type",
    "Price": "price",
    "Qty": "quantity",
    "Owned": "owned",
    "ΔOwn": "ownership_change",
    "Value": "value",
}

DROP_COLS = ["1d", "1w", "1m", "6m"]

STANDARD_COLS = [
    "filing_date",
    "trade_date",
    "ticker",
    "company_name",
    "insider_name",
    "title",
    "trade_type",
    "price",
    "quantity",
    "owned",
    "ownership_change",
    "value",
]

STANDARD_PK = ["filing_date", "ticker", "insider_name", "trade_type"]


class BaseLatestModule:
    ENDPOINT: str = ""
    TABLE_NAME: str = ""
    COLS: list = STANDARD_COLS
    PK_COLS: list = STANDARD_PK
    RENAME_MAP: dict = STANDARD_RENAME_MAP
    DEFAULT_STALE_THRESHOLD: dt.timedelta = dt.timedelta(days=1)

    def __init__(self):
        self.conn = _init_tables()

    def get(
        self,
        stale_threshold: dt.timedelta | None = None,
        force_update: bool = False,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ) -> pl.DataFrame:
        if stale_threshold is None:
            stale_threshold = self.DEFAULT_STALE_THRESHOLD
        raw_df = self._read()
        if raw_df.is_empty() or force_update:
            df = self._scrape()
            self._insert(df)
            return self._read(min_date=min_date, max_date=max_date)
        last_filing_date = self._get_last_filing_date()
        if last_filing_date is not None:
            today = dt.datetime.now(dt.timezone.utc)
            if (today - last_filing_date) > stale_threshold:
                df = self._scrape()
                self._insert(df)
        return self._read(min_date=min_date, max_date=max_date)

    def _scrape(self) -> pl.DataFrame:
        url = f"{BASE_URL}/{self.ENDPOINT}"
        df = scrape_table(url, as_dataframe=True)
        df = df.rename({col: re.sub(r"\s+", " ", col).strip() for col in df.columns})
        df = df.rename({k: v for k, v in self.RENAME_MAP.items() if k in df.columns})
        df = df.drop([c for c in DROP_COLS if c in df.columns])
        for col in ("price", "value", "quantity", "owned"):
            if col in df.columns:
                df = df.with_columns(
                    pl.col(col).map_elements(parse_dollar_value, return_dtype=pl.Float64)
                )
        if "ownership_change" in df.columns:
            df = df.with_columns(
                pl.col("ownership_change").map_elements(
                    parse_percentage_value, return_dtype=pl.Float64
                )
            )
        return df

    def _read(
        self,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ) -> pl.DataFrame:
        query = f"SELECT * FROM {self.TABLE_NAME}"
        params = []
        clauses = []
        if min_date is not None:
            clauses.append("filing_date > ?")
            params.append(min_date)
        if max_date is not None:
            clauses.append("filing_date < ?")
            params.append(max_date)
        if clauses:
            query += " WHERE " + " AND ".join(clauses)
        return self.conn.execute(query, params).pl()

    def _insert(self, df: pl.DataFrame):
        insert_data(df, self.COLS, self.TABLE_NAME, self.conn, pk_cols=self.PK_COLS)

    def _get_last_filing_date(self):
        result = self.conn.execute(
            f"SELECT MAX(filing_date) FROM {self.TABLE_NAME}"
        ).fetchone()
        return result[0] if result else None
