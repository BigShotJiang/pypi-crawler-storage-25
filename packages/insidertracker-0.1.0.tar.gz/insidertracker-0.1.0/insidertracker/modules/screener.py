import polars as pl
from ..periphery.scraper import get_screener_table


class Screener:
    def get(self, **kwargs) -> pl.DataFrame:
        return get_screener_table(**kwargs)
