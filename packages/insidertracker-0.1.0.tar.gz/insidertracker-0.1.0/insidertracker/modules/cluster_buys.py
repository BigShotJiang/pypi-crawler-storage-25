import datetime as dt
import polars as pl
from .base import BaseLatestModule

CLUSTER_BUYS_COLS = [
    "filing_date",
    "trade_date",
    "ticker",
    "company_name",
    "industry",
    "num_insiders",
    "trade_type",
    "price",
    "quantity",
    "owned",
    "ownership_change",
    "value",
]

CLUSTER_BUYS_PK = ["filing_date", "ticker", "trade_type"]

CLUSTER_BUYS_RENAME_MAP = {
    "Filing Date": "filing_date",
    "Trade Date": "trade_date",
    "Ticker": "ticker",
    "Company Name": "company_name",
    "Industry": "industry",
    "# Insiders": "num_insiders",
    "Trade Type": "trade_type",
    "Price": "price",
    "Qty": "quantity",
    "Owned": "owned",
    "ΔOwn": "ownership_change",
    "Value": "value",
}


class ClusterBuys(BaseLatestModule):
    ENDPOINT = "latest-cluster-buys"
    TABLE_NAME = "cluster_buys"
    COLS = CLUSTER_BUYS_COLS
    PK_COLS = CLUSTER_BUYS_PK
    RENAME_MAP = CLUSTER_BUYS_RENAME_MAP
    DEFAULT_STALE_THRESHOLD = dt.timedelta(days=5)

    def get_cluster_buys(
        self,
        stale_threshold: dt.timedelta = dt.timedelta(days=5),
        force_update: bool = False,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ) -> pl.DataFrame:
        return self.get(
            stale_threshold=stale_threshold,
            force_update=force_update,
            min_date=min_date,
            max_date=max_date,
        )
