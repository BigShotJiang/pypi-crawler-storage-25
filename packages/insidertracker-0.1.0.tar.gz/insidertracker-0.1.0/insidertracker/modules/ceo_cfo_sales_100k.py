import datetime as dt
import polars as pl
from .base import BaseLatestModule, STANDARD_COLS, STANDARD_PK


class CeoCfoSales100k(BaseLatestModule):
    ENDPOINT = "latest-ceo-cfo-sales-100k"
    TABLE_NAME = "ceo_cfo_sales_100k"
    COLS = STANDARD_COLS
    PK_COLS = STANDARD_PK

    def get_ceo_cfo_sales_100k(
        self,
        stale_threshold: dt.timedelta = dt.timedelta(days=1),
        force_update: bool = False,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ) -> pl.DataFrame:
        return self.get(
            stale_threshold=stale_threshold,
            force_update=force_update,
            min_date=min_date,
            max_date=max_date,
        )
