import datetime as dt
import polars as pl
from .base import BaseLatestModule, STANDARD_COLS, STANDARD_PK


class InsiderPurchases(BaseLatestModule):
    ENDPOINT = "insider-purchases"
    TABLE_NAME = "insider_purchases"
    COLS = STANDARD_COLS
    PK_COLS = STANDARD_PK

    def get_insider_purchases(
        self,
        stale_threshold: dt.timedelta = dt.timedelta(days=1),
        force_update: bool = False,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ) -> pl.DataFrame:
        return self.get(
            stale_threshold=stale_threshold,
            force_update=force_update,
            min_date=min_date,
            max_date=max_date,
        )
