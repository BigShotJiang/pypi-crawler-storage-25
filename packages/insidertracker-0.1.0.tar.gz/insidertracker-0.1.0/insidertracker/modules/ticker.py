import re
import polars as pl
import datetime as dt
from ..periphery.db import _init_tables, insert_data
from ..periphery.scraper import scrape_table
from ..periphery.utils import parse_dollar_value, parse_percentage_value

TICKERS_COLS = [
    "filing_date",
    "trade_date",
    "ticker",
    "insider_name",
    "title",
    "trade_type",
    "price",
    "quantity",
    "owned",
    "ownership_change",
    "value",
]

TICKERS_PK = ["filing_date", "ticker", "insider_name", "trade_type"]

ENDPOINT = "search?q={}"


class Ticker:
    def __init__(self):
        self.conn = _init_tables()
        self.table_name = "tickers"

    def get_insider_trades(
        self,
        ticker: list[str],
        stale_threshold: dt.timedelta = dt.timedelta(days=365),
        force_update: bool = False,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ):
        if isinstance(ticker, str):
            ticker = [ticker]
        data = []
        for t in ticker:
            df = self._get(
                ticker=t, stale_threshold=stale_threshold, force_update=force_update,
                min_date=min_date, max_date=max_date,
            )
            data.append(df)
        full_df = pl.concat(data)
        return full_df

    def get_insider_sales(
        self,
        ticker: list[str] | str,
        stale_threshold: dt.timedelta = dt.timedelta(days=365),
        force_update: bool = False,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ) -> pl.DataFrame:
        df = self.get_insider_trades(
            ticker=ticker,
            stale_threshold=stale_threshold,
            force_update=force_update,
            min_date=min_date,
            max_date=max_date,
        )
        return df.filter(pl.col("trade_type").str.contains("(?i)sale"))

    def _get(
        self,
        ticker: str,
        stale_threshold: dt.timedelta = dt.timedelta(days=365),
        force_update: bool = False,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ) -> pl.DataFrame:
        ticker = ticker.upper()
        df = self._read_tickers(ticker)
        if df.is_empty() or force_update:
            df = self.search_ticker(ticker)
            self._insert_tickers(df)
            return self._read_tickers(ticker, min_date=min_date, max_date=max_date)
        today = dt.datetime.now(dt.timezone.utc)
        last_filing_date = self._get_last_filing_date(ticker)
        delta = today - last_filing_date
        if delta > stale_threshold:
            df = self.search_ticker(ticker)
            self._insert_tickers(df)
        return self._read_tickers(ticker, min_date=min_date, max_date=max_date)

    def _read_tickers(
        self,
        ticker: str,
        min_date: dt.datetime | None = None,
        max_date: dt.datetime | None = None,
    ) -> pl.DataFrame:
        query = f"SELECT * FROM {self.table_name} WHERE ticker = ?"
        params = [ticker]
        if min_date is not None:
            query += " AND filing_date > ?"
            params.append(min_date)
        if max_date is not None:
            query += " AND filing_date < ?"
            params.append(max_date)
        return self.conn.execute(query, params).pl()

    def _insert_tickers(self, df: pl.DataFrame):
        insert_data(df, TICKERS_COLS, self.table_name, self.conn, pk_cols=TICKERS_PK)

    def _get_last_filing_date(self, ticker: str):
        result = self.conn.execute(
            f"SELECT MAX(filing_date) FROM {self.table_name} WHERE ticker = ?",
            [ticker],
        ).fetchone()
        return result[0] if result else None

    def search_ticker(self, ticker: str, limit: int = 500) -> pl.DataFrame:
        url = f"http://openinsider.com/screener?s={ticker}&o=&pl=&ph=&ll=&lh=&fd=0&fdr=&td=0&tdr=&fdlyl=&fdlyh=&daysago=&xp=1&xs=1&vl=&vh=&ocl=&och=&sic1=-1&sicl=100&sich=9999&grp=0&nfl=&nfh=&nil=&nih=&nol=&noh=&v2l=&v2h=&oc2l=&oc2h=&sortcol=0&cnt={limit}&page=1"

        # url = f"{BASE_URL}/{ENDPOINT.format(ticker)}"
        df = scrape_table(url, as_dataframe=True)
        df = df.rename({col: re.sub(r"\s+", " ", col).strip() for col in df.columns})
        df = df.rename(
            {
                "Filing Date": "filing_date",
                "Trade Date": "trade_date",
                "Ticker": "ticker",
                "Insider Name": "insider_name",
                "Title": "title",
                "Trade Type": "trade_type",
                "Price": "price",
                "Qty": "quantity",
                "Owned": "owned",
                "ΔOwn": "ownership_change",
                "Value": "value",
            }
        ).drop(["1d", "1w", "1m", "6m"])

        for col in ("price", "value", "quantity", "owned"):
            df = df.with_columns(
                pl.col(col).map_elements(parse_dollar_value, return_dtype=pl.Float64)
            )

        df = df.with_columns(
            pl.col("ownership_change").map_elements(
                parse_percentage_value, return_dtype=pl.Float64
            )
        )

        return df
