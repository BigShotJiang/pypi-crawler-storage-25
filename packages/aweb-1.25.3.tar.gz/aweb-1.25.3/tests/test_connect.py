"""Tests for POST /v1/connect — agent auto-provisioning via team certificate."""

from __future__ import annotations

import uuid

import pytest

from nacl.signing import SigningKey

from awid.did import did_from_public_key


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_keypair():
    sk = SigningKey.generate()
    pk = bytes(sk.verify_key)
    did_key = did_from_public_key(pk)
    return bytes(sk), pk, did_key


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestConnect:
    @pytest.mark.asyncio
    async def test_auto_provisions_team_and_agent(self, aweb_cloud_db):
        from aweb.routes.connect import connect_agent

        db = aweb_cloud_db.aweb_db

        team_sk, _, team_did_key = _make_keypair()
        agent_sk, _, agent_did_key = _make_keypair()

        cert_info = {
            "team_id": "backend:acme.com",
            "alias": "alice",
            "did_key": agent_did_key,
            "identity_scope": "global",
            "certificate_id": "cert-001",
        }

        result = await connect_agent(
            db=db,
            cert_info=cert_info,
            team_did_key=team_did_key,
            hostname="Mac.local",
            workspace_path="/Users/alice/project",
            repo_origin="https://github.com/acme/backend.git",
            role="developer",
            human_name="Alice",
            agent_type="agent",
        )

        assert result["team_id"] == "backend:acme.com"
        assert result["alias"] == "alice"
        assert result["role"] == "developer"
        assert result["agent_id"] is not None
        assert result["workspace_id"] is not None

        # Verify team row was created
        team = await db.fetch_one(
            "SELECT * FROM {{tables.teams}} WHERE team_id = $1",
            "backend:acme.com",
        )
        assert team is not None
        assert team["team_did_key"] == team_did_key
        assert team["namespace"] == "acme.com"
        assert team["team_name"] == "backend"

        # Verify agent row was created
        agent = await db.fetch_one(
            "SELECT * FROM {{tables.agents}} WHERE agent_id = $1",
            uuid.UUID(result["agent_id"]),
        )
        assert agent is not None
        assert agent["alias"] == "alice"
        assert agent["did_key"] == agent_did_key
        assert agent["identity_scope"] == "global"

    @pytest.mark.asyncio
    async def test_idempotent_reconnect(self, aweb_cloud_db):
        from aweb.routes.connect import connect_agent

        db = aweb_cloud_db.aweb_db

        team_sk, _, team_did_key = _make_keypair()
        _, _, agent_did_key = _make_keypair()

        cert_info = {
            "team_id": "backend:acme.com",
            "alias": "alice",
            "did_key": agent_did_key,
            "identity_scope": "global",
            "certificate_id": "cert-001",
        }

        kwargs = dict(
            db=db,
            cert_info=cert_info,
            team_did_key=team_did_key,
            hostname="Mac.local",
            workspace_path="/Users/alice/project",
            repo_origin="",
            role="developer",
            human_name="",
            agent_type="agent",
        )

        result1 = await connect_agent(**kwargs)
        result2 = await connect_agent(**kwargs)

        assert result1["agent_id"] == result2["agent_id"]
        assert result1["team_id"] == result2["team_id"]
        assert result1["workspace_id"] == result2["workspace_id"]

    @pytest.mark.asyncio
    async def test_team_id_parsed_correctly(self, aweb_cloud_db):
        from aweb.routes.connect import connect_agent

        db = aweb_cloud_db.aweb_db

        team_sk, _, team_did_key = _make_keypair()
        _, _, agent_did_key = _make_keypair()

        cert_info = {
            "team_id": "frontend:example.org",
            "alias": "bob",
            "did_key": agent_did_key,
            "identity_scope": "local",
            "certificate_id": "cert-002",
        }

        result = await connect_agent(
            db=db,
            cert_info=cert_info,
            team_did_key=team_did_key,
            hostname="",
            workspace_path="",
            repo_origin="",
            role="",
            human_name="",
            agent_type="agent",
        )

        team = await db.fetch_one(
            "SELECT * FROM {{tables.teams}} WHERE team_id = $1",
            "frontend:example.org",
        )
        assert team["namespace"] == "example.org"
        assert team["team_name"] == "frontend"

    @pytest.mark.asyncio
    async def test_persistent_cert_populates_did_aw_and_address(self, aweb_cloud_db):
        from aweb.routes.connect import connect_agent

        db = aweb_cloud_db.aweb_db

        _, _, team_did_key = _make_keypair()
        _, _, agent_did_key = _make_keypair()

        cert_info = {
            "team_id": "backend:acme.com",
            "alias": "alice",
            "did_key": agent_did_key,
            "identity_scope": "global",
            "certificate_id": "cert-persistent-001",
            "member_did_aw": "did:aw:z6Mkstable",
            "member_address": "acme.com/alice",
        }

        result = await connect_agent(
            db=db,
            cert_info=cert_info,
            team_did_key=team_did_key,
            hostname="Mac.local",
            workspace_path="/Users/alice/project",
            repo_origin="",
            role="developer",
            human_name="Alice",
            agent_type="agent",
        )

        agent = await db.fetch_one(
            "SELECT did_aw, address FROM {{tables.agents}} WHERE agent_id = $1",
            uuid.UUID(result["agent_id"]),
        )
        assert agent["did_aw"] == "did:aw:z6Mkstable"
        assert agent["address"] == "acme.com/alice"

    @pytest.mark.asyncio
    async def test_ephemeral_cert_leaves_did_aw_and_address_null(self, aweb_cloud_db):
        from aweb.routes.connect import connect_agent

        db = aweb_cloud_db.aweb_db

        _, _, team_did_key = _make_keypair()
        _, _, agent_did_key = _make_keypair()

        cert_info = {
            "team_id": "backend:acme.com",
            "alias": "alice",
            "did_key": agent_did_key,
            "identity_scope": "local",
            "certificate_id": "cert-ephemeral-001",
            "member_did_aw": "",
            "member_address": "",
        }

        result = await connect_agent(
            db=db,
            cert_info=cert_info,
            team_did_key=team_did_key,
            hostname="",
            workspace_path="",
            repo_origin="",
            role="",
            human_name="",
            agent_type="agent",
        )

        agent = await db.fetch_one(
            "SELECT did_aw, address FROM {{tables.agents}} WHERE agent_id = $1",
            uuid.UUID(result["agent_id"]),
        )
        assert agent["did_aw"] is None
        assert agent["address"] is None

    @pytest.mark.asyncio
    async def test_workspace_created_with_repo(self, aweb_cloud_db):
        from aweb.routes.connect import connect_agent

        db = aweb_cloud_db.aweb_db

        _, _, team_did_key = _make_keypair()
        _, _, agent_did_key = _make_keypair()

        cert_info = {
            "team_id": "backend:acme.com",
            "alias": "alice",
            "did_key": agent_did_key,
            "identity_scope": "global",
            "certificate_id": "cert-001",
        }

        result = await connect_agent(
            db=db,
            cert_info=cert_info,
            team_did_key=team_did_key,
            hostname="Mac.local",
            workspace_path="/Users/alice/project",
            repo_origin="https://github.com/acme/backend.git",
            role="developer",
            human_name="Alice",
            agent_type="agent",
        )

        workspace = await db.fetch_one(
            "SELECT * FROM {{tables.workspaces}} WHERE workspace_id = $1",
            uuid.UUID(result["workspace_id"]),
        )
        assert workspace is not None
        assert workspace["hostname"] == "Mac.local"
        assert workspace["workspace_path"] == "/Users/alice/project"
        assert workspace["alias"] == "alice"
