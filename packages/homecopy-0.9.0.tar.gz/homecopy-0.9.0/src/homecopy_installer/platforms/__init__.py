"""Platform-specific installer helpers."""
