# pmon — 跨平台进程监控工具

跨平台进程资源监控命令行工具，支持 macOS / Linux / Windows。

## 安装

```bash
pip install psutil
pip install .
```

或直接从 PyPI 安装（发布后）：

```bash
pip install pmon
```

## 用法

```bash
pmon                          # 进程列表（按 CPU 降序，top 30）
pmon -n 50                    # 显示 top 50
pmon -f chrome                # 按名称/PID/用户过滤
pmon -s mem                   # 排序: cpu|mem|rss|pid|name|threads|fds
pmon -w                       # watch 模式，每 3 秒刷新
pmon -w -i 5                  # 自定义刷新间隔（秒）
pmon -p 1234                  # 查看指定 PID 的详细信息
pmon -p 1234 --tree           # 显示进程树（含子进程）
pmon -p 1234 --ancestry       # 只显示祖先链
pmon -p 1234 --json           # JSON 输出
pmon -p 1234 --warnings       # 只显示告警
pmon --port 8080              # 按端口反查进程
pmon --file /tmp/x.lock       # 按文件路径反查持有进程
pmon --kill 1234              # 发送 SIGTERM
pmon --kill 1234 -9           # 发送 SIGKILL
pmon --pause 1234             # 暂停进程 (SIGSTOP)
pmon --resume 1234            # 恢复进程 (SIGCONT)
pmon --renice 1234 10         # 调整优先级 (-20~19)
pmon --no-color               # 禁用颜色输出
```

## 显示信息

### 进程列表
PID、进程名、用户、状态、CPU%、内存%、RSS(MB)、线程数、FD数、启动时间

### 详情页（`-p <PID>`）
- **概览**：进程名、PID、父进程 ID/路径、可执行路径、工作目录、启动命令、启动用户、状态、启动时间、已运行时长、优先级、终端
- **祖先链 & 起源**：完整启动链路 + 自动检测起源类型（shell/ssh/launchd/systemd/cron/container）
- **告警**：僵尸进程、高内存/CPU、root 运行、可疑目录、环境变量注入、公网绑定等
- **资源占用**：CPU/内存/磁盘 I/O/上下文切换
- **内存详情**：macOS 显示 memory_full_info，Linux 显示内存映射表
- **打开的文件**、**网络连接/端口**、**线程**、**环境变量**

## 依赖

- Python >= 3.8
- psutil >= 5.9

## 许可证

MIT
