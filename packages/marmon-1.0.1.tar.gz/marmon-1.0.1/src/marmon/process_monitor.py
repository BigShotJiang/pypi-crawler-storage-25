#!/usr/bin/env python3
"""
marmon — 跨平台进程资源监控工具
依赖: pip install marmon
平台: macOS / Linux / Windows

用法:
  marmon                          # 进程列表（按 CPU 降序，top 30）
  marmon -n 50                    # 显示 top 50
  marmon -f chrome                # 按名称/PID/用户过滤
  marmon -s mem                   # 排序字段: cpu|mem|rss|pid|name|threads|fds
  marmon -w                       # watch 模式，每 3 秒刷新
  marmon -w -i 5                  # 自定义刷新间隔（秒）
  marmon -p 1234                  # 查看指定 PID 的详细信息
  marmon -p 1234 --tree           # 显示进程树（含子进程）
  marmon -p 1234 --ancestry       # 只显示祖先链
  marmon -p 1234 --json           # JSON 输出
  marmon -p 1234 --warnings       # 只显示告警
  marmon --port 8080              # 按端口反查进程
  marmon --file /tmp/x.lock       # 按文件路径反查持有进程
  marmon --kill 1234              # 发送 SIGTERM
  marmon --kill 1234 -9           # 发送 SIGKILL
  marmon --pause 1234             # 暂停进程 (SIGSTOP)
  marmon --resume 1234            # 恢复进程 (SIGCONT)
  marmon --renice 1234 10         # 调整优先级 (-20~19)
  marmon --no-color               # 禁用颜色输出
"""

import argparse
import json
import os
import platform
import shutil
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime, timedelta

import psutil

# ──────────────────────────────────────────────────────────────────────────────
# 终端工具
# ──────────────────────────────────────────────────────────────────────────────

IS_WIN  = platform.system() == "Windows"
IS_MAC  = platform.system() == "Darwin"
IS_LIN  = platform.system() == "Linux"

# 颜色开关（--no-color 或 NO_COLOR 环境变量）
_USE_COLOR = True

def disable_color():
    global _USE_COLOR
    _USE_COLOR = False

def _c(code, text):
    if not _USE_COLOR:
        return text
    return f"\033[{code}m{text}\033[0m"

def bold(t):   return _c("1",  t)
def green(t):  return _c("32", t)
def yellow(t): return _c("33", t)
def red(t):    return _c("31", t)
def cyan(t):   return _c("36", t)
def magenta(t):return _c("35", t)
def dim(t):    return _c("2",  t)

def term_width():
    return shutil.get_terminal_size((120, 40)).columns

def clear_screen():
    os.system("cls" if IS_WIN else "clear")

# ──────────────────────────────────────────────────────────────────────────────
# 格式化工具
# ──────────────────────────────────────────────────────────────────────────────

def safe(fn, default="N/A"):
    try:
        v = fn()
        return v if v is not None else default
    except Exception:
        return default

def fmt_bytes(n):
    if not isinstance(n, (int, float)):
        return "N/A"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"

def fmt_mb(n):
    return f"{n / 1024**2:.1f}" if isinstance(n, (int, float)) else "N/A"

def fmt_time(ts):
    try:
        return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "N/A"

def fmt_uptime(ts):
    """返回进程已运行时间，如 '3d 2h 15m'"""
    try:
        delta = datetime.now() - datetime.fromtimestamp(ts)
        d = delta.days
        h, rem = divmod(delta.seconds, 3600)
        m, _ = divmod(rem, 60)
        if d:
            return f"{d}d {h}h {m}m"
        elif h:
            return f"{h}h {m}m"
        else:
            return f"{m}m"
    except Exception:
        return "N/A"

def conn_proto(conn):
    family = {socket.AF_INET: "IPv4", socket.AF_INET6: "IPv6",
              socket.AF_UNIX: "Unix"}.get(conn.family, "?")
    kind   = {socket.SOCK_STREAM: "TCP", socket.SOCK_DGRAM: "UDP"}.get(conn.type, "?")
    return f"{family}/{kind}"

def trunc(s, n):
    s = str(s)
    return s if len(s) <= n else s[:n - 1] + "…"

def ljust(s, n):
    s = str(s)
    width = sum(2 if ord(c) > 127 else 1 for c in s)
    pad = max(0, n - width)
    return s + " " * pad

def rjust(s, n):
    s = str(s)
    width = sum(2 if ord(c) > 127 else 1 for c in s)
    pad = max(0, n - width)
    return " " * pad + s

# ──────────────────────────────────────────────────────────────────────────────
# 数据采集
# ──────────────────────────────────────────────────────────────────────────────

FETCH_ATTRS = [
    "pid", "name", "username", "status",
    "cpu_percent", "memory_percent", "memory_info",
    "num_threads", "create_time",
]

def fetch_processes():
    # 先采样设置 CPU 基准
    try:
        list(psutil.process_iter(["pid", "cpu_percent"]))
    except Exception:
        pass
    time.sleep(0.5)

    result = []
    for p in psutil.process_iter(FETCH_ATTRS):
        try:
            i = p.info
            mem_rss = i["memory_info"].rss if i.get("memory_info") else 0
            fds = safe(lambda: p.num_fds() if hasattr(p, "num_fds") else 0, 0)
            result.append({
                "pid":     i["pid"],
                "name":    i.get("name") or "",
                "user":    (i.get("username") or "").split("\\")[-1],
                "status":  i.get("status") or "",
                "cpu":     i.get("cpu_percent") or 0.0,
                "mem_pct": i.get("memory_percent") or 0.0,
                "mem_rss": mem_rss,
                "threads": i.get("num_threads") or 0,
                "fds":     fds,
                "started": fmt_time(i["create_time"]) if i.get("create_time") else "",
                "create_time": i.get("create_time") or 0,
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    return result

SORT_KEYS = {
    "cpu":     lambda p: p["cpu"],
    "mem":     lambda p: p["mem_pct"],
    "rss":     lambda p: p["mem_rss"],
    "pid":     lambda p: p["pid"],
    "name":    lambda p: p["name"].lower(),
    "threads": lambda p: p["threads"],
    "fds":     lambda p: p["fds"],
}

# ──────────────────────────────────────────────────────────────────────────────
# 祖先链构建
# ──────────────────────────────────────────────────────────────────────────────

def get_ancestry(pid: int) -> list:
    """返回 [root, ..., parent, target] 有序祖先链"""
    chain = []
    seen = set()
    current = pid
    while current and current not in seen:
        seen.add(current)
        try:
            p = psutil.Process(current)
            info = {
                "pid":  p.pid,
                "name": safe(p.name, "?"),
                "exe":  safe(p.exe, ""),
                "cmdline": safe(lambda: " ".join(p.cmdline()), ""),
                "user": safe(p.username, ""),
                "status": safe(p.status, ""),
                "create_time": safe(p.create_time, 0),
            }
            chain.append(info)
            ppid = safe(p.ppid, 0)
            if ppid == 0 or ppid == current:
                break
            current = ppid
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            break
    chain.reverse()
    return chain

def get_children(pid: int, recursive=True) -> list:
    """返回所有子进程（递归）"""
    try:
        p = psutil.Process(pid)
        return p.children(recursive=recursive)
    except Exception:
        return []

def render_tree(pid: int, prefix="", is_last=True, depth=0) -> list:
    """递归渲染进程树，返回行列表"""
    lines = []
    try:
        p = psutil.Process(pid)
        name = safe(p.name, "?")
        connector = "└─ " if is_last else "├─ "
        cpu = safe(lambda: f"{p.cpu_percent(interval=0):.1f}%", "")
        mem = safe(lambda: f"{p.memory_percent():.1f}%", "")
        lines.append(f"{prefix}{connector}{bold(name)} ({pid}) {dim(f'cpu={cpu} mem={mem}')}")
        children = safe(lambda: p.children(), [])
        child_prefix = prefix + ("   " if is_last else "│  ")
        for i, child in enumerate(children):
            last = (i == len(children) - 1)
            lines.extend(render_tree(child.pid, child_prefix, last, depth + 1))
    except Exception:
        pass
    return lines

# ──────────────────────────────────────────────────────────────────────────────
# 起源检测
# ──────────────────────────────────────────────────────────────────────────────

SHELL_NAMES = {
    "bash", "zsh", "sh", "fish", "csh", "tcsh", "ksh", "dash",
    "cmd.exe", "powershell.exe", "pwsh.exe", "explorer.exe",
}
CONTAINER_RUNTIMES = {
    "docker", "containerd", "containerd-shim", "podman", "crio",
    "runc", "kata-runtime", "nerdctl",
}
SUPERVISOR_NAMES = {"supervisord", "supervisor", "circus", "honcho", "foreman"}

def detect_source(ancestry: list) -> dict:
    """
    检测进程的来源类型。
    返回 {"type": ..., "name": ..., "description": ...}
    优先级: container > ssh > shell > launchd > systemd > cron > supervisor > init > unknown
    """
    names = [a["name"].lower() for a in ancestry]
    exes  = [a.get("exe", "").lower() for a in ancestry]

    # 1. 容器运行时
    for i, n in enumerate(names):
        for rt in CONTAINER_RUNTIMES:
            if rt in n:
                return {"type": "container", "name": n,
                        "description": f"在容器运行时 {n} 中运行"}

    # 2. SSH
    for i, n in enumerate(names):
        if "sshd" in n:
            # 尝试从目标进程的环境变量中提取 SSH_CLIENT
            try:
                target = psutil.Process(ancestry[-1]["pid"])
                env = target.environ()
                ssh_client = env.get("SSH_CLIENT", env.get("SSH_CONNECTION", ""))
                remote_ip = ssh_client.split()[0] if ssh_client else "unknown"
                user = ancestry[-1].get("user", "")
                return {"type": "ssh", "name": "sshd",
                        "description": f"SSH 远程登录，来源 {remote_ip}，用户 {user}"}
            except Exception:
                return {"type": "ssh", "name": "sshd",
                        "description": "SSH 远程会话"}

    # 3. Shell / 终端复用器
    for i, n in enumerate(names):
        if n in SHELL_NAMES:
            # 检测 tmux / screen
            try:
                target = psutil.Process(ancestry[-1]["pid"])
                env = target.environ()
                if "TMUX" in env:
                    tmux_session = env["TMUX"].split(",")[0].split("/")[-1]
                    return {"type": "shell", "name": n,
                            "description": f"在 tmux 会话 '{tmux_session}' 中的 {n} 启动"}
                if "STY" in env:
                    screen_session = env["STY"].split(".", 1)[-1] if "." in env["STY"] else env["STY"]
                    return {"type": "shell", "name": n,
                            "description": f"在 GNU screen 会话 '{screen_session}' 中的 {n} 启动"}
            except Exception:
                pass
            return {"type": "shell", "name": n,
                    "description": f"由交互式 shell {n} 启动"}

    # 4. launchd（macOS）
    if IS_MAC:
        for i, n in enumerate(names):
            if n == "launchd":
                proc_name = ancestry[-1]["name"]
                # 尝试 launchctl 查询
                label = _launchd_label(ancestry[-1]["pid"])
                if label:
                    return {"type": "launchd", "name": label,
                            "description": f"launchd 服务: {label}"}
                return {"type": "launchd", "name": "launchd",
                        "description": f"由 launchd 管理的系统/用户服务"}

    # 5. systemd（Linux）
    if IS_LIN:
        if os.path.exists("/run/systemd/system"):
            unit = _systemd_unit(ancestry[-1]["pid"])
            if unit:
                return {"type": "systemd", "name": unit,
                        "description": f"systemd 服务单元: {unit}"}
            if any("systemd" in n for n in names):
                return {"type": "systemd", "name": "systemd",
                        "description": "由 systemd 管理"}

    # 6. cron
    for n in names:
        if "cron" in n:
            return {"type": "cron", "name": n,
                    "description": f"由 cron 调度程序 ({n}) 定时触发"}

    # 7. supervisor
    for n in names:
        if n in SUPERVISOR_NAMES:
            return {"type": "supervisor", "name": n,
                    "description": f"由进程管理器 {n} 监控"}

    # 8. init / PID 1
    if len(ancestry) >= 1 and ancestry[0]["pid"] == 1:
        init_name = ancestry[0]["name"]
        return {"type": "init", "name": init_name,
                "description": f"由 init 进程 ({init_name}, PID 1) 派生"}

    return {"type": "unknown", "name": "?",
            "description": "无法确定起源（可能是孤儿进程或权限不足）"}

def _launchd_label(pid: int) -> str:
    """尝试通过 launchctl 查找进程对应的 label"""
    try:
        out = subprocess.check_output(
            ["launchctl", "list"], stderr=subprocess.DEVNULL, timeout=3
        ).decode(errors="replace")
        for line in out.splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[0] == str(pid):
                return parts[2]
    except Exception:
        pass
    return ""

def _systemd_unit(pid: int) -> str:
    """从 /proc/[pid]/cgroup 提取 systemd unit 名"""
    try:
        with open(f"/proc/{pid}/cgroup") as f:
            for line in f:
                if ".service" in line:
                    # 提取 xxx.service
                    parts = line.strip().split("/")
                    for part in reversed(parts):
                        if part.endswith(".service"):
                            return part
    except Exception:
        pass
    return ""

# ──────────────────────────────────────────────────────────────────────────────
# 告警系统
# ──────────────────────────────────────────────────────────────────────────────

WARN_OLD_DAYS = 90   # 运行超过 N 天告警
WARN_HIGH_MEM = 1024 * 1024 * 1024  # RSS > 1GB
WARN_HIGH_CPU_HOURS = 2              # 累计 CPU > 2 小时

SUSPICIOUS_DIRS = {"/", "/tmp", "/var/tmp", "/dev/shm"}
DANGEROUS_ENV   = {"LD_PRELOAD"}     # Linux 注入
DANGEROUS_ENV_PREFIX = {"DYLD_"}     # macOS 注入

def check_warnings(pid: int, proc=None, ancestry=None) -> list:
    """
    检查进程告警，返回告警字符串列表。
    """
    warnings = []
    if proc is None:
        try:
            proc = psutil.Process(pid)
        except Exception:
            return warnings

    # 僵尸进程
    try:
        if proc.status() == psutil.STATUS_ZOMBIE:
            warnings.append("⚠ 僵尸进程 (zombie)：进程已退出但父进程未回收")
    except Exception:
        pass

    # 停止进程
    try:
        if proc.status() == psutil.STATUS_STOPPED:
            warnings.append("⚠ 进程已暂停 (stopped/SIGSTOP)")
    except Exception:
        pass

    # 高内存
    try:
        mem = proc.memory_info()
        if mem.rss > WARN_HIGH_MEM:
            warnings.append(f"⚠ 内存占用过高: RSS = {fmt_bytes(mem.rss)}（阈值 1 GB）")
    except Exception:
        pass

    # 高 CPU 累计时间
    try:
        cpu_t = proc.cpu_times()
        total_cpu = cpu_t.user + cpu_t.system
        if total_cpu > WARN_HIGH_CPU_HOURS * 3600:
            warnings.append(f"⚠ 累计 CPU 时间过高: {total_cpu/3600:.1f}h（阈值 {WARN_HIGH_CPU_HOURS}h）")
    except Exception:
        pass

    # 运行时间过长
    try:
        ct = proc.create_time()
        age_days = (time.time() - ct) / 86400
        if age_days > WARN_OLD_DAYS:
            warnings.append(f"⚠ 进程运行时间过长: {int(age_days)} 天（阈值 {WARN_OLD_DAYS} 天）")
    except Exception:
        pass

    # root 运行
    try:
        if proc.username() in ("root", "SYSTEM", "NT AUTHORITY\\SYSTEM"):
            warnings.append("⚠ 以高权限账户运行 (root / SYSTEM)")
    except Exception:
        pass

    # 可疑工作目录
    try:
        cwd = proc.cwd()
        if cwd in SUSPICIOUS_DIRS:
            warnings.append(f"⚠ 可疑工作目录: {cwd}")
    except Exception:
        pass

    # 二进制已被删除（仅 Linux）
    try:
        exe = proc.exe()
        if exe.endswith(" (deleted)") or "(deleted)" in exe:
            warnings.append(f"⚠ 可执行文件已被删除: {exe}")
    except Exception:
        pass

    # 公网绑定
    try:
        get_conns = (proc.net_connections
                     if hasattr(proc, "net_connections")
                     else proc.connections)
        for c in get_conns(kind="inet"):
            if hasattr(c.laddr, "ip"):
                ip = c.laddr.ip
                state = getattr(c, "status", "")
                if ip in ("0.0.0.0", "::") and state in ("LISTEN", ""):
                    warnings.append(
                        f"⚠ 公网绑定端口: {c.laddr.port} ({conn_proto(c)}) — 监听所有网络接口")
                    break
    except Exception:
        pass

    # 环境变量注入检测
    try:
        env = proc.environ()
        for key in DANGEROUS_ENV:
            if key in env and env[key]:
                warnings.append(f"⚠ 危险环境变量 {key}={env[key][:80]}")
        for key in env:
            for prefix in DANGEROUS_ENV_PREFIX:
                if key.startswith(prefix):
                    warnings.append(f"⚠ 可疑 macOS 注入变量 {key}={env[key][:60]}")
                    break
    except Exception:
        pass

    # 祖先链中同一命令出现多次（重启循环）
    if ancestry:
        name_counts: dict = {}
        for a in ancestry:
            n = a["name"]
            name_counts[n] = name_counts.get(n, 0) + 1
        for n, cnt in name_counts.items():
            if cnt > 5:
                warnings.append(f"⚠ 可能的重启循环：祖先链中 '{n}' 出现 {cnt} 次")

    return warnings

# ──────────────────────────────────────────────────────────────────────────────
# 端口 / 文件反查
# ──────────────────────────────────────────────────────────────────────────────

def find_by_port(port: int) -> list:
    """返回持有该端口的 PID 列表（macOS/Linux/Windows 均支持）"""
    pids = []
    try:
        # psutil >= 5.8 支持 psutil.net_connections
        get_conns = (psutil.net_connections
                     if hasattr(psutil, "net_connections")
                     else psutil.net_connections)
        for c in get_conns(kind="inet"):
            if hasattr(c.laddr, "port") and c.laddr.port == port:
                if c.pid and c.pid not in pids:
                    pids.append(c.pid)
    except Exception:
        pass

    # macOS 备用：lsof
    if not pids and IS_MAC:
        try:
            out = subprocess.check_output(
                ["lsof", "-i", f":{port}", "-n", "-P", "-F", "p"],
                stderr=subprocess.DEVNULL, timeout=5
            ).decode(errors="replace")
            for line in out.splitlines():
                if line.startswith("p"):
                    try:
                        pid = int(line[1:])
                        if pid not in pids:
                            pids.append(pid)
                    except ValueError:
                        pass
        except Exception:
            pass
    return pids

def find_by_file(filepath: str) -> list:
    """返回持有该文件的 PID 列表"""
    real_path = os.path.realpath(filepath)
    pids = []

    # Linux：遍历 /proc/[pid]/fd
    if IS_LIN:
        try:
            for entry in os.listdir("/proc"):
                if not entry.isdigit():
                    continue
                fd_dir = f"/proc/{entry}/fd"
                try:
                    for fd in os.listdir(fd_dir):
                        link = os.readlink(os.path.join(fd_dir, fd))
                        if link == real_path:
                            pid = int(entry)
                            if pid not in pids:
                                pids.append(pid)
                            break
                except Exception:
                    continue
        except Exception:
            pass

    # macOS/通用：psutil open_files
    if not pids:
        for p in psutil.process_iter(["pid"]):
            try:
                for f in p.open_files():
                    if os.path.realpath(f.path) == real_path:
                        if p.pid not in pids:
                            pids.append(p.pid)
                        break
            except Exception:
                continue

    # macOS 备用：lsof
    if not pids and IS_MAC:
        try:
            out = subprocess.check_output(
                ["lsof", filepath, "-F", "p"],
                stderr=subprocess.DEVNULL, timeout=5
            ).decode(errors="replace")
            for line in out.splitlines():
                if line.startswith("p"):
                    try:
                        pid = int(line[1:])
                        if pid not in pids:
                            pids.append(pid)
                    except ValueError:
                        pass
        except Exception:
            pass

    return pids

# ──────────────────────────────────────────────────────────────────────────────
# 进程列表输出
# ──────────────────────────────────────────────────────────────────────────────

LIST_COLS = [
    ("pid",     "PID",      7,  "r"),
    ("name",    "进程名",  22,  "l"),
    ("user",    "用户",    12,  "l"),
    ("status",  "状态",     9,  "l"),
    ("cpu",     "CPU%",     6,  "r"),
    ("mem_pct", "MEM%",     6,  "r"),
    ("mem_rss", "RSS(MB)",  9,  "r"),
    ("threads", "线程",     5,  "r"),
    ("fds",     "FD",       5,  "r"),
    ("started", "启动时间",19,  "l"),
]

STATUS_COLOR = {
    "running":  green,
    "sleeping": dim,
    "zombie":   red,
    "stopped":  yellow,
    "idle":     dim,
}

def color_status(status):
    fn = STATUS_COLOR.get(status, lambda x: x)
    return fn(status)

def render_list(procs, sort_by="cpu", filter_q="", top_n=30):
    q = filter_q.lower()
    if q:
        procs = [p for p in procs
                 if q in p["name"].lower()
                 or q in str(p["pid"])
                 or q in p["user"].lower()]

    key_fn = SORT_KEYS.get(sort_by, SORT_KEYS["cpu"])
    procs.sort(key=key_fn, reverse=(sort_by != "name"))
    procs = procs[:top_n]

    w = term_width()
    sep = dim("─" * w)
    lines = []
    lines.append(bold(cyan(
        f"  Process Monitor  —  {datetime.now().strftime('%H:%M:%S')}  "
        f"({len(procs)} shown, sort={sort_by})"
    )))
    lines.append(sep)

    header = ""
    for key, title, width, align in LIST_COLS:
        cell = trunc(title, width)
        header += (rjust(cell, width) if align == "r" else ljust(cell, width)) + "  "
    lines.append(bold(header))
    lines.append(sep)

    for p in procs:
        row = ""
        for key, _, width, align in LIST_COLS:
            if key == "cpu":
                raw  = f"{p['cpu']:.1f}"
                cell = rjust(trunc(raw, width), width)
                if p["cpu"] > 50:   cell = red(cell)
                elif p["cpu"] > 10: cell = yellow(cell)
            elif key == "mem_pct":
                raw  = f"{p['mem_pct']:.1f}"
                cell = rjust(trunc(raw, width), width)
                if p["mem_pct"] > 20: cell = red(cell)
            elif key == "mem_rss":
                cell = rjust(trunc(fmt_mb(p["mem_rss"]), width), width)
            elif key == "status":
                cell = ljust(trunc(color_status(p["status"]), width + 20), width + 20)
                row += cell + "  "
                continue
            elif align == "r":
                cell = rjust(trunc(str(p[key]), width), width)
            else:
                cell = ljust(trunc(str(p[key]), width), width)
            row += cell + "  "
        lines.append(row)

    lines.append(sep)
    lines.append(dim(
        "  Ctrl+C 退出  |  -p <PID> 查看详情  |  -f <关键词> 过滤  |  "
        "--port <端口> 反查  |  --file <路径> 反查"
    ))
    return "\n".join(lines)

# ──────────────────────────────────────────────────────────────────────────────
# 进程详情输出
# ──────────────────────────────────────────────────────────────────────────────

def section(title):
    w = term_width()
    bar = "─" * max(0, w - len(title) - 4)
    return bold(cyan(f"\n┌─ {title} {bar}"))

def kv(label, value, label_w=24):
    return f"  {bold(ljust(label, label_w))}  {value}"

def print_detail(pid: int, show_tree=False, show_ancestry_only=False,
                 as_json=False, warnings_only=False):
    try:
        proc = psutil.Process(pid)
    except psutil.NoSuchProcess:
        print(red(f"进程 {pid} 不存在"))
        sys.exit(2)

    # 先设置 CPU 基准
    try:
        proc.cpu_percent()
    except Exception:
        pass

    # 构建祖先链
    ancestry = get_ancestry(pid)
    source   = detect_source(ancestry)
    warnings = check_warnings(pid, proc, ancestry)

    # ── JSON 模式 ─────────────────────────────────────────────────────────────
    if as_json:
        data = {
            "pid":      pid,
            "name":     safe(proc.name),
            "user":     safe(proc.username),
            "status":   safe(proc.status),
            "exe":      safe(proc.exe),
            "cwd":      safe(proc.cwd),
            "cmdline":  safe(lambda: " ".join(proc.cmdline()), ""),
            "started":  safe(lambda: fmt_time(proc.create_time())),
            "uptime":   safe(lambda: fmt_uptime(proc.create_time())),
            "ancestry": [{"pid": a["pid"], "name": a["name"], "exe": a["exe"]}
                         for a in ancestry],
            "source":   source,
            "warnings": warnings,
            "cpu_percent": safe(lambda: proc.cpu_percent(interval=0.5), 0),
            "memory": {
                "rss": safe(lambda: proc.memory_info().rss, 0),
                "vms": safe(lambda: proc.memory_info().vms, 0),
            },
        }
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return

    # ── 只显示告警 ────────────────────────────────────────────────────────────
    if warnings_only:
        name = safe(proc.name)
        print(bold(cyan(f"\n  告警报告  —  {name} (PID {pid})")))
        if warnings:
            for w in warnings:
                print(f"  {red(w)}")
        else:
            print(f"  {green('✓ 未检测到告警')}")
        print()
        return

    # ── 只显示祖先链 ──────────────────────────────────────────────────────────
    if show_ancestry_only:
        chain_str = " → ".join(
            f"{bold(a['name'])} ({dim(str(a['pid']))})" for a in ancestry
        )
        print(f"\n  {chain_str}\n")
        return

    # ── 完整详情 ──────────────────────────────────────────────────────────────
    print(bold(cyan(
        f"\n  进程详情  —  PID {pid}  —  {datetime.now().strftime('%H:%M:%S')}"
    )))

    # 概览
    print(section("概览"))
    ppid = safe(proc.ppid)
    parent_path = "N/A"
    try:
        parent_path = psutil.Process(ppid).exe()
    except Exception:
        pass

    uptime = safe(lambda: fmt_uptime(proc.create_time()), "N/A")
    for label, value in [
        ("进程名称",       safe(proc.name)),
        ("进程 ID (PID)",  pid),
        ("父进程 ID",      ppid),
        ("父进程路径",     parent_path),
        ("可执行文件路径", safe(proc.exe)),
        ("工作目录 (CWD)", safe(proc.cwd)),
        ("启动命令",       safe(lambda: " ".join(proc.cmdline()), "N/A")),
        ("启动用户",       safe(proc.username)),
        ("进程状态",       color_status(safe(proc.status))),
        ("启动时间",       safe(lambda: fmt_time(proc.create_time()))),
        ("已运行时长",     uptime),
        ("优先级 (nice)",  safe(proc.nice)),
        ("终端",           safe(lambda: proc.terminal() or "无")),
    ]:
        print(kv(label, value))

    # 祖先链 + 起源
    print(section("祖先链 & 起源"))
    chain_str = " → ".join(
        f"{bold(a['name'])} ({dim(str(a['pid']))})" for a in ancestry
    )
    print(f"  {chain_str}")
    print()
    src_color = {
        "shell": cyan, "ssh": magenta, "launchd": green,
        "systemd": green, "container": yellow, "cron": yellow,
        "init": dim, "unknown": red,
    }.get(source["type"], lambda x: x)
    print(kv("起源类型",   src_color(source["type"])))
    print(kv("起源名称",   source["name"]))
    print(kv("起源说明",   source["description"]))

    # 告警
    if warnings:
        print(section("⚠ 告警"))
        for w in warnings:
            print(f"  {red(w)}")

    # 资源占用
    print(section("资源占用"))
    mem   = safe(proc.memory_info)
    cpu_t = safe(proc.cpu_times)
    ctx   = safe(proc.num_ctx_switches)
    io    = safe(lambda: proc.io_counters() if hasattr(proc, "io_counters") else None)
    cpu_pct = safe(lambda: f"{proc.cpu_percent(interval=0.5):.1f} %")

    for label, value in [
        ("CPU 使用率",         cpu_pct),
        ("CPU 用户态时间",     f"{cpu_t.user:.2f} s"   if cpu_t != "N/A" else "N/A"),
        ("CPU 内核态时间",     f"{cpu_t.system:.2f} s" if cpu_t != "N/A" else "N/A"),
        ("内存 RSS",           fmt_bytes(mem.rss)  if mem != "N/A" else "N/A"),
        ("内存 VMS",           fmt_bytes(mem.vms)  if mem != "N/A" else "N/A"),
        ("内存共享",           fmt_bytes(getattr(mem, "shared", None)) if mem != "N/A" else "N/A"),
        ("内存占比",           safe(lambda: f"{proc.memory_percent():.2f} %")),
        ("线程数",             safe(proc.num_threads)),
        ("文件描述符数",       safe(lambda: proc.num_fds() if hasattr(proc, "num_fds") else "N/A")),
        ("上下文切换 (自愿)",  ctx.voluntary   if ctx != "N/A" else "N/A"),
        ("上下文切换 (非自愿)",ctx.involuntary if ctx != "N/A" else "N/A"),
        ("磁盘读取总量",       fmt_bytes(io.read_bytes)  if io and io != "N/A" else "N/A"),
        ("磁盘写入总量",       fmt_bytes(io.write_bytes) if io and io != "N/A" else "N/A"),
        ("磁盘读取次数",       io.read_count  if io and io != "N/A" else "N/A"),
        ("磁盘写入次数",       io.write_count if io and io != "N/A" else "N/A"),
    ]:
        print(kv(label, value))

    # 子进程树
    if show_tree:
        print(section("进程树"))
        tree_lines = render_tree(pid)
        for line in tree_lines:
            print(f"  {line}")

    # 内存详情
    print(section("内存详情"))
    if hasattr(proc, "memory_maps"):
        try:
            maps = proc.memory_maps(grouped=False)
            w = term_width()
            fmt_str = "  {:<18} {:<6} {:>10}  {}"
            print(dim(fmt_str.format("地址", "权限", "RSS(MB)", "路径")))
            for m in maps[:40]:
                print(fmt_str.format(
                    trunc(m.addr, 18), m.perms,
                    f"{m.rss/1024**2:.2f}", trunc(m.path, w - 42)
                ))
            if len(maps) > 40:
                print(dim(f"  … 共 {len(maps)} 条，仅显示前 40 条"))
        except Exception as e:
            print(kv("状态", f"(需要 sudo 运行: {e})"))
    else:
        try:
            fi = proc.memory_full_info()
            for field in fi._fields:
                print(kv(field.upper(), fmt_bytes(getattr(fi, field))))
        except Exception:
            try:
                mi = proc.memory_info()
                for field in mi._fields:
                    print(kv(field.upper(), fmt_bytes(getattr(mi, field))))
            except Exception as e:
                print(kv("状态", f"(需要 sudo 运行: {e})"))

    # 打开的文件
    print(section("打开的文件"))
    try:
        files = proc.open_files()
        if files:
            w = term_width()
            fmt_str = "  {:>5}  {:<8}  {}"
            print(dim(fmt_str.format("FD", "模式", "路径")))
            for f in files:
                print(fmt_str.format(f.fd, getattr(f, "mode", ""), trunc(f.path, w - 20)))
        else:
            print(dim("  (无打开的文件)"))
    except psutil.AccessDenied:
        print(dim("  (需要 sudo 运行)"))
    except Exception as e:
        print(dim(f"  ({e})"))

    # 网络连接 / 端口
    print(section("网络连接 / 端口"))
    try:
        get_conns = (proc.net_connections
                     if hasattr(proc, "net_connections")
                     else proc.connections)
        conns = get_conns(kind="all")
        if conns:
            fmt_str = "  {:<12} {:<22} {:<22} {}"
            print(dim(fmt_str.format("协议", "本地地址:端口", "远端地址:端口", "状态")))
            for c in conns:
                local  = f"{c.laddr.ip}:{c.laddr.port}" if hasattr(c.laddr, "ip") else (str(c.laddr) if c.laddr else "")
                remote = f"{c.raddr.ip}:{c.raddr.port}" if hasattr(c.raddr, "ip") else (str(c.raddr) if c.raddr else "")
                print(fmt_str.format(
                    conn_proto(c), trunc(local, 22), trunc(remote, 22),
                    c.status if c.status else ""
                ))
        else:
            print(dim("  (无网络连接)"))
    except psutil.AccessDenied:
        print(dim("  (需要 sudo 运行)"))
    except Exception as e:
        print(dim(f"  ({e})"))

    # 线程
    print(section("线程"))
    try:
        threads = proc.threads()
        fmt_str = "  {:>8}  {:>14}  {:>14}"
        print(dim(fmt_str.format("TID", "用户态 (s)", "内核态 (s)")))
        for t in threads:
            print(fmt_str.format(t.id, f"{t.user_time:.3f}", f"{t.system_time:.3f}"))
    except psutil.AccessDenied:
        print(dim("  (需要 sudo 运行)"))
    except Exception as e:
        print(dim(f"  ({e})"))

    # 环境变量
    print(section("环境变量"))
    try:
        env = proc.environ()
        w = term_width()
        for k, v in sorted(env.items()):
            print(f"  {bold(k)}={trunc(v, w - len(k) - 3)}")
    except psutil.AccessDenied:
        print(dim("  (需要 sudo 运行)"))
    except Exception as e:
        print(dim(f"  ({e})"))

    print()

# ──────────────────────────────────────────────────────────────────────────────
# 进程操作
# ──────────────────────────────────────────────────────────────────────────────

def send_signal(pid: int, sig):
    """向进程发送信号"""
    try:
        p = psutil.Process(pid)
        name = safe(p.name, str(pid))
        if IS_WIN:
            if sig in ("SIGKILL", signal.SIGTERM, 9):
                p.kill()
                print(green(f"✓ 已终止进程 {name} (PID {pid})"))
            else:
                print(yellow("Windows 仅支持 SIGTERM/SIGKILL"))
        else:
            sig_map = {
                "SIGTERM": signal.SIGTERM,
                "SIGKILL": signal.SIGKILL,
                "SIGSTOP": signal.SIGSTOP,
                "SIGCONT": signal.SIGCONT,
            }
            if isinstance(sig, str):
                sig = sig_map.get(sig.upper(), signal.SIGTERM)
            os.kill(pid, sig)
            sig_name = {v: k for k, v in signal.__dict__.items()
                        if isinstance(v, int) and k.startswith("SIG")}.get(sig, str(sig))
            print(green(f"✓ 已向 {name} (PID {pid}) 发送 {sig_name}"))
    except psutil.NoSuchProcess:
        print(red(f"✗ 进程 {pid} 不存在"))
        sys.exit(2)
    except psutil.AccessDenied:
        print(red(f"✗ 权限不足，无法操作进程 {pid}（尝试 sudo）"))
        sys.exit(3)
    except Exception as e:
        print(red(f"✗ 操作失败: {e}"))
        sys.exit(1)

def do_renice(pid: int, nice: int):
    """调整进程优先级"""
    if not -20 <= nice <= 19:
        print(red("nice 值必须在 -20 ~ 19 之间"))
        sys.exit(4)
    try:
        p = psutil.Process(pid)
        old = p.nice()
        p.nice(nice)
        name = safe(p.name, str(pid))
        print(green(f"✓ {name} (PID {pid}) 优先级: {old} → {nice}"))
    except psutil.NoSuchProcess:
        print(red(f"✗ 进程 {pid} 不存在"))
        sys.exit(2)
    except psutil.AccessDenied:
        print(red(f"✗ 权限不足（提高优先级需要 sudo）"))
        sys.exit(3)
    except Exception as e:
        print(red(f"✗ 操作失败: {e}"))
        sys.exit(1)

# ──────────────────────────────────────────────────────────────────────────────
# 入口
# ──────────────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description="跨平台进程监控工具（macOS / Linux / Windows）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # 查询目标
    target = p.add_argument_group("查询目标")
    target.add_argument("-p", "--pid",    type=int,   help="查看指定 PID 的详细信息")
    target.add_argument("--port",         type=int,   help="按端口号反查持有进程")
    target.add_argument("--file",         type=str,   help="按文件路径反查持有进程")

    # 列表过滤/排序
    lst = p.add_argument_group("进程列表")
    lst.add_argument("-f", "--filter", default="", help="按进程名/PID/用户过滤")
    lst.add_argument("-s", "--sort",   default="cpu",
                     choices=list(SORT_KEYS.keys()), help="排序字段（默认 cpu）")
    lst.add_argument("-n", "--top",    type=int, default=30, help="显示前 N 个（默认 30）")
    lst.add_argument("-w", "--watch",  action="store_true", help="持续刷新模式")
    lst.add_argument("-i", "--interval", type=float, default=3.0, help="刷新间隔秒数（默认 3）")

    # 详情模式
    det = p.add_argument_group("详情选项（配合 -p 使用）")
    det.add_argument("--tree",     action="store_true", help="显示子进程树")
    det.add_argument("--ancestry", action="store_true", help="只显示祖先链单行")
    det.add_argument("--json",     action="store_true", help="JSON 格式输出")
    det.add_argument("--warnings", action="store_true", help="只显示告警")

    # 进程操作
    ops = p.add_argument_group("进程操作")
    ops.add_argument("--kill",   type=int, metavar="PID", help="终止进程 (SIGTERM)")
    ops.add_argument("-9",       dest="kill9", action="store_true", help="配合 --kill，发送 SIGKILL")
    ops.add_argument("--pause",  type=int, metavar="PID", help="暂停进程 (SIGSTOP)")
    ops.add_argument("--resume", type=int, metavar="PID", help="恢复进程 (SIGCONT)")
    ops.add_argument("--renice", type=int, nargs=2, metavar=("PID", "NICE"),
                     help="调整进程 nice 值，如 --renice 1234 10")

    # 通用
    p.add_argument("--no-color", action="store_true", help="禁用颜色输出")

    return p.parse_args()


def main():
    args = parse_args()

    if args.no_color or os.environ.get("NO_COLOR"):
        disable_color()

    # ── 进程操作 ──────────────────────────────────────────────────────────────
    if args.kill:
        sig = signal.SIGKILL if args.kill9 else signal.SIGTERM
        send_signal(args.kill, sig)
        return

    if args.pause:
        if IS_WIN:
            print(yellow("Windows 不支持 SIGSTOP，请使用任务管理器"))
            sys.exit(4)
        send_signal(args.pause, signal.SIGSTOP)
        return

    if args.resume:
        if IS_WIN:
            print(yellow("Windows 不支持 SIGCONT"))
            sys.exit(4)
        send_signal(args.resume, signal.SIGCONT)
        return

    if args.renice:
        do_renice(args.renice[0], args.renice[1])
        return

    # ── 端口反查 ──────────────────────────────────────────────────────────────
    if args.port is not None:
        pids = find_by_port(args.port)
        if not pids:
            print(yellow(f"端口 {args.port} 未找到持有进程（可能需要 sudo）"))
            sys.exit(2)
        print(bold(cyan(f"\n  端口 {args.port} 的持有进程：")))
        for pid in pids:
            try:
                p = psutil.Process(pid)
                print(f"  PID {bold(str(pid))}  {p.name()}  [{safe(p.status)}]  {safe(p.username)}")
            except Exception:
                print(f"  PID {pid}")
        print()
        # 若只有一个进程，自动显示详情
        if len(pids) == 1:
            print_detail(pids[0], show_tree=args.tree, as_json=args.json,
                         warnings_only=args.warnings)
        return

    # ── 文件反查 ──────────────────────────────────────────────────────────────
    if args.file:
        pids = find_by_file(args.file)
        if not pids:
            print(yellow(f"文件 '{args.file}' 未找到持有进程（可能需要 sudo）"))
            sys.exit(2)
        print(bold(cyan(f"\n  文件 '{args.file}' 的持有进程：")))
        for pid in pids:
            try:
                p = psutil.Process(pid)
                print(f"  PID {bold(str(pid))}  {p.name()}  [{safe(p.status)}]  {safe(p.username)}")
            except Exception:
                print(f"  PID {pid}")
        print()
        if len(pids) == 1:
            print_detail(pids[0], show_tree=args.tree, as_json=args.json,
                         warnings_only=args.warnings)
        return

    # ── PID 详情 ──────────────────────────────────────────────────────────────
    if args.pid:
        print_detail(
            args.pid,
            show_tree=args.tree,
            show_ancestry_only=args.ancestry,
            as_json=args.json,
            warnings_only=args.warnings,
        )
        return

    # ── 进程列表 ──────────────────────────────────────────────────────────────
    if args.watch:
        try:
            while True:
                procs = fetch_processes()
                clear_screen()
                print(render_list(procs, args.sort, args.filter, args.top))
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\n已退出")
    else:
        procs = fetch_processes()
        print(render_list(procs, args.sort, args.filter, args.top))


if __name__ == "__main__":
    main()
