"""pmon - Cross-platform process monitor"""
__version__ = "0.1.0"
