from setuptools import setup, find_packages

setup(
    name="marmon",
    version="1.0.1",
    description="跨平台进程监控工具 — macOS / Linux / Windows",
    python_requires=">=3.8",
    install_requires=["psutil>=5.9"],
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    entry_points={"console_scripts": ["marmon=marmon.cli:main"]},
)
