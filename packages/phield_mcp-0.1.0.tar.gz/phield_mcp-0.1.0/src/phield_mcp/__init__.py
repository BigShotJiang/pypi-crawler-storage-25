"""Phield MCP — Connecteur Claude Desktop vers CRM Phield."""
