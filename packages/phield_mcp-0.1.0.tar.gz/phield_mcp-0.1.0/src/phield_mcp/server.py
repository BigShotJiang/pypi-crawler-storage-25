"""Serveur MCP Phield — connecte Claude Desktop au CRM Phield."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from phield_mcp.tools import actions, dashboard, interactions, pharmacies, veille

mcp = FastMCP(
    "Phield CRM",
    instructions=(
        "Tu es l'assistant CRM des commerciaux Phield. "
        "Utilise les outils Phield pour consulter le dashboard, rechercher des pharmacies, "
        "enregistrer des interactions, planifier des actions, et surveiller les alertes de veille. "
        "Réponds toujours en français. "
        "Quand un commercial décrit une visite ou un appel, propose d'enregistrer l'interaction. "
        "Quand il demande ce qu'il a à faire, utilise le tableau de bord."
    ),
)

# Register all tool modules
dashboard.register(mcp)
pharmacies.register(mcp)
actions.register(mcp)
interactions.register(mcp)
veille.register(mcp)


def main() -> None:
    """Entry point for `uvx phield-mcp` or `python -m phield_mcp.server`."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
