"""Tools MCP — Création et complétion d'actions."""

from __future__ import annotations

from typing import Optional

from mcp.server.fastmcp import FastMCP

from phield_mcp.client import api


def register(mcp: FastMCP) -> None:
    @mcp.tool()
    async def creer_action(
        id_pharmacie: str,
        date_prevue: str,
        type_action: str,
        priorite: str = "normale",
        note: Optional[str] = None,
    ) -> str:
        """Planifie une nouvelle action pour une pharmacie.

        Args:
            id_pharmacie: UUID de la pharmacie
            date_prevue: Date prévue (YYYY-MM-DD)
            type_action: appel, email, visite, relance, demo, devis, signature
            priorite: basse, normale, haute, urgente (défaut: normale)
            note: Note optionnelle
        """
        payload: dict = {
            "id_pharmacie": id_pharmacie,
            "date_prevue": date_prevue,
            "type_action": type_action,
            "priorite": priorite,
        }
        if note:
            payload["note"] = note

        data = await api.post("/actions", payload)
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        return (
            f"Action créée : {type_action} le {date_prevue} "
            f"(priorité {priorite}, ID `{data.get('id_action', '?')}`)"
        )

    @mcp.tool()
    async def completer_action(
        id_action: str,
        statut: str = "fait",
        note: Optional[str] = None,
    ) -> str:
        """Marque une action comme faite, annulée ou reportée.

        Args:
            id_action: UUID de l'action
            statut: fait, annule, reporte (défaut: fait)
            note: Note optionnelle
        """
        payload: dict = {"statut": statut}
        if note:
            payload["note"] = note

        data = await api.patch(f"/actions/{id_action}", payload)
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        return f"Action marquée **{statut}**."
