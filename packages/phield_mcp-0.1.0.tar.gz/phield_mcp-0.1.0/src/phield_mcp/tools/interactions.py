"""Tools MCP — Enregistrement d'interactions."""

from __future__ import annotations

from typing import Optional

from mcp.server.fastmcp import FastMCP

from phield_mcp.client import api


def register(mcp: FastMCP) -> None:
    @mcp.tool()
    async def enregistrer_interaction(
        id_pharmacie: str,
        date: str,
        type: str,
        canal: str,
        resultat: str = "neutre",
        duree_minutes: Optional[int] = None,
        interlocuteur_nom: Optional[str] = None,
        note: Optional[str] = None,
        produits_evoques: Optional[str] = None,
    ) -> str:
        """Enregistre un compte-rendu d'interaction (visite, appel, email…).

        Args:
            id_pharmacie: UUID de la pharmacie
            date: Date et heure (ISO 8601, ex: 2026-04-10T14:30:00)
            type: appel_sortant, appel_entrant, email_envoye, email_recu, visite, demo, salon, autre
            canal: telephone, email, physique, visio, autre
            resultat: positif, neutre, negatif, absent, a_rappeler (défaut: neutre)
            duree_minutes: Durée en minutes
            interlocuteur_nom: Nom de l'interlocuteur
            note: Compte-rendu / notes
            produits_evoques: Produits évoqués, séparés par des virgules (ex: "robot_officine,agencement")
        """
        payload: dict = {
            "id_pharmacie": id_pharmacie,
            "date": date,
            "type": type,
            "canal": canal,
            "resultat": resultat,
        }
        if duree_minutes is not None:
            payload["duree_minutes"] = duree_minutes
        if interlocuteur_nom:
            payload["interlocuteur_nom"] = interlocuteur_nom
        if note:
            payload["note"] = note
        if produits_evoques:
            payload["produits_evoques"] = [p.strip() for p in produits_evoques.split(",")]

        data = await api.post("/interactions", payload)
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        return (
            f"Interaction enregistrée : {type} ({canal}) — résultat {resultat} "
            f"(ID `{data.get('id_interaction', '?')}`)"
        )
