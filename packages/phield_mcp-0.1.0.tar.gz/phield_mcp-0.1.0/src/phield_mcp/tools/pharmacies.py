"""Tools MCP — Recherche, fiche, EHPAD proximité, changement statut."""

from __future__ import annotations

from typing import Optional

from mcp.server.fastmcp import FastMCP

from phield_mcp.client import api


def register(mcp: FastMCP) -> None:
    @mcp.tool()
    async def rechercher_pharmacie(
        recherche: Optional[str] = None,
        departement: Optional[str] = None,
        statut: Optional[str] = None,
        score_min: Optional[int] = None,
        score_max: Optional[int] = None,
        produit: Optional[str] = None,
        concurrent: Optional[str] = None,
        page: int = 1,
    ) -> str:
        """Recherche des pharmacies avec filtres.

        Args:
            recherche: Texte libre (nom, ville, SIRET, titulaire)
            departement: Code département (ex: "92", "75")
            statut: prospect, contacte, en_negociation, client, perdu, inactif
            score_min: Score minimum (0-100)
            score_max: Score maximum (0-100)
            produit: Type de produit (robot_officine, robot_ehpad, agencement, grossiste)
            concurrent: Nom du concurrent (partiel)
            page: Page de résultats (défaut 1)
        """
        data = await api.get(
            "/pharmacies",
            search=recherche,
            departement=departement,
            statut=statut,
            score_min=score_min,
            score_max=score_max,
            produit=produit,
            concurrent=concurrent,
            page=page,
            page_size=20,
        )
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        items = data.get("items", [])
        total = data.get("total", 0)

        if not items:
            return "Aucune pharmacie trouvée avec ces critères."

        lines = [f"## {total} pharmacie(s) trouvée(s) (page {page})\n"]
        for p in items:
            score = p.get("score_priorite") or "—"
            opp = " [OPPOSITION]" if p.get("opposition_prospection") else ""
            lines.append(
                f"- **{p['raison_sociale']}** ({p['ville']}, {p['departement']})\n"
                f"  SIRET {p['siret']} | Score {score} | {p['statut_commercial']}{opp}\n"
                f"  ID : `{p['id_pharmacie']}`"
            )

        if total > page * 20:
            lines.append(f"\n_Page {page}/{(total + 19) // 20} — relance avec page={page + 1} pour la suite._")

        return "\n".join(lines)

    @mcp.tool()
    async def fiche_pharmacie(id_pharmacie: str) -> str:
        """Affiche la fiche complète d'une pharmacie : coordonnées, financier, score, produits, interactions récentes, actions.

        Args:
            id_pharmacie: UUID de la pharmacie
        """
        # Fetch pharmacy detail + products + interactions + actions in parallel
        import asyncio

        pharma, produits, interactions, actions = await asyncio.gather(
            api.get(f"/pharmacies/{id_pharmacie}"),
            api.get(f"/pharmacies/{id_pharmacie}/produits"),
            api.get(f"/interactions/pharmacie/{id_pharmacie}", limit=10),
            api.get(f"/actions/pharmacie/{id_pharmacie}"),
        )

        if isinstance(pharma, dict) and "erreur" in pharma:
            return pharma["erreur"]

        lines: list[str] = []

        # Header
        p = pharma
        opp = " **[OPPOSITION PROSPECTION]**" if p.get("opposition_prospection") else ""
        lines.append(f"# {p['raison_sociale']}{opp}")
        lines.append(f"SIRET {p['siret']} | {p['adresse']}, {p['code_postal']} {p['ville']}")

        if p.get("telephone"):
            lines.append(f"Tel : {p['telephone']}")
        if p.get("email"):
            lines.append(f"Email : {p['email']}")
        if p.get("titulaire_nom"):
            tit = p['titulaire_nom']
            if p.get("titulaire_prenom"):
                tit = f"{p['titulaire_prenom']} {tit}"
            lines.append(f"Titulaire : {tit}")

        # Commercial status
        lines.append(f"\n## Statut commercial")
        lines.append(f"Pipeline : **{p['statut_commercial']}** | Score : **{p.get('score_priorite', '—')}/100**")
        if p.get("score_override"):
            lines.append(f"Score forcé — motif : {p.get('score_override_motif', '?')}")

        # Financier
        if p.get("ca") or p.get("resultat_net"):
            lines.append(f"\n## Données financières")
            if p.get("ca"):
                lines.append(f"CA : {p['ca']:,} EUR".replace(",", " "))
            if p.get("resultat_net"):
                lines.append(f"Résultat net : {p['resultat_net']:,} EUR".replace(",", " "))
            if p.get("effectifs"):
                lines.append(f"Effectifs : {p['effectifs']}")
            if p.get("annee_bilan"):
                lines.append(f"Année bilan : {p['annee_bilan']}")

        # Products
        if isinstance(produits, list) and produits:
            lines.append(f"\n## Produits ({len(produits)})")
            for pr in produits:
                status_icon = "**installé**" if pr.get("installe") else "pas installé"
                concurrent = f" (concurrent: {pr['concurrent']})" if pr.get("concurrent") else ""
                lines.append(f"- {pr['produit']} : {status_icon}{concurrent}")
                if pr.get("note"):
                    lines.append(f"  Note : {pr['note']}")

        # Interactions
        if isinstance(interactions, list) and interactions:
            lines.append(f"\n## Dernières interactions")
            for i in interactions[:5]:
                lines.append(f"- {i['date'][:10]} {i['type']} ({i['canal']}) — {i['resultat']}")
                if i.get("note"):
                    lines.append(f"  {i['note'][:200]}")

        # Actions
        if isinstance(actions, list) and actions:
            pending = [a for a in actions if a.get("statut") == "a_faire"]
            if pending:
                lines.append(f"\n## Actions à faire ({len(pending)})")
                for a in pending[:5]:
                    lines.append(f"- {a['date_prevue']} : {a['type_action']} [{a['priorite']}]")
                    if a.get("note"):
                        lines.append(f"  {a['note'][:150]}")

        return "\n".join(lines)

    @mcp.tool()
    async def ehpad_proximite(id_pharmacie: str) -> str:
        """Liste les EHPAD à proximité d'une pharmacie avec nombre de lits et distance.

        Args:
            id_pharmacie: UUID de la pharmacie
        """
        data = await api.get(f"/pharmacies/{id_pharmacie}/ehpad-proximite")
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        items = data.get("items", []) if isinstance(data, dict) else data
        if not items:
            return "Aucun EHPAD trouvé à proximité."

        lines = [f"## {len(items)} EHPAD à proximité\n"]
        for e in items:
            lits = f"{e.get('nombre_lits', '?')} lits" if e.get("nombre_lits") else ""
            dist = f"{e.get('distance_km', '?')} km" if e.get("distance_km") is not None else ""
            ref = " (référencé)" if e.get("est_reference") else ""
            lines.append(f"- **{e.get('raison_sociale', '?')}** — {dist}, {lits}{ref}")
            if e.get("adresse"):
                lines.append(f"  {e['adresse']}, {e.get('code_postal', '')} {e.get('ville', '')}")
        return "\n".join(lines)

    @mcp.tool()
    async def changer_statut(id_pharmacie: str, statut: str) -> str:
        """Change le statut pipeline d'une pharmacie.

        Args:
            id_pharmacie: UUID de la pharmacie
            statut: Nouveau statut — prospect, contacte, en_negociation, client, perdu, inactif
        """
        data = await api.patch(
            f"/pharmacies/{id_pharmacie}/statut",
            {"statut": statut},
        )
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        return f"Statut changé en **{statut}** pour {data.get('raison_sociale', 'la pharmacie')}."
