"""Tools MCP — Dashboard et actions en retard."""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from phield_mcp.client import api


def register(mcp: FastMCP) -> None:
    @mcp.tool()
    async def tableau_de_bord() -> str:
        """Affiche le tableau de bord du jour : actions prévues, en retard, de la semaine, alertes de veille, et dernières fiches consultées."""
        data = await api.get("/dashboard")
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        lines: list[str] = []

        retard = data.get("actions_retard", [])
        if retard:
            lines.append(f"## Actions en retard ({len(retard)})")
            for a in retard:
                lines.append(f"- {a['type_action']} — {a['pharmacie_nom']} (prévu {a['date_prevue']})")

        jour = data.get("actions_jour", [])
        if jour:
            lines.append(f"\n## Actions du jour ({len(jour)})")
            for a in jour:
                lines.append(f"- [{a['priorite']}] {a['type_action']} — {a['pharmacie_nom']}")
                if a.get("note"):
                    lines.append(f"  Note : {a['note']}")

        semaine = data.get("actions_semaine", [])
        if semaine:
            lines.append(f"\n## Cette semaine ({len(semaine)})")
            for a in semaine:
                lines.append(f"- {a['date_prevue']} : {a['type_action']} — {a['pharmacie_nom']}")

        alertes = data.get("alertes", [])
        if alertes:
            lines.append(f"\n## Alertes veille ({len(alertes)})")
            for al in alertes[:5]:
                lines.append(f"- [{al['type_veille']}] {al['titre']}")
                if al.get("pharmacie_nom"):
                    lines.append(f"  Pharmacie : {al['pharmacie_nom']}")

        fiches = data.get("fiches_recentes", [])
        if fiches:
            lines.append(f"\n## Dernières fiches consultées")
            for f in fiches[:5]:
                lines.append(f"- {f['raison_sociale']} ({f['ville']}) — score {f.get('score_priorite', '?')}, {f['statut_commercial']}")

        if not lines:
            return "Rien de prévu aujourd'hui. Bonne journée !"

        return "\n".join(lines)

    @mcp.tool()
    async def mes_actions_en_retard() -> str:
        """Liste uniquement les actions en retard (non effectuées dont la date est passée)."""
        data = await api.get("/actions/overdue")
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        if not data:
            return "Aucune action en retard."

        lines = [f"## Actions en retard ({len(data)})"]
        for a in data:
            lines.append(f"- {a['type_action']} — pharmacie {a['id_pharmacie'][:8]}… (prévu {a['date_prevue']}, priorité {a['priorite']})")
            if a.get("note"):
                lines.append(f"  Note : {a['note']}")
        return "\n".join(lines)
