"""Tools MCP — Alertes veille BODACC/BOAMP."""

from __future__ import annotations

from typing import Optional

from mcp.server.fastmcp import FastMCP

from phield_mcp.client import api


def register(mcp: FastMCP) -> None:
    @mcp.tool()
    async def alertes_veille(
        type_veille: Optional[str] = None,
        non_lues: bool = True,
    ) -> str:
        """Affiche les alertes de veille BODACC (procédures collectives) et BOAMP (marchés publics).

        Args:
            type_veille: Filtrer par type — bodacc, boamp (défaut: tous)
            non_lues: Ne montrer que les non-lues (défaut: oui)
        """
        params: dict = {}
        if type_veille:
            params["type_veille"] = type_veille
        if non_lues:
            params["lu"] = False

        data = await api.get("/veille", **params)
        if isinstance(data, dict) and "erreur" in data:
            return data["erreur"]

        items = data.get("items", []) if isinstance(data, dict) else data
        if not items:
            return "Aucune alerte de veille" + (" non lue." if non_lues else ".")

        lines = [f"## {len(items)} alerte(s) de veille\n"]
        for a in items:
            lines.append(f"- **[{a.get('type_veille', '?')}]** {a.get('titre', '—')}")
            if a.get("resume"):
                lines.append(f"  {a['resume'][:200]}")
            if a.get("pharmacie_nom"):
                lines.append(f"  Pharmacie : {a['pharmacie_nom']}")
            lines.append(f"  Détecté le {a.get('date_detection', '?')}")

        return "\n".join(lines)
