# phield-mcp

Connecteur MCP (Model Context Protocol) pour le CRM Phield. Permet aux commerciaux d'interagir avec le CRM directement depuis Claude Desktop.

## Installation

```bash
uvx phield-mcp
```

## Configuration Claude Desktop

```json
{
  "mcpServers": {
    "phield": {
      "command": "uvx",
      "args": ["phield-mcp"],
      "env": {
        "PHIELD_API_KEY": "<votre clé API>",
        "PHIELD_API_URL": "https://pharos-production-624e.up.railway.app"
      }
    }
  }
}
```

## Tools disponibles

| Tool | Description |
|------|-------------|
| `tableau_de_bord` | Dashboard du jour (actions, retards, alertes, fiches) |
| `mes_actions_en_retard` | Actions en retard uniquement |
| `rechercher_pharmacie` | Recherche par nom/ville/SIRET + filtres |
| `fiche_pharmacie` | Fiche complète (coordonnées, financier, produits, historique) |
| `ehpad_proximite` | EHPADs proches (lits, distance, référencement) |
| `creer_action` | Planifier une action (appel, visite, relance, demo...) |
| `completer_action` | Marquer une action faite/annulée/reportée |
| `enregistrer_interaction` | Logger un CR de visite/appel/email |
| `changer_statut` | Changer le statut pipeline d'une pharmacie |
| `alertes_veille` | Alertes BODACC/BOAMP non lues |
