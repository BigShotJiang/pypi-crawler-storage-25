from __future__ import annotations

import logging
import math
import weakref
from typing import TYPE_CHECKING

import cv2
import numpy as np
from fastapi import Response
from nicegui import app

from .. import run
from ..geometry import Rectangle
from .calibration import Calibration
from .image import Image
from .image_processing import encode_image_as_jpeg, process_ndarray_image
from .image_rotation import ImageRotation

if TYPE_CHECKING:
    from .camera import Camera

log = logging.getLogger('rosys.image_route')


def create_image_route(camera: Camera) -> None:
    placeholder_url = '/' + camera.base_path + '/placeholder'
    timestamp_url = '/' + camera.base_path + '/{timestamp}'
    undistorted_url = '/' + camera.base_path + '/{timestamp}/undistorted'

    app.remove_route(placeholder_url)
    app.remove_route(timestamp_url)
    app.remove_route(undistorted_url)

    camera_ref = weakref.ref(camera)

    async def get_camera_image(timestamp: str,
                               shrink: float = 1.0,
                               max_dimension: float | None = None,
                               fast: bool = True,
                               compression: int = 60,
                               crop_x: int | None = None,
                               crop_y: int | None = None,
                               crop_w: int | None = None,
                               crop_h: int | None = None,
                               rotation: int = 0) -> Response:
        camera = camera_ref()
        if not camera:
            return Response(content='Camera was removed', status_code=404)
        try:
            crop = Rectangle(x=crop_x, y=crop_y, width=crop_w, height=crop_h) \
                if crop_x is not None and crop_y is not None and crop_w is not None and crop_h is not None else None
            image_rotation = ImageRotation.from_degrees(rotation)
        except ValueError as e:
            return Response(content=str(e), status_code=400)
        return await _get_image(camera, timestamp,
                                shrink=shrink,
                                max_dimension=max_dimension,
                                undistort=False,
                                fast=fast,
                                compression=compression,
                                crop=crop,
                                rotation=image_rotation)

    async def get_camera_image_undistorted(timestamp: str,
                                           shrink: float = 1.0,
                                           max_dimension: float | None = None,
                                           fast: bool = True,
                                           compression: int = 60,
                                           crop_x: int | None = None,
                                           crop_y: int | None = None,
                                           crop_w: int | None = None,
                                           crop_h: int | None = None,
                                           rotation: int = 0) -> Response:
        camera = camera_ref()
        if not camera:
            return Response(content='Camera was removed', status_code=404)
        try:
            crop = Rectangle(x=crop_x, y=crop_y, width=crop_w, height=crop_h) \
                if crop_x is not None and crop_y is not None and crop_w is not None and crop_h is not None else None
            image_rotation = ImageRotation.from_degrees(rotation)
        except ValueError as e:
            return Response(content=str(e), status_code=400)
        return await _get_image(camera,
                                timestamp,
                                shrink=shrink,
                                max_dimension=max_dimension,
                                undistort=True,
                                fast=fast,
                                compression=compression,
                                crop=crop,
                                rotation=image_rotation)

    app.add_api_route(placeholder_url, _get_placeholder)
    app.add_api_route(timestamp_url, get_camera_image)
    app.add_api_route(undistorted_url, get_camera_image_undistorted)


def _create_placeholder(shrink: int) -> bytes:
    image = Image.create_placeholder('no image', shrink=shrink)
    return image.to_jpeg_bytes()


async def _get_placeholder(shrink: int = 1) -> Response:
    placeholder_jpeg = await run.cpu_bound(_create_placeholder, shrink)
    if placeholder_jpeg is None:
        return Response('Server is stopping', 500)
    return Response(placeholder_jpeg, media_type='image/jpeg')


async def _get_image(camera: Camera,
                     timestamp: str, *,
                     shrink: float,
                     max_dimension: float | None,
                     undistort: bool,
                     fast: bool,
                     compression: int,
                     crop: Rectangle | None = None,
                     rotation: ImageRotation = ImageRotation.NONE) -> Response:
    try:
        if undistort and getattr(camera, 'calibration', None) is None:
            return Response(content='Camera is not calibrated', status_code=404)
        jpeg = await _try_get_jpeg(camera,
                                   timestamp,
                                   shrink=shrink,
                                   max_dimension=max_dimension,
                                   undistort=undistort,
                                   fast=fast,
                                   compression=compression,
                                   crop=crop,
                                   rotation=rotation)
        if not jpeg:
            return Response(content='Image not found', status_code=404)
        return Response(content=jpeg, headers={'cache-control': 'max-age=7776000'}, media_type='image/jpeg')
    except Exception:
        log.exception('could not get image')
        raise


async def _try_get_jpeg(camera: Camera,
                        timestamp: str, *,
                        shrink: float,
                        max_dimension: float | None,
                        undistort: bool,
                        fast: bool,
                        compression: int,
                        crop: Rectangle | None = None,
                        rotation: ImageRotation = ImageRotation.NONE) -> bytes | None:
    for image in reversed(camera.images):
        if str(image.time) == timestamp:
            shrink_from_max = max(image.size.width, image.size.height) / max_dimension if max_dimension else shrink

            shrink = max(1, shrink, shrink_from_max)

            if shrink == 1 and not undistort and compression == 60 \
                    and crop is None and rotation == ImageRotation.NONE:
                return await run.cpu_bound(encode_image_as_jpeg, image.array)

            calibration = camera.calibration if undistort else None  # type: ignore
            return await run.cpu_bound(_process, image, calibration, shrink, undistort, fast, compression,
                                       crop, rotation)

    return None


def _process(image: Image,
             calibration: Calibration | None,
             shrink: float,
             undistort: bool,
             fast: bool,
             compression: int,
             crop: Rectangle | None = None,
             rotation: ImageRotation = ImageRotation.NONE) -> bytes | None:
    image_array: np.ndarray = image.array

    if undistort:
        assert calibration is not None
        image_array = calibration.undistort_image(image_array, crop=True)
        if image_array is None or image_array.size == 0:
            logging.warning('undistort_array returned an empty image')
            return None

    if crop is not None or rotation != ImageRotation.NONE:
        image_array = process_ndarray_image(image_array, rotation, crop)

    if shrink != 1.0:
        if fast:
            shrink_factor = math.ceil(shrink)
            image_array = image_array[::shrink_factor, ::shrink_factor]
        else:
            new_width = int(image_array.shape[1] / shrink)
            new_height = int(image_array.shape[0] / shrink)
            # INTER_AREA is optimal for downsampling
            image_array = cv2.resize(image_array, (new_width, new_height), interpolation=cv2.INTER_AREA)

    return encode_image_as_jpeg(image_array, compression_level=compression)
