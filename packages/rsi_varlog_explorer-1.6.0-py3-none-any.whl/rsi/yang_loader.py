"""yang_loader.py — Load pre-compiled YANG command trees for tab-completion.

The data files live at rsi/data/yang/<major>.<minor>.json.gz.
Version matching: "23.2R2-S3.8" → major=23, minor=2 → tries "23.2.json.gz",
then any 23.x, then the latest available.
"""

from __future__ import annotations

import gzip
import json
import re
from pathlib import Path
from typing import Dict, List, Optional

_DATA_DIR = Path(__file__).parent / "data" / "yang"


def _parse_version(version_str: str) -> Optional[tuple]:
    """Extract (major, minor) from a Junos version string like '23.2R2-S3.8'."""
    if not isinstance(version_str, str):
        return None
    m = re.match(r"(\d+)\.(\d+)", version_str.strip())
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


def _available_versions() -> Dict[tuple, Path]:
    """Return {(major, minor): path} for all bundled YANG trees."""
    versions: Dict[tuple, Path] = {}
    if not _DATA_DIR.is_dir():
        return versions
    for f in sorted(_DATA_DIR.glob("*.json.gz")):
        v = _parse_version(f.stem)   # "23.2" → (23, 2)
        if v:
            versions[v] = f
    return versions


def _find_best_path(junos_version: Optional[str]) -> Optional[Path]:
    """Return the best-matching .json.gz path for a given Junos version string."""
    avail = _available_versions()
    if not avail:
        return None

    if junos_version:
        parsed = _parse_version(junos_version)
        if parsed:
            major, minor = parsed
            # Exact match
            if (major, minor) in avail:
                return avail[(major, minor)]
            # Same major, closest minor
            same_major = {k: v for k, v in avail.items() if k[0] == major}
            if same_major:
                best = max(same_major.keys())
                return same_major[best]

    # Fall back to newest version overall
    return avail[max(avail.keys())]


def load_tree(junos_version: Optional[str] = None) -> Optional["YangTree"]:
    """Load and return a YangTree for the given Junos version (or the newest available).

    Returns None if no YANG data is bundled.
    """
    path = _find_best_path(junos_version)
    if path is None:
        return None
    try:
        with gzip.open(path, "rb") as f:
            data = json.loads(f.read().decode("utf-8"))
        return YangTree(data.get("tree", {}), data.get("version", "?"))
    except Exception:
        return None


class YangTree:
    """Navigation helper for the YANG command tree.

    The tree format is a nested dict:
      {
        "interfaces": {
          "_k": "name",        <- list nodes have "_k" (key leaf name)
          "unit": {"_k": "number", "family": {"inet": {...}}},
          "description": {}    <- leaf nodes have empty dicts
        },
        "protocols": { ... }
      }

    List node navigation rule:
      If "_k" in node AND current token is NOT a known child keyword,
      treat the token as a list-key value and advance WITHOUT descending.
    """

    def __init__(self, tree: dict, version: str) -> None:
        self._tree = tree
        self.version = version

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def _navigate(self, tokens: List[str]) -> Optional[dict]:
        """Navigate the tree following `tokens`.  Returns the node reached,
        or None if the path is invalid.

        Handles two navigation patterns:
          A) Explicit list keyword:  protocols bgp group <name> ...
             ("group" is a list child, user types it explicitly)
          B) Implicit list keyword:  interfaces <name> unit <n> ...
             ("interface" list keyword is omitted; user types only the key)
        """
        node: dict = self._tree
        i = 0
        while i < len(tokens):
            tok = tokens[i].lower()

            # At a list node: if token is not a child keyword, treat it as key value
            if "_k" in node and tok not in node:
                i += 1
                continue

            # Token matches a child keyword → navigate in
            if tok in node:
                node = node[tok]
                i += 1
                continue

            # Token doesn't match anything — try implicit list navigation:
            # the parent is a container that has list children, and the user
            # provided the list-key value without typing the list name first.
            implicit = self._implicit_list_navigate(node, tokens, i)
            if implicit is not None:
                node, i = implicit
                continue

            return None   # genuine dead end
        return node

    def _implicit_list_navigate(
        self, node: dict, tokens: List[str], i: int
    ) -> Optional[tuple]:
        """Try implicit navigation when the current token looks like a list-key value
        for an un-named list child of node (e.g., 'ge-0/0/0' after 'interfaces').

        Returns (new_node, new_i) or None.
        """
        # Collect list children (children whose dicts contain "_k")
        list_children = [
            (k, v)
            for k, v in node.items()
            if not k.startswith("_") and isinstance(v, dict) and "_k" in v
        ]
        if not list_children:
            return None

        next_tok = tokens[i + 1].lower() if i + 1 < len(tokens) else None

        if next_tok is not None:
            # Use next token to disambiguate: find the list child that contains next_tok
            for _list_name, list_node in list_children:
                if next_tok in list_node:
                    # Advance past the implicit key value; caller will process next_tok
                    return (list_node, i + 1)

        # No next_tok or no unambiguous match → pick first list child
        return (list_children[0][1], i + 1)

    # ------------------------------------------------------------------
    # Public API: completions and help
    # ------------------------------------------------------------------

    def get_completions(self, path_tokens: List[str], prefix: str = "") -> List[str]:
        """Return valid next keywords at `path_tokens`, filtered by `prefix`.

        path_tokens: the definite path tokens (all entered completely)
        prefix: partial prefix of the next token (may be "")
        """
        node = self._navigate(path_tokens)
        if node is None:
            return []
        prefix_l = prefix.lower()
        results = [k for k in node if not k.startswith("_") and k.startswith(prefix_l)]
        # If this is a list node, add a placeholder hint
        if "_k" in node:
            key_name = node["_k"]
            placeholder = f"<{key_name}>"
            if not prefix or placeholder.startswith(prefix_l):
                results.append(placeholder)
        return sorted(set(results))

    def get_help_lines(self, path_tokens: List[str], prefix: str = "") -> List[str]:
        """Return Junos-style help lines: ['> keyword   description', ...]"""
        completions = self.get_completions(path_tokens, prefix)
        if not completions:
            return []
        lines: List[str] = []
        for c in completions:
            if c.startswith("<"):
                lines.append(f"> {c}   (list key)")
            else:
                lines.append(f"> {c}")
        return lines
