"""Plugin manager for template-based command conversion.

This module provides automatic discovery and loading of conversion templates
for different Junos commands.
"""

import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from .template_engine import TemplateEngine, TemplateError


class PluginManager:
    """Manages template plugins for command conversion.
    
    Automatically discovers available templates and provides command-to-template
    mapping functionality.
    """
    
    def __init__(self, template_dir: Optional[Path] = None):
        """Initialize the plugin manager.
        
        Args:
            template_dir: Directory containing template files
        """
        self.template_engine = TemplateEngine(template_dir)
        self.command_mappings: Dict[str, str] = {}  # command_pattern -> template_path
        self.template_metadata: Dict[str, Dict] = {}  # template_path -> metadata
        self.fuzzy_patterns: List[Tuple[re.Pattern, str]] = []  # (compiled_pattern, template_path)
        
        # Discover and load all available templates
        self.discover_templates()
    
    def discover_templates(self) -> None:
        """Discover all available templates and build command mappings."""
        template_dir = self.template_engine.template_dir
        
        if not template_dir.exists():
            print(f"Warning: Template directory does not exist: {template_dir}")
            return
        
        # Find all YAML template files (excluding base templates)
        for template_file in template_dir.rglob("*.yaml"):
            # Skip base templates
            if "base" in template_file.parts:
                continue
            
            # Get relative path from template directory
            relative_path = template_file.relative_to(template_dir)
            template_path = str(relative_path)
            
            try:
                # Load template to extract metadata
                template = self.template_engine.load_template(template_path)
                self.template_metadata[template_path] = template
                
                # Extract command patterns
                command_patterns = template.get('command_patterns', [])
                if not command_patterns:
                    # Fallback: use template name as pattern
                    template_name = template.get('name', template_file.stem)
                    command_patterns = [template_name.replace('_', ' ')]
                
                # Register command patterns
                for pattern in command_patterns:
                    self._register_command_pattern(pattern, template_path)
                
            except TemplateError as e:
                print(f"Warning: Failed to load template {template_path}: {e}")
            except Exception as e:
                print(f"Warning: Error processing template {template_path}: {e}")
    
    def _register_command_pattern(self, pattern: str, template_path: str) -> None:
        """Register a command pattern with its associated template.
        
        Args:
            pattern: Command pattern (may contain wildcards)
            template_path: Path to template file
        """
        # Handle exact matches first
        if '*' not in pattern and '.*' not in pattern:
            self.command_mappings[pattern.lower()] = template_path
        else:
            # Convert shell-style wildcards to regex
            regex_pattern = pattern.replace('*', '.*').replace('?', '.')
            compiled_pattern = re.compile(f"^{regex_pattern}$", re.IGNORECASE)
            self.fuzzy_patterns.append((compiled_pattern, template_path))
    
    def find_template_for_command(self, command: str) -> Optional[str]:
        """Find the best template for a given command.
        
        Args:
            command: Command string to match
            
        Returns:
            Template path if found, None otherwise
        """
        command_lower = command.strip().lower()
        
        # Try exact match first
        if command_lower in self.command_mappings:
            return self.command_mappings[command_lower]
        
        # Try fuzzy matching
        for pattern, template_path in self.fuzzy_patterns:
            if pattern.match(command_lower):
                return template_path
        
        # Try partial matching (find best substring match)
        best_match = None
        best_score = 0
        
        for registered_command, template_path in self.command_mappings.items():
            score = self._calculate_similarity(command_lower, registered_command)
            if score > best_score and score > 0.7:  # Threshold for similarity
                best_score = score
                best_match = template_path
        
        return best_match
    
    def _calculate_similarity(self, command1: str, command2: str) -> float:
        """Calculate similarity between two command strings.
        
        Args:
            command1: First command string
            command2: Second command string
            
        Returns:
            Similarity score (0.0 to 1.0)
        """
        # Simple word-based similarity
        words1 = set(command1.split())
        words2 = set(command2.split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1.intersection(words2)
        union = words1.union(words2)
        
        return len(intersection) / len(union)
    
    def convert_command(self, command: str, text_output: str) -> Optional[str]:
        """Convert command text output to XML using appropriate template.
        
        Args:
            command: Command string
            text_output: Text output from command
            
        Returns:
            XML string if conversion successful, None otherwise
        """
        template_path = self.find_template_for_command(command)
        
        if not template_path:
            return None
        
        try:
            return self.template_engine.convert_text_to_xml(text_output, template_path)
        except TemplateError as e:
            print(f"Warning: Conversion failed for command '{command}': {e}")
            return None
    
    def get_supported_commands(self) -> List[str]:
        """Get list of all supported command patterns.
        
        Returns:
            List of supported command patterns
        """
        commands = list(self.command_mappings.keys())
        
        # Add fuzzy patterns (convert back to human-readable)
        for pattern, _ in self.fuzzy_patterns:
            pattern_str = pattern.pattern.replace('^', '').replace('$', '')
            pattern_str = pattern_str.replace('.*', '*').replace('.', '?')
            commands.append(pattern_str)
        
        return sorted(commands)
    
    def get_template_info(self, template_path: str) -> Optional[Dict]:
        """Get metadata information for a template.
        
        Args:
            template_path: Path to template file
            
        Returns:
            Template metadata dictionary
        """
        return self.template_metadata.get(template_path)
    
    def list_templates(self) -> Dict[str, Dict]:
        """List all available templates with their metadata.
        
        Returns:
            Dictionary mapping template paths to metadata
        """
        return self.template_metadata.copy()
    
    def validate_templates(self) -> Dict[str, List[str]]:
        """Validate all loaded templates and return any errors.
        
        Returns:
            Dictionary mapping template paths to error messages
        """
        errors = {}
        
        for template_path in self.template_metadata.keys():
            template_errors = []
            
            try:
                template = self.template_metadata[template_path]
                
                # Check required fields
                required_fields = ['name', 'parsing_strategy']
                for field in required_fields:
                    if field not in template:
                        template_errors.append(f"Missing required field: {field}")
                
                # Check parsing strategy validity
                valid_strategies = ['table', 'key_value', 'hierarchical', 'mixed', 'custom']
                strategy = template.get('parsing_strategy')
                if strategy and strategy not in valid_strategies:
                    template_errors.append(f"Invalid parsing strategy: {strategy}")
                
                # Check XML output configuration
                if 'xml_output' not in template:
                    template_errors.append("Missing xml_output configuration")
                
                # Check command patterns
                if not template.get('command_patterns'):
                    template_errors.append("No command patterns specified")
                
            except Exception as e:
                template_errors.append(f"Validation error: {e}")
            
            if template_errors:
                errors[template_path] = template_errors
        
        return errors
    
    def reload_templates(self) -> None:
        """Reload all templates (useful for development)."""
        # Clear caches
        self.command_mappings.clear()
        self.template_metadata.clear()
        self.fuzzy_patterns.clear()
        self.template_engine.template_cache.clear()
        
        # Rediscover templates
        self.discover_templates()
    
    def register_custom_template(self, command_pattern: str, template_path: str) -> None:
        """Register a custom command-to-template mapping.
        
        Args:
            command_pattern: Command pattern to match
            template_path: Path to template file
        """
        self._register_command_pattern(command_pattern, template_path)
        
        # Load template metadata if not already loaded
        if template_path not in self.template_metadata:
            try:
                template = self.template_engine.load_template(template_path)
                self.template_metadata[template_path] = template
            except TemplateError as e:
                print(f"Warning: Failed to load custom template {template_path}: {e}")
    
    def get_conversion_statistics(self) -> Dict[str, int]:
        """Get statistics about template usage and coverage.
        
        Returns:
            Dictionary with conversion statistics
        """
        return {
            'total_templates': len(self.template_metadata),
            'exact_mappings': len(self.command_mappings),
            'fuzzy_patterns': len(self.fuzzy_patterns),
            'base_templates': len(self.template_engine.base_templates)
        }