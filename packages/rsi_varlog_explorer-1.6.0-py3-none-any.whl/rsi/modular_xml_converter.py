"""Modular XML converter using template-based architecture.

This replaces the hardcoded RSIToXMLConverter with a flexible, template-driven system
that can handle hundreds of different command types through configuration.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Union

from .plugin_manager import PluginManager
from .template_engine import TemplateError


class ModularXMLConverter:
    """Modular XML converter using template-based parsing.
    
    This converter automatically discovers and uses appropriate templates
    for different command types, replacing the hardcoded parser system.
    """
    
    def __init__(self, device_client=None, template_dir: Optional[Union[str, Path]] = None,
                 cache_dir: Optional[Union[str, Path]] = None):
        """Initialize the modular XML converter.
        
        Args:
            device_client: MCP Junos device client for live XML reference
            template_dir: Directory containing template files
            cache_dir: Directory to store cached mappings and templates
        """
        self.device_client = device_client
        self.cache_dir = Path(cache_dir) if cache_dir else Path.home() / '.rsi_xml_cache'
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize plugin manager with template engine
        self.plugin_manager = PluginManager(Path(template_dir) if template_dir else None)
        
        # Device integration for XMLRPC mappings
        self.command_mappings: Dict[str, str] = {}  # show_command -> xmlrpc_name
        self.device_xml_cache: Dict[str, str] = {}  # command -> device XML output
        
        # Load cached mappings
        self._load_cache()
        
        # Conversion statistics
        self.conversion_stats = {
            'successful': 0,
            'failed': 0,
            'template_not_found': 0,
            'device_queries': 0
        }
    
    def _load_cache(self) -> None:
        """Load cached mappings from disk."""
        mappings_file = self.cache_dir / 'command_mappings.json'
        if mappings_file.exists():
            try:
                with open(mappings_file, 'r') as f:
                    self.command_mappings = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass  # Use empty mappings if cache is corrupted
    
    def _save_cache(self) -> None:
        """Save mappings to disk cache."""
        mappings_file = self.cache_dir / 'command_mappings.json'
        try:
            with open(mappings_file, 'w') as f:
                json.dump(self.command_mappings, f, indent=2)
        except OSError:
            pass  # Ignore cache save failures
    
    def convert_command_output(self, command: str, text_output: str) -> Optional[str]:
        """Convert command text output to XML using appropriate template.
        
        Args:
            command: Original show command
            text_output: Text output from RSI file
            
        Returns:
            XML formatted output, or None if conversion fails
        """
        try:
            # Use plugin manager to find and apply appropriate template
            xml_output = self.plugin_manager.convert_command(command, text_output)
            
            if xml_output:
                self.conversion_stats['successful'] += 1
                return xml_output
            else:
                self.conversion_stats['template_not_found'] += 1
                # Fallback to basic conversion
                return self._convert_with_fallback(command, text_output)
                
        except Exception as e:
            self.conversion_stats['failed'] += 1
            print(f"Warning: Conversion failed for command '{command}': {e}")
            return self._convert_with_fallback(command, text_output)
    
    def _convert_with_fallback(self, command: str, text_output: str) -> str:
        """Fallback conversion when no template is available.
        
        Args:
            command: Original command
            text_output: Text output
            
        Returns:
            Basic XML structure
        """
        # Create basic XML wrapper
        from xml.etree.ElementTree import Element, SubElement, tostring
        from xml.dom import minidom
        
        root = Element('command-output')
        command_elem = SubElement(root, 'command')
        command_elem.text = command
        
        output_elem = SubElement(root, 'output')
        output_elem.text = text_output
        
        # Format XML
        rough_string = tostring(root, encoding='unicode')
        reparsed = minidom.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ")
    
    def build_command_mappings(self, commands: List[str]) -> None:
        """Build command to XMLRPC mappings using device queries.
        
        Args:
            commands: List of show commands to map
        """
        if not self.device_client:
            print("Warning: No device client available for building mappings")
            return
        
        for command in commands:
            if command not in self.command_mappings:
                try:
                    # Query device for XMLRPC name
                    rpc_command = f"{command} | display xml rpc"
                    rpc_output = self.device_client.execute_junos_command(
                        router_name="vsrx1",
                        command=rpc_command
                    )
                    
                    # Extract XMLRPC method name
                    xmlrpc_name = self._extract_xmlrpc_name(rpc_output)
                    if xmlrpc_name:
                        self.command_mappings[command] = xmlrpc_name
                        self.conversion_stats['device_queries'] += 1
                    
                    # Also cache device XML output for reference
                    xml_command = f"{command} | display xml"
                    xml_output = self.device_client.execute_junos_command(
                        router_name="vsrx1",
                        command=xml_command
                    )
                    
                    if xml_output:
                        self.device_xml_cache[command] = xml_output
                        
                except Exception as e:
                    print(f"Warning: Failed to query device for command '{command}': {e}")
        
        # Save updated mappings
        self._save_cache()
    
    def _extract_xmlrpc_name(self, rpc_output: str) -> Optional[str]:
        """Extract XMLRPC method name from device output.
        
        Args:
            rpc_output: Raw output from '| display xml rpc' command
            
        Returns:
            XMLRPC method name or None if not found
        """
        import xml.etree.ElementTree as ET
        import re
        
        try:
            # Parse the RPC XML output
            root = ET.fromstring(rpc_output)
            
            # If root is rpc-reply, get its first child element
            if root.tag == 'rpc-reply':
                for child in root:
                    return child.tag
            
            # Or find rpc-reply element and get its first child
            for element in root.iter():
                if element.tag == 'rpc-reply':
                    for child in element:
                        return child.tag
                        
        except ET.ParseError:
            pass
            
        # Fallback: regex pattern matching
        patterns = [
            r'<([^>]+)>',  # First XML tag
            r'<rpc-reply[^>]*>\s*<([^>\s]+)',  # First tag after rpc-reply
        ]
        
        for pattern in patterns:
            match = re.search(pattern, rpc_output)
            if match:
                return match.group(1)
                
        return None
    
    def get_xmlrpc_name(self, command: str) -> Optional[str]:
        """Get XMLRPC method name for a command.
        
        Args:
            command: Show command string
            
        Returns:
            XMLRPC method name or None if not mapped
        """
        return self.command_mappings.get(command)
    
    def get_supported_commands(self) -> List[str]:
        """Get list of all supported command patterns.
        
        Returns:
            List of supported command patterns from templates
        """
        return self.plugin_manager.get_supported_commands()
    
    def get_template_info(self, command: str) -> Optional[Dict]:
        """Get template information for a command.
        
        Args:
            command: Command string
            
        Returns:
            Template metadata if found
        """
        template_path = self.plugin_manager.find_template_for_command(command)
        if template_path:
            return self.plugin_manager.get_template_info(template_path)
        return None
    
    def validate_templates(self) -> Dict[str, List[str]]:
        """Validate all loaded templates.
        
        Returns:
            Dictionary mapping template paths to error messages
        """
        return self.plugin_manager.validate_templates()
    
    def reload_templates(self) -> None:
        """Reload all templates (useful for development)."""
        self.plugin_manager.reload_templates()
    
    def get_conversion_statistics(self) -> Dict[str, any]:
        """Get conversion statistics and template information.
        
        Returns:
            Dictionary with conversion and template statistics
        """
        template_stats = self.plugin_manager.get_conversion_statistics()
        
        return {
            'conversion_stats': self.conversion_stats,
            'template_stats': template_stats,
            'cached_mappings': len(self.command_mappings),
            'cached_xml_outputs': len(self.device_xml_cache)
        }
    
    def list_templates(self) -> Dict[str, Dict]:
        """List all available templates with metadata.
        
        Returns:
            Dictionary mapping template paths to metadata
        """
        return self.plugin_manager.list_templates()
    
    def add_custom_template(self, command_pattern: str, template_path: str) -> None:
        """Add a custom command-to-template mapping.
        
        Args:
            command_pattern: Command pattern to match
            template_path: Path to template file
        """
        self.plugin_manager.register_custom_template(command_pattern, template_path)
    
    def get_device_xml_reference(self, command: str) -> Optional[str]:
        """Get cached device XML output for reference.
        
        Args:
            command: Command string
            
        Returns:
            Device XML output if cached, None otherwise
        """
        return self.device_xml_cache.get(command)
    
    def export_template_mappings(self, output_file: Union[str, Path]) -> None:
        """Export current command-to-template mappings.
        
        Args:
            output_file: File to write mappings to
        """
        mappings = {}
        
        for command in self.get_supported_commands():
            template_path = self.plugin_manager.find_template_for_command(command)
            if template_path:
                mappings[command] = template_path
        
        with open(output_file, 'w') as f:
            json.dump(mappings, f, indent=2)
    
    def import_template_mappings(self, input_file: Union[str, Path]) -> None:
        """Import command-to-template mappings from file.
        
        Args:
            input_file: File to read mappings from
        """
        with open(input_file, 'r') as f:
            mappings = json.load(f)
        
        for command_pattern, template_path in mappings.items():
            self.add_custom_template(command_pattern, template_path)