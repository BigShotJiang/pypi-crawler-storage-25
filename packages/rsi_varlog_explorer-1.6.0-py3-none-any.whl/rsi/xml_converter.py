import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
from xml.dom import minidom

from .parser import RSIParser
from .text_parsers import (
    ShowVersionParser,
    ShowInterfacesParser,
    ShowSystemParser,
    ShowRouteParser,
)


class XMLConversionError(Exception):
    """Exception raised for XML conversion errors."""

    pass


class RSIToXMLConverter:
    """Converts RSI text command outputs to XML format using device reference.

    This class provides functionality to:
    - Map show commands to their XMLRPC method names
    - Convert text command outputs to XML using device-generated templates
    - Cache XML templates and command mappings for performance
    """

    def __init__(
        self, device_client=None, cache_dir: Optional[Union[str, Path]] = None
    ):
        """Initialize the RSI to XML converter.

        Args:
            device_client: MCP Junos device client for live XML reference
            cache_dir: Directory to store cached mappings and templates
        """
        self.device_client = device_client
        self.cache_dir = (
            Path(cache_dir) if cache_dir else Path.home() / ".rsi_xml_cache"
        )
        self.cache_dir.mkdir(parents=True, exist_ok=True)

        # In-memory caches
        self.command_mappings: Dict[str, str] = {}  # show_command -> xmlrpc_name
        self.xml_templates: Dict[str, ET.Element] = {}  # command -> XML template
        self.text_parsers: Dict[str, callable] = {}  # command_type -> parser function

        # Load cached data
        self._load_cache()

        # Initialize built-in text parsers
        self._init_text_parsers()

        # Initialize parser instances
        self.version_parser = ShowVersionParser()
        self.interfaces_parser = ShowInterfacesParser()
        self.system_parser = ShowSystemParser()
        self.route_parser = ShowRouteParser()

    def _load_cache(self) -> None:
        """Load cached mappings and templates from disk."""
        mappings_file = self.cache_dir / "command_mappings.json"
        if mappings_file.exists():
            try:
                with open(mappings_file, "r") as f:
                    self.command_mappings = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass  # Use empty mappings if cache is corrupted

    def _save_cache(self) -> None:
        """Save mappings and templates to disk cache."""
        mappings_file = self.cache_dir / "command_mappings.json"
        try:
            with open(mappings_file, "w") as f:
                json.dump(self.command_mappings, f, indent=2)
        except OSError:
            pass  # Ignore cache save failures

    def _init_text_parsers(self) -> None:
        """Initialize built-in text parsers for common command types."""
        self.text_parsers = {
            "show_version": self._parse_show_version,
            "show_interfaces": self._parse_show_interfaces,
            "show_system": self._parse_show_system,
            "show_route": self._parse_show_route,
            "default": self._parse_default,
        }

    def build_command_mappings(self, commands: List[str]) -> None:
        """Build command to XMLRPC mappings using device queries.

        Args:
            commands: List of show commands to map

        Raises:
            XMLConversionError: If device client is not available
        """
        if not self.device_client:
            raise XMLConversionError("Device client required for building mappings")

        for command in commands:
            if command not in self.command_mappings:
                try:
                    # Get XMLRPC name using '| display xml rpc'
                    rpc_command = f"{command} | display xml rpc"
                    rpc_output = self.device_client.execute_junos_command(
                        router_name="vsrx1", command=rpc_command
                    )

                    # Extract XMLRPC method name from output
                    xmlrpc_name = self._extract_xmlrpc_name(rpc_output)
                    if xmlrpc_name:
                        self.command_mappings[command] = xmlrpc_name

                    # Get XML template using '| display xml'
                    xml_command = f"{command} | display xml"
                    xml_output = self.device_client.execute_junos_command(
                        router_name="vsrx1", command=xml_command
                    )

                    # Parse and store XML template
                    xml_template = self._parse_xml_template(xml_output)
                    if xml_template is not None:
                        self.xml_templates[command] = xml_template

                except Exception as e:
                    # Log warning but continue with other commands
                    print(f"Warning: Failed to map command '{command}': {e}")

        # Save updated mappings to cache
        self._save_cache()

    def _extract_xmlrpc_name(self, rpc_output: str) -> Optional[str]:
        """Extract XMLRPC method name from device RPC output.

        Args:
            rpc_output: Raw output from '| display xml rpc' command

        Returns:
            XMLRPC method name or None if not found
        """
        # Look for <rpc-reply> and extract method name from first element
        try:
            # Parse the RPC XML output
            root = ET.fromstring(rpc_output)

            # If root is rpc-reply, get its first child element
            if root.tag == "rpc-reply":
                for child in root:
                    return child.tag

            # Or find rpc-reply element and get its first child
            for element in root.iter():
                if element.tag == "rpc-reply":
                    for child in element:
                        return child.tag

        except ET.ParseError:
            pass

        # Fallback: regex pattern matching for common RPC formats
        patterns = [
            r"<([^>]+)>",  # First XML tag
            r"<rpc-reply[^>]*>\s*<([^>\s]+)",  # First tag after rpc-reply
        ]

        for pattern in patterns:
            match = re.search(pattern, rpc_output)
            if match:
                return match.group(1)

        return None

    def _parse_xml_template(self, xml_output: str) -> Optional[ET.Element]:
        """Parse XML output from device into template structure.

        Args:
            xml_output: Raw XML output from device

        Returns:
            Parsed XML element tree or None if parsing fails
        """
        try:
            # Clean up XML output (remove CLI headers/footers)
            clean_xml = self._clean_xml_output(xml_output)
            return ET.fromstring(clean_xml)
        except ET.ParseError:
            return None

    def _clean_xml_output(self, xml_output: str) -> str:
        """Clean device XML output by removing CLI formatting.

        Args:
            xml_output: Raw XML output with potential CLI formatting

        Returns:
            Clean XML string
        """
        lines = xml_output.strip().split("\n")
        xml_lines = []
        in_xml = False

        for line in lines:
            # Look for XML start
            if "<rpc-reply" in line or line.strip().startswith("<?xml"):
                in_xml = True

            if in_xml:
                xml_lines.append(line)

            # Look for XML end
            if "</rpc-reply>" in line:
                break

        return "\n".join(xml_lines)

    def convert_command_output(self, command: str, text_output: str) -> str:
        """Convert text command output to XML format.

        Args:
            command: Original show command
            text_output: Text output from RSI file

        Returns:
            XML formatted output as string

        Raises:
            XMLConversionError: If conversion fails
        """
        try:
            # Determine command type for appropriate parser
            command_type = self._classify_command(command)
            parser_func = self.text_parsers.get(
                command_type, self.text_parsers["default"]
            )

            # Parse text output into structured data
            parsed_data = parser_func(text_output)

            # Get XML template if available
            xml_template = self.xml_templates.get(command)

            # Generate XML from parsed data and template
            xml_element = self._generate_xml(command, parsed_data, xml_template)

            # Convert to formatted string
            return self._format_xml(xml_element)

        except Exception as e:
            raise XMLConversionError(f"Failed to convert command '{command}': {e}")

    def _classify_command(self, command: str) -> str:
        """Classify command to determine appropriate parser.

        Args:
            command: Show command string

        Returns:
            Command classification string
        """
        command_lower = command.lower()

        if "show version" in command_lower:
            return "show_version"
        elif "show interfaces" in command_lower:
            return "show_interfaces"
        elif "show system" in command_lower:
            return "show_system"
        elif "show route" in command_lower:
            return "show_route"
        else:
            return "default"

    def _generate_xml(
        self, command: str, parsed_data: dict, template: Optional[ET.Element] = None
    ) -> ET.Element:
        """Generate XML element from parsed data and template.

        Args:
            command: Original command
            parsed_data: Structured data from text parser
            template: XML template from device (optional)

        Returns:
            Generated XML element
        """
        if template is not None:
            # Use template-based generation
            return self._populate_xml_template(template, parsed_data)
        else:
            # Generate basic XML structure
            return self._generate_basic_xml(command, parsed_data)

    def _populate_xml_template(self, template: ET.Element, data: dict) -> ET.Element:
        """Populate XML template with parsed data values.

        Args:
            template: XML template structure
            data: Parsed data dictionary

        Returns:
            Populated XML element
        """
        # Create a copy of the template
        result = ET.fromstring(ET.tostring(template))

        # Recursively populate template with data
        self._populate_element(result, data)

        return result

    def _populate_element(self, element: ET.Element, data: dict) -> None:
        """Recursively populate XML element with data.

        Args:
            element: XML element to populate
            data: Data dictionary
        """
        # Simple implementation - can be enhanced based on template structure
        for key, value in data.items():
            # Find matching child elements
            for child in element:
                if child.tag.lower().replace("-", "_") == key.lower().replace("-", "_"):
                    if isinstance(value, dict):
                        self._populate_element(child, value)
                    elif isinstance(value, list):
                        # Handle list data (e.g., interfaces)
                        self._populate_list_element(child, value)
                    else:
                        child.text = str(value)
                        break

    def _populate_list_element(self, element: ET.Element, data_list: List) -> None:
        """Populate XML element with list data.

        Args:
            element: Parent XML element
            data_list: List of data items
        """
        # For list data, duplicate the element structure for each item
        parent = element.getparent()
        if parent is not None:
            for item in data_list[1:]:  # Keep first element, add copies for rest
                new_element = ET.fromstring(ET.tostring(element))
                if isinstance(item, dict):
                    self._populate_element(new_element, item)
                parent.append(new_element)

            # Populate the original element with first item
            if data_list and isinstance(data_list[0], dict):
                self._populate_element(element, data_list[0])

    def _generate_basic_xml(self, command: str, data: dict) -> ET.Element:
        """Generate basic XML structure when no template is available.

        Args:
            command: Original command
            data: Parsed data dictionary

        Returns:
            Basic XML element structure
        """
        # Create root element based on command
        root_name = self._get_root_element_name(command)
        root = ET.Element(root_name)

        # Recursively build XML from data
        self._build_xml_from_data(root, data)

        return root

    def _get_root_element_name(self, command: str) -> str:
        """Get appropriate root element name for command.

        Args:
            command: Show command

        Returns:
            Root element name
        """
        # Use XMLRPC mapping if available
        xmlrpc_name = self.command_mappings.get(command)
        if xmlrpc_name:
            return xmlrpc_name

        # Fallback: derive from command
        clean_command = command.lower().replace("show ", "").replace(" ", "-")
        return f"{clean_command}-information"

    def _build_xml_from_data(self, parent: ET.Element, data: dict) -> None:
        """Recursively build XML elements from data dictionary.

        Args:
            parent: Parent XML element
            data: Data dictionary to convert
        """
        for key, value in data.items():
            element_name = key.replace(" ", "-").replace("_", "-")

            if isinstance(value, dict):
                child = ET.SubElement(parent, element_name)
                self._build_xml_from_data(child, value)
            elif isinstance(value, list):
                for item in value:
                    child = ET.SubElement(parent, element_name)
                    if isinstance(item, dict):
                        self._build_xml_from_data(child, item)
                    else:
                        child.text = str(item)
            else:
                child = ET.SubElement(parent, element_name)
                child.text = str(value)

    def _format_xml(self, element: ET.Element) -> str:
        """Format XML element as indented string.

        Args:
            element: XML element to format

        Returns:
            Formatted XML string
        """
        rough_string = ET.tostring(element, encoding="unicode")
        reparsed = minidom.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ")

    def get_xmlrpc_name(self, command: str) -> Optional[str]:
        """Get XMLRPC method name for a show command.

        Args:
            command: Show command string

        Returns:
            XMLRPC method name or None if not mapped
        """
        return self.command_mappings.get(command)

    def list_mapped_commands(self) -> List[str]:
        """Get list of commands that have been mapped to XMLRPC.

        Returns:
            List of mapped command strings
        """
        return list(self.command_mappings.keys())

    # Text parser implementations
    def _parse_show_version(self, text_output: str) -> dict:
        """Parse show version command output."""
        return self.version_parser.parse(text_output)

    def _parse_show_interfaces(self, text_output: str) -> dict:
        """Parse show interfaces command output."""
        # Determine if this is terse or extensive output
        if (
            "Interface" in text_output
            and "Admin" in text_output
            and "Link" in text_output
        ):
            return self.interfaces_parser.parse_terse(text_output)
        else:
            return self.interfaces_parser.parse_extensive(text_output)

    def _parse_show_system(self, text_output: str) -> dict:
        """Parse show system command output."""
        # Handle different system commands
        if "Current time:" in text_output or "System booted:" in text_output:
            return self.system_parser.parse_uptime(text_output)
        else:
            # Default system parsing
            return {"system-information": {"output": text_output}}

    def _parse_show_route(self, text_output: str) -> dict:
        """Parse show route command output."""
        # Handle route summary vs detailed route output
        if "routes:" in text_output.lower():
            return self.route_parser.parse_summary(text_output)
        else:
            # Default route parsing
            return {"route-information": {"output": text_output}}

    def _parse_default(self, text_output: str) -> dict:
        """Default parser for unknown command types."""
        return {"command-output": {"output": text_output}}
