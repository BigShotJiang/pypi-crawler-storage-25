"""Text parsers for converting Junos command output to structured data."""

import re
from typing import Dict, List, Optional, Any


class TextParsingError(Exception):
    """Exception raised for text parsing errors."""

    pass


class JunosTextParser:
    """Base class for Junos text output parsers."""

    @staticmethod
    def parse_key_value_pairs(text: str, separator: str = ":") -> Dict[str, str]:
        """Parse key-value pairs from text.

        Args:
            text: Input text containing key-value pairs
            separator: Separator between key and value

        Returns:
            Dictionary of parsed key-value pairs
        """
        result = {}
        lines = text.strip().split("\n")

        for line in lines:
            if separator in line:
                key, value = line.split(separator, 1)
                key = key.strip()
                value = value.strip()
                if key and value:
                    result[key] = value

        return result

    @staticmethod
    def parse_table(text: str, skip_header_lines: int = 1) -> List[Dict[str, str]]:
        """Parse tabular data from text.

        Args:
            text: Input text containing tabular data
            skip_header_lines: Number of header lines to skip

        Returns:
            List of dictionaries representing table rows
        """
        lines = text.strip().split("\n")
        if len(lines) < skip_header_lines + 1:
            return []

        # Extract header to determine column positions
        if skip_header_lines > 0:
            header_line = lines[skip_header_lines - 1]
            headers = header_line.split()
        else:
            return []

        # Parse data rows
        result = []
        for line in lines[skip_header_lines:]:
            if not line.strip():
                continue

            # Split line into columns based on whitespace
            values = line.split()
            if len(values) >= len(headers):
                row = {}
                for i, header in enumerate(headers):
                    if i < len(values):
                        row[header] = values[i]
                result.append(row)

        return result


class ShowVersionParser(JunosTextParser):
    """Parser for 'show version' command output."""

    def parse(self, text: str) -> Dict[str, Any]:
        """Parse show version output.

        Args:
            text: Show version command output

        Returns:
            Structured version information
        """
        result = {"software-information": {}}

        lines = text.strip().split("\n")
        current_section = None
        packages = []

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Parse hostname
            if line.startswith("Hostname:"):
                result["software-information"]["hostname"] = line.split(":", 1)[
                    1
                ].strip()

            # Parse model
            elif line.startswith("Model:"):
                result["software-information"]["product-model"] = line.split(":", 1)[
                    1
                ].strip()

            # Parse Junos version
            elif line.startswith("Junos:"):
                result["software-information"]["junos-version"] = line.split(":", 1)[
                    1
                ].strip()

            # Parse package information
            elif "JUNOS" in line and "[" in line and "]" in line:
                # Extract package name and version
                match = re.match(r"^(.+?)\s+\[(.+?)\]$", line)
                if match:
                    package_name = match.group(1).strip()
                    package_version = match.group(2).strip()
                    packages.append({"name": package_name, "version": package_version})

        if packages:
            result["software-information"]["package-information"] = packages

        return result


class ShowInterfacesParser(JunosTextParser):
    """Parser for 'show interfaces' command output."""

    def parse_terse(self, text: str) -> Dict[str, Any]:
        """Parse show interfaces terse output.

        Args:
            text: Show interfaces terse output

        Returns:
            Structured interface information matching device XML format
        """
        result = {"interface-information": {"physical-interface": []}}

        lines = text.strip().split("\n")
        header_found = False
        current_physical = None
        current_logical = None
        physical_interfaces = {}  # name -> interface_dict

        i = 0
        while i < len(lines):
            line = lines[i].rstrip()
            
            # Look for the header line
            if not header_found and "Interface" in line and "Admin" in line and "Link" in line:
                header_found = True
                i += 1
                continue

            if not header_found:
                i += 1
                continue

            # Skip empty lines
            if not line.strip():
                i += 1
                continue

            # Parse interface line
            parts = line.split()
            if len(parts) >= 2:  # At minimum we need interface name and admin status
                interface_name = parts[0]
                admin_status = parts[1] if len(parts) > 1 else ""
                oper_status = parts[2] if len(parts) > 2 else admin_status
                protocol = parts[3] if len(parts) > 3 else ""
                local_addr = parts[4] if len(parts) > 4 else ""
                remote_addr = parts[5] if len(parts) > 5 else ""

                # Determine if this is a physical or logical interface
                if "." in interface_name:
                    # Logical interface
                    physical_name = interface_name.split(".")[0]
                    
                    # Ensure physical interface exists
                    if physical_name not in physical_interfaces:
                        physical_interfaces[physical_name] = {
                            "name": physical_name,
                            "admin-status": admin_status,
                            "oper-status": oper_status,
                            "logical-interface": []
                        }

                    # Create logical interface
                    logical_interface = {
                        "name": interface_name,
                        "admin-status": admin_status,
                        "oper-status": oper_status,
                        "filter-information": {},
                    }

                    # Add address families if protocol is specified
                    if protocol or local_addr:
                        logical_interface["address-family"] = []
                        
                        if protocol:
                            addr_family = {
                                "address-family-name": protocol
                            }
                            
                            if local_addr:
                                addr_family["interface-address"] = []
                                
                                # Parse address and destination
                                address_entry = {"ifa-local": local_addr}
                                if remote_addr and remote_addr != "-->":
                                    address_entry["ifa-destination"] = remote_addr
                                elif "-->" in line:
                                    # Handle "127.0.0.1 --> 0/0" format
                                    arrow_parts = line.split("-->")
                                    if len(arrow_parts) > 1:
                                        dest = arrow_parts[1].strip()
                                        if dest:
                                            address_entry["ifa-destination"] = dest
                                
                                addr_family["interface-address"].append(address_entry)
                                
                                # Check for additional addresses on following lines
                                j = i + 1
                                while j < len(lines) and lines[j].strip():
                                    next_line = lines[j].strip()
                                    next_parts = next_line.split()
                                    
                                    # Check if this is a continuation line (starts with spaces in original)
                                    if (lines[j].startswith(" ") or lines[j].startswith("\t")) and next_parts:
                                        # This might be additional address info
                                        if next_parts[0] in ["inet", "inet6"]:
                                            # New address family on continuation line
                                            additional_family = {
                                                "address-family-name": next_parts[0]
                                            }
                                            if len(next_parts) > 1:
                                                additional_family["interface-address"] = []
                                                addr_entry = {"ifa-local": next_parts[1]}
                                                if len(next_parts) > 3 and next_parts[2] == "-->":
                                                    addr_entry["ifa-destination"] = next_parts[3]
                                                additional_family["interface-address"].append(addr_entry)
                                            logical_interface["address-family"].append(additional_family)
                                            i = j  # Skip this line in main loop
                                        elif self._looks_like_ip_address(next_parts[0]):
                                            # Additional IP address for same family
                                            addr_entry = {"ifa-local": next_parts[0]}
                                            if len(next_parts) > 2 and next_parts[1] == "-->":
                                                addr_entry["ifa-destination"] = next_parts[2]
                                            addr_family["interface-address"].append(addr_entry)
                                            i = j  # Skip this line in main loop
                                        else:
                                            break
                                    else:
                                        break
                                    j += 1
                            
                            logical_interface["address-family"].append(addr_family)

                    physical_interfaces[physical_name]["logical-interface"].append(logical_interface)
                    current_physical = physical_interfaces[physical_name]
                    current_logical = logical_interface
                else:
                    # Physical interface
                    if interface_name not in physical_interfaces:
                        physical_interfaces[interface_name] = {
                            "name": interface_name,
                            "admin-status": admin_status,
                            "oper-status": oper_status,
                            "logical-interface": []
                        }
                    current_physical = physical_interfaces[interface_name]
                    current_logical = None

            i += 1

        # Convert to list format expected by XML structure
        result["interface-information"]["physical-interface"] = list(physical_interfaces.values())
        return result

    def _looks_like_ip_address(self, addr: str) -> bool:
        """Check if a string looks like an IP address."""
        import re
        # Simple IP address pattern
        ip_pattern = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}'
        return bool(re.match(ip_pattern, addr))

    def parse_extensive(self, text: str) -> Dict[str, Any]:
        """Parse show interfaces extensive output.

        Args:
            text: Show interfaces extensive output

        Returns:
            Structured interface information
        """
        result = {"interface-information": {"physical-interface": []}}

        lines = text.strip().split("\n")
        current_interface = None

        for line in lines:
            # Look for physical interface header
            phys_match = re.match(r"^Physical interface:\s*([^,]+)", line)
            if phys_match:
                if current_interface:
                    result["interface-information"]["physical-interface"].append(
                        current_interface
                    )

                current_interface = {
                    "name": phys_match.group(1).strip(),
                    "description": "",
                    "admin-status": "",
                    "oper-status": "",
                    "logical-interface": [],
                }

                # Parse status information from the same line
                if "Enabled," in line:
                    current_interface["admin-status"] = "up"
                elif "Disabled," in line:
                    current_interface["admin-status"] = "down"

                if "Physical link is Up" in line:
                    current_interface["oper-status"] = "up"
                elif "Physical link is Down" in line:
                    current_interface["oper-status"] = "down"

                continue

            # Look for logical interface
            if current_interface:
                logical_match = re.match(r"^\s+Logical interface\s+([^\s]+)", line)
                if logical_match:
                    logical_interface = {
                        "name": logical_match.group(1),
                        "description": "",
                        "admin-status": "",
                        "oper-status": "",
                    }
                    current_interface["logical-interface"].append(logical_interface)

        # Add the last interface
        if current_interface:
            result["interface-information"]["physical-interface"].append(
                current_interface
            )

        return result


class ShowSystemParser(JunosTextParser):
    """Parser for 'show system' command variants."""

    def parse_uptime(self, text: str) -> Dict[str, Any]:
        """Parse show system uptime output.

        Args:
            text: Show system uptime output

        Returns:
            Structured uptime information
        """
        result = {"system-uptime-information": {}}

        lines = text.strip().split("\n")

        for line in lines:
            line = line.strip()
            if not line:
                continue

            if line.startswith("Current time:"):
                result["system-uptime-information"]["current-time"] = line.split(
                    ":", 1
                )[1].strip()

            elif line.startswith("System booted:"):
                result["system-uptime-information"]["boot-time"] = line.split(":", 1)[
                    1
                ].strip()

            elif line.startswith("System uptime:"):
                result["system-uptime-information"]["uptime"] = line.split(":", 1)[
                    1
                ].strip()

            elif "users" in line and "load average" in line:
                # Parse load average and user count
                parts = line.split(",")
                for part in parts:
                    part = part.strip()
                    if "users" in part:
                        users_match = re.search(r"(\d+)\s+users?", part)
                        if users_match:
                            result["system-uptime-information"]["active-users"] = (
                                users_match.group(1)
                            )
                    elif "load average" in part:
                        # Handle different load average formats
                        load_matches = re.findall(r"([\d.]+)", part)
                        if load_matches:
                            result["system-uptime-information"]["load-average-1"] = (
                                load_matches[0]
                            )

        return result


class ShowRouteParser(JunosTextParser):
    """Parser for 'show route' command output."""

    def parse_summary(self, text: str) -> Dict[str, Any]:
        """Parse show route summary output.

        Args:
            text: Show route summary output

        Returns:
            Structured route summary information
        """
        result = {"route-summary-information": {"route-table": []}}

        lines = text.strip().split("\n")
        current_table = None

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Look for routing table entries in format: "inet.0: 8 destinations, 8 routes..."
            route_match = re.match(
                r"^([^:]+):\s*(\d+)\s+destinations?,\s*(\d+)\s+routes?\s*\((\d+)\s+active,\s*(\d+)\s+holddown,\s*(\d+)\s+hidden\)",
                line,
            )
            if route_match:
                table_name = route_match.group(1)
                destinations = int(route_match.group(2))
                routes = int(route_match.group(3))
                active = int(route_match.group(4))
                holddown = int(route_match.group(5))
                hidden = int(route_match.group(6))

                current_table = {
                    "table-name": table_name,
                    "destination-count": destinations,
                    "route-count": routes,
                    "active-route-count": active,
                    "holddown-route-count": holddown,
                    "hidden-route-count": hidden,
                }
                result["route-summary-information"]["route-table"].append(current_table)

        return result
