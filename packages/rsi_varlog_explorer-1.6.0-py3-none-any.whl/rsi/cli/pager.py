"""Pager utility for handling large CLI outputs."""

import os
import re
import shutil
import sys
from pathlib import Path
from typing import List, Optional
import termios
import tty


class Pager:
    """Smart pager that provides Junos-like paging behavior."""

    def __init__(
        self,
        enabled: bool = True,
        threshold_ratio: float = 0.8,
        less_options: Optional[str] = None,
        less_prompt: str = "---(more)---",
    ) -> None:
        """Initialize pager with configuration.

        Args:
            enabled: Whether paging is enabled
            threshold_ratio: Ratio of terminal height to trigger paging (0.0-1.0)
            less_options: Reserved for backward compatibility
            less_prompt: Prompt string shown by less while paging
        """
        self.enabled = enabled and self._is_paging_available()
        self.threshold_ratio = max(0.0, min(1.0, threshold_ratio))
        self.less_options = less_options or "-RFSXE"
        self.less_prompt = less_prompt
        self._terminal_height = self._get_terminal_height()

    def _is_paging_available(self) -> bool:
        """Check if paging is available and appropriate."""
        # Don't page if not in a TTY (e.g., piped output, redirected)
        if not sys.stdout.isatty():
            return False

        return True

    def _get_terminal_height(self) -> int:
        """Get current terminal height in lines."""
        try:
            return shutil.get_terminal_size().lines
        except OSError:
            return 24  # Fallback to reasonable default

    def _count_lines(self, text: str) -> int:
        """Count visible lines in text, accounting for ANSI escape sequences."""
        if not text:
            return 0

        lines = text.split("\n")
        return len(lines)

    def _should_page(self, text: str) -> bool:
        """Determine if text should be paged."""
        if not self.enabled:
            return False

        line_count = self._count_lines(text)
        threshold = int(self._terminal_height * self.threshold_ratio)

        return line_count > threshold

    def display(self, text: str) -> None:
        """Display text, using pager if appropriate.

        Args:
            text: Text to display, may contain ANSI escape sequences
        """
        self.display_with_mode(text, force=False)

    def display_with_mode(self, text: str, force: bool = False) -> None:
        """Display text with optional forced automore behavior.

        Args:
            text: Text to display
            force: If True, always enter automore when paging is enabled
        """
        if not text:
            return

        if self.enabled and (force or self._should_page(text)):
            self._page_text(text)
        else:
            self._direct_output(text)

    def _apply_filters(
        self,
        lines: List[str],
        include_regex: Optional[re.Pattern],
        exclude_regex: Optional[re.Pattern],
    ) -> List[str]:
        """Apply include/exclude filters used by automore."""
        filtered = lines
        if include_regex is not None:
            filtered = [line for line in filtered if include_regex.search(line)]
        if exclude_regex is not None:
            filtered = [line for line in filtered if not exclude_regex.search(line)]
        return filtered

    def _read_line_input(self, prompt: str) -> str:
        """Read a full line from terminal while paging."""
        if not sys.stdin.isatty():
            return ""

        sys.stdout.write(prompt)
        sys.stdout.flush()
        try:
            return sys.stdin.readline().rstrip("\n")
        except KeyboardInterrupt:
            return ""

    def _find_match_index(
        self,
        lines: List[str],
        start_idx: int,
        pattern: re.Pattern,
        forward: bool,
    ) -> Optional[int]:
        """Find next/previous index that matches regex pattern."""
        if not lines:
            return None

        if forward:
            for idx in range(start_idx + 1, len(lines)):
                if pattern.search(lines[idx]):
                    return idx
        else:
            for idx in range(start_idx - 1, -1, -1):
                if pattern.search(lines[idx]):
                    return idx
        return None

    def _show_automore_help(self) -> None:
        """Display Junos-style automore help summary."""
        help_text = [
            "                                                                    ---(Help for CLI automore)---",
            "    Clear all match and except strings:                          c or C",
            "    Display all line matching a regexp:                 m or M <string>",
            "    Display all lines except those matching a regexp:   e or E <string>",
            "    Display this help text:                                           h",
            "    Don't hold in automore at bottom of output:                       N",
            "    Hold in automore at bottom of output:                             H",
            "    Move down half display:                               TAB, d, or ^D",
            "    Move down one line:             Enter, j, ^N, ^X, ^Z, or Down-Arrow",
            "    Move down one page:                    Space, f, ^F, or Right-Arrow",
            "    Move to bottom of output:                             G, ^E, or End",
            "    Move to top of output:                               g, ^A, or Home",
            "    Move up half display:                                       u or ^U",
            "    Move up one line:             k, Delete, Backspace, ^P, or Up-Arrow",
            "    Move up one page:                              b, ^B, or Left-Arrow",
            "    Quit automore:                                             q, Q, ^K",
            "    Redraw display:                                            ^L or ^R",
            "    Repeat a keystroke command 1 to 9 times:                  Meta-1..9",
            "    Repeat last search:                                               n",
            "    Save output to a file:                        s or S <filename/url>",
            "    Search backwards thru the output:                         ?<string>",
            "    Search forwards thru the output:                          /<string>",
            "---(End of Help)---",
        ]
        self._direct_output("\n".join(help_text))

    def _page_text(self, text: str) -> None:
        """Page text using an internal Junos-style automore pager."""
        original_lines = text.split("\n")
        page_size = max(1, self._terminal_height - 1)
        half_page = max(1, page_size // 2)
        window_start = 0

        include_regex: Optional[re.Pattern] = None
        exclude_regex: Optional[re.Pattern] = None
        last_search_regex: Optional[re.Pattern] = None
        last_search_forward = True
        last_found_line: Optional[int] = None  # track exact line for n/N repeat
        hold_at_bottom = False
        just_navigated = False  # suppress auto-exit on the iteration after explicit navigation

        try:
            while True:
                lines = self._apply_filters(original_lines, include_regex, exclude_regex)
                total_lines = len(lines)

                if total_lines == 0:
                    self._direct_output("(no matching lines)")
                    window_start = 0
                else:
                    max_start = max(0, total_lines - page_size)
                    window_start = max(0, min(window_start, max_start))
                    window_end = min(window_start + page_size, total_lines)
                    page = "\n".join(lines[window_start:window_end])
                    at_end = window_end >= total_lines

                    if page:
                        self._direct_output(page)

                    if at_end and not hold_at_bottom and not just_navigated:
                        break
                    just_navigated = False

                # Build prompt with percentage like real MX960
                if total_lines > 0:
                    pct = int(window_end * 100 / total_lines) if total_lines > 0 else 100
                    if pct >= 100:
                        base_prompt = "---(more 100%)---"
                    else:
                        base_prompt = f"---(more {pct}%)---"
                else:
                    base_prompt = self.less_prompt
                if include_regex is not None or exclude_regex is not None:
                    prompt = base_prompt.replace("---(more", "---(more[filtered]")
                else:
                    prompt = base_prompt

                sys.stdout.write(prompt)
                sys.stdout.flush()
                key = self._read_single_key()
                sys.stdout.write("\r" + (" " * len(prompt)) + "\r")
                sys.stdout.flush()

                if key in ("q", "Q", "\x0b", "\x03"):  # q, Q, ^K, Ctrl+C
                    break
                if key in ("\x0c", "\x12"):  # ^L or ^R — redraw (reloop)
                    continue
                if False:  # placeholder (unreachable)
                    break

                # Down navigation
                if key in (" ", "f", "F", "\x06", "\x1b[C"):  # Space/f/Ctrl+F/Right-Arrow
                    window_start += page_size
                    continue
                if key in ("\n", "\r", "j", "J", "\x0e", "\x18", "\x1a", "\x1b[B"):  # Enter/j/^N/^X/^Z/Down-Arrow
                    window_start += 1
                    continue
                if key in ("\t", "d", "D", "\x04"):  # TAB/d/Ctrl+D
                    window_start += half_page
                    continue

                # Up navigation
                if key in ("b", "B", "\x02", "\x1b[D"):  # b/^B/Left-Arrow
                    window_start -= page_size
                    continue
                if key in ("u", "U", "\x15"):  # u/Ctrl+U
                    window_start -= half_page
                    continue
                if key in ("k", "\x7f", "\x08", "\x10", "\x1b[A"):  # k/Delete/Backspace/^P/Up-Arrow
                    window_start -= 1
                    continue

                if key in ("g", "\x01"):  # g or Ctrl+A or Home
                    window_start = 0
                    continue
                if key in ("G", "\x05"):  # G or Ctrl+E or End
                    window_start = max(0, total_lines - page_size)
                    just_navigated = True
                    continue

                # Hold behavior at end
                if key == "N":
                    hold_at_bottom = False
                    continue
                if key == "H":
                    hold_at_bottom = True
                    continue

                # Help
                if key == "h":
                    self._show_automore_help()
                    continue

                # Include/exclude filter
                if key in ("m", "M"):
                    pattern = self._read_line_input("Match for: ")
                    if pattern:
                        try:
                            include_regex = re.compile(pattern, re.IGNORECASE)
                            window_start = 0
                        except re.error:
                            self._direct_output(f"Invalid regex: {pattern}")
                    continue

                if key in ("e", "E"):
                    pattern = self._read_line_input("Match except: ")
                    if pattern:
                        try:
                            exclude_regex = re.compile(pattern, re.IGNORECASE)
                            window_start = 0
                        except re.error:
                            self._direct_output(f"Invalid regex: {pattern}")
                    continue

                if key in ("c", "C"):
                    include_regex = None
                    exclude_regex = None
                    window_start = 0
                    continue

                # Search
                if key == "/":
                    pattern = self._read_line_input("Search for: ")
                    if pattern:
                        try:
                            regex = re.compile(pattern, re.IGNORECASE)
                            found = self._find_match_index(lines, window_start, regex, True)
                            if found is not None:
                                window_start = found
                                last_found_line = found
                                last_search_regex = regex
                                last_search_forward = True
                                just_navigated = True
                            else:
                                self._direct_output("Pattern not found")
                        except re.error:
                            self._direct_output(f"Invalid regex: {pattern}")
                    continue

                if key == "?":
                    pattern = self._read_line_input("Reverse search for: ")
                    if pattern:
                        try:
                            regex = re.compile(pattern, re.IGNORECASE)
                            found = self._find_match_index(lines, window_start, regex, False)
                            if found is not None:
                                window_start = found
                                last_found_line = found
                                last_search_regex = regex
                                last_search_forward = False
                                just_navigated = True
                            else:
                                self._direct_output("Pattern not found")
                        except re.error:
                            self._direct_output(f"Invalid regex: {pattern}")
                    continue

                if key in ("n", "N") and last_search_regex is not None:
                    search_from = last_found_line if last_found_line is not None else window_start
                    found = self._find_match_index(
                        lines, search_from, last_search_regex, last_search_forward
                    )
                    if found is not None:
                        window_start = found
                        last_found_line = found
                        just_navigated = True
                    else:
                        self._direct_output("Pattern not found")
                    continue

                if key in ("s", "S"):
                    filename = self._read_line_input("Filename: ")
                    if filename:
                        try:
                            target = Path(filename).expanduser()
                            target.parent.mkdir(parents=True, exist_ok=True)
                            target.write_text("\n".join(lines), encoding="utf-8")
                            self._direct_output(f"Saved output to {target}")
                        except OSError as exc:
                            self._direct_output(f"Failed to save output: {exc}")
                    continue

                # Unknown key: keep current view.
                continue
        except KeyboardInterrupt:
            return

    def _read_single_key(self) -> str:
        """Read a single key press from stdin."""
        if not sys.stdin.isatty():
            return "q"
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    def _direct_output(self, text: str) -> None:
        """Output text directly to stdout."""
        print(text, end="" if text.endswith("\n") else "\n")

    def is_enabled(self) -> bool:
        """Check if paging is currently enabled."""
        return self.enabled

    def set_enabled(self, enabled: bool) -> None:
        """Enable or disable paging.

        Args:
            enabled: Whether to enable paging
        """
        self.enabled = enabled and self._is_paging_available()

    def update_terminal_size(self) -> None:
        """Update cached terminal size (call after terminal resize)."""
        self._terminal_height = self._get_terminal_height()


# Global pager instance for CLI use
_default_pager: Optional[Pager] = None


def get_default_pager() -> Pager:
    """Get or create the default pager instance."""
    global _default_pager
    if _default_pager is None:
        # Check environment variables for configuration
        enabled = os.environ.get("RSI_PAGER", "1").lower() not in ("0", "false", "off")
        threshold = float(os.environ.get("RSI_PAGER_THRESHOLD", "0.8"))
        less_opts = os.environ.get("RSI_LESS_OPTIONS")
        less_prompt = os.environ.get("RSI_LESS_PROMPT", "---(more)---")

        _default_pager = Pager(
            enabled=enabled,
            threshold_ratio=threshold,
            less_options=less_opts,
            less_prompt=less_prompt,
        )

    return _default_pager


def display_text(text: str, force: bool = False) -> None:
    """Convenience function to display text using the default pager.

    Args:
        text: Text to display
        force: If True, force automore regardless of line threshold
    """
    get_default_pager().display_with_mode(text, force=force)


def is_paging_enabled() -> bool:
    """Check if paging is enabled on the default pager."""
    return get_default_pager().is_enabled()


def set_paging_enabled(enabled: bool) -> None:
    """Enable or disable paging on the default pager.

    Args:
        enabled: Whether to enable paging
    """
    get_default_pager().set_enabled(enabled)
