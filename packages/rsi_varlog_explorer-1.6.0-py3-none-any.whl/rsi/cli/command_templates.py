import re
from dataclasses import dataclass
from typing import List, Optional, Sequence


_PLACEHOLDER_PATTERN = re.compile(r"^<[^>]+>$")
_IPV4_PATTERN = re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$")
_INTERFACE_PATTERN = re.compile(r"^[a-z][a-z0-9-]*-\d+/\d+/\d+(?::\d+)?(?:\.\d+)?$", re.IGNORECASE)
_INTEGER_PATTERN = re.compile(r"^\d+$")


def _split_tokens(command: str) -> List[str]:
    return [tok for tok in command.strip().split() if tok]


@dataclass(frozen=True)
class CommandTemplate:
    command: str
    tokens: Sequence[str]
    placeholder_count: int


class CommandTemplateMatcher:
    """Best-effort matcher for commands containing placeholder tokens.

    This matcher is intentionally conservative: it only uses command templates
    that contain explicit Junos-like placeholders such as ``<id>`` or
    ``<interface-name>``. It does not attempt fuzzy token guessing.
    """

    def __init__(self, commands: Sequence[str]) -> None:
        self.templates: List[CommandTemplate] = []
        for cmd in commands:
            tokens = _split_tokens(cmd)
            if not tokens:
                continue
            placeholder_count = sum(1 for t in tokens if _PLACEHOLDER_PATTERN.match(t))
            if placeholder_count == 0:
                continue
            self.templates.append(
                CommandTemplate(command=cmd, tokens=tokens, placeholder_count=placeholder_count)
            )

    def best_match(self, user_input: str) -> Optional[str]:
        user_tokens = _split_tokens(user_input)
        if not user_tokens:
            return None

        best_command: Optional[str] = None
        best_score = -1.0
        best_placeholders = 10**9

        for template in self.templates:
            if len(template.tokens) != len(user_tokens):
                continue

            static_matches = 0
            static_total = 0
            valid = True

            for expected, actual in zip(template.tokens, user_tokens):
                if _PLACEHOLDER_PATTERN.match(expected):
                    if not self._validate_placeholder(expected, actual):
                        valid = False
                        break
                else:
                    static_total += 1
                    if expected.lower() == actual.lower():
                        static_matches += 1
                    else:
                        valid = False
                        break

            if not valid:
                continue

            # Prefer templates with stronger static alignment and fewer placeholders.
            score = (static_matches / static_total) if static_total else 0.0
            if score > best_score or (score == best_score and template.placeholder_count < best_placeholders):
                best_score = score
                best_placeholders = template.placeholder_count
                best_command = template.command

        return best_command

    def _validate_placeholder(self, placeholder: str, value: str) -> bool:
        key = placeholder.strip("<>").lower()
        if not value:
            return False

        if "interface" in key:
            return bool(_INTERFACE_PATTERN.match(value))

        if key in {"id", "index", "count", "slot", "fpc", "pic", "port", "unit", "vlan", "number"}:
            return bool(_INTEGER_PATTERN.match(value))

        if "ip" in key or "addr" in key:
            if ":" in value:
                return True  # Accept IPv6-style values conservatively.
            if _IPV4_PATTERN.match(value):
                return all(0 <= int(part) <= 255 for part in value.split("."))
            return False

        # Generic placeholder fallback.
        return True
