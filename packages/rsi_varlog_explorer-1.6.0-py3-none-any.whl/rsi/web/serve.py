#!/usr/bin/env python3
"""
Simple HTTP server for serving the RSI Web UI locally.
Run this script from the rsi/web directory to test the application.
"""

import http.server
import os
import socketserver
import sys
from pathlib import Path


def main():
    # Change to the web directory
    web_dir = Path(__file__).parent
    os.chdir(web_dir)

    # Default port
    port = 8000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            print(f"Invalid port number: {sys.argv[1]}")
            sys.exit(1)

    # Create server
    handler = http.server.SimpleHTTPRequestHandler

    try:
        with socketserver.TCPServer(("", port), handler) as httpd:
            print(f"RSI Web UI server running at http://localhost:{port}/")
            print("Press Ctrl+C to stop the server")
            print()
            print("To test the application:")
            print("1. Open the URL above in your browser")
            print("2. Drag and drop the test.rsi file onto the upload area")
            print("3. Start typing commands like 'show version'")
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    except OSError as e:
        if e.errno == 48:  # Address already in use
            print(f"Port {port} is already in use. Try a different port:")
            print(f"python3 serve.py {port + 1}")
        else:
            print(f"Error starting server: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
