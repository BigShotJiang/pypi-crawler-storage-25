/**
 * Command Tree - JavaScript port of the Python CommandTree class
 * Builds and manages a hierarchical command tree from RSI commands
 * for efficient command completion and help lookup
 */

class CommandNode {
    constructor(name = '') {
        this.name = name;
        this.children = {};
        this.isComplete = false;  // True if this is a complete command
        this.fullCommand = null;  // The full original command
    }

    /**
     * Add a child node and return it
     * @param {string} name - Name of the child node to add
     * @returns {CommandNode} The child node (new or existing)
     */
    addChild(name) {
        if (!(name in this.children)) {
            this.children[name] = new CommandNode(name);
        }
        return this.children[name];
    }

    /**
     * Get all possible completions from this node
     * @param {string} prefix - Optional prefix to filter completions
     * @returns {string[]} Sorted list of completion strings
     */
    getCompletions(prefix = '') {
        const completions = [];
        const lowerPrefix = prefix.toLowerCase();
        
        for (const [childName, childNode] of Object.entries(this.children)) {
            if (childName.startsWith(lowerPrefix)) {
                completions.push(childName);
            }
        }
        
        return completions.sort();
    }
}

class CommandTree {
    constructor(commands) {
        this.root = new CommandNode();
        this._buildTree(commands);
    }

    /**
     * Build the command tree from a list of commands
     * @param {string[]} commands - Array of command strings
     */
    _buildTree(commands) {
        for (const command of commands) {
            this._addCommand(command);
        }
    }

    /**
     * Add a single command to the tree
     * @param {string} command - The command to add
     */
    _addCommand(command) {
        // Split command into parts (handle quoted strings)
        const parts = this._splitCommand(command);

        let currentNode = this.root;
        for (const part of parts) {
            currentNode = currentNode.addChild(part.toLowerCase());
        }

        // Mark the final node as a complete command
        currentNode.isComplete = true;
        currentNode.fullCommand = command;
    }

    /**
     * Split command into parts, handling quoted strings
     * @param {string} command - The command to split
     * @returns {string[]} Array of command parts
     */
    _splitCommand(command) {
        const parts = [];
        let currentPart = '';
        let inQuotes = false;

        for (let i = 0; i < command.length; i++) {
            const char = command[i];
            
            if (char === '"' && !inQuotes) {
                inQuotes = true;
                currentPart += char;
            } else if (char === '"' && inQuotes) {
                inQuotes = false;
                currentPart += char;
            } else if (char === ' ' && !inQuotes) {
                if (currentPart) {
                    parts.push(currentPart);
                    currentPart = '';
                }
            } else {
                currentPart += char;
            }
        }

        if (currentPart) {
            parts.push(currentPart);
        }

        return parts;
    }

    /**
     * Get possible completions for a partial command
     * @param {string} partialCommand - The partial command to complete
     * @returns {string[]} Array of possible completions
     */
    getCompletions(partialCommand) {
        if (!partialCommand.trim()) {
            return this.root.getCompletions();
        }

        const parts = this._splitCommand(partialCommand.trim());
        let currentNode = this.root;

        // Navigate to the appropriate node
        for (let i = 0; i < parts.length - 1; i++) {
            const part = parts[i];
            if (part.toLowerCase() in currentNode.children) {
                currentNode = currentNode.children[part.toLowerCase()];
            } else {
                return []; // Invalid path
            }
        }

        // Get completions for the last part
        const lastPart = parts.length > 0 ? parts[parts.length - 1] : '';
        return currentNode.getCompletions(lastPart);
    }

    /**
     * Find the full command that matches a partial command
     * @param {string} partialCommand - The partial command to find
     * @returns {string|null} The full command or null if not found
     */
    findCommand(partialCommand) {
        const parts = this._splitCommand(partialCommand.trim());
        let currentNode = this.root;

        for (const part of parts) {
            if (part.toLowerCase() in currentNode.children) {
                currentNode = currentNode.children[part.toLowerCase()];
            } else {
                return null;
            }
        }

        return currentNode.isComplete ? currentNode.fullCommand : null;
    }

    /**
     * Get help information for a partial command
     * @param {string} partialCommand - The partial command to get help for
     * @returns {string[]} Array of help lines
     */
    getHelp(partialCommand) {
        if (!partialCommand.trim()) {
            const completions = this.root.getCompletions();
            return completions.slice(0, 10).map(comp => `  ${comp}`);
        }

        const parts = this._splitCommand(partialCommand.trim());
        let currentNode = this.root;

        // Navigate to the appropriate node
        for (const part of parts) {
            if (part.toLowerCase() in currentNode.children) {
                currentNode = currentNode.children[part.toLowerCase()];
            } else {
                return [`Unknown command: ${partialCommand}`];
            }
        }

        // Get available subcommands
        const completions = currentNode.getCompletions();
        if (completions.length === 0) {
            return [`Complete command: ${partialCommand}`];
        }

        const helpLines = [];
        const maxLines = 10;
        
        for (let i = 0; i < Math.min(completions.length, maxLines); i++) {
            helpLines.push(`  ${completions[i]}`);
        }

        if (completions.length > maxLines) {
            helpLines.push(`  ... and ${completions.length - maxLines} more options`);
        }

        return helpLines;
    }

    /**
     * Check if a command is valid (exists in the tree)
     * @param {string} command - The command to check
     * @returns {boolean} True if the command exists
     */
    isValidCommand(command) {
        return this.findCommand(command) !== null;
    }

    /**
     * Get all complete commands in the tree
     * @returns {string[]} Array of all complete commands
     */
    getAllCommands() {
        const commands = [];
        this._collectCommands(this.root, commands);
        return commands.sort();
    }

    /**
     * Recursively collect all complete commands from a node
     * @param {CommandNode} node - The node to collect from
     * @param {string[]} commands - The array to collect commands into
     * @private
     */
    _collectCommands(node, commands) {
        if (node.isComplete && node.fullCommand) {
            commands.push(node.fullCommand);
        }
        
        for (const child of Object.values(node.children)) {
            this._collectCommands(child, commands);
        }
    }

    /**
     * Get statistics about the command tree
     * @returns {Object} Object containing tree statistics
     */
    getStats() {
        const allCommands = this.getAllCommands();
        return {
            totalCommands: allCommands.length,
            maxDepth: this._getMaxDepth(this.root),
            rootChildren: Object.keys(this.root.children).length
        };
    }

    /**
     * Get the maximum depth of the tree
     * @param {CommandNode} node - The node to measure depth from
     * @returns {number} Maximum depth from this node
     * @private
     */
    _getMaxDepth(node) {
        if (Object.keys(node.children).length === 0) {
            return 0;
        }
        
        let maxChildDepth = 0;
        for (const child of Object.values(node.children)) {
            const childDepth = this._getMaxDepth(child);
            maxChildDepth = Math.max(maxChildDepth, childDepth);
        }
        
        return 1 + maxChildDepth;
    }
}

// Export for use in other modules (if using modules)
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = { CommandTree, CommandNode };
}