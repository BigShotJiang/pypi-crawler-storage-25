/**
 * Main application logic for RSI Device CLI Simulator
 * Handles file upload, processing, and terminal initialization
 */

class RSIWebApp {
    constructor() {
        this.rsiParser = null;
        this.terminal = null;
        this.isProcessing = false;
        this.worker = null;
        this.workerMessageId = 0;
        this.workerCallbacks = new Map();
        
        this.initializeElements();
        this.bindEvents();
        this.initializeWorker();
    }

    initializeElements() {
        // UI Elements
        this.uploadArea = document.getElementById('upload-area');
        this.fileInput = document.getElementById('file-input');
        this.browseBtn = document.getElementById('browse-btn');
        this.processing = document.getElementById('processing');
        this.errorMessage = document.getElementById('error-message');
        this.errorText = document.getElementById('error-text');
        this.resetBtn = document.getElementById('reset-btn');
        this.terminalContainer = document.getElementById('terminal-container');
        this.terminalTitle = document.getElementById('terminal-title');
        this.terminalStats = document.getElementById('terminal-stats');
        this.clearTerminalBtn = document.getElementById('clear-terminal');
        this.fullscreenToggleBtn = document.getElementById('fullscreen-toggle');
    }

    bindEvents() {
        // File input events
        this.fileInput.addEventListener('change', (e) => this.handleFileSelect(e));
        this.browseBtn.addEventListener('click', () => this.fileInput.click());
        
        // Drag and drop events
        this.uploadArea.addEventListener('dragover', (e) => this.handleDragOver(e));
        this.uploadArea.addEventListener('dragleave', (e) => this.handleDragLeave(e));
        this.uploadArea.addEventListener('drop', (e) => this.handleFileDrop(e));
        this.uploadArea.addEventListener('click', () => this.fileInput.click());
        
        // UI control events
        this.resetBtn.addEventListener('click', () => this.resetApplication());
        this.clearTerminalBtn.addEventListener('click', () => this.clearTerminal());
        this.fullscreenToggleBtn.addEventListener('click', () => this.toggleFullscreen());
        
        // Prevent default drag behaviors on document
        document.addEventListener('dragover', (e) => e.preventDefault());
        document.addEventListener('drop', (e) => e.preventDefault());
    }

    initializeWorker() {
        try {
            this.worker = new Worker('js/worker.js');
            this.worker.onmessage = (e) => this.handleWorkerMessage(e);
            this.worker.onerror = (e) => {
                console.warn('Web Worker not available, using main thread processing');
                this.worker = null;
            };
        } catch (error) {
            console.warn('Web Worker not supported, using main thread processing');
            this.worker = null;
        }
    }

    handleWorkerMessage(e) {
        const { type, id, data, error } = e.data;
        
        if (type === 'ready') {
            console.log('Web Worker ready');
            return;
        }
        
        const callback = this.workerCallbacks.get(id);
        if (callback) {
            this.workerCallbacks.delete(id);
            
            if (type === 'error') {
                callback.reject(new Error(error));
            } else {
                callback.resolve(data);
            }
        }
    }

    sendWorkerMessage(type, data) {
        return new Promise((resolve, reject) => {
            if (!this.worker) {
                reject(new Error('Worker not available'));
                return;
            }
            
            const id = ++this.workerMessageId;
            this.workerCallbacks.set(id, { resolve, reject });
            
            this.worker.postMessage({ type, data, id });
        });
    }

    handleDragOver(e) {
        e.preventDefault();
        this.uploadArea.classList.add('drag-over');
    }

    handleDragLeave(e) {
        e.preventDefault();
        if (!this.uploadArea.contains(e.relatedTarget)) {
            this.uploadArea.classList.remove('drag-over');
        }
    }

    handleFileDrop(e) {
        e.preventDefault();
        this.uploadArea.classList.remove('drag-over');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }

    handleFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.processFile(files[0]);
        }
    }

    async processFile(file) {
        if (this.isProcessing) return;
        
        try {
            this.isProcessing = true;
            this.showProcessing();
            
            // Validate file type
            if (!this.isValidFileType(file)) {
                throw new Error('Invalid file type. Please upload a .rsi, .txt, .log, .gz, .tgz, or .zip file.');
            }
            
            // Read and decompress file
            const fileContent = await this.readAndDecompressFile(file);
            
            // Parse RSI content (use worker if available)
            if (this.worker) {
                try {
                    const parseResult = await this.sendWorkerMessage('parseRSI', { content: fileContent });
                    
                    // Create parser instance with results
                    this.rsiParser = new RSIParser();
                    this.rsiParser.user = parseResult.user;
                    this.rsiParser.hostname = parseResult.hostname;
                    this.rsiParser.commands = parseResult.commands;
                } catch (workerError) {
                    console.warn('Worker parsing failed, using main thread:', workerError.message);
                    // Fallback to main thread parsing
                    this.rsiParser = new RSIParser();
                    this.rsiParser.parseContent(fileContent);
                }
            } else {
                // Main thread parsing
                this.rsiParser = new RSIParser();
                this.rsiParser.parseContent(fileContent);
            }
            
            // Initialize terminal
            this.initializeTerminal();
            
            // Update UI
            this.showTerminal();
            this.updateTerminalStats();
            
        } catch (error) {
            console.error('Error processing file:', error);
            this.showError(error.message);
        } finally {
            this.isProcessing = false;
        }
    }

    isValidFileType(file) {
        const validExtensions = ['.rsi', '.txt', '.log', '.gz', '.tgz', '.zip'];
        const fileName = file.name.toLowerCase();
        return validExtensions.some(ext => fileName.endsWith(ext));
    }

    async readAndDecompressFile(file) {
        const fileName = file.name.toLowerCase();
        const arrayBuffer = await this.readFileAsArrayBuffer(file);
        
        try {
            if (fileName.endsWith('.zip')) {
                return await this.decompressZip(arrayBuffer);
            } else if (fileName.endsWith('.gz') || fileName.endsWith('.tgz')) {
                return await this.decompressGzip(arrayBuffer);
            } else {
                // Handle .rsi, .txt, .log, or other plain text files
                return new TextDecoder().decode(arrayBuffer);
            }
        } catch (error) {
            throw new Error(`Failed to decompress file: ${error.message}`);
        }
    }

    readFileAsArrayBuffer(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(new Error('Failed to read file'));
            reader.readAsArrayBuffer(file);
        });
    }

    async decompressGzip(arrayBuffer) {
        try {
            const decompressed = pako.inflate(arrayBuffer, { to: 'string' });
            return decompressed;
        } catch (error) {
            throw new Error('Invalid gzip format');
        }
    }

    async decompressZip(arrayBuffer) {
        try {
            const zip = await JSZip.loadAsync(arrayBuffer);
            const files = Object.keys(zip.files);
            
            if (files.length === 0) {
                throw new Error('Empty zip file');
            }
            
            // Find the first .rsi file or use the first file
            let targetFile = files.find(f => f.toLowerCase().endsWith('.rsi')) || files[0];
            const content = await zip.files[targetFile].async('string');
            
            return content;
        } catch (error) {
            throw new Error('Invalid zip format or no readable files found');
        }
    }

    initializeTerminal() {
        const user = this.rsiParser.getUser() || 'user';
        const hostname = this.rsiParser.getHostname() || 'device';
        
        this.terminal = new RSITerminal(
            document.getElementById('terminal'),
            this.rsiParser,
            user,
            hostname
        );
        
        this.terminal.start();
    }

    updateTerminalStats() {
        const commandCount = Object.keys(this.rsiParser.getCommands()).length;
        const user = this.rsiParser.getUser() || 'user';
        const hostname = this.rsiParser.getHostname() || 'device';
        
        this.terminalTitle.textContent = `${user}@${hostname}`;
        this.terminalStats.textContent = `${commandCount} commands loaded`;
    }

    clearTerminal() {
        if (this.terminal) {
            this.terminal.clear();
        }
    }

    showProcessing() {
        this.hideAllSections();
        this.processing.classList.remove('hidden');
    }

    showError(message) {
        this.hideAllSections();
        this.errorText.textContent = message;
        this.errorMessage.classList.remove('hidden');
    }

    showTerminal() {
        this.hideAllSections();
        this.terminalContainer.classList.remove('hidden');
    }

    hideAllSections() {
        this.uploadArea.classList.add('hidden');
        this.processing.classList.add('hidden');
        this.errorMessage.classList.add('hidden');
        this.terminalContainer.classList.add('hidden');
    }

    resetApplication() {
        // Reset state
        this.rsiParser = null;
        this.terminal = null;
        this.isProcessing = false;
        
        // Reset file input
        this.fileInput.value = '';
        
        // Show upload area
        this.uploadArea.classList.remove('hidden');
        this.hideAllSections();
        this.uploadArea.classList.remove('hidden');
    }

    toggleFullscreen() {
        if (!this.terminalContainer.classList.contains('hidden')) {
            const isFullscreen = this.terminalContainer.classList.contains('fullscreen');
            
            if (isFullscreen) {
                // Exit fullscreen
                this.terminalContainer.classList.remove('fullscreen');
                this.fullscreenToggleBtn.textContent = '⛶';
                this.fullscreenToggleBtn.title = 'Enter Fullscreen';
                document.body.style.overflow = '';
            } else {
                // Enter fullscreen
                this.terminalContainer.classList.add('fullscreen');
                this.fullscreenToggleBtn.textContent = '⛶';
                this.fullscreenToggleBtn.title = 'Exit Fullscreen';
                document.body.style.overflow = 'hidden';
            }
            
            // Recalculate pager size if active
            if (this.terminal && this.terminal.pager) {
                setTimeout(() => {
                    // Force pager to recalculate if it's active
                    if (this.terminal.pager.isActive) {
                        this.terminal.pager.calculatePageSize();
                        this.terminal.pager.updateDisplay();
                    }
                }, 100);
            }
        }
    }
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.rsiApp = new RSIWebApp();
});