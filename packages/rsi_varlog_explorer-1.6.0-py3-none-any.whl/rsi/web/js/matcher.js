/**
 * Command Matcher - JavaScript port of the Python CommandMatcher class
 * Handles command matching and fuzzy search for RSI commands
 */

/**
 * Calculate similarity between two strings using a simple algorithm
 * This replaces Python's SequenceMatcher functionality
 * @param {string} a - First string
 * @param {string} b - Second string
 * @returns {number} Similarity ratio between 0.0 and 1.0
 */
function calculateSimilarity(a, b) {
    if (a === b) return 1.0;
    if (a.length === 0 || b.length === 0) return 0.0;
    
    // Use Levenshtein distance for similarity calculation
    const matrix = [];
    
    // Create matrix
    for (let i = 0; i <= b.length; i++) {
        matrix[i] = [i];
    }
    
    for (let j = 0; j <= a.length; j++) {
        matrix[0][j] = j;
    }
    
    // Fill matrix
    for (let i = 1; i <= b.length; i++) {
        for (let j = 1; j <= a.length; j++) {
            if (b.charAt(i - 1) === a.charAt(j - 1)) {
                matrix[i][j] = matrix[i - 1][j - 1];
            } else {
                matrix[i][j] = Math.min(
                    matrix[i - 1][j - 1] + 1, // substitution
                    matrix[i][j - 1] + 1,     // insertion
                    matrix[i - 1][j] + 1      // deletion
                );
            }
        }
    }
    
    const distance = matrix[b.length][a.length];
    const maxLength = Math.max(a.length, b.length);
    
    return (maxLength - distance) / maxLength;
}

class CommandMatcher {
    constructor(commands) {
        this.commands = commands;
        this.commandList = Object.keys(commands);
    }

    /**
     * Find exact command match
     * @param {string} command - Command string to match exactly
     * @returns {string|null} Command output if found, null otherwise
     */
    exactMatch(command) {
        return this.commands[command] || null;
    }

    /**
     * Find commands that start with the partial command
     * @param {string} partialCommand - Partial command string to match
     * @returns {string[]} Sorted list of commands starting with the partial string
     */
    partialMatch(partialCommand) {
        const partialLower = partialCommand.toLowerCase().trim();
        const matches = [];

        for (const cmd of this.commandList) {
            if (cmd.toLowerCase().startsWith(partialLower)) {
                matches.push(cmd);
            }
        }

        return matches.sort();
    }

    /**
     * Find commands similar to the input using fuzzy matching
     * @param {string} command - Command string to find similar matches for
     * @param {number} threshold - Minimum similarity score (0.0 to 1.0) for matches
     * @returns {Array<{command: string, score: number}>} Array of matches sorted by similarity
     */
    fuzzyMatch(command, threshold = 0.6) {
        const commandLower = command.toLowerCase().trim();
        const matches = [];

        for (const cmd of this.commandList) {
            const ratio = calculateSimilarity(commandLower, cmd.toLowerCase());
            if (ratio >= threshold) {
                matches.push({ command: cmd, score: ratio });
            }
        }

        // Sort by similarity score (descending)
        return matches.sort((a, b) => b.score - a.score);
    }

    /**
     * Find the best matching command for user input
     * @param {string} userInput - User input to match
     * @returns {string|null} Best matching command or null if none found
     */
    findBestMatch(userInput) {
        const input = userInput.trim();

        // Try exact match first
        if (input in this.commands) {
            return input;
        }

        // Try partial matches
        const partialMatches = this.partialMatch(input);
        if (partialMatches.length === 1) {
            return partialMatches[0];
        }

        // No fuzzy matching - require exact or partial matches only
        return null;
    }

    /**
     * Get output for the best matching command
     * @param {string} userInput - User input to match
     * @returns {string|null} Command output or null if no match found
     */
    getCommandOutput(userInput) {
        const bestMatch = this.findBestMatch(userInput);
        if (bestMatch) {
            return this.commands[bestMatch];
        }
        return null;
    }

    /**
     * Suggest similar commands for invalid input
     * @param {string} userInput - User input to find suggestions for
     * @param {number} maxSuggestions - Maximum number of suggestions to return
     * @returns {string[]} Array of suggested commands
     */
    suggestCommands(userInput, maxSuggestions = 5) {
        // Try partial matches first
        const partialMatches = this.partialMatch(userInput);
        if (partialMatches.length > 0) {
            return partialMatches.slice(0, maxSuggestions);
        }

        // Fall back to fuzzy matches
        const fuzzyMatches = this.fuzzyMatch(userInput, 0.4);
        return fuzzyMatches.slice(0, maxSuggestions).map(match => match.command);
    }

    /**
     * Check if a command exists (exact match)
     * @param {string} command - Command to check
     * @returns {boolean} True if command exists
     */
    hasCommand(command) {
        return command in this.commands;
    }

    /**
     * Get all available commands
     * @returns {string[]} Array of all command names
     */
    getAllCommands() {
        return [...this.commandList];
    }

    /**
     * Get commands that contain a specific substring
     * @param {string} substring - Substring to search for
     * @param {boolean} caseSensitive - Whether search should be case sensitive
     * @returns {string[]} Array of matching commands
     */
    searchCommands(substring, caseSensitive = false) {
        const searchTerm = caseSensitive ? substring : substring.toLowerCase();
        const matches = [];

        for (const cmd of this.commandList) {
            const searchTarget = caseSensitive ? cmd : cmd.toLowerCase();
            if (searchTarget.includes(searchTerm)) {
                matches.push(cmd);
            }
        }

        return matches.sort();
    }

    /**
     * Get statistics about the command matcher
     * @returns {Object} Object containing matcher statistics
     */
    getStats() {
        return {
            totalCommands: this.commandList.length,
            averageCommandLength: this.commandList.reduce((sum, cmd) => sum + cmd.length, 0) / this.commandList.length,
            longestCommand: this.commandList.reduce((longest, cmd) => cmd.length > longest.length ? cmd : longest, ''),
            shortestCommand: this.commandList.reduce((shortest, cmd) => cmd.length < shortest.length ? cmd : shortest, this.commandList[0] || '')
        };
    }

    /**
     * Find commands by pattern matching (simple regex support)
     * @param {string} pattern - Pattern to match (supports basic wildcards)
     * @returns {string[]} Array of matching commands
     */
    findByPattern(pattern) {
        // Convert simple wildcard pattern to regex
        const regexPattern = pattern
            .replace(/\*/g, '.*')  // * becomes .*
            .replace(/\?/g, '.');  // ? becomes .
        
        try {
            const regex = new RegExp(regexPattern, 'i');
            return this.commandList.filter(cmd => regex.test(cmd)).sort();
        } catch (error) {
            // Invalid regex pattern
            return [];
        }
    }
}

// Export for use in other modules (if using modules)
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = { CommandMatcher };
}