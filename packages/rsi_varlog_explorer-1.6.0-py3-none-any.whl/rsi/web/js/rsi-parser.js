/**
 * RSI Parser - JavaScript port of the Python RSIParser class
 * Parses Juniper RSI (Request Support Information) files and extracts
 * user information, hostname, and command-output pairs
 */

class RSIParseError extends Error {
    constructor(message) {
        super(message);
        this.name = 'RSIParseError';
    }
}

class RSIParser {
    constructor() {
        this.user = null;
        this.hostname = null;
        this.commands = {};
        this.commandPattern = /^([^@]+)@(.+-RE[0-9])> (.+)$/;
    }

    /**
     * Parse RSI content from string
     * @param {string} content - The RSI file content as a string
     * @throws {RSIParseError} If content is empty or contains no valid commands
     */
    parseContent(content) {
        if (!content || typeof content !== 'string') {
            throw new RSIParseError('Content is empty or invalid');
        }

        const lines = content.split(/\r?\n/);
        
        if (lines.length === 0) {
            throw new RSIParseError('Content is empty');
        }

        let currentCommand = null;
        let outputLines = [];

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i].replace(/\r$/, ''); // Remove trailing carriage return
            const match = this.commandPattern.exec(line);

            if (match) {
                // Save previous command output if exists
                if (currentCommand !== null) {
                    this.commands[currentCommand] = outputLines.join('\n');
                }

                // Extract user and hostname from first command if not set
                if (this.user === null) {
                    this.user = match[1];
                    this.hostname = match[2];
                }

                // Set new current command and reset output
                currentCommand = match[3];
                outputLines = [];
            } else {
                // Collect output lines for current command
                if (currentCommand !== null) {
                    outputLines.push(line);
                }
            }
        }

        // Save last command output
        if (currentCommand !== null) {
            this.commands[currentCommand] = outputLines.join('\n');
        }

        // Validate that we found at least one command
        if (Object.keys(this.commands).length === 0) {
            throw new RSIParseError('No valid RSI commands found in content');
        }

        // Validate that user and hostname were extracted
        if (this.user === null || this.hostname === null) {
            throw new RSIParseError('Unable to extract user or hostname from content');
        }
    }

    /**
     * Get the extracted username from the RSI content
     * @returns {string|null} The username or null if not parsed
     */
    getUser() {
        return this.user;
    }

    /**
     * Get the extracted hostname from the RSI content
     * @returns {string|null} The hostname or null if not parsed
     */
    getHostname() {
        return this.hostname;
    }

    /**
     * Get output for a specific command
     * @param {string} command - The command to look up
     * @returns {string|null} The output for the command or null if not found
     */
    getCommandOutput(command) {
        return this.commands[command] || null;
    }

    /**
     * Get all commands and their outputs
     * @returns {Object} Copy of the commands object
     */
    getCommands() {
        return { ...this.commands };
    }

    /**
     * Get list of all available command names
     * @returns {string[]} Array of command names
     */
    getCommandNames() {
        return Object.keys(this.commands);
    }

    /**
     * Check if a specific command exists
     * @param {string} command - The command to check
     * @returns {boolean} True if command exists
     */
    hasCommand(command) {
        return command in this.commands;
    }

    /**
     * Get the total number of commands
     * @returns {number} Number of commands
     */
    getCommandCount() {
        return Object.keys(this.commands).length;
    }

    /**
     * Clear all parsed data
     */
    clear() {
        this.user = null;
        this.hostname = null;
        this.commands = {};
    }

    /**
     * Get parser statistics
     * @returns {Object} Object containing parser statistics
     */
    getStats() {
        return {
            user: this.user,
            hostname: this.hostname,
            commandCount: this.getCommandCount(),
            commands: this.getCommandNames()
        };
    }
}

// Export for use in other modules (if using modules)
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = { RSIParser, RSIParseError };
}