# RSI Device Web UI

A client-side web application that provides an interactive CLI simulator for Juniper RSI (Request Support Information) files.

## Features

- **Drag & Drop Interface**: Simply drag and drop RSI files to start a CLI session
- **File Format Support**: Supports .rsi, .txt, .log, .gz, .tgz, and .zip formats
- **Complete CLI Simulation**: Full feature parity with the Python CLI version
- **Command Completion**: Tab completion for commands
- **Command History**: Navigate command history with up/down arrows
- **Help System**: Type `?` after any command for help
- **Pipe Commands**: Full support for pipe operations (match, count, save, etc.)
- **Client-Side Processing**: All processing happens in the browser (no server required)
- **Privacy**: Files never leave your browser

## Quick Start

1. Open `index.html` in a modern web browser
2. Drag and drop an RSI file onto the upload area (or click Browse to select)
3. Wait for the file to process
4. Start typing commands in the terminal

## Usage

### File Upload
- Supported formats: `.rsi`, `.txt`, `.log`, `.gz`, `.tgz`, `.zip`
- Drag files directly onto the upload area
- Or click "Browse Files" to select manually

### Terminal Commands
Once an RSI file is loaded, you can use all the commands that were captured in the file:

```bash
# Basic commands
show version
show interfaces terse
show bgp summary

# Tab completion
show int<TAB>  # Completes to available options

# Command history
<Up Arrow>     # Previous command
<Down Arrow>   # Next command

# Help system
show ?         # Show help for 'show' command
?              # Show all available commands

# Pipe commands
show interfaces | match ge-0/0/0
show version | count
show config | save backup.conf
show bgp summary | last 10
```

### Pipe Commands
All pipe commands from the Python CLI are supported:

- `no-more` - Disable paging for output
- `save <filename>` - Save output to file (downloads in browser)
- `count` - Count lines in output
- `match <pattern>` - Show lines matching regex pattern
- `except <pattern>` - Show lines NOT matching pattern
- `last <N>` - Show last N lines
- `find <pattern>` - Show from first matching line onward
- `trim <N>` - Remove N characters from left of each line
- `display set` - Convert config to set commands

### Special Commands
- `clear` - Clear the terminal
- `quit` or `exit` - Exit message (doesn't actually close browser)

## Technical Details

### Architecture
- **Client-Side Only**: No server required, all processing in browser
- **Web Workers**: Background processing to keep UI responsive
- **Modern JavaScript**: Uses ES6+ features

### File Processing
1. File is read using File API
2. Compressed files are decompressed (gzip/zip)
3. RSI content is parsed to extract commands and outputs
4. Command tree is built for tab completion
5. Terminal interface is initialized

### Browser Compatibility
- Requires modern browser with:
  - File API support
  - Web Workers (optional, graceful fallback)
  - ES6+ JavaScript support

### Libraries Used
- **pako.js** - Gzip compression/decompression
- **jszip.js** - ZIP file handling
- **Custom terminal** - Lightweight terminal implementation

## Development

### File Structure
```
rsi/web/
├── index.html          # Main application page
├── css/
│   └── style.css       # Application styles
├── js/
│   ├── main.js         # Main application logic
│   ├── rsi-parser.js   # RSI file parser
│   ├── command-tree.js # Command tree for completion
│   ├── matcher.js      # Command matching and suggestions
│   ├── pipe-processor.js # Pipe command processing
│   ├── terminal.js     # Terminal interface
│   └── worker.js       # Web Worker for background processing
├── lib/
│   ├── pako.min.js     # Gzip support
│   ├── jszip.min.js    # ZIP support
│   └── README.md       # Library documentation
└── test.rsi           # Sample RSI file for testing
```

### Testing
1. Use the included `test.rsi` file for basic testing
2. Test with compressed files (.gz, .zip)
3. Verify all pipe commands work correctly
4. Test tab completion and command history

## Deployment

Since this is a static web application, it can be deployed to:
- GitHub Pages
- Netlify
- Vercel
- Any static web hosting service
- Local web server for development

Simply upload all files to the web server and access `index.html`.

## Limitations

- Files are processed entirely in memory (large files may cause issues)
- .tgz files have simplified tar extraction
- No real device connectivity (simulation only)
- Browser file size limits apply

## Troubleshooting

### File Won't Load
- Check file format is supported (.rsi, .txt, .log, .gz, .tgz, .zip)
- Ensure file contains valid RSI format data
- Check browser console for error messages

### Commands Don't Work
- Verify the command exists in the original RSI file
- Try tab completion to see available commands
- Use `?` for help with command syntax

### Performance Issues
- Large RSI files may take time to process
- Web Workers help but aren't required
- Clear browser cache if issues persist