import re
import sys
import gzip
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set, Union


class RSIParseError(Exception):
    """Exception raised for RSI parsing errors."""

    pass


class RSIParser:
    """Parser for Juniper RSI (Request Support Information) files.

    This class provides functionality to parse RSI files and extract:
    - User information from command prompts
    - Hostname information from command prompts
    - Commands and their corresponding outputs

    The parser expects RSI files to contain command lines in the format:
    user@hostname-RE0> command
    followed by the command output.
    """

    def __init__(self) -> None:
        """Initialize RSI parser with empty state.

        Attributes:
            user: Extracted username from RSI file
            hostname: Extracted hostname from RSI file
            commands: Dictionary mapping commands to their outputs
        """
        self.user: Optional[str] = None
        self.hostname: Optional[str] = None
        self.commands: Dict[str, str] = {}
        self._command_pattern = re.compile(r"^([^@]+)@([^>]+)> (.+)$")

        # Interface parsing data structures
        self.interfaces: Dict[
            str, Dict[str, str]
        ] = {}  # interface_name -> {command_type -> output}
        self.interface_hierarchy: Dict[
            str, List[str]
        ] = {}  # physical -> [logical_interfaces]

        # Interface parsing patterns
        self._physical_interface_pattern = re.compile(r"^Physical interface: ([^,]+),")
        self._logical_interface_pattern = re.compile(
            r"^\s+Logical interface ([^\s]+) \("
        )
        self._interface_terse_pattern = re.compile(r"^([^\s]+)\s+")

        # Optional external var-log support (e.g., case/.../var-re0)
        self.var_log_dir: Optional[Path] = None
        self.var_logs: Dict[str, Path] = {}
        self.master_re_name: Optional[str] = None

    def _get_macos_volume_candidate(self, file_path: Union[str, Path]) -> Optional[Path]:
        """Return canonical /Volumes candidate for common macOS mount typos."""
        path_str = str(file_path)
        lower_path = path_str.lower()
        if lower_path.startswith("/volume/"):
            return Path("/Volumes" + path_str[7:])
        if lower_path.startswith("/volumes/"):
            return Path("/Volumes" + path_str[8:])
        return None

    def _normalize_input_path(self, file_path: Union[str, Path]) -> Path:
        """Normalize user-supplied RSI paths for local filesystem access.

        On macOS, users sometimes provide `/volume/...` or `/volumes/...` while
        mounted disks live under `/Volumes/...`. If the original path does not
        exist, try the canonical `/Volumes` prefix before failing.
        """
        file_path_obj = Path(file_path)
        if file_path_obj.exists() or sys.platform != "darwin":
            return file_path_obj

        candidate = self._get_macos_volume_candidate(file_path)
        if candidate and candidate.exists():
            return candidate

        return file_path_obj

    def _format_file_not_found_message(
        self, file_path: Union[str, Path], normalized_path: Path
    ) -> str:
        """Build a clear not-found message with local-mount guidance."""
        original_path = str(file_path)
        message = f"File not found: {original_path}"
        hints: List[str] = []

        if sys.platform == "darwin":
            candidate = self._get_macos_volume_candidate(file_path)
            if candidate is not None:
                hints.append(f"On macOS, mounted volumes usually appear under {candidate}.")

        path_obj = Path(original_path)
        if path_obj.is_absolute():
            hints.append(
                "This tool reads files from the local filesystem of the machine where it is running."
            )
            hints.append(
                "If this is a server path, mount that location locally first or copy the RSI file onto this machine before running rsi-cli."
            )

        if hints:
            return message + " " + " ".join(hints)
        return message

    def parse_file(self, file_path: Union[str, Path]) -> None:
        """Parse RSI file and extract user, hostname, commands and outputs.

        Args:
            file_path: Path to the RSI file to parse (can be string or Path object)

        Raises:
            RSIParseError: If file cannot be read, is empty, or contains no valid commands

        Note:
            This method populates the user, hostname, and commands attributes.
            Commands are stored as a dictionary mapping command strings to their outputs.
        """
        file_path_obj = self._normalize_input_path(file_path)

        if not file_path_obj.exists():
            raise RSIParseError(
                self._format_file_not_found_message(file_path, file_path_obj)
            )

        if not file_path_obj.is_file():
            raise RSIParseError(f"Path is not a file: {file_path}")

        try:
            with open(file_path_obj, encoding="utf-8") as file:
                lines = file.readlines()
        except UnicodeDecodeError as e:
            raise RSIParseError(f"Unable to decode file as UTF-8: {file_path}") from e
        except PermissionError as e:
            raise RSIParseError(f"Permission denied reading file: {file_path}") from e
        except OSError as e:
            raise RSIParseError(f"Error reading file {file_path}: {e}") from e

        if not lines:
            raise RSIParseError(f"File is empty: {file_path}")

        current_command = None
        output_lines = []

        for line in lines:
            line = line.rstrip("\n")
            match = self._command_pattern.match(line)

            if match:
                # Save previous command output if exists
                if current_command is not None:
                    self.commands[current_command] = "\n".join(output_lines)

                # Extract user and hostname from first command if not set
                if self.user is None:
                    self.user = match.group(1)
                    self.hostname = match.group(2)

                # Set new current command and reset output
                current_command = match.group(3)
                output_lines = []
            else:
                # Collect output lines for current command
                if current_command is not None:
                    output_lines.append(line)

        # Save last command output
        if current_command is not None:
            self.commands[current_command] = "\n".join(output_lines)

        # Validate that we found at least one command
        if not self.commands:
            raise RSIParseError(f"No valid RSI commands found in file: {file_path}")

        # Validate that user and hostname were extracted
        if self.user is None or self.hostname is None:
            raise RSIParseError(
                f"Unable to extract user or hostname from file: {file_path}"
            )

        # Parse interface data after parsing commands
        self.parse_interfaces()

        # Best-effort derive master RE from routing-engine output.
        self.master_re_name = self._detect_master_re_name()
        if self.hostname and self.master_re_name:
            if not re.search(r"-re[01]$", self.hostname, flags=re.IGNORECASE):
                self.hostname = f"{self.hostname}-{self.master_re_name}"

        # Best-effort auto-discovery of case var-log directories.
        self.autodiscover_var_log_dir(file_path_obj)

    def _detect_master_re_name(self) -> Optional[str]:
        """Detect master RE name (re0/re1) from routing-engine command output."""
        routing_output: Optional[str] = None
        for cmd, out in self.commands.items():
            if re.match(r"^show\s+chassis\s+routing-engine(?:\s|$)", cmd, flags=re.IGNORECASE):
                routing_output = out
                break

        if not routing_output:
            return None

        current_slot: Optional[int] = None
        for line in routing_output.splitlines():
            slot_match = re.match(r"^\s*Slot\s+([01])\s*:\s*$", line, flags=re.IGNORECASE)
            if slot_match:
                current_slot = int(slot_match.group(1))
                continue

            if current_slot is None:
                continue

            # Typical output: "Current state              Master"
            if re.search(r"^\s*Current\s+state\s+.*\bMaster\b", line, flags=re.IGNORECASE):
                return f"re{current_slot}"

            # Fallback for variants: "Mastership state: master"
            if re.search(r"mastership\s+state.*\bmaster\b", line, flags=re.IGNORECASE):
                return f"re{current_slot}"

        return None

    def load_var_log_dir(self, log_dir: Union[str, Path]) -> bool:
        """Load external var-log directory and register show log commands.

        Args:
            log_dir: Directory containing log files (for example, `var-re0`)

        Returns:
            True when at least one log file was loaded, False otherwise.

        Raises:
            RSIParseError: If the provided path is missing or not a directory.
        """
        path = self._normalize_input_path(log_dir)
        if not path.exists():
            raise RSIParseError(f"Var-log directory not found: {log_dir}")
        if not path.is_dir():
            raise RSIParseError(f"Var-log path is not a directory: {log_dir}")

        files = [p for p in sorted(path.iterdir(), key=lambda p: p.name.lower()) if p.is_file()]

        # Replace previously-registered synthetic show log commands before
        # loading a new log directory (for RE switching scenarios).
        for cmd in [c for c in list(self.commands.keys()) if c == "show log" or c.startswith("show log ")]:
            self.commands.pop(cmd, None)

        self.var_log_dir = path
        self.var_logs = {p.name: p for p in files}

        self._register_log_commands()
        return bool(self.var_logs)

    def autodiscover_var_log_dir(self, rsi_file_path: Union[str, Path]) -> bool:
        """Auto-discover common var-log directory locations near RSI file.

        Checks common case layouts such as sibling `var-re0`.
        """
        # Respect explicit load if already configured.
        if self.var_logs:
            return True

        p = Path(rsi_file_path)
        search_roots = [p.parent]
        if p.parent.parent != p.parent:
            search_roots.append(p.parent.parent)

        candidates: List[Path] = []
        for root in search_roots:
            candidates.extend([
                root / "var-re0",
                root / "var" / "log",
                root / "var" / "var" / "log",
                root / "varlog",
            ])

        seen: Set[str] = set()
        for candidate in candidates:
            key = str(candidate)
            if key in seen:
                continue
            seen.add(key)
            if candidate.exists() and candidate.is_dir():
                try:
                    return self.load_var_log_dir(candidate)
                except RSIParseError:
                    continue

        return False

    def has_var_logs(self) -> bool:
        """Return True when external var-log files are loaded."""
        return bool(self.var_logs)



    def get_log_files(self) -> List[str]:
        """Return available var-log filenames."""
        return sorted(self.var_logs.keys(), key=lambda n: n.lower())

    def _register_log_commands(self) -> None:
        """Register synthetic show log commands for completion and matching."""
        if not self.var_logs:
            return

        self.commands.setdefault("show log", "")
        for name in self.get_log_files():
            self.commands.setdefault(f"show log {name}", "")

        if "messages" in self.var_logs:
            self.commands.setdefault("show log messages", "")

    def _format_log_entry(self, name: str, path: Path) -> str:
        """Format one log file entry similar to Junos completion output."""
        try:
            stat = path.stat()
            size = stat.st_size
            changed = datetime.fromtimestamp(stat.st_mtime).strftime("%b %d %Y %H:%M:%S")
            return f"{name:<24} Size: {size}, Last changed: {changed}"
        except OSError:
            return f"{name:<24} Size: unknown, Last changed: unknown"

    def get_log_listing_output(self) -> Optional[str]:
        """Return output for `show log` command."""
        if not self.var_logs:
            return None
        lines = [self._format_log_entry(name, self.var_logs[name]) for name in self.get_log_files()]
        return "\n".join(lines)

    def get_log_help_lines(self) -> List[str]:
        """Return help lines for `show log ?` command."""
        if not self.var_logs:
            return ["Possible completions:", "(no log files loaded)"]

        lines = [
            "Possible completions:",
            "<Enter>                Execute this command",
            "<filename>             Name of log file",
        ]
        for name in self.get_log_files():
            lines.append(self._format_log_entry(name, self.var_logs[name]))
        return lines

    def get_log_output(self, filename: str) -> Optional[str]:
        """Return the content of a log file for `show log <filename>`.

        Supports plain-text files and `.gz` files.
        """
        if not self.var_logs:
            return None

        path = self.var_logs.get(filename)
        if path is None:
            return None

        try:
            if filename.endswith(".gz"):
                with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
                    return f.read()
            with open(path, encoding="utf-8", errors="replace") as f:
                return f.read()
        except OSError:
            return None

    def get_user(self) -> Optional[str]:
        """Return the extracted username from the RSI file.

        Returns:
            The username extracted from command prompts, or None if not yet parsed
        """
        return self.user

    def get_hostname(self) -> Optional[str]:
        """Return the extracted hostname from the RSI file.

        Returns:
            The hostname extracted from command prompts, or None if not yet parsed
        """
        return self.hostname

    def get_master_re_name(self) -> Optional[str]:
        """Return detected master RE name as re0/re1 when available."""
        return self.master_re_name

    def get_junos_version(self) -> Optional[str]:
        """Extract Junos version string from 'show version' output in RSI.

        Returns e.g. '23.2R2-S3.8', or None if not found.
        """
        import re as _re
        for cmd, out in self.commands.items():
            if "show version" not in cmd:
                continue
            # Match "Junos: 23.2R2-S3.8" or "JUNOS Software Release [23.2R2-S3.8]"
            m = _re.search(
                r"(?:Junos|JUNOS)[^\d]*(\d+\.\d+[A-Z]\d+[\w\-\.]*)",
                out,
                _re.IGNORECASE,
            )
            if m:
                return m.group(1)
        return None

    def get_command_output(self, command: str) -> Optional[str]:
        """Get output for a specific command.

        Args:
            command: The command to look up

        Returns:
            The output for the specified command, or None if command not found
        """
        return self.commands.get(command)

    def get_commands(self) -> Dict[str, str]:
        """Return dictionary of all commands and their outputs.

        Returns:
            A copy of the commands dictionary mapping command strings to outputs
        """
        return self.commands.copy()

    def parse_interfaces(self) -> None:
        """Parse interface data from show interfaces commands.

        Extracts interface information from various show interfaces commands
        and organizes them by interface name and command type.
        """
        # Clear existing interface data
        self.interfaces.clear()
        self.interface_hierarchy.clear()

        # Process each command that contains interface data
        for command, output in self.commands.items():
            if self._is_interface_command(command):
                command_type = self._extract_interface_command_type(command)
                self._parse_interface_output(output, command_type)

    def get_interface_output(
        self, interface_name: str, command_type: str = "extensive"
    ) -> Optional[str]:
        """Get filtered output for a specific interface.

        Args:
            interface_name: Name of interface (e.g., 'ge-0/0/0', 'ge-0/0/0.0')
            command_type: Type of interface command ('extensive', 'terse', 'queue')

        Returns:
            Filtered output for the specified interface, or None if not found.
            For physical interfaces, includes all logical interfaces underneath.
        """
        # Check if this is a specific logical interface request
        if "." in interface_name and interface_name in self.interfaces:
            # Return only the specific logical interface
            return self.interfaces[interface_name].get(command_type)

        # Check if this is a physical interface request
        if interface_name in self.interfaces:
            output_parts = []

            # Add the physical interface output
            physical_output = self.interfaces[interface_name].get(command_type)
            if physical_output:
                output_parts.append(physical_output)

            # Add all logical interfaces under this physical interface
            logical_interfaces = self.get_logical_interfaces(interface_name)
            for logical_interface in sorted(logical_interfaces):
                logical_output = self.interfaces[logical_interface].get(command_type)
                if logical_output:
                    output_parts.append(logical_output)

            if output_parts:
                # For terse output, remove duplicate headers
                if command_type == "terse":
                    return self._combine_terse_outputs(output_parts)
                else:
                    return "\n".join(output_parts)

        return None

    def get_available_interfaces(self) -> Set[str]:
        """Get set of all available interface names.

        Returns:
            Set of interface names found in RSI data
        """
        return set(self.interfaces.keys())

    def get_physical_interfaces(self) -> Set[str]:
        """Get set of physical interface names.

        Returns:
            Set of physical interface names (those without dots)
        """
        return {iface for iface in self.interfaces.keys() if "." not in iface}

    def get_logical_interfaces(self, physical_interface: str) -> List[str]:
        """Get logical interfaces for a physical interface.

        Args:
            physical_interface: Name of physical interface

        Returns:
            List of logical interface names under the physical interface
        """
        return self.interface_hierarchy.get(physical_interface, [])

    def _is_interface_command(self, command: str) -> bool:
        """Check if command is an interfaces-related command."""
        return command.startswith("show interfaces")

    def _extract_interface_command_type(self, command: str) -> str:
        """Extract the type of interface command (extensive, terse, etc.)."""
        if "terse" in command:
            return "terse"
        elif "queue" in command:
            return "queue"
        elif "extensive" in command:
            return "extensive"
        else:
            return "default"

    def _parse_interface_output(self, output: str, command_type: str) -> None:
        """Parse interface output and extract interface sections."""
        if command_type == "terse":
            self._parse_terse_output(output)
        elif command_type in ["extensive", "default"]:
            self._parse_extensive_output(output)
        elif command_type == "queue":
            self._parse_queue_output(output)

    def _parse_terse_output(self, output: str) -> None:
        """Parse terse interface output format."""
        lines = output.split("\n")
        current_section = []
        header_found = False

        for line in lines:
            # Skip until we find the header line
            if (
                not header_found
                and "Interface" in line
                and "Admin" in line
                and "Link" in line
            ):
                header_found = True
                current_section = [line]
                continue

            if header_found:
                if not line.strip():
                    # End of interface section
                    break

                current_section.append(line)

                # Extract interface name from line
                match = self._interface_terse_pattern.match(line)
                if match:
                    interface_name = match.group(1)
                    # Store the header + this interface line
                    interface_output = current_section[0] + "\n" + line
                    self._store_interface_data(
                        interface_name, "terse", interface_output
                    )

    def _parse_extensive_output(self, output: str) -> None:
        """Parse extensive interface output format."""
        lines = output.split("\n")
        current_interface = None
        current_section = []

        i = 0
        while i < len(lines):
            line = lines[i]

            # Check for physical interface
            phys_match = self._physical_interface_pattern.match(line)
            if phys_match:
                # Save previous interface if exists
                if current_interface and current_section:
                    section_text = "\n".join(current_section)
                    self._store_interface_data(
                        current_interface, "extensive", section_text
                    )

                # Start new physical interface
                current_interface = phys_match.group(1)
                current_section = [line]

                # Initialize hierarchy for physical interface
                if current_interface not in self.interface_hierarchy:
                    self.interface_hierarchy[current_interface] = []

                i += 1
                continue

            # Check for logical interface
            logical_match = self._logical_interface_pattern.match(line)
            if logical_match:
                # Save previous interface section if exists
                if current_interface and current_section:
                    section_text = "\n".join(current_section)
                    self._store_interface_data(
                        current_interface, "extensive", section_text
                    )

                # Start new logical interface
                logical_name = logical_match.group(1)
                current_interface = logical_name
                current_section = [line]

                # Add to hierarchy (find parent physical interface)
                physical_name = (
                    logical_name.split(".")[0] if "." in logical_name else logical_name
                )
                if physical_name in self.interface_hierarchy:
                    if logical_name not in self.interface_hierarchy[physical_name]:
                        self.interface_hierarchy[physical_name].append(logical_name)

                i += 1
                continue

            # Check if we're starting a new interface section
            if current_interface is None:
                i += 1
                continue

            # Check if this line starts a new major section (end current interface)
            if (
                line
                and not line.startswith(" ")
                and not line.startswith("\t")
                and not self._physical_interface_pattern.match(line)
                and not self._logical_interface_pattern.match(line)
                and current_section
            ):
                # This line doesn't belong to current interface
                break

            # Add line to current section
            if (
                line.strip() or current_section
            ):  # Include empty lines if we're in a section
                current_section.append(line)

            i += 1

        # Save last interface
        if current_interface and current_section:
            section_text = "\n".join(current_section)
            self._store_interface_data(current_interface, "extensive", section_text)

    def _parse_queue_output(self, output: str) -> None:
        """Parse queue interface output format into per-interface blocks.

        Accumulates lines per interface (like extensive): when a line starts with
        an interface-like name, start a new section; otherwise append to current.
        """
        lines = output.split("\n")
        current_interface: Optional[str] = None
        current_section: List[str] = []

        for line in lines:
            stripped = line.strip()
            if not stripped:
                if current_interface and current_section:
                    current_section.append(line)
                continue

            parts = stripped.split()
            if parts and self._looks_like_interface_name(parts[0]):
                # Save previous interface block
                if current_interface and current_section:
                    self._store_interface_data(
                        current_interface, "queue", "\n".join(current_section)
                    )
                current_interface = parts[0]
                current_section = [line]
            else:
                if current_interface:
                    current_section.append(line)

        if current_interface and current_section:
            self._store_interface_data(
                current_interface, "queue", "\n".join(current_section)
            )

    def _store_interface_data(
        self, interface_name: str, command_type: str, data: str
    ) -> None:
        """Store interface data in the interfaces dictionary."""
        if interface_name not in self.interfaces:
            self.interfaces[interface_name] = {}

        self.interfaces[interface_name][command_type] = data

    def _looks_like_interface_name(self, name: str) -> bool:
        """Check if a string looks like an interface name."""
        # Basic heuristic for interface names
        interface_prefixes = [
            "ge-",
            "xe-",
            "et-",
            "fe-",
            "so-",
            "ae",
            "lo",
            "st",
            "gr-",
            "ip-",
            "lsq-",
            "lt-",
            "mt-",
            "sp-",
            "dsc",
            "fti",
            "fxp",
            "gre",
            "ipip",
            "irb",
        ]
        return any(name.startswith(prefix) for prefix in interface_prefixes)

    def _combine_terse_outputs(self, output_parts: List[str]) -> str:
        """Combine terse interface outputs, removing duplicate headers.

        Args:
            output_parts: List of terse output strings, each with potential header

        Returns:
            Combined output with single header and all interface lines
        """
        if not output_parts:
            return ""

        header_line = None
        interface_lines = []

        for output in output_parts:
            lines = output.split("\n")
            for line in lines:
                if line.strip():  # Skip empty lines
                    # Check if this is a header line
                    if "Interface" in line and "Admin" in line and "Link" in line:
                        if header_line is None:
                            header_line = line
                        # Skip duplicate headers
                    else:
                        # This is an interface data line
                        interface_lines.append(line)

        # Combine header with all interface lines
        result_lines = []
        if header_line:
            result_lines.append(header_line)
        result_lines.extend(interface_lines)

        return "\n".join(result_lines)
