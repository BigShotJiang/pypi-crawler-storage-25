from enum import IntEnum, unique
from typing import Dict

from qlsdk.core.crc.crctools import crc16
from qlsdk.core.serial import SerialDevice
from loguru import logger

@unique
class ArsLSECommand(IntEnum):
    """
    设备命令枚举类
    使用 IntEnum 使得枚举值可以直接作为整数使用
    @unique 装饰器确保所有值都是唯一的
    """
    # 握手命令
    HAND_SHAKE = 0x01           # 握手
    
    # 电刺激相关命令
    STOP_E_STIM = 0x11          # 停止电刺激
    START_E_STIM = 0x17         # 开始电刺激
    GET_E_REMAIN_TIME = 0x18    # 获取剩余电刺激时间
    GET_E_PATTERN = 0x19        # 获取当前电刺激范式
    E_STIM_STATE_NOTIFY = 0x13  # 刺激状态通知(设备主动发)
    
    # 阻抗采集相关命令
    START_IMPEDANCE = 0x21      # 开始阻抗采集
    STOP_IMPEDANCE = 0x22       # 停止阻抗采集
    IMPEDANCE_DATA = 0x23       # 阻抗数据包(设备主动发)
    
    # 刺激电流相关
    E_CURRENT_DATA = 0x24       # 刺激电流推送(设备主动发)
    
    # 声光刺激相关命令
    SET_AL_STIM = 0x25          # 声光刺激配置
    STOP_AL_STIM = 0x26         # 声光刺激停止
    
    # 同步刺激命令
    SYNC_START_ALE = 0x27       # 光声电同步开始
    SYNC_STOP_ALE = 0x28        # 光声电同步结束
    GET_AL_REMAIN_TIME = 0x29   # 获取剩余声光刺激时间
    
    # 使用界面设置的参数开始刺激（不使用命令行参数）
    READY_FOR_UI_STIM = 0x2A        #准备刺激
    START_UI_STIM = 0x2B   #使用界面参数开始刺激
    STOP_UI_STIM = 0x2C    #停止界面参数刺激

# 可选：创建反向查找字典
CMD_DESCRIPTION: Dict[ArsLSECommand, str] = {
    ArsLSECommand.HAND_SHAKE: "握手",
    ArsLSECommand.STOP_E_STIM: "停止电刺激",
    ArsLSECommand.START_E_STIM: "开始电刺激",
    ArsLSECommand.GET_E_REMAIN_TIME: "获取剩余电刺激时间",
    ArsLSECommand.GET_E_PATTERN: "获取当前电刺激范式",
    ArsLSECommand.E_STIM_STATE_NOTIFY: "刺激状态通知(设备主动发)",
    ArsLSECommand.START_IMPEDANCE: "开始阻抗采集",
    ArsLSECommand.STOP_IMPEDANCE: "停止阻抗采集",
    ArsLSECommand.IMPEDANCE_DATA: "阻抗数据包(设备主动发)",
    ArsLSECommand.E_CURRENT_DATA: "刺激电流推送(设备主动发)",
    ArsLSECommand.SET_AL_STIM: "声光刺激配置",
    ArsLSECommand.STOP_AL_STIM: "声光刺激停止",
    ArsLSECommand.SYNC_START_ALE: "光声电同步开始",
    ArsLSECommand.SYNC_STOP_ALE: "光声电同步结束",
    ArsLSECommand.GET_AL_REMAIN_TIME: "获取剩余声光刺激时间",
    ArsLSECommand.READY_FOR_UI_STIM : "准备刺激（使用UI参数）",
    ArsLSECommand.START_UI_STIM : "开始刺激（使用UI参数）",
    ArsLSECommand.STOP_UI_STIM : "停止刺激（使用UI参数）"
}

class Message(object):
    def __init__(self, cmd: ArsLSECommand, data: bytes = b""):
        self.cmd = cmd
        self.data = data

class ArsLSEMessage(object):
    PKG_START = 0xA55A
    HEADER_LEN = 14
    
    @classmethod
    def _pack(cls, cmd: int, data: bytes = b"") -> bytes:    
        header = cls._pack_header(cmd, len(data))
        payload = header + data
        return payload + cls.checksum(payload)
    
    @classmethod
    def _pack_header(cls, cmd:int, data_len: int) -> bytes:
        return (
            ArsLSEMessage.PKG_START.to_bytes(2, 'little')
            + 0x0.to_bytes(6, 'little')  # 保留6字节
            + (ArsLSEMessage.HEADER_LEN + data_len + 2).to_bytes(4, 'little')  # +1 for checksum
            + cmd.to_bytes(2, 'little')
        )
    @staticmethod
    def checksum(data: bytes) -> bytes:
        return crc16(data).to_bytes(2, 'little')
    
    @staticmethod
    def handshake():
        return ArsLSEMessage._pack(ArsLSECommand.HAND_SHAKE.value)
    
    # 准备刺激、使用界面参数开始刺激、停止界面参数刺激的命令
    @staticmethod
    def ready_for_ui_stim():
        return ArsLSEMessage._pack(ArsLSECommand.READY_FOR_UI_STIM.value)
    
    # 开始刺激--使用界面参数
    @staticmethod
    def start_ui_stim():
        return ArsLSEMessage._pack(ArsLSECommand.START_UI_STIM.value)
    
    #停止刺激--使用界面参数
    @staticmethod
    def stop_ui_stim():
        return ArsLSEMessage._pack(ArsLSECommand.STOP_UI_STIM.value)

    @staticmethod
    def start_stim():
        mode = 2 # 暂不开启配置模式，直接用默认参数刺激
        body = mode.to_bytes(2, 'little')
        body += (1).to_bytes(4, 'little') # 固定1
        body += (0).to_bytes(4, 'little') # 保留4字节
        body += (0).to_bytes(4, 'little') # 无配置参数，长度0
        return ArsLSEMessage._pack(ArsLSECommand.START_E_STIM.value, body)
    
    @staticmethod
    def stop_stim():
        return ArsLSEMessage._pack(ArsLSECommand.STOP_E_STIM.value)
    
    
class ArsLse(object):
    def __init__(self, device: SerialDevice):
        if not device:
            raise ValueError("不能指定空设备")    
        
        self.device:SerialDevice = device
        
    def disconnect(self):
        self.device.disconnect()
        
    def connect(self):
        self.device.connect()
        # 读取设备返回的握手响应
        self.device.start_reading(self._response_handler)  # 确保读取线程正在运行
        
    def _response_handler(self, response: bytes):
        # 这里可以添加对不同响应的处理逻辑
        if len(response) >= 20:
            cmd = int.from_bytes(response[12:14], 'little')
            result = int.from_bytes(response[16:20], 'little')
            try:
                cmd_enum = ArsLSECommand(cmd)
                logger.debug(f"设备响应：{CMD_DESCRIPTION.get(cmd_enum.value, '未知命令')}-{('成功' if result == 0 else '失败')}")
            except ValueError:
                logger.debug(f"未知设备响应: {cmd.hex()}")
        
    def ready_for_ui_stim(self):
        logger.debug("发送准备刺激命令（使用UI参数）")
        return self.device.send(ArsLSEMessage.ready_for_ui_stim())
        
    def start_ui_stim(self):
        logger.debug("发送开始刺激命令(使用UI参数)")
        return self.device.send(ArsLSEMessage.start_ui_stim())
        
    def stop_ui_stim(self):
        logger.debug("发送停止刺激命令(使用UI参数)")
        return self.device.send(ArsLSEMessage.stop_ui_stim())
        