"""Tests for `datasight generate` persisting database configuration."""

from __future__ import annotations

import sqlite3
from types import SimpleNamespace

import duckdb
import pandas as pd
import pytest
from click.testing import CliRunner

from datasight.cli import cli
from datasight.config import set_env_vars
from datasight.explore import build_persistent_duckdb, create_ephemeral_session
from datasight.llm import TextBlock

from tests._env_helpers import DATASIGHT_ENV_VARS, scrub_datasight_env


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    for key in DATASIGHT_ENV_VARS:
        monkeypatch.delenv(key, raising=False)
    yield
    scrub_datasight_env()


@pytest.fixture
def parquet_file(tmp_path):
    path = tmp_path / "generation_fuel.parquet"
    pd.DataFrame(
        {
            "energy_source_code": ["WND", "SUN", "NG"],
            "net_generation_mwh": [100.0, 80.0, 200.0],
        }
    ).to_parquet(path)
    return path


# ---------------------------------------------------------------------------
# build_persistent_duckdb
# ---------------------------------------------------------------------------


def test_build_persistent_duckdb_creates_views(tmp_path, parquet_file):
    _, tables_info = create_ephemeral_session([str(parquet_file)])
    db_path = tmp_path / "out.duckdb"
    result = build_persistent_duckdb(db_path, tables_info)
    assert result == db_path.resolve()
    assert db_path.exists()

    with duckdb.connect(str(db_path), read_only=True) as conn:
        view_name = tables_info[0]["name"]
        df = conn.execute(f'SELECT COUNT(*) AS n FROM "{view_name}"').fetchdf()
        assert int(df["n"].iloc[0]) == 3


def test_build_persistent_duckdb_materializes_csv_tables(tmp_path):
    csv_path = tmp_path / "generation.csv"
    csv_path.write_text("x\n1\n2\n", encoding="utf-8")
    _, tables_info = create_ephemeral_session([str(csv_path)], import_mode="table")

    db_path = tmp_path / "out.duckdb"
    build_persistent_duckdb(db_path, tables_info)

    with duckdb.connect(str(db_path), read_only=True) as conn:
        relation = conn.execute(
            "SELECT table_type FROM information_schema.tables "
            "WHERE table_schema='main' AND table_name='generation'"
        ).fetchone()
        assert relation == ("BASE TABLE",)


def test_build_persistent_duckdb_refuses_overwrite(tmp_path, parquet_file):
    _, tables_info = create_ephemeral_session([str(parquet_file)])
    db_path = tmp_path / "out.duckdb"
    build_persistent_duckdb(db_path, tables_info)
    with pytest.raises(FileExistsError):
        build_persistent_duckdb(db_path, tables_info)
    build_persistent_duckdb(db_path, tables_info, overwrite=True)


# ---------------------------------------------------------------------------
# set_env_vars
# ---------------------------------------------------------------------------


def test_set_env_vars_creates_from_template(tmp_path):
    env_path = tmp_path / ".env"
    set_env_vars(env_path, {"DB_MODE": "duckdb", "DB_PATH": "./data.duckdb"})
    text = env_path.read_text(encoding="utf-8")
    assert "DB_MODE=duckdb" in text
    assert "DB_PATH=./data.duckdb" in text
    # Template placeholders preserved
    assert "ANTHROPIC_API_KEY" in text


def test_set_env_vars_replaces_existing_uncommented(tmp_path):
    env_path = tmp_path / ".env"
    env_path.write_text(
        "ANTHROPIC_API_KEY=my-key\nDB_MODE=sqlite\nDB_PATH=./old.sqlite\n",
        encoding="utf-8",
    )
    set_env_vars(env_path, {"DB_MODE": "duckdb", "DB_PATH": "./new.duckdb"})
    text = env_path.read_text(encoding="utf-8")
    assert "ANTHROPIC_API_KEY=my-key" in text
    assert "DB_MODE=duckdb" in text
    assert "DB_PATH=./new.duckdb" in text
    assert "./old.sqlite" not in text


def test_set_env_vars_uncomments_commented_line(tmp_path):
    env_path = tmp_path / ".env"
    env_path.write_text("# DB_PATH=./old.duckdb\n", encoding="utf-8")
    set_env_vars(env_path, {"DB_PATH": "./new.duckdb"})
    text = env_path.read_text(encoding="utf-8")
    assert "DB_PATH=./new.duckdb" in text
    assert "# DB_PATH" not in text


def test_set_env_vars_appends_missing(tmp_path):
    env_path = tmp_path / ".env"
    env_path.write_text("ANTHROPIC_API_KEY=x\n", encoding="utf-8")
    set_env_vars(env_path, {"NEW_VAR": "y"})
    text = env_path.read_text(encoding="utf-8")
    assert "ANTHROPIC_API_KEY=x" in text
    assert "NEW_VAR=y" in text


# ---------------------------------------------------------------------------
# CLI: datasight generate <file>
# ---------------------------------------------------------------------------


class _StubLLMClient:
    calls: list[dict]

    def __init__(self):
        self.calls = []

    async def create_message(self, **kwargs):
        self.calls.append(kwargs)
        text = (
            "--- schema_description.md ---\n"
            "# Schema\n\nGeneration fuel data.\n\n"
            "--- queries.yaml ---\n"
            "- question: Total MWh\n"
            "  sql: SELECT SUM(net_generation_mwh) FROM generation_fuel\n"
        )
        return SimpleNamespace(
            content=[TextBlock(text)],
            stop_reason="end_turn",
            usage=SimpleNamespace(input_tokens=1, output_tokens=1),
        )


@pytest.fixture
def stub_llm(monkeypatch):
    client = _StubLLMClient()
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    monkeypatch.setattr("datasight.cli.create_llm_client", lambda **kwargs: client)
    return client


def test_generate_creates_db_and_updates_env(tmp_path, parquet_file, stub_llm):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["generate", str(parquet_file), "--project-dir", str(tmp_path)],
    )
    assert result.exit_code == 0, result.output

    db_path = tmp_path / "database.duckdb"
    assert db_path.exists(), result.output

    env_path = tmp_path / ".env"
    assert env_path.exists()
    env_text = env_path.read_text(encoding="utf-8")
    assert "DB_MODE=duckdb" in env_text
    assert "DB_PATH=./database.duckdb" in env_text

    with duckdb.connect(str(db_path), read_only=True) as conn:
        tables = conn.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_schema='main'"
        ).fetchdf()
        assert "generation_fuel" in tables["table_name"].tolist()


def test_generate_respects_custom_db_path(tmp_path, parquet_file, stub_llm):
    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(parquet_file),
            "--project-dir",
            str(tmp_path),
            "--db-path",
            "db/custom.duckdb",
        ],
    )
    assert result.exit_code == 0, result.output
    assert (tmp_path / "db" / "custom.duckdb").exists()
    env_text = (tmp_path / ".env").read_text(encoding="utf-8")
    assert "DB_PATH=./db/custom.duckdb" in env_text


def test_generate_preserves_existing_spark_backend(tmp_path, parquet_file, stub_llm, monkeypatch):
    """generate <file> must not clobber DB_MODE=spark with DB_MODE=duckdb.

    The 'new project from parquet files' flow creates a local DuckDB
    mirror and writes DB_MODE=duckdb. When the project is already
    configured for Spark (or another non-DuckDB backend), that would
    silently replace the user's real backend. The command should
    preserve the existing .env and skip the DuckDB mirror.
    """
    env_path = tmp_path / ".env"
    env_path.write_text(
        "ANTHROPIC_API_KEY=test-key\nDB_MODE=spark\nSPARK_REMOTE=sc://my-cluster:15002\n",
        encoding="utf-8",
    )

    # Route the Spark-mode files session through the DuckDB path so the
    # test doesn't need a real Spark cluster. We're only exercising the
    # CLI's env-preservation logic here; the Spark plumbing is tested
    # separately in test_spark_runner.py.
    from datasight.explore import create_ephemeral_session

    def _fake_session(file_paths, settings, import_mode="auto"):
        return create_ephemeral_session(file_paths, import_mode=import_mode)

    # cli imports create_files_session_for_settings locally inside the
    # _run coroutine, so we patch where it lives in explore.
    monkeypatch.setattr("datasight.explore.create_files_session_for_settings", _fake_session)

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["generate", str(parquet_file), "--project-dir", str(tmp_path)],
    )
    assert result.exit_code == 0, result.output

    # No local DuckDB mirror.
    assert not (tmp_path / "database.duckdb").exists(), result.output

    # DB_MODE stays on spark; SPARK_REMOTE is preserved; no DB_PATH was added.
    env_text = env_path.read_text(encoding="utf-8")
    assert "DB_MODE=spark" in env_text, env_text
    assert "DB_MODE=duckdb" not in env_text, env_text
    assert "SPARK_REMOTE=sc://my-cluster:15002" in env_text, env_text
    assert "DB_PATH=" not in env_text, env_text

    # Schema description and queries are still written — those describe
    # the tables regardless of which backend serves them.
    assert (tmp_path / "schema_description.md").exists()
    assert (tmp_path / "queries.yaml").exists()


def test_generate_sqlite_file_updates_env_without_creating_duckdb(tmp_path, stub_llm):
    db_path = tmp_path / "generation.sqlite"
    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE generation_fuel (energy_source_code TEXT, net_generation_mwh REAL)")
    conn.executemany(
        "INSERT INTO generation_fuel VALUES (?, ?)",
        [("WND", 100.0), ("SUN", 80.0), ("NG", 200.0)],
    )
    conn.commit()
    conn.close()

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["generate", str(db_path), "--project-dir", str(tmp_path)],
    )
    assert result.exit_code == 0, result.output

    assert not (tmp_path / "database.duckdb").exists()
    env_text = (tmp_path / ".env").read_text(encoding="utf-8")
    assert "DB_MODE=sqlite" in env_text
    assert "DB_PATH=./generation.sqlite" in env_text
    assert "sqlite" in stub_llm.calls[0]["messages"][0]["content"].lower()


def test_generate_duckdb_file_updates_env_without_creating_default_db(tmp_path, stub_llm):
    db_path = tmp_path / "generation.duckdb"
    conn = duckdb.connect(str(db_path))
    conn.execute(
        "CREATE TABLE generation_fuel AS "
        "SELECT 'WND' AS energy_source_code, 100.0 AS net_generation_mwh"
    )
    conn.close()

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["generate", str(db_path), "--project-dir", str(tmp_path)],
    )
    assert result.exit_code == 0, result.output

    env_text = (tmp_path / ".env").read_text(encoding="utf-8")
    assert "DB_MODE=duckdb" in env_text
    assert "DB_PATH=./generation.duckdb" in env_text
    assert "duckdb" in stub_llm.calls[0]["messages"][0]["content"].lower()


def test_generate_import_mode_view_keeps_csv_as_view(tmp_path, stub_llm):
    csv_path = tmp_path / "generation.csv"
    csv_path.write_text(
        "energy_source_code,net_generation_mwh\nWND,100\nSUN,80\n", encoding="utf-8"
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(csv_path),
            "--project-dir",
            str(tmp_path),
            "--import-mode",
            "view",
        ],
    )
    assert result.exit_code == 0, result.output

    db_path = tmp_path / "database.duckdb"
    with duckdb.connect(str(db_path), read_only=True) as conn:
        relation = conn.execute(
            "SELECT table_type FROM information_schema.tables "
            "WHERE table_schema='main' AND table_name='generation'"
        ).fetchone()
        assert relation == ("VIEW",)


def test_generate_import_mode_table_materializes_before_introspection(
    tmp_path, stub_llm, monkeypatch
):
    csv_path = tmp_path / "generation.csv"
    csv_path.write_text(
        "energy_source_code,net_generation_mwh\nWND,100\nSUN,80\n", encoding="utf-8"
    )

    from datasight import explore as explore_module
    import datasight.schema as schema_module

    original_session = explore_module.create_files_session_for_settings
    original_build = explore_module.build_persistent_duckdb
    captured: dict[str, object] = {}
    session_import_modes: list[str] = []
    introspect_runner_types: list[str] = []

    def _capturing_session(file_paths, settings, import_mode="auto"):
        session_import_modes.append(import_mode)
        return original_session(file_paths, settings, import_mode=import_mode)

    def _capturing_build(db_path, tables_info, *, overwrite=False):
        captured["persistent_import_modes"] = [t.get("import_mode") for t in tables_info]
        return original_build(db_path, tables_info, overwrite=overwrite)

    async def _capturing_introspect_schema(run_sql, runner=None):
        introspect_runner_types.append(type(runner).__name__)
        return await original_introspect_schema(run_sql, runner=runner)

    original_introspect_schema = schema_module.introspect_schema
    monkeypatch.setattr(explore_module, "create_files_session_for_settings", _capturing_session)
    monkeypatch.setattr(explore_module, "build_persistent_duckdb", _capturing_build)
    monkeypatch.setattr(schema_module, "introspect_schema", _capturing_introspect_schema)

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(csv_path),
            "--project-dir",
            str(tmp_path),
            "--import-mode",
            "table",
        ],
    )
    assert result.exit_code == 0, result.output
    assert session_import_modes == ["auto"]
    assert captured["persistent_import_modes"] == ["table"]
    assert introspect_runner_types == ["DuckDBRunner"] * 3

    db_path = tmp_path / "database.duckdb"
    with duckdb.connect(str(db_path), read_only=True) as conn:
        relation = conn.execute(
            "SELECT table_type FROM information_schema.tables "
            "WHERE table_schema='main' AND table_name='generation'"
        ).fetchone()
        assert relation == ("BASE TABLE",)


def test_generate_rejects_import_mode_with_existing_duckdb(tmp_path, stub_llm):
    db_path = tmp_path / "generation.duckdb"
    conn = duckdb.connect(str(db_path))
    conn.execute("CREATE TABLE generation_fuel (energy_source_code VARCHAR)")
    conn.close()

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(db_path),
            "--project-dir",
            str(tmp_path),
            "--import-mode",
            "table",
        ],
    )
    assert result.exit_code != 0
    assert "--import-mode only applies" in result.output
    assert not stub_llm.calls


def test_generate_rejects_import_mode_without_files(tmp_path, stub_llm):
    db_path = tmp_path / "generation.duckdb"
    conn = duckdb.connect(str(db_path))
    conn.execute("CREATE TABLE generation_fuel (energy_source_code VARCHAR)")
    conn.close()

    env_path = tmp_path / ".env"
    env_path.write_text(
        "ANTHROPIC_API_KEY=test-key\nDB_MODE=duckdb\nDB_PATH=./generation.duckdb\n",
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["generate", "--project-dir", str(tmp_path), "--import-mode", "table"],
    )
    assert result.exit_code != 0
    assert "--import-mode only applies when importing CSV/Parquet/Excel files" in result.output
    assert not stub_llm.calls


def test_generate_warns_and_allows_excel_in_view_mode(tmp_path, stub_llm):
    xlsx_path = tmp_path / "generation.xlsx"
    pd.DataFrame({"energy_source_code": ["WND"], "net_generation_mwh": [100]}).to_excel(
        xlsx_path, index=False
    )
    csv_path = tmp_path / "plants.csv"
    csv_path.write_text("plant_id,name\n1,Alpha\n", encoding="utf-8")

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(xlsx_path),
            str(csv_path),
            "--project-dir",
            str(tmp_path),
            "--import-mode",
            "view",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "Warning: Excel inputs are always materialized as DuckDB tables" in result.output
    assert stub_llm.calls

    db_path = tmp_path / "database.duckdb"
    with duckdb.connect(str(db_path), read_only=True) as conn:
        relation_types = dict(
            conn.execute(
                "SELECT table_name, table_type FROM information_schema.tables "
                "WHERE table_schema='main'"
            ).fetchall()
        )
        assert relation_types["generation"] == "BASE TABLE"
        assert relation_types["plants"] == "VIEW"


def test_generate_rejects_import_mode_table_for_spark_files(tmp_path, parquet_file, stub_llm):
    env_path = tmp_path / ".env"
    env_path.write_text(
        "ANTHROPIC_API_KEY=test-key\nDB_MODE=spark\nSPARK_REMOTE=sc://my-cluster:15002\n",
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(parquet_file),
            "--project-dir",
            str(tmp_path),
            "--import-mode",
            "table",
        ],
    )
    assert result.exit_code != 0
    assert "--import-mode=table is not supported when DB_MODE=spark" in result.output
    assert not stub_llm.calls


def test_generate_rejects_import_mode_table_for_non_duckdb_file_projects(
    tmp_path, parquet_file, stub_llm
):
    env_path = tmp_path / ".env"
    env_path.write_text(
        "ANTHROPIC_API_KEY=test-key\nDB_MODE=postgres\nDB_HOST=localhost\nDB_NAME=grid\n",
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(parquet_file),
            "--project-dir",
            str(tmp_path),
            "--import-mode",
            "table",
        ],
    )
    assert result.exit_code != 0
    assert "--import-mode=table requires DB_MODE=duckdb" in result.output
    assert not stub_llm.calls


def test_generate_reports_generic_import_mode_error_for_direct_db_inputs_in_spark_project(
    tmp_path, stub_llm
):
    db_path = tmp_path / "generation.duckdb"
    conn = duckdb.connect(str(db_path))
    conn.execute("CREATE TABLE generation_fuel (energy_source_code VARCHAR)")
    conn.close()

    env_path = tmp_path / ".env"
    env_path.write_text(
        "ANTHROPIC_API_KEY=test-key\nDB_MODE=spark\nSPARK_REMOTE=sc://my-cluster:15002\n",
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(db_path),
            "--project-dir",
            str(tmp_path),
            "--import-mode",
            "table",
        ],
    )
    assert result.exit_code != 0
    assert "--import-mode only applies when importing CSV/Parquet/Excel" in result.output
    assert "DB_MODE=spark" not in result.output
    assert not stub_llm.calls


def test_generate_rejects_db_path_with_existing_sqlite(tmp_path, stub_llm):
    db_path = tmp_path / "generation.sqlite"
    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE generation_fuel (energy_source_code TEXT)")
    conn.commit()
    conn.close()

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(db_path),
            "--project-dir",
            str(tmp_path),
            "--db-path",
            "db/custom.duckdb",
        ],
    )
    assert result.exit_code != 0
    assert "--db-path is only used" in result.output
    assert not stub_llm.calls


def test_generate_rejects_db_path_with_existing_duckdb(tmp_path, stub_llm):
    db_path = tmp_path / "generation.duckdb"
    conn = duckdb.connect(str(db_path))
    conn.execute("CREATE TABLE generation_fuel (energy_source_code VARCHAR)")
    conn.close()

    runner = CliRunner()
    result = runner.invoke(
        cli,
        [
            "generate",
            str(db_path),
            "--project-dir",
            str(tmp_path),
            "--db-path",
            "db/custom.duckdb",
        ],
    )
    assert result.exit_code != 0
    assert "--db-path is only used" in result.output
    assert not stub_llm.calls


def test_generate_rejects_sqlite_file_mixed_with_other_inputs(tmp_path, parquet_file, stub_llm):
    db_path = tmp_path / "generation.sqlite"
    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE generation_fuel (energy_source_code TEXT)")
    conn.commit()
    conn.close()

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["generate", str(db_path), str(parquet_file), "--project-dir", str(tmp_path)],
    )
    assert result.exit_code != 0
    assert "SQLite input currently supports exactly one" in result.output
    assert not stub_llm.calls


def test_generate_refuses_to_overwrite_existing_db(tmp_path, parquet_file, stub_llm):
    (tmp_path / "database.duckdb").write_bytes(b"")
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["generate", str(parquet_file), "--project-dir", str(tmp_path)],
    )
    assert result.exit_code != 0
    assert "already exists" in result.output


def test_generate_db_preflight_runs_before_llm_call(tmp_path, parquet_file, monkeypatch):
    """An existing DB must abort generate before docs are written or the LLM is called."""
    (tmp_path / "database.duckdb").write_bytes(b"")

    called = {"n": 0}

    def _unreachable(**kwargs):
        called["n"] += 1
        raise AssertionError("LLM should not be called when preflight rejects the run")

    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    monkeypatch.setattr("datasight.cli.create_llm_client", _unreachable)

    runner = CliRunner()
    result = runner.invoke(
        cli,
        ["generate", str(parquet_file), "--project-dir", str(tmp_path)],
    )
    assert result.exit_code != 0
    assert "database.duckdb" in result.output
    assert called["n"] == 0
    # No partial docs should have been left behind.
    for name in ("schema_description.md", "queries.yaml", "measures.yaml", "time_series.yaml"):
        assert not (tmp_path / name).exists(), (
            f"{name} was written before preflight rejected the run"
        )
