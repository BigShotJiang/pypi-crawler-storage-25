"""CLI command module."""

import sys
from pathlib import Path

import rich_click as click


from datasight import cli
from datasight.cli_helpers import format_epilog


@click.command(
    epilog=format_epilog(
        """
        Examples:

            datasight export --list-sessions
            datasight export abc123def -o my-analysis.html
            datasight export abc123def --format py -o my-analysis.py
            datasight export abc123def --format bundle -o analysis-bundle.zip
            datasight export abc123def --exclude 2,3
        """
    )
)
@click.argument("session_id", required=False)
@click.option(
    "--output",
    "-o",
    "output_path",
    type=click.Path(),
    default=None,
    help=(
        "Output file path. Defaults to <session_id>.<format> with the "
        "session ID truncated to 20 characters."
    ),
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["html", "py", "bundle"], case_sensitive=False),
    default="html",
    help="html (viewer), py (runnable script), or bundle (zip archive with artifacts).",
)
@click.option(
    "--include",
    "include_artifacts",
    default=None,
    help=(
        "Bundle-only: comma-separated artifacts to include. Choices: "
        "html,sql,python,csv,charts,metadata. Default: all."
    ),
)
@click.option(
    "--project-dir",
    type=click.Path(exists=True),
    default=".",
    help="Project directory containing .datasight/conversations/.",
)
@click.option(
    "--exclude",
    default=None,
    help="Comma-separated turn indices to exclude (0-based, each turn is a Q&A pair).",
)
@click.option("--list-sessions", is_flag=True, help="List available sessions and exit.")
def export(
    session_id,
    output_path,
    output_format,
    include_artifacts,
    project_dir,
    exclude,
    list_sessions,
):
    """Export a conversation session as a self-contained HTML page or Python script.

    SESSION_ID is the conversation ID (use --list-sessions to see available IDs).
    """
    import json as json_mod

    project_dir = str(Path(project_dir).resolve())
    conv_dir = Path(project_dir) / ".datasight" / "conversations"

    if list_sessions or session_id == "list":
        if not conv_dir.exists():
            click.echo("No conversations found.")
            return
        sessions = []
        for f in sorted(conv_dir.glob("*.json")):
            try:
                data = json_mod.loads(f.read_text(encoding="utf-8"))
                events = data.get("events", [])
                msg_count = sum(1 for e in events if e.get("event") == "user_message")
                if msg_count == 0:
                    continue
                sessions.append(
                    {
                        "id": f.stem,
                        "title": data.get("title", "Untitled"),
                        "messages": msg_count,
                    }
                )
            except (json_mod.JSONDecodeError, OSError):
                continue
        if not sessions:
            click.echo("No conversations found.")
            return

        from rich.console import Console
        from rich.table import Table

        console = Console()
        table = Table(title="Available Sessions")
        table.add_column("Session ID", style="cyan", no_wrap=True)
        table.add_column("Title", overflow="fold")
        table.add_column("Messages", justify="right")
        for s in sessions:
            table.add_row(s["id"], s["title"], str(s["messages"]))
        console.print(table)
        return

    if not session_id:
        click.echo(
            "Error: provide a SESSION_ID or use --list-sessions to see available sessions.",
            err=True,
        )
        sys.exit(1)

    # Load session
    session_path = conv_dir / f"{session_id}.json"
    if not session_path.exists():
        click.echo(f"Error: Session not found: {session_id}", err=True)
        click.echo("Use 'datasight export --list-sessions' to see available sessions.", err=True)
        sys.exit(1)

    data = json_mod.loads(session_path.read_text(encoding="utf-8"))
    events = data.get("events", [])
    title = data.get("title", "datasight session")

    if not events:
        click.echo("Error: Session has no events.", err=True)
        sys.exit(1)

    exclude_indices: set[int] | None = None
    if exclude:
        try:
            exclude_indices = {int(x.strip()) for x in exclude.split(",")}
        except ValueError:
            click.echo("Error: --exclude must be comma-separated integers.", err=True)
            sys.exit(1)

    fmt = output_format.lower()
    include_values = None
    if include_artifacts:
        include_values = [item.strip() for item in include_artifacts.split(",") if item.strip()]
        if not include_values:
            click.echo(
                "Error: --include must name at least one artifact or be omitted.",
                err=True,
            )
            sys.exit(1)
    if include_values and fmt != "bundle":
        click.echo("Error: --include is only supported with --format bundle.", err=True)
        sys.exit(1)

    if fmt == "py":
        from datasight.export import export_session_python

        settings, _ = cli.resolve_settings(project_dir)
        db_path = cli.resolve_db_path(settings, project_dir)
        script = export_session_python(
            events,
            title=title,
            db_path=db_path,
            db_mode=settings.database.mode or "duckdb",
            exclude_indices=exclude_indices,
        )
        if not output_path:
            output_path = f"{session_id[:20]}.py"
        Path(output_path).write_text(script, encoding="utf-8")
        click.echo(f"Session exported to {output_path}")
        return

    if fmt == "bundle":
        from datasight.export import export_session_bundle, normalize_bundle_includes

        settings, _ = cli.resolve_settings(project_dir)
        db_path = cli.resolve_db_path(settings, project_dir)
        try:
            bundle = export_session_bundle(
                events,
                title=title,
                session_id=session_id,
                db_path=db_path,
                db_mode=settings.database.mode or "duckdb",
                exclude_indices=exclude_indices,
                include=normalize_bundle_includes(include_values),
            )
        except ValueError as exc:
            click.echo(f"Error: {exc}", err=True)
            sys.exit(1)
        if not output_path:
            output_path = f"{session_id[:20]}.zip"
        Path(output_path).write_bytes(bundle)
        click.echo(f"Session exported to {output_path}")
        return

    from datasight.export import export_session_html

    html = export_session_html(events, title=title, exclude_indices=exclude_indices)

    if not output_path:
        output_path = f"{session_id[:20]}.html"

    Path(output_path).write_text(html, encoding="utf-8")
    click.echo(f"Session exported to {output_path}")
