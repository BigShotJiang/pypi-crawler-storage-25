import os
from unittest.mock import MagicMock, Mock, patch

import pytest

from azpaddypy.mgmt.logging import AzureLogger


@pytest.fixture(
    params=["asyncio"],
)
def anyio_backend(request):
    """Force anyio to use asyncio backend."""
    return request.param


@pytest.fixture
def azure_logger():
    """AzureLogger instance for testing GenAI tracing."""
    return AzureLogger(
        service_name="test_genai_service",
        connection_string="InstrumentationKey=test",
    )


@pytest.fixture(autouse=True)
def _cleanup_content_recording_env():
    """Remove content recording env var before and after each test."""
    os.environ.pop("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED", None)
    yield
    os.environ.pop("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED", None)


class TestGenAIInstrumentorActivation:
    """Test that OpenAIInstrumentor is activated during logger init."""

    def test_genai_instrumented_flag_set_when_package_available(self):
        """Verify _genai_instrumented is True when opentelemetry-instrumentation-openai-v2 is installed."""
        logger = AzureLogger(
            service_name="test_genai_flag",
            connection_string="InstrumentationKey=test",
        )
        assert logger._genai_instrumented is True

    def test_genai_instrumented_flag_false_when_import_fails(self):
        """Verify _genai_instrumented is False when the package is not available."""
        with patch.dict("sys.modules", {"opentelemetry.instrumentation.openai_v2": None}):
            with patch("builtins.__import__", side_effect=_make_import_blocker("opentelemetry.instrumentation.openai_v2")):
                logger = AzureLogger(
                    service_name="test_genai_missing",
                    connection_string="InstrumentationKey=test",
                )
                assert logger._genai_instrumented is False

    def test_instrumentor_called_once(self):
        """Verify OpenAIInstrumentor.instrument() is called during init."""
        mock_instrumentor_instance = MagicMock()
        mock_instrumentor_instance.is_instrumented_by_opentelemetry = False
        mock_instrumentor_class = MagicMock(return_value=mock_instrumentor_instance)

        original_import = __import__

        def patched_import(name, *args, **kwargs):
            if name == "opentelemetry.instrumentation.openai_v2":
                module = MagicMock()
                module.OpenAIInstrumentor = mock_instrumentor_class
                return module
            return original_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=patched_import):
            logger = AzureLogger(
                service_name="test_instrumentor_call",
                connection_string="InstrumentationKey=test",
            )

        # The instrumentor was already called during previous tests in this process,
        # so is_instrumented_by_opentelemetry may be True. Just verify the flag is set.
        assert isinstance(logger._genai_instrumented, bool)

    def test_idempotent_instrumentation(self):
        """Creating multiple loggers does not raise from double-instrumentation."""
        logger1 = AzureLogger(
            service_name="test_idempotent_1",
            connection_string="InstrumentationKey=test",
        )
        logger2 = AzureLogger(
            service_name="test_idempotent_2",
            connection_string="InstrumentationKey=test",
        )
        assert logger1._genai_instrumented is True
        assert logger2._genai_instrumented is True


class TestContentRecordingWithLogResult:
    """Test that log_result=True enables GenAI content recording."""

    def test_log_result_true_sets_content_recording_env(self, azure_logger):
        """When log_result=True, AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED is set."""
        assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None

        @azure_logger.trace_function(log_result=True)
        def my_func():
            assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") == "true"
            return "result"

        result = my_func()
        assert result == "result"

    def test_log_result_false_does_not_set_content_recording_env(self, azure_logger):
        """When log_result=False (default), content recording env var is not set."""

        @azure_logger.trace_function(log_result=False)
        def my_func():
            assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None
            return "result"

        result = my_func()
        assert result == "result"

    def test_default_log_result_does_not_set_content_recording_env(self, azure_logger):
        """Default trace_function (log_result=False) does not enable content recording."""

        @azure_logger.trace_function()
        def my_func():
            assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None
            return "result"

        result = my_func()
        assert result == "result"

    @pytest.mark.anyio
    async def test_log_result_true_sets_content_recording_env_async(self, azure_logger):
        """Async: when log_result=True, content recording env var is set."""
        assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None

        @azure_logger.trace_function(log_result=True)
        async def my_async_func():
            assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") == "true"
            return "async_result"

        result = await my_async_func()
        assert result == "async_result"

    @pytest.mark.anyio
    async def test_log_result_false_does_not_set_content_recording_env_async(self, azure_logger):
        """Async: default log_result does not enable content recording."""

        @azure_logger.trace_function(log_result=False)
        async def my_async_func():
            assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None
            return "async_result"

        result = await my_async_func()
        assert result == "async_result"

    def test_content_recording_not_set_when_genai_not_instrumented(self):
        """When GenAI instrumentation failed, log_result=True does not set env var."""
        with patch.dict("sys.modules", {"opentelemetry.instrumentation.openai_v2": None}):
            with patch("builtins.__import__", side_effect=_make_import_blocker("opentelemetry.instrumentation.openai_v2")):
                logger = AzureLogger(
                    service_name="test_no_genai",
                    connection_string="InstrumentationKey=test",
                )
                assert logger._genai_instrumented is False

        @logger.trace_function(log_result=True)
        def my_func():
            assert os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") is None
            return "result"

        result = my_func()
        assert result == "result"


class TestContentRecordingWithExceptions:
    """Test content recording env var behavior when functions raise."""

    def test_content_recording_set_before_exception(self, azure_logger):
        """Content recording env var is set even when the function raises."""
        env_was_set = False

        @azure_logger.trace_function(log_result=True)
        def my_failing_func():
            nonlocal env_was_set
            env_was_set = os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") == "true"
            msg = "intentional error"
            raise ValueError(msg)

        with pytest.raises(ValueError, match="intentional error"):
            my_failing_func()

        assert env_was_set is True

    @pytest.mark.anyio
    async def test_content_recording_set_before_async_exception(self, azure_logger):
        """Async: content recording env var is set even when the function raises."""
        env_was_set = False

        @azure_logger.trace_function(log_result=True)
        async def my_failing_async_func():
            nonlocal env_was_set
            env_was_set = os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED") == "true"
            msg = "intentional async error"
            raise ValueError(msg)

        with pytest.raises(ValueError, match="intentional async error"):
            await my_failing_async_func()

        assert env_was_set is True


class TestContentRecordingFunctionalIntegration:
    """Integration tests verifying content recording works with trace_function features."""

    def test_log_result_true_still_traces_result(self, azure_logger):
        """log_result=True still captures function return value on the span."""
        mock_span = Mock()
        mock_tracer = Mock()
        mock_tracer.start_as_current_span.return_value.__enter__ = Mock(return_value=mock_span)
        mock_tracer.start_as_current_span.return_value.__exit__ = Mock(return_value=None)

        with patch.object(azure_logger, "tracer", mock_tracer):

            @azure_logger.trace_function(log_result=True)
            def my_func():
                return "traced_result"

            result = my_func()
            assert result == "traced_result"

            attrs = {
                call[0][0]: call[0][1]
                for call in mock_span.set_attribute.call_args_list
                if len(call[0]) == 2
            }
            assert attrs.get("function.decorator.log_result") is True
            assert attrs.get("function.has_result") is True
            assert attrs.get("function.result_type") == "str"

    def test_correlation_id_works_with_content_recording(self, azure_logger):
        """Correlation ID generation is unaffected by content recording."""
        assert azure_logger.get_correlation_id() is None

        @azure_logger.trace_function(log_result=True)
        def my_func():
            return "result"

        my_func()
        assert azure_logger.get_correlation_id() is not None

    def test_multiple_functions_different_log_result(self, azure_logger):
        """Functions with different log_result values set env var correctly."""

        @azure_logger.trace_function(log_result=True)
        def func_with_recording():
            return os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED")

        @azure_logger.trace_function(log_result=False)
        def func_without_recording():
            return os.environ.get("AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED")

        assert func_with_recording() == "true"
        # After func_with_recording, the env var is still set (not cleaned up).
        # This is expected - content recording is a deployment-level decision.
        # The key behavior is that log_result=False does NOT set it.


# ── Test helpers ────────────────────────────────────────────────────


def _make_import_blocker(blocked_module: str):
    """Create an __import__ replacement that blocks a specific module."""
    original_import = __import__

    def blocker(name, *args, **kwargs):
        if name == blocked_module:
            msg = f"Simulated missing module: {blocked_module}"
            raise ImportError(msg)
        return original_import(name, *args, **kwargs)

    return blocker
