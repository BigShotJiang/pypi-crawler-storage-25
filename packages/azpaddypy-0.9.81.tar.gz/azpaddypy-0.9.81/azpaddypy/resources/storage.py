import datetime
import mimetypes
from datetime import timedelta
from typing import Any, BinaryIO
from urllib.parse import quote, urlparse

import chardet
from azure.core.credentials import TokenCredential
from azure.core.exceptions import AzureError, ResourceExistsError, ResourceNotFoundError
from azure.storage.blob import (
    BlobClient,
    BlobServiceClient,
    ContentSettings,
    UserDelegationKey,
    generate_blob_sas,
    generate_container_sas,
)
from azure.storage.fileshare import ShareServiceClient
from azure.storage.queue import QueueServiceClient

from .._cache import RingCache
from ..mgmt.identity import AzureIdentity
from ..mgmt.logging import AzureLogger
from ._utils import setup_credential, setup_logger

# Storage instance caching (bounded ring buffer, max 10)
_storage_instances: RingCache = RingCache(maxsize=10)


class AzureStorage:
    """
    Azure Storage Account management with comprehensive blob, file share, and queue operations.

    Provides standardized Azure Storage operations using Azure SDK clients
    with integrated logging, error handling, and OpenTelemetry tracing support.
    Supports operations for blob storage, file shares, and queues with proper
    authentication and authorization handling. Container, share, and queue
    creation is handled by infrastructure as code.

    Attributes:
        account_url: Azure Storage Account URL
        service_name: Service identifier for logging and tracing
        service_version: Service version for context
        logger: AzureLogger instance for structured logging
        credential: Azure credential for authentication
        blob_service_client: Azure Blob Service Client instance
        file_service_client: Azure File Share Service Client instance
        queue_service_client: Azure Queue Service Client instance

    """

    def __init__(
        self,
        account_url: str,
        credential: TokenCredential | None = None,
        azure_identity: AzureIdentity | None = None,
        account_key: str | None = None,
        service_name: str = "azure_storage",
        service_version: str = "1.0.0",
        logger: AzureLogger | None = None,
        connection_string: str | None = None,
        enable_blob_storage: bool = True,
        enable_file_storage: bool = False,
        enable_queue_storage: bool = True,
    ):
        """
        Initialize Azure Storage with comprehensive configuration.

        Args:
            account_url: Azure Storage Account URL (e.g., https://account.blob.core.windows.net/)
            credential: Azure credential for authentication
            azure_identity: AzureIdentity instance for credential management
            account_key: Optional Azure Storage account key for SAS generation
            service_name: Service name for tracing context
            service_version: Service version for metadata
            logger: Optional AzureLogger instance
            connection_string: Application Insights connection string
            enable_blob_storage: Enable blob storage operations client
            enable_file_storage: Enable file share operations client
            enable_queue_storage: Enable queue storage operations client

        Raises:
            ValueError: If neither credential nor azure_identity is provided
            Exception: If client initialization fails

        """
        self.account_url = account_url
        self.account_name = urlparse(account_url).hostname.split(".")[0] if urlparse(account_url).hostname else ""
        self.account_key = account_key
        self.service_name = service_name
        self.service_version = service_version
        self.enable_blob_storage = enable_blob_storage
        self.enable_file_storage = enable_file_storage
        self.enable_queue_storage = enable_queue_storage

        # Initialize logger using utility function
        self.logger = setup_logger(
            logger=logger,
            service_name=service_name,
            service_version=service_version,
            connection_string=connection_string,
        )

        # Setup credential using utility function
        self.credential, _ = setup_credential(
            credential=credential,
            azure_identity=azure_identity,
        )

        # Initialize clients
        self.blob_service_client: BlobServiceClient | None = None
        self.file_service_client: ShareServiceClient | None = None
        self.queue_service_client: QueueServiceClient | None = None
        self.user_delegation_key: UserDelegationKey | None = None
        self._delegation_key_expiry: datetime.datetime | None = None

        self._setup_clients()

        self.logger.info(
            f"Azure Storage initialized for service '{service_name}' v{service_version}",
            extra={
                "account_url": account_url,
                "blob_enabled": enable_blob_storage,
                "file_enabled": enable_file_storage,
                "queue_enabled": enable_queue_storage,
            },
        )

    def _setup_clients(self):
        """
        Initialize Storage clients based on enabled features.

        Raises:
            Exception: If client initialization fails

        """
        try:
            if self.enable_blob_storage:
                self.blob_service_client = BlobServiceClient(account_url=self.account_url, credential=self.credential)
                self.logger.debug("BlobServiceClient initialized successfully")

                # If using token credential (RBAC), get a user delegation key for SAS generation
                if isinstance(self.credential, TokenCredential):
                    self._request_user_delegation_key()

            if self.enable_file_storage:
                file_url = self._build_service_url("file")
                self.file_service_client = ShareServiceClient(
                    account_url=file_url, credential=self.credential, token_intent="backup"
                )
                self.logger.debug("ShareServiceClient initialized successfully")

            if self.enable_queue_storage:
                queue_url = self._build_service_url("queue")
                self.queue_service_client = QueueServiceClient(account_url=queue_url, credential=self.credential)
                self.logger.debug("QueueServiceClient initialized successfully")

        except (AzureError, RuntimeError, ValueError):
            self.logger.exception("Failed to initialize Storage clients")
            raise

    def _build_service_url(self, service: str) -> str:
        """
        Build a service-specific URL from the account URL.

        Args:
            service: Service type ("blob", "file", "queue")

        Returns:
            URL for the specified service endpoint

        """
        parsed = urlparse(self.account_url)
        hostname = parsed.hostname or ""
        parts = hostname.split(".")

        # Replace the service subdomain (e.g., "account.blob.core..." -> "account.file.core...")
        if len(parts) >= 2 and parts[1] in ("blob", "file", "queue"):
            parts[1] = service
        else:
            # Fallback: construct from account name
            return f"https://{self.account_name}.{service}.core.windows.net/"

        new_hostname = ".".join(parts)
        return parsed._replace(netloc=new_hostname).geturl()

    def _request_user_delegation_key(self):
        """
        Request a user delegation key for generating user delegation SAS.
        The key is valid for 1 day.
        """
        if not self.blob_service_client:
            self.logger.warning("Blob service client not available. Cannot request user delegation key.")
            return

        try:
            self.logger.debug("Requesting user delegation key.")
            delegation_key_start_time = datetime.datetime.now(datetime.UTC)
            delegation_key_expiry_time = delegation_key_start_time + timedelta(days=1)

            self.user_delegation_key = self.blob_service_client.get_user_delegation_key(
                key_start_time=delegation_key_start_time,
                key_expiry_time=delegation_key_expiry_time,
            )
            self._delegation_key_expiry = delegation_key_expiry_time
            self.logger.info("Successfully obtained user delegation key.")
        except AzureError:
            self.logger.exception("Failed to get user delegation key")

    def _ensure_valid_delegation_key(self) -> None:
        """Renew the user delegation key if it has expired or is about to expire (within 5 minutes)."""
        if self.user_delegation_key is None:
            return

        if self._delegation_key_expiry is None:
            self._request_user_delegation_key()
            return

        buffer = timedelta(minutes=5)
        if datetime.datetime.now(datetime.UTC) + buffer >= self._delegation_key_expiry:
            self.logger.info("User delegation key is expiring soon, renewing.")
            self._request_user_delegation_key()

    def _detect_content_settings(
        self,
        file_name: str,
        data: bytes | str | BinaryIO,
        content_type: str | None = None,
    ) -> ContentSettings | None:
        """Detect content type and return ContentSettings for upload."""
        if content_type:
            return ContentSettings(content_type=content_type)

        if isinstance(data, bytes):
            guessed_type = mimetypes.MimeTypes().guess_type(file_name)[0]
            if guessed_type:
                charset = ""
                if "text" in guessed_type:
                    detected_encoding = chardet.detect(data).get("encoding", "utf-8")
                    charset = f"; charset={detected_encoding}"
                return ContentSettings(content_type=guessed_type + charset)

        return None

    # Blob Storage Operations
    def upload_blob(
        self,
        container_name: str,
        blob_name: str,
        data: bytes | str | BinaryIO,
        overwrite: bool = False,
        metadata: dict[str, str] | None = None,
        content_type: str | None = None,
        **kwargs,
    ) -> bool:
        """
        Upload a blob to Azure Blob Storage.
        If content_type is not provided, it will be inferred.

        Args:
            container_name: Name of the container
            blob_name: Name of the blob
            data: Data to upload (bytes, string, or file-like object)
            overwrite: Whether to overwrite existing blob
            metadata: Optional metadata for the blob
            content_type: Optional content type for the blob
            **kwargs: Additional parameters for blob upload

        Returns:
            True if blob was uploaded successfully

        Raises:
            RuntimeError: If blob service client is not initialized
            Exception: If blob upload fails

        """
        with self.logger.create_span(
            "AzureStorage.upload_blob",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_upload",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Uploading blob to Azure Storage",
                    extra={
                        "container_name": container_name,
                        "blob_name": blob_name,
                        "overwrite": overwrite,
                        "has_metadata": metadata is not None,
                        "content_type": content_type,
                    },
                )

                blob_client = self.blob_service_client.get_blob_client(
                    container=container_name,
                    blob=blob_name,
                )

                if isinstance(data, str):
                    data = data.encode("utf-8")

                if "content_settings" not in kwargs:
                    kwargs["content_settings"] = self._detect_content_settings(
                        file_name=blob_name, data=data, content_type=content_type
                    )

                blob_client.upload_blob(data, overwrite=overwrite, metadata=metadata, **kwargs)

                self.logger.info(
                    "Blob uploaded successfully",
                    extra={"container_name": container_name, "blob_name": blob_name, "overwrite": overwrite},
                )

                return True

            except (AzureError, ValueError, OSError, TypeError):
                self.logger.exception(
                    f"Failed to upload blob '{blob_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    def download_blob_by_url(self, blob_url: str, credential: TokenCredential | None = None, **kwargs) -> bytes | None:
        """
        Download a blob directly by URL using specified credentials.

        Args:
            blob_url: Full URL to the blob (e.g., https://account.blob.core.windows.net/container/blob)
            credential: Azure credential for authentication (if None, uses instance credential)
            **kwargs: Additional parameters for blob download

        Returns:
            Blob data as bytes if found, None if not found

        Raises:
            ValueError: If blob URL is invalid or no credential available
            Exception: If blob download fails for reasons other than not found

        """
        with self.logger.create_span(
            "AzureStorage.download_blob_by_url",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_download_by_url",
                "storage.blob_url": blob_url,
            },
        ):
            try:
                self.logger.debug("Downloading blob by URL", extra={"blob_url": blob_url})

                # Use provided credential or fall back to instance credential
                download_credential = credential if credential is not None else self.credential

                if download_credential is None:
                    msg = "No credential available for blob download"
                    raise ValueError(msg)

                # Create blob client directly from URL
                blob_client = BlobClient.from_blob_url(blob_url=blob_url, credential=download_credential)

                blob_data = blob_client.download_blob(**kwargs)
                content = blob_data.readall()

                self.logger.info(
                    "Blob downloaded successfully by URL",
                    extra={"blob_url": blob_url, "content_length": len(content) if content else 0},
                )

                return content

            except ResourceNotFoundError:
                self.logger.warning(f"Blob not found at URL: {blob_url}", extra={"blob_url": blob_url})
                return None
            except AzureError:
                self.logger.exception(f"Failed to download blob by URL '{blob_url}'", extra={"blob_url": blob_url})
                raise

    def download_blob(self, container_name: str, blob_name: str, **kwargs) -> bytes | None:
        """
        Download a blob from Azure Blob Storage.

        Args:
            container_name: Name of the container
            blob_name: Name of the blob
            **kwargs: Additional parameters for blob download

        Returns:
            Blob data as bytes if found, None if not found

        Raises:
            RuntimeError: If blob service client is not initialized
            Exception: If blob download fails for reasons other than not found

        """
        with self.logger.create_span(
            "AzureStorage.download_blob",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_download",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Downloading blob from Azure Storage",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )

                blob_client = self.blob_service_client.get_blob_client(container=container_name, blob=blob_name)

                blob_data = blob_client.download_blob(**kwargs)
                content = blob_data.readall()

                self.logger.info(
                    "Blob downloaded successfully",
                    extra={
                        "container_name": container_name,
                        "blob_name": blob_name,
                        "content_length": len(content) if content else 0,
                    },
                )

                return content

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Blob '{blob_name}' not found in container '{container_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to download blob '{blob_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    def delete_blob(self, container_name: str, blob_name: str, **kwargs) -> bool:
        """
        Delete a blob from Azure Blob Storage.

        Args:
            container_name: Name of the container
            blob_name: Name of the blob to delete
            **kwargs: Additional parameters for blob deletion

        Returns:
            True if blob was deleted successfully

        Raises:
            RuntimeError: If blob service client is not initialized
            Exception: If blob deletion fails

        """
        with self.logger.create_span(
            "AzureStorage.delete_blob",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_deletion",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Deleting blob from Azure Storage", extra={"container_name": container_name, "blob_name": blob_name}
                )

                blob_client = self.blob_service_client.get_blob_client(container=container_name, blob=blob_name)

                blob_client.delete_blob(**kwargs)

                self.logger.info(
                    "Blob deleted successfully", extra={"container_name": container_name, "blob_name": blob_name}
                )

                return True

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Blob '{blob_name}' not found in container '{container_name}' for deletion",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                return False
            except AzureError:
                self.logger.exception(
                    f"Failed to delete blob '{blob_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    def list_blobs(
        self,
        container_name: str,
        name_starts_with: str | None = None,
        max_results: int | None = None,
        **kwargs,
    ) -> list[str]:
        """
        List blobs in a container.

        Args:
            container_name: Name of the container
            name_starts_with: Optional prefix to filter blob names
            max_results: Maximum number of blob names to return (None for all)
            **kwargs: Additional parameters for listing blobs

        Returns:
            List of blob names

        Raises:
            RuntimeError: If blob service client is not initialized
            AzureError: If listing blobs fails

        """
        with self.logger.create_span(
            "AzureStorage.list_blobs",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_listing",
                "storage.container_name": container_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Listing blobs from Azure Storage",
                    extra={"container_name": container_name, "name_starts_with": name_starts_with},
                )

                container_client = self.blob_service_client.get_container_client(container_name)

                blob_names = []
                for blob in container_client.list_blobs(name_starts_with=name_starts_with, **kwargs):
                    blob_names.append(blob.name)
                    if max_results is not None and len(blob_names) >= max_results:
                        break

                self.logger.info(
                    "Blobs listed successfully", extra={"container_name": container_name, "blob_count": len(blob_names)}
                )

                return blob_names

            except AzureError:
                self.logger.exception(
                    f"Failed to list blobs in container '{container_name}'",
                    extra={"container_name": container_name},
                )
                raise

    def blob_exists(self, container_name: str, blob_name: str) -> bool:
        """
        Check if a blob exists in a container.

        Args:
            container_name: Name of the container
            blob_name: Name of the blob

        Returns:
            True if the blob exists, False otherwise

        Raises:
            RuntimeError: If blob service client is not initialized

        """
        with self.logger.create_span(
            "AzureStorage.blob_exists",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_exists",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                blob_client = self.blob_service_client.get_blob_client(container=container_name, blob=blob_name)
                exists = blob_client.exists()
                self.logger.debug(f"Blob '{blob_name}' exists: {exists}")
                return exists
            except AzureError:
                self.logger.exception(
                    f"Failed to check existence for blob '{blob_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    def delete_blobs(
        self,
        container_name: str,
        blob_names: list[str] | dict[str, Any],
        integrated_vectorization: bool = False,
        **kwargs,
    ) -> dict[str, bool]:
        """
        Delete multiple blobs from Azure Blob Storage using the SDK batch API.

        Uses ContainerClient.delete_blobs() which sends a single batch request
        for up to 256 blobs, significantly reducing HTTP round-trips compared
        to individual delete calls.

        Args:
            container_name: Name of the container
            blob_names: List of blob names or dict with filenames as keys
            integrated_vectorization: If True, use full paths; if False, extract filename from path
            **kwargs: Additional parameters for blob deletion

        Returns:
            Dictionary mapping blob names to deletion success status

        Raises:
            RuntimeError: If blob service client is not initialized
            AzureError: If batch deletion fails

        """
        with self.logger.create_span(
            "AzureStorage.delete_blobs",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_batch_deletion",
                "storage.container_name": container_name,
                "storage.account_url": self.account_url,
                "storage.blob_count": len(blob_names),
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Batch deleting blobs from Azure Storage",
                    extra={
                        "container_name": container_name,
                        "blob_count": len(blob_names),
                        "integrated_vectorization": integrated_vectorization,
                    },
                )

                # Handle dict input (filename -> ids mapping)
                if isinstance(blob_names, dict):
                    filenames = list(blob_names.keys())
                else:
                    filenames = blob_names

                # Build resolved blob names
                resolved_names = [
                    f if integrated_vectorization else f.split("/")[-1] for f in filenames
                ]

                container_client = self.blob_service_client.get_container_client(container_name)

                results: dict[str, bool] = dict.fromkeys(filenames, True)

                # SDK batch delete: processes up to 256 per request
                batch_results = container_client.delete_blobs(*resolved_names, **kwargs)
                for i, result in enumerate(batch_results):
                    original_name = filenames[i]
                    if isinstance(result, Exception):
                        if isinstance(result, ResourceNotFoundError):
                            self.logger.warning(f"Blob not found for deletion: {resolved_names[i]}")
                        else:
                            self.logger.warning(
                                f"Failed to delete blob '{resolved_names[i]}': {result}",
                                extra={"container_name": container_name},
                            )
                        results[original_name] = False

                successful_deletions = sum(1 for success in results.values() if success)
                self.logger.info(
                    "Batch blob deletion completed",
                    extra={
                        "container_name": container_name,
                        "total_blobs": len(blob_names),
                        "successful_deletions": successful_deletions,
                        "failed_deletions": len(blob_names) - successful_deletions,
                    },
                )

                return results

            except AzureError:
                self.logger.exception(
                    f"Failed to batch delete blobs in container '{container_name}'",
                    extra={"container_name": container_name},
                )
                raise

    def list_blobs_with_metadata(
        self,
        container_name: str,
        name_starts_with: str | None = None,
        include_sas: bool = True,
        sas_expiry_delta: timedelta = timedelta(hours=3),
        **kwargs,
    ) -> list[dict[str, Any]]:
        """
        List blobs with metadata and optional SAS URLs.

        Returns blob properties including name, size, timestamps, content type,
        raw metadata dict, and optionally a SAS-signed full URL.

        Args:
            container_name: Name of the container
            name_starts_with: Optional prefix to filter blob names
            include_sas: Whether to include SAS URLs for each blob
            sas_expiry_delta: Timedelta for SAS URL validity
            **kwargs: Additional parameters for listing blobs

        Returns:
            List of dictionaries with keys: filename, size, last_modified,
            etag, content_type, metadata, fullpath

        Raises:
            RuntimeError: If blob service client is not initialized
            AzureError: If listing blobs fails

        """
        with self.logger.create_span(
            "AzureStorage.list_blobs_with_metadata",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_listing_enhanced",
                "storage.container_name": container_name,
                "storage.account_url": self.account_url,
                "storage.include_sas": include_sas,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Listing blobs with metadata from Azure Storage",
                    extra={
                        "container_name": container_name,
                        "name_starts_with": name_starts_with,
                        "include_sas": include_sas,
                    },
                )

                container_client = self.blob_service_client.get_container_client(container_name)

                # Get container SAS if needed
                container_sas = ""
                if include_sas:
                    try:
                        container_sas = self.get_container_sas(
                            container_name=container_name, permission="r", expiry_delta=sas_expiry_delta
                        )
                    except AzureError as e:
                        self.logger.warning(f"Failed to generate container SAS: {e}")
                        include_sas = False

                files: list[dict[str, Any]] = []

                for blob in container_client.list_blobs(
                    name_starts_with=name_starts_with, include=["metadata"], **kwargs
                ):
                    blob_info: dict[str, Any] = {
                        "filename": blob.name,
                        "size": blob.size,
                        "last_modified": blob.last_modified,
                        "etag": blob.etag,
                        "content_type": getattr(blob, "content_settings", {}).get("content_type")
                        if hasattr(blob, "content_settings")
                        else None,
                        "metadata": blob.metadata or {},
                    }

                    encoded_blob_name = quote(blob.name, safe="/")
                    if include_sas and container_sas:
                        blob_info["fullpath"] = (
                            f"{self.account_url}{container_name}/{encoded_blob_name}?{container_sas}"
                        )
                    else:
                        blob_info["fullpath"] = f"{self.account_url}{container_name}/{encoded_blob_name}"

                    files.append(blob_info)

                self.logger.info(
                    "Blobs listed with metadata successfully",
                    extra={
                        "container_name": container_name,
                        "blob_count": len(files),
                        "include_sas": include_sas,
                    },
                )

                return files

            except AzureError:
                self.logger.exception(
                    f"Failed to list blobs with metadata in container '{container_name}'",
                    extra={"container_name": container_name},
                )
                raise

    def get_blob_properties(self, container_name: str, blob_name: str) -> Any | None:
        """Get properties of a specific blob."""
        with self.logger.create_span(
            "AzureStorage.get_blob_properties",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_properties",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Getting blob properties",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )

                blob_client = self.blob_service_client.get_blob_client(container=container_name, blob=blob_name)
                properties = blob_client.get_blob_properties()

                self.logger.info(
                    "Blob properties retrieved successfully",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )

                return properties

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Blob '{blob_name}' not found in container '{container_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to get properties for blob '{blob_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    def get_blob_properties_by_url(
        self, blob_url: str, credential: TokenCredential | None = None, **kwargs
    ) -> Any | None:
        """
        Get properties of a specific blob using its URL.

        Args:
            blob_url: Full URL to the blob (e.g., https://account.blob.core.windows.net/container/blob)
            credential: Azure credential for authentication (if None, uses instance credential)
            **kwargs: Additional parameters for blob property retrieval

        Returns:
            Blob properties if found, None if not found

        Raises:
            ValueError: If blob URL is invalid or no credential available
            Exception: If getting blob properties fails for reasons other than not found

        Example:
            ```python
            storage = AzureStorage(account_url="https://account.blob.core.windows.net/")
            url = "https://stdatarpcdev.blob.core.windows.net/documents/1-document-2025-09-18 07:40:41.333584.json"
            properties = storage.get_blob_properties_by_url(url)
            if properties:
                print(f"Blob size: {properties.size}")
                print(f"Last modified: {properties.last_modified}")
            ```

        """
        with self.logger.create_span(
            "AzureStorage.get_blob_properties_by_url",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_properties_by_url",
                "storage.blob_url": blob_url,
            },
        ):
            try:
                self.logger.debug("Getting blob properties by URL", extra={"blob_url": blob_url})

                # Use provided credential or fall back to instance credential
                properties_credential = credential if credential is not None else self.credential

                if properties_credential is None:
                    msg = "No credential available for blob properties retrieval"
                    raise ValueError(msg)

                # Create blob client directly from URL
                blob_client = BlobClient.from_blob_url(blob_url=blob_url, credential=properties_credential)

                properties = blob_client.get_blob_properties(**kwargs)

                self.logger.info(
                    "Blob properties retrieved successfully by URL",
                    extra={
                        "blob_url": blob_url,
                        "blob_size": getattr(properties, "size", 0),
                        "last_modified": getattr(properties, "last_modified", None),
                    },
                )

                return properties

            except ResourceNotFoundError:
                self.logger.warning(f"Blob not found at URL: {blob_url}", extra={"blob_url": blob_url})
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to get blob properties by URL '{blob_url}'",
                    extra={"blob_url": blob_url},
                )
                raise

    # Append Blob Operations
    def create_append_blob(
        self,
        container_name: str,
        blob_name: str,
        metadata: dict[str, str] | None = None,
        content_type: str | None = None,
        **kwargs,
    ) -> bool:
        """
        Create an empty append blob in Azure Blob Storage.

        Args:
            container_name: Name of the container
            blob_name: Name of the append blob
            metadata: Optional metadata for the blob
            content_type: Optional content type for the blob
            **kwargs: Additional parameters for blob creation

        Returns:
            True if the append blob was created successfully

        Raises:
            RuntimeError: If blob service client is not initialized
            Exception: If append blob creation fails

        """
        with self.logger.create_span(
            "AzureStorage.create_append_blob",
            attributes={
                "service.name": self.service_name,
                "operation.type": "append_blob_create",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Creating append blob in Azure Storage",
                    extra={
                        "container_name": container_name,
                        "blob_name": blob_name,
                        "has_metadata": metadata is not None,
                        "content_type": content_type,
                    },
                )

                container_client = self.blob_service_client.get_container_client(container=container_name)
                append_blob_client = container_client.get_blob_client(blob=blob_name)

                content_settings = None
                if content_type:
                    content_settings = ContentSettings(content_type=content_type)

                append_blob_client.create_append_blob(
                    content_settings=content_settings,
                    metadata=metadata,
                    **kwargs,
                )

                self.logger.info(
                    "Append blob created successfully",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )

                return True

            except (AzureError, ValueError, OSError, TypeError):
                self.logger.exception(
                    f"Failed to create append blob '{blob_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    def append_block(
        self,
        container_name: str,
        blob_name: str,
        data: bytes | str,
        **kwargs,
    ) -> int:
        """
        Append a block of data to an existing append blob.

        The append blob must already exist (use create_append_blob first).

        Args:
            container_name: Name of the container
            blob_name: Name of the append blob
            data: Data to append (bytes or string, max 4 MiB per block)
            **kwargs: Additional parameters for append block

        Returns:
            The byte offset at which the block was appended

        Raises:
            RuntimeError: If blob service client is not initialized
            Exception: If appending the block fails

        """
        with self.logger.create_span(
            "AzureStorage.append_block",
            attributes={
                "service.name": self.service_name,
                "operation.type": "append_blob_append",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                if isinstance(data, str):
                    data = data.encode("utf-8")

                self.logger.debug(
                    "Appending block to append blob",
                    extra={
                        "container_name": container_name,
                        "blob_name": blob_name,
                        "data_length": len(data),
                    },
                )

                container_client = self.blob_service_client.get_container_client(container=container_name)
                append_blob_client = container_client.get_blob_client(blob=blob_name)

                result = append_blob_client.append_block(data=data, length=len(data), **kwargs)

                blob_append_offset = result.get("blob_append_offset", 0)

                self.logger.info(
                    "Block appended successfully",
                    extra={
                        "container_name": container_name,
                        "blob_name": blob_name,
                        "data_length": len(data),
                        "append_offset": blob_append_offset,
                    },
                )

                return blob_append_offset

            except ResourceNotFoundError:
                self.logger.exception(
                    f"Append blob '{blob_name}' not found. Create it first with create_append_blob.",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise
            except (AzureError, ValueError, OSError, TypeError):
                self.logger.exception(
                    f"Failed to append block to blob '{blob_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    def append_blob_from_text(
        self,
        container_name: str,
        blob_name: str,
        text: str,
        create_if_not_exists: bool = True,
        content_type: str = "text/plain; charset=utf-8",
        metadata: dict[str, str] | None = None,
        **kwargs,
    ) -> bool:
        """
        Convenience method: append text to an append blob, optionally creating it first.

        Args:
            container_name: Name of the container
            blob_name: Name of the append blob
            text: Text to append
            create_if_not_exists: If True, create the append blob if it does not exist
            content_type: Content type for the blob (used only on creation)
            metadata: Optional metadata (used only on creation)
            **kwargs: Additional parameters passed to append_block

        Returns:
            True if the text was appended successfully

        Raises:
            RuntimeError: If blob service client is not initialized
            Exception: If appending fails

        """
        with self.logger.create_span(
            "AzureStorage.append_blob_from_text",
            attributes={
                "service.name": self.service_name,
                "operation.type": "append_blob_text",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if create_if_not_exists:
                properties = self.get_blob_properties(
                    container_name=container_name,
                    blob_name=blob_name,
                )
                if properties is None:
                    self.create_append_blob(
                        container_name=container_name,
                        blob_name=blob_name,
                        content_type=content_type,
                        metadata=metadata,
                    )

            self.append_block(
                container_name=container_name,
                blob_name=blob_name,
                data=text,
                **kwargs,
            )

            return True

    def upload_blob_with_sas(
        self,
        container_name: str,
        blob_name: str,
        data: bytes | str | BinaryIO,
        overwrite: bool = True,
        metadata: dict[str, str] | None = None,
        content_type: str | None = None,
        sas_permission: str = "r",
        sas_expiry_delta: timedelta = timedelta(hours=3),
        **kwargs,
    ) -> str:
        """
        Upload a blob and return its SAS URL.

        Args:
            container_name: Name of the container
            blob_name: Name of the blob
            data: Data to upload (bytes, string, or file-like object)
            overwrite: Whether to overwrite existing blob
            metadata: Optional metadata for the blob
            content_type: Optional content type for the blob
            sas_permission: SAS permissions for the generated URL
            sas_expiry_delta: Timedelta for SAS URL validity
            **kwargs: Additional parameters for blob upload

        Returns:
            Full blob URL with SAS token

        Raises:
            RuntimeError: If blob service client is not initialized
            Exception: If blob upload or SAS generation fails

        """
        with self.logger.create_span(
            "AzureStorage.upload_blob_with_sas",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_upload_with_sas",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Uploading blob with SAS URL generation",
                    extra={
                        "container_name": container_name,
                        "blob_name": blob_name,
                        "overwrite": overwrite,
                        "has_metadata": metadata is not None,
                        "content_type": content_type,
                        "sas_permission": sas_permission,
                    },
                )

                blob_client = self.blob_service_client.get_blob_client(container=container_name, blob=blob_name)

                if isinstance(data, str):
                    data = data.encode("utf-8")

                if "content_settings" not in kwargs:
                    kwargs["content_settings"] = self._detect_content_settings(
                        file_name=blob_name, data=data, content_type=content_type
                    )

                # Upload the blob
                blob_client.upload_blob(data, overwrite=overwrite, metadata=metadata, **kwargs)

                # Generate SAS URL
                sas_token = self.get_blob_sas(
                    container_name=container_name,
                    blob_name=blob_name,
                    permission=sas_permission,
                    expiry_delta=sas_expiry_delta,
                )
                encoded_blob_name = quote(blob_name, safe="/")
                sas_url = f"{self.account_url}{container_name}/{encoded_blob_name}?{sas_token}"

                self.logger.info(
                    "Blob uploaded with SAS URL generated successfully",
                    extra={
                        "container_name": container_name,
                        "blob_name": blob_name,
                        "overwrite": overwrite,
                        "sas_permission": sas_permission,
                    },
                )

                return sas_url

            except AzureError:
                self.logger.exception(
                    f"Failed to upload blob '{blob_name}' with SAS",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    def upsert_blob_metadata(self, container_name: str, blob_name: str, metadata: dict[str, str]):
        """
        Update or insert metadata for a specific blob.

        Args:
            container_name: The name of the container.
            blob_name: The name of the blob.
            metadata: A dictionary of metadata to upsert.

        Raises:
            RuntimeError: If blob service client is not initialized.
            Exception: If updating metadata fails.

        """
        with self.logger.create_span(
            "AzureStorage.upsert_blob_metadata",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_metadata_upsert",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.blob_service_client is None:
                error_msg = "Blob service client not initialized. Enable blob storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Upserting blob metadata",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )

                blob_client = self.blob_service_client.get_blob_client(container=container_name, blob=blob_name)

                # Fetch existing metadata to avoid overwriting
                blob_properties = blob_client.get_blob_properties()
                existing_metadata = blob_properties.metadata or {}

                # Update with new metadata
                existing_metadata.update(metadata)

                blob_client.set_blob_metadata(metadata=existing_metadata)
                self.logger.info(f"Successfully upserted metadata for blob '{blob_name}'.")

            except AzureError:
                self.logger.exception(
                    f"Failed to upsert metadata for blob '{blob_name}'",
                    extra={"container_name": container_name, "blob_name": blob_name},
                )
                raise

    # Queue Operations
    def send_message(
        self,
        queue_name: str,
        content: str,
        visibility_timeout: int | None = None,
        time_to_live: int | None = None,
        **kwargs,
    ) -> bool:
        """
        Send a message to an Azure Storage Queue.

        Args:
            queue_name: Name of the queue
            content: Message content
            visibility_timeout: Optional visibility timeout in seconds
            time_to_live: Optional time to live in seconds
            **kwargs: Additional parameters for message sending

        Returns:
            True if message was sent successfully

        Raises:
            RuntimeError: If queue service client is not initialized
            Exception: If message sending fails

        """
        with self.logger.create_span(
            "AzureStorage.send_message",
            attributes={
                "service.name": self.service_name,
                "operation.type": "queue_send_message",
                "storage.queue_name": queue_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.queue_service_client is None:
                error_msg = "Queue service client not initialized. Enable queue storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Sending message to Azure Storage Queue",
                    extra={
                        "queue_name": queue_name,
                        "message_length": len(content),
                        "visibility_timeout": visibility_timeout,
                        "time_to_live": time_to_live,
                    },
                )

                queue_client = self.queue_service_client.get_queue_client(queue_name)

                queue_client.send_message(
                    content=content, visibility_timeout=visibility_timeout, time_to_live=time_to_live, **kwargs
                )

                self.logger.info("Message sent successfully", extra={"queue_name": queue_name})

                return True

            except AzureError:
                self.logger.exception(
                    f"Failed to send message to queue '{queue_name}'",
                    extra={"queue_name": queue_name},
                )
                raise

    def receive_messages(
        self, queue_name: str, messages_per_page: int = 1, visibility_timeout: int | None = None, **kwargs
    ) -> list[dict[str, Any]]:
        """
        Receive messages from an Azure Storage Queue.

        Args:
            queue_name: Name of the queue
            messages_per_page: Number of messages to receive per page
            visibility_timeout: Optional visibility timeout in seconds
            **kwargs: Additional parameters for message receiving

        Returns:
            List of message dictionaries containing message data

        Raises:
            RuntimeError: If queue service client is not initialized
            Exception: If message receiving fails

        """
        with self.logger.create_span(
            "AzureStorage.receive_messages",
            attributes={
                "service.name": self.service_name,
                "operation.type": "queue_receive_messages",
                "storage.queue_name": queue_name,
                "storage.account_url": self.account_url,
            },
        ):
            if self.queue_service_client is None:
                error_msg = "Queue service client not initialized. Enable queue storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Receiving messages from Azure Storage Queue",
                    extra={
                        "queue_name": queue_name,
                        "messages_per_page": messages_per_page,
                        "visibility_timeout": visibility_timeout,
                    },
                )

                queue_client = self.queue_service_client.get_queue_client(queue_name)

                messages = []
                for message in queue_client.receive_messages(
                    messages_per_page=messages_per_page, visibility_timeout=visibility_timeout, **kwargs
                ):
                    messages.append(
                        {
                            "id": message.id,
                            "content": message.content,
                            "dequeue_count": message.dequeue_count,
                            "insertion_time": message.insertion_time,
                            "expiration_time": message.expiration_time,
                            "pop_receipt": message.pop_receipt,
                        }
                    )

                self.logger.info(
                    "Messages received successfully", extra={"queue_name": queue_name, "message_count": len(messages)}
                )

                return messages

            except AzureError:
                self.logger.exception(
                    f"Failed to receive messages from queue '{queue_name}'",
                    extra={"queue_name": queue_name},
                )
                raise

    def delete_message(self, queue_name: str, message_id: str, pop_receipt: str, **kwargs) -> bool:
        """
        Delete a message from an Azure Storage Queue.

        Args:
            queue_name: Name of the queue
            message_id: ID of the message to delete
            pop_receipt: Pop receipt of the message
            **kwargs: Additional parameters for message deletion

        Returns:
            True if message was deleted successfully

        Raises:
            RuntimeError: If queue service client is not initialized
            Exception: If message deletion fails

        """
        with self.logger.create_span(
            "AzureStorage.delete_message",
            attributes={
                "service.name": self.service_name,
                "operation.type": "queue_delete_message",
                "storage.queue_name": queue_name,
                "storage.message_id": message_id,
                "storage.account_url": self.account_url,
            },
        ):
            if self.queue_service_client is None:
                error_msg = "Queue service client not initialized. Enable queue storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Deleting message from Azure Storage Queue",
                    extra={"queue_name": queue_name, "message_id": message_id},
                )

                queue_client = self.queue_service_client.get_queue_client(queue_name)

                queue_client.delete_message(message=message_id, pop_receipt=pop_receipt, **kwargs)

                self.logger.info(
                    "Message deleted successfully", extra={"queue_name": queue_name, "message_id": message_id}
                )

                return True

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Message '{message_id}' not found in queue '{queue_name}'",
                    extra={"queue_name": queue_name, "message_id": message_id},
                )
                return False
            except AzureError:
                self.logger.exception(
                    f"Failed to delete message '{message_id}' from queue '{queue_name}'",
                    extra={"queue_name": queue_name, "message_id": message_id},
                )
                raise

    # File Share Operations
    def upload_share_file(
        self,
        share_name: str,
        file_path: str,
        data: bytes | str | BinaryIO,
        metadata: dict[str, str] | None = None,
        content_type: str | None = None,
        **kwargs,
    ) -> bool:
        """
        Upload a file to an Azure File Share.

        Creates parent directories automatically if they don't exist.

        Args:
            share_name: Name of the file share
            file_path: Full path within the share (e.g., "dir1/dir2/file.txt")
            data: Data to upload (bytes, string, or file-like object)
            metadata: Optional metadata for the file
            content_type: Optional content type for the file
            **kwargs: Additional parameters for file upload

        Returns:
            True if file was uploaded successfully

        Raises:
            RuntimeError: If file service client is not initialized
            Exception: If file upload fails

        """
        with self.logger.create_span(
            "AzureStorage.upload_share_file",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_file_upload",
                "storage.share_name": share_name,
                "storage.file_path": file_path,
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Uploading file to Azure File Share",
                    extra={
                        "share_name": share_name,
                        "file_path": file_path,
                        "has_metadata": metadata is not None,
                        "content_type": content_type,
                    },
                )

                share_client = self.file_service_client.get_share_client(share_name)

                # Create parent directories if the path contains directories
                dir_path = "/".join(file_path.split("/")[:-1])
                if dir_path:
                    self._ensure_share_directories(share_client=share_client, directory_path=dir_path)

                file_client = share_client.get_file_client(file_path)

                if isinstance(data, str):
                    data = data.encode("utf-8")

                content_settings = self._detect_content_settings(
                    file_name=file_path, data=data, content_type=content_type
                )
                if content_settings:
                    kwargs["content_settings"] = content_settings

                file_client.upload_file(data=data, metadata=metadata, **kwargs)

                self.logger.info(
                    "File uploaded to share successfully",
                    extra={"share_name": share_name, "file_path": file_path},
                )

                return True

            except (AzureError, ValueError, OSError, TypeError):
                self.logger.exception(
                    f"Failed to upload file '{file_path}' to share '{share_name}'",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                raise

    def download_share_file(self, share_name: str, file_path: str, **kwargs) -> bytes | None:
        """
        Download a file from an Azure File Share.

        Args:
            share_name: Name of the file share
            file_path: Full path within the share
            **kwargs: Additional parameters for file download

        Returns:
            File data as bytes if found, None if not found

        Raises:
            RuntimeError: If file service client is not initialized
            Exception: If file download fails for reasons other than not found

        """
        with self.logger.create_span(
            "AzureStorage.download_share_file",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_file_download",
                "storage.share_name": share_name,
                "storage.file_path": file_path,
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Downloading file from Azure File Share",
                    extra={"share_name": share_name, "file_path": file_path},
                )

                share_client = self.file_service_client.get_share_client(share_name)
                file_client = share_client.get_file_client(file_path)

                stream = file_client.download_file(**kwargs)
                content = stream.readall()

                self.logger.info(
                    "File downloaded from share successfully",
                    extra={
                        "share_name": share_name,
                        "file_path": file_path,
                        "content_length": len(content) if content else 0,
                    },
                )

                return content

            except ResourceNotFoundError:
                self.logger.warning(
                    f"File '{file_path}' not found in share '{share_name}'",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to download file '{file_path}' from share '{share_name}'",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                raise

    def delete_share_file(self, share_name: str, file_path: str, **kwargs) -> bool:
        """
        Delete a file from an Azure File Share.

        Args:
            share_name: Name of the file share
            file_path: Full path within the share
            **kwargs: Additional parameters for file deletion

        Returns:
            True if deleted, False if not found

        Raises:
            RuntimeError: If file service client is not initialized
            Exception: If file deletion fails

        """
        with self.logger.create_span(
            "AzureStorage.delete_share_file",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_file_deletion",
                "storage.share_name": share_name,
                "storage.file_path": file_path,
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Deleting file from Azure File Share",
                    extra={"share_name": share_name, "file_path": file_path},
                )

                share_client = self.file_service_client.get_share_client(share_name)
                file_client = share_client.get_file_client(file_path)
                file_client.delete_file(**kwargs)

                self.logger.info(
                    "File deleted from share successfully",
                    extra={"share_name": share_name, "file_path": file_path},
                )

                return True

            except ResourceNotFoundError:
                self.logger.warning(
                    f"File '{file_path}' not found in share '{share_name}' for deletion",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                return False
            except AzureError:
                self.logger.exception(
                    f"Failed to delete file '{file_path}' from share '{share_name}'",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                raise

    def share_file_exists(self, share_name: str, file_path: str) -> bool:
        """
        Check if a file exists in an Azure File Share.

        Args:
            share_name: Name of the file share
            file_path: Full path within the share

        Returns:
            True if the file exists, False otherwise

        Raises:
            RuntimeError: If file service client is not initialized

        """
        with self.logger.create_span(
            "AzureStorage.share_file_exists",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_file_exists",
                "storage.share_name": share_name,
                "storage.file_path": file_path,
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                share_client = self.file_service_client.get_share_client(share_name)
                file_client = share_client.get_file_client(file_path)
                file_client.get_file_properties()
                self.logger.debug(f"File '{file_path}' exists in share '{share_name}'")
                return True
            except ResourceNotFoundError:
                self.logger.debug(f"File '{file_path}' does not exist in share '{share_name}'")
                return False
            except AzureError:
                self.logger.exception(
                    f"Failed to check existence for file '{file_path}' in share '{share_name}'",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                raise

    def get_share_file_properties(self, share_name: str, file_path: str) -> Any | None:
        """
        Get properties of a file in an Azure File Share.

        Args:
            share_name: Name of the file share
            file_path: Full path within the share

        Returns:
            FileProperties if found, None if not found

        Raises:
            RuntimeError: If file service client is not initialized

        """
        with self.logger.create_span(
            "AzureStorage.get_share_file_properties",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_file_properties",
                "storage.share_name": share_name,
                "storage.file_path": file_path,
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Getting file properties from share",
                    extra={"share_name": share_name, "file_path": file_path},
                )

                share_client = self.file_service_client.get_share_client(share_name)
                file_client = share_client.get_file_client(file_path)
                properties = file_client.get_file_properties()

                self.logger.info(
                    "File properties retrieved from share successfully",
                    extra={"share_name": share_name, "file_path": file_path},
                )

                return properties

            except ResourceNotFoundError:
                self.logger.warning(
                    f"File '{file_path}' not found in share '{share_name}'",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to get properties for file '{file_path}' in share '{share_name}'",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                raise

    def list_share_files(
        self,
        share_name: str,
        directory_path: str | None = None,
        name_starts_with: str | None = None,
        **kwargs,
    ) -> list[dict[str, Any]]:
        """
        List files and directories in an Azure File Share.

        Args:
            share_name: Name of the file share
            directory_path: Optional directory path to list (None for share root)
            name_starts_with: Optional prefix to filter names
            **kwargs: Additional parameters for listing

        Returns:
            List of dicts with keys: name, is_directory, size (files only)

        Raises:
            RuntimeError: If file service client is not initialized
            Exception: If listing fails

        """
        with self.logger.create_span(
            "AzureStorage.list_share_files",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_file_listing",
                "storage.share_name": share_name,
                "storage.directory_path": directory_path or "",
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Listing files in Azure File Share",
                    extra={
                        "share_name": share_name,
                        "directory_path": directory_path,
                        "name_starts_with": name_starts_with,
                    },
                )

                share_client = self.file_service_client.get_share_client(share_name)

                items = []
                for item in share_client.list_directories_and_files(
                    directory_name=directory_path, name_starts_with=name_starts_with, **kwargs
                ):
                    entry: dict[str, Any] = {
                        "name": item["name"],
                        "is_directory": item.get("is_directory", False),
                    }
                    if not entry["is_directory"]:
                        entry["size"] = item.get("size", 0)
                    items.append(entry)

                self.logger.info(
                    "Files listed from share successfully",
                    extra={
                        "share_name": share_name,
                        "directory_path": directory_path,
                        "item_count": len(items),
                    },
                )

                return items

            except AzureError:
                self.logger.exception(
                    f"Failed to list files in share '{share_name}'",
                    extra={"share_name": share_name, "directory_path": directory_path},
                )
                raise

    def create_share_directory(self, share_name: str, directory_path: str, **kwargs) -> bool:
        """
        Create a directory in an Azure File Share.

        Creates parent directories automatically if they don't exist.

        Args:
            share_name: Name of the file share
            directory_path: Directory path to create (e.g., "dir1/dir2/dir3")
            **kwargs: Additional parameters for directory creation

        Returns:
            True if directory was created successfully

        Raises:
            RuntimeError: If file service client is not initialized
            Exception: If directory creation fails

        """
        with self.logger.create_span(
            "AzureStorage.create_share_directory",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_directory_create",
                "storage.share_name": share_name,
                "storage.directory_path": directory_path,
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Creating directory in Azure File Share",
                    extra={"share_name": share_name, "directory_path": directory_path},
                )

                share_client = self.file_service_client.get_share_client(share_name)
                self._ensure_share_directories(share_client=share_client, directory_path=directory_path)

                self.logger.info(
                    "Directory created in share successfully",
                    extra={"share_name": share_name, "directory_path": directory_path},
                )

                return True

            except AzureError:
                self.logger.exception(
                    f"Failed to create directory '{directory_path}' in share '{share_name}'",
                    extra={"share_name": share_name, "directory_path": directory_path},
                )
                raise

    def delete_share_directory(self, share_name: str, directory_path: str, **kwargs) -> bool:
        """
        Delete a directory from an Azure File Share. Directory must be empty.

        Args:
            share_name: Name of the file share
            directory_path: Directory path to delete
            **kwargs: Additional parameters for directory deletion

        Returns:
            True if deleted, False if not found

        Raises:
            RuntimeError: If file service client is not initialized
            Exception: If directory deletion fails

        """
        with self.logger.create_span(
            "AzureStorage.delete_share_directory",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_directory_deletion",
                "storage.share_name": share_name,
                "storage.directory_path": directory_path,
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                self.logger.debug(
                    "Deleting directory from Azure File Share",
                    extra={"share_name": share_name, "directory_path": directory_path},
                )

                share_client = self.file_service_client.get_share_client(share_name)
                dir_client = share_client.get_directory_client(directory_path)
                dir_client.delete_directory(**kwargs)

                self.logger.info(
                    "Directory deleted from share successfully",
                    extra={"share_name": share_name, "directory_path": directory_path},
                )

                return True

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Directory '{directory_path}' not found in share '{share_name}'",
                    extra={"share_name": share_name, "directory_path": directory_path},
                )
                return False
            except AzureError:
                self.logger.exception(
                    f"Failed to delete directory '{directory_path}' from share '{share_name}'",
                    extra={"share_name": share_name, "directory_path": directory_path},
                )
                raise

    def upsert_share_file_metadata(self, share_name: str, file_path: str, metadata: dict[str, str]) -> None:
        """
        Merge metadata into a file in an Azure File Share.

        Reads existing metadata first, then merges the new values before writing,
        because the SDK's set_file_metadata replaces all metadata on each call.

        Args:
            share_name: Name of the file share
            file_path: Full path within the share
            metadata: Dictionary of metadata to merge

        Raises:
            RuntimeError: If file service client is not initialized
            Exception: If updating metadata fails

        """
        with self.logger.create_span(
            "AzureStorage.upsert_share_file_metadata",
            attributes={
                "service.name": self.service_name,
                "operation.type": "share_file_metadata_upsert",
                "storage.share_name": share_name,
                "storage.file_path": file_path,
                "storage.account_url": self.account_url,
            },
        ):
            if self.file_service_client is None:
                error_msg = "File service client not initialized. Enable file storage during initialization."
                self.logger.error(error_msg)
                raise RuntimeError(error_msg)

            try:
                share_client = self.file_service_client.get_share_client(share_name)
                file_client = share_client.get_file_client(file_path)

                existing_props = file_client.get_file_properties()
                existing_metadata = existing_props.metadata or {}
                existing_metadata.update(metadata)

                file_client.set_file_metadata(metadata=existing_metadata)
                self.logger.info(f"Successfully upserted metadata for share file '{file_path}'.")

            except AzureError:
                self.logger.exception(
                    f"Failed to upsert metadata for file '{file_path}' in share '{share_name}'",
                    extra={"share_name": share_name, "file_path": file_path},
                )
                raise

    def _ensure_share_directories(self, share_client: Any, directory_path: str) -> None:
        """Create all directories in a path, skipping those that already exist."""
        stripped = directory_path.strip("/")
        if not stripped:
            return

        current_path = ""
        for part in stripped.split("/"):
            current_path = f"{current_path}/{part}" if current_path else part
            dir_client = share_client.get_directory_client(current_path)
            try:
                dir_client.create_directory()
                self.logger.debug(f"Created share directory: {current_path}")
            except ResourceExistsError:
                self.logger.debug(f"Share directory already exists: {current_path}")
            except ResourceNotFoundError:
                self.logger.warning(f"Parent share not found when creating directory: {current_path}")
                raise

    def test_connection(self) -> bool:
        """
        Test connection to Azure Storage by attempting to list containers.

        Returns:
            True if connection is successful, False otherwise

        """
        with self.logger.create_span(
            "AzureStorage.test_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_test",
                "storage.account_url": self.account_url,
            },
        ):
            try:
                self.logger.debug("Testing Azure Storage connection", extra={"account_url": self.account_url})

                if self.blob_service_client is not None:
                    # Try to list containers (limited to 1) to test connection
                    list(self.blob_service_client.list_containers(results_per_page=1))
                elif self.file_service_client is not None:
                    # Try to list shares if blob storage is disabled
                    list(self.file_service_client.list_shares(results_per_page=1))
                elif self.queue_service_client is not None:
                    # Try to list queues if blob and file storage are disabled
                    list(self.queue_service_client.list_queues(results_per_page=1))
                else:
                    self.logger.error("No clients available for connection testing")
                    return False

                self.logger.info("Azure Storage connection test successful")
                return True

            except AzureError as e:
                self.logger.warning(
                    f"Azure Storage connection test failed: {e}", extra={"account_url": self.account_url}
                )
                return False

    def set_correlation_id(self, correlation_id: str):
        """
        Set correlation ID for request/transaction tracking.

        Args:
            correlation_id: Unique identifier for transaction correlation

        """
        self.logger.set_correlation_id(correlation_id)

    def get_correlation_id(self) -> str | None:
        """
        Get current correlation ID.

        Returns:
            Current correlation ID if set, otherwise None

        """
        return self.logger.get_correlation_id()

    # SAS Generation
    def get_container_sas(
        self,
        container_name: str,
        permission: str = "r",
        expiry_delta: timedelta = timedelta(hours=1),
    ) -> str:
        """
        Generate a SAS token for a container.

        Args:
            container_name: Name of the container.
            permission: SAS permissions (e.g., 'r' for read, 'w' for write).
            expiry_delta: Timedelta for how long the SAS is valid.

        Returns:
            The SAS token string.

        Raises:
            ValueError: If no valid credential (user delegation key or account key) is available.

        """
        with self.logger.create_span(
            "AzureStorage.get_container_sas",
            attributes={
                "service.name": self.service_name,
                "operation.type": "container_sas_generation",
                "storage.container_name": container_name,
                "storage.account_url": self.account_url,
            },
        ):
            self._ensure_valid_delegation_key()
            expiry_time = datetime.datetime.now(datetime.UTC) + expiry_delta
            if self.user_delegation_key:
                self.logger.debug("Generating container SAS with user delegation key.")
                return generate_container_sas(
                    account_name=self.account_name,
                    container_name=container_name,
                    user_delegation_key=self.user_delegation_key,
                    permission=permission,
                    expiry=expiry_time,
                )
            if self.account_key:
                self.logger.debug("Generating container SAS with account key.")
                return generate_container_sas(
                    account_name=self.account_name,
                    container_name=container_name,
                    account_key=self.account_key,
                    permission=permission,
                    expiry=expiry_time,
                )
            msg = "Cannot generate SAS token. No user delegation key or account key is configured."
            raise ValueError(msg)

    def get_blob_sas(
        self,
        container_name: str,
        blob_name: str,
        permission: str = "r",
        expiry_delta: timedelta = timedelta(hours=1),
    ) -> str:
        """
        Generate a SAS token for a blob.

        Args:
            container_name: Name of the container.
            blob_name: Name of the blob.
            permission: SAS permissions.
            expiry_delta: Timedelta for how long the SAS is valid.

        Returns:
            The SAS token string (same format as get_container_sas).

        Raises:
            ValueError: If no valid credential (user delegation key or account key) is available.

        """
        with self.logger.create_span(
            "AzureStorage.get_blob_sas",
            attributes={
                "service.name": self.service_name,
                "operation.type": "blob_sas_generation",
                "storage.container_name": container_name,
                "storage.blob_name": blob_name,
                "storage.account_url": self.account_url,
            },
        ):
            self._ensure_valid_delegation_key()
            expiry_time = datetime.datetime.now(datetime.UTC) + expiry_delta
            if self.user_delegation_key:
                self.logger.debug("Generating blob SAS with user delegation key.")
                return generate_blob_sas(
                    account_name=self.account_name,
                    container_name=container_name,
                    blob_name=blob_name,
                    user_delegation_key=self.user_delegation_key,
                    permission=permission,
                    expiry=expiry_time,
                )
            if self.account_key:
                self.logger.debug("Generating blob SAS with account key.")
                return generate_blob_sas(
                    account_name=self.account_name,
                    container_name=container_name,
                    blob_name=blob_name,
                    account_key=self.account_key,
                    permission=permission,
                    expiry=expiry_time,
                )
            msg = "Cannot generate SAS token. No user delegation key or account key is configured."
            raise ValueError(msg)

    def get_container_sas_with_prefix(
        self, container_name: str, permission: str = "r", expiry_delta: timedelta = timedelta(days=365 * 5)
    ) -> str:
        """Wrapper around get_container_sas that prepends '?' to the token."""
        sas_token = self.get_container_sas(
            container_name=container_name, permission=permission, expiry_delta=expiry_delta
        )
        return f"?{sas_token}"


def create_azure_storage(
    account_url: str,
    credential: TokenCredential | None = None,
    azure_identity: AzureIdentity | None = None,
    account_key: str | None = None,
    service_name: str = "azure_storage",
    service_version: str = "1.0.0",
    logger: AzureLogger | None = None,
    connection_string: str | None = None,
    enable_blob_storage: bool = True,
    enable_file_storage: bool = False,
    enable_queue_storage: bool = True,
) -> AzureStorage:
    """
    Factory function to create a cached AzureStorage instance.

    Returns existing instance if one with same configuration and credential
    exists. Creates a default AzureIdentity if neither credential nor
    azure_identity is provided.

    """
    if credential is None and azure_identity is None:
        from ..mgmt.identity import create_azure_identity

        azure_identity = create_azure_identity(
            service_name=f"{service_name}_identity",
            service_version=service_version,
            connection_string=connection_string,
        )

    cache_key = (
        account_url,
        account_key,
        service_name,
        service_version,
        connection_string,
        enable_blob_storage,
        enable_file_storage,
        enable_queue_storage,
        id(credential) if credential is not None else None,
        id(azure_identity) if azure_identity is not None else None,
    )

    if cache_key in _storage_instances:
        return _storage_instances[cache_key]

    # Create new instance and cache it
    storage_instance = AzureStorage(
        account_url=account_url,
        credential=credential,
        azure_identity=azure_identity,
        account_key=account_key,
        service_name=service_name,
        service_version=service_version,
        logger=logger,
        connection_string=connection_string,
        enable_blob_storage=enable_blob_storage,
        enable_file_storage=enable_file_storage,
        enable_queue_storage=enable_queue_storage,
    )

    _storage_instances[cache_key] = storage_instance
    return storage_instance
