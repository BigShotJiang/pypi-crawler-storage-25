from typing import Any

import openai
from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import (
    AgentDetails,
    AgentVersionDetails,
    Connection,
    ConnectionType,
    Deployment,
    DeploymentType,
    PromptAgentDefinition,
)
from azure.core.credentials import TokenCredential
from azure.core.exceptions import AzureError, ClientAuthenticationError, ResourceNotFoundError

from .._cache import RingCache
from ..mgmt.identity import AzureIdentity
from ..mgmt.logging import AzureLogger
from ._utils import setup_credential, setup_logger

# AI Project instance caching (bounded ring buffer, max 10)
_ai_project_instances: RingCache = RingCache(maxsize=10)


class AzureAIProject:
    """
    Azure AI Foundry Project management with agents, deployments, connections,
    and OpenAI client integration.

    Provides standardized Azure AI Project operations using the Azure AI Projects SDK
    with integrated logging, error handling, and OpenTelemetry tracing support.

    Attributes:
        endpoint: Azure AI Foundry project endpoint URL
        service_name: Service identifier for logging and tracing
        service_version: Service version for context
        logger: AzureLogger instance for structured logging
        credential: Azure credential for authentication
        client: AIProjectClient instance

    """

    def __init__(
        self,
        endpoint: str,
        credential: TokenCredential | None = None,
        azure_identity: AzureIdentity | None = None,
        service_name: str = "azure_ai_project",
        service_version: str = "1.0.0",
        logger: AzureLogger | None = None,
        connection_string: str | None = None,
        enable_agents: bool = True,
        enable_deployments: bool = True,
        enable_connections: bool = True,
    ):
        """
        Initialize Azure AI Foundry Project client.

        Args:
            endpoint: AI Foundry project endpoint URL
                (e.g., https://<ai-services>.services.ai.azure.com/api/projects/<project>)
            credential: Azure credential for authentication
            azure_identity: AzureIdentity instance for credential management
            service_name: Service name for tracing context
            service_version: Service version for metadata
            logger: Optional AzureLogger instance
            connection_string: Application Insights connection string
            enable_agents: Enable agent operations
            enable_deployments: Enable deployment operations
            enable_connections: Enable connection operations

        Raises:
            ValueError: If neither credential nor azure_identity is provided
            AzureError: If client initialization fails

        """
        self.endpoint = endpoint
        self.service_name = service_name
        self.service_version = service_version
        self.enable_agents = enable_agents
        self.enable_deployments = enable_deployments
        self.enable_connections = enable_connections

        self.logger = setup_logger(
            logger=logger,
            service_name=service_name,
            service_version=service_version,
            connection_string=connection_string,
        )

        self.credential, _ = setup_credential(
            credential=credential,
            azure_identity=azure_identity,
        )

        self.client: AIProjectClient | None = None
        self._setup_client()

        self.logger.info(
            f"Azure AI Project initialized for service '{service_name}' v{service_version}",
            extra={
                "endpoint": endpoint,
                "agents_enabled": enable_agents,
                "deployments_enabled": enable_deployments,
                "connections_enabled": enable_connections,
            },
        )

    def _setup_client(self) -> None:
        """Initialize the AIProjectClient."""
        try:
            self.client = AIProjectClient(
                endpoint=self.endpoint,
                credential=self.credential,
            )
            self.logger.debug("AIProjectClient initialized successfully")
        except (AzureError, RuntimeError):
            self.logger.exception("Failed to initialize AIProjectClient")
            raise

    def _ensure_client(self) -> AIProjectClient:
        """Return the client or raise if not initialized."""
        if self.client is None:
            error_msg = "AIProjectClient not initialized."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)
        return self.client

    def _ensure_agents_enabled(self) -> None:
        """Raise if agent operations are disabled."""
        if not self.enable_agents:
            error_msg = "Agent operations not enabled. Enable agents during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)

    def _ensure_deployments_enabled(self) -> None:
        """Raise if deployment operations are disabled."""
        if not self.enable_deployments:
            error_msg = "Deployment operations not enabled. Enable deployments during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)

    def _ensure_connections_enabled(self) -> None:
        """Raise if connection operations are disabled."""
        if not self.enable_connections:
            error_msg = "Connection operations not enabled. Enable connections during initialization."
            self.logger.error(error_msg)
            raise RuntimeError(error_msg)

    # ── OpenAI Client ─────────────────────────────────────────────

    def get_openai_client(self, **kwargs: Any) -> openai.OpenAI:
        """
        Get an authenticated OpenAI client configured for this AI project.

        Returns:
            Configured OpenAI client with project endpoint and credentials

        Raises:
            RuntimeError: If client is not initialized
            AzureError: If OpenAI client creation fails

        """
        with self.logger.create_span(
            "AzureAIProject.get_openai_client",
            attributes={
                "service.name": self.service_name,
                "operation.type": "openai_client_creation",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            try:
                openai_client = client.get_openai_client(**kwargs)
                self.logger.info("OpenAI client created successfully")
                return openai_client
            except AzureError:
                self.logger.exception("Failed to create OpenAI client")
                raise

    # ── Agent Operations ──────────────────────────────────────────

    def create_agent(
        self,
        agent_name: str,
        definition: PromptAgentDefinition,
        description: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> AgentVersionDetails:
        """
        Create a new agent version in the AI project.

        Args:
            agent_name: Name for the agent
            definition: Agent definition (e.g., PromptAgentDefinition)
            description: Optional agent description
            metadata: Optional metadata dict

        Returns:
            AgentVersionDetails for the created agent

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If agent creation fails

        """
        with self.logger.create_span(
            "AzureAIProject.create_agent",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_creation",
                "ai_project.agent_name": agent_name,
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug(
                    "Creating agent",
                    extra={"agent_name": agent_name},
                )

                agent_version = client.agents.create_version(
                    agent_name=agent_name,
                    definition=definition,
                    description=description,
                    metadata=metadata,
                )

                self.logger.info(
                    "Agent created successfully",
                    extra={
                        "agent_name": agent_name,
                        "version": getattr(agent_version, "version", None),
                    },
                )
                return agent_version

            except AzureError:
                self.logger.exception(
                    f"Failed to create agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise

    def get_agent(self, agent_name: str) -> AgentDetails | None:
        """
        Get an agent by name.

        Args:
            agent_name: Name of the agent

        Returns:
            AgentDetails if found, None if not found

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If retrieval fails for reasons other than not found

        """
        with self.logger.create_span(
            "AzureAIProject.get_agent",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_retrieval",
                "ai_project.agent_name": agent_name,
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug(
                    "Retrieving agent",
                    extra={"agent_name": agent_name},
                )

                agent = client.agents.get(agent_name=agent_name)

                self.logger.info(
                    "Agent retrieved successfully",
                    extra={"agent_name": agent_name},
                )
                return agent

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Agent '{agent_name}' not found",
                    extra={"agent_name": agent_name},
                )
                return None
            except ClientAuthenticationError:
                self.logger.exception(
                    f"Authentication failed for agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise

    def list_agents(self, **kwargs: Any) -> list[AgentDetails]:
        """
        List all agents in the AI project.

        Args:
            **kwargs: Additional parameters (kind, limit, order, before)

        Returns:
            List of AgentDetails

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If listing fails

        """
        with self.logger.create_span(
            "AzureAIProject.list_agents",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_listing",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug("Listing agents")

                agents = list(client.agents.list(**kwargs))

                self.logger.info(
                    "Agents listed successfully",
                    extra={"agent_count": len(agents)},
                )
                return agents

            except AzureError:
                self.logger.exception("Failed to list agents")
                raise

    def delete_agent(self, agent_name: str) -> bool:
        """
        Delete an agent by name.

        Args:
            agent_name: Name of the agent to delete

        Returns:
            True if deleted, False if not found

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If deletion fails

        """
        with self.logger.create_span(
            "AzureAIProject.delete_agent",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_deletion",
                "ai_project.agent_name": agent_name,
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug(
                    "Deleting agent",
                    extra={"agent_name": agent_name},
                )

                client.agents.delete(agent_name=agent_name)

                self.logger.info(
                    "Agent deleted successfully",
                    extra={"agent_name": agent_name},
                )
                return True

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Agent '{agent_name}' not found for deletion",
                    extra={"agent_name": agent_name},
                )
                return False
            except AzureError:
                self.logger.exception(
                    f"Failed to delete agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise

    def invoke_agent(
        self,
        agent_name: str,
        user_message: str,
        model: str = "not-used",
    ) -> dict[str, Any]:
        """
        Invoke an agent with a user message via the OpenAI responses API.

        Args:
            agent_name: Name of the agent to invoke
            user_message: Message to send to the agent
            model: Model parameter (ignored when using agent_reference)

        Returns:
            Dict with response_id, status, and response text

        Raises:
            RuntimeError: If client or agents not enabled
            AzureError: If invocation fails

        """
        with self.logger.create_span(
            "AzureAIProject.invoke_agent",
            attributes={
                "service.name": self.service_name,
                "operation.type": "agent_invocation",
                "ai_project.agent_name": agent_name,
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_agents_enabled()

            try:
                self.logger.debug(
                    "Invoking agent",
                    extra={"agent_name": agent_name},
                )

                openai_client = client.get_openai_client()
                response = openai_client.responses.create(
                    model=model,
                    input=user_message,
                    extra_body={
                        "agent_reference": {
                            "name": agent_name,
                            "type": "agent_reference",
                        },
                    },
                )

                result: dict[str, Any] = {
                    "response_id": response.id,
                    "status": response.status,
                    "response": response.output_text,
                }

                self.logger.info(
                    "Agent invoked successfully",
                    extra={
                        "agent_name": agent_name,
                        "response_id": response.id,
                        "status": response.status,
                    },
                )
                return result

            except AzureError:
                self.logger.exception(
                    f"Failed to invoke agent '{agent_name}'",
                    extra={"agent_name": agent_name},
                )
                raise

    # ── Deployment Operations ─────────────────────────────────────

    def list_deployments(
        self,
        model_publisher: str | None = None,
        model_name: str | None = None,
        deployment_type: DeploymentType | None = None,
        **kwargs: Any,
    ) -> list[Deployment]:
        """
        List model deployments in the AI project.

        Args:
            model_publisher: Filter by model publisher
            model_name: Filter by model name
            deployment_type: Filter by deployment type
            **kwargs: Additional parameters

        Returns:
            List of Deployment objects

        Raises:
            RuntimeError: If client or deployments not enabled
            AzureError: If listing fails

        """
        with self.logger.create_span(
            "AzureAIProject.list_deployments",
            attributes={
                "service.name": self.service_name,
                "operation.type": "deployment_listing",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_deployments_enabled()

            try:
                self.logger.debug(
                    "Listing deployments",
                    extra={
                        "model_publisher": model_publisher,
                        "model_name": model_name,
                    },
                )

                deployments = list(
                    client.deployments.list(
                        model_publisher=model_publisher,
                        model_name=model_name,
                        deployment_type=deployment_type,
                        **kwargs,
                    )
                )

                self.logger.info(
                    "Deployments listed successfully",
                    extra={"deployment_count": len(deployments)},
                )
                return deployments

            except AzureError:
                self.logger.exception("Failed to list deployments")
                raise

    def get_deployment(self, name: str) -> Deployment | None:
        """
        Get a specific deployment by name.

        Args:
            name: Name of the deployment

        Returns:
            Deployment if found, None if not found

        Raises:
            RuntimeError: If client or deployments not enabled
            AzureError: If retrieval fails

        """
        with self.logger.create_span(
            "AzureAIProject.get_deployment",
            attributes={
                "service.name": self.service_name,
                "operation.type": "deployment_retrieval",
                "ai_project.deployment_name": name,
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_deployments_enabled()

            try:
                self.logger.debug(
                    "Retrieving deployment",
                    extra={"deployment_name": name},
                )

                deployment = client.deployments.get(name=name)

                self.logger.info(
                    "Deployment retrieved successfully",
                    extra={"deployment_name": name},
                )
                return deployment

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Deployment '{name}' not found",
                    extra={"deployment_name": name},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve deployment '{name}'",
                    extra={"deployment_name": name},
                )
                raise

    # ── Connection Operations ─────────────────────────────────────

    def list_connections(
        self,
        connection_type: ConnectionType | None = None,
        default_connection: bool | None = None,
        **kwargs: Any,
    ) -> list[Connection]:
        """
        List connections in the AI project.

        Args:
            connection_type: Filter by connection type
            default_connection: Filter by default connection status
            **kwargs: Additional parameters

        Returns:
            List of Connection objects

        Raises:
            RuntimeError: If client or connections not enabled
            AzureError: If listing fails

        """
        with self.logger.create_span(
            "AzureAIProject.list_connections",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_listing",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_connections_enabled()

            try:
                self.logger.debug("Listing connections")

                connections = list(
                    client.connections.list(
                        connection_type=connection_type,
                        default_connection=default_connection,
                        **kwargs,
                    )
                )

                self.logger.info(
                    "Connections listed successfully",
                    extra={"connection_count": len(connections)},
                )
                return connections

            except AzureError:
                self.logger.exception("Failed to list connections")
                raise

    def get_connection(
        self,
        name: str,
        include_credentials: bool = False,
    ) -> Connection | None:
        """
        Get a specific connection by name.

        Args:
            name: Name of the connection
            include_credentials: Whether to include credentials in the response

        Returns:
            Connection if found, None if not found

        Raises:
            RuntimeError: If client or connections not enabled
            AzureError: If retrieval fails

        """
        with self.logger.create_span(
            "AzureAIProject.get_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_retrieval",
                "ai_project.connection_name": name,
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_connections_enabled()

            try:
                self.logger.debug(
                    "Retrieving connection",
                    extra={"connection_name": name, "include_credentials": include_credentials},
                )

                connection = client.connections.get(
                    name=name,
                    include_credentials=include_credentials,
                )

                self.logger.info(
                    "Connection retrieved successfully",
                    extra={"connection_name": name},
                )
                return connection

            except ResourceNotFoundError:
                self.logger.warning(
                    f"Connection '{name}' not found",
                    extra={"connection_name": name},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve connection '{name}'",
                    extra={"connection_name": name},
                )
                raise

    def get_default_connection(
        self,
        connection_type: ConnectionType,
        include_credentials: bool = False,
    ) -> Connection | None:
        """
        Get the default connection for a given type.

        Args:
            connection_type: Type of connection to retrieve
            include_credentials: Whether to include credentials

        Returns:
            Connection if found, None if not found

        Raises:
            RuntimeError: If client or connections not enabled
            AzureError: If retrieval fails

        """
        with self.logger.create_span(
            "AzureAIProject.get_default_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "default_connection_retrieval",
                "ai_project.connection_type": str(connection_type),
                "ai_project.endpoint": self.endpoint,
            },
        ):
            client = self._ensure_client()
            self._ensure_connections_enabled()

            try:
                self.logger.debug(
                    "Retrieving default connection",
                    extra={"connection_type": str(connection_type)},
                )

                connection = client.connections.get_default(
                    connection_type=connection_type,
                    include_credentials=include_credentials,
                )

                self.logger.info(
                    "Default connection retrieved successfully",
                    extra={"connection_type": str(connection_type)},
                )
                return connection

            except ResourceNotFoundError:
                self.logger.warning(
                    f"No default connection found for type '{connection_type}'",
                    extra={"connection_type": str(connection_type)},
                )
                return None
            except AzureError:
                self.logger.exception(
                    f"Failed to retrieve default connection for type '{connection_type}'",
                    extra={"connection_type": str(connection_type)},
                )
                raise

    # ── Connection Test & Correlation ─────────────────────────────

    def test_connection(self) -> bool:
        """
        Test connection to the AI project by listing deployments.

        Returns:
            True if connection is successful, False otherwise

        """
        with self.logger.create_span(
            "AzureAIProject.test_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_test",
                "ai_project.endpoint": self.endpoint,
            },
        ):
            try:
                self.logger.debug("Testing AI Project connection", extra={"endpoint": self.endpoint})

                client = self._ensure_client()
                list(client.deployments.list())

                self.logger.info("AI Project connection test successful")
                return True

            except AzureError as e:
                self.logger.warning(
                    f"AI Project connection test failed: {e}",
                    extra={"endpoint": self.endpoint},
                )
                return False

    def set_correlation_id(self, correlation_id: str) -> None:
        """Set correlation ID for request/transaction tracking."""
        self.logger.set_correlation_id(correlation_id)

    def get_correlation_id(self) -> str | None:
        """Get current correlation ID."""
        return self.logger.get_correlation_id()


def create_azure_ai_project(
    endpoint: str,
    credential: TokenCredential | None = None,
    azure_identity: AzureIdentity | None = None,
    service_name: str = "azure_ai_project",
    service_version: str = "1.0.0",
    logger: AzureLogger | None = None,
    connection_string: str | None = None,
    enable_agents: bool = True,
    enable_deployments: bool = True,
    enable_connections: bool = True,
) -> AzureAIProject:
    """
    Factory function to create a cached AzureAIProject instance.

    Returns existing instance if one with same configuration exists.
    Creates a default AzureIdentity if neither credential nor
    azure_identity is provided.

    """
    if credential is None and azure_identity is None:
        from ..mgmt.identity import create_azure_identity

        azure_identity = create_azure_identity(
            service_name=f"{service_name}_identity",
            service_version=service_version,
            connection_string=connection_string,
        )

    cache_key = (
        endpoint,
        service_name,
        service_version,
        connection_string,
        enable_agents,
        enable_deployments,
        enable_connections,
        id(credential) if credential is not None else None,
        id(azure_identity) if azure_identity is not None else None,
    )

    if cache_key in _ai_project_instances:
        return _ai_project_instances[cache_key]

    ai_project_instance = AzureAIProject(
        endpoint=endpoint,
        credential=credential,
        azure_identity=azure_identity,
        service_name=service_name,
        service_version=service_version,
        logger=logger,
        connection_string=connection_string,
        enable_agents=enable_agents,
        enable_deployments=enable_deployments,
        enable_connections=enable_connections,
    )

    _ai_project_instances[cache_key] = ai_project_instance
    return ai_project_instance
