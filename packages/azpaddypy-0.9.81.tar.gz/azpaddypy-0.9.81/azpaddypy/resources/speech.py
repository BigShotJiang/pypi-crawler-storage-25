from typing import Any

import azure.cognitiveservices.speech as speechsdk
from azure.core.credentials import TokenCredential
from azure.core.exceptions import AzureError, ClientAuthenticationError

from .._cache import RingCache
from ..mgmt.identity import AzureIdentity
from ..mgmt.logging import AzureLogger
from ._utils import setup_credential, setup_logger

# Speech instance caching (bounded ring buffer, max 10)
_speech_instances: RingCache = RingCache(maxsize=10)

# Token scope for Cognitive Services
COGNITIVE_SERVICES_SCOPE = "https://cognitiveservices.azure.com/.default"


class AzureSpeech:
    """
    Azure Cognitive Services Speech Service management with Entra ID authentication.

    Provides standardized speech synthesis and recognition operations using the
    Azure Speech SDK with integrated logging, error handling, and OpenTelemetry
    tracing support.

    The Azure Speech SDK does not natively accept TokenCredential objects, so
    this wrapper handles the AAD token format ('aad#<resource_id>#<token>')
    required by SpeechConfig and provides token refresh helpers for long-lived
    synthesizers and recognizers.

    Attributes:
        region: Azure region (e.g., 'westeurope', 'eastus')
        resource_id: Full ARM resource ID of the Speech / AI Services resource
        service_name: Service identifier for logging and tracing
        service_version: Service version for context
        logger: AzureLogger instance for structured logging
        credential: Azure credential for authentication

    """

    def __init__(
        self,
        region: str,
        resource_id: str,
        credential: TokenCredential | None = None,
        azure_identity: AzureIdentity | None = None,
        service_name: str = "azure_speech",
        service_version: str = "1.0.0",
        logger: AzureLogger | None = None,
        connection_string: str | None = None,
        default_speech_recognition_language: str = "en-US",
        default_speech_synthesis_voice_name: str = "en-US-JennyNeural",
    ):
        """
        Initialize Azure Speech client.

        Args:
            region: Azure region (e.g., 'westeurope', 'eastus')
            resource_id: Full ARM resource ID of the Speech resource
                (/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.CognitiveServices/accounts/<name>)
            credential: Azure credential for authentication
            azure_identity: AzureIdentity instance for credential management
            service_name: Service name for tracing context
            service_version: Service version for metadata
            logger: Optional AzureLogger instance
            connection_string: Application Insights connection string
            default_speech_recognition_language: Default recognition language
            default_speech_synthesis_voice_name: Default synthesis voice

        Raises:
            ValueError: If neither credential nor azure_identity is provided
                or if region/resource_id are empty

        """
        if not region:
            msg = "'region' is required for Azure Speech (e.g., 'westeurope')"
            raise ValueError(msg)
        if not resource_id:
            msg = (
                "'resource_id' is required for Azure Speech "
                "(format: /subscriptions/<sub>/resourceGroups/<rg>/providers/"
                "Microsoft.CognitiveServices/accounts/<name>)"
            )
            raise ValueError(msg)

        self.region = region
        self.resource_id = resource_id
        self.service_name = service_name
        self.service_version = service_version
        self.default_speech_recognition_language = default_speech_recognition_language
        self.default_speech_synthesis_voice_name = default_speech_synthesis_voice_name

        self.logger = setup_logger(
            logger=logger,
            service_name=service_name,
            service_version=service_version,
            connection_string=connection_string,
        )

        self.credential, _ = setup_credential(
            credential=credential,
            azure_identity=azure_identity,
        )

        self.logger.info(
            f"Azure Speech initialized for service '{service_name}' v{service_version}",
            extra={
                "region": region,
                "resource_id": resource_id,
                "default_voice": default_speech_synthesis_voice_name,
                "default_language": default_speech_recognition_language,
            },
        )

    # ── Token Acquisition ─────────────────────────────────────────

    def get_authorization_token(self) -> str:
        """
        Acquire a fresh AAD token and format it for the Speech SDK.

        The Speech SDK requires the format 'aad#<resource_id>#<access_token>'.
        Tokens are typically valid for ~10 minutes.

        Returns:
            Formatted authorization token string

        Raises:
            ClientAuthenticationError: If token acquisition fails

        """
        with self.logger.create_span(
            "AzureSpeech.get_authorization_token",
            attributes={
                "service.name": self.service_name,
                "operation.type": "token_acquisition",
                "speech.region": self.region,
            },
        ):
            try:
                token = self.credential.get_token(COGNITIVE_SERVICES_SCOPE)
                self.logger.debug("Acquired Speech authorization token")
                return f"aad#{self.resource_id}#{token.token}"
            except ClientAuthenticationError:
                self.logger.exception("Failed to acquire Speech authorization token")
                raise

    # ── SpeechConfig Builders ─────────────────────────────────────

    def get_speech_config(
        self,
        speech_recognition_language: str | None = None,
        speech_synthesis_voice_name: str | None = None,
        speech_synthesis_output_format: speechsdk.SpeechSynthesisOutputFormat | None = None,
    ) -> speechsdk.SpeechConfig:
        """
        Build a fresh SpeechConfig with a current AAD authorization token.

        Tokens have a limited lifetime (~10 minutes). For long-lived
        synthesizers or recognizers, call refresh_authorization_token() on
        them periodically.

        Args:
            speech_recognition_language: Override default recognition language
            speech_synthesis_voice_name: Override default synthesis voice
            speech_synthesis_output_format: Override default output format

        Returns:
            Configured SpeechConfig instance

        Raises:
            ClientAuthenticationError: If token acquisition fails
            AzureError: If SpeechConfig creation fails

        """
        with self.logger.create_span(
            "AzureSpeech.get_speech_config",
            attributes={
                "service.name": self.service_name,
                "operation.type": "speech_config_creation",
                "speech.region": self.region,
            },
        ):
            try:
                auth_token = self.get_authorization_token()
                speech_config = speechsdk.SpeechConfig(auth_token=auth_token, region=self.region)

                speech_config.speech_recognition_language = (
                    speech_recognition_language or self.default_speech_recognition_language
                )
                speech_config.speech_synthesis_voice_name = (
                    speech_synthesis_voice_name or self.default_speech_synthesis_voice_name
                )

                if speech_synthesis_output_format is not None:
                    speech_config.set_speech_synthesis_output_format(speech_synthesis_output_format)

                self.logger.debug("SpeechConfig created successfully")
                return speech_config

            except ClientAuthenticationError:
                raise
            except Exception:
                self.logger.exception("Failed to create SpeechConfig")
                raise

    def refresh_authorization_token(
        self,
        target: speechsdk.SpeechSynthesizer | speechsdk.SpeechRecognizer,
    ) -> None:
        """
        Refresh the authorization token on an existing synthesizer or recognizer.

        Long-lived speech objects need their token refreshed before the
        ~10 minute expiry. Call this from a background task.

        Args:
            target: Active SpeechSynthesizer or SpeechRecognizer

        Raises:
            ClientAuthenticationError: If token acquisition fails

        """
        with self.logger.create_span(
            "AzureSpeech.refresh_authorization_token",
            attributes={
                "service.name": self.service_name,
                "operation.type": "token_refresh",
                "speech.target_type": type(target).__name__,
            },
        ):
            try:
                target.authorization_token = self.get_authorization_token()
                self.logger.debug(
                    "Authorization token refreshed",
                    extra={"target_type": type(target).__name__},
                )
            except ClientAuthenticationError:
                self.logger.exception("Failed to refresh Speech authorization token")
                raise

    # ── Internal Synthesis Helper ─────────────────────────────────

    def _run_synthesis(
        self,
        text: str,
        audio_config: speechsdk.audio.AudioOutputConfig | None,
        voice_name: str | None,
        output_format: speechsdk.SpeechSynthesisOutputFormat | None,
        operation_name: str,
        operation_type: str,
    ) -> speechsdk.SpeechSynthesisResult:
        """
        Build a SpeechConfig + SpeechSynthesizer, run speak_text_async, and
        validate the result. Raises AzureError on cancellation or failure.
        """
        with self.logger.create_span(
            f"AzureSpeech.{operation_name}",
            attributes={
                "service.name": self.service_name,
                "operation.type": operation_type,
                "speech.voice_name": voice_name or self.default_speech_synthesis_voice_name,
                "speech.text_length": len(text),
            },
        ):
            try:
                self.logger.debug(
                    f"Running {operation_name}",
                    extra={"text_length": len(text)},
                )

                speech_config = self.get_speech_config(
                    speech_synthesis_voice_name=voice_name,
                    speech_synthesis_output_format=output_format,
                )

                synthesizer = speechsdk.SpeechSynthesizer(
                    speech_config=speech_config, audio_config=audio_config
                )
                result = synthesizer.speak_text_async(text).get()

                if result is None:
                    error_msg = "Speech synthesis returned no result"
                    self.logger.error(error_msg)
                    raise AzureError(error_msg)

                if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
                    self.logger.info(
                        f"{operation_name} succeeded",
                        extra={"audio_size_bytes": len(result.audio_data)},
                    )
                    return result

                if result.reason == speechsdk.ResultReason.Canceled:
                    cancellation = result.cancellation_details
                    error_msg = (
                        f"Speech synthesis canceled: reason={cancellation.reason}, "
                        f"details={cancellation.error_details}"
                    )
                    self.logger.error(error_msg)
                    raise AzureError(error_msg)

                error_msg = f"Speech synthesis failed with reason: {result.reason}"
                self.logger.error(error_msg)
                raise AzureError(error_msg)

            except AzureError:
                raise
            except Exception as exc:
                self.logger.exception(f"Failed to run {operation_name}")
                msg = f"Speech synthesis failed: {exc}"
                raise AzureError(msg) from exc

    # ── Synthesis: To Bytes (in-memory) ───────────────────────────

    def synthesize_text_to_bytes(
        self,
        text: str,
        voice_name: str | None = None,
        output_format: speechsdk.SpeechSynthesisOutputFormat | None = None,
    ) -> bytes:
        """
        Synthesize text to audio and return the audio bytes in memory.

        Passes audio_config=None so the audio is routed to the result buffer
        instead of being played on the default speaker.

        Args:
            text: Text to synthesize
            voice_name: Optional voice override (default: instance default)
            output_format: Optional output format override

        Returns:
            Audio bytes (format depends on output_format)

        Raises:
            AzureError: If synthesis fails

        """
        result = self._run_synthesis(
            text=text,
            audio_config=None,
            voice_name=voice_name,
            output_format=output_format,
            operation_name="synthesize_text_to_bytes",
            operation_type="text_synthesis_bytes",
        )
        return bytes(result.audio_data)

    # ── Synthesis: To File ────────────────────────────────────────

    def synthesize_text_to_file(
        self,
        text: str,
        file_path: str,
        voice_name: str | None = None,
        output_format: speechsdk.SpeechSynthesisOutputFormat | None = None,
    ) -> None:
        """
        Synthesize text and write the audio directly to a file.

        Args:
            text: Text to synthesize
            file_path: Output file path (e.g., 'output.wav')
            voice_name: Optional voice override
            output_format: Optional output format override

        Raises:
            AzureError: If synthesis fails

        """
        audio_config = speechsdk.audio.AudioOutputConfig(filename=file_path)
        self._run_synthesis(
            text=text,
            audio_config=audio_config,
            voice_name=voice_name,
            output_format=output_format,
            operation_name="synthesize_text_to_file",
            operation_type="text_synthesis_file",
        )

    # ── Synthesis: To Default Speaker ─────────────────────────────

    def synthesize_text_to_speaker(
        self,
        text: str,
        voice_name: str | None = None,
        output_format: speechsdk.SpeechSynthesisOutputFormat | None = None,
    ) -> None:
        """
        Synthesize text and play it on the default speaker.

        Uses speechsdk.audio.AudioOutputConfig(use_default_speaker=True) to
        route audio to the active output device. Useful for local development
        and interactive scenarios; not suitable for server/container use.

        Args:
            text: Text to synthesize
            voice_name: Optional voice override
            output_format: Optional output format override

        Raises:
            AzureError: If synthesis fails

        """
        audio_config = speechsdk.audio.AudioOutputConfig(use_default_speaker=True)
        self._run_synthesis(
            text=text,
            audio_config=audio_config,
            voice_name=voice_name,
            output_format=output_format,
            operation_name="synthesize_text_to_speaker",
            operation_type="text_synthesis_speaker",
        )

    # ── Connection Test & Correlation ─────────────────────────────

    def test_connection(self) -> bool:
        """
        Test connection by acquiring a token and constructing a SpeechConfig.

        Returns:
            True if token acquisition and config creation succeed

        """
        with self.logger.create_span(
            "AzureSpeech.test_connection",
            attributes={
                "service.name": self.service_name,
                "operation.type": "connection_test",
                "speech.region": self.region,
            },
        ):
            try:
                self.logger.debug("Testing Speech connection")
                self.get_speech_config()
                self.logger.info("Speech connection test successful")
                return True
            except (AzureError, ClientAuthenticationError, Exception) as e:  # noqa: BLE001
                self.logger.warning(
                    f"Speech connection test failed: {e}",
                    extra={"region": self.region},
                )
                return False

    def set_correlation_id(self, correlation_id: str) -> None:
        """Set correlation ID for request/transaction tracking."""
        self.logger.set_correlation_id(correlation_id)

    def get_correlation_id(self) -> str | None:
        """Get current correlation ID."""
        return self.logger.get_correlation_id()


def create_azure_speech(
    region: str,
    resource_id: str,
    credential: TokenCredential | None = None,
    azure_identity: AzureIdentity | None = None,
    service_name: str = "azure_speech",
    service_version: str = "1.0.0",
    logger: AzureLogger | None = None,
    connection_string: str | None = None,
    default_speech_recognition_language: str = "en-US",
    default_speech_synthesis_voice_name: str = "en-US-JennyNeural",
) -> AzureSpeech:
    """
    Factory function to create a cached AzureSpeech instance.

    Returns existing instance if one with same configuration exists.
    Creates a default AzureIdentity if neither credential nor
    azure_identity is provided.

    """
    if credential is None and azure_identity is None:
        from ..mgmt.identity import create_azure_identity

        azure_identity = create_azure_identity(
            service_name=f"{service_name}_identity",
            service_version=service_version,
            connection_string=connection_string,
        )

    cache_key: tuple[Any, ...] = (
        region,
        resource_id,
        service_name,
        service_version,
        connection_string,
        default_speech_recognition_language,
        default_speech_synthesis_voice_name,
        id(credential) if credential is not None else None,
        id(azure_identity) if azure_identity is not None else None,
    )

    if cache_key in _speech_instances:
        return _speech_instances[cache_key]

    instance = AzureSpeech(
        region=region,
        resource_id=resource_id,
        credential=credential,
        azure_identity=azure_identity,
        service_name=service_name,
        service_version=service_version,
        logger=logger,
        connection_string=connection_string,
        default_speech_recognition_language=default_speech_recognition_language,
        default_speech_synthesis_voice_name=default_speech_synthesis_voice_name,
    )

    _speech_instances[cache_key] = instance
    return instance
