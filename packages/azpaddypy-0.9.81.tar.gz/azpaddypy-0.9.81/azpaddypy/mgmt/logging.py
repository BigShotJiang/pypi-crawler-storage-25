import contextvars
import functools
import inspect
import logging
import os
import sys
import time
import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from azure.core.exceptions import AzureError
from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry import baggage, trace
from opentelemetry.context import Context
from opentelemetry.sdk.resources import Resource
from opentelemetry.trace import Span, Status, StatusCode

from .._cache import RingCache


class AzureLogger:
    """
    Azure-integrated logger with OpenTelemetry distributed tracing.

    Provides comprehensive logging with Azure Monitor integration, correlation
    tracking, baggage propagation, and automated function tracing for Azure
    applications with seamless local development support.

    CLOUD ROLE NAME INTEGRATION:
    The service_name parameter automatically sets the cloud role name for
    Application Insights. When multiple services emit telemetry to the same
    Application Insights resource, each service will appear as a separate
    node on the Application Map, enabling proper service topology visualization.

    CORRELATION ID AUTOMATION:
    The trace_function decorator automatically generates UUID4 correlation IDs
    when none are manually set, ensuring consistent distributed tracing across
    all function calls without requiring manual configuration.

    AI FOUNDRY TRACING:
    On initialization, the logger automatically instruments the OpenAI SDK
    via opentelemetry-instrumentation-openai-v2 (if installed). This creates
    GenAI-semantic spans (model name, token usage, latency) for every
    openai.chat.completions.create() call. These spans flow through the
    existing Azure Monitor exporter and appear in the AI Foundry Tracing UI
    when the Application Insights resource is linked to a Foundry project.
    When trace_function is used with log_result=True, GenAI content recording
    is enabled so that prompt messages and completion responses are captured
    in the trace spans.

    Supports all standard logging levels (debug, info, warning, error, exception,
    critical) with enhanced context including trace IDs, correlation IDs, and
    baggage propagation.

    Attributes:
        service_name: Service identifier for telemetry and cloud role name
        service_version: Service version for context
        connection_string: Application Insights connection string
        logger: Python logger instance
        tracer: OpenTelemetry tracer for spans

    """

    _RESERVED_LOG_RECORD_ATTRIBUTES: frozenset[str] = frozenset(
        {
            "name",
            "msg",
            "args",
            "levelname",
            "levelno",
            "pathname",
            "filename",
            "module",
            "exc_info",
            "exc_text",
            "stack_info",
            "lineno",
            "funcName",
            "created",
            "msecs",
            "relativeCreated",
            "thread",
            "threadName",
            "processName",
            "process",
            "getMessage",
        }
    )

    def __init__(
        self,
        service_name: str,
        service_version: str = "1.0.0",
        connection_string: str | None = None,
        log_level: int = logging.INFO,
        enable_console_logging: bool = True,
        custom_resource_attributes: dict[str, str] | None = None,
        instrumentation_options: dict[str, Any] | None = None,
        cloud_role_name: str | None = None,
    ):
        """
        Initialize Azure Logger with OpenTelemetry tracing.

        The service_name parameter automatically sets the cloud role name for
        Application Insights Application Map visualization. When multiple services
        emit telemetry to the same Application Insights resource, each service
        will appear as a separate node on the Application Map.

        Args:
            service_name: Service identifier for telemetry and cloud role name
            service_version: Service version for metadata
            connection_string: Application Insights connection string
            log_level: Python logging level (default: INFO)
            enable_console_logging: Enable console output for local development
            custom_resource_attributes: Additional OpenTelemetry resource attributes
            instrumentation_options: Azure Monitor instrumentation options
            cloud_role_name: Override cloud role name (defaults to service_name)

        """
        self.service_name = service_name
        self.service_version = service_version
        self.connection_string = connection_string or os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")

        # Use explicit cloud role name or default to service name
        effective_cloud_role_name = cloud_role_name or service_name
        self.cloud_role_name = effective_cloud_role_name

        # Configure resource attributes according to Azure Monitor OpenTelemetry best practices
        # NOTE: Azure Monitor cloud role name uses service.namespace + service.name,
        # or falls back to service.name if service.namespace isn't set
        resource_attributes = {
            "service.name": effective_cloud_role_name,
            "service.version": service_version,
        }

        if custom_resource_attributes:
            resource_attributes.update(custom_resource_attributes)

        # Configure Azure Monitor if connection string available
        if self.connection_string:
            try:
                # Create a Resource with the attributes to ensure they're properly applied
                # This ensures Azure Monitor correctly maps service.name to cloud role name
                resource = Resource.create(resource_attributes)

                configure_azure_monitor(
                    connection_string=self.connection_string,
                    resource=resource,
                    enable_live_metrics=True,
                    instrumentation_options=instrumentation_options or {},
                )
                self._telemetry_enabled = True
            except (AzureError, RuntimeError, ValueError) as e:
                print(f"Warning: Failed to configure Azure Monitor: {e}")
                self._telemetry_enabled = False
        else:
            self._telemetry_enabled = False
            print("Warning: No Application Insights connection string found. Telemetry disabled.")

        # Instrument OpenAI SDK for AI Foundry tracing.
        # Spans follow OpenTelemetry GenAI semantic conventions and flow
        # through the already-configured Azure Monitor exporter.
        self._genai_instrumented = False
        try:
            from opentelemetry.instrumentation.openai_v2 import OpenAIInstrumentor

            instrumentor = OpenAIInstrumentor()
            if not instrumentor.is_instrumented_by_opentelemetry:
                instrumentor.instrument()
            self._genai_instrumented = True
        except ImportError:
            pass

        # Configure Python logger
        self.logger = logging.getLogger(service_name)
        self.logger.setLevel(log_level)
        self.logger.handlers.clear()

        if enable_console_logging:
            self._setup_console_handler()

        # Initialize OpenTelemetry tracer and correlation context
        self.tracer = trace.get_tracer(__name__)
        self._correlation_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
            f"correlation_id_{service_name}", default=None
        )

        self.info(
            f"Azure Logger initialized for service '{service_name}' v{service_version} "
            f"(cloud role: '{effective_cloud_role_name}')"
        )

    def _setup_console_handler(self):
        """Configure console handler for local development."""
        console_handler = logging.StreamHandler()
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s - %(pathname)s:%(lineno)d")
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

    def _get_correlation_id(self) -> str | None:
        """Get correlation ID from the current async context."""
        return self._correlation_id_var.get()

    def _set_correlation_id(self, correlation_id: str) -> None:
        """Set correlation ID in the current async context."""
        self._correlation_id_var.set(correlation_id)

    def set_correlation_id(self, correlation_id: str):
        """
        Set correlation ID for request/transaction tracking.

        Manually sets the correlation ID that will be used for all subsequent
        tracing operations in the current async context. This value takes
        precedence over auto-generated correlation IDs in the trace_function
        decorator.

        Uses contextvars for async safety -- each concurrent coroutine/task
        maintains its own correlation ID without cross-contamination.

        Args:
            correlation_id: Unique identifier for transaction correlation

        Note:
            If not set manually, the trace_function decorator will automatically
            generate a UUID4 correlation_id on first use.

        """
        self._set_correlation_id(correlation_id)

    def get_correlation_id(self) -> str | None:
        """
        Get current correlation ID.

        Returns the currently active correlation ID, whether manually set
        or automatically generated by the trace_function decorator.

        Returns:
            Current correlation ID if set (manual or auto-generated), otherwise None

        """
        return self._get_correlation_id()

    def set_baggage(self, key: str, value: str) -> Context:
        """
        Set baggage item in OpenTelemetry context.

        Args:
            key: Baggage key
            value: Baggage value

        Returns:
            Updated context with baggage item

        """
        return baggage.set_baggage(key, value)

    def get_baggage(self, key: str) -> str | None:
        """
        Get baggage item from current context.

        Args:
            key: Baggage key

        Returns:
            Baggage value if exists, otherwise None

        """
        return baggage.get_baggage(key)

    def get_all_baggage(self) -> dict[str, str]:
        """
        Get all baggage items from current context.

        Returns:
            Dictionary of all baggage items

        """
        return dict(baggage.get_all())

    def _enhance_extra(self, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Enrich log records with contextual information.

        Args:
            extra: Optional custom data dictionary

        Returns:
            Enhanced dictionary with service context, correlation ID, trace
            context, and baggage items, with built-in LogRecord attributes filtered out

        """
        reserved_attributes = self._RESERVED_LOG_RECORD_ATTRIBUTES

        enhanced_extra = {
            "service_name": self.service_name,
            "service_version": self.service_version,
            "timestamp": datetime.now(tz=UTC).isoformat(),
        }

        correlation_id = self._get_correlation_id()
        if correlation_id:
            enhanced_extra["correlation_id"] = correlation_id

        # Add span context if available
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            span_context = current_span.get_span_context()
            enhanced_extra["trace_id"] = format(span_context.trace_id, "032x")
            enhanced_extra["span_id"] = format(span_context.span_id, "016x")

        # Add baggage items, filtering out any reserved attribute names
        baggage_items = self.get_all_baggage()
        if baggage_items:
            # Filter baggage items to avoid conflicts with LogRecord attributes
            filtered_baggage = {k: v for k, v in baggage_items.items() if k not in reserved_attributes}
            if filtered_baggage:
                enhanced_extra["baggage"] = filtered_baggage

            # Log warning if any baggage keys were filtered out
            filtered_baggage_keys = set(baggage_items.keys()) - set(filtered_baggage.keys())
            if filtered_baggage_keys:
                # Use the base logger directly to avoid infinite recursion
                self.logger.warning(f"Filtered out reserved LogRecord attributes from baggage: {filtered_baggage_keys}")

        if isinstance(extra, dict):
            # Filter out any keys that would conflict with built-in LogRecord attributes
            filtered_extra = {k: v for k, v in extra.items() if k not in reserved_attributes}
            enhanced_extra.update(filtered_extra)

            # Log warning if any keys were filtered out
            filtered_keys = set(extra.keys()) - set(filtered_extra.keys())
            if filtered_keys:
                # Use the base logger directly to avoid infinite recursion
                self.logger.warning(f"Filtered out reserved LogRecord attributes from extra data: {filtered_keys}")

        return enhanced_extra

    def debug(self, message: str, extra: dict[str, Any] | None = None):
        """Log debug message with enhanced context."""
        self.logger.debug(message, extra=self._enhance_extra(extra))

    def info(self, message: str, extra: dict[str, Any] | None = None):
        """Log info message with enhanced context."""
        self.logger.info(message, extra=self._enhance_extra(extra))

    def warning(self, message: str, extra: dict[str, Any] | None = None):
        """Log warning message with enhanced context."""
        self.logger.warning(message, extra=self._enhance_extra(extra))

    def error(
        self,
        message: str,
        extra: dict[str, Any] | None = None,
        exc_info: bool = True,
    ):
        """Log error message with enhanced context and exception info."""
        self.logger.error(message, extra=self._enhance_extra(extra), exc_info=exc_info)

    def exception(self, message: str, extra: dict[str, Any] | None = None):
        """
        Log exception message with enhanced context and automatic exception info.

        This method is a convenience method equivalent to calling error() with
        exc_info=True. It should typically be called only from exception handlers.

        Args:
            message: Exception message to log
            extra: Additional custom properties

        """
        self.logger.error(message, extra=self._enhance_extra(extra), exc_info=True)  # noqa: LOG014

    def critical(self, message: str, extra: dict[str, Any] | None = None):
        """Log critical message with enhanced context."""
        self.logger.critical(message, extra=self._enhance_extra(extra))

    def log_function_execution(
        self,
        function_name: str,
        duration_ms: float,
        success: bool = True,
        extra: dict[str, Any] | None = None,
    ):
        """
        Log function execution metrics for performance monitoring.

        Args:
            function_name: Name of executed function
            duration_ms: Execution duration in milliseconds
            success: Whether function executed successfully
            extra: Additional custom properties

        """
        log_data = {
            "function_name": function_name,
            "duration_ms": duration_ms,
            "success": success,
            "performance_category": "function_execution",
        }

        if extra:
            log_data.update(extra)

        message = f"Function '{function_name}' executed in {duration_ms:.2f}ms - {'SUCCESS' if success else 'FAILED'}"

        if success:
            self.info(message, extra=log_data)
        else:
            self.error(message, extra=log_data, exc_info=False)

    def log_request(
        self,
        method: str,
        url: str,
        status_code: int,
        duration_ms: float,
        extra: dict[str, Any] | None = None,
    ):
        """
        Log HTTP request with comprehensive details.

        Args:
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            status_code: HTTP response status code
            duration_ms: Request duration in milliseconds
            extra: Additional custom properties

        """
        log_data = {
            "http_method": method,
            "http_url": str(url),
            "http_status_code": status_code,
            "duration_ms": duration_ms,
            "request_category": "http_request",
        }

        if extra:
            log_data.update(extra)

        # Determine log level and status based on status code
        if status_code < 400:
            log_level = logging.INFO
            status_text = "SUCCESS"
        elif status_code < 500:
            log_level = logging.WARNING
            status_text = "CLIENT_ERROR"
        else:
            log_level = logging.ERROR
            status_text = "SERVER_ERROR"

        message = f"{method} {url} - {status_code} - {duration_ms:.2f}ms - {status_text}"
        self.logger.log(log_level, message, extra=self._enhance_extra(log_data))

    def create_span(
        self,
        span_name: str,
        attributes: dict[str, str | int | float | bool] | None = None,
    ) -> trace.Span:
        """
        Create OpenTelemetry span for distributed tracing.

        Uses start_as_current_span so that any child spans created inside
        the returned context manager are automatically linked as children.

        Args:
            span_name: Name for the span
            attributes: Initial span attributes

        Returns:
            OpenTelemetry span context manager

        """
        default_attributes: dict[str, str | int | float | bool] = {
            "service.name": self.service_name,
            "service.version": self.service_version,
        }

        correlation_id = self._get_correlation_id()
        if correlation_id:
            default_attributes["correlation.id"] = correlation_id

        if attributes:
            default_attributes.update(attributes)

        return self.tracer.start_as_current_span(span_name, attributes=default_attributes)

    @staticmethod
    def _format_span_attribute(value: Any) -> str:
        """Format a span attribute value for safe serialization."""
        try:
            attr_value = str(value)
        except (AttributeError, OverflowError, TypeError, ValueError):
            return "<non-serializable>"
        if len(attr_value) > 1000:
            attr_value = f"{attr_value[:1000]}..."
        return attr_value

    def _setup_span_for_function_trace(
        self,
        span: Span,
        func: Callable,
        is_async: bool,
        log_args: bool,
        args: tuple,
        kwargs: dict,
        log_result: bool,
        log_execution: bool,
    ):
        """Configure span attributes for function tracing."""
        span.set_attribute("function.name", func.__name__)
        span.set_attribute("function.module", func.__module__)
        span.set_attribute("service.name", self.service_name)
        span.set_attribute("function.is_async", is_async)

        # Add decorator parameters as span attributes
        span.set_attribute("function.decorator.log_args", log_args)
        span.set_attribute("function.decorator.log_result", log_result)
        span.set_attribute("function.decorator.log_execution", log_execution)

        correlation_id = self._get_correlation_id()
        if correlation_id:
            span.set_attribute("correlation.id", correlation_id)

        if log_args:
            if args:
                span.set_attribute("function.args_count", len(args))
                # Add positional arguments as span attributes
                param_names: list[str] = []
                try:
                    param_names = list(inspect.signature(func).parameters.keys())
                except (ValueError, TypeError):
                    param_names = []

                for i, arg_value in enumerate(args):
                    param_name = param_names[i] if i < len(param_names) else f"arg_{i}"
                    attr_value = self._format_span_attribute(arg_value)
                    span.set_attribute(f"function.arg.{param_name}", attr_value)

            if kwargs:
                span.set_attribute("function.kwargs_count", len(kwargs))
                # Add keyword arguments as span attributes
                for key, value in kwargs.items():
                    attr_value = self._format_span_attribute(value)
                    span.set_attribute(f"function.kwarg.{key}", attr_value)

    def _handle_function_success(
        self,
        span: Span,
        func: Callable,
        duration_ms: float,
        result: Any,
        log_result: bool,
        log_execution: bool,
        is_async: bool,
        args: tuple,
        kwargs: dict,
    ):
        """Handle successful function execution in tracing."""
        span.set_attribute("function.duration_ms", duration_ms)
        span.set_attribute("function.success", True)  # noqa: FBT003
        span.set_status(Status(StatusCode.OK))

        if log_result and result is not None:
            span.set_attribute("function.has_result", True)  # noqa: FBT003
            span.set_attribute("function.result_type", type(result).__name__)
            attr_value = self._format_span_attribute(result)
            span.set_attribute("function.result", attr_value)

        if log_execution:
            self.log_function_execution(
                func.__name__,
                duration_ms,
                success=True,
                extra={
                    "args_count": len(args) if args else 0,
                    "kwargs_count": len(kwargs) if kwargs else 0,
                    "is_async": is_async,
                },
            )

        log_prefix = "Async function" if is_async else "Function"
        self.debug(f"{log_prefix} execution completed: {func.__name__}")

    def _handle_function_exception(
        self,
        span: Span,
        func: Callable,
        duration_ms: float,
        e: Exception,
        log_execution: bool,
        is_async: bool,
    ):
        """Handle failed function execution in tracing."""
        span.set_status(Status(StatusCode.ERROR, description=str(e)))
        span.record_exception(e)
        if log_execution:
            self.log_function_execution(function_name=func.__name__, duration_ms=duration_ms, success=False)
            self.error(f"Exception in {'async ' if is_async else ''}function '{func.__name__}': {e}")

    def trace_function(
        self,
        function_name: str | None = None,
        log_execution: bool = True,
        log_args: bool = True,
        log_result: bool = False,
    ) -> Callable:
        """
        Trace function execution with OpenTelemetry.

        This decorator provides a simple way to instrument a function by automatically
        creating an OpenTelemetry span to trace its execution. It measures execution
        time, captures arguments, and records the result as attributes on the span.
        It supports both synchronous and asynchronous functions.

        A correlation ID is automatically managed. If one is not already set on the
        logger instance, a new UUID4 correlation ID will be generated and used for
        the function's trace, ensuring that all related logs and traces can be
        linked together.

        Args:
            function_name (Optional[str]):
                Specifies a custom name for the span. If not provided, the name of the
                decorated function is used. Defaults to None.
            log_execution (bool):
                When True, a log message is emitted at the start and end of the function's
                execution, including the execution duration. This provides a clear
                record of the function's lifecycle. Defaults to True.
            log_args (bool):
                When True, the arguments passed to the function are recorded as
                attributes on the span. It captures argument names and their string
                representations, truncating long values to 1000 characters.
                This is useful for understanding the context of the function call.
                Sensitive arguments should be handled with care. Defaults to True.
            log_result (bool):
                When True, the function's return value is recorded as an attribute
                on the span. It captures the result's type and its string
                representation, truncating long values to 1000 characters. This
                should be used cautiously, as large or sensitive return values may
                be captured. Defaults to False.
                When GenAI instrumentation is active, setting log_result=True also
                enables AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED so that
                prompt messages and completion responses from OpenAI SDK calls
                within this function are captured in AI Foundry traces.

        Returns:
            Callable: A decorator that can be applied to a function.

        Examples:
            Basic usage with default settings:
            Logs execution, arguments, but not the result.

            @logger.trace_function()
            def sample_function(param1, param2="default"):
                return "done"

            Customizing the span name:
            The span will be named "MyCustomTask" instead of "process_data".

            @logger.trace_function(function_name="MyCustomTask")
            def process_data(data):
                # processing logic
                return {"status": "processed"}

            Logging the result:
            Enable `log_result=True` to capture the function's return value.

            @logger.trace_function(log_result=True)
            def get_user_id(username):
                return 12345

            Disabling argument logging for sensitive data:
            If a function handles sensitive information, disable argument logging.

            @logger.trace_function(log_args=False)
            def process_payment(credit_card_details):
                # payment processing logic
                pass

            Tracing an asynchronous function:
            The decorator works with async functions without any extra configuration.

            @logger.trace_function(log_result=True)
            async def fetch_remote_data(url):
                # async data fetching
                return await http_get(url)

        """

        def _begin_trace(span: Span, func: Callable, is_async: bool, args: tuple, kwargs: dict) -> float:
            """Shared setup for traced function execution. Returns start time."""
            if not self._get_correlation_id():
                self._set_correlation_id(str(uuid.uuid4()))

            # Sync GenAI content recording with log_result so that
            # prompt/completion payloads appear in AI Foundry traces
            # when the caller already opted into result logging.
            if self._genai_instrumented and log_result:
                os.environ["AZURE_TRACING_GEN_AI_CONTENT_RECORDING_ENABLED"] = "true"

            self._setup_span_for_function_trace(
                span,
                func,
                is_async=is_async,
                log_args=log_args,
                args=args,
                kwargs=kwargs,
                log_result=log_result,
                log_execution=log_execution,
            )
            log_prefix = "async function" if is_async else "function"
            self.debug(f"Starting {log_prefix} execution: {func.__name__}")
            return time.time()

        def _end_trace(
            span: Span, func: Callable, is_async: bool, start_time: float, result: Any, args: tuple, kwargs: dict
        ) -> None:
            """Shared finalization for traced function execution."""
            duration_ms = (time.time() - start_time) * 1000
            _, exc_value, _ = sys.exc_info()
            if exc_value is not None:
                self._handle_function_exception(
                    span, func, duration_ms, exc_value, log_execution=log_execution, is_async=is_async
                )
            else:
                self._handle_function_success(
                    span,
                    func,
                    duration_ms,
                    result,
                    log_result=log_result,
                    log_execution=log_execution,
                    is_async=is_async,
                    args=args,
                    kwargs=kwargs,
                )

        def decorator(func):
            is_async = inspect.iscoroutinefunction(func)

            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                span_name = function_name or f"{func.__module__}.{func.__name__}"
                with self.tracer.start_as_current_span(span_name) as span:
                    start_time = _begin_trace(span, func, is_async=True, args=args, kwargs=kwargs)
                    result: Any | None = None
                    try:
                        result = await func(*args, **kwargs)
                    finally:
                        _end_trace(
                            span, func, is_async=True, start_time=start_time, result=result, args=args, kwargs=kwargs
                        )
                    return result

            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                span_name = function_name or f"{func.__module__}.{func.__name__}"
                with self.tracer.start_as_current_span(span_name) as span:
                    start_time = _begin_trace(span, func, is_async=False, args=args, kwargs=kwargs)
                    result: Any | None = None
                    try:
                        result = func(*args, **kwargs)
                    finally:
                        _end_trace(
                            span, func, is_async=False, start_time=start_time, result=result, args=args, kwargs=kwargs
                        )
                    return result

            if is_async:
                return async_wrapper
            return sync_wrapper

        return decorator

    def add_span_attributes(self, attributes: dict[str, str | int | float | bool]):
        """Add attributes to current active span."""
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            for key, value in attributes.items():
                current_span.set_attribute(key, value)

    def add_span_event(self, name: str, attributes: dict[str, Any] | None = None):
        """Add event to current active span."""
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            event_attributes = attributes or {}
            correlation_id = self._get_correlation_id()
            if correlation_id:
                event_attributes["correlation_id"] = correlation_id
            current_span.add_event(name, event_attributes)

    def set_span_status(self, status_code: StatusCode, description: str | None = None):
        """Set status of current active span."""
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            current_span.set_status(Status(status_code, description))

    def log_with_span(
        self,
        span_name: str,
        message: str,
        level: int = logging.INFO,
        extra: dict[str, Any] | None = None,
        span_attributes: dict[str, str | int | float | bool] | None = None,
    ):
        """
        Log message within a span context.

        Args:
            span_name: Name for the span
            message: Log message
            level: Python logging level
            extra: Additional log properties
            span_attributes: Attributes to add to span

        """
        with self.tracer.start_as_current_span(span_name) as span:
            if span_attributes:
                for key, value in span_attributes.items():
                    span.set_attribute(key, value)

            self.logger.log(level, message, extra=self._enhance_extra(extra))

    def log_dependency(
        self,
        dependency_type: str,
        name: str,
        command: str,
        success: bool,
        duration_ms: float,
        extra: dict[str, Any] | None = None,
    ):
        """
        Log external dependency calls for monitoring.

        Args:
            dependency_type: Type of dependency (SQL, HTTP, etc.)
            name: Dependency identifier
            command: Command/query executed
            success: Whether call was successful
            duration_ms: Call duration in milliseconds
            extra: Additional properties

        """
        log_data = {
            "dependency_type": dependency_type,
            "dependency_name": name,
            "dependency_command": command,
            "dependency_success": success,
            "duration_ms": duration_ms,
            "category": "dependency_call",
        }

        if extra:
            log_data.update(extra)

        log_level = logging.INFO if success else logging.ERROR
        status = "SUCCESS" if success else "FAILED"
        message = f"Dependency call: {dependency_type}:{name} - {duration_ms:.2f}ms - {status}"

        self.logger.log(log_level, message, extra=self._enhance_extra(log_data))

    def flush(self):
        """Flush pending telemetry data and logger handlers."""
        # Flush Python logger handlers
        for handler in self.logger.handlers:
            handler.flush()

        if self._telemetry_enabled:
            try:
                tracer_provider = trace.get_tracer_provider()
                if hasattr(tracer_provider, "force_flush"):
                    tracer_provider.force_flush(timeout_millis=5000)

                logger_provider = logging.getLogger().manager.root
                if hasattr(logger_provider, "handlers"):
                    for handler in logger_provider.handlers:
                        handler.flush()
            except (AzureError, RuntimeError) as e:
                self.warning(f"Failed to flush telemetry: {e}")


# Factory functions with logger caching (bounded ring buffer, max 10)
_loggers: RingCache = RingCache(maxsize=10)


def create_app_logger(
    service_name: str,
    service_version: str = "1.0.0",
    connection_string: str | None = None,
    log_level: int = logging.INFO,
    enable_console_logging: bool = True,
    custom_resource_attributes: dict[str, str] | None = None,
    instrumentation_options: dict[str, Any] | None = None,
    cloud_role_name: str | None = None,
) -> AzureLogger:
    """
    Factory function to create a cached AzureLogger instance for applications.

    Returns existing instance if one with same configuration exists.
    The service_name automatically becomes the cloud role name in
    Application Insights unless overridden via cloud_role_name.

    """
    resolved_connection_string = connection_string or os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")

    attr_items = tuple(sorted(custom_resource_attributes.items())) if custom_resource_attributes else None
    instr_items = (
        tuple(
            sorted(
                (k, tuple(sorted(v.items())) if isinstance(v, dict) else v) for k, v in instrumentation_options.items()
            )
        )
        if instrumentation_options
        else None
    )

    params_key = (
        service_name,
        service_version,
        resolved_connection_string,
        log_level,
        enable_console_logging,
        attr_items,
        instr_items,
        cloud_role_name,
    )

    if params_key in _loggers:
        return _loggers[params_key]

    logger = AzureLogger(
        service_name=service_name,
        service_version=service_version,
        connection_string=connection_string,
        log_level=log_level,
        enable_console_logging=enable_console_logging,
        custom_resource_attributes=custom_resource_attributes,
        instrumentation_options=instrumentation_options,
        cloud_role_name=cloud_role_name,
    )
    _loggers[params_key] = logger
    return logger


def create_function_logger(
    function_app_name: str,
    function_name: str,
    service_version: str = "1.0.0",
    connection_string: str | None = None,
    log_level: int = logging.INFO,
    instrumentation_options: dict[str, Any] | None = None,
    cloud_role_name: str | None = None,
) -> AzureLogger:
    """
    Factory function to create an AzureLogger for Azure Functions.

    Cloud role name defaults to '{function_app_name}.{function_name}'
    so each function appears as a separate node in the Application
    Insights Application Map. Delegates to create_app_logger.

    """
    custom_attributes = {
        "azure.function.app": function_app_name,
        "azure.function.name": function_name,
        "azure.resource.type": "function",
    }

    default_service_name = f"{function_app_name}.{function_name}"

    return create_app_logger(
        service_name=default_service_name,
        service_version=service_version,
        connection_string=connection_string,
        log_level=log_level,
        custom_resource_attributes=custom_attributes,
        instrumentation_options=instrumentation_options,
        cloud_role_name=cloud_role_name,
    )
