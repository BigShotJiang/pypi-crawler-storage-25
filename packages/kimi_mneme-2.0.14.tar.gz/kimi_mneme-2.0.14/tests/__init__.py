"""Tests for kimi-mneme."""
