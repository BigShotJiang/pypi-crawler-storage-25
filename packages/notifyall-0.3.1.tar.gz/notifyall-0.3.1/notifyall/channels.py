import smtplib
import json
import urllib.request
import urllib.parse
import base64
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


class BaseChannel:
    name = "base"

    def send(self, message: str, title: str = "") -> dict:
        raise NotImplementedError

    def send_with_retry(self, message: str, title: str = "", retries: int = 3, delay: float = 2.0) -> dict:
        last_result = {}
        for attempt in range(1, retries + 1):
            result = self.send(message, title)
            if result.get("status") == "ok":
                return result
            last_result = result
            if attempt < retries:
                time.sleep(delay)
        last_result["attempts"] = retries
        return last_result


class EmailChannel(BaseChannel):
    name = "email"

    def __init__(self, smtp_host: str, smtp_port: int, username: str,
                 password: str, from_addr: str, to_addr: str, use_tls: bool = True):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.from_addr = from_addr
        self.to_addr = to_addr
        self.use_tls = use_tls

    def send(self, message: str, title: str = "Notification") -> dict:
        try:
            msg = MIMEMultipart()
            msg["From"] = self.from_addr
            msg["To"] = self.to_addr
            msg["Subject"] = title
            msg.attach(MIMEText(message, "plain", "utf-8"))
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                if self.use_tls:
                    server.starttls()
                server.login(self.username, self.password)
                server.sendmail(self.from_addr, self.to_addr, msg.as_string())
            return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}

    def send_html(self, html_message: str, title: str = "Notification") -> dict:
        try:
            msg = MIMEMultipart("alternative")
            msg["From"] = self.from_addr
            msg["To"] = self.to_addr
            msg["Subject"] = title
            msg.attach(MIMEText(html_message, "html", "utf-8"))
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                if self.use_tls:
                    server.starttls()
                server.login(self.username, self.password)
                server.sendmail(self.from_addr, self.to_addr, msg.as_string())
            return {"channel": self.name, "status": "ok", "format": "html"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}

    def send_to_multiple(self, message: str, recipients: list, title: str = "Notification") -> list:
        return [EmailChannel(
            self.smtp_host, self.smtp_port, self.username,
            self.password, self.from_addr, r, self.use_tls
        ).send(message, title) for r in recipients]


class SlackChannel(BaseChannel):
    name = "slack"

    def __init__(self, webhook_url: str, username: str = "notifyall", icon_emoji: str = ":bell:"):
        self.webhook_url = webhook_url
        self.username = username
        self.icon_emoji = icon_emoji

    def send(self, message: str, title: str = "") -> dict:
        try:
            text = f"*{title}*\n{message}" if title else message
            payload = json.dumps({
                "text": text,
                "username": self.username,
                "icon_emoji": self.icon_emoji
            }).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}

    def send_blocks(self, blocks: list, title: str = "") -> dict:
        try:
            payload = json.dumps({
                "text": title,
                "blocks": blocks,
                "username": self.username,
                "icon_emoji": self.icon_emoji
            }).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok", "format": "blocks"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}


class TelegramChannel(BaseChannel):
    name = "telegram"

    def __init__(self, bot_token: str, chat_id: str,
                 parse_mode: str = "HTML", disable_preview: bool = False):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.parse_mode = parse_mode
        self.disable_preview = disable_preview

    def send(self, message: str, title: str = "") -> dict:
        try:
            text = f"<b>{title}</b>\n{message}" if title else message
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            payload = json.dumps({
                "chat_id": self.chat_id,
                "text": text,
                "parse_mode": self.parse_mode,
                "disable_web_page_preview": self.disable_preview
            }).encode("utf-8")
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}

    def send_photo(self, photo_url: str, caption: str = "") -> dict:
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/sendPhoto"
            payload = json.dumps({
                "chat_id": self.chat_id,
                "photo": photo_url,
                "caption": caption
            }).encode("utf-8")
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok", "format": "photo"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}

    def send_document(self, document_url: str, caption: str = "") -> dict:
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/sendDocument"
            payload = json.dumps({
                "chat_id": self.chat_id,
                "document": document_url,
                "caption": caption
            }).encode("utf-8")
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok", "format": "document"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}

    def send_poll(self, question: str, options: list) -> dict:
        try:
            url = f"https://api.telegram.org/bot{self.bot_token}/sendPoll"
            payload = json.dumps({
                "chat_id": self.chat_id,
                "question": question,
                "options": options
            }).encode("utf-8")
            req = urllib.request.Request(
                url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok", "format": "poll"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}


class DiscordChannel(BaseChannel):
    name = "discord"

    def __init__(self, webhook_url: str, username: str = "notifyall", avatar_url: str = ""):
        self.webhook_url = webhook_url
        self.username = username
        self.avatar_url = avatar_url

    def send(self, message: str, title: str = "") -> dict:
        try:
            content = f"**{title}**\n{message}" if title else message
            data = {"content": content, "username": self.username}
            if self.avatar_url:
                data["avatar_url"] = self.avatar_url
            payload = json.dumps(data).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}

    def send_embed(self, title: str, description: str,
                   color: int = 0x00b4d8, fields: list = None,
                   footer: str = "", thumbnail_url: str = "") -> dict:
        try:
            embed = {"title": title, "description": description, "color": color}
            if fields:
                embed["fields"] = fields
            if footer:
                embed["footer"] = {"text": footer}
            if thumbnail_url:
                embed["thumbnail"] = {"url": thumbnail_url}
            data = {"username": self.username, "embeds": [embed]}
            if self.avatar_url:
                data["avatar_url"] = self.avatar_url
            payload = json.dumps(data).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok", "format": "embed"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}


class WhatsAppChannel(BaseChannel):
    name = "whatsapp"

    def __init__(self, account_sid: str, auth_token: str, from_number: str, to_number: str):
        self.account_sid = account_sid
        self.auth_token = auth_token
        self.from_number = from_number
        self.to_number = to_number

    def send(self, message: str, title: str = "") -> dict:
        try:
            text = f"{title}\n{message}" if title else message
            url = f"https://api.twilio.com/2010-04-01/Accounts/{self.account_sid}/Messages.json"
            data = urllib.parse.urlencode({
                "From": self.from_number, "To": self.to_number, "Body": text
            }).encode("utf-8")
            creds = base64.b64encode(f"{self.account_sid}:{self.auth_token}".encode()).decode()
            req = urllib.request.Request(url, data=data, headers={"Authorization": f"Basic {creds}"})
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}


class TeamsChannel(BaseChannel):
    name = "teams"

    def __init__(self, webhook_url: str):
        self.webhook_url = webhook_url

    def send(self, message: str, title: str = "") -> dict:
        try:
            payload = json.dumps({
                "@type": "MessageCard",
                "@context": "http://schema.org/extensions",
                "summary": title or message,
                "themeColor": "0076D7",
                "title": title,
                "text": message
            }).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}

    def send_card(self, title: str, message: str, facts: list = None, color: str = "0076D7") -> dict:
        try:
            sections = [{"facts": facts}] if facts else []
            payload = json.dumps({
                "@type": "MessageCard",
                "@context": "http://schema.org/extensions",
                "themeColor": color,
                "summary": title,
                "sections": [{"activityTitle": title, "activityText": message}] + sections
            }).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok", "format": "card"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}


class PushoverChannel(BaseChannel):
    name = "pushover"
    PRIORITY_LOW = -1
    PRIORITY_NORMAL = 0
    PRIORITY_HIGH = 1

    def __init__(self, app_token: str, user_key: str, priority: int = 0, sound: str = "pushover"):
        self.app_token = app_token
        self.user_key = user_key
        self.priority = priority
        self.sound = sound

    def send(self, message: str, title: str = "") -> dict:
        try:
            data = urllib.parse.urlencode({
                "token": self.app_token,
                "user": self.user_key,
                "message": message,
                "title": title or "notifyall",
                "priority": self.priority,
                "sound": self.sound
            }).encode("utf-8")
            req = urllib.request.Request("https://api.pushover.net/1/messages.json", data=data)
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}


class NtfyChannel(BaseChannel):
    name = "ntfy"

    def __init__(self, topic: str, server: str = "https://ntfy.sh", priority: str = "default"):
        self.topic = topic
        self.server = server.rstrip("/")
        self.priority = priority

    def send(self, message: str, title: str = "") -> dict:
        try:
            url = f"{self.server}/{self.topic}"
            headers = {"Content-Type": "text/plain", "Priority": self.priority}
            if title:
                headers["Title"] = title
            req = urllib.request.Request(url, data=message.encode("utf-8"), headers=headers)
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}


class MattermostChannel(BaseChannel):
    name = "mattermost"

    def __init__(self, webhook_url: str, channel: str = "", username: str = "notifyall"):
        self.webhook_url = webhook_url
        self.channel = channel
        self.username = username

    def send(self, message: str, title: str = "") -> dict:
        try:
            text = f"**{title}**\n{message}" if title else message
            data = {"text": text, "username": self.username}
            if self.channel:
                data["channel"] = self.channel
            payload = json.dumps(data).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}


class RocketChatChannel(BaseChannel):
    name = "rocketchat"

    def __init__(self, webhook_url: str, alias: str = "notifyall", emoji: str = ":bell:"):
        self.webhook_url = webhook_url
        self.alias = alias
        self.emoji = emoji

    def send(self, message: str, title: str = "") -> dict:
        try:
            text = f"**{title}**\n{message}" if title else message
            payload = json.dumps({
                "text": text,
                "alias": self.alias,
                "emoji": self.emoji
            }).encode("utf-8")
            req = urllib.request.Request(
                self.webhook_url, data=payload,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10):
                return {"channel": self.name, "status": "ok"}
        except Exception as e:
            return {"channel": self.name, "status": "error", "error": str(e)}