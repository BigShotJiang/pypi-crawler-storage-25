import time
import threading
from typing import List, Optional, Dict, Callable
from .channels import BaseChannel


class Notifier:
    def __init__(self, default_title: str = ""):
        self._channels: List[BaseChannel] = []
        self._history: List[dict] = []
        self._hooks: Dict[str, List[Callable]] = {"before": [], "after": [], "error": []}
        self.default_title = default_title

    def add(self, channel: BaseChannel) -> "Notifier":
        self._channels.append(channel)
        return self

    def remove(self, channel: BaseChannel) -> "Notifier":
        self._channels = [c for c in self._channels if c is not channel]
        return self

    def on(self, event: str, callback: Callable) -> "Notifier":
        if event in self._hooks:
            self._hooks[event].append(callback)
        return self

    def _trigger(self, event: str, **kwargs):
        for fn in self._hooks.get(event, []):
            try:
                fn(**kwargs)
            except Exception:
                pass

    def notify(self, message: str, title: str = "") -> List[dict]:
        if not self._channels:
            raise RuntimeError("Aucun canal configuré. Utilisez .add() d'abord.")
        t = title or self.default_title
        self._trigger("before", message=message, title=t)
        results = [ch.send(message, t) for ch in self._channels]
        self._trigger("after", message=message, title=t, results=results)
        for r in results:
            if r and r.get("status") == "error":
                self._trigger("error", result=r)
        self._save_history(message, t, results)
        return results

    def notify_parallel(self, message: str, title: str = "") -> List[dict]:
        if not self._channels:
            raise RuntimeError("Aucun canal configuré. Utilisez .add() d'abord.")
        t = title or self.default_title
        results = [None] * len(self._channels)

        def _send(index, channel):
            results[index] = channel.send(message, t)

        threads = [threading.Thread(target=_send, args=(i, ch)) for i, ch in enumerate(self._channels)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()

        self._save_history(message, t, results)
        return results

    def notify_one(self, channel_name: str, message: str, title: str = "") -> Optional[dict]:
        for ch in self._channels:
            if type(ch).__name__.lower().startswith(channel_name.lower()):
                return ch.send(message, title or self.default_title)
        return None

    def notify_template(self, template: str, **kwargs) -> List[dict]:
        return self.notify(template.format(**kwargs))

    def notify_if(self, condition: bool, message: str, title: str = "") -> Optional[List[dict]]:
        if condition:
            return self.notify(message, title)
        return None

    def notify_level(self, level: str, message: str) -> List[dict]:
        icons = {"info": "ℹ️", "success": "✅", "warning": "⚠️", "error": "❌", "critical": "🚨"}
        icon = icons.get(level.lower(), "🔔")
        return self.notify(f"{icon} {message}", title=level.upper())

    def notify_scheduled(self, message: str, title: str = "", delay_seconds: float = 0) -> None:
        def _delayed():
            if delay_seconds > 0:
                time.sleep(delay_seconds)
            self.notify(message, title)
        threading.Thread(target=_delayed, daemon=True).start()

    def notify_repeat(self, message: str, title: str = "", times: int = 1, interval: float = 60.0) -> None:
        def _repeat():
            for _ in range(times):
                self.notify(message, title)
                if _ < times - 1:
                    time.sleep(interval)
        threading.Thread(target=_repeat, daemon=True).start()

    def _save_history(self, message: str, title: str, results: list):
        self._history.append({
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "title": title,
            "message": message,
            "results": results
        })

    @property
    def history(self) -> List[dict]:
        return self._history.copy()

    def clear_history(self) -> None:
        self._history.clear()

    def failed_notifications(self) -> List[dict]:
        return [
            h for h in self._history
            if any(r and r.get("status") == "error" for r in h["results"])
        ]

    def stats(self) -> dict:
        total = sum(len(h["results"]) for h in self._history)
        success = sum(
            1 for h in self._history for r in h["results"]
            if r and r.get("status") == "ok"
        )
        errors = total - success
        return {
            "total_sends": total,
            "success": success,
            "errors": errors,
            "success_rate": f"{(success/total*100):.1f}%" if total > 0 else "N/A",
            "notifications_sent": len(self._history),
            "channels_configured": self.channel_count
        }

    def export_history(self, filepath: str) -> None:
        import json
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(self._history, f, ensure_ascii=False, indent=2)

    @property
    def channel_count(self) -> int:
        return len(self._channels)

    def __repr__(self) -> str:
        return f"Notifier(channels={[type(c).__name__ for c in self._channels]})"