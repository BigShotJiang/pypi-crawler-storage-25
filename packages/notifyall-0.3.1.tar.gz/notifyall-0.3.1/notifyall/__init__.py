from .core import Notifier
from .channels import (
    EmailChannel,
    SlackChannel,
    TelegramChannel,
    DiscordChannel,
    WhatsAppChannel,
    TeamsChannel,
    PushoverChannel,
    NtfyChannel,
    MattermostChannel,
    RocketChatChannel,
)

__version__ = "0.3.0"
__all__ = [
    "Notifier",
    "EmailChannel",
    "SlackChannel",
    "TelegramChannel",
    "DiscordChannel",
    "WhatsAppChannel",
    "TeamsChannel",
    "PushoverChannel",
    "NtfyChannel",
    "MattermostChannel",
    "RocketChatChannel",
]