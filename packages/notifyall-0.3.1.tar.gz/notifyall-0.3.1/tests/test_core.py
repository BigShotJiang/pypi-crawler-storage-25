import pytest
from notifyall import Notifier
from notifyall.channels import BaseChannel


class MockChannel(BaseChannel):
    def __init__(self, name="mock"):
        self.name = name
        self.calls = []

    def send(self, message, title=""):
        self.calls.append({"message": message, "title": title})
        return {"channel": self.name, "status": "ok"}


def test_add_channel():
    n = Notifier()
    n.add(MockChannel())
    assert n.channel_count == 1

def test_chaining():
    n = Notifier()
    result = n.add(MockChannel("a")).add(MockChannel("b"))
    assert isinstance(result, Notifier)
    assert n.channel_count == 2

def test_notify_all():
    ch1 = MockChannel("slack")
    ch2 = MockChannel("telegram")
    n = Notifier()
    n.add(ch1).add(ch2)
    results = n.notify("Hello", title="Test")
    assert len(results) == 2
    assert results[0]["channel"] == "slack"
    assert results[1]["channel"] == "telegram"
    assert ch1.calls[0]["message"] == "Hello"
    assert ch1.calls[0]["title"] == "Test"

def test_notify_no_channel_raises():
    with pytest.raises(RuntimeError):
        Notifier().notify("test")

def test_notify_one():
    ch1 = MockChannel("SlackChannel")
    ch2 = MockChannel("TelegramChannel")
    n = Notifier()
    n.add(ch1).add(ch2)
    result = n.notify_one("slack", "message ciblé")
    assert result["channel"] == "SlackChannel"
    assert len(ch2.calls) == 0

def test_remove():
    ch = MockChannel()
    n = Notifier()
    n.add(ch).remove(ch)
    assert n.channel_count == 0

def test_repr():
    n = Notifier()
    n.add(MockChannel())
    assert "MockChannel" in repr(n)