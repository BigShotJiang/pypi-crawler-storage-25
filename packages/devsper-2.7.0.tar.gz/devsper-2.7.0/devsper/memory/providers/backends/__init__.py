"""Concrete MemoryBackend implementations."""
