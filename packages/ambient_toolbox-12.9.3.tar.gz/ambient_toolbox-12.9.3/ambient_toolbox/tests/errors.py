class TestSetupConfigurationError(RuntimeError):
    pass
