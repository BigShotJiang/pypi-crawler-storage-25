"""Phase 4 — Python client for the hybrid X25519 + ML-KEM-768 KEM.

Mirrors `cai_auth_core::crypto::hybrid_kem` byte-for-byte so that an
ephemeral public key generated here can be encapsulated-to by the Rust
server, and the returned ciphertext decapsulated back into the same
32-byte shared secret the server computed.

### Wire format

Two independent byte blobs per direction:

* Client → server (in ``ChallengeVerifyRequest``):
    * ``kem_ephemeral_pk_x``  — 32 B X25519 public key
    * ``kem_ephemeral_pk_pq`` — 1184 B ML-KEM-768 encapsulation key
* Server → client (in ``ChallengeVerifyResponse``):
    * ``kem_ciphertext_x``  — 32 B X25519 ephemeral public key
    * ``kem_ciphertext_pq`` — 1088 B ML-KEM-768 ciphertext

### Shared-secret derivation

Both sides compute the same 32-byte secret:

    ss = SHA-256(
        b"CAI-AUTH/hybrid-kem/v1"
        || x25519_dh(eph_sk, peer_pk)   -- 32 B
        || ml_kem_768_dk.decap(pq_ct)   -- 32 B
        || eph_pk                       -- 32 B (sender's X25519 pub)
        || pq_ct                        -- 1088 B
    )

This mirrors Cloudflare's transcript-bound combiner: the classical and
PQ halves are hashed together with the transcript material so a broken
combine-XOR construction can't drop IND-CCA2.

### Optional dependencies

Install the SDK with the ``hybrid-kem`` extra to pull in ``quantcrypt``
(ML-KEM-768) and ``cryptography`` (X25519):

.. code-block:: bash

    pip install 'cai-auth-sdk[hybrid-kem]'
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from typing import Any

# Lazy imports so the SDK can be imported on Python environments that do
# not have the PQ / classical crypto extras installed — only the
# functions below will fail, with a clear install hint.
try:  # pragma: no cover - exercised by install-time presence
    from cryptography.hazmat.primitives.asymmetric.x25519 import (
        X25519PrivateKey,
        X25519PublicKey,
    )
    from cryptography.hazmat.primitives.serialization import (
        Encoding,
        PublicFormat,
    )
    from quantcrypt.kem import MLKEM_768

    _HAS_DEPS = True
except ImportError:  # pragma: no cover
    _HAS_DEPS = False


# ---- Constants — must stay in sync with cai_auth_core::crypto::hybrid_kem.

#: Length of the shared secret (bytes).
HYBRID_SS_LEN = 32

#: Length of an X25519 public key (bytes).
X25519_PK_LEN = 32

#: Length of an ML-KEM-768 encapsulation key (bytes, per FIPS 203).
MLKEM768_EK_LEN = 1184

#: Length of an ML-KEM-768 ciphertext (bytes, per FIPS 203).
MLKEM768_CT_LEN = 1088

#: Domain-separation label for the transcript-bound combiner.
_COMBINE_LABEL = b"CAI-AUTH/hybrid-kem/v1"


def _require_deps() -> None:
    if not _HAS_DEPS:
        raise RuntimeError(
            "cai_auth_sdk.hybrid_kem requires the 'hybrid-kem' extras. "
            "Install with: pip install 'cai-auth-sdk[hybrid-kem]'"
        )


# ---- Keypair / ciphertext container types.


@dataclass(frozen=True, slots=True)
class HybridKemKeypair:
    """Ephemeral keypair — callers keep the secret halves on the stack
    and drop them as soon as decapsulation is done.

    The public halves (:attr:`x_pk_bytes`, :attr:`pq_pk_bytes`) are what
    goes on the wire to the server.
    """

    x_sk: "X25519PrivateKey"
    x_pk_bytes: bytes
    pq_sk_bytes: bytes
    pq_pk_bytes: bytes


@dataclass(frozen=True, slots=True)
class HybridKemCiphertext:
    """Wire-form KEM ciphertext (the server's reply)."""

    x_pk_bytes: bytes
    pq_ct_bytes: bytes


# ---- Public API.


def generate_ephemeral_keypair() -> HybridKemKeypair:
    """Generate a fresh hybrid KEM keypair (X25519 + ML-KEM-768).

    The secret halves live in memory only for the duration of one
    challenge/verify round-trip — the client is expected to discard the
    :class:`HybridKemKeypair` immediately after :func:`decapsulate`
    returns, achieving forward secrecy for the derived session token.
    """
    _require_deps()

    # Classical half — X25519.
    x_sk = X25519PrivateKey.generate()
    x_pk_bytes = x_sk.public_key().public_bytes(
        Encoding.Raw, PublicFormat.Raw
    )
    assert len(x_pk_bytes) == X25519_PK_LEN

    # Post-quantum half — ML-KEM-768 via quantcrypt.
    mlkem = MLKEM_768()
    pq_pk_bytes, pq_sk_bytes = mlkem.keygen()
    assert len(pq_pk_bytes) == MLKEM768_EK_LEN, (
        f"ML-KEM-768 ek length {len(pq_pk_bytes)} != {MLKEM768_EK_LEN}"
    )

    return HybridKemKeypair(
        x_sk=x_sk,
        x_pk_bytes=bytes(x_pk_bytes),
        pq_sk_bytes=bytes(pq_sk_bytes),
        pq_pk_bytes=bytes(pq_pk_bytes),
    )


def decapsulate(
    keypair: HybridKemKeypair,
    ciphertext: HybridKemCiphertext,
) -> bytes:
    """Derive the 32-byte hybrid shared secret from the server's KEM reply.

    Validates the wire-format lengths up front, runs the classical and PQ
    halves independently, then feeds both DH outputs + the full
    transcript material into SHA-256 using the same domain-separation
    label as the Rust server.
    """
    _require_deps()

    if len(ciphertext.x_pk_bytes) != X25519_PK_LEN:
        raise ValueError(
            f"kem_ciphertext_x length {len(ciphertext.x_pk_bytes)} "
            f"!= {X25519_PK_LEN}"
        )
    if len(ciphertext.pq_ct_bytes) != MLKEM768_CT_LEN:
        raise ValueError(
            f"kem_ciphertext_pq length {len(ciphertext.pq_ct_bytes)} "
            f"!= {MLKEM768_CT_LEN}"
        )

    # Classical half — DH between our ephemeral secret and server's pub.
    peer_x_pk = X25519PublicKey.from_public_bytes(ciphertext.x_pk_bytes)
    x_ss: bytes = keypair.x_sk.exchange(peer_x_pk)

    # Post-quantum half — decapsulate server's ciphertext with our ML-KEM
    # secret key.
    mlkem = MLKEM_768()
    pq_ss = mlkem.decaps(keypair.pq_sk_bytes, ciphertext.pq_ct_bytes)

    return _combine(
        x_ss,
        bytes(pq_ss),
        ciphertext.x_pk_bytes,
        ciphertext.pq_ct_bytes,
    )


def _combine(
    x_ss: bytes, pq_ss: bytes, x_pk: bytes, pq_ct: bytes
) -> bytes:
    """Transcript-bound SHA-256 combiner. Must match
    ``cai_auth_core::crypto::hybrid_kem::combine`` byte-for-byte.
    """
    h = hashlib.sha256()
    h.update(_COMBINE_LABEL)
    h.update(x_ss)
    h.update(pq_ss)
    h.update(x_pk)
    h.update(pq_ct)
    out = h.digest()
    assert len(out) == HYBRID_SS_LEN
    return out
