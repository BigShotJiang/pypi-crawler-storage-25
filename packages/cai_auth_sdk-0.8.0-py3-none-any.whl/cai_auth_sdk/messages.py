"""Pydantic v2 models for every CAI-AUTH CBOR envelope in the 0.2.0 spec.

Each model's field names match the Rust server's serde field names
byte-for-byte (snake_case). `bytes` is used for every `ByteBuf` field so
that round-tripping through the canonical CBOR codec is lossless.

The server's request/response shapes are **not always symmetrical** —
for example `POST /v1/enroll/complete` takes an `EnrollComplete` envelope
but returns an `EnrollAck` (a 3-field acknowledgement), not another
`EnrollResponse`. The models here follow the *wire* shapes from
`cai-auth-server/src/routes/*.rs`, not the logical names from
`cai-auth-core/src/protocol/messages.rs`.
"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------- helpers ----------


class _Strict(BaseModel):
    """All SDK models forbid unknown fields and coerce on demand."""

    model_config = ConfigDict(extra="forbid", arbitrary_types_allowed=True)


# ---------- /health ----------


class HealthResponse(_Strict):
    """JSON body from `GET /health`."""

    status: str
    version: str
    uptime_secs: int


# ---------- enroll ----------


class EnrollBeginRequest(_Strict):
    """Body of `POST /v1/enroll/begin` — matches `EnrollBegin` in core."""

    version: int
    user_handle: bytes
    rp_id: str
    origin: str
    client_caps: int
    timestamp_ms: int


class EnrollBeginResponse(_Strict):
    """Response from `/v1/enroll/begin` — matches `EnrollResponse` in core."""

    version: int
    challenge: bytes
    challenge_id: bytes
    attestation_nonce: bytes
    alg_list: list[int]
    timeout_ms: int
    rp_id: str


class DeviceInfo(_Strict):
    """Embedded in `EnrollCompleteRequest`."""

    model: str
    os: str
    strongbox: bool


class EnrollCompleteRequest(_Strict):
    """Body of `POST /v1/enroll/complete` — matches `EnrollComplete` in core."""

    version: int
    challenge_id: bytes
    credential_id: bytes
    pk_hybrid: bytes
    attestation_cert_chain: list[bytes]
    client_data_json: bytes
    auth_data: bytes
    sig_hybrid: bytes
    device_info: DeviceInfo
    # Phase 4b — SEC1-uncompressed ECDSA-P256 public key (65 B) minted
    # in Android Keystore with setUserConfirmationRequired(true). Used
    # by the server to verify Protected Confirmation signatures on
    # later high-risk challenge responses.
    confirmation_pk: Optional[bytes] = None
    # Phase 4c — DER-encoded X.509 Key Attestation chain for the
    # confirmation_pk. Empty list on devices without attestation.
    confirmation_attestation_chain: list[bytes] = Field(default_factory=list)


class EnrollCompleteResponse(_Strict):
    """Server's `EnrollAck` reply — 3 fields."""

    version: int
    status: int
    credential_id: bytes


# ---------- challenge ----------


class ChallengeCreateRequest(_Strict):
    """Body of `POST /v1/challenge/create` — server's `ChallengeCreateReq`."""

    version: int
    user_handle: bytes
    rp_id: str
    origin: str
    action: Optional[str] = None


class ChallengeCreateResponse(_Strict):
    """Response from `/v1/challenge/create` — matches `ChallengeCreate` in core."""

    version: int
    challenge: bytes
    challenge_id: bytes
    timestamp_ms: int
    ttl_ms: int
    rp_id: str
    origin: str
    allowed_credentials: list[bytes] = Field(default_factory=list)
    action: Optional[str] = None
    alg_list: list[int] = Field(default_factory=list)


class ChallengeVerifyRequest(_Strict):
    """Body of `POST /v1/challenge/verify` — matches `ChallengeResponse` in core."""

    version: int
    challenge_id: bytes
    credential_id: bytes
    auth_data: bytes
    client_data_json: bytes
    sig_hybrid: bytes
    user_handle: Optional[bytes] = None
    # Phase 4 forward-secrecy — ephemeral hybrid KEM public key halves.
    # When both are supplied, the server encapsulates to them and uses
    # the resulting shared secret as the HKDF IKM for the session token.
    kem_ephemeral_pk_x: Optional[bytes] = None
    kem_ephemeral_pk_pq: Optional[bytes] = None
    # Phase 4b Action-Visible Confirmation — TEE-attested prompt bytes
    # + ECDSA-P256 signature for high-risk challenges.
    action_confirmation_blob: Optional[bytes] = None
    action_confirmation_sig: Optional[bytes] = None
    # Phase 5 (experimental) — Continuous Behavioural Binding hash.
    # Server logs these for model training; enforcement is deferred.
    behavioral_hash: Optional[bytes] = None
    behavioral_version: Optional[int] = None
    # Phase 5b — raw 16-float feature vector (opt-in). Server uses
    # it to score Mahalanobis distance against the per-credential
    # reference and then discards it; only the hash is persisted.
    behavioral_features: Optional[list[float]] = None


class ChallengeVerifyResponse(_Strict):
    """Server's `VerifyResp` reply from `/v1/challenge/verify`."""

    version: int
    status: int
    user_handle: bytes
    sign_count: int
    session_token: bytes
    expires_at: int
    # Phase 4 forward-secrecy — present iff the client sent the
    # ephemeral KEM pub halves. Clients decapsulate with their stashed
    # ephemeral secret to derive the same HKDF IKM the server used.
    kem_ciphertext_x: Optional[bytes] = None
    kem_ciphertext_pq: Optional[bytes] = None
    # 1 = session token derived from hybrid KEM shared secret
    # (forward-secret), 0 = legacy nonce-based derivation.
    fs_kem: int = 0


# ---------- recovery ----------


class RecoveryBeginRequest(_Strict):
    version: int
    user_handle: bytes
    initiator_proof: bytes
    timestamp_ms: int


class RecoveryBeginResponse(_Strict):
    """Shape used by `POST /v1/recovery/begin` — server returns an ack with the
    freshly created session ID and the timelock expiry.
    """

    version: int
    status: int
    recovery_session_id: bytes
    timelock_expires_at: int


class RecoverySubmitShardRequest(_Strict):
    version: int
    recovery_session_id: bytes
    shard_id: int
    shard_ciphertext: bytes
    guardian_signature: bytes


class RecoverySubmitShardResponse(_Strict):
    version: int
    status: int
    shards_received: int


class RecoveryCompleteRequest(_Strict):
    version: int
    recovery_session_id: bytes
    new_credential: EnrollCompleteRequest
    timelock_proof: bytes


class RecoveryCompleteResponse(_Strict):
    version: int
    status: int
    credential_id: bytes


# ---------- revoke ----------


class RevokeRequest(_Strict):
    version: int
    credential_id: bytes
    reason: int
    sig_hybrid: bytes
    timestamp_ms: int


class RevokeResponse(_Strict):
    version: int
    status: int
    credential_id: bytes


# ---------- audit ----------


class AuditEvent(_Strict):
    id: int
    event_type: str
    rp_id: str
    timestamp_micros: int
    hash_self: bytes
    prev_hash: Optional[bytes] = None
    credential_id: Optional[bytes] = None
    origin: Optional[str] = None
    metadata: Optional[dict] = None


class AuditResponse(_Strict):
    """JSON body from `GET /v1/audit`."""

    events: list[AuditEvent]
    merkle_ok: bool
