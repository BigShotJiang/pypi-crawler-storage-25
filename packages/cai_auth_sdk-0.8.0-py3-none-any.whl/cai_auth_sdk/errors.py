"""Typed exception hierarchy for CAI-AUTH server responses.

The SDK raises a subclass of :class:`CaiAuthError` for every documented
protocol-level error (per spec §7). Network, DNS, TLS and timeout errors
surface as :class:`TransportError`. Anything else — including unexpected
2xx bodies — raises :class:`ServerError` so the caller can log and
continue.
"""

from __future__ import annotations


class CaiAuthError(Exception):
    """Base class for every error raised by the SDK."""

    def __init__(self, message: str, *, http_status: int | None = None, code: str | None = None) -> None:
        super().__init__(message)
        self.http_status = http_status
        self.code = code


class TransportError(CaiAuthError):
    """Network, DNS, TLS, or timeout failure — did not reach the server."""


class ServerError(CaiAuthError):
    """Unexpected or malformed server response."""


# ---------- Protocol-level errors per spec §7 ----------


class InvalidSignatureError(CaiAuthError):
    """HTTP 401 — Ed25519 and/or ML-DSA-65 signature verification failed."""


class CloneDetectedError(CaiAuthError):
    """HTTP 403 — sign_count regressed; possible authenticator cloning."""


class ReusedChallengeError(CaiAuthError):
    """HTTP 409 — the challenge was already consumed."""


class ExpiredChallengeError(CaiAuthError):
    """HTTP 410 — challenge TTL elapsed before the caller submitted it."""


class RecoveryTimelockActiveError(CaiAuthError):
    """HTTP 425 — 48h recovery timelock is still running, cannot complete."""


# HTTP status → error class map used by the client to route failures.
HTTP_STATUS_TO_ERROR: dict[int, type[CaiAuthError]] = {
    401: InvalidSignatureError,
    403: CloneDetectedError,
    409: ReusedChallengeError,
    410: ExpiredChallengeError,
    425: RecoveryTimelockActiveError,
}
