"""Canonical CBOR encode/decode for the CAI-AUTH wire format.

The server uses deterministic, canonical CBOR (RFC 8949 §4.2.1) for
every body to keep BLAKE3 hashes reproducible across implementations.
This module centralises those settings so every request sent by the SDK
matches byte-for-byte what the server signs over.
"""

from __future__ import annotations

from typing import Any

import cbor2


def encode(obj: Any) -> bytes:
    """Serialise `obj` to canonical CBOR bytes."""
    return cbor2.dumps(obj, canonical=True)


def decode(data: bytes) -> Any:
    """Deserialise canonical CBOR bytes back into Python objects."""
    return cbor2.loads(data)
