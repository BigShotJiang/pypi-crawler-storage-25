"""CAI-AUTH Python SDK.

Pure-Python async client for the CAI-AUTH server protocol (v0.2.0). All
eleven endpoints in the `cai-auth-server` OpenAPI surface are exposed
through :class:`CaiAuthClient`, with pydantic v2 models for every
request and response and a single canonical CBOR codec.
"""

from . import hybrid_kem
from .client import CaiAuthClient
from .errors import (
    CaiAuthError,
    CloneDetectedError,
    ExpiredChallengeError,
    InvalidSignatureError,
    RecoveryTimelockActiveError,
    ReusedChallengeError,
    ServerError,
    TransportError,
)
from .messages import (
    ChallengeCreateRequest,
    ChallengeCreateResponse,
    ChallengeVerifyRequest,
    ChallengeVerifyResponse,
    EnrollBeginRequest,
    EnrollBeginResponse,
    EnrollCompleteRequest,
    EnrollCompleteResponse,
    HealthResponse,
)

__all__ = [
    "CaiAuthClient",
    "CaiAuthError",
    "CloneDetectedError",
    "ExpiredChallengeError",
    "InvalidSignatureError",
    "RecoveryTimelockActiveError",
    "ReusedChallengeError",
    "ServerError",
    "TransportError",
    "ChallengeCreateRequest",
    "ChallengeCreateResponse",
    "ChallengeVerifyRequest",
    "ChallengeVerifyResponse",
    "EnrollBeginRequest",
    "EnrollBeginResponse",
    "EnrollCompleteRequest",
    "EnrollCompleteResponse",
    "HealthResponse",
    "hybrid_kem",
]

__version__ = "0.7.8"
