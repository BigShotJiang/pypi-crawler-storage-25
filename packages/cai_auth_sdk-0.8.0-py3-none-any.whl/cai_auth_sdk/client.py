"""Async HTTP client for the CAI-AUTH server.

Every method below:

1. Serialises its request model with canonical CBOR (for CBOR routes) or
   ``httpx``'s default JSON (for the plain-JSON routes `/health` and
   `/v1/audit`).
2. Sends the body with the correct ``Content-Type`` and ``Accept``
   headers.
3. Routes non-2xx responses to a typed exception via
   :mod:`cai_auth_sdk.errors`.
4. Parses the response body with the matching pydantic model.

The client is async-first (``httpx.AsyncClient``) because the primary
consumer, the CAI Hub gateway, is FastAPI. A synchronous counterpart can
be added in a follow-up if needed.
"""

from __future__ import annotations

from types import TracebackType
from typing import Any, Type

import httpx

from . import cbor as _cbor
from .errors import (
    CaiAuthError,
    HTTP_STATUS_TO_ERROR,
    ServerError,
    TransportError,
)
from .messages import (
    AuditResponse,
    ChallengeCreateRequest,
    ChallengeCreateResponse,
    ChallengeVerifyRequest,
    ChallengeVerifyResponse,
    EnrollBeginRequest,
    EnrollBeginResponse,
    EnrollCompleteRequest,
    EnrollCompleteResponse,
    HealthResponse,
    RecoveryBeginRequest,
    RecoveryBeginResponse,
    RecoveryCompleteRequest,
    RecoveryCompleteResponse,
    RecoverySubmitShardRequest,
    RecoverySubmitShardResponse,
    RevokeRequest,
    RevokeResponse,
)

CBOR_MIME = "application/cbor"
JSON_MIME = "application/json"
DEFAULT_TIMEOUT_SECONDS = 10.0


class CaiAuthClient:
    """Async client for the CAI-AUTH server v0.2.0."""

    def __init__(
        self,
        base_url: str,
        *,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        if not base_url.startswith(("http://", "https://")):
            raise ValueError(
                f"base_url must start with http:// or https:// (got {base_url!r})"
            )
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            transport=transport,
        )

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "CaiAuthClient":
        return self

    async def __aexit__(
        self,
        exc_type: Type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._client.aclose()

    # ------------------------------------------------------------------
    # Internal plumbing
    # ------------------------------------------------------------------

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if 200 <= resp.status_code < 300:
            return
        body = resp.text[:500] if resp.content else ""
        err_cls = HTTP_STATUS_TO_ERROR.get(resp.status_code, ServerError)
        raise err_cls(
            f"{resp.request.method} {resp.request.url} -> {resp.status_code}: {body}",
            http_status=resp.status_code,
        )

    async def _cbor_post(
        self,
        path: str,
        body_model: Any,
        response_cls: Type[Any],
    ) -> Any:
        payload = _cbor.encode(body_model.model_dump(mode="python"))
        try:
            resp = await self._client.post(
                path,
                content=payload,
                headers={
                    "Content-Type": CBOR_MIME,
                    "Accept": CBOR_MIME,
                },
            )
        except httpx.HTTPError as e:
            raise TransportError(f"{path}: {e}") from e

        self._raise_for_status(resp)

        content_type = resp.headers.get("Content-Type", "").lower()
        if CBOR_MIME not in content_type:
            raise ServerError(
                f"{path}: expected Content-Type: {CBOR_MIME}, got {content_type!r}",
                http_status=resp.status_code,
            )
        try:
            decoded = _cbor.decode(resp.content)
        except Exception as e:  # pragma: no cover - ciborium errors
            raise ServerError(f"{path}: cbor decode failed: {e}") from e
        try:
            return response_cls.model_validate(decoded)
        except Exception as e:
            raise ServerError(
                f"{path}: unexpected response shape: {e}",
                http_status=resp.status_code,
            ) from e

    async def _json_get(self, path: str, response_cls: Type[Any]) -> Any:
        try:
            resp = await self._client.get(path, headers={"Accept": JSON_MIME})
        except httpx.HTTPError as e:
            raise TransportError(f"{path}: {e}") from e
        self._raise_for_status(resp)
        try:
            return response_cls.model_validate(resp.json())
        except Exception as e:
            raise ServerError(f"{path}: unexpected response shape: {e}") from e

    # ------------------------------------------------------------------
    # Public methods — 11 endpoints
    # ------------------------------------------------------------------

    async def health(self) -> HealthResponse:
        """``GET /health`` — liveness probe."""
        return await self._json_get("/health", HealthResponse)

    async def metrics(self) -> str:
        """``GET /metrics`` — Prometheus text exposition."""
        try:
            resp = await self._client.get(
                "/metrics", headers={"Accept": "text/plain"}
            )
        except httpx.HTTPError as e:
            raise TransportError(f"/metrics: {e}") from e
        self._raise_for_status(resp)
        return resp.text

    async def enroll_begin(self, req: EnrollBeginRequest) -> EnrollBeginResponse:
        """``POST /v1/enroll/begin`` — start enrollment."""
        return await self._cbor_post("/v1/enroll/begin", req, EnrollBeginResponse)

    async def enroll_complete(
        self, req: EnrollCompleteRequest
    ) -> EnrollCompleteResponse:
        """``POST /v1/enroll/complete`` — finalise enrollment with PoP."""
        return await self._cbor_post(
            "/v1/enroll/complete", req, EnrollCompleteResponse
        )

    async def challenge_create(
        self, req: ChallengeCreateRequest
    ) -> ChallengeCreateResponse:
        """``POST /v1/challenge/create`` — emit a challenge for an existing user."""
        return await self._cbor_post(
            "/v1/challenge/create", req, ChallengeCreateResponse
        )

    async def challenge_verify(
        self, req: ChallengeVerifyRequest
    ) -> ChallengeVerifyResponse:
        """``POST /v1/challenge/verify`` — check a signature and mint a session."""
        return await self._cbor_post(
            "/v1/challenge/verify", req, ChallengeVerifyResponse
        )

    async def recovery_begin(
        self, req: RecoveryBeginRequest
    ) -> RecoveryBeginResponse:
        """``POST /v1/recovery/begin`` — open 48h recovery window."""
        return await self._cbor_post("/v1/recovery/begin", req, RecoveryBeginResponse)

    async def recovery_submit_shard(
        self, req: RecoverySubmitShardRequest
    ) -> RecoverySubmitShardResponse:
        """``POST /v1/recovery/submit-shard`` — guardian submits a Shamir share."""
        return await self._cbor_post(
            "/v1/recovery/submit-shard", req, RecoverySubmitShardResponse
        )

    async def recovery_complete(
        self, req: RecoveryCompleteRequest
    ) -> RecoveryCompleteResponse:
        """``POST /v1/recovery/complete`` — finalise after timelock."""
        return await self._cbor_post(
            "/v1/recovery/complete", req, RecoveryCompleteResponse
        )

    async def revoke(self, req: RevokeRequest) -> RevokeResponse:
        """``POST /v1/revoke`` — revoke a credential."""
        return await self._cbor_post("/v1/revoke", req, RevokeResponse)

    async def audit(self) -> AuditResponse:
        """``GET /v1/audit`` — Merkle-chained audit log."""
        return await self._json_get("/v1/audit", AuditResponse)


__all__ = ["CaiAuthClient"]
