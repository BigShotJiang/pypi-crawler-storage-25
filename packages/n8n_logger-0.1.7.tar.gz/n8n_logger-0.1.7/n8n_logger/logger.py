import os
import json
import time
import socket
import logging
import requests
import traceback
import sys
from datetime import datetime
from pathlib import Path

# ================= CONFIG =================

END_LEVEL = 25  # entre INFO (20) e WARNING (30)
logging.addLevelName(END_LEVEL, "END")

def end(self, message, *args, **kwargs):
    if self.isEnabledFor(END_LEVEL):
        self._log(END_LEVEL, message, args, **kwargs)

logging.Logger.end = end

# ================= JSON HANDLER =================

class JsonFileHandler(logging.Handler):
    def __init__(self, file_path):
        super().__init__()
        self.file_path = file_path

    def emit(self, record):
        try:
            payload = {
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
                "function_module": record.module,
                "funcName": record.funcName,
                "line": record.lineno,
            }

            if record.exc_info:
                payload["exception"] = "".join(traceback.format_exception(*record.exc_info))

            with self.file_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(payload, ensure_ascii=False) + "\n")

        except Exception:
            self.handleError(record)

# ================= N8N FILTER =================

class N8NFilter(logging.Filter):
    def filter(self, record):
        return record.levelname in ["WARNING" , "ERROR", "END"]

# ================= N8N HANDLER =================

class N8NHandler(logging.Handler):
    def __init__(self, webhook_url, job_id=None, log_path=None, json_path=None):
        super().__init__()
        self.webhook_url = webhook_url
        self.job_id = job_id
        self.log_path = log_path
        self.json_path = json_path

    def emit(self, record):
        try:
            payload = {
                "jobId": self.job_id,
                "status": self._map_level(record.levelname),
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "logger": record.name,
                "message": record.getMessage(),
                "main_module": self._get_main_module(),
                "function_module": record.module,
                "funcName": record.funcName,
                "line": record.lineno,
                "host": socket.gethostname()
            }

            if record.exc_info:
                payload["exception"] = "".join(traceback.format_exception(*record.exc_info))

            if self.log_path is not None:
                payload["logPath"] = str(self.log_path)
            if self.json_path is not None:
                payload["jsonPath"] = str(self.json_path)

            for attempt in range(3):
                try:
                    requests.post(self.webhook_url, json=payload, timeout=5)
                    break
                except Exception:
                    if attempt < 2:
                        time.sleep(2)

        except Exception:
            self.handleError(record)

    def _map_level(self, level):
        return {
            "ERROR": "error",
            "END": "success",
            "WARNING": "warning"
        }.get(level, "running")

    def _get_main_module(self):
        try:
            main_file = sys.modules["__main__"].__file__
            if main_file:
                return Path(main_file).stem
        except Exception:
            pass
        return "unknown"

# ================= LOGGER SETUP =================

def setup_logger(
    robot_name: str,
    job_id: str = None,
    base_path: str = ".",
    n8n_webhook_url: str = None
):
    base_path = Path(base_path)

    queue_path = base_path / "get_log_n8n" / "queue"
    log_path = base_path
    json_log_dir = base_path / "24hrs"

    # cria diretórios cross-platform (Linux/Windows)
    queue_path.mkdir(parents=True, exist_ok=True)
    log_path.mkdir(parents=True, exist_ok=True)
    json_log_dir.mkdir(parents=True, exist_ok=True)

    if Path(robot_name).is_absolute() or "/" in robot_name or "\\" in robot_name:
        robot_name = Path(robot_name).stem

    logger = logging.getLogger(f"robot.{robot_name}")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if logger.handlers:
        logger.handlers.clear()

    log_file = log_path / f"{robot_name}.log"
    json_file = json_log_dir / f"{robot_name}.jsonl"

    # limpa JSON ao iniciar
    json_file.write_text("", encoding="utf-8")

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setFormatter(formatter)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    json_handler = JsonFileHandler(json_file)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    logger.addHandler(json_handler)

    # só adiciona N8N se URL for fornecida
    if n8n_webhook_url:
        n8n_handler = N8NHandler(
            n8n_webhook_url,
            job_id=job_id,
            log_path=log_file,
            json_path=json_file,
        )
        n8n_handler.addFilter(N8NFilter())
        logger.addHandler(n8n_handler)

    return logger