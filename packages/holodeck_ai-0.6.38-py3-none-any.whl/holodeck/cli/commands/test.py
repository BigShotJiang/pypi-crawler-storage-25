"""CLI command for executing agent test cases.

Implements the 'holodeck test' command for running test suites against agents
with evaluation metrics and report generation.
"""

import asyncio
import sys
import threading
import time
from contextlib import nullcontext
from pathlib import Path
from typing import Any

import click

from holodeck.lib.errors import ConfigError, EvaluationError, ExecutionError
from holodeck.lib.eval_run import (
    build_eval_run_metadata,
    write_eval_run,
)
from holodeck.lib.logging_config import get_logger, setup_logging
from holodeck.lib.observability import (
    ObservabilityContext,
    initialize_observability,
    shutdown_observability,
)
from holodeck.lib.prompt_version import resolve_prompt_version
from holodeck.lib.test_runner.executor import TestExecutor
from holodeck.lib.test_runner.progress import ProgressIndicator
from holodeck.lib.test_runner.reporter import generate_markdown_report
from holodeck.models.agent import Agent
from holodeck.models.config import ExecutionConfig
from holodeck.models.eval_run import EvalRun
from holodeck.models.test_case import TestCaseModel
from holodeck.models.test_result import TestReport, TestResult

logger = get_logger(__name__)


class SpinnerThread(threading.Thread):
    """Background thread for spinner animation."""

    def __init__(self, progress: ProgressIndicator) -> None:
        """Initialize spinner thread.

        Args:
            progress: ProgressIndicator instance
        """
        super().__init__(daemon=True)
        self.progress = progress
        self._stop_event = threading.Event()
        self._running = False

    def run(self) -> None:
        """Run spinner animation loop."""
        self._running = True
        while not self._stop_event.is_set():
            line = self.progress.get_spinner_line()
            if line:
                # Use \r to overwrite line, flush to ensure display
                sys.stdout.write(f"\r{line}")
                sys.stdout.flush()
            time.sleep(0.1)
        self._running = False

    def stop(self) -> None:
        """Stop spinner animation."""
        self._stop_event.set()
        if self._running:
            # Clear spinner line
            sys.stdout.write("\r" + " " * 60 + "\r")
            sys.stdout.flush()


class _TestGroup(click.Group):
    """Click group whose default subcommand is the test runner.

    Lets `holodeck test`, `holodeck test agent.yaml`, and
    `holodeck test agent.yaml --verbose` keep working (legacy contract) while
    also routing `holodeck test view --seed` to the `view` subcommand.

    The default-injection runs in :meth:`parse_args` so it executes *before*
    Click's empty-args handling kicks in (which would otherwise short-circuit
    to the group's help text and skip ``resolve_command`` entirely).
    """

    def parse_args(self, ctx, args):  # type: ignore[no-untyped-def]
        first_positional_idx = next(
            (i for i, a in enumerate(args) if not a.startswith("-")), None
        )
        candidate = (
            args[first_positional_idx] if first_positional_idx is not None else None
        )
        if candidate is None or candidate not in self.commands:
            args = ["run", *args]
        return super().parse_args(ctx, args)


@click.group(cls=_TestGroup)
def test() -> None:
    """Execute agent test cases with evaluation metrics.

    Default subcommand is `run` — so `holodeck test agent.yaml` stays valid
    shorthand for `holodeck test run agent.yaml`. Subcommands:

      run    Execute test cases (default).
      view   Launch the Dash evaluation dashboard.
    """


@test.command("run")
@click.argument("agent_config", type=click.Path(exists=True), default="agent.yaml")
@click.option(
    "--output",
    type=click.Path(),
    default=None,
    help="Path to save test report file (JSON or Markdown)",
)
@click.option(
    "--format",
    type=click.Choice(["json", "markdown"]),
    default=None,
    help="Report format (auto-detect from extension if not specified)",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="Enable verbose output with debug information",
)
@click.option(
    "--quiet",
    "-q",
    is_flag=True,
    help="Suppress progress output (summary still shown)",
)
@click.option(
    "--timeout",
    type=int,
    default=None,
    help="LLM execution timeout in seconds",
)
@click.option(
    "--force-ingest",
    "-f",
    is_flag=True,
    help="Force re-ingestion of all vector store source files",
)
@click.option(
    "--parallel-test-cases",
    type=click.IntRange(min=1),
    default=None,
    help=(
        "Max concurrent multi-turn test cases (>= 1). "
        "Overrides YAML / env / defaults. See feature 032 FR-009a."
    ),
)
@click.option(
    "--limit",
    "-n",
    type=click.IntRange(min=1),
    default=None,
    help=(
        "Run only the first N test cases (in the order they appear in the "
        "configuration). Useful for smoke tests."
    ),
)
def run(
    agent_config: str,
    output: str | None,
    format: str | None,
    verbose: bool,
    quiet: bool,
    timeout: int | None,
    force_ingest: bool,
    parallel_test_cases: int | None,
    limit: int | None,
) -> None:
    """Execute agent test cases with evaluation metrics.

    Runs test cases defined in the agent configuration file and displays
    pass/fail status with evaluation metric scores.

    AGENT_CONFIG is the path to the agent.yaml configuration file.
    """
    # Initialize observability context (will be set if observability enabled)
    obs_context: ObservabilityContext | None = None
    effective_quiet = quiet and not verbose

    start_time = time.time()

    try:
        # Create execution config from CLI options
        cli_config = None
        if timeout is not None or verbose or quiet or parallel_test_cases is not None:
            cli_config = ExecutionConfig(
                llm_timeout=timeout,
                file_timeout=None,
                download_timeout=None,
                cache_enabled=None,
                cache_dir=None,
                verbose=verbose or None,
                quiet=quiet or None,
                parallel_test_cases=parallel_test_cases,
            )

        # Load agent config and resolve execution config in one call
        from holodeck.config.loader import load_agent_with_config

        agent, resolved_config, _loader = load_agent_with_config(
            agent_config, cli_config=cli_config
        )

        # Determine logging strategy: OTel replaces setup_logging when enabled
        if agent.observability and agent.observability.enabled:
            # OTel handles all logging - skip setup_logging
            # Console exporter not enabled by default (only serve enables it)
            obs_context = initialize_observability(
                agent.observability, agent.name, verbose=verbose, quiet=quiet
            )
        else:
            # Traditional logging
            setup_logging(verbose=verbose, quiet=effective_quiet)

        logger.info(
            f"Test command invoked: config={agent_config}, "
            f"verbose={verbose}, quiet={quiet}, timeout={timeout}, "
            f"force_ingest={force_ingest}"
        )
        logger.debug(f"Loading agent configuration from {agent_config}")
        logger.info(f"Agent configuration loaded successfully: {agent.name}")
        logger.debug(
            f"Resolved execution config: verbose={resolved_config.verbose}, "
            f"quiet={resolved_config.quiet}, llm_timeout={resolved_config.llm_timeout}"
        )

        # Apply --limit cap (slice the first N test cases). Done after the
        # agent is loaded so the executor, progress indicator, and EvalRun
        # persistence all see the truncated list consistently.
        if limit is not None and agent.test_cases:
            original_count = len(agent.test_cases)
            if limit < original_count:
                agent.test_cases = agent.test_cases[:limit]
                logger.info(
                    "Test cases capped by --limit: keeping %d of %d",
                    limit,
                    original_count,
                )
                if not effective_quiet:
                    click.echo(
                        f"--limit {limit}: running {limit} of "
                        f"{original_count} test cases"
                    )

        # Get total test count
        total_tests = len(agent.test_cases) if agent.test_cases else 0
        logger.info(f"Found {total_tests} test cases to execute")

        # Initialize progress indicator
        progress = ProgressIndicator(
            total_tests=total_tests, quiet=quiet, verbose=verbose
        )

        # Initialize spinner thread
        spinner_thread = SpinnerThread(progress)

        # Define callbacks
        def on_test_start(test_case: TestCaseModel) -> None:
            """Start spinner for new test."""
            progress.start_test(test_case.name or "Test")
            if not spinner_thread.is_alive() and not quiet and sys.stdout.isatty():
                # Start thread if not running (it handles its own loop)
                # Note: We can't restart a thread, so we might need a new instance
                # or just keep it running and use events.
                # Simpler approach: Start it once before execution and use flags.
                pass

        def progress_callback(result: TestResult) -> None:
            """Update progress indicator and display progress line."""
            # Temporarily stop spinner to print result
            # In a real implementation with threading, we might need a lock
            # But here we just clear the line in the main thread (via update)

            # Update progress state
            progress.update(result)

            # Get formatted result line
            progress_line = progress.get_progress_line()

            if progress_line:  # Only print if not empty (respects quiet mode)
                # Clear current line (handled by \r in spinner)
                sys.stdout.write("\r" + " " * 60 + "\r")
                click.echo(progress_line)

        # Initialize executor with pre-loaded configs to avoid duplicate I/O
        logger.debug("Initializing test executor")
        executor = TestExecutor(
            agent_config_path=agent_config,
            progress_callback=progress_callback,
            on_test_start=on_test_start,
            force_ingest=force_ingest,
            agent_config=agent,
            resolved_execution_config=resolved_config,
        )

        # Run tests asynchronously
        logger.info("Starting test execution")

        # Start spinner thread
        if not quiet and sys.stdout.isatty():
            spinner_thread.start()

        # Determine if observability is enabled for span creation
        observability_enabled = obs_context is not None

        async def run_tests_with_cleanup() -> TestReport:
            """Execute tests and ensure proper cleanup of MCP plugins."""
            # Create parent span for test command if observability is enabled
            if observability_enabled:
                from holodeck.lib.observability import get_tracer

                tracer = get_tracer(__name__)
                span_context: Any = tracer.start_as_current_span("holodeck.cli.test")
            else:
                span_context = nullcontext()

            with span_context:
                try:
                    return await executor.execute_tests()
                finally:
                    await executor.shutdown()

        # Run tests
        try:
            report = asyncio.run(run_tests_with_cleanup())
        finally:
            # Ensure spinner stops
            if spinner_thread.is_alive():
                spinner_thread.stop()
                spinner_thread.join()

        elapsed_time = time.time() - start_time
        logger.info(
            f"Test execution completed in {elapsed_time:.2f}s - "
            f"{report.summary.passed} passed, {report.summary.failed} failed"
        )

        # Display summary (always shown, even in quiet mode)
        summary_text = progress.get_summary()
        click.echo(summary_text)

        # Save report if output specified
        if output:
            logger.debug(f"Saving report to {output} (format={format})")
            _save_report(report, output, format)
            logger.info(f"Report saved successfully to {output}")

        # Persist EvalRun (FR-006). Emitted after --output, only when at
        # least one test result was produced (contracts/cli.md).
        if report.results:
            _persist_eval_run(
                agent=agent,
                report=report,
                agent_config_path=agent_config,
                quiet=effective_quiet,
            )

        # Exit with appropriate code
        if report.summary.failed > 0:
            logger.info("Exiting with failure status (failed tests)")
            sys.exit(1)
        else:
            logger.info("Exiting with success status (all tests passed)")
            sys.exit(0)

    except ConfigError as e:
        logger.error(f"Configuration error: {e}", exc_info=True)
        click.echo(f"Configuration Error: {e}", err=True)
        sys.exit(2)
    except ExecutionError as e:
        logger.error(f"Execution error: {e}", exc_info=True)
        click.echo(f"Execution Error: {e}", err=True)
        sys.exit(3)
    except EvaluationError as e:
        logger.error(f"Evaluation error: {e}", exc_info=True)
        click.echo(f"Evaluation Error: {e}", err=True)
        sys.exit(4)
    except Exception as e:
        logger.error(f"Unexpected error: {e}", exc_info=True)
        click.echo(f"Error: {str(e)}", err=True)
        sys.exit(3)
    finally:
        # Shutdown observability if it was initialized
        if obs_context:
            shutdown_observability(obs_context)


def _persist_eval_run(
    agent: Agent,
    report: TestReport,
    agent_config_path: str,
    quiet: bool,
) -> None:
    """Build an :class:`EvalRun` and write it atomically.

    Persistence failures (permission denied, disk full) log a WARNING and
    surface a single CLI notice — the test exit code is unchanged (FR-009).
    """
    try:
        agent_base_dir = Path(agent_config_path).resolve().parent
        prompt_version = resolve_prompt_version(
            agent.instructions, base_dir=agent_base_dir
        )
        # build_eval_run_metadata performs deep-copy + redact internally so
        # the live ``agent`` instance used by the executor is never mutated.
        metadata = build_eval_run_metadata(
            agent=agent,
            prompt_version=prompt_version,
            argv=sys.argv[1:],
        )
        run = EvalRun(report=report, metadata=metadata)
        target = write_eval_run(run, agent_base_dir=agent_base_dir)
        try:
            display = target.relative_to(Path.cwd())
        except ValueError:
            display = target
        if not quiet:
            click.echo(f"EvalRun persisted: {display}")
        logger.info("EvalRun persisted to %s", target)
    except (OSError, PermissionError) as exc:
        logger.warning("Failed to persist EvalRun: %s", exc)
        click.echo(
            f"Warning: failed to persist EvalRun ({exc}); test exit code preserved.",
            err=True,
        )
    except Exception as exc:  # noqa: BLE001 — never mask exit code on persistence
        logger.warning("Unexpected error persisting EvalRun: %s", exc, exc_info=True)
        click.echo(
            f"Warning: failed to persist EvalRun ({exc}); test exit code preserved.",
            err=True,
        )


def _save_report(report: TestReport, output: str, format: str | None) -> None:
    """Save test report to file in specified format.

    Args:
        report: TestReport instance to save
        output: Output file path
        format: Report format (json/markdown). If None, auto-detect from extension.
    """
    output_path = Path(output)

    # Determine format if not specified
    if format is None:
        if output.endswith(".json"):
            format = "json"
        elif output.endswith(".md") or output.endswith(".markdown"):
            format = "markdown"
        else:
            format = "json"  # Default to JSON
        logger.debug(f"Auto-detected report format: {format}")

    # Generate report content
    logger.debug(f"Generating {format} report")
    if format == "json":
        # Use pydantic's model_dump_json method
        content = report.model_dump_json(indent=2)
    else:  # markdown
        # Generate markdown format using reporter module
        content = generate_markdown_report(report)

    # Write to file (overwrites if exists)
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content, encoding="utf-8")
        click.echo(f"Report saved to {output}")
    except OSError as e:
        logger.error(f"Failed to write report to {output}: {e}")
        raise


# Register the `view` subcommand for the Dash dashboard launcher.
# Imported at module bottom to avoid circular imports with the dashboard package.
from holodeck.cli.commands.test_view import view  # noqa: E402

test.add_command(view)
