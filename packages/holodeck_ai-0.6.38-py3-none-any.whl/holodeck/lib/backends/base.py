"""Provider-agnostic backend interfaces for HoloDeck agent execution.

This module defines the core abstractions that all agent execution backends
(Semantic Kernel, Claude Agent SDK) must implement. Downstream consumers
(TestExecutor, ChatSessionManager, AgentExecutor) depend only on these
interfaces — no provider-specific types leak through.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal, Protocol, runtime_checkable

from holodeck.lib.errors import HoloDeckError
from holodeck.models.token_usage import TokenUsage

if TYPE_CHECKING:
    from holodeck.lib.structured_chunker import DocumentChunk


@dataclass
class ExecutionResult:
    """Provider-agnostic result of a single agent turn.

    Attributes:
        response: The text response from the agent.
        tool_calls: List of tool call records made during execution.
        tool_results: List of tool result records returned during execution.
        token_usage: Token consumption metadata for this turn.
        structured_output: Optional structured output from the agent.
        num_turns: Number of turns taken to produce this result.
        is_error: Whether the execution ended in an error state.
        error_reason: Human-readable reason for the error, if any.
        thinking: Extended-thinking text emitted by the model, concatenated
            in arrival order. Empty when extended thinking is disabled or
            unsupported by the backend.
    """

    response: str
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    tool_results: list[dict[str, Any]] = field(default_factory=list)
    token_usage: TokenUsage = field(default_factory=TokenUsage.zero)
    structured_output: Any | None = None
    num_turns: int = 1
    is_error: bool = False
    error_reason: str | None = None
    thinking: str = ""


@dataclass
class ToolEvent:
    """Real-time tool execution event from the backend.

    Emitted by backends that support hook-based tool observation (e.g. Claude
    Agent SDK).  Events are pushed onto an ``asyncio.Queue`` that consumers
    can drain concurrently during agent execution.

    Attributes:
        kind: Event type — ``"start"`` before execution, ``"end"`` after
            success, ``"error"`` after failure, ``"subagent_message"`` for an
            assistant text snapshot streamed by an in-flight subagent (Task
            tool), ``"parent_link"`` to declare that a tool invocation was
            spawned by a subagent (so the panel can annotate it),
            ``"thinking"`` for an extended-thinking block streamed mid-turn
            (one event per ``ThinkingBlock``, ahead of any tool call the
            block precedes).
        tool_name: Name of the tool being invoked. Empty for
            ``"thinking"`` (no tool involved).
        tool_use_id: Unique identifier correlating start/end/error for the
            same invocation. For ``"subagent_message"`` events this is the
            parent Task's ``tool_use_id`` so consumers can attach the
            snapshot to the corresponding active entry. For ``"parent_link"``
            this is the *child* tool's id. For ``"thinking"`` this is a
            per-block id callers can thread through any downstream protocol
            (e.g. AG-UI ``REASONING_*`` ``message_id``).
        tool_input: Tool input parameters (present on ``"start"``).
        tool_response: Tool output (present on ``"end"``).
        error: Error description (present on ``"error"``).
        parent_tool_use_id: For nested events, the parent Task's
            ``tool_use_id``.  Present on ``"subagent_message"`` and
            ``"parent_link"``.
        text: Latest assistant text snapshot from a subagent (present on
            ``"subagent_message"``), or the thinking-block text (present
            on ``"thinking"``).
    """

    kind: Literal[
        "start", "end", "error", "subagent_message", "parent_link", "thinking"
    ]
    tool_name: str
    tool_use_id: str
    tool_input: dict[str, Any] | None = None
    tool_response: str | None = None
    error: str | None = None
    parent_tool_use_id: str | None = None
    text: str | None = None


@runtime_checkable
class AgentSession(Protocol):
    """Stateful multi-turn conversation session.

    Implementations maintain conversation history across multiple ``send``
    calls. Callers must invoke ``close`` when the session is no longer needed
    to release any held resources (connections, subprocesses, etc.).
    """

    async def prepare(self) -> None:
        """Connect or otherwise ready the session before the first ``send``.

        Called by callers that need the session's underlying transport
        opened in a specific async task context (e.g.
        ``_TaskBoundSession`` requires the SDK's ``connect()`` to run in
        the actor task so the anyio task group binds correctly).

        Default behavior is a no-op. Implementations that have lazy
        connect semantics — like ``ClaudeSession`` — should override
        this to perform the connect explicitly. Implementations that
        connect at construction time can leave this as a no-op.
        """
        return None

    async def send(self, message: str) -> ExecutionResult:
        """Send a message and receive a single-turn result.

        Args:
            message: The user message to send to the agent.

        Returns:
            ExecutionResult containing the agent response and metadata.
        """
        ...

    async def send_streaming(self, message: str) -> AsyncGenerator[str, None]:
        """Send a message and stream the agent response token by token.

        Args:
            message: The user message to send to the agent.

        Yields:
            Successive string chunks of the agent response.
        """
        # Protocol stub — concrete implementations use `yield`
        yield ""  # pragma: no cover

    async def close(self) -> None:
        """Release session resources (connections, subprocesses, etc.)."""
        ...


@runtime_checkable
class AgentBackend(Protocol):
    """Provider backend factory.

    Each backend encapsulates provider-specific initialisation logic and
    exposes a uniform surface for single-turn invocations (``invoke_once``)
    and stateful sessions (``create_session``). Callers must call
    ``initialize`` before any other method and ``teardown`` when done.
    """

    async def initialize(self) -> None:
        """Prepare the backend for use.

        Raises:
            BackendInitError: If the backend cannot be initialised (e.g.
                missing API key, unavailable subprocess).
        """
        ...

    async def invoke_once(
        self,
        message: str,
        context: list[dict[str, Any]] | None = None,
    ) -> ExecutionResult:
        """Execute a single stateless agent turn.

        Args:
            message: The user message to send to the agent.
            context: Optional list of prior conversation turns.

        Returns:
            ExecutionResult containing the agent response and metadata.

        Raises:
            BackendSessionError: If the invocation fails at runtime.
            BackendTimeoutError: If the invocation exceeds configured timeout.
        """
        ...

    async def create_session(self, *, eager_connect: bool = True) -> AgentSession:
        """Create a new stateful multi-turn session.

        Args:
            eager_connect: When True (default), the backend may open its
                underlying transport before returning. When False, the
                backend must return a session whose transport is opened
                lazily — typically by ``AgentSession.prepare()`` invoked
                from a specific async task. Used by callers that need
                connection lifecycle bound to a different task than the
                one calling ``create_session`` (e.g.
                ``_TaskBoundSession`` actor). Backends without lazy
                connect semantics may accept and ignore this argument.

        Returns:
            A fresh AgentSession instance bound to this backend.

        Raises:
            BackendInitError: If the backend was not initialised before calling.
            BackendSessionError: If the session cannot be created.
        """
        ...

    async def teardown(self) -> None:
        """Release all backend resources."""
        ...


class BackendError(HoloDeckError):
    """Base exception for all backend errors.

    Catch this to handle any backend-related failure without needing to know
    the specific subtype.
    """

    pass


class BackendInitError(BackendError):
    """Raised during ``initialize()`` — startup validation failures.

    Examples include a missing API key, an unreachable subprocess, or an
    incompatible runtime environment.
    """

    pass


class BackendSessionError(BackendError):
    """Raised during ``send()`` — session-level failures.

    Examples include unexpected disconnections, malformed responses, or
    provider-reported errors during an active session.
    """

    pass


class BackendTimeoutError(BackendError):
    """Raised when a single invocation exceeds the configured timeout.

    Callers may choose to retry with a longer timeout or surface this as a
    user-visible error.
    """

    pass


@runtime_checkable
class ContextGenerator(Protocol):
    """Backend-agnostic contextual embedding generation.

    Implementations produce situating context for document chunks by
    summarising each chunk's role within the larger document. Both the
    existing Semantic Kernel generator and future Claude SDK generator
    should satisfy this protocol.
    """

    async def contextualize_batch(
        self,
        chunks: list[DocumentChunk],
        document_text: str,
        concurrency: int | None = None,
    ) -> list[str]:
        """Generate contextual descriptions for a batch of chunks.

        Args:
            chunks: Document chunks to contextualize.
            document_text: Full text of the source document.
            concurrency: Maximum number of concurrent LLM calls.

        Returns:
            A list of contextual description strings, one per chunk.
        """
        ...
