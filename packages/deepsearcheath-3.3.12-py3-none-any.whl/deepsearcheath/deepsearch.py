# =============================================================================
# deepsearch.py — 레거시 facade
# =============================================================================
#
# 이 파일은 legacy/local.py의 클래스들을 그대로 re-export한다.
# 기존 프로젝트에서 `from deepsearcheath import deepsearch as ds` 패턴으로 사용.
#
# 새 아키텍처는 `from deepsearcheath import DeepSearch` 를 사용한다.
# (core.py → facade/ → pipeline/ → client/)
#
# =============================================================================

from .legacy.local import (
    asyncDeepSearchAPI,
    asyncDeepSearchAPI_mk2,
    DeepSearchAPI,
    WaveletAPI,
    asyncWaveletAPI,
    HaystackAPI,
    asyncHaystackAPI,
    backtest,
    _backtest,
    DeepSearchGlobalAPI,
)

__all__ = [
    "asyncDeepSearchAPI",
    "asyncDeepSearchAPI_mk2",
    "DeepSearchAPI",
    "WaveletAPI",
    "asyncWaveletAPI",
    "HaystackAPI",
    "asyncHaystackAPI",
    "backtest",
    "_backtest",
    "DeepSearchGlobalAPI",
]
