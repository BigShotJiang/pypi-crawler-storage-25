import pandas as pd
from typing import List, Optional, Tuple

from ..pipeline.news import (
    prepare_news_data,
    collect_news_frozen,
    collect_news_liquid,
    load_and_preprocess_news,
    filter_news_by_symbol,
    split_news_by_session,
)
from ..pipeline.store import MarketDataCache


class NewsFacade:
    """
    뉴스 데이터 facade.

    ds = DeepSearch()
    news = await ds.news.get(symbols=["AAPL"], date_from="2024-01-01", date_to="2025-01-01")
    """

    def __init__(self, cache_dir: str = ".cache/market_data", concurrency: int = 10):
        self._cache_dir = cache_dir
        self._concurrency = concurrency
        self._cache: Optional[MarketDataCache] = None

    async def get(
        self,
        symbols: Optional[List[str]] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        force_refresh: bool = False,
        flush: bool = False,
        verbose: bool = True,
        **kwargs,
    ) -> pd.DataFrame:
        """
        뉴스 데이터를 수집하고 DataFrame으로 반환.

        Parameters:
            symbols: 종목 리스트 (None이면 keyword 검색)
            date_from: 시작일 (YYYY-MM-DD)
            date_to: 종료일 (YYYY-MM-DD)
            **kwargs: keyword, company_name 등 추가 검색 파라미터

        Returns:
            뉴스 DataFrame
        """
        self._cache = await prepare_news_data(
            symbols=symbols,
            date_from=date_from,
            date_to=date_to,
            cache_dir=self._cache_dir,
            concurrency=self._concurrency,
            force_refresh=force_refresh,
            flush=flush,
            verbose=verbose,
            **kwargs,
        )
        return self._cache.news_data

    async def collect(
        self,
        symbols: List[str],
        date_from: str,
        date_to: Optional[str] = None,
        mode: str = "frozen",
        base_cache_dir: str = ".cache/news_batches",
        batch_size: int = 50,
        verbose: bool = True,
        **kwargs,
    ) -> None:
        """
        대용량 뉴스 배치 수집 (parquet 파일로 저장).

        Parameters:
            symbols: 종목 리스트
            date_from: 시작일
            date_to: 종료일 (liquid 모드에서 None이면 오늘)
            mode: "frozen" (고정 수집) 또는 "liquid" (증분 업데이트)
            base_cache_dir: 배치 파일 저장 경로
            batch_size: 한 번에 처리할 종목 수
        """
        if mode == "frozen":
            await collect_news_frozen(
                target_symbols=symbols,
                start_date=date_from,
                end_date=date_to or "",
                base_cache_dir=base_cache_dir,
                batch_size=batch_size,
                concurrency=self._concurrency,
                verbose=verbose,
                **kwargs,
            )
        elif mode == "liquid":
            await collect_news_liquid(
                target_symbols=symbols,
                start_date=date_from,
                end_date=date_to,
                base_cache_dir=base_cache_dir,
                batch_size=batch_size,
                concurrency=self._concurrency,
                verbose=verbose,
                **kwargs,
            )
        else:
            raise ValueError(f"Unknown mode: {mode}. Use 'frozen' or 'liquid'.")

    def load(
        self,
        base_dir: str,
        sections: Optional[List[str]] = None,
        vendors: Optional[List[str]] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
    ) -> pd.DataFrame:
        """저장된 parquet 뉴스 데이터를 로드하고 필터링."""
        return load_and_preprocess_news(
            base_dir=base_dir,
            sections=sections,
            vendors=vendors,
            date_from=date_from,
            date_to=date_to,
        )

    @staticmethod
    def filter_by_symbol(df: pd.DataFrame, symbols: List[str]) -> pd.DataFrame:
        """뉴스 DataFrame에서 특정 종목 관련 기사만 필터링."""
        return filter_news_by_symbol(df, symbols)

    @staticmethod
    def split_by_session(
        df: pd.DataFrame,
        date_col: str = "published_at",
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """뉴스를 장중/장후/야간 시간대별로 분리."""
        return split_news_by_session(df, date_col=date_col)
