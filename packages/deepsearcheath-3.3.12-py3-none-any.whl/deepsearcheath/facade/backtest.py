import pandas as pd
from typing import Tuple

from ..legacy.local import DeepSearchGlobalAPI


class BacktestFacade:
    """
    백테스트 facade.

    ds = DeepSearch()
    total, detail = ds.backtest.run(portfolio, price_data, fee=0.0025)
    """

    def __init__(self):
        self._api = DeepSearchGlobalAPI()

    def run(
        self,
        portfolio_holdings: pd.DataFrame,
        price_data: pd.DataFrame,
        initial_capital: float = 100_000_000_000,
        verbose: int = 0,
        fee: float = 0.0025,
    ) -> Tuple[pd.Series, pd.DataFrame]:
        """
        포트폴리오 백테스트 실행.

        Parameters:
            portfolio_holdings: 리밸런싱 일자별 포트폴리오 (date, symbol, weight 컬럼 필수)
            price_data: 일별 수익률 데이터 (index: date, columns: symbols)
            initial_capital: 초기 투자금액
            verbose: 0=없음, 1=요약, 2=상세
            fee: 거래 수수료율 (회전율 대비)

        Returns:
            (total_value, portfolio_value) — 전체 가치 변화, 종목별 가치 변화
        """
        return self._api.backtest_global(
            portfolio_holdings=portfolio_holdings,
            price_data=price_data,
            initial_capital=initial_capital,
            verbose=verbose,
            fee=fee,
        )
