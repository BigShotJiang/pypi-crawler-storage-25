import pandas as pd
from typing import List, Optional, Dict, Tuple

from ..pipeline.market import prepare_market_data, get_krx_market_price, get_krx_market_price_period
from ..pipeline.store import MarketDataCache


class StockFacade:
    """
    시세 데이터 facade.

    ds = DeepSearch()
    price, mktcap = await ds.stock.get(["AAPL"], "2024-01-01", "2025-01-01")
    """

    def __init__(self, cache_dir: str = ".cache/market_data", concurrency: int = 10):
        self._cache_dir = cache_dir
        self._concurrency = concurrency
        self._cache: Optional[MarketDataCache] = None

    async def get(
        self,
        symbols: List[str],
        date_from: str,
        date_to: str,
        force_refresh: bool = False,
        flush: bool = False,
        verbose: bool = True,
        use_massive: bool = False,
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        종목 시세 데이터를 수집하고 (price, mktcap) 튜플로 반환.

        Parameters:
            symbols: 종목 리스트 (예: ["AAPL", "005930"], "ALL_US", "ALL_KO")
            date_from: 시작일 (YYYY-MM-DD)
            date_to: 종료일 (YYYY-MM-DD)
            force_refresh: 캐시 무시하고 새로 요청
            flush: 기존 캐시 삭제 후 처음부터
            verbose: 상세 로그 출력
            use_massive: True일 때 date_to가 오늘 이상이면 Massive API로 당일 실시간 스냅샷 추가 조회.
                         False(기본값)이면 DeepSearch D-1 래그 데이터만 사용.

        Returns:
            (price_df, mktcap_df) — pivot 형태 (index: date, columns: symbol)
        """
        self._cache = await prepare_market_data(
            symbols=symbols,
            date_from=date_from,
            date_to=date_to,
            cache_dir=self._cache_dir,
            concurrency=self._concurrency,
            force_refresh=force_refresh,
            flush=flush,
            verbose=verbose,
            use_massive=use_massive,
        )

        matrices = self._cache.get_market_matrices(
            date_from=date_from,
            date_to=date_to,
        )
        return matrices.get("price", pd.DataFrame()), matrices.get("market_cap", pd.DataFrame())

    def price(
        self,
        symbols: Optional[List[str]] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
    ) -> pd.DataFrame:
        """캐시에서 가격 데이터 조회 (API 호출 없음)."""
        if self._cache is None:
            self._cache = MarketDataCache(self._cache_dir)
        if symbols:
            return self._cache.get_price(symbols, date_from, date_to)
        return self._cache.price_data

    def matrices(
        self,
        symbols: Optional[List[str]] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
    ) -> Dict[str, pd.DataFrame]:
        """캐시에서 행렬 데이터 조회 (price, market_cap, volume, return)."""
        if self._cache is None:
            self._cache = MarketDataCache(self._cache_dir)
        return self._cache.get_market_matrices(symbols, date_from, date_to)

    async def krx_daily(
        self,
        date: str,
        market: str = "ALL",
        auth_key: Optional[str] = None,
    ) -> pd.DataFrame:
        """KRX 특정 일자 전종목 시세."""
        return await get_krx_market_price(date=date, market=market, auth_key=auth_key)

    async def krx_period(
        self,
        date_from: str,
        date_to: str,
        market: str = "ALL",
        auth_key: Optional[str] = None,
        concurrency: int = 10,
        delay: float = 0.3,
    ) -> pd.DataFrame:
        """KRX 기간별 전종목 시세."""
        return await get_krx_market_price_period(
            date_from=date_from,
            date_to=date_to,
            market=market,
            auth_key=auth_key,
            concurrency=concurrency,
            delay=delay,
        )
