from typing import Dict, Any
from ._base import MassiveBase


class CorporateActions(MassiveBase):
    """
    기업 행동(Corporate Actions) 엔드포인트.
    배당, 주식분할, IPO, 티커 이벤트 이력을 제공한다.
    """

    async def dividends(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        배당금 이력 조회 (선언일·배당락일·지급일 포함).
        (GET /v3/reference/dividends)

        :param ticker: 티커 심볼 (예: "AAPL")
        :param opts: ex_dividend_date, record_date, pay_date, order, limit 등
        :return: {"results": [{"ticker","cash_amount","declaration_date",
                               "dividend_type","ex_dividend_date","pay_date",...},...]}
        """
        params = {"ticker": ticker, **opts}
        return await self._request("GET", "/v3/reference/dividends", params=params)

    async def splits(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        주식 분할 이력 조회 (분할 비율·실행일 포함).
        (GET /v3/reference/splits)

        :param ticker: 티커 심볼
        :param opts: execution_date, reverse_split, order, limit 등
        :return: {"results": [{"ticker","execution_date","split_from","split_to"},...]}
        """
        params = {"ticker": ticker, **opts}
        return await self._request("GET", "/v3/reference/splits", params=params)

    async def ipos(self, **opts) -> Dict[str, Any]:
        """
        IPO 정보 조회 (2008년 이후).
        (GET /vX/reference/ipos)

        :param opts: ticker, us_code, isin, listing_date, order, limit 등
        :return: {"results": [{"ticker","name","listing_date","lot_size","ipo_price",...},...]}
        """
        return await self._request("GET", "/vX/reference/ipos", params=opts)

    async def ticker_events(self, id_: str) -> Dict[str, Any]:
        """
        특정 티커/식별자의 주요 이벤트 타임라인 조회.
        (GET /vX/reference/tickers/{id}/events)

        :param id_: 티커 심볼 또는 복합 FIGI 식별자
        :return: {"results": {"name","events": [{"type","date","ticker_change",...}]}}
        """
        return await self._request(
            "GET", f"/vX/reference/tickers/{id_}/events"
        )
