from typing import Dict, Any, Optional
from ._base import MassiveBase


class Tickers(MassiveBase):
    """
    티커 메타데이터 엔드포인트.
    종목 목록, 개요, 유형, 연관 종목을 제공한다.
    """

    async def all_(
        self,
        ticker: Optional[str] = None,
        type: Optional[str] = None,
        market: Optional[str] = None,
        **opts,
    ) -> Dict[str, Any]:
        """
        Massive가 지원하는 전체 티커 목록 조회.
        (GET /v3/reference/tickers)

        :param ticker: 특정 티커 필터 (예: "AAPL")
        :param type: 티커 유형 필터 (예: "CS"=보통주, "ETF")
        :param market: 시장 필터 (예: "stocks", "fx", "crypto")
        :param opts: 추가 쿼리 파라미터 (cursor, limit 등)
        :return: {"results": [{ticker,name,market,locale,type,...},...], "next_url": ...}
        """
        params = {
            k: v for k, v in {"ticker": ticker, "type": type, "market": market}.items()
            if v is not None
        }
        params.update(opts)
        return await self._request("GET", "/v3/reference/tickers", params=params)

    async def overview(self, ticker: str) -> Dict[str, Any]:
        """
        단일 티커 상세 정보 조회.
        (GET /v3/reference/tickers/{ticker})

        :param ticker: 티커 심볼 (예: "AAPL")
        :return: {ticker, name, market, locale, primary_exchange, type,
                  active, currency_name, cik, composite_figi, ...}
        """
        return await self._request("GET", f"/v3/reference/tickers/{ticker}")

    async def ticker_types(
        self,
        asset_class: Optional[str] = None,
        locale: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Massive가 지원하는 티커 유형 목록 조회.
        (GET /v3/reference/tickers/types)

        :param asset_class: 자산 유형 필터
        :param locale: 지역 필터
        :return: {"results": [{"code","description","asset_class","locale"},...]}
        """
        params = {
            k: v for k, v in {"asset_class": asset_class, "locale": locale}.items()
            if v is not None
        }
        return await self._request("GET", "/v3/reference/tickers/types", params=params)

    async def related(self, ticker: str) -> Dict[str, Any]:
        """
        특정 티커와 연관된 종목 조회 (뉴스·수익률 분석 기반).
        (GET /v2/reference/related-companies/{ticker})

        :param ticker: 티커 심볼 (예: "AAPL")
        :return: {"results": [{"ticker"},...], "request_id": str}
        """
        return await self._request(
            "GET", f"/v2/reference/related-companies/{ticker}"
        )
