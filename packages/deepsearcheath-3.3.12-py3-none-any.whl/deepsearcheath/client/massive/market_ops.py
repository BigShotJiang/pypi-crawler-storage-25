from typing import Dict, Any
from ._base import MassiveBase


class MarketOps(MassiveBase):
    """
    시장 운영 관련 엔드포인트.
    장 상태, 공휴일, 거래소, 체결 조건 코드를 제공한다.
    """

    async def status(self) -> Dict[str, Any]:
        """
        현재 미국 시장 상태 조회.
        (GET /v1/marketstatus/now)

        :return: {"market": "open"|"closed"|"extended-hours",
                  "afterHours": bool, "earlyHours": bool,
                  "exchanges": {"nasdaq": ..., "nyse": ..., "otc": ...},
                  "serverTime": str}
        """
        return await self._request("GET", "/v1/marketstatus/now")

    async def holidays(self) -> Dict[str, Any]:
        """
        향후 미국 시장 공휴일 및 단축 거래일 조회.
        (GET /v1/marketstatus/upcoming)

        :return: [{"date","exchange","name","status","open","close"}, ...]
        """
        return await self._request("GET", "/v1/marketstatus/upcoming")

    async def exchanges(
        self, asset_class: str = "stocks", locale: str = "us"
    ) -> Dict[str, Any]:
        """
        거래소 목록 조회.
        (GET /v3/reference/exchanges)

        :param asset_class: 자산 유형 (기본값: "stocks")
        :param locale: 지역 코드 (기본값: "us")
        :return: {"results": [{"id","type","market","mic","name","acronym",...}], ...}
        """
        params = {"asset_class": asset_class, "locale": locale}
        return await self._request("GET", "/v3/reference/exchanges", params=params)

    async def condition_codes(
        self, asset_class: str = "stocks", data_type: str = "trade"
    ) -> Dict[str, Any]:
        """
        체결/호가 조건 코드 목록 조회.
        (GET /v3/reference/conditions)

        :param asset_class: 자산 유형 (기본값: "stocks")
        :param data_type: 데이터 유형 ("trade" 또는 "quote")
        :return: {"results": [{"id","type","name","description",...}], ...}
        """
        params = {"asset_class": asset_class, "data_type": data_type}
        return await self._request("GET", "/v3/reference/conditions", params=params)
