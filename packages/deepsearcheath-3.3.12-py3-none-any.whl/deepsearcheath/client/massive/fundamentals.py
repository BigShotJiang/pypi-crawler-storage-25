from typing import Dict, Any
from ._base import MassiveBase


class Fundamentals(MassiveBase):
    """
    재무제표·기본 지표 엔드포인트.
    대차대조표, 손익계산서, 현금흐름표, 재무비율, 공매도 데이터 등을 제공한다.
    """

    async def balance_sheets(
        self, ticker: str, timeframe: str = "quarterly", **opts
    ) -> Dict[str, Any]:
        """
        대차대조표 조회.
        (GET /vX/reference/financials?financials_type=balance_sheet)

        :param ticker: 티커 심볼
        :param timeframe: "quarterly" (분기) 또는 "annual" (연간)
        :return: {"results": [{"financials": {"balance_sheet": {...}}, ...}], ...}
        """
        params = {
            "ticker": ticker,
            "timeframe": timeframe,
            "financials_type": "balance_sheet",
            **opts,
        }
        return await self._request("GET", "/vX/reference/financials", params=params)

    async def income_statements(
        self, ticker: str, timeframe: str = "quarterly", **opts
    ) -> Dict[str, Any]:
        """
        손익계산서 조회.
        (GET /vX/reference/financials?financials_type=income_statement)

        :param ticker: 티커 심볼
        :param timeframe: "quarterly" (분기) 또는 "annual" (연간)
        :return: {"results": [{"financials": {"income_statement": {...}}, ...}], ...}
        """
        params = {
            "ticker": ticker,
            "timeframe": timeframe,
            "financials_type": "income_statement",
            **opts,
        }
        return await self._request("GET", "/vX/reference/financials", params=params)

    async def cash_flow_statements(
        self, ticker: str, timeframe: str = "quarterly", **opts
    ) -> Dict[str, Any]:
        """
        현금흐름표 조회.
        (GET /vX/reference/financials?financials_type=cash_flow_statement)

        :param ticker: 티커 심볼
        :param timeframe: "quarterly" (분기) 또는 "annual" (연간)
        :return: {"results": [{"financials": {"cash_flow_statement": {...}}, ...}], ...}
        """
        params = {
            "ticker": ticker,
            "timeframe": timeframe,
            "financials_type": "cash_flow_statement",
            **opts,
        }
        return await self._request("GET", "/vX/reference/financials", params=params)

    async def ratios(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        재무비율 조회 (밸류에이션·수익성·유동성·레버리지).
        (GET /vX/reference/financials/ratios)

        :param ticker: 티커 심볼
        :return: P/E, P/B, ROE, ROA, 부채비율 등 재무비율 데이터
        """
        params = {"ticker": ticker, **opts}
        return await self._request(
            "GET", "/vX/reference/financials/ratios", params=params
        )

    async def float_(self, ticker: str) -> Dict[str, Any]:
        """
        유동 주식 수 (Free Float) 조회.
        (GET /vX/reference/financials/float)

        :param ticker: 티커 심볼
        :return: 최신 유동 주식 수 데이터
        """
        return await self._request(
            "GET", "/vX/reference/financials/float", params={"ticker": ticker}
        )

    async def short_interest(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        공매도 잔량 조회 (FINRA 격주 보고 기준).
        (GET /vX/reference/short-interest)

        :param ticker: 티커 심볼
        :return: 공매도 잔량 및 관련 통계
        """
        params = {"ticker": ticker, **opts}
        return await self._request(
            "GET", "/vX/reference/short-interest", params=params
        )

    async def short_volume(self, ticker: str, date: str, **opts) -> Dict[str, Any]:
        """
        일별 공매도 거래량 조회 (ATS·장외 거래소 집계).
        (GET /vX/reference/short-volume)

        :param ticker: 티커 심볼
        :param date: 조회 날짜 (YYYY-MM-DD)
        :return: 해당 날짜의 공매도 거래량 데이터
        """
        params = {"ticker": ticker, "date": date, **opts}
        return await self._request(
            "GET", "/vX/reference/short-volume", params=params
        )
