from typing import Dict, Any
from ._base import MassiveBase


class Technical(MassiveBase):
    """
    기술적 지표 엔드포인트.
    SMA, EMA, MACD, RSI를 특정 기간·윈도우로 조회한다.
    """

    async def sma(
        self,
        ticker: str,
        timespan: str,
        window: int,
        series_type: str = "close",
        **opts,
    ) -> Dict[str, Any]:
        """
        단순이동평균 (Simple Moving Average) 조회.
        (GET /v1/indicators/sma/{ticker})

        :param ticker: 티커 심볼 (예: "AAPL")
        :param timespan: 기간 단위 ("minute","hour","day","week","month","quarter","year")
        :param window: 이동평균 윈도우 크기 (예: 20)
        :param series_type: 기준 가격 ("close","open","high","low")
        :return: {"results": {"values": [{"timestamp","value"},...], "ohlc": [...]}, ...}
        """
        params = {
            "timespan": timespan,
            "window": window,
            "series_type": series_type,
            **opts,
        }
        return await self._request("GET", f"/v1/indicators/sma/{ticker}", params=params)

    async def ema(
        self,
        ticker: str,
        timespan: str,
        window: int,
        series_type: str = "close",
        **opts,
    ) -> Dict[str, Any]:
        """
        지수이동평균 (Exponential Moving Average) 조회.
        (GET /v1/indicators/ema/{ticker})

        :param ticker: 티커 심볼
        :param timespan: 기간 단위
        :param window: 이동평균 윈도우 크기
        :param series_type: 기준 가격 (기본값: "close")
        :return: EMA 값 시계열
        """
        params = {
            "timespan": timespan,
            "window": window,
            "series_type": series_type,
            **opts,
        }
        return await self._request("GET", f"/v1/indicators/ema/{ticker}", params=params)

    async def macd(
        self,
        ticker: str,
        timespan: str,
        **opts,
    ) -> Dict[str, Any]:
        """
        MACD (Moving Average Convergence/Divergence) 조회.
        (GET /v1/indicators/macd/{ticker})

        :param ticker: 티커 심볼
        :param timespan: 기간 단위
        :param opts: short_window, long_window, signal_window, series_type 등
        :return: {"results": {"values": [{"timestamp","value","signal","histogram"},...], ...}}
        """
        params = {"timespan": timespan, **opts}
        return await self._request(
            "GET", f"/v1/indicators/macd/{ticker}", params=params
        )

    async def rsi(
        self,
        ticker: str,
        timespan: str,
        window: int,
        **opts,
    ) -> Dict[str, Any]:
        """
        RSI (Relative Strength Index) 조회.
        (GET /v1/indicators/rsi/{ticker})

        :param ticker: 티커 심볼
        :param timespan: 기간 단위
        :param window: RSI 윈도우 크기 (일반적으로 14)
        :param opts: series_type 등 추가 파라미터
        :return: RSI 값 시계열
        """
        params = {"timespan": timespan, "window": window, **opts}
        return await self._request(
            "GET", f"/v1/indicators/rsi/{ticker}", params=params
        )
