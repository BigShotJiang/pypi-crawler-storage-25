"""
deepsearcheath.client.massive
=============================
Massive REST API 클라이언트 패키지.

Usage (새 도메인 구조):
    client = MassiveClient()
    async with client:
        snap  = await client.snapshots.batch(["AAPL", "MSFT"])
        bars  = await client.aggregates.prev_day_bar("AAPL")
        rsi   = await client.technical.rsi("AAPL", "day", 14)
        news  = await client.news.get("AAPL")
        bs    = await client.fundamentals.balance_sheets("AAPL")

Usage (backward-compat — pipeline/market.py 기존 호출 방식):
    client = MassiveClient()
    async with client:
        result = await client.get_snapshots(["AAPL", "MSFT"])
        status = await client.get_market_status()

환경변수:
    MASSIVE_API_KEY
"""

import os
from typing import Optional, Dict, Any, List
import aiohttp

from .aggregates import Aggregates
from .corporate_actions import CorporateActions
from .filings import Filings
from .fundamentals import Fundamentals
from .market_ops import MarketOps
from .news import News
from .snapshots import Snapshots
from .technical import Technical
from .tickers import Tickers
from .trades_quotes import TradesQuotes

__all__ = ["MassiveClient"]


class MassiveClient:
    """
    Massive REST API 파사드 클라이언트.

    모든 도메인 서브클라이언트를 조합하며,
    컨텍스트 매니저 진입 시 단일 aiohttp 세션을 생성해
    모든 도메인 클라이언트에 공유 주입한다.

    Attributes:
        aggregates       (Aggregates)       OHLCV 집계
        snapshots        (Snapshots)        당일 실시간 스냅샷
        tickers          (Tickers)          티커 메타데이터
        trades_quotes    (TradesQuotes)     체결·호가 틱 데이터
        fundamentals     (Fundamentals)     재무제표·기본 지표
        technical        (Technical)        기술적 지표
        corporate_actions (CorporateActions) 기업 행동(배당·분할·IPO)
        filings          (Filings)          SEC 공시
        market_ops       (MarketOps)        시장 운영 (장 상태·공휴일)
        news             (News)             주식 뉴스
    """

    def __init__(self, api_key: Optional[str] = None):
        """
        :param api_key: Massive API Key.
                        없으면 MASSIVE_API_KEY 환경변수 사용.
        :raises ValueError: API 키가 설정되지 않은 경우
        """
        key = api_key or os.getenv("MASSIVE_API_KEY")
        if not key:
            raise ValueError("MASSIVE_API_KEY environment variable is not set")
        self._api_key = key
        self._session: Optional[aiohttp.ClientSession] = None

        # 도메인 서브클라이언트
        self.aggregates        = Aggregates(key)
        self.snapshots         = Snapshots(key)
        self.tickers           = Tickers(key)
        self.trades_quotes     = TradesQuotes(key)
        self.fundamentals      = Fundamentals(key)
        self.technical         = Technical(key)
        self.corporate_actions = CorporateActions(key)
        self.filings           = Filings(key)
        self.market_ops        = MarketOps(key)
        self.news              = News(key)

        self._domain_clients = [
            self.aggregates, self.snapshots, self.tickers,
            self.trades_quotes, self.fundamentals, self.technical,
            self.corporate_actions, self.filings, self.market_ops, self.news,
        ]

    async def __aenter__(self):
        """
        단일 aiohttp 세션을 생성하고 모든 도메인 클라이언트에 공유 주입.
        → 10개의 개별 커넥션 풀 대신 1개의 커넥션 풀 사용.
        """
        self._session = aiohttp.ClientSession(
            headers={"Authorization": f"Bearer {self._api_key}"}
        )
        for client in self._domain_clients:
            client.session = self._session
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._session:
            await self._session.close()
            self._session = None
        for client in self._domain_clients:
            client.session = None

    # ── Backward-compatible shortcuts ─────────────────────────────────────────
    # pipeline/market.py 의 기존 호출 방식(fetch_today_snapshots)과 호환 유지

    async def get_snapshots(self, tickers: List[str]) -> Dict[str, Any]:
        """Backward-compat: self.snapshots.batch() 위임."""
        return await self.snapshots.batch(tickers)

    async def get_snapshot(self, ticker: str) -> Dict[str, Any]:
        """Backward-compat: self.snapshots.single() 위임."""
        return await self.snapshots.single(ticker)

    async def get_market_status(self) -> Dict[str, Any]:
        """Backward-compat: self.market_ops.status() 위임."""
        return await self.market_ops.status()

    async def get_prev_day_bar(
        self, ticker: str, adjusted: bool = True
    ) -> Dict[str, Any]:
        """Backward-compat: self.aggregates.prev_day_bar() 위임."""
        return await self.aggregates.prev_day_bar(ticker, adjusted=adjusted)

    async def get_daily_open_close(
        self, ticker: str, date: str, adjusted: bool = True
    ) -> Dict[str, Any]:
        """Backward-compat: self.aggregates.daily_ticker_summary() 위임."""
        return await self.aggregates.daily_ticker_summary(ticker, date, adjusted=adjusted)
