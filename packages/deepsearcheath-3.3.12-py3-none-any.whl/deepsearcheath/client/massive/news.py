from typing import Dict, Any
from ._base import MassiveBase


class News(MassiveBase):
    """
    주식 뉴스 엔드포인트.
    특정 티커 관련 최신 뉴스 기사와 감성(sentiment) 정보를 제공한다.
    """

    async def get(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        특정 티커 관련 최신 뉴스 기사 조회.
        (GET /v2/reference/news)

        :param ticker: 티커 심볼 (예: "AAPL")
        :param opts: published_utc, order, limit, sort 등 추가 파라미터
        :return: {"results": [{"id","publisher","title","author","published_utc",
                               "article_url","tickers","description","keywords",
                               "insights": [{"ticker","sentiment","sentiment_reasoning"}]
                               },...], "next_url": ...}
        """
        params = {"ticker": ticker, **opts}
        return await self._request("GET", "/v2/reference/news", params=params)
