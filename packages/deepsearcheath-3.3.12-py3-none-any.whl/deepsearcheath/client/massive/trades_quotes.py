from typing import Dict, Any
from ._base import MassiveBase


class TradesQuotes(MassiveBase):
    """
    체결·호가 틱 데이터 엔드포인트.
    실시간/최신 체결가 및 NBBO 호가를 제공한다.
    """

    async def trades(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        특정 티커의 틱 단위 체결 내역 조회.
        (GET /v3/trades/{ticker})

        :param ticker: 티커 심볼 (예: "AAPL")
        :param opts: timestamp, order, limit, sort 등 추가 파라미터
        :return: {"results": [{"price","size","exchange","conditions","timestamp",...},...]}
        """
        return await self._request("GET", f"/v3/trades/{ticker}", params=opts)

    async def last_trade(self, ticker: str) -> Dict[str, Any]:
        """
        최신 체결 정보 조회 (가격·수량·거래소·타임스탬프).
        (GET /v2/last/trade/{ticker})

        :param ticker: 티커 심볼 (예: "AAPL")
        :return: {"results": {"T","p","s","x","t","c",...}, "status": str}
        """
        return await self._request("GET", f"/v2/last/trade/{ticker}")

    async def quotes(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        특정 티커의 NBBO 호가 내역 조회.
        (GET /v3/quotes/{ticker})

        :param ticker: 티커 심볼 (예: "AAPL")
        :param opts: timestamp, order, limit, sort 등 추가 파라미터
        :return: {"results": [{"ask_price","ask_size","bid_price","bid_size","timestamp",...},...]}
        """
        return await self._request("GET", f"/v3/quotes/{ticker}", params=opts)

    async def last_quote(self, ticker: str) -> Dict[str, Any]:
        """
        최신 NBBO (National Best Bid and Offer) 호가 조회.
        (GET /v2/last/nbbo/{ticker})

        :param ticker: 티커 심볼 (예: "AAPL")
        :return: {"results": {"T","P","p","S","s","t","x","X",...}, "status": str}
                 P=최우선매도, p=최우선매수, S=매도수량, s=매수수량
        """
        return await self._request("GET", f"/v2/last/nbbo/{ticker}")
