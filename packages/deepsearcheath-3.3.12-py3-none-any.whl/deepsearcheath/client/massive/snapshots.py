from typing import Dict, Any, List
from ._base import MassiveBase


class Snapshots(MassiveBase):
    """
    미국 주식 스냅샷 엔드포인트.
    당일 실시간 시장 데이터(현재가·OHLC·거래량)를 제공한다.
    """

    async def full_market(self, include_otc: bool = False) -> Dict[str, Any]:
        """
        전체 미국 주식 시장 스냅샷 조회.
        (GET /v2/snapshot/locale/us/markets/stocks/tickers)

        :param include_otc: OTC 종목 포함 여부 (기본값: False)
        :return: {"tickers": [...], "count": int, "status": str}
        """
        params: Dict[str, Any] = {}
        if include_otc:
            params["include_otc"] = "true"
        return await self._request(
            "GET", "/v2/snapshot/locale/us/markets/stocks/tickers", params=params
        )

    async def batch(self, tickers: List[str]) -> Dict[str, Any]:
        """
        복수 티커 당일 스냅샷 배치 조회.
        (GET /v2/snapshot/locale/us/markets/stocks/tickers?tickers=AAPL,MSFT,...)

        :param tickers: 티커 리스트 (예: ["AAPL", "MSFT"])
        :return: {"tickers": [...], "count": int, "status": str}
                 ticker 객체: {ticker, day:{o,h,l,c,v,vw}, min, prevDay, lastTrade, lastQuote, ...}
        """
        params = {"tickers": ",".join(tickers)}
        return await self._request(
            "GET", "/v2/snapshot/locale/us/markets/stocks/tickers", params=params
        )

    async def single(self, ticker: str) -> Dict[str, Any]:
        """
        단일 티커 당일 스냅샷 조회.
        (GET /v2/snapshot/locale/us/markets/stocks/tickers/{ticker})

        :param ticker: 티커 심볼 (예: "AAPL")
        :return: {"ticker": {...}, "status": str, "request_id": str}
        """
        return await self._request(
            "GET", f"/v2/snapshot/locale/us/markets/stocks/tickers/{ticker}"
        )

    async def top_movers(self, direction: str = "gainers") -> Dict[str, Any]:
        """
        당일 상위 등락 종목 Top 20 조회.
        (GET /v2/snapshot/locale/us/markets/stocks/{direction})

        :param direction: "gainers" (상승) 또는 "losers" (하락)
        :return: {"tickers": [...], "status": str}
        """
        return await self._request(
            "GET", f"/v2/snapshot/locale/us/markets/stocks/{direction}"
        )

    async def unified(self, tickers: List[str], **opts) -> Dict[str, Any]:
        """
        주식·옵션·외환·암호화폐 통합 스냅샷 조회.
        (GET /v3/snapshot)

        :param tickers: 티커 리스트
        :param opts: 추가 쿼리 파라미터
        :return: 통합 스냅샷 JSON
        """
        params = {"ticker.any_of": ",".join(tickers), **opts}
        return await self._request("GET", "/v3/snapshot", params=params)
