from typing import Dict, Any
from ._base import MassiveBase


class Aggregates(MassiveBase):
    """
    OHLCV 집계 데이터 엔드포인트.
    커스텀 바, 일별 요약, 전일 바 등 시계열 집계 데이터를 제공한다.
    """

    async def custom_bars(
        self,
        ticker: str,
        multiplier: int,
        timespan: str,
        from_: str,
        to: str,
        adjusted: bool = True,
        sort: str = "asc",
        limit: int = 5000,
    ) -> Dict[str, Any]:
        """
        커스텀 기간 OHLCV 집계 바 조회.
        (GET /v2/aggs/ticker/{ticker}/range/{multiplier}/{timespan}/{from}/{to})

        :param ticker: 티커 심볼 (예: "AAPL")
        :param multiplier: 시간 단위 배수 (예: 1)
        :param timespan: 시간 단위 ("minute","hour","day","week","month","quarter","year")
        :param from_: 시작일 (YYYY-MM-DD 또는 밀리초 타임스탬프)
        :param to: 종료일 (YYYY-MM-DD 또는 밀리초 타임스탬프)
        :param adjusted: 분할 조정 여부 (기본값: True)
        :param sort: 정렬 방향 ("asc" 또는 "desc")
        :param limit: 최대 결과 수 (기본값: 5000, 최대: 50000)
        :return: {"ticker", "results": [{o,h,l,c,v,vw,t,n},...], "resultsCount", ...}
        """
        params = {
            "adjusted": str(adjusted).lower(),
            "sort": sort,
            "limit": limit,
        }
        return await self._request(
            "GET",
            f"/v2/aggs/ticker/{ticker}/range/{multiplier}/{timespan}/{from_}/{to}",
            params=params,
        )

    async def daily_market_summary(
        self, date: str, adjusted: bool = True
    ) -> Dict[str, Any]:
        """
        특정 날짜 전체 미국 주식 일별 시장 요약 (grouped bars).
        (GET /v2/aggs/grouped/locale/us/market/stocks/{date})

        :param date: 조회 날짜 (YYYY-MM-DD)
        :param adjusted: 분할 조정 여부 (기본값: True)
        :return: {"results": [{T,o,h,l,c,v,vw,t,n},...], ...}
        """
        params = {"adjusted": str(adjusted).lower()}
        return await self._request(
            "GET",
            f"/v2/aggs/grouped/locale/us/market/stocks/{date}",
            params=params,
        )

    async def daily_ticker_summary(
        self, ticker: str, date: str, adjusted: bool = True
    ) -> Dict[str, Any]:
        """
        특정 날짜 단일 티커 일별 시가/종가 조회 (프리마켓·애프터마켓 포함).
        (GET /v1/open-close/{ticker}/{date})

        :param ticker: 티커 심볼 (예: "AAPL")
        :param date: 날짜 (YYYY-MM-DD)
        :param adjusted: 분할 조정 여부 (기본값: True)
        :return: {open, high, low, close, volume, afterHours, preMarket, from, symbol, status}
        """
        params = {"adjusted": str(adjusted).lower()}
        return await self._request(
            "GET", f"/v1/open-close/{ticker}/{date}", params=params
        )

    async def prev_day_bar(
        self, ticker: str, adjusted: bool = True
    ) -> Dict[str, Any]:
        """
        전일 OHLCV 바 데이터 조회.
        (GET /v2/aggs/ticker/{ticker}/prev)

        :param ticker: 티커 심볼 (예: "AAPL")
        :param adjusted: 분할 조정 여부 (기본값: True)
        :return: {"results": [{"T","o","h","l","c","v","vw","t","n"}], ...}
        """
        params = {"adjusted": str(adjusted).lower()}
        return await self._request(
            "GET", f"/v2/aggs/ticker/{ticker}/prev", params=params
        )
