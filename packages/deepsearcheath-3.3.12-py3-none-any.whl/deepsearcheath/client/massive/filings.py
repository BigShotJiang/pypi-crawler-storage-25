from typing import Dict, Any
from ._base import MassiveBase


class Filings(MassiveBase):
    """
    SEC 공시 파일링 엔드포인트.
    10-K, 8-K, 리스크 팩터 등 AI 분석에 적합한 형태로 제공한다.
    """

    async def sec_index(self, **opts) -> Dict[str, Any]:
        """
        SEC EDGAR 전체 파일링 인덱스 조회.
        (GET /vX/reference/sec/filings)

        :param opts: ticker, cik, type, filing_date, period_of_report,
                     include_total_count, order, limit 등
        :return: {"results": [{"accession_number","filing_date","period_of_report",
                               "ticker","cik","company_name","form_type",...},...]}
        """
        return await self._request("GET", "/vX/reference/sec/filings", params=opts)

    async def filing_10k(
        self, accession: str, section: str, **opts
    ) -> Dict[str, Any]:
        """
        10-K 공시의 특정 섹션 텍스트 조회.
        (GET /vX/reference/sec/filings/{accession}/sections/{section})

        :param accession: SEC 접수 번호 (예: "0000320193-23-000106")
        :param section: 섹션 번호 (예: "1A" = Risk Factors, "7" = MD&A)
        :return: 해당 섹션의 텍스트 콘텐츠
        """
        return await self._request(
            "GET",
            f"/vX/reference/sec/filings/{accession}/sections/{section}",
            params=opts,
        )

    async def filing_8k(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        8-K 공시 텍스트 조회 (중요 사건 즉시 공시).
        (GET /vX/reference/sec/filings?type=8-K)

        :param ticker: 티커 심볼
        :param opts: filing_date, order, limit 등
        :return: 파싱된 8-K 텍스트 콘텐츠
        """
        params = {"ticker": ticker, "type": "8-K", **opts}
        return await self._request("GET", "/vX/reference/sec/filings", params=params)

    async def risk_factors(self, ticker: str, **opts) -> Dict[str, Any]:
        """
        SEC 공시 리스크 팩터 조회 (표준화·기계 가독 형식).
        (GET /vX/reference/sec/risk-factors)

        :param ticker: 티커 심볼
        :param opts: 추가 필터 파라미터
        :return: 표준화된 리스크 팩터 목록
        """
        params = {"ticker": ticker, **opts}
        return await self._request(
            "GET", "/vX/reference/sec/risk-factors", params=params
        )

    async def risk_categories(self) -> Dict[str, Any]:
        """
        리스크 팩터 분류 체계(taxonomy) 조회.
        (GET /vX/reference/sec/risk-categories)

        :return: SEC 공시에서 사용하는 전체 리스크 카테고리 목록
        """
        return await self._request("GET", "/vX/reference/sec/risk-categories")
