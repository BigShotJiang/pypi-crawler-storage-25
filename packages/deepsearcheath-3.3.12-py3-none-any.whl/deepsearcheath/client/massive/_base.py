import os
from typing import Optional, Dict, Any
import aiohttp


class MassiveBase:
    """
    Massive REST API 공통 기반 클래스.
    모든 도메인 클라이언트가 상속하여 HTTP 세션·인증·요청 로직을 공유한다.
    """
    BASE_URL = "https://api.massive.com"

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("MASSIVE_API_KEY")
        if not self.api_key:
            raise ValueError("MASSIVE_API_KEY environment variable is not set")
        self.session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self):
        self.session = aiohttp.ClientSession(
            headers={"Authorization": f"Bearer {self.api_key}"}
        )
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
            self.session = None

    async def _request(self, method: str, endpoint: str, **kwargs) -> Dict[str, Any]:
        """
        공통 HTTP 요청 메서드.
        컨텍스트 매니저 내부면 영구 세션을 사용하고,
        외부에서 단독 호출 시 일회성 세션을 생성한다.
        """
        url = f"{self.BASE_URL}{endpoint}"
        if self.session:
            async with self.session.request(method, url, **kwargs) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise aiohttp.ClientResponseError(
                        response.request_info,
                        response.history,
                        status=response.status,
                        message=f"{response.reason}, body={error_text}",
                        headers=response.headers,
                    )
                return await response.json()
        async with aiohttp.ClientSession(
            headers={"Authorization": f"Bearer {self.api_key}"}
        ) as session:
            async with session.request(method, url, **kwargs) as response:
                if not response.ok:
                    error_text = await response.text()
                    raise aiohttp.ClientResponseError(
                        response.request_info,
                        response.history,
                        status=response.status,
                        message=f"{response.reason}, body={error_text}",
                        headers=response.headers,
                    )
                return await response.json()
