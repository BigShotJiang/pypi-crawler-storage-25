"""
심볼별 수집 완료 구간(interval)을 추적하는 CollectionIndex.

collection_index.json 예시:
{
  "AAPL": [["2024-01-01", "2024-06-30"], ["2024-09-01", "2024-12-31"]],
  "MSFT": [["2024-01-01", "2024-12-31"]]
}

구간은 항상 정렬되고 병합된 상태로 유지된다.
"""

import json
import datetime
from pathlib import Path
from typing import List, Tuple, Optional


class CollectionIndex:
    """심볼×기간 수집 이력을 관리한다."""

    def __init__(self, base_dir: str):
        self._path = Path(base_dir) / "collection_index.json"
        self._data: dict = {}
        self._load()

    # ------------------------------------------------------------------
    # I/O
    # ------------------------------------------------------------------
    def _load(self):
        if self._path.exists():
            with open(self._path, "r", encoding="utf-8") as f:
                self._data = json.load(f)

    def save(self):
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(self._data, f, ensure_ascii=False, indent=2)

    # ------------------------------------------------------------------
    # 구간 병합 유틸 (날짜 문자열 "YYYY-MM-DD" 기반)
    # ------------------------------------------------------------------
    @staticmethod
    def _parse(d: str) -> datetime.date:
        return datetime.datetime.strptime(d, "%Y-%m-%d").date()

    @staticmethod
    def _fmt(d: datetime.date) -> str:
        return d.strftime("%Y-%m-%d")

    @staticmethod
    def _merge_intervals(intervals: List[Tuple[datetime.date, datetime.date]]) -> List[Tuple[datetime.date, datetime.date]]:
        """겹치거나 인접한 구간을 병합한다."""
        if not intervals:
            return []
        intervals.sort()
        merged = [intervals[0]]
        for start, end in intervals[1:]:
            prev_start, prev_end = merged[-1]
            # 인접(하루 차이)까지 병합
            if start <= prev_end + datetime.timedelta(days=1):
                merged[-1] = (prev_start, max(prev_end, end))
            else:
                merged.append((start, end))
        return merged

    # ------------------------------------------------------------------
    # 갭 계산
    # ------------------------------------------------------------------
    def get_gaps(self, symbol: str, date_from: str, date_to: str) -> List[Tuple[str, str]]:
        """
        요청 구간에서 아직 수집하지 않은 부분(갭)을 반환한다.

        Returns:
            [("2024-07-01", "2024-08-31"), ("2025-01-01", "2025-03-31")] 형태
            빈 리스트이면 전부 수집 완료.
        """
        req_start = self._parse(date_from)
        req_end = self._parse(date_to)

        raw = self._data.get(symbol, [])
        collected = [(self._parse(s), self._parse(e)) for s, e in raw]
        collected = self._merge_intervals(collected)

        gaps: List[Tuple[datetime.date, datetime.date]] = []
        cursor = req_start

        for seg_start, seg_end in collected:
            # 요청 범위를 벗어난 구간은 무시
            if seg_end < cursor:
                continue
            if seg_start > req_end:
                break

            # cursor ~ seg_start-1 이 갭
            if seg_start > cursor:
                gap_end = min(seg_start - datetime.timedelta(days=1), req_end)
                if cursor <= gap_end:
                    gaps.append((cursor, gap_end))

            cursor = max(cursor, seg_end + datetime.timedelta(days=1))

        # 마지막 구간 이후 남은 부분
        if cursor <= req_end:
            gaps.append((cursor, req_end))

        return [(self._fmt(s), self._fmt(e)) for s, e in gaps]

    def is_fully_covered(self, symbol: str, date_from: str, date_to: str) -> bool:
        return len(self.get_gaps(symbol, date_from, date_to)) == 0

    # ------------------------------------------------------------------
    # 수집 완료 기록
    # ------------------------------------------------------------------
    def mark_collected(self, symbol: str, date_from: str, date_to: str):
        """수집 완료 구간을 추가하고 병합한다."""
        raw = self._data.get(symbol, [])
        intervals = [(self._parse(s), self._parse(e)) for s, e in raw]
        intervals.append((self._parse(date_from), self._parse(date_to)))
        merged = self._merge_intervals(intervals)
        self._data[symbol] = [[self._fmt(s), self._fmt(e)] for s, e in merged]

    # ------------------------------------------------------------------
    # 조회
    # ------------------------------------------------------------------
    def get_intervals(self, symbol: str) -> List[Tuple[str, str]]:
        return [(s, e) for s, e in self._data.get(symbol, [])]

    def symbols(self) -> List[str]:
        return list(self._data.keys())

    def clear(self, symbol: Optional[str] = None):
        """특정 심볼 또는 전체 인덱스를 초기화한다."""
        if symbol:
            self._data.pop(symbol, None)
        else:
            self._data = {}
        self.save()
