import logging
from typing import Optional, Union, List, Dict, Any
import pandas as pd
from ..client.gemini import GeminiClient
from .prompts import METHODOLOGIES, KEYWORD_PROTOCOL_TURN1, KEYWORD_PROTOCOL_TURN2, KEYWORD_PROTOCOL_TURN3

logger = logging.getLogger(__name__)


def _build_data_context(
    data: Union[pd.DataFrame, List[pd.DataFrame]],
    max_rows: int = 50,
) -> str:
    """
    DataFrame을 LLM 프롬프트용 텍스트 컨텍스트로 변환

    - shape, dtypes, describe() 등 메타정보 포함
    - 행이 max_rows 초과 시 head/tail로 축약
    - 복수 DataFrame 지원
    """
    if isinstance(data, pd.DataFrame):
        frames = [("data", data)]
    else:
        frames = [(f"data_{i+1}", df) for i, df in enumerate(data)]

    parts = []
    for name, df in frames:
        section = [f"=== {name} ==="]
        section.append(f"Shape: {df.shape[0]} rows x {df.shape[1]} columns")
        section.append(f"Columns: {list(df.columns)}")
        section.append(f"Dtypes:\n{df.dtypes.to_string()}")

        # 수치형 컬럼이 있으면 통계 요약
        numeric_cols = df.select_dtypes(include='number')
        if not numeric_cols.empty:
            section.append(f"Statistics:\n{numeric_cols.describe().to_string()}")

        # 결측치 정보
        null_counts = df.isnull().sum()
        if null_counts.any():
            section.append(f"Null counts:\n{null_counts[null_counts > 0].to_string()}")

        # 데이터 샘플
        if len(df) <= max_rows:
            section.append(f"Full data:\n{df.to_string()}")
        else:
            half = max_rows // 2
            section.append(f"First {half} rows:\n{df.head(half).to_string()}")
            section.append(f"Last {half} rows:\n{df.tail(half).to_string()}")

        parts.append("\n".join(section))

    return "\n\n".join(parts)


def _resolve_methodology(methodology: Optional[str]) -> Optional[str]:
    """
    methodology 키를 방법론 텍스트로 변환.
    등록된 키가 아니면 문자열 그대로 사용 (커스텀 방법론 지원).
    """
    if methodology is None:
        return None
    return METHODOLOGIES.get(methodology, methodology)


async def gemini(
    prompt: str,
    data: Optional[Union[pd.DataFrame, List[pd.DataFrame]]] = None,
    methodology: Optional[str] = None,
    model: str = "gemini-2.0-flash",
    max_tokens: int = 1024,
    max_rows: int = 50,
    temperature: Optional[float] = None,
    system_instruction: Optional[str] = None,
    api_key: Optional[str] = None,
    raw: bool = False,
) -> str:
    """
    Gemini LLM 단일 호출 (무상태)

    사용 가능한 모델: https://ai.google.dev/gemini-api/docs/models

    Args:
        prompt: 사용자 프롬프트
        data: 분석할 DataFrame 또는 DataFrame 리스트 (Optional).
              전달 시 shape, dtypes, describe(), 데이터 샘플이 자동으로 프롬프트에 첨부됨.
        methodology: 방법론 키 또는 커스텀 방법론 텍스트 (Optional).
                     등록된 키: "keyword" (키워드 추출 방법론).
                     등록되지 않은 문자열은 그대로 방법론 텍스트로 사용됨.
        model: 모델 ID (기본값: 'gemini-2.0-flash')
        max_tokens: 최대 출력 토큰 수 (기본값: 1024)
        max_rows: data 축약 시 포함할 최대 행 수 (기본값: 50, 초과 시 head/tail)
        temperature: 생성 온도 (None이면 API 기본값)
        system_instruction: 시스템 프롬프트 (Optional)
        api_key: Gemini API Key (None이면 GEMINI_API_KEY 환경변수 사용)
        raw: True이면 API 원본 응답 dict 반환, False이면 텍스트만 반환

    Returns:
        생성된 텍스트 (raw=False) 또는 API 원본 응답 dict (raw=True)
    """
    # 프롬프트 조립
    prompt_parts = []

    methodology_text = _resolve_methodology(methodology)
    if methodology_text:
        prompt_parts.append(f"[방법론]\n{methodology_text}")

    if data is not None:
        context = _build_data_context(data, max_rows=max_rows)
        prompt_parts.append(f"[데이터 컨텍스트]\n{context}")

    prompt_parts.append(f"[요청]\n{prompt}")

    full_prompt = "\n\n".join(prompt_parts)

    client = GeminiClient(api_key=api_key)

    async with client:
        response = await client.generate(
            prompt=full_prompt,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            system_instruction=system_instruction,
        )

    if raw:
        return response

    return GeminiClient.extract_text(response)


class GeminiChat:
    """
    Gemini 멀티턴 대화 클래스 (유상태)

    대화 히스토리를 누적하여 후속 질문에서 이전 맥락을 유지한다.
    턴이 쌓일수록 매 요청의 토큰 소비가 증가하므로, 긴 대화 시 reset()으로 초기화 가능.

    사용 가능한 모델: https://ai.google.dev/gemini-api/docs/models

    Usage:
        # 기본 사용
        chat = GeminiChat(system_instruction="한국어로 답변해줘")
        r1 = await chat.send("이 데이터의 추이를 분석해줘", data=df)
        r2 = await chat.send("그 중 감성이 가장 부정적인 날짜는?")

        # 방법론 주입
        chat = GeminiChat()
        r1 = await chat.send("ESS에 대해 키워드를 추출하라", methodology="keyword")

        chat.reset()  # 대화 초기화
    """

    def __init__(
        self,
        model: str = "gemini-2.0-flash",
        max_tokens: int = 1024,
        temperature: Optional[float] = None,
        system_instruction: Optional[str] = None,
        api_key: Optional[str] = None,
        max_rows: int = 50,
    ):
        """
        Args:
            model: 모델 ID (기본값: 'gemini-2.0-flash')
            max_tokens: 최대 출력 토큰 수 (기본값: 1024)
            temperature: 생성 온도 (None이면 API 기본값)
            system_instruction: 시스템 프롬프트 (Optional)
            api_key: Gemini API Key (None이면 GEMINI_API_KEY 환경변수 사용)
            max_rows: data 축약 시 포함할 최대 행 수 (기본값: 50)
        """
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.system_instruction = system_instruction
        self.api_key = api_key
        self.max_rows = max_rows
        self._history: List[Dict[str, Any]] = []

    async def send(
        self,
        prompt: str,
        data: Optional[Union[pd.DataFrame, List[pd.DataFrame]]] = None,
        methodology: Optional[str] = None,
        max_tokens: Optional[int] = None,
        raw: bool = False,
    ) -> str:
        """
        메시지를 보내고 응답을 받는다. 대화 히스토리가 자동 누적된다.

        Args:
            prompt: 사용자 프롬프트
            data: 분석할 DataFrame 또는 DataFrame 리스트 (Optional).
                  첫 턴에 전달하면 이후 턴에서도 맥락이 유지됨.
            methodology: 방법론 키 또는 커스텀 방법론 텍스트 (Optional).
                         등록된 키: "keyword" (키워드 추출 방법론).
                         등록되지 않은 문자열은 그대로 방법론 텍스트로 사용됨.
            max_tokens: 이 턴의 최대 출력 토큰 (None이면 인스턴스 기본값 사용)
            raw: True이면 API 원본 응답 dict 반환

        Returns:
            생성된 텍스트 (raw=False) 또는 API 원본 응답 dict (raw=True)
        """
        # 프롬프트 조립
        prompt_parts = []

        methodology_text = _resolve_methodology(methodology)
        if methodology_text:
            prompt_parts.append(f"[방법론]\n{methodology_text}")

        if data is not None:
            context = _build_data_context(data, max_rows=self.max_rows)
            prompt_parts.append(f"[데이터 컨텍스트]\n{context}")

        prompt_parts.append(f"[요청]\n{prompt}")

        user_text = "\n\n".join(prompt_parts)

        self._history.append({
            "role": "user",
            "parts": [{"text": user_text}]
        })

        client = GeminiClient(api_key=self.api_key)
        tokens = max_tokens if max_tokens is not None else self.max_tokens

        async with client:
            response = await client.generate_multiturn(
                contents=self._history,
                model=self.model,
                max_tokens=tokens,
                temperature=self.temperature,
                system_instruction=self.system_instruction,
            )

        reply_text = GeminiClient.extract_text(response)

        self._history.append({
            "role": "model",
            "parts": [{"text": reply_text}]
        })

        if raw:
            return response

        return reply_text

    def reset(self):
        """대화 히스토리 초기화"""
        self._history.clear()

    @property
    def history(self) -> List[Dict[str, Any]]:
        """현재 대화 히스토리 반환 (읽기 전용)"""
        return list(self._history)

    @property
    def turn_count(self) -> int:
        """현재까지의 턴 수 (user+model 각각 1턴)"""
        return len(self._history) // 2


def _parse_keyword_list(text: str) -> List[str]:
    """
    LLM 응답에서 keyword_list = [...] 형태의 파이썬 리스트를 파싱.
    """
    import re
    import ast

    # keyword_list = [...] 패턴 추출
    match = re.search(r'keyword_list\s*=\s*\[', text)
    if match:
        start = match.start()
        # 대괄호 짝 맞추기
        bracket_start = text.index('[', start)
        depth = 0
        for i in range(bracket_start, len(text)):
            if text[i] == '[':
                depth += 1
            elif text[i] == ']':
                depth -= 1
                if depth == 0:
                    list_str = text[bracket_start:i + 1]
                    try:
                        return ast.literal_eval(list_str)
                    except (ValueError, SyntaxError):
                        break

    # fallback: 코드블록 내 리스트 추출
    code_match = re.search(r'```(?:python)?\s*\n.*?keyword_list\s*=\s*(\[.*?\])', text, re.DOTALL)
    if code_match:
        try:
            return ast.literal_eval(code_match.group(1))
        except (ValueError, SyntaxError):
            pass

    logger.warning("Failed to parse keyword_list from LLM response")
    return []


async def extract_keywords(
    data: Union[pd.DataFrame, List[pd.DataFrame]],
    system_instruction: str = "헤지펀드 기업분석을 위한 자료를 작성해야 한다. "
        "제시되는 데이터를 바탕으로 해당 데이터로 정의되는 루트 메인 키워드에 대한 "
        "구성 투자종목 분석을 수행할 것이다.",
    model: str = "gemini-2.0-flash",
    max_tokens: int = 2048 * 4,
    max_rows: int = 50,
    temperature: Optional[float] = None,
    api_key: Optional[str] = None,
    verbose: bool = False,
) -> List[str]:
    """
    DataFrame에서 HAP 방법론 기반 키워드를 추출하여 파이썬 리스트로 반환.

    3턴 프로토콜:
        1턴: 데이터 분석 → Root 식별, 주제/이벤트 정리, 기술 용어 나열
        2턴: HAP 방법론 적용 → 5개 검증 질문 통과 여부 표 + 최종 채택
        3턴: 파이썬 리스트 출력

    사용 가능한 모델: https://ai.google.dev/gemini-api/docs/models

    Args:
        data: 분석할 DataFrame 또는 DataFrame 리스트 (뉴스 데이터 등)
        system_instruction: 시스템 프롬프트 (기본값: 헤지펀드 기업분석 컨텍스트)
        model: 모델 ID (기본값: 'gemini-2.0-flash')
        max_tokens: 최대 출력 토큰 수 (기본값: 8192)
        max_rows: data 축약 시 포함할 최대 행 수 (기본값: 50)
        temperature: 생성 온도 (None이면 API 기본값)
        api_key: Gemini API Key (None이면 GEMINI_API_KEY 환경변수 사용)
        verbose: True이면 각 턴의 응답을 로깅

    Returns:
        추출된 키워드 리스트 (List[str])

    Usage:
        keywords = await ds.extract_keywords(data=news_df)
        # ['LFP', 'NCA', '실리콘 음극재', 'BMS', '플로우 배터리', ...]

        # 모델/시스템 프롬프트 커스텀
        keywords = await ds.extract_keywords(
            data=df,
            model="gemini-2.5-pro",
            system_instruction="반도체 산업 분석을 수행한다.",
        )
    """
    chat = GeminiChat(
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        system_instruction=system_instruction,
        api_key=api_key,
        max_rows=max_rows,
    )

    # 1턴: 데이터 분석 — Root 식별, 주제/이벤트, 기술 용어 나열
    r1 = await chat.send(KEYWORD_PROTOCOL_TURN1, data=data)
    if verbose:
        logger.info(f"[extract_keywords] Turn 1:\n{r1}")

    # 2턴: HAP 방법론 적용 — 검증 테이블 + 최종 채택
    r2 = await chat.send(KEYWORD_PROTOCOL_TURN2, methodology="keyword")
    if verbose:
        logger.info(f"[extract_keywords] Turn 2:\n{r2}")

    # 3턴: 파이썬 리스트 출력
    r3 = await chat.send(KEYWORD_PROTOCOL_TURN3)
    if verbose:
        logger.info(f"[extract_keywords] Turn 3:\n{r3}")

    return _parse_keyword_list(r3)
