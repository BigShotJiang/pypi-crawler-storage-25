"""JLFramework Web Namespace.

This namespace contains web application components for building
FastAPI-based web applications with multi-tenant support.

Components:
    - restrict_access_middleware: Multi-tenant access control middleware
    - get_tenant_id: Extract tenant ID from request
    - database_middleware: Database session lifecycle middleware
    - initialize_database: Initialize database from connection string
    - initialize_database_from_azure: Initialize database from Azure config
    - get_db: FastAPI dependency for database sessions
    - get_db_session: Create new database session
    - close_db_session: Close database session
    - get_request_db: Get database session from request state
    - Settings: Pydantic settings with environment variable support
    - get_settings: Get cached settings instance

Example:
    ```python
    from fastapi import FastAPI, Depends, Request
    from jlframework.web import (
        restrict_access_middleware,
        database_middleware,
        initialize_database,
        get_db,
        get_tenant_id
    )
    
    app = FastAPI()
    
    # Initialize database
    initialize_database("postgresql://user:pass@localhost/db")
    
    # Add middleware
    app.middleware("http")(restrict_access_middleware)
    app.middleware("http")(database_middleware)
    
    @app.get("/items")
    async def get_items(request: Request, db: Session = Depends(get_db)):
        tenant_id = get_tenant_id(request)
        # Query tenant-specific data
        items = db.query(Item).filter(Item.tenant_id == tenant_id).all()
        return items
    ```
"""

from jlframework.web.middleware import restrict_access_middleware, get_tenant_id
from jlframework.web.database import (
    initialize_database,
    get_db,
    get_db_session,
    close_db_session,
    get_request_db,
    database_middleware,
)
from jlframework.web.azure_db import initialize_database_from_azure
from jlframework.web.config import Settings, get_settings

__all__ = [
    # Middleware
    "restrict_access_middleware",
    "get_tenant_id",
    "database_middleware",

    # Database
    "initialize_database",
    "initialize_database_from_azure",
    "get_db",
    "get_db_session",
    "close_db_session",
    "get_request_db",

    # Configuration
    "Settings",
    "get_settings",
]
