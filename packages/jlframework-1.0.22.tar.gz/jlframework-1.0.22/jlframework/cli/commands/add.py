"""Add command for jlframework CLI."""

import json
from pathlib import Path

import click

from jlframework.cli.utils.template_manager import TemplateManager
from jlframework.cli.utils.validators import validate_jlframework_project


@click.command(name="add")
@click.argument("template_name", type=click.Choice([
    "backend",
    "frontend-embedded",
    "frontend-features",
    "frontend-marketplace"
], case_sensitive=False))
@click.option("--skip-install", is_flag=True, help="Skip dependency installation")
def add_command(template_name, skip_install):
    """Add a template to the current project.

    Available templates:
    - backend: FastAPI backend with domain-driven design
    - frontend-embedded: Vue.js embedded application
    - frontend-features: Vue.js micro-frontend features
    - frontend-marketplace: Vue.js marketplace application

    Example:
        jlframework add backend
        jlframework add frontend-embedded --skip-install
    """

    # Validate we're in a JLFramework project
    if not validate_jlframework_project():
        click.echo(click.style(
            "[ERROR] Not a JLFramework project. Run 'jlframework init' first.",
            fg="red"
        ))
        return

    # Load project config
    config_file = Path.cwd() / ".jlframework.json"
    with open(config_file, "r") as f:
        config = json.load(f)

    # Check if template already exists
    if template_name in config.get("templates", {}):
        if not click.confirm(f"\n[WARN] Template '{template_name}' already exists. Overwrite?"):
            click.echo("Cancelled.")
            return

    click.echo(
        f"\n[*] Adding {click.style(template_name, fg='cyan', bold=True)} template...")

    # Initialize template manager
    try:
        manager = TemplateManager(template_name)
    except ValueError as e:
        click.echo(click.style(f"[ERROR] {str(e)}", fg="red"))
        return

    # Gather template-specific configuration
    template_config = manager.prompt_configuration()

    # Copy template files
    click.echo("\n[*] Copying template files...")
    destination = Path.cwd() / manager.get_destination_dir()

    try:
        manager.copy_template(destination, template_config)
    except Exception as e:
        click.echo(click.style(
            f"[ERROR] Failed to copy template: {str(e)}", fg="red"))
        return

    # Update project config
    config.setdefault("templates", {})[template_name] = {
        "installed": True,
        **template_config
    }

    with open(config_file, "w") as f:
        json.dump(config, f, indent=2)

    click.echo(click.style(
        f"\n[SUCCESS] Template '{template_name}' added successfully!", fg="green", bold=True))

    # Install dependencies
    if not skip_install:
        if click.confirm("\n[*] Install dependencies?", default=True):
            manager.install_dependencies(destination)
    else:
        click.echo(click.style(
            "\n[WARN] Skipped dependency installation", fg="yellow"))

    # Show next steps
    manager.show_next_steps(destination)
