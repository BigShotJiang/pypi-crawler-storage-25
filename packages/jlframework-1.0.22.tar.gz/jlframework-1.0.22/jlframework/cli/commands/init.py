"""Init command for jlframework CLI."""

import json
import subprocess
from pathlib import Path

import click

from jlframework.cli.utils.file_operations import create_directory
from jlframework.cli.utils.validators import validate_project_name


@click.command(name="init")
@click.argument("project_name", required=False)
@click.option("--no-git", is_flag=True, help="Skip git initialization")
def init_command(project_name, no_git):
    """Initialize a new JLFramework project.

    Creates a new project directory with configuration files and structure.

    Example:
        jlframework init my-awesome-app
    """

    # Prompt for project name if not provided
    if not project_name:
        project_name = click.prompt("Project name", type=str)

    # Validate project name
    if not validate_project_name(project_name):
        click.echo(click.style(
            "[ERROR] Invalid project name. Use only letters, numbers, hyphens, and underscores.",
            fg="red"
        ))
        return

    # Create project directory
    project_path = Path.cwd() / project_name
    if project_path.exists():
        click.echo(click.style(
            f"[ERROR] Directory '{project_name}' already exists", fg="red"))
        return

    click.echo(
        f"\n[*] Creating project: {click.style(project_name, fg='cyan', bold=True)}")
    create_directory(project_path)

    # Gather project metadata
    click.echo("\n[*] Project configuration:")
    description = click.prompt("  Description", default="", show_default=False)
    author = click.prompt("  Author name", default="", show_default=False)
    version = click.prompt("  Version", default="1.0.0")

    # Create .jlframework.json
    config = {
        "project_name": project_name,
        "description": description,
        "author": author,
        "version": version,
        "templates": {}
    }

    config_file = project_path / ".jlframework.json"
    with open(config_file, "w") as f:
        json.dump(config, f, indent=2)

    # Create README.md
    readme_content = f"""# {project_name}

{description}

## Getting Started

This project was created with [JLFramework](https://github.com/jlframework/jlframework).

### Add Backend
```bash
jlframework add backend
```

### Add Frontend
```bash
jlframework add frontend-embedded
jlframework add frontend-features
jlframework add frontend-marketplace
```

## Project Structure

```
{project_name}/
├── backend/           # FastAPI backend (add with: jlframework add backend)
├── frontend/          # Vue.js frontends
│   ├── embedded/     # Embedded app (add with: jlframework add frontend-embedded)
│   ├── features/     # Micro-frontend features (add with: jlframework add frontend-features)
│   └── marketplace/  # Marketplace app (add with: jlframework add frontend-marketplace)
└── .jlframework.json # Project configuration
```

## Author

{author}

## Version

{version}
"""

    readme_file = project_path / "README.md"
    readme_file.write_text(readme_content, encoding='utf-8')

    # Create .gitignore
    gitignore_content = """# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
ENV/
.venv
*.egg-info/
dist/
build/

# Environment
.env
.env.local
.env.*.local
.env.development
.env.production

# IDEs
.vscode/
.idea/
*.swp
*.swo
*.sublime-*

# OS
.DS_Store
Thumbs.db
*.log

# Node
node_modules/
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.pnpm-debug.log*

# Build
dist/
build/
*.tsbuildinfo

# Testing
.coverage
htmlcov/
.pytest_cache/
"""

    gitignore_file = project_path / ".gitignore"
    gitignore_file.write_text(gitignore_content, encoding='utf-8')

    # Initialize git
    if not no_git:
        try:
            subprocess.run(
                ["git", "init"],
                cwd=project_path,
                check=True,
                capture_output=True,
                text=True
            )
            subprocess.run(
                ["git", "add", "."],
                cwd=project_path,
                check=True,
                capture_output=True,
                text=True
            )
            subprocess.run(
                ["git", "commit", "-m", "Initial commit from jlframework"],
                cwd=project_path,
                check=True,
                capture_output=True,
                text=True
            )
            click.echo(click.style(
                "  [OK] Git repository initialized", fg="green"))
        except (subprocess.CalledProcessError, FileNotFoundError):
            click.echo(click.style(
                "  [WARN] Git initialization skipped (git not found)", fg="yellow"))

    click.echo(click.style(
        f"\n[SUCCESS] Project '{project_name}' created successfully!", fg="green", bold=True))
    click.echo(f"\n[*] Next steps:")
    click.echo(f"  cd {project_name}")
    click.echo(f"  jlframework add backend")
    click.echo(f"  jlframework add frontend-embedded")
    click.echo(
        f"\n[TIP] Run 'jlframework list' to see all available templates")
