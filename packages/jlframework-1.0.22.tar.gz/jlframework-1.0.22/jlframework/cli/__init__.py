"""CLI module for jlframework."""
