"""Template management utilities for jlframework CLI."""

import shutil
import subprocess
from pathlib import Path
from typing import Any, Dict, List

import click
from jinja2 import Environment, FileSystemLoader, select_autoescape


class TemplateManager:
    """Manages template operations."""

    TEMPLATE_CONFIGS = {
        "backend": {
            "destination": "backend",
            "description": "FastAPI backend with domain-driven design",
            "prompts": [
                {"key": "app_name", "prompt": "Application name",
                    "default": "FastAPI Boilerplate"},
                {"key": "database", "prompt": "Database type", "type": "choice",
                 "choices": ["mssql", "postgresql", "mysql"], "default": "mssql"},
                {"key": "azure_enabled", "prompt": "Enable Azure integration",
                    "type": "bool", "default": True},
                {"key": "audit_enabled", "prompt": "Enable audit logging",
                    "type": "bool", "default": True},
            ]
        },
        "frontend-embedded": {
            "destination": "frontend/embedded",
            "description": "Vue.js embedded application",
            "prompts": [
                {"key": "app_name", "prompt": "Application name",
                    "default": "Frontend App"},
                {"key": "api_url", "prompt": "API URL",
                    "default": "http://localhost:8000"},
                {"key": "oidc_enabled", "prompt": "Enable OIDC authentication",
                    "type": "bool", "default": True},
                {"key": "port", "prompt": "Development port", "default": "3000"},
            ]
        },
        "frontend-features": {
            "destination": "frontend/features",
            "description": "Vue.js micro-frontend features",
            "prompts": [
                {"key": "app_name", "prompt": "Application name",
                    "default": "Features App"},
                {"key": "api_url", "prompt": "API URL",
                    "default": "http://localhost:8000"},
            ]
        },
        "frontend-marketplace": {
            "destination": "frontend/marketplace",
            "description": "Vue.js marketplace application",
            "prompts": [
                {"key": "app_name", "prompt": "Application name",
                    "default": "Marketplace App"},
                {"key": "api_url", "prompt": "API URL",
                    "default": "http://localhost:8000"},
                {"key": "oidc_enabled", "prompt": "Enable OIDC authentication",
                    "type": "bool", "default": True},
            ]
        }
    }

    def __init__(self, template_name: str):
        """Initialize template manager.

        Args:
            template_name: Name of the template to manage

        Raises:
            ValueError: If template name is invalid
        """
        if template_name not in self.TEMPLATE_CONFIGS:
            raise ValueError(f"Unknown template: {template_name}")

        self.template_name = template_name
        self.config = self.TEMPLATE_CONFIGS[template_name]
        self.template_dir = Path(
            __file__).parent.parent.parent / "templates" / template_name

    def get_destination_dir(self) -> str:
        """Get destination directory for template.

        Returns:
            Destination directory path
        """
        return self.config["destination"]

    def prompt_configuration(self) -> Dict[str, Any]:
        """Prompt user for template configuration.

        Returns:
            Dictionary of configuration values
        """
        config = {}

        click.echo("\n[*] Configuration:")
        for prompt_config in self.config["prompts"]:
            key = prompt_config["key"]
            prompt_text = f"  {prompt_config['prompt']}"
            default = prompt_config.get("default")

            if prompt_config.get("type") == "bool":
                value = click.confirm(prompt_text, default=default)
            elif prompt_config.get("type") == "choice":
                value = click.prompt(
                    prompt_text,
                    type=click.Choice(prompt_config["choices"]),
                    default=default
                )
            else:
                value = click.prompt(prompt_text, default=default)

            config[key] = value

        return config

    def copy_template(self, destination: Path, config: Dict[str, Any]) -> None:
        """Copy template files with variable replacement.

        Args:
            destination: Destination directory path
            config: Configuration dictionary for variable replacement
        """
        # Check if template directory exists
        if not self.template_dir.exists():
            click.echo(click.style(
                f"[WARN] Template directory not found: {self.template_dir}",
                fg="yellow"
            ))
            click.echo(click.style(
                "   Creating basic template structure...",
                fg="yellow"
            ))
            self._create_basic_template(destination, config)
            return

        # Create destination directory
        destination.mkdir(parents=True, exist_ok=True)

        # Setup Jinja2 environment
        env = Environment(
            loader=FileSystemLoader(self.template_dir),
            autoescape=select_autoescape(),
            keep_trailing_newline=True,
        )

        # Add custom filters
        env.filters['lower'] = str.lower
        env.filters['upper'] = str.upper

        # Walk through template files
        for template_file in self.template_dir.rglob("*"):
            if template_file.is_file() and not self._should_skip(template_file):
                relative_path = template_file.relative_to(self.template_dir)
                dest_file = destination / relative_path

                # Create parent directories
                dest_file.parent.mkdir(parents=True, exist_ok=True)

                # Process template if text file
                if self._is_text_file(template_file):
                    try:
                        # Jinja expects POSIX-style relative paths for nested templates.
                        template = env.get_template(relative_path.as_posix())
                        content = template.render(**config)
                        dest_file.write_text(content, encoding='utf-8')
                    except Exception:
                        # If template rendering fails, copy as-is
                        shutil.copy2(template_file, dest_file)
                else:
                    # Copy binary files as-is
                    shutil.copy2(template_file, dest_file)

        # Handle .env.example -> .env conversion for frontend templates
        env_example = destination / '.env.example'
        env_file = destination / '.env'
        if env_example.exists() and not env_file.exists():
            shutil.copy2(env_example, env_file)
            click.echo(click.style(
                f"   Created .env file from .env.example",
                fg="green"
            ))

    def _create_basic_template(self, destination: Path, config: Dict[str, Any]) -> None:
        """Create a basic template structure when template files don't exist.

        Args:
            destination: Destination directory path
            config: Configuration dictionary
        """
        destination.mkdir(parents=True, exist_ok=True)

        # Create a basic README
        readme_content = f"""# {config.get('app_name', 'Application')}

This is a placeholder for the {self.template_name} template.

## Note

The full template files are not included in this installation.
Please copy your boilerplate files to: `jlframework/templates/{self.template_name}/`

## Configuration

{chr(10).join(f'- {k}: {v}' for k, v in config.items())}
"""
        readme_file = destination / "README.md"
        readme_file.write_text(readme_content, encoding='utf-8')

        click.echo(click.style(
            f"  [INFO] Created placeholder structure at {destination}",
            fg="blue"
        ))

    def install_dependencies(self, destination: Path) -> None:
        """Install template dependencies.

        Args:
            destination: Template destination directory
        """
        if self.template_name == "backend":
            # Install Python dependencies
            requirements_file = destination / "requirements.txt"
            if requirements_file.exists():
                click.echo("\n[*] Installing Python dependencies...")
                try:
                    subprocess.run(
                        ["pip", "install", "-r", str(requirements_file)],
                        check=True,
                        capture_output=True,
                        text=True
                    )
                    click.echo(click.style(
                        "  ✓ Dependencies installed", fg="green"))
                except subprocess.CalledProcessError as e:
                    click.echo(click.style(
                        f"  [WARN] Failed to install dependencies: {e}", fg="yellow"))
                except FileNotFoundError:
                    click.echo(click.style(
                        "  [WARN] pip not found", fg="yellow"))

        elif self.template_name.startswith("frontend"):
            # Install npm dependencies
            package_json = destination / "package.json"
            if package_json.exists():
                click.echo("\n[*] Installing npm dependencies...")
                try:
                    subprocess.run(
                        ["npm", "install"],
                        cwd=destination,
                        check=True,
                        capture_output=True,
                        text=True
                    )
                    click.echo(click.style(
                        "  ✓ Dependencies installed", fg="green"))
                except subprocess.CalledProcessError as e:
                    click.echo(click.style(
                        f"  [WARN] Failed to install dependencies: {e}", fg="yellow"))
                except FileNotFoundError:
                    click.echo(click.style(
                        "  [WARN] npm not found", fg="yellow"))

    def show_next_steps(self, destination: Path) -> None:
        """Show next steps after template installation.

        Args:
            destination: Template destination directory
        """
        click.echo(f"\n🎯 Next steps:")

        if self.template_name == "backend":
            click.echo(f"  cd {destination}")
            click.echo("  # Configure environment variables")
            if (destination / ".env.example").exists():
                click.echo("  cp .env.example .env")
            click.echo("  # Edit .env with your configuration")
            click.echo("  # Run the application")
            click.echo("  python main.py")

        elif self.template_name.startswith("frontend"):
            click.echo(f"  cd {destination}")
            click.echo("  # Run development server")
            click.echo("  npm run dev")
            click.echo("  # Build for production")
            click.echo("  npm run build")

    def _should_skip(self, file_path: Path) -> bool:
        """Check if file should be skipped.

        Args:
            file_path: File path to check

        Returns:
            True if file should be skipped
        """
        skip_patterns = [
            "__pycache__",
            ".pyc",
            ".pyo",
            ".git",
            ".DS_Store",
            "node_modules",
            ".vscode",
            ".idea",
        ]
        return any(pattern in str(file_path) for pattern in skip_patterns)

    def _is_text_file(self, file_path: Path) -> bool:
        """Check if file is a text file.

        Args:
            file_path: File path to check

        Returns:
            True if file is a text file
        """
        text_extensions = {
            ".py", ".txt", ".md", ".json", ".yaml", ".yml",
            ".toml", ".ini", ".cfg", ".conf", ".env",
            ".js", ".ts", ".vue", ".html", ".css", ".scss",
            ".sh", ".bash", ".dockerfile", ".gitignore",
        }
        return file_path.suffix.lower() in text_extensions or file_path.name.lower() in {
            "dockerfile", "makefile", "readme", "license"
        }


def get_available_templates() -> List[Dict[str, str]]:
    """Get list of available templates.

    Returns:
        List of template dictionaries with name and description
    """
    return [
        {
            "name": name,
            "description": config["description"]
        }
        for name, config in TemplateManager.TEMPLATE_CONFIGS.items()
    ]
