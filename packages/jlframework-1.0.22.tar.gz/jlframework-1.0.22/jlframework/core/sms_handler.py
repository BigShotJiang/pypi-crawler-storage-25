"""SMS Handler Module for Twilio integration.

This module provides SMS functionality using Twilio API with credentials
loaded from environment variables or Azure App Configuration.
"""

import os
from typing import Optional
from twilio.rest import Client
from twilio.base.exceptions import TwilioRestException


class SMSHandler:
    """Handler for sending SMS messages via Twilio.

    Credentials are loaded from environment variables:
    - TWILIO_ACCOUNT_SID: Twilio account SID
    - TWILIO_AUTH_TOKEN: Twilio authentication token
    - TWILIO_MESSAGING_SERVICE_SID: Twilio messaging service SID
    - TWILIO_FROM_NUMBER: (Optional) Default sender phone number

    Example:
        ```python
        from jlframework import SMSHandler

        # Initialize handler (credentials from environment)
        sms = SMSHandler()

        # Send SMS
        result = sms.send_sms(
            to_number="+1234567890",
            message_body="Your verification code is 123456",
            sender="MyApp"
        )

        if result['success']:
            print(f"SMS sent! SID: {result['sid']}")
        else:
            print(f"Failed: {result['error']}")
        ```
    """

    def __init__(
        self,
        account_sid: Optional[str] = None,
        auth_token: Optional[str] = None,
        messaging_service_sid: Optional[str] = None,
        from_number: Optional[str] = None
    ):
        """Initialize SMS handler with Twilio credentials.

        Args:
            account_sid: Twilio account SID (defaults to TWILIO_ACCOUNT_SID env var)
            auth_token: Twilio auth token (defaults to TWILIO_AUTH_TOKEN env var)
            messaging_service_sid: Messaging service SID (defaults to TWILIO_MESSAGING_SERVICE_SID env var)
            from_number: Default sender number (defaults to TWILIO_FROM_NUMBER env var)

        Raises:
            ValueError: If required credentials are not provided
        """
        self.account_sid = account_sid or os.getenv("TWILIO_ACCOUNT_SID")
        self.auth_token = auth_token or os.getenv("TWILIO_AUTH_TOKEN")
        self.messaging_service_sid = messaging_service_sid or os.getenv(
            "TWILIO_MESSAGING_SERVICE_SID")
        self.from_number = from_number or os.getenv("TWILIO_FROM_NUMBER")

        if not self.account_sid or not self.auth_token:
            raise ValueError(
                "Twilio credentials not found. Please set TWILIO_ACCOUNT_SID and "
                "TWILIO_AUTH_TOKEN environment variables or pass them to constructor."
            )

        if not self.messaging_service_sid and not self.from_number:
            raise ValueError(
                "Either TWILIO_MESSAGING_SERVICE_SID or TWILIO_FROM_NUMBER must be provided."
            )

        self.client = Client(self.account_sid, self.auth_token)

    def send_sms(
        self,
        to_number: str,
        message_body: str,
        sender: Optional[str] = None,
        from_number: Optional[str] = None
    ) -> dict:
        """Send an SMS message via Twilio.

        Args:
            to_number: Recipient phone number (E.164 format recommended, e.g., +1234567890)
            message_body: Message content to send
            sender: Optional sender name (only used if messaging_service_sid is set)
            from_number: Optional sender phone number (overrides default)

        Returns:
            Dictionary with result:
                - success (bool): Whether the SMS was sent successfully
                - sid (str): Twilio message SID if successful
                - status (str): Message status if successful
                - error (str): Error message if failed

        Example:
            ```python
            result = sms.send_sms(
                to_number="+1234567890",
                message_body="Hello from JLFramework!",
                sender="MyApp"
            )
            ```
        """
        try:
            # Prepare message parameters
            message_params = {
                "body": message_body,
                "to": to_number
            }

            # Use messaging service or direct number
            if self.messaging_service_sid:
                message_params["messaging_service_sid"] = self.messaging_service_sid
            else:
                message_params["from_"] = from_number or self.from_number

            # Send message
            message = self.client.messages.create(**message_params)

            return {
                "success": True,
                "sid": message.sid,
                "status": message.status,
                "to": message.to,
                "from": message.from_,
                "error": None
            }

        except TwilioRestException as e:
            return {
                "success": False,
                "sid": None,
                "status": None,
                "error": f"Twilio error: {e.msg} (Code: {e.code})"
            }
        except Exception as e:
            return {
                "success": False,
                "sid": None,
                "status": None,
                "error": f"Unexpected error: {str(e)}"
            }

    def get_sms_details(self, sid: str) -> dict:
        """Get details of a sent SMS message.

        Args:
            sid: Twilio message SID

        Returns:
            Dictionary with message details:
                - success (bool): Whether the lookup was successful
                - sid (str): Message SID
                - status (str): Current message status
                - to (str): Recipient number
                - from (str): Sender number
                - body (str): Message content
                - date_sent (datetime): When message was sent
                - error_code (str): Error code if failed
                - error_message (str): Error message if failed

        Example:
            ```python
            details = sms.get_sms_details("SM1234567890abcdef")
            if details['success']:
                print(f"Status: {details['status']}")
            ```
        """
        try:
            message = self.client.messages(sid).fetch()

            return {
                "success": True,
                "sid": message.sid,
                "status": message.status,
                "to": message.to,
                "from": message.from_,
                "body": message.body,
                "date_sent": message.date_sent,
                "date_created": message.date_created,
                "date_updated": message.date_updated,
                "error_code": message.error_code,
                "error_message": message.error_message,
                "price": message.price,
                "price_unit": message.price_unit,
                "direction": message.direction,
                "num_segments": message.num_segments
            }

        except TwilioRestException as e:
            return {
                "success": False,
                "error": f"Twilio error: {e.msg} (Code: {e.code})"
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"Unexpected error: {str(e)}"
            }

    def send_bulk_sms(
        self,
        recipients: list[str],
        message_body: str,
        sender: Optional[str] = None
    ) -> dict:
        """Send SMS to multiple recipients.

        Args:
            recipients: List of recipient phone numbers
            message_body: Message content to send
            sender: Optional sender name

        Returns:
            Dictionary with results:
                - total (int): Total number of recipients
                - successful (int): Number of successful sends
                - failed (int): Number of failed sends
                - results (list): List of individual results

        Example:
            ```python
            results = sms.send_bulk_sms(
                recipients=["+1234567890", "+0987654321"],
                message_body="Bulk notification",
                sender="MyApp"
            )
            print(f"Sent {results['successful']}/{results['total']}")
            ```
        """
        results = []
        successful = 0
        failed = 0

        for recipient in recipients:
            result = self.send_sms(
                to_number=recipient,
                message_body=message_body,
                sender=sender
            )
            results.append(result)

            if result["success"]:
                successful += 1
            else:
                failed += 1

        return {
            "total": len(recipients),
            "successful": successful,
            "failed": failed,
            "results": results
        }
