"""GraphQL Client Module for jlframework.

This module provides GraphQL API integration with OAuth 2.0 support and token management.
"""

import httpx
from httpx import Response, AsyncClient
from typing import Optional, Dict, Any
import base64
import asyncio
from datetime import datetime, timedelta
import json
import os


class TokenGenerationError(Exception):
    """Custom exception for token generation errors."""
    pass


class GraphQLServiceManager:
    """GraphQL service manager with OAuth 2.0 authentication and token caching.

    This class provides a complete GraphQL client with:
    - OAuth 2.0 client credentials flow
    - Automatic token refresh
    - Token caching with expiration
    - Async HTTP client management

    Credentials can be loaded from environment variables or Azure App Configuration:
    - GRAPHQL_ENDPOINT: GraphQL API endpoint
    - GRAPHQL_CLIENT_ID: OAuth client ID
    - GRAPHQL_CLIENT_SECRET: OAuth client secret
    - GRAPHQL_TOKEN_URL: OAuth token endpoint
    - GRAPHQL_SCOPE: OAuth scope (optional)

    Example:
        ```python
        from jlframework import GraphQLServiceManager

        # Initialize with config
        graphql = GraphQLServiceManager(config, tenant_id="your-tenant")

        # Execute query
        query = '''
            query GetUsers {
                users {
                    id
                    name
                    email
                }
            }
        '''

        response = await graphql.execute(query)
        data = response.json()

        # Close client when done
        await graphql.aclose()
        ```
    """

    def __init__(self, config=None, tenant_id: str = None, **kwargs):
        """Initialize GraphQL service manager.

        Args:
            config: Configuration object with graphql_config attribute (optional)
            tenant_id: Tenant ID for multi-tenant applications
            **kwargs: Direct configuration parameters:
                - endpoint: GraphQL endpoint URL
                - client_id: OAuth client ID
                - client_secret: OAuth client secret
                - token_url: OAuth token URL
                - scope: OAuth scope (optional)
                - headers: Custom headers dict (optional)

        Raises:
            ValueError: If required configuration is missing
        """
        # Load from config object or kwargs or environment
        if config and hasattr(config, 'graphql_config'):
            graphql_config = json.loads(config.graphql_config)
        else:
            graphql_config = kwargs

        self.endpoint = graphql_config.get(
            "endpoint") or os.getenv("GRAPHQL_ENDPOINT")
        self.headers = graphql_config.get(
            "headers", {"Content-Type": "application/json"})
        self.tenant_id = tenant_id or os.getenv("GRAPHQL_TENANT_ID")
        self._client: AsyncClient = None

        # OAuth 2.0 configuration
        self.client_id = graphql_config.get(
            "client_id") or os.getenv("GRAPHQL_CLIENT_ID")
        self.client_secret = graphql_config.get(
            "client_secret") or os.getenv("GRAPHQL_CLIENT_SECRET")
        self.token_url = graphql_config.get(
            "token_url") or os.getenv("GRAPHQL_TOKEN_URL")
        self.scope = graphql_config.get("scope") or os.getenv("GRAPHQL_SCOPE")

        # Token management
        self._access_token: Optional[str] = None
        self._token_expires_at: Optional[datetime] = None
        self._token_lock = asyncio.Lock()

        if not self.endpoint:
            raise ValueError(
                "GraphQL endpoint is required. Set GRAPHQL_ENDPOINT or pass endpoint parameter.")

    async def _generate_oauth_token(self) -> str:
        """Generate an OAuth 2.0 access token using client credentials flow.

        Returns:
            str: The access token string

        Raises:
            ValueError: If OAuth configuration is missing
            httpx.HTTPStatusError: If token request fails
            TokenGenerationError: If token generation fails
        """
        if not self.is_oauth_configured():
            raise ValueError(
                "OAuth configuration incomplete. client_id, client_secret, and token_url are required."
            )

        # Create basic auth header
        credentials = f"{self.client_id}:{self.client_secret}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()

        headers = {
            "Authorization": f"Basic {encoded_credentials}",
            "Content-Type": "application/x-www-form-urlencoded"
        }

        # Prepare the token request data
        data = {"grant_type": "client_credentials"}

        if self.scope:
            data["scope"] = self.scope

        self._ensure_client()

        try:
            response = await self._client.post(
                self.token_url,
                headers=headers,
                data=data
            )
            response.raise_for_status()

            token_data = response.json()
            access_token = token_data.get("access_token")

            if not access_token:
                raise ValueError("No access_token found in token response")

            # Calculate expiration time (default to 1 hour if not provided)
            expires_in = token_data.get(
                "expires_in", 3600)  # Default to 1 hour
            # Refresh 1 minute early to avoid expiration during requests
            self._token_expires_at = datetime.now() + timedelta(seconds=expires_in - 60)

            return access_token

        except httpx.HTTPStatusError as e:
            raise httpx.HTTPStatusError(
                f"Token request failed: {e.response.status_code} - {e.response.text}",
                request=e.request,
                response=e.response
            )
        except Exception as e:
            raise TokenGenerationError("Failed to generate OAuth token") from e

    async def _get_valid_token(self) -> Optional[str]:
        """Return a valid access token, generating a new one if necessary.

        Returns:
            Optional[str]: Valid access token or None if OAuth is not configured

        Raises:
            ValueError: If OAuth configuration is incomplete
        """
        if not self.is_oauth_configured():
            return None  # OAuth not configured, proceed without token

        async with self._token_lock:
            # Check if we need a new token
            if (not self._access_token or
                not self._token_expires_at or
                    datetime.now() >= self._token_expires_at):

                self._access_token = await self._generate_oauth_token()

            return self._access_token

    async def refresh_token(self) -> str:
        """Manually refresh the OAuth token.

        Returns:
            str: New access token

        Raises:
            ValueError: If OAuth configuration is missing
        """
        async with self._token_lock:
            self._access_token = None
            self._token_expires_at = None
            return await self._generate_oauth_token()

    def is_oauth_configured(self) -> bool:
        """Check if OAuth 2.0 is properly configured.

        Returns:
            bool: True if OAuth is configured, False otherwise
        """
        return all([self.client_id, self.client_secret, self.token_url])

    async def execute(
        self,
        query: str,
        variables: Optional[Dict[str, Any]] = None,
        operation_name: Optional[str] = None,
        method: str = "POST",
        tenant_id: Optional[str] = None
    ) -> Response:
        """Execute a GraphQL query against the specified endpoint.

        Args:
            query: The GraphQL query string
            variables: Optional dictionary of variables to be used in the query
            operation_name: Optional name of the operation to execute
            method: The HTTP method to use ('POST' or 'GET'). Defaults to 'POST'
            tenant_id: Optional tenant ID to override the default tenant ID

        Returns:
            Response: httpx Response object containing the GraphQL response

        Raises:
            ValueError: If an unsupported HTTP method is provided
            httpx.HTTPError: If the request fails

        Example:
            ```python
            query = '''
                query GetUser($id: ID!) {
                    user(id: $id) {
                        name
                        email
                    }
                }
            '''

            response = await graphql.execute(
                query,
                variables={"id": "123"},
                operation_name="GetUser"
            )

            data = response.json()
            if "errors" in data:
                print(f"GraphQL errors: {data['errors']}")
            else:
                print(f"User: {data['data']['user']}")
            ```
        """
        self._ensure_client()

        # Get OAuth token if configured and add to headers
        token = await self._get_valid_token()
        request_headers = self.headers.copy()

        if token:
            request_headers["Authorization"] = f"Bearer {token}"

        tenant_id = tenant_id or self.tenant_id
        url = f"{self.endpoint}/{tenant_id}/graphql-v2" if tenant_id else self.endpoint

        payload = {"query": query}

        if variables is not None:
            payload["variables"] = variables
        if operation_name:
            payload["operationName"] = operation_name

        if method.upper() == "POST":
            response = await self._client.post(url, json=payload, headers=request_headers)
        elif method.upper() == "GET":
            response = await self._client.get(url, params=payload, headers=request_headers)
        else:
            raise ValueError(f"Unsupported HTTP method for GraphQL: {method}")

        return response

    def _ensure_client(self):
        """Ensure HTTP client is initialized and not closed."""
        if not self._client or self._client.is_closed:
            self._client = httpx.AsyncClient()

    async def aclose(self):
        """Close the HTTP client and release resources.

        Example:
            ```python
            graphql = GraphQLServiceManager(config, tenant_id="tenant1")
            try:
                response = await graphql.execute(query)
            finally:
                await graphql.aclose()
            ```
        """
        if self._client:
            await self._client.aclose()

    async def __aenter__(self):
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.aclose()
