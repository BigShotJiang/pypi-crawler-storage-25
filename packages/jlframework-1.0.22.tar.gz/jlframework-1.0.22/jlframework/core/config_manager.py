"""Unified Configuration Manager for jlframework.

This module provides a centralized, thread-safe configuration management system
that consolidates all configuration sources (Azure App Configuration, environment
variables, etc.) into a single interface.

Key Features:
    - Thread-safe singleton pattern
    - Azure App Configuration integration
    - Environment variable fallback
    - Typed configuration keys
    - Lazy loading with caching
    - Support for multiple environments

Example:
    ```python
    from jlframework.core.config_manager import ConfigurationManager
    
    config = ConfigurationManager.get_instance()
    
    # Get configuration values
    api_url = config.get(ConfigurationManager.Keys.MAIN_API_URL)
    storage_conn = config.get(ConfigurationManager.Keys.STORAGE_CONNECTION)
    
    # With default value
    redis_port = config.get(ConfigurationManager.Keys.REDIS_PORT, default=6379)
    ```
"""

import os
import logging
from typing import Any, Optional, Dict
from threading import Lock
from azure.appconfiguration import AzureAppConfigurationClient
from azure.core.exceptions import ResourceNotFoundError

logger = logging.getLogger(__name__)


class ConfigurationKeys:
    """Centralized configuration keys for all jlframework components.

    This class defines all configuration keys used throughout the framework,
    providing a single source of truth and preventing typos.
    """

    # Environment
    APPLICATION_ENVIRONMENT = "APPLICATION_ENVIRONMENT"

    # Azure App Configuration
    APP_CONFIG_CONNECTION = "APP_CONFIGURATION_CONNECTION_STRING"

    # Azure Storage
    STORAGE_CONNECTION = "STORAGE_CONNECTION_STRING"
    STORAGE_CONTAINER = "STORAGE_CONTAINER_NAME"

    # API Configuration
    MAIN_API_URL = "MainSubSystemApiUrl"
    MAIN_API_KEY = "MainSubSystemApiKey"
    API_HEADER_NAME = "API_HEADER_NAME"

    # SharePoint/Microsoft Graph
    SHAREPOINT_CONFIG = "Sharepoint"  # JSON object with SharePoint configuration
    AZURECONNECTION = "Azureconnection"  # Alternative key name for SharePoint config
    GRAPH_CLIENT_ID = "GRAPH_CLIENT_ID"
    GRAPH_CLIENT_SECRET = "GRAPH_CLIENT_SECRET"
    GRAPH_TENANT_ID = "GRAPH_TENANT_ID"
    GRAPH_DRIVE_ID = "GRAPH_DRIVE_ID"
    GRAPH_USER_EMAIL = "GRAPH_USER_EMAIL"

    # Twilio SMS
    TWILIO_ACCOUNT_SID = "TWILIO_ACCOUNT_SID"
    TWILIO_AUTH_TOKEN = "TWILIO_AUTH_TOKEN"
    TWILIO_FROM_NUMBER = "TWILIO_FROM_NUMBER"

    # MongoDB
    MONGO_CONNECTION = "MONGO_CONNECTION_STRING"
    MONGO_DATABASE = "MONGO_DATABASE_NAME"
    MONGO_COLLECTION = "MONGO_COLLECTION_NAME"

    # SQL Database
    SQL_CONNECTION = "SQL_CONNECTION_STRING"
    SQL_DRIVER = "SQL_DRIVER"
    SQL_SERVER = "SQL_SERVER"
    SQL_DATABASE = "SQL_DATABASE"
    SQL_USERNAME = "SQL_USERNAME"
    SQL_PASSWORD = "SQL_PASSWORD"

    # Redis
    REDIS_HOST = "REDIS_HOST"
    REDIS_PORT = "REDIS_PORT"
    REDIS_PASSWORD = "REDIS_PASSWORD"
    REDIS_DB = "REDIS_DB"

    # GraphQL
    GRAPHQL_ENDPOINT = "GRAPHQL_ENDPOINT"
    GRAPHQL_CLIENT_ID = "GRAPHQL_CLIENT_ID"
    GRAPHQL_CLIENT_SECRET = "GRAPHQL_CLIENT_SECRET"
    GRAPHQL_TOKEN_URL = "GRAPHQL_TOKEN_URL"
    GRAPHQL_SCOPE = "GRAPHQL_SCOPE"

    # Slack
    SLACK_SUCCESS_WEBHOOK = "SLACK_SUCCESS_WEBHOOK"
    SLACK_FAILURE_WEBHOOK = "SLACK_FAILURE_WEBHOOK"

    # Teams
    TEAMS_WEBHOOK = "TEAMS_WEBHOOK"
    TEAMS_ENABLED = "TEAMS_ENABLED"

    # SendGrid
    SENDGRID_API_KEY = "SENDGRID_API_KEY"
    SENDGRID_FROM_EMAIL = "SENDGRID_FROM_EMAIL"
    SENDGRID_URL = "SENDGRID_URL"


class ConfigurationManager:
    """Unified configuration manager for all jlframework components.

    This class provides a thread-safe singleton interface for accessing
    configuration values from multiple sources with a defined precedence:
    1. Azure App Configuration (if configured)
    2. Environment variables
    3. Default values (if provided)

    The manager implements lazy loading and caching for optimal performance.

    Attributes:
        Keys: ConfigurationKeys class for accessing configuration key constants

    Example:
        ```python
        config = ConfigurationManager.get_instance()

        # Get required configuration
        api_url = config.get(ConfigurationManager.Keys.MAIN_API_URL)

        # Get with default
        port = config.get(ConfigurationManager.Keys.REDIS_PORT, default=6379)

        # Check if key exists
        if config.has(ConfigurationManager.Keys.TWILIO_ACCOUNT_SID):
            # Twilio is configured
            pass
        ```
    """

    Keys = ConfigurationKeys

    _instance: Optional["ConfigurationManager"] = None
    _lock = Lock()

    def __init__(self):
        """Initialize the configuration manager.

        Note:
            This should not be called directly. Use get_instance() instead.
        """
        self.environment = os.getenv(
            ConfigurationKeys.APPLICATION_ENVIRONMENT, "dev"
        )
        self.app_config_connection = os.getenv(
            ConfigurationKeys.APP_CONFIG_CONNECTION
        )

        self._configs: Dict[str, Any] = {}
        self._azure_loaded = False
        self._load_lock = Lock()

        logger.info(
            f"ConfigurationManager initialized for environment: {self.environment}"
        )

    @classmethod
    def get_instance(cls) -> "ConfigurationManager":
        """Get or create the singleton instance of ConfigurationManager.

        Thread-safe factory method that ensures only one instance exists
        throughout the application lifetime.

        Returns:
            ConfigurationManager: The singleton instance.

        Example:
            ```python
            config = ConfigurationManager.get_instance()
            ```
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @classmethod
    def reset_instance(cls):
        """Reset the singleton instance (primarily for testing).

        Warning:
            This should only be used in test scenarios.
        """
        with cls._lock:
            cls._instance = None

    def _load_azure_config(self):
        """Load configuration from Azure App Configuration.

        This method is called lazily on first configuration access.
        It loads all configuration settings filtered by the current environment.
        """
        if self._azure_loaded:
            return

        with self._load_lock:
            if self._azure_loaded:
                return

            if not self.app_config_connection:
                logger.info(
                    "Azure App Configuration not configured, "
                    "using environment variables only"
                )
                self._azure_loaded = True
                return

            try:
                client = AzureAppConfigurationClient.from_connection_string(
                    self.app_config_connection
                )

                settings = client.list_configuration_settings(
                    label_filter=self.environment
                )

                count = 0
                for item in settings:
                    self._configs[item.key] = item.value
                    count += 1

                self._azure_loaded = True
                logger.info(
                    f"Loaded {count} configuration settings from Azure App Configuration "
                    f"for environment: {self.environment}"
                )

            except Exception as e:
                logger.error(f"Error loading Azure App Configuration: {e}")
                logger.info("Falling back to environment variables only")
                self._azure_loaded = True

    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value with fallback chain.

        Precedence order:
        1. Azure App Configuration (if configured)
        2. Environment variable
        3. Default value (if provided)

        Args:
            key: Configuration key to retrieve
            default: Default value if key not found (optional)

        Returns:
            Configuration value or default

        Raises:
            KeyError: If key not found and no default provided

        Example:
            ```python
            # Required configuration (raises KeyError if not found)
            api_url = config.get(ConfigurationManager.Keys.MAIN_API_URL)

            # Optional configuration with default
            port = config.get(ConfigurationManager.Keys.REDIS_PORT, default=6379)
            ```
        """
        # Ensure Azure config is loaded
        if not self._azure_loaded:
            self._load_azure_config()

        # Try Azure App Configuration first
        if key in self._configs:
            return self._configs[key]

        # Fall back to environment variable
        env_value = os.getenv(key)
        if env_value is not None:
            return env_value

        # Use default if provided
        if default is not None:
            return default

        # Key not found and no default
        raise KeyError(
            f"Configuration key '{key}' not found in Azure App Configuration "
            f"or environment variables"
        )

    def get_int(self, key: str, default: Optional[int] = None) -> int:
        """Get configuration value as integer.

        Args:
            key: Configuration key to retrieve
            default: Default value if key not found (optional)

        Returns:
            Configuration value as integer

        Example:
            ```python
            port = config.get_int(ConfigurationManager.Keys.REDIS_PORT, default=6379)
            ```
        """
        value = self.get(key, default=default)
        return int(value)

    def get_bool(self, key: str, default: Optional[bool] = None) -> bool:
        """Get configuration value as boolean.

        Recognizes: true, yes, 1, on (case-insensitive) as True

        Args:
            key: Configuration key to retrieve
            default: Default value if key not found (optional)

        Returns:
            Configuration value as boolean

        Example:
            ```python
            enabled = config.get_bool(ConfigurationManager.Keys.TEAMS_ENABLED, default=False)
            ```
        """
        value = self.get(key, default=default)
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.lower() in ('true', 'yes', '1', 'on')
        return bool(value)

    def has(self, key: str) -> bool:
        """Check if configuration key exists.

        Args:
            key: Configuration key to check

        Returns:
            True if key exists, False otherwise

        Example:
            ```python
            if config.has(ConfigurationManager.Keys.TWILIO_ACCOUNT_SID):
                # Twilio is configured
                sms_handler = SMSHandler(config)
            ```
        """
        try:
            self.get(key)
            return True
        except KeyError:
            return False

    def get_all(self) -> Dict[str, Any]:
        """Get all configuration values.

        Returns:
            Dictionary of all configuration key-value pairs

        Note:
            This includes both Azure App Configuration and environment variables.
        """
        if not self._azure_loaded:
            self._load_azure_config()

        # Combine Azure config and environment variables
        all_config = dict(self._configs)

        # Add environment variables not in Azure config
        for key in dir(ConfigurationKeys):
            if not key.startswith('_'):
                env_key = getattr(ConfigurationKeys, key)
                if env_key not in all_config:
                    env_value = os.getenv(env_key)
                    if env_value is not None:
                        all_config[env_key] = env_value

        return all_config

    def __getattr__(self, name: str) -> Any:
        """Provide attribute-style access to configuration values for backward compatibility.

        This method enables accessing configuration values using dot notation,
        maintaining compatibility with the old Configurations class.

        Args:
            name (str): The configuration key name.

        Returns:
            Any: The configuration value.

        Raises:
            AttributeError: If the configuration key is not found.

        Example:
            ```python
            config = ConfigurationManager.get_instance()
            # Both ways work:
            value1 = config.get(config.Keys.REDIS)  # Recommended
            value2 = config.Redis  # Backward compatible
            ```

        Note:
            While this method provides backward compatibility, using the
            get() method with Keys is recommended for better type safety.
        """
        # Avoid infinite recursion for internal attributes
        if name.startswith('_'):
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{name}'")

        # Try to get the value using the get method
        try:
            return self.get(name)
        except KeyError:
            raise AttributeError(f"Configuration key '{name}' not found")

    def reload(self):
        """Reload configuration from Azure App Configuration.

        This forces a refresh of all configuration values from Azure.
        Useful when configuration has been updated externally.

        Example:
            ```python
            config.reload()  # Refresh from Azure
            ```
        """
        with self._load_lock:
            self._azure_loaded = False
            self._configs.clear()
            self._load_azure_config()

        logger.info("Configuration reloaded from Azure App Configuration")
