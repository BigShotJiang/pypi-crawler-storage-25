"""Azure-based database initialization for jlframework.

This module provides utilities to initialize database connections
using configuration loaded from Azure App Configuration.
"""

import logging

from sqlalchemy import create_engine, event
from sqlalchemy.engine import URL
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import QueuePool

logger = logging.getLogger(__name__)


def initialize_database_from_azure(
    db_settings: dict,
    pool_size: int = 20,
    max_overflow: int = 10,
    pool_recycle: int = 3600,
    echo: bool = False,
):
    """Initialize database engine and session factory from Azure configuration.

    This function creates a database engine using settings loaded from
    Azure App Configuration, typically containing UID, PWD, SERVER, and DATABASE.

    Args:
        db_settings: Dictionary containing database configuration with keys:
                    UID, PWD, SERVER, DATABASE (from Azure App Configuration)
        pool_size: Connection pool size (default: 20)
        max_overflow: Maximum overflow connections (default: 10)
        pool_recycle: Recycle connections after this many seconds (default: 3600)
        echo: Enable SQL query logging (default: False)

    Returns:
        tuple: (engine, SessionLocal) - SQLAlchemy engine and session factory

    Raises:
        ValueError: If required configuration keys are missing

    Example:
        from configs.azure_config import configurations
        from jlframework.core.azure_db import initialize_database_from_azure

        engine, SessionLocal = initialize_database_from_azure(
            configurations.db_settings
        )
    """
    required_keys = ["UID", "PWD", "SERVER", "DATABASE"]
    missing_keys = [key for key in required_keys if not db_settings.get(key)]
    if missing_keys:
        raise ValueError(
            f"Missing database configuration keys: {missing_keys}")

    # Extract server and port if specified
    server_parts = db_settings.get("SERVER", "").split(",")
    server_host = server_parts[0]
    server_port = int(server_parts[1]) if len(server_parts) > 1 else None

    try:
        database_url = URL.create(
            "mssql+pyodbc",
            username=db_settings.get("UID"),
            password=db_settings.get("PWD"),
            host=server_host,
            port=server_port,
            database=db_settings.get("DATABASE"),
            query={
                "driver": "ODBC Driver 17 for SQL Server",
                "TrustServerCertificate": "yes",
            },
        )

        engine = create_engine(
            database_url,
            poolclass=QueuePool,
            pool_size=pool_size,
            max_overflow=max_overflow,
            pool_pre_ping=True,
            pool_recycle=pool_recycle,
            echo=echo,
        )

        # Add connection event listeners
        @event.listens_for(engine, "connect")
        def set_connection_settings(dbapi_connection, connection_record):
            """Set connection-specific settings for SQL Server."""
            logger.debug("New database connection established")

        @event.listens_for(engine, "checkout")
        def receive_checkout(dbapi_connection, connection_record, connection_proxy):
            """Log connection checkout events."""
            logger.debug("Database connection checked out from pool")

        # Create session factory
        SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=engine,
            expire_on_commit=False,
        )

        logger.info(
            "Database engine configured successfully for server: %s", server_host)

        return engine, SessionLocal

    except Exception as e:
        logger.error("Failed to create database engine: %s", e)
        raise
