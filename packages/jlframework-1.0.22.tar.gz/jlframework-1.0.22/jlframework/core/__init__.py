"""JLFramework Core Namespace.

This namespace contains core utilities shared across all use cases
(automation and web applications).

Components:
    - ConfigurationManager: Unified configuration management
    - SharePointManager: SharePoint and Microsoft Graph integration
    - GraphQLServiceManager: GraphQL client
    - AuditManager: Audit logging to MongoDB
    - BlobStorageManager: Azure Blob Storage operations
    - SMSHandler: SMS notifications via Twilio
    - Notification decorators: Slack and Teams notifications
    - Common utilities: Enums, utilities, base managers

Example:
    ```python
    from jlframework.core import ConfigurationManager, SharePointManager
    
    # Get configuration
    config = ConfigurationManager.get_instance()
    
    # Use SharePoint
    sp = SharePointManager(config=config)
    await sp.send_email(...)
    ```
"""

# Configuration Management
from jlframework.core.config_manager import ConfigurationManager, ConfigurationKeys

# Base Manager Classes
from jlframework.core.base_manager import (
    BaseManager,
    BaseAzureManager,
    BaseAPIManager,
    BaseDatabaseManager,
    SingletonMeta,
)

# SharePoint and Microsoft Graph
from jlframework.core.sharepoint import (
    SharePointManager,
    ContentType,
    GraphMethod,
    graph_request,
)

# GraphQL Client
from jlframework.core.graphql_client import GraphQLServiceManager, TokenGenerationError

# Audit Management
from jlframework.core.audit_handler import AuditManager, AuditData

# Azure Blob Storage
from jlframework.core.blob_storage import BlobStorageManager

# SMS Handler
from jlframework.core.sms_handler import SMSHandler

# Notifications
from jlframework.core.notifications import (
    slack_notification,
    teams_notification,
)

# Common Utilities
from jlframework.core.common_utils import (
    ExecutionResult,
    ReportStatus,
    ReportRequestError,
    ReportStatusError,
    WINDOWS_TO_IANA,
    get_iana_timezone,
    AuditStatus,
    AuditAction,
    EntityType,
)

# Utilities
from jlframework.core.utils import deprecated

# Enums (legacy)
from jlframework.core.enums import (
    AuditAction as LegacyAuditAction,
    AuditStatus as LegacyAuditStatus,
    EntityType as LegacyEntityType,
)

__all__ = [
    # Configuration Management
    "ConfigurationManager",
    "ConfigurationKeys",

    # Base Manager Classes
    "BaseManager",
    "BaseAzureManager",
    "BaseAPIManager",
    "BaseDatabaseManager",
    "SingletonMeta",

    # SharePoint and Microsoft Graph
    "SharePointManager",
    "ContentType",
    "GraphMethod",
    "graph_request",

    # GraphQL Client
    "GraphQLServiceManager",
    "TokenGenerationError",

    # Audit Management
    "AuditManager",
    "AuditData",

    # Azure Blob Storage
    "BlobStorageManager",

    # SMS Handler
    "SMSHandler",

    # Notifications
    "slack_notification",
    "teams_notification",

    # Common Utilities
    "ExecutionResult",
    "ReportStatus",
    "ReportRequestError",
    "ReportStatusError",
    "WINDOWS_TO_IANA",
    "get_iana_timezone",
    "AuditStatus",
    "AuditAction",
    "EntityType",

    # Utilities
    "deprecated",

    # Legacy Enums
    "LegacyAuditAction",
    "LegacyAuditStatus",
    "LegacyEntityType",
]
