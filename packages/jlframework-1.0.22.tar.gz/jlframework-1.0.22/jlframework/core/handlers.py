"""Request handlers and common utilities for FastAPI applications."""

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Union
from uuid import UUID, uuid4

from fastapi import HTTPException, Request, status
from pymongo import MongoClient

from .enums import AuditAction, AuditStatus, EntityType

logger = logging.getLogger(__name__)


class CommonManager:
    """Common utilities for request handling.

    This class provides static methods for common request handling operations
    that are used across multiple domains and services.
    """

    @staticmethod
    def get_tenant_id(request: Request) -> str:
        """Get tenant ID from request context.

        The tenant ID is provided by the frontend in the 'x-jl-tenant-id' header
        and stored in request.state.tenant_id by the restrict_access middleware.

        Args:
            request: FastAPI Request object containing the tenant context.

        Returns:
            Tenant identifier from the middleware.

        Raises:
            HTTPException: If tenant ID is not found in request state.
        """
        tenant_id: Optional[str] = getattr(request.state, "tenant_id", None)

        if not tenant_id:
            logger.error("Tenant ID not found in request state")
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Tenant ID not found. Please provide 'x-jl-tenant-id' header.",
            )

        logger.debug("Retrieved tenant ID: %s", tenant_id)
        return tenant_id

    @staticmethod
    def get_client_info(request: Request) -> dict:
        """Extract client information from HTTP request headers.

        This method retrieves client IP address, user agent, and host information
        from the request. It properly handles proxy headers (X-Forwarded-For, X-Real-IP)
        to get the actual client IP when behind a reverse proxy or load balancer.

        Args:
            request (Request): FastAPI Request object containing headers and client info.

        Returns:
            dict: Dictionary containing:
                - ip (str): Client IP address (considers proxy headers)
                - user_agent (str): Client's user agent string
                - host (str): Request host header value

        Example:
            ```python
            client_info = CommonManager.get_client_info(request)
            logger.info(f"Request from {client_info['ip']}")
            ```

        Note:
            Priority for IP detection:
            1. X-Forwarded-For header (first IP in comma-separated list)
            2. X-Real-IP header
            3. Direct client connection IP
        """
        client_info = {
            "ip": "unknown",
            "user_agent": request.headers.get("User-Agent", "unknown"),
            "host": request.headers.get("Host", "unknown"),
        }

        # Get client IP with proxy consideration
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            client_info["ip"] = forwarded_for.split(",")[0].strip()
        elif request.headers.get("X-Real-IP"):
            client_info["ip"] = request.headers.get("X-Real-IP")
        elif hasattr(request, "client") and request.client:
            client_info["ip"] = request.client.host

        return client_info

    @staticmethod
    def validate_pagination(
        page_index: int, page_size: int, max_page_size: int = 100
    ) -> None:
        """Validate pagination parameters for list endpoints.

        Ensures pagination parameters are within acceptable ranges to prevent
        performance issues and invalid queries.

        Args:
            page_index (int): Page number (1-based indexing).
            page_size (int): Number of items to return per page.
            max_page_size (int, optional): Maximum allowed items per page. Defaults to 100.

        Raises:
            HTTPException: 400 Bad Request if:
                - page_index is less than 1
                - page_size is less than 1
                - page_size exceeds max_page_size

        Example:
            ```python
            @router.get("/items")
            async def list_items(page: int = 1, size: int = 10):
                CommonManager.validate_pagination(page, size)
                # ... fetch and return items
            ```
        """
        if page_index < 1:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Page index must be greater than 0",
            )

        if page_size < 1:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Page size must be greater than 0",
            )

        if page_size > max_page_size:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Page size cannot exceed {max_page_size}",
            )


@dataclass
class AuditData:
    """Data class representing a single audit log entry.

    This class encapsulates all information needed to track an operation
    in the system, including what entity was affected, what action was performed,
    who performed it, and whether it succeeded.

    Attributes:
        entity (EntityType): Type of entity being audited (e.g., Job, Customer, Invoice).
        action (AuditAction): Type of action performed (CREATE, UPDATE, DELETE, OTHER).
        is_successfull (AuditStatus): Whether the operation succeeded or failed.
        message (str): Human-readable description of the operation.
        timestamp (datetime): When the operation occurred.
        tenant_id (UUID): Tenant identifier for multi-tenancy.
        app_id (int): Application identifier (e.g., 299 for Cost Centre).
        key_id (Optional[int]): Primary key of the affected entity (if applicable).
        key_GUID (UUID): GUID identifier of the affected entity.
        process_id (UUID): Unique identifier for this audit process (auto-generated).
        details (Optional[Dict[str, Any]]): Additional context or metadata.

    Example:
        ```python
        from datetime import datetime
        from uuid import uuid4

        audit = AuditData(
            entity=EntityType.Job,
            action=AuditAction.CREATE,
            is_successfull=AuditStatus.SUCCESS,
            message="Job created successfully",
            timestamp=datetime.utcnow(),
            tenant_id=UUID("..."),
            app_id=299,
            key_id=12345,
            key_GUID=uuid4(),
            details={"job_number": "JOB-001"}
        )
        ```
    """
    entity: EntityType
    action: AuditAction
    is_successfull: AuditStatus
    message: str
    timestamp: datetime
    tenant_id: UUID
    app_id: int
    key_id: Optional[int]
    key_GUID: UUID
    process_id: UUID = field(default_factory=uuid4)
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert audit data to dictionary format for MongoDB storage.

        Transforms the dataclass into a dictionary suitable for insertion
        into MongoDB, with enum values converted to their integer/boolean values.

        Returns:
            Dict[str, Any]: Dictionary containing all audit fields with:
                - Enum values converted to their underlying values
                - All UUIDs and timestamps preserved
                - Optional fields included if present

        Example:
            ```python
            audit_dict = audit.to_dict()
            collection.insert_one(audit_dict)
            ```
        """
        return {
            "process_id": self.process_id,
            "tenant_id": self.tenant_id,
            "app_id": self.app_id,
            "key_id": self.key_id,
            "key_GUID": self.key_GUID,
            "entity": self.entity.value,
            "action": self.action.value,
            "is_successfull": self.is_successfull.value,
            "message": self.message,
            "timestamp": self.timestamp,
            "details": self.details,
        }


class AuditManager:
    """Manager for audit logging to MongoDB.

    This class provides a centralized interface for creating and storing audit
    log entries in MongoDB. It handles connection management, data validation,
    and batch operations for efficient audit logging.

    The audit logs are stored in MongoDB to provide:
    - High-performance writes for audit trails
    - Flexible schema for varying audit details
    - Easy querying and analysis of system operations
    - Scalable storage for large audit volumes

    Attributes:
        app_id (int): Application identifier for this audit manager.
        tenant_id (str): Tenant identifier for multi-tenancy support.
        config (Dict[str, Any]): MongoDB configuration parsed from connection string.
        database_name (str): Name of the MongoDB database.
        collection_name (str): Name of the collection ('MPApps' by default).
        client (MongoClient): MongoDB client instance.

    Example:
        ```python
        # Initialize audit manager
        manager = AuditManager(
            app_id=299,
            tenant_id="tenant-uuid",
            mongo_connection_string=config.mongo_db_connection_string
        )

        # Create and save audit entry
        audit = AuditData(...)
        await manager.save_audit(audit)

        # Save multiple entries
        audits = [AuditData(...), AuditData(...)]
        await manager.save_audit(audits)
        ```
    """

    def __init__(self, app_id: int, tenant_id: str, mongo_connection_string: str) -> None:
        """Initialize the AuditManager with MongoDB connection.

        Args:
            app_id (int): Application identifier (e.g., 299 for Cost Centre).
            tenant_id (str): Tenant identifier for multi-tenancy.
            mongo_connection_string (str): JSON string containing MongoDB configuration:
                - connection_string: MongoDB connection URI
                - database_name: Name of the database to use

        Example:
            ```python
            config_json = json.dumps({
                "connection_string": "mongodb://localhost:27017",
                "database_name": "audit_logs"
            })
            manager = AuditManager(299, "tenant-id", config_json)
            ```

        Note:
            The MongoDB client uses uuidRepresentation="standard" for proper
            UUID handling across different MongoDB drivers.
        """
        self.app_id = app_id
        self.tenant_id = tenant_id

        self.config: Dict[str, Any] = json.loads(mongo_connection_string)
        connection_string = self.config.get("connection_string")
        self.database_name = self.config.get("database_name")
        self.collection_name = 'MPApps'

        self.client = MongoClient(
            connection_string, uuidRepresentation="standard")

    def build_audit(self, audit_entries: List[AuditData]) -> None:
        """Populate audit entries with default app_id and tenant_id if missing.

        This method ensures all audit entries have the required app_id and tenant_id
        values, using the manager's defaults if not explicitly set.

        Args:
            audit_entries (List[AuditData]): List of audit entries to populate.

        Note:
            - Modifies entries in-place
            - Only sets values if they are missing (None)
            - Converts string tenant_id to UUID if needed
        """
        for entry in audit_entries:
            if not entry.app_id:
                entry.app_id = self.app_id
            if not entry.tenant_id and self.tenant_id:
                entry.tenant_id = UUID(self.tenant_id) if not isinstance(
                    self.tenant_id, UUID) else self.tenant_id

    def audit_validation(self, audit_entries: Union[AuditData, List[AuditData]]) -> bool:
        """Validate audit entries and determine if single or batch operation.

        Args:
            audit_entries (Union[AuditData, List[AuditData]]): Single entry or list of entries.

        Returns:
            bool: True if single AuditData instance, False if list of instances.

        Raises:
            ValueError: If input is neither AuditData nor List[AuditData].

        Example:
            ```python
            is_single = manager.audit_validation(audit_data)
            if is_single:
                # Handle single entry
            else:
                # Handle batch entries
            ```
        """
        if isinstance(audit_entries, AuditData):
            return True
        elif isinstance(audit_entries, list) and all(isinstance(e, AuditData) for e in audit_entries):
            return False
        else:
            raise ValueError(
                "Input must be an AuditData instance or a list of AuditData instances.")

    async def save_audit(self, audit_entries: Union[AuditData, List[AuditData]]):
        """Save one or more audit entries to MongoDB.

        This method handles both single and batch audit operations, automatically
        populating default values and choosing the appropriate MongoDB operation.

        Args:
            audit_entries (Union[AuditData, List[AuditData]]): Single audit entry
                or list of entries to save to MongoDB.

        Returns:
            Union[ObjectId, List[ObjectId]]: MongoDB inserted ID(s):
                - Single ObjectId if one entry was saved
                - List of ObjectIds if multiple entries were saved

        Raises:
            ValueError: If audit_entries is not valid AuditData or List[AuditData].
            Exception: If MongoDB operation fails (logged and re-raised).

        Example:
            ```python
            # Save single entry
            audit_id = await manager.save_audit(audit_data)

            # Save multiple entries
            audit_ids = await manager.save_audit([audit1, audit2, audit3])
            ```

        Note:
            - MongoDB client connection is kept open for reuse
            - Uses insert_one() for single entries
            - Uses insert_many() for batch entries
            - All entries are validated and populated before insertion
            - Call close_connection() when done with all audit operations
        """
        try:
            is_single = self.audit_validation(audit_entries)
            if is_single:
                audit_entries = [audit_entries]
            self.build_audit(audit_entries)

            db = self.client[self.database_name]
            collection = db[self.collection_name]

            documents = [entry.to_dict() for entry in audit_entries]

            if is_single:
                result = collection.insert_one(documents[0])
                return result.inserted_id
            else:
                result = collection.insert_many(documents)
                return result.inserted_ids

        except Exception as e:
            logging.error(f"An error occurred in saving audit: {e}")
            raise

    async def close_connection(self):
        """Close the MongoDB client connection.

        This should be called when all audit operations are complete,
        typically during cleanup operations.
        """
        try:
            if self.client:
                self.client.close()
                logging.debug(
                    "MongoDB client connection closed for MPApps AuditManager")
        except Exception as e:
            logging.error(f"Error closing MongoDB connection: {e}")
            raise
