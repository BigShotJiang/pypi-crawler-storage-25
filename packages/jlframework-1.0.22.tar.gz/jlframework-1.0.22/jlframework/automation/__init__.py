"""JLFramework Automation Namespace.

This namespace contains automation-specific components for building
Azure Function-based automation workflows.

Components:
    - AutomationManager: Base class for automation workflows
    - SqlManager: SQL database operations with connection pooling
    - MainSubSysApiManager: API client for external service calls
    - CommonManager: Common utilities for automation workflows
    - AutomationDetails: Data class for automation metadata
    - ExecutionResult: Data class for execution results
    - RequestType: Enum for HTTP request methods
    - ApiError: Custom exception for API errors

Example:
    ```python
    from jlframework.automation import AutomationManager, ExecutionResult
    
    class MyAutomation(AutomationManager):
        async def start_processing(self, data):
            # Access pre-configured managers
            result = await self.db.execute_query("SELECT * FROM table")
            
            # Update execution history
            exec_result = ExecutionResult(
                execution_time=datetime.now().isoformat(),
                read_count=100,
                create_count=10
            )
            await self.common.update_execution_history_async(exec_result)
            
            return result
    ```
"""

from jlframework.automation.manager import AutomationManager, AutomationDetails
from jlframework.automation.sql import SqlManager
from jlframework.automation.api_client import MainSubSysApiManager, RequestType, ApiError
from jlframework.automation.common import CommonManager, ExecutionResult

__all__ = [
    # Core automation classes
    "AutomationManager",
    "AutomationDetails",

    # Database
    "SqlManager",

    # API client
    "MainSubSysApiManager",
    "RequestType",
    "ApiError",

    # Common utilities
    "CommonManager",
    "ExecutionResult",
]
