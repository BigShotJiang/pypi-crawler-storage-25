<template>
    <div id="starterAppTab" role="tabpanel" class="tab-pane fade">
        <div id="assignedAttributesVM">
            <AssetRequests/>
        </div>
    </div>
</template>

<script>
import AssetRequests from '@/views/Assets.vue';

export default {
    name: "MarketplaceAppsFeature",
    components: { AssetRequests }
}
</script>