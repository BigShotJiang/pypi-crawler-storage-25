import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { fileURLToPath, URL } from 'url';
import tailwindcss from '@tailwindcss/vite'

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
    return {
        define: {
            rootDirectory: JSON.stringify(__dirname),
            __VUE_PROD_DEVTOOLS__: mode !== 'production',
        },

        plugins: [vue(),  tailwindcss()],

        resolve: {
            alias: {
                '@': fileURLToPath(new URL('./src', import.meta.url)),
            },
        },

        build: {
            emptyOutDir: false,
            target: 'esnext',
        },
    };
});
