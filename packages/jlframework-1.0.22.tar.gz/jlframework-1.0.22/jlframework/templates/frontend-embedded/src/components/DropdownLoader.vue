<template>
  <div class="dropdown-loader"
    :class="{ 'dropdown-loader--small': size === 'small', 'dropdown-loader--large': size === 'large' }">
    <div class="circle-loader">
      <div class="dropdown-icon">
        <svg :width="iconSize" :height="iconSize" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M7 10L12 15L17 10H7Z" fill="currentColor" />
        </svg>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'DropdownLoader',
  props: {
    size: {
      type: String,
      default: 'medium',
      validator: (value) => ['small', 'medium', 'large'].includes(value)
    }
  },
  computed: {
    iconSize() {
      switch (this.size) {
        case 'small': return 12;
        case 'large': return 20;
        default: return 16;
      }
    }
  }
}
</script>

<style scoped>
.dropdown-loader {
  display: flex;
  align-items: center;
  justify-content: center;
}

.circle-loader {
  width: 24px;
  height: 24px;
  border: 2px solid #e9ecef;
  border-top: 2px solid #3b82f6;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  animation: spin 1s linear infinite;
  position: relative;
}

.dropdown-icon {
  color: #3b82f6;
  animation: bounce 1.5s ease-in-out infinite;
}

.dropdown-loader--small .circle-loader {
  width: 18px;
  height: 18px;
  border-width: 1.5px;
}

.dropdown-loader--large .circle-loader {
  width: 32px;
  height: 32px;
  border-width: 3px;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
}

@keyframes bounce {

  0%,
  20%,
  50%,
  80%,
  100% {
    transform: translateY(0);
  }

  40% {
    transform: translateY(-2px);
  }

  60% {
    transform: translateY(-1px);
  }
}
</style>
