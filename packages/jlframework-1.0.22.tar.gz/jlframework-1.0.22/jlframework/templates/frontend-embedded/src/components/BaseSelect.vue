<template>
  <div class="base-select">
    <label v-if="label" :for="selectId" class="base-select__label">
      {{ label }}
    </label>
    <div class="base-select__wrapper">
      <select :id="selectId" :value="modelValue" :disabled="disabled || loading" class="base-select__input"
        @change="handleChange">
        <option value="" disabled>
          {{ placeholder }}
        </option>
        <option v-for="option in options" :key="getOptionValue(option)" :value="getOptionValue(option)">
          {{ getOptionLabel(option) }}
        </option>
      </select>
      <div v-if="loading" class="base-select__spinner">
        <DropdownLoader size="small" />
      </div>
      <div v-else class="base-select__arrow">
        <svg width="12" height="8" viewBox="0 0 12 8" fill="none">
          <path d="M1 1.5L6 6.5L11 1.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
            stroke-linejoin="round" />
        </svg>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import DropdownLoader from './DropdownLoader.vue';

interface SelectOption {
  [key: string]: any;
  label?: string;
  value?: any;
  name?: string;
}

interface Props {
  modelValue?: string | number | SelectOption | null;
  options?: (string | number | SelectOption)[];
  label?: string;
  placeholder?: string;
  disabled?: boolean;
  loading?: boolean;
  labelKey?: string;
  valueKey?: string;
}

interface Emits {
  'update:modelValue': [value: string | number | SelectOption | null];
}

const props = withDefaults(defineProps<Props>(), {
  modelValue: null,
  options: () => [],
  label: '',
  placeholder: 'Select an option...',
  disabled: false,
  loading: false,
  labelKey: 'label',
  valueKey: 'value',
});

const emit = defineEmits<Emits>();

const selectId = computed((): string =>
  `base-select-${Math.random().toString(36).substr(2, 9)}`
);

const getOptionLabel = (option: string | number | SelectOption): string => {
  if (typeof option === 'string' || typeof option === 'number') {
    return String(option);
  }
  return (option[props.labelKey] || option.label || option.name || option.toString()) as string;
};

const getOptionValue = (option: string | number | SelectOption): any => {
  if (typeof option === 'string' || typeof option === 'number') {
    return option;
  }
  return option[props.valueKey] || option.value || option;
};

const handleChange = (event: Event): void => {
  const target = event.target as HTMLSelectElement;
  const value = target.value;

  if (props.options.length > 0 && typeof props.options[0] === 'object') {
    const selectedOption = props.options.find((option: string | number | SelectOption) => {
      const optionValue = getOptionValue(option);
      return String(optionValue) === String(value);
    });
    emit('update:modelValue', selectedOption || value);
  } else {
    emit('update:modelValue', value);
  }
};
</script>

<style scoped>
.base-select {
  width: 100%;
}

.base-select__label {
  display: block;
  margin-bottom: 6px;
  font-weight: 500;
  color: #374151;
  font-size: 14px;
}

.base-select__wrapper {
  position: relative;
  width: 100%;
}

.base-select__input {
  width: 100%;
  padding: 10px 40px 10px 12px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
  font-size: 14px;
  line-height: 1.5;
  color: #374151;
  background-color: #ffffff;
  cursor: pointer;
  transition: all 0.2s ease;
  appearance: none;
  -webkit-appearance: none;
  -moz-appearance: none;
}

.base-select__input:focus {
  outline: none;
  border-color: #3b82f6;
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.base-select__input:disabled {
  background-color: #f9fafb;
  color: #9ca3af;
  cursor: not-allowed;
}

.base-select__arrow {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
  color: #6b7280;
  transition: transform 0.2s ease;
}

.base-select__input:focus+.base-select__arrow {
  transform: translateY(-50%) rotate(180deg);
}

.base-select__spinner {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
}

.base-select__input:hover:not(:disabled) {
  border-color: #9ca3af;
}

.base-select__input:hover:not(:disabled)+.base-select__arrow {
  color: #374151;
}
</style>
