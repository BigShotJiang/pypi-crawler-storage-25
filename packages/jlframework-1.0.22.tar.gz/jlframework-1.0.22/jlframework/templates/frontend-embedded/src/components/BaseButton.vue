<template>
  <button :class="[
    'base-button',
    classes,
    {
      'base-button--disabled': disabled,
      'base-button--loading': loading
    }
  ]" :style="{ width: width }" :disabled="disabled || loading" :type="type" @click="handleClick"
    @keypress="handleKeyPress">
    <span v-if="loading" class="base-button__spinner"></span>
    <span v-else>{{ label }}</span>
  </button>
</template>

<script setup lang="ts">

interface Props {
  label: string;
  disabled?: boolean;
  loading?: boolean;
  width?: string;
  classes?: string;
  type?: 'button' | 'submit' | 'reset';
}

interface Emits {
  onClick: [event: MouseEvent];
  onKeyPress: [event: KeyboardEvent];
}

const props = withDefaults(defineProps<Props>(), {
  disabled: false,
  loading: false,
  width: 'auto',
  classes: '',
  type: 'button',
});

const emit = defineEmits<Emits>();

const handleClick = (event: MouseEvent): void => {
  if (!props.disabled && !props.loading) {
    emit('onClick', event);
  }
};

const handleKeyPress = (event: KeyboardEvent): void => {
  if (!props.disabled && !props.loading && (event.key === 'Enter' || event.key === ' ')) {
    event.preventDefault();
    emit('onKeyPress', event);
  }
};
</script>

<style scoped>
.base-button {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  background-color: #007bff;
  color: white;
  outline: none;
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 36px;
}

.base-button:hover:not(.base-button--disabled):not(.base-button--loading) {
  background-color: #0056b3;
  transform: translateY(-1px);
}

.base-button:active:not(.base-button--disabled):not(.base-button--loading) {
  transform: translateY(0);
}

.base-button--disabled {
  background-color: #6c757d;
  cursor: not-allowed;
  opacity: 0.6;
}

.base-button--loading {
  cursor: not-allowed;
}

.base-button__spinner {
  width: 16px;
  height: 16px;
  border: 2px solid #ffffff;
  border-top: 2px solid transparent;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
}

:global(.jl-button-green) {
  background-color: #28a745;
}

:global(.jl-button-green:hover) {
  background-color: #218838;
}
</style>
