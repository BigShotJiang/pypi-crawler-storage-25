/**
 * Simple Tenant Manager
 * Gets company and updates temporary.TenantId in session storage
 * Validates and resets tenant ID on page reload
 */

const TENANT_KEY = 'temporary.TenantId';

/**
 * Set tenant ID in session storage
 */
export function setTenantId(tenantId: string): void {
  sessionStorage.setItem(TENANT_KEY, tenantId);
}

/**
 * Get tenant ID from session storage
 */
export function getTenantId(): string | null {
  return sessionStorage.getItem(TENANT_KEY);
}

/**
 * Clear tenant ID from session storage
 */
export function clearTenantId(): void {
  sessionStorage.removeItem(TENANT_KEY);
}

/**
 * Validate and reset tenant ID to actual logged-in user's value
 * Call this on page reload to ensure tenant ID is correct
 */
export async function validateAndResetTenantId(): Promise<void> {
  try {
    // Import company service to get actual tenant data
    const { getCompany } = await import('./company.service');
    const result = await getCompany();
    
    if (result.success && Array.isArray(result.additionalData) && result.additionalData.length > 0) {
      // If only one tenant, set it automatically
      if (result.additionalData.length === 1) {
        const actualTenantId = result.additionalData[0].TenantId;
        if (actualTenantId) {
          setTenantId(actualTenantId);
        }
      } else {
        // Multiple tenants - check if current stored tenant is valid
        const currentTenantId = getTenantId();
        const isValidTenant = result.additionalData.some(company => company.TenantId === currentTenantId);
        
        if (!isValidTenant) {
          // Current tenant is invalid, clear it to force user to select
          clearTenantId();
        }
      }
    } else {
      // No valid tenants found, clear stored value
      clearTenantId();
    }
  } catch (error) {
    console.error('Failed to validate tenant ID:', error);
    // On error, clear tenant to be safe
    clearTenantId();
  }
}