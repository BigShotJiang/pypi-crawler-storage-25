declare module 'jl-vue-oidc-client/vue3-oidc-ts' {
    import { Router } from 'vue-router';
    import {
        UserManagerSettings,
        Logger,
        User,
        UserManager,
        Profile,
        UserManagerEvents
    } from 'oidc-client-ts';

    export enum SignInType {
        Window = 0,
        Popup = 1
    }

    export enum LogLevel {
        None = 0,
        Error = 1,
        Warn = 2,
        Info = 3,
        Debug = 4
    }

    export interface OidcAuth {
        readonly appUrl: string;
        readonly authName: string;
        readonly isAuthenticated: boolean;
        readonly accessToken: string;
        readonly userProfile: Profile;
        readonly events: UserManagerEvents;
        readonly mgr: UserManager;
        startup(): Promise<boolean>;
        useRouter(router: Router): void;
        signIn(args?: any): Promise<User | void>;
        signOut(args?: any): Promise<void>;
        startSilentRenew(): void;
        stopSilentRenew(): void;
    }

    export function createOidcAuth(
        authName: string,
        defaultSignInType: SignInType,
        appUrl: string,
        redirectUrl: string,
        oidcConfig: UserManagerSettings,
        logger?: Logger,
        logLevel?: LogLevel
    ): OidcAuth;
}

declare module '*.vue' {
    import type { DefineComponent } from 'vue'
    const component: DefineComponent<{}, {}, any>
    export default component
}
