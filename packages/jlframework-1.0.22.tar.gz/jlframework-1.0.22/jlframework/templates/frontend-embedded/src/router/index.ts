import { createRouter, createWebHistory, Router, RouteRecordRaw } from 'vue-router';
import { AUTH_NAME, PRIVATE_ROUTE_PATHS, STORAGE_KEY } from '@/utils/const';

/**
 * Create and configure Vue Router instance
 * @param baseUrl - Optional base URL for the router
 * @returns Configured router instance
 */
const getRouter = (baseUrl?: string): Router => {
    const routes: Array<RouteRecordRaw> = [
        {
            path: PRIVATE_ROUTE_PATHS.COMPANY,
            name: 'Company',
            component: () =>
                import(
                    /* webpackChunkName: "Company" */ '@/views/Company.vue'
                ),
            meta: {
                authName: AUTH_NAME,
                title: 'Company Selection',
                requiresAuth: true
            }
        },
        {
            path: PRIVATE_ROUTE_PATHS.PROJECT_DETAILS,
            name: 'ProjectDetails',
            component: () =>
                import(
                    /* webpackChunkName: "ProjectDetails" */ '@/views/ProjectDetails.vue'
                ),
            meta: {
                authName: AUTH_NAME,
                title: 'Project Details',
                requiresAuth: true,
                requiresTenant: true
            }
        },
        // Redirect root to company selection
        {
            path: '/',
            redirect: PRIVATE_ROUTE_PATHS.COMPANY
        },
    ];

    const router = createRouter({
        history: createWebHistory(baseUrl ?? ''),
        scrollBehavior() {
            return { top: 0 };
        },
        routes
    });

    // Navigation guard for route meta titles and tenant validation
    router.beforeEach((to, _from, next) => {
        // Set document title based on route meta
        if (to.meta?.title) {
            document.title = to.meta.title as string;
        }

        const baseIdentityUrl = import.meta.env.VITE_BASE_IDENTITY;
        const isBaseIdentityRoute = baseIdentityUrl && to.path.includes(baseIdentityUrl);
        
        // Check if route requires tenant ID
        if (to.meta?.requiresTenant && to.path !== PRIVATE_ROUTE_PATHS.COMPANY && !isBaseIdentityRoute && to.path !== PRIVATE_ROUTE_PATHS.CALLBACK) {
            const tenantId = sessionStorage.getItem(STORAGE_KEY.TENANT_ID);
            if (!tenantId) {
                console.log('No tenant ID found in session, redirecting to company selection');
                window.location.href = '/company';
                return;
            }
        }
        
        next();
    });

    return router;
};

export default getRouter;
