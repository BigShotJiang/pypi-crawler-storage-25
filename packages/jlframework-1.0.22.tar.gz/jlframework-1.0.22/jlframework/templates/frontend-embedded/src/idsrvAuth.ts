import { createOidcAuth, SignInType, LogLevel } from 'jl-vue-oidc-client/vue3-oidc-ts';
import { oidcSettings } from "./utils/oidc.js";
import { AUTH_NAME, PRIVATE_ROUTE_PATHS } from "./utils/const.js";

const appRootUrl = window.location.origin;

const idsrvAuth = createOidcAuth(
    AUTH_NAME,
    SignInType.Window,
    appRootUrl,
    PRIVATE_ROUTE_PATHS.COMPANY,
    oidcSettings,
    LogLevel.Debug
);

idsrvAuth.events.addAccessTokenExpiring(() => {});
idsrvAuth.events.addAccessTokenExpired(() => {});
idsrvAuth.events.addSilentRenewError(() => {});
idsrvAuth.events.addUserLoaded(() => {});
idsrvAuth.events.addUserUnloaded(() => {});
idsrvAuth.events.addUserSignedOut(() => {});
idsrvAuth.events.addUserSessionChanged(() => {});

export default idsrvAuth;