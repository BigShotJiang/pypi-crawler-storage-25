"""Shared utilities and database management."""
