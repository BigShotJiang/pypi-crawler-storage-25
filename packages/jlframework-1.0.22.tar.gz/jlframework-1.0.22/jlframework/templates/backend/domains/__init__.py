"""Domains package for domain-driven design structure."""
