"""Company domain module."""
