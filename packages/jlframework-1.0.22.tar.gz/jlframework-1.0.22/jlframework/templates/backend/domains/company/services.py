import json
import logging
from contextlib import asynccontextmanager
from typing import Any, Dict, Optional

import httpx

from configs.azure_config import configurations as config


class CompanyService:

    def __init__(self):
        self._config = self._load_config()
        self._token = None
        self._logger = logging.getLogger(__name__)

    def _load_config(self) -> Dict[str, Any]:
        """Load and parse application configuration."""
        try:
            return json.loads(config().app_default)
        except (json.JSONDecodeError, AttributeError) as e:
            self._logger.error(f"Failed to load configuration: {e}")
            raise ValueError("Invalid application configuration") from e

    @asynccontextmanager
    async def _get_http_client(self):
        """Context manager for HTTP client with proper resource cleanup."""
        client = httpx.AsyncClient(timeout=30.0)
        try:
            yield client
        finally:
            await client.aclose()

    async def _get_access_token(self) -> Optional[str]:
        """
        Get an access token using client credentials flow.

        Returns:
            Optional[str]: Access token if successful, None otherwise
        """
        if self._token:
            return self._token

        try:
            identity_url = self._config.get("identity_base_url")
            client_id = self._config.get("client_id")
            client_secret = self._config.get("client_secret")

            if not all([identity_url, client_id, client_secret]):
                self._logger.error(
                    "Missing required authentication configuration")
                return None

            async with self._get_http_client() as client:
                url = f"{identity_url}/connect/token"
                data = {
                    "grant_type": "client_credentials",
                    "client_id": client_id,
                    "client_secret": client_secret,
                }
                headers = {"Content-Type": "application/x-www-form-urlencoded"}

                response = await client.post(url, data=data, headers=headers)
                response.raise_for_status()

                token_data = response.json()
                self._token = token_data.get("access_token")

                if not self._token:
                    self._logger.error(
                        "No access token received from identity server")
                    return None

                return self._token

        except httpx.HTTPError as e:
            self._logger.error(f"HTTP error getting access token: {e}")
            return None
        except Exception as e:
            self._logger.error(f"Unexpected error getting access token: {e}")
            return None

    async def _get_auth_headers(self) -> Dict[str, str]:
        """
        Get headers with authorization token.

        Returns:
            Dict[str, str]: Headers with Bearer token if available, empty dict otherwise
        """
        token = await self._get_access_token()
        if not token:
            return {}

        return {"Authorization": f"Bearer {token}"}

    async def check_subscription(self, tenant_id: str, app_id: int = 299) -> bool:
        """
        Check if the tenant has an active subscription.

        Args:
            tenant_id (str): The tenant identifier
            app_id (int): The application ID (default: 299)

        Returns:
            bool: True if subscription is active, False otherwise
        """
        if not tenant_id:
            self._logger.warning(
                "Empty tenant_id provided for subscription check")
            return False

        try:
            base_url = self._config.get("base_url")
            if not base_url:
                self._logger.error("Missing base_url in configuration")
                return False

            url = f"{base_url}/api/tenancy/{tenant_id}/marketplace/check-subscription"
            headers = await self._get_auth_headers()

            if not headers:
                self._logger.error("Failed to get authentication headers")
                return False

            async with self._get_http_client() as client:
                response = await client.get(
                    url, params={"appId": app_id}, headers=headers
                )
                response.raise_for_status()

                data = response.json()
                return bool(data)  # Ensure boolean return

        except httpx.HTTPError as e:
            self._logger.error(
                f"HTTP error checking subscription for tenant {tenant_id}: {e}"
            )
            return False
        except Exception as e:
            self._logger.error(
                f"Unexpected error checking subscription for tenant {tenant_id}: {e}"
            )
            return False

    async def get_user_tenants(self, current_user: str) -> Dict[str, Any]:
        """
        Get user tenants and check subscription status for each.

        Args:
            current_user (str): The current user identifier

        Returns:
            Dict[str, Any]: User tenant data with subscription status
        """
        if not current_user:
            self._logger.warning("Empty current_user provided")
            return {}

        try:
            base_url = self._config.get("base_url")
            if not base_url:
                self._logger.error("Missing base_url in configuration")
                return {}

            url = f"{base_url}/api/tenantless/uk/companies/get-web-user-detail-by-identity"

            async with self._get_http_client() as client:
                response = await client.get(
                    url, params={"IdentityUserId": current_user}
                )
                response.raise_for_status()

                data = response.json()

                # Enhance tenant data with subscription status
                if data and isinstance(data, list):
                    for tenant in data:
                        if tenant_id := tenant.get("TenantId"):
                            has_subscription = await self.check_subscription(tenant_id)
                            tenant["hasSubscription"] = has_subscription
                        else:
                            tenant["hasSubscription"] = False

                return data or {}

        except httpx.HTTPError as e:
            self._logger.error(
                f"HTTP error getting user tenants for user {current_user}: {e}"
            )
            return {}
        except Exception as e:
            self._logger.error(
                f"Unexpected error getting user tenants for user {current_user}: {e}"
            )
            return {}
