import logging
from typing import Dict, Any

from fastapi import APIRouter, HTTPException, Query, Request, status

from jlframework import CommonManager

from .services import CompanyService

# Set up logging
logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


@router.get("/user-tenants")
async def get_user_tenants(
    current_user: str = Query(..., description="Current user identity ID"),
    request: Request = None,
) -> Dict[str, Any]:
    """Get user tenants with subscription status.

    This endpoint retrieves all tenants associated with a user and checks
    their subscription status for the application.

    Args:
        current_user: User identity ID from the query parameter
        request: FastAPI request object (injected)

    Returns:
        Dict containing user tenant data with subscription information

    Raises:
        HTTPException: If the request fails or user data cannot be retrieved
    """
    try:
        # Log request details
        if request:
            client_info = CommonManager.get_client_info(request)
            logger.info(
                f"Get user tenants request from IP: {client_info['ip']}, User: {current_user}"
            )

        # Create service and get user tenants
        service = CompanyService()
        result = await service.get_user_tenants(current_user.strip())

        if not result:
            logger.warning(f"No tenants found for user: {current_user}")
            return {"data": [], "message": "No tenants found for this user"}

        logger.info(f"Successfully retrieved tenants for user: {current_user}")
        return {"data": result, "message": "Success"}

    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Service configuration error. Please contact support.",
        )
    except Exception as e:
        logger.error(f"Error getting user tenants: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while retrieving user tenants",
        )


@router.get("/check-subscription")
async def check_subscription(
    tenant_id: str = Query(...,
                           description="Tenant ID to check subscription for"),
    app_id: int = Query(299, description="Application ID"),
    request: Request = None,
) -> Dict[str, Any]:
    """Check if a tenant has an active subscription.

    Args:
        tenant_id: Tenant identifier
        app_id: Application ID (default: 299)
        request: FastAPI request object (injected)

    Returns:
        Dict containing subscription status

    Raises:
        HTTPException: If the subscription check fails
    """
    try:
        # Log request details
        if request:
            client_info = CommonManager.get_client_info(request)
            logger.info(
                f"Check subscription request from IP: {client_info['ip']}, Tenant: {tenant_id}"
            )

        # Create service and check subscription
        service = CompanyService()
        has_subscription = await service.check_subscription(tenant_id.strip(), app_id)

        logger.info(
            f"Subscription check for tenant {tenant_id}: {has_subscription}")
        return {
            "hasSubscription": has_subscription,
            "tenantId": tenant_id,
            "appId": app_id,
        }

    except ValueError as e:
        logger.error(f"Configuration error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Service configuration error. Please contact support.",
        )
    except Exception as e:
        logger.error(f"Error checking subscription: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An error occurred while checking subscription",
        )
