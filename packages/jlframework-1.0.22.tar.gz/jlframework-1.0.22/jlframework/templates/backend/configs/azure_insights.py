import logging
import os

from opencensus.ext.azure.log_exporter import AzureLogHandler

# Application Insights connection string from environment
CONNECTION_STRING = os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING")


def setup_logging():
    """Set up Application Insights and console logging."""
    # Set up basic logging
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # Create the Application Insights log handler using connection string
    azure_handler = AzureLogHandler(connection_string=CONNECTION_STRING)
    logger.addHandler(azure_handler)

    # Console logging for development
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] [%(process)d] %(name)s: %(message)s')
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # Set up FastAPI-specific loggers
    fastapi_logger = logging.getLogger("fastapi")
    fastapi_logger.setLevel(logging.INFO)

    uvicorn_logger = logging.getLogger("uvicorn")
    uvicorn_logger.setLevel(logging.INFO)

    # Add handlers to FastAPI and Uvicorn loggers (but prevent propagation to avoid duplicates)
    for fastapi_log in [fastapi_logger, uvicorn_logger]:
        fastapi_log.handlers.clear()
        fastapi_log.addHandler(azure_handler)
        fastapi_log.propagate = False  # Prevent duplicate messages

    return logger
