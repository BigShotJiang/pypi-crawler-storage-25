from functools import lru_cache

from pydantic import field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings with environment variable support"""

    # Application settings
    app_name: str = "{{ app_name }}"
    version: str = "1.0.0"
    description: str = "A production-ready FastAPI application built with JLFramework"
    debug: bool = False

    # Server settings
    host: str = "0.0.0.0"
    port: int = 8000

    @field_validator("debug", mode="before")
    @classmethod
    def parse_debug(cls, v):
        """Parse debug value from string or boolean"""
        if isinstance(v, str):
            return v.lower() in ("true", "1", "yes", "on")
        return v

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": False,
        "extra": "ignore",
    }


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance"""
    return Settings()


# Global settings instance
settings = get_settings()
