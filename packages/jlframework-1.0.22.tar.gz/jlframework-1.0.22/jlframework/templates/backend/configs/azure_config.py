"""Configuration module using jlframework ConfigurationManager.

This module provides a centralized configuration instance for your application
using jlframework's ConfigurationManager.

The ConfigurationManager loads all configuration from Azure App Configuration
using the connection string from your .env file.

Environment Variables Required:
    - APP_CONFIGURATION_CONNECTION_STRING: Azure App Configuration connection string
    - APPLICATION_ENVIRONMENT: Environment label (e.g., "Production", "Uat", "Dev")

Example:
    ```python
    from configs.azure_config import configurations
    
    # Access configuration values
    database_url = configurations.get("DatabaseConnectionString")
    api_key = configurations.get("ApiKey")
    
    # Or use attribute access (backward compatible)
    database_url = configurations.DatabaseConnectionString
    api_key = configurations.ApiKey
    ```
"""

from jlframework.core.config_manager import ConfigurationManager, ConfigurationKeys

# Get the singleton configuration instance
# This loads all configuration from Azure App Configuration
configurations = ConfigurationManager.get_instance()

# Example: Access specific configuration values using ConfigurationKeys
# database_url = configurations.get(ConfigurationKeys.DATABASE_URL)
# api_key = configurations.get(ConfigurationKeys.API_KEY)

# For backward compatibility, you can also use attribute access:
# database_url = configurations.DATABASE_URL
# api_key = configurations.API_KEY

# Example: Access with type conversion
# max_retries = configurations.get_int(ConfigurationKeys.MAX_RETRIES, default=3)
# debug_mode = configurations.get_bool(ConfigurationKeys.DEBUG_MODE, default=False)

# Example: Check if a key exists
# if configurations.has(ConfigurationKeys.FEATURE_FLAG):
#     feature_enabled = configurations.get_bool(ConfigurationKeys.FEATURE_FLAG)

# Example: Get all configurations as a dictionary
# all_configs = configurations.get_all()
