import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader

from jlframework import restrict_access_middleware

from configs.app_config import settings
from configs.azure_insights import setup_logging
from routes import api_router
from shared.database import database_middleware

# Define the tenant ID header for Swagger UI
tenant_id_header = APIKeyHeader(name="x-jl-tenant-id", auto_error=False)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan manager.

    Handles startup and shutdown events for the FastAPI application.

    Args:
        app: The FastAPI application instance.

    Yields:
        None: Control back to the application.
    """
    # Startup
    logging.info("Starting up FastAPI application...")

    # Setup logging (for Azure Insights)
    setup_logging()

    # Log application startup
    logging.info("Application started: %s", settings.app_name)
    logging.info("FastAPI application started successfully")

    yield

    # Shutdown
    logging.info("Shutting down FastAPI application...")
    logging.info("Application shutdown: %s", settings.app_name)
    logging.info("FastAPI application shutdown complete")


# Create FastAPI application
app = FastAPI(
    title=settings.app_name,
    description=settings.description,
    version=settings.version,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
    swagger_ui_parameters={
        "persistAuthorization": True,
    },
)

# Add custom OpenAPI schema to include tenant ID header


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    from fastapi.openapi.utils import get_openapi

    openapi_schema = get_openapi(
        title=settings.app_name,
        version=settings.version,
        description=settings.description,
        routes=app.routes,
    )

    # Add security scheme for tenant ID header
    openapi_schema["components"]["securitySchemes"] = {
        "TenantID": {
            "type": "apiKey",
            "in": "header",
            "name": "x-jl-tenant-id",
            "description": "Tenant ID for multi-tenant access control. Required for all API endpoints."
        }
    }

    # Apply security to all paths
    for path in openapi_schema["paths"]:
        for method in openapi_schema["paths"][path]:
            if method in ["get", "post", "put", "delete", "patch"]:
                openapi_schema["paths"][path][method]["security"] = [
                    {"TenantID": []}]

    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi

# Add CORS middleware with configurable settings
app.add_middleware(
    CORSMiddleware,
    # Configure specific origins in production via environment variables
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=[
        "Accept",
        "Accept-Language",
        "Content-Language",
        "Content-Type",
        "Authorization",
        "x-jl-tenant-id",  # Custom tenant header
    ],
)

# Add custom middlewares (order matters!)
# 1. Database middleware - creates DB session for each request
app.middleware("http")(database_middleware)

# 2. Access restriction middleware - validates tenant ID
app.middleware("http")(restrict_access_middleware)

# Include routers
app.include_router(api_router)

if __name__ == "__main__":
    logging.info(
        "Starting %s on %s:%s", settings.app_name, settings.host, settings.port
    )
    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level="info" if not settings.debug else "debug",
    )
