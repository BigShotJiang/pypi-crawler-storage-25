"""
AioPynamoDB Library
^^^^^^^^^^^^^^^^

A simple async abstraction over DynamoDB

"""
__author__ = 'Bruno Belloni'
__license__ = 'MIT'
__version__ = '1.0.1'
