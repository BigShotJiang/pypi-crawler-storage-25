"""Tests for Archie Connect client instantiation and transport behaviour."""

from __future__ import annotations

import archie_connect
import httpx
import pytest
import respx
from archie_connect.client import Archie, AsyncArchie
from archie_connect.errors import ArchieAuthError, ArchieRateLimitError


# ---------------------------------------------------------------------------
# Instantiation
# ---------------------------------------------------------------------------


def test_sync_client_instantiation():
    """Archie client is created with a valid API key."""
    client = Archie(api_key="sk_test_abc123")
    assert client._api_key == "sk_test_abc123"
    assert client._sandbox is False
    assert client._api_version == Archie.DEFAULT_API_VERSION
    client.close()


def test_async_client_instantiation():
    """AsyncArchie client is created with a valid API key."""
    client = AsyncArchie(api_key="sk_test_abc123")
    assert client._api_key == "sk_test_abc123"
    assert client._api_version == AsyncArchie.DEFAULT_API_VERSION


def test_client_sandbox_flag():
    """sandbox=True flag is stored on the client."""
    client = Archie(api_key="sk_test_xyz", sandbox=True)
    assert client._sandbox is True
    client.close()


def test_client_custom_base_url():
    """Custom base_url is passed to the transport."""
    client = Archie(api_key="sk_test_xyz", base_url="https://api.stuart.dev.arch.ie")
    assert "stuart.dev.arch.ie" in client._transport._base_url
    client.close()


def test_client_api_version_override():
    """Explicit api_version is stored."""
    client = Archie(api_key="sk_test_xyz", api_version="2025-01-01")
    assert client._api_version == "2025-01-01"
    client.close()


def test_client_context_manager():
    """Archie supports context-manager protocol."""
    with Archie(api_key="sk_test_xyz") as client:
        assert client._api_key == "sk_test_xyz"


def test_all_resources_accessible():
    """All 10 resource properties are accessible on the client."""
    client = Archie(api_key="sk_test_xyz")
    assert client.messages is not None
    assert client.search is not None
    assert client.conversations is not None
    assert client.drafts is not None
    assert client.workstreams is not None
    assert client.journal_entries is not None
    assert client.standards is not None
    assert client.documents is not None
    assert client.reports is not None
    assert client.keys is not None
    client.close()


def test_top_level_exports():
    """All documented exports are importable from the top-level package."""
    assert archie_connect.Archie is Archie
    assert archie_connect.AsyncArchie is AsyncArchie
    assert archie_connect.ArchieError is not None
    assert archie_connect.ArchieAuthError is not None
    assert archie_connect.ArchieRateLimitError is not None
    assert archie_connect.MessageResponse is not None


# ---------------------------------------------------------------------------
# Auth header
# ---------------------------------------------------------------------------


@respx.mock
def test_auth_header_is_sent():
    """Every request includes Authorization: Bearer <api_key>."""
    respx.post("https://api.heyarchie.ai/v1/messages").mock(
        return_value=httpx.Response(
            200,
            json={
                "object": "message",
                "id": "msg_01",
                "conversation_id": "conv_01",
                "role": "assistant",
                "content": "Hello",
                "created_at": "2026-04-24T11:00:00.000Z",
            },
        )
    )

    with Archie(api_key="sk_test_mykey") as client:
        client.messages.create("Hello?")

    request = respx.calls.last.request
    assert request.headers["Authorization"] == "Bearer sk_test_mykey"


@respx.mock
def test_user_agent_header_is_sent():
    """User-Agent header identifies the SDK."""
    respx.post("https://api.heyarchie.ai/v1/messages").mock(
        return_value=httpx.Response(
            200,
            json={
                "object": "message",
                "id": "msg_01",
                "conversation_id": "conv_01",
                "role": "assistant",
                "content": "Hi",
                "created_at": "2026-04-24T11:00:00.000Z",
            },
        )
    )

    with Archie(api_key="sk_test_mykey") as client:
        client.messages.create("Hi")

    request = respx.calls.last.request
    assert "archie-connect-python" in request.headers["User-Agent"]


# ---------------------------------------------------------------------------
# Error mapping
# ---------------------------------------------------------------------------


@respx.mock
def test_401_raises_auth_error():
    """A 401 response raises ArchieAuthError."""
    respx.post("https://api.heyarchie.ai/v1/messages").mock(
        return_value=httpx.Response(
            401,
            json={"error": {"type": "authentication_error", "code": "invalid_api_key", "message": "Invalid key"}},
        )
    )

    with pytest.raises(ArchieAuthError) as exc_info:
        with Archie(api_key="sk_test_bad") as client:
            client.messages.create("test")

    assert exc_info.value.status == 401
    assert exc_info.value.code == "invalid_api_key"


@respx.mock
def test_429_raises_rate_limit_error_with_retry_after():
    """A 429 response raises ArchieRateLimitError with retry_after populated."""
    # First call 429, second also 429 (to bypass the auto-retry and still raise)
    respx.post("https://api.heyarchie.ai/v1/messages").mock(
        side_effect=[
            httpx.Response(
                429,
                headers={"Retry-After": "5"},
                json={"error": {"type": "rate_limit_error", "code": "rate_limit_exceeded", "message": "Too many requests"}},
            ),
            httpx.Response(
                429,
                headers={"Retry-After": "5"},
                json={"error": {"type": "rate_limit_error", "code": "rate_limit_exceeded", "message": "Too many requests"}},
            ),
        ]
    )

    # Patch sleep so the test doesn't actually wait
    import unittest.mock

    with unittest.mock.patch("time.sleep"):
        with pytest.raises(ArchieRateLimitError) as exc_info:
            with Archie(api_key="sk_test_rl") as client:
                client.messages.create("test")

    assert exc_info.value.status == 429
    assert exc_info.value.retry_after == 5.0


# ---------------------------------------------------------------------------
# Sandbox URL switching
# ---------------------------------------------------------------------------


def test_sandbox_base_url_override():
    """Custom base_url is reflected in the transport."""
    sandbox_url = "https://api.heyarchie.ai"
    client = Archie(api_key="sk_test_xyz", base_url=sandbox_url, sandbox=True)
    assert client._transport._base_url == sandbox_url
    client.close()
