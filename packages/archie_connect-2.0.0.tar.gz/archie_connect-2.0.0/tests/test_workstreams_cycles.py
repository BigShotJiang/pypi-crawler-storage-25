"""Unit tests for WorkstreamsResource cycle helpers.

plan-087b6914 Phase 3 — assert each cycle method hits the correct
``/api/v1/workstreams/cycles/*`` path with the right body. Uses respx
to mock HTTP — no real API needed.
"""

from __future__ import annotations

import warnings

import httpx
import pytest
import respx
from archie_connect.client import AsyncArchie, Archie


BASE = "https://api.heyarchie.ai"
KEY = "sk_test_ws"


def _async_client() -> AsyncArchie:
    return AsyncArchie(api_key=KEY, base_url=BASE)


def _sync_client() -> Archie:
    return Archie(api_key=KEY, base_url=BASE)


# ---------------------------------------------------------------------------
# Cycle lifecycle (sync)
# ---------------------------------------------------------------------------


class TestSyncCycleLifecycle:
    @respx.mock
    def test_start_cycle(self) -> None:
        route = respx.post(f"{BASE}/api/v1/workstreams/cycles").mock(
            return_value=httpx.Response(
                201, json={"id": "cy-1", "blueprint_id": "bp-1", "status": "running"}
            )
        )
        c = _sync_client()
        result = c.workstreams.start_cycle(
            "bp-1", input_data={"period": "2026Q1"}, priority=3
        )
        assert result.id == "cy-1"
        assert result.status == "running"
        # Confirm body shape
        body = route.calls.last.request.content
        assert b'"blueprint_id":"bp-1"' in body
        assert b'"priority":3' in body

    @respx.mock
    def test_get_cycle(self) -> None:
        respx.get(f"{BASE}/api/v1/workstreams/cycles/cy-1").mock(
            return_value=httpx.Response(
                200, json={"id": "cy-1", "status": "completed", "tasks": []}
            )
        )
        result = _sync_client().workstreams.get_cycle("cy-1")
        assert result.status == "completed"

    @respx.mock
    def test_list_cycles_with_filters(self) -> None:
        route = respx.get(f"{BASE}/api/v1/workstreams/cycles").mock(
            return_value=httpx.Response(
                200, json={"items": [], "pagination": {"total": 0, "limit": 5, "offset": 0, "has_more": False}}
            )
        )
        _sync_client().workstreams.list_cycles(
            blueprint_id="bp-1", status="running", limit=5
        )
        url = str(route.calls.last.request.url)
        assert "blueprint_id=bp-1" in url
        assert "status=running" in url
        assert "limit=5" in url

    @respx.mock
    @pytest.mark.parametrize(
        "method,suffix",
        [
            ("pause_cycle", "/pause"),
            ("resume_cycle", "/resume"),
            ("cancel_cycle", "/cancel"),
            ("restart_cycle", "/restart-workflow"),
        ],
    )
    def test_lifecycle_signal(self, method: str, suffix: str) -> None:
        respx.post(f"{BASE}/api/v1/workstreams/cycles/cy-1{suffix}").mock(
            return_value=httpx.Response(200, json={"id": "cy-1", "status": "paused"})
        )
        result = getattr(_sync_client().workstreams, method)("cy-1")
        assert result.id == "cy-1"

    @respx.mock
    def test_abandon_cycle_returns_none(self) -> None:
        respx.post(f"{BASE}/api/v1/workstreams/cycles/cy-1/abandon").mock(
            return_value=httpx.Response(204)
        )
        result = _sync_client().workstreams.abandon_cycle("cy-1")
        assert result is None

    @respx.mock
    def test_delete_cycle(self) -> None:
        respx.delete(f"{BASE}/api/v1/workstreams/cycles/cy-1").mock(
            return_value=httpx.Response(204)
        )
        _sync_client().workstreams.delete_cycle("cy-1")


# ---------------------------------------------------------------------------
# Task signals
# ---------------------------------------------------------------------------


class TestTaskSignals:
    @respx.mock
    def test_guide_cycle_task(self) -> None:
        route = respx.post(
            f"{BASE}/api/v1/workstreams/cycles/cy-1/tasks/t-1/guide"
        ).mock(return_value=httpx.Response(204))
        _sync_client().workstreams.guide_cycle_task(
            "cy-1", "t-1", "Approved with caveat", option_value="opt-a"
        )
        body = route.calls.last.request.content
        assert b'"response":"Approved with caveat"' in body
        assert b'"option_value":"opt-a"' in body

    @respx.mock
    def test_guide_cycle_task_without_option(self) -> None:
        route = respx.post(
            f"{BASE}/api/v1/workstreams/cycles/cy-1/tasks/t-1/guide"
        ).mock(return_value=httpx.Response(204))
        _sync_client().workstreams.guide_cycle_task("cy-1", "t-1", "ok")
        body = route.calls.last.request.content
        assert b"option_value" not in body  # omitted when None


# ---------------------------------------------------------------------------
# Cycle lifecycle (async)
# ---------------------------------------------------------------------------


class TestAsyncCycleLifecycle:
    @respx.mock
    @pytest.mark.asyncio
    async def test_start_cycle(self) -> None:
        respx.post(f"{BASE}/api/v1/workstreams/cycles").mock(
            return_value=httpx.Response(
                201, json={"id": "cy-2", "blueprint_id": "bp-2", "status": "running"}
            )
        )
        result = await _async_client().workstreams.start_cycle("bp-2")
        assert result.id == "cy-2"

    @respx.mock
    @pytest.mark.asyncio
    async def test_guide_cycle_task(self) -> None:
        respx.post(
            f"{BASE}/api/v1/workstreams/cycles/cy-2/tasks/t-2/guide"
        ).mock(return_value=httpx.Response(204))
        await _async_client().workstreams.guide_cycle_task(
            "cy-2", "t-2", "ack"
        )


# ---------------------------------------------------------------------------
# Deprecation warnings on legacy run / get_run
# ---------------------------------------------------------------------------


class TestLegacyDeprecation:
    @respx.mock
    def test_run_emits_deprecation(self) -> None:
        respx.post(f"{BASE}/v1/workstreams/ws-1/runs").mock(
            return_value=httpx.Response(
                201,
                json={"id": "r-1", "workstream_id": "ws-1", "status": "running"},
            )
        )
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            _sync_client().workstreams.run("ws-1", client_id="c-1")
        assert any(
            issubclass(w.category, DeprecationWarning)
            and "start_cycle" in str(w.message)
            for w in caught
        )

    @respx.mock
    def test_get_run_emits_deprecation(self) -> None:
        respx.get(f"{BASE}/v1/workstreams/ws-1/runs/r-1").mock(
            return_value=httpx.Response(
                200,
                json={"id": "r-1", "workstream_id": "ws-1", "status": "completed"},
            )
        )
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            _sync_client().workstreams.get_run("ws-1", "r-1")
        assert any(
            issubclass(w.category, DeprecationWarning)
            and "get_cycle" in str(w.message)
            for w in caught
        )
