"""Low-level HTTP transport for the Archie Connect SDK.

Responsibilities:
- Attach the Authorization: Bearer header on every request.
- Decode the standard error envelope into typed ArchieError subclasses.
- Automatic single retry on 429 using the Retry-After value.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator, Iterator
from dataclasses import dataclass
from typing import Any

import httpx

from .errors import (
    ArchieAPIError,
    ArchieAuthError,
    ArchieError,
    ArchieIdempotencyError,
    ArchieNotFoundError,
    ArchiePermissionError,
    ArchieRateLimitError,
)


_DEFAULT_TIMEOUT = httpx.Timeout(60.0, connect=10.0)
_STREAM_TIMEOUT = httpx.Timeout(600.0, connect=10.0)


@dataclass
class SkillStreamChunk:
    """A single SSE chunk from a skill stream.

    Attributes:
        delta: The incremental text content of this chunk, or ``None`` for
               non-content events (e.g. ``[DONE]`` or structured metadata).
        event: The SSE event name (``"delta"``, ``"done"``, ``"error"``, etc.).
        data: The full parsed JSON body of the event, if any.
    """

    delta: str | None
    event: str | None
    data: dict[str, Any] | None = None


def _flush_sse_event(
    data_lines: list[str],
    event_name: str | None,
    chunks: list[SkillStreamChunk],
) -> None:
    if not data_lines:
        return
    raw_data = "\n".join(data_lines)
    if raw_data == "[DONE]":
        chunks.append(SkillStreamChunk(delta=None, event="done"))
    else:
        try:
            parsed = json.loads(raw_data)
            delta = parsed.get("delta") if isinstance(parsed, dict) else None
            chunks.append(SkillStreamChunk(delta=delta, event=event_name, data=parsed))
        except json.JSONDecodeError:
            chunks.append(SkillStreamChunk(delta=raw_data, event=event_name))


def _parse_sse_lines(raw: str) -> list[SkillStreamChunk]:
    """Parse one or more SSE events from a raw string block."""
    chunks: list[SkillStreamChunk] = []
    event_name: str | None = None
    data_lines: list[str] = []

    for line in raw.splitlines():
        if line.startswith("event:"):
            event_name = line[6:].strip()
        elif line.startswith("data:"):
            data_lines.append(line[5:].strip())
        elif line == "":
            _flush_sse_event(data_lines, event_name, chunks)
            event_name = None
            data_lines = []

    # Flush any trailing event not terminated by a blank line
    _flush_sse_event(data_lines, event_name, chunks)
    return chunks


def _build_headers(api_key: str, extra: dict[str, str] | None = None) -> dict[str, str]:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "archie-connect-python/0.1.0",
    }
    if extra:
        headers.update(extra)
    return headers


def _raise_for_response(response: httpx.Response) -> None:
    """Parse the response and raise a typed ArchieError if the status is 4xx/5xx."""
    if response.status_code < 400:
        return

    request_id = response.headers.get("X-Request-Id")
    body: Any = None
    code: str | None = None
    message: str = response.reason_phrase or "Unknown error"

    try:
        body = response.json()
        if isinstance(body, dict) and "error" in body:
            err = body["error"]
            code = err.get("code")
            message = err.get("message", message)
            request_id = err.get("request_id", request_id)
    except Exception:
        pass

    status = response.status_code
    kwargs: dict[str, Any] = dict(
        status=status,
        code=code,
        request_id=request_id,
        body=body,
    )

    if status == 401:
        raise ArchieAuthError(message, **kwargs)
    if status == 403:
        raise ArchiePermissionError(message, **kwargs)
    if status == 404:
        raise ArchieNotFoundError(message, **kwargs)
    if status == 422:
        raise ArchieIdempotencyError(message, **kwargs)
    if status == 429:
        retry_after_raw = response.headers.get("Retry-After")
        retry_after = float(retry_after_raw) if retry_after_raw else None
        raise ArchieRateLimitError(message, retry_after=retry_after, **kwargs)
    if status >= 500:
        raise ArchieAPIError(message, **kwargs)

    raise ArchieError(message, **kwargs)


class SyncTransport:
    """Synchronous HTTP transport wrapping httpx.Client."""

    def __init__(self, api_key: str, base_url: str) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=_DEFAULT_TIMEOUT,
        )

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        extra_headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        headers = _build_headers(self._api_key, extra_headers)
        response = self._client.request(
            method,
            path,
            params=params,
            json=json,
            headers=headers,
        )
        if response.status_code == 429:
            # single automatic retry
            retry_after_raw = response.headers.get("Retry-After")
            wait = float(retry_after_raw) if retry_after_raw else 1.0
            time.sleep(min(wait, 60.0))
            response = self._client.request(
                method,
                path,
                params=params,
                json=json,
                headers=headers,
            )
        _raise_for_response(response)
        return response

    def stream(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        extra_headers: dict[str, str] | None = None,
    ) -> Iterator[SkillStreamChunk]:
        """Stream SSE events from a skill endpoint.

        Yields :class:`SkillStreamChunk` objects as events arrive.
        The final ``[DONE]`` event yields a chunk with ``event="done"`` and
        ``delta=None``.
        """
        headers = _build_headers(self._api_key, {"Accept": "text/event-stream", **(extra_headers or {})})
        with self._client.stream(
            method,
            path,
            params=params,
            json=json,
            headers=headers,
            timeout=_STREAM_TIMEOUT,
        ) as response:
            _raise_for_response(response)
            buffer = ""
            for chunk in response.iter_text():
                buffer += chunk
                while "\n\n" in buffer:
                    block, buffer = buffer.split("\n\n", 1)
                    for parsed in _parse_sse_lines(block):
                        yield parsed

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> SyncTransport:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncTransport:
    """Asynchronous HTTP transport wrapping httpx.AsyncClient."""

    def __init__(self, api_key: str, base_url: str) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=_DEFAULT_TIMEOUT,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        extra_headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        import asyncio

        headers = _build_headers(self._api_key, extra_headers)
        response = await self._client.request(
            method,
            path,
            params=params,
            json=json,
            headers=headers,
        )
        if response.status_code == 429:
            retry_after_raw = response.headers.get("Retry-After")
            wait = float(retry_after_raw) if retry_after_raw else 1.0
            await asyncio.sleep(min(wait, 60.0))
            response = await self._client.request(
                method,
                path,
                params=params,
                json=json,
                headers=headers,
            )
        _raise_for_response(response)
        return response

    async def stream(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        extra_headers: dict[str, str] | None = None,
    ) -> AsyncIterator[SkillStreamChunk]:
        """Stream SSE events from a skill endpoint (async).

        Yields :class:`SkillStreamChunk` objects as events arrive.
        """
        headers = _build_headers(self._api_key, {"Accept": "text/event-stream", **(extra_headers or {})})
        async with self._client.stream(
            method,
            path,
            params=params,
            json=json,
            headers=headers,
            timeout=_STREAM_TIMEOUT,
        ) as response:
            _raise_for_response(response)
            buffer = ""
            async for chunk in response.aiter_text():
                buffer += chunk
                while "\n\n" in buffer:
                    block, buffer = buffer.split("\n\n", 1)
                    for parsed in _parse_sse_lines(block):
                        yield parsed

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> AsyncTransport:
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()
