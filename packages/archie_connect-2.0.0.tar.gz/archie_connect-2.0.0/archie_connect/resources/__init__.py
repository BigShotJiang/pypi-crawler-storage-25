"""Resource modules for the Archie Connect SDK."""

from .conversations import AsyncConversationsResource, ConversationsResource
from .documents import AsyncDocumentsResource, DocumentsResource
from .drafts import AsyncDraftsResource, DraftsResource
from .journal_entries import AsyncJournalEntriesResource, JournalEntriesResource
from .keys import AsyncKeysResource, KeysResource
from .messages import AsyncMessagesResource, MessagesResource
from .reports import AsyncReportsResource, ReportsResource
from .search import AsyncSearchResource, SearchResource
from .skills import AsyncSkillsResource, SkillsResource
from .standards import AsyncStandardsResource, StandardsResource
from .workstreams import AsyncWorkstreamsResource, WorkstreamsResource


__all__ = [
    "AsyncConversationsResource",
    "AsyncDocumentsResource",
    "AsyncDraftsResource",
    "AsyncJournalEntriesResource",
    "AsyncKeysResource",
    "AsyncMessagesResource",
    "AsyncReportsResource",
    "AsyncSearchResource",
    "AsyncSkillsResource",
    "AsyncStandardsResource",
    "AsyncWorkstreamsResource",
    "ConversationsResource",
    "DocumentsResource",
    "DraftsResource",
    "JournalEntriesResource",
    "KeysResource",
    "MessagesResource",
    "ReportsResource",
    "SearchResource",
    "SkillsResource",
    "StandardsResource",
    "WorkstreamsResource",
]
