"""Triggers resource — create, list, get, update, and delete playbook triggers.

Sync and async variants mirror the pattern used by PlaybooksResource.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class TriggersResource:
    """Sync triggers resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def create(
        self,
        *,
        playbook_id: str,
        trigger_type: str,
        config: dict[str, Any] | None = None,
        description: str | None = None,
        client_id: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "playbook_id": playbook_id,
            "trigger_type": trigger_type,
            "config": config or {},
        }
        if description is not None:
            body["description"] = description
        if client_id is not None:
            body["client_id"] = client_id
        return self._t.post("/api/v1/playbooks/triggers", json=body)

    def list(self) -> list[dict[str, Any]]:
        return self._t.get("/api/v1/playbooks/triggers")

    def get(self, trigger_id: str) -> dict[str, Any]:
        return self._t.get(f"/api/v1/playbooks/triggers/{trigger_id}")

    def update(
        self,
        trigger_id: str,
        *,
        enabled: bool | None = None,
        config: dict[str, Any] | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if enabled is not None:
            body["enabled"] = enabled
        if config is not None:
            body["config"] = config
        if description is not None:
            body["description"] = description
        return self._t.patch(f"/api/v1/playbooks/triggers/{trigger_id}", json=body)

    def disable(self, trigger_id: str) -> dict[str, Any]:
        return self.update(trigger_id, enabled=False)

    def enable(self, trigger_id: str) -> dict[str, Any]:
        return self.update(trigger_id, enabled=True)

    def delete(self, trigger_id: str) -> None:
        self._t.delete(f"/api/v1/playbooks/triggers/{trigger_id}")


class AsyncTriggersResource:
    """Async triggers resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def create(
        self,
        *,
        playbook_id: str,
        trigger_type: str,
        config: dict[str, Any] | None = None,
        description: str | None = None,
        client_id: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "playbook_id": playbook_id,
            "trigger_type": trigger_type,
            "config": config or {},
        }
        if description is not None:
            body["description"] = description
        if client_id is not None:
            body["client_id"] = client_id
        return await self._t.post("/api/v1/playbooks/triggers", json=body)

    async def list(self) -> list[dict[str, Any]]:
        return await self._t.get("/api/v1/playbooks/triggers")

    async def get(self, trigger_id: str) -> dict[str, Any]:
        return await self._t.get(f"/api/v1/playbooks/triggers/{trigger_id}")

    async def update(
        self,
        trigger_id: str,
        *,
        enabled: bool | None = None,
        config: dict[str, Any] | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {}
        if enabled is not None:
            body["enabled"] = enabled
        if config is not None:
            body["config"] = config
        if description is not None:
            body["description"] = description
        return await self._t.patch(f"/api/v1/playbooks/triggers/{trigger_id}", json=body)

    async def disable(self, trigger_id: str) -> dict[str, Any]:
        return await self.update(trigger_id, enabled=False)

    async def enable(self, trigger_id: str) -> dict[str, Any]:
        return await self.update(trigger_id, enabled=True)

    async def delete(self, trigger_id: str) -> None:
        await self._t.delete(f"/api/v1/playbooks/triggers/{trigger_id}")
