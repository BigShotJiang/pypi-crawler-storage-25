"""Workstreams resource — cycles + lifecycle + task signals.

Stuart's terminology rule: never use "runs" in user-facing API. The
canonical hierarchy is **Workstream → Blueprint → Cycle → Task**. The
``cycle`` methods below target ``/api/v1/workstreams/cycles/*`` and are
the recommended public surface. The legacy ``run`` / ``get_run``
methods remain for back-compat (deprecated).

plan-087b6914 Phase 3 — additive SDK rename.

Two access shapes are supported:

* **Flat** (legacy/internal): ``client.workstreams.start_cycle(...)``,
  ``client.workstreams.list()``, ``client.workstreams.get_cycle(id)``.
* **Nested** (the public-facing shape, matches CONNECT-24H-BRIEF):
  ``client.workstreams.blueprints.list()``,
  ``client.workstreams.cycles.create(blueprint_id=...)``,
  ``client.workstreams.cycles.stream_events(cycle_id)``.

The nested namespaces are zero-cost proxies over the flat methods —
they exist so the externally-documented SDK example reads cleanly.
"""

from __future__ import annotations

import warnings
from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

from ..models import WorkstreamListResponse, WorkstreamRunCreate, WorkstreamRunResponse


if TYPE_CHECKING:
    from .._http import AsyncTransport, SkillStreamChunk, SyncTransport


# ---------------------------------------------------------------------------
# Lightweight response wrap (mirrors ``resources/playbooks._Attrs``) so cycle
# methods can return attribute-accessible dicts without taking a Pydantic
# dep. Cycle response shape evolves on the API side; SDK callers should
# read fields by name.
# ---------------------------------------------------------------------------


class _Attrs(dict):
    def __getattr__(self, name: str) -> Any:
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc


def _wrap(data: Any) -> Any:
    if isinstance(data, dict):
        return _Attrs({k: _wrap(v) for k, v in data.items()})
    if isinstance(data, list):
        return [_wrap(i) for i in data]
    return data


# ---------------------------------------------------------------------------
# Sync resource
# ---------------------------------------------------------------------------


class WorkstreamsResource:
    """Synchronous workstreams resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport
        # Public nested namespaces — see module docstring.
        self.blueprints = _BlueprintsNamespace(self)
        self.cycles = _CyclesNamespace(self)

    # ------------------------------------------------------------------
    # Workstream definitions (list)
    # ------------------------------------------------------------------

    def list(
        self,
        *,
        limit: int = 20,
        after: str | None = None,
        client_id: str | None = None,
    ) -> WorkstreamListResponse:
        """List available workstream blueprints for the caller's organisation.

        Args:
            limit: Page size (1-100, default 20).
            after: Cursor for pagination.
            client_id: Filter blueprints by client.

        Returns:
            WorkstreamListResponse.
        """
        params: dict[str, Any] = {"limit": limit}
        if after:
            params["after"] = after
        if client_id:
            params["client_id"] = client_id
        response = self._transport.request("GET", "/v1/workstreams", params=params)
        return WorkstreamListResponse.model_validate(response.json())

    # ------------------------------------------------------------------
    # Cycle lifecycle (canonical surface — Phase 3 of plan-087b6914)
    # ------------------------------------------------------------------

    def start_cycle(
        self,
        blueprint_id: str,
        *,
        input_data: dict[str, Any] | None = None,
        priority: int = 5,
    ) -> _Attrs:
        """Start a new cycle for a blueprint.

        Args:
            blueprint_id: Blueprint UUID to instantiate.
            input_data: Cycle input vars (e.g. period, account_ids).
            priority: Execution priority 1-10 (1 = highest, default 5).

        Returns:
            Cycle row (id, status, blueprint_id, etc.). Status is
            ``running`` on success.
        """
        body: dict[str, Any] = {
            "blueprint_id": blueprint_id,
            "input_data": input_data or {},
            "priority": priority,
        }
        resp = self._transport.request("POST", "/api/v1/workstreams/cycles", json=body)
        return _wrap(resp.json())

    def get_cycle(self, cycle_id: str) -> _Attrs:
        """Retrieve a cycle (with embedded tasks) by UUID."""
        resp = self._transport.request("GET", f"/api/v1/workstreams/cycles/{cycle_id}")
        return _wrap(resp.json())

    def list_cycles(
        self,
        *,
        blueprint_id: str | None = None,
        client_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> _Attrs:
        """List cycles (fleet view) with filters."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if blueprint_id:
            params["blueprint_id"] = blueprint_id
        if client_id:
            params["client_id"] = client_id
        if status:
            params["status"] = status
        resp = self._transport.request("GET", "/api/v1/workstreams/cycles", params=params)
        return _wrap(resp.json())

    def pause_cycle(self, cycle_id: str) -> _Attrs:
        """Pause a running cycle."""
        resp = self._transport.request("POST", f"/api/v1/workstreams/cycles/{cycle_id}/pause")
        return _wrap(resp.json())

    def resume_cycle(self, cycle_id: str) -> _Attrs:
        """Resume a paused cycle."""
        resp = self._transport.request("POST", f"/api/v1/workstreams/cycles/{cycle_id}/resume")
        return _wrap(resp.json())

    def cancel_cycle(self, cycle_id: str) -> _Attrs:
        """Cancel a cycle (emergency stop)."""
        resp = self._transport.request("POST", f"/api/v1/workstreams/cycles/{cycle_id}/cancel")
        return _wrap(resp.json())

    def abandon_cycle(self, cycle_id: str) -> None:
        """Abandon a paused cycle (transition to terminal abandoned state).

        Distinct from ``cancel_cycle``: cancel signals a workflow to
        terminate from any active state. Abandon is for paused cycles
        that are no longer interesting.
        """
        self._transport.request("POST", f"/api/v1/workstreams/cycles/{cycle_id}/abandon")

    def restart_cycle(self, cycle_id: str) -> _Attrs:
        """Restart the underlying Temporal workflow for a cycle."""
        resp = self._transport.request(
            "POST", f"/api/v1/workstreams/cycles/{cycle_id}/restart-workflow"
        )
        return _wrap(resp.json())

    def delete_cycle(self, cycle_id: str) -> None:
        """Soft-delete a cycle."""
        self._transport.request("DELETE", f"/api/v1/workstreams/cycles/{cycle_id}")

    # ------------------------------------------------------------------
    # Task-level signals on cycles
    # ------------------------------------------------------------------

    def guide_cycle_task(
        self,
        cycle_id: str,
        task_id: str,
        response: str,
        *,
        option_value: str | None = None,
    ) -> None:
        """Provide guidance to unblock a task awaiting human input.

        Args:
            cycle_id: Cycle UUID.
            task_id: Task UUID (the underlying ``workstreams.task.id``).
            response: Free-text guidance reply.
            option_value: Selected choice (when the task offered options).
        """
        body: dict[str, Any] = {"response": response}
        if option_value is not None:
            body["option_value"] = option_value
        self._transport.request(
            "POST",
            f"/api/v1/workstreams/cycles/{cycle_id}/tasks/{task_id}/guide",
            json=body,
        )

    # ------------------------------------------------------------------
    # Drafts (Spec 12 §2.5) — workstream authoring loop
    # plan-369d2c00 Phase 7a — moved from PlaybooksResource.draft_*
    # ------------------------------------------------------------------

    def draft_create(
        self,
        topic_id: str,
        *,
        initial_message: str | None = None,
        draft_definition: dict[str, Any] | None = None,
    ) -> _Attrs:
        """Start a new conversational workstream draft anchored to a Topic."""
        body: dict[str, Any] = {"topic_id": topic_id}
        if initial_message is not None:
            body["initial_message"] = initial_message
        if draft_definition is not None:
            body["draft_definition"] = draft_definition
        resp = self._transport.request("POST", "/api/v1/workstream-drafts", json=body)
        return _wrap(resp.json())

    def draft_list(
        self,
        *,
        topic_id: str | None = None,
        author_user_id: str | None = None,
        status: str | None = "drafting",
        limit: int = 50,
        offset: int = 0,
    ) -> _Attrs:
        """List drafts visible to the workspace."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if topic_id is not None:
            params["topic_id"] = topic_id
        if author_user_id is not None:
            params["author_user_id"] = author_user_id
        if status is not None:
            params["status"] = status
        resp = self._transport.request("GET", "/api/v1/workstream-drafts", params=params)
        return _wrap(resp.json())

    def draft_get(self, draft_id: str) -> _Attrs:
        resp = self._transport.request("GET", f"/api/v1/workstream-drafts/{draft_id}")
        return _wrap(resp.json())

    def draft_update(
        self,
        draft_id: str,
        *,
        message: str | None = None,
        draft_definition: dict[str, Any] | None = None,
        validation_errors: list[dict[str, Any]] | None = None,
    ) -> _Attrs:
        """Iterate on a draft (append message → regenerate, or override)."""
        body: dict[str, Any] = {}
        if message is not None:
            body["message"] = message
        if draft_definition is not None:
            body["draft_definition"] = draft_definition
        if validation_errors is not None:
            body["validation_errors"] = validation_errors
        resp = self._transport.request("PATCH", f"/api/v1/workstream-drafts/{draft_id}", json=body)
        return _wrap(resp.json())

    def draft_commit(
        self,
        draft_id: str,
        *,
        scope: str = "user",
        name: str | None = None,
        slug: str | None = None,
        scope_owner_id: str | None = None,
    ) -> _Attrs:
        """Commit a draft into a real Workstream. Returns ``{draft, playbook}``."""
        body: dict[str, Any] = {"scope": scope}
        if name is not None:
            body["name"] = name
        if slug is not None:
            body["slug"] = slug
        if scope_owner_id is not None:
            body["scope_owner_id"] = scope_owner_id
        resp = self._transport.request(
            "POST", f"/api/v1/workstream-drafts/{draft_id}/commit", json=body
        )
        return _wrap(resp.json())

    def draft_abandon(self, draft_id: str) -> None:
        self._transport.request("DELETE", f"/api/v1/workstream-drafts/{draft_id}")

    # ------------------------------------------------------------------
    # Legacy: ``run`` / ``get_run`` — DEPRECATED
    # ------------------------------------------------------------------
    #
    # These methods predate the workstreams unification (plan-087b6914)
    # and use the ``runs`` noun that Stuart's terminology rule forbids
    # in user-facing API. New code should call ``start_cycle`` /
    # ``get_cycle``. Kept for back-compat; will be removed once
    # consumers migrate (Phase 5 of plan-087b6914).

    def run(
        self,
        workstream_id: str,
        client_id: str,
        *,
        period: str | None = None,
        parameters: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> WorkstreamRunResponse:
        """Deprecated — use :meth:`start_cycle` instead."""
        warnings.warn(
            "WorkstreamsResource.run() is deprecated; use start_cycle(blueprint_id, ...) "
            "for the canonical /workstreams/cycles surface (plan-087b6914 Phase 3).",
            DeprecationWarning,
            stacklevel=2,
        )
        body = WorkstreamRunCreate(
            client_id=client_id,
            period=period,
            parameters=parameters,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = self._transport.request(
            "POST",
            f"/v1/workstreams/{workstream_id}/runs",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return WorkstreamRunResponse.model_validate(response.json())

    def get_run(self, workstream_id: str, run_id: str) -> WorkstreamRunResponse:
        """Deprecated — use :meth:`get_cycle` instead."""
        warnings.warn(
            "WorkstreamsResource.get_run() is deprecated; use get_cycle(cycle_id) "
            "for the canonical /workstreams/cycles surface (plan-087b6914 Phase 3).",
            DeprecationWarning,
            stacklevel=2,
        )
        response = self._transport.request("GET", f"/v1/workstreams/{workstream_id}/runs/{run_id}")
        return WorkstreamRunResponse.model_validate(response.json())

    # ------------------------------------------------------------------
    # SSE — cycle events stream
    # ------------------------------------------------------------------

    def stream_cycle_events(self, cycle_id: str) -> Iterator[SkillStreamChunk]:
        """Stream live events from a cycle's SSE channel.

        Wraps ``GET /api/v1/workstreams/cycles/{cycle_id}/events``. Yields
        :class:`~archie_connect._http.SkillStreamChunk` objects as events
        arrive (one per SSE ``data:`` frame). The stream ends when the
        server closes or a ``done`` chunk arrives.

        Example::

            for chunk in client.workstreams.cycles.stream_events(cycle.id):
                if chunk.event == "task_completed":
                    print(chunk.delta)
        """
        yield from self._transport.stream(
            "GET",
            f"/api/v1/workstreams/cycles/{cycle_id}/events",
        )


# ---------------------------------------------------------------------------
# Nested namespaces (public-facing shape per CONNECT-24H-BRIEF)
# ---------------------------------------------------------------------------


class _BlueprintsNamespace:
    """``client.workstreams.blueprints.*`` — workstream definition surface."""

    def __init__(self, parent: WorkstreamsResource) -> None:
        self._parent = parent

    def list(
        self,
        *,
        limit: int = 20,
        after: str | None = None,
        client_id: str | None = None,
    ) -> WorkstreamListResponse:
        """List available workstream blueprints. Proxies to ``workstreams.list``."""
        return self._parent.list(limit=limit, after=after, client_id=client_id)


class _CyclesNamespace:
    """``client.workstreams.cycles.*`` — cycle lifecycle + event streaming."""

    def __init__(self, parent: WorkstreamsResource) -> None:
        self._parent = parent

    def create(
        self,
        blueprint_id: str,
        *,
        input_data: dict[str, Any] | None = None,
        priority: int = 5,
    ) -> _Attrs:
        """Start a new cycle. Proxies to ``workstreams.start_cycle``."""
        return self._parent.start_cycle(blueprint_id, input_data=input_data, priority=priority)

    def get(self, cycle_id: str) -> _Attrs:
        """Get cycle (with embedded tasks). Proxies to ``workstreams.get_cycle``."""
        return self._parent.get_cycle(cycle_id)

    def list(
        self,
        *,
        blueprint_id: str | None = None,
        client_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> _Attrs:
        """List cycles. Proxies to ``workstreams.list_cycles``."""
        return self._parent.list_cycles(
            blueprint_id=blueprint_id,
            client_id=client_id,
            status=status,
            limit=limit,
            offset=offset,
        )

    def pause(self, cycle_id: str) -> _Attrs:
        return self._parent.pause_cycle(cycle_id)

    def resume(self, cycle_id: str) -> _Attrs:
        return self._parent.resume_cycle(cycle_id)

    def cancel(self, cycle_id: str) -> _Attrs:
        return self._parent.cancel_cycle(cycle_id)

    def abandon(self, cycle_id: str) -> None:
        self._parent.abandon_cycle(cycle_id)

    def stream_events(self, cycle_id: str) -> Iterator[SkillStreamChunk]:
        """Stream live SSE events from a cycle.

        Proxies to ``workstreams.stream_cycle_events``. Yields
        :class:`~archie_connect._http.SkillStreamChunk` per event frame.
        """
        return self._parent.stream_cycle_events(cycle_id)


# ---------------------------------------------------------------------------
# Async resource
# ---------------------------------------------------------------------------


class AsyncWorkstreamsResource:
    """Asynchronous workstreams resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def list(
        self,
        *,
        limit: int = 20,
        after: str | None = None,
        client_id: str | None = None,
    ) -> WorkstreamListResponse:
        params: dict[str, Any] = {"limit": limit}
        if after:
            params["after"] = after
        if client_id:
            params["client_id"] = client_id
        response = await self._transport.request("GET", "/v1/workstreams", params=params)
        return WorkstreamListResponse.model_validate(response.json())

    # ------------------------------------------------------------------
    # Cycle lifecycle (async)
    # ------------------------------------------------------------------

    async def start_cycle(
        self,
        blueprint_id: str,
        *,
        input_data: dict[str, Any] | None = None,
        priority: int = 5,
    ) -> _Attrs:
        body: dict[str, Any] = {
            "blueprint_id": blueprint_id,
            "input_data": input_data or {},
            "priority": priority,
        }
        resp = await self._transport.request("POST", "/api/v1/workstreams/cycles", json=body)
        return _wrap(resp.json())

    async def get_cycle(self, cycle_id: str) -> _Attrs:
        resp = await self._transport.request("GET", f"/api/v1/workstreams/cycles/{cycle_id}")
        return _wrap(resp.json())

    async def list_cycles(
        self,
        *,
        blueprint_id: str | None = None,
        client_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> _Attrs:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if blueprint_id:
            params["blueprint_id"] = blueprint_id
        if client_id:
            params["client_id"] = client_id
        if status:
            params["status"] = status
        resp = await self._transport.request("GET", "/api/v1/workstreams/cycles", params=params)
        return _wrap(resp.json())

    async def pause_cycle(self, cycle_id: str) -> _Attrs:
        resp = await self._transport.request("POST", f"/api/v1/workstreams/cycles/{cycle_id}/pause")
        return _wrap(resp.json())

    async def resume_cycle(self, cycle_id: str) -> _Attrs:
        resp = await self._transport.request(
            "POST", f"/api/v1/workstreams/cycles/{cycle_id}/resume"
        )
        return _wrap(resp.json())

    async def cancel_cycle(self, cycle_id: str) -> _Attrs:
        resp = await self._transport.request(
            "POST", f"/api/v1/workstreams/cycles/{cycle_id}/cancel"
        )
        return _wrap(resp.json())

    async def abandon_cycle(self, cycle_id: str) -> None:
        await self._transport.request("POST", f"/api/v1/workstreams/cycles/{cycle_id}/abandon")

    async def restart_cycle(self, cycle_id: str) -> _Attrs:
        resp = await self._transport.request(
            "POST", f"/api/v1/workstreams/cycles/{cycle_id}/restart-workflow"
        )
        return _wrap(resp.json())

    async def delete_cycle(self, cycle_id: str) -> None:
        await self._transport.request("DELETE", f"/api/v1/workstreams/cycles/{cycle_id}")

    async def guide_cycle_task(
        self,
        cycle_id: str,
        task_id: str,
        response: str,
        *,
        option_value: str | None = None,
    ) -> None:
        body: dict[str, Any] = {"response": response}
        if option_value is not None:
            body["option_value"] = option_value
        await self._transport.request(
            "POST",
            f"/api/v1/workstreams/cycles/{cycle_id}/tasks/{task_id}/guide",
            json=body,
        )

    # ------------------------------------------------------------------
    # Drafts (Spec 12 §2.5) — workstream authoring loop
    # plan-369d2c00 Phase 7a — async equivalents
    # ------------------------------------------------------------------

    async def draft_create(
        self,
        topic_id: str,
        *,
        initial_message: str | None = None,
        draft_definition: dict[str, Any] | None = None,
    ) -> _Attrs:
        body: dict[str, Any] = {"topic_id": topic_id}
        if initial_message is not None:
            body["initial_message"] = initial_message
        if draft_definition is not None:
            body["draft_definition"] = draft_definition
        resp = await self._transport.request("POST", "/api/v1/workstream-drafts", json=body)
        return _wrap(resp.json())

    async def draft_list(
        self,
        *,
        topic_id: str | None = None,
        author_user_id: str | None = None,
        status: str | None = "drafting",
        limit: int = 50,
        offset: int = 0,
    ) -> _Attrs:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if topic_id is not None:
            params["topic_id"] = topic_id
        if author_user_id is not None:
            params["author_user_id"] = author_user_id
        if status is not None:
            params["status"] = status
        resp = await self._transport.request("GET", "/api/v1/workstream-drafts", params=params)
        return _wrap(resp.json())

    async def draft_get(self, draft_id: str) -> _Attrs:
        resp = await self._transport.request("GET", f"/api/v1/workstream-drafts/{draft_id}")
        return _wrap(resp.json())

    async def draft_update(
        self,
        draft_id: str,
        *,
        message: str | None = None,
        draft_definition: dict[str, Any] | None = None,
        validation_errors: list[dict[str, Any]] | None = None,
    ) -> _Attrs:
        body: dict[str, Any] = {}
        if message is not None:
            body["message"] = message
        if draft_definition is not None:
            body["draft_definition"] = draft_definition
        if validation_errors is not None:
            body["validation_errors"] = validation_errors
        resp = await self._transport.request(
            "PATCH", f"/api/v1/workstream-drafts/{draft_id}", json=body
        )
        return _wrap(resp.json())

    async def draft_commit(
        self,
        draft_id: str,
        *,
        scope: str = "user",
        name: str | None = None,
        slug: str | None = None,
        scope_owner_id: str | None = None,
    ) -> _Attrs:
        body: dict[str, Any] = {"scope": scope}
        if name is not None:
            body["name"] = name
        if slug is not None:
            body["slug"] = slug
        if scope_owner_id is not None:
            body["scope_owner_id"] = scope_owner_id
        resp = await self._transport.request(
            "POST", f"/api/v1/workstream-drafts/{draft_id}/commit", json=body
        )
        return _wrap(resp.json())

    async def draft_abandon(self, draft_id: str) -> None:
        await self._transport.request("DELETE", f"/api/v1/workstream-drafts/{draft_id}")

    # ------------------------------------------------------------------
    # Legacy: ``run`` / ``get_run`` — DEPRECATED
    # ------------------------------------------------------------------

    async def run(
        self,
        workstream_id: str,
        client_id: str,
        *,
        period: str | None = None,
        parameters: dict[str, Any] | None = None,
        idempotency_key: str | None = None,
    ) -> WorkstreamRunResponse:
        """Deprecated — use :meth:`start_cycle` instead."""
        warnings.warn(
            "AsyncWorkstreamsResource.run() is deprecated; use start_cycle(blueprint_id, ...) "
            "for the canonical /workstreams/cycles surface (plan-087b6914 Phase 3).",
            DeprecationWarning,
            stacklevel=2,
        )
        body = WorkstreamRunCreate(
            client_id=client_id,
            period=period,
            parameters=parameters,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = await self._transport.request(
            "POST",
            f"/v1/workstreams/{workstream_id}/runs",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return WorkstreamRunResponse.model_validate(response.json())

    async def get_run(self, workstream_id: str, run_id: str) -> WorkstreamRunResponse:
        """Deprecated — use :meth:`get_cycle` instead."""
        warnings.warn(
            "AsyncWorkstreamsResource.get_run() is deprecated; use get_cycle(cycle_id) "
            "for the canonical /workstreams/cycles surface (plan-087b6914 Phase 3).",
            DeprecationWarning,
            stacklevel=2,
        )
        response = await self._transport.request(
            "GET", f"/v1/workstreams/{workstream_id}/runs/{run_id}"
        )
        return WorkstreamRunResponse.model_validate(response.json())
