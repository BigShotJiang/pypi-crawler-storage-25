"""API Keys resource — flush-cache and key management helpers.

The gateway exposes a ``POST /v1/keys/{id}/flush-cache`` admin operation.
This module also wraps a hypothetical management surface for listing and
creating keys (which lives on the management plane, not the data plane).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models import KeyCreate, KeyListResponse, KeyResponse


if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class KeysResource:
    """Synchronous keys resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def list(self, *, limit: int = 20, after: str | None = None) -> KeyListResponse:
        """List API keys for the caller's organisation.

        Args:
            limit: Page size (1–100, default 20).
            after: Cursor for forward pagination.

        Returns:
            KeyListResponse. Secret values are never returned on list.
        """
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        response = self._transport.request("GET", "/v1/keys", params=params)
        return KeyListResponse.model_validate(response.json())

    def create(self, name: str, permissions: list[str], *, description: str | None = None) -> KeyResponse:
        """Create a new API key.

        Args:
            name: Human-readable name for the key.
            permissions: List of permission scopes (e.g. ``["messages:create", "search:read"]``).
            description: Optional description.

        Returns:
            KeyResponse — the ``secret`` field is only present on this initial response.
        """
        body = KeyCreate(name=name, permissions=permissions, description=description)
        response = self._transport.request(
            "POST",
            "/v1/keys",
            json=body.model_dump(exclude_none=True),
        )
        return KeyResponse.model_validate(response.json())

    def revoke(self, key_id: str) -> None:
        """Revoke (delete) an API key.

        Args:
            key_id: The key ID to revoke.
        """
        self._transport.request("DELETE", f"/v1/keys/{key_id}")

    def flush_cache(self, key_id: str) -> None:
        """Flush the Redis auth-cache entry for a key (admin-only).

        Requires the caller's session cookie to carry the ``archie-admin`` role.

        Args:
            key_id: The key ID whose cache entry to flush.
        """
        self._transport.request("POST", f"/v1/keys/{key_id}/flush-cache")


class AsyncKeysResource:
    """Asynchronous keys resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def list(self, *, limit: int = 20, after: str | None = None) -> KeyListResponse:
        params: dict = {"limit": limit}
        if after:
            params["after"] = after
        response = await self._transport.request("GET", "/v1/keys", params=params)
        return KeyListResponse.model_validate(response.json())

    async def create(
        self, name: str, permissions: list[str], *, description: str | None = None
    ) -> KeyResponse:
        body = KeyCreate(name=name, permissions=permissions, description=description)
        response = await self._transport.request(
            "POST",
            "/v1/keys",
            json=body.model_dump(exclude_none=True),
        )
        return KeyResponse.model_validate(response.json())

    async def revoke(self, key_id: str) -> None:
        await self._transport.request("DELETE", f"/v1/keys/{key_id}")

    async def flush_cache(self, key_id: str) -> None:
        await self._transport.request("POST", f"/v1/keys/{key_id}/flush-cache")
