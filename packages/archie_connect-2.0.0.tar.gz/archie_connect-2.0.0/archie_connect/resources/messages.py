"""Messages resource — POST /v1/messages, GET /v1/messages/{id}."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..models import MessageCreate, MessageResponse


if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class MessagesResource:
    """Synchronous messages resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def create(
        self,
        query: str,
        *,
        client_id: str | None = None,
        conversation_id: str | None = None,
        context: dict[str, Any] | None = None,
        stream: bool = False,
        idempotency_key: str | None = None,
    ) -> MessageResponse:
        """Create a message (ask Archie a question).

        Args:
            query: The accounting question, 1–8000 characters.
            client_id: The client to scope this query to.
            conversation_id: Continue an existing conversation.
            context: Arbitrary skill-specific runtime variables.
            stream: If True, raises NotImplementedError (use AsyncArchie for streaming).
            idempotency_key: Optional client-provided idempotency key.

        Returns:
            MessageResponse with the assistant's answer and citations.
        """
        if stream:
            raise NotImplementedError(
                "Synchronous streaming is not supported. "
                "Use AsyncArchie.messages.create(stream=True) instead."
            )
        body = MessageCreate(
            query=query,
            client_id=client_id,
            conversation_id=conversation_id,
            context=context,
            stream=False,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = self._transport.request(
            "POST",
            "/v1/messages",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return MessageResponse.model_validate(response.json())

    def retrieve(self, message_id: str) -> MessageResponse:
        """Retrieve a previously created message by ID.

        Args:
            message_id: The message ID (e.g. ``msg_01HX9…``).

        Returns:
            MessageResponse.
        """
        response = self._transport.request("GET", f"/v1/messages/{message_id}")
        return MessageResponse.model_validate(response.json())


class AsyncMessagesResource:
    """Asynchronous messages resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def create(
        self,
        query: str,
        *,
        client_id: str | None = None,
        conversation_id: str | None = None,
        context: dict[str, Any] | None = None,
        stream: bool = False,
        idempotency_key: str | None = None,
    ) -> MessageResponse:
        if stream:
            raise NotImplementedError(
                "Async streaming via SSE is not yet supported in v0.1.0. "
                "Pass stream=False or use the raw httpx client."
            )
        body = MessageCreate(
            query=query,
            client_id=client_id,
            conversation_id=conversation_id,
            context=context,
            stream=False,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = await self._transport.request(
            "POST",
            "/v1/messages",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return MessageResponse.model_validate(response.json())

    async def retrieve(self, message_id: str) -> MessageResponse:
        response = await self._transport.request("GET", f"/v1/messages/{message_id}")
        return MessageResponse.model_validate(response.json())
