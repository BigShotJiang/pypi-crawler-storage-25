"""Reports resource — POST /v1/reports/{id}/exports."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models import ReportExportCreate, ReportExportResponse


if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


class ReportsResource:
    """Synchronous reports resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def export(
        self,
        report_id: str,
        *,
        format: str = "pdf",
        include_citations: bool = True,
        idempotency_key: str | None = None,
    ) -> ReportExportResponse:
        """Produce a downloadable export of a report.

        Args:
            report_id: The report ID (e.g. ``rpt_01HX…``).
            format: Export format — ``"pdf"`` or ``"csv"`` (default ``"pdf"``).
            include_citations: Whether to embed citations in the export.
            idempotency_key: Optional client-provided idempotency key.

        Returns:
            ReportExportResponse with ``download_url`` once ``status == "ready"``.
        """
        body = ReportExportCreate(
            format=format,  # type: ignore[arg-type]
            include_citations=include_citations,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = self._transport.request(
            "POST",
            f"/v1/reports/{report_id}/exports",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return ReportExportResponse.model_validate(response.json())


class AsyncReportsResource:
    """Asynchronous reports resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def export(
        self,
        report_id: str,
        *,
        format: str = "pdf",
        include_citations: bool = True,
        idempotency_key: str | None = None,
    ) -> ReportExportResponse:
        body = ReportExportCreate(
            format=format,  # type: ignore[arg-type]
            include_citations=include_citations,
        )
        extra_headers: dict[str, str] = {}
        if idempotency_key:
            extra_headers["Idempotency-Key"] = idempotency_key
        response = await self._transport.request(
            "POST",
            f"/v1/reports/{report_id}/exports",
            json=body.model_dump(exclude_none=True),
            extra_headers=extra_headers or None,
        )
        return ReportExportResponse.model_validate(response.json())
