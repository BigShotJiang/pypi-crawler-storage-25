"""Conversations resource — POST/GET/PATCH /v1/conversations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..models import (
    ChatMessage,
    ConversationListResponse,
    ConversationResponse,
    ConversationTurnRequest,
    ConversationTurnResponse,
    ConversationUpdate,
)


if TYPE_CHECKING:
    from .._http import AsyncTransport, SyncTransport


def _build_turn_body(
    *,
    message: str | None,
    messages: list[ChatMessage] | list[dict[str, Any]] | None,
    conversation_id: str | None,
    client_id: str | None,
    locale: str,
    jurisdiction: str,
) -> dict[str, Any]:
    if message is None and not messages:
        raise ValueError("Provide either `message=...` or `messages=[...]`.")
    body = ConversationTurnRequest(
        message=message,
        messages=[
            m if isinstance(m, ChatMessage) else ChatMessage.model_validate(m)
            for m in (messages or [])
        ]
        or None,
        conversation_id=conversation_id,
        client_id=client_id,
        locale=locale,
        jurisdiction=jurisdiction,
    )
    return body.model_dump(exclude_none=True)


class ConversationsResource:
    """Synchronous conversations resource."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def create(
        self,
        *,
        message: str | None = None,
        messages: list[ChatMessage] | list[dict[str, Any]] | None = None,
        conversation_id: str | None = None,
        client_id: str | None = None,
        locale: str = "en-AU",
        jurisdiction: str = "AU",
    ) -> ConversationTurnResponse:
        """Send one turn of a conversation. Returns Archie's reply.

        Pass either ``message="..."`` for one-shot calls, or ``messages=[...]``
        with the full OpenAI-style chat history for multi-turn. Echo back
        ``conversation_id`` from the prior response to thread turns.

        Args:
            message: Single user turn shorthand.
            messages: OpenAI-style ``[{role, content}, ...]`` history.
            conversation_id: Echo from a prior reply to thread the conversation.
            client_id: Optional workspace/client scope.
            locale: BCP-47 locale, defaults to ``"en-AU"``.
            jurisdiction: ISO-3166 alpha-2, defaults to ``"AU"``.

        Returns:
            ConversationTurnResponse with the assistant reply and citations.
        """
        body = _build_turn_body(
            message=message,
            messages=messages,
            conversation_id=conversation_id,
            client_id=client_id,
            locale=locale,
            jurisdiction=jurisdiction,
        )
        response = self._transport.request("POST", "/v1/conversations", json=body)
        return ConversationTurnResponse.model_validate(response.json())

    def list(
        self,
        *,
        limit: int = 20,
        after: str | None = None,
        before: str | None = None,
        client_id: str | None = None,
        status: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
    ) -> ConversationListResponse:
        """List conversations for the caller's organisation.

        Args:
            limit: Number of results per page (1–100, default 20).
            after: Cursor for forward pagination.
            before: Cursor for backward pagination.
            client_id: Filter by client.
            status: Filter by status (``"active"`` or ``"archived"``).
            created_after: ISO-8601 lower bound on creation time.
            created_before: ISO-8601 upper bound on creation time.

        Returns:
            ConversationListResponse.
        """
        params: dict[str, Any] = {"limit": limit}
        if after:
            params["after"] = after
        if before:
            params["before"] = before
        if client_id:
            params["client_id"] = client_id
        if status:
            params["status"] = status
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before

        response = self._transport.request("GET", "/v1/conversations", params=params)
        return ConversationListResponse.model_validate(response.json())

    def get(self, conversation_id: str, *, expand: list[str] | None = None) -> ConversationResponse:
        """Retrieve a single conversation.

        Args:
            conversation_id: The conversation ID.
            expand: Optional expansions, e.g. ``["messages", "client"]``.

        Returns:
            ConversationResponse.
        """
        params: dict[str, Any] = {}
        if expand:
            params["expand[]"] = expand
        response = self._transport.request(
            "GET", f"/v1/conversations/{conversation_id}", params=params or None
        )
        return ConversationResponse.model_validate(response.json())

    def update(
        self,
        conversation_id: str,
        *,
        title: str | None = None,
        status: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ConversationResponse:
        """Update mutable fields on a conversation.

        Args:
            conversation_id: The conversation ID.
            title: New title.
            status: New status (``"active"`` or ``"archived"``).
            metadata: Arbitrary key-value metadata to merge.

        Returns:
            Updated ConversationResponse.
        """
        body = ConversationUpdate(title=title, status=status, metadata=metadata)  # type: ignore[arg-type]
        response = self._transport.request(
            "PATCH",
            f"/v1/conversations/{conversation_id}",
            json=body.model_dump(exclude_none=True),
        )
        return ConversationResponse.model_validate(response.json())


class AsyncConversationsResource:
    """Asynchronous conversations resource."""

    def __init__(self, transport: AsyncTransport) -> None:
        self._transport = transport

    async def create(
        self,
        *,
        message: str | None = None,
        messages: list[ChatMessage] | list[dict[str, Any]] | None = None,
        conversation_id: str | None = None,
        client_id: str | None = None,
        locale: str = "en-AU",
        jurisdiction: str = "AU",
    ) -> ConversationTurnResponse:
        """Async variant of :meth:`ConversationsResource.create`."""
        body = _build_turn_body(
            message=message,
            messages=messages,
            conversation_id=conversation_id,
            client_id=client_id,
            locale=locale,
            jurisdiction=jurisdiction,
        )
        response = await self._transport.request("POST", "/v1/conversations", json=body)
        return ConversationTurnResponse.model_validate(response.json())

    async def list(
        self,
        *,
        limit: int = 20,
        after: str | None = None,
        before: str | None = None,
        client_id: str | None = None,
        status: str | None = None,
        created_after: str | None = None,
        created_before: str | None = None,
    ) -> ConversationListResponse:
        params: dict[str, Any] = {"limit": limit}
        if after:
            params["after"] = after
        if before:
            params["before"] = before
        if client_id:
            params["client_id"] = client_id
        if status:
            params["status"] = status
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before

        response = await self._transport.request("GET", "/v1/conversations", params=params)
        return ConversationListResponse.model_validate(response.json())

    async def get(
        self, conversation_id: str, *, expand: list[str] | None = None
    ) -> ConversationResponse:
        params: dict[str, Any] = {}
        if expand:
            params["expand[]"] = expand
        response = await self._transport.request(
            "GET", f"/v1/conversations/{conversation_id}", params=params or None
        )
        return ConversationResponse.model_validate(response.json())

    async def update(
        self,
        conversation_id: str,
        *,
        title: str | None = None,
        status: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ConversationResponse:
        body = ConversationUpdate(title=title, status=status, metadata=metadata)  # type: ignore[arg-type]
        response = await self._transport.request(
            "PATCH",
            f"/v1/conversations/{conversation_id}",
            json=body.model_dump(exclude_none=True),
        )
        return ConversationResponse.model_validate(response.json())
