"""Archie Connect CLI — author, run, and debug playbooks.

Entry point registered as ``archie`` in pyproject.toml.

Subcommands:
    archie playbook list                      — list playbooks in the workspace
    archie playbook apply <file.yaml>         — create or update a playbook from YAML
    archie playbook describe <slug-or-id>     — show full playbook definition
    archie playbook run <id> --client <id>    — launch a playbook run
    archie playbook publish <slug-or-id>      — set status=active
    archie playbook archive <slug-or-id>      — set status=archived
    archie run debug <run_id>                 — open an interactive debug REPL
    archie run watch <run_id>                 — stream live events for a run
    archie trigger create                     — create a trigger
    archie trigger list                       — list triggers
    archie trigger get <id>                   — get a trigger
    archie trigger disable <id>               — disable a trigger
    archie trigger enable <id>                — enable a trigger
    archie trigger delete <id>                — delete a trigger

The REPL supports:
    bp set <step_id> [--when <cel>]   set a breakpoint
    bp ls                              list breakpoints
    bp clear <bp_id>                  clear a breakpoint
    step [N]                           step N times (default 1)
    continue                           resume normal execution
    inject <key>=<val> ...             inject runtime vars
    events                             stream events until run ends
    status                             show current run status
    quit / exit                        release session and exit
"""

from __future__ import annotations

import asyncio
import datetime
import json
import os
import sys
from typing import Any

import click

from .client import AsyncArchie


_PROD_URL = "https://api.heyarchie.ai"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _resolve_playbook_id(client: AsyncArchie, ref: str) -> str:
    """Return a UUID string for a playbook — resolves slugs and permakeys via direct GET."""
    import re
    if re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", ref, re.I):
        return ref  # already a UUID
    # slug or permakey — the API now accepts them directly
    try:
        pb = await client.playbooks.get(ref)
    except Exception as exc:
        raise click.ClickException(f"Playbook {ref!r} not found") from exc
    return str(pb["id"])


def _make_client(api_key: str | None, base_url: str | None) -> AsyncArchie:
    key = api_key or os.environ.get("ARCHIE_API_KEY") or os.environ.get("ARCHIE_E2E_SECRET")
    url = base_url or os.environ.get("ARCHIE_BASE_URL") or _PROD_URL
    if not key:
        click.echo("error: no API key. set ARCHIE_API_KEY or pass --api-key", err=True)
        sys.exit(1)
    return AsyncArchie(api_key=key, base_url=url)


def _run(coro: Any) -> Any:
    return asyncio.get_event_loop().run_until_complete(coro)


def _fmt(obj: Any, indent: int = 0) -> str:
    pad = "  " * indent
    if isinstance(obj, dict):
        lines = [f"{pad}{{"]
        for k, v in obj.items():
            lines.append(f"{pad}  {k}: {_fmt(v, indent + 1).lstrip()}")
        lines.append(f"{pad}}}")
        return "\n".join(lines)
    if isinstance(obj, list):
        if not obj:
            return "[]"
        return "\n".join(f"{pad}- {_fmt(i, indent + 1).lstrip()}" for i in obj)
    return f"{pad}{obj}"


# ---------------------------------------------------------------------------
# Top-level group
# ---------------------------------------------------------------------------


@click.group()
@click.option("--api-key", envvar="ARCHIE_API_KEY", default=None, help="Archie API key")
@click.option(
    "--base-url",
    envvar="ARCHIE_BASE_URL",
    default=None,
    help=f"API base URL (default: {_PROD_URL})",
)
@click.pass_context
def main(ctx: click.Context, api_key: str | None, base_url: str | None) -> None:
    """Archie Connect CLI — manage playbooks and debug runs."""
    ctx.ensure_object(dict)
    ctx.obj["api_key"] = api_key
    ctx.obj["base_url"] = base_url


# ---------------------------------------------------------------------------
# archie playbook …
# ---------------------------------------------------------------------------


@main.group()
def playbook() -> None:
    """Manage playbooks (list, apply, run, publish, archive)."""


@playbook.command("list")
@click.option("--scope", default=None, help="Filter by scope")
@click.option("--jurisdiction", default=None, help="Filter by jurisdiction")
@click.option("--limit", default=20, show_default=True)
@click.pass_context
def playbook_list(ctx: click.Context, scope: str | None, jurisdiction: str | None, limit: int) -> None:
    """List playbooks in your workspace."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        result = await client.playbooks.list(scope=scope, jurisdiction=jurisdiction, limit=limit)
        playbooks = result.get("playbooks") or []
        if not playbooks:
            click.echo("No playbooks found.")
            return
        for pb in playbooks:
            name = pb.get("name", "(unnamed)")
            pid = pb.get("id", "")
            scope_val = pb.get("scope", "")
            click.echo(f"  {pid}  {name}  [{scope_val}]")

    _run(_go())


@playbook.command("run")
@click.argument("playbook_id")
@click.option("--client", "client_id", required=True, help="Client ID to run against")
@click.option("--period", default=None, help="Accounting period (e.g. 2026-Q1)")
@click.option("--var", "vars_", multiple=True, help="Runtime vars as key=value")
@click.pass_context
def playbook_run(
    ctx: click.Context,
    playbook_id: str,
    client_id: str,
    period: str | None,
    vars_: tuple[str, ...],
) -> None:
    """Launch a playbook run."""
    runtime_vars: dict[str, str] = {}
    for kv in vars_:
        if "=" not in kv:
            click.echo(f"error: var must be key=value, got: {kv}", err=True)
            sys.exit(1)
        k, _, v = kv.partition("=")
        runtime_vars[k.strip()] = v.strip()

    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_id(client, playbook_id)
        run = await client.playbooks.run(
            pb_id,
            client_id=client_id,
            period=period,
            runtime_vars=runtime_vars or None,
            launched_via="cli",
        )
        run_id = run.get("id", "")
        status = run.get("status", "")
        click.echo(f"run started: {run_id}  status={status}")

    _run(_go())


# ---------------------------------------------------------------------------
# archie playbook apply
# ---------------------------------------------------------------------------


@playbook.command("apply")
@click.argument("file", type=click.Path(exists=True))
@click.pass_context
def playbook_apply(ctx: click.Context, file: str) -> None:
    """Create or update a playbook from a YAML file (kubectl-style apply)."""
    try:
        import yaml  # type: ignore[import]
    except ImportError:
        click.echo("error: pyyaml not installed — run: pip install pyyaml", err=True)
        sys.exit(1)

    with open(file) as f:
        spec = yaml.safe_load(f)

    if not isinstance(spec, dict):
        click.echo("error: YAML must be a mapping at the top level", err=True)
        sys.exit(1)

    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        slug = spec.get("slug")
        existing = None

        if slug:
            try:
                result = await client.playbooks.list(status=None)
                all_pbs = result.get("playbooks") or []
                existing = next((p for p in all_pbs if p.get("slug") == slug), None)
            except Exception:
                pass

        steps = spec.get("steps", [])

        if existing:
            pb = await client.playbooks.update(
                existing["id"],
                name=spec.get("name"),
                description=spec.get("description"),
                steps=steps,
                jurisdictions=spec.get("jurisdictions"),
                intent_keys=spec.get("intent_keys"),
            )
            action = "updated"
        else:
            pb = await client.playbooks.create(
                name=spec["name"],
                steps=steps,
                description=spec.get("description"),
                slug=slug,
                scope=spec.get("scope", "firm"),
                jurisdictions=spec.get("jurisdictions"),
                intent_keys=spec.get("intent_keys"),
                skills_used=spec.get("skills_used"),
                inputs_required=spec.get("inputs_required"),
            )
            action = "created"

        pb_id = pb.get("id", "")
        pb_name = pb.get("name", spec.get("name", ""))
        click.echo(f"{action} {pb_name!r} ({pb_id})")

    _run(_go())


# ---------------------------------------------------------------------------
# archie playbook describe
# ---------------------------------------------------------------------------


@playbook.command("describe")
@click.argument("slug_or_id")
@click.pass_context
def playbook_describe(ctx: click.Context, slug_or_id: str) -> None:
    """Show full playbook definition including steps."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        try:
            pb_id = await _resolve_playbook_id(client, slug_or_id)
            pb = await client.playbooks.get(pb_id)
        except Exception as exc:
            click.echo(f"error: {exc}", err=True)
            sys.exit(1)

        click.echo(f"name:        {pb.get('name')}")
        click.echo(f"id:          {pb.get('id')}")
        click.echo(f"slug:        {pb.get('slug') or '(none)'}")
        click.echo(f"status:      {pb.get('status')}")
        click.echo(f"scope:       {pb.get('scope')}")
        desc = pb.get("description") or ""
        if desc:
            click.echo(f"description: {desc}")
        jurisdictions = pb.get("jurisdictions") or []
        if jurisdictions:
            click.echo(f"jurisdictions: {', '.join(jurisdictions)}")
        intent_keys = pb.get("intent_keys") or []
        if intent_keys:
            click.echo(f"intent_keys: {', '.join(intent_keys)}")

        steps = pb.get("steps") or []
        if steps:
            click.echo(f"\nsteps ({len(steps)}):")
            for i, step in enumerate(steps, 1):
                sid = step.get("id", f"step-{i}")
                stype = step.get("type", "?")
                sname = step.get("name") or step.get("instruction", "")[:60]
                click.echo(f"  {i}. [{stype}] {sid}  —  {sname}")
        else:
            click.echo("\n(no steps)")

    _run(_go())


# ---------------------------------------------------------------------------
# archie playbook publish
# ---------------------------------------------------------------------------


@playbook.command("publish")
@click.argument("slug_or_id")
@click.pass_context
def playbook_publish_cmd(ctx: click.Context, slug_or_id: str) -> None:
    """Publish a playbook (set status=active)."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_id(client, slug_or_id)
        pb = await client.playbooks.publish(pb_id)
        click.echo(f"published: {pb.get('name')} ({pb.get('id')})  status={pb.get('status')}")

    _run(_go())


# ---------------------------------------------------------------------------
# archie playbook archive
# ---------------------------------------------------------------------------


@playbook.command("archive")
@click.argument("slug_or_id")
@click.confirmation_option(prompt="Archive this playbook?")
@click.pass_context
def playbook_archive_cmd(ctx: click.Context, slug_or_id: str) -> None:
    """Archive a playbook (set status=archived)."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_id(client, slug_or_id)
        await client.playbooks.archive(pb_id)
        click.echo(f"archived: {slug_or_id}")

    _run(_go())


# ---------------------------------------------------------------------------
# archie playbook edit — patch a committed playbook
# ---------------------------------------------------------------------------


@playbook.command("edit")
@click.argument("slug_or_id")
@click.option("--name", help="Update the name.")
@click.option("--description", help="Update the description.")
@click.option(
    "--steps-from-file",
    "steps_file",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to a JSON file containing the new steps array.",
)
@click.option(
    "--inputs-from-file",
    "inputs_file",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to a JSON file containing the new inputs_required array.",
)
@click.option("--add-jurisdiction", "add_jurisdictions", multiple=True)
@click.option("--add-intent-key", "add_intent_keys", multiple=True)
@click.pass_context
def playbook_edit_cmd(
    ctx: click.Context,
    slug_or_id: str,
    name: str | None,
    description: str | None,
    steps_file: str | None,
    inputs_file: str | None,
    add_jurisdictions: tuple[str, ...],
    add_intent_keys: tuple[str, ...],
) -> None:
    """Patch a committed playbook (steps, name, description, jurisdictions, etc.).

    For draft authoring use ``archie playbook draft edit`` instead.
    """
    import pathlib

    patch: dict[str, Any] = {}
    if name:
        patch["name"] = name
    if description:
        patch["description"] = description
    if steps_file:
        patch["steps"] = json.loads(pathlib.Path(steps_file).read_text())
    if inputs_file:
        patch["inputs_required"] = json.loads(pathlib.Path(inputs_file).read_text())
    if add_jurisdictions:
        patch["jurisdictions"] = list(add_jurisdictions)
    if add_intent_keys:
        patch["intent_keys"] = list(add_intent_keys)

    if not patch:
        click.echo("error: nothing to update — pass at least one option", err=True)
        sys.exit(2)

    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_id(client, slug_or_id)
        updated = await client.playbooks.update(pb_id, **patch)
        click.echo(
            f"updated: {updated.get('name')} ({updated.get('id')})  "
            f"steps={len(updated.get('steps', []))}  status={updated.get('status')}"
        )

    _run(_go())


# ---------------------------------------------------------------------------
# archie playbook clone / promote-scope
# ---------------------------------------------------------------------------


@playbook.command("clone")
@click.argument("slug_or_id")
@click.option(
    "--scope",
    "target_scope",
    type=click.Choice(["user", "team", "firm"]),
    default="user",
    show_default=True,
    help="Where to clone into.",
)
@click.pass_context
def playbook_clone_cmd(ctx: click.Context, slug_or_id: str, target_scope: str) -> None:
    """Clone a playbook (typically gallery → your scope) — copy-not-link."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        cloned = await client.playbooks.clone(slug_or_id, target_scope=target_scope)
        click.echo(
            f"cloned: {cloned.get('name')} ({cloned.get('id')})  scope={cloned.get('scope')}"
        )

    _run(_go())


@playbook.command("promote-scope")
@click.argument("slug_or_id")
@click.option(
    "--to",
    "target_scope",
    type=click.Choice(["user", "team", "firm", "gallery"]),
    required=True,
    help="Target scope (must be wider than current).",
)
@click.pass_context
def playbook_promote_scope_cmd(
    ctx: click.Context, slug_or_id: str, target_scope: str
) -> None:
    """Promote a playbook to a wider scope (user→team→firm→gallery)."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_id(client, slug_or_id)
        promoted = await client.playbooks.promote_scope(pb_id, target_scope=target_scope)
        click.echo(
            f"promoted: {promoted.get('name')} ({promoted.get('id')})  scope={promoted.get('scope')}"
        )

    _run(_go())


# ---------------------------------------------------------------------------
# archie playbook draft …  (Spec 12 §2.5 conversational authoring)
# ---------------------------------------------------------------------------


@playbook.group("draft")
def playbook_draft_group() -> None:
    """In-flight conversational drafts. Author iteratively, then commit."""


@playbook_draft_group.command("new")
@click.option("--topic", "topic_id", required=True, help="Topic UUID to anchor the draft.")
@click.option(
    "-m",
    "--message",
    "initial_message",
    help="First user message; runs the generation service to seed the draft.",
)
@click.option(
    "--from-file",
    "from_file",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to a JSON file with a pre-seeded draft_definition.",
)
@click.pass_context
def playbook_draft_new(
    ctx: click.Context,
    topic_id: str,
    initial_message: str | None,
    from_file: str | None,
) -> None:
    """Start a new conversational draft."""
    import json
    import pathlib

    pre_def: dict[str, Any] | None = None
    if from_file:
        pre_def = json.loads(pathlib.Path(from_file).read_text())

    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        d = await client.playbooks.draft_create(
            topic_id, initial_message=initial_message, draft_definition=pre_def
        )
        click.echo(f"draft: {d.get('id')}  status={d.get('status')}")
        defn = d.get("draft_definition") or {}
        if defn.get("name"):
            steps = defn.get("steps") or []
            click.echo(f"  name: {defn['name']}  ({len(steps)} step(s))")
        errs = d.get("validation_errors") or []
        if errs:
            click.echo(f"  validation_errors: {len(errs)}")
            for e in errs[:5]:
                click.echo(f"    - {e.get('path', '?')}: {e.get('message', '?')}")

    _run(_go())


@playbook_draft_group.command("list")
@click.option("--topic", "topic_id", help="Filter by topic UUID.")
@click.option("--author", "author_user_id", help="Filter by author user ID.")
@click.option(
    "--status",
    type=click.Choice(["drafting", "committed", "abandoned", "all"]),
    default="drafting",
    show_default=True,
)
@click.option("--limit", default=50, show_default=True)
@click.pass_context
def playbook_draft_list(
    ctx: click.Context,
    topic_id: str | None,
    author_user_id: str | None,
    status: str,
    limit: int,
) -> None:
    """List drafts in your workspace."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        result = await client.playbooks.draft_list(
            topic_id=topic_id,
            author_user_id=author_user_id,
            status=None if status == "all" else status,
            limit=limit,
        )
        drafts = result.get("drafts") or []
        click.echo(f"{len(drafts)} draft(s) (total={result.get('total')}):")
        for d in drafts:
            defn = d.get("draft_definition") or {}
            name = defn.get("name") or "<unnamed>"
            click.echo(
                f"  {d.get('id')}  [{d.get('status')}]  {name}  topic={d.get('topic_id')}"
            )

    _run(_go())


@playbook_draft_group.command("describe")
@click.argument("draft_id")
@click.pass_context
def playbook_draft_describe(ctx: click.Context, draft_id: str) -> None:
    """Show a draft's current state, conversation, and validation."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        d = await client.playbooks.draft_get(draft_id)
        click.echo(f"draft: {d.get('id')}  status={d.get('status')}")
        click.echo(f"  topic:  {d.get('topic_id')}")
        click.echo(f"  author: {d.get('author_user_id')}")
        defn = d.get("draft_definition") or {}
        if defn.get("name"):
            click.echo(f"  name:   {defn['name']}")
            steps = defn.get("steps") or []
            click.echo(f"  steps ({len(steps)}):")
            for s in steps:
                stype = s.get("type", "archie_query")
                click.echo(f"    - {s.get('id')} [{stype}] {s.get('name')}")
        conv = d.get("conversation") or []
        if conv:
            click.echo(f"  conversation ({len(conv)} turns):")
            for turn in conv[-5:]:
                click.echo(
                    f"    {turn.get('role', '?')}: {turn.get('message', '')[:100]}"
                )
        errs = d.get("validation_errors") or []
        if errs:
            click.echo(f"  validation_errors ({len(errs)}):")
            for e in errs:
                click.echo(f"    - {e.get('path', '?')}: {e.get('message', '?')}")

    _run(_go())


@playbook_draft_group.command("edit")
@click.argument("draft_id")
@click.option(
    "-m",
    "--message",
    required=True,
    help="Feedback message — regenerates the definition via the generation service.",
)
@click.pass_context
def playbook_draft_edit(ctx: click.Context, draft_id: str, message: str) -> None:
    """Iterate on a draft with a new instruction (regenerates the definition)."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        d = await client.playbooks.draft_update(draft_id, message=message)
        click.echo(f"draft: {d.get('id')}  status={d.get('status')}")
        defn = d.get("draft_definition") or {}
        steps = defn.get("steps") or []
        click.echo(f"  steps now ({len(steps)}):")
        for s in steps:
            click.echo(f"    - {s.get('id')} [{s.get('type', 'archie_query')}] {s.get('name')}")
        errs = d.get("validation_errors") or []
        if errs:
            click.echo(f"  validation_errors: {len(errs)}")

    _run(_go())


@playbook_draft_group.command("commit")
@click.argument("draft_id")
@click.option(
    "--scope",
    type=click.Choice(["user", "team", "firm"]),
    default="user",
    show_default=True,
)
@click.option("--name", help="Override the playbook name from the draft.")
@click.option("--slug", help="Override the slug.")
@click.pass_context
def playbook_draft_commit(
    ctx: click.Context,
    draft_id: str,
    scope: str,
    name: str | None,
    slug: str | None,
) -> None:
    """Commit a draft into a real Playbook."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        result = await client.playbooks.draft_commit(
            draft_id, scope=scope, name=name, slug=slug
        )
        pb = result.get("playbook") or {}
        click.echo(f"committed → playbook: {pb.get('name')} ({pb.get('id')})")
        click.echo(f"  scope: {pb.get('scope')}  status: {pb.get('status')}")

    _run(_go())


@playbook_draft_group.command("abandon")
@click.argument("draft_id")
@click.confirmation_option(prompt="Abandon this draft?")
@click.pass_context
def playbook_draft_abandon(ctx: click.Context, draft_id: str) -> None:
    """Abandon a draft (idempotent)."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        await client.playbooks.draft_abandon(draft_id)
        click.echo(f"abandoned: {draft_id}")

    _run(_go())


# ---------------------------------------------------------------------------
# archie run …
# ---------------------------------------------------------------------------


@main.group("run")
def run_group() -> None:
    """Manage playbook runs."""


async def _resolve_playbook_for_run(client: AsyncArchie, run_id: str) -> str:
    """Use the /lookup endpoint to map a run permakey → playbook permakey."""
    lookup = await client._t.request("GET", f"/api/v1/playbooks/runs/{run_id}/lookup")
    pb = lookup.json().get("playbook_id")
    if not pb:
        raise click.ClickException(f"could not resolve playbook for run {run_id}")
    return pb


@run_group.command("pause")
@click.argument("run_id")
@click.option("--reason", default="cli pause")
@click.pass_context
def run_pause(ctx: click.Context, run_id: str, reason: str) -> None:
    """Pause a running playbook run."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_for_run(client, run_id)
        run = await client.playbooks.pause_run(pb_id, run_id, reason=reason)
        click.echo(f"paused: {run.get('id')}  status={run.get('status')}")

    _run(_go())


@run_group.command("resume")
@click.argument("run_id")
@click.pass_context
def run_resume(ctx: click.Context, run_id: str) -> None:
    """Resume a paused playbook run."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_for_run(client, run_id)
        run = await client.playbooks.resume_run(pb_id, run_id)
        click.echo(f"resumed: {run.get('id')}  status={run.get('status')}")

    _run(_go())


@run_group.command("cancel")
@click.argument("run_id")
@click.option("--reason", default="cli cancel")
@click.confirmation_option(prompt="Cancel this run?")
@click.pass_context
def run_cancel(ctx: click.Context, run_id: str, reason: str) -> None:
    """Cancel a running or paused playbook run."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_for_run(client, run_id)
        run = await client.playbooks.cancel_run(pb_id, run_id, reason=reason)
        click.echo(f"cancelled: {run.get('id')}  status={run.get('status')}")

    _run(_go())


@run_group.command("guide")
@click.argument("run_id")
@click.argument("step_run_id")
@click.option("-m", "--message", "response", required=True, help="Free-text guidance.")
@click.option("--option", "option_value", help="Choose from offered options.")
@click.pass_context
def run_guide(
    ctx: click.Context,
    run_id: str,
    step_run_id: str,
    response: str,
    option_value: str | None,
) -> None:
    """Unblock a step_run that's waiting for guidance."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_for_run(client, run_id)
        await client.playbooks.provide_guidance(
            pb_id, run_id, step_run_id, response, option_value=option_value
        )
        click.echo(f"guidance sent: step_run={step_run_id}")

    _run(_go())


@run_group.command("approve")
@click.argument("run_id")
@click.argument("step_run_id")
@click.option(
    "--decision",
    type=click.Choice(["approve", "reject", "guidance"]),
    default="approve",
    show_default=True,
)
@click.option("--guidance", help="Free-text guidance (used with --decision guidance).")
@click.pass_context
def run_approve(
    ctx: click.Context,
    run_id: str,
    step_run_id: str,
    decision: str,
    guidance: str | None,
) -> None:
    """Approve / reject a step_run that requires human approval."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        pb_id = await _resolve_playbook_for_run(client, run_id)
        await client.playbooks.approve_step(
            pb_id, run_id, step_run_id, decision, guidance=guidance
        )
        click.echo(f"{decision}: step_run={step_run_id}")

    _run(_go())


@run_group.command("debug")
@click.argument("run_id")
@click.pass_context
def run_debug(ctx: click.Context, run_id: str) -> None:
    """Open an interactive debug REPL for a run."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])
    _run(_debug_repl(client, run_id))


@run_group.command("watch")
@click.argument("run_id")
@click.option("--debug", "show_debug", is_flag=True, help="Show internal debug/engineer tier events")
@click.pass_context
def run_watch(ctx: click.Context, run_id: str, show_debug: bool) -> None:
    """Stream live events for a run to stdout. Ctrl+C to stop."""
    import httpx

    api_key = ctx.obj["api_key"] or os.environ.get("ARCHIE_API_KEY") or os.environ.get("ARCHIE_E2E_SECRET")
    base_url = ctx.obj["base_url"] or os.environ.get("ARCHIE_BASE_URL") or _PROD_URL
    if not api_key:
        click.echo("error: no API key. set ARCHIE_API_KEY or pass --api-key", err=True)
        sys.exit(1)

    async def _stream() -> None:
        headers = {"Authorization": f"Bearer {api_key}", "Accept": "text/event-stream"}
        base = base_url.rstrip("/")
        # Resolve playbook_id from run — needed for events URL
        async with __import__("httpx").AsyncClient(timeout=10) as http:
            r = await http.get(
                f"{base}/api/v1/playbooks/runs/{run_id}/lookup",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            if r.status_code != 200:
                click.echo(f"error: could not look up run {run_id}: {r.status_code}", err=True)
                return
            playbook_id = r.json()["playbook_id"]
        url = f"{base}/api/v1/playbooks/{playbook_id}/runs/{run_id}/events"
        click.echo(f"watching run {run_id} …")
        try:
            async with httpx.AsyncClient(timeout=None, follow_redirects=True) as http, http.stream("GET", url, headers=headers) as resp:
                if resp.status_code != 200:
                    body = await resp.aread()
                    click.echo(f"error: HTTP {resp.status_code}  {body.decode()[:200]}", err=True)
                    return
                event_type = ""
                data_lines: list[str] = []
                async for raw_line in resp.aiter_lines():
                    line = raw_line.strip()
                    if line.startswith("event:"):
                        event_type = line[6:].strip()
                    elif line.startswith("data:"):
                        data_lines.append(line[5:].strip())
                    elif line == "" and (event_type or data_lines):
                        raw_data = " ".join(data_lines)
                        data_lines = []
                        try:
                            payload: dict[str, Any] = json.loads(raw_data) if raw_data else {}
                        except json.JSONDecodeError:
                            payload = {"raw": raw_data}

                        tier = payload.get("tier", "")
                        if not show_debug and tier in ("internal_archie", "internal_engineer"):
                            event_type = ""
                            continue

                        severity = payload.get("severity", "info")
                        ts = datetime.datetime.now(datetime.UTC).strftime("%H:%M:%S")
                        summary = _event_summary(event_type, payload)

                        line_out = f"{ts}  {severity:<7}  {event_type:<30}  {summary}"
                        if severity in ("error", "critical"):
                            click.echo(click.style(line_out, fg="red"))
                        elif severity == "warn":
                            click.echo(click.style(line_out, fg="yellow"))
                        else:
                            click.echo(line_out)

                        if event_type == "stream.closed":
                            break
                        event_type = ""
        except KeyboardInterrupt:
            click.echo("\nstopped.")

    _run(_stream())


# ---------------------------------------------------------------------------
# archie run telemetry / events  — Tier 2 read-only inspection
# ---------------------------------------------------------------------------


def _format_duration(ms: float | int | None) -> str:
    if ms is None:
        return "—"
    if ms < 1000:
        return f"{int(ms)}ms"
    return f"{ms / 1000:.2f}s"


_STATUS_GLYPH = {
    "completed": "✓",
    "running": "⟳",
    "failed": "⚠",
    "skipped": "⊘",
    "pending": "○",
    "needs_guidance": "?",
    "cancelled": "✕",
    "abandoned": "✕",
    "paused": "⏸",
}


@run_group.command("telemetry")
@click.argument("run_id")
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Print the raw span tree JSON instead of the formatted view.",
)
@click.pass_context
def run_telemetry(ctx: click.Context, run_id: str, as_json: bool) -> None:
    """Show the OTel-style span tree for a run (Tier 2 telemetry)."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        # The /spans endpoint is shaped /playbooks/{pb}/runs/{run}/spans, so
        # resolve the playbook permakey first.
        from contextlib import suppress

        playbook_id: str | None = None
        with suppress(Exception):
            lookup = await client._t.request(
                "GET", f"/api/v1/playbooks/runs/{run_id}/lookup"
            )
            playbook_id = lookup.json().get("playbook_id")
        if not playbook_id:
            click.echo(f"error: could not resolve playbook for run {run_id}", err=True)
            sys.exit(1)

        spans = await client.playbooks.get_run_spans(playbook_id, run_id)
        if as_json:
            click.echo(json.dumps(dict(spans), indent=2, default=str))
            return

        root = spans.get("root") or {}
        glyph = _STATUS_GLYPH.get(root.get("status", ""), "●")
        click.echo(
            f"{glyph} run  {spans.get('run_id')}  status={root.get('status')}  "
            f"duration={_format_duration(root.get('duration_ms'))}  "
            f"tier={spans.get('telemetry_tier')}"
        )
        children = root.get("children") or []
        for step in children:
            sg = _STATUS_GLYPH.get(step.get("status", ""), "○")
            sid = step.get("step_id") or f"step-{step.get('step_index')}"
            click.echo(
                f"  {sg} step  {sid:<24} {_format_duration(step.get('duration_ms')):>8}  "
                f"cluster={step.get('cluster') or '-'}  model={step.get('model') or '-'}"
            )
            if step.get("tokens_input") or step.get("tokens_output"):
                click.echo(
                    f"     tokens in={step.get('tokens_input')}  out={step.get('tokens_output')}"
                )
            for tc in step.get("children") or []:
                tg = "✓" if tc.get("ok", True) else "⚠"
                click.echo(
                    f"     {tg} tool  {tc.get('tool', '?')}  "
                    f"{_format_duration(tc.get('duration_ms')):>8}"
                )

    _run(_go())


@run_group.command("events")
@click.argument("run_id")
@click.option("--limit", default=50, show_default=True, help="Max events to fetch.")
@click.option(
    "--severity",
    type=click.Choice(["info", "warn", "error", "debug"]),
    help="Filter by severity.",
)
@click.option(
    "--json",
    "as_json",
    is_flag=True,
    help="Print raw event JSON.",
)
@click.pass_context
def run_events(
    ctx: click.Context, run_id: str, limit: int, severity: str | None, as_json: bool
) -> None:
    """Print a snapshot of the last N events for a run."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        from contextlib import suppress

        playbook_id: str | None = None
        with suppress(Exception):
            lookup = await client._t.request(
                "GET", f"/api/v1/playbooks/runs/{run_id}/lookup"
            )
            playbook_id = lookup.json().get("playbook_id")
        if not playbook_id:
            click.echo(f"error: could not resolve playbook for run {run_id}", err=True)
            sys.exit(1)

        events = await client.playbooks.get_run_events(playbook_id, run_id, limit=limit)
        if severity:
            events = [e for e in events if e.get("severity") == severity]
        if as_json:
            click.echo(json.dumps([dict(e) for e in events], indent=2, default=str))
            return

        if not events:
            click.echo("(no events)")
            return
        for ev in events:
            ts = ev.get("occurred_at", "")[:19].replace("T", " ")
            sev = ev.get("severity", "info")
            line = f"{ts}  {sev:<5}  {ev.get('event_type'):<28}  {_event_summary(ev.get('event_type', ''), ev.get('payload') or {})}"
            if sev in ("error", "critical"):
                click.echo(click.style(line, fg="red"))
            elif sev == "warn":
                click.echo(click.style(line, fg="yellow"))
            else:
                click.echo(line)

    _run(_go())


def _event_summary(event_type: str, payload: dict[str, Any]) -> str:
    """Format a one-line summary of an SSE event payload."""
    if event_type == "tool_execution.result":
        tool = payload.get("tool_name", "")
        status = payload.get("status", "")
        return f"{tool} → {status}"
    if event_type == "cluster.classified":
        clusters = payload.get("clusters") or []
        return f"clusters={clusters}"
    if event_type == "skill.activated":
        return str(payload.get("skill_name", ""))
    if event_type == "step_run.completed":
        sid = payload.get("step_id", "")
        status = payload.get("status", "")
        return f"step={sid} status={status}"
    if event_type.startswith("error.") or event_type == "step_run.failed":
        return str(payload.get("message") or payload.get("error", ""))[:120]
    for v in payload.values():
        if isinstance(v, str | int | float) and not isinstance(v, bool):
            s = str(v)
            if len(s) > 2:
                return s[:80]
    return ""


# ---------------------------------------------------------------------------
# Debug REPL
# ---------------------------------------------------------------------------


async def _debug_repl(client: AsyncArchie, run_id: str) -> None:
    try:
        from prompt_toolkit import PromptSession
        from prompt_toolkit.history import InMemoryHistory

        session: Any = PromptSession(history=InMemoryHistory())

        async def _input(prompt: str) -> str:
            return await session.prompt_async(prompt)

    except ImportError:
        async def _input(prompt: str) -> str:  # type: ignore[misc]
            return input(prompt)

    click.echo(f"attaching debug session to run {run_id} …")
    async with await client.playbooks.attach_debug(run_id) as dbg:
        sess_id = dbg.session_id
        click.echo(f"debug session {sess_id} acquired. type 'help' for commands.")

        while True:
            try:
                raw = await _input("archie-debug> ")
            except (EOFError, KeyboardInterrupt):
                click.echo("\nreleasing session …")
                break

            line = raw.strip()
            if not line:
                continue

            parts = line.split()
            cmd = parts[0].lower()

            try:
                await _handle_cmd(dbg, cmd, parts[1:])
            except SystemExit:
                break
            except Exception as exc:
                click.echo(f"error: {exc}", err=True)


async def _handle_cmd(dbg: Any, cmd: str, args: list[str]) -> None:
    if cmd in ("quit", "exit", "q"):
        raise SystemExit

    elif cmd == "help":
        click.echo(
            "\n".join([
                "  bp set <step_id> [--when <cel>]     set a breakpoint",
                "  bp ls                                list breakpoints",
                "  bp clear <bp_id>                     clear a breakpoint",
                "  step [N]                             step N steps (default 1)",
                "  continue                             resume normal execution",
                "  inject <key>=<val> ...               inject runtime vars",
                "  snapshot [--label <text>]            capture run state snapshot",
                "  restore <snapshot_id> [--in-place]  restore snapshot (default: new run)",
                "  replay <step_id>                     fork run from a given step",
                "  events                               stream run events until closed",
                "  status                               show run and session info",
                "  quit / exit / q                      release and exit",
            ])
        )

    elif cmd == "bp":
        if not args:
            click.echo("usage: bp set|ls|clear …")
            return
        subcmd = args[0].lower()
        if subcmd == "set":
            if len(args) < 2:
                click.echo("usage: bp set <step_id> [--when <cel_expr>]")
                return
            step_id = args[1]
            when: str | None = None
            if "--when" in args:
                idx = args.index("--when")
                if idx + 1 < len(args):
                    when = args[idx + 1]
            bp = await dbg.set_breakpoint(step_id, when=when)
            click.echo(f"breakpoint {bp.get('id')} set on step {step_id}")

        elif subcmd == "ls":
            bps = await dbg.list_breakpoints()
            if not bps:
                click.echo("no breakpoints")
            for b in bps:
                status = b.get("status", "")
                bid = b.get("id", "")
                sid = b.get("step_id", "")
                when = b.get("when_clause") or ""
                click.echo(f"  {bid}  step={sid}  status={status}  when={when!r}")

        elif subcmd == "clear":
            if len(args) < 2:
                click.echo("usage: bp clear <bp_id>")
                return
            result = await dbg.clear_breakpoint(args[1])
            click.echo(f"cleared: {result.get('id')}")
        else:
            click.echo(f"unknown bp subcommand: {subcmd}")

    elif cmd == "step":
        n = int(args[0]) if args else 1
        result = await dbg.step(n)
        click.echo(f"stepped {n}  →  status={result.get('status', '?')}")

    elif cmd in ("continue", "cont", "c"):
        result = await dbg.continue_()
        click.echo(f"resumed  →  status={result.get('status', '?')}")

    elif cmd == "inject":
        if not args:
            click.echo("usage: inject <key>=<val> …")
            return
        kv_pairs: dict[str, str] = {}
        for item in args:
            if "=" not in item:
                click.echo(f"error: expected key=val, got: {item}", err=True)
                return
            k, _, v = item.partition("=")
            kv_pairs[k.strip()] = v.strip()
        await dbg.inject(scope="task", **kv_pairs)
        click.echo(f"injected: {list(kv_pairs.keys())}")

    elif cmd == "events":
        click.echo("streaming events (ctrl-c to stop) …")
        try:
            async for event in dbg.events():
                etype = event.get("event_type", "?")
                payload = {k: v for k, v in event.items() if k != "event_type"}
                click.echo(f"  [{etype}] {payload}")
                if etype == "stream.closed":
                    break
        except KeyboardInterrupt:
            click.echo("\nstopped.")

    elif cmd == "snapshot":
        label: str | None = None
        if "--label" in args:
            idx = args.index("--label")
            if idx + 1 < len(args):
                label = args[idx + 1]
        snap = await dbg.snapshot(label=label)
        click.echo(f"snapshot {snap.get('id')}  step={snap.get('captured_at_step_index', '?')}")

    elif cmd == "restore":
        if not args:
            click.echo("usage: restore <snapshot_id> [--in-place]")
            return
        snap_id = args[0]
        as_new_run = "--in-place" not in args
        fork = await dbg.restore(snap_id, as_new_run=as_new_run)
        if as_new_run:
            click.echo(f"forked new run: {fork.get('id')}")
        else:
            click.echo(f"restored in-place: {fork.get('id')}")

    elif cmd == "replay":
        if not args:
            click.echo("usage: replay <step_id>")
            return
        step_id = args[0]
        # replay-from-step is on the resource, not the session — need playbook_id
        # fetch it from the run data on the session if available
        playbook_id = dbg.data.get("playbook_id")
        if not playbook_id:
            click.echo("error: could not determine playbook_id from session data", err=True)
            return
        fork = await dbg._t.request(
            "POST",
            f"/api/v1/playbooks/{playbook_id}/runs/{dbg.run_id}/replay-from-step",
            json={"step_id": step_id},
        )
        result = fork.json()
        click.echo(f"forked from step {step_id!r}: new run {result.get('id')}")

    elif cmd == "status":
        click.echo(f"run_id={dbg.run_id}  session={dbg.session_id}")
        data = dict(dbg.data)
        for k, v in data.items():
            click.echo(f"  {k}: {v}")

    else:
        click.echo(f"unknown command: {cmd}  (type 'help' for list)")


# ---------------------------------------------------------------------------
# archie trigger …
# ---------------------------------------------------------------------------


@main.group("trigger")
def trigger_group() -> None:
    """Manage playbook triggers (schedule, webhook, event-driven)."""


@trigger_group.command("create")
@click.option("--playbook", "playbook_id", required=True, help="Playbook ID to trigger")
@click.option(
    "--type",
    "trigger_type",
    required=True,
    type=click.Choice(["schedule", "webhook", "board_change", "data_threshold"]),
    help="Trigger type",
)
@click.option("--schedule", "cron_expression", default=None, help="Cron expression (schedule triggers)")
@click.option("--description", default=None, help="Human-readable description")
@click.option("--client-id", default=None, help="Scope trigger to a specific client")
@click.option("--event-match", default=None, help="Event pattern (board_change/data_threshold triggers)")
@click.pass_context
def trigger_create(
    ctx: click.Context,
    playbook_id: str,
    trigger_type: str,
    cron_expression: str | None,
    description: str | None,
    client_id: str | None,
    event_match: str | None,
) -> None:
    """Create a playbook trigger."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    config: dict[str, Any] = {}
    if cron_expression:
        config["cron_expression"] = cron_expression
    if event_match:
        config["event_match"] = event_match

    async def _go() -> None:
        trigger = await client.triggers.create(
            playbook_id=playbook_id,
            trigger_type=trigger_type,
            config=config,
            description=description,
            client_id=client_id,
        )
        click.echo(_fmt(trigger))

    _run(_go())


@trigger_group.command("list")
@click.pass_context
def trigger_list(ctx: click.Context) -> None:
    """List triggers in your workspace."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        triggers = await client.triggers.list()
        if not triggers:
            click.echo("No triggers found.")
            return
        for t in triggers:
            status = "enabled" if t.get("enabled") else "disabled"
            click.echo(
                f"  {t.get('id')}  [{t.get('trigger_type')}]  {status}  "
                f"{t.get('description') or ''}"
            )

    _run(_go())


@trigger_group.command("get")
@click.argument("trigger_id")
@click.pass_context
def trigger_get(ctx: click.Context, trigger_id: str) -> None:
    """Get a trigger by ID."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        trigger = await client.triggers.get(trigger_id)
        click.echo(_fmt(trigger))

    _run(_go())


@trigger_group.command("disable")
@click.argument("trigger_id")
@click.pass_context
def trigger_disable(ctx: click.Context, trigger_id: str) -> None:
    """Disable a trigger."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        await client.triggers.disable(trigger_id)
        click.echo(f"Trigger {trigger_id} disabled.")

    _run(_go())


@trigger_group.command("enable")
@click.argument("trigger_id")
@click.pass_context
def trigger_enable(ctx: click.Context, trigger_id: str) -> None:
    """Enable a trigger."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        await client.triggers.enable(trigger_id)
        click.echo(f"Trigger {trigger_id} enabled.")

    _run(_go())


@trigger_group.command("delete")
@click.argument("trigger_id")
@click.confirmation_option(prompt="Are you sure you want to delete this trigger?")
@click.pass_context
def trigger_delete(ctx: click.Context, trigger_id: str) -> None:
    """Delete a trigger permanently."""
    client = _make_client(ctx.obj["api_key"], ctx.obj["base_url"])

    async def _go() -> None:
        await client.triggers.delete(trigger_id)
        click.echo(f"Trigger {trigger_id} deleted.")

    _run(_go())
