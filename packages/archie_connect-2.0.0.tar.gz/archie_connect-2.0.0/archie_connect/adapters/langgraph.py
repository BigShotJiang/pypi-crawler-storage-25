"""LangGraph adapter — expose Archie skills as LangGraph-compatible tools.

Requires ``langgraph`` and ``langchain-core`` to be installed.

Usage::

    from archie_connect.adapters.langgraph import as_langgraph_tools
    from langgraph.graph import StateGraph
    from langgraph.prebuilt import ToolNode

    tools = as_langgraph_tools(api_key="sk_...", scope="tax:read")

    # Bind to a model
    from langchain_anthropic import ChatAnthropic
    model = ChatAnthropic(model="claude-sonnet-4-6").bind_tools(tools)

    # Or use ToolNode in a graph
    tool_node = ToolNode(tools)
"""

from __future__ import annotations

import json
from typing import Any

from ._base import SkillEntry, fetch_skills, invoke_skill


_DEFAULT_BASE_URL = "https://api.heyarchie.ai"


def _make_tool(skill: SkillEntry, api_key: str, base_url: str, client_id: str | None):
    """Build a LangChain/LangGraph BaseTool for a single skill."""
    try:
        from langchain_core.tools import StructuredTool  # type: ignore[import]
    except ImportError as e:
        raise ImportError(
            "langchain-core is required for the LangGraph adapter. "
            "Install with: pip install langchain-core langgraph"
        ) from e

    slug = skill.slug

    def run(**kwargs: Any) -> str:  # type: ignore[return]
        result = invoke_skill(api_key, slug, kwargs, base_url=base_url, client_id=client_id)
        content = result.get("content") or result.get("answer") or json.dumps(result)
        trace = result.get("trace_url", "")
        if trace:
            return f"{content}\n\n[Trace: {trace}]"
        return content  # type: ignore[return-value]

    # Build a minimal JSON schema for the tool inputs.
    # Skills expose a flat dict of inputs; most have at least query + client_id.
    schema = skill.input_schema or {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "The question or instruction."},
            "client_id": {"type": "string", "description": "Client context ID."},
        },
        "required": ["query"],
    }

    return StructuredTool.from_function(
        func=run,
        name=skill.tool_name,
        description=skill.description,
        args_schema=_schema_to_pydantic(schema, skill.tool_name),
        return_direct=False,
    )


def _schema_to_pydantic(schema: dict[str, Any], name: str):
    """Convert a JSON schema dict to a pydantic v1-style model for LangChain."""
    try:
        from pydantic import BaseModel, Field, create_model  # type: ignore[import]
    except ImportError:
        return None

    props: dict[str, Any] = schema.get("properties", {
        "query": {"type": "string", "description": "The question or instruction."},
    })
    required: list[str] = schema.get("required", [])

    field_defs: dict[str, Any] = {}
    for prop_name, prop in props.items():
        description = prop.get("description", "")
        annotation = str  # default
        t = prop.get("type", "string")
        if t == "number":
            annotation = float
        elif t == "integer":
            annotation = int
        elif t == "boolean":
            annotation = bool

        if prop_name in required:
            field_defs[prop_name] = (annotation, Field(description=description))
        else:
            field_defs[prop_name] = (annotation | None, Field(default=None, description=description))  # type: ignore[assignment]

    if not field_defs:
        field_defs["query"] = (str, Field(description="The question or instruction."))

    return create_model(f"{name.title().replace('_', '')}Input", **field_defs)


def as_langgraph_tools(
    api_key: str,
    *,
    base_url: str = _DEFAULT_BASE_URL,
    scope: str | list[str] | None = None,
    client_id: str | None = None,
    limit: int = 200,
) -> list[Any]:
    """Return a list of LangGraph/LangChain tools backed by the Archie skill registry.

    Args:
        api_key: Your Archie API key (``sk_...``).
        base_url: Override the default API base URL.
        scope: Optional scope to filter skills (e.g. ``"tax:read"``).
        client_id: Default client context for every tool call.
        limit: Maximum number of skills to include.

    Returns:
        List of ``StructuredTool`` instances ready for use with LangGraph or LangChain.

    Example::

        tools = as_langgraph_tools(api_key="sk_...", scope="tax:read")
        model = ChatAnthropic(...).bind_tools(tools)
    """
    skills = fetch_skills(api_key, base_url=base_url, scope=scope, limit=limit)
    return [_make_tool(s, api_key, base_url, client_id) for s in skills]
