"""LangChain adapter — expose Archie skills as LangChain tools.

Requires ``langchain-core`` (``pip install langchain-core``) to be installed.
This adapter is a thin wrapper: :func:`as_langchain_tools` is identical to
:func:`archie_connect.adapters.langgraph.as_langgraph_tools` because LangGraph
is built on LangChain Core. Import from whichever name is more readable.

Usage::

    from archie_connect.adapters.langchain import as_langchain_tools
    from langchain_anthropic import ChatAnthropic
    from langchain.agents import AgentExecutor, create_tool_calling_agent
    from langchain_core.prompts import ChatPromptTemplate

    tools = as_langchain_tools(api_key="sk_...", scope="tax:read")

    llm = ChatAnthropic(model="claude-sonnet-4-6").bind_tools(tools)
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an accounting assistant powered by Archie."),
        ("human", "{input}"),
        ("placeholder", "{agent_scratchpad}"),
    ])
    agent = create_tool_calling_agent(llm, tools, prompt)
    executor = AgentExecutor(agent=agent, tools=tools)
    result = executor.invoke({"input": "What is the BAS for Growthwise Q1 2026?"})
"""

from __future__ import annotations

from typing import Any

from .langgraph import as_langgraph_tools


_DEFAULT_BASE_URL = "https://api.heyarchie.ai"


def as_langchain_tools(
    api_key: str,
    *,
    base_url: str = _DEFAULT_BASE_URL,
    scope: str | list[str] | None = None,
    client_id: str | None = None,
    limit: int = 200,
) -> list[Any]:
    """Return a list of LangChain tools backed by the Archie skill registry.

    Identical to :func:`archie_connect.adapters.langgraph.as_langgraph_tools`.
    Both LangGraph and LangChain use the same ``StructuredTool`` base class from
    ``langchain-core``.

    Args:
        api_key: Your Archie API key (``sk_...``).
        base_url: Override the default API base URL.
        scope: Optional scope to filter skills (e.g. ``"tax:read"``).
        client_id: Default client context for every tool call.
        limit: Maximum number of skills to include.

    Returns:
        List of ``StructuredTool`` instances.
    """
    return as_langgraph_tools(
        api_key,
        base_url=base_url,
        scope=scope,
        client_id=client_id,
        limit=limit,
    )
