"""OpenAI Agents SDK adapter — expose Archie skills as OpenAI Agents tools.

Requires ``openai-agents`` (``pip install openai-agents``) to be installed.

Usage::

    from archie_connect.adapters.openai_agents import as_openai_tools
    from agents import Agent, Runner

    tools = as_openai_tools(api_key="sk_...", scope="tax:read")

    agent = Agent(
        name="Archie Tax Advisor",
        instructions="You are an expert accounting assistant powered by Archie.",
        tools=tools,
    )
    result = Runner.run_sync(agent, "What is the BAS for Q1 2026?")
    print(result.final_output)
"""

from __future__ import annotations

import json
from typing import Any

from ._base import SkillEntry, fetch_skills, invoke_skill


_DEFAULT_BASE_URL = "https://api.heyarchie.ai"


def _make_function_tool(
    skill: SkillEntry,
    api_key: str,
    base_url: str,
    client_id: str | None,
) -> Any:
    """Create an OpenAI Agents SDK FunctionTool for a single skill."""
    try:
        from agents import function_tool  # type: ignore[import]
    except ImportError as e:
        raise ImportError(
            "openai-agents is required for the OpenAI Agents adapter. "
            "Install with: pip install openai-agents"
        ) from e

    slug = skill.slug
    description = skill.description

    def _invoke(query: str, client_id_override: str | None = None) -> str:
        inputs = {"query": query}
        resolved_client_id = client_id_override or client_id
        result = invoke_skill(
            api_key, slug, inputs, base_url=base_url, client_id=resolved_client_id
        )
        content = result.get("content") or result.get("answer") or json.dumps(result)
        trace = result.get("trace_url", "")
        if trace:
            return f"{content}\n\n[Trace: {trace}]"
        return content  # type: ignore[return-value]

    # Rename the function so the tool name matches the skill slug
    _invoke.__name__ = skill.tool_name
    _invoke.__doc__ = description

    return function_tool(_invoke)


def as_openai_tools(
    api_key: str,
    *,
    base_url: str = _DEFAULT_BASE_URL,
    scope: str | list[str] | None = None,
    client_id: str | None = None,
    limit: int = 200,
) -> list[Any]:
    """Return a list of OpenAI Agents SDK tools backed by the Archie skill registry.

    Args:
        api_key: Your Archie API key (``sk_...``).
        base_url: Override the default API base URL.
        scope: Optional scope to filter skills (e.g. ``"tax:read"``).
        client_id: Default client context for every tool call.
        limit: Maximum number of skills to include.

    Returns:
        List of ``FunctionTool`` instances for use with ``Agent(tools=...)``.

    Example::

        from archie_connect.adapters.openai_agents import as_openai_tools
        from agents import Agent, Runner

        tools = as_openai_tools(api_key="sk_...", scope="tax:read")
        agent = Agent(name="Tax Advisor", instructions="...", tools=tools)
        result = Runner.run_sync(agent, "What's the BAS for Q1?")
    """
    skills = fetch_skills(api_key, base_url=base_url, scope=scope, limit=limit)
    return [_make_function_tool(s, api_key, base_url, client_id) for s in skills]
