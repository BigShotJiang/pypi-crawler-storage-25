"""Shared skill-fetching and invocation logic used by all adapters."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import httpx


_DEFAULT_BASE_URL = "https://api.heyarchie.ai"


@dataclass
class SkillEntry:
    """A single skill from the registry."""

    name: str
    slug: str
    description: str
    cluster: str
    category: str
    permission: str
    streaming: bool = False
    input_schema: dict[str, Any] = field(default_factory=dict)

    @property
    def tool_name(self) -> str:
        """Sanitise slug into a valid identifier (dots→underscores)."""
        return self.slug.replace("-", "_").replace(".", "_")


def fetch_skills(
    api_key: str,
    *,
    base_url: str = _DEFAULT_BASE_URL,
    scope: str | list[str] | None = None,
    limit: int = 200,
) -> list[SkillEntry]:
    """Fetch the live skill registry and return a list of SkillEntry objects.

    Args:
        api_key: Bearer token (``sk_...``).
        base_url: API base URL. Defaults to production.
        scope: Optional scope string or list of scopes. When provided, only
            skills whose ``permission`` field matches at least one scope prefix
            are returned (e.g. ``"tax:read"`` matches ``"tax:read"`` and
            ``"tax:write"`` but not ``"client:read"``).
        limit: Maximum number of skills to fetch from the registry.

    Returns:
        List of :class:`SkillEntry` objects.
    """
    scopes: list[str] | None = None
    if isinstance(scope, str):
        scopes = [scope]
    elif isinstance(scope, list):
        scopes = scope

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
    }

    with httpx.Client(timeout=15) as client:
        resp = client.get(
            f"{base_url}/v1/skills",
            headers=headers,
            params={"limit": limit},
        )
        resp.raise_for_status()
        body = resp.json()

    raw_skills: list[dict[str, Any]] = body.get("data", [])

    skills: list[SkillEntry] = []
    for s in raw_skills:
        entry = SkillEntry(
            name=s["name"],
            slug=s["slug"],
            description=s.get("description", ""),
            cluster=s.get("cluster", ""),
            category=s.get("category", ""),
            permission=s.get("permission", ""),
            streaming=s.get("streaming", False),
            input_schema=s.get("input_schema", {}),
        )
        if scopes:
            perm_prefix = entry.permission.split(":")[0] if ":" in entry.permission else entry.permission
            if not any(
                s.startswith(perm_prefix) or perm_prefix.startswith(s.split(":")[0])
                for s in scopes
            ):
                continue
        skills.append(entry)

    return skills


async def fetch_skills_async(
    api_key: str,
    *,
    base_url: str = _DEFAULT_BASE_URL,
    scope: str | list[str] | None = None,
    limit: int = 200,
) -> list[SkillEntry]:
    """Async variant of :func:`fetch_skills`."""
    scopes: list[str] | None = None
    if isinstance(scope, str):
        scopes = [scope]
    elif isinstance(scope, list):
        scopes = scope

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
    }

    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(
            f"{base_url}/v1/skills",
            headers=headers,
            params={"limit": limit},
        )
        resp.raise_for_status()
        body = resp.json()

    raw_skills: list[dict[str, Any]] = body.get("data", [])

    skills: list[SkillEntry] = []
    for s in raw_skills:
        entry = SkillEntry(
            name=s["name"],
            slug=s["slug"],
            description=s.get("description", ""),
            cluster=s.get("cluster", ""),
            category=s.get("category", ""),
            permission=s.get("permission", ""),
            streaming=s.get("streaming", False),
            input_schema=s.get("input_schema", {}),
        )
        if scopes:
            perm_prefix = entry.permission.split(":")[0] if ":" in entry.permission else entry.permission
            if not any(
                s.startswith(perm_prefix) or perm_prefix.startswith(s.split(":")[0])
                for s in scopes
            ):
                continue
        skills.append(entry)

    return skills


def invoke_skill(
    api_key: str,
    slug: str,
    inputs: dict[str, Any],
    *,
    base_url: str = _DEFAULT_BASE_URL,
    client_id: str | None = None,
) -> dict[str, Any]:
    """Invoke a skill synchronously via POST /api/v1/skills/{slug}/invoke.

    Args:
        api_key: Bearer token.
        slug: The skill slug (e.g. ``"advise_tax"``).
        inputs: Key/value inputs for the skill.
        base_url: API base URL.
        client_id: Optional client context.

    Returns:
        The parsed JSON response body as a dict.
    """
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    body: dict[str, Any] = dict(inputs)
    if client_id:
        body["client_id"] = client_id

    with httpx.Client(timeout=60) as client:
        resp = client.post(
            f"{base_url}/api/v1/skills/{slug}/invoke",
            headers=headers,
            json=body,
        )
        resp.raise_for_status()
        return resp.json()  # type: ignore[no-any-return]


async def invoke_skill_async(
    api_key: str,
    slug: str,
    inputs: dict[str, Any],
    *,
    base_url: str = _DEFAULT_BASE_URL,
    client_id: str | None = None,
) -> dict[str, Any]:
    """Async variant of :func:`invoke_skill`."""
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    body: dict[str, Any] = dict(inputs)
    if client_id:
        body["client_id"] = client_id

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            f"{base_url}/api/v1/skills/{slug}/invoke",
            headers=headers,
            json=body,
        )
        resp.raise_for_status()
        return resp.json()  # type: ignore[no-any-return]
