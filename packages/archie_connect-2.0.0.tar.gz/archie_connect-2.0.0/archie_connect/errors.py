"""Typed error hierarchy for the Archie Connect SDK."""

from __future__ import annotations

from typing import Any


class ArchieError(Exception):
    """Base error for all Archie Connect SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        code: str | None = None,
        request_id: str | None = None,
        trace_id: str | None = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code
        self.request_id = request_id
        self.trace_id = trace_id
        self.body = body

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"message={self.message!r}, "
            f"status={self.status!r}, "
            f"code={self.code!r}, "
            f"request_id={self.request_id!r}"
            f")"
        )


class ArchieAuthError(ArchieError):
    """Raised on 401 — missing, malformed, or invalid bearer token."""


class ArchiePermissionError(ArchieError):
    """Raised on 403 — FGA deny or org mismatch."""


class ArchieNotFoundError(ArchieError):
    """Raised on 404 — resource not found."""


class ArchieRateLimitError(ArchieError):
    """Raised on 429 — rate limit exceeded.

    Attributes:
        retry_after: Seconds to wait before retrying, from the Retry-After header.
    """

    def __init__(
        self,
        message: str,
        *,
        retry_after: float | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class ArchieIdempotencyError(ArchieError):
    """Raised on 422 — Idempotency-Key reused with a different request body."""


class ArchieAPIError(ArchieError):
    """Raised on 5xx — gateway or upstream failure."""
