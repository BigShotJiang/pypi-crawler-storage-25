"""Top-level Archie Connect client.

Usage (sync):

    import archie_connect
    archie = archie_connect.Archie(api_key="ak_test_...")
    msg = archie.messages.create("What is the BAS for Growthwise Q1 2026?", client_id="client_test_growthwise")
    print(msg.content)

Usage (async):

    import asyncio
    import archie_connect

    async def main():
        archie = archie_connect.AsyncArchie(api_key="ak_test_...")
        msg = await archie.messages.create("Summarise Q1 BAS", client_id="client_test_growthwise")
        print(msg.content)

    asyncio.run(main())
"""

from __future__ import annotations

from ._http import AsyncTransport, SyncTransport
from .resources import (
    AsyncConversationsResource,
    AsyncDocumentsResource,
    AsyncDraftsResource,
    AsyncJournalEntriesResource,
    AsyncKeysResource,
    AsyncMessagesResource,
    AsyncReportsResource,
    AsyncSearchResource,
    AsyncSkillsResource,
    AsyncStandardsResource,
    AsyncWorkstreamsResource,
    ConversationsResource,
    DocumentsResource,
    DraftsResource,
    JournalEntriesResource,
    KeysResource,
    MessagesResource,
    ReportsResource,
    SearchResource,
    SkillsResource,
    StandardsResource,
    WorkstreamsResource,
)
from .resources.triggers import AsyncTriggersResource, TriggersResource


_PROD_BASE_URL = "https://api.heyarchie.ai"
_SANDBOX_BASE_URL = "https://api.heyarchie.ai"  # sandbox is env-scoped, not subdomain-scoped


class Archie:
    """Synchronous Archie Connect client.

    Args:
        api_key: Your Archie API key (``ak_test_…`` for sandbox, ``ak_live_…`` for live).
        base_url: Override the default API base URL.
        sandbox: If True and no explicit ``base_url`` given, adds ``X-Archie-Env: test``
            hint header. In practice the key prefix determines the env; this flag is a
            convenience for documentation-clarity.
        api_version: Pin to a specific api-version date (``YYYY-MM-DD``). Defaults to the
            SDK's bundled default (``"2026-04-24"``).
    """

    DEFAULT_API_VERSION = "2026-04-24"

    def __init__(
        self,
        api_key: str,
        base_url: str = _PROD_BASE_URL,
        *,
        sandbox: bool = False,
        api_version: str | None = None,
    ) -> None:
        self._api_key = api_key
        self._sandbox = sandbox
        self._api_version = api_version or self.DEFAULT_API_VERSION

        resolved_base = base_url
        self._transport = SyncTransport(api_key=api_key, base_url=resolved_base)

        # Resource properties are constructed lazily to keep __init__ fast.
        self._messages: MessagesResource | None = None
        self._search: SearchResource | None = None
        self._conversations: ConversationsResource | None = None
        self._drafts: DraftsResource | None = None
        self._workstreams: WorkstreamsResource | None = None
        self._journal_entries: JournalEntriesResource | None = None
        self._standards: StandardsResource | None = None
        self._documents: DocumentsResource | None = None
        self._reports: ReportsResource | None = None
        self._keys: KeysResource | None = None
        self._skills: SkillsResource | None = None
        self._triggers: TriggersResource | None = None

    # ------------------------------------------------------------------
    # Resource accessors
    # ------------------------------------------------------------------

    @property
    def messages(self) -> MessagesResource:
        if self._messages is None:
            self._messages = MessagesResource(self._transport)
        return self._messages

    @property
    def search(self) -> SearchResource:
        if self._search is None:
            self._search = SearchResource(self._transport)
        return self._search

    @property
    def conversations(self) -> ConversationsResource:
        if self._conversations is None:
            self._conversations = ConversationsResource(self._transport)
        return self._conversations

    @property
    def drafts(self) -> DraftsResource:
        if self._drafts is None:
            self._drafts = DraftsResource(self._transport)
        return self._drafts

    @property
    def workstreams(self) -> WorkstreamsResource:
        if self._workstreams is None:
            self._workstreams = WorkstreamsResource(self._transport)
        return self._workstreams

    @property
    def journal_entries(self) -> JournalEntriesResource:
        if self._journal_entries is None:
            self._journal_entries = JournalEntriesResource(self._transport)
        return self._journal_entries

    @property
    def standards(self) -> StandardsResource:
        if self._standards is None:
            self._standards = StandardsResource(self._transport)
        return self._standards

    @property
    def documents(self) -> DocumentsResource:
        if self._documents is None:
            self._documents = DocumentsResource(self._transport)
        return self._documents

    @property
    def reports(self) -> ReportsResource:
        if self._reports is None:
            self._reports = ReportsResource(self._transport)
        return self._reports

    @property
    def keys(self) -> KeysResource:
        if self._keys is None:
            self._keys = KeysResource(self._transport)
        return self._keys

    @property
    def skills(self) -> SkillsResource:
        if self._skills is None:
            self._skills = SkillsResource(self._transport)
        return self._skills

    @property
    def triggers(self) -> TriggersResource:
        if self._triggers is None:
            self._triggers = TriggersResource(self._transport)
        return self._triggers

    # ------------------------------------------------------------------
    # Context-manager support
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._transport.close()

    def __enter__(self) -> Archie:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncArchie:
    """Asynchronous Archie Connect client.

    All resource methods are coroutines; ``await`` them directly.

    Args:
        api_key: Your Archie API key.
        base_url: Override the default API base URL.
        sandbox: Convenience flag; actual env is inferred from the key prefix.
        api_version: Pin to a specific api-version date.
    """

    DEFAULT_API_VERSION = "2026-04-24"

    def __init__(
        self,
        api_key: str,
        base_url: str = _PROD_BASE_URL,
        *,
        sandbox: bool = False,
        api_version: str | None = None,
    ) -> None:
        self._api_key = api_key
        self._sandbox = sandbox
        self._api_version = api_version or self.DEFAULT_API_VERSION

        self._transport = AsyncTransport(api_key=api_key, base_url=base_url)

        self._messages: AsyncMessagesResource | None = None
        self._search: AsyncSearchResource | None = None
        self._conversations: AsyncConversationsResource | None = None
        self._drafts: AsyncDraftsResource | None = None
        self._workstreams: AsyncWorkstreamsResource | None = None
        self._journal_entries: AsyncJournalEntriesResource | None = None
        self._standards: AsyncStandardsResource | None = None
        self._documents: AsyncDocumentsResource | None = None
        self._reports: AsyncReportsResource | None = None
        self._keys: AsyncKeysResource | None = None
        self._skills: AsyncSkillsResource | None = None
        self._triggers: AsyncTriggersResource | None = None

    @property
    def messages(self) -> AsyncMessagesResource:
        if self._messages is None:
            self._messages = AsyncMessagesResource(self._transport)
        return self._messages

    @property
    def search(self) -> AsyncSearchResource:
        if self._search is None:
            self._search = AsyncSearchResource(self._transport)
        return self._search

    @property
    def conversations(self) -> AsyncConversationsResource:
        if self._conversations is None:
            self._conversations = AsyncConversationsResource(self._transport)
        return self._conversations

    @property
    def drafts(self) -> AsyncDraftsResource:
        if self._drafts is None:
            self._drafts = AsyncDraftsResource(self._transport)
        return self._drafts

    @property
    def workstreams(self) -> AsyncWorkstreamsResource:
        if self._workstreams is None:
            self._workstreams = AsyncWorkstreamsResource(self._transport)
        return self._workstreams

    @property
    def journal_entries(self) -> AsyncJournalEntriesResource:
        if self._journal_entries is None:
            self._journal_entries = AsyncJournalEntriesResource(self._transport)
        return self._journal_entries

    @property
    def standards(self) -> AsyncStandardsResource:
        if self._standards is None:
            self._standards = AsyncStandardsResource(self._transport)
        return self._standards

    @property
    def documents(self) -> AsyncDocumentsResource:
        if self._documents is None:
            self._documents = AsyncDocumentsResource(self._transport)
        return self._documents

    @property
    def reports(self) -> AsyncReportsResource:
        if self._reports is None:
            self._reports = AsyncReportsResource(self._transport)
        return self._reports

    @property
    def keys(self) -> AsyncKeysResource:
        if self._keys is None:
            self._keys = AsyncKeysResource(self._transport)
        return self._keys

    @property
    def skills(self) -> AsyncSkillsResource:
        if self._skills is None:
            self._skills = AsyncSkillsResource(self._transport)
        return self._skills

    @property
    def triggers(self) -> AsyncTriggersResource:
        if self._triggers is None:
            self._triggers = AsyncTriggersResource(self._transport)
        return self._triggers

    async def aclose(self) -> None:
        """Close the underlying async HTTP connection pool."""
        await self._transport.aclose()

    async def __aenter__(self) -> AsyncArchie:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
