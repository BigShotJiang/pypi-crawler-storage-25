from .utils import (
    ensure_runtime_dir,
    project_python_env,
    root_join,
    runtime_join,
    text_content,
    upload_file_to_folder,
)
import os
from modict import modict
from .message import (
    DeveloperMessage,
    ServerToolResponseMessage,
    ToolResultMessage,
    UserMessage,
    message_from_data,
)
from .image import ImageMessage
from .command import CommandManager
from .config import ConfigManager
from .context import ContextManager
from .hooks import HookManager
from .mainloop import MainLoopManager
from .plugin import PluginsManager
from .provider import ProvidersManager
from .runtime import RuntimeManager
from .scheduler import AgentScheduler
from .sessions import SessionsManager
from .status import StatusManager
from .stream import StreamManager
from .tool import ToolsManager, reset_current_agent, set_current_agent
from .ai import AIClient
from .event import AssistantInterruptRequestedEvent, AssistantInterrupted, AssistantInterruptedEvent, EventBus
from threading import Event as ThreadEvent

class Agent:

    def __init__(self, session="latest", **kwargs):
        """Initializes the Agent instance with configuration, events, tools, and message history.

        Args:
            session: Session id or JSON session file to resume. Defaults to
                "latest"; pass "new" to force a fresh session.
            **kwargs: Additional keyword arguments to update the agent configuration.
        """
        ensure_runtime_dir()
        launch_cwd = os.path.abspath(os.getcwd())
        self.process_launch_cwd = launch_cwd
        explicit_root_dir = kwargs.pop("root_dir", None)
        explicit_cwd = kwargs.pop("cwd", None)
        self.init_execution_environment()
        self.config_manager = ConfigManager(self)
        self.config_manager.load()
        self.config_manager.update(kwargs, save=False)
        self.init_working_directories(root_dir=explicit_root_dir or launch_cwd, cwd=explicit_cwd)
        self.config_manager.apply_openai_capability_defaults()
        self.events = EventBus()
        self.tools_manager = ToolsManager(self)
        self.providers_manager = ProvidersManager(self)
        self.command_manager = CommandManager(self)
        self.context_manager = ContextManager(self)
        self.plugins_manager = PluginsManager(self)
        self.sessions_manager = SessionsManager(self)
        self.runtime = RuntimeManager(self)
        self.scheduler = AgentScheduler(self)
        self.hooks = HookManager(self)
        self.stream_manager = StreamManager(self)
        self.mainloop_manager = MainLoopManager(self)
        self._interrupt_requested = ThreadEvent()
        self.current_session_id = None
        self.session = None
        self.status_manager = StatusManager(self)
        self.context_namespace = self.create_context_namespace()
        self.init_workfolder()
        self.sessions_manager.init_folder()
        self.command_manager.init_folder()
        self.plugins_manager.init_folder()
        self.ai = AIClient(self)
        self.command_manager.init_builtin()
        self.plugins_manager.init_builtin()
        self.plugins_manager.init_runtime()
        self.command_manager.init_runtime()
        self.tools_manager.init_server_tools()
        self.tools_manager.apply_config_exclusions()
        self.start_new_session() if session == "new" else self.load_session(session)

    def on(self, event_type, handler=None, owner=None):
        """Register an event handler.

        Can be used as ``agent.on(ResponseContentDeltaEvent, handler)`` or as
        ``@agent.on(ResponseContentDeltaEvent)``.
        """
        return self.events.on(event_type, handler, owner=owner)

    def emit(self, event_type, **data):
        event = self.events.emit(event_type, **data)
        mainloop_manager = getattr(self, "mainloop_manager", None)
        if mainloop_manager is not None:
            mainloop_manager.record_event(event)
        return event

    @property
    def config(self):
        return self.config_manager.config

    @config.setter
    def config(self, value):
        self.config_manager.config = value
        if hasattr(self.config_manager, "configs"):
            self.config_manager.configs.agent = value

    @property
    def tools(self):
        return self.tools_manager.tools

    @property
    def providers(self):
        return self.providers_manager.providers

    @property
    def commands(self):
        return self.command_manager.commands

    @property
    def plugins(self):
        return self.plugins_manager.plugins

    @property
    def stream_processors(self):
        return self.stream_manager.processors

    @property
    def stream_processor_owners(self):
        return self.stream_manager.owners

    @property
    def busy(self):
        return self.mainloop_manager.busy

    @property
    def current_turn_id(self):
        return self.mainloop_manager.current_turn_id

    def start(self):
        return self.mainloop_manager.start()

    def stop(self, timeout=None):
        return self.mainloop_manager.stop(timeout=timeout)

    def submit(self, command, **payload):
        return self.mainloop_manager.submit(command, **payload)

    def _run_or_queue_state_command(self, command, action, **payload):
        if hasattr(self, "mainloop_manager") and self.mainloop_manager.should_queue_state_command():
            return self.submit(command, **payload).wait().result
        return action()

    def start_turn(self):
        return self.mainloop_manager.start_turn()

    def resume_turn(self, turn):
        future = self.mainloop_manager.resume_turn(turn)
        return None if future is None else future.wait()

    def submit_command(self, prompt):
        return self.command_manager.submit(prompt)

    def submit_message(self, message):
        return self.mainloop_manager.submit_message(message)

    def set_turn_result(self, data):
        return self.mainloop_manager.set_turn_result(data)

    def list_wakeups(self, include_done=True):
        return self.scheduler.list(include_done=include_done)

    def schedule_wakeup(self, **kwargs):
        return self._run_or_queue_state_command(
            "schedule_wakeup",
            lambda: self.scheduler.schedule(**kwargs),
            **kwargs,
        )

    def cancel_wakeup(self, job_id):
        return self._run_or_queue_state_command(
            "cancel_wakeup",
            lambda: self.scheduler.cancel(job_id),
            job_id=job_id,
        )

    def delete_wakeup(self, job_id):
        return self._run_or_queue_state_command(
            "delete_wakeup",
            lambda: self.scheduler.delete(job_id),
            job_id=job_id,
        )

    def interrupt(self, reason="user"):
        abort_error = None
        if not self._interrupt_requested.is_set():
            self._interrupt_requested.set()
            if getattr(self, "ai", None) is not None:
                try:
                    self.ai.abort()
                except Exception as exc:
                    abort_error = exc
            self.emit(AssistantInterruptedEvent, reason=reason)
        self.emit(
            AssistantInterruptRequestedEvent,
            reason=reason,
            interrupted=True,
            error=str(abort_error) if abort_error else "",
        )
        return True

    def clear_interrupt(self):
        self._interrupt_requested.clear()

    def is_interrupted(self):
        return self._interrupt_requested.is_set()

    def check_interrupt(self):
        if self.is_interrupted():
            raise AssistantInterrupted()

    def create_context_namespace(self):
        return {
            "agent": self,
            "os": os,
            "runtime_join": runtime_join,
            "root_join": root_join,
            "text_content": text_content,
        }

    def normalize_directory(self, path):
        return os.path.abspath(os.path.expanduser(str(path)))

    def sync_working_cwd_from_process(self, save_session=False):
        cwd = self.normalize_directory(os.getcwd())
        self.config.cwd = cwd
        session = getattr(self, "session", None)
        if session:
            session.cwd = cwd
            if save_session:
                self.save_session()
        return cwd

    def set_process_cwd(self, cwd, save_session=False):
        cwd = self.normalize_directory(cwd)
        os.chdir(cwd)
        return self.sync_working_cwd_from_process(save_session=save_session)

    def init_working_directories(self, root_dir=None, cwd=None):
        root_dir = self.normalize_directory(
            root_dir or getattr(self, "process_launch_cwd", None) or self.config.root_dir
        )
        cwd = self.normalize_directory(cwd or root_dir)
        self.config.root_dir = root_dir
        self.set_process_cwd(cwd)
        return self.config.cwd

    def apply_session_working_directories(self):
        if not self.session:
            return self.config.cwd
        root_dir = (
            getattr(self.session, "root_dir", None)
            or self.config.root_dir
            or getattr(self, "process_launch_cwd", None)
        )
        cwd = getattr(self.session, "cwd", None) or root_dir
        self.config.root_dir = self.normalize_directory(root_dir)
        self.session.root_dir = self.config.root_dir
        self.set_process_cwd(cwd)
        self.session.cwd = self.config.cwd
        return self.config.cwd

    def working_cwd(self):
        return self.sync_working_cwd_from_process(save_session=False)

    def resolve_path(self, path):
        path = os.path.expanduser(str(path))
        if os.path.isabs(path):
            return os.path.abspath(path)
        return os.path.abspath(os.path.join(self.working_cwd(), path))

    def init_workfolder(self):
        if not os.path.isdir(self.config.workfolder):
            os.makedirs(self.config.workfolder, exist_ok=True)

    def init_execution_environment(self):
        os.environ.update(project_python_env())

    def execution_env(self):
        return project_python_env()

    def get_sessions(self):
        return self.sessions_manager.list()

    def latest_session_id(self):
        return self.sessions_manager.latest_id()

    def load_session(self, session):
        return self.sessions_manager.load(session)

    def start_new_session(self, root_dir=None, cwd=None):
        return self.sessions_manager.start_new(root_dir=root_dir, cwd=cwd)

    def delete_session(self, session):
        return self.sessions_manager.delete(session)

    def navigate_session(self, direction):
        return self.sessions_manager.navigate(direction)

    def save_session(self):
        return self.sessions_manager.save()

    def compact_session(self, client=None, model=None, instructions=None, max_compacted_turns=None):
        return self.sessions_manager.compact(
            client=client,
            model=model,
            instructions=instructions,
            max_compacted_turns=max_compacted_turns,
        )

    def add_message(self, msg, pending=False):
        """Queue a message for the next pending flush, except tool results."""
        if isinstance(msg, ToolResultMessage):
            return self.sessions_manager.append_message(msg)
        if self.mainloop_manager.dumping_pending:
            return self.sessions_manager.append_message(msg)
        return self.mainloop_manager.add_pending_message(msg)

    def new_message(self, pending=False, **kwargs):
        """Helper to create and add a message based on provided keyword arguments.

        Args:
            pending: If True, stores message in pending list instead of main messages.
            **kwargs: Message fields. Must include an explicit ``type``.

        Returns:
            The created message object.
        """
        msg = message_from_data(kwargs)
        return self.add_message(msg, pending=pending)

    def add_image(self, source, pending=False, **kwargs):
        if source:
            img = ImageMessage(
                content=source,
                **kwargs,
            )
            if not img.is_valid():
                raise ValueError(f"Invalid or inaccessible image source: {source!r}")
            self.add_message(img, pending=pending)
            return img

    def add_tool(
        self,
        func=None,
        name=None,
        description=None,
        parameters=None,
        required=None,
        tool_type=None,
        format=None,
        owner=None,
    ):
        return self.tools_manager.add(
            func=func,
            name=name,
            description=description,
            parameters=parameters,
            required=required,
            tool_type=tool_type,
            format=format,
            owner=owner,
        )

    def add_provider(self, func=None, name=None, owner=None):
        return self.providers_manager.add(func=func, name=name, owner=owner)

    def add_command(self, func=None, name=None, owner=None):
        return self.command_manager.add(func, name=name, owner=owner)

    def add_plugin(self, plugin):
        return self.plugins_manager.add_plugin(plugin)

    def load_builtin_plugin(self, name):
        return self.plugins_manager.load_builtin_plugin(name)

    def load_runtime_plugin(self, name_or_path):
        return self.plugins_manager.load_runtime_plugin(name_or_path)

    def unload_plugin(self, plugin_or_name, timeout=None):
        return self.plugins_manager.unload_plugin(plugin_or_name, timeout=timeout)

    def reload_plugin(self, plugin_or_name, timeout=None):
        return self.plugins_manager.reload_plugin(plugin_or_name, timeout=timeout)

    def add_stream_processor(self, key, processor, owner=None):
        return self.stream_manager.add(key, processor, owner=owner)

    def get_stream_processors(self, key):
        return self.stream_manager.get(key)

    def remove_stream_processors_by_owner(self, owner):
        return self.stream_manager.remove_by_owner(owner)

    def add_hook(self, key, func=None, owner=None):
        """Register a runtime hook.

        Hooks are callable extension points keyed by name. They are runtime
        functions stored outside persisted payloads, and can be used as
        ``@agent.add_hook("audio_playback_hook")``.
        """
        if func is None:
            def decorator(f):
                return self.add_hook(key, f, owner=owner)
            return decorator

        return self._run_or_queue_state_command(
            "add_hook",
            lambda: self.hooks.add(key, func, owner=owner),
            key=key,
            func=func,
            owner=owner,
        )

    def has_hook(self, key):
        return self.hooks.has(key)

    def run_hook(self, key, **payload):
        agent_context = set_current_agent(self)
        try:
            return self.hooks.run(key, **payload)
        finally:
            reset_current_agent(agent_context)

    def run_hooks(self, key, *args):
        agent_context = set_current_agent(self)
        try:
            return self.hooks.run_legacy(key, *args)
        finally:
            reset_current_agent(agent_context)

    def get_messages(self, filter=None):
        return self.sessions_manager.messages(filter=filter)

    def get_status(self):
        return self.status_manager.get_status()

    def get_response(self):
        """Run the model, emit response events, and store the final message.

        Returns:
            Message: The aggregated assistant message with content and/or tool calls.
        """
        if self.session and not self.session.is_sane():
            repair = self.session.repair()
            if repair.repaired:
                self.status_manager.invalidate_context_cache()
        messages = self.context_manager.get_context()
        if self.context_manager.should_auto_compact(messages):
            self.compact_session()
            messages = self.context_manager.get_context()

        message = self.ai.run(
            messages=messages,
            tools=self.tools_manager.get_response_tools(),
            prompt_cache_key=self.current_session_id,
            **self.config.extract("model", "reasoning", "text", "parallel_tool_calls"),
        )
        self.sessions_manager.append_message(message)
        for item in message.output_items:
            if self.tools_manager.server_tool_for_item(item):
                self.sessions_manager.append_message(ServerToolResponseMessage(item=item))
        return message

    def listen(self, source, language=None, **kwargs):
        """
        description: |
            Transcribe audio from bytes, BytesIO, or a file path, then add the text as a user message.
        parameters:
            source:
                description: Audio source as a path string, BytesIO object, or bytes.
            language:
                description: Optional ISO-639-1 language code, such as "en" or "fr".
            kwargs:
                description: Extra transcription options forwarded to the backend.
        """

        transcribed_text = self.transcribe(source, language, **kwargs)
        self.add_message(UserMessage(content=transcribed_text))

    def transcribe(self, source, language=None, **kwargs):
        """
        description: Transcribe audio from bytes, BytesIO, or a file path.
        parameters:
            source:
                description: Audio source as a path string, BytesIO object, or bytes.
            language:
                description: Optional ISO-639-1 language code, such as "en" or "fr".
            kwargs:
                description: Extra transcription options forwarded to the backend.
        """
        if source is None:
            raise ValueError("An audio source must be provided")

        transcribed_text = self.ai.audio_to_text(
            source=source,
            language=language,
            **kwargs,
        )

        return transcribed_text

    def upload_file(self, source, name=None):
        """
        description: Upload a file into the workfolder and notify the agent.
        parameters:
            source:
                description: File path, BytesIO object, or bytes to upload.
            name:
                description: Optional destination name; required for unnamed bytes and may include an extension.
        returns:
            description: Absolute path to the uploaded file.
        """
        dest_path = upload_file_to_folder(source, self.config.workfolder, name=name)
        dest_filename = os.path.basename(dest_path)

        self.add_message(
            DeveloperMessage(
                content=f"File '{dest_filename}' has been uploaded to the workfolder at: {dest_path}"
            )
        )

        return dest_path

    def __call__(self, prompt=None):
        return self.mainloop_manager.call(prompt=prompt)

    def stream(self, prompt=None):
        from .stream import AgentStream
        return AgentStream(self, prompt=prompt).start()

    def interact(self):
        """Starts the interactive Textual chat UI."""
        from .utils import set_root_path
        import os
        if os.environ.get('AGENT_ROOT_PATH') is None:
            set_root_path(file=__file__)
        from .tui import Chat
        Chat(self).run()
