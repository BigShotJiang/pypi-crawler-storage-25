from types import SimpleNamespace

from codex_agent.message import CompactionMessage, DeveloperMessage, SystemMessage, UserMessage
from codex_agent.token_counter import TokenCounter
from codex_agent.builtin_plugins.image_generation import ImageGenerationTool
from codex_agent.tool import Tool, WebSearchTool


class FakeAI:
    def __init__(self):
        self.calls = []

    def count_input_tokens(self, **payload):
        self.calls.append(payload)
        baseline_input = [{
            "type": "message",
            "role": "user",
            "content": [{"type": "input_text", "text": "PING"}],
        }]
        if payload.get("input") == baseline_input and len(payload) == 2:
            return 10
        if "instructions" in payload and payload.get("input") == baseline_input:
            return 111
        if "tools" in payload and payload.get("input") == baseline_input:
            return 212
        if "input" in payload:
            return 303
        return 0


def test_token_counter_routes_user_message_to_input_and_caches_result():
    ai = FakeAI()
    counter = TokenCounter(ai, default_model="gpt-5.4")
    message = UserMessage(content="hello")

    count = counter.count_object(message)

    assert count == 303
    assert ai.calls == [{
        "model": "gpt-5.4",
        "input": [message.to_response_format()],
    }]
    assert message.token_count["gpt-5.4"]["count"] == 303

    again = counter.count_object(message)

    assert again == 303
    assert len(ai.calls) == 1


def test_token_counter_routes_system_message_to_instructions():
    ai = FakeAI()
    counter = TokenCounter(ai, default_model="gpt-5")
    message = SystemMessage(content="System rules")

    count = counter.count_object(message)

    assert count == 101
    assert ai.calls == [
        {
            "model": "gpt-5",
            "input": [{
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "PING"}],
            }],
        },
        {
            "model": "gpt-5",
            "instructions": "System rules",
            "input": [{
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "PING"}],
            }],
        },
    ]
    assert message.token_count["gpt-5"]["count"] == 101


def test_token_counter_routes_tool_to_tools_payload_and_caches_result():
    ai = FakeAI()
    counter = TokenCounter(ai, default_model="gpt-5")
    tool = Tool(
        name="lookup",
        description="Look things up",
        parameters={"query": {"type": "string"}},
        required=["query"],
    )

    count = counter.count_object(tool)

    assert count == 202
    assert ai.calls == [
        {
            "model": "gpt-5",
            "input": [{
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "PING"}],
            }],
        },
        {
            "model": "gpt-5",
            "tools": [tool.to_response_tool()],
            "input": [{
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "PING"}],
            }],
        },
    ]
    assert tool.token_count["gpt-5"]["count"] == 202


def test_token_counter_routes_server_tool_to_tools_payload():
    ai = FakeAI()
    counter = TokenCounter(ai, default_model="gpt-5")
    tool = WebSearchTool(user_location={"type": "approximate", "country": "FR"})

    count = counter.count_object(tool)

    assert count == 202
    assert ai.calls == [
        {
            "model": "gpt-5",
            "input": [{
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "PING"}],
            }],
        },
        {
            "model": "gpt-5",
            "tools": [tool.to_response_tool()],
            "input": [{
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": "PING"}],
            }],
        },
    ]
    assert tool.token_count["gpt-5"]["count"] == 202


def test_token_counter_prefers_observed_usage_for_compaction_message():
    ai = FakeAI()
    counter = TokenCounter(ai, default_model="gpt-5")
    message = CompactionMessage(
        output_items=[{"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"}],
        usage={"input_tokens": 400, "output_tokens": 120, "total_tokens": 520},
    )

    count = counter.count_object(message)

    assert count == 120
    assert ai.calls == []
    assert message.token_count["gpt-5"]["count"] == 120


def test_token_counter_falls_back_to_compaction_request_when_no_observed_usage():
    ai = FakeAI()
    counter = TokenCounter(ai, default_model="gpt-5")
    message = CompactionMessage(
        output_items=[{"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"}],
    )

    count = counter.count_object(message)

    assert count == 303
    assert ai.calls == [{
        "model": "gpt-5",
        "input": [{
            "type": "compaction_summary",
            "id": "cs_123",
            "encrypted_content": "<encrypted_compaction_summary>",
        }],
    }]
    assert message.token_count["gpt-5"]["count"] == 303


def test_token_counter_hydrate_counts_multiple_objects():
    ai = FakeAI()
    counter = TokenCounter(ai, default_model="gpt-5")
    objects = [
        UserMessage(content="hello"),
        SystemMessage(content="rules"),
        Tool(name="lookup", description="Look things up", parameters={}, required=[]),
    ]

    counts = counter.hydrate(objects)

    assert counts == [303, 101, 202]
    assert len(ai.calls) == 4


def test_server_tool_uses_baked_token_estimate_without_api_calls():
    tool = WebSearchTool()

    assert tool.baked_token_count == 4436
    assert tool.count_tokens(model="gpt-5.4") == 4436
    assert tool.token_count["gpt-5.4"]["count"] == 4436



def test_image_generation_tool_uses_baked_token_estimate():
    tool = ImageGenerationTool()

    assert tool.baked_token_count == 342
    assert tool.count_tokens(model="gpt-5.4") == 342
    assert tool.token_count["gpt-5.4"]["count"] == 342
