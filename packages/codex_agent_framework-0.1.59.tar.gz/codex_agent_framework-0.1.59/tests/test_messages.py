import json
import os
from types import SimpleNamespace

import pytest

import codex_agent.utils as utils
from codex_agent.message import message_from_data
from codex_agent.message import (
    AssistantMessage,
    CompactionMessage,
    DeveloperMessage,
    InterruptMessage,
    ServerToolResponseMessage,
    SystemMessage,
    ToolResultMessage,
    ToolResultWrapper,
    UserMessage,
)
from codex_agent.image import ImageMessage


def test_message_type_is_computed_from_hierarchical_types():
    message = UserMessage(content="hello")
    payload = json.loads(json.dumps(message))

    assert message.types == ["message", "text_message", "user_message"]
    assert message.type == "user_message"
    assert payload["types"] == ["message", "text_message", "user_message"]
    assert payload["type"] == "user_message"
    assert payload["role"] == "user"
    assert payload["turns_left"] == -1
    assert isinstance(message_from_data(payload), UserMessage)


def test_message_from_data_migrates_legacy_type_to_types():
    message = message_from_data({"type": "user_message", "content": "legacy"})

    assert isinstance(message, UserMessage)
    assert message.types == ["message", "text_message", "user_message"]
    assert message.type == "user_message"


def test_missing_message_type_is_rejected():
    with pytest.raises(ValueError):
        message_from_data({"role": "user", "content": "legacy"})


def test_system_message_is_instructions_only_and_counts_content_tokens():
    message = SystemMessage(content="System rules only.")

    assert message.to_response_format() is None
    assert message.count_tokens(model="gpt-5.4") == utils.token_count("System rules only.", model="gpt-5.4")


def test_only_system_message_content_is_templated():
    context = {"agent": SimpleNamespace(config=SimpleNamespace(runtime_dir="/tmp/runtime"))}
    raw = "runtime=<<agent.config.runtime_dir>>"

    assert SystemMessage(content=raw).format(context=context).content == "runtime=/tmp/runtime"
    assert DeveloperMessage(content=raw).format(context=context).content == raw
    assert ToolResultWrapper(content=raw).format(context=context).content == raw
    assert ToolResultMessage(call_id="call_1", content=raw).format(context=context).content == raw
    assert UserMessage(content=raw).format(context=context).content == raw
    assert AssistantMessage(content=raw).format(context=context).content == raw


def test_assistant_message_formats_tool_calls():
    message = AssistantMessage(content="done")
    message.tool_calls = [{
        "call_id": "call_1",
        "name": "lookup",
        "arguments": "{}",
    }]

    assert message.to_response_format() == [
        {
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": "done"}],
        },
        {
            "type": "function_call",
            "call_id": "call_1",
            "name": "lookup",
            "arguments": "{}",
        },
    ]


def test_tool_result_message_formats_function_output():
    message = ToolResultMessage(call_id="call_1", content="42")

    assert message.to_response_format() == {
        "type": "function_call_output",
        "call_id": "call_1",
        "output": "42",
    }


def test_tool_result_message_as_string_includes_call_metadata():
    message = ToolResultMessage(
        call_id="call_1",
        tool_call_type="custom_tool_call",
        content="created /tmp/out.txt",
    )

    text = message.as_string()

    assert text.startswith("<ToolResultMessage ")
    assert "call_id='call_1'" in text
    assert "tool_call_type='custom_tool_call'" in text
    assert "created /tmp/out.txt" in text


def test_assistant_message_formats_custom_tool_calls():
    message = AssistantMessage()
    message.tool_calls = [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "code_exec",
        "input": "print('hi')",
    }]

    assert message.to_response_format() == [{
        "type": "custom_tool_call",
        "call_id": "call_1",
        "name": "code_exec",
        "input": "print('hi')",
    }]


def test_assistant_message_as_string_includes_tool_calls():
    message = AssistantMessage(content="I will look it up.")
    message.tool_calls = [
        {
            "call_id": "call_1",
            "name": "lookup",
            "arguments": '{"query": "modict"}',
        },
        {
            "type": "custom_tool_call",
            "call_id": "call_2",
            "name": "python",
            "input": "print('hi')",
        },
    ]

    text = message.as_string()

    assert text.startswith("<AssistantMessage ")
    assert "I will look it up." in text
    assert '<tool_call type=\'function_call\' name=\'lookup\' call_id=\'call_1\'>' in text
    assert '{"query": "modict"}' in text
    assert '<tool_call type=\'custom_tool_call\' name=\'python\' call_id=\'call_2\'>' in text
    assert "print('hi')" in text
    assert text.rstrip().endswith("</AssistantMessage>")


def test_tool_result_message_formats_custom_output():
    message = ToolResultMessage(
        call_id="call_1",
        content="ok",
        tool_call_type="custom_tool_call",
    )

    assert message.to_response_format() == {
        "type": "custom_tool_call_output",
        "call_id": "call_1",
        "output": "ok",
    }


def test_tool_result_wrapper_formats_developer_xml():
    message = ToolResultWrapper(
        call_id="call_1",
        tool_name="lookup",
        status="success",
        content="<raw>& result",
    )

    response = message.to_response_format()

    assert response["role"] == "developer"
    text = response["content"][0]["text"]
    assert "<tool_result_wrapper " in text
    assert 'call_id="call_1"' in text
    assert 'tool_name="lookup"' in text
    assert f'wrapper_id="{message.id}"' in text
    assert "&lt;raw&gt;&amp; result" in text
    assert isinstance(message_from_data(json.loads(json.dumps(message))), ToolResultWrapper)


def test_server_tool_response_message_formats_raw_output_item():
    item = {"type": "web_search_call", "id": "ws_123", "status": "completed"}
    message = ServerToolResponseMessage(item=item)

    assert message.to_response_format() == item
    assert isinstance(message_from_data(json.loads(json.dumps(message))), ServerToolResponseMessage)


def test_server_tool_response_message_as_string_includes_item_metadata():
    item = {"type": "web_search_call", "id": "ws_123", "status": "completed"}
    message = ServerToolResponseMessage(content="Search completed.", item=item)

    text = message.as_string()

    assert text.startswith("<ServerToolResponseMessage ")
    assert "item_type='web_search_call'" in text
    assert "item_id='ws_123'" in text
    assert "status='completed'" in text
    assert "Search completed." in text
    assert "<server_tool_item>" in text
    assert '"type": "web_search_call"' in text


def test_compaction_message_replays_only_backend_summary_items():
    output_items = [
        {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "old"}]},
        {"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"},
    ]
    message = CompactionMessage(
        response_id="resp_123",
        output_items=output_items,
        compacted_message_count=4,
    )

    assert message.to_response_format() == [output_items[1]]
    text = message.as_string()
    assert text.startswith("<CompactionMessage ")
    assert "response_id='resp_123'" in text
    assert "compacted_message_count=4" in text
    assert "<compaction_summary id='cs_123'>" in text
    assert "opaque backend summary" in text
    assert "encrypted_content" not in text


def test_compaction_message_migrates_legacy_output_items_without_persisting_them():
    output_items = [
        {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "old"}]},
        {"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"},
    ]

    message = CompactionMessage({"output_items": output_items})

    assert "output_items" not in message
    assert message.summaries == [output_items[1]]
    assert message.to_response_format() == [output_items[1]]


def test_compaction_message_prefers_input_usage_token_count():
    message = CompactionMessage(
        output_items=[{"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"}],
        usage={"input_tokens": 42897, "output_tokens": 12000, "total_tokens": 54912},
    )

    assert message.count_tokens(model="gpt-5") == 42897
    assert message.effective_token_count == 42897


def test_compaction_message_falls_back_to_max_input_tokens():
    message = CompactionMessage(
        output_items=[{"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"}],
        usage={"max_input_tokens": 50000, "output_tokens": 12000},
    )

    assert message.count_tokens(model="gpt-5") == 50000
    assert message.effective_token_count == 50000


def test_image_generation_response_message_persists_result_as_file(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    result = "Zm9v"
    item = {"type": "image_generation_call", "id": "ig_123", "result": result}

    message = ServerToolResponseMessage(item=item)
    payload = json.loads(json.dumps(message))

    assert os.path.isfile(message.content)
    assert message.content.startswith(str(tmp_path / "images"))
    assert payload["content"] == message.content
    assert "result" not in payload["item"]
    assert result not in json.dumps(payload)
    response_format = message.to_response_format()
    assert response_format[0]["type"] == "message"
    assert response_format[0]["role"] == "user"
    assert response_format[0]["content"][0]["type"] == "input_image"
    assert response_format[0]["content"][0]["image_url"].startswith("data:image/png;base64,")
    assert response_format[0]["content"][1] == {
        "type": "input_text",
        "text": (
            "This is an image previously generated by the image_generation tool. "
            "Use it as the base image for any requested follow-up image edits."
        ),
    }
    assert response_format[1] == {
        "type": "message",
        "role": "developer",
        "content": [{
            "type": "input_text",
            "text": (
                "The generated image has also been saved locally at: "
                f"{message.content}\n"
                "Use the show tool to open it for the user, or observe it if visual analysis is needed."
            ),
        }],
    }


def test_developer_message_formats_as_api_developer_message():
    message = DeveloperMessage(content="Use care.")

    assert message.to_response_format() == {
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "Use care."}],
    }


def test_interrupt_message_round_trips_and_formats_as_developer_message():
    message = InterruptMessage()
    payload = json.loads(json.dumps(message))

    assert payload["types"] == ["message", "text_message", "developer_message", "interrupt_message"]
    assert payload["type"] == "interrupt_message"
    assert payload["name"] == "interrupt"
    assert payload["content"] == "User interrupted the current turn."
    assert isinstance(message_from_data(payload), InterruptMessage)
    assert message.to_response_format() == {
        "type": "message",
        "role": "developer",
        "content": [{"type": "input_text", "text": "User interrupted the current turn."}],
    }


def test_image_message_as_string_exposes_source_and_metadata():
    message = ImageMessage(
        content="/tmp/image.png",
        image_name="image.png",
        detail="high",
        description="A generated sketch.",
    )

    text = message.as_string()

    assert text.startswith("<ImageMessage ")
    assert "image_name='image.png'" in text
    assert "detail='high'" in text
    assert "<source>/tmp/image.png</source>" in text
    assert "<description>A generated sketch.</description>" in text
