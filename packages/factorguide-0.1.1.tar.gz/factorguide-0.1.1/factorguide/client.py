"""HTTP client for the FactorGuide oracle API."""

from __future__ import annotations

from typing import Any

import httpx


class FactorGuideClient:
    """Client for the FactorGuide decision intelligence oracle.

    Wraps the FactorGuide HTTP REST API. All methods return parsed JSON
    responses as Python dicts.

    Args:
        endpoint: Base URL of the FactorGuide service.
            Defaults to the public instance at https://factorguide.io.
        wallet_hash: Wallet identifier for payment allocation tracking.
            Trial tier (15 free queries) is auto-allocated on first use.
        timeout: Request timeout in seconds.

    Example:
        >>> fg = FactorGuideClient()
        >>> result = fg.navigate(
        ...     coupling={"correlation_matrix": [[1.0, 0.5], [0.5, 1.0]]},
        ...     sample_size=200,
        ... )
        >>> print(result["dipole_analysis"]["pair_classification"][0]["zone"])
        2
    """

    def __init__(
        self,
        endpoint: str = "https://factorguide.io",
        wallet_hash: str | None = None,
        timeout: float = 30.0,
    ):
        self.endpoint = endpoint.rstrip("/")
        self.wallet_hash = wallet_hash
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.wallet_hash:
            headers["X-Wallet-Hash"] = self.wallet_hash
        return headers

    def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Send POST request and return parsed JSON response."""
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                f"{self.endpoint}{path}",
                json=payload,
                headers=self._headers(),
            )
            if response.status_code == 402:
                raise PaymentRequired(response.json())
            response.raise_for_status()
            return response.json()

    def navigate(
        self,
        coupling: dict[str, Any],
        sample_size: int,
        model_class: str = "unknown",
        accuracy_target: float = 2.0,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Map the factorization terrain.

        Send coupling structure and receive zone classifications,
        block-diagonal strategy, and calibrated risk prediction.

        Args:
            coupling: One of:
                - {"correlation_matrix": [[1.0, 0.5], [0.5, 1.0]]}
                - {"covariance_matrix": [[1.0, 0.5], [0.5, 2.0]]}
                - {"precision_matrix": [[2.0, -0.5], [-0.5, 2.0]]}
                - {"edge_list": [{"i": "a", "j": "b", "coupling": 0.5}], "n": 3}
            sample_size: Number of observations used to estimate coupling.
            model_class: One of "unknown", "constitutive", "inductive".
            accuracy_target: Maximum acceptable MSE ratio. Default 2.0.
            **kwargs: Additional fields (e.g., report_sign_detectability=True).

        Returns:
            Full navigate response with zone classifications, block strategy,
            prediction hash, and outcome callback template.
        """
        payload = {
            "coupling": coupling,
            "sample_size": sample_size,
            "model_class": model_class,
            "accuracy_target": accuracy_target,
            **kwargs,
        }
        return self._post("/navigate", payload)

    def diagnose(
        self,
        i: str,
        j: str,
        coupling_value: float,
        sample_size: int,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Quick single-pair diagnostic.

        Returns IC with risk predictions for both constitutive and
        inductive model classes.

        Args:
            i: Name of the first variable.
            j: Name of the second variable.
            coupling_value: Coupling strength (correlation, partial correlation).
            sample_size: Number of observations.
            **kwargs: Optional fields (variance_i, variance_j).

        Returns:
            Diagnostic with ic, risk_constitutive, risk_inductive, and zone.
        """
        payload = {
            "i": i,
            "j": j,
            "coupling_value": coupling_value,
            "sample_size": sample_size,
            **kwargs,
        }
        return self._post("/diagnose", payload)

    def explain(self, prediction_hash: str) -> dict[str, Any]:
        """Get plain-language explanation of a previous navigate response.

        Args:
            prediction_hash: The prediction_hash from a navigate response.

        Returns:
            Structured explanation with summary, zone details, and
            wave mechanics grounding.

        Note:
            Requires starter tier or above. Trial wallets cannot
            access explain.
        """
        return self._post("/explain", {"prediction_hash": prediction_hash})

    def report_outcome(
        self,
        prediction_hash: str,
        approach_taken: str = "factorized",
        **diagnostics: Any,
    ) -> dict[str, Any]:
        """Report inference outcome to close the prediction loop.

        This is free — no query allocation is consumed. Reporting
        outcomes improves future predictions for everyone via the
        calibration flywheel.

        Args:
            prediction_hash: The prediction_hash from the original
                navigate response.
            approach_taken: One of "factorized", "structured", "hybrid".
            **diagnostics: Inference diagnostics. Common fields:
                - ess_ratio: float (ESS / n_draws)
                - psis_khat: float (Pareto shape diagnostic)
                - log_lik_gap: float (structured - factorized log-lik)
                - actual_mse_ratio: float (direct MSE measurement)

        Returns:
            Acceptance confirmation with plausibility assessment.
        """
        payload = {
            "prediction_hash": prediction_hash,
            "approach_taken": approach_taken,
            **diagnostics,
        }
        return self._post("/report_outcome", payload)

    def health(self) -> dict[str, Any]:
        """Check service health.

        Returns:
            Status dict with version information.
        """
        with httpx.Client(timeout=self.timeout) as client:
            response = client.get(f"{self.endpoint}/health")
            response.raise_for_status()
            return response.json()


class PaymentRequired(Exception):
    """Raised when the wallet has no remaining query allocation.

    The `requirements` attribute contains the payment options
    (bundle sizes, prices, wallet addresses) needed to purchase
    additional queries.
    """

    def __init__(self, requirements: dict[str, Any]):
        self.requirements = requirements
        super().__init__(
            "Payment required. Use requirements attribute to see bundle options."
        )
