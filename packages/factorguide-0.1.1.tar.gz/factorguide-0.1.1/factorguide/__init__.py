"""FactorGuide — Decision intelligence oracle for AI agents.

Send coupling structure (covariance, precision, correlation matrix, or edge list)
and receive zone classifications, optimal factorization strategy, and calibrated
risk predictions with falsifiable prediction hashes.

Usage:
    from factorguide import FactorGuideClient

    fg = FactorGuideClient()

    # Navigate: full factorization analysis
    result = fg.navigate(
        coupling={"correlation_matrix": [[1.0, 0.5], [0.5, 1.0]]},
        sample_size=200,
    )

    # Diagnose: quick single-pair check
    diag = fg.diagnose(i="x", j="y", coupling_value=0.3, sample_size=100)

    # Explain: plain-language interpretation
    explanation = fg.explain(prediction_hash=result["prediction"]["prediction_hash"])

    # Report outcome: close the prediction loop (free)
    fg.report_outcome(
        prediction_hash=result["prediction"]["prediction_hash"],
        approach_taken="factorized",
        ess_ratio=0.85,
    )
"""

from factorguide.client import FactorGuideClient

__version__ = "0.1.1"
__all__ = ["FactorGuideClient"]
