"""Cost estimation processor for Pipecat frames."""

import time

from pipecat.frames.frames import (
    Frame,
    MetricsFrame,
)
from pipecat.metrics.metrics import (
    LLMUsageMetricsData,
    TTSUsageMetricsData,
)
from pipecat.processors.frame_processor import (
    FrameDirection,
    FrameProcessor,
)


class CostLogger(FrameProcessor):
    """Track usage and estimate costs for pipeline frames.

    The cost logger records prompt and completion token usage, cache
    read and creation tokens, TTS characters, and session duration. It
    computes cost estimates using configured pricing values.
    """

    def __init__(
        self,
        PRICE_PER_1K_PROMPT_TOKENS: float,
        PRICE_PER_1K_COMPLETION_TOKENS: float,
        PRICE_PER_1K_CACHE_READ_TOKENS: float,
        PRICE_PER_1K_CACHE_CREATION_TOKENS: float,
        PRICE_PER_1K_TTS_CHARS: float,
        PRICE_PER_STT_MINUTE: float,
    ):
        """Initialize the cost logger.

        Args:
            PRICE_PER_1K_PROMPT_TOKENS: Price per 1k prompt tokens.
            PRICE_PER_1K_COMPLETION_TOKENS: Price per 1k completion tokens.
            PRICE_PER_1K_CACHE_READ_TOKENS: Price per 1k cache read tokens.
            PRICE_PER_1K_CACHE_CREATION_TOKENS: Price per 1k cache creation tokens.
            PRICE_PER_1K_TTS_CHARS: Price per 1k TTS characters.
            PRICE_PER_STT_MINUTE: Price per STT minute.
        """
        self.PRICE_PER_1K_PROMPT_TOKENS = PRICE_PER_1K_PROMPT_TOKENS
        self.PRICE_PER_1K_COMPLETION_TOKENS = PRICE_PER_1K_COMPLETION_TOKENS
        self.PRICE_PER_1K_CACHE_READ_TOKENS = PRICE_PER_1K_CACHE_READ_TOKENS
        self.PRICE_PER_1K_CACHE_CREATION_TOKENS = PRICE_PER_1K_CACHE_CREATION_TOKENS
        self.PRICE_PER_1K_TTS_CHARS = PRICE_PER_1K_TTS_CHARS
        self.PRICE_PER_STT_MINUTE = PRICE_PER_STT_MINUTE
        super().__init__()

        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.cache_read_tokens = 0
        self.cache_creation_tokens = 0

        self.tts_characters = 0

        self.session_start = None
        self.session_end = None

        self.usage:dict = {}
        self.cost_estimation:dict = {}

    async def process_frame(self, frame: Frame, direction: FrameDirection):
        """Process an incoming frame and update usage counters.

        Args:
            frame: Frame to process.
            direction: Direction of the frame.

        Returns:
            None
        """
        await super().process_frame(frame, direction)

        if self.session_start is None:
            self.session_start = time.time()

        if isinstance(frame, MetricsFrame):
            for d in frame.data:

                if isinstance(d, LLMUsageMetricsData):
                    usage = d.value
                    self.prompt_tokens += usage.prompt_tokens
                    self.completion_tokens += usage.completion_tokens

                    if getattr(usage, "cache_read_input_tokens", None) is not None:
                        self.cache_read_tokens += usage.cache_read_input_tokens
                    if getattr(usage, "cache_creation_input_tokens", None) is not None:
                        self.cache_creation_tokens += usage.cache_creation_input_tokens

                elif isinstance(d, TTSUsageMetricsData):
                    self.tts_characters += d.value

        await self.push_frame(frame, direction)


    @property
    def get_cost_report(self):
        """Get the current session cost report.

        Returns:
            A dictionary containing usage statistics and cost estimation.
        """
        session_seconds = (time.time() - self.session_start) if self.session_start else 0
        stt_minutes = session_seconds / 60.0

        normal_prompt_tokens = max(self.prompt_tokens - self.cache_read_tokens, 0)

        cost_prompt = (normal_prompt_tokens / 1000.0) * self.PRICE_PER_1K_PROMPT_TOKENS
        cost_completion = (self.completion_tokens / 1000.0) * self.PRICE_PER_1K_COMPLETION_TOKENS
        cost_cache_read = (self.cache_read_tokens / 1000.0) * self.PRICE_PER_1K_CACHE_READ_TOKENS
        cost_cache_creation = (self.cache_creation_tokens / 1000.0) * self.PRICE_PER_1K_CACHE_CREATION_TOKENS
        llm_total_cost = cost_prompt + cost_completion + cost_cache_read + cost_cache_creation
        tts_cost = (self.tts_characters / 1000.0) * self.PRICE_PER_1K_TTS_CHARS
        stt_cost = stt_minutes * self.PRICE_PER_STT_MINUTE
        grand_total = llm_total_cost + tts_cost + stt_cost

        usage = {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "cache_read_tokens": self.cache_read_tokens,
            "cache_creation_tokens": self.cache_creation_tokens,
            "tts_characters": self.tts_characters,
            "session_seconds": session_seconds,
        }
        cost = {
            "llm_cost_prompt": round(cost_prompt, 4),
            "llm_cost_completion": round(cost_completion, 4),
            "llm_cost_cache_read": round(cost_cache_read, 4),
            "llm_total_cost": round(llm_total_cost, 4),
            "tts_cost": round(tts_cost, 4),
            "stt_cost": round(stt_cost, 4),
            "grand_total": round(grand_total, 4),
        }


        return {
            "usage": usage,
            "cost_estimation": cost
            }