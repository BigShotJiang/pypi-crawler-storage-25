# Pipecat Costing SDK

A Python SDK for calculating costs associated with voice AI pipelines using Pipecat metrics. This library helps track and estimate costs for LLM, TTS, and STT usage in real-time voice applications.

## Features

- Tracks LLM token usage (prompt, completion, cache read, cache creation)
- Monitors TTS character count
- Estimates session duration for STT costs
- Provides detailed cost breakdowns and grand totals
- Integrates seamlessly with Pipecat's frame processing pipeline

## Installation

Install the package from PyPI:

```bash
pip install pipecat-costing-sdk
```

## Usage

```python
from pipecat_costing_sdk import CostLogger

# Initialize the cost logger with pricing rates
cost_logger = CostLogger(
    PRICE_PER_1K_PROMPT_TOKENS=0.0015,
    PRICE_PER_1K_COMPLETION_TOKENS=0.002,
    PRICE_PER_1K_CACHE_READ_TOKENS=0.00075,
    PRICE_PER_1K_CACHE_CREATION_TOKENS=0.00125,
    PRICE_PER_1K_TTS_CHARS=0.015,
    PRICE_PER_STT_MINUTE=0.011
)

# Integrate into your Pipecat pipeline
# (Assuming you have a pipeline set up with metrics frames)

# After processing, get the cost report
usage, costs = cost_logger.get_cost_report
print("Usage:", usage)
print("Costs:", costs)
```

## API Reference

### CostLogger

- `__init__(PRICE_PER_1K_PROMPT_TOKENS: float, PRICE_PER_1K_COMPLETION_TOKENS: float, PRICE_PER_1K_CACHE_READ_TOKENS: float, PRICE_PER_1K_CACHE_CREATION_TOKENS: float, PRICE_PER_1K_TTS_CHARS: float, PRICE_PER_STT_MINUTE: float)`: Initialize with pricing rates per unit
- `get_cost_report`: Property that returns a tuple of (usage_dict, cost_dict)

#### Usage Dictionary
- `prompt_tokens`: Total prompt tokens used
- `completion_tokens`: Total completion tokens used
- `cache_read_tokens`: Tokens read from cache
- `cache_creation_tokens`: Tokens used to create cache
- `tts_characters`: Total characters synthesized
- `session_seconds`: Total session duration in seconds

#### Cost Dictionary
- `llm_cost_prompt`: Cost for prompt tokens
- `llm_cost_completion`: Cost for completion tokens
- `llm_cost_cache_read`: Cost for cache read tokens
- `llm_total_cost`: Total LLM cost
- `tts_cost`: Cost for TTS
- `stt_cost`: Cost for STT
- `grand_total`: Total cost for the session

## Dependencies

- pipecat

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

If you encounter any issues or have questions, please open an issue on GitHub.