use pyo3::prelude::*;
use pyo3::exceptions::PyValueError;
use serde_json::Value;

use argon2::{password_hash::{PasswordHasher, SaltString}, Argon2, Params, Algorithm, Version};
use rand::rngs::OsRng;
use aes_gcm::{aead::{Aead, KeyInit}, Aes256Gcm, Nonce};
use sha2::{Sha256, Digest};
use base64::{Engine as _, engine::general_purpose::STANDARD as BASE64};

/// 🛡️ 第一引擎：哈希级联与算力压制 (暴露给 Python)
#[pyfunction]
fn seal_nozf_block(payload_str: String, prev_hash: String) -> PyResult<(String, String)> {
    // 1. 解析 Python 传过来的 JSON 字符串
    let payload: Value = serde_json::from_str(&payload_str)
        .map_err(|e| PyValueError::new_err(format!("JSON 格式非法: {}", e)))?;
    let data_str = payload.to_string();

    // 2. AES-GCM 级联加密
    let mut hasher = Sha256::new();
    hasher.update(prev_hash.as_bytes());
    let key_bytes = hasher.finalize();
    let cipher = Aes256Gcm::new(&key_bytes.into());
    let nonce = Nonce::from_slice(b"NOZF_NONCE12"); 

    let ciphertext = cipher.encrypt(nonce, data_str.as_bytes())
        .map_err(|e| PyValueError::new_err(format!("AES 加密失败: {:?}", e)))?;
    let encrypted_payload_b64 = BASE64.encode(ciphertext);

    // 3. Argon2id 算力压制
    let salt = SaltString::generate(&mut OsRng);
    let params = Params::new(65536, 4, 4, Some(Params::DEFAULT_OUTPUT_LEN)).unwrap();
    let argon2 = Argon2::new(Algorithm::Argon2id, Version::V0x13, params);
    
    let new_hash = argon2.hash_password(encrypted_payload_b64.as_bytes(), &salt)
        .map_err(|e| PyValueError::new_err(format!("Argon2id 崩溃: {}", e)))?
        .to_string();

    // 返回给 Python 一个 Tuple: (生成的哈希, 加密后的 Base64 数据)
    Ok((new_hash, encrypted_payload_b64))
}

/// 🔓 第二引擎：逆向解密 (暴露给 Python)
#[pyfunction]
fn decrypt_nozf_payload(encrypted_b64: String, prev_hash: String) -> PyResult<String> {
    let mut hasher = Sha256::new();
    hasher.update(prev_hash.as_bytes());
    let key_bytes = hasher.finalize();
    let cipher = Aes256Gcm::new(&key_bytes.into());
    let nonce = Nonce::from_slice(b"NOZF_NONCE12");

    let ciphertext = BASE64.decode(&encrypted_b64)
        .map_err(|_| PyValueError::new_err("Base64 解码失败"))?;
    
    let plaintext = cipher.decrypt(nonce, ciphertext.as_ref())
        .map_err(|_| PyValueError::new_err("哈希级联断裂！数据极可能已被篡改！"))?;

    let json_str = String::from_utf8(plaintext)
        .map_err(|e| PyValueError::new_err(format!("UTF8 转换失败: {}", e)))?;
    
    Ok(json_str)
}

/// 🚀 Python 模块注册入口点
#[pymodule]
fn nozf_core(_py: Python, m: &PyModule) -> PyResult<()> {
    // 把上面两个硬核 Rust 函数挂载到 Python 模块上
    m.add_function(wrap_pyfunction!(seal_nozf_block, m)?)?;
    m.add_function(wrap_pyfunction!(decrypt_nozf_payload, m)?)?;
    Ok(())
}