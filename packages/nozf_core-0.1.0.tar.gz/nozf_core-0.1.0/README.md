\# 🛡️ NOZF Core - 绝对确权与防篡改的数据黑匣子



\[!\[PyPI version](https://img.shields.io/pypi/v/nozf-core.svg)](https://pypi.org/project/nozf-core/)

\[!\[License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

\[!\[Rust Engine](https://img.shields.io/badge/Engine-Rust-orange.svg)]()



> 在零信任的数字时代，与其相信人类的承诺，不如相信物理的算力。



NOZF (Non-erasable Zipped Format) 是一种基于现代密码学（Argon2id + AES 级联）构建的\*\*单向追加型（Append-Only）单文件格式\*\*。它用纯软件在本地文件系统中模拟了“区块链的哈希咬合”与“WORM（一次写入，多次读取）特种硬盘”的物理防篡改特性。



现有的备份插件只是带橡皮擦的记事本，而 NOZF 是用钛合金浇筑的飞行黑匣子。



\## ✨ 核心特性



\- ⛓️ \*\*密码学级物理死锁\*\*：底层使用 Rust 编写。每一次数据追加，都需经过高压强的 Argon2id 算力榨汁（Proof of Work），并将前置区块的 Hash 作为下一个区块的加密盐值。哈希链环环相扣，试图篡改历史记录的单个标点符号，将导致整个文件链条瞬间崩溃。

\- 📦 \*\*极致的便携性\*\*：所有历史记录、加密乱码与去重后的资源文件，均通过极客级的纯净 Deflate 流极限压缩进一个独立的 `.nozf` 单文件中。无需携带复杂的 Git 目录或隐藏缓存，可通过任何通讯软件一键发送。

\- 🤖 \*\*人机分流的“双模式”架构\*\*：

&#x20; - \*\*档案模式 (Archive Mode)\*\*：面向人类交互（配合 NOZF 桌面/移动端编辑器），强制要求手写笔迹签名与屏幕视觉暗哨，实现绝对的物理确权。

&#x20; - \*\*记录模式 (Record Mode)\*\*：为 Python 脚本、量化交易日志、自动化流水线量身打造。以高吞吐量进行静默压制，并附带专属的“机器印章”，完美向下兼容老版本的 GUI 编辑器。



\## 🚀 快速开始



\### 1. 安装引擎



我们提供了基于 `maturin` 编译的预发布 Wheel 包，核心高频密码学运算完全由底层 Rust 接管：



```bash

pip install nozf-core

