import nozf_core
import json
import time
import os
import zlib  # 极客级数据压缩库

class Archive:
    # 🤖 机器专属的官方印章 (SVG Base64)
    # 🤖 机器专属的官方印章 Plus 版 (300x80 分辨率，加粗双语)
    # 🤖 机器专属的官方印章 Plus 版 (300x80 分辨率，加粗双语)
   # 🤖 机器专属的官方印章 终极版 (300x80 分辨率，带 UTF-8 声明，绝对不裂开)
    RECORD_MODE_SIG = "data:image/svg+xml;charset=utf-8;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iODAiPgogIDxyZWN0IHdpZHRoPSIzMDAiIGhlaWdodD0iODAiIGZpbGw9IiNmM2YzZjMiIHJ4PSI4IiBzdHJva2U9IiNjY2MiIHN0cm9rZS13aWR0aD0iMiIvPgogIDx0ZXh0IHg9IjE1MCIgeT0iMzUiIGZvbnQtZmFtaWx5PSJzYW5zLXNlcmlmIiBmb250LXNpemU9IjIwIiBmaWxsPSIjNjY2IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCI+U1lTVEVNIFJFQ09SRCBNT0RFPC90ZXh0PgogIDx0ZXh0IHg9IjE1MCIgeT0iNjAiIGZvbnQtZmFtaWx5PSJzYW5zLXNlcmlmIiBmb250LXNpemU9IjE0IiBmaWxsPSIjYWFhIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCI+57O757uf6Ieq5Yqo6K6w5b2V5qih5byPPC90ZXh0Pgo8L3N2Zz4="
    def __init__(self, filepath):
        self.filepath = filepath
        self.history_blocks = []
        
        # 实际开发中应该先尝试读取已存在的文件
        # 这里做 MVP 演示，默认这是一个全新的档案
        self.last_hash = "NOZF_GENESIS_KEY_2026" 
        self.version_counter = 1
        print(f"📦 已挂载 NOZF 黑匣子: {self.filepath}")

    def append(self, text_content, sign_mode="local"):
        """
        向档案追加不可篡改的数据块
        """
        # 1. 组装给老版本 Vue 编辑器看的 Quill Delta 格式
        # 让 Python 传过去的纯文本，能在老版本里完美显示
        delta_ops = {"ops": [{"i": text_content + "\n"}]}
        
        # 2. 组装送入算力绞肉机的 Ultimate Payload
        ultimate_payload = {
            "content": delta_ops,
            # 绝杀：老版本以为我们在手写，其实我们塞了机器印章
            "signature_img": self.RECORD_MODE_SIG, 
            "sentinels": [] # 豁免视觉暗哨
        }
        
        payload_str = json.dumps(ultimate_payload)

        # 3. 呼叫 Rust 底层算力引擎！
        start_time = time.time()
        new_hash, encrypted_b64 = nozf_core.seal_nozf_block(payload_str, self.last_hash)
        cost_time = (time.time() - start_time) * 1000

        # 4. 拼装历史记录区块
        current_time_str = time.strftime("%Y/%m/%d %H:%M:%S", time.localtime())
        new_block = {
            "version": f"V1.{self.version_counter}",
            "time": current_time_str,
            "hash": new_hash,
            "encryptedData": encrypted_b64,
            "signatureImg": self.RECORD_MODE_SIG,
            "signMode": sign_mode, # "local" 或 "online"
            "kmsSignature": "" # Python本地版暂不连网
        }
        
        # 将新区块压入内存的区块链条（最前面）
        self.history_blocks.insert(0, new_block)
        self.last_hash = new_hash
        self.version_counter += 1

        print(f"🛡️ [记录模式] 算力压制完成! 耗时: {cost_time:.1f}ms | Hash: {new_hash[:20]}...")

        # 5. 立刻执行物理落盘
        self._save_to_disk()

    def _save_to_disk(self):
        """
        极限压缩并生成 .nozf 物理文件（完美对齐 Rust 的 Deflate 算法）
        """
        # 1. 构建与老版本编辑器完全兼容的宏观 JSON
        nozf_file_object = {
            "magic_header": "NOZF_SECURE_WORM_FILE_V_MPA",
            "global_assets": {}, 
            "chain_blocks": self.history_blocks
        }
        json_str = json.dumps(nozf_file_object, separators=(',', ':'))

        # 2. 启动 Python 的极限压缩引擎 (匹配 Rust 的 raw deflate)
        # 极客技巧：-zlib.MAX_WBITS 可以去除 zlib 的头尾，生成纯净的 Deflate 流
        compressor = zlib.compressobj(level=9, wbits=-zlib.MAX_WBITS)
        binary_data = compressor.compress(json_str.encode('utf-8')) + compressor.flush()

        # 3. 物理死锁至硬盘
        with open(self.filepath, 'wb') as f:
            f.write(binary_data)
            
        print(f"💾 数据已死锁至物理硬盘: {self.filepath}")

# ==========================================
# 🚀 极客试车专区
# ==========================================
if __name__ == "__main__":
    archive = Archive("system_logs.nozf")
    
    # 模拟自动化脚本写入重要日志
    archive.append("User 'admin' logged into the system.")
    archive.append("Initiated database backup protocol.")
    archive.append("CRITICAL: Firewall detected unauthorized access attempt!")
    
    print("\n✅ 试车完毕！请用你之前开发的 Windows NOZF 编辑器打开 'system_logs.nozf' 看看效果！")