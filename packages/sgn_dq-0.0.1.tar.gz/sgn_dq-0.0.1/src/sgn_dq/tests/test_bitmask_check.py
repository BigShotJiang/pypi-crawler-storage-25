"""Tests for BitMaskCheck evaluator."""

import numpy as np
from sgn.apps import Pipeline
from sgnts.sinks import DumpSeriesSink
from sgnts.sources.segment import SegmentSource

from sgn_dq.transforms.evaluators import BitMaskCheck


def test_bitmask_check_any_pass(tmp_path):
    """Test BitMaskCheck with any_mask when condition passes."""
    p = Pipeline()

    # Create source with bitmask value 0b0101 (5) - has bit 0 and bit 2 set
    # any_mask = 0b0001 (1) - looking for bit 0
    # Should pass because bit 0 is set
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=0.5,
            segments=((0, int(0.5 * 1e9)),),
            values=(5,),  # 0b0101
        ),
        BitMaskCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            any_mask=0b0001,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    assert len(output_data) > 0, "Expected non-empty output"
    assert np.all(output_data[:, 1] == 1), "Expected all ones (condition met)"


def test_bitmask_check_any_fail(tmp_path):
    """Test BitMaskCheck with any_mask when condition fails."""
    p = Pipeline()

    # Create source with bitmask value 0b0100 (4) - only bit 2 set
    # any_mask = 0b0001 (1) - looking for bit 0
    # Should fail because bit 0 is not set
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=0.5,
            segments=((0, int(0.5 * 1e9)),),
            values=(4,),  # 0b0100
        ),
        BitMaskCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            any_mask=0b0001,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Output should be empty (gaps not written)
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Expected empty output (condition not met)"


def test_bitmask_check_all_pass(tmp_path):
    """Test BitMaskCheck with all_mask when condition passes."""
    p = Pipeline()

    # Create source with bitmask value 0b0111 (7) - bits 0, 1, 2 set
    # all_mask = 0b0011 (3) - need bits 0 and 1
    # Should pass because both required bits are set
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=0.5,
            segments=((0, int(0.5 * 1e9)),),
            values=(7,),  # 0b0111
        ),
        BitMaskCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            all_mask=0b0011,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    assert len(output_data) > 0, "Expected non-empty output"
    assert np.all(output_data[:, 1] == 1), "Expected all ones (condition met)"


def test_bitmask_check_all_fail(tmp_path):
    """Test BitMaskCheck with all_mask when condition fails."""
    p = Pipeline()

    # Create source with bitmask value 0b0101 (5) - bits 0 and 2 set
    # all_mask = 0b0011 (3) - need bits 0 and 1
    # Should fail because bit 1 is not set
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=0.5,
            segments=((0, int(0.5 * 1e9)),),
            values=(5,),  # 0b0101
        ),
        BitMaskCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            all_mask=0b0011,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Output should be empty (gaps not written)
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Expected empty output (condition not met)"


def test_bitmask_check_both_masks(tmp_path):
    """Test BitMaskCheck with both any_mask and all_mask."""
    p = Pipeline()

    # Create source with bitmask value 0b0111 (7)
    # any_mask = 0b1000 (8) - looking for bit 3
    # all_mask = 0b0011 (3) - need bits 0 and 1
    # Should fail because any_mask check fails (bit 3 not set)
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=0.5,
            segments=((0, int(0.5 * 1e9)),),
            values=(7,),  # 0b0111
        ),
        BitMaskCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            any_mask=0b1000,
            all_mask=0b0011,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Output should be empty (any_mask check fails)
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Expected empty output (any_mask condition not met)"


def test_bitmask_check_no_mask(tmp_path):
    """Test BitMaskCheck with no masks (always passes for valid data)."""
    p = Pipeline()

    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=0.5,
            segments=((0, int(0.5 * 1e9)),),
            values=(123,),  # Any value
        ),
        BitMaskCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            # No masks specified
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    assert len(output_data) > 0, "Expected non-empty output"
    assert np.all(output_data[:, 1] == 1), "Expected all ones (no conditions to fail)"


def test_bitmask_check_preserves_gaps(tmp_path):
    """Test that BitMaskCheck preserves input gaps."""
    p = Pipeline()

    # Source with gap in middle
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=(
                (0, int(0.3 * 1e9)),
                (int(0.7 * 1e9), int(1.0 * 1e9)),
            ),
            values=(0xFF, 0xFF),
        ),
        BitMaskCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            any_mask=0x01,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Check output has two distinct regions (0-0.3s and 0.7-1.0s)
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    time_diffs = np.diff(output_data[:, 0])
    gap_threshold = 2.0 / 128  # Two sample periods
    gap_indices = np.where(time_diffs > gap_threshold)[0]

    assert len(gap_indices) == 1, "Expected one gap in output"
