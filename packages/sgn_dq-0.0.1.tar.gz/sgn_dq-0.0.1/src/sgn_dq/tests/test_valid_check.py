"""Tests for ValidCheck evaluator."""

import numpy as np
from sgn.apps import Pipeline
from sgnts.sinks import DumpSeriesSink
from sgnts.sources.segment import SegmentSource

from sgn_dq.transforms.evaluators import ValidCheck


def test_valid_check_basic(tmp_path):
    """Test basic ValidCheck functionality with two inputs."""
    p = Pipeline()

    # Source 1: has data from 0.1-0.5s (gap from 0-0.1s and 0.5-1s)
    # Source 2: has data from 0.3-1.0s (gap from 0-0.3s)
    # Expected output: valid from 0.3-0.5s (where both have data)
    p.insert(
        SegmentSource(
            name="src1",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=((int(0.1 * 1e9), int(0.5 * 1e9)),),
            values=(1,),
        ),
        SegmentSource(
            name="src2",
            source_pad_names=("src",),
            rate=64,
            start=0.0,
            duration=1.0,
            segments=((int(0.3 * 1e9), int(1.0 * 1e9)),),
            values=(2,),
        ),
        ValidCheck(
            name="validator",
            sink_pad_names=("input1", "input2"),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "validator:snk:input1": "src1:src:src",
            "validator:snk:input2": "src2:src:src",
            "sink:snk:snk": "validator:src:src",
        },
    )

    # Run pipeline
    p.run()

    # Load and verify output
    output_data = np.loadtxt(str(tmp_path / "output.txt"))

    # Find where output is 1 (all inputs have valid data)
    high_indices = np.where(output_data[:, 1] == 1)[0]

    if len(high_indices) > 0:
        # Check that valid region is approximately 0.3-0.5s
        first_high_time = output_data[high_indices[0], 0]
        last_high_time = output_data[high_indices[-1], 0]

        assert 0.28 < first_high_time < 0.32, (
            f"Expected first valid around 0.3s, got {first_high_time}"
        )
        assert 0.48 < last_high_time < 0.52, (
            f"Expected last valid around 0.5s, got {last_high_time}"
        )


def test_valid_check_single_input(tmp_path):
    """Test ValidCheck with a single input."""
    p = Pipeline()

    p.insert(
        SegmentSource(
            name="src1",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=((int(0.2 * 1e9), int(0.8 * 1e9)),),
            values=(1,),
        ),
        ValidCheck(
            name="validator",
            sink_pad_names=("input1",),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "validator:snk:input1": "src1:src:src",
            "sink:snk:snk": "validator:src:src",
        },
    )

    p.run()

    # Output should mirror input validity
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    high_indices = np.where(output_data[:, 1] == 1)[0]

    if len(high_indices) > 0:
        first_high_time = output_data[high_indices[0], 0]
        last_high_time = output_data[high_indices[-1], 0]

        assert 0.18 < first_high_time < 0.22
        assert 0.78 < last_high_time < 0.82


def test_valid_check_no_overlap(tmp_path):
    """Test ValidCheck when inputs have no overlapping valid data."""
    p = Pipeline()

    # Source 1: data from 0-0.4s
    # Source 2: data from 0.6-1.0s
    # No overlap - output should be all gaps
    p.insert(
        SegmentSource(
            name="src1",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=((0, int(0.4 * 1e9)),),
            values=(1,),
        ),
        SegmentSource(
            name="src2",
            source_pad_names=("src",),
            rate=64,
            start=0.0,
            duration=1.0,
            segments=((int(0.6 * 1e9), int(1.0 * 1e9)),),
            values=(1,),
        ),
        ValidCheck(
            name="validator",
            sink_pad_names=("input1", "input2"),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "validator:snk:input1": "src1:src:src",
            "validator:snk:input2": "src2:src:src",
            "sink:snk:snk": "validator:src:src",
        },
    )

    p.run()

    # Verify output is empty (gap buffers aren't written to file)
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Expected empty output (gap) when no overlap"


def test_valid_check_all_valid(tmp_path):
    """Test ValidCheck when all inputs have continuous valid data."""
    p = Pipeline()

    # Both sources have continuous data from 0-1s
    # Output should be all ones
    p.insert(
        SegmentSource(
            name="src1",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=((0, int(1e9)),),
            values=(1,),
        ),
        SegmentSource(
            name="src2",
            source_pad_names=("src",),
            rate=64,
            start=0.0,
            duration=1.0,
            segments=((0, int(1e9)),),
            values=(1,),
        ),
        ValidCheck(
            name="validator",
            sink_pad_names=("input1", "input2"),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "validator:snk:input1": "src1:src:src",
            "validator:snk:input2": "src2:src:src",
            "sink:snk:snk": "validator:src:src",
        },
    )

    p.run()

    # Verify output is all ones
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    assert np.all(output_data[:, 1] == 1), (
        "Expected all ones when all inputs have valid data"
    )


def test_valid_check_all_gaps(tmp_path):
    """Test ValidCheck when all inputs have only gaps."""
    p = Pipeline()

    # Create sources with only gaps (no segments)
    p.insert(
        SegmentSource(
            name="src1",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=0.125,
            segments=(),
            values=(),
        ),
        SegmentSource(
            name="src2",
            source_pad_names=("src",),
            rate=64,
            start=0.0,
            duration=0.125,
            segments=(),
            values=(),
        ),
        ValidCheck(
            name="validator",
            sink_pad_names=("input1", "input2"),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "validator:snk:input1": "src1:src:src",
            "validator:snk:input2": "src2:src:src",
            "sink:snk:snk": "validator:src:src",
        },
    )

    p.run()

    # Output should be empty (gap buffers aren't written to file)
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Expected empty output (gaps) for all-gap inputs"


def test_valid_check_three_inputs(tmp_path):
    """Test ValidCheck with three inputs of different rates."""
    p = Pipeline()

    # Source 1: data from 0.1-0.2s, 0.4-0.7s, 0.8-1.0s
    # Source 2: data from 0.15-0.5s, 0.65-1.0s
    # Source 3: data from 0.1-0.3s, 0.6-0.9s
    # Expected valid: 0.15-0.2s, 0.65-0.7s, 0.8-0.9s
    p.insert(
        SegmentSource(
            name="src1",
            source_pad_names=("src",),
            rate=256,
            start=0.0,
            duration=1.0,
            segments=(
                (int(0.1 * 1e9), int(0.2 * 1e9)),
                (int(0.4 * 1e9), int(0.7 * 1e9)),
                (int(0.8 * 1e9), int(1.0 * 1e9)),
            ),
            values=(1, 1, 1),
        ),
        SegmentSource(
            name="src2",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=(
                (int(0.15 * 1e9), int(0.5 * 1e9)),
                (int(0.65 * 1e9), int(1.0 * 1e9)),
            ),
            values=(1, 1),
        ),
        SegmentSource(
            name="src3",
            source_pad_names=("src",),
            rate=64,
            start=0.0,
            duration=1.0,
            segments=(
                (int(0.1 * 1e9), int(0.3 * 1e9)),
                (int(0.6 * 1e9), int(0.9 * 1e9)),
            ),
            values=(1, 1),
        ),
        ValidCheck(
            name="validator",
            sink_pad_names=("input1", "input2", "input3"),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "validator:snk:input1": "src1:src:src",
            "validator:snk:input2": "src2:src:src",
            "validator:snk:input3": "src3:src:src",
            "sink:snk:snk": "validator:src:src",
        },
    )

    p.run()

    # Verify output
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    high_data = output_data[output_data[:, 1] == 1]

    # Should have three distinct valid regions
    if len(high_data) > 0:
        # Find continuous regions
        time_diffs = np.diff(high_data[:, 0])
        gap_threshold = 2.0 / 256  # Two samples at max rate
        gap_indices = np.where(time_diffs > gap_threshold)[0]

        # Should have 2 gaps, so 3 regions
        assert len(gap_indices) == 2, (
            f"Expected 3 valid regions, found {len(gap_indices) + 1}"
        )
