"""Pipeline tests for the BooleanGate combiner element."""

import numpy as np
from sgn.apps import Pipeline
from sgnts.sinks import DumpSeriesSink
from sgnts.sources.segment import SegmentSource

from sgn_dq.transforms.boolean_gate import BooleanGate, GateMode


def _run_gate_pipeline(tmp_path, sources, *, gate_mode):
    """Helper to wire N sources -> BooleanGate -> DumpSeriesSink."""
    outfile = str(tmp_path / "output.txt")
    sink_names = tuple(f"in{i}" for i in range(len(sources)))

    p = Pipeline()
    link_map = {}
    for i, _ in enumerate(sources):
        link_map[f"gate:snk:in{i}"] = f"src{i}:src:src"
    link_map["sink:snk:snk"] = "gate:src:src"

    p.insert(
        *sources,
        BooleanGate(
            name="gate",
            sink_pad_names=sink_names,
            source_pad_names=("src",),
            gate_mode=gate_mode,
        ),
        DumpSeriesSink(name="sink", fname=outfile, sink_pad_names=("snk",)),
        link_map=link_map,
    )
    p.run()
    return outfile


def _segment_source(name, segments, *, rate=64, duration=1.0):
    values = tuple(1 for _ in segments)
    return SegmentSource(
        name=name,
        source_pad_names=("src",),
        rate=rate,
        start=0.0,
        duration=duration,
        segments=segments,
        values=values,
    )


def _gap_source(name, *, rate=64, duration=1.0):
    return SegmentSource(
        name=name,
        source_pad_names=("src",),
        rate=rate,
        start=0.0,
        duration=duration,
        segments=(),
        values=(),
    )


class TestBooleanGateAnd:
    def test_both_buffer(self, tmp_path):
        """AND: both inputs fully buffer -> buffer output."""
        outfile = _run_gate_pipeline(
            tmp_path,
            [
                _segment_source("src0", ((0, int(1e9)),)),
                _segment_source("src1", ((0, int(1e9)),)),
            ],
            gate_mode=GateMode.ALL,
        )
        data = np.loadtxt(outfile)
        assert len(data) > 0
        assert np.all(data[:, 1] == 1.0)

    def test_one_gap(self, tmp_path):
        """AND: one input all gap -> all gap output."""
        outfile = _run_gate_pipeline(
            tmp_path,
            [
                _segment_source("src0", ((0, int(1e9)),)),
                _gap_source("src1"),
            ],
            gate_mode=GateMode.ALL,
        )
        with open(outfile) as f:
            assert f.read() == ""

    def test_partial_overlap(self, tmp_path):
        """AND: partial overlap -> buffer only in overlapping region."""
        outfile = _run_gate_pipeline(
            tmp_path,
            [
                _segment_source("src0", ((0, int(0.6e9)),)),
                _segment_source("src1", ((int(0.4e9), int(1e9)),)),
            ],
            gate_mode=GateMode.ALL,
        )
        data = np.loadtxt(outfile)
        assert len(data) > 0
        # Output should be in the 0.4-0.6s overlap region
        assert data[0, 0] >= 0.39
        assert data[-1, 0] <= 0.61

    def test_three_inputs(self, tmp_path):
        """AND: three inputs, output only where all three overlap."""
        outfile = _run_gate_pipeline(
            tmp_path,
            [
                _segment_source("src0", ((0, int(0.7e9)),)),
                _segment_source("src1", ((int(0.2e9), int(1e9)),)),
                _segment_source("src2", ((int(0.4e9), int(0.8e9)),)),
            ],
            gate_mode=GateMode.ALL,
        )
        data = np.loadtxt(outfile)
        assert len(data) > 0
        # Overlap is 0.4-0.7s
        assert data[0, 0] >= 0.39
        assert data[-1, 0] <= 0.71


class TestBooleanGateOr:
    def test_both_buffer(self, tmp_path):
        """OR: both inputs buffer -> buffer output."""
        outfile = _run_gate_pipeline(
            tmp_path,
            [
                _segment_source("src0", ((0, int(1e9)),)),
                _segment_source("src1", ((0, int(1e9)),)),
            ],
            gate_mode=GateMode.ANY,
        )
        data = np.loadtxt(outfile)
        assert len(data) > 0

    def test_one_buffer_one_gap(self, tmp_path):
        """OR: one buffer, one gap -> buffer output."""
        outfile = _run_gate_pipeline(
            tmp_path,
            [
                _segment_source("src0", ((0, int(1e9)),)),
                _gap_source("src1"),
            ],
            gate_mode=GateMode.ANY,
        )
        data = np.loadtxt(outfile)
        assert len(data) > 0

    def test_no_overlap(self, tmp_path):
        """OR: two non-overlapping segments -> buffer in both regions."""
        outfile = _run_gate_pipeline(
            tmp_path,
            [
                _segment_source("src0", ((0, int(0.4e9)),)),
                _segment_source("src1", ((int(0.6e9), int(1e9)),)),
            ],
            gate_mode=GateMode.ANY,
        )
        data = np.loadtxt(outfile)
        assert len(data) > 0
        # Should have data in both 0-0.4s and 0.6-1.0s regions
        times = data[:, 0]
        has_early = np.any(times < 0.3)
        has_late = np.any(times > 0.7)
        assert has_early
        assert has_late

    def test_all_gap(self, tmp_path):
        """OR: all inputs gap -> gap output."""
        outfile = _run_gate_pipeline(
            tmp_path,
            [
                _gap_source("src0"),
                _gap_source("src1"),
            ],
            gate_mode=GateMode.ANY,
        )
        with open(outfile) as f:
            assert f.read() == ""
