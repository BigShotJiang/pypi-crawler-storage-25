"""Pipeline tests for the Not inversion element."""

import numpy as np
from sgn.apps import Pipeline
from sgnts.sinks import DumpSeriesSink
from sgnts.sources.segment import SegmentSource

from sgn_dq.transforms.boolean_not import Not


def _run_not_pipeline(tmp_path, source):
    """Helper to wire a source -> Not -> DumpSeriesSink pipeline."""
    outfile = str(tmp_path / "output.txt")
    p = Pipeline()
    p.insert(
        source,
        Not(
            name="inv",
            sink_pad_names=("src",),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(name="sink", fname=outfile, sink_pad_names=("snk",)),
        link_map={
            "inv:snk:src": "source:src:src",
            "sink:snk:snk": "inv:src:src",
        },
    )
    p.run()
    return outfile


class TestNotInversion:
    def test_all_buffer_to_all_gap(self, tmp_path):
        """All-buffer input -> all-gap output (empty file)."""
        outfile = _run_not_pipeline(
            tmp_path,
            SegmentSource(
                name="source",
                source_pad_names=("src",),
                rate=64,
                start=0.0,
                duration=1.0,
                segments=((0, int(1e9)),),
                values=(1,),
            ),
        )
        with open(outfile) as f:
            assert f.read() == ""

    def test_all_gap_to_all_buffer(self, tmp_path):
        """All-gap input -> all-buffer output."""
        outfile = _run_not_pipeline(
            tmp_path,
            SegmentSource(
                name="source",
                source_pad_names=("src",),
                rate=64,
                start=0.0,
                duration=1.0,
                segments=(),
                values=(),
            ),
        )
        data = np.loadtxt(outfile)
        assert len(data) > 0
        assert np.all(data[:, 1] == 1.0)

    def test_mixed_inversion(self, tmp_path):
        """Buffer in first half, gap in second -> gap first half, buffer second."""
        outfile = _run_not_pipeline(
            tmp_path,
            SegmentSource(
                name="source",
                source_pad_names=("src",),
                rate=64,
                start=0.0,
                duration=1.0,
                segments=((0, int(0.5e9)),),
                values=(1,),
            ),
        )
        data = np.loadtxt(outfile)
        assert len(data) > 0
        # Output should be in the 0.5-1.0s region (inverted from gap to buffer)
        assert data[0, 0] >= 0.49
        assert data[-1, 0] <= 1.01
