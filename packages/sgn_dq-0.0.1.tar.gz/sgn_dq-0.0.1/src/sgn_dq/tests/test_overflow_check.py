"""Tests for OverflowCheck evaluator."""

import numpy as np
from sgn.apps import Pipeline
from sgnts.sinks import DumpSeriesSink
from sgnts.sources.segment import SegmentSource

from sgn_dq.transforms.evaluators import OverflowCheck


def test_overflow_check_no_overflow(tmp_path):
    """Test OverflowCheck when counter values are constant (no overflow)."""
    p = Pipeline()

    # Constant value = no overflow
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=((0, int(1.0 * 1e9)),),
            values=(100,),  # Constant value
        ),
        OverflowCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # No overflow means all gaps (gaps not written to file)
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Expected empty output (no overflow detected)"


def test_overflow_check_overflow_detected(tmp_path):
    """Test OverflowCheck when counter value increases (overflow detected)."""
    p = Pipeline()

    # Two segments with increasing values = overflow
    # First segment: value 100
    # Second segment: value 200 (> 100, so overflow detected)
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=(
                (0, int(0.5 * 1e9)),
                (int(0.5 * 1e9), int(1.0 * 1e9)),
            ),
            values=(100, 200),  # Increasing values
        ),
        OverflowCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Should have output in the second interval
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    if len(output_data) > 0:
        # Check that the output is in the 0.5-1.0s range
        times = output_data[:, 0]
        assert np.min(times) >= 0.48, "Overflow should be detected in second interval"


def test_overflow_check_first_interval_gap(tmp_path):
    """Test that first interval always outputs gap (no previous to compare)."""
    p = Pipeline()

    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=0.5,
            segments=((0, int(0.5 * 1e9)),),
            values=(100,),
        ),
        OverflowCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # First interval should be gap (no previous to compare)
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Expected empty output for first interval"


def test_overflow_check_gap_resets_state(tmp_path):
    """Test that gaps reset the overflow detection state."""
    p = Pipeline()

    # Segment 1: value 100
    # Gap in middle
    # Segment 2: value 200
    # Should NOT detect overflow because gap resets state
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=(
                (0, int(0.3 * 1e9)),
                (int(0.7 * 1e9), int(1.0 * 1e9)),
            ),
            values=(100, 200),
        ),
        OverflowCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Gap should reset state, so no overflow detected
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Gap should reset state, no overflow detected"


def test_overflow_check_multi_channel(tmp_path):
    """Test OverflowCheck with multiple input channels."""
    p = Pipeline()

    # Channel 1: constant (no overflow)
    # Channel 2: increasing (overflow)
    # Should detect overflow because ANY channel has overflow
    p.insert(
        SegmentSource(
            name="src1",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=(
                (0, int(0.5 * 1e9)),
                (int(0.5 * 1e9), int(1.0 * 1e9)),
            ),
            values=(100, 100),  # Constant
        ),
        SegmentSource(
            name="src2",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=(
                (0, int(0.5 * 1e9)),
                (int(0.5 * 1e9), int(1.0 * 1e9)),
            ),
            values=(50, 150),  # Increasing (overflow)
        ),
        OverflowCheck(
            name="checker",
            sink_pad_names=("input1", "input2"),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input1": "src1:src:src",
            "checker:snk:input2": "src2:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Should detect overflow in second interval
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    if len(output_data) > 0:
        times = output_data[:, 0]
        assert np.min(times) >= 0.48, "Overflow should be in second interval"


def test_overflow_check_decreasing_no_overflow(tmp_path):
    """Test that decreasing values do not trigger overflow."""
    p = Pipeline()

    # Decreasing values: 200 -> 100
    # This should NOT be considered overflow (only increasing triggers)
    p.insert(
        SegmentSource(
            name="src",
            source_pad_names=("src",),
            rate=128,
            start=0.0,
            duration=1.0,
            segments=(
                (0, int(0.5 * 1e9)),
                (int(0.5 * 1e9), int(1.0 * 1e9)),
            ),
            values=(200, 100),  # Decreasing
        ),
        OverflowCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Decreasing should not trigger overflow
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Decreasing values should not trigger overflow"
