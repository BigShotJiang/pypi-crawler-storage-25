"""Tests for RmsCheck evaluator."""

import numpy as np
from sgn.apps import Pipeline
from sgnts.sinks import DumpSeriesSink
from sgnts.sources import FakeSeriesSource

from sgn_dq.transforms.evaluators import RmsCheck


def test_rms_check_below_threshold(tmp_path):
    """Test RmsCheck when RMS is below threshold."""
    p = Pipeline()

    # Constant signal has zero RMS
    p.insert(
        FakeSeriesSource(
            name="src",
            source_pad_names=("src",),
            rate=256,
            signal_type="const",
            const=1.0,
            end=1.0,
        ),
        RmsCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            threshold=0.1,  # Above zero RMS
            avg_time=0.5,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # RMS of constant signal is 0, which is below threshold
    # So output should be gap (empty file)
    with open(tmp_path / "output.txt") as f:
        content = f.read()
    assert content == "", "Expected empty output (RMS below threshold)"


def test_rms_check_above_threshold(tmp_path):
    """Test RmsCheck when RMS exceeds threshold."""
    p = Pipeline()

    # White noise has significant RMS
    p.insert(
        FakeSeriesSource(
            name="src",
            source_pad_names=("src",),
            rate=256,
            signal_type="white",
            end=1.0,
        ),
        RmsCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            threshold=0.01,  # Very low threshold, noise will exceed
            avg_time=0.5,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # White noise should exceed low threshold
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    assert len(output_data) > 0, "Expected non-empty output (RMS above threshold)"


def test_rms_check_sine_wave(tmp_path):
    """Test RmsCheck with sine wave (known RMS)."""
    p = Pipeline()

    # Sine wave with amplitude A has RMS = A/sqrt(2) ~ 0.707*A
    expected_rms = 1.0 / np.sqrt(2)

    p.insert(
        FakeSeriesSource(
            name="src",
            source_pad_names=("src",),
            rate=256,
            signal_type="sin",
            fsin=10.0,
            end=2.0,  # Multiple periods
        ),
        RmsCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            threshold=expected_rms * 0.5,  # Below expected RMS
            avg_time=1.0,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Sine RMS should exceed threshold
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    assert len(output_data) > 0, "Expected non-empty output"


def test_rms_check_gap_resets_history(tmp_path):
    """Test that gaps reset the RMS history."""
    p = Pipeline()

    # Use FakeSeriesSource with regular gaps (ngap=2 means every 2nd buffer is gap)
    p.insert(
        FakeSeriesSource(
            name="src",
            source_pad_names=("src",),
            rate=256,
            signal_type="white",
            ngap=2,  # Every 2nd buffer is a gap
            end=4.0,  # Longer duration to ensure gaps occur
        ),
        RmsCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            threshold=0.01,  # Low threshold, white noise should exceed
            avg_time=0.5,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # The test just verifies the transform handles gaps without error
    # With ngap=2, every other buffer is a gap, and history should reset
    # Output may have gaps corresponding to where input has gaps plus
    # areas where RMS fell below threshold after history reset
    assert True, "Gap handling test completed without error"


def test_rms_check_window_accumulation(tmp_path):
    """Test that RMS window accumulates properly."""
    p = Pipeline()

    # White noise has RMS around 1.0
    p.insert(
        FakeSeriesSource(
            name="src",
            source_pad_names=("src",),
            rate=256,
            signal_type="white",
            end=2.0,
        ),
        RmsCheck(
            name="checker",
            sink_pad_names=("input",),
            source_pad_names=("src",),
            threshold=0.5,  # Moderate threshold
            avg_time=0.5,
        ),
        DumpSeriesSink(
            name="sink", fname=str(tmp_path / "output.txt"), sink_pad_names=("snk",)
        ),
        link_map={
            "checker:snk:input": "src:src:src",
            "sink:snk:snk": "checker:src:src",
        },
    )

    p.run()

    # Should have some output once window fills with noisy data
    output_data = np.loadtxt(str(tmp_path / "output.txt"))
    # White noise with standard randn() has RMS ~1.0, should exceed 0.5 threshold
    assert len(output_data) > 0, "Expected some output once window fills"
