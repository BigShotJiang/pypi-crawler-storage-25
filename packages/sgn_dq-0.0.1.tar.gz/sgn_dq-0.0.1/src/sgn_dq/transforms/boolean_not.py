"""Unary inversion of buffer/gap status."""

from __future__ import annotations

from dataclasses import dataclass

from sgn import validator
from sgnts.base import (
    SeriesBuffer,
    TSCollectFrame,
    TSFrame,
    TSSlice,
    TSSlices,
    TSTransform,
)
from sgnts.decorators import transform


@dataclass
class Not(TSTransform):
    """Invert buffer/gap status of an input stream.

    Buffers become gaps and gaps become buffers. The output uses the
    same sample rate as the input and contains ones where the input
    had gaps.
    """

    @validator.one_to_one
    def validate(self) -> None:
        pass

    @transform.one_to_one
    def process(self, input_frame: TSFrame, output_frame: TSCollectFrame) -> None:
        """Invert buffer/gap regions."""
        nongap_slices = TSSlices([buf.slice for buf in input_frame if not buf.is_gap])

        frame_slice = TSSlice(input_frame[0].offset, input_frame[-1].end_offset)

        inverted_slices = nongap_slices.invert(frame_slice)

        full_buffer = SeriesBuffer.fromoffsetslice(
            frame_slice,
            sample_rate=input_frame.sample_rate,
            data=1,
        )

        output_buffers = (
            full_buffer.split(inverted_slices, contiguous=True)
            if inverted_slices.slices
            else [full_buffer.new()]
        )

        output_frame.extend(output_buffers)
