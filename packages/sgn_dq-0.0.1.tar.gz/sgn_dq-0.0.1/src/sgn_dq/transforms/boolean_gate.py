"""N-ary boolean combiner for buffer/gap streams."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from sgn import validator
from sgnts.base import (
    SeriesBuffer,
    TSCollectFrame,
    TSFrame,
    TSSlice,
    TSSlices,
    TSTransform,
)
from sgnts.decorators import transform

if TYPE_CHECKING:
    from sgn.base import SinkPad


class GateMode(Enum):
    """How multiple input streams are combined.

    Attributes:
        ALL: Output buffer only where ALL inputs have buffer (logical AND).
        ANY: Output buffer where ANY input has buffer (logical OR).
    """

    ALL = "all"
    ANY = "any"


@dataclass(kw_only=True)
class BooleanGate(TSTransform):
    """Combine multiple buffer/gap streams with boolean logic.

    Accepts N input pads and produces a single output. Each input is
    treated as a boolean signal: buffer = true, gap = false.

    In :attr:`GateMode.ALL` mode the output is buffer only where every
    input has buffer (logical AND). In :attr:`GateMode.ANY` mode the
    output is buffer where at least one input has buffer (logical OR).

    Args:
        gate_mode:
            Whether to combine inputs with AND or OR semantics.
    """

    gate_mode: GateMode

    def configure(self) -> None:
        self.adapter_config.enable = False

    @validator.many_to_one
    def validate(self) -> None:
        pass

    @transform.many_to_one
    def process(
        self,
        input_frames: dict[SinkPad, TSFrame],
        output_frame: TSCollectFrame,
    ) -> None:
        """Combine input streams according to gate mode."""
        frames = list(input_frames.values())
        max_rate = max(f.sample_rate for f in frames)

        all_nongap_slices = [
            TSSlices([buf.slice for buf in frame if not buf.is_gap]) for frame in frames
        ]

        match self.gate_mode:
            case GateMode.ALL:
                result_slices = TSSlices.intersection_of_multiple(all_nongap_slices)
            case GateMode.ANY:
                combined = TSSlices(
                    [s for slices in all_nongap_slices for s in slices.slices]
                )
                result_slices = combined.simplify()

        frame_slice = TSSlice(frames[0].offset, frames[0].end_offset)
        full_buffer = SeriesBuffer.fromoffsetslice(
            frame_slice, sample_rate=max_rate, data=1
        )

        output_buffers = (
            full_buffer.split(result_slices, contiguous=True)
            if result_slices.slices
            else [full_buffer.new()]
        )

        output_frame.extend(output_buffers)
