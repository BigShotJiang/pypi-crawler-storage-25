"""BandRmsCheck evaluator for bandpass-filtered RMS threshold checking."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
from scipy import signal
from sgn import validator
from sgnts.base import (
    SeriesBuffer,
    TSCollectFrame,
    TSFrame,
    TSTransform,
)
from sgnts.decorators import transform


@dataclass(kw_only=True)
class BandRmsCheck(TSTransform):
    """Check bandpass-filtered RMS against a threshold.

    This evaluator:
    1. Applies an elliptic bandpass filter to the input
    2. Computes instantaneous RMS: sqrt(mean(filtered**2))
    3. Optionally applies exponential averaging with a decay time constant
    4. Compares against threshold: rms <= rms_max means condition met

    Output semantics:
    - Buffer (condition met): RMS is at or below threshold
    - Gap (condition not met): RMS exceeds threshold

    Args:
        rms_max:
            float, required. Maximum RMS threshold. Condition is met when
            RMS <= rms_max.
        bandpass:
            dict, required. Filter specification with keys:
            - type: str, filter type (must be 'elliptic')
            - order: int, filter order
            - ripple_db: float, passband ripple in dB
            - stop_atten_db: float, stopband attenuation in dB
            - low_hz: float, low cutoff frequency
            - high_hz: float, high cutoff frequency
        decay_time:
            float, optional. Exponential averaging time constant in seconds.
            If None or 0, no averaging is applied.
        settle:
            float, optional. Settling time in seconds before condition
            evaluation begins. During settling, outputs gap.
    """

    rms_max: float
    bandpass: dict[str, Any]
    decay_time: float | None = None
    settle: float | None = None

    # Internal state
    _filter_sos: np.ndarray | None = field(default=None, init=False, repr=False)
    _filter_zi: np.ndarray | None = field(default=None, init=False, repr=False)
    _running_rms: float | None = field(default=None, init=False, repr=False)
    _settle_samples_remaining: int = field(default=0, init=False, repr=False)
    _sample_rate: int = field(default=0, init=False, repr=False)

    def configure(self) -> None:
        """Disable adapter to preserve gap boundaries."""
        self.adapter_config.enable = False

    @validator.one_to_one
    def validate(self) -> None:
        """Validate parameters."""
        assert self.rms_max > 0, f"rms_max must be positive, got {self.rms_max}"

        required_keys = {
            "type",
            "order",
            "ripple_db",
            "stop_atten_db",
            "low_hz",
            "high_hz",
        }
        assert required_keys <= set(self.bandpass.keys()), (
            f"bandpass must contain keys: {required_keys}, "
            f"got {set(self.bandpass.keys())}"
        )
        assert self.bandpass["type"] == "elliptic", (
            f"Only 'elliptic' filter type supported, got {self.bandpass['type']}"
        )
        assert self.bandpass["order"] > 0, "filter order must be positive"
        assert self.bandpass["low_hz"] < self.bandpass["high_hz"], (
            "low_hz must be less than high_hz"
        )
        assert self.bandpass["low_hz"] > 0, "low_hz must be positive"

        if self.decay_time is not None:
            assert self.decay_time >= 0, "decay_time must be non-negative"
        if self.settle is not None:
            assert self.settle >= 0, "settle must be non-negative"

    def _init_filter(self, sample_rate: int) -> None:
        """Initialize elliptic bandpass filter."""
        self._sample_rate = sample_rate
        nyquist = sample_rate / 2

        low_norm = self.bandpass["low_hz"] / nyquist
        high_norm = self.bandpass["high_hz"] / nyquist

        # Check normalized frequencies are valid
        if low_norm >= 1.0 or high_norm >= 1.0:
            msg = (
                f"Filter frequencies must be below Nyquist ({nyquist} Hz). "
                f"Got low={self.bandpass['low_hz']} Hz, "
                f"high={self.bandpass['high_hz']} Hz."
            )
            raise ValueError(msg)

        # Design elliptic bandpass filter (SOS format for numerical stability)
        self._filter_sos = signal.ellip(
            N=self.bandpass["order"],
            rp=self.bandpass["ripple_db"],
            rs=self.bandpass["stop_atten_db"],
            Wn=[low_norm, high_norm],
            btype="bandpass",
            output="sos",
        )

        # Initialize filter state
        self._filter_zi = signal.sosfilt_zi(self._filter_sos)

        # Initialize settling counter
        if self.settle and self._sample_rate > 0:
            self._settle_samples_remaining = int(self.settle * sample_rate)
        else:
            self._settle_samples_remaining = 0

    def _reset_state(self) -> None:
        """Reset filter and averaging state."""
        if self._filter_sos is not None:
            self._filter_zi = signal.sosfilt_zi(self._filter_sos)
        self._running_rms = None
        if self.settle and self._sample_rate > 0:
            self._settle_samples_remaining = int(self.settle * self._sample_rate)

    @transform.one_to_one
    def process(self, input_frame: TSFrame, output_frame: TSCollectFrame) -> None:
        """Apply bandpass filter, compute RMS, check threshold."""
        for buf in input_frame:
            if buf.is_gap:
                self._reset_state()
                output_frame.append(buf.new())
                continue

            assert buf.data is not None

            # Initialize filter on first non-gap buffer
            if self._filter_sos is None:
                self._init_filter(buf.sample_rate)

            data = np.asarray(buf.data).flatten().astype(np.float64)

            # Apply bandpass filter with state continuity
            filtered, self._filter_zi = signal.sosfilt(
                self._filter_sos, data, zi=self._filter_zi * data[0]
            )

            # Compute instantaneous RMS
            instant_rms = float(np.sqrt(np.mean(filtered**2)))

            # Apply exponential averaging if configured
            if self.decay_time and self.decay_time > 0:
                alpha = 1.0 - np.exp(-buf.duration / self.decay_time)

                if self._running_rms is None:
                    self._running_rms = instant_rms
                else:
                    self._running_rms = (
                        alpha * instant_rms + (1 - alpha) * self._running_rms
                    )

                rms = self._running_rms
            else:
                rms = instant_rms

            # Check settling time
            if self._settle_samples_remaining > 0:
                self._settle_samples_remaining -= buf.samples
                # During settling, output gap (condition not met)
                output_frame.append(buf.new())
                continue

            # Check threshold (condition met if rms <= rms_max)
            condition_met = rms <= self.rms_max

            if condition_met:
                # Condition met: output buffer with 1s
                out_buf = SeriesBuffer(
                    offset=buf.offset,
                    sample_rate=buf.sample_rate,
                    data=1,
                    shape=buf.shape,
                )
            else:
                # Condition not met: output gap
                out_buf = buf.new()

            output_frame.append(out_buf)
