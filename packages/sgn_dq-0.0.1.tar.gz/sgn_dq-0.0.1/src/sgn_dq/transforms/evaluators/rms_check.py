"""RmsCheck evaluator for rolling RMS threshold checking."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

import numpy as np
from sgn import validator
from sgnts.base import (
    SeriesBuffer,
    TSCollectFrame,
    TSFrame,
    TSTransform,
)
from sgnts.decorators import transform


@dataclass
class RmsCheck(TSTransform):
    """Check if RMS (standard deviation) exceeds a threshold over a rolling window.

    This evaluator maintains a rolling history buffer and computes the standard
    deviation. When sigma exceeds the threshold, condition is met (buffer output).

    Output semantics:
    - Buffer (condition met): RMS exceeds threshold
    - Gap (condition not met): RMS is at or below threshold

    Args:
        threshold:
            float, sigma threshold above which condition is met.
        avg_time:
            float, duration of rolling history window in seconds.
    """

    threshold: float = 1.0
    avg_time: float = 1.0

    # Internal state
    _history: deque = field(default_factory=deque, init=False, repr=False)
    _history_duration: float = field(default=0.0, init=False, repr=False)
    _sample_rate: int = field(default=0, init=False, repr=False)

    def configure(self) -> None:
        """Disable adapter to preserve gap boundaries."""
        self.adapter_config.enable = False

    @validator.one_to_one
    def validate(self) -> None:
        """Validate parameters."""
        assert self.threshold > 0, f"threshold must be positive, got {self.threshold}"
        assert self.avg_time > 0, f"avg_time must be positive, got {self.avg_time}"

    def _reset_history(self) -> None:
        """Reset rolling history buffer."""
        self._history.clear()
        self._history_duration = 0.0

    @transform.one_to_one
    def process(self, input_frame: TSFrame, output_frame: TSCollectFrame) -> None:
        """Compute rolling RMS and check against threshold."""
        for buf in input_frame:
            if buf.is_gap:
                # Reset history on gaps
                self._reset_history()
                output_frame.append(buf.new())
                continue

            assert buf.data is not None
            data = np.asarray(buf.data).flatten()
            self._sample_rate = buf.sample_rate

            # Add new data to history
            self._history.append(data)
            self._history_duration += buf.duration

            # Trim history to window size
            while self._history_duration > self.avg_time and len(self._history) > 1:
                old_data = self._history.popleft()
                old_duration = len(old_data) / self._sample_rate
                self._history_duration -= old_duration

            # Compute RMS (standard deviation) across entire history
            all_data = np.concatenate(list(self._history))
            rms = float(np.std(all_data))

            # Check threshold
            condition_met = rms > self.threshold

            if condition_met:
                # Condition met: output buffer with 1s
                out_buf = SeriesBuffer(
                    offset=buf.offset,
                    sample_rate=buf.sample_rate,
                    data=1,
                    shape=buf.shape,
                )
            else:
                # Condition not met: output gap
                out_buf = buf.new()

            output_frame.append(out_buf)
