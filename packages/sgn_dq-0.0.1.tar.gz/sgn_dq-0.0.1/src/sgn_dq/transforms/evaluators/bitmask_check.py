"""BitMaskCheck evaluator for testing bitwise conditions."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sgn import validator
from sgnts.base import (
    SeriesBuffer,
    TSCollectFrame,
    TSFrame,
    TSTransform,
)
from sgnts.decorators import transform


@dataclass
class BitMaskCheck(TSTransform):
    """Check bitwise conditions on a uint32 channel.

    This evaluator tests two independent conditions:
    - any_mask: OR mask - condition met if ANY specified bits are set in ANY sample
    - all_mask: AND mask - condition met if ALL specified bits are set in ALL samples

    Both conditions must pass for the output to be a buffer (condition met).
    If neither mask is specified, all valid input produces buffer output.

    Output semantics:
    - Buffer (non-gap) = condition met
    - Gap = condition not met

    Args:
        any_mask:
            int, optional. OR mask for "any bits set" test.
            Condition passes if (any_sample & any_mask) != 0.
        all_mask:
            int, optional. AND mask for "all bits set" test.
            Condition passes if (all_samples & all_mask) == all_mask.
    """

    any_mask: int | None = None
    all_mask: int | None = None

    def configure(self) -> None:
        """Disable adapter to preserve gap boundaries."""
        self.adapter_config.enable = False

    @validator.one_to_one
    def validate(self) -> None:
        """Validate parameters."""
        if self.any_mask is not None:
            assert isinstance(self.any_mask, int) and self.any_mask >= 0, (
                f"'any_mask' must be non-negative integer, got {self.any_mask}"
            )
        if self.all_mask is not None:
            assert isinstance(self.all_mask, int) and self.all_mask >= 0, (
                f"'all_mask' must be non-negative integer, got {self.all_mask}"
            )

    @transform.one_to_one
    def process(self, input_frame: TSFrame, output_frame: TSCollectFrame) -> None:
        """Check bitmask conditions on input data."""
        for buf in input_frame:
            if buf.is_gap:
                # Preserve gaps
                output_frame.append(buf.new())
                continue

            assert buf.data is not None
            data = np.asarray(buf.data, dtype=np.uint32)

            # Evaluate conditions
            condition_met = True

            if self.any_mask is not None:
                # Check if any of the specified bits are set in any sample
                any_accum = np.bitwise_or.reduce(data.flatten())
                any_result = (any_accum & self.any_mask) != 0
                condition_met = condition_met and any_result

            if self.all_mask is not None:
                # Check if all specified bits are set in all samples
                all_accum = np.bitwise_and.reduce(data.flatten())
                all_result = (all_accum & self.all_mask) == self.all_mask
                condition_met = condition_met and all_result

            if condition_met:
                # Condition met: output buffer with 1s
                out_buf = SeriesBuffer(
                    offset=buf.offset,
                    sample_rate=buf.sample_rate,
                    data=1,
                    shape=buf.shape,
                )
            else:
                # Condition not met: output gap
                out_buf = buf.new()

            output_frame.append(out_buf)
