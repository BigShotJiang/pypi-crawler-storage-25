"""OverflowCheck evaluator for detecting ADC/DAC overflow."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
from sgn import validator
from sgnts.base import (
    ArrayBackend,
    NumpyBackend,
    Offset,
    SeriesBuffer,
    TSCollectFrame,
    TSFrame,
    TSSlice,
    TSSlices,
    TSTransform,
)
from sgnts.decorators import transform

if TYPE_CHECKING:
    from sgn.base import SinkPad


@dataclass
class OverflowCheck(TSTransform):
    """Detect ADC/DAC overflow by comparing max values across intervals.

    This evaluator monitors one or more overflow accumulator channels and
    detects when the max value in the current interval exceeds the max
    value from the previous interval for ANY channel.

    State resets on data gaps (assumes hardware reset on gap).

    Output semantics:
    - Buffer (condition met): Overflow detected (current_max > prev_max)
    - Gap (condition not met): No overflow, first interval, or after gap

    Note: This evaluator returns buffer when overflow IS detected. Use the
    `invert` flag in the flag configuration to flip the DQ vector bit so
    that 1 = no overflow (good).

    Args:
        backend:
            type[ArrayBackend], the wrapper around array operations
        output_shape:
            tuple[int, ...], shape of output samples (excluding time dimension).
    """

    backend: type[ArrayBackend] = NumpyBackend
    output_shape: tuple[int, ...] = field(default_factory=tuple)

    # Internal state: previous interval max values per channel
    _prev_max: dict[str, float | None] = field(
        default_factory=dict, init=False, repr=False
    )

    def configure(self) -> None:
        """Disable adapter to preserve gap boundaries."""
        self.adapter_config.enable = False

    @validator.many_to_one
    def validate(self) -> None:
        """Validate at least one input channel."""
        assert len(self.sink_pads) >= 1, "OverflowCheck requires at least one input"

    def _reset_state(self) -> None:
        """Reset state for all channels."""
        self._prev_max.clear()

    @transform.many_to_one
    def process(
        self, input_frames: dict[SinkPad, TSFrame], output_frame: TSCollectFrame
    ) -> None:
        """Check for overflow across all input channels."""
        frames = list(input_frames.values())
        pads = list(input_frames.keys())

        # Use the maximum sample rate among all inputs for output
        max_rate = max(f.sample_rate for f in frames)

        # Collect non-gap slices from each input
        all_nongap_slices = [
            TSSlices([buf.slice for buf in frame if not buf.is_gap]) for frame in frames
        ]

        # Find intersection where ALL inputs have valid data
        intersection_slices = TSSlices.intersection_of_multiple(all_nongap_slices)

        # Get frame boundaries
        frame_slice = TSSlice(frames[0].offset, frames[0].end_offset)

        # If no valid intersection, reset state and output gap
        if not intersection_slices.slices:
            self._reset_state()
            full_gap = SeriesBuffer.fromoffsetslice(
                frame_slice,
                sample_rate=max_rate,
                data=None,
                channels=self.output_shape,
            )
            output_frame.append(full_gap)
            return

        # Process each valid interval, resetting state at gaps between them
        output_buffers = []
        gap_slices = intersection_slices.invert(frame_slice)
        prev_interval_end = frame_slice.start

        for interval_slice in intersection_slices.slices:
            # Reset state if there was a gap before this interval
            if interval_slice.start > prev_interval_end:
                self._reset_state()
            prev_interval_end = interval_slice.stop
            # Extract data from each channel for this interval
            channel_maxes = []
            has_gap = False

            for i, frame in enumerate(frames):
                pad_name = pads[i].pad_name
                interval_data = []

                for buf in frame:
                    if buf.is_gap:
                        continue
                    # Check if buffer overlaps with interval
                    buf_slice = buf.slice
                    intersection = buf_slice & interval_slice
                    if intersection and intersection.start < intersection.stop:
                        # Extract overlapping data using offset-to-sample conversion
                        start_idx = Offset.tosamples(
                            intersection.start - buf.offset, buf.sample_rate
                        )
                        end_idx = Offset.tosamples(
                            intersection.stop - buf.offset, buf.sample_rate
                        )
                        if buf.data is not None and end_idx > start_idx:
                            interval_data.append(buf.data[..., start_idx:end_idx])

                if not interval_data:
                    has_gap = True
                    break

                # Compute max for this channel in this interval
                combined = np.concatenate(
                    [np.asarray(d).flatten() for d in interval_data]
                )
                current_max = float(np.max(combined))
                channel_maxes.append((pad_name, current_max))

            if has_gap:
                # Gap detected - reset state and output gap for this interval
                self._reset_state()
                gap_buf = SeriesBuffer.fromoffsetslice(
                    interval_slice,
                    sample_rate=max_rate,
                    data=None,
                    channels=self.output_shape,
                )
                output_buffers.append(gap_buf)
                continue

            # Check for overflow: any channel where current_max > prev_max
            overflow_detected = False
            for pad_name, current_max in channel_maxes:
                prev_max = self._prev_max.get(pad_name)
                if prev_max is not None and current_max > prev_max:
                    overflow_detected = True
                # Update state
                self._prev_max[pad_name] = current_max

            # Create output buffer for this interval
            if overflow_detected:
                # Overflow detected: output buffer with 1s
                out_buf = SeriesBuffer.fromoffsetslice(
                    interval_slice,
                    sample_rate=max_rate,
                    data=1,
                    channels=self.output_shape,
                )
            else:
                # No overflow (or first interval): output gap
                out_buf = SeriesBuffer.fromoffsetslice(
                    interval_slice,
                    sample_rate=max_rate,
                    data=None,
                    channels=self.output_shape,
                )
            output_buffers.append(out_buf)

        # Fill gaps between valid intervals
        gap_slices = intersection_slices.invert(frame_slice)
        for gap_slice in gap_slices.slices:
            # Reset state on gap
            self._reset_state()
            gap_buf = SeriesBuffer.fromoffsetslice(
                gap_slice,
                sample_rate=max_rate,
                data=None,
                channels=self.output_shape,
            )
            output_buffers.append(gap_buf)

        # Sort and output
        output_buffers.sort(key=lambda b: b.offset)
        output_frame.extend(output_buffers)
