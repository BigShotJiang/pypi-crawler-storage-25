"""SGN transforms for data quality."""
