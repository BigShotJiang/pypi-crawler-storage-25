"""Data quality elements for sgn."""
