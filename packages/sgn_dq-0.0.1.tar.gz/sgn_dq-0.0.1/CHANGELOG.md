# Changelog

## [Unreleased]

## [0.0.1] - 2026-04-20

- Initial release.

[unreleased]: https://git.ligo.org/detchar/sgn-dq/sgn-dq/-/compare/0.0.1...main
[0.0.1]: https://git.ligo.org/detchar/sgn-dq/sgn-dq/-/tags/0.0.1
