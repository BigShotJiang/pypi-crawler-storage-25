<h1 align="center">sgn-dq</h1>

<p align="center">Data quality elements for <a href="https://git.ligo.org/greg/sgn">sgn</a></p>

<p align="center">
  <a href="https://git.ligo.org/detchar/sgn-dq/sgn-dq/-/pipelines/latest">
    <img alt="ci" src="https://git.ligo.org/detchar/sgn-dq/sgn-dq/badges/main/pipeline.svg" />
  </a>
  <a href="https://git.ligo.org/detchar/sgn-dq/sgn-dq/-/pipelines/latest">
    <img alt="coverage" src="https://git.ligo.org/detchar/sgn-dq/sgn-dq/badges/main/coverage.svg" />
  </a>
  <a href="https://detchar.docs.ligo.org/sgn-dq/sgn-dq">
    <img alt="documentation" src="https://img.shields.io/badge/docs-mkdocs%20material-blue.svg?style=flat" />
  </a>
</p>

---

## Resources

* [Documentation](https://detchar.docs.ligo.org/sgn-dq/sgn-dq)
* [Source Code](https://git.ligo.org/detchar/sgn-dq/sgn-dq)
* [Issue Tracker](https://git.ligo.org/detchar/sgn-dq/sgn-dq/-/issues)

## Installation

```
pip install sgn-dq
```
