"""Documentation macros package."""
