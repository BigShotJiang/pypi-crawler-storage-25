"""UnitOfWork with undo stack and YAML persistence commit boundary."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from .models import StandardNameEntry
from .services import validate_models


@dataclass
class Snapshot:
    name: str
    model: StandardNameEntry


@dataclass
class UndoOpAdd:  # inverse delete
    name: str


@dataclass
class UndoOpDelete:  # inverse reinsert
    snap: Snapshot


@dataclass
class UndoOpUpdate:  # inverse restore old
    snap: Snapshot


@dataclass
class UndoOpRename:  # inverse delete new then reinsert old
    old: Snapshot
    new_name: str


if TYPE_CHECKING:  # pragma: no cover
    from .repository import StandardNameCatalog


class UnitOfWork:
    def __init__(self, repo: StandardNameCatalog):
        self.repo = repo
        self.catalog = repo.catalog
        self._undo: list[object] = []
        self._closed = False

    # Mutations --------------------------------------------------------------
    def has(self, name: str) -> bool:
        """Check if an entry with the given name exists in the catalog."""
        return self.catalog.get_row(name) is not None

    def add(self, model: StandardNameEntry) -> None:
        if self.catalog.get_row(model.name):
            raise ValueError(f"Entry '{model.name}' exists")
        self.catalog.insert(model)
        self._undo.append(UndoOpAdd(model.name))

    def update(self, name: str, model: StandardNameEntry):
        row = self.catalog.get_row(name)
        if not row:
            raise KeyError(name)
        old_model = self.repo._row_to_model(row)
        self.catalog.delete(name)
        self.catalog.insert(model)
        self._undo.append(UndoOpUpdate(Snapshot(name, old_model)))

    def remove(self, name: str):
        row = self.catalog.get_row(name)
        if not row:
            return
        old_model = self.repo._row_to_model(row)
        self.catalog.delete(name)
        self._undo.append(UndoOpDelete(Snapshot(name, old_model)))

    def rename(self, old_name: str, new_model: StandardNameEntry):
        if old_name == new_model.name:
            return self.update(old_name, new_model)
        row = self.catalog.get_row(old_name)
        if not row:
            raise KeyError(old_name)
        old_model = self.repo._row_to_model(row)
        if self.catalog.get_row(new_model.name):
            raise ValueError(f"Target name '{new_model.name}' exists")
        self.catalog.delete(old_name)
        self.catalog.insert(new_model)
        self._undo.append(UndoOpRename(Snapshot(old_name, old_model), new_model.name))

    # Validation --------------------------------------------------------------
    def validate(self):
        models = {m.name: m for m in self.repo.list()}
        return validate_models(models)

    # Lifecycle ---------------------------------------------------------------
    def commit(self):
        issues = self.validate()
        if issues:
            raise ValueError("Validation failed:\n" + "\n".join(issues))

        # Build map of existing files with their full paths
        existing_files = {f.stem: f for f in self.repo.store.yaml_files()}
        current_names = set()

        # Write all models and detect primary tag changes
        for m in self.repo.list():
            name = m.name
            # Check if this is an update with a primary tag change
            if name in existing_files:
                old_path = existing_files[name]
                # Get expected new path based on current primary tag
                if m.tags and len(m.tags) > 0:
                    expected_subdir = m.tags[0]
                    expected_path = (
                        self.repo.store.root / expected_subdir / f"{name}.yml"
                    )
                else:
                    expected_path = self.repo.store.root / f"{name}.yml"

                # If primary tag changed, delete old file before writing new one
                if old_path.resolve() != expected_path.resolve():
                    try:
                        old_path.unlink()
                    except OSError:
                        pass

            self.repo.store.write(m)
            current_names.add(name)

        # Delete orphaned files (entries that no longer exist)
        for name in set(existing_files.keys()) - current_names:
            self.repo.store.delete(name)

        self._undo.clear()
        self.close()

    def rollback(self):
        while self._undo:
            op = self._undo.pop()
            if isinstance(op, UndoOpAdd):
                self.catalog.delete(op.name)
            elif isinstance(op, UndoOpDelete):
                self.catalog.insert(op.snap.model)
            elif isinstance(op, UndoOpUpdate):
                self.catalog.delete(op.snap.name)
                self.catalog.insert(op.snap.model)
            elif isinstance(op, UndoOpRename):
                self.catalog.delete(op.new_name)
                self.catalog.insert(op.old.model)
        self.close()

    # Granular undo ---------------------------------------------------------
    def undo_last(self) -> bool:
        """Undo only the most recent mutation.

        Returns True if an operation was undone, False if there was nothing to undo.
        Leaves the UnitOfWork open for further staging or eventual commit/rollback.
        Raises RuntimeError if the UnitOfWork is already closed.
        """
        if self._closed:
            raise RuntimeError("UnitOfWork is closed")
        if not self._undo:
            return False
        op = self._undo.pop()
        if isinstance(op, UndoOpAdd):
            self.catalog.delete(op.name)
        elif isinstance(op, UndoOpDelete):
            self.catalog.insert(op.snap.model)
        elif isinstance(op, UndoOpUpdate):
            self.catalog.delete(op.snap.name)
            self.catalog.insert(op.snap.model)
        elif isinstance(op, UndoOpRename):
            self.catalog.delete(op.new_name)
            self.catalog.insert(op.old.model)
        else:  # pragma: no cover - defensive programming
            raise RuntimeError(f"Unknown undo op: {op!r}")
        return True

    def close(self):
        if not self._closed:
            self._closed = True
            self.repo._end_uow()


__all__ = [
    "UnitOfWork",
    "Snapshot",
    "UndoOpAdd",
    "UndoOpDelete",
    "UndoOpUpdate",
    "UndoOpRename",
]
