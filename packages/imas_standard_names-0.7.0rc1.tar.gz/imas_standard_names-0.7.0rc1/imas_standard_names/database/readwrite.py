"""Writable in-memory SQLite catalog (authoring workflow)."""

from __future__ import annotations

import json
import logging
import os
import sqlite3
from collections.abc import Iterable

from ..models import StandardNameEntry
from .base import CatalogBase

DDL = [
    "PRAGMA foreign_keys=ON;",
    "CREATE TABLE standard_name ( name TEXT PRIMARY KEY, kind TEXT NOT NULL, status TEXT NOT NULL, unit TEXT, description TEXT NOT NULL, documentation TEXT, validity_domain TEXT, deprecates TEXT, superseded_by TEXT, is_dimensionless INTEGER NOT NULL DEFAULT 0 );",
    "CREATE TABLE provenance_operator ( name TEXT PRIMARY KEY REFERENCES standard_name(name) ON DELETE CASCADE, operator_chain TEXT NOT NULL, base TEXT NOT NULL, operator_id TEXT );",
    "CREATE TABLE provenance_reduction ( name TEXT PRIMARY KEY REFERENCES standard_name(name) ON DELETE CASCADE, reduction TEXT NOT NULL, domain TEXT NOT NULL, base TEXT NOT NULL );",
    "CREATE TABLE provenance_expression ( name TEXT PRIMARY KEY REFERENCES standard_name(name) ON DELETE CASCADE, expression TEXT NOT NULL );",
    "CREATE TABLE provenance_expression_dependency ( name TEXT NOT NULL REFERENCES provenance_expression(name) ON DELETE CASCADE, dependency TEXT NOT NULL REFERENCES standard_name(name), PRIMARY KEY(name,dependency) );",
    "CREATE TABLE tag ( name TEXT NOT NULL REFERENCES standard_name(name) ON DELETE CASCADE, tag TEXT NOT NULL, PRIMARY KEY(name,tag));",
    "CREATE TABLE link ( name TEXT NOT NULL REFERENCES standard_name(name) ON DELETE CASCADE, link TEXT NOT NULL, PRIMARY KEY(name,link));",
    "CREATE TABLE ids_path ( name TEXT NOT NULL REFERENCES standard_name(name) ON DELETE CASCADE, ids_path TEXT NOT NULL, PRIMARY KEY(name,ids_path));",
    "CREATE VIRTUAL TABLE fts_standard_name USING fts5(name UNINDEXED, description, documentation);",
]


logger = logging.getLogger("imas_standard_names.database")


def _configure_logging():  # lightweight, idempotent
    if getattr(_configure_logging, "_done", False):  # type: ignore[attr-defined]
        return
    level_name = os.getenv("IMAS_SN_LOG_LEVEL", "WARNING").upper()
    level = getattr(logging, level_name, logging.WARNING)
    logging.basicConfig(level=level, format="[%(levelname)s] %(name)s: %(message)s")
    _configure_logging._done = True  # type: ignore[attr-defined]


class CatalogReadWrite(CatalogBase):
    def __init__(self):
        _configure_logging()
        conn = sqlite3.connect(":memory:")
        super().__init__(conn)
        cur = self.conn.cursor()
        for stmt in DDL:
            cur.execute(stmt)
        self.conn.commit()
        logger.debug("Initialized in-memory writable catalog with schema")

    def load_models(self, models: Iterable[StandardNameEntry]):
        for m in models:
            self.insert(m)

    def _diagnose_fk(self) -> list[tuple[str, int, str, int]]:
        cur = self.conn.cursor()
        cur.execute("PRAGMA foreign_key_check;")
        rows = cur.fetchall()
        return [(r[0], r[1], r[2], r[3]) for r in rows]

    def insert(self, m: StandardNameEntry):
        logger.debug(
            "Inserting standard name '%s' (kind=%s)", m.name, getattr(m, "kind", "?")
        )
        c = self.conn.cursor()
        try:
            c.execute(
                "INSERT INTO standard_name(name,kind,status,unit,description,documentation,validity_domain,deprecates,superseded_by,is_dimensionless) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (
                    m.name,
                    getattr(m, "kind", ""),
                    getattr(m, "status", "draft"),
                    getattr(m, "unit", "") or None,
                    m.description,
                    getattr(m, "documentation", "") or None,
                    getattr(m, "validity_domain", "") or None,
                    getattr(m, "deprecates", "") or None,
                    getattr(m, "superseded_by", "") or None,
                    1 if getattr(m, "is_dimensionless", False) else 0,
                ),
            )
            prov = getattr(m, "provenance", None)
            if prov:
                mode = getattr(prov, "mode", None)
                if mode == "operator":
                    c.execute(
                        "INSERT INTO provenance_operator(name, operator_chain, base, operator_id) VALUES (?,?,?,?)",
                        (
                            m.name,
                            json.dumps(getattr(prov, "operators", [])),
                            getattr(prov, "base", None),
                            getattr(prov, "operator_id", None),
                        ),
                    )
                elif mode == "reduction":
                    c.execute(
                        "INSERT INTO provenance_reduction(name, reduction, domain, base) VALUES (?,?,?,?)",
                        (
                            m.name,
                            getattr(prov, "reduction", None),
                            getattr(prov, "domain", None),
                            getattr(prov, "base", None),
                        ),
                    )
                elif mode == "expression":
                    c.execute(
                        "INSERT INTO provenance_expression(name, expression) VALUES (?,?)",
                        (m.name, getattr(prov, "expression", None)),
                    )
                    for dep in getattr(prov, "dependencies", []):
                        c.execute(
                            "INSERT INTO provenance_expression_dependency(name, dependency) VALUES (?,?)",
                            (m.name, dep),
                        )
            for t in getattr(m, "tags", []) or []:
                c.execute("INSERT INTO tag(name, tag) VALUES (?,?)", (m.name, t))
            for link in getattr(m, "links", []) or []:
                c.execute("INSERT INTO link(name, link) VALUES (?,?)", (m.name, link))
            for ids_path in getattr(m, "ids_paths", []) or []:
                c.execute(
                    "INSERT INTO ids_path(name, ids_path) VALUES (?,?)",
                    (m.name, ids_path),
                )
            c.execute(
                "INSERT INTO fts_standard_name(name, description, documentation) VALUES (?,?,?)",
                (m.name, m.description, getattr(m, "documentation", "") or ""),
            )
            self.conn.commit()
        except sqlite3.IntegrityError as e:  # enhance FK diagnostics
            failed = self._diagnose_fk()
            if failed:
                details_lines = []
                for table, rowid, parent, fkid in failed:
                    ref_val = None
                    try:
                        if table == "vector_component":
                            r = self.conn.execute(
                                "SELECT vector_name, axis, component_name FROM vector_component WHERE rowid=?",
                                (rowid,),
                            ).fetchone()
                            if r:
                                ref_val = r[2]
                        elif table == "provenance_expression_dependency":
                            r = self.conn.execute(
                                "SELECT dependency FROM provenance_expression_dependency WHERE rowid=?",
                                (rowid,),
                            ).fetchone()
                            if r:
                                ref_val = r[0]
                    except Exception:  # pragma: no cover - best effort
                        pass
                    details_lines.append(
                        f"table={table} rowid={rowid} parent_table={parent} fkid={fkid}"
                        + (f" missing_ref='{ref_val}'" if ref_val else "")
                    )
                msg = (
                    f"Foreign key constraint failed while inserting '{m.name}'.\n"
                    + "\n".join(details_lines)
                    + "\nHint: This often means referenced dependency names were not inserted yet."
                )
                logger.error(msg)
                raise sqlite3.IntegrityError(msg) from e
            raise

    def get_row(self, name: str):
        return self.conn.execute(
            "SELECT * FROM standard_name WHERE name=?", (name,)
        ).fetchone()

    def list_rows(self):
        return self.conn.execute("SELECT * FROM standard_name").fetchall()

    def delete(self, name: str):
        c = self.conn.cursor()
        for table, col in [
            ("provenance_operator", "name"),
            ("provenance_reduction", "name"),
            ("provenance_expression_dependency", "name"),
            ("provenance_expression", "name"),
            ("tag", "name"),
            ("link", "name"),
            ("ids_path", "name"),
            ("fts_standard_name", "name"),
            ("standard_name", "name"),
        ]:
            c.execute(f"DELETE FROM {table} WHERE {col}=?", (name,))
        self.conn.commit()


__all__ = ["CatalogReadWrite", "DDL"]
