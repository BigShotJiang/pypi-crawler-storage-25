"""Knowledge Base service — full LLM Wiki implementation.

Based on the LLM-powered wiki pattern:
  raw/      — drop zone (user dumps files, agent processes + moves)
  library/  — organized archive (category/YYYY-MM/file)
  wiki/     — LLM-compiled articles with [[backlinks]]
    entities/  — person, organization, tool pages
    concepts/  — topic and concept pages
    sources/   — source summary pages
    .index.md  — content catalog
    .concepts.md — concept map
  output/   — generated reports, slides, charts
  SCHEMA.md — conventions, structure, workflows
  log.md    — chronological operation log

Rules:
- LLM is editor, not writer. Every sentence traces to a source.
- Gaps marked [TODO: ...], never hallucinated.
- Contradictions flagged explicitly.
- Incremental compilation — only new/changed sources processed.
- Tiered context loading — index first, then targeted reads.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import threading
import time
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.infra.job_registry import ProgressHandle
    from agntspace.llm.base import LLMProvider
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.writer import VaultWriter

# File-type registry — single source of truth for classify + extract +
# render (decisions.md §2026-04-18). Populated from bundled defaults at
# init; Phase 2 will augment from skill YAML + plugin hooks.
from agntspace.kb.file_types import ExtractResult, FileTypeRegistry
from agntspace.kb.file_types_defaults import build_default_registry, load_file_type_skills

log = logging.getLogger(__name__)

# All wiki subdirectories that may contain articles.
# `sources` and `source_summary` retained as legacy aliases during the
# 2026-04-27 sources→digests L1 rename transition; new vaults file at
# `digests/`. arch:deterministic — fixed wiki directory layout,
# structural invariant shared with VaultPaths resolver.
_WIKI_SUBDIRS = ("entities", "concepts", "digests", "sources", "source_summary", "synthesis", "decisions", "projects")  # arch:deterministic — fixed wiki directory layout, structural invariant shared with VaultPaths resolver


def _fresh_compile_state() -> dict:
    """Return an empty compile-state skeleton."""
    return {
        "last_ingest": None,
        "last_compile": None,
        "processed_hashes": {},
        "sources": {},
    }


class _EchoDetected(Exception):
    """Raised when a local-LLM extraction duplicates an existing source summary.

    Used to break out of nested loops in the ingest pipeline without leaking
    state. The outer handler quarantines the file and continues with the
    next inbox item.
    """


# ── Page templates per entity type ──
#
# Phase 4 (Rule 12) migration: templates previously lived as a 350-line
# Python dict at this location. They now live as individual .md files
# under ``defaults/skills/core/wiki-article-templates/templates/``.
# Each file is named ``{entity_type}.md`` and uses Python str.format()
# placeholders ({title}, {date}, etc.) for dynamic content.
#
# The loader below reads them via the SkillLoader (vault-first, then
# bundled defaults) and caches at the module level. A degraded-mode
# fallback provides a minimal concept template when the skill files
# are unavailable.

_TEMPLATES_CACHE: dict[str, str] | None = None

_CONCEPT_FALLBACK = """---
title: "{title}"
entity_type: concept
provenance: "{provenance}"
category: "{category}"
taxonomy_path: "{taxonomy_path}"
status: draft
sources: {sources}
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

# {title}

## Overview
[TODO: summary from sources]

## Open Questions
[TODO: what don't we know?]

## Sources
{source_list}
"""  # arch:deterministic -- minimal degraded-mode template when skill files are missing


def _load_article_templates(skill_loader: object | None = None) -> dict[str, str]:
    """Load per-entity-type article templates from the skill directory.

    Resolution order:
      1. Module-level cache (returned immediately if populated).
      2. ``wiki-article-templates`` skill's ``templates/`` directory
         via the SkillLoader. Each ``.md`` file becomes a key in the
         returned dict (filename stem = entity type).
      3. Degraded-mode fallback: a single ``concept`` template that
         matches the pre-Phase-4 hardcoded behavior for the most
         common entity type.

    The cache is cleared by ``invalidate_template_cache()`` for tests
    and hot-reload.
    """
    global _TEMPLATES_CACHE
    if _TEMPLATES_CACHE is not None:
        return _TEMPLATES_CACHE

    templates: dict[str, str] = {}

    # Try the skill loader path
    if skill_loader is not None and hasattr(skill_loader, "get_skill"):
        try:
            skill = skill_loader.get_skill("wiki-article-templates")
            if skill and skill.path:
                from pathlib import Path as _Path
                # skill.path is relative to skills_dir and points at SKILL.md
                skill_rel = _Path(skill.path)
                if skill_rel.name == "SKILL.md":
                    skill_rel = skill_rel.parent
                templates_dir = skill_loader._skills_dir / skill_rel / "templates"
                if templates_dir.is_dir():
                    for md_file in sorted(templates_dir.glob("*.md")):
                        entity_type = md_file.stem
                        templates[entity_type] = md_file.read_text(encoding="utf-8")
        except Exception:
            log.debug("kb: failed to load article templates from skill", exc_info=True)

    # Fallback: if nothing loaded, provide the concept template
    if not templates:
        templates["concept"] = _CONCEPT_FALLBACK

    _TEMPLATES_CACHE = templates
    return templates


def invalidate_template_cache() -> None:
    """Clear the article template cache. Tests call this between cases."""
    global _TEMPLATES_CACHE
    _TEMPLATES_CACHE = None


# Backwards-compat shim: code that references ``_TEMPLATES[entity_type]``
# still works because ``_load_article_templates()`` returns a dict with
# the same keys. The only call site (``_get_template``) is updated below.
# This comment exists so a grep for ``_TEMPLATES`` in this file finds it
# and understands the migration.



_SCHEMA_TEMPLATE = """---
title: "{topic} — Knowledge Base Schema"
type: kb_schema
author: user
library_layout: thematic
---

# {topic}

## Purpose
<!-- What is this knowledge base about? What questions should it answer? -->

## Conventions
- Every claim must trace to a source. No hallucinated content.
- Gaps marked with [TODO: ...] rather than invented filler.
- Articles use `[[Title]]` wikilinks for cross-references.
- Each article has frontmatter: title, entity_type, category, status, sources, author.
- Contradictions tracked in "Counter-Arguments & Data Gaps" sections.

## Entity Types
- **person** — people (wiki/entities/person-name.md)
- **organization** — companies, institutions (wiki/entities/org-name.md)
- **concept** — topics, ideas, methods (wiki/concepts/concept-name.md)
- **source_summary** — per-source summary (wiki/sources/filename.md)
- **synthesis** — cross-source analysis, insights connecting multiple sources (wiki/synthesis/slug.md)
- **decision_record** — structural decisions about wiki organization (wiki/decisions/slug.md)

## Status Values
- **draft** — auto-generated, not yet verified
- **verified** — human-reviewed and confirmed
- **stale** — may be outdated by newer sources

## Structure
- `inbox/` — drop zone for new source files
- `library/` — organized sources (agent-maintained)
- `wiki/entities/` — entity pages (people, organizations)
- `wiki/concepts/` — concept and topic pages
- `wiki/sources/` — source summary pages
- `wiki/synthesis/` — cross-source analysis and insights
- `wiki/decisions/` — structural decision records (why the wiki is shaped this way)
- `wiki/projects/` — project-scoped knowledge (project-specific entities, concepts, notes)
- `output/` — research outputs, reports, slides

## Project Scoping
When sources are project-specific, articles go to `wiki/projects/<project-slug>/`.
Each project gets an overview page at `wiki/projects/<project-slug>/<project-slug>.md`.
Global knowledge stays in top-level categories. Project articles link to global ones via wikilinks.

## Article Sections (required)
Every article must include:
- Summary paragraph after the title
- Key content sections
- **Open Questions** — what we don't know yet about this topic
- **Sources** — links to source files

## Notes
<!-- Domain-specific instructions for the agent -->
"""

_INDEX_TEMPLATE = """---
title: "{topic} — Index"
type: kb_index
author: agent
agent: librarian
updated: "{date}"
source_count: 0
article_count: 0
---

# {topic} — Knowledge Base

## Sources

<!-- Each source: link, one-line summary, date ingested -->

## Entities

<!-- Entity pages: [[link]] — one-line description -->

## Concepts

<!-- Concept pages: [[link]] — one-line description -->

## Statistics
- Sources ingested: 0
- Entity pages: 0
- Concept pages: 0
- Last updated: {date}
"""

# ── Source type classification ──

_SOURCE_TYPES = {
    "paper": {"exts": {".pdf"}, "prompt_focus": "Extract thesis, methodology, key findings, citations. Academic rigor."},
    "article": {"exts": {".md", ".html", ".htm", ".txt", ".rst"}, "prompt_focus": "Extract main arguments, key facts, quotes, author perspective."},
    "data": {"exts": {".csv", ".tsv", ".yaml", ".yml"}, "prompt_focus": "Describe the data structure, key fields, notable patterns, size."},
    "chat_history": {"exts": {".jsonl"}, "prompt_focus": "Extract key decisions, insights, topics discussed, action items from this conversation."},
    "export": {"exts": {".json"}, "prompt_focus": "Extract key topics, decisions, people mentioned, and actionable insights."},
    "transcript": {"exts": {".vtt", ".srt"}, "prompt_focus": "Extract key discussion points, decisions made, action items, attendees mentioned."},
    "code": {"exts": {".py", ".js", ".ts"}, "prompt_focus": "Describe purpose, key functions, architecture, dependencies."},
    "image": {"exts": {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp"}, "prompt_focus": "Describe what the image shows, any text/labels visible, context."},
}

_CLASSIFY_PROMPT_FALLBACK = """Classify this source document and extract information.

Source file: {filename}
Source type: {source_type}
Type-specific focus: {type_focus}

IMPORTANT: The body text may start with ads, navigation, or sidebar content captured by
web clippers. Use the SOURCE METADATA (title, description, URL) to determine the article's
TRUE topic. Ignore unrelated noise at the start of the body.

KB Schema:
{schema}

Existing wiki index (what's already in the KB — for DEDUP ONLY):
{index}

RULES:
- Every fact must trace to the source text. Do NOT invent information.
- If something is unclear, write [TODO: clarify from source].
- Note any contradictions with the existing wiki index.
- Use the frontmatter title/description as the authoritative topic — not the first line of body text.
- ANTI-CONTAMINATION: The "Existing wiki index" above is for dedup only — so you can suggest UPDATE instead of CREATE. Do NOT copy concept or entity names from that list into the concepts, entities, or summary blocks unless the concept is EXPLICITLY DISCUSSED in the source content.

Produce:

```summary
(3-5 sentence summary of the source, citing specific details)
```

```concepts
(ONLY concepts explicitly discussed or depicted in the source content.
Do NOT tag the source with existing KB concepts not present in this source.)
- concept1
- concept2
```

```entities
(ONLY people/orgs named and described in the source content.)
- person: Name — role/description
- organization: Org Name — what they do
```

```contradictions
(any facts that contradict existing wiki content, or "none found")
```

```wiki_updates
List ONLY entities and concepts that are SIGNIFICANT to this source — not every noun mentioned.

Significance test: would someone search for this concept to understand the source's domain?
- YES: a named methodology explained in the source, a person with a described role
- NO: generic terms, passing mentions, concepts from the existing wiki index that this source does not discuss

CREATE sparingly. Prefer UPDATE to existing pages. Maximum 5 CREATE lines per source.

Format:
- CREATE entities/person-slug: Full name and role | REASON: why this person matters
- CREATE entities/org-slug: Organization name | REASON: significance to the domain
- CREATE concepts/topic-slug: What this concept is about | REASON: why it deserves its own page
- UPDATE concepts/existing-slug: What new info to add from this source
```

```bibliography
- title: (exact title of the work — not the filename)
- authors: (comma-separated list of authors, or "unknown")
- date: (publication date YYYY-MM-DD or YYYY, or "unknown")
- publisher: (journal, conference, website, publisher name, or "unknown")
- doi: (DOI if visible, or "")
```"""

_COMPILE_PROMPT_FALLBACK = """You are a knowledge base wiki compiler.

KB SCHEMA:
{schema}

WIKI INDEX:
{index}

KNOWLEDGE TAXONOMY (assign each article a taxonomy_path from this tree):
{taxonomy}

EXISTING ARTICLES (summaries):
{existing_articles}

NEW SOURCES TO PROCESS:
{sources}

VALID SUBDIRECTORIES — V3 LAYOUT (7 fixed L1 buckets — subdir prefix MUST equal taxonomy_path prefix):
- entities/people/ — INDIVIDUAL HUMANS only (entity_type=person)
- entities/organizations/ — companies, agencies, universities, NGOs (entity_type=organization)
- entities/places/ — countries, cities, sites (entity_type=place)
- entities/products/ — apps, tools, books, devices (entity_type=thing)
- entities/events/ — meetings, conferences, incidents (entity_type=event)
- knowledge/{{leaf}}/ — durable subject knowledge (entity_type=concept). leaf ∈ {{science, engineering, technology, business, society, humanities, risk-safety}}
- digests/{{leaf}}/ — per-source summaries (entity_type=digest, ingest creates these)
- reference/{{leaf}}/ — reusable structured material (entity_type=concept|document). decisions go in reference/decisions/.
- workflows/{{leaf}}/ and areas/{{leaf}}/ and projects/{{leaf}}/ — rare for compile.

LEGACY PATHS (concepts/, synthesis/, sources/, decisions/ at the L1 root) ARE FORBIDDEN. The engine rewrites them to v3 but logs a warning each time. Always emit v3 paths directly.

CANONICAL TITLE RULE — strip dates/qualifiers from titles. "Möte med Tony" not "Möte med Tony (2025-11-17 1430)". Date goes in the body + date_created frontmatter, not the title. Otherwise every compile pass creates a duplicate article.

RULES — CRITICAL:
1. You are an EDITOR, not a writer. Every sentence must trace to a source.
2. NEVER invent information. If data is missing, write [TODO: ...].
3. Use [[wiki-links]] generously for cross-references.
4. Flag contradictions explicitly in a "Counter-Arguments & Data Gaps" section.
5. Include [Source: filename] citations for every claim.
6. Use ONLY V3 subdirs above. Meetings → entities/events/, concepts → knowledge/{{leaf}}/, syntheses → knowledge/{{leaf}}/ (with provenance: compiled), decisions → reference/decisions/. NEVER use concepts/, synthesis/, sources/, or decisions/ as L1.
7. ALWAYS include taxonomy_path in frontmatter — pick the most specific matching node from the taxonomy. The taxonomy_path MUST agree with the entity_type AND the subdir per the pairing table (mirror rule).
8. WRITE FULL CONTENT — not stubs. Extract ALL available information from the sources into article sections. A person page must include their role, affiliations, contributions. A concept page must explain what it is, how it works, where it's used. Only use [TODO: ...] for information genuinely absent from the sources.
9. UPDATE existing articles that are stubs (mostly [TODO] placeholders). Fill them with real content from sources.
10. Include an "Open Questions" section listing what the sources don't answer.
11. Deduplicate: do NOT create new articles for entities/concepts that already have pages. Use the EXISTING slug. For recurring meetings/reviews, ONE article — append occurrences as `## YYYY-MM-DD HH:MM` sections in the body.
12. QUALITY OVER QUANTITY. Only create articles for concepts that are CENTRAL to the sources — not every term mentioned. A concept article should have at least 3 sentences of real content. If you can't write 3 sourced sentences about it, it's not worth an article. Maximum 10 new articles per compile pass.

Output format — for each article (new OR updated stub):
```article:{{subdir}}/{{slug}}
---
title: "Article Title"
entity_type: "person|organization|concept|event|place|document|decision|thing"
category: "category-name"
taxonomy_path: "parent-slug/child-slug"
status: draft
related: ["other-slug"]
sources: ["source1.md"]
source_count: 1
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

(FULL article content with [[wiki-links]] and [Source: file] citations — NOT stubs)

## Open Questions
(what the sources don't tell us)

## Counter-Arguments & Data Gaps
(contradictions, unknowns)
```

After all entity/concept articles, if 2+ sources connect in a non-obvious way, create a SYNTHESIS page:
```article:synthesis/{{slug}}
---
title: "Synthesis: descriptive title"
entity_type: synthesis
category: "cross-source"
taxonomy_path: "relevant/path"
status: draft
related: ["entity-or-concept-1", "entity-or-concept-2"]
sources: ["source1.md", "source2.md"]
source_count: 2
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

(Cross-source insight — what do these sources reveal TOGETHER that neither says alone?)

## Connections
(how the sources relate)

## Implications
(what this means for the domain)

## Open Questions
(what this cross-reference raises but doesn't answer)
```

Only create synthesis pages when there is a genuine cross-source insight. Do NOT create them for trivial overlaps (same person mentioned in 2 sources is NOT a synthesis — that's just an entity page).

After all articles:
```concepts
## Category Name
- [[Concept One]] — brief description [Source: file]
```"""

_RESEARCH_OUTPUT_FORMATS = {  # arch:deterministic — output format templates for KB research; structural framing, not content strategy
    "markdown": "",  # default — no extra instruction, uses wiki article format
    "comparison": (
        "OUTPUT FORMAT: Comparison Table.\n"
        "Structure your answer as a markdown table comparing the relevant entities/concepts side by side.\n"
        "Use columns for each entity and rows for each comparison dimension.\n"
        "Include a brief analysis paragraph after the table summarizing key differences and similarities.\n"
        "Cite sources in each cell with [Source: file]."
    ),
    "slides": (
        "OUTPUT FORMAT: Marp Slide Deck.\n"
        "Structure your answer as a Marp-compatible markdown presentation.\n"
        "Start with:\n```\n---\nmarp: true\ntheme: default\npaginate: true\n---\n```\n"
        "Use `---` to separate slides. Each slide should have:\n"
        "- A clear heading (# or ##)\n"
        "- 3-5 bullet points maximum\n"
        "- Speaker notes in HTML comments <!-- notes --> where useful\n"
        "Aim for 5-10 slides covering: title, overview, key findings, details, conclusions.\n"
        "Keep text concise — slides are for presenting, not reading.\n"
        "Cite sources on a final 'References' slide."
    ),
    "briefing": (
        "OUTPUT FORMAT: Executive Briefing.\n"
        "Structure your answer as a concise executive briefing:\n"
        "1. **Bottom Line Up Front (BLUF)** — 1-2 sentence answer\n"
        "2. **Key Facts** — 3-5 bullet points with the essential data\n"
        "3. **Context** — 1 short paragraph of background\n"
        "4. **Implications** — what this means, what to watch\n"
        "5. **Sources** — numbered reference list\n"
        "Total length: under 500 words. Every fact cited with [Source: file]."
    ),
}

_RESEARCH_PROMPT_FALLBACK = """You are a knowledge base research assistant.

KB SCHEMA:
{schema}

WIKI ARTICLES:
{context}

QUESTION:
{query}

RULES:
- Answer using ONLY wiki content. Cite articles: [See: Article Title]
- If the wiki lacks information, say exactly what's missing.
- Use [[wiki-links]] for concepts.
- Never invent facts not in the wiki.
- Mark uncertainties with [Unverified] or [TODO: needs source].

{output_instruction}"""

_REFLECT_PROMPT_FALLBACK = """You are a knowledge base structural analyst. The wiki must understand its own shape — not just what it knows, but WHY it knows things that way.

WHAT JUST CHANGED:
- Articles created: {articles_created}
- Files ingested: {files_ingested}

RECENTLY CREATED/MODIFIED ARTICLES (full content):
{recent_articles}

FULL WIKI STATE (titles and types):
{existing_articles}

KB SCHEMA:
{schema}

Analyze with these questions:
1. **Why were these articles created this way?** — What framing was chosen? Was "bowtie analysis" categorized as a concept rather than a process? Was a person filed globally rather than under a project? What alternatives existed?
2. **What got connected and what didn't?** — Which sources drove which articles? Are there obvious connections the compile missed?
3. **Ingestion bias** — Are early sources over-represented as hubs? Is the wiki shaped by what was ingested first rather than what matters most?
4. **Blind spots** — Topics the domain clearly requires but the wiki lacks. Questions the wiki should answer but can't.
5. **Structural debt** — Taxonomy mismatches, concepts that should be merged, entities that should be split.

RULES:
- Only create decision records for SIGNIFICANT structural choices — not routine additions.
- Each decision record must explain what ALTERNATIVE framing was possible and WHY this one was chosen.
- Be brutally honest. The point is to catch biases, not confirm choices.
- If nothing significant happened, say so.

Output format — ONLY if there are significant decisions:
```decision
title: Short decision title
decision: What was decided
context: What triggered this
alternatives: What other approaches were possible
reasoning: Why this choice
consequences: What this means going forward
affects: article-slug-1, article-slug-2
```

If no significant decisions were made, output:
```no_decisions
Routine update — no structural decisions to record.
```"""

_CONSOLIDATE_PROMPT_FALLBACK = """You are rewriting a wiki article that has accumulated incremental updates over time.

The article below contains the original content plus multiple "Updated from compile" sections appended at different dates. Your job is to merge everything into a single coherent, well-structured article.

Rules:
1. Preserve ALL factual content — do not lose any information from any update
2. Resolve contradictions: newer information supersedes older (use the dates to determine recency)
3. Remove the "Updated from compile" markers and date stamps — integrate the content naturally
4. Maintain the original structure (sections, headers) but reorganize if the updates make it clearer
5. Keep all [[wikilinks]] intact
6. Keep all [Source: ...] citations intact
7. Mark any remaining gaps with [TODO: ...]
8. Preserve the writing style and tone of the original
9. Output ONLY the consolidated article body (no frontmatter, no fences)"""

_LINT_PROMPT_FALLBACK = """You are a knowledge base health checker performing a deep wiki audit.

KB SCHEMA:
{schema}

WIKI INDEX:
{index}

STRUCTURAL ISSUES (pre-computed from file analysis — already verified):
{structural_issues}

ARTICLES (full content for semantic analysis):
{articles}

Your job is the SEMANTIC analysis. The structural issues above are already confirmed.
Focus on what only an LLM can detect:

1. **Contradictions** — conflicting facts across articles (same entity, different claims)
2. **Stale claims** — information that newer sources have likely superseded
3. **Missing cross-references** — related articles that should link to each other but don't
4. **Important concepts without pages** — ideas mentioned repeatedly across articles that deserve their own page
5. **Data gaps** — important questions the KB should answer but doesn't, topics that could be filled with a web search
6. **Unsourced claims** — statements not traced to any source file
7. **Quality issues** — articles that are mostly [TODO] placeholder text, or very thin compared to available sources

Output:
```issues
- [contradiction] Article "A" says X but Article "B" says Y
- [stale] Article "X" claim about Y may be outdated — check against newer sources
- [unsourced] Article "X" claims Y without citing a source
- [quality] Article "X" is mostly placeholder text (N TODOs, only M sentences of real content)
```

```suggestions
- [new_article] "Title" — mentioned in articles X, Y, Z but has no dedicated page
- [new_link] Article "A" should cross-reference [[B]] — they discuss related topics
- [investigate] "Question?" — researching this would fill a gap in the KB
- [web_search] "Search query" — this information gap could likely be filled with a web search
- [verify] Claim in "X" should be cross-checked — it may conflict with "Y"
- [merge] Articles "A" and "B" cover the same topic and should be consolidated
```"""


class IngestFrozenError(RuntimeError):
    """Raised when ``KnowledgeBaseService.ingest()`` is called while the global
    pipeline freeze flag is set.

    This is a SHORT-CIRCUIT — the call never enters the per-file extraction
    loop, never touches the LLM, never moves files. Callers should:

      * **Work queue retries** → catch + re-queue with extended backoff. The
        freeze WILL lift eventually; queued work must not be dead-lettered.
      * **HTTP / agent / drag-drop entry points** → return 423 Locked or
        equivalent so the user sees an honest "frozen" reason, not a silent
        no-op.
      * **Watcher** → already short-circuits via ``is_paused()`` for its own
        reasons; the freeze gate at ``ingest()`` catches anything that slips
        past the watcher's pause check.

    Distinct from ``watcher.paused`` (which only stops auto-discovery). Freeze
    is the global "no ingestion ever, period" emergency lever.
    """


class KnowledgeBaseService:
    """Manages personal knowledge bases — full LLM Wiki implementation."""

    def __init__(
        self,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        llm: LLMProvider,
        skills_dir: Path | None = None,
        skill_loader: object | None = None,
        model_router: object | None = None,
        bibliography: object | None = None,
        work_queue: object | None = None,
    ) -> None:
        self._reader = vault_reader
        self._vault = vault_reader  # alias used by taxonomy override + attachment URL resolution
        self._writer = vault_writer
        self._llm = llm
        self._skills_dir = skills_dir
        self._skill_loader = skill_loader
        self._model_router = model_router
        self._bibliography = bibliography
        self._work_queue = work_queue
        self._orchestrator: object | None = None  # injected post-hoc for activity tracking
        self._activity: object | None = None  # injected post-hoc by main.py
        self._decisions: object | None = None  # DecisionLogger, injected by main.py
        self._graph: object | None = None  # KnowledgeGraph, injected by main.py
        self._contract: object | None = None  # ContractEnforcer, injected by main.py
        self._error_logger: object | None = None  # ErrorLogger, injected by main.py — captures tracebacks for /logs page
        self._settings_service: object | None = None  # SettingsService, injected by main.py — backs is_pipeline_frozen()
        # When True, LLM failures raise instead of enqueuing (work queue handles retries)
        self._called_from_queue = False
        # Per-retry escalation state — set by the work queue handler before
        # re-entering `_do_ingest`. Read once and honored for the matching
        # file, then cleared. Parallel to `_language_drift_escalation` so the
        # retry reason stays clear in logs and source_meta flags.
        self._empty_extraction_escalation: dict | None = None
        # Per-KB locks to prevent concurrent ingest (watcher + API racing)
        self._ingest_locks: dict[str, asyncio.Lock] = {}
        # File-type registry — the extraction contract (decisions.md §2026-04-18,
        # revised). Built from bundled defaults at init, then augmented from
        # per-type skill YAMLs (Phase 2 — `defaults/skills/file-types/*/config/file-type.yaml`
        # plus user vault overrides in `system/skills/file-types/`). Plugins
        # register further via ``kb_service._file_types.register_extractor(...)``
        # in their async_init.
        #
        # Precedence (last registration wins because loader passes overwrite=True):
        #   1. Bundled Python defaults (this file's DEFAULT_SPECS)
        #   2. Shipped skill YAMLs (defaults/skills/file-types/)
        #   3. User vault skill YAMLs (system/skills/file-types/ — SkillLoader
        #      scans these as part of its normal skill tree discovery)
        #   4. Plugins that register with overwrite=True
        self._file_types: FileTypeRegistry = build_default_registry()
        if self._skill_loader is not None:
            try:
                load_file_type_skills(self._file_types, self._skill_loader)
            except Exception:
                log.debug("file-types skill loader failed at init", exc_info=True)

        # Per-batch consecutive-crash counter. Bug-class exceptions
        # (AttributeError, NameError, ImportError) trip the circuit at 3;
        # transient failures (timeout, HTTP, rate-limit) trip at 10. The
        # safety net resets the counter on any successful file in the same
        # batch (success means the path works). Cleared at start of each
        # _do_ingest_body. See `_classify_crash` + the safety net at
        # the bottom of the per-file loop for the actual logic.
        self._consecutive_crash_counts: dict[str, int] = {}

        # arch:short-ttl-cache — Phase 0.1 (2026-05-04). The most-called
        # endpoint by far re-walks every KB folder (~1 s on a 3-KB / 1700-
        # article vault). Every page load hits 2-3 cards that need this list,
        # so caching saves multiple seconds of cumulative event-loop time
        # per navigation. TTL is short (30 s) AND we invalidate explicitly
        # on every mutation that could change the result (create/delete/
        # rename + ingest/compile completion that changes article + source
        # counts). Mutations win immediately; the TTL is just the safety net
        # for missed invalidations. Lock prevents N concurrent first-callers
        # from each running the FS walk in parallel under GIL contention.
        self._kb_list_cache: list[dict] | None = None
        self._kb_list_cache_at: float = 0.0
        self._kb_list_cache_ttl: float = 30.0
        self._kb_list_cache_lock: threading.Lock = threading.Lock()
        # In-memory pub/sub for cache invalidation downstream — the
        # route layer (which owns wiki_stats / article caches) registers
        # callbacks here so ingest/compile completion in the background
        # also fires the route caches. Plain list of zero-arg callables;
        # exceptions in subscribers are swallowed so a broken subscriber
        # never breaks the kb path. Mirrors a 1-method pub/sub bus.
        self._invalidation_subscribers: list[callable] = []

    # Bug-class exceptions = code is broken, retry won't help. Anything not
    # in this tuple is treated as transient (LLM timeout, HTTP error, dedup
    # collision, etc.) and gets a higher circuit-breaker threshold.
    _BUG_CLASS_EXCEPTIONS: tuple[type[BaseException], ...] = (  # arch:deterministic — Python builtin error types tied 1:1 to runtime semantics; not strategy
        AttributeError,
        NameError,
        ImportError,
        ModuleNotFoundError,
        IndentationError,
        SyntaxError,
    )
    _BUG_CLASS_THRESHOLD: int = 3  # arch:deterministic — circuit-breaker safety threshold; this is structural protection (halt after N consecutive identical bug-class crashes), not user strategy. Tuning belongs to operators not skill authors.
    _TRANSIENT_THRESHOLD: int = 10  # arch:deterministic — same rationale; bounded retries before halt so a flaky LLM doesn't churn the queue forever.

    @classmethod
    def _classify_crash(cls, exc: BaseException) -> str:
        """Return ``"bug"`` for code-broken exceptions, ``"transient"`` otherwise.

        Used by the per-file safety net to (a) tag the activity event /
        decision row so the user can filter by class, (b) pick the right
        circuit-breaker threshold (bug-class trips faster).
        """
        return "bug" if isinstance(exc, cls._BUG_CLASS_EXCEPTIONS) else "transient"

    # Required dependencies that must be wired before the service is
    # usable. Listed explicitly so a missing assignment fails LOUDLY at boot
    # instead of silently at first ingest (which is what the 2026-04-27
    # `_vault` bug did — 200 files crashed with AttributeError before the
    # user noticed). Constructor params are checked separately from
    # post-init injection. The arch test in tests/arch/test_service_wiring.py
    # AST-scans the class body and fails CI if a NEW `self._X` reference
    # is added without being either set in __init__ or listed here.
    _REQUIRED_INIT_ATTRS: tuple[str, ...] = (  # arch:deterministic — dependency-injection contract; identifiers are Python attribute names, not strategy. Used by validate_wiring() and tests/arch/test_service_wiring.py.
        "_reader", "_vault", "_writer", "_llm",
    )
    _REQUIRED_INJECTED_ATTRS: tuple[str, ...] = (  # arch:deterministic — same as _REQUIRED_INIT_ATTRS; lists the post-hoc attrs main.py wires after construction.
        "_decisions",      # captures per-file ingest decisions
        "_graph",          # populates entities/triples
        "_contract",       # authorizes writes inside scope
        "_activity",       # emits activity events
        "_error_logger",   # surfaces tracebacks to /logs
    )

    def validate_wiring(self) -> None:
        """Raise RuntimeError if a required dependency wasn't wired.

        Called once from main.py after all post-init injection completes.
        Replaces the silent-crash-at-first-use failure mode with a loud
        boot-time error that names the missing attribute.
        """
        missing_init = [
            a for a in self._REQUIRED_INIT_ATTRS
            if not hasattr(self, a) or getattr(self, a) is None
        ]
        if missing_init:
            raise RuntimeError(
                f"KnowledgeBaseService.__init__ failed to set: {missing_init}. "
                "Code references these throughout the ingest path; without "
                "them every ingest crashes silently in the per-file safety "
                "net. Check the constructor."
            )
        missing_injected = [
            a for a in self._REQUIRED_INJECTED_ATTRS
            if getattr(self, a, None) is None
        ]
        if missing_injected:
            raise RuntimeError(
                f"KnowledgeBaseService missing post-init dependencies: "
                f"{missing_injected}. main.py must inject these after "
                "constructing the service. Without them the observability + "
                "contract layers degrade silently."
            )

    def _resolve(self, relative_path: str) -> Path:
        """Resolve a logical vault path to a physical Path.

        Delegates to VaultPaths if available, otherwise falls back to
        vault_dir / relative_path.
        """
        if self._reader.paths:
            return self._reader.paths.resolve(relative_path)
        return self._reader._vault_dir / relative_path

    def _to_logical(self, physical_path: Path) -> str:
        """Convert a physical path back to a logical vault-relative path."""
        if self._reader.paths:
            return self._reader.paths.to_logical(physical_path)
        return str(physical_path.relative_to(self._reader._vault_dir)).replace("\\", "/")

    def _load_skill_rules(self, skill_name: str) -> str:
        """Load quality rules from a skill's SKILL.md body.

        Returns the "## Quality Rules" section (and below) if found, empty string otherwise.
        """
        if not self._skills_dir:
            return ""
        skill_path = self._skills_dir / "core" / skill_name / "SKILL.md"
        if not skill_path.exists():
            return ""
        try:
            import frontmatter as fm
            post = fm.load(str(skill_path))
            content = post.content
            # Extract from "## Quality Rules" onward (skip instructions, include rules)
            marker = "## Quality Rules"
            idx = content.find(marker)
            if idx >= 0:
                return content[idx:]
            return ""
        except Exception:
            return ""

    def _get_skill_prompt(self, skill_name: str) -> str:
        """Load system prompt from skill definition via SkillLoader.

        Falls back to empty string if the skill loader is unavailable or
        the skill has no System Prompt section.
        """
        if not self._skill_loader:
            return ""
        try:
            prompt = self._skill_loader.get_system_prompt(skill_name)
            return prompt or ""
        except Exception:
            return ""

    def _get_skill_rules(self, skill_name: str) -> str:
        """Load quality rules from skill definition via SkillLoader.

        Falls back to the legacy ``_load_skill_rules`` method if the
        skill loader is unavailable.
        """
        if self._skill_loader:
            try:
                rules = self._skill_loader.get_skill_rules(skill_name)
                if rules:
                    return rules
            except Exception:
                pass
        return self._load_skill_rules(skill_name)

    def _resolve_model(self, tier: str) -> str | None:
        """Resolve a model tier to a specific model via the router. Returns None if no router."""
        if self._model_router and hasattr(self._model_router, "resolve"):
            return self._model_router.resolve(tier)
        return None

    async def _feedback_context_for_articles(
        self, slugs: list[str], *, max_total_chars: int = 4000,
    ) -> str:
        """Phase 8 (2026-04-30) — render open user feedback for the given
        article slugs into a single string for inclusion in the LLM
        system prompt.

        Returns empty string when:
          - The wiki feedback service isn't wired (legacy / minimal install)
          - The feedback feature is disabled via YAML
          - No open feedback exists for any of the provided slugs

        The total rendered length is bounded by ``max_total_chars`` so a
        single article with hundreds of open feedback rows can't blow up
        the LLM prompt budget. Per-article budget = max_total_chars / N.
        """
        feedback_svc = getattr(self, "_wiki_feedback", None)
        if feedback_svc is None or not slugs:
            return ""

        rendered_parts: list[str] = []
        per_slug_budget = max(200, max_total_chars // max(1, len(slugs)))
        for slug in slugs:
            try:
                snippet = await feedback_svc.render_agent_prompt(slug)
            except Exception:
                continue  # broken renderer must NEVER break compile/synthesize
            if not snippet:
                continue
            if len(snippet) > per_slug_budget:
                snippet = snippet[: per_slug_budget - 1] + "…"
            # Prefix with the slug so the LLM knows WHICH article each
            # block of feedback applies to.
            rendered_parts.append(f"## Feedback for `{slug}`\n{snippet}")

        if not rendered_parts:
            return ""

        body = "\n\n".join(rendered_parts)
        return (
            "\n\n# Open user feedback\n"
            "The user flagged the following articles as needing fixes. "
            "Address these notes in your regeneration; do not produce the same "
            "wrong content again.\n\n"
            f"{body}"
        )

    def _is_local_mode(self) -> bool:
        """True when the active model router is configured for local (Ollama) mode."""
        return bool(
            self._model_router
            and getattr(self._model_router, "_profile", "") == "local"
        )

    # ── Timeout-retry policy (used by ingest classify) ────────────────
    #
    # When the classify LLM call hits ``asyncio.TimeoutError``, we no
    # longer quarantine immediately. Instead we enqueue a retry through
    # the work queue with the next tier in this ladder, up to N total
    # attempts (initial + N-1 retries). After exhausting the ladder, the
    # file is quarantined with a rich reason listing every tier tried.
    #
    # The asymmetry being fixed: a non-timeout exception already enqueued
    # through the work queue with infinite exponential backoff. Timeout —
    # the most common transient failure — was the only mode that quarantined
    # on the first try. This made every cloud blip a permanent data loss.
    #
    # Tier escalation rationale: most "timeouts" on a small-input request
    # are model overload, not actual compute exhaustion. Switching tier
    # routes to a different model (different queue depth, different load)
    # often resolves them faster than waiting on the original.
    _TIMEOUT_RETRY_TIERS: tuple[str, ...] = ("fast", "capable", "reasoning")  # arch:deterministic — ModelRouter tier identifiers in escalation order, not classification strategy
    _TIMEOUT_MAX_ATTEMPTS: int = 3  # initial + 2 retries

    def _llm_timeout(self, op: str, default: int | None = None) -> float:
        """Per-operation LLM timeout. Local models are slower, so local gets
        generous timeouts. Cloud gets tight timeouts to fail fast and retry.

        Local-mode budgets bumped 2026-04-26 — the old 180s classify ceiling
        was tight for the ``capable`` tier (often a 14B model on CPU) and
        triggered spurious quarantines. Combined with the new tier-escalation
        retry path (TimeoutError now enqueues a retry instead of going
        straight to quarantine), the longer per-call budget reduces the
        retry fanout without increasing tail latency for the user.

        `default` is a fallback when `op` isn't in the budget map — lets new
        operations be added without touching this method.
        """
        local = self._is_local_mode()
        # operation → (local_seconds, cloud_seconds)
        budget = {
            "classify":   (300, 120),  # was (180, 90); local capable models need headroom
            "compile":    (420, 240),  # was (300, 180); compile reads many sources
            "synthesize": (420, 180),  # was (300, 120)
            "reflect":    (300, 120),  # was (180, 90)
            "research":   (420, 180),  # was (300, 120)
            "lint":       (420, 180),  # was (300, 120)
            "consolidate":(360, 180),  # was (240, 120)
        }
        fallback_pair = (default, default) if default is not None else (300, 120)
        loc, cld = budget.get(op, fallback_pair)
        return float(loc if local else cld)

    # ── Observability helpers (Rule #13: every ingest step is visible) ──
    #
    # Every KB ingest path (watcher, API, work queue, tool) runs through
    # _do_ingest and MUST emit:
    #   1. an ActivityLogger event (category=knowledge) so the agent sees
    #      the work in get_daily_summary() / get_relationship_context()
    #   2. a DecisionLogger record (actor=librarian) so the causal chain
    #      is reconstructable from the /decisions page
    #   3. knowledge-graph entities/triples so the ingested source becomes
    #      queryable structured knowledge, not just a markdown artefact
    # These helpers centralise the fire-and-forget pattern so call sites
    # stay readable. All three are non-fatal: a broken observability layer
    # must never break ingest.

    @asynccontextmanager
    async def _scoped_pipeline(self, reason: str, scope_prefix: str = "kb"):
        """Context manager that wraps a KB service method body with the
        full observability + governance stack:

          1. Inherit an outer correlation scope if we're nested inside
             one (chat turn, workflow, HTTP request). Otherwise start a
             fresh ``{scope_prefix}-xxx`` chain.
          2. Authorize the ``write_vault`` + ``modify_wiki`` contract
             actions inside the scope, going through ``contract.check()``
             when a ContractEnforcer is wired, falling back to
             ``mark_action_authorized`` for tests.
          3. Apply a scope-wide ``trusted_scope(reason)`` on the writer
             so every vault write inside inherits ``trust_reason=reason``
             without having to thread kwargs through dozens of call
             sites.

        Every public KB service method that writes to the vault
        (``ingest``, ``compile_wiki``, ``reflect``, ``research``,
        ``synthesize``, ``lint``, ``run_wiki_job``) routes its body
        through this helper. Adding a new method that writes to the
        vault? Wrap it too — the runtime guard will reject every write
        otherwise (Rule #3 "Contract is the law" made enforceable in
        code, not convention).
        """
        from agntspace.activity.decisions import (
            correlation_scope,
            current_correlation_id,
            new_correlation_id,
        )

        _existing = current_correlation_id()
        _scope = correlation_scope(_existing or new_correlation_id(scope_prefix))
        with _scope, self._writer.trusted_scope(reason):
            self._authorize_ingest_scope()
            yield

    def _authorize_ingest_scope(self) -> None:
        """Authorize the vault writes this ingest batch will make.

        Every ``correlation_scope`` starts with an empty authorized-actions
        set, so the VaultWriter runtime guard will reject unscoped writes.
        The canonical way to grant permission is to call
        ``contract.check(action)`` which marks the action authorized on
        success. When there's no contract (tests, minimal installs) we
        fall back to ``mark_action_authorized`` directly so the writer
        guard still sees the scope as green.

        Actions authorized here match what the pipeline actually does:
          - ``write_vault`` — source summaries, index, wiki article writes
          - ``modify_wiki`` — in-place updates to existing wiki articles
          - ``canvas_push`` — (future) pipeline visualization if enabled
        """
        contract = getattr(self, "_contract", None)
        actions_to_authorize = ("write_vault", "modify_wiki")
        for action in actions_to_authorize:
            authorized = False
            if contract is not None and hasattr(contract, "check"):
                try:
                    result = contract.check(action)
                    # ContractEnforcer returns an ActionResult with an
                    # ``allowed`` attribute; if it's blocked we don't
                    # mark it. The writer guard will then catch the
                    # violation on the first write — exactly right.
                    authorized = bool(getattr(result, "allowed", False))
                except Exception:
                    log.debug("kb: contract.check(%s) failed", action, exc_info=True)
            if not authorized:
                # Fallback: mark directly (tests, minimal installs)
                try:
                    from agntspace.activity.decisions import mark_action_authorized
                    mark_action_authorized(action)
                except Exception:
                    log.debug("kb: mark_action_authorized(%s) failed", action, exc_info=True)

    def _log_activity(
        self,
        action: str,
        summary: str,
        details: dict | None = None,
        importance: str = "medium",
    ) -> None:
        """Emit a knowledge/ingest activity event. Never raises."""
        activity = getattr(self, "_activity", None)
        if activity is None or not hasattr(activity, "log"):
            return
        try:
            activity.log("knowledge", action, summary, details or {}, importance=importance)
        except Exception:
            log.debug("kb: activity.log failed", exc_info=True)

    async def _record_decision(
        self,
        action_type: str,
        action_target: str,
        *,
        contract_action: str = "ingest",
        contract_result: str = "allowed",
        triggered_by: str = "ingest",
        rationale: str = "",
        details: dict | None = None,
        context_skills: list[str] | None = None,
    ) -> None:
        """Record a librarian decision. Never raises."""
        decisions = getattr(self, "_decisions", None)
        if decisions is None or not hasattr(decisions, "record"):
            return
        try:
            await decisions.record(
                actor="librarian",
                action_type=action_type,
                action_target=action_target,
                contract_action=contract_action,
                contract_result=contract_result,
                triggered_by=triggered_by,
                context_skills=context_skills or ["kb-ingest"],
                rationale=rationale,
                details=details or {},
            )
        except Exception:
            log.debug("kb: decisions.record failed", exc_info=True)

    # Junk-pattern filtering is skill-driven (Rule 12). All rejection rules
    # live in ``defaults/skills/core/kb-ingest/config/junk-patterns.yaml``
    # and are loaded at call time via the SkillLoader. See the YAML file
    # for the full taxonomy (exact_names, substrings, leading_tokens,
    # limits) and multilingual coverage.
    #
    # The engine here is deliberately dumb: it loads the rules, applies
    # them in order, and returns a boolean. Tuning the behavior means
    # editing the YAML, not this method.

    # Lightweight runtime cache for parsed junk patterns so we don't
    # re-parse the YAML on every candidate. The cache is invalidated
    # when ``invalidate_junk_cache()`` is called (e.g. from tests or
    # a skill-reload hook) or when the process restarts. Skills hot-
    # reload on mtime — if we ever want live-reload without restart,
    # extend SkillLoader to bust this cache on skill mtime change.
    _junk_patterns_cache: dict | None = None

    _FALLBACK_LIMITS: dict[str, object] = {  # arch:deterministic — degraded-mode safety net used only when kb-ingest/config/junk-patterns.yaml is missing; the YAML is the real strategy, this is what the engine does when users have no strategy file to tune
        "max_chars": 60, "min_chars": 2, "max_words": 6,
        "reject_trailing_period": True,
    }

    @classmethod
    def invalidate_junk_cache(cls) -> None:
        """Clear the cached junk patterns. Tests call this between cases."""
        cls._junk_patterns_cache = None

    # Phase 2 (Rule 12) caches: throughput cap + skip patterns from
    # the kb-ingest skill config. Same pattern as the junk-pattern cache:
    # class-level so the YAML is read at most once per process unless
    # explicitly invalidated.
    _throughput_cache: dict | None = None
    _skip_patterns_cache: tuple[str, ...] | None = None

    @classmethod
    def invalidate_throughput_cache(cls) -> None:
        cls._throughput_cache = None

    @classmethod
    def invalidate_skip_patterns_cache(cls) -> None:
        cls._skip_patterns_cache = None

    def _load_throughput_cap(self, key: str, *, default: int) -> int:
        """Load one numeric cap from kb-ingest/config/throughput.yaml.

        Returns the configured value, or the documented default if the
        skill loader is missing / config is absent / value is invalid.
        Cached at the class level so multiple call sites in the same
        ingest cycle don't re-parse the YAML.
        """
        if type(self)._throughput_cache is None:
            cfg: dict = {}
            loader = getattr(self, "_skill_loader", None)
            if loader is not None and hasattr(loader, "load_skill_config_file"):
                try:
                    raw = loader.load_skill_config_file("kb-ingest", "throughput.yaml")
                    if isinstance(raw, dict):
                        cfg = raw
                except Exception:
                    log.debug("kb: throughput.yaml load failed", exc_info=True)
            type(self)._throughput_cache = cfg
        try:
            return int(type(self)._throughput_cache.get(key, default))
        except (TypeError, ValueError):
            return default

    def _load_skip_patterns(self) -> tuple[str, ...]:
        """Load multilingual skip patterns from kb-ingest/config/skip-patterns.yaml.

        Returns a flat tuple of lowercased patterns across all language
        sections. Falls back to a minimal English-only set when the
        skill loader / file / data is unavailable -- the same documented
        default as the pre-Phase-2 hardcoded constants.
        """
        if type(self)._skip_patterns_cache is not None:
            return type(self)._skip_patterns_cache

        # Degraded-mode default mirrors the pre-Phase-2 hardcoded set.
        # See ``kb-ingest/config/skip-patterns.yaml`` for the real source.
        fallback: tuple[str, ...] = (
            "time report", "time-report", "timereport",
            "day template", "template",
            "untitled",
            "links",
        )

        loader = getattr(self, "_skill_loader", None)
        if loader is None or not hasattr(loader, "load_skill_config_file"):
            type(self)._skip_patterns_cache = fallback
            return fallback

        try:
            raw = loader.load_skill_config_file("kb-ingest", "skip-patterns.yaml")
        except Exception:
            log.debug("kb: skip-patterns.yaml load failed", exc_info=True)
            type(self)._skip_patterns_cache = fallback
            return fallback

        if not isinstance(raw, dict):
            type(self)._skip_patterns_cache = fallback
            return fallback

        section = raw.get("mundane_filenames")
        flat: list[str] = []
        if isinstance(section, dict):
            for _lang, words in section.items():
                if isinstance(words, list):
                    for w in words:
                        if isinstance(w, str) and w.strip():
                            flat.append(w.strip().lower())
        elif isinstance(section, list):
            for w in section:
                if isinstance(w, str) and w.strip():
                    flat.append(w.strip().lower())

        if not flat:
            type(self)._skip_patterns_cache = fallback
            return fallback

        # Dedup while preserving insertion order
        seen: set[str] = set()
        unique: list[str] = []
        for p in flat:
            if p not in seen:
                seen.add(p)
                unique.append(p)
        result = tuple(unique)
        type(self)._skip_patterns_cache = result
        return result

    def _get_junk_patterns(self) -> dict:
        """Load and flatten junk patterns from the kb-ingest skill config.

        Returns a dict with four flat collections derived from the
        multilingual YAML:

            {
                "exact_names": set[str],      # all languages merged, lowercased
                "substrings":  tuple[str, ...],  # all languages merged, lowercased
                "leading_tokens": tuple[str, ...],  # all languages merged, lowercased
                "limits": {max_chars, min_chars, max_words, reject_trailing_period},
            }

        If the skill config is missing or malformed, returns a minimal
        fallback (limits only, no pattern filtering). This is the
        Rule 12-compliant "no hardcoded patterns" behavior: if the
        strategy YAML isn't there, the engine cannot invent policy —
        it applies only the structural limits that are inherent to
        what-is-an-entity-name (length, word count, trailing period).
        """
        if type(self)._junk_patterns_cache is not None:
            return type(self)._junk_patterns_cache

        patterns = {
            "exact_names": set(),
            "substrings": tuple(),
            "leading_tokens": tuple(),
            "limits": dict(type(self)._FALLBACK_LIMITS),
        }

        loader = getattr(self, "_skill_loader", None)
        if loader is None:
            type(self)._junk_patterns_cache = patterns
            return patterns

        try:
            raw = loader.load_skill_config_file("kb-ingest", "junk-patterns.yaml")
        except Exception:
            log.debug("kb: junk-patterns.yaml load failed", exc_info=True)
            type(self)._junk_patterns_cache = patterns
            return patterns

        if not isinstance(raw, dict):
            type(self)._junk_patterns_cache = patterns
            return patterns

        def _flatten(section: object) -> list[str]:
            """Flatten a multilingual ``{lang: [words...]}`` section into one
            lowercased list. Accepts either a dict of language → list or a
            flat list for backwards compatibility."""
            out: list[str] = []
            if isinstance(section, dict):
                for _lang, words in section.items():
                    if isinstance(words, list):
                        for w in words:
                            if isinstance(w, str) and w.strip():
                                out.append(w.strip().lower())
            elif isinstance(section, list):
                for w in section:
                    if isinstance(w, str) and w.strip():
                        out.append(w.strip().lower())
            return out

        patterns["exact_names"] = set(_flatten(raw.get("exact_names")))
        patterns["substrings"] = tuple(_flatten(raw.get("substrings")))
        patterns["leading_tokens"] = tuple(_flatten(raw.get("leading_tokens")))
        patterns["trailing_attribution_tokens"] = tuple(_flatten(raw.get("trailing_attribution_tokens")))

        yaml_limits = raw.get("limits")
        if isinstance(yaml_limits, dict):
            for key in ("max_chars", "min_chars", "max_words", "reject_trailing_period"):
                if key in yaml_limits:
                    patterns["limits"][key] = yaml_limits[key]

        type(self)._junk_patterns_cache = patterns
        return patterns

    def _is_junk_name(self, name: str) -> bool:
        """Reject LLM prose masquerading as an entity/concept name.

        All rejection strategy lives in
        ``kb-ingest/config/junk-patterns.yaml``. This method only applies
        what the YAML says. Length/word-count limits also come from the
        YAML; the ``_FALLBACK_LIMITS`` are used only when the YAML is
        missing (degraded mode, no silent hardcoded list).
        """
        if not name:
            return True
        lower = name.strip().lower()
        if not lower:
            return True

        patterns = self._get_junk_patterns()
        limits = patterns["limits"]

        if lower in patterns["exact_names"]:
            return True
        for sub in patterns["substrings"]:
            if sub in lower:
                return True
        # Leading tokens are word-boundary matches, not raw prefix matches.
        # The YAML loader strips trailing whitespace (standard YAML behavior),
        # so a token like ``"a "`` loads as ``"a"``. We restore the word
        # boundary at check time by appending a space: ``lower.startswith("a ")``
        # — which correctly matches ``"a type of"`` but NOT ``"acme corp"``.
        # A single-word candidate that equals a leading token (e.g. ``"a"``)
        # is matched too via the equality fallback, because a bare article
        # is not a valid entity name regardless of context.
        for prefix in patterns["leading_tokens"]:
            if not prefix:
                continue
            if lower == prefix or lower.startswith(prefix + " "):
                return True

        if limits.get("reject_trailing_period") and lower.endswith("."):
            return True

        # Comma-attribution rejection: news prose introduces people as
        # "Name, role at Org" — the LLM extractor sometimes emits the whole
        # phrase as one entity name. If the text after the FIRST comma starts
        # with a known role/attribution token, the candidate is prose, not
        # a name. Strategy YAML drives the multilingual token list; real
        # names with commas (e.g. "University of California, Berkeley",
        # "Apple, Inc.", "King Charles, III") have non-role trailing parts
        # and are preserved.
        trailing_tokens = patterns.get("trailing_attribution_tokens") or ()
        if trailing_tokens and "," in lower:
            after_comma = lower.split(",", 1)[1].strip()
            if after_comma:
                for token in trailing_tokens:
                    if not token:
                        continue
                    # Token may already include a trailing space (e.g. "who ");
                    # in that case we match the leading-word variant via
                    # plain startswith. Otherwise we require a word boundary
                    # — bare equality, space-separated continuation, or
                    # punctuation-separated continuation — so "ceo" matches
                    # "ceo" / "ceo at acme" / "ceo, founder" but NOT "ceolite".
                    if token.endswith(" "):
                        if after_comma.startswith(token):
                            return True
                    else:
                        if after_comma == token:
                            return True
                        if after_comma.startswith(token + " "):
                            return True
                        if after_comma.startswith(token + ","):
                            return True

        max_words = limits.get("max_words")
        if isinstance(max_words, int) and max_words > 0 and len(lower.split()) > max_words:
            return True

        return False

    def _filter_concepts_by_source(
        self, concepts_text: str, source_text: str,
    ) -> str:
        """Strip concept lines that don't appear in the source content.

        The classify LLM receives existing KB article titles in its system
        prompt (for dedup). Small and medium models parrot those titles into
        the ``concepts`` block even when the source doesn't mention them.
        This is the engine-level safety net (prompt rules are Layer 1).

        Each bullet line is checked: the concept name (lowercased) must
        appear as a substring in the lowercased source_text, OR every
        significant word (3+ chars) in a multi-word concept must appear.
        Lines that fail are stripped and logged.

        Returns the filtered concepts text (may be empty string).
        """
        if not concepts_text or not source_text:
            return concepts_text
        src_lower = source_text.lower()
        kept: list[str] = []
        stripped: list[str] = []
        for line in concepts_text.split("\n"):
            raw = line.strip()
            if not raw:
                continue
            # Extract concept name from bullet: "- Bowtie Analysis" → "Bowtie Analysis"
            name = raw.lstrip("-•*").strip()
            if not name:
                continue
            nl = name.lower()
            # Direct substring match
            if nl in src_lower:
                kept.append(line)
                continue
            # Multi-word: accept if every word (3+ chars) appears in source
            words = [w for w in nl.split() if len(w) >= 3]
            if len(words) >= 2 and all(w in src_lower for w in words):
                kept.append(line)
                continue
            # Single short word (< 3 chars per word, or single word): check direct
            if len(words) <= 1 and nl in src_lower:
                kept.append(line)
                continue
            stripped.append(name)
        if stripped:
            log.info(
                "KB concepts filter: stripped %d concept(s) not in source text: %s",
                len(stripped), stripped,
            )
        return "\n".join(kept)

    # Allowed entity types that the LLM may use as a prefix in the
    # ``entities:`` block. This is NOT strategy — it's the structural
    # set of valid values for the ``entity_type`` field in the ontology.
    # The ontology YAML is the source of truth; this set is derived from
    # it. If the ontology ever becomes loadable at class-definition
    # time, this list can be replaced with a dynamic lookup. For now
    # the list is duplicated here with an arch:deterministic marker
    # because changing it requires a matching ontology change.
    _ALLOWED_ENTITY_TYPE_PREFIXES = frozenset({  # arch:deterministic — mirrors the ``types`` set in defaults/skills/_meta/ontology/config/ontology.yaml; not user-tunable strategy, it's the schema
        "person", "organization", "concept", "event", "place",
        "document", "decision", "project", "task", "goal",
        "ai_agent", "skill", "thing",
    })

    def _parse_entities_block(self, block: str) -> list[tuple[str, str]]:
        """Parse the ``entities`` block of a classify response into (type, name).

        Expected input format (one bullet per line):

            - person: Sarah Chen — CTO
            - organization: Acme Corp — aerospace
            - place: Stockholm

        **Strict prefix rule (Rule 12 Phase 1):** lines WITHOUT a valid
        ``entity_type:`` prefix are rejected, not silently defaulted to
        ``concept``. The old behavior — "if it doesn't have a prefix,
        call it a concept" — was the root cause of the person-as-concept
        bug: small/fast-tier LLMs routinely drop the prefix, and the
        silent default then stored real people as concepts in the graph.

        The new behavior:
          1. Lines with a valid prefix (from the allowed set) are parsed
             and returned as ``(type, name)``.
          2. Lines with a bogus prefix (something before ``:`` that isn't
             a known entity type) are rejected with a log line so drift
             is visible.
          3. Lines WITHOUT any prefix are rejected. We do not guess.

        Junk names (from the skill's junk-patterns.yaml) are filtered on
        top of all of the above.
        """
        results: list[tuple[str, str]] = []
        if not block:
            return results

        patterns = self._get_junk_patterns()
        limits = patterns["limits"]
        min_chars = int(limits.get("min_chars", 2))
        max_chars = int(limits.get("max_chars", 60))

        rejected_unprefixed = 0
        rejected_bad_prefix = 0

        for raw_line in block.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("-"):
                line = line[1:].strip()
            if not line:
                continue

            # Strict prefix parsing. No silent default.
            if ":" not in line:
                rejected_unprefixed += 1
                continue
            head, rest = line.split(":", 1)
            head_clean = head.strip().lower()
            if head_clean not in self._ALLOWED_ENTITY_TYPE_PREFIXES:
                rejected_bad_prefix += 1
                continue
            etype = head_clean
            line = rest.strip()

            # Name portion is everything before a dash/em-dash description.
            for sep in (" — ", " – ", " - "):
                if sep in line:
                    line = line.split(sep, 1)[0]
                    break
            name = line.strip().strip(".,;:")
            if len(name) < min_chars or len(name) > max_chars:
                continue
            if self._is_junk_name(name):
                continue
            results.append((etype, name))

        if rejected_unprefixed or rejected_bad_prefix:
            log.info(
                "kb-ingest: entities block — rejected %d unprefixed and %d "
                "bad-prefix lines (strict parsing; no silent concept default)",
                rejected_unprefixed, rejected_bad_prefix,
            )

        # De-duplicate within one ingest while preserving order
        seen: set[tuple[str, str]] = set()
        out: list[tuple[str, str]] = []
        for pair in results:
            key = (pair[0], pair[1].lower())
            if key in seen:
                continue
            seen.add(key)
            out.append(pair)
        return out

    def _parse_concepts_block(self, block: str) -> list[str]:
        """Parse the ``concepts`` block into a list of concept names.

        Applies the same skill-driven junk filter as ``_parse_entities_block``.
        Concepts do not carry a type prefix (they are, by definition, all
        of type ``concept``), so no prefix rule applies here.
        """
        if not block:
            return []

        patterns = self._get_junk_patterns()
        limits = patterns["limits"]
        min_chars = int(limits.get("min_chars", 2))
        max_chars = int(limits.get("max_chars", 60))

        out: list[str] = []
        for raw in block.splitlines():
            line = raw.strip().lstrip("-*0123456789.").strip()
            if not line or line.startswith("#"):
                continue
            line = line.strip(".,;:")
            if not (min_chars <= len(line) <= max_chars):
                continue
            if self._is_junk_name(line):
                continue
            out.append(line)
        # Dedup (case-insensitive) preserving first occurrence
        seen: set[str] = set()
        dedup: list[str] = []
        for c in out:
            k = c.lower()
            if k in seen:
                continue
            seen.add(k)
            dedup.append(c)
        return dedup

    def _populate_graph_from_ingest(
        self,
        *,
        source_file: str,
        source_slug: str,
        entities_block: str,
        concepts_block: str,
        kb_slug: str,
        source_text: str = "",
    ) -> dict:
        """Add source + mentioned entities + concepts as triples to the graph.

        Returns a dict with counts suitable for a decision record. Never
        raises — graph failures must not break ingest. The source becomes
        a ``document`` entity; each extracted entity/concept gets an
        ``about_entity`` or ``about_concept`` triple from the source.

        **Rule 12 Phase 1 change (2026-04-11):** the old regex Title-Case
        fallback — which silently fabricated ``concept`` triples when the
        LLM returned an empty extraction — has been removed. Silent
        fabrication was the root cause of the person-as-concept bug:
        real people detected by the Title-Case scan were stored as
        concepts because the fallback hardcoded ``object_type="concept"``.

        The new behavior on empty extraction:
          - The source ``document`` entity is still registered (so the
            file is not invisible in the graph).
          - NO fabricated entity or concept triples are added.
          - A high-importance ``ingest_empty_extraction`` activity event
            is emitted so the agent (and the user) see that this file
            produced no usable extraction and can decide whether to
            re-ingest at a higher model tier.

        ``source_text`` is used for hallucination detection: each extracted
        entity/concept name is checked against the source text. Names not
        present in the source are rejected as potential hallucinations
        (logged at info level). This catches the "Real Person + FakeCompany"
        pattern where one entity is real and the other is fabricated.
        """
        result = {
            "entities": 0, "concepts": 0, "triples": 0,
            "used_fallback": False, "empty_extraction": False,
        }
        graph = getattr(self, "_graph", None)
        if graph is None or not hasattr(graph, "add_triple"):
            return result
        try:
            source_date = datetime.now(UTC).strftime("%Y-%m-%d")
        except Exception:
            source_date = ""
        # Register the source document itself
        try:
            graph.registry.add(
                source_slug or source_file,
                entity_type="document",
                authority="system",
            )
        except Exception:
            log.debug("kb: graph.registry.add(source) failed", exc_info=True)
        entities = self._parse_entities_block(entities_block)
        concepts = self._parse_concepts_block(concepts_block)

        # ── Hallucination gate: reject entities/concepts not in source text ──
        # Each name must appear (case-insensitive) in the source material.
        # Also checks entity registry aliases (EU → European Union, etc.)
        # and individual words (multi-word names where each word appears).
        _src_lower = source_text.lower() if source_text else ""
        if _src_lower:
            _registry = getattr(getattr(self, "_graph", None), "registry", None) if getattr(self, "_graph", None) else None

            def _name_in_source(name: str) -> bool:
                nl = name.lower()
                # Direct substring match
                if nl in _src_lower:
                    return True
                # Check entity registry aliases (e.g., "EU" has alias "European Union")
                if _registry:
                    try:
                        slug = _registry.resolve(name)
                        if slug:
                            canonical = (_registry.get_name(slug) or "").lower()
                            if canonical and canonical in _src_lower:
                                return True
                            # Check all aliases
                            entity = _registry.entities.get(slug, {})
                            for alias in entity.get("aliases", []):
                                if alias.lower() in _src_lower:
                                    return True
                    except Exception:
                        pass
                # Multi-word: accept if every word (3+ chars) appears in source
                words = [w for w in nl.split() if len(w) >= 3]
                if len(words) >= 2 and all(w in _src_lower for w in words):
                    return True
                return False

            _pre_entity_count = len(entities)
            entities = [(t, n) for t, n in entities if _name_in_source(n)]
            _rejected_e = _pre_entity_count - len(entities)
            if _rejected_e:
                log.info("KB %s: rejected %d hallucinated entities for %s (not in source text)",
                         kb_slug, _rejected_e, source_file)

            _pre_concept_count = len(concepts)
            concepts = [c for c in concepts if _name_in_source(c)]
            _rejected_c = _pre_concept_count - len(concepts)
            if _rejected_c:
                log.info("KB %s: rejected %d hallucinated concepts for %s (not in source text)",
                         kb_slug, _rejected_c, source_file)

        # LLM extraction produced nothing usable — either the fenced blocks
        # were missing/malformed, everything was filtered as junk, or all
        # names were hallucinated. Record at high importance so the agent
        # can decide on retry/escalation, and move on.
        if not entities and not concepts:
            result["empty_extraction"] = True
            log.warning(
                "KB %s: LLM produced no usable entities/concepts for %s — "
                "no triples added",
                kb_slug, source_file,
            )
            self._log_activity(
                "ingest_empty_extraction",
                f"{source_file}: LLM returned no usable entities or concepts",
                {
                    "slug": kb_slug,
                    "file": source_file,
                    "entities_block_empty": not entities_block,
                    "concepts_block_empty": not concepts_block,
                    "fabrication": False,
                    "next_action": "escalate_or_accept",
                },
                importance="high",
            )
        for etype, name in entities:
            try:
                graph.add_triple(
                    subject=source_slug or source_file,
                    predicate="about_entity",
                    obj=name,
                    authority="system",
                    source_file=f"knowledge/{kb_slug}/wiki/sources/{source_file}",
                    source_date=source_date,
                    confidence=0.75,
                    subject_type="document",
                    object_type=etype,
                    epistemic_status="believed",
                )
                result["entities"] += 1
                result["triples"] += 1
            except Exception:
                log.debug("kb: add_triple(about_entity) failed for %s", name, exc_info=True)
        for concept in concepts:
            try:
                graph.add_triple(
                    subject=source_slug or source_file,
                    predicate="about_concept",
                    obj=concept,
                    authority="system",
                    source_file=f"knowledge/{kb_slug}/wiki/sources/{source_file}",
                    source_date=source_date,
                    confidence=0.75,
                    subject_type="document",
                    object_type="concept",
                    epistemic_status="believed",
                )
                result["concepts"] += 1
                result["triples"] += 1
            except Exception:
                log.debug("kb: add_triple(about_concept) failed for %s", concept, exc_info=True)
        # Persist once after the batch of triples from this file.
        try:
            if hasattr(graph, "save"):
                graph.save()
        except Exception:
            log.debug("kb: graph.save() failed", exc_info=True)
        return result

    def _populate_graph_from_images(
        self,
        *,
        source_slug: str,
        source_file: str,
        kb_slug: str,
        extract_result: Any,
    ) -> dict:
        """Phase 5 v2 — emit figure entities + ``depicts`` triples from
        embedded-image vision descriptions.

        Walks ``extract_result.elements`` for Image elements with a linked
        description paragraph (same ``parent_id``). For each pair:
          1. Register a figure entity with slug ``{source}-page{N}-img{J}``
             (entity_type=``document`` — figures reuse the document type;
             the slug suffix is the distinguishing convention).
          2. Emit ``(figure, part_of, source_document)`` — structural link
             so queries can navigate figure → parent document.
          3. Parse the description prose for Title-Case entity candidates,
             apply the shared junk filter, and emit
             ``(figure, depicts, concept_or_entity)`` for each survivor.
             Every triple carries ``situational_context.extracted_from_vision
             = True`` + ``image_page`` + ``image_idx`` + ``source_document``
             for full provenance. Authority = system, confidence = 0.7
             (slightly below the ``about_concept`` triples from classify
             because vision output is inherently less certain than textual
             classification).

        Returns ``{figures, triples, depicts_triples, part_of_triples}``.
        Never raises — graph failures never break ingest.

        No-op paths (each returns zero counts without touching the graph):
          - ``extract_result is None`` or lacks ``elements`` attr
          - No Image elements in ``extract_result.elements``
          - Image element has no linked description paragraph (emits
            ``part_of`` only — figure is registered but zero ``depicts``)
          - ``_graph`` isn't wired (degraded mode, common in tests)
        """
        counts = {
            "figures": 0, "triples": 0,
            "depicts_triples": 0, "part_of_triples": 0,
        }
        graph = getattr(self, "_graph", None)
        if graph is None or not hasattr(graph, "add_triple"):
            return counts
        elements = getattr(extract_result, "elements", None) or []
        if not elements:
            return counts

        # Collect image elements + their linked description paragraphs.
        # An image's description is the FIRST paragraph element with
        # ``parent_id == img.element_id``. If none, figure still gets
        # registered + ``part_of`` triple, but no ``depicts`` triples.
        images: list[tuple[Any, str, int, int]] = []
        desc_by_parent: dict[str, str] = {}
        for el in elements:
            kind = getattr(el, "kind", None)
            if kind == "paragraph":
                pid = getattr(el, "parent_id", None)
                if pid and pid not in desc_by_parent:
                    desc_by_parent[pid] = getattr(el, "text", "") or ""
        for el in elements:
            if getattr(el, "kind", None) != "image":
                continue
            img_id = getattr(el, "element_id", None)
            if not img_id:
                continue
            page = getattr(el, "page", None) or 0
            # Parse image_idx from element_id format "page{N}_img{J}"
            img_idx = 0
            try:
                if "_img" in img_id:
                    img_idx = int(img_id.rsplit("_img", 1)[1])
            except (ValueError, IndexError):
                img_idx = 0
            images.append((el, img_id, int(page or 0), img_idx))
        if not images:
            return counts

        try:
            source_date = datetime.now(UTC).strftime("%Y-%m-%d")
        except Exception:
            source_date = ""
        source_wiki_path = f"knowledge/{kb_slug}/wiki/sources/{source_file}"

        for el, img_id, page_no, img_idx in images:
            description = desc_by_parent.get(img_id, "").strip()
            # Stable figure slug — deterministic across re-ingests of the
            # same source so Phase 4.75 re-extract replaces rather than
            # accumulates figure entities.
            figure_slug = f"{source_slug}-page{page_no}-img{img_idx}"
            # Register the figure as a document sub-entity.
            try:
                display = f"Figure {img_idx} on page {page_no} of {source_slug}"
                graph.registry.add(
                    figure_slug,
                    entity_type="document",
                    authority="system",
                    aliases=[display],
                )
            except Exception:
                log.debug("kb: graph.registry.add(figure) failed", exc_info=True)
                continue
            counts["figures"] += 1

            # Provenance carried on every triple this helper emits so the
            # user can trace a concept back to the specific figure that
            # surfaced it.
            base_context = {
                "extracted_from_vision": True,
                "image_page": page_no,
                "image_idx": img_idx,
                "source_document": source_slug,
                "figure_slug": figure_slug,
            }

            # 1. part_of — link figure to its source document.
            try:
                graph.add_triple(
                    subject=figure_slug,
                    predicate="part_of",
                    obj=source_slug or source_file,
                    authority="system",
                    source_file=source_wiki_path,
                    source_date=source_date,
                    confidence=0.9,
                    subject_type="document",
                    object_type="document",
                    epistemic_status="believed",
                    situational_context=dict(base_context),
                )
                counts["part_of_triples"] += 1
                counts["triples"] += 1
            except Exception:
                log.debug(
                    "kb: add_triple(figure part_of source) failed for %s",
                    figure_slug, exc_info=True,
                )

            # 2. depicts — parse concept candidates from the description
            # and link the figure to each. Strip the "[Page N · Image J]"
            # header before parsing so it doesn't become an entity.
            if not description:
                continue
            # Drop the bracket-prefix line; keep the rest as description prose
            desc_body = description
            if desc_body.startswith("[") and "]" in desc_body:
                desc_body = desc_body.split("\n", 1)[-1] if "\n" in desc_body else ""
            if not desc_body.strip():
                continue

            try:
                from agntspace.text import extract_entity_candidates
            except Exception:
                log.debug("kb: extract_entity_candidates unavailable", exc_info=True)
                continue

            seen: set[str] = set()
            try:
                candidates = extract_entity_candidates(desc_body) or []
            except Exception:
                log.debug(
                    "kb: candidate extraction failed for figure %s",
                    figure_slug, exc_info=True,
                )
                candidates = []

            for raw_name in candidates:
                name = (raw_name or "").strip()
                if not name:
                    continue
                if self._is_junk_name(name):
                    continue
                nl = name.lower()
                if nl in seen:
                    continue
                seen.add(nl)
                try:
                    graph.add_triple(
                        subject=figure_slug,
                        predicate="depicts",
                        obj=name,
                        authority="system",
                        source_file=source_wiki_path,
                        source_date=source_date,
                        confidence=0.7,
                        subject_type="document",
                        object_type="concept",
                        epistemic_status="believed",
                        situational_context=dict(base_context),
                    )
                    counts["depicts_triples"] += 1
                    counts["triples"] += 1
                except Exception:
                    log.debug(
                        "kb: add_triple(depicts) failed for %s → %s",
                        figure_slug, name, exc_info=True,
                    )

        # Persist once after all figures for this source.
        try:
            if hasattr(graph, "save"):
                graph.save()
        except Exception:
            log.debug("kb: graph.save() after images failed", exc_info=True)
        return counts

    @property
    def _taxonomy_text(self) -> str:
        """Lazily load the merged (bundled + vault override) taxonomy and
        render as prompt text."""
        if self._skills_dir:
            from agntspace.kb.taxonomy import load_taxonomy, taxonomy_for_prompt
            vault_dir = getattr(self._vault, "vault_dir", None)
            tree = load_taxonomy(self._skills_dir, vault_dir=vault_dir)
            return taxonomy_for_prompt(tree)
        return "(no taxonomy configured)"

    def _classify(self, entity_type: str, category: str, title: str) -> str:
        """Classify an article against the merged taxonomy. Returns
        ``taxonomy_path`` or ``""`` when nothing matches."""
        if not self._skills_dir:
            return ""
        from agntspace.kb.taxonomy import classify_article, flatten_taxonomy, load_taxonomy
        vault_dir = getattr(self._vault, "vault_dir", None)
        tree = load_taxonomy(self._skills_dir, vault_dir=vault_dir)
        flat_nodes = flatten_taxonomy(tree)
        return classify_article(entity_type=entity_type, category=category, title=title, flat_nodes=flat_nodes)

    def _validated_taxonomy_path(
        self,
        llm_emitted: str,
        *,
        fallback_etype: str,
        fallback_category: str,
        fallback_title: str,
    ) -> str:
        """Return a taxonomy_path, preferring the LLM's emitted choice when
        valid, falling back to the structural classifier otherwise.

        Validation rules (Session 1 of Wiki classification overhaul,
        2026-04-27 evening — closes Problem B at the source for new ingests):

        - The candidate must be non-empty after strip.
        - The candidate must NOT be a bare L1 slug (``sources``, ``entities``,
          etc.) — those are the degenerate-fallback sentinels we're trying to
          eliminate. Require at least one ``/`` (L2 minimum).
        - The candidate must exist in the loaded taxonomy tree as a known
          path. Hallucinated nodes are rejected.

        On rejection, we fall back to the structural ``classify_article`` call
        so the file still gets classified rather than crashing the ingest. A
        debug log line records which path was used for forensic visibility.
        """
        if not self._skills_dir:
            # Degraded mode (no skills loaded). Return whatever the LLM
            # gave us as a best-effort path; caller layers will tolerate
            # empty strings via the existing "" handling.
            return (llm_emitted or "").strip()

        from agntspace.kb.taxonomy import classify_article, flatten_taxonomy, load_taxonomy
        vault_dir = getattr(self._vault, "vault_dir", None)
        tree = load_taxonomy(self._skills_dir, vault_dir=vault_dir)
        flat_nodes = flatten_taxonomy(tree)
        known_paths = {n["path"] for n in flat_nodes}

        candidate = (llm_emitted or "").strip()
        # Strip surrounding quotes that some local LLMs add around the value.
        if len(candidate) >= 2 and candidate[0] == candidate[-1] and candidate[0] in ('"', "'"):
            candidate = candidate[1:-1].strip()
        # Normalize separator — Windows-y backslashes from copy-paste mistakes.
        candidate = candidate.replace("\\", "/").strip("/").lower()

        if candidate and "/" in candidate and candidate in known_paths:
            log.debug(
                "kb_ingest taxonomy_path: using LLM-emitted leaf %r for %s",
                candidate, fallback_title,
            )
            return candidate

        if candidate:
            log.debug(
                "kb_ingest taxonomy_path: rejecting LLM emit %r (bare L1, "
                "unknown path, or empty) — falling back to structural classify",
                candidate,
            )
        return classify_article(
            entity_type=fallback_etype,
            category=fallback_category,
            title=fallback_title,
            flat_nodes=flat_nodes,
        )

    # ── Helpers ──

    def _classify_source(self, filename: str) -> tuple[str, str]:
        """Classify source by file type. Returns (type_name, prompt_focus).

        Resolution order (first non-None wins):
          1. FileTypeRegistry (bundled defaults + Phase-2 skill YAMLs + plugins).
          2. ``kb-ingest/config/source-types.yaml`` via the skill loader.
          3. Hardcoded ``_SOURCE_TYPES`` fallback (degraded mode).

        The registry path intentionally returns
        ``(spec.default_source_type, spec.prompt_focus)`` so the written
        ``source_type`` frontmatter + prompt_focus stay IDENTICAL to the
        pre-registry world. The registry's own ``spec.type_name`` (more
        granular — ``article_text`` vs ``article_html``) flows into
        provenance instead, via ``ExtractResult.provenance['type_name']``.
        """
        ext = Path(filename).suffix.lower()
        # 1. Registry — new canonical path.
        spec = self._file_types.resolve_type(Path(filename))
        if spec is not None:
            return spec.default_source_type, spec.prompt_focus
        # 2. Skill-driven YAML (legacy compat until Phase 2 migrates to
        #    per-type skill dirs and the registry is fully authoritative).
        yaml_types = self._load_source_types_config()
        if yaml_types:
            for stype, info in yaml_types.items():
                if stype.startswith("__"):
                    continue
                exts = info.get("extensions", [])
                if ext in exts:
                    return stype, info.get("prompt_focus", "")
            return yaml_types.get("__default_type", "article"), yaml_types.get("__default_focus", "Extract main points, key facts, and context.")
        # 3. Hardcoded degraded-mode fallback.
        for stype, info in _SOURCE_TYPES.items():
            if ext in info["exts"]:
                return stype, info["prompt_focus"]
        return "article", "Extract main points, key facts, and context."

    async def _extract_source(
        self,
        raw_file: Path,
        fname: str,
    ) -> tuple[str, dict, str, str, ExtractResult | None]:
        """Extract source content via the FileTypeRegistry.

        Returns ``(source_text, source_meta, raw_source_url, content_hash, extract_result)``
        — exactly the 4-tuple the pre-registry ingest loop used, plus the
        raw ExtractResult so the caller can emit provenance triples + read
        richer structured elements in later phases.

        Parity guarantees vs the pre-registry world:

        - **Text files** (`.md` / `.txt` / `.rst` / `.html` / `.htm` / `.yaml`):
          frontmatter is peeled into ``source_meta``; body runs through
          ``_strip_web_noise`` for HTML-like content; ``source_url`` /
          ``source`` / ``url`` frontmatter keys become ``raw_source_url``.
        - **PDF / JSONL / JSON / VTT / SRT**: routed through their dedicated
          extractors (``pdf_pdfplumber`` / ``json_pretty`` / ``vtt_srt``)
          which internally call ``kb.parsers.parse_file`` for backward compat.
        - **Images**: the ``vision_llm`` extractor runs OCR + multimodal LLM
          with the same 120s timeout and the same error fallback string
          (``"[Image file: X — could not analyze]"``) the pre-registry code
          produced. ``source_meta`` gains ``has_ocr`` / ``has_description``
          flags instead of the empty dict it used to be — new richness,
          not a contract break.
        - **Empty / unreadable**: fallback string
          ``"[Binary or unreadable file: X]"`` preserved so the content_hash
          stays deterministic and the dedup map keeps working.

        Never raises. Extractor failures are absorbed by
        ``FileTypeRegistry.extract`` and returned as ExtractResults with
        ``provenance["error"]`` set so the caller can see what failed.
        """
        spec = self._file_types.resolve_type(raw_file)
        if spec is None:
            # Unknown extension — fall back to the text_utf8 extractor so
            # we still get a result (text + frontmatter peeled). The caller
            # relies on fall-through for skip patterns that run before us.
            spec = self._file_types.get_spec("article_text")
            if spec is None:
                # Registry was never populated — degraded-mode error.
                msg = f"[Binary or unreadable file: {fname}]"
                return msg, {}, "", hashlib.md5(fname.encode()).hexdigest()[:12], None

        # Extractor context — vision extractor needs the llm provider +
        # the service's describe_image method for its OCR-aware flow.
        context: dict[str, Any] = {
            "llm": self._llm,
            "describe_image": getattr(self, "_describe_image", None),
            "vision_timeout": 120,
        }

        result = await self._file_types.extract(raw_file, spec, context)

        # Text assembly.
        if result.is_empty and not result.provenance.get("error"):
            source_text = f"[Binary or unreadable file: {fname}]"
            content_hash = hashlib.md5(fname.encode()).hexdigest()[:12]
        else:
            source_text = result.as_text()
            if not source_text.strip():
                # Extractor returned only empty elements + an error marker —
                # keep the content_hash stable by hashing the filename.
                source_text = f"[Binary or unreadable file: {fname}]"
                content_hash = hashlib.md5(fname.encode()).hexdigest()[:12]
            else:
                # Post-process text-like extractions to strip web-clipper noise
                # (iframes, leading blank lines, HTML comments). Binary-origin
                # extractors — PDF, vision, CSV, transcript — don't need this.
                if spec.extractor in ("text_utf8", "html_parser"):
                    source_text = self._strip_web_noise(source_text)
                content_hash = hashlib.md5(source_text.encode()).hexdigest()[:12]

        # Frontmatter / doc_metadata carries source_url candidates.
        source_meta = dict(result.doc_metadata or {})
        raw_source_url = str(
            source_meta.get("source_url", "")
            or source_meta.get("source", "")
            or source_meta.get("url", "")
            or ""
        )
        if raw_source_url and not raw_source_url.startswith(("http://", "https://")):
            raw_source_url = ""

        return source_text, source_meta, raw_source_url, content_hash, result

    def _load_source_types_config(self) -> dict | None:
        """Load source-types.yaml from the kb-ingest skill."""
        if not self._skill_loader:
            return None
        try:
            cfg = self._skill_loader.load_skill_config_file("kb-ingest", "source-types.yaml")
            if not cfg or not isinstance(cfg.get("source_types"), dict):
                return None
            result = cfg["source_types"]
            result["__default_type"] = cfg.get("default_type", "article")
            result["__default_focus"] = cfg.get("default_prompt_focus", "Extract main points, key facts, and context.")
            return result
        except Exception:
            return None

    @staticmethod
    def _strip_web_noise(content: str) -> str:
        """Strip web-clipper noise — thin wrapper over agntspace.text.

        Kept as a method so existing call sites still work; the actual
        implementation is the shared ``strip_web_clipper_noise`` in
        ``agntspace.text.html`` so KB ingest and any future text-consuming
        subsystem share one source of truth.
        """
        from agntspace.text import strip_web_clipper_noise
        return strip_web_clipper_noise(content)

    def _get_wiki_subdirs(self, slug: str) -> list[str]:
        """Discover all wiki subdirectories dynamically (covers LLM-created dirs like events/)."""
        wiki_dir = self._resolve(f"knowledge/{slug}/wiki")
        if not wiki_dir.is_dir():
            return list(_WIKI_SUBDIRS)
        dirs = []
        for d in wiki_dir.iterdir():
            if d.is_dir() and not d.name.startswith(("_", ".")):
                dirs.append(d.name)
        # Ensure static subdirs are always included
        for sd in _WIKI_SUBDIRS:
            if sd not in dirs:
                dirs.append(sd)
        return dirs

    def _list_wiki_articles(self, base_path: str, pattern: str = "*.md") -> list:
        """List wiki article files, excluding any dot-prefixed segment.

        Skips any file whose path contains a segment starting with "."
        — covers `.history/`, `.archives/`, `.pytest_cache/`, `.git/`,
        `.venv/`, etc. plus dot-prefixed filenames. Mirrors the
        path-segment rule used in `api/routes/wiki.py::can_open_in_obsidian`
        and `automation/fs_events.py`.
        """
        try:
            files = self._reader.list_files(base_path, pattern)
            return [
                f for f in files
                if not any(
                    part.startswith(".")
                    for part in str(f).replace("\\", "/").split("/")
                    if part
                )
            ]
        except Exception:
            return []

    def _collect_image_inventory(self, base: str) -> list[dict]:
        """Scan wiki/sources/ for image source summaries.

        Returns a list of dicts with ``library_path`` (relative to the
        wiki article that will embed it) and ``description`` (the vision
        LLM's summary of what the image shows).  The compile LLM uses
        this to embed ``![caption](path)`` in the articles it generates.
        """
        images: list[dict] = []
        sources_dir = f"{base}/wiki/sources"
        try:
            files = self._list_wiki_articles(sources_dir)
        except Exception:
            return images

        for f in files:
            try:
                rel = self._to_logical(f)
                doc = self._reader.read(rel)
                meta = doc.metadata or {}

                # Only image source summaries
                if meta.get("category") != "image":
                    continue

                library_path = meta.get("library_path", "")
                if not library_path:
                    continue

                # Extract the summary or first paragraph as description
                content = doc.content or ""
                description = ""

                # Try the "## Summary" section first
                if "## Summary" in content:
                    after_summary = content.split("## Summary", 1)[1]
                    # Take until the next ## heading
                    next_heading = after_summary.find("\n## ")
                    if next_heading > 0:
                        description = after_summary[:next_heading].strip()
                    else:
                        description = after_summary[:500].strip()
                elif "## Visual Description" in content:
                    after_vis = content.split("## Visual Description", 1)[1]
                    next_heading = after_vis.find("\n## ")
                    if next_heading > 0:
                        description = after_vis[:next_heading].strip()
                    else:
                        description = after_vis[:500].strip()

                if not description:
                    # Fallback: first non-empty line after the title
                    for line in content.split("\n"):
                        line = line.strip()
                        if line and not line.startswith("#") and not line.startswith(">") and not line.startswith("!"):
                            description = line[:300]
                            break

                images.append({
                    "source_file": meta.get("source_file", f.name),
                    "library_path": library_path,
                    "description": description or "Image (no description available)",
                })
            except Exception:
                continue

        return images

    def _read_schema(self, slug: str) -> str:
        path = f"knowledge/{slug}/SCHEMA.md"
        if self._reader.exists(path):
            return self._reader.read(path).content
        return ""

    def _read_schema_meta(self, slug: str) -> dict:
        """Return SCHEMA.md frontmatter as a dict. Empty dict if missing."""
        path = f"knowledge/{slug}/SCHEMA.md"
        if not self._reader.exists(path):
            return {}
        try:
            return dict(self._reader.read(path).metadata or {})
        except Exception:
            return {}

    # Library layout modes — controls how originals are filed under library/.
    # ``type-date`` is the historical default and remains the fallback for
    # KBs whose SCHEMA.md predates the field. New KBs created after 2026-04
    # default to ``thematic`` via the SCHEMA template.
    _VALID_LIBRARY_LAYOUTS = frozenset({"flat", "type-date", "thematic"})  # arch:deterministic — layout vocabulary

    def _kb_library_layout(self, slug: str) -> str:
        """Resolve the effective library layout for a KB.

        Returns one of ``flat`` / ``type-date`` / ``thematic``. When the
        SCHEMA.md doesn't declare ``library_layout`` (existing KBs,
        corrupted frontmatter, etc.) falls back to ``type-date`` so the
        old on-disk arrangement stays honoured — the "no surprises" rule.
        """
        meta = self._read_schema_meta(slug)
        raw = str(meta.get("library_layout") or "").strip().lower()
        if raw in self._VALID_LIBRARY_LAYOUTS:
            return raw
        return "type-date"

    def _read_index(self, slug: str) -> str:
        path = f"knowledge/{slug}/wiki/.index.md"
        if self._reader.exists(path):
            return self._reader.read(path).content
        return ""

    def _append_log(self, slug: str, operation: str, details: str) -> None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        entry = f"\n## [{now}] {operation} | {details}\n"
        log_path = f"knowledge/{slug}/log.md"
        if not self._reader.exists(log_path):
            self._writer.write(log_path, (
                "---\ntitle: \"Operation Log\"\ntype: kb_log\nauthor: agent\nagent: librarian\n---\n\n"
                "# Knowledge Base Log\n"
            ), trust_reason="kb_log")
        self._writer.append(log_path, entry, trust_reason="kb_log")

    def _read_compile_state(self, slug: str) -> dict:
        # Read the JSON state file directly from the filesystem. Do NOT
        # use VaultReader: it runs every file through python-frontmatter,
        # which interprets a leading ``{`` as JSON frontmatter and returns
        # an empty ``content``. _write_compile_state already writes the
        # file directly (atomic rename), so the read path must match.
        physical = self._resolve(f"knowledge/{slug}/.compile-state.json")
        if physical.is_file():
            try:
                raw = physical.read_text(encoding="utf-8")
                if not raw.strip():
                    # Empty file (partial write, never populated) — just
                    # treat as fresh state, no need to back up.
                    return _fresh_compile_state()
                state = json.loads(raw)
                # Migrate old format: ensure "sources" dict exists
                if "sources" not in state:
                    state["sources"] = {}
                    for fname, h in state.get("processed_hashes", {}).items():
                        state["sources"][fname] = {
                            "hash": h,
                            "vault_source": "",
                            "ingested_at": state.get("last_ingest", ""),
                            "source_type": "",
                            "library_path": "",
                            "produced_pages": [],
                            "agent": "librarian",
                            "status": "ingested",
                        }
                return state
            except json.JSONDecodeError as exc:
                # Genuine corruption (not frontmatter-misread). Back it
                # up with a timestamped name so repeated corruptions
                # don't collide on the same backup target.
                log.warning(
                    "KB %s: compile-state corrupted (%s) — backing up and reconstructing",
                    slug, exc,
                )
                try:
                    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")
                    backup = physical.with_suffix(f".json.corrupted.{stamp}")
                    physical.replace(backup)
                except Exception:
                    log.exception("KB %s: could not back up corrupted state", slug)
            except Exception:
                log.exception("KB %s: unexpected error reading compile-state", slug)
        return _fresh_compile_state()

    def _write_compile_state(self, slug: str, state: dict) -> None:
        # Atomic write: write to temp file, then rename. Prevents corruption
        # if the process dies mid-write.
        path = self._resolve(f"knowledge/{slug}/.compile-state.json")
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        try:
            tmp.write_text(json.dumps(state, indent=2), encoding="utf-8")
            tmp.replace(path)
        except Exception:
            log.exception("KB %s: failed to write compile-state", slug)
            if tmp.exists():
                try:
                    tmp.unlink()
                except Exception:
                    pass

    def _record_source(
        self, state: dict, fname: str, *,
        content_hash: str, vault_source: str = "",
        source_type: str = "", library_path: str = "",
        produced_pages: list[str] | None = None,
        agent: str = "librarian",
    ) -> None:
        """Record full provenance for a processed source."""
        now = datetime.now(UTC).isoformat()
        sources = state.setdefault("sources", {})
        existing = sources.get(fname, {})
        sources[fname] = {
            "hash": content_hash,
            "vault_source": vault_source or existing.get("vault_source", ""),
            "ingested_at": existing.get("ingested_at", now),
            "updated_at": now,
            "source_type": source_type or existing.get("source_type", ""),
            "library_path": library_path or existing.get("library_path", ""),
            "produced_pages": (produced_pages or []) + existing.get("produced_pages", []),
            "agent": agent,
            "status": "ingested",
        }
        # Keep backward compat
        state.setdefault("processed_hashes", {})[fname] = content_hash

    def _check_cross_kb_duplicate(self, current_slug: str, content_hash: str) -> str | None:
        """Check if content_hash exists in any other KB's processed_hashes.
        Returns the other KB slug if found, else None.
        """
        for kb in self.list_kbs():
            other_slug = kb["slug"]
            if other_slug == current_slug:
                continue
            other_state = self._read_compile_state(other_slug)
            if content_hash in other_state.get("processed_hashes", {}).values():
                return other_slug
        return None

    @staticmethod
    def _canonicalize_title(title: str) -> str:
        """Strip dates, parenthesized qualifiers, and trailing whitespace
        so two titles for the same conceptual entity collapse to a match.

        Production failure mode this catches (Wolf vault, 2026-04-28):
        the LLM produced THREE separate articles for the same Möte med
        Tony meeting:
          - "2025-11-17 1430 Möte med Tony"   (date prefix)
          - "Möte med Tony (2025-11-17 1430)" (parenthesized date)
          - "Möte med Tony 2025-11-17 1430"   (date suffix)
        SequenceMatcher between the raw forms gives ratio ~0.44 — well
        below the 0.75 threshold — so dedup misses all three. After
        canonicalization, all three reduce to "möte med tony" and match
        exactly.

        Pure function; the patterns are deterministic — extending them
        is a matter of adding a regex, no semantic risk.
        """
        import re as _re

        if not title:
            return ""
        s = title.strip().lower()

        # Strip parenthesized date qualifiers anywhere in the title:
        #   "Möte med Tony (2025-11-17 1430)" → "Möte med Tony"
        #   "Q3 Review (FY24)"                → "Q3 Review"
        s = _re.sub(r"\s*\([^)]*\d{4}[^)]*\)\s*", " ", s)
        s = _re.sub(r"\s*\(\s*[^)]+\s*\)\s*$", " ", s)  # any trailing parenthesized qualifier

        # Strip ISO-style date+time runs ANYWHERE: "2025-11-17 1430"
        # or "2025-11-17T14:30" or just "2025-11-17". Catches both
        # date-prefixed and date-suffixed title forms. The `[Tt\s]`
        # accepts both upper and lowercase T because the title was
        # already lowercased above.
        s = _re.sub(
            r"\b\d{4}-\d{1,2}-\d{1,2}([Tt\s]\d{1,4}(:\d{2})?)?\b",
            " ",
            s,
        )

        # Strip trailing time-only suffixes "1430" / "14:30" left over
        # after a date strip (e.g. "Möte 14:30").
        s = _re.sub(r"\b\d{2}:?\d{2}\b\s*$", " ", s)

        # Collapse whitespace.
        s = _re.sub(r"\s+", " ", s).strip()

        return s

    @staticmethod
    def _normalize_slug(s: str) -> str:
        """Convert a title-like or filename-stem string to a comparable
        canonical form: lowercase, ASCII-fold non-letter chars to dashes,
        collapse runs, strip ends. Both sides of any slug similarity check
        MUST go through this so we're not comparing apples ("Möte med Tony")
        to oranges ("mote-med-tony")."""
        import re as _re
        return _re.sub(r"[^a-z0-9]+", "-", (s or "").lower()).strip("-")

    def _find_similar_article(self, kb_slug: str, article_path: str, content: str) -> str | None:
        """Check if a near-duplicate article already exists.

        Checks (in order):
        1. CANONICALIZED title exact match — strips dates so
           "Möte med Tony (2025-11-17 1430)" and
           "Möte med Tony 2025-11-17 1430" both reduce to "möte med tony"
           and match. **Highest-precision check — runs first**.
        2. NORMALIZED slug similarity — both sides routed through
           ``_normalize_slug`` so the comparison is between like forms
           (no longer "möte-med-tony" vs "Möte med Tony 2025-11-17 1430"
           which gave a misleading 0.44 ratio).
        3. Title similarity — SequenceMatcher > 0.80 on canonicalized
           titles.

        Returns the path of the duplicate if found, else None.
        """
        import re as _re
        from difflib import SequenceMatcher

        # Extract the proposed slug and subdir
        parts = article_path.split("/", 1)
        if len(parts) != 2:
            return None
        subdir, new_slug = parts

        # Extract proposed title from content frontmatter
        new_title = ""
        title_match = _re.search(r'^title:\s*"?(.+?)"?\s*$', content, _re.MULTILINE)
        if title_match:
            new_title = title_match.group(1).strip()

        # Pre-compute canonical forms ONCE for comparison.
        new_slug_norm = self._normalize_slug(new_slug)
        new_title_canonical = self._canonicalize_title(new_title)

        # Gap 3 fix (2026-04-28): registry-aware dedup. Ask the entity
        # registry whether this title resolves to a known canonical entity.
        # If yes, the registry's canonical name becomes an additional
        # comparison target — catches the cross-language / synonym case
        # where "Felmodanalys-workshop" resolves to the same canonical
        # entity as "FMEA Workshop", or "Sam Altman" / "Samuel Altman"
        # collapse via the alias index. The registry already encodes
        # 4-tier resolution (exact / alias / cosine ≥0.82 / SequenceMatcher
        # ≥0.92) so anything it returns has crossed an explicit threshold.
        registry_canonical_title = ""
        graph = getattr(self, "_graph", None)
        registry = getattr(graph, "registry", None) if graph is not None else None
        if registry is not None and new_title and len(new_title) >= 4:
            try:
                resolved_slug = registry.resolve(new_title)
                if resolved_slug:
                    canonical_name = registry.get_name(resolved_slug) or ""
                    if canonical_name and canonical_name.strip().lower() != new_title.strip().lower():
                        registry_canonical_title = self._canonicalize_title(canonical_name)
            except Exception:
                # Registry hiccup must NEVER break compile. Skip the
                # registry hint and fall back to title+slug matching.
                log.debug(
                    "kb: registry resolve failed for title %r — falling back to title/slug dedup",
                    new_title, exc_info=True,
                )

        # Scan existing articles in the same subdir
        base = f"knowledge/{kb_slug}/wiki/{subdir}"
        try:
            existing_files = list(self._reader.list_files(base, "*.md"))
        except Exception:
            return None

        for ef in existing_files:
            # Skip version history files
            if "/.history/" in str(ef).replace("\\", "/") or "\\.history\\" in str(ef):
                continue
            existing_slug = ef.stem

            # 1. Title canonicalization match — runs FIRST because it's the
            #    highest-precision signal (catches the date-format-variation
            #    failure mode that defeated the old SequenceMatcher path).
            #    Compares BOTH the LLM-emitted title canonical AND (when
            #    available) the registry's canonical name canonical form,
            #    so cross-language / synonym variants resolve too (Gap 3).
            if new_title_canonical or registry_canonical_title:
                try:
                    doc = self._reader.read(f"{base}/{ef.name}")
                    existing_title_raw = doc.metadata.get("title", "")
                    existing_title_canonical = self._canonicalize_title(existing_title_raw)
                    if existing_title_canonical:
                        # Exact-canonical match against either signal.
                        if existing_title_canonical == new_title_canonical:
                            return f"{subdir}/{existing_slug}"
                        if registry_canonical_title and existing_title_canonical == registry_canonical_title:
                            return f"{subdir}/{existing_slug}"
                        # Soft title match: SequenceMatcher on canonical forms
                        # (LLM title) — kept at the same 0.80 threshold.
                        if new_title_canonical and SequenceMatcher(
                            None, new_title_canonical, existing_title_canonical,
                        ).ratio() > 0.80:
                            return f"{subdir}/{existing_slug}"
                        # Soft title match against the REGISTRY canonical too
                        # — same threshold, separate from the LLM-title path.
                        if registry_canonical_title and SequenceMatcher(
                            None, registry_canonical_title, existing_title_canonical,
                        ).ratio() > 0.80:
                            return f"{subdir}/{existing_slug}"
                except Exception:
                    pass  # fall through to slug check

            # 2. Slug similarity on NORMALIZED forms — both sides slugified
            #    so we're not comparing dashes-vs-spaces or mixed casing.
            existing_slug_norm = self._normalize_slug(existing_slug)
            if new_slug_norm and existing_slug_norm:
                if (
                    new_slug_norm == existing_slug_norm
                    or new_slug_norm in existing_slug_norm
                    or existing_slug_norm in new_slug_norm
                    or SequenceMatcher(None, new_slug_norm, existing_slug_norm).ratio() > 0.75
                ):
                    return f"{subdir}/{existing_slug}"

        return None

    def _render_template(self, entity_type: str, **kwargs) -> str:
        templates = _load_article_templates(getattr(self, "_skill_loader", None))
        template = templates.get(entity_type, templates.get("concept", _CONCEPT_FALLBACK))
        kwargs.setdefault("agent", "editor")
        # Provenance — Layer 2 of the three-layer model (type × provenance × status).
        # Fixed-provenance templates (source_summary, synthesis, decision_record)
        # hardcode their own value and ignore this kwarg. Flexible templates
        # (person/org/concept/event/place/document/decision) interpolate {provenance}
        # from here. Default to "compiled" because that's the most common write
        # path (editor compiling entity pages from sources); callers override
        # for research/manual/reflected paths.
        kwargs.setdefault("provenance", "compiled")
        # Graceful fallback: when the loaded template has placeholders
        # the caller didn't provide (e.g. {sources} in the concept
        # fallback, {source_list} in the concept template), supply
        # empty strings so .format() never raises KeyError. The
        # template files evolve independently from the kwargs list
        # and this is the one place they meet at runtime.
        import string
        try:
            needed = {
                fname
                for _, fname, _, _ in string.Formatter().parse(template)
                if fname is not None
            }
        except Exception:
            needed = set()
        for key in needed:
            kwargs.setdefault(key, "")
        return template.format(**kwargs)

    def _enrich_index(self, slug: str) -> None:
        """Rebuild _index.md with per-article metadata.

        Pattern: each page listed with a link, a one-line summary, and
        optionally metadata like date or source count.

        Scans all wiki articles and rebuilds the Sources, Entities, and
        Concepts sections with: ``- [[Title]] — summary (N sources, date)``
        """
        base = f"knowledge/{slug}"
        idx_path = f"{base}/wiki/.index.md"
        if not self._reader.exists(idx_path):
            return

        doc = self._reader.read(idx_path)
        idx_raw = doc.raw

        # Collect articles by category
        sources_lines: list[str] = []
        entities_lines: list[str] = []
        concepts_lines: list[str] = []
        synthesis_lines: list[str] = []

        for subdir, target_list in [
            ("sources", sources_lines),
            ("entities", entities_lines),
            ("concepts", concepts_lines),
            ("synthesis", synthesis_lines),
        ]:
            try:
                for wf in sorted(
                    self._list_wiki_articles(f"{base}/wiki/{subdir}"),
                    key=lambda f: f.stem,
                ):
                    rel = self._to_logical(wf)
                    adoc = self._reader.read(rel)
                    meta = adoc.metadata or {}
                    title = meta.get("title", wf.stem)
                    # One-line summary: first non-empty, non-heading line
                    summary = ""
                    for line in (adoc.content or "").split("\n"):
                        line = line.strip()
                        if line and not line.startswith("#") and not line.startswith("!") and not line.startswith(">"):
                            summary = line[:120]
                            if len(line) > 120:
                                summary += "..."
                            break
                    src_count = meta.get("source_count", len(meta.get("sources", [])))
                    date = meta.get("date_created", meta.get("date_updated", ""))
                    if date:
                        date = date[:10]  # just the date part

                    parts = [f"- [[{title}]]"]
                    if summary:
                        parts.append(f"— {summary}")
                    meta_bits = []
                    if src_count:
                        meta_bits.append(f"{src_count} source{'s' if int(src_count) != 1 else ''}")
                    if date:
                        meta_bits.append(date)
                    if meta_bits:
                        parts.append(f"({', '.join(meta_bits)})")
                    target_list.append(" ".join(parts))
            except Exception:
                continue

        # Rebuild sections in the index
        def _replace_section(text: str, header: str, new_lines: list[str]) -> str:
            marker = f"## {header}"
            if marker not in text:
                return text
            before, rest = text.split(marker, 1)
            # Find the next ## heading
            next_h2 = rest.find("\n## ")
            if next_h2 > 0:
                after = rest[next_h2:]
            else:
                after = ""
            body = "\n".join(new_lines) if new_lines else "\n*No articles yet.*"
            return f"{before}{marker}\n\n{body}\n{after}"

        updated = idx_raw
        updated = _replace_section(updated, "Sources", sources_lines)
        updated = _replace_section(updated, "Entities", entities_lines)
        updated = _replace_section(updated, "Concepts", concepts_lines)

        # Add Synthesis section if we have synthesis articles and section doesn't exist
        if synthesis_lines:
            if "## Synthesis" not in updated:
                # Insert before Statistics
                if "## Statistics" in updated:
                    updated = updated.replace(
                        "## Statistics",
                        "## Synthesis\n\n" + "\n".join(synthesis_lines) + "\n\n## Statistics",
                    )
            else:
                updated = _replace_section(updated, "Synthesis", synthesis_lines)

        # Also update the stats
        src_total = len(sources_lines)
        ent_total = len(entities_lines)
        con_total = len(concepts_lines)
        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")
        import re as _re
        updated = _re.sub(r"- Sources ingested: \d+", f"- Sources ingested: {src_total}", updated)
        updated = _re.sub(r"- Entity pages: \d+", f"- Entity pages: {ent_total}", updated)
        updated = _re.sub(r"- Concept pages: \d+", f"- Concept pages: {con_total}", updated)
        updated = _re.sub(r"- Last updated: .+", f"- Last updated: {date_str}", updated)
        updated = self._update_frontmatter(updated, "source_count", str(src_total))
        updated = self._update_frontmatter(updated, "article_count", str(ent_total + con_total))

        with self._writer.trusted_scope("kb_index_enrich"):
            self._writer.write(idx_path, updated)

    def _update_index_stats(self, slug: str) -> None:
        """Recount articles on disk and update .index.md frontmatter + Statistics section."""
        import re as _re
        base = f"knowledge/{slug}"
        idx_path = f"{base}/wiki/.index.md"
        if not self._reader.exists(idx_path):
            return
        src_count = len([f for f in self._reader.list_files(f"{base}/library", "**/*") if f.name != ".gitkeep"])
        ent_count = len(self._list_wiki_articles(f"{base}/wiki/entities"))
        con_count = len(self._list_wiki_articles(f"{base}/wiki/concepts"))
        # Count source pages across both legacy (source_summary/) and current (sources/) dirs
        src_pages = set()
        for sd in ("sources", "source_summary"):
            src_pages.update(f.stem for f in self._list_wiki_articles(f"{base}/wiki/{sd}"))
        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

        doc = self._reader.read(idx_path)
        idx = doc.raw
        idx = self._update_frontmatter(idx, "source_count", str(src_count))
        idx = self._update_frontmatter(idx, "article_count", str(ent_count + con_count))
        # Update Statistics section
        idx = _re.sub(r"- Sources ingested: \d+", f"- Sources ingested: {src_count}", idx)
        idx = _re.sub(r"- Entity pages: \d+", f"- Entity pages: {ent_count}", idx)
        idx = _re.sub(r"- Concept pages: \d+", f"- Concept pages: {con_count}", idx)
        idx = _re.sub(r"- Last updated: .+", f"- Last updated: {date_str}", idx)
        self._writer.write(idx_path, idx)

    # ── KB Management ���─

    def create_kb(
        self,
        topic: str,
        *,
        description: str = "",
        focus_questions: list[str] | None = None,
        source_types: list[str] | None = None,
        notes: str = "",
    ) -> dict:
        slug = topic.lower().replace(" ", "-")
        base = f"knowledge/{slug}"
        now = datetime.now().strftime("%Y-%m-%d %H:%M")

        # KB creation is user-initiated — wrap all scaffold writes in a
        # trusted scope so the VaultWriter runtime guard passes them.
        # Wiki/ scaffolding uses the canonical v3 7-bucket L1 taxonomy
        # (areas/projects/knowledge/entities/digests/workflows/reference)
        # — NOT the legacy v1 layout (concepts/sources/synthesis/decisions).
        # Locked by FIXED_L1_SLUGS in kb/taxonomy.py; the ``# arch:deterministic``
        # marker on that constant is the architectural source of truth.
        with self._writer.trusted_scope("kb_create"):
            self._writer.write(f"{base}/inbox/.gitkeep", "")
            self._writer.write(f"{base}/library/.gitkeep", "")
            self._writer.write(f"{base}/wiki/.index.md", _INDEX_TEMPLATE.format(topic=topic, date=now))
            from agntspace.kb.taxonomy import FIXED_L1_SLUGS
            for l1_slug in FIXED_L1_SLUGS:
                self._writer.write(f"{base}/wiki/{l1_slug}/.gitkeep", "")
            self._writer.write(f"{base}/output/.gitkeep", "")

            # Build enriched SCHEMA.md from wizard fields
            schema = _SCHEMA_TEMPLATE.format(topic=topic)
            if description:
                schema = schema.replace(
                    "<!-- What is this knowledge base about? What questions should it answer? -->",
                    description,
                )
            if focus_questions:
                fq_lines = "\n".join(f"- {q}" for q in focus_questions)
                schema = schema.replace(
                    "## Conventions",
                    f"## Focus Questions\n{fq_lines}\n\n## Conventions",
                )
            if source_types:
                st_lines = "\n".join(f"- **{t}**" for t in source_types)
                schema = schema.replace(
                    "## Notes\n<!-- Domain-specific instructions for the agent -->",
                    f"## Expected Source Types\n{st_lines}\n\n## Notes\n{notes if notes else '<!-- Domain-specific instructions for the agent -->'}",
                )
            elif notes:
                schema = schema.replace(
                    "<!-- Domain-specific instructions for the agent -->",
                    notes,
                )

            self._writer.write(f"{base}/SCHEMA.md", schema)
            self._write_compile_state(slug, {"last_ingest": None, "last_compile": None, "processed_hashes": {}})
            self._append_log(slug, "create", f"Knowledge base created: {topic}")

        # arch:short-ttl-cache (Phase 0.1) — new KB means list_kbs() result
        # changed; drop cache so the next read picks it up immediately.
        self.invalidate_kb_list_cache()
        return {"topic": topic, "slug": slug, "path": base}

    def delete_kb(self, slug: str) -> dict:
        """Delete a knowledge base and clean up all references."""
        import shutil

        kb_path = self._resolve(f"knowledge/{slug}")
        if not kb_path.is_dir():
            raise FileNotFoundError(f"KB not found: {slug}")

        # Count articles and sources before deleting
        article_count = 0
        for sd in _WIKI_SUBDIRS:
            article_count += len(self._list_wiki_articles(f"knowledge/{slug}/wiki/{sd}"))
        source_count = len([
            f for f in self._reader.list_files(f"knowledge/{slug}/library", "**/*")
            if f.name != ".gitkeep"
        ])

        # Delete the entire KB folder
        shutil.rmtree(kb_path)

        # Clean up bibliography entries
        bib_cleaned = 0
        bib_path = self._resolve("knowledge/bibliography.json")
        if bib_path.is_file():
            try:
                entries = json.loads(bib_path.read_text(encoding="utf-8"))
                before = len(entries)
                entries = [e for e in entries if e.get("kb_slug") != slug]
                bib_cleaned = before - len(entries)
                if bib_cleaned > 0:
                    bib_path.write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")
            except Exception:
                log.warning("Failed to clean bibliography for deleted KB %s", slug)

        # Clean up project references
        projects_updated = self._remove_kb_from_projects(slug)

        # arch:short-ttl-cache (Phase 0.1) — KB removed from disk; drop
        # cache so a cleanup tick doesn't keep returning the deleted slug.
        self.invalidate_kb_list_cache()
        return {
            "slug": slug,
            "deleted_articles": article_count,
            "deleted_sources": source_count,
            "bibliography_cleaned": bib_cleaned,
            "projects_updated": projects_updated,
        }

    def rename_kb(self, slug: str, new_title: str) -> dict:
        """Rename a knowledge base (folder + all references)."""
        import re as _re
        import shutil

        old_path = self._resolve(f"knowledge/{slug}")
        if not old_path.is_dir():
            raise FileNotFoundError(f"KB not found: {slug}")

        new_slug = _re.sub(r"[^a-z0-9-]", "", new_title.lower().replace(" ", "-")).strip("-")
        if not new_slug:
            raise ValueError("Invalid title — produces empty slug")

        new_path = self._resolve(f"knowledge/{new_slug}")
        if new_path.exists():
            raise ValueError(f"KB already exists: {new_slug}")

        # Get old title from index
        idx_rel = f"knowledge/{slug}/wiki/.index.md"
        old_title = slug.replace("-", " ").title()
        if self._reader.exists(idx_rel):
            doc = self._reader.read(idx_rel)
            old_title = doc.metadata.get("title", old_title)

        # Rename the folder
        shutil.move(str(old_path), str(new_path))

        # Update _index.md title inside the KB
        new_idx_path = new_path / "wiki" / ".index.md"
        if new_idx_path.is_file():
            content = new_idx_path.read_text(encoding="utf-8")
            # Update frontmatter title
            content = _re.sub(
                r'^title:\s*".*?"',
                f'title: "{new_title} — Index"',
                content, count=1, flags=_re.MULTILINE,
            )
            # Update heading
            content = _re.sub(
                r"^# .+ — Knowledge Base",
                f"# {new_title} — Knowledge Base",
                content, count=1, flags=_re.MULTILINE,
            )
            new_idx_path.write_text(content, encoding="utf-8")

        # Update bibliography entries
        bib_updated = 0
        bib_path = self._resolve("knowledge/bibliography.json")
        if bib_path.is_file():
            try:
                entries = json.loads(bib_path.read_text(encoding="utf-8"))
                for e in entries:
                    if e.get("kb_slug") == slug:
                        e["kb_slug"] = new_slug
                        bib_updated += 1
                if bib_updated > 0:
                    bib_path.write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")
            except Exception:
                log.warning("Failed to update bibliography for renamed KB %s -> %s", slug, new_slug)

        # Update project references
        projects_updated = self._rename_kb_in_projects(slug, new_slug)

        # arch:short-ttl-cache (Phase 0.1) — slug + title changed; drop
        # cache so the next read shows the new identity immediately.
        self.invalidate_kb_list_cache()
        return {
            "old_slug": slug,
            "new_slug": new_slug,
            "old_title": old_title,
            "new_title": new_title,
            "bibliography_updated": bib_updated,
            "projects_updated": projects_updated,
        }

    def _remove_kb_from_projects(self, kb_slug: str) -> list[str]:
        """Remove a KB slug from linked_kbs in all PROJECT.md files."""
        import frontmatter as fm

        updated = []
        projects_dir = self._resolve("projects")
        if not projects_dir.is_dir():
            return updated
        for child in projects_dir.iterdir():
            if not child.is_dir():
                continue
            project_file = child / "PROJECT.md"
            if not project_file.is_file():
                continue
            try:
                post = fm.load(str(project_file))
                linked = post.metadata.get("linked_kbs") or []
                if kb_slug in linked:
                    linked = [k for k in linked if k != kb_slug]
                    post.metadata["linked_kbs"] = linked
                    project_file.write_text(fm.dumps(post), encoding="utf-8")
                    updated.append(child.name)
            except Exception:
                log.warning("Failed to update project %s for KB cleanup", child.name)
        return updated

    def _rename_kb_in_projects(self, old_slug: str, new_slug: str) -> list[str]:
        """Replace old KB slug with new in linked_kbs across all PROJECT.md files."""
        import frontmatter as fm

        updated = []
        projects_dir = self._resolve("projects")
        if not projects_dir.is_dir():
            return updated
        for child in projects_dir.iterdir():
            if not child.is_dir():
                continue
            project_file = child / "PROJECT.md"
            if not project_file.is_file():
                continue
            try:
                post = fm.load(str(project_file))
                linked = post.metadata.get("linked_kbs") or []
                if old_slug in linked:
                    linked = [new_slug if k == old_slug else k for k in linked]
                    post.metadata["linked_kbs"] = linked
                    project_file.write_text(fm.dumps(post), encoding="utf-8")
                    updated.append(child.name)
            except Exception:
                log.warning("Failed to update project %s for KB rename", child.name)
        return updated

    def list_kbs(self) -> list[dict]:
        """Return all knowledge bases with article + source counts.

        arch:short-ttl-cache — Phase 0.1 (2026-05-04). Reads return a cached
        list inside ``_kb_list_cache_ttl`` (30 s) since the underlying FS
        walk is ~1 s on a 3-KB / 1700-article vault. Invalidated explicitly
        by ``invalidate_kb_list_cache()`` on every mutation that could
        change the result (create/delete/rename + ingest/compile completion
        that changes article + source counts). Mutations win immediately;
        the TTL is the safety net for missed invalidations.

        Single-flight via the lock — N concurrent first-callers don't each
        run the FS walk in parallel under GIL contention.
        """
        # Fast path — fresh cache, no lock needed (read of a single dict
        # value is atomic enough; the lock matters for the build path
        # where we'd otherwise duplicate the FS walk).
        cached = self._kb_list_cache
        if cached is not None and (time.time() - self._kb_list_cache_at) < self._kb_list_cache_ttl:
            return cached

        with self._kb_list_cache_lock:
            # Re-check after acquiring the lock — another thread may
            # have populated the cache while we were waiting.
            cached = self._kb_list_cache
            if cached is not None and (time.time() - self._kb_list_cache_at) < self._kb_list_cache_ttl:
                return cached

            kbs = self._compute_kb_list()
            self._kb_list_cache = kbs
            self._kb_list_cache_at = time.time()
            return kbs

    def _compute_kb_list(self) -> list[dict]:
        """Synchronous FS walk that produces the KB list. Cached by
        ``list_kbs``; never call directly except from tests / cache rebuild.
        """
        kbs = []
        seen_slugs: set[str] = set()
        try:
            files = self._reader.list_files("knowledge", "**/wiki/.index.md")
        except Exception:
            return []
        for f in files:
            # Skip archived copies
            f_str = str(f).replace("\\", "/")
            if "/.archives/" in f_str:
                continue
            try:
                parts = f_str.split("/")
                kb_idx = next(
                    i for i, p in enumerate(parts)
                    if p in ("knowledge", "agntspace-knowledge")
                )
                slug = parts[kb_idx + 1]
                if slug in seen_slugs:
                    continue
                seen_slugs.add(slug)
                doc = self._reader.read(f"knowledge/{slug}/wiki/.index.md")
                lib = self._reader.list_files(f"knowledge/{slug}/library", "**/*")
                wiki = self._reader.list_files(f"knowledge/{slug}/wiki", "**/*.md")
                kbs.append({
                    "slug": slug,
                    "title": doc.metadata.get("title", slug),
                    "sources": len([r for r in lib if r.name != ".gitkeep"]),
                    "articles": len([w for w in wiki if not w.name.startswith(("_", "."))
                                     and "/.history/" not in str(w).replace("\\", "/")
                                     and "/.archives/" not in str(w).replace("\\", "/")]),
                    "updated": doc.metadata.get("updated", ""),
                })
            except Exception:
                continue
        return kbs

    def invalidate_kb_list_cache(self) -> None:
        """Drop the cached KB list so the next ``list_kbs()`` rebuilds.

        Called explicitly from every mutation that could change the result:
        ``create_kb``, ``delete_kb``, ``rename_kb``, ``rename_default_kb_folder``,
        and from ``ingest()`` / ``compile_wiki()`` completion paths since
        article + source counts change. Cheap (just clears the dict) so
        callers can fire it freely without performance concern.

        Also fans out to every registered downstream subscriber so other
        in-process caches (wiki_stats response cache, etc.) invalidate
        in lockstep. Subscriber exceptions swallowed.
        """
        # No lock needed — assignment of a single attribute is atomic in
        # CPython (GIL). A racing reader either sees the old cache (returns
        # stale by one tick) or the new None (rebuilds). Both safe.
        self._kb_list_cache = None
        self._kb_list_cache_at = 0.0
        for cb in list(self._invalidation_subscribers):
            try:
                cb()
            except Exception:
                log.debug("kb cache invalidation subscriber raised", exc_info=True)

    def subscribe_invalidation(self, callback) -> None:
        """Register a zero-arg callback fired on every cache invalidation.

        Mirrors a 1-method pub/sub bus. Used by the route layer to wire
        the wiki_stats response cache to KB mutations originating from
        background tasks (watcher → ingest → compile) where the route
        cache layer can't observe the write directly.

        Idempotent — registering the same callback twice still only fires
        once because we don't dedupe; callers should register from a known
        wiring point (lifespan / main.py) rather than from request paths.
        """
        if callable(callback):
            self._invalidation_subscribers.append(callback)

    # ── Phase 4.5: source-page provenance walker ──────────────────────

    def list_source_records(self, slug: str | None = None) -> list[dict]:
        """Walk ``wiki/sources/*.md`` across KBs and return provenance records.

        Each record carries the fields ``propose_extractor_upgrades`` needs
        (``path``, ``type_name``, ``extractor_id``) plus extras the UI will
        want (``kb``, ``filename``, ``extractor_version``, ``source_type``,
        ``date_updated``). Sources without an ``extractor_id`` frontmatter
        field (ingested before Phase 4.5 wired provenance into the template)
        are INCLUDED with an empty ``extractor_id`` so the upgrade-proposals
        function skips them silently — they represent the "unknown history"
        bucket that a future reingest pass will fill in.

        ``slug=None`` walks every KB; passing a slug scopes to that KB.
        Excludes ``.history/``, ``.archives/`` (internal bookkeeping) and
        ``quarantine/`` / ``.quarantine/`` (failed-ingest user content)
        by path. The dot and non-dot quarantine names are both excluded
        so a half-migrated vault behaves correctly.
        """
        records: list[dict] = []
        kb_slugs: list[str] = []
        if slug is not None:
            kb_slugs = [slug]
        else:
            for kb in self.list_kbs():
                if isinstance(kb, dict) and kb.get("slug"):
                    kb_slugs.append(kb["slug"])

        for kb_slug in kb_slugs:
            sources_dir = self._resolve(f"knowledge/{kb_slug}/wiki/sources")
            if not sources_dir.is_dir():
                continue
            for src in sources_dir.rglob("*.md"):
                # Filter out historical / archived copies so we only report
                # the LIVE source page for a given filename.
                posix = str(src).replace("\\", "/")
                if any(
                    f"/{x}/" in posix
                    for x in (".history", ".archives", ".quarantine", "quarantine")
                ):
                    continue
                try:
                    logical = f"knowledge/{kb_slug}/wiki/sources/{src.relative_to(sources_dir).as_posix()}"
                    doc = self._reader.read(logical)
                except Exception:
                    continue
                meta = doc.metadata or {}
                records.append({
                    "kb": kb_slug,
                    "path": logical,
                    "filename": str(meta.get("source_file") or ""),
                    "type_name": str(meta.get("type_name") or ""),
                    "extractor_id": str(meta.get("extractor_id") or ""),
                    "extractor_version": str(meta.get("extractor_version") or ""),
                    "source_type": str(meta.get("category") or meta.get("source_type") or ""),
                    "date_updated": str(meta.get("date_updated") or ""),
                })
        return records

    async def reextract_source(
        self,
        kb_slug: str,
        source_slug: str,
        extractor_id: str = "",
    ) -> dict:
        """Re-run extraction on one source using a different tier.

        Phase 4.75 of decisions.md §2026-04-18. Scope is deliberately tight:
        only the raw-extraction text + provenance frontmatter update, NOT
        a full re-ingest (no re-classification, no entity/concept re-extraction,
        no wiki compile). The target use case: user clicks "re-ingest with
        OCR" on a scanned PDF, we run `pdf_pdfplumber_ocr`, append the new
        text to the source page, stamp new provenance. Full pipeline re-run
        remains an explicit ``POST /api/kb/{slug}/reingest`` action.

        Returns a result dict with keys: ``ok``, ``error``, ``kb``, ``source``,
        ``extractor_id``, ``extractor_version``, ``cost_tier``, ``fidelity``,
        ``element_count``, ``library_path``.

        ``extractor_id=""`` picks the best upgrade target for this source
        type via ``ExtractionSelector`` (highest fidelity within budget).
        An explicit id bypasses the selector — used when the UI knows
        which tier the user picked.
        """
        base = f"knowledge/{kb_slug}"
        source_path = f"{base}/wiki/sources/{source_slug}.md"
        if not self._reader.exists(source_path):
            return {"ok": False, "error": f"Source page not found: {source_path}"}

        doc = self._reader.read(source_path)
        meta = dict(doc.metadata or {})

        # Resolve the original file's physical path from the source page's
        # frontmatter. ``library_path`` is written as a relative path like
        # ``../../library/{taxonomy}/file.pdf`` (relative to the source
        # page's own location inside wiki/sources/). Rebuild the absolute
        # physical path by walking that back to the KB root.
        lib_rel = str(meta.get("library_path") or "").strip()
        if not lib_rel:
            return {"ok": False, "error": "Source page missing library_path frontmatter"}

        # Normalise — strip any leading ``../../`` that goes past the KB root.
        # The source page lives at knowledge/{kb}/wiki/sources/{slug}.md, so
        # two ``../`` segments point at the KB root. Beyond that we refuse.
        lib_clean = lib_rel.replace("\\", "/")
        while lib_clean.startswith("../"):
            lib_clean = lib_clean[3:]
        abs_file = self._resolve(f"{base}/{lib_clean}")
        if not abs_file.is_file():
            return {
                "ok": False,
                "error": f"Original file not found at {lib_clean}",
                "library_path": lib_rel,
            }

        # Resolve the spec for this file. Prefer the recorded type_name
        # (Phase 4.5+ ingest wrote it); fall back to extension-based
        # resolution so legacy sources still work.
        type_name = str(meta.get("type_name") or "").strip()
        spec = None
        if type_name:
            spec = self._file_types.get_spec(type_name)
        if spec is None:
            spec = self._file_types.resolve_type(abs_file)
        if spec is None:
            return {
                "ok": False,
                "error": f"No FileTypeSpec found for {abs_file.name}",
                "library_path": lib_rel,
            }

        # Pick the extractor. Explicit id wins; otherwise ExtractionSelector
        # returns the highest-fidelity binding that fits the budget.
        from agntspace.kb.file_types import ExtractionSelector
        selector = ExtractionSelector()
        if extractor_id:
            binding = spec.find_binding(extractor_id)
            if binding is None and extractor_id in self._file_types._extractors:
                # Caller asked for a registered extractor that isn't in the
                # ladder — honour via the registry's extract_id kwarg path.
                pass
            elif binding is None:
                return {
                    "ok": False,
                    "error": f"Unknown extractor '{extractor_id}' for type '{spec.type_name}'",
                }
        else:
            binding = selector.select(spec, max_cost_tier="reasoning")
            extractor_id = binding.extractor

        # Run the new extraction. The registry wrapper stamps provenance
        # with cost_tier + fidelity automatically.
        context = {
            "llm": self._llm,
            "describe_image": getattr(self, "_describe_image", None),
            "vision_timeout": 120,
        }
        result = await self._file_types.extract(
            abs_file, spec, context, extractor_id=extractor_id,
        )

        if result.provenance.get("error"):
            return {
                "ok": False,
                "error": f"Extraction failed: {result.provenance.get('error')}",
                "library_path": lib_rel,
                "extractor_id": extractor_id,
            }

        # Rewrite the source page: preserve the existing body, replace
        # provenance frontmatter with the new extractor metadata, and
        # APPEND a new "## Re-extracted Content" section with the fresh
        # element text. This keeps the original summary + concepts intact
        # (those came from the classify LLM prompt which we're NOT re-running)
        # while making the richer extraction available for the next compile.
        body = doc.content or ""

        # Update provenance fields on the frontmatter dict, then re-serialise.
        import frontmatter as _fm
        meta["type_name"] = str(result.provenance.get("type_name") or spec.type_name)
        meta["extractor_id"] = str(result.provenance.get("extractor_id") or extractor_id)
        meta["extractor_version"] = str(result.provenance.get("extractor_version") or "")
        meta["date_updated"] = datetime.now(UTC).date().isoformat()

        # Clip and tag the new body — drop any prior re-extraction section
        # so re-running the upgrade doesn't pile up duplicate sections.
        marker = "\n\n## Re-extracted Content"
        if marker in body:
            body = body.split(marker, 1)[0].rstrip() + "\n"

        cost_tier = result.provenance.get("cost_tier", "fast")
        fidelity = result.provenance.get("fidelity", "medium")
        new_text = result.as_text()
        body += (
            f"\n\n## Re-extracted Content\n\n"
            f"*Extracted via `{extractor_id}` (tier: {cost_tier}, fidelity: {fidelity}) "
            f"on {meta['date_updated']}.*\n\n"
            f"{new_text}\n"
        )

        post = _fm.Post(body, **meta)
        new_page = _fm.dumps(post) + "\n"
        self._writer.write(source_path, new_page, contract_action="modify_wiki")

        return {
            "ok": True,
            "kb": kb_slug,
            "source": source_slug,
            "library_path": lib_rel,
            "extractor_id": extractor_id,
            "extractor_version": meta["extractor_version"],
            "cost_tier": cost_tier,
            "fidelity": fidelity,
            "element_count": len(result.elements),
        }

    def get_kb_status(self, slug: str) -> dict:
        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        doc = self._reader.read(f"{base}/wiki/.index.md")
        raw = [r.name for r in self._reader.list_files(f"{base}/inbox", "**/*") if r.name != ".gitkeep"]
        lib = [s.name for s in self._reader.list_files(f"{base}/library", "**/*") if s.name != ".gitkeep"]
        # Recursive glob (**/*.md) so post-scope-2-migration articles at
        # deeper paths (e.g. wiki/sources/articles/news/X.md) are still
        # counted. Pre-migration flat layouts also work — `**/*.md` matches
        # both wiki/sources/X.md AND wiki/sources/articles/news/X.md.
        entities = [w.name for w in self._reader.list_files(f"{base}/wiki/entities", "**/*.md")]
        concepts = [w.name for w in self._reader.list_files(f"{base}/wiki/concepts", "**/*.md")]
        sources = [w.name for w in self._reader.list_files(f"{base}/wiki/sources", "**/*.md")]
        source_summaries = [w.name for w in self._reader.list_files(f"{base}/wiki/source_summary", "**/*.md")]
        sources = list(set(sources + source_summaries))  # merge legacy + current
        state = self._read_compile_state(slug)

        return {
            "slug": slug, "title": doc.metadata.get("title", slug),
            "raw_pending": raw, "library": lib,
            "entity_pages": entities, "concept_pages": concepts, "source_pages": sources,
            "raw_count": len(raw), "library_count": len(lib),
            "entity_count": len(entities), "concept_count": len(concepts), "source_count": len(sources),
            "last_ingest": state.get("last_ingest"), "last_compile": state.get("last_compile"),
            "has_schema": self._reader.exists(f"{base}/SCHEMA.md"),
        }

    # ── Delete / Reset ──

    def delete_article(self, slug: str, article_slug: str) -> dict:
        """Delete a single wiki article from a KB. Returns info about what was deleted."""
        base = f"knowledge/{slug}/wiki"
        deleted = []
        for subdir in _WIKI_SUBDIRS:
            path = f"{base}/{subdir}/{article_slug}.md"
            full = self._resolve(path)
            log.debug("delete_article: checking %s (exists=%s)", full, full.exists())
            if full.exists():
                full.unlink()
                deleted.append(f"{subdir}/{article_slug}")
                log.info("Deleted wiki article: %s", full)
        if not deleted:
            log.warning("delete_article: no files found for %s in KB %s", article_slug, slug)

        # Also remove from .index.md and update stats
        if deleted:
            idx_path = f"knowledge/{slug}/wiki/.index.md"
            if self._reader.exists(idx_path):
                doc = self._reader.read(idx_path)
                idx = doc.raw
                for d in deleted:
                    idx = idx.replace(f"- [[{d}]]\n", "")
                    idx = idx.replace(f"- [[{article_slug}]]\n", "")
                self._writer.write(idx_path, idx)
            self._update_index_stats(slug)
            self._append_log(slug, "delete", f"Deleted article: {article_slug}")

            # Rebuild graph to remove orphaned nodes and stale triples
            _graph = getattr(self, "_graph", None)
            if _graph and hasattr(_graph, "build"):
                try:
                    _graph.build()
                except Exception:
                    log.debug("Graph rebuild after delete failed", exc_info=True)

        return {"slug": slug, "article": article_slug, "deleted": deleted}

    # ------------------------------------------------------------------
    # Article CRUD helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _filename_stem_to_slug(stem: str) -> str:
        """Convert a filename stem to the slug form that matches
        ``_find_article_by_slug``'s internal lookup regex.

        Shared between the lookup itself and the migration call sites
        that pass a slug-form fallback when no frontmatter ``slug:``
        field is present. Without this round-trip, callers passing the
        raw stem (e.g. ``Source: $KC You know this stock...``) hit the
        "Article not found" branch even when the file IS on disk —
        because the lookup re-slugifies internally and the comparison
        fails on case + special chars + spaces.
        """
        import re as _re
        return _re.sub(r"[^a-z0-9]+", "-", stem.lower()).strip("-")

    def _find_article_by_slug(self, slug: str) -> tuple[str, str, Path, dict, str] | None:
        """Find a wiki article by slug across all KBs.

        Returns (kb_slug, subdir, filepath, metadata, content) or None.
        Searches filename-stem match FIRST (cheap — no read), falls back to
        frontmatter ``slug`` field scan.

        **Performance**: previously this read every file's frontmatter on
        every call (O(N) reads). With ~1693 articles, the migration's per-
        item ``update_article`` chain became O(N²) — 2.8M reads worst-case.
        Filename-first means: O(N) glob + zero reads for the common case
        (caller passes ``_filename_stem_to_slug(stem)`` as the slug-form
        fallback after the 2026-04-27 slug-fix). Frontmatter-slug callers
        still pay O(N) reads in the slow path. Fixes the "server hijacking
        during migration" gap from the same session.
        """
        try:
            files = self._reader.list_files("knowledge", "**/wiki/**/*.md")
        except Exception:
            return None

        # FAST PATH: filename-stem scan, no reads.
        # The migration uses _filename_stem_to_slug as the slug-form
        # fallback — almost every call lands here.
        candidates: list[Path] = []
        for f in files:
            f_str = str(f).replace("\\", "/")
            if "/.archives/" in f_str or "/.history/" in f_str:
                continue
            if f.name.startswith(("_", ".")):
                continue

            stem_slug = self._filename_stem_to_slug(f.stem)
            if stem_slug == slug:
                # Found by filename — read this ONE file for the return tuple.
                try:
                    rel = self._to_logical(f)
                    doc = self._reader.read(rel)
                except Exception:
                    return None
                return self._build_find_article_result(f, rel, doc.metadata, doc.content)
            candidates.append(f)

        # SLOW PATH: scan frontmatter ``slug:`` field across the rest of the
        # candidates. Only enters when a caller passed a slug NOT derivable
        # from any filename — rare post-slug-fix.
        for f in candidates:
            try:
                rel = self._to_logical(f)
                doc = self._reader.read(rel)
            except Exception:
                continue
            if doc.metadata.get("slug", "") == slug:
                return self._build_find_article_result(f, rel, doc.metadata, doc.content)

        return None

    @staticmethod
    def _build_find_article_result(
        filepath: Path, rel_path: str, meta: dict, content: str,
    ) -> tuple[str, str, Path, dict, str]:
        """Extract (kb_slug, subdir, filepath, meta, content) from a found
        wiki article. Pure helper — no I/O. Shared between the fast and
        slow paths of ``_find_article_by_slug`` so the return shape is
        consistent."""
        parts = rel_path.replace("\\", "/").split("/")
        try:
            kb_idx = parts.index("knowledge")
            kb_slug = parts[kb_idx + 1]
        except (ValueError, IndexError):
            kb_slug = ""
        try:
            wiki_idx = parts.index("wiki")
            if wiki_idx + 2 < len(parts):
                subdir = parts[wiki_idx + 1]
            else:
                subdir = ""
        except (ValueError, IndexError):
            subdir = ""
        return (kb_slug, subdir, filepath, meta, content)

    def create_article(
        self,
        kb_slug: str,
        title: str,
        content: str,
        entity_type: str = "concept",
        subdir: str | None = None,
    ) -> dict:
        """Create a new wiki article in a knowledge base.

        Returns {"slug", "title", "kb", "path"}.
        Raises ValueError on duplicate slug.
        """
        import re as _re
        from datetime import date

        from agntspace.vault.writer import title_to_filename

        # Determine subdir
        if not subdir:
            if entity_type in ("person", "organization"):
                subdir = "entities"
            else:
                subdir = "concepts"

        # Generate slug
        slug = _re.sub(r"[^a-z0-9-]", "", title.lower().replace(" ", "-")).strip("-")
        if not slug:
            slug = "untitled"

        # Check for duplicate slug across this KB's wiki

        wiki_base = self._resolve(f"knowledge/{kb_slug}/wiki")
        if wiki_base.exists():
            for sd in _WIKI_SUBDIRS:
                sd_path = wiki_base / sd
                if not sd_path.exists():
                    continue
                for f in sd_path.glob("*.md"):
                    if f.name.startswith(("_", ".")):
                        continue
                    stem_slug = _re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-")
                    if stem_slug == slug:
                        raise ValueError(f"Article with slug '{slug}' already exists in KB '{kb_slug}'")
                    # Also check frontmatter slug
                    try:
                        rel = self._to_logical(f)
                        doc = self._reader.read(rel)
                        if doc.metadata.get("slug") == slug:
                            raise ValueError(f"Article with slug '{slug}' already exists in KB '{kb_slug}'")
                    except ValueError:
                        raise
                    except Exception:
                        pass
            # Re-check: the inner ValueError may have been caught by the bare except
            # Actually the except clause above only catches FileNotFoundError and ValueError
            # Let me restructure — check root wiki dir too
            for f in wiki_base.glob("*.md"):
                if f.name.startswith(("_", ".")):
                    continue
                stem_slug = _re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-")
                if stem_slug == slug:
                    raise ValueError(f"Article with slug '{slug}' already exists in KB '{kb_slug}'")

        filename = title_to_filename(title)
        relative_path = f"knowledge/{kb_slug}/wiki/{subdir}/{filename}.md"

        metadata = {
            "title": title,
            "slug": slug,
            "entity_type": entity_type,
            "provenance": "manual",
            "author": "user",
            "date": date.today().isoformat(),
        }

        self._writer.write(relative_path, content, metadata, versioned=True)
        self._append_log(kb_slug, "create", f"Created article: {title} ({slug})")

        return {"slug": slug, "title": title, "kb": kb_slug, "path": relative_path}

    def update_article(
        self,
        slug: str,
        content: str | None = None,
        metadata_updates: dict | None = None,
    ) -> dict:
        """Update an existing wiki article (content and/or metadata).

        Finds the article by slug across all KBs.
        Returns {"slug", "title", "kb", "path", "updated_fields"}.
        Raises FileNotFoundError if not found.
        """
        from datetime import date

        found = self._find_article_by_slug(slug)
        if not found:
            raise FileNotFoundError(f"Article not found: {slug}")

        kb_slug, subdir, filepath, meta, existing_content = found
        rel_path = self._to_logical(filepath)

        updated_fields: list[str] = []

        # Update content
        if content is not None:
            existing_content = content
            updated_fields.append("content")

        # Merge metadata updates
        if metadata_updates:
            for k, v in metadata_updates.items():
                meta[k] = v
                updated_fields.append(k)

        # Always set date_updated
        meta["date_updated"] = date.today().isoformat()

        self._writer.write(rel_path, existing_content, meta, versioned=True)
        self._append_log(kb_slug, "update", f"Updated article: {meta.get('title', slug)} ({slug})")

        return {
            "slug": slug,
            "title": meta.get("title", slug),
            "kb": kb_slug,
            "path": rel_path,
            "updated_fields": updated_fields,
        }

    def rename_article(self, slug: str, new_title: str) -> dict:
        """Rename a wiki article: new file, backlink rewriting, compile state update.

        Returns {"old_slug", "new_slug", "old_title", "new_title", "kb", "backlinks_updated"}.
        Raises FileNotFoundError if not found, ValueError on slug collision.
        """
        import re as _re
        from datetime import date

        from agntspace.vault.writer import title_to_filename

        found = self._find_article_by_slug(slug)
        if not found:
            raise FileNotFoundError(f"Article not found: {slug}")

        kb_slug, subdir, filepath, meta, content = found

        old_rel = self._to_logical(filepath)
        old_title = meta.get("title", filepath.stem)

        # Generate new slug
        new_slug = _re.sub(r"[^a-z0-9-]", "", new_title.lower().replace(" ", "-")).strip("-")
        if not new_slug:
            new_slug = "untitled"

        # Check for collision (skip if renaming to same slug)
        if new_slug != slug:
            collision = self._find_article_by_slug(new_slug)
            if collision:
                raise ValueError(f"Article with slug '{new_slug}' already exists")

        # Build new path
        new_filename = title_to_filename(new_title)
        if subdir:
            new_rel = f"knowledge/{kb_slug}/wiki/{subdir}/{new_filename}.md"
        else:
            new_rel = f"knowledge/{kb_slug}/wiki/{new_filename}.md"

        # Update metadata
        meta["title"] = new_title
        meta["slug"] = new_slug
        meta["date_updated"] = date.today().isoformat()

        # Write new file
        self._writer.write(new_rel, content, meta, versioned=True)

        # Delete old file
        if filepath.exists() and old_rel != new_rel:
            filepath.unlink()

        # --- Backlink rewriting across ALL KBs ---
        backlinks_updated = 0
        try:
            all_files = self._reader.list_files("knowledge", "**/wiki/**/*.md")
        except Exception:
            all_files = []

        for f in all_files:
            f_str = str(f).replace("\\", "/")
            if "/.archives/" in f_str or "/.history/" in f_str:
                continue
            if f.name.startswith(("_", ".")):
                continue
            # Skip the article we just wrote
            f_rel = self._to_logical(f)
            if f_rel == new_rel:
                continue

            try:
                doc = self._reader.read(f_rel)
                raw = doc.raw
            except Exception:
                continue

            updated_raw = raw
            # Replace [[Old Title]] with [[New Title]]
            if old_title and old_title != new_title:
                updated_raw = updated_raw.replace(f"[[{old_title}]]", f"[[{new_title}]]")
            # Replace [[old-slug]] with [[new-slug]]
            if slug != new_slug:
                updated_raw = updated_raw.replace(f"[[{slug}]]", f"[[{new_slug}]]")

            if updated_raw != raw:
                # Write the updated file directly (mechanical rewrite, no versioning)
                full_path = self._resolve(f_rel)
                full_path.write_text(updated_raw, encoding="utf-8")
                backlinks_updated += 1

        # --- Update compile state ---
        try:
            state = self._read_compile_state(kb_slug)
            sources = state.get("sources", {})
            changed = False
            for fname, info in sources.items():
                pages = info.get("produced_pages", [])
                new_pages = []
                for p in pages:
                    if p == old_rel:
                        new_pages.append(new_rel)
                        changed = True
                    else:
                        new_pages.append(p)
                info["produced_pages"] = new_pages
            if changed:
                self._write_compile_state(kb_slug, state)
        except Exception:
            log.warning("Failed to update compile state during rename", exc_info=True)

        # --- Update _index.md ---
        idx_path = f"knowledge/{kb_slug}/wiki/_index.md"
        try:
            if self._reader.exists(idx_path):
                doc = self._reader.read(idx_path)
                idx_raw = doc.raw
                updated_idx = idx_raw.replace(f"[[{old_title}]]", f"[[{new_title}]]")
                if slug != new_slug:
                    updated_idx = updated_idx.replace(f"[[{slug}]]", f"[[{new_slug}]]")
                if updated_idx != idx_raw:
                    self._writer.write(idx_path, updated_idx, versioned=False)
        except Exception:
            log.warning("Failed to update _index.md during rename", exc_info=True)

        self._append_log(
            kb_slug, "rename",
            f"Renamed article: {old_title} → {new_title} ({slug} → {new_slug}), "
            f"{backlinks_updated} backlinks updated",
        )

        return {
            "old_slug": slug,
            "new_slug": new_slug,
            "old_title": old_title,
            "new_title": new_title,
            "kb": kb_slug,
            "backlinks_updated": backlinks_updated,
        }

    def find_backlinks(self, slug: str) -> list[dict]:
        """Find all articles that link to the given article via [[wikilinks]].

        Returns list of {"slug", "title", "kb"} dicts.
        """
        import re as _re

        found = self._find_article_by_slug(slug)
        if not found:
            return []

        _kb_slug, _subdir, _filepath, meta, _content = found
        title = meta.get("title", "")

        backlinks: list[dict] = []

        try:
            all_files = self._reader.list_files("knowledge", "**/wiki/**/*.md")
        except Exception:
            return []

        for f in all_files:
            f_str = str(f).replace("\\", "/")
            if "/.archives/" in f_str or "/.history/" in f_str:
                continue
            if f.name.startswith(("_", ".")):
                continue

            try:
                rel = self._to_logical(f)
                doc = self._reader.read(rel)
                raw_content = doc.content
            except Exception:
                continue

            # Check for [[Title]] or [[slug]] references
            has_link = False
            if title and f"[[{title}]]" in raw_content:
                has_link = True
            if f"[[{slug}]]" in raw_content:
                has_link = True

            if has_link:
                art_slug = doc.metadata.get("slug") or _re.sub(
                    r"[^a-z0-9]+", "-", f.stem.lower()
                ).strip("-")
                parts = rel.split("/")
                try:
                    kb_idx = parts.index("knowledge")
                    art_kb = parts[kb_idx + 1]
                except (ValueError, IndexError):
                    art_kb = ""
                backlinks.append({
                    "slug": art_slug,
                    "title": doc.metadata.get("title", f.stem),
                    "kb": art_kb,
                })

        return backlinks

    def reset_wiki(self, slug: str) -> dict:
        """Delete ALL wiki articles for a KB and reset compile state. Keeps library/inbox intact."""

        base_rel = f"knowledge/{slug}/wiki"
        wiki_dir = self._resolve(f"knowledge/{slug}/wiki")

        if not wiki_dir.exists():
            return {"slug": slug, "deleted": 0, "message": "Wiki directory not found"}

        # Count articles before deletion
        deleted_count = 0
        for subdir in _WIKI_SUBDIRS:
            d = wiki_dir / subdir
            if d.exists():
                for f in d.glob("*.md"):
                    f.unlink()
                    deleted_count += 1

        # Reset .index.md to clean state (matching _INDEX_TEMPLATE structure)
        idx_path = wiki_dir / ".index.md"
        if idx_path.exists():
            title = slug.replace("-", " ").title()
            date_str = datetime.now().strftime('%Y-%m-%d')
            self._writer.write(f"{base_rel}/.index.md", _INDEX_TEMPLATE.format(
                topic=title, date=date_str,
            ).strip())

        # Reset .concepts.md
        concepts_path = wiki_dir / ".concepts.md"
        if concepts_path.exists():
            concepts_path.unlink()

        # Reset compile state so next compile starts fresh
        self._write_compile_state(slug, {"last_ingest": None, "last_compile": None, "processed_hashes": {}})

        self._append_log(slug, "reset", f"Wiki reset — deleted {deleted_count} articles")
        return {"slug": slug, "deleted": deleted_count}

    def reset_all_wikis(self) -> dict:
        """Reset wikis across ALL knowledge bases."""
        kbs = self.list_kbs()
        total = 0
        results = []
        for kb in kbs:
            r = self.reset_wiki(kb["slug"])
            total += r["deleted"]
            results.append(r)
        return {"kbs_reset": len(results), "total_deleted": total, "details": results}

    # ── Ingest ──

    async def find_drifted_sources(self, slug: str | None = None) -> dict:
        """Return source pages whose recorded language policy no longer matches
        the current effective policy (spec §19 item 3).

        Walks every source_summary page in the requested KB (or all KBs),
        reads its `content_language`, `output_language`, `language_policy`,
        and re-resolves the policy using the current skill config + schema
        + global config. Pages where the newly-resolved output_language or
        effective_policy differs from what was recorded are returned.

        Result:
            {
                "drifted": [
                    {
                        "kb": "general",
                        "source": "article.md",
                        "recorded": {"content_lang": ..., "output_lang": ..., "policy": ..., "source": ...},
                        "current":  {"content_lang": ..., "output_lang": ..., "policy": ..., "source": ...},
                    },
                    ...
                ],
                "scanned": N,
                "drifted_count": M,
            }
        """
        import frontmatter

        from agntspace.infra.language import resolve_languages

        kbs_to_scan: list[str] = []
        base_knowledge = self._resolve("knowledge")
        if slug:
            kbs_to_scan.append(slug)
        else:
            if base_knowledge.is_dir():
                for kb_dir in base_knowledge.iterdir():
                    if kb_dir.is_dir():
                        kbs_to_scan.append(kb_dir.name)

        # Precompute per-KB config so we don't re-read it per file
        _skill_lang_cfg: dict = {}
        if self._skill_loader and hasattr(self._skill_loader, "get_skill_config"):
            _skill_lang_cfg = self._skill_loader.get_skill_config(
                "kb-ingest", "language",
            ) or {}
        _global_policy = getattr(self, "_global_language_policy", None)
        _user_locale = getattr(self, "_user_locale", "en")

        drifted: list[dict] = []
        scanned = 0

        for kb_slug in kbs_to_scan:
            sources_dir = self._resolve(f"knowledge/{kb_slug}/wiki/sources")
            if not sources_dir.is_dir():
                continue
            _schema_meta = self._read_schema_meta(kb_slug)

            for source_file in sources_dir.glob("*.md"):
                if source_file.name.startswith((".", "_")):
                    continue
                try:
                    post = frontmatter.load(source_file)
                except Exception:
                    continue
                meta = dict(post.metadata or {})
                # Only audit source_summary pages
                if meta.get("entity_type") != "source_summary":
                    continue
                scanned += 1

                recorded_content = str(meta.get("content_language") or "")
                recorded_output = str(meta.get("output_language") or "")
                recorded_policy = str(meta.get("language_policy") or "")

                # Re-resolve using current config. We use the summary body
                # itself for detection since the original source may be
                # gone; body length is usually sufficient.
                new_content, new_output, new_policy, new_source = resolve_languages(
                    post.content,
                    source_meta=None,
                    skill_config=_skill_lang_cfg,
                    kb_schema=_schema_meta,
                    global_policy=_global_policy,
                    user_locale=_user_locale,
                )

                # Prefer the recorded content_lang as ground truth — we don't
                # want detection drift here, only policy drift.
                if recorded_content:
                    new_content = recorded_content
                    from agntspace.infra.language import resolve_output_language
                    # Re-apply policy with the trusted content_lang
                    # Walk the current chain manually to find winning policy
                    eff_policy = "source"
                    eff_source = "default"
                    if _global_policy:
                        eff_policy, eff_source = _global_policy, "config"
                    if _skill_lang_cfg.get("output_policy"):
                        eff_policy, eff_source = _skill_lang_cfg["output_policy"], "skill"
                    if _schema_meta.get("language_policy"):
                        eff_policy, eff_source = _schema_meta["language_policy"], "schema"
                    new_output = resolve_output_language(
                        recorded_content, eff_policy, _user_locale,
                    )
                    new_policy, new_source = eff_policy, eff_source

                if new_output != recorded_output or new_policy != recorded_policy:
                    drifted.append({
                        "kb": kb_slug,
                        "source": source_file.name,
                        "recorded": {
                            "content_lang": recorded_content,
                            "output_lang": recorded_output,
                            "policy": recorded_policy,
                            "source": str(meta.get("language_policy_source") or ""),
                        },
                        "current": {
                            "content_lang": new_content,
                            "output_lang": new_output,
                            "policy": new_policy,
                            "source": new_source,
                        },
                    })

        return {
            "drifted": drifted,
            "scanned": scanned,
            "drifted_count": len(drifted),
        }

    async def reingest_drifted_sources(self, slug: str | None = None) -> dict:
        """Re-ingest all source pages whose recorded language policy no
        longer matches the current effective policy (spec §19 item 3).

        Finds drifted sources via `find_drifted_sources`, then for each:
          1. Locates the original file in the KB library (by source_file meta)
          2. Copies it back into the KB inbox so the ingest pipeline picks it up
          3. Triggers `ingest(kb_slug)` once per affected KB

        Returns:
            {
                "drifted_count": N,
                "requeued": M,
                "kbs_ingested": [slug, ...],
                "errors": [...],
            }
        """
        import shutil

        drift_report = await self.find_drifted_sources(slug)
        drifted = drift_report["drifted"]

        if not drifted:
            return {
                "drifted_count": 0,
                "requeued": 0,
                "kbs_ingested": [],
                "errors": [],
            }

        requeued = 0
        errors: list[str] = []
        affected_kbs: set[str] = set()

        for entry in drifted:
            kb_slug = entry["kb"]
            source_name = entry["source"]
            try:
                # Read the source page to find the original library file
                source_path = self._resolve(
                    f"knowledge/{kb_slug}/wiki/sources/{source_name}"
                )
                if not source_path.is_file():
                    continue
                import frontmatter
                post = frontmatter.load(source_path)
                meta = dict(post.metadata or {})
                library_file = meta.get("source_file") or ""
                if not library_file:
                    errors.append(f"{kb_slug}/{source_name}: no source_file in frontmatter")
                    continue
                library_path = self._resolve(f"knowledge/{kb_slug}/library/{library_file}")
                if not library_path.is_file():
                    errors.append(f"{kb_slug}/{source_name}: library file missing ({library_file})")
                    continue
                inbox_dir = self._resolve(f"knowledge/{kb_slug}/inbox")
                inbox_dir.mkdir(parents=True, exist_ok=True)
                dest = inbox_dir / library_file
                if not dest.exists():
                    shutil.copy2(library_path, dest)
                requeued += 1
                affected_kbs.add(kb_slug)
            except Exception as exc:
                errors.append(f"{kb_slug}/{source_name}: {exc}")

        kbs_ingested: list[str] = []
        for kb_slug in sorted(affected_kbs):
            try:
                await self.ingest(kb_slug)
                kbs_ingested.append(kb_slug)
            except Exception as exc:
                errors.append(f"ingest({kb_slug}): {exc}")

        return {
            "drifted_count": len(drifted),
            "requeued": requeued,
            "kbs_ingested": kbs_ingested,
            "errors": errors,
        }

    def is_pipeline_frozen(self) -> bool:
        """True when the user has frozen ALL ingestion via Settings or API.

        Reads ``[pipeline].frozen`` from config.toml on every call so toggling
        in the UI takes effect immediately without a restart. Defaults to
        False (ingestion runs normally) when the settings service isn't wired
        or the key is absent — preserves pre-freeze behavior on every existing
        vault. Mirrors the watcher's ``is_paused()`` pattern (raw_watcher.py).

        This is the GLOBAL emergency lever — distinct from
        ``watcher.paused`` which only stops auto-discovery. When this returns
        True, ``ingest()`` short-circuits with ``IngestFrozenError`` BEFORE
        any work happens. Every entry point (watcher, work queue, agent tool,
        HTTP endpoint, plugin) hits the same chokepoint.
        """
        svc = self._settings_service
        if svc is None:
            return False
        try:
            return bool(svc.get_value("pipeline", "frozen", False))  # type: ignore[attr-defined]
        except Exception:
            return False

    async def ingest(self, slug: str) -> dict:
        """Process raw/ files: classify, extract, create source summary + wiki updates, move to library/.

        Single entry point for every ingest path (watcher, REST, work
        queue, agent tool). Owns three observability responsibilities
        (Rule #13): open a correlation scope, emit start/end activity
        events, and record a root librarian decision that per-file
        decisions chain to.

        Raises ``IngestFrozenError`` immediately when the global pipeline
        freeze flag is set — short-circuits BEFORE any locks, scopes, or
        side effects. The freeze gate is the load-bearing invariant of the
        "global stop ingestion" feature: every path that wants to ingest
        eventually calls this method, so checking here covers them all.
        """
        # Global freeze gate — fires BEFORE the lock + scope so frozen calls
        # don't even queue behind in-flight ingests. Emit a low-importance
        # activity event so the user sees "the agent tried to ingest while
        # frozen" in the activity log without spamming higher tiers.
        if self.is_pipeline_frozen():
            self._log_activity(
                "ingest_blocked_frozen",
                f"KB {slug}: ingest blocked — pipeline is frozen",
                {"slug": slug, "triggered_by": "from_queue" if self._called_from_queue else "direct"},
                importance="low",
            )
            raise IngestFrozenError(
                f"Pipeline is frozen — ingest({slug}) refused. "
                "Thaw via Settings → Inbox watcher → 'Freeze all ingestion' "
                "or PUT /api/settings/pipeline-freeze body {\"frozen\": false}.",
            )

        lock = self._ingest_locks.setdefault(slug, asyncio.Lock())
        if self._orchestrator and hasattr(self._orchestrator, "_active_tasks"):
            self._orchestrator._active_tasks["librarian"] = f"Ingesting sources into {slug}"

        _started_iso = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        self._log_activity(
            "ingest_started",
            f"KB {slug}: ingest batch started",
            {"slug": slug, "triggered_by": "from_queue" if self._called_from_queue else "direct"},
            importance="low",
        )

        try:
            async with self._scoped_pipeline("kb_ingest", "ingest"):
                async with lock:
                    result = await self._do_ingest(slug)
                _ingested_files = result.get("ingested", []) if isinstance(result, dict) else []
                _skipped_files = result.get("skipped", []) if isinstance(result, dict) else []
                self._log_activity(
                    "ingest_completed",
                    f"KB {slug}: ingested {len(_ingested_files)} file(s), skipped {len(_skipped_files)}",
                    {
                        "slug": slug,
                        "count": len(_ingested_files),
                        "files": _ingested_files[:20],
                        "skipped_count": len(_skipped_files),
                        "skipped": _skipped_files[:20],
                    },
                    importance="medium" if _ingested_files else "low",
                )
                # arch:short-ttl-cache (Phase 0.1) — sources count changed
                # for this KB. Invalidate so the next list_kbs() / wiki_stats
                # rebuild picks up the new totals immediately. Cheap.
                if _ingested_files:
                    self.invalidate_kb_list_cache()
                await self._record_decision(
                    action_type="ingest_batch",
                    action_target=f"kb/{slug}",
                    rationale=f"Ingest batch produced {len(_ingested_files)} source summaries",
                    details={
                        "slug": slug,
                        "count": len(_ingested_files),
                        "files": _ingested_files[:20],
                        "started_at": _started_iso,
                    },
                )
                # Auto-refresh structural graph overlay so the new
                # source nodes + triples appear without requiring a
                # manual /api/graph/build call. Phase A perf fix
                # (2026-05-06): walks vault.list_files("**/*.md") +
                # iterates every triple — heavy sync IO. Off-loop via
                # asyncio.to_thread so /api/health stays responsive
                # while the graph rebuild runs.
                graph = getattr(self, "_graph", None)
                if graph is not None and hasattr(graph, "refresh_structural_triples"):
                    try:
                        await asyncio.to_thread(graph.refresh_structural_triples)
                    except Exception:
                        log.debug("kb: refresh_structural_triples failed", exc_info=True)
                return result
        except Exception as exc:
            self._log_activity(
                "ingest_failed",
                f"KB {slug}: ingest batch raised {type(exc).__name__}",
                {"slug": slug, "error": str(exc)[:500]},
                importance="high",
            )
            await self._record_decision(
                action_type="ingest_batch",
                action_target=f"kb/{slug}",
                contract_result="failed",
                rationale=f"Ingest batch aborted: {type(exc).__name__}",
                details={"slug": slug, "error": str(exc)[:500]},
            )
            raise
        finally:
            if self._orchestrator and hasattr(self._orchestrator, "_active_tasks"):
                self._orchestrator._active_tasks.pop("librarian", None)

    async def _do_ingest(self, slug: str) -> dict:
        """Internal ingest implementation (holds per-KB lock)."""

        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Pipeline mode: suppress versioning for automated writes.
        # Guaranteed reset in finally block below — never leak True across calls.
        self._writer._pipeline_mode = True
        try:
            return await self._do_ingest_body(slug, base)
        finally:
            self._writer._pipeline_mode = False

    async def _do_ingest_body(self, slug: str, base: str) -> dict:
        """Main ingest body. Pipeline mode is managed by the caller."""
        from agntspace.llm.base import Message  # noqa: F401 — used by LLM helpers below

        # Fresh batch — clear the per-batch consecutive-crash counters so
        # the circuit breaker only trips on PATTERNS within one batch, not
        # cross-batch noise. The work queue's exponential backoff handles
        # the cross-batch retry behavior; the circuit breaker is for "this
        # batch's first 3 files all crashed identically — stop now".
        self._consecutive_crash_counts.clear()

        index_doc = self._reader.read(f"{base}/wiki/.index.md")
        index_content = index_doc.raw
        schema = self._read_schema(slug)
        state = self._read_compile_state(slug)

        # Skip both legacy ``.quarantine`` and visible ``quarantine`` —
        # ingest never touches files already parked there. The path check
        # uses ``/{name}/`` so we don't match a real KB or filename that
        # happens to contain "quarantine" as a substring.
        all_inbox = [
            f for f in self._reader.list_files(f"{base}/inbox", "**/*")
            if f.name != ".gitkeep"
            and "/.quarantine/" not in str(f).replace("\\", "/")
            and "/quarantine/" not in str(f).replace("\\", "/")
        ]
        raw_files = [f for f in all_inbox if not f.name.endswith(".source") and f.is_file()]
        if not raw_files:
            return {"slug": slug, "ingested": [], "skipped": [], "count": 0, "message": "raw/ is empty."}

        # Cap files per ingest call to keep individual cycles short.
        # Sort alphabetically for stable order; remaining files picked
        # up next cycle. Phase 2 (Rule 12): cap value lives in
        # ``kb-ingest/config/throughput.yaml`` so users can tune their
        # ingest pipeline without touching code.
        _max_per_ingest = self._load_throughput_cap("max_per_ingest", default=10)
        raw_files.sort(key=lambda f: f.name)
        if len(raw_files) > _max_per_ingest:
            raw_files = raw_files[:_max_per_ingest]
            log.info("KB %s: capping ingest to %d files (more pending)", slug, _max_per_ingest)

        # Read sidecar .source files to get original vault paths
        vault_sources: dict[str, str] = {}
        for f in all_inbox:
            if f.name.endswith(".source"):
                try:
                    original_name = f.name[:-7]  # strip ".source"
                    vault_sources[original_name] = f.read_text(encoding="utf-8").strip()
                except Exception:
                    pass

        now = datetime.now(UTC)
        local_now = datetime.now()
        date_folder = now.strftime("%Y-%m")
        date_str = local_now.strftime("%Y-%m-%d %H:%M")
        ingested: list[str] = []
        skipped: list[dict] = []
        wiki_updates = []

        # Discover known projects for auto-routing
        known_projects: dict[str, str] = {}  # slug → title
        projects_dir = self._resolve(f"{base}/wiki/projects")
        if projects_dir.is_dir():
            for d in projects_dir.iterdir():
                if d.is_dir() and d.name != ".gitkeep":
                    known_projects[d.name] = d.name.replace("-", " ").title()
        # Also check vault projects (from ProjectService)
        vault_projects_dir = self._resolve("projects")
        if vault_projects_dir.is_dir():
            for d in vault_projects_dir.iterdir():
                if d.is_dir() and d.name not in known_projects:
                    known_projects[d.name] = d.name.replace("-", " ").title()

        # Skip patterns for files that don't contain useful knowledge.
        # Phase 2 (Rule 12): patterns live in
        # ``kb-ingest/config/skip-patterns.yaml`` (multilingual).
        # The loader flattens all language sections into one match set.
        _skip_patterns = self._load_skip_patterns()

        for raw_file in raw_files:
            try:
                fname = raw_file.name
                fname_lower = fname.lower()

                # Skip mundane files (time reports, templates, etc.) — delete from inbox
                # so the watcher doesn't re-discover them every cycle.
                if any(p in fname_lower for p in _skip_patterns):
                    log.info("KB %s: skipping mundane file %s", slug, fname)
                    try:
                        raw_file.unlink()
                    except OSError:
                        pass
                    continue

                # Classify first — determines how to read the file
                source_type, type_focus = self._classify_source(fname)
                is_image = source_type == "image"

                # Extract via the file-type registry. One call, one contract,
                # preserves every pre-registry behaviour (image vision + timeout,
                # parsers path for PDF/JSON/VTT, text path with frontmatter +
                # web-noise stripping, empty/unreadable fallback with stable
                # content_hash). See ``_extract_source`` docstring for parity
                # guarantees and decisions.md §2026-04-18 for the overall design.
                source_text, source_meta, raw_source_url, content_hash, _extract_result = \
                    await self._extract_source(raw_file, fname)

                # ── Resolve embedded image references ───────────────────
                # Markdown files (from Obsidian Clipper, web clippers, etc.)
                # often contain ![alt](image.png) or ![[Pasted image.png]]
                # references.  The watcher copies sibling images alongside
                # the .md file, so they should be in the same inbox dir.
                # Here we: (1) find local images, (2) download remote ones,
                # (3) run each through OCR + vision LLM, (4) append the
                # descriptions to source_text so the LLM sees them during
                # classification and the descriptions become searchable.
                if not is_image and source_text:
                    resolved_images = await self._resolve_embedded_images(
                        source_text, raw_file, base, slug,
                    )
                    if resolved_images:
                        image_section_parts: list[str] = []
                        for ri in resolved_images:
                            if ri.resolved:
                                desc = await self._describe_embedded_image(ri)
                                if desc:
                                    label = ri.alt_text or ri.local_path.name  # type: ignore[union-attr]
                                    image_section_parts.append(
                                        f"### Image: {label}\n{desc}"
                                    )
                        if image_section_parts:
                            source_text += "\n\n## Embedded Images\n\n" + "\n\n".join(image_section_parts)
                            # Recompute hash now that source_text includes image descriptions
                            content_hash = hashlib.md5(source_text.encode()).hexdigest()[:12]
                            log.info(
                                "KB %s: resolved %d embedded image(s) for %s (%d described)",
                                slug, len(resolved_images), fname,
                                len(image_section_parts),
                            )

                # Skip if already processed — check by filename AND by content hash.
                # Emit a visible activity event so re-clipping an unchanged file
                # doesn't look like silent failure in the UI.
                if state["processed_hashes"].get(fname) == content_hash:
                    log.info(
                        "KB %s: %s unchanged since last ingest (hash %s) — moving to library",
                        slug, fname, content_hash,
                    )
                    self._append_log(slug, "skip", f"Unchanged: {fname} (hash {content_hash})")
                    self._log_activity(
                        "ingest_skipped_unchanged",
                        f"{fname} unchanged since last ingest in KB {slug}",
                        {
                            "slug": slug,
                            "file": fname,
                            "content_hash": content_hash,
                            "reason": "identical_content",
                        },
                        importance="low",
                    )
                    await self._record_decision(
                        action_type="ingest_file",
                        action_target=f"kb/{slug}/{fname}",
                        contract_result="skipped",
                        rationale=f"Skipped {fname}: identical content already ingested",
                        details={
                            "slug": slug,
                            "file": fname,
                            "skip_reason": "unchanged",
                            "content_hash": content_hash,
                        },
                    )
                    skipped.append({"file": fname, "reason": "unchanged", "hash": content_hash})
                    # DELETE the inbox copy instead of moving to library/unsorted/.
                    # The previous ingest already filed this file at its proper
                    # taxonomy path; moving it to unsorted/ creates a byte-
                    # identical duplicate of an already-tracked source. Empirical
                    # cause of the `library/unsorted/` accumulation in production
                    # vaults — a "skip" was duplicating, not skipping.
                    self._safe_unlink_dedup(raw_file, fname, slug, "unchanged")
                    continue

                # Check for duplicate content under a different filename (same KB)
                all_hashes = state["processed_hashes"]
                duplicate_of = next(
                    (existing_name for existing_name, h in all_hashes.items() if h == content_hash and existing_name != fname),
                    None,
                )
                if duplicate_of:
                    log.info("KB %s: skipping %s — duplicate of %s (same content hash)", slug, fname, duplicate_of)
                    self._append_log(slug, "skip", f"Duplicate: {fname} = {duplicate_of}")
                    self._log_activity(
                        "ingest_skipped_duplicate",
                        f"{fname} is a duplicate of {duplicate_of} in KB {slug}",
                        {"slug": slug, "file": fname, "duplicate_of": duplicate_of, "content_hash": content_hash},
                        importance="low",
                    )
                    await self._record_decision(
                        action_type="ingest_file",
                        action_target=f"kb/{slug}/{fname}",
                        contract_result="skipped",
                        rationale=f"Skipped {fname}: duplicate content of {duplicate_of}",
                        details={
                            "slug": slug,
                            "file": fname,
                            "skip_reason": "duplicate",
                            "duplicate_of": duplicate_of,
                            "content_hash": content_hash,
                        },
                    )
                    skipped.append({"file": fname, "reason": "duplicate", "duplicate_of": duplicate_of})
                    state["processed_hashes"][fname] = content_hash
                    self._safe_unlink_dedup(raw_file, fname, slug, "duplicate")
                    self._write_compile_state(slug, state)
                    continue

                # Cross-KB dedup: check if this content hash exists in any other KB
                cross_dup = self._check_cross_kb_duplicate(slug, content_hash)
                if cross_dup:
                    log.info("KB %s: skipping %s — already ingested in KB %s", slug, fname, cross_dup)
                    self._append_log(slug, "skip", f"Cross-KB duplicate: {fname} already in {cross_dup}")
                    self._log_activity(
                        "ingest_skipped_cross_kb",
                        f"{fname} already ingested in KB {cross_dup}",
                        {"slug": slug, "file": fname, "other_kb": cross_dup, "content_hash": content_hash},
                        importance="low",
                    )
                    await self._record_decision(
                        action_type="ingest_file",
                        action_target=f"kb/{slug}/{fname}",
                        contract_result="skipped",
                        rationale=f"Skipped {fname}: already ingested in KB {cross_dup}",
                        details={
                            "slug": slug,
                            "file": fname,
                            "skip_reason": "cross_kb_duplicate",
                            "other_kb": cross_dup,
                            "content_hash": content_hash,
                        },
                    )
                    skipped.append({"file": fname, "reason": "cross_kb_duplicate", "other_kb": cross_dup})
                    state["processed_hashes"][fname] = content_hash
                    self._safe_unlink_dedup(raw_file, fname, slug, "cross_kb_duplicate")
                    self._write_compile_state(slug, state)
                    continue

                # Skip empty files — LLM will reject empty content
                if not source_text.strip():
                    log.info("KB %s: skipping %s — empty file", slug, fname)
                    state["processed_hashes"][fname] = content_hash
                    self._safe_unlink_dedup(raw_file, fname, slug, "empty_file")
                    self._write_compile_state(slug, state)
                    continue

                # Check if this is an updated version of an existing file (same stem, different hash)
                existing_entry = next(
                    (existing_name for existing_name in all_hashes if Path(existing_name).stem == Path(fname).stem and existing_name != fname),
                    None,
                )
                if existing_entry:
                    log.info("KB %s: %s appears to be an update of %s — replacing", slug, fname, existing_entry)
                    # Clean up old source summary if the slug changed
                    old_source_slug = Path(existing_entry).stem.lower().replace(" ", "-")
                    new_source_slug = Path(fname).stem.lower().replace(" ", "-")
                    if old_source_slug != new_source_slug:
                        old_page = self._resolve(f"{base}/wiki/sources") / f"{old_source_slug}.md"
                        if old_page.exists():
                            old_page.unlink()
                            log.info("KB %s: cleaned up orphaned source page %s", slug, old_source_slug)
                    # Also clean up pages the old source produced
                    old_provenance = state.get("sources", {}).get(existing_entry, {})
                    for old_page_path in old_provenance.get("produced_pages", []):
                        if old_page_path.startswith("sources/"):
                            continue  # handled above
                        full = self._resolve(f"{base}/wiki") / f"{old_page_path}.md"
                        if full.exists():
                            full.unlink()
                            log.info("KB %s: cleaned up old produced page %s", slug, old_page_path)
                    # Remove old hash and provenance
                    del all_hashes[existing_entry]
                    state.get("sources", {}).pop(existing_entry, None)

                # type_focus already set from classification above

                # For large documents: chunked multi-pass extraction
                # Extracts knowledge from ALL sections via parallel LLM calls,
                # then merges into a single consolidated summary. No content dropped.
                from agntspace.kb.chunked_extract import chunked_extract, needs_chunking
                if not is_image and needs_chunking(source_text):
                    try:
                        # Large documents need "capable" tier — small models (fast) produce
                        # garbage on multi-page content (truncation, hallucination, empty output)
                        source_text = await chunked_extract(
                            source_text, fname, source_type, self._llm,
                            model=self._resolve_model("capable"),
                        )
                        log.info("KB %s: chunked extraction complete for %s (%d chars)",
                                 slug, fname, len(source_text))
                    except Exception:
                        log.exception("KB %s: chunked extraction failed for %s — using first 12K chars",
                                      slug, fname)
                        source_text = source_text[:12000]

                # LLM: type-specific extraction — wrapped in try/except so one failure
                # doesn't kill the entire batch
                try:
                    # Build classify prompt: skill-loaded or hardcoded fallback
                    _bib_block = (
                        "\n\nAlso extract bibliographic metadata into this block:\n"
                        "```bibliography\n"
                        "- title: (exact title of the work — not the filename)\n"
                        "- authors: (comma-separated, Last First or First Last format)\n"
                        "- date: (publication date, e.g. \"14 July 2025\" or \"2025\" or \"2025-07-14\")\n"
                        "- publisher: (journal name, newspaper, website name, or publisher)\n"
                        "- doi: (DOI if visible, or \"\")\n"
                        "- volume: (journal volume number, or \"\")\n"
                        "- issue: (journal issue number, or \"\")\n"
                        "- pages: (page range e.g. \"263-276\", or \"\")\n"
                        "- issn: (ISSN if visible, or \"\")\n"
                        "- isbn: (ISBN if visible, or \"\")\n"
                        "- language: (content language if not English, e.g. \"Hungarian\", or \"\")\n"
                        "- via: (hosting platform if different from publisher, e.g. \"Taylor & Francis\", or \"\")\n"
                        "```"
                    )

                    # Build frontmatter context block — gives the LLM authoritative
                    # metadata from the source (title, description, author, URL) so it
                    # doesn't have to guess the topic from potentially noisy body text.
                    _fm_parts: list[str] = []
                    if not is_image and source_meta:
                        fm_title = source_meta.get("title", "")
                        fm_desc = source_meta.get("description", "")
                        fm_author = source_meta.get("author", "")
                        fm_published = source_meta.get("published", source_meta.get("date", ""))
                        fm_tags = source_meta.get("tags", [])
                        if fm_title:
                            _fm_parts.append(f"Title: {fm_title}")
                        if fm_desc:
                            _fm_parts.append(f"Description: {fm_desc}")
                        if fm_author:
                            if isinstance(fm_author, list):
                                fm_author = ", ".join(str(a).strip("[]") for a in fm_author)
                            _fm_parts.append(f"Author: {fm_author}")
                        if fm_published:
                            _fm_parts.append(f"Published: {fm_published}")
                        if raw_source_url:
                            _fm_parts.append(f"Source URL: {raw_source_url}")
                        if fm_tags and isinstance(fm_tags, list):
                            _fm_parts.append(f"Tags: {', '.join(str(t) for t in fm_tags)}")
                    _fm_block = ""
                    if _fm_parts:
                        _fm_block = (
                            "\n\nSOURCE METADATA (from file frontmatter — this is authoritative, "
                            "use it to determine the article's true topic even if body text "
                            "starts with ads or unrelated content):\n"
                            + "\n".join(_fm_parts) + "\n"
                        )

                    # Extract only article TITLES from the index, not content.
                    # Small models copy content from the prompt, producing wrong
                    # summaries. Titles-only gives context without contamination.
                    _index_titles: list[str] = []
                    for _line in (index_doc.content or "").split("\n"):
                        _l = _line.strip()
                        if _l.startswith("### ") or _l.startswith("## "):
                            _index_titles.append(_l.lstrip("# ").strip())
                    _index_summary = (
                        ("Existing articles: " + ", ".join(_index_titles[:30]))
                        if _index_titles else "Existing articles: (none)"
                    )
                    # ── Safe defaults for all language variables ──────────
                    # These 8 variables are set inside the language block
                    # below and used later in the template rendering +
                    # observability logging. If the block raises for any
                    # reason, these defaults ensure the rest of the per-file
                    # loop doesn't crash with NameError. The defaults are
                    # conservative: English, source policy, no drift, no
                    # bilingual, no escalation. Fix for the 2026-04-11
                    # production crash where undefined _language_check
                    # cascaded into NameError downstream.
                    content_lang: str = "en"
                    output_lang: str = "en"
                    _policy: str = "source"
                    _policy_source: str = "default"
                    _is_bilingual: bool = False
                    _secondary: str = ""
                    _language_check: dict = {"status": "skipped", "detected": "", "expected": "en", "reason": "defaults", "confidence": 0.0}
                    _classify_tier: str = "fast"
                    entities_block: str = ""

                    # ── Three-language architecture ─────────────────────────
                    # Resolve content/output language via the policy override
                    # chain: frontmatter > SCHEMA > skill > config > default.
                    # Build an English directive that tells the LLM what
                    # language to write the summary in, then inject it into
                    # the system prompt.
                    from agntspace.infra.language import (
                        build_bilingual_directive,
                        build_language_directive,
                        resolve_languages,
                    )
                    _skill_lang_cfg: dict = {}
                    if self._skill_loader and hasattr(self._skill_loader, "get_skill_config"):
                        _skill_lang_cfg = self._skill_loader.get_skill_config(
                            "kb-ingest", "language",
                        ) or {}
                    _schema_meta = self._read_schema_meta(slug)
                    _global_policy = getattr(self, "_global_language_policy", None)
                    _user_locale = getattr(self, "_user_locale", "en")
                    content_lang, output_lang, _policy, _policy_source = resolve_languages(
                        source_text,
                        source_meta=source_meta,
                        skill_config=_skill_lang_cfg,
                        kb_schema=_schema_meta,
                        global_policy=_global_policy,
                        user_locale=_user_locale,
                    )

                    # Bilingual mode (spec §19 item 4): when policy is "both",
                    # emit a directive that asks for two parallel outputs —
                    # primary in content_lang, secondary in user_locale.
                    _is_bilingual = (_policy or "").strip().lower() == "both"
                    if _is_bilingual:
                        _secondary = _user_locale.replace("_", "-").split("-")[0].lower()
                        if _secondary == content_lang:
                            # Degenerate case — nothing to translate
                            _lang_directive = build_language_directive(content_lang, content_lang)
                            _is_bilingual = False
                        else:
                            _lang_directive = build_bilingual_directive(content_lang, _secondary)
                    else:
                        _lang_directive = build_language_directive(content_lang, output_lang)

                    dynamic_ctx = (
                        f"\nSource file: {fname}\nSource type: {source_type}\n"
                        f"Type-specific focus: {type_focus}\n"
                        f"{_fm_block}\n"
                        f"KB Schema:\n{schema[:1000]}\n\n"
                        f"{_index_summary}\n\n"
                        f"KNOWLEDGE TAXONOMY:\n{self._taxonomy_text}"
                        f"{_bib_block}"
                        f"{_lang_directive}"
                    )
                    skill_prompt = self._get_skill_prompt("kb-ingest")
                    if skill_prompt:
                        classify_system = skill_prompt + "\n\n" + dynamic_ctx
                    else:
                        classify_system = _CLASSIFY_PROMPT_FALLBACK.format(
                            filename=fname, source_type=source_type, type_focus=type_focus,
                            schema=schema[:1000], index=_index_summary,
                            taxonomy=self._taxonomy_text,
                        )
                        classify_system += _lang_directive
                    classify_system += "\n\n" + self._get_skill_rules("kb-ingest")
                    # Use "capable" for papers/long content, "fast" for short articles.
                    # In local mode, always use "fast" — "capable" is typically a 70b
                    # model that's too slow for classification under any reasonable timeout.
                    if self._is_local_mode():
                        _classify_tier = "fast"
                        _timeout = 180
                    else:
                        _classify_tier = "capable" if source_type == "paper" or len(source_text) > 5000 else "fast"
                        _timeout = 90

                    # Language-drift escalation (spec v1.1 follow-up):
                    # When the work queue retries an ingest because an earlier
                    # attempt produced wrong-language output, the payload carries
                    # an `escalate_tier` hint which bumps the model tier for this
                    # specific file. Cleared after first use by the handler.
                    _escalation = getattr(self, "_language_drift_escalation", None)
                    _forced_model: str | None = None
                    if (
                        _escalation
                        and isinstance(_escalation, dict)
                        and (not _escalation.get("file") or _escalation["file"] == fname)
                    ):
                        if _escalation.get("tier"):
                            _classify_tier = _escalation["tier"]
                            if isinstance(source_meta, dict):
                                source_meta["_language_drift_retry"] = True
                        # Provider escalation (gap #5): when tier-escalation has
                        # already been tried, swap to a concrete fallback model
                        # string (e.g. "openai/gpt-5.4") via the LiteLLM provider
                        # override. Different provider = different training data
                        # bias, so multilingual adherence may improve.
                        if _escalation.get("fallback_model"):
                            _forced_model = _escalation["fallback_model"]
                            if isinstance(source_meta, dict):
                                source_meta["_language_drift_provider_retry"] = True

                    # Empty-extraction escalation: same shape as the drift
                    # escalation, used when an earlier attempt produced no
                    # usable entities/concepts. The retry runs at a higher
                    # tier so the LLM is more likely to produce proper
                    # fenced blocks. Does not override an active drift
                    # escalation — both retry reasons can coexist, drift
                    # takes priority because language correctness is
                    # load-bearing for downstream semantic work.
                    _empty_esc = getattr(self, "_empty_extraction_escalation", None)
                    if (
                        _empty_esc
                        and isinstance(_empty_esc, dict)
                        and (not _empty_esc.get("file") or _empty_esc["file"] == fname)
                        and not _forced_model  # don't override drift provider retry
                    ):
                        if _empty_esc.get("tier"):
                            _classify_tier = _empty_esc["tier"]
                            if isinstance(source_meta, dict):
                                source_meta["_empty_extraction_retry"] = True

                    # Timeout-retry escalation: when a previous attempt hit
                    # asyncio.TimeoutError, the work queue handler set this
                    # so the retry runs at the next tier in the ladder.
                    # Tracked separately from the other two channels because
                    # the trigger (timeout) is orthogonal to drift / empty
                    # output. Same file-scoping rule.
                    _timeout_esc = getattr(self, "_timeout_escalation", None)
                    _timeout_attempt = 1  # 1 = original attempt; queue retries bump this
                    if (
                        _timeout_esc
                        and isinstance(_timeout_esc, dict)
                        and (not _timeout_esc.get("file") or _timeout_esc["file"] == fname)
                    ):
                        if _timeout_esc.get("tier") and not _forced_model:
                            _classify_tier = _timeout_esc["tier"]
                            if isinstance(source_meta, dict):
                                source_meta["_timeout_retry"] = True
                        _timeout_attempt = int(_timeout_esc.get("attempt", 1))

                    # Prompt injection defense: wrap the raw source text in
                    # structural boundary markers before it reaches the LLM.
                    # This is the primary defense against malicious web content
                    # that contains "ignore previous instructions" payloads.
                    # See docs/threat-model.md §9.1 and security/prompt_guard.py.
                    from agntspace.security.prompt_guard import sanitize_for_llm
                    _safe_source_text = sanitize_for_llm(
                        source_text,
                        source="ingested_file",
                        context=fname,
                    )

                    _classify_model = _forced_model or self._resolve_model(_classify_tier)
                    response = await asyncio.wait_for(
                        self._llm.complete(
                            messages=[Message(role="user", content=_safe_source_text)],
                            system=classify_system,
                            max_tokens=3500,
                            temperature=0.3,
                            model=_classify_model,  # librarian: classification
                        ),
                        timeout=_timeout,
                    )
                except TimeoutError:
                    # Retry-with-tier-escalation policy. See class-level
                    # _TIMEOUT_RETRY_TIERS / _TIMEOUT_MAX_ATTEMPTS. First
                    # timeout enqueues a retry at the next tier; subsequent
                    # timeouts bump the attempt counter and walk the ladder.
                    # Quarantine only fires after the ladder is exhausted.
                    next_attempt = _timeout_attempt + 1
                    # Pick next tier: walk past current position in the ladder.
                    try:
                        cur_idx = self._TIMEOUT_RETRY_TIERS.index(_classify_tier)
                    except ValueError:
                        cur_idx = -1  # current tier not in ladder; start ladder fresh
                    next_idx = min(cur_idx + 1, len(self._TIMEOUT_RETRY_TIERS) - 1)
                    next_tier = self._TIMEOUT_RETRY_TIERS[next_idx]

                    if (
                        _timeout_attempt < self._TIMEOUT_MAX_ATTEMPTS
                        and self._work_queue is not None
                        and not self._called_from_queue
                    ):
                        # Enqueue retry — file stays in inbox until either the
                        # retry succeeds (file moves to library) or the ladder
                        # is exhausted on a future attempt (file → quarantine).
                        # NOTE: we DON'T move the file out of inbox here. The
                        # user sees the file is still queued; the next watcher
                        # cycle picks it up after the work-queue retry fires.
                        log.info(
                            "KB %s: classify timeout for %s (attempt %d/%d, tier %s) "
                            "— enqueueing retry at tier %s",
                            slug, fname, _timeout_attempt, self._TIMEOUT_MAX_ATTEMPTS,
                            _classify_tier, next_tier,
                        )
                        try:
                            asyncio.create_task(self._work_queue.enqueue(
                                "ingest",
                                {
                                    "slug": slug,
                                    "timeout_retry_tier": next_tier,
                                    "timeout_retry_attempt": next_attempt,
                                    "target_file": fname,
                                    "reason": "timeout",
                                },
                                deduplicate=True,
                            ))
                        except Exception:
                            log.exception(
                                "KB %s: failed to enqueue timeout retry for %s — "
                                "falling through to quarantine",
                                slug, fname,
                            )
                            # If enqueue itself failed, fall through to quarantine
                            # below by setting attempt to max.
                            _timeout_attempt = self._TIMEOUT_MAX_ATTEMPTS

                    if (
                        _timeout_attempt >= self._TIMEOUT_MAX_ATTEMPTS
                        or self._work_queue is None
                    ):
                        # Exhausted the ladder OR no work queue available.
                        # Quarantine with a rich reason so the user knows
                        # how many tries we made and which tiers failed.
                        tiers_tried_label = (
                            ", ".join(
                                self._TIMEOUT_RETRY_TIERS[:cur_idx + 1]
                                if cur_idx >= 0
                                else [_classify_tier]
                            ) or _classify_tier
                        )
                        reason = (
                            f"Timed out after {_timeout_attempt} attempt(s) — "
                            f"tiers tried: {tiers_tried_label}"
                            if self._work_queue is not None
                            else "Timed out (no work queue available for retry)"
                        )
                        log.warning(
                            "KB %s: LLM extraction timed out for %s — %s",
                            slug, fname, reason,
                        )
                        try:
                            from agntspace.automation.raw_watcher import QUARANTINE_DIRNAME
                            quarantine = self._resolve(f"{base}/inbox/{QUARANTINE_DIRNAME}")
                            quarantine.mkdir(parents=True, exist_ok=True)
                            raw_file.rename(quarantine / fname)
                            # Rule #13: visible activity event so the agent
                            # sees what just happened and the user can find
                            # the rich reason in /pipeline + /decisions.
                            self._log_activity(
                                action="ingest_quarantined",
                                summary=f"KB {slug}: quarantined {fname} after {_timeout_attempt} timeout(s)",
                                details={
                                    "slug": slug,
                                    "filename": fname,
                                    "attempts": _timeout_attempt,
                                    "tiers_tried": tiers_tried_label,
                                    "reason": "timeout",
                                },
                                importance="high",
                            )
                        except OSError:
                            log.exception("KB %s: failed to quarantine %s", slug, fname)
                    continue
                except Exception as exc:
                    log.warning("KB %s: LLM extraction failed for %s: %s", slug, fname, exc)
                    if self._called_from_queue:
                        raise  # Let work queue handle retry scheduling
                    if self._work_queue:
                        asyncio.create_task(self._work_queue.enqueue(
                            "ingest", {"slug": slug}, deduplicate=True,
                        ))
                        log.info("KB %s: queued ingest for retry (LLM unavailable)", slug)
                    continue

                summary = self._extract_block(response.content, "summary") or response.content[:300]

                # ── Language adherence gate (spec §19 items 1 + 5) ──
                # Detect the actual language of the summary and compare it to the
                # expected output_lang. Small local models often ignore language
                # directives. On mismatch, log the drift and record it in the
                # frontmatter so the user can re-ingest with a better model.
                from agntspace.infra.language import verify_output_language
                _language_check = verify_output_language(summary, output_lang)
                if _language_check["status"] == "mismatch":
                    log.warning(
                        "KB %s: LLM output language drift — expected %s, got %s (file=%s)",
                        slug, output_lang, _language_check["detected"], fname,
                    )
                    _activity = getattr(self, "_activity", None)
                    if _activity and hasattr(_activity, "log"):
                        try:
                            _activity.log(
                                "llm", "language_drift",
                                f"LLM produced {_language_check['detected']} "
                                f"instead of requested {output_lang} for {fname}",
                                {
                                    "slug": slug,
                                    "file": fname,
                                    "expected": output_lang,
                                    "detected": _language_check["detected"],
                                },
                                importance="medium",
                            )
                        except Exception:
                            pass
                    # Language-aware quality gate (spec §19 item 5 + tier escalation):
                    # Re-queue the ingest with an ESCALATED model tier when the
                    # LLM produces wrong-language output. The escalated tier is
                    # encoded in the job payload; `_do_ingest` reads it on retry.
                    # Default escalation path: fast → capable → reasoning. Stops
                    # after one escalation per file to avoid loops.
                    _drift_retry_enabled = _skill_lang_cfg.get("retry_on_language_drift")
                    # When retry is ON by default, allow opt-out via explicit False.
                    if _drift_retry_enabled is None:
                        _drift_retry_enabled = True
                    if (
                        _drift_retry_enabled
                        and self._work_queue
                    ):
                        _already_tier_escalated = (
                            isinstance(source_meta, dict)
                            and source_meta.get("_language_drift_retry")
                        )
                        _already_provider_escalated = (
                            isinstance(source_meta, dict)
                            and source_meta.get("_language_drift_provider_retry")
                        )

                        # Step 1: tier escalation (fast → capable → reasoning)
                        if not _already_tier_escalated and not self._called_from_queue:
                            _escalation_map = {"fast": "capable", "capable": "reasoning"}
                            _next_tier = _escalation_map.get(_classify_tier)
                            if _next_tier:
                                try:
                                    asyncio.create_task(self._work_queue.enqueue(
                                        "ingest",
                                        {
                                            "slug": slug,
                                            "reason": "language_drift",
                                            "escalate_tier": _next_tier,
                                            "target_file": fname,
                                        },
                                        deduplicate=True,
                                    ))
                                    log.info(
                                        "KB %s: queued ingest retry at tier %s due to "
                                        "language drift (%s → %s) for %s",
                                        slug, _next_tier, output_lang,
                                        _language_check["detected"], fname,
                                    )
                                except Exception:
                                    log.debug("Failed to enqueue language-drift tier retry", exc_info=True)

                        # Step 2: provider escalation — if tier-escalation was
                        # already tried (we're in a queue retry) and STILL drifts,
                        # swap to a concrete fallback model from skill config or
                        # global LLM settings.
                        elif not _already_provider_escalated:
                            _fallback_model = (
                                _skill_lang_cfg.get("fallback_model")
                                or getattr(self, "_language_drift_fallback_model", None)
                            )
                            if _fallback_model:
                                try:
                                    asyncio.create_task(self._work_queue.enqueue(
                                        "ingest",
                                        {
                                            "slug": slug,
                                            "reason": "language_drift_provider",
                                            "fallback_model": _fallback_model,
                                            "target_file": fname,
                                        },
                                        deduplicate=True,
                                    ))
                                    log.warning(
                                        "KB %s: tier escalation exhausted — queuing "
                                        "provider retry (%s) for %s",
                                        slug, _fallback_model, fname,
                                    )
                                except Exception:
                                    log.debug("Failed to enqueue language-drift provider retry", exc_info=True)
                            else:
                                log.warning(
                                    "KB %s: tier escalation exhausted and no "
                                    "fallback_model configured — drift persists for %s",
                                    slug, fname,
                                )

                # Quality gate: reject garbage extractions (truncated, empty, too short)
                _MIN_SUMMARY_CHARS = 80
                if len(summary.strip()) < _MIN_SUMMARY_CHARS:
                    log.warning(
                        "KB %s: extraction quality too low for %s — summary only %d chars: %s",
                        slug, fname, len(summary.strip()), summary.strip()[:100],
                    )
                    # 2026-05-01 fix B — quarantine on quality rejection.
                    # Pre-fix: the rejection path did `continue` (file stayed
                    # in inbox) + enqueued a retry, creating an infinite loop
                    # for files that simply have no extractable content (e.g.
                    # OneNote stubs with just `# Untitled page` and frontmatter).
                    # Quality is unlikely to improve on retry — same model,
                    # same content — so quarantine immediately. The watcher's
                    # evidence check sees `.quarantine/` and stops re-copying.
                    try:
                        from agntspace.automation.raw_watcher import QUARANTINE_DIRNAME
                        quarantine = self._resolve(f"{base}/inbox/{QUARANTINE_DIRNAME}")
                        quarantine.mkdir(parents=True, exist_ok=True)
                        # Collision-safe: if quarantine already has a same-
                        # named file (different source), suffix with a hash
                        # of the new file's content so both are preserved.
                        target = quarantine / fname
                        if target.exists():
                            # NB: hashlib is imported at module top; redundant
                            # function-local import would mark every reference
                            # in this method as "local" and break earlier uses
                            # (F823) — keep this as a plain reference.
                            try:
                                h = hashlib.sha256(raw_file.read_bytes()).hexdigest()[:8]
                                target = quarantine / f"{raw_file.stem}.{h}{raw_file.suffix}"
                            except OSError:
                                target = quarantine / f"{raw_file.stem}.{int(raw_file.stat().st_mtime)}{raw_file.suffix}"
                        raw_file.rename(target)
                        self._log_activity(
                            action="ingest_quarantined",
                            summary=f"KB {slug}: quarantined {fname} (extraction quality too low)",
                            details={
                                "slug": slug,
                                "filename": fname,
                                "summary_chars": len(summary.strip()),
                                "min_required": _MIN_SUMMARY_CHARS,
                                "reason": "quality_too_low",
                            },
                            importance="medium",
                        )
                    except OSError:
                        log.exception("KB %s: failed to quarantine low-quality %s", slug, fname)
                    if self._called_from_queue:
                        # Don't raise — the file is now safely in quarantine,
                        # so this isn't a retry-worthy failure. Let the queue
                        # mark the job complete. Pre-fix raised here, which
                        # forced the work queue into another retry loop.
                        pass
                    continue

                # Echo-detection gate: small local models sometimes regurgitate a
                # previously-generated summary from the prompt context. Flag the
                # extraction if it's a near-duplicate of another source in the
                # same KB (by first 200 chars). The compile state's sources dict
                # tracks hashes; here we check against *existing summaries* on disk.
                if self._is_local_mode():
                    summary_head = " ".join(summary.strip().split())[:200].lower()
                    if summary_head:
                        try:
                            for other in self._reader.list_files(
                                f"{base}/wiki/sources", "*.md"
                            ):
                                if other.stem == Path(fname).stem:
                                    continue
                                try:
                                    other_doc = self._reader.read(
                                        f"{base}/wiki/sources/{other.name}"
                                    )
                                    other_summary = self._extract_block(
                                        other_doc.content, "summary"
                                    ) or ""
                                    other_head = " ".join(
                                        other_summary.strip().split()
                                    )[:200].lower()
                                    if (
                                        other_head
                                        and len(other_head) >= 80
                                        and other_head == summary_head
                                    ):
                                        log.warning(
                                            "KB %s: extraction for %s duplicates %s "
                                            "(local LLM echo) — quarantining",
                                            slug, fname, other.stem,
                                        )
                                        try:
                                            from agntspace.automation.raw_watcher import (
                                                QUARANTINE_DIRNAME,
                                            )
                                            quarantine = self._resolve(
                                                f"{base}/inbox/{QUARANTINE_DIRNAME}"
                                            )
                                            quarantine.mkdir(parents=True, exist_ok=True)
                                            raw_file.rename(quarantine / fname)
                                        except OSError:
                                            log.exception(
                                                "KB %s: failed to quarantine echo %s",
                                                slug, fname,
                                            )
                                        raise _EchoDetected()
                                except _EchoDetected:
                                    raise
                                except Exception:
                                    continue
                        except _EchoDetected:
                            continue
                        except Exception:
                            log.debug(
                                "echo detection failed for %s", fname, exc_info=True
                            )
                concepts_raw = self._extract_block(response.content, "concepts") or ""
                # Layer 2 anti-contamination: strip concept lines that came
                # from the existing-articles list in the system prompt rather
                # than from the actual source content. The classify LLM sees
                # KB article titles for dedup and small models parrot them.
                concepts = self._filter_concepts_by_source(concepts_raw, source_text)
                entities_block = self._extract_block(response.content, "entities") or ""
                contradictions = self._extract_block(response.content, "contradictions") or "none found"
                updates = self._extract_block(response.content, "wiki_updates") or ""
                bib_raw = self._extract_block(response.content, "bibliography") or ""
                # LLM-emitted taxonomy_path (Session 1 of wiki classification overhaul,
                # 2026-04-27 evening). The skill prompt now asks the LLM to pick a real
                # leaf for each source. We extract + validate against the loaded taxonomy
                # tree and use it at line 4796 area in preference to the structural
                # ``classify_article("source_summary", ...)`` fallback (which returns
                # the L1 sentinel "sources" — root cause of Problem B). When the LLM
                # produces an empty/invalid path, we fall back to the structural call
                # so the file still gets classified rather than crashing the ingest.
                taxonomy_path_raw = self._extract_block(response.content, "taxonomy_path") or ""

                # Create source summary page — use display name for filename
                from agntspace.vault.writer import title_to_filename
                source_slug = Path(fname).stem.lower().replace(" ", "-")
                source_display = title_to_filename(Path(fname).stem)
                file_category = source_type if source_type in ("article", "paper", "image", "data", "code") else self._classify_source(fname)[0]
                lib_path = f"library/{file_category}/{date_folder}/{fname}"

                # For images: embed the image in the wiki page
                if is_image:
                    image_section = f"\n![{fname}](../../{lib_path})\n\n> *Image analyzed by AI vision — see description below.*\n\n"
                else:
                    image_section = ""

                vault_src = vault_sources.get(fname, "")
                vault_source_line = f"- Original: `{vault_src}`\n" if vault_src else ""

                # Preserve date_created from existing source page (don't overwrite on re-ingest)
                source_path = f"{base}/wiki/sources/{source_display}.md"
                original_date = date_str
                if self._reader.exists(source_path):
                    try:
                        existing_doc = self._reader.read(source_path)
                        original_date = existing_doc.metadata.get("date_created", date_str)
                    except Exception:
                        pass

                # Register in global bibliography (before source page so we get cite_key)
                cite_key = ""
                if self._bibliography:
                    try:
                        bib_meta = self._parse_bib_metadata(bib_raw, fname, source_type, raw_source_url, date_str) if bib_raw else {
                            "title": Path(fname).stem.replace("-", " ").replace("_", " "),
                            "authors": [],
                            "date": date_str,
                            "source_type": source_type,
                        }
                        if raw_source_url:
                            bib_meta["url"] = raw_source_url
                        bib_entry = self._bibliography.register_from_ingest({
                            **bib_meta,
                            "kb_slug": slug,
                            "source_file": fname,
                            "library_path": lib_path,
                            "content_hash": content_hash,
                            "date_ingested": date_str,
                        })
                        cite_key = bib_entry.get("cite_key", "")
                    except Exception:
                        log.debug("KB %s: bibliography registration failed for %s", slug, fname, exc_info=True)

                # Capture once — reused by _move_to_library so the thematic
                # layout can route the original to the right taxonomy folder.
                #
                # Resolution order (Session 1, 2026-04-27 evening — Wiki classification
                # overhaul). Prefer the LLM's emitted leaf path when valid; fall back
                # to structural ``_classify`` when not. This closes Problem B for new
                # ingests at the source: source_summary articles get a real L3 leaf
                # (e.g. "sources/articles/news") instead of the L1 sentinel "sources".
                source_taxonomy_path = self._validated_taxonomy_path(
                    taxonomy_path_raw,
                    fallback_etype="source_summary",
                    fallback_category=source_type,
                    fallback_title=fname,
                )
                # Phase 4.5: surface extractor provenance in the source
                # page's frontmatter so the upgrade-proposals surface can
                # tell whether a higher-fidelity tier became available
                # after this source was ingested. Graceful empty fallback
                # when the extractor didn't set these (shouldn't happen
                # post-Phase 1 — registry.extract() always stamps them —
                # but the template renders safely with empty strings).
                _prov = getattr(_extract_result, "provenance", {}) or {}
                _ext_id = str(_prov.get("extractor_id") or "")
                _ext_ver = str(_prov.get("extractor_version") or "")
                _ext_type = str(_prov.get("type_name") or "")
                source_page = self._render_template("source_summary",
                    title=fname, filename=fname, category=source_type,
                    taxonomy_path=source_taxonomy_path,
                    summary=summary, concepts=concepts,
                    date_created=original_date, date_updated=date_str,
                    hash=content_hash,
                    library_path=f"../../{lib_path}",
                    source_url=raw_source_url,
                    image_section=image_section,
                    vault_source=vault_src,
                    vault_source_line=vault_source_line,
                    cite_key=cite_key,
                    content_language=content_lang,
                    output_language=output_lang,
                    language_policy=_policy,
                    language_policy_source=_policy_source,
                    language_adherence=_language_check.get("status", "skipped"),
                    secondary_output_language=(
                        _secondary if _is_bilingual else ""
                    ),
                    type_name=_ext_type,
                    extractor_id=_ext_id,
                    extractor_version=_ext_ver,
                )

                # For images: append raw OCR text and vision description to the source page
                if is_image and source_text:
                    source_page += "\n\n## Extracted Content\n" + source_text
                self._writer.write(source_path, source_page)
                wiki_updates.append(f"created sources/{source_display}")

                # Process CREATE/UPDATE wiki actions
                created_entities: list[str] = []
                created_concepts: list[str] = []
                if updates:
                    for line in updates.strip().split("\n"):
                        line = line.strip().lstrip("- ")
                        if line.startswith("CREATE "):
                            parts = line[7:].split(":", 1)
                            if len(parts) == 2:
                                page_path = parts[0].strip()
                                desc_and_reason = parts[1].strip()
                                # Parse optional REASON
                                created_reason = ""
                                if "| REASON:" in desc_and_reason:
                                    description, _, created_reason = desc_and_reason.partition("| REASON:")
                                    description = description.strip()
                                    created_reason = created_reason.strip()
                                else:
                                    description = desc_and_reason
                                # Normalize slug: strip type prefixes, remap invalid subdirs
                                subdir, raw_slug = page_path.rsplit("/", 1) if "/" in page_path else ("concepts", page_path)
                                _INGEST_REMAP = {"events": "concepts", "meetings": "concepts", "people": "entities",
                                                 "organizations": "entities", "orgs": "entities", "references": "sources"}
                                subdir = _INGEST_REMAP.get(subdir, subdir)
                                # Reject placeholder slugs from prompt examples
                                _PLACEHOLDER_SLUGS = {"person-slug", "topic-slug", "slug", "org-slug", "existing-slug"}
                                if raw_slug in _PLACEHOLDER_SLUGS or page_path.split("/")[-1] in _PLACEHOLDER_SLUGS:
                                    continue
                                for prefix in ("person-", "org-", "organization-", "company-", "concept-", "entity-"):
                                    if raw_slug.startswith(prefix):
                                        raw_slug = raw_slug[len(prefix):]
                                        break
                                page_path = f"{subdir}/{raw_slug}"

                                # Project auto-routing: if source or description mentions a known project,
                                # route to wiki/projects/{project}/{subdir}/ instead of global
                                matched_project = None
                                if known_projects:
                                    source_lower = source_text.lower()
                                    desc_lower = description.lower()
                                    for proj_slug, proj_title in known_projects.items():
                                        proj_words = proj_slug.replace("-", " ")
                                        if proj_words in source_lower or proj_words in desc_lower:
                                            matched_project = proj_slug
                                            break
                                if matched_project:
                                    page_path = f"projects/{matched_project}/{subdir}/{raw_slug}"
                                    # Ensure project subdir exists
                                    proj_subdir = self._resolve(f"{base}/wiki/projects") / matched_project / subdir
                                    proj_subdir.mkdir(parents=True, exist_ok=True)

                                # Clean the description before using it as a
                                # filename: LLMs bleed chain-of-thought, trailing
                                # periods, and full sentences into what's supposed
                                # to be a short title. Result in prior sessions:
                                # filenames like "A type of AI-powered rocket
                                # technology. REASON This concept is crucial..."
                                # Truncate at the first sentence boundary (period,
                                # colon, semicolon) and strip any leaked markers.
                                _clean = description
                                for _marker in ("REASON:", "REASON ", "TODO:", "NOTE:", "—"):
                                    if _marker in _clean:
                                        _clean = _clean.split(_marker, 1)[0].strip()
                                for _stop in (". ", "; ", ": "):
                                    if _stop in _clean:
                                        _clean = _clean.split(_stop, 1)[0].strip()
                                _clean = _clean.rstrip(".,;:").strip()
                                # Hard cap: 60 chars. Real titles fit well under this.
                                if len(_clean) > 60:
                                    _clean = _clean[:60].rsplit(" ", 1)[0]
                                # Reject the whole CREATE if it's LLM prose leakage
                                # (placeholder, leading article, chain-of-thought,
                                # too many words). This is the same junk filter used
                                # by the entity/concept parsers — one rule, one truth.
                                if not _clean or self._is_junk_name(_clean):
                                    log.info(
                                        "KB %s: compile rejecting junk CREATE description: %s",
                                        slug, description[:80],
                                    )
                                    self._log_activity(
                                        "compile_rejected_junk_title",
                                        f"Rejected junk article title in KB {slug}",
                                        {
                                            "slug": slug,
                                            "page_path": page_path,
                                            "raw_description": description[:200],
                                            "cleaned": _clean,
                                        },
                                        importance="low",
                                    )
                                    continue
                                description = _clean

                                # Determine entity type from the v3 typed subdir.
                                # 2026-05-01 fix — pre-fix this was a one-line "default
                                # to person if entities/ in path" heuristic with an
                                # English-only keyword override (`company`, `organization`,
                                # `institution`, `firm`). It silently produced the
                                # split-brain bug the user reported: file at
                                # `entities/organizations/3M Corporation.md` but
                                # frontmatter stamped `entity_type: person,
                                # taxonomy_path: entities/people` because "3m
                                # corporation" doesn't contain any of the four
                                # English keywords. Same trap for every Swedish
                                # company name + most non-English orgs + every
                                # institution whose proper name doesn't contain
                                # the English word "company".
                                #
                                # The v3 taxonomy specifies typed sub-buckets
                                # (entities/people, entities/organizations,
                                # entities/places, entities/products, entities/events).
                                # The LLM correctly emits the right subdir; we just
                                # need to read it. Fall back to the keyword heuristic
                                # only if the LLM emitted a generic ``entities/``
                                # path with no typed leaf — which the v3 prompt
                                # forbids, but defensive coding accepts.
                                etype = "concept"  # safe default for unmatched paths
                                if page_path.startswith("entities/people/") or page_path == "entities/people":
                                    etype = "person"
                                elif page_path.startswith("entities/organizations/") or page_path == "entities/organizations":
                                    etype = "organization"
                                elif page_path.startswith("entities/places/") or page_path == "entities/places":
                                    etype = "place"
                                elif page_path.startswith("entities/products/") or page_path == "entities/products":
                                    etype = "thing"
                                elif page_path.startswith("entities/events/") or page_path == "entities/events":
                                    etype = "event"
                                elif page_path.startswith("entities/"):
                                    # LLM emitted an untyped entities/ path —
                                    # defensive fallback. Try the keyword heuristic
                                    # AS A LAST RESORT before defaulting. Better
                                    # to default to organization than person here:
                                    # in the user's vault, ~90% of bare-name
                                    # entities are companies, not people.
                                    desc_lower = description.lower()
                                    if any(kw in desc_lower for kw in (
                                        "company", "organization", "institution", "firm",
                                        "corporation", "corp", "inc.", "ltd", "llc",
                                        "ab", "oy", "gmbh", "s.a.", "sa", "spa",
                                    )):
                                        etype = "organization"
                                    elif any(kw in desc_lower for kw in (
                                        "mr ", "ms ", "dr ", "prof ", "ceo", "founder",
                                    )):
                                        etype = "person"
                                    else:
                                        # Genuine ambiguity — log for the
                                        # philosopher's daily repair_classifications
                                        # pass to disambiguate via the LLM.
                                        etype = "organization"  # 90/10 prior on user's vault
                                        log.debug(
                                            "KB %s: untyped entities/ path for '%s' — "
                                            "defaulting to organization (will be re-classified "
                                            "by daily repair pass if wrong)",
                                            slug, description[:60],
                                        )
                                elif page_path.startswith("concepts/") or page_path.startswith("knowledge/"):
                                    etype = "concept"
                                elif page_path.startswith("digests/") or page_path.startswith("sources/"):
                                    # v3 + legacy — digests are summaries of source
                                    # documents.
                                    etype = "digest"
                                elif page_path.startswith("decisions/") or page_path.startswith("reference/decisions/"):
                                    etype = "decision"
                                # Use display-name filename, keep slug for dedup and API
                                display_name = title_to_filename(description)
                                full_path = f"{base}/wiki/{subdir}/{display_name}.md"
                                if not self._reader.exists(full_path):
                                    alt_exists = False
                                    try:
                                        # Words too generic for meaningful dedup
                                        _SLUG_STOPWORDS = {
                                            "analysis", "assessment", "management", "system", "systems",
                                            "process", "review", "report", "data", "control", "overview",
                                            "general", "safety", "security", "tracking", "standard",
                                        }
                                        new_words = {w for w in raw_slug.split("-") if len(w) >= 4 and w not in _SLUG_STOPWORDS}
                                        for existing_file in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                                            if "/.history/" in str(existing_file).replace("\\", "/") or "\\.history\\" in str(existing_file):
                                                continue
                                            existing_slug = existing_file.stem
                                            # 1. Substring match (archer-futura ⊂ archer-futura-technologies)
                                            if raw_slug in existing_slug or existing_slug in raw_slug:
                                                alt_exists = True
                                                log.info("KB %s: dedup %s — substring of %s", slug, page_path, existing_slug)
                                                break
                                            # 2. Word overlap (bowtie-analysis ~ bowtie-methodology)
                                            if new_words:
                                                existing_words = {w for w in existing_slug.split("-") if len(w) >= 4 and w not in _SLUG_STOPWORDS}
                                                overlap = new_words & existing_words
                                                # If they share a significant word AND both are short slugs, likely same topic
                                                if overlap and (len(overlap) / max(len(new_words), 1) >= 0.5
                                                               or len(overlap) / max(len(existing_words), 1) >= 0.5):
                                                    alt_exists = True
                                                    log.info("KB %s: dedup %s — word overlap with %s (shared: %s)",
                                                             slug, page_path, existing_slug, ", ".join(overlap))
                                                    break
                                    except Exception:
                                        pass
                                    # Also check against pages created in THIS batch
                                    if not alt_exists:
                                        batch_slugs = [p.rsplit("/", 1)[-1] for p in created_entities + created_concepts]
                                        for bs in batch_slugs:
                                            if raw_slug in bs or bs in raw_slug:
                                                alt_exists = True
                                                log.info("KB %s: dedup %s — substring of batch page %s", slug, page_path, bs)
                                                break
                                            bs_words = {w for w in bs.split("-") if len(w) >= 4 and w not in _SLUG_STOPWORDS}
                                            if new_words and bs_words:
                                                overlap = new_words & bs_words
                                                if overlap and (len(overlap) / max(len(new_words), 1) >= 0.5
                                                               or len(overlap) / max(len(bs_words), 1) >= 0.5):
                                                    alt_exists = True
                                                    log.info("KB %s: dedup %s — word overlap with batch page %s (shared: %s)",
                                                             slug, page_path, bs, ", ".join(overlap))
                                                    break
                                    if alt_exists:
                                        continue
                                    page = self._render_template(etype,
                                        title=description, category=source_type,
                                        taxonomy_path=self._classify(etype, source_type, description),
                                        sources=json.dumps([fname]),
                                        source_list=f"- [[{source_display}|{fname}]]",
                                        date=date_str,
                                        provenance="compiled",
                                    )
                                    # Inject slug + created_reason into frontmatter
                                    if "---" in page:
                                        fm_parts = page.split("---", 2)
                                        if len(fm_parts) >= 3:
                                            fm_parts[1] = fm_parts[1].rstrip() + f'\nslug: "{raw_slug}"\n'
                                            if created_reason:
                                                fm_parts[1] = fm_parts[1].rstrip() + f'\ncreated_reason: "{created_reason}"\n'
                                            page = "---".join(fm_parts)
                                    self._writer.write(full_path, page)
                                    wiki_updates.append(f"created {page_path}")
                                    # Track for index update
                                    if page_path.startswith("entities/"):
                                        created_entities.append(page_path)
                                    elif page_path.startswith("concepts/"):
                                        created_concepts.append(page_path)

                        elif line.startswith("UPDATE "):
                            parts = line[7:].split(":", 1)
                            if len(parts) == 2:
                                page_path = parts[0].strip()
                                note = parts[1].strip()
                                full_path = f"{base}/wiki/{page_path}.md"
                                if self._reader.exists(full_path):
                                    # Insert the update marker BEFORE any existing
                                    # ## References block so _numberify_sources can
                                    # cleanly strip + rebuild references. Appending
                                    # at EOF would orphan the new [Source: ...]
                                    # behind the old reference list.
                                    marker = (
                                        f"\n\n> **Update from [[{fname}]]**: "
                                        f"{note} [Source: {fname}]\n"
                                    )
                                    try:
                                        existing_raw = self._reader.read(full_path).raw
                                    except Exception:
                                        existing_raw = ""
                                    ref_match = self._REFERENCES_BLOCK_RE.search(existing_raw) if existing_raw else None
                                    if ref_match:
                                        updated_raw = (
                                            existing_raw[: ref_match.start()].rstrip()
                                            + marker
                                            + existing_raw[ref_match.start():]
                                        )
                                        self._writer.write(full_path, updated_raw)
                                    else:
                                        self._writer.append(full_path, marker)
                                    # Re-run the numbering pass so [Source: fname] becomes [N]
                                    # and the ## References section stays consistent.
                                    self._renumberify_article(full_path, [fname], slug)
                                    wiki_updates.append(f"updated {page_path}")

                # Add created entity/concept pages to index
                if created_entities:
                    new = [p for p in created_entities if f"[[{p}]]" not in index_content]
                    if new:
                        entry = "\n".join(f"- [[{p}]]" for p in new)
                        index_content = index_content.replace(
                            "<!-- Entity pages:",
                            f"<!-- Entity pages:\n{entry}",
                        )
                if created_concepts:
                    new = [p for p in created_concepts if f"[[{p}]]" not in index_content]
                    if new:
                        entry = "\n".join(f"- [[{p}]]" for p in new)
                        index_content = index_content.replace(
                            "<!-- Concept pages:",
                            f"<!-- Concept pages:\n{entry}",
                        )

                # Log contradictions (source page may not exist yet)
                if contradictions and contradictions != "none found":
                    try:
                        self._writer.append(f"{base}/wiki/sources/{source_slug}.md",
                            f"\n## Contradictions Detected\n{contradictions}\n")
                    except FileNotFoundError:
                        log.debug("KB %s: source page %s not found for contradiction log", slug, source_slug)

                # Update index — skip if this source is already listed
                dest_path = f"library/{source_type}/{date_folder}/{fname}"
                if f"### [{fname}]" not in index_content:
                    entry = f"\n### [{fname}]({dest_path})\n- Type: {source_type}\n- Summary: {summary}\n- Hash: {content_hash}\n"
                    index_content = index_content.replace(
                        "<!-- Each source: link, one-line summary, date ingested -->",
                        f"<!-- Each source: link, one-line summary, date ingested -->\n{entry}",
                    )

                # Record full provenance — only pages created by THIS source
                lib_path = f"library/{source_type}/{date_folder}/{fname}"
                file_pages = [f"sources/{source_slug}"]
                file_pages.extend(created_entities)
                file_pages.extend(created_concepts)
                # Also count updates (not just creates)
                file_pages.extend(u.split(" ", 1)[-1] for u in wiki_updates if u.startswith("updated ") and fname in u)
                vault_src = vault_sources.get(fname, "")
                self._record_source(
                    state, fname,
                    content_hash=content_hash,
                    vault_source=vault_src,
                    source_type=source_type,
                    library_path=lib_path,
                    produced_pages=file_pages,
                    agent="librarian",
                )
                ingested.append(fname)
                self._move_to_library(
                    raw_file, base, fname, date_folder,
                    slug=slug, taxonomy_path=source_taxonomy_path,
                )
                # Atomic save: index FIRST (so it's never behind state), then state
                self._writer.write(f"{base}/wiki/.index.md", index_content)
                self._write_compile_state(slug, state)

                log.info("KB %s: ingested %s (hash %s, %d pages)", slug, fname, content_hash, len(file_pages))

                # ── Observability: per-file activity + decision + graph population ──
                # This is the single point where one source transitions from
                # "raw file in inbox" to "durable knowledge". Rule #13 requires
                # it to produce structured evidence that the agent can see.
                _graph_result = self._populate_graph_from_ingest(
                    source_file=fname,
                    source_slug=source_slug,
                    entities_block=entities_block,
                    concepts_block=concepts,
                    kb_slug=slug,
                    source_text=source_text,
                )

                # Phase 5 v2 — multi-modal graph: register figure entities
                # and emit `depicts` triples for every embedded image that
                # produced a vision description in this file's ExtractResult.
                # Piggybacks on the same kb_slug / source_slug identity as
                # the classify-LLM triples above. No-op when the opt-in
                # flag was disabled (no Image elements in the result) OR
                # when the vision call didn't produce a description (image
                # element stays, description paragraph absent → only the
                # structural ``part_of`` triple is emitted).
                try:
                    _image_graph = self._populate_graph_from_images(
                        source_slug=source_slug,
                        source_file=fname,
                        kb_slug=slug,
                        extract_result=_extract_result,
                    )
                    if _image_graph.get("triples"):
                        log.info(
                            "KB %s: image-graph %s → %d figures, %d depicts, %d part_of",
                            slug, fname,
                            _image_graph["figures"],
                            _image_graph["depicts_triples"],
                            _image_graph["part_of_triples"],
                        )
                except Exception:
                    log.debug(
                        "kb: _populate_graph_from_images failed for %s",
                        fname, exc_info=True,
                    )

                # Empty-extraction retry: when the LLM produced zero usable
                # entities/concepts AND the regex fallback also found nothing
                # (or produced a weak result), escalate the model tier and
                # re-enqueue via the persistent work queue. Same pattern as
                # language-drift retry: at most one escalation per file per
                # reason, guarded by `_empty_extraction_retry` on source_meta.
                # The work queue owns retry lifecycle — infinite retry with
                # exponential backoff, survives server restarts.
                _already_empty_retried = (
                    isinstance(source_meta, dict)
                    and source_meta.get("_empty_extraction_retry")
                )
                if (
                    _graph_result.get("empty_extraction")
                    and not _graph_result.get("used_fallback")
                    and not _already_empty_retried
                    and not self._called_from_queue
                    and self._work_queue
                ):
                    _escalation_map = {"fast": "capable", "capable": "reasoning"}
                    _next_tier = _escalation_map.get(_classify_tier)
                    if _next_tier:
                        try:
                            asyncio.create_task(self._work_queue.enqueue(
                                "ingest",
                                {
                                    "slug": slug,
                                    "reason": "empty_extraction",
                                    "empty_extraction_tier": _next_tier,
                                    "target_file": fname,
                                },
                                deduplicate=True,
                            ))
                            log.info(
                                "KB %s: queued ingest retry at tier %s due to "
                                "empty entity/concept extraction for %s",
                                slug, _next_tier, fname,
                            )
                            self._log_activity(
                                "ingest_empty_extraction_retry_queued",
                                f"{fname} had no usable entities — retrying at tier {_next_tier}",
                                {
                                    "slug": slug,
                                    "file": fname,
                                    "next_tier": _next_tier,
                                    "previous_tier": _classify_tier,
                                },
                                importance="medium",
                            )
                        except Exception:
                            log.debug(
                                "Failed to enqueue empty-extraction retry",
                                exc_info=True,
                            )
                    else:
                        # Already at highest tier — record defeat so the
                        # user sees it in the decisions log, but don't
                        # keep spinning. Manual re-ingest or model change
                        # is the only recourse.
                        log.warning(
                            "KB %s: empty extraction at top tier (%s) for %s — "
                            "giving up retry, file landed in graph with regex fallback only",
                            slug, _classify_tier, fname,
                        )
                        self._log_activity(
                            "ingest_empty_extraction_exhausted",
                            f"{fname} still produced no entities at tier {_classify_tier}",
                            {"slug": slug, "file": fname, "top_tier": _classify_tier},
                            importance="high",
                        )

                # All language variables are pre-initialized with safe
                # defaults at the top of the per-file block, so they're
                # always defined here — no need for locals().get().
                _drift_status = _language_check.get("status", "unknown")
                self._log_activity(
                    "ingested",
                    f"KB {slug}: ingested {fname}",
                    {
                        "slug": slug,
                        "file": fname,
                        "source_type": source_type,
                        "content_hash": content_hash,
                        "pages": len(file_pages),
                        "content_language": content_lang,
                        "output_language": output_lang,
                        "language_adherence": _drift_status,
                        "entities_added": _graph_result.get("entities", 0),
                        "concepts_added": _graph_result.get("concepts", 0),
                        "triples_added": _graph_result.get("triples", 0),
                    },
                    importance="medium",
                )
                await self._record_decision(
                    action_type="ingest_file",
                    action_target=f"kb/{slug}/{fname}",
                    rationale=(
                        f"Classified as {source_type}; policy={_policy} "
                        f"({_policy_source}); adherence={_drift_status}; "
                        f"extracted {_graph_result.get('entities', 0)} entities "
                        f"+ {_graph_result.get('concepts', 0)} concepts"
                    ),
                    details={
                        "slug": slug,
                        "file": fname,
                        "source_type": source_type,
                        "content_hash": content_hash,
                        "pages": len(file_pages),
                        "content_language": content_lang,
                        "output_language": output_lang,
                        "language_policy": _policy,
                        "language_policy_source": _policy_source,
                        "language_adherence": _drift_status,
                        "model_tier": _classify_tier,
                        "graph": _graph_result,
                    },
                )
                # Success: the path works. Reset the consecutive-crash
                # counter so transient blips that recover don't slowly
                # accumulate toward the circuit-breaker threshold.
                self._consecutive_crash_counts.clear()

            except Exception as _crash_exc:
                # Safety net: an unexpected failure processing ONE file
                # must never kill the entire batch. Log, record a failed
                # decision, escalate the traceback to /logs, continue.
                # Plus: classify the crash (bug vs transient) and trip a
                # circuit breaker after N consecutive identical errors
                # so a code bug surfaces as one halt event instead of
                # 200 silent retries.
                _err_type = type(_crash_exc).__name__
                _crash_class = self._classify_crash(_crash_exc)
                log.exception(
                    "KB %s: unexpected failure processing %s — skipping file",
                    slug, raw_file.name,
                )
                self._log_activity(
                    "ingest_file_crashed",
                    f"Ingest crashed on {raw_file.name} in KB {slug}: {_err_type}",
                    {
                        "slug": slug,
                        "file": raw_file.name,
                        "error": str(_crash_exc)[:500],
                        "error_type": _err_type,
                        "crash_class": _crash_class,
                    },
                    importance="high",
                )
                await self._record_decision(
                    action_type="ingest_file",
                    action_target=f"kb/{slug}/{raw_file.name}",
                    contract_result="failed",
                    rationale=(
                        f"Unexpected {_err_type} during ingest "
                        f"({_crash_class}-class)"
                    ),
                    details={
                        "slug": slug,
                        "file": raw_file.name,
                        "error": str(_crash_exc)[:500],
                        "crash_class": _crash_class,
                    },
                )
                # Escalate traceback to ErrorLogger so /logs surfaces the
                # crash with full traceback. Best-effort: missing/broken
                # logger never breaks the safety net itself.
                err_logger = getattr(self, "_error_logger", None)
                if err_logger is not None and hasattr(err_logger, "log_exception"):
                    try:
                        await err_logger.log_exception(
                            _crash_exc,
                            source="kb_ingest",
                            context={
                                "slug": slug,
                                "file": raw_file.name,
                                "crash_class": _crash_class,
                            },
                        )
                    except Exception:
                        log.debug("kb: error_logger.log_exception failed", exc_info=True)

                # Circuit breaker: count consecutive crashes of the same
                # error_type. If we hit the threshold (3 for bug-class,
                # 10 for transient), halt the rest of the batch with one
                # high-importance "circuit broken" event. Without this,
                # a code bug like the 2026-04-27 missing _vault attribute
                # silently retried across 200 files before anyone
                # noticed. Counters reset on any successful file in the
                # same batch (success means the path works) and at the
                # start of each batch.
                self._consecutive_crash_counts[_err_type] = (
                    self._consecutive_crash_counts.get(_err_type, 0) + 1
                )
                _count = self._consecutive_crash_counts[_err_type]
                _threshold = (
                    self._BUG_CLASS_THRESHOLD
                    if _crash_class == "bug"
                    else self._TRANSIENT_THRESHOLD
                )
                if _count >= _threshold:
                    self._log_activity(
                        "ingest_circuit_broken",
                        (
                            f"Halting batch in KB {slug} after {_count} "
                            f"consecutive {_err_type} crashes "
                            f"({_crash_class}-class). Likely a code or "
                            f"infrastructure issue, not transient — see "
                            f"/decisions and /logs for the traceback."
                        ),
                        {
                            "slug": slug,
                            "error_type": _err_type,
                            "crash_class": _crash_class,
                            "consecutive_count": _count,
                            "threshold": _threshold,
                            "last_error": str(_crash_exc)[:300],
                            "last_file": raw_file.name,
                        },
                        importance="high",
                    )
                    break
                continue
        if ingested:
            index_content = self._update_frontmatter(index_content, "updated", date_str)
            self._writer.write(f"{base}/wiki/.index.md", index_content)
            self._update_index_stats(slug)
            state["last_ingest"] = now.isoformat()
            self._write_compile_state(slug, state)
            self._append_log(slug, "ingest", f"{len(ingested)} sources: {', '.join(ingested)}")

        return {
            "slug": slug,
            "ingested": ingested,
            "skipped": skipped,
            "wiki_updates": wiki_updates,
            "count": len(ingested),
        }

    async def _describe_image(self, image_path: Path, ocr_text: str = "") -> str:
        """Use vision LLM to describe an image. Returns text description."""
        import base64

        from agntspace.llm.base import ImageContent

        # Read and encode image
        raw_bytes = image_path.read_bytes()
        b64 = base64.b64encode(raw_bytes).decode()

        # Determine media type
        ext = image_path.suffix.lower()
        media_types = {
            ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".gif": "image/gif", ".webp": "image/webp", ".svg": "image/svg+xml",
        }
        media_type = media_types.get(ext, "image/png")

        image = ImageContent(base64_data=b64, media_type=media_type)

        prompt_parts = [
            "Describe this image in detail for a knowledge base. Include:",
            "1. What the image shows (diagram, photo, screenshot, chart, etc.)",
            "2. Any text, labels, or annotations visible",
            "3. Key information that should be indexed",
            "4. People, organizations, or concepts depicted",
            "5. How this relates to a knowledge base context",
            "",
            "Be thorough — this description replaces the image for text-based search and wiki compilation.",
        ]
        if ocr_text:
            prompt_parts.append(
                f"\n\nOCR has already extracted the following text from this image. "
                f"Use it as ground truth for any text visible, and focus your description "
                f"on visual elements, layout, and context that OCR cannot capture:\n\n{ocr_text}"
            )

        response = await self._llm.complete_vision(
            prompt="\n".join(prompt_parts),
            images=[image],
            max_tokens=1024,
        )

        log.info("Image described via vision LLM: %s (%d chars)", image_path.name, len(response.content))
        return response.content

    async def _resolve_embedded_images(
        self,
        source_text: str,
        raw_file: Path,
        base: str,
        slug: str,
    ) -> list:
        """Find and resolve image references inside a markdown source file.

        Resolves both local sibling images (``![alt](photo.png)``,
        ``![[Pasted image.png]]``) and remote URLs (``![alt](https://...)``).
        Remote images are downloaded into the KB inbox so they travel
        through the normal ingest pipeline.

        Returns a list of ``ResolvedImage`` objects.
        """
        try:
            from agntspace.kb.image_resolver import resolve_all_images
        except ImportError:
            return []

        source_dir = raw_file.parent
        inbox_dir = self._resolve(f"{base}/inbox")

        # Extra search paths: the KB inbox itself (watcher may have copied
        # siblings there) and the vault root (in case the user's folder
        # structure places images at the root level).
        search_dirs = [inbox_dir]
        vault_dir = getattr(self._reader, "_vault_dir", None)
        if vault_dir and Path(vault_dir).is_dir():
            search_dirs.append(Path(vault_dir))

        try:
            return resolve_all_images(
                source_text,
                source_dir,
                dest_dir=inbox_dir,
                search_dirs=search_dirs,
                max_remote=10,
                download_timeout=15,
            )
        except Exception:
            log.debug("Image resolution failed for %s", raw_file.name, exc_info=True)
            return []

    async def _describe_embedded_image(self, resolved_image) -> str:
        """Run OCR + vision LLM on a resolved embedded image.

        Mirrors the direct-image-file pipeline (OCR → vision) but for
        images found via markdown references rather than as standalone
        inbox files.  Returns the description text, or empty string on
        failure.
        """
        image_path = resolved_image.local_path
        if not image_path or not image_path.exists():
            return ""

        try:
            # OCR pass (optional — graceful when Tesseract not installed)
            ocr_text = ""
            try:
                from agntspace.llm.ocr import extract_text as ocr_extract
                ocr_text = ocr_extract(image_path)
            except Exception:
                pass

            # Vision LLM pass
            description = await self._describe_image(image_path, ocr_text=ocr_text)
            return description
        except Exception:
            log.debug(
                "Could not describe embedded image %s",
                image_path.name, exc_info=True,
            )
            return ""

    # Max destination path length for thematic layout — Windows MAX_PATH is
    # 260, leave headroom for filename + separators. Long taxonomy paths fall
    # back to ``unsorted/`` with a high-importance activity event so the user
    # sees the degradation instead of silent truncation.
    _MAX_LIBRARY_PATH = 240  # arch:deterministic — Windows MAX_PATH safety margin

    def _sanitize_taxonomy_segment(self, segment: str) -> str:
        """Reduce one taxonomy slug to a safe folder name.

        The classifier returns lowercase-hyphenated slugs from taxonomy.yaml,
        but LLM paths sometimes leak stray whitespace, accented characters,
        or path separators. Keep only [a-z0-9_-], collapse everything else
        to ``-``, strip leading/trailing punctuation. Empty results are
        rejected by the caller (folds into ``unsorted/``).
        """
        import re
        s = str(segment or "").strip().lower()
        s = re.sub(r"[^a-z0-9_-]+", "-", s)
        return s.strip("-_")

    def _resolve_library_dir(
        self,
        base: str,
        filename: str,
        date_folder: str,
        layout: str,
        taxonomy_path: str | None,
        source_type: str,
    ) -> tuple[Path, str]:
        """Resolve the target library directory for one source file.

        Returns ``(dest_dir, fallback_reason)``. ``fallback_reason`` is an
        empty string on the happy path; otherwise it names why the thematic
        layout degraded (``no_path``, ``invalid_segments``, ``path_too_long``).
        Callers emit a medium/high activity event when fallback_reason is set.
        """
        library_root = self._resolve(f"{base}/library")

        if layout == "flat":
            return library_root, ""

        if layout == "type-date":
            return library_root / source_type / date_folder, ""

        # thematic
        if not taxonomy_path or taxonomy_path.strip().lower() in ("", "general", "unsorted"):
            return library_root / "unsorted", "no_path"

        segments = [
            self._sanitize_taxonomy_segment(p)
            for p in str(taxonomy_path).replace("\\", "/").split("/")
            if p.strip() and p.strip() != ".."
        ]
        segments = [s for s in segments if s]
        if not segments:
            return library_root / "unsorted", "invalid_segments"

        dest_dir = library_root.joinpath(*segments)
        # Windows MAX_PATH safety — full dest including filename must fit.
        full_len = len(str(dest_dir / filename))
        if full_len > self._MAX_LIBRARY_PATH:
            return library_root / "unsorted", "path_too_long"

        return dest_dir, ""

    def merge_wiki_files_for_entity_pair(
        self,
        slug_keep: str,
        slug_remove: str,
        *,
        dry_run: bool = False,
    ) -> dict:
        """Wiki-file merge follow-through after an entity registry merge
        (Gap 2, shipped 2026-04-28). When the graph layer canonicalizes
        two entities into one, the corresponding wiki article files don't
        automatically follow — leaving stale duplicate articles on disk.

        This walker finds both articles by slug (filename-stem fast path
        first, then frontmatter scan), and if both exist at DIFFERENT
        paths, concatenates the removed file's body into the kept file
        under a ``## Merged from {title}`` marker, then archives the
        removed file to ``knowledge/{kb}/.archives/wiki-merged/{date}/``
        for retrieval.

        Conservative: skips silently when only one side has a file (the
        other entity is graph-only — no merge needed), when both
        resolve to the same file (already canonical), or when reads fail.
        ``dry_run=True`` returns the audit shape without touching disk.

        Returns dict with keys:
          ``merged: bool``, ``reason: str`` (when merged=False),
          ``kept_path``, ``removed_path``, ``archived_to``,
          ``appended_chars``.
        """
        import shutil
        from datetime import UTC, datetime

        keep_result = self._find_article_by_slug(slug_keep)
        remove_result = self._find_article_by_slug(slug_remove)

        if remove_result is None:
            return {"merged": False, "reason": "no_wiki_file_for_removed_slug",
                    "slug_keep": slug_keep, "slug_remove": slug_remove}
        if keep_result is None:
            # Removed entity has a wiki file, kept doesn't. Two options:
            # (a) Rename the removed file to match the kept slug.
            # (b) Leave alone — user can manually rename via wiki UI.
            # Conservative pick (b): the rename would change the filename
            # which is the wiki's display name — surprising side effect.
            return {"merged": False, "reason": "no_wiki_file_for_kept_slug",
                    "slug_keep": slug_keep, "slug_remove": slug_remove,
                    "removed_path": str(remove_result[2])}

        keep_kb, _keep_subdir, keep_path, _keep_meta, keep_content = keep_result
        remove_kb, _remove_subdir, remove_path, remove_meta, remove_content = remove_result

        if str(keep_path) == str(remove_path):
            # Both slugs resolved to the same file (already canonical via
            # filename — entity registry merge was metadata-only).
            return {"merged": False, "reason": "same_file",
                    "slug_keep": slug_keep, "slug_remove": slug_remove}

        # Strip removed file's frontmatter — body only goes into the kept file.
        removed_body = remove_content
        if "---" in remove_content:
            parts = remove_content.split("---", 2)
            if len(parts) >= 3:
                removed_body = parts[2].strip()

        date_str = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S")
        date_only = date_str.split()[0]
        removed_title = remove_meta.get("title", slug_remove)

        merge_marker = (
            f"\n\n<!-- merged from {slug_remove} on {date_str} -->\n\n"
            f"## Merged from {removed_title}\n\n{removed_body}"
        )

        if dry_run:
            return {
                "merged": False,
                "dry_run": True,
                "kept_path": str(keep_path),
                "removed_path": str(remove_path),
                "kept_kb": keep_kb,
                "removed_kb": remove_kb,
                "appended_chars": len(merge_marker),
                "removed_title": removed_title,
            }

        # Append into kept file.
        try:
            keep_rel = self._to_logical(keep_path)
            self._writer.append(keep_rel, merge_marker, contract_action="modify_wiki")
        except Exception:
            log.warning(
                "merge_wiki_files: append failed for kept file %s",
                keep_path, exc_info=True,
            )
            return {"merged": False, "reason": "append_failed",
                    "kept_path": str(keep_path), "removed_path": str(remove_path)}

        # Archive removed file. Use vault-relative archive dir under the
        # removed file's KB so retrieval is obvious. Each .archives entry
        # is namespaced by date so concurrent merges of different pairs
        # don't collide.
        archive_dir = (
            self._writer._vault_dir
            / Path(f"agntspace-knowledge/{remove_kb}/.archives/wiki-merged/{date_only}")
        )
        archive_target = archive_dir / remove_path.name

        try:
            archive_dir.mkdir(parents=True, exist_ok=True)
            # Collision handling: if same-day merge of same-name file already
            # exists in the archive, suffix the new copy.
            if archive_target.exists():
                stem = remove_path.stem
                ext = remove_path.suffix
                idx = 1
                while archive_target.exists() and idx < 100:
                    archive_target = archive_dir / f"{stem}.{idx}{ext}"
                    idx += 1
            shutil.move(str(remove_path), str(archive_target))
        except Exception:
            log.warning(
                "merge_wiki_files: archive move failed for %s → %s",
                remove_path, archive_target, exc_info=True,
            )
            # We've already appended the body to kept; the removed file
            # is still on disk. Return half-applied so caller can decide
            # what to do (most callers will accept it — content was
            # preserved, archive failed).
            return {
                "merged": True,
                "kept_path": str(keep_path),
                "removed_path": str(remove_path),
                "archived_to": "",
                "archive_failed": True,
                "appended_chars": len(merge_marker),
            }

        log.info(
            "Wiki-file merge: %s → %s, archived to %s (%d chars appended)",
            remove_path, keep_path, archive_target, len(merge_marker),
        )
        return {
            "merged": True,
            "kept_path": str(keep_path),
            "removed_path": str(remove_path),
            "archived_to": str(archive_target),
            "appended_chars": len(merge_marker),
            "removed_title": removed_title,
        }

    def _apply_to_existing_on_dedup(
        self,
        *,
        slug: str,
        existing_full_path: str,
        new_content: str,
        source_texts: list[str],
        date_str: str,
        state: dict,
        articles_written: list[str],
        article_path: str,
    ) -> str:
        """When compile dedup catches a near-duplicate, redirect the new
        content into the EXISTING article instead of dropping it (Gap 1,
        shipped 2026-04-28).

        Returns one of:
          - ``"stub_replaced"``  — existing was a TODO-heavy stub; overwritten
                                   with the new content + recorded
          - ``"enriched"``       — existing had real content; new body appended
                                   under an "Updated from compile" marker
          - ``"too_similar"``    — new body is >60% similar to existing; nothing
                                   appended (no value added)
          - ``"missing"``        — existing file vanished between dedup and
                                   write (race / FS lock / external delete);
                                   caller should fall through to fresh write
          - ``"error"``          — read or write raised; caller should fall
                                   through (defensive — never break the batch)

        Mirrors the legacy enrichment block at the matching-path branch
        but operates on the dup-target's path. Caller is responsible for
        the ``continue`` / fall-through decision.
        """
        from difflib import SequenceMatcher

        # Read existing — guard against race (file vanished after dedup).
        try:
            if not self._reader.exists(existing_full_path):
                return "missing"
            existing_doc = self._reader.read(existing_full_path)
        except Exception:
            log.warning(
                "KB %s: dedup-redirect read failed for %s",
                slug, existing_full_path, exc_info=True,
            )
            return "error"

        existing_text = existing_doc.content.strip()
        todo_count = existing_text.count("[TODO:")
        real_content_len = len(existing_text.replace("[TODO:", "").strip())

        # Stub replacement: existing is mostly placeholders → overwrite
        # with the new (richer) content. Same threshold as the legacy
        # enrichment block (3+ TODOs OR <300 real chars).
        if todo_count >= 3 or real_content_len < 300:
            try:
                self._writer.write(existing_full_path, new_content)
            except Exception:
                log.warning(
                    "KB %s: dedup-redirect stub-replace write failed for %s",
                    slug, existing_full_path, exc_info=True,
                )
                return "error"
            articles_written.append(article_path)
            source_fnames = [
                sf.split("\n")[0].replace("### ", "").strip()
                for sf in source_texts
            ]
            compile_record = state.setdefault("compiled_articles", {})
            compile_record[article_path] = {
                "compiled_at": date_str,
                "derived_from": source_fnames[:20],
                "agent": "editor",
                "stub_replaced": True,
                "redirected_from_dedup": True,
            }
            return "stub_replaced"

        # Non-stub: extract the new body (strip frontmatter) and decide
        # whether enrichment adds value (similarity check).
        new_body = new_content
        if "---" in new_content:
            fm_parts = new_content.split("---", 2)
            if len(fm_parts) >= 3:
                new_body = fm_parts[2].strip()

        if not new_body or len(new_body) <= 100:
            # Nothing meaningful to add.
            return "too_similar"

        similarity = SequenceMatcher(None, existing_text[:3000], new_body[:3000]).ratio()
        if similarity > 0.6:
            return "too_similar"

        # Append the new body under an explicit update marker so the
        # provenance is honest about which compile pass added what.
        source_fnames = [
            sf.split("\n")[0].replace("### ", "").strip()
            for sf in source_texts
        ]
        update_note = (
            f"\n\n<!-- compile update {date_str} (dedup-redirect) -->\n\n"
            f"> **Updated from compile ({date_str})** — new sources: "
            f"{', '.join(source_fnames[:5])}\n\n"
        )
        try:
            self._writer.append(existing_full_path, update_note + new_body)
        except Exception:
            log.warning(
                "KB %s: dedup-redirect enrichment append failed for %s",
                slug, existing_full_path, exc_info=True,
            )
            return "error"

        articles_written.append(article_path)
        compile_record = state.setdefault("compiled_articles", {})
        compile_record[article_path] = {
            "compiled_at": date_str,
            "derived_from": source_fnames[:20],
            "agent": "editor",
            "enriched": True,
            "redirected_from_dedup": True,
        }
        return "enriched"

    def _safe_unlink_dedup(
        self,
        raw_file: Path,
        filename: str,
        kb_slug: str,
        reason: str,
    ) -> None:
        """Delete an inbox file that was rejected as a duplicate.

        Use this for the four ingest dedup paths — unchanged content
        already in library, same-content-different-name within KB,
        cross-KB duplicate, and empty file. The previous semantics
        (``_move_to_library(taxonomy_path=None)``) parked these files
        in ``library/unsorted/`` next to a perfectly-good library copy
        elsewhere, which is exactly the architectural duplication
        Wolf surfaced 2026-04-28: byte-identical originals at two
        library paths for the same conceptual source.

        Total fail-safe: if unlink raises (file already gone, FS
        permission, parent dir lost mid-call) we log + continue.
        Re-detecting the file on the next watcher cycle would just
        run dedup again and end here, so durability is irrelevant.
        """
        try:
            if raw_file.exists():
                raw_file.unlink()
                log.info(
                    "KB %s: deleted inbox %s (%s — already in library)",
                    kb_slug, filename, reason,
                )
        except Exception:
            log.warning(
                "KB %s: could not delete inbox copy of %s after %s dedup",
                kb_slug, filename, reason,
                exc_info=True,
            )

    def _move_to_library(
        self,
        raw_file: Path,
        base: str,
        filename: str,
        date_folder: str,
        *,
        slug: str | None = None,
        taxonomy_path: str | None = None,
        layout: str | None = None,
    ) -> None:
        """Move a source file out of inbox into the KB's library/.

        Layout resolution order: explicit ``layout`` param → SCHEMA.md via
        ``slug`` → hardcoded ``type-date`` fallback. Existing KBs without
        ``library_layout`` in their SCHEMA.md stay on ``type-date`` so
        their on-disk arrangement is untouched (no-surprises guarantee).
        """
        import shutil
        stype, _ = self._classify_source(filename)

        # Resolve effective layout mode
        effective_layout = (layout or "").strip().lower()
        if effective_layout not in self._VALID_LIBRARY_LAYOUTS:
            effective_layout = self._kb_library_layout(slug) if slug else "type-date"

        dest_dir, fallback_reason = self._resolve_library_dir(
            base=base,
            filename=filename,
            date_folder=date_folder,
            layout=effective_layout,
            taxonomy_path=taxonomy_path,
            source_type=stype,
        )

        if fallback_reason:
            # Emit a visible event so thematic-layout degradation is
            # never silent. ``path_too_long`` is worth escalating to
            # ``medium`` because the wiki UI can't surface it otherwise.
            importance = "medium" if fallback_reason == "path_too_long" else "low"
            self._log_activity(
                "library_layout_fallback",
                f"{filename}: thematic layout fell back to unsorted/ ({fallback_reason})",
                {
                    "slug": slug or "",
                    "file": filename,
                    "layout": effective_layout,
                    "taxonomy_path": taxonomy_path or "",
                    "reason": fallback_reason,
                },
                importance=importance,
            )

        dest_dir.mkdir(parents=True, exist_ok=True)
        src = raw_file if isinstance(raw_file, Path) else Path(str(raw_file))
        dest = dest_dir / filename
        try:
            # shutil.move fails on Windows if dest exists. Remove it first
            # (we've already processed this content, so overwriting is correct).
            if dest.exists():
                dest.unlink()
            shutil.move(str(src), str(dest))
        except Exception as exc:
            log.warning("KB: failed to move %s to library: %s", filename, exc)
            # Last resort: if the file is still in the inbox after a failed move,
            # delete it so it doesn't get re-ingested forever.
            if src.exists() and dest.exists():
                try:
                    src.unlink()
                    log.info("KB: removed stale inbox copy of %s (already in library)", filename)
                except Exception:
                    log.exception("KB: could not remove stale inbox copy of %s", filename)
        # Clean up sidecar .source file if it exists
        source_meta = src.parent / f"{filename}.source"
        if source_meta.exists():
            try:
                source_meta.unlink()
            except Exception:
                pass

    # ── Library layout management ──

    async def park_unsupported_file(self, slug: str, src_path: Path, reason: str) -> Path | None:
        """Move an unsupported/oversized inbox file to library/unsupported/.

        Writes a sidecar ``.reason.txt`` next to the file explaining WHY
        it was skipped, and emits a medium-importance activity event so
        the user sees it in /decisions. Collisions get a numeric suffix.

        Returns the parked destination path on success, None on failure.
        """
        import shutil
        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/SCHEMA.md"):
            # 2026-04-27: default slug renamed `general` → `main`. Both
            # accepted: auto-create the missing default KB so the user's
            # vault doesn't get stuck on a fresh boot.
            if slug in ("main", "general"):
                try:
                    self.create_kb("Main" if slug == "main" else "General")
                except Exception:
                    log.warning("park_unsupported_file: could not auto-create default KB '%s'", slug)
                    return None
            else:
                log.warning("park_unsupported_file: KB %s not found", slug)
                return None

        dest_dir = self._resolve(f"{base}/library/unsupported")
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src_path.name
        if dest.exists() and dest.resolve() != src_path.resolve():
            stem, ext = src_path.stem, src_path.suffix
            for i in range(1, 100):
                alt = dest_dir / f"{stem}-{i}{ext}"
                if not alt.exists():
                    dest = alt
                    break

        try:
            with self._writer.trusted_scope("unsupported_file_parked"):
                shutil.move(str(src_path), str(dest))
        except Exception as exc:
            log.warning("park_unsupported_file: move failed for %s: %s", src_path.name, exc)
            return None

        sidecar = dest.with_suffix(dest.suffix + ".reason.txt")
        try:
            sidecar.write_text(self._format_unsupported_reason(reason, src_path.name), encoding="utf-8")
        except OSError:
            pass

        importance = "medium" if reason.startswith("oversized:") else "low"
        self._log_activity(
            "ingest_skipped_unsupported",
            f"Parked {src_path.name} to library/unsupported/ ({reason})",
            {
                "slug": slug,
                "file": src_path.name,
                "reason": reason,
                "parked_to": str(dest).replace("\\", "/"),
            },
            importance=importance,
        )
        await self._record_decision(
            action_type="ingest_file",
            action_target=f"kb/{slug}/{src_path.name}",
            contract_result="skipped",
            rationale=f"Parked {src_path.name} to library/unsupported/ ({reason})",
            details={
                "slug": slug,
                "file": src_path.name,
                "skip_reason": "unsupported",
                "reason": reason,
                "parked_to": str(dest).replace("\\", "/"),
            },
        )
        return dest

    def _format_unsupported_reason(self, reason: str, filename: str) -> str:
        """Build the human-readable .reason.txt body for a parked file."""
        from datetime import datetime
        now = datetime.now().isoformat(timespec="seconds")
        lines = [
            "# File parked: not supported by the ingest pipeline",
            "",
            f"File: {filename}",
            f"Parked at: {now}",
            "",
        ]
        if reason.startswith("oversized:"):
            try:
                size = int(reason.split(":", 1)[1])
                mb = size / 1024 / 1024
                lines.append(
                    f"Reason: file size {mb:.1f} MB exceeds the current 10 MB ingest cap."
                )
                lines.append("")
                lines.append(
                    "Options: compress / chunk the file, "
                    "or raise the cap via the kb-ingest skill config."
                )
            except ValueError:
                lines.append(f"Reason: oversized ({reason})")
        elif reason.startswith("unsupported_type:"):
            ext = reason.split(":", 1)[1]
            lines.append(
                f"Reason: extension '{ext}' is not in the supported list."
            )
            lines.append("")
            lines.append(
                "Supported: .md .txt .html .pdf .png .jpg .jpeg .csv .json .jsonl .vtt .srt"
            )
            lines.append(
                f"Options: convert to a supported type, "
                f"or request plugin support for '{ext}' files."
            )
        else:
            lines.append(f"Reason: {reason}")
        lines.append("")
        return "\n".join(lines)

    def set_library_layout(self, slug: str, layout: str) -> dict:
        """Set the library_layout field in SCHEMA.md. Creates the field if missing.

        Does NOT reorganize existing files — call reorganize_library() for that.
        Returns {layout, previous, ok}.
        """
        layout = str(layout or "").strip().lower()
        if layout not in self._VALID_LIBRARY_LAYOUTS:
            return {"error": f"invalid layout: {layout}",
                    "valid": sorted(self._VALID_LIBRARY_LAYOUTS)}
        schema_path = f"knowledge/{slug}/SCHEMA.md"
        if not self._reader.exists(schema_path):
            return {"error": f"SCHEMA.md not found for KB {slug}"}
        previous = self._kb_library_layout(slug)
        doc = self._reader.read(schema_path)
        meta = dict(doc.metadata or {})
        meta["library_layout"] = layout
        # Reassemble frontmatter + body. Use python-frontmatter via VaultWriter
        # when available; fall back to manual assembly.
        import frontmatter as _fm
        post = _fm.Post(doc.content, **meta)
        new_text = _fm.dumps(post) + "\n"
        self._writer.write(schema_path, new_text, trust_reason="library_layout_change")
        self._log_activity(
            "library_layout_changed",
            f"KB {slug}: library_layout {previous} → {layout}",
            {"slug": slug, "previous": previous, "new": layout},
            importance="medium",
        )
        return {"layout": layout, "previous": previous, "ok": True}

    def _source_taxonomy_for_file(self, slug: str, filename: str) -> str | None:
        """Look up the taxonomy_path recorded on the source_summary page
        for a library file, by filename stem. Returns None when no source
        page references this file.
        """
        stem = Path(filename).stem
        sources_dir = self._resolve(f"knowledge/{slug}/wiki/sources")
        if not sources_dir.is_dir():
            return None
        # Try exact stem match first (source pages usually share the stem)
        for ext in (".md",):
            candidate = sources_dir / f"{stem}{ext}"
            if candidate.is_file():
                try:
                    doc = self._reader.read(f"knowledge/{slug}/wiki/sources/{candidate.name}")
                    tp = str(doc.metadata.get("taxonomy_path") or "").strip()
                    return tp or None
                except Exception:
                    pass
        # Fallback: scan source pages for one referencing this filename.
        # 2026-05-09: explicit skip of dot-prefixed segments. The
        # ``VaultReader._SKIP_DIRS`` filter only applies to
        # ``list_files()``; this is a direct ``rglob`` walk so it must
        # honor the same exclusion manually. Without this guard, archived
        # source pages under ``.archives/`` could match an outdated
        # ``filename`` field and resolve a stale taxonomy_path.
        try:
            for src_page in sources_dir.rglob("*.md"):
                rel_parts = str(src_page).replace("\\", "/").split("/")
                if any(p.startswith(".") for p in rel_parts if p):
                    continue
                try:
                    doc = self._reader.read(f"knowledge/{slug}/wiki/sources/{src_page.name}")
                    if doc.metadata.get("filename") == filename:
                        tp = str(doc.metadata.get("taxonomy_path") or "").strip()
                        return tp or None
                except Exception:
                    continue
        except Exception:
            pass
        return None

    async def reorganize_library(self, slug: str, dry_run: bool = True) -> dict:
        """Reorganize existing library/ files to match the KB's current layout.

        Walks every file under library/ (skipping .archives, .quarantine,
        .history), computes the target path for each under the current
        layout + recorded taxonomy_path, and returns a list of moves.
        When ``dry_run`` is False, the moves execute and per-file activity
        events are emitted (medium importance).

        This is the "opt-in migration" path. The default layout on existing
        KBs stays ``type-date`` until the user changes it — see the
        ``no-surprises`` contract (CLAUDE.md §1).
        """
        import shutil
        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/SCHEMA.md"):
            return {"error": f"KB {slug} not found"}

        layout = self._kb_library_layout(slug)
        library_root = self._resolve(f"{base}/library")
        if not library_root.is_dir():
            return {"layout": layout, "moves": [], "executed": 0, "errors": []}

        # Both names for the quarantine subdir — defense-in-depth so
        # half-migrated vaults (legacy ``.quarantine`` + new ``quarantine``)
        # are both excluded from the library reorganize walk.
        _SKIP_DIRS = {".archives", ".quarantine", "quarantine", ".history", ".tmp"}
        moves: list[dict] = []
        seen_targets: set[str] = set()

        for current_path in library_root.rglob("*"):
            if not current_path.is_file():
                continue
            # Skip files inside protected subdirs
            rel_parts = current_path.relative_to(library_root).parts
            if any(part in _SKIP_DIRS for part in rel_parts):
                continue
            if current_path.name.startswith("."):
                continue

            filename = current_path.name
            source_type, _ = self._classify_source(filename)
            taxonomy_path = self._source_taxonomy_for_file(slug, filename)

            # Use a synthetic date_folder for type-date targets — the original
            # ingest date is unrecoverable without parsing .compile-state.json.
            # We pick the year-month of the file's current mtime as a reasonable
            # proxy; when migrating OUT of type-date to thematic, the path is
            # ignored anyway.
            from datetime import datetime as _dt
            date_folder = _dt.fromtimestamp(current_path.stat().st_mtime).strftime("%Y-%m")

            target_dir, fallback_reason = self._resolve_library_dir(
                base=base,
                filename=filename,
                date_folder=date_folder,
                layout=layout,
                taxonomy_path=taxonomy_path,
                source_type=source_type,
            )
            target = target_dir / filename

            if target.resolve() == current_path.resolve():
                continue  # already in the right place

            move_entry = {
                "from": str(current_path.relative_to(library_root)).replace("\\", "/"),
                "to": str(target.relative_to(library_root)).replace("\\", "/"),
                "taxonomy_path": taxonomy_path or "",
                "fallback_reason": fallback_reason,
                "collision": str(target) in seen_targets or (target.exists() and target != current_path),
            }
            seen_targets.add(str(target))
            moves.append(move_entry)

        if dry_run:
            return {
                "layout": layout,
                "dry_run": True,
                "moves": moves,
                "executed": 0,
                "errors": [],
            }

        # Execute moves. Use trusted_scope so every rename inside passes the
        # VaultWriter guard without individual contract actions.
        executed = 0
        errors: list[dict] = []
        with self._writer.trusted_scope("library_reorganize"):
            for m in moves:
                src = library_root / m["from"]
                dst = library_root / m["to"]
                try:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    if dst.exists() and dst.resolve() != src.resolve():
                        # Collision — skip to avoid destroying data
                        errors.append({"file": m["from"], "reason": "collision_with_existing"})
                        continue
                    shutil.move(str(src), str(dst))
                    executed += 1
                    self._log_activity(
                        "library_file_moved",
                        f"KB {slug}: {m['from']} → {m['to']}",
                        {"slug": slug, **m},
                        importance="low",
                    )
                except Exception as exc:
                    errors.append({"file": m["from"], "reason": str(exc)[:200]})

        # Clean up empty directories left behind
        for d in sorted(library_root.rglob("*"), key=lambda p: -len(str(p))):
            if d.is_dir() and not any(d.iterdir()):
                try:
                    d.rmdir()
                except OSError:
                    pass

        self._log_activity(
            "library_reorganize_completed",
            f"KB {slug}: reorganized {executed} file(s) to {layout} layout",
            {"slug": slug, "layout": layout, "executed": executed, "errors": len(errors)},
            importance="medium" if executed else "low",
        )
        await self._record_decision(
            action_type="library_reorganize",
            action_target=f"kb/{slug}",
            rationale=f"Reorganized {executed} file(s) to {layout} layout ({len(errors)} errors)",
            details={"slug": slug, "layout": layout, "executed": executed,
                     "errors": errors, "dry_run": False},
        )

        return {
            "layout": layout,
            "dry_run": False,
            "moves": moves,
            "executed": executed,
            "errors": errors,
        }

    # ── Compile ──

    @staticmethod
    def _normalize_compiled_article_frontmatter(
        content: str,
        article_title: str,
        flat_nodes: list,
        classify_fn,
    ) -> tuple[str, str, dict | None]:
        """Validate taxonomy_path exists + entity_type ↔ path pairing.

        Returns ``(normalized_content, validated_entity_type, change_event_or_None)``:
          - ``normalized_content`` — the article body with any taxonomy_path
            replacements applied (frontmatter only — body untouched).
          - ``validated_entity_type`` — the frontmatter entity_type, or "" when
            absent / unparseable. Caller uses this to label the graph entry.
          - ``change_event_or_None`` — when a pairing reconciliation fired, a
            dict the caller can hand to ActivityLogger:
              ``{"old_taxonomy_path", "new_taxonomy_path", "entity_type", "declared_entity_types"}``
            None when no change was made.

        ``flat_nodes`` is the result of ``flatten_taxonomy(load_taxonomy(...))``
        — passed in (rather than loaded inside) so the test can stand up a
        synthetic taxonomy and so a single load is reused across articles
        in a compile batch.

        ``classify_fn`` is a callable ``(entity_type, category, title) -> path``
        — typically ``self._classify``. Passed in for testability.

        The pairing check uses the taxonomy YAML's per-node ``entity_types``
        declaration as the source of truth: if the path's declared set is
        non-empty AND the frontmatter ``entity_type`` is not in it, prefer
        the entity_type (more reliable signal than path) and reclassify the
        path via ``classify_fn``. The reclassified path is only adopted when
        it differs from the current path AND is a real node — never invents.
        """
        if "---" not in content:
            return content, "", None
        parts = content.split("---", 2)
        if len(parts) < 3:
            return content, "", None

        tax_path = ""
        etype_fm = ""
        for line in parts[1].strip().split("\n"):
            if line.startswith("taxonomy_path:"):
                tax_path = line.split(":", 1)[1].strip().strip('"').strip("'")
            elif line.startswith("entity_type:"):
                etype_fm = line.split(":", 1)[1].strip().strip('"').strip("'")

        validated_etype = etype_fm
        change: dict | None = None

        if not tax_path:
            return content, validated_etype, None

        known = {n["path"] for n in flat_nodes}
        by_path = {n["path"]: n for n in flat_nodes}

        # Step 1: invalid path → reclassify
        if tax_path not in known:
            fixed = classify_fn(etype_fm, "", article_title or "")
            if fixed and fixed in known:
                parts[1] = parts[1].replace(
                    f'taxonomy_path: "{tax_path}"', f'taxonomy_path: "{fixed}"'
                )
                parts[1] = parts[1].replace(
                    f"taxonomy_path: {tax_path}", f'taxonomy_path: "{fixed}"'
                )
                content = "---".join(parts)
                tax_path = fixed

        # Step 2: pairing check — entity_type must be in the path's declared set
        node = by_path.get(tax_path)
        declared = list(node.get("entity_types") or []) if node else []
        if etype_fm and declared and etype_fm not in declared:
            new_path = classify_fn(etype_fm, "", article_title or "")
            if new_path and new_path != tax_path and new_path in known:
                change = {
                    "old_taxonomy_path": tax_path,
                    "new_taxonomy_path": new_path,
                    "entity_type": etype_fm,
                    "declared_entity_types": declared,
                }
                parts[1] = parts[1].replace(
                    f'taxonomy_path: "{tax_path}"', f'taxonomy_path: "{new_path}"'
                )
                parts[1] = parts[1].replace(
                    f"taxonomy_path: {tax_path}", f'taxonomy_path: "{new_path}"'
                )
                content = "---".join(parts)

        return content, validated_etype, change

    async def compile_wiki(self, slug: str, full: bool = False) -> dict:
        """Compile sources into wiki articles. Incremental by default.

        Wrapped in ``_scoped_pipeline`` so every write issued during
        compile is either authorised (``write_vault``/``modify_wiki``)
        or trusted (``kb_compile``). Same observability contract as
        ``ingest``: activity start/end events, decision record, graph
        refresh at the end.
        """
        if self._orchestrator and hasattr(self._orchestrator, "_active_tasks"):
            self._orchestrator._active_tasks["editor"] = f"Compiling wiki for {slug}"
        self._log_activity(
            "compile_started",
            f"KB {slug}: compile started",
            {"slug": slug, "full": full},
            importance="low",
        )
        try:
            async with self._scoped_pipeline("kb_compile", "compile"):
                result = await self._do_compile_wiki(slug, full=full)
                _count = len(result.get("articles", [])) if isinstance(result, dict) else 0
                self._log_activity(
                    "compile_completed",
                    f"KB {slug}: compile produced {_count} article(s)",
                    {"slug": slug, "count": _count},
                    importance="medium" if _count else "low",
                )
                # arch:short-ttl-cache (Phase 0.1) — articles count changed
                # for this KB. Invalidate so the next list_kbs() / wiki_stats
                # rebuild picks up the new totals immediately. Cheap.
                if _count:
                    self.invalidate_kb_list_cache()
                await self._record_decision(
                    action_type="compile_batch",
                    action_target=f"kb/{slug}",
                    rationale=f"Compile produced {_count} wiki articles",
                    details={"slug": slug, "count": _count, "full": full},
                )
                # Phase A perf fix (2026-05-06): structural-triple refresh
                # off the event loop — see ingest path comment.
                graph = getattr(self, "_graph", None)
                if graph is not None and hasattr(graph, "refresh_structural_triples"):
                    try:
                        await asyncio.to_thread(graph.refresh_structural_triples)
                    except Exception:
                        log.debug("kb: refresh_structural_triples failed", exc_info=True)
                return result
        except Exception as exc:
            self._log_activity(
                "compile_failed",
                f"KB {slug}: compile raised {type(exc).__name__}",
                {"slug": slug, "error": str(exc)[:500]},
                importance="high",
            )
            await self._record_decision(
                action_type="compile_batch",
                action_target=f"kb/{slug}",
                contract_result="failed",
                rationale=f"Compile aborted: {type(exc).__name__}",
                details={"slug": slug, "error": str(exc)[:500]},
            )
            raise
        finally:
            if self._orchestrator and hasattr(self._orchestrator, "_active_tasks"):
                self._orchestrator._active_tasks.pop("editor", None)

    async def _do_compile_wiki(self, slug: str, full: bool = False) -> dict:
        """Internal compile implementation."""
        from agntspace.llm.base import Message

        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        self._writer._pipeline_mode = True

        index_doc = self._reader.read(f"{base}/wiki/.index.md")
        schema = self._read_schema(slug)
        state = self._read_compile_state(slug)
        now = datetime.now(UTC)
        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

        # Read existing articles (summaries only — tiered L1 loading)
        existing = {}
        for subdir in self._get_wiki_subdirs(slug):
            for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                try:
                    doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                    # L1: title + first 200 chars only
                    title = doc.metadata.get("title", wf.stem)
                    existing[f"{subdir}/{wf.stem}"] = f"{title}: {doc.content[:200]}"
                except Exception:
                    continue

        existing_text = "\n".join(f"- {k}: {v}" for k, v in existing.items()) or "No existing articles."

        # Identify stub pages that need filling (3+ TODOs, mostly placeholder)
        stubs = []
        for subdir in self._get_wiki_subdirs(slug):
            for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                try:
                    doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                    todo_count = doc.content.count("[TODO:")
                    if todo_count >= 3:
                        stubs.append(f"{subdir}/{wf.stem}")
                except Exception:
                    continue

        # Read sources — only new since last compile (unless full)
        # Sort by modification time (newest first) so recent ingests get compile priority
        source_files: list[tuple[float, Path]] = []
        last_compile = state.get("last_compile") if not full else None
        for search_dir in [f"{base}/library", f"{base}/inbox"]:
            try:
                for sf in self._reader.list_files(search_dir, "**/*"):
                    if sf.name == ".gitkeep":
                        continue
                    mtime = os.path.getmtime(sf)
                    # Incremental: skip if older than last compile
                    if last_compile:
                        file_time = datetime.fromtimestamp(mtime, tz=UTC).isoformat()
                        if file_time < last_compile:
                            continue
                    source_files.append((mtime, sf))
            except Exception:
                continue

        # Newest sources first — ensures recently ingested content gets compiled
        source_files.sort(key=lambda x: x[0], reverse=True)

        source_texts = []
        for _, sf in source_files:
            try:
                rel = self._to_logical(sf)
                doc = self._reader.read(rel)
                # Prompt injection defense: source summaries were derived
                # from untrusted inbox content. Neutralize injection
                # patterns before feeding them back to the compile LLM.
                # We use neutralize_injection_patterns (not the full
                # envelope) because the compile prompt already structures
                # sources inside a "NEW SOURCES TO PROCESS" section — a
                # second structural envelope would confuse the LLM.
                from agntspace.security.prompt_guard import neutralize_injection_patterns
                safe_content = neutralize_injection_patterns(doc.content[:2500])
                source_texts.append(f"### {sf.name}\n{safe_content}")
            except Exception:
                continue

        if not source_texts and not stubs:
            return {"slug": slug, "articles": [], "count": 0, "message": "No new sources and no stubs to fill."}

        # ── Collect available images for embedding in compiled articles ──
        # Scan wiki/sources/ for image source summaries (category=image).
        # Each one has a library_path and a vision-generated description.
        # We pass this inventory to the compile LLM so it can embed
        # relevant images in the articles it generates.
        image_inventory = self._collect_image_inventory(base)
        image_ctx = ""
        if image_inventory:
            image_lines = []
            for img in image_inventory[:20]:  # cap at 20 images
                image_lines.append(
                    f"- Path: `{img['library_path']}` | "
                    f"Description: {img['description'][:200]}"
                )
            image_ctx = (
                "\n\nAVAILABLE IMAGES (embed in articles where relevant):\n"
                "When an image is relevant to an article, include it with "
                "![descriptive caption](library_path). Place images near the "
                "top of the article or next to the section they illustrate.\n"
                + "\n".join(image_lines)
            )

        # Build user message with specific instructions
        stubs_instruction = ""
        if stubs:
            stubs_list = ", ".join(stubs[:15])
            stubs_instruction = (
                f"\n\nCRITICAL: These {len(stubs)} existing articles are STUBS with only [TODO] placeholders. "
                f"You MUST rewrite them with FULL content extracted from the sources above. "
                f"Output each as an article block. Stubs to fill: {stubs_list}"
            )

        # Build compile prompt: skill-loaded or hardcoded fallback
        dynamic_ctx = (
            f"\nKB SCHEMA:\n{schema[:1500]}\n\n"
            f"WIKI INDEX:\n{index_doc.content[:2000]}\n\n"
            f"KNOWLEDGE TAXONOMY:\n{self._taxonomy_text}\n\n"
            f"EXISTING ARTICLES:\n{existing_text[:5000]}\n\n"
            f"NEW SOURCES TO PROCESS:\n{chr(10).join(source_texts)[:30000]}\n\n"
            f"{image_ctx}\n\n"
            f"Date: {date_str}"
        )
        skill_prompt = self._get_skill_prompt("kb-compile")
        if skill_prompt:
            compile_system = skill_prompt + "\n\n" + dynamic_ctx
        else:
            compile_system = _COMPILE_PROMPT_FALLBACK.format(
                schema=schema[:1500], index=index_doc.content[:2000],
                taxonomy=self._taxonomy_text,
                existing_articles=existing_text[:3000], sources="\n\n".join(source_texts)[:8000],
                date=date_str,
            )
        compile_system += "\n\n" + self._get_skill_rules("kb-compile")
        # Phase 8 (2026-04-30) — inject open user feedback for every
        # existing article we might touch. The LLM regenerates with
        # the user's WHY in context, addressing the gap instead of
        # producing the same wrong content. No-op when no feedback or
        # the service isn't wired.
        compile_system += await self._feedback_context_for_articles(
            list(existing.keys()),
        )
        # Build explicit skip list from existing articles
        existing_slugs = list(existing.keys())
        skip_note = ""
        if existing_slugs:
            skip_note = f" ALREADY EXISTS (do NOT recreate): {', '.join(existing_slugs[:50])}."

        user_msg = (
            "Compile the wiki from sources now. "
            "Output ONLY ```article: blocks — no preamble, no explanation, no markdown outside the blocks. "
            "Start your response immediately with ```article:subdir/slug. "
            "Create NEW articles for entities, concepts, and techniques NOT already covered."
            f"{skip_note}"
            f"{stubs_instruction}"
        )
        # Compile emits 8K tokens which is slow on local models. Timeout
        # aborts the cycle cleanly and enqueues for retry via work queue.
        try:
            response = await asyncio.wait_for(
                self._llm.complete(
                    messages=[Message(role="user", content=user_msg)],
                    system=compile_system,
                    max_tokens=8192,
                    temperature=0.0,
                    # Compile is structural classification work — for every article
                    # the LLM must pick entity_type + taxonomy_path + subdir + title
                    # + sources, with strong cross-field coupling. The lesson learned
                    # for ingest classification ("fast → capable because small models
                    # produced (X, related_to, None) garbage") applies here verbatim:
                    # a 7B model handed a 5-field discrimination task collapses to
                    # the first plausible default (e.g. all entities → person). In
                    # local mode there's no higher tier to escalate to; in cloud
                    # mode capable goes to the cloud regardless of hybrid routing.
                    model=self._resolve_model("fast" if self._is_local_mode() else "capable"),  # editor: compilation
                ),
                timeout=self._llm_timeout("compile"),
            )
        except TimeoutError:
            log.warning("KB %s: compile LLM timed out", slug)
            self._writer._pipeline_mode = False
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue("compile", {"slug": slug}, deduplicate=True))
            return {"slug": slug, "error": "LLM timed out", "queued": True}
        except Exception as exc:
            log.warning("KB %s: compile LLM failed: %s", slug, exc)
            self._writer._pipeline_mode = False
            if self._called_from_queue:
                raise
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue("compile", {"slug": slug}, deduplicate=True))
            return {"slug": slug, "error": f"LLM unavailable: {exc}", "queued": True}

        articles_written = []
        # Within-batch cross-subdir dedup tracker. Same-subdir is naturally
        # caught by `_find_similar_article` (filesystem-read sees fresh
        # writes from earlier in the same pass) — but if the LLM emits
        # two CREATEs for the same conceptual entity into DIFFERENT
        # subdirs (e.g. "Möte med Tony" → entities/events/meetings/ AND
        # also → knowledge/conversations/ via legacy remap), the per-subdir
        # filesystem scan misses the cross-subdir collision. This list of
        # `(article_path, canonical_title)` pairs is checked BEFORE every
        # write so a same-canonical-title duplicate routed to ANY subdir
        # in this pass dedupes against its sibling.
        batch_articles: list[tuple[str, str]] = []
        log.info("KB %s compile: LLM response %d chars, contains 'article:': %s",
                 slug, len(response.content), "```article:" in response.content)
        if "```article:" not in response.content:
            # LLM returned text but no fenced article blocks. This is a
            # malformed response — same class as empty extraction during
            # ingest. Log visibly, emit activity event, and enqueue a
            # retry so the work queue can escalate the model tier.
            log.warning(
                "KB %s compile: LLM returned %d chars with no article blocks — enqueueing retry",
                slug, len(response.content),
            )
            log.info("KB %s compile: response preview: %s", slug, response.content[:500])
            self._log_activity(
                "compile_no_article_blocks",
                f"KB {slug} compile LLM returned no article blocks ({len(response.content)} chars)",
                {
                    "slug": slug,
                    "response_chars": len(response.content),
                    "preview": response.content[:300],
                },
                importance="medium",
            )
            if self._called_from_queue:
                raise RuntimeError(f"compile produced no article blocks ({len(response.content)} chars)")
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue(
                    "compile",
                    {"slug": slug, "reason": "no_article_blocks"},
                    deduplicate=True,
                ))
            return {
                "slug": slug,
                "articles": [],
                "count": 0,
                "error": "LLM returned no article blocks",
                "queued": True,
            }
        parts = response.content.split("```article:")
        for part in parts[1:]:
            lines = part.split("\n", 1)
            article_path = lines[0].strip()  # e.g., "entities/person-name" or "concepts/topic"
            rest = lines[1] if len(lines) > 1 else ""
            end = rest.find("```")
            content = rest[:end].strip() if end != -1 else rest.strip()

            if article_path and content:
                # ── Compile quality gate ──
                # Extract body (content after frontmatter) for validation
                _body = content
                if "---" in content:
                    _fm = content.split("---", 2)
                    if len(_fm) >= 3:
                        _body = _fm[2]
                _body_stripped = _body.strip()
                _body_len = len(_body_stripped)

                # Gate 1: minimum body length (200 chars of real content)
                if _body_len < 200:
                    log.info("KB %s: compile skipping %s — body too short (%d chars)", slug, article_path, _body_len)
                    continue

                # Gate 2: must have at least one [Source: ...] citation
                if "[Source:" not in content:
                    log.info("KB %s: compile skipping %s — no [Source:] citations", slug, article_path)
                    continue

                # Gate 3: must have at least one ## heading (structure check)
                if "## " not in _body_stripped:
                    log.info("KB %s: compile skipping %s — no section headings", slug, article_path)
                    continue

                # Remap unknown subdirectories to valid ones.
                #
                # v3 layout (taxonomy.yaml FIXED_L1_SLUGS): articles ALWAYS root
                # at one of the 7 fixed L1 buckets — areas/, projects/,
                # knowledge/, entities/, digests/, workflows/, reference/.
                # The wiki/library mirror rule means subdir ALWAYS equals the
                # taxonomy_path prefix.
                #
                # _SUBDIR_REMAP rewrites LEGACY v1 paths emitted by the LLM
                # forward into v3, NOT the other way around. This was the
                # v3-defeating bug: the previous map sent v3 paths to v1
                # (concepts default), guaranteeing every fresh-vault compile
                # would re-create the legacy clutter.
                from agntspace.kb.taxonomy import FIXED_L1_SLUGS, LEGACY_L1_ALIASES
                _VALID_SUBDIRS = set(FIXED_L1_SLUGS)
                # Legacy → v3 rewrite. Sources rename to digests; concepts/
                # synthesis fold into knowledge; decisions move to reference.
                # Multi-segment values are joined onto the trailing path.
                _SUBDIR_REMAP = {
                    "sources": "digests",
                    "concepts": "knowledge",
                    "synthesis": "knowledge",
                    "decisions": "reference/decisions",
                    "org": "entities/organizations",
                    "places": "entities/places",
                    "products": "entities/products",
                    # LLM convenience aliases — bare bucket names that should
                    # land under entities/{leaf}/.
                    "events": "entities/events",
                    "meetings": "entities/events/meetings",
                    "people": "entities/people",
                    "organizations": "entities/organizations",
                    "orgs": "entities/organizations",
                    "references": "reference",
                    "skills": "knowledge",
                    "journal": "digests/conversations",
                }
                # Merge in LEGACY_L1_ALIASES so the canonical alias map (single
                # source of truth in kb/taxonomy.py) wins on any overlap.
                _SUBDIR_REMAP.update(LEGACY_L1_ALIASES)
                if "/" in article_path:
                    subdir_part = article_path.split("/")[0]
                    if subdir_part not in _VALID_SUBDIRS:
                        # Default fallback is "knowledge" (the v3 bucket for
                        # general concepts) — NOT "concepts" (v1 legacy).
                        remapped = _SUBDIR_REMAP.get(subdir_part, "knowledge")
                        slug_part = article_path.split("/", 1)[1]
                        log.info("KB %s: remapping %s/ → %s/ for %s", slug, subdir_part, remapped, slug_part)
                        article_path = f"{remapped}/{slug_part}"

                # Extract title from article content frontmatter for display-name filename
                article_title = None
                if "---" in content:
                    _fm_parts = content.split("---", 2)
                    if len(_fm_parts) >= 3:
                        for _fm_line in _fm_parts[1].strip().split("\n"):
                            if _fm_line.startswith("title:"):
                                article_title = _fm_line.split(":", 1)[1].strip().strip('"').strip("'")
                                break

                # Use display-name filename if title available, otherwise fall back to slug
                from agntspace.vault.writer import title_to_filename
                if article_title:
                    article_subdir = article_path.rsplit("/", 1)[0] if "/" in article_path else "concepts"
                    display_filename = title_to_filename(article_title)
                    full_path = f"{base}/wiki/{article_subdir}/{display_filename}.md"
                    # Inject slug into frontmatter for API routing
                    article_slug = article_path.rsplit("/", 1)[-1] if "/" in article_path else article_path
                    if "---" in content:
                        _fm_parts = content.split("---", 2)
                        if len(_fm_parts) >= 3 and "slug:" not in _fm_parts[1]:
                            _fm_parts[1] = _fm_parts[1].rstrip() + f"\nslug: \"{article_slug}\"\n"
                            content = "---".join(_fm_parts)
                else:
                    full_path = f"{base}/wiki/{article_path}.md"

                is_stub_replace = False
                # If article exists: stub → replace, real content → enrich (append new info)
                if self._reader.exists(full_path):
                    existing_doc = self._reader.read(full_path)
                    todo_count = existing_doc.content.count("[TODO:")
                    real_content = len(existing_doc.content.replace("[TODO:", "").strip())
                    if todo_count >= 3 or real_content < 300:
                        is_stub_replace = True
                        log.info("KB %s: replacing stub %s (%d TODOs)", slug, article_path, todo_count)
                    else:
                        # Non-stub enrichment: append ONLY genuinely new content
                        new_body = content
                        if "---" in content:
                            fm_parts = content.split("---", 2)
                            if len(fm_parts) >= 3:
                                new_body = fm_parts[2].strip()
                        # Skip if new body is too similar to existing content (>60% overlap)
                        existing_text = existing_doc.content.strip()
                        if new_body and len(new_body) > 100:
                            from difflib import SequenceMatcher
                            similarity = SequenceMatcher(None, existing_text[:3000], new_body[:3000]).ratio()
                            if similarity > 0.6:
                                log.info("KB %s: skipping enrichment for %s — %.0f%% similar to existing", slug, article_path, similarity * 100)
                                continue
                            source_fnames = [sf.split("\n")[0].replace("### ", "").strip() for sf in source_texts]
                            # Use HTML comment separator (not ---) to avoid frontmatter ambiguity
                            update_note = f"\n\n<!-- compile update {date_str} -->\n\n> **Updated from compile ({date_str})** — new sources: {', '.join(source_fnames[:5])}\n\n"
                            self._writer.append(full_path, update_note + new_body)
                            articles_written.append(article_path)
                            log.info("KB %s: enriched %s with new source content (%.0f%% novel)", slug, article_path, (1 - similarity) * 100)

                            # Track enriched articles in compile state + graph (Fix #4)
                            compile_record = state.setdefault("compiled_articles", {})
                            compile_record[article_path] = {
                                "compiled_at": date_str,
                                "derived_from": source_fnames[:20],
                                "agent": "editor",
                                "enriched": True,
                            }
                        continue
                # Dedup: skip for stub replacements (they SHOULD match existing slugs)
                new_canonical = self._canonicalize_title(article_title) if article_title else ""
                if not is_stub_replace:
                    dup = self._find_similar_article(slug, article_path, content)
                    if dup:
                        # Gap 1 fix (2026-04-28): redirect new content to ENRICH
                        # the existing dup-target instead of dropping it.
                        # Previously: ``continue`` lost facts the LLM extracted
                        # from a new source whenever dedup caught a near-duplicate
                        # path. Now: read the existing file, decide stub-replace
                        # vs append vs skip-too-similar based on its current
                        # content, write to the DUP's path (not ours).
                        dup_full_path = f"{base}/wiki/{dup}.md"
                        action = self._apply_to_existing_on_dedup(
                            slug=slug,
                            existing_full_path=dup_full_path,
                            new_content=content,
                            source_texts=source_texts,
                            date_str=date_str,
                            state=state,
                            articles_written=articles_written,
                            article_path=dup,  # record under the canonical path
                        )
                        if action == "enriched" or action == "stub_replaced":
                            # Track in batch tracker so subsequent dedup catches
                            # any further proposals for the same canonical title
                            # within this pass.
                            if new_canonical:
                                batch_articles.append((dup, new_canonical))
                            log.info(
                                "KB %s: compile redirected %s → %s (%s)",
                                slug, article_path, dup, action,
                            )
                        elif action == "too_similar":
                            log.info(
                                "KB %s: compile skipping %s — content too similar to existing %s (no enrichment needed)",
                                slug, article_path, dup,
                            )
                        else:  # "missing" / "error" — fall through to fresh write at original path
                            log.info(
                                "KB %s: compile dedup match %s for %s — but enrichment failed (%s); writing fresh",
                                slug, dup, article_path, action,
                            )
                            # Reset is_stub_replace so we DO write at original path
                            # (skip the dup since enrichment didn't take).
                            continue
                        continue
                    # Cross-subdir within-batch dedup: same canonical title
                    # already written THIS PASS into ANY subdir means we're
                    # about to create a duplicate (e.g. legacy remap routed
                    # one CREATE to entities/events/meetings/ and another
                    # to knowledge/conversations/ for the same meeting).
                    # Per-subdir filesystem scan misses this; explicit batch
                    # tracker catches it.
                    if new_canonical:
                        prior_match = next(
                            (
                                prior_path
                                for prior_path, prior_canonical in batch_articles
                                if prior_canonical == new_canonical
                            ),
                            None,
                        )
                        if prior_match:
                            log.info(
                                "KB %s: compile cross-subdir batch dedup — %s (canonical %r) "
                                "matches earlier batch entry %s",
                                slug, article_path, new_canonical, prior_match,
                            )
                            continue
                # Validate taxonomy_path + entity_type ↔ taxonomy_path pairing.
                # See ``_normalize_compiled_article_frontmatter`` for the rules.
                # Captures _validated_etype for the graph-registration block below.
                _validated_etype = ""
                if self._skills_dir:
                    from agntspace.kb.taxonomy import flatten_taxonomy, load_taxonomy
                    _flat = flatten_taxonomy(load_taxonomy(self._skills_dir))
                    content, _validated_etype, _change = self._normalize_compiled_article_frontmatter(
                        content, article_title or "", _flat, self._classify,
                    )
                    if _change:
                        log.info(
                            "KB %s: entity_type/taxonomy_path mismatch — entity_type=%s, path=%s declares %s. Reclassifying path → %s for %s",
                            slug, _change["entity_type"], _change["old_taxonomy_path"],
                            _change["declared_entity_types"], _change["new_taxonomy_path"], article_path,
                        )
                        _activity = getattr(self, "_activity", None)
                        if _activity:
                            try:
                                await _activity.log(
                                    category="knowledge",
                                    action="entity_type_taxonomy_normalized",
                                    summary=f"Reconciled {article_path}: entity_type={_change['entity_type']}, path {_change['old_taxonomy_path']} → {_change['new_taxonomy_path']}",
                                    details={"kb": slug, "article": article_path, **_change},
                                    importance="medium",
                                )
                            except Exception:
                                pass

                # Inject derived_from with source files that contributed
                source_fnames = [sf.split("\n")[0].replace("### ", "").strip() for sf in source_texts]
                if "---" in content:
                    # Insert derived_from into existing frontmatter
                    parts_fm = content.split("---", 2)
                    if len(parts_fm) >= 3:
                        derived = json.dumps(source_fnames[:20])
                        parts_fm[1] = parts_fm[1].rstrip() + f"\nderived_from: {derived}\ncompiled_by: editor\ncompiled_at: \"{date_str}\"\n"
                        content = "---".join(parts_fm)
                # Post-process: replace [Source: filename] with [N] and append numbered references.
                # NEVER gate on `source_fnames` being non-empty — `_numberify_sources` scans the
                # body itself for `[Source: ...]` markers (kb/service.py:_SOURCE_REF_RE) and uses
                # `source_files` only as a tail for uncited sources. Stubs-only compile batches
                # arrive here with `source_fnames=[]` but the LLM still emits `[Source: X]` in the
                # rewritten stub body — those MUST still be numberified. See research path (line
                # 6336) and synthesize path (line 5761) for the same unconditional pattern.
                if self._bibliography:
                    content = self._numberify_sources(content, source_fnames, slug)

                self._writer.write(full_path, content)
                articles_written.append(article_path)
                # Record canonical title for the cross-subdir batch dedup tracker
                # (consumed by the next CREATE iteration's pre-write check above).
                if new_canonical:
                    batch_articles.append((article_path, new_canonical))

                # ── Register compiled article in the knowledge graph ──
                # Closes the gap where compile bypassed the epistemic layer.
                # Each article becomes a document node with derived_from triples.
                _graph = getattr(self, "_graph", None)
                if _graph and hasattr(_graph, "add_triple"):
                    try:
                        _article_slug = article_path.rsplit("/", 1)[-1] if "/" in article_path else article_path
                        _article_title = article_title or _article_slug.replace("-", " ").title()
                        # Determine entity_type — prefer the frontmatter value validated above
                        # (so a Renewcell-as-organization article registers as `organization`,
                        # not `person`). Fall back to subdir-based heuristic when frontmatter
                        # had no entity_type. The entities/ default is "thing" not "person"
                        # because entities/ now contains people/orgs/places/products/events
                        # subdirs and "person" is the wrong silent default for an unknown.
                        _subdir = article_path.split("/")[0] if "/" in article_path else "concepts"
                        if _validated_etype:
                            _etype = _validated_etype
                        else:
                            _etype = {"entities": "thing", "concepts": "concept", "synthesis": "document",
                                      "decisions": "decision"}.get(_subdir, "document")
                        # Register the article as a graph entity
                        _graph.registry.add(_article_title, entity_type=_etype, authority="system")
                        # Link article to its source files
                        for _sf in source_fnames[:20]:
                            _graph.add_triple(
                                subject=_article_title,
                                predicate="created_by",
                                obj="editor",
                                authority="system",
                                confidence=0.9,
                                subject_type=_etype,
                                object_type="ai_agent",
                                epistemic_status="believed",
                                source_file=full_path,
                            )
                            _graph.add_triple(
                                subject=_article_title,
                                predicate="about_entity" if _etype in ("person", "organization") else "about_concept",
                                obj=_sf.replace(".md", "").replace("-", " ").title(),
                                authority="system",
                                confidence=0.7,
                                subject_type="document",
                                object_type="document",
                                epistemic_status="believed",
                                source_file=full_path,
                            )
                        # Phase A perf fix (2026-05-06): graph.save() writes
                        # triples.json — fine alone but called per-article in
                        # this loop. Off-loop via to_thread so a 50-article
                        # compile doesn't pin /api/health for the duration.
                        await asyncio.to_thread(_graph.save)
                    except Exception:
                        log.debug("KB %s: graph registration failed for %s", slug, article_path, exc_info=True)

                # Track in compile state: which sources produced this article
                compile_record = state.setdefault("compiled_articles", {})
                compile_record[article_path] = {
                    "compiled_at": date_str,
                    "derived_from": source_fnames[:20],
                    "agent": "editor",
                }

        # Concept map
        concepts = self._extract_block(response.content, "concepts")
        if concepts:
            self._writer.write(f"{base}/wiki/.concepts.md", (
                f"---\ntitle: \"Concept Map\"\ntype: kb_concepts\nauthor: agent\nagent: editor\n"
                f"date_updated: \"{date_str}\"\n---\n\n{concepts}"
            ))

        # Update index — deduplicate, separate entities from concepts
        if articles_written:
            idx = index_doc.raw
            new_entities = [a for a in articles_written if a.startswith("entities/") and f"[[{a}]]" not in idx]
            new_concepts = [a for a in articles_written if a.startswith("concepts/") and f"[[{a}]]" not in idx]
            if new_entities:
                entity_list = "\n".join(f"- [[{a}]]" for a in new_entities)
                marker = "<!-- Entity pages:"
                if marker in idx:
                    idx = idx.replace(marker, f"{marker}\n{entity_list}\n")
            if new_concepts:
                concept_list = "\n".join(f"- [[{a}]]" for a in new_concepts)
                marker = "<!-- Concept pages:"
                if marker in idx:
                    idx = idx.replace(marker, f"{marker}\n{concept_list}\n")
            idx = self._update_frontmatter(idx, "updated", date_str)
            self._writer.write(f"{base}/wiki/.index.md", idx)

        self._update_index_stats(slug)
        state["last_compile"] = now.isoformat()
        self._write_compile_state(slug, state)
        self._append_log(slug, "compile", f"{len(articles_written)} articles: {', '.join(articles_written)}")

        self._writer._pipeline_mode = False
        return {"slug": slug, "articles": articles_written, "count": len(articles_written)}

    # ── Cross-Link ──

    def cross_link(self, slug: str) -> dict:
        """Scan all wiki pages for unlinked mentions of existing articles. Add [[wikilinks]].

        Scans every article for plain-text mentions of other article titles/slugs
        that aren't already wrapped in [[links]]. Converts them in-place.
        Pipeline mode: no versioning for automated cross-link writes.
        """
        import re as _re
        self._writer._pipeline_mode = True

        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Build lookup: slug → title for all articles
        articles: dict[str, str] = {}  # slug → title
        for subdir in self._get_wiki_subdirs(slug):
            try:
                for wf in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                    if wf.name.startswith(("_", ".")):
                        continue
                    try:
                        doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                        title = doc.metadata.get("title", wf.stem.replace("-", " ").title())
                        articles[wf.stem] = title
                    except Exception:
                        pass
            except Exception:
                continue

        if len(articles) < 2:
            return {"slug": slug, "links_added": 0, "pages_modified": 0}

        # Build regex patterns: match title or slug (case-insensitive) NOT inside [[...]]
        # Sort by title length descending so longer titles match first
        patterns: list[tuple[str, str, str]] = []  # (slug, title, regex pattern)
        for article_slug, title in sorted(articles.items(), key=lambda x: len(x[1]), reverse=True):
            # Skip very short titles (too many false positives)
            if len(title) < 8 or len(article_slug) < 4:  # arch:deterministic — minimum length to avoid false positive crosslinks
                continue
            # Match title or slug-as-words, NOT already inside [[ ]]
            escaped_title = _re.escape(title)
            escaped_slug_words = _re.escape(article_slug.replace("-", " "))
            # Combine: match either title or slug-as-words
            if escaped_title.lower() != escaped_slug_words.lower():
                pattern = f"(?:{escaped_title}|{escaped_slug_words})"
            else:
                pattern = escaped_title
            patterns.append((article_slug, title, pattern))

        links_added = 0
        pages_modified = 0

        # Scan each article
        for subdir in self._get_wiki_subdirs(slug):
            try:
                for wf in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                    if wf.name.startswith(("_", ".")):
                        continue
                    current_slug = wf.stem
                    try:
                        rel_path = f"{base}/wiki/{subdir}/{wf.name}"
                        doc = self._reader.read(rel_path)
                        content = doc.raw
                    except Exception:
                        continue

                    # Split into frontmatter and body
                    body_start = 0
                    if content.startswith("---"):
                        fm_end = content.find("---", 3)
                        if fm_end != -1:
                            body_start = fm_end + 3

                    frontmatter = content[:body_start]
                    body = content[body_start:]
                    modified = False

                    for target_slug, target_title, pattern in patterns:
                        # Don't link to self
                        if target_slug == current_slug:
                            continue

                        # Find mentions NOT already inside [[ ]]
                        def replace_mention(m: _re.Match, _title=target_title, body=body) -> str:
                            # Check if already inside a wikilink
                            start = m.start()
                            prefix = body[:start]
                            if prefix.endswith("[[") or "[[" in prefix[max(0, start - 50):start]:
                                # Check more carefully
                                last_open = prefix.rfind("[[")
                                last_close = prefix.rfind("]]")
                                if last_open > last_close:
                                    return m.group(0)  # inside [[ ]], leave alone
                            # Use display-name wikilinks: [[Title]] resolves to Title.md
                            # If matched text differs from title, use pipe: [[Title|matched text]]
                            matched = m.group(0)
                            if matched.lower() == _title.lower():
                                return f"[[{_title}]]"
                            return f"[[{_title}|{matched}]]"

                        new_body = _re.sub(
                            rf"(?<!\[\[)\b({pattern})\b(?!\]\])",
                            replace_mention,
                            body,
                            flags=_re.IGNORECASE,
                            count=1,  # Only link first mention per article
                        )
                        if new_body != body:
                            body = new_body
                            modified = True
                            links_added += 1

                    if modified:
                        self._writer.write(rel_path, frontmatter + body)
                        pages_modified += 1
            except Exception:
                continue

        if links_added:
            self._append_log(slug, "cross-link", f"{links_added} links added across {pages_modified} pages")
            log.info("KB %s: cross-linked %d mentions across %d pages", slug, links_added, pages_modified)

        self._writer._pipeline_mode = False
        return {"slug": slug, "links_added": links_added, "pages_modified": pages_modified}

    # ── Synthesize ──

    async def synthesize(self, slug: str) -> dict:
        """Public entry point — wraps ``_body_synthesize`` in the scoped
        pipeline so every vault write is authorised or trusted."""
        self._log_activity(
            "synthesize_started",
            f"KB {slug}: synthesis started",
            {"slug": slug},
            importance="low",
        )
        try:
            async with self._scoped_pipeline("kb_synthesize", "synthesize"):
                result = await self._body_synthesize(slug)
                _count = len(result.get("pages", [])) if isinstance(result, dict) else 0
                self._log_activity(
                    "synthesize_completed",
                    f"KB {slug}: synthesis produced {_count} page(s)",
                    {"slug": slug, "count": _count},
                    importance="medium" if _count else "low",
                )
                await self._record_decision(
                    action_type="synthesize_batch",
                    action_target=f"kb/{slug}",
                    rationale=f"Synthesis produced {_count} pages",
                    details={"slug": slug, "count": _count},
                )
                return result
        except Exception as exc:
            self._log_activity(
                "synthesize_failed",
                f"KB {slug}: synthesis raised {type(exc).__name__}",
                {"slug": slug, "error": str(exc)[:500]},
                importance="high",
            )
            await self._record_decision(
                action_type="synthesize_batch",
                action_target=f"kb/{slug}",
                contract_result="failed",
                rationale=f"Synthesis aborted: {type(exc).__name__}",
                details={"slug": slug, "error": str(exc)[:500]},
            )
            raise

    async def _body_synthesize(self, slug: str) -> dict:
        """Generate cross-source synthesis pages — insights that no single source contains alone."""
        from agntspace.llm.base import Message

        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Read all source summaries — recursive so post-scope-2-migration
        # articles at deeper paths (wiki/sources/articles/news/X.md) are
        # still picked up. ``self._reader.read`` needs the full relative
        # path under the kb root, so we use ``_to_logical(sf)`` to get it
        # rather than rejoining from the flat name.
        #
        # 2026-05-09 (synthesis bloat fix): two filters at the input boundary
        #   1. drop ``img-<hex>.md`` digest pages — these are OneNote-imported
        #      image binaries that leaked into wiki/sources/ and have no
        #      semantic content for synthesis; carrying them inflates the
        #      References list with hundreds of irrelevant entries.
        #   2. cap input at ``_SYNTHESIZE_MAX_SOURCES`` — vaults with 700+
        #      source pages blow every model's context window AND produce
        #      a 700-entry References list when ``_numberify_sources``
        #      tacks the input list onto the output. Cap at 30, prefer
        #      most-recently-modified (mtime desc) so synthesize picks up
        #      the user's current focus instead of arbitrary alphabetical
        #      first 30. When capped, emit ``synthesize_input_capped`` at
        #      medium importance so the user can SEE the truncation.
        source_pages: list = []
        skipped_image_digests = 0
        try:
            for sf in self._reader.list_files(f"{base}/wiki/sources", "**/*.md"):
                if self._IMG_DIGEST_STEM_RE.match(sf.stem):
                    skipped_image_digests += 1
                    continue
                source_pages.append(sf)
        except Exception:
            pass

        total_eligible = len(source_pages)
        capped = False
        if total_eligible > self._SYNTHESIZE_MAX_SOURCES:
            try:
                source_pages.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            except Exception:
                source_pages.sort(key=lambda p: p.name)
            source_pages = source_pages[: self._SYNTHESIZE_MAX_SOURCES]
            capped = True

        source_texts: list[str] = []
        for sf in source_pages:
            try:
                rel = self._to_logical(sf)
            except Exception:
                rel = f"{base}/wiki/sources/{sf.name}"
            try:
                doc = self._reader.read(rel)
                source_texts.append(f"### {sf.stem}\n{doc.content[:2000]}")
            except Exception:
                continue

        if capped or skipped_image_digests:
            self._log_activity(
                "synthesize_input_filtered",
                (
                    f"KB {slug}: synthesize input filtered — "
                    f"{len(source_texts)} of {total_eligible + skipped_image_digests} sources used "
                    f"({skipped_image_digests} image digests skipped, capped={capped})"
                ),
                {
                    "slug": slug,
                    "used": len(source_texts),
                    "total": total_eligible + skipped_image_digests,
                    "skipped_image_digests": skipped_image_digests,
                    "capped": capped,
                    "cap": self._SYNTHESIZE_MAX_SOURCES,
                },
                importance="medium" if capped else "low",
            )

        if len(source_texts) < 2:
            return {"slug": slug, "articles": [], "count": 0, "message": "Need 2+ sources for synthesis."}

        # Read existing synthesis pages to avoid re-creating
        existing_synthesis = []
        try:
            for sf in self._reader.list_files(f"{base}/wiki/synthesis", "**/*.md"):
                existing_synthesis.append(sf.stem)
        except Exception:
            pass

        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

        # Phase 8 (2026-04-30) — pull open user feedback for ALL existing
        # synthesis pages so the LLM addresses any flagged issues in the
        # next regeneration. Empty when no feedback wired or no open rows.
        feedback_ctx = await self._feedback_context_for_articles(existing_synthesis)

        try:
            response = await asyncio.wait_for(self._llm.complete(
                messages=[Message(role="user", content=(
                    f"Analyze these {len(source_texts)} source summaries and identify cross-source insights — "
                    f"connections, contradictions, patterns, or implications that no single source reveals alone.\n\n"
                    f"Existing synthesis pages (do NOT duplicate): {', '.join(existing_synthesis) or 'none'}\n\n"
                    f"For each genuine insight, create an article block. Only create synthesis pages for "
                    f"NON-OBVIOUS connections. If no real cross-source insights exist, output nothing."
                ))],
                system=(
                    "You are a knowledge synthesis specialist. Read source summaries and find connections across them.\n\n"
                    "SOURCES:\n" + "\n\n".join(source_texts) + "\n\n"
                    + feedback_ctx +
                    "Output format for each synthesis:\n"
                    "```article:synthesis/{slug}\n"
                    "---\n"
                    f'title: "Synthesis: descriptive title"\n'
                    "entity_type: synthesis\n"
                    "provenance: compiled\n"
                    "category: cross-source\n"
                    'status: draft\n'
                    f'sources: ["source1", "source2"]\n'
                    "author: agent\n"
                    "agent: editor\n"
                    f'date_created: "{date_str}"\n'
                    f'date_updated: "{date_str}"\n'
                    "---\n\n"
                    "(Full analysis with [[wikilinks]] and [Source: file] citations)\n\n"
                    "## Connections\n(how the sources relate)\n\n"
                    "## Implications\n(what this means)\n\n"
                    "## Open Questions\n(what this raises but doesn't answer)\n"
                    "```\n\n"
                    "If no genuine cross-source insights exist, respond with: no_synthesis"
                ),
                max_tokens=4096,
                temperature=0.1,
                model=self._resolve_model("fast" if self._is_local_mode() else "capable"),  # editor: synthesis
            ), timeout=self._llm_timeout("synthesize"))
        except TimeoutError:
            log.warning("KB %s: synthesize LLM timed out", slug)
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue("synthesize", {"slug": slug}, deduplicate=True))
            return {"slug": slug, "error": "LLM timed out", "queued": True}
        except Exception as exc:
            log.warning("KB %s: synthesize LLM failed: %s", slug, exc)
            if self._called_from_queue:
                raise
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue("synthesize", {"slug": slug}, deduplicate=True))
            return {"slug": slug, "error": f"LLM unavailable: {exc}", "queued": True}

        if "no_synthesis" in response.content.lower():
            return {"slug": slug, "articles": [], "count": 0, "message": "No cross-source insights found."}

        articles_written = []
        parts = response.content.split("```article:")
        for part in parts[1:]:
            lines = part.split("\n", 1)
            article_path = lines[0].strip()
            rest = lines[1] if len(lines) > 1 else ""
            end = rest.find("```")
            content = rest[:end].strip() if end != -1 else rest.strip()

            if article_path and content and article_path.startswith("synthesis/"):
                full_path = f"{base}/wiki/{article_path}.md"
                if not self._reader.exists(full_path):
                    # 2026-05-09 (synthesis bloat fix): use the LLM's declared
                    # ``sources:`` frontmatter instead of every input source.
                    # Pre-fix, ``synth_source_fnames`` carried EVERY source
                    # in the KB (700+ for the user's main vault) and
                    # ``_numberify_sources`` appended all of them to the
                    # References section even though the LLM only used ~9-30.
                    # The LLM has already done the relevance judgment via the
                    # prompt's ``sources: ["source1", "source2"]`` example —
                    # honor it. Empty fallback means the post-processor only
                    # references inline-cited [Source:] markers.
                    llm_sources = self._parse_sources_field_from_frontmatter(content)
                    content = self._numberify_sources(content, llm_sources, slug)
                    self._writer.write(full_path, content)
                    articles_written.append(article_path)

        if articles_written:
            self._append_log(slug, "synthesize", f"{len(articles_written)} synthesis pages: {', '.join(articles_written)}")

        return {"slug": slug, "articles": articles_written, "count": len(articles_written)}

    # ── Archive ──

    def snapshot(self, slug: str, reason: str = "manual") -> dict:
        """Create a timestamped snapshot of the wiki before destructive operations."""
        import shutil

        base = self._resolve(f"knowledge/{slug}")
        if not (base / "wiki" / ".index.md").exists():
            return {"error": f"KB not found: {slug}"}

        now = datetime.now(UTC)
        archive_name = now.strftime("%Y%m%dT%H%M%S")
        archive_dir = base / ".archives" / archive_name
        archive_dir.mkdir(parents=True, exist_ok=True)

        # Copy wiki/ and metadata
        wiki_dir = base / "wiki"
        if wiki_dir.is_dir():
            shutil.copytree(str(wiki_dir), str(archive_dir / "wiki"))

        # Copy state files
        for fname in (".compile-state.json", "SCHEMA.md", "log.md"):
            src = base / fname
            if src.exists():
                shutil.copy2(str(src), str(archive_dir / fname))

        # Write archive metadata
        import json as _json
        article_count = sum(1 for _ in wiki_dir.rglob("*.md")) if wiki_dir.is_dir() else 0
        meta = {
            "archived_at": now.isoformat(),
            "reason": reason,
            "article_count": article_count,
            "slug": slug,
        }
        (archive_dir / "archive-meta.json").write_text(_json.dumps(meta, indent=2), encoding="utf-8")

        self._append_log(slug, "snapshot", f"Archive created: {archive_name} (reason: {reason}, {article_count} articles)")
        log.info("KB %s: snapshot created at %s (%d articles)", slug, archive_name, article_count)
        return {"slug": slug, "archive": archive_name, "articles": article_count, "reason": reason}

    def list_snapshots(self, slug: str) -> list[dict]:
        """List available snapshots for a KB."""
        import json as _json

        archive_dir = self._resolve(f"knowledge/{slug}/.archives")
        if not archive_dir.is_dir():
            return []

        snapshots = []
        for d in sorted(archive_dir.iterdir(), reverse=True):
            if not d.is_dir():
                continue
            meta_file = d / "archive-meta.json"
            if meta_file.exists():
                try:
                    meta = _json.loads(meta_file.read_text(encoding="utf-8"))
                    meta["archive_id"] = d.name
                    snapshots.append(meta)
                except Exception:
                    snapshots.append({"archived_at": d.name, "archive_id": d.name, "reason": "unknown"})
        return snapshots

    def restore_snapshot(self, slug: str, archive_id: str) -> dict:
        """Restore a wiki from a previous snapshot.

        Safety: snapshots current state before restoring.
        """
        import shutil

        base = self._resolve(f"knowledge/{slug}")
        archive_dir = base / ".archives" / archive_id
        if not archive_dir.is_dir():
            return {"error": f"Snapshot not found: {archive_id}"}

        archived_wiki = archive_dir / "wiki"
        if not archived_wiki.is_dir():
            return {"error": f"Snapshot has no wiki directory: {archive_id}"}

        # Safety: snapshot current state before restoring
        pre_restore = self.snapshot(slug, reason="pre-restore")

        # Clear current wiki
        live_wiki = base / "wiki"
        if live_wiki.is_dir():
            shutil.rmtree(str(live_wiki))

        # Copy archived wiki back
        shutil.copytree(str(archived_wiki), str(live_wiki))

        # Restore state files if they exist in the archive
        for fname in (".compile-state.json", "SCHEMA.md", "log.md"):
            archived_file = archive_dir / fname
            if archived_file.exists():
                shutil.copy2(str(archived_file), str(base / fname))

        self._append_log(slug, "restore", f"Restored from snapshot {archive_id} (pre-restore saved as {pre_restore.get('archive', '?')})")
        log.info("KB %s: restored from snapshot %s", slug, archive_id)

        # Count restored articles
        article_count = sum(1 for _ in live_wiki.rglob("*.md"))

        return {
            "slug": slug,
            "restored_from": archive_id,
            "pre_restore_snapshot": pre_restore.get("archive", ""),
            "articles_restored": article_count,
        }

    # ── Project Scoping ──

    def create_project_wiki(
        self, kb_slug: str, project_slug: str, project_title: str,
        project_data: dict | None = None,
    ) -> str:
        """Create a project namespace within a KB wiki.

        If project_data is provided (from ProjectService), populates the overview
        with real description, goals, agents, milestones, and status.
        """
        base = f"knowledge/{kb_slug}/wiki/projects/{project_slug}"
        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

        # Pull real data from the projects module
        pd = project_data or {}
        description = pd.get("description", "")
        status = pd.get("status", "active")
        target_date = pd.get("target_date", "")
        goals = pd.get("related_goals", [])
        agents = pd.get("assigned_agents", [])
        milestones = pd.get("milestones", "")

        desc_text = description if description else "[TODO: project description]"
        target_text = f"\n**Target date:** {target_date}" if target_date else ""

        goals_text = "\n".join(f"- [[{g}]]" for g in goals) if goals else "[TODO: link to goals]"
        agents_text = "\n".join(f"- {a}" for a in agents) if agents else "[TODO: assigned agents]"

        milestones_text = ""
        if milestones:
            milestones_text = f"\n## Milestones\n{milestones}\n"

        overview = (
            f"---\ntitle: \"{project_title}\"\n"
            f"entity_type: project\ncategory: project\n"
            f"status: {status}\nauthor: agent\nagent: wiki-supervisor\n"
            f"related_goals: {json.dumps(goals)}\nassigned_agents: {json.dumps(agents)}\n"
            f"date_created: \"{date_str}\"\ndate_updated: \"{date_str}\"\n---\n\n"
            f"# {project_title}\n{target_text}\n\n"
            f"## Overview\n{desc_text}\n\n"
            f"## Goals\n{goals_text}\n\n"
            f"## Assigned Agents\n{agents_text}\n"
            f"{milestones_text}\n"
            f"## Key Concepts\n[TODO: link to project-specific concept pages]\n\n"
            f"## Key People\n[TODO: link to entity pages]\n\n"
            f"## Open Questions\n- [TODO: what don't we know yet?]\n\n"
            f"## Sources\n[TODO: source links]\n"
        )
        self._writer.write(f"{base}/{project_slug}.md", overview)
        self._writer.write(f"{base}/concepts/.gitkeep", "")
        self._writer.write(f"{base}/entities/.gitkeep", "")
        self._writer.write(f"{base}/notes/.gitkeep", "")

        self._append_log(kb_slug, "project", f"Project wiki created: {project_title} ({project_slug})")
        return f"{base}/{project_slug}.md"

    # ── Reflect ──

    def create_decision_record(
        self, slug: str, *,
        title: str, decision: str, context: str,
        alternatives: str = "None documented.",
        reasoning: str = "", consequences: str = "",
        affects: list[str] | None = None,
    ) -> str:
        """Create a decision record as a first-class wiki page."""
        date_str = datetime.now(UTC).strftime("%Y-%m-%d")
        from agntspace.vault.writer import title_to_filename
        record_display = title_to_filename(title)
        path = f"knowledge/{slug}/wiki/decisions/{record_display}.md"

        page = self._render_template("decision_record",
            title=title, date=date_str,
            decision=decision, context=context,
            alternatives=alternatives, reasoning=reasoning,
            consequences=consequences,
            affects=json.dumps(affects or []),
        )
        self._writer.write(path, page)
        self._append_log(slug, "decision", f"Decision recorded: {title}")
        return path

    async def reflect(
        self, slug: str, *,
        articles_created: list[str] | None = None,
        files_ingested: list[str] | None = None,
    ) -> dict:
        """Public entry — scoped pipeline wrapper around ``_body_reflect``."""
        self._log_activity(
            "reflect_started",
            f"KB {slug}: reflection started",
            {"slug": slug},
            importance="low",
        )
        try:
            async with self._scoped_pipeline("kb_reflect", "reflect"):
                result = await self._body_reflect(
                    slug,
                    articles_created=articles_created,
                    files_ingested=files_ingested,
                )
                _created = len(result.get("created", [])) if isinstance(result, dict) else 0
                self._log_activity(
                    "reflect_completed",
                    f"KB {slug}: reflection produced {_created} decision record(s)",
                    {"slug": slug, "count": _created},
                    importance="medium" if _created else "low",
                )
                await self._record_decision(
                    action_type="reflect_batch",
                    action_target=f"kb/{slug}",
                    rationale=f"Reflection produced {_created} decision records",
                    details={"slug": slug, "count": _created},
                )
                return result
        except Exception as exc:
            self._log_activity(
                "reflect_failed",
                f"KB {slug}: reflection raised {type(exc).__name__}",
                {"slug": slug, "error": str(exc)[:500]},
                importance="high",
            )
            await self._record_decision(
                action_type="reflect_batch",
                action_target=f"kb/{slug}",
                contract_result="failed",
                rationale=f"Reflection aborted: {type(exc).__name__}",
                details={"slug": slug, "error": str(exc)[:500]},
            )
            raise

    async def _body_reflect(
        self, slug: str, *,
        articles_created: list[str] | None = None,
        files_ingested: list[str] | None = None,
    ) -> dict:
        """Structural reflection after compile — creates decision records for significant changes.

        Part of the full pipeline: ingest → compile → **reflect** → lint
        """
        from agntspace.llm.base import Message

        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        articles_created = articles_created or []
        files_ingested = files_ingested or []

        # Nothing to reflect on
        if not articles_created and not files_ingested:
            return {"slug": slug, "decisions_created": 0, "message": "No changes to reflect on."}

        schema = self._read_schema(slug)

        # Read FULL content of recently created/modified articles
        recent_articles_text = []
        for art_path in articles_created[:10]:
            full = f"{base}/wiki/{art_path}.md"
            if self._reader.exists(full):
                try:
                    doc = self._reader.read(full)
                    recent_articles_text.append(f"### {art_path}\n{doc.content[:1000]}")
                except Exception:
                    pass

        # Also read source summaries for ingested files
        for fname in files_ingested[:5]:
            src_slug = fname.lower().replace(" ", "-").replace(".md", "")
            src_path = f"{base}/wiki/sources/{src_slug}.md"
            if self._reader.exists(src_path):
                try:
                    doc = self._reader.read(src_path)
                    recent_articles_text.append(f"### sources/{src_slug}\n{doc.content[:800]}")
                except Exception:
                    pass

        # Read existing article titles for context.
        # Phase B perf fix (2026-05-06): per-article frontmatter read across
        # every wiki subdir was the dominant sync block in reflect's body —
        # 1700+ reads on Wolf's vault. Off-loop via to_thread.
        def _gather_existing_titles() -> list[str]:
            out: list[str] = []
            for subdir in self._get_wiki_subdirs(slug):
                try:
                    for wf in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                        if wf.name.startswith(("_", ".")):
                            continue
                        try:
                            doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                            title = doc.metadata.get("title", wf.stem)
                            etype = doc.metadata.get("entity_type", "")
                            out.append(f"- {subdir}/{wf.stem} [{etype}]: {title}")
                        except Exception:
                            pass
                except Exception:
                    continue
            return out

        existing = await asyncio.to_thread(_gather_existing_titles)

        # Build reflect prompt: skill-loaded or hardcoded fallback
        dynamic_ctx = (
            f"\nWHAT JUST CHANGED:\n"
            f"- Articles created: {', '.join(articles_created) or 'none'}\n"
            f"- Files ingested: {', '.join(files_ingested[:10]) or 'none'}\n\n"
            f"RECENTLY CREATED/MODIFIED ARTICLES:\n"
            f"{chr(10).join(recent_articles_text) or 'No recent articles to analyze.'}\n\n"
            f"FULL WIKI STATE:\n{chr(10).join(existing[:80]) or 'No existing articles.'}\n\n"
            f"KB SCHEMA:\n{schema[:1000]}"
        )
        skill_prompt = self._get_skill_prompt("kb-reflect")
        if skill_prompt:
            reflect_system = skill_prompt + "\n\n" + dynamic_ctx
        else:
            reflect_system = _REFLECT_PROMPT_FALLBACK.format(
                articles_created=", ".join(articles_created) or "none",
                files_ingested=", ".join(files_ingested[:10]) or "none",
                recent_articles="\n\n".join(recent_articles_text) or "No recent articles to analyze.",
                existing_articles="\n".join(existing[:80]) or "No existing articles.",
                schema=schema[:1000],
            )
        try:
            response = await asyncio.wait_for(self._llm.complete(
                messages=[Message(role="user", content="Analyze the structural impact of recent wiki changes.")],
                system=reflect_system,
                max_tokens=2000, temperature=0.3,
                model=self._resolve_model("fast" if self._is_local_mode() else "capable"),  # editor: reflection
            ), timeout=self._llm_timeout("reflect"))
        except TimeoutError:
            log.warning("KB %s: reflect LLM timed out", slug)
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue("reflect", {"slug": slug}, deduplicate=True))
            return {"slug": slug, "error": "LLM timed out", "queued": True}
        except Exception as exc:
            log.warning("KB %s: reflect LLM failed: %s", slug, exc)
            if self._called_from_queue:
                raise
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue(
                    "reflect", {"slug": slug, "articles_created": articles_created, "files_ingested": files_ingested},
                    deduplicate=True,
                ))
            return {"slug": slug, "error": f"LLM unavailable: {exc}", "queued": True}

        # Check if LLM found significant decisions
        if "```no_decisions" in response.content:
            self._append_log(slug, "reflect", "No significant structural decisions")
            return {"slug": slug, "decisions_created": 0, "message": "Routine update — no structural decisions."}

        # Parse decision blocks
        decisions_created = 0
        for block in response.content.split("```decision"):
            if not block.strip() or block.strip().startswith("```"):
                continue
            end = block.find("```")
            content = block[:end].strip() if end != -1 else block.strip()

            # Parse fields
            fields: dict[str, str] = {}
            for line in content.split("\n"):
                if ":" in line:
                    key, _, val = line.partition(":")
                    fields[key.strip().lower()] = val.strip()

            title = fields.get("title", "Unnamed decision")
            if not title or title == "Unnamed decision":
                continue

            # Quote-aware comma split — same shape as the citations parser.
            # Naive split would break on entries like ``"Project X, Y"`` where
            # the literal comma is part of one project name. Defensive: same
            # bug class as the synthesis citations bloat fix (2026-05-09).
            _affects_raw = fields.get("affects", "")
            affects = self._split_yaml_inline_list_tokens(_affects_raw)

            self.create_decision_record(
                slug,
                title=title,
                decision=fields.get("decision", ""),
                context=fields.get("context", ""),
                alternatives=fields.get("alternatives", "None documented."),
                reasoning=fields.get("reasoning", ""),
                consequences=fields.get("consequences", ""),
                affects=affects,
            )
            decisions_created += 1

        self._append_log(slug, "reflect", f"{decisions_created} decision records created")
        return {"slug": slug, "decisions_created": decisions_created}

    # ── Research ──

    async def research(
        self, slug: str, query: str, save_output: bool = False,
        file_to_wiki: bool = False, output_format: str = "markdown",
    ) -> dict:
        """Public entry — scoped pipeline wrapper around ``_body_research``.

        *output_format* controls the shape of the LLM response:
        - ``"markdown"`` (default) — wiki article with citations
        - ``"comparison"`` — markdown comparison table
        - ``"slides"`` — Marp slide deck
        - ``"briefing"`` — executive briefing (short, structured)
        """
        self._log_activity(
            "research_started",
            f"KB {slug}: research started — {query[:120]}",
            {"slug": slug, "query": query[:500], "output_format": output_format},
            importance="low",
        )
        try:
            async with self._scoped_pipeline("kb_research", "research"):
                result = await self._body_research(
                    slug, query, save_output=save_output,
                    file_to_wiki=file_to_wiki, output_format=output_format,
                )
                self._log_activity(
                    "research_completed",
                    f"KB {slug}: research completed",
                    {"slug": slug, "saved": save_output, "filed_to_wiki": file_to_wiki},
                    importance="medium",
                )
                await self._record_decision(
                    action_type="research",
                    action_target=f"kb/{slug}",
                    rationale=f"Research query: {query[:200]}",
                    details={"slug": slug, "query": query[:500], "saved": save_output},
                )
                return result
        except Exception as exc:
            self._log_activity(
                "research_failed",
                f"KB {slug}: research raised {type(exc).__name__}",
                {"slug": slug, "error": str(exc)[:500]},
                importance="high",
            )
            await self._record_decision(
                action_type="research",
                action_target=f"kb/{slug}",
                contract_result="failed",
                rationale=f"Research aborted: {type(exc).__name__}",
                details={"slug": slug, "error": str(exc)[:500]},
            )
            raise

    async def _body_research(
        self, slug: str, query: str, save_output: bool = False,
        file_to_wiki: bool = False, output_format: str = "markdown",
    ) -> dict:
        """Research with tiered context loading: index → search → targeted reads."""
        from agntspace.llm.base import Message

        base = f"knowledge/{slug}"
        schema = self._read_schema(slug)
        self._read_index(slug)  # warm cache

        # L1: Read index to find relevant pages
        query_words = set(query.lower().split())

        # L2: Score articles by relevance using index
        all_articles = {}
        for subdir in _WIKI_SUBDIRS:
            try:
                for wf in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                    path = f"{base}/wiki/{subdir}/{wf.name}"
                    doc = self._reader.read(path)
                    title = doc.metadata.get("title", wf.stem)
                    # Score by query word overlap in title + first 200 chars
                    preview = f"{title} {doc.content[:200]}".lower()
                    score = sum(1 for w in query_words if w in preview)
                    all_articles[path] = {"title": title, "score": score, "content": doc.content}
            except Exception:
                continue

        if not all_articles:
            return {"answer": "No wiki articles. Run ingest + compile first.", "sources": []}

        # L3: Load full content of top-scoring articles only
        sorted_articles = sorted(all_articles.items(), key=lambda x: x[1]["score"], reverse=True)
        context_parts = []
        included_slugs: list[str] = []
        token_budget = 15000
        used = 0
        for path, info in sorted_articles[:15]:
            article_text = f"## {info['title']}\n\n{info['content']}"
            if used + len(article_text) > token_budget:
                break
            context_parts.append(article_text)
            # Phase 8: track which slugs we included so we can pull
            # their open feedback below. Slug ≈ filename stem.
            try:
                from pathlib import Path as _P
                included_slugs.append(_P(path).stem.lower())
            except Exception:
                pass
            used += len(article_text)

        output_instruction = _RESEARCH_OUTPUT_FORMATS.get(output_format, "")
        if file_to_wiki and not output_instruction:
            output_instruction = "Format as a wiki article with frontmatter. Use [[wiki-links]] and [Source: file] citations."

        # Build research prompt: skill-loaded or hardcoded fallback
        articles_ctx = "\n\n---\n\n".join(context_parts)
        dynamic_ctx = (
            f"\nKB SCHEMA:\n{schema[:1000]}\n\n"
            f"WIKI ARTICLES:\n{articles_ctx}\n\n"
            f"QUESTION:\n{query}\n\n{output_instruction}"
        )
        skill_prompt = self._get_skill_prompt("kb-research")
        if skill_prompt:
            research_system = skill_prompt + "\n\n" + dynamic_ctx
        else:
            research_system = _RESEARCH_PROMPT_FALLBACK.format(
                schema=schema[:1000], context="\n\n---\n\n".join(context_parts),
                query=query, output_instruction=output_instruction,
            )
        # Phase 8 (2026-04-30) — inject open user feedback for the source
        # articles. Tells the LLM "be skeptical of these sources, the user
        # flagged them as wrong" so the research answer doesn't inherit the
        # wrongness. Empty when no feedback wired or no open rows.
        research_system += await self._feedback_context_for_articles(included_slugs)
        try:
            response = await asyncio.wait_for(self._llm.complete(
                messages=[Message(role="user", content=query)],
                system=research_system,
                max_tokens=2048, temperature=0.3,
                model=self._resolve_model("fast" if self._is_local_mode() else "reasoning"),  # researcher: research
            ), timeout=self._llm_timeout("research"))
        except TimeoutError:
            log.warning("KB %s: research LLM timed out", slug)
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue("research", {"slug": slug, "query": query}, deduplicate=True))
            return {"slug": slug, "error": "LLM timed out", "queued": True}
        except Exception as exc:
            log.warning("KB %s: research LLM failed: %s", slug, exc)
            if self._called_from_queue:
                raise
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue(
                    "research", {"slug": slug, "query": query, "save_output": save_output},
                    deduplicate=True,
                ))
            return {"slug": slug, "error": f"LLM unavailable: {exc}", "queued": True, "answer": ""}

        # Auto-file to wiki if answer has good citation coverage (>= 3 source references)
        source_refs = response.content.count("[Source:") + response.content.count("[[sources/")
        if not file_to_wiki and source_refs >= 3:
            file_to_wiki = True
            log.info("KB %s: auto-filing research answer to wiki (%d source citations)", slug, source_refs)

        output_path = None
        if save_output or file_to_wiki:
            ts = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
            date_today = datetime.now(UTC).strftime("%Y-%m-%d")
            q_slug = query[:40].lower().replace(" ", "-").replace("/", "-")
            if file_to_wiki:
                output_path = f"{base}/wiki/concepts/research-{q_slug}.md"
                # Idempotent: update existing research article instead of duplicating
                if self._reader.exists(output_path):
                    existing = self._reader.read(output_path)
                    content = self._update_frontmatter(existing.raw, "date_updated", date_today)
                    # Replace body after frontmatter
                    fm_end = content.find("---", content.find("---") + 3)
                    if fm_end != -1:
                        content = content[:fm_end + 3] + f"\n\n{response.content}"
                    log.info("KB %s: updated existing research article %s", slug, output_path)
                else:
                    content = response.content if response.content.startswith("---") else (
                        f"---\ntitle: \"{query[:80]}\"\nentity_type: concept\nprovenance: researched\ncategory: research\n"
                        f"status: draft\nauthor: agent\nagent: researcher\ndate_created: \"{date_today}\"\n"
                        f"date_updated: \"{date_today}\"\n---\n\n{response.content}"
                    )
            else:
                output_path = f"{base}/output/research_{q_slug}_{ts}.md"
                content = (
                    f"---\ntitle: \"{query[:80]}\"\ntype: kb_research\nauthor: agent\nagent: researcher\n"
                    f"date: \"{date_today}\"\n---\n\n# Research: {query}\n\n{response.content}"
                )
            # Numberify inline [Source: ...] markers (collected from LLM output itself)
            # so research output gets [N] + ## References like every other wiki write path.
            content = self._numberify_sources(content, [], slug)
            self._writer.write(output_path, content)

        self._append_log(slug, "research", f"Q: {query[:80]}")
        return {"answer": response.content, "output_path": output_path, "filed_to_wiki": file_to_wiki}

    # ── Lint ──

    async def _structural_analysis(self, slug: str) -> tuple[list[dict], dict[str, str]]:
        """Pre-compute structural wiki issues from file data (no LLM needed).

        Returns (issues_list, articles_dict) where articles_dict maps path → content.

        Tier-3 perf fix (2026-05-07): converted from sync (called via
        ``asyncio.to_thread``) to chunked async with periodic yields.
        Prior shape held the GIL for minutes on a 1700-article vault —
        even though the work was running in a thread, GIL contention
        starved the event loop, producing 5-minute blocks recorded by
        the perf tracker. New shape:
        - File reads happen in batches of ``_LINT_FS_BATCH`` (50)
          inside ``asyncio.to_thread``; the loop yields between batches.
        - Pure-Python analysis loops yield via ``asyncio.sleep(0)``
          every ``_LINT_ANALYSIS_CHUNK`` (200) items.
        - Cooperative cancel: each batch checks if the outer
          ``wait_for`` cancelled us and bails cleanly so the heartbeat
          editor-quality-pass can interrupt without orphaning threads
          that keep running for minutes after timeout.
        Reference: tasks/lessons.md 2026-04-27 dual-fix pattern (yield
        frequency + per-call short-circuits).
        """
        import re as _re
        from difflib import SequenceMatcher

        base = f"knowledge/{slug}"
        issues: list[dict] = []

        # Tier-3 perf fix: chunked file reads with per-batch yields.
        # ``_LINT_FS_BATCH`` keeps each batch < 250ms wall on a typical
        # vault (50 files × ~5ms/read). The loop gets a turn between
        # batches; the perf tracker no longer sees multi-second blocks.
        _LINT_FS_BATCH = 50

        def _read_one_article(wf_path: str, rel: str, full_path: str) -> tuple[str, dict]:
            """Pure-sync: read one file's content + frontmatter. Returns
            (rel_path, info_dict). Raises only if the file vanished mid-read."""
            doc = self._reader.read(full_path)
            outbound = set(_re.findall(r'\[\[([^\]]+)\]\]', doc.content))
            todos = len(_re.findall(r'\[TODO:', doc.content))
            return (rel, {
                "content": doc.content,
                "title": doc.metadata.get("title", wf_path),  # wf.stem at the call site
                "metadata": doc.metadata,
                "outbound_links": outbound,
                "inbound_count": 0,
                "todo_count": todos,
                "status": doc.metadata.get("status", ""),
                "entity_type": doc.metadata.get("entity_type", ""),
                "sources": doc.metadata.get("sources", []),
                "date_created": doc.metadata.get("date_created", ""),
            })

        def _read_batch(items: list[tuple[str, str, str]]) -> list[tuple[str, dict]]:
            """Read one batch of (rel, full_path, stem) triples. Pure-sync —
            runs inside ``asyncio.to_thread`` so disk I/O overlaps with
            other coroutines. Per-file failures are skipped quietly."""
            out: list[tuple[str, dict]] = []
            for stem, rel, full in items:
                try:
                    out.append(_read_one_article(stem, rel, full))
                except Exception:
                    continue
            return out

        # Walk subdirs and collect (stem, rel, full_path) triples first.
        # The list-files calls are cheap (one glob per subdir); the heavy
        # work is the per-file read which runs in chunked batches below.
        all_triples: list[tuple[str, str, str]] = []
        for subdir in _WIKI_SUBDIRS:
            try:
                for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                    rel = f"{subdir}/{wf.stem}"
                    full = f"{base}/wiki/{subdir}/{wf.name}"
                    all_triples.append((wf.stem, rel, full))
            except Exception:
                continue

        # Batched reads with periodic yields. The yield IS the perf fix —
        # without it, a 1700-article vault holds the loop for minutes.
        articles: dict[str, dict] = {}
        for batch_start in range(0, len(all_triples), _LINT_FS_BATCH):
            batch = all_triples[batch_start : batch_start + _LINT_FS_BATCH]
            try:
                results = await asyncio.to_thread(_read_batch, batch)
            except asyncio.CancelledError:
                # Cooperative cancel — outer ``wait_for`` triggered. Bail
                # with whatever we have so far. The caller (lint Phase 1)
                # gets a partial result rather than orphaning a thread that
                # keeps running for minutes after timeout.
                raise
            for rel, info in results:
                # Restore the original title default (wf.stem, not the
                # placeholder we passed to _read_one_article).
                if not info["metadata"].get("title"):
                    info["title"] = rel.rsplit("/", 1)[-1] if "/" in rel else rel
                articles[rel] = info
            # Yield between batches so the loop stays responsive.
            await asyncio.sleep(0)

        if not articles:
            return issues, {}

        # Build inbound link counts + find broken links
        all_slugs = set(articles.keys())
        # Also index by just the slug part (without subdir) for fuzzy matching
        slug_to_path = {}
        for path in all_slugs:
            parts = path.split("/", 1)
            if len(parts) == 2:
                slug_to_path[parts[1]] = path

        missing_pages: set[str] = set()
        for path, info in articles.items():
            for link in info["outbound_links"]:
                # Normalize: links might be "slug" or "subdir/slug"
                link_norm = link.lower().replace(" ", "-")
                target = None
                if link_norm in all_slugs:
                    target = link_norm
                elif link_norm in slug_to_path:
                    target = slug_to_path[link_norm]
                else:
                    # Try partial match
                    for s in all_slugs:
                        if s.endswith(f"/{link_norm}"):
                            target = s
                            break

                if target and target in articles:
                    articles[target]["inbound_count"] += 1
                elif link_norm not in missing_pages:
                    missing_pages.add(link_norm)

        # 1. Orphan pages (no inbound links, excluding source summaries and index)
        for path, info in articles.items():
            if info["inbound_count"] == 0 and not path.startswith("sources/") and not path.startswith("source_summary/"):
                issues.append({
                    "type": "orphan",
                    "severity": "warning",
                    "message": f'Article "{info["title"]}" ({path}) has no inbound links',
                })

        # 2. Broken/missing pages
        for link in missing_pages:
            issues.append({
                "type": "missing_page",
                "severity": "critical",
                "message": f'[[{link}]] is linked but no article exists',
            })

        # 3. High TODO density
        for path, info in articles.items():
            if info["todo_count"] >= 3:
                issues.append({
                    "type": "todo",
                    "severity": "warning",
                    "message": f'Article "{info["title"]}" ({path}) has {info["todo_count"]} [TODO] items',
                })

        # 4. Missing frontmatter
        required_fields = {"entity_type", "status"}
        for path, info in articles.items():
            missing = [f for f in required_fields if not info["metadata"].get(f)]
            if missing:
                issues.append({
                    "type": "frontmatter",
                    "severity": "warning",
                    "message": f'Article "{info["title"]}" ({path}) missing frontmatter: {", ".join(missing)}',
                })

        # 5. Slug-based duplicate detection
        titles_seen: dict[str, str] = {}  # normalized_title → path
        for path, info in articles.items():
            if path.startswith("sources/") or path.startswith("source_summary/"):
                continue
            norm_title = info["title"].lower().strip()
            if norm_title in titles_seen:
                issues.append({
                    "type": "duplicate",
                    "severity": "critical",
                    "message": f'Potential duplicate: "{info["title"]}" ({path}) and ({titles_seen[norm_title]}) have the same title',
                })
            else:
                titles_seen[norm_title] = path

        # Also check slug similarity — pairwise.
        #
        # Performance guard (added 2026-04-25, same audit pass that found
        # the EntityRegistry Tier 4 runaway): naive O(N²) SequenceMatcher
        # over all wiki slugs is fine on small KBs (<500 articles) but
        # pins one CPU core for ~30-60s on a 2700-article vault — and the
        # user can't tell the lint endpoint from a hung server.
        #
        # Two cheap guards keep this safe at any vault size without
        # losing detection quality:
        #   (a) length prefilter — skip pairs whose lengths differ by
        #       more than 30%; SequenceMatcher.ratio() can't exceed
        #       2*min(a,b)/(a+b), so a 5-char slug vs a 30-char slug
        #       maxes at 0.286 — well below the 0.80 threshold. This
        #       eliminates ~95% of pair comparisons on heterogeneous
        #       vaults.
        #   (b) hard cap — if even after the prefilter we'd be doing
        #       more than 500K comparisons, downgrade to slug-prefix
        #       grouping (catches "foo-bar"/"foo-bar-2" duplicates,
        #       misses semantic-only similarity which is rare).
        non_source_paths = [p for p in all_slugs if not p.startswith("sources/") and not p.startswith("source_summary/")]
        slugs = [(p, p.split("/")[-1]) for p in non_source_paths]
        n = len(slugs)
        # Length-prefilter pair count estimate: a slug s only needs to be
        # compared against slugs whose length is within 30% of len(s).
        slugs_sorted = sorted(slugs, key=lambda ps: len(ps[1]))
        seen_pairs: int = 0
        max_pairs = 500_000  # ~600ms wall on a typical machine
        # Tier-3 perf fix (2026-05-07): the 600ms cap was the per-CALL
        # ceiling; on a vault that hits the cap, the loop is held for
        # the full budget. Yield every ``_SIMILARITY_YIELD_EVERY`` pairs
        # so the loop stays responsive even on big vaults.
        _SIMILARITY_YIELD_EVERY = 10_000
        emitted: set[tuple[str, str]] = set()
        for i, (p1, slug1) in enumerate(slugs_sorted):
            len1 = len(slug1)
            min_len = max(1, int(len1 * 0.7))
            max_len = max(len1, int(len1 * 1.43))
            for p2, slug2 in slugs_sorted[i + 1:]:
                len2 = len(slug2)
                if len2 > max_len:
                    break  # sorted ascending, all subsequent are too long
                if len2 < min_len:
                    continue
                seen_pairs += 1
                if seen_pairs > max_pairs:
                    # Hard cap: fall back to prefix grouping for the rest.
                    break
                # Yield to the loop every N pairs. SequenceMatcher.ratio()
                # is pure C/Python and holds the GIL; without this yield,
                # 500K pairs at ~1μs each is 500ms of solid block.
                if seen_pairs % _SIMILARITY_YIELD_EVERY == 0:
                    await asyncio.sleep(0)
                if slug1 != slug2 and SequenceMatcher(None, slug1, slug2).ratio() > 0.80:
                    key = tuple(sorted((p1, p2)))
                    if key not in emitted:
                        emitted.add(key)
                        issues.append({
                            "type": "duplicate",
                            "severity": "warning",
                            "message": f'Similar slugs: {p1} and {p2} — may be duplicates',
                        })
            if seen_pairs > max_pairs:
                break
        if seen_pairs > max_pairs:
            issues.append({
                "type": "info",
                "severity": "info",
                "message": (
                    f"Slug-similarity check capped at {max_pairs} comparisons "
                    f"(vault has {n} non-source articles). "
                    "Re-run lint on a smaller subset to surface deeper duplicates."
                ),
            })

        # 6. Stale articles (source_summary pointing to deleted files)
        for path, info in articles.items():
            if info["status"] == "stale":
                issues.append({
                    "type": "stale",
                    "severity": "warning",
                    "message": f'Article "{info["title"]}" ({path}) is marked stale',
                })

        # Build articles_text dict for LLM prompt
        articles_text = {path: info["content"] for path, info in articles.items()}

        return issues, articles_text

    async def lint(self, slug: str, *, structural_only: bool = False) -> dict:
        """Public entry — scoped pipeline wrapper around ``_body_lint``.

        ``structural_only=True`` skips the LLM-powered Phase 2 (semantic
        review). Used by the watcher's auto-lint path: pure-engine
        deterministic dedup + orphan + broken-link detection that runs
        cheap and fast. Phase 2 (semantic merge candidates, contradictions
        between articles) requires an LLM and is invoked only when the
        caller explicitly asks for the full pass (default behaviour
        preserved for backward compat).
        """
        self._log_activity(
            "lint_started",
            f"KB {slug}: lint started ({'structural-only' if structural_only else 'full'})",
            {"slug": slug, "structural_only": structural_only},
            importance="low",
        )
        try:
            async with self._scoped_pipeline("kb_lint", "lint"):
                result = await self._body_lint(slug, structural_only=structural_only)
                _issues = len(result.get("issues", [])) if isinstance(result, dict) else 0
                self._log_activity(
                    "lint_completed",
                    f"KB {slug}: lint found {_issues} issue(s)",
                    {"slug": slug, "issue_count": _issues, "structural_only": structural_only},
                    importance="medium" if _issues else "low",
                )
                await self._record_decision(
                    action_type="lint_batch",
                    action_target=f"kb/{slug}",
                    rationale=f"Lint found {_issues} issues ({'structural' if structural_only else 'full'})",
                    details={"slug": slug, "issue_count": _issues, "structural_only": structural_only},
                )
                return result
        except Exception as exc:
            self._log_activity(
                "lint_failed",
                f"KB {slug}: lint raised {type(exc).__name__}",
                {"slug": slug, "error": str(exc)[:500]},
                importance="high",
            )
            await self._record_decision(
                action_type="lint_batch",
                action_target=f"kb/{slug}",
                contract_result="failed",
                rationale=f"Lint aborted: {type(exc).__name__}",
                details={"slug": slug, "error": str(exc)[:500]},
            )
            raise

    async def _body_lint(self, slug: str, *, structural_only: bool = False) -> dict:
        """Run wiki health-check: structural analysis + (optionally) LLM
        semantic review. ``structural_only=True`` short-circuits after
        Phase 1 — no LLM call, no work-queue retry path, no semantic
        merge candidates. Returns the same shape with empty semantic
        fields (``llm_issues=[]``, ``suggestions=[]``)."""
        from agntspace.llm.base import Message

        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        schema = self._read_schema(slug)
        index_doc = self._reader.read(f"{base}/wiki/.index.md")

        # Phase 1: Structural analysis (fast, no LLM).
        # Tier-3 perf fix (2026-05-07): _structural_analysis is now an
        # `async def` that does its file reads in chunked batches via
        # asyncio.to_thread + per-batch yields. Replaces the prior
        # whole-function to_thread wrap (Phase B 2026-05-06) which still
        # held the GIL across all batches and produced 5-min event-loop
        # blocks on a 1700-article vault. Direct await now — the function
        # owns its own yield discipline.
        structural_issues, articles_content = await self._structural_analysis(slug)

        if structural_only:
            # Watcher path — pure deterministic dedup + orphan + broken
            # link detection. No LLM call. No retry queue. Same result
            # shape so callers don't have to special-case.
            self._append_log(slug, "lint",
                f"{len(structural_issues)} structural issues (structural-only)")
            return {
                "slug": slug,
                "issues": [f"- [{i['type']}] {i['message']}" for i in structural_issues],
                "suggestions": [],
                "issue_count": len(structural_issues),
                "suggestion_count": 0,
                "structural_issues": len(structural_issues),
                "semantic_issues": 0,
                "structural_only": True,
            }

        structural_text = "\n".join(
            f"- [{i['type']}] ({i['severity']}) {i['message']}" for i in structural_issues
        ) or "No structural issues found."

        # Phase 2: Semantic analysis (LLM)
        articles_text = []
        for path, content in articles_content.items():
            articles_text.append(f"### {path}\n{content[:1500]}")

        # Build lint prompt: skill-loaded or hardcoded fallback
        dynamic_ctx = (
            f"\nKB SCHEMA:\n{schema[:1000]}\n\n"
            f"WIKI INDEX:\n{index_doc.content[:3000]}\n\n"
            f"STRUCTURAL ISSUES:\n{structural_text[:3000]}\n\n"
            f"ARTICLES:\n{chr(10).join(articles_text)[:10000]}"
        )
        skill_prompt = self._get_skill_prompt("kb-lint")
        if skill_prompt:
            lint_system = skill_prompt + "\n\n" + dynamic_ctx
        else:
            lint_system = _LINT_PROMPT_FALLBACK.format(
                schema=schema[:1000], index=index_doc.content[:3000],
                structural_issues=structural_text[:3000],
                articles="\n\n".join(articles_text)[:10000],
            )
        try:
            response = await asyncio.wait_for(self._llm.complete(
                messages=[Message(role="user", content="Run deep wiki health check. Focus on semantic issues the structural analysis can't detect.")],
                system=lint_system,
                max_tokens=2048, temperature=0.3,
                model=self._resolve_model("fast" if self._is_local_mode() else "capable"),  # editor: lint
            ), timeout=self._llm_timeout("lint"))
        except TimeoutError:
            log.warning("KB %s: lint LLM timed out", slug)
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue("lint", {"slug": slug}, deduplicate=True))
            return {"slug": slug, "error": "LLM timed out", "queued": True}
        except Exception as exc:
            log.warning("KB %s: lint LLM failed: %s", slug, exc)
            if self._called_from_queue:
                raise
            if self._work_queue:
                asyncio.create_task(self._work_queue.enqueue("lint", {"slug": slug}, deduplicate=True))
            return {"slug": slug, "structural_issues": structural_issues, "llm_issues": [],
                    "suggestions": [], "error": f"LLM unavailable (structural results only): {exc}", "queued": True}

        llm_issues_text = self._extract_block(response.content, "issues") or ""
        suggestions_text = self._extract_block(response.content, "suggestions") or ""
        llm_issues = [l.strip() for l in llm_issues_text.split("\n") if l.strip().startswith("- ")]
        suggestion_list = [l.strip() for l in suggestions_text.split("\n") if l.strip().startswith("- ")]

        # Combine structural + semantic issues
        all_issues = [f"- [{i['type']}] {i['message']}" for i in structural_issues] + llm_issues

        self._append_log(slug, "lint",
            f"{len(structural_issues)} structural + {len(llm_issues)} semantic issues, {len(suggestion_list)} suggestions")
        return {
            "slug": slug,
            "issues": all_issues,
            "suggestions": suggestion_list,
            "issue_count": len(all_issues),
            "suggestion_count": len(suggestion_list),
            "structural_issues": len(structural_issues),
            "semantic_issues": len(llm_issues),
        }

    # ── Schema co-evolution ──

    async def evolve_schema(self, slug: str) -> dict:
        """Analyze the KB and propose SCHEMA.md updates.

        Detects patterns like:
        - Entity types used in articles but not listed in schema
        - Taxonomy categories that articles cluster around but aren't documented
        - Conventions that emerged organically (e.g., recurring frontmatter fields)
        - New focus questions suggested by the content

        Applies approved proposals directly to SCHEMA.md.
        """
        from agntspace.llm.base import Message

        base = f"knowledge/{slug}"
        schema = self._read_schema(slug)
        if not schema:
            return {"error": f"No SCHEMA.md found for KB {slug}"}

        # Gather evidence: what entity_types, categories, and patterns exist
        entity_types_used: dict[str, int] = {}
        categories_used: dict[str, int] = {}
        taxonomy_paths_used: dict[str, int] = {}
        frontmatter_fields: dict[str, int] = {}
        article_count = 0

        for subdir in _WIKI_SUBDIRS:
            try:
                for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                    rel = self._to_logical(wf)
                    doc = self._reader.read(rel)
                    meta = doc.metadata or {}
                    article_count += 1

                    et = meta.get("entity_type", "")
                    if et:
                        entity_types_used[et] = entity_types_used.get(et, 0) + 1
                    cat = meta.get("category", "")
                    if cat:
                        categories_used[cat] = categories_used.get(cat, 0) + 1
                    tp = meta.get("taxonomy_path", "")
                    if tp:
                        taxonomy_paths_used[tp] = taxonomy_paths_used.get(tp, 0) + 1
                    for k in meta:
                        frontmatter_fields[k] = frontmatter_fields.get(k, 0) + 1
            except Exception:
                continue

        if article_count < 3:
            return {"slug": slug, "proposals": [], "message": "Too few articles to detect patterns"}

        # Check ontology fallback count
        fallback_count = 0
        graph = getattr(self, "_graph", None)
        if graph and hasattr(graph, "get_stats"):
            stats = graph.get_stats()
            fallback_count = stats.get("extraction_metrics", {}).get("related_to_fallbacks", 0)

        # Build evidence for the LLM
        evidence = (
            f"KB: {slug} ({article_count} articles)\n\n"
            f"Current SCHEMA.md:\n```\n{schema}\n```\n\n"
            f"Entity types actually used (type: count):\n"
            + "\n".join(f"  - {t}: {c}" for t, c in sorted(entity_types_used.items(), key=lambda x: -x[1]))
            + "\n\nCategories used:\n"
            + "\n".join(f"  - {c}: {n}" for c, n in sorted(categories_used.items(), key=lambda x: -x[1]))
            + "\n\nTaxonomy paths used:\n"
            + "\n".join(f"  - {p}: {n}" for p, n in sorted(taxonomy_paths_used.items(), key=lambda x: -x[1])[:20])
            + "\n\nFrontmatter fields across articles:\n"
            + "\n".join(f"  - {f}: {n}/{article_count}" for f, n in sorted(frontmatter_fields.items(), key=lambda x: -x[1]))
        )
        if fallback_count > 0:
            evidence += f"\n\nOntology `related_to` fallbacks (unknown predicates): {fallback_count}"

        prompt = (
            "You are a knowledge base architect. Analyze this KB's actual usage patterns "
            "and propose concrete updates to SCHEMA.md.\n\n"
            "Look for:\n"
            "1. Entity types used in articles but NOT listed in the schema's Entity Types section\n"
            "2. Categories or taxonomy clusters that suggest new schema sections\n"
            "3. Conventions that emerged (frontmatter fields used across many articles) not documented\n"
            "4. Focus questions the content suggests but aren't listed\n"
            "5. Missing subdirectory documentation\n\n"
            "Output a JSON array of proposals. Each proposal:\n"
            '```json\n[{"section": "Entity Types|Conventions|Focus Questions|Structure|Notes", '
            '"action": "add|update", "content": "the line(s) to add", '
            '"reason": "why this change"}]\n```\n'
            "Only propose changes NOT already in the schema. If the schema is complete, return `[]`.\n\n"
            + evidence
        )

        try:
            response = await asyncio.wait_for(
                self._llm.complete(
                    messages=[Message(role="user", content=prompt)],
                    system="You are a knowledge base schema architect. Return ONLY valid JSON.",
                    max_tokens=2048,
                    temperature=0.2,
                    # Schema evolution emits structured JSON proposals about a
                    # KB's ontology — same discrimination class as compile/lint.
                    # Mirror their conditional-tier pattern: capable in cloud,
                    # fast in local (no higher option there).
                    model=self._resolve_model("fast" if self._is_local_mode() else "capable"),
                ),
                timeout=self._llm_timeout("lint"),
            )
        except Exception:
            log.debug("Schema evolution LLM failed for %s", slug, exc_info=True)
            return {"slug": slug, "proposals": [], "error": "LLM unavailable"}

        # Parse proposals
        import json as _json
        proposals = []
        try:
            raw = response.content
            # Extract JSON from fenced block if present
            if "```json" in raw:
                raw = raw.split("```json", 1)[1].split("```", 1)[0]
            elif "```" in raw:
                raw = raw.split("```", 1)[1].split("```", 1)[0]
            proposals = _json.loads(raw.strip())
            if not isinstance(proposals, list):
                proposals = []
        except Exception:
            log.debug("Could not parse schema evolution proposals for %s", slug)

        # Apply proposals to SCHEMA.md
        applied = []
        if proposals:
            updated_schema = schema
            for p in proposals:
                section = p.get("section", "")
                content = p.get("content", "")
                reason = p.get("reason", "")
                if not section or not content:
                    continue

                # Find the section header and append content after it
                section_marker = f"## {section}"
                if section_marker in updated_schema:
                    # Insert after the section header and any existing content
                    parts = updated_schema.split(section_marker, 1)
                    # Find the next ## or end of file
                    rest = parts[1]
                    next_section = rest.find("\n## ")
                    if next_section > 0:
                        insert_point = next_section
                    else:
                        insert_point = len(rest)
                    # Append before the next section
                    updated_content = rest[:insert_point].rstrip() + f"\n{content}\n"
                    updated_schema = parts[0] + section_marker + updated_content + rest[insert_point:]
                    applied.append({"section": section, "content": content, "reason": reason})

            if applied and updated_schema != schema:
                with self._writer.trusted_scope("schema_evolution"):
                    self._writer.write(f"{base}/SCHEMA.md", updated_schema)
                self._append_log(slug, "schema-evolution",
                    f"Updated SCHEMA.md: {len(applied)} changes — "
                    + ", ".join(p["section"] for p in applied))
                self._log_activity(
                    "schema_evolved",
                    f"KB {slug}: SCHEMA.md updated with {len(applied)} proposals",
                    {"slug": slug, "applied": applied},
                    importance="medium",
                )

        return {
            "slug": slug,
            "proposals": proposals,
            "applied": applied,
            "article_count": article_count,
            "entity_types_found": entity_types_used,
        }

    # ── Repair ──

    async def repair(self, slug: str) -> dict:
        """Auto-fix wiki issues: delete orphans, remove duplicates, clean .history/ noise.

        Runs structural analysis, then acts on fixable issues:
        - Orphan articles (no inbound links, not sources): deleted
        - Duplicate titles: keeps the one with more content, deletes the other
        - .history/ files that leaked into wiki listings: cleaned up
        - Empty articles (< 50 chars of real content): deleted

        Does NOT require LLM. Fast, deterministic.
        """
        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # _structural_analysis is async since the 2026-05-07 Tier-3 fix
        # (chunked reads + per-batch yields).
        issues, articles_text = await self._structural_analysis(slug)
        actions = {"deleted": [], "kept": [], "cleaned": []}

        # 1. Delete empty articles (< 50 chars of real content)
        for subdir in self._get_wiki_subdirs(slug):
            for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                try:
                    doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                    # Strip frontmatter and whitespace
                    real = doc.content.strip()
                    if len(real) < 50:
                        full = self._resolve(f"{base}/wiki") / subdir / wf.name
                        if full.exists():
                            full.unlink()
                            actions["deleted"].append(f"{subdir}/{wf.stem} (empty)")
                except Exception:
                    continue

        # 2. Delete duplicate titles (keep the one with more content)
        title_map: dict[str, list[tuple[str, int]]] = {}  # norm_title → [(path, content_len)]
        for issue in issues:
            if issue["type"] == "duplicate" and "same title" in issue["message"]:
                # Extract both paths from the message
                import re as _re
                paths = _re.findall(r'\(([^)]+)\)', issue["message"])
                if len(paths) >= 2:
                    for p in paths:
                        content = articles_text.get(p, "")
                        title_map.setdefault(issue["message"], []).append((p, len(content)))

        for _msg, entries in title_map.items():
            if len(entries) < 2:
                continue
            # Keep the one with more content
            entries.sort(key=lambda x: x[1], reverse=True)
            keep = entries[0][0]
            for path, _size in entries[1:]:
                subdir, stem = path.split("/", 1) if "/" in path else ("", path)
                full = self._resolve(f"{base}/wiki") / subdir / f"{stem}.md"
                if full.exists():
                    full.unlink()
                    actions["deleted"].append(f"{path} (duplicate of {keep})")
            actions["kept"].append(keep)

        # 3. Clean up .history/ files that shouldn't exist (e.g., in non-wiki dirs)
        try:
            history_dirs = list((self._resolve(f"{base}/wiki")).rglob(".history"))
            for hd in history_dirs:
                if hd.is_dir():
                    # Count files
                    history_files = list(hd.glob("*.md"))
                    if len(history_files) > 20:
                        # Keep only 20 most recent per article stem
                        stems: dict[str, list] = {}
                        for hf in history_files:
                            stem = hf.stem.rsplit("_", 1)[0] if "_" in hf.stem else hf.stem
                            stems.setdefault(stem, []).append(hf)
                        for stem, files in stems.items():
                            files.sort(key=lambda f: f.name, reverse=True)
                            for old in files[20:]:
                                old.unlink()
                                actions["cleaned"].append(str(old.name))
        except Exception:
            pass

        self._append_log(slug, "repair",
            f"deleted {len(actions['deleted'])}, cleaned {len(actions['cleaned'])}")

        return {
            "slug": slug,
            "deleted": actions["deleted"],
            "kept": actions["kept"],
            "cleaned": actions["cleaned"],
            "total_actions": len(actions["deleted"]) + len(actions["cleaned"]),
        }

    # ─────────────────────────────────────────────────────────────────
    # Repair classifications — backfill entity_type + taxonomy_path on
    # legacy wiki articles that were compiled before the kb-compile prompt
    # had the entity_type ↔ taxonomy_path pairing rules + before compile
    # was bumped to the capable tier. Six bug classes addressed:
    #
    #   1. Empty taxonomy_path                → backfill via classify_article
    #   2. L1-only taxonomy_path              → deepen via classify_article
    #   3. entity_type ↔ taxonomy_path        → reconcile via the normalizer
    #   4. entity_type ↔ subdir mismatch      → reconcile via subdir → etype
    #   5. Person-default in entities/ on a   → LLM reclassification (capable)
    #      non-personal-name title              tier — same call class as compile
    #   6. Junk title (email, sentence)       → flag for manual delete (NEVER
    #                                            auto-deletes — caller decides)
    #
    # Idempotent: re-running on an already-fixed article is a no-op.
    # ─────────────────────────────────────────────────────────────────

    # arch:deterministic — common org-suffix tokens used to detect that a
    # capitalised name is more likely an organization than a person. Not
    # exhaustive (no pattern list could be); the LLM reclassification step
    # is the primary discriminator for ambiguous names. These suffixes catch
    # the obvious cases without needing an LLM call.
    _ORG_NAME_SUFFIXES: tuple[str, ...] = (  # arch:deterministic — closed lexicon for org-suffix shape detection
        " inc", " inc.", " corp", " corp.", " corporation",
        " ltd", " ltd.", " limited", " llc", " l.l.c.",
        " ab", " a/s", " oy", " gmbh", " s.a.", " sa", " s.r.l.", " srl",
        " plc", " sas", " bv", " nv", " co.", " co",
        " group", " holdings", " holding", " ventures", " partners",
        " foundation", " institute", " association", " agency",
        " university", " college", " school",
        " labs", " systems", " technologies", " technology",
        " software", " network", " networks",
    )

    # arch:deterministic — keyword markers for common product/tool names that
    # default-to-person classification keeps mistaking. Substring match on
    # the lowercased title.
    _PRODUCT_NAME_MARKERS: tuple[str, ...] = (  # arch:deterministic — product-name lexicon for substring shape detection
        "gpt", "chatgpt", "claude", "gemini",
        "tensorflow", "pytorch", "keras", "scikit",
        "framework", "library", "platform", "engine", "toolkit",
        ".com", ".ai", ".io", ".dev",
    )

    # arch:deterministic — the email regex matches the Internet-Standard
    # general shape, NOT RFC 5322 in full. False positives at this gate are
    # low-cost (article gets flagged for manual review, never auto-deleted).
    _EMAIL_REGEX = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")

    @classmethod
    def _looks_like_personal_name(cls, title: str) -> bool:
        """Heuristic for whether a wiki title is plausibly a person's name.

        Returns True for: 1-3 capitalised words separated by single spaces,
        no special chars except apostrophes/hyphens within the name, no
        org-suffix tokens, no product markers, no email shape.

        False positives (returns True for non-persons) end up SKIPPED by
        the LLM reclassification — those are safe. False negatives (returns
        False for real persons) trigger an unnecessary LLM call — also safe,
        the LLM will confirm person.
        """
        if not title:
            return False
        t = title.strip()
        # Reject obvious non-person shapes
        if cls._EMAIL_REGEX.match(t):
            return False
        t_lower = t.lower()
        for suffix in cls._ORG_NAME_SUFFIXES:
            if t_lower.endswith(suffix) or suffix.strip() + " " in t_lower:
                return False
        for marker in cls._PRODUCT_NAME_MARKERS:
            if marker in t_lower:
                return False
        # Reject titles with commas, periods (other than initials), digits,
        # or parentheses — those are usually descriptions or org-shapes.
        if any(c in t for c in ",;:()[]{}/\\"):
            return False
        if any(c.isdigit() for c in t):
            return False
        # Person names: 2-4 words, each starts uppercase. Hyphens + apostrophes
        # within a word are fine. Reject all-caps tokens (likely acronyms).
        # SINGLE-WORD names (Renewcell, Tony, Yoldia) are deliberately rejected
        # by this heuristic — they're ambiguous between first names and
        # one-word org names. The LLM reclassification step is the right
        # tier to disambiguate; the heuristic's job is only to skip LLM for
        # CLEARLY personal names (which are 2+ words almost without exception).
        words = t.split()
        if not (2 <= len(words) <= 4):
            return False
        for w in words:
            if not w:
                return False
            if not w[0].isupper():
                return False
            if w.isupper() and len(w) > 2:  # all-caps acronym (DALL, NASA, etc.)
                return False
        return True

    # arch:deterministic — sentence-detection lexicon. Three closed sets used
    # only by the junk-title heuristic. English + Swedish for the user vault;
    # add languages here as the user base grows.
    _SENTENCE_QUESTION_STARTS: frozenset[str] = frozenset({  # arch:deterministic — sentence-detection lexicon
        # English
        "how", "what", "why", "where", "when", "who", "which",
        # Swedish
        "hur", "vad", "varför", "var", "när", "vem", "vilken", "vilka",
    })
    _SENTENCE_VERB_STARTS: frozenset[str] = frozenset({  # arch:deterministic — sentence-detection lexicon
        # English — common verb forms that start sentence fragments
        # ("Describes specific...", "Identifies the...")
        "describes", "identifies", "explains", "shows", "demonstrates",
        "analyzes", "discusses", "explores", "covers", "addresses",
        "provides", "presents", "outlines", "summarizes", "highlights",
    })
    _SENTENCE_TRAILING_TELLS: frozenset[str] = frozenset({  # arch:deterministic — sentence-detection lexicon
        # English
        "the", "a", "an", "of", "for", "to", "in", "on", "at", "by",
        "with", "from", "and", "or", "but", "is", "are", "was", "were",
        "being", "been",
        # Swedish
        "som", "att", "och", "eller", "för", "av", "i", "på", "med",
        "till", "vid",
    })

    @classmethod
    def _is_junk_title(cls, title: str) -> tuple[bool, str]:
        """Detect titles that aren't real entity names.

        Returns (is_junk, reason). Reasons: ``email``, ``sentence_fragment``,
        ``trailing_preposition``, ``sentence_start``, or ``""`` when not junk.

        Three sentence-detection signals (any one fires):
          1. Trailing word is a preposition / conjunction / article — the
             classic chain-of-thought tail.
          2. First word is a question word (How/What/Why/Hur/Vad/Varför...)
             AND title is 4+ words. Question-word starts almost never appear
             in entity names.
          3. First word is a sentence-starting verb form (Describes /
             Identifies / Beskriver / etc.) AND title is 4+ words.
          4. Any title with 8+ words is very likely a sentence regardless.
        """
        if not title:
            return False, ""
        t = title.strip()
        if cls._EMAIL_REGEX.match(t):
            return True, "email"
        words = t.split()
        if not words:
            return False, ""
        first_lower = words[0].lower().rstrip(".,;:!?")
        last_lower = words[-1].lower().rstrip(".,;:!?")
        # Signal 1: trailing tell
        if len(words) > 5 and last_lower in cls._SENTENCE_TRAILING_TELLS:
            return True, "trailing_preposition"
        # Signal 2: question-word start
        if len(words) >= 4 and first_lower in cls._SENTENCE_QUESTION_STARTS:
            return True, "sentence_start"
        # Signal 3: sentence-starting verb
        if len(words) >= 4 and first_lower in cls._SENTENCE_VERB_STARTS:
            return True, "sentence_start"
        # Signal 4: sheer length
        if len(words) >= 8:
            return True, "sentence_fragment"
        return False, ""

    async def _llm_pick_taxonomy_leaf(
        self, title: str, body_excerpt: str, candidate_leaves: list[str],
    ) -> str:
        """Call the LLM (capable tier) to pick the deepest matching taxonomy
        leaf for an article from a constrained candidate set.

        This is the active-deepening pass that closes Problem B from the
        2026-04-27 wiki classification overhaul (Session 2): source_summary
        articles whose `taxonomy_path` is the bare L1 sentinel "sources"
        cannot be deepened by the deterministic ``classify_article`` (which
        returns the same L1 because the L1 node declares ``entity_types:
        ["source_summary", "document"]`` and that's the deepest match). The
        LLM has read the body and CAN pick a real leaf — it just wasn't being
        asked.

        Args:
            title: The article title (filename or frontmatter title).
            body_excerpt: First N chars of the article body. Provides domain
                context for the leaf decision.
            candidate_leaves: Constrained set of valid leaf paths (e.g. all
                paths under ``sources/`` at depth ≥ 2). The LLM MUST pick from
                this list — outputs not in the list are rejected.

        Returns:
            The chosen leaf path (e.g. ``"sources/articles/news"``) or ``""``
            when the LLM is unavailable, unparseable, or picks something not
            in the candidate set. Caller should leave the article unchanged
            in that case.
        """
        if not self._llm or not candidate_leaves:
            return ""

        # Build a numbered enum for the LLM. Numbered list constrains output
        # better than free-form path emission — small local models drift less
        # when picking "12" than when re-typing "sources/articles/blog-posts".
        leaves_block = "\n".join(
            f"  {i+1:>2}. {leaf}" for i, leaf in enumerate(candidate_leaves)
        )
        prompt = (
            f"Title: {title}\n\n"
            f"First excerpt:\n{body_excerpt[:600]}\n\n"
            f"Pick the SINGLE best taxonomy leaf for this article from the "
            f"list below. Match by both the source TYPE (article / book / "
            f"podcast / standard document / meeting transcript) AND the "
            f"source's TOPIC. Reply with ONLY the leaf path on its own "
            f"line — no explanation, no number, no quotes.\n\n"
            f"Candidates:\n{leaves_block}\n"
        )
        try:
            from agntspace.llm.base import Message
            response = await asyncio.wait_for(
                self._llm.complete(
                    messages=[Message(role="user", content=prompt)],
                    system=(
                        "You are a knowledge-base taxonomy classifier. "
                        "Reply with ONE leaf path on a single line, exactly "
                        "as shown in the candidate list. No explanation."
                    ),
                    max_tokens=64,
                    temperature=0.0,
                    model=self._resolve_model(
                        "fast" if self._is_local_mode() else "capable"
                    ),
                ),
                timeout=self._llm_timeout("classify", default=30),
            )
            raw = (response.content or "").strip()
            # Take the first non-empty line — small models sometimes add a
            # trailing newline + commentary despite instructions.
            for line in raw.splitlines():
                cand = line.strip().strip('"').strip("'").strip("`")
                # Sometimes LLMs prefix with the number ("3. sources/articles/news")
                if "." in cand and cand.split(".", 1)[0].strip().isdigit():
                    cand = cand.split(".", 1)[1].strip()
                # Normalize separator
                cand = cand.replace("\\", "/").strip("/").lower()
                if cand and cand in {leaf.lower() for leaf in candidate_leaves}:
                    # Find the original-cased leaf to preserve casing.
                    for leaf in candidate_leaves:
                        if leaf.lower() == cand:
                            return leaf
            return ""
        except Exception:
            log.debug("LLM taxonomy leaf pick failed for %r", title, exc_info=True)
            return ""

    async def _llm_reclassify_entity(
        self, title: str, body_excerpt: str,
    ) -> str:
        """Call the LLM (capable tier) to determine entity_type for one article.

        Returns one of: ``person | organization | place | thing | event | concept``.
        Returns ``""`` when the LLM is unavailable or unparseable — caller
        should leave the article unchanged in that case.
        """
        if not self._llm:
            return ""
        prompt = (
            f"Title: {title}\n\n"
            f"First excerpt:\n{body_excerpt[:600]}\n\n"
            f"Classify the SUBJECT of this wiki article into ONE of:\n"
            f"  person       — an individual human (Greg Kamradt, Sarah Chen)\n"
            f"  organization — a company, agency, NGO, university, fund (Renewcell, Volvo, OpenAI, MIT)\n"
            f"  place        — a city, country, site, venue (Stockholm, Byggmax store branch)\n"
            f"  thing        — a product, tool, app, book, device (ChatGPT, PyTorch, iPhone)\n"
            f"  event        — a meeting, conference, incident (Q3 Board Meeting, NeurIPS 2024)\n"
            f"  concept      — an idea, method, topic (Bayesian inference, FMEA)\n\n"
            f"Reply with ONLY the single word, lowercase. No explanation."
        )
        try:
            from agntspace.llm.base import Message
            response = await asyncio.wait_for(
                self._llm.complete(
                    messages=[Message(role="user", content=prompt)],
                    system="You are a knowledge-base entity classifier. Reply with one lowercase word.",
                    max_tokens=16,
                    temperature=0.0,
                    model=self._resolve_model("fast" if self._is_local_mode() else "capable"),
                ),
                timeout=self._llm_timeout("classify", default=30),
            )
            raw = (response.content or "").strip().lower()
            # Strip any punctuation / extra words — take the first token.
            token = re.findall(r"[a-z_]+", raw)
            if not token:
                return ""
            t = token[0]
            valid = {"person", "organization", "place", "thing", "event", "concept"}
            return t if t in valid else ""
        except Exception:
            log.debug("LLM reclassify failed for %r", title, exc_info=True)
            return ""

    # Phase 0.4 (2026-05-04) — hard per-pass cap on LLM-requiring fixes.
    # The previous default (None → effectively unlimited via 10_000) timed
    # out at 180 s on a vault with 113 split-brain articles. Now: each
    # pass drains at most _REPAIR_DEFAULT_LIMIT articles; the daily
    # heartbeat-driven editor-quality-pass calls this with the YAML cap
    # which we ship at 20. Vault drains over a week of daily ticks
    # instead of timing out every time.
    _REPAIR_DEFAULT_LIMIT: int = 20  # arch:deterministic — bounded background work; load-bearing for the "200 articles → 1 week of daily ticks" SLA.

    async def repair_classifications(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = True,
        use_llm: bool = True,
        limit: int | None = None,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Public entry point — wraps body in ``_scoped_pipeline`` for write
        authorization (Rule 3). See ``_do_repair_classifications``.

        Args:
            slug: KB slug; ``None`` scans every KB.
            dry_run: True (default) → return the plan, no writes. False →
                apply fixes via ``update_article`` (contract-gated, auto-versioned).
            use_llm: True (default) → use the capable LLM to re-classify
                person-defaulted entities/. False → only apply deterministic
                fixes (empty paths, L1-only paths, normalizer reconciliation).
            limit: Cap the number of LLM-requiring articles per run. Useful
                for incremental sweeps. Phase 0.4 (2026-05-04) — when None,
                defaults to ``_REPAIR_DEFAULT_LIMIT`` (20) instead of
                "effectively unlimited". Bounds background work so a
                single tick can't burn 180 s of LLM budget. Callers who
                want a bigger sweep pass an explicit larger ``limit``.
            progress: Optional ``ProgressHandle`` (Phase 2 of async-job pattern).
                When set, this method updates total/processed and yields to
                the event loop every N items so the server stays responsive
                during long apply runs.

        Returns:
            ``{scanned, fixes_applied, fixes_pending, flags, errors, dry_run, ...}``
        """
        if dry_run:
            return await self._do_repair_classifications(slug, dry_run=True, use_llm=use_llm, limit=limit, progress=progress)
        async with self._scoped_pipeline(
            "kb_repair_classifications", scope_prefix="repair-class"
        ):
            return await self._do_repair_classifications(slug, dry_run=False, use_llm=use_llm, limit=limit, progress=progress)

    async def _do_repair_classifications(
        self,
        slug: str | None,
        *,
        dry_run: bool,
        use_llm: bool,
        limit: int | None,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Implementation. See public wrapper for docstring."""
        from agntspace.kb.taxonomy import (
            classify_article,
            flatten_taxonomy,
            load_taxonomy,
        )

        # Resolve KB list
        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        # One taxonomy load shared across all articles
        flat_nodes = flatten_taxonomy(load_taxonomy(self._skills_dir)) if self._skills_dir else []
        known_paths = {n["path"] for n in flat_nodes}
        by_path = {n["path"]: n for n in flat_nodes}

        # Subdir → expected entity_type set. Used for bug class 4 detection.
        # arch:deterministic — derived from the v2 taxonomy + wiki layout
        # convention. Adding a new entity subdir requires updating this map.
        SUBDIR_EXPECTED: dict[str, frozenset[str]] = {
            "entities": frozenset({"person", "organization", "place", "thing", "event"}),
            "concepts": frozenset({"concept"}),
            "synthesis": frozenset({"synthesis"}),
            "decisions": frozenset({"decision_record", "decision"}),
            # 2026-04-27: source_summary → digest rename. Both accepted during
            # transition; the wiki/sources/ subdir holds legacy articles, the
            # new wiki/digests/ subdir holds renamed ones.
            "sources": frozenset({"source_summary", "document", "digest"}),
            "digests": frozenset({"digest", "document"}),
            "projects": frozenset({"project"}),
        }

        import asyncio as _asyncio

        from agntspace.infra.job_registry import ProgressHandle
        progress = progress or ProgressHandle.detached()

        scanned = 0
        fixes_applied: list[dict] = []
        fixes_pending: list[dict] = []
        flags: list[dict] = []
        errors: list[dict] = []
        # Phase 0.4 (2026-05-04) — None → bounded default (20). Callers
        # who want a bigger sweep pass an explicit larger limit.
        if limit is None:
            limit = self._REPAIR_DEFAULT_LIMIT
        llm_calls_remaining = limit

        # Pre-walk all KBs to count files for the progress bar — cheap.
        # We keep the nested kb_slug→wiki_files iteration below
        # (preserves the original logic that uses ``kb_slug`` deep in
        # the body); the pre-walk only feeds total/processed into the
        # progress handle.
        _total = 0
        for _ks in kbs:
            try:
                _total += len(self._reader.list_files(f"knowledge/{_ks}/wiki", "**/*.md"))
            except Exception:
                pass
        progress.set_total(_total)
        progress.set_processed(0)

        # Yield every item — sleep(0) is microseconds and the
        # per-iteration work (file read + frontmatter parse + maybe
        # update_article) is on the order of 50-200ms. Yielding every
        # 25 items meant up to 5s of event-loop blocking per batch,
        # which made /api/health and DELETE /api/jobs/{id} unreachable
        # during long apply runs. Per-item yield closes that gap with
        # negligible overhead (<1ms total over 1693 items).
        _YIELD_EVERY = 1
        _processed_idx = 0
        _cancelled = False

        for kb_slug in kbs:
            if _cancelled:
                break
            base = f"knowledge/{kb_slug}"
            try:
                wiki_files = self._reader.list_files(f"{base}/wiki", "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files: {exc}"})
                continue

            for wf in wiki_files:
                if _processed_idx % _YIELD_EVERY == 0:
                    if progress.cancelled():
                        _cancelled = True
                        break
                    await _asyncio.sleep(0)
                _processed_idx += 1
                progress.tick()

                name = wf.name
                path_str = str(wf).replace("\\", "/")
                if name.startswith("_") or name.startswith("."):
                    continue
                if "/.history/" in path_str or "/.archives/" in path_str:
                    continue

                try:
                    rel = self._to_logical(wf)
                except Exception:
                    continue

                scanned += 1
                try:
                    doc = self._reader.read(rel)
                except Exception as exc:
                    errors.append({"path": rel, "error": f"read: {exc}"})
                    continue

                meta = doc.metadata or {}
                title = str(meta.get("title") or wf.stem).strip()
                etype = str(meta.get("entity_type") or "").strip()
                tax_path = str(meta.get("taxonomy_path") or "").strip()
                # Subdir is the FIRST path segment under wiki/, not the parent dir
                # (which could be a deeper category subfolder).
                wiki_idx = path_str.find("/wiki/")
                subdir = ""
                if wiki_idx >= 0:
                    rest = path_str[wiki_idx + len("/wiki/"):]
                    subdir = rest.split("/", 1)[0] if "/" in rest else ""

                # ── Bug class 6: junk title — flag, never auto-fix ──
                # Only check in subdirs where titles MUST be entity-names or
                # concept-names. sources/ pages legitimately carry filename-
                # derived titles ("Source: $KC You know this stock..."); flagging
                # those would be a false-positive cascade. synthesis/ titles are
                # short descriptive phrases — sentence-shape detection isn't
                # meaningful there. decisions/ titles ARE checked because they
                # follow a strict "Decision: <noun phrase>" template.
                _check_junk_in = {"entities", "concepts", "decisions"}
                if subdir in _check_junk_in:
                    is_junk, junk_reason = self._is_junk_title(title)
                    if is_junk:
                        flags.append({
                            "slug": meta.get("slug") or wf.stem,
                            "kb": kb_slug,
                            "path": rel,
                            "title": title,
                            "issue": f"junk_title:{junk_reason}",
                            "current_entity_type": etype,
                            "current_taxonomy_path": tax_path,
                        })
                        continue

                # Compute target_etype
                target_etype = etype

                # ── Bug class 5: person default in entities/ for non-personal name ──
                # Trigger LLM reclassification when the article is in entities/
                # AND classified as person AND the title doesn't look like a
                # personal name. Uses the LLM (capable tier) to pick the correct
                # type from {person, organization, place, thing, event, concept}.
                needs_llm = (
                    use_llm
                    and subdir == "entities"
                    and etype == "person"
                    and not self._looks_like_personal_name(title)
                    and llm_calls_remaining > 0
                )
                if needs_llm:
                    body_excerpt = (doc.content or "")[:600]
                    new_etype = await self._llm_reclassify_entity(title, body_excerpt)
                    llm_calls_remaining -= 1
                    if new_etype and new_etype != etype:
                        target_etype = new_etype

                # ── Bug class 4: subdir vs entity_type mismatch ──
                # If the article is in entities/ but its entity_type is concept
                # (or similar), flag — don't auto-move. File-system moves are
                # destructive and should require user confirmation.
                expected_etypes = SUBDIR_EXPECTED.get(subdir, frozenset())
                if (
                    expected_etypes
                    and target_etype
                    and target_etype not in expected_etypes
                ):
                    flags.append({
                        "slug": meta.get("slug") or wf.stem,
                        "kb": kb_slug,
                        "path": rel,
                        "title": title,
                        "issue": "subdir_etype_mismatch",
                        "current_entity_type": target_etype,
                        "current_subdir": subdir,
                        "expected_entity_types": sorted(expected_etypes),
                    })
                    # Continue to taxonomy_path checks even when subdir mismatches
                    # — fixing taxonomy_path is still valuable while user decides
                    # whether to physically move the file.

                # Compute target_taxonomy_path
                target_path = tax_path

                # ── Bug class 1: empty taxonomy_path ──
                if not tax_path and target_etype and flat_nodes:
                    new_path = classify_article(target_etype, "", title, flat_nodes)
                    if new_path and new_path in known_paths:
                        target_path = new_path

                # ── Bug class 2: L1-only taxonomy_path → deepen if possible ──
                elif tax_path and "/" not in tax_path and target_etype and flat_nodes:
                    deeper = classify_article(target_etype, "", title, flat_nodes)
                    # Only adopt if it IS deeper (has more segments) than current.
                    if deeper and "/" in deeper and deeper.startswith(tax_path + "/"):
                        target_path = deeper

                # ── Bug class 2b: source_summary stuck at L1 — LLM active deepen ──
                # Closes Problem B from the 2026-04-27 wiki classification overhaul.
                # The deterministic Bug class 2 cannot deepen source_summary
                # articles whose path is bare "sources" because the L1 node
                # declares entity_types: ["source_summary", "document"] — so
                # ``classify_article`` returns the same "sources" L1, never a
                # leaf. The LLM has read the body and CAN pick a real leaf;
                # we just need to ask it from a constrained candidate set.
                #
                # Trigger: target_etype is source_summary or document, AND the
                # current target_path is empty / bare "sources" / hasn't been
                # successfully deepened by class 2 above. Use a budget-checked
                # LLM call so a huge KB doesn't burn through the user's
                # cap silently.
                # Accept both legacy "source_summary" and the new "digest"
                # entity_type during the 2026-04-27 source_summary → digest
                # rename transition. Future writes use "digest".
                _needs_source_deepen = (
                    use_llm
                    and target_etype in ("source_summary", "document", "digest")
                    and (not target_path or target_path == "sources")
                    and llm_calls_remaining > 0
                    and flat_nodes
                )
                if _needs_source_deepen:
                    # Build candidate set: every leaf under "sources/" at depth ≥ 2.
                    # Filter out the L1 node itself ("sources" with no slash).
                    sources_leaves = sorted(
                        n["path"] for n in flat_nodes
                        if n["path"].startswith("sources/") and "/" in n["path"]
                    )
                    if sources_leaves:
                        body_excerpt = (doc.content or "")[:600]
                        new_path = await self._llm_pick_taxonomy_leaf(
                            title, body_excerpt, sources_leaves,
                        )
                        llm_calls_remaining -= 1
                        if new_path and new_path in known_paths:
                            target_path = new_path

                # ── Bug class 3: entity_type ↔ taxonomy_path declared mismatch ──
                # If the path's declared entity_types is non-empty AND etype isn't
                # in it, reconcile via the normalizer's logic (prefer etype, find
                # a path that matches it).
                if target_path and target_path in by_path:
                    declared = list(by_path[target_path].get("entity_types") or [])
                    if target_etype and declared and target_etype not in declared:
                        new_path = classify_article(target_etype, "", title, flat_nodes)
                        if new_path and new_path in known_paths and new_path != target_path:
                            target_path = new_path

                # If nothing changed, skip
                if target_etype == etype and target_path == tax_path:
                    continue

                fix_record = {
                    "slug": meta.get("slug") or wf.stem,
                    "kb": kb_slug,
                    "path": rel,
                    "title": title,
                    "old_entity_type": etype,
                    "new_entity_type": target_etype,
                    "old_taxonomy_path": tax_path,
                    "new_taxonomy_path": target_path,
                    "used_llm": needs_llm and target_etype != etype,
                }

                if dry_run:
                    fixes_pending.append(fix_record)
                else:
                    try:
                        updates: dict = {}
                        if target_etype != etype:
                            updates["entity_type"] = target_etype
                        if target_path != tax_path:
                            updates["taxonomy_path"] = target_path
                        if updates:
                            # Slug fallback uses the slug-form, NOT the raw
                            # filename stem — see _filename_stem_to_slug
                            # docstring. Without this round-trip, articles
                            # whose filename has spaces/special chars and
                            # no explicit frontmatter `slug:` field fail
                            # the update_article lookup with "Article not
                            # found" even though the file IS on disk.
                            self.update_article(
                                meta.get("slug") or self._filename_stem_to_slug(wf.stem),
                                None,
                                updates,
                            )
                            fixes_applied.append(fix_record)
                    except Exception as exc:
                        errors.append({
                            "path": rel,
                            "error": f"update_article: {exc}",
                            **fix_record,
                        })

        # Activity event — Rule 13 awareness
        try:
            _activity = getattr(self, "_activity", None)
            if _activity:
                await _activity.log(
                    category="knowledge",
                    action="kb_classifications_repaired" if not dry_run else "kb_classifications_scanned",
                    summary=(
                        f"Scanned {scanned}, "
                        f"{'pending ' + str(len(fixes_pending)) if dry_run else 'applied ' + str(len(fixes_applied))}, "
                        f"flagged {len(flags)}, errors {len(errors)}"
                    ),
                    details={
                        "scanned": scanned,
                        "fixes_applied": len(fixes_applied),
                        "fixes_pending": len(fixes_pending),
                        "flags": len(flags),
                        "errors": len(errors),
                        "dry_run": dry_run,
                    },
                    importance="medium",
                )
        except Exception:
            pass

        return {
            "scanned": scanned,
            "fixes_applied": len(fixes_applied) if not dry_run else 0,
            "fixes_pending": len(fixes_pending) if dry_run else 0,
            "flags": len(flags),
            "errors": len(errors),
            "dry_run": dry_run,
            "applied": fixes_applied if not dry_run else [],
            "pending": fixes_pending if dry_run else [],
            "flagged": flags,
            "error_details": errors,
        }

    @staticmethod
    def _build_library_filename_index(library_root: Path) -> dict[str, str]:
        """Walk ``library/`` and return ``{filename: vault_relative_path}``.

        Used by ``repair_library_paths`` (Problem C closer) to resolve
        phantom ``library_path`` frontmatter entries to their actual on-disk
        location. First-occurrence wins on duplicate filenames — collisions
        are unusual but unavoidable when a file legitimately exists in two
        taxonomy branches.

        Skips .archives/, .quarantine/, .history/ and dot-prefixed files
        (image sidecars + bookkeeping).
        """
        skip_dirs = {".archives", ".quarantine", "quarantine", ".history", ".tmp"}
        index: dict[str, str] = {}
        if not library_root.is_dir():
            return index
        for f in library_root.rglob("*"):
            if not f.is_file():
                continue
            if f.name.startswith("."):
                continue
            rel_parts = f.relative_to(library_root).parts
            if any(p in skip_dirs for p in rel_parts):
                continue
            if f.name not in index:
                # Vault-relative path computed below at the call site —
                # we just record the relative-to-library path here so the
                # caller can compose with the kb prefix.
                index[f.name] = "/".join(rel_parts).replace("\\", "/")
        return index

    async def repair_library_paths(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = True,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Public entry point — wraps body in ``_scoped_pipeline`` for write
        authorization (Rule 3). See ``_do_repair_library_paths``.

        Closes Problem C from the 2026-04-27 wiki classification overhaul:
        wiki source pages whose ``library_path:`` frontmatter points at a
        path that doesn't exist on disk (legacy type-date layout paths like
        ``../../library/article/2026-04/foo.pdf``) get rewritten to the
        actual on-disk vault-relative absolute path (e.g.
        ``library/sources/articles/news/foo.pdf``). Resolution by filename
        lookup against the live library/ tree; first-occurrence wins on
        collisions. Idempotent.

        Args:
            slug: KB slug; ``None`` scans every KB.
            dry_run: True (default) → return the plan, no writes.
            progress: Optional ``ProgressHandle`` (Phase 2 of async-job
                pattern). When set, populates total/processed and yields
                to the event loop every N items.

        Returns:
            ``{scanned, rewrites_pending, rewrites_applied, errors, dry_run, ...}``
        """
        if dry_run:
            return await self._do_repair_library_paths(slug, dry_run=True, progress=progress)
        async with self._scoped_pipeline(
            "kb_repair_library_paths", scope_prefix="repair-libpath"
        ):
            return await self._do_repair_library_paths(slug, dry_run=False, progress=progress)

    async def _do_repair_library_paths(
        self,
        slug: str | None,
        *,
        dry_run: bool,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Implementation. See public wrapper for docstring."""
        import asyncio as _asyncio

        from agntspace.infra.job_registry import ProgressHandle
        progress = progress or ProgressHandle.detached()

        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        scanned = 0
        rewrites_pending: list[dict] = []
        rewrites_applied: list[dict] = []
        errors: list[dict] = []
        unresolved: list[dict] = []  # phantom but no on-disk match

        # Pre-walk for total — cheap.
        _total = 0
        for _ks in kbs:
            try:
                _total += len(self._reader.list_files(
                    f"knowledge/{_ks}/wiki/sources", "**/*.md",
                ))
            except Exception:
                pass
        progress.set_total(_total)
        progress.set_processed(0)

        # Yield every item — see analogous comment in
        # _do_repair_classifications. Per-item sleep(0) is microseconds,
        # while sync-I/O blocking accumulates linearly. Per-25-item
        # yields meant /api/health and DELETE /api/jobs/{id} were
        # unreachable during long apply runs. Per-item yield closes
        # that with negligible overhead.
        _YIELD_EVERY = 1
        _processed_idx = 0
        _cancelled = False

        for kb_slug in kbs:
            if _cancelled:
                break
            base = f"knowledge/{kb_slug}"
            sources_dir = f"{base}/wiki/sources"
            try:
                source_files = self._reader.list_files(sources_dir, "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files: {exc}"})
                continue

            # Build per-KB filename index ONCE
            library_root = self._resolve(f"{base}/library")
            file_index = self._build_library_filename_index(library_root)

            for sf in source_files:
                if _processed_idx % _YIELD_EVERY == 0:
                    if progress.cancelled():
                        _cancelled = True
                        break
                    await _asyncio.sleep(0)
                _processed_idx += 1
                progress.tick()

                name = sf.name
                if name.startswith("_") or name.startswith("."):
                    continue
                path_str = str(sf).replace("\\", "/")
                if "/.history/" in path_str or "/.archives/" in path_str:
                    continue

                try:
                    rel = self._to_logical(sf)
                except Exception:
                    continue

                scanned += 1
                try:
                    doc = self._reader.read(rel)
                except Exception as exc:
                    errors.append({"path": rel, "error": f"read: {exc}"})
                    continue

                meta = doc.metadata or {}
                old_lib_path = str(meta.get("library_path") or "").strip()
                if not old_lib_path:
                    # No library_path frontmatter — skip silently (some legacy
                    # source pages predate this field).
                    continue

                # Compute the CURRENT physical target of the existing
                # library_path. If it's relative, resolve against the source
                # page's parent directory. If it's vault-relative absolute
                # (starts with "library/" or "knowledge/"), normalize.
                lib_filename = old_lib_path.rsplit("/", 1)[-1]
                if not lib_filename:
                    continue

                current_target_exists = False
                try:
                    if old_lib_path.startswith("../"):
                        # Resolve against source page parent dir, then map
                        # back to vault-relative.
                        source_parent = sf.parent
                        resolved = (source_parent / old_lib_path).resolve()
                        current_target_exists = resolved.is_file()
                    else:
                        # Treat as vault-relative.
                        candidate_rel = old_lib_path.lstrip("./").lstrip("/")
                        resolved_vault = self._resolve(candidate_rel)
                        current_target_exists = resolved_vault.is_file()
                except Exception:
                    current_target_exists = False

                # If current target exists AND is in vault-relative absolute
                # form starting with "library/", it's already canonical.
                # Skip — this is the idempotency guarantee.
                if (
                    current_target_exists
                    and old_lib_path.startswith(f"{base}/library/")
                ):
                    continue
                if current_target_exists and old_lib_path.startswith("library/"):
                    # Vault-relative without kb prefix — caller-side variant.
                    # Treat as canonical; skip.
                    continue

                # Find the actual file by filename in this KB's library/
                actual_in_lib = file_index.get(lib_filename)
                if not actual_in_lib:
                    # Phantom AND no match found — record for user awareness
                    # but don't error. The file may have been deleted from
                    # library/ entirely.
                    unresolved.append({
                        "kb": kb_slug,
                        "path": rel,
                        "title": str(meta.get("title") or sf.stem),
                        "old_library_path": old_lib_path,
                        "filename_searched": lib_filename,
                    })
                    continue

                # Compute new vault-relative absolute library_path
                new_lib_path = f"{base}/library/{actual_in_lib}"
                if new_lib_path == old_lib_path:
                    continue  # already in canonical form (just verifying)

                rewrite = {
                    "kb": kb_slug,
                    "path": rel,
                    "title": str(meta.get("title") or sf.stem),
                    "old_library_path": old_lib_path,
                    "new_library_path": new_lib_path,
                    "current_target_exists": current_target_exists,
                }

                if dry_run:
                    rewrites_pending.append(rewrite)
                    continue

                # Apply the rewrite via update_article (contract-gated, versioned).
                # Slug fallback uses the slug-form (see _filename_stem_to_slug)
                # so legacy files without an explicit frontmatter `slug:`
                # field still resolve.
                try:
                    self.update_article(
                        meta.get("slug") or self._filename_stem_to_slug(sf.stem),
                        None,
                        {"library_path": new_lib_path},
                    )
                    rewrites_applied.append(rewrite)
                except Exception as exc:
                    errors.append({
                        "path": rel,
                        "error": f"update_article: {exc}",
                        **rewrite,
                    })

        # Activity event
        try:
            _activity = getattr(self, "_activity", None)
            if _activity:
                await _activity.log(
                    category="knowledge",
                    action=(
                        "kb_library_paths_repaired" if not dry_run
                        else "kb_library_paths_scanned"
                    ),
                    summary=(
                        f"Scanned {scanned}, "
                        f"{'pending ' + str(len(rewrites_pending)) if dry_run else 'applied ' + str(len(rewrites_applied))}, "
                        f"unresolved {len(unresolved)}, errors {len(errors)}"
                    ),
                    details={
                        "scanned": scanned,
                        "rewrites_pending": len(rewrites_pending),
                        "rewrites_applied": len(rewrites_applied),
                        "unresolved": len(unresolved),
                        "errors": len(errors),
                        "dry_run": dry_run,
                    },
                    importance="medium",
                )
        except Exception:
            pass

        return {
            "scanned": scanned,
            "rewrites_pending": len(rewrites_pending) if dry_run else 0,
            "rewrites_applied": len(rewrites_applied) if not dry_run else 0,
            "unresolved_count": len(unresolved),
            "errors": len(errors),
            "dry_run": dry_run,
            "applied": rewrites_applied if not dry_run else [],
            "pending": rewrites_pending if dry_run else [],
            "unresolved": unresolved,
            "error_details": errors,
        }

    async def rewrite_taxonomy_path_legacy_l1(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = True,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Rewrite frontmatter ``taxonomy_path: <legacy>/...`` → canonical
        L1 slug for each entry in ``kb.taxonomy.LEGACY_L1_ALIASES``.

        Runs as Phase 0.5 of ``migrate_to_taxonomy`` — between Phase 0
        (entity_type rename) and Phase 1 (repair_classifications). Pure
        frontmatter rewrite, no LLM, no path moves. Phase 4
        (``migrate_wiki_articles``) handles the physical folder moves
        once frontmatter is canonical.

        Currently maps:
          - ``sources/...`` → ``digests/...`` (2026-04-27 L1 rename)

        Idempotent — articles already at canonical L1 are skipped.
        """
        if dry_run:
            return await self._do_rewrite_taxonomy_path_legacy_l1(slug, dry_run=True, progress=progress)
        async with self._scoped_pipeline(
            "kb_rewrite_taxonomy_path_legacy_l1", scope_prefix="rewrite-tax-l1",
        ):
            return await self._do_rewrite_taxonomy_path_legacy_l1(slug, dry_run=False, progress=progress)

    async def _do_rewrite_taxonomy_path_legacy_l1(
        self,
        slug: str | None,
        *,
        dry_run: bool,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Implementation. See public wrapper for docstring."""
        import asyncio as _asyncio

        from agntspace.infra.job_registry import ProgressHandle
        from agntspace.kb.taxonomy import LEGACY_L1_ALIASES
        progress = progress or ProgressHandle.detached()

        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        scanned = 0
        rewrites_pending: list[dict] = []
        rewrites_applied: list[dict] = []
        errors: list[dict] = []

        # Pre-walk for total count.
        _total = 0
        for _ks in kbs:
            try:
                _total += len(self._reader.list_files(f"knowledge/{_ks}/wiki", "**/*.md"))
            except Exception:
                pass
        progress.set_total(_total)
        progress.set_processed(0)

        _YIELD_EVERY = 1
        _processed_idx = 0
        _cancelled = False

        for kb_slug in kbs:
            if _cancelled:
                break
            base = f"knowledge/{kb_slug}"
            try:
                wiki_files = self._reader.list_files(f"{base}/wiki", "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files: {exc}"})
                continue

            for wf in wiki_files:
                if _processed_idx % _YIELD_EVERY == 0:
                    if progress.cancelled():
                        _cancelled = True
                        break
                    await _asyncio.sleep(0)
                _processed_idx += 1
                progress.tick()

                name = wf.name
                if name.startswith("_") or name.startswith("."):
                    continue
                path_str = str(wf).replace("\\", "/")
                if "/.history/" in path_str or "/.archives/" in path_str or "/.quarantine/" in path_str:
                    continue

                try:
                    rel = self._to_logical(wf)
                except Exception:
                    continue

                scanned += 1
                try:
                    doc = self._reader.read(rel)
                except Exception as exc:
                    errors.append({"path": rel, "error": f"read: {exc}"})
                    continue

                meta = doc.metadata or {}
                tax_path = str(meta.get("taxonomy_path") or "").strip()

                # Two paths to a rewrite:
                #   (a) taxonomy_path is set + starts with a legacy L1 →
                #       rewrite the L1 segment, keep the tail.
                #   (b) taxonomy_path is empty/missing AND the on-disk path
                #       lives under a legacy bucket → infer taxonomy_path
                #       from the path so Phase 4 can move the article to
                #       its v3 location.
                if tax_path:
                    head = tax_path.split("/", 1)[0]
                    tail = tax_path[len(head):]  # includes leading "/" if any
                    new_l1 = LEGACY_L1_ALIASES.get(head)
                    if not new_l1:
                        continue  # already canonical, or unrelated path
                    new_tax_path = new_l1 + tail
                else:
                    # Path-based inference for legacy on-disk articles that
                    # never got a taxonomy_path frontmatter field.
                    rel_path_str = str(rel).replace("\\", "/")
                    wiki_marker = f"knowledge/{kb_slug}/wiki/"
                    if wiki_marker not in rel_path_str:
                        continue
                    wiki_rel = rel_path_str.split(wiki_marker, 1)[1]
                    # Drop the filename — keep only the directory chain.
                    if "/" not in wiki_rel:
                        continue  # bare-file at wiki root — not legacy-bucketed
                    dir_chain = wiki_rel.rsplit("/", 1)[0]
                    head = dir_chain.split("/", 1)[0]
                    new_l1 = LEGACY_L1_ALIASES.get(head)
                    if not new_l1:
                        continue  # path already starts with a v3 L1 — leave alone
                    tail = dir_chain[len(head):]  # includes leading "/" if any
                    new_tax_path = new_l1 + tail
                    if not new_tax_path or "/" not in new_tax_path:
                        # Phase 4 requires a multi-segment taxonomy_path.
                        new_tax_path = new_tax_path + "/general"
                rewrite = {
                    "kb": kb_slug,
                    "path": rel,
                    "title": str(meta.get("title") or wf.stem),
                    "old_taxonomy_path": tax_path,
                    "new_taxonomy_path": new_tax_path,
                }

                if dry_run:
                    rewrites_pending.append(rewrite)
                    continue

                try:
                    self.update_article(
                        meta.get("slug") or self._filename_stem_to_slug(wf.stem),
                        None,
                        {"taxonomy_path": new_tax_path},
                    )
                    rewrites_applied.append(rewrite)
                except Exception as exc:
                    errors.append({
                        "path": rel,
                        "error": f"update_article: {exc}",
                        **rewrite,
                    })

        try:
            _activity = getattr(self, "_activity", None)
            if _activity:
                await _activity.log(
                    category="knowledge",
                    action=(
                        "kb_taxonomy_path_l1_rewritten" if not dry_run
                        else "kb_taxonomy_path_l1_scanned"
                    ),
                    summary=(
                        f"Scanned {scanned}, "
                        f"{'pending ' + str(len(rewrites_pending)) if dry_run else 'applied ' + str(len(rewrites_applied))}, "
                        f"errors {len(errors)}"
                    ),
                    details={
                        "scanned": scanned,
                        "rewrites_pending": len(rewrites_pending),
                        "rewrites_applied": len(rewrites_applied),
                        "errors": len(errors),
                        "dry_run": dry_run,
                    },
                    importance="medium",
                )
        except Exception:
            pass

        return {
            "scanned": scanned,
            "rewrites_pending": len(rewrites_pending) if dry_run else 0,
            "rewrites_applied": len(rewrites_applied) if not dry_run else 0,
            "errors": len(errors),
            "dry_run": dry_run,
            "applied": rewrites_applied if not dry_run else [],
            "pending": rewrites_pending if dry_run else [],
            "error_details": errors,
        }

    async def rename_source_summary_to_digest(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = True,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Public entry point — wraps body in ``_scoped_pipeline``. See
        ``_do_rename_source_summary_to_digest``.

        Sweep every wiki article and rewrite frontmatter
        ``entity_type: source_summary`` → ``entity_type: digest``. Pure
        frontmatter rewrite, no LLM, no path moves. Runs as Phase 0 of
        the migration orchestrator (before ``repair_classifications``)
        so subsequent phases see the new entity_type value.

        Idempotent — articles already at ``entity_type: digest`` are
        skipped.

        Closes the entity_type rename component of scope-1b
        (2026-04-27 evening finalization).
        """
        if dry_run:
            return await self._do_rename_source_summary_to_digest(slug, dry_run=True, progress=progress)
        async with self._scoped_pipeline(
            "kb_rename_source_summary_to_digest", scope_prefix="rename-digest"
        ):
            return await self._do_rename_source_summary_to_digest(slug, dry_run=False, progress=progress)

    async def _do_rename_source_summary_to_digest(
        self,
        slug: str | None,
        *,
        dry_run: bool,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Implementation. See public wrapper for docstring."""
        import asyncio as _asyncio

        from agntspace.infra.job_registry import ProgressHandle
        progress = progress or ProgressHandle.detached()

        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        scanned = 0
        renames_pending: list[dict] = []
        renames_applied: list[dict] = []
        errors: list[dict] = []

        # Pre-walk all KBs to count files for the progress bar — cheap
        # because list_files is a glob, not an LLM call.
        all_files: list[tuple[str, Path]] = []
        for kb_slug in kbs:
            base = f"knowledge/{kb_slug}"
            try:
                wiki_files = self._reader.list_files(f"{base}/wiki", "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files: {exc}"})
                continue
            for wf in wiki_files:
                all_files.append((kb_slug, wf))
        progress.set_total(len(all_files))
        progress.set_processed(0)

        # Yield every N items so /api/health, /api/jobs/{id}, and
        # DELETE /api/jobs/{id} (cancel) can land between batches.
        # 25 keeps the cooperative-cancel response p99 below ~300ms on
        # a fast disk; lower would yield more often but slow throughput.
        # Yield every item — see analogous comment in
        # _do_repair_classifications. Per-item sleep(0) is microseconds,
        # while sync-I/O blocking accumulates linearly. Per-25-item
        # yields meant /api/health and DELETE /api/jobs/{id} were
        # unreachable during long apply runs. Per-item yield closes
        # that with negligible overhead.
        _YIELD_EVERY = 1

        for idx, (kb_slug, wf) in enumerate(all_files):
            if idx % _YIELD_EVERY == 0:
                if progress.cancelled():
                    break
                await _asyncio.sleep(0)

            progress.tick()
            name = wf.name
            if name.startswith("_") or name.startswith("."):
                continue
            path_str = str(wf).replace("\\", "/")
            if (
                "/.history/" in path_str
                or "/.archives/" in path_str
                or "/.quarantine/" in path_str
            ):
                continue

            try:
                rel = self._to_logical(wf)
            except Exception:
                continue

            scanned += 1
            try:
                doc = self._reader.read(rel)
            except Exception as exc:
                errors.append({"path": rel, "error": f"read: {exc}"})
                continue

            meta = doc.metadata or {}
            etype = str(meta.get("entity_type") or "").strip()
            current_title = str(meta.get("title") or wf.stem)

            # Two changes can be needed:
            #   (a) entity_type rewrite (source_summary → digest)
            #   (b) title prefix rewrite (Source: ... → Digest: ...)
            # Source-summary template predates the digest rename, so legacy
            # articles still carry the misleading "Source: <filename>" title
            # even after their entity_type is fixed. Backfill both in one
            # phase. Idempotent: an article that's already digest AND has a
            # Digest: title is skipped entirely.
            needs_etype_fix = etype == "source_summary"
            is_digest_kind = etype in ("source_summary", "digest")
            needs_title_fix = is_digest_kind and current_title.startswith("Source: ")

            if not needs_etype_fix and not needs_title_fix:
                continue  # idempotent: already digest with non-Source title, or different type

            new_title = (
                "Digest: " + current_title[len("Source: "):]
                if needs_title_fix
                else current_title
            )

            rename = {
                "kb": kb_slug,
                "path": rel,
                "title": current_title,
                "new_title": new_title if needs_title_fix else current_title,
                "old_entity_type": etype,
                "new_entity_type": "digest" if needs_etype_fix else etype,
                "fixed_etype": needs_etype_fix,
                "fixed_title": needs_title_fix,
            }

            if dry_run:
                renames_pending.append(rename)
                continue

            try:
                meta_updates: dict = {}
                if needs_etype_fix:
                    meta_updates["entity_type"] = "digest"
                if needs_title_fix:
                    meta_updates["title"] = new_title
                # Slug fallback uses the slug-form (see _filename_stem_to_slug)
                # so legacy files without an explicit frontmatter `slug:`
                # field still resolve. This closes the 143 "Article not
                # found" errors observed during the 2026-04-27 evening 2
                # live-verification run.
                self.update_article(
                    meta.get("slug") or self._filename_stem_to_slug(wf.stem),
                    None,
                    meta_updates,
                )
                renames_applied.append(rename)
            except Exception as exc:
                errors.append({
                    "path": rel,
                    "error": f"update_article: {exc}",
                    **rename,
                })

        try:
            _activity = getattr(self, "_activity", None)
            if _activity:
                await _activity.log(
                    category="knowledge",
                    action=(
                        "kb_source_summary_renamed_to_digest" if not dry_run
                        else "kb_source_summary_rename_scanned"
                    ),
                    summary=(
                        f"Scanned {scanned}, "
                        f"{'pending ' + str(len(renames_pending)) if dry_run else 'applied ' + str(len(renames_applied))}, "
                        f"errors {len(errors)}"
                    ),
                    details={
                        "scanned": scanned,
                        "renames_pending": len(renames_pending),
                        "renames_applied": len(renames_applied),
                        "errors": len(errors),
                        "dry_run": dry_run,
                    },
                    importance="medium",
                )
        except Exception:
            pass

        return {
            "scanned": scanned,
            "renames_pending": len(renames_pending) if dry_run else 0,
            "renames_applied": len(renames_applied) if not dry_run else 0,
            "errors": len(errors),
            "dry_run": dry_run,
            "applied": renames_applied if not dry_run else [],
            "pending": renames_pending if dry_run else [],
            "error_details": errors,
        }

    # Wiki subdirs that DELIBERATELY stay flat after the scope-2 migration
    # (cross-cutting / meta / project-scoped exceptions to the taxonomy spine).
    # arch:deterministic — fixed wiki layout exception list, structural
    # invariant from the 2026-04-27 wiki classification overhaul.
    _WIKI_MIGRATION_EXCEPTIONS: tuple[str, ...] = (  # arch:deterministic — fixed wiki layout exception list, structural invariant from the 2026-04-27 wiki classification overhaul
        "synthesis",
        "decisions",
        "projects",
    )

    @classmethod
    def _is_wiki_migration_exception(cls, wiki_relative: str) -> bool:
        """Return True when this wiki path is in a deliberately-flat subdir."""
        wiki_relative = wiki_relative.lstrip("/")
        if "/" not in wiki_relative:
            return False
        first_segment = wiki_relative.split("/", 1)[0]
        return first_segment in cls._WIKI_MIGRATION_EXCEPTIONS

    @staticmethod
    def _compute_wiki_move(
        rel_path: str,
        taxonomy_path: str,
        kb_slug: str,
    ) -> str | None:
        """Compute the target wiki path for an article being migrated to the
        taxonomy-driven layout.

        Returns the new vault-relative path or ``None`` when migration is
        skipped (empty taxonomy_path, already-correct path, or article in
        a flat-exception subdir).

        **Wiki / library mirror rule (load-bearing user invariant)**: the
        on-disk folder structure under ``wiki/`` MUST match the structure
        under ``library/``. The ``taxonomy_path`` frontmatter field IS the
        on-disk path under both roots:

        - ``taxonomy_path: sources/articles/news`` →
          ``wiki/sources/articles/news/Foo.md`` (mirrors
          ``library/sources/articles/news/foo.pdf``)
        - ``taxonomy_path: entities/organizations/companies`` →
          ``wiki/entities/organizations/companies/Volvo Cars.md``

        The ``wiki/`` vs ``library/`` root distinction marks "summary"
        vs "original" — no other prefix is needed. **Do NOT add a
        ``digests/`` (or any other) prefix to differentiate source
        digests from other articles.** The prior session's "Form B"
        scheme that prepended ``digests/`` for taxonomy paths under
        ``sources/`` was a violation of this rule and was reverted on
        2026-04-27 (memory: ``feedback_wiki_library_mirror.md``).
        """
        if not taxonomy_path or not taxonomy_path.strip():
            return None
        clean_tax = taxonomy_path.strip().strip("/").replace("\\", "/")
        if not clean_tax or "/" not in clean_tax:
            return None

        wiki_prefix = f"knowledge/{kb_slug}/wiki/"
        if not rel_path.startswith(wiki_prefix):
            return None
        wiki_relative = rel_path[len(wiki_prefix):]

        if KnowledgeBaseService._is_wiki_migration_exception(wiki_relative):
            return None

        filename = wiki_relative.rsplit("/", 1)[-1]
        if filename.startswith(".") or filename.startswith("_"):
            return None

        new_path = f"{wiki_prefix}{clean_tax}/{filename}"
        if new_path == rel_path:
            return None
        return new_path

    async def migrate_wiki_articles(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = True,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Public entry point — wraps body in ``_scoped_pipeline``.

        Move wiki articles to ``wiki/{taxonomy_path}/{title}.md`` based on
        their frontmatter taxonomy_path. The scope-2 structure refactor
        from the 2026-04-27 wiki classification overhaul.

        **Run AFTER** ``repair_classifications --apply``,
        ``reorganize_library --execute``, ``repair_library_paths --apply``.

        Skips synthesis/, decisions/, projects/{slug}/ flat-exception
        subdirs. Skips bookkeeping files (`.` / `_` prefix). Idempotent.

        Backlinks (``[[Title]]``) unaffected because filenames stay
        title-based regardless of folder location.
        """
        if dry_run:
            return await self._do_migrate_wiki_articles(slug, dry_run=True, progress=progress)
        async with self._scoped_pipeline(
            "kb_wiki_migration", scope_prefix="wiki-migrate"
        ):
            return await self._do_migrate_wiki_articles(slug, dry_run=False, progress=progress)

    async def _do_migrate_wiki_articles(
        self,
        slug: str | None,
        *,
        dry_run: bool,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Implementation. See public wrapper for docstring."""
        import asyncio as _asyncio
        import shutil

        from agntspace.infra.job_registry import ProgressHandle
        progress = progress or ProgressHandle.detached()

        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        scanned = 0
        moves_pending: list[dict] = []
        moves_applied: list[dict] = []
        skipped: list[dict] = []
        collisions: list[dict] = []
        errors: list[dict] = []

        # Pre-walk for total — cheap.
        _total = 0
        for _ks in kbs:
            try:
                _total += len(self._reader.list_files(
                    f"knowledge/{_ks}/wiki", "**/*.md",
                ))
            except Exception:
                pass
        progress.set_total(_total)
        progress.set_processed(0)

        # Yield every item — see analogous comment in
        # _do_repair_classifications. Per-item sleep(0) is microseconds,
        # while sync-I/O blocking accumulates linearly. Per-25-item
        # yields meant /api/health and DELETE /api/jobs/{id} were
        # unreachable during long apply runs. Per-item yield closes
        # that with negligible overhead.
        _YIELD_EVERY = 1
        _processed_idx = 0
        _cancelled = False

        for kb_slug in kbs:
            if _cancelled:
                break
            base = f"knowledge/{kb_slug}"
            wiki_dir_path = f"{base}/wiki"
            try:
                wiki_files = self._reader.list_files(wiki_dir_path, "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files: {exc}"})
                continue

            planned_targets: dict[str, str] = {}

            for wf in wiki_files:
                if _processed_idx % _YIELD_EVERY == 0:
                    if progress.cancelled():
                        _cancelled = True
                        break
                    await _asyncio.sleep(0)
                _processed_idx += 1
                progress.tick()

                name = wf.name
                if name.startswith("_") or name.startswith("."):
                    continue
                path_str = str(wf).replace("\\", "/")
                if (
                    "/.history/" in path_str
                    or "/.archives/" in path_str
                    or "/.quarantine/" in path_str
                ):
                    continue

                try:
                    rel = self._to_logical(wf)
                except Exception:
                    continue

                scanned += 1
                try:
                    doc = self._reader.read(rel)
                except Exception as exc:
                    errors.append({"path": rel, "error": f"read: {exc}"})
                    continue

                meta = doc.metadata or {}
                tax_path = str(meta.get("taxonomy_path") or "").strip()
                title = str(meta.get("title") or wf.stem).strip()

                new_rel = self._compute_wiki_move(rel, tax_path, kb_slug)
                if new_rel is None:
                    if (
                        tax_path
                        and rel.startswith(f"{base}/wiki/")
                        and not self._is_wiki_migration_exception(
                            rel[len(f"{base}/wiki/"):]
                        )
                    ):
                        skipped.append({
                            "kb": kb_slug,
                            "path": rel,
                            "title": title,
                            "taxonomy_path": tax_path,
                            "reason": (
                                "no_deep_taxonomy" if "/" not in tax_path
                                else "already_correct"
                            ),
                        })
                    continue

                if new_rel in planned_targets:
                    collisions.append({
                        "kb": kb_slug,
                        "first_source": planned_targets[new_rel],
                        "second_source": rel,
                        "target": new_rel,
                    })
                    continue
                target_physical = self._resolve(new_rel)
                if (
                    target_physical.exists()
                    and target_physical.resolve() != wf.resolve()
                ):
                    collisions.append({
                        "kb": kb_slug,
                        "source": rel,
                        "target": new_rel,
                        "reason": "target_already_exists",
                    })
                    continue

                planned_targets[new_rel] = rel
                move = {
                    "kb": kb_slug,
                    "path": rel,
                    "title": title,
                    "old_path": rel,
                    "new_path": new_rel,
                    "taxonomy_path": tax_path,
                }

                if dry_run:
                    moves_pending.append(move)
                    continue

                src_physical = wf
                try:
                    target_physical.parent.mkdir(parents=True, exist_ok=True)
                    if target_physical.exists() and target_physical.resolve() != src_physical.resolve():
                        collisions.append({
                            "kb": kb_slug,
                            "source": rel,
                            "target": new_rel,
                            "reason": "race_condition_target_exists",
                        })
                        continue
                    shutil.move(str(src_physical), str(target_physical))

                    src_history_dir = src_physical.parent / ".history"
                    if src_history_dir.is_dir():
                        target_history_dir = target_physical.parent / ".history"
                        target_history_dir.mkdir(parents=True, exist_ok=True)
                        stem = src_physical.stem
                        for hist_file in src_history_dir.glob(f"{stem}_*.md"):
                            try:
                                shutil.move(
                                    str(hist_file),
                                    str(target_history_dir / hist_file.name),
                                )
                            except Exception as exc:
                                log.debug(
                                    "kb migrate: history move failed for %s: %s",
                                    hist_file, exc,
                                )

                    moves_applied.append(move)
                except Exception as exc:
                    errors.append({
                        "path": rel,
                        "error": f"move: {exc}",
                        **move,
                    })

        try:
            _activity = getattr(self, "_activity", None)
            if _activity:
                await _activity.log(
                    category="knowledge",
                    action=(
                        "kb_wiki_migrated" if not dry_run
                        else "kb_wiki_migration_scanned"
                    ),
                    summary=(
                        f"Scanned {scanned}, "
                        f"{'pending ' + str(len(moves_pending)) if dry_run else 'applied ' + str(len(moves_applied))}, "
                        f"collisions {len(collisions)}, errors {len(errors)}"
                    ),
                    details={
                        "scanned": scanned,
                        "moves_pending": len(moves_pending),
                        "moves_applied": len(moves_applied),
                        "skipped": len(skipped),
                        "collisions": len(collisions),
                        "errors": len(errors),
                        "dry_run": dry_run,
                    },
                    importance="medium",
                )
        except Exception:
            pass

        return {
            "scanned": scanned,
            "moves_pending": len(moves_pending) if dry_run else 0,
            "moves_applied": len(moves_applied) if not dry_run else 0,
            "skipped_count": len(skipped),
            "collisions_count": len(collisions),
            "errors": len(errors),
            "dry_run": dry_run,
            "applied": moves_applied if not dry_run else [],
            "pending": moves_pending if dry_run else [],
            "skipped": skipped,
            "collisions": collisions,
            "error_details": errors,
        }

    # ── Phase 5: rename default KB folder (general → main) ───────────

    async def rename_default_kb_folder(
        self,
        *,
        legacy_slug: str = "general",
        new_slug: str = "main",
        dry_run: bool = True,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """One-shot vault-level rename — ``agntspace-knowledge/general/``
        → ``agntspace-knowledge/main/`` — plus all reference updates that
        depend on the slug:

          1. Physical folder rename via ``Path.rename``.
          2. ``linked_kbs: [..., "general", ...]`` → ``[..., "main", ...]``
             in every ``agntspace-projects/<slug>/PROJECT.md`` frontmatter.
          3. Bibliography entries with ``kb_slug == legacy_slug`` →
             ``kb_slug == new_slug``.
          4. ``.compile-state.json`` string sweep — any vault path
             reference containing ``knowledge/<legacy_slug>/`` rewritten
             to ``knowledge/<new_slug>/`` (defensive — most internal
             paths are KB-relative and need no change).

        Idempotent shapes:
          - If ``main/`` already exists AND ``general/`` does NOT →
            return ``{"skipped": "already_renamed"}`` (no-op).
          - If neither exists → return ``{"skipped": "no_legacy_folder"}``
            (no-op, fresh vault).
          - If both exist → return ``{"error": "both_folders_present"}``
            (refuse — user must resolve manually).

        Runs as Phase 5 of ``migrate_to_taxonomy`` — AFTER all wiki
        article moves finish (so the rename doesn't break paths
        mid-flight). Subsequent runs see only ``main/`` and no-op.
        """
        if dry_run:
            return await self._do_rename_default_kb_folder(
                legacy_slug=legacy_slug, new_slug=new_slug,
                dry_run=True, progress=progress,
            )
        async with self._scoped_pipeline(
            "kb_rename_default_folder", scope_prefix="rename-default-kb",
        ):
            return await self._do_rename_default_kb_folder(
                legacy_slug=legacy_slug, new_slug=new_slug,
                dry_run=False, progress=progress,
            )

    async def _do_rename_default_kb_folder(
        self,
        *,
        legacy_slug: str,
        new_slug: str,
        dry_run: bool,
        progress: ProgressHandle | None,
    ) -> dict:
        """Implementation. See public wrapper for docstring."""
        import asyncio as _asyncio
        import json as _json

        from agntspace.infra.job_registry import ProgressHandle
        progress = progress or ProgressHandle.detached()

        # Resolve physical paths to both folders.
        try:
            legacy_dir = self._resolve(f"knowledge/{legacy_slug}")
            new_dir = self._resolve(f"knowledge/{new_slug}")
        except Exception as exc:
            return {
                "scanned": 0,
                "renames_pending": 0,
                "renames_applied": 0,
                "errors": 1,
                "dry_run": dry_run,
                "error": f"resolve: {exc}",
            }

        legacy_exists = legacy_dir.is_dir()
        new_exists = new_dir.is_dir()

        # Idempotency / safety branches.
        if not legacy_exists and not new_exists:
            return {
                "scanned": 0,
                "renames_pending": 0,
                "renames_applied": 0,
                "errors": 0,
                "dry_run": dry_run,
                "skipped": "no_legacy_folder",
                "legacy_slug": legacy_slug,
                "new_slug": new_slug,
            }
        if not legacy_exists and new_exists:
            return {
                "scanned": 0,
                "renames_pending": 0,
                "renames_applied": 0,
                "errors": 0,
                "dry_run": dry_run,
                "skipped": "already_renamed",
                "legacy_slug": legacy_slug,
                "new_slug": new_slug,
            }
        if legacy_exists and new_exists:
            return {
                "scanned": 0,
                "renames_pending": 0,
                "renames_applied": 0,
                "errors": 1,
                "dry_run": dry_run,
                "error": "both_folders_present",
                "legacy_slug": legacy_slug,
                "new_slug": new_slug,
            }

        # Pre-walk: count what we'd touch (folder + projects + bibliography
        # entries + compile-state files). Pure scan, no writes.
        projects_to_update: list[tuple[str, list[str]]] = []
        try:
            projects_dir = self._resolve("projects")
        except Exception:
            projects_dir = None

        if projects_dir and projects_dir.is_dir():
            for child in sorted(projects_dir.iterdir()):
                if not child.is_dir():
                    continue
                project_md = child / "PROJECT.md"
                if not project_md.is_file():
                    continue
                try:
                    doc = self._reader.read(f"projects/{child.name}/PROJECT.md")
                except Exception:
                    continue
                linked = (doc.metadata or {}).get("linked_kbs") or []
                if isinstance(linked, list) and legacy_slug in linked:
                    projects_to_update.append((child.name, list(linked)))

        # Bibliography entries.
        biblio_count = 0
        try:
            biblio_doc = self._reader.read("knowledge/bibliography.json")
            biblio_entries = (
                _json.loads(biblio_doc.content) if biblio_doc.content.strip() else []
            )
            for e in biblio_entries:
                if e.get("kb_slug") == legacy_slug:
                    biblio_count += 1
        except Exception:
            biblio_entries = []

        # Compile-state files inside legacy_dir that may carry slug strings.
        compile_state_path = legacy_dir / ".compile-state.json"
        compile_state_needs_rewrite = False
        if compile_state_path.is_file():
            try:
                raw = compile_state_path.read_text(encoding="utf-8")
                if (
                    f"knowledge/{legacy_slug}/" in raw
                    or f"agntspace-knowledge/{legacy_slug}/" in raw
                ):
                    compile_state_needs_rewrite = True
            except Exception:
                pass

        plan = {
            "folder_rename": f"{legacy_slug} → {new_slug}",
            "projects_with_linked_kb": [name for name, _ in projects_to_update],
            "bibliography_entries_to_rewrite": biblio_count,
            "compile_state_needs_rewrite": compile_state_needs_rewrite,
        }
        progress.set_total(1 + len(projects_to_update) + (1 if biblio_count else 0))
        progress.set_processed(0)

        if dry_run:
            return {
                "scanned": 1,
                "renames_pending": 1,
                "renames_applied": 0,
                "errors": 0,
                "dry_run": True,
                "plan": plan,
                "legacy_slug": legacy_slug,
                "new_slug": new_slug,
            }

        # ── apply ──
        errors: list[dict] = []
        applied: dict = {"projects_updated": [], "bibliography_updated": 0}

        # 1. Physical folder rename.
        try:
            legacy_dir.rename(new_dir)
            progress.tick()
            applied["folder_renamed"] = True
        except Exception as exc:
            return {
                "scanned": 1,
                "renames_pending": 0,
                "renames_applied": 0,
                "errors": 1,
                "dry_run": False,
                "error": f"folder_rename: {exc}",
                "legacy_slug": legacy_slug,
                "new_slug": new_slug,
            }
        await _asyncio.sleep(0)

        # 2. PROJECT.md linked_kbs rewrites.
        for proj_slug, linked in projects_to_update:
            try:
                if progress.cancelled():
                    break
                new_linked = [
                    new_slug if k == legacy_slug else k for k in linked
                ]
                # de-dup if both legacy + new were present (defensive)
                seen: set[str] = set()
                new_linked = [k for k in new_linked if not (k in seen or seen.add(k))]
                self._update_project_linked_kbs(proj_slug, new_linked)
                applied["projects_updated"].append(proj_slug)
                progress.tick()
            except Exception as exc:
                errors.append({
                    "project": proj_slug,
                    "error": f"update_linked_kbs: {exc}",
                })
            await _asyncio.sleep(0)

        # 3. Bibliography rewrite.
        if biblio_count:
            try:
                biblio_changed = False
                for e in biblio_entries:
                    if e.get("kb_slug") == legacy_slug:
                        e["kb_slug"] = new_slug
                        biblio_changed = True
                if biblio_changed:
                    self._writer.write(
                        "knowledge/bibliography.json",
                        _json.dumps(biblio_entries, indent=2, ensure_ascii=False),
                        contract_action="modify_wiki",
                    )
                    applied["bibliography_updated"] = biblio_count
                progress.tick()
            except Exception as exc:
                errors.append({
                    "bibliography": "knowledge/bibliography.json",
                    "error": f"rewrite: {exc}",
                })

        # 4. .compile-state.json string sweep — folder is already at new_dir.
        new_compile_state = new_dir / ".compile-state.json"
        if compile_state_needs_rewrite and new_compile_state.is_file():
            try:
                raw = new_compile_state.read_text(encoding="utf-8")
                rewritten = raw.replace(
                    f"knowledge/{legacy_slug}/", f"knowledge/{new_slug}/",
                ).replace(
                    f"agntspace-knowledge/{legacy_slug}/",
                    f"agntspace-knowledge/{new_slug}/",
                )
                if rewritten != raw:
                    new_compile_state.write_text(rewritten, encoding="utf-8")
                    applied["compile_state_rewritten"] = True
            except Exception as exc:
                errors.append({
                    "compile_state": str(new_compile_state),
                    "error": f"rewrite: {exc}",
                })

        # Activity event — high importance because this is a one-shot
        # vault structural change with cross-cutting impact.
        try:
            _activity = getattr(self, "_activity", None)
            if _activity:
                await _activity.log(
                    category="knowledge",
                    action="kb_default_folder_renamed",
                    summary=(
                        f"Renamed {legacy_slug} → {new_slug}. "
                        f"Projects updated: {len(applied['projects_updated'])}. "
                        f"Bibliography entries: {applied['bibliography_updated']}. "
                        f"Errors: {len(errors)}."
                    ),
                    details={
                        "legacy_slug": legacy_slug,
                        "new_slug": new_slug,
                        "projects_updated": applied["projects_updated"],
                        "bibliography_updated": applied["bibliography_updated"],
                        "compile_state_rewritten": applied.get(
                            "compile_state_rewritten", False,
                        ),
                        "errors": len(errors),
                    },
                    importance="high",
                )
        except Exception:
            pass

        # arch:short-ttl-cache (Phase 0.1) — slug changed at the folder
        # level; drop cache so the next read shows the new slug.
        self.invalidate_kb_list_cache()
        return {
            "scanned": 1,
            "renames_pending": 0,
            "renames_applied": 1 if not errors else 0,
            "errors": len(errors),
            "dry_run": False,
            "plan": plan,
            "applied": applied,
            "error_details": errors,
            "legacy_slug": legacy_slug,
            "new_slug": new_slug,
        }

    def _update_project_linked_kbs(self, slug: str, new_linked: list[str]) -> None:
        """Surgical PROJECT.md frontmatter rewrite for ``linked_kbs``.

        Standalone helper rather than calling ``ProjectService.update_project``
        because the migration runs in a process where ``ProjectService`` may
        not be wired (CLI dry-runs, tests). Reads the file, rewrites the
        ``linked_kbs:`` line in frontmatter, writes back. Authorized via
        the surrounding ``_scoped_pipeline`` ``trusted_scope``.
        """
        import re as _re

        import yaml as _yaml

        path = f"projects/{slug}/PROJECT.md"
        doc = self._reader.read(path)
        content = doc.raw or ""

        # Format: ``linked_kbs: ["a", "b"]`` on one line, or block-style.
        # Use yaml.safe_dump to produce a one-line flow style that matches
        # ``ProjectService._to_yaml_list`` so re-reads parse cleanly.
        formatted = _yaml.safe_dump(
            new_linked, default_flow_style=True,
        ).strip()
        # Remove trailing newline/empty bracket inconsistencies.
        if formatted == "[]":
            replacement = "linked_kbs: []"
        else:
            replacement = f"linked_kbs: {formatted}"

        new_content, n = _re.subn(
            r"^linked_kbs:\s*.*$",
            replacement,
            content,
            count=1,
            flags=_re.MULTILINE,
        )
        if n == 0:
            # No linked_kbs field present — defensive, just no-op.
            return
        if new_content == content:
            return  # nothing to write
        # Authorized by the surrounding ``_scoped_pipeline`` ``trusted_scope``
        # — internal bookkeeping write tied to the user's already-authorized
        # default-folder rename. Passing an explicit contract_action here
        # would conflict with the scope's authorized-actions set
        # (``modify_project`` isn't on the kb-rename scope).
        self._writer.write(path, new_content, trust_reason="kb_rename_default_folder")

    # ── Phase 6: project base scaffolding + notes migration ──────────

    async def migrate_project_bases(
        self,
        *,
        dry_run: bool = True,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Sweep every ``agntspace-projects/<slug>/`` to (a) ensure the
        v3 wikized scaffolding exists (``wiki/``, ``library/``,
        ``inbox/``, plus a ``.gitkeep`` placeholder per Stage B), and
        (b) move legacy ``notes/*.md`` files into the project's
        ``inbox/`` as ``note-{stem}.md`` so they're queued for the
        classify pipeline (which lands them in the project's
        ``wiki/{taxonomy_path}/`` once project-base ingest is wired —
        for now, holding pattern preserves the data in the right
        physical location).

        Behaviour:
          - Each project independent — failure on one doesn't block
            others.
          - Idempotent: re-running on a fully-scaffolded project is a
            no-op. Notes that already collide with an inbox filename
            get a numeric suffix (``note-<stem>-1.md``) rather than
            being silently overwritten.
          - Empty ``notes/`` directories are removed after migration.

        Runs as Phase 6 of ``migrate_to_taxonomy`` — AFTER Phase 5's
        folder rename (so the working slug set is canonical).
        """
        if dry_run:
            return await self._do_migrate_project_bases(dry_run=True, progress=progress)
        async with self._scoped_pipeline(
            "kb_migrate_project_bases", scope_prefix="migrate-projects",
        ):
            return await self._do_migrate_project_bases(
                dry_run=False, progress=progress,
            )

    async def _do_migrate_project_bases(
        self,
        *,
        dry_run: bool,
        progress: ProgressHandle | None,
    ) -> dict:
        """Implementation. See public wrapper for docstring."""
        import asyncio as _asyncio
        import shutil as _shutil

        from agntspace.infra.job_registry import ProgressHandle
        progress = progress or ProgressHandle.detached()

        try:
            projects_dir = self._resolve("projects")
        except Exception as exc:
            return {
                "scanned": 0,
                "scaffolded_pending": 0,
                "scaffolded_applied": 0,
                "notes_moved_pending": 0,
                "notes_moved_applied": 0,
                "errors": 1,
                "dry_run": dry_run,
                "error": f"resolve: {exc}",
            }

        if not projects_dir.is_dir():
            return {
                "scanned": 0,
                "scaffolded_pending": 0,
                "scaffolded_applied": 0,
                "notes_moved_pending": 0,
                "notes_moved_applied": 0,
                "errors": 0,
                "dry_run": dry_run,
                "skipped": "no_projects_directory",
            }

        REQUIRED_SUBDIRS = ("wiki", "library", "inbox")
        scanned = 0
        scaffolded_pending: list[dict] = []
        scaffolded_applied: list[dict] = []
        notes_pending: list[dict] = []
        notes_applied: list[dict] = []
        errors: list[dict] = []

        project_dirs = [p for p in sorted(projects_dir.iterdir()) if p.is_dir()]

        # Pre-walk for total count: 1 per project (scaffolding) + 1 per note.
        _total = 0
        for p in project_dirs:
            _total += 1  # scaffolding step
            notes_dir = p / "notes"
            if notes_dir.is_dir():
                _total += sum(
                    1 for f in notes_dir.iterdir()
                    if f.is_file() and f.suffix.lower() in (".md", ".markdown")
                )
        progress.set_total(_total)
        progress.set_processed(0)

        for project_dir in project_dirs:
            if progress.cancelled():
                break
            slug = project_dir.name
            project_md = project_dir / "PROJECT.md"
            if not project_md.is_file():
                # Not a real project — skip.
                progress.tick()
                continue
            scanned += 1

            # ── Scaffolding ──
            missing = [s for s in REQUIRED_SUBDIRS if not (project_dir / s).is_dir()]
            if missing:
                if dry_run:
                    scaffolded_pending.append({
                        "project": slug,
                        "missing": missing,
                    })
                else:
                    try:
                        for sub in missing:
                            sub_dir = project_dir / sub
                            sub_dir.mkdir(parents=True, exist_ok=True)
                            gitkeep = sub_dir / ".gitkeep"
                            if not gitkeep.is_file():
                                gitkeep.write_text("", encoding="utf-8")
                        scaffolded_applied.append({
                            "project": slug,
                            "created": missing,
                        })
                    except Exception as exc:
                        errors.append({
                            "project": slug,
                            "phase": "scaffold",
                            "error": str(exc),
                        })
            progress.tick()
            await _asyncio.sleep(0)

            # ── Notes migration ──
            notes_dir = project_dir / "notes"
            inbox_dir = project_dir / "inbox"
            if notes_dir.is_dir():
                note_files = [
                    f for f in sorted(notes_dir.iterdir())
                    if f.is_file() and f.suffix.lower() in (".md", ".markdown")
                ]
                for note_file in note_files:
                    if progress.cancelled():
                        break
                    target_name = f"note-{note_file.stem}.md"
                    target_path = inbox_dir / target_name
                    # Idempotency: avoid overwrite collisions.
                    if target_path.exists():
                        # Already migrated OR collision — generate suffix.
                        suffix = 1
                        while True:
                            alt = inbox_dir / f"note-{note_file.stem}-{suffix}.md"
                            if not alt.exists():
                                target_path = alt
                                break
                            suffix += 1

                    if dry_run:
                        notes_pending.append({
                            "project": slug,
                            "from": str(note_file.relative_to(project_dir)),
                            "to": str(target_path.relative_to(project_dir)),
                        })
                    else:
                        try:
                            # Ensure inbox/ exists (scaffolding above
                            # should have created it; defensive).
                            inbox_dir.mkdir(parents=True, exist_ok=True)
                            _shutil.move(str(note_file), str(target_path))
                            notes_applied.append({
                                "project": slug,
                                "from": str(note_file.name),
                                "to": str(target_path.name),
                            })
                        except Exception as exc:
                            errors.append({
                                "project": slug,
                                "phase": "notes",
                                "file": note_file.name,
                                "error": str(exc),
                            })
                    progress.tick()
                    await _asyncio.sleep(0)

                # Clean up empty notes/ dir post-migration (apply only).
                if not dry_run:
                    try:
                        remaining = [f for f in notes_dir.iterdir() if f.name != ".gitkeep"]
                        if not remaining:
                            # Remove .gitkeep if present, then remove dir.
                            gitkeep = notes_dir / ".gitkeep"
                            if gitkeep.is_file():
                                gitkeep.unlink()
                            try:
                                notes_dir.rmdir()
                            except OSError:
                                pass  # not empty (maybe a non-md leftover)
                    except Exception:
                        pass

        # Activity event.
        try:
            _activity = getattr(self, "_activity", None)
            if _activity:
                await _activity.log(
                    category="knowledge",
                    action=(
                        "project_bases_migrated" if not dry_run
                        else "project_bases_scanned"
                    ),
                    summary=(
                        f"Scanned {scanned} projects, "
                        f"{'scaffolded ' + str(len(scaffolded_pending)) + ' missing dirs' if dry_run else 'scaffolded ' + str(len(scaffolded_applied)) + ' projects'}, "
                        f"{'notes pending ' + str(len(notes_pending)) if dry_run else 'notes moved ' + str(len(notes_applied))}, "
                        f"errors {len(errors)}."
                    ),
                    details={
                        "scanned": scanned,
                        "scaffolded_pending": len(scaffolded_pending),
                        "scaffolded_applied": len(scaffolded_applied),
                        "notes_pending": len(notes_pending),
                        "notes_applied": len(notes_applied),
                        "errors": len(errors),
                        "dry_run": dry_run,
                    },
                    importance="medium",
                )
        except Exception:
            pass

        return {
            "scanned": scanned,
            "scaffolded_pending": len(scaffolded_pending) if dry_run else 0,
            "scaffolded_applied": len(scaffolded_applied) if not dry_run else 0,
            "notes_moved_pending": len(notes_pending) if dry_run else 0,
            "notes_moved_applied": len(notes_applied) if not dry_run else 0,
            "errors": len(errors),
            "dry_run": dry_run,
            "scaffold_pending": scaffolded_pending if dry_run else [],
            "scaffold_applied": scaffolded_applied if not dry_run else [],
            "notes_pending": notes_pending if dry_run else [],
            "notes_applied": notes_applied if not dry_run else [],
            "error_details": errors,
        }

    # ── Phase 7: cleanup legacy wiki directory shells ──────────────

    async def cleanup_legacy_wiki_dirs(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = True,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Remove empty legacy v1/v2 wiki bucket directories after Phase 4
        has moved their content to v3 L1 paths.

        For each entry in ``LEGACY_L1_ALIASES`` (concepts/sources/synthesis/
        decisions/org/places/products), walk the corresponding
        ``wiki/<legacy>/`` tree. If it has ZERO non-``.history`` /
        non-``.archives`` ``.md`` files left, remove the entire dir tree
        (including stale .history/ snapshots — the articles they version
        no longer live at those paths after Phase 4 moved them).

        If a legacy dir still has real article content, leaves it alone
        and reports in the result dict so the user can investigate.

        Idempotent: re-running on a vault with no legacy dirs is a no-op.
        Phase 7 of ``migrate_to_taxonomy``. Always runs LAST so all
        article moves complete first.
        """
        if dry_run:
            return await self._do_cleanup_legacy_wiki_dirs(
                slug, dry_run=True, progress=progress,
            )
        async with self._scoped_pipeline(
            "kb_cleanup_legacy_dirs", scope_prefix="cleanup-legacy",
        ):
            return await self._do_cleanup_legacy_wiki_dirs(
                slug, dry_run=False, progress=progress,
            )

    async def _do_cleanup_legacy_wiki_dirs(
        self,
        slug: str | None,
        *,
        dry_run: bool,
        progress: ProgressHandle | None,
    ) -> dict:
        """Implementation. See public wrapper for docstring."""
        import asyncio as _asyncio
        import shutil as _shutil

        from agntspace.infra.job_registry import ProgressHandle
        from agntspace.kb.taxonomy import LEGACY_L1_ALIASES
        progress = progress or ProgressHandle.detached()

        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        legacy_l1s = sorted(LEGACY_L1_ALIASES.keys())
        progress.set_total(len(kbs) * len(legacy_l1s))
        progress.set_processed(0)

        cleanups_pending: list[dict] = []
        cleanups_applied: list[dict] = []
        skipped_with_content: list[dict] = []
        errors: list[dict] = []
        _processed_idx = 0

        for kb_slug in kbs:
            for legacy in legacy_l1s:
                if progress.cancelled():
                    break
                _processed_idx += 1
                progress.tick()
                if _processed_idx % 1 == 0:
                    await _asyncio.sleep(0)

                try:
                    legacy_dir = self._resolve(f"knowledge/{kb_slug}/wiki/{legacy}")
                except Exception as exc:
                    errors.append({"kb": kb_slug, "legacy": legacy, "error": str(exc)})
                    continue

                if not legacy_dir.is_dir():
                    continue  # already gone

                # Count user-facing .md files (excluding .history/.archives)
                user_md_count = 0
                try:
                    for f in legacy_dir.rglob("*.md"):
                        f_str = str(f).replace("\\", "/")
                        if "/.history/" in f_str or "/.archives/" in f_str:
                            continue
                        user_md_count += 1
                except Exception as exc:
                    errors.append({
                        "kb": kb_slug, "legacy": legacy,
                        "error": f"scan: {exc}",
                    })
                    continue

                entry = {
                    "kb": kb_slug,
                    "legacy_dir": f"knowledge/{kb_slug}/wiki/{legacy}",
                    "user_md_count": user_md_count,
                }

                if user_md_count > 0:
                    skipped_with_content.append(entry)
                    continue

                # Empty (or only .history/.archives) — safe to remove.
                if dry_run:
                    cleanups_pending.append(entry)
                    continue

                try:
                    _shutil.rmtree(legacy_dir)
                    cleanups_applied.append(entry)
                except Exception as exc:
                    errors.append({
                        "kb": kb_slug, "legacy": legacy,
                        "error": f"rmtree: {exc}",
                    })

        # Activity event.
        try:
            _activity = getattr(self, "_activity", None)
            if _activity:
                await _activity.log(
                    category="knowledge",
                    action=(
                        "kb_legacy_dirs_cleaned" if not dry_run
                        else "kb_legacy_dirs_scanned"
                    ),
                    summary=(
                        f"Scanned {len(kbs)} KBs × {len(legacy_l1s)} legacy buckets, "
                        f"{'pending ' + str(len(cleanups_pending)) if dry_run else 'removed ' + str(len(cleanups_applied))}, "
                        f"skipped {len(skipped_with_content)} with content, "
                        f"errors {len(errors)}."
                    ),
                    details={
                        "kbs_scanned": len(kbs),
                        "legacy_buckets_checked": len(legacy_l1s),
                        "cleanups_pending": len(cleanups_pending),
                        "cleanups_applied": len(cleanups_applied),
                        "skipped_with_content": len(skipped_with_content),
                        "errors": len(errors),
                        "dry_run": dry_run,
                    },
                    importance="medium",
                )
        except Exception:
            pass

        return {
            "scanned": len(kbs) * len(legacy_l1s),
            "cleanups_pending": len(cleanups_pending) if dry_run else 0,
            "cleanups_applied": len(cleanups_applied) if not dry_run else 0,
            "skipped_with_content": len(skipped_with_content),
            "errors": len(errors),
            "dry_run": dry_run,
            "pending": cleanups_pending if dry_run else [],
            "applied": cleanups_applied if not dry_run else [],
            "skipped": skipped_with_content,
            "error_details": errors,
        }

    async def migrate_to_taxonomy(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = True,
        use_llm: bool = True,
        limit: int | None = None,
        progress: ProgressHandle | None = None,
    ) -> dict:
        """Single-command orchestrator for the full scope-2 taxonomy
        migration. Runs eight phases sequentially and returns a
        combined report.

        Phases (each idempotent — re-running is safe):
          0. ``rename_source_summary_to_digest`` — entity_type rewrite
             (frontmatter only, no path moves).
          0.5. ``rewrite_taxonomy_path_legacy_l1`` — taxonomy_path L1
             alias rewrite (e.g. ``sources/...`` → ``digests/...``).
          1. ``repair_classifications`` — Problems A + B (entity_type fixes
             + LLM source-deepening for source_summary at L1).
          2. ``reorganize_library`` — physical move of library/ files to
             ``library/{taxonomy_path}/{filename}`` based on the now-correct
             frontmatter.
          3. ``repair_library_paths`` — Problem C (rewrite phantom
             ``library_path`` frontmatter to vault-relative absolute form
             pointing at the actual on-disk file).
          4. ``migrate_wiki_articles`` — physical move of wiki articles to
             ``wiki/{taxonomy_path}/{title}.md`` (scope-2 structure).
          5. ``rename_default_kb_folder`` — one-shot vault rename
             ``agntspace-knowledge/general/`` → ``main/`` (+ ``linked_kbs``
             rewrites in PROJECT.md + bibliography ``kb_slug`` rewrites +
             ``.compile-state.json`` string sweep).
          6. ``migrate_project_bases`` — scaffold every project's missing
             ``wiki/``/``library/``/``inbox/`` and move legacy
             ``notes/*.md`` into the project's ``inbox/`` for future
             classify-pipeline ingestion.

        Args:
            slug: KB slug. None scans every KB (each phase iterates).
                Phases 5+6 are vault-level and ignore the slug.
            dry_run: True (default) → run all dry-runs, return combined
                plan. False → execute all in order.
            use_llm: Forwarded to phase 1. False skips LLM-driven
                reclassification (deterministic only).
            limit: Forwarded to phase 1's LLM call budget cap.
            progress: Optional ``ProgressHandle`` from a JobRegistry job.
                When set, the orchestrator updates ``phase`` between
                phases and increments ``phases_completed`` after each
                phase finishes (out of ``phases_total=8``). Cancellation
                is checked between phases — a cancelled run aborts after
                the current phase finishes, returning the partial report.
                None (default) is the legacy synchronous-call shape.

        Returns:
            ``{dry_run, phases: [{name, result}, ...], summary: {...}}``
            ``summary`` aggregates pending/applied counts + total errors
            across all four phases for a one-glance status.

        **Note:** the four phases ARE intentionally independent in code —
        an error in one doesn't block the next. The next phase will just
        see less to do. This makes the orchestrator robust to partial
        failures and naturally idempotent — you can re-run after fixing
        the underlying issue (e.g. a corrupt source page) and only the
        remaining work happens.
        """
        import asyncio as _asyncio  # local — avoid module-level shadowing

        from agntspace.infra.job_registry import ProgressHandle  # local import to avoid cycle
        progress = progress or ProgressHandle.detached()
        # Phase 2 of the async-job pattern: each sub-phase OWNS its own
        # total/processed/phase counters via the same ProgressHandle.
        # The orchestrator only sets the phase name + checks cancellation
        # between phases. ``details["phases_completed"]`` carries ordinal
        # info ("3 of 5 phases done") for callers that want it.
        progress.update_details(phases_total=9, phases_completed=0)

        phases: list[dict] = []

        # Phase 0 — entity_type rename: source_summary → digest
        # (scope-1b finalization). Pure frontmatter sweep, no LLM.
        # Runs FIRST so all downstream phases see the new entity_type
        # value (Bug class 2b's trigger has been updated to accept
        # both, but new state is canonical).
        progress.set_phase("rename source_summary → digest")
        p0 = await self.rename_source_summary_to_digest(
            slug, dry_run=dry_run, progress=progress,
        )
        phases.append({"name": "rename_source_summary_to_digest", "result": p0})
        progress.update_details(phases_completed=1)
        await _asyncio.sleep(0)

        # If KB not found at phase 0, propagate immediately.
        if "error" in p0:
            return {
                "dry_run": dry_run,
                "phases": phases,
                "summary": {
                    "scanned": 0,
                    "changes_pending": 0,
                    "changes_applied": 0,
                    "errors": 1,
                },
                "error": p0["error"],
            }

        if progress.cancelled():
            return self._migration_cancelled_result(dry_run, phases)

        # Phase 0.5 — taxonomy_path L1 rename (e.g. sources/... → digests/...).
        # Pure frontmatter rewrite. Runs BEFORE repair_classifications so the
        # taxonomy_path values match the new canonical L1 set when classify
        # logic looks them up. No-op for vaults that already canonical.
        progress.set_phase("rewrite legacy L1 in taxonomy_path (sources → digests)")
        p_rewrite = await self.rewrite_taxonomy_path_legacy_l1(
            slug, dry_run=dry_run, progress=progress,
        )
        phases.append({"name": "rewrite_taxonomy_path_legacy_l1", "result": p_rewrite})
        progress.update_details(phases_completed=2)
        await _asyncio.sleep(0)

        if "error" in p_rewrite:
            return {
                "dry_run": dry_run,
                "phases": phases,
                "summary": {
                    "scanned": 0,
                    "changes_pending": 0,
                    "changes_applied": 0,
                    "errors": 1,
                },
                "error": p_rewrite["error"],
            }

        if progress.cancelled():
            return self._migration_cancelled_result(dry_run, phases)

        # Phase 1 — Problems A + B
        progress.set_phase("repair classifications (entity_type + taxonomy_path)")
        p1 = await self.repair_classifications(
            slug, dry_run=dry_run, use_llm=use_llm, limit=limit,
            progress=progress,
        )
        phases.append({"name": "repair_classifications", "result": p1})
        progress.update_details(phases_completed=3)
        await _asyncio.sleep(0)

        # If KB not found at phase 1, propagate immediately. Subsequent
        # phases would just produce noise.
        if "error" in p1:
            return {
                "dry_run": dry_run,
                "phases": phases,
                "summary": {
                    "scanned": 0,
                    "changes_pending": 0,
                    "changes_applied": 0,
                    "errors": 1,
                },
                "error": p1["error"],
            }

        if progress.cancelled():
            return self._migration_cancelled_result(dry_run, phases)

        # Phase 2 — Library file moves
        # ``reorganize_library`` doesn't accept a None slug — it requires
        # a specific KB. When slug is None we iterate ourselves.
        progress.set_phase("reorganize library files by taxonomy")
        if slug is None:
            p2_per_kb: list[dict] = []
            for kb in self.list_kbs():
                p2_kb = await self.reorganize_library(kb["slug"], dry_run=dry_run)
                p2_per_kb.append({"slug": kb["slug"], **p2_kb})
                await _asyncio.sleep(0)  # yield between per-kb runs
            p2 = {"per_kb": p2_per_kb}
        else:
            p2 = await self.reorganize_library(slug, dry_run=dry_run)
        phases.append({"name": "reorganize_library", "result": p2})
        progress.update_details(phases_completed=4)
        await _asyncio.sleep(0)

        if progress.cancelled():
            return self._migration_cancelled_result(dry_run, phases)

        # Phase 3 — Problem C
        progress.set_phase("repair library_path frontmatter")
        p3 = await self.repair_library_paths(slug, dry_run=dry_run, progress=progress)
        phases.append({"name": "repair_library_paths", "result": p3})
        progress.update_details(phases_completed=5)
        await _asyncio.sleep(0)

        if progress.cancelled():
            return self._migration_cancelled_result(dry_run, phases)

        # Phase 4 — Wiki article moves
        progress.set_phase("migrate wiki articles by taxonomy")
        p4 = await self.migrate_wiki_articles(slug, dry_run=dry_run, progress=progress)
        phases.append({"name": "migrate_wiki_articles", "result": p4})
        progress.update_details(phases_completed=6)
        await _asyncio.sleep(0)

        if progress.cancelled():
            return self._migration_cancelled_result(dry_run, phases)

        # Phase 5 — Default KB folder rename (general → main)
        # One-shot vault structural change. Runs LATE so all article-level
        # work above sees the legacy slug name. Idempotent: subsequent runs
        # see only ``main/`` and no-op.
        progress.set_phase("rename default KB folder (general → main)")
        p5 = await self.rename_default_kb_folder(
            dry_run=dry_run, progress=progress,
        )
        phases.append({"name": "rename_default_kb_folder", "result": p5})
        progress.update_details(phases_completed=7)
        await _asyncio.sleep(0)

        if progress.cancelled():
            return self._migration_cancelled_result(dry_run, phases)

        # Phase 6 — Project base scaffolding + notes migration
        # Sweeps every ``agntspace-projects/<slug>/`` to ensure the v3
        # wikized structure (wiki/library/inbox) and migrate any legacy
        # ``notes/*.md`` into the project's ``inbox/``.
        progress.set_phase("migrate project bases (scaffold + notes)")
        p6 = await self.migrate_project_bases(
            dry_run=dry_run, progress=progress,
        )
        phases.append({"name": "migrate_project_bases", "result": p6})
        progress.update_details(phases_completed=8)
        await _asyncio.sleep(0)

        if progress.cancelled():
            return self._migration_cancelled_result(dry_run, phases)

        # Phase 7 — Cleanup legacy wiki directory shells
        # After all article moves complete, walks every legacy v1/v2 L1
        # bucket (concepts/sources/synthesis/decisions/org/places/products)
        # and removes empty ones. Idempotent — re-running on a fully-clean
        # vault is a no-op.
        progress.set_phase("cleanup legacy wiki dirs (concepts/sources/synthesis/decisions/org/places/products)")
        p7 = await self.cleanup_legacy_wiki_dirs(
            slug, dry_run=dry_run, progress=progress,
        )
        phases.append({"name": "cleanup_legacy_wiki_dirs", "result": p7})
        progress.update_details(phases_completed=9)

        # Aggregate stats. Each phase has slightly different field names
        # for "pending"/"applied" — we read them by phase to keep the
        # summary honest.
        def _phase2_count(p2_result: dict, kind: str) -> int:
            """Phase 2 counts depend on slug=None vs single-slug mode."""
            if "per_kb" in p2_result:
                if dry_run:
                    return sum(len(k.get("moves", [])) for k in p2_result["per_kb"])
                return sum(k.get("executed", 0) for k in p2_result["per_kb"])
            if dry_run:
                return len(p2_result.get("moves", []))
            return p2_result.get("executed", 0)

        if dry_run:
            changes_pending = (
                p0.get("renames_pending", 0)
                + p_rewrite.get("rewrites_pending", 0)  # Phase 0.5: taxonomy_path L1 rewrite
                + p1.get("fixes_pending", 0)
                + _phase2_count(p2, "moves")
                + p3.get("rewrites_pending", 0)
                + p4.get("moves_pending", 0)
                + p5.get("renames_pending", 0)  # Phase 5: default KB folder rename
                + p6.get("scaffolded_pending", 0)  # Phase 6: project scaffolding
                + p6.get("notes_moved_pending", 0)
                + p7.get("cleanups_pending", 0)  # Phase 7: legacy dir cleanup
            )
            changes_applied = 0
        else:
            changes_pending = 0
            changes_applied = (
                p0.get("renames_applied", 0)
                + p_rewrite.get("rewrites_applied", 0)  # Phase 0.5
                + p1.get("fixes_applied", 0)
                + _phase2_count(p2, "executed")
                + p3.get("rewrites_applied", 0)
                + p4.get("moves_applied", 0)
                + p5.get("renames_applied", 0)  # Phase 5
                + p6.get("scaffolded_applied", 0)  # Phase 6
                + p6.get("notes_moved_applied", 0)
                + p7.get("cleanups_applied", 0)  # Phase 7
            )

        # Errors — phase 1+3+4 use int counters; phase 2 uses a list per-kb
        # or top-level errors list.
        def _phase_errors(p: dict) -> int:
            errs = p.get("errors")
            if isinstance(errs, int):
                return errs
            if isinstance(errs, list):
                return len(errs)
            if "per_kb" in p:
                total = 0
                for k in p["per_kb"]:
                    e = k.get("errors")
                    if isinstance(e, int):
                        total += e
                    elif isinstance(e, list):
                        total += len(e)
                return total
            return 0

        total_errors = sum(_phase_errors(ph["result"]) for ph in phases)

        # Scanned count: phase 1's "scanned" is the most representative
        # (it walks every wiki article). Phase 4 also walks wiki, but
        # phase 1 is the canonical user-visible "I scanned N articles".
        scanned = p1.get("scanned", 0)

        return {
            "dry_run": dry_run,
            "phases": phases,
            "summary": {
                "scanned": scanned,
                "changes_pending": changes_pending,
                "changes_applied": changes_applied,
                "errors": total_errors,
            },
        }

    @staticmethod
    def _migration_cancelled_result(dry_run: bool, phases: list[dict]) -> dict:
        """Build a partial-result dict when the orchestrator is cancelled
        between phases. Tracks which phases ran so the user can see how
        far the migration got before they pulled the plug. The vault is
        always in a coherent state at this boundary because each phase
        runs to completion before we check for cancel — we never abort
        mid-phase."""
        scanned = 0
        changes_pending = 0
        changes_applied = 0
        for ph in phases:
            r = ph.get("result") or {}
            scanned = max(scanned, r.get("scanned", 0))
            if dry_run:
                changes_pending += (
                    r.get("renames_pending", 0)
                    + r.get("fixes_pending", 0)
                    + r.get("rewrites_pending", 0)
                    + r.get("moves_pending", 0)
                )
            else:
                changes_applied += (
                    r.get("renames_applied", 0)
                    + r.get("fixes_applied", 0)
                    + r.get("rewrites_applied", 0)
                    + r.get("moves_applied", 0)
                )
        return {
            "dry_run": dry_run,
            "phases": phases,
            "cancelled": True,
            "summary": {
                "scanned": scanned,
                "changes_pending": changes_pending,
                "changes_applied": changes_applied,
                "errors": 0,
                "phases_completed": len(phases),
            },
        }

    async def repair_citations(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = False,
    ) -> dict:
        """Public entry point — wraps the body in the canonical ``_scoped_pipeline``
        so writes pass the VaultWriter runtime guard. See ``_do_repair_citations``
        for the implementation.
        """
        if dry_run:
            # Dry-run performs zero writes — no need for a trusted_scope.
            return await self._do_repair_citations(slug, dry_run=True)
        async with self._scoped_pipeline(
            "kb_citations_repair", scope_prefix="citations-repair"
        ):
            return await self._do_repair_citations(slug, dry_run=False)

    async def _do_repair_citations(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = False,
    ) -> dict:
        """Backfill numberification on wiki articles that still carry raw
        ``[Source: filename]`` markers without a matching ``## References``
        section or ``citations:`` frontmatter.

        Closes the historic gap where the compile CREATE path silently skipped
        ``_numberify_sources`` when the batch had no source summaries (e.g. a
        stubs-only rewrite pass). The LLM still emitted ``[Source: X]`` markers
        from the stub's existing references, but numberification was gated on
        ``source_fnames`` being non-empty — so the prose kept raw markers while
        the UI's References panel rendered ``1. X`` from the bibliography
        registry, producing the disagreement between inline ``[1]`` and list
        ``1.`` numbers the user saw.

        Idempotent: ``_renumberify_article`` reverses prior ``[N]`` markers
        back to filenames using the ``citations:`` frontmatter before the next
        pass, so running this method twice is a no-op.

        Args:
            slug: KB slug to repair. ``None`` scans every KB.
            dry_run: If True, return the list of candidate articles without
                mutating the vault.

        Returns:
            ``{scanned, needs_repair, repaired, errors, dry_run, articles, error_details}``
        """
        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        scanned = 0
        repaired: list[dict] = []
        candidates: list[dict] = []
        errors: list[dict] = []

        for kb_slug in kbs:
            base = f"knowledge/{kb_slug}"
            try:
                wiki_files = self._reader.list_files(f"{base}/wiki", "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files: {exc}"})
                continue

            for wf in wiki_files:
                name = wf.name
                path_str = str(wf).replace("\\", "/")
                # Skip: catalogs/index files, dotfiles, history, archives
                if name.startswith("_") or name.startswith("."):
                    continue
                if "/.history/" in path_str or "/.archives/" in path_str:
                    continue

                try:
                    rel = self._to_logical(wf)
                except Exception:
                    continue

                scanned += 1
                try:
                    doc = self._reader.read(rel)
                    content = doc.raw
                except Exception as exc:
                    errors.append({"path": rel, "error": f"read: {exc}"})
                    continue

                head, body = self._split_frontmatter(content)

                # Count ONLY well-formed `[Source: filename]` markers — skip
                # `[[Source: filename|Title]]` wikilink-style leakage from old
                # LLM output. Those can't be cleanly numberified without also
                # stripping the wikilink wrappers; treat them as pre-existing
                # data corruption and leave alone. The negative-lookbehind
                # ensures we don't count `[Source:` preceded by another `[`.
                has_raw_markers = bool(
                    re.search(r"(?<!\[)\[Source:\s*[^\]\[]+?\]", body)
                )
                has_refs = bool(self._REFERENCES_BLOCK_RE.search(body))
                has_citations_fm = bool(self._read_citations_frontmatter(head))

                # Detect old-format References section that uses "[N] citation"
                # as the list prefix instead of the canonical markdown ordered
                # list "N. citation". These articles were numberified before the
                # format switch and need a reformat pass. `_renumberify_article`
                # is idempotent — re-running on an already-numberified article
                # reads the citations frontmatter, reverses [N] back to
                # [Source: filename], strips the old References block, and
                # rebuilds it in the new "N. " prefix form.
                old_format_refs = False
                if has_refs:
                    refs_match = self._REFERENCES_BLOCK_RE.search(body)
                    if refs_match:
                        refs_text = refs_match.group(0)
                        has_old = bool(re.search(r"^\[\d+\]\s", refs_text, flags=re.MULTILINE))
                        has_new = bool(re.search(r"^\d+\.\s", refs_text, flags=re.MULTILINE))
                        old_format_refs = has_old and not has_new

                # Detect citations placed AFTER a sentence-ending period
                # (``claim. [N]``) — Wikipedia/academic convention is ``claim
                # [N].``. The post-processor in ``_numberify_sources`` will fix
                # this on next run via ``_renumberify_article``. Scope to the
                # body only (not the References section, where ``N. citation``
                # is the canonical list prefix).
                body_excl_refs = self._REFERENCES_BLOCK_RE.sub("", body)
                misplaced_citations = bool(
                    self._CITATION_MISPLACED_RE.search(body_excl_refs)
                )

                # Already clean: numberified inline + new-format refs + citations fm + correctly placed.
                if (
                    not has_raw_markers
                    and has_refs
                    and has_citations_fm
                    and not old_format_refs
                    and not misplaced_citations
                ):
                    continue

                # Nothing to repair: no markers, no refs section — pristine source
                # summaries, stub pages, or articles that never cited anything.
                if not has_raw_markers and not has_refs and not misplaced_citations:
                    continue

                if has_raw_markers and not has_refs:
                    reason = "missing_references_section"
                elif has_raw_markers and not has_citations_fm:
                    reason = "missing_citations_frontmatter"
                elif old_format_refs:
                    reason = "old_bracket_format"
                elif misplaced_citations:
                    reason = "citation_after_period"
                elif has_raw_markers:
                    reason = "mixed_state_raw_markers"
                else:
                    reason = "mixed_state"
                entry = {"kb": kb_slug, "path": rel, "reason": reason}
                candidates.append(entry)

                if dry_run:
                    continue

                try:
                    self._renumberify_article(rel, [], kb_slug)
                    repaired.append(entry)
                    self._log_activity(
                        "wiki_citations_repaired",
                        f"Repaired citations in {rel}",
                        {"kb": kb_slug, "path": rel, "reason": reason},
                        importance="medium",
                    )
                except Exception as exc:
                    errors.append({"path": rel, "error": f"renumberify: {exc}"})

        if not dry_run and (repaired or errors):
            self._append_log(
                slug or "all",
                "repair_citations",
                f"repaired {len(repaired)} of {len(candidates)} candidate articles "
                f"across {len(kbs)} KBs, {len(errors)} errors",
            )

        return {
            "scanned": scanned,
            "needs_repair": len(candidates),
            "repaired": len(repaired),
            "errors": len(errors),
            "dry_run": dry_run,
            "articles": candidates if dry_run else repaired,
            "error_details": errors[:20],
            "kb_count": len(kbs),
        }

    async def repair_synthesis_citations(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = False,
    ) -> dict:
        """Public entry point — wraps the body in the canonical ``_scoped_pipeline``."""
        if dry_run:
            return await self._do_repair_synthesis_citations(slug, dry_run=True)
        async with self._scoped_pipeline(
            "kb_synthesis_citations_repair", scope_prefix="synthesis-repair"
        ):
            return await self._do_repair_synthesis_citations(slug, dry_run=False)

    async def _do_repair_synthesis_citations(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = False,
    ) -> dict:
        """Recompact the References section of every synthesis page to ONLY
        the LLM-emitted ``sources:`` from its frontmatter.

        Closes the historic synthesize bug (pre-2026-05-09) where every
        synthesis call passed every source page in the KB to
        ``_numberify_sources``, producing a 700+ entry References list when
        the LLM had only declared ~9-30 sources in its own ``sources:``
        frontmatter. ``_renumberify_article`` is idempotent — the call here
        re-reverses any ``[N]`` markers, strips the bloated References
        block, and rebuilds it from the trimmed source list.

        Skip rules: synthesis pages with empty ``sources:`` frontmatter are
        left alone (no signal of what the LLM intended → can't safely
        compact). Pages already at expected size (≤ ``len(sources) + 5``
        entries) are skipped to keep the pass cheap on already-clean vaults.

        Args:
            slug: KB slug to repair. ``None`` scans every KB.
            dry_run: If True, return candidate paths without mutating.

        Returns:
            ``{scanned, needs_repair, repaired, errors, dry_run, articles, error_details}``
        """
        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        scanned = 0
        repaired: list[dict] = []
        candidates: list[dict] = []
        errors: list[dict] = []

        for kb_slug in kbs:
            base = f"knowledge/{kb_slug}"
            try:
                synth_files = self._reader.list_files(f"{base}/wiki/synthesis", "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files: {exc}"})
                continue

            for sf in synth_files:
                name = sf.name
                path_str = str(sf).replace("\\", "/")
                if name.startswith("_") or name.startswith("."):
                    continue
                if "/.history/" in path_str or "/.archives/" in path_str:
                    continue

                try:
                    rel = self._to_logical(sf)
                except Exception:
                    continue

                scanned += 1
                try:
                    doc = self._reader.read(rel)
                    content = doc.raw
                except Exception as exc:
                    errors.append({"path": rel, "error": f"read: {exc}"})
                    continue

                head, _body = self._split_frontmatter(content)
                llm_sources = self._parse_sources_field_from_frontmatter(content)
                existing_citations = self._read_citations_frontmatter(head)

                # No LLM-declared sources — can't safely compact, skip.
                if not llm_sources:
                    continue

                # Already compact: ``citations`` count is within
                # ``llm_sources + 5`` (a small slop for downstream
                # bibliography expansions or a single source legitimately
                # listed twice). 2026-05-09: tightened from a 2x multiplier
                # to a fixed +5 buffer because the 2x rule failed to catch
                # double-count bugs from the old comma-naive parser
                # (a 12-source synthesis with one comma-bearing filename
                # ended up at 24 citations after the FIRST repair, exactly
                # 2x, and silently passed the skip gate).
                if (
                    existing_citations
                    and len(existing_citations) <= len(llm_sources) + 5
                ):
                    continue

                entry = {
                    "kb": kb_slug,
                    "path": rel,
                    "llm_source_count": len(llm_sources),
                    "current_citation_count": len(existing_citations),
                }
                candidates.append(entry)

                if dry_run:
                    continue

                try:
                    # force_rebuild=True so a corrupted prev_citations
                    # (e.g. comma-naive split of a quoted filename) doesn't
                    # double-count via the reversal step. The LLM-emitted
                    # ``sources:`` field is the authoritative truth here.
                    self._renumberify_article(
                        rel, llm_sources, kb_slug, force_rebuild=True
                    )
                    repaired.append(entry)
                    self._log_activity(
                        "wiki_synthesis_citations_repaired",
                        f"Compacted {rel} from {len(existing_citations)} to {len(llm_sources)} citations",
                        entry,
                        importance="medium",
                    )
                except Exception as exc:
                    errors.append({"path": rel, "error": f"renumberify: {exc}"})

        if not dry_run and (repaired or errors):
            self._append_log(
                slug or "all",
                "repair_synthesis_citations",
                f"compacted {len(repaired)} of {len(candidates)} synthesis pages "
                f"across {len(kbs)} KBs, {len(errors)} errors",
            )

        return {
            "scanned": scanned,
            "needs_repair": len(candidates),
            "repaired": len(repaired),
            "errors": len(errors),
            "dry_run": dry_run,
            "articles": candidates if dry_run else repaired,
            "error_details": errors[:20],
            "kb_count": len(kbs),
        }

    async def cleanup_image_digest_sources(
        self,
        slug: str | None = None,
        *,
        dry_run: bool = True,
        also_library: bool = False,
    ) -> dict:
        """Remove ``img-<hex>.md`` digest pages from ``wiki/sources/`` (and
        optionally their image binaries from ``library/``).

        The 2026-05-09 vault audit found 403 such pages on the user's main
        vault — OneNote-imported image binaries that leaked into the KB
        ingest pipeline as standalone digest pages. They have no semantic
        content (vision-LLM descriptions of image fragments) and pollute
        synthesis input + reference lists.

        ``dry_run=True`` (the default) is safer — returns the candidate
        list without deleting anything. ``dry_run=False`` actually removes
        the files.

        ``also_library=False`` (default) keeps the original image binaries
        on disk under ``library/``. The user can opt in to removing them
        too via ``also_library=True`` after reviewing the dry-run.

        Args:
            slug: KB slug. ``None`` scans every KB.
            dry_run: If True, return candidates without deleting.
            also_library: If True, also delete ``library/**/img-*.{png,jpg,...}``.

        Returns:
            ``{scanned, candidates, removed, errors, dry_run, also_library, ...}``
        """
        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        candidates_wiki: list[str] = []
        candidates_library: list[str] = []
        removed_wiki: list[str] = []
        removed_library: list[str] = []
        errors: list[dict] = []

        for kb_slug in kbs:
            base = f"knowledge/{kb_slug}"
            # Wiki-side sweep
            try:
                src_files = self._reader.list_files(f"{base}/wiki/sources", "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files(wiki): {exc}"})
                src_files = []

            for sf in src_files:
                if not self._IMG_DIGEST_STEM_RE.match(sf.stem):
                    continue
                try:
                    rel = self._to_logical(sf)
                except Exception:
                    rel = f"{base}/wiki/sources/{sf.name}"
                candidates_wiki.append(rel)
                if dry_run:
                    continue
                try:
                    sf.unlink()
                    removed_wiki.append(rel)
                except Exception as exc:
                    errors.append({"path": rel, "error": f"unlink: {exc}"})

            if also_library:
                # Library-side sweep
                try:
                    lib_files = self._reader.list_files(f"{base}/library", "**/img-*.*")
                except Exception as exc:
                    errors.append({"kb": kb_slug, "error": f"list_files(library): {exc}"})
                    continue
                for lf in lib_files:
                    if not lf.is_file():
                        continue
                    if not self._IMG_DIGEST_STEM_RE.match(lf.stem):
                        continue
                    try:
                        rel = self._to_logical(lf)
                    except Exception:
                        rel = str(lf)
                    candidates_library.append(rel)
                    if dry_run:
                        continue
                    try:
                        lf.unlink()
                        removed_library.append(rel)
                    except Exception as exc:
                        errors.append({"path": rel, "error": f"unlink(library): {exc}"})

        if not dry_run and (removed_wiki or removed_library or errors):
            self._append_log(
                slug or "all",
                "cleanup_image_digest_sources",
                f"removed {len(removed_wiki)} wiki source(s), "
                f"{len(removed_library)} library binary(ies), "
                f"{len(errors)} errors",
            )
            self._log_activity(
                "wiki_image_digests_removed",
                f"Removed {len(removed_wiki)} img-*.md source pages "
                f"({'with' if also_library else 'without'} library binaries)",
                {
                    "wiki_count": len(removed_wiki),
                    "library_count": len(removed_library),
                    "errors": len(errors),
                    "kbs": kbs,
                },
                importance="high",
            )

        return {
            "scanned_kbs": len(kbs),
            "candidates_wiki": len(candidates_wiki),
            "candidates_library": len(candidates_library),
            "removed_wiki": len(removed_wiki),
            "removed_library": len(removed_library),
            "errors": len(errors),
            "dry_run": dry_run,
            "also_library": also_library,
            "wiki_paths": candidates_wiki if dry_run else removed_wiki,
            "library_paths": candidates_library if dry_run else removed_library,
            "error_details": errors[:20],
        }

    async def cleanup_duplicates_from_external_tree(
        self,
        external_root: str | Path,
        *,
        slug: str | None = None,
        dry_run: bool = True,
        also_library: bool = False,
    ) -> dict:
        """Remove KB digest + library copies whose basename matches a file
        in ``external_root`` (e.g. ``<vault>/OneNote``).

        Closes the OneNote-double-ingest bug class: when an external tree
        (OneNote / Apple Notes / Notion / Roam / Logseq) lives inside the
        vault root and the inbox watcher hadn't been told to skip it,
        every page got re-ingested as a KB digest at
        ``wiki/sources/<basename>.md`` AND a library copy at
        ``library/.../<basename>.md``. The user's source-of-truth is the
        external tree itself; the digests are pure pollution.

        ``dry_run=True`` (default) returns the candidate list without
        deleting. ``also_library=True`` also removes matching binary
        copies under ``library/``.

        Args:
            external_root: Path to the external tree (relative to vault
                root or absolute). Walked recursively for ``.md`` files;
                the basenames are matched against ``wiki/sources/`` (and
                optionally ``library/``).
            slug: KB slug. ``None`` scans every KB.
            dry_run: If True, return candidates without deleting.
            also_library: If True, also delete library binary copies
                whose basename matches an external tree file.

        Returns:
            ``{external_root, external_count, scanned_kbs, candidates_wiki,
              candidates_library, removed_wiki, removed_library, errors,
              dry_run, also_library, ...}``
        """
        external_path = Path(external_root)
        if not external_path.is_absolute():
            try:
                external_path = self._resolve(str(external_root))
            except Exception:
                pass
        if not external_path.is_dir():
            return {"error": f"external_root not found: {external_path}"}

        # Build basename set from the external tree (recursive .md walk)
        external_basenames: set[str] = set()
        try:
            for f in external_path.rglob("*.md"):
                if not f.is_file():
                    continue
                external_basenames.add(f.name)
        except Exception as exc:
            return {"error": f"walk failed: {exc}"}

        if not external_basenames:
            return {
                "external_root": str(external_path),
                "external_count": 0,
                "scanned_kbs": 0,
                "candidates_wiki": 0,
                "candidates_library": 0,
                "removed_wiki": 0,
                "removed_library": 0,
                "errors": 0,
                "dry_run": dry_run,
                "also_library": also_library,
                "wiki_paths": [],
                "library_paths": [],
                "error_details": [],
            }

        if slug is None:
            kbs = [kb["slug"] for kb in self.list_kbs()]
        else:
            if not self._reader.exists(f"knowledge/{slug}/wiki/.index.md"):
                return {"error": f"KB not found: {slug}"}
            kbs = [slug]

        candidates_wiki: list[str] = []
        candidates_library: list[str] = []
        removed_wiki: list[str] = []
        removed_library: list[str] = []
        errors: list[dict] = []

        for kb_slug in kbs:
            base = f"knowledge/{kb_slug}"
            # Wiki-side sweep
            try:
                src_files = self._reader.list_files(f"{base}/wiki/sources", "**/*.md")
            except Exception as exc:
                errors.append({"kb": kb_slug, "error": f"list_files(wiki): {exc}"})
                src_files = []

            for sf in src_files:
                if sf.name not in external_basenames:
                    continue
                try:
                    rel = self._to_logical(sf)
                except Exception:
                    rel = f"{base}/wiki/sources/{sf.name}"
                candidates_wiki.append(rel)
                if dry_run:
                    continue
                try:
                    sf.unlink()
                    removed_wiki.append(rel)
                except Exception as exc:
                    errors.append({"path": rel, "error": f"unlink: {exc}"})

            if also_library:
                try:
                    lib_files = self._reader.list_files(f"{base}/library", "**/*.md")
                except Exception as exc:
                    errors.append({"kb": kb_slug, "error": f"list_files(library): {exc}"})
                    continue
                for lf in lib_files:
                    if not lf.is_file():
                        continue
                    if lf.name not in external_basenames:
                        continue
                    try:
                        rel = self._to_logical(lf)
                    except Exception:
                        rel = str(lf)
                    candidates_library.append(rel)
                    if dry_run:
                        continue
                    try:
                        lf.unlink()
                        removed_library.append(rel)
                    except Exception as exc:
                        errors.append({"path": rel, "error": f"unlink(library): {exc}"})

        if not dry_run and (removed_wiki or removed_library or errors):
            self._append_log(
                slug or "all",
                "cleanup_duplicates_from_external_tree",
                f"external_root={external_path.name}: removed {len(removed_wiki)} wiki, "
                f"{len(removed_library)} library, {len(errors)} errors",
            )
            self._log_activity(
                "wiki_external_duplicates_removed",
                f"Removed {len(removed_wiki)} digest pages duplicated from {external_path.name}/ "
                f"({'with' if also_library else 'without'} library binaries)",
                {
                    "external_root": str(external_path),
                    "external_count": len(external_basenames),
                    "wiki_count": len(removed_wiki),
                    "library_count": len(removed_library),
                    "errors": len(errors),
                    "kbs": kbs,
                },
                importance="high",
            )

        return {
            "external_root": str(external_path),
            "external_count": len(external_basenames),
            "scanned_kbs": len(kbs),
            "candidates_wiki": len(candidates_wiki),
            "candidates_library": len(candidates_library),
            "removed_wiki": len(removed_wiki),
            "removed_library": len(removed_library),
            "errors": len(errors),
            "dry_run": dry_run,
            "also_library": also_library,
            "wiki_paths": candidates_wiki if dry_run else removed_wiki,
            "library_paths": candidates_library if dry_run else removed_library,
            "error_details": errors[:20],
        }

    async def sync_projects_to_wiki(self, slug: str) -> dict:
        """Ensure all vault projects have wiki pages in this KB.

        For each project that doesn't have a wiki namespace yet,
        creates a project wiki page with overview, status, and links.
        """
        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Get all projects from vault
        projects_dir = self._resolve("projects")
        if not projects_dir.is_dir():
            return {"slug": slug, "synced": 0, "message": "No projects directory"}

        synced = 0
        for proj_dir in projects_dir.iterdir():
            if not proj_dir.is_dir():
                continue
            project_md = proj_dir / "PROJECT.md"
            if not project_md.exists():
                continue

            proj_slug = proj_dir.name
            wiki_path = f"{base}/wiki/projects/{proj_slug}/{proj_slug}.md"

            # Skip if already exists
            if self._reader.exists(wiki_path):
                continue

            # Read project data
            try:
                import frontmatter as fm
                post = fm.load(str(project_md))
                title = post.metadata.get("title", proj_slug.replace("-", " ").title())
                status = post.metadata.get("status", "active")
                description = post.content[:500] if post.content else ""
                goals = post.metadata.get("related_goals", [])
                agents = post.metadata.get("assigned_agents", [])
                kbs = post.metadata.get("linked_kbs", [])
            except Exception:
                title = proj_slug.replace("-", " ").title()
                status = "active"
                description = ""
                goals = []
                agents = []
                kbs = []

            # Create project wiki page
            content = f"""---
title: "{title}"
entity_type: project
category: projects
status: {status}
author: agent
agent: wiki-supervisor
date_created: "{datetime.now(UTC).strftime('%Y-%m-%d %H:%M')}"
---

# {title}

{description}

## Status

{status}

## Links

"""
            if goals:
                content += "### Goals\n" + "\n".join(f"- [[{g}]]" for g in goals) + "\n\n"
            if agents:
                content += "### Agents\n" + "\n".join(f"- [[{a}]]" for a in agents) + "\n\n"
            if kbs:
                content += "### Knowledge Bases\n" + "\n".join(f"- {kb}" for kb in kbs) + "\n\n"

            # Write
            (self._resolve(f"{base}/wiki/projects") / proj_slug).mkdir(parents=True, exist_ok=True)
            self._writer.write(wiki_path, content)
            synced += 1
            log.info("Synced project to wiki: %s → %s", proj_slug, wiki_path)

        if synced:
            self._append_log(slug, "sync-projects", f"{synced} projects synced to wiki")

        return {"slug": slug, "synced": synced}

    # ── Article Consolidation ──

    async def consolidate_articles(self, slug: str, min_updates: int = 3) -> dict:
        """Find and rewrite append-only articles that have accumulated updates.

        Articles with `min_updates` or more "Updated from compile" markers get
        rewritten by the LLM into a single coherent article. Old version is
        automatically saved to .history/ by the vault writer.

        Returns count of articles consolidated.
        """
        from agntspace.llm.base import Message

        base = f"knowledge/{slug}"
        wiki_base = f"{base}/wiki"

        if not self._reader.exists(f"{wiki_base}/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Phase B perf fix (2026-05-06): the consolidation candidate scan
        # walks every wiki subdir × every article × sync _reader.read — same
        # event-loop block class as lint's _structural_analysis. Off-loop.
        #
        # 2026-05-09 (v3 audit fix): walk every v3 L1 bucket AND legacy v1
        # aliases that may still hold articles on partially-migrated vaults.
        # Pre-fix the scan hardcoded ("entities", "concepts", "sources",
        # "synthesis", "decisions") and was BLIND to v3 buckets (knowledge/,
        # digests/, reference/, areas/, workflows/, projects/) — so the
        # heartbeat editor-quality-pass consolidated only the legacy
        # quarter of the user's wiki. Recursive glob so nested v3 sub-
        # buckets (entities/people/, entities/organizations/, etc.)
        # are reached.
        from agntspace.kb.taxonomy import FIXED_L1_SLUGS, LEGACY_L1_ALIASES

        def _gather_consolidation_candidates() -> list[dict]:
            out: list[dict] = []
            # Union of v3 L1 + v1 legacy roots so partially-migrated vaults
            # aren't missed. Dedup on the dir name (FIXED_L1_SLUGS already
            # includes "entities" which is also a v1 bucket).
            buckets = set(FIXED_L1_SLUGS) | set(LEGACY_L1_ALIASES.keys())
            for subdir in sorted(buckets):
                dir_path = f"{wiki_base}/{subdir}"
                try:
                    # Recursive — v3 sub-buckets like entities/people/,
                    # entities/organizations/, knowledge/programming/, etc.
                    files = self._reader.list_files(dir_path, "**/*.md")
                except Exception:
                    continue
                for f in files:
                    if f.name.startswith(("_", ".")):
                        continue
                    # Skip dot-prefixed segments (.archives/.history/.quarantine/).
                    rel_parts = str(f).replace("\\", "/").split("/")
                    if any(p.startswith(".") for p in rel_parts if p):
                        continue
                    try:
                        relative = self._to_logical(f) if hasattr(self, "_to_logical") else None
                        if not relative:
                            relative = f"{dir_path}/{f.name}"
                        doc = self._reader.read(relative)
                        update_count = doc.content.count("Updated from compile")
                        if update_count >= min_updates:
                            out.append({
                                "path": relative,
                                "title": doc.metadata.get("title", f.stem),
                                "update_count": update_count,
                                "size": len(doc.content),
                            })
                    except Exception:
                        continue
            return out

        candidates = await asyncio.to_thread(_gather_consolidation_candidates)

        if not candidates:
            return {"slug": slug, "consolidated": 0, "message": "No articles need consolidation"}

        # Sort by most updates first
        candidates.sort(key=lambda x: x["update_count"], reverse=True)

        consolidated = 0
        for article in candidates[:10]:  # max 10 per run
            try:
                doc = self._reader.read(article["path"])
                frontmatter_raw = doc.raw[:doc.raw.index("---", 3) + 3] if "---" in doc.raw[3:] else ""

                consolidate_system = self._get_skill_prompt("kb-consolidate") or _CONSOLIDATE_PROMPT_FALLBACK
                try:
                    response = await asyncio.wait_for(
                        self._llm.complete(
                            messages=[Message(role="user", content=doc.content)],
                            system=consolidate_system,
                            max_tokens=4096,
                            temperature=0.3,
                            model=self._resolve_model("capable"),  # editor: consolidate
                        ),
                        timeout=self._llm_timeout("consolidate", default=120),
                    )
                except (TimeoutError, Exception) as llm_exc:
                    log.warning(
                        "KB %s: consolidate LLM failed for %s: %s",
                        slug, article["path"], llm_exc,
                    )
                    self._log_activity(
                        "consolidate_llm_failed",
                        f"Consolidation LLM failed for {article['path']}",
                        {"slug": slug, "path": article["path"], "error": str(llm_exc)[:200]},
                        importance="medium",
                    )
                    if self._called_from_queue:
                        # Let the work queue's backoff machinery handle it.
                        raise
                    if self._work_queue:
                        asyncio.create_task(self._work_queue.enqueue(
                            "consolidate", {"slug": slug}, deduplicate=True,
                        ))
                    continue

                new_content = response.content.strip()
                if not new_content or len(new_content) < 100:
                    log.warning(
                        "KB %s: consolidate produced empty/short output for %s (%d chars) — enqueueing retry",
                        slug, article["path"], len(new_content),
                    )
                    self._log_activity(
                        "consolidate_empty_output",
                        f"Consolidation LLM returned {len(new_content)} chars for {article['path']}",
                        {"slug": slug, "path": article["path"], "chars": len(new_content)},
                        importance="medium",
                    )
                    if not self._called_from_queue and self._work_queue:
                        asyncio.create_task(self._work_queue.enqueue(
                            "consolidate", {"slug": slug}, deduplicate=True,
                        ))
                    continue

                # Preserve frontmatter, replace body
                if frontmatter_raw:
                    full = f"{frontmatter_raw}\n\n{new_content}"
                else:
                    full = new_content

                # Write (versioning happens automatically in VaultWriter)
                self._writer.write(article["path"], full)
                consolidated += 1
                log.info("Consolidated article: %s (%d updates merged)",
                         article["path"], article["update_count"])
                self._log_activity(
                    "consolidate_success",
                    f"Consolidated {article['path']} ({article['update_count']} updates merged)",
                    {"slug": slug, "path": article["path"], "updates": article["update_count"]},
                    importance="low",
                )
            except Exception as e:
                log.warning("Failed to consolidate %s: %s", article["path"], e)
                self._log_activity(
                    "consolidate_crashed",
                    f"Consolidation crashed on {article['path']}: {type(e).__name__}",
                    {"slug": slug, "path": article["path"], "error": str(e)[:200]},
                    importance="high",
                )
                continue

        self._append_log(slug, "consolidate", f"{consolidated} articles consolidated")
        return {"slug": slug, "consolidated": consolidated, "candidates": len(candidates)}

    # ── Full Pipeline ──

    async def run_wiki_job(
        self,
        slug: str,
        *,
        skip_lint: bool = False,
        skip_reflect: bool = False,
        force_end_of_queue_passes: bool = False,
    ) -> dict:
        """Run the full wiki pipeline: snapshot → ingest → compile → reflect → lint.

        This is the single entry point for a complete wiki processing cycle.
        Designed to be called from chat (agent tool) or API.

        Throughput contract (2026-04-28): the LLM-heavy end-of-queue passes
        (compile, synthesize, cross-link, reflect, lint, schema-evolution,
        index-enrich) only run when ``ingest_count > 0`` (or the caller
        explicitly opts in via ``force_end_of_queue_passes=True``).

        Why: ingest is per-file (capped at ``max_per_ingest``). The other
        passes operate over the WHOLE KB and are LLM-heavy. Running them
        every dispatch — even when 0 new files arrived — turned a ~30 min
        backlog drain into a 6-10 hour one. With the new shape, agent
        dispatches that find an empty inbox return in <1 s; dispatches
        that ingest N files run the end-of-queue passes ONCE for the
        whole batch. The ``force_end_of_queue_passes`` flag preserves the
        legacy "always run" behaviour for callers (e.g. UI "Compile now"
        button on /wiki, ad-hoc agent tool calls explicitly asking for
        a fresh pass).

        Idempotent across sequential dispatches: if ingest yielded 0
        files, the function does only the snapshot + ingest + log-append
        steps. The next dispatch with new files runs the full pass.
        """
        base = f"knowledge/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        results: dict[str, Any] = {"slug": slug, "steps": []}

        # 1. Snapshot (safety net before processing).
        # Off-loop via asyncio.to_thread — snapshot() does a full
        # shutil.copytree of the wiki tree + an rglob("*.md") count,
        # both synchronous I/O. On a 1700-article vault that's
        # multiple seconds of sync work that would block the event
        # loop and starve every concurrent request (canonical pattern
        # from CLAUDE.md sessions 2026-05-04 / 2026-05-06).
        try:
            import asyncio  # noqa: PLC0415
            snap = await asyncio.to_thread(
                self.snapshot, slug, reason="pre-wiki-job",
            )
            results["snapshot"] = snap.get("path", "")
            results["steps"].append("snapshot")
        except Exception:
            log.warning("KB %s: snapshot failed, continuing anyway", slug)

        # 2. Ingest (process inbox files)
        try:
            ingest_result = await self.ingest(slug)
            results["ingested"] = ingest_result.get("count", 0)
            results["ingested_files"] = ingest_result.get("ingested", [])
            results["steps"].append("ingest")
        except Exception:
            log.exception("KB %s: ingest failed during wiki job", slug)
            results["ingested"] = 0
            results["ingest_error"] = True

        # End-of-queue gate: skip the LLM-heavy whole-KB passes when this
        # cycle didn't ingest anything. Caller can force the legacy "always
        # run" behaviour via ``force_end_of_queue_passes=True`` (UI compile
        # button, manual sweeps).
        ingested_count = int(results.get("ingested", 0) or 0)
        run_end_of_queue = bool(force_end_of_queue_passes) or ingested_count > 0
        results["end_of_queue_ran"] = run_end_of_queue
        if not run_end_of_queue:
            results["compiled"] = 0
            results["end_of_queue_skipped_reason"] = "ingest_yielded_zero_files"
            self._append_log(
                slug,
                "wiki-job",
                "Pipeline complete: 0 ingested — end-of-queue passes "
                "(compile/lint/reflect) skipped (no new sources)",
            )
            return results

        # 3. Compile (generate/update wiki articles)
        try:
            compile_result = await self.compile_wiki(slug)
            results["compiled"] = compile_result.get("count", 0)
            results["compiled_articles"] = compile_result.get("articles", [])
            results["steps"].append("compile")
        except Exception:
            log.exception("KB %s: compile failed during wiki job", slug)
            results["compiled"] = 0
            results["compile_error"] = True

        # Trivial-batch gate (2026-04-28): when compile produced 0 NEW
        # wiki articles AND the batch is small (≤ trivial threshold),
        # skip the LLM-heavy whole-KB passes (synthesize, cross_link,
        # reflect, lint, schema-evolution). Saves 30-60s of lint+reflect
        # on tiny batches (e.g. a 4-line markdown that produced 1 source
        # page + 0 entities + 0 new wiki articles). Threshold lives in
        # ``kb-ingest/config/throughput.yaml`` so users can tune.
        # Caller can force the legacy "always run" via
        # ``force_end_of_queue_passes=True``.
        compiled_count = int(results.get("compiled", 0) or 0)
        ingested_files_count = int(results.get("ingested", 0) or 0)
        trivial_threshold = self._load_throughput_cap(
            "trivial_batch_max_files", default=1,
        )
        skip_due_to_trivial = (
            not force_end_of_queue_passes
            and compiled_count == 0
            and ingested_files_count <= trivial_threshold
        )
        if skip_due_to_trivial:
            results["end_of_queue_passes_skipped"] = "trivial_batch"
            self._append_log(
                slug,
                "wiki-job",
                f"Pipeline complete: {ingested_files_count} ingested + "
                f"{compiled_count} compiled — synthesize/cross_link/reflect/"
                f"lint skipped (trivial batch, threshold={trivial_threshold})",
            )
            return results

        # 4. Synthesize (cross-source insights — only if 2+ sources exist)
        if results.get("ingested", 0) > 0 or results.get("compiled", 0) > 0:
            try:
                synth_result = await self.synthesize(slug)
                results["synthesized"] = synth_result.get("count", 0)
                if synth_result.get("count", 0) > 0:
                    results["steps"].append("synthesize")
            except Exception:
                log.exception("KB %s: synthesize failed during wiki job", slug)

        # 5. Cross-link (scan for unlinked mentions, add [[wikilinks]])
        # Off-loop: cross_link() walks every wiki file synchronously
        # (reader.read + regex per file). On a 1700-article vault that
        # is multi-second sync work that would block the event loop.
        if results.get("ingested", 0) > 0 or results.get("compiled", 0) > 0:
            try:
                import asyncio  # noqa: PLC0415
                xlink = await asyncio.to_thread(self.cross_link, slug)
                results["cross_links_added"] = xlink.get("links_added", 0)
                if xlink.get("links_added", 0) > 0:
                    results["steps"].append("cross-link")
            except Exception:
                log.exception("KB %s: cross-link failed during wiki job", slug)

        # 6. Reflect (structural analysis — only if something changed)
        if not skip_reflect and (results.get("ingested", 0) > 0 or results.get("compiled", 0) > 0):
            try:
                reflect_result = await self.reflect(
                    slug,
                    articles_created=results.get("compiled_articles", []),
                    files_ingested=results.get("ingested_files", []),
                )
                results["decisions_created"] = reflect_result.get("decisions_created", 0)
                results["reflect_message"] = reflect_result.get("message", "")
                results["steps"].append("reflect")
            except Exception:
                log.exception("KB %s: reflect failed during wiki job", slug)
                results["reflect_error"] = True

        # 6. Lint (health check)
        if not skip_lint:
            try:
                lint_result = await self.lint(slug)
                results["issues"] = lint_result.get("issue_count", 0)
                results["suggestions"] = lint_result.get("suggestion_count", 0)
                results["lint_issues"] = lint_result.get("issues", [])[:10]  # top 10
                results["lint_suggestions"] = lint_result.get("suggestions", [])[:5]
                results["steps"].append("lint")
            except Exception:
                log.exception("KB %s: lint failed during wiki job", slug)
                results["lint_error"] = True

        # 7. Schema evolution (propose SCHEMA.md updates based on patterns)
        if results.get("compiled", 0) > 0 or results.get("ingested", 0) > 0:
            try:
                evo = await self.evolve_schema(slug)
                if evo.get("applied"):
                    results["schema_proposals"] = len(evo["applied"])
                    results["schema_changes"] = [p["section"] for p in evo["applied"]]
                    results["steps"].append("schema-evolution")
            except Exception:
                log.debug("KB %s: schema evolution failed", slug, exc_info=True)

        # 8. Enrich index with per-article metadata
        # Off-loop: _enrich_index() reads + rewrites every wiki section's
        # listing in _index.md by walking each subdir's .md files via
        # reader.list_files + reader.read. Multi-second sync I/O on
        # large vaults; same to_thread treatment as snapshot/cross_link.
        try:
            import asyncio  # noqa: PLC0415
            await asyncio.to_thread(self._enrich_index, slug)
            results["steps"].append("index-enrich")
        except Exception:
            log.debug("KB %s: index enrichment failed", slug, exc_info=True)

        self._append_log(slug, "wiki-job",
            f"Pipeline complete: {results.get('ingested', 0)} ingested, "
            f"{results.get('compiled', 0)} compiled, "
            f"{results.get('synthesized', 0)} synthesized, "
            f"{results.get('cross_links_added', 0)} cross-links, "
            f"{results.get('decisions_created', 0)} decisions, "
            f"{results.get('issues', '?')} issues")

        return results

    # ── Reclassify ──

    def reclassify_articles(self, slug: str | None = None) -> dict:
        """Re-run taxonomy classification on all articles and update their frontmatter.

        Call after taxonomy YAML changes to migrate all articles to new paths.
        If slug is None, reclassifies across all KBs.
        """
        from agntspace.kb.taxonomy import classify_article, flatten_taxonomy, load_taxonomy

        if not self._skills_dir:
            return {"error": "No skills directory configured", "updated": 0}

        tree = load_taxonomy(self._skills_dir)
        flat_nodes = flatten_taxonomy(tree)
        slugs = [slug] if slug else [kb["slug"] for kb in self.list_kbs()]
        updated = 0
        total = 0

        for kb_slug in slugs:
            base = f"knowledge/{kb_slug}/wiki"
            for subdir in _WIKI_SUBDIRS:
                try:
                    files = self._reader.list_files(f"{base}/{subdir}", "*.md")
                except Exception:
                    continue
                for f in files:
                    total += 1
                    try:
                        rel = f"knowledge/{kb_slug}/wiki/{subdir}/{f.name}"
                        doc = self._reader.read(rel)
                        meta = doc.metadata
                        old_path = meta.get("taxonomy_path", "")

                        new_path = classify_article(
                            entity_type=meta.get("entity_type", ""),
                            category=meta.get("category", ""),
                            title=meta.get("title", f.stem.replace("-", " ").title()),
                            flat_nodes=flat_nodes,
                        )

                        if new_path != old_path:
                            content = self._update_frontmatter(doc.raw, "taxonomy_path", new_path)
                            self._writer.write(rel, content)
                            updated += 1
                    except Exception:
                        continue

        return {"updated": updated, "total": total, "kbs": slugs}

    # ── Utility ──

    @staticmethod
    def _extract_block(text: str, label: str, max_chars: int = 10_000) -> str | None:
        marker = f"```{label}"
        start = text.find(marker)
        if start == -1:
            return None
        start = text.index("\n", start) + 1
        end = text.find("```", start)
        if end == -1:
            # Unclosed fence — cap at max_chars to prevent runaway extraction
            result = text[start:start + max_chars].strip()
            if result:
                log.warning("_extract_block(%s): unclosed fence, capped at %d chars", label, max_chars)
            return result
        return text[start:end].strip()

    # Domains that indicate a placeholder/fabricated URL — never render these.
    _FAKE_URL_DOMAINS = {"example.com", "localhost", "placeholder", "fake.com", "test.test"}  # arch:deterministic — domain blocklist for URL validation, not content strategy

    @classmethod
    def _is_fake_url(cls, url: str) -> bool:
        """Return True when a URL looks fabricated (placeholder domain)."""
        if not url:
            return False
        low = url.lower()
        return any(d in low for d in cls._FAKE_URL_DOMAINS)

    # Regex matching [Source: filename.ext] markers in article prose.
    # Handles optional whitespace around the filename and both .md and other extensions.
    _SOURCE_REF_RE = re.compile(r"\[Source:\s*([^\]]+?)\s*\]")
    # Regex matching standalone [N] numeric citations (for reverse-mapping).
    _NUMERIC_REF_RE = re.compile(r"\[(\d+)\]")
    # Regex matching ``sources: ["a.md", "b.md"]`` inline-list form in a
    # frontmatter block. Mirrors ``_read_citations_frontmatter``'s shape — used
    # by ``_parse_sources_field_from_frontmatter`` to recover the LLM's
    # declared source list during synthesize, so post-processing renders only
    # the LLM-relevant references instead of every source the KB carries.
    _SOURCES_FIELD_RE = re.compile(
        r"^sources:\s*\[(.*?)\]\s*$",
        flags=re.MULTILINE | re.DOTALL,
    )
    # Cap on input source-summaries fed to the synthesize LLM call. The
    # post-2026-04-29 vault audit found 718 source pages in main/wiki/sources/
    # which exceeds every model's context window AND produces References
    # bloat downstream. 30 is a deterministic floor — tunable later via skill
    # config if the rule needs to change.
    _SYNTHESIZE_MAX_SOURCES: int = 30  # arch:deterministic — synthesize input cap; structural infrastructure
    # Regex matching ``img-<hex>`` digest filename stems (case-insensitive).
    # OneNote-imported image binaries that leaked into wiki/sources/ as
    # standalone digest pages — they have no semantic content for synthesis
    # and pollute the input set. Filter at synthesize input boundary.
    _IMG_DIGEST_STEM_RE = re.compile(r"^img-[0-9a-f]+$", re.IGNORECASE)
    # Regex matching an existing ## References block at end of article.
    _REFERENCES_BLOCK_RE = re.compile(r"\n*## References\s*\n.*\Z", flags=re.DOTALL)
    # Regex matching end-of-sentence punctuation followed by inline space then
    # numeric citation(s) at sentence boundary. Used to rewrite
    # ``claim. [N]`` → ``claim [N].`` per Wikipedia/academic convention (the
    # citation belongs INSIDE the sentence it cites, not floating after).
    # Restricted to inline spacing ([ \t]+) so a paragraph break between
    # sentence-end and a fresh-paragraph citation isn't collapsed. Lookahead
    # requires the citation to end at a sentence boundary (whitespace, newline,
    # or end-of-string), so we don't move a citation that begins a NEW sentence.
    _CITATION_AFTER_PUNCT_RE = re.compile(
        r"([.!?])[ \t]+(\[\d+\](?:[ \t]*\[\d+\])*)(?=\s|$)",
        flags=re.MULTILINE,
    )
    # Detector regex (reuses the same pattern but only checks presence).
    # Used by repair_citations() to flag articles that need a position fix.
    _CITATION_MISPLACED_RE = re.compile(r"[.!?][ \t]+\[\d+\]")

    def _numberify_sources(self, content: str, source_files: list[str], kb_slug: str) -> str:
        """Replace ``[Source: filename]`` markers with ``[N]`` + append numbered references.

        Idempotent: every call persists the ordered filename list in the article's
        frontmatter as ``citations:``. On re-run, the previous citations are used to
        reverse inline ``[N]`` markers back to ``[Source: filename]`` so new append
        operations can extend the list without orphaning old numbers. This is the
        single post-processor that turns LLM output into Wikipedia-style numbered
        inline citations, and it is called from every wiki write path (compile
        CREATE, compile UPDATE, synthesize, research).

        Numbers are assigned by order of first appearance in the prose.
        Sources that appear in ``source_files`` but are never cited in the text
        are appended at the end of the reference list so no source is lost.
        """
        # Split frontmatter off so the numeric-ref reversal never touches metadata.
        head, body = self._split_frontmatter(content)
        prev_citations = self._read_citations_frontmatter(head)

        # Step 0: if the article was previously numberified, reverse [N] → [Source: filename]
        # BEFORE stripping the old References block — so numbers still resolve.
        if prev_citations:
            def _reverse(m: re.Match) -> str:
                idx = int(m.group(1))
                if 1 <= idx <= len(prev_citations):
                    return f"[Source: {prev_citations[idx - 1]}]"
                return m.group(0)
            body = self._NUMERIC_REF_RE.sub(_reverse, body)

        # Strip any existing ## References section (will be rebuilt from scratch).
        body = self._REFERENCES_BLOCK_RE.sub("", body).rstrip()

        # Pass 0.5: ALWAYS run the citation-position fix on whatever ``[N]``
        # markers already exist in the body. This catches the case where the
        # body was previously numberified but the citations frontmatter is in
        # YAML block-style (``citations:\n- file.md``) which the inline-only
        # reader can't parse — so reversal was skipped, and the body still
        # carries ``[N]`` markers that need to move to before the period.
        # Idempotent: running on already-correct ``[N].`` is a no-op.
        body = self._CITATION_AFTER_PUNCT_RE.sub(
            lambda m: f" {m.group(2)}{m.group(1)}",
            body,
        )

        # Pass 1: collect all [Source: ...] markers in order of first appearance.
        seen_order: list[str] = []  # filenames in first-appearance order
        seen_set: set[str] = set()

        for m in self._SOURCE_REF_RE.finditer(body):
            fname = m.group(1).strip()
            if fname and fname not in seen_set:
                seen_order.append(fname)
                seen_set.add(fname)

        # Add source_files that were never cited (so no source is lost).
        for fname in source_files:
            if fname and fname not in seen_set:
                seen_order.append(fname)
                seen_set.add(fname)

        if not seen_order:
            # Nothing to cite — drop any stale citations frontmatter field.
            head = self._write_citations_frontmatter(head, [])
            return head + body

        # Build filename → number mapping.
        num_map: dict[str, int] = {fname: i + 1 for i, fname in enumerate(seen_order)}

        # Pass 2: replace [Source: filename] with [N].
        def _replace_source_ref(m: re.Match) -> str:
            fname = m.group(1).strip()
            n = num_map.get(fname)
            return f"[{n}]" if n else m.group(0)

        body = self._SOURCE_REF_RE.sub(_replace_source_ref, body)

        # Pass 2.5: move citations from after sentence-ending punctuation to
        # before. Wikipedia/academic convention: ``claim [N].`` not
        # ``claim. [N]``. Runs AFTER ``[Source:]`` → ``[N]`` so it operates on
        # canonical numeric markers. Idempotent — well-placed ``claim [N].``
        # has no ``. [N]`` pattern to match, so re-running is a no-op.
        body = self._CITATION_AFTER_PUNCT_RE.sub(
            lambda m: f" {m.group(2)}{m.group(1)}",
            body,
        )

        # Pass 3: build numbered reference list as a proper markdown ordered list.
        # Format is "N. citation" (Wikipedia-style footnotes). Tight list (single
        # newline between items) so markdown renders one list, not N 1-item lists.
        # Inline markers stay [N] per academic convention; list prefix is N. so the
        # References body reads like a normal numbered list when viewed in Obsidian
        # or any markdown editor that doesn't render the UI's separate <ol> panel.
        ref_lines: list[str] = []
        for fname in seen_order:
            n = num_map[fname]
            bib = self._bibliography.find_by_source(fname, kb_slug) if self._bibliography else None
            if bib:
                citation = self._format_citation(bib, fname, kb_slug)
                ref_lines.append(f"{n}. {citation}")
            else:
                ref_lines.append(f"{n}. {Path(fname).stem.replace('-', ' ').replace('_', ' ')}")

        body = body + "\n\n## References\n\n" + "\n".join(ref_lines) + "\n"

        # Persist the ordered citations list so the next call is idempotent.
        head = self._write_citations_frontmatter(head, seen_order)
        return head + body

    @staticmethod
    def _split_frontmatter(content: str) -> tuple[str, str]:
        """Return (head_including_closing_delim, body). Head is '' when no frontmatter."""
        if not content.startswith("---"):
            return "", content
        # Find the closing ---
        end = content.find("\n---", 3)
        if end == -1:
            return "", content
        # Include the closing --- and its trailing newline (if present)
        tail_start = end + 4  # past "\n---"
        if tail_start < len(content) and content[tail_start] == "\n":
            tail_start += 1
        return content[:tail_start], content[tail_start:]

    @staticmethod
    def _split_yaml_inline_list_tokens(raw: str) -> list[str]:
        """Split a YAML inline-list body (the part between ``[`` and ``]``)
        into tokens, respecting quoted strings.

        Handles ``"a, b.md"`` as ONE token instead of splitting on the
        embedded comma. Both single and double quotes are honored; the
        more permissive scanner accepts mixed quoting in one list. Empty
        and whitespace-only tokens are filtered out.

        2026-05-09: pre-fix the parser used naive ``raw.split(",")``,
        which corrupted any source filename containing a literal comma
        (e.g. ``"Winchkåpa, Winch Cover.md"`` → two phantom citations).
        Fix shared by ``_read_citations_frontmatter`` and
        ``_parse_sources_field_from_frontmatter`` so both surfaces stay
        in lockstep.

        Total — never raises on malformed input. Unterminated quoted
        strings are treated as plain content from the opening quote
        through end-of-input.
        """
        tokens: list[str] = []
        current: list[str] = []
        i = 0
        n = len(raw)
        in_double = False
        in_single = False
        while i < n:
            ch = raw[i]
            if in_double:
                if ch == '"':
                    in_double = False
                else:
                    current.append(ch)
            elif in_single:
                if ch == "'":
                    in_single = False
                else:
                    current.append(ch)
            else:
                if ch == '"':
                    in_double = True
                elif ch == "'":
                    in_single = True
                elif ch == ",":
                    tok = "".join(current).strip()
                    if tok:
                        tokens.append(tok)
                    current = []
                else:
                    current.append(ch)
            i += 1
        # Tail token (no trailing comma, or unterminated quote)
        tail = "".join(current).strip()
        if tail:
            tokens.append(tail)
        return tokens

    @staticmethod
    def _read_citations_frontmatter(head: str) -> list[str]:
        """Parse ``citations: ["a.md", "b.md"]`` from frontmatter head. Returns []."""
        if not head:
            return []
        m = re.search(r"^citations:\s*\[(.*?)\]\s*$", head, flags=re.MULTILINE | re.DOTALL)
        if not m:
            return []
        return KnowledgeBaseService._split_yaml_inline_list_tokens(m.group(1))

    @classmethod
    def _parse_sources_field_from_frontmatter(cls, content: str) -> list[str]:
        """Parse ``sources: ["a.md", "b.md"]`` from a full article (frontmatter + body).

        Mirrors ``_read_citations_frontmatter`` but operates on full article
        content and only reads the inline-list form (the form the synthesize
        prompt teaches the LLM to emit). Returns ``[]`` when the field is
        absent OR when the content has no frontmatter — both cases tell the
        caller "fall through to the legacy behavior". YAML block-list form
        (``sources:\\n  - a.md``) is NOT parsed here; the synthesize prompt
        emits the inline form, so block-form is out of scope. Total — never
        raises on malformed input.

        Used by ``_body_synthesize`` to recover the LLM's declared source
        list so post-processing renders ONLY relevant references instead of
        every source the KB carries.
        """
        if not content:
            return []
        head, _body = cls._split_frontmatter(content)
        if not head:
            return []
        m = cls._SOURCES_FIELD_RE.search(head)
        if not m:
            return []
        return cls._split_yaml_inline_list_tokens(m.group(1))

    @staticmethod
    def _write_citations_frontmatter(head: str, citations: list[str]) -> str:
        """Upsert a ``citations: [...]`` line in the frontmatter head.

        Removes the field when the list is empty. No-op when there is no
        frontmatter (keeps behavior safe for article fragments that bypass
        the normal write pipeline — the next full compile will re-emit it).
        """
        if not head:
            return head
        if citations:
            # json.dumps produces valid YAML-flow-style list of strings
            value_str = json.dumps(citations, ensure_ascii=False)
            new_line = f"citations: {value_str}"
            if re.search(r"^citations:\s*\[", head, flags=re.MULTILINE):
                head = re.sub(
                    r"^citations:\s*\[.*?\]\s*$",
                    new_line,
                    head,
                    count=1,
                    flags=re.MULTILINE | re.DOTALL,
                )
            else:
                # Insert before the closing --- delimiter
                closing = head.rfind("\n---")
                if closing != -1:
                    head = head[:closing] + f"\n{new_line}" + head[closing:]
        else:
            head = re.sub(
                r"^citations:\s*\[.*?\]\s*\n",
                "",
                head,
                count=1,
                flags=re.MULTILINE | re.DOTALL,
            )
        return head

    def _renumberify_article(
        self,
        full_path: str,
        source_files: list[str],
        kb_slug: str,
        *,
        force_rebuild: bool = False,
    ) -> None:
        """Read an on-disk wiki article, run ``_numberify_sources``, write it back.

        Thin wrapper around ``_numberify_sources`` for callers that operate on
        files already written to the vault (UPDATE path, synthesize, research).
        No-op when the article doesn't exist or the post-processor is disabled.

        ``force_rebuild=True`` strips the existing ``citations:`` frontmatter
        BEFORE the post-processor runs. Without this, ``_numberify_sources``
        uses ``prev_citations`` to reverse ``[N]`` markers in the body — and
        when those prev_citations were corrupted by an older parser bug
        (e.g. comma-naive split of a quoted filename), the reversal
        produces split-token ``[Source:]`` markers AND the source_files
        argument adds full strings on top, doubling the citation count.
        Used by the synthesis repair pass which has the LLM-emitted
        ``sources:`` field as the authoritative source of truth.
        """
        if not self._bibliography:
            return
        if not self._reader.exists(full_path):
            return
        try:
            existing = self._reader.read(full_path)
            content = existing.raw
            if force_rebuild:
                head, body = self._split_frontmatter(content)
                head = self._write_citations_frontmatter(head, [])
                # Also strip body's [N] markers so the (now-empty)
                # prev_citations reversal can't pick them up at all and
                # the rebuild operates purely on llm_sources + body
                # [Source:] markers.
                body = self._NUMERIC_REF_RE.sub("", body)
                content = head + body
            new_content = self._numberify_sources(content, source_files, kb_slug)
            if new_content != content:
                self._writer.write(full_path, new_content)
        except Exception:
            log.debug("KB %s: renumberify failed for %s", kb_slug, full_path, exc_info=True)

    def _build_bibliography_section(self, source_files: list[str], kb_slug: str) -> str:
        """Build a standalone bibliography section (used when _numberify_sources is not called).

        Output follows Wikipedia/Chicago style:
          Author, First (Date). "Title". *Publisher*. Vol(Issue): Pages.
          doi:10.xxx. ISSN xxxx-xxxx – via Platform. Retrieved Date.
        """
        entries: list[str] = []
        for i, fname in enumerate(source_files, 1):
            bib = self._bibliography.find_by_source(fname, kb_slug)
            if bib:
                citation = self._format_citation(bib, fname, kb_slug)
                entries.append(f"[{i}] {citation}")
            else:
                entries.append(f"[{i}] {Path(fname).stem.replace('-', ' ').replace('_', ' ')}")
        if not entries:
            return ""
        return "## References\n\n" + "\n\n".join(entries) + "\n"

    def _format_citation(self, bib: dict, fname: str, kb_slug: str) -> str:
        """Format a single bibliography entry in Wikipedia/Chicago style."""
        parts: list[str] = []

        # ── Authors ──
        authors = bib.get("authors", [])
        author_str = "; ".join(authors) if authors else ""
        if author_str:
            parts.append(author_str)

        # ── Date (in parentheses) ──
        date = bib.get("date", "")
        if date:
            parts.append(f"({date})")

        # ── Title (quoted, optionally linked) ──
        title = bib.get("title", fname)
        url = bib.get("url", "")

        # Never output fabricated URLs — Rule 16: no fabricated data
        if url and self._is_fake_url(url):
            url = ""
        publisher = bib.get("publisher", "")
        if publisher and self._is_fake_url(publisher):
            publisher = ""

        # Resolve local file path for clickable links
        local_path = ""
        if not url:
            lib_path = bib.get("library_path", "")
            if lib_path:
                local_path = f"knowledge/{kb_slug}/{lib_path}"
            else:
                try:
                    found = self._vault.list_files(f"knowledge/{kb_slug}/library", f"**/{fname}")
                    if found:
                        p = found[0]
                        if self._vault.paths:
                            local_path = self._vault.paths.to_logical(p)
                        else:
                            local_path = str(p.relative_to(self._vault.vault_dir)).replace("\\", "/")
                except Exception:
                    pass

        if url:
            parts.append(f'["{title}"]({url})')
        elif local_path:
            parts.append(f'["{title}"]({local_path})')
        else:
            parts.append(f'"{title}"')

        # ── Publisher / journal (italicized) ──
        if publisher:
            lang = bib.get("language", "")
            pub_str = f"*{publisher}*"
            if lang:
                pub_str += f" (in {lang})"
            parts.append(pub_str)

        # ── Volume, issue, pages (journal-style) ──
        vol = bib.get("volume", "")
        issue = bib.get("issue", "")
        pages = bib.get("pages", "")
        if vol or issue or pages:
            loc_parts: list[str] = []
            if vol and issue:
                loc_parts.append(f"{vol} ({issue})")
            elif vol:
                loc_parts.append(vol)
            elif issue:
                loc_parts.append(f"({issue})")
            if pages:
                loc_parts.append(pages)
            parts.append(": ".join(loc_parts))

        # ── DOI ──
        doi = bib.get("doi", "")
        if doi:
            doi_clean = doi.strip()
            if doi_clean.startswith("10."):
                parts.append(f"[doi:{doi_clean}](https://doi.org/{doi_clean})")
            else:
                parts.append(f"doi:{doi_clean}")

        # ── ISSN / ISBN ──
        issn = bib.get("issn", "")
        if issn:
            parts.append(f"ISSN {issn}")
        isbn = bib.get("isbn", "")
        if isbn:
            parts.append(f"ISBN {isbn}")

        # ── Via (hosting platform) ──
        via = bib.get("via", "")
        if via:
            parts.append(f"– via {via}")

        # ── Access date ──
        access_date = bib.get("access_date", "")
        if access_date:
            parts.append(f"Retrieved {access_date}")

        return ". ".join(parts) + "."

    # Junk patterns in LLM-extracted bibliography values — prompt echoes,
    # TODO markers, and placeholder instructions that should never be stored.
    _BIB_JUNK_RE = re.compile(  # arch:deterministic — prompt-echo detection regex for bibliography parsing
        r"^\[?TODO[:\s]|"                  # [TODO: ...] or TODO: ...
        r"^\(.*or\s+\"unknown\"\)$|"        # (comma-separated list of authors, or "unknown")
        r"^\(.*or\s+\"\"\)$|"               # (DOI if visible, or "")
        r"^\(.*if visible|"                 # (DOI if visible, ...)
        r"^unknown$|"                       # bare "unknown"
        r"^\[?no\s|"                        # [no title specified] etc.
        r"^n/?a$",                          # n/a, N/A
        re.IGNORECASE,
    )

    @classmethod
    def _is_bib_junk(cls, val: str) -> bool:
        """Return True if a bibliography value is a prompt echo or placeholder."""
        return bool(cls._BIB_JUNK_RE.search(val.strip()))

    # All bibliography fields the LLM can extract.
    _BIB_SIMPLE_FIELDS = frozenset({  # arch:deterministic — bibliography field names for structured parsing
        "title", "date", "publisher", "doi",
        "volume", "issue", "pages", "issn", "isbn", "language", "via",
    })

    @classmethod
    def _parse_bib_metadata(
        cls, bib_raw: str, filename: str, source_type: str, source_url: str, date_str: str,
    ) -> dict:
        """Parse the LLM-produced bibliography block into structured metadata."""
        meta: dict = {"source_type": source_type}
        for line in bib_raw.strip().split("\n"):
            line = line.strip().lstrip("- ")
            if ":" not in line:
                continue
            key, _, val = line.partition(":")
            key = key.strip().lower()
            val = val.strip().strip('"').strip("'")
            if not val or cls._is_bib_junk(val):
                continue
            if key == "authors":
                authors = [a.strip() for a in val.split(",") if a.strip() and not cls._is_bib_junk(a.strip())]
                if authors:
                    meta["authors"] = authors
            elif key in cls._BIB_SIMPLE_FIELDS:
                meta[key] = val
        # ── Validation gates (Rule 16: no fabricated data) ──

        # Date: must look like a date (YYYY, YYYY-MM, YYYY-MM-DD, or with time)
        if "date" in meta:
            d = meta["date"]
            if not re.match(r"^\d{4}(?:-\d{1,2}(?:-\d{1,2})?)?(?:\s+\d{1,2}:\d{2})?$", d):
                del meta["date"]  # Malformed date — drop it

        # Publisher: reject if it looks like a fake domain
        if "publisher" in meta and cls._is_fake_url(meta["publisher"]):
            del meta["publisher"]

        # URL from source: reject fake domains at storage time (not just display)
        url_to_store = source_url or ""
        if url_to_store and cls._is_fake_url(url_to_store):
            url_to_store = ""

        # DOI: must start with 10. (standard DOI prefix)
        if "doi" in meta:
            doi = meta["doi"].strip()
            if not doi.startswith("10."):
                del meta["doi"]

        # Fallbacks
        if "title" not in meta:
            meta["title"] = Path(filename).stem.replace("-", " ").replace("_", " ")
        if url_to_store:
            meta["url"] = url_to_store
        if "date" not in meta:
            meta["date"] = date_str
        return meta

    @staticmethod
    def _update_frontmatter(content: str, key: str, value: str) -> str:
        """Update or insert a frontmatter key-value pair.

        Matches both quoted (``key: "value"``) and unquoted (``key: value``)
        forms so numeric fields like ``source_count: 0`` don't accumulate
        duplicate entries on every update.
        """
        import re
        # Match quoted values ("...") OR unquoted values (rest of line)
        pattern = rf'^{key}:\s*(?:"[^"]*"|.+)$'
        replacement = f'{key}: "{value}"'
        result = re.sub(pattern, replacement, content, count=1, flags=re.MULTILINE)
        if result == content:
            # Key not found — insert after opening ---
            result = content.replace("---\n", f"---\n{key}: \"{value}\"\n", 1)
        return result
