"""Finance API — Phase 1.

Surfaces the FinanceLedger, MerchantResolver, and ReceiptIngest services
over HTTP. Routes are designed to mirror the agent-tool surface so the
UI and the agent see the same state.

Mutating routes (commit, update, delete, ingest) go through the
ContractMiddleware in production — the contract action map is in
[api/contract_middleware.py](../contract_middleware.py). Read-only routes
are exempt.

Activity middleware classifications live in
[api/activity_middleware.py](../activity_middleware.py).
"""

from __future__ import annotations

import logging
import mimetypes
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

if TYPE_CHECKING:
    from decimal import Decimal

from agntspace.finance.storage import (
    archive_rejected_draft,
    read_draft,
    write_transaction,
)
from agntspace.finance.types import Budget, TransactionStatus

log = logging.getLogger(__name__)

router = APIRouter(prefix="/finance", tags=["finance"])


# ────────────────────────────────────────────────────────────────────
# Service handles
# ────────────────────────────────────────────────────────────────────
def _ledger(request: Request):
    svc = getattr(request.app.state, "finance_ledger", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Finance ledger not wired.")
    return svc


def _merchants(request: Request):
    svc = getattr(request.app.state, "merchant_resolver", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Merchant resolver not wired.")
    return svc


def _ingest(request: Request):
    svc = getattr(request.app.state, "receipt_ingest", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Receipt ingest not wired.")
    return svc


def _writer(request: Request):
    svc = getattr(request.app.state, "vault_writer", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Vault writer not wired.")
    return svc


def _reader(request: Request):
    svc = getattr(request.app.state, "vault_reader", None)
    if svc is None:
        raise HTTPException(status_code=503, detail="Vault reader not wired.")
    return svc


# ────────────────────────────────────────────────────────────────────
# Request/response models
# ────────────────────────────────────────────────────────────────────
class IngestRequest(BaseModel):
    path: str = ""  # logical or physical path; required if file upload not used


class UpdateLineItem(BaseModel):
    item_id: str
    category_slug: str | None = None
    project_slug: str | None = None
    tax_deductible: bool | None = None
    notes: str | None = None
    # Phase 2 — set by the UI when the user-edit path overrides an
    # agent-suggested value. UI passes "user_override" when changing a
    # non-empty agent suggestion, "user" when filling an empty slot. The
    # approve flow uses these to compute Bayesian trust feedback.
    category_source: str | None = None
    project_source: str | None = None


class UpdateTransactionRequest(BaseModel):
    project_slug: str | None = None
    notes: str | None = None
    items: list[UpdateLineItem] = []
    # Phase 2 — accompanying source for transaction-level project edits.
    project_source: str | None = None


class RejectRequest(BaseModel):
    reason: str = ""


class MerchantUpsert(BaseModel):
    canonical_name: str
    slug: str = ""
    aliases: list[str] = []
    country: str = ""
    default_category: str = ""
    default_project: str = ""
    notes: str = ""


class ApplyDefaultsRequest(BaseModel):
    """Body for `POST /merchants/{slug}/apply-defaults`.

    Both fields optional. Pass either or both. When provided, the merchant
    record is updated AND every existing verified txn for that merchant is
    re-tagged. Empty string clears the default for that merchant going
    forward (but does NOT clear values on historical txns).
    """
    category_slug: str | None = None
    project_slug: str | None = None
    apply_to_history: bool = True   # Set False to only update merchant record


class BudgetUpsertRequest(BaseModel):
    period: str
    scope_type: str = "global"   # "global" | "project" | "category"
    scope_slug: str = ""
    category_slug: str = ""
    amount: str = "0.00"
    currency: str = ""
    notes: str = ""


class GenerateReportRequest(BaseModel):
    period: str = ""             # "YYYY-MM" | "YYYY-Qn" | "YYYY" | "monthly" | "quarterly" | "yearly"
    scope: str = "all"           # "all" | "deductible_only"


# ────────────────────────────────────────────────────────────────────
# Read paths
# ────────────────────────────────────────────────────────────────────
@router.get("/transactions")
async def list_transactions(
    request: Request,
    since: str = "",
    until: str = "",
    merchant_slug: str = "",
    project_slug: str = "",
    category_slug: str = "",
    currency: str = "",
    status: str = "",
    search: str = "",
    limit: int = 50,
    offset: int = 0,
) -> dict:
    """List transactions newest-first. Default filter excludes archived + rejected.

    ``search`` matches a substring (case-insensitive) against the merchant
    slug OR any line item description on the transaction. Powers the
    unified ledger UI's single search box.
    """
    ledger = _ledger(request)
    rows = await ledger.list_transactions(
        since=since,
        until=until,
        merchant_slug=merchant_slug,
        project_slug=project_slug,
        category_slug=category_slug,
        currency=currency,
        status=status,
        search=search,
        limit=limit,
        offset=offset,
    )
    # Rule 20: ``count: len(rows)`` is post-slice and lies once the result
    # exceeds ``limit``. Fetch the true total via the dedicated count
    # query that uses the same WHERE clause but no LIMIT/OFFSET.
    total = await ledger.count_transactions(
        since=since,
        until=until,
        merchant_slug=merchant_slug,
        project_slug=project_slug,
        category_slug=category_slug,
        currency=currency,
        status=status,
        search=search,
    )
    return {
        # ``count`` retained as deprecated alias for backward compat with
        # any UI consumer that hasn't switched yet. New consumers MUST
        # source from ``total`` per Rule 20.
        "count": len(rows),
        "total": total,
        "has_more": (offset + len(rows)) < total,
        "transactions": [_transaction_to_dict(t) for t in rows],
    }


@router.get("/transactions/{txn_id}")
async def get_transaction(request: Request, txn_id: str) -> dict:
    txn = await _ledger(request).get_transaction(txn_id)
    if txn is None:
        raise HTTPException(status_code=404, detail=f"Transaction not found: {txn_id}")
    return _transaction_to_dict(txn, include_items=True)


@router.get("/pending")
async def list_pending(request: Request, limit: int = 100, offset: int = 0) -> dict:
    """Return drafts awaiting user approval (status='draft').

    Rule 20 shape: ``count`` retained for backward compat but is the
    sliced length; new consumers MUST source from ``total``.
    """
    ledger = _ledger(request)
    rows = await ledger.list_transactions(status="draft", limit=limit, offset=offset)
    total = await ledger.count_transactions(status="draft")
    return {
        "count": len(rows),  # deprecated alias for backward compat
        "total": total,
        "has_more": (offset + len(rows)) < total,
        "drafts": [_transaction_to_dict(t, include_items=True) for t in rows],
    }


@router.post("/reconcile")
async def reconcile_finance_drafts(request: Request) -> dict:
    """Live recovery for orphan drafts whose markdown exists but whose
    ledger row never landed.

    Walks ``agntspace-finance/pending/*.md`` and re-commits any draft
    whose ``draft_id`` is missing from the ledger. Idempotent — drafts
    already present in the ledger are skipped via the per-draft pre-check
    AND ``commit_transaction``'s own ``content_hash`` dedup.

    The boot-time pass at ``main.py`` already runs this on every startup,
    so this admin endpoint exists for the case where the user hits SQLite
    lock contention mid-session and doesn't want to restart to recover
    the orphans. Closes the 2026-04-29 gap where the ONLY recovery path
    was a process restart.

    Returns the same summary shape as the boot pass:
    ``{scanned, already_in_ledger, recovered, failed, unreadable, ids_recovered}``.
    """
    reader = _reader(request)
    if reader is None:
        raise HTTPException(status_code=503, detail="vault reader not wired")
    ledger = _ledger(request)
    if ledger is None:
        raise HTTPException(status_code=503, detail="finance ledger not wired")

    # Reuse the same reconciler the boot pass calls — single source of
    # truth so a future change to the recovery contract lands in one
    # place. ``activity_logger`` and ``merchants`` are BOTH optional in
    # the reconciler (it's defensive about missing deps), so we read
    # them straight off ``app.state`` instead of through ``_merchants(...)``
    # which would 503 the route on a vault that hasn't seeded a merchant
    # resolver yet (early boot, fresh install, fixture configurations).
    from agntspace.finance.reconcile import reconcile_pending_drafts

    activity_logger = _activity(request)
    merchants = getattr(request.app.state, "merchant_resolver", None)
    summary = await reconcile_pending_drafts(
        reader=reader,
        ledger=ledger,
        merchants=merchants,
        activity_logger=activity_logger,
    )
    return summary


@router.get("/health")
async def finance_health(request: Request) -> dict:
    h = _ledger(request).health()
    return {
        "ledger": h,
        "merchants_wired": bool(getattr(request.app.state, "merchant_resolver", None)),
        "ingest_wired": bool(getattr(request.app.state, "receipt_ingest", None)),
    }


@router.get("/categories")
async def list_categories(request: Request) -> dict:
    """Return the live finance category taxonomy.

    Source of truth is the ``transaction-categorize`` skill's
    ``config/categories.yaml`` block (Rule 12: strategy lives in skills).
    Vault overrides at
    ``system/skills/finance/transaction-categorize/config/categories.yaml``
    win automatically — the skill loader merges vault > bundled defaults.

    Caller pattern: dropdown rendering in the finance UI. Cached in the
    frontend at page load; no need to call per row. Re-fetched when the
    user edits the YAML (mtime-based cache invalidation in SkillLoader).

    Response shape: ``{"categories": [{"slug": str, "description": str}],
    "dont_autoclassify": [str], "fallback": bool}``. ``fallback=True``
    surfaces when the skill loader isn't wired or the YAML is malformed
    so the UI can still render a sensible default list.
    """
    skills = getattr(request.app.state, "skills", None)
    if skills is None:
        return _category_fallback("skills_not_wired")
    # ``categories.yaml`` lives at ``config/categories.yaml`` next to
    # SKILL.md — separate file, not frontmatter. Use ``load_skill_config_file``
    # (NOT ``get_skill_config`` which reads frontmatter blocks).
    try:
        cfg = skills.load_skill_config_file(
            "transaction-categorize", "categories.yaml",
        )
    except Exception:
        return _category_fallback("config_load_failed")
    if not isinstance(cfg, dict):
        return _category_fallback("config_not_dict")
    raw_cats = cfg.get("categories")
    if not isinstance(raw_cats, dict) or not raw_cats:
        return _category_fallback("no_categories_in_yaml")

    cats: list[dict] = []
    for slug, body in raw_cats.items():
        if not isinstance(slug, str) or not slug.strip():
            continue
        description = ""
        if isinstance(body, dict):
            d = body.get("description")
            if isinstance(d, str):
                description = d.strip()
        cats.append({"slug": slug.strip(), "description": description})

    dont_auto = cfg.get("dont_autoclassify")
    skip_list: list[str] = []
    if isinstance(dont_auto, list):
        skip_list = [str(s) for s in dont_auto if isinstance(s, (str, int, float))]

    return {"categories": cats, "dont_autoclassify": skip_list, "fallback": False}


# arch:deterministic — degraded-mode mirror of the shipped categories.yaml
# 12-bucket starter taxonomy. ONLY surfaces when the skill loader path
# fails (which means the wheel/vault is broken). Keeping it here so the
# UI dropdown is never empty even on a half-wired install.
_CATEGORY_FALLBACK_SLUGS: tuple[str, ...] = (  # arch:deterministic — emergency fallback when transaction-categorize skill YAML can't load; the YAML is the strategy, this is the safety net
    "groceries", "restaurants", "fuel", "housing", "utilities",
    "saas", "equipment", "travel", "health", "education",
    "entertainment", "other",
)


def _category_fallback(reason: str) -> dict:
    return {
        "categories": [{"slug": s, "description": ""} for s in _CATEGORY_FALLBACK_SLUGS],
        "dont_autoclassify": [],
        "fallback": True,
        "fallback_reason": reason,
    }


# ────────────────────────────────────────────────────────────────────
# Photo serving — used by chat UI to render images sent via channels
# (Telegram photo intercept writes ![Photo](/api/finance/photo/<file>)
# into the conversation; the chat's react-markdown loads through this
# endpoint) AND by the finance UI to render the attached receipt next to
# every transaction. Only serves files inside the finance vault subtree;
# anything else is 403.
# ────────────────────────────────────────────────────────────────────
_PHOTO_EXTS = frozenset({".jpg", ".jpeg", ".png", ".heic", ".webp", ".gif", ".pdf"})  # arch:deterministic — capability surface of the photo serving endpoint


def _serve_finance_file(paths, candidate: Path, *, source_dir: Path) -> FileResponse:
    """Serve a verified candidate path under ``source_dir`` with proper headers.

    Caller is responsible for the ``relative_to`` traversal check; we just
    pick the media type and build the response.
    """
    media_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
    return FileResponse(
        path=str(candidate),
        media_type=media_type,
        headers={"Cache-Control": "private, max-age=300"},
    )


@router.get("/photo/{filename}")
async def serve_finance_photo(request: Request, filename: str) -> FileResponse:
    """Serve a receipt image from the finance vault for inline chat rendering.

    Search order: ``finance/inbox/`` then a recursive scan of
    ``finance/library/`` (so files moved to ``library/YYYY-MM/`` after
    ingest still resolve by bare filename — required for the Telegram-bot
    photo links written before the move). Refuses any path containing
    separators or ``..``, and any extension outside the photo set, so the
    endpoint can't be used to exfiltrate arbitrary vault files.
    """
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(status_code=403, detail="Access denied")
    ext = Path(filename).suffix.lower()
    if ext not in _PHOTO_EXTS:
        raise HTTPException(status_code=415, detail=f"Unsupported extension: {ext}")
    paths = getattr(request.app.state, "vault_paths", None)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault paths not wired")

    # Direct hits in the two flat search dirs first.
    for sub in ("finance/inbox", "finance/library"):
        sub_root = paths.resolve(sub)
        candidate = sub_root / filename
        try:
            candidate.resolve().relative_to(sub_root.resolve())
        except (ValueError, OSError):
            continue
        if candidate.exists() and candidate.is_file():
            return _serve_finance_file(paths, candidate, source_dir=sub_root)

    # Then walk library/YYYY-MM/ subdirs. The library is bounded by the
    # number of months the vault has been collecting receipts, so this is
    # cheap even for power users.
    library_root = paths.resolve("finance/library")
    if library_root.exists() and library_root.is_dir():
        for child in library_root.iterdir():
            if not child.is_dir():
                continue
            candidate = child / filename
            try:
                candidate.resolve().relative_to(library_root.resolve())
            except (ValueError, OSError):
                continue
            if candidate.exists() and candidate.is_file():
                return _serve_finance_file(paths, candidate, source_dir=library_root)

    raise HTTPException(status_code=404, detail=f"Photo not found: {filename}")


@router.get("/transactions/{txn_id}/attachment")
async def serve_transaction_attachment(request: Request, txn_id: str) -> FileResponse:
    """Serve the original receipt or invoice attached to a transaction.

    This is the canonical UI surface for "show me the document this
    transaction was extracted from". It looks up the transaction's
    ``source_file`` field via the ledger and serves whatever it points at,
    constrained to ``finance/inbox/`` and ``finance/library/`` to prevent
    arbitrary-file disclosure if the field has been tampered with.

    Returns 404 when the transaction has no attachment (e.g. a manually
    entered transaction, or a draft whose original was deleted before it
    was attached).
    """
    ledger = _ledger(request)
    paths = getattr(request.app.state, "vault_paths", None)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault paths not wired")

    txn = await ledger.get_transaction(txn_id)
    if txn is None:
        raise HTTPException(status_code=404, detail=f"Transaction not found: {txn_id}")
    source = (txn.source_file or "").replace("\\", "/").strip()
    if not source:
        raise HTTPException(status_code=404, detail="No attachment recorded")
    # Constrain to finance/ subtree
    if not (
        source.startswith("finance/inbox/")
        or source.startswith("finance/library/")
    ):
        raise HTTPException(status_code=403, detail="Attachment outside finance vault")
    ext = Path(source).suffix.lower()
    if ext not in _PHOTO_EXTS:
        raise HTTPException(status_code=415, detail=f"Unsupported extension: {ext}")
    physical = paths.resolve(source)
    finance_root = paths.resolve("finance")
    try:
        physical.resolve().relative_to(finance_root.resolve())
    except (ValueError, OSError) as exc:
        raise HTTPException(status_code=403, detail="Path traversal refused") from exc
    if not physical.exists() or not physical.is_file():
        raise HTTPException(status_code=404, detail="Attachment file missing")
    return _serve_finance_file(paths, physical, source_dir=finance_root)


# ────────────────────────────────────────────────────────────────────
# Merchants
# ────────────────────────────────────────────────────────────────────
@router.get("/merchants")
async def list_merchants(request: Request, limit: int = 100, offset: int = 0) -> dict:
    rows = await _merchants(request).list_merchants(limit=limit, offset=offset)
    return {
        "count": len(rows),
        "merchants": [
            {
                "merchant_slug": m.merchant_slug,
                "canonical_name": m.canonical_name,
                "aliases": list(m.aliases),
                "country": m.country,
                "default_category": m.default_category,
                "last_seen": m.last_seen,
                "notes": m.notes,
            }
            for m in rows
        ],
    }


@router.get("/merchants/{merchant_slug}")
async def get_merchant(request: Request, merchant_slug: str) -> dict:
    m = await _merchants(request).get(merchant_slug)
    if m is None:
        raise HTTPException(status_code=404, detail=f"Merchant not found: {merchant_slug}")
    return {
        "merchant_slug": m.merchant_slug,
        "canonical_name": m.canonical_name,
        "aliases": list(m.aliases),
        "country": m.country,
        "default_category": m.default_category,
        "last_seen": m.last_seen,
        "notes": m.notes,
    }


@router.put("/merchants/{merchant_slug}")
async def upsert_merchant(
    request: Request, merchant_slug: str, body: MerchantUpsert,
) -> dict:
    """Update an existing merchant or create a new one. Idempotent."""
    slug = await _merchants(request).upsert_merchant(
        slug=body.slug or merchant_slug,
        canonical_name=body.canonical_name,
        aliases=body.aliases,
        country=body.country,
        default_category=body.default_category,
        notes=body.notes,
    )
    if not slug:
        raise HTTPException(status_code=400, detail="canonical_name is required")
    return {"ok": True, "merchant_slug": slug}


# ────────────────────────────────────────────────────────────────────
# Ingest (manual trigger)
# ────────────────────────────────────────────────────────────────────
@router.post("/ingest")
async def ingest_existing_file(request: Request, body: IngestRequest) -> dict:
    """Ingest a receipt file already in the vault.

    The path may be logical (``finance/inbox/r1.jpg``) or absolute. The
    file remains in place — this endpoint does not move it. The watcher
    (when enabled in Phase 1.5) will move processed files to ``library/``
    automatically.
    """
    if not body.path:
        raise HTTPException(status_code=400, detail="path is required")
    physical: Path
    paths = getattr(request.app.state, "vault_paths", None)
    if paths is not None:
        physical = paths.resolve(body.path)
    else:
        physical = Path(body.path)
    result = await _ingest(request).ingest(physical, source_logical_path=body.path)
    return result.to_dict()


@router.post("/ingest/upload")
async def ingest_upload(request: Request, file: UploadFile = File(...)) -> dict:
    """Upload a receipt and ingest it in one call.

    The file is saved to ``finance/inbox/`` then handed to the ingest
    engine. Useful for the UI's drag-and-drop UX without going through
    the watcher.
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="filename is required")
    paths = getattr(request.app.state, "vault_paths", None)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault paths not wired")
    inbox = paths.resolve("finance/inbox")
    inbox.mkdir(parents=True, exist_ok=True)
    target = inbox / Path(file.filename).name
    try:
        with target.open("wb") as fp:
            shutil.copyfileobj(file.file, fp)
    finally:
        await file.close()
    logical = f"finance/inbox/{target.name}"
    result = await _ingest(request).ingest(target, source_logical_path=logical)
    return result.to_dict()


# ────────────────────────────────────────────────────────────────────
# Approval gate
# ────────────────────────────────────────────────────────────────────
@router.post("/transactions/{txn_id}/approve")
async def approve_draft(request: Request, txn_id: str) -> dict:
    """Promote a draft to verified. Mirrors the memory-approval pattern.

    Side effects: ledger row flipped to ``verified``, canonical markdown
    written to ``transactions/YYYY-MM/``, Bayesian trust feedback emitted
    on the ``Financial reports`` domain for each surviving agent suggestion
    (``"good"`` when the user accepted it, ``"needs_improvement"`` when
    they overrode it). Phase 2 will additionally decrement matching budgets
    and emit SPO triples.
    """
    ledger = _ledger(request)
    writer = _writer(request)
    txn = await ledger.get_transaction(txn_id)
    if txn is None:
        raise HTTPException(status_code=404, detail=f"Transaction not found: {txn_id}")
    if txn.status not in (TransactionStatus.DRAFT, TransactionStatus.REJECTED):
        raise HTTPException(
            status_code=409,
            detail=f"Cannot approve transaction in status '{txn.status.value}'",
        )
    # Snapshot the BEFORE-approval state so we can compute trust feedback
    # against the agent's last suggestions. The user may have edited line
    # items after the suggestion engine ran — those overrides ARE the
    # signal we want. ``user`` source means the user filled an empty
    # slot (no agent suggestion to grade); ``user_override`` means they
    # changed an agent value (the agent missed it).
    feedback_summary = _emit_trust_feedback_for_approval(request, txn)

    ok = await ledger.update_transaction_status(txn_id, TransactionStatus.VERIFIED)
    if not ok:
        raise HTTPException(status_code=500, detail="ledger update failed")
    # Re-fetch to get verified_at populated, then materialise markdown
    txn = await ledger.get_transaction(txn_id)
    if txn is not None:
        try:
            write_transaction(writer, txn)
        except Exception:
            log.exception("approve: markdown write failed for %s", txn_id)
    # Phase 2 — auto-consume budgets matching this transaction. Idempotent
    # on (budget_id, txn_id), so re-approving (e.g. after reopen) does not
    # double-count. Failures here never block the approval — the txn is
    # ledger-canonical regardless of whether budget consumption succeeded.
    budget_summary: dict = {"consumed": [], "skipped": []}
    try:
        budget_summary = await ledger.consume_budget(txn_id)
    except Exception:
        log.exception("approve: consume_budget failed for %s", txn_id)
    return {
        "ok": True,
        "txn_id": txn_id,
        "status": "verified",
        "trust_feedback": feedback_summary,
        "budget_consumption": budget_summary,
    }


def _emit_trust_feedback_for_approval(request: Request, txn) -> dict:
    """Diff agent suggestions vs final state and feed Bayesian trust.

    Per-line: each item with ``category_source`` ∈ {merchant_default,
    merchant_history, llm} that survived to approval = ``good``. Each
    with ``category_source == "user_override"`` = ``needs_improvement``.
    Same logic for the transaction-level ``project_source``.

    Empty fields (the agent left them empty AND the user didn't fill them)
    produce NO signal — silence isn't a quality grade.

    Returns a summary dict for the API response so the UI can display
    "+3 good signals, +1 needs_improvement" if it wants to. Never raises;
    a missing trust service degrades to ``{"recorded": False}``.
    """
    summary = {"recorded": False, "good": 0, "needs_improvement": 0}
    trust = getattr(request.app.state, "trust_service", None)
    if trust is None:
        return summary
    AGENT_SOURCES = {"merchant_default", "merchant_history", "llm"}
    USER_OVERRIDE_SOURCES = {"user_override"}
    try:
        # Per-line categories
        for item in txn.items or ():
            src = getattr(item, "category_source", "") or ""
            if src in AGENT_SOURCES:
                trust.record_feedback(
                    "Financial reports", "good", agent_key="bookkeeper",
                )
                summary["good"] += 1
            elif src in USER_OVERRIDE_SOURCES:
                trust.record_feedback(
                    "Financial reports", "needs_improvement", agent_key="bookkeeper",
                )
                summary["needs_improvement"] += 1
        # Transaction-level project
        proj_src = getattr(txn, "project_source", "") or ""
        if proj_src in AGENT_SOURCES:
            trust.record_feedback(
                "Financial reports", "good", agent_key="bookkeeper",
            )
            summary["good"] += 1
        elif proj_src in USER_OVERRIDE_SOURCES:
            trust.record_feedback(
                "Financial reports", "needs_improvement", agent_key="bookkeeper",
            )
            summary["needs_improvement"] += 1
        summary["recorded"] = (
            summary["good"] > 0 or summary["needs_improvement"] > 0
        )
    except Exception:
        log.exception("approve: trust feedback emission failed for %s", txn.txn_id)
    return summary


@router.post("/transactions/{txn_id}/reject")
async def reject_draft(request: Request, txn_id: str, body: RejectRequest) -> dict:
    """Mark a draft rejected. Does NOT consume budget; archived for audit."""
    ledger = _ledger(request)
    reader = _reader(request)
    writer = _writer(request)
    txn = await ledger.get_transaction(txn_id)
    if txn is None:
        raise HTTPException(status_code=404, detail=f"Transaction not found: {txn_id}")
    if txn.status != TransactionStatus.DRAFT:
        raise HTTPException(
            status_code=409,
            detail=f"Only drafts can be rejected (current status: {txn.status.value})",
        )
    ok = await ledger.update_transaction_status(txn_id, TransactionStatus.REJECTED)
    if not ok:
        raise HTTPException(status_code=500, detail="ledger update failed")
    # Mirror the rejection into the rejected/ markdown trail
    draft = read_draft(reader, txn_id)
    if draft is not None:
        try:
            archive_rejected_draft(writer, draft, reason=body.reason)
        except Exception:
            log.exception("reject: rejected/ markdown write failed for %s", txn_id)
    return {"ok": True, "txn_id": txn_id, "status": "rejected"}


# ────────────────────────────────────────────────────────────────────
# Update / delete
# ────────────────────────────────────────────────────────────────────
@router.put("/transactions/{txn_id}")
async def update_transaction(
    request: Request, txn_id: str, body: UpdateTransactionRequest,
) -> dict:
    """Update line-item fields and/or transaction-level project + notes.

    Phase 2: ``project_slug``/``notes`` at the transaction level are now
    persisted via ``update_transaction_meta``. The UI's user-edit path
    additionally passes ``project_source`` / ``category_source`` so the
    approval flow can distinguish user overrides from agent suggestions
    when computing Bayesian trust feedback.
    """
    ledger = _ledger(request)
    txn = await ledger.get_transaction(txn_id)
    if txn is None:
        raise HTTPException(status_code=404, detail=f"Transaction not found: {txn_id}")
    items_updated = 0
    for entry in body.items:
        if not entry.item_id:
            continue
        if await ledger.update_line_item(
            entry.item_id,
            category_slug=entry.category_slug,
            project_slug=entry.project_slug,
            tax_deductible=entry.tax_deductible,
            notes=entry.notes,
            category_source=entry.category_source,
            project_source=entry.project_source,
        ):
            items_updated += 1
    meta_updated = False
    if (
        body.project_slug is not None
        or body.notes is not None
        or body.project_source is not None
    ):
        meta_updated = await ledger.update_transaction_meta(
            txn_id,
            project_slug=body.project_slug,
            project_source=body.project_source,
            notes=body.notes,
        )
    return {
        "ok": True,
        "txn_id": txn_id,
        "items_updated": items_updated,
        "meta_updated": meta_updated,
    }


@router.post("/transactions/{txn_id}/suggest")
async def suggest_for_draft(request: Request, txn_id: str) -> dict:
    """Manually re-trigger the SuggestionEngine for a draft.

    Idempotent: existing suggestions and user values are preserved (only
    empty + non-user-source fields get filled). Useful when (a) the
    auto-fire pass after ingest didn't run yet OR failed, or (b) the
    user wants to re-suggest after editing the merchant or projects list.

    Returns the SuggestionEngine result dict so callers can see what was
    applied (per-line categories + transaction-level project, plus skip
    reasons). Synchronous: waits for both Layer A + Layer B to complete
    so the UI can render fresh state immediately.
    """
    engine = getattr(request.app.state, "suggestion_engine", None)
    if engine is None:
        raise HTTPException(status_code=503, detail="Suggestion engine not wired.")
    ledger = _ledger(request)
    txn = await ledger.get_transaction(txn_id)
    if txn is None:
        raise HTTPException(status_code=404, detail=f"Transaction not found: {txn_id}")
    if txn.status.value != "draft":
        raise HTTPException(
            status_code=409,
            detail=f"Suggestions only apply to drafts (current status: {txn.status.value})",
        )
    result = await engine.suggest_all(txn_id)
    return {"ok": True, **result}


@router.delete("/transactions/{txn_id}")
async def delete_transaction(request: Request, txn_id: str) -> dict:
    """Soft-delete (archive). Reversible by re-approving."""
    ok = await _ledger(request).soft_delete_transaction(txn_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Transaction not found: {txn_id}")
    return {"ok": True, "txn_id": txn_id, "status": "archived"}


# ────────────────────────────────────────────────────────────────────
# Reopen — flip verified back to draft (Phase 2)
# ────────────────────────────────────────────────────────────────────
@router.post("/transactions/{txn_id}/reopen")
async def reopen_transaction(request: Request, txn_id: str) -> dict:
    """Flip a verified or archived transaction back to ``draft``.

    Use case: user spots a wrong category or project on a transaction
    they already approved. Reopen returns it to the editable draft pool;
    the user edits items, then re-approves. Budget consumption is
    automatically released on reopen so re-approval re-consumes against
    current budgets — never double-counted.

    Refuses to reopen rejected rows; those go through approve directly
    (the approve route already accepts ``draft`` and ``rejected``).
    """
    ledger = _ledger(request)
    txn = await ledger.get_transaction(txn_id)
    if txn is None:
        raise HTTPException(status_code=404, detail=f"Transaction not found: {txn_id}")
    if txn.status == TransactionStatus.REJECTED:
        raise HTTPException(
            status_code=409,
            detail="Rejected transactions cannot be reopened — use approve directly.",
        )
    if txn.status == TransactionStatus.DRAFT:
        # Already a draft; idempotent return.
        return {"ok": True, "txn_id": txn_id, "status": "draft", "noop": True}
    ok = await ledger.reopen_transaction(txn_id)
    if not ok:
        raise HTTPException(status_code=500, detail="Reopen failed.")
    return {"ok": True, "txn_id": txn_id, "status": "draft"}


# ────────────────────────────────────────────────────────────────────
# Budgets (Phase 2)
# ────────────────────────────────────────────────────────────────────
@router.post("/budgets")
async def create_budget(request: Request, body: BudgetUpsertRequest) -> dict:
    """Create or update a budget for a (period, scope, category) tuple.

    Idempotent on the scope tuple — re-posting with the same period +
    scope_type + scope_slug + category_slug updates the amount in place
    rather than creating a duplicate. The user thinks of "the groceries
    budget for May", not "budget #42".
    """
    ledger = _ledger(request)
    budget = Budget(
        budget_id="",
        period=body.period,
        scope_type=body.scope_type,
        scope_slug=body.scope_slug,
        category_slug=body.category_slug,
        amount=body.amount,
        currency=body.currency,
        notes=body.notes,
    )
    bid = await ledger.upsert_budget(budget)
    if not bid:
        raise HTTPException(status_code=500, detail="Budget upsert failed.")
    return {"ok": True, "budget_id": bid}


@router.get("/budgets")
async def list_budgets(
    request: Request,
    period: str = "",
    scope_type: str = "",
    scope_slug: str = "",
    category_slug: str = "",
) -> dict:
    """List budgets with their consumption snapshots.

    Each entry includes ``spent`` (decimal string), ``txn_count``, and
    ``percent_consumed`` (float in [0.0, ∞) — values >1.0 mean over budget).
    Currency is the budget's own currency; consumption is summed only
    over txns that matched the budget's currency exactly.
    """
    ledger = _ledger(request)
    budgets = await ledger.list_budgets(
        period=period,
        scope_type=scope_type,
        scope_slug=scope_slug,
        category_slug=category_slug,
    )
    out: list[dict] = []
    for budget in budgets:
        consumption = await ledger.get_budget_consumption(budget.budget_id)
        try:
            from decimal import Decimal
            cap = Decimal(budget.amount or "0.00")
            spent = Decimal(consumption.get("spent", "0.00") or "0.00")
            pct = float(spent / cap) if cap > 0 else 0.0
        except Exception:
            pct = 0.0
        out.append({
            "budget_id": budget.budget_id,
            "period": budget.period,
            "scope_type": budget.scope_type,
            "scope_slug": budget.scope_slug,
            "category_slug": budget.category_slug,
            "amount": budget.amount,
            "currency": budget.currency,
            "notes": budget.notes,
            "created_at": budget.created_at,
            "updated_at": budget.updated_at,
            "spent": consumption.get("spent", "0.00"),
            "txn_count": consumption.get("txn_count", 0),
            "percent_consumed": pct,
        })
    return {"items": out, "total": len(out)}


@router.get("/budgets/{budget_id}")
async def get_budget(request: Request, budget_id: str) -> dict:
    """Single budget with consumption + contributing txn ids."""
    ledger = _ledger(request)
    budget = await ledger.get_budget(budget_id)
    if budget is None:
        raise HTTPException(status_code=404, detail=f"Budget not found: {budget_id}")
    consumption = await ledger.get_budget_consumption(budget_id)
    return {
        "budget_id": budget.budget_id,
        "period": budget.period,
        "scope_type": budget.scope_type,
        "scope_slug": budget.scope_slug,
        "category_slug": budget.category_slug,
        "amount": budget.amount,
        "currency": budget.currency,
        "notes": budget.notes,
        "created_at": budget.created_at,
        "updated_at": budget.updated_at,
        "spent": consumption.get("spent", "0.00"),
        "txn_count": consumption.get("txn_count", 0),
        "txn_ids": consumption.get("txn_ids", []),
    }


@router.put("/budgets/{budget_id}")
async def update_budget(
    request: Request, budget_id: str, body: BudgetUpsertRequest,
) -> dict:
    """Update an existing budget's amount, currency, or notes.

    Scope fields (period / scope_type / scope_slug / category_slug) are
    immutable on a given budget row — to "change scope" delete this
    budget and create a new one. Same UX pattern as renaming a project:
    rename = delete + create.
    """
    ledger = _ledger(request)
    existing = await ledger.get_budget(budget_id)
    if existing is None:
        raise HTTPException(status_code=404, detail=f"Budget not found: {budget_id}")
    # Refuse scope changes — defensive (frontend shouldn't send them)
    if (
        body.period != existing.period
        or body.scope_type != existing.scope_type
        or body.scope_slug != existing.scope_slug
        or body.category_slug != existing.category_slug
    ):
        raise HTTPException(
            status_code=409,
            detail="Cannot change a budget's scope — delete and recreate.",
        )
    updated = Budget(
        budget_id=existing.budget_id,
        period=existing.period,
        scope_type=existing.scope_type,
        scope_slug=existing.scope_slug,
        category_slug=existing.category_slug,
        amount=body.amount,
        currency=body.currency,
        notes=body.notes,
        created_at=existing.created_at,
    )
    bid = await ledger.upsert_budget(updated)
    return {"ok": True, "budget_id": bid}


@router.delete("/budgets/{budget_id}")
async def delete_budget(request: Request, budget_id: str) -> dict:
    """Hard-delete a budget. Cleans up consumption rows."""
    ledger = _ledger(request)
    ok = await ledger.delete_budget(budget_id)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Budget not found: {budget_id}")
    return {"ok": True, "budget_id": budget_id}


@router.post("/budgets/{budget_id}/reconsume")
async def reconsume_budget(request: Request, budget_id: str) -> dict:
    """Recompute consumption for a budget by replaying every verified txn.

    Useful when a budget was added AFTER transactions were already approved.
    Walks every verified transaction and applies ``consume_budget`` for it
    so the budget catches up. Idempotent on the (budget_id, txn_id) primary
    key in ``finance_budget_consumed``.
    """
    ledger = _ledger(request)
    budget = await ledger.get_budget(budget_id)
    if budget is None:
        raise HTTPException(status_code=404, detail=f"Budget not found: {budget_id}")
    # Walk verified txns in the budget's period (or "monthly"/"yearly" rolling
    # windows — let consume_budget's matcher handle the period decision).
    txns = await ledger.list_transactions(status="verified", limit=10000)
    consumed_total = 0
    for txn in txns:
        result = await ledger.consume_budget(txn.txn_id)
        if any(c["budget_id"] == budget_id for c in result.get("consumed", [])):
            consumed_total += 1
    consumption = await ledger.get_budget_consumption(budget_id)
    return {
        "ok": True,
        "budget_id": budget_id,
        "scanned": len(txns),
        "applied": consumed_total,
        "spent": consumption.get("spent", "0.00"),
        "txn_count": consumption.get("txn_count", 0),
    }


# ────────────────────────────────────────────────────────────────────
# Helpers
# ────────────────────────────────────────────────────────────────────
def _attachment_url(txn) -> str:
    """Build a canonical URL for the transaction's attached receipt.

    Returns ``""`` when the transaction has no usable attachment (manual
    entry, deleted source, unsupported file type). The UI uses presence of
    this URL to decide whether to render a thumbnail.
    """
    source = (getattr(txn, "source_file", "") or "").replace("\\", "/").strip()
    if not source:
        return ""
    if not (
        source.startswith("finance/inbox/")
        or source.startswith("finance/library/")
    ):
        return ""
    ext = Path(source).suffix.lower()
    if ext not in _PHOTO_EXTS:
        return ""
    txn_id = getattr(txn, "txn_id", "")
    if not txn_id:
        return ""
    return f"/api/finance/transactions/{txn_id}/attachment"


def _attachment_kind(txn) -> str:
    """Classify the attachment for the UI: ``image`` | ``pdf`` | ``""``."""
    source = (getattr(txn, "source_file", "") or "").lower()
    if not source:
        return ""
    ext = Path(source).suffix.lower()
    if ext == ".pdf":
        return "pdf"
    if ext in {".jpg", ".jpeg", ".png", ".heic", ".webp", ".gif"}:
        return "image"
    return ""


def _transaction_to_dict(txn, *, include_items: bool = False) -> dict:
    out = {
        "txn_id": txn.txn_id,
        "txn_date": txn.txn_date,
        "merchant_slug": txn.merchant_slug,
        "currency": txn.currency,
        "total": txn.total,
        "tax": txn.tax,
        "project_slug": txn.project_slug,
        # Phase 2 — suggestion provenance: WHO last set the project_slug.
        # "merchant_history" / "llm" / "user" / "user_override" / "" .
        "project_source": getattr(txn, "project_source", "") or "",
        "status": txn.status.value,
        "payment_method": txn.payment_method,
        "source_file": txn.source_file,
        "attachment_url": _attachment_url(txn),
        "attachment_kind": _attachment_kind(txn),
        "correlation_id": txn.correlation_id,
        "created_at": txn.created_at,
        "verified_at": txn.verified_at,
        "item_count": len(txn.items),
        # Phase 2 — audit flags now persisted on the ledger row, not just
        # the markdown. Empty list when ingest had nothing to flag.
        "audit_flags": list(getattr(txn, "audit_flags", ()) or ()),
        # Phase 1.5 accounting fields (stored since 2026-04-25, exposed now)
        "receipt_number": getattr(txn, "receipt_number", "") or "",
        "document_type": getattr(txn, "document_type", "") or "",
        "subtotal": getattr(txn, "subtotal", "") or "",
        "vendor_tax_id": getattr(txn, "vendor_tax_id", "") or "",
        "vendor_address": getattr(txn, "vendor_address", "") or "",
        "due_date": getattr(txn, "due_date", "") or "",
        "discount_total": getattr(txn, "discount_total", "") or "",
        "discount_description": getattr(txn, "discount_description", "") or "",
        "tip": getattr(txn, "tip", "") or "",
        "buyer_tax_id": getattr(txn, "buyer_tax_id", "") or "",
        "reverse_charge": bool(getattr(txn, "reverse_charge", False)),
    }
    if include_items:
        out["items"] = [
            {
                "item_id": item.item_id,
                "description": item.description,
                "quantity": item.quantity,
                "unit_price": item.unit_price,
                "amount": item.amount,
                "category_slug": item.category_slug,
                "project_slug": item.project_slug,
                "tax_deductible": item.tax_deductible,
                "notes": item.notes,
                # Phase 2 — per-line suggestion provenance
                "category_source": getattr(item, "category_source", "") or "",
                "project_source": getattr(item, "project_source", "") or "",
                # Phase 1.5 — line-level fields
                "item_code": getattr(item, "item_code", "") or "",
                "discount": getattr(item, "discount", "") or "",
                "tax_rate": getattr(item, "tax_rate", "") or "",
            }
            for item in txn.items
        ]
    return out


# ────────────────────────────────────────────────────────────────────
# Reports — list / get / generate / delete period reports
# ────────────────────────────────────────────────────────────────────

# Finance activity events the UI surfaces. Anomaly + budget-alert events
# come from the heartbeat-driven services; receipt + approval events come
# from the activity middleware on user-initiated routes.
_FINANCE_ACTIVITY_ACTIONS = frozenset({  # arch:deterministic — activity-action identifiers emitted by finance routes; structural to the audit log shape, not strategy
    "transaction_anomaly_flagged",
    "budget_threshold_crossed",
    "receipt_ingested",
    "receipt_ledger_persist_failed",
    "receipt_unsupported_parked",
    "transaction_approved",
    "transaction_rejected",
    "transaction_updated",
    "transaction_deleted",
    "transaction_uploaded",
    "transaction_reopened",
    "budget_created",
    "budget_updated",
    "budget_deleted",
    "merchant_upserted",
    "merchant_auto_created",
    "draft_reconciled",
    "reconcile_pass_completed",
    "finance_reconciled",
})


def _vault_paths(request: Request):
    return getattr(request.app.state, "vault_paths", None)


def _activity(request: Request):
    return getattr(request.app.state, "activity_logger", None)


def _parse_report_filename(filename: str) -> str:
    """Defang an inbound filename so it cannot escape ``finance/reports/``.

    Returns just the basename, stripped of any path traversal.
    Refuses anything that doesn't end in ``.md``.
    """
    # Strip any path separators — only basenames allowed
    base = Path(filename).name
    if not base or base.startswith("."):
        raise HTTPException(status_code=400, detail="Invalid report filename.")
    if not base.endswith(".md"):
        raise HTTPException(status_code=400, detail="Reports are markdown files (.md).")
    return base


def _read_report_frontmatter(report_path: Path) -> tuple[dict, str]:
    """Split frontmatter + body from a report file. Forgiving of malformed input."""
    try:
        content = report_path.read_text(encoding="utf-8")
    except OSError:
        return {}, ""

    if not content.startswith("---\n"):
        return {}, content

    end = content.find("\n---\n", 4)
    if end == -1:
        return {}, content

    fm_text = content[4:end]
    body = content[end + 5:]

    fm: dict[str, str] = {}
    for line in fm_text.splitlines():
        if ":" not in line:
            continue
        key, _, val = line.partition(":")
        key = key.strip()
        val = val.strip()
        if not key:
            continue
        # Strip matched surrounding quotes
        if (val.startswith('"') and val.endswith('"') and len(val) >= 2) or (
            val.startswith("'") and val.endswith("'") and len(val) >= 2
        ):
            val = val[1:-1]
        fm[key] = val
    return fm, body


@router.get("/reports")
async def list_finance_reports(request: Request, limit: int = 100) -> dict:
    """List generated period reports under ``agntspace-finance/reports/``.

    Returns newest-first with frontmatter parsed (period, scope, generated_at,
    title) plus raw filename + logical path for downstream fetches.
    """
    paths = _vault_paths(request)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault paths not wired.")

    reports_dir = paths.resolve("finance/reports")
    if not reports_dir.is_dir():
        return {"items": [], "total": 0, "has_more": False}

    items: list[dict] = []
    for md_path in reports_dir.glob("*.md"):
        if md_path.name.startswith("."):
            continue
        fm, _body = _read_report_frontmatter(md_path)
        try:
            mtime = md_path.stat().st_mtime
        except OSError:
            mtime = 0.0
        items.append({
            "filename": md_path.name,
            "path": f"finance/reports/{md_path.name}",
            "title": fm.get("title", md_path.stem),
            "period": fm.get("period", ""),
            "scope": fm.get("scope", "all"),
            "generated_at": fm.get("generated_at", ""),
            "date": fm.get("date", ""),
            "mtime": mtime,
        })

    # Newest-first: prefer generated_at when present, fall back to mtime
    items.sort(
        key=lambda it: (it["generated_at"] or "", it["mtime"]),
        reverse=True,
    )
    total = len(items)
    capped_limit = max(1, min(limit, 500))
    return {
        "items": items[:capped_limit],
        "total": total,
        "has_more": total > capped_limit,
    }


@router.get("/reports/{filename}")
async def get_finance_report(request: Request, filename: str) -> dict:
    """Read a single report file's frontmatter + markdown body."""
    paths = _vault_paths(request)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault paths not wired.")

    base = _parse_report_filename(filename)
    report_path = paths.resolve(f"finance/reports/{base}")
    if not report_path.is_file():
        raise HTTPException(status_code=404, detail=f"Report not found: {base}")

    fm, body = _read_report_frontmatter(report_path)
    try:
        mtime = report_path.stat().st_mtime
    except OSError:
        mtime = 0.0
    return {
        "filename": base,
        "path": f"finance/reports/{base}",
        "title": fm.get("title", report_path.stem),
        "period": fm.get("period", ""),
        "scope": fm.get("scope", "all"),
        "generated_at": fm.get("generated_at", ""),
        "date": fm.get("date", ""),
        "frontmatter": fm,
        "content": body,
        "mtime": mtime,
    }


@router.post("/reports")
async def generate_finance_report_route(
    request: Request, body: GenerateReportRequest,
) -> dict:
    """Generate a period report and write to ``finance/reports/``.

    Delegates to the same ``generate_period_report`` engine the agent tool
    uses, so the UI and the agent see identical output.
    """
    from agntspace.finance.reports import generate_period_report

    ledger = _ledger(request)
    writer = _writer(request)
    result = await generate_period_report(
        ledger,
        writer,
        period=body.period,
        scope=body.scope,
    )
    if "error" in result:
        # Surface the engine's error as a 500 — the user explicitly asked
        # for the report and there's no graceful degrade.
        raise HTTPException(status_code=500, detail=result["error"])
    return result


@router.delete("/reports/{filename}")
async def delete_finance_report(request: Request, filename: str) -> dict:
    """Delete a generated report file."""
    paths = _vault_paths(request)
    if paths is None:
        raise HTTPException(status_code=503, detail="Vault paths not wired.")

    base = _parse_report_filename(filename)
    report_path = paths.resolve(f"finance/reports/{base}")
    if not report_path.is_file():
        raise HTTPException(status_code=404, detail=f"Report not found: {base}")

    try:
        report_path.unlink()
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"Delete failed: {exc}") from exc

    return {"ok": True, "filename": base, "path": f"finance/reports/{base}"}


# ────────────────────────────────────────────────────────────────────
# Activity feed — finance-specific events for sidebar panel + dashboard
# ────────────────────────────────────────────────────────────────────
@router.get("/activity")
async def finance_activity(
    request: Request,
    since: str | None = None,
    min_importance: str = "low",
    limit: int = 50,
) -> dict:
    """Return recent finance activity events.

    Filters today's ActivityLogger buffer to finance-specific actions
    (anomaly flags, budget alerts, receipt ingest, approvals, etc.).
    Today-only by design — buffer resets at local midnight, matching
    the dashboard background-work toaster's contract.

    Returns newest-first.
    """
    activity = _activity(request)
    from datetime import UTC, datetime

    from agntspace.infra.timezone import format_iso_local

    now = format_iso_local(datetime.now(UTC))
    if activity is None:
        return {"items": [], "total": 0, "now": now, "has_more": False}

    capped = max(1, min(limit, 200))
    try:
        events = activity.get_recent_events(
            since_iso=since,
            categories=["user"],
            min_importance=min_importance,
            # Pull a bigger window so the action filter has material to draw from
            limit=capped * 4,
        )
    except Exception:
        log.exception("finance activity query failed")
        return {"items": [], "total": 0, "now": now, "has_more": False}

    # Filter to finance-specific actions
    matching = [e for e in events if e.action in _FINANCE_ACTIVITY_ACTIONS]
    # Newest-first
    matching.reverse()

    serialized = [
        {
            "category": e.category,
            "action": e.action,
            "summary": e.summary,
            "details": e.details,
            "timestamp": e.timestamp,
            "importance": e.importance,
            "correlation_id": e.correlation_id,
        }
        for e in matching[:capped]
    ]
    return {
        "items": serialized,
        "total": len(matching),
        "now": now,
        "has_more": len(matching) > capped,
    }


# ────────────────────────────────────────────────────────────────────
# Dashboard summary — single aggregate endpoint for the dashboard card
# ────────────────────────────────────────────────────────────────────
@router.get("/summary")
async def finance_summary(request: Request, period: str = "") -> dict:
    """Aggregate finance state for the dashboard card.

    Returns spend in the requested period (defaults to current month) as
    multi-currency totals, top categories, top merchants, draft + budget
    counts, and today's anomaly + budget-alert counts. One round-trip,
    cheap, suitable for 15s polling.
    """
    from decimal import Decimal

    from agntspace.finance.ledger import _period_includes_date

    # Default period: "all" — show full history at a glance. Was current
    # month, which left vaults with sparse spend looking empty.
    period = (period or "").strip().lower() or "all"
    ledger = _ledger(request)

    # Verified transactions in the period — feeds spend + categories + merchants
    all_verified = await ledger.list_transactions(status="verified", limit=10000)
    txns = [t for t in all_verified if _period_includes_date(period, t.txn_date)]

    by_currency: dict[str, Decimal] = {}
    by_category: dict[str, Decimal] = {}
    by_merchant: dict[str, Decimal] = {}
    for txn in txns:
        cur = (txn.currency or "").upper() or "—"
        try:
            total = Decimal(txn.total or "0.00")
        except Exception:
            total = Decimal("0.00")
        by_currency[cur] = by_currency.get(cur, Decimal("0")) + total
        if txn.merchant_slug:
            by_merchant[txn.merchant_slug] = by_merchant.get(txn.merchant_slug, Decimal("0")) + total
        for item in (txn.items or ()):
            cat = item.category_slug or "(uncategorized)"
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                amt = Decimal("0.00")
            by_category[cat] = by_category.get(cat, Decimal("0")) + amt

    # Drafts + merchants + budgets — quick counts only (no aggregation)
    drafts = await ledger.list_transactions(status="draft", limit=200)
    drafts_count = len(drafts)

    merchants_svc = getattr(request.app.state, "merchant_resolver", None)
    merchants_count = 0
    if merchants_svc is not None:
        try:
            merchants_count = len(await merchants_svc.list_merchants())
        except Exception:
            pass

    # Budgets with consumption — band classification feeds the traffic-light
    budgets = await ledger.list_budgets()
    budget_status = {"on_track": 0, "near_cap": 0, "at_cap": 0, "over_cap": 0}
    for budget in budgets:
        try:
            consumption = await ledger.get_budget_consumption(budget.budget_id)
            cap = Decimal(budget.amount or "0.00")
            spent = Decimal(consumption.get("spent", "0.00") or "0.00")
            pct = float(spent / cap) if cap > 0 else 0.0
        except Exception:
            pct = 0.0
        # Mirror the alert engine's bands: < 0.75 ok, < 0.95 near, < 1.0 at, >= 1.0 over
        if pct >= 1.0:
            budget_status["over_cap"] += 1
        elif pct >= 0.95:
            budget_status["at_cap"] += 1
        elif pct >= 0.75:
            budget_status["near_cap"] += 1
        else:
            budget_status["on_track"] += 1

    # Today's anomaly + budget-alert counts (in-memory buffer)
    activity = _activity(request)
    anomalies_today = 0
    alerts_today = 0
    latest_anomaly: dict | None = None
    latest_alert: dict | None = None
    if activity is not None:
        try:
            events = activity.get_recent_events(
                categories=["user"], min_importance="low", limit=200,
            )
            for e in events:
                if e.action == "transaction_anomaly_flagged":
                    anomalies_today += 1
                    latest_anomaly = {
                        "summary": e.summary,
                        "timestamp": e.timestamp,
                        "importance": e.importance,
                        "details": e.details,
                    }
                elif e.action == "budget_threshold_crossed":
                    alerts_today += 1
                    latest_alert = {
                        "summary": e.summary,
                        "timestamp": e.timestamp,
                        "importance": e.importance,
                        "details": e.details,
                    }
        except Exception:
            log.exception("summary activity query failed")

    return {
        "period": period,
        "spend": [
            {"currency": cur, "total": f"{total:.2f}", "txn_count": sum(1 for t in txns if (t.currency or "").upper() == cur)}
            for cur, total in sorted(by_currency.items())
        ],
        "txn_count": len(txns),
        "top_categories": [
            {"slug": cat, "total": f"{amt:.2f}"}
            for cat, amt in sorted(by_category.items(), key=lambda kv: -kv[1])[:5]
        ],
        "top_merchants": [
            {"slug": m, "total": f"{amt:.2f}"}
            for m, amt in sorted(by_merchant.items(), key=lambda kv: -kv[1])[:5]
        ],
        "drafts_count": drafts_count,
        "merchants_count": merchants_count,
        "budgets_total": len(budgets),
        "budget_status": budget_status,
        "anomalies_today": anomalies_today,
        "alerts_today": alerts_today,
        "latest_anomaly": latest_anomaly,
        "latest_alert": latest_alert,
    }


# ────────────────────────────────────────────────────────────────────
# Aggregations — by-project, by-category, monthly time-series
# ────────────────────────────────────────────────────────────────────
def _shift_month(period_ym: str, delta: int) -> str:
    """Add ``delta`` calendar months to a ``YYYY-MM`` period. Returns ``YYYY-MM``."""
    try:
        year = int(period_ym[0:4])
        month = int(period_ym[5:7])
    except (ValueError, IndexError):
        return period_ym
    total = year * 12 + (month - 1) + delta
    new_year, new_month0 = divmod(total, 12)
    return f"{new_year:04d}-{new_month0 + 1:02d}"


def _txn_falls_in_month(txn_date: str, ym: str) -> bool:
    """True when ``YYYY-MM-DD`` starts with ``YYYY-MM-``."""
    return bool(txn_date) and txn_date.startswith(ym + "-")


def _decimal_pct(numerator: Decimal, denominator: Decimal) -> float:  # type: ignore[name-defined]
    """Safe percent = num/denom as float. 0 when denom == 0."""
    from decimal import Decimal
    if denominator == Decimal("0"):
        return 0.0
    try:
        return float(numerator / denominator)
    except Exception:
        return 0.0


@router.get("/aggregations")
async def finance_aggregations(
    request: Request,
    period: str = "",
    months_back: int = 12,
) -> dict:
    """Per-project + per-category + 12-month spend rollup for the dashboard.

    Returns three orthogonal slices:
      - ``by_project``: one row per project_slug present in verified txns
        for the period. Includes prior-period total + MoM delta + linked
        budget consumption (when a budget targets this project).
      - ``by_category``: one row per category_slug seen in line items for
        the period. Same shape as by_project for cross-comparison.
      - ``by_month``: ``months_back`` months of multi-currency spend totals
        + txn counts. Newest-last so the UI can render left-to-right
        without reversing.

    All amounts are decimal strings (no FX conversion — Phase 2.2 layer 2).
    Multi-currency rollup keeps each currency separate to avoid silent
    summing.
    """
    from datetime import UTC, datetime
    from decimal import Decimal

    period = (period or "").strip().lower()
    today = datetime.now(UTC)
    # Default period is "all" — show the user their full history. Was
    # current-month, which left vaults with sparse spend looking empty.
    if not period:
        period = "all"
    # Prior period only makes sense for explicit calendar months (YYYY-MM).
    # For "all" / "yearly" / quarterly / annual periods, MoM delta has no
    # meaningful predecessor — frontend hides the delta UI when prior == "".
    prior = _shift_month(period, -1) if len(period) == 7 and period[4] == "-" else ""

    ledger = _ledger(request)
    all_verified = await ledger.list_transactions(status="verified", limit=10000)

    from agntspace.finance.ledger import _period_includes_date

    period_txns = [t for t in all_verified if _period_includes_date(period, t.txn_date)]
    prior_txns = (
        [t for t in all_verified if _period_includes_date(prior, t.txn_date)]
        if prior
        else []
    )

    # ── by_project ─────────────────────────────────────────────────
    # Effective-project semantics (split-receipt aware):
    #   1. Per line item: item.project_slug (set explicitly on the line)
    #      OR txn.project_slug (the receipt's overall project) OR "(no project)".
    #   2. Each line item's amount goes to its effective project's bucket.
    #   3. Each distinct effective project on a txn gets txn_count += 1.
    # Why this matters: users often categorize at the LINE-ITEM level (every
    # item on a Bauhaus receipt → "development-of-agntspace") and leave the
    # txn-level project_slug empty. The old code only looked at txn-level →
    # all that work was invisible in the rollup. Fixed by walking items and
    # using item project as primary, txn project as fallback.
    UNATTRIBUTED_SLUG = "(no project)"

    def _effective_project(item: Any, txn: Any) -> str:
        return (
            getattr(item, "project_slug", None)
            or txn.project_slug
            or UNATTRIBUTED_SLUG
        )

    def _ensure_proj_bucket(d: dict, slug: str) -> dict:
        return d.setdefault(slug, {
            "spend": {},  # currency → Decimal
            "txn_count": 0,
            "categories": {},
            "merchants": {},
        })

    proj_now: dict[str, dict] = {}
    for t in period_txns:
        cur = (t.currency or "").upper() or "—"
        items = list(t.items or ())
        if not items:
            # Headless txn — attribute the whole total to the txn's project
            slug = t.project_slug or UNATTRIBUTED_SLUG
            bucket = _ensure_proj_bucket(proj_now, slug)
            try:
                total = Decimal(t.total or "0.00")
            except Exception:
                total = Decimal("0.00")
            bucket["spend"][cur] = bucket["spend"].get(cur, Decimal("0")) + total
            bucket["txn_count"] += 1
            if t.merchant_slug:
                bucket["merchants"][t.merchant_slug] = bucket["merchants"].get(t.merchant_slug, Decimal("0")) + total
            continue

        seen_proj_for_txn: set[str] = set()
        for item in items:
            slug = _effective_project(item, t)
            bucket = _ensure_proj_bucket(proj_now, slug)
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                amt = Decimal("0.00")
            bucket["spend"][cur] = bucket["spend"].get(cur, Decimal("0")) + amt
            if t.merchant_slug:
                bucket["merchants"][t.merchant_slug] = bucket["merchants"].get(t.merchant_slug, Decimal("0")) + amt
            cat = item.category_slug or ""
            if cat:
                bucket["categories"][cat] = bucket["categories"].get(cat, Decimal("0")) + amt
            seen_proj_for_txn.add(slug)
        # txn_count += 1 for each distinct effective project this txn touched
        for slug in seen_proj_for_txn:
            proj_now[slug]["txn_count"] += 1

    proj_prior: dict[str, Decimal] = {}
    for t in prior_txns:
        items = list(t.items or ())
        if not items:
            slug = t.project_slug or UNATTRIBUTED_SLUG
            try:
                total = Decimal(t.total or "0.00")
            except Exception:
                total = Decimal("0.00")
            proj_prior[slug] = proj_prior.get(slug, Decimal("0")) + total
            continue
        for item in items:
            slug = _effective_project(item, t)
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                amt = Decimal("0.00")
            proj_prior[slug] = proj_prior.get(slug, Decimal("0")) + amt

    # Pull budgets to mark which projects have one + show consumption.
    # Each snapshot now carries a `remaining` field (cap - spent, decimal
    # string, may be negative when over budget) so the UI doesn't have to
    # recompute it client-side.
    budgets = await ledger.list_budgets()
    proj_budgets: dict[str, list[dict]] = {}
    for b in budgets:
        if b.scope_type == "project" and b.scope_slug:
            consumption = await ledger.get_budget_consumption(b.budget_id)
            try:
                cap = Decimal(b.amount or "0.00")
                spent = Decimal(consumption.get("spent", "0.00") or "0.00")
                remaining = cap - spent
                pct = float(spent / cap) if cap > 0 else 0.0
            except Exception:
                pct = 0.0
                remaining = Decimal("0.00")
            proj_budgets.setdefault(b.scope_slug, []).append({
                "budget_id": b.budget_id,
                "period": b.period,
                "amount": b.amount,
                "currency": b.currency,
                "spent": consumption.get("spent", "0.00"),
                "remaining": f"{remaining:.2f}",
                "percent_consumed": pct,
            })

    by_project: list[dict] = []
    for slug, bucket in proj_now.items():
        # Pick "primary currency" as the largest one for delta math
        primary_total = max(bucket["spend"].values()) if bucket["spend"] else Decimal("0")
        primary_cur = ""
        for cur, amt in bucket["spend"].items():
            if amt == primary_total:
                primary_cur = cur
                break
        prior_total = proj_prior.get(slug, Decimal("0"))
        delta_pct = 0.0
        if prior_total > 0:
            delta_pct = float((primary_total - prior_total) / prior_total)
        elif primary_total > 0:
            delta_pct = 1.0  # 100% increase from zero
        top_cat = max(bucket["categories"].items(), key=lambda kv: kv[1], default=("", Decimal("0")))
        top_merch = max(bucket["merchants"].items(), key=lambda kv: kv[1], default=("", Decimal("0")))
        by_project.append({
            "slug": slug,
            "spend": [
                {"currency": cur, "total": f"{amt:.2f}"}
                for cur, amt in sorted(bucket["spend"].items())
            ],
            "primary_currency": primary_cur,
            "primary_total": f"{primary_total:.2f}",
            "txn_count": bucket["txn_count"],
            "prior_total": f"{prior_total:.2f}",
            "mom_delta_pct": delta_pct,
            "top_category": top_cat[0] or "",
            "top_merchant": top_merch[0] or "",
            "budgets": proj_budgets.get(slug, []),
        })
    by_project.sort(
        key=lambda p: Decimal(p["primary_total"] or "0"),
        reverse=True,
    )

    # ── by_category ────────────────────────────────────────────────
    cat_now: dict[str, dict] = {}
    for t in period_txns:
        cur = (t.currency or "").upper() or "—"
        for item in (t.items or ()):
            cat = item.category_slug or "(uncategorized)"
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                amt = Decimal("0.00")
            bucket = cat_now.setdefault(cat, {
                "spend": {},
                "txn_count": 0,
                "txns": set(),
                "merchants": {},
                "projects": {},
            })
            bucket["spend"][cur] = bucket["spend"].get(cur, Decimal("0")) + amt
            bucket["txns"].add(t.txn_id)
            if t.merchant_slug:
                bucket["merchants"][t.merchant_slug] = bucket["merchants"].get(t.merchant_slug, Decimal("0")) + amt
            project_for_item = (item.project_slug or t.project_slug or "")
            if project_for_item:
                bucket["projects"][project_for_item] = bucket["projects"].get(project_for_item, Decimal("0")) + amt

    cat_prior: dict[str, Decimal] = {}
    for t in prior_txns:
        for item in (t.items or ()):
            cat = item.category_slug or "(uncategorized)"
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                amt = Decimal("0.00")
            cat_prior[cat] = cat_prior.get(cat, Decimal("0")) + amt

    cat_budgets: dict[str, list[dict]] = {}
    for b in budgets:
        if b.scope_type == "category" and b.scope_slug:
            consumption = await ledger.get_budget_consumption(b.budget_id)
            try:
                cap = Decimal(b.amount or "0.00")
                spent = Decimal(consumption.get("spent", "0.00") or "0.00")
                pct = float(spent / cap) if cap > 0 else 0.0
            except Exception:
                pct = 0.0
            cat_budgets.setdefault(b.scope_slug, []).append({
                "budget_id": b.budget_id,
                "period": b.period,
                "amount": b.amount,
                "currency": b.currency,
                "spent": consumption.get("spent", "0.00"),
                "percent_consumed": pct,
            })

    by_category: list[dict] = []
    for cat, bucket in cat_now.items():
        primary_total = max(bucket["spend"].values()) if bucket["spend"] else Decimal("0")
        primary_cur = ""
        for cur, amt in bucket["spend"].items():
            if amt == primary_total:
                primary_cur = cur
                break
        prior_total = cat_prior.get(cat, Decimal("0"))
        delta_pct = 0.0
        if prior_total > 0:
            delta_pct = float((primary_total - prior_total) / prior_total)
        elif primary_total > 0:
            delta_pct = 1.0
        top_merch = max(bucket["merchants"].items(), key=lambda kv: kv[1], default=("", Decimal("0")))
        top_proj = max(bucket["projects"].items(), key=lambda kv: kv[1], default=("", Decimal("0")))
        by_category.append({
            "slug": cat,
            "spend": [
                {"currency": cur, "total": f"{amt:.2f}"}
                for cur, amt in sorted(bucket["spend"].items())
            ],
            "primary_currency": primary_cur,
            "primary_total": f"{primary_total:.2f}",
            "txn_count": len(bucket["txns"]),
            "prior_total": f"{prior_total:.2f}",
            "mom_delta_pct": delta_pct,
            "top_merchant": top_merch[0] or "",
            "top_project": top_proj[0] or "",
            "budgets": cat_budgets.get(cat, []),
        })
    by_category.sort(
        key=lambda c: Decimal(c["primary_total"] or "0"),
        reverse=True,
    )

    # ── by_month (12-month series, newest-last) ────────────────────
    # Anchor: when period is YYYY-MM, anchor on that month; otherwise
    # ("all", "yearly", YYYY, etc.) anchor on today's YYYY-MM so the chart
    # always shows the most recent N months relative to NOW.
    months_back = max(1, min(months_back, 24))
    if len(period) == 7 and period[4] == "-":
        anchor_ym = period
    else:
        anchor_ym = today.strftime("%Y-%m")
    series: list[dict] = []
    if anchor_ym:
        for i in range(months_back - 1, -1, -1):
            ym = _shift_month(anchor_ym, -i)
            month_totals: dict[str, Decimal] = {}
            month_count = 0
            for t in all_verified:
                if not _txn_falls_in_month(t.txn_date, ym):
                    continue
                cur = (t.currency or "").upper() or "—"
                try:
                    total = Decimal(t.total or "0.00")
                except Exception:
                    total = Decimal("0.00")
                month_totals[cur] = month_totals.get(cur, Decimal("0")) + total
                month_count += 1
            series.append({
                "month": ym,
                "spend": [
                    {"currency": cur, "total": f"{amt:.2f}"}
                    for cur, amt in sorted(month_totals.items())
                ],
                "txn_count": month_count,
            })

    return {
        "period": period,
        "prior_period": prior,
        "by_project": by_project,
        "by_category": by_category,
        "by_month": series,
        "total_projects": len(by_project),
        "total_categories": len(by_category),
    }


# ────────────────────────────────────────────────────────────────────
# Follow-ups — actionable signals that need attention
# ────────────────────────────────────────────────────────────────────
@router.get("/follow-ups")
async def finance_follow_ups(request: Request) -> dict:
    """Return actionable signals: things the user should look at.

    Five types, each turning passive financial data into something that
    can be acted on:

      1. ``unattributed_txn`` — verified txns missing project AND any
         line-item categorization. User probably forgot to categorize.
      2. ``old_drafts`` — drafts pending approval > 7 days. Forgotten.
      3. ``project_no_budget`` — projects with ≥ 5 verified txns this
         year but no budget. User probably should add one.
      4. ``budget_near_cap`` — budgets at 75-99% with > 7 days of period
         remaining. Likely to bust.
      5. ``category_spike`` — category spend this month > 2× mean of
         prior 3 months AND > 1.0 in primary currency.

    Each item carries severity (high/medium/low), a count, a summary,
    examples (slugs/ids/dates the user can click into), and an
    ``action_url`` deep-link that opens the relevant view filtered
    accordingly.
    """
    from datetime import UTC, datetime, timedelta
    from decimal import Decimal

    ledger = _ledger(request)
    today = datetime.now(UTC)
    today_str = today.strftime("%Y-%m-%d")
    this_month = today.strftime("%Y-%m")

    items: list[dict] = []

    # ── 1. unattributed_txn ───────────────────────────────────────
    # A txn is unattributed only when it has NEITHER a txn-level nor any
    # item-level project, AND no item carries a category. Users frequently
    # attribute at the line-item level (every line on a receipt → same
    # project), and that work shouldn't be flagged as "unattributed".
    verified = await ledger.list_transactions(status="verified", limit=2000)
    unattributed_examples: list[dict] = []
    unattributed_total = 0
    for t in verified:
        has_txn_project = bool(t.project_slug)
        has_item_project = any(
            getattr(item, "project_slug", None) for item in (t.items or ())
        )
        has_category = any(item.category_slug for item in (t.items or ()))
        if not has_txn_project and not has_item_project and not has_category:
            unattributed_total += 1
            if len(unattributed_examples) < 5:
                unattributed_examples.append({
                    "txn_id": t.txn_id,
                    "merchant_slug": t.merchant_slug,
                    "date": t.txn_date,
                    "total": t.total,
                    "currency": t.currency,
                })
    if unattributed_total > 0:
        items.append({
            "kind": "unattributed_txn",
            "severity": "medium" if unattributed_total >= 5 else "low",
            "count": unattributed_total,
            "summary": (
                f"{unattributed_total} verified transaction{'s' if unattributed_total != 1 else ''} "
                f"with no project and no category"
            ),
            "examples": unattributed_examples,
            "action_url": "/finance/ledger?unattributed=1",
            "action_label": "Categorize them",
        })

    # ── 2. old_drafts ─────────────────────────────────────────────
    drafts = await ledger.list_transactions(status="draft", limit=500)
    cutoff_iso = (today - timedelta(days=7)).isoformat(timespec="seconds")
    old_drafts: list[dict] = []
    for d in drafts:
        if d.created_at and d.created_at < cutoff_iso:
            old_drafts.append({
                "txn_id": d.txn_id,
                "merchant_slug": d.merchant_slug,
                "date": d.txn_date,
                "total": d.total,
                "currency": d.currency,
                "created_at": d.created_at,
            })
    if old_drafts:
        old_drafts.sort(key=lambda d: d["created_at"])  # oldest first
        items.append({
            "kind": "old_drafts",
            "severity": "high" if len(old_drafts) >= 5 else "medium",
            "count": len(old_drafts),
            "summary": (
                f"{len(old_drafts)} draft{'s' if len(old_drafts) != 1 else ''} "
                f"pending approval > 7 days"
            ),
            "examples": old_drafts[:5],
            "action_url": "/finance/ledger?status=draft",
            "action_label": "Review drafts",
        })

    # ── 3. project_no_budget ──────────────────────────────────────
    # Look at txns from the last year so we don't bug user about
    # projects that were active 3 years ago and are now dormant.
    # Counts each distinct effective project per txn (items > txn).
    one_year_ago = (today - timedelta(days=365)).strftime("%Y-%m-%d")
    proj_txn_count: dict[str, int] = {}
    for t in verified:
        if not t.txn_date or t.txn_date < one_year_ago:
            continue
        slugs_for_txn: set[str] = set()
        for item in (t.items or ()):
            ip = getattr(item, "project_slug", None) or t.project_slug
            if ip:
                slugs_for_txn.add(ip)
        # Headless txn: just use txn-level
        if not slugs_for_txn and t.project_slug:
            slugs_for_txn.add(t.project_slug)
        for slug in slugs_for_txn:
            proj_txn_count[slug] = proj_txn_count.get(slug, 0) + 1
    budgets = await ledger.list_budgets()
    projects_with_budget = {
        b.scope_slug for b in budgets if b.scope_type == "project" and b.scope_slug
    }
    no_budget_projects = sorted(
        [
            (slug, count)
            for slug, count in proj_txn_count.items()
            if slug not in projects_with_budget and count >= 5
        ],
        key=lambda kv: -kv[1],
    )
    if no_budget_projects:
        items.append({
            "kind": "project_no_budget",
            "severity": "low",
            "count": len(no_budget_projects),
            "summary": (
                f"{len(no_budget_projects)} project{'s' if len(no_budget_projects) != 1 else ''} "
                f"with active spend but no budget"
            ),
            "examples": [
                {"project_slug": slug, "txn_count_12mo": count}
                for slug, count in no_budget_projects[:5]
            ],
            "action_url": "/finance/budgets",
            "action_label": "Add a budget",
        })

    # ── 4. budget_near_cap ────────────────────────────────────────
    # Only fires for current-period budgets (period matches today's
    # YYYY-MM / YYYY-Qn / YYYY OR period is rolling). Triggers at 75-99%.
    near_cap: list[dict] = []
    for b in budgets:
        try:
            cap = Decimal(b.amount or "0.00")
        except Exception:
            cap = Decimal("0")
        if cap == Decimal("0"):
            continue
        # Is this budget's period the current one?
        from agntspace.finance.ledger import _period_includes_date
        is_current = _period_includes_date(b.period, today_str)
        if not is_current:
            continue
        consumption = await ledger.get_budget_consumption(b.budget_id)
        try:
            spent = Decimal(consumption.get("spent", "0.00") or "0.00")
            pct = float(spent / cap) if cap > 0 else 0.0
        except Exception:
            pct = 0.0
        if 0.75 <= pct < 1.0:
            near_cap.append({
                "budget_id": b.budget_id,
                "period": b.period,
                "scope_type": b.scope_type,
                "scope_slug": b.scope_slug,
                "category_slug": b.category_slug,
                "amount": b.amount,
                "currency": b.currency,
                "spent": consumption.get("spent", "0.00"),
                "percent_consumed": pct,
            })
    if near_cap:
        items.append({
            "kind": "budget_near_cap",
            "severity": "medium",
            "count": len(near_cap),
            "summary": (
                f"{len(near_cap)} budget{'s' if len(near_cap) != 1 else ''} "
                f"at 75-99% mid-period"
            ),
            "examples": near_cap[:5],
            "action_url": "/finance/budgets",
            "action_label": "Review budgets",
        })

    # ── 5. category_spike ─────────────────────────────────────────
    # Compare this month's per-category total to the mean of prior 3.
    # Only flag when this-month > 2 × mean AND > 1.0 in any currency.
    cat_this: dict[str, Decimal] = {}
    cat_prior_3: dict[str, list[Decimal]] = {}
    for t in verified:
        if not t.txn_date:
            continue
        for item in (t.items or ()):
            cat = item.category_slug
            if not cat:
                continue
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                continue
            if t.txn_date.startswith(this_month + "-"):
                cat_this[cat] = cat_this.get(cat, Decimal("0")) + amt
            else:
                # Check prior 3 months
                for i in range(1, 4):
                    ym = _shift_month(this_month, -i)
                    if t.txn_date.startswith(ym + "-"):
                        cat_prior_3.setdefault(cat, []).append(amt)
                        break
    spikes: list[dict] = []
    for cat, this_total in cat_this.items():
        if this_total <= Decimal("1.0"):
            continue
        prior_amounts = cat_prior_3.get(cat, [])
        if len(prior_amounts) < 3:
            # Not enough history — don't flag (might just be a new category)
            continue
        prior_sum = sum(prior_amounts, Decimal("0"))
        prior_mean = prior_sum / Decimal(len(prior_amounts))
        if prior_mean == Decimal("0"):
            continue
        ratio = float(this_total / prior_mean)
        if ratio >= 2.0:
            spikes.append({
                "category_slug": cat,
                "this_month_total": f"{this_total:.2f}",
                "prior_3mo_mean": f"{prior_mean:.2f}",
                "ratio": ratio,
            })
    if spikes:
        spikes.sort(key=lambda s: -s["ratio"])
        items.append({
            "kind": "category_spike",
            "severity": "medium",
            "count": len(spikes),
            "summary": (
                f"{len(spikes)} categor{'ies' if len(spikes) != 1 else 'y'} "
                f"spending > 2× the prior 3-month average this month"
            ),
            "examples": spikes[:5],
            "action_url": "/finance/ledger",
            "action_label": "Review category spend",
        })

    return {
        "items": items,
        "total": len(items),
        "high_count": sum(1 for it in items if it["severity"] == "high"),
        "medium_count": sum(1 for it in items if it["severity"] == "medium"),
        "low_count": sum(1 for it in items if it["severity"] == "low"),
    }


# ────────────────────────────────────────────────────────────────────
# Per-project drill-down — Phase 3 starter
# ────────────────────────────────────────────────────────────────────
@router.get("/projects/{project_slug}/detail")
async def finance_project_detail(
    request: Request,
    project_slug: str,
    months_back: int = 12,
    txn_limit: int = 50,
) -> dict:
    """One-shot project-detail endpoint for /finance/projects/{slug}.

    Bundles everything the drill-down page needs into a single round-trip:
    summary totals, 12-month spend series, top categories, top merchants,
    linked budgets with consumption, and the most recent transactions.

    All multi-currency rows are kept separate (no FX). 404 when the slug
    has no transactions AND no linked budgets — distinguishes a typo'd
    slug from a real-but-empty project.
    """
    from datetime import UTC, datetime
    from decimal import Decimal

    project_slug = (project_slug or "").strip()
    if not project_slug:
        raise HTTPException(status_code=400, detail="project_slug is required")

    ledger = _ledger(request)
    months_back = max(1, min(months_back, 24))
    txn_limit = max(1, min(txn_limit, 500))

    # All verified txns for this project (no date filter — full history)
    project_txns = await ledger.list_transactions(
        status="verified",
        project_slug=project_slug,
        limit=10000,
    )

    # Linked budgets — ANY budget targeting this project_slug
    all_budgets = await ledger.list_budgets()
    project_budgets = [b for b in all_budgets if b.scope_type == "project" and b.scope_slug == project_slug]

    if not project_txns and not project_budgets:
        raise HTTPException(
            status_code=404,
            detail=f"No transactions or budgets for project: {project_slug}",
        )

    # ── Summary totals ───────────────────────────────────────────
    by_currency: dict[str, Decimal] = {}
    earliest = ""
    latest = ""
    for t in project_txns:
        cur = (t.currency or "").upper() or "—"
        try:
            total = Decimal(t.total or "0.00")
        except Exception:
            total = Decimal("0.00")
        by_currency[cur] = by_currency.get(cur, Decimal("0")) + total
        if t.txn_date:
            if not earliest or t.txn_date < earliest:
                earliest = t.txn_date
            if not latest or t.txn_date > latest:
                latest = t.txn_date

    # ── Top categories ───────────────────────────────────────────
    cat_totals: dict[str, Decimal] = {}
    cat_counts: dict[str, int] = {}
    for t in project_txns:
        for item in (t.items or ()):
            cat = item.category_slug or "(uncategorized)"
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                amt = Decimal("0.00")
            cat_totals[cat] = cat_totals.get(cat, Decimal("0")) + amt
            cat_counts[cat] = cat_counts.get(cat, 0) + 1
    top_categories = [
        {"slug": cat, "total": f"{total:.2f}", "txn_count": cat_counts[cat]}
        for cat, total in sorted(cat_totals.items(), key=lambda kv: -kv[1])[:10]
    ]

    # ── Top merchants ────────────────────────────────────────────
    merch_totals: dict[str, Decimal] = {}
    merch_counts: dict[str, int] = {}
    for t in project_txns:
        if not t.merchant_slug:
            continue
        try:
            total = Decimal(t.total or "0.00")
        except Exception:
            total = Decimal("0.00")
        merch_totals[t.merchant_slug] = merch_totals.get(t.merchant_slug, Decimal("0")) + total
        merch_counts[t.merchant_slug] = merch_counts.get(t.merchant_slug, 0) + 1
    top_merchants = [
        {"slug": m, "total": f"{total:.2f}", "txn_count": merch_counts[m]}
        for m, total in sorted(merch_totals.items(), key=lambda kv: -kv[1])[:10]
    ]

    # ── Monthly series (newest-last) ─────────────────────────────
    today = datetime.now(UTC)
    this_ym = today.strftime("%Y-%m")
    series: list[dict] = []
    for i in range(months_back - 1, -1, -1):
        ym = _shift_month(this_ym, -i)
        month_totals: dict[str, Decimal] = {}
        month_count = 0
        for t in project_txns:
            if not _txn_falls_in_month(t.txn_date, ym):
                continue
            cur = (t.currency or "").upper() or "—"
            try:
                total = Decimal(t.total or "0.00")
            except Exception:
                total = Decimal("0.00")
            month_totals[cur] = month_totals.get(cur, Decimal("0")) + total
            month_count += 1
        series.append({
            "month": ym,
            "spend": [
                {"currency": cur, "total": f"{amt:.2f}"}
                for cur, amt in sorted(month_totals.items())
            ],
            "txn_count": month_count,
        })

    # ── Linked budgets with consumption ──────────────────────────
    budgets_out: list[dict] = []
    for b in project_budgets:
        consumption = await ledger.get_budget_consumption(b.budget_id)
        try:
            cap = Decimal(b.amount or "0.00")
            spent = Decimal(consumption.get("spent", "0.00") or "0.00")
            pct = float(spent / cap) if cap > 0 else 0.0
        except Exception:
            pct = 0.0
        budgets_out.append({
            "budget_id": b.budget_id,
            "period": b.period,
            "amount": b.amount,
            "currency": b.currency,
            "category_slug": b.category_slug,
            "spent": consumption.get("spent", "0.00"),
            "txn_count": consumption.get("txn_count", 0),
            "percent_consumed": pct,
        })

    # ── Recent transactions (newest-first, capped) ───────────────
    project_txns.sort(key=lambda t: (t.txn_date or "", t.txn_id), reverse=True)
    recent = project_txns[:txn_limit]
    recent_out = [
        {
            "txn_id": t.txn_id,
            "txn_date": t.txn_date,
            "merchant_slug": t.merchant_slug,
            "currency": t.currency,
            "total": t.total,
            "item_count": len(t.items or ()),
            "audit_flags": list(getattr(t, "audit_flags", []) or []),
        }
        for t in recent
    ]

    return {
        "project_slug": project_slug,
        "summary": {
            "spend": [
                {"currency": cur, "total": f"{total:.2f}"}
                for cur, total in sorted(by_currency.items())
            ],
            "txn_count": len(project_txns),
            "earliest_date": earliest,
            "latest_date": latest,
        },
        "by_month": series,
        "top_categories": top_categories,
        "top_merchants": top_merchants,
        "budgets": budgets_out,
        "has_budget": len(budgets_out) > 0,
        "transactions": recent_out,
        "total_transactions": len(project_txns),
        "has_more_transactions": len(project_txns) > txn_limit,
    }


# ────────────────────────────────────────────────────────────────────
# Recurring transactions — Phase 3
# ────────────────────────────────────────────────────────────────────
@router.get("/recurring")
async def finance_recurring(
    request: Request,
    min_occurrences: int = 3,
    day_tolerance: int = 5,
) -> dict:
    """List detected recurring charges (subscriptions, repeated payments).

    Pure deterministic detector — walks verified txns, groups by merchant,
    classifies cadence (weekly/monthly/quarterly/yearly), checks interval
    + amount stability. Returns charges sorted by estimated annual cost
    descending so the UI leads with biggest spend.

    Tunable knobs (defaults safe):
      - ``min_occurrences``: how many charges before "pattern" is real
        (default 3 — below this is just two coincidences).
      - ``day_tolerance``: stdev floor for "stable interval" classification.
    """
    from agntspace.finance.recurring import days_until, detect_recurring_charges

    ledger = _ledger(request)
    verified = await ledger.list_transactions(status="verified", limit=10000)
    detected = detect_recurring_charges(
        verified,
        min_occurrences=max(2, min_occurrences),
        day_tolerance=max(1, day_tolerance),
    )
    charges = [r.to_dict() for r in detected]
    # Add days_until_next for the UI's "due in N days" badge
    for c in charges:
        c["days_until_next"] = days_until(c["predicted_next_date"])
    return {
        "items": charges,
        "total": len(charges),
        "params": {
            "min_occurrences": min_occurrences,
            "day_tolerance": day_tolerance,
        },
    }


# ────────────────────────────────────────────────────────────────────
# Spending insights — Phase 3
# ────────────────────────────────────────────────────────────────────
@router.get("/insights")
async def finance_insights(request: Request) -> dict:
    """Deterministic narrative bullets for the dashboard insights panel.

    Computes "what's interesting" from the verified history: spending
    velocity, top category change vs prior month, largest single expense,
    unattributed alerts, recurring subscriptions, quiet projects. v1 is
    purely deterministic — no LLM. Returns up to 8 insights, sorted by
    importance (warns first, info last).
    """
    from agntspace.finance.insights import compute_insights
    from agntspace.finance.recurring import detect_recurring_charges

    ledger = _ledger(request)
    verified = await ledger.list_transactions(status="verified", limit=10000)

    # Recurring charges feed the recurring-subscription insight
    recurring = detect_recurring_charges(verified, min_occurrences=3)

    # Known project slugs — for the "quiet project" insight. Derive from
    # the projects service when wired (so the heuristic doesn't fire on
    # one-off slugs the user typed in once and never used again).
    project_slugs_known: set[str] = set()
    project_svc = getattr(request.app.state, "project_service", None)
    if project_svc is not None:
        try:
            projects = await project_svc.list_projects()
            for p in projects:
                slug = p.get("slug", "") if isinstance(p, dict) else getattr(p, "slug", "")
                if slug:
                    project_slugs_known.add(slug)
        except Exception:
            log.debug("project list failed; skipping quiet_project insight")

    insights = compute_insights(
        verified,
        recurring_charges=recurring,
        project_slugs_known=project_slugs_known or None,
    )
    return {
        "items": [i.to_dict() for i in insights],
        "total": len(insights),
    }


# ────────────────────────────────────────────────────────────────────
# Apply merchant defaults to historical transactions — Phase 3 rule UI
# ────────────────────────────────────────────────────────────────────
@router.post("/merchants/{merchant_slug}/apply-defaults")
async def apply_merchant_defaults(
    request: Request,
    merchant_slug: str,
    body: ApplyDefaultsRequest,
) -> dict:
    """Set merchant default category/project AND apply retroactively.

    Two-in-one workflow ("custom rule"): pick a category/project on a
    Bauhaus receipt, click "Apply to all from Bauhaus" → every historical
    Bauhaus txn gets the same attribution + future receipts auto-fill via
    the SuggestionEngine's Layer A merchant-default path.

    ``apply_to_history=False`` only updates the merchant record (the
    "going-forward only" mode for users who've already manually
    categorized historical txns and don't want to overwrite them).

    Returns counts: ``{updated_txns, updated_items, merchant_updated}``.
    """
    merchants_svc = _merchants(request)
    ledger = _ledger(request)

    existing = await merchants_svc.get(merchant_slug)
    if existing is None:
        raise HTTPException(status_code=404, detail=f"Merchant not found: {merchant_slug}")

    # Update merchant record — empty string CLEARS the default.
    # `None` means "leave unchanged" (per the request shape).
    new_category = body.category_slug if body.category_slug is not None else existing.default_category
    new_project = body.project_slug if body.project_slug is not None else existing.default_project
    await merchants_svc.upsert_merchant(
        slug=merchant_slug,
        canonical_name=existing.canonical_name,
        aliases=list(existing.aliases),
        country=existing.country,
        default_category=new_category,
        default_project=new_project,
        notes=existing.notes,
        tax_id=existing.tax_id,
    )

    if not body.apply_to_history:
        return {
            "ok": True,
            "merchant_slug": merchant_slug,
            "updated_txns": 0,
            "updated_items": 0,
            "merchant_updated": True,
            "applied_to_history": False,
        }

    # Walk every verified txn for this merchant. Set txn-level project +
    # every line-item's category. Source = "user" (treat user clicking
    # "apply to all" as a deliberate manual choice, not an override of
    # an agent suggestion).
    updated_txns = 0
    updated_items = 0
    txns = await ledger.list_transactions(
        status="verified",
        merchant_slug=merchant_slug,
        limit=10000,
    )
    for t in txns:
        meta_changes = False
        # Apply project_slug at txn level when caller passed a project
        if body.project_slug is not None:
            await ledger.update_transaction_meta(
                t.txn_id,
                project_slug=body.project_slug,
                project_source="user",
            )
            meta_changes = True
        # Apply category to every line item when caller passed a category
        if body.category_slug is not None:
            for item in (t.items or ()):
                ok = await ledger.update_line_item(
                    item.item_id,
                    category_slug=body.category_slug,
                    category_source="user",
                )
                if ok:
                    updated_items += 1
        if meta_changes or body.category_slug is not None:
            updated_txns += 1

    return {
        "ok": True,
        "merchant_slug": merchant_slug,
        "updated_txns": updated_txns,
        "updated_items": updated_items,
        "merchant_updated": True,
        "applied_to_history": True,
    }


# ────────────────────────────────────────────────────────────────────
# Per-category drill-down — mirrors per-project drill-down
# ────────────────────────────────────────────────────────────────────
@router.get("/categories/{category_slug}/detail")
async def finance_category_detail(
    request: Request,
    category_slug: str,
    months_back: int = 12,
    txn_limit: int = 50,
) -> dict:
    """One-shot category-detail endpoint for /finance/categories/{slug}.

    Mirrors the project drill-down: summary totals, 12-month series, top
    merchants, top projects, linked budgets, recent transactions.

    Categories live at line-item level (each LineItem has category_slug).
    A "transaction matches" iff any of its items has the given category.
    Item amounts are attributed to the category; merchant/project rollups
    use the txn's merchant + the item's effective project (item.project_slug
    OR txn.project_slug). Special slug ``(uncategorized)`` matches items
    with empty category_slug.

    Returns 404 when the slug has neither matching transactions nor any
    linked budget — distinguishes a typo'd slug from real-but-empty.
    """
    from datetime import UTC, datetime
    from decimal import Decimal

    category_slug = (category_slug or "").strip()
    if not category_slug:
        raise HTTPException(status_code=400, detail="category_slug is required")

    ledger = _ledger(request)
    months_back = max(1, min(months_back, 24))
    txn_limit = max(1, min(txn_limit, 500))

    # Category lives on line items, so we filter txns post-hoc by
    # presence of an item matching this slug. The list_transactions
    # `category_slug` filter exists but item amounts vs txn totals
    # require post-fetch math anyway, so pull verified once and walk.
    all_verified = await ledger.list_transactions(status="verified", limit=10000)

    def _item_matches(item: Any) -> bool:
        slug = item.category_slug or "(uncategorized)"
        return slug == category_slug

    def _txn_matches(t: Any) -> bool:
        return any(_item_matches(item) for item in (t.items or ()))

    matching_txns = [t for t in all_verified if _txn_matches(t)]

    # Linked budgets — any budget targeting this category slug
    all_budgets = await ledger.list_budgets()
    cat_budgets = [
        b for b in all_budgets
        if b.scope_type == "category" and b.scope_slug == category_slug
    ]

    if not matching_txns and not cat_budgets:
        raise HTTPException(
            status_code=404,
            detail=f"No transactions or budgets for category: {category_slug}",
        )

    # ── Summary totals ───────────────────────────────────────────
    # We sum LINE-ITEM amounts (not txn totals) so a Bauhaus receipt with
    # one "tools" item and one "groceries" item only counts the tools amount.
    by_currency: dict[str, Decimal] = {}
    earliest = ""
    latest = ""
    for t in matching_txns:
        cur = (t.currency or "").upper() or "—"
        for item in (t.items or ()):
            if not _item_matches(item):
                continue
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                amt = Decimal("0.00")
            by_currency[cur] = by_currency.get(cur, Decimal("0")) + amt
        if t.txn_date:
            if not earliest or t.txn_date < earliest:
                earliest = t.txn_date
            if not latest or t.txn_date > latest:
                latest = t.txn_date

    # ── Top merchants ────────────────────────────────────────────
    merch_totals: dict[str, Decimal] = {}
    merch_counts: dict[str, int] = {}
    for t in matching_txns:
        if not t.merchant_slug:
            continue
        # Sum only the matching items' amounts for this merchant
        item_total = Decimal("0")
        for item in (t.items or ()):
            if not _item_matches(item):
                continue
            try:
                item_total += Decimal(item.amount or "0.00")
            except Exception:
                continue
        if item_total > 0 or item_total < 0:  # include refunds
            merch_totals[t.merchant_slug] = merch_totals.get(t.merchant_slug, Decimal("0")) + item_total
            merch_counts[t.merchant_slug] = merch_counts.get(t.merchant_slug, 0) + 1
    top_merchants = [
        {"slug": m, "total": f"{total:.2f}", "txn_count": merch_counts[m]}
        for m, total in sorted(merch_totals.items(), key=lambda kv: -kv[1])[:10]
    ]

    # ── Top projects ─────────────────────────────────────────────
    # Effective project per matching item: item.project_slug OR txn.project_slug
    proj_totals: dict[str, Decimal] = {}
    proj_counts: dict[str, int] = {}
    UNATTRIBUTED = "(no project)"
    for t in matching_txns:
        seen_proj: set[str] = set()
        for item in (t.items or ()):
            if not _item_matches(item):
                continue
            slug = (
                getattr(item, "project_slug", None)
                or t.project_slug
                or UNATTRIBUTED
            )
            try:
                amt = Decimal(item.amount or "0.00")
            except Exception:
                amt = Decimal("0.00")
            proj_totals[slug] = proj_totals.get(slug, Decimal("0")) + amt
            seen_proj.add(slug)
        for slug in seen_proj:
            proj_counts[slug] = proj_counts.get(slug, 0) + 1
    top_projects = [
        {"slug": p, "total": f"{total:.2f}", "txn_count": proj_counts[p]}
        for p, total in sorted(proj_totals.items(), key=lambda kv: -kv[1])[:10]
    ]

    # ── Monthly series (newest-last, anchored on today) ──────────
    today = datetime.now(UTC)
    this_ym = today.strftime("%Y-%m")
    series: list[dict] = []
    for i in range(months_back - 1, -1, -1):
        ym = _shift_month(this_ym, -i)
        month_totals: dict[str, Decimal] = {}
        month_count = 0
        for t in matching_txns:
            if not _txn_falls_in_month(t.txn_date, ym):
                continue
            cur = (t.currency or "").upper() or "—"
            had_match = False
            for item in (t.items or ()):
                if not _item_matches(item):
                    continue
                had_match = True
                try:
                    month_totals[cur] = month_totals.get(cur, Decimal("0")) + Decimal(item.amount or "0.00")
                except Exception:
                    continue
            if had_match:
                month_count += 1
        series.append({
            "month": ym,
            "spend": [
                {"currency": cur, "total": f"{amt:.2f}"}
                for cur, amt in sorted(month_totals.items())
            ],
            "txn_count": month_count,
        })

    # ── Linked budgets with consumption ──────────────────────────
    budgets_out: list[dict] = []
    for b in cat_budgets:
        consumption = await ledger.get_budget_consumption(b.budget_id)
        try:
            cap = Decimal(b.amount or "0.00")
            spent = Decimal(consumption.get("spent", "0.00") or "0.00")
            remaining = cap - spent
            pct = float(spent / cap) if cap > 0 else 0.0
        except Exception:
            pct = 0.0
            remaining = Decimal("0.00")
        budgets_out.append({
            "budget_id": b.budget_id,
            "period": b.period,
            "amount": b.amount,
            "currency": b.currency,
            "scope_type": b.scope_type,
            "scope_slug": b.scope_slug,
            "spent": consumption.get("spent", "0.00"),
            "remaining": f"{remaining:.2f}",
            "txn_count": consumption.get("txn_count", 0),
            "percent_consumed": pct,
        })

    # ── Recent transactions (newest-first, capped) ───────────────
    matching_txns.sort(key=lambda t: (t.txn_date or "", t.txn_id), reverse=True)
    recent = matching_txns[:txn_limit]
    recent_out = [
        {
            "txn_id": t.txn_id,
            "txn_date": t.txn_date,
            "merchant_slug": t.merchant_slug,
            "currency": t.currency,
            "total": t.total,
            "item_count": len(t.items or ()),
            "audit_flags": list(getattr(t, "audit_flags", []) or []),
        }
        for t in recent
    ]

    return {
        "category_slug": category_slug,
        "summary": {
            "spend": [
                {"currency": cur, "total": f"{total:.2f}"}
                for cur, total in sorted(by_currency.items())
            ],
            "txn_count": len(matching_txns),
            "earliest_date": earliest,
            "latest_date": latest,
        },
        "by_month": series,
        "top_merchants": top_merchants,
        "top_projects": top_projects,
        "budgets": budgets_out,
        "has_budget": len(budgets_out) > 0,
        "transactions": recent_out,
        "total_transactions": len(matching_txns),
        "has_more_transactions": len(matching_txns) > txn_limit,
    }
