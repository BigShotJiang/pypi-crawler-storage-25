# Shape-Aware Spec Validation — Design

**Status:** Draft
**Owner:** Bowen Li
**Date:** 2026-05-07
**Predecessor:** PR #25 — plugin-shape-aware spec generation + shape-aware dispatch (Phases 1–4)

## Background

PR #25 landed shape-aware *parsing* and *scheduling*: spec authors can declare `<feature shape="plugin">` or `<feature shape="core">`, the parser auto-derives `touches_files` for plugin-shape features, the ORM persists `shape`/`plugin` columns, and the scheduler single-flights core-shape tasks while dispatching plugin-shape tasks freely.

`claw-forge validate-spec` was not updated. As a result:

- Typos in `shape=` values silently coerce to `None` (the spec author thinks they declared shape but didn't).
- `shape="plugin"` features missing both `plugin=` and explicit `touches_files=` parse cleanly with empty `touches_files` — opting out of file-claim locking and defeating the parallel-safety guarantee.
- Cross-feature consistency (plugin vs. core glob overlap, plugin directory existence on brownfield projects, suspicious cross-shape dependency chains) is unchecked.
- Categories whose bullets read like plugins but lack shape annotation get no nudge to migrate.

The dispatcher reads these values from the DB at runtime. Coherence checks at validate time are the right place — by the time `claw-forge plan` seeds the DB, the values must already be sound.

## Goals

1. **Coherence floor.** Every `Task.shape` and `Task.touches_files` value the scheduler sees is internally consistent: declared shapes are typo-free, plugin-shape features have file footprints, core-shape features don't accidentally overlap plugin directories.
2. **Adoption ramp.** Spec authors using legacy bullets or shape-less `<feature>` elements get a non-blocking nudge toward shape annotation, with a strict mode that escalates the nudge to an error once the project has migrated.
3. **Auto-fix-first.** Every issue the validator reports has a `/fix-spec` recipe — deterministic for unambiguous cases, structured manual-review prompts for cases that require domain judgment.

## Non-goals

- Changes to `Scheduler.get_ready_tasks` or any dispatch-time behavior.
- Changes to the ORM, state-service API, or DB schema.
- Auto-detection of plugin patterns from existing source code (that's the boundaries harness).
- Auto-fixing decisions that require domain knowledge (overlap resolution, missing-directory creation).

## Design Decisions (locked)

| Decision | Choice | Rationale |
|---|---|---|
| Strictness model | **Defensive + advisory nudges + `--strict-shape` flag** | Default is back-compat; flag is the migration on-ramp for projects that have shape-annotated their spec. |
| Layer organization | **New Layer 4: Shape** | Single-purpose layer; CLI gains a fourth PASS/FAIL line; future shape rules accrete in one place. |
| Severity matrix | See [§ Severity matrix](#severity-matrix) | Per-row rationale documented inline. |
| Parser-level guards | **Preserved as hard floor** | Dispatcher reads from DB; bad values must not reach `claw-forge plan`. Validator-only enforcement is bypassable. |
| `/fix-spec` policy | **Auto-fix deterministic, surface ambiguous as Manual Review** | Honors "fix all" intent without producing wrong fixes that the user has to undo. |

## Architecture overview

```
┌─────────────────────────────────────────────────────────────────────┐
│ spec/parser.py                                                      │
│   • Tighten typo handling: unknown non-empty `shape=` raises        │
│   • Existing `core` requires `touches_files` rule unchanged         │
│                                                                     │
│ spec/validator.py                                                   │
│   • New: run_shape_checks(spec, project_root, strict)               │
│   • New: 5 check functions (1 per-feature, 2 cross-feature,         │
│     1 heuristic, 1 filesystem)                                      │
│   • Existing validate_spec() gains 2 kwargs, calls Layer 4          │
│                                                                     │
│ cli.py — validate_spec_cmd                                          │
│   • New flags: --strict-shape, --project-root                       │
│   • Auto-derive project_root from spec_path (walk up to             │
│     .claw-forge.yaml or .git); skip filesystem L4 if neither found  │
│   • New Layer 4 output block in same style as L3                    │
│   • Header summary gains: "Shape: N annotated, M unannotated"       │
│                                                                     │
│ .claude/commands/fix-spec.md                                        │
│   • New Step 0: parse-error pre-pass (typo / core missing files)    │
│   • New Layer 4 fix table (3 deterministic recipes)                 │
│   • New Manual Review block in output (gaps 3, 5, 7)                │
│                                                                     │
│ tests/                                                              │
│   • New tests/spec/test_validator_shape.py (L4 unit tests)          │
│   • New tests/test_cli_validate_spec_strict_shape.py (flag wiring)  │
│   • Extend tests/spec/test_parser.py (typo-raise case)              │
│   • Extend tests/spec/test_validator.py (validate_spec integration) │
│   • Extend tests/e2e/test_cli_e2e.py (subprocess e2e)               │
│                                                                     │
│ docs/                                                               │
│   • CLAUDE.md: add Layer 4 to the validator section                 │
│   • docs/commands.md: validate-spec gains --strict-shape entry      │
│   • README.md: spec-format example mentions shape annotation        │
└─────────────────────────────────────────────────────────────────────┘
```

**Unchanged:** `state/scheduler.py`, `state/models.py`, `state/service.py`, dispatcher and plan/run flows. The contract this work establishes: by the time a `Task.shape` value reaches the scheduler, it is coherent.

## Severity matrix

| # | Gap | Severity (default) | Severity (`--strict-shape`) | Layer / mechanism |
|---|---|---|---|---|
| 1 | `shape="plugin"` with no `plugin=` and no `touches_files` | ERROR | ERROR | L4 per-feature |
| 2 | Two `shape="plugin"` features with same `plugin=` name | (no check — normal) | — | — |
| 3 | `touches_files` overlap between core and plugin | WARNING | ERROR | L4 cross-feature |
| 4 | Typo in `shape=` value | ERROR (parse-time) | ERROR (parse-time) | Parser raises `ValueError` |
| 5 | `plugin="X"` references nonexistent directory | WARNING (brownfield only) | ERROR (brownfield only) | L4 filesystem |
| 6 | Category bullets look vertical, no shape declared | WARNING | ERROR | L4 heuristic |
| 7 | Long core-on-core `depends_on` chain (depth ≥ 4) | WARNING | WARNING | L4 graph |
| - | (existing) `shape="core"` missing `touches_files` | ERROR (parse-time) | ERROR (parse-time) | Parser raises `ValueError` |

**Notes:**

- **Gap 1 is always ERROR** — it represents a silent disable of file-claim locking, which can cause real data corruption when two parallel tasks edit the same file. Strict mode does not affect.
- **Gap 4 raises at parse time** for the same reason the existing core/touches_files rule does: the dispatcher reads from the DB; a typo'd shape that silently becomes `None` would cause the scheduler to mis-dispatch.
- **Gap 5 only fires on brownfield projects** (project root contains `src/plugins/`). Greenfield specs predate the directory structure; flagging would be noise.
- **Gap 7 is always WARNING** — long core chains are an architectural smell, not an invariant violation. Strict mode does not promote.

## Layer 4 component design

### Module layout (`claw_forge/spec/validator.py`)

```python
# Constants ----------------------------------------------------------

VERTICAL_INDICATORS = frozenset({
    "user can", "user cannot", "displays", "shows", "submits",
    "registers", "logs in", "logs out", "creates", "deletes", "edits",
})
CROSS_CUTTING_INDICATORS = frozenset({
    "every endpoint", "all endpoints", "middleware", "intercepts",
    "all requests", "globally", "across", "any plugin", "every plugin",
    "rate limit", "audit log", "metrics", "tracing",
})
VERTICAL_RATIO_THRESHOLD = 0.6
VERTICAL_MIN_BULLETS = 3
CORE_CHAIN_DEPTH_THRESHOLD = 4

# Per-feature -------------------------------------------------------

def check_plugin_shape_complete(
    feat: FeatureItem, *, strict: bool
) -> ValidationIssue | None:
    """Gap 1 — shape='plugin' must have plugin= or non-empty touches_files."""

# Cross-feature -----------------------------------------------------

def check_touches_overlap(
    spec: ProjectSpec, *, strict: bool
) -> list[ValidationIssue]:
    """Gap 3 — core feature's touches_files glob overlaps a plugin's directory."""

def check_core_chain_depth(spec: ProjectSpec) -> list[ValidationIssue]:
    """Gap 7 — depends_on chain of shape='core' features depth ≥ 4."""

# Heuristic ---------------------------------------------------------

def check_category_looks_vertical(
    category: str, feats: list[FeatureItem], *, strict: bool
) -> ValidationIssue | None:
    """Gap 6 — category bullets look vertical but no shape declared."""

# Filesystem --------------------------------------------------------

def check_plugin_dir_exists(
    feat: FeatureItem, project_root: Path, *, strict: bool, brownfield: bool
) -> ValidationIssue | None:
    """Gap 5 — plugin='X' must reference an existing directory."""

# Entrypoint --------------------------------------------------------

def run_shape_checks(
    spec: ProjectSpec,
    *,
    project_root: Path | None = None,
    strict: bool = False,
) -> ValidationReport:
    """Layer 4: architectural-shape coherence."""
```

### Glob overlap algorithm (Gap 3)

For each `shape="plugin"` feature, derive the plugin root: `f"src/plugins/{feat.plugin}/"`. For each `shape="core"` feature, check whether any of its `touches_files` globs match a representative path under each plugin root via `fnmatch.fnmatchcase(plugin_root + "__placeholder__.py", core_glob)`.

This is conservative: it catches sloppy core globs (`src/**`) that accidentally include plugin directories, and it does NOT flag legitimate non-overlaps. Subtle false-negatives are acceptable — the explicit `touches_files=` override remains the operator's escape hatch.

### Heuristic scoring (Gap 6)

For a category C with features F₁…Fₙ, **operate on the unannotated subset U = {Fᵢ : Fᵢ.shape is None}**:

1. Skip if `|U| == 0` (every feature in the category is already shape-annotated — nothing to nudge).
2. Skip if `|U| < VERTICAL_MIN_BULLETS` (sample too small to be statistically meaningful).
3. For each Fᵢ in U, scoring on Fᵢ.description (lowercased):
   - +1 if any token from `VERTICAL_INDICATORS` matches.
   - −1 if any token from `CROSS_CUTTING_INDICATORS` matches.
4. Compute `score / |U|`. Flag if ≥ `VERTICAL_RATIO_THRESHOLD`.

The flag's `bullet` field references the first unannotated feature; the message names the count and the slug-derived plugin candidate. This keeps the warning targeted: "12 unannotated bullets in Authentication category look vertical — convert them to `<feature shape='plugin' plugin='authentication'>`" rather than a category-wide critique that ignores the already-annotated half.

### Core-chain depth (Gap 7)

BFS over the dependency graph filtered to nodes where `shape == "core"`. For each connected component, find the longest chain. Flag once per component if length ≥ `CORE_CHAIN_DEPTH_THRESHOLD`. Deduplicates by component root.

## CLI surface

```python
@app.command("validate-spec")
def validate_spec_cmd(
    spec: str = typer.Argument(...),
    no_llm: bool = typer.Option(False, "--no-llm", ...),
    threshold: float = typer.Option(7.0, "--threshold", "-t", ...),
    model: str = typer.Option("claude-haiku-4-5-20251001", "--model", "-m", ...),
    strict_shape: bool = typer.Option(
        False, "--strict-shape",
        help="Promote shape WARNINGs (gaps 3, 5, 6) to ERRORs.",
    ),
    project_root: Path | None = typer.Option(
        None, "--project-root",
        help="Override auto-detected project root for filesystem-aware shape checks.",
    ),
) -> None:
```

### Project-root resolution

Helper: `_resolve_project_root(spec_path: Path, override: Path | None) -> Path | None`

1. If `override` provided, return it.
2. Walk up from `spec_path.parent` looking for `.claw-forge.yaml`, then `.git`.
3. If neither found, return `None`. Layer 4 still runs but skips `check_plugin_dir_exists`; CLI prints one dim line:
   ```
   Layer 4 (Shape): filesystem checks skipped (no project root detected — pass --project-root to enable)
   ```

### Header summary

```
Validating: app_spec.xml
  Features:   142
  Categories: 8
  Endpoints:  37
  Tables:     12
  Shape:      89 annotated, 53 unannotated      ← NEW
```

### Layer 4 output block

```
Layer 4 (Shape)       FAIL  2 errors, 4 warnings
  ✗ [auth] shape="plugin" missing plugin= and touches_files=
    → Add plugin="auth" or explicit touches_files
    Bullet: "User can register with email and password"
  ⚠ [Authentication] Category bullets look vertical but no shape declared
    → Convert to <feature shape="plugin" plugin="authentication">
  ⚠ [billing-overlap] core feature's touches_files overlaps src/plugins/billing/
    → Narrow the core glob to exclude src/plugins/billing/
  ⚠ [profile] plugin="profile" references nonexistent directory src/plugins/profile/
    → Rename plugin= or run claw-forge boundaries apply to create the directory
```

## `/fix-spec` extension

Three additions to `.claude/commands/fix-spec.md`:

### New Step 0: Handle parse-blocking errors

Runs *before* the existing main loop:

```
Run: claw-forge validate-spec <spec-file> 2>&1
If output starts with "Failed to parse spec:" then:
  - If message mentions unrecognized shape value (regex: shape='([^']+)'):
      Levenshtein-match the value against {plugin, core}. If best distance ≤ 2,
      replace in spec file. Otherwise list under Manual Review.
  - If message mentions "core requires explicit touches_files":
      List under Manual Review (can't auto-fix without domain knowledge).
  - Re-run validate-spec. If still parse-blocked, report and stop.
Else proceed to existing Step 2.
```

### New "Layer 4 fixes" table (added to Step 4)

| Issue | Severity | Fix recipe |
|---|---|---|
| Gap 1: `shape="plugin"` no `plugin=` and no `touches_files` | ERROR | Add `plugin="<category-slug>"` to the `<feature>` element. Slug: lowercase, strip non-alphanumerics, collapse whitespace to `-`. |
| Gap 6: vertical category, no shape | WARN/ERR | For each bullet in the flagged category, convert legacy bullet form to `<feature shape="plugin" plugin="<category-slug>">…<description>{bullet text}</description></feature>`. Preserve text verbatim. |
| Gap 4 typo (parse-time): `shape="ploogin"` | parse error | Levenshtein match to `{plugin, core}`. Apply if distance ≤ 2; else Manual Review. |

### New "Manual Review" output block

Appended to fix-spec output when ambiguous shape gaps remain:

```
Manual review needed (3 items):

  1. [billing] core feature touches_files overlap with src/plugins/billing/
     Feature: "All endpoints validate JWT" (touches_files: src/**)
     Question: which feature owns billing/auth.py — core or the billing plugin?
     Candidate fixes:
       a) Narrow core to src/core/**, src/middleware/**
       b) Move the plugin's auth.py to src/core/billing-auth.py
       c) Drop the overlap by excluding the plugin glob

  2. [profile] plugin="profile" references nonexistent directory
     Question: typo, or does the plugin not exist yet?
     Candidate fixes:
       a) Rename to plugin="profiles" (closest existing dir, distance 1)
       b) Override with explicit touches_files=
       c) Create src/plugins/profile/ via boundaries apply

  3. [auth-chain] depends_on chain of 5 core features
     Chain: auth-base → jwt-mw → rate-limit → audit-log → metrics
     Question: can any link be reshaped as a plugin instead of core?
     Suggestion: factor jwt-mw into a shape="plugin" plugin="jwt"
     by isolating its files to src/plugins/jwt/.
```

## Test strategy

**Unit — `tests/spec/test_validator_shape.py` (new):**
- One class per check function.
- `check_category_looks_vertical` boundary cases: 2 bullets (skip), 3 bullets all vertical (flag), 3 bullets at 0.6 ratio (flag), 3 at 0.59 (don't flag).
- `check_touches_overlap` table-driven: matrix over (core_glob, plugin_glob, expect_overlap).
- `check_core_chain_depth`: chains of length 1, 3, 4, 5; mixed core/plugin chains; diamond patterns.
- `check_plugin_dir_exists` uses `tmp_path`: brownfield, greenfield, missing dir, present dir.

**Parser change — extends `tests/spec/test_parser.py`:**
- `test_unknown_shape_raises` — `<feature shape="ploogin">` raises `ValueError`.
- `test_empty_shape_attr_still_none` — back-compat for `shape=""`.
- `test_case_normalization_still_works` — `<feature shape="PLUGIN">` parses to `"plugin"`.

**Integration — extends `tests/spec/test_validator.py`:**
- `test_validate_spec_runs_layer_4`.
- `test_strict_shape_promotes_warnings_to_errors`.
- `test_layer_4_skipped_without_project_root`.

**CLI — `tests/test_cli_validate_spec_strict_shape.py` (new):**
- `--strict-shape` flag → strict propagates → exit code reflects promoted errors.
- `--project-root` override → filesystem check uses the override path.
- Auto-detected project root via tmp dir + `.claw-forge.yaml`.
- Output contains "Layer 4 (Shape)" header line.

**E2E — extends `tests/e2e/test_cli_e2e.py`:**
- New `TestValidateSpecShape` class using existing `_invoke()` subprocess helper.
- Three fixture specs under `tests/e2e/fixtures/specs_with_shape/`:
  - `clean.xml` — fully shape-annotated; exits 0; no L4 issues.
  - `mixed.xml` — partial annotation; exits 0; L4 warnings present.
  - `bad.xml` — gap-1 missing plugin attr; exits 1; L4 error.
- `test_strict_shape_promotes` — runs `mixed.xml` twice (with/without flag), asserts exit code differs.

**Coverage budget:** new code ≈ 250 lines validator + 40 lines CLI plumbing. Per-function unit + integration + e2e tests should land coverage at 95%+ on new code. CI 90% gate is the floor.

`/fix-spec.md` is LLM-driven prose; not unit-testable. CLI/e2e tests catch divergence between validator output and the format `/fix-spec.md` parses.

## Documentation impact

- **`CLAUDE.md`** — Under the existing `spec/parser.py` section, add a Layer 4 paragraph. ~25 lines explaining the four shape gaps the validator catches and the `--strict-shape` flag.
- **`docs/commands.md`** — Under `claw-forge validate-spec`, add `--strict-shape` and `--project-root` entries. Add a "Layer 4 — Architectural shape" subsection alongside the existing L1/L2/L3 explanations.
- **`README.md`** — One sentence in the spec-format section: "Use `<feature shape='plugin' plugin='auth'>` to opt into shape-aware scheduling; `claw-forge validate-spec --strict-shape` enforces shape annotations."
- **`/fix-spec.md`** — updates land via Section 4.

## Risks and mitigations

| Risk | Mitigation |
|---|---|
| Heuristic for Gap 6 produces false positives ("e.g. an auth category that legitimately needs cross-cutting middleware bullets") | WARNING by default, not ERROR. User can ignore. Strict mode is explicit opt-in. Indicator vocabulary lives in module constants, easily tunable. |
| Gap 3 glob-overlap algorithm misses subtle overlaps | Conservative by design — false-negatives over false-positives. Operator escape hatch (explicit `touches_files=`) remains. Tests cover the boundary matrix. |
| Tightening parser to raise on unknown `shape=` values breaks existing specs | Empty string still benign (no annotation). Only non-empty unrecognized raises. Existing tests confirm back-compat. New test covers the raise. |
| `/fix-spec` Step 0 (parse-error pre-pass) infinite-loops if it can't fix | Existing 3-pass cap applies. Step 0 fails fast: if the typo can't be Levenshtein-matched to plugin/core within distance 2, it goes to Manual Review and exits without modifying. |
| Filesystem check (Gap 5) flags greenfield specs incorrectly | Brownfield-only: only fires when project root contains `src/plugins/`. Greenfield specs see no filesystem checks. |

## Out-of-scope (deferred)

- Reading plugin-root path from `.claw-forge.yaml` (currently hardcoded to `src/plugins/`). If a project uses a different layout, they pass explicit `touches_files=` per feature. Configurable plugin root is a follow-up.
- Auto-suggesting plugin names from existing source code (boundaries-harness territory).
- Validating that `<feature depends_on>` references existing feature indices (separate gap, not shape-specific).
- Performance: `check_touches_overlap` is O(plugins × core × globs); for a spec with 200 features this is sub-second. No optimization until data shows it's needed.
