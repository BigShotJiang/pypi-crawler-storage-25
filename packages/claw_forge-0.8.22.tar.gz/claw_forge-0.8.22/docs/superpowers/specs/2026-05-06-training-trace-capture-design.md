# Training-Trace Capture & Export Design

**Date:** 2026-05-06
**Status:** Approved

## Purpose

Capture the full agent trajectory (assistant turns, thinking blocks, tool
calls, tool results) from every `claw-forge run` task into the state DB,
then expose a `claw-forge export training` command that emits the corpus
as JSONL suitable for fine-tuning a smaller code-specific LLM (Qwen2.5-Coder,
DeepSeek-Coder-V2, etc.) via Unsloth or HuggingFace.

The goal is to **distill Sonnet/Opus's coding-agent behaviour into a smaller
model** by reusing the data the harness already produces during real coding
work. claw-forge owns corpus production end-to-end (capture → export →
hygiene); training, eval, and inference live outside the harness.

## Non-Goals

- No `transformers` / `peft` / `unsloth` dependency in `pyproject.toml`.
- No `claw-forge train` command. Training is a separate user-owned project.
- No model registry, artifact store, or hosted-inference layer.
- No network upload of traces. Export to local JSONL is the boundary.
- No encryption-at-rest for traces beyond what the rest of the DB already has.

## Legal / Policy Stance

Anthropic's Usage Policies prohibit using Claude outputs to develop models
that compete with Anthropic's services. This feature is designed for
**personal/internal distillation** — building a smaller model that imitates
the user's *own* Claude usage on the user's *own* code, for the user's *own*
internal use. The opt-in is two-key (`enabled` + `acknowledged_terms`) with
a first-run banner that quotes the relevant policy text. Provenance fields
on every record (model, date, claw-forge version) preserve a verifiable
lineage. **Distribution of derived models is the user's responsibility and
out of scope for this design.**

## Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                      claw-forge run                           │
│                                                                │
│  task_handler ──→ run_agent() ──→ async iterator of Messages │
│         │                                  │                  │
│         │   (1) Section 1 tap              │                  │
│         ▼                                  ▼                  │
│  record_messages() ─POST→ /sessions/{id}/events              │
│                            event_type="agent_message"        │
│                            payload = serialized SDK Message  │
└──────────────────────────────────────────────────────────────┘
                                │
                                ▼
                      .claw-forge/state.db
                      (Event table, one row per Message)
                                │
                                ▼
┌──────────────────────────────────────────────────────────────┐
│            claw-forge export training (Section 2)            │
│                                                               │
│  reader → filter → projector → redactor → splitter → JSONL  │
│  (Event)  (success/   (OpenAI    (secrets/  (train/         │
│           recovered)  tool-use)  usernames) val/test)        │
└──────────────────────────────────────────────────────────────┘
                                │
                                ▼
              user's external training pipeline
                  (Unsloth / Axolotl / trl)
                  → Qwen2.5-Coder-7B-Instruct + LoRA
                  → eval via diff-overlap on final_diff
```

## Section 1 — Capture

### Tap point

`run_agent()` in `claw_forge/agent/runner.py` stays a pure SDK wrapper. The
recording layer is added at the **caller** side — the four call sites that
already hold `session_id` and `task_id`:

- `cli.py` `task_handler` (the dispatcher's main consumer)
- `agent/runner.py:collect_result`
- `agent/runner.py:collect_structured_result`
- `plugins/bugfix.py`

Each call site wraps the message stream with `record_messages()`:

```python
stream = run_agent(prompt, ...)
if recorder_enabled:
    stream = record_messages(
        stream,
        session_id=sid,
        task_id=tid,
        state_url=state_url,
    )
async for message in stream:
    ...
```

### `record_messages` helper

New module `claw_forge/training/recorder.py`:

```python
async def record_messages(
    messages: AsyncIterator[Message],
    *,
    session_id: str,
    task_id: str,
    state_url: str,
) -> AsyncIterator[Message]:
    """Tee: POST each message to /events, then re-yield to caller.
    Recorder failures are logged but never abort the agent."""
    turn = 0
    async for message in messages:
        try:
            await _post_event(state_url, session_id, task_id, turn, message)
        except Exception:
            log.warning("trace recording failed; continuing", exc_info=True)
        turn += 1
        yield message
```

Best-effort by design: a transient state-service hiccup must never kill an
in-flight task.

### Event row schema (reuses existing `events` table)

| column | value |
|---|---|
| `session_id` | task's session |
| `task_id` | the task |
| `event_type` | `"agent_message"` (new constant) |
| `payload` | JSON dict (below) |
| `created_at` | server-side `datetime.now(UTC)` |

`payload` shape (lossless serialization of the SDK's `Message` object):

```jsonc
{
  "turn": 7,
  "kind": "AssistantMessage",
  "model": "claude-sonnet-4-5",
  "stop_reason": "tool_use",
  "content": [
    {"type": "thinking", "thinking": "Let me look at the auth module first..."},
    {"type": "tool_use", "id": "tu_01", "name": "Read",
     "input": {"file_path": "src/auth.py"}},
    {"type": "text", "text": "I'll add the JWT validation here."}
  ],
  "usage": {"input_tokens": 4231, "output_tokens": 412, "cache_read": 12000}
}
```

### Schema decisions

- **One Event row per SDK Message** (not per content-block). Preserves SDK
  semantics atomically; tool_use ↔ tool_result correlation stays implicit
  via SDK IDs.
- **Reuse the existing `Event` table.** No new table, no migration.
- **Lossless raw payload.** All projection (ChatML, ShareGPT, Qwen-Coder)
  happens at export time. Capture the superset; derive subsets later.

### One-column migration: `Task.merge_commit_sha`

Add a single nullable `String(40)` column to the `Task` model. After
`squash_merge` completes in `git/merge.py`, PATCH the resulting commit SHA
back to the task. Used by `--include-diff` at export time to attach the
canonical "ground-truth answer" diff to every successful trajectory.

### Volume estimate

Per task: ~30–150 messages × ~1–20KB payload = ~0.5–3 MB. Per 100-task
session: ~50–300 MB. SQLite handles this comfortably; retention is covered
in Section 3.

## Section 2 — Export

### Command

`claw-forge export training` (parallel to existing `claw-forge export`).
Reads `.claw-forge/state.db` directly via `sqlite3` — no state-service
dependency, safe to run while a session is active.

```
claw-forge export training
  [--scope session|all]              # default: all
  [--session UUID]
  [--filter success|recovered|both]  # default: both
  [--include-failed]                 # default: off; for DPO negatives
  [--format openai-tools|sharegpt|chatml|raw-jsonl]   # default: openai-tools
  [--include-diff]                   # default: on
  [--include-thinking]               # default: on
  [--min-turns N]                    # default: 4
  [--max-turns N]                    # default: 200
  [--redact secrets|usernames|both|none]   # default: both
  [--dedupe-by prompt|diff|both|none]      # default: both
  [--split 80/10/10]                 # default: none — emits one file
  [--out PATH]                       # default: stdout (or directory for split)
```

### Filter semantics

| Filter | SQL predicate | Trains the SLM to … |
|---|---|---|
| `success` | `status='completed' AND merged_to_target_branch=1 AND bugfix_retry_count=0` | Imitate clean expert trajectories |
| `recovered` | `status='completed' AND merged_to_target_branch=1 AND bugfix_retry_count>0` | Recover from failure; resume mid-task |
| `both` (default) | union of the above | Full distribution of expert behaviour |
| `--include-failed` | adds `status='failed'` rows tagged `outcome='failed'` | DPO/rejection-sampling negatives |

`recovered` is the underused signal — the resume preamble that
`task_handler` constructs from `branch_commit_subjects` + prior
`error_message` + `HANDOFF.md` is part of the captured stream, so the SLM
learns the full course-correction loop.

### Per-task JSONL record

```jsonc
{
  "task_id": "0a8e…",
  "session_id": "…",
  "outcome": "success",                // success | recovered | failed
  "plugin": "coding",
  "category": "auth",
  "shape": "plugin",
  "retry_count": 0,
  "metrics": {"input_tokens": 124021, "output_tokens": 8214,
              "cost_usd": 0.42, "duration_s": 187},
  "messages": [
    {"role": "system", "content": "You are a coding agent..."},
    {"role": "user",   "content": "Implement JWT validation..."},
    {"role": "assistant",
     "content": "I'll start by reading the auth module.",
     "thinking": "The user wants JWT validation. I should first…",
     "tool_calls": [{"id": "tu_01", "type": "function",
                     "function": {"name": "Read",
                                  "arguments": "{\"file_path\":\"src/auth.py\"}"}}]},
    {"role": "tool", "tool_call_id": "tu_01", "content": "<file contents…>"},
    {"role": "assistant", "content": "Now I'll add the validator."}
  ],
  "final_diff": "diff --git a/src/auth.py …",  // when --include-diff
  "merge_commit": "abc1234",
  "provenance": {
    "claude_model": "claude-sonnet-4-5",
    "captured_at": "2026-05-06T…",
    "claw_forge_version": "0.5.37",
    "redaction_rules": ["SecretsRule", "UsernamesRule"]
  }
}
```

### Format choices

| Format | When to pick |
|---|---|
| `openai-tools` (default) | Lossless; `tool_calls` + `role:tool`. Reads natively into HF `apply_chat_template(tools=...)`. The `thinking` field on assistant messages is a non-standard extension — most loaders will drop it silently; users who want to train on chain-of-thought should use `raw-jsonl` or post-process. |
| `sharegpt` | trl/Axolotl ShareGPT loader. Tool calls flatten to text (lossy). |
| `chatml` | Generic `<|im_start|>` template for non-tool-using models. |
| `raw-jsonl` | Direct dump of SDK messages; do your own templating downstream. |

### Projection (`claw_forge/training/exporter.py`)

```python
def project_task(task: Task, events: list[Event]) -> dict:
    messages = [{"role": "system", "content": _reconstruct_system_prompt(task)}]
    messages.append({"role": "user", "content": task.description_or_resume_prompt()})
    for ev in events:                       # ordered by created_at
        msg = ev.payload
        if msg["kind"] == "AssistantMessage":
            messages.append(_assistant_from_blocks(msg["content"], msg["model"]))
        elif msg["kind"] == "UserMessage":  # tool_result blocks live here
            messages.extend(_tool_results_from_blocks(msg["content"]))
        # SystemMessage / ResultMessage are skipped — SDK plumbing
    return {"task_id": task.id, "outcome": _label(task), "messages": messages, …}
```

`_assistant_from_blocks` folds `thinking` + `text` + `tool_use` blocks of one
assistant message into one OpenAI-format assistant record with
`content`, optional `thinking`, and `tool_calls[]`.

### Hygiene operations (in scope)

- **Dedupe**: `--dedupe-by prompt|diff|both|none`. Drops trajectories where
  `(user_prompt, final_diff)` already appears in the corpus. Default `both`.
- **Train/val/test split**: `--split 80/10/10`. Deterministic (seeded by
  `task_id` hash). Splits at task level (no leakage across files within a
  task). Emits `train.jsonl`, `val.jsonl`, `test.jsonl` into `--out`
  directory.

### Hygiene operations (out of scope)

- Tokenization, length filtering by tokens, model-specific template
  rendering — the user's training repo handles these.

## Section 3 — Privacy, Redaction, Retention, Opt-In

### Opt-in config (`claw-forge.yaml`)

```yaml
training_traces:
  enabled: false                  # default OFF
  acknowledged_terms: false       # default OFF — must be true to record
  redaction:
    secrets: true
    usernames: true
    paths: false
    custom_patterns: []
  retention:
    keep_days: 0                  # 0 = forever
    on_state_service_startup: true
```

### Two-key opt-in

If `enabled: true` but `acknowledged_terms: false`, the state service logs
a one-time banner with the relevant Anthropic Usage Policy excerpt and
**does not record traces**. Once `acknowledged_terms: true`, recording
begins. Both flips are logged to `state.log` for audit trail.

### Redaction (export-time, not capture-time)

Why export-time: capture-time redaction is destructive and irreversible.
Export-time lets the user re-export with different rules and keeps the local
DB authoritative. The "DB leaks while sitting on disk" threat is already
covered by the existing trust boundary (`.claw-forge/state.db` is
project-local, same trust as the source code).

Module: `claw_forge/training/redact.py`. A `Redactor` class composes rules:

| Rule | Default | Targets |
|---|---|---|
| `SecretsRule` | **on** | AWS / GCP / GitHub / Stripe / Anthropic / OpenAI key patterns; `Authorization:` headers in tool_result content; lines from `.env` / `.envrc` reads |
| `UsernamesRule` | **on** | OS username in absolute paths (`/Users/bowenli/` → `/Users/<USER>/`); preserves directory structure |
| `PathsRule` | **off** | Aggressive path anonymization (off — file structure is meaningful learning signal) |
| `HighEntropyRule` | **off** | Strings >20 chars base64-like; high false-positive rate |
| `CustomPatternsRule` | **on (empty)** | User-supplied regex list applied to all string fields |

Replacement markers are structured (`<REDACTED:secret>`, `<REDACTED:username>`)
so the SLM doesn't learn to fabricate the redacted form.

### Retention (`claw-forge traces` subcommand group)

```
claw-forge traces status                # count + disk-MB of agent_message events, by session
claw-forge traces prune [--before DATE | --keep-last N | --session UUID | --all]
                        [--dry-run]
                        [--keep-completed]   # spare events from completed/merged tasks
```

**Auto-prune at startup**: when `retention.keep_days > 0`, the state service
lifespan startup hook deletes `event_type='agent_message' AND created_at <
now - keep_days`. Cheap (indexed query), runs in the same `init_db()` pass
as WAL-checkpoint logic.

**VACUUM policy**: after `prune`, run `VACUUM` only if reclaimable space
exceeds 100 MB (rewriting the entire DB file isn't free).

### Provenance stamping

Every JSONL record gets:

```jsonc
"provenance": {
  "claude_model": "claude-sonnet-4-5",
  "captured_at": "2026-05-06T…",
  "claw_forge_version": "0.5.37",
  "redaction_rules": ["SecretsRule", "UsernamesRule"]
}
```

Verifiable lineage: "this trace came from my Claude usage, on date X, on
my own code."

## Section 4 — Fine-Tuning Recipe & Scope Boundary

### claw-forge stops at JSONL export

In scope:

- Capture, export, redaction, retention.
- Dedupe + train/val/test split at the JSONL layer.
- A worked-example recipe doc at `docs/training/unsloth-recipe.md`.

Out of scope:

- Tokenization, fine-tuning, eval, model serving.
- No `transformers` / `peft` / `unsloth` deps in `pyproject.toml`.
- No `claw-forge train` command.

### Recipe doc — `docs/training/unsloth-recipe.md`

Reference setup (not enforced; users may swap any piece):

**Base model** — `unsloth/Qwen2.5-Coder-7B-Instruct-bnb-4bit`. Coder-specialised,
native tool-use chat template, Apache-2.0 licence, fits a 24 GB consumer GPU.
DeepSeek-Coder-V2-Lite-Instruct noted as alternative (better raw eval scores
but MoE is finicky for LoRA).

**LoRA config:**

```python
r=16, alpha=32,
target_modules=["q_proj","k_proj","v_proj","o_proj",
                "gate_proj","up_proj","down_proj"],
lora_dropout=0.0,
```

**Training args:**

```python
per_device_train_batch_size=2, grad_accum=8,    # effective batch 16
num_train_epochs=3, learning_rate=2e-4,
warmup_ratio=0.03, lr_scheduler_type="cosine",
optim="adamw_8bit", max_seq_length=8192,
```

Wall-time depends heavily on token distribution and packing; for ~500
trajectories at avg 6 K tokens each, expect single-digit hours on a 4090.
Calibrate with a 50-task dry run before committing to a full run.

**Eval (on `test.jsonl` from the split):**

- ROUGE-L on `assistant` content (reasoning quality).
- **Diff similarity** between the model's reconstructed final patch and the
  captured `final_diff`. Concrete metric: reconstruct the model's proposed
  patch from its `tool_calls` (Edit / Write blocks), then score with
  line-level Jaccard plus `difflib.SequenceMatcher` ratio against
  `final_diff`. This is the real correctness signal — whether the model
  proposes the same code change the expert eventually landed.

**Phase 2 (note only)**: `final_diff` unlocks DPO / rejection-sampling. K
candidate completions per prompt → score by diff similarity with ground
truth → preference pairs → DPO step. Corpus is already structured for this.

## File-Level Changes Summary

| File | Change | Why |
|---|---|---|
| `claw_forge/training/__init__.py` | new | Module root |
| `claw_forge/training/recorder.py` | new | `record_messages()` tee helper |
| `claw_forge/training/exporter.py` | new | `claw-forge export training` core: read events → filter → project → emit JSONL |
| `claw_forge/training/redact.py` | new | `Redactor` class + `SecretsRule` / `UsernamesRule` / `CustomPatternsRule` |
| `claw_forge/training/cli.py` | new | Typer subapp: `claw-forge traces status \| prune` |
| `claw_forge/state/models.py` | `Task.merge_commit_sha` column added | Ground-truth diff lookup |
| `claw_forge/git/merge.py` | PATCH `merge_commit_sha` after squash | Hooks ground-truth diff into the corpus |
| `claw_forge/cli.py` (4 call sites) | wrap `run_agent` stream with `record_messages` when `training_traces.enabled` | Capture |
| `claw_forge/cli.py` `export` | new `training` subcommand | Export entrypoint |
| `claw_forge/cli.py` | register `traces` subapp | Retention entrypoint |
| `claw_forge/state/service.py` | startup hook: auto-prune when `retention.keep_days > 0` | Retention |
| `claw_forge/config.py` | `training_traces` config block + two-key opt-in validation | Opt-in |
| `claw_forge.yaml` template | new `training_traces` block (default OFF) | Discoverability |
| `docs/commands.md` | new `claw-forge export training` + `claw-forge traces` sections | Docs |
| `docs/training/unsloth-recipe.md` | new | Worked example |
| `CLAUDE.md` | append "Training-Trace Capture" section under Architecture | Architecture overview |
| `tests/training/test_recorder.py` | new | Tee semantics + best-effort failure |
| `tests/training/test_exporter.py` | new | Filter / projection / dedupe / split |
| `tests/training/test_redact.py` | new | Each rule + replacement markers |

## Open Questions / Future Work

- **Schema evolution.** Today's payload is "whatever the SDK Message
  serializes to." If the SDK changes its Message shape, old traces still
  parse but new traces look different. Acceptable for now; revisit if it
  becomes a corpus-mixing pain point.
- **Cross-project corpus mixing.** Each project has its own state.db.
  Combining corpora across projects is `cat *.jsonl` — works fine for SFT
  but the `provenance.claude_model` field should be checked first to avoid
  mixing teacher models inadvertently.
- **DPO phase 2.** Out of scope for this design but the schema is
  forward-compatible. `final_diff` + `outcome=failed` traces are the
  preference-pair substrate.
- **Boundary refactors as training data.** The boundaries-harness
  (`claw_forge/boundaries/`) produces refactor trajectories with their own
  squash-merge commits. They flow through this pipeline unchanged — a nice
  bonus.
