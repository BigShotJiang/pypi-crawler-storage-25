"""End-to-end tests for the ``.env file → claw-forge.yaml → ProviderConfig
→ ProviderPoolManager`` chain.

Pre-existing tests in ``test_cli_commands.py`` cover ``_expand_env_vars``
syntax (``${VAR}`` and ``${VAR:-default}``) in isolation, but never run
the full chain that drives ``claw-forge run`` — yaml on disk + .env on
disk + provider construction + pool routing.  This file plugs that gap.

Specifically guards against the v0.8.x debug session's regression class
where multi-OAuth-token setups looked broken in the activity log: any
break in this chain (env-loader silently dropping a line, interpolation
mishandling underscores, pool ignoring ``oauth_token``, etc.) would now
fail loudly here instead of silently shipping with one credential pinned
to all agents.
"""
from __future__ import annotations

import os
import sys
import types
from pathlib import Path

# ``claw-forge.cli`` imports ``claude_agent_sdk.types`` transitively.  When
# this file is collected before any test that loads the real package, the
# subpackage import fails — same workaround as ``test_pool_toggle.py``.
if "claude_agent_sdk" not in sys.modules:
    sys.modules["claude_agent_sdk"] = types.ModuleType("claude_agent_sdk")

import pytest

# ── _load_env_file: parses .env format ──────────────────────────────────


class TestLoadEnvFile:
    """``_load_env_file(directory)`` reads ``directory/.env`` and seeds
    ``os.environ`` with the contained KEY=VAL lines.  Used by
    ``_load_config`` so yaml ``${VAR}`` placeholders resolve from the
    project's ``.env`` without the user having to ``source`` it."""

    def test_loads_simple_key_value_lines(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from claw_forge.cli import _load_env_file

        (tmp_path / ".env").write_text(
            "OAUTH_TOKEN_A=sk-ant-oauth-aaa\n"
            "OAUTH_TOKEN_B=sk-ant-oauth-bbb\n"
        )
        monkeypatch.delenv("OAUTH_TOKEN_A", raising=False)
        monkeypatch.delenv("OAUTH_TOKEN_B", raising=False)
        _load_env_file(tmp_path)
        assert os.environ["OAUTH_TOKEN_A"] == "sk-ant-oauth-aaa"
        assert os.environ["OAUTH_TOKEN_B"] == "sk-ant-oauth-bbb"

    def test_skips_comments_and_blanks(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from claw_forge.cli import _load_env_file

        (tmp_path / ".env").write_text(
            "# comment line\n"
            "\n"
            "OAUTH_TOKEN_X=value\n"
            "  \n"
            "  # indented comment\n"
        )
        monkeypatch.delenv("OAUTH_TOKEN_X", raising=False)
        _load_env_file(tmp_path)
        assert os.environ["OAUTH_TOKEN_X"] == "value"

    def test_setdefault_semantics_shell_wins(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If the shell already has the variable set, ``.env`` does NOT
        override.  This is the documented ``setdefault`` semantics — gives
        operators a way to override per-shell without editing ``.env``."""
        from claw_forge.cli import _load_env_file

        (tmp_path / ".env").write_text("OAUTH_TOKEN_A=from-dotenv\n")
        monkeypatch.setenv("OAUTH_TOKEN_A", "from-shell")
        _load_env_file(tmp_path)
        assert os.environ["OAUTH_TOKEN_A"] == "from-shell"

    def test_missing_env_file_is_silent_no_op(self, tmp_path: Path) -> None:
        from claw_forge.cli import _load_env_file
        # No .env in tmp_path — must not raise.
        _load_env_file(tmp_path)

    def test_handles_equals_in_value(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """OAuth tokens commonly contain ``=`` characters.  ``partition('=')``
        keeps the trailing ``=`` in the value; round-trip preserves it."""
        from claw_forge.cli import _load_env_file

        (tmp_path / ".env").write_text("OAUTH_TOKEN=sk-ant-oauth-pad==\n")
        monkeypatch.delenv("OAUTH_TOKEN", raising=False)
        _load_env_file(tmp_path)
        assert os.environ["OAUTH_TOKEN"] == "sk-ant-oauth-pad=="


# ── _load_config: yaml + .env interpolation ─────────────────────────────


class TestLoadConfigInterpolatesEnvFromDotEnv:
    """``_load_config(yaml_path)`` reads the yaml, auto-loads
    ``yaml_path.parent/.env``, and recursively substitutes ``${VAR}``
    placeholders.  This is the single funnel every ``claw-forge`` command
    uses to materialise its config — the ``.env`` → yaml hand-off must
    work for OAuth tokens to actually reach the pool."""

    def test_oauth_token_placeholder_resolved_from_dotenv(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from claw_forge.cli import _load_config

        (tmp_path / ".env").write_text(
            "OAUTH_TOKEN_A=sk-ant-oauth-aaa\n"
            "OAUTH_TOKEN_B=sk-ant-oauth-bbb\n"
        )
        (tmp_path / "claw-forge.yaml").write_text(
            "providers:\n"
            "  claude-oauth-1:\n"
            "    type: anthropic_oauth\n"
            "    oauth_token: ${OAUTH_TOKEN_A}\n"
            "    enabled: true\n"
            "  claude-oauth-2:\n"
            "    type: anthropic_oauth\n"
            "    oauth_token: ${OAUTH_TOKEN_B}\n"
            "    enabled: true\n"
        )
        monkeypatch.delenv("OAUTH_TOKEN_A", raising=False)
        monkeypatch.delenv("OAUTH_TOKEN_B", raising=False)

        cfg = _load_config(str(tmp_path / "claw-forge.yaml"))
        assert cfg["providers"]["claude-oauth-1"]["oauth_token"] == "sk-ant-oauth-aaa"
        assert cfg["providers"]["claude-oauth-2"]["oauth_token"] == "sk-ant-oauth-bbb"


# ── End-to-end: .env → ProviderConfig → ProviderPoolManager ─────────────


class TestEndToEndOauthChainReachesPool:
    """The user's specific concern: "OAuth tokens defined in .env are not
    being used".  Verify the full chain from ``.env`` on disk to
    ``next_provider_for_dispatch().config.oauth_token`` actually carries
    the token through every layer.

    Any silent break in this chain (env-loader, yaml interpolation,
    ``load_configs_from_yaml``, ``ProviderPoolManager.from_config``,
    ``Router.select`` filtering) would fail one of these assertions.
    """

    def _write_fengshui_like_setup(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Mirror the fengshui yaml + .env shape: 1 disabled api_key
        provider + 3 enabled OAuth providers, round_robin strategy."""
        (tmp_path / ".env").write_text(
            "OAUTH_TOKEN_A=oauth-aaa-token\n"
            "OAUTH_TOKEN_B=oauth-bbb-token\n"
            "OAUTH_TOKEN_C=oauth-ccc-token\n"
        )
        (tmp_path / "claw-forge.yaml").write_text(
            "pool:\n"
            "  strategy: round_robin\n"
            "providers:\n"
            "  anthropic-direct:\n"
            "    type: anthropic\n"
            "    api_key: ${ANTHROPIC_API_KEY}\n"
            "    enabled: false\n"
            "    priority: 2\n"
            "  claude-oauth-1:\n"
            "    type: anthropic_oauth\n"
            "    oauth_token: ${OAUTH_TOKEN_A}\n"
            "    enabled: true\n"
            "    priority: 1\n"
            "  claude-oauth-2:\n"
            "    type: anthropic_oauth\n"
            "    oauth_token: ${OAUTH_TOKEN_B}\n"
            "    enabled: true\n"
            "    priority: 1\n"
            "  claude-oauth-3:\n"
            "    type: anthropic_oauth\n"
            "    oauth_token: ${OAUTH_TOKEN_C}\n"
            "    enabled: true\n"
            "    priority: 1\n"
        )
        for k in ("OAUTH_TOKEN_A", "OAUTH_TOKEN_B", "OAUTH_TOKEN_C", "ANTHROPIC_API_KEY"):
            monkeypatch.delenv(k, raising=False)

    def test_load_configs_from_yaml_carries_oauth_tokens(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """ProviderConfig instances built from the loaded yaml carry the
        resolved OAuth tokens — not the raw ``${VAR}`` placeholder, not
        an empty string."""
        from claw_forge.cli import _load_config
        from claw_forge.pool.providers.registry import load_configs_from_yaml

        self._write_fengshui_like_setup(tmp_path, monkeypatch)
        cfg = _load_config(str(tmp_path / "claw-forge.yaml"))
        configs = load_configs_from_yaml(cfg)

        by_name = {c.name: c for c in configs}
        # Disabled provider with missing api_key — empty string, but config
        # still loaded so the user can flip ``enabled: true`` later without
        # restarting.
        assert by_name["anthropic-direct"].enabled is False
        assert by_name["anthropic-direct"].api_key == ""
        # All 3 OAuth providers loaded with their resolved tokens.
        assert by_name["claude-oauth-1"].enabled is True
        assert getattr(by_name["claude-oauth-1"], "oauth_token", "") == "oauth-aaa-token"
        assert by_name["claude-oauth-2"].enabled is True
        assert getattr(by_name["claude-oauth-2"], "oauth_token", "") == "oauth-bbb-token"
        assert by_name["claude-oauth-3"].enabled is True
        assert getattr(by_name["claude-oauth-3"], "oauth_token", "") == "oauth-ccc-token"

    def test_pool_dispatch_picker_returns_provider_with_oauth_token(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Round-robin pool dispatches across all 3 OAuth providers AND
        each picked provider's ``config.oauth_token`` is the resolved
        token from ``.env`` — exactly what the SDK env-cred picker in
        ``cli.py`` (post-v0.8.11) reads to seed ``ANTHROPIC_AUTH_TOKEN``
        per agent task.  (Note: through v0.8.10 this was wired to
        ``ANTHROPIC_SETUP_TOKEN`` instead, which the Claude CLI silently
        ignored — see ``test_resolve_sdk_credentials.py`` for the
        regression test that locks in the correct env var.)"""
        from claw_forge.cli import _load_config
        from claw_forge.pool.manager import ProviderPoolManager
        from claw_forge.pool.providers.registry import load_configs_from_yaml

        self._write_fengshui_like_setup(tmp_path, monkeypatch)
        cfg = _load_config(str(tmp_path / "claw-forge.yaml"))
        configs = load_configs_from_yaml(cfg)
        pool = ProviderPoolManager.from_config(configs, cfg)
        assert pool is not None

        expected_tokens = {
            "claude-oauth-1": "oauth-aaa-token",
            "claude-oauth-2": "oauth-bbb-token",
            "claude-oauth-3": "oauth-ccc-token",
        }

        # 6 picks across 3 enabled OAuth providers under round_robin →
        # each name appears exactly twice and ``anthropic-direct`` is
        # never picked (filtered out by enabled=False).
        seen: dict[str, int] = {}
        for _ in range(6):
            p = pool.next_provider_for_dispatch()
            assert p is not None
            assert p.name != "anthropic-direct", (
                "disabled provider must be filtered out of dispatch"
            )
            tok = getattr(p.config, "oauth_token", "")
            assert tok == expected_tokens[p.name], (
                f"oauth_token mismatch for {p.name}: "
                f"expected {expected_tokens[p.name]!r}, got {tok!r}"
            )
            seen[p.name] = seen.get(p.name, 0) + 1
        assert seen == {n: 2 for n in expected_tokens}, (
            f"round_robin distribution drift: {seen}"
        )

    def test_oauth_provider_unavailable_when_dotenv_var_missing(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """If the operator forgot to set ``OAUTH_TOKEN_A`` in ``.env`` (or
        the var name is misspelled), the resulting ProviderConfig has
        ``oauth_token=""`` — and the SDK env-cred picker will skip it and
        fall through to the next provider rather than seeding empty creds."""
        from claw_forge.cli import _load_config
        from claw_forge.pool.providers.registry import load_configs_from_yaml

        # Only OAUTH_TOKEN_B is set — A is missing entirely.
        (tmp_path / ".env").write_text("OAUTH_TOKEN_B=oauth-bbb-token\n")
        (tmp_path / "claw-forge.yaml").write_text(
            "providers:\n"
            "  claude-oauth-1:\n"
            "    type: anthropic_oauth\n"
            "    oauth_token: ${OAUTH_TOKEN_A}\n"
            "    enabled: true\n"
            "  claude-oauth-2:\n"
            "    type: anthropic_oauth\n"
            "    oauth_token: ${OAUTH_TOKEN_B}\n"
            "    enabled: true\n"
        )
        for k in ("OAUTH_TOKEN_A", "OAUTH_TOKEN_B"):
            monkeypatch.delenv(k, raising=False)

        cfg = _load_config(str(tmp_path / "claw-forge.yaml"))
        configs = load_configs_from_yaml(cfg)
        by_name = {c.name: c for c in configs}
        assert getattr(by_name["claude-oauth-1"], "oauth_token", "") == ""
        assert getattr(by_name["claude-oauth-2"], "oauth_token", "") == "oauth-bbb-token"
