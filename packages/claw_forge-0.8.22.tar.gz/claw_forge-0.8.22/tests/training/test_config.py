"""Tests for the training_traces config block."""
from __future__ import annotations

from claw_forge.training.config import (
    TrainingTracesConfig,
    extract_training_traces_config,
)


def test_default_off() -> None:
    cfg = extract_training_traces_config({})
    assert cfg.enabled is False
    assert cfg.acknowledged_terms is False
    assert cfg.recording_active is False


def test_enabled_only_does_not_activate() -> None:
    cfg = extract_training_traces_config({"training_traces": {"enabled": True}})
    assert cfg.enabled is True
    assert cfg.acknowledged_terms is False
    assert cfg.recording_active is False


def test_both_flags_activate() -> None:
    cfg = extract_training_traces_config({
        "training_traces": {"enabled": True, "acknowledged_terms": True},
    })
    assert cfg.recording_active is True


def test_redaction_defaults() -> None:
    cfg = extract_training_traces_config({"training_traces": {"enabled": True}})
    assert cfg.redaction_secrets is True
    assert cfg.redaction_usernames is True
    assert cfg.redaction_paths is False
    assert cfg.redaction_custom_patterns == []


def test_retention_defaults() -> None:
    cfg = extract_training_traces_config({})
    assert cfg.retention_keep_days == 0
    assert cfg.retention_on_startup is True


def test_retention_overrides() -> None:
    cfg = extract_training_traces_config({
        "training_traces": {
            "retention": {"keep_days": 30, "on_state_service_startup": False},
        },
    })
    assert cfg.retention_keep_days == 30
    assert cfg.retention_on_startup is False


def test_custom_patterns_pass_through() -> None:
    cfg = extract_training_traces_config({
        "training_traces": {
            "redaction": {"custom_patterns": [r"FOO-\d+", r"customer-\d+"]},
        },
    })
    assert cfg.redaction_custom_patterns == [r"FOO-\d+", r"customer-\d+"]


def test_frozen_dataclass() -> None:
    """Config is immutable so consumers can hash / share without surprises."""
    import dataclasses

    cfg = extract_training_traces_config({})
    with pytest.raises(dataclasses.FrozenInstanceError):
        cfg.enabled = True  # type: ignore[misc]


# ── A6: enabled-but-not-acknowledged banner ─────────────────────────────────


def test_banner_when_enabled_but_not_acknowledged() -> None:
    from claw_forge.training.config import banner_message_for

    cfg = TrainingTracesConfig(enabled=True, acknowledged_terms=False)
    msg = banner_message_for(cfg)
    assert msg is not None
    assert "acknowledged_terms" in msg
    assert "Anthropic" in msg


def test_no_banner_when_off() -> None:
    from claw_forge.training.config import banner_message_for

    assert banner_message_for(TrainingTracesConfig()) is None


def test_no_banner_when_active() -> None:
    from claw_forge.training.config import banner_message_for

    cfg = TrainingTracesConfig(enabled=True, acknowledged_terms=True)
    assert banner_message_for(cfg) is None


import pytest  # noqa: E402  (used by the FrozenInstanceError test only)
