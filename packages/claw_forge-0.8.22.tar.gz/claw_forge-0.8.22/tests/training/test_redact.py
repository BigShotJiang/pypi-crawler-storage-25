"""Tests for export-time redaction (C1, C2)."""
from __future__ import annotations

from claw_forge.training.redact import (
    CustomPatternsRule,
    Redactor,
    SecretsRule,
    UsernamesRule,
)

# ── C1: SecretsRule ─────────────────────────────────────────────────────────


def test_secrets_rule_redacts_aws_key() -> None:
    rule = SecretsRule()
    text = "AWS key is AKIAIOSFODNN7EXAMPLE in prod"
    out = rule.apply_text(text)
    assert "AKIA" not in out
    assert "<REDACTED:secret>" in out


def test_secrets_rule_redacts_github_token() -> None:
    rule = SecretsRule()
    text = "token: ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789"
    out = rule.apply_text(text)
    assert "ghp_" not in out
    assert "<REDACTED:secret>" in out


def test_secrets_rule_redacts_authorization_header_value() -> None:
    rule = SecretsRule()
    text = "Authorization: Bearer sk-abc123def456ghi789jkl012mno345pqr678"
    out = rule.apply_text(text)
    assert "sk-abc123" not in out


def test_secrets_rule_redacts_anthropic_key() -> None:
    rule = SecretsRule()
    text = "ANTHROPIC_API_KEY=sk-ant-api03-abcdefghijklmnopqrstuvwxyz0123456789ABCDEF"
    out = rule.apply_text(text)
    assert "sk-ant-api03" not in out


def test_redactor_walks_nested_record() -> None:
    redactor = Redactor(rules=[SecretsRule()])
    rec = {
        "messages": [
            {"role": "user", "content": "AKIAIOSFODNN7EXAMPLE in env"},
            {"role": "tool", "content": [{"text": "ghp_aBcDeFgHiJkLmNoPqRsTuVwXyZ0123456789"}]},
        ],
        "task_id": "t1",
    }
    out = redactor.apply(rec)
    assert "AKIA" not in str(out)
    assert "ghp_" not in str(out)
    assert out["task_id"] == "t1"


def test_redactor_no_rules_is_identity() -> None:
    redactor = Redactor(rules=[])
    rec = {"a": "b", "c": [1, 2]}
    assert redactor.apply(rec) == rec


# ── C2: UsernamesRule + CustomPatternsRule ──────────────────────────────────


def test_usernames_rule_substitutes_home_dir() -> None:
    rule = UsernamesRule(username="bowenli")
    text = "see /Users/bowenli/development/claw-forge/src/auth.py for context"
    out = rule.apply_text(text)
    assert "bowenli" not in out
    assert "<REDACTED:username>" in out
    assert "/development/claw-forge/src/auth.py" in out


def test_usernames_rule_handles_linux_home() -> None:
    rule = UsernamesRule(username="alice")
    text = "logs at /home/alice/.local/state/claw-forge.log"
    out = rule.apply_text(text)
    assert "alice" not in out
    assert "/home/<REDACTED:username>/.local/state/claw-forge.log" in out


def test_usernames_rule_no_username_is_no_op() -> None:
    rule = UsernamesRule(username="")
    text = "/Users/somebody/x.py"
    assert rule.apply_text(text) == text


def test_custom_patterns_rule() -> None:
    rule = CustomPatternsRule(patterns=[r"customer-\d+", r"INTERNAL-[A-Z0-9]+"])
    text = "ticket customer-12345 and order INTERNAL-ABC1"
    out = rule.apply_text(text)
    assert "customer-12345" not in out
    assert "INTERNAL-ABC1" not in out
    assert "<REDACTED:custom>" in out


def test_redactor_with_all_rules_chains() -> None:
    redactor = Redactor(rules=[
        SecretsRule(),
        UsernamesRule(username="bowenli"),
        CustomPatternsRule(patterns=[r"FOO-\d+"]),
    ])
    rec = {"x": "AKIAIOSFODNN7EXAMPLE in /Users/bowenli/dir for FOO-9"}
    out = redactor.apply(rec)
    assert "AKIA" not in out["x"]
    assert "bowenli" not in out["x"]
    assert "FOO-9" not in out["x"]
