"""Tests for `claw-forge export training` CLI."""
from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner


def _seed_minimal_db(db: Path) -> None:
    """Seed the same shape as tests/training/test_exporter.py uses."""
    db.parent.mkdir(parents=True, exist_ok=True)
    from tests.training.test_exporter import _seed_db
    _seed_db(db)


def test_export_training_emits_jsonl(tmp_path: Path) -> None:
    db = tmp_path / ".claw-forge" / "state.db"
    _seed_minimal_db(db)
    out = tmp_path / "train.jsonl"

    # Import the export_app subapp directly to avoid the top-level cli's
    # SDK import chain (which is fragile under pytest collection).
    from claw_forge.export_cli import export_app

    runner = CliRunner()
    res = runner.invoke(export_app, [
        "training",
        "--scope", "all", "--filter", "both",
        "--format", "openai-tools",
        "--out", str(out),
        "--project", str(tmp_path),
        "--no-include-diff",       # avoid git show against a non-repo tmp_path
        "--min-turns", "0",        # seeded events are 1 message each
    ])
    assert res.exit_code == 0, res.output
    lines = out.read_text().splitlines()
    assert len(lines) == 2
    parsed = [json.loads(line) for line in lines]
    assert {p["outcome"] for p in parsed} == {"success", "recovered"}
    assert all("messages" in p for p in parsed)


def test_export_training_split_writes_three_files(tmp_path: Path) -> None:
    db = tmp_path / ".claw-forge" / "state.db"
    _seed_minimal_db(db)

    from claw_forge.export_cli import export_app

    out_dir = tmp_path / "split"
    runner = CliRunner()
    res = runner.invoke(export_app, [
        "training", "--scope", "all",
        "--split", "80/10/10",
        "--out", str(out_dir),
        "--project", str(tmp_path),
        "--no-include-diff",
        "--min-turns", "0",
    ])
    assert res.exit_code == 0, res.output
    assert (out_dir / "train.jsonl").exists()
    assert (out_dir / "val.jsonl").exists()
    assert (out_dir / "test.jsonl").exists()
