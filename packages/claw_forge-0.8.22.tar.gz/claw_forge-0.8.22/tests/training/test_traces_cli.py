"""Tests for ``claw-forge traces`` subapp + auto-prune (C3, C4)."""
from __future__ import annotations

import sqlite3
from datetime import UTC, datetime, timedelta
from pathlib import Path

from typer.testing import CliRunner

# Import the subapp directly — `claw_forge.cli` pulls the SDK transitively,
# which makes pytest collection fragile. The subapp is the actual code under
# test anyway; integration through the top-level app is exercised by the
# manual smoke step in W1.
from claw_forge.training.cli import traces_app


def _seed_db_with_events(db: Path, n_events: int = 5) -> None:
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db)
    conn.executescript("""
        CREATE TABLE sessions (id TEXT PRIMARY KEY, project_path TEXT, status TEXT,
                               created_at TEXT, manifest_json TEXT);
        CREATE TABLE tasks (id TEXT PRIMARY KEY, session_id TEXT, plugin_name TEXT,
                            status TEXT, merged_to_target_branch INTEGER,
                            bugfix_retry_count INTEGER, merge_commit_sha TEXT,
                            created_at TEXT);
        CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT,
                             session_id TEXT, task_id TEXT, event_type TEXT,
                             payload TEXT, created_at TEXT);
    """)
    now = datetime.now(UTC)
    conn.execute(
        "INSERT INTO sessions VALUES ('s', '/tmp', 'active', ?, '{}')",
        (now.isoformat(),),
    )
    conn.execute(
        "INSERT INTO tasks VALUES ('t', 's', 'coding', 'completed', 1, 0, 'abc', ?)",
        (now.isoformat(),),
    )
    for i in range(n_events):
        ts = (now - timedelta(days=i * 10)).isoformat()
        conn.execute(
            "INSERT INTO events (session_id, task_id, event_type, payload, created_at) "
            "VALUES (?,?,?,?,?)",
            ("s", "t", "agent_message", '{"turn": 0}', ts),
        )
    conn.commit()
    conn.close()


# ── C3: status + prune subcommands ──────────────────────────────────────────


def test_traces_status_reports_counts(tmp_path: Path) -> None:
    db = tmp_path / ".claw-forge" / "state.db"
    _seed_db_with_events(db, n_events=5)
    runner = CliRunner()
    res = runner.invoke(traces_app, ["status", "--project", str(tmp_path)])
    assert res.exit_code == 0, res.output
    assert "5" in res.output
    assert "agent_message" in res.output


def test_traces_prune_keep_last(tmp_path: Path) -> None:
    db = tmp_path / ".claw-forge" / "state.db"
    _seed_db_with_events(db, n_events=5)
    runner = CliRunner()
    res = runner.invoke(traces_app, [
        "prune", "--keep-last", "2", "--project", str(tmp_path),
    ])
    assert res.exit_code == 0, res.output
    conn = sqlite3.connect(db)
    n = conn.execute(
        "SELECT COUNT(*) FROM events WHERE event_type='agent_message'"
    ).fetchone()[0]
    conn.close()
    assert n == 2


def test_traces_prune_dry_run_does_not_delete(tmp_path: Path) -> None:
    db = tmp_path / ".claw-forge" / "state.db"
    _seed_db_with_events(db, n_events=5)
    runner = CliRunner()
    res = runner.invoke(traces_app, [
        "prune", "--keep-last", "1", "--dry-run",
        "--project", str(tmp_path),
    ])
    assert res.exit_code == 0, res.output
    conn = sqlite3.connect(db)
    n = conn.execute(
        "SELECT COUNT(*) FROM events WHERE event_type='agent_message'"
    ).fetchone()[0]
    conn.close()
    assert n == 5


def test_traces_prune_before_date(tmp_path: Path) -> None:
    db = tmp_path / ".claw-forge" / "state.db"
    _seed_db_with_events(db, n_events=5)  # events at days 0, 10, 20, 30, 40 ago
    cutoff = (datetime.now(UTC) - timedelta(days=25)).isoformat()
    runner = CliRunner()
    res = runner.invoke(traces_app, [
        "prune", "--before", cutoff, "--project", str(tmp_path),
    ])
    assert res.exit_code == 0, res.output
    conn = sqlite3.connect(db)
    n = conn.execute(
        "SELECT COUNT(*) FROM events WHERE event_type='agent_message'"
    ).fetchone()[0]
    conn.close()
    assert n == 3  # days 0, 10, 20 kept; 30, 40 pruned


# ── C4: auto-prune at state-service startup ────────────────────────────────


def test_auto_prune_old_traces(tmp_path: Path) -> None:
    """When training_traces.retention.keep_days > 0, the helper deletes old events."""
    db = tmp_path / "state.db"
    _seed_db_with_events(db, n_events=5)

    config = {
        "training_traces": {
            "retention": {"keep_days": 25, "on_state_service_startup": True},
        },
    }
    from claw_forge.state.service import auto_prune_old_traces

    deleted = auto_prune_old_traces(db, config=config)
    assert deleted == 2  # 30 and 40 days ago

    conn = sqlite3.connect(db)
    n = conn.execute(
        "SELECT COUNT(*) FROM events WHERE event_type='agent_message'"
    ).fetchone()[0]
    conn.close()
    assert n == 3


def test_auto_prune_no_op_when_disabled(tmp_path: Path) -> None:
    db = tmp_path / "state.db"
    _seed_db_with_events(db, n_events=3)
    from claw_forge.state.service import auto_prune_old_traces

    deleted = auto_prune_old_traces(db, config={})
    assert deleted == 0


def test_auto_prune_no_op_on_missing_db(tmp_path: Path) -> None:
    from claw_forge.state.service import auto_prune_old_traces

    deleted = auto_prune_old_traces(tmp_path / "nonexistent.db", config={
        "training_traces": {"retention": {"keep_days": 1}},
    })
    assert deleted == 0
