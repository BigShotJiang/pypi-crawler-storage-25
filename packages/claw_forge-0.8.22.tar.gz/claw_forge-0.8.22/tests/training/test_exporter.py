"""Tests for training-trace export (B1-B5)."""
from __future__ import annotations

import json
import sqlite3
from datetime import UTC, datetime
from pathlib import Path

import pytest


def _seed_db(db: Path) -> None:
    """Build a state.db with three tasks (success, recovered, failed) and
    one agent_message event each. Schema mirrors what AgentStateService creates."""
    db.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db)
    conn.executescript("""
        CREATE TABLE sessions (id TEXT PRIMARY KEY, project_path TEXT, status TEXT,
                               created_at TEXT, manifest_json TEXT);
        CREATE TABLE tasks (id TEXT PRIMARY KEY, session_id TEXT, plugin_name TEXT,
                            description TEXT, status TEXT, priority INTEGER,
                            depends_on TEXT, category TEXT, steps TEXT,
                            result_json TEXT, error_message TEXT,
                            human_question TEXT, human_answer TEXT,
                            input_tokens INTEGER, output_tokens INTEGER,
                            cost_usd REAL, active_subagents INTEGER,
                            parent_task_id TEXT, bugfix_retry_count INTEGER,
                            shape TEXT, plugin TEXT, touches_files TEXT,
                            merged_to_target_branch INTEGER,
                            merge_commit_sha TEXT,
                            created_at TEXT, started_at TEXT, completed_at TEXT);
        CREATE TABLE events (id INTEGER PRIMARY KEY AUTOINCREMENT,
                             session_id TEXT, task_id TEXT, event_type TEXT,
                             payload TEXT, created_at TEXT);
    """)
    now = datetime.now(UTC).isoformat()
    conn.execute(
        "INSERT INTO sessions VALUES (?,?,?,?,?)",
        ("s", "/tmp/p", "active", now, "{}"),
    )
    rows = [
        # id, session, plugin, desc, status, retries, sha
        ("t-success", "s", "coding", "Implement JWT validation", "completed", 0, "abc1234", 1),
        ("t-recovered", "s", "coding", "Took two tries", "completed", 1, "def5678", 1),
        ("t-failed", "s", "coding", "Did not work", "failed", 0, None, 0),
    ]
    insert_sql = (
        "INSERT INTO tasks VALUES "
        "(?,?,?,?,?,0,'[]','auth','[]',NULL,?,NULL,NULL,0,0,0.0,"
        "0,NULL,?,NULL,NULL,'[]',?,?,?,?,?)"
    )
    for tid, session_id, plugin, desc, status, retries, sha, merged in rows:
        conn.execute(
            insert_sql,
            (tid, session_id, plugin, desc, status,
             "boom" if status == "failed" else None,
             retries, merged, sha, now, now, now),
        )
    for tid, text in [("t-success", "s-msg"), ("t-recovered", "r-msg"), ("t-failed", "f-msg")]:
        conn.execute(
            "INSERT INTO events (session_id, task_id, event_type, payload, created_at) "
            "VALUES (?,?,?,?,?)",
            ("s", tid, "agent_message",
             json.dumps({
                 "turn": 0, "kind": "AssistantMessage", "model": "claude-sonnet-4-5",
                 "content": [{"type": "text", "text": text}],
             }),
             now),
        )
    conn.commit()
    conn.close()


@pytest.fixture
def seeded_db(tmp_path: Path) -> Path:
    db = tmp_path / "state.db"
    _seed_db(db)
    return db


# ── B1: reader + filter ─────────────────────────────────────────────────────


def test_filter_success_only(seeded_db: Path) -> None:
    from claw_forge.training.exporter import iter_training_records
    records = list(iter_training_records(seeded_db, scope="all", filter_="success"))
    assert {r["task_id"] for r in records} == {"t-success"}


def test_filter_recovered_only(seeded_db: Path) -> None:
    from claw_forge.training.exporter import iter_training_records
    records = list(iter_training_records(seeded_db, scope="all", filter_="recovered"))
    assert {r["task_id"] for r in records} == {"t-recovered"}


def test_filter_both(seeded_db: Path) -> None:
    from claw_forge.training.exporter import iter_training_records
    records = list(iter_training_records(seeded_db, scope="all", filter_="both"))
    assert {r["task_id"] for r in records} == {"t-success", "t-recovered"}


def test_include_failed(seeded_db: Path) -> None:
    from claw_forge.training.exporter import iter_training_records
    records = list(iter_training_records(
        seeded_db, scope="all", filter_="both", include_failed=True,
    ))
    assert {r["task_id"] for r in records} == {"t-success", "t-recovered", "t-failed"}
    fail = next(r for r in records if r["task_id"] == "t-failed")
    assert fail["outcome"] == "failed"


def test_outcome_labels(seeded_db: Path) -> None:
    from claw_forge.training.exporter import iter_training_records
    by_id = {r["task_id"]: r for r in iter_training_records(
        seeded_db, scope="all", filter_="both", include_failed=True,
    )}
    assert by_id["t-success"]["outcome"] == "success"
    assert by_id["t-recovered"]["outcome"] == "recovered"
    assert by_id["t-failed"]["outcome"] == "failed"


# ── B2: openai-tools projector ──────────────────────────────────────────────


def test_openai_tools_basic() -> None:
    from claw_forge.training.projectors import to_openai_tools
    raw = {
        "task_id": "t1", "session_id": "s",
        "outcome": "success", "plugin": "coding",
        "category": "auth", "shape": None, "retry_count": 0,
        "metrics": {"input_tokens": 10, "output_tokens": 5, "cost_usd": 0.01},
        "description": "Implement JWT validation",
        "merge_commit_sha": "abc1234",
        "raw_events": [
            {"turn": 0, "kind": "AssistantMessage", "model": "claude-sonnet-4-5",
             "content": [
                 {"type": "thinking", "thinking": "Let me think..."},
                 {"type": "text", "text": "I'll read the auth module."},
                 {"type": "tool_use", "id": "tu_1", "name": "Read",
                  "input": {"file_path": "src/auth.py"}},
             ]},
            {"turn": 1, "kind": "UserMessage",
             "content": [
                 {"type": "tool_result", "tool_use_id": "tu_1",
                  "content": "<contents of auth.py>"},
             ]},
            {"turn": 2, "kind": "AssistantMessage",
             "content": [{"type": "text", "text": "Done."}]},
            {"turn": 3, "kind": "ResultMessage", "result": "Done."},
        ],
    }
    out = to_openai_tools(raw, include_thinking=True)
    msgs = out["messages"]
    assert msgs[0]["role"] == "system"
    assert msgs[1]["role"] == "user"
    assert msgs[1]["content"] == "Implement JWT validation"
    asst1 = msgs[2]
    assert asst1["role"] == "assistant"
    assert asst1["content"] == "I'll read the auth module."
    assert asst1["thinking"] == "Let me think..."
    assert asst1["tool_calls"][0]["function"]["name"] == "Read"
    args = json.loads(asst1["tool_calls"][0]["function"]["arguments"])
    assert args == {"file_path": "src/auth.py"}
    tool = msgs[3]
    assert tool["role"] == "tool"
    assert tool["tool_call_id"] == "tu_1"
    assert msgs[4]["content"] == "Done."
    assert out["merge_commit"] == "abc1234"


def test_openai_tools_drops_thinking_when_disabled() -> None:
    from claw_forge.training.projectors import to_openai_tools
    raw = {
        "task_id": "t1", "session_id": "s",
        "outcome": "success", "plugin": "coding",
        "category": None, "shape": None, "retry_count": 0,
        "metrics": {}, "description": "x", "merge_commit_sha": None,
        "raw_events": [
            {"turn": 0, "kind": "AssistantMessage",
             "content": [{"type": "thinking", "thinking": "x"},
                         {"type": "text", "text": "y"}]},
        ],
    }
    out = to_openai_tools(raw, include_thinking=False)
    asst = next(m for m in out["messages"] if m["role"] == "assistant")
    assert "thinking" not in asst
    assert asst["content"] == "y"


# ── B3: sharegpt / chatml / raw projectors ──────────────────────────────────


def test_sharegpt_flattens_tools() -> None:
    from claw_forge.training.projectors import to_sharegpt
    raw = {
        "task_id": "t1", "session_id": "s",
        "outcome": "success", "plugin": "coding", "category": None, "shape": None,
        "retry_count": 0, "metrics": {}, "description": "do it", "merge_commit_sha": None,
        "raw_events": [
            {"turn": 0, "kind": "AssistantMessage",
             "content": [
                 {"type": "text", "text": "calling Read"},
                 {"type": "tool_use", "id": "tu1", "name": "Read",
                  "input": {"file_path": "x.py"}},
             ]},
            {"turn": 1, "kind": "UserMessage",
             "content": [{"type": "tool_result", "tool_use_id": "tu1", "content": "FILE"}]},
        ],
    }
    out = to_sharegpt(raw, include_thinking=False)
    convos = out["conversations"]
    assert convos[0]["from"] == "system"
    assert convos[1]["from"] == "human"
    asst = next(c for c in convos if c["from"] == "gpt")
    assert "Read" in asst["value"]
    assert "x.py" in asst["value"]
    assert any(c["from"] == "tool" and c["value"] == "FILE" for c in convos)


def test_chatml_emits_im_tags() -> None:
    from claw_forge.training.projectors import to_chatml
    raw = {
        "task_id": "t1", "session_id": "s",
        "outcome": "success", "plugin": "coding", "category": None, "shape": None,
        "retry_count": 0, "metrics": {}, "description": "do it", "merge_commit_sha": None,
        "raw_events": [
            {"turn": 0, "kind": "AssistantMessage",
             "content": [{"type": "text", "text": "ok"}]},
        ],
    }
    out = to_chatml(raw, include_thinking=False)
    text = out["text"]
    assert "<|im_start|>system" in text
    assert "<|im_start|>user\ndo it<|im_end|>" in text
    assert "<|im_start|>assistant\nok<|im_end|>" in text


def test_raw_jsonl_dumps_events_unchanged() -> None:
    from claw_forge.training.projectors import to_raw_jsonl
    raw = {
        "task_id": "t1", "session_id": "s",
        "outcome": "success", "plugin": "coding", "category": None, "shape": None,
        "retry_count": 0, "metrics": {}, "description": "do it", "merge_commit_sha": None,
        "raw_events": [
            {"turn": 0, "kind": "AssistantMessage",
             "content": [{"type": "text", "text": "ok"}]},
        ],
    }
    out = to_raw_jsonl(raw, include_thinking=True)
    assert out["task_id"] == "t1"
    assert out["events"] == raw["raw_events"]


# ── B4: include_diff + provenance ───────────────────────────────────────────


def test_include_diff_attaches_git_show_output(seeded_db: Path, monkeypatch) -> None:
    from claw_forge.training import exporter

    captured: dict = {}

    def fake_git_show(repo: Path, sha: str) -> str:
        captured["sha"] = sha
        return f"diff for {sha}"

    monkeypatch.setattr(exporter, "_git_show", fake_git_show)
    records = list(exporter.iter_training_records(
        seeded_db, scope="all", filter_="success",
        include_diff=True, repo_dir=Path("/tmp/repo"),
    ))
    rec = records[0]
    assert rec["final_diff"] == "diff for abc1234"
    assert captured["sha"] == "abc1234"


def test_provenance_stamped(seeded_db: Path) -> None:
    from claw_forge.training.exporter import iter_training_records
    rec = next(iter_training_records(seeded_db, scope="all", filter_="success"))
    prov = rec["provenance"]
    assert "claw_forge_version" in prov
    assert "captured_at" in prov
    assert prov["claude_model"] == "claude-sonnet-4-5"
    assert prov["redaction_rules"] == []


def test_include_diff_off_by_default_skips_git_show(seeded_db: Path, monkeypatch) -> None:
    from claw_forge.training import exporter

    def boom(*_a, **_k) -> str:
        raise AssertionError("git show should not be called when include_diff=False")

    monkeypatch.setattr(exporter, "_git_show", boom)
    list(exporter.iter_training_records(seeded_db, scope="all", filter_="success"))


# ── B5: dedupe + split ──────────────────────────────────────────────────────


def test_dedupe_by_prompt() -> None:
    from claw_forge.training.exporter import dedupe_records
    recs = [
        {"task_id": "a", "description": "X", "merge_commit_sha": "a1"},
        {"task_id": "b", "description": "X", "merge_commit_sha": "a2"},
        {"task_id": "c", "description": "Y", "merge_commit_sha": "a3"},
    ]
    out = list(dedupe_records(recs, by="prompt"))
    assert [r["task_id"] for r in out] == ["a", "c"]


def test_dedupe_by_diff_keeps_none_shas() -> None:
    from claw_forge.training.exporter import dedupe_records
    recs = [
        {"task_id": "a", "description": "X", "merge_commit_sha": "h1"},
        {"task_id": "b", "description": "Y", "merge_commit_sha": "h1"},
        {"task_id": "c", "description": "Z", "merge_commit_sha": None},
    ]
    out = list(dedupe_records(recs, by="diff"))
    assert [r["task_id"] for r in out] == ["a", "c"]


def test_dedupe_by_both_drops_only_when_both_match() -> None:
    from claw_forge.training.exporter import dedupe_records
    recs = [
        {"task_id": "a", "description": "X", "merge_commit_sha": "h1"},
        {"task_id": "b", "description": "X", "merge_commit_sha": "h2"},
        {"task_id": "c", "description": "X", "merge_commit_sha": "h1"},  # full duplicate
    ]
    out = list(dedupe_records(recs, by="both"))
    assert [r["task_id"] for r in out] == ["a", "b"]


def test_dedupe_none_passes_through() -> None:
    from claw_forge.training.exporter import dedupe_records
    recs = [{"task_id": "a", "description": "X", "merge_commit_sha": "h"}] * 3
    out = list(dedupe_records(recs, by="none"))
    assert len(out) == 3


def test_split_deterministic_by_task_id() -> None:
    from claw_forge.training.exporter import split_records
    recs = [{"task_id": f"t{i}", "description": "x", "merge_commit_sha": None}
            for i in range(100)]
    train, val, test = split_records(recs, ratios=(0.8, 0.1, 0.1))
    assert len(train) + len(val) + len(test) == 100
    train2, val2, test2 = split_records(recs, ratios=(0.8, 0.1, 0.1))
    assert {r["task_id"] for r in train} == {r["task_id"] for r in train2}
    assert {r["task_id"] for r in val} == {r["task_id"] for r in val2}
    assert {r["task_id"] for r in test} == {r["task_id"] for r in test2}
    # Roughly 80/10/10 — wide band because n=100 is small and hash buckets
    # are bernoulli-ish. Real corpora are 100x larger so the distribution
    # gets much tighter; the assertion here is only a smoke check.
    assert 60 <= len(train) <= 95
    assert 1 <= len(val) <= 25
    assert 1 <= len(test) <= 25


def test_split_ratios_must_sum_to_one() -> None:
    from claw_forge.training.exporter import split_records
    with pytest.raises(ValueError):
        split_records([], ratios=(0.5, 0.4, 0.2))
