"""Tests for training-trace capture."""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine

from claw_forge.state.models import Base, Session, Task


@pytest.mark.asyncio
async def test_task_has_merge_commit_sha_column() -> None:
    """Task ORM must expose a nullable merge_commit_sha column."""
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    factory = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

    async with factory() as db:
        sess = Session(id="s1", project_path="/tmp/x", status="active")
        task = Task(
            id="t1", session_id="s1", plugin_name="coding",
            description="x", merge_commit_sha="abc1234",
        )
        db.add_all([sess, task])
        await db.commit()

    async with factory() as db:
        loaded = (await db.execute(select(Task).where(Task.id == "t1"))).scalar_one()
        assert loaded.merge_commit_sha == "abc1234"

    async with factory() as db:
        sess2 = Session(id="s2", project_path="/tmp/y", status="active")
        task2 = Task(id="t2", session_id="s2", plugin_name="coding")
        db.add_all([sess2, task2])
        await db.commit()
        loaded2 = (await db.execute(select(Task).where(Task.id == "t2"))).scalar_one()
        assert loaded2.merge_commit_sha is None


@pytest.fixture
def state_app(tmp_path):
    """Build a FastAPI app against a temp SQLite DB and yield it.

    Returns the app object so tests can construct either a sync TestClient
    or an async httpx.AsyncClient with ASGITransport against the same app.
    """
    from claw_forge.state.service import AgentStateService

    db_url = f"sqlite+aiosqlite:///{tmp_path / 'state.db'}"
    svc = AgentStateService(database_url=db_url)
    yield svc.create_app()


@pytest.fixture
def state_client(state_app):
    """Synchronous TestClient — for routine endpoint exercises."""
    with TestClient(state_app) as client:
        yield client


def test_post_event_persists_payload(state_client):
    sresp = state_client.post("/sessions", json={"project_path": "/tmp/p"})
    assert sresp.status_code == 201
    sid = sresp.json()["id"]
    tresp = state_client.post(
        f"/sessions/{sid}/tasks",
        json={"plugin_name": "coding", "description": "x"},
    )
    tid = tresp.json()["id"]

    payload = {"turn": 0, "kind": "AssistantMessage", "content": [{"type": "text", "text": "hi"}]}
    eresp = state_client.post(
        f"/sessions/{sid}/events",
        json={"event_type": "agent_message", "task_id": tid, "payload": payload},
    )
    assert eresp.status_code == 201
    assert eresp.json() == {"status": "recorded"}

    list_resp = state_client.get(f"/sessions/{sid}/events/all")
    assert list_resp.status_code == 200
    rows = list_resp.json()
    assert any(
        r["event_type"] == "agent_message" and r["payload"]["content"][0]["text"] == "hi"
        for r in rows
    )


# ── A3: recorder.py — RecordingDestination + record_messages tee ────────────


class _TextBlock:
    def __init__(self, text: str) -> None:
        self.text = text
        self.type = "text"


class AssistantMessage:
    """Test fake whose class name matches the SDK kind the recorder records."""

    def __init__(self, content: list, model: str = "claude-sonnet-4-5") -> None:
        self.content = content
        self.model = model


def test_serialize_message_preserves_content_blocks() -> None:
    from claw_forge.training.recorder import _serialize_message

    msg = AssistantMessage(content=[_TextBlock(text="hello")])
    out = _serialize_message(msg, turn=3)
    assert out["turn"] == 3
    assert out["kind"] == "AssistantMessage"
    assert out["content"][0]["type"] == "text"
    assert out["content"][0]["text"] == "hello"


@pytest.mark.asyncio
async def test_record_messages_tees_and_yields(state_app, state_client) -> None:
    """Every message yielded upstream is also POSTed to /events.

    Uses an in-process ASGI transport so the recorder talks to the same
    FastAPI app instance that the sync TestClient does — round-trip through
    the real route + DB without a TCP listener.
    """
    import httpx

    from claw_forge.training.recorder import RecordingDestination, record_messages

    sid = state_client.post("/sessions", json={"project_path": "/tmp"}).json()["id"]
    tid = state_client.post(
        f"/sessions/{sid}/tasks", json={"plugin_name": "coding", "description": "x"}
    ).json()["id"]

    async def upstream():
        yield AssistantMessage(content=[_TextBlock(text="m1")])
        yield AssistantMessage(content=[_TextBlock(text="m2")])

    dest = RecordingDestination(
        session_id=sid, task_id=tid, state_url="http://testserver",
    )

    transport = httpx.ASGITransport(app=state_app)
    async with httpx.AsyncClient(transport=transport, base_url="http://testserver") as client:
        received = []
        async for msg in record_messages(upstream(), dest=dest, client=client):
            received.append(msg)
        assert len(received) == 2

    rows = state_client.get(f"/sessions/{sid}/events/all").json()
    agent_msgs = [r for r in rows if r["event_type"] == "agent_message"]
    assert len(agent_msgs) == 2
    assert agent_msgs[0]["payload"]["turn"] == 0
    assert agent_msgs[1]["payload"]["turn"] == 1


@pytest.mark.asyncio
async def test_record_messages_swallows_post_failures() -> None:
    """Recorder failures must never abort the upstream stream."""
    from claw_forge.training.recorder import RecordingDestination, record_messages

    async def upstream():
        yield AssistantMessage(content=[_TextBlock(text="m")])

    # Nothing listening on port 1 — connection refused
    dest = RecordingDestination(
        session_id="nonexistent",
        task_id="nonexistent",
        state_url="http://127.0.0.1:1",
    )
    received = []
    async for msg in record_messages(upstream(), dest=dest):
        received.append(msg)
    assert len(received) == 1


# ── A4: thread record_to into runner.py ─────────────────────────────────────
#
# The behavioural test for the tee lives at test_record_messages_tees_and_yields
# above — record_messages is what does the actual work, and run_agent's job is
# only to forward the destination into it.  We verify the parameter wiring by
# AST inspection (no runtime import) so this file remains independent of the
# claude-agent-sdk runtime, which the runner module pulls in transitively.


def test_runner_signatures_accept_record_to() -> None:
    """run_agent / collect_result / collect_structured_result must all accept
    record_to as a keyword arg defaulting to None.  Verified by parsing the
    runner.py source so the test stays decoupled from the SDK runtime chain.
    """
    import ast
    from pathlib import Path

    src = Path(__file__).parents[2] / "claw_forge" / "agent" / "runner.py"
    tree = ast.parse(src.read_text())
    fns = {
        node.name: node
        for node in ast.walk(tree)
        if isinstance(node, ast.AsyncFunctionDef)
        and node.name in {"run_agent", "collect_result", "collect_structured_result"}
    }
    assert set(fns) == {"run_agent", "collect_result", "collect_structured_result"}, (
        f"missing one of the runner entry points; found {set(fns)}"
    )

    for name, fn in fns.items():
        kwonly_names = [a.arg for a in fn.args.kwonlyargs]
        assert "record_to" in kwonly_names, (
            f"{name} missing record_to keyword arg; has {kwonly_names}"
        )
        # Defaults for kwonly args align with kwonlyargs by position
        idx = kwonly_names.index("record_to")
        default = fn.args.kw_defaults[idx]
        assert isinstance(default, ast.Constant) and default.value is None, (
            f"{name}.record_to must default to None"
        )


# ── A7: destination_from_context + plugin wiring ────────────────────────────


def test_destination_from_context_off_by_default() -> None:
    from claw_forge.training.recorder import destination_from_context

    dest = destination_from_context(
        session_id="s", task_id="t", config={"state_url": "http://x"},
    )
    assert dest is None  # training_traces not in config → off


def test_destination_from_context_off_when_only_enabled() -> None:
    from claw_forge.training.recorder import destination_from_context

    dest = destination_from_context(
        session_id="s", task_id="t",
        config={
            "state_url": "http://x",
            "training_traces": {"enabled": True},  # acknowledged_terms not set
        },
    )
    assert dest is None


def test_destination_from_context_off_when_no_state_url() -> None:
    from claw_forge.training.recorder import destination_from_context

    dest = destination_from_context(
        session_id="s", task_id="t",
        config={
            "training_traces": {"enabled": True, "acknowledged_terms": True},
        },
    )
    assert dest is None  # both flags set but no state_url → can't record


def test_destination_from_context_active() -> None:
    from claw_forge.training.recorder import destination_from_context

    dest = destination_from_context(
        session_id="sid",
        task_id="tid",
        config={
            "state_url": "http://localhost:8420",
            "training_traces": {"enabled": True, "acknowledged_terms": True},
        },
    )
    assert dest is not None
    assert dest.session_id == "sid"
    assert dest.task_id == "tid"
    assert dest.state_url == "http://localhost:8420"


# ── A8: PATCH merge_commit_sha ──────────────────────────────────────────────


def test_patch_task_accepts_merge_commit_sha(state_client) -> None:
    """PATCH /tasks/{id} should allow setting merge_commit_sha."""
    sid = state_client.post("/sessions", json={"project_path": "/tmp"}).json()["id"]
    tid = state_client.post(
        f"/sessions/{sid}/tasks", json={"plugin_name": "coding", "description": "x"}
    ).json()["id"]
    resp = state_client.patch(
        f"/tasks/{tid}",
        json={"merge_commit_sha": "abc1234"},
    )
    assert resp.status_code == 200
    got = state_client.get(f"/tasks/{tid}").json()
    assert got["merge_commit_sha"] == "abc1234"


def test_get_session_tasks_includes_merge_commit_sha(state_client) -> None:
    """GET /sessions/{sid}/tasks should expose merge_commit_sha on each task."""
    sid = state_client.post("/sessions", json={"project_path": "/tmp"}).json()["id"]
    tid = state_client.post(
        f"/sessions/{sid}/tasks", json={"plugin_name": "coding", "description": "x"}
    ).json()["id"]
    state_client.patch(f"/tasks/{tid}", json={"merge_commit_sha": "deadbeef"})
    rows = state_client.get(f"/sessions/{sid}/tasks").json()
    assert any(r.get("merge_commit_sha") == "deadbeef" for r in rows)
