"""CLI flag wiring for validate-spec's --strict-shape and --project-root.

Helper unit tests + Typer flag-propagation tests using CliRunner.
"""
from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from claw_forge.cli import _resolve_project_root

runner = CliRunner()


class TestResolveProjectRoot:
    def test_explicit_override_wins(self, tmp_path: Path) -> None:
        spec = tmp_path / "spec.xml"
        spec.write_text("<x/>")
        override = tmp_path / "elsewhere"
        override.mkdir()
        assert _resolve_project_root(spec, override=override) == override

    def test_walks_up_to_find_claw_forge_yaml(self, tmp_path: Path) -> None:
        # tmp_path/proj/.claw-forge.yaml
        # tmp_path/proj/specs/spec.xml
        proj = tmp_path / "proj"
        (proj / "specs").mkdir(parents=True)
        (proj / ".claw-forge.yaml").write_text("")
        spec = proj / "specs" / "spec.xml"
        spec.write_text("<x/>")
        assert _resolve_project_root(spec, override=None) == proj

    def test_walks_up_to_find_dot_git(self, tmp_path: Path) -> None:
        proj = tmp_path / "proj"
        (proj / "deep" / "nested").mkdir(parents=True)
        (proj / ".git").mkdir()
        spec = proj / "deep" / "nested" / "spec.xml"
        spec.write_text("<x/>")
        assert _resolve_project_root(spec, override=None) == proj

    def test_claw_forge_yaml_wins_over_git(self, tmp_path: Path) -> None:
        # claw-forge.yaml is more specific than .git
        proj = tmp_path / "proj"
        (proj / "subdir").mkdir(parents=True)
        (proj / ".git").mkdir()
        (proj / "subdir" / ".claw-forge.yaml").write_text("")
        spec = proj / "subdir" / "spec.xml"
        spec.write_text("<x/>")
        assert _resolve_project_root(spec, override=None) == proj / "subdir"

    def test_returns_none_when_neither_marker_found(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Walk all the way up without finding a marker → None."""
        spec = tmp_path / "spec.xml"
        spec.write_text("<x/>")
        monkeypatch.setattr(Path, "is_file", lambda self: False)
        monkeypatch.setattr(Path, "exists", lambda self: False)
        assert _resolve_project_root(spec, override=None) is None


class TestStrictShapeFlag:
    """--strict-shape promotes WARNINGs to ERRORs in Layer 4 output."""

    def _vertical_no_shape_spec(self, tmp_path: Path) -> Path:
        """Spec with a vertical-looking unannotated category — Gap 6."""
        xml = """<?xml version="1.0"?>
<project_specification>
  <project_name>Test</project_name>
  <overview>x</overview>
  <tech_stack></tech_stack>
  <core_features>
    <category name="Authentication">
      <feature index="1">
        <description>User can register with email (returns 200)</description>
      </feature>
      <feature index="2">
        <description>User can log in with credentials (returns 200)</description>
      </feature>
      <feature index="3"><description>User can log out (returns 204)</description></feature>
    </category>
  </core_features>
</project_specification>"""
        spec = tmp_path / "spec.xml"
        spec.write_text(xml)
        return spec

    def test_default_mode_warnings(self, tmp_path: Path) -> None:
        from claw_forge.cli import app

        spec = self._vertical_no_shape_spec(tmp_path)
        result = runner.invoke(app, ["validate-spec", str(spec), "--no-llm"])
        # Default mode: Layer 4 emits warnings, exit 0 (warnings don't fail)
        assert result.exit_code == 0, result.stdout
        assert "Layer 4 (Shape)" in result.stdout
        assert "warning" in result.stdout.lower()

    def test_strict_mode_promotes_to_errors(self, tmp_path: Path) -> None:
        from claw_forge.cli import app

        spec = self._vertical_no_shape_spec(tmp_path)
        result = runner.invoke(
            app, ["validate-spec", str(spec), "--no-llm", "--strict-shape"],
        )
        assert result.exit_code == 1
        assert "Layer 4 (Shape)" in result.stdout
        assert "FAIL" in result.stdout

    def test_header_summary_includes_shape_count(self, tmp_path: Path) -> None:
        from claw_forge.cli import app

        xml = """<?xml version="1.0"?>
<project_specification>
  <project_name>Test</project_name>
  <overview>x</overview>
  <tech_stack></tech_stack>
  <core_features>
    <category name="Auth">
      <feature index="1" shape="plugin" plugin="auth">
        <description>User can register (returns 200)</description>
      </feature>
      <feature index="2"><description>User can log in (returns 200)</description></feature>
    </category>
  </core_features>
</project_specification>"""
        spec = tmp_path / "spec.xml"
        spec.write_text(xml)
        result = runner.invoke(app, ["validate-spec", str(spec), "--no-llm"])
        assert "Shape:" in result.stdout
        assert "annotated" in result.stdout

    def test_project_root_override_flag(self, tmp_path: Path) -> None:
        from claw_forge.cli import app

        # Create a brownfield root where plugin "auth" exists
        proj = tmp_path / "proj"
        (proj / "src" / "plugins" / "auth").mkdir(parents=True)
        spec_xml = """<?xml version="1.0"?>
<project_specification>
  <project_name>Test</project_name>
  <overview>x</overview>
  <tech_stack></tech_stack>
  <core_features>
    <category name="Auth">
      <feature index="1" shape="plugin" plugin="ghost">
        <description>User can register (returns 200)</description>
      </feature>
    </category>
  </core_features>
</project_specification>"""
        spec = tmp_path / "spec.xml"
        spec.write_text(spec_xml)
        result_with_root = runner.invoke(
            app, ["validate-spec", str(spec), "--no-llm",
                  "--project-root", str(proj)],
        )
        # With --project-root pointing at proj, "ghost" plugin missing
        assert "ghost" in result_with_root.stdout.lower()

    def test_unannotated_features_count_correct(self, tmp_path: Path) -> None:
        """Count is total features minus shape-set features."""
        from claw_forge.cli import app

        xml = """<?xml version="1.0"?>
<project_specification>
  <project_name>Test</project_name>
  <overview>x</overview>
  <tech_stack></tech_stack>
  <core_features>
    <category name="Auth">
      <feature index="1" shape="plugin" plugin="auth">
        <description>User can register (returns 200)</description>
      </feature>
      <feature index="2" shape="plugin" plugin="auth">
        <description>User can log in (returns 200)</description>
      </feature>
      <feature index="3"><description>User can log out (returns 204)</description></feature>
    </category>
  </core_features>
</project_specification>"""
        spec = tmp_path / "spec.xml"
        spec.write_text(xml)
        result = runner.invoke(app, ["validate-spec", str(spec), "--no-llm"])
        assert "2 annotated, 1 unannotated" in result.stdout
