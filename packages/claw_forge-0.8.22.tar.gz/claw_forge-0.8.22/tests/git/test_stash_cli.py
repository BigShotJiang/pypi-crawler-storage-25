"""Tests for ``claw_forge.git.stash_cli`` — the v0.8.16 operator surface
for harness-managed stashes (auto/manual/leak).  Locks in:

  * ``_list_cf_stashes`` filters operator-personal stashes out and
    classifies harness entries by kind.
  * ``stash list`` prints all three kinds with kind tags.
  * ``stash drop <ref>`` accepts both ``stash@{N}`` and bare ``N``
    forms, refuses to drop non-harness stashes, and short-circuits
    on missing refs.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
from typer.testing import CliRunner

from claw_forge.git.stash_cli import _list_cf_stashes, stash_app

runner = CliRunner()


def _git(args: list[str], cwd: Path) -> None:
    subprocess.run(
        ["git", *args], cwd=str(cwd), check=True,
        capture_output=True, text=True,
    )


@pytest.fixture
def repo_with_stashes(tmp_path: Path) -> Path:
    """Repo seeded with three harness stashes (one of each kind) plus
    one operator-personal stash so we can verify the filter."""
    repo = tmp_path / "proj"
    repo.mkdir()
    _git(["init", "-q", "-b", "main"], repo)
    _git(["config", "user.email", "test@example.com"], repo)
    _git(["config", "user.name", "Test"], repo)
    _git(["config", "commit.gpgsign", "false"], repo)
    (repo / "tracked.txt").write_text("v0\n")
    _git(["add", "tracked.txt"], repo)
    _git(["commit", "-q", "-m", "init"], repo)

    # Stash 1: auto.
    (repo / "tracked.txt").write_text("auto cleanup case\n")
    _git(["stash", "push", "-m", "claw-forge-auto-20260510-103300"], repo)

    # Stash 2: manual.
    (repo / "tracked.txt").write_text("manual cleanup case\n")
    _git(["stash", "push", "-m", "claw-forge-manual-20260510-110000"], repo)

    # Stash 3: leak (with task_id).
    (repo / "leaked.py").write_text("agent escaped\n")
    _git(["stash", "push", "-u", "-m", "claw-forge-leak-fe7f8298-20260510-104000"], repo)

    # Stash 4: boot baseline (v0.8.17).
    (repo / "tracked.txt").write_text("pre-run user wip\n")
    _git(["stash", "push", "-m", "claw-forge-boot-20260510-103200"], repo)

    # Stash 5: operator-personal (no marker prefix).  Must NOT show up
    # in claw-forge stash list.
    (repo / "tracked.txt").write_text("personal wip\n")
    _git(["stash", "push", "-m", "wip — refactor in progress"], repo)
    return repo


class TestListCfStashes:
    def test_filters_harness_entries(self, repo_with_stashes: Path) -> None:
        """The personal ``wip`` stash must be excluded; the four
        harness entries (auto, manual, leak, boot) must each appear."""
        rows = _list_cf_stashes(repo_with_stashes)
        kinds = sorted(r["kind"] for r in rows)
        assert kinds == ["auto", "boot", "leak", "manual"]
        # Personal stash is at index 0 (most recent push); verify NONE
        # of the harness rows reference the personal entry's message.
        assert all(
            "wip — refactor" not in r["message"] for r in rows
        )

    def test_returns_empty_for_non_git_dir(self, tmp_path: Path) -> None:
        """Outside a repo, git stash list fails → empty result."""
        not_a_repo = tmp_path / "not-a-repo"
        not_a_repo.mkdir()
        assert _list_cf_stashes(not_a_repo) == []

    def test_returns_empty_when_no_harness_stashes(
        self, tmp_path: Path,
    ) -> None:
        """Repo with only operator-personal stashes → empty result.
        The CLI is scoped to harness-managed entries only."""
        repo = tmp_path / "p"
        repo.mkdir()
        _git(["init", "-q", "-b", "main"], repo)
        _git(["config", "user.email", "test@example.com"], repo)
        _git(["config", "user.name", "Test"], repo)
        _git(["config", "commit.gpgsign", "false"], repo)
        (repo / "f").write_text("init\n")
        _git(["add", "f"], repo)
        _git(["commit", "-q", "-m", "init"], repo)
        (repo / "f").write_text("personal wip\n")
        _git(["stash", "push", "-m", "personal — not a harness stash"], repo)

        assert _list_cf_stashes(repo) == []


class TestStashListCmd:
    def test_prints_all_four_kinds(self, repo_with_stashes: Path) -> None:
        """``stash list`` shows entries with kind labels and a summary
        covering all four harness kinds (auto/manual/leak/boot)."""
        result = runner.invoke(
            stash_app, ["list", "--project", str(repo_with_stashes)],
        )
        assert result.exit_code == 0, result.output
        # Each kind tag appears.
        assert "(auto)" in result.output
        assert "(manual)" in result.output
        assert "(leak)" in result.output
        assert "(boot)" in result.output
        # Summary line.
        assert "1 auto" in result.output
        assert "1 manual" in result.output
        assert "1 leak" in result.output
        assert "1 boot" in result.output
        # Personal stash NOT shown.
        assert "wip — refactor" not in result.output

    def test_handles_no_stashes(self, tmp_path: Path) -> None:
        """Empty case prints a friendly notice, not a stack trace."""
        not_a_repo = tmp_path / "empty"
        not_a_repo.mkdir()
        result = runner.invoke(
            stash_app, ["list", "--project", str(not_a_repo)],
        )
        assert result.exit_code == 0
        assert "No claw-forge-managed stash entries" in result.output


class TestStashDropCmd:
    def test_drops_harness_stash_by_ref(
        self, repo_with_stashes: Path,
    ) -> None:
        """``stash drop stash@{N}`` of a harness entry succeeds with -y.

        We assert by message identity, not by ref — git renumbers stashes
        after a drop (``stash@{2}`` becomes ``stash@{1}``), so a ref check
        would falsely succeed when the surviving entry shifts into the
        dropped slot.
        """
        rows = _list_cf_stashes(repo_with_stashes)
        target = rows[0]
        result = runner.invoke(
            stash_app,
            [
                "drop", target["ref"],
                "--project", str(repo_with_stashes),
                "--yes",
            ],
        )
        assert result.exit_code == 0, result.output
        rows_after = _list_cf_stashes(repo_with_stashes)
        # Same identity check via message — the dropped entry must not
        # reappear in the harness-filtered list.
        assert len(rows_after) == len(rows) - 1
        assert all(
            r["message"] != target["message"] for r in rows_after
        )

    def test_accepts_bare_integer_index(
        self, repo_with_stashes: Path,
    ) -> None:
        """``stash drop 1`` is sugar for ``stash drop stash@{1}`` —
        same identity-by-message check as above."""
        rows = _list_cf_stashes(repo_with_stashes)
        target = rows[-1]  # oldest harness entry
        result = runner.invoke(
            stash_app,
            [
                "drop", str(target["index"]),
                "--project", str(repo_with_stashes),
                "--yes",
            ],
        )
        assert result.exit_code == 0, result.output
        rows_after = _list_cf_stashes(repo_with_stashes)
        assert len(rows_after) == len(rows) - 1
        assert all(
            r["message"] != target["message"] for r in rows_after
        )

    def test_refuses_to_drop_personal_stash(
        self, repo_with_stashes: Path,
    ) -> None:
        """The personal ``wip`` stash sits at ``stash@{0}`` (most recent
        push).  ``stash drop 0`` must refuse — it's not a harness entry."""
        result = runner.invoke(
            stash_app,
            ["drop", "0", "--project", str(repo_with_stashes), "--yes"],
        )
        assert result.exit_code != 0
        assert "No claw-forge-managed stash" in result.output

    def test_refuses_missing_ref(
        self, repo_with_stashes: Path,
    ) -> None:
        """Asking to drop a stash that doesn't exist short-circuits with
        a clear message — no raw git error leaks through."""
        result = runner.invoke(
            stash_app,
            [
                "drop", "stash@{99}",
                "--project", str(repo_with_stashes), "--yes",
            ],
        )
        assert result.exit_code != 0
        assert "No claw-forge-managed stash" in result.output
