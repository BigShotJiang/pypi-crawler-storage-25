"""Tests for ``claw-forge worktrees`` CLI commands."""
from __future__ import annotations

import sqlite3
import subprocess
from pathlib import Path

import pytest
from typer.testing import CliRunner

from claw_forge.cli import app
from claw_forge.git.branching import (
    branch_exists,
    create_worktree,
)
from claw_forge.git.commits import commit_checkpoint
from claw_forge.git.slug import make_branch_name


def _seed_running_task(
    project: Path, *, category: str, description: str,
) -> str:
    """Write a single ``status='running'`` row to ``.claw-forge/state.db``
    and return the slug ``prune`` would protect.

    We don't depend on the full ORM schema — ``_running_task_slugs`` only
    selects ``category, description WHERE status = 'running'``, so a stub
    table with those three columns is enough.
    """
    db_dir = project / ".claw-forge"
    db_dir.mkdir(exist_ok=True)
    db = db_dir / "state.db"
    with sqlite3.connect(db) as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS tasks "
            "(status TEXT, category TEXT, description TEXT)",
        )
        conn.execute(
            "INSERT INTO tasks (status, category, description) "
            "VALUES (?, ?, ?)",
            ("running", category, description),
        )
        conn.commit()
    branch = make_branch_name(description, category)
    return branch[len("feat/"):]


@pytest.fixture()
def git_repo(tmp_path: Path) -> Path:
    subprocess.run(
        ["git", "init", "-q", "-b", "main"], cwd=tmp_path, check=True,
    )
    subprocess.run(
        ["git", "config", "user.email", "t@t.x"], cwd=tmp_path, check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "t"], cwd=tmp_path, check=True,
    )
    (tmp_path / "README.md").write_text("# init\n")
    subprocess.run(["git", "add", "."], cwd=tmp_path, check=True)
    subprocess.run(
        ["git", "commit", "-q", "-m", "init"], cwd=tmp_path, check=True,
    )
    return tmp_path


def _make_worktree_with_commit(
    project: Path, slug: str, *, commit_msg: str = "feat: change",
) -> tuple[str, Path]:
    branch, wt = create_worktree(project, f"task-{slug}", slug)
    (wt / f"{slug}.py").write_text(f"# {slug}\n")
    commit_checkpoint(
        wt, message=commit_msg,
        task_id=f"task-{slug}", plugin="coding", phase="coding",
        session_id="s1",
    )
    return branch, wt


class TestWorktreesList:
    def test_list_no_worktrees_directory(self, git_repo: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            app, ["worktrees", "list", "--project", str(git_repo)],
        )
        assert result.exit_code == 0, result.output
        assert "No worktree directories" in result.output

    def test_list_shows_branch_and_commit_count(self, git_repo: Path) -> None:
        _make_worktree_with_commit(git_repo, "alpha", commit_msg="feat: a1")

        runner = CliRunner()
        result = runner.invoke(
            app, ["worktrees", "list", "--project", str(git_repo)],
        )
        assert result.exit_code == 0, result.output
        assert "feat/alpha" in result.output
        assert "1 commit" in result.output
        assert "feat: a1" in result.output
        assert "1 salvageable" in result.output

    def test_worktrees_no_subcommand_shows_help(self) -> None:
        """Bare ``claw-forge worktrees`` shows help; users must pick a
        subcommand.  ``no_args_is_help=True`` is what produces this.
        """
        runner = CliRunner()
        result = runner.invoke(app, ["worktrees"])
        assert "list" in result.output.lower()
        assert "prune" in result.output.lower()

    def test_list_includes_empty_branches(self, git_repo: Path) -> None:
        """Worktree dirs whose branches have no commits ahead of target are
        listed too — otherwise ``empty + leftover`` cases would be invisible
        until the user ran ``prune``.
        """
        # Create a worktree but DON'T commit to it.
        create_worktree(git_repo, "task-empty", "emptywt")

        runner = CliRunner()
        result = runner.invoke(
            app, ["worktrees", "list", "--project", str(git_repo)],
        )
        assert result.exit_code == 0, result.output
        assert "feat/emptywt" in result.output
        assert "empty" in result.output


class TestWorktreesPrune:
    def test_prune_salvage_merges_branch_with_commits(
        self, git_repo: Path,
    ) -> None:
        branch, wt = _make_worktree_with_commit(git_repo, "gamma")

        runner = CliRunner()
        result = runner.invoke(
            app, ["worktrees", "prune", "--project", str(git_repo)],
        )
        assert result.exit_code == 0, result.output
        assert "Salvage-merged" in result.output
        assert branch in result.output
        # Worktree dir + branch removed; salvaged work landed on main.
        assert not wt.exists()
        assert not branch_exists(git_repo, branch)
        assert (git_repo / "gamma.py").exists()

    def test_prune_drops_empty_directory(self, git_repo: Path) -> None:
        """A worktree dir whose branch has no commits is just removed —
        nothing to salvage.
        """
        _, wt = create_worktree(git_repo, "task-empty", "delta")
        # Branch exists but is at the same commit as main → nothing to salvage.

        runner = CliRunner()
        result = runner.invoke(
            app, ["worktrees", "prune", "--project", str(git_repo)],
        )
        assert result.exit_code == 0, result.output
        assert not wt.exists()
        # The empty branch shouldn't be salvage-merged (nothing to merge).
        assert "Salvage-merged" not in result.output
        assert "Pruned" in result.output

    def test_prune_no_worktrees_directory(self, git_repo: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            app, ["worktrees", "prune", "--project", str(git_repo)],
        )
        assert result.exit_code == 0, result.output
        assert "No worktree directories" in result.output

    def test_prune_discard_skips_salvage_and_force_removes(
        self, git_repo: Path,
    ) -> None:
        """``--discard`` removes the worktree + branch even if the branch has
        unmerged commits, without attempting salvage.  Use case: throwaway
        agent output the user explicitly does not want on main.
        """
        branch, wt = _make_worktree_with_commit(git_repo, "epsilon")
        # Confirm there are commits to discard.
        assert branch_exists(git_repo, branch)

        runner = CliRunner()
        result = runner.invoke(
            app,
            ["worktrees", "prune", "--project", str(git_repo), "--discard"],
        )
        assert result.exit_code == 0, result.output
        assert "Discarded 1 worktree" in result.output
        assert not wt.exists()
        assert not branch_exists(git_repo, branch)
        # Discarded work did NOT land on main.
        assert not (git_repo / "epsilon.py").exists()

    def test_prune_skips_running_task_worktree_by_default(
        self, git_repo: Path,
    ) -> None:
        """The fix: a worktree backing a ``status='running'`` task in the
        state DB must survive a default ``prune`` so the live agent's
        working tree isn't yanked from under it.
        """
        live_slug = _seed_running_task(
            git_repo, category="auth", description="JWT authentication",
        )
        live_branch, live_wt = _make_worktree_with_commit(
            git_repo, live_slug, commit_msg="feat: live work",
        )
        # Plus an unrelated stale worktree that should still be cleaned up.
        stale_branch, stale_wt = _make_worktree_with_commit(
            git_repo, "zeta", commit_msg="feat: stale",
        )

        runner = CliRunner()
        result = runner.invoke(
            app, ["worktrees", "prune", "--project", str(git_repo)],
        )
        assert result.exit_code == 0, result.output
        assert "Skipping 1 worktree" in result.output
        assert live_branch in result.output

        # Live worktree + branch survived.
        assert live_wt.exists()
        assert branch_exists(git_repo, live_branch)
        # Stale worktree was salvage-merged and removed.
        assert not stale_wt.exists()
        assert not branch_exists(git_repo, stale_branch)

    def test_prune_force_overrides_running_protection(
        self, git_repo: Path,
    ) -> None:
        """``--force`` is the explicit opt-out for cases where the operator
        has already stopped the dispatcher and wants the running-task slugs
        cleaned up too.
        """
        live_slug = _seed_running_task(
            git_repo, category="auth", description="JWT authentication",
        )
        live_branch, live_wt = _make_worktree_with_commit(
            git_repo, live_slug, commit_msg="feat: live work",
        )

        runner = CliRunner()
        result = runner.invoke(
            app,
            ["worktrees", "prune", "--project", str(git_repo), "--force"],
        )
        assert result.exit_code == 0, result.output
        assert "Skipping" not in result.output
        assert not live_wt.exists()
        assert not branch_exists(git_repo, live_branch)

    def test_prune_fails_open_when_state_db_unreadable(
        self, git_repo: Path,
    ) -> None:
        """If ``state.db`` exists but the schema doesn't expose ``tasks`` —
        e.g. a corrupted file or a future schema migration in flight — the
        helper must return an empty protected set so ``prune`` can still
        clear stale worktrees.  This is the fail-open promise that lets
        ``--force`` remain a true override rather than a workaround.
        """
        # Create state.db with a schema that has no tasks table → query raises.
        db_dir = git_repo / ".claw-forge"
        db_dir.mkdir(exist_ok=True)
        with sqlite3.connect(db_dir / "state.db") as conn:
            conn.execute("CREATE TABLE unrelated (x INT)")
            conn.commit()

        # A stale worktree we expect to be pruned.
        branch, wt = _make_worktree_with_commit(git_repo, "eta")

        runner = CliRunner()
        result = runner.invoke(
            app, ["worktrees", "prune", "--project", str(git_repo)],
        )
        assert result.exit_code == 0, result.output
        assert "Skipping" not in result.output
        assert not wt.exists()
        assert not branch_exists(git_repo, branch)

    def test_prune_discard_respects_running_protection(
        self, git_repo: Path,
    ) -> None:
        """``--discard`` is destructive (no salvage) so the protection check
        applies to it too.
        """
        live_slug = _seed_running_task(
            git_repo, category="auth", description="JWT authentication",
        )
        live_branch, live_wt = _make_worktree_with_commit(
            git_repo, live_slug, commit_msg="feat: live work",
        )

        runner = CliRunner()
        result = runner.invoke(
            app,
            ["worktrees", "prune", "--project", str(git_repo), "--discard"],
        )
        assert result.exit_code == 0, result.output
        assert "Skipping 1 worktree" in result.output
        # Live worktree + branch survived even under --discard.
        assert live_wt.exists()
        assert branch_exists(git_repo, live_branch)
