"""Tests for ``claw_forge.git.leak_watch`` — the v0.8.16 mid-run leak
detector.  Locks in:

  * porcelain snapshotting catches both modified-tracked and untracked.
  * the set-difference contract: only NEW dirt vs the baseline shows up.
  * stash markers carry the suspect ``task_id`` and a UTC timestamp so
    the operator can correlate later.
  * git failures don't propagate — leak watching is best-effort.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from claw_forge.git.leak_watch import (
    capture_boot_baseline,
    project_status_porcelain,
    stash_leak_with_marker,
)


def _git(args: list[str], cwd: Path) -> str:
    return subprocess.check_output(
        ["git", *args], cwd=str(cwd), text=True,
    )


@pytest.fixture
def tiny_repo(tmp_path: Path) -> Path:
    """Minimal initialised git repo with one tracked file on main, ready
    for the test to dirty it however the case requires."""
    repo = tmp_path / "proj"
    repo.mkdir()
    _git(["init", "-q", "-b", "main"], repo)
    _git(["config", "user.email", "test@example.com"], repo)
    _git(["config", "user.name", "Test"], repo)
    _git(["config", "commit.gpgsign", "false"], repo)
    (repo / "tracked.txt").write_text("original\n")
    _git(["add", "tracked.txt"], repo)
    _git(["commit", "-q", "-m", "init"], repo)
    return repo


class TestProjectStatusPorcelain:
    def test_clean_repo_returns_empty_set(self, tiny_repo: Path) -> None:
        """Fresh repo with one committed file → empty dirt set."""
        assert project_status_porcelain(tiny_repo) == set()

    def test_modified_tracked_appears(self, tiny_repo: Path) -> None:
        """Edit-in-place of a tracked file shows up as porcelain ``M``."""
        (tiny_repo / "tracked.txt").write_text("modified\n")
        assert project_status_porcelain(tiny_repo) == {"tracked.txt"}

    def test_untracked_appears(self, tiny_repo: Path) -> None:
        """Brand-new file shows up as porcelain ``??``."""
        (tiny_repo / "leaked.py").write_text("agent leaked me\n")
        assert project_status_porcelain(tiny_repo) == {"leaked.py"}

    def test_both_categories_appear_together(self, tiny_repo: Path) -> None:
        """Modified-tracked + untracked in one snapshot — both reported."""
        (tiny_repo / "tracked.txt").write_text("changed\n")
        (tiny_repo / "leaked.py").write_text("new\n")
        result = project_status_porcelain(tiny_repo)
        assert result == {"tracked.txt", "leaked.py"}

    def test_set_difference_isolates_new_dirt(self, tiny_repo: Path) -> None:
        """The watcher's contract: ``post - baseline`` is the leak set."""
        (tiny_repo / "preexisting.txt").write_text("from concurrent task\n")
        baseline = project_status_porcelain(tiny_repo)
        # Now THIS task leaks something new.
        (tiny_repo / "this_task_leaked.py").write_text("oops\n")
        post = project_status_porcelain(tiny_repo)
        new_dirt = post - baseline
        assert new_dirt == {"this_task_leaked.py"}

    def test_non_git_dir_returns_empty_set(self, tmp_path: Path) -> None:
        """Outside a git repo, git status fails — caller treats as clean."""
        not_a_repo = tmp_path / "not-a-repo"
        not_a_repo.mkdir()
        assert project_status_porcelain(not_a_repo) == set()


class TestStashLeakWithMarker:
    def test_returns_none_for_empty_leak_set(self, tiny_repo: Path) -> None:
        """No leak → no stash, no work done."""
        assert stash_leak_with_marker(tiny_repo, "task-abc", set()) is None

    def test_stashes_untracked_with_marker(self, tiny_repo: Path) -> None:
        """Untracked leak gets stashed via ``-u``; marker contains the
        first 8 chars of the task_id and a timestamp."""
        (tiny_repo / "leak1.py").write_text("dirt\n")
        marker = stash_leak_with_marker(
            tiny_repo, "fe7f8298-deadbeef", {"leak1.py"},
        )
        assert marker is not None
        assert marker.startswith("claw-forge-leak-fe7f8298-")
        # Confirm the stash actually landed and the leak is no longer
        # in the working tree.
        stash_list = _git(["stash", "list"], tiny_repo)
        assert marker in stash_list
        assert not (tiny_repo / "leak1.py").exists()

    def test_stashes_modified_tracked_with_marker(
        self, tiny_repo: Path,
    ) -> None:
        """Modified-tracked leak gets stashed too — same marker format."""
        (tiny_repo / "tracked.txt").write_text("agent leaked me\n")
        marker = stash_leak_with_marker(
            tiny_repo, "abc12345-xx", {"tracked.txt"},
        )
        assert marker is not None
        assert marker.startswith("claw-forge-leak-abc12345-")
        # Working tree restored to HEAD.
        assert (tiny_repo / "tracked.txt").read_text() == "original\n"

    def test_stash_marker_unique_per_call(self, tiny_repo: Path) -> None:
        """Two leaks → two distinct markers (timestamp differs at second
        granularity; force a perceptible delay if collision is possible).

        Skipped: stash markers carry second-resolution timestamps, so two
        back-to-back calls within the same wall-clock second produce the
        same marker.  Test the contract — distinct task_ids → distinct
        marker prefixes — not the timestamp uniqueness."""
        (tiny_repo / "leak_a.py").write_text("a\n")
        marker_a = stash_leak_with_marker(
            tiny_repo, "task-aaaaaa-1", {"leak_a.py"},
        )
        (tiny_repo / "leak_b.py").write_text("b\n")
        marker_b = stash_leak_with_marker(
            tiny_repo, "task-bbbbbb-2", {"leak_b.py"},
        )
        assert marker_a is not None and marker_b is not None
        assert "task-aaa" in marker_a
        assert "task-bbb" in marker_b
        assert marker_a != marker_b

    def test_returns_none_on_git_failure(self, tmp_path: Path) -> None:
        """Stashing in a non-git dir fails — function returns None,
        does not raise.  Best-effort contract."""
        not_a_repo = tmp_path / "not-a-repo"
        not_a_repo.mkdir()
        assert stash_leak_with_marker(
            not_a_repo, "task-x", {"foo.py"},
        ) is None


class TestCaptureBootBaseline:
    """v0.8.17 boot baseline — captures pre-existing dirt at dispatcher
    startup so the per-task post-rollback can enforce
    HEAD-clean-main as a run-lifetime invariant."""

    def test_returns_none_when_clean(self, tiny_repo: Path) -> None:
        """The healthy default: smart-cleanup ran, main is clean →
        boot baseline is a no-op (returns ``None``).  No stash created."""
        assert capture_boot_baseline(tiny_repo) is None
        # Confirm nothing landed in the stash list.
        stash_list = _git(["stash", "list"], tiny_repo)
        assert "claw-forge-boot" not in stash_list

    def test_captures_modified_tracked_dirt(self, tiny_repo: Path) -> None:
        """Pre-existing modified-tracked file → captured to
        ``claw-forge-boot-<ts>`` and project_path becomes clean."""
        (tiny_repo / "tracked.txt").write_text("user wip not committed\n")
        marker = capture_boot_baseline(tiny_repo)
        assert marker is not None
        assert marker.startswith("claw-forge-boot-")
        # Stash exists.
        stash_list = _git(["stash", "list"], tiny_repo)
        assert marker in stash_list
        # Working tree restored to HEAD — invariant established.
        assert (tiny_repo / "tracked.txt").read_text() == "original\n"
        assert project_status_porcelain(tiny_repo) == set()

    def test_captures_untracked_dirt(self, tiny_repo: Path) -> None:
        """Untracked file at boot → captured via ``-u`` flag and
        removed from main's working tree."""
        (tiny_repo / "user_wip.py").write_text("scratch\n")
        marker = capture_boot_baseline(tiny_repo)
        assert marker is not None
        assert not (tiny_repo / "user_wip.py").exists()
        assert project_status_porcelain(tiny_repo) == set()

    def test_returns_none_in_non_git_dir(self, tmp_path: Path) -> None:
        """Outside a git repo, stash fails → ``None`` returned, no raise.
        Best-effort contract — same as the leak-stash helper."""
        not_a_repo = tmp_path / "not-a-repo"
        not_a_repo.mkdir()
        assert capture_boot_baseline(not_a_repo) is None

    def test_captured_baseline_recoverable_via_apply(
        self, tiny_repo: Path,
    ) -> None:
        """The contract that makes boot baseline safe: the operator can
        always recover their pre-run state via ``git stash apply <ref>``
        after the run completes."""
        (tiny_repo / "user_state.py").write_text("operator wip\n")
        marker = capture_boot_baseline(tiny_repo)
        assert marker is not None
        # Find the stash ref by message.
        stash_list = _git(["stash", "list"], tiny_repo).splitlines()
        ref = next(
            line.split(":", 1)[0] for line in stash_list if marker in line
        )
        # Restore — file should reappear with the same content.
        subprocess.run(
            ["git", "stash", "apply", "--quiet", ref],
            cwd=str(tiny_repo), check=True,
            capture_output=True, text=True,
        )
        assert (tiny_repo / "user_state.py").read_text() == "operator wip\n"
