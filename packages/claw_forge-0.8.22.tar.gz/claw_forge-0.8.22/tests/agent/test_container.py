"""Tests for ``claw_forge.agent.container`` — Level 4 opt-in container
isolation (v0.8.19).  Covers runtime detection, image-existence
checks, wrapper-script generation, and the fail-fast behaviours that
prevent silent fallback when the operator opted in.

The wrapper-script tests don't actually run ``docker`` — they
inspect the generated script's contents to verify mounts, env
forwarding, and arg pass-through.  Tests requiring a real container
runtime are gated on docker/podman availability.
"""
from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path
from unittest.mock import patch

import pytest

from claw_forge.agent.container import (
    _AUTH_ENV_VARS,
    detect_runtime,
    image_exists,
    make_container_wrapper,
    write_container_wrapper,
)


class TestDetectRuntime:
    def test_auto_returns_docker_when_available(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """``"auto"`` prefers docker (the more common default) over podman."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which",
            lambda name: "/usr/local/bin/docker" if name == "docker" else None,
        )
        assert detect_runtime("auto") == "docker"

    def test_auto_falls_through_to_podman(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """When docker isn't available but podman is, auto picks podman."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which",
            lambda name: "/usr/bin/podman" if name == "podman" else None,
        )
        assert detect_runtime("auto") == "podman"

    def test_auto_returns_none_when_neither_available(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """No runtime → ``None``; caller decides what to do."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which", lambda name: None,
        )
        assert detect_runtime("auto") is None

    def test_explicit_docker_requires_docker(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """``"docker"`` returns docker if available, else ``None`` —
        does NOT fall through to podman."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which",
            lambda name: "/usr/bin/podman" if name == "podman" else None,
        )
        assert detect_runtime("docker") is None

    def test_explicit_podman_requires_podman(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which",
            lambda name: "/usr/local/bin/docker" if name == "docker" else None,
        )
        assert detect_runtime("podman") is None


class TestImageExists:
    def test_returns_false_on_subprocess_error(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Image inspection failure (image not found, daemon not
        running, anything) → ``False``.  Best-effort check; caller
        decides whether to pull or fail."""
        import subprocess

        def fake_run(*args: object, **kwargs: object) -> object:
            raise subprocess.CalledProcessError(
                1, ["docker", "image", "inspect", "x"],
            )

        monkeypatch.setattr(
            "claw_forge.agent.container.subprocess.run", fake_run,
        )
        assert image_exists("docker", "nonexistent:latest") is False

    def test_returns_true_on_success(
        self, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        from subprocess import CompletedProcess

        def fake_run(*args: object, **kwargs: object) -> object:
            return CompletedProcess(args=[], returncode=0, stdout="", stderr="")

        monkeypatch.setattr(
            "claw_forge.agent.container.subprocess.run", fake_run,
        )
        assert image_exists("docker", "real-image:latest") is True


class TestWriteContainerWrapper:
    """Generated wrapper script contract — mounts, env vars,
    workdir, arg pass-through.  No docker invocation; we just
    inspect the script's contents."""

    @pytest.fixture
    def setup(self, tmp_path: Path) -> tuple[Path, Path]:
        """Return ``(worktree_path, output_dir)``."""
        worktree = tmp_path / "wt"
        worktree.mkdir()
        return worktree, tmp_path / "out"

    def test_wrapper_is_executable(
        self, setup: tuple[Path, Path],
    ) -> None:
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        assert wrapper.exists()
        assert os.access(wrapper, os.X_OK)
        assert wrapper.stat().st_mode & stat.S_IXUSR

    def test_wrapper_mounts_worktree_to_workspace(
        self, setup: tuple[Path, Path],
    ) -> None:
        """The single critical mount: worktree → /workspace.  The
        agent's cwd inside the container is /workspace; without this
        mount the agent has no way to read its own files."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        # Use resolved path so symlinks (e.g. /tmp → /private/tmp on
        # macOS) match what's actually written into the wrapper.
        assert f'-v "{worktree.resolve()}":/workspace' in content
        assert "--workdir /workspace" in content

    def test_wrapper_passes_anthropic_auth_env_vars(
        self, setup: tuple[Path, Path],
    ) -> None:
        """Container needs Anthropic auth to reach the API.  All
        three auth env vars are forwarded by name (the container
        reads the host's current value at run-time)."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        for var in _AUTH_ENV_VARS:
            assert f"-e {var}" in content

    def test_wrapper_does_not_mount_parent_project(
        self, setup: tuple[Path, Path],
    ) -> None:
        """The Level 4 promise: parent project absent from container's
        filesystem namespace.  Wrapper must not have a ``-v <parent>``
        mount that would re-introduce the leak surface."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        # Parent project is the worktree's parent directory.
        parent = worktree.parent.resolve()
        assert f'-v "{parent}":' not in content

    def test_wrapper_passes_args_through(
        self, setup: tuple[Path, Path],
    ) -> None:
        """SDK invokes ``<wrapper> <claude_args>``; wrapper must pass
        ``"$@"`` to claude inside the container so the SDK's args
        reach the agent verbatim."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        assert "claude" in content
        assert '"$@"' in content

    def test_extra_mounts_are_added(
        self, setup: tuple[Path, Path],
    ) -> None:
        """Operator-supplied extra mounts (test fixtures, language
        toolchains, etc.) appear as additional ``-v`` flags."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
            extra_mounts=["/host/cache:/cache:ro"],
        )
        assert '-v "/host/cache:/cache:ro"' in wrapper.read_text()

    def test_extra_env_vars_are_forwarded(
        self, setup: tuple[Path, Path],
    ) -> None:
        """Beyond the auth set, operator can add domain env vars."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="docker", image="my-img",
            worktree_path=worktree, output_dir=out,
            extra_env=["MY_PROJECT_TOKEN", "TEST_ENV"],
        )
        content = wrapper.read_text()
        assert "-e MY_PROJECT_TOKEN" in content
        assert "-e TEST_ENV" in content

    def test_runtime_is_used_in_wrapper(
        self, setup: tuple[Path, Path],
    ) -> None:
        """Podman wrapper uses ``podman run``, not ``docker run`` —
        the wrapper is portable across both runtimes."""
        worktree, out = setup
        wrapper = write_container_wrapper(
            runtime="podman", image="my-img",
            worktree_path=worktree, output_dir=out,
        )
        content = wrapper.read_text()
        assert "podman run" in content
        assert "docker run" not in content


class TestMakeContainerWrapper:
    """High-level entrypoint contract: fail-fast on missing runtime
    or image, no silent fallback when operator opted in."""

    def test_raises_when_runtime_missing(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Operator set ``isolation: container`` → silent fallback to
        weaker isolation would violate their explicit choice.  Raise
        with a clear message instead."""
        monkeypatch.setattr(
            "claw_forge.agent.container.shutil.which", lambda name: None,
        )
        with pytest.raises(RuntimeError, match="requires"):
            make_container_wrapper(
                worktree_path=tmp_path / "wt",
                output_dir=tmp_path / "out",
                image="my-img",
            )

    def test_raises_when_image_missing_and_pull_disabled(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Default ``pull_if_missing: false`` — operator controls image
        sourcing.  Quietly pulling from a registry the operator didn't
        approve would be a security surprise."""
        monkeypatch.setattr(
            "claw_forge.agent.container.detect_runtime",
            lambda pref: "docker",
        )
        monkeypatch.setattr(
            "claw_forge.agent.container.image_exists", lambda r, i: False,
        )
        (tmp_path / "wt").mkdir()
        with pytest.raises(RuntimeError, match="not found"):
            make_container_wrapper(
                worktree_path=tmp_path / "wt",
                output_dir=tmp_path / "out",
                image="missing:latest",
            )

    def test_attempts_pull_when_pull_if_missing_true(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Opt-in pull: ``pull_if_missing: true`` triggers a single
        ``docker pull`` attempt; success → wrapper, failure → raise."""
        from subprocess import CompletedProcess

        pull_calls: list[list[str]] = []

        def fake_run(args: list[str], **kw: object) -> object:
            pull_calls.append(args)
            return CompletedProcess(args=args, returncode=0, stdout="", stderr="")

        monkeypatch.setattr(
            "claw_forge.agent.container.detect_runtime",
            lambda pref: "docker",
        )
        monkeypatch.setattr(
            "claw_forge.agent.container.image_exists", lambda r, i: False,
        )
        monkeypatch.setattr(
            "claw_forge.agent.container.subprocess.run", fake_run,
        )
        (tmp_path / "wt").mkdir()
        wrapper = make_container_wrapper(
            worktree_path=tmp_path / "wt",
            output_dir=tmp_path / "out",
            image="will-pull:latest",
            pull_if_missing=True,
        )
        assert wrapper.exists()
        assert any(a[0:2] == ["docker", "pull"] for a in pull_calls)

    def test_returns_wrapper_when_image_present(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """Happy path: runtime + image both available → wrapper
        written, no pull attempted."""
        monkeypatch.setattr(
            "claw_forge.agent.container.detect_runtime",
            lambda pref: "docker",
        )
        monkeypatch.setattr(
            "claw_forge.agent.container.image_exists", lambda r, i: True,
        )
        (tmp_path / "wt").mkdir()
        wrapper = make_container_wrapper(
            worktree_path=tmp_path / "wt",
            output_dir=tmp_path / "out",
            image="present:latest",
        )
        assert wrapper.exists()
        assert os.access(wrapper, os.X_OK)


@pytest.mark.skipif(
    shutil.which("docker") is None,
    reason="docker required for end-to-end container test",
)
class TestEndToEndDockerAvailable:
    """Integration tests that actually run docker — gated on
    docker availability so they skip cleanly on CI runners
    without a daemon."""

    def test_detect_runtime_finds_docker(self) -> None:
        """When docker is on PATH AND the daemon is running, detect
        succeeds.  This is the smoke test that ``v0.8.19`` is
        usable on this host."""
        with patch("claw_forge.agent.container.shutil.which", wraps=shutil.which):
            assert detect_runtime("docker") == "docker"
