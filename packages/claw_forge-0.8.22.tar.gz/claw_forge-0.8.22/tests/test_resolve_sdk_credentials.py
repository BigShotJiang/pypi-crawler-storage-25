"""Regression tests for ``_resolve_sdk_credentials`` — the helper that
picks which env vars to seed for a Claude Agent SDK invocation.

This test file exists because of a real silent-failure mode shipped from
v0.8.5 through v0.8.10: the SDK env-cred picker set
``ANTHROPIC_SETUP_TOKEN`` for OAuth providers, but that env var is
**only** consumed by the one-shot ``claude setup-token`` import flow —
not by a running ``claude`` CLI.  The CLI silently ignored it and fell
through to the keychain identity from the operator's last ``claude
login``.  Result: every agent in a 3-OAuth-token parallel-dispatch setup
authenticated as the same keychain user, the configured ``oauth_token``
providers were never used, and the operator's per-token usage dashboards
showed zero traffic for hours.

Per the official Claude Code authentication precedence
(https://code.claude.com/docs/en/authentication#authentication-precedence),
runtime auth env vars are:

  1. ``ANTHROPIC_AUTH_TOKEN`` → Bearer header (OAuth access tokens, proxy
     bearer tokens — anything ``sk-ant-oat01-…`` shaped or any custom
     gateway token).
  2. ``ANTHROPIC_API_KEY`` → X-Api-Key header (direct Anthropic API keys
     ``sk-ant-api03-…``).

Empirically verified against the live ``claude`` CLI: bogus
``ANTHROPIC_AUTH_TOKEN`` returns 401 *Invalid bearer token* (env wins
over keychain), bogus ``ANTHROPIC_SETUP_TOKEN`` is silently dropped
(keychain wins), bogus ``CLAUDE_CODE_OAUTH_TOKEN`` is also silently
dropped despite the documented precedence — only ``ANTHROPIC_AUTH_TOKEN``
reliably overrides keychain and accepts ``sk-ant-oat01-…`` tokens.
"""
from __future__ import annotations

import sys
import types
from dataclasses import dataclass

# ``claude_agent_sdk.types`` import via cli.py — same workaround as
# ``test_pool_toggle.py``.
if "claude_agent_sdk" not in sys.modules:
    sys.modules["claude_agent_sdk"] = types.ModuleType("claude_agent_sdk")

import pytest


@dataclass
class _FakeProviderConfig:
    name: str
    api_key: str = ""
    oauth_token: str = ""


@dataclass
class _FakeProvider:
    name: str
    config: _FakeProviderConfig


class _FakePool:
    """Stand-in for ``ProviderPoolManager`` — returns a fixed sequence of
    providers from ``next_provider_for_dispatch()`` so the cred picker can
    be tested without spinning up a real pool."""

    def __init__(self, providers: list[_FakeProvider | None]) -> None:
        self._providers = list(providers)
        self._idx = 0

    def next_provider_for_dispatch(self) -> _FakeProvider | None:
        if self._idx >= len(self._providers):
            return None
        p = self._providers[self._idx]
        self._idx += 1
        return p


def _picker():
    from claw_forge.cli import _resolve_sdk_credentials
    return _resolve_sdk_credentials


# ── Process-env precedence ──────────────────────────────────────────────


class TestProcessEnvWins:
    def test_api_key_env_var_wins_over_pool(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``ANTHROPIC_API_KEY`` in the operator's shell takes precedence
        over any pool config (legacy behaviour preserved)."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-api03-from-shell")
        monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)

        pool = _FakePool([
            _FakeProvider("claude-oauth-1", _FakeProviderConfig(
                "claude-oauth-1", oauth_token="sk-ant-oat01-pool",
            )),
        ])
        sdk_env, provider_name = _picker()(pool)

        assert sdk_env == {"ANTHROPIC_API_KEY": "sk-ant-api03-from-shell"}
        assert provider_name == "env"

    def test_auth_token_env_var_wins_over_pool(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``ANTHROPIC_AUTH_TOKEN`` in the operator's shell takes precedence
        over any pool config — and crucially is the right env var name (NOT
        the v0.8.5–v0.8.10 ``ANTHROPIC_SETUP_TOKEN`` which the CLI ignores)."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "sk-ant-oat01-from-shell")

        pool = _FakePool([
            _FakeProvider("claude-oauth-1", _FakeProviderConfig(
                "claude-oauth-1", oauth_token="sk-ant-oat01-pool",
            )),
        ])
        sdk_env, provider_name = _picker()(pool)

        assert sdk_env == {"ANTHROPIC_AUTH_TOKEN": "sk-ant-oat01-from-shell"}
        assert provider_name == "env"

    def test_api_key_takes_precedence_over_auth_token_when_both_set(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When both env vars are set, ``ANTHROPIC_API_KEY`` wins (matches
        the documented Claude CLI precedence — API_KEY is checked before
        AUTH_TOKEN in the env path)."""
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-api03-from-shell")
        monkeypatch.setenv("ANTHROPIC_AUTH_TOKEN", "sk-ant-oat01-from-shell")

        sdk_env, provider_name = _picker()(None)

        assert sdk_env == {"ANTHROPIC_API_KEY": "sk-ant-api03-from-shell"}
        assert provider_name == "env"


# ── Pool fallback when no process-env creds ─────────────────────────────


class TestPoolFallback:
    def test_oauth_provider_seeds_anthropic_auth_token(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """**The v0.8.11 fix.**  An OAuth provider's token must be seeded as
        ``ANTHROPIC_AUTH_TOKEN`` (Bearer header) — NOT ``ANTHROPIC_SETUP_TOKEN``
        which the CLI silently ignores at runtime.  Pre-v0.8.11 this test
        would have asserted ``ANTHROPIC_SETUP_TOKEN`` and the regression that
        kept all agents pinned to keychain would have shipped silently."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)

        pool = _FakePool([
            _FakeProvider("claude-oauth-1", _FakeProviderConfig(
                "claude-oauth-1", oauth_token="sk-ant-oat01-aaa",
            )),
        ])
        sdk_env, provider_name = _picker()(pool)

        assert "ANTHROPIC_AUTH_TOKEN" in sdk_env, (
            f"OAuth tokens must seed ANTHROPIC_AUTH_TOKEN (Bearer); got {sdk_env}"
        )
        assert sdk_env["ANTHROPIC_AUTH_TOKEN"] == "sk-ant-oat01-aaa"
        assert "ANTHROPIC_SETUP_TOKEN" not in sdk_env, (
            "ANTHROPIC_SETUP_TOKEN is the import-flow env var, not a runtime "
            "auth credential — must never be set by the SDK env-cred picker"
        )
        assert provider_name == "claude-oauth-1"

    def test_api_key_provider_seeds_anthropic_api_key(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """An ``api_key`` provider's key seeds ``ANTHROPIC_API_KEY``
        (X-Api-Key header) — unchanged from prior versions."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)

        pool = _FakePool([
            _FakeProvider("anthropic-direct", _FakeProviderConfig(
                "anthropic-direct", api_key="sk-ant-api03-direct",
            )),
        ])
        sdk_env, provider_name = _picker()(pool)

        assert sdk_env == {"ANTHROPIC_API_KEY": "sk-ant-api03-direct"}
        assert provider_name == "anthropic-direct"

    def test_pool_none_returns_empty_sdk_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """``pool=None`` and no process env → empty sdk_env so the CLI falls
        back to its keychain identity (pre-claw-forge behaviour, single
        identity).  Backward-compat: ``claw-forge run`` against a yaml with
        no providers configured still works."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)

        sdk_env, provider_name = _picker()(None)

        assert sdk_env == {}
        assert provider_name == "env"

    def test_pool_returns_no_provider_returns_empty_sdk_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When every pool provider is disabled / circuit-open / rate-
        limited, ``next_provider_for_dispatch`` returns ``None`` — the cred
        picker leaves ``sdk_env`` empty so the CLI surfaces a clean auth
        error rather than silently using a stale credential."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)

        pool = _FakePool([None])  # next call returns None
        sdk_env, provider_name = _picker()(pool)

        assert sdk_env == {}
        assert provider_name == "env"

    def test_provider_with_neither_creds_returns_empty(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """A provider with empty ``api_key`` AND empty ``oauth_token``
        (e.g. ``${VAR}`` placeholder didn't resolve) seeds nothing — the
        CLI surfaces a clean auth error rather than seeding ``""``."""
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.delenv("ANTHROPIC_AUTH_TOKEN", raising=False)

        pool = _FakePool([
            _FakeProvider("misconfigured", _FakeProviderConfig("misconfigured")),
        ])
        sdk_env, provider_name = _picker()(pool)

        assert sdk_env == {}
        # provider_name stays at "env" — the picker never advanced past the
        # fallthrough path.
        assert provider_name == "env"
