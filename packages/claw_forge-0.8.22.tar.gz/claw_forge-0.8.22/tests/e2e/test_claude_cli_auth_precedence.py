"""End-to-end regression test: verify the live ``claude`` CLI honours
``ANTHROPIC_AUTH_TOKEN`` (and that ``ANTHROPIC_SETUP_TOKEN`` is silently
ignored at runtime).

Why this lives here: the v0.8.5–v0.8.10 silent-failure mode existed
because the codebase couldn't see the CLI's actual env-var precedence —
the unit-tested helper picked the right-looking string but the CLI
quietly dropped it.  This test calls the real ``claude`` binary so that
if Anthropic ever changes the precedence (or fixes the
``ANTHROPIC_SETUP_TOKEN`` bug), this test fails loudly and we revisit
``_resolve_sdk_credentials``.

Skipped when:
  - The ``claude`` CLI is not on ``PATH`` (CI without the SDK installed).
  - ``CLAW_FORGE_E2E_CLAUDE_CLI=1`` is not set in the env (opt-in — these
    tests cost real Anthropic API tokens, so they don't run by default).
"""
from __future__ import annotations

import os
import shutil
import subprocess

import pytest

_SKIP_REASON_PATH = "claude CLI not on PATH"
_SKIP_REASON_OPT = (
    "set CLAW_FORGE_E2E_CLAUDE_CLI=1 to opt into this e2e test "
    "(it spends real Anthropic API tokens)"
)

pytestmark = [
    pytest.mark.skipif(
        shutil.which("claude") is None, reason=_SKIP_REASON_PATH
    ),
    pytest.mark.skipif(
        os.environ.get("CLAW_FORGE_E2E_CLAUDE_CLI") != "1",
        reason=_SKIP_REASON_OPT,
    ),
]


def _claude_print(
    env: dict[str, str], prompt: str = "reply with single word: pong",
) -> subprocess.CompletedProcess[str]:
    """Run a one-shot ``claude --print`` invocation under the given env.

    Inherits PATH and HOME from the test runner so the ``claude`` binary
    is locatable; nukes every Anthropic-relevant auth env var first so
    the test only exercises the keys we explicitly pass in ``env``.
    """
    base = {
        "PATH": os.environ.get("PATH", ""),
        "HOME": os.environ.get("HOME", ""),
    }
    base.update(env)
    return subprocess.run(
        [
            "claude",
            "--print",
            "--model", "claude-sonnet-4-6",
            prompt,
        ],
        env=base,
        capture_output=True,
        text=True,
        timeout=30,
    )


def test_anthropic_auth_token_with_bogus_value_returns_401() -> None:
    """If the CLI honours ``ANTHROPIC_AUTH_TOKEN`` (it should), a bogus
    value forces a 401 *Invalid bearer token* — env wins over keychain.

    Pre-v0.8.11 we wrongly believed ``ANTHROPIC_SETUP_TOKEN`` was
    runtime-honoured; this test asserts the working knob is
    ``ANTHROPIC_AUTH_TOKEN``."""
    result = _claude_print({"ANTHROPIC_AUTH_TOKEN": "bogus-bearer-test-value"})
    combined = (result.stdout + result.stderr).lower()
    assert "invalid bearer" in combined or "401" in combined, (
        f"Expected 401 / invalid bearer, got stdout={result.stdout!r} stderr={result.stderr!r}"
    )


def test_anthropic_setup_token_does_not_authenticate_alone() -> None:
    """A bogus ``ANTHROPIC_SETUP_TOKEN`` paired with a *valid*
    ``ANTHROPIC_AUTH_TOKEN`` must not interfere — proving SETUP_TOKEN is
    not a runtime auth credential.  If SETUP_TOKEN ever became
    runtime-honoured, this test would still pass *via the AUTH_TOKEN
    fallback*, so the asymmetry is captured by the bogus-AUTH_TOKEN-401
    test above plus this no-op one.

    Requires ``CLAW_FORGE_TEST_OAUTH_TOKEN`` set to a valid
    ``sk-ant-oat01-…`` token."""
    valid_token = os.environ.get("CLAW_FORGE_TEST_OAUTH_TOKEN")
    if not valid_token:
        pytest.skip("set CLAW_FORGE_TEST_OAUTH_TOKEN to a valid sk-ant-oat01-… token")

    result = _claude_print({
        "ANTHROPIC_AUTH_TOKEN": valid_token,
        "ANTHROPIC_SETUP_TOKEN": "bogus-noise-must-not-break-anything",
    })
    assert result.returncode == 0, (
        f"Adding bogus SETUP_TOKEN broke a valid AUTH_TOKEN call: "
        f"stdout={result.stdout!r} stderr={result.stderr!r}"
    )


def test_anthropic_auth_token_overrides_keychain_with_valid_token() -> None:
    """If the operator supplies ``ANTHROPIC_AUTH_TOKEN`` with a valid OAuth
    token in the env (not their keychain identity), the CLI uses *that*
    token — not keychain.  This is the load-bearing behaviour for
    claw-forge's per-task OAuth rotation.

    Requires ``CLAW_FORGE_TEST_OAUTH_TOKEN`` set to a valid OAuth access
    token (``sk-ant-oat01-…``) in addition to the opt-in env var."""
    valid_token = os.environ.get("CLAW_FORGE_TEST_OAUTH_TOKEN")
    if not valid_token:
        pytest.skip(
            "set CLAW_FORGE_TEST_OAUTH_TOKEN to a valid sk-ant-oat01-… token "
            "for this assertion"
        )

    result = _claude_print({"ANTHROPIC_AUTH_TOKEN": valid_token})
    combined = (result.stdout + result.stderr).lower()
    assert result.returncode == 0, (
        f"Valid ANTHROPIC_AUTH_TOKEN failed: stdout={result.stdout!r} stderr={result.stderr!r}"
    )
    assert "invalid" not in combined and "401" not in combined
