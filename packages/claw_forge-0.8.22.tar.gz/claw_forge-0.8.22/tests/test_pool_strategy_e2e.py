"""End-to-end tests for ``ProviderPoolManager.execute()`` under every
routing strategy.

The unit tests in ``test_router.py`` verify ``Router.select(...)`` ordering
in isolation; these tests verify the wired-up dispatch path actually picks
the right provider, observes strategy semantics across multiple calls,
and falls through to the next provider on failure.

Pattern: build a pool with N ``CallRecordingProvider`` instances under a
specific strategy, patch ``asyncio.sleep`` to skip real backoff, call
``pool.execute(...)`` one or more times, and assert which provider(s)
ran via the recorded call counts.
"""

from __future__ import annotations

import sys
import types

# Mock claude_agent_sdk if not installed (pre-existing pattern from
# test_pool_toggle.py — required when the file is collected before any
# test that imports the real package).
if "claude_agent_sdk" not in sys.modules:
    sys.modules["claude_agent_sdk"] = types.ModuleType("claude_agent_sdk")

from typing import Any
from unittest.mock import patch

import pytest

from claw_forge.pool.health import CircuitBreaker
from claw_forge.pool.manager import ProviderPoolManager
from claw_forge.pool.providers.base import (
    BaseProvider,
    ProviderConfig,
    ProviderError,
    ProviderResponse,
    ProviderType,
)
from claw_forge.pool.router import RoutingStrategy


class CallRecordingProvider(BaseProvider):
    """Records every execute() call; configurable to fail N times first."""

    def __init__(
        self,
        config: ProviderConfig,
        *,
        fail_count: int = 0,
        latency_ms: float = 50.0,
    ) -> None:
        super().__init__(config)
        self.calls: int = 0
        self._fail_count = fail_count
        self._latency_ms = latency_ms

    async def execute(self, model: str, messages: list, **kwargs: Any) -> ProviderResponse:  # type: ignore[override]
        self.calls += 1
        if self._fail_count > 0:
            self._fail_count -= 1
            raise ProviderError(f"{self.name}: simulated failure", retryable=True)
        return ProviderResponse(
            content="ok",
            model=model,
            provider_name=self.name,
            input_tokens=10,
            output_tokens=5,
            latency_ms=self._latency_ms,
        )

    async def health_check(self) -> bool:
        return True


def _build_pool(
    n: int = 3,
    *,
    strategy: RoutingStrategy = RoutingStrategy.PRIORITY,
    weights: list[float] | None = None,
    costs: list[float] | None = None,
    fail_counts: list[int] | None = None,
    max_retries: int = 1,
) -> ProviderPoolManager:
    """Build a pool of N CallRecordingProvider instances for a given strategy.

    ``weights`` / ``costs`` / ``fail_counts`` are per-provider; defaults
    spread these so each strategy has a clear "winner" in tests.
    """
    weights = weights if weights is not None else [1.0] * n
    costs = costs if costs is not None else [float(i + 1) for i in range(n)]
    fail_counts = fail_counts if fail_counts is not None else [0] * n

    configs = [
        ProviderConfig(
            name=f"p{i}",
            provider_type=ProviderType.ANTHROPIC,
            priority=i + 1,
            api_key="k",
            weight=weights[i],
            cost_per_mtok_input=costs[i],
        )
        for i in range(n)
    ]
    pool = ProviderPoolManager(configs, strategy=strategy, max_retries=max_retries)
    pool._providers = [
        CallRecordingProvider(c, fail_count=fail_counts[i]) for i, c in enumerate(configs)
    ]
    pool._circuits = {p.name: CircuitBreaker(p.name) for p in pool._providers}
    return pool


async def _execute_once(pool: ProviderPoolManager) -> ProviderResponse:
    """Call pool.execute with a stub asyncio.sleep so tests don't actually wait."""
    async def _no_sleep(_: float) -> None:
        return None

    with patch("claw_forge.pool.manager.asyncio.sleep", side_effect=_no_sleep):
        return await pool.execute(model="test", messages=[{"role": "user", "content": "hi"}])


# ── PRIORITY ────────────────────────────────────────────────────────────────

class TestPriorityStrategyE2E:
    """``priority`` always prefers the lowest-priority-integer provider."""

    @pytest.mark.asyncio
    async def test_priority_picks_lowest_priority_first(self) -> None:
        pool = _build_pool(3, strategy=RoutingStrategy.PRIORITY)
        await _execute_once(pool)
        assert pool._providers[0].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[1].calls == 0  # type: ignore[attr-defined]
        assert pool._providers[2].calls == 0  # type: ignore[attr-defined]

    @pytest.mark.asyncio
    async def test_priority_falls_through_to_next_on_failure(self) -> None:
        """p0 fails once → router falls through to p1 within the same attempt."""
        pool = _build_pool(3, strategy=RoutingStrategy.PRIORITY, fail_counts=[1, 0, 0])
        await _execute_once(pool)
        assert pool._providers[0].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[1].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[2].calls == 0  # type: ignore[attr-defined]


# ── ROUND_ROBIN ─────────────────────────────────────────────────────────────

class TestRoundRobinStrategyE2E:
    """``round_robin`` advances a cursor per call so load spreads evenly
    across providers."""

    @pytest.mark.asyncio
    async def test_round_robin_full_cycle_through_all_providers(self) -> None:
        """3 providers, 3 successful calls → each called exactly once."""
        pool = _build_pool(3, strategy=RoutingStrategy.ROUND_ROBIN)
        for _ in range(3):
            await _execute_once(pool)
        assert pool._providers[0].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[1].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[2].calls == 1  # type: ignore[attr-defined]

    @pytest.mark.asyncio
    async def test_round_robin_repeats_cycle_after_n_calls(self) -> None:
        """6 calls across 3 providers → each called exactly twice."""
        pool = _build_pool(3, strategy=RoutingStrategy.ROUND_ROBIN)
        for _ in range(6):
            await _execute_once(pool)
        assert pool._providers[0].calls == 2  # type: ignore[attr-defined]
        assert pool._providers[1].calls == 2  # type: ignore[attr-defined]
        assert pool._providers[2].calls == 2  # type: ignore[attr-defined]

    @pytest.mark.asyncio
    async def test_round_robin_cursor_advances_by_one_per_call(self) -> None:
        """Within one execute() call, p0 fails → router falls through to p1
        within the same ``select()`` result.  The cursor advances **once per
        ``select()`` call**, not once per provider tried, so the next
        execute() call starts from p1 (cursor=1), not p2.  This locks in
        the cursor-advancement contract — a regression that incremented
        the cursor per provider attempt would surface here."""
        pool = _build_pool(3, strategy=RoutingStrategy.ROUND_ROBIN, fail_counts=[1, 0, 0])
        await _execute_once(pool)
        # Call 1 used select()→[p0, p1, p2]; tried p0 (fail) then p1 (success).
        # Cursor advanced 0 → 1 once.
        assert pool._providers[0].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[1].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[2].calls == 0  # type: ignore[attr-defined]

        await _execute_once(pool)
        # Call 2 uses select()→[p1, p2, p0] (cursor=1), tries p1 first → success.
        # If the cursor had advanced twice (once per provider tried in call 1),
        # this call would start from p2 instead and p1.calls would stay at 1.
        assert pool._providers[1].calls == 2  # type: ignore[attr-defined]
        assert pool._providers[2].calls == 0  # type: ignore[attr-defined]


# ── LEAST_COST ──────────────────────────────────────────────────────────────

class TestLeastCostStrategyE2E:
    """``least_cost`` orders by ``cost_per_mtok_input`` ascending."""

    @pytest.mark.asyncio
    async def test_least_cost_picks_cheapest_first(self) -> None:
        # costs out of order: p0=3.0, p1=1.0, p2=2.0 → p1 should win.
        pool = _build_pool(3, strategy=RoutingStrategy.LEAST_COST, costs=[3.0, 1.0, 2.0])
        await _execute_once(pool)
        assert pool._providers[1].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[0].calls == 0  # type: ignore[attr-defined]
        assert pool._providers[2].calls == 0  # type: ignore[attr-defined]

    @pytest.mark.asyncio
    async def test_least_cost_falls_through_to_second_cheapest(self) -> None:
        # cheapest (p1) fails → next cheapest (p2) is used.
        pool = _build_pool(
            3,
            strategy=RoutingStrategy.LEAST_COST,
            costs=[3.0, 1.0, 2.0],
            fail_counts=[0, 1, 0],
        )
        await _execute_once(pool)
        assert pool._providers[1].calls == 1  # type: ignore[attr-defined]  # tried first, failed
        assert pool._providers[2].calls == 1  # type: ignore[attr-defined]  # second cheapest, succeeded
        assert pool._providers[0].calls == 0  # type: ignore[attr-defined]  # most expensive, never reached


# ── LEAST_LATENCY ───────────────────────────────────────────────────────────

class TestLeastLatencyStrategyE2E:
    """``least_latency`` sorts by per-provider p50 latency observed in the
    UsageTracker.  Cold-start has no samples and falls through whatever
    the tracker returns by default."""

    @pytest.mark.asyncio
    async def test_least_latency_after_warmup_picks_fastest(self) -> None:
        pool = _build_pool(3, strategy=RoutingStrategy.LEAST_LATENCY)
        # Seed the tracker with synthetic latency samples: p2 is fastest.
        pool._tracker.record_request("p0", 10, 5, 1.0, 1.0, latency_ms=100.0)
        pool._tracker.record_request("p1", 10, 5, 1.0, 1.0, latency_ms=80.0)
        pool._tracker.record_request("p2", 10, 5, 1.0, 1.0, latency_ms=20.0)

        # Reset call counters so the warmup record_request calls don't pollute
        # the assertion (record_request doesn't invoke provider.execute, but
        # be explicit).
        for p in pool._providers:
            p.calls = 0  # type: ignore[attr-defined]

        await _execute_once(pool)
        assert pool._providers[2].calls == 1  # type: ignore[attr-defined]
        assert pool._providers[0].calls == 0  # type: ignore[attr-defined]
        assert pool._providers[1].calls == 0  # type: ignore[attr-defined]


# ── WEIGHTED_RANDOM ─────────────────────────────────────────────────────────

class TestWeightedRandomStrategyE2E:
    """``weighted_random`` samples by the ``weight:`` config field.  The
    distribution is statistical, so we test bulk behaviour over many
    trials with a generous tolerance instead of asserting exact ratios."""

    @pytest.mark.asyncio
    async def test_weighted_random_skews_toward_heavier_weight(self) -> None:
        """With weights [9, 1], p0 should win first-call dispatch
        substantially more often than p1 across 200 trials.

        Each trial uses a fresh pool to reset the round-robin cursor and
        ensure independence.  Tolerance: p0 wins at least 70% of trials
        (expected ~90%; binomial 95% CI for n=200, p=0.9 is roughly
        [85%, 94%], well above 70%)."""
        n_trials = 200
        p0_wins = 0
        for _ in range(n_trials):
            pool = _build_pool(2, strategy=RoutingStrategy.WEIGHTED_RANDOM, weights=[9.0, 1.0])
            await _execute_once(pool)
            if pool._providers[0].calls == 1:  # type: ignore[attr-defined]
                p0_wins += 1
        win_rate = p0_wins / n_trials
        assert win_rate > 0.70, (
            f"weighted_random with weights=[9,1] only picked p0 {win_rate:.1%} of the time"
            f" across {n_trials} trials (expected ~90%)"
        )

    @pytest.mark.asyncio
    async def test_next_provider_for_dispatch_round_robin(self) -> None:
        """``next_provider_for_dispatch()`` rotates through enabled providers
        under round_robin — used by the CLI's SDK env-cred picker so each
        agent gets the next OAuth token in rotation rather than pinning every
        agent to ``pool.providers[0]``."""
        pool = _build_pool(3, strategy=RoutingStrategy.ROUND_ROBIN)
        names = [pool.next_provider_for_dispatch().name for _ in range(6)]  # type: ignore[union-attr]
        # Six picks across three providers under round_robin: each name
        # appears exactly twice; cursor advances per call.
        assert sorted(names[:3]) == ["p0", "p1", "p2"]
        assert names[:3] == names[3:]

    @pytest.mark.asyncio
    async def test_next_provider_for_dispatch_skips_disabled(self) -> None:
        """Disabled providers are filtered by Router.select — picker should
        never return them.  Mirrors the fengshui-yaml case where the user
        has anthropic-direct disabled but oauth-1/2/3 enabled."""
        pool = _build_pool(3, strategy=RoutingStrategy.ROUND_ROBIN)
        pool._providers[0].config.enabled = False  # type: ignore[index]
        names = {pool.next_provider_for_dispatch().name for _ in range(20)}  # type: ignore[union-attr]
        assert names == {"p1", "p2"}  # p0 disabled, never picked

    @pytest.mark.asyncio
    async def test_next_provider_for_dispatch_returns_none_when_all_unavailable(self) -> None:
        """All providers disabled → caller falls back to a clear auth error
        rather than receiving a stale provider."""
        pool = _build_pool(2, strategy=RoutingStrategy.ROUND_ROBIN)
        for p in pool._providers:
            p.config.enabled = False  # type: ignore[attr-defined]
        assert pool.next_provider_for_dispatch() is None

    @pytest.mark.asyncio
    async def test_weighted_random_eventually_picks_each_provider(self) -> None:
        """Equal weights → both providers get picked at least once over 50
        trials.  This guards against the bug class where a strategy gets
        stuck on a single provider."""
        n_trials = 50
        seen: set[str] = set()
        for _ in range(n_trials):
            pool = _build_pool(2, strategy=RoutingStrategy.WEIGHTED_RANDOM, weights=[1.0, 1.0])
            await _execute_once(pool)
            for p in pool._providers:
                if p.calls > 0:  # type: ignore[attr-defined]
                    seen.add(p.name)
        assert seen == {"p0", "p1"}, f"weighted_random never selected {{'p0','p1'}} - {seen}"
