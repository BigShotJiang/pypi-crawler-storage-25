"""Typer subapp: ``claw-forge export [training]``.

CSV/SQL/JSON export of session+task data from state.db, plus JSONL export of
agent trajectories for fine-tuning.

This module is intentionally self-contained (no SDK imports) so it can be
imported directly in tests without triggering the SDK import chain.
"""

from __future__ import annotations

import json
import os
import re
import sqlite3 as _sq
from pathlib import Path
from typing import Any, Literal, cast

import typer
import yaml
from rich.console import Console

export_app = typer.Typer(
    invoke_without_command=True,
    no_args_is_help=False,
    help=(
        "Export session/task data. Without a subcommand, exports CSV/SQL/JSON. "
        "Use 'claw-forge export training' for fine-tuning JSONL."
    ),
)

console = Console()


# ── Internal helpers (self-contained, no SDK dep) ────────────────────────────


def _load_env_file(directory: Path) -> None:
    """Load a .env file from *directory* into ``os.environ`` (setdefault)."""
    env_file = directory / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            key, _, val = line.partition("=")
            os.environ.setdefault(key.strip(), val.strip())


def _expand_env_vars(obj: object) -> object:
    """Recursively expand ${VAR} and ${VAR:-default} placeholders."""
    if isinstance(obj, str):
        def _replace(m: re.Match) -> str:  # type: ignore[type-arg]
            expr = m.group(1)
            if ":-" in expr:
                key, default = expr.split(":-", 1)
                return os.environ.get(key.strip(), default.strip())
            return os.environ.get(expr, "")
        return re.sub(r"\$\{([^}]+)\}", _replace, obj)
    if isinstance(obj, dict):
        return {k: _expand_env_vars(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_env_vars(i) for i in obj]
    return obj


def _load_config_yaml(config_path: str) -> dict[str, Any]:
    """Load YAML config — best-effort, no scaffolding, no console errors."""
    path = Path(config_path)
    if not path.exists():
        return {}
    _load_env_file(path.parent)
    raw = yaml.safe_load(path.read_text())
    if raw is None:
        return {}
    return _expand_env_vars(raw)  # type: ignore[return-value]


def _resolve_latest_session(db_path: Path, project_path: Path | None = None) -> str:
    """Read the most-recent session id from state.db; return '' if none found."""
    try:
        if db_path.exists():
            with _sq.connect(str(db_path)) as conn:
                if project_path is not None:
                    row = conn.execute(
                        "SELECT id FROM sessions WHERE project_path = ? "
                        "ORDER BY created_at DESC LIMIT 1",
                        (str(project_path),),
                    ).fetchone()
                else:
                    row = conn.execute(
                        "SELECT id FROM sessions ORDER BY created_at DESC LIMIT 1"
                    ).fetchone()
                if row:
                    return str(row[0])
    except Exception:  # noqa: BLE001
        pass
    return ""


def _session_exists(db_path: Path, session_id: str) -> bool:
    try:
        with _sq.connect(str(db_path)) as conn:
            row = conn.execute(
                "SELECT 1 FROM sessions WHERE id = ? LIMIT 1", (session_id,)
            ).fetchone()
            return row is not None
    except Exception:  # noqa: BLE001
        return False


def _list_sessions_for_help(
    db_path: Path, project_path: Path | None = None, limit: int = 10
) -> list[tuple[str, str, str]]:
    try:
        if not db_path.exists():
            return []
        with _sq.connect(str(db_path)) as conn:
            if project_path is not None:
                cursor = conn.execute(
                    "SELECT id, project_path, created_at FROM sessions "
                    "WHERE project_path = ? "
                    "ORDER BY created_at DESC LIMIT ?",
                    (str(project_path), limit),
                )
            else:
                cursor = conn.execute(
                    "SELECT id, project_path, created_at FROM sessions "
                    "ORDER BY created_at DESC LIMIT ?",
                    (limit,),
                )
            return [(str(r[0]), str(r[1]), str(r[2])) for r in cursor.fetchall()]
    except Exception:  # noqa: BLE001
        return []


def _count_sessions_and_tasks(
    db_path: Path, session_id: str | None
) -> tuple[int, int]:
    try:
        with _sq.connect(str(db_path)) as conn:
            if session_id is None:
                s_count = conn.execute("SELECT COUNT(*) FROM sessions").fetchone()[0]
                t_count = conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
            else:
                s_count = conn.execute(
                    "SELECT COUNT(*) FROM sessions WHERE id = ?", (session_id,)
                ).fetchone()[0]
                t_count = conn.execute(
                    "SELECT COUNT(*) FROM tasks WHERE session_id = ?", (session_id,)
                ).fetchone()[0]
            return int(s_count), int(t_count)
    except Exception:  # noqa: BLE001
        return 0, 0


def _print_session_hints(db_path: Path, project_path: Path) -> None:
    sessions = _list_sessions_for_help(db_path, project_path=project_path)
    if not sessions:
        sessions = _list_sessions_for_help(db_path)
    if sessions:
        console.print("\n  Available sessions:")
        for sid, ppath, created in sessions:
            console.print(
                f"    [cyan]{sid}[/cyan]  {created}  [dim]{ppath}[/dim]"
            )
    else:
        console.print(
            "\n  [dim]No sessions in DB. Run [bold]claw-forge run[/bold] first.[/dim]"
        )


# ── export (default — CSV/SQL/JSON) ─────────────────────────────────────────


@export_app.callback()
def _export_default(
    ctx: typer.Context,
    format_: str = typer.Option(
        "csv", "--format", "-f", help="Output format: csv, sql, json.",
    ),
    scope: str = typer.Option(
        "session", "--scope",
        help="'session' = one session, 'all' = entire DB.",
    ),
    session: str = typer.Option(
        "", "--session", "-s",
        help="Session UUID (default: latest session for this project).",
    ),
    csv_mode: str = typer.Option(
        "flat", "--csv-mode",
        help="'flat' = denormalized CSV, 'split' = directory with one CSV per table.",
    ),
    out: str = typer.Option(
        "", "--out", "-o",
        help="Output path (file, or directory for --csv-mode split). "
             "Default: claw-forge-export-<id>-<timestamp>.<ext>.",
    ),
    project: str = typer.Option(
        ".", "--project", "-p",
        help="Project directory (to find .claw-forge/state.db).",
    ),
) -> None:
    """Export session and task data from state.db to CSV, SQL, or JSON.

    Examples:

        claw-forge export                                 # latest session, flat CSV
        claw-forge export --format sql                    # SQL dump
        claw-forge export --format json --scope all       # all sessions, JSON
        claw-forge export --csv-mode split                # directory with per-table CSVs
        claw-forge export --session <uuid> --out my.csv   # explicit session + path
    """
    if ctx.invoked_subcommand is not None:
        return

    from datetime import datetime as _dt

    from claw_forge.exporter import (
        export_csv_flat,
        export_csv_split,
        export_json,
        export_sql,
    )

    fmt = format_.lower()
    if fmt not in ("csv", "sql", "json"):
        console.print(
            f"[bold red]✖  Unknown --format {format_!r}.[/bold red] "
            "Choose one of: csv, sql, json."
        )
        raise typer.Exit(1)
    if scope not in ("session", "all"):
        console.print(
            f"[bold red]✖  Unknown --scope {scope!r}.[/bold red] "
            "Choose one of: session, all."
        )
        raise typer.Exit(1)
    if csv_mode not in ("flat", "split"):
        console.print(
            f"[bold red]✖  Unknown --csv-mode {csv_mode!r}.[/bold red] "
            "Choose one of: flat, split."
        )
        raise typer.Exit(1)

    project_path = Path(project).resolve()
    db_path = project_path / ".claw-forge" / "state.db"
    if not db_path.exists():
        console.print(
            f"[bold red]✖  State database not found at {db_path}[/bold red]"
        )
        console.print(
            "  Run [bold]claw-forge run[/bold] in this project to create it,\n"
            "  or pass [bold]--project[/bold] to point at the right directory."
        )
        raise typer.Exit(1)

    session_id: str | None
    if scope == "all":
        session_id = None
    else:
        if session:
            session_id = session
            if not _session_exists(db_path, session_id):
                console.print(
                    f"[bold red]✖  Session {session_id!r} not found in "
                    f"{db_path}.[/bold red]"
                )
                _print_session_hints(db_path, project_path)
                raise typer.Exit(1)
        else:
            resolved = _resolve_latest_session(db_path, project_path)
            if not resolved:
                console.print(
                    "[bold red]✖  No session found for this project.[/bold red]"
                )
                _print_session_hints(db_path, project_path)
                raise typer.Exit(1)
            session_id = resolved

    timestamp = _dt.now().strftime("%Y%m%d-%H%M%S")
    if not out:
        if scope == "all":
            base = f"claw-forge-export-all-{timestamp}"
        else:
            assert session_id is not None
            base = f"claw-forge-export-{session_id[:8]}-{timestamp}"
        if fmt == "csv" and csv_mode == "split":
            out = base
        else:
            ext = fmt
            out = f"{base}.{ext}"
    out_path = Path(out)

    if fmt == "csv":
        if csv_mode == "split":
            result_path = export_csv_split(db_path, session_id, out_path)
            fmt_label = "CSV (split)"
        else:
            result_path = export_csv_flat(db_path, session_id, out_path)
            fmt_label = "CSV (flat)"
    elif fmt == "sql":
        result_path = export_sql(db_path, session_id, out_path)
        fmt_label = "SQL"
    else:
        result_path = export_json(db_path, session_id, out_path)
        fmt_label = "JSON"

    s_count, t_count = _count_sessions_and_tasks(db_path, session_id)
    if scope == "all":
        console.print(
            f"\n  [green]✓[/green] Exported {s_count} session(s), "
            f"{t_count} task(s)"
        )
    else:
        assert session_id is not None
        console.print(
            f"\n  [green]✓[/green] Exported {t_count} task(s) from "
            f"session {session_id[:8]}…"
        )
    console.print(f"  Format:  {fmt_label}")
    console.print(f"  Output:  {result_path}\n")


# ── export training ─────────────────────────────────────────────────────────


@export_app.command("training")
def export_training(
    scope: str = typer.Option("all", "--scope"),
    session: str = typer.Option("", "--session"),
    filter_: str = typer.Option("both", "--filter"),
    include_failed: bool = typer.Option(False, "--include-failed"),
    format_: str = typer.Option("openai-tools", "--format"),
    include_diff: bool = typer.Option(True, "--include-diff/--no-include-diff"),
    include_thinking: bool = typer.Option(True, "--include-thinking/--no-include-thinking"),
    min_turns: int = typer.Option(4, "--min-turns"),
    max_turns: int = typer.Option(200, "--max-turns"),
    redact: str = typer.Option("both", "--redact"),
    dedupe_by: str = typer.Option("both", "--dedupe-by"),
    split: str = typer.Option("", "--split", help="e.g. 80/10/10"),
    out: str = typer.Option("", "--out", "-o"),
    project: str = typer.Option(".", "--project", "-p"),
) -> None:
    """Export agent trajectories as JSONL for fine-tuning."""
    from claw_forge.training import exporter as exp
    from claw_forge.training import projectors as proj
    from claw_forge.training.redact import (
        CustomPatternsRule,
        Redactor,
        SecretsRule,
        UsernamesRule,
    )

    if filter_ not in ("success", "recovered", "both"):
        console.print(f"[red]✖  Unknown --filter {filter_!r}[/red]")
        raise typer.Exit(1)
    if format_ not in ("openai-tools", "sharegpt", "chatml", "raw-jsonl"):
        console.print(f"[red]✖  Unknown --format {format_!r}[/red]")
        raise typer.Exit(1)
    if dedupe_by not in ("prompt", "diff", "both", "none"):
        console.print(f"[red]✖  Unknown --dedupe-by {dedupe_by!r}[/red]")
        raise typer.Exit(1)

    project_path = Path(project).resolve()
    db_path = project_path / ".claw-forge" / "state.db"
    if not db_path.exists():
        console.print(f"[red]✖  State database not found at {db_path}[/red]")
        raise typer.Exit(1)

    sess_id: str | None = session or None
    if scope == "session" and not sess_id:
        sess_id = _resolve_latest_session(db_path, project_path)

    # Build redactor from --redact + custom patterns from yaml (if available)
    rules: list[Any] = []
    if redact in ("secrets", "both"):
        rules.append(SecretsRule())
    if redact in ("usernames", "both"):
        rules.append(UsernamesRule())
    custom: list[str] = []
    try:
        cfg_yaml = _load_config_yaml(str(project_path / "claw-forge.yaml"))
        custom = list(((cfg_yaml.get("training_traces") or {}).get("redaction") or {}).get(
            "custom_patterns") or [])
    except Exception:  # noqa: BLE001
        pass
    if custom:
        rules.append(CustomPatternsRule(patterns=custom))
    redactor = Redactor(rules=rules)
    redaction_rule_names = [r.name for r in rules]

    # Narrow validated str → Literal for the typed exporter API
    scope_lit = cast('Literal["session", "all"]', scope)
    filter_lit = cast('Literal["success", "recovered", "both"]', filter_)
    dedupe_lit = cast('Literal["prompt", "diff", "both", "none"]', dedupe_by)

    raw_iter = exp.iter_training_records(
        db_path,
        scope=scope_lit, session=sess_id,
        filter_=filter_lit, include_failed=include_failed,
        include_diff=include_diff, repo_dir=project_path,
        redaction_rules=redaction_rule_names,
    )

    def _passes_turn_filter(rec: dict[str, Any]) -> bool:
        n = sum(1 for ev in rec.get("raw_events", []) if ev.get("kind") == "AssistantMessage")
        return min_turns <= n <= max_turns

    filtered = (r for r in raw_iter if _passes_turn_filter(r))
    deduped = exp.dedupe_records(filtered, by=dedupe_lit)

    project_fn = {
        "openai-tools": proj.to_openai_tools,
        "sharegpt": proj.to_sharegpt,
        "chatml": proj.to_chatml,
        "raw-jsonl": proj.to_raw_jsonl,
    }[format_]

    projected = [
        redactor.apply(project_fn(r, include_thinking=include_thinking))
        for r in deduped
    ]

    if split:
        parts = [int(x) for x in split.split("/")]
        if len(parts) != 3 or sum(parts) != 100:
            console.print("[red]✖  --split must be like 80/10/10[/red]")
            raise typer.Exit(1)
        ratios = (parts[0] / 100, parts[1] / 100, parts[2] / 100)
        train, val, test = exp.split_records(projected, ratios=ratios)
        out_dir = Path(out) if out else project_path / "claw-forge-training"
        out_dir.mkdir(parents=True, exist_ok=True)
        for name, recs in [("train", train), ("val", val), ("test", test)]:
            (out_dir / f"{name}.jsonl").write_text(
                "\n".join(json.dumps(r) for r in recs) + ("\n" if recs else "")
            )
        console.print(
            f"[green]✓ wrote {len(train)}/{len(val)}/{len(test)} "
            f"records to {out_dir}[/green]"
        )
    else:
        body = "\n".join(json.dumps(r) for r in projected)
        if projected:
            body += "\n"
        if out:
            out_path = Path(out)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(body)
            console.print(
                f"[green]✓ wrote {len(projected)} records to {out_path}[/green]"
            )
        else:
            console.print(body, end="")
