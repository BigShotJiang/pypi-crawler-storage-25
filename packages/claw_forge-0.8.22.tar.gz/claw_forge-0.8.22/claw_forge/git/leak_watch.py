"""Mid-run leak detection — catch the v0.8.15 leak class at the point
where it actually leaks, not just at startup.

The smart-cleanup at startup (``cleanup.py``) handles dirt that exists
*when ``claw-forge run`` boots*.  But the v0.8.14 leak class (agent
writes to the parent project mid-run via ``git -C``, ``python /abs/…``,
or other escape patterns the per-tool sandbox can't intercept) generates
NEW dirt after startup.  Without mid-run watching, that dirt sits in
the target branch's working tree until the next startup-time cleanup
— and worse, the squash-merge flow happily commits it as part of
whatever task happens to land next.

This module brackets each agent's execution with a snapshot of
``git status --porcelain`` on ``project_path``:

  1. Pre-agent: snapshot baseline dirt (likely empty if smart cleanup
     ran).  Concurrent agents complicate this — T2's leak might already
     be in T1's baseline, but the *delta* between bracketing snapshots
     captures dirt added during T1's window specifically.
  2. Post-agent: re-snapshot, compute set difference.  Any new entries
     are dirt added during the agent's lifetime — strongly suggestive
     of a leak.
  3. If leaked dirt is detected, ``stash_leak_with_marker`` captures it
     to ``refs/stash`` with a marker referencing the suspect task ID
     so the operator can correlate, inspect, and ``git stash apply``
     the work into the correct worktree later.

The check is best-effort: any subprocess failure logs and returns the
empty set / None — the dispatcher must not fail the task on a leak-
watch hiccup.  The tradeoff is we may miss a leak when ``git`` is
flaky, which is the right error mode for a forensic safety net.
"""
from __future__ import annotations

import logging
import subprocess
from datetime import datetime
from pathlib import Path

_log = logging.getLogger(__name__)


def project_status_porcelain(project_dir: Path) -> set[str]:
    """Return the set of dirty/untracked file paths in *project_dir*.

    Uses ``git status --porcelain`` so the format is stable across git
    versions (unlike ``--short`` which can change column widths).

    Returns the empty set when the directory is clean OR when git is
    unreachable — the caller should treat both as "no leak detectable".
    """
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=str(project_dir),
            capture_output=True,
            text=True,
            check=True,
            timeout=15,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        _log.warning(
            "leak-watch: git status failed for %s: %s", project_dir, exc,
        )
        return set()
    return {
        # Strip the 2-char status prefix + space (e.g. ``?? path/to/foo``
        # → ``path/to/foo``).  Quoted paths (with leading ``"``) are
        # preserved as-is — the operator can still read them.
        line[3:].strip()
        for line in result.stdout.splitlines()
        if line.strip()
    }


def capture_boot_baseline(project_dir: Path) -> str | None:
    """Capture *project_dir*'s pre-run state as a boot baseline (v0.8.17).

    Called once at dispatcher startup, AFTER smart-cleanup runs.  If
    smart-cleanup left main clean (the default + intended path), this
    returns ``None`` and no stash is created.  If main has dirt at boot
    — either because the operator opted out of smart-cleanup
    (``handle_uncommitted_at_startup: ignore``) or because cleanup
    couldn't archive everything — the dirt is captured to a stash
    tagged with the run timestamp.

    The boot baseline establishes the snapshot-rollback invariant for
    the run: ``project_dir`` must be HEAD-clean for the entire dispatch
    lifetime.  Pre-existing operator state goes here and is recoverable
    via ``claw-forge stash list`` (kind=boot) + ``git stash apply``.

    Returns the stash marker on success, ``None`` if main was already
    clean OR if the stash command failed (the snapshot-rollback path
    then degrades to "all changes treated as leaks", which is correct
    when there was no baseline to preserve).
    """
    marker = (
        f"claw-forge-boot-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    )
    # Pathspec exclusion: ``.claw-forge/`` is the harness's own state dir
    # (state.db, state.log, worktrees/, orphans/, …) and must NEVER be
    # captured by the boot baseline.  In a freshly-initialised repo or
    # in test fixtures that don't ``.gitignore`` it, the orphans archive
    # smart-cleanup just produced would otherwise be stashed and lost.
    # The pathspec ``. ':!.claw-forge'`` says "everything in the project
    # root except ``.claw-forge``" (git's negative-pathspec syntax).
    try:
        result = subprocess.run(
            [
                "git", "stash", "push", "-u", "-m", marker,
                "--", ".", ":!.claw-forge", ":!.claw-forge/**",
            ],
            cwd=str(project_dir),
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        _log.warning(
            "leak-watch: boot baseline stash failed for %s: %s",
            project_dir, exc,
        )
        return None
    # ``git stash push`` prints "No local changes to save" and exits 0
    # when there's nothing to stash — the desired healthy state.
    combined = (result.stdout or "") + (result.stderr or "")
    if "No local changes" in combined:
        return None
    _log.info(
        "leak-watch: captured boot baseline as %s — recover pre-run state "
        "with `git stash apply <ref>` after the run completes",
        marker,
    )
    return marker


def stash_leak_with_marker(
    project_dir: Path,
    task_id: str,
    leaked: set[str],
) -> str | None:
    """Stash leaked dirt in *project_dir* with a marker tagging the
    suspect *task_id* and a UTC timestamp.

    Uses ``git stash push -u`` (``-u`` includes untracked) so a single
    stash entry captures both the new files and the modified-tracked
    diff.  Returns the stash message on success, ``None`` on failure
    (caller should log and continue — leak detection is best-effort).
    """
    if not leaked:
        return None
    marker = (
        f"claw-forge-leak-{task_id[:8]}-"
        f"{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    )
    try:
        subprocess.run(
            ["git", "stash", "push", "-u", "-m", marker],
            cwd=str(project_dir),
            capture_output=True,
            text=True,
            check=True,
            timeout=30,
        )
    except (subprocess.SubprocessError, OSError) as exc:
        _log.warning(
            "leak-watch: stash failed for %s (task %s): %s",
            project_dir, task_id, exc,
        )
        return None
    _log.warning(
        "leak-watch: stashed %d leaked path(s) from task %s as %s — "
        "recover with `git stash apply stash@{0}` if needed; sample: %s",
        len(leaked), task_id, marker, sorted(leaked)[:3],
    )
    return marker
