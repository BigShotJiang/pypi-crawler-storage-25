"""Smart-mode worktree cleanup at ``claw-forge run`` startup.

When ``git.cleanup_orphan_worktrees: smart`` is set in ``claw-forge.yaml``,
the startup hook walks every directory under ``.claw-forge/worktrees/`` and
decides — based on the corresponding task's state in the DB — whether to
preserve, salvage, or remove it.  This bridges the gap left by the legacy
gate (``orphans_reset > 0``), which only fires for tasks killed mid-run and
ignores residue from terminally-failed tasks and from ``completed`` tasks
whose squash-merge itself failed (the v0.5.35 bug class).

Decision matrix (``decide_action``):

================  ============  ===============================================
task.status       has_commits   action      rationale
================  ============  ===============================================
``pending``       True          preserve    resume substrate for prefer_resumable
``pending``       False         remove      empty branch; nothing to keep
``running``       any           preserve    handled by orphans_reset path
``failed``        True          salvage     terminal — no auto-retry across runs
``failed``        False         remove      empty branch; nothing to keep
``completed``     True          salvage     squash failed previously (v0.5.35)
``completed``     False         remove      bookkeeping; merge already happened
no matching task  True          salvage     orphan from prior session
no matching task  False         remove      no value, no owner
================  ============  ===============================================

Conflicts during salvage preserve the worktree + branch and surface a
report to the user.  When ``git.llm_conflict_proposals: true`` is also set,
``draft_conflict_proposal`` is invoked to write a ``CONFLICT_PROPOSAL.md``
inside the preserved worktree the user can read, edit, and apply.
"""

from __future__ import annotations

import shutil
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, Protocol

from claw_forge.git.branching import (
    branch_exists,
    branch_has_commits_ahead,
)
from claw_forge.git.merge import squash_merge
from claw_forge.git.repo import _run_git
from claw_forge.git.slug import make_branch_name

Action = Literal["preserve", "salvage", "remove"]


@dataclass
class CleanupOutcome:
    slug: str
    branch: str
    action: Action
    task_status: str | None
    success: bool = False
    commit_hash: str | None = None
    error: str | None = None
    proposal_path: str | None = None
    conflicts: list[str] = field(default_factory=list)


class ConflictAdvisor(Protocol):
    """Pluggable hook for drafting CONFLICT_PROPOSAL.md on salvage failure.

    Kept as a Protocol so ``cleanup.py`` doesn't import the agent runner
    transitively — callers wire in ``draft_conflict_proposal`` from
    ``conflict_advisor.py`` only when the config flag is on.
    """

    def __call__(
        self,
        project_dir: Path,
        worktree_path: Path,
        branch: str,
        target: str,
        task: dict[str, Any] | None,
    ) -> Path | None:
        ...


def decide_action(task_status: str | None, has_commits: bool) -> Action:
    """Pick preserve/salvage/remove based on task state and committed work.

    No external dependencies — pure logic — so it's trivially unit-testable.
    """
    if not has_commits:
        return "remove"
    if task_status in ("pending", "running"):
        # Pending: keep as resume substrate for prefer_resumable.
        # Running: orphans_reset will reset it shortly; let that path own it.
        return "preserve"
    # ``failed``, ``completed``, or no matching task → salvage.
    return "salvage"


# ── Uncommitted-state handling (startup hook) ──────────────────────────────────
#
# At ``claw-forge run`` startup, the harness scans the main worktree for any
# uncommitted state — untracked files, unstaged modifications to tracked
# files, and staged-but-not-committed changes — and dispatches per-state
# actions fully autonomously.  No human in the loop.  Hard gate: no agent
# worktrees are created until the main worktree is clean.
#
# Architectural rule: agent worktrees branch from main's HEAD commit.  Anything
# not in HEAD is invisible to the agent and a future squash-merge collision.
# So the discriminator is binary: committed-to-HEAD vs everything-else.  Three
# uncommitted states each get the right reversible primitive:
#
# Decision matrix (smart mode):
#   untracked file                → archive to .claw-forge/orphans/<ts>/<path>
#                                   with PROVENANCE.json (recover via cp)
#   unstaged-modified tracked     → ┐
#   staged-not-committed tracked  → ┴ git stash push (recover via stash pop)
#
# Both primitives are reversible.  ``smart`` mode never aborts — the harness
# owns the cleanup end-to-end.  ``abort`` mode (explicit opt-in) refuses to
# start whenever any uncommitted state exists.

UncommittedAction = Literal["archive", "stash"]


@dataclass
class UncommittedDecision:
    """A single per-file decision from ``classify_untracked_file``.

    Stash decisions are bundled at the composition layer — one ``git stash
    push`` operation captures all dirty-tracked files at once — so per-file
    Decision objects with action='stash' are produced for accounting only.
    """

    path: str
    action: UncommittedAction
    reason: str
    matched_glob: str | None = None


def _glob_matches(path: str, pattern: str) -> bool:
    """Match *path* against *pattern* with ``**`` semantics.

    Matches the same globbing rules as ``touches_files`` declarations
    use elsewhere in claw-forge: ``*`` matches a single path segment,
    ``**`` matches zero or more segments.
    """
    import re
    from pathlib import PurePath

    if "**" not in pattern:
        return PurePath(path).match(pattern)
    parts = pattern.split("**")
    regex = ".*".join(re.escape(p).replace(r"\*", "[^/]*") for p in parts)
    return re.fullmatch(regex, path) is not None


def classify_untracked_file(
    *,
    path: str,
    known_touches_globs: set[str],
) -> UncommittedDecision:
    """Decide how to archive an untracked file.

    Pure function — no I/O.  Always returns ``action='archive'`` since
    untracked files have no in-tree baseline to preserve.  Cross-references
    the path against the session's task ``touches_files`` declarations to
    enrich the provenance JSON; matching files get a ``matched_glob`` field
    pointing to the originating task.
    """
    for glob in known_touches_globs:
        if _glob_matches(path, glob):
            return UncommittedDecision(
                path=path,
                action="archive",
                reason=f"matches known task touches_files glob: {glob}",
                matched_glob=glob,
            )
    return UncommittedDecision(
        path=path,
        action="archive",
        reason="orphan untracked file with no task provenance",
    )


def _collect_untracked_files(project_dir: Path) -> list[str]:
    """Return untracked files in *project_dir* as relative paths.

    Honors ``.gitignore``.  Uses ``--untracked-files=all`` so each file in
    an untracked directory is listed individually (default ``normal`` mode
    collapses to the directory name, losing per-file granularity).  Returns
    an empty list if *project_dir* isn't a git repo.
    """
    try:
        result = _run_git(
            ["status", "--porcelain", "--untracked-files=all"], project_dir,
        )
    except Exception:  # noqa: BLE001
        return []
    out: list[str] = []
    for line in result.stdout.splitlines():
        if line.startswith("?? "):
            out.append(line[3:])
    return out


def _collect_dirty_tracked_files(project_dir: Path) -> list[str]:
    """Return tracked files with unstaged or staged-not-committed changes.

    Reads ``git status --porcelain`` and filters for any non-untracked
    status entry (any line whose 2-char prefix isn't ``??``).  Captures
    the modify / add / delete / rename / copy axes in either the index
    or working-tree column.
    """
    try:
        result = _run_git(["status", "--porcelain"], project_dir)
    except Exception:  # noqa: BLE001
        return []
    out: list[str] = []
    for line in result.stdout.splitlines():
        if not line or line.startswith("??"):
            continue
        # ``XY <path>`` — first two chars are status, then space, then path.
        # Renames look like ``R  old -> new``; we want the new name.
        path_part = line[3:]
        if " -> " in path_part:
            path_part = path_part.split(" -> ", 1)[1]
        out.append(path_part)
    return out


def _archive_one(
    *,
    project_dir: Path,
    archive_root: Path,
    decision: UncommittedDecision,
) -> Path:
    """Move one untracked file from *project_dir* to *archive_root*,
    preserving the relative directory structure.  Writes a sibling
    ``<filename>.PROVENANCE.json`` describing the decision.

    Returns the destination path.
    """
    import json

    src = project_dir / decision.path
    dst = archive_root / decision.path
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))

    provenance_path = dst.with_name(dst.name + ".PROVENANCE.json")
    provenance_path.write_text(
        json.dumps(
            {
                "path": decision.path,
                "action": decision.action,
                "reason": decision.reason,
                "matched_glob": decision.matched_glob,
            },
            indent=2,
        )
        + "\n"
    )
    return dst


def _stash_dirty_state(project_dir: Path, *, message: str) -> str | None:
    """Run ``git stash push -m <message>`` in *project_dir*.

    Captures the entire dirty-tracked state in one stash entry — both
    unstaged modifications and the index.  Untracked files must be
    archived separately *before* this call; ``-u`` is intentionally NOT
    passed so this function is purely scoped to tracked state.

    Returns the stash message (used as a recovery marker) on success,
    None if there was nothing to stash or the operation failed.
    """
    try:
        result = _run_git(
            ["stash", "push", "-m", message], project_dir,
        )
    except Exception:  # noqa: BLE001
        return None
    # ``git stash push`` prints "No local changes to save" and exits 0
    # when there's nothing to stash — treat as soft no-op.
    if "No local changes" in (result.stdout + result.stderr):
        return None
    return message


@dataclass
class UncommittedHandlingResult:
    """Outcome of ``smart_handle_uncommitted_in_project_dir``.

    Smart mode is fully autonomous: every uncommitted file is dispatched
    to a reversible primitive.  No abort cell.  ``proceed`` is always
    True — the property is preserved for callsite compatibility but
    never returns False from this function.

    Recovery:
      - archived files: ``cp`` from ``archive_root``
      - stashed state:  ``git stash list`` → ``git stash pop`` matching
        ``stash_message``
    """

    decisions: list[UncommittedDecision] = field(default_factory=list)
    archived: list[str] = field(default_factory=list)
    stashed: list[str] = field(default_factory=list)
    archive_root: Path | None = None
    stash_message: str | None = None

    @property
    def proceed(self) -> bool:
        return True


def smart_handle_uncommitted_in_project_dir(
    *,
    project_dir: Path,
    tasks: list[dict[str, Any]],
) -> UncommittedHandlingResult:
    """Scan *project_dir* for uncommitted state and dispatch per-state
    actions automatically.

    Two phases:
      1. Walk untracked files; archive each to
         ``.claw-forge/orphans/<startup-ts>/<original-path>`` with a
         sibling ``PROVENANCE.json`` (path + reason + matched_glob).
      2. ``git stash push`` once to capture all dirty-tracked state in
         a single stash entry tagged with the same timestamp.

    *tasks* is the session's task list (any ``status``).  Each task's
    ``touches_files`` field is folded into the known-provenance set used
    to enrich archive PROVENANCE.json entries.

    Always returns ``proceed=True`` — smart mode never refuses to start.
    Both primitives are reversible.
    """
    from datetime import datetime

    untracked = _collect_untracked_files(project_dir)
    dirty_tracked = _collect_dirty_tracked_files(project_dir)

    result = UncommittedHandlingResult()
    if not untracked and not dirty_tracked:
        return result

    known_globs: set[str] = set()
    for t in tasks:
        for g in t.get("touches_files") or []:
            known_globs.add(g)

    ts = datetime.now().strftime("%Y%m%d-%H%M%S")

    # Phase 1: archive untracked files with provenance.
    archive_root: Path | None = None
    for path in untracked:
        decision = classify_untracked_file(
            path=path, known_touches_globs=known_globs,
        )
        result.decisions.append(decision)
        if archive_root is None:
            archive_root = project_dir / ".claw-forge" / "orphans" / ts
            archive_root.mkdir(parents=True, exist_ok=True)
            result.archive_root = archive_root
        _archive_one(
            project_dir=project_dir,
            archive_root=archive_root,
            decision=decision,
        )
        result.archived.append(path)

    # Phase 2: stash dirty-tracked state in one operation.
    if dirty_tracked:
        stash_msg = f"claw-forge-auto-{ts}"
        stash_ref = _stash_dirty_state(project_dir, message=stash_msg)
        if stash_ref is not None:
            result.stash_message = stash_ref
            for path in dirty_tracked:
                result.decisions.append(UncommittedDecision(
                    path=path, action="stash",
                    reason="dirty tracked file — preserved in git stash",
                ))
                result.stashed.append(path)

    return result


def is_main_worktree_clean(project_dir: Path) -> bool:
    """True when *project_dir*'s working tree has no uncommitted state.

    Used by the abort-mode gate in cli.py: when
    ``git.handle_uncommitted_at_startup: abort``, the run refuses to
    start unless this returns True.
    """
    if _collect_untracked_files(project_dir):
        return False
    return not _collect_dirty_tracked_files(project_dir)


def _build_slug_to_task_map(
    tasks: list[dict[str, Any]], *, prefix: str,
) -> dict[str, dict[str, Any]]:
    """Map worktree slug → task dict by reproducing the branch-name slug.

    The dispatcher's ``create_worktree`` derives the slug from
    ``make_branch_name(description, category, plugin)``; we replay the same
    derivation here to find each worktree directory's owning task.
    """
    out: dict[str, dict[str, Any]] = {}
    for t in tasks:
        branch = make_branch_name(
            t.get("description"),
            t.get("category"),
            t.get("plugin_name") or prefix,
            prefix=prefix,
        )
        slug = branch.removeprefix(f"{prefix}/")
        out[slug] = t
    return out


def smart_cleanup_worktrees(
    project_dir: Path,
    tasks: list[dict[str, Any]],
    *,
    prefix: str = "feat",
    target: str = "main",
    advisor: ConflictAdvisor | None = None,
    title_for_salvage: str | None = None,
) -> list[CleanupOutcome]:
    """Walk ``.claw-forge/worktrees/`` and act per-slug per the decision matrix.

    *tasks* is the session's task list as returned by the state service
    (``init_data["tasks"]``).  Each task dict must include at least
    ``description``, ``category``, ``plugin_name``, and ``status``.

    Returns a list of :class:`CleanupOutcome` records the caller can render.
    """
    worktrees_dir = project_dir / ".claw-forge" / "worktrees"
    if not worktrees_dir.is_dir():
        return []

    slug_to_task = _build_slug_to_task_map(tasks, prefix=prefix)
    outcomes: list[CleanupOutcome] = []

    for child in sorted(worktrees_dir.iterdir()):
        if not child.is_dir():
            continue
        slug = child.name
        branch = f"{prefix}/{slug}"
        task = slug_to_task.get(slug)
        task_status = task.get("status") if task else None
        has_commits = (
            branch_exists(project_dir, branch)
            and branch_has_commits_ahead(project_dir, branch, target)
        )
        action = decide_action(task_status, has_commits)
        outcome = CleanupOutcome(
            slug=slug, branch=branch, action=action, task_status=task_status,
        )

        if action == "preserve":
            outcome.success = True
            outcomes.append(outcome)
            continue

        if action == "remove":
            with suppress(Exception):
                _run_git(
                    ["worktree", "remove", "--force", str(child)],
                    project_dir,
                )
            if child.exists():
                shutil.rmtree(child, ignore_errors=True)
            # If the branch has no commits ahead it's safe to delete too —
            # but be defensive and only delete when branch_exists confirms it.
            if branch_exists(project_dir, branch):
                with suppress(Exception):
                    _run_git(
                        ["branch", "-D", branch], project_dir,
                    )
            outcome.success = True
            outcomes.append(outcome)
            continue

        # action == "salvage"
        result = squash_merge(
            project_dir, branch, target,
            title=title_for_salvage or f"salvage: {branch}",
            worktree_path=child,
        )
        if result.get("merged"):
            outcome.success = True
            outcome.commit_hash = result.get("commit_hash")
        else:
            outcome.success = False
            outcome.error = result.get("error")
            # Conflict — invoke advisor if provided.  Defensively swallow
            # advisor failures: they must not break the cleanup loop.
            if advisor is not None:
                with suppress(Exception):
                    proposal = advisor(project_dir, child, branch, target, task)
                    if proposal is not None:
                        outcome.proposal_path = str(proposal)
        outcomes.append(outcome)

    # Final bookkeeping sweep — drop stale entries in .git/worktrees/ for
    # directories we just removed.
    with suppress(Exception):
        _run_git(["worktree", "prune"], project_dir)

    return outcomes


__all__ = [
    "Action",
    "CleanupOutcome",
    "ConflictAdvisor",
    "decide_action",
    "smart_cleanup_worktrees",
]
