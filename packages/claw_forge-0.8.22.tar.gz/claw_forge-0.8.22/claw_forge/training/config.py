"""Config schema for ``training_traces`` in claw-forge.yaml.

Two-key opt-in by design: ``enabled`` and ``acknowledged_terms`` must both
be true before any traces are recorded.  See the spec at
``docs/superpowers/specs/2026-05-06-training-trace-capture-design.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class TrainingTracesConfig:
    """Resolved training-traces configuration with sane defaults.

    All flags default to the safest stance:
    - capture: OFF (both ``enabled`` and ``acknowledged_terms`` default False)
    - redaction: secrets ON, usernames ON (low-risk anonymisation),
      paths OFF (file structure is meaningful learning signal)
    - retention: forever (``keep_days=0``)
    """

    enabled: bool = False
    acknowledged_terms: bool = False
    redaction_secrets: bool = True
    redaction_usernames: bool = True
    redaction_paths: bool = False
    redaction_custom_patterns: list[str] = field(default_factory=list)
    retention_keep_days: int = 0
    retention_on_startup: bool = True

    @property
    def recording_active(self) -> bool:
        """Both flags must flip on for recording to actually happen."""
        return self.enabled and self.acknowledged_terms


def extract_training_traces_config(raw: dict[str, Any]) -> TrainingTracesConfig:
    """Extract the ``training_traces`` block from a loaded claw-forge.yaml dict.

    Missing keys take their dataclass defaults (everything OFF for capture,
    sensible defaults for redaction and retention).
    """
    block = raw.get("training_traces") or {}
    redaction = block.get("redaction") or {}
    retention = block.get("retention") or {}
    return TrainingTracesConfig(
        enabled=bool(block.get("enabled", False)),
        acknowledged_terms=bool(block.get("acknowledged_terms", False)),
        redaction_secrets=bool(redaction.get("secrets", True)),
        redaction_usernames=bool(redaction.get("usernames", True)),
        redaction_paths=bool(redaction.get("paths", False)),
        redaction_custom_patterns=list(redaction.get("custom_patterns") or []),
        retention_keep_days=int(retention.get("keep_days", 0)),
        retention_on_startup=bool(retention.get("on_state_service_startup", True)),
    )


def banner_message_for(cfg: TrainingTracesConfig) -> str | None:
    """Return the one-time startup banner text when traces are gated.

    If the user enabled traces but hasn't acknowledged terms, the state
    service should log this once at startup.  Returns None when off or
    fully active — no banner needed in those states.
    """
    if not cfg.enabled or cfg.acknowledged_terms:
        return None
    return (
        "\n"
        "─── Training-trace capture is GATED ───\n"
        "  training_traces.enabled=true but acknowledged_terms=false.\n"
        "  No traces will be recorded until you set acknowledged_terms=true.\n"
        "\n"
        "  Reminder: Anthropic's Usage Policies prohibit using Claude outputs\n"
        "  to develop models that compete with Anthropic's services.  This\n"
        "  feature is intended for personal/internal distillation on your own\n"
        "  code, for your own internal use.  Distribution of derived models\n"
        "  is your responsibility.\n"
        "──────────────────────────────────────────"
    )
