"""Training-trace capture & export.

Captures full agent trajectories from claw-forge runs into the events table,
then exports them as JSONL for fine-tuning smaller code-specific LLMs.

Disabled by default — opt in via ``training_traces.enabled`` and
``training_traces.acknowledged_terms`` in claw-forge.yaml.
"""
