"""Export-time redaction.

Applied AFTER projection (so it sees the final JSONL shape) and BEFORE
serialization (so the regex sweeps cover every string field). Walks records
recursively; non-string values pass through.

Why export-time and not capture-time:
  Capture-time redaction is destructive and irreversible. Export-time lets
  the user re-export with different rules and keeps the local DB authoritative.
  The "DB leaks while sitting on disk" threat is already covered by the
  existing trust boundary (``.claw-forge/state.db`` is project-local — same
  trust as the source code).
"""

from __future__ import annotations

import getpass
import re
from dataclasses import dataclass, field
from typing import Any, Protocol


class RedactionRule(Protocol):
    name: str
    def apply_text(self, text: str) -> str: ...


# Conservative pattern set — better to miss some than to mangle innocuous
# strings that happen to look secret-shaped.
_SECRET_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"AKIA[0-9A-Z]{16}"), "<REDACTED:secret>"),                  # AWS access key
    (re.compile(r"(?i)aws_secret[_a-z0-9]*\s*[:=]\s*\S+"), "<REDACTED:secret>"),
    (re.compile(r"ghp_[A-Za-z0-9]{36}"), "<REDACTED:secret>"),               # GitHub PAT
    (re.compile(r"github_pat_[A-Za-z0-9_]{82}"), "<REDACTED:secret>"),       # GitHub fine-grained
    (re.compile(r"sk-ant-(api|admin)\d+-[A-Za-z0-9_-]{40,}"), "<REDACTED:secret>"),  # Anthropic
    (re.compile(r"sk-(?!ant-)[A-Za-z0-9]{20,}"), "<REDACTED:secret>"),        # OpenAI / generic sk-
    (re.compile(r"sk_(live|test)_[A-Za-z0-9]{24,}"), "<REDACTED:secret>"),   # Stripe
    (re.compile(r"AIza[0-9A-Za-z_-]{35}"), "<REDACTED:secret>"),             # GCP API key
    (re.compile(r"(?i)authorization\s*:\s*\S+"), "Authorization: <REDACTED:secret>"),
]


@dataclass
class SecretsRule:
    """Scrub well-known token / API-key patterns."""

    name: str = "SecretsRule"

    def apply_text(self, text: str) -> str:
        for pat, repl in _SECRET_PATTERNS:
            text = pat.sub(repl, text)
        return text


@dataclass
class UsernamesRule:
    """Substitute the OS username in absolute home-directory paths.

    Targets ``/Users/<user>/``, ``/home/<user>/``, ``C:\\Users\\<user>\\``.
    Preserves directory structure after the username — file layout is
    meaningful learning signal.
    """

    username: str | None = None
    name: str = "UsernamesRule"

    def __post_init__(self) -> None:
        if self.username is None:
            try:
                self.username = getpass.getuser()
            except Exception:
                self.username = ""

    def apply_text(self, text: str) -> str:
        if not self.username:
            return text
        u = re.escape(self.username)
        text = re.sub(rf"/Users/{u}\b", "/Users/<REDACTED:username>", text)
        text = re.sub(rf"/home/{u}\b", "/home/<REDACTED:username>", text)
        text = re.sub(rf"C:\\\\Users\\\\{u}\b", r"C:\\Users\\<REDACTED:username>", text)
        return text


@dataclass
class CustomPatternsRule:
    """User-supplied regex list. Each match becomes ``<REDACTED:custom>``."""

    patterns: list[str] = field(default_factory=list)
    name: str = "CustomPatternsRule"
    _compiled: list[re.Pattern[str]] = field(default_factory=list, init=False, repr=False)

    def __post_init__(self) -> None:
        self._compiled = [re.compile(p) for p in self.patterns]

    def apply_text(self, text: str) -> str:
        for pat in self._compiled:
            text = pat.sub("<REDACTED:custom>", text)
        return text


@dataclass
class Redactor:
    """Composed sequence of redaction rules applied recursively to a record."""

    rules: list[RedactionRule] = field(default_factory=list)

    def apply(self, record: Any) -> Any:
        if not self.rules:
            return record
        return self._walk(record)

    def _walk(self, val: Any) -> Any:
        if isinstance(val, str):
            for rule in self.rules:
                val = rule.apply_text(val)
            return val
        if isinstance(val, dict):
            return {k: self._walk(v) for k, v in val.items()}
        if isinstance(val, list):
            return [self._walk(v) for v in val]
        if isinstance(val, tuple):
            return tuple(self._walk(v) for v in val)
        return val
