"""Read agent_message events from state.db and emit per-task training records.

Reads the DB directly via sqlite3 — no state-service dependency, safe to
run while a session is active.

Pipeline: reader → filter → projector → redactor → splitter → JSONL.
This module owns reader + filter + record assembly + dedupe + split.
Projection lives in :mod:`claw_forge.training.projectors`; redaction in
:mod:`claw_forge.training.redact`.
"""

from __future__ import annotations

import hashlib
import json
import math
import sqlite3
import subprocess
from collections.abc import Iterable, Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

try:
    from importlib.metadata import version as _pkg_version
    _CLAW_FORGE_VERSION = _pkg_version("claw-forge")
except Exception:
    _CLAW_FORGE_VERSION = "0.0.0.dev0"


Filter = Literal["success", "recovered", "both"]
DedupeMode = Literal["prompt", "diff", "both", "none"]


def iter_training_records(
    db: Path,
    *,
    scope: Literal["session", "all"] = "all",
    session: str | None = None,
    filter_: Filter = "both",
    include_failed: bool = False,
    include_diff: bool = False,
    repo_dir: Path | None = None,
    redaction_rules: list[str] | None = None,
) -> Iterator[dict[str, Any]]:
    """Yield one assembled record per task that passes the filter.

    The yielded dicts are pre-projection — they carry the raw SDK message
    stream under ``raw_events``. Apply a projector from
    :mod:`claw_forge.training.projectors` to render to a target chat format.
    """
    conn = sqlite3.connect(str(db))
    conn.row_factory = sqlite3.Row
    try:
        for task in _iter_tasks(
            conn, scope=scope, session=session,
            filter_=filter_, include_failed=include_failed,
        ):
            events = list(_iter_events_for(conn, task["id"]))
            rec = _assemble_record(task, events)
            if include_diff and task["merge_commit_sha"] and repo_dir:
                rec["final_diff"] = _git_show(repo_dir, task["merge_commit_sha"])
            rec["provenance"] = {
                "claude_model": _detect_model_from_events(events),
                "captured_at": datetime.now(UTC).isoformat(),
                "claw_forge_version": _CLAW_FORGE_VERSION,
                "redaction_rules": list(redaction_rules or []),
            }
            yield rec
    finally:
        conn.close()


def _iter_tasks(
    conn: sqlite3.Connection,
    *,
    scope: str,
    session: str | None,
    filter_: Filter,
    include_failed: bool,
) -> Iterator[sqlite3.Row]:
    where: list[str] = []
    args: list[Any] = []

    if scope == "session" and session:
        where.append("session_id = ?")
        args.append(session)

    outcome_clauses: list[str] = []
    if filter_ in ("success", "both"):
        outcome_clauses.append(
            "(status='completed' AND merged_to_target_branch=1 AND bugfix_retry_count=0)"
        )
    if filter_ in ("recovered", "both"):
        outcome_clauses.append(
            "(status='completed' AND merged_to_target_branch=1 AND bugfix_retry_count>0)"
        )
    if include_failed:
        outcome_clauses.append("status='failed'")
    if outcome_clauses:
        where.append("(" + " OR ".join(outcome_clauses) + ")")

    where_sql = " AND ".join(where) if where else "1=1"
    sql = f"SELECT * FROM tasks WHERE {where_sql} ORDER BY created_at"
    yield from conn.execute(sql, args)


def _iter_events_for(conn: sqlite3.Connection, task_id: str) -> Iterator[dict[str, Any]]:
    sql = (
        "SELECT payload FROM events "
        "WHERE task_id = ? AND event_type = 'agent_message' "
        "ORDER BY created_at, id"
    )
    for row in conn.execute(sql, (task_id,)):
        raw = row[0]
        if raw is None:
            continue
        try:
            yield json.loads(raw) if isinstance(raw, str) else raw
        except json.JSONDecodeError:
            continue


def _label(task: sqlite3.Row) -> str:
    if task["status"] == "failed":
        return "failed"
    if int(task["bugfix_retry_count"] or 0) > 0:
        return "recovered"
    return "success"


def _assemble_record(task: sqlite3.Row, events: list[dict[str, Any]]) -> dict[str, Any]:
    """Build the per-task record (pre-projection)."""
    return {
        "task_id": task["id"],
        "session_id": task["session_id"],
        "outcome": _label(task),
        "plugin": task["plugin_name"],
        "category": task["category"],
        "shape": task["shape"],
        "retry_count": int(task["bugfix_retry_count"] or 0),
        "metrics": {
            "input_tokens": int(task["input_tokens"] or 0),
            "output_tokens": int(task["output_tokens"] or 0),
            "cost_usd": float(task["cost_usd"] or 0.0),
        },
        "description": task["description"],
        "merge_commit_sha": task["merge_commit_sha"],
        "raw_events": events,
    }


def _git_show(repo: Path, sha: str) -> str:
    """Return the diff for one commit. Empty string on any failure."""
    try:
        out = subprocess.run(
            ["git", "show", "--pretty=format:", sha],
            cwd=str(repo), capture_output=True, text=True, timeout=10,
            check=False,
        )
        return out.stdout
    except Exception:
        return ""


def _detect_model_from_events(events: list[dict[str, Any]]) -> str | None:
    for ev in events:
        model = ev.get("model")
        if model:
            return str(model)
    return None


# ── Hygiene operations ──────────────────────────────────────────────────────


def dedupe_records(
    records: Iterable[dict[str, Any]],
    *,
    by: DedupeMode,
) -> Iterator[dict[str, Any]]:
    """Drop trajectories that already appear in the corpus under the chosen key.

    - ``prompt``: dedupe by ``description``
    - ``diff``: dedupe by ``merge_commit_sha`` (None never collides — kept)
    - ``both``: dedupe only when both match exactly
    - ``none``: pass-through
    """
    if by == "none":
        yield from records
        return
    seen: set[Any] = set()
    for r in records:
        if by == "prompt":
            key: Any = ("p", r.get("description") or "")
        elif by == "diff":
            sha = r.get("merge_commit_sha")
            if sha is None:
                yield r
                continue
            key = ("d", sha)
        else:  # both
            key = ("b", r.get("description") or "", r.get("merge_commit_sha"))
        if key in seen:
            continue
        seen.add(key)
        yield r


def split_records(
    records: Iterable[dict[str, Any]],
    *,
    ratios: tuple[float, float, float],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Deterministic split (seeded by ``task_id`` SHA-256) into train/val/test.

    Ratios must sum to 1.0 (within 1e-6 tolerance). Same input set always
    produces the same partition — important so val/test holdouts are stable
    across re-exports.
    """
    if not math.isclose(sum(ratios), 1.0, abs_tol=1e-6):
        raise ValueError(f"ratios must sum to 1.0, got {ratios} (sum={sum(ratios)})")
    train_r, val_r, _ = ratios
    train: list[dict[str, Any]] = []
    val: list[dict[str, Any]] = []
    test: list[dict[str, Any]] = []
    for r in records:
        h = int(hashlib.sha256(r["task_id"].encode()).hexdigest()[:8], 16) / (16**8)
        if h < train_r:
            train.append(r)
        elif h < train_r + val_r:
            val.append(r)
        else:
            test.append(r)
    return train, val, test
