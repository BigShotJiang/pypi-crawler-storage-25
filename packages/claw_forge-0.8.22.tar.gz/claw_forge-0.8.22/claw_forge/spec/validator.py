"""Layer 1 spec validator: deterministic structural checks on feature bullets."""

from __future__ import annotations

import contextlib
import os
import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from claw_forge.spec.parser import FeatureItem, ProjectSpec

__all__ = [
    "CORE_CHAIN_DEPTH_THRESHOLD",
    "CROSS_CUTTING_INDICATORS",
    "DEFAULT_MIGRATION_TOUCHES_FILES",
    "IssueSeverity",
    "MIGRATION_INDICATORS",
    "VERTICAL_INDICATORS",
    "VERTICAL_MIN_BULLETS",
    "VERTICAL_RATIO_THRESHOLD",
    "ValidationIssue",
    "ValidationReport",
    "_slugify_plugin_name",
    "check_category_looks_vertical",
    "check_core_chain_depth",
    "check_plugin_dir_exists",
    "check_has_measurable_outcome",
    "check_plugin_shape_complete",
    "check_migration_shape_candidate",
    "check_touches_overlap",
    "check_is_atomic",
    "check_not_too_vague",
    "check_starts_with_action_verb",
    "run_coverage_checks",
    "run_shape_checks",
    "run_structural_checks",
    "SpecEvaluator",
    "SPEC_DIMENSIONS",
    "run_llm_evaluation",
    "validate_spec",
]


class IssueSeverity(Enum):
    ERROR = "error"
    WARNING = "warning"


@dataclass
class ValidationIssue:
    severity: IssueSeverity
    layer: int
    category: str
    bullet: str
    message: str
    suggestion: str = ""


@dataclass
class ValidationReport:
    issues: list[ValidationIssue]
    category_scores: dict[str, float]

    @property
    def error_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == IssueSeverity.ERROR)

    @property
    def warning_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == IssueSeverity.WARNING)

    @property
    def total_issues(self) -> int:
        return len(self.issues)

    @property
    def passed(self) -> bool:
        return self.error_count == 0

    def layer_issues(self, layer: int) -> list[ValidationIssue]:
        return [i for i in self.issues if i.layer == layer]


# ---------------------------------------------------------------------------
# Structural rule helpers
# ---------------------------------------------------------------------------

_ACTION_VERB_PREFIXES = (
    "user can ",
    "user cannot ",
    "system ",
    "api ",
    "ui ",
    "app ",
    "admin ",
    "service ",
    "backend ",
    "frontend ",
    "database ",
    "agent ",
    "webhook ",
    "background ",
)

_MEASURABLE_PATTERNS = [
    re.compile(r"returns?\s+\d{3}", re.IGNORECASE),
    re.compile(r"\(returns?\s", re.IGNORECASE),
    re.compile(r"displays?\s+", re.IGNORECASE),
    re.compile(r"shows?\s+", re.IGNORECASE),
    re.compile(r"redirects?\s+to\s+", re.IGNORECASE),
    re.compile(r"saves?\s+to\s+", re.IGNORECASE),
    re.compile(r"emits?\s+", re.IGNORECASE),
    re.compile(r"sends?\s+", re.IGNORECASE),
    re.compile(r"creates?\s+", re.IGNORECASE),
    re.compile(r"with\s+\w+_\w+", re.IGNORECASE),
    re.compile(r"HTTP\s+\d{3}"),
    re.compile(r"\d{3}\s+error", re.IGNORECASE),
    re.compile(r"error\s+message", re.IGNORECASE),
    re.compile(r"toast\s+notification", re.IGNORECASE),
    re.compile(r"persists?\s+", re.IGNORECASE),
]

_COMPOUND_CONNECTORS = [
    "and then",
    "and also",
    "and after",
    "then login",
    "then register",
    "and receive",
    "and redirect",
    "and create",
    "and send",
    "and return",
]

_VAGUE_WORDS = re.compile(
    r"\b(etc|various|multiple|some|things|stuff|items)\b", re.IGNORECASE
)


# ---------------------------------------------------------------------------
# Public check functions
# ---------------------------------------------------------------------------


def check_starts_with_action_verb(feat: FeatureItem) -> ValidationIssue | None:
    """Return WARNING if bullet does not start with a recognised subject prefix."""
    text = feat.description.lower()
    for prefix in _ACTION_VERB_PREFIXES:
        if text.startswith(prefix):
            return None
    return ValidationIssue(
        severity=IssueSeverity.WARNING,
        layer=1,
        category="action_verb",
        bullet=feat.description,
        message=(
            "Bullet does not start with a recognised subject/action prefix "
            f"(e.g. 'User can', 'System ', 'API '). Got: {feat.description[:40]!r}"
        ),
        suggestion="Rewrite to start with a subject prefix such as 'User can …' or 'System …'.",
    )


def check_has_measurable_outcome(feat: FeatureItem) -> ValidationIssue | None:
    """Return WARNING if bullet contains no measurable/observable outcome."""
    text = feat.description
    for pattern in _MEASURABLE_PATTERNS:
        if pattern.search(text):
            return None
    return ValidationIssue(
        severity=IssueSeverity.WARNING,
        layer=1,
        category="measurable_outcome",
        bullet=feat.description,
        message=(
            "Bullet has no detectable measurable outcome "
            "(e.g. HTTP status code, 'displays', 'saves to', 'error message')."
        ),
        suggestion=(
            "Add an observable result, e.g. '(returns 200 with JWT)'"
            " or 'displays an error message'."
        ),
    )


def check_is_atomic(feat: FeatureItem) -> ValidationIssue | None:
    """Return ERROR if bullet contains a compound connector implying multiple actions."""
    text = feat.description.lower()
    for phrase in _COMPOUND_CONNECTORS:
        if phrase in text:
            return ValidationIssue(
                severity=IssueSeverity.ERROR,
                layer=1,
                category="atomic",
                bullet=feat.description,
                message=(
                    "Bullet appears to describe multiple actions "
                    f"(found compound connector: {phrase!r}). "
                    "Split into separate atomic bullets."
                ),
                suggestion=f"Remove '{phrase}' and split into two separate feature bullets.",
            )
    return None


def check_not_too_vague(feat: FeatureItem) -> ValidationIssue | None:
    """Return WARNING if bullet is too short or contains vague filler words."""
    text = feat.description
    word_count = len(text.split())
    if word_count < 6:
        return ValidationIssue(
            severity=IssueSeverity.WARNING,
            layer=1,
            category="vague",
            bullet=text,
            message=(
                f"Bullet is too short ({word_count} words)."
                " Bullets should be at least 6 words."
            ),
            suggestion="Expand the bullet to include subject, action, and expected outcome.",
        )
    match = _VAGUE_WORDS.search(text)
    if match:
        word = match.group(0)
        return ValidationIssue(
            severity=IssueSeverity.WARNING,
            layer=1,
            category="vague",
            bullet=text,
            message=f"Bullet contains vague filler word {word!r}. Be specific.",
            suggestion=f"Replace {word!r} with concrete, enumerated terms.",
        )
    return None


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

_CHECKS = [
    check_starts_with_action_verb,
    check_has_measurable_outcome,
    check_is_atomic,
    check_not_too_vague,
]

# Maps each check function to the canonical category string used in ValidationIssue.category.
# Keeping this explicit avoids fragile name-mangling and ensures category_scores keys
# are always consistent with the issue categories reported.
_CHECK_CATEGORIES: dict[str, str] = {
    "check_starts_with_action_verb": "action_verb",
    "check_has_measurable_outcome": "measurable_outcome",
    "check_is_atomic": "atomic",
    "check_not_too_vague": "vague",
}


def run_structural_checks(spec: ProjectSpec) -> ValidationReport:
    """Run all Layer-1 structural checks on every feature in the spec."""
    issues: list[ValidationIssue] = []
    category_pass: dict[str, int] = {}
    category_total: dict[str, int] = {}

    for feat in spec.features:
        for check in _CHECKS:
            issue = check(feat)
            cat = _check_category(check)
            category_total[cat] = category_total.get(cat, 0) + 1
            if issue is not None:
                issues.append(issue)
            else:
                category_pass[cat] = category_pass.get(cat, 0) + 1

    category_scores: dict[str, float] = {}
    for cat, total in category_total.items():
        passed = category_pass.get(cat, 0)
        category_scores[cat] = passed / total if total > 0 else 1.0

    return ValidationReport(issues=issues, category_scores=category_scores)


def _endpoint_path(endpoint_line: str) -> str:
    """Extract the URL path from 'POST /api/auth/register - Register new user'.

    Strips query strings (``?…``) so that ``/api/users?active=true`` is
    normalised to ``/api/users`` before the coverage check.
    """
    parts = endpoint_line.strip().split()
    for part in parts:
        if part.startswith("/"):
            # Drop any query string (e.g. /api/users?active=true → /api/users)
            return part.split("?")[0]
    return endpoint_line.strip()


def _term_in_bullets(term: str, all_bullets: str) -> bool:
    """Return True if *term* appears as a whole token in *all_bullets*.

    Uses a word-boundary regex so that ``/api/user`` does **not** match a
    bullet that only mentions ``/api/users``, avoiding false-positive coverage.
    Non-word characters at the boundaries of the term (``/``, ``-``, ``_``)
    are treated as delimiters.
    """
    escaped = re.escape(term)
    return bool(re.search(r"(?<!\w)" + escaped + r"(?!\w)", all_bullets))


def run_coverage_checks(spec: ProjectSpec) -> ValidationReport:
    """Layer 3: cross-reference endpoints and tables against feature bullets.

    Every API endpoint in <api_endpoints_summary> must appear in at least one
    feature bullet (path match). Every table in <database_schema> must be
    referenced in at least one bullet. Missing coverage means the agent will
    never implement that endpoint or table.
    """
    issues: list[ValidationIssue] = []
    all_bullets = " ".join(feat.description.lower() for feat in spec.features)

    for domain, endpoint_lines in spec.api_endpoints.items():
        for endpoint_line in endpoint_lines:
            path = _endpoint_path(endpoint_line)
            path_lower = path.lower()
            path_clean = path.lstrip("/").replace("-", " ").replace("_", " ").lower()
            if not _term_in_bullets(path_lower, all_bullets) and not _term_in_bullets(
                path_clean, all_bullets
            ):
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.WARNING,
                        layer=3,
                        category=domain,
                        bullet="",
                        message=f"No feature bullet references endpoint {path}",
                        suggestion=f"Add a bullet in '{domain}' covering {path}",
                    )
                )

    for table_name in spec.database_tables:
        table_lower = table_name.lower()
        table_clean = table_name.replace("_", " ").lower()
        if not _term_in_bullets(table_lower, all_bullets) and not _term_in_bullets(
            table_clean, all_bullets
        ):
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.WARNING,
                    layer=3,
                    category="Database",
                    bullet="",
                    message=f"No feature bullet references table '{table_name}'",
                    suggestion=f"Add CRUD bullets for the '{table_name}' table",
                )
            )

    return ValidationReport(issues=issues, category_scores={})


def _check_category(check: object) -> str:
    """Return the canonical category label for a check function.

    Uses the explicit ``_CHECK_CATEGORIES`` mapping so that keys in
    ``ValidationReport.category_scores`` always match ``ValidationIssue.category``
    values emitted by the same check.
    """
    name = getattr(check, "__name__", str(check))
    return _CHECK_CATEGORIES.get(name, name)


# ---------------------------------------------------------------------------
# Layer 2: adversarial LLM evaluation per category
# ---------------------------------------------------------------------------

SPEC_DIMENSIONS: list[tuple[str, int, str]] = [
    (
        "Testability",
        3,
        "Can you write a pass/fail test for every bullet?"
        " Each bullet must have a verifiable outcome.",
    ),
    (
        "Atomicity",
        3,
        "Is each bullet one implementable unit?"
        " No compound sequences. No 'and then' chains.",
    ),
    (
        "Specificity",
        2,
        "Does each bullet name concrete things:"
        " HTTP status, field names, UI elements, error messages?",
    ),
    (
        "ErrorCoverage",
        2,
        "Does the category cover error and edge cases, not just the happy path?",
    ),
]
_TOTAL_WEIGHT = sum(w for _, w, _ in SPEC_DIMENSIONS)

_STRONG_EXAMPLE = """\
Authentication bullets (score ≈8.5):
- User can login with email + password (POST /api/auth/login returns 200 with JWT)
- System returns 401 with {"error": "invalid_credentials"} on wrong password
- System returns 400 with field errors when email is malformed
- User can logout (DELETE /api/auth/session returns 204, clears HttpOnly cookie)
"""

_WEAK_EXAMPLE = """\
Core bullets (score ≈3.5):
- User can manage things
- System handles errors
- App does login stuff and then redirects user somewhere
"""


class SpecEvaluator:
    """Adversarial evaluator for spec category bullets."""

    def __init__(self, approve_threshold: float = 7.0) -> None:
        self.approve_threshold = approve_threshold

    def grade(
        self,
        bullets: str,
        category: str,
        dimension_scores: dict[str, float],
        feedback: str = "",
    ) -> dict[str, Any]:
        """Compute weighted score across SPEC_DIMENSIONS and return grading result."""
        total_weight = _TOTAL_WEIGHT
        weighted_sum = 0.0
        breakdown: dict[str, float] = {}
        for dim_name, weight, _ in SPEC_DIMENSIONS:
            score = float(dimension_scores.get(dim_name, 0.0))
            breakdown[dim_name] = score
            weighted_sum += score * weight

        score = (weighted_sum / (total_weight * 10)) * 10 if total_weight > 0 else 0.0
        verdict = "APPROVE" if score >= self.approve_threshold else "REQUEST_CHANGES"
        return {
            "score": score,
            "verdict": verdict,
            "breakdown": breakdown,
            "feedback": feedback,
            "category": category,
        }

    def build_evaluator_prompt(
        self,
        bullets: str,
        category: str,
        tech_stack: str = "",
    ) -> str:
        """Return adversarial evaluator prompt for the given bullets."""
        dimensions_block = "\n".join(
            f"- {name} (weight {weight}): {desc}"
            for name, weight, desc in SPEC_DIMENSIONS
        )
        tech_line = f"Tech stack: {tech_stack}\n" if tech_stack else ""
        prompt = f"""\
ADVERSARIAL SPEC EVALUATOR

You are an adversarial evaluator grading feature spec bullets for implementability.
Be strict. Real projects fail when specs are vague or non-testable.

{tech_line}Category: {category}

## Grading Dimensions
{dimensions_block}

Score each dimension 1-10 (10 = perfect).

## Calibration Examples

{_STRONG_EXAMPLE}
{_WEAK_EXAMPLE}

## Bullets to Evaluate

{bullets}

## Required Output Format
Output exactly these lines (no extra text before them):
Testability: <score>
Atomicity: <score>
Specificity: <score>
ErrorCoverage: <score>
Verdict: APPROVE or REQUEST_CHANGES
Feedback: <one or two sentences>
"""
        return prompt

    def parse_llm_response(self, text: str) -> tuple[dict[str, float], str]:
        """Parse dimension scores and feedback from LLM response text."""
        scores: dict[str, float] = {}
        feedback = ""
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            if line.lower().startswith("feedback:"):
                feedback = line[len("feedback:"):].strip()
                continue
            for dim_name, _, _ in SPEC_DIMENSIONS:
                prefix = f"{dim_name}:"
                if line.startswith(prefix):
                    value_str = line[len(prefix):].strip().split()[0]
                    with contextlib.suppress(ValueError):
                        scores[dim_name] = float(value_str)
                    break
        return scores, feedback


def run_llm_evaluation(
    spec: ProjectSpec,
    approve_threshold: float = 7.0,
    model: str = "claude-haiku-4-5-20251001",
) -> ValidationReport:
    """Layer 2: adversarial LLM evaluation per category.

    Requires ANTHROPIC_API_KEY. If absent, returns empty report with one
    WARNING issue explaining the skip — never raises.
    Uses Haiku by default (structured prompt, cheap model sufficient).
    Groups features by category, calls API once per category.
    Scores stored in report.category_scores[category_name].
    Categories scoring < approve_threshold get a WARNING issue (layer=2).
    Any API error per category gets a WARNING issue (layer=2) and continues.
    """
    issues: list[ValidationIssue] = []
    category_scores: dict[str, float] = {}

    api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not api_key:
        issues.append(
            ValidationIssue(
                severity=IssueSeverity.WARNING,
                layer=2,
                category="llm_evaluation",
                bullet="",
                message=(
                    "Layer 2 LLM evaluation skipped: ANTHROPIC_API_KEY is not set."
                ),
                suggestion="Set ANTHROPIC_API_KEY to enable adversarial LLM evaluation.",
            )
        )
        return ValidationReport(issues=issues, category_scores=category_scores)

    # Group features by category
    categories: dict[str, list[str]] = {}
    for feat in spec.features:
        categories.setdefault(feat.category, []).append(feat.description)

    # Build tech_stack string
    ts = spec.tech_stack
    if hasattr(ts, "raw") and ts.raw:
        tech_stack = ts.raw
    else:
        parts = []
        if hasattr(ts, "frontend_framework") and ts.frontend_framework:
            parts.append(ts.frontend_framework)
        if hasattr(ts, "backend_runtime") and ts.backend_runtime:
            parts.append(ts.backend_runtime)
        tech_stack = " + ".join(parts) if parts else ""

    try:
        import anthropic
    except ImportError:
        issues.append(ValidationIssue(
            severity=IssueSeverity.WARNING, layer=2, category="", bullet="",
            message="Layer 2 LLM evaluation skipped: 'anthropic' package not installed.",
        ))
        return ValidationReport(issues=issues, category_scores=category_scores)

    evaluator = SpecEvaluator(approve_threshold=approve_threshold)
    client = anthropic.Anthropic(api_key=api_key)

    for category, bullets in categories.items():
        bullet_block = "\n".join(f"- {b}" for b in bullets)
        prompt = evaluator.build_evaluator_prompt(bullet_block, category, tech_stack)
        try:
            response = client.messages.create(
                model=model,
                max_tokens=512,
                system="You are an adversarial spec evaluator. Grade ruthlessly.",
                messages=[{"role": "user", "content": prompt}],
            )
            raw_text = getattr(response.content[0], "text", None)
            response_text = raw_text if isinstance(raw_text, str) else ""
            dimension_scores, feedback = evaluator.parse_llm_response(response_text)
            result = evaluator.grade(bullet_block, category, dimension_scores, feedback)
            score = result["score"]
            category_scores[category] = score
            if result["verdict"] == "REQUEST_CHANGES":
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.WARNING,
                        layer=2,
                        category=category,
                        bullet="",
                        message=(
                            f"Category '{category}' scored {score:.1f}/10 "
                            f"(threshold {approve_threshold}). {feedback}"
                        ),
                        suggestion=(
                            "Improve bullet specificity, testability, atomicity, "
                            "and error coverage."
                        ),
                    )
                )
        except Exception as exc:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.WARNING,
                    layer=2,
                    category=category,
                    bullet="",
                    message=f"LLM evaluation failed for category '{category}': {exc}",
                    suggestion="Check API key and model name, then retry.",
                )
            )

    return ValidationReport(issues=issues, category_scores=category_scores)


# ---------------------------------------------------------------------------
# Layer 4: architectural-shape coherence checks
# ---------------------------------------------------------------------------

# Heuristic vocabulary for "looks vertical" detection (Gap 6).  Bullets
# matching VERTICAL_INDICATORS score +1; matching CROSS_CUTTING_INDICATORS
# score -1.  A category is flagged when (vertical-score / |unannotated|)
# meets VERTICAL_RATIO_THRESHOLD with at least VERTICAL_MIN_BULLETS bullets.
VERTICAL_INDICATORS: frozenset[str] = frozenset({
    "user can", "user cannot", "displays", "shows", "submits",
    "registers", "logs in", "logs out", "creates", "deletes", "edits",
})
CROSS_CUTTING_INDICATORS: frozenset[str] = frozenset({
    "every endpoint", "all endpoints", "middleware", "intercepts",
    "all requests", "globally", "across", "any plugin", "every plugin",
    "rate limit", "audit log", "metrics", "tracing",
})
VERTICAL_RATIO_THRESHOLD: float = 0.6
VERTICAL_MIN_BULLETS: int = 3
CORE_CHAIN_DEPTH_THRESHOLD: int = 4

# Vocabulary for "looks like migration / DB-schema work" detection (Gap 8).
# A feature whose description matches any of these tokens is a candidate
# for shape='core' annotation.  ``table`` alone is intentionally NOT in
# this set — it appears too often in non-DB contexts (HTML tables, lookup
# tables) and would over-trigger.  The verb-combos catch the DB sense.
MIGRATION_INDICATORS: frozenset[str] = frozenset({
    "migration",
    "alembic",
    "schema migration",
    "database schema",
    "ddl",
    "foreign key",
    "primary key",
    "create table",
    "alter table",
    "drop table",
    "add column",
    "drop column",
    "alter column",
    "create index",
    "unique constraint",
})

# Recommended ``touches_files`` glob for migration-touching shape='core'
# features.  Used in the Gap 8 suggestion message so the auto-fix in
# /fix-spec can paste it verbatim into the <feature> element.
DEFAULT_MIGRATION_TOUCHES_FILES: str = "migrations/versions/**"


def _slugify_plugin_name(category: str) -> str:
    """Convert a category name to a plugin-attribute slug.

    Lowercase, replace non-alphanumerics with whitespace, collapse runs
    of whitespace to single dashes, strip leading/trailing dashes.

    Distinct from claw_forge.git.slug.make_slug — that helper strips
    leading action verbs for branch names; here we keep the noun.
    """
    cleaned = re.sub(r"[^a-z0-9]+", " ", category.lower()).strip()
    return re.sub(r"\s+", "-", cleaned)


def check_plugin_shape_complete(
    feat: FeatureItem, *, strict: bool,
) -> ValidationIssue | None:
    """Gap 1 — shape='plugin' must have plugin= or non-empty touches_files.

    Always ERROR.  Silent acceptance would mean the dispatcher dispatches
    the task without file-claim locking, breaking the parallel-safety
    guarantee that shape-aware scheduling promises.  ``strict`` is accepted
    for API consistency but does not change behavior.
    """
    del strict  # gap 1 is always ERROR
    if feat.shape != "plugin":
        return None
    if feat.plugin or feat.touches_files:
        return None
    suggested_slug = _slugify_plugin_name(feat.category) or "<plugin-name>"
    return ValidationIssue(
        severity=IssueSeverity.ERROR,
        layer=4,
        category=feat.category,
        bullet=feat.description,
        message=(
            "shape='plugin' feature missing both plugin= and touches_files= "
            "— file-claim locking is silently disabled."
        ),
        suggestion=(
            f"Add plugin=\"{suggested_slug}\" to the <feature> element, "
            f"or declare an explicit touches_files= attribute."
        ),
    )


def check_migration_shape_candidate(
    feat: FeatureItem, *, strict: bool,
) -> ValidationIssue | None:
    """Gap 8 — feature description suggests migration / DB-schema work
    but isn't declared shape='core'.

    Migration-touching features mutate alembic's revision tree, a global
    shared resource.  When ``shape='core'`` the dispatcher single-flights
    them (one at a time, regardless of ``max_concurrency``), preventing
    parallel agents from writing colliding revisions.  Without the
    annotation, parallel runs produce duplicate ``revision="0010"``
    files that alembic refuses to load.

    WARNING by default; ERROR in strict mode (matches Gap 3, 5, 6).
    Already-correct shape='core' annotation passes silently.
    """
    if feat.shape == "core":
        return None
    description_lower = feat.description.lower()
    if not any(token in description_lower for token in MIGRATION_INDICATORS):
        return None
    severity = IssueSeverity.ERROR if strict else IssueSeverity.WARNING
    return ValidationIssue(
        severity=severity,
        layer=4,
        category=feat.category,
        bullet=feat.description,
        message=(
            "feature description suggests migration / schema work but is not "
            "declared shape='core' — parallel agents may write colliding "
            "alembic revisions."
        ),
        suggestion=(
            f'Add shape="core" touches_files="{DEFAULT_MIGRATION_TOUCHES_FILES}" '
            f"to the <feature> element so the dispatcher single-flights it."
        ),
    )


def check_touches_overlap(
    spec: ProjectSpec, *, strict: bool,
) -> list[ValidationIssue]:
    """Gap 3 — core feature's touches_files glob overlaps a plugin directory.

    Conservative algorithm: for each shape='plugin' feature with a plugin=
    attribute, derive the plugin root path 'src/plugins/<name>/' and probe
    each shape='core' feature's touches_files globs with fnmatch against
    a representative path under that root.  Catches sloppy core globs
    ('src/**') and explicit core paths inside plugin directories.
    Misses subtle overlaps (e.g. core globs that match siblings of the
    plugin root) — false-negatives over false-positives by design.

    WARNING by default; ERROR in strict mode.
    """
    import fnmatch

    from claw_forge.spec.parser import DEFAULT_PLUGIN_ROOT

    severity = IssueSeverity.ERROR if strict else IssueSeverity.WARNING
    issues: list[ValidationIssue] = []

    plugin_feats = [
        f for f in spec.features
        if f.shape == "plugin" and f.plugin
    ]
    core_feats = [f for f in spec.features if f.shape == "core"]

    for plugin_feat in plugin_feats:
        plugin_root = f"{DEFAULT_PLUGIN_ROOT}/{plugin_feat.plugin}/"
        probe = f"{plugin_root}__placeholder__.py"
        for core_feat in core_feats:
            for glob in core_feat.touches_files:
                # Two detection paths:
                # 1. Glob pattern matches our representative probe path.
                # 2. Glob is a literal path that starts with the plugin root
                #    (e.g. "src/plugins/billing/auth.py" — not a wildcard, but
                #    still naming a file owned by the plugin).
                overlaps = fnmatch.fnmatchcase(probe, glob) or glob.startswith(
                    plugin_root
                )
                if overlaps:
                    issues.append(
                        ValidationIssue(
                            severity=severity,
                            layer=4,
                            category=core_feat.category,
                            bullet=core_feat.description,
                            message=(
                                f"core feature's touches_files glob {glob!r} "
                                f"overlaps {plugin_root}"
                            ),
                            suggestion=(
                                f"Narrow the core glob to exclude {plugin_root}, "
                                f"or re-shape the file ownership."
                            ),
                        )
                    )
                    break  # one issue per (plugin, core) pair, not per glob
    return issues


def check_core_chain_depth(spec: ProjectSpec) -> list[ValidationIssue]:
    """Gap 7 — depends_on chain of shape='core' features ≥ threshold.

    Computes longest path through the core-only subgraph using DP over
    a topological order (FeatureItem.index is 1-based positional).
    Skips legacy features without index=.  One WARNING per long chain
    root (deduplicated by chain endpoint).  Always WARNING.
    """
    # Build index → feature map; skip features without index
    by_index: dict[int, FeatureItem] = {
        f.index: f for f in spec.features if f.index is not None
    }

    # Longest path ending at each core node, restricted to core-only chains
    longest: dict[int, int] = {}
    for idx in sorted(by_index):
        feat = by_index[idx]
        if feat.shape != "core":
            longest[idx] = 0
            continue
        # Path length = 1 (this node) + max core-predecessor path length
        max_pred = 0
        for dep_idx in feat.depends_on_indices:
            pred = by_index.get(dep_idx)
            if pred is not None and pred.shape == "core":
                max_pred = max(max_pred, longest.get(dep_idx, 0))
        longest[idx] = 1 + max_pred

    # Find chain endpoints: nodes whose longest core chain ≥ threshold AND
    # no successor extends them further (so we report each chain once).
    successors: dict[int, list[int]] = {idx: [] for idx in by_index}
    for idx, feat in by_index.items():
        for dep_idx in feat.depends_on_indices:
            if dep_idx in successors:
                successors[dep_idx].append(idx)

    issues: list[ValidationIssue] = []
    for idx, length in longest.items():
        if length < CORE_CHAIN_DEPTH_THRESHOLD:
            continue
        feat = by_index[idx]
        if feat.shape != "core":
            continue
        # Only emit if no successor has a longer or equal chain through us
        extends_further = any(
            longest.get(s, 0) > length and by_index[s].shape == "core"
            for s in successors[idx]
        )
        if extends_further:
            continue
        issues.append(
            ValidationIssue(
                severity=IssueSeverity.WARNING,
                layer=4,
                category=feat.category,
                bullet=feat.description,
                message=(
                    f"shape='core' depends_on chain of length {length} "
                    f"ending at feature index {idx} — "
                    f"all {length} features serialize at dispatch time."
                ),
                suggestion=(
                    "Consider re-shaping intermediate links as plugin-shape "
                    "features (isolate their files to src/plugins/<name>/)."
                ),
            )
        )
    return issues


def check_category_looks_vertical(
    category: str, feats: list[FeatureItem], *, strict: bool,
) -> ValidationIssue | None:
    """Gap 6 — category bullets look vertical but no shape declared.

    Operates on the unannotated subset U = {f : f.shape is None}.
    Score each bullet: +1 for any VERTICAL_INDICATORS match, -1 for
    any CROSS_CUTTING_INDICATORS match (capped at ±1 per bullet).
    Flag when |U| ≥ VERTICAL_MIN_BULLETS and (score / |U|) ≥
    VERTICAL_RATIO_THRESHOLD.

    WARNING / ERROR strict.
    """
    severity = IssueSeverity.ERROR if strict else IssueSeverity.WARNING
    unannotated = [f for f in feats if f.shape is None]
    if len(unannotated) < VERTICAL_MIN_BULLETS:
        return None

    score = 0
    for feat in unannotated:
        text = feat.description.lower()
        is_vertical = any(tok in text for tok in VERTICAL_INDICATORS)
        is_cross = any(tok in text for tok in CROSS_CUTTING_INDICATORS)
        if is_vertical and not is_cross:
            score += 1
        elif is_cross and not is_vertical:
            score -= 1
        # mixed or neither → 0

    ratio = score / len(unannotated)
    if ratio < VERTICAL_RATIO_THRESHOLD:
        return None

    suggested_slug = _slugify_plugin_name(category) or "<plugin-name>"
    return ValidationIssue(
        severity=severity,
        layer=4,
        category=category,
        bullet=unannotated[0].description,
        message=(
            f"{len(unannotated)} unannotated bullets in '{category}' look "
            f"vertical (vertical-ratio {ratio:.2f}) but no shape declared."
        ),
        suggestion=(
            f"Convert each unannotated bullet to "
            f"<feature shape=\"plugin\" plugin=\"{suggested_slug}\">."
        ),
    )


def check_plugin_dir_exists(
    feat: FeatureItem,
    project_root: Path,
    *,
    strict: bool,
    brownfield: bool,
) -> ValidationIssue | None:
    """Gap 5 — plugin='X' must reference an existing directory.

    Brownfield-only: greenfield specs predate the directory structure,
    so flagging would be noise.  WARNING / ERROR strict.
    """
    from claw_forge.spec.parser import DEFAULT_PLUGIN_ROOT

    if not brownfield:
        return None
    if feat.shape != "plugin" or not feat.plugin:
        return None

    severity = IssueSeverity.ERROR if strict else IssueSeverity.WARNING
    plugin_dir = project_root / DEFAULT_PLUGIN_ROOT / feat.plugin
    if plugin_dir.is_dir():
        return None
    return ValidationIssue(
        severity=severity,
        layer=4,
        category=feat.category,
        bullet=feat.description,
        message=(
            f"plugin='{feat.plugin}' references nonexistent directory "
            f"{DEFAULT_PLUGIN_ROOT}/{feat.plugin}/ — typo or missing scaffold?"
        ),
        suggestion=(
            f"Rename plugin= to an existing directory, override with explicit "
            f"touches_files=, or run `claw-forge boundaries apply` "
            f"to create {DEFAULT_PLUGIN_ROOT}/{feat.plugin}/."
        ),
    )


def run_shape_checks(
    spec: ProjectSpec,
    *,
    project_root: Path | None = None,
    strict: bool = False,
) -> ValidationReport:
    """Layer 4: architectural-shape coherence.

    Composes the six check functions:
      - check_plugin_shape_complete (Gap 1; per-feature; always ERROR)
      - check_migration_shape_candidate (Gap 8; per-feature; WARN/ERR strict)
      - check_touches_overlap (Gap 3; cross-feature; WARN/ERR strict)
      - check_core_chain_depth (Gap 7; graph; always WARN)
      - check_category_looks_vertical (Gap 6; per-category heuristic; WARN/ERR strict)
      - check_plugin_dir_exists (Gap 5; filesystem; brownfield only; WARN/ERR strict)

    Filesystem checks skip when project_root is None.  Brownfield is
    detected by the presence of src/plugins/ under project_root.
    """
    from claw_forge.spec.parser import DEFAULT_PLUGIN_ROOT

    issues: list[ValidationIssue] = []

    # Per-feature checks
    for feat in spec.features:
        issue = check_plugin_shape_complete(feat, strict=strict)
        if issue is not None:
            issues.append(issue)
        issue = check_migration_shape_candidate(feat, strict=strict)
        if issue is not None:
            issues.append(issue)

    # Cross-feature
    issues.extend(check_touches_overlap(spec, strict=strict))
    issues.extend(check_core_chain_depth(spec))

    # Per-category heuristic
    by_category: dict[str, list[FeatureItem]] = {}
    for feat in spec.features:
        by_category.setdefault(feat.category, []).append(feat)
    for cat, feats in by_category.items():
        issue = check_category_looks_vertical(cat, feats, strict=strict)
        if issue is not None:
            issues.append(issue)

    # Filesystem (brownfield only)
    if project_root is not None:
        plugin_root_dir = project_root / DEFAULT_PLUGIN_ROOT
        brownfield = plugin_root_dir.is_dir()
        for feat in spec.features:
            issue = check_plugin_dir_exists(
                feat, project_root,
                strict=strict, brownfield=brownfield,
            )
            if issue is not None:
                issues.append(issue)

    return ValidationReport(issues=issues, category_scores={})


def validate_spec(
    spec: ProjectSpec,
    run_llm: bool = True,
    approve_threshold: float = 7.0,
    llm_model: str = "claude-haiku-4-5-20251001",
    *,
    strict_shape: bool = False,
    project_root: Path | None = None,
) -> ValidationReport:
    """Run all four validation layers and return a merged ValidationReport.

    Parameters
    ----------
    spec:
        Parsed ProjectSpec (from ProjectSpec.from_file()).
    run_llm:
        Whether to run Layer 2 adversarial LLM evaluation.
        Skipped automatically if ANTHROPIC_API_KEY is absent.
    approve_threshold:
        Minimum category score for Layer 2 APPROVE. Default: 7.0.
    llm_model:
        Model for Layer 2. Default: Haiku (fast + cheap).
    strict_shape:
        If True, promote Layer 4 WARNING issues for gaps 3, 5, 6 to ERROR.
        Gap 1 is always ERROR; Gap 7 is always WARNING (not promoted).
    project_root:
        Project root for Layer 4 filesystem checks (Gap 5).  If None,
        filesystem checks are skipped.
    """
    merged = ValidationReport(issues=[], category_scores={})

    # Layer 1 — structural checks
    l1 = run_structural_checks(spec)
    merged.issues.extend(l1.issues)

    # Layer 2 — adversarial LLM (optional)
    if run_llm:
        l2 = run_llm_evaluation(spec, approve_threshold=approve_threshold, model=llm_model)
        merged.issues.extend(l2.issues)
        merged.category_scores.update(l2.category_scores)

    # Layer 3 — coverage gaps
    l3 = run_coverage_checks(spec)
    merged.issues.extend(l3.issues)

    # Layer 4 — architectural-shape coherence
    l4 = run_shape_checks(
        spec, project_root=project_root, strict=strict_shape,
    )
    merged.issues.extend(l4.issues)

    return merged
