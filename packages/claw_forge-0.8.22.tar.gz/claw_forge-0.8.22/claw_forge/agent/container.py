"""Per-agent container isolation (v0.8.19 Level 4) — opt-in.

The architectural step beyond v0.8.18's OS-level filesystem jail.
Level 2 (sandbox-exec / bwrap) makes file writes outside the worktree
return ``EACCES`` — strong, but the parent project's path still
exists in the agent's filesystem namespace, so a determined agent
can ``readdir`` it, ``stat`` it, learn paths to attempt.

Level 4 removes the parent project from the agent's universe
entirely.  Each agent runs in a container where ``/workspace`` is
the worktree (the only mount), and the parent project doesn't exist
as a path the kernel can resolve.  ``open("/Users/.../fengshui/...",
"w")`` doesn't fail with ``EACCES`` — it fails with ``ENOENT``
because that path is not in the container's filesystem namespace.

## Why opt-in (not the default)

Container isolation requires:

  * A container runtime (Docker or Podman) installed and accessible.
  * A user-built agent image with the ``claude`` CLI inside.
  * Sufficient resources for per-task container spawn cost (~1–3s
    startup latency per task — material when running many short
    tasks in parallel).

These costs are right for security-sensitive deployments and for
operators who want absolute isolation, but wrong for the default
single-machine dev loop where Level 2 + behavioural layers are
already plenty.  Operators opt in via ``agent.isolation: container``
in ``claw-forge.yaml``.

## Image requirements

The user's image must satisfy:

  * ``claude`` CLI on PATH (typically via
    ``npm install -g @anthropic-ai/claude-code``).
  * A working git installation.
  * A user account with write access to ``/workspace`` (the bind-
    mount target).  Default ``WORKDIR`` should be ``/workspace``.

A reference Dockerfile lives in ``docs/container-isolation.md`` —
operators copy it into their project, customise the base image to
match their stack (Python/Node/Go/etc.), build with
``docker build -t my-claw-forge-agent .``, and reference it via
``agent.container.image: my-claw-forge-agent`` in the config.

## What the wrapper does

For each task, the dispatcher generates a per-task wrapper script
that exec's:

  ``docker run --rm -i \\
      --volume <worktree>:/workspace \\
      --workdir /workspace \\
      --env ANTHROPIC_API_KEY \\
      --env ANTHROPIC_AUTH_TOKEN \\
      --env ANTHROPIC_BASE_URL \\
      [extra mounts] \\
      <image> claude "$@"``

The SDK's ``ClaudeAgentOptions.cli_path`` points at the wrapper, so
the SDK launches the wrapper instead of the bare ``claude`` binary;
stdio is proxied through ``docker run`` to the container's
``claude`` process via PID-1 signal forwarding and inherited fds.

## Networking

Default ``--network bridge`` (Docker's default) — claude needs
network access to call the Anthropic API.  No special configuration
required; we don't override.  Operators with stricter network
requirements can use ``--network none`` via ``extra_mounts``-style
extensions (out of scope for v0.8.19).

## Auth

Auth is passed via env-var pass-through (``-e ANTHROPIC_AUTH_TOKEN``
etc.) — the same env vars the dispatcher already constructs in
``sdk_env``.  We do NOT mount ``~/.claude`` into the container
because keychain-stored credentials don't translate across the
host-container boundary anyway, and bind-mounting the host's
config dir leaks more than auth (history, MCP config, model
preferences).  Env-var auth keeps the boundary clean.
"""
from __future__ import annotations

import logging
import shutil
import stat
import subprocess
from pathlib import Path

_log = logging.getLogger(__name__)

# Anthropic auth-related env vars that should be passed into the
# container so claude can authenticate.  Other env vars in the
# dispatcher's ``sdk_env`` (e.g. operator-set proxies) are NOT
# forwarded by default — operators add them via ``extra_env`` if
# they need.  Limiting the surface keeps the container's env clean
# and avoids accidentally leaking host secrets the agent doesn't
# need.
_AUTH_ENV_VARS: tuple[str, ...] = (
    "ANTHROPIC_API_KEY",
    "ANTHROPIC_AUTH_TOKEN",
    "ANTHROPIC_BASE_URL",
)


def detect_runtime(preference: str = "auto") -> str | None:
    """Return the container runtime to use, or ``None`` if none found.

    ``preference`` is one of ``"auto"``, ``"docker"``, ``"podman"``.
    For ``"auto"`` we try docker first (the more common default),
    then podman.  An explicit ``"docker"`` or ``"podman"`` returns
    that runtime if available, ``None`` otherwise.
    """
    if preference == "docker":
        return "docker" if shutil.which("docker") else None
    if preference == "podman":
        return "podman" if shutil.which("podman") else None
    # auto
    for candidate in ("docker", "podman"):
        if shutil.which(candidate):
            return candidate
    return None


def image_exists(runtime: str, image: str) -> bool:
    """Check whether *image* is locally available to *runtime*.

    Uses ``<runtime> image inspect <image>`` which is a lightweight
    check (no network call, no pull).  Returns ``False`` on any
    subprocess error so the caller can decide whether to attempt a
    pull or fail fast.
    """
    try:
        subprocess.run(
            [runtime, "image", "inspect", image],
            capture_output=True, text=True, check=True, timeout=15,
        )
    except (subprocess.SubprocessError, OSError):
        return False
    return True


def write_container_wrapper(
    *,
    runtime: str,
    image: str,
    worktree_path: Path,
    output_dir: Path,
    extra_mounts: list[str] | None = None,
    extra_env: list[str] | None = None,
) -> Path:
    """Write a per-task container-runner wrapper script.

    Returns the absolute path to the wrapper, suitable for
    ``ClaudeAgentOptions.cli_path``.  The SDK invokes the wrapper
    with claude's args; the wrapper exec's ``<runtime> run`` with
    the worktree mounted at ``/workspace``, then ``claude "$@"``
    inside the container so claude's args are passed verbatim.

    *extra_mounts*: additional ``-v`` mount specs (raw strings,
    e.g., ``"/host/path:/container/path:ro"``).  Operators use this
    for project-specific resources — language toolchains, test
    fixtures, shared caches — that the agent needs but shouldn't
    receive via env-var pass-through.

    *extra_env*: additional env-var names to forward beyond the
    Anthropic auth set.  Each becomes a ``-e <NAME>`` flag, so the
    container reads the host process's current value at run time
    (not at wrapper-write time).
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    # Mount specs: worktree + any extras.  Worktree is canonical-
    # path resolved so symlinks (e.g. /tmp → /private/tmp on macOS)
    # don't trip up Docker's path validation.
    mount_args = [f'-v "{worktree_path.resolve()}":/workspace']
    for m in extra_mounts or []:
        mount_args.append(f'-v "{m}"')

    env_names = list(_AUTH_ENV_VARS) + list(extra_env or [])
    env_args = [f"-e {name}" for name in env_names]

    # ``docker run`` lines:
    #   --rm: remove container after exit (no accumulating cruft)
    #   -i: keep stdin open (SDK uses it for the claude protocol)
    #   --workdir /workspace: agent's cwd is the worktree (mapped)
    # We do NOT pass -t (no TTY) — the SDK doesn't need a terminal
    # and -t would change claude's output framing.
    cmd_parts = [
        runtime, "run", "--rm", "-i",
        *mount_args,
        "--workdir", "/workspace",
        *env_args,
        image,
        "claude",
        '"$@"',
    ]

    wrapper_path = output_dir / "claude_containered"
    wrapper_path.write_text(
        "#!/bin/bash\n"
        "exec " + " ".join(cmd_parts) + "\n"
    )
    wrapper_path.chmod(
        wrapper_path.stat().st_mode
        | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH,
    )
    return wrapper_path


def make_container_wrapper(
    *,
    worktree_path: Path,
    output_dir: Path,
    runtime_preference: str = "auto",
    image: str,
    extra_mounts: list[str] | None = None,
    extra_env: list[str] | None = None,
    pull_if_missing: bool = False,
) -> Path:
    """High-level entrypoint: detect runtime, verify image, write wrapper.

    Raises ``RuntimeError`` (with a clear message) when:

      * ``runtime_preference`` is set but no runtime is available.
        Operator opted in to container isolation via config; silently
        falling back would mean the agent runs with weaker isolation
        than the operator asked for — fail fast instead.
      * The named *image* doesn't exist locally and ``pull_if_missing``
        is false (the default).  Operators control image availability
        explicitly; we don't quietly pull from a registry the operator
        didn't approve.

    Returns the wrapper path on success.  Caller wires this into
    ``ClaudeAgentOptions.cli_path``.
    """
    runtime = detect_runtime(runtime_preference)
    if runtime is None:
        raise RuntimeError(
            f"agent.isolation: container requires {runtime_preference} "
            "(or any container runtime when 'auto') but none found on "
            "PATH.  Install Docker or Podman, or set "
            "agent.isolation: process to use the OS-level sandbox."
        )

    if not image_exists(runtime, image):
        if not pull_if_missing:
            raise RuntimeError(
                f"agent.container.image '{image}' not found locally to "
                f"{runtime}.  Build it from the Dockerfile template in "
                "docs/container-isolation.md, or set "
                "agent.container.pull_if_missing: true."
            )
        # Best-effort pull; fail with a clear error if the image
        # doesn't exist remotely either.
        try:
            subprocess.run(
                [runtime, "pull", image],
                check=True, capture_output=True, text=True, timeout=300,
            )
        except subprocess.SubprocessError as exc:
            raise RuntimeError(
                f"agent.container.image '{image}' pull failed: {exc}.  "
                "Verify the image name and your registry access, or "
                "build it locally with 'docker build'."
            ) from exc

    return write_container_wrapper(
        runtime=runtime,
        image=image,
        worktree_path=worktree_path,
        output_dir=output_dir,
        extra_mounts=extra_mounts,
        extra_env=extra_env,
    )


__all__ = [
    "detect_runtime",
    "image_exists",
    "make_container_wrapper",
    "write_container_wrapper",
]
