# Author: Abdulwahed Mansour
"""django_pyforge — High-performance Django integration powered by Rust."""
__author__ = "Abdulwahed Mansour"
__version__ = "0.1.0"
try:
    from pyforge_django import (
        ModelSchema, extract_model_fields, serialize_batch, serialize_fields,
        serialize_instance, validate_fields, validate_instance, version,
    )
except ImportError as exc:
    raise ImportError("pyforge_django native extension not found. pip install pyforge-django") from exc
__all__ = ["ModelSchema", "extract_model_fields", "serialize_instance", "serialize_batch",
           "serialize_fields", "validate_instance", "validate_fields"]
