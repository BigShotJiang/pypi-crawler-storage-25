"""Unit tests for calibration: reliability curves, Bayes thresholds, calibrators, T-scaling.

Adapted from prompt_injection_detector/tests/test_calibration.py and
test_temperature_scaling.py — merged into one file per Decision 2 layout.
"""

from __future__ import annotations

import numpy as np
import pytest

from eval_toolkit.calibration import (
    CostMatrix,
    PlattFit,
    bayes_optimal_threshold,
    fit_isotonic_calibrator,
    fit_platt_calibrator,
    fit_temperature,
    fit_temperature_binary,
    fit_temperature_oracle,
    maximum_calibration_error,
    reliability_curve,
)


@pytest.fixture
def well_separated() -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(0)
    n = 500
    y = rng.binomial(1, 0.3, size=n).astype(int)
    s = np.clip(y * 0.6 + rng.normal(0, 0.2, n), 0, 1)
    return y, s


@pytest.mark.unit
def test_reliability_curve_schema(well_separated: tuple[np.ndarray, np.ndarray]) -> None:
    y, s = well_separated
    out = reliability_curve(y, s, n_bins=10, strategy="uniform")
    expected = {
        "n",
        "n_positive",
        "n_bins",
        "strategy",
        "prob_true",
        "prob_pred",
        "bin_edges",
        "n_per_bin",
        "ece_equal_mass",
        "ece_equal_width",
    }
    assert expected.issubset(out.keys())
    assert len(out["bin_edges"]) == 11  # n_bins + 1
    assert 0.0 <= out["ece_equal_width"] <= 1.0
    assert 0.0 <= out["ece_equal_mass"] <= 1.0


@pytest.mark.unit
def test_reliability_curve_skips_single_class() -> None:
    y_all_neg = np.zeros(20, dtype=int)
    s = np.linspace(0.1, 0.9, 20)
    out = reliability_curve(y_all_neg, s)
    assert "skipped" in out
    assert out["n_positive"] == 0


@pytest.mark.unit
def test_maximum_calibration_error_in_unit_interval(
    well_separated: tuple[np.ndarray, np.ndarray],
) -> None:
    y, s = well_separated
    mce = maximum_calibration_error(y, s, n_bins=10, strategy="quantile")
    assert mce is not None
    assert 0.0 <= mce <= 1.0


@pytest.mark.unit
def test_maximum_calibration_error_single_class_returns_none() -> None:
    s = np.linspace(0.1, 0.9, 20)
    assert maximum_calibration_error(np.zeros(20, dtype=int), s) is None
    assert maximum_calibration_error(np.ones(20, dtype=int), s) is None


@pytest.mark.unit
def test_maximum_calibration_error_validates() -> None:
    y = np.array([0, 1, 0, 1])
    s = np.array([0.1, 0.9, 0.2, 0.8])
    with pytest.raises(ValueError, match="shape mismatch"):
        maximum_calibration_error(y, s[:3])
    with pytest.raises(ValueError, match="empty"):
        maximum_calibration_error(np.array([]), np.array([]))
    with pytest.raises(ValueError, match="n_bins"):
        maximum_calibration_error(y, s, n_bins=1)
    with pytest.raises(ValueError, match="strategy"):
        maximum_calibration_error(y, s, strategy="invalid")  # type: ignore[arg-type]


@pytest.mark.unit
def test_maximum_calibration_error_agrees_with_reliability_curve_max_gap(
    well_separated: tuple[np.ndarray, np.ndarray],
) -> None:
    """Reference-impl agreement: MCE = max |prob_true - prob_pred| over populated bins.

    The standalone metric must equal the max-gap reconstructed from
    :func:`reliability_curve`'s ``prob_true`` / ``prob_pred`` arrays.
    """
    y, s = well_separated
    for strategy in ("uniform", "quantile"):
        mce = maximum_calibration_error(y, s, n_bins=10, strategy=strategy)
        rc = reliability_curve(y, s, n_bins=10, strategy=strategy)
        expected = float(np.abs(np.asarray(rc["prob_true"]) - np.asarray(rc["prob_pred"])).max())
        assert mce == pytest.approx(expected), f"strategy={strategy}"


@pytest.mark.unit
def test_maximum_calibration_error_ge_expected_calibration_error(
    well_separated: tuple[np.ndarray, np.ndarray],
) -> None:
    """MCE ≥ ECE: max of |gaps| dominates any weighted mean of |gaps|.

    Holds for both binning strategies; max ≥ weighted_mean is identity.
    """
    y, s = well_separated
    for strategy in ("uniform", "quantile"):
        mce = maximum_calibration_error(y, s, n_bins=10, strategy=strategy)
        rc = reliability_curve(y, s, n_bins=10, strategy=strategy)
        ece_key = "ece_equal_width" if strategy == "uniform" else "ece_equal_mass"
        ece = float(rc[ece_key])
        assert mce is not None
        assert mce + 1e-12 >= ece, f"strategy={strategy}: MCE {mce} < ECE {ece}"


@pytest.mark.unit
def test_fit_platt_returns_platt_fit_dataclass(
    well_separated: tuple[np.ndarray, np.ndarray],
) -> None:
    """v0.12.0: fit_platt_calibrator returns PlattFit, not a plain Callable.

    PlattFit exposes (a, b) and delegates __call__ to transform, preserving
    back-compat with v0.11.0 and earlier (where the return was a Callable).
    """
    y, s = well_separated
    fit = fit_platt_calibrator(y, s)
    assert isinstance(fit, PlattFit)
    assert isinstance(fit.a, float)
    assert isinstance(fit.b, float)
    # Well-separated → positive slope (high score → high P)
    assert fit.a > 0.0


@pytest.mark.unit
def test_platt_fit_call_delegates_to_transform(
    well_separated: tuple[np.ndarray, np.ndarray],
) -> None:
    """PlattFit.__call__(scores) === PlattFit.transform(scores) (back-compat)."""
    y, s = well_separated
    fit = fit_platt_calibrator(y, s)
    test_scores = np.array([0.0, 0.3, 0.7, 1.0])
    via_call = fit(test_scores)
    via_transform = fit.transform(test_scores)
    np.testing.assert_array_equal(via_call, via_transform)


@pytest.mark.unit
def test_platt_fit_a_b_match_sigmoid_parameterization(
    well_separated: tuple[np.ndarray, np.ndarray],
) -> None:
    """PlattFit.a, PlattFit.b parameterize sigmoid(a·s + b).

    Verify the closed-form: transform(0) = σ(b) = 1/(1+exp(-b)) and
    transform(1) = σ(a + b). Tolerance 1e-9.
    """
    y, s = well_separated
    fit = fit_platt_calibrator(y, s)
    out = fit(np.array([0.0, 1.0]))
    expected_at_0 = 1.0 / (1.0 + np.exp(-fit.b))
    expected_at_1 = 1.0 / (1.0 + np.exp(-(fit.a + fit.b)))
    assert float(out[0]) == pytest.approx(expected_at_0, abs=1e-9)
    assert float(out[1]) == pytest.approx(expected_at_1, abs=1e-9)


@pytest.mark.unit
def test_platt_fit_is_frozen() -> None:
    """PlattFit is a frozen dataclass — assigning fields raises."""
    y = np.array([0, 1, 0, 1, 0, 1])
    s = np.array([0.1, 0.9, 0.2, 0.8, 0.15, 0.85])
    fit = fit_platt_calibrator(y, s)
    with pytest.raises((AttributeError, Exception)):  # FrozenInstanceError or dataclasses-specific
        fit.a = 0.0  # type: ignore[misc]


@pytest.mark.unit
def test_bayes_optimal_threshold_symmetric_costs() -> None:
    """At symmetric costs c_fp=c_fn, the threshold equals 1-π (Elkan 2001).

    Derivation: t* = c_fp(1-π) / (c_fp(1-π) + c_fn·π).
    With c_fp = c_fn = c, this simplifies to (1-π) since c factors out
    of numerator and denominator: t* = (1-π) / ((1-π) + π) = 1-π.
    """
    for π in [0.1, 0.3, 0.5, 0.7, 0.9]:
        assert bayes_optimal_threshold(π, c_fp=1.0, c_fn=1.0) == pytest.approx(1.0 - π)


@pytest.mark.unit
def test_bayes_optimal_threshold_extremes() -> None:
    assert bayes_optimal_threshold(0.0, c_fp=1.0, c_fn=1.0) == 1.0
    assert bayes_optimal_threshold(1.0, c_fp=1.0, c_fn=1.0) == 0.0


@pytest.mark.unit
def test_bayes_optimal_threshold_validates() -> None:
    with pytest.raises(ValueError, match="prior"):
        bayes_optimal_threshold(-0.1, 1.0, 1.0)
    with pytest.raises(ValueError, match="c_fp"):
        bayes_optimal_threshold(0.5, 0.0, 1.0)
    with pytest.raises(ValueError, match="c_fn"):
        bayes_optimal_threshold(0.5, 1.0, 0.0)


@pytest.mark.unit
def test_cost_matrix_bayes_threshold_consistency() -> None:
    cm = CostMatrix(prior=0.01, fp_cost=1.0, fn_cost=10.0)
    assert cm.bayes_threshold == bayes_optimal_threshold(0.01, 1.0, 10.0)


@pytest.mark.unit
def test_cost_matrix_validates() -> None:
    with pytest.raises(ValueError, match="prior"):
        CostMatrix(prior=1.5)
    with pytest.raises(ValueError, match="fp_cost"):
        CostMatrix(fp_cost=-1.0)
    with pytest.raises(ValueError, match="fn_cost"):
        CostMatrix(fn_cost=0.0)


@pytest.mark.unit
def test_fit_isotonic_calibrator_monotone(well_separated: tuple[np.ndarray, np.ndarray]) -> None:
    """Output is monotone in input."""
    y, s = well_separated
    g = fit_isotonic_calibrator(y, s)
    test_inputs = np.linspace(0.0, 1.0, 50)
    out = g(test_inputs)
    assert all(out[i] <= out[i + 1] + 1e-9 for i in range(len(out) - 1))


@pytest.mark.unit
def test_fit_isotonic_clips_to_unit_interval(
    well_separated: tuple[np.ndarray, np.ndarray],
) -> None:
    y, s = well_separated
    g = fit_isotonic_calibrator(y, s)
    out = g(np.array([-1.0, 0.0, 0.5, 1.0, 2.0]))
    assert (out >= 0.0).all() and (out <= 1.0).all()


@pytest.mark.unit
def test_fit_platt_in_unit_interval(well_separated: tuple[np.ndarray, np.ndarray]) -> None:
    """Canonical Platt outputs are in [0, 1].

    Note: canonical Platt (Lin 2007) does NOT clip; large |z| values saturate
    σ(z) → 0 or 1 in floating-point. Previous (≤ v0.2.0) implementation
    used L2-regularized LogisticRegression which kept the slope smaller and
    avoided saturation; the saturation here is canonical-Platt-correct.
    """
    y, s = well_separated
    g = fit_platt_calibrator(y, s)
    out = g(np.linspace(-2.0, 3.0, 50))
    assert (out >= 0.0).all() and (out <= 1.0).all()


@pytest.mark.unit
def test_fit_platt_monotonic(well_separated: tuple[np.ndarray, np.ndarray]) -> None:
    """Platt is a strictly monotonic transform on the score."""
    y, s = well_separated
    g = fit_platt_calibrator(y, s)
    grid = np.linspace(-2.0, 3.0, 50)
    out = g(grid)
    diffs = np.diff(out)
    # Either monotone increasing or monotone decreasing, depending on data direction.
    assert (diffs >= 0).all() or (diffs <= 0).all()


@pytest.mark.unit
def test_fit_temperature_oracle_runs(
    well_separated: tuple[np.ndarray, np.ndarray],
) -> None:
    y, s = well_separated
    s_clipped = np.clip(s, 0.01, 0.99)
    T_opt, apply = fit_temperature_oracle(y, s_clipped)
    assert T_opt > 0
    out = apply(s_clipped)
    assert (out > 0.0).all() and (out < 1.0).all()


@pytest.mark.unit
def test_fit_temperature_recovers_known_temperature() -> None:
    """When labels are sampled at T_true=3, fit_temperature should recover ~3."""
    rng = np.random.default_rng(42)
    n = 2000
    base = rng.normal(size=(n, 2))
    T_true = 3.0
    # Labels generated at the true T (i.e., sharp logits / T_true)
    sharpened = base / T_true
    probs = np.exp(sharpened) / np.exp(sharpened).sum(axis=1, keepdims=True)
    labels = (rng.uniform(size=n) < probs[:, 1]).astype(int)
    # Now: present logits as `base` (overconfident) — fit T should recover T_true.
    result = fit_temperature(base, labels)
    # Tolerance: ±50% on T because synthetic noise is finite.
    assert 0.5 * T_true < result["temperature"] < 1.5 * T_true


@pytest.mark.unit
def test_fit_temperature_improves_nll(well_separated: tuple[np.ndarray, np.ndarray]) -> None:
    """fit_temperature never increases NLL (T=1 is a feasible point)."""
    rng = np.random.default_rng(0)
    n = 500
    logits = rng.normal(size=(n, 2)) * 3  # overconfident
    labels = (logits[:, 1] > logits[:, 0]).astype(int)
    result = fit_temperature(logits, labels)
    assert result["nll_post"] <= result["nll_pre"] + 1e-9
    assert result["improvement"] >= -1e-9


@pytest.mark.unit
def test_fit_temperature_validates() -> None:
    with pytest.raises(ValueError, match="must be \\(n, 2\\)"):
        fit_temperature(np.zeros(10), np.zeros(10))
    with pytest.raises(ValueError, match="must be binary"):
        fit_temperature(np.zeros((5, 2)), np.array([0, 1, 2, 0, 1]))
    with pytest.raises(ValueError, match="length mismatch"):
        fit_temperature(np.zeros((5, 2)), np.zeros(7, dtype=int))


@pytest.mark.unit
def test_calibrator_rejects_single_class() -> None:
    y_all_pos = np.ones(50, dtype=int)
    s = np.linspace(0.1, 0.9, 50)
    with pytest.raises(ValueError, match="both classes"):
        fit_isotonic_calibrator(y_all_pos, s)
    with pytest.raises(ValueError, match="both classes"):
        fit_platt_calibrator(y_all_pos, s)


@pytest.mark.unit
def test_fit_platt_matches_sklearn_canonical() -> None:
    """fit_platt_calibrator now matches sklearn's _SigmoidCalibration to <1e-6.

    Canonical Platt + Lin 2007 is implemented in
    sklearn.calibration._SigmoidCalibration; v0.3.0 reproduces it directly
    rather than wrapping LogisticRegression.
    """
    from sklearn.calibration import _SigmoidCalibration  # noqa: PLC0415

    rng = np.random.default_rng(0)
    n = 300
    y = rng.binomial(1, 0.3, size=n).astype(int)  # imbalanced; Lin 2007 matters most here
    s = y + rng.normal(0, 1.0, size=n)

    ours = fit_platt_calibrator(y, s)
    sk_cal = _SigmoidCalibration().fit(s, y)

    grid = np.linspace(s.min(), s.max(), 100)
    ours_out = ours(grid)
    sk_out = sk_cal.predict(grid)
    np.testing.assert_allclose(ours_out, sk_out, atol=1e-6, rtol=1e-6)


# --- fit_temperature_binary (#28) -------------------------------------------------


@pytest.mark.unit
def test_fit_temperature_binary_runs(well_separated: tuple[np.ndarray, np.ndarray]) -> None:
    """Smoke test: returns positive T + callable; calibrated outputs in (0, 1)."""
    y, s = well_separated
    s_clipped = np.clip(s, 0.01, 0.99)
    T, apply = fit_temperature_binary(y, s_clipped)
    assert T > 0
    out = apply(s_clipped)
    assert out.shape == s_clipped.shape  # scalar (n,) in/out contract
    assert (out > 0.0).all() and (out < 1.0).all()


@pytest.mark.unit
def test_fit_temperature_binary_shape_contract() -> None:
    """Apply returns shape (n,), never (n, 2). Guards against 2-col regressions."""
    rng = np.random.default_rng(0)
    y = rng.binomial(1, 0.3, size=200).astype(int)
    s = np.clip(y * 0.6 + rng.normal(0, 0.2, 200), 0.01, 0.99)
    _, apply = fit_temperature_binary(y, s)
    for shape in [(1,), (3,), (50,)]:
        p_test = rng.uniform(0.05, 0.95, size=shape)
        assert apply(p_test).shape == shape


@pytest.mark.unit
def test_fit_temperature_binary_handles_extremes() -> None:
    """Probas at exactly 0 and 1 produce finite outputs (clipping covers the logit pole).

    Contract: ``logit(0)`` and ``logit(1)`` are infinite, but the internal
    clipping to ``[1e-7, 1-1e-7]`` keeps the math finite. Outputs may hit the
    float64 boundary (0.0 or 1.0) at extreme inputs with small T — that is
    correct behavior, not a violation. The real failure mode this test guards
    against is ``inf`` / ``nan`` in either fit or apply.
    """
    rng = np.random.default_rng(0)
    n = 200
    y = rng.binomial(1, 0.5, size=n).astype(int)
    s = y.astype(float)  # exact 0s and 1s in val data
    T, apply = fit_temperature_binary(y, s)
    assert np.isfinite(T)
    # Apply to extremes — must be finite + in [0, 1] (boundary-inclusive)
    p_test = np.array([0.0, 0.5, 1.0])
    out = apply(p_test)
    assert np.isfinite(out).all()
    assert (out >= 0.0).all() and (out <= 1.0).all()


@pytest.mark.unit
def test_fit_temperature_binary_parity_with_multiclass() -> None:
    """fit_temperature_binary(y, p) matches manual fit_temperature(2-col-logits, y).

    Establishes the contract that the binary adapter is a thin wrapper, not a
    re-implementation: identical T, identical applied probabilities.
    """
    rng = np.random.default_rng(7)
    n = 400
    y = rng.binomial(1, 0.4, size=n).astype(int)
    p_val = np.clip(y * 0.5 + rng.normal(0, 0.25, n), 0.01, 0.99)
    p_test = rng.uniform(0.05, 0.95, size=50)

    T_binary, apply_binary = fit_temperature_binary(y, p_val)

    # Manual multi-class path: build 2-col logits, fit T, apply via softmax row 1.
    logit_val = np.log(p_val / (1.0 - p_val))
    val_logits_2col = np.column_stack([np.zeros_like(logit_val), logit_val])
    result_mc = fit_temperature(val_logits_2col, y)
    T_mc = result_mc["temperature"]

    logit_test = np.log(p_test / (1.0 - p_test))
    test_logits_2col = np.column_stack([np.zeros_like(logit_test), logit_test]) / T_mc
    # softmax row 1 = exp(z1) / (exp(0) + exp(z1)) = sigmoid(z1)
    expected = 1.0 / (1.0 + np.exp(-test_logits_2col[:, 1]))

    assert T_binary == pytest.approx(T_mc, rel=1e-9)
    np.testing.assert_allclose(apply_binary(p_test), expected, rtol=1e-9, atol=1e-12)


@pytest.mark.unit
def test_fit_temperature_binary_improves_nll() -> None:
    """T_post NLL ≤ T_pre NLL (T=1 is always a feasible point in the bracket)."""
    rng = np.random.default_rng(0)
    n = 500
    y = rng.binomial(1, 0.4, size=n).astype(int)
    # Overconfident probabilities: push away from 0.5
    raw = y * 0.7 + rng.normal(0, 0.15, n)
    p = np.clip(0.5 + 2.5 * (raw - 0.5), 0.01, 0.99)
    T, apply = fit_temperature_binary(y, p)
    eps = 1e-12

    def _binary_nll(probs: np.ndarray, labels: np.ndarray) -> float:
        c = np.clip(probs, eps, 1 - eps)
        return float(-(labels * np.log(c) + (1 - labels) * np.log(1 - c)).mean())

    nll_pre = _binary_nll(p, y)
    nll_post = _binary_nll(apply(p), y)
    assert nll_post <= nll_pre + 1e-9


@pytest.mark.unit
def test_fit_temperature_binary_validates() -> None:
    """Error paths inherit from _validate_calibrator_inputs."""
    with pytest.raises(ValueError, match="shape mismatch"):
        fit_temperature_binary(np.zeros(5, dtype=int), np.zeros(7))
    with pytest.raises(ValueError, match="empty"):
        fit_temperature_binary(np.array([], dtype=int), np.array([]))
    with pytest.raises(ValueError, match="NaN or inf"):
        fit_temperature_binary(np.array([0, 1, 0, 1]), np.array([0.1, np.nan, 0.3, 0.7]))
    with pytest.raises(ValueError, match="both classes"):
        fit_temperature_binary(np.ones(50, dtype=int), np.linspace(0.1, 0.9, 50))


@pytest.mark.unit
def test_fit_temperature_binary_apply_rejects_nonfinite() -> None:
    """Apply rejects non-finite test-time scores (does not silently mask)."""
    rng = np.random.default_rng(0)
    y = rng.binomial(1, 0.3, size=200).astype(int)
    s = np.clip(y * 0.6 + rng.normal(0, 0.2, 200), 0.01, 0.99)
    _, apply = fit_temperature_binary(y, s)
    with pytest.raises(ValueError, match="NaN or inf"):
        apply(np.array([0.5, np.nan, 0.7]))
