"""Adversarial robustness: character-injection bypass suite + Scorer-Protocol sweep.

Implements the character-injection bypass techniques from Microsoft Research
2024 ([1]_) for testing prompt-injection-detection scorers under adversarial
input perturbation. Each technique is deterministic given a ``seed`` and
preserves the surface meaning of the text from a human reader's perspective
while shifting the tokenizer / scorer's representation.

Core techniques shipped in v0.43.0:

- :class:`ZeroWidthSpaceInjection` — insert U+200B zero-width spaces
- :class:`HomoglyphSubstitution` — Latin → Cyrillic/Greek lookalikes
- :class:`DiacriticInjection` — combining-mark insertion (NFC bypass)
- :class:`WhitespaceInjection` — variable whitespace padding (regular + NBSP)
- :class:`CaseRandomization` — random case-flipping per character
- :class:`PunctuationInjection` — non-semantic punctuation insertion

The :func:`sweep` function applies a set of techniques against a
:class:`~eval_toolkit.protocols.Scorer`-Protocol-compliant scorer and
returns a DataFrame of
``(text_id, technique, original_score, transformed_score, asr)``
for adversarial robustness analysis. ASR (attack success rate) is the
fraction of inputs where the scorer crossed the threshold from positive
to negative under the transformation.

The six advanced techniques (bidi RTL override, tag stripping, synonym
substitution, token splitting, Unicode normalization, invisible
characters) are scheduled for v0.43.1 as a follow-up patch; the sweep
API stabilizes in v0.43.0 so the v0.43.1 additions are pure extensions.

A module-level :data:`character_injection` namespace exposes the
function-style API from the upstream issue spec:

>>> from eval_toolkit.adversarial import character_injection
>>> character_injection.zero_width_space("hello")  # doctest: +SKIP
'h​e​l​l​o'

References
----------
.. [1] Microsoft Research, 2024. "Adversarial Suffixes Hidden in Plain
       Sight." arXiv:2404.13208.
"""

from __future__ import annotations

import random
from collections.abc import Sequence
from dataclasses import dataclass
from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

import numpy as np

from eval_toolkit.protocols import Scorer

if TYPE_CHECKING:
    import pandas as pd

__all__ = [
    "CORE_TECHNIQUES",
    "CaseRandomization",
    "CharacterInjectionStrategy",
    "DiacriticInjection",
    "HomoglyphSubstitution",
    "PunctuationInjection",
    "WhitespaceInjection",
    "ZeroWidthSpaceInjection",
    "character_injection",
    "sweep",
]


# Character constants
_ZWSP = "​"  # zero-width space
_NBSP = " "  # non-breaking space
_TAB = "\t"
_PUNCT_CHARS = ".,;:!?-_"

# Latin → Cyrillic homoglyph substitution table (visually identical, distinct
# code points). Subset chosen to maximize Unicode-confusable coverage without
# breaking text legibility in most fonts.
_HOMOGLYPHS: dict[str, str] = {
    "a": "а",  # CYRILLIC SMALL LETTER A
    "c": "с",  # CYRILLIC SMALL LETTER ES
    "e": "е",  # CYRILLIC SMALL LETTER IE
    "o": "о",  # CYRILLIC SMALL LETTER O
    "p": "р",  # CYRILLIC SMALL LETTER ER
    "x": "х",  # CYRILLIC SMALL LETTER HA
    "y": "у",  # CYRILLIC SMALL LETTER U
    "A": "А",  # CYRILLIC CAPITAL LETTER A
    "B": "В",  # CYRILLIC CAPITAL LETTER VE
    "E": "Е",  # CYRILLIC CAPITAL LETTER IE
    "K": "К",  # CYRILLIC CAPITAL LETTER KA
    "O": "О",  # CYRILLIC CAPITAL LETTER O
    "P": "Р",  # CYRILLIC CAPITAL LETTER ER
    "T": "Т",  # CYRILLIC CAPITAL LETTER TE
}

# Combining marks (NFD-style). Applied after a base char they render as
# diacritics; the visual is unchanged in most fonts but the byte stream
# carries extra code points.
_COMBINING_MARKS: tuple[str, ...] = (
    "̀",  # combining grave accent
    "́",  # combining acute accent
    "̂",  # combining circumflex accent
    "̃",  # combining tilde
    "̄",  # combining macron
    "̆",  # combining breve
    "̇",  # combining dot above
    "̈",  # combining diaeresis
)

# Whitespace variants (regular " " excluded — substituting space-for-space is a
# no-op and prevents the test from observing the substitution actually happened).
_WHITESPACE_VARIANTS: tuple[str, ...] = (_NBSP, _TAB)


@runtime_checkable
class CharacterInjectionStrategy(Protocol):
    """Apply a deterministic character-level adversarial transformation.

    Implementations are frozen dataclasses configured via constructor
    params (e.g. ``ratio`` + ``seed``) and expose:

    - ``name`` — stable technique identifier used in sweep result rows
    - ``transform(text: str) -> str`` — the transformation itself

    Strategies must be picklable for parallel sweep dispatch (no
    closures over local state; ``frozen=True, slots=True`` enforced).
    """

    name: str

    def transform(self, text: str) -> str:  # pragma: no cover
        """Return the transformed text."""
        ...


@dataclass(frozen=True, slots=True)
class ZeroWidthSpaceInjection:
    """Insert U+200B zero-width spaces between characters at the given ratio.

    Visually identical to the original text; tokenizers split on the inserted
    code point, often shifting sub-word boundaries enough to evade pattern-
    matching detectors.

    Parameters
    ----------
    ratio : float, optional
        Probability of inserting a ZWSP after each character. ``0.5`` (default)
        injects between roughly every other char. Must be in ``[0, 1]``.
    seed : int, optional
        Random seed for deterministic insertion. Default ``42``.
    name : str, optional
        Override the default technique name (``"zero_width_space"``); rarely
        needed.
    """

    ratio: float = 0.5
    seed: int = 42
    name: str = "zero_width_space"

    def __post_init__(self) -> None:
        if not 0.0 <= self.ratio <= 1.0:
            raise ValueError(f"ZeroWidthSpaceInjection: ratio must be in [0, 1]; got {self.ratio}")

    def transform(self, text: str) -> str:
        rng = random.Random(self.seed)
        out: list[str] = []
        for ch in text:
            out.append(ch)
            if rng.random() < self.ratio:
                out.append(_ZWSP)
        return "".join(out)


@dataclass(frozen=True, slots=True)
class HomoglyphSubstitution:
    """Substitute Latin characters with Cyrillic/Greek homoglyph lookalikes.

    Each substitution is deterministic given the seed: a per-character RNG
    decides whether to swap based on ``ratio``. Characters not in the
    homoglyph table pass through unchanged.

    Parameters
    ----------
    ratio : float, optional
        Probability of substituting each homoglyph-eligible character.
        Default ``0.3``.
    seed : int, optional
        Random seed for determinism. Default ``42``.
    name : str, optional
        Override technique name. Default ``"homoglyph"``.
    """

    ratio: float = 0.3
    seed: int = 42
    name: str = "homoglyph"

    def __post_init__(self) -> None:
        if not 0.0 <= self.ratio <= 1.0:
            raise ValueError(f"HomoglyphSubstitution: ratio must be in [0, 1]; got {self.ratio}")

    def transform(self, text: str) -> str:
        rng = random.Random(self.seed)
        out: list[str] = []
        for ch in text:
            if ch in _HOMOGLYPHS and rng.random() < self.ratio:
                out.append(_HOMOGLYPHS[ch])
            else:
                out.append(ch)
        return "".join(out)


@dataclass(frozen=True, slots=True)
class DiacriticInjection:
    """Insert combining diacritic marks after random characters.

    Combining marks (U+0300..U+0308) attach to the preceding character
    visually but produce a distinct code-point stream that tokenizers
    process as different sub-words. Most fonts render the result with
    subtle visual artifacts (zalgo-style for high ratios).

    Parameters
    ----------
    ratio : float, optional
        Probability of inserting a combining mark after each base
        character. Default ``0.3``.
    seed : int, optional
        Random seed. Default ``42``.
    name : str, optional
        Override technique name. Default ``"diacritic"``.
    """

    ratio: float = 0.3
    seed: int = 42
    name: str = "diacritic"

    def __post_init__(self) -> None:
        if not 0.0 <= self.ratio <= 1.0:
            raise ValueError(f"DiacriticInjection: ratio must be in [0, 1]; got {self.ratio}")

    def transform(self, text: str) -> str:
        rng = random.Random(self.seed)
        out: list[str] = []
        for ch in text:
            out.append(ch)
            # Combining marks attach to base characters (alphanumeric); skip on
            # whitespace / punctuation where they render poorly.
            if ch.isalnum() and rng.random() < self.ratio:
                out.append(rng.choice(_COMBINING_MARKS))
        return "".join(out)


@dataclass(frozen=True, slots=True)
class WhitespaceInjection:
    """Insert / substitute whitespace variants (regular, non-breaking, tab).

    Replaces existing spaces with random whitespace variants and optionally
    pads non-space positions with extra spaces. Detectors that tokenize on
    whitespace can shift token boundaries; some lose detection signal
    entirely when NBSPs replace regular spaces.

    Parameters
    ----------
    pad_ratio : float, optional
        Probability of inserting an extra space after each character (regardless
        of whether the position was a space). Default ``0.1``.
    substitute_ratio : float, optional
        Probability of replacing each existing space with a non-breaking-space
        or tab variant. Default ``0.5``.
    seed : int, optional
        Random seed. Default ``42``.
    name : str, optional
        Override technique name. Default ``"whitespace"``.
    """

    pad_ratio: float = 0.1
    substitute_ratio: float = 0.5
    seed: int = 42
    name: str = "whitespace"

    def __post_init__(self) -> None:
        for field_name, val in (
            ("pad_ratio", self.pad_ratio),
            ("substitute_ratio", self.substitute_ratio),
        ):
            if not 0.0 <= val <= 1.0:
                raise ValueError(f"WhitespaceInjection: {field_name} must be in [0, 1]; got {val}")

    def transform(self, text: str) -> str:
        rng = random.Random(self.seed)
        out: list[str] = []
        for ch in text:
            if ch == " " and rng.random() < self.substitute_ratio:
                out.append(rng.choice(_WHITESPACE_VARIANTS))
            else:
                out.append(ch)
            if rng.random() < self.pad_ratio:
                out.append(" ")
        return "".join(out)


@dataclass(frozen=True, slots=True)
class CaseRandomization:
    """Randomly flip the case of alphabetic characters.

    Deterministic given the seed. Numeric / punctuation / whitespace pass
    through unchanged. Useful against detectors that don't lower-case their
    input.

    Parameters
    ----------
    ratio : float, optional
        Probability of flipping each alphabetic character's case.
        Default ``0.5``.
    seed : int, optional
        Random seed. Default ``42``.
    name : str, optional
        Override technique name. Default ``"case_random"``.
    """

    ratio: float = 0.5
    seed: int = 42
    name: str = "case_random"

    def __post_init__(self) -> None:
        if not 0.0 <= self.ratio <= 1.0:
            raise ValueError(f"CaseRandomization: ratio must be in [0, 1]; got {self.ratio}")

    def transform(self, text: str) -> str:
        rng = random.Random(self.seed)
        out: list[str] = []
        for ch in text:
            if ch.isalpha() and rng.random() < self.ratio:
                out.append(ch.lower() if ch.isupper() else ch.upper())
            else:
                out.append(ch)
        return "".join(out)


@dataclass(frozen=True, slots=True)
class PunctuationInjection:
    """Insert non-semantic punctuation between characters.

    Inserts characters from ``.,;:!?-_`` at random positions; renders as
    obvious noise to a human but can fragment regex / pattern-matching
    detectors. Use sparingly (low ``ratio``).

    Parameters
    ----------
    ratio : float, optional
        Probability of inserting punctuation after each character.
        Default ``0.1``.
    seed : int, optional
        Random seed. Default ``42``.
    name : str, optional
        Override technique name. Default ``"punctuation"``.
    """

    ratio: float = 0.1
    seed: int = 42
    name: str = "punctuation"

    def __post_init__(self) -> None:
        if not 0.0 <= self.ratio <= 1.0:
            raise ValueError(f"PunctuationInjection: ratio must be in [0, 1]; got {self.ratio}")

    def transform(self, text: str) -> str:
        rng = random.Random(self.seed)
        out: list[str] = []
        for ch in text:
            out.append(ch)
            # Only inject after alphanumeric chars; avoids double-punctuation
            # noise where it would be obvious to a human reader.
            if ch.isalnum() and rng.random() < self.ratio:
                out.append(rng.choice(_PUNCT_CHARS))
        return "".join(out)


# Core 6 — registered by default in :func:`sweep` when ``techniques="all"``
# during v0.43.0. Advanced 6 (bidi, tag stripping, synonym, token split,
# Unicode normalization, invisible chars) land in v0.43.1 and will append
# to this tuple.
# Annotated as ``tuple[type[Any], ...]`` because Protocol classes can't be
# used as the parameter of ``type[...]`` in concrete tuple literals without
# triggering a strict-mypy assignability error (Protocol is structural;
# ``type[Protocol]`` rejects concrete-class types). The runtime check in
# :func:`sweep` re-asserts each instance satisfies the Protocol.
CORE_TECHNIQUES: tuple[type[Any], ...] = (
    ZeroWidthSpaceInjection,
    HomoglyphSubstitution,
    DiacriticInjection,
    WhitespaceInjection,
    CaseRandomization,
    PunctuationInjection,
)


# ----------------------------------------------------------------------------
# Module-level function namespace (matches issue spec API)
# ----------------------------------------------------------------------------


def _zero_width_space(text: str, ratio: float = 0.5, seed: int = 42) -> str:
    """Functional alias for :class:`ZeroWidthSpaceInjection`."""
    return ZeroWidthSpaceInjection(ratio=ratio, seed=seed).transform(text)


def _homoglyph(text: str, ratio: float = 0.3, seed: int = 42) -> str:
    """Functional alias for :class:`HomoglyphSubstitution`."""
    return HomoglyphSubstitution(ratio=ratio, seed=seed).transform(text)


def _diacritic(text: str, ratio: float = 0.3, seed: int = 42) -> str:
    """Functional alias for :class:`DiacriticInjection`."""
    return DiacriticInjection(ratio=ratio, seed=seed).transform(text)


def _whitespace(
    text: str, pad_ratio: float = 0.1, substitute_ratio: float = 0.5, seed: int = 42
) -> str:
    """Functional alias for :class:`WhitespaceInjection`."""
    return WhitespaceInjection(
        pad_ratio=pad_ratio, substitute_ratio=substitute_ratio, seed=seed
    ).transform(text)


def _case_random(text: str, ratio: float = 0.5, seed: int = 42) -> str:
    """Functional alias for :class:`CaseRandomization`."""
    return CaseRandomization(ratio=ratio, seed=seed).transform(text)


def _punctuation(text: str, ratio: float = 0.1, seed: int = 42) -> str:
    """Functional alias for :class:`PunctuationInjection`."""
    return PunctuationInjection(ratio=ratio, seed=seed).transform(text)


# Namespace exposing the upstream-issue's preferred functional API
# (``character_injection.zero_width_space(text)``). Built once at import time;
# pickling-safe (SimpleNamespace + function references).
character_injection = SimpleNamespace(
    zero_width_space=_zero_width_space,
    homoglyph=_homoglyph,
    diacritic=_diacritic,
    whitespace=_whitespace,
    case_random=_case_random,
    punctuation=_punctuation,
    sweep=None,  # populated below after sweep is defined
)


# ----------------------------------------------------------------------------
# Scorer-Protocol sweep
# ----------------------------------------------------------------------------


def sweep(
    texts: Sequence[str],
    scorer: Scorer,
    *,
    techniques: Sequence[CharacterInjectionStrategy] | str = "all",
    threshold: float = 0.5,
    seed: int = 42,
) -> pd.DataFrame:
    """Run a multi-technique adversarial sweep against ``scorer``.

    For each input text and each technique:

    1. Compute the original score ``s_orig = scorer.predict_proba([text])[0]``
    2. Transform the text via the technique
    3. Compute the transformed score ``s_adv = scorer.predict_proba([t'])[0]``
    4. Record an attack-success flag: ``s_orig >= threshold > s_adv``
       (the scorer detected the original but missed the adversarial)

    The returned DataFrame has one row per ``(text_id, technique)`` pair plus
    aggregate ASR available via ``.groupby("technique")["asr"].mean()``.

    Parameters
    ----------
    texts : sequence of str
        Inputs to test. Each is identified by its 0-based index as
        ``text_id``.
    scorer : Scorer
        Any object satisfying the :class:`~eval_toolkit.protocols.Scorer`
        Protocol (a ``predict_proba(X) -> np.ndarray`` method).
    techniques : sequence of CharacterInjectionStrategy or {"all"}, optional
        Which techniques to apply. ``"all"`` (default) instantiates each
        class in :data:`CORE_TECHNIQUES` with default kwargs and the
        sweep ``seed``. Pass pre-configured strategy instances for custom
        ratios.
    threshold : float, optional
        Score threshold the scorer publishes as its decision boundary
        (default ``0.5``). Used for the ASR flag.
    seed : int, optional
        Seed forwarded to ``"all"``-spawned techniques; ignored when
        ``techniques`` is an explicit instance list (each instance carries
        its own seed). Default ``42``.

    Returns
    -------
    pandas.DataFrame
        Columns: ``text_id`` (int), ``technique`` (str), ``original_score``
        (float), ``transformed_score`` (float), ``asr`` (bool — attack
        succeeded for this row). Row order: ``(technique, text_id)``
        nested.

    Examples
    --------
    >>> import numpy as np
    >>> from eval_toolkit.adversarial import sweep
    >>> class Detector:
    ...     def predict_proba(self, X):
    ...         return np.array([1.0 if "ignore" in t else 0.0 for t in X])
    >>> df = sweep(["ignore prior", "weather today"], Detector())  # doctest: +SKIP
    >>> df.groupby("technique")["asr"].mean().sort_index()  # doctest: +SKIP

    Notes
    -----
    The sweep performs ``len(texts) * (1 + len(techniques))`` scorer calls
    (one baseline + one per technique). For large corpora consider
    pre-computing the baseline scores once and passing a pre-thresholded
    subset of "originally-positive" texts (the ASR is only meaningful when
    ``s_orig >= threshold``).
    """
    import pandas as pd

    # Resolve techniques
    if isinstance(techniques, str):
        if techniques != "all":
            raise ValueError(
                f"sweep: techniques string must be 'all'; got {techniques!r}. "
                f"Pass an explicit sequence of CharacterInjectionStrategy "
                f"instances for custom configuration."
            )
        instances: list[CharacterInjectionStrategy] = [cls(seed=seed) for cls in CORE_TECHNIQUES]
    else:
        instances = list(techniques)
        if not instances:
            raise ValueError("sweep: techniques sequence is empty")

    # Baseline scores
    original_scores = np.asarray(scorer.predict_proba(list(texts))).astype(float)
    if original_scores.shape != (len(texts),):
        raise ValueError(
            f"sweep: scorer returned shape {original_scores.shape} for {len(texts)} inputs; "
            f"expected ({len(texts)},). Scorer must produce one P(positive) per input."
        )

    rows: list[dict[str, object]] = []
    for strategy in instances:
        transformed_texts = [strategy.transform(t) for t in texts]
        transformed_scores = np.asarray(scorer.predict_proba(transformed_texts)).astype(float)
        if transformed_scores.shape != (len(texts),):
            raise ValueError(
                f"sweep: scorer returned shape {transformed_scores.shape} for technique "
                f"{strategy.name!r}; expected ({len(texts)},)."
            )
        for i in range(len(texts)):
            orig = float(original_scores[i])
            adv = float(transformed_scores[i])
            asr = bool(orig >= threshold and adv < threshold)
            rows.append(
                {
                    "text_id": int(i),
                    "technique": strategy.name,
                    "original_score": orig,
                    "transformed_score": adv,
                    "asr": asr,
                }
            )
    return pd.DataFrame(
        rows, columns=["text_id", "technique", "original_score", "transformed_score", "asr"]
    )


# Wire sweep into the namespace now that it's defined
character_injection.sweep = sweep
