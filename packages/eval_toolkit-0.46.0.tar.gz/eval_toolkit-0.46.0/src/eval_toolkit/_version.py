"""Single lightweight version source."""

__all__ = ["__version__"]

__version__ = "0.46.0"
