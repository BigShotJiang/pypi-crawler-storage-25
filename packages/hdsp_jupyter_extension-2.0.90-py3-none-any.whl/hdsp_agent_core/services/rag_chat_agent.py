"""RAG Chat Agent — LangChain create_agent 기반 ReAct 에이전트.

chat mode에서 RAG 검색이 필요할 때 LLM이 자동으로 rag_search tool을 호출.
최대 2회 tool call, 스트리밍 지원.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Raw LLM 로깅 유틸리티
# ---------------------------------------------------------------------------

_LOG_DIR = Path("agent_logs")


def _get_raw_log_path() -> Path:
    """타임스탬프 기반 로그 파일 경로 반환."""
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return _LOG_DIR / f"raw_llm_{ts}.json"


def _is_raw_logging_enabled() -> bool:
    """config에서 rawLlmLogging 설정을 매번 확인 (핫리로드)."""
    try:
        from hdsp_agent_core.managers.config_manager import get_config_manager

        return bool(get_config_manager().get_config().get("rawLlmLogging", False))
    except Exception:
        return False


def _append_log(log_path: Path, entry: Dict[str, Any]) -> None:
    """JSON 배열에 엔트리 추가 (보기 좋은 포맷)."""
    try:
        entries: list = []
        if log_path.exists() and log_path.stat().st_size > 0:
            with open(log_path, "r", encoding="utf-8") as f:
                entries = json.load(f)
        entries.append(entry)
        with open(log_path, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, default=str, indent=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Harmony 토큰 필터 래퍼
# ---------------------------------------------------------------------------

# GPT-OSS harmony 특수 토큰 패턴
_HARMONY_TOKEN_RE = re.compile(
    r"<\|(?:start|end|message|channel|call|system|user|assistant|"
    r"analysis|commentary|final|functions?)\|>"
)
_HARMONY_BLOCK_RE = re.compile(r"<\|message\|>.*?<\|end\|>", re.DOTALL)


def _create_developer_role_middleware_class():
    """SystemMessage → developer role 변환 미들웨어.

    gpt-oss는 system role을 메타데이터로 취급하고,
    developer role을 최우선 지시사항으로 따른다.
    """
    from langchain.agents.middleware import AgentMiddleware

    class _DeveloperRole(AgentMiddleware):
        def before_model(self, state, runtime=None):  # noqa: ARG002
            from langchain_core.messages import ChatMessage

            messages = state.get("messages", [])
            if not messages:
                return None

            converted = []
            changed = False
            for msg in messages:
                if msg.type == "system":
                    converted.append(ChatMessage(role="developer", content=msg.content))
                    changed = True
                else:
                    converted.append(msg)

            return {"messages": converted} if changed else None

        async def abefore_model(self, state, runtime=None):  # noqa: ARG002
            return self.before_model(state, runtime)

    return _DeveloperRole


def _strip_harmony_tokens(text: str) -> str:
    """응답 텍스트에서 harmony 특수 토큰/블록을 제거."""
    if not text:
        return text
    # 전체 harmony 블록 제거 (tool call이 content에 섞인 경우)
    cleaned = _HARMONY_BLOCK_RE.sub("", text)
    # 잔여 개별 토큰 제거
    cleaned = _HARMONY_TOKEN_RE.sub("", cleaned)
    return cleaned.strip()


# 기존 chat 시스템 프롬프트 + RAG 가이드
_RAG_SYSTEM_PROMPT_ADDITION = """

## RAG 검색 도구

rag_search로 사내 데이터를 검색할 수 있습니다. 반드시 먼저 아래 컬렉션에서 정보를 획득한 후 응답을 생성하세요.

### 컬렉션
- **enterprise_tables**: 전사 테이블 메타데이터 (테이블/컬럼/스키마)
- **bdp_tables**: BDP 테이블 메타데이터 (쿼리 생성/검토 시 참조)
- **guide_docs**: BDP/bdpengine 가이드 (S3 접근 방법, Athena 쿼리 방법, Spark 활용 방법 등)
- **ds_guide_docs**: 데이터사이언스 가이드 (Pandas, PySpark 등)
- **codebase**: 사용자 코드베이스 (함수/클래스/메서드 검색)

### 도구 호출 규칙 (순서 엄수 — 반드시 load_skills → rag_search)
1. **먼저 `load_skills`**: 필요한 스킬을 쉼표로 모두 포함하여 **1회 호출**. 단, 이전 대화에서 이미 로드한 스킬은 재호출 금지.
   - **table_filter**: 테이블/컬럼/DB 검색 시 (pre-filtering 필드 확인)
   - **athena_sql**: Athena SQL 쿼리 작성/검토 시 (문법, 함수, Iceberg DML, 튜닝)
2. **그 다음 `rag_search`**: 필요한 쿼리를 모두 queries 배열에 담아 **반드시 1회만 호출**. rag_search를 여러 번 병렬 호출하지 마세요 — queries 배열 안에 여러 쿼리를 넣으면 내부에서 병렬 처리됩니다. load_skills 완료 전에 절대 호출하지 마세요.
3. 호출 후에는 **결과가 부족해도 가진 정보로 바로 답변**. 같은 주제로 재호출하지 마세요.
4. 결과가 0건일 때만 쿼리를 변경하여 1회 재시도를 허용합니다.
5. 일반 Python 문법, 수학 계산 등 RAG와 무관한 질문은 도구 없이 답변하세요.

### Python 코드 생성 시
- 반드시 guide_docs에서 관련 가이드를 먼저 검색한 후 코드를 작성하세요.
- 검색 없이 함수명이나 사용법을 추측하지 마세요.

### 검색 결과 사용 시 주의사항
- 테이블명, 컬럼명, 스키마명, 시스템명, 함수명 등 고유명사는 **RAG 검색 결과에 있는 값을 그대로** 사용하세요. 임의로 번역하거나 영문/한글로 치환하지 마세요.

### 도구 호출 시 주의사항 (매우 중요)
- 도구 호출(tool call)이 필요하면, content에는 반드시 "검색 중입니다"처럼 **한 줄 상태 메시지만** 넣으세요. 긴 설명이나 답변을 넣지 마세요.
"""


def _format_tool_status(queries_str: str) -> str:
    """tool_start 이벤트에서 사용자 친화적 상태 메시지 생성."""
    try:
        q_list = json.loads(queries_str) if queries_str else []
    except Exception:
        return "📚 지식 베이스 검색 중..."

    # codebase 컬렉션이 포함되어 있으면 코드 베이스 검색 표시
    has_codebase = any(
        isinstance(q, dict) and q.get("collection") == "codebase" for q in q_list
    )
    if has_codebase:
        return "📚 코드 베이스 검색 중..."

    # 쿼리 텍스트 추출
    queries = [
        q.get("query", "") for q in q_list if isinstance(q, dict) and q.get("query")
    ]
    if queries:
        q_text = ", ".join(f'"{q}"' for q in queries[:3])
        return f"📚 지식 베이스 검색 중... {q_text}"

    return "📚 지식 베이스 검색 중..."


class RAGChatAgent:
    """LangChain create_agent 기반 RAG chat agent.

    chat mode에서 RAG가 가용할 때 LLMService 대신 사용.
    rag_search 도구 1개로 ReAct loop (최대 2회 tool call).
    """

    def __init__(self, llm_config: Dict[str, Any], checkpointer=None):
        self._llm_config = llm_config
        self._checkpointer = checkpointer
        self._agent = None

    def _create_model(self):
        """vLLM 설정으로 LangChain ChatModel 생성."""
        from langchain.chat_models import init_chat_model

        cfg = self._llm_config.get("vllm", {})
        endpoint = cfg.get("endpoint", "").rstrip("/")
        if not endpoint.endswith("/v1"):
            endpoint += "/v1"

        return init_chat_model(
            f"openai:{cfg.get('model', 'default')}",
            base_url=endpoint,
            api_key=cfg.get("apiKey", ""),
            temperature=0.0,
            streaming=True,
            extra_body={"include_reasoning": False},
        )

    @staticmethod
    def _create_tools():
        """rag_search + load_skills 도구 생성."""
        from jupyter_ext.agent.langchain_tools import (
            create_enhanced_rag_search_tool,
            create_load_skills_tool,
        )

        return [create_enhanced_rag_search_tool(), create_load_skills_tool()]

    @staticmethod
    def _build_system_prompt() -> str:
        """관리자 커스텀 또는 기본 chat/rag 프롬프트를 결합."""
        base_prompt = ""
        rag_prompt = ""

        try:
            from hdsp_agent_core.managers.config_manager import get_config_manager

            prompts = get_config_manager().get_config().get("prompts", {})
            custom_base = prompts.get("chat_system_prompt")
            if custom_base and custom_base.strip():
                base_prompt = custom_base.strip()
            custom_rag = prompts.get("chat_rag_prompt")
            if custom_rag and custom_rag.strip():
                rag_prompt = custom_rag.strip()
        except Exception:
            pass

        if not base_prompt:
            from hdsp_agent_core.llm.service import _CHAT_SYSTEM_PROMPT

            base_prompt = _CHAT_SYSTEM_PROMPT

        if not rag_prompt:
            rag_prompt = _RAG_SYSTEM_PROMPT_ADDITION

        return base_prompt + "\n\n" + rag_prompt

    def _ensure_agent(self):
        """create_agent로 agent graph 생성 (lazy)."""
        if self._agent is not None:
            return

        from langchain.agents import create_agent
        from langchain.agents.middleware import (
            ModelRetryMiddleware,
            SummarizationMiddleware,
        )
        from langchain.agents.middleware.tool_call_limit import (
            ToolCallLimitMiddleware,
        )

        model = self._create_model()
        tools = self._create_tools()
        system_prompt = self._build_system_prompt()

        create_kwargs: Dict[str, Any] = dict(
            model=model,
            tools=tools,
            system_prompt=system_prompt,
            middleware=[
                _create_developer_role_middleware_class()(),
                ToolCallLimitMiddleware(
                    tool_name="rag_search",
                    run_limit=5,
                    exit_behavior="continue",
                ),
                ToolCallLimitMiddleware(
                    run_limit=15,
                    exit_behavior="continue",
                ),
                ModelRetryMiddleware(
                    max_retries=3,
                    backoff_factor=1.5,
                    initial_delay=0.3,
                    max_delay=30.0,
                ),
                SummarizationMiddleware(
                    model=model,
                    trigger=("tokens", 30000),
                    keep=("messages", 15),
                ),
            ],
        )
        if self._checkpointer is not None:
            create_kwargs["checkpointer"] = self._checkpointer
        self._agent = create_agent(**create_kwargs)

    async def stream_response(
        self,
        user_message: str,
        history_messages: Optional[List[Dict[str, str]]] = None,
        file_context: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Agent 응답을 스트리밍. SSE 호환 청크 yield.

        Args:
            history_messages: 첫 turn에만 전달 (checkpointer 미사용 또는 서버 재시작 후).
                checkpointer가 state를 유지하면 None으로 전달해 중복 방지.
            thread_id: checkpointer용 thread ID. conversation_id 사용 권장.

        Yields:
            {"content": str, "done": False} — LLM 토큰
            {"status": str, "icon": str, "done": False} — 도구 호출 상태
        """
        self._ensure_agent()

        from langchain_core.messages import AIMessage, HumanMessage

        # 메시지 구성
        messages = []
        if history_messages:
            for m in history_messages:
                if m["role"] == "user":
                    messages.append(HumanMessage(content=m["content"]))
                else:
                    messages.append(AIMessage(content=m["content"]))

        if file_context:
            messages.append(HumanMessage(content=f"[참고 컨텍스트]\n{file_context}"))

        messages.append(HumanMessage(content=user_message))

        input_dict = {"messages": messages}
        config: Dict[str, Any] = {"recursion_limit": 50}
        if thread_id:
            config["configurable"] = {"thread_id": thread_id}

        content_started = False
        tool_call_count = 0
        _pending_tool = False  # parallel tool call 방어: 첫 번째만 처리
        _content_buffer: list[str] = []  # LLM 턴별 content 버퍼 (할루시네이션 방지)
        _tool_processing = False  # tool call 실행 후 LLM 응답 대기 상태

        # Raw LLM 로깅 (핫리로드: 매 요청마다 config 확인)
        _raw_logging = _is_raw_logging_enabled()
        _raw_log_path: Optional[Path] = None
        if _raw_logging:
            _raw_log_path = _get_raw_log_path()
            _append_log(
                _raw_log_path,
                {
                    "type": "user_request",
                    "timestamp": datetime.now().isoformat(),
                    "thread_id": thread_id,
                    "system_prompt": self._build_system_prompt(),
                    "user_message": user_message,
                    "history_count": len(history_messages) if history_messages else 0,
                    "has_file_context": bool(file_context),
                    "file_context": file_context[:500] if file_context else None,
                    "input_messages": [
                        {"role": m.type, "content": m.content} for m in messages
                    ],
                },
            )

        print(f"[RAG] user_message: {user_message[:200]}", flush=True)

        try:
            async for event in self._agent.astream_events(
                input_dict, version="v2", config=config
            ):
                kind = event.get("event", "")

                if kind == "on_chat_model_stream":
                    chunk = event.get("data", {}).get("chunk")
                    if chunk and hasattr(chunk, "content") and chunk.content:
                        # GPT-OSS harmony 특수 토큰 필터링
                        text = chunk.content
                        if _HARMONY_TOKEN_RE.search(text):
                            text = _strip_harmony_tokens(text)
                            if not text:
                                continue

                        # 매 LLM 턴마다 버퍼링: tool call 오면 폐기, 안 오면 flush
                        _content_buffer.append(text)

                elif kind == "on_chat_model_end":
                    output = event.get("data", {}).get("output")
                    has_tc = bool(
                        output and hasattr(output, "tool_calls") and output.tool_calls
                    )
                    buf_len = len(_content_buffer)
                    buf_preview = (
                        "".join(_content_buffer)[:80] if _content_buffer else ""
                    )
                    print(
                        f"[RAG] chat_model_end: has_tool_calls={has_tc} "
                        f"buf={buf_len} "
                        f"preview={buf_preview!r}",
                        flush=True,
                    )
                    # tool call이 있는 턴: 버퍼 폐기 (할루시네이션)
                    # tool call이 없는 턴: 버퍼 flush (최종 답변)
                    if _content_buffer and has_tc:
                        print(
                            f"[RAG] discarding content with tool_calls: "
                            f"{buf_len} chunks",
                            flush=True,
                        )
                        _content_buffer.clear()
                    elif _content_buffer:
                        # tool call 후 LLM 응답 시작 → tool_processing 해제
                        if _tool_processing:
                            _tool_processing = False
                            yield {"tool_processing_end": True, "done": False}
                        for buffered in _content_buffer:
                            content_started = True
                            yield {"content": buffered, "done": False}
                        _content_buffer.clear()

                    # Raw LLM 로깅: LLM turn 종료 시 전체 응답 기록
                    if _raw_log_path:
                        output = event.get("data", {}).get("output")
                        log_entry: Dict[str, Any] = {
                            "type": "llm_response",
                            "timestamp": datetime.now().isoformat(),
                            "thread_id": thread_id,
                        }
                        if output and hasattr(output, "content"):
                            log_entry["content"] = output.content or None
                        if output and hasattr(output, "tool_calls"):
                            tc = output.tool_calls
                            if tc:
                                log_entry["tool_calls"] = [
                                    {"name": t.get("name"), "args": t.get("args")}
                                    for t in tc
                                ]
                        _append_log(_raw_log_path, log_entry)

                elif kind == "on_tool_start":
                    # tool call 발생: 버퍼에 쌓인 할루시네이션 content 폐기
                    if _content_buffer:
                        print(
                            f"[RAG] discarding buffered hallucination: "
                            f"{len(_content_buffer)} chunks",
                            flush=True,
                        )
                        _content_buffer.clear()
                    content_started = False

                    # parallel tool call 방어: 이미 tool 실행 중이면 스킵
                    if _pending_tool:
                        print(
                            f"[RAG] parallel tool call skipped: {event.get('name', '')}",
                            flush=True,
                        )
                        continue
                    _pending_tool = True
                    tool_call_count += 1
                    tool_name = event.get("name", "")
                    tool_input = event.get("data", {}).get("input", {})

                    if "skill" in tool_name.lower():
                        # Skill 로드 도구
                        skill_names = ""
                        if isinstance(tool_input, dict):
                            skill_names = tool_input.get("names", "")
                        elif isinstance(tool_input, str):
                            skill_names = tool_input
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): {tool_name}",
                            flush=True,
                        )
                        if skill_names:
                            yield {
                                "status": f"🔧 스킬 로딩: {skill_names}",
                                "icon": "search",
                                "done": False,
                            }
                    else:
                        # rag_search 도구
                        queries_str = ""
                        if isinstance(tool_input, dict):
                            queries_str = tool_input.get("queries", "")
                        elif isinstance(tool_input, str):
                            queries_str = tool_input
                        status_msg = _format_tool_status(queries_str)
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): "
                            f"input_type={type(tool_input).__name__} "
                            f"{queries_str[:200]}",
                            flush=True,
                        )
                        yield {
                            "status": status_msg,
                            "icon": "search",
                            "done": False,
                        }

                elif kind == "on_tool_end":
                    _pending_tool = False  # 다음 tool call 허용
                    tool_name = event.get("name", "")
                    output = event.get("data", {}).get("output", "")
                    if hasattr(output, "content"):
                        output = output.content

                    if "skill" in tool_name.lower():
                        # Skill 로드 완료 — 상태 메시지 없이 로깅만
                        print(f"[RAG] tool_end: {tool_name} loaded", flush=True)
                    else:
                        # rag_search 결과 — 상태 메시지 없이 로깅만
                        total = 0
                        try:
                            parsed = (
                                json.loads(output)
                                if isinstance(output, str)
                                else output
                            )
                            if isinstance(parsed, dict):
                                total = parsed.get("total", 0)
                        except Exception:
                            pass
                        print(f"[RAG] tool_end: total={total}", flush=True)

                        # tool 실행 완료 → LLM이 결과 분석 중 상태
                        if not _tool_processing:
                            _tool_processing = True
                            yield {"tool_processing": True, "done": False}

                        # Raw LLM 로깅: tool_call 결과 기록
                        if _raw_log_path:
                            _append_log(
                                _raw_log_path,
                                {
                                    "type": "tool_result",
                                    "timestamp": datetime.now().isoformat(),
                                    "thread_id": thread_id,
                                    "tool_name": tool_name,
                                    "total": total,
                                    "output": output[:2000]
                                    if isinstance(output, str)
                                    else str(output)[:2000],
                                },
                            )

        except Exception as e:
            import traceback

            err_msg = str(e)
            print(f"[RAG] ERROR: {err_msg}", flush=True)
            traceback.print_exc()

            if "recursion limit" in err_msg.lower():
                print("[RAG] Recursion limit — finishing gracefully", flush=True)
                if not content_started:
                    yield {
                        "content": "검색 결과를 바탕으로 답변을 준비했으나 "
                        "처리 한도에 도달했습니다. 질문을 더 구체적으로 "
                        "해주시면 정확한 답변을 드릴 수 있습니다.",
                        "done": False,
                    }
            else:
                yield {"error": f"RAG agent 오류: {err_msg}"}
