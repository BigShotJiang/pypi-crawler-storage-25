"use strict";
(self["webpackChunkhdsp_agent"] = self["webpackChunkhdsp_agent"] || []).push([["lib_index_js"],{

/***/ "./lib/components/AdminSettingsPanel.js"
/*!**********************************************!*\
  !*** ./lib/components/AdminSettingsPanel.js ***!
  \**********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AdminSettingsPanel: () => (/* binding */ AdminSettingsPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/icons-material/CheckCircle */ "./node_modules/@mui/icons-material/esm/CheckCircle.js");
/* harmony import */ var _mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/Error */ "./node_modules/@mui/icons-material/esm/Error.js");
/* harmony import */ var _mui_icons_material_HourglassEmpty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/HourglassEmpty */ "./node_modules/@mui/icons-material/esm/HourglassEmpty.js");
/* harmony import */ var _mui_icons_material_Code__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/icons-material/Code */ "./node_modules/@mui/icons-material/esm/Code.js");
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/icons-material/Search */ "./node_modules/@mui/icons-material/esm/Search.js");
/* harmony import */ var _mui_icons_material_Analytics__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/icons-material/Analytics */ "./node_modules/@mui/icons-material/esm/Analytics.js");
/* harmony import */ var _mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/icons-material/GpsFixed */ "./node_modules/@mui/icons-material/esm/GpsFixed.js");
/* harmony import */ var _mui_icons_material_ChatBubbleOutline__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @mui/icons-material/ChatBubbleOutline */ "./node_modules/@mui/icons-material/esm/ChatBubbleOutline.js");
/* harmony import */ var _mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @mui/icons-material/ExpandMore */ "./node_modules/@mui/icons-material/esm/ExpandMore.js");
/* harmony import */ var _mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @mui/icons-material/ChevronRight */ "./node_modules/@mui/icons-material/esm/ChevronRight.js");
/* harmony import */ var _services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../services/ApiKeyManager */ "./lib/services/ApiKeyManager.js");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_12__);
/**
 * Admin Settings Panel Component
 *
 * Comprehensive configuration for administrators:
 * - LLM Provider settings (vLLM / OpenAI-compatible endpoint)
 * - Summarization LLM settings
 * - Embedding configuration
 * - User preferences (also editable by admin)
 * - Agent prompts
 * - Server settings
 *
 * Note: RAG/Qdrant URL is configured in Agent Server only (not exposed in UI)
 */













// ---------------------------------------------------------------------------
// Codebase RAG Section
// ---------------------------------------------------------------------------
const CodebaseRagSection = ({ workspaceRoot }) => {
    const [status, setStatus] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [running, setRunning] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [progress, setProgress] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [autoWatch, setAutoWatch] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => {
        try {
            return localStorage.getItem('codebuff_codebase_autowatch') === 'true';
        }
        catch {
            return false;
        }
    });
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const prevPointsRef = react__WEBPACK_IMPORTED_MODULE_0___default().useRef(null);
    const baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_12__.URLExt.join(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_12__.PageConfig.getBaseUrl(), 'hdsp-agent');
    // 오른쪽 아래 팝업 알림
    const showToast = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((msg) => {
        const el = document.createElement('div');
        el.textContent = msg;
        el.style.cssText = `
      position: fixed; bottom: 20px; right: 20px; z-index: 10000;
      background: #1e293b; color: #fff; padding: 12px 20px;
      border-radius: 8px; font-size: 13px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      opacity: 0; transition: opacity 0.3s;
    `;
        document.body.appendChild(el);
        requestAnimationFrame(() => { el.style.opacity = '1'; });
        setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, 4000);
    }, []);
    const getHeaders = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        const value = `; ${document.cookie}`;
        const parts = value.split('; _xsrf=');
        const xsrf = parts.length === 2 ? parts.pop()?.split(';').shift() || '' : '';
        return { 'Content-Type': 'application/json', 'X-XSRFToken': xsrf };
    }, []);
    const fetchStatus = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        try {
            const res = await fetch(`${baseUrl}/rag/admin/codebase/status`);
            const data = await res.json();
            setStatus(data);
        }
        catch { /* ignore */ }
    }, [baseUrl]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        fetchStatus();
        // autoWatch가 true이고 workspaceRoot가 있으면 watcher 재시작
        if (autoWatch && workspaceRoot.trim()) {
            fetch(`${baseUrl}/rag/admin/codebase/watcher`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ rootDir: workspaceRoot, enabled: true }),
            }).catch(() => { });
        }
        // autoWatch 시 30초마다 polling → dirty 감지 → update 실행 → toast
        if (!autoWatch)
            return;
        let updating = false;
        const interval = setInterval(async () => {
            if (updating)
                return;
            try {
                const res = await fetch(`${baseUrl}/rag/admin/codebase/status`);
                const data = await res.json();
                // dirty 감지 → update 자동 실행
                if (data.dirty && workspaceRoot.trim()) {
                    updating = true;
                    const updateRes = await fetch(`${baseUrl}/rag/admin/codebase`, {
                        method: 'POST',
                        headers: getHeaders(),
                        body: JSON.stringify({ rootDir: workspaceRoot, action: 'update' }),
                    });
                    // SSE 응답 소비
                    const reader = updateRes.body?.getReader();
                    if (reader) {
                        const decoder = new TextDecoder();
                        let buf = '';
                        while (true) {
                            const { done, value } = await reader.read();
                            if (done)
                                break;
                            buf += decoder.decode(value, { stream: true });
                            for (const line of buf.split('\n')) {
                                if (!line.startsWith('data: '))
                                    continue;
                                try {
                                    const ev = JSON.parse(line.slice(6));
                                    if (ev.status === 'complete') {
                                        const parts = [];
                                        if (ev.added)
                                            parts.push(`추가 ${ev.added}`);
                                        if (ev.updated)
                                            parts.push(`수정 ${ev.updated}`);
                                        if (ev.deleted)
                                            parts.push(`삭제 ${ev.deleted}`);
                                        if (parts.length > 0) {
                                            showToast(`🔍 코드 증분 적재 완료: ${parts.join(', ')}`);
                                        }
                                    }
                                }
                                catch { /* ignore */ }
                            }
                            buf = '';
                        }
                    }
                    updating = false;
                    fetchStatus();
                }
                else {
                    setStatus(data);
                    prevPointsRef.current = data.total_points || 0;
                }
            }
            catch {
                updating = false;
            }
        }, 30000);
        return () => clearInterval(interval);
    }, [fetchStatus, autoWatch, workspaceRoot, baseUrl]);
    const runAction = async (action) => {
        if (!workspaceRoot.trim()) {
            setMessage('워크스페이스 경로를 먼저 입력하세요.');
            return;
        }
        if (action === 'delete') {
            setRunning(true);
            try {
                await fetch(`${baseUrl}/rag/admin/codebase`, {
                    method: 'POST',
                    headers: getHeaders(),
                    body: JSON.stringify({ rootDir: workspaceRoot, action: 'delete' }),
                });
                setMessage('코드베이스 RAG 삭제 완료');
                fetchStatus();
            }
            catch (e) {
                setMessage(`삭제 실패: ${e.message}`);
            }
            setRunning(false);
            return;
        }
        setRunning(true);
        setProgress(null);
        setMessage('');
        try {
            const response = await fetch(`${baseUrl}/rag/admin/codebase`, {
                method: 'POST',
                headers: getHeaders(),
                body: JSON.stringify({ rootDir: workspaceRoot, action }),
            });
            const reader = response.body?.getReader();
            if (!reader)
                return;
            const decoder = new TextDecoder();
            let buffer = '';
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (!line.startsWith('data: '))
                        continue;
                    try {
                        const data = JSON.parse(line.slice(6));
                        if (data.status === 'running') {
                            setProgress({ current: data.current, total: data.total });
                        }
                        else if (data.status === 'complete') {
                            const parts = [];
                            if (data.total_files)
                                parts.push(`${data.total_files}개 파일`);
                            if (data.total_chunks)
                                parts.push(`${data.total_chunks}개 청크`);
                            if (data.added !== undefined)
                                parts.push(`추가 ${data.added}, 수정 ${data.updated}, 삭제 ${data.deleted}`);
                            setMessage(`완료: ${parts.join(', ')}`);
                        }
                    }
                    catch { /* ignore */ }
                }
            }
        }
        catch (e) {
            setMessage(`실패: ${e.message}`);
        }
        finally {
            setRunning(false);
            setProgress(null);
            fetchStatus();
        }
    };
    const toggleWatcher = async () => {
        const newVal = !autoWatch;
        try {
            await fetch(`${baseUrl}/rag/admin/codebase/watcher`, {
                method: 'POST',
                headers: getHeaders(),
                body: JSON.stringify({ rootDir: workspaceRoot, enabled: newVal }),
            });
            setAutoWatch(newVal);
            try {
                localStorage.setItem('codebuff_codebase_autowatch', String(newVal));
            }
            catch { /* ignore */ }
        }
        catch { /* ignore */ }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-rag-section" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-rag-header" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-rag-title" }, "Codebase RAG"),
            status && status.indexed && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-rag-badge" },
                status.total_points.toLocaleString(),
                " points"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-rag-actions" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-admin-btn jp-admin-btn-primary", onClick: () => runAction('index'), disabled: running || !workspaceRoot.trim() }, running ? '실행 중...' : '전체 적재'),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-admin-btn", onClick: () => runAction('update'), disabled: running || !workspaceRoot.trim() }, "\uC99D\uBD84 \uC5C5\uB370\uC774\uD2B8"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-admin-btn jp-admin-btn-danger", onClick: () => runAction('delete'), disabled: running }, "\uC0AD\uC81C")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-rag-toggle" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: autoWatch, onChange: toggleWatcher }),
            "\uC790\uB3D9 \uC99D\uBD84 \uC801\uC7AC (30\uCD08 \uC8FC\uAE30)"),
        progress && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-rag-progress" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-rag-progress-bar" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-rag-progress-fill", style: { width: `${(progress.current / progress.total) * 100}%` } })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-rag-progress-text" },
                progress.current,
                "/",
                progress.total,
                " \uD30C\uC77C"))),
        message && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-rag-message" }, message))));
};
const AdminSettingsPanel = ({ onClose, onSave, apiService }) => {
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isSaving, setIsSaving] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Collapsible sections
    const [expandedSections, setExpandedSections] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        llm: true,
        summarization: false,
        embedding: false,
        user: true,
        server: false,
        prompts: false
    });
    // ═══════════════════════════════════════════════════════════════════════════
    // LLM Provider Settings (vLLM / OpenAI-compatible only)
    // ═══════════════════════════════════════════════════════════════════════════
    const [vllmEndpoint, setVllmEndpoint] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('https://openrouter.ai/api/v1');
    const [vllmApiKey, setVllmApiKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [vllmModel, setVllmModel] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('openai/gpt-4o');
    // ═══════════════════════════════════════════════════════════════════════════
    // Summarization LLM
    // ═══════════════════════════════════════════════════════════════════════════
    const [summarizationEnabled, setSummarizationEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [summarizationModel, setSummarizationModel] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [summarizationEndpoint, setSummarizationEndpoint] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [summarizationApiKey, setSummarizationApiKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    // ═══════════════════════════════════════════════════════════════════════════
    // Embedding Settings
    // ═══════════════════════════════════════════════════════════════════════════
    const [embeddingModel, setEmbeddingModel] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('text-embedding-3-small');
    const [embeddingApiKey, setEmbeddingApiKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [embeddingEndpoint, setEmbeddingEndpoint] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    // ═══════════════════════════════════════════════════════════════════════════
    // User Settings (also editable by admin)
    // ═══════════════════════════════════════════════════════════════════════════
    const [workspaceRoot, setWorkspaceRoot] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [temperature, setTemperature] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0.0);
    const [autoApprove, setAutoApprove] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // ═══════════════════════════════════════════════════════════════════════════
    // Server Settings
    // ═══════════════════════════════════════════════════════════════════════════
    const [idleTimeout, setIdleTimeout] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(3600); // Default: 1 hour
    const [rawLlmLogging, setRawLlmLogging] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // ═══════════════════════════════════════════════════════════════════════════
    // Agent Prompts
    // ═══════════════════════════════════════════════════════════════════════════
    const [agentPrompts, setAgentPrompts] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [expandedAgents, setExpandedAgents] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [defaultPrompts, setDefaultPrompts] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_11__.getCachedPrompts)());
    const [isLoadingPrompts, setIsLoadingPrompts] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(!(0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_11__.getCachedPrompts)());
    // Test state
    const [isTesting, setIsTesting] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [testResults, setTestResults] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    // ═══════════════════════════════════════════════════════════════════════════
    // Load Config
    // ═══════════════════════════════════════════════════════════════════════════
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        loadConfig();
        if (!defaultPrompts) {
            setIsLoadingPrompts(true);
            (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_11__.fetchDefaultPrompts)().then(prompts => {
                setDefaultPrompts(prompts);
                setIsLoadingPrompts(false);
            });
        }
    }, []);
    const loadConfig = async () => {
        try {
            setIsLoading(true);
            // LLM 설정: localStorage에서 우선 읽기 (admin mode)
            const savedLLM = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_11__.getAdminLLMConfig)();
            if (savedLLM) {
                setVllmEndpoint(savedLLM.vllm?.endpoint || 'https://openrouter.ai/api/v1');
                setVllmApiKey(savedLLM.vllm?.apiKey || '');
                setVllmModel(savedLLM.vllm?.model || 'openai/gpt-4o');
                setSummarizationEnabled(Boolean(savedLLM.summarization?.enabled));
                setSummarizationModel(savedLLM.summarization?.model || '');
                setSummarizationEndpoint(savedLLM.summarization?.endpoint || '');
                setSummarizationApiKey(savedLLM.summarization?.apiKey || '');
                setEmbeddingModel(savedLLM.embedding?.model || 'text-embedding-3-small');
                setEmbeddingApiKey(savedLLM.embedding?.apiKey || '');
                setEmbeddingEndpoint(savedLLM.embedding?.endpoint || '');
            }
            // 프롬프트/서버 설정: 서버에서 읽기
            const adminConfig = await apiService.getAdminConfig();
            // localStorage에 LLM 설정이 없으면 서버에서 읽기 (최초 마이그레이션)
            if (!savedLLM) {
                if (adminConfig.vllm) {
                    setVllmEndpoint(adminConfig.vllm.endpoint || 'https://openrouter.ai/api/v1');
                    setVllmApiKey(adminConfig.vllm.apiKey || '');
                    setVllmModel(adminConfig.vllm.model || 'openai/gpt-4o');
                }
                if (adminConfig.summarization) {
                    setSummarizationEnabled(Boolean(adminConfig.summarization.enabled));
                    setSummarizationModel(adminConfig.summarization.model || '');
                    setSummarizationEndpoint(adminConfig.summarization.endpoint || '');
                    setSummarizationApiKey(adminConfig.summarization.apiKey || '');
                }
                if (adminConfig.embedding) {
                    setEmbeddingModel(adminConfig.embedding.model || 'text-embedding-3-small');
                    setEmbeddingApiKey(adminConfig.embedding.apiKey || '');
                    setEmbeddingEndpoint(adminConfig.embedding.endpoint || '');
                }
            }
            // Server settings (always from server)
            setIdleTimeout(adminConfig.idleTimeout || 3600);
            setRawLlmLogging(Boolean(adminConfig.rawLlmLogging));
            // Prompts (always from server)
            if (adminConfig.prompts) {
                setAgentPrompts(adminConfig.prompts);
            }
            // Load user config
            const userConfig = await apiService.getUserConfig();
            setWorkspaceRoot(userConfig.workspaceRoot || '');
            setTemperature(userConfig.temperature ?? 0.0);
            setAutoApprove(Boolean(userConfig.autoApprove));
            setError(null);
        }
        catch (err) {
            setError(`설정을 불러오는데 실패했습니다: ${err}`);
        }
        finally {
            setIsLoading(false);
        }
    };
    // ═══════════════════════════════════════════════════════════════════════════
    // Save Config
    // ═══════════════════════════════════════════════════════════════════════════
    const handleSave = async () => {
        try {
            setIsSaving(true);
            // 1. LLM 설정 → localStorage (admin mode에서 브라우저에 저장)
            const llmConfig = {
                provider: 'vllm',
                vllm: {
                    endpoint: vllmEndpoint,
                    apiKey: vllmApiKey,
                    model: vllmModel
                },
                summarization: {
                    enabled: summarizationEnabled,
                    provider: 'vllm',
                    model: summarizationModel || undefined,
                    endpoint: summarizationEndpoint,
                    apiKey: summarizationApiKey
                },
                embedding: {
                    provider: 'vllm',
                    model: embeddingModel,
                    apiKey: embeddingApiKey || undefined,
                    endpoint: embeddingEndpoint
                },
                prompts: agentPrompts,
                idleTimeout
            };
            (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_11__.saveAdminLLMConfig)(llmConfig);
            console.log('[AdminSettingsPanel] LLM config saved to localStorage');
            // 2. 프롬프트/서버 설정 → 서버 (서버 파일에 저장)
            await apiService.updateAdminConfig({
                prompts: agentPrompts,
                idleTimeout,
                rawLlmLogging
            });
            // 3. User preferences → 서버 (기존 동작)
            await apiService.updateUserConfig({
                workspaceRoot: workspaceRoot.trim(),
                temperature,
                autoApprove
            });
            // Save user preferences to localStorage too
            const userPrefs = {
                workspaceRoot: workspaceRoot.trim(),
                autoApprove
            };
            (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_11__.saveLLMConfig)(userPrefs);
            onSave(llmConfig);
            onClose();
        }
        catch (err) {
            setError(`설정 저장에 실패했습니다: ${err}`);
        }
        finally {
            setIsSaving(false);
        }
    };
    // ═══════════════════════════════════════════════════════════════════════════
    // Helpers
    // ═══════════════════════════════════════════════════════════════════════════
    const toggleSection = (key) => {
        setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }));
    };
    const handleTest = async () => {
        setIsTesting(true);
        setTestResults({});
        setTestResults({ 0: vllmEndpoint ? 'success' : 'error' });
        setIsTesting(false);
    };
    const getTestStatusIcon = (index) => {
        const status = testResults[index];
        if (status === 'testing')
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_HourglassEmpty__WEBPACK_IMPORTED_MODULE_3__["default"], { sx: { fontSize: 16, color: 'info.main' } });
        if (status === 'success')
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_1__["default"], { sx: { fontSize: 16, color: 'success.main' } });
        if (status === 'error')
            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_2__["default"], { sx: { fontSize: 16, color: 'error.main' } });
        return null;
    };
    // ═══════════════════════════════════════════════════════════════════════════
    // Section Header Component
    // ═══════════════════════════════════════════════════════════════════════════
    const SectionHeader = ({ title, sectionKey, subtitle }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section-header", onClick: () => toggleSection(sectionKey) },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section-title" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-section-icon" }, expandedSections[sectionKey] ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_10__["default"], null)),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, title),
            subtitle && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-section-subtitle" }, subtitle))));
    // ═══════════════════════════════════════════════════════════════════════════
    // Render
    // ═══════════════════════════════════════════════════════════════════════════
    if (isLoading) {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-overlay" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-dialog jp-admin-dialog" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-content", style: { textAlign: 'center', padding: '40px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_HourglassEmpty__WEBPACK_IMPORTED_MODULE_3__["default"], { sx: { fontSize: 48, color: 'info.main' } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "\uC124\uC815\uC744 \uBD88\uB7EC\uC624\uB294 \uC911...")))));
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-overlay" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-dialog jp-admin-dialog" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null, "\uAD00\uB9AC\uC790 \uC124\uC815"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-close", onClick: onClose, title: "\uB2EB\uAE30" }, "\u00D7")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-content" },
                error && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-error" }, error)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SectionHeader, { title: "LLM \uC124\uC815", sectionKey: "llm", subtitle: "vLLM / OpenAI-compatible" }),
                    expandedSections.llm && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section-content" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" }, "API Base URL"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-admin-input", value: vllmEndpoint, onChange: (e) => setVllmEndpoint(e.target.value), placeholder: "https://openrouter.ai/api/v1" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" }, "API \uD0A4"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "password", className: "jp-admin-input", value: vllmApiKey, onChange: (e) => setVllmApiKey(e.target.value), placeholder: "sk-or-..." }),
                            getTestStatusIcon(0)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" }, "\uBAA8\uB378"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-admin-input", value: vllmModel, onChange: (e) => setVllmModel(e.target.value), placeholder: "openai/gpt-4o" }))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SectionHeader, { title: "\uC0AC\uC6A9\uC790 \uC124\uC815", sectionKey: "user", subtitle: "\uC6CC\uD06C\uC2A4\uD398\uC774\uC2A4, \uC628\uB3C4, \uC790\uB3D9 \uC2B9\uC778" }),
                    expandedSections.user && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section-content" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" },
                                "\uC6CC\uD06C\uC2A4\uD398\uC774\uC2A4 \uB8E8\uD2B8",
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-label-hint" }, "\uBE44\uC6B0\uBA74 \uD604\uC7AC \uB178\uD2B8\uBD81 \uD3F4\uB354 \uAE30\uC900")),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-admin-input", value: workspaceRoot, onChange: (e) => setWorkspaceRoot(e.target.value), placeholder: "/path/to/project" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(CodebaseRagSection, { workspaceRoot: workspaceRoot }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" },
                                "Temperature",
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-label-hint" }, "0.0 = \uACB0\uC815\uC801, 1.0+ = \uCC3D\uC758\uC801")),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-slider-row" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "range", min: 0, max: 2, step: 0.1, value: temperature, onChange: (e) => setTemperature(parseFloat(e.target.value)), className: "jp-admin-slider" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "number", className: "jp-admin-input jp-admin-input-small", value: temperature, onChange: (e) => setTemperature(Math.max(0, Math.min(2, parseFloat(e.target.value) || 0))), min: 0, max: 2, step: 0.1 }))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-checkbox" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: autoApprove, onChange: (e) => setAutoApprove(e.target.checked) }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "\uC790\uB3D9 \uC2E4\uD589 \uC2B9\uC778 (\uCF54\uB4DC/\uD30C\uC77C/\uC178 \uD3EC\uD568)")),
                            autoApprove && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-warning" }, "\uC8FC\uC758: \uC5D0\uC774\uC804\uD2B8\uAC00 \uC0DD\uC131\uD55C \uCF54\uB4DC\uAC00 \uC790\uB3D9\uC73C\uB85C \uC2E4\uD589\uB429\uB2C8\uB2E4.")))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SectionHeader, { title: "\uC694\uC57D\uC6A9 LLM", sectionKey: "summarization", subtitle: "\uB300\uD654 \uC555\uCD95 \uC2DC \uC0AC\uC6A9" }),
                    expandedSections.summarization && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section-content" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-checkbox" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: summarizationEnabled, onChange: (e) => setSummarizationEnabled(e.target.checked) }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "\uBCC4\uB3C4 LLM\uC73C\uB85C \uC694\uC57D \uC218\uD589 (\uBBF8\uC124\uC815 \uC2DC \uBA54\uC778 LLM \uC0AC\uC6A9)"))),
                        summarizationEnabled && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" }, "API Base URL"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-admin-input", value: summarizationEndpoint, onChange: (e) => setSummarizationEndpoint(e.target.value), placeholder: "\uBE44\uC6B0\uBA74 \uBA54\uC778 LLM \uC5D4\uB4DC\uD3EC\uC778\uD2B8 \uC0AC\uC6A9" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" }, "API \uD0A4"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "password", className: "jp-admin-input", value: summarizationApiKey, onChange: (e) => setSummarizationApiKey(e.target.value), placeholder: "\uBE44\uC6B0\uBA74 \uBA54\uC778 LLM API \uD0A4 \uC0AC\uC6A9" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" },
                                    "\uBAA8\uB378",
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-label-hint" }, "\uBE44\uC6B0\uBA74 \uAE30\uBCF8 \uBAA8\uB378 \uC0AC\uC6A9")),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-admin-input", value: summarizationModel, onChange: (e) => setSummarizationModel(e.target.value), placeholder: "openai/gpt-4o-mini" }))))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SectionHeader, { title: "\uC784\uBCA0\uB529 \uC124\uC815", sectionKey: "embedding", subtitle: "RAG \uBCA1\uD130 \uAC80\uC0C9\uC6A9" }),
                    expandedSections.embedding && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section-content" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" }, "API Base URL"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-admin-input", value: embeddingEndpoint, onChange: (e) => setEmbeddingEndpoint(e.target.value), placeholder: "\uBE44\uC6B0\uBA74 \uBA54\uC778 LLM \uC5D4\uB4DC\uD3EC\uC778\uD2B8 \uC0AC\uC6A9" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" }, "API \uD0A4"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "password", className: "jp-admin-input", value: embeddingApiKey, onChange: (e) => setEmbeddingApiKey(e.target.value), placeholder: "\uBE44\uC6B0\uBA74 \uBA54\uC778 LLM API \uD0A4 \uC0AC\uC6A9" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" }, "\uBAA8\uB378"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", className: "jp-admin-input", value: embeddingModel, onChange: (e) => setEmbeddingModel(e.target.value), placeholder: "text-embedding-3-small" }))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SectionHeader, { title: "\uC11C\uBC84 \uC124\uC815", sectionKey: "server", subtitle: "Idle \uD0C0\uC784\uC544\uC6C3, \uB85C\uAE45" }),
                    expandedSections.server && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section-content" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-label" },
                                "Idle Timeout (\uCD08)",
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-label-hint" }, "0 = \uBE44\uD65C\uC131\uD654, \uAE30\uBCF8\uAC12 3600\uCD08 (1\uC2DC\uAC04)")),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "number", className: "jp-admin-input jp-admin-input-small", value: idleTimeout, onChange: (e) => setIdleTimeout(Math.max(0, parseInt(e.target.value) || 0)), min: 0, max: 86400 })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-row" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-admin-checkbox" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: rawLlmLogging, onChange: (e) => setRawLlmLogging(e.target.checked) }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Raw LLM \uB85C\uAE45 (\uC0AC\uC6A9\uC790 \uC694\uCCAD + LLM \uC751\uB2F5\uC744 .agent_logs/ \uC5D0 \uAE30\uB85D)")))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(SectionHeader, { title: "\uC5D0\uC774\uC804\uD2B8 \uD504\uB86C\uD504\uD2B8", sectionKey: "prompts", subtitle: "\uC2DC\uC2A4\uD15C \uD504\uB86C\uD504\uD2B8 \uCEE4\uC2A4\uD130\uB9C8\uC774\uC9D5" }),
                    expandedSections.prompts && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-section-content" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-card" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-header", onClick: () => setExpandedAgents(prev => ({ ...prev, chat_system_prompt: !prev.chat_system_prompt })) },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-icon" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChatBubbleOutline__WEBPACK_IMPORTED_MODULE_8__["default"], { sx: { fontSize: 18 } })),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Chat \uBAA8\uB4DC \uC2DC\uC2A4\uD15C \uD504\uB86C\uD504\uD2B8"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-chevron" }, expandedAgents.chat_system_prompt ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_10__["default"], null))),
                            expandedAgents.chat_system_prompt && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-body" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-admin-textarea", value: agentPrompts.chat_system_prompt || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, chat_system_prompt: e.target.value })), placeholder: "\uBE44\uC5B4\uC788\uC73C\uBA74 \uAE30\uBCF8 Chat \uC2DC\uC2A4\uD15C \uD504\uB86C\uD504\uD2B8\uAC00 \uC0AC\uC6A9\uB429\uB2C8\uB2E4.", rows: 6 }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-admin-btn-reset", onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, chat_system_prompt: defaultPrompts.chat_system_prompt })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값 복원')))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-card" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-header", onClick: () => setExpandedAgents(prev => ({ ...prev, chat_rag_prompt: !prev.chat_rag_prompt })) },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-icon" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5__["default"], { sx: { fontSize: 18 } })),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "RAG \uAC80\uC0C9 \uAC00\uC774\uB4DC \uD504\uB86C\uD504\uD2B8"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-chevron" }, expandedAgents.chat_rag_prompt ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_10__["default"], null))),
                            expandedAgents.chat_rag_prompt && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-body" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-admin-textarea", value: agentPrompts.chat_rag_prompt || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, chat_rag_prompt: e.target.value })), placeholder: "\uBE44\uC5B4\uC788\uC73C\uBA74 \uAE30\uBCF8 RAG \uAC80\uC0C9 \uAC00\uC774\uB4DC\uAC00 \uC0AC\uC6A9\uB429\uB2C8\uB2E4.", rows: 8 }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-admin-btn-reset", onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, chat_rag_prompt: defaultPrompts.chat_rag_prompt })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값 복원')))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-card" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-header", onClick: () => setExpandedAgents(prev => ({ ...prev, planner: !prev.planner })) },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-icon" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_7__["default"], { sx: { fontSize: 18 } })),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Planner (Supervisor)"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-chevron" }, expandedAgents.planner ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_10__["default"], null))),
                            expandedAgents.planner && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-body" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-admin-textarea", value: agentPrompts.planner || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, planner: e.target.value })), rows: 6 }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-admin-btn-reset", onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, planner: defaultPrompts.planner })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값 복원')))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-card" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-header", onClick: () => setExpandedAgents(prev => ({ ...prev, python_developer: !prev.python_developer })) },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-icon" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Code__WEBPACK_IMPORTED_MODULE_4__["default"], { sx: { fontSize: 18 } })),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Python Developer"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-chevron" }, expandedAgents.python_developer ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_10__["default"], null))),
                            expandedAgents.python_developer && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-body" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-admin-textarea", value: agentPrompts.python_developer || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, python_developer: e.target.value })), rows: 6 }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-admin-btn-reset", onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, python_developer: defaultPrompts.python_developer })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값 복원')))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-card" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-header", onClick: () => setExpandedAgents(prev => ({ ...prev, researcher: !prev.researcher })) },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-icon" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5__["default"], { sx: { fontSize: 18 } })),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Researcher"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-chevron" }, expandedAgents.researcher ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_10__["default"], null))),
                            expandedAgents.researcher && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-body" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-admin-textarea", value: agentPrompts.researcher || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, researcher: e.target.value })), rows: 6 }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-admin-btn-reset", onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, researcher: defaultPrompts.researcher })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값 복원')))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-card" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-header", onClick: () => setExpandedAgents(prev => ({ ...prev, athena_query: !prev.athena_query })) },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-icon" },
                                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Analytics__WEBPACK_IMPORTED_MODULE_6__["default"], { sx: { fontSize: 18 } })),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Athena Query"),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-admin-prompt-chevron" }, expandedAgents.athena_query ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_9__["default"], null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_10__["default"], null))),
                            expandedAgents.athena_query && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-admin-prompt-body" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { className: "jp-admin-textarea", value: agentPrompts.athena_query || '', onChange: (e) => setAgentPrompts(prev => ({ ...prev, athena_query: e.target.value })), rows: 6 }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-admin-btn-reset", onClick: () => defaultPrompts && setAgentPrompts(prev => ({ ...prev, athena_query: defaultPrompts.athena_query })), disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '기본값 복원')))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { type: "button", className: "jp-admin-btn-reset-all", onClick: () => {
                                if (defaultPrompts) {
                                    setAgentPrompts({
                                        planner: defaultPrompts.planner,
                                        python_developer: defaultPrompts.python_developer,
                                        researcher: defaultPrompts.researcher,
                                        athena_query: defaultPrompts.athena_query,
                                    });
                                }
                            }, disabled: isLoadingPrompts }, isLoadingPrompts ? '로딩중...' : '모든 프롬프트 기본값 복원'))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-footer" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-secondary", onClick: onClose }, "\uCDE8\uC18C"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-test", onClick: handleTest, disabled: isTesting }, isTesting ? '테스트 중...' : 'API 테스트'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-primary", onClick: handleSave, disabled: isSaving }, isSaving ? '저장 중...' : '저장')))));
};


/***/ },

/***/ "./lib/components/AgentPanel.js"
/*!**************************************!*\
  !*** ./lib/components/AgentPanel.js ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AgentPanelWidget: () => (/* binding */ AgentPanelWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _SettingsPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SettingsPanel */ "./lib/components/SettingsPanel.js");
/* harmony import */ var _AdminSettingsPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./AdminSettingsPanel */ "./lib/components/AdminSettingsPanel.js");
/* harmony import */ var _UserSettingsPanel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./UserSettingsPanel */ "./lib/components/UserSettingsPanel.js");
/* harmony import */ var _services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/ApiKeyManager */ "./lib/services/ApiKeyManager.js");
/* harmony import */ var _utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../utils/markdownRenderer */ "./lib/utils/markdownRenderer.js");
/* harmony import */ var _FileSelectionDialog__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./FileSelectionDialog */ "./lib/components/FileSelectionDialog.js");
/* harmony import */ var _StreamingMessage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./StreamingMessage */ "./lib/components/StreamingMessage.js");
/* harmony import */ var _ContextAutocomplete__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./ContextAutocomplete */ "./lib/components/ContextAutocomplete.js");
/* harmony import */ var _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../services/AnalyticsService */ "./lib/services/AnalyticsService.js");
/* harmony import */ var _utils_icons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils/icons */ "./lib/utils/icons.js");
/* harmony import */ var _mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @mui/icons-material/ExpandLess */ "./node_modules/@mui/icons-material/esm/ExpandLess.js");
/* harmony import */ var _mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @mui/icons-material/ExpandMore */ "./node_modules/@mui/icons-material/esm/ExpandMore.js");
/* harmony import */ var _logoSvg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../logoSvg */ "./lib/logoSvg.js");
/**
 * Agent Panel - Main sidebar panel for Jupyter Agent
 * Cursor AI Style: Unified Chat + Agent Interface
 */



 // Fallback for legacy mode











// 로고 이미지 (SVG) - TypeScript 모듈에서 인라인 문자열로 import

// 탭바 아이콘 생성
const hdspTabIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({
    name: 'hdsp-agent:tab-icon',
    svgstr: _logoSvg__WEBPACK_IMPORTED_MODULE_15__.tabbarLogoSvg
});
// ═══════════════════════════════════════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════════════════════════════════════
const REVIEW_MAX_TOKENS = 8192;
// ═══════════════════════════════════════════════════════════════════════════
// Python 파일 에러 감지 및 처리 유틸리티
// ═══════════════════════════════════════════════════════════════════════════
// Python 에러 패턴 감지
const detectPythonError = (text) => {
    const errorPatterns = [
        /Traceback \(most recent call last\)/i,
        /SyntaxError:/i,
        /NameError:/i,
        /TypeError:/i,
        /ImportError:/i,
        /ModuleNotFoundError:/i,
        /AttributeError:/i,
        /ValueError:/i,
        /KeyError:/i,
        /IndexError:/i,
        /FileNotFoundError:/i,
        /File\s+"[^"]+\.py"/i,
    ];
    return errorPatterns.some(pattern => pattern.test(text));
};
// 에러 메시지에서 Python 파일 경로 추출
const extractFilePathsFromError = (text) => {
    const paths = [];
    // 패턴 1: python xxx.py 명령어
    const cmdMatch = text.match(/python\s+(\S+\.py)/gi);
    if (cmdMatch) {
        cmdMatch.forEach(match => {
            const pathMatch = match.match(/python\s+(\S+\.py)/i);
            if (pathMatch)
                paths.push(pathMatch[1]);
        });
    }
    // 패턴 2: File "xxx.py" 형식 (트레이스백)
    const fileMatches = text.matchAll(/File\s+"([^"]+\.py)"/gi);
    for (const match of fileMatches) {
        if (!paths.includes(match[1])) {
            paths.push(match[1]);
        }
    }
    return paths;
};
// 메인 파일 경로 추출 (명령어에서 실행한 파일)
const extractMainFilePath = (text) => {
    // python xxx.py 명령어에서 추출
    const cmdMatch = text.match(/python\s+(\S+\.py)/i);
    if (cmdMatch) {
        return cmdMatch[1];
    }
    return null;
};
// 에러가 발생한 실제 파일 추출 (트레이스백의 마지막 파일)
const extractErrorFilePath = (text) => {
    // File "xxx.py" 패턴들 중 마지막 것 (실제 에러 발생 위치)
    const fileMatches = [...text.matchAll(/File\s+"([^"]+\.py)"/gi)];
    if (fileMatches.length > 0) {
        return fileMatches[fileMatches.length - 1][1];
    }
    return null;
};
// Python 파일에서 로컬 import 추출
const extractLocalImports = (content) => {
    const imports = [];
    // from xxx import yyy (로컬 모듈)
    const fromImports = content.matchAll(/^from\s+(\w+)\s+import/gm);
    for (const match of fromImports) {
        const moduleName = match[1];
        // 표준 라이브러리가 아닌 것만 (간단한 휴리스틱)
        if (!isStdLibModule(moduleName)) {
            imports.push(moduleName);
        }
    }
    // import xxx (로컬 모듈)
    const directImports = content.matchAll(/^import\s+(\w+)/gm);
    for (const match of directImports) {
        const moduleName = match[1];
        if (!isStdLibModule(moduleName)) {
            imports.push(moduleName);
        }
    }
    return [...new Set(imports)];
};
// 표준 라이브러리 모듈 체크 (간단한 목록)
const isStdLibModule = (name) => {
    const stdLibModules = [
        'os', 'sys', 'json', 're', 'math', 'datetime', 'time', 'random',
        'collections', 'itertools', 'functools', 'typing', 'pathlib',
        'subprocess', 'threading', 'multiprocessing', 'asyncio', 'socket',
        'http', 'urllib', 'email', 'html', 'xml', 'logging', 'unittest',
        'io', 'pickle', 'copy', 'pprint', 'traceback', 'warnings',
        'contextlib', 'abc', 'dataclasses', 'enum', 'types',
        // 외부 라이브러리 (일반적으로 설치됨)
        'numpy', 'pandas', 'matplotlib', 'seaborn', 'sklearn', 'scipy',
        'torch', 'tensorflow', 'keras', 'requests', 'flask', 'django',
    ];
    return stdLibModules.includes(name.toLowerCase());
};
// ═══════════════════════════════════════════════════════════════════════════
// 코드리뷰 프롬프트 빌더 (모듈 레벨 - /review 및 analyzeFile 공용)
// ═══════════════════════════════════════════════════════════════════════════
const buildReviewPrompts = (content, totalItems) => {
    const commonRules = `
⚠️ 규칙:
- 코드를 표(table) 안에 넣지 마세요. 반드시 마크다운 코드 블록을 사용하세요.
- 각 관점 섹션의 코드 스니펫은 해당 부분만 발췌하세요.
- 섹션 제목은 반드시 프롬프트에 명시된 한국어 제목(### 보안, ### 성능, ### 코드 품질, ### 요약)을 그대로 사용하세요. 영어 제목이나 이모지를 섹션 제목에 사용하지 마세요.
- 이슈당 설명은 간결하게 작성하고, 개선 코드는 변경이 필요한 부분만 발췌하세요. 셀 전체 코드를 반복하지 마세요 (요약 섹션 제외).
`;
    const perspectives = [
        {
            label: '보안',
            prompt: `### 보안
금융권 규제 준수 및 정보 유출 사고 예방을 위해 보안 취약점을 점검합니다.
입력 검증 미비, SQL 인젝션, 파일 경로 조작, 민감 정보(고객 계좌·신용정보) 노출, 크리덴셜 하드코딩 등을 식별합니다.
해당 사항 없으면 "✅ 보안 이슈 없음"으로 넘어가세요.

⚠️ 검출 규칙:
- 하나의 셀에 여러 종류의 취약점이 있으면 각각 별도 항목(1-1, 1-2, ...)으로 분리하세요.
- 은닉/우회 패턴(변수 조합, 문자열 역순, ROT13, base64, 함수 기본 인자 등)은 패턴별로 개별 지적하세요.
- DataFrame에 PII 컬럼이 여러 개 있으면 모든 PII 컬럼을 나열하고 각각 마스킹/암호화 방안을 제시하세요.
- 개선 코드는 해당 취약점만 발췌하지 말고, 셀 전체의 개선 코드를 제시하세요.

발견 항목은 아래 형식을 따르세요:

#### 1-1. (이슈 제목)
**셀 N** | 문제에 대한 설명과 왜 개선이 필요한지 요약

\`\`\`python
# 개선 전
위험한_코드()

# 개선 후
안전한_코드()
\`\`\`
> 💡 **변경 내용**: 무엇을 왜 바꿨는지 한두 문장으로 설명`,
        },
        {
            label: '성능',
            prompt: `### 성능
{{RESOURCE_CONTEXT}}

반드시 "### 성능" 제목을 먼저 출력한 뒤, 실행 환경 정보가 제공된 경우 아래 배너를 그 다음에 출력하세요:
> **실행 환경**: (위에 제공된 환경 요약을 그대로 복사)

DS가 자주 겪는 OOM(Out-of-Memory) 방지, 전처리·학습 속도 개선, 컴퓨팅 리소스 최적 활용을 점검합니다.
불필요한 DataFrame 복사, 비효율적 dtypes, 중복 연산, 과도한 메모리 적재 등 실무에서 병목이 되는 패턴을 식별합니다.
**환경 기반 점검 가이드가 제공된 경우**, 해당 가이드에 명시된 기술 스택(pandas vs Polars vs Dask, joblib vs Ray, cuDF vs RAPIDS 등)을 기준으로 개선안을 제시하세요. 단순 파라미터 조정이 아닌, 환경 등급에 맞는 **기술 전환**(예: pandas→Polars, for루프→joblib 병렬처리, sklearn→cuML GPU 가속)을 우선 권장하세요.
해당 사항 없으면 다음 섹션으로 넘어가세요.

발견 항목은 아래 형식을 **반드시** 따르세요 (환경 근거와 예상 개선 수치 누락 시 불합격):

#### 2-1. (이슈 제목)
**셀 N** | 문제 설명. **현재 환경(CPU ○코어·RAM ○GB·GPU ○)에서는** 환경 가이드에 따라 ~~~기술이 적합하므로 ~~~. **예상 개선: 메모리 ~Y% 절감(OOM 위험 해소) / 처리 시간 ~X% 단축 / 리소스 사용량 N→M**

\`\`\`python
# 개선 전
비효율_코드()

# 개선 후
최적화_코드()
\`\`\`
> 💡 **변경 내용**: 무엇을 왜 바꿨는지 한두 문장으로 설명

**요약** 문단도 반드시 전체 개선 효과를 수치로 집계하세요 (예: "OOM 위험 구간 해소, 전처리 시간 ~40% 단축, 메모리 피크 ~X% 절감, GPU 활용률 N%→M%").`,
        },
        {
            label: '코드 품질',
            prompt: `### 코드 품질
분석 코드의 재현성·유지보수성을 높여 팀 생산성을 향상시키기 위해 점검합니다.
코드 구조, 일관성, 에러 처리, 변수명, 타입 힌트 등을 식별합니다.
해당 사항 없으면 "✅ 코드 품질 이슈 없음"으로 넘어가세요.

발견 항목은 아래 형식을 따르세요:

#### 3-1. (이슈 제목)
**셀 N** | 문제에 대한 설명과 왜 개선이 필요한지 요약

\`\`\`python
# 개선 전
나쁜_코드()

# 개선 후
좋은_코드()
\`\`\`
> 💡 **변경 내용**: 무엇을 왜 바꿨는지 한두 문장으로 설명`,
        },
        {
            label: '요약',
            prompt: `### 요약
- 보안·성능·품질 관점의 종합 평가 (한 문단)
- 비즈니스 임팩트가 큰 순서대로 시급한 개선 포인트 3가지
- 위 보안·성능·품질 섹션에서 수정이 제안된 **모든 셀**에 대해, 셀 번호 순서대로 전체 개선 코드를 제시:

#### 셀 N 개선 코드
\`\`\`python
(셀 전체를 개선한 완성 코드)
\`\`\`

⚠️ 각 셀의 개선 코드는 해당 셀의 전체 코드를 포함하세요. 하나의 셀에 여러 관점의 수정이 있으면 모두 통합하세요.
⚠️ 이전 분석 결과에서 언급된 셀을 빠뜨리지 마세요.`,
        },
    ];
    const estimatedTokens = Math.ceil(content.length / 3);
    let callPlan;
    if (estimatedTokens < 2000) {
        callPlan = [
            { displayLabel: '전체 코드리뷰', perspectiveIndices: [0, 1, 2, 3] },
        ];
    }
    else {
        callPlan = perspectives.map((p, i) => ({
            displayLabel: `코드리뷰: ${p.label}`,
            perspectiveIndices: [i],
        }));
    }
    console.log(`[AgentPanel] /review strategy: ${callPlan.length} call(s), ` +
        `estimated ~${estimatedTokens} input tokens, ${totalItems} items`);
    return { callPlan, perspectives, commonRules };
};
const ChatPanel = (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(({ apiService, notebookTracker, consoleTracker }, ref) => {
    // 통합 메시지 목록 (Chat + Agent 실행)
    const [messages, setMessages] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [input, setInput] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isStreaming, setIsStreaming] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [streamingMessageId, setStreamingMessageId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [conversationId, setConversationId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [showSettings, setShowSettings] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isAdmin, setIsAdmin] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null); // null = loading, false/true = resolved
    const [llmConfig, setLlmConfig] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Agent 실행 상태
    const [isAgentRunning, setIsAgentRunning] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Compact 압축 상태
    // 입력 모드 (Cursor AI 스타일) - 로컬 스토리지에서 복원
    // Note: 'agent_v2'는 'agent'로 마이그레이션
    const [inputMode, setInputMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(() => {
        try {
            const saved = localStorage.getItem('hdsp-agent-input-mode');
            if (saved === 'agent_v2')
                return 'agent'; // 마이그레이션
            return (saved === 'agent' || saved === 'chat') ? saved : 'agent'; // 기본값: agent
        }
        catch {
            return 'agent'; // 기본값: agent
        }
    });
    const [showModeDropdown, setShowModeDropdown] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // 파일 수정 관련 상태
    const [pendingFileFixes, setPendingFileFixes] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    // Console 에러 자동 감지 상태
    const [lastConsoleError, setLastConsoleError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [showConsoleErrorNotification, setShowConsoleErrorNotification] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // File selection state
    const [fileSelectionMetadata, setFileSelectionMetadata] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [pendingAgentRequest, setPendingAgentRequest] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Context autocomplete state (@file)
    const [showAutocomplete, setShowAutocomplete] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [hasAutocompleteOptions, setHasAutocompleteOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [cursorPosition, setCursorPosition] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const textareaRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    // Human-in-the-Loop state
    const [debugStatus, setDebugStatusRaw] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [isDebugExpanded, setIsDebugExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Chat mode: accumulated status lines (append mode for RAG search status)
    const chatStatusLinesRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
    // Tool processing state: LLM이 도구 호출 결과를 분석 중
    const [toolProcessing, setToolProcessing] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Minimum display time for status messages (2 seconds)
    const MIN_STATUS_DISPLAY_MS = 2000;
    const lastStatusTimeRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(0);
    const statusTimerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const pendingStatusRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    // Wrapper for setDebugStatus that ensures minimum 1 second display time
    const setDebugStatus = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((status) => {
        const now = Date.now();
        const timeSinceLastStatus = now - lastStatusTimeRef.current;
        // Clear any pending timer
        if (statusTimerRef.current) {
            clearTimeout(statusTimerRef.current);
            statusTimerRef.current = null;
        }
        // If clearing status (null), allow immediately
        if (status === null) {
            // If last status was shown recently, delay the clear
            if (timeSinceLastStatus < MIN_STATUS_DISPLAY_MS && lastStatusTimeRef.current > 0) {
                const delay = MIN_STATUS_DISPLAY_MS - timeSinceLastStatus;
                statusTimerRef.current = setTimeout(() => {
                    setDebugStatusRaw(null);
                    lastStatusTimeRef.current = 0;
                }, delay);
            }
            else {
                setDebugStatusRaw(null);
                lastStatusTimeRef.current = 0;
            }
            return;
        }
        // If previous status was shown recently, queue this status
        if (timeSinceLastStatus < MIN_STATUS_DISPLAY_MS && lastStatusTimeRef.current > 0) {
            const delay = MIN_STATUS_DISPLAY_MS - timeSinceLastStatus;
            pendingStatusRef.current = status;
            statusTimerRef.current = setTimeout(() => {
                if (pendingStatusRef.current !== null) {
                    setDebugStatusRaw(pendingStatusRef.current);
                    lastStatusTimeRef.current = Date.now();
                    pendingStatusRef.current = null;
                }
            }, delay);
        }
        else {
            // Show immediately
            setDebugStatusRaw(status);
            lastStatusTimeRef.current = now;
        }
    }, []);
    // Cleanup status timer on unmount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        return () => {
            if (statusTimerRef.current) {
                clearTimeout(statusTimerRef.current);
            }
        };
    }, []);
    const [interruptData, setInterruptData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Todo list state (from TodoListMiddleware)
    const [todos, setTodos] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [isTodoExpanded, setIsTodoExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    // When true, render in_progress todos as cancelled (survives late SSE overwrites)
    const [isTodoStopped, setIsTodoStopped] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Agent thread ID for context persistence across cycles (SummarizationMiddleware support)
    const [agentThreadId, setAgentThreadId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // AbortController for stopping long-running tasks
    const abortControllerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    // Rejection feedback mode - when user clicks reject, wait for optional feedback
    const [isRejectionMode, setIsRejectionMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [pendingRejectionInterrupt, setPendingRejectionInterrupt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Ask user mode - when ask_user_tool is called, wait for user input
    const [isAskUserMode, setIsAskUserMode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [pendingAskUserInterrupt, setPendingAskUserInterrupt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const interruptMessageIdRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const approvalPendingRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    const pendingToolCallsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
    const handledToolCallKeysRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(new Set());
    const isNotebookWidget = (widget) => {
        if (!widget)
            return false;
        if (widget instanceof _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookPanel)
            return true;
        const model = widget?.content?.model;
        return Boolean(model && (model.cells || model.sharedModel?.cells));
    };
    const getActiveNotebookPanel = () => {
        const app = window.jupyterapp;
        const currentWidget = app?.shell?.currentWidget;
        if (isNotebookWidget(currentWidget)) {
            return currentWidget;
        }
        return null;
    };
    /**
     * Strip ANSI escape codes from traceback strings
     */
    const stripAnsi = (str) => str.replace(/\x1b\[[0-9;]*m/g, '');
    /**
     * Resolve @notebook, @cell, @error mentions in message text.
     * Returns { resolvedMessage, displayMessage } where:
     * - displayMessage: original text shown to user
     * - resolvedMessage: text with mention content injected for LLM
     */
    const resolveMentions = async (message) => {
        let resolved = message;
        const notebook = getActiveNotebookPanel();
        // Helper: collect cell sources, tracking which are empty
        const collectCellSources = (cells) => {
            const parts = [];
            for (let i = 0; i < cells.length; i++) {
                const cell = cells.get(i);
                const source = cell.sharedModel?.getSource?.() || '';
                const cellType = cell.type || 'code';
                const execCount = cell.executionCount;
                const execLabel = execCount != null ? `, In[${execCount}]` : '';
                parts.push({
                    text: `# Cell ${i + 1} (${cellType}${execLabel}):\n${source}`,
                    sourceEmpty: source.trim() === ''
                });
            }
            return parts;
        };
        // === @notebook ===
        if (/@notebook\b/.test(resolved)) {
            let content;
            if (!notebook) {
                content = '[노트북이 열려있지 않습니다]';
            }
            else {
                const cells = notebook.content.model?.cells;
                if (!cells || cells.length === 0) {
                    content = '[노트북에 셀이 없습니다]';
                }
                else {
                    let parts = collectCellSources(cells);
                    // If most cells are empty, the notebook model may not be fully loaded yet — wait and retry
                    const emptyCells = parts.filter(p => p.sourceEmpty).length;
                    if (emptyCells > cells.length / 2 && cells.length > 1) {
                        console.warn(`[resolveMentions] ${emptyCells}/${cells.length} cells empty — waiting for model load`);
                        await new Promise(resolve => setTimeout(resolve, 500));
                        parts = collectCellSources(cells);
                        const retryEmpty = parts.filter(p => p.sourceEmpty).length;
                        console.log(`[resolveMentions] After retry: ${retryEmpty}/${cells.length} cells empty`);
                    }
                    content = parts.map(p => p.text).join('\n\n');
                }
            }
            resolved = resolved.replace(/@notebook\b/, `\n\n--- Current Notebook ---\n${content}\n--- End Notebook ---\n\n`);
        }
        // === @cell ===
        if (/@cell\b/.test(resolved)) {
            let content;
            if (!notebook) {
                content = '[노트북이 열려있지 않습니다]';
            }
            else {
                const activeCell = notebook.content.activeCell;
                if (!activeCell) {
                    content = '[선택된 셀이 없습니다]';
                }
                else {
                    const source = activeCell.model?.sharedModel?.getSource?.() || '';
                    const cellIndex = notebook.content.activeCellIndex + 1;
                    content = `# Cell ${cellIndex} (${activeCell.model?.type || 'code'}):\n${source}`;
                    // Include cell output if code cell
                    if (activeCell.model?.type === 'code') {
                        const outputs = activeCell.model?.outputs;
                        if (outputs && outputs.length > 0) {
                            const outputParts = [];
                            for (let i = 0; i < outputs.length; i++) {
                                const output = outputs.get(i);
                                if (output.type === 'stream') {
                                    const text = Array.isArray(output.text) ? output.text.join('') : output.text;
                                    outputParts.push(text);
                                }
                                else if (output.type === 'execute_result' || output.type === 'display_data') {
                                    const text = output.data?.['text/plain'];
                                    if (text)
                                        outputParts.push(Array.isArray(text) ? text.join('') : text);
                                }
                                else if (output.type === 'error') {
                                    if (Array.isArray(output.traceback)) {
                                        outputParts.push(output.traceback.map(stripAnsi).join('\n'));
                                    }
                                }
                            }
                            if (outputParts.length > 0) {
                                content += `\n\n# Output:\n${outputParts.join('\n')}`;
                            }
                        }
                    }
                }
            }
            resolved = resolved.replace(/@cell\b/, `\n\n--- Selected Cell ---\n${content}\n--- End Cell ---\n\n`);
        }
        // === @error ===
        if (/@error\b/.test(resolved)) {
            let content;
            if (!notebook) {
                content = '[노트북이 열려있지 않습니다]';
            }
            else {
                const cells = notebook.content.model?.cells;
                if (!cells || cells.length === 0) {
                    content = '[노트북에 셀이 없습니다]';
                }
                else {
                    // Find the most recent error by execution_count
                    let latestError = null;
                    for (let i = 0; i < cells.length; i++) {
                        const cell = cells.get(i);
                        if (cell.type !== 'code')
                            continue;
                        const execCount = cell.executionCount;
                        if (execCount == null)
                            continue;
                        const outputs = cell.outputs;
                        if (!outputs)
                            continue;
                        for (let j = 0; j < outputs.length; j++) {
                            const output = outputs.get(j);
                            if (output.type === 'error') {
                                if (!latestError || execCount > latestError.execCount) {
                                    latestError = {
                                        execCount,
                                        source: cell.sharedModel?.getSource?.() || '',
                                        ename: output.ename || 'Error',
                                        evalue: output.evalue || '',
                                        traceback: Array.isArray(output.traceback) ? output.traceback.map(stripAnsi) : [],
                                    };
                                }
                                break; // one error per cell is enough
                            }
                        }
                    }
                    if (!latestError) {
                        content = '[최근 에러가 없습니다]';
                    }
                    else {
                        content = `# Error Cell (In[${latestError.execCount}]):\n${latestError.source}\n\n# ${latestError.ename}: ${latestError.evalue}\n${latestError.traceback.join('\n')}`;
                    }
                }
            }
            resolved = resolved.replace(/@error\b/, `\n\n--- Recent Error ---\n${content}\n--- End Error ---\n\n`);
        }
        // === @bq-expert-agent ===
        if (/@bq-expert-agent\b/.test(resolved)) {
            resolved = resolved.replace(/@bq-expert-agent\b/, '');
            resolved = '[ROUTE:bq_agent] ' + resolved;
        }
        // === @airflow-expert-agent ===
        if (/@airflow-expert-agent\b/.test(resolved)) {
            resolved = resolved.replace(/@airflow-expert-agent\b/, '');
            resolved = '[ROUTE:airflow_expert] ' + resolved;
        }
        // === @athena-expert-agent ===
        if (/@athena-expert-agent\b/.test(resolved)) {
            resolved = resolved.replace(/@athena-expert-agent\b/, '');
            resolved = '[ROUTE:athena_query] ' + resolved;
        }
        // === @lambda-expert-agent ===
        if (/@lambda-expert-agent\b/.test(resolved)) {
            resolved = resolved.replace(/@lambda-expert-agent\b/, '');
            resolved = '[ROUTE:lambda_expert] ' + resolved;
        }
        // === @emr-expert-agent ===
        if (/@emr-expert-agent\b/.test(resolved)) {
            resolved = resolved.replace(/@emr-expert-agent\b/, '');
            resolved = '[ROUTE:emr_expert] ' + resolved;
        }
        // === @spring-expert-agent ===
        if (/@spring-expert-agent\b/.test(resolved)) {
            resolved = resolved.replace(/@spring-expert-agent\b/, '');
            resolved = '[ROUTE:spring_expert] ' + resolved;
        }
        return { resolvedMessage: resolved, displayMessage: message };
    };
    /**
     * Scroll notebook to show a specific cell
     */
    const scrollToNotebookCell = (notebook, cellIndex) => {
        try {
            const cell = notebook.content.widgets[cellIndex];
            if (cell?.node) {
                // Small delay to ensure the cell is rendered in DOM
                setTimeout(() => {
                    cell.node.scrollIntoView({
                        behavior: 'smooth',
                        block: 'center',
                    });
                }, 100);
            }
        }
        catch (error) {
            console.warn('[AgentPanel] Failed to scroll to cell:', error);
        }
    };
    const insertCell = (notebook, cellType, source) => {
        const model = notebook.content?.model;
        const cellCount = model?.cells?.length ?? model?.sharedModel?.cells?.length;
        if (!model?.sharedModel || cellCount === undefined) {
            console.warn('[AgentPanel] Notebook model not ready for insert');
            return null;
        }
        const insertIndex = cellCount;
        model.sharedModel.insertCell(insertIndex, {
            cell_type: cellType,
            source,
            metadata: { hdsp_agent_source: 'created' }
        });
        notebook.content.activeCellIndex = insertIndex;
        // Scroll to the newly inserted cell
        scrollToNotebookCell(notebook, insertIndex);
        return insertIndex;
    };
    // Insert cell above active cell
    const insertCellAbove = (notebook, source) => {
        const model = notebook.content?.model;
        if (!model?.sharedModel) {
            console.warn('[AgentPanel] Notebook model not ready for insertAbove');
            return null;
        }
        const activeIndex = notebook.content.activeCellIndex;
        const insertIndex = activeIndex >= 0 ? activeIndex : 0;
        model.sharedModel.insertCell(insertIndex, {
            cell_type: 'code',
            source,
            metadata: { hdsp_agent_source: 'created' }
        });
        notebook.content.activeCellIndex = insertIndex;
        // Scroll to the newly inserted cell
        scrollToNotebookCell(notebook, insertIndex);
        console.log('[AgentPanel] Inserted cell above at index:', insertIndex);
        return insertIndex;
    };
    // Insert cell below active cell
    const insertCellBelow = (notebook, source) => {
        const model = notebook.content?.model;
        const cellCount = model?.cells?.length ?? model?.sharedModel?.cells?.length;
        if (!model?.sharedModel || cellCount === undefined) {
            console.warn('[AgentPanel] Notebook model not ready for insertBelow');
            return null;
        }
        const activeIndex = notebook.content.activeCellIndex;
        const insertIndex = activeIndex >= 0 ? activeIndex + 1 : cellCount;
        model.sharedModel.insertCell(insertIndex, {
            cell_type: 'code',
            source,
            metadata: { hdsp_agent_source: 'created' }
        });
        notebook.content.activeCellIndex = insertIndex;
        // Scroll to the newly inserted cell
        scrollToNotebookCell(notebook, insertIndex);
        console.log('[AgentPanel] Inserted cell below at index:', insertIndex);
        return insertIndex;
    };
    // Callbacks for code block toolbar
    const handleInsertCodeAbove = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((code) => {
        const notebook = getActiveNotebookPanel();
        if (notebook) {
            insertCellAbove(notebook, code);
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('code_insert_from_agent', {
                position: 'above',
                code_length: code.length,
                code_lines: code.split('\n').length,
            });
        }
        else {
            console.warn('[AgentPanel] No active notebook for insert above');
        }
    }, []);
    const handleInsertCodeBelow = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((code) => {
        const notebook = getActiveNotebookPanel();
        if (notebook) {
            insertCellBelow(notebook, code);
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('code_insert_from_agent', {
                position: 'below',
                code_length: code.length,
                code_lines: code.split('\n').length,
            });
        }
        else {
            console.warn('[AgentPanel] No active notebook for insert below');
        }
    }, []);
    const handleInsertCodeAsCell = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((code) => {
        const notebook = getActiveNotebookPanel();
        if (notebook) {
            insertCell(notebook, 'code', code);
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('code_insert_from_agent', {
                position: 'new_cell',
                code_length: code.length,
                code_lines: code.split('\n').length,
            });
        }
        else {
            console.warn('[AgentPanel] No active notebook for insert as cell');
        }
    }, []);
    const deleteCell = (notebook, cellIndex) => {
        const model = notebook.content?.model;
        const cellCount = model?.cells?.length ?? model?.sharedModel?.cells?.length;
        if (!model?.sharedModel || cellCount === undefined) {
            console.warn('[AgentPanel] Notebook model not ready for delete');
            return false;
        }
        if (cellIndex < 0 || cellIndex >= cellCount) {
            console.warn('[AgentPanel] Invalid cell index for delete:', cellIndex);
            return false;
        }
        model.sharedModel.deleteCell(cellIndex);
        console.log('[AgentPanel] Deleted rejected cell at index:', cellIndex);
        return true;
    };
    const executeCell = async (notebook, cellIndex) => {
        try {
            await notebook.sessionContext.ready;
            notebook.content.activeCellIndex = cellIndex;
            // Scroll to the cell being executed
            scrollToNotebookCell(notebook, cellIndex);
            await _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.NotebookActions.run(notebook.content, notebook.sessionContext);
            // Wait for IOPub outputs to propagate to cell model.
            // execute_reply arrives before error/stream outputs in some cases.
            await waitForCellOutputs(notebook, cellIndex);
        }
        catch (error) {
            console.error('[AgentPanel] Cell execution failed:', error);
        }
    };
    /**
     * Poll cell model until outputs appear or timeout.
     * Needed because NotebookActions.run resolves on execute_reply,
     * but IOPub error/stream outputs may arrive slightly later.
     */
    const waitForCellOutputs = (notebook, cellIndex, maxWaitMs = 2000, intervalMs = 100) => {
        return new Promise((resolve) => {
            const cell = notebook.content.widgets[cellIndex];
            const model = cell?.model;
            if (!model) {
                resolve();
                return;
            }
            // If outputs already present, resolve immediately
            const outputs = model.outputs;
            if (outputs && outputs.length > 0) {
                resolve();
                return;
            }
            // If execution count is set and no outputs, the cell completed with no output
            const execCount = model.executionCount;
            if (execCount !== null && execCount !== undefined) {
                // Give a brief grace period for late-arriving outputs
                setTimeout(resolve, 150);
                return;
            }
            // Poll for outputs
            let elapsed = 0;
            const timer = setInterval(() => {
                elapsed += intervalMs;
                const currentOutputs = model.outputs;
                const currentExecCount = model.executionCount;
                if ((currentOutputs && currentOutputs.length > 0) || elapsed >= maxWaitMs || (currentExecCount !== null && currentExecCount !== undefined)) {
                    clearInterval(timer);
                    // Brief grace period after first output appears (more may follow)
                    setTimeout(resolve, 100);
                }
            }, intervalMs);
        });
    };
    const captureExecutionResult = (notebook, cellIndex) => {
        const cell = notebook.content.widgets[cellIndex];
        const model = cell?.model;
        const outputs = model?.outputs;
        const rawState = model?.executionState;
        const executionState = typeof rawState === 'string'
            ? rawState
            : rawState?.get?.() ?? rawState?.value ?? null;
        const result = {
            success: true,
            output: '',
            error: undefined,
            error_type: undefined,
            traceback: undefined,
            execution_count: model?.executionCount ?? null,
            execution_state: executionState,
            kernel_status: notebook.sessionContext?.session?.kernel?.status ?? null,
            cell_type: model?.type ?? null,
            outputs: [],
        };
        if (!outputs || outputs.length === 0) {
            return result;
        }
        const stripImageData = (data) => {
            const filtered = {};
            Object.keys(data || {}).forEach((key) => {
                if (!key.toLowerCase().startsWith('image/')) {
                    filtered[key] = data[key];
                }
            });
            return filtered;
        };
        const errorSignatures = [
            'command not found',
            'ModuleNotFoundError',
            'No module named',
            'Traceback (most recent call last)',
            'Error:',
        ];
        for (let i = 0; i < outputs.length; i++) {
            const output = outputs.get(i);
            const json = output.toJSON?.() || output;
            let sanitizedOutput = json;
            if (output.type === 'error') {
                result.outputs.push(sanitizedOutput);
                result.success = false;
                result.error_type = json.ename;
                result.error = json.evalue;
                if (Array.isArray(json.traceback)) {
                    result.traceback = json.traceback;
                }
            }
            else if (output.type === 'stream' && json.text) {
                result.outputs.push(sanitizedOutput);
                result.output += json.text;
                const lowerText = json.text.toLowerCase();
                if (errorSignatures.some(signature => lowerText.includes(signature.toLowerCase()))) {
                    result.success = false;
                    result.error_type = 'runtime_error';
                    result.error = json.text.trim();
                }
            }
            else if ((output.type === 'execute_result' || output.type === 'display_data') && json.data) {
                const filteredData = stripImageData(json.data);
                if (Object.keys(filteredData).length > 0) {
                    sanitizedOutput = { ...json, data: filteredData };
                    result.outputs.push(sanitizedOutput);
                    result.output += JSON.stringify(filteredData);
                }
            }
        }
        return result;
    };
    const executePendingApproval = async () => {
        const notebook = getActiveNotebookPanel();
        if (!notebook) {
            console.warn('[AgentPanel] No active notebook to execute cell');
            return null;
        }
        const pending = pendingToolCallsRef.current;
        if (pending.length === 0) {
            approvalPendingRef.current = false;
            return null;
        }
        const next = pending.shift();
        if (!next) {
            approvalPendingRef.current = false;
            return null;
        }
        if (next.tool === 'jupyter_cell' && next.code && typeof next.cellIndex === 'number') {
            await executeCell(notebook, next.cellIndex);
            const execResult = captureExecutionResult(notebook, next.cellIndex);
            execResult.code = next.code;
            next.execution_result = execResult;
            console.log('[AgentPanel] Executed approved code cell from tool call');
            approvalPendingRef.current = pendingToolCallsRef.current.length > 0;
            return next;
        }
        approvalPendingRef.current = pendingToolCallsRef.current.length > 0;
        return next;
    };
    const getAutoApproveEnabled = (config) => (Boolean(config?.autoApprove));
    /**
     * Get effective LLM config for agent requests.
     * Admin mode: merges AdminLLMConfig (localStorage) into user config.
     * Normal mode: returns user config as-is (backend reads env vars).
     */
    const getEffectiveLLMConfig = () => {
        const base = llmConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getDefaultLLMConfig)();
        if (isAdmin) {
            const adminLLM = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getAdminLLMConfig)();
            if (adminLLM) {
                return { ...base, ...adminLLM };
            }
        }
        return base;
    };
    const queueApprovalCell = (code) => {
        const notebook = getActiveNotebookPanel();
        if (!notebook) {
            console.warn('[AgentPanel] No active notebook to add approval cell');
            return;
        }
        const key = `jupyter_cell:${code}`;
        if (handledToolCallKeysRef.current.has(key)) {
            return;
        }
        const index = insertCell(notebook, 'code', code);
        if (index === null) {
            return;
        }
        handledToolCallKeysRef.current.add(key);
        approvalPendingRef.current = true;
        pendingToolCallsRef.current.push({ tool: 'jupyter_cell', code, cellIndex: index });
        console.log('[AgentPanel] Added code cell pending approval via interrupt');
    };
    const handleToolCall = (toolCall) => {
        const key = `${toolCall.tool}:${toolCall.code || toolCall.content || ''}`;
        if (handledToolCallKeysRef.current.has(key)) {
            return;
        }
        if (toolCall.tool === 'jupyter_cell') {
            return;
        }
        if (toolCall.tool === 'jupyter_markdown' && (toolCall.content || toolCall.code)) {
            const notebook = getActiveNotebookPanel();
            if (!notebook) {
                console.warn('[AgentPanel] No active notebook to add markdown');
                return;
            }
            const markdownContent = toolCall.content || toolCall.code || '';
            const index = insertCell(notebook, 'markdown', markdownContent);
            if (index !== null) {
                handledToolCallKeysRef.current.add(key);
                console.log('[AgentPanel] Added markdown cell from tool call');
            }
        }
    };
    // 모드 변경 시 로컬 스토리지에 저장
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        try {
            localStorage.setItem('hdsp-agent-input-mode', inputMode);
        }
        catch {
            // 로컬 스토리지 접근 불가 시 무시
        }
    }, [inputMode]);
    const messagesContainerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const messagesEndRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const pendingLlmPromptRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const pendingMaxTokensRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(undefined);
    const allCodeBlocksRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
    const currentCellIdRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const currentCellIndexRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const makeMessageId = (suffix) => {
        const base = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        return suffix ? `${base}-${suffix}` : base;
    };
    // Expose handleSendMessage via ref
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useImperativeHandle)(ref, () => ({
        handleSendMessage: async () => {
            await handleSendMessage();
        },
        setInput: (value) => {
            setInput(value);
        },
        setLlmPrompt: (prompt) => {
            pendingLlmPromptRef.current = prompt;
            // Find textarea and set data attribute
            const textarea = messagesEndRef.current?.parentElement?.querySelector('.jp-agent-input');
            if (textarea) {
                textarea.setAttribute('data-llm-prompt', prompt);
            }
        },
        setMaxTokens: (tokens) => {
            pendingMaxTokensRef.current = tokens;
        },
        setCurrentCellId: (cellId) => {
            console.log('[AgentPanel] setCurrentCellId called with:', cellId);
            currentCellIdRef.current = cellId;
        },
        setCurrentCellIndex: (cellIndex) => {
            console.log('[AgentPanel] setCurrentCellIndex called with:', cellIndex);
            currentCellIndexRef.current = cellIndex;
        },
        setInputMode: (mode) => {
            console.log('[AgentPanel] setInputMode called with:', mode);
            setInputMode(mode);
        },
        sendChatMessage: async (opts) => {
            return await sendChatMessage(opts);
        },
        addAssistantMessage: (content) => {
            const msg = {
                id: makeMessageId('review-intro'),
                role: 'assistant',
                content,
                timestamp: Date.now(),
            };
            setMessages(prev => [...prev, msg]);
        },
    }));
    // Load config and check admin mode on mount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        loadConfig();
        // Check admin mode for settings panel selection
        const checkAdminMode = async () => {
            try {
                const result = await apiService.checkIsAdmin();
                setIsAdmin(result.isAdmin);
                console.log('[AgentPanel] Admin mode check:', result.isAdmin, result.reason);
            }
            catch (err) {
                console.warn('[AgentPanel] Failed to check admin mode, defaulting to user mode:', err);
                setIsAdmin(false); // Default to user mode on error
            }
        };
        checkAdminMode();
    }, []);
    // Force chat mode for non-admin users (agent mode is admin-only for now)
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (isAdmin === false && inputMode !== 'chat') {
            console.log('[AgentPanel] Non-admin user detected, forcing chat mode');
            setInputMode('chat');
        }
    }, [isAdmin]);
    // Reset expand state when debug status changes
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        setIsDebugExpanded(false);
    }, [debugStatus]);
    // ═══════════════════════════════════════════════════════════════════════════
    // Console 출력 모니터링 - Python 에러 자동 감지
    // ═══════════════════════════════════════════════════════════════════════════
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!consoleTracker) {
            console.log('[AgentPanel] ConsoleTracker not available');
            return;
        }
        console.log('[AgentPanel] Setting up console output monitoring');
        // Console 출력에서 에러 감지하는 함수
        const checkConsoleForErrors = () => {
            const currentConsole = consoleTracker.currentWidget;
            if (!currentConsole) {
                return;
            }
            try {
                // Console의 출력 영역에서 텍스트 추출
                const consoleNode = currentConsole.node;
                if (!consoleNode)
                    return;
                // JupyterLab Console의 출력은 .jp-OutputArea-output 클래스에 있음
                const outputAreas = consoleNode.querySelectorAll('.jp-OutputArea-output');
                if (outputAreas.length === 0)
                    return;
                // 최근 출력만 확인 (마지막 몇 개)
                const recentOutputs = Array.from(outputAreas).slice(-5);
                let combinedOutput = '';
                recentOutputs.forEach((output) => {
                    const text = output.textContent || '';
                    combinedOutput += text + '\n';
                });
                // Python 에러 감지
                if (detectPythonError(combinedOutput)) {
                    console.log('[AgentPanel] Python error detected in console output');
                    // 중복 알림 방지
                    if (lastConsoleError !== combinedOutput) {
                        setLastConsoleError(combinedOutput);
                        setShowConsoleErrorNotification(true);
                        // 5초 후 자동으로 알림 숨기기
                        setTimeout(() => {
                            setShowConsoleErrorNotification(false);
                        }, 10000);
                    }
                }
            }
            catch (e) {
                console.error('[AgentPanel] Error checking console output:', e);
            }
        };
        // MutationObserver로 Console 출력 변경 감지
        let observer = null;
        const setupObserver = () => {
            const currentConsole = consoleTracker.currentWidget;
            if (!currentConsole?.node)
                return;
            // 기존 observer 정리
            if (observer) {
                observer.disconnect();
            }
            observer = new MutationObserver((mutations) => {
                // 출력 영역에 변화가 있으면 에러 체크
                const hasOutputChange = mutations.some(mutation => mutation.type === 'childList' ||
                    (mutation.type === 'characterData'));
                if (hasOutputChange) {
                    // 약간의 딜레이 후 체크 (출력이 완전히 렌더링될 때까지)
                    setTimeout(checkConsoleForErrors, 100);
                }
            });
            // Console 전체를 관찰
            observer.observe(currentConsole.node, {
                childList: true,
                subtree: true,
                characterData: true
            });
            console.log('[AgentPanel] MutationObserver set up for console');
        };
        // 현재 Console에 observer 설정
        setupObserver();
        // Console 변경 시 observer 재설정
        const onConsoleChanged = () => {
            console.log('[AgentPanel] Console changed, re-setting up observer');
            setupObserver();
        };
        consoleTracker.currentChanged?.connect(onConsoleChanged);
        // Cleanup
        return () => {
            if (observer) {
                observer.disconnect();
            }
            consoleTracker.currentChanged?.disconnect(onConsoleChanged);
        };
    }, [consoleTracker, lastConsoleError]);
    // Remove lastActiveNotebook state - just use currentWidget directly
    const loadConfig = () => {
        // Load from localStorage using ApiKeyManager
        const config = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getLLMConfig)();
        if (!config) {
            console.log('[AgentPanel] No config in localStorage, using default');
            const defaultConfig = (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getDefaultLLMConfig)();
            setLlmConfig(defaultConfig);
            return;
        }
        setLlmConfig(config);
        // Log loaded user preferences (LLM settings now come from server AdminConfig)
        console.log('=== HDSP Agent User Preferences (localStorage) ===');
        console.log('Workspace Root:', config.workspaceRoot || '(default)');
        console.log('Auto Approve:', config.autoApprove ? '✓ Enabled' : '✗ Disabled');
        console.log('Note: LLM settings are managed by Agent Server AdminConfig');
        console.log('====================================================');
    };
    // ═══════════════════════════════════════════════════════════════════════════
    // Python 파일 에러 수정 관련 함수들
    // ═══════════════════════════════════════════════════════════════════════════
    // JupyterLab Contents API를 통해 파일 내용 로드
    const loadFileContent = async (filePath) => {
        try {
            // PageConfig에서 base URL 가져오기
            const { PageConfig, URLExt } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
            const baseUrl = PageConfig.getBaseUrl();
            const apiUrl = URLExt.join(baseUrl, 'api/contents', filePath);
            console.log('[AgentPanel] Loading file:', filePath, 'from:', apiUrl);
            const response = await fetch(apiUrl, {
                method: 'GET',
                credentials: 'include',
            });
            if (!response.ok) {
                console.warn('[AgentPanel] Failed to load file:', filePath, response.status);
                return null;
            }
            const data = await response.json();
            return data.content;
        }
        catch (error) {
            console.error('[AgentPanel] Error loading file:', filePath, error);
            return null;
        }
    };
    // 파일에 수정된 코드 저장
    const saveFileContent = async (filePath, content) => {
        try {
            const { PageConfig, URLExt } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
            const baseUrl = PageConfig.getBaseUrl();
            const apiUrl = URLExt.join(baseUrl, 'api/contents', filePath);
            console.log('[AgentPanel] Saving file:', filePath);
            const response = await fetch(apiUrl, {
                method: 'PUT',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    type: 'file',
                    format: 'text',
                    content: content,
                }),
            });
            if (!response.ok) {
                console.error('[AgentPanel] Failed to save file:', filePath, response.status);
                return false;
            }
            console.log('[AgentPanel] File saved successfully:', filePath);
            return true;
        }
        catch (error) {
            console.error('[AgentPanel] Error saving file:', filePath, error);
            return false;
        }
    };
    // Python 에러 메시지 처리 및 파일 수정 요청
    // Returns true if handled, false if should fall back to regular chat
    const handlePythonErrorFix = async (errorMessage) => {
        console.log('[AgentPanel] Handling Python error fix request');
        // 1. 에러가 발생한 파일 경로 추출
        const errorFilePath = extractErrorFilePath(errorMessage);
        const mainFilePath = extractMainFilePath(errorMessage);
        const allFilePaths = extractFilePathsFromError(errorMessage);
        console.log('[AgentPanel] Error file:', errorFilePath);
        console.log('[AgentPanel] Main file:', mainFilePath);
        console.log('[AgentPanel] All files:', allFilePaths);
        if (!errorFilePath && !mainFilePath) {
            // 파일 경로를 찾을 수 없으면 일반 채팅으로 처리
            console.log('[AgentPanel] No file path found, falling back to regular chat stream');
            return false;
        }
        // 2. 주요 파일 내용 로드
        const targetFile = errorFilePath || mainFilePath;
        const mainContent = await loadFileContent(targetFile);
        if (!mainContent) {
            console.warn('[AgentPanel] Could not load file content for:', targetFile);
            // 파일을 읽을 수 없으면 에러 메시지만으로 처리 시도
            const errorOnlyRequest = {
                action: 'fix',
                mainFile: { path: targetFile, content: '(파일 읽기 실패)' },
                errorOutput: errorMessage,
            };
            try {
                const result = await apiService.fileAction(errorOnlyRequest);
                handleFileFixResponse(result.response, result.fixedFiles);
            }
            catch (error) {
                console.error('[AgentPanel] File fix API error:', error);
                addErrorMessage('파일 수정 요청 실패: ' + error.message);
            }
            return true; // Handled (even if failed)
        }
        // 3. 관련 파일들 (imports) 로드
        const localImports = extractLocalImports(mainContent);
        const relatedFiles = [];
        // 에러 메시지에 언급된 다른 파일들도 로드
        for (const path of allFilePaths) {
            if (path !== targetFile) {
                const content = await loadFileContent(path);
                if (content) {
                    relatedFiles.push({ path, content });
                }
            }
        }
        // 로컬 import 파일들도 로드
        const baseDir = targetFile.includes('/') ? targetFile.substring(0, targetFile.lastIndexOf('/')) : '';
        for (const moduleName of localImports) {
            const modulePath = baseDir ? `${baseDir}/${moduleName}.py` : `${moduleName}.py`;
            if (!allFilePaths.includes(modulePath) && !relatedFiles.some(f => f.path === modulePath)) {
                const content = await loadFileContent(modulePath);
                if (content) {
                    relatedFiles.push({ path: modulePath, content });
                }
            }
        }
        console.log('[AgentPanel] Related files loaded:', relatedFiles.length);
        // 4. 파일 수정 API 호출
        const request = {
            action: 'fix',
            mainFile: { path: targetFile, content: mainContent },
            errorOutput: errorMessage,
            relatedFiles: relatedFiles.length > 0 ? relatedFiles : undefined,
        };
        try {
            setIsLoading(true);
            const result = await apiService.fileAction(request);
            handleFileFixResponse(result.response, result.fixedFiles);
            return true; // Successfully handled
        }
        catch (error) {
            console.error('[AgentPanel] File fix API error:', error);
            addErrorMessage('파일 수정 요청 실패: ' + error.message);
            return true; // Handled (even if failed)
        }
        finally {
            setIsLoading(false);
        }
    };
    // 파일 수정 응답 처리
    const handleFileFixResponse = (response, fixedFiles) => {
        console.log('[AgentPanel] File fix response received, fixed files:', fixedFiles.length);
        // Assistant 메시지로 응답 표시
        const assistantMessage = {
            id: makeMessageId('file-fix'),
            role: 'assistant',
            content: response,
            timestamp: Date.now(),
            metadata: { type: 'file_fix', fixedFiles },
        };
        setMessages(prev => [...prev, assistantMessage]);
        // 수정된 파일이 있으면 상태에 저장 (적용 버튼용)
        if (fixedFiles.length > 0) {
            setPendingFileFixes(fixedFiles);
        }
    };
    // 수정된 파일 적용
    const applyFileFix = async (fix) => {
        console.log('[AgentPanel] Applying fix to file:', fix.path);
        const success = await saveFileContent(fix.path, fix.content);
        if (success) {
            // 성공 메시지
            const successMessage = {
                id: makeMessageId('apply-success'),
                role: 'assistant',
                content: `✅ **${fix.path}** 파일이 수정되었습니다.\n\n파일 에디터에서 변경사항을 확인하세요.`,
                timestamp: Date.now(),
            };
            setMessages(prev => [...prev, successMessage]);
            // 적용된 파일은 pending에서 제거
            setPendingFileFixes(prev => prev.filter(f => f.path !== fix.path));
        }
        else {
            addErrorMessage(`파일 저장 실패: ${fix.path}`);
        }
    };
    // 에러 메시지 추가 헬퍼
    const addErrorMessage = (message) => {
        const errorMessage = {
            id: makeMessageId('error'),
            role: 'assistant',
            content: `⚠️ ${message}`,
            timestamp: Date.now(),
        };
        setMessages(prev => [...prev, errorMessage]);
    };
    const handleSaveConfig = (config) => {
        console.log('[AgentPanel] Saving user preferences to localStorage');
        console.log('Workspace Root:', config.workspaceRoot || '(default)');
        console.log('Auto Approve:', config.autoApprove ? '✓ Enabled' : '✗ Disabled');
        // Save to localStorage using ApiKeyManager
        (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.saveLLMConfig)(config);
        // Update state
        setLlmConfig(config);
        console.log('[AgentPanel] User preferences saved successfully');
    };
    // File selection handlers (simplified - old agent mode removed)
    const handleFileSelect = async (index) => {
        console.log('[AgentPanel] File selected:', index);
        if (!fileSelectionMetadata || !pendingAgentRequest) {
            console.error('[AgentPanel] Missing file selection metadata or pending request');
            return;
        }
        const selectedFile = fileSelectionMetadata.options[index - 1];
        if (!selectedFile) {
            console.error('[AgentPanel] Invalid file selection index:', index);
            return;
        }
        console.log('[AgentPanel] Selected file:', selectedFile.path);
        setFileSelectionMetadata(null);
        setPendingAgentRequest(null);
        setIsAgentRunning(false);
    };
    const handleFileSelectCancel = () => {
        console.log('[AgentPanel] File selection cancelled');
        setFileSelectionMetadata(null);
        setPendingAgentRequest(null);
        setIsAgentRunning(false);
    };
    /**
     * Stop the currently running task.
     * This will:
     * 1. Abort any ongoing fetch requests
     * 2. Interrupt the Jupyter kernel if a cell is executing
     * 3. Reset all loading/running states
     * 4. Enable the input box for new commands
     */
    const stopCurrentTask = async () => {
        console.log('[AgentPanel] Stopping current task...');
        // 1. Mark todos as stopped — rendering will show in_progress as cancelled
        setIsTodoStopped(true);
        // 2. Abort any ongoing fetch requests
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            abortControllerRef.current = null;
            console.log('[AgentPanel] Aborted fetch request');
        }
        // 2. Cancel the server-side agent execution
        if (agentThreadId) {
            try {
                const result = await apiService.cancelAgent(agentThreadId);
                console.log('[AgentPanel] Server-side agent cancel result:', result);
            }
            catch (error) {
                console.warn('[AgentPanel] Error cancelling server-side agent:', error);
            }
        }
        // 3. Interrupt the Jupyter kernel if executing (try all possible kernels)
        try {
            // Try notebook kernel first
            const notebook = notebookTracker?.currentWidget;
            if (notebook?.sessionContext?.session?.kernel) {
                const kernel = notebook.sessionContext.session.kernel;
                console.log('[AgentPanel] Notebook kernel status:', kernel.status);
                // Always try to interrupt - don't check status first
                // Shell commands may show different status
                await kernel.interrupt();
                console.log('[AgentPanel] Interrupted notebook kernel');
            }
            // Also try console kernel if available
            if (consoleTracker?.currentWidget?.sessionContext?.session?.kernel) {
                const consoleKernel = consoleTracker.currentWidget.sessionContext.session.kernel;
                console.log('[AgentPanel] Console kernel status:', consoleKernel.status);
                await consoleKernel.interrupt();
                console.log('[AgentPanel] Interrupted console kernel');
            }
        }
        catch (error) {
            console.warn('[AgentPanel] Failed to interrupt kernel:', error);
        }
        // 4. Reset all states
        setIsLoading(false);
        setIsStreaming(false);
        setIsAgentRunning(false);
        setStreamingMessageId(null);
        setInterruptData(null);
        setIsRejectionMode(false);
        setPendingRejectionInterrupt(null);
        // Reset thread ID so new task starts fresh
        setAgentThreadId(null);
        // 6. Update current in_progress todo to show it was stopped
        setTodos(prev => prev.map(todo => todo.status === 'in_progress'
            ? { ...todo, status: 'cancelled' }
            : todo));
        // Show notification
        showNotification('작업이 중단되었습니다.', 'info');
        console.log('[AgentPanel] Task stopped successfully');
    };
    // Interval-based auto-scroll during streaming
    const scrollIntervalRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const container = messagesContainerRef.current;
        if (!container)
            return;
        if (isStreaming) {
            // 스트리밍 중: 1.5초마다 맨 아래로 스크롤 (사용자가 하단 근처에 있을 때만)
            scrollIntervalRef.current = setInterval(() => {
                const distanceFromBottom = container.scrollHeight - container.scrollTop - container.clientHeight;
                if (distanceFromBottom < 1000) {
                    container.scrollTop = container.scrollHeight;
                }
            }, 1000);
        }
        else {
            // 스트리밍 종료: interval 해제 후 최종 스크롤
            if (scrollIntervalRef.current) {
                clearInterval(scrollIntervalRef.current);
                scrollIntervalRef.current = null;
            }
            setTimeout(() => {
                if (container) {
                    container.scrollTop = container.scrollHeight;
                }
            }, 100);
        }
        return () => {
            if (scrollIntervalRef.current) {
                clearInterval(scrollIntervalRef.current);
                scrollIntervalRef.current = null;
            }
        };
    }, [isStreaming]);
    const handleNextItemSelection = async (nextText) => {
        const trimmed = nextText.trim();
        if (!trimmed)
            return;
        // Check if there's a pending interrupt (HITL approval waiting)
        const hasPendingInterrupt = interruptData !== null;
        // Check if all todos are completed
        const allTodosCompleted = todos.length === 0 || todos.every(t => t.status === 'completed');
        // Block if there's a pending interrupt OR if agent is running with incomplete todos
        // Allow if all todos are completed even if streaming is finishing up
        if (hasPendingInterrupt || (isAgentRunning && !allTodosCompleted)) {
            showNotification('다른 작업이 진행 중입니다. 완료 후 다시 시도해주세요.', 'warning');
            return;
        }
        await sendChatMessage({
            displayContent: trimmed,
            clearInput: true
        });
    };
    const sendChatMessage = async ({ displayContent, llmPrompt, textarea, clearInput = true, maxTokens, freshConversation = false, }) => {
        const displayContentText = displayContent || (llmPrompt ? '셀 분석 요청' : '');
        if (!displayContentText && !llmPrompt)
            return;
        // Analytics: C5/C6 - track chat/agent send
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick(inputMode === 'chat' ? 'chat_send' : 'agent_send', { input_mode: inputMode, prompt: displayContentText });
        // Build effective config (admin: merges localStorage LLM settings)
        const currentConfig = getEffectiveLLMConfig();
        // Get user preferences (API keys are now managed by Agent Server)
        const autoApproveEnabled = getAutoApproveEnabled(currentConfig);
        const userMessage = {
            id: makeMessageId(),
            role: 'user',
            content: displayContentText,
            timestamp: Date.now()
        };
        setMessages(prev => [...prev, userMessage]);
        // 메시지 추가 즉시 스크롤을 최하단으로
        requestAnimationFrame(() => {
            const container = messagesContainerRef.current;
            if (container)
                container.scrollTop = container.scrollHeight;
        });
        if (clearInput && displayContentText) {
            setInput('');
        }
        setIsLoading(true);
        setIsStreaming(true);
        setIsTodoStopped(false);
        // Clear todos only when starting a new task (all completed or no todos)
        // Keep todos if there are pending/in_progress items (continuation of current task)
        const hasActiveTodos = todos.some(t => t.status === 'pending' || t.status === 'in_progress');
        if (!hasActiveTodos) {
            setTodos([]);
        }
        setDebugStatus(null);
        chatStatusLinesRef.current = [];
        // Clear the data attribute and ref after using it
        if (llmPrompt) {
            pendingLlmPromptRef.current = null;
            if (textarea) {
                textarea.removeAttribute('data-llm-prompt');
            }
        }
        // Create assistant message ID for streaming updates
        const assistantMessageId = makeMessageId('assistant');
        let streamedContent = '';
        setStreamingMessageId(assistantMessageId);
        // Add empty assistant message that will be updated during streaming
        const initialAssistantMessage = {
            id: assistantMessageId,
            role: 'assistant',
            content: '',
            timestamp: Date.now()
        };
        setMessages(prev => [...prev, initialAssistantMessage]);
        try {
            // Use LLM prompt if available, otherwise use the display content
            // Resolve @notebook, @cell, @error mentions (inject notebook context into message)
            const rawMessage = llmPrompt || displayContentText;
            const { resolvedMessage } = await resolveMentions(rawMessage);
            const messageToSend = resolvedMessage;
            // Chat 모드: 단순 Q&A (sendChatStream)
            // Agent V2 모드 또는 그 외: LangChain Deep Agent (sendAgentV2Stream)
            if (inputMode === 'chat') {
                // 단순 Chat 모드 - /chat/stream 사용
                // Create AbortController for chat streaming
                abortControllerRef.current = new AbortController();
                const maxTokensOverride = maxTokens || pendingMaxTokensRef.current;
                pendingMaxTokensRef.current = undefined;
                await apiService.sendChatStream({
                    message: messageToSend,
                    conversationId: freshConversation ? undefined : (conversationId || undefined),
                    llmConfig: currentConfig,
                    ...(maxTokensOverride ? { maxTokens: maxTokensOverride } : {})
                }, 
                // onChunk callback
                (chunk) => {
                    // content_clear: tool call 시 이전 할루시네이션 content 초기화
                    if (chunk === '__content_clear__') {
                        streamedContent = '';
                        setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                            ? { ...msg, content: '' }
                            : msg));
                        return;
                    }
                    // tool processing 시그널 처리
                    if (chunk === '__tool_processing__') {
                        setToolProcessing(true);
                        return;
                    }
                    if (chunk === '__tool_processing_end__') {
                        setToolProcessing(false);
                        return;
                    }
                    streamedContent += chunk;
                    setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                        ? { ...msg, content: streamedContent }
                        : msg));
                }, 
                // onMetadata callback
                (metadata) => {
                    if (!freshConversation && metadata.conversationId && !conversationId) {
                        setConversationId(metadata.conversationId);
                    }
                }, 
                // AbortSignal for stopping the stream
                abortControllerRef.current.signal, 
                // onDebug callback for status messages (RAG search status, etc.)
                (status) => {
                    // Handle __clear__ sentinel: reset accumulated lines and clear status
                    const statusText = typeof status === 'string' ? status : status.status;
                    if (statusText === '__clear__') {
                        chatStatusLinesRef.current = [];
                        setDebugStatusRaw(null);
                        return;
                    }
                    // "지식 베이스 검색 중..." / "코드 베이스 검색 중..." 패턴은 replace (중복 방지)
                    const isSearchStatus = statusText.includes('지식 베이스 검색 중') || statusText.includes('코드 베이스 검색 중');
                    if (isSearchStatus) {
                        // 기존 검색 상태 라인을 제거하고 새 것으로 교체
                        chatStatusLinesRef.current = [
                            ...chatStatusLinesRef.current.filter(line => !line.includes('지식 베이스 검색 중') && !line.includes('코드 베이스 검색 중')),
                            statusText
                        ];
                    }
                    else {
                        chatStatusLinesRef.current = [...chatStatusLinesRef.current, statusText];
                    }
                    setDebugStatusRaw(chatStatusLinesRef.current.join('\n'));
                });
            }
            else {
                // Agent V2 모드 - /agent/langchain/stream 사용 (HITL, Todo, 도구 실행)
                // Agent V2 모드용 AbortController 생성
                abortControllerRef.current = new AbortController();
                await apiService.sendAgentV2Stream({
                    message: messageToSend,
                    conversationId: freshConversation ? undefined : (conversationId || undefined),
                    llmConfig: currentConfig // Include API keys with request
                }, 
                // onChunk callback - update message content incrementally
                (chunk) => {
                    streamedContent += chunk;
                    setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                        ? { ...msg, content: streamedContent }
                        : msg));
                }, 
                // onMetadata callback - update conversationId and metadata
                (metadata) => {
                    if (!freshConversation && metadata.conversationId && !conversationId) {
                        setConversationId(metadata.conversationId);
                    }
                    if (metadata.provider || metadata.model) {
                        setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                            ? {
                                ...msg,
                                metadata: {
                                    ...msg.metadata,
                                    provider: metadata.provider,
                                    model: metadata.model
                                }
                            }
                            : msg));
                    }
                }, 
                // onDebug callback - show debug status in gray
                (status) => {
                    setDebugStatus(status);
                }, 
                // onInterrupt callback - show approval dialog
                (interrupt) => {
                    approvalPendingRef.current = true;
                    // Capture threadId from interrupt for context persistence
                    if (interrupt.threadId && !agentThreadId) {
                        setAgentThreadId(interrupt.threadId);
                        console.log('[AgentPanel] Captured agentThreadId from interrupt:', interrupt.threadId);
                    }
                    // Auto-approve search/file/resource tools - execute immediately without user interaction
                    if (interrupt.action === 'search_notebook_cells_tool'
                        || interrupt.action === 'check_resource_tool'
                        || interrupt.action === 'read_file_tool'
                        || interrupt.action === 'list_workspace_tool'
                        || interrupt.action === 'search_files_tool') {
                        void handleAutoToolInterrupt(interrupt);
                        return;
                    }
                    // Auto-approve jupyter_cell READ operations (non-destructive, no user approval needed)
                    if (interrupt.action === 'jupyter_cell_tool' && interrupt.args?.operation === 'READ') {
                        console.log('[AgentPanel] Auto-approving jupyter_cell READ operation');
                        resumeFromInterrupt(interrupt, 'approve').catch(err => {
                            console.error('[AgentPanel] jupyter_cell READ auto-approve FAILED:', err);
                        });
                        return;
                    }
                    // Handle ask_user_tool - show input UI instead of approval dialog
                    if (interrupt.action === 'ask_user_tool') {
                        console.log('[AgentPanel] ask_user_tool interrupt:', interrupt.args);
                        setIsAskUserMode(true);
                        setPendingAskUserInterrupt(interrupt);
                        setIsLoading(false);
                        setIsStreaming(false);
                        // Display the question as an assistant message
                        const question = interrupt.args?.question || '응답을 입력하세요...';
                        const options = interrupt.args?.options;
                        const inputType = interrupt.args?.input_type || 'text';
                        let questionContent = `❓ **${question}**`;
                        if (options && options.length > 0) {
                            questionContent += '\n\n선택지:\n' + options.map((opt, i) => `${i + 1}. ${opt}`).join('\n');
                        }
                        if (inputType === 'file') {
                            questionContent += '\n\n_(파일을 업로드하거나 파일 경로를 입력하세요)_';
                        }
                        const askUserMessage = {
                            id: makeMessageId('ask_user'),
                            role: 'assistant',
                            content: questionContent,
                            timestamp: Date.now(),
                        };
                        setMessages(prev => [...prev, askUserMessage]);
                        // Focus on input for user to provide response
                        setTimeout(() => {
                            const textarea = document.querySelector('.jp-agent-input');
                            if (textarea) {
                                textarea.focus();
                                textarea.placeholder = question;
                            }
                        }, 100);
                        return;
                    }
                    if (autoApproveEnabled) {
                        // 자동 승인 모드일 때도 인터럽트 메시지를 생성하여 코드블럭으로 표시
                        upsertInterruptMessage(interrupt, true);
                        // jupyter_cell_tool인 경우 먼저 셀 생성 후 승인 진행
                        if (interrupt.action === 'jupyter_cell_tool' && interrupt.args?.code) {
                            const shouldQueue = shouldExecuteInNotebook(interrupt.args.code);
                            console.log('[AgentPanel] AUTO-APPROVE jupyter_cell_tool: shouldQueue=', shouldQueue, 'code=', interrupt.args.code.slice(0, 80));
                            if (shouldQueue) {
                                queueApprovalCell(interrupt.args.code);
                            }
                        }
                        console.log('[AgentPanel] AUTO-APPROVE: calling resumeFromInterrupt, action=', interrupt.action);
                        resumeFromInterrupt(interrupt, 'approve').catch(err => {
                            console.error('[AgentPanel] AUTO-APPROVE resumeFromInterrupt FAILED:', err);
                        });
                        return;
                    }
                    if (interrupt.action === 'jupyter_cell_tool' && interrupt.args?.code) {
                        const shouldQueue = shouldExecuteInNotebook(interrupt.args.code);
                        if (isAutoApprovedCode(interrupt.args.code)) {
                            if (shouldQueue) {
                                queueApprovalCell(interrupt.args.code);
                            }
                            resumeFromInterrupt(interrupt, 'approve').catch(err => {
                                console.error('[AgentPanel] auto-approved code resumeFromInterrupt FAILED:', err);
                            });
                            return;
                        }
                        if (shouldQueue) {
                            queueApprovalCell(interrupt.args.code);
                        }
                    }
                    setInterruptData(interrupt);
                    upsertInterruptMessage(interrupt);
                    setIsLoading(false);
                    setIsStreaming(false);
                }, 
                // onTodos callback - update todo list UI
                (newTodos) => {
                    console.log('[AgentPanel] Todos updated:', newTodos.length, 'items');
                    setTodos(newTodos);
                }, 
                // onDebugClear callback - clear debug status
                () => {
                    setDebugStatus(null);
                }, 
                // onToolCall callback - add cells to notebook
                handleToolCall, 
                // onComplete callback - capture thread_id for context persistence
                (data) => {
                    if (data.threadId) {
                        setAgentThreadId(data.threadId);
                        console.log('[AgentPanel] Captured agentThreadId for context persistence:', data.threadId);
                    }
                }, 
                // threadId - pass existing thread_id to continue context
                agentThreadId || undefined, abortControllerRef.current?.signal);
            }
        }
        catch (error) {
            // Handle abort error gracefully (user clicked stop)
            if (error instanceof Error && error.name === 'AbortError') {
                _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackError('chat_abort', { input_mode: inputMode });
                console.log('[AgentPanel] Chat stream stopped by user');
                setDebugStatus(null);
                // Keep the streamed content as-is, just add a stopped indicator
                if (streamedContent) {
                    setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                        ? { ...msg, content: streamedContent + '\n\n*(응답 중단됨)*' }
                        : msg));
                }
            }
            else {
                const message = error instanceof Error ? error.message : 'Failed to send message';
                _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackError('chat_error', { input_mode: inputMode, error: message });
                setDebugStatus(`오류: ${message}`);
                // Update the assistant message with error
                setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                    ? {
                        ...msg,
                        content: streamedContent + `\n\nError: ${message}`
                    }
                    : msg));
            }
        }
        finally {
            // 상태 이력을 메시지 metadata에 저장 (streaming 종료 후에도 표시)
            const finalStatus = chatStatusLinesRef.current.join('\n');
            if (finalStatus) {
                setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                    ? { ...msg, metadata: { ...msg.metadata, statusHistory: finalStatus } }
                    : msg));
            }
            if (!approvalPendingRef.current) {
                // interrupt 체인 없이 정상 완료 또는 에러 — 상태 정리
                setIsLoading(false);
                setIsStreaming(false);
                setStreamingMessageId(null);
            }
            chatStatusLinesRef.current = [];
            setDebugStatusRaw(null);
            // approvalPendingRef=true면 체인된 resumeFromInterrupt가 로딩 상태 관리
            abortControllerRef.current = null;
        }
        return streamedContent;
    };
    // Extract and store code blocks from messages, setup button listeners
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        // Use a small delay to ensure DOM is updated after message rendering
        const timeoutId = setTimeout(() => {
            // Find messages container - try multiple selectors
            const messagesContainer = document.querySelector('.jp-agent-messages') ||
                messagesEndRef.current?.parentElement ||
                document.querySelector('[class*="jp-agent-messages"]');
            if (!messagesContainer) {
                console.log('[AgentPanel] Messages container not found');
                return;
            }
            // Extract code blocks from all assistant messages
            const codeBlocks = [];
            const containers = messagesContainer.querySelectorAll('.code-block-container');
            containers.forEach(container => {
                const blockId = container.getAttribute('data-block-id');
                if (!blockId)
                    return;
                const codeElement = container.querySelector(`#${blockId}`);
                if (!codeElement)
                    return;
                const codeText = codeElement.textContent || '';
                const langElement = container.querySelector('.code-block-language');
                const language = langElement?.textContent?.toLowerCase() || 'python';
                codeBlocks.push({
                    id: blockId,
                    code: codeText,
                    language: language
                });
            });
            // Update code blocks ref
            allCodeBlocksRef.current = codeBlocks;
            // Use event delegation - attach single listener to container
            const handleContainerClick = async (e) => {
                const target = e.target;
                const nextItem = target.closest('.jp-next-items-item');
                if (nextItem) {
                    e.stopPropagation();
                    e.preventDefault();
                    const subject = nextItem.querySelector('.jp-next-items-subject')?.textContent?.trim() || '';
                    const description = nextItem.querySelector('.jp-next-items-description')?.textContent?.trim() || '';
                    const nextText = subject && description
                        ? `${subject}\n\n${description}`
                        : (subject || description);
                    if (nextText) {
                        void handleNextItemSelection(nextText);
                    }
                    return;
                }
                // Handle expand/collapse button
                if (target.classList.contains('code-block-toggle') || target.closest('.code-block-toggle')) {
                    const button = target.classList.contains('code-block-toggle')
                        ? target
                        : target.closest('.code-block-toggle');
                    e.stopPropagation();
                    e.preventDefault();
                    const container = button.closest('.code-block-container');
                    if (!container)
                        return;
                    const isExpanded = container.classList.toggle('is-expanded');
                    button.setAttribute('aria-expanded', String(isExpanded));
                    button.setAttribute('title', isExpanded ? '접기' : '전체 보기');
                    button.setAttribute('aria-label', isExpanded ? '접기' : '전체 보기');
                    const icon = button.querySelector('.code-block-toggle-icon');
                    if (icon) {
                        icon.textContent = isExpanded ? '▴' : '▾';
                    }
                    return;
                }
                // Handle copy button
                if (target.classList.contains('code-block-copy') || target.closest('.code-block-copy')) {
                    const button = target.classList.contains('code-block-copy')
                        ? target
                        : target.closest('.code-block-copy');
                    e.stopPropagation();
                    e.preventDefault();
                    const blockId = button.getAttribute('data-block-id');
                    if (!blockId)
                        return;
                    const block = allCodeBlocksRef.current.find(b => b.id === blockId);
                    if (!block)
                        return;
                    try {
                        await navigator.clipboard.writeText(block.code);
                        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('code_copy_from_agent', {
                            code_length: block.code.length,
                            code_lines: block.code.split('\n').length,
                        });
                        const originalText = button.textContent;
                        button.textContent = '복사됨!';
                        setTimeout(() => {
                            button.textContent = originalText || '복사';
                        }, 2000);
                    }
                    catch (error) {
                        console.error('Failed to copy code:', error);
                        showNotification('복사에 실패했습니다.', 'error');
                    }
                    return;
                }
                // Handle apply button
                if (target.classList.contains('code-block-apply') || target.closest('.code-block-apply')) {
                    const button = target.classList.contains('code-block-apply')
                        ? target
                        : target.closest('.code-block-apply');
                    e.stopPropagation();
                    e.preventDefault();
                    const blockId = button.getAttribute('data-block-id');
                    console.log(`[AgentPanel] Apply button clicked via delegation, blockId: ${blockId}`);
                    if (!blockId) {
                        showNotification('코드 블록 ID를 찾을 수 없습니다.', 'error');
                        return;
                    }
                    const block = allCodeBlocksRef.current.find(b => b.id === blockId);
                    if (!block) {
                        console.error('[AgentPanel] Block not found!', {
                            clickedId: blockId,
                            availableIds: allCodeBlocksRef.current.map(b => b.id),
                            blocksCount: allCodeBlocksRef.current.length
                        });
                        showNotification('코드를 찾을 수 없습니다.', 'error');
                        return;
                    }
                    console.log(`[AgentPanel] Applying code to cell via delegation, code length: ${block.code.length}`);
                    await applyCodeToCell(block.code, blockId, button);
                    return;
                }
            };
            // Attach single event listener to container
            messagesContainer.addEventListener('click', handleContainerClick);
            // Cleanup - store handler reference for cleanup
            messagesContainer._agentPanelClickHandler = handleContainerClick;
        }, 100); // Small delay to ensure DOM is ready
        // Cleanup
        return () => {
            clearTimeout(timeoutId);
            // Remove event listener on cleanup
            const messagesContainer = document.querySelector('.jp-agent-messages') ||
                messagesEndRef.current?.parentElement ||
                document.querySelector('[class*="jp-agent-messages"]');
            if (messagesContainer && messagesContainer._agentPanelClickHandler) {
                messagesContainer.removeEventListener('click', messagesContainer._agentPanelClickHandler);
                delete messagesContainer._agentPanelClickHandler;
            }
        };
    }, [messages.length, streamingMessageId]);
    // Helper: Get notification background color
    const getNotificationColor = (type) => {
        switch (type) {
            case 'error': return '#f56565';
            case 'warning': return '#ed8936';
            default: return '#4299e1';
        }
    };
    // Helper: Create and show notification element
    const createNotificationElement = (message, backgroundColor) => {
        const notification = document.createElement('div');
        notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 16px;
      border-radius: 6px;
      color: white;
      font-size: 14px;
      font-weight: 500;
      z-index: 10001;
      opacity: 0;
      transition: opacity 0.3s ease;
      max-width: 300px;
      word-wrap: break-word;
      background: ${backgroundColor};
    `;
        notification.textContent = message;
        return notification;
    };
    // Helper: Animate notification in and out
    const animateNotification = (notification) => {
        setTimeout(() => notification.style.opacity = '1', 10);
        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    };
    // Show notification
    const showNotification = (message, type = 'info') => {
        const notification = createNotificationElement(message, getNotificationColor(type));
        document.body.appendChild(notification);
        animateNotification(notification);
    };
    // Show tooltip on a specific cell
    const showCellTooltip = (cellElement, message) => {
        // Remove any existing tooltip
        const existingTooltip = document.querySelector('.jp-agent-cell-tooltip');
        if (existingTooltip) {
            existingTooltip.remove();
        }
        const tooltip = document.createElement('div');
        tooltip.className = 'jp-agent-cell-tooltip';
        tooltip.textContent = message;
        tooltip.style.cssText = `
      position: absolute;
      top: 0;
      left: 50%;
      transform: translateX(-50%);
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 8px 16px;
      border-radius: 0 0 8px 8px;
      font-size: 13px;
      font-weight: 500;
      box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
      z-index: 1000;
      opacity: 0;
      transition: opacity 0.3s ease;
      pointer-events: none;
      white-space: nowrap;
    `;
        // Make cell position relative if not already
        const originalPosition = cellElement.style.position;
        if (!originalPosition || originalPosition === 'static') {
            cellElement.style.position = 'relative';
        }
        cellElement.appendChild(tooltip);
        // Fade in
        requestAnimationFrame(() => {
            tooltip.style.opacity = '1';
        });
        // Fade out and remove after 2 seconds
        setTimeout(() => {
            tooltip.style.opacity = '0';
            setTimeout(() => {
                tooltip.remove();
                // Restore original position
                if (!originalPosition || originalPosition === 'static') {
                    cellElement.style.position = originalPosition || '';
                }
            }, 300);
        }, 2000);
    };
    // Apply code to Jupyter cell
    const applyCodeToCell = async (code, blockId, button) => {
        console.log('[AgentPanel] applyCodeToCell called', { codeLength: code.length, blockId });
        const originalText = button.textContent;
        try {
            button.disabled = true;
            button.textContent = '적용 중...';
            const app = window.jupyterapp;
            if (!app) {
                console.error('[AgentPanel] jupyterapp not found in window');
                showNotification('JupyterLab을 찾을 수 없습니다.', 'error');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            console.log('[AgentPanel] Found jupyterapp');
            // Try to get notebook tracker from app
            // The notebookTracker is passed to cellButtonsPlugin, so we need to access it differently
            // Use shell to find current notebook widget
            const shell = app.shell;
            const currentWidget = shell.currentWidget;
            // Check if current widget is a notebook
            if (currentWidget && 'content' in currentWidget) {
                const notebook = currentWidget.content;
                // Check if it's a notebook (has model and cells)
                if (notebook && 'model' in notebook && notebook.model && 'cells' in notebook.model) {
                    await applyCodeToNotebookCell(code, notebook, blockId, button, originalText);
                    return;
                }
            }
            // Fallback: show cell selector dialog
            showCellSelectorDialog(code, button, originalText);
        }
        catch (error) {
            console.error('Failed to apply code to cell:', error);
            showNotification('코드 적용에 실패했습니다.', 'error');
            button.disabled = false;
            button.textContent = originalText || '셀에 적용';
        }
    };
    // Helper: Try different methods to set cell source
    const setCellSource = (cellModel, code) => {
        if (cellModel.sharedModel && typeof cellModel.sharedModel.setSource === 'function') {
            cellModel.sharedModel.setSource(code);
        }
        else if (cellModel.setSource && typeof cellModel.setSource === 'function') {
            cellModel.setSource(code);
        }
        else if (cellModel.value && typeof cellModel.value.setText === 'function') {
            cellModel.value.setText(code);
        }
        else if (cellModel.value && cellModel.value.text !== undefined) {
            cellModel.value.text = code;
        }
        else {
            throw new Error('Unable to set cell source - no compatible method found');
        }
    };
    // Helper: Reset button state
    const resetButtonState = (button, originalText) => {
        button.disabled = false;
        button.textContent = originalText || '셀에 적용';
    };
    // Apply code to a specific notebook cell
    const applyCodeToNotebookCell = async (code, notebook, blockId, button, originalText) => {
        try {
            // Get widgets from notebook
            const cells = notebook.widgets || [];
            const modelCellsLength = notebook.model?.cells?.length || 0;
            console.log('[AgentPanel] applyCodeToNotebookCell called', {
                currentCellIndex: currentCellIndexRef.current,
                currentCellId: currentCellIdRef.current,
                blockId,
                widgetsLength: cells.length,
                modelCellsLength: modelCellsLength
            });
            // Try cell index first (most reliable)
            if (currentCellIndexRef.current !== null && currentCellIndexRef.current !== undefined) {
                console.log('[AgentPanel] Using cell index:', currentCellIndexRef.current);
                // Safety check: if widgets array is empty but model has cells, there might be a rendering issue
                if (cells.length === 0 && modelCellsLength > 0) {
                    console.warn('[AgentPanel] Widgets not rendered yet, model has', modelCellsLength, 'cells');
                    // Fall through to show selector dialog
                }
                else if (currentCellIndexRef.current >= 0 && currentCellIndexRef.current < cells.length) {
                    const cell = cells[currentCellIndexRef.current];
                    const cellModel = cell.model || cell;
                    console.log('[AgentPanel] Found cell at index, applying code...');
                    try {
                        setCellSource(cellModel, code);
                        console.log('[AgentPanel] Code applied successfully!');
                        // Show tooltip on the target cell
                        if (cell.node) {
                            showCellTooltip(cell.node, '✓ 코드가 적용되었습니다');
                        }
                        else {
                            showNotification('코드가 셀에 적용되었습니다!', 'info');
                        }
                        resetButtonState(button, originalText);
                        // Clear the cell index after successful application
                        currentCellIndexRef.current = null;
                        currentCellIdRef.current = null;
                        return;
                    }
                    catch (updateError) {
                        console.error('Failed to update cell content:', updateError);
                        showNotification('셀 내용 업데이트 실패: ' + updateError.message, 'error');
                        resetButtonState(button, originalText);
                        return;
                    }
                }
                else {
                    console.error('[AgentPanel] Cell index out of bounds:', {
                        currentIndex: currentCellIndexRef.current,
                        widgetsLength: cells.length,
                        modelCellsLength: modelCellsLength
                    });
                    // Don't show error, fall through to selector dialog
                    currentCellIndexRef.current = null;
                    currentCellIdRef.current = null;
                }
            }
            // Fallback: show selector dialog
            console.log('[AgentPanel] Showing cell selector dialog');
            showCellSelectorDialog(code, button, originalText);
        }
        catch (error) {
            console.error('Failed to apply code:', error);
            showNotification('코드 적용에 실패했습니다.', 'error');
            resetButtonState(button, originalText);
        }
    };
    // Show cell selector dialog (similar to chrome_agent)
    const showCellSelectorDialog = (code, button, originalText) => {
        try {
            const app = window.jupyterapp;
            if (!app) {
                showNotification('JupyterLab을 찾을 수 없습니다.', 'error');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            // Find current notebook from shell
            const shell = app.shell;
            const currentWidget = shell.currentWidget;
            if (!currentWidget || !('content' in currentWidget)) {
                showNotification('활성 노트북을 찾을 수 없습니다.', 'warning');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            const notebook = currentWidget.content;
            if (!notebook || !('model' in notebook) || !notebook.model || !('cells' in notebook.model)) {
                showNotification('활성 노트북을 찾을 수 없습니다.', 'warning');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            const cells = notebook.widgets || [];
            const codeCells = [];
            // Collect code cells
            cells.forEach((cell, index) => {
                const cellModel = cell.model || cell;
                if (cellModel.type === 'code') {
                    const cellId = cellModel.metadata?.get?.('jupyterAgentCellId') ||
                        cellModel.id ||
                        `cell-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
                    // Ensure cell has ID
                    try {
                        if (!cellModel.metadata?.get?.('jupyterAgentCellId')) {
                            if (cellModel.metadata?.set) {
                                cellModel.metadata.set('jupyterAgentCellId', cellId);
                            }
                        }
                    }
                    catch (e) {
                        // Metadata might not be accessible, continue anyway
                    }
                    const content = (cellModel.sharedModel?.getSource?.() ||
                        cellModel.value?.text ||
                        '').toString();
                    const preview = content.substring(0, 100).replace(/\n/g, ' ');
                    codeCells.push({
                        cell,
                        index,
                        id: cellId,
                        preview
                    });
                }
            });
            if (codeCells.length === 0) {
                showNotification('코드 셀을 찾을 수 없습니다.', 'warning');
                button.disabled = false;
                button.textContent = originalText || '셀에 적용';
                return;
            }
            // Remove existing dialog
            const existingDialog = document.querySelector('.jp-agent-cell-selector-dialog');
            if (existingDialog) {
                existingDialog.remove();
            }
            // Create dialog overlay
            const dialogOverlay = document.createElement('div');
            dialogOverlay.className = 'jp-agent-cell-selector-dialog';
            dialogOverlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.3);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
      `;
            // Create dialog container
            const dialogContainer = document.createElement('div');
            dialogContainer.style.cssText = `
        background: #fafafa;
        border: 1px solid #e0e0e0;
        border-radius: 4px;
        padding: 24px;
        max-width: 500px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      `;
            // Create cell list HTML
            const cellListHTML = codeCells.map(({ index, id, preview }) => {
                return `
          <div class="jp-agent-cell-selector-item" data-cell-id="${id}" style="
            padding: 12px;
            margin-bottom: 8px;
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s ease;
          ">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
              <span style="
                background: #667eea;
                color: white;
                padding: 2px 8px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 600;
              ">셀 ${index + 1}</span>
            </div>
            <div style="font-size: 12px; color: #757575; font-family: 'Menlo', monospace; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
              ${escapeHtml(preview)}${preview.length >= 100 ? '...' : ''}
            </div>
          </div>
        `;
            }).join('');
            // Dialog content
            dialogContainer.innerHTML = `
        <div style="margin-bottom: 20px;">
          <h3 style="margin: 0 0 8px 0; color: #424242; font-size: 16px; font-weight: 500;">
            코드를 적용할 셀 선택
          </h3>
          <p style="margin: 0; color: #757575; font-size: 13px;">
            AI가 생성한 코드를 적용할 셀을 선택하세요
          </p>
        </div>
        <div class="jp-agent-cell-list" style="margin-bottom: 20px;">
          ${cellListHTML}
        </div>
        <div style="display: flex; gap: 12px; justify-content: flex-end;">
          <button class="jp-agent-cell-selector-cancel-btn" style="
            background: transparent;
            color: #616161;
            border: 1px solid #d1d5db;
            border-radius: 3px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.15s ease;
          ">취소</button>
        </div>
      `;
            dialogOverlay.appendChild(dialogContainer);
            document.body.appendChild(dialogOverlay);
            // Cell item click handlers
            const cellItems = dialogContainer.querySelectorAll('.jp-agent-cell-selector-item');
            cellItems.forEach(item => {
                item.addEventListener('click', () => {
                    const cellId = item.getAttribute('data-cell-id');
                    if (!cellId)
                        return;
                    // Find the cell
                    const cellInfo = codeCells.find(c => c.id === cellId);
                    if (!cellInfo)
                        return;
                    const cellModel = cellInfo.cell.model || cellInfo.cell;
                    // Apply code to cell
                    try {
                        setCellSource(cellModel, code);
                        dialogOverlay.remove();
                        // Show tooltip on the target cell
                        if (cellInfo.cell.node) {
                            showCellTooltip(cellInfo.cell.node, '✓ 코드가 적용되었습니다');
                        }
                        else {
                            showNotification('코드가 셀에 적용되었습니다!', 'info');
                        }
                        resetButtonState(button, originalText);
                    }
                    catch (error) {
                        console.error('Failed to apply code to cell:', error);
                        showNotification('코드 적용에 실패했습니다.', 'error');
                        resetButtonState(button, originalText);
                    }
                });
                // Hover effects
                item.addEventListener('mouseenter', () => {
                    item.style.borderColor = '#667eea';
                    item.style.background = '#f8f9ff';
                });
                item.addEventListener('mouseleave', () => {
                    item.style.borderColor = '#e0e0e0';
                    item.style.background = 'white';
                });
            });
            // Cancel button
            const cancelBtn = dialogContainer.querySelector('.jp-agent-cell-selector-cancel-btn');
            if (cancelBtn) {
                cancelBtn.addEventListener('click', () => {
                    dialogOverlay.remove();
                    button.disabled = false;
                    button.textContent = originalText || '셀에 적용';
                });
                cancelBtn.addEventListener('mouseenter', () => {
                    cancelBtn.style.background = '#f5f5f5';
                    cancelBtn.style.borderColor = '#9ca3af';
                });
                cancelBtn.addEventListener('mouseleave', () => {
                    cancelBtn.style.background = 'transparent';
                    cancelBtn.style.borderColor = '#d1d5db';
                });
            }
            // Close on overlay click
            dialogOverlay.addEventListener('click', (e) => {
                if (e.target === dialogOverlay) {
                    dialogOverlay.remove();
                    button.disabled = false;
                    button.textContent = originalText || '셀에 적용';
                }
            });
            // ESC key to close
            const handleEsc = (e) => {
                if (e.key === 'Escape') {
                    dialogOverlay.remove();
                    document.removeEventListener('keydown', handleEsc);
                    button.disabled = false;
                    button.textContent = originalText || '셀에 적용';
                }
            };
            document.addEventListener('keydown', handleEsc);
        }
        catch (error) {
            console.error('Failed to show cell selector:', error);
            showNotification('셀 선택 다이얼로그 표시에 실패했습니다.', 'error');
            button.disabled = false;
            button.textContent = originalText || '셀에 적용';
        }
    };
    // Helper function to escape HTML
    const escapeHtml = (text) => {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    };
    const isAutoApprovedCode = (code) => {
        const lines = code
            .split('\n')
            .map(line => line.trim())
            .filter(line => line.length > 0 && !line.startsWith('#'));
        if (lines.length === 0) {
            return true;
        }
        if (lines.some(line => (line.startsWith('!')
            || line.startsWith('%%bash')
            || line.startsWith('%%sh')
            || line.startsWith('%%shell')))) {
            return false;
        }
        const disallowedPatterns = [
            /(^|[^=!<>])=([^=]|$)/,
            /\.read_[a-zA-Z0-9_]*\s*\(/,
            /\bread_[a-zA-Z0-9_]*\s*\(/,
            /\.to_[a-zA-Z0-9_]*\s*\(/,
        ];
        if (lines.some(line => disallowedPatterns.some(pattern => pattern.test(line)))) {
            return false;
        }
        const allowedPatterns = [
            /^print\(.+\)$/,
            /^display\(.+\)$/,
            /^df\.(head|info|describe)\s*\(.*\)$/,
            /^display\(df\.(head|info|describe)\s*\(.*\)\)$/,
            /^df\.(tail|sample)\s*\(.*\)$/,
            /^display\(df\.(tail|sample)\s*\(.*\)\)$/,
            /^df\.(shape|columns|dtypes)$/,
            /^import\s+pandas\s+as\s+pd$/,
        ];
        return lines.every(line => allowedPatterns.some(pattern => pattern.test(line)));
    };
    const userRequestedNotebookExecution = () => {
        const lastUserMessage = [...messages]
            .reverse()
            .find((msg) => isChatMessage(msg) && msg.role === 'user');
        const content = lastUserMessage?.content ?? '';
        return /노트북|셀|cell|notebook|jupyter/i.test(content);
    };
    const isShellCell = (code) => {
        const lines = code.split('\n');
        const firstLine = lines.find(line => line.trim().length > 0)?.trim() || '';
        if (firstLine.startsWith('%%bash')
            || firstLine.startsWith('%%sh')
            || firstLine.startsWith('%%shell')) {
            return true;
        }
        return lines.some(line => line.trim().startsWith('!'));
    };
    const extractShellCommand = (code) => {
        const lines = code.split('\n');
        const firstNonEmptyIndex = lines.findIndex(line => line.trim().length > 0);
        if (firstNonEmptyIndex === -1) {
            return '';
        }
        const firstLine = lines[firstNonEmptyIndex].trim();
        if (firstLine.startsWith('%%bash')
            || firstLine.startsWith('%%sh')
            || firstLine.startsWith('%%shell')) {
            const script = lines.slice(firstNonEmptyIndex + 1).join('\n').trim();
            if (!script) {
                return '';
            }
            const escaped = script
                .replace(/\\/g, '\\\\')
                .replace(/'/g, "\\'")
                .replace(/\r?\n/g, '\\n');
            return `bash -lc $'${escaped}'`;
        }
        const shellLines = lines
            .map(line => line.trim())
            .filter(line => line.startsWith('!'))
            .map(line => line.replace(/^!+/, '').trim())
            .filter(Boolean);
        return shellLines.join('\n');
    };
    const buildPythonCommand = (code) => (`python3 -c ${JSON.stringify(code)}`);
    const shouldExecuteInNotebook = (code) => {
        const notebook = getActiveNotebookPanel();
        if (!notebook) {
            return false;
        }
        if (isShellCell(code) && !userRequestedNotebookExecution()) {
            return false;
        }
        return true;
    };
    const truncateOutputLines = (output, maxLines = 2) => {
        const lines = output.split(/\r?\n/).filter(line => line.length > 0);
        const text = lines.slice(0, maxLines).join('\n');
        return { text, truncated: lines.length > maxLines };
    };
    const createCommandOutputMessage = (command) => {
        const messageId = makeMessageId('command-output');
        const outputMessage = {
            id: messageId,
            role: 'system',
            content: `${command}\n`,
            timestamp: Date.now(),
            metadata: {
                kind: 'shell-output',
                command
            }
        };
        setMessages(prev => [...prev, outputMessage]);
        return messageId;
    };
    const appendCommandOutputMessage = (messageId, text, stream) => {
        if (!text)
            return;
        const prefix = stream === 'stderr' ? '[stderr] ' : '';
        setMessages(prev => prev.map(msg => {
            if (msg.id !== messageId || !('role' in msg)) {
                return msg;
            }
            const chatMsg = msg;
            return {
                ...chatMsg,
                content: `${chatMsg.content}${prefix}${text}`
            };
        }));
    };
    const executeSubprocessCommand = async (command, timeout, onOutput, stdin) => {
        try {
            const result = await apiService.executeCommandStream(command, { timeout, onOutput, stdin });
            const stdout = typeof result.stdout === 'string' ? result.stdout : '';
            const stderr = typeof result.stderr === 'string' ? result.stderr : '';
            const combined = [stdout, stderr].filter(Boolean).join('\n');
            const summary = truncateOutputLines(combined, 2);
            const truncated = summary.truncated || Boolean(result.truncated);
            const output = summary.text || '(no output)';
            if (result.success) {
                return {
                    success: true,
                    output,
                    returncode: result.returncode ?? null,
                    command,
                    truncated
                };
            }
            const errorText = summary.text || result.error || stderr || 'Command failed';
            return {
                success: false,
                output,
                error: errorText,
                returncode: result.returncode ?? null,
                command,
                truncated
            };
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Command execution failed';
            if (onOutput) {
                onOutput({ stream: 'stderr', text: `${message}\n` });
            }
            const summary = truncateOutputLines(message, 2);
            return {
                success: false,
                output: '',
                error: summary.text || 'Command execution failed',
                returncode: null,
                command,
                truncated: summary.truncated
            };
        }
    };
    const executeCodeViaSubprocess = async (code, timeout, onOutput) => {
        const isShell = isShellCell(code);
        const command = isShell ? extractShellCommand(code) : buildPythonCommand(code);
        if (!command) {
            return {
                success: false,
                output: '',
                error: isShell ? 'Shell command is empty' : 'Python command is empty',
                returncode: null,
                command,
                truncated: false,
                execution_method: 'subprocess'
            };
        }
        const result = await executeSubprocessCommand(command, timeout, onOutput);
        return {
            ...result,
            execution_method: 'subprocess'
        };
    };
    const upsertInterruptMessage = (interrupt, autoApproved) => {
        const interruptMessageId = interruptMessageIdRef.current || makeMessageId('interrupt');
        interruptMessageIdRef.current = interruptMessageId;
        const interruptMessage = {
            id: interruptMessageId,
            role: 'system',
            content: interrupt.description || '코드 실행 승인이 필요합니다.',
            timestamp: Date.now(),
            metadata: {
                interrupt: {
                    ...interrupt,
                    resolved: autoApproved || false,
                    decision: autoApproved ? 'approve' : undefined,
                    autoApproved: autoApproved || false
                }
            }
        };
        setMessages(prev => {
            const hasExisting = prev.some(msg => msg.id === interruptMessageId);
            if (hasExisting) {
                return prev.map(msg => msg.id === interruptMessageId ? interruptMessage : msg);
            }
            return [...prev, interruptMessage];
        });
    };
    const clearInterruptMessage = (decision) => {
        if (!interruptMessageIdRef.current)
            return;
        const messageId = interruptMessageIdRef.current;
        interruptMessageIdRef.current = null;
        setMessages(prev => prev.map(msg => {
            // Only IChatMessage has metadata property (check via 'role' property)
            if (msg.id === messageId && 'role' in msg) {
                const chatMsg = msg;
                return {
                    ...chatMsg,
                    metadata: {
                        ...chatMsg.metadata,
                        interrupt: {
                            ...(chatMsg.metadata?.interrupt || {}),
                            resolved: true,
                            decision: decision || 'approve' // Track approve/reject decision
                        }
                    }
                };
            }
            return msg;
        }));
    };
    const validateRelativePath = (path) => {
        const trimmed = path.trim();
        if (trimmed.startsWith('/') || trimmed.startsWith('\\') || /^[A-Za-z]:/.test(trimmed)) {
            return { valid: false, error: 'Absolute paths are not allowed' };
        }
        if (trimmed.includes('..')) {
            return { valid: false, error: 'Path traversal (..) is not allowed' };
        }
        return { valid: true };
    };
    const normalizeContentsPath = (path) => {
        const trimmed = path.trim();
        if (!trimmed || trimmed === '.' || trimmed === './') {
            return '';
        }
        return trimmed
            .replace(/^\.\/+/, '')
            .replace(/^\/+/, '')
            .replace(/\/+$/, '');
    };
    const globToRegex = (pattern) => {
        const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, '\\$&');
        const regex = `^${escaped.replace(/\*/g, '.*').replace(/\?/g, '.')}$`;
        return new RegExp(regex);
    };
    const fetchContentsModel = async (path, options) => {
        try {
            const { PageConfig, URLExt } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
            const baseUrl = PageConfig.getBaseUrl();
            const normalizedPath = normalizeContentsPath(path);
            const apiUrl = URLExt.join(baseUrl, 'api/contents', normalizedPath);
            const query = new URLSearchParams();
            if (options?.content !== undefined) {
                query.set('content', options.content ? '1' : '0');
            }
            if (options?.format) {
                query.set('format', options.format);
            }
            const url = query.toString() ? `${apiUrl}?${query.toString()}` : apiUrl;
            const response = await fetch(url, {
                method: 'GET',
                credentials: 'include',
            });
            if (!response.ok) {
                return { success: false, error: `Failed to load contents: ${response.status}` };
            }
            const data = await response.json();
            return { success: true, data };
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Failed to load contents';
            return { success: false, error: message };
        }
    };
    const executeListFilesTool = async (params) => {
        const pathCheck = validateRelativePath(params.path);
        if (!pathCheck.valid) {
            return { success: false, error: pathCheck.error };
        }
        // Directories to skip during recursive traversal (performance optimization)
        const IGNORED_DIRS = new Set([
            'node_modules',
            '.git',
            '__pycache__',
            '.venv',
            'venv',
            '.tox',
            '.pytest_cache',
            '.mypy_cache',
            '.ruff_cache',
            'dist',
            'build',
            '.next',
            '.nuxt',
            'coverage',
            '.coverage',
            '.ipynb_checkpoints',
        ]);
        const pattern = (params.pattern || '*').trim() || '*';
        const recursive = params.recursive ?? false;
        const matcher = globToRegex(pattern);
        const maxEntries = 500;
        const files = [];
        const pendingDirs = [normalizeContentsPath(params.path)];
        const visited = new Set();
        while (pendingDirs.length > 0 && files.length < maxEntries) {
            const dirPath = pendingDirs.shift() ?? '';
            if (visited.has(dirPath)) {
                continue;
            }
            visited.add(dirPath);
            const contentsResult = await fetchContentsModel(dirPath, { content: true });
            if (!contentsResult.success) {
                // Skip directories that return 404 (might not exist or permission denied)
                // Only fail on the root path
                if (dirPath === '' || dirPath === '.') {
                    return { success: false, error: contentsResult.error };
                }
                continue; // Skip this directory and continue with others
            }
            const model = contentsResult.data;
            if (!model || model.type !== 'directory' || !Array.isArray(model.content)) {
                const displayPath = dirPath || '.';
                return { success: false, error: `Not a directory: ${displayPath}` };
            }
            for (const entry of model.content) {
                if (!entry) {
                    continue;
                }
                const name = entry.name || entry.path?.split('/').pop() || '';
                const entryPath = entry.path || name;
                const isDir = entry.type === 'directory';
                // Skip ignored directories
                if (isDir && IGNORED_DIRS.has(name)) {
                    continue;
                }
                if (matcher.test(name)) {
                    files.push({
                        path: entryPath,
                        isDir,
                        size: isDir ? 0 : (entry.size ?? 0),
                    });
                }
                if (recursive && isDir && entryPath) {
                    pendingDirs.push(entryPath);
                }
                if (files.length >= maxEntries) {
                    break;
                }
            }
        }
        const formatted = files.map((file) => {
            const icon = file.isDir ? '[DIR]' : '[FILE]';
            const sizeInfo = file.isDir ? '' : ` (${file.size} bytes)`;
            return `${icon} ${file.path}${file.isDir ? '/' : sizeInfo}`;
        }).join('\n');
        return {
            success: true,
            output: formatted || '(empty directory)',
            metadata: { count: files.length, files }
        };
    };
    const executeReadFileTool = async (params) => {
        if (!params.path) {
            return { success: false, error: 'Path is required' };
        }
        const pathCheck = validateRelativePath(params.path);
        if (!pathCheck.valid) {
            return { success: false, error: pathCheck.error };
        }
        // Support both old (maxLines) and new (offset/limit) parameters
        const offset = typeof params.offset === 'number' ? Math.max(0, params.offset) : 0;
        const limit = typeof params.limit === 'number'
            ? params.limit
            : (typeof params.maxLines === 'number' ? params.maxLines : 500);
        const safeLimit = Math.max(0, limit);
        const contentsResult = await fetchContentsModel(params.path, { content: true, format: 'text' });
        if (!contentsResult.success) {
            return { success: false, error: contentsResult.error };
        }
        const model = contentsResult.data;
        if (!model) {
            return { success: false, error: 'File not found' };
        }
        if (model.type === 'directory') {
            return { success: false, error: `Path is a directory: ${params.path}` };
        }
        let content = model.content ?? '';
        if (model.format === 'base64') {
            return { success: false, error: 'Binary file content is not supported' };
        }
        if (typeof content !== 'string') {
            content = JSON.stringify(content, null, 2);
        }
        const lines = content.split('\n');
        const totalLines = lines.length;
        // Apply offset and limit
        const sliced = lines.slice(offset, offset + safeLimit);
        return {
            success: true,
            output: sliced.join('\n'),
            metadata: {
                lineCount: sliced.length,
                totalLines,
                offset,
                limit: safeLimit,
                truncated: totalLines > offset + safeLimit
            }
        };
    };
    // Helper function for auto-approving search/file tools with execution results
    const handleAutoToolInterrupt = async (interrupt) => {
        const { threadId, action, args } = interrupt;
        const toolActionCount = interrupt.actionCount || 1;
        console.log('[AgentPanel] Auto-approving tool:', action, 'actionCount:', toolActionCount, args);
        // 안전 타임아웃: 백엔드 5분 타임아웃보다 약간 길게 설정
        const SAFETY_TIMEOUT_MS = 330000; // 5분 30초
        const safetyTimer = setTimeout(() => {
            console.error('[AgentPanel] handleAutoToolInterrupt safety timeout - 강제 해제');
            setIsLoading(false);
            setIsStreaming(false);
            setStreamingMessageId(null);
            approvalPendingRef.current = false;
            setDebugStatus('오류: 응답 시간 초과 (Agent 응답 없음)');
        }, SAFETY_TIMEOUT_MS);
        try {
            let executionResult;
            if (action === 'search_notebook_cells_tool') {
                setDebugStatus({ status: `노트북 검색 실행 중: ${args?.pattern || ''}`, icon: 'search' });
                executionResult = await apiService.searchNotebookCells({
                    pattern: args?.pattern || '',
                    notebook_path: args?.notebook_path,
                    cell_type: args?.cell_type,
                    max_results: args?.max_results || 30,
                    case_sensitive: args?.case_sensitive || false
                });
                console.log('[AgentPanel] search_notebook_cells result:', executionResult);
            }
            else if (action === 'check_resource_tool') {
                const filesList = args?.files || [];
                setDebugStatus({ status: `리소스 체크 중: ${filesList.join(', ') || 'system'}`, icon: 'check' });
                executionResult = await apiService.checkResource({
                    files: filesList,
                    dataframes: args?.dataframes || [],
                    file_size_command: args?.file_size_command || '',
                    dataframe_check_code: args?.dataframe_check_code || ''
                });
                console.log('[AgentPanel] check_resource result:', executionResult);
            }
            else if (action === 'read_file_tool') {
                setDebugStatus({ status: '파일 읽는 중...', icon: 'read' });
                const readParams = {
                    path: typeof args?.path === 'string' ? args.path : '',
                    encoding: typeof args?.encoding === 'string' ? args.encoding : undefined,
                    offset: typeof args?.offset === 'number' ? args.offset : 0,
                    limit: typeof args?.limit === 'number' ? args.limit : (args?.max_lines ?? args?.maxLines ?? 500)
                };
                executionResult = await executeReadFileTool(readParams);
            }
            else if (action === 'list_workspace_tool') {
                const searchPattern = args?.pattern && args.pattern !== '*' ? ` 패턴: ${args.pattern}` : '';
                setDebugStatus({ status: `파일 목록 조회${searchPattern}`, icon: 'tool' });
                const listParams = {
                    path: typeof args?.path === 'string' ? args.path : '.',
                    pattern: typeof args?.pattern === 'string' ? args.pattern : '*',
                    recursive: args?.recursive === true,
                };
                executionResult = await executeListFilesTool(listParams);
            }
            else if (action === 'search_files_tool') {
                setDebugStatus({ status: `파일 검색 중: ${args?.pattern || ''}`, icon: 'search' });
                try {
                    const currentLlmConfig = llmConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getDefaultLLMConfig)();
                    const searchResult = await apiService.searchWorkspace({
                        pattern: args?.pattern || '',
                        file_types: args?.file_pattern ? [args.file_pattern] : ['*'],
                        path: args?.path || '.',
                        max_results: args?.max_results || 30,
                        case_sensitive: args?.case_sensitive || false,
                        workspaceRoot: currentLlmConfig.workspaceRoot
                    });
                    if (searchResult.success && searchResult.results) {
                        const formatted = searchResult.results.map((r) => `${r.file_path}:${r.line_number}: ${r.content}`).join('\n');
                        executionResult = {
                            success: true,
                            output: formatted || '(no matches found)',
                            metadata: { count: searchResult.total_results }
                        };
                    }
                    else {
                        executionResult = { success: false, error: searchResult.error || 'Search failed' };
                    }
                }
                catch (error) {
                    executionResult = { success: false, error: error.message || 'Search failed' };
                }
                console.log('[AgentPanel] search_files result:', executionResult);
            }
            else {
                console.warn('[AgentPanel] Unknown auto tool:', action);
                return;
            }
            // Resume with execution result
            const resumeArgs = {
                ...args,
                execution_result: executionResult
            };
            // Clear interrupt state (don't show approval UI for search)
            setInterruptData(null);
            // Create new assistant message for continued response
            const assistantMessageId = makeMessageId('assistant');
            setStreamingMessageId(assistantMessageId);
            setMessages(prev => [
                ...prev,
                {
                    id: assistantMessageId,
                    role: 'assistant',
                    content: '',
                    timestamp: Date.now()
                }
            ]);
            let streamedContent = '';
            let interrupted = false;
            setDebugStatus({ status: 'LLM 응답 대기 중', icon: 'thinking' });
            await apiService.resumeAgent(threadId, 'edit', // Use 'edit' to pass execution_result in args
            resumeArgs, undefined, getEffectiveLLMConfig(), (chunk) => {
                streamedContent += chunk;
                setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                    ? { ...msg, content: streamedContent }
                    : msg));
            }, (status) => {
                setDebugStatus(status);
            }, (nextInterrupt) => {
                interrupted = true;
                approvalPendingRef.current = true;
                const autoApproveEnabled = getAutoApproveEnabled(llmConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getDefaultLLMConfig)());
                // Handle next interrupt (could be another search or code execution)
                if (nextInterrupt.action === 'search_notebook_cells_tool'
                    || nextInterrupt.action === 'check_resource_tool'
                    || nextInterrupt.action === 'read_file_tool'
                    || nextInterrupt.action === 'list_workspace_tool'
                    || nextInterrupt.action === 'search_files_tool') {
                    void handleAutoToolInterrupt(nextInterrupt);
                    return;
                }
                // Auto-approve jupyter_cell READ operations (non-destructive)
                if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.operation === 'READ') {
                    console.log('[AgentPanel] Auto-approving jupyter_cell READ operation (handleAutoToolInterrupt chain)');
                    resumeFromInterrupt(nextInterrupt, 'approve').catch(err => {
                        console.error('[AgentPanel] jupyter_cell READ auto-approve FAILED:', err);
                    });
                    return;
                }
                // Handle ask_user_tool - show input UI
                if (nextInterrupt.action === 'ask_user_tool') {
                    console.log('[AgentPanel] ask_user_tool interrupt (resume):', nextInterrupt.args);
                    setIsAskUserMode(true);
                    setPendingAskUserInterrupt(nextInterrupt);
                    setIsLoading(false);
                    setIsStreaming(false);
                    // Display the question as an assistant message
                    const question = nextInterrupt.args?.question || '응답을 입력하세요...';
                    const options = nextInterrupt.args?.options;
                    const inputType = nextInterrupt.args?.input_type || 'text';
                    let questionContent = `❓ **${question}**`;
                    if (options && options.length > 0) {
                        questionContent += '\n\n선택지:\n' + options.map((opt, i) => `${i + 1}. ${opt}`).join('\n');
                    }
                    if (inputType === 'file') {
                        questionContent += '\n\n_(파일을 업로드하거나 파일 경로를 입력하세요)_';
                    }
                    const askUserMessage = {
                        id: makeMessageId('ask_user'),
                        role: 'assistant',
                        content: questionContent,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, askUserMessage]);
                    setTimeout(() => {
                        const textarea = document.querySelector('.jp-agent-input');
                        if (textarea) {
                            textarea.focus();
                            textarea.placeholder = question;
                        }
                    }, 100);
                    return;
                }
                if (autoApproveEnabled) {
                    // 자동 승인 모드일 때도 인터럽트 메시지를 생성하여 코드블럭으로 표시
                    upsertInterruptMessage(nextInterrupt, true);
                    // jupyter_cell_tool인 경우 먼저 셀 생성 후 승인 진행
                    if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.code) {
                        const shouldQueue = shouldExecuteInNotebook(nextInterrupt.args.code);
                        if (shouldQueue) {
                            queueApprovalCell(nextInterrupt.args.code);
                        }
                    }
                    resumeFromInterrupt(nextInterrupt, 'approve').catch(err => {
                        console.error('[AgentPanel] nested resumeFromInterrupt FAILED:', err);
                    });
                    return;
                }
                if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.code) {
                    const shouldQueue = shouldExecuteInNotebook(nextInterrupt.args.code);
                    if (isAutoApprovedCode(nextInterrupt.args.code)) {
                        if (shouldQueue) {
                            queueApprovalCell(nextInterrupt.args.code);
                        }
                        resumeFromInterrupt(nextInterrupt, 'approve').catch(err => {
                            console.error('[AgentPanel] nested resumeFromInterrupt FAILED:', err);
                        });
                        return;
                    }
                    if (shouldQueue) {
                        queueApprovalCell(nextInterrupt.args.code);
                    }
                }
                setInterruptData(nextInterrupt);
                upsertInterruptMessage(nextInterrupt);
                setIsLoading(false);
                setIsStreaming(false);
            }, (newTodos) => {
                setTodos(newTodos);
            }, () => {
                setDebugStatus(null);
            }, handleToolCall, toolActionCount, abortControllerRef.current?.signal);
            if (!interrupted) {
                setIsLoading(false);
                setIsStreaming(false);
                setStreamingMessageId(null);
                approvalPendingRef.current = false;
            }
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Tool execution failed';
            console.error('[AgentPanel] Auto tool error:', error);
            setDebugStatus(`오류: ${message}`);
            setIsLoading(false);
            setIsStreaming(false);
            approvalPendingRef.current = false;
        }
        finally {
            clearTimeout(safetyTimer);
        }
    };
    const resumeFromInterrupt = async (interrupt, decision, feedback // Optional feedback message for rejection
    ) => {
        const { threadId } = interrupt;
        const interruptActionCount = interrupt.actionCount || 1;
        console.log('[AgentPanel] resumeFromInterrupt START: action=', interrupt.action, 'decision=', decision, 'threadId=', threadId);
        setInterruptData(null);
        setDebugStatus(null);
        clearInterruptMessage(decision); // Pass decision to track approve/reject
        let resumeDecision = decision;
        let resumeArgs = undefined;
        if (decision === 'approve') {
            // Handle write_file_tool separately - execute file write on Jupyter server
            if (interrupt.action === 'write_file_tool') {
                try {
                    setDebugStatus({ status: '파일 쓰기 중...', icon: 'write' });
                    const writeResult = await apiService.writeFile(interrupt.args?.path || '', interrupt.args?.content || '', {
                        encoding: interrupt.args?.encoding || 'utf-8',
                        overwrite: interrupt.args?.overwrite || false
                    });
                    console.log('[AgentPanel] write_file result:', writeResult);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: writeResult
                    };
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'File write failed';
                    console.error('[AgentPanel] write_file error:', error);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, error: message }
                    };
                }
            }
            else if (interrupt.action === 'edit_file_tool') {
                // Handle edit_file_tool - read file, perform replacement, write back
                try {
                    setDebugStatus({ status: '파일 수정 중...', icon: 'edit' });
                    const filePath = interrupt.args?.path || '';
                    const oldString = interrupt.args?.old_string || '';
                    const newString = interrupt.args?.new_string || '';
                    const replaceAll = interrupt.args?.replace_all || false;
                    // Read current file content
                    const readResult = await apiService.readFile(filePath);
                    if (!readResult.success || readResult.content === undefined) {
                        throw new Error(readResult.error || 'Failed to read file');
                    }
                    const originalContent = readResult.content;
                    const occurrences = (originalContent.match(new RegExp(oldString.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
                    if (occurrences === 0) {
                        throw new Error(`String not found in file: '${oldString.slice(0, 100)}...'`);
                    }
                    if (occurrences > 1 && !replaceAll) {
                        throw new Error(`String appears ${occurrences} times. Use replace_all=True or provide more context.`);
                    }
                    // Perform replacement
                    const newContent = replaceAll
                        ? originalContent.split(oldString).join(newString)
                        : originalContent.replace(oldString, newString);
                    // Generate diff for logging
                    const diffLines = [];
                    const originalLines = originalContent.split('\n');
                    const newLines = newContent.split('\n');
                    diffLines.push(`--- ${filePath} (before)`);
                    diffLines.push(`+++ ${filePath} (after)`);
                    // Simple diff generation
                    let i = 0, j = 0;
                    while (i < originalLines.length || j < newLines.length) {
                        if (i < originalLines.length && j < newLines.length && originalLines[i] === newLines[j]) {
                            i++;
                            j++;
                        }
                        else if (i < originalLines.length && (j >= newLines.length || originalLines[i] !== newLines[j])) {
                            diffLines.push(`-${originalLines[i]}`);
                            i++;
                        }
                        else {
                            diffLines.push(`+${newLines[j]}`);
                            j++;
                        }
                    }
                    const diff = diffLines.join('\n');
                    // Write the modified content
                    const writeResult = await apiService.writeFile(filePath, newContent, {
                        encoding: 'utf-8',
                        overwrite: true
                    });
                    console.log('[AgentPanel] edit_file result:', writeResult);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: {
                            ...writeResult,
                            diff,
                            occurrences,
                            lines_added: newLines.length - originalLines.length > 0 ? newLines.length - originalLines.length : 0,
                            lines_removed: originalLines.length - newLines.length > 0 ? originalLines.length - newLines.length : 0,
                        }
                    };
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'File edit failed';
                    console.error('[AgentPanel] edit_file error:', error);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, error: message }
                    };
                }
            }
            else if (interrupt.action === 'multiedit_file_tool') {
                // Handle multiedit_file_tool - apply multiple edits atomically (Crush 패턴)
                try {
                    setDebugStatus({ status: '다중 파일 수정 중...', icon: 'edit' });
                    const filePath = interrupt.args?.path || '';
                    const edits = interrupt.args?.edits || [];
                    if (!filePath || edits.length === 0) {
                        throw new Error('File path and edits are required');
                    }
                    // Read current file content
                    const readResult = await apiService.readFile(filePath);
                    if (!readResult.success || readResult.content === undefined) {
                        throw new Error(readResult.error || 'Failed to read file');
                    }
                    const originalContent = readResult.content;
                    let currentContent = originalContent;
                    let editsApplied = 0;
                    let editsFailed = 0;
                    const failedEdits = [];
                    // Apply edits sequentially
                    for (let i = 0; i < edits.length; i++) {
                        const edit = edits[i];
                        const oldString = edit.old_string || '';
                        const newString = edit.new_string || '';
                        const replaceAll = edit.replace_all || false;
                        const occurrences = (currentContent.match(new RegExp(oldString.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length;
                        if (occurrences === 0) {
                            failedEdits.push(`Edit ${i + 1}: String not found`);
                            editsFailed++;
                            continue;
                        }
                        if (occurrences > 1 && !replaceAll) {
                            failedEdits.push(`Edit ${i + 1}: String appears ${occurrences} times (use replace_all)`);
                            editsFailed++;
                            continue;
                        }
                        // Apply this edit
                        currentContent = replaceAll
                            ? currentContent.split(oldString).join(newString)
                            : currentContent.replace(oldString, newString);
                        editsApplied++;
                    }
                    // Generate diff
                    const diffLines = [];
                    const originalLines = originalContent.split('\n');
                    const newLines = currentContent.split('\n');
                    diffLines.push(`--- ${filePath} (before)`);
                    diffLines.push(`+++ ${filePath} (after)`);
                    let i = 0, j = 0;
                    while (i < originalLines.length || j < newLines.length) {
                        if (i < originalLines.length && j < newLines.length && originalLines[i] === newLines[j]) {
                            i++;
                            j++;
                        }
                        else if (i < originalLines.length && (j >= newLines.length || originalLines[i] !== newLines[j])) {
                            diffLines.push(`-${originalLines[i]}`);
                            i++;
                        }
                        else {
                            diffLines.push(`+${newLines[j]}`);
                            j++;
                        }
                    }
                    const diff = diffLines.join('\n');
                    // Write the modified content if any edits succeeded
                    if (editsApplied > 0) {
                        const writeResult = await apiService.writeFile(filePath, currentContent, {
                            encoding: 'utf-8',
                            overwrite: true
                        });
                        console.log('[AgentPanel] multiedit_file result:', writeResult, 'applied:', editsApplied, 'failed:', editsFailed);
                        resumeDecision = 'edit';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                ...writeResult,
                                diff,
                                edits_applied: editsApplied,
                                edits_failed: editsFailed,
                                failed_details: failedEdits,
                                lines_added: newLines.length - originalLines.length > 0 ? newLines.length - originalLines.length : 0,
                                lines_removed: originalLines.length - newLines.length > 0 ? originalLines.length - newLines.length : 0,
                            }
                        };
                    }
                    else {
                        throw new Error(`All ${edits.length} edits failed: ${failedEdits.join('; ')}`);
                    }
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'Multi-edit failed';
                    console.error('[AgentPanel] multiedit_file error:', error);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, error: message, edits_applied: 0, edits_failed: 0 }
                    };
                }
            }
            else if (interrupt.action === 'diagnostics_tool') {
                // Handle diagnostics_tool - get LSP diagnostics via LSP Bridge
                try {
                    setDebugStatus({ status: 'LSP 진단 조회 중...', icon: 'diagnostics' });
                    const filePath = interrupt.args?.path || null;
                    const severityFilter = interrupt.args?.severity_filter || null;
                    // Get LSP Bridge instance
                    const lspBridge = window._hdspLSPBridge;
                    if (lspBridge && lspBridge.isLSPAvailable()) {
                        const result = await lspBridge.getDiagnostics(filePath);
                        // Apply severity filter if specified
                        let diagnostics = result.diagnostics;
                        if (severityFilter) {
                            diagnostics = diagnostics.filter((d) => d.severity === severityFilter);
                        }
                        resumeDecision = 'approve';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                success: true,
                                lsp_available: true,
                                diagnostics
                            }
                        };
                    }
                    else {
                        // LSP not available - return empty result
                        console.log('[AgentPanel] LSP not available, returning empty diagnostics');
                        resumeDecision = 'approve';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                success: true,
                                lsp_available: false,
                                diagnostics: []
                            }
                        };
                    }
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'Diagnostics failed';
                    console.error('[AgentPanel] diagnostics_tool error:', error);
                    resumeDecision = 'approve';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, lsp_available: false, error: message, diagnostics: [] }
                    };
                }
            }
            else if (interrupt.action === 'references_tool') {
                // Handle references_tool - find symbol references
                try {
                    setDebugStatus({ status: '참조 검색 중...', icon: 'search' });
                    const symbol = interrupt.args?.symbol || '';
                    const filePath = interrupt.args?.path || null;
                    // Get LSP Bridge instance
                    const lspBridge = window._hdspLSPBridge;
                    if (lspBridge && lspBridge.isLSPAvailable()) {
                        const result = await lspBridge.getReferences(symbol, filePath, interrupt.args?.line, interrupt.args?.character);
                        resumeDecision = 'approve';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                success: result.success,
                                lsp_available: true,
                                locations: result.locations,
                                used_grep: false
                            }
                        };
                    }
                    else {
                        // LSP not available - suggest using grep tool
                        console.log('[AgentPanel] LSP not available for references, suggesting grep fallback');
                        resumeDecision = 'approve';
                        resumeArgs = {
                            ...interrupt.args,
                            execution_result: {
                                success: false,
                                lsp_available: false,
                                locations: [],
                                used_grep: false
                            }
                        };
                    }
                }
                catch (error) {
                    const message = error instanceof Error ? error.message : 'References search failed';
                    console.error('[AgentPanel] references_tool error:', error);
                    resumeDecision = 'approve';
                    resumeArgs = {
                        ...interrupt.args,
                        execution_result: { success: false, lsp_available: false, error: message, locations: [] }
                    };
                }
            }
            else if (interrupt.action === 'jupyter_cell_tool' && interrupt.args?.code) {
                const code = interrupt.args.code;
                console.log('[AgentPanel] jupyter_cell_tool: shouldExecuteInNotebook=', shouldExecuteInNotebook(code));
                // Wrap entire cell execution in try-catch to guarantee resumeAgent is always called.
                // Without this, any exception during cell execution would prevent resume → agent hangs.
                try {
                    if (!shouldExecuteInNotebook(code)) {
                        setDebugStatus({ status: '서브프로세스로 코드 실행 중...', icon: 'terminal' });
                        const subCmd = isShellCell(code) ? extractShellCommand(code) : buildPythonCommand(code);
                        const subOutputId = subCmd ? createCommandOutputMessage(subCmd) : null;
                        const execResult = await executeCodeViaSubprocess(code, interrupt.args?.timeout, subOutputId
                            ? (chunk) => appendCommandOutputMessage(subOutputId, chunk.text, chunk.stream)
                            : undefined);
                        console.log('[AgentPanel] jupyter_cell subprocess result:', JSON.stringify(execResult).slice(0, 200));
                        resumeDecision = 'edit';
                        resumeArgs = {
                            code,
                            execution_result: execResult
                        };
                    }
                    else {
                        const executed = await executePendingApproval();
                        console.log('[AgentPanel] executePendingApproval result:', executed ? `tool=${executed.tool}` : 'null');
                        if (executed && executed.tool === 'jupyter_cell') {
                            const execResult = executed.execution_result;
                            console.log('[AgentPanel] jupyter_cell exec result: success=', execResult?.success, 'error=', execResult?.error?.slice?.(0, 100));
                            resumeDecision = 'edit';
                            resumeArgs = {
                                code: executed.code,
                                execution_result: execResult
                            };
                        }
                        else {
                            const notebook = getActiveNotebookPanel();
                            console.log('[AgentPanel] fallback: notebook=', !!notebook);
                            if (!notebook) {
                                setDebugStatus({ status: '노트북이 없어 서브프로세스로 실행 중...', icon: 'terminal' });
                                const nbCmd = isShellCell(code) ? extractShellCommand(code) : buildPythonCommand(code);
                                const nbOutputId = nbCmd ? createCommandOutputMessage(nbCmd) : null;
                                const execResult = await executeCodeViaSubprocess(code, interrupt.args?.timeout, nbOutputId
                                    ? (chunk) => appendCommandOutputMessage(nbOutputId, chunk.text, chunk.stream)
                                    : undefined);
                                resumeDecision = 'edit';
                                resumeArgs = {
                                    code,
                                    execution_result: execResult
                                };
                            }
                            else {
                                const cellIndex = insertCell(notebook, 'code', code);
                                if (cellIndex === null) {
                                    setDebugStatus({ status: '노트북 모델이 없어 서브프로세스로 실행 중...', icon: 'terminal' });
                                    const mdlCmd = isShellCell(code) ? extractShellCommand(code) : buildPythonCommand(code);
                                    const mdlOutputId = mdlCmd ? createCommandOutputMessage(mdlCmd) : null;
                                    const execResult = await executeCodeViaSubprocess(code, interrupt.args?.timeout, mdlOutputId
                                        ? (chunk) => appendCommandOutputMessage(mdlOutputId, chunk.text, chunk.stream)
                                        : undefined);
                                    resumeDecision = 'edit';
                                    resumeArgs = {
                                        code,
                                        execution_result: execResult
                                    };
                                }
                                else {
                                    await executeCell(notebook, cellIndex);
                                    const execResult = captureExecutionResult(notebook, cellIndex);
                                    resumeDecision = 'edit';
                                    resumeArgs = {
                                        code,
                                        execution_result: execResult
                                    };
                                }
                            }
                        }
                    }
                }
                catch (cellError) {
                    // Catch-all: ensure resume always happens even if cell execution throws
                    const errMsg = cellError instanceof Error ? cellError.message : String(cellError);
                    console.error('[AgentPanel] jupyter_cell_tool execution error (will still resume):', cellError);
                    resumeDecision = 'edit';
                    resumeArgs = {
                        code,
                        execution_result: { success: false, error: errMsg, error_type: 'FrontendExecutionError' }
                    };
                }
            }
            else if (interrupt.action === 'ask_user_tool') {
                // Handle ask_user_tool - pass user's response back to the agent
                // The feedback parameter contains the user's response from handleSendMessage
                console.log('[AgentPanel] ask_user_tool approve with user response:', feedback);
                resumeDecision = 'edit';
                resumeArgs = {
                    ...interrupt.args,
                    user_response: feedback || ''
                };
            }
            else {
                const executed = await executePendingApproval();
                if (executed && executed.tool === 'jupyter_cell') {
                    resumeDecision = 'edit';
                    resumeArgs = {
                        code: executed.code,
                        execution_result: executed.execution_result
                    };
                }
                else if (executed && executed.tool === 'markdown') {
                    resumeDecision = 'edit';
                    resumeArgs = {
                        content: executed.content
                    };
                }
            }
        }
        else {
            // Reject: delete the pending cell from notebook
            const pendingCall = pendingToolCallsRef.current[0];
            if (pendingCall && pendingCall.cellIndex !== undefined) {
                const notebook = getActiveNotebookPanel();
                if (notebook) {
                    deleteCell(notebook, pendingCall.cellIndex);
                }
            }
            pendingToolCallsRef.current.shift();
            approvalPendingRef.current = pendingToolCallsRef.current.length > 0;
        }
        setIsLoading(true);
        setIsStreaming(true);
        let interrupted = false;
        // 항상 새 메시지 생성 - 승인 UI 아래에 append되도록
        const assistantMessageId = makeMessageId('assistant');
        setStreamingMessageId(assistantMessageId);
        // 새 메시지 추가 (맨 아래에 append)
        setMessages(prev => [
            ...prev,
            {
                id: assistantMessageId,
                role: 'assistant',
                content: '',
                timestamp: Date.now()
            }
        ]);
        let streamedContent = '';
        // Build feedback message for rejection
        const rejectionFeedback = resumeDecision === 'reject'
            ? (feedback ? `사용자 피드백: ${feedback}` : 'User rejected this action')
            : undefined;
        console.log('[AgentPanel] CALLING resumeAgent: decision=', resumeDecision, 'args_keys=', resumeArgs ? Object.keys(resumeArgs) : 'none', 'exec_result_success=', resumeArgs?.execution_result?.success);
        try {
            await apiService.resumeAgent(threadId, resumeDecision, resumeArgs, rejectionFeedback, getEffectiveLLMConfig(), (chunk) => {
                streamedContent += chunk;
                setMessages(prev => prev.map(msg => msg.id === assistantMessageId && isChatMessage(msg)
                    ? { ...msg, content: streamedContent }
                    : msg));
            }, (status) => {
                setDebugStatus(status);
            }, (nextInterrupt) => {
                interrupted = true;
                approvalPendingRef.current = true;
                const autoApproveEnabled = getAutoApproveEnabled(llmConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.getDefaultLLMConfig)());
                // Auto-approve search/file/resource tools
                if (nextInterrupt.action === 'search_notebook_cells_tool'
                    || nextInterrupt.action === 'check_resource_tool'
                    || nextInterrupt.action === 'read_file_tool'
                    || nextInterrupt.action === 'list_workspace_tool'
                    || nextInterrupt.action === 'search_files_tool') {
                    void handleAutoToolInterrupt(nextInterrupt);
                    return;
                }
                // Auto-approve jupyter_cell READ operations (non-destructive)
                if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.operation === 'READ') {
                    console.log('[AgentPanel] Auto-approving jupyter_cell READ operation (resume)');
                    resumeFromInterrupt(nextInterrupt, 'approve').catch(err => {
                        console.error('[AgentPanel] jupyter_cell READ auto-approve FAILED (resume):', err);
                    });
                    return;
                }
                // Handle ask_user_tool - show input UI
                if (nextInterrupt.action === 'ask_user_tool') {
                    console.log('[AgentPanel] ask_user_tool interrupt (resume callback):', nextInterrupt.args);
                    setIsAskUserMode(true);
                    setPendingAskUserInterrupt(nextInterrupt);
                    setIsLoading(false);
                    setIsStreaming(false);
                    // Display the question as an assistant message
                    const question = nextInterrupt.args?.question || '응답을 입력하세요...';
                    const options = nextInterrupt.args?.options;
                    const inputType = nextInterrupt.args?.input_type || 'text';
                    let questionContent = `❓ **${question}**`;
                    if (options && options.length > 0) {
                        questionContent += '\n\n선택지:\n' + options.map((opt, i) => `${i + 1}. ${opt}`).join('\n');
                    }
                    if (inputType === 'file') {
                        questionContent += '\n\n_(파일을 업로드하거나 파일 경로를 입력하세요)_';
                    }
                    const askUserMessage = {
                        id: makeMessageId('ask_user'),
                        role: 'assistant',
                        content: questionContent,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, askUserMessage]);
                    // Focus on input and set placeholder to the question
                    setTimeout(() => {
                        const textarea = document.querySelector('.jp-agent-input');
                        if (textarea) {
                            textarea.focus();
                            textarea.placeholder = question;
                        }
                    }, 100);
                    return;
                }
                if (autoApproveEnabled) {
                    // 자동 승인 모드일 때도 인터럽트 메시지를 생성하여 코드블럭으로 표시
                    upsertInterruptMessage(nextInterrupt, true);
                    // jupyter_cell_tool인 경우 먼저 셀 생성 후 승인 진행
                    if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.code) {
                        const shouldQueue = shouldExecuteInNotebook(nextInterrupt.args.code);
                        if (shouldQueue) {
                            queueApprovalCell(nextInterrupt.args.code);
                        }
                    }
                    resumeFromInterrupt(nextInterrupt, 'approve').catch(err => {
                        console.error('[AgentPanel] nested resumeFromInterrupt FAILED:', err);
                    });
                    return;
                }
                if (nextInterrupt.action === 'jupyter_cell_tool' && nextInterrupt.args?.code) {
                    const shouldQueue = shouldExecuteInNotebook(nextInterrupt.args.code);
                    if (isAutoApprovedCode(nextInterrupt.args.code)) {
                        if (shouldQueue) {
                            queueApprovalCell(nextInterrupt.args.code);
                        }
                        resumeFromInterrupt(nextInterrupt, 'approve').catch(err => {
                            console.error('[AgentPanel] nested resumeFromInterrupt FAILED:', err);
                        });
                        return;
                    }
                    if (shouldQueue) {
                        queueApprovalCell(nextInterrupt.args.code);
                    }
                }
                setInterruptData(nextInterrupt);
                upsertInterruptMessage(nextInterrupt);
                setIsLoading(false);
                setIsStreaming(false);
            }, (newTodos) => {
                setTodos(newTodos);
            }, () => {
                setDebugStatus(null);
            }, handleToolCall, interruptActionCount, abortControllerRef.current?.signal);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'Failed to resume';
            setDebugStatus(`오류: ${message}`);
            console.error('Resume failed:', error);
            setMessages(prev => [
                ...prev,
                {
                    id: makeMessageId(),
                    role: 'assistant',
                    content: `Error: ${message}`,
                    timestamp: Date.now()
                }
            ]);
        }
        finally {
            if (!interrupted) {
                // 마지막 resume — 체인된 resume 없으므로 모든 상태 정리
                setIsLoading(false);
                setIsStreaming(false);
                setStreamingMessageId(null);
                approvalPendingRef.current = false;
            }
            // interrupted=true면 체인된 resume가 로딩 상태를 관리
        }
    };
    // ═══════════════════════════════════════════════════════════════════════════
    // /review 코드리뷰 헬퍼 함수들
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * 리뷰용 셀 출력 정규화: 실행 카운트, 타임스탬프 등 비결정적 요소를 제거하여
     * 동일 코드에 대해 안정적인 LLM 입력을 생성한다.
     */
    const normalizeOutput = (output) => {
        return output
            // 실행 카운트 정규화: Out[123] → Out[...]
            .replace(/Out\[\d+\]/g, 'Out[...]')
            // In[123] 정규화
            .replace(/In\[\d+\]/g, 'In[...]')
            // 타임스탬프 패턴 정규화
            .replace(/\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?/g, '[TIMESTAMP]')
            // trailing whitespace 정규화
            .replace(/[ \t]+$/gm, '');
    };
    const buildNotebookContent = (cells) => {
        const totalCells = cells.length;
        const cellsWithErrors = cells.filter(cell => cell.output && (cell.output.includes('Error') ||
            cell.output.includes('Traceback') ||
            cell.output.includes('Exception'))).length;
        const cellsWithImports = cells.filter(cell => cell.imports && cell.imports.length > 0).length;
        const localImports = cells.reduce((acc, cell) => {
            if (cell.imports) {
                return acc + cell.imports.filter((imp) => imp.isLocal).length;
            }
            return acc;
        }, 0);
        const moduleSummary = cells._moduleSummary || {};
        const crossCellDeps = cells._crossCellDeps || [];
        const transitiveModuleSources = cells._transitiveModuleSources || {};
        const directModuleCount = Object.values(moduleSummary).filter((m) => m.depth === 1 || !m.depth).length;
        const transitiveModuleCount = Object.values(moduleSummary).filter((m) => m.depth === 2).length;
        const modulesWithSource = directModuleCount + transitiveModuleCount;
        const shownModules = new Set();
        let content = `다음은 저장하기 전의 Jupyter 노트북 전체 내용입니다.

## 노트북 요약
- 전체 셀 수: ${totalCells}개
- 에러가 있는 셀: ${cellsWithErrors}개
- Import가 있는 셀: ${cellsWithImports}개
- 로컬 모듈 import: ${localImports}개 (직접: ${directModuleCount}개, 간접: ${transitiveModuleCount}개)
- 셀 간 의존 관계: ${crossCellDeps.length}개

## 전체 셀 내용

`;
        cells.forEach((cell, index) => {
            content += `### 셀 ${index + 1} (ID: ${cell.id})
\`\`\`python
${cell.content}
\`\`\`
`;
            if (cell.output) {
                content += `
**실행 결과:**
\`\`\`
${normalizeOutput(cell.output)}
\`\`\`
`;
            }
            if (cell.imports && cell.imports.length > 0) {
                content += `
**Imports:**
`;
                cell.imports.forEach((imp) => {
                    content += `- \`${imp.module}\` (${imp.isLocal ? '로컬' : '표준 라이브러리'})\n`;
                });
            }
            if (cell.localModuleSources && Object.keys(cell.localModuleSources).length > 0) {
                for (const [mod, source] of Object.entries(cell.localModuleSources)) {
                    if (!shownModules.has(mod)) {
                        content += `\n**로컬 모듈 \`${mod}\` 소스:**\n\`\`\`python\n${source}\n\`\`\`\n`;
                        shownModules.add(mod);
                    }
                }
            }
            content += '\n---\n\n';
        });
        // Append transitive (depth-2) module sources
        const transitiveEntries = Object.entries(transitiveModuleSources);
        if (transitiveEntries.length > 0) {
            content += `## 간접 Import 모듈 소스 (2단계)\n\n`;
            for (const [mod, source] of transitiveEntries) {
                if (!shownModules.has(mod)) {
                    const info = moduleSummary[mod];
                    const importedBy = info?.importedBy ? ` (imported by \`${info.importedBy}\`)` : '';
                    content += `### 모듈 \`${mod}\`${importedBy}\n\`\`\`python\n${source}\n\`\`\`\n\n`;
                    shownModules.add(mod);
                }
            }
        }
        return content;
    };
    const executeReviewCalls = async (callPlan, perspectives, commonRules, content, sendFn) => {
        // 코드리뷰 안내 메시지 표시
        const introMsg = {
            id: makeMessageId('review-intro'),
            role: 'assistant',
            content: '코드리뷰를 시작합니다. 아래 **4가지 관점**으로 분석합니다.\n\n' +
                '| 순서 | 섹션 | 설명 |\n' +
                '|:---:|------|------|\n' +
                '| 1 | **보안** | 코드 내 취약점 점검 |\n' +
                '| 2 | **성능개선** | 코드 성능 최적화 |\n' +
                '| 3 | **코드품질** | 코드 구조, 일관성, 에러 처리, 네이밍 점검 |\n' +
                '| 4 | **요약** | 1~3을 셀단위로 요약 |\n',
            timestamp: Date.now(),
        };
        setMessages(prev => [...prev, introMsg]);
        const priorResults = [];
        for (let i = 0; i < callPlan.length; i++) {
            const plan = callPlan[i];
            const selectedPrompts = plan.perspectiveIndices
                .map(idx => perspectives[idx].prompt)
                .join('\n\n');
            const sectionLabels = plan.perspectiveIndices.map(idx => perspectives[idx].label).join(', ');
            const isLastCall = i === callPlan.length - 1;
            let llmPrompt;
            if (isLastCall && priorResults.length > 0) {
                // 요약 호출: 이전 분석 결과를 컨텍스트로 주입하되, 원본 코드는 생략하여 토큰 절약
                // 각 관점당 최대 ~6000자 (약 2000토큰) → 3개 합계 ~18000자
                const MAX_CHARS_PER_RESULT = 6000;
                const truncated = priorResults.map(r => {
                    if (r.length <= MAX_CHARS_PER_RESULT)
                        return r;
                    const cut = r.slice(0, MAX_CHARS_PER_RESULT);
                    const lastNewline = cut.lastIndexOf('\n');
                    return (lastNewline > 0 ? cut.slice(0, lastNewline) : cut) + '\n\n… (이하 생략)';
                });
                llmPrompt =
                    '## 이전 분석 결과\n' +
                        '아래는 이전 호출에서 수행된 보안·성능·코드 품질 분석 결과입니다. ' +
                        '이 결과에서 수정이 제안된 모든 셀에 대해 개선 코드를 제시하세요.\n\n' +
                        truncated.join('\n\n---\n\n') +
                        '\n\n## 코드리뷰 요청 사항\n' +
                        `이 요청은 ${callPlan.length}개 호출 중 ${i + 1}번째입니다. "${sectionLabels}" 섹션만 작성하세요.\n` +
                        '다른 섹션(이전 호출에서 이미 분석됨)은 절대 포함하지 마세요.\n\n' +
                        selectedPrompts +
                        '\n' +
                        commonRules;
            }
            else {
                llmPrompt =
                    content +
                        '\n## 코드리뷰 요청 사항\n' +
                        `이 요청은 ${callPlan.length}개 호출 중 ${i + 1}번째입니다. "${sectionLabels}" 섹션만 작성하세요.\n` +
                        '다른 섹션(이전 호출에서 이미 분석됨)은 절대 포함하지 마세요.\n\n' +
                        selectedPrompts +
                        '\n' +
                        commonRules;
            }
            const displayPrompt = `${plan.displayLabel} [${i + 1}/${callPlan.length}]`;
            for (let attempt = 0; attempt < 2; attempt++) {
                try {
                    const response = await sendFn({
                        displayContent: displayPrompt,
                        llmPrompt,
                        clearInput: false,
                        maxTokens: REVIEW_MAX_TOKENS,
                        freshConversation: true,
                    });
                    if (response && !isLastCall) {
                        priorResults.push(response);
                    }
                    break;
                }
                catch (error) {
                    if (attempt === 0) {
                        console.warn(`[AgentPanel] Review call ${i + 1} failed, retrying in 2s...`, error);
                        await new Promise(r => setTimeout(r, 2000));
                    }
                    else {
                        console.error(`[AgentPanel] Review call ${i + 1} failed after retry:`, error);
                        const errMsg = {
                            id: makeMessageId(`review-error-${i}`),
                            role: 'assistant',
                            content: `⚠️ **${plan.displayLabel}** 분석 중 오류가 발생했습니다. (${error instanceof Error ? error.message : 'network error'})\n\n다른 섹션은 계속 진행합니다.`,
                            timestamp: Date.now(),
                        };
                        setMessages(prev => [...prev, errMsg]);
                    }
                }
            }
        }
        // 코드리뷰 완료 메시지
        const doneMsg = {
            id: makeMessageId('review-done'),
            role: 'assistant',
            content: '✅ **코드리뷰가 완료되었습니다.**',
            timestamp: Date.now(),
        };
        setMessages(prev => [...prev, doneMsg]);
    };
    const handleSendMessage = async () => {
        // Handle rejection mode - resume with optional feedback
        if (isRejectionMode && pendingRejectionInterrupt) {
            const feedback = input.trim() || undefined; // Empty input means no feedback
            // Add user message bubble if there's feedback
            if (feedback) {
                const userMessage = {
                    id: makeMessageId(),
                    role: 'user',
                    content: feedback,
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, userMessage]);
            }
            setInput('');
            setIsRejectionMode(false);
            const interruptToResume = pendingRejectionInterrupt;
            setPendingRejectionInterrupt(null);
            await resumeFromInterrupt(interruptToResume, 'reject', feedback);
            return;
        }
        // Handle ask_user mode - pass user's response to the agent
        if (isAskUserMode && pendingAskUserInterrupt) {
            const userResponse = input.trim();
            if (!userResponse) {
                // User submitted empty input - prompt them
                return;
            }
            // Add user message bubble
            const userMessage = {
                id: makeMessageId(),
                role: 'user',
                content: userResponse,
                timestamp: Date.now(),
            };
            setMessages(prev => [...prev, userMessage]);
            setInput('');
            setIsAskUserMode(false);
            const interruptToResume = pendingAskUserInterrupt;
            setPendingAskUserInterrupt(null);
            // Reset textarea placeholder
            setTimeout(() => {
                const textarea = document.querySelector('.jp-agent-input');
                if (textarea) {
                    textarea.placeholder = '메세지를 입력하세요.';
                }
            }, 100);
            // Resume with user response passed as feedback
            await resumeFromInterrupt(interruptToResume, 'approve', userResponse);
            return;
        }
        // Check if there's an LLM prompt stored (from cell action)
        const textarea = messagesEndRef.current?.parentElement?.querySelector('.jp-agent-input');
        const llmPrompt = pendingLlmPromptRef.current || textarea?.getAttribute('data-llm-prompt');
        // Allow execution if we have an LLM prompt even if input is empty (for auto-execution)
        if ((!input.trim() && !llmPrompt) || isLoading || isStreaming || isAgentRunning)
            return;
        const currentInput = input.trim();
        // /review 명령어 처리
        if (currentInput.startsWith('/review')) {
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('cmd_review', {
                input_mode: inputMode,
                has_file_arg: currentInput.includes('@file:'),
            });
            const rest = currentInput.replace(/^\/review\s*/, '').trim();
            const fileMatch = rest.match(/@file:(\S+)/);
            if (fileMatch) {
                // /review @file:path — 특정 파일 코드리뷰
                const filePath = fileMatch[1];
                const readResult = await apiService.readFile(filePath);
                if (!readResult.success || !readResult.content) {
                    const errorMsg = {
                        id: makeMessageId(),
                        role: 'assistant',
                        content: `파일을 읽을 수 없습니다: ${readResult.error || filePath}`,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, errorMsg]);
                    setInput('');
                    return;
                }
                let enrichedModules = '';
                if (filePath.endsWith('.py')) {
                    try {
                        const app = window.jupyterapp;
                        const serverSettings = app?.serviceManager?.serverSettings;
                        const baseUrl = serverSettings?.baseUrl || '/';
                        const enrichResponse = await fetch(`${baseUrl}hdsp-agent/file/enrich`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ filePath }),
                        });
                        if (enrichResponse.ok) {
                            const enrichData = await enrichResponse.json();
                            const allSources = { ...(enrichData.moduleSources || {}), ...(enrichData.transitiveModuleSources || {}) };
                            const summary = enrichData.moduleSummary || {};
                            for (const [mod, source] of Object.entries(allSources)) {
                                const info = summary[mod] || {};
                                const depthLabel = info.depth === 2
                                    ? `간접 import (imported by \`${info.importedBy}\`)`
                                    : '직접 import';
                                enrichedModules += `\n### 로컬 모듈 \`${mod}\` (${depthLabel})\n\`\`\`python\n${source}\n\`\`\`\n`;
                            }
                        }
                    }
                    catch (e) {
                        console.warn('[Review] File enrich failed:', e);
                    }
                }
                const fileContent = `다음은 코드리뷰 대상 파일입니다.

## 파일 정보
- 파일 경로: ${filePath}

## 파일 내용

\`\`\`python
${readResult.content}
\`\`\`
${enrichedModules}`;
                const lines = readResult.content.split('\n').length;
                const { callPlan, perspectives, commonRules } = buildReviewPrompts(fileContent, lines);
                // 유저 메시지 표시
                const userMessage = {
                    id: makeMessageId(),
                    role: 'user',
                    content: currentInput,
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, userMessage]);
                setInput('');
                await executeReviewCalls(callPlan, perspectives, commonRules, fileContent, sendChatMessage);
                return;
            }
            // /review — 현재 활성 탭 코드리뷰 (노트북 또는 일반 파일)
            const app = window.jupyterapp;
            const currentWidget = app?.shell?.currentWidget;
            const activeFilePath = (currentWidget && 'context' in currentWidget)
                ? currentWidget.context?.path || null
                : null;
            if (!activeFilePath) {
                const errorMsg = {
                    id: makeMessageId(),
                    role: 'assistant',
                    content: '사용법:\n- `/review` — 현재 활성 탭 코드리뷰 (노트북 또는 파일)\n- `/review @file:경로` — 특정 파일 코드리뷰\n\n예시:\n- `/review`\n- `/review @file:utils.py`\n- `/review @file:src/analysis.py`',
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, errorMsg]);
                setInput('');
                return;
            }
            if (activeFilePath.endsWith('.ipynb')) {
                // 노트북 리뷰 흐름
                const panel = getActiveNotebookPanel();
                if (!panel) {
                    setInput('');
                    return;
                }
                const serverSettings = app?.serviceManager?.serverSettings;
                const { collectAllCodeCells } = await Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ../plugins/save-interceptor-plugin */ "./lib/plugins/save-interceptor-plugin.js"));
                const cells = await collectAllCodeCells(panel, serverSettings, activeFilePath);
                if (cells.length === 0) {
                    const errorMsg = {
                        id: makeMessageId(),
                        role: 'assistant',
                        content: '노트북에 코드 셀이 없습니다.',
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, errorMsg]);
                    setInput('');
                    return;
                }
                const notebookContent = buildNotebookContent(cells);
                const { callPlan, perspectives, commonRules } = buildReviewPrompts(notebookContent, cells.length);
                const userMessage = {
                    id: makeMessageId(),
                    role: 'user',
                    content: currentInput,
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, userMessage]);
                setInput('');
                await executeReviewCalls(callPlan, perspectives, commonRules, notebookContent, sendChatMessage);
            }
            else {
                // 일반 파일 리뷰 흐름
                const readResult = await apiService.readFile(activeFilePath);
                if (!readResult.success || !readResult.content) {
                    const errorMsg = {
                        id: makeMessageId(),
                        role: 'assistant',
                        content: `파일을 읽을 수 없습니다: ${readResult.error || activeFilePath}`,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, errorMsg]);
                    setInput('');
                    return;
                }
                const ext = activeFilePath.split('.').pop() || '';
                const langMap = { py: 'python', js: 'javascript', ts: 'typescript', jsx: 'jsx', tsx: 'tsx', java: 'java', sql: 'sql', sh: 'bash', yaml: 'yaml', yml: 'yaml', json: 'json' };
                const lang = langMap[ext] || ext;
                let enrichedModules = '';
                if (ext === 'py') {
                    try {
                        const enrichResponse = await fetch(`${app?.serviceManager?.serverSettings?.baseUrl || '/'}hdsp-agent/file/enrich`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ filePath: activeFilePath }),
                        });
                        if (enrichResponse.ok) {
                            const enrichData = await enrichResponse.json();
                            const allSources = { ...(enrichData.moduleSources || {}), ...(enrichData.transitiveModuleSources || {}) };
                            const summary = enrichData.moduleSummary || {};
                            for (const [mod, source] of Object.entries(allSources)) {
                                const info = summary[mod] || {};
                                const depthLabel = info.depth === 2
                                    ? `간접 import (imported by \`${info.importedBy}\`)`
                                    : '직접 import';
                                enrichedModules += `\n### 로컬 모듈 \`${mod}\` (${depthLabel})\n\`\`\`python\n${source}\n\`\`\`\n`;
                            }
                        }
                    }
                    catch (e) {
                        console.warn('[Review] File enrich failed:', e);
                    }
                }
                const fileContent = `다음은 코드리뷰 대상 파일입니다.\n\n## 파일 정보\n- 파일 경로: ${activeFilePath}\n\n## 파일 내용\n\n\`\`\`${lang}\n${readResult.content}\n\`\`\`\n${enrichedModules}`;
                const lines = readResult.content.split('\n').length;
                const { callPlan, perspectives, commonRules } = buildReviewPrompts(fileContent, lines);
                const userMessage = {
                    id: makeMessageId(),
                    role: 'user',
                    content: currentInput,
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, userMessage]);
                setInput('');
                await executeReviewCalls(callPlan, perspectives, commonRules, fileContent, sendChatMessage);
            }
            return;
        }
        // /unittest 명령어 처리
        if (currentInput.startsWith('/unittest')) {
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('cmd_unittest', {
                input_mode: inputMode,
                has_file_arg: currentInput.includes('@file:'),
            });
            const rest = currentInput.replace(/^\/unittest\s*/, '').trim();
            const fileMatch = rest.match(/@file:(\S+)/);
            let filePath;
            let additionalInstructions;
            if (fileMatch) {
                // @file: 멘션이 있는 경우
                filePath = fileMatch[1];
                additionalInstructions = rest.replace(/@file:\S+/, '').trim();
            }
            else {
                // @file: 없음 → 활성 탭에서 자동 감지
                const app = window.jupyterapp;
                let activeFilePath = null;
                // 1. app.shell.currentWidget에서 파일 경로 추출
                const currentWidget = app?.shell?.currentWidget;
                if (currentWidget && 'context' in currentWidget) {
                    activeFilePath = currentWidget.context?.path || null;
                }
                // 2. notebookTracker fallback
                if (!activeFilePath) {
                    activeFilePath = notebookTracker?.currentWidget?.context?.path || null;
                }
                if (!activeFilePath) {
                    const errorMsg = {
                        id: makeMessageId(),
                        role: 'assistant',
                        content: '테스트할 파일을 지정하거나 파일 탭을 열어주세요.\n\n사용법:\n- `/unittest @file:utils.py`\n- `/unittest` (활성 탭의 파일 자동 인식)\n- `/unittest @file:src/main.py edge case 위주로`',
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, errorMsg]);
                    setInput('');
                    return;
                }
                filePath = activeFilePath;
                additionalInstructions = rest;
            }
            // 파일 내용을 미리 읽어서 프롬프트에 포함 (LLM이 read_file 호출 불필요)
            let readResult = await apiService.readFile(filePath);
            // 직접 경로로 실패 시 → 파일명으로 워크스페이스 전체 검색
            if (!readResult.success || !readResult.content) {
                const fileName = filePath.split('/').pop() || filePath;
                try {
                    const searchResult = await apiService.getContextAutocomplete({
                        partialCommand: `@file:${fileName}`,
                        baseDir: '',
                    });
                    if (searchResult?.options?.length > 0) {
                        // 파일명이 정확히 일치하는 결과 우선, 없으면 첫 번째 결과 사용
                        const matched = searchResult.options.find((opt) => opt.label?.endsWith(`/${fileName}`) || opt.label === `@file:${fileName}`) || searchResult.options[0];
                        if (matched?.label) {
                            const resolvedPath = matched.label.replace(/^@file:/, '');
                            readResult = await apiService.readFile(resolvedPath);
                            if (readResult.success && readResult.content) {
                                filePath = resolvedPath;
                            }
                        }
                    }
                }
                catch (e) {
                    console.warn('[AgentPanel] File search fallback failed:', e);
                }
            }
            if (!readResult.success || !readResult.content) {
                const errorMsg = {
                    id: makeMessageId(),
                    role: 'assistant',
                    content: `파일을 읽을 수 없습니다: ${readResult.error || filePath}`,
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, errorMsg]);
                setInput('');
                return;
            }
            // LLM에게 보낼 프롬프트 구성 (파일 내용 포함)
            let llmMessage = `[UNITTEST] 다음 파일의 pytest 유닛테스트를 생성하세요.\n파일 경로: ${filePath}\n\n--- 파일 내용 ---\n${readResult.content}\n--- 파일 끝 ---`;
            if (additionalInstructions) {
                llmMessage += `\n추가 지시: ${additionalInstructions}`;
            }
            await sendChatMessage({
                displayContent: currentInput,
                llmPrompt: llmMessage,
                clearInput: true,
            });
            return;
        }
        // /create-notebook 명령어 처리
        if (currentInput.startsWith('/create-notebook')) {
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('cmd_create_notebook', {
                input_mode: inputMode,
            });
            const prompt = currentInput.replace(/^\/create-notebook\s*/, '').trim();
            if (!prompt) {
                const errorMsg = {
                    id: makeMessageId(),
                    role: 'assistant',
                    content: '사용법: `/create-notebook <프롬프트>`\n\n예시: `/create-notebook 타이타닉 데이터 분석하는 노트북 만들어줘`',
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, errorMsg]);
                setInput('');
                return;
            }
            // 유저 메시지 표시
            const userMessage = {
                id: makeMessageId(),
                role: 'user',
                content: currentInput,
                timestamp: Date.now(),
            };
            setMessages(prev => [...prev, userMessage]);
            setInput('');
            // JupyterLab 커맨드로 노트북 생성 (TaskManagerWidget의 진행 팝업 재사용)
            try {
                const app = window.jupyterapp;
                await app.commands.execute('hdsp-agent:generate-from-prompt', { prompt });
                const assistantMsg = {
                    id: makeMessageId(),
                    role: 'assistant',
                    content: `노트북 자동생성을 시작했습니다.\n\n프롬프트: "${prompt}"\n\n오른쪽 하단에서 진행 상태를 확인할 수 있습니다.`,
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, assistantMsg]);
            }
            catch (error) {
                const errorMsg = {
                    id: makeMessageId(),
                    role: 'assistant',
                    content: `노트북 생성 실패: ${error.message}`,
                    timestamp: Date.now(),
                };
                setMessages(prev => [...prev, errorMsg]);
            }
            return;
        }
        // Agent 모드이면 Agent 실행
        if (inputMode === 'agent') {
            // Use app.shell.currentWidget for reliable active tab detection
            const app = window.jupyterapp;
            let notebook = null;
            if (app?.shell?.currentWidget) {
                const currentWidget = app.shell.currentWidget;
                if ('content' in currentWidget && currentWidget.content?.model) {
                    notebook = currentWidget;
                }
            }
            if (!notebook) {
                notebook = notebookTracker?.currentWidget;
            }
            // 노트북이 없는 경우
            if (!notebook) {
                // [DISABLED] Python 에러가 감지되면 파일 수정 모드로 전환
                // 이 레거시 기능은 /file/action API가 구현되지 않아 비활성화됨
                // if (detectPythonError(currentInput)) {
                //   console.log('[AgentPanel] Agent mode: No notebook, but Python error detected - attempting file fix');
                //   const handled = await handlePythonErrorFix(currentInput);
                //   if (handled) {
                //     const userMessage: IChatMessage = {
                //       id: makeMessageId(),
                //       role: 'user',
                //       content: currentInput,
                //       timestamp: Date.now(),
                //     };
                //     setMessages(prev => [...prev, userMessage]);
                //     setInput('');
                //     return;
                //   }
                //   console.log('[AgentPanel] Agent mode: No file path found, continuing...');
                // }
                // 파일 수정 관련 자연어 요청 감지 (에러, 고쳐, 수정, fix 등)
                const fileFixRequestPatterns = [
                    /에러.*해결/i,
                    /에러.*고쳐/i,
                    /에러.*수정/i,
                    /오류.*해결/i,
                    /오류.*고쳐/i,
                    /오류.*수정/i,
                    /fix.*error/i,
                    /\.py.*에러/i,
                    /\.py.*오류/i,
                    /콘솔.*에러/i,
                    /console.*error/i,
                    /파일.*에러/i,
                    /파일.*오류/i,
                ];
                const isFileFixRequest = fileFixRequestPatterns.some(pattern => pattern.test(currentInput));
                if (isFileFixRequest) {
                    console.log('[AgentPanel] Agent mode: No notebook, file fix request detected - prompting for error details');
                    // User 메시지 추가
                    const userMessage = {
                        id: makeMessageId(),
                        role: 'user',
                        content: currentInput,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, userMessage]);
                    setInput('');
                    // 에러 메시지 요청 안내
                    const guideMessage = {
                        id: makeMessageId('guide'),
                        role: 'assistant',
                        content: `파일 에러 수정을 도와드리겠습니다!

**에러 메시지를 복사해서 붙여넣어 주세요.**

Console에서 발생한 에러 전체를 복사해주시면:
1. 에러가 발생한 파일을 자동으로 찾아서 읽고
2. 관련된 import 파일들도 함께 분석하여
3. 수정된 코드를 제안해 드립니다.

예시:
\`\`\`
$ python b.py
Traceback (most recent call last):
  File "a.py", line 3
    def foo(
          ^
SyntaxError: '(' was never closed
\`\`\``,
                        timestamp: Date.now(),
                    };
                    setMessages(prev => [...prev, guideMessage]);
                    return;
                }
                // 일반적인 요청은 Chat 모드로 fallback (sendChatMessage 사용)
                console.log('[AgentPanel] Agent mode: No notebook - using LangChain agent without notebook context');
            }
            // Agent 모드는 sendChatMessage를 통해 sendAgentV2Stream (LangChain) 사용
        }
        // [DISABLED] Python 에러 감지 및 파일 수정 모드 (Chat 모드에서만)
        // 이 레거시 기능은 /file/action API가 구현되지 않아 비활성화됨
        // LangChain agent의 edit_file_tool을 사용하도록 변경됨
        // if (inputMode === 'chat' && detectPythonError(currentInput)) {
        //   console.log('[AgentPanel] Python error detected in message, attempting file fix...');
        //   const handled = await handlePythonErrorFix(currentInput);
        //   if (handled) {
        //     const userMessage: IChatMessage = {
        //       id: makeMessageId(),
        //       role: 'user',
        //       content: currentInput,
        //       timestamp: Date.now(),
        //     };
        //     setMessages(prev => [...prev, userMessage]);
        //     setInput('');
        //     return;
        //   }
        //   console.log('[AgentPanel] No file path found in error, using regular LLM stream');
        // }
        // Use the display prompt (input) for the user message, or use a fallback if input is empty
        const displayContent = currentInput || (llmPrompt ? '셀 분석 요청' : '');
        await sendChatMessage({
            displayContent,
            llmPrompt,
            textarea,
            clearInput: Boolean(currentInput)
        });
    };
    // Handle resume after user approval/rejection
    const handleResumeAgent = async (decision) => {
        if (!interruptData)
            return;
        if (decision === 'reject') {
            // Enter rejection mode - wait for user feedback before resuming
            setIsRejectionMode(true);
            setPendingRejectionInterrupt(interruptData);
            // Clear the interrupt UI but keep the data for later, mark as rejected
            setInterruptData(null);
            clearInterruptMessage('reject'); // Pass 'reject' to show "거부됨"
            // Focus on input for user to provide feedback
            const textarea = document.querySelector('.jp-agent-input');
            if (textarea) {
                textarea.focus();
            }
            return;
        }
        await resumeFromInterrupt(interruptData, decision);
    };
    // Handle input change and track cursor position for autocomplete
    const handleInputChange = (e) => {
        const newValue = e.target.value;
        const newCursorPosition = e.target.selectionStart || 0;
        setInput(newValue);
        setCursorPosition(newCursorPosition);
        // Check if we should show autocomplete (when typing @ or / commands)
        // Find the start of the current word (from cursor back to whitespace)
        let wordStart = newCursorPosition;
        while (wordStart > 0 && !/\s/.test(newValue[wordStart - 1])) {
            wordStart--;
        }
        const currentWord = newValue.slice(wordStart, newCursorPosition);
        // Show autocomplete if current word starts with @ or /
        if (currentWord.startsWith('@') || currentWord.startsWith('/')) {
            setShowAutocomplete(true);
        }
        else {
            setShowAutocomplete(false);
        }
    };
    // Handle autocomplete selection
    // viaEnter: true = Enter key or click (final selection), false = Tab key (navigation)
    const handleAutocompleteSelect = async (option, viaEnter) => {
        // Check if this is an action command (like /reset, /compact)
        if (option.id === '/reset' && option.is_complete) {
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('cmd_reset', { input_mode: inputMode });
            // Execute reset action
            await executeResetAction();
            setShowAutocomplete(false);
            setHasAutocompleteOptions(false);
            setInput('');
            return;
        }
        if (option.id === '/help' && option.is_complete) {
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('cmd_help', { input_mode: inputMode });
            // Execute help action (no async, just display help message)
            executeHelpAction();
            setShowAutocomplete(false);
            setHasAutocompleteOptions(false);
            setInput('');
            return;
        }
        if (option.id === '/version' && option.is_complete) {
            executeVersionAction();
            setShowAutocomplete(false);
            setHasAutocompleteOptions(false);
            setInput('');
            return;
        }
        if (!textareaRef.current)
            return;
        const text = input;
        // Find the start of the current context command
        let start = cursorPosition;
        while (start > 0 && !/\s/.test(text[start - 1])) {
            start--;
        }
        // Build new text with the selected option
        const beforeCommand = text.slice(0, start);
        const afterCursor = text.slice(cursorPosition);
        // For Enter (final selection): add space after complete options
        // For Tab (navigation): don't add space, allow further navigation
        const addSpace = viaEnter && option.is_complete;
        const newText = beforeCommand + option.label + (addSpace ? ' ' : '') + afterCursor;
        const newCursorPosition = beforeCommand.length + option.label.length + (addSpace ? 1 : 0);
        setInput(newText);
        setCursorPosition(newCursorPosition);
        // Close autocomplete only on Enter (final selection)
        if (viaEnter) {
            setShowAutocomplete(false);
            setHasAutocompleteOptions(false);
        }
        // For Tab on directory, keep autocomplete open - it will refetch options
        // Focus and set cursor position
        setTimeout(() => {
            if (textareaRef.current) {
                textareaRef.current.focus();
                textareaRef.current.setSelectionRange(newCursorPosition, newCursorPosition);
            }
        }, 0);
    };
    // Execute /reset action
    const executeResetAction = async () => {
        try {
            // Reset both agent thread and conversation
            const threadId = agentThreadId || conversationId;
            if (threadId) {
                const result = await apiService.resetAgent(threadId);
                console.log('[AgentPanel] Reset result:', result);
            }
            // Clear local state (same as trash icon)
            setMessages([]);
            setConversationId('');
            setAgentThreadId(null);
            setIsAgentRunning(false);
            setIsLoading(false);
            setIsStreaming(false);
            setTodos([]);
            setDebugStatus(null);
            setInterruptData(null);
            setIsRejectionMode(false);
            setIsAskUserMode(false);
            console.log('[AgentPanel] Session reset complete');
        }
        catch (error) {
            console.error('[AgentPanel] Failed to reset session:', error);
            const errorMessage = {
                id: `error-${Date.now()}`,
                role: 'assistant',
                content: `Failed to reset session: ${error}`,
                timestamp: Date.now(),
            };
            setMessages(prev => [...prev, errorMessage]);
        }
    };
    // Execute /help action - Display help guide (no LLM call)
    const executeHelpAction = () => {
        // Create logo with 60px height for help content (use base64 data URL)
        const svgBase64 = btoa(unescape(encodeURIComponent(_logoSvg__WEBPACK_IMPORTED_MODULE_15__.headerLogoSvg)));
        const helpContent = `<div style="text-align: center; margin-bottom: 16px;"><img src="data:image/svg+xml;base64,${svgBase64}" style="max-width: 50%; height: auto;" alt="Codebuff Logo" /></div>

## Codebuff 사용 가이드

**Codebuff**는 LLM 기반의 지능형 데이터 분석 코딩 어시스턴트입니다. JupyterLab 환경에서 AI와 대화하며 데이터 분석, 코드 작성, 문제 해결을 도움 받을 수 있습니다.

---

### 📌 모드 소개

| 모드 | 설명 |
|------|------|
| **Chat 모드** | AI와 자유롭게 대화하며 질문하고 답변을 받습니다. 모든 사용자가 사용 가능합니다. |
| **Agent 모드** | AI가 직접 코드를 실행하고 작업을 수행합니다. **출시 예정**입니다. |

---

### 💬 Chat 모드 기능 상세

#### 1. 채팅 기능

- AI와 자유롭게 대화하며 질문/답변을 주고받을 수 있습니다.
- 슬래시 명령어(\`/\`)와 컨텍스트 멘션(\`@\`)을 지원합니다.

#### 2. 셀 내 버튼 기능

노트북의 각 코드 셀 옆에 있는 아이콘 버튼을 활용하세요:

| 아이콘 | 기능 | 설명 |
|--------|------|------|
| 💡 | **코드 설명** | 코드의 동작 원리와 로직을 상세히 설명합니다. |
| ❓ | **질문하기** | 선택한 셀 코드에 대해 자유롭게 질문합니다. |
| 🔧 | **수정 제안** | 선택한 셀의 코드를 분석하여 개선 사항을 제안합니다. |

버튼 클릭 시 해당 셀의 코드가 자동으로 대화창에 포함됩니다.

#### 3. 상단 버튼 기능

| 버튼 | 설명 |
|------|------|
| 💾 **저장하기** (\`Ctrl/Cmd+S\`) | 저장 시 **저장만 하기** 또는 **코드리뷰 후 저장** 중 선택하는 모달이 표시됩니다. 코드리뷰를 선택하면 AI가 현재 노트북을 분석한 뒤 저장합니다. |
| ✨ **노트북 설명하기** | 클릭 → 확인 다이얼로그 → \`@notebook 설명해줘\`가 자동 전송되어 노트북 전체를 설명합니다. |

#### 4. Launcher 기능

Launcher 페이지에서 Codebuff 아이콘의 **노트북 자동생성** 버튼을 클릭하면:
1. 원하는 노트북 내용을 자연어로 입력
2. AI가 마크다운 설명 + 코드 셀이 포함된 노트북을 자동 생성

채팅에서 \`/create-notebook 타이타닉 데이터 분석\`으로도 생성할 수 있습니다.

#### 5. 설정 기능

우측 상단 ⚙️ 아이콘으로 설정 패널을 열 수 있습니다.

| 항목 | 설명 |
|------|------|
| **워크스페이스** | 파일 경로 기준 폴더를 설정합니다. |
| **Temperature** | LLM 응답 다양성을 조절합니다 (0.0 = 일관됨, 1.0+ = 창의적). |
| **codebuff.md** | 프로젝트별 AI 지시사항 파일 감지 상태를 표시합니다. |

#### 6. 슬래시 명령어 (/) 와 컨텍스트 멘션 (@)

**슬래시 명령어**

| 명령어 | 설명 |
|--------|------|
| \`/help\` | 이 도움말을 표시합니다. |
| \`/create-notebook\` | 자연어로 노트북을 자동 생성합니다. 예: \`/create-notebook 타이타닉 데이터 EDA\` |
| \`/review\` | 코드리뷰를 수행합니다. (1) \`/review\` — 활성 탭 리뷰, (2) \`/review @file:경로\` — 특정 파일 리뷰. |
| \`/unittest\` | 유닛테스트를 자동 생성합니다. (1) \`/unittest\` — 활성 탭, (2) \`/unittest @file:경로\` — 특정 파일. |
| \`/reset\` | 세션을 초기화합니다. 대화 기록을 삭제하고 에이전트 스레드를 리셋합니다. |
| \`/compact\` | 대화 기록을 요약하여 압축합니다. 긴 대화 시 컨텍스트를 절약할 수 있습니다. |
| \`/version\` | 현재 Codebuff 버전 정보를 표시합니다. |

**컨텍스트 멘션** — 입력창에 \`@\`를 입력하면 자동완성으로 선택할 수 있습니다.

| 멘션 | 설명 |
|------|------|
| \`@file:경로\` | 파일 내용을 포함합니다. fzf 스타일 퍼지 검색을 지원합니다. |
| \`@notebook\` | 현재 열린 노트북 전체 내용을 포함합니다. |
| \`@cell\` | 현재 선택된 셀의 코드를 포함합니다. |
| \`@error\` | 최근 발생한 에러 내용을 포함합니다. |
| \`@bq-expert-agent\` | BigQuery 전문가에게 쿼리 분석/최적화를 요청합니다. |
| \`@airflow-expert-agent\` | Airflow 전문가에게 DAG 분석/튜닝/에러 해결을 요청합니다. |
| \`@athena-expert-agent\` | Athena 전문가에게 쿼리 분석/성능 튜닝/로그 분석을 요청합니다. |
| \`@lambda-expert-agent\` | Lambda 전문가에게 함수 최적화/Cold Start 분석/로그 분석을 요청합니다. |
| \`@emr-expert-agent\` | EMR 전문가에게 Spark 성능 튜닝/로그 분석을 요청합니다. |
| \`@spring-expert-agent\` | Spring 전문가에게 JVM 튜닝/성능 분석/로그 분석을 요청합니다. |

#### 8. 프로젝트 지시사항 (codebuff.md)

워크스페이스 루트에 \`codebuff.md\` 파일을 생성하면 AI에게 프로젝트별 지시사항을 전달할 수 있습니다.

| 항목 | 설명 |
|------|------|
| **파일 위치** | 워크스페이스 루트 디렉토리의 \`codebuff.md\` |
| **동작 방식** | 대화 시작 시 자동으로 시스템 프롬프트에 반영됩니다 |
| **용도** | 코딩 규칙, 프로젝트 컨벤션, 특수 요구사항 등 |
| **크기 제한** | 최대 10,000자. 초과 시 자동으로 잘립니다 |

설정 메뉴(⚙️)에서 codebuff.md 감지 여부를 확인할 수 있습니다.

#### 9. 키보드 단축키

| 단축키 | 동작 |
|--------|------|
| \`Enter\` | 메시지 전송 |
| \`Shift+Enter\` | 줄바꿈 |
| \`Escape\` | 스트리밍 중지 / 자동완성 닫기 |

---

### 🔍 RAG 검색 (Chat 모드)

Chat 모드에서는 질문 내용에 따라 AI가 자동으로 RAG(벡터 검색)를 수행하여 관련 데이터를 참조합니다.

**검색 가능한 데이터 소스:**

| 컬렉션 | 내용 | 활용 예시 |
|--------|------|----------|
| **enterprise_tables** | 전사 테이블 메타데이터 (테이블/컬럼/스키마) | "카드 매출 테이블 알려줘" |
| **bdp_tables** | BDP 테이블 메타데이터 | "BDP에 어떤 테이블 있어?" |
| **guide_docs** | BDP/bdpengine 가이드 (S3, Athena, Spark 등) | "Athena 쿼리 작성법" |
| **ds_guide_docs** | 데이터사이언스 가이드 (Pandas, PySpark 등) | "PySpark 최적화 방법" |
| **codebase** | 워크스페이스 코드베이스 (함수/클래스/메서드) | "기존 ETL 파이프라인 패턴 참고해서 신규 배치 작성해줘" |

- 질문하면 AI가 적절한 컬렉션을 자동으로 선택하여 검색합니다.
- **codebase** 검색을 사용하려면 설정에서 워크스페이스를 코드베이스에 적재해야 합니다.

---

### 💡 팁

- 긴 대화는 자동으로 요약/압축됩니다 (별도 조작 불필요)
- \`/review\`로 작성한 코드의 품질을 점검하세요
- \`/unittest\`로 테스트 코드를 자동 생성하세요
- 코드 분석 시 \`@file:\`로 파일을 직접 참조하세요
- 셀 버튼으로 빠르게 코드 설명/질문/개선을 요청하세요`;
        const helpMessage = {
            id: `help-${Date.now()}`,
            role: 'assistant',
            content: helpContent,
            timestamp: Date.now(),
        };
        setMessages(prev => [...prev, helpMessage]);
        console.log('[AgentPanel] Help displayed');
    };
    const executeVersionAction = async () => {
        const { PageConfig } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
        const ver = PageConfig.getOption('HDSP_EXTENSION_VERSION') || 'unknown';
        const buildTime = PageConfig.getOption('HDSP_BUILD_TIME') || '';
        let buildInfo = '';
        if (buildTime) {
            const d = new Date(buildTime);
            const kst = new Date(d.getTime() + 9 * 60 * 60 * 1000);
            const formatted = kst.toISOString().replace('T', ' ').slice(0, 19) + ' KST';
            buildInfo = `\nBuild: ${formatted}`;
        }
        const versionContent = `**Codebuff** v${ver}${buildInfo}`;
        const versionMessage = {
            id: `version-${Date.now()}`,
            role: 'assistant',
            content: versionContent,
            timestamp: Date.now(),
        };
        setMessages(prev => [...prev, versionMessage]);
    };
    const handleKeyDown = (e) => {
        // If autocomplete is visible AND has options, let it handle Tab/Enter
        if (showAutocomplete && hasAutocompleteOptions) {
            // These keys are handled by ContextAutocomplete
            if (e.key === 'Tab' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                return; // Let autocomplete handle it
            }
            if (e.key === 'Enter' && !e.shiftKey) {
                return; // Let autocomplete handle it
            }
            if (e.key === 'Escape') {
                setShowAutocomplete(false);
                setHasAutocompleteOptions(false);
                return;
            }
        }
        // Escape: Stop chat streaming (only in chat mode when streaming)
        if (e.key === 'Escape' && isStreaming) {
            e.preventDefault();
            stopCurrentTask();
            return;
        }
        // Enter: 전송 (IME 조합 중이면 무시)
        if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
            e.preventDefault();
            handleSendMessage();
        }
        // Shift+Tab: 모드 전환 (chat ↔ agent) - admin only
        if (e.key === 'Tab' && e.shiftKey && isAdmin) {
            e.preventDefault();
            setInputMode(prev => prev === 'chat' ? 'agent' : 'chat');
            return;
        }
        // Cmd/Ctrl + . : 모드 전환 (대체 단축키) - admin only
        if (e.key === '.' && (e.metaKey || e.ctrlKey) && isAdmin) {
            e.preventDefault();
            setInputMode(prev => prev === 'chat' ? 'agent' : 'chat');
        }
        // Tab (without Shift): Agent 모드일 때 드롭다운 토글 - admin only
        if (e.key === 'Tab' && !e.shiftKey && inputMode !== 'chat' && isAdmin) {
            e.preventDefault();
            setShowModeDropdown(prev => !prev);
        }
    };
    // 모드 토글 함수 (chat ↔ agent) - admin only
    const toggleMode = () => {
        if (!isAdmin)
            return; // Non-admin users can only use chat mode
        const from = inputMode;
        const to = from === 'chat' ? 'agent' : 'chat';
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('mode_switch', { from, to });
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackImpression(to, { input_mode: to });
        setInputMode(to);
        setShowModeDropdown(false);
    };
    const clearChat = () => {
        setMessages([]);
        setTodos([]);
        setDebugStatus(null);
        setInterruptData(null);
        setIsRejectionMode(false);
        setIsAskUserMode(false);
    };
    // 메시지가 Chat 메시지인지 확인 (UnifiedMessage는 이제 IChatMessage만 있음)
    const isChatMessage = (msg) => {
        return true;
    };
    const mapStatusText = (raw) => {
        const normalized = raw.toLowerCase();
        if (normalized.includes('calling tool')) {
            return raw.replace(/Calling tool:/gi, '도구 호출 중:').trim();
        }
        if (normalized.includes('waiting for user approval')) {
            return '승인 대기 중...';
        }
        if (normalized.includes('resuming execution')) {
            return '승인 반영 후 실행 재개 중...';
        }
        return raw;
    };
    // Get status text from debug status (handling both string and IDebugStatus)
    const getDebugStatusText = () => {
        if (!debugStatus)
            return '';
        if (typeof debugStatus === 'string') {
            return mapStatusText(debugStatus);
        }
        // IDebugStatus object
        let text;
        if (isDebugExpanded && debugStatus.full_text) {
            text = mapStatusText(debugStatus.full_text);
        }
        else {
            text = mapStatusText(debugStatus.status);
        }
        // Add turn/step prefix if available
        if (debugStatus.turn !== undefined && debugStatus.turn > 0) {
            const parts = [`턴 ${debugStatus.turn}`];
            if (debugStatus.tool_label) {
                parts.push(debugStatus.tool_label);
            }
            // tool_label 없으면 턴 번호만 표시 (도구 N 제거)
            text = `[${parts.join(' · ')}] ${text}`;
        }
        return text;
    };
    // Get icon SVG for debug status (if available)
    const getDebugStatusIcon = () => {
        if (!debugStatus || typeof debugStatus === 'string')
            return '';
        if (debugStatus.icon) {
            return (0,_utils_icons__WEBPACK_IMPORTED_MODULE_12__.getIconByName)(debugStatus.icon);
        }
        return '';
    };
    // Check if debug status is expandable
    const isDebugStatusExpandable = () => {
        if (!debugStatus || typeof debugStatus === 'string')
            return false;
        return debugStatus.expandable === true;
    };
    const getStatusText = () => {
        if (interruptData) {
            return `승인 대기: ${interruptData.action}`;
        }
        if (debugStatus) {
            return getDebugStatusText();
        }
        if (isLoading || isStreaming) {
            // 기본 상태 메시지 - todo 내용은 compact todo UI에서 표시
            return '요청 처리 중';
        }
        return null;
    };
    const statusText = getStatusText();
    // When stopped, treat in_progress as cancelled for rendering
    const displayTodos = isTodoStopped
        ? todos.map(t => t.status === 'in_progress' ? { ...t, status: 'cancelled' } : t)
        : todos;
    const hasActiveTodos = displayTodos.some(todo => todo.status === 'pending' || todo.status === 'in_progress');
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-panel" },
        showSettings && (isAdmin === true ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_AdminSettingsPanel__WEBPACK_IMPORTED_MODULE_4__.AdminSettingsPanel, { onClose: () => setShowSettings(false), onSave: (config) => {
                // Refresh llmConfig from localStorage after admin save
                loadConfig();
                console.log('[AgentPanel] Admin config saved');
            }, apiService: apiService })) : isAdmin === false ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_UserSettingsPanel__WEBPACK_IMPORTED_MODULE_5__.UserSettingsPanel, { onClose: () => setShowSettings(false), onSave: (config) => {
                // Update llmConfig with user settings
                if (llmConfig) {
                    const updatedConfig = {
                        ...llmConfig,
                        workspaceRoot: config.workspaceRoot,
                        autoApprove: config.autoApprove
                    };
                    (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_6__.saveLLMConfig)(updatedConfig);
                    setLlmConfig(updatedConfig);
                }
                console.log('[AgentPanel] User config saved');
            }, apiService: apiService, inputMode: inputMode })) : (
        // Fallback to legacy SettingsPanel while checking admin mode
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_SettingsPanel__WEBPACK_IMPORTED_MODULE_3__.SettingsPanel, { onClose: () => setShowSettings(false), onSave: handleSaveConfig, currentConfig: llmConfig || undefined }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-header" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-header-logo", dangerouslySetInnerHTML: { __html: _logoSvg__WEBPACK_IMPORTED_MODULE_15__.headerLogoSvg } }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-header-buttons" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-clear-button", onClick: () => { _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('panel_clear'); clearChat(); }, title: "\uD654\uBA74 \uC9C0\uC6B0\uAE30" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("polyline", { points: "3 6 5 6 21 6" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "10", y1: "11", x2: "10", y2: "17" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "14", y1: "11", x2: "14", y2: "17" }))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button-icon", onClick: () => { _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackClick('panel_settings'); setShowSettings(true); }, title: "\uC124\uC815" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "4", y1: "21", x2: "4", y2: "14" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "4", y1: "10", x2: "4", y2: "3" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "12", y1: "21", x2: "12", y2: "12" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "12", y1: "8", x2: "12", y2: "3" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "20", y1: "21", x2: "20", y2: "16" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "20", y1: "12", x2: "20", y2: "3" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "1", y1: "14", x2: "7", y2: "14" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "9", y1: "8", x2: "15", y2: "8" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("line", { x1: "17", y1: "16", x2: "23", y2: "16" }))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-messages", ref: messagesContainerRef },
            messages.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-empty-state" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-guide-center-area" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "jp-agent-guide-title" },
                        "\uC548\uB155\uD558\uC138\uC694! ",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "Codebuff"),
                        " \uC785\uB2C8\uB2E4."),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-guide-tips" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-guide-tip" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-guide-icon" }, "\uD83D\uDCAC"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "\uC9C8\uBB38\uC744 \uC785\uB825\uD558\uBA74 AI\uAC00 \uCF54\uB4DC \uC791\uC131, \uB370\uC774\uD130 \uBD84\uC11D\uC744 \uB3C4\uC640\uC90D\uB2C8\uB2E4")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-guide-tip" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-guide-icon" }, "\uD83D\uDCDA"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "\uC0AC\uB0B4 \uD14C\uC774\uBE14/\uAC00\uC774\uB4DC\uB97C \uC790\uB3D9\uC73C\uB85C \uAC80\uC0C9\uD558\uC5EC \uB2F5\uBCC0\uD569\uB2C8\uB2E4")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-guide-tip" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-guide-icon" }, "\u2328\uFE0F"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("code", null, "/help"),
                                " \uBA85\uB839\uC5B4\uB85C \uC0C1\uC138 \uC0AC\uC6A9\uBC95\uC744 \uD655\uC778\uD558\uC138\uC694")))))) : (messages.map(msg => {
                if (isChatMessage(msg)) {
                    // Skip empty assistant messages (except streaming ones)
                    const isEmptyAssistant = msg.role === 'assistant'
                        && (!msg.content || msg.content.trim() === '')
                        && streamingMessageId !== msg.id;
                    if (isEmptyAssistant) {
                        return null;
                    }
                    // 일반 Chat 메시지
                    const isAssistant = msg.role === 'assistant';
                    const isShellOutput = msg.metadata?.kind === 'shell-output';
                    const interruptAction = msg.metadata?.interrupt?.action;
                    const isWriteFile = interruptAction === 'write_file_tool';
                    const isEditFile = interruptAction === 'edit_file_tool';
                    const isMultiEditFile = interruptAction === 'multiedit_file_tool';
                    const isMarkdownTool = interruptAction === 'markdown_tool' || interruptAction === 'markdown';
                    const writePath = (isWriteFile
                        && typeof msg.metadata?.interrupt?.args?.path === 'string') ? msg.metadata?.interrupt?.args?.path : '';
                    const editPath = ((isEditFile || isMultiEditFile)
                        && typeof msg.metadata?.interrupt?.args?.path === 'string') ? msg.metadata?.interrupt?.args?.path : '';
                    const autoApproved = msg.metadata?.interrupt?.autoApproved;
                    const headerRole = msg.role === 'user'
                        ? '사용자'
                        : msg.role === 'system'
                            ? (isShellOutput ? 'shell 실행' : (autoApproved ? '자동 승인됨' : '승인 요청'))
                            : 'Agent';
                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: msg.id, className: isAssistant
                            ? 'jp-agent-message jp-agent-message-assistant-inline'
                            : `jp-agent-message jp-agent-message-${msg.role}${isShellOutput ? ' jp-agent-message-shell-output' : ''}` },
                        !isAssistant && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-message-header" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-message-role" }, headerRole),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-message-time" }, new Date(msg.timestamp).toLocaleTimeString()))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-agent-message-content${streamingMessageId === msg.id ? ' streaming' : ''}${isShellOutput ? ' jp-agent-message-content-shell' : ''}` }, msg.role === 'system' && msg.metadata?.interrupt ? (msg.metadata?.interrupt?.autoApproved ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-auto-approved-summary" }, (() => {
                            const action = msg.metadata?.interrupt?.action || '';
                            const args = msg.metadata?.interrupt?.args || {};
                            const label = action === 'jupyter_cell_tool'
                                ? `셀 ${args.operation === 'READ' ? '읽기' : '삽입'}`
                                : action === 'write_file_tool'
                                    ? `파일 생성: ${args.path || ''}`
                                    : action === 'edit_file_tool' || action === 'multiedit_file_tool'
                                        ? `파일 수정: ${args.path || ''}`
                                        : action === 'search_notebook_cells_tool'
                                            ? '노트북 검색'
                                            : action === 'read_file_tool'
                                                ? `파일 읽기: ${args.path || ''}`
                                                : action === 'list_workspace_tool'
                                                    ? '워크스페이스 목록'
                                                    : action === 'search_files_tool'
                                                        ? '파일 검색'
                                                        : action === 'check_resource_tool'
                                                            ? '리소스 확인'
                                                            : action.replace(/_tool$/, '').replace(/_/g, ' ');
                            return `✅ ${label}`;
                        })())) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-agent-interrupt-inline` },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-interrupt-action" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-interrupt-action-args" }, (() => {
                                    const command = msg.metadata?.interrupt?.args?.command;
                                    const code = msg.metadata?.interrupt?.args?.code || msg.metadata?.interrupt?.args?.content || '';
                                    // Handle edit_file_tool and multiedit_file_tool with diff preview
                                    let snippet;
                                    let language;
                                    if (isMultiEditFile) {
                                        // Handle multiedit_file_tool - show all edits
                                        const edits = msg.metadata?.interrupt?.args?.edits || [];
                                        const editsPreview = edits.slice(0, 5).map((edit, idx) => {
                                            const oldStr = edit.old_string || '';
                                            const newStr = edit.new_string || '';
                                            const oldPreview = oldStr.length > 100 ? oldStr.slice(0, 100) + '...' : oldStr;
                                            const newPreview = newStr.length > 100 ? newStr.slice(0, 100) + '...' : newStr;
                                            return `# Edit ${idx + 1}${edit.replace_all ? ' (replace_all)' : ''}\n` +
                                                oldPreview.split('\n').map((line) => `-${line}`).join('\n') + '\n' +
                                                newPreview.split('\n').map((line) => `+${line}`).join('\n');
                                        }).join('\n\n');
                                        const moreEdits = edits.length > 5 ? `\n\n... and ${edits.length - 5} more edits` : '';
                                        snippet = `--- ${editPath} (${edits.length} edits)\n+++ ${editPath} (after)\n\n${editsPreview}${moreEdits}`;
                                        language = 'diff';
                                    }
                                    else if (isEditFile) {
                                        const oldStr = msg.metadata?.interrupt?.args?.old_string || '';
                                        const newStr = msg.metadata?.interrupt?.args?.new_string || '';
                                        const replaceAll = msg.metadata?.interrupt?.args?.replace_all;
                                        // Generate simple diff preview
                                        const oldPreview = oldStr.length > 500 ? oldStr.slice(0, 500) + '...' : oldStr;
                                        const newPreview = newStr.length > 500 ? newStr.slice(0, 500) + '...' : newStr;
                                        snippet = `--- ${editPath} (before)\n+++ ${editPath} (after)\n` +
                                            oldPreview.split('\n').map((line) => `-${line}`).join('\n') + '\n' +
                                            newPreview.split('\n').map((line) => `+${line}`).join('\n') +
                                            (replaceAll ? '\n\n(replace_all: true)' : '');
                                        language = 'diff';
                                    }
                                    else if (isMarkdownTool) {
                                        // markdown_tool: render as HTML, not as code block
                                        snippet = code || '';
                                        language = 'markdown';
                                    }
                                    else {
                                        snippet = (command || code || '(no details)');
                                        language = command ? 'bash' : 'python';
                                    }
                                    const resolved = msg.metadata?.interrupt?.resolved;
                                    const decision = msg.metadata?.interrupt?.decision;
                                    const autoApproved = msg.metadata?.interrupt?.autoApproved;
                                    // 자동 승인일 때는 코드블럭 헤더에 배지가 표시되므로 actionHtml에는 표시하지 않음
                                    const resolvedIcon = autoApproved ? '' : (decision === 'reject' ? _utils_icons__WEBPACK_IMPORTED_MODULE_12__.Icons.rejectCircle : _utils_icons__WEBPACK_IMPORTED_MODULE_12__.Icons.doubleCheck);
                                    const resolvedClass = autoApproved ? '' : (decision === 'reject' ? 'jp-agent-interrupt-actions--rejected' : 'jp-agent-interrupt-actions--resolved');
                                    const actionHtml = resolved && !autoApproved
                                        ? `<div class="jp-agent-interrupt-actions ${resolvedClass}">${resolvedIcon}</div>`
                                        : resolved && autoApproved
                                            ? '' // 자동 승인일 때는 actionHtml 비움 (코드블럭 헤더에 배지 표시)
                                            : `
<div class="code-block-actions jp-agent-interrupt-actions">
  <button class="jp-agent-interrupt-approve-btn" data-action="approve" title="승인">${_utils_icons__WEBPACK_IMPORTED_MODULE_12__.Icons.approveCircle}</button>
  <button class="jp-agent-interrupt-reject-btn" data-action="reject" title="거부">${_utils_icons__WEBPACK_IMPORTED_MODULE_12__.Icons.rejectCircle}</button>
</div>
`;
                                    // Get tool description from args (for jupyter_cell_tool)
                                    const toolDescription = msg.metadata?.interrupt?.args?.description;
                                    const renderedHtml = (() => {
                                        // markdown_tool: render content as HTML directly, not as code block
                                        let html = isMarkdownTool
                                            ? (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_7__.formatMarkdownToHtml)(snippet)
                                            : (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_7__.formatMarkdownToHtml)(`\n\`\`\`${language}\n${snippet}\n\`\`\``);
                                        if (isWriteFile && writePath) {
                                            const safePath = escapeHtml(writePath);
                                            html = html.replace(/<span class="code-block-language">[^<]*<\/span>/, `<span class="code-block-language jp-agent-interrupt-path">${safePath}</span>`);
                                        }
                                        if ((isEditFile || isMultiEditFile) && editPath) {
                                            const safePath = escapeHtml(editPath);
                                            const editIcon = _utils_icons__WEBPACK_IMPORTED_MODULE_12__.Icons.edit;
                                            html = html.replace(/<span class="code-block-language">[^<]*<\/span>/, `<span class="code-block-language jp-agent-interrupt-path">${editIcon} ${safePath}</span>`);
                                        }
                                        // actionHtml이 비어있지 않을 때만 추가
                                        let codeHtml;
                                        if (isMarkdownTool) {
                                            // markdown_tool: wrap in container with action buttons
                                            codeHtml = actionHtml
                                                ? `<div class="jp-agent-markdown-preview">${html}${actionHtml}</div>`
                                                : `<div class="jp-agent-markdown-preview">${html}</div>`;
                                        }
                                        else {
                                            codeHtml = actionHtml ? html.replace('</div>', `${actionHtml}</div>`) : html;
                                        }
                                        // Build the final HTML with proper ordering:
                                        // 1. jp-agent-code-description (detailed description) - top
                                        // 2. jp-agent-interrupt-description (approval message) - right above code
                                        // 3. code block
                                        let result = '';
                                        // 1. 코드 설명이 있으면 맨 위에 표시
                                        if (toolDescription) {
                                            // Escape HTML first, then clean up newlines
                                            const safeDescription = escapeHtml(toolDescription)
                                                .replace(/\\n/g, ' ') // Remove literal \n strings
                                                .replace(/\n/g, ' ') // Remove actual newlines
                                                .replace(/\s+/g, ' ') // Collapse multiple spaces
                                                .trim();
                                            result += `<div class="jp-agent-code-description">${_utils_icons__WEBPACK_IMPORTED_MODULE_12__.Icons.description} ${safeDescription}</div>`;
                                        }
                                        // 2. 승인 메시지 (자동 승인이 아닐 때만) - 코드 블록 바로 위
                                        if (!msg.metadata?.interrupt?.autoApproved && msg.content) {
                                            const safeContent = escapeHtml(msg.content);
                                            result += `<div class="jp-agent-interrupt-description">${_utils_icons__WEBPACK_IMPORTED_MODULE_12__.Icons.approvalWarning} ${safeContent}</div>`;
                                        }
                                        // 3. 코드 블록
                                        result += codeHtml;
                                        return result;
                                    })();
                                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-RenderedHTMLCommon", style: { padding: '0 4px' }, dangerouslySetInnerHTML: { __html: renderedHtml }, onClick: (event) => {
                                            const target = event.target;
                                            // Find the button element with data-action (handles clicks on SVG inside button)
                                            const button = target.closest('[data-action]');
                                            const action = button?.getAttribute?.('data-action');
                                            if (msg.metadata?.interrupt?.resolved) {
                                                return;
                                            }
                                            if (action === 'approve') {
                                                handleResumeAgent('approve');
                                            }
                                            else if (action === 'reject') {
                                                handleResumeAgent('reject');
                                            }
                                        } }));
                                })()))))) : msg.role === 'assistant' ? (
                        // Assistant(AI) 메시지: 스트리밍 지원 마크다운 렌더링
                        // 이벤트 위임은 상위 messages-container에서 처리됨
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_StreamingMessage__WEBPACK_IMPORTED_MODULE_9__.StreamingMessage, { content: msg.content, isStreaming: streamingMessageId === msg.id, onInsertAbove: handleInsertCodeAbove, onInsertBelow: handleInsertCodeBelow, onInsertAsCell: handleInsertCodeAsCell, cellActionsEnabled: !!getActiveNotebookPanel(), statusText: streamingMessageId === msg.id ? getDebugStatusText() : (msg.metadata?.statusHistory || undefined), toolProcessing: streamingMessageId === msg.id && toolProcessing })) : (
                        // User(사용자) 메시지: 텍스트 그대로 줄바꿈만 처리
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { whiteSpace: 'pre-wrap' } }, msg.content)))));
                }
                return null;
            })),
            showConsoleErrorNotification && lastConsoleError && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-console-error-notification" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-console-error-header" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "16", height: "16" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M8.982 1.566a1.13 1.13 0 00-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 01-1.1 0L7.1 5.995A.905.905 0 018 5zm.002 6a1 1 0 110 2 1 1 0 010-2z" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Console\uC5D0\uC11C Python \uC5D0\uB7EC\uAC00 \uAC10\uC9C0\uB418\uC5C8\uC2B5\uB2C8\uB2E4")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-console-error-preview" },
                    lastConsoleError.slice(0, 200),
                    lastConsoleError.length > 200 ? '...' : ''),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-console-error-actions" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-console-error-fix-btn", onClick: () => {
                            // 에러를 자동으로 입력창에 넣고 파일 수정 요청
                            setInput(`다음 에러를 분석하고 수정해주세요:\n\n${lastConsoleError}`);
                            setShowConsoleErrorNotification(false);
                            // 입력창에 포커스
                            const textarea = document.querySelector('.jp-agent-input');
                            if (textarea)
                                textarea.focus();
                        } }, "\uC5D0\uB7EC \uBD84\uC11D \uC694\uCCAD"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-console-error-dismiss-btn", onClick: () => setShowConsoleErrorNotification(false) }, "\uB2EB\uAE30")))),
            pendingFileFixes.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-file-fixes" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-file-fixes-header" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "14", height: "14" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M14 1H2a1 1 0 00-1 1v12a1 1 0 001 1h12a1 1 0 001-1V2a1 1 0 00-1-1zM2 0a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V2a2 2 0 00-2-2H2z" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M9.5 5a.5.5 0 00-1 0v3.793L6.854 7.146a.5.5 0 10-.708.708l2.5 2.5a.5.5 0 00.708 0l2.5-2.5a.5.5 0 00-.708-.708L9.5 8.793V5z" })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null,
                        "\uC218\uC815\uB41C \uD30C\uC77C (",
                        pendingFileFixes.length,
                        "\uAC1C)")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-file-fixes-list" }, pendingFileFixes.map((fix, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, className: "jp-agent-file-fix-item" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-file-fix-info" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M4 0a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V4.5L9.5 0H4zm5.5 1.5v2a1 1 0 001 1h2l-3-3zM4.5 8a.5.5 0 010 1h7a.5.5 0 010-1h-7zm0 2a.5.5 0 010 1h7a.5.5 0 010-1h-7zm0 2a.5.5 0 010 1h4a.5.5 0 010-1h-4z" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-file-fix-path" }, fix.path)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-file-fix-apply", onClick: () => applyFileFix(fix), title: `${fix.path} 파일에 수정 적용` }, "\uC801\uC6A9\uD558\uAE30"))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-file-fixes-dismiss", onClick: () => setPendingFileFixes([]), title: "\uC218\uC815 \uC81C\uC548 \uB2EB\uAE30" }, "\uB2EB\uAE30"))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: messagesEndRef })),
        inputMode !== 'chat' && todos.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact-header", onClick: () => setIsTodoExpanded(!isTodoExpanded) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact-left" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { className: `jp-agent-todo-expand-icon ${isTodoExpanded ? 'jp-agent-todo-expand-icon--expanded' : ''}`, viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M6 12l4-4-4-4" })),
                    (() => {
                        const isStillWorking = isStreaming || isLoading || isAgentRunning;
                        if (isTodoStopped) {
                            return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-current" }, "\uC791\uC5C5 \uC911\uB2E8\uB428");
                        }
                        const currentTodo = displayTodos.find(t => t.status === 'in_progress') || displayTodos.find(t => t.status === 'pending');
                        if (currentTodo) {
                            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact-spinner" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-current" }, currentTodo.content)));
                        }
                        else if (isStillWorking) {
                            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-compact-spinner" }),
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-current" }, "\uC791\uC5C5 \uB9C8\uBB34\uB9AC \uC911...")));
                        }
                        else {
                            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-current", dangerouslySetInnerHTML: { __html: `${_utils_icons__WEBPACK_IMPORTED_MODULE_12__.Icons.check} 모든 작업 완료` } }));
                        }
                    })()),
                !isTodoStopped && (isStreaming || isLoading || isAgentRunning || displayTodos.some(t => t.status === 'in_progress')) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-todo-stop-btn", onClick: (e) => {
                        e.stopPropagation();
                        console.log('[AgentPanel] Stop button clicked');
                        stopCurrentTask();
                    }, title: "\uC791\uC5C5 \uC911\uB2E8" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("rect", { x: "3", y: "3", width: "10", height: "10", rx: "1" })))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-compact-progress" },
                    todos.filter(t => t.status === 'completed').length,
                    "/",
                    todos.length)),
            statusText && hasActiveTodos && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-agent-message jp-agent-message-debug jp-agent-message-debug--inline${statusText.startsWith('오류:') ? ' jp-agent-message-debug-error' : ''}` },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-debug-content" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-debug-branch", "aria-hidden": "true" }),
                    getDebugStatusIcon() && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-debug-icon", dangerouslySetInnerHTML: { __html: getDebugStatusIcon() } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jp-agent-debug-text${isDebugStatusExpandable() ? ' jp-agent-debug-text--expandable' : ''}`, onClick: isDebugStatusExpandable() ? () => setIsDebugExpanded(!isDebugExpanded) : undefined, title: isDebugStatusExpandable() ? (isDebugExpanded ? '접기' : '펼치기') : undefined },
                        statusText,
                        isDebugStatusExpandable() && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-debug-expand-icon" }, isDebugExpanded ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_13__["default"], { sx: { fontSize: 14 } }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_14__["default"], { sx: { fontSize: 14 } }))))))),
            isTodoExpanded && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-expanded" }, displayTodos.map((todo, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: index, className: `jp-agent-todo-item jp-agent-todo-item--${todo.status}` },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-item-indicator" },
                    todo.status === 'completed' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M13.78 4.22a.75.75 0 010 1.06l-7.25 7.25a.75.75 0 01-1.06 0L2.22 9.28a.75.75 0 011.06-1.06L6 10.94l6.72-6.72a.75.75 0 011.06 0z" }))),
                    todo.status === 'in_progress' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-todo-item-spinner" }),
                    todo.status === 'cancelled' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M3.72 3.72a.75.75 0 011.06 0L8 6.94l3.22-3.22a.75.75 0 111.06 1.06L9.06 8l3.22 3.22a.75.75 0 11-1.06 1.06L8 9.06l-3.22 3.22a.75.75 0 01-1.06-1.06L6.94 8 3.72 4.78a.75.75 0 010-1.06z" }))),
                    todo.status === 'pending' && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-todo-item-number" }, index + 1)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jp-agent-todo-item-text ${todo.status === 'completed' ? 'jp-agent-todo-item-text--done' : ''}` }, todo.content)))))))),
        statusText && !hasActiveTodos && !(inputMode === 'chat' && isStreaming) && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: `jp-agent-message jp-agent-message-debug jp-agent-message-debug--above-input${statusText.startsWith('오류:') ? ' jp-agent-message-debug-error' : ''}` },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-debug-content" },
                getDebugStatusIcon() && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-debug-icon", dangerouslySetInnerHTML: { __html: getDebugStatusIcon() } })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: `jp-agent-debug-text${isDebugStatusExpandable() ? ' jp-agent-debug-text--expandable' : ''}`, onClick: isDebugStatusExpandable() ? () => setIsDebugExpanded(!isDebugExpanded) : undefined, title: isDebugStatusExpandable() ? (isDebugExpanded ? '접기' : '펼치기') : undefined },
                    statusText,
                    isDebugStatusExpandable() && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-debug-expand-icon" }, isDebugExpanded ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_13__["default"], { sx: { fontSize: 14 } }) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_14__["default"], { sx: { fontSize: 14 } }))))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-input-container" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-input-wrapper", style: { position: 'relative' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ContextAutocomplete__WEBPACK_IMPORTED_MODULE_10__.ContextAutocomplete, { apiService: apiService, inputValue: input, cursorPosition: cursorPosition, baseDir: notebookTracker?.currentWidget?.context?.path ?
                        notebookTracker.currentWidget.context.path.replace(/[^/]*$/, '') : undefined, onSelect: handleAutocompleteSelect, onClose: () => { setShowAutocomplete(false); setHasAutocompleteOptions(false); }, onOptionsChange: setHasAutocompleteOptions, visible: showAutocomplete, anchorEl: textareaRef.current }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { ref: textareaRef, className: `jp-agent-input ${inputMode !== 'chat' ? 'jp-agent-input--agent-mode' : ''} ${isRejectionMode ? 'jp-agent-input--rejection-mode' : ''}`, value: input, onChange: handleInputChange, onKeyDown: handleKeyDown, onSelect: (e) => setCursorPosition(e.target.selectionStart || 0), placeholder: isRejectionMode
                        ? '다른 방향 제시'
                        : (inputMode === 'agent'
                            ? '노트북 작업을 입력하세요... (예: @file:path로 파일 참조)'
                            : '메세지를 입력하세요.'), disabled: isLoading || isAgentRunning }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-button-container" }, isStreaming ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-stop-button", onClick: stopCurrentTask, title: "\uC751\uB2F5 \uC911\uB2E8 (Esc)" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", width: "16", height: "16" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("circle", { cx: "12", cy: "12", r: "10" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("rect", { x: "9", y: "9", width: "6", height: "6", rx: "1", fill: "currentColor", stroke: "none" })),
                    "\uC911\uB2E8")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-send-button", onClick: handleSendMessage, disabled: (!input.trim() && !isRejectionMode) || isLoading || isStreaming || isAgentRunning, title: isRejectionMode ? "거부 전송 (Enter)" : "전송 (Enter)" }, isAgentRunning ? '실행 중...' : (isRejectionMode ? '거부' : '전송'))))),
            isAdmin && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-mode-bar" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-mode-toggle-container" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-agent-mode-toggle ${inputMode !== 'chat' ? 'jp-agent-mode-toggle--active' : ''}`, onClick: toggleMode, title: `${inputMode === 'chat' ? 'Chat' : 'Agent'} 모드 (⇧Tab)` },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { className: "jp-agent-mode-icon", viewBox: inputMode === 'chat' ? "0 0 16 16" : "0 -960 960 960", fill: "currentColor", width: "14", height: "14" }, inputMode === 'chat' ? (
                        // 채팅 아이콘 (Chat 모드)
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M8 1C3.58 1 0 4.13 0 8c0 1.5.5 2.88 1.34 4.04L.5 15l3.37-.92A8.56 8.56 0 008 15c4.42 0 8-3.13 8-7s-3.58-7-8-7zM4.5 9a1 1 0 110-2 1 1 0 010 2zm3.5 0a1 1 0 110-2 1 1 0 010 2zm3.5 0a1 1 0 110-2 1 1 0 010 2z" })) : (
                        // 로봇/AI 아이콘 (Agent 모드)
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M309-389q29 29 71 29t71-29l160-160q29-29 29-71t-29-71q-29-29-71-29t-71 29q-37-13-73-6t-61 32q-25 25-32 61t6 73q-29 29-29 71t29 71ZM240-80v-172q-57-52-88.5-121.5T120-520q0-150 105-255t255-105q125 0 221.5 73.5T827-615l52 205q5 19-7 34.5T840-360h-80v120q0 33-23.5 56.5T680-160h-80v80h-80v-160h160v-200h108l-38-155q-23-91-98-148t-172-57q-116 0-198 81t-82 197q0 60 24.5 114t69.5 96l26 24v208h-80Zm254-360Z" }))),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-mode-label" }, inputMode === 'chat' ? 'Chat' : 'Agent'),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { className: "jp-agent-mode-chevron", viewBox: "0 0 16 16", fill: "currentColor", width: "12", height: "12" },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M4.47 5.47a.75.75 0 011.06 0L8 7.94l2.47-2.47a.75.75 0 111.06 1.06l-3 3a.75.75 0 01-1.06 0l-3-3a.75.75 0 010-1.06z" }))),
                    showModeDropdown && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-mode-dropdown" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-agent-mode-option ${inputMode === 'chat' ? 'jp-agent-mode-option--selected' : ''}`, onClick: () => { setInputMode('chat'); setShowModeDropdown(false); } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 0 16 16", fill: "currentColor", width: "14", height: "14" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M8 1C3.58 1 0 4.13 0 8c0 1.5.5 2.88 1.34 4.04L.5 15l3.37-.92A8.56 8.56 0 008 15c4.42 0 8-3.13 8-7s-3.58-7-8-7zM4.5 9a1 1 0 110-2 1 1 0 010 2zm3.5 0a1 1 0 110-2 1 1 0 010 2zm3.5 0a1 1 0 110-2 1 1 0 010 2z" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Chat"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-mode-shortcut" }, "\uC77C\uBC18 \uB300\uD654")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-agent-mode-option ${inputMode === 'agent' ? 'jp-agent-mode-option--selected' : ''}`, onClick: () => { setInputMode('agent'); setShowModeDropdown(false); } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { viewBox: "0 -960 960 960", fill: "currentColor", width: "14", height: "14" },
                                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M309-389q29 29 71 29t71-29l160-160q29-29 29-71t-29-71q-29-29-71-29t-71 29q-37-13-73-6t-61 32q-25 25-32 61t6 73q-29 29-29 71t29 71ZM240-80v-172q-57-52-88.5-121.5T120-520q0-150 105-255t255-105q125 0 221.5 73.5T827-615l52 205q5 19-7 34.5T840-360h-80v120q0 33-23.5 56.5T680-160h-80v80h-80v-160h160v-200h108l-38-155q-23-91-98-148t-172-57q-116 0-198 81t-82 197q0 60 24.5 114t69.5 96l26 24v208h-80Zm254-360Z" })),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "Agent"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-mode-shortcut" }, "\uB178\uD2B8\uBD81 \uC790\uB3D9 \uC2E4\uD589"))))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-mode-hints" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-agent-mode-hint" }, "\u21E7Tab \uBAA8\uB4DC \uC804\uD658"))))),
        fileSelectionMetadata && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_FileSelectionDialog__WEBPACK_IMPORTED_MODULE_8__.FileSelectionDialog, { filename: fileSelectionMetadata.pattern, options: fileSelectionMetadata.options, message: fileSelectionMetadata.message, onSelect: handleFileSelect, onCancel: handleFileSelectCancel }))));
});
ChatPanel.displayName = 'ChatPanel';
/**
 * Agent Panel Widget
 */
class AgentPanelWidget extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(apiService, notebookTracker, consoleTracker) {
        super();
        this.chatPanelRef = react__WEBPACK_IMPORTED_MODULE_0___default().createRef();
        this.apiService = apiService;
        this.notebookTracker = notebookTracker;
        this.consoleTracker = consoleTracker;
        this.id = 'hdsp-agent-panel';
        this.title.caption = 'HDSP Agent Assistant';
        this.title.icon = hdspTabIcon;
        this.addClass('jp-agent-widget');
    }
    onActivateRequest(msg) {
        super.onActivateRequest(msg);
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_11__.AnalyticsService.getInstance().trackImpression('panel_open');
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(ChatPanel, { ref: this.chatPanelRef, apiService: this.apiService, notebookTracker: this.notebookTracker, consoleTracker: this.consoleTracker }));
    }
    /**
     * Add a message from cell action
     * @param action - The action type (explain, fix, custom_prompt)
     * @param cellContent - The cell content
     * @param displayPrompt - The user-facing prompt to show in the UI
     * @param llmPrompt - The actual prompt to send to the LLM
     * @param cellId - The cell ID for applying code (optional)
     * @param cellIndex - The cell index (0-based) for applying code (optional)
     */
    addCellActionMessage(action, cellContent, displayPrompt, llmPrompt, cellId, cellIndex) {
        console.log('[AgentPanel] Cell action:', action);
        console.log('[AgentPanel] Display prompt:', displayPrompt);
        console.log('[AgentPanel] LLM prompt:', llmPrompt);
        console.log('[AgentPanel] Cell ID:', cellId);
        console.log('[AgentPanel] Cell Index:', cellIndex);
        if (!this.chatPanelRef.current) {
            console.error('[AgentPanel] ChatPanel ref not available');
            return;
        }
        // E, F, ? 버튼 클릭 시 항상 일반 대화(chat) 모드로 전환
        if (this.chatPanelRef.current.setInputMode) {
            this.chatPanelRef.current.setInputMode('chat');
        }
        // Store cell index for code application (preferred method)
        if (cellIndex !== undefined && this.chatPanelRef.current.setCurrentCellIndex) {
            this.chatPanelRef.current.setCurrentCellIndex(cellIndex);
        }
        // Store cell ID for code application (fallback)
        if (cellId && this.chatPanelRef.current.setCurrentCellId) {
            this.chatPanelRef.current.setCurrentCellId(cellId);
        }
        // Set the display prompt in the input field
        this.chatPanelRef.current.setInput(displayPrompt);
        // Store the LLM prompt
        this.chatPanelRef.current.setLlmPrompt(llmPrompt);
        // Automatically execute after a short delay to ensure state is updated
        setTimeout(() => {
            if (this.chatPanelRef.current) {
                this.chatPanelRef.current.handleSendMessage().catch(error => {
                    console.error('[AgentPanel] Failed to send message automatically:', error);
                });
            }
        }, 100);
    }
    /**
     * 노트북 관련 메시지를 사이드 패널로 전송
     * 툴바 스파클 버튼에서 호출됨
     */
    sendNotebookMessage(prompt) {
        if (!this.chatPanelRef.current) {
            console.error('[AgentPanel] ChatPanel ref not available');
            return;
        }
        if (this.chatPanelRef.current.setInputMode) {
            this.chatPanelRef.current.setInputMode('chat');
        }
        const message = `@notebook ${prompt}`;
        this.chatPanelRef.current.sendChatMessage({
            displayContent: message,
            llmPrompt: message,
            clearInput: true,
        });
    }
    /**
     * Analyze entire notebook before saving
     * @param cells - Array of collected cells with content, output, and imports
     * @param onComplete - Callback to execute after analysis (perform save)
     */
    analyzeNotebook(cells, onComplete) {
        console.log('[AgentPanel] analyzeNotebook called with', cells.length, 'cells');
        if (!this.chatPanelRef.current) {
            console.error('[AgentPanel] ChatPanel ref not available');
            onComplete();
            return;
        }
        // 저장 시 코드리뷰도 항상 일반 대화(chat) 모드로 전환
        if (this.chatPanelRef.current.setInputMode) {
            this.chatPanelRef.current.setInputMode('chat');
        }
        // Create summary of notebook
        const totalCells = cells.length;
        const cellsWithErrors = cells.filter(cell => cell.output && (cell.output.includes('Error') ||
            cell.output.includes('Traceback') ||
            cell.output.includes('Exception'))).length;
        const cellsWithImports = cells.filter(cell => cell.imports && cell.imports.length > 0).length;
        const localImports = cells.reduce((acc, cell) => {
            if (cell.imports) {
                return acc + cell.imports.filter((imp) => imp.isLocal).length;
            }
            return acc;
        }, 0);
        const moduleSummary = cells._moduleSummary || {};
        const crossCellDeps = cells._crossCellDeps || [];
        const modulesWithSource = Object.keys(moduleSummary).length;
        const shownModules = new Set();
        // Build notebook content (reusable across calls)
        let notebookContent = `다음은 저장하기 전의 Jupyter 노트북 전체 내용입니다.

## 노트북 요약
- 전체 셀 수: ${totalCells}개
- 에러가 있는 셀: ${cellsWithErrors}개
- Import가 있는 셀: ${cellsWithImports}개
- 로컬 모듈 import: ${localImports}개 (소스 코드 포함: ${modulesWithSource}개)
- 셀 간 의존 관계: ${crossCellDeps.length}개

## 전체 셀 내용

`;
        cells.forEach((cell, index) => {
            notebookContent += `### 셀 ${index + 1} (ID: ${cell.id})
\`\`\`python
${cell.content}
\`\`\`
`;
            if (cell.output) {
                const normalized = cell.output
                    .replace(/Out\[\d+\]/g, 'Out[...]')
                    .replace(/In\[\d+\]/g, 'In[...]')
                    .replace(/\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?/g, '[TIMESTAMP]')
                    .replace(/[ \t]+$/gm, '');
                notebookContent += `
**실행 결과:**
\`\`\`
${normalized}
\`\`\`
`;
            }
            if (cell.imports && cell.imports.length > 0) {
                notebookContent += `
**Imports:**
`;
                cell.imports.forEach((imp) => {
                    notebookContent += `- \`${imp.module}\` (${imp.isLocal ? '로컬' : '표준 라이브러리'})\n`;
                });
            }
            // Render local module sources (deduplicated across cells)
            if (cell.localModuleSources && Object.keys(cell.localModuleSources).length > 0) {
                for (const [mod, source] of Object.entries(cell.localModuleSources)) {
                    if (!shownModules.has(mod)) {
                        notebookContent += `\n**로컬 모듈 \`${mod}\` 소스:**\n\`\`\`python\n${source}\n\`\`\`\n`;
                        shownModules.add(mod);
                    }
                }
            }
            notebookContent += '\n---\n\n';
        });
        const { callPlan, perspectives, commonRules } = buildReviewPrompts(notebookContent, totalCells);
        const chatPanel = this.chatPanelRef.current;
        const executeReviewCalls = async () => {
            // 코드리뷰 안내 메시지 표시
            if (chatPanel.addAssistantMessage) {
                chatPanel.addAssistantMessage('코드리뷰를 시작합니다. 아래 **4가지 관점**으로 분석합니다.\n\n' +
                    '| 순서 | 섹션 | 설명 |\n' +
                    '|:---:|------|------|\n' +
                    '| 1 | **보안** | 코드 내 취약점 점검 |\n' +
                    '| 2 | **성능개선** | 코드 성능 최적화 |\n' +
                    '| 3 | **코드품질** | 코드 구조, 일관성, 에러 처리, 네이밍 점검 |\n' +
                    '| 4 | **요약** | 1~3을 셀단위로 요약 |\n');
            }
            for (let i = 0; i < callPlan.length; i++) {
                const plan = callPlan[i];
                const selectedPrompts = plan.perspectiveIndices
                    .map(idx => perspectives[idx].prompt)
                    .join('\n\n');
                const sectionLabels = plan.perspectiveIndices.map(idx => perspectives[idx].label).join(', ');
                const llmPrompt = notebookContent +
                    '\n## 코드리뷰 요청 사항\n' +
                    `이 요청은 ${callPlan.length}개 호출 중 ${i + 1}번째입니다. "${sectionLabels}" 섹션만 작성하세요.\n` +
                    '다른 섹션(이전 호출에서 이미 분석됨)은 절대 포함하지 마세요.\n\n' +
                    selectedPrompts + '\n' + commonRules;
                const displayPrompt = `${plan.displayLabel} (${totalCells}개 셀) [${i + 1}/${callPlan.length}]`;
                for (let attempt = 0; attempt < 2; attempt++) {
                    try {
                        await chatPanel.sendChatMessage({
                            displayContent: displayPrompt,
                            llmPrompt,
                            clearInput: false,
                            maxTokens: REVIEW_MAX_TOKENS,
                            freshConversation: true,
                        });
                        break;
                    }
                    catch (error) {
                        if (attempt === 0) {
                            console.warn(`[AgentPanel] Review call ${i + 1} failed, retrying in 2s...`, error);
                            await new Promise(r => setTimeout(r, 2000));
                        }
                        else {
                            console.error(`[AgentPanel] Review call ${i + 1} failed after retry:`, error);
                            if (chatPanel.addAssistantMessage) {
                                chatPanel.addAssistantMessage(`⚠️ **${plan.displayLabel}** 분석 중 오류가 발생했습니다. (${error instanceof Error ? error.message : 'network error'})\n\n다른 섹션은 계속 진행합니다.`);
                            }
                        }
                    }
                }
            }
            // 코드리뷰 완료 메시지
            if (chatPanel.addAssistantMessage) {
                chatPanel.addAssistantMessage('✅ **코드리뷰가 완료되었습니다.**');
            }
        };
        executeReviewCalls()
            .catch(error => {
            console.error('[AgentPanel] Code review failed:', error);
        })
            .finally(() => {
            console.log('[AgentPanel] Analysis complete, executing onComplete callback');
            onComplete();
        });
    }
    /**
     * Analyze a general file (non-notebook) for code review
     * Called from save-interceptor-plugin for .py etc. files
     */
    analyzeFile(filePath, onComplete) {
        console.log('[AgentPanel] analyzeFile called for', filePath);
        if (!this.chatPanelRef.current) {
            console.error('[AgentPanel] ChatPanel ref not available');
            onComplete();
            return;
        }
        if (this.chatPanelRef.current.setInputMode) {
            this.chatPanelRef.current.setInputMode('chat');
        }
        const chatPanel = this.chatPanelRef.current;
        const doReview = async () => {
            const readResult = await this.apiService.readFile(filePath);
            if (!readResult.success || !readResult.content) {
                console.error('[AgentPanel] Failed to read file:', filePath);
                onComplete();
                return;
            }
            const ext = filePath.split('.').pop() || '';
            const langMap = { py: 'python', js: 'javascript', ts: 'typescript', jsx: 'jsx', tsx: 'tsx', java: 'java', sql: 'sql', sh: 'bash', yaml: 'yaml', yml: 'yaml', json: 'json' };
            const lang = langMap[ext] || ext;
            const fileContent = `다음은 코드리뷰 대상 파일입니다.\n\n## 파일 정보\n- 파일 경로: ${filePath}\n\n## 파일 내용\n\n\`\`\`${lang}\n${readResult.content}\n\`\`\`\n`;
            const lines = readResult.content.split('\n').length;
            const { callPlan, perspectives, commonRules } = buildReviewPrompts(fileContent, lines);
            // 코드리뷰 안내 메시지 표시
            if (chatPanel.addAssistantMessage) {
                chatPanel.addAssistantMessage('코드리뷰를 시작합니다. 아래 **4가지 관점**으로 분석합니다.\n\n' +
                    '| 순서 | 섹션 | 설명 |\n' +
                    '|:---:|------|------|\n' +
                    '| 1 | **보안** | 코드 내 취약점 점검 |\n' +
                    '| 2 | **성능개선** | 코드 성능 최적화 |\n' +
                    '| 3 | **코드품질** | 코드 구조, 일관성, 에러 처리, 네이밍 점검 |\n' +
                    '| 4 | **요약** | 1~3을 셀단위로 요약 |\n');
            }
            for (let i = 0; i < callPlan.length; i++) {
                const plan = callPlan[i];
                const selectedPrompts = plan.perspectiveIndices.map(idx => perspectives[idx].prompt).join('\n\n');
                const sectionLabels = plan.perspectiveIndices.map(idx => perspectives[idx].label).join(', ');
                const llmPrompt = fileContent + '\n## 코드리뷰 요청 사항\n' +
                    `이 요청은 ${callPlan.length}개 호출 중 ${i + 1}번째입니다. "${sectionLabels}" 섹션만 작성하세요.\n` +
                    '다른 섹션(이전 호출에서 이미 분석됨)은 절대 포함하지 마세요.\n\n' +
                    selectedPrompts + '\n' + commonRules;
                const displayPrompt = `${plan.displayLabel} [${i + 1}/${callPlan.length}]`;
                for (let attempt = 0; attempt < 2; attempt++) {
                    try {
                        await chatPanel.sendChatMessage({
                            displayContent: displayPrompt,
                            llmPrompt,
                            clearInput: false,
                            maxTokens: REVIEW_MAX_TOKENS,
                            freshConversation: true,
                        });
                        break;
                    }
                    catch (error) {
                        if (attempt === 0) {
                            console.warn(`[AgentPanel] Review call ${i + 1} failed, retrying in 2s...`, error);
                            await new Promise(r => setTimeout(r, 2000));
                        }
                        else {
                            console.error(`[AgentPanel] Review call ${i + 1} failed after retry:`, error);
                            if (chatPanel.addAssistantMessage) {
                                chatPanel.addAssistantMessage(`⚠️ **${plan.displayLabel}** 분석 중 오류가 발생했습니다. (${error instanceof Error ? error.message : 'network error'})\n\n다른 섹션은 계속 진행합니다.`);
                            }
                        }
                    }
                }
            }
            // 코드리뷰 완료 메시지
            if (chatPanel.addAssistantMessage) {
                chatPanel.addAssistantMessage('✅ **코드리뷰가 완료되었습니다.**');
            }
        };
        doReview()
            .catch(error => console.error('[AgentPanel] File review failed:', error))
            .finally(() => {
            console.log('[AgentPanel] File analysis complete');
            onComplete();
        });
    }
}


/***/ },

/***/ "./lib/components/ContextAutocomplete.js"
/*!***********************************************!*\
  !*** ./lib/components/ContextAutocomplete.js ***!
  \***********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ContextAutocomplete: () => (/* binding */ ContextAutocomplete),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_InsertDriveFile__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/icons-material/InsertDriveFile */ "./node_modules/@mui/icons-material/esm/InsertDriveFile.js");
/* harmony import */ var _mui_icons_material_Folder__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/Folder */ "./node_modules/@mui/icons-material/esm/Folder.js");
/* harmony import */ var _mui_icons_material_Description__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/Description */ "./node_modules/@mui/icons-material/esm/Description.js");
/**
 * Context Autocomplete Component
 *
 * Provides autocomplete functionality for @file and other context commands.
 * Inspired by jupyter-ai's autocomplete implementation.
 */




/**
 * Extract the word at cursor position that might be a context command.
 * Returns the partial command (e.g., "@file:" or "@file:src/")
 */
function getPartialCommand(text, cursorPosition) {
    // Find the start of the current word
    let start = cursorPosition;
    while (start > 0 && !/\s/.test(text[start - 1])) {
        start--;
    }
    const word = text.slice(start, cursorPosition);
    // Check if it looks like a context command (@ for context, / for actions)
    if (word.startsWith('@') || word.startsWith('/')) {
        return word;
    }
    return null;
}
/**
 * Get icon for autocomplete option
 */
function getOptionIcon(option) {
    const description = option.description.toLowerCase();
    if (description.includes('directory') || description.includes('folder')) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Folder__WEBPACK_IMPORTED_MODULE_2__["default"], { sx: { fontSize: 16, color: 'var(--jp-ui-font-color2)' } });
    }
    if (description.includes('python') || description.includes('.py')) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_InsertDriveFile__WEBPACK_IMPORTED_MODULE_1__["default"], { sx: { fontSize: 16, color: '#3572A5' } });
    }
    if (description.includes('notebook') || description.includes('.ipynb')) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_InsertDriveFile__WEBPACK_IMPORTED_MODULE_1__["default"], { sx: { fontSize: 16, color: '#F37626' } });
    }
    if (description.includes('javascript') || description.includes('typescript')) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_InsertDriveFile__WEBPACK_IMPORTED_MODULE_1__["default"], { sx: { fontSize: 16, color: '#f1e05a' } });
    }
    if (description.includes('markdown')) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Description__WEBPACK_IMPORTED_MODULE_3__["default"], { sx: { fontSize: 16, color: 'var(--jp-ui-font-color2)' } });
    }
    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_InsertDriveFile__WEBPACK_IMPORTED_MODULE_1__["default"], { sx: { fontSize: 16, color: 'var(--jp-ui-font-color2)' } });
}
const ContextAutocomplete = ({ apiService, inputValue, cursorPosition, baseDir, onSelect, onClose, onOptionsChange, visible, anchorEl, placement, }) => {
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [selectedIndex, setSelectedIndex] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [partialCommand, setPartialCommand] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const containerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    // Fetch autocomplete options
    const fetchOptions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (partial) => {
        setLoading(true);
        try {
            const response = await apiService.getContextAutocomplete({
                partialCommand: partial,
                baseDir,
            });
            setOptions(response.options);
            setSelectedIndex(0);
        }
        catch (error) {
            console.error('[ContextAutocomplete] Failed to fetch options:', error);
            setOptions([]);
        }
        finally {
            setLoading(false);
        }
    }, [apiService, baseDir]);
    // Update options when input changes
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const partial = getPartialCommand(inputValue, cursorPosition);
        setPartialCommand(partial);
        if (partial) {
            // Debounce the fetch
            const timer = setTimeout(() => {
                fetchOptions(partial);
            }, 150);
            return () => clearTimeout(timer);
        }
        else {
            setOptions([]);
        }
    }, [inputValue, cursorPosition, fetchOptions]);
    // Notify parent when options change
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        onOptionsChange?.(options.length > 0);
    }, [options, onOptionsChange]);
    // Handle keyboard navigation
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!visible || options.length === 0)
            return;
        const handleKeyDown = (e) => {
            const selectedOption = options[selectedIndex];
            switch (e.key) {
                case 'ArrowDown':
                    e.preventDefault();
                    setSelectedIndex(prev => (prev + 1) % options.length);
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    setSelectedIndex(prev => (prev - 1 + options.length) % options.length);
                    break;
                case 'Tab':
                    // Tab: Only navigate into directories (is_complete=false)
                    // On files (is_complete=true), do nothing
                    if (selectedOption && !selectedOption.is_complete) {
                        e.preventDefault();
                        onSelect(selectedOption, false); // viaEnter=false (Tab navigation)
                    }
                    else {
                        // On complete file, just prevent default but don't select
                        e.preventDefault();
                    }
                    break;
                case 'Enter':
                    // Enter: Select any option (directory or file) and close autocomplete
                    if (selectedOption) {
                        e.preventDefault();
                        e.stopPropagation(); // Prevent AgentPanel from sending message
                        onSelect(selectedOption, true); // viaEnter=true (final selection)
                    }
                    break;
                case 'Escape':
                    e.preventDefault();
                    onClose();
                    break;
            }
        };
        document.addEventListener('keydown', handleKeyDown, true);
        return () => document.removeEventListener('keydown', handleKeyDown, true);
    }, [visible, options, selectedIndex, onSelect, onClose]);
    // Scroll selected item into view
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (containerRef.current && options.length > 0) {
            const selectedItem = containerRef.current.querySelector('.jp-context-autocomplete-item--selected');
            if (selectedItem) {
                selectedItem.scrollIntoView({ block: 'nearest' });
            }
        }
    }, [selectedIndex, options]);
    // Close on click outside
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!visible || options.length === 0)
            return;
        const handleClickOutside = (e) => {
            if (containerRef.current && !containerRef.current.contains(e.target)) {
                // Also check if click is on the anchor element (textarea)
                if (anchorEl && !anchorEl.contains(e.target)) {
                    onClose();
                }
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [visible, options, anchorEl, onClose]);
    // Don't render if not visible or no partial command
    if (!visible || !partialCommand || options.length === 0) {
        return null;
    }
    // Calculate position based on anchor element
    const effectivePlacement = placement ?? 'above';
    const style = {
        position: 'absolute',
        left: 0,
        right: 0,
        zIndex: 1000,
        ...(effectivePlacement === 'above'
            ? { bottom: anchorEl ? anchorEl.offsetHeight + 4 : 'auto' }
            : { top: anchorEl ? anchorEl.offsetHeight + 4 : 'auto' }),
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: containerRef, className: "jp-context-autocomplete", style: style },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-context-autocomplete-header" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-context-autocomplete-hint" }, partialCommand.includes(':') ? 'Select a file' : 'Context commands'),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-context-autocomplete-loading" }, loading && 'Loading...')),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-context-autocomplete-list" }, options.map((option, index) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: `${option.id}-${option.label}-${index}`, className: `jp-context-autocomplete-item ${index === selectedIndex ? 'jp-context-autocomplete-item--selected' : ''}`, onClick: () => onSelect(option, true), onMouseEnter: () => setSelectedIndex(index) },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-context-autocomplete-item-icon" }, getOptionIcon(option)),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-context-autocomplete-item-label" }, option.label),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-context-autocomplete-item-description" }, option.description))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-context-autocomplete-footer" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("kbd", null, "Tab"),
            " navigate, ",
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("kbd", null, "Enter"),
            " select, ",
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("kbd", null, "Esc"),
            " close")));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContextAutocomplete);


/***/ },

/***/ "./lib/components/FileSelectionDialog.js"
/*!***********************************************!*\
  !*** ./lib/components/FileSelectionDialog.js ***!
  \***********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FileSelectionDialog: () => (/* binding */ FileSelectionDialog)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/**
 * File Selection Dialog - 파일 선택 다이얼로그 컴포넌트
 *
 * 파일명이 모호할 때 여러 파일 옵션을 사용자에게 표시
 */

const FileSelectionDialog = ({ filename, options, message, onSelect, onCancel }) => {
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-dialog" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-overlay", onClick: onCancel }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-content" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h3", null, "\uD30C\uC77C \uC120\uD0DD"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", { className: "file-selection-message" }, message),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-options" }, options.map((option, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { key: idx, className: "file-option-button", onClick: () => onSelect(idx + 1) },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "file-option-number" }, idx + 1),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "file-option-path" }, option.relative))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "file-selection-actions" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "file-selection-cancel", onClick: onCancel }, "\uCDE8\uC18C"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("style", null, `
        .file-selection-dialog {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          z-index: 10000;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .file-selection-overlay {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.5);
        }

        .file-selection-content {
          position: relative;
          background: var(--jp-layout-color1);
          border: 1px solid var(--jp-border-color1);
          border-radius: 8px;
          padding: 24px;
          max-width: 600px;
          width: 90%;
          max-height: 80vh;
          overflow-y: auto;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        }

        .file-selection-content h3 {
          margin: 0 0 12px 0;
          color: var(--jp-ui-font-color1);
          font-size: 18px;
          font-weight: 600;
        }

        .file-selection-message {
          margin: 0 0 20px 0;
          color: var(--jp-ui-font-color2);
          font-size: 14px;
          white-space: pre-wrap;
          line-height: 1.6;
        }

        .file-selection-options {
          display: flex;
          flex-direction: column;
          gap: 8px;
          margin-bottom: 20px;
        }

        .file-option-button {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px 16px;
          background: var(--jp-layout-color2);
          border: 1px solid var(--jp-border-color2);
          border-radius: 6px;
          cursor: pointer;
          transition: all 0.2s;
          text-align: left;
        }

        .file-option-button:hover {
          background: var(--jp-layout-color3);
          border-color: var(--jp-brand-color1);
          transform: translateY(-1px);
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .file-option-number {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 28px;
          height: 28px;
          background: var(--jp-brand-color1);
          color: white;
          border-radius: 50%;
          font-weight: 600;
          font-size: 14px;
          flex-shrink: 0;
        }

        .file-option-path {
          flex: 1;
          color: var(--jp-ui-font-color1);
          font-family: var(--jp-code-font-family);
          font-size: 13px;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .file-selection-actions {
          display: flex;
          justify-content: flex-end;
          gap: 8px;
        }

        .file-selection-cancel {
          padding: 8px 16px;
          background: transparent;
          border: 1px solid var(--jp-border-color2);
          border-radius: 4px;
          color: var(--jp-ui-font-color1);
          cursor: pointer;
          font-size: 14px;
          transition: all 0.2s;
        }

        .file-selection-cancel:hover {
          background: var(--jp-layout-color2);
          border-color: var(--jp-border-color1);
        }
      `)));
};


/***/ },

/***/ "./lib/components/PromptGenerationDialog.js"
/*!**************************************************!*\
  !*** ./lib/components/PromptGenerationDialog.js ***!
  \**************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PromptGenerationDialog: () => (/* binding */ PromptGenerationDialog)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_icons_material_AutoFixHigh__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/AutoFixHigh */ "./node_modules/@mui/icons-material/esm/AutoFixHigh.js");
/* harmony import */ var _mui_icons_material_Lightbulb__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/Lightbulb */ "./node_modules/@mui/icons-material/esm/Lightbulb.js");
/* harmony import */ var _ContextAutocomplete__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ContextAutocomplete */ "./lib/components/ContextAutocomplete.js");
/**
 * Prompt Generation Dialog - 프롬프트 생성 다이얼로그 컴포넌트
 * 노트북 생성을 위한 프롬프트 입력 다이얼로그
 */





const PromptGenerationDialog = ({ open, onClose, onGenerate, apiService }) => {
    const [prompt, setPrompt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isGenerating, setIsGenerating] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [progress, setProgress] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const [statusMessage, setStatusMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [showAutocomplete, setShowAutocomplete] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [hasAutocompleteOptions, setHasAutocompleteOptions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [cursorPosition, setCursorPosition] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const textareaRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const handleGenerate = () => {
        if (prompt.trim()) {
            setIsGenerating(true);
            onGenerate(prompt.trim());
            setPrompt('');
            setIsGenerating(false);
            onClose();
        }
    };
    const handleKeyDown = (event) => {
        // Let autocomplete handle keys when it's open with options
        if (showAutocomplete && hasAutocompleteOptions) {
            if (event.key === 'Tab' || event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                return;
            }
            if (event.key === 'Enter' && !event.shiftKey) {
                return;
            }
            if (event.key === 'Escape') {
                setShowAutocomplete(false);
                setHasAutocompleteOptions(false);
                return;
            }
        }
        if (event.key === 'Enter' && event.ctrlKey) {
            event.preventDefault();
            handleGenerate();
        }
    };
    const handleInputChange = (e) => {
        const newValue = e.target.value;
        const newCursorPosition = e.target.selectionStart || 0;
        setPrompt(newValue);
        setCursorPosition(newCursorPosition);
        // Find word from cursor back to whitespace
        let wordStart = newCursorPosition;
        while (wordStart > 0 && !/\s/.test(newValue[wordStart - 1])) {
            wordStart--;
        }
        const currentWord = newValue.slice(wordStart, newCursorPosition);
        if (currentWord.startsWith('@')) {
            setShowAutocomplete(true);
        }
        else {
            setShowAutocomplete(false);
        }
    };
    const handleAutocompleteSelect = (option, viaEnter) => {
        const text = prompt;
        // Find the @-command being typed
        let start = cursorPosition;
        while (start > 0 && !/\s/.test(text[start - 1])) {
            start--;
        }
        const beforeCommand = text.slice(0, start);
        const afterCursor = text.slice(cursorPosition);
        const addSpace = viaEnter && option.is_complete;
        const newText = beforeCommand + option.label + (addSpace ? ' ' : '') + afterCursor;
        const newCursor = start + option.label.length + (addSpace ? 1 : 0);
        setPrompt(newText);
        setCursorPosition(newCursor);
        if (viaEnter) {
            setShowAutocomplete(false);
            setHasAutocompleteOptions(false);
        }
        // Refocus textarea
        setTimeout(() => {
            if (textareaRef.current) {
                textareaRef.current.focus();
                textareaRef.current.setSelectionRange(newCursor, newCursor);
            }
        }, 0);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Dialog, { open: open, onClose: onClose, maxWidth: "md", fullWidth: true, PaperProps: {
            sx: {
                borderRadius: 2,
                minHeight: '400px'
            }
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogTitle, null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", alignItems: "center", gap: 1 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_AutoFixHigh__WEBPACK_IMPORTED_MODULE_2__["default"], { color: "primary" }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "h6" }, "Codebuff \uB178\uD2B8\uBD81 \uC790\uB3D9\uC0DD\uC131"))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogContent, { sx: { overflow: 'visible' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", flexDirection: "column", gap: 2, mt: 1 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "body2", color: "text.secondary" }, "\uC6D0\uD558\uB294 \uB178\uD2B8\uBD81\uC758 \uB0B4\uC6A9\uC744 \uC790\uC5F0\uC5B4\uB85C \uC124\uBA85\uD574\uC8FC\uC138\uC694. AI\uAC00 \uC790\uB3D9\uC73C\uB85C \uB178\uD2B8\uBD81\uC744 \uC0DD\uC131\uD569\uB2C8\uB2E4."),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { position: 'relative' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_ContextAutocomplete__WEBPACK_IMPORTED_MODULE_4__.ContextAutocomplete, { placement: "below", apiService: apiService, inputValue: prompt, cursorPosition: cursorPosition, onSelect: handleAutocompleteSelect, onClose: () => { setShowAutocomplete(false); setHasAutocompleteOptions(false); }, onOptionsChange: setHasAutocompleteOptions, visible: showAutocomplete, anchorEl: textareaRef.current }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("textarea", { ref: textareaRef, autoFocus: true, value: prompt, onChange: handleInputChange, onKeyDown: handleKeyDown, onSelect: (e) => setCursorPosition(e.target.selectionStart || 0), disabled: isGenerating, placeholder: "\uC608: \uD0C0\uC774\uD0C0\uB2C9 \uC0DD\uC874\uC790 \uC608\uCE21\uC744 dask\uC640 lgbm\uC73C\uB85C \uC0DD\uC131\uD574\uC918", rows: 6, style: {
                            width: '100%',
                            fontSize: '14px',
                            fontFamily: 'inherit',
                            padding: '16.5px 14px',
                            border: '1px solid rgba(0, 0, 0, 0.23)',
                            borderRadius: '4px',
                            resize: 'vertical',
                            outline: 'none',
                            boxSizing: 'border-box',
                            lineHeight: '1.4375em'
                        }, onFocus: (e) => { e.target.style.borderColor = '#1976d2'; e.target.style.borderWidth = '2px'; e.target.style.padding = '15.5px 13px'; }, onBlur: (e) => { e.target.style.borderColor = 'rgba(0, 0, 0, 0.23)'; e.target.style.borderWidth = '1px'; e.target.style.padding = '16.5px 14px'; } })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
                        backgroundColor: 'action.hover',
                        borderRadius: 1,
                        padding: 2
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary", component: "div", sx: { display: 'flex', flexDirection: 'column' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: { display: 'flex', alignItems: 'center', gap: 0.5 } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Lightbulb__WEBPACK_IMPORTED_MODULE_3__["default"], { fontSize: "small", sx: { color: '#ffc107' } }),
                            " ",
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("strong", null, "\uD301:")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 \uC0AC\uC6A9\uD560 \uB77C\uC774\uBE0C\uB7EC\uB9AC\uB97C \uBA85\uC2DC\uD558\uBA74 \uB354 \uC815\uD655\uD569\uB2C8\uB2E4",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 \uBD84\uC11D \uBAA9\uC801\uACFC \uB370\uC774\uD130\uB97C \uAD6C\uCCB4\uC801\uC73C\uB85C \uC124\uBA85\uD558\uC138\uC694",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 @file:\uB85C \uCC38\uACE0\uD560 \uD30C\uC77C\uC744 \uC9C0\uC815\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 Ctrl + Enter\uB85C \uBE60\uB974\uAC8C \uC0DD\uC131\uD560 \uC218 \uC788\uC2B5\uB2C8\uB2E4",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("br", null),
                        "\u2022 \uC0DD\uC131\uC740 \uBC31\uADF8\uB77C\uC6B4\uB4DC\uC5D0\uC11C \uC9C4\uD589\uB418\uBA70, \uC644\uB8CC\uB418\uBA74 \uC54C\uB9BC\uC744 \uBC1B\uC2B5\uB2C8\uB2E4")))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.DialogActions, { sx: { padding: 2, paddingTop: 0 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: onClose, disabled: isGenerating }, "\uCDE8\uC18C"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { onClick: handleGenerate, variant: "contained", disabled: !prompt.trim() || isGenerating, startIcon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_AutoFixHigh__WEBPACK_IMPORTED_MODULE_2__["default"], null) }, "\uC0DD\uC131 \uC2DC\uC791"))));
};


/***/ },

/***/ "./lib/components/RAGBrowserPanel.js"
/*!*******************************************!*\
  !*** ./lib/components/RAGBrowserPanel.js ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RAGBrowserPanel: () => (/* binding */ RAGBrowserPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _rag_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rag-shared */ "./lib/components/rag-shared.js");
/**
 * RAG Browser Panel — 데이터 브라우저 + 검색 테스트.
 */


const COLLECTIONS = ['enterprise_tables', 'bdp_tables', 'guide_docs', 'ds_guide_docs', 'codebase'];
const RAGBrowserPanel = ({ onClose }) => {
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({ browser: true, search: true });
    // Browser state
    const [browserCollection, setBrowserCollection] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('enterprise_tables');
    const [browserData, setBrowserData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [browserOffset, setBrowserOffset] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [browserHistory, setBrowserHistory] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [expandedRows, setExpandedRows] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(new Set());
    // Filter state (multi-filter, AND 조건)
    const [filters, setFilters] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([{ field: '', value: '' }]);
    // Search state
    const [searchQuery, setSearchQuery] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [searchCollection, setSearchCollection] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [searchResults, setSearchResults] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [expandedSearchRows, setExpandedSearchRows] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(new Set());
    const toggle = (k) => setExpanded(p => ({ ...p, [k]: !p[k] }));
    const showMsg = (msg) => { setMessage(msg); setTimeout(() => setMessage(''), 5000); };
    const toggleRow = (id) => {
        setExpandedRows(prev => {
            const next = new Set(prev);
            if (next.has(id))
                next.delete(id);
            else
                next.add(id);
            return next;
        });
    };
    const toggleSearchRow = (idx) => {
        setExpandedSearchRows(prev => {
            const next = new Set(prev);
            if (next.has(idx))
                next.delete(idx);
            else
                next.add(idx);
            return next;
        });
    };
    const browse = async (offset = null, pushHistory = true) => {
        setLoading(true);
        try {
            let params = offset ? `offset=${offset}&limit=10` : 'limit=10';
            const activeFilters = filters.filter(f => f.field && f.value);
            if (activeFilters.length > 0) {
                params += `&filters=${encodeURIComponent(JSON.stringify(activeFilters))}`;
            }
            const result = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)(`rag/admin/browse/${browserCollection}?${params}`);
            setBrowserData(result);
            if (pushHistory)
                setBrowserHistory(prev => [...prev, browserOffset]);
            setBrowserOffset(offset);
            setExpandedRows(new Set());
        }
        catch (e) {
            showMsg(`브라우저 오류: ${e.message}`);
        }
        setLoading(false);
    };
    const deletePoint = async (pointId) => {
        try {
            await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)(`rag/admin/browse/${browserCollection}`, 'DELETE', { pointId });
            browse(browserOffset, false);
        }
        catch (e) {
            showMsg(`삭제 실패: ${e.message}`);
        }
    };
    const searchTest = async () => {
        if (!searchQuery)
            return;
        setLoading(true);
        try {
            const result = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/search-test', 'POST', {
                query: searchQuery,
                collection: searchCollection || null,
                topK: 5,
            });
            setSearchResults(result.results || []);
            setExpandedSearchRows(new Set());
        }
        catch (e) {
            showMsg(`검색 실패: ${e.message}`);
        }
        setLoading(false);
    };
    /** payload에서 대표 요약 텍스트를 추출 */
    const getSummaryText = (payload) => {
        if (!payload)
            return '';
        // guide_docs: title > section
        if (payload.title) {
            let s = payload.title;
            if (payload.section)
                s += ` > ${payload.section}`;
            return s;
        }
        // table collections: 첫 번째 키 값
        const keys = Object.keys(payload).filter(k => !k.startsWith('_'));
        if (keys.length > 0) {
            const vals = keys.slice(0, 3).map(k => {
                const v = payload[k];
                if (typeof v === 'string')
                    return v.length > 40 ? v.substring(0, 40) + '...' : v;
                if (Array.isArray(v))
                    return `[${v.length}건]`;
                return String(v);
            });
            return vals.join(' | ');
        }
        return JSON.stringify(payload).substring(0, 60);
    };
    /** payload 키-값을 깔끔하게 렌더링 */
    const renderPayloadDetail = (payload) => {
        if (!payload)
            return null;
        const entries = Object.entries(payload);
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', flexDirection: 'column', gap: 6 } }, entries.map(([key, val]) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: key, style: { display: 'flex', gap: 8, fontSize: 12 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                    minWidth: 100,
                    fontWeight: 600,
                    color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary,
                    flexShrink: 0,
                    wordBreak: 'break-all',
                } }, key),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                    color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray700,
                    wordBreak: 'break-all',
                    whiteSpace: 'pre-wrap',
                    lineHeight: 1.5,
                    flex: 1,
                } }, typeof val === 'string'
                ? val
                : JSON.stringify(val, null, 2)))))));
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.PanelContainer, null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.PanelHeader, { title: "\uB370\uC774\uD130 \uD0D0\uC0C9", subtitle: "\uC801\uC7AC\uB41C \uB370\uC774\uD130 \uC870\uD68C \uBC0F \uAC80\uC0C9 \uD14C\uC2A4\uD2B8" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Toast, { message: message }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "\uB370\uC774\uD130 \uBE0C\uB77C\uC6B0\uC800", icon: "\uD83D\uDD0D", expanded: expanded.browser, onToggle: () => toggle('browser') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { style: { fontSize: 12, fontWeight: 500, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600 } }, "\uCEEC\uB809\uC158"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { value: browserCollection, onChange: e => setBrowserCollection(e.target.value), style: {
                        padding: '6px 10px',
                        fontSize: 13,
                        border: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray300}`,
                        borderRadius: 6,
                        outline: 'none',
                        background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.white,
                    } }, COLLECTIONS.map(c => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { key: c, value: c }, c)))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC870\uD68C", onClick: () => { setBrowserHistory([]); browse(null, false); }, variant: "primary", disabled: loading })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                    marginBottom: 12,
                    padding: '8px 10px',
                    background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray50,
                    borderRadius: 6,
                    border: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}`,
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { style: { fontSize: 11, fontWeight: 500, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray500 } }, "\uD544\uD130 (AND)"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: () => setFilters(prev => [...prev, { field: '', value: '' }]), style: {
                            fontSize: 11,
                            color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary,
                            background: 'none',
                            border: 'none',
                            cursor: 'pointer',
                            padding: '2px 6px',
                            fontWeight: 500,
                        } }, "+ \uCD94\uAC00")),
                filters.map((f, idx) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: idx, style: { display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", value: f.field, onChange: e => {
                            const next = [...filters];
                            next[idx] = { ...next[idx], field: e.target.value };
                            setFilters(next);
                        }, placeholder: "\uD544\uB4DC (\uC608: source, columns[].col_name)", style: {
                            padding: '4px 8px',
                            fontSize: 12,
                            border: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray300}`,
                            borderRadius: 4,
                            outline: 'none',
                            flex: 1,
                            minWidth: 0,
                        } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontSize: 11, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400 } }, "="),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "text", value: f.value, onChange: e => {
                            const next = [...filters];
                            next[idx] = { ...next[idx], value: e.target.value };
                            setFilters(next);
                        }, placeholder: "\uAC12", style: {
                            padding: '4px 8px',
                            fontSize: 12,
                            border: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray300}`,
                            borderRadius: 4,
                            outline: 'none',
                            flex: 1,
                            minWidth: 0,
                        } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: () => {
                            if (filters.length <= 1) {
                                setFilters([{ field: '', value: '' }]);
                            }
                            else {
                                setFilters(prev => prev.filter((_, i) => i !== idx));
                            }
                        }, style: {
                            fontSize: 11,
                            color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400,
                            background: 'none',
                            border: 'none',
                            cursor: 'pointer',
                            padding: '2px 4px',
                            flexShrink: 0,
                        } }, "\u2715")))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: 10, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400, marginTop: 4 } }, "\uBC30\uC5F4 \uB0B4\uBD80 \uD544\uD130: columns[].col_name = \uAC12")),
            browserData && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: 12, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray500, marginBottom: 8 } },
                    browserData.count,
                    "\uAC74 \uD45C\uC2DC",
                    filters.filter(f => f.field && f.value).map((f, i) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { key: i, style: {
                            marginLeft: 6,
                            fontSize: 11,
                            background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primaryLight,
                            color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary,
                            padding: '1px 8px',
                            borderRadius: 10,
                        } },
                        f.field,
                        " = ",
                        f.value)))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { maxHeight: 500, overflow: 'auto' } }, browserData.items?.map((item) => {
                    const isExpanded = expandedRows.has(item.id);
                    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: item.id, style: {
                            marginBottom: 6,
                            background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.white,
                            borderRadius: 8,
                            border: `1px solid ${isExpanded ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}`,
                            overflow: 'hidden',
                            transition: 'border-color 0.15s',
                        } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: () => toggleRow(item.id), style: {
                                display: 'flex',
                                alignItems: 'center',
                                padding: '8px 12px',
                                cursor: 'pointer',
                                background: isExpanded ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray50 : 'transparent',
                                gap: 8,
                                userSelect: 'none',
                            } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                                    fontSize: 10,
                                    color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400,
                                    transition: 'transform 0.15s',
                                    transform: isExpanded ? 'rotate(90deg)' : 'none',
                                    flexShrink: 0,
                                } }, "\u25B6"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("code", { style: {
                                    fontSize: 11,
                                    color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary,
                                    fontWeight: 600,
                                    flexShrink: 0,
                                } }, item.id.substring(0, 8)),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                                    fontSize: 12,
                                    color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600,
                                    flex: 1,
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    whiteSpace: 'nowrap',
                                } }, getSummaryText(item.payload)),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: e => { e.stopPropagation(); deletePoint(item.id); }, style: {
                                    fontSize: 11,
                                    color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.danger,
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                    padding: '2px 6px',
                                    borderRadius: 4,
                                    flexShrink: 0,
                                    opacity: 0.6,
                                }, onMouseEnter: e => (e.currentTarget.style.opacity = '1'), onMouseLeave: e => (e.currentTarget.style.opacity = '0.6') }, "\uC0AD\uC81C")),
                        isExpanded && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                                padding: '12px 16px',
                                borderTop: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}`,
                                background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.white,
                            } }, renderPayloadDetail(item.payload)))));
                })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: 10, display: 'flex', gap: 6 } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\u2190 \uC774\uC804", onClick: () => {
                            const prev = browserHistory[browserHistory.length - 1] ?? null;
                            setBrowserHistory(h => h.slice(0, -1));
                            browse(prev, false);
                        }, disabled: browserHistory.length === 0 }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uB2E4\uC74C \u2192", onClick: () => browse(browserData.next_offset), disabled: !browserData.next_offset }))))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "\uAC80\uC0C9 \uD14C\uC2A4\uD2B8", icon: "\u26A1", expanded: expanded.search, onToggle: () => toggle('search') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "\uAC80\uC0C9 \uCFFC\uB9AC", value: searchQuery, onChange: setSearchQuery, placeholder: "\uCE74\uB4DC \uAC70\uB798 \uD14C\uC774\uBE14" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { style: { fontSize: 12, fontWeight: 500, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600, minWidth: 120 } }, "\uCEEC\uB809\uC158"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("select", { value: searchCollection, onChange: e => setSearchCollection(e.target.value), style: {
                        padding: '6px 10px',
                        fontSize: 13,
                        border: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray300}`,
                        borderRadius: 6,
                        outline: 'none',
                        flex: 1,
                        background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.white,
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "" }, "\uC804\uCCB4"),
                    COLLECTIONS.map(c => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { key: c, value: c }, c)))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uAC80\uC0C9", onClick: searchTest, variant: "primary", disabled: loading || !searchQuery })),
            searchResults.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { maxHeight: 500, overflow: 'auto' } }, searchResults.map((r, i) => {
                const isExpanded = expandedSearchRows.has(i);
                return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: i, style: {
                        marginBottom: 6,
                        background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.white,
                        borderRadius: 8,
                        border: `1px solid ${isExpanded ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}`,
                        overflow: 'hidden',
                        transition: 'border-color 0.15s',
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: () => toggleSearchRow(i), style: {
                            display: 'flex',
                            alignItems: 'center',
                            padding: '8px 12px',
                            cursor: 'pointer',
                            background: isExpanded ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray50 : 'transparent',
                            gap: 8,
                            userSelect: 'none',
                        } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                                fontSize: 10,
                                color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400,
                                transition: 'transform 0.15s',
                                transform: isExpanded ? 'rotate(90deg)' : 'none',
                                flexShrink: 0,
                            } }, "\u25B6"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                                fontSize: 11,
                                fontWeight: 600,
                                color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray700,
                                flexShrink: 0,
                            } }, r.collection),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                                fontSize: 12,
                                color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600,
                                flex: 1,
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap',
                            } }, getSummaryText(r.payload)),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                                fontSize: 11,
                                fontWeight: 700,
                                color: r.score >= 0.8 ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.success : r.score >= 0.5 ? '#d97706' : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.danger,
                                background: r.score >= 0.8 ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.successLight : r.score >= 0.5 ? '#fffbeb' : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.dangerLight,
                                padding: '1px 8px',
                                borderRadius: 10,
                                flexShrink: 0,
                            } }, typeof r.score === 'number' ? r.score.toFixed(3) : r.score)),
                    isExpanded && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                            padding: '12px 16px',
                            borderTop: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}`,
                            background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.white,
                        } }, renderPayloadDetail(r.payload)))));
            }))),
            searchResults.length === 0 && searchQuery && !loading && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400, fontSize: 12, textAlign: 'center', padding: 16 } }, "\uAC80\uC0C9 \uBC84\uD2BC\uC744 \uB20C\uB7EC \uACB0\uACFC\uB97C \uD655\uC778\uD558\uC138\uC694")))));
};


/***/ },

/***/ "./lib/components/RAGLoadPanel.js"
/*!****************************************!*\
  !*** ./lib/components/RAGLoadPanel.js ***!
  \****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RAGLoadPanel: () => (/* binding */ RAGLoadPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _rag_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rag-shared */ "./lib/components/rag-shared.js");
/**
 * RAG Load Panel — 4개 컬렉션 적재 및 적재 이력.
 */


const RAGLoadPanel = ({ onClose }) => {
    const [config, setConfig] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [stats, setStats] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [history, setHistory] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        enterprise: true,
        bdp: false,
        guide: false,
        dsGuide: false,
        stats: true,
        history: false,
    });
    // localStorage persistence helpers
    const LS_KEY = 'rag_load_settings';
    const loadLS = () => {
        try {
            return JSON.parse(localStorage.getItem(LS_KEY) || '{}');
        }
        catch {
            return {};
        }
    };
    const saveLS = (patch) => {
        try {
            localStorage.setItem(LS_KEY, JSON.stringify({ ...loadLS(), ...patch }));
        }
        catch { /* ignore */ }
    };
    const ls = loadLS();
    // Collection state (restore from localStorage)
    const [enterpriseFile, setEnterpriseFile] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(ls.enterpriseFile || '');
    const [enterpriseMapping, setEnterpriseMapping] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(ls.enterpriseMapping || {});
    const [bdpTableFile, setBdpTableFile] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(ls.bdpTableFile || '');
    const [bdpColumnFile, setBdpColumnFile] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(ls.bdpColumnFile || '');
    const [bdpJoinKey, setBdpJoinKey] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(ls.bdpJoinKey || 'table_id');
    const [bdpMapping, setBdpMapping] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(ls.bdpMapping || {});
    // CSV headers
    const [csvHeaders, setCsvHeaders] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [bdpHeaders, setBdpHeaders] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    // Preview / Progress
    const [previewData, setPreviewData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [progress, setProgress] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // Chunking (from config)
    const [chunkTargetSize, setChunkTargetSize] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(800);
    const [chunkMinSize, setChunkMinSize] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(150);
    const [chunkMaxSize, setChunkMaxSize] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(2000);
    const toggle = (k) => setExpanded(p => ({ ...p, [k]: !p[k] }));
    const showMsg = (msg) => { setMessage(msg); setTimeout(() => setMessage(''), 5000); };
    const loadData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        try {
            const [cfgData, statsData, histData] = await Promise.all([
                (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/config'),
                (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/stats').catch(() => ({ stats: {} })),
                (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/history').catch(() => ({ history: [] })),
            ]);
            setConfig(cfgData);
            setStats(statsData.stats || {});
            setHistory(histData.history || []);
            if (cfgData.chunking) {
                setChunkTargetSize(cfgData.chunking.target_size || 800);
                setChunkMinSize(cfgData.chunking.min_size || 150);
                setChunkMaxSize(cfgData.chunking.max_size || 2000);
            }
        }
        catch (e) {
            showMsg(`로드 실패: ${e.message}`);
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => { loadData(); }, [loadData]);
    // ---- CSV header loading ----
    const loadCsvHeaders = async (filePath, setter) => {
        try {
            const result = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/preview', 'POST', { filePath, type: 'csv_headers' });
            (setter || setCsvHeaders)(result.headers || []);
        }
        catch (e) {
            showMsg(`헤더 로드 실패: ${e.message}`);
        }
    };
    const loadBdpHeaders = async (tableFile, colFile) => {
        try {
            const headers = new Set();
            if (tableFile) {
                const r1 = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/preview', 'POST', { filePath: tableFile, type: 'csv_headers' });
                (r1.headers || []).forEach((h) => headers.add(h));
            }
            if (colFile) {
                const r2 = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/preview', 'POST', { filePath: colFile, type: 'csv_headers' });
                (r2.headers || []).forEach((h) => headers.add(h));
            }
            setBdpHeaders(Array.from(headers).sort());
        }
        catch (e) {
            showMsg(`BDP 헤더 로드 실패: ${e.message}`);
        }
    };
    // Persist collection settings to localStorage on change
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        saveLS({ enterpriseFile, enterpriseMapping, bdpTableFile, bdpColumnFile, bdpJoinKey, bdpMapping });
    }, [enterpriseFile, enterpriseMapping, bdpTableFile, bdpColumnFile, bdpJoinKey, bdpMapping]);
    // Restore CSV headers on mount if file paths exist
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (enterpriseFile)
            loadCsvHeaders(enterpriseFile);
        if (bdpTableFile || bdpColumnFile)
            loadBdpHeaders(bdpTableFile, bdpColumnFile);
    }, []); // eslint-disable-line react-hooks/exhaustive-deps
    // ---- Upsert ----
    const upsertCollection = async (collection, filePath, mapping, joinFilePath, joinKey) => {
        setLoading(true);
        try {
            const body = { collection, filePath, mapping };
            if (joinFilePath)
                body.joinFilePath = joinFilePath;
            if (joinKey)
                body.joinKey = joinKey;
            if (collection === 'guide_docs' || collection === 'ds_guide_docs') {
                body.chunking = { target_size: chunkTargetSize, min_size: chunkMinSize, max_size: chunkMaxSize, overlap: 0 };
            }
            setProgress({ status: 'starting' });
            const pollId = window.setInterval(async () => {
                try {
                    const p = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/progress');
                    setProgress(p);
                    if (p.status === 'done' || p.status === 'idle')
                        window.clearInterval(pollId);
                }
                catch { /* ignore */ }
            }, 1000);
            try {
                const result = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/upsert', 'POST', body);
                window.clearInterval(pollId);
                setProgress(null);
                const skipped = result.skipped ? `, 기존 ${result.skipped}건 스킵` : '';
                showMsg(`적재 완료: ${result.total_chunks || result.total || 0}건 (${result.elapsed_s || 0}s${skipped})`);
                await loadData();
            }
            catch (e) {
                window.clearInterval(pollId);
                setProgress(null);
                showMsg(`적재 실패: ${e.message}`);
            }
        }
        catch (e) {
            showMsg(`적재 실패: ${e.message}`);
        }
        setLoading(false);
    };
    const deleteCollection = async (name) => {
        if (!confirm(`${name} 컬렉션을 초기화하시겠습니까?`))
            return;
        setLoading(true);
        try {
            await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)(`rag/admin/collection/${name}`, 'DELETE');
            showMsg(`${name} 초기화 완료`);
            await loadData();
        }
        catch (e) {
            showMsg(`초기화 실패: ${e.message}`);
        }
        setLoading(false);
    };
    const dryRun = async (collection, filePath, mapping) => {
        setLoading(true);
        try {
            const body = { collection, filePath, mapping };
            if (collection === 'bdp_tables') {
                body.joinFilePath = bdpColumnFile;
                body.joinKey = bdpJoinKey;
            }
            if (collection === 'guide_docs' || collection === 'ds_guide_docs') {
                body.chunking = { target_size: chunkTargetSize, min_size: chunkMinSize, max_size: chunkMaxSize };
            }
            const result = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/dry-run', 'POST', body);
            setPreviewData(result);
            showMsg('프리뷰 완료');
        }
        catch (e) {
            showMsg(`프리뷰 실패: ${e.message}`);
        }
        setLoading(false);
    };
    const validateCsv = async (filePath, mapping) => {
        try {
            const result = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/validate', 'POST', { filePath, mapping });
            showMsg(result.valid ? `검증 통과 (${result.total_rows}행)` : `검증 실패: ${result.missing_fields?.join(', ')}`);
        }
        catch (e) {
            showMsg(`검증 실패: ${e.message}`);
        }
    };
    if (!config) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: 40, textAlign: 'center', color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400 } }, "\uB85C\uB4DC \uC911...");
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.PanelContainer, null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.PanelHeader, { title: "RAG \uC801\uC7AC", subtitle: "\uCEEC\uB809\uC158 \uB370\uC774\uD130 \uC801\uC7AC \uBC0F \uBCC0\uD658" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Toast, { message: message }),
        progress && progress.status !== 'idle' && progress.status !== 'done' && progress.status !== 'cancelled' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { margin: '0 0 12px', padding: '10px 14px', background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray50, borderRadius: 8, border: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}` } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontSize: 12, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray500 } }, progress.total
                    ? `${progress.collection || ''} 적재 중... ${progress.done || 0}/${progress.total}`
                    : '적재 준비 중...'),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC911\uC9C0", variant: "danger", onClick: async () => {
                        try {
                            await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/cancel', 'POST');
                            showMsg('적재 중지 요청됨');
                        }
                        catch { /* ignore */ }
                    } })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { height: 6, background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200, borderRadius: 3, overflow: 'hidden' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                        height: '100%',
                        width: progress.total ? `${Math.round(((progress.done || 0) / progress.total) * 100)}%` : '0%',
                        background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary,
                        borderRadius: 3,
                        transition: 'width 0.3s ease',
                    } })))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "\uC804\uC0AC \uD14C\uC774\uBE14", icon: "\uD83C\uDFE2", badge: `${stats.enterprise_tables?.points || 0}개`, expanded: expanded.enterprise, onToggle: () => toggle('enterprise') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "\uB370\uC774\uD130 \uD30C\uC77C (CSV/Parquet)", value: enterpriseFile, onChange: v => { setEnterpriseFile(v); if (v)
                    loadCsvHeaders(v); }, placeholder: "/home/jovyan/data/tables.csv \uB610\uB294 .parquet" }),
            csvHeaders.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.MappingEditor, { headers: csvHeaders, mapping: enterpriseMapping, onChange: setEnterpriseMapping })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: 12, display: 'flex', gap: 6 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uAC80\uC99D", onClick: () => validateCsv(enterpriseFile, enterpriseMapping), disabled: !enterpriseFile }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uD504\uB9AC\uBDF0", onClick: () => dryRun('enterprise_tables', enterpriseFile, enterpriseMapping), disabled: !enterpriseFile }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC801\uC7AC \uC2E4\uD589", onClick: () => upsertCollection('enterprise_tables', enterpriseFile, enterpriseMapping), variant: "primary", disabled: loading || !enterpriseFile }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uCD08\uAE30\uD654", onClick: () => deleteCollection('enterprise_tables'), variant: "danger" }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "BDP \uD14C\uC774\uBE14", icon: "\uD83D\uDCCB", badge: `${stats.bdp_tables?.points || 0}개`, expanded: expanded.bdp, onToggle: () => toggle('bdp') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "\uD14C\uC774\uBE14 \uD30C\uC77C (CSV/Parquet)", value: bdpTableFile, onChange: v => { setBdpTableFile(v); if (v)
                    loadBdpHeaders(v, bdpColumnFile); }, placeholder: "/home/jovyan/data/bdp_tables.csv \uB610\uB294 .parquet" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "\uCEEC\uB7FC \uD30C\uC77C (CSV/Parquet)", value: bdpColumnFile, onChange: v => { setBdpColumnFile(v); if (v)
                    loadBdpHeaders(bdpTableFile, v); }, placeholder: "/home/jovyan/data/bdp_columns.csv \uB610\uB294 .parquet" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "\uC870\uC778 \uD0A4", value: bdpJoinKey, onChange: setBdpJoinKey }),
            bdpHeaders.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.MappingEditor, { headers: bdpHeaders, mapping: bdpMapping, onChange: setBdpMapping })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: 12, display: 'flex', gap: 6 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uD504\uB9AC\uBDF0", onClick: () => dryRun('bdp_tables', bdpTableFile, bdpMapping), disabled: !bdpTableFile }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC801\uC7AC \uC2E4\uD589", onClick: () => upsertCollection('bdp_tables', bdpTableFile, bdpMapping, bdpColumnFile, bdpJoinKey), variant: "primary", disabled: loading || !bdpTableFile }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uCD08\uAE30\uD654", onClick: () => deleteCollection('bdp_tables'), variant: "danger" }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.GuidePipelineCard, { title: "BDP \uAC00\uC774\uB4DC \uBB38\uC11C", icon: "\uD83D\uDCD6", collection: "guide_docs", points: stats.guide_docs?.points || 0, expanded: expanded.guide, onToggle: () => toggle('guide'), loading: loading, onDeleteCollection: () => deleteCollection('guide_docs') }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.GuidePipelineCard, { title: "DS \uAC00\uC774\uB4DC \uBB38\uC11C", icon: "\uD83D\uDCD7", collection: "ds_guide_docs", points: stats.ds_guide_docs?.points || 0, expanded: expanded.dsGuide, onToggle: () => toggle('dsGuide'), loading: loading, onDeleteCollection: () => deleteCollection('ds_guide_docs') }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "\uCEEC\uB809\uC158 \uD604\uD669", icon: "\uD83D\uDCCA", expanded: expanded.stats, onToggle: () => toggle('stats') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', gap: 10, flexWrap: 'wrap' } }, ['enterprise_tables', 'bdp_tables', 'guide_docs', 'ds_guide_docs'].map(name => {
                const s = stats[name] || { points: 0, status: 'unknown' };
                const labelMap = {
                    enterprise_tables: '전사 테이블',
                    bdp_tables: 'BDP 테이블',
                    guide_docs: 'BDP 가이드',
                    ds_guide_docs: 'DS 가이드',
                };
                const label = labelMap[name] || name;
                return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: name, style: {
                        flex: 1,
                        minWidth: 130,
                        padding: '14px 12px',
                        background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray50,
                        borderRadius: 10,
                        border: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}`,
                        textAlign: 'center',
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: 22, fontWeight: 700, color: s.points > 0 ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400 } }, s.points),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: 11, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray500, marginTop: 2, marginBottom: 8 } }, label),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: () => deleteCollection(name), disabled: loading || s.points === 0, style: {
                            fontSize: 11,
                            padding: '3px 10px',
                            borderRadius: 6,
                            border: `1px solid ${s.points > 0 ? '#fecaca' : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}`,
                            background: s.points > 0 ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.dangerLight : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray100,
                            color: s.points > 0 ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.danger : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400,
                            cursor: s.points > 0 ? 'pointer' : 'default',
                            fontWeight: 500,
                        } }, "\uC804\uCCB4 \uC0AD\uC81C")));
            }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "\uC801\uC7AC \uC774\uB825", icon: "\uD83D\uDCDC", expanded: expanded.history, onToggle: () => toggle('history') }, history.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400, fontSize: 12, textAlign: 'center', padding: 12 } }, "\uC774\uB825 \uC5C6\uC74C")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { maxHeight: 280, overflow: 'auto' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("table", { style: { width: '100%', fontSize: 12, borderCollapse: 'collapse' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("thead", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { style: { borderBottom: `2px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}` } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", { style: { textAlign: 'left', padding: '6px 8px', fontWeight: 600, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600 } }, "\uC2DC\uAC01"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", { style: { textAlign: 'left', padding: '6px 8px', fontWeight: 600, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600 } }, "\uCEEC\uB809\uC158"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", { style: { textAlign: 'right', padding: '6px 8px', fontWeight: 600, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600 } }, "\uAC74\uC218"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", { style: { textAlign: 'right', padding: '6px 8px', fontWeight: 600, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600 } }, "\uC2DC\uAC04"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("th", { style: { textAlign: 'center', padding: '6px 8px', fontWeight: 600, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600 } }, "\uC0C1\uD0DC"))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tbody", null, [...history].reverse().map((h, i) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("tr", { key: i, style: { borderBottom: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray100}` } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { style: { padding: '6px 8px', color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray500 } }, h.timestamp.substring(5, 16)),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { style: { padding: '6px 8px' } }, h.collection),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { style: { textAlign: 'right', padding: '6px 8px', fontWeight: 600 } }, h.count),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { style: { textAlign: 'right', padding: '6px 8px', color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray500 } },
                        h.elapsed_s,
                        "s"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("td", { style: { textAlign: 'center', padding: '6px 8px' } }, h.errors.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.danger, fontWeight: 600 } },
                        h.errors.length,
                        " err")) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.success } }, "OK"))))))))))),
        previewData && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { margin: '0 20px 20px', background: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray50, borderRadius: 10, border: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}`, overflow: 'hidden' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', borderBottom: `1px solid ${_rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray200}` } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontWeight: 600, fontSize: 13, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray700 } }, "\uD504\uB9AC\uBDF0 \uACB0\uACFC"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uB2EB\uAE30", onClick: () => setPreviewData(null), size: "sm" })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("pre", { style: { fontSize: 11, maxHeight: 300, overflow: 'auto', whiteSpace: 'pre-wrap', padding: 14, margin: 0 } }, JSON.stringify(previewData, null, 2))))));
};


/***/ },

/***/ "./lib/components/RAGSettingsPanel.js"
/*!********************************************!*\
  !*** ./lib/components/RAGSettingsPanel.js ***!
  \********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RAGSettingsPanel: () => (/* binding */ RAGSettingsPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _rag_shared__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./rag-shared */ "./lib/components/rag-shared.js");
/**
 * RAG Settings Panel — Qdrant 연결, 임베딩, 청킹 설정.
 * 각 섹션별 개별 저장 버튼.
 */


const RAGSettingsPanel = ({ onClose }) => {
    const [config, setConfig] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        qdrant: true,
        embedding: true,
        chunking: false,
    });
    const [chunkTargetSize, setChunkTargetSize] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(800);
    const [chunkMinSize, setChunkMinSize] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(150);
    const [chunkMaxSize, setChunkMaxSize] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(2000);
    const toggle = (k) => setExpanded(p => ({ ...p, [k]: !p[k] }));
    const showMsg = (msg) => { setMessage(msg); setTimeout(() => setMessage(''), 5000); };
    const loadData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        try {
            const cfgData = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/config');
            setConfig(cfgData);
            if (cfgData.chunking) {
                setChunkTargetSize(cfgData.chunking.target_size || 800);
                setChunkMinSize(cfgData.chunking.min_size || 150);
                setChunkMaxSize(cfgData.chunking.max_size || 2000);
            }
        }
        catch (e) {
            showMsg(`로드 실패: ${e.message}`);
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => { loadData(); }, [loadData]);
    const saveSection = async (section) => {
        if (!config)
            return;
        setLoading(true);
        try {
            const body = {};
            if (section === 'qdrant') {
                body.qdrantMode = config.qdrantMode;
                body.qdrantUrl = config.qdrantUrl;
                body.qdrantApiKey = config.qdrantApiKey;
                body.qdrantPath = config.qdrantPath;
            }
            else if (section === 'embedding') {
                body.embeddingEndpoint = config.embeddingEndpoint;
                body.embeddingApiKey = config.embeddingApiKey;
                body.embeddingModel = config.embeddingModel;
                body.embeddingDimension = config.embeddingDimension;
            }
            else {
                body.chunking = { target_size: chunkTargetSize, min_size: chunkMinSize, max_size: chunkMaxSize, overlap: 0 };
            }
            await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/config', 'POST', body);
            showMsg(`${section === 'qdrant' ? 'Qdrant' : section === 'embedding' ? '임베딩' : '청킹'} 설정 저장 완료`);
            await loadData();
        }
        catch (e) {
            showMsg(`저장 실패: ${e.message}`);
        }
        setLoading(false);
    };
    const testConnection = async (type) => {
        setLoading(true);
        try {
            const result = await (0,_rag_shared__WEBPACK_IMPORTED_MODULE_1__.apiCall)('rag/admin/test-connection', 'POST', { type });
            showMsg(result.success ? `${type} 연결 성공` : `${type} 연결 실패: ${result.error}`);
        }
        catch (e) {
            showMsg(`연결 테스트 실패: ${e.message}`);
        }
        setLoading(false);
    };
    const updateConfig = (key, value) => {
        if (!config)
            return;
        setConfig({ ...config, [key]: value });
    };
    if (!config) {
        return react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: 40, textAlign: 'center', color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400 } }, "\uC124\uC815 \uB85C\uB4DC \uC911...");
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.PanelContainer, null,
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.PanelHeader, { title: "RAG \uC124\uC815", subtitle: "Qdrant \uC5F0\uACB0, \uC784\uBCA0\uB529 \uBAA8\uB378, \uCCAD\uD0B9 \uD30C\uB77C\uBBF8\uD130" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Toast, { message: message }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "Qdrant \uC5F0\uACB0", icon: "\uD83D\uDDC4\uFE0F", expanded: expanded.qdrant, onToggle: () => toggle('qdrant') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginBottom: 10 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { style: { fontSize: 12, fontWeight: 500, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600, marginRight: 16 } }, "\uBAA8\uB4DC"),
                ['local', 'server'].map(mode => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { key: mode, style: {
                        fontSize: 12,
                        marginRight: 14,
                        padding: '4px 10px',
                        borderRadius: 6,
                        border: `1px solid ${config.qdrantMode === mode ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray300}`,
                        background: config.qdrantMode === mode ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primaryLight : 'transparent',
                        color: config.qdrantMode === mode ? _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.primary : _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray600,
                        cursor: 'pointer',
                        fontWeight: 500,
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "radio", name: "qdrantMode", value: mode, checked: config.qdrantMode === mode, onChange: () => updateConfig('qdrantMode', mode), style: { display: 'none' } }),
                    mode === 'local' ? 'Local (파일)' : 'Server (원격)')))),
            config.qdrantMode === 'server' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "URL", value: config.qdrantUrl, onChange: v => updateConfig('qdrantUrl', v) }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "API Key", value: config.qdrantApiKey, onChange: v => updateConfig('qdrantApiKey', v), type: "password" }))),
            config.qdrantMode === 'local' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "\uC800\uC7A5 \uACBD\uB85C", value: config.qdrantPath, onChange: v => updateConfig('qdrantPath', v) })),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: 10, display: 'flex', gap: 6 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC5F0\uACB0 \uD14C\uC2A4\uD2B8", onClick: () => testConnection('qdrant'), disabled: loading }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC800\uC7A5", onClick: () => saveSection('qdrant'), variant: "primary", disabled: loading }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "\uC784\uBCA0\uB529 \uBAA8\uB378", icon: "\uD83E\uDDE0", expanded: expanded.embedding, onToggle: () => toggle('embedding') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "Endpoint", value: config.embeddingEndpoint, onChange: v => updateConfig('embeddingEndpoint', v), placeholder: "https://..." }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "API Key", value: config.embeddingApiKey, onChange: v => updateConfig('embeddingApiKey', v), type: "password" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "Model", value: config.embeddingModel, onChange: v => updateConfig('embeddingModel', v) }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "Dimension", value: config.embeddingDimension, onChange: v => updateConfig('embeddingDimension', parseInt(v) || 0), type: "number" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: 10, display: 'flex', gap: 6 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC5F0\uACB0 \uD14C\uC2A4\uD2B8", onClick: () => testConnection('embedding'), disabled: loading }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC800\uC7A5", onClick: () => saveSection('embedding'), variant: "primary", disabled: loading }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Card, { title: "\uCCAD\uD0B9 \uC124\uC815", icon: "\u2702\uFE0F", expanded: expanded.chunking, onToggle: () => toggle('chunking') },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "Target Size (\uC790)", value: chunkTargetSize, onChange: v => setChunkTargetSize(parseInt(v) || 800), type: "number" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "Min Size (\uC790)", value: chunkMinSize, onChange: v => setChunkMinSize(parseInt(v) || 150), type: "number" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.InputField, { label: "Max Size (\uC790)", value: chunkMaxSize, onChange: v => setChunkMaxSize(parseInt(v) || 2000), type: "number" }),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: 11, color: _rag_shared__WEBPACK_IMPORTED_MODULE_1__.colors.gray400, marginTop: 4 } }, "Overlap: 0 (\uD5E4\uB354 \uD504\uB9AC\uD53D\uC2A4 + LLM \uC694\uC57D\uC73C\uB85C \uB300\uCCB4)"),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: 10 } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_rag_shared__WEBPACK_IMPORTED_MODULE_1__.Btn, { label: "\uC800\uC7A5", onClick: () => saveSection('chunking'), variant: "primary", disabled: loading })))));
};


/***/ },

/***/ "./lib/components/SettingsPanel.js"
/*!*****************************************!*\
  !*** ./lib/components/SettingsPanel.js ***!
  \*****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SettingsPanel: () => (/* binding */ SettingsPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../services/ApiKeyManager */ "./lib/services/ApiKeyManager.js");
/**
 * Settings Panel Component
 * User preference settings panel
 *
 * NOTE: LLM settings (provider, API keys, models, prompts) are now managed
 * by the Agent Server's AdminConfig. This panel only handles user preferences:
 * - workspaceRoot: User's workspace directory
 * - autoApprove: Skip human approval for code execution
 */


const SettingsPanel = ({ onClose, onSave, currentConfig }) => {
    // Initialize from localStorage or props
    const initConfig = currentConfig || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_1__.getLLMConfig)() || (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_1__.getDefaultLLMConfig)();
    // User preferences (the only settings stored in localStorage)
    const [workspaceRoot, setWorkspaceRoot] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initConfig.workspaceRoot || '');
    const [autoApprove, setAutoApprove] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(Boolean(initConfig.autoApprove));
    // Update state when currentConfig changes
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (currentConfig) {
            setWorkspaceRoot(currentConfig.workspaceRoot || '');
            setAutoApprove(Boolean(currentConfig.autoApprove));
        }
    }, [currentConfig]);
    // Build config from state
    const buildLLMConfig = () => ({
        workspaceRoot: workspaceRoot.trim() ? workspaceRoot.trim() : undefined,
        autoApprove
    });
    const handleSave = () => {
        const config = buildLLMConfig();
        // Save to localStorage
        (0,_services_ApiKeyManager__WEBPACK_IMPORTED_MODULE_1__.saveLLMConfig)(config);
        // Notify parent component
        onSave(config);
        onClose();
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-overlay" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-dialog" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null, "\uC0AC\uC6A9\uC790 \uC124\uC815"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-close", onClick: onClose, title: "\uB2EB\uAE30" }, "\u00D7")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-content" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-notice" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "LLM \uC124\uC815 (\uD504\uB85C\uBC14\uC774\uB354, API \uD0A4, \uBAA8\uB378, \uD504\uB86C\uD504\uD2B8)\uC740 \uAD00\uB9AC\uC790 \uC124\uC815\uC5D0\uC11C \uAD00\uB9AC\uB429\uB2C8\uB2E4.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label", htmlFor: "jp-agent-workspace-root" },
                        "\uC6CC\uD06C\uC2A4\uD398\uC774\uC2A4 \uB8E8\uD2B8",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { fontWeight: 'normal', marginLeft: '8px', color: '#666' } }, "\uBE44\uC6B0\uBA74 \uD604\uC7AC \uB178\uD2B8\uBD81 \uD3F4\uB354 \uAE30\uC900, \uC808\uB300/\uC0C1\uB300 \uACBD\uB85C \uAC00\uB2A5")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { id: "jp-agent-workspace-root", type: "text", className: "jp-agent-settings-input", value: workspaceRoot, onChange: (e) => setWorkspaceRoot(e.target.value), placeholder: "\uC608: /Users/you/project", "data-testid": "workspace-root-input" })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uC790\uB3D9 \uC2E4\uD589 \uC2B9\uC778"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-checkbox" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: autoApprove, onChange: (e) => setAutoApprove(e.target.checked), "data-testid": "auto-approve-checkbox" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "\uC2B9\uC778 \uC5C6\uC774 \uBC14\uB85C \uC2E4\uD589 (\uCF54\uB4DC/\uD30C\uC77C/\uC178 \uD3EC\uD568)")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginTop: '4px', marginLeft: '24px' } }, "\uD65C\uC131\uD654 \uC2DC Human-in-the-Loop \uC2B9\uC778 \uB2E8\uACC4\uB97C \uAC74\uB108\uB701\uB2C8\uB2E4"))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-footer" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-secondary", onClick: onClose }, "\uCDE8\uC18C"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-primary", onClick: handleSave }, "\uC800\uC7A5")))));
};


/***/ },

/***/ "./lib/components/StreamingMessage.js"
/*!********************************************!*\
  !*** ./lib/components/StreamingMessage.js ***!
  \********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   StreamingMessage: () => (/* binding */ StreamingMessage),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "webpack/sharing/consume/default/react-dom");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useStreamingMarkdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../hooks/useStreamingMarkdown */ "./lib/hooks/useStreamingMarkdown.js");
/* harmony import */ var _code_blocks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./code-blocks */ "./lib/components/code-blocks/index.js");
/* harmony import */ var _utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../utils/markdownRenderer */ "./lib/utils/markdownRenderer.js");
/**
 * StreamingMessage - A component that renders markdown with streaming support
 *
 * Phase 4 Implementation:
 * - Uses JupyterLab Rendermime when available for native rendering
 * - Falls back to custom formatMarkdownToHtml for compatibility
 * - Debounced rendering to reduce flickering during streaming
 * - Writing indicator while content is being generated
 * - Code block toolbar with copy/insert functionality
 */





const MD_MIME_TYPE = 'text/markdown';
/**
 * Get the global rendermime registry if available
 */
function getGlobalRenderMimeRegistry() {
    return window._hdspRenderMimeRegistry || null;
}
/**
 * Post-process Rendermime-rendered code blocks to apply syntax highlighting.
 * Rendermime generates <pre><code class="language-python"> but without token-level coloring.
 */
function highlightRendermimeCodeBlocks(contentDiv) {
    const codeElements = contentDiv.querySelectorAll('pre code[class*="language-"]');
    codeElements.forEach((codeEl) => {
        // Skip if already highlighted
        if (codeEl.querySelector('.syntax-keyword, .syntax-string, .syntax-comment'))
            return;
        const language = extractLanguageFromClass(codeEl.className);
        if (!language)
            return;
        const rawText = codeEl.textContent || '';
        let html;
        switch (language) {
            case 'python':
            case 'py':
                html = (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_4__.highlightPython)(rawText);
                break;
            case 'javascript':
            case 'js':
            case 'typescript':
            case 'ts':
                html = (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_4__.highlightJavaScript)(rawText);
                break;
            case 'diff':
                html = (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_4__.highlightDiff)(rawText);
                break;
            case 'json':
                html = (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_4__.highlightJson)(rawText);
                break;
            default:
                return;
        }
        codeEl.innerHTML = html;
    });
}
/**
 * Writing indicator component shown during streaming
 */
/**
 * Status history shown above streaming content (persists during streaming)
 */
const StatusHistory = ({ statusText }) => {
    const lines = statusText.split('\n');
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: '12px', color: 'var(--jp-ui-font-color2)', lineHeight: '1.5', marginBottom: '6px', padding: '4px 0' } }, lines.map((line, i) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: i, style: { opacity: i === lines.length - 1 ? 1 : 0.6 } }, line)))));
};
const WritingIndicator = ({ hasContent, toolProcessing }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-streaming-indicator" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-streaming-dots" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-streaming-dot" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-streaming-dot" }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-streaming-dot" })),
    !hasContent && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-streaming-text" }, toolProcessing ? 'AI가 도구 호출 결과를 분석하고 있습니다...' : 'AI가 응답을 생성하고 있습니다...'))));
/**
 * Sanitize a quoted label: encode inner `"` as &quot;, `[]` as `()`
 */
function sanitizeLabel(content) {
    return content.replace(/"/g, '&quot;').replace(/\[/g, '(').replace(/\]/g, ')');
}
/**
 * Replace nested [] inside node labels with ().
 * Uses bracket depth tracking instead of regex.
 * e.g. A["state['key']=None"] → A["state('key')=None"]
 *      A[data[0] value]       → A[data(0) value]
 */
function flattenNestedBrackets(code) {
    const result = [];
    let i = 0;
    while (i < code.length) {
        // Look for word[ pattern (node label start)
        if (code[i] === '[' && i > 0 && /\w/.test(code[i - 1])) {
            // Check it's not [[ (subroutine) — handle separately
            if (code[i + 1] === '[') {
                // Skip [[ ... ]] — find matching ]]
                result.push(code[i], code[i + 1]);
                i += 2;
                let depth = 1;
                while (i < code.length && depth > 0) {
                    if (code[i] === '[' && code[i + 1] === '[') {
                        depth++;
                        result.push(code[i], code[i + 1]);
                        i += 2;
                        continue;
                    }
                    if (code[i] === ']' && code[i + 1] === ']') {
                        depth--;
                        if (depth === 0) {
                            result.push(']', ']');
                            i += 2;
                            break;
                        }
                        result.push(']', ']');
                        i += 2;
                        continue;
                    }
                    result.push(code[i]);
                    i++;
                }
                continue;
            }
            // Single [ — track depth, replace inner [] with ()
            result.push('[');
            i++;
            let depth = 1;
            while (i < code.length && depth > 0) {
                if (code[i] === '[') {
                    depth++;
                    result.push('(');
                    i++;
                    continue;
                }
                if (code[i] === ']') {
                    depth--;
                    if (depth === 0) {
                        result.push(']');
                        i++;
                        break;
                    }
                    result.push(')');
                    i++;
                    continue;
                }
                if (code[i] === '\n') {
                    result.push(code[i]);
                    i++;
                    break;
                } // newline = unclosed, bail
                result.push(code[i]);
                i++;
            }
        }
        else {
            result.push(code[i]);
            i++;
        }
    }
    return result.join('');
}
/**
 * Preprocess Mermaid code blocks to fix common syntax errors.
 * Rules derived from @probelabs/maid fix patterns.
 *
 * Categories:
 *  1. Comments — remove %% inline comments
 *  2. Reserved keywords — rename node IDs that collide with keywords
 *  3. Arrow syntax — fix invalid arrows (-> to -->)
 *  4. Node labels — quote/encode special chars in labels
 *  5. Edge labels — fix quoted/bracket edge labels
 *  6. Subgraph — quote titles with spaces
 *  7. Unclosed brackets — close mismatched brackets
 *  8. Empty labels — remove empty shape labels
 *  9. Direction — fix invalid direction keywords
 */
function preprocessMermaid(markdown) {
    return markdown.replace(/```mermaid\s*\n([\s\S]*?)```/g, (_match, code) => {
        let processed = code;
        // === 1. Remove %% comments (inline comments break parser) ===
        processed = processed.replace(/%%.*$/gm, '');
        // === 2. Reserved keyword collision ===
        // Only rename 'end' — the most common collision when used as node ID.
        // Protect: 'end' alone on a line (subgraph closer) or inside
        // class/style/click directives (node references).
        processed = processed.replace(/^(\s*)end(\s*)$/gm, '$1__END_PH__$2');
        // Protect class/style/click directive lines entirely
        processed = processed.replace(/^(\s*(?:class|style|click|classDef|linkStyle)\b.*)$/gm, (line) => line.replace(/\bend\b/g, '__END_PH__'));
        // Rename remaining 'end' as node ID (use suffix to avoid tokenizer issues)
        processed = processed.replace(/\bend\b/g, 'end_node');
        processed = processed.replace(/__END_PH__/g, 'end');
        // === 3. Escaped quotes — convert \" to &quot; (before label processing) ===
        processed = processed.replace(/\\"/g, '&quot;');
        // === 4. Arrow syntax — fix invalid arrows ===
        // Single arrow -> to --> (but not inside labels/quotes)
        processed = processed.replace(/(\s)->([\s\w])/g, '$1-->$2');
        // Fix -. -> -.-> (dotted arrow missing dot)
        processed = processed.replace(/(\s)-\.(\s)/g, '$1-.->$2');
        // === 4b. Nested brackets & misquoted labels ===
        // Handles two cases that break the step-5 regex:
        //   (a) Nested brackets: H["dask[dataframe] 설치"] — inner [] escaped
        //   (b) Misquoted close: E["rcParams['family'"] 설정] — " in wrong position
        // Uses pure depth counting on [ ] to find true label extent.
        processed = processed.replace(/^(.*)$/gm, (line) => {
            const result = [];
            let i = 0;
            while (i < line.length) {
                if (i > 0 &&
                    /\w/.test(line[i - 1]) &&
                    line[i] === '[' &&
                    line[i + 1] !== '[' &&
                    line[i + 1] !== '(' &&
                    line[i + 1] !== '/' &&
                    line[i + 1] !== '\\') {
                    // Depth-count to find the matching ]
                    let depth = 1;
                    let j = i + 1;
                    while (j < line.length && depth > 0) {
                        if (line[j] === '[')
                            depth++;
                        else if (line[j] === ']')
                            depth--;
                        if (depth > 0)
                            j++;
                    }
                    if (depth === 0) {
                        // j points to the matching ]
                        let inner = line.slice(i + 1, j);
                        // Strip surrounding quotes
                        if (inner.startsWith('"') && inner.endsWith('"')) {
                            inner = inner.slice(1, -1);
                        }
                        else if (inner.startsWith('"')) {
                            // Misquoted: opening " but no matching closing "
                            // The stray " inside was a misplaced delimiter — strip all
                            inner = inner.replace(/"/g, '');
                        }
                        // Only transform if special chars exist; leave simple labels for step 5
                        if (/[\[\]"]/.test(inner)) {
                            const escaped = inner
                                .replace(/\[/g, '&#91;')
                                .replace(/\]/g, '&#93;')
                                .replace(/"/g, '&quot;');
                            result.push(`["${escaped}"]`);
                        }
                        else {
                            result.push(line.slice(i, j + 1));
                        }
                        i = j + 1;
                    }
                    else {
                        result.push(line[i]);
                        i++;
                    }
                }
                else {
                    result.push(line[i]);
                    i++;
                }
            }
            return result.join('');
        });
        // === 5. Node labels — quote and encode special chars ===
        // Pre-pass: flatten nested [] inside labels to () via depth tracking
        processed = flattenNestedBrackets(processed);
        // [[content]] (subroutine) — process before single brackets
        processed = processed.replace(/(\b\w+)\[\[([^\]\n]*)\]\]/g, (m, id, content) => {
            if (content.startsWith('"') && content.endsWith('"'))
                return m;
            return `${id}[["${sanitizeLabel(content)}"]]`;
        });
        // [content] (rectangle) — skip [[ [( variants; /\ are quoted to prevent shape interpretation
        processed = processed.replace(/(\b\w+)\[(?!\[|\()([^\]\n]*)\]/g, (m, id, content) => {
            if (content.startsWith('"') && content.endsWith('"'))
                return m;
            return `${id}["${sanitizeLabel(content)}"]`;
        });
        // Note: () and {} labels are NOT processed to avoid cross-contamination
        // with composite shapes like ([text]), ((text)), and nested patterns
        // inside already-quoted [] labels. [] covers 90%+ of cases.
        // === 6. Edge labels — fix bracket/quote issues ===
        // Encode brackets inside pipe-delimited edge labels: |[text]| → |&#91;text&#93;|
        processed = processed.replace(/\|([^|]*)\|/g, (m, content) => {
            if (!/[\[\]]/.test(content))
                return m;
            return `|${content.replace(/\[/g, '&#91;').replace(/\]/g, '&#93;')}|`;
        });
        // === 7. Subgraph — quote unquoted titles with spaces ===
        processed = processed.replace(/^(\s*subgraph\s+)(?!")([^\n]*[ \t][^\n]*)$/gm, (m, prefix, title) => {
            // Skip if it looks like: subgraph id [title]
            if (/^\w+\s*\[/.test(title))
                return m;
            return `${prefix}"${title.replace(/"/g, '&quot;')}"`;
        });
        // === 8. Empty labels — remove A[""] patterns ===
        processed = processed.replace(/(\b\w+)\[""\]/g, '$1');
        // === 9. Direction — fix invalid direction values ===
        processed = processed.replace(/^(\s*direction\s+)(?!TB|BT|LR|RL|TD)(\w+)/gm, '$1TD');
        return '```mermaid\n' + processed + '```';
    });
}
/**
 * Escape LaTeX delimiters for proper rendering with Rendermime
 */
function escapeLatexDelimiters(text) {
    return text
        .replace(/\\\(/g, '\\\\(')
        .replace(/\\\)/g, '\\\\)')
        .replace(/\\\[/g, '\\\\[')
        .replace(/\\\]/g, '\\\\]');
}
/**
 * Close incomplete markdown blocks for streaming
 */
function closeIncompleteBlocks(content) {
    let result = content;
    // Close unclosed code blocks
    const codeBlockMatches = result.match(/```/g);
    const codeBlockCount = codeBlockMatches ? codeBlockMatches.length : 0;
    if (codeBlockCount % 2 !== 0) {
        result += '\n```';
    }
    return result;
}
/**
 * Check if content has incomplete code blocks
 */
function hasIncompleteCodeBlock(content) {
    const codeBlockMatches = content.match(/```/g);
    const codeBlockCount = codeBlockMatches ? codeBlockMatches.length : 0;
    return codeBlockCount % 2 !== 0;
}
/**
 * Extract language from a code block's class name
 */
function extractLanguageFromClass(className) {
    // Look for language-* class
    const match = className.match(/language-(\w+)/);
    if (match) {
        return match[1];
    }
    // Also try hljs class format
    const hljsMatch = className.match(/hljs\s+(\w+)/);
    if (hljsMatch) {
        return hljsMatch[1];
    }
    return undefined;
}
/**
 * StreamingMessage component with hybrid rendering and code toolbars
 */
const StreamingMessage = react__WEBPACK_IMPORTED_MODULE_0___default().memo(({ content, isStreaming = false, className = '', debounceMs = 16, onClick, useRendermime = true, onInsertAbove, onInsertBelow, onInsertAsCell, cellActionsEnabled = true, statusText, toolProcessing = false, }) => {
    const containerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const rendererRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const lastContentRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)('');
    const [codeToolbarDefs, setCodeToolbarDefs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const toolbarRootsRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)([]);
    // Throttle refs for native Rendermime streaming render
    const pendingRenderRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const latestContentForRender = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)('');
    // Synchronously determine renderer type (useMemo instead of useState+useEffect)
    // Use fallback renderer for summary JSON (native renderer doesn't parse it)
    const useNativeRenderer = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        const rmRegistry = getGlobalRenderMimeRegistry();
        const hasSummaryJson = content && content.includes('"summary"') && content.includes('"next_items"');
        return useRendermime && rmRegistry !== null && !hasSummaryJson;
    }, [useRendermime, content]);
    // Use custom hook for fallback rendering
    const { renderedHtml, isRendering: isFallbackRendering, hasIncompleteBlocks, } = (0,_hooks_useStreamingMarkdown__WEBPACK_IMPORTED_MODULE_2__.useStreamingMarkdown)(content, {
        debounceMs,
        isStreaming,
        forceImmediate: !isStreaming,
    });
    /**
     * Attach code toolbars to all pre blocks in the rendered content
     */
    const attachCodeToolbars = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((contentDiv) => {
        // Clean up old toolbar roots via ref (avoids stale closure over state)
        toolbarRootsRef.current.forEach(root => {
            if (root.parentNode) {
                root.parentNode.removeChild(root);
            }
        });
        toolbarRootsRef.current = [];
        const preBlocks = contentDiv.querySelectorAll('pre');
        const newDefs = [];
        const newRoots = [];
        preBlocks.forEach((preBlock) => {
            const container = preBlock.closest('.code-block-container');
            let language;
            if (container) {
                // Fallback renderer (formatMarkdownToHtml): hide old-style header buttons,
                // replace with CodeToolbar for consistent UI across chat/agent modes
                const header = container.querySelector('.code-block-header');
                if (header) {
                    // Extract language before hiding
                    const langEl = header.querySelector('.code-block-language');
                    language = langEl?.textContent?.trim().toLowerCase() || undefined;
                    // Use class to override !important CSS rules
                    header.classList.add('jp-hdsp-hidden');
                }
            }
            else {
                // Native Rendermime path: extract language from code element class
                const codeElement = preBlock.querySelector('code');
                language = codeElement
                    ? extractLanguageFromClass(codeElement.className)
                    : undefined;
            }
            // Create toolbar root element
            const toolbarRoot = document.createElement('div');
            toolbarRoot.className = 'jp-hdsp-code-toolbar-container';
            // Insert toolbar after the pre block
            preBlock.parentNode?.insertBefore(toolbarRoot, preBlock.nextSibling);
            newRoots.push(toolbarRoot);
            newDefs.push({
                root: toolbarRoot,
                content: preBlock.textContent || '',
                language
            });
        });
        toolbarRootsRef.current = newRoots;
        setCodeToolbarDefs(newDefs);
    }, []);
    // Track whether renderer node is already mounted in DOM
    const rendererMountedRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    // Render content using Rendermime with double-buffering to prevent scroll jitter.
    // During streaming, renders to an off-screen clone, then swaps the finished DOM in
    // one synchronous operation — eliminating the height-collapse gap that causes jitter.
    const renderWithRendermime = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async (contentToRender) => {
        const rmRegistry = getGlobalRenderMimeRegistry();
        if (!rmRegistry || !containerRef.current) {
            return false;
        }
        // Skip if content hasn't changed
        if (contentToRender === lastContentRef.current) {
            return true;
        }
        lastContentRef.current = contentToRender;
        try {
            // Process content for streaming
            let processedContent = contentToRender;
            if (isStreaming && hasIncompleteCodeBlock(processedContent)) {
                processedContent = closeIncompleteBlocks(processedContent);
            }
            // Preprocess Mermaid node labels, escape LaTeX, fix bold with punctuation
            processedContent = preprocessMermaid(processedContent);
            let mdStr = escapeLatexDelimiters(processedContent);
            mdStr = (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_4__.preprocessForRendermime)(mdStr);
            // Create mime model
            const model = rmRegistry.createModel({
                data: { [MD_MIME_TYPE]: mdStr }
            });
            if (isStreaming) {
                // === Double-buffer path: render off-screen, swap synchronously ===
                // Create a fresh renderer each time (cheap) to avoid mutating the live DOM
                const offRenderer = rmRegistry.createRenderer(MD_MIME_TYPE);
                await offRenderer.renderModel(model);
                if (offRenderer.node && containerRef.current) {
                    const contentDiv = containerRef.current.querySelector('.jp-streaming-content');
                    if (contentDiv) {
                        // Single synchronous swap — no height collapse between clear and insert
                        contentDiv.replaceChildren(offRenderer.node);
                        rendererMountedRef.current = true;
                        // Dispose the previous renderer if we had one
                        if (rendererRef.current && rendererRef.current !== offRenderer) {
                            try {
                                rendererRef.current.dispose();
                            }
                            catch { /* noop */ }
                        }
                        rendererRef.current = offRenderer;
                    }
                }
            }
            else {
                // === Non-streaming path: reuse renderer, render in-place ===
                if (!rendererRef.current) {
                    rendererRef.current = rmRegistry.createRenderer(MD_MIME_TYPE);
                    rendererMountedRef.current = false;
                }
                const renderer = rendererRef.current;
                await renderer.renderModel(model);
                if (renderer.node && containerRef.current) {
                    const contentDiv = containerRef.current.querySelector('.jp-streaming-content');
                    if (contentDiv) {
                        if (!rendererMountedRef.current || !contentDiv.contains(renderer.node)) {
                            contentDiv.replaceChildren(renderer.node);
                            rendererMountedRef.current = true;
                        }
                        // Apply LaTeX typesetting if available
                        if (rmRegistry.latexTypesetter) {
                            rmRegistry.latexTypesetter.typeset(contentDiv);
                        }
                        // Note: code toolbars and syntax highlighting are attached by
                        // the useEffect that watches isStreaming/content, not here.
                        // Calling attachCodeToolbars here AND in useEffect caused a
                        // race where the second call wiped portals from the first.
                    }
                }
            }
            return true;
        }
        catch (error) {
            console.warn('[StreamingMessage] Rendermime error, falling back:', error);
            return false;
        }
    }, [isStreaming]);
    // Effect for rendering with Rendermime (throttle pattern during streaming)
    // Uses throttle instead of debounce: if tokens arrive faster than debounceMs,
    // debounce would keep resetting the timer and never render. Throttle ensures
    // rendering happens at most once per debounceMs window.
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!useNativeRenderer || !content) {
            // Clear pending render when not using native renderer or no content
            if (pendingRenderRef.current) {
                clearTimeout(pendingRenderRef.current);
                pendingRenderRef.current = null;
            }
            return;
        }
        if (!isStreaming) {
            // Not streaming: render immediately, clear any pending throttle
            if (pendingRenderRef.current) {
                clearTimeout(pendingRenderRef.current);
                pendingRenderRef.current = null;
            }
            void renderWithRendermime(content);
            return;
        }
        // Streaming: throttle — always track latest content, schedule only if none pending
        latestContentForRender.current = content;
        if (!pendingRenderRef.current) {
            pendingRenderRef.current = setTimeout(() => {
                pendingRenderRef.current = null;
                void renderWithRendermime(latestContentForRender.current);
            }, debounceMs);
        }
        // No cleanup that clears the timeout — throttle pattern intentionally
        // lets the scheduled render fire even when content updates again
    }, [content, isStreaming, useNativeRenderer, debounceMs, renderWithRendermime]);
    // Attach toolbars when streaming stops (only for native renderer)
    // Note: Fallback renderer has its own code-block-header with buttons
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (useNativeRenderer && !isStreaming && content && containerRef.current) {
            const contentDiv = containerRef.current.querySelector('.jp-streaming-content');
            if (contentDiv) {
                // Small delay to ensure DOM is updated
                setTimeout(() => {
                    attachCodeToolbars(contentDiv);
                    highlightRendermimeCodeBlocks(contentDiv);
                }, 100);
                // Second attempt for late-rendered content (e.g., last review section)
                setTimeout(() => {
                    const hasToolbar = contentDiv.querySelector('.jp-hdsp-code-toolbar-container');
                    const hasPreBlocks = contentDiv.querySelector('pre');
                    if (hasPreBlocks && !hasToolbar) {
                        attachCodeToolbars(contentDiv);
                    }
                }, 500);
            }
        }
    }, [isStreaming, content, attachCodeToolbars, useNativeRenderer]);
    // Attach toolbars for fallback renderer when content changes
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!useNativeRenderer && renderedHtml && !isStreaming && containerRef.current) {
            const contentDiv = containerRef.current.querySelector('.jp-streaming-content');
            if (contentDiv) {
                setTimeout(() => {
                    attachCodeToolbars(contentDiv);
                }, 100);
                // Second attempt for late-rendered content (e.g., last review section)
                setTimeout(() => {
                    const hasToolbar = contentDiv.querySelector('.jp-hdsp-code-toolbar-container');
                    const hasPreBlocks = contentDiv.querySelector('pre');
                    if (hasPreBlocks && !hasToolbar) {
                        attachCodeToolbars(contentDiv);
                    }
                }, 500);
            }
        }
    }, [useNativeRenderer, renderedHtml, isStreaming, attachCodeToolbars]);
    // Cleanup renderer, throttle timer, and toolbar roots on unmount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        return () => {
            if (rendererRef.current && rendererRef.current.dispose) {
                rendererRef.current.dispose();
                rendererRef.current = null;
            }
            rendererMountedRef.current = false;
            if (pendingRenderRef.current) {
                clearTimeout(pendingRenderRef.current);
                pendingRenderRef.current = null;
            }
            // Clean up toolbar roots via ref (avoids stale closure)
            toolbarRootsRef.current.forEach(root => {
                if (root.parentNode) {
                    root.parentNode.removeChild(root);
                }
            });
            toolbarRootsRef.current = [];
        };
    }, []);
    // Determine what to show
    const showIndicator = isStreaming && !content;
    const showContent = content && (useNativeRenderer || renderedHtml);
    const isRendering = isFallbackRendering;
    // Debug: Log render state for summary JSON
    const hasSummaryJsonContent = content && content.includes('"summary"') && content.includes('"next_items"');
    if (hasSummaryJsonContent) {
        console.log('[StreamingMessage] Render state for summary JSON:', {
            useNativeRenderer,
            hasRenderedHtml: !!renderedHtml,
            renderedHtmlPreview: renderedHtml?.slice(0, 100),
            showContent,
            contentLength: content?.length,
        });
    }
    // Combine class names
    const containerClassName = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => {
        const classes = ['jp-RenderedHTMLCommon', 'jp-RenderedMarkdown', 'jp-streaming-message'];
        if (className)
            classes.push(className);
        if (isStreaming)
            classes.push('streaming');
        if (hasIncompleteBlocks)
            classes.push('incomplete');
        if (useNativeRenderer)
            classes.push('jp-rendermime-native');
        return classes.join(' ');
    }, [className, isStreaming, hasIncompleteBlocks, useNativeRenderer]);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { ref: containerRef, className: containerClassName, style: { padding: '0 5px' } },
        statusText && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(StatusHistory, { statusText: statusText }),
        showIndicator && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(WritingIndicator, { hasContent: !!content, toolProcessing: toolProcessing }),
        showContent && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-streaming-content", ...(!useNativeRenderer && renderedHtml ? {
                dangerouslySetInnerHTML: { __html: renderedHtml }
            } : {}), onClick: onClick })),
        isStreaming && content && !isRendering && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-streaming-cursor" })),
        !isStreaming && codeToolbarDefs.map((def, index) => ((0,react_dom__WEBPACK_IMPORTED_MODULE_1__.createPortal)(react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_code_blocks__WEBPACK_IMPORTED_MODULE_3__.CodeToolbar, { key: index, content: def.content, language: def.language, onInsertAbove: onInsertAbove, onInsertBelow: onInsertBelow, onInsertAsCell: onInsertAsCell, cellActionsEnabled: cellActionsEnabled }), def.root)))));
});
StreamingMessage.displayName = 'StreamingMessage';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StreamingMessage);


/***/ },

/***/ "./lib/components/TaskProgressWidget.js"
/*!**********************************************!*\
  !*** ./lib/components/TaskProgressWidget.js ***!
  \**********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TaskProgressWidget: () => (/* binding */ TaskProgressWidget)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @mui/icons-material/Close */ "./node_modules/@mui/icons-material/esm/Close.js");
/* harmony import */ var _mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @mui/icons-material/ExpandMore */ "./node_modules/@mui/icons-material/esm/ExpandMore.js");
/* harmony import */ var _mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @mui/icons-material/ExpandLess */ "./node_modules/@mui/icons-material/esm/ExpandLess.js");
/* harmony import */ var _mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @mui/icons-material/CheckCircle */ "./node_modules/@mui/icons-material/esm/CheckCircle.js");
/* harmony import */ var _mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/icons-material/Error */ "./node_modules/@mui/icons-material/esm/Error.js");
/* harmony import */ var _mui_icons_material_Cancel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @mui/icons-material/Cancel */ "./node_modules/@mui/icons-material/esm/Cancel.js");
/**
 * Task Progress Widget - 작업 진행 상태 위젯 컴포넌트
 * 노트북 생성 진행 상태를 표시하는 플로팅 위젯
 */








const TaskProgressWidget = ({ taskStatus, onClose, onCancel, onOpenNotebook }) => {
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [showDetails, setShowDetails] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { status, progress, message, prompt, error, notebookPath } = taskStatus;
    const isComplete = status === 'completed';
    const isFailed = status === 'failed';
    const isCancelled = status === 'cancelled';
    const isRunning = status === 'running';
    const isDone = isComplete || isFailed || isCancelled;
    // Helper: Map status to color
    const getStatusColor = (currentStatus) => {
        switch (currentStatus) {
            case 'completed': return 'success';
            case 'failed': return 'error';
            case 'cancelled': return 'default';
            default: return 'primary';
        }
    };
    // Helper: Map status to icon
    const getStatusIcon = (currentStatus) => {
        switch (currentStatus) {
            case 'completed': return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_5__["default"], { fontSize: "small" });
            case 'failed': return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_6__["default"], { fontSize: "small" });
            case 'cancelled': return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Cancel__WEBPACK_IMPORTED_MODULE_7__["default"], { fontSize: "small" });
            default: return null;
        }
    };
    // Helper: Map status to Korean text
    const getStatusText = (currentStatus) => {
        const statusTextMap = {
            'pending': '대기 중',
            'running': '생성 중',
            'completed': '완료',
            'failed': '실패',
            'cancelled': '취소됨'
        };
        return statusTextMap[currentStatus] || currentStatus;
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Card, { sx: {
            position: 'fixed',
            bottom: 20,
            right: 20,
            width: expanded ? 380 : 320,
            maxWidth: '90vw',
            boxShadow: 3,
            zIndex: 1300,
            transition: 'all 0.3s ease'
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.CardContent, { sx: { padding: 2, '&:last-child': { paddingBottom: 2 } } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", justifyContent: "space-between", alignItems: "center", mb: 1 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", alignItems: "center", gap: 1 },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "subtitle2", fontWeight: "bold" }, "\uB178\uD2B8\uBD81 \uC0DD\uC131"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Chip, { label: getStatusText(status), size: "small", color: getStatusColor(status), icon: getStatusIcon(status) || undefined })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { size: "small", onClick: () => setShowDetails(!showDetails) }, showDetails ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandLess__WEBPACK_IMPORTED_MODULE_4__["default"], { fontSize: "small" })) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_ExpandMore__WEBPACK_IMPORTED_MODULE_3__["default"], { fontSize: "small" }))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.IconButton, { size: "small", onClick: onClose },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_2__["default"], { fontSize: "small" })))),
            !isDone && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mb: 2 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.LinearProgress, { variant: "determinate", value: progress, sx: {
                        height: 6,
                        borderRadius: 1,
                        '& .MuiLinearProgress-bar': {
                            transition: 'transform 0.8s ease-in-out',
                        },
                    } }),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", justifyContent: "space-between", mt: 0.5 },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary" }, message),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary" },
                        progress,
                        "%")))),
            isComplete && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mb: 2 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "body2", color: "success.main", sx: { display: 'flex', alignItems: 'center', gap: 0.5 } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_CheckCircle__WEBPACK_IMPORTED_MODULE_5__["default"], { fontSize: "small" }),
                    " ",
                    message))),
            isFailed && error && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { mb: 2 },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "body2", color: "error.main", sx: { display: 'flex', alignItems: 'center', gap: 0.5 } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_Error__WEBPACK_IMPORTED_MODULE_6__["default"], { fontSize: "small" }),
                    " ",
                    error))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Collapse, { in: showDetails },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { sx: {
                        backgroundColor: 'action.hover',
                        borderRadius: 1,
                        padding: 1.5,
                        mb: 2
                    } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary", display: "block", mb: 0.5 }, "\uD504\uB86C\uD504\uD2B8:"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "body2", sx: { wordBreak: 'break-word' } }, prompt),
                    notebookPath && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", color: "text.secondary", display: "block", mt: 1, mb: 0.5 }, "\uC800\uC7A5 \uC704\uCE58:"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, { variant: "caption", sx: { wordBreak: 'break-all', fontFamily: 'monospace' } }, notebookPath))))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, { display: "flex", gap: 1, justifyContent: "flex-end" },
                isRunning && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { size: "small", variant: "outlined", onClick: onCancel }, "\uCDE8\uC18C")),
                isComplete && notebookPath && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { size: "small", variant: "contained", onClick: onOpenNotebook }, "\uB178\uD2B8\uBD81 \uC5F4\uAE30")),
                isDone && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, { size: "small", variant: "text", onClick: onClose }, "\uB2EB\uAE30"))))));
};


/***/ },

/***/ "./lib/components/UserSettingsPanel.js"
/*!*********************************************!*\
  !*** ./lib/components/UserSettingsPanel.js ***!
  \*********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   UserSettingsPanel: () => (/* binding */ UserSettingsPanel)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_HourglassEmpty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @mui/icons-material/HourglassEmpty */ "./node_modules/@mui/icons-material/esm/HourglassEmpty.js");
/**
 * User Settings Panel Component
 *
 * User preferences configuration:
 * - Workspace root path
 * - Temperature setting
 * - Auto-approve toggle
 */


const UserSettingsPanel = ({ onClose, onSave, apiService, inputMode }) => {
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isSaving, setIsSaving] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    // User settings
    const [workspaceRoot, setWorkspaceRoot] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [temperature, setTemperature] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0.0);
    const [autoApprove, setAutoApprove] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [codebuffExists, setCodebuffExists] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [codebuffPath, setCodebuffPath] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [codebuffSize, setCodebuffSize] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const [codebuffTruncated, setCodebuffTruncated] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    // Load config on mount
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        loadConfig();
    }, []);
    const loadConfig = async () => {
        try {
            setIsLoading(true);
            const config = await apiService.getUserConfig();
            setWorkspaceRoot(config.workspaceRoot || '');
            setTemperature(config.temperature ?? 0.0);
            setAutoApprove(Boolean(config.autoApprove));
            // Load codebuff.md status
            try {
                const codebuffStatus = await apiService.getCodebuffStatus();
                setCodebuffExists(codebuffStatus.exists);
                setCodebuffPath(codebuffStatus.path);
                setCodebuffSize(codebuffStatus.size ?? 0);
                setCodebuffTruncated(codebuffStatus.truncated ?? false);
            }
            catch {
                // Non-critical, ignore
            }
            setError(null);
        }
        catch (err) {
            setError(`설정을 불러오는데 실패했습니다: ${err}`);
        }
        finally {
            setIsLoading(false);
        }
    };
    const handleSave = async () => {
        try {
            setIsSaving(true);
            const config = {
                workspaceRoot: workspaceRoot.trim() || '',
                temperature,
                autoApprove
            };
            await apiService.updateUserConfig(config);
            onSave(config);
            onClose();
        }
        catch (err) {
            setError(`설정 저장에 실패했습니다: ${err}`);
        }
        finally {
            setIsSaving(false);
        }
    };
    if (isLoading) {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-overlay" },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-dialog", style: { maxWidth: '400px' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-content", style: { textAlign: 'center', padding: '40px' } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_mui_icons_material_HourglassEmpty__WEBPACK_IMPORTED_MODULE_1__["default"], { sx: { fontSize: 48, color: 'info.main' } }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("p", null, "\uC124\uC815\uC744 \uBD88\uB7EC\uC624\uB294 \uC911...")))));
    }
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-overlay" },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-dialog", style: { maxWidth: '400px' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-header" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", null, "\uC0AC\uC6A9\uC790 \uC124\uC815"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-close", onClick: onClose, title: "\uB2EB\uAE30" }, "\u00D7")),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-content" },
                error && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-error", style: { color: 'red', marginBottom: '12px' } }, error)),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-notice" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "\uAC1C\uC778 \uD658\uACBD\uC124\uC815\uC744 \uAD00\uB9AC\uD569\uB2C8\uB2E4.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label", htmlFor: "jp-user-workspace-root" },
                        "\uC6CC\uD06C\uC2A4\uD398\uC774\uC2A4 \uB8E8\uD2B8",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { fontWeight: 'normal', marginLeft: '8px', color: '#666' } }, "\uBE44\uC6B0\uBA74 \uD604\uC7AC \uB178\uD2B8\uBD81 \uD3F4\uB354 \uAE30\uC900")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { id: "jp-user-workspace-root", type: "text", className: "jp-agent-settings-input", value: workspaceRoot, onChange: (e) => setWorkspaceRoot(e.target.value), placeholder: "\uC608: /Users/you/project \uB610\uB294 ./my-project" }),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginTop: '4px' } }, "\uC808\uB300 \uACBD\uB85C \uB610\uB294 \uC0C1\uB300 \uACBD\uB85C \uBAA8\uB450 \uC0AC\uC6A9 \uAC00\uB2A5\uD569\uB2C8\uB2E4.")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label", htmlFor: "jp-user-temperature" },
                        "Temperature",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { fontWeight: 'normal', marginLeft: '8px', color: '#666' } }, "LLM \uC751\uB2F5\uC758 \uCC3D\uC758\uC131 \uC870\uC808")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', alignItems: 'center', gap: '12px' } },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { id: "jp-user-temperature", type: "range", min: 0, max: 2, step: 0.1, value: temperature, onChange: (e) => setTemperature(parseFloat(e.target.value)), style: { flex: 1 } }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "number", className: "jp-agent-settings-input", value: temperature, onChange: (e) => setTemperature(Math.max(0, Math.min(2, parseFloat(e.target.value) || 0))), min: 0, max: 2, step: 0.1, style: { width: '70px' } })),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginTop: '4px' } }, "0.0 = \uACB0\uC815\uC801 (\uC77C\uAD00\uB41C \uC751\uB2F5), 1.0+ = \uCC3D\uC758\uC801 (\uB2E4\uC591\uD55C \uC751\uB2F5)")),
                inputMode === 'agent' && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uC790\uB3D9 \uC2E4\uD589 \uC2B9\uC778"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-checkbox" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: autoApprove, onChange: (e) => setAutoApprove(e.target.checked) }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", null, "\uC2B9\uC778 \uC5C6\uC774 \uBC14\uB85C \uC2E4\uD589 (\uCF54\uB4DC/\uD30C\uC77C/\uC178 \uD3EC\uD568)")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginTop: '4px' } }, autoApprove
                        ? '주의: 에이전트가 생성한 코드가 자동으로 실행됩니다.'
                        : '에이전트가 코드 실행, 파일 수정, 셸 명령 실행 전 승인을 요청합니다.'))),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-group" },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { className: "jp-agent-settings-label" }, "\uD504\uB85C\uC81D\uD2B8 \uC9C0\uC2DC\uC0AC\uD56D (codebuff.md)"),
                    codebuffExists === true ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', alignItems: 'center', gap: '6px' } },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: codebuffTruncated ? '#ff9800' : '#4caf50', fontSize: '16px' } }, "\u25CF"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: codebuffTruncated ? '#ff9800' : '#4caf50' } },
                                "codebuff.md \uAC10\uC9C0\uB428 (",
                                codebuffTruncated
                                    ? `${codebuffSize.toLocaleString()}자 → 10,000자로 잘림`
                                    : `${codebuffSize.toLocaleString()}자`,
                                ")")),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: codebuffTruncated ? '#ff9800' : '#666', display: 'block', marginTop: '4px' } }, codebuffTruncated
                            ? '최대 10,000자 제한을 초과하여 잘렸습니다. 파일을 줄여주세요.'
                            : '최대 10,000자까지 지원됩니다.'))) : (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#999' } }, "codebuff.md \uC5C6\uC74C \u2014 \uC6CC\uD06C\uC2A4\uD398\uC774\uC2A4 \uB8E8\uD2B8\uC5D0 \uC0DD\uC131\uD558\uBA74 AI \uC9C0\uC2DC\uC0AC\uD56D\uC73C\uB85C \uC0AC\uC6A9\uB429\uB2C8\uB2E4 (\uCD5C\uB300 10,000\uC790)")),
                    codebuffPath && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("small", { style: { color: '#666', display: 'block', marginTop: '4px' } }, codebuffPath)))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: "jp-agent-settings-footer" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-secondary", onClick: onClose }, "\uCDE8\uC18C"),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-agent-settings-button jp-agent-settings-button-primary", onClick: handleSave, disabled: isSaving }, isSaving ? '저장 중...' : '저장')))));
};


/***/ },

/***/ "./lib/components/code-blocks/CodeToolbar.js"
/*!***************************************************!*\
  !*** ./lib/components/code-blocks/CodeToolbar.js ***!
  \***************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeToolbar: () => (/* binding */ CodeToolbar),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _CopyButton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CopyButton */ "./lib/components/code-blocks/CopyButton.js");
/* harmony import */ var _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/AnalyticsService */ "./lib/services/AnalyticsService.js");
/**
 * CodeToolbar - Toolbar for code blocks with copy/insert functionality
 * Uses inline SVG icons (no MUI dependency for cross-environment compatibility)
 */



const CODE_TOOLBAR_CLASS = 'jp-hdsp-code-toolbar';
/* ── Inline SVG Icons (Material Design, 16x16) ── */
const InsertAboveIcon = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "currentColor" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M8 11h3v10h2V11h3l-4-4-4 4zM4 3v2h16V3H4z" })));
const InsertBelowIcon = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "currentColor" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M16 13h-3V3h-2v10H8l4 4 4-4zM4 19v2h16v-2H4z" })));
const NewCellIcon = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "currentColor" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M14 10H2v2h12v-2zm0-4H2v2h12V6zm4 8v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zM2 16h8v-2H2v2z" })));
function CodeToolbar({ content, language, onInsertAbove, onInsertBelow, onInsertAsCell, cellActionsEnabled = true }) {
    const impressionFiredRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!impressionFiredRef.current) {
            impressionFiredRef.current = true;
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackImpression('code_block_shown', {
                code_length: content.length,
                code_lines: content.split('\n').length,
                language: language || 'unknown',
            });
        }
    }, []);
    const handleInsertAbove = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        onInsertAbove?.(content);
    }, [content, onInsertAbove]);
    const handleInsertBelow = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        onInsertBelow?.(content);
    }, [content, onInsertBelow]);
    const handleInsertAsCell = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(() => {
        onInsertAsCell?.(content);
    }, [content, onInsertAsCell]);
    const canInsert = cellActionsEnabled && (onInsertAbove || onInsertBelow || onInsertAsCell);
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: CODE_TOOLBAR_CLASS },
        language && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-code-language-badge" }, language)),
        canInsert && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            onInsertAbove && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-hdsp-toolbar-btn", onClick: handleInsertAbove, disabled: !cellActionsEnabled, title: "\uD65C\uC131 \uC140 \uC704\uC5D0 \uC0BD\uC785", "aria-label": "Insert above active cell" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(InsertAboveIcon, null))),
            onInsertBelow && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-hdsp-toolbar-btn", onClick: handleInsertBelow, disabled: !cellActionsEnabled, title: "\uD65C\uC131 \uC140 \uC544\uB798\uC5D0 \uC0BD\uC785", "aria-label": "Insert below active cell" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(InsertBelowIcon, null))),
            onInsertAsCell && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: "jp-hdsp-toolbar-btn", onClick: handleInsertAsCell, disabled: !cellActionsEnabled, title: "\uC0C8 \uC140\uB85C \uCD94\uAC00", "aria-label": "Insert as new cell" },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(NewCellIcon, null))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { className: "jp-hdsp-toolbar-divider" }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_CopyButton__WEBPACK_IMPORTED_MODULE_1__.CopyButton, { value: content })));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CodeToolbar);


/***/ },

/***/ "./lib/components/code-blocks/CopyButton.js"
/*!**************************************************!*\
  !*** ./lib/components/code-blocks/CopyButton.js ***!
  \**************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CopyButton: () => (/* binding */ CopyButton),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/AnalyticsService */ "./lib/services/AnalyticsService.js");
/**
 * CopyButton - Copy to clipboard button with status feedback
 * Uses inline SVG icons (no MUI dependency for cross-environment compatibility)
 */


var CopyStatus;
(function (CopyStatus) {
    CopyStatus[CopyStatus["None"] = 0] = "None";
    CopyStatus[CopyStatus["Copying"] = 1] = "Copying";
    CopyStatus[CopyStatus["Copied"] = 2] = "Copied";
    CopyStatus[CopyStatus["Disabled"] = 3] = "Disabled";
})(CopyStatus || (CopyStatus = {}));
const CopyIcon = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "currentColor" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z" })));
const CheckIcon = () => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "currentColor" },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("path", { d: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" })));
function CopyButton({ value, className }) {
    const isCopyDisabled = typeof navigator === 'undefined' || navigator.clipboard === undefined;
    const [copyStatus, setCopyStatus] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(isCopyDisabled ? CopyStatus.Disabled : CopyStatus.None);
    const timeoutId = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const copy = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        if (copyStatus === CopyStatus.Copying) {
            return;
        }
        try {
            await navigator.clipboard.writeText(value);
            // Store copied agent code for paste detection
            const store = window._hdspAgentCopiedCodes ??
                (window._hdspAgentCopiedCodes = new Set());
            store.add(value.trim());
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_1__.AnalyticsService.getInstance().trackClick('code_copy_from_agent', {
                code_length: value.length,
                code_lines: value.split('\n').length,
            });
        }
        catch (err) {
            console.error('Failed to copy text:', err);
            setCopyStatus(CopyStatus.None);
            return;
        }
        setCopyStatus(CopyStatus.Copied);
        if (timeoutId.current) {
            clearTimeout(timeoutId.current);
        }
        timeoutId.current = window.setTimeout(() => setCopyStatus(CopyStatus.None), 1500);
    }, [copyStatus, value]);
    const isCopied = copyStatus === CopyStatus.Copied;
    const tooltip = isCopied ? '복사됨!' : '클립보드에 복사';
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { className: `jp-hdsp-toolbar-btn ${className || ''} ${isCopied ? 'jp-hdsp-toolbar-btn-copied' : ''}`, onClick: copy, disabled: isCopyDisabled, title: tooltip, "aria-label": "Copy to clipboard" }, isCopied ? react__WEBPACK_IMPORTED_MODULE_0___default().createElement(CheckIcon, null) : react__WEBPACK_IMPORTED_MODULE_0___default().createElement(CopyIcon, null)));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CopyButton);


/***/ },

/***/ "./lib/components/code-blocks/index.js"
/*!*********************************************!*\
  !*** ./lib/components/code-blocks/index.js ***!
  \*********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeToolbar: () => (/* reexport safe */ _CodeToolbar__WEBPACK_IMPORTED_MODULE_1__.CodeToolbar),
/* harmony export */   CopyButton: () => (/* reexport safe */ _CopyButton__WEBPACK_IMPORTED_MODULE_0__.CopyButton)
/* harmony export */ });
/* harmony import */ var _CopyButton__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CopyButton */ "./lib/components/code-blocks/CopyButton.js");
/* harmony import */ var _CodeToolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CodeToolbar */ "./lib/components/code-blocks/CodeToolbar.js");
/**
 * Code blocks components
 */




/***/ },

/***/ "./lib/components/rag-shared.js"
/*!**************************************!*\
  !*** ./lib/components/rag-shared.js ***!
  \**************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Btn: () => (/* binding */ Btn),
/* harmony export */   Card: () => (/* binding */ Card),
/* harmony export */   GuidePipelineCard: () => (/* binding */ GuidePipelineCard),
/* harmony export */   InputField: () => (/* binding */ InputField),
/* harmony export */   MappingEditor: () => (/* binding */ MappingEditor),
/* harmony export */   PanelContainer: () => (/* binding */ PanelContainer),
/* harmony export */   PanelHeader: () => (/* binding */ PanelHeader),
/* harmony export */   ProgressBar: () => (/* binding */ ProgressBar),
/* harmony export */   Toast: () => (/* binding */ Toast),
/* harmony export */   apiCall: () => (/* binding */ apiCall),
/* harmony export */   colors: () => (/* binding */ colors)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__);
/**
 * RAG Admin Shared — 3개 RAG 패널에서 공유하는 타입, API, UI 컴포넌트.
 */


// ============ API Helper ============
function getBaseUrl() {
    const serverRoot = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.PageConfig.getBaseUrl();
    return _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.join(serverRoot, 'hdsp-agent');
}
function getCsrfToken() {
    const value = `; ${document.cookie}`;
    const parts = value.split('; _xsrf=');
    if (parts.length === 2)
        return parts.pop()?.split(';').shift() || '';
    return '';
}
async function apiCall(path, method = 'GET', body) {
    const url = `${getBaseUrl()}/${path}`;
    const headers = {
        'Content-Type': 'application/json',
        'X-XSRFToken': getCsrfToken()
    };
    const opts = { method, headers };
    if (body)
        opts.body = JSON.stringify(body);
    const resp = await fetch(url, opts);
    return resp.json();
}
// ============ Design Tokens ============
const colors = {
    primary: '#2563eb',
    primaryLight: '#dbeafe',
    primaryDark: '#1d4ed8',
    danger: '#dc2626',
    dangerLight: '#fef2f2',
    success: '#16a34a',
    successLight: '#f0fdf4',
    gray50: '#f9fafb',
    gray100: '#f3f4f6',
    gray200: '#e5e7eb',
    gray300: '#d1d5db',
    gray400: '#9ca3af',
    gray500: '#6b7280',
    gray600: '#4b5563',
    gray700: '#374151',
    gray800: '#1f2937',
    white: '#ffffff',
    bg: '#f8fafc',
};
// ============ Shared UI Components ============
const PanelContainer = ({ children }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
        height: '100%',
        overflow: 'auto',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        fontSize: 13,
        background: colors.bg,
        color: colors.gray800,
    } }, children));
const PanelHeader = ({ title, subtitle, actions }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
        padding: '20px 24px 16px',
        background: `linear-gradient(135deg, ${colors.primary} 0%, ${colors.primaryDark} 100%)`,
        color: colors.white,
    } },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("h2", { style: { margin: 0, fontSize: 18, fontWeight: 600, letterSpacing: '-0.01em' } }, title),
            subtitle && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: 12, opacity: 0.85, marginTop: 4 } }, subtitle))),
        actions)));
const Toast = ({ message }) => {
    if (!message)
        return null;
    const isError = message.includes('실패');
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
            position: 'fixed',
            top: 8,
            left: '50%',
            transform: 'translateX(-50%)',
            zIndex: 9999,
            padding: '10px 20px',
            background: isError ? colors.dangerLight : colors.successLight,
            color: isError ? colors.danger : colors.success,
            borderRadius: 8,
            fontSize: 12,
            fontWeight: 500,
            border: `1px solid ${isError ? '#fecaca' : '#bbf7d0'}`,
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            maxWidth: 400,
        } },
        isError ? '✕ ' : '✓ ',
        message));
};
const Card = ({ title, badge, expanded, onToggle, children, icon }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
        margin: '12px 20px',
        background: colors.white,
        borderRadius: 10,
        border: `1px solid ${colors.gray200}`,
        overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
    } },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { onClick: onToggle, style: {
            display: 'flex',
            alignItems: 'center',
            cursor: 'pointer',
            padding: '12px 16px',
            background: expanded ? colors.gray50 : colors.white,
            borderBottom: expanded ? `1px solid ${colors.gray200}` : 'none',
            userSelect: 'none',
            transition: 'background 0.15s',
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontSize: 10, color: colors.gray400, marginRight: 10, transition: 'transform 0.2s', transform: expanded ? 'rotate(90deg)' : 'none' } }, "\u25B6"),
        icon && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { marginRight: 8, fontSize: 16 } }, icon),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontWeight: 600, fontSize: 13, color: colors.gray700, flex: 1 } }, title),
        badge && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: {
                fontSize: 11,
                background: colors.primaryLight,
                color: colors.primary,
                padding: '2px 8px',
                borderRadius: 10,
                fontWeight: 600,
            } }, badge))),
    expanded && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { padding: '16px' } }, children)));
const InputField = ({ label, value, onChange, type = 'text', placeholder, disabled }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginBottom: 10, display: 'flex', alignItems: 'center', gap: 10 } },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { style: { minWidth: 120, fontSize: 12, fontWeight: 500, color: colors.gray600 } }, label),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: type, value: value, onChange: e => onChange(e.target.value), placeholder: placeholder, disabled: disabled, style: {
            flex: 1,
            padding: '7px 10px',
            border: `1px solid ${colors.gray300}`,
            borderRadius: 6,
            fontSize: 13,
            outline: 'none',
            background: disabled ? colors.gray100 : colors.white,
            transition: 'border-color 0.15s',
        } })));
const Btn = ({ label, onClick, disabled, variant = 'ghost', size = 'md' }) => {
    const styles = {
        primary: {
            background: disabled ? colors.gray300 : colors.primary,
            color: colors.white,
            border: 'none',
        },
        danger: {
            background: 'transparent',
            color: disabled ? colors.gray400 : colors.danger,
            border: `1px solid ${disabled ? colors.gray300 : '#fca5a5'}`,
        },
        ghost: {
            background: 'transparent',
            color: disabled ? colors.gray400 : colors.gray600,
            border: `1px solid ${colors.gray300}`,
        },
    };
    const pad = size === 'sm' ? '5px 10px' : '7px 14px';
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("button", { onClick: onClick, disabled: disabled, style: {
            padding: pad,
            borderRadius: 6,
            cursor: disabled ? 'not-allowed' : 'pointer',
            fontSize: size === 'sm' ? 11 : 12,
            fontWeight: 500,
            marginRight: 6,
            transition: 'all 0.15s',
            ...styles[variant],
        } }, label));
};
const ProgressBar = ({ progress }) => {
    if (!progress || progress.status !== 'running')
        return null;
    const pct = progress.summary_total
        ? Math.round(((progress.summary_done || 0) / progress.summary_total) * 100)
        : 0;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
            marginTop: 14,
            padding: '12px 14px',
            background: colors.primaryLight,
            borderRadius: 8,
            border: `1px solid #bfdbfe`,
        } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: 12, fontWeight: 500, color: colors.gray700, marginBottom: 6 } },
            "[",
            progress.processed_files || 0,
            "/",
            progress.total_files || '?',
            "] ",
            progress.current_file || '...'),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                width: '100%',
                height: 6,
                background: '#bfdbfe',
                borderRadius: 3,
                overflow: 'hidden',
            } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
                    width: `${pct}%`,
                    height: '100%',
                    background: colors.primary,
                    borderRadius: 3,
                    transition: 'width 0.5s ease',
                } })),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', justifyContent: 'space-between', marginTop: 4 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontSize: 11, color: colors.gray500 } },
                "LLM \uC694\uC57D: ",
                progress.summary_done || 0,
                "/",
                progress.summary_total || '?'),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontSize: 11, color: colors.gray500 } },
                "\uC784\uBCA0\uB529 ",
                progress.total_chunks || 0,
                "\uAC1C \uC644\uB8CC"))));
};
const MappingEditor = ({ headers, mapping, onChange }) => {
    const update = (key, value) => {
        onChange({ ...mapping, [key]: value });
    };
    const toggleField = (listKey, field) => {
        const current = mapping[listKey] || [];
        const next = current.includes(field)
            ? current.filter((f) => f !== field)
            : [...current, field];
        update(listKey, next);
    };
    const labels = {
        groupBy: '그룹핑 키',
        embeddingFields: '임베딩 필드',
        tableFields: '테이블 필드',
        columnFields: '컬럼 필드',
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: {
            background: colors.gray50,
            padding: '12px 14px',
            borderRadius: 8,
            marginTop: 10,
            border: `1px solid ${colors.gray200}`,
        } }, ['groupBy', 'embeddingFields', 'tableFields', 'columnFields'].map(listKey => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: listKey, style: { marginBottom: 8 } },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { style: { fontWeight: 600, fontSize: 12, color: colors.gray600 } }, labels[listKey]),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 4 } }, headers.map(h => {
            const checked = (mapping[listKey] || []).includes(h);
            return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("label", { key: h, style: {
                    fontSize: 11,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 3,
                    padding: '2px 6px',
                    borderRadius: 4,
                    background: checked ? colors.primaryLight : colors.white,
                    border: `1px solid ${checked ? '#93c5fd' : colors.gray200}`,
                    cursor: 'pointer',
                    transition: 'all 0.1s',
                } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("input", { type: "checkbox", checked: checked, onChange: () => toggleField(listKey, h), style: { display: 'none' } }),
                checked && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: colors.primary, fontSize: 10 } }, "\u2713"),
                h));
        })))))));
};
// ============ Guide Pipeline 3-Step Card ============
const StepRow = ({ step, label, enabled, running, complete, progress, onRun }) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0', borderBottom: `1px solid ${colors.gray200}` } },
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontWeight: 600, fontSize: 13, minWidth: 28, color: colors.gray500 } },
        "#",
        step),
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { flex: 1, fontSize: 13 } }, label),
    running && progress ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontSize: 12, color: colors.gray500 } },
        "\u23F3 ",
        progress.current,
        "/",
        progress.total)) : complete ? (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { fontSize: 12, color: colors.success } },
        "\u2705 ",
        complete.success ?? complete.total_chunks ?? complete.upserted ?? '완료')) : null,
    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Btn, { label: running ? '실행 중...' : '▶ 실행', onClick: onRun, variant: "primary", disabled: !enabled || running })));
const GuidePipelineCard = ({ title, icon, collection, points, expanded, onToggle, loading, onDeleteCollection }) => {
    const [sourceDir, setSourceDir] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [stepStatus, setStepStatus] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
    const [runningStep, setRunningStep] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [progress, setProgress] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [errors, setErrors] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [pipelineInfo, setPipelineInfo] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const checkStatus = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async () => {
        if (!sourceDir)
            return;
        try {
            const res = await apiCall(`rag/admin/guide-pipeline/status?sourceDir=${encodeURIComponent(sourceDir)}`, 'GET');
            setPipelineInfo(res);
        }
        catch { /* ignore */ }
    }, [sourceDir]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => { if (sourceDir)
        checkStatus(); }, [sourceDir, checkStatus]);
    const runStep = async (step) => {
        setRunningStep(step);
        setProgress(null);
        setErrors([]);
        try {
            const baseUrl = (() => {
                const serverRoot = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.PageConfig.getBaseUrl();
                return _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_1__.URLExt.join(serverRoot, 'hdsp-agent');
            })();
            const headers = {
                'Content-Type': 'application/json',
                'X-XSRFToken': (() => {
                    const value = `; ${document.cookie}`;
                    const parts = value.split('; _xsrf=');
                    if (parts.length === 2)
                        return parts.pop()?.split(';').shift() || '';
                    return '';
                })(),
            };
            const response = await fetch(`${baseUrl}/rag/admin/guide-pipeline`, {
                method: 'POST',
                headers,
                body: JSON.stringify({ sourceDir, collection, step }),
            });
            const reader = response.body?.getReader();
            if (!reader)
                return;
            const decoder = new TextDecoder();
            let buffer = '';
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (!line.startsWith('data: '))
                        continue;
                    try {
                        const data = JSON.parse(line.slice(6));
                        if (data.status === 'running') {
                            setProgress({ current: data.current, total: data.total });
                        }
                        else if (data.status === 'error' && data.file) {
                            setErrors(prev => [...prev, `${data.file}: ${data.error}`]);
                        }
                        else if (data.status === 'complete') {
                            setStepStatus(prev => ({ ...prev, [step]: data }));
                        }
                    }
                    catch { /* ignore parse error */ }
                }
            }
        }
        catch (e) {
            setErrors(prev => [...prev, `Step ${step} 실패: ${e.message}`]);
        }
        finally {
            setRunningStep(null);
            checkStatus();
        }
    };
    const mdExists = pipelineInfo?.mdversion?.exists && pipelineInfo?.mdversion?.files > 0;
    const chunkedExists = pipelineInfo?.chunked?.exists && pipelineInfo?.chunked?.files > 0;
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Card, { title: title, icon: icon, badge: `${points}개`, expanded: expanded, onToggle: onToggle },
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(InputField, { label: "\uC6D0\uBCF8 \uB514\uB809\uD1A0\uB9AC", value: sourceDir, onChange: setSourceDir, placeholder: "/home/jovyan/guides/" }),
        pipelineInfo && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { fontSize: 11, color: colors.gray400, margin: '4px 0 8px' } },
            "mdversion: ",
            pipelineInfo.mdversion?.files || 0,
            "\uAC1C \uD30C\uC77C | chunked: ",
            pipelineInfo.chunked?.files || 0,
            "\uAC1C \uD30C\uC77C")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(StepRow, { step: 1, label: "MD \uC7AC\uAD6C\uC131", enabled: !!sourceDir && !loading, running: runningStep === 1, complete: stepStatus[1] || (mdExists && !stepStatus[1] ? { success: pipelineInfo.mdversion.files } : null), progress: runningStep === 1 ? progress : null, onRun: () => runStep(1) }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(StepRow, { step: 2, label: "\uCCAD\uD0B9 + \uC694\uC57D", enabled: !!mdExists && !loading, running: runningStep === 2, complete: stepStatus[2] || (chunkedExists && !stepStatus[2] ? { total_chunks: pipelineInfo.chunked.files } : null), progress: runningStep === 2 ? progress : null, onRun: () => runStep(2) }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(StepRow, { step: 3, label: "\uC784\uBCA0\uB529 \uC801\uC7AC", enabled: !!chunkedExists && !loading, running: runningStep === 3, complete: stepStatus[3], progress: runningStep === 3 ? progress : null, onRun: () => runStep(3) }),
        errors.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: 8, fontSize: 12, color: colors.danger, maxHeight: 100, overflow: 'auto' } }, errors.map((e, i) => react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { key: i },
            "\u26A0 ",
            e)))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: 12 } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Btn, { label: "\uD83D\uDDD1 \uCEEC\uB809\uC158 \uCD08\uAE30\uD654", onClick: onDeleteCollection, variant: "danger", disabled: loading }))));
};


/***/ },

/***/ "./lib/hooks/useStreamingMarkdown.js"
/*!*******************************************!*\
  !*** ./lib/hooks/useStreamingMarkdown.js ***!
  \*******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   useStreamingMarkdown: () => (/* binding */ useStreamingMarkdown)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils/markdownRenderer */ "./lib/utils/markdownRenderer.js");
/**
 * useStreamingMarkdown - Advanced streaming markdown rendering
 *
 * Phase 2 Implementation:
 * 1. Comprehensive incomplete markdown detection
 * 2. Smart block closing for safe rendering
 * 3. Stable content extraction for smoother updates
 * 4. Debounced rendering with intelligent batching
 */


/**
 * Comprehensive detection of incomplete markdown structures
 */
function analyzeIncompleteMarkdown(content) {
    const info = {
        hasUnclosedCodeBlock: false,
        hasUnclosedInlineCode: false,
        hasUnclosedBold: false,
        hasUnclosedItalic: false,
        hasUnclosedLink: false,
        hasUnclosedTable: false,
        lastStableIndex: content.length,
    };
    if (!content)
        return info;
    // 1. Check for unclosed fenced code blocks (```)
    const codeBlockMatches = content.match(/```/g);
    const codeBlockCount = codeBlockMatches ? codeBlockMatches.length : 0;
    info.hasUnclosedCodeBlock = codeBlockCount % 2 !== 0;
    // If we're inside a code block, find where it started
    if (info.hasUnclosedCodeBlock) {
        const lastCodeBlockStart = content.lastIndexOf('```');
        info.lastStableIndex = Math.min(info.lastStableIndex, lastCodeBlockStart);
    }
    // 2. Check for unclosed inline code in the last line (only matters outside code blocks)
    if (!info.hasUnclosedCodeBlock) {
        const lines = content.split('\n');
        const lastLine = lines[lines.length - 1];
        // Count backticks that aren't part of code blocks
        let inlineBackticks = 0;
        let i = 0;
        while (i < lastLine.length) {
            if (lastLine[i] === '`') {
                // Check if it's a triple backtick (code block start)
                if (lastLine.substring(i, i + 3) === '```') {
                    i += 3;
                    continue;
                }
                inlineBackticks++;
            }
            i++;
        }
        info.hasUnclosedInlineCode = inlineBackticks % 2 !== 0;
    }
    // 3. Check for unclosed bold (**) in last line
    if (!info.hasUnclosedCodeBlock) {
        const lastLine = content.split('\n').pop() || '';
        const boldMatches = lastLine.match(/\*\*/g);
        const boldCount = boldMatches ? boldMatches.length : 0;
        info.hasUnclosedBold = boldCount % 2 !== 0;
    }
    // 4. Check for unclosed italic (*) - more complex due to bold overlap
    if (!info.hasUnclosedCodeBlock && !info.hasUnclosedBold) {
        const lastLine = content.split('\n').pop() || '';
        // Remove bold markers first, then count single asterisks
        const withoutBold = lastLine.replace(/\*\*/g, '');
        const italicMatches = withoutBold.match(/\*/g);
        const italicCount = italicMatches ? italicMatches.length : 0;
        info.hasUnclosedItalic = italicCount % 2 !== 0;
    }
    // 5. Check for unclosed links [text](url) or [text][ref]
    const lastLine = content.split('\n').pop() || '';
    const openBracket = lastLine.lastIndexOf('[');
    const closeBracket = lastLine.lastIndexOf(']');
    const openParen = lastLine.lastIndexOf('(');
    const closeParen = lastLine.lastIndexOf(')');
    if (openBracket > closeBracket) {
        // We have an unclosed [
        info.hasUnclosedLink = true;
    }
    else if (closeBracket > -1 && openParen > closeBracket && openParen > closeParen) {
        // We have [...](  but no closing )
        info.hasUnclosedLink = true;
    }
    // 6. Check for incomplete tables (line starts with | but doesn't end with |)
    const lines = content.split('\n');
    const lastNonEmptyLine = lines.filter(l => l.trim()).pop() || '';
    if (lastNonEmptyLine.trim().startsWith('|') && !lastNonEmptyLine.trim().endsWith('|')) {
        info.hasUnclosedTable = true;
    }
    // Calculate last stable index based on all incomplete markers
    if (info.hasUnclosedInlineCode || info.hasUnclosedBold || info.hasUnclosedItalic || info.hasUnclosedLink) {
        // Find the start of the last line
        const lastNewline = content.lastIndexOf('\n');
        info.lastStableIndex = Math.min(info.lastStableIndex, lastNewline > 0 ? lastNewline : 0);
    }
    return info;
}
/**
 * Detect if content has any incomplete blocks
 */
function hasAnyIncompleteBlocks(info) {
    return (info.hasUnclosedCodeBlock ||
        info.hasUnclosedInlineCode ||
        info.hasUnclosedBold ||
        info.hasUnclosedItalic ||
        info.hasUnclosedLink ||
        info.hasUnclosedTable);
}
/**
 * Close incomplete markdown blocks for safer rendering during streaming
 */
function closeIncompleteBlocks(content, info) {
    let result = content;
    // Close unclosed code blocks first (highest priority)
    if (info.hasUnclosedCodeBlock) {
        // Find the language hint if any
        const lastCodeBlockStart = result.lastIndexOf('```');
        const afterBackticks = result.substring(lastCodeBlockStart + 3);
        const firstNewline = afterBackticks.indexOf('\n');
        // If there's content after the opening ```, add a closing
        if (firstNewline > -1 || afterBackticks.length > 0) {
            result += '\n```';
        }
        return result; // Return early - code block content shouldn't be further processed
    }
    // Close inline code
    if (info.hasUnclosedInlineCode) {
        result += '`';
    }
    // Close bold
    if (info.hasUnclosedBold) {
        result += '**';
    }
    // Close italic
    if (info.hasUnclosedItalic) {
        result += '*';
    }
    // Close unclosed links - just close the bracket
    if (info.hasUnclosedLink) {
        const lastLine = result.split('\n').pop() || '';
        const openBracket = lastLine.lastIndexOf('[');
        const closeBracket = lastLine.lastIndexOf(']');
        const openParen = lastLine.lastIndexOf('(');
        if (openBracket > closeBracket) {
            result += ']';
        }
        else if (openParen > closeBracket) {
            result += ')';
        }
    }
    // Close incomplete table row
    if (info.hasUnclosedTable) {
        result += ' |';
    }
    return result;
}
/**
 * Extract stable content that can be safely rendered
 * Returns content up to the last complete block/paragraph
 */
function extractStableContent(content, info) {
    if (!hasAnyIncompleteBlocks(info)) {
        return { stableContent: content, unstableContent: '' };
    }
    // For code blocks, render everything with closing
    if (info.hasUnclosedCodeBlock) {
        return {
            stableContent: closeIncompleteBlocks(content, info),
            unstableContent: '',
        };
    }
    // For other incomplete blocks, split at last newline
    const lastNewline = content.lastIndexOf('\n');
    if (lastNewline > 0) {
        const stable = content.substring(0, lastNewline);
        const unstable = content.substring(lastNewline + 1);
        // Check if stable part is actually stable
        const stableInfo = analyzeIncompleteMarkdown(stable);
        if (!hasAnyIncompleteBlocks(stableInfo)) {
            return { stableContent: stable, unstableContent: unstable };
        }
    }
    // Fallback: close blocks and render all
    return {
        stableContent: closeIncompleteBlocks(content, info),
        unstableContent: '',
    };
}
/**
 * Hook for debounced markdown rendering during streaming
 */
function useStreamingMarkdown(content, options = {}) {
    const { debounceMs = 50, isStreaming = false, forceImmediate = false, minContentLength = 10, } = options;
    const [renderedHtml, setRenderedHtml] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)('');
    const [isRendering, setIsRendering] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const timeoutRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const lastContentRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)('');
    const lastRenderedRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)('');
    const renderCountRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(0);
    // Ref to track latest streaming content for throttle pattern
    const latestStreamContentRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)('');
    // Analyze incomplete blocks
    const incompleteBlockInfo = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => analyzeIncompleteMarkdown(content), [content]);
    const hasIncompleteBlocks = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(() => hasAnyIncompleteBlocks(incompleteBlockInfo), [incompleteBlockInfo]);
    // Render function with smart content processing
    const renderContent = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((contentToRender, forceRender = false) => {
        // Skip if content hasn't changed significantly
        if (!forceRender && contentToRender === lastContentRef.current && lastRenderedRef.current) {
            setIsRendering(false);
            return;
        }
        // Skip very short content during streaming (wait for more)
        if (isStreaming && !forceRender && contentToRender.length < minContentLength) {
            setIsRendering(false);
            return;
        }
        lastContentRef.current = contentToRender;
        renderCountRef.current++;
        try {
            let processedContent;
            if (isStreaming && hasIncompleteBlocks) {
                // Use smart content extraction during streaming
                const { stableContent } = extractStableContent(contentToRender, incompleteBlockInfo);
                processedContent = stableContent;
            }
            else {
                processedContent = contentToRender;
            }
            const html = (0,_utils_markdownRenderer__WEBPACK_IMPORTED_MODULE_1__.formatMarkdownToHtml)(processedContent);
            lastRenderedRef.current = html;
            setRenderedHtml(html);
        }
        catch (error) {
            console.warn('[useStreamingMarkdown] Render error:', error);
            // Fallback to escaped content
            const escaped = contentToRender
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
            setRenderedHtml(`<pre style="white-space: pre-wrap;">${escaped}</pre>`);
        }
        setIsRendering(false);
    }, [isStreaming, hasIncompleteBlocks, incompleteBlockInfo, minContentLength]);
    // Effect for throttled rendering during streaming
    // Uses throttle instead of debounce: debounce resets the timer on every content
    // change, so if tokens arrive faster than debounceMs, rendering never fires.
    // Throttle schedules a render and lets it fire even when content updates again,
    // ensuring at least one render per debounceMs window.
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        // Empty content - clear immediately
        if (!content) {
            setRenderedHtml('');
            setIsRendering(false);
            lastContentRef.current = '';
            lastRenderedRef.current = '';
            latestStreamContentRef.current = '';
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
                timeoutRef.current = null;
            }
            return;
        }
        // Force immediate render (e.g., when streaming stops)
        if (forceImmediate || !isStreaming) {
            if (timeoutRef.current) {
                clearTimeout(timeoutRef.current);
                timeoutRef.current = null;
            }
            renderContent(content, true);
            return;
        }
        // Streaming: throttle pattern — always track latest content,
        // only schedule a new render if none is pending
        setIsRendering(true);
        latestStreamContentRef.current = content;
        if (!timeoutRef.current) {
            // Dynamic delay: shorter for longer content (user is waiting)
            const dynamicDelay = content.length > 500 ? debounceMs * 0.5 : debounceMs;
            timeoutRef.current = setTimeout(() => {
                timeoutRef.current = null;
                renderContent(latestStreamContentRef.current);
            }, dynamicDelay);
        }
        // No cleanup that clears the timeout — throttle pattern intentionally
        // lets the scheduled render fire even when content updates again
    }, [content, isStreaming, forceImmediate, debounceMs, renderContent]);
    // Final render when streaming stops
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        if (!isStreaming && content) {
            // Always do a final render when streaming stops to ensure complete content
            renderContent(content, true);
        }
    }, [isStreaming]); // Intentionally only depend on isStreaming
    return {
        renderedHtml,
        isRendering,
        hasIncompleteBlocks,
        incompleteBlockInfo,
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useStreamingMarkdown);


/***/ },

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _plugins_sidebar_plugin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./plugins/sidebar-plugin */ "./lib/plugins/sidebar-plugin.js");
/* harmony import */ var _plugins_cell_buttons_plugin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./plugins/cell-buttons-plugin */ "./lib/plugins/cell-buttons-plugin.js");
/* harmony import */ var _plugins_prompt_generation_plugin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./plugins/prompt-generation-plugin */ "./lib/plugins/prompt-generation-plugin.js");
/* harmony import */ var _plugins_save_interceptor_plugin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./plugins/save-interceptor-plugin */ "./lib/plugins/save-interceptor-plugin.js");
/* harmony import */ var _plugins_idle_monitor_plugin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./plugins/idle-monitor-plugin */ "./lib/plugins/idle-monitor-plugin.js");
/* harmony import */ var _plugins_lsp_bridge_plugin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./plugins/lsp-bridge-plugin */ "./lib/plugins/lsp-bridge-plugin.js");
/* harmony import */ var _plugins_notebook_toolbar_plugin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./plugins/notebook-toolbar-plugin */ "./lib/plugins/notebook-toolbar-plugin.js");
/* harmony import */ var _plugins_rag_admin_plugin__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./plugins/rag-admin-plugin */ "./lib/plugins/rag-admin-plugin.js");
/**
 * Jupyter Agent Extension Entry Point
 */
// Import plugins








/**
 * The main plugin export
 * Note: sidebarPlugin must load before cellButtonsPlugin
 * saveInterceptorPlugin loads last to intercept save operations
 */
const plugins = [
    _plugins_sidebar_plugin__WEBPACK_IMPORTED_MODULE_0__.sidebarPlugin,
    _plugins_cell_buttons_plugin__WEBPACK_IMPORTED_MODULE_1__.cellButtonsPlugin,
    _plugins_notebook_toolbar_plugin__WEBPACK_IMPORTED_MODULE_6__.notebookToolbarPlugin,
    _plugins_prompt_generation_plugin__WEBPACK_IMPORTED_MODULE_2__.promptGenerationPlugin,
    _plugins_save_interceptor_plugin__WEBPACK_IMPORTED_MODULE_3__.saveInterceptorPlugin,
    _plugins_idle_monitor_plugin__WEBPACK_IMPORTED_MODULE_4__.idleMonitorPlugin,
    _plugins_lsp_bridge_plugin__WEBPACK_IMPORTED_MODULE_5__.lspBridgePlugin,
    _plugins_rag_admin_plugin__WEBPACK_IMPORTED_MODULE_7__.ragAdminPlugin
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugins);


/***/ },

/***/ "./lib/logoSvg.js"
/*!************************!*\
  !*** ./lib/logoSvg.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   headerLogoSvg: () => (/* binding */ headerLogoSvg),
/* harmony export */   tabbarLogoSvg: () => (/* binding */ tabbarLogoSvg)
/* harmony export */ });
/**
 * Logo SVG strings for Codebuff Agent
 * These are inlined to avoid webpack module resolution issues with SVG imports
 */
// Header logo: "Codebuff" text with code bracket icon (icon scaled to match text height)
const headerLogoSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="240" viewBox="0 0 1080 240">
  <defs>
    <linearGradient id="hg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#6366f1"/>
      <stop offset="100%" style="stop-color:#8b5cf6"/>
    </linearGradient>
  </defs>
  <g transform="translate(10, 20) scale(0.7)">
    <rect width="280" height="280" rx="56" fill="url(#hg)"/>
    <path d="M 100 80 L 40 140 L 100 200" stroke="white" stroke-width="20" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
    <path d="M 180 80 L 240 140 L 180 200" stroke="white" stroke-width="20" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
    <line x1="155" y1="65" x2="125" y2="215" stroke="rgba(255,255,255,0.4)" stroke-width="10" stroke-linecap="round"/>
  </g>
  <text x="250" y="175" font-family="system-ui, -apple-system, 'Segoe UI', sans-serif" font-size="180" font-weight="700" fill="#1e1b4b" letter-spacing="-4">Codebuff</text>
</svg>`;
// Tabbar icon: flat color for LabIcon compatibility (no gradients/style attrs)
const tabbarLogoSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 280 280">
  <rect width="280" height="280" rx="56" fill="#6366f1"/>
  <path d="M 100 80 L 40 140 L 100 200" stroke="white" stroke-width="20" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  <path d="M 180 80 L 240 140 L 180 200" stroke="white" stroke-width="20" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  <line x1="155" y1="65" x2="125" y2="215" stroke="white" stroke-opacity="0.4" stroke-width="10" stroke-linecap="round"/>
</svg>`;


/***/ },

/***/ "./lib/plugins/cell-buttons-plugin.js"
/*!********************************************!*\
  !*** ./lib/plugins/cell-buttons-plugin.js ***!
  \********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cellButtonsPlugin: () => (/* binding */ cellButtonsPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../types */ "./lib/types/index.js");
/* harmony import */ var _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/AnalyticsService */ "./lib/services/AnalyticsService.js");
/**
 * Cell Buttons Plugin - 셀 버튼 플러그인
 * 노트북 셀에 E, F, ? 액션 버튼 삽입
 * Chrome 확장 대신 사이드바 패널과 통신
 */



/**
 * 셀 버튼 플러그인
 */
const cellButtonsPlugin = {
    id: '@hdsp-agent/cell-buttons',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, notebookTracker) => {
        console.log('[CellButtonsPlugin] Activated');
        // Store app reference globally for later use
        window.jupyterapp = app;
        // Handle new notebooks
        notebookTracker.widgetAdded.connect((sender, panel) => {
            console.log('[CellButtonsPlugin] Notebook widget added:', panel.id);
            // Wait for session to be ready
            panel.sessionContext.ready.then(() => {
                observeNotebook(panel);
            }).catch(err => {
                console.error('[CellButtonsPlugin] Error waiting for session:', err);
            });
        });
        // Handle current notebook if exists
        if (notebookTracker.currentWidget) {
            observeNotebook(notebookTracker.currentWidget);
        }
        // Handle notebook focus changes
        notebookTracker.currentChanged.connect((sender, panel) => {
            if (panel) {
                observeNotebook(panel);
            }
        });
    }
};
/**
 * Observe a notebook for cell changes and inject buttons
 */
function observeNotebook(panel) {
    const notebook = panel.content;
    // Initial injection with delay to ensure cells are rendered
    setTimeout(() => {
        injectButtonsIntoAllCells(notebook, panel);
        // Retry after longer delay for cells that weren't ready
        setTimeout(() => {
            injectButtonsIntoAllCells(notebook, panel);
        }, 500);
    }, 200);
    // Watch for cell changes (add/remove/reorder)
    const cellsChangedHandler = () => {
        setTimeout(() => {
            injectButtonsIntoAllCells(notebook, panel);
        }, 100);
    };
    // Remove any previous listeners to avoid duplicates
    try {
        notebook.model?.cells.changed.disconnect(cellsChangedHandler);
    }
    catch {
        // Ignore if not connected
    }
    // Connect new listener
    notebook.model?.cells.changed.connect(cellsChangedHandler);
    // --- Paste detection: tag cells pasted with agent code ---
    const pasteHandler = (e) => {
        const pastedText = e.clipboardData?.getData('text/plain')?.trim();
        if (!pastedText)
            return;
        const store = window._hdspAgentCopiedCodes;
        if (!store || !store.has(pastedText))
            return;
        // Tag the active cell with hdsp_agent_source metadata
        const activeCell = notebook.activeCell;
        if (!activeCell?.model)
            return;
        try {
            const meta = activeCell.model.metadata;
            if (typeof meta.set === 'function') {
                meta.set('hdsp_agent_source', 'pasted');
            }
            else {
                meta.hdsp_agent_source = 'pasted';
            }
        }
        catch { /* silent */ }
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackClick('code_paste_from_agent', {
            code_length: pastedText.length,
            code_lines: pastedText.split('\n').length,
        });
    };
    panel.node.addEventListener('paste', pasteHandler, true);
}
/**
 * Inject buttons into all cells in a notebook
 */
function injectButtonsIntoAllCells(notebook, panel) {
    for (let i = 0; i < notebook.widgets.length; i++) {
        const cell = notebook.widgets[i];
        injectButtonsIntoCell(cell, panel);
    }
}
/**
 * SVG Icons for cell action buttons
 */
const ICONS = {
    // Lightbulb icon for Explain
    explain: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M9 18h6"/>
    <path d="M10 22h4"/>
    <path d="M15.09 14c.18-.98.65-1.74 1.41-2.5A4.65 4.65 0 0 0 18 8 6 6 0 0 0 6 8c0 1 .23 2.23 1.5 3.5A4.61 4.61 0 0 1 8.91 14"/>
  </svg>`,
    // Wrench icon for Fix
    fix: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
  </svg>`,
    // Question mark icon for Custom Prompt
    question: `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
    <path d="M12 17h.01"/>
  </svg>`
};
/**
 * Inject buttons into a single cell's toolbar
 * Buttons are placed in the jp-cell-toolbar when it exists
 */
function injectButtonsIntoCell(cell, panel) {
    // Safety checks
    if (!cell || !cell.model) {
        return;
    }
    // Only inject buttons into code cells (not markdown, raw, etc.)
    if (cell.model.type !== 'code') {
        return;
    }
    const cellNode = cell.node;
    if (!cellNode || !cellNode.classList.contains('jp-CodeCell')) {
        return;
    }
    // Try to find the cell toolbar
    const cellToolbar = cellNode.querySelector('.jp-cell-toolbar');
    if (cellToolbar) {
        // Inject into existing toolbar
        injectButtonsIntoToolbar(cellToolbar, cell);
    }
    // Set up error output watcher to blink Fix button on errors
    setupErrorWatcher(cell);
    // Set up MutationObserver to watch for toolbar creation
    if (!cellNode.hasAttribute('data-hdsp-observer')) {
        cellNode.setAttribute('data-hdsp-observer', 'true');
        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                for (const node of Array.from(mutation.addedNodes)) {
                    if (node instanceof HTMLElement) {
                        const toolbar = node.classList.contains('jp-cell-toolbar')
                            ? node
                            : node.querySelector('.jp-cell-toolbar');
                        if (toolbar) {
                            injectButtonsIntoToolbar(toolbar, cell);
                        }
                    }
                }
            }
        });
        observer.observe(cellNode, { childList: true, subtree: true });
    }
}
/**
 * Inject HDSP buttons into the cell toolbar
 */
function injectButtonsIntoToolbar(toolbar, cell) {
    // Check if buttons already exist
    if (toolbar.querySelector('.jp-hdsp-toolbar-btn')) {
        return;
    }
    // Create a separator
    const separator = document.createElement('div');
    separator.className = 'jp-Toolbar-item jp-hdsp-separator';
    separator.style.cssText = `
    width: 1px;
    height: 20px;
    background: var(--jp-border-color1, #ccc);
    margin: 0 4px;
  `;
    // Create icon buttons
    const explainBtn = createToolbarButton(ICONS.explain, '코드 설명 (Explain)', () => {
        handleCellAction(_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.EXPLAIN, cell);
    });
    const questionBtn = createToolbarButton(ICONS.question, '질문하기 (Ask)', () => {
        handleCellAction(_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.CUSTOM_PROMPT, cell);
    });
    // Insert at the beginning of the toolbar
    const firstChild = toolbar.firstChild;
    toolbar.insertBefore(questionBtn, firstChild);
    toolbar.insertBefore(explainBtn, firstChild);
    toolbar.insertBefore(separator, firstChild);
}
/**
 * Create a toolbar button matching JupyterLab's style
 */
function createToolbarButton(iconSvg, title, onClick) {
    const container = document.createElement('div');
    container.className = 'lm-Widget jp-CommandToolbarButton jp-Toolbar-item jp-hdsp-toolbar-btn';
    const button = document.createElement('button');
    button.className = 'jp-ToolbarButtonComponent jp-hdsp-action-btn';
    button.title = title;
    button.setAttribute('aria-label', title);
    button.innerHTML = iconSvg;
    button.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick();
    };
    // Style to match JupyterLab buttons
    button.style.cssText = `
    background: transparent;
    border: none;
    cursor: pointer;
    padding: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    color: var(--jp-ui-font-color1, #333);
    transition: background 0.1s ease;
  `;
    button.addEventListener('mouseenter', () => {
        button.style.background = 'var(--jp-layout-color2, #e0e0e0)';
    });
    button.addEventListener('mouseleave', () => {
        button.style.background = 'transparent';
    });
    container.appendChild(button);
    return container;
}
/**
 * Handle cell action button click
 */
async function handleCellAction(action, cell) {
    const cellContent = cell?.model?.sharedModel?.getSource() || '';
    if (!cellContent.trim()) {
        showNotification('셀 내용이 비어있습니다.', 'warning');
        return;
    }
    const cellIndex = getCellIndex(cell);
    // Analytics: track cell button clicks (C1-C3)
    const featureMap = {
        [_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.EXPLAIN]: 'cell_explain',
        [_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.FIX]: 'cell_fix',
        [_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.CUSTOM_PROMPT]: 'cell_question',
    };
    const feature = featureMap[action];
    if (feature) {
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackClick(feature, { cell_index: cellIndex, prompt: cellContent });
    }
    if (action === _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.CUSTOM_PROMPT) {
        // For custom prompt, show dialog (no confirmation needed)
        showCustomPromptDialog(cell);
    }
    else {
        // Get cell output
        const cellOutput = getCellOutput(cell);
        // Determine confirmation dialog content based on action
        let title = '';
        let message = '';
        switch (action) {
            case _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.EXPLAIN:
                title = `셀 ${cellIndex}번째: 설명 요청`;
                message = '이 셀의 코드 설명을 보시겠습니까?';
                break;
            case _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.FIX: {
                const isError = hasCellError(cell);
                title = isError
                    ? `셀 ${cellIndex}번째: 에러 수정 요청`
                    : `셀 ${cellIndex}번째: 개선 제안 요청`;
                message = isError
                    ? '이 셀의 에러를 분석하고 수정 방법을 제안받으시겠습니까?'
                    : '이 셀의 코드 개선 제안을 받으시겠습니까?';
                break;
            }
        }
        // Show confirmation dialog first
        const confirmed = await showConfirmDialog(title, message);
        if (confirmed) {
            const errorDetected = hasCellError(cell);
            sendToSidebarPanel(action, cell, cellContent, cellIndex, cellOutput, errorDetected);
        }
    }
}
/**
 * Get the index of a cell in the notebook
 */
function getCellIndex(cell) {
    const app = window.jupyterapp;
    const notebookTracker = app?.shell?.currentWidget?.content;
    if (!notebookTracker) {
        return -1;
    }
    const widgets = notebookTracker.widgets;
    for (let i = 0; i < widgets.length; i++) {
        if (widgets[i] === cell) {
            return i + 1; // Return 1-based index
        }
    }
    return -1;
}
/**
 * Extract output from a code cell
 */
function getCellOutput(cell) {
    // cell.model이 null일 수 있으므로 안전하게 체크
    if (!cell?.model || cell.model.type !== 'code') {
        return '';
    }
    const codeCell = cell;
    const outputs = codeCell.model?.outputs;
    if (!outputs || outputs.length === 0) {
        return '';
    }
    const outputTexts = [];
    for (let i = 0; i < outputs.length; i++) {
        const output = outputs.get(i);
        const outputType = output.type;
        if (outputType === 'stream') {
            // stdout, stderr
            const text = output.text;
            if (Array.isArray(text)) {
                outputTexts.push(text.join(''));
            }
            else {
                outputTexts.push(text);
            }
        }
        else if (outputType === 'execute_result' || outputType === 'display_data') {
            // Execution results or display data
            const data = output.data;
            if (data['text/plain']) {
                const text = data['text/plain'];
                if (Array.isArray(text)) {
                    outputTexts.push(text.join(''));
                }
                else {
                    outputTexts.push(text);
                }
            }
        }
        else if (outputType === 'error') {
            // Error output
            const traceback = output.traceback;
            if (Array.isArray(traceback)) {
                outputTexts.push(traceback.join('\n'));
            }
        }
    }
    return outputTexts.join('\n');
}
function stripAnsi(str) {
    return str.replace(/\x1b\[[0-9;]*m/g, '');
}
function hasCellError(cell) {
    const codeCell = cell;
    const outputs = codeCell.model?.outputs;
    if (!outputs)
        return false;
    for (let i = 0; i < outputs.length; i++) {
        const output = outputs.get(i);
        if (output.type === 'error')
            return true;
    }
    return false;
}
/**
 * Get or assign cell ID to a cell
 */
function getOrAssignCellId(cell) {
    const cellModel = cell.model;
    let cellId;
    // Try to get cell ID from metadata
    try {
        if (cellModel.metadata && typeof cellModel.metadata.get === 'function') {
            cellId = cellModel.metadata.get('jupyterAgentCellId');
        }
        else if (cellModel.metadata?.jupyterAgentCellId) {
            cellId = cellModel.metadata.jupyterAgentCellId;
        }
    }
    catch (e) {
        // Ignore errors
    }
    if (!cellId) {
        cellId = `cell-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        // Try to set cell ID in metadata
        try {
            if (cellModel.metadata && typeof cellModel.metadata.set === 'function') {
                cellModel.metadata.set('jupyterAgentCellId', cellId);
            }
            else if (cellModel.metadata) {
                cellModel.metadata.jupyterAgentCellId = cellId;
            }
        }
        catch (e) {
            // Ignore errors
        }
    }
    return cellId;
}
/**
 * Send cell action to sidebar panel
 */
function sendToSidebarPanel(action, cell, cellContent, cellIndex, cellOutput, hasError) {
    const agentPanel = window._hdspAgentPanel;
    if (!agentPanel) {
        console.error('[CellButtonsPlugin] Agent panel not found. Make sure sidebar plugin is loaded.');
        return;
    }
    // Get or assign cell ID
    const cellId = getOrAssignCellId(cell);
    // Activate the sidebar panel
    const app = window.jupyterapp;
    if (app) {
        app.shell.activateById(agentPanel.id);
    }
    // Create user-facing display prompt
    let displayPrompt = '';
    // Create actual LLM prompt (based on chrome_agent)
    // Note: Use original content, not escaped. JSON.stringify will handle escaping.
    let llmPrompt = '';
    switch (action) {
        case _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.EXPLAIN:
            // User sees: "Cell x: 설명 요청" (chrome_agent와 동일)
            displayPrompt = `${cellIndex}번째 셀: 설명 요청`;
            // LLM receives: chrome_agent와 동일한 프롬프트
            llmPrompt = `다음 Jupyter 셀의 내용을 자세히 설명해주세요:

\`\`\`python
${cellContent}
\`\`\``;
            break;
        case _types__WEBPACK_IMPORTED_MODULE_1__.CellAction.FIX:
            console.log('[CellButtonsPlugin] FIX action:', { hasError, cellOutputLength: cellOutput.length });
            if (hasError) {
                // 에러가 있는 경우 (chrome_agent와 동일)
                displayPrompt = `${cellIndex}번째 셀: 에러 수정 요청`;
                llmPrompt = `다음 Jupyter 셀 코드에 에러가 발생했습니다.

원본 코드:
\`\`\`python
${cellContent}
\`\`\`

에러:
\`\`\`
${stripAnsi(cellOutput)}
\`\`\`

다음 형식으로 응답해주세요:

## 에러 원인
(에러가 발생한 원인을 간단히 설명)

## 수정 방법

### 방법 1: (수정 방법 제목)
(이 방법에 대한 간단한 설명)
\`\`\`python
(수정된 코드)
\`\`\`

### 방법 2: (수정 방법 제목)
(이 방법에 대한 간단한 설명)
\`\`\`python
(수정된 코드)
\`\`\`

### 방법 3: (수정 방법 제목) (있는 경우)
(이 방법에 대한 간단한 설명)
\`\`\`python
(수정된 코드)
\`\`\`

최소 2개, 최대 3개의 다양한 수정 방법을 제안해주세요.`;
            }
            else {
                // 에러가 없는 경우 - 코드 리뷰/개선 제안 (chrome_agent와 동일)
                displayPrompt = `${cellIndex}번째 셀: 개선 제안 요청`;
                llmPrompt = `다음 Jupyter 셀 코드를 리뷰하고 개선 방법을 제안해주세요.

코드:
\`\`\`python
${cellContent}
\`\`\`${cellOutput ? `\n\n실행 결과:\n\`\`\`\n${stripAnsi(cellOutput)}\n\`\`\`` : ''}

다음 형식으로 응답해주세요:

## 코드 분석
(현재 코드의 기능과 특징을 간단히 설명)

## 개선 방법

### 방법 1: (개선 방법 제목)
(이 방법에 대한 간단한 설명)
\`\`\`python
(개선된 코드)
\`\`\`

### 방법 2: (개선 방법 제목)
(이 방법에 대한 간단한 설명)
\`\`\`python
(개선된 코드)
\`\`\`

### 방법 3: (개선 방법 제목) (있는 경우)
(이 방법에 대한 간단한 설명)
\`\`\`python
(개선된 코드)
\`\`\`

최소 2개, 최대 3개의 다양한 개선 방법을 제안해주세요.`;
            }
            break;
    }
    // Send both prompts to panel with cell ID and cell index
    if (agentPanel.addCellActionMessage) {
        // cellIndex is 1-based (for display), convert to 0-based for array access
        const cellIndexZeroBased = cellIndex - 1;
        agentPanel.addCellActionMessage(action, cellContent, displayPrompt, llmPrompt, cellId, cellIndexZeroBased);
    }
}
/**
 * Helper: Remove existing dialog if present
 */
function removeExistingDialog(className) {
    const existingDialog = document.querySelector(`.${className}`);
    if (existingDialog) {
        existingDialog.remove();
    }
}
/**
 * Helper: Create dialog overlay element
 */
function createDialogOverlay(className) {
    const dialogOverlay = document.createElement('div');
    dialogOverlay.className = className;
    dialogOverlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    z-index: 10000;
    display: flex;
    align-items: center;
    justify-content: center;
  `;
    return dialogOverlay;
}
/**
 * Helper: Create dialog container element
 */
function createDialogContainer(maxWidth = '400px') {
    const dialogContainer = document.createElement('div');
    dialogContainer.style.cssText = `
    background: #fafafa;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    padding: 24px;
    max-width: ${maxWidth};
    width: 90%;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;
    return dialogContainer;
}
/**
 * Show confirmation dialog
 * Based on chrome_agent's showConfirmDialog implementation
 */
function showConfirmDialog(title, message) {
    return new Promise((resolve) => {
        removeExistingDialog('jp-agent-confirm-dialog');
        const dialogOverlay = createDialogOverlay('jp-agent-confirm-dialog');
        const dialogContainer = createDialogContainer();
        // Dialog content
        dialogContainer.innerHTML = `
      <div style="margin-bottom: 20px;">
        <h3 style="margin: 0 0 12px 0; color: #424242; font-size: 16px; font-weight: 500;">
          ${escapeHtml(title)}
        </h3>
        <p style="margin: 0; color: #616161; font-size: 14px; line-height: 1.5;">
          ${escapeHtml(message)}
        </p>
      </div>
      <div style="display: flex; gap: 12px; justify-content: flex-end;">
        <button class="jp-agent-confirm-cancel-btn" style="
          background: transparent;
          color: #616161;
          border: 1px solid #d1d5db;
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">취소</button>
        <button class="jp-agent-confirm-submit-btn" style="
          background: #1976d2;
          color: white;
          border: 1px solid #1976d2;
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">확인</button>
      </div>
    `;
        dialogOverlay.appendChild(dialogContainer);
        document.body.appendChild(dialogOverlay);
        // Button event listeners
        const cancelBtn = dialogContainer.querySelector('.jp-agent-confirm-cancel-btn');
        const submitBtn = dialogContainer.querySelector('.jp-agent-confirm-submit-btn');
        // Cancel button
        cancelBtn.addEventListener('click', () => {
            dialogOverlay.remove();
            resolve(false);
        });
        cancelBtn.addEventListener('mouseenter', () => {
            cancelBtn.style.background = '#f5f5f5';
        });
        cancelBtn.addEventListener('mouseleave', () => {
            cancelBtn.style.background = 'transparent';
        });
        // Submit button
        submitBtn.addEventListener('click', () => {
            submitBtn.disabled = true;
            submitBtn.textContent = '처리 중...';
            // Small delay to show processing state
            setTimeout(() => {
                dialogOverlay.remove();
                resolve(true);
            }, 100);
        });
        submitBtn.addEventListener('mouseenter', () => {
            if (!submitBtn.disabled) {
                submitBtn.style.background = '#1565c0';
            }
        });
        submitBtn.addEventListener('mouseleave', () => {
            if (!submitBtn.disabled) {
                submitBtn.style.background = '#1976d2';
            }
        });
        // ESC key to close
        const handleEsc = (e) => {
            if (e.key === 'Escape') {
                dialogOverlay.remove();
                document.removeEventListener('keydown', handleEsc);
                resolve(false);
            }
        };
        document.addEventListener('keydown', handleEsc);
        // Close on overlay click
        dialogOverlay.addEventListener('click', (e) => {
            if (e.target === dialogOverlay) {
                dialogOverlay.remove();
                document.removeEventListener('keydown', handleEsc);
                resolve(false);
            }
        });
    });
}
/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
/**
 * Escape content for markdown code blocks
 * Based on chrome_agent's escapeContent function
 */
function escapeContent(content) {
    if (!content)
        return '';
    // 백슬래시를 먼저 escape (다른 escape 처리 전에 수행)
    let escaped = content.replace(/\\/g, '\\\\');
    // 백틱 escape (마크다운 코드 블록 안에서 문제 방지)
    escaped = escaped.replace(/`/g, '\\`');
    return escaped;
}
/**
 * Get notification background color
 */
function getNotificationColor(type) {
    switch (type) {
        case 'error': return '#f56565';
        case 'warning': return '#ed8936';
        default: return '#4299e1';
    }
}
/**
 * Create notification element with styles
 */
function createNotificationElement(message, backgroundColor) {
    const notification = document.createElement('div');
    notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 16px;
    border-radius: 6px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    z-index: 10001;
    opacity: 0;
    transition: opacity 0.3s ease;
    max-width: 300px;
    word-wrap: break-word;
    background: ${backgroundColor};
  `;
    notification.textContent = message;
    return notification;
}
/**
 * Animate notification appearance and removal
 */
function animateNotification(notification) {
    // Show animation
    setTimeout(() => notification.style.opacity = '1', 10);
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}
/**
 * Show notification (simple implementation)
 */
function showNotification(message, type = 'info') {
    const notification = createNotificationElement(message, getNotificationColor(type));
    document.body.appendChild(notification);
    animateNotification(notification);
}
/**
 * Show custom prompt dialog
 * Based on chrome_agent's showCustomPromptDialog implementation
 */
function showCustomPromptDialog(cell) {
    const cellContent = cell?.model?.sharedModel?.getSource() || '';
    const cellIndex = getCellIndex(cell);
    const cellId = getOrAssignCellId(cell);
    console.log('커스텀 프롬프트 다이얼로그 표시', cellIndex, cellId);
    removeExistingDialog('jp-agent-custom-prompt-dialog');
    const dialogOverlay = createDialogOverlay('jp-agent-custom-prompt-dialog');
    const dialogContainer = createDialogContainer('500px');
    // 다이얼로그 내용
    dialogContainer.innerHTML = `
    <div style="margin-bottom: 20px;">
      <h3 style="margin: 0 0 8px 0; color: #424242; font-size: 16px; font-weight: 500;">
        셀에 대해 질문하기
      </h3>
      <p style="margin: 0; color: #757575; font-size: 13px;">
        물리적 위치: 셀 ${cellIndex + 1}번째 (위에서 아래로 카운트)
      </p>
    </div>
    <div style="margin-bottom: 20px;">
      <textarea class="jp-agent-custom-prompt-input"
        placeholder="이 셀에 대해 질문할 내용을 입력하세요..."
        style="
          width: 100%;
          min-height: 100px;
          padding: 12px;
          border: 1px solid #d1d5db;
          border-radius: 4px;
          font-size: 14px;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          resize: vertical;
          box-sizing: border-box;
        "
      ></textarea>
    </div>
    <div style="display: flex; gap: 12px; justify-content: flex-end;">
      <button class="jp-agent-custom-prompt-cancel-btn" style="
        background: transparent;
        color: #616161;
        border: 1px solid #d1d5db;
        border-radius: 3px;
        padding: 8px 16px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
      ">취소</button>
      <button class="jp-agent-custom-prompt-submit-btn" style="
        background: transparent;
        color: #1976d2;
        border: 1px solid #1976d2;
        border-radius: 3px;
        padding: 8px 16px;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s ease;
      ">질문</button>
    </div>
  `;
    dialogOverlay.appendChild(dialogContainer);
    document.body.appendChild(dialogOverlay);
    // 입력 필드에 포커스
    const inputField = dialogContainer.querySelector('.jp-agent-custom-prompt-input');
    setTimeout(() => inputField?.focus(), 100);
    // 버튼 이벤트 리스너
    const cancelBtn = dialogContainer.querySelector('.jp-agent-custom-prompt-cancel-btn');
    const submitBtn = dialogContainer.querySelector('.jp-agent-custom-prompt-submit-btn');
    // 취소 버튼
    cancelBtn.addEventListener('click', () => {
        dialogOverlay.remove();
    });
    cancelBtn.addEventListener('mouseenter', () => {
        cancelBtn.style.background = '#f5f5f5';
        cancelBtn.style.borderColor = '#9ca3af';
    });
    cancelBtn.addEventListener('mouseleave', () => {
        cancelBtn.style.background = 'transparent';
        cancelBtn.style.borderColor = '#d1d5db';
    });
    // 제출 버튼
    const handleSubmit = async () => {
        const promptText = inputField?.value.trim() || '';
        if (!promptText) {
            showNotification('질문 내용을 입력해주세요.', 'warning');
            return;
        }
        dialogOverlay.remove();
        // Get cell output
        const cellOutput = getCellOutput(cell);
        // Create display prompt: "Cell x: Custom request"
        const displayPrompt = `${cellIndex}번째 셀: ${promptText}`;
        // Create LLM prompt with code and output
        let llmPrompt = `${promptText}\n\n셀 내용:\n\`\`\`\n${cellContent}\n\`\`\``;
        if (cellOutput) {
            llmPrompt += `\n\n실행 결과:\n\`\`\`\n${cellOutput}\n\`\`\``;
        }
        const agentPanel = window._hdspAgentPanel;
        if (agentPanel) {
            // Activate the sidebar panel
            const app = window.jupyterapp;
            if (app) {
                app.shell.activateById(agentPanel.id);
            }
            // Send both prompts with cell ID and cell index
            if (agentPanel.addCellActionMessage) {
                // cellIndex is 1-based (for display), convert to 0-based for array access
                const cellIndexZeroBased = cellIndex - 1;
                agentPanel.addCellActionMessage(_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.CUSTOM_PROMPT, cellContent, displayPrompt, llmPrompt, cellId, cellIndexZeroBased);
            }
        }
    };
    submitBtn.addEventListener('click', handleSubmit);
    submitBtn.addEventListener('mouseenter', () => {
        submitBtn.style.background = 'rgba(25, 118, 210, 0.1)';
    });
    submitBtn.addEventListener('mouseleave', () => {
        submitBtn.style.background = 'transparent';
    });
    // Enter 키로 제출 (Shift+Enter는 줄바꿈)
    inputField?.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit();
        }
    });
    // 오버레이 클릭 시 다이얼로그 닫기
    dialogOverlay.addEventListener('click', (e) => {
        if (e.target === dialogOverlay) {
            dialogOverlay.remove();
        }
    });
    // ESC 키로 다이얼로그 닫기
    const handleEscapeKey = (e) => {
        if (e.key === 'Escape') {
            dialogOverlay.remove();
            document.removeEventListener('keydown', handleEscapeKey);
        }
    };
    document.addEventListener('keydown', handleEscapeKey);
}
/**
 * Watch cell outputs for errors and show a floating Fix button on the cell.
 * Listens to the cell output model's changed signal.
 */
function setupErrorWatcher(cell) {
    if (cell.model.type !== 'code')
        return;
    const cellNode = cell.node;
    if (cellNode.hasAttribute('data-hdsp-error-watcher'))
        return;
    cellNode.setAttribute('data-hdsp-error-watcher', 'true');
    const codeCell = cell;
    const outputs = codeCell.model?.outputs;
    if (!outputs)
        return;
    outputs.changed.connect(() => {
        updateErrorFixButton(cell);
    });
    // 초기 검사: 노트북 로드 시 이미 에러가 있으면 버튼 표시
    if (outputs.length > 0) {
        updateErrorFixButton(cell);
    }
}
/**
 * Show or remove a floating "수정 제안" button on cells with error output.
 * The button is injected into the cell's output area so it's always visible,
 * regardless of which cell is currently active/selected.
 */
function updateErrorFixButton(cell) {
    const codeCell = cell;
    const outputs = codeCell.model?.outputs;
    if (!outputs)
        return;
    let hasError = false;
    for (let i = 0; i < outputs.length; i++) {
        const output = outputs.get(i);
        if (output.type === 'error') {
            hasError = true;
            break;
        }
    }
    const cellNode = cell.node;
    const existing = cellNode.querySelector('.jp-hdsp-error-fix-btn');
    if (!hasError) {
        // No error: remove button if present
        if (existing)
            existing.remove();
        return;
    }
    // Already showing
    if (existing)
        return;
    // 에러 발생 시점 자동 로그 (코드 + 아웃풋)
    _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackError('cell_execution_error', {
        cell_index: getCellIndex(cell),
        source: (cell.model?.sharedModel?.getSource() || '').slice(0, 3000),
        output: getCellOutput(cell).slice(0, 3000),
    });
    // Create floating fix button on the cell
    const btn = document.createElement('button');
    btn.className = 'jp-hdsp-error-fix-btn jp-hdsp-fix-blink';
    btn.title = '수정 제안 (Fix)';
    btn.innerHTML = `${ICONS.fix}<span class="jp-hdsp-error-fix-label">수정 제안</span>`;
    btn.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        btn.classList.remove('jp-hdsp-fix-blink');
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackClick('cell_error_fix', { cell_index: getCellIndex(cell), has_error: true, prompt: cell?.model?.sharedModel?.getSource() || '' });
        handleCellAction(_types__WEBPACK_IMPORTED_MODULE_1__.CellAction.FIX, cell);
    };
    // Insert into the output area wrapper
    const outputArea = cellNode.querySelector('.jp-Cell-outputWrapper');
    if (outputArea) {
        outputArea.style.position = 'relative';
        outputArea.appendChild(btn);
    }
}


/***/ },

/***/ "./lib/plugins/idle-monitor-plugin.js"
/*!********************************************!*\
  !*** ./lib/plugins/idle-monitor-plugin.js ***!
  \********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getIdleMonitor: () => (/* binding */ getIdleMonitor),
/* harmony export */   idleMonitorPlugin: () => (/* binding */ idleMonitorPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/terminal */ "webpack/sharing/consume/default/@jupyterlab/terminal");
/* harmony import */ var _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/**
 * Idle Monitor Plugin - 유휴 상태 모니터링 플러그인
 *
 * 사용자 활동을 모니터링하고 유휴 시간 초과 시 종료 트리거.
 * 다음 활동을 추적:
 * - 키보드 이벤트
 * - 마우스 이벤트
 * - 노트북 셀 실행 (커널 busy 상태)
 * - 터미널 출력
 */



/**
 * 플러그인 네임스페이스
 */
const PLUGIN_ID = '@hdsp-agent/idle-monitor';
const CONFIG_STORAGE_KEY = 'hdsp-agent-llm-config';
/**
 * 기본 유휴 타임아웃 (분 단위)
 */
const DEFAULT_IDLE_TIMEOUT_MINUTES = 60;
/**
 * Default tab hidden idle timeout (in minutes)
 * When browser tab is inactive/hidden, shutdown after this duration
 */
const DEFAULT_TAB_HIDDEN_IDLE_TIMEOUT_MINUTES = 30;
// Check intervals - must be shorter than warning period to detect it
const CHECK_INTERVAL_NORMAL_MS = 10 * 1000; // Check every 10 seconds (normal mode)
const CHECK_INTERVAL_WARNING_MS = 1000; // Check every second (warning mode for countdown)
// Warning period: show countdown before timeout (minimum 30 seconds, or 25% of timeout)
const MIN_WARNING_PERIOD_MS = 30 * 1000; // Minimum 30 seconds warning
/**
 * 유휴 상태 모니터링 서비스
 */
class IdleMonitorService {
    constructor() {
        this.checkIntervalId = null;
        this.countdownElement = null;
        this.isShuttingDown = false;
        this.notebookTracker = null;
        this.terminalTracker = null;
        this.isInWarningMode = false;
        this.isDisabled = false;
        // Tab hidden idle timeout configuration
        this.tabHiddenSince = null;
        // Server-side idle check (터미널 프로세스 감지)
        this.lastServerCheckTime = 0;
        this.SERVER_CHECK_INTERVAL_MS = 30 * 1000; // 30초마다 서버 확인
        /**
         * Throttle mousemove events to reduce performance impact
         */
        this.mouseMoveThrottleTime = 0;
        this.lastActivityTime = Date.now();
        // Start with default (60 minutes), then fetch from server
        this.idleTimeoutMinutes = DEFAULT_IDLE_TIMEOUT_MINUTES;
        this.isDisabled = false;
        this.idleTimeoutMs = this.idleTimeoutMinutes * 60 * 1000;
        const warningPeriod = Math.max(MIN_WARNING_PERIOD_MS, this.idleTimeoutMs * 0.25);
        this.warningStartMs = this.idleTimeoutMs - warningPeriod;
        // Initialize tab hidden timeout
        this.tabHiddenIdleTimeoutMinutes = this.loadTabHiddenTimeoutFromConfig();
        this.tabHiddenIdleTimeoutMs = this.tabHiddenIdleTimeoutMinutes * 60 * 1000;
        this.setupActivityListeners();
        this.setupStorageListener();
        this.setupVisibilityListener();
        this.createCountdownElement();
        // Fetch actual timeout from Agent Server
        this.fetchIdleTimeoutFromServer();
        if (!this.isDisabled) {
            this.startIdleCheck();
        }
        console.log('[IdleMonitor] Service initialized. Idle timeout:', this.idleTimeoutMinutes, 'minutes, tab hidden timeout:', this.tabHiddenIdleTimeoutMinutes, 'minutes', this.isDisabled ? '(DISABLED)' : '');
    }
    /**
     * Fetch idle timeout setting from Agent Server
     */
    async fetchIdleTimeoutFromServer() {
        try {
            const serverRoot = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PageConfig.getBaseUrl();
            const response = await fetch(`${serverRoot}hdsp-agent/config/admin`);
            if (!response.ok) {
                console.warn('[IdleMonitor] Failed to fetch config from server:', response.status);
                return;
            }
            const config = await response.json();
            const serverTimeoutSeconds = config.idleTimeout;
            if (typeof serverTimeoutSeconds === 'number' && serverTimeoutSeconds > 0) {
                // Server sends seconds, convert to minutes
                const newTimeoutMinutes = Math.ceil(serverTimeoutSeconds / 60);
                if (newTimeoutMinutes !== this.idleTimeoutMinutes) {
                    this.updateIdleTimeout(newTimeoutMinutes);
                    console.log('[IdleMonitor] Updated timeout from server:', newTimeoutMinutes, 'minutes');
                }
            }
            else if (serverTimeoutSeconds === 0) {
                // 0 means disabled
                this.isDisabled = true;
                this.stopIdleCheck();
                console.log('[IdleMonitor] Idle timeout disabled by server config');
            }
        }
        catch (error) {
            console.warn('[IdleMonitor] Error fetching config from server:', error);
        }
    }
    /**
     * Load tab hidden timeout configuration from localStorage
     */
    loadTabHiddenTimeoutFromConfig() {
        try {
            const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
            if (stored) {
                const config = JSON.parse(stored);
                if (typeof config.tabHiddenIdleTimeoutMinutes === 'number') {
                    return config.tabHiddenIdleTimeoutMinutes;
                }
            }
        }
        catch (e) {
            console.warn('[IdleMonitor] Failed to load tab hidden timeout config:', e);
        }
        return DEFAULT_TAB_HIDDEN_IDLE_TIMEOUT_MINUTES;
    }
    /**
     * Setup Page Visibility API listener for tab hidden/visible changes
     */
    setupVisibilityListener() {
        document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'hidden') {
                // Tab became hidden - start tracking hidden time
                this.tabHiddenSince = Date.now();
                console.log('[IdleMonitor] Tab became hidden');
            }
            else {
                // Tab became visible - reset hidden timer and activity
                this.tabHiddenSince = null;
                this.resetIdleTimer();
                console.log('[IdleMonitor] Tab became visible');
            }
        });
        console.log('[IdleMonitor] Visibility listener attached');
    }
    /**
     * Setup listener for localStorage changes (config updates from settings panel)
     */
    setupStorageListener() {
        window.addEventListener('storage', (e) => {
            if (e.key === CONFIG_STORAGE_KEY) {
                try {
                    const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
                    if (stored) {
                        const config = JSON.parse(stored);
                        if (typeof config.idleTimeoutMinutes === 'number' && config.idleTimeoutMinutes !== this.idleTimeoutMinutes) {
                            this.updateIdleTimeout(config.idleTimeoutMinutes);
                        }
                    }
                }
                catch (err) {
                    console.warn('[IdleMonitor] Failed to parse config update:', err);
                }
            }
        });
        // Also listen for custom event (same-tab config changes)
        window.addEventListener('hdsp-config-updated', () => {
            try {
                const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
                if (stored) {
                    const config = JSON.parse(stored);
                    if (typeof config.idleTimeoutMinutes === 'number' && config.idleTimeoutMinutes !== this.idleTimeoutMinutes) {
                        this.updateIdleTimeout(config.idleTimeoutMinutes);
                    }
                }
            }
            catch (err) {
                console.warn('[IdleMonitor] Failed to parse config update:', err);
            }
        });
    }
    /**
     * Update idle timeout dynamically
     */
    updateIdleTimeout(minutes) {
        this.idleTimeoutMinutes = minutes;
        this.idleTimeoutMs = minutes * 60 * 1000;
        const warningPeriod = Math.max(MIN_WARNING_PERIOD_MS, this.idleTimeoutMs * 0.25);
        this.warningStartMs = this.idleTimeoutMs - warningPeriod;
    }
    /**
     * Stop idle check interval
     */
    stopIdleCheck() {
        if (this.checkIntervalId !== null) {
            clearInterval(this.checkIntervalId);
            this.checkIntervalId = null;
        }
        this.isInWarningMode = false;
        console.log('[IdleMonitor] Idle check stopped');
    }
    /**
     * Set notebook tracker for monitoring cell execution
     */
    setNotebookTracker(tracker) {
        this.notebookTracker = tracker;
        // Monitor cell execution changes
        tracker.currentChanged.connect(() => {
            this.resetIdleTimer();
        });
        // Monitor active cell changes
        tracker.activeCellChanged.connect(() => {
            this.resetIdleTimer();
        });
        console.log('[IdleMonitor] Notebook tracker connected');
    }
    /**
     * Set terminal tracker for monitoring terminal activity
     */
    setTerminalTracker(tracker) {
        this.terminalTracker = tracker;
        // Monitor terminal changes
        tracker.currentChanged.connect(() => {
            this.resetIdleTimer();
        });
        // Setup monitoring for existing terminals
        tracker.forEach(terminal => {
            this.setupTerminalMonitoring(terminal);
        });
        // Monitor new terminals
        tracker.widgetAdded.connect((_, terminal) => {
            this.setupTerminalMonitoring(terminal);
        });
        console.log('[IdleMonitor] Terminal tracker connected');
    }
    /**
     * Setup monitoring for a single terminal
     * Simply reset idle timer on any terminal output
     */
    setupTerminalMonitoring(terminal) {
        const terminalId = terminal.id || terminal.session?.name || 'unknown';
        const session = terminal.session;
        if (!session)
            return;
        // Listen for terminal output - any output resets idle timer
        session.messageReceived.connect(() => {
            this.resetIdleTimer();
        });
        console.log('[IdleMonitor] Terminal monitoring setup:', terminalId);
    }
    /**
     * Setup global activity listeners
     */
    setupActivityListeners() {
        // Keyboard events
        document.addEventListener('keydown', this.handleActivity.bind(this), true);
        document.addEventListener('keyup', this.handleActivity.bind(this), true);
        document.addEventListener('keypress', this.handleActivity.bind(this), true);
        // Mouse events
        document.addEventListener('mousedown', this.handleActivity.bind(this), true);
        document.addEventListener('mouseup', this.handleActivity.bind(this), true);
        document.addEventListener('mousemove', this.throttledMouseMove.bind(this), true);
        document.addEventListener('wheel', this.handleActivity.bind(this), true);
        document.addEventListener('click', this.handleActivity.bind(this), true);
        // Touch events (for tablet support)
        document.addEventListener('touchstart', this.handleActivity.bind(this), true);
        document.addEventListener('touchend', this.handleActivity.bind(this), true);
        console.log('[IdleMonitor] Activity listeners attached');
    }
    throttledMouseMove() {
        const now = Date.now();
        if (now - this.mouseMoveThrottleTime > 5000) { // Only update every 5 seconds for mouse move
            this.mouseMoveThrottleTime = now;
            this.handleActivity();
        }
    }
    /**
     * Handle any user activity
     */
    handleActivity() {
        this.resetIdleTimer();
    }
    /**
     * Reset the idle timer
     */
    resetIdleTimer() {
        this.lastActivityTime = Date.now();
        this.isShuttingDown = false;
        this.hideCountdown();
        // Switch back to normal mode if in warning mode
        this.switchToNormalMode();
    }
    /**
     * Create countdown display element (fixed position, top-right)
     */
    createCountdownElement() {
        // Create countdown container with fixed positioning
        this.countdownElement = document.createElement('div');
        this.countdownElement.id = 'hdsp-idle-countdown';
        this.countdownElement.className = 'hdsp-idle-countdown';
        this.countdownElement.style.cssText = `
      display: none;
      position: fixed;
      right: 20px;
      top: 10px;
      background: linear-gradient(135deg, #ff6b6b 0%, #ee5a5a 100%);
      color: white;
      padding: 8px 16px;
      border-radius: 20px;
      font-size: 14px;
      font-weight: 600;
      box-shadow: 0 4px 12px rgba(238, 90, 90, 0.5);
      z-index: 99999;
      white-space: nowrap;
      cursor: pointer;
      user-select: none;
    `;
        // Click to dismiss and reset timer
        this.countdownElement.addEventListener('click', () => {
            this.resetIdleTimer();
            console.log('[IdleMonitor] User clicked countdown - timer reset');
        });
        // Add pulse animation
        const style = document.createElement('style');
        style.id = 'hdsp-idle-countdown-style';
        style.textContent = `
      @keyframes hdsp-pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.03); }
        100% { transform: scale(1); }
      }

      .hdsp-idle-countdown {
        animation: hdsp-pulse 2s infinite;
      }

      .hdsp-idle-countdown.warning {
        background: linear-gradient(135deg, #ffa726 0%, #fb8c00 100%) !important;
        box-shadow: 0 4px 12px rgba(251, 140, 0, 0.5) !important;
      }

      .hdsp-idle-countdown.critical {
        background: linear-gradient(135deg, #ef5350 0%, #d32f2f 100%) !important;
        box-shadow: 0 4px 12px rgba(211, 47, 47, 0.6) !important;
        animation: hdsp-pulse-critical 0.5s infinite !important;
      }

      @keyframes hdsp-pulse-critical {
        0% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.05); opacity: 0.9; }
        100% { transform: scale(1); opacity: 1; }
      }
    `;
        // Remove existing style if any
        const existingStyle = document.getElementById('hdsp-idle-countdown-style');
        if (existingStyle) {
            existingStyle.remove();
        }
        document.head.appendChild(style);
        // Append to body for fixed positioning
        document.body.appendChild(this.countdownElement);
        console.log('[IdleMonitor] Countdown element created (fixed position)');
    }
    /**
     * Show countdown in toolbar
     * @param secondsRemaining - seconds until shutdown
     * @param isTabHidden - whether this is triggered by tab hidden timeout
     */
    showCountdown(secondsRemaining, isTabHidden = false) {
        console.log(`[IdleMonitor] showCountdown called: ${secondsRemaining}s remaining, tabHidden=${isTabHidden}`);
        if (!this.countdownElement) {
            this.createCountdownElement();
            return;
        }
        this.countdownElement.style.display = 'block';
        const reason = isTabHidden ? '(탭 비활성)' : '';
        this.countdownElement.textContent = `Idle Shutdown ${secondsRemaining}초 전 ${reason}`;
        // Update styling based on urgency
        this.countdownElement.classList.remove('warning', 'critical');
        if (secondsRemaining <= 10) {
            this.countdownElement.classList.add('critical');
        }
        else if (secondsRemaining <= 30) {
            this.countdownElement.classList.add('warning');
        }
    }
    /**
     * Hide countdown display
     */
    hideCountdown() {
        if (this.countdownElement) {
            this.countdownElement.style.display = 'none';
        }
    }
    /**
     * Check if any notebook cells are currently executing
     * Uses kernel status for reliability
     */
    hasRunningCells() {
        if (!this.notebookTracker)
            return false;
        // Check all open notebooks via kernel status
        const notebooks = this.notebookTracker.filter(() => true);
        for (const notebook of notebooks) {
            const session = notebook.sessionContext?.session;
            if (session) {
                const kernelStatus = session.kernel?.status;
                // Kernel is busy = cells are executing
                if (kernelStatus === 'busy') {
                    return true;
                }
            }
            // Fallback: also check DOM for [*] indicator (for edge cases)
            if (notebook.content) {
                const cells = notebook.content.widgets;
                for (const cell of cells) {
                    const model = cell.model;
                    if (model && model.type === 'code') {
                        const promptNode = cell.node.querySelector('.jp-InputPrompt');
                        if (promptNode && promptNode.textContent?.includes('*')) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    /**
     * Start idle checking interval
     * Starts in normal mode (10 min), switches to warning mode (1 sec) when needed
     */
    startIdleCheck() {
        this.checkIntervalId = window.setInterval(() => {
            this.checkIdleStatus();
        }, CHECK_INTERVAL_NORMAL_MS);
        console.log('[IdleMonitor] Started in normal mode: check every 10 seconds');
    }
    /**
     * Switch to warning mode (faster checks for countdown)
     */
    switchToWarningMode() {
        if (this.isInWarningMode)
            return;
        this.isInWarningMode = true;
        // Clear normal interval
        if (this.checkIntervalId !== null) {
            clearInterval(this.checkIntervalId);
        }
        // Start warning interval (1 second)
        this.checkIntervalId = window.setInterval(() => {
            this.checkIdleStatus();
        }, CHECK_INTERVAL_WARNING_MS);
        console.log('[IdleMonitor] Switched to warning mode: check every', CHECK_INTERVAL_WARNING_MS / 1000, 'seconds');
    }
    /**
     * Switch back to normal mode
     */
    switchToNormalMode() {
        if (!this.isInWarningMode)
            return;
        this.isInWarningMode = false;
        // Clear warning interval
        if (this.checkIntervalId !== null) {
            clearInterval(this.checkIntervalId);
        }
        // Start normal interval (10 minutes)
        this.checkIntervalId = window.setInterval(() => {
            this.checkIdleStatus();
        }, CHECK_INTERVAL_NORMAL_MS);
        console.log('[IdleMonitor] Switched to normal mode: check every 10 seconds');
    }
    /**
     * Check current idle status
     */
    checkIdleStatus() {
        // Skip if disabled
        if (this.isDisabled) {
            return;
        }
        // Skip if notebook cells are running (not idle)
        if (this.hasRunningCells()) {
            this.tabHiddenSince = null; // Reset tab hidden timer when kernel is busy
            this.resetIdleTimer();
            return;
        }
        const now = Date.now();
        // 주기적으로 서버에 터미널/커널 활동 확인 (30초마다)
        if (now - this.lastServerCheckTime >= this.SERVER_CHECK_INTERVAL_MS) {
            this.lastServerCheckTime = now;
            this.checkServerIdleStatus();
        }
        // Check tab hidden timeout (separate from DOM activity timeout)
        // If tab is hidden and kernel is idle, use shorter timeout
        if (this.tabHiddenSince !== null && this.tabHiddenIdleTimeoutMs > 0) {
            const hiddenDuration = now - this.tabHiddenSince;
            const hiddenRemaining = this.tabHiddenIdleTimeoutMs - hiddenDuration;
            const hiddenSecondsRemaining = Math.ceil(hiddenRemaining / 1000);
            // Debug log for tab hidden state
            if (Math.floor(hiddenDuration / 1000) % 10 === 0) {
                console.log(`[IdleMonitor] Tab hidden for ${Math.round(hiddenDuration / 1000)}s, timeout at ${Math.round(this.tabHiddenIdleTimeoutMs / 1000)}s`);
            }
            // Warning period for tab hidden (last 30 seconds)
            const tabHiddenWarningMs = Math.max(MIN_WARNING_PERIOD_MS, this.tabHiddenIdleTimeoutMs * 0.1);
            if (hiddenDuration >= this.tabHiddenIdleTimeoutMs - tabHiddenWarningMs && !this.isShuttingDown) {
                this.switchToWarningMode();
                this.showCountdown(hiddenSecondsRemaining, true);
            }
            // Trigger shutdown if tab hidden timeout reached
            if (hiddenDuration >= this.tabHiddenIdleTimeoutMs && !this.isShuttingDown) {
                this.isShuttingDown = true;
                console.log('[IdleMonitor] Tab hidden timeout reached');
                this.triggerShutdown();
                return;
            }
        }
        // Standard DOM activity-based idle check
        const idleTime = now - this.lastActivityTime;
        const remainingTime = this.idleTimeoutMs - idleTime;
        const secondsRemaining = Math.ceil(remainingTime / 1000);
        // Debug log every 10 seconds
        if (Math.floor(idleTime / 1000) % 10 === 0) {
            console.log(`[IdleMonitor] idle=${Math.round(idleTime / 1000)}s, warningAt=${Math.round(this.warningStartMs / 1000)}s, timeout=${Math.round(this.idleTimeoutMs / 1000)}s, remaining=${secondsRemaining}s`);
        }
        // Enter warning period - switch to fast checking for countdown
        if (idleTime >= this.warningStartMs && !this.isShuttingDown) {
            this.switchToWarningMode();
            this.showCountdown(secondsRemaining, false);
        }
        // Trigger shutdown if idle timeout reached
        if (idleTime >= this.idleTimeoutMs && !this.isShuttingDown) {
            this.isShuttingDown = true;
            this.triggerShutdown();
        }
    }
    /**
     * Trigger shutdown process
     */
    async triggerShutdown() {
        console.log('[IdleMonitor] Idle timeout reached. Checking server-side activity...');
        // 서버에 터미널/커널 활동 확인 (터미널 프로세스 실행 중이면 shutdown 취소)
        try {
            const baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PageConfig.getBaseUrl();
            const resp = await fetch(`${baseUrl}hdsp-agent/idle-status`);
            if (resp.ok) {
                const status = await resp.json();
                if (!status.idle) {
                    console.log('[IdleMonitor] Server reports not idle (terminal/kernel active). Resetting timer.');
                    this.isShuttingDown = false;
                    this.resetIdleTimer();
                    return;
                }
            }
        }
        catch (e) {
            console.warn('[IdleMonitor] Failed to check server idle status:', e);
        }
        // Hide countdown
        this.hideCountdown();
        // Call HDSP shutdown API (서버가 환경에 맞게 처리)
        this.callShutdownApi().catch(e => console.error('[IdleMonitor] Shutdown API error:', e));
        // Show notification popup
        alert(`${this.idleTimeoutMinutes}분 동안 활동이 없어 세션이 종료됩니다.`);
    }
    /**
     * 서버에 터미널/커널 활동 확인. 활동 중이면 타이머 리셋.
     */
    async checkServerIdleStatus() {
        try {
            const baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PageConfig.getBaseUrl();
            const resp = await fetch(`${baseUrl}hdsp-agent/idle-status`);
            if (resp.ok) {
                const status = await resp.json();
                if (!status.idle) {
                    console.log('[IdleMonitor] Server reports active (terminal/kernel). Resetting timer.');
                    this.resetIdleTimer();
                }
            }
        }
        catch (e) {
            // 서버 연결 실패 시 무시 (프론트엔드 로직으로 폴백)
        }
    }
    /**
     * Call HDSP shutdown API via server-side endpoint.
     * 서버가 환경에 맞는 shutdown 처리 (HDSP API 또는 SageMaker delete_app).
     * 절대 POST /api/shutdown 으로 Jupyter를 직접 종료하지 않음.
     */
    async callShutdownApi() {
        try {
            const baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PageConfig.getBaseUrl();
            const apiUrl = `${baseUrl}hdsp-agent/idle-shutdown`;
            console.log('[IdleMonitor] Calling HDSP shutdown API:', apiUrl);
            const xsrfToken = document.cookie
                .split('; ')
                .find(row => row.startsWith('_xsrf='))
                ?.split('=')[1] || '';
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-XSRFToken': xsrfToken
                }
            });
            const result = await response.json();
            if (response.ok && result.success) {
                console.log('[IdleMonitor] HDSP shutdown API call successful:', result.message);
            }
            else {
                console.error('[IdleMonitor] HDSP shutdown API call failed:', result.error || response.statusText);
            }
        }
        catch (error) {
            console.error('[IdleMonitor] HDSP shutdown API call error:', error);
        }
    }
    /**
     * Get current idle time in milliseconds
     */
    getIdleTimeMs() {
        return Date.now() - this.lastActivityTime;
    }
    /**
     * Manually trigger activity (for external use)
     */
    triggerActivity() {
        this.resetIdleTimer();
    }
    /**
     * Cleanup service
     */
    dispose() {
        if (this.checkIntervalId !== null) {
            clearInterval(this.checkIntervalId);
            this.checkIntervalId = null;
        }
        if (this.countdownElement && this.countdownElement.parentNode) {
            this.countdownElement.parentNode.removeChild(this.countdownElement);
        }
        console.log('[IdleMonitor] Service disposed');
    }
}
/**
 * Global idle monitor instance
 */
let idleMonitor = null;
/**
 * Get idle monitor instance
 */
function getIdleMonitor() {
    return idleMonitor;
}
/**
 * Idle Monitor Plugin
 */
const idleMonitorPlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [],
    optional: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker, _jupyterlab_terminal__WEBPACK_IMPORTED_MODULE_1__.ITerminalTracker],
    activate: (app, notebookTracker, terminalTracker) => {
        console.log('[IdleMonitorPlugin] Activating Idle Monitor');
        try {
            // Create idle monitor service
            idleMonitor = new IdleMonitorService();
            // Connect notebook tracker if available
            if (notebookTracker) {
                idleMonitor.setNotebookTracker(notebookTracker);
            }
            // Connect terminal tracker if available
            if (terminalTracker) {
                idleMonitor.setTerminalTracker(terminalTracker);
            }
            // Store reference globally for debugging
            window._hdspIdleMonitor = idleMonitor;
            console.log('[IdleMonitorPlugin] Idle Monitor activated successfully');
        }
        catch (error) {
            console.error('[IdleMonitorPlugin] Failed to activate:', error);
        }
    }
};


/***/ },

/***/ "./lib/plugins/lsp-bridge-plugin.js"
/*!******************************************!*\
  !*** ./lib/plugins/lsp-bridge-plugin.js ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DiagnosticSeverity: () => (/* binding */ DiagnosticSeverity),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getLSPBridge: () => (/* binding */ getLSPBridge),
/* harmony export */   lspBridgePlugin: () => (/* binding */ lspBridgePlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/**
 * LSP Bridge Plugin - LSP 브릿지 플러그인
 *
 * jupyterlab-lsp와 HDSP Agent를 연결하는 브릿지
 * Crush 패턴 적용: Version-based 캐싱, 이벤트 기반 업데이트
 *
 * 주요 기능:
 * - LSP 진단 결과 캐싱 및 조회
 * - 심볼 참조 검색
 * - Agent 도구와 연동
 */

/**
 * 플러그인 네임스페이스
 */
const PLUGIN_ID = '@hdsp-agent/lsp-bridge';
/**
 * LSP 진단 심각도 레벨
 */
var DiagnosticSeverity;
(function (DiagnosticSeverity) {
    DiagnosticSeverity[DiagnosticSeverity["Error"] = 1] = "Error";
    DiagnosticSeverity[DiagnosticSeverity["Warning"] = 2] = "Warning";
    DiagnosticSeverity[DiagnosticSeverity["Information"] = 3] = "Information";
    DiagnosticSeverity[DiagnosticSeverity["Hint"] = 4] = "Hint";
})(DiagnosticSeverity || (DiagnosticSeverity = {}));
/**
 * LSP State Cache (Crush의 VersionedMap 패턴)
 * 버전 기반 캐시 무효화로 불필요한 재계산 방지
 */
class LSPStateCache {
    constructor() {
        this.diagnosticsVersion = 0;
        this.diagnosticsCache = new Map();
        this.summaryCache = null;
        this.summaryVersion = -1;
    }
    /**
     * Update diagnostics for a file
     */
    updateDiagnostics(uri, diagnostics) {
        this.diagnosticsCache.set(uri, diagnostics);
        this.diagnosticsVersion++;
    }
    /**
     * Get diagnostics for a specific file or all files
     */
    getDiagnostics(uri) {
        if (uri) {
            return {
                version: this.diagnosticsVersion,
                diagnostics: this.diagnosticsCache.get(uri) || []
            };
        }
        return {
            version: this.diagnosticsVersion,
            diagnostics: this.diagnosticsCache
        };
    }
    /**
     * Get diagnostic counts with caching (Crush 패턴)
     */
    getDiagnosticSummary() {
        // Return cached if version matches
        if (this.summaryVersion === this.diagnosticsVersion && this.summaryCache) {
            return this.summaryCache;
        }
        // Recalculate
        let errors = 0;
        let warnings = 0;
        let hints = 0;
        for (const diags of this.diagnosticsCache.values()) {
            for (const d of diags) {
                switch (d.severity) {
                    case DiagnosticSeverity.Error:
                        errors++;
                        break;
                    case DiagnosticSeverity.Warning:
                        warnings++;
                        break;
                    default:
                        hints++;
                }
            }
        }
        this.summaryCache = {
            errors,
            warnings,
            hints,
            total: errors + warnings + hints,
            version: this.diagnosticsVersion
        };
        this.summaryVersion = this.diagnosticsVersion;
        return this.summaryCache;
    }
    /**
     * Clear diagnostics for a file
     */
    clearDiagnostics(uri) {
        if (this.diagnosticsCache.has(uri)) {
            this.diagnosticsCache.delete(uri);
            this.diagnosticsVersion++;
        }
    }
    /**
     * Clear all diagnostics
     */
    clearAll() {
        this.diagnosticsCache.clear();
        this.diagnosticsVersion++;
    }
    /**
     * Get current version
     */
    getVersion() {
        return this.diagnosticsVersion;
    }
}
/**
 * LSP Bridge Service
 * Agent 도구에서 LSP 기능을 사용할 수 있게 해주는 서비스
 */
class LSPBridgeService {
    constructor() {
        this.cache = new LSPStateCache();
        this.lspAvailable = false;
        this.notebookTracker = null;
        this.checkLSPAvailability();
    }
    /**
     * Check if jupyterlab-lsp is available
     */
    async checkLSPAvailability() {
        try {
            // jupyterlab-lsp가 설치되어 있는지 확인
            // 실제로는 ILSPDocumentConnectionManager 토큰을 통해 확인
            this.lspAvailable = false; // 기본값, 실제 연결 시 true로 변경
            console.log('[LSPBridge] LSP availability check - will be updated when connection established');
        }
        catch (error) {
            console.warn('[LSPBridge] LSP not available:', error);
            this.lspAvailable = false;
        }
    }
    /**
     * Set notebook tracker for document access
     */
    setNotebookTracker(tracker) {
        this.notebookTracker = tracker;
    }
    /**
     * Mark LSP as available (called when connection is established)
     */
    setLSPAvailable(available) {
        this.lspAvailable = available;
        console.log('[LSPBridge] LSP available:', available);
    }
    /**
     * Check if LSP is available
     */
    isLSPAvailable() {
        return this.lspAvailable;
    }
    /**
     * Update diagnostics from external source (e.g., jupyterlab-lsp)
     */
    updateDiagnostics(uri, diagnostics) {
        this.cache.updateDiagnostics(uri, diagnostics);
        this.notifyDiagnosticsChanged(uri);
    }
    /**
     * Get diagnostics for Agent tool
     * Returns formatted diagnostics for a file or entire project
     */
    async getDiagnostics(filePath) {
        const result = this.cache.getDiagnostics(filePath ? this.pathToUri(filePath) : undefined);
        const summary = this.cache.getDiagnosticSummary();
        const formattedDiagnostics = [];
        if (filePath) {
            // Single file
            const diags = result.diagnostics;
            for (const d of diags) {
                formattedDiagnostics.push({
                    severity: this.severityToString(d.severity),
                    line: d.range.start.line + 1,
                    character: d.range.start.character,
                    message: d.message,
                    source: d.source,
                    code: d.code,
                    file: filePath
                });
            }
        }
        else {
            // All files
            const diagsMap = result.diagnostics;
            for (const [uri, diags] of diagsMap) {
                const file = this.uriToPath(uri);
                for (const d of diags) {
                    formattedDiagnostics.push({
                        severity: this.severityToString(d.severity),
                        line: d.range.start.line + 1,
                        character: d.range.start.character,
                        message: d.message,
                        source: d.source,
                        code: d.code,
                        file
                    });
                }
            }
        }
        // Sort: errors first, then by file and line (Crush 패턴)
        formattedDiagnostics.sort((a, b) => {
            const severityOrder = { error: 0, warning: 1, information: 2, hint: 3 };
            const severityDiff = (severityOrder[a.severity] || 3) - (severityOrder[b.severity] || 3);
            if (severityDiff !== 0)
                return severityDiff;
            const fileDiff = a.file.localeCompare(b.file);
            if (fileDiff !== 0)
                return fileDiff;
            return a.line - b.line;
        });
        return {
            success: true,
            diagnostics: formattedDiagnostics,
            summary
        };
    }
    /**
     * Find references for a symbol (Crush의 Grep-then-LSP 패턴)
     * 현재는 grep 기반으로 구현, LSP 연결 시 향상 가능
     */
    async getReferences(symbol, filePath, line, character) {
        // LSP가 없으면 grep 기반으로 검색하도록 안내
        if (!this.lspAvailable) {
            return {
                success: false,
                locations: []
            };
        }
        // TODO: jupyterlab-lsp 연결 시 구현
        // 현재는 빈 결과 반환 (Agent가 grep 도구 사용하도록)
        return {
            success: false,
            locations: []
        };
    }
    /**
     * Get diagnostic summary
     */
    getDiagnosticSummary() {
        return this.cache.getDiagnosticSummary();
    }
    /**
     * Notify diagnostics changed event
     */
    notifyDiagnosticsChanged(uri) {
        const summary = this.cache.getDiagnosticSummary();
        window.dispatchEvent(new CustomEvent('hdsp-lsp-diagnostics-changed', {
            detail: { uri, summary }
        }));
    }
    /**
     * Convert severity number to string
     */
    severityToString(severity) {
        switch (severity) {
            case DiagnosticSeverity.Error:
                return 'error';
            case DiagnosticSeverity.Warning:
                return 'warning';
            case DiagnosticSeverity.Information:
                return 'information';
            case DiagnosticSeverity.Hint:
                return 'hint';
            default:
                return 'hint';
        }
    }
    /**
     * Convert file path to URI
     */
    pathToUri(path) {
        if (path.startsWith('file://')) {
            return path;
        }
        return `file://${path.startsWith('/') ? '' : '/'}${path}`;
    }
    /**
     * Convert URI to file path
     */
    uriToPath(uri) {
        if (uri.startsWith('file://')) {
            return uri.replace('file://', '');
        }
        return uri;
    }
    /**
     * Dispose service
     */
    dispose() {
        this.cache.clearAll();
        console.log('[LSPBridge] Service disposed');
    }
}
/**
 * Global LSP Bridge instance
 */
let lspBridge = null;
/**
 * Get LSP Bridge instance
 */
function getLSPBridge() {
    return lspBridge;
}
/**
 * LSP Bridge Plugin
 *
 * jupyterlab-lsp가 설치되어 있으면 연동하고,
 * 없으면 기본 기능만 제공
 */
const lspBridgePlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [],
    optional: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, notebookTracker) => {
        console.log('[LSPBridgePlugin] Activating LSP Bridge...');
        // Create LSP Bridge service
        lspBridge = new LSPBridgeService();
        // Connect notebook tracker if available
        if (notebookTracker) {
            lspBridge.setNotebookTracker(notebookTracker);
        }
        // Store reference globally for debugging and Agent access
        window._hdspLSPBridge = lspBridge;
        // Try to connect to jupyterlab-lsp if available
        // This is done dynamically to avoid hard dependency
        tryConnectToLSP(app, lspBridge);
        console.log('[LSPBridgePlugin] LSP Bridge activated');
    }
};
/**
 * Try to connect to jupyterlab-lsp extension
 */
async function tryConnectToLSP(app, bridge) {
    try {
        // Check if ILSPDocumentConnectionManager is available
        // This token is provided by jupyterlab-lsp
        const lspToken = '@jupyterlab/lsp:ILSPDocumentConnectionManager';
        // Try to get the LSP manager from the application
        // Note: This requires jupyterlab-lsp to be installed
        const hasLSP = app.commands.hasCommand('lsp:show-diagnostics-panel');
        if (hasLSP) {
            console.log('[LSPBridgePlugin] jupyterlab-lsp detected');
            bridge.setLSPAvailable(true);
            // Listen for LSP diagnostic events
            // jupyterlab-lsp publishes diagnostics through its own mechanism
            setupLSPEventListeners(bridge);
        }
        else {
            console.log('[LSPBridgePlugin] jupyterlab-lsp not detected, using fallback mode');
            bridge.setLSPAvailable(false);
        }
    }
    catch (error) {
        console.warn('[LSPBridgePlugin] Failed to connect to jupyterlab-lsp:', error);
        bridge.setLSPAvailable(false);
    }
}
/**
 * Setup event listeners for LSP events
 */
function setupLSPEventListeners(bridge) {
    // jupyterlab-lsp uses its own event system
    // We'll listen for changes through polling or direct integration
    // This is a placeholder for future implementation
    console.log('[LSPBridgePlugin] LSP event listeners setup (placeholder)');
    // For now, we can use a simple polling mechanism or
    // hook into JupyterLab's document change events
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (lspBridgePlugin);


/***/ },

/***/ "./lib/plugins/notebook-toolbar-plugin.js"
/*!************************************************!*\
  !*** ./lib/plugins/notebook-toolbar-plugin.js ***!
  \************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   notebookToolbarPlugin: () => (/* binding */ notebookToolbarPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/AnalyticsService */ "./lib/services/AnalyticsService.js");
/**
 * Notebook Toolbar Plugin - 노트북 툴바에 스파클(✨) 버튼 추가
 * 클릭 시 확인 다이얼로그 → 사이드 패널에 `@notebook 설명해줘` 전송 (노트북 설명하기)
 */




// Lightbulb 아이콘 (Material Symbols "lightbulb" - 설명 기능 표준 아이콘)
const explainSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" width="16" height="16">
  <path fill="currentColor" d="M480-80q-34 0-57.5-23.5T399-161h162q0 34-23.5 57.5T480-80ZM318-223v-80h324v80H318Zm5-120q-66-43-104.5-107.5T180-597q0-122 89-211t211-89q122 0 211 89t89 211q0 82-38.5 146.5T637-343H323Zm22-80h270q44-29 69.5-71.5T710-597q0-97-66.5-163.5T480-827q-97 0-163.5 66.5T250-597q0 60 25.5 102.5T345-423Zm135 0Z"/>
</svg>`;
const explainIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({
    name: 'hdsp:notebook-explain',
    svgstr: explainSvg,
});
const BUTTON_NAME = 'hdsp-summary';
const DIALOG_CLASS = 'jp-agent-notebook-explain-dialog';
// --- Dialog helpers (same pattern as cell-buttons-plugin) ---
function removeExistingDialog() {
    const existing = document.querySelector(`.${DIALOG_CLASS}`);
    if (existing) {
        existing.remove();
    }
}
function createDialogOverlay() {
    const overlay = document.createElement('div');
    overlay.className = DIALOG_CLASS;
    overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    z-index: 10000;
    display: flex;
    align-items: center;
    justify-content: center;
  `;
    return overlay;
}
function createDialogContainer() {
    const container = document.createElement('div');
    container.style.cssText = `
    background: #fafafa;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    padding: 24px;
    max-width: 400px;
    width: 90%;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;
    return container;
}
function showConfirmDialog() {
    return new Promise((resolve) => {
        removeExistingDialog();
        const dialogOverlay = createDialogOverlay();
        const dialogContainer = createDialogContainer();
        dialogContainer.innerHTML = `
      <div style="margin-bottom: 20px;">
        <h3 style="margin: 0 0 12px 0; color: #424242; font-size: 16px; font-weight: 500;">
          ✨ 노트북 설명하기
        </h3>
        <p style="margin: 0; color: #616161; font-size: 14px; line-height: 1.5;">
          노트북 설명을 요청하시겠습니까?
        </p>
      </div>
      <div style="display: flex; gap: 12px; justify-content: flex-end;">
        <button class="jp-agent-notebook-explain-cancel-btn" style="
          background: transparent;
          color: #616161;
          border: 1px solid #d1d5db;
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">취소</button>
        <button class="jp-agent-notebook-explain-submit-btn" style="
          background: #1976d2;
          color: white;
          border: 1px solid #1976d2;
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">확인</button>
      </div>
    `;
        dialogOverlay.appendChild(dialogContainer);
        document.body.appendChild(dialogOverlay);
        const cancelBtn = dialogContainer.querySelector('.jp-agent-notebook-explain-cancel-btn');
        const submitBtn = dialogContainer.querySelector('.jp-agent-notebook-explain-submit-btn');
        cancelBtn.addEventListener('click', () => {
            dialogOverlay.remove();
            resolve(false);
        });
        cancelBtn.addEventListener('mouseenter', () => {
            cancelBtn.style.background = '#f5f5f5';
        });
        cancelBtn.addEventListener('mouseleave', () => {
            cancelBtn.style.background = 'transparent';
        });
        submitBtn.addEventListener('click', () => {
            submitBtn.disabled = true;
            submitBtn.textContent = '처리 중...';
            setTimeout(() => {
                dialogOverlay.remove();
                resolve(true);
            }, 100);
        });
        submitBtn.addEventListener('mouseenter', () => {
            if (!submitBtn.disabled) {
                submitBtn.style.background = '#1565c0';
            }
        });
        submitBtn.addEventListener('mouseleave', () => {
            if (!submitBtn.disabled) {
                submitBtn.style.background = '#1976d2';
            }
        });
        const handleEsc = (e) => {
            if (e.key === 'Escape') {
                dialogOverlay.remove();
                document.removeEventListener('keydown', handleEsc);
                resolve(false);
            }
        };
        document.addEventListener('keydown', handleEsc);
        dialogOverlay.addEventListener('click', (e) => {
            if (e.target === dialogOverlay) {
                dialogOverlay.remove();
                document.removeEventListener('keydown', handleEsc);
                resolve(false);
            }
        });
    });
}
// --- Plugin ---
function addSummaryButton(app, panel) {
    // 중복 방지: 이미 버튼이 있으면 스킵
    const existingNames = Array.from(panel.toolbar.names());
    if (existingNames.includes(BUTTON_NAME)) {
        return;
    }
    const button = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ToolbarButton({
        icon: explainIcon,
        tooltip: '노트북 설명하기 (HDSP Agent)',
        onClick: async () => {
            const confirmed = await showConfirmDialog();
            if (!confirmed) {
                return;
            }
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_3__.AnalyticsService.getInstance().trackClick('notebook_explain');
            const agentPanel = window._hdspAgentPanel;
            if (!agentPanel) {
                console.error('[NotebookToolbarPlugin] AgentPanel not available');
                return;
            }
            app.shell.activateById('hdsp-agent-panel');
            agentPanel.sendNotebookMessage('설명해줘');
        },
    });
    // 저장 버튼 바로 다음에 삽입, fallback으로 index 1
    const inserted = panel.toolbar.insertAfter('save', BUTTON_NAME, button);
    if (!inserted) {
        panel.toolbar.insertItem(1, BUTTON_NAME, button);
    }
    // Force repaint to prevent toolbar buttons from disappearing after refresh
    requestAnimationFrame(() => {
        panel.toolbar.node.style.display = 'none';
        panel.toolbar.node.offsetHeight; // trigger reflow
        panel.toolbar.node.style.display = '';
    });
}
const notebookToolbarPlugin = {
    id: '@hdsp-agent/notebook-toolbar',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    activate: (app, notebookTracker) => {
        console.log('[NotebookToolbarPlugin] Activated');
        // 이미 열려있는 노트북에 버튼 추가
        notebookTracker.forEach((panel) => {
            addSummaryButton(app, panel);
        });
        // 새로 열리는 노트북에 버튼 추가
        notebookTracker.widgetAdded.connect((_sender, panel) => {
            addSummaryButton(app, panel);
        });
    },
};


/***/ },

/***/ "./lib/plugins/prompt-generation-plugin.js"
/*!*************************************************!*\
  !*** ./lib/plugins/prompt-generation-plugin.js ***!
  \*************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   promptGenerationPlugin: () => (/* binding */ promptGenerationPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/docmanager */ "webpack/sharing/consume/default/@jupyterlab/docmanager");
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @mui/material */ "webpack/sharing/consume/default/@mui/material/@mui/material");
/* harmony import */ var _components_PromptGenerationDialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/PromptGenerationDialog */ "./lib/components/PromptGenerationDialog.js");
/* harmony import */ var _components_TaskProgressWidget__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../components/TaskProgressWidget */ "./lib/components/TaskProgressWidget.js");
/* harmony import */ var _services_TaskService__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../services/TaskService */ "./lib/services/TaskService.js");
/* harmony import */ var _services_ApiService__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../services/ApiService */ "./lib/services/ApiService.js");
/* harmony import */ var _logoSvg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../logoSvg */ "./lib/logoSvg.js");
/* harmony import */ var _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../services/AnalyticsService */ "./lib/services/AnalyticsService.js");
/**
 * Prompt Generation Plugin - 프롬프트 생성 플러그인
 * Jupyter Launcher에 "프롬프트 생성" 추가
 */













/**
 * 플러그인 상수
 */
const PLUGIN_ID = '@hdsp-agent/prompt-generation';
const COMMAND_ID = 'hdsp-agent:generate-from-prompt';
const CATEGORY = 'Codebuff';
/**
 * Codebuff 아이콘
 */
const hdspIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.LabIcon({
    name: 'hdsp-agent:hdsp-icon',
    svgstr: _logoSvg__WEBPACK_IMPORTED_MODULE_11__.tabbarLogoSvg
});
/**
 * Task Manager Widget - 작업 관리 위젯
 * 활성 노트북 생성 작업 관리
 */
class TaskManagerWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(app, docManager) {
        super();
        this.app = app;
        this.docManager = docManager;
        this.taskService = new _services_TaskService__WEBPACK_IMPORTED_MODULE_9__.TaskService();
        this.activeTasks = new Map();
        this.addClass('jp-TaskManagerWidget');
    }
    /**
     * Start a new notebook generation task
     */
    async startGeneration(prompt) {
        try {
            // Start generation
            const response = await this.taskService.generateNotebook({ prompt });
            const taskId = response.taskId;
            // Subscribe to progress
            this.taskService.subscribeToTaskProgress(taskId, (status) => {
                this.activeTasks.set(taskId, status);
                this.update();
                // Show notification on completion
                if (status.status === 'completed' && status.notebookPath) {
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.success(`노트북 생성 완료: ${status.notebookPath.split('/').pop()}`, {
                        autoClose: 5000
                    });
                }
                else if (status.status === 'failed') {
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error(`노트북 생성 실패: ${status.error}`, {
                        autoClose: 10000
                    });
                }
            }, (error) => {
                console.error('Task progress error:', error);
                _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error('진행상황 연결 실패', { autoClose: 5000 });
            }, () => {
                // Task completed, keep in list for user to review
                this.update();
            });
            // Show initial notification
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.info('노트북 생성을 시작했습니다', { autoClose: 3000 });
            this.update();
        }
        catch (error) {
            console.error('Failed to start generation:', error);
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__.AnalyticsService.getInstance().trackError('notebook_gen_error', { error: error.message });
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error(`생성 시작 실패: ${error.message}`, {
                autoClose: 5000
            });
        }
    }
    /**
     * Cancel a task
     */
    async cancelTask(taskId) {
        try {
            await this.taskService.cancelTask(taskId);
            this.activeTasks.delete(taskId);
            this.update();
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.info('작업을 취소했습니다', { autoClose: 3000 });
        }
        catch (error) {
            console.error('Failed to cancel task:', error);
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error(`취소 실패: ${error.message}`, { autoClose: 5000 });
        }
    }
    /**
     * Close/remove task from display
     */
    closeTask(taskId) {
        this.taskService.unsubscribeFromTask(taskId);
        this.activeTasks.delete(taskId);
        this.update();
    }
    /**
     * Open generated notebook
     */
    async openNotebook(notebookPath, taskId) {
        try {
            // Extract just the filename from the path
            const filename = notebookPath.split('/').pop() || notebookPath;
            // Open the notebook
            await this.docManager.openOrReveal(filename);
            // Close the task widget after opening
            this.closeTask(taskId);
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.success(`노트북을 열었습니다: ${filename}`, {
                autoClose: 3000
            });
        }
        catch (error) {
            console.error('Failed to open notebook:', error);
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Notification.error(`노트북 열기 실패: ${error.message}`, {
                autoClose: 5000
            });
        }
    }
    render() {
        const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.createTheme)();
        const tasks = Array.from(this.activeTasks.entries());
        return (react__WEBPACK_IMPORTED_MODULE_5___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_6__.ThemeProvider, { theme: theme },
            react__WEBPACK_IMPORTED_MODULE_5___default().createElement("div", { style: { position: 'fixed', bottom: 0, right: 0, zIndex: 1300 } }, tasks.map(([taskId, status], index) => (react__WEBPACK_IMPORTED_MODULE_5___default().createElement("div", { key: taskId, style: {
                    marginBottom: index < tasks.length - 1 ? '10px' : '0'
                } },
                react__WEBPACK_IMPORTED_MODULE_5___default().createElement(_components_TaskProgressWidget__WEBPACK_IMPORTED_MODULE_8__.TaskProgressWidget, { taskStatus: status, onClose: () => this.closeTask(taskId), onCancel: () => this.cancelTask(taskId), onOpenNotebook: () => status.notebookPath &&
                        this.openNotebook(status.notebookPath, taskId) })))))));
    }
    dispose() {
        this.taskService.dispose();
        super.dispose();
    }
}
/**
 * Dialog Widget for prompt input
 */
class PromptDialogWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(onGenerate, onClose) {
        super();
        this._onGenerate = onGenerate;
        this._onClose = onClose;
        this._apiService = new _services_ApiService__WEBPACK_IMPORTED_MODULE_10__.ApiService();
    }
    render() {
        const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.createTheme)();
        return (react__WEBPACK_IMPORTED_MODULE_5___default().createElement(_mui_material__WEBPACK_IMPORTED_MODULE_6__.ThemeProvider, { theme: theme },
            react__WEBPACK_IMPORTED_MODULE_5___default().createElement(_components_PromptGenerationDialog__WEBPACK_IMPORTED_MODULE_7__.PromptGenerationDialog, { open: true, onClose: this._onClose, onGenerate: this._onGenerate, apiService: this._apiService })));
    }
}
/**
 * Prompt Generation Plugin
 */
const promptGenerationPlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_2__.IDocumentManager],
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__.ILauncher, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    activate: (app, docManager, launcher, palette) => {
        console.log('[PromptGenerationPlugin] Activating');
        try {
            // Create task manager widget
            const taskManager = new TaskManagerWidget(app, docManager);
            taskManager.id = 'hdsp-agent-task-manager';
            taskManager.title.label = 'Task Manager';
            // Add to shell but keep it as a floating overlay (not in main area)
            // The widget renders itself as a fixed position element
            _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__.Widget.attach(taskManager, document.body);
            // Add command
            app.commands.addCommand(COMMAND_ID, {
                label: '노트북 자동생성',
                caption: '노트북 자동생성',
                icon: hdspIcon,
                execute: (args) => {
                    const directPrompt = args?.prompt;
                    // If prompt is provided directly (e.g. from /create-notebook), skip dialog
                    if (directPrompt) {
                        taskManager.startGeneration(directPrompt);
                        return;
                    }
                    // Create dialog widget
                    let dialogWidget = null;
                    const onGenerate = async (prompt) => {
                        if (dialogWidget) {
                            dialogWidget.dispose();
                            dialogWidget = null;
                        }
                        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__.AnalyticsService.getInstance().trackClick('notebook_gen', { prompt });
                        await taskManager.startGeneration(prompt);
                    };
                    const onClose = () => {
                        if (dialogWidget) {
                            dialogWidget.dispose();
                            dialogWidget = null;
                        }
                    };
                    dialogWidget = new PromptDialogWidget(onGenerate, onClose);
                    dialogWidget.id = 'hdsp-agent-prompt-dialog';
                    dialogWidget.title.label = '';
                    app.shell.add(dialogWidget, 'main');
                    _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_12__.AnalyticsService.getInstance().trackImpression('notebook_gen_dialog');
                }
            });
            // Add to launcher
            if (launcher) {
                launcher.add({
                    command: COMMAND_ID,
                    category: CATEGORY,
                    rank: 0
                });
            }
            // Add to command palette
            if (palette) {
                palette.addItem({
                    command: COMMAND_ID,
                    category: CATEGORY
                });
            }
            console.log('[PromptGenerationPlugin] Activated successfully');
        }
        catch (error) {
            console.error('[PromptGenerationPlugin] Failed to activate:', error);
        }
    }
};


/***/ },

/***/ "./lib/plugins/rag-admin-plugin.js"
/*!*****************************************!*\
  !*** ./lib/plugins/rag-admin-plugin.js ***!
  \*****************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ragAdminPlugin: () => (/* binding */ ragAdminPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_RAGSettingsPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../components/RAGSettingsPanel */ "./lib/components/RAGSettingsPanel.js");
/* harmony import */ var _components_RAGLoadPanel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/RAGLoadPanel */ "./lib/components/RAGLoadPanel.js");
/* harmony import */ var _components_RAGBrowserPanel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/RAGBrowserPanel */ "./lib/components/RAGBrowserPanel.js");
/**
 * RAG Admin Plugin — 런처에 3개 RAG 아이템 추가 (Admin 전용).
 *
 * 1. RAG 설정 — Qdrant, 임베딩, 청킹 설정
 * 2. RAG 적재 — 컬렉션별 적재, 변환, 이력
 * 3. 데이터 탐색 — 브라우저, 검색 테스트
 */







const PLUGIN_ID = 'hdsp-agent:rag-admin';
const CATEGORY = 'Codebuff';
// Icons
const settingsIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.49.49 0 0 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.07.62-.07.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6A3.6 3.6 0 1 1 12 8.4a3.6 3.6 0 0 1 0 7.2z"/></svg>`;
const loadIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>`;
const browseIconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><path d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/></svg>`;
const settingsIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({ name: 'hdsp-agent:rag-settings', svgstr: settingsIconSvg });
const loadIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({ name: 'hdsp-agent:rag-load', svgstr: loadIconSvg });
const browseIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.LabIcon({ name: 'hdsp-agent:rag-browse', svgstr: browseIconSvg });
// Widget definitions
const items = [
    {
        commandId: 'hdsp-agent:open-rag-settings',
        widgetId: 'hdsp-agent-rag-settings',
        label: 'RAG 설정',
        caption: 'Qdrant, 임베딩, 청킹 설정',
        icon: settingsIcon,
        rank: 1,
        Component: _components_RAGSettingsPanel__WEBPACK_IMPORTED_MODULE_4__.RAGSettingsPanel,
    },
    {
        commandId: 'hdsp-agent:open-rag-load',
        widgetId: 'hdsp-agent-rag-load',
        label: 'RAG 적재',
        caption: '컬렉션 데이터 적재 및 변환',
        icon: loadIcon,
        rank: 2,
        Component: _components_RAGLoadPanel__WEBPACK_IMPORTED_MODULE_5__.RAGLoadPanel,
    },
    {
        commandId: 'hdsp-agent:open-rag-browser',
        widgetId: 'hdsp-agent-rag-browser',
        label: '데이터 탐색',
        caption: '데이터 브라우저 및 검색 테스트',
        icon: browseIcon,
        rank: 3,
        Component: _components_RAGBrowserPanel__WEBPACK_IMPORTED_MODULE_6__.RAGBrowserPanel,
    },
];
function makeWidget(id, label, Component) {
    const widget = new (class extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.ReactWidget {
        constructor() {
            super();
            this.id = id;
            this.title.label = label;
            this.title.closable = true;
            this.addClass('jp-rag-admin-widget');
        }
        render() {
            return react__WEBPACK_IMPORTED_MODULE_3___default().createElement(Component, { onClose: () => this.dispose() });
        }
    })();
    return widget;
}
const ragAdminPlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    optional: [_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_0__.ILauncher, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    activate: (app, launcher, palette) => {
        console.log('[RAGAdminPlugin] Activating (3 panels)');
        let isAdmin = null;
        const checkAdmin = async () => {
            if (isAdmin !== null)
                return isAdmin;
            try {
                const resp = await fetch(`${app.serviceManager?.serverSettings?.baseUrl || ''}hdsp-agent/config/is-admin`);
                const data = await resp.json();
                isAdmin = data.isAdmin === true;
            }
            catch {
                isAdmin = true;
            }
            return isAdmin;
        };
        for (const item of items) {
            app.commands.addCommand(item.commandId, {
                label: item.label,
                caption: item.caption,
                icon: item.icon,
                execute: async () => {
                    const admin = await checkAdmin();
                    if (!admin)
                        return;
                    // 기존 위젯 활성화
                    const existing = app.shell.widgets('main');
                    let w = existing.next();
                    while (w && !w.done) {
                        if (w.value?.id === item.widgetId) {
                            app.shell.activateById(item.widgetId);
                            return;
                        }
                        w = existing.next();
                    }
                    const widget = makeWidget(item.widgetId, item.label, item.Component);
                    app.shell.add(widget, 'main');
                },
            });
            if (palette) {
                palette.addItem({ command: item.commandId, category: CATEGORY });
            }
        }
        if (launcher) {
            checkAdmin().then(admin => {
                if (!admin)
                    return;
                for (const item of items) {
                    launcher.add({ command: item.commandId, category: CATEGORY, rank: item.rank });
                }
            });
        }
        console.log('[RAGAdminPlugin] Activated');
    },
};


/***/ },

/***/ "./lib/plugins/save-interceptor-plugin.js"
/*!************************************************!*\
  !*** ./lib/plugins/save-interceptor-plugin.js ***!
  \************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   collectAllCodeCells: () => (/* binding */ collectAllCodeCells),
/* harmony export */   saveInterceptorPlugin: () => (/* binding */ saveInterceptorPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/AnalyticsService */ "./lib/services/AnalyticsService.js");
/**
 * Save Interceptor Plugin - 저장 인터셉터 플러그인
 * 노트북 저장 작업을 가로채어 저장 전 코드 리뷰 제공
 * chrome_agent의 저장 인터셉션 기능 기반
 */



/**
 * Track cell attribution — count agent-produced vs user-produced cells on save
 */
function trackCellAttribution(widget) {
    try {
        const content = widget?.content;
        if (!content?.widgets)
            return;
        let totalCodeCells = 0;
        let agentCreatedCells = 0;
        let agentModifiedCells = 0;
        let agentPastedCells = 0;
        let totalMarkdownCells = 0;
        let agentMarkdownCells = 0;
        for (let i = 0; i < content.widgets.length; i++) {
            const cell = content.widgets[i];
            if (!cell?.model)
                continue;
            const cellType = cell.model.type;
            let agentSource;
            try {
                agentSource = typeof cell.model.metadata?.get === 'function'
                    ? cell.model.metadata.get('hdsp_agent_source')
                    : cell.model.metadata?.hdsp_agent_source;
            }
            catch { /* ignore */ }
            if (cellType === 'code') {
                totalCodeCells++;
                if (agentSource === 'created')
                    agentCreatedCells++;
                else if (agentSource === 'modified')
                    agentModifiedCells++;
                else if (agentSource === 'pasted')
                    agentPastedCells++;
            }
            else if (cellType === 'markdown') {
                totalMarkdownCells++;
                if (agentSource)
                    agentMarkdownCells++;
            }
        }
        if (totalCodeCells === 0)
            return;
        const agentCodeRatio = Math.round(((agentCreatedCells + agentModifiedCells + agentPastedCells) / totalCodeCells) * 10000) / 100;
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackImpression('cell_attribution', {
            total_code_cells: totalCodeCells,
            agent_created_code_cells: agentCreatedCells,
            agent_modified_code_cells: agentModifiedCells,
            agent_pasted_code_cells: agentPastedCells,
            agent_code_ratio_pct: agentCodeRatio,
            total_markdown_cells: totalMarkdownCells,
            agent_markdown_cells: agentMarkdownCells,
        });
    }
    catch { /* silent - non-critical */ }
}
/**
 * 저장 인터셉터 플러그인
 */
const saveInterceptorPlugin = {
    id: '@hdsp-agent/save-interceptor',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker],
    optional: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette],
    activate: (app, notebookTracker, palette) => {
        console.log('[SaveInterceptorPlugin] Activated');
        let isSaving = false;
        let originalSaveCommand = null;
        // Store original save command and wrap it
        if (app.commands.hasCommand('docmanager:save')) {
            console.log('[SaveInterceptorPlugin] Found docmanager:save command');
            const commandRegistry = app.commands;
            const commandId = 'docmanager:save';
            // Get the original command's execute function
            const originalCommand = commandRegistry._commands.get(commandId);
            if (originalCommand) {
                originalSaveCommand = originalCommand.execute.bind(originalCommand);
                console.log('[SaveInterceptorPlugin] Stored original save command');
                // Replace the execute function
                originalCommand.execute = async (args) => {
                    // Use app.shell.currentWidget to get the actually focused widget
                    const currentWidget = app.shell.currentWidget;
                    console.log('[SaveInterceptorPlugin] Save command triggered', {
                        hasCurrentWidget: !!currentWidget,
                        isSaving: isSaving,
                        widgetType: currentWidget?.constructor?.name
                    });
                    // Only intercept for Python files (.ipynb, .py)
                    if (!currentWidget) {
                        console.log('[SaveInterceptorPlugin] No current widget, allowing default save');
                        return originalSaveCommand(args);
                    }
                    // Check if the current widget has a context (is a document)
                    const context = currentWidget.context;
                    if (!context) {
                        console.log('[SaveInterceptorPlugin] No context, allowing default save');
                        return originalSaveCommand(args);
                    }
                    // Check if the current document is a Python file
                    const path = context?.path || '';
                    const isPythonFile = path.endsWith('.ipynb') || path.endsWith('.py');
                    if (!isPythonFile) {
                        console.log('[SaveInterceptorPlugin] Not a Python file, allowing default save', { path });
                        return originalSaveCommand(args);
                    }
                    if (isSaving) {
                        console.log('[SaveInterceptorPlugin] Already in save process, executing actual save');
                        return originalSaveCommand(args);
                    }
                    console.log('[SaveInterceptorPlugin] Python file save, showing dialog', { path });
                    trackCellAttribution(currentWidget);
                    isSaving = true;
                    try {
                        await handleSaveIntercept(currentWidget, app, originalSaveCommand, args, () => { isSaving = true; }, () => { isSaving = false; });
                    }
                    finally {
                        isSaving = false;
                    }
                };
                console.log('[SaveInterceptorPlugin] Wrapped save command installed');
            }
            else {
                console.error('[SaveInterceptorPlugin] Could not find original save command');
            }
        }
        // Also intercept keyboard shortcut as backup
        document.addEventListener('keydown', async (e) => {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                // Use app.shell.currentWidget instead of notebookTracker to get the actually focused widget
                const currentWidget = app.shell.currentWidget;
                if (!currentWidget) {
                    return; // Not in a document, let default save happen
                }
                // Check if the current widget has a context (is a document)
                const context = currentWidget.context;
                if (!context) {
                    return; // Not a document widget, let default save happen
                }
                // Check if the current document is a Python file
                const path = context?.path || '';
                const isPythonFile = path.endsWith('.ipynb') || path.endsWith('.py');
                if (!isPythonFile) {
                    console.log('[SaveInterceptorPlugin] Not a Python file, allowing default save', { path });
                    return; // Not a Python file, let default save happen
                }
                console.log('[SaveInterceptorPlugin] Save shortcut (Ctrl/Cmd+S) detected for Python file', { path });
                e.preventDefault();
                e.stopPropagation();
                if (isSaving) {
                    console.log('[SaveInterceptorPlugin] Already saving, ignoring duplicate request');
                    return;
                }
                if (!originalSaveCommand) {
                    console.error('[SaveInterceptorPlugin] No original save command stored');
                    return;
                }
                trackCellAttribution(currentWidget);
                await originalSaveCommand();
            }
        }, true); // Use capture phase to intercept before JupyterLab
        console.log('[SaveInterceptorPlugin] Save interception enabled');
    }
};
/**
 * Handle save intercept - show modal and collect cells if needed
 */
async function handleSaveIntercept(panel, app, originalSaveCommand, args, setSaving, clearSaving) {
    // Show confirmation modal
    const shouldAnalyze = await showSaveConfirmModal();
    if (shouldAnalyze === null) {
        // User cancelled
        clearSaving();
        return;
    }
    if (shouldAnalyze) {
        // Code review only (no save)
        await performAnalysis(panel, app);
    }
    else {
        // Direct save without analysis
        await performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving);
    }
}
/**
 * Show save confirmation modal
 * Returns: true for analysis, false for direct save, null for cancel
 */
function showSaveConfirmModal() {
    return new Promise((resolve) => {
        // Remove existing modal if any
        const existingModal = document.querySelector('.jp-agent-save-confirm-modal');
        if (existingModal) {
            existingModal.remove();
        }
        // Create modal overlay
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'jp-agent-save-confirm-modal';
        modalOverlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.3);
      z-index: 10000;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
        // Create modal container
        const modalContainer = document.createElement('div');
        modalContainer.style.cssText = `
      background: var(--jp-layout-color1);
      border: 1px solid var(--jp-border-color1);
      border-radius: 4px;
      padding: 24px;
      max-width: 400px;
      width: 90%;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      font-family: var(--jp-ui-font-family);
    `;
        // Modal content
        modalContainer.innerHTML = `
      <div style="margin-bottom: 20px;">
        <h3 style="margin: 0 0 12px 0; color: var(--jp-ui-font-color1); font-size: 16px; font-weight: 500;">
          저장 또는 코드리뷰를 선택하세요
        </h3>
        <p style="margin: 0; color: var(--jp-ui-font-color2); font-size: 14px; line-height: 1.5;">
          코드리뷰는 모든 셀의 코드와 출력을 분석합니다.
        </p>
      </div>
      <div style="display: flex; gap: 12px; justify-content: flex-end;">
        <button class="jp-agent-save-cancel-btn" style="
          background: transparent;
          color: var(--jp-ui-font-color2);
          border: 1px solid var(--jp-border-color2);
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">취소</button>
        <button class="jp-agent-save-direct-btn" style="
          background: transparent;
          color: var(--jp-ui-font-color1);
          border: 1px solid var(--jp-border-color2);
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">저장</button>
        <button class="jp-agent-save-analysis-btn" style="
          background: var(--jp-brand-color1);
          color: white;
          border: 1px solid var(--jp-brand-color1);
          border-radius: 3px;
          padding: 8px 16px;
          font-size: 13px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.15s ease;
        ">코드리뷰</button>
      </div>
    `;
        modalOverlay.appendChild(modalContainer);
        document.body.appendChild(modalOverlay);
        _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackImpression('save_review_modal');
        // Button event listeners
        const cancelBtn = modalContainer.querySelector('.jp-agent-save-cancel-btn');
        const directSaveBtn = modalContainer.querySelector('.jp-agent-save-direct-btn');
        const analysisSaveBtn = modalContainer.querySelector('.jp-agent-save-analysis-btn');
        // Cancel button
        cancelBtn.addEventListener('click', () => {
            console.log('[SaveInterceptorPlugin] User cancelled save');
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackClick('save_cancel');
            modalOverlay.remove();
            resolve(null);
        });
        cancelBtn.addEventListener('mouseenter', () => {
            cancelBtn.style.background = 'var(--jp-layout-color2)';
        });
        cancelBtn.addEventListener('mouseleave', () => {
            cancelBtn.style.background = 'transparent';
        });
        // Direct save button
        directSaveBtn.addEventListener('click', () => {
            console.log('[SaveInterceptorPlugin] User chose direct save');
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackClick('save_direct');
            modalOverlay.remove();
            resolve(false);
        });
        directSaveBtn.addEventListener('mouseenter', () => {
            directSaveBtn.style.background = 'var(--jp-layout-color2)';
        });
        directSaveBtn.addEventListener('mouseleave', () => {
            directSaveBtn.style.background = 'transparent';
        });
        // Analysis save button
        analysisSaveBtn.addEventListener('click', () => {
            console.log('[SaveInterceptorPlugin] User chose analysis save');
            _services_AnalyticsService__WEBPACK_IMPORTED_MODULE_2__.AnalyticsService.getInstance().trackClick('save_review');
            modalOverlay.remove();
            resolve(true);
        });
        analysisSaveBtn.addEventListener('mouseenter', () => {
            analysisSaveBtn.style.opacity = '0.9';
        });
        analysisSaveBtn.addEventListener('mouseleave', () => {
            analysisSaveBtn.style.opacity = '1';
        });
        // Close on overlay click
        modalOverlay.addEventListener('click', (e) => {
            if (e.target === modalOverlay) {
                console.log('[SaveInterceptorPlugin] User cancelled save');
                modalOverlay.remove();
                resolve(null);
            }
        });
        // ESC key to close
        const handleEscapeKey = (e) => {
            if (e.key === 'Escape') {
                console.log('[SaveInterceptorPlugin] User cancelled save with ESC');
                modalOverlay.remove();
                document.removeEventListener('keydown', handleEscapeKey);
                resolve(null);
            }
        };
        document.addEventListener('keydown', handleEscapeKey);
    });
}
/**
 * Perform direct save without analysis
 */
async function performDirectSave(panel, app, originalSaveCommand, args, setSaving, clearSaving) {
    console.log('[SaveInterceptorPlugin] Performing direct save');
    setSaving();
    try {
        // Use the original save command
        if (originalSaveCommand) {
            await originalSaveCommand(args);
        }
        else {
            // Fallback: Use JupyterLab's document manager to save
            const context = panel.context;
            if (context) {
                await context.save();
            }
        }
    }
    catch (error) {
        console.error('[SaveInterceptorPlugin] Save failed:', error);
        showNotification('저장에 실패했습니다.', 'error');
    }
    finally {
        clearSaving();
    }
}
/**
 * Perform code review only (no save)
 */
async function performAnalysis(panel, app) {
    console.log('[SaveInterceptorPlugin] Performing code review');
    try {
        const agentPanel = window._hdspAgentPanel;
        if (!agentPanel) {
            console.error('[SaveInterceptorPlugin] Agent panel not available');
            return;
        }
        // Activate the sidebar panel
        if (app) {
            app.shell.activateById(agentPanel.id);
        }
        const path = panel?.context?.path || '';
        if (path.endsWith('.ipynb')) {
            // 노트북: 기존 흐름
            if (!agentPanel.analyzeNotebook) {
                console.error('[SaveInterceptorPlugin] analyzeNotebook not available');
                return;
            }
            const serverSettings = app?.serviceManager?.serverSettings;
            const cells = await collectAllCodeCells(panel, serverSettings, path);
            if (cells.length === 0) {
                console.log('[SaveInterceptorPlugin] No code cells to analyze');
                return;
            }
            agentPanel.analyzeNotebook(cells, () => {
                console.log('[SaveInterceptorPlugin] Code review complete');
            });
        }
        else {
            // 일반 파일: analyzeFile 호출
            if (!agentPanel.analyzeFile) {
                console.error('[SaveInterceptorPlugin] analyzeFile not available');
                return;
            }
            agentPanel.analyzeFile(path, () => {
                console.log('[SaveInterceptorPlugin] File review complete');
            });
        }
    }
    catch (error) {
        console.error('[SaveInterceptorPlugin] Code review failed:', error);
    }
}
/**
 * Collect all code cells with content, output, and imports
 * Based on chrome_agent's collectAllCodeCells implementation
 */
async function collectAllCodeCells(panel, serverSettings, notebookPath) {
    const notebook = panel.content;
    const cells = [];
    for (let i = 0; i < notebook.widgets.length; i++) {
        const cell = notebook.widgets[i];
        // Only collect code cells - null safety 추가
        if (!cell?.model || cell.model.type !== 'code') {
            continue;
        }
        const content = cell.model.sharedModel?.getSource() || '';
        if (!content.trim()) {
            continue;
        }
        // Get or assign cell ID
        const cellId = getOrAssignCellId(cell);
        // Extract output
        const output = getCellOutput(cell);
        // Extract imports
        const imports = extractImports(content);
        cells.push({
            index: i,
            id: cellId,
            content: content,
            type: 'code',
            output: output,
            imports: imports
        });
    }
    console.log(`[SaveInterceptorPlugin] Collected ${cells.length} code cells`);
    // Enrich cells via backend AST analysis + local module resolution
    if (serverSettings && cells.length > 0) {
        try {
            const enrichUrl = `${serverSettings.baseUrl}hdsp-agent/notebook/enrich`;
            const headers = { 'Content-Type': 'application/json' };
            if (serverSettings.token) {
                headers['Authorization'] = `token ${serverSettings.token}`;
            }
            const xsrfCookie = document.cookie
                .split('; ')
                .find(c => c.startsWith('_xsrf='));
            if (xsrfCookie) {
                headers['X-XSRFToken'] = xsrfCookie.split('=')[1];
            }
            const response = await fetch(enrichUrl, {
                method: 'POST',
                headers,
                body: JSON.stringify({
                    notebookPath: notebookPath || '',
                    cells: cells.map(c => ({ index: c.index, content: c.content }))
                })
            });
            if (response.ok) {
                const enriched = await response.json();
                // Merge enriched data into cells
                for (const ec of enriched.cells || []) {
                    const cell = cells.find(c => c.index === ec.index);
                    if (cell) {
                        if (ec.localModuleSources && Object.keys(ec.localModuleSources).length > 0) {
                            cell.localModuleSources = ec.localModuleSources;
                        }
                        if (ec.dependencies) {
                            cell.dependencies = ec.dependencies;
                        }
                    }
                }
                // Attach cross-cell metadata
                cells._crossCellDeps = enriched.crossCellDependencies || [];
                cells._moduleSummary = enriched.moduleSummary || {};
                cells._transitiveModuleSources = enriched.transitiveModuleSources || {};
            }
        }
        catch (e) {
            console.warn('[SaveInterceptorPlugin] Enrich API failed, continuing without enrichment:', e);
        }
    }
    return cells;
}
/**
 * Get or assign cell ID to a cell
 */
function getOrAssignCellId(cell) {
    const cellModel = cell.model;
    let cellId;
    // Try to get cell ID from metadata
    try {
        if (cellModel.metadata && typeof cellModel.metadata.get === 'function') {
            cellId = cellModel.metadata.get('jupyterAgentCellId');
        }
        else if (cellModel.metadata?.jupyterAgentCellId) {
            cellId = cellModel.metadata.jupyterAgentCellId;
        }
    }
    catch (e) {
        // Ignore errors
    }
    if (!cellId) {
        cellId = `cell-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        // Try to set cell ID in metadata
        try {
            if (cellModel.metadata && typeof cellModel.metadata.set === 'function') {
                cellModel.metadata.set('jupyterAgentCellId', cellId);
            }
            else if (cellModel.metadata) {
                cellModel.metadata.jupyterAgentCellId = cellId;
            }
        }
        catch (e) {
            // Ignore errors
        }
    }
    return cellId;
}
/**
 * Extract output from a code cell
 */
function getCellOutput(cell) {
    // cell.model이 null일 수 있으므로 안전하게 체크
    if (!cell?.model || cell.model.type !== 'code') {
        return '';
    }
    const codeCell = cell;
    const outputs = codeCell.model?.outputs;
    if (!outputs || outputs.length === 0) {
        return '';
    }
    const outputTexts = [];
    for (let i = 0; i < outputs.length; i++) {
        const output = outputs.get(i);
        const outputType = output.type;
        if (outputType === 'stream') {
            // stdout, stderr
            const text = output.text;
            if (Array.isArray(text)) {
                outputTexts.push(text.join(''));
            }
            else {
                outputTexts.push(text);
            }
        }
        else if (outputType === 'execute_result' || outputType === 'display_data') {
            // Execution results or display data
            const data = output.data;
            if (data['text/plain']) {
                const text = data['text/plain'];
                if (Array.isArray(text)) {
                    outputTexts.push(text.join(''));
                }
                else {
                    outputTexts.push(text);
                }
            }
        }
        else if (outputType === 'error') {
            // Error output
            const traceback = output.traceback;
            if (Array.isArray(traceback)) {
                outputTexts.push(traceback.join('\n'));
            }
        }
    }
    return outputTexts.join('\n');
}
/**
 * Extract imports from Python code
 * Based on chrome_agent's extractImports implementation
 */
function extractImports(cellContent) {
    const imports = [];
    const lines = cellContent.split('\n');
    for (const line of lines) {
        const trimmed = line.trim();
        // Skip comments and empty lines
        if (trimmed.startsWith('#') || trimmed === '')
            continue;
        // Relative import: from . import ... or from .. import ...
        const relativeMatch = trimmed.match(/^from\s+(\.+[\w.]*)\s+import\s+([\w,\s*]+)/);
        if (relativeMatch) {
            imports.push({
                module: relativeMatch[1],
                items: relativeMatch[2],
                isLocal: true
            });
            continue;
        }
        // from X import Y form
        const fromImportMatch = trimmed.match(/^from\s+([\w.]+)\s+import\s+([\w,\s*]+)/);
        if (fromImportMatch) {
            const moduleName = fromImportMatch[1];
            imports.push({
                module: moduleName,
                items: fromImportMatch[2],
                isLocal: isLocalImport(moduleName)
            });
            continue;
        }
        // import X, Y, Z form
        const importMatch = trimmed.match(/^import\s+([\w,\s.]+)/);
        if (importMatch) {
            const modules = importMatch[1].split(',').map(m => m.trim().split(' as ')[0]);
            modules.forEach(moduleName => {
                imports.push({
                    module: moduleName,
                    items: moduleName,
                    isLocal: isLocalImport(moduleName)
                });
            });
        }
    }
    return imports;
}
/**
 * Determine if a module import is local (not a standard library)
 */
function isLocalImport(moduleName) {
    // Relative paths are always local
    if (moduleName.startsWith('.')) {
        return true;
    }
    // Common Python libraries (not exhaustive)
    const commonLibraries = [
        'numpy', 'np', 'pandas', 'pd', 'matplotlib', 'sklearn', 'scipy',
        'torch', 'tensorflow', 'tf', 'keras', 'PIL', 'cv2', 'requests',
        'json', 'os', 'sys', 'datetime', 'time', 'math', 'random',
        'collections', 'itertools', 'functools', 're', 'pathlib',
        'typing', 'dataclasses', 'abc', 'argparse', 'logging',
        'pickle', 'csv', 'sqlite3', 'http', 'urllib', 'email',
        'plotly', 'seaborn', 'statsmodels', 'xgboost', 'lightgbm',
        'transformers', 'datasets', 'accelerate', 'peft',
        'openai', 'anthropic', 'langchain', 'llama_index'
    ];
    // Get top-level module name
    const topLevelModule = moduleName.split('.')[0];
    // If not in common libraries, consider it local
    return !commonLibraries.includes(topLevelModule);
}
/**
 * Get notification background color based on type
 */
function getNotificationColor(type) {
    const colors = {
        success: '#48bb78',
        error: '#f56565',
        warning: '#ed8936',
        info: '#4299e1'
    };
    return colors[type] || colors.info;
}
/**
 * Create notification element with styles
 */
function createNotificationElement(message, backgroundColor) {
    const notification = document.createElement('div');
    notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    border-radius: 8px;
    color: white;
    font-size: 14px;
    font-weight: 500;
    z-index: 10001;
    opacity: 0;
    transition: opacity 0.3s ease;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    max-width: 300px;
    word-wrap: break-word;
    background: ${backgroundColor};
  `;
    notification.textContent = message;
    return notification;
}
/**
 * Animate notification appearance and removal
 */
function animateNotification(notification) {
    // Show animation
    setTimeout(() => {
        notification.style.opacity = '1';
    }, 10);
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}
/**
 * Show notification
 */
function showNotification(message, type = 'info') {
    const notification = createNotificationElement(message, getNotificationColor(type));
    document.body.appendChild(notification);
    animateNotification(notification);
}


/***/ },

/***/ "./lib/plugins/sidebar-plugin.js"
/*!***************************************!*\
  !*** ./lib/plugins/sidebar-plugin.js ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   sidebarPlugin: () => (/* binding */ sidebarPlugin)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_console__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/console */ "webpack/sharing/consume/default/@jupyterlab/console");
/* harmony import */ var _jupyterlab_console__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_console__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/rendermime */ "webpack/sharing/consume/default/@jupyterlab/rendermime");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_AgentPanel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../components/AgentPanel */ "./lib/components/AgentPanel.js");
/* harmony import */ var _services_ApiService__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/ApiService */ "./lib/services/ApiService.js");
/* harmony import */ var _services_AccessControlService__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/AccessControlService */ "./lib/services/AccessControlService.js");
/**
 * Sidebar Plugin - 사이드바 플러그인
 * JupyterLab 사이드바에 Agent 패널 추가
 */








/**
 * Sidebar 플러그인 네임스페이스
 */
const PLUGIN_ID = '@hdsp-agent/sidebar';
const COMMAND_ID = 'hdsp-agent:toggle-sidebar';
/**
 * Agent 사이드바 플러그인
 */
const sidebarPlugin = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [],
    optional: [_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_2__.INotebookTracker, _jupyterlab_console__WEBPACK_IMPORTED_MODULE_3__.IConsoleTracker, _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_4__.IRenderMimeRegistry],
    activate: (app, restorer, palette, notebookTracker, consoleTracker, rmRegistry) => {
        console.log('[SidebarPlugin] Activating Jupyter Agent Sidebar');
        try {
            // Access control check - only show sidebar for allowed teams
            const accessControl = (0,_services_AccessControlService__WEBPACK_IMPORTED_MODULE_7__.getAccessControlService)();
            if (!accessControl.isSidebarAllowed()) {
                const userInfo = accessControl.getUserInfo();
                console.log('[SidebarPlugin] Sidebar hidden for team:', userInfo.team);
                console.log('[SidebarPlugin] User:', userInfo.username, 'is not in allowed teams list');
                return; // Exit without registering sidebar
            }
            console.log('[SidebarPlugin] Access granted for user:', accessControl.getUsername());
            // Create API service
            const apiService = new _services_ApiService__WEBPACK_IMPORTED_MODULE_6__.ApiService();
            // Create agent panel widget with notebook tracker and console tracker
            const agentPanel = new _components_AgentPanel__WEBPACK_IMPORTED_MODULE_5__.AgentPanelWidget(apiService, notebookTracker, consoleTracker);
            // Create tracker for panel state restoration if restorer available
            if (restorer) {
                const tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.WidgetTracker({
                    namespace: 'hdsp-agent'
                });
                // Add panel to tracker
                tracker.add(agentPanel);
                // Restore panel state
                restorer.restore(tracker, {
                    command: COMMAND_ID,
                    name: () => 'hdsp-agent'
                });
            }
            // Add panel to right sidebar
            app.shell.add(agentPanel, 'right', { rank: 100 });
            // Add command to toggle sidebar
            app.commands.addCommand(COMMAND_ID, {
                label: 'Codebuff Agent 사이드바 토글',
                caption: 'Codebuff Agent 패널 표시/숨기기',
                execute: () => {
                    if (agentPanel.isVisible) {
                        agentPanel.close();
                    }
                    else {
                        app.shell.activateById(agentPanel.id);
                    }
                }
            });
            // Add command to palette
            if (palette) {
                palette.addItem({
                    command: COMMAND_ID,
                    category: 'Codebuff Agent',
                    args: {}
                });
            }
            // Store reference globally for cell buttons to access
            window._hdspAgentPanel = agentPanel;
            // Store rendermime registry globally for markdown rendering
            if (rmRegistry) {
                window._hdspRenderMimeRegistry = rmRegistry;
                console.log('[SidebarPlugin] RenderMime registry stored for markdown rendering');
            }
            console.log('[SidebarPlugin] Codebuff Agent Sidebar activated successfully');
        }
        catch (error) {
            console.error('[SidebarPlugin] Failed to activate:', error);
        }
    }
};


/***/ },

/***/ "./lib/services/AccessControlService.js"
/*!**********************************************!*\
  !*** ./lib/services/AccessControlService.js ***!
  \**********************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AccessControlService: () => (/* binding */ AccessControlService),
/* harmony export */   getAccessControlService: () => (/* binding */ getAccessControlService)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/**
 * Access Control Service
 *
 * Provides team-based access control using Keycloak JWT claims.
 * During dog-fooding period, only specific teams have access to the sidebar.
 */

/**
 * List of teams allowed to access the sidebar during dog-fooding period.
 * TODO: Remove this restriction after dog-fooding period ends.
 */
const ALLOWED_TEAMS = ['Cloud개발1팀'];
/**
 * Service for managing user access based on Keycloak team claims
 */
class AccessControlService {
    constructor() {
        this.userInfo = this.loadUserInfo();
    }
    /**
     * Load user information from PageConfig
     */
    loadUserInfo() {
        const username = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getOption('JUPYTERHUB_USER') || '';
        const team = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getOption('HDSP_USER_TEAM') || null;
        const info = {
            username,
            team,
            isAllowed: this.checkAccess(team),
        };
        console.log('[AccessControl] User info loaded:', {
            username: info.username,
            team: info.team,
            isAllowed: info.isAllowed,
        });
        return info;
    }
    /**
     * Check if user has access based on team
     */
    checkAccess(team) {
        // If no team claim is set, allow access by default (development environment)
        if (!team) {
            console.log('[AccessControl] No team claim set, allowing by default (dev mode)');
            return true;
        }
        const isAllowed = ALLOWED_TEAMS.includes(team);
        console.log(`[AccessControl] Team '${team}' access check: ${isAllowed ? 'ALLOWED' : 'DENIED'}`);
        return isAllowed;
    }
    /**
     * Check if sidebar should be displayed for current user
     */
    isSidebarAllowed() {
        return this.userInfo.isAllowed;
    }
    /**
     * Get current user access information
     */
    getUserInfo() {
        return { ...this.userInfo };
    }
    /**
     * Get the username
     */
    getUsername() {
        return this.userInfo.username;
    }
    /**
     * Get the team name
     */
    getTeam() {
        return this.userInfo.team;
    }
}
// Singleton instance
let instance = null;
/**
 * Get the AccessControlService singleton instance
 */
function getAccessControlService() {
    if (!instance) {
        instance = new AccessControlService();
    }
    return instance;
}


/***/ },

/***/ "./lib/services/AnalyticsService.js"
/*!******************************************!*\
  !*** ./lib/services/AnalyticsService.js ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AnalyticsService: () => (/* binding */ AnalyticsService)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/**
 * AnalyticsService - Usage analytics tracking (impression/click/error)
 *
 * Singleton service that buffers events and flushes them to the backend
 * via POST /hdsp-agent/analytics/events. Best-effort: failures are silently dropped.
 *
 * Identity fields (team/project/user_id) are injected server-side by the
 * analytics handler. The frontend always sends events; the backend decides
 * whether to log or discard them (204 when disabled).
 */

const FLUSH_INTERVAL_MS = 30000;
const FLUSH_THRESHOLD = 20;
const SESSION_KEY = 'hdsp-analytics-session-id';
class AnalyticsService {
    constructor() {
        this.buffer = [];
        this.timerId = null;
        const serverRoot = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getBaseUrl();
        this.baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(serverRoot, 'hdsp-agent', 'analytics', 'events');
        this.sessionId = this.getOrCreateSessionId();
        this.version = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getOption('HDSP_EXTENSION_VERSION') || '';
        this.timerId = setInterval(() => this.flush(), FLUSH_INTERVAL_MS);
        if (typeof window !== 'undefined') {
            window.addEventListener('beforeunload', () => {
                this.enqueue('impression', 'session_end', {});
                this.flushBeacon();
            });
        }
        this.enqueue('impression', 'session_start', {});
    }
    static getInstance() {
        if (!AnalyticsService.instance) {
            AnalyticsService.instance = new AnalyticsService();
        }
        return AnalyticsService.instance;
    }
    trackImpression(feature, context) {
        try {
            this.enqueue('impression', feature, context);
        }
        catch {
            // silent fail
        }
    }
    trackClick(feature, context) {
        try {
            this.enqueue('click', feature, context);
        }
        catch {
            // silent fail
        }
    }
    trackError(feature, context) {
        try {
            this.enqueue('error', feature, context);
        }
        catch {
            // silent fail
        }
    }
    enqueue(eventType, feature, context) {
        const event = {
            event_id: crypto.randomUUID(),
            session_id: this.sessionId,
            timestamp: Date.now(),
            event_type: eventType,
            feature,
            extension_version: this.version,
            ...(context ? { context } : {})
        };
        this.buffer.push(event);
        if (this.buffer.length >= FLUSH_THRESHOLD) {
            this.flush();
        }
    }
    flush() {
        if (this.buffer.length === 0)
            return;
        const events = this.buffer.splice(0);
        fetch(this.baseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(events)
        }).catch(() => {
            // silent drop
        });
    }
    flushBeacon() {
        if (this.buffer.length === 0)
            return;
        const events = this.buffer.splice(0);
        const blob = new Blob([JSON.stringify(events)], { type: 'application/json' });
        navigator.sendBeacon(this.baseUrl, blob);
    }
    getOrCreateSessionId() {
        try {
            let id = sessionStorage.getItem(SESSION_KEY);
            if (!id) {
                id = crypto.randomUUID();
                sessionStorage.setItem(SESSION_KEY, id);
            }
            return id;
        }
        catch {
            return crypto.randomUUID();
        }
    }
}
AnalyticsService.instance = null;


/***/ },

/***/ "./lib/services/ApiKeyManager.js"
/*!***************************************!*\
  !*** ./lib/services/ApiKeyManager.js ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_AGENT_PROMPTS: () => (/* binding */ DEFAULT_AGENT_PROMPTS),
/* harmony export */   DEFAULT_ATHENA_QUERY_PROMPT: () => (/* binding */ DEFAULT_ATHENA_QUERY_PROMPT),
/* harmony export */   DEFAULT_PLANNER_PROMPT: () => (/* binding */ DEFAULT_PLANNER_PROMPT),
/* harmony export */   DEFAULT_PYTHON_DEVELOPER_PROMPT: () => (/* binding */ DEFAULT_PYTHON_DEVELOPER_PROMPT),
/* harmony export */   DEFAULT_RESEARCHER_PROMPT: () => (/* binding */ DEFAULT_RESEARCHER_PROMPT),
/* harmony export */   clearAdminLLMConfig: () => (/* binding */ clearAdminLLMConfig),
/* harmony export */   clearCachedPrompts: () => (/* binding */ clearCachedPrompts),
/* harmony export */   clearLLMConfig: () => (/* binding */ clearLLMConfig),
/* harmony export */   fetchDefaultPrompts: () => (/* binding */ fetchDefaultPrompts),
/* harmony export */   getAdminLLMConfig: () => (/* binding */ getAdminLLMConfig),
/* harmony export */   getCachedPrompts: () => (/* binding */ getCachedPrompts),
/* harmony export */   getDefaultLLMConfig: () => (/* binding */ getDefaultLLMConfig),
/* harmony export */   getLLMConfig: () => (/* binding */ getLLMConfig),
/* harmony export */   hasValidApiKey: () => (/* binding */ hasValidApiKey),
/* harmony export */   initializePrompts: () => (/* binding */ initializePrompts),
/* harmony export */   maskApiKey: () => (/* binding */ maskApiKey),
/* harmony export */   saveAdminLLMConfig: () => (/* binding */ saveAdminLLMConfig),
/* harmony export */   saveLLMConfig: () => (/* binding */ saveLLMConfig),
/* harmony export */   testApiKey: () => (/* binding */ testApiKey)
/* harmony export */ });
/**
 * API Key Manager Service
 *
 * Manages LLM API keys in browser localStorage.
 * Keys are stored locally and sent with each request to the Agent Server.
 *
 * IMPORTANT (Financial Security Compliance):
 * - All API keys are stored ONLY in browser localStorage
 * - Agent Server receives ONE key per request (no key storage on server)
 * - Key rotation on rate limit (429) is handled by frontend
 */
const STORAGE_KEY = 'hdsp-agent-llm-config';
/** Cached prompts from API */
let cachedPrompts = null;
/** Fallback prompt when API is unavailable */
const FALLBACK_PROMPT = '(프롬프트를 불러오는 중...)';
/**
 * Fetch default prompts from backend API.
 * Results are cached for the session.
 */
async function fetchDefaultPrompts() {
    // Return cached if available
    if (cachedPrompts) {
        return cachedPrompts;
    }
    try {
        // Use PageConfig to get correct base URL for Jupyter proxy
        const { PageConfig } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
        const serverRoot = PageConfig.getBaseUrl();
        const { URLExt } = await Promise.resolve(/*! import() */).then(__webpack_require__.t.bind(__webpack_require__, /*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils", 23));
        const baseUrl = URLExt.join(serverRoot, 'hdsp-agent');
        const response = await fetch(`${baseUrl}/config/prompts?defaults=true`);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        cachedPrompts = await response.json();
        console.log('[ApiKeyManager] Default prompts fetched from API (code defaults)');
        return cachedPrompts;
    }
    catch (error) {
        console.error('[ApiKeyManager] Failed to fetch default prompts:', error);
        // Return fallback
        return {
            chat_system_prompt: FALLBACK_PROMPT,
            chat_rag_prompt: FALLBACK_PROMPT,
            planner: FALLBACK_PROMPT,
            python_developer: FALLBACK_PROMPT,
            researcher: FALLBACK_PROMPT,
            athena_query: FALLBACK_PROMPT,
        };
    }
}
/**
 * Get cached prompts (sync) - returns null if not yet fetched
 */
function getCachedPrompts() {
    return cachedPrompts;
}
/**
 * Clear cached prompts (useful for refresh)
 */
function clearCachedPrompts() {
    cachedPrompts = null;
}
// Legacy exports for backward compatibility (will be populated after fetch)
let DEFAULT_PLANNER_PROMPT = FALLBACK_PROMPT;
let DEFAULT_PYTHON_DEVELOPER_PROMPT = FALLBACK_PROMPT;
let DEFAULT_RESEARCHER_PROMPT = FALLBACK_PROMPT;
let DEFAULT_ATHENA_QUERY_PROMPT = FALLBACK_PROMPT;
// Default agent prompts collection (populated after fetch)
let DEFAULT_AGENT_PROMPTS = {
    planner: FALLBACK_PROMPT,
    python_developer: FALLBACK_PROMPT,
    researcher: FALLBACK_PROMPT,
    athena_query: FALLBACK_PROMPT,
};
/**
 * Initialize prompts from API (call this on app startup)
 */
async function initializePrompts() {
    const prompts = await fetchDefaultPrompts();
    DEFAULT_PLANNER_PROMPT = prompts.planner;
    DEFAULT_PYTHON_DEVELOPER_PROMPT = prompts.python_developer;
    DEFAULT_RESEARCHER_PROMPT = prompts.researcher;
    DEFAULT_ATHENA_QUERY_PROMPT = prompts.athena_query;
    DEFAULT_AGENT_PROMPTS = {
        planner: prompts.planner,
        python_developer: prompts.python_developer,
        researcher: prompts.researcher,
        athena_query: prompts.athena_query,
    };
}
// ═══════════════════════════════════════════════════════════════════════════
// LocalStorage Functions
// ═══════════════════════════════════════════════════════════════════════════
/**
 * Get the current LLM configuration from localStorage
 */
function getLLMConfig() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (!stored) {
            return null;
        }
        return JSON.parse(stored);
    }
    catch (e) {
        console.error('[ApiKeyManager] Failed to parse stored config:', e);
        return null;
    }
}
/**
 * Save LLM configuration to localStorage
 */
function saveLLMConfig(config) {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
        console.log('[ApiKeyManager] Config saved to localStorage');
        // Dispatch custom event for same-tab listeners (e.g., idle monitor)
        window.dispatchEvent(new CustomEvent('hdsp-config-updated', { detail: config }));
    }
    catch (e) {
        console.error('[ApiKeyManager] Failed to save config:', e);
    }
}
/**
 * Clear stored LLM configuration
 */
function clearLLMConfig() {
    localStorage.removeItem(STORAGE_KEY);
    console.log('[ApiKeyManager] Config cleared from localStorage');
}
/**
 * Check if API key is configured - DEPRECATED
 * All LLM settings now come from Agent Server
 */
function hasValidApiKey(_config) {
    // Always return true - API keys are managed by Agent Server
    return true;
}
/**
 * Get default LLM configuration (simplified - user preferences only)
 */
function getDefaultLLMConfig() {
    return {
        workspaceRoot: '',
        autoApprove: false
    };
}
/**
 * Mask API key for display (show first 4 and last 4 characters)
 */
function maskApiKey(key) {
    if (!key || key.length < 10)
        return '***';
    return `${key.slice(0, 4)}...${key.slice(-4)}`;
}
/**
 * Test API key - DEPRECATED
 * All LLM settings now come from Agent Server
 */
async function testApiKey(_config) {
    // API key testing should be done via Agent Server
    return { success: true, message: 'API keys are managed by Agent Server' };
}
// ═══════════════════════════════════════════════════════════════════════════
// Admin LLM Config (localStorage) - Admin mode only
// ═══════════════════════════════════════════════════════════════════════════
const ADMIN_LLM_STORAGE_KEY = 'hdsp-agent-admin-llm-config';
/**
 * Get admin LLM configuration from localStorage
 */
function getAdminLLMConfig() {
    try {
        const stored = localStorage.getItem(ADMIN_LLM_STORAGE_KEY);
        return stored ? JSON.parse(stored) : null;
    }
    catch {
        return null;
    }
}
/**
 * Save admin LLM configuration to localStorage
 */
function saveAdminLLMConfig(config) {
    localStorage.setItem(ADMIN_LLM_STORAGE_KEY, JSON.stringify(config));
    window.dispatchEvent(new CustomEvent('hdsp-config-updated', { detail: config }));
}
/**
 * Clear admin LLM configuration from localStorage
 */
function clearAdminLLMConfig() {
    localStorage.removeItem(ADMIN_LLM_STORAGE_KEY);
}
// Key rotation functions removed - API keys are now managed by Agent Server


/***/ },

/***/ "./lib/services/ApiService.js"
/*!************************************!*\
  !*** ./lib/services/ApiService.js ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ApiService: () => (/* binding */ ApiService)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/**
 * API 서비스 레이어 - 백엔드와의 REST 통신 담당
 */
// ✅ 핵심 변경 1: ServerConnection 대신 PageConfig 임포트

class ApiService {
    // 생성자에서 baseUrl을 선택적으로 받도록 하되, 없으면 자동으로 계산
    constructor(baseUrl) {
        this.resourceUsageCache = null;
        this.resourceUsageCacheMs = 15000;
        if (baseUrl) {
            this.baseUrl = baseUrl;
        }
        else {
            // ✅ 핵심 변경 2: ServerConnection 대신 PageConfig로 URL 가져오기
            // PageConfig.getBaseUrl()은 '/user/아이디/프로젝트/' 형태의 주소를 정확히 가져옵니다.
            const serverRoot = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getBaseUrl();
            // 3. 경로 합치기
            // 결과: /user/453467/pl2wadmprj/hdsp-agent
            this.baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(serverRoot, 'hdsp-agent');
        }
        console.log('[ApiService] Base URL initialized:', this.baseUrl); // 디버깅용 로그
    }
    /**
     * 쿠키 값 조회
     */
    getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) {
            return parts.pop()?.split(';').shift() || '';
        }
        return '';
    }
    /**
     * CSRF 토큰 조회
     */
    getCsrfToken() {
        return this.getCookie('_xsrf');
    }
    /**
     * POST 요청용 CSRF 토큰 포함 헤더 반환
     */
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            'X-XSRFToken': this.getCsrfToken()
        };
    }
    async getResourceUsageSnapshot() {
        const now = Date.now();
        if (this.resourceUsageCache
            && now - this.resourceUsageCache.timestamp < this.resourceUsageCacheMs) {
            return this.resourceUsageCache.resource;
        }
        try {
            const response = await fetch(`${this.baseUrl}/resource-usage`, {
                method: 'GET',
                credentials: 'include'
            });
            if (!response.ok) {
                return null;
            }
            const payload = await response.json().catch(() => ({}));
            const candidate = payload?.resource ?? payload;
            const snapshot = candidate && typeof candidate === 'object' && !Array.isArray(candidate)
                ? candidate
                : null;
            if (snapshot) {
                this.resourceUsageCache = { resource: snapshot, timestamp: now };
            }
            return snapshot;
        }
        catch (error) {
            console.warn('[ApiService] Resource usage fetch failed:', error);
            return null;
        }
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // API Request Helper
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Simple fetch wrapper for POST requests
     *
     * NOTE: API keys are now managed by Agent Server's AdminConfig.
     * Client only sends workspaceRoot and autoApprove preferences.
     */
    async fetchWithKeyRotation(url, request, options) {
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: this.getHeaders(),
                credentials: 'include',
                body: JSON.stringify(request)
            });
            if (response.ok) {
                return response.json();
            }
            // Handle error response
            const errorText = await response.text();
            let errorMessage = options?.defaultErrorMessage || 'API 요청 실패';
            try {
                const errorJson = JSON.parse(errorText);
                errorMessage = errorJson.detail || errorJson.error || errorJson.message || errorMessage;
            }
            catch (e) {
                errorMessage = errorText || errorMessage;
            }
            throw new Error(errorMessage);
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            throw error instanceof Error ? error : new Error(errorMsg);
        }
    }
    /**
     * 셀 액션 실행 (설명, 수정, 사용자 정의)
     * 전역 Rate Limit 처리 및 키 로테이션 사용
     */
    async cellAction(request) {
        console.log('[ApiService] cellAction request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/cell/action`, request, { defaultErrorMessage: '셀 액션 실패' });
    }
    /**
     * 채팅 메시지 전송 (비스트리밍)
     * 전역 Rate Limit 처리 및 키 로테이션 사용
     */
    async sendMessage(request) {
        console.log('[ApiService] sendMessage request');
        return this.fetchWithKeyRotation(`${this.baseUrl}/chat/message`, request, { defaultErrorMessage: '메시지 전송 실패' });
    }
    /**
     * 스트리밍 응답이 포함된 채팅 메시지 전송
     *
     * NOTE (금융 보안 준수):
     * - API 키 로테이션은 프론트엔드에서 처리 (서버에서 아님)
     * - 서버는 요청당 단일 키만 수신
     * - 429 Rate Limit 시 프론트엔드가 다음 키로 로테이션 후 재시도
     */
    /**
     * 단순 Chat용 스트리밍 - /chat/stream 사용
     * 원래 main 브랜치의 구현 복원 - LangChain 에이전트 없이 단순 Q&A
     *
     * NOTE: API keys are now managed by Agent Server's AdminConfig.
     */
    async sendChatStream(request, onChunk, onMetadata, abortSignal, onDebug) {
        await this.sendChatStreamInternal(request, onChunk, onMetadata, abortSignal, onDebug);
    }
    /**
     * 단순 Chat 스트리밍 내부 구현 - /chat/stream 엔드포인트 사용
     */
    async sendChatStreamInternal(request, onChunk, onMetadata, abortSignal, onDebug) {
        const response = await fetch(`${this.baseUrl}/chat/stream`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(request),
            signal: abortSignal
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to send chat message: ${error}`);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.error) {
                                throw new Error(data.error);
                            }
                            // Handle status clear (RAG → LLM streaming transition)
                            if (data.status_clear && onDebug) {
                                onDebug({ status: '__clear__', icon: '' });
                            }
                            // Handle status events (auto-compact, RAG search, etc.)
                            if (data.status && onDebug) {
                                if (data.icon) {
                                    onDebug({ status: data.status, icon: data.icon });
                                }
                                else {
                                    onDebug(data.status);
                                }
                            }
                            // Handle content clear (tool call 시 이전 할루시네이션 content 초기화)
                            if (data.content_clear) {
                                onChunk('__content_clear__');
                            }
                            // Handle tool processing signals (도구 호출 결과 분석 중)
                            if (data.tool_processing) {
                                onChunk('__tool_processing__');
                            }
                            if (data.tool_processing_end) {
                                onChunk('__tool_processing_end__');
                            }
                            if (data.content) {
                                onChunk(data.content);
                                // Yield to the macrotask queue so React flushes each token
                                // as a separate render. Without this, React 18 automatic
                                // batching combines all tokens from one reader.read() chunk
                                // into a single render, making the response appear all at once.
                                await new Promise(resolve => setTimeout(resolve, 0));
                            }
                            if (data.done && data.conversationId && onMetadata) {
                                onMetadata({ conversationId: data.conversationId });
                            }
                        }
                        catch (e) {
                            if (!(e instanceof SyntaxError)) {
                                throw e;
                            }
                        }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
        }
    }
    /**
     * Agent V2용 스트리밍 - /agent/langchain/stream 사용
     * LangChain Deep Agent (HITL, Todo, 도구 실행 등)
     *
     * NOTE: API keys are now managed by Agent Server's AdminConfig.
     */
    async sendAgentV2Stream(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, // Callback to capture thread_id for context persistence
    threadId, // Optional thread_id to continue existing conversation
    signal) {
        await this.sendAgentV2StreamInternal(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, threadId, signal);
    }
    /**
     * 기존 sendMessageStream 유지 (하위 호환성)
     * 내부적으로 sendAgentV2Stream 호출
     * @deprecated sendChatStream 또는 sendAgentV2Stream을 직접 사용하세요
     */
    async sendMessageStream(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, threadId, signal) {
        return this.sendAgentV2Stream(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, threadId, signal);
    }
    /**
     * Agent V2 스트리밍 내부 구현 - /agent/langchain/stream 사용
     * (기존 sendMessageStreamInternal에서 이름 변경)
     */
    async sendAgentV2StreamInternal(request, onChunk, onMetadata, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, onComplete, threadId, signal) {
        // Convert IChatRequest to LangChain AgentRequest format
        // Frontend's context has limited fields, map what's available
        const resourceContext = await this.getResourceUsageSnapshot();
        const requestConfig = resourceContext && request.llmConfig
            ? { ...request.llmConfig, resourceContext }
            : request.llmConfig;
        const langchainRequest = {
            request: request.message,
            threadId: threadId,
            notebookContext: request.context ? {
                notebook_path: request.context.notebookPath,
                cell_count: 0,
                imported_libraries: [],
                defined_variables: [],
                recent_cells: request.context.selectedCells?.map(cell => ({ source: cell })) || []
            } : undefined,
            llmConfig: requestConfig,
            workspaceRoot: request.llmConfig?.workspaceRoot || '.',
            agentMode: request.agentMode || 'multi' // Pass agent mode to backend (single/multi)
        };
        // Debug: log request size
        const requestBody = JSON.stringify(langchainRequest);
        console.log('[ApiService] Sending langchain request:', {
            messageLength: request.message.length,
            bodyLength: requestBody.length,
            threadId: threadId,
        });
        // Use LangChain streaming endpoint
        const response = await fetch(`${this.baseUrl}/agent/langchain/stream`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: requestBody,
            signal
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to send message: ${error}`);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        let properlyTerminated = false; // Track if stream ended with complete/done/interrupt event
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                // Process complete SSE messages
                const lines = buffer.split('\n');
                buffer = lines.pop() || ''; // Keep incomplete line in buffer
                let currentEventType = '';
                for (const line of lines) {
                    // Handle SSE event type: "event: type"
                    if (line.startsWith('event: ')) {
                        currentEventType = line.slice(7).trim();
                        continue;
                    }
                    // Handle SSE data: "data: json"
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            // Handle based on event type
                            if (currentEventType === 'todos' && data.todos && onTodos) {
                                console.log('[ApiService] Received todos:', data.todos.length, 'items');
                                onTodos(data.todos);
                                currentEventType = '';
                                continue;
                            }
                            if (currentEventType === 'debug_clear' && onDebugClear) {
                                onDebugClear();
                                currentEventType = '';
                                continue;
                            }
                            // Handle summary event (final_summary_tool result)
                            if (currentEventType === 'summary' && data.summary !== undefined) {
                                if (onChunk) {
                                    // Convert to JSON string so StreamingMessage can detect and render as summary card
                                    onChunk(JSON.stringify(data));
                                }
                                currentEventType = '';
                                continue;
                            }
                            if (currentEventType === 'complete' || currentEventType === 'done' || currentEventType === 'cancelled') {
                                properlyTerminated = true;
                                if (onDebugClear) {
                                    onDebugClear();
                                }
                                // Capture thread_id for context persistence across cycles
                                console.log(`[ApiService] ${currentEventType} event received, data:`, data);
                                if (onComplete && data.thread_id) {
                                    console.log('[ApiService] Calling onComplete with threadId:', data.thread_id);
                                    onComplete({ threadId: data.thread_id });
                                }
                                else {
                                    console.log('[ApiService] onComplete not called - onComplete:', !!onComplete, 'thread_id:', data.thread_id);
                                }
                                return;
                            }
                            // Handle errors
                            if (data.error) {
                                if (onDebug) {
                                    onDebug(`오류: ${data.error}`);
                                }
                                throw new Error(data.error);
                            }
                            // Handle debug events (display in gray)
                            if (data.status && onDebug) {
                                // Pass full object if expandable, has icon, or has turn/step info
                                if (data.expandable !== undefined || data.icon || data.turn !== undefined || data.step !== undefined) {
                                    onDebug({
                                        status: data.status,
                                        expandable: data.expandable,
                                        full_text: data.full_text,
                                        icon: data.icon,
                                        turn: data.turn,
                                        step: data.step,
                                        tool_label: data.tool_label
                                    });
                                }
                                else {
                                    onDebug(data.status);
                                }
                            }
                            // Handle interrupt events (Human-in-the-Loop)
                            if (data.thread_id && data.action && onInterrupt) {
                                properlyTerminated = true; // Interrupt is a valid termination
                                console.log('[ApiService] HITL interrupt received:', data.action, 'args:', JSON.stringify(data.args || {}).slice(0, 200), 'currentEventType:', currentEventType);
                                onInterrupt({
                                    threadId: data.thread_id,
                                    action: data.action,
                                    args: data.args || {},
                                    description: data.description || '',
                                    actionCount: data.actionCount
                                });
                                return; // Stop processing, wait for user decision
                            }
                            // Handle token events (streaming LLM response)
                            if (data.content) {
                                // Filter out raw todos JSON that shouldn't be displayed to users
                                // Pattern: {"todos": [{"content": "...", "status": "..."}, ...]}
                                const contentStr = String(data.content).trim();
                                const isSummaryJson = contentStr.includes('"summary"') && contentStr.includes('"next_items"');
                                // Check if this is a raw todos JSON object (not summary JSON)
                                let isRawTodosJson = false;
                                if (!isSummaryJson && contentStr.includes('"todos"')) {
                                    try {
                                        const parsed = JSON.parse(contentStr);
                                        // Check structure: {todos: [{content, status}, ...]}
                                        if (parsed && Array.isArray(parsed.todos) && parsed.todos.length > 0) {
                                            const firstTodo = parsed.todos[0];
                                            if (firstTodo && 'content' in firstTodo && 'status' in firstTodo) {
                                                isRawTodosJson = true;
                                            }
                                        }
                                    }
                                    catch {
                                        // Not valid JSON, check for partial pattern
                                        isRawTodosJson = /"todos"\s*:\s*\[\s*\{[^}]*"content"\s*:/.test(contentStr);
                                    }
                                }
                                if (isRawTodosJson) {
                                    console.log('[ApiService] Filtered raw todos JSON from display');
                                }
                                else {
                                    onChunk(data.content);
                                }
                            }
                            // Handle tool_call events - pass to handler for cell creation
                            if (currentEventType === 'tool_call' && data.tool && onToolCall) {
                                console.log('[ApiService] Tool call:', data.tool);
                                onToolCall({
                                    tool: data.tool,
                                    code: data.code,
                                    content: data.content,
                                    command: data.command,
                                    timeout: data.timeout
                                });
                                currentEventType = '';
                                continue;
                            }
                            // Handle tool_result events - skip displaying raw output
                            if (data.output) {
                                // Don't add raw tool output to chat
                            }
                            // Handle completion
                            if (data.final_answer) {
                                onChunk(data.final_answer);
                            }
                            // Handle metadata
                            if (data.conversationId && onMetadata) {
                                onMetadata({
                                    conversationId: data.conversationId,
                                    messageId: data.messageId,
                                    provider: data.metadata?.provider,
                                    model: data.metadata?.model
                                });
                            }
                            // Final metadata update
                            if (data.done && data.metadata && onMetadata) {
                                onMetadata({
                                    provider: data.metadata.provider,
                                    model: data.metadata.model
                                });
                            }
                            currentEventType = '';
                        }
                        catch (e) {
                            if (e instanceof SyntaxError) {
                                console.warn('Failed to parse SSE data:', line);
                            }
                            else {
                                throw e;
                            }
                        }
                    }
                }
            }
            // 스트림이 complete/done/interrupt 없이 종료된 경우 에러 throw
            if (!properlyTerminated) {
                throw new Error('Agent stream terminated unexpectedly');
            }
        }
        finally {
            reader.releaseLock();
            // Clear debug status if stream ended unexpectedly (no complete/done/interrupt event)
            if (!properlyTerminated && onDebugClear) {
                console.warn('[ApiService] Stream ended without proper termination, clearing debug status');
                onDebugClear();
            }
        }
    }
    /**
     * Resume interrupted agent execution with user decision
     */
    async resumeAgent(threadId, decision, args, feedback, llmConfig, onChunk, onDebug, onInterrupt, onTodos, onDebugClear, onToolCall, actionCount, signal) {
        const resourceContext = await this.getResourceUsageSnapshot();
        const requestConfig = resourceContext && llmConfig
            ? { ...llmConfig, resourceContext }
            : llmConfig;
        const resumeRequest = {
            threadId,
            decisions: [{
                    type: decision,
                    args,
                    feedback
                }],
            llmConfig: requestConfig,
            workspaceRoot: llmConfig?.workspaceRoot || '.'
        };
        if (actionCount && actionCount > 1) {
            resumeRequest.actionCount = actionCount;
        }
        const response = await fetch(`${this.baseUrl}/agent/langchain/resume`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(resumeRequest),
            signal
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to resume agent: ${error}`);
        }
        // Process SSE stream (same as sendMessageStream)
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        let properlyTerminated = false; // Track if stream ended with complete/done event
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                let currentEventType = '';
                for (const line of lines) {
                    // Handle SSE event type
                    if (line.startsWith('event: ')) {
                        currentEventType = line.slice(7).trim();
                        continue;
                    }
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.error) {
                                if (onDebug) {
                                    onDebug(`오류: ${data.error}`);
                                }
                                throw new Error(data.error);
                            }
                            // Handle todos event
                            if (currentEventType === 'todos' && data.todos && onTodos) {
                                console.log('[ApiService] Received todos (resume):', data.todos.length, 'items');
                                onTodos(data.todos);
                                currentEventType = '';
                                continue;
                            }
                            // Handle debug_clear event
                            if (currentEventType === 'debug_clear' && onDebugClear) {
                                onDebugClear();
                                currentEventType = '';
                                continue;
                            }
                            // Handle summary event (final_summary_tool result)
                            if (currentEventType === 'summary' && data.summary !== undefined) {
                                if (onChunk) {
                                    // Convert to JSON string so StreamingMessage can detect and render as summary card
                                    onChunk(JSON.stringify(data));
                                }
                                currentEventType = '';
                                continue;
                            }
                            if (currentEventType === 'complete' || currentEventType === 'done' || currentEventType === 'cancelled') {
                                properlyTerminated = true;
                                if (onDebugClear) {
                                    onDebugClear();
                                }
                                return;
                            }
                            // Debug events
                            if (data.status && onDebug) {
                                // Pass full object if expandable, has icon, or has turn/step info
                                if (data.expandable !== undefined || data.icon || data.turn !== undefined || data.step !== undefined) {
                                    onDebug({
                                        status: data.status,
                                        expandable: data.expandable,
                                        full_text: data.full_text,
                                        icon: data.icon,
                                        turn: data.turn,
                                        step: data.step,
                                        tool_label: data.tool_label
                                    });
                                }
                                else {
                                    onDebug(data.status);
                                }
                            }
                            // Another interrupt
                            if (data.thread_id && data.action && onInterrupt) {
                                properlyTerminated = true; // Interrupt is a valid termination
                                onInterrupt({
                                    threadId: data.thread_id,
                                    action: data.action,
                                    args: data.args || {},
                                    description: data.description || '',
                                    actionCount: data.actionCount
                                });
                                return;
                            }
                            // Content chunks
                            if (data.content && onChunk) {
                                // Filter out raw todos JSON that shouldn't be displayed to users
                                const contentStr = String(data.content).trim();
                                const isSummaryJson = contentStr.includes('"summary"') && contentStr.includes('"next_items"');
                                let isRawTodosJson = false;
                                if (!isSummaryJson && contentStr.includes('"todos"')) {
                                    try {
                                        const parsed = JSON.parse(contentStr);
                                        if (parsed && Array.isArray(parsed.todos) && parsed.todos.length > 0) {
                                            const firstTodo = parsed.todos[0];
                                            if (firstTodo && 'content' in firstTodo && 'status' in firstTodo) {
                                                isRawTodosJson = true;
                                            }
                                        }
                                    }
                                    catch {
                                        isRawTodosJson = /"todos"\s*:\s*\[\s*\{[^}]*"content"\s*:/.test(contentStr);
                                    }
                                }
                                if (isRawTodosJson) {
                                    console.log('[ApiService] Filtered raw todos JSON from display');
                                }
                                else {
                                    onChunk(data.content);
                                }
                            }
                            // Tool call events during resume
                            if (currentEventType === 'tool_call' && data.tool && onToolCall) {
                                onToolCall({
                                    tool: data.tool,
                                    code: data.code,
                                    content: data.content,
                                    command: data.command,
                                    timeout: data.timeout
                                });
                                currentEventType = '';
                                continue;
                            }
                            currentEventType = '';
                        }
                        catch (e) {
                            if (!(e instanceof SyntaxError)) {
                                throw e;
                            }
                        }
                    }
                }
            }
            // 스트림이 complete/done/interrupt 없이 종료된 경우 에러 throw
            if (!properlyTerminated) {
                throw new Error('Agent resume stream terminated unexpectedly');
            }
        }
        finally {
            reader.releaseLock();
            // Clear debug status if stream ended unexpectedly (no complete/done/interrupt event)
            if (!properlyTerminated && onDebugClear) {
                console.warn('[ApiService] Stream ended without proper termination, clearing debug status');
                onDebugClear();
            }
        }
    }
    /**
     * Cancel a running agent execution by thread ID
     */
    async cancelAgent(threadId) {
        const response = await fetch(`${this.baseUrl}/agent/langchain/cancel`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({ thread_id: threadId })
        });
        if (!response.ok) {
            const error = await response.text();
            console.warn('[ApiService] Failed to cancel agent:', error);
            return { status: 'error', message: error };
        }
        return response.json();
    }
    /**
     * Reset an agent thread (clear session and recreate agent)
     */
    async resetAgent(threadId) {
        const response = await fetch(`${this.baseUrl}/agent/langchain/reset`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({ thread_id: threadId })
        });
        if (!response.ok) {
            const error = await response.text();
            console.warn('[ApiService] Failed to reset agent:', error);
            return { status: 'error', message: error };
        }
        return response.json();
    }
    async executeCommand(command, timeout, cwd, stdin, workspaceRoot) {
        const response = await fetch(`${this.baseUrl}/execute-command`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({ command, timeout, cwd, stdin, workspaceRoot })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to execute command';
            throw new Error(errorMessage);
        }
        return payload;
    }
    async executeCommandStream(command, options) {
        const response = await fetch(`${this.baseUrl}/execute-command/stream`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                command,
                timeout: options?.timeout,
                cwd: options?.cwd,
                stdin: options?.stdin,
                workspaceRoot: options?.workspaceRoot
            })
        });
        if (!response.ok) {
            const payload = await response.json().catch(() => ({}));
            const errorMessage = payload.error || 'Failed to execute command';
            throw new Error(errorMessage);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        let result = null;
        let streamError = null;
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                let currentEventType = '';
                for (const line of lines) {
                    if (line.startsWith('event: ')) {
                        currentEventType = line.slice(7).trim();
                        continue;
                    }
                    if (!line.startsWith('data: ')) {
                        continue;
                    }
                    let data;
                    try {
                        data = JSON.parse(line.slice(6));
                    }
                    catch (e) {
                        continue;
                    }
                    if (currentEventType === 'output') {
                        if (typeof data.text === 'string' && options?.onOutput) {
                            options.onOutput({
                                stream: data.stream === 'stderr' ? 'stderr' : 'stdout',
                                text: data.text
                            });
                        }
                        currentEventType = '';
                        continue;
                    }
                    if (currentEventType === 'error') {
                        streamError = data.error || 'Command execution failed';
                        currentEventType = '';
                        continue;
                    }
                    if (currentEventType === 'result') {
                        result = data;
                        return result;
                    }
                    currentEventType = '';
                }
            }
        }
        finally {
            reader.releaseLock();
        }
        if (streamError) {
            throw new Error(streamError);
        }
        if (!result) {
            throw new Error('No command result received');
        }
        return result;
    }
    async readFile(path, options) {
        const response = await fetch(`${this.baseUrl}/read-file`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                path,
                encoding: options?.encoding || 'utf-8',
                cwd: options?.cwd,
                workspaceRoot: options?.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to read file';
            return { success: false, error: errorMessage };
        }
        return payload;
    }
    async writeFile(path, content, options) {
        const response = await fetch(`${this.baseUrl}/write-file`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                path,
                content,
                encoding: options?.encoding,
                overwrite: options?.overwrite,
                cwd: options?.cwd,
                workspaceRoot: options?.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to write file';
            throw new Error(errorMessage);
        }
        return payload;
    }
    /**
     * Search workspace for files matching pattern
     * Executed on Jupyter server using grep/ripgrep
     */
    async searchWorkspace(options) {
        const response = await fetch(`${this.baseUrl}/search-workspace`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                pattern: options.pattern,
                file_types: options.file_types || ['*.py', '*.ipynb'],
                path: options.path || '.',
                max_results: options.max_results || 50,
                case_sensitive: options.case_sensitive || false,
                workspaceRoot: options.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to search workspace';
            throw new Error(errorMessage);
        }
        return payload;
    }
    /**
     * Search notebook cells for pattern
     * Executed on Jupyter server
     */
    async searchNotebookCells(options) {
        const response = await fetch(`${this.baseUrl}/search-notebook-cells`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                pattern: options.pattern,
                notebook_path: options.notebook_path,
                cell_type: options.cell_type,
                max_results: options.max_results || 30,
                case_sensitive: options.case_sensitive || false,
                workspaceRoot: options.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            const errorMessage = payload.error || 'Failed to search notebook cells';
            throw new Error(errorMessage);
        }
        return payload;
    }
    /**
     * Check system resources and file sizes before data processing
     * Executed on Jupyter server
     */
    async checkResource(options) {
        const response = await fetch(`${this.baseUrl}/check-resource`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify({
                files: options.files || [],
                dataframes: options.dataframes || [],
                file_size_command: options.file_size_command || '',
                dataframe_check_code: options.dataframe_check_code || '',
                workspaceRoot: options.workspaceRoot
            })
        });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) {
            if (response.status === 404) {
                return {
                    success: false,
                    files: [],
                    dataframes: [],
                    error: 'Resource check endpoint is not available on this Jupyter server.'
                };
            }
            const errorMessage = payload.error || 'Failed to check resources';
            throw new Error(errorMessage);
        }
        return payload;
    }
    /**
     * Save configuration
     */
    async saveConfig(config) {
        const response = await fetch(`${this.baseUrl}/config`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(config)
        });
        if (!response.ok) {
            const error = await response.json().catch(() => ({ message: 'Failed to save configuration' }));
            throw new Error(error.message || 'Failed to save configuration');
        }
    }
    /**
     * Get current configuration
     */
    async getConfig() {
        const response = await fetch(`${this.baseUrl}/config`);
        if (!response.ok) {
            throw new Error('Failed to load configuration');
        }
        return response.json();
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // Admin/User Config APIs (Settings Split)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Check if current environment is in admin mode
     */
    async checkIsAdmin() {
        const response = await fetch(`${this.baseUrl}/config/is-admin`, {
            method: 'GET',
            credentials: 'include'
        });
        if (!response.ok) {
            throw new Error('Failed to check admin mode');
        }
        return response.json();
    }
    /**
     * Get admin configuration (LLM settings, prompts, server URLs)
     * API keys are masked for security
     */
    async getAdminConfig() {
        const response = await fetch(`${this.baseUrl}/config/admin`, {
            method: 'GET',
            credentials: 'include'
        });
        if (!response.ok) {
            throw new Error('Failed to load admin configuration');
        }
        return response.json();
    }
    /**
     * Update admin configuration
     */
    async updateAdminConfig(updates) {
        const response = await fetch(`${this.baseUrl}/config/admin`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(updates)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to update admin configuration: ${error}`);
        }
        return response.json();
    }
    /**
     * Get user configuration (preferences)
     */
    async getUserConfig() {
        const response = await fetch(`${this.baseUrl}/config/user`, {
            method: 'GET',
            credentials: 'include'
        });
        if (!response.ok) {
            throw new Error('Failed to load user configuration');
        }
        return response.json();
    }
    /**
     * Update user configuration
     */
    async updateUserConfig(updates) {
        const response = await fetch(`${this.baseUrl}/config/user`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(updates)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to update user configuration: ${error}`);
        }
        return response.json();
    }
    /**
     * Check if codebuff.md exists in workspace root
     */
    async getCodebuffStatus() {
        const response = await fetch(`${this.baseUrl}/config/codebuff-status`, {
            method: 'GET',
            credentials: 'include'
        });
        if (!response.ok) {
            throw new Error('Failed to get codebuff status');
        }
        return response.json();
    }
    /**
     * Get health status
     */
    async getStatus() {
        const response = await fetch(`${this.baseUrl}/status`);
        if (!response.ok) {
            throw new Error('Failed to get status');
        }
        return response.json();
    }
    /**
     * Get available models
     */
    async getModels() {
        const response = await fetch(`${this.baseUrl}/models`);
        if (!response.ok) {
            throw new Error('Failed to load models');
        }
        return response.json();
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // Auto-Agent API Methods (All use global rate limit handling)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Generate execution plan for auto-agent task
     */
    async generateExecutionPlan(request, onKeyRotation) {
        console.log('[ApiService] generateExecutionPlan request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/plan`, request, { onKeyRotation, defaultErrorMessage: '계획 생성 실패' });
    }
    /**
     * Refine step code after error (Self-Healing)
     */
    async refineStepCode(request, onKeyRotation) {
        console.log('[ApiService] refineStepCode request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/refine`, request, { onKeyRotation, defaultErrorMessage: '코드 수정 실패' });
    }
    /**
     * Adaptive Replanning - 에러 분석 후 계획 재수립
     */
    async replanExecution(request, onKeyRotation) {
        console.log('[ApiService] replanExecution request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/replan`, request, { onKeyRotation, defaultErrorMessage: '계획 재수립 실패' });
    }
    /**
     * Validate code before execution - 사전 코드 품질 검증 (Pyflakes/AST 기반)
     * Note: This is a local validation, no LLM call, but uses wrapper for consistency
     */
    async validateCode(request) {
        console.log('[ApiService] validateCode request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/validate`, request, { defaultErrorMessage: '코드 검증 실패' });
    }
    /**
     * Reflect on step execution - 실행 결과 분석 및 적응적 조정
     */
    async reflectOnExecution(request, onKeyRotation) {
        console.log('[ApiService] reflectOnExecution request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/reflect`, request, { onKeyRotation, defaultErrorMessage: 'Reflection 실패' });
    }
    /**
     * Verify state after step execution - 상태 검증 (Phase 1)
     * Note: This is a local verification, no LLM call, but uses wrapper for consistency
     */
    async verifyState(request) {
        console.log('[ApiService] verifyState request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/auto-agent/verify-state`, request, { defaultErrorMessage: '상태 검증 실패' });
    }
    /**
     * Stream execution plan generation with real-time updates
     */
    async generateExecutionPlanStream(request, onPlanUpdate, onReasoning) {
        const response = await fetch(`${this.baseUrl}/auto-agent/plan/stream`, {
            method: 'POST',
            headers: this.getHeaders(),
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to generate plan: ${error}`);
        }
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Response body is not readable');
        }
        const decoder = new TextDecoder();
        let buffer = '';
        let finalPlan = null;
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                for (const line of lines) {
                    if (line.startsWith('data: ')) {
                        try {
                            const data = JSON.parse(line.slice(6));
                            if (data.error) {
                                throw new Error(data.error);
                            }
                            if (data.reasoning && onReasoning) {
                                onReasoning(data.reasoning);
                            }
                            if (data.plan) {
                                onPlanUpdate(data.plan);
                                if (data.done) {
                                    finalPlan = data.plan;
                                }
                            }
                        }
                        catch (e) {
                            if (!(e instanceof SyntaxError)) {
                                throw e;
                            }
                        }
                    }
                }
            }
        }
        finally {
            reader.releaseLock();
        }
        if (!finalPlan) {
            throw new Error('No plan received from server');
        }
        return finalPlan;
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // File Action API Methods (Python 파일 에러 수정)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Python 파일 에러 수정/분석/설명 요청
     */
    async fileAction(request, onKeyRotation) {
        console.log('[ApiService] fileAction request:', request);
        return this.fetchWithKeyRotation(`${this.baseUrl}/file/action`, request, { onKeyRotation, defaultErrorMessage: '파일 액션 실패' });
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // File Resolution API Methods (파일 경로 해결)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Resolve file path - 파일명 또는 패턴으로 경로 검색
     */
    async resolveFile(request) {
        console.log('[ApiService] resolveFile request:', request);
        const response = await fetch(`${this.baseUrl}/file/resolve`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to resolve file: ${error}`);
        }
        return response.json();
    }
    /**
     * Select file from multiple options - 사용자 선택 처리
     */
    async selectFile(request) {
        console.log('[ApiService] selectFile request:', request);
        const response = await fetch(`${this.baseUrl}/file/select`, {
            method: 'POST',
            headers: this.getHeaders(),
            credentials: 'include',
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to select file: ${error}`);
        }
        return response.json();
    }
    // ═══════════════════════════════════════════════════════════════════════════
    // Chat Compact API (Conversation Summarization)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Compact conversation history by summarizing older messages.
     *
     * Strategy (Claude Code benchmark):
     * - Keep the last 3 messages intact
     * - Summarize all older messages using LLM
     * - Replace history with [summary] + [last 3 messages]
     */
    // ═══════════════════════════════════════════════════════════════════════════
    // Context Provider APIs (@file autocomplete)
    // ═══════════════════════════════════════════════════════════════════════════
    /**
     * Get autocomplete options for context commands (@file, etc.)
     */
    async getContextAutocomplete(options) {
        const params = new URLSearchParams();
        if (options?.partialCommand) {
            params.append('partialCommand', options.partialCommand);
        }
        if (options?.baseDir) {
            params.append('baseDir', options.baseDir);
        }
        const url = `${this.baseUrl}/context/autocomplete${params.toString() ? '?' + params.toString() : ''}`;
        console.log('[ApiService] getContextAutocomplete:', url);
        const response = await fetch(url, {
            method: 'GET',
            headers: this.getHeaders(),
            credentials: 'include'
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to get autocomplete options: ${error}`);
        }
        return response.json();
    }
    /**
     * List available context providers
     */
    async listContextProviders() {
        const response = await fetch(`${this.baseUrl}/context/providers`, {
            method: 'GET',
            headers: this.getHeaders(),
            credentials: 'include'
        });
        if (!response.ok) {
            const error = await response.text();
            throw new Error(`Failed to list context providers: ${error}`);
        }
        const data = await response.json();
        return data.providers;
    }
}


/***/ },

/***/ "./lib/services/TaskService.js"
/*!*************************************!*\
  !*** ./lib/services/TaskService.js ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TaskService: () => (/* binding */ TaskService)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/**
 * Task Service - 노트북 생성 작업 및 진행 상태 추적 처리
 */

class TaskService {
    constructor(baseUrl) {
        if (baseUrl) {
            this.baseUrl = baseUrl;
        }
        else {
            const serverRoot = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getBaseUrl();
            this.baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(serverRoot, 'hdsp-agent');
        }
        this.eventSources = new Map();
    }
    /**
     * 쿠키 값 조회
     */
    getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) {
            return parts.pop()?.split(';').shift() || '';
        }
        return '';
    }
    /**
     * CSRF 토큰 조회
     */
    getCsrfToken() {
        return this.getCookie('_xsrf');
    }
    /**
     * POST 요청용 CSRF 토큰 포함 헤더 반환
     */
    getHeaders() {
        return {
            'Content-Type': 'application/json',
            'X-XSRFToken': this.getCsrfToken()
        };
    }
    /**
     * 새 노트북 생성 작업 시작
     */
    async generateNotebook(request) {
        const response = await fetch(`${this.baseUrl}/notebook/generate`, {
            method: 'POST',
            headers: this.getHeaders(),
            body: JSON.stringify(request)
        });
        if (!response.ok) {
            const error = await response
                .json()
                .catch(() => ({ message: 'Failed to start notebook generation' }));
            throw new Error(error.message || 'Failed to start notebook generation');
        }
        return response.json();
    }
    /**
     * 현재 작업 상태 조회
     */
    async getTaskStatus(taskId) {
        const response = await fetch(`${this.baseUrl}/task/${taskId}/status`);
        if (!response.ok) {
            const error = await response
                .json()
                .catch(() => ({ message: 'Failed to get task status' }));
            throw new Error(error.message || 'Failed to get task status');
        }
        return response.json();
    }
    /**
     * Server-Sent Events를 통한 작업 진행 상태 구독
     */
    subscribeToTaskProgress(taskId, onProgress, onError, onComplete) {
        // Close existing connection if any
        this.unsubscribeFromTask(taskId);
        const eventSource = new EventSource(`${this.baseUrl}/task/${taskId}/stream`);
        eventSource.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                onProgress(data);
                // Close connection if task is done
                if (['completed', 'failed', 'cancelled'].includes(data.status)) {
                    this.unsubscribeFromTask(taskId);
                    if (onComplete) {
                        onComplete();
                    }
                }
            }
            catch (error) {
                console.error('Failed to parse SSE message:', error);
                if (onError) {
                    onError(error);
                }
            }
        };
        eventSource.onerror = (event) => {
            console.error('SSE connection error:', event);
            this.unsubscribeFromTask(taskId);
            if (onError) {
                onError(new Error('Connection to server lost'));
            }
        };
        this.eventSources.set(taskId, eventSource);
        // Return unsubscribe function
        return () => this.unsubscribeFromTask(taskId);
    }
    /**
     * 작업 진행 상태 구독 해제
     */
    unsubscribeFromTask(taskId) {
        const eventSource = this.eventSources.get(taskId);
        if (eventSource) {
            eventSource.close();
            this.eventSources.delete(taskId);
        }
    }
    /**
     * 실행 중인 작업 취소
     */
    async cancelTask(taskId) {
        const response = await fetch(`${this.baseUrl}/task/${taskId}/cancel`, {
            method: 'POST',
            headers: this.getHeaders()
        });
        if (!response.ok) {
            const error = await response
                .json()
                .catch(() => ({ message: 'Failed to cancel task' }));
            throw new Error(error.message || 'Failed to cancel task');
        }
        // Close SSE connection
        this.unsubscribeFromTask(taskId);
    }
    /**
     * 모든 활성 연결 정리
     */
    dispose() {
        for (const [taskId, _] of this.eventSources) {
            this.unsubscribeFromTask(taskId);
        }
    }
}


/***/ },

/***/ "./lib/types/index.js"
/*!****************************!*\
  !*** ./lib/types/index.js ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AgentEvent: () => (/* binding */ AgentEvent),
/* harmony export */   CellAction: () => (/* binding */ CellAction),
/* harmony export */   FileAction: () => (/* binding */ FileAction)
/* harmony export */ });
/**
 * Jupyter Agent 확장의 핵심 타입 정의
 */
var CellAction;
(function (CellAction) {
    CellAction["EXPLAIN"] = "explain";
    CellAction["FIX"] = "fix";
    CellAction["CUSTOM_PROMPT"] = "custom_prompt";
})(CellAction || (CellAction = {}));
var AgentEvent;
(function (AgentEvent) {
    AgentEvent["CELL_ACTION"] = "hdsp-agent:cell-action";
    AgentEvent["CONFIG_CHANGED"] = "hdsp-agent:config-changed";
    AgentEvent["MESSAGE_SENT"] = "hdsp-agent:message-sent";
    AgentEvent["MESSAGE_RECEIVED"] = "hdsp-agent:message-received";
})(AgentEvent || (AgentEvent = {}));
// ═══════════════════════════════════════════════════════════════════════════
// File Action Types (Python 파일 에러 수정용)
// ═══════════════════════════════════════════════════════════════════════════
var FileAction;
(function (FileAction) {
    FileAction["FIX"] = "fix";
    FileAction["EXPLAIN"] = "explain";
    FileAction["CUSTOM"] = "custom";
})(FileAction || (FileAction = {}));


/***/ },

/***/ "./lib/utils/icons.js"
/*!****************************!*\
  !*** ./lib/utils/icons.js ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Icons: () => (/* binding */ Icons),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getIcon: () => (/* binding */ getIcon),
/* harmony export */   getIcon960: () => (/* binding */ getIcon960),
/* harmony export */   getIconByName: () => (/* binding */ getIconByName)
/* harmony export */ });
/**
 * Material Design Icons as inline SVG strings
 * These can be safely embedded in HTML strings without escaping issues
 */
// Base SVG wrapper with consistent styling (no xmlns for HTML5 inline embedding)
// Standard Material Design Icons (viewBox 0 0 24 24)
const svgWrapper = (path, color = 'currentColor', size = 16) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="${color}" style="vertical-align: middle; display: inline-block;">${path}</svg>`;
// Google Material Symbols wrapper (viewBox 0 -960 960 960)
const svgWrapper960 = (path, color = 'currentColor', size = 16) => `<svg width="${size}" height="${size}" viewBox="0 -960 960 960" fill="${color}" style="vertical-align: middle; display: inline-block;">${path}</svg>`;
// Material Design icon paths (viewBox 0 0 24 24)
const ICON_PATHS = {
    // File system
    folder: '<path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/>',
    file: '<path d="M6 2c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6H6zm7 7V3.5L18.5 9H13z"/>',
    explore: '<path d="M12 10.9c-.61 0-1.1.49-1.1 1.1s.49 1.1 1.1 1.1c.61 0 1.1-.49 1.1-1.1s-.49-1.1-1.1-1.1zM12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm2.19 12.19L6 18l3.81-8.19L18 6l-3.81 8.19z"/>',
    read: '<path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"/>',
    write: '<path d="M19 8l-4 4h3c0 3.31-2.69 6-6 6-1.01 0-1.97-.25-2.8-.7l-1.46 1.46C8.97 19.54 10.43 20 12 20c4.42 0 8-3.58 8-8h3l-4-4zM6 12c0-3.31 2.69-6 6-6 1.01 0 1.97.25 2.8.7l1.46-1.46C15.03 4.46 13.57 4 12 4c-4.42 0-8 3.58-8 8H1l4 4 4-4H6z"/>',
    // Status
    success: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>',
    error: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>',
    warning: '<path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/>',
    info: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>',
    check: '<path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>',
    // Actions
    edit: '<path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>',
    search: '<path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>',
    save: '<path d="M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z"/>',
    diagnostics: '<path d="M19.5 12c0-.23-.01-.45-.03-.68l1.86-1.41c.4-.3.51-.86.26-1.3l-1.87-3.23c-.25-.44-.79-.62-1.25-.42l-2.15.91c-.37-.26-.76-.49-1.17-.68l-.29-2.31C14.8 2.38 14.37 2 13.87 2h-3.73c-.5 0-.93.38-.99.88l-.29 2.31c-.41.19-.8.42-1.17.68l-2.15-.91c-.46-.2-1-.02-1.25.42L2.41 8.62c-.25.44-.14.99.26 1.3l1.86 1.41c-.02.22-.03.44-.03.67s.01.45.03.68l-1.86 1.41c-.4.3-.51.86-.26 1.3l1.87 3.23c.25.44.79.62 1.25.42l2.15-.91c.37.26.76.49 1.17.68l.29 2.31c.06.5.49.88.99.88h3.73c.5 0 .93-.38.99-.88l.29-2.31c.41-.19.8-.42 1.17-.68l2.15.91c.46.2 1 .02 1.25-.42l1.87-3.23c.25-.44.14-.99-.26-1.3l-1.86-1.41c.03-.23.04-.45.04-.68zm-7.46 3.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"/>',
    // Other
    question: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/>',
    code: '<path d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/>',
    terminal: '<path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V8h16v10zm-2-1h-6v-2h6v2zM7.5 17l-1.41-1.41L8.67 13l-2.59-2.59L7.5 9l4 4-4 4z"/>',
    analytics: '<path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"/>',
    skip: '<path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/>',
    // Agents/Roles
    planner: '<path d="M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm8.94 3c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/>',
    build: '<path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/>',
    person: '<path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>',
    researcher: '<path d="M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7zm2.85 11.1l-.85.6V16h-4v-2.3l-.85-.6C7.8 12.16 7 10.63 7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 1.63-.8 3.16-2.15 4.1z"/>',
    // UI elements
    expandMore: '<path d="M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6z"/>',
    expandLess: '<path d="M12 8l-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14z"/>',
    chevronRight: '<path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>',
    // Summary/Tasks
    summary: '<path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>',
    listAlt: '<path d="M19 5v14H5V5h14m1.1-2H3.9c-.5 0-.9.4-.9.9v16.2c0 .4.4.9.9.9h16.2c.4 0 .9-.5.9-.9V3.9c0-.5-.5-.9-.9-.9zM11 7h6v2h-6V7zm0 4h6v2h-6v-2zm0 4h6v2h-6v-2zM7 7h2v2H7V7zm0 4h2v2H7v-2zm0 4h2v2H7v-2z"/>',
};
// Google Material Symbols paths (viewBox 0 -960 960 960)
const ICON_PATHS_960 = {
    // Code terminal icon (for jp-agent-code-description)
    description: '<path d="m384-336 56-57-87-87 87-87-56-57-144 144 144 144Zm192 0 144-144-144-144-56 57 87 87-87 87 56 57ZM200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h560q33 0 56.5 23.5T840-760v560q0 33-23.5 56.5T760-120H200Zm0-80h560v-560H200v560Zm0-560v560-560Z"/>',
    // Next steps icon (for 다음 단계 제안)
    assignment: '<path d="M240-400h80q0-59 43-99.5T466-540q36 0 67 16.5t51 43.5h-64v80h200v-200h-80v62q-32-38-76.5-60T466-620q-95 0-160.5 64T240-400ZM480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/>',
    // Thinking/Loading icon (for LLM 응답 대기중)
    thinking: '<path d="M480-40q-112 0-206-51T120-227v107H40v-240h240v80h-99q48 72 126.5 116T480-120q75 0 140.5-28.5t114-77q48.5-48.5 77-114T840-480h80q0 91-34.5 171T791-169q-60 60-140 94.5T480-40ZM40-480q0-91 34.5-171T169-791q60-60 140-94.5T480-920q112 0 206 51t154 136v-107h80v240H680v-80h99q-48-72-126.5-116T480-840q-75 0-140.5 28.5t-114 77q-48.5 48.5-77 114T120-480H40Zm440 240q21 0 35.5-14.5T530-290q0-21-14.5-36T480-341q-21 0-35.5 14.5T430-291q0 21 14.5 36t35.5 15Zm-36-152h73q0-36 8.5-54t34.5-44q35-35 46.5-56.5T618-598q0-56-40-89t-98-33q-50 0-86 26t-52 74l66 28q7-26 26.5-43t45.5-17q27 0 45.5 15.5T544-595q0 17-8 34t-34 40q-33 29-45.5 56.5T444-392Z"/>',
    // Tool execution icon (for Tool 실행: ...)
    tool: '<path d="M754-81q-8 0-15-2.5T726-92L522-296q-6-6-8.5-13t-2.5-15q0-8 2.5-15t8.5-13l85-85q6-6 13-8.5t15-2.5q8 0 15 2.5t13 8.5l204 204q6 6 8.5 13t2.5 15q0 8-2.5 15t-8.5 13l-85 85q-6 6-13 8.5T754-81Zm0-95 29-29-147-147-29 29 147 147ZM205-80q-8 0-15.5-3T176-92l-84-84q-6-6-9-13.5T80-205q0-8 3-15t9-13l212-212h85l34-34-165-165h-57L80-765l113-113 121 121v57l165 165 116-116-43-43 56-56H495l-28-28 142-142 28 28v113l56-56 142 142q17 17 26 38.5t9 45.5q0 24-9 46t-26 39l-85-85-56 56-42-42-207 207v84L233-92q-6 6-13 9t-15 3Zm0-96 170-170v-29h-29L176-205l29 29Zm0 0-29-29 15 14 14 15Zm549 0 29-29-29 29Z"/>',
    // Subagent complete icon (person with checkmark)
    subagentComplete: '<path d="M702-480 560-622l57-56 85 85 170-170 56 57-226 226Zm-342 0q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM40-160v-112q0-34 17.5-62.5T104-378q62-31 126-46.5T360-440q66 0 130 15.5T616-378q29 15 46.5 43.5T680-272v112H40Zm80-80h480v-32q0-11-5.5-20T580-306q-54-27-109-40.5T360-360q-56 0-111 13.5T140-306q-9 5-14.5 14t-5.5 20v32Zm240-320q33 0 56.5-23.5T440-640q0-33-23.5-56.5T360-720q-33 0-56.5 23.5T280-640q0 33 23.5 56.5T360-560Zm0 260Zm0-340Z"/>',
    // Subagent start icon (person with edit)
    subagentStart: '<path d="M480-240Zm-320 80v-112q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q37 0 73 4.5t72 14.5l-67 68q-20-3-39-5t-39-2q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32h240v80H160Zm400 40v-123l221-220q9-9 20-13t22-4q12 0 23 4.5t20 13.5l37 37q8 9 12.5 20t4.5 22q0 11-4 22.5T903-340L683-120H560Zm300-263-37-37 37 37ZM620-180h38l121-122-18-19-19-18-122 121v38Zm141-141-19-18 37 37-18-19ZM480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47Zm0-80q33 0 56.5-23.5T560-640q0-33-23.5-56.5T480-720q-33 0-56.5 23.5T400-640q0 33 23.5 56.5T480-560Zm0-80Z"/>',
    // Agent execution icon (robot/AI head)
    agent: '<path d="M309-389q29 29 71 29t71-29l160-160q29-29 29-71t-29-71q-29-29-71-29t-71 29q-37-13-73-6t-61 32q-25 25-32 61t6 73q-29 29-29 71t29 71ZM240-80v-172q-57-52-88.5-121.5T120-520q0-150 105-255t255-105q125 0 221.5 73.5T827-615l52 205q5 19-7 34.5T840-360h-80v120q0 33-23.5 56.5T680-160h-80v80h-80v-160h160v-200h108l-38-155q-23-91-98-148t-172-57q-116 0-198 81t-82 197q0 60 24.5 114t69.5 96l26 24v208h-80Zm254-360Z"/>',
    // Pause icon (for 사용자 승인 대기)
    pause: '<path d="M520-200v-560h240v560H520Zm-320 0v-560h240v560H200Zm400-80h80v-400h-80v400Zm-320 0h80v-400h-80v400Zm0-400v400-400Zm320 0v400-400Z"/>',
    // Play icon (for 실행 재개)
    play: '<path d="M320-200v-560l440 280-440 280Zm80-280Zm0 134 210-134-210-134v268Z"/>',
    // Lightbulb icon (for tips)
    lightbulb: '<path d="M480-80q-34 0-57.5-23.5T399-161h162q0 34-23.5 57.5T480-80ZM318-223v-80h324v80H318Zm5-120q-66-43-104.5-107.5T180-597q0-122 89-211t211-89q122 0 211 89t89 211q0 82-38.5 146.5T637-343H323Zm22-80h270q44-29 69.5-71.5T710-597q0-97-66.5-163.5T480-827q-97 0-163.5 66.5T250-597q0 60 25.5 102.5T345-423Zm135 0Z"/>',
    // Approve circle icon (checkmark in circle)
    approveCircle: '<path d="m424-296 282-282-56-56-226 226-114-114-56 56 170 170Zm56 216q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z"/>',
    // Reject circle icon (prohibited sign)
    rejectCircle: '<path d="M480-80q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q54 0 104-17.5t92-50.5L228-676q-33 42-50.5 92T160-480q0 134 93 227t227 93Zm252-124q33-42 50.5-92T800-480q0-134-93-227t-227-93q-54 0-104 17.5T284-732l448 448ZM480-480Z"/>',
    // Double check icon (approved status)
    doubleCheck: '<path d="m381-240 424-424-57-56-368 367-169-170-57 57 227 226Zm0 113L42-466l169-170 170 170 366-367 172 168-538 538Z"/>',
    // Approval warning icon (exclamation point)
    approvalWarning: '<path d="M480-120q-33 0-56.5-23.5T400-200q0-33 23.5-56.5T480-280q33 0 56.5 23.5T560-200q0 33-23.5 56.5T480-120Zm-80-240v-480h160v480H400Z"/>',
};
// Color constants (Material Design color palette)
const COLORS = {
    folder: '#ffc107',
    file: '#2196f3',
    explore: '#757575',
    read: '#757575',
    write: '#757575',
    success: '#4caf50',
    error: '#f44336',
    warning: '#ff9800',
    info: '#2196f3',
    check: '#757575',
    edit: '#757575',
    search: '#757575',
    save: '#4caf50',
    diagnostics: '#607d8b',
    question: '#2196f3',
    description: '#2196f3',
    code: '#9c27b0',
    terminal: '#607d8b',
    analytics: '#00bcd4',
    skip: '#9e9e9e',
    planner: '#e91e63',
    build: '#ff5722',
    person: '#795548',
    researcher: '#3f51b5',
    expandMore: '#757575',
    expandLess: '#757575',
    chevronRight: '#757575',
    summary: '#4caf50',
    assignment: '#2196f3',
    listAlt: '#ff9800',
    // Status message icons - unified grey color for clean look
    tool: '#757575',
    agent: '#757575',
    subagentComplete: '#757575',
    subagentStart: '#757575',
    pause: '#757575',
    play: '#757575',
    thinking: '#757575',
    lightbulb: '#ffc107',
    // Approval action icons
    approveCircle: '#4caf50',
    rejectCircle: '#f44336',
    doubleCheck: '#4caf50',
    approvalWarning: '#ff9800', // Orange for warning
};
/**
 * Get inline SVG icon string
 */
function getIcon(name, size = 16, customColor) {
    const path = ICON_PATHS[name];
    const color = customColor || COLORS[name] || 'currentColor';
    return svgWrapper(path, color, size);
}
/**
 * Get inline SVG icon string for 960x960 icons
 */
function getIcon960(name, size = 16, customColor) {
    const path = ICON_PATHS_960[name];
    const color = customColor || COLORS[name] || 'currentColor';
    return svgWrapper960(path, color, size);
}
/**
 * Get icon by string name (for dynamic icon rendering)
 * Returns empty string if icon not found
 */
function getIconByName(name, size = 16, customColor) {
    // Check 960 icons first (description, assignment, thinking)
    if (name in ICON_PATHS_960) {
        const path = ICON_PATHS_960[name];
        const color = customColor || COLORS[name] || 'currentColor';
        return svgWrapper960(path, color, size);
    }
    // Then check standard icons
    if (name in ICON_PATHS) {
        const path = ICON_PATHS[name];
        const color = customColor || COLORS[name] || 'currentColor';
        return svgWrapper(path, color, size);
    }
    return '';
}
/**
 * Pre-built icon strings for common use cases
 */
const Icons = {
    // File system
    folder: getIcon('folder'),
    file: getIcon('file'),
    explore: getIcon('explore'),
    read: getIcon('read'),
    write: getIcon('write'),
    // Status
    success: getIcon('success'),
    error: getIcon('error'),
    warning: getIcon('warning'),
    info: getIcon('info'),
    check: getIcon('check'),
    thinking: getIcon960('thinking'),
    // Actions
    edit: getIcon('edit'),
    search: getIcon('search'),
    save: getIcon('save'),
    diagnostics: getIcon('diagnostics'),
    // Other
    question: getIcon('question'),
    description: getIcon960('description'),
    code: getIcon('code'),
    terminal: getIcon('terminal'),
    analytics: getIcon('analytics'),
    skip: getIcon('skip'),
    // Agents/Roles
    planner: getIcon('planner'),
    build: getIcon('build'),
    person: getIcon('person'),
    researcher: getIcon('researcher'),
    // UI elements
    expandMore: getIcon('expandMore'),
    expandLess: getIcon('expandLess'),
    chevronRight: getIcon('chevronRight'),
    // Summary/Tasks
    summary: getIcon('summary'),
    assignment: getIcon960('assignment'),
    listAlt: getIcon('listAlt'),
    // Tool execution
    tool: getIcon960('tool'),
    // Subagent icons
    agent: getIcon960('agent'),
    subagentComplete: getIcon960('subagentComplete'),
    subagentStart: getIcon960('subagentStart'),
    // Status icons
    pause: getIcon960('pause'),
    play: getIcon960('play'),
    lightbulb: getIcon960('lightbulb'),
    // Risk levels (colored circles)
    riskLow: getIcon('success', 16, '#4caf50'),
    riskMedium: getIcon('info', 16, '#2196f3'),
    riskHigh: getIcon('warning', 16, '#ff9800'),
    riskCritical: getIcon('error', 16, '#f44336'),
    // Approval action icons
    approveCircle: getIcon960('approveCircle', 20),
    rejectCircle: getIcon960('rejectCircle', 20),
    doubleCheck: getIcon960('doubleCheck', 16),
    approvalWarning: getIcon960('approvalWarning', 16),
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Icons);


/***/ },

/***/ "./lib/utils/markdownRenderer.js"
/*!***************************************!*\
  !*** ./lib/utils/markdownRenderer.js ***!
  \***************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   escapeHtml: () => (/* binding */ escapeHtml),
/* harmony export */   formatMarkdownToHtml: () => (/* binding */ formatMarkdownToHtml),
/* harmony export */   highlightDiff: () => (/* binding */ highlightDiff),
/* harmony export */   highlightJavaScript: () => (/* binding */ highlightJavaScript),
/* harmony export */   highlightJson: () => (/* binding */ highlightJson),
/* harmony export */   highlightPython: () => (/* binding */ highlightPython),
/* harmony export */   preprocessForRendermime: () => (/* binding */ preprocessForRendermime),
/* harmony export */   unescapeHtml: () => (/* binding */ unescapeHtml)
/* harmony export */ });
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./icons */ "./lib/utils/icons.js");
/**
 * Markdown을 HTML로 변환 (구문 강조 포함)
 * chrome_agent의 formatMarkdownToHtml 구현 기반
 */

/**
 * 콘텐츠에서 안정적인 ID 생성을 위한 간단한 해시 함수
 * djb2 알고리즘 사용 (빠른 문자열 해싱)
 */
function simpleHash(str) {
    let hash = 5381;
    for (let i = 0; i < str.length; i++) {
        hash = ((hash << 5) + hash) + str.charCodeAt(i);
        hash = hash & hash; // Convert to 32-bit integer
    }
    // Convert to positive hex string
    return Math.abs(hash).toString(36);
}
/**
 * HTML 특수 문자 이스케이프
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
/**
 * HTML entity를 원래 문자로 디코딩
 * LLM이 코드 블록에 &lt; &gt; 등을 텍스트로 출력하는 경우 대응
 */
function unescapeHtml(text) {
    return text
        .replace(/&amp;/g, '&')
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>')
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#x27;/g, "'");
}
/**
 * 코드 블록의 들여쓰기 정규화
 */
function normalizeIndentation(code) {
    const lines = code.split('\n');
    // Find minimum indent from non-empty lines
    let minIndent = Infinity;
    const nonEmptyLines = [];
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (line.trim().length > 0) {
            const match = line.match(/^(\s*)/);
            const indent = match ? match[1].length : 0;
            minIndent = Math.min(minIndent, indent);
            nonEmptyLines.push(i);
        }
    }
    // If no indent or no non-empty lines, return original
    if (minIndent === Infinity || minIndent === 0) {
        return code;
    }
    // Remove minimum indent from all lines
    const normalized = lines.map(line => {
        if (line.trim().length === 0) {
            return '';
        }
        return line.substring(minIndent);
    });
    return normalized.join('\n');
}
function extractNextItemsBlock(text) {
    if (!text.trim()) {
        return null;
    }
    // Debug: Check if text contains summary JSON markers
    const hasSummaryMarker = text.includes('"summary"');
    const hasNextItemsMarker = text.includes('"next_items"');
    if (hasSummaryMarker && hasNextItemsMarker) {
        console.log('[extractNextItemsBlock] Found summary JSON markers, text length:', text.length);
        console.log('[extractNextItemsBlock] Text preview:', text.slice(0, 200));
    }
    // Try multiple regex patterns for fenced code blocks:
    // 1. Standard: ```json\n...\n``` (with language and newline)
    // 2. No newline: ```json{...}``` (no newline after language)
    // 3. No language: ```\n...\n``` or ```{...}```
    const fencedPatterns = [
        /```(\w+)?\n([\s\S]*?)```/g,
        /```(\w+)?({[\s\S]*?})```/g, // Without newline, content starts with {
    ];
    for (const fencedRegex of fencedPatterns) {
        let match;
        while ((match = fencedRegex.exec(text)) !== null) {
            const lang = (match[1] || '').toLowerCase();
            const content = match[2].trim();
            if (!content)
                continue;
            if (lang && lang !== 'json' && !content.includes('"next_items"')) {
                continue;
            }
            const parsed = parseNextItemsPayload(content);
            if (parsed) {
                const placeholder = `__NEXT_ITEMS_${Math.random().toString(36).slice(2, 11)}__`;
                const updated = text.slice(0, match.index) + placeholder + text.slice(match.index + match[0].length);
                return { items: parsed.items, summary: parsed.summary, placeholder, text: updated };
            }
        }
        // Reset lastIndex for next pattern
        fencedRegex.lastIndex = 0;
    }
    const range = findNextItemsJsonRange(text);
    if (!range) {
        console.log('[extractNextItemsBlock] findNextItemsJsonRange returned null');
        return null;
    }
    console.log('[extractNextItemsBlock] Found JSON range:', range.start, '-', range.end);
    const candidate = text.slice(range.start, range.end + 1);
    console.log('[extractNextItemsBlock] Candidate JSON length:', candidate.length);
    console.log('[extractNextItemsBlock] Candidate JSON preview:', candidate.slice(0, 200));
    const parsed = parseNextItemsPayload(candidate);
    if (!parsed) {
        console.log('[extractNextItemsBlock] parseNextItemsPayload returned null');
        return null;
    }
    // Calculate replacement range
    let replacementStart = range.start;
    let replacementEnd = range.end;
    const lineStart = text.lastIndexOf('\n', range.start - 1) + 1;
    const linePrefix = text.slice(lineStart, range.start).trim();
    const normalizedPrefix = linePrefix.replace(/[：:]$/, '').toLowerCase();
    if (normalizedPrefix === 'json') {
        replacementStart = lineStart;
    }
    // CRITICAL FIX: Handle nested/malformed JSON wrappers
    // Check if there's orphaned JSON wrapper before our JSON (e.g., '{"summary":' or '{"summary": ')
    const textBeforeJson = text.slice(0, replacementStart);
    const wrapperPatterns = [
        /\{\s*"summary"\s*:\s*$/,
        /\{\s*"next_items"\s*:\s*$/,
        /\{\s*$/, // just {
    ];
    for (const pattern of wrapperPatterns) {
        const wrapperMatch = textBeforeJson.match(pattern);
        if (wrapperMatch) {
            // Found an orphaned wrapper, extend replacement to include it
            const wrapperStart = textBeforeJson.lastIndexOf(wrapperMatch[0]);
            if (wrapperStart !== -1) {
                console.log('[extractNextItemsBlock] Found orphaned wrapper:', wrapperMatch[0]);
                replacementStart = wrapperStart;
                break;
            }
        }
    }
    // Check if there's orphaned closing brace after our JSON
    const textAfterJson = text.slice(range.end + 1);
    const closingMatch = textAfterJson.match(/^\s*\}/);
    if (closingMatch) {
        console.log('[extractNextItemsBlock] Found orphaned closing brace');
        replacementEnd = range.end + closingMatch[0].length;
    }
    const placeholder = `__NEXT_ITEMS_${Math.random().toString(36).slice(2, 11)}__`;
    const updated = text.slice(0, replacementStart) + placeholder + text.slice(replacementEnd + 1);
    console.log('[extractNextItemsBlock] Replacement range:', replacementStart, '-', replacementEnd);
    console.log('[extractNextItemsBlock] Updated text preview:', updated.slice(0, 100));
    return { items: parsed.items, summary: parsed.summary, placeholder, text: updated };
}
function findNextItemsJsonRange(text) {
    const key = '"next_items"';
    const keyIndex = text.indexOf(key);
    if (keyIndex === -1)
        return null;
    // Find all { before "next_items" and try from EARLIEST (outermost) first
    // This handles cases where summary contains nested braces like {"summary": "{test}", ...}
    const candidates = [];
    for (let i = 0; i < keyIndex; i++) {
        if (text[i] === '{') {
            candidates.push(i);
        }
    }
    console.log('[findNextItemsJsonRange] Found', candidates.length, 'candidate { positions before "next_items"');
    // Try from earliest { (most likely to be the outer JSON object)
    for (const start of candidates) {
        const end = findMatchingBrace(text, start);
        if (end !== -1 && end > keyIndex) {
            // This { ... } contains "next_items"
            console.log('[findNextItemsJsonRange] Found valid range:', start, '-', end);
            return { start, end };
        }
    }
    return null;
}
function findMatchingBrace(text, start) {
    let depth = 0;
    let inString = false;
    let escaped = false;
    for (let i = start; i < text.length; i++) {
        const char = text[i];
        if (inString) {
            if (escaped) {
                escaped = false;
                continue;
            }
            if (char === '\\') {
                escaped = true;
                continue;
            }
            if (char === '"') {
                inString = false;
            }
            continue;
        }
        if (char === '"') {
            inString = true;
            continue;
        }
        if (char === '{') {
            depth += 1;
        }
        else if (char === '}') {
            depth -= 1;
            if (depth === 0) {
                return i;
            }
        }
    }
    return -1;
}
function parseNextItemsPayload(payload) {
    // Trim whitespace to handle trailing newlines
    const trimmedPayload = payload.trim();
    if (!trimmedPayload.startsWith('{') || !trimmedPayload.endsWith('}')) {
        console.log('[parseNextItemsPayload] Invalid JSON structure - starts with:', trimmedPayload.slice(0, 20), 'ends with:', trimmedPayload.slice(-20));
        return null;
    }
    // Use trimmed payload for parsing
    payload = trimmedPayload;
    // Check if JSON is escaped (starts with {\" instead of {")
    // This can happen when LLM outputs JSON inside another context
    let payloadToparse = payload;
    if (payload.includes('\\"') && !payload.includes('{"')) {
        console.log('[parseNextItemsPayload] Detected escaped JSON, attempting to unescape');
        // Unescape: \" -> ", \\ -> \
        payloadToparse = payload.replace(/\\"/g, '"').replace(/\\\\/g, '\\');
        console.log('[parseNextItemsPayload] Unescaped JSON preview:', payloadToparse.slice(0, 100));
    }
    try {
        console.log('[parseNextItemsPayload] Attempting to parse JSON, length:', payloadToparse.length);
        const parsed = JSON.parse(payloadToparse);
        console.log('[parseNextItemsPayload] JSON parsed successfully, keys:', Object.keys(parsed));
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            return null;
        }
        const nextItemsRaw = parsed.next_items;
        if (!Array.isArray(nextItemsRaw)) {
            return null;
        }
        const items = nextItemsRaw
            .map((item) => {
            if (!item || typeof item !== 'object')
                return null;
            const subject = typeof item.subject === 'string'
                ? item.subject.trim()
                : '';
            const description = typeof item.description === 'string'
                ? item.description.trim()
                : '';
            if (!subject && !description)
                return null;
            return { subject, description };
        })
            .filter((item) => Boolean(item));
        // Extract summary field if present
        const summaryRaw = parsed.summary;
        const summary = typeof summaryRaw === 'string' && summaryRaw.trim() ? summaryRaw.trim() : null;
        // Return if either summary or items exist
        return (items.length > 0 || summary) ? { items, summary } : null;
    }
    catch (e) {
        console.error('[parseNextItemsPayload] JSON parse error:', e);
        console.error('[parseNextItemsPayload] Failed payload:', payload.slice(0, 500));
        return null;
    }
}
function renderNextItemsList(items, summary) {
    // Simple arrow icon for next items
    const arrowSvg = `
<svg class="jp-next-items-icon" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
  <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z"/>
</svg>`;
    // Checkmark icon for summary
    const checkSvg = `
<svg class="jp-summary-icon" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
  <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/>
</svg>`;
    const listItems = items.map((item) => {
        const subject = escapeHtml(item.subject);
        const description = escapeHtml(item.description);
        const subjectHtml = subject ? `<div class="jp-next-items-subject">${subject}</div>` : '';
        const descriptionHtml = description ? `<div class="jp-next-items-description">${description}</div>` : '';
        return `
<li class="jp-next-items-item" data-next-item="true" role="button" tabindex="0">
  <div class="jp-next-items-text">
    ${subjectHtml}
    ${descriptionHtml}
  </div>
  ${arrowSvg}
</li>`;
    }).join('');
    // Get icons for headers
    const summaryIcon = (0,_icons__WEBPACK_IMPORTED_MODULE_0__.getIconByName)('summary', 18);
    const assignmentIcon = (0,_icons__WEBPACK_IMPORTED_MODULE_0__.getIconByName)('assignment', 18);
    // Render summary as separate block above next items
    const summaryHtml = summary ? `
<div class="jp-summary-block">
  <div class="jp-summary-header"><span class="jp-summary-header-icon">${summaryIcon}</span>작업 요약</div>
  <div class="jp-summary-body">
    ${checkSvg}
    <div class="jp-summary-content">${escapeHtml(summary)}</div>
  </div>
</div>` : '';
    // Only show next items section if there are items
    const nextItemsHtml = items.length > 0 ? `
<div class="jp-next-items" data-next-items="true">
  <div class="jp-next-items-header"><span class="jp-next-items-header-icon">${assignmentIcon}</span>다음 단계 제안</div>
  <ul class="jp-next-items-list" role="list">
    ${listItems}
  </ul>
</div>` : '';
    return `${summaryHtml}
${nextItemsHtml}`;
}
/**
 * Highlight Python code with CSS classes for theme support
 */
function highlightPython(code) {
    let highlighted = code;
    // Use CSS classes instead of inline styles for theme support
    const classes = {
        COMMENT: 'syntax-comment',
        STRING: 'syntax-string',
        NUMBER: 'syntax-number',
        KEYWORD: 'syntax-keyword',
        BUILTIN: 'syntax-builtin',
        FUNCTION: 'syntax-function',
        OPERATOR: 'syntax-operator',
        BRACKET: 'syntax-bracket'
    };
    // Use placeholders to preserve order
    const placeholders = [];
    let placeholderIndex = 0;
    // Comments (process first)
    highlighted = highlighted.replace(/(#.*$)/gm, (match) => {
        const id = `__PH${placeholderIndex++}__`;
        placeholders.push({
            id,
            html: `<span class="${classes.COMMENT}">${escapeHtml(match)}</span>`
        });
        return id;
    });
    // Triple-quoted strings
    highlighted = highlighted.replace(/(['"]{3})([\s\S]*?)(\1)/g, (match) => {
        const id = `__PH${placeholderIndex++}__`;
        placeholders.push({
            id,
            html: `<span class="${classes.STRING}">${escapeHtml(match)}</span>`
        });
        return id;
    });
    // Regular strings
    highlighted = highlighted.replace(/(['"])([^'"]*?)(\1)/g, (match) => {
        const id = `__PH${placeholderIndex++}__`;
        placeholders.push({
            id,
            html: `<span class="${classes.STRING}">${escapeHtml(match)}</span>`
        });
        return id;
    });
    // Numbers
    highlighted = highlighted.replace(/\b(\d+\.?\d*)\b/g, (match) => {
        const id = `__PH${placeholderIndex++}__`;
        placeholders.push({
            id,
            html: `<span class="${classes.NUMBER}">${match}</span>`
        });
        return id;
    });
    // Python keywords
    const keywords = [
        'def', 'class', 'if', 'elif', 'else', 'for', 'while', 'return', 'import',
        'from', 'as', 'try', 'except', 'finally', 'with', 'lambda', 'yield',
        'async', 'await', 'pass', 'break', 'continue', 'raise', 'assert', 'del',
        'global', 'nonlocal', 'True', 'False', 'None', 'and', 'or', 'not', 'in', 'is'
    ];
    keywords.forEach(keyword => {
        const regex = new RegExp(`\\b${keyword}\\b`, 'g');
        highlighted = highlighted.replace(regex, (match) => {
            const id = `__PH${placeholderIndex++}__`;
            placeholders.push({
                id,
                html: `<span class="${classes.KEYWORD}">${match}</span>`
            });
            return id;
        });
    });
    // Built-in functions
    const builtins = [
        'print', 'len', 'range', 'str', 'int', 'float', 'list', 'dict', 'tuple',
        'set', 'bool', 'type', 'isinstance', 'issubclass', 'hasattr', 'getattr',
        'setattr', 'delattr', 'dir', 'vars', 'locals', 'globals', 'input', 'open',
        'file', 'abs', 'all', 'any', 'bin', 'chr', 'ord', 'hex', 'oct', 'pow',
        'round', 'sum', 'min', 'max', 'sorted', 'reversed', 'enumerate', 'zip',
        'map', 'filter', 'reduce'
    ];
    builtins.forEach(builtin => {
        const regex = new RegExp(`\\b${builtin}\\b`, 'g');
        highlighted = highlighted.replace(regex, (match) => {
            const id = `__PH${placeholderIndex++}__`;
            placeholders.push({
                id,
                html: `<span class="${classes.BUILTIN}">${match}</span>`
            });
            return id;
        });
    });
    // Function definitions - def keyword followed by function name
    highlighted = highlighted.replace(/(__PH\d+__\s+)([a-zA-Z_][a-zA-Z0-9_]*)/g, (match, defPart, funcName) => {
        const defPlaceholder = placeholders.find(p => p.id === defPart.trim());
        if (defPlaceholder && defPlaceholder.html.includes('def')) {
            const id = `__PH${placeholderIndex++}__`;
            placeholders.push({
                id,
                html: `<span class="${classes.FUNCTION}">${funcName}</span>`
            });
            return defPart + id;
        }
        return match;
    });
    // Process remaining text - escape HTML and handle operators/brackets
    highlighted = highlighted.split(/(__PH\d+__)/g).map(part => {
        if (part.match(/^__PH\d+__$/)) {
            return part; // Keep placeholder as is
        }
        // Escape HTML first
        part = escapeHtml(part);
        // Operators — match on escaped entities too so &gt; &lt; &amp; stay intact
        part = part.replace(/((?:&[a-z]+;|[+\-*/%=<>!&|^~])+)/g, `<span class="${classes.OPERATOR}">$1</span>`);
        // Brackets and delimiters
        part = part.replace(/([()[\]{}])/g, `<span class="${classes.BRACKET}">$1</span>`);
        return part;
    }).join('');
    // Replace placeholders with actual HTML
    placeholders.forEach(ph => {
        highlighted = highlighted.replace(ph.id, ph.html);
    });
    return highlighted;
}
/**
 * diff 출력에 추가/삭제 색상으로 구문 강조
 */
function highlightDiff(code) {
    const lines = code.split('\n');
    const highlightedLines = lines.map(line => {
        const escapedLine = escapeHtml(line);
        // File headers (--- and +++)
        if (line.startsWith('---') || line.startsWith('+++')) {
            return `<span class="diff-header">${escapedLine}</span>`;
        }
        // Hunk headers (@@ ... @@)
        if (line.startsWith('@@')) {
            return `<span class="diff-hunk">${escapedLine}</span>`;
        }
        // Added lines
        if (line.startsWith('+')) {
            return `<span class="diff-add">${escapedLine}</span>`;
        }
        // Removed lines
        if (line.startsWith('-')) {
            return `<span class="diff-del">${escapedLine}</span>`;
        }
        // Context lines (unchanged)
        return `<span class="diff-context">${escapedLine}</span>`;
    });
    return highlightedLines.join('\n');
}
/**
 * diff 코드에서 추가 및 삭제 라인 수 계산
 */
function countDiffLines(code) {
    const lines = code.split('\n');
    let additions = 0;
    let deletions = 0;
    for (const line of lines) {
        // Skip file headers
        if (line.startsWith('+++') || line.startsWith('---'))
            continue;
        if (line.startsWith('+'))
            additions++;
        else if (line.startsWith('-'))
            deletions++;
    }
    return { additions, deletions };
}
/**
 * JavaScript 코드 구문 강조
 */
function highlightJavaScript(code) {
    const escaped = escapeHtml(code);
    const lines = escaped.split('\n');
    const keywords = [
        'function', 'const', 'let', 'var', 'if', 'else', 'for', 'while',
        'return', 'class', 'import', 'export', 'from', 'async', 'await',
        'new', 'this', 'null', 'undefined', 'true', 'false', 'typeof'
    ];
    let inMultilineComment = false;
    const highlightedLines = lines.map(line => {
        // Check for multiline comment continuation
        if (inMultilineComment) {
            const endIndex = line.indexOf('*/');
            if (endIndex !== -1) {
                inMultilineComment = false;
                return `<span class="syntax-comment">${line.substring(0, endIndex + 2)}</span>` +
                    highlightJSTokens(line.substring(endIndex + 2), keywords);
            }
            return `<span class="syntax-comment">${line}</span>`;
        }
        // Single-line comment
        const commentMatch = line.match(/^(\s*)(\/\/.*)$/);
        if (commentMatch) {
            return commentMatch[1] + `<span class="syntax-comment">${commentMatch[2]}</span>`;
        }
        // Multiline comment start
        const multiCommentStart = line.indexOf('/*');
        if (multiCommentStart !== -1) {
            const multiCommentEnd = line.indexOf('*/', multiCommentStart);
            if (multiCommentEnd !== -1) {
                return highlightJSTokens(line.substring(0, multiCommentStart), keywords) +
                    `<span class="syntax-comment">${line.substring(multiCommentStart, multiCommentEnd + 2)}</span>` +
                    highlightJSTokens(line.substring(multiCommentEnd + 2), keywords);
            }
            else {
                inMultilineComment = true;
                return highlightJSTokens(line.substring(0, multiCommentStart), keywords) +
                    `<span class="syntax-comment">${line.substring(multiCommentStart)}</span>`;
            }
        }
        // Comment in middle of line
        const commentIndex = line.indexOf('//');
        if (commentIndex !== -1) {
            return highlightJSTokens(line.substring(0, commentIndex), keywords) +
                `<span class="syntax-comment">${line.substring(commentIndex)}</span>`;
        }
        return highlightJSTokens(line, keywords);
    });
    return highlightedLines.join('\n');
}
/**
 * Highlight JavaScript tokens (keywords, strings, numbers)
 * Uses CSS classes for theme support
 */
function highlightJSTokens(line, keywords) {
    const container = document.createElement('span');
    let i = 0;
    while (i < line.length) {
        // String check (template literal, double quote, single quote)
        if (line[i] === '`') {
            let j = i + 1;
            let escaped = false;
            while (j < line.length) {
                if (line[j] === '\\' && !escaped) {
                    escaped = true;
                    j++;
                    continue;
                }
                if (line[j] === '`' && !escaped)
                    break;
                escaped = false;
                j++;
            }
            if (j < line.length && line[j] === '`') {
                const span = document.createElement('span');
                span.className = 'syntax-string';
                span.textContent = line.substring(i, j + 1);
                container.appendChild(span);
                i = j + 1;
                continue;
            }
        }
        if (line[i] === '"') {
            let j = i + 1;
            let escaped = false;
            while (j < line.length) {
                if (line[j] === '\\' && !escaped) {
                    escaped = true;
                    j++;
                    continue;
                }
                if (line[j] === '"' && !escaped)
                    break;
                escaped = false;
                j++;
            }
            if (j < line.length && line[j] === '"') {
                const span = document.createElement('span');
                span.className = 'syntax-string';
                span.textContent = line.substring(i, j + 1);
                container.appendChild(span);
                i = j + 1;
                continue;
            }
            // Unclosed string - treat rest as string
            const span = document.createElement('span');
            span.className = 'syntax-string';
            span.textContent = line.substring(i);
            container.appendChild(span);
            break;
        }
        if (line[i] === '\'') {
            let j = i + 1;
            let escaped = false;
            while (j < line.length) {
                if (line[j] === '\\' && !escaped) {
                    escaped = true;
                    j++;
                    continue;
                }
                if (line[j] === '\'' && !escaped)
                    break;
                escaped = false;
                j++;
            }
            if (j < line.length && line[j] === '\'') {
                const span = document.createElement('span');
                span.className = 'syntax-string';
                span.textContent = line.substring(i, j + 1);
                container.appendChild(span);
                i = j + 1;
                continue;
            }
            // Unclosed string
            const span = document.createElement('span');
            span.className = 'syntax-string';
            span.textContent = line.substring(i);
            container.appendChild(span);
            break;
        }
        // Number check
        if (/\d/.test(line[i])) {
            let j = i;
            while (j < line.length && /[\d.]/.test(line[j])) {
                j++;
            }
            const span = document.createElement('span');
            span.className = 'syntax-number';
            span.textContent = line.substring(i, j);
            container.appendChild(span);
            i = j;
            continue;
        }
        // Word check (keyword or identifier)
        if (/[a-zA-Z_$]/.test(line[i])) {
            let j = i;
            while (j < line.length && /[a-zA-Z0-9_$]/.test(line[j])) {
                j++;
            }
            const word = line.substring(i, j);
            if (keywords.includes(word)) {
                const span = document.createElement('span');
                span.className = 'syntax-keyword';
                span.textContent = word;
                container.appendChild(span);
            }
            else {
                const textNode = document.createTextNode(word);
                container.appendChild(textNode);
            }
            i = j;
            continue;
        }
        // Regular character
        const textNode = document.createTextNode(line[i]);
        container.appendChild(textNode);
        i++;
    }
    return container.innerHTML;
}
/**
 * Highlight JSON syntax
 * Uses CSS classes for theme support: syntax-string, syntax-number, syntax-keyword, syntax-bracket
 */
function highlightJson(code) {
    // Process the entire code at once using regex replacement
    // Order matters: strings first (to avoid matching keywords inside strings)
    let result = escapeHtml(code);
    // Strings (both keys and values)
    result = result.replace(/&quot;(?:[^\\&]|\\.|&[^;]*;)*?&quot;/g, '<span class="syntax-string">$&</span>');
    // Numbers (integers and floats, including negative)
    result = result.replace(/(?<![a-zA-Z&\w])-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?(?![a-zA-Z\w])/g, '<span class="syntax-number">$&</span>');
    // Booleans and null
    result = result.replace(/\b(true|false|null)\b/g, '<span class="syntax-keyword">$1</span>');
    // Structural characters: { } [ ] , :
    result = result.replace(/([{}\[\],:])/g, '<span class="syntax-bracket">$1</span>');
    return result;
}
/**
 * 텍스트 내 인라인 마크다운 포맷팅 (굵게, 기울임, 인라인 코드)
 */
function formatInlineMarkdown(text) {
    let html = escapeHtml(text);
    // Inline code first (to protect from other transformations)
    html = html.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
    // Bold text (**text**) - use non-greedy match
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    // Italic text (*text*) - use non-greedy match
    html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');
    return html;
}
/**
 * 마크다운 테이블을 HTML로 파싱
 */
function parseMarkdownTable(tableText) {
    const lines = tableText.trim().split('\n');
    if (lines.length < 2)
        return escapeHtml(tableText);
    // Check if it's a valid table (has header separator)
    const separatorIndex = lines.findIndex(line => /^\|?\s*[-:]+[-|\s:]+\s*\|?$/.test(line));
    if (separatorIndex === -1 || separatorIndex === 0)
        return escapeHtml(tableText);
    const headerLines = lines.slice(0, separatorIndex);
    const separatorLine = lines[separatorIndex];
    const bodyLines = lines.slice(separatorIndex + 1);
    // Parse alignment from separator
    const alignments = [];
    const separatorCells = separatorLine.split('|').filter(cell => cell.trim());
    separatorCells.forEach(cell => {
        const trimmed = cell.trim();
        if (trimmed.startsWith(':') && trimmed.endsWith(':')) {
            alignments.push('center');
        }
        else if (trimmed.endsWith(':')) {
            alignments.push('right');
        }
        else {
            alignments.push('left');
        }
    });
    // Build HTML table with wrapper for horizontal scroll
    let html = '<div class="markdown-table-wrapper"><table class="markdown-table">';
    // Header
    html += '<thead>';
    headerLines.forEach(line => {
        html += '<tr>';
        const cells = line.split('|').filter((cell, idx, arr) => {
            // Filter out empty cells from leading/trailing |
            if (idx === 0 && cell.trim() === '')
                return false;
            if (idx === arr.length - 1 && cell.trim() === '')
                return false;
            return true;
        });
        cells.forEach((cell, idx) => {
            const align = alignments[idx] || 'left';
            html += `<th style="text-align: center;">${formatInlineMarkdown(cell.trim())}</th>`;
        });
        html += '</tr>';
    });
    html += '</thead>';
    // Body
    if (bodyLines.length > 0) {
        html += '<tbody>';
        bodyLines.forEach(line => {
            if (!line.trim())
                return;
            html += '<tr>';
            const cells = line.split('|').filter((cell, idx, arr) => {
                if (idx === 0 && cell.trim() === '')
                    return false;
                if (idx === arr.length - 1 && cell.trim() === '')
                    return false;
                return true;
            });
            cells.forEach((cell, idx) => {
                const align = alignments[idx] || 'left';
                html += `<td style="text-align: left;">${formatInlineMarkdown(cell.trim())}</td>`;
            });
            html += '</tr>';
        });
        html += '</tbody>';
    }
    html += '</table></div>';
    return html;
}
/**
 * 마크다운 텍스트를 구문 강조가 적용된 HTML로 변환
 */
/**
 * Native rendermime(marked 파서) 전달 전 전처리.
 * CommonMark에서 **"text"** 같이 delimiter 바로 안쪽에 구두점이 오면
 * left-flanking delimiter로 인식 못하는 문제를 HTML <strong>로 선변환.
 */
function preprocessForRendermime(content) {
    let result = content;
    // Protect code blocks
    const codeBlockPlaceholders = [];
    result = result.replace(/```[\s\S]*?```/g, (match) => {
        const ph = `__PREPROC_CB_${codeBlockPlaceholders.length}__`;
        codeBlockPlaceholders.push({ placeholder: ph, original: match });
        return ph;
    });
    // Protect inline code
    const inlineCodePlaceholders = [];
    result = result.replace(/`[^`]+`/g, (match) => {
        const ph = `__PREPROC_IC_${inlineCodePlaceholders.length}__`;
        inlineCodePlaceholders.push({ placeholder: ph, original: match });
        return ph;
    });
    // Fix bold with punctuation: **"text"** → <strong>"text"</strong>
    // This catches cases where marked fails due to punctuation-adjacent delimiters
    result = result.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    // Restore placeholders (reverse order)
    // Use () => original to avoid $& $' $` special patterns in String.replace
    inlineCodePlaceholders.forEach(({ placeholder, original }) => {
        result = result.replace(placeholder, () => original);
    });
    codeBlockPlaceholders.forEach(({ placeholder, original }) => {
        result = result.replace(placeholder, () => original);
    });
    return result;
}
function formatMarkdownToHtml(text) {
    console.log('[formatMarkdownToHtml] Input text length:', text.length);
    console.log('[formatMarkdownToHtml] Has "next_items":', text.includes('"next_items"'));
    console.log('[formatMarkdownToHtml] Text preview:', text.slice(0, 150));
    const nextItemsBlock = extractNextItemsBlock(text);
    console.log('[formatMarkdownToHtml] nextItemsBlock result:', nextItemsBlock ? 'found' : 'null');
    // Decode HTML entities if present
    const textarea = document.createElement('textarea');
    textarea.innerHTML = nextItemsBlock ? nextItemsBlock.text : text;
    let html = textarea.value;
    // Step 0.5: Protect DataFrame HTML tables (must be before code blocks)
    const dataframeHtmlPlaceholders = [];
    html = html.replace(/<!--DFHTML-->([\s\S]*?)<!--\/DFHTML-->/g, (match, tableHtml) => {
        const placeholder = '__DATAFRAME_HTML_' + Math.random().toString(36).substr(2, 9) + '__';
        dataframeHtmlPlaceholders.push({
            placeholder: placeholder,
            html: tableHtml
        });
        return placeholder;
    });
    // Step 1: Protect code blocks by replacing with placeholders
    const codeBlocks = [];
    const codeBlockPlaceholders = [];
    html = html.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, language, code) => {
        const lang = (language || 'python').toLowerCase();
        const trimmedCode = unescapeHtml(normalizeIndentation(code.trim()));
        // Use content-based hash for stable ID across re-renders
        const contentHash = simpleHash(trimmedCode + lang);
        const blockId = 'code-block-' + contentHash;
        const placeholder = '__CODE_BLOCK_' + blockId + '__';
        codeBlocks.push({
            id: blockId,
            code: trimmedCode,
            language: lang
        });
        // Create HTML for code block
        const isDiff = lang === 'diff';
        const highlightedCode = isDiff
            ? highlightDiff(trimmedCode)
            : lang === 'python' || lang === 'py'
                ? highlightPython(trimmedCode)
                : lang === 'javascript' || lang === 'js'
                    ? highlightJavaScript(trimmedCode)
                    : lang === 'json'
                        ? highlightJson(trimmedCode)
                        : escapeHtml(trimmedCode);
        // For diff blocks, calculate and show line counts
        let diffLineCountHtml = '';
        if (isDiff) {
            const { additions, deletions } = countDiffLines(trimmedCode);
            diffLineCountHtml = '<span class="diff-line-counts">' +
                '<span class="diff-additions">+' + additions + '</span>' +
                '<span class="diff-deletions">-' + deletions + '</span>' +
                '</span>';
        }
        const htmlBlock = '<div class="code-block-container' + (isDiff ? ' diff-block' : '') + '" data-block-id="' + blockId + '">' +
            '<div class="code-block-header">' +
            '<span class="code-block-language">' + escapeHtml(lang) + '</span>' +
            diffLineCountHtml +
            '<div class="code-block-actions">' +
            (isDiff ? '' : '<button class="code-block-apply" data-block-id="' + blockId + '" title="셀에 적용">셀에 적용</button>') +
            '<button class="code-block-copy" data-block-id="' + blockId + '" title="복사">복사</button>' +
            '</div>' +
            '</div>' +
            '<pre class="code-block language-' + escapeHtml(lang) + '"><code id="' + blockId + '">' + highlightedCode + '</code></pre>' +
            '<button class="code-block-toggle" data-block-id="' + blockId + '" title="전체 보기" aria-label="전체 보기" aria-expanded="false">' +
            '<span class="code-block-toggle-icon" aria-hidden="true">▾</span>' +
            '</button>' +
            '</div>';
        codeBlockPlaceholders.push({
            placeholder: placeholder,
            html: htmlBlock
        });
        return placeholder;
    });
    // Step 2: Protect inline code
    const inlineCodePlaceholders = [];
    html = html.replace(/`([^`]+)`/g, (match, code) => {
        const placeholder = '__INLINE_CODE_' + Math.random().toString(36).substr(2, 9) + '__';
        inlineCodePlaceholders.push({
            placeholder: placeholder,
            html: '<code class="inline-code">' + escapeHtml(code) + '</code>'
        });
        return placeholder;
    });
    // Step 3: Parse and protect markdown tables
    const tablePlaceholders = [];
    // Improved table detection: look for lines with | separators and a separator row
    // Match pattern: header row(s), separator row (with ---), body rows
    // More flexible regex to handle various table formats
    const tableRegex = /(?:^|\n)((?:\|[^\n]+\|\n?)+\|[-:| ]+\|(?:\n\|[^\n]+\|)*)/gm;
    html = html.replace(tableRegex, (match, tableBlock) => {
        const placeholder = '__TABLE_' + Math.random().toString(36).substr(2, 9) + '__';
        const tableHtml = parseMarkdownTable(tableBlock.trim());
        tablePlaceholders.push({
            placeholder: placeholder,
            html: tableHtml
        });
        return '\n' + placeholder + '\n';
    });
    // Alternative: tables without leading/trailing | (GFM style)
    // Pattern: "header | header\n---|---\ndata | data"
    const gfmTableRegex = /(?:^|\n)((?:[^\n|]+\|[^\n]+\n)+[-:|\s]+[-|]+\n(?:[^\n|]+\|[^\n]+\n?)*)/gm;
    html = html.replace(gfmTableRegex, (match, tableBlock) => {
        // Skip if already processed (contains placeholder)
        if (tableBlock.includes('__TABLE_'))
            return match;
        const placeholder = '__TABLE_' + Math.random().toString(36).substr(2, 9) + '__';
        const tableHtml = parseMarkdownTable(tableBlock.trim());
        tablePlaceholders.push({
            placeholder: placeholder,
            html: tableHtml
        });
        return '\n' + placeholder + '\n';
    });
    // Third pattern: catch any remaining tables with | characters and --- separator
    const fallbackTableRegex = /(?:^|\n)(\|[^\n]*\|\n\|[-:| ]*\|(?:\n\|[^\n]*\|)*)/gm;
    html = html.replace(fallbackTableRegex, (match, tableBlock) => {
        if (tableBlock.includes('__TABLE_'))
            return match;
        const placeholder = '__TABLE_' + Math.random().toString(36).substr(2, 9) + '__';
        const tableHtml = parseMarkdownTable(tableBlock.trim());
        tablePlaceholders.push({
            placeholder: placeholder,
            html: tableHtml
        });
        return '\n' + placeholder + '\n';
    });
    // Step 4: Escape HTML for non-placeholder text
    html = html.split(/(__(?:DATAFRAME_HTML|CODE_BLOCK|INLINE_CODE|TABLE|NEXT_ITEMS)_[a-z0-9-]+__)/gi)
        .map((part, index) => {
        // Odd indices are placeholders - keep as is
        if (index % 2 === 1)
            return part;
        // Even indices are regular text - escape HTML
        return escapeHtml(part);
    })
        .join('');
    // Step 5: Convert markdown to HTML
    // Headings (process from h6 to h1 to avoid conflicts)
    html = html.replace(/^###### (.*$)/gim, '<h6>$1</h6>');
    html = html.replace(/^##### (.*$)/gim, '<h5>$1</h5>');
    html = html.replace(/^#### (.*$)/gim, '<h4>$1</h4>');
    html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
    html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    // Horizontal rule (---)
    html = html.replace(/^---+$/gim, '<hr>');
    // Links [text](url)
    html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    // Lists - process BEFORE bold/italic to handle "* item" correctly
    // Unordered lists: - or * at start of line
    html = html.replace(/^[\-\*]\s+(.*$)/gim, '<li>$1</li>');
    // Numbered lists: 1. 2. etc
    html = html.replace(/^\d+\.\s+(.*$)/gim, '<li>$1</li>');
    // Bold text (must be before italic) - use non-greedy match to handle nested content
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    // Italic text - only match single * not at line start (to avoid conflict with lists)
    html = html.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
    // Line breaks
    html = html.replace(/\n/g, '<br>');
    // Step 6: Restore table placeholders
    // Use () => to avoid $& $' $` special patterns in String.replace
    tablePlaceholders.forEach(item => {
        html = html.replace(item.placeholder, () => item.html);
    });
    // Step 6.5: Restore DataFrame HTML tables
    dataframeHtmlPlaceholders.forEach(item => {
        html = html.replace(item.placeholder, () => item.html);
    });
    // Step 7: Restore inline code placeholders
    inlineCodePlaceholders.forEach(item => {
        html = html.replace(item.placeholder, () => item.html);
    });
    // Step 8: Restore code block placeholders
    codeBlockPlaceholders.forEach(item => {
        html = html.replace(item.placeholder, () => item.html);
    });
    // Step 8.5: Restore next items list placeholders
    if (nextItemsBlock) {
        html = html.split(nextItemsBlock.placeholder).join(renderNextItemsList(nextItemsBlock.items, nextItemsBlock.summary));
    }
    return html;
}


/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Analytics.js"
/*!***********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Analytics.js ***!
  \***********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2M9 17H7v-5h2zm4 0h-2v-3h2zm0-5h-2v-2h2zm4 5h-2V7h2z"
}), 'Analytics'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/AutoFixHigh.js"
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/AutoFixHigh.js ***!
  \*************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M7.5 5.6 10 7 8.6 4.5 10 2 7.5 3.4 5 2l1.4 2.5L5 7zm12 9.8L17 14l1.4 2.5L17 19l2.5-1.4L22 19l-1.4-2.5L22 14zM22 2l-2.5 1.4L17 2l1.4 2.5L17 7l2.5-1.4L22 7l-1.4-2.5zm-7.63 5.29a.996.996 0 0 0-1.41 0L1.29 18.96c-.39.39-.39 1.02 0 1.41l2.34 2.34c.39.39 1.02.39 1.41 0L16.7 11.05c.39-.39.39-1.02 0-1.41zm-1.03 5.49-2.12-2.12 2.44-2.44 2.12 2.12z"
}), 'AutoFixHigh'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Cancel.js"
/*!********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Cancel.js ***!
  \********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 2C6.47 2 2 6.47 2 12s4.47 10 10 10 10-4.47 10-10S17.53 2 12 2m5 13.59L15.59 17 12 13.41 8.41 17 7 15.59 10.59 12 7 8.41 8.41 7 12 10.59 15.59 7 17 8.41 13.41 12z"
}), 'Cancel'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/ChatBubbleOutline.js"
/*!*******************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/ChatBubbleOutline.js ***!
  \*******************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2m0 14H6l-2 2V4h16z"
}), 'ChatBubbleOutline'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/CheckCircle.js"
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/CheckCircle.js ***!
  \*************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m-2 15-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8z"
}), 'CheckCircle'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/ChevronRight.js"
/*!**************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/ChevronRight.js ***!
  \**************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M10 6 8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"
}), 'ChevronRight'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Close.js"
/*!*******************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Close.js ***!
  \*******************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
}), 'Close'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Code.js"
/*!******************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Code.js ***!
  \******************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M9.4 16.6 4.8 12l4.6-4.6L8 6l-6 6 6 6zm5.2 0 4.6-4.6-4.6-4.6L16 6l6 6-6 6z"
}), 'Code'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Description.js"
/*!*************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Description.js ***!
  \*************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8zm2 16H8v-2h8zm0-4H8v-2h8zm-3-5V3.5L18.5 9z"
}), 'Description'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Error.js"
/*!*******************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Error.js ***!
  \*******************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m1 15h-2v-2h2zm0-4h-2V7h2z"
}), 'Error'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/ExpandLess.js"
/*!************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/ExpandLess.js ***!
  \************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "m12 8-6 6 1.41 1.41L12 10.83l4.59 4.58L18 14z"
}), 'ExpandLess'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/ExpandMore.js"
/*!************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/ExpandMore.js ***!
  \************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z"
}), 'ExpandMore'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Folder.js"
/*!********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Folder.js ***!
  \********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8z"
}), 'Folder'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/GpsFixed.js"
/*!**********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/GpsFixed.js ***!
  \**********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4m8.94 3c-.46-4.17-3.77-7.48-7.94-7.94V1h-2v2.06C6.83 3.52 3.52 6.83 3.06 11H1v2h2.06c.46 4.17 3.77 7.48 7.94 7.94V23h2v-2.06c4.17-.46 7.48-3.77 7.94-7.94H23v-2zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7"
}), 'GpsFixed'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/HourglassEmpty.js"
/*!****************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/HourglassEmpty.js ***!
  \****************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M6 2v6h.01L6 8.01 10 12l-4 4 .01.01H6V22h12v-5.99h-.01L18 16l-4-4 4-3.99-.01-.01H18V2zm10 14.5V20H8v-3.5l4-4zm-4-5-4-4V4h8v3.5z"
}), 'HourglassEmpty'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/InsertDriveFile.js"
/*!*****************************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/InsertDriveFile.js ***!
  \*****************************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M6 2c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm7 7V3.5L18.5 9z"
}), 'InsertDriveFile'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Lightbulb.js"
/*!***********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Lightbulb.js ***!
  \***********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M9 21c0 .5.4 1 1 1h4c.6 0 1-.5 1-1v-1H9zm3-19C8.1 2 5 5.1 5 9c0 2.4 1.2 4.5 3 5.7V17c0 .5.4 1 1 1h6c.6 0 1-.5 1-1v-2.3c1.8-1.3 3-3.4 3-5.7 0-3.9-3.1-7-7-7"
}), 'Lightbulb'));

/***/ },

/***/ "./node_modules/@mui/icons-material/esm/Search.js"
/*!********************************************************!*\
  !*** ./node_modules/@mui/icons-material/esm/Search.js ***!
  \********************************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils/createSvgIcon.js */ "./node_modules/@mui/material/utils/createSvgIcon.js");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
"use client";



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_utils_createSvgIcon_js__WEBPACK_IMPORTED_MODULE_0__["default"])(/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
  d: "M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14"
}), 'Search'));

/***/ }

}]);
//# sourceMappingURL=lib_index_js.ef7dd4246537ac24a21b.js.map