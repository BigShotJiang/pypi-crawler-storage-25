# Paquete Inteligencia Artificial

Paquete de algoritmos de Inteligencia Artificial para aprendizaje de estructura de Redes Bayesianas.

## Instalación
```bash
pip install inteligenciartificial
```

O desde fuente local:
```bash
pip install ./fia
```

## Uso

### Algoritmos de aprendizaje de estructura

#### K2

Algoritmo greedy que requiere un orden topológico de variables. Agrega padres iterativamente si mejoran la métrica de scoring.

```python
from inteligenciartificial.modelografosprobabilisticos.busqueda import K2
from inteligenciartificial.modelografosprobabilisticos.metricas import Entropia, BIC

orden = ["Churn", "tenure_cat", "OnlineSecurity", "TechSupport", "Contract"]
k2 = K2(orden, max_padres=4, df=df_train, metrica=Entropia())
# [K2] Grafos explorados: 35 | Tiempo: 0.1234 s | Throughput: 283.61 grafos/s

modelo = k2.fit(X_train, y_train, alpha=1.0)
```

#### Hill-Climbing

Algoritmo de búsqueda local que en cada paso evalúa operaciones de agregar, eliminar e invertir aristas, seleccionando la que mayor mejora produce.

A partir de la versión 0.0.6 acepta configurar el estado inicial:

- **Por defecto** parte de un grafo vacío.
- `grafo_inicial`: `Grafo` desde el cual iniciar la búsqueda.
- `grafos_iniciales`: lista de `Grafo` para ejecutar varias corridas con inicios manuales.
- `reinicios` + `seed`: número de reinicios desde DAGs aleatorios reproducibles.

```python
from inteligenciartificial.modelografosprobabilisticos.busqueda import HillClimbing
from inteligenciartificial.modelografosprobabilisticos.metricas import BIC
from inteligenciartificial.modelografosprobabilisticos.grafo import Grafo

variables = ["Churn", "tenure_cat", "OnlineSecurity", "TechSupport", "Contract"]

# Inicio por defecto (grafo vacío)
hc = HillClimbing(variables, max_padres=4, df=df_train, metrica=BIC(), max_iter=100)

# Inicio desde un grafo dado
hc = HillClimbing(variables, max_padres=4, df=df_train, metrica=BIC(), max_iter=100,
                  grafo_inicial=Grafo([("Contract", "Churn")]))

# Reinicios aleatorios reproducibles
hc = HillClimbing(variables, max_padres=4, df=df_train, metrica=BIC(), max_iter=100,
                  reinicios=5, seed=42)

# Reinicios manuales
hc = HillClimbing(variables, max_padres=4, df=df_train, metrica=BIC(), max_iter=100,
                  grafos_iniciales=[Grafo([]), Grafo([("Contract", "Churn")])])

modelo = hc.fit(X_train, y_train, alpha=1.0)
```

#### Simulated Annealing

Búsqueda estocástica que en cada iteración propone una operación vecina aleatoria (agregar / eliminar / invertir arista). Si la operación mejora el score se acepta; si lo empeora, se acepta con probabilidad `exp(Δ / T)`. La temperatura decae geométricamente con factor `enfriamiento`.

```python
from inteligenciartificial.modelografosprobabilisticos.busqueda import SimulatedAnnealing
from inteligenciartificial.modelografosprobabilisticos.metricas import BIC

sa = SimulatedAnnealing(
    variables, max_padres=4, df=df_train, metrica=BIC(),
    max_iter=2000, t_inicial=1.0, t_min=1e-3, enfriamiento=0.995, seed=42,
)
modelo = sa.fit(X_train, y_train, alpha=1.0)
```

### Métricas de throughput

Todos los algoritmos (K2, Hill-Climbing y Simulated Annealing) reportan automáticamente al finalizar el entrenamiento:

| Atributo | Descripción |
|---|---|
| `grafos_explorados` | Cantidad de configuraciones de grafo (conjuntos de padres) evaluadas |
| `tiempo_segundos` | Tiempo total de la búsqueda de estructura en segundos |
| `throughput` | Tasa de exploración: `grafos_explorados / tiempo_segundos` (grafos/s) |

```python
print(k2.grafos_explorados)   # e.g., 35
print(k2.tiempo_segundos)     # e.g., 0.1234
print(k2.throughput)           # e.g., 283.61
```

### Métricas de scoring

| Métrica | Descripción |
|---|---|
| `Entropia` | Usa `-H(X\|Pa)` como score (mayor es mejor) |
| `BIC` | Bayesian Information Criterion con penalización `(k/2)*log(N)` |

### Modelos

- **RedBayesiana**: Red Bayesiana discreta con CPTs estimadas por conteos + suavizado Dirichlet(alpha).
- **NaiveBayes**: Caso especial donde todas las features dependen únicamente de la clase.

## Dependencias

- `numpy >= 1.23`
- `pandas >= 1.5`

## Licencia

MIT
