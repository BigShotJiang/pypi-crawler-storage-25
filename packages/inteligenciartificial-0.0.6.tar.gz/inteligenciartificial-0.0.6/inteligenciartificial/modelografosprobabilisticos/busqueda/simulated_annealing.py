# inteligenciartificial/modelografosprobabilisticos/busqueda/simulated_annealing.py

import math
import time
import random
from collections import deque
from typing import List, Optional, Set, Tuple
import pandas as pd
from ..grafo import Grafo
from ..modelos.red_bayesiana import RedBayesiana
from ..utils import ensure_categorical


class SimulatedAnnealing:
    """
    Algoritmo Simulated Annealing clásico para aprendizaje de estructura de
    Redes Bayesianas.

    En cada iteración se propone una operación vecina aleatoria sobre el grafo
    actual (agregar, eliminar o invertir una arista, respetando aciclicidad y
    'max_padres'). Sea Δ = score(nuevo) - score(actual):
      - Si Δ > 0 la operación se acepta siempre.
      - Si Δ ≤ 0 se acepta con probabilidad exp(Δ / T), donde T es la
        temperatura actual.

    Enfriamiento geométrico: T_{k+1} = enfriamiento * T_k.
    Se detiene al alcanzar 'max_iter' iteraciones o cuando T < 't_min'.

    Reporta métricas: grafos explorados, tiempo y throughput (grafos/s).
    """
    def __init__(self, variables: List[str], max_padres: int, df: pd.DataFrame,
                 metrica, alpha: Optional[float] = None,
                 max_iter: int = 1000,
                 t_inicial: float = 1.0,
                 t_min: float = 1e-3,
                 enfriamiento: float = 0.995,
                 grafo_inicial: Optional[Grafo] = None,
                 seed: Optional[int] = None):
        self.variables = variables
        self.max_padres = max_padres
        self.df = ensure_categorical(df)
        self.metrica = metrica
        self.alpha = alpha
        self.max_iter = int(max_iter)
        self.t_inicial = float(t_inicial)
        self.t_min = float(t_min)
        self.enfriamiento = float(enfriamiento)
        self.grafo_inicial = grafo_inicial
        self.seed = seed

        self.grafos_explorados = 0
        self.tiempo_segundos = 0.0
        self.throughput = 0.0

        # Trazas opcionales
        self.iteraciones_realizadas = 0
        self.aceptadas = 0
        self.rechazadas = 0
        self.mejor_score: Optional[float] = None
        self.historia_score: List[float] = []
        self.historia_temperatura: List[float] = []

        self._grafo = self._aprender_estructura()

    # ---------- Utilitarios ----------

    @staticmethod
    def _hay_camino(aristas_set, variables, origen, destino):
        adj = {v: [] for v in variables}
        for u, v in aristas_set:
            adj[u].append(v)
        visitados = set()
        cola = deque([origen])
        while cola:
            nodo = cola.popleft()
            if nodo == destino:
                return True
            if nodo in visitados:
                continue
            visitados.add(nodo)
            for hijo in adj.get(nodo, []):
                cola.append(hijo)
        return False

    @staticmethod
    def _padres_de(aristas, v):
        return sorted(u for u, w in aristas if w == v)

    def _aristas_iniciales(self) -> Set[Tuple[str, str]]:
        if self.grafo_inicial is None:
            return set()
        return {(u, v) for (u, v) in self.grafo_inicial.aristas()
                if u in self.variables and v in self.variables}

    # ---------- Generación de operación vecina aleatoria ----------

    def _operaciones_validas(self, aristas: Set[Tuple[str, str]]):
        """
        Enumera las operaciones (tipo, u, v) válidas en el grafo actual:
        ADD, DEL, REV, respetando aciclicidad y max_padres.
        """
        ops = []
        # ADD
        for u in self.variables:
            for v in self.variables:
                if u == v or (u, v) in aristas:
                    continue
                if len(self._padres_de(aristas, v)) >= self.max_padres:
                    continue
                if self._hay_camino(aristas, self.variables, v, u):
                    continue
                ops.append(('add', u, v))
        # DEL
        for (u, v) in aristas:
            ops.append(('del', u, v))
        # REV
        for (u, v) in aristas:
            if (v, u) in aristas:
                continue
            if len(self._padres_de(aristas, u)) >= self.max_padres:
                continue
            aristas_sin = aristas - {(u, v)}
            if self._hay_camino(aristas_sin, self.variables, u, v):
                continue
            ops.append(('rev', u, v))
        return ops

    def _delta_y_aplicar(self, aristas: Set[Tuple[str, str]],
                         scores: dict, op: Tuple[str, str, str]):
        """
        Calcula el delta de aplicar 'op' y retorna también la información
        suficiente para materializar el cambio si la operación es aceptada.
        """
        tipo, u, v = op
        if tipo == 'add':
            nuevos_padres = sorted(self._padres_de(aristas, v) + [u])
            nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres)
            delta = nuevo_score_v - scores[v]
            return delta, ('add', u, v, {'v': nuevo_score_v})
        if tipo == 'del':
            nuevos_padres = sorted(p for p in self._padres_de(aristas, v) if p != u)
            nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres)
            delta = nuevo_score_v - scores[v]
            return delta, ('del', u, v, {'v': nuevo_score_v})
        # rev
        nuevos_padres_v = sorted(p for p in self._padres_de(aristas, v) if p != u)
        nuevos_padres_u = sorted(self._padres_de(aristas, u) + [v])
        nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres_v)
        nuevo_score_u = self.metrica.score(self.df, u, nuevos_padres_u)
        delta = (nuevo_score_v - scores[v]) + (nuevo_score_u - scores[u])
        return delta, ('rev', u, v, {'v': nuevo_score_v, 'u': nuevo_score_u})

    @staticmethod
    def _aplicar(aristas: Set[Tuple[str, str]], scores: dict, plan):
        tipo = plan[0]
        if tipo == 'add':
            _, u, v, ns = plan
            aristas.add((u, v))
            scores[v] = ns['v']
        elif tipo == 'del':
            _, u, v, ns = plan
            aristas.discard((u, v))
            scores[v] = ns['v']
        elif tipo == 'rev':
            _, u, v, ns = plan
            aristas.discard((u, v))
            aristas.add((v, u))
            scores[v] = ns['v']
            scores[u] = ns['u']

    # ---------- Bucle principal ----------

    def _aprender_estructura(self) -> Grafo:
        inicio = time.perf_counter()
        grafos_explorados = 0
        rng = random.Random(self.seed)

        aristas: Set[Tuple[str, str]] = self._aristas_iniciales()
        scores = {}
        for v in self.variables:
            scores[v] = self.metrica.score(self.df, v, self._padres_de(aristas, v))
            grafos_explorados += 1

        score_actual = sum(scores.values())
        mejor_aristas = set(aristas)
        mejor_scores = dict(scores)
        mejor_score = score_actual

        T = self.t_inicial
        it = 0
        aceptadas = 0
        rechazadas = 0

        while it < self.max_iter and T > self.t_min:
            ops = self._operaciones_validas(aristas)
            if not ops:
                break
            op = rng.choice(ops)
            delta, plan = self._delta_y_aplicar(aristas, scores, op)
            grafos_explorados += 1

            if delta > 0 or rng.random() < math.exp(delta / max(T, 1e-12)):
                self._aplicar(aristas, scores, plan)
                score_actual += delta
                aceptadas += 1
                if score_actual > mejor_score + 1e-12:
                    mejor_score = score_actual
                    mejor_aristas = set(aristas)
                    mejor_scores = dict(scores)
            else:
                rechazadas += 1

            self.historia_score.append(score_actual)
            self.historia_temperatura.append(T)

            T *= self.enfriamiento
            it += 1

        fin = time.perf_counter()
        self.iteraciones_realizadas = it
        self.aceptadas = aceptadas
        self.rechazadas = rechazadas
        self.mejor_score = mejor_score
        self.grafos_explorados = grafos_explorados
        self.tiempo_segundos = fin - inicio
        self.throughput = grafos_explorados / self.tiempo_segundos if self.tiempo_segundos > 0 else float('inf')

        print(f"[SimulatedAnnealing] Iter: {self.iteraciones_realizadas} | "
              f"Aceptadas: {self.aceptadas} | Rechazadas: {self.rechazadas} | "
              f"Grafos explorados: {self.grafos_explorados} | "
              f"Tiempo: {self.tiempo_segundos:.4f} s | "
              f"Throughput: {self.throughput:.2f} grafos/s | "
              f"Mejor score: {self.mejor_score:.4f}")

        grafo = Grafo(list(mejor_aristas))
        for v in self.variables:
            grafo._nodos.add(v)
        return grafo

    # ---------- API pública ----------

    def fit(self, X: pd.DataFrame, y: pd.Series = None, alpha: Optional[float] = None):
        """
        Devuelve una RedBayesiana con CPTs estimadas usando la mejor estructura encontrada.
        'alpha' aquí tiene prioridad sobre el de __init__; si ambos son None, se usa 1.0.
        """
        a = 1.0 if (alpha is None and self.alpha is None) else (self.alpha if alpha is None else alpha)
        rb = RedBayesiana(self._grafo, alpha=a)
        rb.fit(X, y)
        return rb

    def __repr__(self):
        return (f"SimulatedAnnealing(grafo={self._grafo}, "
                f"iter={self.iteraciones_realizadas}, "
                f"grafos_explorados={self.grafos_explorados}, "
                f"throughput={self.throughput:.2f} grafos/s, "
                f"mejor_score={self.mejor_score:.4f})")
