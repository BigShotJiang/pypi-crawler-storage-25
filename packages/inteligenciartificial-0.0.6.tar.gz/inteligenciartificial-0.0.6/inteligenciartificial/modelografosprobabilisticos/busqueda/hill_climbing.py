# inteligenciartificial/modelografosprobabilisticos/busqueda/hill_climbing.py

import time
import random
from collections import deque
from typing import List, Optional, Sequence, Tuple, Set
import pandas as pd
from ..grafo import Grafo
from ..modelos.red_bayesiana import RedBayesiana
from ..utils import ensure_categorical


class HillClimbing:
    """
    Algoritmo Hill-Climbing para aprendizaje de estructura de Redes Bayesianas.

    En cada iteración evalúa tres tipos de operaciones:
      - Agregar una arista (u -> v)
      - Eliminar una arista (u -> v)
      - Invertir una arista (u -> v) a (v -> u)

    Selecciona la operación que mayor mejora produce en el score total y la aplica.
    Se detiene cuando ninguna operación mejora el score o se alcanza 'max_iter'.

    Configuración del estado inicial:
      - Por defecto inicia desde un grafo vacío.
      - 'grafo_inicial' (Grafo) permite indicar un DAG inicial específico.
      - 'grafos_iniciales' (lista de Grafo) ejecuta una corrida por cada grafo inicial.
      - 'reinicios' (int) + 'seed' (int) genera 'reinicios' DAGs iniciales aleatorios
        de manera reproducible y devuelve la mejor estructura encontrada.

    Al finalizar reporta métricas acumuladas: grafos explorados, tiempo y throughput.
    """
    def __init__(self, variables: List[str], max_padres: int, df: pd.DataFrame,
                 metrica, alpha: Optional[float] = None, max_iter: int = 100,
                 grafo_inicial: Optional[Grafo] = None,
                 grafos_iniciales: Optional[Sequence[Grafo]] = None,
                 reinicios: int = 0,
                 seed: Optional[int] = None,
                 prob_arista: float = 0.3):
        self.variables = variables
        self.max_padres = max_padres
        self.df = ensure_categorical(df)
        self.metrica = metrica
        self.alpha = alpha
        self.max_iter = max_iter
        self.grafo_inicial = grafo_inicial
        self.grafos_iniciales = list(grafos_iniciales) if grafos_iniciales is not None else None
        self.reinicios = int(reinicios)
        self.seed = seed
        self.prob_arista = float(prob_arista)

        # Métricas acumuladas sobre todas las corridas
        self.grafos_explorados = 0
        self.tiempo_segundos = 0.0
        self.throughput = 0.0

        # Métricas por corrida (lista de dicts con keys: grafos, tiempo, score, aristas)
        self.corridas = []

        # Mejor score alcanzado y aristas del mejor grafo
        self.mejor_score = None

        self._grafo = self._ejecutar()

    # ---------- Utilitarios estáticos ----------

    @staticmethod
    def _hay_camino(aristas_set, variables, origen, destino):
        """BFS para verificar si existe un camino de 'origen' a 'destino'."""
        adj = {v: [] for v in variables}
        for u, v in aristas_set:
            adj[u].append(v)
        visitados = set()
        cola = deque([origen])
        while cola:
            nodo = cola.popleft()
            if nodo == destino:
                return True
            if nodo in visitados:
                continue
            visitados.add(nodo)
            for hijo in adj.get(nodo, []):
                cola.append(hijo)
        return False

    @staticmethod
    def _padres_de(aristas, v):
        """Devuelve los padres de v en el conjunto de aristas dado."""
        return sorted(u for u, w in aristas if w == v)

    # ---------- Generación de DAGs iniciales aleatorios ----------

    def _dag_aleatorio(self, rng: random.Random) -> Set[Tuple[str, str]]:
        """
        Genera un DAG aleatorio reproducible usando 'rng':
          - Permuta las variables para fijar un orden topológico.
          - Para cada par (i, j) con i < j incluye la arista orden[i] -> orden[j]
            con probabilidad 'self.prob_arista', respetando 'max_padres'.
        """
        orden = list(self.variables)
        rng.shuffle(orden)
        aristas: Set[Tuple[str, str]] = set()
        padres_count = {v: 0 for v in self.variables}
        for j in range(1, len(orden)):
            for i in range(j):
                if padres_count[orden[j]] >= self.max_padres:
                    break
                if rng.random() < self.prob_arista:
                    aristas.add((orden[i], orden[j]))
                    padres_count[orden[j]] += 1
        return aristas

    # ---------- Hill-Climbing desde un estado inicial ----------

    def _aristas_iniciales_desde_grafo(self, g: Optional[Grafo]) -> Set[Tuple[str, str]]:
        if g is None:
            return set()
        # Filtrar aristas que sólo involucren las variables conocidas
        return {(u, v) for (u, v) in g.aristas() if u in self.variables and v in self.variables}

    def _ascenso_desde(self, aristas_init: Set[Tuple[str, str]]):
        """
        Ejecuta Hill-Climbing partiendo del conjunto de aristas dado.
        Devuelve (aristas_finales, score_total, grafos_explorados, tiempo_segundos).
        """
        inicio = time.perf_counter()
        grafos_explorados = 0

        aristas = set(aristas_init)
        # Cache de scores por nodo, considerando los padres iniciales
        scores = {}
        for v in self.variables:
            scores[v] = self.metrica.score(self.df, v, self._padres_de(aristas, v))
            grafos_explorados += 1

        for _ in range(self.max_iter):
            mejor_delta = 0.0
            mejor_op = None

            # --- 1. Operaciones ADD ---
            for u in self.variables:
                for v in self.variables:
                    if u == v or (u, v) in aristas:
                        continue
                    padres_v = self._padres_de(aristas, v)
                    if len(padres_v) >= self.max_padres:
                        continue
                    if self._hay_camino(aristas, self.variables, v, u):
                        continue
                    nuevos_padres = sorted(padres_v + [u])
                    nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres)
                    grafos_explorados += 1
                    delta = nuevo_score_v - scores[v]
                    if delta > mejor_delta + 1e-12:
                        mejor_delta = delta
                        mejor_op = ('add', u, v, {'v': nuevo_score_v})

            # --- 2. Operaciones DELETE ---
            for (u, v) in list(aristas):
                padres_v = self._padres_de(aristas, v)
                nuevos_padres = sorted(p for p in padres_v if p != u)
                nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres)
                grafos_explorados += 1
                delta = nuevo_score_v - scores[v]
                if delta > mejor_delta + 1e-12:
                    mejor_delta = delta
                    mejor_op = ('del', u, v, {'v': nuevo_score_v})

            # --- 3. Operaciones REVERSE ---
            for (u, v) in list(aristas):
                if (v, u) in aristas:
                    continue
                padres_u = self._padres_de(aristas, u)
                if len(padres_u) >= self.max_padres:
                    continue
                aristas_sin = aristas - {(u, v)}
                if self._hay_camino(aristas_sin, self.variables, u, v):
                    continue
                padres_v = self._padres_de(aristas, v)
                nuevos_padres_v = sorted(p for p in padres_v if p != u)
                nuevos_padres_u = sorted(padres_u + [v])
                nuevo_score_v = self.metrica.score(self.df, v, nuevos_padres_v)
                nuevo_score_u = self.metrica.score(self.df, u, nuevos_padres_u)
                grafos_explorados += 1
                delta = (nuevo_score_v - scores[v]) + (nuevo_score_u - scores[u])
                if delta > mejor_delta + 1e-12:
                    mejor_delta = delta
                    mejor_op = ('rev', u, v, {'v': nuevo_score_v, 'u': nuevo_score_u})

            if mejor_op is None:
                break

            op_tipo = mejor_op[0]
            if op_tipo == 'add':
                _, u_op, v_op, new_scores = mejor_op
                aristas.add((u_op, v_op))
                scores[v_op] = new_scores['v']
            elif op_tipo == 'del':
                _, u_op, v_op, new_scores = mejor_op
                aristas.discard((u_op, v_op))
                scores[v_op] = new_scores['v']
            elif op_tipo == 'rev':
                _, u_op, v_op, new_scores = mejor_op
                aristas.discard((u_op, v_op))
                aristas.add((v_op, u_op))
                scores[v_op] = new_scores['v']
                scores[u_op] = new_scores['u']

        fin = time.perf_counter()
        score_total = sum(scores.values())
        return aristas, score_total, grafos_explorados, fin - inicio

    # ---------- Orquestación de corridas ----------

    def _ejecutar(self) -> Grafo:
        # Construir lista de estados iniciales según parámetros
        estados_iniciales: List[Set[Tuple[str, str]]] = []
        etiquetas: List[str] = []

        if self.grafos_iniciales is not None and len(self.grafos_iniciales) > 0:
            for i, g in enumerate(self.grafos_iniciales):
                estados_iniciales.append(self._aristas_iniciales_desde_grafo(g))
                etiquetas.append(f"manual[{i}]")
        elif self.reinicios and self.reinicios > 0:
            rng = random.Random(self.seed)
            # Primer arranque: respetar grafo_inicial si fue dado, si no, vacío
            base = self._aristas_iniciales_desde_grafo(self.grafo_inicial)
            estados_iniciales.append(base)
            etiquetas.append("inicial")
            for i in range(self.reinicios):
                estados_iniciales.append(self._dag_aleatorio(rng))
                etiquetas.append(f"aleatorio[{i}]")
        else:
            estados_iniciales.append(self._aristas_iniciales_desde_grafo(self.grafo_inicial))
            etiquetas.append("inicial")

        mejor_aristas: Optional[Set[Tuple[str, str]]] = None
        mejor_score: Optional[float] = None
        total_grafos = 0
        total_tiempo = 0.0

        for etiqueta, init in zip(etiquetas, estados_iniciales):
            aristas, score_total, ge, t = self._ascenso_desde(init)
            total_grafos += ge
            total_tiempo += t
            self.corridas.append({
                'inicio': etiqueta,
                'grafos_explorados': ge,
                'tiempo_segundos': t,
                'score': score_total,
                'aristas': sorted(aristas),
            })
            if mejor_score is None or score_total > mejor_score:
                mejor_score = score_total
                mejor_aristas = aristas

        self.grafos_explorados = total_grafos
        self.tiempo_segundos = total_tiempo
        self.throughput = total_grafos / total_tiempo if total_tiempo > 0 else float('inf')
        self.mejor_score = mejor_score

        print(f"[HillClimbing] Corridas: {len(self.corridas)} | "
              f"Grafos explorados: {self.grafos_explorados} | "
              f"Tiempo: {self.tiempo_segundos:.4f} s | "
              f"Throughput: {self.throughput:.2f} grafos/s | "
              f"Mejor score: {self.mejor_score:.4f}")

        grafo = Grafo(list(mejor_aristas or []))
        for v in self.variables:
            grafo._nodos.add(v)
        return grafo

    # ---------- API pública ----------

    def fit(self, X: pd.DataFrame, y: pd.Series = None, alpha: Optional[float] = None):
        """
        Devuelve una RedBayesiana con CPTs estimadas.
        'alpha' aquí tiene prioridad sobre el de __init__; si ambos son None, se usa 1.0.
        """
        a = 1.0 if (alpha is None and self.alpha is None) else (self.alpha if alpha is None else alpha)
        rb = RedBayesiana(self._grafo, alpha=a)
        rb.fit(X, y)
        return rb

    def __repr__(self):
        return (f"HillClimbing(grafo={self._grafo}, "
                f"corridas={len(self.corridas)}, "
                f"grafos_explorados={self.grafos_explorados}, "
                f"throughput={self.throughput:.2f} grafos/s)")
