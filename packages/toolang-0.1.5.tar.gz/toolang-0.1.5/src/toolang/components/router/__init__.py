"""HTTP router component implementations."""

