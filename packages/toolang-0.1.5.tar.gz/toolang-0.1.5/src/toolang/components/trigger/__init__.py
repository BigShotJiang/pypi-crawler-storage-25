"""Background trigger component implementations."""

