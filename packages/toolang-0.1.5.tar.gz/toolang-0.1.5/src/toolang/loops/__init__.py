"""Built-in agent loops."""
