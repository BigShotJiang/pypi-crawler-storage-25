"""Built-in model adapters."""
