"""Built-in model providers."""
