# Capability Model

Caps are composable agent primitives.


## Kinds

Current cap kinds are:

- `psyche`
- `skill`
- `service`
- `prompt`


## Runtime Scope

Prepared cap entries use runtime scope:

- `global`: available to all agents under the Toolang root
- `home`: available to one agent home
- `packed`: follows one authored agent program

Precedence is:

1. `packed`
2. `home`
3. `global`

One effective cap set is built by applying this precedence to all visible cap
definitions.

User-facing CLI list commands collapse `home` and `packed` into one `agent`
scope, because both are only available through the selected agent. HTTP read
APIs expose the runtime `scope` values.

HTTP write payloads and internal storage still use `shared` and `private` to
choose authored placement. CLI write commands expose that placement as command
shape instead: without `AGENT`, they write global caps; with `AGENT`, they write
that agent's caps.


## Form, Scope, And Origin

Cap entries separate how a cap is attached, where it is available, and where
its content comes from.

Form tells how a cap is attached:

| Form | Meaning |
| --- | --- |
| `inline` | Defined directly in `agent.too` |
| `cited` | Referenced by `use ...` in `agent.too` |
| `remote` | Connected through `config.toml` |
| `local` | Mounted from local files or folders |

Scope tells where a cap is available:

| Scope | Meaning |
| --- | --- |
| `global` | Available to all agents under the Toolang root |
| `home` | Available to one agent home |
| `packed` | Packed with one authored agent program |

`origin` describes where the cap content is authored:

| Origin | Meaning |
| --- | --- |
| `local` | Local authored content, including inline program declarations and local files or directories |
| `remote` | A remote authored cap fetched through a ref |

Runtime APIs expose effective caps. They do not expose every authored source
variant as a separate history object.

HTTP write payloads default to `private` placement. CLI write commands default
to global caps when `AGENT` is omitted. Only `local` and `remote` forms can
be authored at shared placement and surface as `global`, because they can be
authored at the Toolang root. `cited` and `inline` forms are tied to one
agent program and surface as `packed`.

Authored placement, such as `config.toml`, `agent.too`, or a cap file path, is
exposed separately as `definition_file`. When known, APIs may also include
`line`.


## CLI List Projection

The `caps list` and `caps <kind> list` commands present a compact user-facing
view:

| Column | Meaning |
| --- | --- |
| `SOURCE` | Authored file path, `agent.too` line reference, or directly accessible remote URL |
| `FORM` | Source form: `inline`, `cited`, `remote`, or `local` |
| `SCOPE` | Display scope: `global` or `agent` |

`FORM` uses the same values as the runtime source form. It is not remapped for
display.

`SCOPE` is also projected for CLI readability:

| Runtime scope | CLI `SCOPE` |
| --- | --- |
| `global` | `global` |
| `home` | `agent` |
| `packed` | `agent` |

The `--filter` option accepts kind, form, and display-scope values. Values in
the same group are unioned; conditions across groups are intersected.


## Refs

Public cap refs identify the selected cap itself:

| Ref | Meaning |
| --- | --- |
| `inline://prompts/reviewer` | Embedded inline cap definition |
| `home://services/github` | Private local cap in the agent home |
| `root://skills/reviewer` | Shared local cap under the Toolang root |
| `github://user/repo/path/name.md@rev` | Remote cap target |

GitHub cap refs must include `@rev`. Shorthand refs such as `owner/name`
resolve to the matched repository's default branch before they are stored.
Three-part shorthand such as `owner/repo/name` specifies the repository exactly
and probes only paths inside that repository.

Current cap shorthand probe rules are:

| Kind | Input | Probe order |
| --- | --- | --- |
| `skill` | `owner/name` | `github://owner/agents/skills/name@<default-branch>`, `github://owner/agent-skills/name@<default-branch>`, `github://owner/agent-skills/skills/name@<default-branch>`, `github://owner/skills/name@<default-branch>`, `github://owner/skills/skills/name@<default-branch>` |
| `psyche` | `owner/name` | `github://owner/agents/psyches/name.md@<default-branch>`, `github://owner/agent-psyches/name.md@<default-branch>`, `github://owner/psyches/name.md@<default-branch>` |
| `service` | `owner/name` | `github://owner/agents/services/name.md@<default-branch>`, `github://owner/agent-services/name.md@<default-branch>`, `github://owner/services/name.md@<default-branch>` |
| `prompt` | `owner/name` | `github://owner/agents/prompts/name.md@<default-branch>`, `github://owner/agent-prompts/name.md@<default-branch>`, `github://owner/prompts/name.md@<default-branch>` |

For `owner/repo/name`, Toolang uses the specified repository and probes only
kind-specific paths in that repository. Agents use `agents/name.too`, then
`name.too`. Skills use `skills/name`, then `name`, except dedicated
`agent-skills` and `skills` repositories prefer `name` first. File-backed caps
use `{kind}s/name.md`, then `name.md`, except dedicated cap repositories prefer
`name.md`.

Skill existence checks look for `SKILL.md` inside the candidate directory.
GitHub URLs are exact refs, not shorthand; a URL ending in
`skills/name/SKILL.md` is stored as the parent skill directory ref.


## Local Cap Paths

Shared local caps:

- `${TOOLANG_ROOT}/psyches/`
- `${TOOLANG_ROOT}/skills/`
- `${TOOLANG_ROOT}/services/`
- `${TOOLANG_ROOT}/prompts/`

Private local caps:

- `${TOOLANG_ROOT}/agents/<agent>/psyches/`
- `${TOOLANG_ROOT}/agents/<agent>/skills/`
- `${TOOLANG_ROOT}/agents/<agent>/services/`
- `${TOOLANG_ROOT}/agents/<agent>/prompts/`


## Prepared Cap Paths

Prepared materialized caps live under `.caps` roots:

- `inline` caps are materialized under `.caps/inline`
- `cited` remote caps are materialized under `.caps/cited`
- `remote` caps are materialized under `.caps/remote`

For agent-specific prepared caps, the `.caps` root is
`${TOOLANG_ROOT}/agents/<agent>/.caps`. For global prepared caps, the `.caps` root is
`${TOOLANG_ROOT}/.caps`.


## Local Cap Frontmatter

`skill` and `service` definitions use `description` as their progressive
loading trigger summary. It should be a short natural-language phrase that
helps the model decide whether to load the cap body or service details. The cap
name comes from its file or directory name, not from frontmatter.

Skill frontmatter:

| Field | Required | Meaning |
| --- | --- | --- |
| `description` | yes | Trigger summary used before the skill body is loaded |

Skill bodies are required and contain the loaded workflow instructions. Put the
selection hint in `description`; put the actual workflow, rules, and output
shape in the body.

Service frontmatter:

| Field | Required | Meaning |
| --- | --- | --- |
| `description` | yes | Trigger summary used before service details are loaded |
| `transport` | yes | `http` or `stdio` |
| `target` | yes | Endpoint URL for `http`; argv command line for `stdio` |
| `headers` | no | String map for HTTP headers |
| `env` | no | Comma-separated environment variable names |

Service bodies are optional and can document exposed capabilities, auth notes,
and when optional `headers` or `env` values are expected. Header values like
`$API_TOKEN` declare required host environment variables. For `stdio`, `target`
is written as one shell-like command line, and `env` can list required variables
as `env: API_TOKEN, ANOTHER_ENV_VAR`.


## Effective Cap Set

One activation sees one effective cap set.

The runtime:

1. collects global and agent definitions
2. resolves remote entries
3. materializes runtime-ready artifacts when needed
4. selects the winning definition for each `(kind, name)`

Runs inherit the effective cap set of the activation that executes them.


## HTTP API

Read endpoints:

- `GET /api/v1/caps`
- `GET /api/v1/psyches`
- `GET /api/v1/skills`
- `GET /api/v1/services`
- `GET /api/v1/prompts`
- `GET /api/v1/psyches/{name}`
- `GET /api/v1/skills/{name}`
- `GET /api/v1/services/{name}`
- `GET /api/v1/prompts/{name}`
- `GET /api/v1/psyches/templates`
- `GET /api/v1/skills/templates`
- `GET /api/v1/services/templates`
- `GET /api/v1/prompts/templates`
- `GET /api/v1/psyches/templates/{template_name}`
- `GET /api/v1/skills/templates/{template_name}`
- `GET /api/v1/services/templates/{template_name}`
- `GET /api/v1/prompts/templates/{template_name}`

Write endpoints:

- `PUT /api/v1/psyches/{name}/local`
- `PUT /api/v1/skills/{name}/local`
- `PUT /api/v1/services/{name}/local`
- `PUT /api/v1/prompts/{name}/local`
- `DELETE /api/v1/psyches/{name}/local`
- `DELETE /api/v1/skills/{name}/local`
- `DELETE /api/v1/services/{name}/local`
- `DELETE /api/v1/prompts/{name}/local`
- `PUT /api/v1/psyches/{name}/remote`
- `PUT /api/v1/skills/{name}/remote`
- `PUT /api/v1/services/{name}/remote`
- `PUT /api/v1/prompts/{name}/remote`
- `DELETE /api/v1/psyches/{name}/remote`
- `DELETE /api/v1/skills/{name}/remote`
- `DELETE /api/v1/services/{name}/remote`
- `DELETE /api/v1/prompts/{name}/remote`

Local write requests carry `visibility` and `content`. Remote write requests
carry `visibility` and `ref`. Deletes use a `visibility` query parameter.
`visibility` is the HTTP write-placement field: `shared` maps to globally
authored caps and `private` maps to the current agent's authored caps.

Template detail responses include template metadata and raw content. Cap read
requests return the effective runtime view with `scope`, `origin`, `form`,
`ref`, `definition_file`, and optional `line`. CLI list commands project that
runtime view into `SOURCE`, `FORM`, and display `SCOPE`.
