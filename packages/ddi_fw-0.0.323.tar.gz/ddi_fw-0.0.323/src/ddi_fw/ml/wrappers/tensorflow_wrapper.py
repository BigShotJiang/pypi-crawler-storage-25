from typing import Any, Callable, Dict, List, Optional
from ddi_fw.ml.wrappers.model_wrapper import ModelWrapper
import tensorflow as tf
# from keras.callbacks import EarlyStopping, ModelCheckpoint
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback
from sklearn.model_selection import train_test_split, KFold, StratifiedKFold
import numpy as np
from tensorflow.keras import Model
from ddi_fw.ml.evaluation_helper import Metrics, evaluate

from ddi_fw.ml.tracking_service import TrackingService
import ddi_fw.utils as utils
import os
 

class TFModelWrapper(ModelWrapper):

    def __init__(self, date, descriptor, model_func, tracking_service: TrackingService | None = None, **kwargs):
        super().__init__(date, descriptor, model_func, **kwargs)
        self.batch_size = kwargs.get('batch_size', 128)
        self.epochs = kwargs.get('epochs', 100)
        self.tracking_service = tracking_service
        
    def _to_tf_compatible(self, X):
        """
        Convert nested/object numpy payloads into TF-compatible numeric tensors.
        Supports:
        - ndarray(dtype=object) rows containing arrays/lists/scalars
        - list/tuple/dict structures (multi-input)
        - legacy tuple input: (X, y) -> keeps X only
        """
        # backward compatibility: X can be (X_data, y_data)
        if isinstance(X, tuple) and len(X) == 2:
            X = X[0]

        if isinstance(X, dict):
            return {k: self._to_tf_compatible(v) for k, v in X.items()}

        if isinstance(X, (list, tuple)):
            return type(X)(self._to_tf_compatible(v) for v in X)

        arr = X.to_numpy() if hasattr(X, "to_numpy") else np.asarray(X)

        if arr.dtype == object:
            rows = []
            for row in arr:
                row_obj = np.asarray(row, dtype=object).ravel()
                parts = [np.asarray(cell, dtype=np.float32).ravel() for cell in row_obj]
                rows.append(np.concatenate(parts, axis=0))
            arr = np.stack(rows, axis=0)

        try:
            arr = np.asarray(arr, dtype=np.float32)
        except Exception as ex:
            raise TypeError(f"TensorFlow input conversion failed. dtype={arr.dtype}, shape={arr.shape}") from ex

        return arr

    # TODO think different settings for num_classes
    def fit_model(self, X_train, y_train, X_valid, y_valid):
        X_train = self._to_tf_compatible(X_train)
        y_train = np.asarray(y_train, dtype=np.float32)
        if isinstance(X_train, np.ndarray):
            self.kwargs['input_shape'] = X_train.shape
        else:
            self.kwargs['input_shape'] = self.train_data.shape if hasattr(self.train_data, 'shape') else (None,)
        self.num_classes = y_train.shape[1] if y_train.ndim > 1 else 1
        self.kwargs['num_classes'] = self.num_classes
        model = self.model_func(**self.kwargs)
        checkpoint = ModelCheckpoint(
            filepath=f'{self.descriptor}_validation.weights.h5',
            monitor='val_loss',
            save_best_only=True,
            save_weights_only=True,
            verbose=1,
            mode='min'
        )
        early_stopping = EarlyStopping(
            monitor='val_loss', patience=10, mode='auto')
        if self.tracking_service:
            custom_callback = CustomCallback(self.tracking_service)
            callbacks = [early_stopping, checkpoint, custom_callback]
        else:
            callbacks = [early_stopping, checkpoint]
        train_dataset = tf.data.Dataset.from_tensor_slices((X_train, y_train))
        train_dataset = train_dataset.batch(batch_size=self.batch_size)

        if X_valid is not None and y_valid is not None:
            X_valid = self._to_tf_compatible(X_valid)
            y_valid = np.asarray(y_valid, dtype=np.float32)
            val_dataset = tf.data.Dataset.from_tensor_slices(
                (X_valid, y_valid))
            val_dataset = val_dataset.batch(batch_size=self.batch_size)
        else:
            val_dataset = None

        history = model.fit(
            train_dataset,
            epochs=self.epochs,
            validation_data=val_dataset,
            callbacks=callbacks
        )

        # Check if early stopping was applied
        if early_stopping.stopped_epoch > 0:
            print(
                f"Early stopping was applied at epoch {early_stopping.stopped_epoch}.")
        else:
            print("Early stopping was not applied.")
        if self.tracking_service:
            self.tracking_service.log_param(
                "early_stopping_applied", early_stopping.stopped_epoch > 0)
            self.tracking_service.log_param(
                "early_stopping_epoch", early_stopping.stopped_epoch)
        # ex
        # history = model.fit(
        #     X_train, y_train,
        #     batch_size=self.batch_size,
        #     epochs=self.epochs,
        #     validation_data=(X_valid, y_valid),
        #     callbacks=[early_stopping, checkpoint, custom_callback]
        # )

        if os.path.exists(f'{self.descriptor}_validation.weights.h5'):
            os.remove(f'{self.descriptor}_validation.weights.h5')

        return model, checkpoint

    def fit(self):
        print(self.train_data.shape)
        models = {}
        # rename models_val_acc to models_val_loss
        models_val_acc = {}
        val_preds_dict = {}
        if self.train_idx_arr and self.val_idx_arr:
            for i, (train_idx, val_idx) in enumerate(zip(self.train_idx_arr, self.val_idx_arr)):
                print(f"Validation {i}")
                X_train_cv = self.train_data[train_idx]
                y_train_cv = self.train_label[train_idx]
                X_valid_cv = self.train_data[val_idx]
                y_valid_cv = self.train_label[val_idx]

                def fit_model_cv_func():
                    model, checkpoint = self.fit_model(
                        X_train_cv, y_train_cv, X_valid_cv, y_valid_cv)
                    return model, checkpoint

                if self.tracking_service:
                    model, checkpoint = self.tracking_service.run(
                        run_name=f'Validation {i}', description='CV models', nested_run=True, func=fit_model_cv_func)
                    # with mlflow.start_run(run_name=f'Validation {i}', description='CV models', nested=True) as cv_fit:

                    #     model, checkpoint = self.fit_model(
                    #         X_train_cv, y_train_cv, X_valid_cv, y_valid_cv)
                    #     models[f'{self.descriptor}_validation_{i}'] = model
                    #     models_val_acc[f'{self.descriptor}_validation_{i}'] = checkpoint.best
                else:
                    model, checkpoint = fit_model_cv_func()
                    # model, checkpoint = self.fit_model(
                    #     X_train_cv, y_train_cv, X_valid_cv, y_valid_cv)
                models[f'{self.descriptor}_validation_{i}'] = model
                val_pred = self._predict(model, X_valid_cv)
                val_preds_dict[f'{self.descriptor}_validation_{i}'] = val_pred
                models_val_acc[f'{self.descriptor}_validation_{i}'] = checkpoint.best
        else:
            def fit_model_func():
                model, checkpoint = self.fit_model(
                    self.train_data, self.train_label, None, None)
                return model, checkpoint, None

            if self.tracking_service:
                model, checkpoint = self.tracking_service.run(
                    run_name=f'Training', description='Training', nested_run=True, func=fit_model_func)
                # with mlflow.start_run(run_name=f'Training', description='Training', nested=True) as cv_fit:
                #     model, checkpoint = self.fit_model(
                #         self.train_data, self.train_label, None, None)
                #     models[self.descriptor] = model
                #     models_val_acc[self.descriptor] = checkpoint.best
            else:
                model, checkpoint, _ = fit_model_func()
                # models[self.descriptor] = model
                # models_val_acc[self.descriptor] = checkpoint.best
            models[self.descriptor] = model
            models_val_acc[self.descriptor] = checkpoint.best
        if models_val_acc == {}:
            return model, None, None
        best_model_key = min(models_val_acc, key=lambda k: models_val_acc[k])
        print("best model key: ", best_model_key)
        # best_model_key = max(models_val_acc, key=models_val_acc.get)
        best_model = models[best_model_key]
        val_pred = val_preds_dict.get(best_model_key, None)
        return best_model, best_model_key, val_preds_dict

    # https://github.com/mlflow/mlflow/blob/master/examples/tensorflow/train.py

    def _predict(self, model, X, batch_size=None):
        if batch_size is None:
            batch_size = self.batch_size

        X = self._to_tf_compatible(X)
        dataset = tf.data.Dataset.from_tensor_slices(X).batch(batch_size)
        return model.predict(dataset)

    def predict(self, scenario: Optional[str] = None):
        if self.best_model is None:
            raise RuntimeError("Model not trained yet. Call fit() first.")
        X_test, _ = self._resolve_test_payload(scenario=scenario)
        #TODO test senaryosuna göre test data çözülmeli
        # X_test = self.test_data
        print("Attention")
        print(X_test.shape)
        if(self.is_meta_learner):
          print("meta learner")
        else:
          print("base")
          # X_test = self.test_data
        print(self.test_data.shape)

        if (
            isinstance(X_test, np.ndarray)
            and X_test.ndim == 2
            and isinstance(X_test[0][0], np.ndarray)
        ):
            X_test = np.stack(X_test[:, 0])[:, np.newaxis, :]

        print(X_test.shape)

        return self._predict(model=self.best_model, X=X_test, batch_size=1)

    # def predict(self):
    #     # test_dataset = tf.data.Dataset.from_tensor_slices(
    #     #     (self.test_data, self.test_label))
    #     # test_dataset = test_dataset.batch(batch_size=1)
    #     # # pred = self.best_model.predict(self.test_data)
    #     # pred = self.best_model.predict(test_dataset)
    #     pred = self._predict(model=self.best_model, X=(
    #         self.test_data, self.test_label), batch_size=1)
    #     return pred
    
    
    def fit_and_evaluate(self, print_detail=False) -> tuple[dict[str, Any], Metrics, Any]:
        """
        Fit the model, evaluate it, and log results using the tracking service.

        Args:
            print_detail (bool): Whether to print detailed evaluation logs.

        Returns:
            tuple: A tuple containing logs, metrics, and predictions.
        """
        self.best_model: Model = None

        def evaluate_and_log(artifact_uri=None):
            # Fit the model
            best_model, best_model_key, val_pred = self.fit()
            self.best_model = best_model

            # Make predictions
            pred = self.predict()
            actual = self.test_label

            # Convert predictions and actual labels to categorical format
            pred_as_cat = utils.convert_to_categorical(pred, self.num_classes)
            actual_as_cat = utils.convert_to_categorical(actual, self.num_classes)

            # Evaluate the model
            logs, metrics = evaluate(
                actual=actual_as_cat, pred=pred_as_cat, info=self.descriptor, print_detail=print_detail
            )
            metrics.format_float()

            if self.tracking_service:
                # Log metrics and parameters
                self.tracking_service.log_metrics(logs)
                self.tracking_service.log_param('best_cv', best_model_key)

                # Save metrics to the artifact URI if provided
                if artifact_uri:
                    utils.compress_and_save_data(
                        metrics.__dict__, artifact_uri, f'{self.date}_metrics.gzip'
                    )
                    self.tracking_service.log_artifact(
                        f'{artifact_uri}/{self.date}_metrics.gzip'
                    )

            return logs, metrics, pred

        # Use the tracking service to run the evaluation
        if self.tracking_service:
            return self.tracking_service.run(
                run_name=self.descriptor,
                description="Fit and evaluate the model",
                nested_run=True,
                func=evaluate_and_log
            )
        else:
            # If no tracking service is provided, run the evaluation directly
            return evaluate_and_log()


class CustomCallback(Callback):
    """
    Custom Keras callback for logging training metrics and model summary to MLflow.
    """

    def __init__(self, tracking_service: TrackingService):
        super().__init__()
        self.tracking_service = tracking_service

    # def _mlflow_log(self, func: Callable):
    #     if self.use_mlflow:
    #         func()

    def on_train_begin(self, logs=None):
        if logs is None:
            logs = {}
        if not isinstance(self.model, Model):
            raise TypeError("self.model must be an instance of Model")

        keys = list(logs.keys())

        self.tracking_service.log_param("train_begin_keys", keys)
        # self._mlflow_log(lambda: mlflow.log_param("train_begin_keys", keys))

        # config = self.model.optimizer.get_config()
        config = self.model.get_config()
        for attribute in config:
            self.tracking_service.log_param(
                "opt_" + attribute, config[attribute])
            # self._mlflow_log(lambda: mlflow.log_param(
            #     "opt_" + attribute, config[attribute]))

        sum_list = []
        self.model.summary(print_fn=sum_list.append)
        summary = "\n".join(sum_list)
        self.tracking_service.log_text(
            summary, file_name="model_summary.txt")
        # self._mlflow_log(lambda: mlflow.log_text(
        #     summary, artifact_file="model_summary.txt"))

    def on_train_end(self, logs=None):
        if logs is None:
            logs = {}
        print(logs)
        self.tracking_service.log_metrics(logs)
        # self._mlflow_log(lambda: mlflow.log_metrics(logs))

    def on_epoch_begin(self, epoch, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_epoch_end(self, epoch, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_test_begin(self, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_test_end(self, logs=None):
        if logs is None:
            logs = {}
        self.tracking_service.log_metrics(logs)
        # self._mlflow_log(lambda: mlflow.log_metrics(logs))
        print(logs)

    def on_predict_begin(self, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_predict_end(self, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())
        self.tracking_service.log_metrics(logs)
        # self._mlflow_log(lambda: mlflow.log_metrics(logs))

    def on_train_batch_begin(self, batch, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_train_batch_end(self, batch, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_test_batch_begin(self, batch, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_test_batch_end(self, batch, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_predict_batch_begin(self, batch, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())

    def on_predict_batch_end(self, batch, logs=None):
        if logs is None:
            logs = {}
        keys = list(logs.keys())
