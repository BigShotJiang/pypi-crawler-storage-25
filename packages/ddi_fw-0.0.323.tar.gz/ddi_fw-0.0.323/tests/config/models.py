import tensorflow as tf
from tensorflow import keras
from keras import layers

# from keras import metrics
# from keras.models import Model, Sequential
# # from keras.layers import Dense, Dropout, Input, Activation, BatchNormalization
# from keras.layers import Dense, Dropout, Input, Activation, BatchNormalization,InputLayer,Conv1D,MaxPooling1D,Flatten

event_num = 65
droprate = 0.3

import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

def create_model(**params):
    print("params:")
    print(params)
    input_shape = params.get('input_shape')

    if len(input_shape) == 1:
      s = 1
    else:
      s = input_shape[1]
    model = Sequential([
        Dense(64, activation='relu', input_shape=(s,)),
        Dense(32, activation='relu'),
        Dense(3, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

def DummyModel(**params):
    return None

import torch
import torch.nn as nn
# Define a simple model function
def torch_DNN(**params):
    """
    A simple function to create a Deep Neural Network (DNN) model in PyTorch.
    
    Parameters:
    - params: dictionary containing model parameters
    
    Returns:
    - model: PyTorch model (nn.Sequential)
    """
    input_shape = params.get('input_shape')
    num_classes = params.get('num_classes', event_num) 
    # Define the model using nn.Sequential
    model = nn.Sequential(
        nn.Linear(input_shape[1], 512),            # Input to first hidden layer
        nn.ReLU(),                                # Activation function
        nn.BatchNorm1d(512),                      # Batch Normalization
        nn.Dropout(droprate),                     # Dropout for regularization
        
        nn.Linear(512, 256),                      # Hidden layer 1 to 2
        nn.ReLU(),                                # Activation function
        nn.BatchNorm1d(256),                      # Batch Normalization
        nn.Dropout(droprate),                     # Dropout
        
        nn.Linear(256, num_classes)              # Final output layer
    )
    return model

def LSTM(**params):
    input_shape = params.get('input_shape')
    num_classes = params.get('num_classes', 10)  # Default number of classes
    droprate = params.get('droprate', 0.5)  # Default dropout rate
    
    # Check that input_shape is in the correct format (1, 1536) for LSTM input
    if isinstance(input_shape, tuple) and len(input_shape) == 3:
        samples, timesteps, vector_size = input_shape
    else:
        raise ValueError("Input shape should be a tuple of the form (samples, timesteps, vector_size)")

    model = keras.Sequential()
    model.add(layers.Input(shape=(timesteps, vector_size), name='Inputlayer'))
    
    # LSTM layer with 128 units
    model.add(layers.LSTM(128, activation='relu', return_sequences=False))  
    model.add(layers.BatchNormalization())
    model.add(layers.Dropout(droprate))
    
    # Fully connected layer after LSTM
    model.add(layers.Dense(64, activation='relu'))
    model.add(layers.BatchNormalization())
    model.add(layers.Dropout(droprate))
    
    # Output layer with num_classes neurons, activated with softmax for classification
    model.add(layers.Dense(num_classes))
    model.add(layers.Activation('softmax'))
    
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy', metrics=['accuracy'])
    
    return model


def DNN(**params):
    input_shape = params.get('input_shape')
    num_classes = params.get('num_classes', event_num) 
    vector_size = input_shape[1]
    model = keras.Sequential()
    model.add(keras.layers.Input(shape=(vector_size,), name='Inputlayer'))
    model.add(keras.layers.Dense(512, activation='relu'))
    model.add(keras.layers.BatchNormalization())
    model.add(keras.layers.Dropout(droprate))
    model.add(keras.layers.Dense(256, activation='relu'))
    model.add(keras.layers.BatchNormalization())
    model.add(keras.layers.Dropout(droprate))
    model.add(keras.layers.Dense(num_classes))
    model.add(keras.layers.Activation('softmax'))
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy', metrics=['accuracy'])
# ['accuracy',metrics.Precision() ]
    return model


def CNN(**params):
    # Set default values or get from params
    input_shape = params.get('input_shape')
    sequence_length = input_shape[1]
    embedding_dim = input_shape[2]
    # sequence_length = params.get('sequence_length', 2)  # default to 2
    # embedding_dim = params.get('embedding_dim', 2048)  # default to 2048
    num_classes = params.get('num_classes', event_num)  # default to 65 classes

    # Ensure parameters are correct types
    if not isinstance(sequence_length, int) or not isinstance(embedding_dim, int) or not isinstance(num_classes, int):
        raise ValueError(
            "sequence_length, embedding_dim, and num_classes must be integers")

    # Create the CNN model
    model = keras.Sequential([
        keras.layers.Input(shape=(sequence_length, embedding_dim)),
        keras.layers.Conv1D(128, 1, activation='relu'),
        # keras.layers.MaxPooling1D(pool_size=1),
        keras.layers.MaxPooling1D(pool_size=1, strides=1),
        keras.layers.Flatten(),
        # keras.layers.Dense(64, activation='relu'),
        keras.layers.Dense(num_classes, activation='softmax')
    ])

    # Compile the model
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    return model


def CNN2(**params):
    # Set default values or get from params
    input_shape = params.get('input_shape')
    sequence_length = input_shape[1]
    embedding_dim = input_shape[2]
    # sequence_length = params.get('sequence_length', 2)  # default to 2
    # embedding_dim = params.get('embedding_dim', 2048)  # default to 2048
    num_classes = params.get('num_classes', event_num)  # default to 65 classes

    # Ensure parameters are correct types
    if not isinstance(sequence_length, int) or not isinstance(embedding_dim, int) or not isinstance(num_classes, int):
        raise ValueError(
            "sequence_length, embedding_dim, and num_classes must be integers")

    # Create the CNN model
    model = keras.Sequential([
        keras.layers.Input(
            shape=(sequence_length, embedding_dim)),  # Input layer

        # First Conv1D Layer
        # Larger kernel size and 'same' padding
        keras.layers.Conv1D(128, 3, activation='relu', padding='same'),

        # BatchNormalization for stable training
        keras.layers.BatchNormalization(),

        # MaxPooling1D layer
        # Increased pool size for better downsampling
        keras.layers.MaxPooling1D(pool_size=2),

        # Second Conv1D Layer (with dropout for regularization)
        # Increased number of filters
        keras.layers.Conv1D(256, 3, activation='relu', padding='same'),
        keras.layers.BatchNormalization(),
        keras.layers.Dropout(0.3),  # Dropout layer to avoid overfitting

        # Third Conv1D Layer
        # More filters for richer feature learning
        keras.layers.Conv1D(512, 3, activation='relu', padding='same'),
        keras.layers.BatchNormalization(),
        # Another max pooling to reduce spatial dimensions
        keras.layers.MaxPooling1D(pool_size=2),

        # Flatten layer to prepare for Dense layers
        keras.layers.Flatten(),

        # Fully connected layer (Dense)
        # Added a dense layer for better representation
        keras.layers.Dense(512, activation='relu'),
        keras.layers.Dropout(0.5),  # Additional dropout for regularization

        # Output layer
        # Output layer with softmax for multi-class classification
        keras.layers.Dense(num_classes, activation='softmax')
    ])

    # Compile the model
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    return model


# def DNN_new(vector_size):
#     model = Sequential()
#     model.add(Input(shape=(vector_size,), name='Inputlayer'))
#     _mean = int((vector_size + 512) / 2)
#     model.add(Dense(_mean, activation='relu'))
#     model.add(BatchNormalization())
#     model.add(Dense(512, activation='relu'))
#     model.add(BatchNormalization())
#     model.add(Dropout(droprate))
#     model.add(Dense(256, activation='relu'))
#     model.add(BatchNormalization())
#     model.add(Dropout(droprate))
#     model.add(Dense(event_num))
#     model.add(Activation('softmax'))
#     model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
# # ['accuracy',metrics.Precision() ]
#     return model
