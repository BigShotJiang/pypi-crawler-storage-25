import json
import os
from pathlib import Path

import pytest

from ddi_fw.pipeline import MultiPipeline
def _load_dotenv_if_available() -> None:
    try:
        from dotenv import load_dotenv
    except Exception:
        return
    load_dotenv()

@pytest.fixture(scope="session")
def kaggle_dataset_path():
    """
    Downloads the Kaggle dataset if not present and returns the local path.
    'kagglehub' automatically checks if the dataset is already downloaded.
    """
    _load_dotenv_if_available()
    local_path = os.getenv("OPENFDA_DATASET_PATH")
    if local_path and Path(local_path).exists():
        print(f"\n[INFO] Using local dataset path: {local_path}")
        return local_path

    kagglehub = pytest.importorskip("kagglehub")
    # Ensure credentials are in environment for kagglehub/kaggle
    os.environ['KAGGLE_USERNAME'] = os.getenv('KAGGLE_USERNAME', '')
    os.environ['KAGGLE_KEY'] = os.getenv('KAGGLE_KEY', '')
    if not os.environ['KAGGLE_USERNAME'] or not os.environ['KAGGLE_KEY']:
        pytest.skip("Kaggle credentials not set.")
    
    dataset_handle = "kivancbayraktar/96b9dbee-754d-4a80-a903-bcdc957c2098"
    path = kagglehub.dataset_download(dataset_handle)
    print(f"\n[INFO] Dataset path: {path}")
    return path


@pytest.mark.integration
def test_pipeline_creation_openfda2(kaggle_dataset_path):
    print(f"\n[INFO] Using dataset from: {kaggle_dataset_path}")
    if os.getenv("RUN_INTEGRATION_TESTS") != "1":
        pytest.skip("Set RUN_INTEGRATION_TESTS=1 to enable pipeline tests.")

    config_path = Path("./tests/config/pipeline_kk_all_mpnet.json")
    if not config_path.exists():
        pytest.skip("OpenFDA pipeline config missing.")

    with open(config_path, "r") as f:
        config = json.load(f)

    mp = MultiPipeline(experiments_config=config).build()
    mp.run()
    assert mp.results()


@pytest.mark.integration
def test_pipeline_openfda_multi_scenarios(kaggle_dataset_path):
    print(f"\n[INFO] Using dataset from: {kaggle_dataset_path}")
    if os.getenv("RUN_INTEGRATION_TESTS") != "1":
        pytest.skip("Set RUN_INTEGRATION_TESTS=1 to enable pipeline tests.")

    config_path = Path("./tests/config/pipeline_kk_all_mpnet.json")
    if not config_path.exists():
        pytest.skip("OpenFDA pipeline config missing.")

    with open(config_path, "r") as f:
        config = json.load(f)

    experiment_name = config["experiments"][0]["experiment_name"]

    mp = MultiPipeline(experiments_config=config).build()
    mp.run()
    results = mp.results()

    assert experiment_name in results
    scenario_results = results[experiment_name]
    assert isinstance(scenario_results, dict)

    # Expect scenario keys (kk/ku/uu) when indexes are present
    for scenario in ("kk", "ku", "uu"):
        if scenario in scenario_results:
            assert scenario_results[scenario] is not None