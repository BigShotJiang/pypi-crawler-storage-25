from typing import List, cast

import numpy as np

from ddi_fw.ml.ensemble.ensemble_wrapper import GenericEnsembleWrapper
from ddi_fw.ml.wrappers.model_wrapper import ModelWrapper
from ddi_fw.datasets.processor import DefaultInputProcessor


class DummyBaseWrapper(ModelWrapper):
    def __init__(self, descriptor: str, train_idx_arr, val_idx_arr, train_label, val_preds):
        super().__init__(date="20240101", descriptor=descriptor, model_func=None)
        self.train_idx_arr = train_idx_arr
        self.val_idx_arr = val_idx_arr
        self.train_label = train_label
        self.val_preds = val_preds
        self.num_classes = val_preds[0].shape[1]

    def _predict(self, model, X):
        return None

    def predict(self, scenario=None):
        return None

    def fit_model(self, X_train, y_train, X_valid, y_valid):
        return None

    def fit(self):
        val_preds_dict = {}
        for i, preds in enumerate(self.val_preds):
            val_preds_dict[f"{self.descriptor}_validation_{i}"] = preds
        return None, None, val_preds_dict

    def fit_and_evaluate(self, print_detail=False):
        return {}, None, None


class DummyMetaLearner(ModelWrapper):
    def __init__(self, descriptor: str, num_classes: int = 3):
        super().__init__(date="20240101", descriptor=descriptor, model_func=None)
        self.num_classes = num_classes

    def _predict(self, model, X):
        return None

    def predict(self, scenario=None):
        if self.test_label is None:
            return np.zeros((0, self.num_classes))
        # Return proper class probabilities (simulated random distribution)
        return np.random.dirichlet(np.ones(self.num_classes), len(self.test_label)).astype(np.float32)

    def fit_model(self, X_train, y_train, X_valid, y_valid):
        return None

    def fit(self):
        return None, None, None

    def fit_and_evaluate(self, print_detail=False):
        return {}, None, None


def test_stacking_uses_base_outputs_as_features():
    train_label = np.array([
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1],
        [1, 0, 0],
    ])
    train_idx_arr = [np.array([0, 1]), np.array([2, 3])]
    val_idx_arr = [np.array([2, 3]), np.array([0, 1])]

    base1_preds = [
        np.array([[0.7, 0.2, 0.1], [0.1, 0.8, 0.1]]),
        np.array([[0.2, 0.3, 0.5], [0.6, 0.2, 0.2]]),
    ]
    base2_preds = [
        np.array([[0.6, 0.3, 0.1], [0.2, 0.7, 0.1]]),
        np.array([[0.1, 0.2, 0.7], [0.5, 0.3, 0.2]]),
    ]

    base_wrappers: List[ModelWrapper] = [
        DummyBaseWrapper("base1", train_idx_arr, val_idx_arr, train_label, base1_preds),
        DummyBaseWrapper("base2", train_idx_arr, val_idx_arr, train_label, base2_preds),
    ]
    meta_wrappers: List[ModelWrapper] = [DummyMetaLearner("meta", num_classes=3)]

    meta_learner_processors = {
        "meta": {
            "processor": DefaultInputProcessor,
            "processor_config": {"force_stack": False}
        }
    }

    ensemble = GenericEnsembleWrapper(
        base_wrappers=cast(List[ModelWrapper], base_wrappers),
        meta_learners=cast(List[ModelWrapper], meta_wrappers),
        meta_learner_processors=meta_learner_processors,
        ensemble_strategies="stacking",
        name="ensemble",
    )

    ensemble.fit()

    meta = meta_wrappers[0]
    assert meta.train_data is not None
    assert meta.train_label is not None
    assert meta.train_data.shape == (4, 6)
    assert meta.train_label.shape == (4, 3)
