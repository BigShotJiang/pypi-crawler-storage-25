import os
from typing import List, cast

import numpy as np
import pytest

pytest.importorskip("tensorflow")

from tensorflow import keras

from ddi_fw.datasets.processor import DefaultInputProcessor
from ddi_fw.ml.ensemble.ensemble_wrapper import GenericEnsembleWrapper
from ddi_fw.ml.wrappers.model_wrapper import ModelWrapper
from ddi_fw.ml.wrappers.tensorflow_wrapper import TFModelWrapper


class DummyMetaLearner(ModelWrapper):
    def __init__(self, descriptor: str, num_classes: int = 3):
        super().__init__(date="20240101", descriptor=descriptor, model_func=None)
        self.num_classes = num_classes

    def _predict(self, model, X):
        return None

    def predict(self, scenario=None):
        if self.test_label is None:
            return np.zeros((0, self.num_classes))
        # Return proper class probabilities (simulated random distribution)
        return np.random.dirichlet(np.ones(self.num_classes), len(self.test_label)).astype(np.float32)

    def fit_model(self, X_train, y_train, X_valid, y_valid):
        return None

    def fit(self):
        return None, None, None

    def fit_and_evaluate(self, print_detail=False):
        return {}, None, None


def _simple_tf_model(**params):
    input_shape = params.get("input_shape")
    num_classes = params.get("num_classes", 3)
    model = keras.Sequential(
        [
            keras.layers.Input(shape=(input_shape[1],)),
            keras.layers.Dense(8, activation="relu"),
            keras.layers.Dense(num_classes, activation="softmax"),
        ]
    )
    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
    return model


@pytest.mark.integration
def test_stacking_with_tf_base_models():
    if os.getenv("RUN_TF_TESTS") != "1":
        pytest.skip("Set RUN_TF_TESTS=1 to enable TensorFlow stacking test.")

    rng = np.random.default_rng(42)
    X_train = rng.normal(size=(8, 6)).astype(np.float32)
    y_train = np.eye(3, dtype=np.float32)[rng.integers(0, 3, size=8)]
    X_test = rng.normal(size=(4, 6)).astype(np.float32)
    y_test = np.eye(3, dtype=np.float32)[rng.integers(0, 3, size=4)]

    train_idx_arr = [np.array([0, 1, 2, 3]), np.array([4, 5, 6, 7])]
    val_idx_arr = [np.array([4, 5, 6, 7]), np.array([0, 1, 2, 3])]

    base_wrappers: List[ModelWrapper] = [
        TFModelWrapper("20240101", "base1", _simple_tf_model, epochs=1, batch_size=4),
        TFModelWrapper("20240101", "base2", _simple_tf_model, epochs=1, batch_size=4),
    ]

    for wrapper in base_wrappers:
        wrapper.set_data(train_idx_arr, val_idx_arr, X_train, y_train, X_test, y_test)

    meta_wrappers: List[ModelWrapper] = [DummyMetaLearner("meta", num_classes=3)]

    meta_learner_processors = {
        "meta": {
            "processor": DefaultInputProcessor,
            "processor_config": {"force_stack": False}
        }
    }

    ensemble = GenericEnsembleWrapper(
        base_wrappers=cast(List[ModelWrapper], base_wrappers),
        meta_learners=cast(List[ModelWrapper], meta_wrappers),
        meta_learner_processors=meta_learner_processors,
        ensemble_strategies="stacking",
        name="ensemble",
    )

    ensemble.fit()

    meta = meta_wrappers[0]
    assert meta.train_data is not None
    assert meta.train_label is not None
    assert meta.train_data.shape == (8, 6)
    assert meta.train_label.shape == (8, 3)
