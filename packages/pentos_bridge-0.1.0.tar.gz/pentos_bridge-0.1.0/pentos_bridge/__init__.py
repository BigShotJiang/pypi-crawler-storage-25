"""Pentos Bridge — local MCP server bridging agents to Bittensor subnets."""

__version__ = "0.1.0"
