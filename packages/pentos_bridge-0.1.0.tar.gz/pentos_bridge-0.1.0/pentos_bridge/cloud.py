"""Strue cloud client — wraps all Pentos Gateway API calls."""

from __future__ import annotations

import logging
from typing import Any

import httpx

logger = logging.getLogger(__name__)


class StrueClient:
    """HTTP client for the Strue/Pentos Gateway API."""

    def __init__(self, base_url: str, api_key: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    async def _request(
        self,
        method: str,
        path: str,
        json: dict | None = None,
        timeout: float = 60.0,
    ) -> dict[str, Any]:
        """Make an authenticated request to the Gateway."""
        url = f"{self.base_url}{path}"
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.request(
                method, url, json=json, headers=self._headers()
            )
            resp.raise_for_status()
            return resp.json()

    # --- Inference (OpenAI-compatible) ---

    async def chat_completions(self, payload: dict) -> dict:
        """POST /v1/chat/completions — OpenAI-compatible inference."""
        return await self._request("POST", "/v1/chat/completions", json=payload)

    # --- Research ---

    async def research(self, query: str, depth: str = "standard") -> dict:
        """POST /v1/research — deep research via Arloop."""
        return await self._request("POST", "/v1/research", json={
            "query": query, "depth": depth,
        })

    async def search(self, query: str) -> dict:
        """POST /v1/search — web search via Apex."""
        return await self._request("POST", "/v1/search", json={"query": query})

    # --- Data ---

    async def data_query(
        self,
        source: str = "X",
        keywords: list[str] | None = None,
        usernames: list[str] | None = None,
        limit: int = 100,
    ) -> dict:
        """POST /v1/data — social data from Data Universe."""
        return await self._request("POST", "/v1/data", json={
            "source": source,
            "keywords": keywords or [],
            "usernames": usernames or [],
            "limit": limit,
        })

    # --- Storage ---

    async def store(self, data: str, filename: str = "file.bin", backend: str = "r2") -> dict:
        """POST /v1/store — store file."""
        return await self._request("POST", "/v1/store", json={
            "data": data, "filename": filename, "backend": backend,
        })

    async def retrieve(self, key: str) -> dict:
        """POST /v1/retrieve — retrieve file."""
        return await self._request("POST", "/v1/retrieve", json={"key": key})

    # --- Compute ---

    async def gpu_list(self) -> dict:
        """POST /v1/compute — list available GPUs on Lium."""
        return await self._request("POST", "/v1/compute", json={"action": "list"})

    async def compute(self, payload: dict) -> dict:
        """POST /v1/compute — GPU rental."""
        return await self._request("POST", "/v1/compute", json=payload)

    # --- Memory ---

    async def memory_store(self, content: str, sender: str = "", tags: list[str] | None = None,
                           session_id: str = "") -> dict:
        """POST /v1/memory/store — store a memory."""
        payload: dict = {"content": content}
        if sender:
            payload["sender"] = sender
        if tags:
            payload["tags"] = tags
        if session_id:
            payload["session_id"] = session_id
        return await self._request("POST", "/v1/memory/store", json=payload)

    async def memory_recall(self, query: str, limit: int = 5, session_id: str = "") -> dict:
        """POST /v1/memory/recall — recall relevant memories."""
        payload: dict = {"query": query, "limit": limit}
        if session_id:
            payload["session_id"] = session_id
        return await self._request("POST", "/v1/memory/recall", json=payload)

    async def memory_search(self, query: str, limit: int = 10) -> dict:
        """GET /v1/memory/search — search memories by keyword."""
        return await self._request("GET", f"/v1/memory/search?q={query}&limit={limit}")

    async def memory_forget(self, memory_id: str) -> dict:
        """DELETE /v1/memory/forget — remove a memory."""
        return await self._request("DELETE", "/v1/memory/forget", json={"memory_id": memory_id})

    async def memory_stats(self) -> dict:
        """GET /v1/memory/stats — memory usage statistics."""
        return await self._request("GET", "/v1/memory/stats")

    # --- Health ---

    async def health(self) -> dict:
        """GET / — check Gateway health."""
        try:
            return await self._request("GET", "/", timeout=5.0)
        except Exception:
            return {"status": "unreachable"}
