"""Research identity — self-hosted mTLS certificates for provenance.

Three levels:
  Level 1: Local certificate (Ed25519 key + self-signed X.509 cert, file-based)
  Level 2: GitHub link (OAuth device flow attestation signed with identity key)
  Level 3: Device-bound (private key in OS keychain, not exportable)

Usage:
    from pentos_bridge.identity import IdentityManager
    mgr = IdentityManager()
    mgr.create("jordan")
    info = mgr.load()
    print(info.fingerprint, info.name)
"""

from __future__ import annotations

import hashlib
import json
import logging
import platform
import socket
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

IDENTITY_DIR = Path.home() / ".pentos-bridge" / "identity"

# GitHub OAuth device flow for Pentos (public client ID — no secret needed)
GITHUB_DEVICE_CODE_URL = "https://github.com/login/device/code"
GITHUB_TOKEN_URL = "https://github.com/login/oauth/access_token"
GITHUB_USER_URL = "https://api.github.com/user"
GITHUB_CLIENT_ID = "pentos-bridge"  # Replace with real OAuth app client ID


@dataclass
class IdentityInfo:
    """Loaded identity information."""
    name: str = ""
    fingerprint: str = ""
    created: str = ""
    device_bound: bool = False
    device_hash: str = ""
    # GitHub link
    github_username: str = ""
    github_id: int = 0
    github_linked_at: str = ""
    # ArNS link
    arns_name: str = ""
    arns_verified_at: str = ""
    # Paths
    cert_path: str = ""
    key_path: str = ""

    def to_dict(self) -> dict:
        d: dict[str, Any] = {
            "name": self.name,
            "fingerprint": self.fingerprint,
            "created": self.created,
            "device_bound": self.device_bound,
        }
        if self.device_hash:
            d["device_hash"] = self.device_hash
        if self.github_username:
            d["github"] = {
                "username": self.github_username,
                "id": self.github_id,
                "linked_at": self.github_linked_at,
            }
        if self.arns_name:
            d["arns"] = {
                "name": self.arns_name,
                "verified_at": self.arns_verified_at,
            }
        return d


class IdentityManager:
    """Manages research identity certificates."""

    def __init__(self, identity_dir: Path | str | None = None) -> None:
        self.identity_dir = Path(identity_dir) if identity_dir else IDENTITY_DIR

    @property
    def cert_path(self) -> Path:
        return self.identity_dir / "cert.pem"

    @property
    def key_path(self) -> Path:
        return self.identity_dir / "key.pem"

    @property
    def meta_path(self) -> Path:
        return self.identity_dir / "identity.json"

    @property
    def github_path(self) -> Path:
        return self.identity_dir / "github.json"

    @property
    def arns_path(self) -> Path:
        return self.identity_dir / "arns.json"

    def exists(self) -> bool:
        """Check if an identity exists."""
        return self.cert_path.exists() and self.meta_path.exists()

    # ------------------------------------------------------------------
    # Create identity
    # ------------------------------------------------------------------

    def create(self, name: str, device_bound: bool = False) -> IdentityInfo:
        """Create a new identity with Ed25519 key pair and self-signed X.509 cert.

        Args:
            name: Common name for the certificate (e.g., researcher name)
            device_bound: If True, store private key in OS keychain
        """
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives import serialization
        from cryptography import x509
        from cryptography.x509.oid import NameOID

        self.identity_dir.mkdir(parents=True, exist_ok=True)

        # Generate Ed25519 key pair
        private_key = Ed25519PrivateKey.generate()
        public_key = private_key.public_key()

        # Build self-signed X.509 certificate
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, name),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Pentos Bridge"),
        ])

        now = datetime.now(timezone.utc)
        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(public_key)
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(now + timedelta(days=3650))  # 10 years
            .sign(private_key, algorithm=None)  # Ed25519 doesn't use a hash algorithm
        )

        # Compute fingerprint (SHA-256 of DER-encoded cert)
        cert_der = cert.public_bytes(serialization.Encoding.DER)
        fingerprint = hashlib.sha256(cert_der).hexdigest()

        # Serialize
        cert_pem = cert.public_bytes(serialization.Encoding.PEM)
        key_pem = private_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        )

        # Device hash
        device_hash = ""
        if device_bound:
            device_hash = self._compute_device_hash()

        # Store private key
        key_stored_in_keychain = False
        if device_bound:
            key_stored_in_keychain = self._store_key_in_keychain(key_pem, fingerprint)
            if not key_stored_in_keychain:
                logger.warning(
                    "Could not store key in OS keychain. "
                    "Falling back to file-based storage (Level 1)."
                )

        if not key_stored_in_keychain:
            self.key_path.write_bytes(key_pem)
            self.key_path.chmod(0o600)

        # Write cert
        self.cert_path.write_bytes(cert_pem)

        # Write metadata
        meta = {
            "name": name,
            "fingerprint": fingerprint,
            "created": now.isoformat(),
            "device_bound": device_bound and key_stored_in_keychain,
            "device_hash": device_hash,
            "version": 1,
        }
        self.meta_path.write_text(json.dumps(meta, indent=2))

        return IdentityInfo(
            name=name,
            fingerprint=fingerprint,
            created=now.isoformat(),
            device_bound=device_bound and key_stored_in_keychain,
            device_hash=device_hash,
            cert_path=str(self.cert_path),
            key_path=str(self.key_path) if not key_stored_in_keychain else "(keychain)",
        )

    # ------------------------------------------------------------------
    # Load identity
    # ------------------------------------------------------------------

    def load(self) -> IdentityInfo | None:
        """Load existing identity. Returns None if not found."""
        if not self.exists():
            return None

        meta = json.loads(self.meta_path.read_text())

        info = IdentityInfo(
            name=meta.get("name", ""),
            fingerprint=meta.get("fingerprint", ""),
            created=meta.get("created", ""),
            device_bound=meta.get("device_bound", False),
            device_hash=meta.get("device_hash", ""),
            cert_path=str(self.cert_path),
            key_path=str(self.key_path) if self.key_path.exists() else "(keychain)",
        )

        # Load GitHub link if present
        if self.github_path.exists():
            gh = json.loads(self.github_path.read_text())
            info.github_username = gh.get("github_username", "")
            info.github_id = gh.get("github_id", 0)
            info.github_linked_at = gh.get("linked_at", "")

        # Load ArNS link if present
        if self.arns_path.exists():
            arns = json.loads(self.arns_path.read_text())
            info.arns_name = arns.get("arns_name", "")
            info.arns_verified_at = arns.get("verified_at", "")

        return info

    # ------------------------------------------------------------------
    # Export public cert
    # ------------------------------------------------------------------

    def export_cert(self) -> str:
        """Export the public certificate as PEM string."""
        if not self.cert_path.exists():
            raise IdentityError("No identity found. Run: pentos-bridge identity create")
        return self.cert_path.read_text()

    # ------------------------------------------------------------------
    # GitHub link (Level 2)
    # ------------------------------------------------------------------

    def link_github(self, client_id: str = GITHUB_CLIENT_ID) -> dict:
        """Link identity to GitHub using OAuth device flow.

        Returns:
            dict with github_username, github_id, device_code, user_code, verification_uri
        """
        import httpx

        # Step 1: Request device code
        resp = httpx.post(
            GITHUB_DEVICE_CODE_URL,
            json={"client_id": client_id, "scope": "read:user"},
            headers={"Accept": "application/json"},
        )
        resp.raise_for_status()
        device_data = resp.json()

        return {
            "device_code": device_data["device_code"],
            "user_code": device_data["user_code"],
            "verification_uri": device_data["verification_uri"],
            "expires_in": device_data.get("expires_in", 900),
            "interval": device_data.get("interval", 5),
        }

    def complete_github_link(self, device_code: str, client_id: str = GITHUB_CLIENT_ID) -> dict:
        """Poll for GitHub OAuth completion and save attestation.

        Args:
            device_code: From link_github() response
        """
        import httpx

        # Poll for access token
        resp = httpx.post(
            GITHUB_TOKEN_URL,
            json={
                "client_id": client_id,
                "device_code": device_code,
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            },
            headers={"Accept": "application/json"},
        )
        resp.raise_for_status()
        token_data = resp.json()

        if "error" in token_data:
            return {"error": token_data["error"], "description": token_data.get("error_description", "")}

        access_token = token_data["access_token"]

        # Get user info
        user_resp = httpx.get(
            GITHUB_USER_URL,
            headers={"Authorization": f"Bearer {access_token}", "Accept": "application/json"},
        )
        user_resp.raise_for_status()
        user_data = user_resp.json()

        github_username = user_data.get("login", "")
        github_id = user_data.get("id", 0)

        # Load identity for signing
        identity = self.load()
        if not identity:
            raise IdentityError("No identity found. Create one first.")

        # Create signed attestation
        attestation = {
            "cert_fingerprint": identity.fingerprint,
            "github_username": github_username,
            "github_id": github_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "linked_at": datetime.now(timezone.utc).isoformat(),
        }

        # Sign with private key
        signature = self._sign_data(json.dumps(attestation, sort_keys=True))
        attestation["signature"] = signature

        # Save
        self.github_path.write_text(json.dumps(attestation, indent=2))

        return {
            "github_username": github_username,
            "github_id": github_id,
            "attestation_saved": str(self.github_path),
        }

    # ------------------------------------------------------------------
    # ArNS link
    # ------------------------------------------------------------------

    def link_arns(self, arns_name: str) -> dict:
        """Link identity to an ArNS Primary Name.

        Validates the name resolves via an AR.IO gateway, then stores
        the link in arns.json.

        Args:
            arns_name: The ArNS name (e.g. 'jordan')

        Returns:
            dict with arns_name, verified_at, attestation_saved
        """
        import httpx

        if not self.exists():
            raise IdentityError("No identity found. Create one first.")

        # Validate the ArNS name resolves
        url = f"https://{arns_name}.arweave.net"
        try:
            resp = httpx.head(url, timeout=15.0, follow_redirects=True)
            # Accept any 2xx/3xx — the name exists if the gateway doesn't 404
            if resp.status_code >= 400:
                raise IdentityError(
                    f"ArNS name '{arns_name}' did not resolve. "
                    f"GET {url} returned {resp.status_code}. "
                    f"Make sure the name is registered on ArNS."
                )
        except httpx.ConnectError as e:
            raise IdentityError(f"Could not connect to {url}: {e}")
        except httpx.TimeoutException:
            raise IdentityError(f"Timeout connecting to {url}")

        now = datetime.now(timezone.utc).isoformat()

        # Load identity for signing
        identity = self.load()
        if not identity:
            raise IdentityError("No identity found. Create one first.")

        # Create signed attestation
        attestation = {
            "arns_name": arns_name,
            "cert_fingerprint": identity.fingerprint,
            "verified_at": now,
        }
        signature = self._sign_data(json.dumps(attestation, sort_keys=True))
        attestation["signature"] = signature

        self.arns_path.write_text(json.dumps(attestation, indent=2))

        return {
            "arns_name": arns_name,
            "verified_at": now,
            "attestation_saved": str(self.arns_path),
        }

    # ------------------------------------------------------------------
    # Signing
    # ------------------------------------------------------------------

    def _sign_data(self, data: str) -> str:
        """Sign data with the identity private key. Returns hex-encoded signature."""
        key_pem = self._load_private_key_pem()

        from cryptography.hazmat.primitives.serialization import load_pem_private_key
        private_key = load_pem_private_key(key_pem, password=None)
        signature = private_key.sign(data.encode())  # type: ignore[union-attr]
        return signature.hex()

    def _load_private_key_pem(self) -> bytes:
        """Load private key from file or keychain."""
        if self.key_path.exists():
            return self.key_path.read_bytes()

        # Try keychain
        identity = self.load()
        if identity and identity.device_bound:
            key_data = self._load_key_from_keychain(identity.fingerprint)
            if key_data:
                return key_data

        raise IdentityError("Private key not found. Identity may be corrupted.")

    # ------------------------------------------------------------------
    # Keychain operations (Level 3)
    # ------------------------------------------------------------------

    @staticmethod
    def _store_key_in_keychain(key_pem: bytes, fingerprint: str) -> bool:
        """Store private key in OS keychain. Returns True on success."""
        try:
            import keyring
            keyring.set_password("pentos-bridge-identity", fingerprint, key_pem.decode())
            # Verify it was stored
            stored = keyring.get_password("pentos-bridge-identity", fingerprint)
            return stored is not None
        except Exception as e:
            logger.debug(f"Keychain storage failed: {e}")
            return False

    @staticmethod
    def _load_key_from_keychain(fingerprint: str) -> bytes | None:
        """Load private key from OS keychain."""
        try:
            import keyring
            stored = keyring.get_password("pentos-bridge-identity", fingerprint)
            if stored:
                return stored.encode()
        except Exception as e:
            logger.debug(f"Keychain load failed: {e}")
        return None

    @staticmethod
    def _compute_device_hash() -> str:
        """Compute a hash of device identifiers (hostname + platform + machine ID)."""
        components = [
            socket.gethostname(),
            platform.system(),
            platform.machine(),
            platform.node(),
        ]

        # Try to get a more unique machine ID
        machine_id_paths = [
            "/etc/machine-id",           # Linux
            "/var/lib/dbus/machine-id",  # Linux fallback
        ]
        for p in machine_id_paths:
            path = Path(p)
            if path.exists():
                components.append(path.read_text().strip())
                break

        raw = "|".join(components)
        return hashlib.sha256(raw.encode()).hexdigest()[:32]


class IdentityError(Exception):
    """Identity operation error."""
    pass
