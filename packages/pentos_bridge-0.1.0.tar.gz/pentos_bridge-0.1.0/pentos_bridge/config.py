"""Bridge configuration — loaded from ~/.pentos-bridge/config.json and env vars."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

CONFIG_DIR = Path.home() / ".pentos-bridge"
CONFIG_FILE = CONFIG_DIR / "config.json"

# Model tier definitions
TIER1_LOCAL = ["llama3.2:1b", "qwen2.5:1.5b", "phi-3-mini", "tinyllama", "phi3:mini"]
TIER2_GPU = ["mistral:7b", "llama3.2:8b", "qwen2.5:7b", "llama3.1:8b", "gemma2:9b"]
TIER3_CLOUD = ["deepseek-ai/DeepSeek-V3", "covenant-72b", "llama3.1:70b", "qwen2.5:72b"]


@dataclass
class BridgeConfig:
    """Bridge configuration."""

    strue_api_key: str = ""
    strue_base_url: str = "https://pentos-gateway.strue.workers.dev"
    local_ollama_url: str = "http://localhost:11434"
    local_lm_studio_url: str = "http://localhost:1234"
    local_evermemos_url: str = "http://localhost:1995"
    bridge_port: int = 8787
    prefer_local: bool = True
    memory_sync_enabled: bool = False
    model_tiers: dict = field(default_factory=lambda: {
        "tier1_local": list(TIER1_LOCAL),
        "tier2_gpu": list(TIER2_GPU),
        "tier3_cloud": list(TIER3_CLOUD),
    })

    def save(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(self.to_dict(), indent=2))

    def to_dict(self) -> dict:
        return {
            "strue_api_key": self.strue_api_key,
            "strue_base_url": self.strue_base_url,
            "local_ollama_url": self.local_ollama_url,
            "local_lm_studio_url": self.local_lm_studio_url,
            "local_evermemos_url": self.local_evermemos_url,
            "bridge_port": self.bridge_port,
            "prefer_local": self.prefer_local,
            "memory_sync_enabled": self.memory_sync_enabled,
            "model_tiers": self.model_tiers,
        }

    @classmethod
    def load(cls) -> BridgeConfig:
        """Load config from file, then overlay env vars."""
        config = cls()

        if CONFIG_FILE.exists():
            try:
                data = json.loads(CONFIG_FILE.read_text())
                for k, v in data.items():
                    if hasattr(config, k):
                        setattr(config, k, v)
            except (json.JSONDecodeError, KeyError):
                pass

        # Env vars override file config
        if key := os.environ.get("STRUE_API_KEY"):
            config.strue_api_key = key
        if url := os.environ.get("STRUE_BASE_URL"):
            config.strue_base_url = url
        if port := os.environ.get("BRIDGE_PORT"):
            config.bridge_port = int(port)
        if ollama := os.environ.get("OLLAMA_URL"):
            config.local_ollama_url = ollama
        if lm := os.environ.get("LM_STUDIO_URL"):
            config.local_lm_studio_url = lm
        if evermemos := os.environ.get("EVERMEMOS_URL"):
            config.local_evermemos_url = evermemos

        return config

    @property
    def has_api_key(self) -> bool:
        return bool(self.strue_api_key)

    def get_model_tier(self, model: str) -> int:
        """Return tier (1, 2, 3) for a model name. 0 if unknown."""
        model_lower = model.lower()
        for name in self.model_tiers.get("tier1_local", []):
            if name.lower() in model_lower or model_lower in name.lower():
                return 1
        for name in self.model_tiers.get("tier2_gpu", []):
            if name.lower() in model_lower or model_lower in name.lower():
                return 2
        for name in self.model_tiers.get("tier3_cloud", []):
            if name.lower() in model_lower or model_lower in name.lower():
                return 3
        # Heuristic: check parameter count in name
        return _estimate_tier_from_name(model)


def _estimate_tier_from_name(model: str) -> int:
    """Estimate tier from parameter count in model name."""
    import re
    matches = re.findall(r"(\d+(?:\.\d+)?)b", model.lower())
    if not matches:
        return 1  # Default to local-capable
    params = max(float(m) for m in matches)
    if params >= 30:
        return 3
    if params >= 4:
        return 2
    return 1
