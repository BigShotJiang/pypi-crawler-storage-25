"""Smart router — local when free, Strue cloud when needed.

Routing logic:
- Inference: check if model is available locally → call local. Otherwise → cloud.
- Tier 1 (small): always try local first (CPU ok)
- Tier 2 (medium): local if GPU available, cloud otherwise
- Tier 3 (large/specialized): always cloud
- Non-inference (research, data, storage, compute, training, privacy): always cloud
"""

from __future__ import annotations

import logging
import time
import uuid
from typing import Any

import httpx

from pentos_bridge.config import BridgeConfig
from pentos_bridge.local import LocalRegistry, LocalModel
from pentos_bridge.cloud import StrueClient
from pentos_bridge.models import ChatCompletionRequest, ChatCompletionResponse, ChatChoice, ChatMessage, UsageInfo

logger = logging.getLogger(__name__)

# Request types that always go to cloud
CLOUD_ONLY = {"research", "search_research", "data_query", "store", "retrieve",
              "gpu_list", "compute", "finetune", "vpn", "privacy"}

EVERMEMOS_API_BASE = "/api/v1"


class SmartRouter:
    """Routes requests between local inference and Strue cloud."""

    def __init__(self, config: BridgeConfig, registry: LocalRegistry) -> None:
        self.config = config
        self.registry = registry
        self.cloud = StrueClient(config.strue_base_url, config.strue_api_key)

    async def route_chat_completion(self, request: ChatCompletionRequest) -> tuple[ChatCompletionResponse, str]:
        """Route a chat completion request. Returns (response, routed_via)."""
        model = request.model
        routed_via = "strue-cloud"

        # Check if we can serve locally
        if self.config.prefer_local and self._should_route_local(model):
            local_model = self.registry.get_model(model)
            if local_model:
                try:
                    result = await self._call_local(local_model, request)
                    return result, "local"
                except Exception as e:
                    logger.warning(f"Local inference failed, falling back to cloud: {e}")

        # Cloud fallback
        result = await self._call_cloud(request)
        return result, routed_via

    def _should_route_local(self, model: str) -> bool:
        """Decide if a model should be routed locally."""
        # If the model is explicitly available locally, use it
        if self.registry.has_model(model):
            tier = self.config.get_model_tier(model)
            # Tier 3 models are cloud-only even if somehow loaded locally
            if tier >= 3:
                return False
            return True
        return False

    async def _call_local(self, model: LocalModel, request: ChatCompletionRequest) -> ChatCompletionResponse:
        """Call a local model (Ollama or LM Studio) using OpenAI-compatible API."""
        if model.provider == "ollama":
            url = f"{model.base_url}/v1/chat/completions"
        else:
            url = f"{model.base_url}/v1/chat/completions"

        payload = {
            "model": model.name,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages],
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
        }

        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()

        return self._parse_openai_response(data, model.name)

    async def _call_cloud(self, request: ChatCompletionRequest) -> ChatCompletionResponse:
        """Call Strue cloud for inference."""
        payload = {
            "model": request.model,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages],
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
        }

        data = await self.cloud.chat_completions(payload)
        return self._parse_openai_response(data, request.model)

    @staticmethod
    def _parse_openai_response(data: dict, model: str) -> ChatCompletionResponse:
        """Parse an OpenAI-format response into our model."""
        choices = []
        for c in data.get("choices", []):
            msg = c.get("message", {})
            choices.append(ChatChoice(
                index=c.get("index", 0),
                message=ChatMessage(
                    role=msg.get("role", "assistant"),
                    content=msg.get("content", ""),
                ),
                finish_reason=c.get("finish_reason", "stop"),
            ))

        usage = data.get("usage", {})
        return ChatCompletionResponse(
            id=data.get("id", f"chatcmpl-{uuid.uuid4().hex[:8]}"),
            object="chat.completion",
            created=data.get("created", int(time.time())),
            model=model,
            choices=choices,
            usage=UsageInfo(
                prompt_tokens=usage.get("prompt_tokens", 0),
                completion_tokens=usage.get("completion_tokens", 0),
                total_tokens=usage.get("total_tokens", 0),
            ),
        )

    # --- Non-inference cloud tools ---

    async def research(self, query: str, depth: str = "standard") -> dict:
        return await self.cloud.research(query, depth)

    async def search_research(self, query: str) -> dict:
        return await self.cloud.search(query)

    async def data_query(self, source: str = "X", keywords: list | None = None,
                         usernames: list | None = None, limit: int = 100) -> dict:
        return await self.cloud.data_query(source, keywords, usernames, limit)

    async def store(self, data: str, filename: str = "file.bin") -> dict:
        return await self.cloud.store(data, filename)

    async def retrieve(self, key: str) -> dict:
        return await self.cloud.retrieve(key)

    async def gpu_list(self) -> dict:
        return await self.cloud.gpu_list()

    # --- Memory (local EverMemOS first, cloud fallback) ---

    async def memory_store(self, content: str, sender: str = "", tags: list[str] | None = None,
                           session_id: str = "") -> tuple[dict, str]:
        """Store a memory. Returns (result, source)."""
        if self.registry.evermemos.available:
            try:
                result = await self._call_local_evermemos("POST", "/memories", json={
                    "message_id": f"msg_{uuid.uuid4().hex[:8]}",
                    "create_time": time.strftime("%Y-%m-%dT%H:%M:%S+00:00"),
                    "sender": sender or "bridge_user",
                    "content": content,
                })
                return result, "local"
            except Exception as e:
                logger.warning(f"Local EverMemOS store failed, falling back to cloud: {e}")
        return await self.cloud.memory_store(content, sender, tags, session_id), "cloud"

    async def memory_recall(self, query: str, limit: int = 5, session_id: str = "") -> tuple[dict, str]:
        """Recall relevant memories. Returns (result, source)."""
        if self.registry.evermemos.available:
            try:
                result = await self._call_local_evermemos("POST", "/memories/search", json={
                    "query": query,
                    "user_id": "bridge_user",
                    "limit": limit,
                })
                return {"memories": result.get("results", result.get("memories", [])), "source": "local"}, "local"
            except Exception as e:
                logger.warning(f"Local EverMemOS recall failed, falling back to cloud: {e}")
        result = await self.cloud.memory_recall(query, limit, session_id)
        return result, "cloud"

    async def memory_search(self, query: str, limit: int = 10) -> tuple[dict, str]:
        """Search memories. Returns (result, source)."""
        if self.registry.evermemos.available:
            try:
                result = await self._call_local_evermemos("POST", "/memories/search", json={
                    "query": query,
                    "user_id": "bridge_user",
                    "limit": limit,
                })
                return {"memories": result.get("results", result.get("memories", [])), "source": "local"}, "local"
            except Exception as e:
                logger.warning(f"Local EverMemOS search failed, falling back to cloud: {e}")
        return await self.cloud.memory_search(query, limit), "cloud"

    async def memory_forget(self, memory_id: str) -> tuple[dict, str]:
        """Delete a memory. Returns (result, source)."""
        if self.registry.evermemos.available:
            try:
                result = await self._call_local_evermemos("DELETE", f"/memories/{memory_id}")
                return result, "local"
            except Exception as e:
                logger.warning(f"Local EverMemOS forget failed, falling back to cloud: {e}")
        return await self.cloud.memory_forget(memory_id), "cloud"

    async def memory_stats(self) -> tuple[dict, str]:
        """Get memory stats. Returns (result, source)."""
        if self.registry.evermemos.available:
            try:
                result = await self._call_local_evermemos("GET", "/stats")
                return result, "local"
            except Exception as e:
                logger.warning(f"Local EverMemOS stats failed, falling back to cloud: {e}")
        return await self.cloud.memory_stats(), "cloud"

    async def _call_local_evermemos(self, method: str, path: str, json: dict | None = None) -> dict:
        """Call the local EverMemOS API."""
        url = f"{self.registry.evermemos.url}{EVERMEMOS_API_BASE}{path}"
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.request(method, url, json=json)
            resp.raise_for_status()
            return resp.json()
