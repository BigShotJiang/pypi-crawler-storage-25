"""MCP server — exposes Strue tools to Claude Desktop, Cursor, Windsurf.

Supports both stdio mode (for Claude Desktop) and HTTP mode.
Uses the mcp Python SDK for proper protocol compliance.
"""

from __future__ import annotations

import json
import sys
import asyncio
import logging
from typing import Any

from pentos_bridge.config import BridgeConfig
from pentos_bridge.local import LocalRegistry
from pentos_bridge.router import SmartRouter
from pentos_bridge.models import ChatMessage, ChatCompletionRequest

logger = logging.getLogger(__name__)


# --- Stdio MCP implementation (no SDK dependency) ---
# Implements JSON-RPC 2.0 over stdin/stdout per MCP spec

TOOL_DEFINITIONS = [
    {
        "name": "inference",
        "description": "Chat completion — routes to local model if available, Strue cloud if not. Returns OpenAI-compatible response.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "The user message to send"},
                "model": {"type": "string", "description": "Model name (e.g. llama3.2:8b, deepseek-ai/DeepSeek-V3)", "default": "qwen2.5:1.5b"},
                "max_tokens": {"type": "integer", "description": "Max tokens to generate", "default": 256},
            },
            "required": ["prompt"],
        },
    },
    {
        "name": "research",
        "description": "Deep research via Arloop pipeline. Always routes to Strue cloud.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Research question"},
                "depth": {"type": "string", "enum": ["quick", "standard", "deep"], "default": "standard"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "search_research",
        "description": "Search existing Arloop research library.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "data_query",
        "description": "Query real-time social data from Data Universe (X, Reddit, YouTube).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "source": {"type": "string", "enum": ["X", "Reddit", "YouTube"], "default": "X"},
                "keywords": {"type": "array", "items": {"type": "string"}, "description": "Keywords to search"},
                "usernames": {"type": "array", "items": {"type": "string"}, "description": "Usernames to filter"},
                "limit": {"type": "integer", "default": 100},
            },
        },
    },
    {
        "name": "store",
        "description": "Store files on decentralized storage (R2, Arweave, Hippius).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "data": {"type": "string", "description": "Base64-encoded file content"},
                "filename": {"type": "string", "default": "file.bin"},
            },
            "required": ["data"],
        },
    },
    {
        "name": "retrieve",
        "description": "Retrieve stored files by key.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Storage key or URL"},
            },
            "required": ["key"],
        },
    },
    {
        "name": "gpu_list",
        "description": "List available GPUs on Lium (SN51).",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "memory_store",
        "description": "Store a memory. Routes to local EverMemOS if available, Strue cloud otherwise. Costs 1 credit on cloud.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Memory content to store"},
                "sender": {"type": "string", "description": "Sender identifier", "default": ""},
                "tags": {"type": "array", "items": {"type": "string"}, "description": "Tags for categorization"},
                "session_id": {"type": "string", "description": "Session ID for grouping", "default": ""},
            },
            "required": ["content"],
        },
    },
    {
        "name": "memory_recall",
        "description": "Recall relevant memories for a given context. Free to use. Routes to local EverMemOS if available.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "What to recall (e.g. 'what language does the user prefer')"},
                "limit": {"type": "integer", "description": "Max memories to return", "default": 5},
                "session_id": {"type": "string", "description": "Session ID to scope recall", "default": ""},
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_search",
        "description": "Search memories by keyword or semantic similarity. Free to use.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "limit": {"type": "integer", "description": "Max results", "default": 10},
            },
            "required": ["query"],
        },
    },
    {
        "name": "memory_forget",
        "description": "Delete a specific memory by ID. Free to use.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "memory_id": {"type": "string", "description": "ID of the memory to delete"},
            },
            "required": ["memory_id"],
        },
    },
]


class MCPStdioServer:
    """MCP server communicating over stdin/stdout (JSON-RPC 2.0)."""

    def __init__(self, config: BridgeConfig, registry: LocalRegistry, router: SmartRouter) -> None:
        self.config = config
        self.registry = registry
        self.router = router

    async def run(self) -> None:
        """Run the stdio MCP server — reads JSON-RPC from stdin, writes to stdout."""
        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)
        await asyncio.get_event_loop().connect_read_pipe(lambda: protocol, sys.stdin.buffer)

        # Initial scan
        await self.registry.scan()

        logger.info(f"MCP stdio server started. {len(self.registry.models)} local models.")

        while True:
            try:
                line = await reader.readline()
                if not line:
                    break

                line_str = line.decode("utf-8").strip()
                if not line_str:
                    continue

                request = json.loads(line_str)
                response = await self._handle_request(request)
                if response is not None:
                    self._write_response(response)

            except json.JSONDecodeError as e:
                self._write_response({
                    "jsonrpc": "2.0",
                    "error": {"code": -32700, "message": f"Parse error: {e}"},
                    "id": None,
                })
            except Exception as e:
                logger.error(f"MCP error: {e}")
                break

    def _write_response(self, response: dict) -> None:
        """Write a JSON-RPC response to stdout."""
        out = json.dumps(response) + "\n"
        sys.stdout.write(out)
        sys.stdout.flush()

    async def _handle_request(self, request: dict) -> dict | None:
        """Handle a single JSON-RPC request."""
        method = request.get("method", "")
        req_id = request.get("id")
        params = request.get("params", {})

        if method == "initialize":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {
                        "name": "pentos-bridge",
                        "version": "0.1.0",
                    },
                },
            }

        if method == "notifications/initialized":
            return None  # No response for notifications

        if method == "tools/list":
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {"tools": TOOL_DEFINITIONS},
            }

        if method == "tools/call":
            tool_name = params.get("name", "")
            arguments = params.get("arguments", {})
            result = await self._call_tool(tool_name, arguments)
            return {
                "jsonrpc": "2.0",
                "id": req_id,
                "result": {
                    "content": [{"type": "text", "text": json.dumps(result, default=str)}],
                },
            }

        # Unknown method
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": -32601, "message": f"Unknown method: {method}"},
        }

    async def _call_tool(self, name: str, args: dict) -> dict:
        """Execute an MCP tool call via the router."""
        try:
            if name == "inference":
                request = ChatCompletionRequest(
                    model=args.get("model", "qwen2.5:1.5b"),
                    messages=[ChatMessage(role="user", content=args.get("prompt", ""))],
                    max_tokens=args.get("max_tokens", 256),
                )
                result, via = await self.router.route_chat_completion(request)
                return {
                    "response": result.model_dump(),
                    "routed_via": via,
                }

            elif name == "research":
                return await self.router.research(args["query"], args.get("depth", "standard"))

            elif name == "search_research":
                return await self.router.search_research(args["query"])

            elif name == "data_query":
                return await self.router.data_query(
                    source=args.get("source", "X"),
                    keywords=args.get("keywords"),
                    usernames=args.get("usernames"),
                    limit=args.get("limit", 100),
                )

            elif name == "store":
                return await self.router.store(args["data"], args.get("filename", "file.bin"))

            elif name == "retrieve":
                return await self.router.retrieve(args["key"])

            elif name == "gpu_list":
                return await self.router.gpu_list()

            elif name == "memory_store":
                result, source = await self.router.memory_store(
                    content=args["content"],
                    sender=args.get("sender", ""),
                    tags=args.get("tags"),
                    session_id=args.get("session_id", ""),
                )
                return {"result": result, "source": source}

            elif name == "memory_recall":
                result, source = await self.router.memory_recall(
                    query=args["query"],
                    limit=args.get("limit", 5),
                    session_id=args.get("session_id", ""),
                )
                return {"result": result, "source": source}

            elif name == "memory_search":
                result, source = await self.router.memory_search(
                    query=args["query"],
                    limit=args.get("limit", 10),
                )
                return {"result": result, "source": source}

            elif name == "memory_forget":
                result, source = await self.router.memory_forget(args["memory_id"])
                return {"result": result, "source": source}

            else:
                return {"error": f"Unknown tool: {name}"}

        except Exception as e:
            return {"error": str(e)}
