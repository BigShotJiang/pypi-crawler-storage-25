"""FastAPI server — OpenAI-compatible endpoint + health."""

from __future__ import annotations

import time
import uuid
import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from pentos_bridge.config import BridgeConfig
from pentos_bridge.local import LocalRegistry
from pentos_bridge.router import SmartRouter
from pentos_bridge.models import (
    ChatCompletionRequest,
    ChatCompletionResponse,
    HealthResponse,
    LocalModelInfo,
)

logger = logging.getLogger(__name__)


def create_app(config: BridgeConfig, registry: LocalRegistry, router: SmartRouter) -> FastAPI:
    """Create the FastAPI application."""

    app = FastAPI(title="Pentos Bridge", version="0.1.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Store refs on app state
    app.state.config = config
    app.state.registry = registry
    app.state.router = router

    @app.get("/")
    async def root():
        return {
            "name": "pentos-bridge",
            "version": "0.1.0",
            "status": "running",
        }

    @app.get("/health")
    async def health():
        reg: LocalRegistry = app.state.registry
        cloud_status = "configured" if config.has_api_key else "no-api-key"

        local_models = [
            LocalModelInfo(name=m.name, provider=m.provider, url=m.base_url)
            for m in reg.models
        ]

        resp = HealthResponse(
            status="ok",
            local_models=local_models,
            cloud_status=cloud_status,
            cloud_url=config.strue_base_url,
        )
        data = resp.model_dump()
        data["memory"] = {
            "available": reg.evermemos.available,
            "url": reg.evermemos.url,
            "version": reg.evermemos.version,
            "memory_count": reg.evermemos.memory_count,
        }
        return data

    @app.get("/v1/models")
    async def list_models():
        """List available models (local + cloud)."""
        reg: LocalRegistry = app.state.registry
        models = []

        for m in reg.models:
            models.append({
                "id": m.name,
                "object": "model",
                "owned_by": f"local-{m.provider}",
            })

        # Add well-known cloud models
        for name in config.model_tiers.get("tier3_cloud", []):
            models.append({
                "id": name,
                "object": "model",
                "owned_by": "strue-cloud",
            })

        return {"object": "list", "data": models}

    @app.post("/v1/chat/completions")
    async def chat_completions(request: ChatCompletionRequest):
        """OpenAI-compatible chat completions — routes local or cloud."""
        rtr: SmartRouter = app.state.router

        try:
            result, routed_via = await rtr.route_chat_completion(request)
            result.x_routed_via = routed_via

            # Return as dict with the routing header info
            response_data = result.model_dump()
            response = JSONResponse(content=response_data)
            response.headers["X-Routed-Via"] = routed_via
            return response

        except Exception as e:
            logger.error(f"Chat completion error: {e}")
            return JSONResponse(
                status_code=502,
                content={"error": {"message": str(e), "type": "bridge_error"}},
            )

    return app
