"""Local model detection — Ollama and LM Studio scanning with periodic refresh."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

import httpx

logger = logging.getLogger(__name__)


@dataclass
class LocalModel:
    """A model available on a local inference server."""
    name: str
    provider: str  # "ollama" or "lm-studio"
    base_url: str  # e.g. "http://localhost:11434"


@dataclass
class EverMemOSInfo:
    """Status info for a local EverMemOS instance."""
    available: bool = False
    url: str = "http://localhost:1995"
    version: str = ""
    memory_count: int = 0


@dataclass
class LocalRegistry:
    """Tracks all locally available models and services. Re-scans periodically."""

    ollama_url: str = "http://localhost:11434"
    lm_studio_url: str = "http://localhost:1234"
    evermemos_url: str = "http://localhost:1995"
    models: list[LocalModel] = field(default_factory=list)
    evermemos: EverMemOSInfo = field(default_factory=EverMemOSInfo)
    _scan_task: asyncio.Task | None = field(default=None, repr=False)

    @property
    def model_names(self) -> list[str]:
        return [m.name for m in self.models]

    def has_model(self, name: str) -> bool:
        name_lower = name.lower()
        return any(m.name.lower() == name_lower for m in self.models)

    def get_model(self, name: str) -> LocalModel | None:
        name_lower = name.lower()
        for m in self.models:
            if m.name.lower() == name_lower:
                return m
        return None

    def get_any_model(self) -> LocalModel | None:
        """Return the first available local model, or None."""
        return self.models[0] if self.models else None

    async def scan(self) -> list[LocalModel]:
        """Scan for Ollama, LM Studio models, and EverMemOS. Updates self.models."""
        found: list[LocalModel] = []

        ollama, lm, _evermemos = await asyncio.gather(
            self._scan_ollama(),
            self._scan_lm_studio(),
            self._scan_evermemos(),
            return_exceptions=True,
        )

        if isinstance(ollama, list):
            found.extend(ollama)
        if isinstance(lm, list):
            found.extend(lm)

        self.models = found
        return found

    def scan_sync(self) -> list[LocalModel]:
        """Synchronous scan wrapper."""
        return asyncio.run(self.scan())

    async def start_periodic_scan(self, interval: int = 60) -> None:
        """Start background scanning every `interval` seconds."""
        self._scan_task = asyncio.create_task(self._periodic_scan(interval))

    async def stop_periodic_scan(self) -> None:
        if self._scan_task:
            self._scan_task.cancel()
            try:
                await self._scan_task
            except asyncio.CancelledError:
                pass

    async def _periodic_scan(self, interval: int) -> None:
        while True:
            try:
                await self.scan()
                logger.debug(f"Periodic scan: {len(self.models)} models found")
            except Exception as e:
                logger.warning(f"Periodic scan error: {e}")
            await asyncio.sleep(interval)

    async def _scan_ollama(self) -> list[LocalModel]:
        """Probe Ollama at /api/tags."""
        models = []
        try:
            async with httpx.AsyncClient(timeout=3.0) as client:
                resp = await client.get(f"{self.ollama_url}/api/tags")
                if resp.status_code == 200:
                    data = resp.json()
                    for m in data.get("models", []):
                        name = m.get("name", "")
                        if name:
                            models.append(LocalModel(
                                name=name,
                                provider="ollama",
                                base_url=self.ollama_url,
                            ))
                    logger.info(f"Ollama: {len(models)} models at {self.ollama_url}")
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout):
            logger.debug(f"Ollama not found at {self.ollama_url}")
        except Exception as e:
            logger.debug(f"Ollama probe error: {e}")
        return models

    async def _scan_lm_studio(self) -> list[LocalModel]:
        """Probe LM Studio at /v1/models."""
        models = []
        try:
            async with httpx.AsyncClient(timeout=3.0) as client:
                resp = await client.get(f"{self.lm_studio_url}/v1/models")
                if resp.status_code == 200:
                    data = resp.json()
                    for m in data.get("data", []):
                        model_id = m.get("id", "")
                        if model_id:
                            models.append(LocalModel(
                                name=model_id,
                                provider="lm-studio",
                                base_url=self.lm_studio_url,
                            ))
                    logger.info(f"LM Studio: {len(models)} models at {self.lm_studio_url}")
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout):
            logger.debug(f"LM Studio not found at {self.lm_studio_url}")
        except Exception as e:
            logger.debug(f"LM Studio probe error: {e}")
        return models

    async def _scan_evermemos(self) -> bool:
        """Probe for local EverMemOS instance at /health."""
        try:
            async with httpx.AsyncClient(timeout=3.0) as client:
                resp = await client.get(f"{self.evermemos_url}/health")
                if resp.status_code == 200:
                    data = resp.json()
                    if data.get("status") == "healthy":
                        self.evermemos = EverMemOSInfo(
                            available=True,
                            url=self.evermemos_url,
                            version=data.get("version", ""),
                            memory_count=data.get("memory_count", 0),
                        )
                        logger.info(f"EverMemOS: healthy at {self.evermemos_url}")
                        return True
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.ReadTimeout):
            logger.debug(f"EverMemOS not found at {self.evermemos_url}")
        except Exception as e:
            logger.debug(f"EverMemOS probe error: {e}")
        self.evermemos = EverMemOSInfo(available=False, url=self.evermemos_url)
        return False
