"""Pentos Bridge CLI — start, mcp, status, config.

Usage:
    pentos-bridge start --key "sk_your_strue_api_key"
    pentos-bridge mcp
    pentos-bridge status
    pentos-bridge config --key "sk_new_key"
"""

from __future__ import annotations

import asyncio
import json
import sys
import logging

import click

from pentos_bridge.config import BridgeConfig, CONFIG_FILE
from pentos_bridge.local import LocalRegistry


def _setup_logging(debug: bool = False) -> None:
    level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stderr,  # Keep stdout clean for MCP stdio
    )


@click.group()
def main() -> None:
    """Pentos Bridge — local MCP server for Bittensor subnets."""
    pass


@main.command()
@click.option("--key", envvar="STRUE_API_KEY", default="", help="Strue API key")
@click.option("--port", default=8787, help="Server port")
@click.option("--no-local", is_flag=True, help="Disable local routing")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def start(key: str, port: int, no_local: bool, debug: bool) -> None:
    """Start Bridge (MCP + OpenAI API on localhost:8787)."""
    _setup_logging(debug)

    config = BridgeConfig.load()
    if key:
        config.strue_api_key = key
    config.bridge_port = port
    if no_local:
        config.prefer_local = False

    registry = LocalRegistry(
        ollama_url=config.local_ollama_url,
        lm_studio_url=config.local_lm_studio_url,
        evermemos_url=config.local_evermemos_url,
    )

    async def _startup():
        # Scan for local models
        click.echo("Scanning for local models...")
        models = await registry.scan()

        if models:
            for m in models:
                click.echo(f"  Found: {m.name} ({m.provider} at {m.base_url})")
        else:
            click.echo("  No local models detected.")

        # EverMemOS status
        if registry.evermemos.available:
            click.echo(f"  Memory: EverMemOS (local) — healthy"
                       + (f", {registry.evermemos.memory_count} memories" if registry.evermemos.memory_count else ""))
        else:
            click.echo("  Memory: EverMemOS not detected (cloud fallback)")

        click.echo()
        summary = f"Bridge running. {len(models)} local model{'s' if len(models) != 1 else ''} detected."
        if config.has_api_key:
            summary += " Cloud fallback: Strue API."
        else:
            summary += " Cloud fallback: no API key (set with --key)."
        click.echo(summary)
        click.echo(f"  OpenAI API: http://localhost:{port}/v1")
        click.echo(f"  Health:     http://localhost:{port}/health")
        click.echo()

        # Start periodic rescan
        await registry.start_periodic_scan(interval=60)

        # Build router and app
        from pentos_bridge.router import SmartRouter
        from pentos_bridge.server import create_app

        router = SmartRouter(config, registry)
        app = create_app(config, registry, router)

        # Run uvicorn
        import uvicorn
        server_config = uvicorn.Config(
            app, host="127.0.0.1", port=port,
            log_level="debug" if debug else "info",
        )
        server = uvicorn.Server(server_config)
        await server.serve()

    try:
        asyncio.run(_startup())
    except KeyboardInterrupt:
        click.echo("\nStopped.")


@main.command()
@click.option("--key", envvar="STRUE_API_KEY", default="", help="Strue API key")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def mcp(key: str, debug: bool) -> None:
    """Start MCP server in stdio mode (for Claude Desktop)."""
    _setup_logging(debug)

    config = BridgeConfig.load()
    if key:
        config.strue_api_key = key

    registry = LocalRegistry(
        ollama_url=config.local_ollama_url,
        lm_studio_url=config.local_lm_studio_url,
        evermemos_url=config.local_evermemos_url,
    )

    from pentos_bridge.router import SmartRouter
    from pentos_bridge.mcp import MCPStdioServer

    router = SmartRouter(config, registry)
    server = MCPStdioServer(config, registry, router)

    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        pass
    except BrokenPipeError:
        pass


@main.command()
def status() -> None:
    """Check what's detected locally + cloud status."""
    _setup_logging()

    config = BridgeConfig.load()
    registry = LocalRegistry(
        ollama_url=config.local_ollama_url,
        lm_studio_url=config.local_lm_studio_url,
        evermemos_url=config.local_evermemos_url,
    )

    click.echo("Scanning for local models and services...")
    models = registry.scan_sync()

    if models:
        click.echo(f"\nLocal models ({len(models)}):")
        for m in models:
            click.echo(f"  {m.name} — {m.provider} at {m.base_url}")
    else:
        click.echo("\nNo local models detected.")
        click.echo("  Supported: Ollama (port 11434), LM Studio (port 1234)")

    click.echo(f"\nMemory:")
    if registry.evermemos.available:
        click.echo(f"  EverMemOS (local) — healthy at {registry.evermemos.url}")
        if registry.evermemos.version:
            click.echo(f"  Version: {registry.evermemos.version}")
        if registry.evermemos.memory_count:
            click.echo(f"  Memories: {registry.evermemos.memory_count:,}")
        click.echo(f"  Sync: {'enabled (local → cloud)' if config.memory_sync_enabled else 'disabled'}")
    else:
        click.echo(f"  EverMemOS not detected at {config.local_evermemos_url}")
        click.echo("  Install: docker compose up -d (from EverMemOS repo)")
        click.echo("  Cloud memory available via Strue API")

    click.echo(f"\nCloud:")
    click.echo(f"  Gateway: {config.strue_base_url}")
    click.echo(f"  API key: {'configured' if config.has_api_key else 'not set'}")
    click.echo(f"  Prefer local: {config.prefer_local}")
    click.echo(f"\nConfig file: {CONFIG_FILE}")


@main.group()
def memory() -> None:
    """Memory commands — stats, export."""
    pass


@memory.command("stats")
def memory_stats() -> None:
    """Show memory statistics."""
    _setup_logging()

    config = BridgeConfig.load()
    registry = LocalRegistry(
        ollama_url=config.local_ollama_url,
        lm_studio_url=config.local_lm_studio_url,
        evermemos_url=config.local_evermemos_url,
    )

    async def _run():
        await registry.scan()
        from pentos_bridge.router import SmartRouter
        router = SmartRouter(config, registry)
        result, source = await router.memory_stats()
        return result, source

    try:
        result, source = asyncio.run(_run())
        click.echo(f"Memory stats (source: {source}):")
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Failed to get memory stats: {e}")
        click.echo("Is EverMemOS running locally or do you have a Strue API key configured?")


@memory.command("export")
@click.option("--output", "-o", default="memories_export.json", help="Output file path")
def memory_export(output: str) -> None:
    """Export all memories as JSON."""
    _setup_logging()

    config = BridgeConfig.load()
    registry = LocalRegistry(
        ollama_url=config.local_ollama_url,
        lm_studio_url=config.local_lm_studio_url,
        evermemos_url=config.local_evermemos_url,
    )

    async def _run():
        await registry.scan()
        from pentos_bridge.router import SmartRouter
        router = SmartRouter(config, registry)
        # Search with empty query to get all memories
        result, source = await router.memory_search("", limit=10000)
        return result, source

    try:
        result, source = asyncio.run(_run())
        import pathlib
        pathlib.Path(output).write_text(json.dumps(result, indent=2, default=str))
        memories = result.get("memories", [])
        click.echo(f"Exported {len(memories)} memories to {output} (source: {source})")
    except Exception as e:
        click.echo(f"Failed to export memories: {e}")
        click.echo("Is EverMemOS running locally or do you have a Strue API key configured?")


main.add_command(memory)


# --- Autoresearch commands ---

@main.group()
def autoresearch() -> None:
    """Autoresearch — Karpathy-style experiment loop."""
    pass


# Module-level state so status/stop can access a running harness
_active_harness: "AutoresearchHarness | None" = None


@autoresearch.command("start")
@click.argument("experiment_dir", type=click.Path(exists=True))
@click.option("--model", default="deepseek-ai/DeepSeek-V3", help="Planning model")
@click.option("--model-key", default="", envvar="MODEL_API_KEY", help="Direct API key for model provider")
@click.option("--key", default="", envvar="STRUE_API_KEY", help="Strue API key")
@click.option("--budget", default=5, type=int, help="Minutes per experiment")
@click.option("--max-experiments", default=100, type=int, help="Max experiments to run")
@click.option("--publish", is_flag=True, help="Publish results to Arloop on completion")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def autoresearch_start(experiment_dir: str, model: str, model_key: str, key: str,
                        budget: int, max_experiments: int, publish: bool, debug: bool) -> None:
    """Start a classic autoresearch (local GPU)."""
    _setup_logging(debug)
    global _active_harness

    config = BridgeConfig.load()
    api_key = key or config.strue_api_key

    from pentos_bridge.autoresearch import AutoresearchHarness

    harness = AutoresearchHarness(
        model=model,
        model_key=model_key,
        strue_api_key=api_key,
        strue_base_url=config.strue_base_url,
        ollama_url=config.local_ollama_url,
    )
    _active_harness = harness

    click.echo(f"Starting autoresearch in {experiment_dir}")
    click.echo(f"  Model: {model}")
    click.echo(f"  Budget: {budget} min/experiment")
    click.echo(f"  Max experiments: {max_experiments}")
    click.echo(f"  Publish: {publish}")
    click.echo()

    try:
        state = asyncio.run(harness.run(
            experiment_dir=experiment_dir,
            budget_minutes=budget,
            max_experiments=max_experiments,
            publish=publish,
        ))
        click.echo(f"\nAutoresearch complete!")
        click.echo(f"  Experiments: {len(state.experiments)}")
        click.echo(f"  Best metric: {state.best_metric}")
        kept = sum(1 for e in state.experiments if e.decision == "keep")
        click.echo(f"  Kept: {kept} / Discarded: {len(state.experiments) - kept}")
    except KeyboardInterrupt:
        click.echo("\nStopping after current experiment...")
        harness.stop()
    except Exception as e:
        click.echo(f"\nAutoresearch failed: {e}")
        sys.exit(1)
    finally:
        _active_harness = None


@autoresearch.command("continue")
@click.argument("parent_id")
@click.option("--dir", "experiment_dir", type=click.Path(exists=True), default=".",
              help="Local experiment directory")
@click.option("--model", default="deepseek-ai/DeepSeek-V3", help="Planning model")
@click.option("--model-key", default="", envvar="MODEL_API_KEY", help="Direct API key for model provider")
@click.option("--key", default="", envvar="STRUE_API_KEY", help="Strue API key")
@click.option("--budget", default=5, type=int, help="Minutes per experiment")
@click.option("--max-experiments", default=50, type=int, help="Max experiments to run")
@click.option("--publish", is_flag=True, help="Publish results to Arloop on completion")
@click.option("--debug", is_flag=True, help="Enable debug logging")
def autoresearch_continue(parent_id: str, experiment_dir: str, model: str, model_key: str,
                           key: str, budget: int, max_experiments: int,
                           publish: bool, debug: bool) -> None:
    """Continue from an existing Arloop autoresearch entry."""
    _setup_logging(debug)
    global _active_harness

    config = BridgeConfig.load()
    api_key = key or config.strue_api_key

    from pentos_bridge.autoresearch import AutoresearchHarness

    harness = AutoresearchHarness(
        model=model,
        model_key=model_key,
        strue_api_key=api_key,
        strue_base_url=config.strue_base_url,
        ollama_url=config.local_ollama_url,
    )
    _active_harness = harness

    click.echo(f"Continuing autoresearch from Arloop entry: {parent_id}")
    click.echo(f"  Directory: {experiment_dir}")
    click.echo(f"  Model: {model}")
    click.echo(f"  Max experiments: {max_experiments}")
    click.echo()

    try:
        state = asyncio.run(harness.run(
            experiment_dir=experiment_dir,
            budget_minutes=budget,
            max_experiments=max_experiments,
            publish=publish,
            parent_id=parent_id,
        ))
        click.echo(f"\nAutoresearch complete!")
        click.echo(f"  Experiments: {len(state.experiments)}")
        click.echo(f"  Best metric: {state.best_metric}")
    except KeyboardInterrupt:
        click.echo("\nStopping after current experiment...")
        harness.stop()
    except Exception as e:
        click.echo(f"\nAutoresearch failed: {e}")
        sys.exit(1)
    finally:
        _active_harness = None


@autoresearch.command("status")
def autoresearch_status() -> None:
    """Check status of running autoresearch."""
    if _active_harness is None:
        click.echo("No autoresearch is currently running.")
        return

    status = _active_harness.get_status()
    click.echo(f"Autoresearch status: {status['status']}")
    click.echo(f"  Directory: {status['experiment_dir']}")
    click.echo(f"  Model: {status['model']}")
    click.echo(f"  Experiment: {status['current_experiment']}/{status['max_experiments']}")
    click.echo(f"  Best metric: {status['best_metric']}")
    click.echo(f"  Completed: {status['experiments_completed']}")
    if status.get('error'):
        click.echo(f"  Error: {status['error']}")


@autoresearch.command("stop")
def autoresearch_stop() -> None:
    """Stop running autoresearch after current experiment."""
    if _active_harness is None:
        click.echo("No autoresearch is currently running.")
        return

    _active_harness.stop()
    click.echo("Stop requested. Will finish after current experiment.")


main.add_command(autoresearch)


# --- Identity commands ---

@main.group()
def identity() -> None:
    """Research identity — self-hosted mTLS certificates."""
    pass


@identity.command("create")
@click.option("--name", required=True, help="Common name for the certificate (e.g. your name)")
@click.option("--device-bound", is_flag=True, help="Store private key in OS keychain (Level 3)")
def identity_create(name: str, device_bound: bool) -> None:
    """Create a new research identity (Ed25519 + X.509 cert)."""
    from pentos_bridge.identity import IdentityManager

    mgr = IdentityManager()
    if mgr.exists():
        click.echo("Identity already exists. Use 'identity show' to view it.")
        click.echo("Delete ~/.pentos-bridge/identity/ to start fresh.")
        return

    info = mgr.create(name, device_bound=device_bound)
    click.echo(f"Identity created!")
    click.echo(f"  Name:        {info.name}")
    click.echo(f"  Fingerprint: {info.fingerprint}")
    click.echo(f"  Created:     {info.created}")
    click.echo(f"  Device-bound: {info.device_bound}")
    click.echo(f"  Cert:        {info.cert_path}")
    click.echo(f"  Key:         {info.key_path}")


@identity.command("show")
def identity_show() -> None:
    """Show current research identity."""
    from pentos_bridge.identity import IdentityManager

    mgr = IdentityManager()
    info = mgr.load()
    if info is None:
        click.echo("No identity found. Create one with: pentos-bridge identity create --name 'your name'")
        return

    click.echo(f"Research Identity")
    click.echo(f"  Name:        {info.name}")
    click.echo(f"  Fingerprint: {info.fingerprint}")
    click.echo(f"  Created:     {info.created}")
    click.echo(f"  Device-bound: {info.device_bound}")
    if info.device_hash:
        click.echo(f"  Device hash: {info.device_hash}")
    if info.github_username:
        click.echo(f"  GitHub:      {info.github_username} (id: {info.github_id})")
        click.echo(f"  Linked at:   {info.github_linked_at}")
    if info.arns_name:
        click.echo(f"  ArNS:        {info.arns_name}.arweave.net")
        click.echo(f"  Verified at: {info.arns_verified_at}")
    click.echo(f"  Cert:        {info.cert_path}")
    click.echo(f"  Key:         {info.key_path}")


@identity.command("export")
def identity_export() -> None:
    """Export the public certificate (PEM)."""
    from pentos_bridge.identity import IdentityManager, IdentityError

    mgr = IdentityManager()
    try:
        pem = mgr.export_cert()
        click.echo(pem)
    except IdentityError as e:
        click.echo(f"Error: {e}")


@identity.command("link-github")
def identity_link_github() -> None:
    """Link identity to GitHub via OAuth device flow."""
    import time as _time
    from pentos_bridge.identity import IdentityManager, IdentityError

    mgr = IdentityManager()
    if not mgr.exists():
        click.echo("No identity found. Create one first: pentos-bridge identity create --name 'your name'")
        return

    try:
        device_data = mgr.link_github()
    except Exception as e:
        click.echo(f"Failed to start GitHub device flow: {e}")
        return

    click.echo(f"Go to: {device_data['verification_uri']}")
    click.echo(f"Enter code: {device_data['user_code']}")
    click.echo()
    click.echo("Waiting for authorization...")

    interval = device_data.get("interval", 5)
    expires_in = device_data.get("expires_in", 900)
    device_code = device_data["device_code"]
    deadline = _time.monotonic() + expires_in

    while _time.monotonic() < deadline:
        _time.sleep(interval)
        try:
            result = mgr.complete_github_link(device_code)
        except Exception as e:
            click.echo(f"Error: {e}")
            return

        if "error" in result:
            if result["error"] == "authorization_pending":
                continue
            if result["error"] == "slow_down":
                interval += 5
                continue
            click.echo(f"GitHub auth failed: {result.get('description', result['error'])}")
            return

        click.echo(f"Linked to GitHub: {result['github_username']} (id: {result['github_id']})")
        click.echo(f"Attestation saved to: {result['attestation_saved']}")
        return

    click.echo("Timed out waiting for GitHub authorization.")


@identity.command("link-arns")
@click.option("--name", required=True, help="ArNS Primary Name (e.g. 'jordan')")
def identity_link_arns(name: str) -> None:
    """Link identity to an ArNS Primary Name."""
    from pentos_bridge.identity import IdentityManager, IdentityError

    mgr = IdentityManager()
    if not mgr.exists():
        click.echo("No identity found. Create one first: pentos-bridge identity create --name 'your name'")
        return

    click.echo(f"Verifying ArNS name '{name}' at https://{name}.arweave.net ...")
    try:
        result = mgr.link_arns(name)
    except IdentityError as e:
        click.echo(f"Error: {e}")
        return

    click.echo(f"Linked to ArNS: {result['arns_name']}.arweave.net")
    click.echo(f"Verified at: {result['verified_at']}")
    click.echo(f"Attestation saved to: {result['attestation_saved']}")


main.add_command(identity)


@main.command("config")
@click.option("--key", default=None, help="Set Strue API key")
@click.option("--ollama-port", default=None, type=int, help="Set Ollama port")
@click.option("--lm-studio-port", default=None, type=int, help="Set LM Studio port")
@click.option("--port", default=None, type=int, help="Set Bridge port")
@click.option("--show", is_flag=True, help="Show current config")
def configure(key: str | None, ollama_port: int | None, lm_studio_port: int | None,
              port: int | None, show: bool) -> None:
    """Set API key, ports, and preferences."""
    config = BridgeConfig.load()

    if show:
        click.echo(json.dumps(config.to_dict(), indent=2))
        return

    changed = False
    if key is not None:
        config.strue_api_key = key
        click.echo(f"API key: set")
        changed = True
    if ollama_port is not None:
        config.local_ollama_url = f"http://localhost:{ollama_port}"
        click.echo(f"Ollama URL: {config.local_ollama_url}")
        changed = True
    if lm_studio_port is not None:
        config.local_lm_studio_url = f"http://localhost:{lm_studio_port}"
        click.echo(f"LM Studio URL: {config.local_lm_studio_url}")
        changed = True
    if port is not None:
        config.bridge_port = port
        click.echo(f"Bridge port: {port}")
        changed = True

    if changed:
        config.save()
        click.echo(f"Saved to {CONFIG_FILE}")
    else:
        click.echo("No changes. Use --show to view config, or pass options to set values.")


if __name__ == "__main__":
    main()
