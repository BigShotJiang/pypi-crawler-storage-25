"""Autoresearch harness — Karpathy-style experiment loop.

Reads program.md, modifies train.py, runs experiments with time budgets,
evaluates metrics, keeps or discards, logs everything, publishes to Arloop.

Usage:
    harness = AutoresearchHarness(config, router)
    await harness.run("./my-experiment", model="deepseek-ai/DeepSeek-V3", budget_minutes=5)
"""

from __future__ import annotations

import asyncio
import csv
import hashlib
import json
import logging
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

METRIC_PATTERN = re.compile(r"(?:val_bpb|val_loss|metric|score|accuracy|loss)\s*[=:]\s*([\d.]+)", re.IGNORECASE)


@dataclass
class ExperimentResult:
    """Result of a single experiment."""
    number: int
    hypothesis: str
    diff: str
    metric_before: float | None
    metric_after: float | None
    decision: str  # "keep" or "discard"
    duration_seconds: float
    git_hash: str
    timestamp: str


@dataclass
class AutoresearchState:
    """Tracks running autoresearch state."""
    status: str = "idle"  # idle, running, stopping, completed, failed
    experiment_dir: str = ""
    model: str = ""
    budget_minutes: int = 5
    max_experiments: int = 100
    current_experiment: int = 0
    best_metric: float | None = None
    metric_name: str = ""
    experiments: list[ExperimentResult] = field(default_factory=list)
    parent_id: str | None = None
    timestamp_start: str = ""
    timestamp_end: str = ""
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "status": self.status,
            "experiment_dir": self.experiment_dir,
            "model": self.model,
            "budget_minutes": self.budget_minutes,
            "max_experiments": self.max_experiments,
            "current_experiment": self.current_experiment,
            "best_metric": self.best_metric,
            "metric_name": self.metric_name,
            "experiments_completed": len(self.experiments),
            "parent_id": self.parent_id,
            "timestamp_start": self.timestamp_start,
            "error": self.error,
        }


class AutoresearchHarness:
    """Manages the autoresearch experiment loop.

    Steps:
    1. Read program.md for instructions
    2. Call planning model to propose a modification to train.py
    3. Apply the modification
    4. Run train.py with timeout
    5. Read metric from output
    6. Keep (git commit) or discard (git revert)
    7. Repeat
    """

    def __init__(
        self,
        model: str = "covenant-72b",
        model_key: str = "",
        strue_api_key: str = "",
        strue_base_url: str = "https://pentos-gateway.strue.workers.dev",
        ollama_url: str = "http://localhost:11434",
    ) -> None:
        self.model = model
        self.model_key = model_key
        self.strue_api_key = strue_api_key
        self.strue_base_url = strue_base_url.rstrip("/")
        self.ollama_url = ollama_url
        self.state = AutoresearchState()
        self._stop_requested = False
        self._identity_info: Any = None
        self._load_identity()

    def _load_identity(self) -> None:
        """Try to load research identity from ~/.pentos-bridge/identity/."""
        try:
            from pentos_bridge.identity import IdentityManager
            mgr = IdentityManager()
            self._identity_info = mgr.load()
            if self._identity_info:
                logger.info(f"Research identity loaded: {self._identity_info.fingerprint[:16]}...")
            else:
                logger.warning("No research identity found. Create one with: pentos-bridge identity create")
        except Exception as e:
            logger.debug(f"Could not load identity: {e}")
            self._identity_info = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def run(
        self,
        experiment_dir: str,
        budget_minutes: int = 5,
        max_experiments: int = 100,
        publish: bool = False,
        parent_id: str | None = None,
    ) -> AutoresearchState:
        """Run the autoresearch loop."""
        exp_path = Path(experiment_dir).resolve()
        self._validate_directory(exp_path)

        self.state = AutoresearchState(
            status="running",
            experiment_dir=str(exp_path),
            model=self.model,
            budget_minutes=budget_minutes,
            max_experiments=max_experiments,
            parent_id=parent_id,
            timestamp_start=datetime.now(timezone.utc).isoformat(),
        )
        self._stop_requested = False

        try:
            # Initialize git if needed
            self._ensure_git(exp_path)

            # Read program.md
            program = self._read_program(exp_path)
            self.state.metric_name = self._extract_metric_name(program)

            # Handle continue mode — fetch parent's best train.py
            if parent_id:
                await self._fetch_parent(exp_path, parent_id)

            # Get initial metric by running train.py once
            logger.info("Running initial experiment to establish baseline...")
            initial_metric = await self._run_experiment(exp_path, budget_minutes)
            self.state.best_metric = initial_metric
            logger.info(f"Baseline metric: {initial_metric}")

            # Commit initial state
            self._git_commit(exp_path, "initial: baseline experiment")

            # Main experiment loop
            for i in range(1, max_experiments + 1):
                if self._stop_requested:
                    logger.info("Stop requested, finishing up...")
                    break

                self.state.current_experiment = i
                logger.info(f"\n{'='*60}")
                logger.info(f"Experiment {i}/{max_experiments}")
                logger.info(f"{'='*60}")

                # Save current train.py for potential revert
                train_py = exp_path / "train.py"
                original_code = train_py.read_text()

                # Ask planning model for a modification
                hypothesis, new_code = await self._plan_experiment(
                    program, original_code, self.state.experiments, self.state.best_metric
                )

                if not new_code or new_code.strip() == original_code.strip():
                    logger.warning("Planning model returned no meaningful change, skipping...")
                    continue

                # Validate the new code compiles
                if not self._validate_code(new_code, exp_path):
                    logger.warning("Modified code has syntax errors, discarding...")
                    result = ExperimentResult(
                        number=i,
                        hypothesis=hypothesis,
                        diff=self._compute_diff(original_code, new_code),
                        metric_before=self.state.best_metric,
                        metric_after=None,
                        decision="discard",
                        duration_seconds=0,
                        git_hash="",
                        timestamp=datetime.now(timezone.utc).isoformat(),
                    )
                    self.state.experiments.append(result)
                    self._append_results_tsv(exp_path, result)
                    continue

                # Apply modification
                train_py.write_text(new_code)

                # Check that prepare.py wasn't modified
                if not self._verify_immutable_files(exp_path):
                    logger.warning("Immutable files modified, reverting...")
                    train_py.write_text(original_code)
                    continue

                # Run experiment
                start_time = time.monotonic()
                try:
                    new_metric = await self._run_experiment(exp_path, budget_minutes)
                except ExperimentTimeout:
                    logger.warning(f"Experiment {i} timed out")
                    train_py.write_text(original_code)
                    result = ExperimentResult(
                        number=i,
                        hypothesis=hypothesis,
                        diff=self._compute_diff(original_code, new_code),
                        metric_before=self.state.best_metric,
                        metric_after=None,
                        decision="discard",
                        duration_seconds=time.monotonic() - start_time,
                        git_hash="",
                        timestamp=datetime.now(timezone.utc).isoformat(),
                    )
                    self.state.experiments.append(result)
                    self._append_results_tsv(exp_path, result)
                    continue
                except ExperimentError as e:
                    logger.warning(f"Experiment {i} failed: {e}")
                    train_py.write_text(original_code)
                    result = ExperimentResult(
                        number=i,
                        hypothesis=hypothesis,
                        diff=self._compute_diff(original_code, new_code),
                        metric_before=self.state.best_metric,
                        metric_after=None,
                        decision="discard",
                        duration_seconds=time.monotonic() - start_time,
                        git_hash="",
                        timestamp=datetime.now(timezone.utc).isoformat(),
                    )
                    self.state.experiments.append(result)
                    self._append_results_tsv(exp_path, result)
                    continue

                duration = time.monotonic() - start_time
                diff = self._compute_diff(original_code, new_code)

                # Decision: keep or discard
                improved = self._is_improvement(new_metric, self.state.best_metric)
                if improved:
                    decision = "keep"
                    git_hash = self._git_commit(exp_path, f"exp {i}: {hypothesis} ({new_metric})")
                    self.state.best_metric = new_metric
                    logger.info(f"  KEEP — metric improved: {new_metric} (was {self.state.best_metric})")
                else:
                    decision = "discard"
                    train_py.write_text(original_code)
                    git_hash = ""
                    logger.info(f"  DISCARD — metric not improved: {new_metric} (best: {self.state.best_metric})")

                result = ExperimentResult(
                    number=i,
                    hypothesis=hypothesis,
                    diff=diff,
                    metric_before=self.state.best_metric if decision == "discard" else (
                        self.state.experiments[-1].metric_after if self.state.experiments else initial_metric
                    ),
                    metric_after=new_metric,
                    decision=decision,
                    duration_seconds=duration,
                    git_hash=git_hash,
                    timestamp=datetime.now(timezone.utc).isoformat(),
                )
                self.state.experiments.append(result)
                self._append_results_tsv(exp_path, result)

            # Done
            self.state.status = "completed"
            self.state.timestamp_end = datetime.now(timezone.utc).isoformat()

            # Publish if requested
            if publish:
                await self._publish(exp_path)

            return self.state

        except Exception as e:
            self.state.status = "failed"
            self.state.error = str(e)
            self.state.timestamp_end = datetime.now(timezone.utc).isoformat()
            logger.error(f"Autoresearch failed: {e}")
            raise

    def stop(self) -> None:
        """Request graceful stop after current experiment finishes."""
        self._stop_requested = True
        self.state.status = "stopping"

    def get_status(self) -> dict:
        """Return current status."""
        return self.state.to_dict()

    # ------------------------------------------------------------------
    # Directory validation
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_directory(path: Path) -> None:
        """Ensure directory has required files."""
        if not path.is_dir():
            raise AutoresearchError(f"Not a directory: {path}")
        if not (path / "program.md").exists():
            raise AutoresearchError(f"Missing program.md in {path}")
        if not (path / "train.py").exists():
            raise AutoresearchError(f"Missing train.py in {path}")

    @staticmethod
    def _read_program(path: Path) -> str:
        """Read program.md instructions."""
        return (path / "program.md").read_text()

    @staticmethod
    def _extract_metric_name(program: str) -> str:
        """Extract the metric name from program.md."""
        # Look for common patterns like "metric: val_bpb" or "evaluate: val_loss"
        m = re.search(r"(?:metric|evaluate|measure|optimize)\s*[:=]\s*(\w+)", program, re.IGNORECASE)
        if m:
            return m.group(1)
        # Check for metric names in the text
        for name in ["val_bpb", "val_loss", "accuracy", "loss", "score", "perplexity"]:
            if name in program.lower():
                return name
        return "metric"

    # ------------------------------------------------------------------
    # Git operations
    # ------------------------------------------------------------------

    @staticmethod
    def _ensure_git(path: Path) -> None:
        """Initialize git repo if not already."""
        if not (path / ".git").exists():
            subprocess.run(["git", "init"], cwd=path, capture_output=True, check=True)
            subprocess.run(["git", "add", "."], cwd=path, capture_output=True, check=True)
            subprocess.run(
                ["git", "commit", "-m", "autoresearch: initial state"],
                cwd=path, capture_output=True, check=True,
            )

    @staticmethod
    def _git_commit(path: Path, message: str) -> str:
        """Stage all changes and commit. Returns the commit hash."""
        subprocess.run(["git", "add", "."], cwd=path, capture_output=True, check=True)
        subprocess.run(
            ["git", "commit", "-m", message, "--allow-empty"],
            cwd=path, capture_output=True, check=True,
        )
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=path, capture_output=True, text=True, check=True,
        )
        return result.stdout.strip()[:12]

    # ------------------------------------------------------------------
    # Experiment runner
    # ------------------------------------------------------------------

    async def _run_experiment(self, path: Path, budget_minutes: int) -> float:
        """Run train.py with timeout, return metric value."""
        timeout_seconds = int(budget_minutes * 60 * 1.1)  # 10% grace

        proc = await asyncio.create_subprocess_exec(
            sys.executable, "train.py",
            cwd=path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise ExperimentTimeout(f"Experiment exceeded {budget_minutes}min budget")

        output = stdout.decode("utf-8", errors="replace")

        # Write run.log
        (path / "run.log").write_text(output)

        if proc.returncode != 0:
            raise ExperimentError(f"train.py exited with code {proc.returncode}")

        # Extract metric from output
        metric = self._extract_metric(output)
        if metric is None:
            raise ExperimentError("Could not find metric in train.py output")

        return metric

    @staticmethod
    def _extract_metric(output: str) -> float | None:
        """Extract metric value from training output. Returns the last match."""
        matches = METRIC_PATTERN.findall(output)
        if matches:
            return float(matches[-1])
        return None

    # ------------------------------------------------------------------
    # Planning agent
    # ------------------------------------------------------------------

    async def _plan_experiment(
        self,
        program: str,
        current_code: str,
        history: list[ExperimentResult],
        best_metric: float | None,
    ) -> tuple[str, str]:
        """Ask the planning model for a code modification.

        Returns (hypothesis, modified_train_py_code).
        """
        history_text = self._format_history(history)

        prompt = f"""You are an autoresearch agent. Your job is to improve a training script.

## Instructions (from program.md)
{program}

## Current train.py
```python
{current_code}
```

## Experiment History
{history_text if history_text else "No experiments yet. This is the first modification."}

## Current Best Metric
{best_metric if best_metric is not None else "Not yet established"}

## Your Task
1. Analyze the code and history
2. Propose ONE specific modification to train.py that might improve the metric
3. Return your hypothesis and the COMPLETE modified train.py

IMPORTANT: Return your response in this exact format:

HYPOTHESIS: <one sentence describing what you're trying and why>

```python
<complete modified train.py code>
```
"""

        response = await self._call_planning_model(prompt)
        return self._parse_planning_response(response)

    async def _call_planning_model(self, prompt: str) -> str:
        """Call the planning model. Supports Ollama, Strue cloud, or direct API."""
        model = self.model.lower()

        if model.startswith("ollama:"):
            return await self._call_ollama(prompt, model.removeprefix("ollama:"))
        elif model in ("claude-opus", "claude-sonnet") and self.model_key:
            return await self._call_anthropic(prompt)
        elif model in ("gpt-4", "gpt-4o", "gpt-5") and self.model_key:
            return await self._call_openai_direct(prompt)
        else:
            # Default: Strue cloud inference
            return await self._call_strue(prompt)

    async def _call_ollama(self, prompt: str, model_name: str) -> str:
        """Call local Ollama model."""
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.post(
                f"{self.ollama_url}/v1/chat/completions",
                json={
                    "model": model_name,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 4096,
                    "temperature": 0.7,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]

    async def _call_strue(self, prompt: str) -> str:
        """Call Strue cloud inference (Chutes / Covenant / DeepSeek)."""
        headers = {"Content-Type": "application/json"}
        if self.strue_api_key:
            headers["Authorization"] = f"Bearer {self.strue_api_key}"

        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.post(
                f"{self.strue_base_url}/v1/chat/completions",
                headers=headers,
                json={
                    "model": self.model,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 4096,
                    "temperature": 0.7,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]

    async def _call_anthropic(self, prompt: str) -> str:
        """Call Anthropic API directly with user's key."""
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": self.model_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                },
                json={
                    "model": "claude-opus-4-20250514" if "opus" in self.model.lower() else "claude-sonnet-4-20250514",
                    "max_tokens": 4096,
                    "messages": [{"role": "user", "content": prompt}],
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["content"][0]["text"]

    async def _call_openai_direct(self, prompt: str) -> str:
        """Call OpenAI API directly with user's key."""
        async with httpx.AsyncClient(timeout=300.0) as client:
            resp = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.model_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self.model,
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 4096,
                    "temperature": 0.7,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]

    @staticmethod
    def _parse_planning_response(response: str) -> tuple[str, str]:
        """Parse hypothesis and code from planning model response."""
        hypothesis = ""
        code = ""

        # Extract hypothesis
        h_match = re.search(r"HYPOTHESIS:\s*(.+?)(?:\n|$)", response)
        if h_match:
            hypothesis = h_match.group(1).strip()

        # Extract code block
        code_match = re.search(r"```python\s*\n(.*?)```", response, re.DOTALL)
        if code_match:
            code = code_match.group(1).strip()

        if not hypothesis:
            hypothesis = "Modification proposed by planning model"

        return hypothesis, code

    @staticmethod
    def _format_history(history: list[ExperimentResult]) -> str:
        """Format experiment history for the planning prompt."""
        if not history:
            return ""
        lines = []
        for exp in history[-10:]:  # Last 10 experiments
            lines.append(
                f"Exp {exp.number}: {exp.hypothesis} — "
                f"metric: {exp.metric_before} → {exp.metric_after} — {exp.decision}"
            )
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Code validation
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_code(code: str, path: Path) -> bool:
        """Check that code is valid Python (compiles without errors)."""
        try:
            compile(code, "train.py", "exec")
            return True
        except SyntaxError as e:
            logger.warning(f"Syntax error in modified code: {e}")
            return False

    @staticmethod
    def _verify_immutable_files(path: Path) -> bool:
        """Verify that prepare.py and program.md haven't been modified."""
        result = subprocess.run(
            ["git", "diff", "--name-only"],
            cwd=path, capture_output=True, text=True,
        )
        changed = result.stdout.strip().split("\n") if result.stdout.strip() else []
        immutable = {"prepare.py", "program.md"}
        violations = set(changed) & immutable
        if violations:
            logger.warning(f"Immutable files modified: {violations}")
            # Revert the immutable files
            for f in violations:
                subprocess.run(["git", "checkout", "--", f], cwd=path, capture_output=True)
            return False
        return True

    # ------------------------------------------------------------------
    # Decision engine
    # ------------------------------------------------------------------

    @staticmethod
    def _is_improvement(new_metric: float, best_metric: float | None) -> bool:
        """Compare metrics. Lower is better (loss-style metrics)."""
        if best_metric is None:
            return True
        return new_metric < best_metric

    @staticmethod
    def _compute_diff(old_code: str, new_code: str) -> str:
        """Compute a unified diff between old and new code."""
        import difflib
        old_lines = old_code.splitlines(keepends=True)
        new_lines = new_code.splitlines(keepends=True)
        diff = difflib.unified_diff(old_lines, new_lines, fromfile="a/train.py", tofile="b/train.py")
        return "".join(diff)

    @staticmethod
    def _append_results_tsv(path: Path, result: ExperimentResult) -> None:
        """Append experiment result to results.tsv."""
        tsv_path = path / "results.tsv"
        write_header = not tsv_path.exists()

        with open(tsv_path, "a", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            if write_header:
                writer.writerow([
                    "experiment", "hypothesis", "metric_before", "metric_after",
                    "decision", "duration_seconds", "git_hash", "timestamp",
                ])
            writer.writerow([
                result.number, result.hypothesis, result.metric_before,
                result.metric_after, result.decision,
                f"{result.duration_seconds:.1f}", result.git_hash, result.timestamp,
            ])

    # ------------------------------------------------------------------
    # Publication
    # ------------------------------------------------------------------

    async def _publish(self, path: Path) -> dict:
        """Package and publish results to Arweave + Arloop."""
        experiment_log = self._build_experiment_log(path)
        log_json = json.dumps(experiment_log, indent=2)

        # Compute integrity hash (includes fingerprint if present)
        integrity_hash = hashlib.sha256(log_json.encode()).hexdigest()
        experiment_log["integrity_hash"] = f"sha256:{integrity_hash}"

        # Upload to Arweave via Strue /v1/store
        headers = {"Content-Type": "application/json"}
        if self.strue_api_key:
            headers["Authorization"] = f"Bearer {self.strue_api_key}"

        store_tags: dict[str, str] = {
            "type": "autoresearch",
            "metric": self.state.metric_name,
            "model": self.model,
            "integrity_hash": f"sha256:{integrity_hash}",
        }
        if self._identity_info:
            store_tags["cert_fingerprint"] = self._identity_info.fingerprint
            store_tags["identity_name"] = self._identity_info.name
            if self._identity_info.github_username:
                store_tags["github_username"] = self._identity_info.github_username
            if self._identity_info.arns_name:
                store_tags["arns_name"] = self._identity_info.arns_name
            store_tags["device_bound"] = str(self._identity_info.device_bound).lower()

        async with httpx.AsyncClient(timeout=60.0) as client:
            # Store experiment log
            store_resp = await client.post(
                f"{self.strue_base_url}/v1/store",
                headers=headers,
                json={
                    "data": json.dumps(experiment_log),
                    "filename": "autoresearch_log.json",
                    "backend": "arweave",
                    "tags": store_tags,
                },
            )
            store_resp.raise_for_status()
            store_data = store_resp.json()
            tx_id = store_data.get("id", store_data.get("tx_id", ""))

            # Publish to Arloop
            best_train = (path / "train.py").read_text()
            badges = ["verified_autoresearch"]
            if self.state.parent_id:
                badges.append("continued")

            upload_resp = await client.post(
                f"{self.strue_base_url}/v1/loop/upload",
                headers=headers,
                json={
                    "title": f"Autoresearch: {self.state.metric_name} optimization",
                    "content": self._format_report(experiment_log, best_train),
                    "topics": ["autoresearch", self.state.metric_name],
                    "badges": badges,
                    "metadata": {
                        "type": "autoresearch",
                        "arweave_tx_id": tx_id,
                        "parent_id": self.state.parent_id,
                        "model": self.model,
                        "best_metric": self.state.best_metric,
                        "total_experiments": len(self.state.experiments),
                        "integrity_hash": f"sha256:{integrity_hash}",
                    },
                },
            )
            upload_resp.raise_for_status()
            arloop_data = upload_resp.json()

        logger.info(f"Published to Arloop: {arloop_data.get('url', arloop_data.get('id', ''))}")
        return {
            "arweave_tx_id": tx_id,
            "arloop": arloop_data,
            "integrity_hash": f"sha256:{integrity_hash}",
        }

    def _build_experiment_log(self, path: Path) -> dict:
        """Build the full experiment log JSON."""
        program_md = (path / "program.md").read_text()
        initial_train = ""  # We don't store the initial separately, but git has it

        log: dict[str, Any] = {
            "type": "autoresearch",
            "version": "1.0",
            "program_md_hash": f"sha256:{hashlib.sha256(program_md.encode()).hexdigest()}",
            "initial_train_py_hash": "",
            "metric": self.state.metric_name,
            "budget_minutes": self.state.budget_minutes,
            "planning_model": self.model,
            "compute": "local",
            "parent_id": self.state.parent_id,
        }

        # Embed identity info if available
        if self._identity_info:
            log["cert_fingerprint"] = self._identity_info.fingerprint
            log["identity_name"] = self._identity_info.name
            if self._identity_info.github_username:
                log["github_username"] = self._identity_info.github_username
            if self._identity_info.arns_name:
                log["arns_name"] = self._identity_info.arns_name
            log["device_bound"] = self._identity_info.device_bound

        log["experiments"] = [
                {
                    "number": exp.number,
                    "hypothesis": exp.hypothesis,
                    "diff": exp.diff,
                    "metric_before": exp.metric_before,
                    "metric_after": exp.metric_after,
                    "decision": exp.decision,
                    "duration_seconds": exp.duration_seconds,
                    "git_hash": exp.git_hash,
                    "timestamp": exp.timestamp,
                }
                for exp in self.state.experiments
            ]
        log["best_metric"] = self.state.best_metric
        log["best_experiment"] = self._best_experiment_number()
        log["total_experiments"] = len(self.state.experiments)
        log["total_duration_seconds"] = sum(e.duration_seconds for e in self.state.experiments)
        log["timestamp_start"] = self.state.timestamp_start
        log["timestamp_end"] = self.state.timestamp_end

        return log

    def _best_experiment_number(self) -> int | None:
        """Return the experiment number with the best metric."""
        kept = [e for e in self.state.experiments if e.decision == "keep" and e.metric_after is not None]
        if not kept:
            return None
        best = min(kept, key=lambda e: e.metric_after)  # type: ignore[arg-type]
        return best.number

    @staticmethod
    def _format_report(log: dict, best_train: str) -> str:
        """Format a human-readable report for Arloop."""
        experiments = log.get("experiments", [])
        kept = [e for e in experiments if e["decision"] == "keep"]
        discarded = [e for e in experiments if e["decision"] == "discard"]

        lines = [
            f"# Autoresearch Report",
            f"",
            f"**Metric:** {log['metric']}",
            f"**Planning model:** {log['planning_model']}",
            f"**Budget:** {log['budget_minutes']} min/experiment",
            f"**Total experiments:** {log['total_experiments']}",
            f"**Kept:** {len(kept)} | **Discarded:** {len(discarded)}",
            f"**Best metric:** {log['best_metric']}",
            f"",
            f"## Experiment Log",
            f"",
        ]

        for exp in experiments:
            marker = "✓" if exp["decision"] == "keep" else "✗"
            lines.append(
                f"- {marker} Exp {exp['number']}: {exp['hypothesis']} "
                f"({exp['metric_before']} → {exp['metric_after']}) [{exp['decision']}]"
            )

        lines.extend([
            f"",
            f"## Best train.py",
            f"",
            f"```python",
            best_train,
            f"```",
        ])

        if log.get("parent_id"):
            lines.extend([
                f"",
                f"## Continued From",
                f"",
                f"Parent: {log['parent_id']}",
            ])

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Continue mode
    # ------------------------------------------------------------------

    async def _fetch_parent(self, path: Path, parent_id: str) -> None:
        """Fetch parent entry from Arloop and use their best train.py."""
        headers = {"Content-Type": "application/json"}
        if self.strue_api_key:
            headers["Authorization"] = f"Bearer {self.strue_api_key}"

        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                f"{self.strue_base_url}/v1/loop/r/{parent_id}",
                headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()

        # Extract the best train.py from the parent's report
        report = data.get("report", data.get("content", ""))
        code_match = re.search(r"```python\s*\n(.*?)```", report, re.DOTALL)
        if code_match:
            parent_code = code_match.group(1).strip()
            (path / "train.py").write_text(parent_code)
            logger.info(f"Loaded parent's best train.py from Arloop entry {parent_id}")
        else:
            logger.warning(f"Could not extract train.py from parent entry {parent_id}")


# ------------------------------------------------------------------
# Exceptions
# ------------------------------------------------------------------

class AutoresearchError(Exception):
    """General autoresearch error."""
    pass


class ExperimentTimeout(AutoresearchError):
    """Experiment exceeded time budget."""
    pass


class ExperimentError(AutoresearchError):
    """Experiment execution failed."""
    pass
