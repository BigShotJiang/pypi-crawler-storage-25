"""Pydantic request/response models — OpenAI-compatible format."""

from __future__ import annotations

from typing import Any
from pydantic import BaseModel, Field


# --- OpenAI-compatible chat completions ---

class ChatMessage(BaseModel):
    role: str = "user"
    content: str = ""


class ChatCompletionRequest(BaseModel):
    model: str = "qwen2.5:1.5b"
    messages: list[ChatMessage]
    max_tokens: int = 256
    temperature: float = 0.7
    stream: bool = False


class ChatChoice(BaseModel):
    index: int = 0
    message: ChatMessage
    finish_reason: str = "stop"


class UsageInfo(BaseModel):
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class ChatCompletionResponse(BaseModel):
    id: str = ""
    object: str = "chat.completion"
    created: int = 0
    model: str = ""
    choices: list[ChatChoice] = []
    usage: UsageInfo = UsageInfo()
    x_routed_via: str = ""  # "local" or "strue-cloud"


# --- MCP tool calls ---

class ToolCallRequest(BaseModel):
    tool: str
    arguments: dict[str, Any] = {}


class RoutingInfo(BaseModel):
    target: str  # "local" or "strue-cloud"
    reason: str
    cost: int = 0


class ToolCallResponse(BaseModel):
    result: Any = None
    error: str | None = None
    routing: RoutingInfo | None = None


# --- Health ---

class LocalModelInfo(BaseModel):
    name: str
    provider: str  # "ollama", "lm-studio"
    url: str


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str = "0.1.0"
    local_models: list[LocalModelInfo] = []
    cloud_status: str = "unknown"
    cloud_url: str = ""
