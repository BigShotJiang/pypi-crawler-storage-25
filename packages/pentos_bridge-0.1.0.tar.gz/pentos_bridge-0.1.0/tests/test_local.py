"""Tests for local model detection — mock Ollama and LM Studio responses."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from pentos_bridge.local import LocalRegistry, LocalModel


@pytest.fixture
def registry():
    return LocalRegistry(
        ollama_url="http://localhost:11434",
        lm_studio_url="http://localhost:1234",
    )


class TestOllamaDetection:
    """Test Ollama model scanning."""

    @pytest.mark.asyncio
    async def test_ollama_found(self, registry):
        """Should detect models when Ollama is running."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "models": [
                {"name": "llama3.2:1b", "size": 1000000000},
                {"name": "mistral:7b", "size": 7000000000},
                {"name": "qwen2.5:1.5b", "size": 1500000000},
            ]
        }

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            models = await registry._scan_ollama()

            assert len(models) == 3
            assert models[0].name == "llama3.2:1b"
            assert models[0].provider == "ollama"
            assert models[0].base_url == "http://localhost:11434"

    @pytest.mark.asyncio
    async def test_ollama_not_running(self, registry):
        """Should return empty list when Ollama isn't running."""
        import httpx

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.side_effect = httpx.ConnectError("refused")
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            models = await registry._scan_ollama()
            assert models == []

    @pytest.mark.asyncio
    async def test_ollama_no_models_loaded(self, registry):
        """Should return empty list when Ollama has no models."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"models": []}

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            models = await registry._scan_ollama()
            assert models == []


class TestLMStudioDetection:
    """Test LM Studio model scanning."""

    @pytest.mark.asyncio
    async def test_lm_studio_found(self, registry):
        """Should detect models when LM Studio is running."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "data": [
                {"id": "lmstudio-community/Meta-Llama-3.1-8B-Instruct"},
                {"id": "TheBloke/Mistral-7B-Instruct-v0.2"},
            ]
        }

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            models = await registry._scan_lm_studio()

            assert len(models) == 2
            assert models[0].provider == "lm-studio"
            assert models[0].base_url == "http://localhost:1234"

    @pytest.mark.asyncio
    async def test_lm_studio_not_running(self, registry):
        import httpx

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.side_effect = httpx.ConnectError("refused")
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            models = await registry._scan_lm_studio()
            assert models == []


class TestFullScan:
    """Test the combined scan."""

    @pytest.mark.asyncio
    async def test_both_providers_found(self, registry):
        """Should combine models from both providers."""
        ollama_resp = MagicMock()
        ollama_resp.status_code = 200
        ollama_resp.json.return_value = {
            "models": [{"name": "llama3.2:1b"}]
        }

        lm_resp = MagicMock()
        lm_resp.status_code = 200
        lm_resp.json.return_value = {
            "data": [{"id": "some-model"}]
        }

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()

            async def mock_get(url):
                if "11434" in url:
                    return ollama_resp
                elif "1234" in url:
                    return lm_resp
                raise Exception(f"unexpected url: {url}")

            mock_instance.get = mock_get
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            models = await registry.scan()
            assert len(models) == 2
            providers = {m.provider for m in models}
            assert providers == {"ollama", "lm-studio"}

    @pytest.mark.asyncio
    async def test_neither_running(self, registry):
        """Should return empty when nothing is running."""
        import httpx

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.side_effect = httpx.ConnectError("refused")
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            models = await registry.scan()
            assert models == []


class TestRegistryLookup:
    """Test model lookup on the registry."""

    def test_has_model(self):
        reg = LocalRegistry()
        reg.models = [
            LocalModel(name="llama3.2:1b", provider="ollama", base_url="http://localhost:11434"),
        ]
        assert reg.has_model("llama3.2:1b") is True
        assert reg.has_model("LLAMA3.2:1B") is True  # Case insensitive
        assert reg.has_model("nonexistent") is False

    def test_get_model(self):
        reg = LocalRegistry()
        model = LocalModel(name="mistral:7b", provider="ollama", base_url="http://localhost:11434")
        reg.models = [model]
        assert reg.get_model("mistral:7b") is model
        assert reg.get_model("nope") is None

    def test_get_any_model(self):
        reg = LocalRegistry()
        assert reg.get_any_model() is None
        model = LocalModel(name="test", provider="ollama", base_url="http://localhost:11434")
        reg.models = [model]
        assert reg.get_any_model() is model
