"""Tests for research identity module."""

import json
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from pentos_bridge.identity import IdentityManager, IdentityInfo, IdentityError


@pytest.fixture
def tmp_identity_dir(tmp_path):
    """Temporary identity directory."""
    return tmp_path / "identity"


@pytest.fixture
def mgr(tmp_identity_dir):
    """IdentityManager with temp directory."""
    return IdentityManager(identity_dir=tmp_identity_dir)


# ------------------------------------------------------------------
# Identity creation
# ------------------------------------------------------------------

class TestCreate:
    def test_create_basic(self, mgr, tmp_identity_dir):
        info = mgr.create("test-user")
        assert info.name == "test-user"
        assert len(info.fingerprint) == 64  # SHA-256 hex
        assert info.device_bound is False
        assert (tmp_identity_dir / "cert.pem").exists()
        assert (tmp_identity_dir / "key.pem").exists()
        assert (tmp_identity_dir / "identity.json").exists()

    def test_create_writes_valid_cert(self, mgr, tmp_identity_dir):
        mgr.create("cert-test")
        cert_pem = (tmp_identity_dir / "cert.pem").read_text()
        assert "BEGIN CERTIFICATE" in cert_pem
        assert "END CERTIFICATE" in cert_pem

    def test_create_writes_valid_key(self, mgr, tmp_identity_dir):
        mgr.create("key-test")
        key_pem = (tmp_identity_dir / "key.pem").read_text()
        assert "BEGIN PRIVATE KEY" in key_pem

    def test_create_writes_metadata(self, mgr, tmp_identity_dir):
        mgr.create("meta-test")
        meta = json.loads((tmp_identity_dir / "identity.json").read_text())
        assert meta["name"] == "meta-test"
        assert "fingerprint" in meta
        assert "created" in meta
        assert meta["version"] == 1

    def test_key_permissions(self, mgr, tmp_identity_dir):
        mgr.create("perm-test")
        key_path = tmp_identity_dir / "key.pem"
        mode = key_path.stat().st_mode & 0o777
        assert mode == 0o600

    def test_create_device_bound_fallback(self, mgr):
        """Device-bound without keyring falls back to file-based."""
        with patch("pentos_bridge.identity.IdentityManager._store_key_in_keychain", return_value=False):
            info = mgr.create("device-test", device_bound=True)
            # Falls back to Level 1 since keychain failed
            assert info.device_bound is False


# ------------------------------------------------------------------
# Identity loading
# ------------------------------------------------------------------

class TestLoad:
    def test_load_existing(self, mgr):
        created = mgr.create("load-test")
        loaded = mgr.load()
        assert loaded is not None
        assert loaded.name == "load-test"
        assert loaded.fingerprint == created.fingerprint

    def test_load_nonexistent(self, mgr):
        assert mgr.load() is None

    def test_load_with_github(self, mgr, tmp_identity_dir):
        mgr.create("gh-test")
        # Write a github.json
        github_data = {
            "github_username": "testuser",
            "github_id": 12345,
            "linked_at": "2026-01-01T00:00:00Z",
        }
        (tmp_identity_dir / "github.json").write_text(json.dumps(github_data))
        loaded = mgr.load()
        assert loaded.github_username == "testuser"
        assert loaded.github_id == 12345


# ------------------------------------------------------------------
# Export
# ------------------------------------------------------------------

class TestExport:
    def test_export_cert(self, mgr):
        mgr.create("export-test")
        pem = mgr.export_cert()
        assert "BEGIN CERTIFICATE" in pem

    def test_export_no_identity(self, mgr):
        with pytest.raises(IdentityError):
            mgr.export_cert()


# ------------------------------------------------------------------
# Existence check
# ------------------------------------------------------------------

class TestExists:
    def test_exists_false(self, mgr):
        assert mgr.exists() is False

    def test_exists_true(self, mgr):
        mgr.create("exists-test")
        assert mgr.exists() is True


# ------------------------------------------------------------------
# Signing
# ------------------------------------------------------------------

class TestSigning:
    def test_sign_data(self, mgr):
        mgr.create("sign-test")
        sig = mgr._sign_data("hello world")
        assert isinstance(sig, str)
        assert len(sig) > 0  # Ed25519 signature as hex

    def test_sign_deterministic_key(self, mgr):
        """Same key signs same data to same signature."""
        mgr.create("det-test")
        sig1 = mgr._sign_data("test data")
        sig2 = mgr._sign_data("test data")
        assert sig1 == sig2

    def test_sign_different_data(self, mgr):
        mgr.create("diff-test")
        sig1 = mgr._sign_data("data one")
        sig2 = mgr._sign_data("data two")
        assert sig1 != sig2


# ------------------------------------------------------------------
# Device hash
# ------------------------------------------------------------------

class TestDeviceHash:
    def test_device_hash_is_deterministic(self):
        h1 = IdentityManager._compute_device_hash()
        h2 = IdentityManager._compute_device_hash()
        assert h1 == h2
        assert len(h1) == 32  # 32 hex chars (truncated SHA-256)


# ------------------------------------------------------------------
# IdentityInfo
# ------------------------------------------------------------------

class TestIdentityInfo:
    def test_to_dict_basic(self):
        info = IdentityInfo(name="test", fingerprint="abc123", created="2026-01-01")
        d = info.to_dict()
        assert d["name"] == "test"
        assert d["fingerprint"] == "abc123"
        assert "github" not in d

    def test_to_dict_with_github(self):
        info = IdentityInfo(
            name="test", fingerprint="abc123", created="2026-01-01",
            github_username="user", github_id=42, github_linked_at="2026-01-02",
        )
        d = info.to_dict()
        assert d["github"]["username"] == "user"
        assert d["github"]["id"] == 42

    def test_to_dict_with_device_hash(self):
        info = IdentityInfo(name="t", fingerprint="f", created="c", device_hash="deadbeef")
        d = info.to_dict()
        assert d["device_hash"] == "deadbeef"


# ------------------------------------------------------------------
# Keychain operations (mocked)
# ------------------------------------------------------------------

class TestKeychain:
    def test_store_key_in_keychain_success(self):
        mock_keyring = MagicMock()
        mock_keyring.get_password.return_value = "stored_key"
        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = IdentityManager._store_key_in_keychain(b"key_data", "fp123")
            assert result is True

    def test_store_key_in_keychain_failure(self):
        mock_keyring = MagicMock()
        mock_keyring.set_password.side_effect = Exception("no backend")
        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = IdentityManager._store_key_in_keychain(b"key_data", "fp123")
            assert result is False

    def test_load_key_from_keychain(self):
        mock_keyring = MagicMock()
        mock_keyring.get_password.return_value = "-----BEGIN PRIVATE KEY-----"
        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = IdentityManager._load_key_from_keychain("fp123")
            assert result == b"-----BEGIN PRIVATE KEY-----"

    def test_load_key_from_keychain_not_found(self):
        mock_keyring = MagicMock()
        mock_keyring.get_password.return_value = None
        with patch.dict("sys.modules", {"keyring": mock_keyring}):
            result = IdentityManager._load_key_from_keychain("fp123")
            assert result is None


# ------------------------------------------------------------------
# GitHub link (mocked HTTP)
# ------------------------------------------------------------------

class TestGitHubLink:
    def test_link_github_returns_device_data(self, mgr):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "device_code": "dc_123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://github.com/login/device",
            "expires_in": 900,
            "interval": 5,
        }
        mock_resp.raise_for_status = MagicMock()

        with patch("httpx.post", return_value=mock_resp):
            result = mgr.link_github()
            assert result["device_code"] == "dc_123"
            assert result["user_code"] == "ABCD-1234"
            assert result["verification_uri"] == "https://github.com/login/device"

    def test_complete_github_link_saves_attestation(self, mgr, tmp_identity_dir):
        mgr.create("gh-link-test")

        # Mock token response
        token_resp = MagicMock()
        token_resp.json.return_value = {"access_token": "gho_fake"}
        token_resp.raise_for_status = MagicMock()

        # Mock user response
        user_resp = MagicMock()
        user_resp.json.return_value = {"login": "testuser", "id": 99}
        user_resp.raise_for_status = MagicMock()

        with patch("httpx.post", return_value=token_resp), \
             patch("httpx.get", return_value=user_resp):
            result = mgr.complete_github_link("dc_123")
            assert result["github_username"] == "testuser"
            assert result["github_id"] == 99
            assert (tmp_identity_dir / "github.json").exists()


# ------------------------------------------------------------------
# ArNS link (mocked HTTP)
# ------------------------------------------------------------------

class TestArNSLink:
    def test_link_arns_success(self, mgr, tmp_identity_dir):
        mgr.create("arns-test")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()

        with patch("httpx.head", return_value=mock_resp):
            result = mgr.link_arns("jordan")
            assert result["arns_name"] == "jordan"
            assert "verified_at" in result
            assert (tmp_identity_dir / "arns.json").exists()

    def test_link_arns_saves_attestation(self, mgr, tmp_identity_dir):
        mgr.create("arns-attest-test")

        mock_resp = MagicMock()
        mock_resp.status_code = 200

        with patch("httpx.head", return_value=mock_resp):
            mgr.link_arns("testname")

        arns_data = json.loads((tmp_identity_dir / "arns.json").read_text())
        assert arns_data["arns_name"] == "testname"
        assert "signature" in arns_data
        assert "cert_fingerprint" in arns_data

    def test_link_arns_name_not_found(self, mgr):
        mgr.create("arns-fail-test")

        mock_resp = MagicMock()
        mock_resp.status_code = 404

        with patch("httpx.head", return_value=mock_resp):
            with pytest.raises(IdentityError, match="did not resolve"):
                mgr.link_arns("nonexistent_name_xyz")

    def test_link_arns_no_identity(self, mgr):
        with pytest.raises(IdentityError, match="No identity found"):
            mgr.link_arns("jordan")

    def test_load_includes_arns(self, mgr, tmp_identity_dir):
        mgr.create("arns-load-test")

        mock_resp = MagicMock()
        mock_resp.status_code = 200

        with patch("httpx.head", return_value=mock_resp):
            mgr.link_arns("myname")

        loaded = mgr.load()
        assert loaded.arns_name == "myname"
        assert loaded.arns_verified_at != ""

    def test_to_dict_includes_arns(self):
        info = IdentityInfo(
            name="test", fingerprint="fp", created="c",
            arns_name="jordan", arns_verified_at="2026-03-28T00:00:00Z",
        )
        d = info.to_dict()
        assert d["arns"]["name"] == "jordan"
        assert d["arns"]["verified_at"] == "2026-03-28T00:00:00Z"

    def test_link_arns_timeout(self, mgr):
        mgr.create("arns-timeout-test")

        import httpx as _httpx
        with patch("httpx.head", side_effect=_httpx.TimeoutException("timed out")):
            with pytest.raises(IdentityError, match="Timeout"):
                mgr.link_arns("slowname")


# ------------------------------------------------------------------
# Integration with autoresearch (unit test)
# ------------------------------------------------------------------

class TestAutoresearchIntegration:
    def test_identity_loaded_in_harness(self, mgr, tmp_identity_dir):
        """Autoresearch harness loads identity on init."""
        mgr.create("harness-test")

        with patch("pentos_bridge.identity.IDENTITY_DIR", tmp_identity_dir):
            from pentos_bridge.autoresearch import AutoresearchHarness
            harness = AutoresearchHarness()
            assert harness._identity_info is not None
            assert harness._identity_info.name == "harness-test"

    def test_experiment_log_includes_fingerprint(self, mgr, tmp_identity_dir):
        """Experiment log includes cert_fingerprint when identity is present."""
        info = mgr.create("log-test")

        with patch("pentos_bridge.identity.IDENTITY_DIR", tmp_identity_dir):
            from pentos_bridge.autoresearch import AutoresearchHarness
            harness = AutoresearchHarness()
            harness.state.metric_name = "val_loss"
            harness.state.budget_minutes = 5
            harness.state.timestamp_start = "2026-01-01T00:00:00Z"
            harness.state.timestamp_end = "2026-01-01T00:05:00Z"

            # Create a minimal experiment dir
            exp_dir = tmp_identity_dir.parent / "experiment"
            exp_dir.mkdir()
            (exp_dir / "program.md").write_text("metric: val_loss")

            log = harness._build_experiment_log(exp_dir)
            assert log["cert_fingerprint"] == info.fingerprint
            assert log["identity_name"] == "log-test"

    def test_experiment_log_includes_arns(self, mgr, tmp_identity_dir):
        """Experiment log includes arns_name when ArNS is linked."""
        mgr.create("arns-harness-test")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("httpx.head", return_value=mock_resp):
            mgr.link_arns("myresearch")

        with patch("pentos_bridge.identity.IDENTITY_DIR", tmp_identity_dir):
            from pentos_bridge.autoresearch import AutoresearchHarness
            harness = AutoresearchHarness()
            harness.state.metric_name = "val_loss"
            harness.state.budget_minutes = 5
            harness.state.timestamp_start = "2026-01-01T00:00:00Z"
            harness.state.timestamp_end = "2026-01-01T00:05:00Z"

            exp_dir = tmp_identity_dir.parent / "experiment2"
            exp_dir.mkdir()
            (exp_dir / "program.md").write_text("metric: val_loss")

            log = harness._build_experiment_log(exp_dir)
            assert log["arns_name"] == "myresearch"


# ------------------------------------------------------------------
# Integration with arloop client (unit test)
# ------------------------------------------------------------------

class TestArloopIntegration:
    def test_identity_auto_loaded(self, mgr, tmp_identity_dir):
        """Arloop client loads identity from specified path."""
        info = mgr.create("arloop-test")

        from arloop.client import Arloop
        loop = Arloop(process_id="test_process", identity=str(tmp_identity_dir))
        assert loop._identity is not None
        assert loop._identity["fingerprint"] == info.fingerprint

    def test_identity_not_found(self):
        """Arloop client gracefully handles missing identity."""
        from arloop.client import Arloop
        loop = Arloop(process_id="test_process", identity="/nonexistent/path")
        assert loop._identity is None

    def test_identity_includes_arns(self, mgr, tmp_identity_dir):
        """Arloop client loads ArNS name from identity directory."""
        mgr.create("arns-arloop-test")

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        with patch("httpx.head", return_value=mock_resp):
            mgr.link_arns("myresearch")

        from arloop.client import Arloop
        loop = Arloop(process_id="test_process", identity=str(tmp_identity_dir))
        assert loop._identity is not None
        assert loop._identity["arns_name"] == "myresearch"
