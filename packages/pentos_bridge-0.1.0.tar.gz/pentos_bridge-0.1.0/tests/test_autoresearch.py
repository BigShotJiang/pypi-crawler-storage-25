"""Tests for the autoresearch harness."""

import asyncio
import json
import os
import subprocess
import textwrap
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from pentos_bridge.autoresearch import (
    AutoresearchHarness,
    AutoresearchError,
    AutoresearchState,
    ExperimentError,
    ExperimentResult,
    ExperimentTimeout,
)


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------

@pytest.fixture
def tmp_experiment(tmp_path):
    """Create a minimal experiment directory."""
    program = tmp_path / "program.md"
    program.write_text(textwrap.dedent("""\
        # Experiment: Optimize val_loss

        metric: val_loss
        Lower is better. Modify train.py to reduce validation loss.
    """))

    train = tmp_path / "train.py"
    train.write_text(textwrap.dedent("""\
        import random
        random.seed(42)
        val_loss = random.uniform(1.0, 2.0)
        print(f"val_loss = {val_loss:.4f}")
    """))

    prepare = tmp_path / "prepare.py"
    prepare.write_text("# Data preparation (immutable)\nprint('prepared')\n")

    # Init git
    subprocess.run(["git", "init"], cwd=tmp_path, capture_output=True, check=True)
    subprocess.run(["git", "add", "."], cwd=tmp_path, capture_output=True, check=True)
    subprocess.run(
        ["git", "commit", "-m", "init"],
        cwd=tmp_path, capture_output=True, check=True,
        env={**os.environ, "GIT_AUTHOR_NAME": "test", "GIT_AUTHOR_EMAIL": "test@test.com",
             "GIT_COMMITTER_NAME": "test", "GIT_COMMITTER_EMAIL": "test@test.com"},
    )

    return tmp_path


@pytest.fixture
def harness():
    """Create a harness instance."""
    return AutoresearchHarness(
        model="deepseek-ai/DeepSeek-V3",
        strue_api_key="sk_test",
        strue_base_url="https://gateway.test",
    )


# ------------------------------------------------------------------
# Directory validation
# ------------------------------------------------------------------

class TestDirectoryValidation:
    def test_validates_missing_dir(self, tmp_path):
        with pytest.raises(AutoresearchError, match="Not a directory"):
            AutoresearchHarness._validate_directory(tmp_path / "nonexistent")

    def test_validates_missing_program_md(self, tmp_path):
        (tmp_path / "train.py").write_text("pass")
        with pytest.raises(AutoresearchError, match="Missing program.md"):
            AutoresearchHarness._validate_directory(tmp_path)

    def test_validates_missing_train_py(self, tmp_path):
        (tmp_path / "program.md").write_text("# test")
        with pytest.raises(AutoresearchError, match="Missing train.py"):
            AutoresearchHarness._validate_directory(tmp_path)

    def test_validates_good_directory(self, tmp_experiment):
        AutoresearchHarness._validate_directory(tmp_experiment)


# ------------------------------------------------------------------
# Metric extraction
# ------------------------------------------------------------------

class TestMetricExtraction:
    def test_extract_val_loss(self):
        output = "Epoch 1/10\nval_loss = 1.3456\nDone."
        assert AutoresearchHarness._extract_metric(output) == 1.3456

    def test_extract_val_bpb(self):
        output = "Training...\nval_bpb: 1.234\nFinished."
        assert AutoresearchHarness._extract_metric(output) == 1.234

    def test_extract_accuracy(self):
        output = "accuracy = 0.95\n"
        assert AutoresearchHarness._extract_metric(output) == 0.95

    def test_extract_last_match(self):
        output = "val_loss = 2.0\nval_loss = 1.5\nval_loss = 1.2\n"
        assert AutoresearchHarness._extract_metric(output) == 1.2

    def test_no_metric_found(self):
        output = "Some output with no metric"
        assert AutoresearchHarness._extract_metric(output) is None


# ------------------------------------------------------------------
# Metric name from program.md
# ------------------------------------------------------------------

class TestMetricNameExtraction:
    def test_explicit_metric(self):
        assert AutoresearchHarness._extract_metric_name("metric: val_bpb") == "val_bpb"

    def test_evaluate_format(self):
        assert AutoresearchHarness._extract_metric_name("evaluate: val_loss") == "val_loss"

    def test_fallback_to_text(self):
        assert AutoresearchHarness._extract_metric_name("Optimize the val_loss metric") == "val_loss"

    def test_default(self):
        assert AutoresearchHarness._extract_metric_name("Do some stuff") == "metric"


# ------------------------------------------------------------------
# Planning response parsing
# ------------------------------------------------------------------

class TestPlanningParsing:
    def test_parses_hypothesis_and_code(self):
        response = textwrap.dedent("""\
            HYPOTHESIS: Try a larger learning rate

            ```python
            lr = 0.01
            print(f"val_loss = {lr}")
            ```
        """)
        hypothesis, code = AutoresearchHarness._parse_planning_response(response)
        assert hypothesis == "Try a larger learning rate"
        assert "lr = 0.01" in code

    def test_missing_hypothesis(self):
        response = "```python\nprint('hello')\n```"
        hypothesis, code = AutoresearchHarness._parse_planning_response(response)
        assert hypothesis == "Modification proposed by planning model"
        assert "print('hello')" in code

    def test_no_code_block(self):
        response = "HYPOTHESIS: Try something\nNo code here"
        hypothesis, code = AutoresearchHarness._parse_planning_response(response)
        assert hypothesis == "Try something"
        assert code == ""


# ------------------------------------------------------------------
# Code validation
# ------------------------------------------------------------------

class TestCodeValidation:
    def test_valid_code(self, tmp_experiment):
        assert AutoresearchHarness._validate_code("x = 1\nprint(x)", tmp_experiment)

    def test_invalid_code(self, tmp_experiment):
        assert not AutoresearchHarness._validate_code("def f(\n  broken", tmp_experiment)


# ------------------------------------------------------------------
# Decision engine
# ------------------------------------------------------------------

class TestDecisionEngine:
    def test_improvement_lower_is_better(self):
        assert AutoresearchHarness._is_improvement(1.0, 1.5) is True

    def test_no_improvement(self):
        assert AutoresearchHarness._is_improvement(1.5, 1.0) is False

    def test_equal_no_improvement(self):
        assert AutoresearchHarness._is_improvement(1.0, 1.0) is False

    def test_first_metric_always_improvement(self):
        assert AutoresearchHarness._is_improvement(1.5, None) is True


# ------------------------------------------------------------------
# Diff computation
# ------------------------------------------------------------------

class TestDiffComputation:
    def test_computes_diff(self):
        old = "line1\nline2\nline3\n"
        new = "line1\nmodified\nline3\n"
        diff = AutoresearchHarness._compute_diff(old, new)
        assert "-line2" in diff
        assert "+modified" in diff

    def test_identical_code(self):
        code = "same\n"
        diff = AutoresearchHarness._compute_diff(code, code)
        assert diff == ""


# ------------------------------------------------------------------
# Results TSV
# ------------------------------------------------------------------

class TestResultsTSV:
    def test_creates_tsv_with_header(self, tmp_path):
        result = ExperimentResult(
            number=1, hypothesis="test", diff="", metric_before=1.5,
            metric_after=1.3, decision="keep", duration_seconds=60.0,
            git_hash="abc123", timestamp="2026-03-28T01:00:00Z",
        )
        AutoresearchHarness._append_results_tsv(tmp_path, result)

        tsv = (tmp_path / "results.tsv").read_text()
        assert "experiment\t" in tsv
        assert "1\ttest\t1.5\t1.3\tkeep" in tsv

    def test_appends_without_header(self, tmp_path):
        r1 = ExperimentResult(1, "first", "", 1.5, 1.3, "keep", 60.0, "a", "t1")
        r2 = ExperimentResult(2, "second", "", 1.3, 1.4, "discard", 55.0, "", "t2")

        AutoresearchHarness._append_results_tsv(tmp_path, r1)
        AutoresearchHarness._append_results_tsv(tmp_path, r2)

        lines = (tmp_path / "results.tsv").read_text().strip().split("\n")
        assert len(lines) == 3  # header + 2 results


# ------------------------------------------------------------------
# Experiment log format
# ------------------------------------------------------------------

class TestExperimentLog:
    def test_builds_log_structure(self, tmp_experiment, harness):
        harness.state = AutoresearchState(
            status="completed",
            experiment_dir=str(tmp_experiment),
            model="deepseek-ai/DeepSeek-V3",
            budget_minutes=5,
            max_experiments=10,
            best_metric=1.2,
            metric_name="val_loss",
            experiments=[
                ExperimentResult(1, "test", "diff", 1.5, 1.2, "keep", 60.0, "abc", "t1"),
            ],
            timestamp_start="2026-03-28T01:00:00Z",
            timestamp_end="2026-03-28T01:10:00Z",
        )

        log = harness._build_experiment_log(tmp_experiment)

        assert log["type"] == "autoresearch"
        assert log["version"] == "1.0"
        assert log["metric"] == "val_loss"
        assert log["best_metric"] == 1.2
        assert log["total_experiments"] == 1
        assert log["planning_model"] == "deepseek-ai/DeepSeek-V3"
        assert len(log["experiments"]) == 1
        assert log["experiments"][0]["decision"] == "keep"


# ------------------------------------------------------------------
# Report formatting
# ------------------------------------------------------------------

class TestReportFormatting:
    def test_formats_report(self):
        log = {
            "metric": "val_loss",
            "planning_model": "deepseek",
            "budget_minutes": 5,
            "total_experiments": 2,
            "best_metric": 1.2,
            "parent_id": None,
            "experiments": [
                {"number": 1, "hypothesis": "h1", "metric_before": 1.5,
                 "metric_after": 1.2, "decision": "keep"},
                {"number": 2, "hypothesis": "h2", "metric_before": 1.2,
                 "metric_after": 1.3, "decision": "discard"},
            ],
        }
        report = AutoresearchHarness._format_report(log, "print('best')")
        assert "# Autoresearch Report" in report
        assert "val_loss" in report
        assert "**Kept:** 1" in report
        assert "print('best')" in report

    def test_report_with_parent(self):
        log = {
            "metric": "val_loss", "planning_model": "m", "budget_minutes": 5,
            "total_experiments": 0, "best_metric": 1.0, "parent_id": "tx_parent",
            "experiments": [],
        }
        report = AutoresearchHarness._format_report(log, "code")
        assert "Continued From" in report
        assert "tx_parent" in report


# ------------------------------------------------------------------
# Experiment runner (mocked subprocess)
# ------------------------------------------------------------------

class TestExperimentRunner:
    @pytest.mark.asyncio
    async def test_runs_train_py(self, tmp_experiment, harness):
        metric = await harness._run_experiment(tmp_experiment, budget_minutes=1)
        assert isinstance(metric, float)
        assert (tmp_experiment / "run.log").exists()

    @pytest.mark.asyncio
    async def test_timeout_kills_process(self, tmp_path, harness):
        # Create an experiment that takes too long
        (tmp_path / "program.md").write_text("metric: val_loss")
        (tmp_path / "train.py").write_text(textwrap.dedent("""\
            import time
            time.sleep(999)
            print("val_loss = 1.0")
        """))

        with pytest.raises(ExperimentTimeout):
            # Budget of 0 minutes → timeout_seconds = 0 * 60 * 1.1 = 0
            # Use a very small budget that will trigger timeout quickly
            await harness._run_experiment(tmp_path, budget_minutes=0)

    @pytest.mark.asyncio
    async def test_nonzero_exit_raises(self, tmp_path, harness):
        (tmp_path / "program.md").write_text("metric: val_loss")
        (tmp_path / "train.py").write_text("raise SystemExit(1)")

        with pytest.raises(ExperimentError, match="exited with code"):
            await harness._run_experiment(tmp_path, budget_minutes=1)

    @pytest.mark.asyncio
    async def test_no_metric_raises(self, tmp_path, harness):
        (tmp_path / "program.md").write_text("metric: val_loss")
        (tmp_path / "train.py").write_text("print('no metric here')")

        with pytest.raises(ExperimentError, match="Could not find metric"):
            await harness._run_experiment(tmp_path, budget_minutes=1)


# ------------------------------------------------------------------
# Planning agent (mocked HTTP)
# ------------------------------------------------------------------

class TestPlanningAgent:
    @pytest.mark.asyncio
    async def test_calls_strue_cloud(self, harness):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content":
                "HYPOTHESIS: Increase learning rate\n\n```python\nlr = 0.01\nprint(f'val_loss = {lr}')\n```"
            }}]
        }

        with patch("pentos_bridge.autoresearch.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client_cls.return_value = mock_client

            result = await harness._call_strue("test prompt")
            assert "Increase learning rate" in result

    @pytest.mark.asyncio
    async def test_calls_ollama(self, harness):
        harness.model = "ollama:mistral:7b"
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "HYPOTHESIS: Test\n\n```python\npass\n```"}}]
        }

        with patch("pentos_bridge.autoresearch.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=mock_response)
            mock_client_cls.return_value = mock_client

            result = await harness._call_ollama("test prompt", "mistral:7b")
            assert "Test" in result


# ------------------------------------------------------------------
# Full loop (mocked planning + real subprocess)
# ------------------------------------------------------------------

class TestFullLoop:
    @pytest.mark.asyncio
    async def test_single_experiment_keep(self, tmp_experiment, harness):
        """Run one experiment that improves the metric."""
        improved_code = textwrap.dedent("""\
            import random
            random.seed(42)
            val_loss = 0.5  # hard-coded improvement
            print(f"val_loss = {val_loss:.4f}")
        """)

        call_count = 0

        async def mock_plan(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            return "Lower the loss directly", improved_code

        with patch.object(harness, "_plan_experiment", side_effect=mock_plan):
            state = await harness.run(
                str(tmp_experiment),
                budget_minutes=1,
                max_experiments=1,
                publish=False,
            )

        assert state.status == "completed"
        assert len(state.experiments) == 1
        assert state.experiments[0].decision == "keep"
        assert state.best_metric is not None
        assert (tmp_experiment / "results.tsv").exists()

    @pytest.mark.asyncio
    async def test_single_experiment_discard(self, tmp_experiment, harness):
        """Run one experiment that doesn't improve the metric."""
        worse_code = textwrap.dedent("""\
            import random
            random.seed(42)
            val_loss = 9.9  # much worse
            print(f"val_loss = {val_loss:.4f}")
        """)

        async def mock_plan(*args, **kwargs):
            return "Make it worse", worse_code

        with patch.object(harness, "_plan_experiment", side_effect=mock_plan):
            state = await harness.run(
                str(tmp_experiment),
                budget_minutes=1,
                max_experiments=1,
                publish=False,
            )

        assert state.status == "completed"
        assert len(state.experiments) == 1
        assert state.experiments[0].decision == "discard"

    @pytest.mark.asyncio
    async def test_syntax_error_discarded(self, tmp_experiment, harness):
        """Planning model returns invalid code — should be discarded."""
        async def mock_plan(*args, **kwargs):
            return "Bad code", "def f(\n  broken syntax"

        with patch.object(harness, "_plan_experiment", side_effect=mock_plan):
            state = await harness.run(
                str(tmp_experiment),
                budget_minutes=1,
                max_experiments=1,
                publish=False,
            )

        assert state.status == "completed"
        assert len(state.experiments) == 1
        assert state.experiments[0].decision == "discard"
        assert state.experiments[0].metric_after is None

    @pytest.mark.asyncio
    async def test_stop_request(self, tmp_experiment, harness):
        """Stop after first experiment."""
        improved_code = textwrap.dedent("""\
            import random
            random.seed(42)
            val_loss = 0.5
            print(f"val_loss = {val_loss:.4f}")
        """)

        call_count = 0

        async def mock_plan(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                harness.stop()
            return "Improve", improved_code

        with patch.object(harness, "_plan_experiment", side_effect=mock_plan):
            state = await harness.run(
                str(tmp_experiment),
                budget_minutes=1,
                max_experiments=100,
                publish=False,
            )

        assert state.status == "completed"
        # Should have stopped early, not run all 100
        assert len(state.experiments) <= 3


# ------------------------------------------------------------------
# Publication (mocked HTTP)
# ------------------------------------------------------------------

class TestPublication:
    @pytest.mark.asyncio
    async def test_publish_flow(self, tmp_experiment, harness):
        harness.state = AutoresearchState(
            status="completed",
            experiment_dir=str(tmp_experiment),
            model="deepseek-ai/DeepSeek-V3",
            budget_minutes=5,
            best_metric=1.2,
            metric_name="val_loss",
            experiments=[
                ExperimentResult(1, "test", "diff", 1.5, 1.2, "keep", 60.0, "abc", "t1"),
            ],
            timestamp_start="2026-03-28T01:00:00Z",
            timestamp_end="2026-03-28T01:10:00Z",
        )

        store_response = MagicMock()
        store_response.status_code = 200
        store_response.raise_for_status = MagicMock()
        store_response.json.return_value = {"tx_id": "ar_tx_123", "id": "ar_tx_123"}

        upload_response = MagicMock()
        upload_response.status_code = 200
        upload_response.raise_for_status = MagicMock()
        upload_response.json.return_value = {"id": "loop_entry_1", "url": "https://arloop.org/r/loop_entry_1"}

        with patch("pentos_bridge.autoresearch.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(side_effect=[store_response, upload_response])
            mock_client_cls.return_value = mock_client

            result = await harness._publish(tmp_experiment)

        assert result["arweave_tx_id"] == "ar_tx_123"
        assert result["arloop"]["url"] == "https://arloop.org/r/loop_entry_1"
        assert result["integrity_hash"].startswith("sha256:")


# ------------------------------------------------------------------
# Continue mode (mocked HTTP)
# ------------------------------------------------------------------

class TestContinueMode:
    @pytest.mark.asyncio
    async def test_fetches_parent_train_py(self, tmp_experiment, harness):
        parent_response = MagicMock()
        parent_response.status_code = 200
        parent_response.raise_for_status = MagicMock()
        parent_response.json.return_value = {
            "report": "## Best train.py\n\n```python\nprint('parent code')\nprint(f'val_loss = 0.8')\n```"
        }

        with patch("pentos_bridge.autoresearch.httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.get = AsyncMock(return_value=parent_response)
            mock_client_cls.return_value = mock_client

            await harness._fetch_parent(tmp_experiment, "tx_parent_123")

        code = (tmp_experiment / "train.py").read_text()
        assert "parent code" in code


# ------------------------------------------------------------------
# State management
# ------------------------------------------------------------------

class TestState:
    def test_state_to_dict(self):
        state = AutoresearchState(
            status="running",
            experiment_dir="/tmp/exp",
            model="test-model",
            current_experiment=5,
            best_metric=1.3,
        )
        d = state.to_dict()
        assert d["status"] == "running"
        assert d["current_experiment"] == 5
        assert d["best_metric"] == 1.3

    def test_initial_state(self):
        state = AutoresearchState()
        assert state.status == "idle"
        assert state.experiments == []
        assert state.best_metric is None


# ------------------------------------------------------------------
# Immutable file verification
# ------------------------------------------------------------------

class TestImmutableFiles:
    def test_no_changes_passes(self, tmp_experiment):
        assert AutoresearchHarness._verify_immutable_files(tmp_experiment) is True

    def test_prepare_py_change_detected(self, tmp_experiment):
        (tmp_experiment / "prepare.py").write_text("# modified\n")
        assert AutoresearchHarness._verify_immutable_files(tmp_experiment) is False
