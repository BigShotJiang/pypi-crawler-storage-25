"""Tests for MCP server — verify tool definitions and handling."""

import pytest
import json
from unittest.mock import AsyncMock, patch, MagicMock

from pentos_bridge.config import BridgeConfig
from pentos_bridge.local import LocalRegistry, LocalModel
from pentos_bridge.router import SmartRouter
from pentos_bridge.mcp import MCPStdioServer, TOOL_DEFINITIONS


@pytest.fixture
def config():
    return BridgeConfig(strue_api_key="sk_test")


@pytest.fixture
def registry():
    reg = LocalRegistry()
    reg.models = [
        LocalModel(name="llama3.2:1b", provider="ollama", base_url="http://localhost:11434"),
    ]
    return reg


@pytest.fixture
def mcp_server(config, registry):
    router = SmartRouter(config, registry)
    return MCPStdioServer(config, registry, router)


class TestToolDefinitions:
    """Verify MCP tool schemas match expected format."""

    def test_all_tools_present(self):
        names = {t["name"] for t in TOOL_DEFINITIONS}
        expected = {"inference", "research", "search_research", "data_query",
                    "store", "retrieve", "gpu_list",
                    "memory_store", "memory_recall", "memory_search", "memory_forget"}
        assert names == expected

    def test_tools_have_input_schema(self):
        for tool in TOOL_DEFINITIONS:
            assert "inputSchema" in tool, f"{tool['name']} missing inputSchema"
            assert tool["inputSchema"]["type"] == "object"

    def test_inference_tool_schema(self):
        inference = next(t for t in TOOL_DEFINITIONS if t["name"] == "inference")
        props = inference["inputSchema"]["properties"]
        assert "prompt" in props
        assert "model" in props
        assert "max_tokens" in props
        assert inference["inputSchema"]["required"] == ["prompt"]

    def test_research_tool_schema(self):
        research = next(t for t in TOOL_DEFINITIONS if t["name"] == "research")
        assert "query" in research["inputSchema"]["properties"]
        assert research["inputSchema"]["required"] == ["query"]

    def test_store_tool_schema(self):
        store = next(t for t in TOOL_DEFINITIONS if t["name"] == "store")
        assert "data" in store["inputSchema"]["properties"]
        assert store["inputSchema"]["required"] == ["data"]


class TestMCPProtocol:
    """Test JSON-RPC request handling."""

    @pytest.mark.asyncio
    async def test_initialize(self, mcp_server):
        request = {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}}
        response = await mcp_server._handle_request(request)

        assert response["id"] == 1
        assert response["result"]["protocolVersion"] == "2024-11-05"
        assert response["result"]["serverInfo"]["name"] == "pentos-bridge"

    @pytest.mark.asyncio
    async def test_tools_list(self, mcp_server):
        request = {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}}
        response = await mcp_server._handle_request(request)

        assert response["id"] == 2
        tools = response["result"]["tools"]
        assert len(tools) == 11
        names = {t["name"] for t in tools}
        assert "inference" in names

    @pytest.mark.asyncio
    async def test_notification_no_response(self, mcp_server):
        """Notifications should return None (no response)."""
        request = {"jsonrpc": "2.0", "method": "notifications/initialized"}
        response = await mcp_server._handle_request(request)
        assert response is None

    @pytest.mark.asyncio
    async def test_unknown_method(self, mcp_server):
        request = {"jsonrpc": "2.0", "id": 3, "method": "unknown/method", "params": {}}
        response = await mcp_server._handle_request(request)

        assert response["error"]["code"] == -32601

    @pytest.mark.asyncio
    async def test_tool_call_inference(self, mcp_server):
        """Test calling the inference tool via MCP."""
        mock_response = {
            "id": "chatcmpl-test",
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": "Hello!"},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
        }

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = mock_response
            mock_resp.raise_for_status = MagicMock()

            mock_instance = AsyncMock()
            mock_instance.post.return_value = mock_resp
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            request = {
                "jsonrpc": "2.0",
                "id": 4,
                "method": "tools/call",
                "params": {
                    "name": "inference",
                    "arguments": {"prompt": "Hi", "model": "llama3.2:1b"},
                },
            }
            response = await mcp_server._handle_request(request)

            assert response["id"] == 4
            content = response["result"]["content"][0]
            assert content["type"] == "text"
            result_data = json.loads(content["text"])
            assert result_data["routed_via"] == "local"

    @pytest.mark.asyncio
    async def test_tool_call_unknown_tool(self, mcp_server):
        request = {
            "jsonrpc": "2.0",
            "id": 5,
            "method": "tools/call",
            "params": {"name": "nonexistent", "arguments": {}},
        }
        response = await mcp_server._handle_request(request)
        result_data = json.loads(response["result"]["content"][0]["text"])
        assert "error" in result_data
