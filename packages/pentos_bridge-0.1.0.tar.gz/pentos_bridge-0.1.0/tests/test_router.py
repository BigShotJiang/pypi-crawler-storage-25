"""Tests for the smart router — verify routing decisions."""

import pytest
import asyncio
import json
from unittest.mock import AsyncMock, patch, MagicMock

from pentos_bridge.config import BridgeConfig
from pentos_bridge.local import LocalRegistry, LocalModel
from pentos_bridge.router import SmartRouter
from pentos_bridge.models import ChatCompletionRequest, ChatMessage


@pytest.fixture
def config():
    return BridgeConfig(
        strue_api_key="sk_test_key",
        strue_base_url="https://api.strue.com",
    )


@pytest.fixture
def registry_with_models():
    """Registry with pre-loaded local models (no actual scanning)."""
    reg = LocalRegistry()
    reg.models = [
        LocalModel(name="llama3.2:1b", provider="ollama", base_url="http://localhost:11434"),
        LocalModel(name="mistral:7b", provider="ollama", base_url="http://localhost:11434"),
    ]
    return reg


@pytest.fixture
def empty_registry():
    reg = LocalRegistry()
    reg.models = []
    return reg


@pytest.fixture
def router(config, registry_with_models):
    return SmartRouter(config, registry_with_models)


@pytest.fixture
def cloud_only_router(config, empty_registry):
    return SmartRouter(config, empty_registry)


class TestRoutingDecisions:
    """Test that routing logic picks local vs cloud correctly."""

    def test_local_model_available_routes_local(self, router):
        """Tier 1 model available locally → should route local."""
        assert router._should_route_local("llama3.2:1b") is True

    def test_tier2_model_available_routes_local(self, router):
        """Tier 2 model available locally → should route local."""
        assert router._should_route_local("mistral:7b") is True

    def test_unknown_model_routes_cloud(self, router):
        """Model not loaded locally → should not route local."""
        assert router._should_route_local("deepseek-ai/DeepSeek-V3") is False

    def test_no_local_models_routes_cloud(self, cloud_only_router):
        """No local models → everything goes to cloud."""
        assert cloud_only_router._should_route_local("llama3.2:1b") is False

    def test_prefer_local_false_skips_local(self, config, registry_with_models):
        """prefer_local=False → always cloud."""
        config.prefer_local = False
        router = SmartRouter(config, registry_with_models)
        # _should_route_local returns True but route_chat_completion checks prefer_local
        # The check is in route_chat_completion, not _should_route_local
        assert router._should_route_local("llama3.2:1b") is True  # Method itself doesn't check pref

    @pytest.mark.asyncio
    async def test_route_chat_completion_local(self, router):
        """Full routing: local model available, should call local."""
        request = ChatCompletionRequest(
            model="llama3.2:1b",
            messages=[ChatMessage(role="user", content="Hello")],
        )

        mock_response = {
            "id": "chatcmpl-test",
            "object": "chat.completion",
            "created": 1234567890,
            "model": "llama3.2:1b",
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": "Hi there!"},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
        }

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = mock_response
            mock_resp.raise_for_status = MagicMock()

            mock_instance = AsyncMock()
            mock_instance.post.return_value = mock_resp
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result, via = await router.route_chat_completion(request)

            assert via == "local"
            assert result.choices[0].message.content == "Hi there!"
            assert result.model == "llama3.2:1b"

    @pytest.mark.asyncio
    async def test_route_chat_completion_cloud_fallback(self, cloud_only_router):
        """No local models → routes to cloud."""
        request = ChatCompletionRequest(
            model="llama3.2:1b",
            messages=[ChatMessage(role="user", content="Hello")],
        )

        mock_response = {
            "id": "chatcmpl-cloud",
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": "Cloud response"},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 5, "completion_tokens": 3, "total_tokens": 8},
        }

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = mock_response
            mock_resp.raise_for_status = MagicMock()

            mock_instance = AsyncMock()
            mock_instance.post.return_value = mock_resp
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            # Cloud client uses _request which also uses httpx.AsyncClient
            with patch("pentos_bridge.cloud.httpx.AsyncClient") as mock_cloud_client:
                mock_cloud_resp = MagicMock()
                mock_cloud_resp.status_code = 200
                mock_cloud_resp.json.return_value = mock_response
                mock_cloud_resp.raise_for_status = MagicMock()

                mock_cloud_instance = AsyncMock()
                mock_cloud_instance.request.return_value = mock_cloud_resp
                mock_cloud_instance.__aenter__ = AsyncMock(return_value=mock_cloud_instance)
                mock_cloud_instance.__aexit__ = AsyncMock(return_value=False)
                mock_cloud_client.return_value = mock_cloud_instance

                result, via = await cloud_only_router.route_chat_completion(request)

                assert via == "strue-cloud"
                assert result.choices[0].message.content == "Cloud response"


class TestModelTiers:
    """Test model tier classification."""

    def test_tier1_models(self, config):
        assert config.get_model_tier("llama3.2:1b") == 1
        assert config.get_model_tier("qwen2.5:1.5b") == 1

    def test_tier2_models(self, config):
        assert config.get_model_tier("mistral:7b") == 2
        assert config.get_model_tier("llama3.2:8b") == 2

    def test_tier3_models(self, config):
        assert config.get_model_tier("deepseek-ai/DeepSeek-V3") == 3
        assert config.get_model_tier("covenant-72b") == 3

    def test_unknown_model_heuristic(self, config):
        """Unknown models use parameter count heuristic."""
        assert config.get_model_tier("custom-model-1b") == 1
        assert config.get_model_tier("custom-model-70b") == 3
