"""Tests for EverMemOS integration — detection, routing, MCP tools."""

import pytest
import json
from unittest.mock import AsyncMock, MagicMock, patch

from pentos_bridge.config import BridgeConfig
from pentos_bridge.local import LocalRegistry, LocalModel, EverMemOSInfo
from pentos_bridge.router import SmartRouter
from pentos_bridge.mcp import MCPStdioServer, TOOL_DEFINITIONS


@pytest.fixture
def config():
    return BridgeConfig(strue_api_key="sk_test_key")


@pytest.fixture
def registry_with_evermemos():
    """Registry with EverMemOS available."""
    reg = LocalRegistry(evermemos_url="http://localhost:1995")
    reg.models = [
        LocalModel(name="llama3.2:1b", provider="ollama", base_url="http://localhost:11434"),
    ]
    reg.evermemos = EverMemOSInfo(
        available=True,
        url="http://localhost:1995",
        version="0.2.0",
        memory_count=42,
    )
    return reg


@pytest.fixture
def registry_no_evermemos():
    """Registry without EverMemOS."""
    reg = LocalRegistry()
    reg.models = []
    reg.evermemos = EverMemOSInfo(available=False)
    return reg


class TestEverMemOSDetection:
    """Test EverMemOS scanning."""

    @pytest.mark.asyncio
    async def test_evermemos_healthy(self):
        """Should detect healthy EverMemOS instance."""
        registry = LocalRegistry(evermemos_url="http://localhost:1995")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "status": "healthy",
            "version": "0.2.0",
            "memory_count": 1247,
        }

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result = await registry._scan_evermemos()

            assert result is True
            assert registry.evermemos.available is True
            assert registry.evermemos.version == "0.2.0"
            assert registry.evermemos.memory_count == 1247

    @pytest.mark.asyncio
    async def test_evermemos_not_running(self):
        """Should mark unavailable when EverMemOS isn't running."""
        import httpx
        registry = LocalRegistry(evermemos_url="http://localhost:1995")

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.side_effect = httpx.ConnectError("refused")
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result = await registry._scan_evermemos()

            assert result is False
            assert registry.evermemos.available is False

    @pytest.mark.asyncio
    async def test_evermemos_unhealthy(self):
        """Should mark unavailable when health check returns non-healthy."""
        registry = LocalRegistry(evermemos_url="http://localhost:1995")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"status": "degraded"}

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.get.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result = await registry._scan_evermemos()

            assert result is False
            assert registry.evermemos.available is False

    @pytest.mark.asyncio
    async def test_full_scan_includes_evermemos(self):
        """Full scan should probe EverMemOS alongside Ollama and LM Studio."""
        import httpx
        registry = LocalRegistry(evermemos_url="http://localhost:1995")

        evermemos_resp = MagicMock()
        evermemos_resp.status_code = 200
        evermemos_resp.json.return_value = {"status": "healthy", "version": "0.2.0"}

        with patch("pentos_bridge.local.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()

            async def mock_get(url):
                if "1995" in url:
                    return evermemos_resp
                raise httpx.ConnectError("refused")

            mock_instance.get = mock_get
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            await registry.scan()

            assert registry.evermemos.available is True
            assert registry.models == []  # No Ollama/LM Studio


class TestMemoryRouting:
    """Test memory routing — local EverMemOS first, cloud fallback."""

    @pytest.mark.asyncio
    async def test_store_routes_local(self, config, registry_with_evermemos):
        """Should route to local EverMemOS when available."""
        router = SmartRouter(config, registry_with_evermemos)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"memory_id": "mem_001", "stored": True}
        mock_response.raise_for_status = MagicMock()

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.request.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result, source = await router.memory_store("User prefers Python")

            assert source == "local"
            assert result["stored"] is True

    @pytest.mark.asyncio
    async def test_store_falls_back_to_cloud(self, config, registry_no_evermemos):
        """Should fall back to cloud when local is unavailable."""
        router = SmartRouter(config, registry_no_evermemos)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"memory_id": "mem_cloud_001", "stored": True, "backend": "cloud"}
        mock_response.raise_for_status = MagicMock()

        with patch("pentos_bridge.cloud.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.request.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result, source = await router.memory_store("User prefers Python")

            assert source == "cloud"

    @pytest.mark.asyncio
    async def test_recall_routes_local(self, config, registry_with_evermemos):
        """Should recall from local EverMemOS."""
        router = SmartRouter(config, registry_with_evermemos)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "results": [
                {"memory_id": "mem_001", "content": "User prefers Python", "relevance": 0.94}
            ]
        }
        mock_response.raise_for_status = MagicMock()

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.request.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result, source = await router.memory_recall("What language does user prefer?")

            assert source == "local"
            assert len(result["memories"]) == 1
            assert result["memories"][0]["content"] == "User prefers Python"

    @pytest.mark.asyncio
    async def test_forget_routes_local(self, config, registry_with_evermemos):
        """Should delete from local EverMemOS."""
        router = SmartRouter(config, registry_with_evermemos)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"deleted": True}
        mock_response.raise_for_status = MagicMock()

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.request.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result, source = await router.memory_forget("mem_001")

            assert source == "local"

    @pytest.mark.asyncio
    async def test_stats_routes_local(self, config, registry_with_evermemos):
        """Should get stats from local EverMemOS."""
        router = SmartRouter(config, registry_with_evermemos)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "total_memories": 42,
            "storage_bytes": 1024000,
            "top_tags": ["preference", "development"],
        }
        mock_response.raise_for_status = MagicMock()

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.request.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            result, source = await router.memory_stats()

            assert source == "local"
            assert result["total_memories"] == 42

    @pytest.mark.asyncio
    async def test_local_failure_falls_back_to_cloud(self, config, registry_with_evermemos):
        """If local EverMemOS errors, should fall back to cloud."""
        router = SmartRouter(config, registry_with_evermemos)

        cloud_response = MagicMock()
        cloud_response.status_code = 200
        cloud_response.json.return_value = {"memories": [], "source": "cloud"}
        cloud_response.raise_for_status = MagicMock()

        call_count = 0

        # Both _call_local_evermemos and cloud._request use httpx.AsyncClient.
        # We need local to fail (first call) and cloud to succeed (second call).
        # Patch the router's local method directly to raise, then let cloud work.
        with patch.object(router, "_call_local_evermemos", side_effect=Exception("connection refused")):
            with patch("pentos_bridge.cloud.httpx.AsyncClient") as mock_cloud:
                mock_cloud_instance = AsyncMock()
                mock_cloud_instance.request.return_value = cloud_response
                mock_cloud_instance.__aenter__ = AsyncMock(return_value=mock_cloud_instance)
                mock_cloud_instance.__aexit__ = AsyncMock(return_value=False)
                mock_cloud.return_value = mock_cloud_instance

                result, source = await router.memory_recall("test query")

                assert source == "cloud"


class TestMemoryMCPTools:
    """Test memory MCP tool definitions and calls."""

    def test_memory_tools_defined(self):
        names = {t["name"] for t in TOOL_DEFINITIONS}
        assert "memory_store" in names
        assert "memory_recall" in names
        assert "memory_search" in names
        assert "memory_forget" in names

    def test_memory_store_schema(self):
        tool = next(t for t in TOOL_DEFINITIONS if t["name"] == "memory_store")
        props = tool["inputSchema"]["properties"]
        assert "content" in props
        assert "tags" in props
        assert tool["inputSchema"]["required"] == ["content"]

    def test_memory_recall_schema(self):
        tool = next(t for t in TOOL_DEFINITIONS if t["name"] == "memory_recall")
        props = tool["inputSchema"]["properties"]
        assert "query" in props
        assert "limit" in props
        assert tool["inputSchema"]["required"] == ["query"]

    def test_memory_forget_schema(self):
        tool = next(t for t in TOOL_DEFINITIONS if t["name"] == "memory_forget")
        assert tool["inputSchema"]["required"] == ["memory_id"]

    @pytest.mark.asyncio
    async def test_mcp_memory_store_call(self, config, registry_with_evermemos):
        """Test calling memory_store via MCP protocol."""
        router = SmartRouter(config, registry_with_evermemos)
        server = MCPStdioServer(config, registry_with_evermemos, router)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"memory_id": "mem_001", "stored": True}
        mock_response.raise_for_status = MagicMock()

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.request.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            request = {
                "jsonrpc": "2.0",
                "id": 10,
                "method": "tools/call",
                "params": {
                    "name": "memory_store",
                    "arguments": {"content": "User prefers dark mode", "tags": ["preference"]},
                },
            }
            response = await server._handle_request(request)

            assert response["id"] == 10
            result_data = json.loads(response["result"]["content"][0]["text"])
            assert result_data["source"] == "local"

    @pytest.mark.asyncio
    async def test_mcp_memory_recall_call(self, config, registry_with_evermemos):
        """Test calling memory_recall via MCP protocol."""
        router = SmartRouter(config, registry_with_evermemos)
        server = MCPStdioServer(config, registry_with_evermemos, router)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "results": [{"memory_id": "mem_001", "content": "User prefers dark mode"}]
        }
        mock_response.raise_for_status = MagicMock()

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_instance = AsyncMock()
            mock_instance.request.return_value = mock_response
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            request = {
                "jsonrpc": "2.0",
                "id": 11,
                "method": "tools/call",
                "params": {
                    "name": "memory_recall",
                    "arguments": {"query": "What does the user prefer?"},
                },
            }
            response = await server._handle_request(request)

            assert response["id"] == 11
            result_data = json.loads(response["result"]["content"][0]["text"])
            assert result_data["source"] == "local"


class TestEverMemOSInfo:
    """Test EverMemOSInfo dataclass."""

    def test_default_unavailable(self):
        info = EverMemOSInfo()
        assert info.available is False
        assert info.url == "http://localhost:1995"
        assert info.version == ""
        assert info.memory_count == 0

    def test_with_values(self):
        info = EverMemOSInfo(
            available=True,
            url="http://localhost:1995",
            version="0.2.0",
            memory_count=1247,
        )
        assert info.available is True
        assert info.memory_count == 1247
