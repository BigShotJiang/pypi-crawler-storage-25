"""Tests for the FastAPI server — OpenAI-compatible endpoint."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from fastapi.testclient import TestClient

from pentos_bridge.config import BridgeConfig
from pentos_bridge.local import LocalRegistry, LocalModel
from pentos_bridge.router import SmartRouter
from pentos_bridge.server import create_app


@pytest.fixture
def config():
    return BridgeConfig(strue_api_key="sk_test")


@pytest.fixture
def registry():
    reg = LocalRegistry()
    reg.models = [
        LocalModel(name="llama3.2:1b", provider="ollama", base_url="http://localhost:11434"),
    ]
    return reg


@pytest.fixture
def router(config, registry):
    return SmartRouter(config, registry)


@pytest.fixture
def client(config, registry, router):
    app = create_app(config, registry, router)
    return TestClient(app)


class TestRootAndHealth:

    def test_root(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "pentos-bridge"
        assert data["status"] == "running"

    def test_health(self, client):
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert len(data["local_models"]) == 1
        assert data["local_models"][0]["name"] == "llama3.2:1b"

    def test_list_models(self, client):
        resp = client.get("/v1/models")
        assert resp.status_code == 200
        data = resp.json()
        assert data["object"] == "list"
        model_ids = [m["id"] for m in data["data"]]
        assert "llama3.2:1b" in model_ids


class TestChatCompletions:

    def test_chat_completions_routes_local(self, client):
        """POST /v1/chat/completions with local model."""
        mock_response = {
            "id": "chatcmpl-test",
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": "Hi!"},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 3, "completion_tokens": 1, "total_tokens": 4},
        }

        with patch("pentos_bridge.router.httpx.AsyncClient") as mock_client:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = mock_response
            mock_resp.raise_for_status = MagicMock()

            mock_instance = AsyncMock()
            mock_instance.post.return_value = mock_resp
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            resp = client.post("/v1/chat/completions", json={
                "model": "llama3.2:1b",
                "messages": [{"role": "user", "content": "Hello"}],
            })

            assert resp.status_code == 200
            assert resp.headers.get("X-Routed-Via") == "local"
            data = resp.json()
            assert data["choices"][0]["message"]["content"] == "Hi!"
            assert data["x_routed_via"] == "local"

    def test_chat_completions_cloud_model(self, client):
        """POST /v1/chat/completions with cloud-only model."""
        mock_response = {
            "id": "chatcmpl-cloud",
            "choices": [{
                "index": 0,
                "message": {"role": "assistant", "content": "Cloud response"},
                "finish_reason": "stop",
            }],
            "usage": {"prompt_tokens": 5, "completion_tokens": 2, "total_tokens": 7},
        }

        with patch("pentos_bridge.cloud.httpx.AsyncClient") as mock_client:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = mock_response
            mock_resp.raise_for_status = MagicMock()

            mock_instance = AsyncMock()
            mock_instance.request.return_value = mock_resp
            mock_instance.__aenter__ = AsyncMock(return_value=mock_instance)
            mock_instance.__aexit__ = AsyncMock(return_value=False)
            mock_client.return_value = mock_instance

            resp = client.post("/v1/chat/completions", json={
                "model": "deepseek-ai/DeepSeek-V3",
                "messages": [{"role": "user", "content": "Hi"}],
            })

            assert resp.status_code == 200
            assert resp.headers.get("X-Routed-Via") == "strue-cloud"

    def test_chat_completions_missing_messages(self, client):
        """Should return 422 for missing required field."""
        resp = client.post("/v1/chat/completions", json={
            "model": "test",
        })
        assert resp.status_code == 422
