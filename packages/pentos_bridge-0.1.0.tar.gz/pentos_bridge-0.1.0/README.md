# Pentos Bridge

Local-first AI agent bridge with decentralized cloud fallback.

Pentos Bridge detects local AI models (Ollama, llama.cpp, vLLM) and routes inference requests locally when possible, falling back to Strue's decentralized cloud when needed.

## Install

```bash
pip install pentos-bridge
```

## Quick Start

```bash
# Check what's available locally
pentos-bridge status

# Start the bridge (OpenAI-compatible API on localhost:8787)
pentos-bridge start --key "your-strue-api-key"
```

## Features

- **Local-first routing** — automatically detects Ollama and routes requests to local models
- **Cloud fallback** — requests for unavailable models route through Strue's decentralized inference network
- **OpenAI-compatible API** — drop-in replacement at `http://localhost:8787/v1`
- **MCP server** — works with Claude Desktop and other MCP clients
- **Memory integration** — optional EverMemOS support for persistent agent memory

## Usage

### As an OpenAI-compatible API

```bash
pentos-bridge start --key "sk_..."

curl http://localhost:8787/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gemma3:4b",
    "messages": [{"role": "user", "content": "Hello!"}]
  }'
```

### As an MCP server (Claude Desktop)

```bash
pentos-bridge mcp
```

## Requirements

- Python 3.10+
- [Ollama](https://ollama.ai) (optional, for local inference)

## Links

- [Strue](https://strue.com) — Decentralized agent infrastructure
- [Arloop](https://arloop.org) — The autoresearch library
