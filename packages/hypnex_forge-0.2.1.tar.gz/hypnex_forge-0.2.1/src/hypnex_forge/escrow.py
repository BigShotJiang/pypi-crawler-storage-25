"""Escrow — high-level interface to the ForgeEscrow contract (Phase 3).

ForgeEscrow turns Forge into a recurring-revenue rail: agents pre-fund
per-tool escrow balances, the Hypnex relayer batches signed call
receipts, and on-chain `settle()` calls debit the agent's balance and
route 90% to the tool owner / 10% to Hypnex treasury.

Read methods (no signer):
    balance, tool_revenue, treasury_revenue, signer_of, last_period_id,
    withdraw_unlock_at, protocol_fee_bps, relayer_address, claim_admin,
    quote_settle.

Write methods — agent side (require account):
    deposit, agent_request_withdraw, agent_execute_withdraw.

Write methods — tool-owner side (require account):
    set_signer, withdraw_tool, sign_receipt, post_receipt, call_with_receipt.

Write methods — admin/relayer (require account):
    settle, withdraw_treasury, set_relayer, set_protocol_fee_bps.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Any, Optional

from eth_account import Account
from eth_account.messages import encode_defunct
from eth_account.signers.local import LocalAccount
from web3 import Web3
from web3.contract import Contract

from ._abi import ERC20_ABI, ESCROW_ABI
from ._constants import (
    CHAIN_IDS,
    DEFAULT_CHAIN,
    DEFAULT_RELAYER_URL,
    ENV_ESCROW_ADDRESS,
    ENV_FORGE_CHAIN,
    ENV_PRIVATE_KEY,
    ENV_RELAYER_URL,
    ENV_RPC,
    ESCROW_ADDRESSES,
    MOR_ADDRESSES,
    PROBE_ADDRESS_BY_CHAIN,
    PROBE_CALLDATA,
    PUBLIC_RPCS,
)


def _connect_with_fallback(chain: str, timeout: int = 20) -> Web3:
    candidates = PUBLIC_RPCS.get(chain, ())
    if not candidates:
        raise ValueError(f"Unknown chain {chain!r}")
    probe_to = Web3.to_checksum_address(PROBE_ADDRESS_BY_CHAIN[chain])
    expected_chain_id = CHAIN_IDS[chain]
    last: Optional[Exception] = None
    for url in candidates:
        try:
            w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": timeout}))
            if not w3.is_connected() or w3.eth.chain_id != expected_chain_id:
                continue
            w3.eth.call({"to": probe_to, "data": PROBE_CALLDATA})
            return w3
        except Exception as e:  # noqa: BLE001
            last = e
            continue
    raise ConnectionError(
        f"None of the public RPCs for {chain} accepted view calls. Pass rpc_url= or set "
        f"{ENV_RPC}. Last error: {last!r}"
    )


def receipt_struct_hash(
    *,
    chain_id: int,
    escrow_address: str,
    tool_id: bytes,
    agent: str,
    call_count: int,
    period_id: int,
) -> bytes:
    """keccak256(abi.encode(chainid, escrow, toolId, agent, callCount, periodId))."""
    encoded = Web3().codec.encode(
        ["uint256", "address", "bytes32", "address", "uint256", "uint256"],
        [
            int(chain_id),
            Web3.to_checksum_address(escrow_address),
            tool_id,
            Web3.to_checksum_address(agent),
            int(call_count),
            int(period_id),
        ],
    )
    return Web3.keccak(encoded)


class Escrow:
    """High-level Hypnex Forge escrow client (Phase 3)."""

    def __init__(
        self,
        address: Optional[str] = None,
        chain: Optional[str] = None,
        w3: Optional[Web3] = None,
        rpc_url: Optional[str] = None,
        account: Optional[LocalAccount] = None,
        private_key: Optional[str] = None,
        relayer_url: Optional[str] = None,
    ) -> None:
        self.chain = chain or os.environ.get(ENV_FORGE_CHAIN, DEFAULT_CHAIN)

        addr = (
            address
            or os.environ.get(ENV_ESCROW_ADDRESS)
            or ESCROW_ADDRESSES.get(self.chain)
        )
        if not addr:
            raise ValueError(
                f"Forge escrow address unknown on chain {self.chain!r}. "
                f"Pass address=... or set {ENV_ESCROW_ADDRESS}."
            )
        self.address: str = Web3.to_checksum_address(addr)

        if w3 is None:
            url = rpc_url or os.environ.get(ENV_RPC)
            if url:
                w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": 30}))
                if not w3.is_connected():
                    raise ConnectionError(f"Configured RPC {url} did not respond.")
            else:
                w3 = _connect_with_fallback(self.chain)
        self.w3 = w3

        if account is None and private_key is None:
            private_key = os.environ.get(ENV_PRIVATE_KEY)
        if account is None and private_key:
            account = Account.from_key(private_key)
        self.account: Optional[LocalAccount] = account

        self.relayer_url: str = (
            relayer_url
            or os.environ.get(ENV_RELAYER_URL)
            or DEFAULT_RELAYER_URL
        )

        self.contract: Contract = w3.eth.contract(address=self.address, abi=ESCROW_ABI)
        self._mor: Optional[Contract] = None

    # --- internals -------------------------------------------------------
    def _require_account(self) -> LocalAccount:
        if self.account is None:
            raise ValueError("This call requires a signer. Pass private_key=... or account=...")
        return self.account

    def _mor_contract(self) -> Contract:
        if self._mor is None:
            mor_addr = MOR_ADDRESSES.get(self.chain)
            if not mor_addr:
                raise ValueError(
                    f"MOR token address unknown on chain {self.chain!r}; "
                    "cannot deposit to Forge escrow."
                )
            self._mor = self.w3.eth.contract(
                address=Web3.to_checksum_address(mor_addr), abi=ERC20_ABI
            )
        return self._mor

    def _send(self, fn, value: int = 0, dry_run: bool = False) -> str:
        acct = self._require_account()
        nonce = self.w3.eth.get_transaction_count(acct.address)
        tx = fn.build_transaction({
            "from": acct.address,
            "nonce": nonce,
            "value": value,
            "chainId": self.w3.eth.chain_id,
        })
        if dry_run:
            return tx["data"]
        signed = acct.sign_transaction(tx)
        return self.w3.eth.send_raw_transaction(signed.raw_transaction).hex()

    # --- read methods ----------------------------------------------------
    def balance(self, tool_id: bytes, agent: Optional[str] = None) -> int:
        """Agent's escrowed balance available for settlement on this tool."""
        addr = agent or (self.account.address if self.account else None)
        if not addr:
            raise ValueError("No account; pass agent= or attach an account.")
        return int(self.contract.functions.balanceOf(tool_id, Web3.to_checksum_address(addr)).call())

    def tool_revenue(self, tool_id: bytes) -> int:
        """Accrued tool-side payout, withdrawable by tool owner."""
        return int(self.contract.functions.toolRevenue(tool_id).call())

    def treasury_revenue(self) -> int:
        """Accrued protocol-fee revenue, withdrawable by claim-admin."""
        return int(self.contract.functions.treasuryRevenue().call())

    def signer_of(self, tool_id: bytes) -> str:
        return self.contract.functions.signerOf(tool_id).call()

    def last_period_id(self, tool_id: bytes, agent: str) -> int:
        return int(self.contract.functions.lastPeriodId(tool_id, Web3.to_checksum_address(agent)).call())

    def withdraw_unlock_at(self, tool_id: bytes, agent: str) -> int:
        return int(self.contract.functions.withdrawUnlockAt(tool_id, Web3.to_checksum_address(agent)).call())

    def protocol_fee_bps(self) -> int:
        return int(self.contract.functions.protocolFeeBps().call())

    def relayer_address(self) -> str:
        return self.contract.functions.relayer().call()

    def claim_admin(self) -> str:
        return self.contract.functions.claimAdmin().call()

    def quote_settle(self, tool_id: bytes, call_count: int) -> tuple[int, int, int]:
        """Returns (totalCost, toolPayout, protocolFee) for `call_count` calls."""
        result = self.contract.functions.quoteSettle(tool_id, int(call_count)).call()
        return int(result[0]), int(result[1]), int(result[2])

    # --- agent-side write methods ---------------------------------------
    def deposit(
        self,
        tool_id: bytes,
        amount: int,
        *,
        auto_approve: bool = True,
        dry_run: bool = False,
    ) -> str:
        """Pre-fund per-tool escrow. Auto-approves MOR allowance if needed."""
        if amount <= 0:
            raise ValueError("amount must be > 0")
        if auto_approve and not dry_run:
            acct = self._require_account()
            mor = self._mor_contract()
            allowance = int(mor.functions.allowance(acct.address, self.address).call())
            if allowance < amount:
                approve_tx = self._send(mor.functions.approve(self.address, amount))
                self.w3.eth.wait_for_transaction_receipt(approve_tx, timeout=120)
        return self._send(self.contract.functions.deposit(tool_id, int(amount)), dry_run=dry_run)

    def agent_request_withdraw(self, tool_id: bytes, *, dry_run: bool = False) -> str:
        return self._send(self.contract.functions.agentRequestWithdraw(tool_id), dry_run=dry_run)

    def agent_execute_withdraw(
        self,
        tool_id: bytes,
        to: Optional[str] = None,
        *,
        dry_run: bool = False,
    ) -> str:
        acct = self._require_account()
        recipient = Web3.to_checksum_address(to or acct.address)
        return self._send(
            self.contract.functions.agentExecuteWithdraw(tool_id, recipient),
            dry_run=dry_run,
        )

    # --- tool-owner write methods ---------------------------------------
    def set_signer(self, tool_id: bytes, new_signer: str, *, dry_run: bool = False) -> str:
        fn = self.contract.functions.setSigner(tool_id, Web3.to_checksum_address(new_signer))
        return self._send(fn, dry_run=dry_run)

    def withdraw_tool(self, tool_id: bytes, to: str, *, dry_run: bool = False) -> str:
        fn = self.contract.functions.withdrawTool(tool_id, Web3.to_checksum_address(to))
        return self._send(fn, dry_run=dry_run)

    def sign_receipt(
        self,
        tool_id: bytes,
        agent: str,
        call_count: int,
        period_id: int,
    ) -> bytes:
        """Sign a receipt with the connected account.

        The connected account MUST be the tool's registered signer
        (see `signer_of(tool_id)`). Returns the 65-byte ECDSA signature
        suitable for `settle()` or for posting to the relayer.
        """
        acct = self._require_account()
        struct_hash = receipt_struct_hash(
            chain_id=self.w3.eth.chain_id,
            escrow_address=self.address,
            tool_id=tool_id,
            agent=agent,
            call_count=call_count,
            period_id=period_id,
        )
        message = encode_defunct(primitive=struct_hash)
        signed = acct.sign_message(message)
        return bytes(signed.signature)

    def post_receipt(
        self,
        tool_id: bytes,
        agent: str,
        call_count: int,
        period_id: int,
        signature: bytes,
        *,
        relayer_url: Optional[str] = None,
        timeout: int = 15,
    ) -> dict[str, Any]:
        """POST a signed receipt to the Hypnex relayer for batching."""
        url = (relayer_url or self.relayer_url).rstrip("/") + "/receipt"
        payload = {
            "chain": self.chain,
            "escrow": self.address,
            "toolId": "0x" + tool_id.hex() if isinstance(tool_id, (bytes, bytearray)) else tool_id,
            "agent": Web3.to_checksum_address(agent),
            "callCount": int(call_count),
            "periodId": int(period_id),
            "signature": "0x" + signature.hex() if isinstance(signature, (bytes, bytearray)) else signature,
        }
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8") or "{}")
        except urllib.error.HTTPError as e:
            raise RuntimeError(f"Relayer rejected receipt ({e.code}): {e.read().decode('utf-8', 'ignore')}")

    def call_with_receipt(
        self,
        tool_id: bytes,
        agent: str,
        call_count: int,
        period_id: int,
        *,
        relayer_url: Optional[str] = None,
    ) -> dict[str, Any]:
        """Tool-owner-side helper: sign a receipt with the connected
        signer key and POST it to the Hypnex relayer.

        This is the fast-path for tool servers — call once per
        billing period (e.g. once per N calls) instead of per call.
        """
        signature = self.sign_receipt(tool_id, agent, call_count, period_id)
        return self.post_receipt(
            tool_id, agent, call_count, period_id, signature, relayer_url=relayer_url
        )

    # --- relayer / admin write methods ----------------------------------
    def settle(
        self,
        tool_id: bytes,
        agent: str,
        call_count: int,
        period_id: int,
        signature: bytes,
        *,
        dry_run: bool = False,
    ) -> str:
        """Submit a signed receipt on-chain. Caller must be the active relayer."""
        fn = self.contract.functions.settle(
            tool_id,
            Web3.to_checksum_address(agent),
            int(call_count),
            int(period_id),
            signature,
        )
        return self._send(fn, dry_run=dry_run)

    def withdraw_treasury(self, to: str, *, dry_run: bool = False) -> str:
        fn = self.contract.functions.withdrawTreasury(Web3.to_checksum_address(to))
        return self._send(fn, dry_run=dry_run)

    def set_relayer(self, new_relayer: str, *, dry_run: bool = False) -> str:
        fn = self.contract.functions.setRelayer(Web3.to_checksum_address(new_relayer))
        return self._send(fn, dry_run=dry_run)

    def set_protocol_fee_bps(self, new_bps: int, *, dry_run: bool = False) -> str:
        fn = self.contract.functions.setProtocolFeeBps(int(new_bps))
        return self._send(fn, dry_run=dry_run)
