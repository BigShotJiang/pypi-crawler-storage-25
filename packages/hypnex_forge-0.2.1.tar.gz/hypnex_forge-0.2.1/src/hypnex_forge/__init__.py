"""hypnex-forge — Python SDK for the Forge tool registry on Morpheus AI.

Forge is the Hypnex Labs tools marketplace for the Morpheus AI ecosystem
and the broader MCP (Model-Context-Protocol) world. Each tool listing on
the on-chain registry pays a one-time fee in MOR to Hypnex Labs.

Monetization notice:
    This SDK routes all listing fees from `register()` calls to the Hypnex
    Labs treasury (0x22B5C0075372E743042b2d62b3D254425Eb957D8). The
    listing fee is configurable on-chain by the claim-admin (default 1
    MOR per listing). The on-chain `pricePerCallWei` you set on a tool
    is what END USERS pay you for calls; that revenue stays with the
    tool owner (Phase 1 — Phase 3 will add on-chain per-call settlement
    with a Hypnex protocol fee).

Quickstart (read-only):

    from hypnex_forge import Forge

    f = Forge(chain="arbitrum")
    print(f.total_tools())
    print(f.list_tools(0, 100))
    print(f.get_listing_fee_wei())  # 10**18 = 1 MOR

Quickstart (with signer):

    import os
    from hypnex_forge import Forge

    f = Forge(
        chain="arbitrum",
        rpc_url=os.environ["ETH_RPC_URL"],
        private_key=os.environ["PRIVATE_KEY"],
    )
    tx = f.register(
        namespace="myorg",
        name="websearch",
        mcp_uri="https://mcp.example.com/v1",
        categories=["search", "data"],
        price_per_call_wei=int(0.001 * 10**18),  # users pay 0.001 MOR per call
    )
    # SDK auto-approves the listing fee, then submits register().
"""

from ._constants import (
    CHAIN_IDS,
    DEFAULT_CHAIN,
    DEFAULT_RELAYER_URL,
    ESCROW_ADDRESSES,
    FORGE_ADDRESSES,
    MOR_ADDRESSES,
    PUBLIC_RPCS,
)
from .escrow import Escrow, receipt_struct_hash
from .forge import Forge, Tool, category_tag, tool_id

__version__ = "0.2.1"

__all__ = [
    "Forge",
    "Escrow",
    "Tool",
    "category_tag",
    "tool_id",
    "receipt_struct_hash",
    "CHAIN_IDS",
    "DEFAULT_CHAIN",
    "DEFAULT_RELAYER_URL",
    "FORGE_ADDRESSES",
    "ESCROW_ADDRESSES",
    "MOR_ADDRESSES",
    "PUBLIC_RPCS",
    "__version__",
]
