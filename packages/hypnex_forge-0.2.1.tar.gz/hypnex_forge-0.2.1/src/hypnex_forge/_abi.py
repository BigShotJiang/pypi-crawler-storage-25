"""ABI for the ForgeToolRegistry contract."""

from __future__ import annotations

FORGE_ABI = [
    {
        "type": "function",
        "name": "toolIdOf",
        "stateMutability": "pure",
        "inputs": [
            {"name": "namespace", "type": "string"},
            {"name": "name", "type": "string"},
        ],
        "outputs": [{"name": "", "type": "bytes32"}],
    },
    {
        "type": "function",
        "name": "register",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "namespace", "type": "string"},
            {"name": "name", "type": "string"},
            {"name": "mcpURI", "type": "string"},
            {"name": "categories", "type": "bytes32[]"},
            {"name": "pricePerCallWei", "type": "uint256"},
        ],
        "outputs": [{"name": "toolId", "type": "bytes32"}],
    },
    {
        "type": "function",
        "name": "updateTool",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "mcpURI", "type": "string"},
            {"name": "pricePerCallWei", "type": "uint256"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "setCategories",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "categories", "type": "bytes32[]"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "deactivate",
        "stateMutability": "nonpayable",
        "inputs": [{"name": "toolId", "type": "bytes32"}],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "reactivate",
        "stateMutability": "nonpayable",
        "inputs": [{"name": "toolId", "type": "bytes32"}],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "transferOwnership",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "newOwner", "type": "address"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "getTool",
        "stateMutability": "view",
        "inputs": [{"name": "toolId", "type": "bytes32"}],
        "outputs": [
            {
                "name": "",
                "type": "tuple",
                "components": [
                    {"name": "owner", "type": "address"},
                    {"name": "name", "type": "string"},
                    {"name": "namespace", "type": "string"},
                    {"name": "mcpURI", "type": "string"},
                    {"name": "categories", "type": "bytes32[]"},
                    {"name": "pricePerCallWei", "type": "uint256"},
                    {"name": "isActive", "type": "bool"},
                    {"name": "createdAt", "type": "uint64"},
                    {"name": "updatedAt", "type": "uint64"},
                ],
            }
        ],
    },
    {
        "type": "function",
        "name": "isRegistered",
        "stateMutability": "view",
        "inputs": [{"name": "toolId", "type": "bytes32"}],
        "outputs": [{"name": "", "type": "bool"}],
    },
    {
        "type": "function",
        "name": "totalTools",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "listTools",
        "stateMutability": "view",
        "inputs": [
            {"name": "offset", "type": "uint256"},
            {"name": "limit", "type": "uint256"},
        ],
        "outputs": [{"name": "page", "type": "bytes32[]"}],
    },
    {
        "type": "function",
        "name": "toolsOf",
        "stateMutability": "view",
        "inputs": [{"name": "owner", "type": "address"}],
        "outputs": [{"name": "", "type": "bytes32[]"}],
    },
    {
        "type": "function",
        "name": "toolsInCategory",
        "stateMutability": "view",
        "inputs": [{"name": "category", "type": "bytes32"}],
        "outputs": [{"name": "", "type": "bytes32[]"}],
    },
    {
        "type": "function",
        "name": "listingFee",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "feeToken",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "address"}],
    },
    {
        "type": "function",
        "name": "claimAdmin",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "address"}],
    },
    {
        "type": "function",
        "name": "setListingFee",
        "stateMutability": "nonpayable",
        "inputs": [{"name": "newFee", "type": "uint256"}],
        "outputs": [],
    },
]


# --- Escrow ABI (Phase 3 — per-call settlement) ---
ESCROW_ABI = [
    {
        "type": "function",
        "name": "deposit",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "amount", "type": "uint256"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "balanceOf",
        "stateMutability": "view",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "agent", "type": "address"},
        ],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "toolRevenue",
        "stateMutability": "view",
        "inputs": [{"name": "toolId", "type": "bytes32"}],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "treasuryRevenue",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "withdrawTool",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "to", "type": "address"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "withdrawTreasury",
        "stateMutability": "nonpayable",
        "inputs": [{"name": "to", "type": "address"}],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "agentRequestWithdraw",
        "stateMutability": "nonpayable",
        "inputs": [{"name": "toolId", "type": "bytes32"}],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "agentExecuteWithdraw",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "to", "type": "address"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "setSigner",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "newSigner", "type": "address"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "signerOf",
        "stateMutability": "view",
        "inputs": [{"name": "toolId", "type": "bytes32"}],
        "outputs": [{"name": "", "type": "address"}],
    },
    {
        "type": "function",
        "name": "lastPeriodId",
        "stateMutability": "view",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "agent", "type": "address"},
        ],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "withdrawUnlockAt",
        "stateMutability": "view",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "agent", "type": "address"},
        ],
        "outputs": [{"name": "", "type": "uint64"}],
    },
    {
        "type": "function",
        "name": "protocolFeeBps",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "relayer",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "address"}],
    },
    {
        "type": "function",
        "name": "claimAdmin",
        "stateMutability": "view",
        "inputs": [],
        "outputs": [{"name": "", "type": "address"}],
    },
    {
        "type": "function",
        "name": "settle",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "agent", "type": "address"},
            {"name": "callCount", "type": "uint256"},
            {"name": "periodId", "type": "uint256"},
            {"name": "receiptSignature", "type": "bytes"},
        ],
        "outputs": [],
    },
    {
        "type": "function",
        "name": "quoteSettle",
        "stateMutability": "view",
        "inputs": [
            {"name": "toolId", "type": "bytes32"},
            {"name": "callCount", "type": "uint256"},
        ],
        "outputs": [
            {"name": "totalCost", "type": "uint256"},
            {"name": "toolPayout", "type": "uint256"},
            {"name": "protocolFee", "type": "uint256"},
        ],
    },
]


# --- minimal ERC-20 ABI for the MOR fee token. ---
ERC20_ABI = [
    {
        "type": "function",
        "name": "approve",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "spender", "type": "address"},
            {"name": "amount", "type": "uint256"},
        ],
        "outputs": [{"name": "", "type": "bool"}],
    },
    {
        "type": "function",
        "name": "allowance",
        "stateMutability": "view",
        "inputs": [
            {"name": "owner", "type": "address"},
            {"name": "spender", "type": "address"},
        ],
        "outputs": [{"name": "", "type": "uint256"}],
    },
    {
        "type": "function",
        "name": "balanceOf",
        "stateMutability": "view",
        "inputs": [{"name": "account", "type": "address"}],
        "outputs": [{"name": "", "type": "uint256"}],
    },
]
