"""Forge — high-level interface to the ForgeToolRegistry contract.

Read methods (no signer): get_tool, list_tools, tools_of, tools_in_category,
total_tools, is_registered, tool_id_of.

Write methods (require account): register, update_tool, set_categories,
deactivate, reactivate, transfer_ownership.

`register()` auto-approves the listing fee MOR allowance for the caller on
first use, then submits the registration tx. The fee is forwarded directly
to claim-admin (Hypnex Labs) inside the registration tx.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

from eth_account import Account
from eth_account.signers.local import LocalAccount
from web3 import Web3
from web3.contract import Contract

from ._abi import ERC20_ABI, FORGE_ABI
from ._constants import (
    CHAIN_IDS,
    DEFAULT_CHAIN,
    ENV_FORGE_ADDRESS,
    ENV_FORGE_CHAIN,
    ENV_PRIVATE_KEY,
    ENV_RPC,
    FORGE_ADDRESSES,
    MOR_ADDRESSES,
    PROBE_ADDRESS_BY_CHAIN,
    PROBE_CALLDATA,
    PUBLIC_RPCS,
)


# --- domain ----------------------------------------------------------------
@dataclass
class Tool:
    owner: str
    name: str
    namespace: str
    mcp_uri: str
    categories: tuple[bytes, ...]
    price_per_call_wei: int
    is_active: bool
    created_at: int
    updated_at: int

    @property
    def id(self) -> bytes:
        return Web3.keccak(text=f"{self.namespace}/{self.name}")

    @property
    def price_per_call_mor(self) -> float:
        return self.price_per_call_wei / 1e18


def category_tag(label: str) -> bytes:
    """Convert a human-readable category string to its bytes32 tag (keccak256)."""
    return Web3.keccak(text=label)


def tool_id(namespace: str, name: str) -> bytes:
    """Compute the canonical toolId (keccak256(namespace + '/' + name))."""
    return Web3.keccak(text=f"{namespace}/{name}")


# --- helpers ---------------------------------------------------------------
def _connect_with_fallback(chain: str, timeout: int = 20) -> Web3:
    candidates = PUBLIC_RPCS.get(chain, ())
    if not candidates:
        raise ValueError(f"Unknown chain {chain!r}")
    probe_to = Web3.to_checksum_address(PROBE_ADDRESS_BY_CHAIN[chain])
    expected_chain_id = CHAIN_IDS[chain]
    last: Optional[Exception] = None
    for url in candidates:
        try:
            w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": timeout}))
            if not w3.is_connected() or w3.eth.chain_id != expected_chain_id:
                continue
            w3.eth.call({"to": probe_to, "data": PROBE_CALLDATA})
            return w3
        except Exception as e:  # noqa: BLE001
            last = e
            continue
    raise ConnectionError(
        f"None of the public RPCs for {chain} accepted view calls. Pass rpc_url= or set "
        f"{ENV_RPC}. Last error: {last!r}"
    )


# --- main class ------------------------------------------------------------
class Forge:
    """High-level Hypnex Forge tool-registry client."""

    def __init__(
        self,
        address: Optional[str] = None,
        chain: Optional[str] = None,
        w3: Optional[Web3] = None,
        rpc_url: Optional[str] = None,
        account: Optional[LocalAccount] = None,
        private_key: Optional[str] = None,
    ) -> None:
        self.chain = chain or os.environ.get(ENV_FORGE_CHAIN, DEFAULT_CHAIN)

        addr = (
            address
            or os.environ.get(ENV_FORGE_ADDRESS)
            or FORGE_ADDRESSES.get(self.chain)
        )
        if not addr:
            raise ValueError(
                f"Forge address unknown on chain {self.chain!r}. "
                f"Pass address=... or set {ENV_FORGE_ADDRESS}. "
                "(Forge is currently deployed on Arbitrum + Base.)"
            )
        self.address: str = Web3.to_checksum_address(addr)

        if w3 is None:
            url = rpc_url or os.environ.get(ENV_RPC)
            if url:
                w3 = Web3(Web3.HTTPProvider(url, request_kwargs={"timeout": 30}))
                if not w3.is_connected():
                    raise ConnectionError(f"Configured RPC {url} did not respond.")
            else:
                w3 = _connect_with_fallback(self.chain)
        self.w3 = w3

        if account is None and private_key is None:
            private_key = os.environ.get(ENV_PRIVATE_KEY)
        if account is None and private_key:
            account = Account.from_key(private_key)
        self.account: Optional[LocalAccount] = account

        self.contract: Contract = w3.eth.contract(address=self.address, abi=FORGE_ABI)
        self._mor: Optional[Contract] = None

    def _require_account(self) -> LocalAccount:
        if self.account is None:
            raise ValueError("This call requires a signer. Pass private_key=... or account=...")
        return self.account

    def _mor_contract(self) -> Contract:
        if self._mor is None:
            mor_addr = MOR_ADDRESSES.get(self.chain)
            if not mor_addr:
                raise ValueError(
                    f"MOR token address unknown on chain {self.chain!r}; "
                    "cannot pay Forge listing fee."
                )
            self._mor = self.w3.eth.contract(
                address=Web3.to_checksum_address(mor_addr), abi=ERC20_ABI
            )
        return self._mor

    # --- view helpers ----------------------------------------------------
    def get_listing_fee_wei(self) -> int:
        """Live listing fee."""
        return int(self.contract.functions.listingFee().call())

    def get_claim_admin(self) -> str:
        return self.contract.functions.claimAdmin().call()

    def get_mor_balance(self, address: Optional[str] = None) -> int:
        addr = address or (self.account.address if self.account else None)
        if not addr:
            raise ValueError("No account; pass address= or attach an account.")
        return int(self._mor_contract().functions.balanceOf(Web3.to_checksum_address(addr)).call())

    def get_mor_allowance(self, owner: Optional[str] = None) -> int:
        addr = owner or (self.account.address if self.account else None)
        if not addr:
            raise ValueError("No account; pass owner= or attach an account.")
        return int(
            self._mor_contract()
            .functions.allowance(Web3.to_checksum_address(addr), self.address)
            .call()
        )

    # --- read methods ----------------------------------------------------
    def tool_id_of(self, namespace: str, name: str) -> bytes:
        return self.contract.functions.toolIdOf(namespace, name).call()

    def is_registered(self, tool_id_: bytes) -> bool:
        return bool(self.contract.functions.isRegistered(tool_id_).call())

    def total_tools(self) -> int:
        return int(self.contract.functions.totalTools().call())

    def list_tools(self, offset: int = 0, limit: int = 100) -> list[bytes]:
        return list(self.contract.functions.listTools(int(offset), int(limit)).call())

    def tools_of(self, owner: str) -> list[bytes]:
        return list(self.contract.functions.toolsOf(Web3.to_checksum_address(owner)).call())

    def tools_in_category(self, category: str | bytes) -> list[bytes]:
        tag = category_tag(category) if isinstance(category, str) else category
        return list(self.contract.functions.toolsInCategory(tag).call())

    def get_tool(self, tool_id_: bytes) -> Tool:
        result = self.contract.functions.getTool(tool_id_).call()
        return Tool(
            owner=result[0],
            name=result[1],
            namespace=result[2],
            mcp_uri=result[3],
            categories=tuple(result[4]),
            price_per_call_wei=int(result[5]),
            is_active=bool(result[6]),
            created_at=int(result[7]),
            updated_at=int(result[8]),
        )

    # --- write methods ---------------------------------------------------
    def _send(self, fn, value: int = 0, dry_run: bool = False) -> str:
        acct = self._require_account()
        nonce = self.w3.eth.get_transaction_count(acct.address)
        tx = fn.build_transaction({
            "from": acct.address,
            "nonce": nonce,
            "value": value,
            "chainId": self.w3.eth.chain_id,
        })
        if dry_run:
            return tx["data"]
        signed = acct.sign_transaction(tx)
        return self.w3.eth.send_raw_transaction(signed.raw_transaction).hex()

    def register(
        self,
        namespace: str,
        name: str,
        mcp_uri: str,
        categories: list[str | bytes],
        price_per_call_wei: int = 0,
        *,
        auto_approve: bool = True,
        dry_run: bool = False,
    ) -> str:
        """Register a tool. Auto-approves the MOR listing fee on first use.

        Args:
            namespace: e.g. "myorg" or "anonymous"
            name: tool name (max 64 chars, must be unique within namespace)
            mcp_uri: Anthropic MCP server endpoint (or other RPC URI)
            categories: list of category labels (e.g. ["search", "data"])
            price_per_call_wei: end-user price in MOR wei
                (this is what users pay you to call the tool;
                Phase 1 is off-chain settlement so this is informational)
        """
        tags = [category_tag(c) if isinstance(c, str) else c for c in categories]

        if auto_approve and not dry_run:
            acct = self._require_account()
            fee = self.get_listing_fee_wei()
            if fee > 0:
                allowance = self.get_mor_allowance(acct.address)
                if allowance < fee:
                    mor = self._mor_contract()
                    approve_fn = mor.functions.approve(self.address, fee)
                    approve_tx = self._send(approve_fn)
                    self.w3.eth.wait_for_transaction_receipt(approve_tx, timeout=120)

        fn = self.contract.functions.register(namespace, name, mcp_uri, tags, int(price_per_call_wei))
        return self._send(fn, dry_run=dry_run)

    def update_tool(
        self,
        tool_id_: bytes,
        mcp_uri: str,
        price_per_call_wei: int,
        *,
        dry_run: bool = False,
    ) -> str:
        return self._send(
            self.contract.functions.updateTool(tool_id_, mcp_uri, int(price_per_call_wei)),
            dry_run=dry_run,
        )

    def set_categories(
        self,
        tool_id_: bytes,
        categories: list[str | bytes],
        *,
        dry_run: bool = False,
    ) -> str:
        tags = [category_tag(c) if isinstance(c, str) else c for c in categories]
        return self._send(self.contract.functions.setCategories(tool_id_, tags), dry_run=dry_run)

    def deactivate(self, tool_id_: bytes, *, dry_run: bool = False) -> str:
        return self._send(self.contract.functions.deactivate(tool_id_), dry_run=dry_run)

    def reactivate(self, tool_id_: bytes, *, dry_run: bool = False) -> str:
        return self._send(self.contract.functions.reactivate(tool_id_), dry_run=dry_run)

    def transfer_ownership(self, tool_id_: bytes, new_owner: str, *, dry_run: bool = False) -> str:
        fn = self.contract.functions.transferOwnership(tool_id_, Web3.to_checksum_address(new_owner))
        return self._send(fn, dry_run=dry_run)
