"""Hypnex Forge constants.

Forge is the paid tool registry — Phase 1 of the MRC 60 tools marketplace.
Each `register()` call costs `listingFee` MOR (default 1 MOR), forwarded
directly to the Hypnex Labs treasury inside the same tx.

Reference Solidity source:
    projects/hypnex/registry-contracts/contracts/ForgeToolRegistry.sol
"""

from __future__ import annotations

# --- Forge contract addresses per chain ---
# Filled in after deploy. None means "not yet deployed on that chain."
FORGE_ADDRESSES: dict[str, str | None] = {
    "arbitrum":      "0xa08ca3C2519DA71e923AD331AFE2989a99f013D2",  # deployed 2026-05-09
    "base":          "0x0c617b36E628b9BE689E3c55Ec901ebDBB8B45aC",  # deployed 2026-05-09
    "ethereum":      None,
    "base-sepolia":  None,
}

# --- ForgeEscrow (Phase 3) addresses per chain ---
# Filled in after deploy. None means "not yet deployed on that chain."
ESCROW_ADDRESSES: dict[str, str | None] = {
    "arbitrum":      "0x88E32F332A5140Af16c6273d8131bC84BC089Da5",  # deployed 2026-05-09
    "base":          "0xCC258a7BBF361fd824e87D4b3C0D394De6Fd454F",  # deployed 2026-05-09
    "ethereum":      None,
    "base-sepolia":  None,
}

DEFAULT_CHAIN = "arbitrum"

# MOR token (ERC-20) per chain — used as the listing-fee token.
MOR_ADDRESSES: dict[str, str | None] = {
    "arbitrum":      "0x092bAaDB7DEf4C3981454dD9c0A0D7FF07bCFc86",
    "base":          "0x7431aDa8a591C955a994a21710752EF9b882b8e3",
    "ethereum":      "0xcBB8f1BDA10b9696c57E13BC128Fe674769DCEc0",
    "base-sepolia":  None,
}

PUBLIC_RPCS: dict[str, tuple[str, ...]] = {
    "base": (
        "https://mainnet.base.org",
        "https://base-rpc.publicnode.com",
        "https://base.llamarpc.com",
    ),
    "arbitrum": (
        "https://arb1.arbitrum.io/rpc",
        "https://arbitrum-one-rpc.publicnode.com",
        "https://arbitrum.llamarpc.com",
    ),
    "ethereum": (
        "https://ethereum-rpc.publicnode.com",
        "https://eth.merkle.io",
        "https://eth.llamarpc.com",
    ),
    "base-sepolia": (
        "https://sepolia.base.org",
    ),
}

CHAIN_IDS: dict[str, int] = {
    "ethereum": 1,
    "base": 8453,
    "arbitrum": 42161,
    "base-sepolia": 84532,
}

PROBE_CALLDATA = "0x70a082310000000000000000000000000000000000000000000000000000000000000000"
PROBE_ADDRESS_BY_CHAIN: dict[str, str] = {
    "ethereum": "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
    "base":     "0x4200000000000000000000000000000000000006",
    "arbitrum": "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
    "base-sepolia": "0x4200000000000000000000000000000000000006",
}

# Environment variables
ENV_FORGE_ADDRESS = "HYPNEX_FORGE_ADDRESS"
ENV_ESCROW_ADDRESS = "HYPNEX_FORGE_ESCROW_ADDRESS"
ENV_FORGE_CHAIN = "HYPNEX_FORGE_CHAIN"
ENV_RPC = "HYPNEX_FORGE_RPC_URL"
ENV_PRIVATE_KEY = "PRIVATE_KEY"
ENV_RELAYER_URL = "HYPNEX_FORGE_RELAYER_URL"

# Default Hypnex relayer endpoint (Phase 3 batched settlement).
DEFAULT_RELAYER_URL = "https://relayer.hypnex.xyz"
