"""Unit tests for hypnex_forge.Escrow — pure mocks, no chain.

Covers the surface that the Anvil E2E test doesn't exercise: address /
chain / RPC resolution, view-method delegation, deposit auto-approve
flow, sign_receipt determinism, post_receipt payload shape, and the
combined call_with_receipt helper.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from web3 import Web3

from hypnex_forge.escrow import Escrow, receipt_struct_hash


# --- pure helper ---------------------------------------------------------


def test_receipt_struct_hash_is_deterministic():
    args = dict(
        chain_id=42161,
        escrow_address=Web3.to_checksum_address("0x" + "a" * 40),
        tool_id=bytes.fromhex("b" * 64),
        agent=Web3.to_checksum_address("0x" + "c" * 40),
        call_count=100,
        period_id=5,
    )
    a = receipt_struct_hash(**args)
    b = receipt_struct_hash(**args)
    assert a == b
    assert isinstance(a, bytes) and len(a) == 32


def test_receipt_struct_hash_changes_with_period():
    base = dict(
        chain_id=42161,
        escrow_address=Web3.to_checksum_address("0x" + "a" * 40),
        tool_id=bytes.fromhex("b" * 64),
        agent=Web3.to_checksum_address("0x" + "c" * 40),
        call_count=100,
    )
    a = receipt_struct_hash(period_id=1, **base)
    b = receipt_struct_hash(period_id=2, **base)
    assert a != b


def test_receipt_struct_hash_changes_with_chain_id():
    base = dict(
        escrow_address=Web3.to_checksum_address("0x" + "a" * 40),
        tool_id=bytes.fromhex("b" * 64),
        agent=Web3.to_checksum_address("0x" + "c" * 40),
        call_count=100,
        period_id=1,
    )
    arb = receipt_struct_hash(chain_id=42161, **base)
    base_chain = receipt_struct_hash(chain_id=8453, **base)
    assert arb != base_chain


# --- constructor address / chain / RPC resolution -----------------------


def _w3_with_chain(chain_id: int = 42161) -> Web3:
    """Build a Web3 instance whose `eth.chain_id` is mocked but whose
    `eth.contract` returns a usable mock contract."""
    w3 = MagicMock(spec=Web3)
    w3.eth = MagicMock()
    w3.eth.chain_id = chain_id
    w3.eth.contract = MagicMock(return_value=MagicMock())
    return w3


def test_constructor_uses_explicit_address():
    w3 = _w3_with_chain()
    addr = Web3.to_checksum_address("0x" + "f" * 40)
    e = Escrow(address=addr, chain="arbitrum", w3=w3)
    assert e.address == addr
    assert e.chain == "arbitrum"


def test_constructor_falls_back_to_env(monkeypatch):
    monkeypatch.setenv("HYPNEX_FORGE_ESCROW_ADDRESS", "0x" + "9" * 40)
    w3 = _w3_with_chain()
    e = Escrow(chain="arbitrum", w3=w3)
    assert e.address.lower() == ("0x" + "9" * 40).lower()


def test_constructor_raises_when_unknown_address(monkeypatch):
    # Make sure neither env nor ESCROW_ADDRESSES has a value.
    monkeypatch.delenv("HYPNEX_FORGE_ESCROW_ADDRESS", raising=False)
    w3 = _w3_with_chain()
    with pytest.raises(ValueError, match="escrow address unknown"):
        Escrow(chain="ethereum", w3=w3)


def test_constructor_default_relayer_url():
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3)
    assert e.relayer_url == "https://relayer.hypnex.xyz"


def test_constructor_relayer_url_override():
    w3 = _w3_with_chain()
    e = Escrow(
        address="0x" + "1" * 40, chain="arbitrum", w3=w3,
        relayer_url="https://custom.example.com",
    )
    assert e.relayer_url == "https://custom.example.com"


def test_constructor_relayer_url_from_env(monkeypatch):
    monkeypatch.setenv("HYPNEX_FORGE_RELAYER_URL", "https://env.example.com")
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3)
    assert e.relayer_url == "https://env.example.com"


# --- view-method delegation ---------------------------------------------


def _make_escrow_with_mock_contract(view_returns: dict | None = None) -> Escrow:
    """Build an Escrow whose self.contract is a fully mocked Contract."""
    w3 = _w3_with_chain()
    contract = MagicMock()
    if view_returns:
        for fn_name, value in view_returns.items():
            getattr(contract.functions, fn_name).return_value.call.return_value = value
    w3.eth.contract = MagicMock(return_value=contract)
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3)
    return e


def test_balance_with_explicit_agent():
    e = _make_escrow_with_mock_contract({"balanceOf": 12345})
    out = e.balance(b"\x00" * 32, agent=Web3.to_checksum_address("0x" + "2" * 40))
    assert out == 12345


def test_balance_requires_agent_or_account():
    e = _make_escrow_with_mock_contract()
    with pytest.raises(ValueError, match="No account"):
        e.balance(b"\x00" * 32)


def test_tool_revenue_delegates():
    e = _make_escrow_with_mock_contract({"toolRevenue": 7 * 10**18})
    assert e.tool_revenue(b"\x00" * 32) == 7 * 10**18


def test_treasury_revenue_delegates():
    e = _make_escrow_with_mock_contract({"treasuryRevenue": 99})
    assert e.treasury_revenue() == 99


def test_protocol_fee_bps_delegates():
    e = _make_escrow_with_mock_contract({"protocolFeeBps": 1000})
    assert e.protocol_fee_bps() == 1000


def test_quote_settle_returns_tuple():
    contract = MagicMock()
    contract.functions.quoteSettle.return_value.call.return_value = [
        100 * 10**15, 90 * 10**15, 10 * 10**15,
    ]
    w3 = _w3_with_chain()
    w3.eth.contract = MagicMock(return_value=contract)
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3)

    total, tool, fee = e.quote_settle(b"\x00" * 32, 100)
    assert total == 100 * 10**15
    assert tool == 90 * 10**15
    assert fee == 10 * 10**15


# --- sign_receipt --------------------------------------------------------


def test_sign_receipt_produces_65_byte_signature():
    pk = "0x" + "1" * 64
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3, private_key=pk)

    sig = e.sign_receipt(
        tool_id=b"\x00" * 32,
        agent=Web3.to_checksum_address("0x" + "2" * 40),
        call_count=10,
        period_id=1,
    )
    assert isinstance(sig, bytes)
    assert len(sig) == 65


def test_sign_receipt_requires_account():
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3)
    with pytest.raises(ValueError, match="requires a signer"):
        e.sign_receipt(b"\x00" * 32, "0x" + "2" * 40, 1, 1)


def test_sign_receipt_is_deterministic_per_input():
    pk = "0x" + "1" * 64
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3, private_key=pk)
    args = dict(
        tool_id=b"\x00" * 32,
        agent=Web3.to_checksum_address("0x" + "2" * 40),
        call_count=10,
        period_id=1,
    )
    sig_a = e.sign_receipt(**args)
    sig_b = e.sign_receipt(**args)
    assert sig_a == sig_b


def test_sign_receipt_changes_with_input():
    pk = "0x" + "1" * 64
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3, private_key=pk)
    base = dict(
        tool_id=b"\x00" * 32,
        agent=Web3.to_checksum_address("0x" + "2" * 40),
        call_count=10,
    )
    sig_1 = e.sign_receipt(period_id=1, **base)
    sig_2 = e.sign_receipt(period_id=2, **base)
    assert sig_1 != sig_2


# --- post_receipt --------------------------------------------------------


def test_post_receipt_sends_correct_payload():
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3)

    captured = {}

    class FakeResp:
        def read(self):
            return b'{"accepted": true}'

    class FakeCtx:
        def __enter__(self):
            return FakeResp()

        def __exit__(self, *args):
            return False

    def fake_urlopen(req, timeout):
        captured["url"] = req.full_url
        captured["body"] = req.data.decode("utf-8")
        captured["method"] = req.get_method()
        captured["headers"] = dict(req.headers)
        return FakeCtx()

    with patch("hypnex_forge.escrow.urllib.request.urlopen", new=fake_urlopen):
        out = e.post_receipt(
            tool_id=b"\xab" * 32,
            agent=Web3.to_checksum_address("0x" + "2" * 40),
            call_count=10,
            period_id=1,
            signature=b"\xcd" * 65,
        )

    assert captured["method"] == "POST"
    assert captured["url"].endswith("/receipt")
    assert "https://relayer.hypnex.xyz" in captured["url"]
    body = captured["body"]
    assert "0x" + "ab" * 32 in body
    assert "0x" + "cd" * 65 in body
    assert '"callCount": 10' in body
    assert '"periodId": 1' in body
    assert out == {"accepted": True}


def test_call_with_receipt_combines_sign_and_post():
    pk = "0x" + "1" * 64
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3, private_key=pk)

    with patch.object(e, "post_receipt", return_value={"accepted": True}) as m:
        out = e.call_with_receipt(
            tool_id=b"\x00" * 32,
            agent=Web3.to_checksum_address("0x" + "2" * 40),
            call_count=5,
            period_id=3,
        )
    assert out == {"accepted": True}
    args, kwargs = m.call_args
    # post_receipt(tool_id, agent, call_count, period_id, signature, ...)
    assert args[0] == b"\x00" * 32
    assert args[2] == 5
    assert args[3] == 3
    assert isinstance(args[4], bytes) and len(args[4]) == 65


# --- write-method gating ------------------------------------------------


def test_write_methods_require_account():
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3)
    with pytest.raises(ValueError, match="requires a signer"):
        e.deposit(b"\x00" * 32, 1, auto_approve=False)
    with pytest.raises(ValueError, match="requires a signer"):
        e.set_signer(b"\x00" * 32, "0x" + "2" * 40)
    with pytest.raises(ValueError, match="requires a signer"):
        e.withdraw_tool(b"\x00" * 32, "0x" + "2" * 40)
    with pytest.raises(ValueError, match="requires a signer"):
        e.settle(b"\x00" * 32, "0x" + "2" * 40, 1, 1, b"\x00" * 65)


def test_deposit_rejects_zero_amount():
    pk = "0x" + "1" * 64
    w3 = _w3_with_chain()
    e = Escrow(address="0x" + "1" * 40, chain="arbitrum", w3=w3, private_key=pk)
    with pytest.raises(ValueError, match="amount must be > 0"):
        e.deposit(b"\x00" * 32, 0)
