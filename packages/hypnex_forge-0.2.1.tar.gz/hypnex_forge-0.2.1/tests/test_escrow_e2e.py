"""End-to-end test: python-forge Escrow SDK signs a receipt, the
deployed ForgeEscrow contract recovers the signer correctly, and
settle() succeeds.

Skipped when `anvil` (foundry) is not on PATH or the compiled artifacts
under registry-contracts/out/ are missing.

This is the cross-stack proof that the SDK byte-encoding matches
on-chain `keccak256(abi.encode(...))` + EIP-191 wrapping. If this passes,
any SDK-signed receipt will also be recovered identically by the
Cloudflare Worker (which uses viem's identical primitives).
"""

from __future__ import annotations

import json
import shutil
import socket
import subprocess
import time
from pathlib import Path
from typing import Iterator

import pytest
from eth_account import Account
from web3 import Web3
from web3.types import TxReceipt

REPO_ROOT = Path(__file__).resolve().parents[2]  # projects/hypnex/
ARTIFACTS = REPO_ROOT / "registry-contracts" / "out"

# Anvil deterministic dev keys (well-known; safe to publish).
ANVIL_KEYS = [
    "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",  # 0xf39F…2266
    "0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d",  # 0x7099…79C8
    "0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a",  # 0x3C44…93BC
    "0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6",  # 0x90F7…b906
]


# --- helpers --------------------------------------------------------------


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _load_artifact(rel: str) -> dict:
    """Read a Foundry-compiled JSON artifact (returns {abi, bytecode})."""
    path = ARTIFACTS / rel
    data = json.loads(path.read_text())
    return {
        "abi": data["abi"],
        "bytecode": data["bytecode"]["object"],
    }


def _deploy(w3: Web3, deployer_pk: str, artifact: dict, *args) -> str:
    acct = Account.from_key(deployer_pk)
    factory = w3.eth.contract(abi=artifact["abi"], bytecode=artifact["bytecode"])
    tx = factory.constructor(*args).build_transaction({
        "from": acct.address,
        "nonce": w3.eth.get_transaction_count(acct.address),
        "chainId": w3.eth.chain_id,
        "gas": 8_000_000,
    })
    signed = acct.sign_transaction(tx)
    txhash = w3.eth.send_raw_transaction(signed.raw_transaction)
    rcpt: TxReceipt = w3.eth.wait_for_transaction_receipt(txhash, timeout=60)
    assert rcpt["status"] == 1, "deploy reverted"
    return rcpt["contractAddress"]


def _send(w3: Web3, pk: str, fn, value: int = 0) -> TxReceipt:
    acct = Account.from_key(pk)
    tx = fn.build_transaction({
        "from": acct.address,
        "nonce": w3.eth.get_transaction_count(acct.address),
        "value": value,
        "chainId": w3.eth.chain_id,
        "gas": 1_500_000,
    })
    signed = acct.sign_transaction(tx)
    txhash = w3.eth.send_raw_transaction(signed.raw_transaction)
    return w3.eth.wait_for_transaction_receipt(txhash, timeout=60)


# MockMOR is already compiled by Foundry as part of ForgeEscrow.t.sol.
# We reuse its artifact rather than recompiling at test time.


# --- fixtures -------------------------------------------------------------


@pytest.fixture(scope="module")
def anvil() -> Iterator[str]:
    if not shutil.which("anvil"):
        pytest.skip("anvil not on PATH; install foundry")
    if not (ARTIFACTS / "ForgeEscrow.sol" / "ForgeEscrow.json").exists():
        pytest.skip("contracts not compiled; run `forge build` first")

    port = _free_port()
    rpc = f"http://127.0.0.1:{port}"
    proc = subprocess.Popen(
        ["anvil", "--port", str(port), "--silent"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    # Poll TCP-level readiness, then verify JSON-RPC.
    ready = False
    for _ in range(80):
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.3):
                pass
            w3 = Web3(Web3.HTTPProvider(rpc, request_kwargs={"timeout": 2}))
            _ = w3.eth.chain_id
            ready = True
            break
        except Exception:
            time.sleep(0.1)
    if not ready:
        proc.terminate()
        pytest.skip("anvil did not become ready")
    try:
        yield rpc
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


@pytest.fixture(scope="module")
def deployed(anvil) -> dict:
    """Deploy MockMOR + ForgeToolRegistry + ForgeEscrow on Anvil."""
    w3 = Web3(Web3.HTTPProvider(anvil))
    deployer_pk = ANVIL_KEYS[0]
    deployer = Account.from_key(deployer_pk).address

    mock = _load_artifact("ForgeEscrow.t.sol/MockMOR.json")
    mor_addr = _deploy(w3, deployer_pk, mock)
    mor = w3.eth.contract(address=mor_addr, abi=mock["abi"])

    reg_art = _load_artifact("ForgeToolRegistry.sol/ForgeToolRegistry.json")
    listing_fee = 10**18
    reg_addr = _deploy(w3, deployer_pk, reg_art, mor_addr, deployer, listing_fee)

    relayer_pk = ANVIL_KEYS[1]
    relayer = Account.from_key(relayer_pk).address

    esc_art = _load_artifact("ForgeEscrow.sol/ForgeEscrow.json")
    esc_addr = _deploy(w3, deployer_pk, esc_art, mor_addr, reg_addr, deployer, relayer, 1000)

    return {
        "rpc": anvil,
        "w3": w3,
        "mor_addr": mor_addr,
        "mor": mor,
        "reg_addr": reg_addr,
        "reg_abi": reg_art["abi"],
        "esc_addr": esc_addr,
        "esc_abi": esc_art["abi"],
        "deployer_pk": deployer_pk,
        "deployer": deployer,
        "relayer_pk": relayer_pk,
        "relayer": relayer,
    }


# --- the actual end-to-end test ------------------------------------------


def test_sdk_signed_receipt_settles_on_chain(deployed):
    """SDK signs a receipt → contract recovers + accepts."""
    from hypnex_forge.escrow import Escrow as EscrowSDK

    w3: Web3 = deployed["w3"]
    mor = deployed["mor"]
    reg = w3.eth.contract(address=deployed["reg_addr"], abi=deployed["reg_abi"])
    esc = w3.eth.contract(address=deployed["esc_addr"], abi=deployed["esc_abi"])

    tool_owner_pk = ANVIL_KEYS[2]
    tool_owner = Account.from_key(tool_owner_pk).address
    agent_pk = ANVIL_KEYS[3]
    agent = Account.from_key(agent_pk).address

    # Fund the tool owner with MOR for the listing fee + grant allowance.
    _send(w3, deployed["deployer_pk"], mor.functions.mint(tool_owner, 10 * 10**18))
    _send(w3, tool_owner_pk, mor.functions.approve(deployed["reg_addr"], 2**256 - 1))

    # Tool owner registers a tool with price 0.001 MOR / call.
    price = 10**15
    rcpt = _send(
        w3, tool_owner_pk,
        reg.functions.register("hypnex", "websearch", "https://mcp.example.com",
                               [Web3.keccak(text="search")], price),
    )
    assert rcpt["status"] == 1
    tool_id = Web3.keccak(text="hypnex/websearch")

    # Tool owner sets themselves as the receipt signer.
    _send(w3, tool_owner_pk, esc.functions.setSigner(tool_id, tool_owner))
    assert esc.functions.signerOf(tool_id).call().lower() == tool_owner.lower()

    # Fund the agent with MOR + escrow deposit via the SDK.
    _send(w3, deployed["deployer_pk"], mor.functions.mint(agent, 10 * 10**18))
    sdk = EscrowSDK(
        address=deployed["esc_addr"],
        chain="arbitrum",  # CHAIN_IDS[arbitrum]=42161; Anvil reports its own id
        w3=w3,
        private_key=agent_pk,
    )
    # Anvil's chain_id won't match arbitrum's 42161; the contract uses
    # block.chainid for the signature struct, so the SDK must reflect
    # the Anvil chain id at sign time. The SDK reads w3.eth.chain_id
    # directly inside sign_receipt, which is correct here.

    # Approve + deposit.
    _send(w3, agent_pk, mor.functions.approve(deployed["esc_addr"], 2**256 - 1))
    sdk.deposit(tool_id, 1 * 10**18, auto_approve=False)
    assert sdk.balance(tool_id, agent) == 10**18

    # Tool owner signs a receipt for 100 calls in period 1.
    tool_owner_sdk = EscrowSDK(
        address=deployed["esc_addr"],
        chain="arbitrum",
        w3=w3,
        private_key=tool_owner_pk,
    )
    sig = tool_owner_sdk.sign_receipt(tool_id, agent, call_count=100, period_id=1)
    assert len(sig) == 65

    # Relayer submits settle().
    relayer_sdk = EscrowSDK(
        address=deployed["esc_addr"],
        chain="arbitrum",
        w3=w3,
        private_key=deployed["relayer_pk"],
    )
    txhash = relayer_sdk.settle(tool_id, agent, 100, 1, sig)
    rcpt = w3.eth.wait_for_transaction_receipt(txhash, timeout=60)
    assert rcpt["status"] == 1, "settle reverted"

    # Verify accounting.
    expected_total = 100 * price
    expected_fee = expected_total * 1000 // 10_000
    expected_tool = expected_total - expected_fee
    assert esc.functions.balanceOf(tool_id, agent).call() == 10**18 - expected_total
    assert esc.functions.toolRevenue(tool_id).call() == expected_tool
    assert esc.functions.treasuryRevenue().call() == expected_fee
    assert esc.functions.lastPeriodId(tool_id, agent).call() == 1


def test_tampered_callcount_rejected_on_chain(deployed):
    """Mismatched callCount must revert with BadSignature."""
    from hypnex_forge.escrow import Escrow as EscrowSDK
    w3: Web3 = deployed["w3"]

    tool_owner_pk = ANVIL_KEYS[2]
    agent = Account.from_key(ANVIL_KEYS[3]).address
    tool_id = Web3.keccak(text="hypnex/websearch")  # registered above

    sdk = EscrowSDK(
        address=deployed["esc_addr"],
        chain="arbitrum",
        w3=w3,
        private_key=tool_owner_pk,
    )
    sig = sdk.sign_receipt(tool_id, agent, call_count=10, period_id=99)

    relayer_sdk = EscrowSDK(
        address=deployed["esc_addr"],
        chain="arbitrum",
        w3=w3,
        private_key=deployed["relayer_pk"],
    )
    # Submit with mismatched callCount (11 not 10) — recovered signer
    # will be wrong → contract reverts with BadSignature.
    with pytest.raises(Exception) as excinfo:
        relayer_sdk.settle(tool_id, agent, 11, 99, sig)
    # web3 surfaces revert reasons; accept either the BadSignature() selector
    # (0x5cd5d233 = keccak256("BadSignature()")[:4]) or the textual form.
    msg = str(excinfo.value).lower()
    assert (
        "badsignature" in msg
        or "0x5cd5d233" in msg
        or "execution reverted" in msg
    )
