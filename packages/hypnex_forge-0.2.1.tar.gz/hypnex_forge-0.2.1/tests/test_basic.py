"""Basic smoke tests for hypnex-forge — pure Python (no chain)."""

from hypnex_forge import Forge, Tool, category_tag, tool_id


def test_imports():
    assert Forge is not None
    assert Tool is not None


def test_tool_id_deterministic():
    a = tool_id("hypnex", "websearch")
    b = tool_id("hypnex", "websearch")
    assert a == b
    assert isinstance(a, bytes) and len(a) == 32


def test_category_tag_matches_keccak():
    a = category_tag("search")
    b = category_tag("search")
    assert a == b
    assert a != category_tag("data")
    assert isinstance(a, bytes) and len(a) == 32


def test_tool_dataclass_round_trip():
    t = Tool(
        owner="0x" + "1" * 40,
        name="websearch",
        namespace="myorg",
        mcp_uri="https://mcp.example.com",
        categories=(category_tag("search"),),
        price_per_call_wei=10**15,
        is_active=True,
        created_at=0,
        updated_at=0,
    )
    assert t.id == tool_id("myorg", "websearch")
    assert abs(t.price_per_call_mor - 0.001) < 1e-9


def test_forge_requires_address_when_chain_undeployed():
    # The forge SDK currently only ships with addresses populated for arbitrum
    # and base. ethereum stays None and must be passed explicitly.
    import pytest
    with pytest.raises(ValueError, match="Forge address unknown"):
        Forge(chain="ethereum")
