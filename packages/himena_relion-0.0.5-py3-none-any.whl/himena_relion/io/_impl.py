from __future__ import annotations

import logging
from pathlib import Path
import polars as pl
import subprocess
import shutil
from typing import TYPE_CHECKING
from himena import MainWindow
from himena.exceptions import Cancelled
from himena_relion.consts import RelionJobState, FileNames
from himena_relion._configs import get_relion_pipeliner_exe
from himena_relion._utils import (
    normalize_job_id,
    open_with_lock,
    update_default_pipeline,
)
from himena_relion.schemas._pipeline import RelionPipelineModel

if TYPE_CHECKING:
    from himena_relion._job_dir import JobDirectory

_LOGGER = logging.getLogger(__name__)


def open_relion_job_star(ui: MainWindow, job_dir: JobDirectory):
    """Openthe job.star file of this RELION job as text."""
    job_star_path = job_dir.job_star()
    ui.read_file(
        job_star_path,
        plugin="himena_builtins.io.read_as_text_anyway",
        append_history=False,
    )


def open_relion_job_pipeline_star(ui: MainWindow, job_dir: JobDirectory):
    """Open the job_pipeline.star file of this RELION job as text."""
    job_star_path = job_dir.job_pipeline()
    ui.read_file(
        job_star_path,
        plugin="himena_builtins.io.read_as_text_anyway",
        append_history=False,
    )


def open_job_parameters(ui: MainWindow, job_dir: JobDirectory):
    from himena_relion._widgets._job_widgets import QJobParameterView

    widget = QJobParameterView()
    widget.initialize(job_dir)
    win = ui.add_widget(
        widget,
        title=f"Parameters of {job_dir.job_normal_id()}",
    )
    win.size = (480, 480)


def gentle_clean_relion_job(ui: MainWindow, job_dir: JobDirectory):
    """Perform a gentle clean of this RELION job."""
    job_num = int(job_dir.job_number)
    # Work like this:
    # $ relion_pipeliner --gentle_clean 5
    subprocess.run(
        [get_relion_pipeliner_exe(), "--gentle_clean", str(job_num)],
        check=True,
        cwd=job_dir.relion_project_dir,
        stdout=subprocess.PIPE,
    )
    ui.show_notification(f"Gentle cleaned job {job_dir.job_normal_id()}.")


def harsh_clean_relion_job(ui: MainWindow, job_dir: JobDirectory):
    """Perform a harsh clean of this RELION job."""
    job_num = int(job_dir.job_number)
    # Work like this:
    # $ relion_pipeliner --harsh_clean 5
    subprocess.run(
        [get_relion_pipeliner_exe(), "--harsh_clean", str(job_num)],
        check=True,
        cwd=job_dir.relion_project_dir,
        stdout=subprocess.PIPE,
    )
    ui.show_notification(f"Harsh cleaned job {job_dir.job_normal_id()}.")


def abort_relion_job(ui: MainWindow, job_dir: JobDirectory):
    """Abort this RELION job."""
    if job_dir.state() == RelionJobState.EXIT_SUCCESS:
        raise RuntimeError("Cannot abort a finished job.")
    if ui.exec_choose_one_dialog(
        title="Abort job?",
        message="Are you sure you want to abort this job?",
        choices=[("Yes, abort", True), ("Cancel", False)],
        how="buttons",
    ):
        job_dir.path.joinpath(FileNames.ABORT_NOW).touch()


def overwrite_relion_job(ui: MainWindow, job_dir: JobDirectory):
    """Overwrite this RELION job's parameters and execute again."""
    job_cls = job_dir._to_job_class()
    if job_cls is None:
        raise RuntimeError("Cannot determine job class.")

    scheduler = job_cls._show_scheduler_widget(ui, {}, cwd=job_dir.relion_project_dir)
    scheduler.set_edit_mode(job_dir)
    scheduler.set_parameters(job_dir.get_job_params_as_dict())


def clone_relion_job(ui: MainWindow, job_dir: JobDirectory):
    """Clone this RELION job.

    This will not immediately make a copy of the job directory, so it is different from
    the clone operation in cryoSPARC. Parameters from this job will be copied to the
    job runner widget to facilitate creating a new job with the same parameters.
    """
    job_cls = job_dir._to_job_class()
    if job_cls is None:
        raise RuntimeError("Cannot determine job class.")
    scheduler = job_cls._show_scheduler_widget(ui, {}, cwd=job_dir.relion_project_dir)
    scheduler.update_by_job(job_cls, cwd=job_dir.relion_project_dir)
    scheduler.set_parameters(job_dir.get_job_params_as_dict())
    scheduler.set_schedule_mode()


def set_job_alias(ui: MainWindow, job_dir: JobDirectory):
    """Set alias for this RELION job."""
    from himena_relion._widgets._main import QRelionJobWidget

    with open_with_lock(job_dir.relion_project_dir / "default_pipeline.star") as f:
        pipeline = RelionPipelineModel.validate_text(f.read())
        # look for current alias
        _matched = pipeline.processes.process_name == job_dir.job_normal_id()
        matched = pipeline.processes.alias.filter(_matched)
        if len(matched) == 1:
            current_alias = matched[0]
            if current_alias == "None":
                current_alias = ""
            elif "/" in current_alias:
                # alias is something like "Extract/extract_bin4/"
                current_alias = current_alias.split("/")[1]
        else:
            current_alias = ""

    # This part waits for the user input, so temporarily exit from the lock context.
    res = ui.exec_user_string_input_dialog(
        message="Give alias here ...",
        choices=["Press 'Enter' to set job alias"],
        default=current_alias,
    )
    if (val := res.get_input()) is None:
        raise Cancelled
    alias = val.strip()
    if alias == "" or alias.startswith("job"):
        raise ValueError("Alias cannot be empty or start with 'job'.")

    # Check if alias is a valid folder name
    invalid_chars = '*?()/"\\|#<>&%{}$'
    if any(char in alias for char in invalid_chars):
        raise ValueError(f"Alias contains invalid characters. Avoid: {invalid_chars}")
    if set(alias) == {"."}:
        raise ValueError("Alias cannot be '.' or '..'")
    if (job_dir.path.parent / alias).exists():
        raise FileExistsError(f"Alias '{alias}' already exists.")

    with open_with_lock(job_dir.relion_project_dir / "default_pipeline.star") as f:
        new_path = job_dir.path.parent / alias
        for other_job in job_dir.path.parent.iterdir():
            if other_job.is_symlink() and other_job.resolve() == job_dir.path:
                # this is the old alias for this job
                other_job.rename(new_path)
                break
        else:
            # no existing alias, create a new one
            new_path.symlink_to(job_dir.path, target_is_directory=True)
        update_default_pipeline(
            f,
            job_dir.path.relative_to(job_dir.relion_project_dir),
            alias=normalize_job_id(new_path),
        )
    # update the job widget title
    for window in ui.iter_windows():
        if (
            isinstance(widget := window.widget, QRelionJobWidget)
            and widget._job_dir.path == job_dir.path
        ):
            widget._state_widget.initialize(job_dir)


def trash_job(ui: MainWindow, job_dir: JobDirectory):
    """Move this RELION job to trash."""
    from himena_relion._job_dir import JobDirectory

    rln_dir = job_dir.relion_project_dir

    with open_with_lock(rln_dir / "default_pipeline.star") as f:
        pipeline = RelionPipelineModel.validate_text(f.read())
        input_indices_to_remove: list[bool] = []
        # to_trash is all the relative paths to be moved to trash
        to_trash = [job_dir.path.relative_to(rln_dir)]
        for from_, to_ in zip(
            pipeline.input_edges.from_node, pipeline.input_edges.process
        ):
            job_spec = Path(to_)
            if Path(from_).parent in to_trash or job_spec in to_trash:
                if (
                    not job_spec.is_absolute()
                    and len(job_spec.parts) == 2
                    and job_spec not in to_trash[::-1]  # faster to search backwards
                ):
                    to_trash.append(job_spec)
                input_indices_to_remove.append(True)
            else:
                input_indices_to_remove.append(False)

        input_indices_to_remove = pl.Series(input_indices_to_remove)
        output_edges_to_remove = pl.Series(
            [Path(from_) in to_trash for from_ in pipeline.output_edges.process]
        )

        resp = ui.exec_choose_one_dialog(
            title="Trash job?",
            message=_html_list("Following jobs would be moved to trash:", to_trash),
            choices=[("Yes, move to trash", True), ("Cancel", False)],
        )
        if resp is None or not resp:
            raise Cancelled

        # determine other fields to remove
        process_name_to_remove = pl.Series(
            [Path(name) in to_trash for name in pipeline.processes.process_name]
        )

        process_nodes_to_remove = pl.Series(
            [Path(name) in to_trash for name in pipeline.nodes.name]
        )

        output_edges_trashed = pipeline.output_edges.dataframe.filter(
            output_edges_to_remove
        )
        nodes_trashed = pipeline.nodes.dataframe.filter(process_nodes_to_remove)

        pipeline.processes = pipeline.processes.dataframe.filter(
            ~process_name_to_remove
        )
        pipeline.nodes = pipeline.nodes.dataframe.filter(~process_nodes_to_remove)
        pipeline.input_edges = pipeline.input_edges.dataframe.filter(
            ~input_indices_to_remove
        )
        pipeline.output_edges = pipeline.output_edges.dataframe.filter(
            ~output_edges_to_remove
        )

        # close all the tabs with trashed jobs
        try:
            tabs_to_close: list[int] = []
            for i_tab, tab in ui.tabs.enumerate():
                if (
                    len(tab) > 0
                    and isinstance(_job_dir := tab[0].value, JobDirectory)
                    and _job_dir.path.relative_to(rln_dir) in to_trash
                ):
                    tabs_to_close.append(i_tab)
            for i_tab in reversed(tabs_to_close):
                del ui.tabs[i_tab]
        except Exception:
            _LOGGER.warning("Failed to close tabs for trashed jobs.", exc_info=True)

        f.seek(0)
        f.write(pipeline.to_string())

        # move the job to trash
        trash_dir = _trash_dir(rln_dir)
        trash_dir.mkdir(exist_ok=True)
        for p in to_trash:
            src = rln_dir / p
            if not src.exists():
                _LOGGER.warning(f"Source {src} does not exist. Skipping.")
                continue
            dest = trash_dir / p
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                _LOGGER.warning(f"Destination {dest} already exists. Overwriting.")
                _remove_dir_or_file(dest)
            src.rename(dest)

        # remove nodes from directories like .Nodes/DensityMap/Reconstruct/job060
        node_to_type_map = _make_node_to_type_map(nodes_trashed)
        to_node_list = output_edges_trashed["rlnPipeLineEdgeToNode"]
        for to_node in to_node_list:
            if type_label := node_to_type_map.get(to_node):
                file_in_node = rln_dir.joinpath(".Nodes", type_label, to_node)
                if file_in_node.exists():
                    file_in_node.unlink()
                # remove directory if empty
                node_dir = file_in_node.parent
                if node_dir.exists() and not any(node_dir.iterdir()):
                    node_dir.rmdir()

    rln_dir.joinpath("default_pipeline.star").touch()


def restore_trashed_jobs(relion_project_dir: Path, job_ids: list[str]):
    trash_dir = _trash_dir(relion_project_dir)
    all_jobs_to_undo: list[Path] = []
    for job_id in job_ids:
        job_path_in_trash = trash_dir / job_id
        if not job_path_in_trash.exists():
            _LOGGER.warning(f"Job {job_id} not found in trash.")
            continue
        all_jobs_to_undo.append(job_path_in_trash)

    with open_with_lock(relion_project_dir / "default_pipeline.star") as f:
        pipeline = RelionPipelineModel.validate_text(f.read())
        all_processes = [pipeline.processes.dataframe]
        all_nodes = [pipeline.nodes.dataframe]
        all_input_edges = [pipeline.input_edges.dataframe]
        all_output_edges = [pipeline.output_edges.dataframe]
        for path_to_undo in all_jobs_to_undo:
            job_pipeline_star = path_to_undo / "job_pipeline.star"
            path_dest = relion_project_dir / path_to_undo.relative_to(trash_dir)
            if not job_pipeline_star.exists():
                _LOGGER.warning(f"{job_pipeline_star} not found. Skipping.")
                continue
            if path_dest.exists():
                _LOGGER.warning(f"Destination {path_dest} already exists. Skipping.")
                continue
            job_pipeline = RelionPipelineModel.validate_file(job_pipeline_star)
            df_proc = job_pipeline.processes.dataframe
            # job_pipeline.star is still in "Running" state, so we have to update it.
            status_label = df_proc["rlnPipeLineProcessStatusLabel"]
            sl = status_label == "Running"
            if path_to_undo.joinpath(FileNames.EXIT_SUCCESS).exists():
                status_label[sl] = "Succeeded"
            elif path_to_undo.joinpath(FileNames.EXIT_FAILURE).exists():
                status_label[sl] = "Failed"
            elif path_to_undo.joinpath(FileNames.EXIT_ABORTED).exists():
                status_label[sl] = "Aborted"
            df_proc = df_proc.with_columns(status_label)
            all_processes.append(df_proc)
            all_nodes.append(job_pipeline.nodes.dataframe)
            all_input_edges.append(job_pipeline.input_edges.dataframe)
            all_output_edges.append(job_pipeline.output_edges.dataframe)
            path_dest.parent.mkdir(parents=True, exist_ok=True)
            if path_dest.exists():
                _LOGGER.warning(f"Destination {path_dest} already exists. Overwriting.")
                _remove_dir_or_file(path_dest)
            path_to_undo.rename(path_dest)
        df_processes = _concat_and_reorder(all_processes, "rlnPipeLineProcessName")
        df_nodes = _concat_and_reorder(all_nodes, "rlnPipeLineNodeName")
        df_input_edges = _concat_and_reorder(all_input_edges, "rlnPipeLineEdgeFromNode")
        df_output_edges = _concat_and_reorder(
            all_output_edges, "rlnPipeLineEdgeProcess"
        )
        pipeline.processes = df_processes
        pipeline.nodes = df_nodes
        pipeline.input_edges = df_input_edges
        pipeline.output_edges = df_output_edges
        f.seek(0)
        f.write(pipeline.to_string())

        # if the trash sub directory is empty, remove it.
        for sub in trash_dir.iterdir():
            if sub.is_dir() and not any(sub.iterdir()):
                sub.rmdir()

        # construct node to type map
        node_to_type_map: dict[str, str] = {}
        for df_node in all_nodes:
            node_to_type_map.update(_make_node_to_type_map(df_node))

        # restore .Nodes/
        node_dir = relion_project_dir.joinpath(".Nodes")
        for df_output_edge in all_output_edges[1:]:  # skip the original pipeline
            # e.g.
            # _rlnPipeLineEdgeProcess
            # _rlnPipeLineEdgeToNode
            # MotionCorr/job002/ MotionCorr/job002/corrected_micrographs.star

            # .Nodes/DensityMap/Reconstruct/job060
            for to_node in df_output_edge["rlnPipeLineEdgeToNode"]:
                if type_label := node_to_type_map.get(to_node):
                    file_in_node = node_dir.joinpath(type_label, to_node)
                    file_in_node.parent.mkdir(parents=True, exist_ok=True)
                    file_in_node.touch()


def new_job(ui: MainWindow, ignore_cancelled: bool = False):
    from himena_relion._job_class import RelionJob

    choices = [(cmd.title, cmd.command_id) for cmd in RelionJob.__relion_job_commands__]
    if resp := ui.exec_choose_one_dialog(
        title="New RELION Job",
        message="Choose a RELION job to create ...",
        choices=choices,
        how="palette",
    ):
        ui.exec_action(resp)
    elif not ignore_cancelled:
        raise Cancelled


def mark_as_finished(job_dir: JobDirectory):
    """Mark this RELION job as finished."""
    with open_with_lock(job_dir.relion_project_dir / "default_pipeline.star") as f:
        update_default_pipeline(f, normalize_job_id(job_dir.path), status="Succeeded")
        job_dir.path.joinpath(FileNames.EXIT_SUCCESS).touch(mode=775, exist_ok=True)
        for fname in [
            FileNames.EXIT_ABORTED,
            FileNames.EXIT_FAILURE,
            FileNames.ABORT_NOW,
        ]:
            path = job_dir.path / fname
            if path.exists():
                path.unlink()


def mark_as_failed(job_dir: JobDirectory):
    """Mark this RELION job as failed."""
    with open_with_lock(job_dir.relion_project_dir / "default_pipeline.star") as f:
        update_default_pipeline(f, normalize_job_id(job_dir.path), status="Failed")
        job_dir.path.joinpath(FileNames.EXIT_FAILURE).touch(mode=775, exist_ok=True)
        for fname in [
            FileNames.EXIT_ABORTED,
            FileNames.EXIT_SUCCESS,
            FileNames.ABORT_NOW,
        ]:
            path = job_dir.path / fname
            if path.exists():
                path.unlink()


def _trash_dir(relion_job_dir: Path) -> Path:
    return relion_job_dir / "Trash"


def _make_node_to_type_map(df_node) -> dict[str, str]:
    node_to_type_map: dict[str, str] = {}
    for node_name, type_label in zip(
        df_node["rlnPipeLineNodeName"], df_node["rlnPipeLineNodeTypeLabel"]
    ):
        node_to_type_map[node_name] = type_label.split(".", maxsplit=1)[0]
    return node_to_type_map


def _remove_dir_or_file(dest: Path):
    if dest.is_dir():
        shutil.rmtree(dest)
    else:
        dest.unlink()


def _concat_and_reorder(dfs: list[pl.DataFrame], column_name: str):
    df_processes = pl.concat(dfs, how="vertical_relaxed")
    order = df_processes[column_name].map_elements(_try_get_job_name).arg_sort()
    return df_processes[order]


def _try_get_job_name(x: str) -> str:
    if "/" in x:
        return x.split("/")[1]
    return x


def _html_list(
    first_line: str,
    items: list[str],
    max_items: int = 15,
):
    message_lines = [f"<p>{first_line}</p><ul>"]
    for p in items:
        message_lines.append(f"<li>{p}</li>")
        if len(message_lines) >= max_items + 1:
            message_lines.append("<li>...</li>")  # truncate long list
            break
    message_lines.append("</ul>")
    return "".join(message_lines)
