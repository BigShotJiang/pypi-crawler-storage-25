from __future__ import annotations
from pathlib import Path
from qtpy import QtWidgets as QtW
import logging
from starfile_rs import read_star
from superqt.utils import thread_worker
from himena import WidgetDataModel, StandardType
from himena.widgets import current_instance
from himena_builtins.qt.dataframe import QDataFrameView
from himena_relion._image_readers import ArrayFilteredView
from himena_relion._widgets import (
    QJobScrollArea,
    Q2DViewer,
    Q2DFilterWidget,
    register_job,
    QMicrographListWidget,
    QNumParticlesLabel,
)
from himena_relion import _job_dir
from himena_relion._widgets._shared.resizer import QResizer
from himena_relion.schemas import TSModel, TSGroupModel

_LOGGER = logging.getLogger(__name__)


@register_job("relion.importtomo", is_tomo=True)
def import_tilt_series_viewer(job_dir: _job_dir.JobDirectory):
    if job_dir.get_job_param("do_coords", default="No") == "Yes":
        return QImportCoordsViewer(job_dir)
    return QImportTiltSeriesViewer(job_dir)


def _is_import_micrographs(job_dir: _job_dir.JobDirectory) -> bool:
    return job_dir.get_job_param("images_are_motion_corrected", default="No") == "Yes"


class QImportTiltSeriesViewer(QJobScrollArea):
    def __init__(self, job_dir: _job_dir.JobDirectory):
        super().__init__()
        self._job_dir = job_dir

        self._viewer = Q2DViewer(zlabel="Tilt index")
        self._viewer.setMinimumHeight(420)
        self._resizer = QResizer(self._viewer)
        self._filter_widget = Q2DFilterWidget(bin_default=8, lowpass_default=30)
        self._ts_list = QMicrographListWidget(
            ["Movie Name", "Voltage", "Cs", "Pixel Size", "Optics Group", "Tomo Hand"]
        )
        self._ts_list.current_changed.connect(self._ts_choice_changed)
        self._layout.addWidget(
            QtW.QLabel("<b>Imported tilt series (movie projection)</b>")
        )
        self._layout.setSpacing(2)
        self._layout.addWidget(self._ts_list)
        self._layout.addWidget(self._filter_widget)
        self._layout.addWidget(self._viewer)
        self._layout.addWidget(self._resizer)
        self._filter_widget.value_changed.connect(self._filter_param_changed)
        self._binsize_old = -1
        self._is_micrograph = _is_import_micrographs(job_dir)

    def on_job_updated(self, job_dir: _job_dir.JobDirectory, path: str):
        """Handle changes to the job directory."""
        fp = Path(path)
        if fp.name.startswith("RELION_JOB_"):
            self.initialize(job_dir)
            _LOGGER.debug("%s Updated", job_dir.job_number)

    def initialize(self, job_dir: _job_dir.JobDirectory):
        """Initialize the viewer with the job directory."""
        tilt_series_star_path = job_dir.path / "tilt_series.star"
        if not tilt_series_star_path.exists():
            return

        ts_group = TSGroupModel.validate_file(tilt_series_star_path)
        choices: list[tuple[str, ...]] = []
        for val in ts_group.zip():
            choices.append(
                (
                    val.tomo_name,
                    f"{val.voltage:.0f} kV",
                    f"{val.cs} mm",
                    f"{val.original_pixel_size:.3f} Å",
                    val.optics_group_name,
                    f"{int(val.tomo_hand)}",
                )
            )
        choices.sort(key=lambda x: x[0])
        self._ts_list.set_choices(choices)

    def _ts_choice_changed(self, texts: tuple[str, ...]):
        """Handle changes to the selected tilt series."""
        if not texts:
            self._viewer.clear()
            return
        tomo_name = texts[0]
        ts_path = self._job_dir.path / "tilt_series" / f"{tomo_name}.star"
        if not ts_path.exists():
            self._viewer.clear()
            return
        ts_model = TSModel.validate_file(ts_path)
        self.window_closed_callback()
        if self._is_micrograph:
            paths = [self._job_dir.resolve_path(p) for p in ts_model.ts_paths_sorted()]
            self._worker = self._read_micrographs(paths)
        else:
            paths = [
                self._job_dir.resolve_path(p) for p in ts_model.ts_movie_paths_sorted()
            ]
            self._worker = self._uncompress_and_read_movies(paths)
        self._start_worker()

    def _on_movie_loaded(self, movie_view: ArrayFilteredView | None):
        if movie_view is None:
            return self._viewer.clear()
        self._viewer.set_array_view(
            movie_view.with_filter(self._filter_widget.apply),
            clim=self._viewer._last_clim,
        )
        self._viewer._auto_contrast()

    @thread_worker
    def _uncompress_and_read_movies(self, movie_paths: list[Path]):
        """If the movie is LZW-TIFF, uncompress it, then read it."""
        if len(movie_paths) == 0:
            yield self._on_movie_loaded, None
        elif Path(movie_paths[0]).suffix == ".mrc":
            yield self._on_movie_loaded, ArrayFilteredView.from_mrc_movies(movie_paths)
        else:
            yield self._on_movie_loaded, ArrayFilteredView.from_tif_movies(movie_paths)

    @thread_worker
    def _read_micrographs(self, mic_paths: list[Path]):
        """Read motion-corrected micrographs."""
        if len(mic_paths) == 0:
            yield self._on_movie_loaded, None
        elif Path(mic_paths[0]).suffix == ".mrc":
            yield self._on_movie_loaded, ArrayFilteredView.from_mrcs(mic_paths)
        else:
            raise ValueError("Unsupported micrograph format.")

    def _filter_param_changed(self):
        """Handle changes to filter parameters."""
        self._viewer.redraw()
        new_binsize = self._filter_widget.bin_factor()
        if self._binsize_old != new_binsize:
            self._binsize_old = new_binsize
            self._viewer.auto_fit()


class QImportCoordsViewer(QJobScrollArea):
    def __init__(self, job_dir: _job_dir.JobDirectory):
        super().__init__()
        self._job_dir = job_dir
        self._table = QDataFrameView(current_instance())
        self._table.setFixedHeight(480)
        self._num_particles_label = QNumParticlesLabel()
        self._layout.addWidget(QtW.QLabel("<b>Imported coordinates</b>"))
        self._layout.addWidget(self._table)
        self._layout.addWidget(self._num_particles_label)

    def on_job_updated(self, job_dir: _job_dir.JobDirectory, path: str):
        """Handle changes to the job directory."""
        fp = Path(path)
        if fp.name == "particles.star":
            self.initialize(job_dir)
            _LOGGER.debug("%s Updated", job_dir.job_number)

    def initialize(self, job_dir: _job_dir.JobDirectory):
        """Initialize the viewer with the job directory."""
        coords_star_path = job_dir.path / "particles.star"
        if coords_star_path.exists():
            df = read_star(coords_star_path).first().to_polars()
            data_model = WidgetDataModel(value=df, type=StandardType.DATAFRAME)
            self._num_particles_label.set_number(df.height)
        else:
            data_model = WidgetDataModel(value={}, type=StandardType.DATAFRAME)
            self._num_particles_label.set_number(-1)
        self._table.update_model(data_model)
