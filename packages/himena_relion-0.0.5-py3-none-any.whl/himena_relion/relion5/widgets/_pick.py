from __future__ import annotations
from pathlib import Path
import logging
from typing import Iterator
import mrcfile
import numpy as np
import polars as pl
from starfile_rs import read_star
from superqt import QToggleSwitch
from superqt.utils import thread_worker
from qtpy import QtWidgets as QtW, QtCore
from himena_builtins.qt.widgets._image_components import QHistogramView
from himena_relion._image_readers._array import ArrayFilteredView
from himena_relion._widgets import (
    QJobScrollArea,
    Q2DViewer,
    Q2DFilterWidget,
    register_job,
    QImageViewTextEdit,
    QMicrographListWidget,
    QPlotCanvas,
)
from himena_relion import _job_dir
from himena_relion._widgets._shared.resizer import QResizer
from himena_relion.relion5._connections import _get_template_for_pick
from himena_relion.schemas import CoordsModel, MicrographsStarModel

_LOGGER = logging.getLogger(__name__)
_DIAMETER_DEFAULT = 100.0


class QMarkerFilterWidget(QtW.QWidget):
    value_changed = QtCore.Signal()

    def __init__(self):
        super().__init__()
        layout = QtW.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self._show_marker_switch = QToggleSwitch("Show particles")
        self._show_marker_switch.setChecked(True)
        self._show_marker_switch.setToolTip("Toggle visibility of the picked particles")
        self._show_marker_switch.toggled.connect(self._on_show_marker_toggled)
        self._hist_view = QHistogramView()
        self._hist_view.setFixedHeight(32)
        self._hist_view.clim_changed.connect(lambda: self.value_changed.emit())
        self._hist_view.setValueFormat(".3f", always_show=True)
        self._hist_view.setToolTip(
            "Distribution of figure of merit (FOM) values in this micrograph"
        )
        layout.addWidget(self._show_marker_switch)
        layout.addWidget(QtW.QLabel("FOM:"))
        layout.addWidget(self._hist_view)

    def _on_show_marker_toggled(self, checked: bool):
        self.value_changed.emit()

    def filter_by_fom(self, coords: CoordsModel) -> np.ndarray:
        """Return filtered coordinates based on FOM."""
        if not self._show_marker_switch.isChecked():
            return np.zeros((0, 3), dtype=np.float32)
        min_val, max_val = self._hist_view.clim()
        if coords.fom is None:
            sl = slice(None)
        else:
            fom = coords.fom.to_numpy()
            sl = (fom >= min_val) & (fom <= max_val)
        arr = np.column_stack([np.zeros(len(coords.x)), coords.y, coords.x])
        return arr[sl]


@register_job("relion.manualpick")
class QManualPickViewer(QJobScrollArea):
    def __init__(self, job_dir: _job_dir.JobDirectory):
        super().__init__()
        self._job_dir = job_dir
        layout = self._layout

        self._viewer = Q2DViewer(zlabel="")
        self._resizer = QResizer(self._viewer)
        self._last_update: dict[str, tuple[float, int]] = {}  # path -> (mtime, npoints)
        self._viewer.setMinimumHeight(480)
        self._mic_list = QMicrographListWidget(
            ["Micrograph", "Picked", "Coordinates", "Micrograph Full Path"]
        )
        self._mic_list.setFixedHeight(130)
        self._mic_list.setColumnHidden(2, True)
        self._mic_list.setColumnHidden(3, True)
        self._mic_list.current_changed.connect(self._mic_changed)
        self._num_picked_label = QtW.QLabel("")
        self._num_picked_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight)
        self._filter_widget = Q2DFilterWidget(bin_default=8, lowpass_default=20)
        self._marker_widget = QMarkerFilterWidget()
        self._marker_widget.value_changed.connect(self._update_points)
        layout.setSpacing(0)
        layout.addWidget(QtW.QLabel("<b>Micrographs with picked particles</b>"))
        layout.addWidget(self._marker_widget)
        layout.addWidget(self._filter_widget)
        layout.addWidget(self._viewer)
        layout.addWidget(self._resizer)
        layout.addWidget(self._num_picked_label)
        layout.addWidget(self._mic_list)
        self._filter_widget.value_changed.connect(self._filter_param_changed)
        self._binsize_old = -1
        # cache current coordinates here
        self._coords: CoordsModel | None = None

    def initialize(self, job_dir: _job_dir.JobDirectory):
        """Initialize the viewer with the job directory."""
        self._job_dir = job_dir
        self._viewer.clear()
        self._last_update.clear()
        self._process_update(force_update=True)
        self._viewer.auto_fit()

    def on_job_updated(self, job_dir: _job_dir.JobDirectory, path: str):
        """Handle changes to the job directory."""
        fp = Path(path)
        if fp.name.startswith("RELION_JOB_") or fp.suffix in (".star", ".mrcs"):
            self._process_update(force_update=fp.name.startswith("RELION_JOB_"))
            _LOGGER.debug("%s Updated", job_dir.job_number)

    def _mic_changed(self, row: tuple[str, str, str, str]):
        """Handle changes to selected micrograph."""
        _, _, _coords_path, _mic_path = row
        mic_path = self._job_dir.resolve_path(_mic_path)
        movie_view = ArrayFilteredView.from_mrc(mic_path)
        image_scale = movie_view.get_scale()
        self._filter_widget.set_image_scale(image_scale)
        self._viewer.set_array_view(
            movie_view.with_filter(self._filter_widget.apply),
            clim=self._viewer._last_clim,
        )
        self._reload_coords(_coords_path)
        self._update_points()
        self._viewer._auto_contrast()

    def _filter_param_changed(self):
        """Handle changes to filter parameters."""
        self._viewer.redraw()
        new_binsize = self._filter_widget.bin_factor()
        if self._binsize_old != new_binsize:
            self._binsize_old = new_binsize
            self._viewer.auto_fit()
        self._update_points()

    def _reload_coords(self, path: str | Path):
        self._coords = None
        if (coords_path := self._job_dir.resolve_path(path)).exists():
            if coords_path.suffix == ".star":
                self._coords = CoordsModel.validate_file(coords_path)
        fom_found = False
        if self._coords is not None:
            if (fom := self._coords.fom) is not None:
                fom_arr = fom.to_numpy()
                min_old, max_old = self._marker_widget._hist_view._minmax
                min_new, max_new = fom_arr.min(), fom_arr.max()
                self._marker_widget._hist_view.set_hist_for_array(
                    fom_arr,
                    clim=self._marker_widget._hist_view.clim(),
                    minmax=(min(min_old, min_new), max(max_old, max_new)),
                )
                fom_found = True
        self._marker_widget.setVisible(fom_found)

    def _clear_points(self, *_):
        """Clear all the points before reloading."""
        self._viewer.set_points(np.empty((0, 3)))
        self._viewer.redraw()

    def _update_points(self, *_):
        if self._coords is None:
            self._clear_points()
        else:
            arr = self._marker_widget.filter_by_fom(self._coords)
            image_scale = self._filter_widget.image_scale()
            bins = self._filter_widget.bin_factor()
            try:
                diameter = self._get_diameter()
            except Exception:
                diameter = _DIAMETER_DEFAULT
            self._viewer.set_points(arr / bins, size=diameter / image_scale / bins)
            self._viewer.redraw()

    def _process_update(self, force_update: bool = False):
        if force_update or self._worker is None:
            self._worker = self._prep_mic_list()
            self._start_worker()

    @thread_worker
    def _prep_mic_list(self):
        choices = []
        num_total = 0
        num_mic_picked = 0
        for mic_path, coords_path in iter_micrograph_and_coordinates(self._job_dir):
            if coords_path is None:
                # No picked particles yet
                num = 0
            else:
                coords_path = self._job_dir.resolve_path(coords_path)
                if not coords_path.exists():
                    # No picked particles yet
                    num = 0
                    self._last_update.pop(coords_path.stem, None)
                else:
                    num_mic_picked += 1
                    # Picked particles found, read the content
                    # Reading all the particles can be slow, so use mtime caching
                    mtime0, num0 = self._last_update.get(coords_path.stem, (-1, 0))
                    if (mtime := coords_path.stat().st_mtime) <= mtime0:
                        num = num0
                    else:
                        num = read_star(coords_path).first().trust_loop().shape[0]
                        self._last_update[coords_path.stem] = mtime, num
                coords_path = coords_path.as_posix()
            mic_path_name = Path(mic_path).name
            choices.append((mic_path_name, str(num), coords_path or "", mic_path))
            num_total += num
        current_path = Path(self._mic_list.current_text(2))
        yield self._mic_list.set_choices, choices

        text = (
            f"Micrograph picked: {num_mic_picked} / {len(choices)} | "
            f"Total: {num_total} particles"
        )
        yield self._num_picked_label.setText, text
        yield self._clear_points, None

        self._reload_coords(current_path)
        yield self._update_points, None
        self._worker = None

    def _get_diameter(self) -> float:
        return float(self._job_dir.get_job_param("diameter"))


def iter_micrograph_and_coordinates(
    job_dir: _job_dir.JobDirectory,
) -> Iterator[tuple[str, str | None]]:
    if job_dir.job_type_label().startswith("relion.manualpick"):
        mic = job_dir.get_job_param("fn_in")
    else:
        mic = job_dir.get_job_param("fn_input_autopick")
    mic_model = MicrographsStarModel.validate_file(job_dir.resolve_path(mic))
    for path in mic_model.micrographs.mic_name:
        fp = Path(path)
        # If micrographs are output of MotionCorr, path is like
        # "MotionCorr/job002/Movies/xxx.mrc". However, if micrographs are directly imported,
        # path is like "micrographs/xxx.mrc".
        parts = fp.parts
        if parts[0] == "MotionCorr":
            parts = parts[2:]
        movie_dir = job_dir.path / "/".join(parts[:-1])
        if (pickpath := movie_dir.joinpath(fp.stem + "_autopick.star")).exists():
            pick_star = job_dir.make_relative_path(pickpath).as_posix()
        elif (pickpath := movie_dir.joinpath(fp.stem + "_manualpick.star")).exists():
            pick_star = job_dir.make_relative_path(pickpath).as_posix()
        else:
            pick_star = None
        yield (path, pick_star)


class QAutopickViewerBase(QManualPickViewer):
    """Viewer for template-based autopicking jobs."""


# fallback for relion.autopick
@register_job("relion.autopick")
class QAutoViewer(QAutopickViewerBase):
    def _get_diameter(self) -> float:
        return _DIAMETER_DEFAULT


@register_job("relion.autopick.ref2d")
class QTemplatePick2DViewer(QAutopickViewerBase):
    def _get_diameter(self) -> float:
        path = self._job_dir.resolve_path(_get_template_for_pick(self._job_dir.path))
        with mrcfile.open(path, header_only=True) as mrc:
            return float(mrc.voxel_size.x * mrc.header.nx)


@register_job("relion.autopick.ref3d")
class QTemplatePick3DViewer(QAutopickViewerBase):
    def __init__(self, job_dir: _job_dir.JobDirectory):
        super().__init__(job_dir)
        self._text_edit = QImageViewTextEdit(image_size_pixel=64)
        self._text_edit.setMinimumHeight(120)
        self._layout.insertWidget(0, QtW.QLabel("<b>&#9679; Reference Projections</b>"))
        self._layout.insertWidget(1, self._text_edit)
        self._last_ref_proj_mtime: float = 0.0

    def _get_diameter(self) -> float:
        path = self._job_dir.path / "reference_projections.mrcs"
        with mrcfile.open(path, header_only=True) as mrc:
            return float(mrc.voxel_size.x * mrc.header.nx)

    def _process_update(self, force_update: bool = False):
        super()._process_update(force_update=force_update)
        ref_proj_path = self._job_dir.path / "reference_projections.mrcs"
        if ref_proj_path.exists():
            if (mtime := ref_proj_path.stat().st_mtime) <= self._last_ref_proj_mtime:
                return
            self._last_ref_proj_mtime = mtime
            self._text_edit.clear()
            with mrcfile.open(ref_proj_path) as mrc:
                images = np.asarray(mrc.data, dtype=np.float32)
            for img_slice in images:
                img_str = self._text_edit.image_to_base64(img_slice)
                self._text_edit.insert_base64_image(img_str)


@register_job("relion.autopick.log")
class QLoGPickViewer(QAutopickViewerBase):
    def _get_diameter(self) -> float:
        return float(self._job_dir.get_job_param("log_diam_max"))


@register_job("relion.autopick.topaz.pick")
class QTopazPickViewer(QAutopickViewerBase):
    def _get_diameter(self) -> float:
        diameter = float(self._job_dir.get_job_param("topaz_particle_diameter"))
        if diameter <= 0:
            diameter = _DIAMETER_DEFAULT
        return diameter


@register_job("relion.autopick.topaz.train")
class QTopazTrainPickViewer(QJobScrollArea):
    def __init__(self, job_dir: _job_dir.JobDirectory):
        super().__init__()
        self._job_dir = job_dir

        self._canvas0 = QPlotCanvas(self)
        self._canvas1 = QPlotCanvas(self)
        self._canvas2 = QPlotCanvas(self)
        self._layout.addWidget(QtW.QLabel("<b>&#9679; Loss</b>"))
        self._layout.addWidget(self._canvas0)
        self._layout.addWidget(QtW.QLabel("<b>&#9679; True Positive</b>"))
        self._layout.addWidget(self._canvas1)
        self._layout.addWidget(QtW.QLabel("<b>&#9679; False Positive</b>"))
        self._layout.addWidget(self._canvas2)

    def on_job_updated(self, job_dir: _job_dir.JobDirectory, path: str):
        """Handle changes to the job directory."""
        fp = Path(path)
        if fp.name.startswith("RELION_JOB_") or fp.suffix == ".sav":
            self.initialize(job_dir)
            _LOGGER.debug("%s Updated", job_dir.job_number)

    def initialize(self, job_dir: _job_dir.JobDirectory):
        """Initialize the viewer with the job directory."""
        model_training_txt = job_dir.path / "model_training.txt"
        if not model_training_txt.exists():
            return
        # model_training.txt has columns:
        # epoch, iter, split, loss, ge_penalty, precision, tpr, fpr, auprc
        # and the null values are represented as "-"
        df = pl.read_csv(model_training_txt, separator="\t", null_values="-")
        is_train = pl.col("split") == "train"
        df_train = df.filter(is_train)  # multiple values per epoch
        df_test = df.filter(~is_train)

        self._canvas0.plot_topaz_train(df_train, df_test, "loss")
        self._canvas1.plot_topaz_train(df_train, df_test, "tpr")
        self._canvas2.plot_topaz_train(df_train, df_test, "fpr")

    def widget_added_callback(self):
        self._canvas0.widget_added_callback()
        self._canvas1.widget_added_callback()
        self._canvas2.widget_added_callback()
