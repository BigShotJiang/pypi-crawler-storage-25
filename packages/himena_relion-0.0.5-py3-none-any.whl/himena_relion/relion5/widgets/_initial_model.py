from __future__ import annotations

import logging
from pathlib import Path
from qtpy import QtWidgets as QtW
from superqt.utils import thread_worker
from himena_relion._widgets._shared.resizer import QResizer
from himena_relion._widgets import (
    QJobScrollArea,
    Q3DViewer,
    register_job,
    QIntWidget,
    QIntChoiceWidget,
    QNumParticlesLabel,
    QSymmetryLabel,
)
from himena_relion import _job_dir
from himena_relion.schemas import ModelStarModel

_LOGGER = logging.getLogger(__name__)


@register_job("relion.initialmodel")
@register_job("relion.initialmodel.tomo", is_tomo=True)
class QInitialModelViewer(QJobScrollArea):
    def __init__(self, job_dir: _job_dir.InitialModel3DJobDirectory):
        super().__init__()
        self._viewer = Q3DViewer()
        self._resizer = QResizer(self._viewer)

        self._class_choice = QIntWidget("Class", label_width=50)
        self._iter_choice = QIntChoiceWidget("Iteration", label_width=60)
        self._class_choice.setMinimum(1)
        self._iter_choice.setMinimum(0)
        self._num_particles_label = QNumParticlesLabel()
        self._num_particles_label.setMaximumWidth(400)
        self._symmetry_label = QSymmetryLabel()
        header = QtW.QWidget()
        header_layout = QtW.QHBoxLayout(header)
        header_layout.setContentsMargins(1, 0, 1, 0)
        header_layout.addWidget(QtW.QLabel("<b>&#9679; Initial Model Map</b>"))
        header_layout.addWidget(self._symmetry_label)
        header.setMaximumWidth(400)

        self._layout.setSpacing(0)
        self._layout.addWidget(header)
        self._layout.addWidget(self._viewer)
        self._layout.addWidget(self._resizer)
        self._layout.addWidget(self._num_particles_label)
        _container = QtW.QWidget()
        _container.setMaximumWidth(400)
        hor_layout = QtW.QHBoxLayout(_container)
        hor_layout.addWidget(self._iter_choice)
        hor_layout.addWidget(self._class_choice)
        hor_layout.setContentsMargins(0, 0, 0, 0)
        self._layout.addWidget(_container)
        self._iter_choice.current_changed.connect(self._on_iter_changed)
        self._class_choice.valueChanged.connect(self._on_class_changed)
        self._index_start = 1
        self._iter_current_value = 0
        self._job_dir = _job_dir.InitialModel3DJobDirectory(job_dir.path)

    def on_job_updated(self, job_dir: _job_dir.InitialModel3DJobDirectory, path: str):
        """Handle changes to the job directory."""
        fp = Path(path)
        if fp.name.startswith("RELION_JOB_") or fp.suffix == ".mrc":
            self.initialize(job_dir)
            _LOGGER.debug("%s Updated", self._job_dir.job_number)

    def initialize(self, job_dir: _job_dir.InitialModel3DJobDirectory):
        """Initialize the viewer with the job directory."""
        nclasses = self._job_dir.num_classes()
        if nclasses == 0:
            return
        niter_list = self._job_dir.niter_list()
        _LOGGER.info("Job with %s classes", nclasses)
        self._class_choice.setMaximum(nclasses)
        self._iter_choice.set_choices(niter_list)
        self._iter_choice.setValue(self._iter_choice.maximum())
        self._on_iter_changed(self._iter_choice.value())
        self._viewer.auto_threshold()
        self._viewer.auto_fit()
        sym_name = self._job_dir.get_job_param("sym_name")
        self._symmetry_label.set_symmetry(sym_name)

    def _on_iter_changed(self, value: int):
        self._update_for_value(value, self._class_choice.value())

    def _on_class_changed(self, value: int):
        self._update_for_value(self._iter_choice.value(), value)

    def _update_for_value(self, niter: int, class_id: int = 1):
        if self._worker is not None and self._worker.is_running:
            self._worker.quit()
        self._worker = None
        self._worker = self._read_items(niter, class_id)
        self._start_worker()

    @thread_worker
    def _read_items(self, niter, class_id: int = 1):
        res = self._job_dir.get_result(niter)

        res = self._job_dir.get_result(niter)
        map0, _ = res.class_map(class_id - self._index_start)
        yield self._viewer.set_image, map0
        if self._num_particles_label.num_known():
            return
        starpath = self._job_dir.path / f"run_it{niter:0>3}_model.star"
        if not starpath.exists():
            yield self._num_particles_label.set_number, -1
            return
        try:
            model = ModelStarModel.validate_file(starpath)
            num_particles = model.groups.num_particles.sum()
        except Exception as e:
            num_particles = -1
            raise e
        yield self._num_particles_label.set_number, num_particles
