from pathlib import Path
import shutil
from typing import Any, Literal

from magicgui.widgets.bases import ValueWidget
from himena_relion._job_class import _Relion5BuiltinJob, parse_string
from himena_relion._job_dir import JobDirectory
from himena_relion import _configs, _annotated as _a
from himena_relion._utils import command_not_found_err_msg
from himena_relion.schemas import OptimisationSetModel
from himena_relion.consts import MenuId
from himena_relion._adapt import norm_blush_reg, norm_blush_reg_inv


class _Relion5Job(_Relion5BuiltinJob):
    @classmethod
    def command_palette_title_prefix(cls):
        return "RELION 5:"


class _Relion5SpaJob(_Relion5BuiltinJob):
    @classmethod
    def command_palette_title_prefix(cls):
        return "RELION 5 SPA:"


class _ImportMoviesJobBase(_Relion5SpaJob):
    """Import movies into RELION."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.import.movies"

    @classmethod
    def menu_id(cls) -> str:
        return MenuId.RELION_IMPORT_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_other"] = False
        kwargs["node_type"] = "Particle coordinates (*.box, *_pick.star)"
        kwargs["fn_in_other"] = ""
        kwargs["optics_group_particles"] = ""
        kwargs["do_raw"] = True
        kwargs["min_dedicated"] = 1
        kwargs["do_queue"] = False
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in [
            "fn_in_other", "do_other", "node_type", "optics_group_particles",
            "do_raw", "do_queue", "min_dedicated",
        ]:  # fmt: skip
            kwargs.pop(name, None)
        return kwargs


class ImportMoviesJob(_ImportMoviesJobBase):
    """Import movies for single particle analysis."""

    @classmethod
    def param_matches(cls, job_params):
        return (
            job_params.get("do_raw") == "Yes"
            and job_params.get("is_multiframe") == "Yes"
        )

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs["is_multiframe"] = True
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs.pop("is_multiframe", None)
        return super().normalize_kwargs_inv(**kwargs)

    def run(
        self,
        fn_in_raw: _a.import_.FN_IN_RAW = "",
        optics_group_name: _a.import_.OPTICS_GROUP_NAME = "opticsGroup1",
        fn_mtf: _a.import_.FN_MTF = "",
        angpix: _a.import_.ANGPIX = 1.4,
        kV: _a.import_.KV = 300,
        Cs: _a.import_.CS = 2.7,
        Q0: _a.import_.Q0 = 0.1,
        beamtilt_x: _a.import_.BEAM_TILT_X = 0,
        beamtilt_y: _a.import_.BEAM_TILT_Y = 0,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class ImportMicrographsJob(_ImportMoviesJobBase):
    """Import motion-corrected micrographs for single particle analysis."""

    @classmethod
    def param_matches(cls, job_params):
        return (
            job_params.get("do_raw") == "Yes"
            and job_params.get("is_multiframe") == "No"
        )

    @classmethod
    def job_title(cls):
        return "Import Micrographs"

    @classmethod
    def command_id(cls):
        return super().command_id() + "-micrographs"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs["is_multiframe"] = False
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs.pop("is_multiframe", None)
        return super().normalize_kwargs_inv(**kwargs)

    def run(
        self,
        fn_in_raw: _a.import_.FN_IN_RAW = "",
        optics_group_name: _a.import_.OPTICS_GROUP_NAME = "opticsGroup1",
        fn_mtf: _a.import_.FN_MTF = "",
        angpix: _a.import_.ANGPIX = 1.4,
        kV: _a.import_.KV = 300,
        Cs: _a.import_.CS = 2.7,
        Q0: _a.import_.Q0 = 0.1,
        beamtilt_x: _a.import_.BEAM_TILT_X = 0,
        beamtilt_y: _a.import_.BEAM_TILT_Y = 0,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class ImportOthersJob(_Relion5Job):
    @classmethod
    def type_label(cls) -> str:
        return "relion.import.other"

    @classmethod
    def menu_id(cls) -> str:
        return MenuId.RELION_IMPORT_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_other"] = True
        kwargs["do_raw"] = False
        kwargs["fn_in_raw"] = ""
        kwargs["is_multiframe"] = True
        kwargs["optics_group_name"] = "opticsGroup1"
        kwargs["fn_mtf"] = ""
        kwargs["angpix"] = 1.4
        kwargs["kV"] = 300
        kwargs["Cs"] = 2.7
        kwargs["Q0"] = 0.1
        kwargs["beamtilt_x"] = 0
        kwargs["beamtilt_y"] = 0
        kwargs["min_dedicated"] = 1
        kwargs["do_queue"] = False
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in [
            "fn_in_raw", "is_multiframe", "optics_group_name", "fn_mtf", "angpix", "kV",
            "Cs", "Q0", "beamtilt_x", "beamtilt_y", "do_other", "do_raw", "do_queue",
            "min_dedicated",
        ]:  # fmt: skip
            kwargs.pop(name, None)
        return kwargs

    def run(
        self,
        fn_in_other: _a.import_.FN_IN_OTHER = "",
        node_type: _a.import_.NODE_TYPE = "Particle coordinates (*.box, *_pick.star)",
        optics_group_particles: _a.import_.OPTICS_GROUP_PARTICLES = "",
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["node_type"].changed.connect
        def _on_node_type_changed(value: str):
            widgets["optics_group_particles"].enabled = value.startswith(
                "Particle coordinates"
            )

        _on_node_type_changed(widgets["node_type"].value)  # initialize


class _MotionCorrJobBase(_Relion5SpaJob):
    @classmethod
    def menu_id(cls) -> str:
        return MenuId.RELION_PREPROCESS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs["fn_motioncor2_exe"] = _configs.get_motioncor2_exe()
        if "patch" in kwargs:
            kwargs["patch_x"], kwargs["patch_y"] = kwargs.pop("patch")
        kwargs.setdefault("do_float16", False)
        kwargs.setdefault("other_motioncor2_args", "")
        kwargs.setdefault("group_for_ps", 4.0)
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs.pop("use_gpu", None)
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs.pop("fn_motioncor2_exe", None)
        kwargs["patch"] = (kwargs.pop("patch_x", 1), kwargs.pop("patch_y", 1))
        return super().normalize_kwargs_inv(**kwargs)


class MotionCorr2Job(_MotionCorrJobBase):
    """Motion correction using MotionCor2 (GPU)."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.motioncorr.motioncor2"

    @classmethod
    def job_title(cls):
        return "Motion Correction (MotionCor2)"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs["do_own_motioncor"] = False
        kwargs["do_save_ps"] = False
        kwargs["group_for_ps"] = 4
        kwargs["do_float16"] = False  # not supported
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("do_own_motioncor", None)
        kwargs.pop("do_save_ps", None)
        kwargs.pop("group_for_ps", None)
        kwargs.pop("do_float16", None)
        return kwargs

    def run(
        self,
        input_star_mics: _a.io.IN_MOVIES = "",
        first_frame_sum: _a.mcor.FIRST_FRAME_SUM = 1,
        last_frame_sum: _a.mcor.LAST_FRAME_SUM = -1,
        dose_per_frame: _a.mcor.DOSE_PER_FRAME = 1.0,
        pre_exposure: _a.mcor.PRE_EXPOSURE = 0.0,
        eer_grouping: _a.mcor.EER_FRAC = 32,
        do_dose_weighting: _a.mcor.DO_DOSE_WEIGHTING = True,
        # Motion correction
        bfactor: _a.mcor.BFACTOR = 150,
        group_frames: _a.mcor.GROUP_FRAMES = 1,
        bin_factor: _a.mcor.BIN_FACTOR = 1,
        fn_defect: _a.mcor.DEFECT_FILE = "",
        fn_gain_ref: _a.mcor.GAIN_REF = "",
        gain_rot: _a.mcor.GAIN_ROT = "No rotation (0)",
        gain_flip: _a.mcor.GAIN_FLIP = "No flipping (0)",
        patch: _a.mcor.PATCH = (1, 1),
        other_motioncor2_args: _a.mcor.OTHER_MOTIONCOR2_ARGS = "",
        gpu_ids: _a.compute.GPU_IDS = "0",
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def prerun_check(cls, **kwargs) -> None:
        if shutil.which(mcor2 := _configs.get_motioncor2_exe()) is None:
            raise ValueError(
                command_not_found_err_msg(f"MotionCor2 executable not found: {mcor2}")
            )


class MotionCorrOwnJob(_MotionCorrJobBase):
    """Motion correction using RELION's implementation (CPU)."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.motioncorr.own"

    @classmethod
    def job_title(cls):
        return "Motion Correction (RELION)"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs["do_own_motioncor"] = True
        kwargs["other_motioncor2_args"] = ""
        kwargs["gpu_ids"] = ""
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs.pop("gpu_ids", None)
        kwargs.pop("do_own_motioncor", None)
        kwargs.pop("other_motioncor2_args", None)
        return super().normalize_kwargs_inv(**kwargs)

    def run(
        self,
        input_star_mics: _a.io.IN_MOVIES = "",
        first_frame_sum: _a.mcor.FIRST_FRAME_SUM = 1,
        last_frame_sum: _a.mcor.LAST_FRAME_SUM = -1,
        dose_per_frame: _a.mcor.DOSE_PER_FRAME = 1.0,
        pre_exposure: _a.mcor.PRE_EXPOSURE = 0.0,
        eer_grouping: _a.mcor.EER_FRAC = 32,
        do_float16: _a.io.DO_F16 = True,
        do_dose_weighting: _a.mcor.DO_DOSE_WEIGHTING = True,
        do_save_noDW: _a.mcor.DO_SAVE_NO_DW = False,
        do_save_ps: _a.mcor.DO_SAVE_PS = True,
        group_for_ps: _a.mcor.SUM_EVERY_E = 4.0,
        # Motion correction
        bfactor: _a.mcor.BFACTOR = 150,
        group_frames: _a.mcor.GROUP_FRAMES = 1,
        bin_factor: _a.mcor.BIN_FACTOR = 1,
        fn_defect: _a.mcor.DEFECT_FILE = "",
        fn_gain_ref: _a.mcor.GAIN_REF = "",
        gain_rot: _a.mcor.GAIN_ROT = "No rotation (0)",
        gain_flip: _a.mcor.GAIN_FLIP = "No flipping (0)",
        patch: _a.mcor.PATCH = (1, 1),
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets: dict[str, ValueWidget]) -> None:
        @widgets["do_save_ps"].changed.connect
        def _on_save_ps(value: bool):
            widgets["group_for_ps"].enabled = value

        _on_save_ps(widgets["do_save_ps"].value)  # initialize


class CtfEstimationJob(_Relion5SpaJob):
    """Contrast transfer function (CTF) estimation using CTFFIND4."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.ctffind.ctffind4"

    @classmethod
    def menu_id(cls) -> str:
        return MenuId.RELION_PREPROCESS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs["fn_ctffind_exe"] = _configs.get_ctffind4_exe()
        if "phase_range" in kwargs:
            kwargs["phase_min"], kwargs["phase_max"], kwargs["phase_step"] = kwargs.pop(
                "phase_range"
            )
        if "dfrange" in kwargs:
            kwargs["dfmin"], kwargs["dfmax"], kwargs["dfstep"] = kwargs.pop("dfrange")
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs.pop("fn_ctffind_exe", None)
        kwargs["phase_range"] = (
            kwargs.pop("phase_min", 0),
            kwargs.pop("phase_max", 180),
            kwargs.pop("phase_step", 10),
        )
        kwargs["dfrange"] = (
            kwargs.pop("dfmin", 5000),
            kwargs.pop("dfmax", 50000),
            kwargs.pop("dfstep", 500),
        )
        return super().normalize_kwargs_inv(**kwargs)

    def run(
        self,
        # I/O
        input_star_mics: _a.io.IN_MICROGRAPHS = "",
        use_noDW: _a.ctffind.USE_NODW = False,
        do_phaseshift: _a.ctffind.DO_PHASESHIFT = False,
        phase_range: _a.ctffind.PHASE_RANGE = (0, 180, 10),
        dast: _a.ctffind.DAST = 100,
        # CTFFIND
        use_given_ps: _a.ctffind.USE_GIVEN_PS = True,
        slow_search: _a.ctffind.SLOW_SEARCH = False,
        ctf_win: _a.ctffind.CTF_WIN = -1,
        box: _a.ctffind.BOX = 512,
        resmax: _a.ctffind.RESMAX = 5,
        resmin: _a.ctffind.RESMIN = 30,
        dfrange: _a.ctffind.DFRANGE = (5000, 50000, 500),
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets: dict[str, ValueWidget]) -> None:
        @widgets["do_phaseshift"].changed.connect
        def _on_do_phaseshift_changed(value: bool):
            widgets["phase_range"].enabled = value

        widgets["phase_range"].enabled = False

    @classmethod
    def prerun_check(cls, **kwargs) -> None:
        if shutil.which(cmd := _configs.get_ctffind4_exe()) is None:
            raise ValueError(
                command_not_found_err_msg(f"CTFFind4 executable not found: {cmd}")
            )


class ManualPickJob(_Relion5SpaJob):
    """Manual particle picking."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.manualpick"

    @classmethod
    def menu_id(cls) -> str:
        return MenuId.RELION_PICK_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        filter_method = kwargs.pop("filter_method", "Band-pass")
        kwargs["do_topaz_denoise"] = filter_method == "Topaz"
        min_pick_fom = kwargs.get("minimum_pick_fom", None)
        kwargs["do_fom_threshold"] = min_pick_fom is not None
        if min_pick_fom is None:
            kwargs["minimum_pick_fom"] = 0
        for name in ["angpix", "highpass"]:
            if name in kwargs and kwargs[name] is None:
                kwargs[name] = -1
        # these are not used, but exist in the job options
        kwargs["do_queue"] = False
        kwargs["min_dedicated"] = 1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs["filter_method"] = (
            "Topaz" if kwargs.pop("do_topaz_denoise", False) else "Band-pass"
        )
        if kwargs.pop("do_fom_threshold", "No") == "No":
            kwargs["minimum_pick_fom"] = None
        for name in ["do_queue", "min_dedicated"]:
            kwargs.pop(name, None)
        for name in ["angpix", "highpass"]:
            if name in kwargs and float(kwargs[name]) < 0:
                kwargs[name] = None
        return kwargs

    def run(
        self,
        fn_in: _a.io.IN_MICROGRAPHS = "",
        do_startend: _a.manualpick.DO_STARTEND = False,
        minimum_pick_fom: _a.manualpick.MINIMUM_PICK_FOM = None,
        # Display
        diameter: _a.manualpick.DIAMETER = 100,
        micscale: _a.manualpick.MICSCALE = 0.2,
        sigma_contrast: _a.manualpick.SIGMA_CONTRAST = 3,
        white_val: _a.manualpick.WHITE_VAL = 0,
        black_val: _a.manualpick.BLACK_VAL = 0,
        angpix: _a.manualpick.ANGPIX = None,
        filter_method: _a.manualpick.FILTER_METHOD = "Band-pass",
        lowpass: _a.manualpick.LOWPASS = 20,
        highpass: _a.manualpick.HIGHPASS = None,
        # Colors
        do_color: _a.manualpick.DO_COLOR = False,
        color_label: _a.manualpick.COLOR_LABEL = "rlnAutopickFigureOfMerit",
        fn_color: _a.manualpick.FN_COLOR = "",
        blue_value: _a.manualpick.BLUE_VALUE = 0,
        red_value: _a.manualpick.RED_VALUE = 2,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["filter_method"].changed.connect
        def _on_filter_method_changed(value: str):
            widgets["lowpass"].enabled = value == "Band-pass"
            widgets["highpass"].enabled = value == "Band-pass"

        _on_filter_method_changed(widgets["filter_method"].value)  # initialize


class _AutoPickJob(_Relion5SpaJob):
    @classmethod
    def menu_id(cls) -> str:
        return MenuId.RELION_PICK_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["continue_manual"] = False
        if kwargs.get("topaz_model", None) is None:
            kwargs["topaz_model"] = ""
        for name in ["topaz_particle_diameter", "topaz_nr_particles"]:
            if kwargs.get(name, None) is None:
                kwargs[name] = -1
        # template pick
        for key, value in [
            ("do_refs", False),
            ("fn_refs_autopick", ""),
            ("do_ref3d", False),
            ("fn_ref3d_autopick", ""),
            ("ref3d_symmetry", "C1"),
            ("ref3d_sampling", "30 degrees"),
            ("lowpass", 20),
            ("psi_sampling_autopick", 5),
            ("do_invert_refs", True),
            ("do_ctf_autopick", True),
            ("do_ignore_first_ctfpeak_autopick", False),
            # LoG
            ("do_log", False),
            ("log_diam_min", 200),
            ("log_diam_max", 250),
            ("log_invert", False),
            ("log_maxres", 20),
            ("log_adjust_thr", 0),
            ("log_upper_thr", 999),
            # Topaz
            ("do_topaz", False),
            ("do_topaz_filaments", False),
            ("do_topaz_pick", False),
            ("do_topaz_train", False),
            ("do_topaz_train_parts", False),
            ("fn_topaz_exe", "relion_python_topaz"),
            ("topaz_filament_threshold", -5),
            ("topaz_hough_length", -1),
            ("topaz_model", ""),
            ("topaz_other_args", ""),
            ("topaz_train_parts", ""),
            ("topaz_train_picks", ""),
        ]:
            kwargs.setdefault(key, value)
        for key in ["highpass", "angpix_ref", "angpix"]:
            if kwargs.get(key, None) is None:
                kwargs[key] = -1

        # others
        kwargs["use_gpu"] = kwargs["gpu_ids"] != ""
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("use_gpu", None)
        for name in ["angpix_ref", "highpass", "angpix"]:
            if name in kwargs and float(kwargs[name]) < 0:
                kwargs[name] = None
        return kwargs


class AutoPickLogJob(_AutoPickJob):
    """Automatic particle picking using Laplacian of Gaussian filter."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.autopick.log"

    @classmethod
    def job_title(cls):
        return "LoG Pick"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs["gpu_ids"] = ""
        kwargs["do_log"] = True
        kwargs["minavgnoise_autopick"] = -999
        kwargs["maxstddevnoise_autopick"] = 1.1  # ignored in LoG picker
        kwargs["mindist_autopick"] = 100  # ignored in LoG picker
        kwargs["threshold_autopick"] = 0.05
        kwargs["shrink"] = 0
        kwargs = super().normalize_kwargs(**kwargs)
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        keys_to_pop = [
            "continue_manual", "minavgnoise_autopick", "do_log", "do_ref3d", "do_refs",
            "angpix_ref", "do_ctf_autopick", "do_ignore_first_ctfpeak_autopick",
            "do_invert_refs", "fn_ref3d_autopick", "fn_refs_autopick", "fn_topaz_exe",
            "highpass", "lowpass", "shrink", "psi_sampling_autopick", "ref3d_sampling",
            "ref3d_symmetry", "gpu_ids", "maxstddevnoise_autopick", "mindist_autopick",
            "threshold_autopick"
        ]  # fmt: skip
        for key in kwargs:
            if key.startswith(("do_topaz", "topaz_")):
                keys_to_pop.append(key)
        for key in keys_to_pop:
            kwargs.pop(key, None)
        return kwargs

    def run(
        self,
        fn_input_autopick: _a.io.IN_MICROGRAPHS = "",
        angpix: _a.autopick.ANGPIX = None,
        # Laplacian
        log_diam_min: _a.autopick.LOG_DIAM_MIN = 200,
        log_diam_max: _a.autopick.LOG_DIAM_MAX = 250,
        log_invert: _a.autopick.LOG_INVERT = False,
        log_maxres: _a.autopick.LOG_MAXRES = 20,
        log_adjust_thr: _a.autopick.LOG_ADJUST_THR = 0,
        log_upper_thr: _a.autopick.LOG_UPPER_THR = 999,
        # Autopicking
        do_write_fom_maps: _a.autopick.DO_WHITE_FOM_MAPS = False,
        do_read_fom_maps: _a.autopick.DO_READ_FOM_MAPS = False,
        # Helical
        do_pick_helical_segments: _a.autopick.DO_PICK_HELICAL_SEGMENTS = False,
        helical_tube_outer_diameter: _a.helix.HELICAL_TUBE_DIAMETER = 200,
        helical_tube_length_min: _a.autopick.HELICAL_TUBE_LENGTH_MIN = -1,
        helical_tube_kappa_max: _a.autopick.HELICAL_TUBE_KAPPA_MAX = 0.1,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_rise: _a.helix.HELICAL_RISE = -1,
        do_amyloid: _a.autopick.DO_AMYLOID = False,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets: dict[str, ValueWidget]) -> None:
        @widgets["do_pick_helical_segments"].changed.connect
        def _on_do_pick_helical_segments_changed(value: bool):
            for name in [
                "helical_tube_outer_diameter",
                "helical_tube_length_min",
                "helical_tube_kappa_max",
                "helical_nr_asu",
                "helical_rise",
                "do_amyloid",
            ]:
                widgets[name].enabled = value

        _on_do_pick_helical_segments_changed(widgets["do_pick_helical_segments"].value)


class AutoPickTemplate2DJob(_AutoPickJob):
    """Automatic particle picking using template matching."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.autopick.ref2d"

    @classmethod
    def job_title(cls):
        return "Template Pick (2D Reference)"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_refs"] = True
        kwargs["do_ref3d"] = False
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        keys_to_pop = [
            "continue_manual",
            "do_log",
            "do_ref3d",
            "do_refs",
            "fn_ref3d_autopick",
            "ref3d_sampling",
            "ref3d_symmetry",
            "fn_topaz_exe",
        ]
        for key in kwargs:
            if key.startswith(("do_topaz", "topaz_", "log_")):
                keys_to_pop.append(key)
        for key in keys_to_pop:
            kwargs.pop(key, None)
        return kwargs

    def run(
        self,
        fn_input_autopick: _a.io.IN_MICROGRAPHS = "",
        angpix: _a.autopick.ANGPIX = None,
        # References
        fn_refs_autopick: _a.autopick.FN_REFS_AUTOPICK = "",
        lowpass: _a.autopick.LOWPASS = 20,
        highpass: _a.autopick.HIGHPASS = None,
        angpix_ref: _a.autopick.ANGPIX_REF = None,
        psi_sampling_autopick: _a.autopick.PSI_SAMPLING_AUTOPICK = 5,
        do_invert_refs: _a.autopick.DO_INVERT_REFS = True,
        do_ctf_autopick: _a.autopick.DO_CTF_AUTOPICK = True,
        do_ignore_first_ctfpeak_autopick: _a.autopick.DO_IGNORE_FIRST_CTFPEAK_AUTOPICK = False,
        # Autopicking
        threshold_autopick: _a.autopick.THRESHOLD_AUTOPICK = 0.05,
        mindist_autopick: _a.autopick.MINDIST_AUTOPICK = 100,
        maxstddevnoise_autopick: _a.autopick.MAXSTDDEVNOISE_AUTOPICK = 1.1,
        minavgnoise_autopick: _a.autopick.MINAVGNOISE_AUOTPICK = -999,
        do_write_fom_maps: _a.autopick.DO_WHITE_FOM_MAPS = False,
        do_read_fom_maps: _a.autopick.DO_READ_FOM_MAPS = False,
        shrink: _a.autopick.SHRINK = 0,
        gpu_ids: _a.compute.GPU_IDS = "",
        # Helical
        do_pick_helical_segments: _a.autopick.DO_PICK_HELICAL_SEGMENTS = False,
        helical_tube_outer_diameter: _a.helix.HELICAL_TUBE_DIAMETER = 200,
        helical_tube_length_min: _a.autopick.HELICAL_TUBE_LENGTH_MIN = -1,
        helical_tube_kappa_max: _a.autopick.HELICAL_TUBE_KAPPA_MAX = 0.1,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_rise: _a.helix.HELICAL_RISE = -1,
        do_amyloid: _a.autopick.DO_AMYLOID = False,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        _autopick_helix_setup(widgets)


class AutoPickTemplate3DJob(_AutoPickJob):
    @classmethod
    def type_label(cls) -> str:
        return "relion.autopick.ref3d"

    @classmethod
    def job_title(cls):
        return "Template Pick (3D Reference)"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_refs"] = kwargs["do_ref3d"] = True
        kwargs["fn_refs_autopick"] = ""
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        keys_to_pop = [
            "continue_manual",
            "do_log",
            "do_ref3d",
            "do_refs",
            "log_upper_thr",
            "fn_topaz_exe",
            "fn_refs_autopick",
        ]
        for key in kwargs:
            if key.startswith(("do_topaz", "topaz_", "log_")):
                keys_to_pop.append(key)
        for key in keys_to_pop:
            kwargs.pop(key, None)
        return kwargs

    def run(
        self,
        fn_input_autopick: _a.io.IN_MICROGRAPHS = "",
        fn_ref3d_autopick: _a.io.REF_TYPE = "",
        angpix: _a.autopick.ANGPIX = None,
        # References
        ref3d_symmetry: _a.autopick.REF3D_SYMMETRY = "C1",
        ref3d_sampling: _a.autopick.REF3D_SAMPLING = "30 degrees",
        lowpass: _a.autopick.LOWPASS = 20,
        highpass: _a.autopick.HIGHPASS = None,
        angpix_ref: _a.autopick.ANGPIX_REF = None,
        psi_sampling_autopick: _a.autopick.PSI_SAMPLING_AUTOPICK = 5,
        do_invert_refs: _a.autopick.DO_INVERT_REFS = True,
        do_ctf_autopick: _a.autopick.DO_CTF_AUTOPICK = True,
        do_ignore_first_ctfpeak_autopick: _a.autopick.DO_IGNORE_FIRST_CTFPEAK_AUTOPICK = False,
        # Autopicking
        threshold_autopick: _a.autopick.THRESHOLD_AUTOPICK = 0.05,
        mindist_autopick: _a.autopick.MINDIST_AUTOPICK = 100,
        maxstddevnoise_autopick: _a.autopick.MAXSTDDEVNOISE_AUTOPICK = 1.1,
        minavgnoise_autopick: _a.autopick.MINAVGNOISE_AUOTPICK = -999,
        do_write_fom_maps: _a.autopick.DO_WHITE_FOM_MAPS = False,
        do_read_fom_maps: _a.autopick.DO_READ_FOM_MAPS = False,
        shrink: _a.autopick.SHRINK = 0,
        gpu_ids: _a.compute.GPU_IDS = "",
        # Helical
        do_pick_helical_segments: _a.autopick.DO_PICK_HELICAL_SEGMENTS = False,
        helical_tube_outer_diameter: _a.helix.HELICAL_TUBE_DIAMETER = 200,
        helical_tube_length_min: _a.autopick.HELICAL_TUBE_LENGTH_MIN = -1,
        helical_tube_kappa_max: _a.autopick.HELICAL_TUBE_KAPPA_MAX = 0.1,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_rise: _a.helix.HELICAL_RISE = -1,
        do_amyloid: _a.autopick.DO_AMYLOID = False,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        _autopick_helix_setup(widgets)


class AutoPickTopazTrain(_AutoPickJob):
    @classmethod
    def type_label(cls) -> str:
        return "relion.autopick.topaz.train"

    @classmethod
    def job_title(cls):
        return "Topaz Train"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_topaz"] = True
        kwargs["do_topaz_train"] = True
        kwargs["fn_topaz_exe"] = _configs.get_topaz_exe()
        if isinstance(kwargs["do_topaz_train_parts"], str):
            kwargs["do_topaz_train_parts"] = kwargs["do_topaz_train_parts"] == "Yes"
        do_parts = kwargs["do_topaz_train_parts"]
        # RELION 5 gives a very confusing error message here by default.
        if not do_parts and kwargs["topaz_train_picks"] == "":
            raise ValueError("Input picked coordinates for training must be provided")
        if do_parts and kwargs["topaz_train_parts"] == "":
            raise ValueError("Particles STAR file for training must be provided")
        kwargs["threshold_autopick"] = 0.05
        kwargs["mindist_autopick"] = 100
        kwargs["maxstddevnoise_autopick"] = 1.1
        kwargs["do_write_fom_maps"] = False
        kwargs["do_read_fom_maps"] = False
        kwargs["shrink"] = 0
        kwargs["do_pick_helical_segments"] = False
        kwargs["helical_tube_outer_diameter"] = 200
        kwargs["helical_tube_length_min"] = -1
        kwargs["helical_tube_kappa_max"] = 0.1
        kwargs["helical_nr_asu"] = 1
        kwargs["helical_rise"] = -1
        kwargs["do_amyloid"] = False
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("fn_topaz_exe", None)
        keys_to_pop = [
            "angpix_ref", "continue_manual", "do_ctf_autopick",
            "do_ignore_first_ctfpeak_autopick", "do_invert_refs", "do_log", "do_ref3d",
            "do_refs", "fn_ref3d_autopick", "fn_refs_autopick", "highpass", "lowpass",
            "minavgnoise_autopick", "psi_sampling_autopick", "ref3d_sampling",
            "ref3d_symmetry", "threshold_autopick", "mindist_autopick",
            "maxstddevnoise_autopick", "do_write_fom_maps", "do_read_fom_maps",
            "shrink", "do_pick_helical_segments", "do_amyloid", "do_topaz",
            "topaz_model", "do_topaz_filaments", "topaz_filament_threshold",
            "topaz_hough_length", "topaz_other_args", "do_topaz_train", "do_topaz_pick",

        ]  # fmt: skip
        for key in kwargs:
            if key.startswith(("log_", "helical_")):
                keys_to_pop.append(key)
        for key in keys_to_pop:
            kwargs.pop(key, None)
        return kwargs

    def run(
        self,
        fn_input_autopick: _a.io.IN_MICROGRAPHS = "",
        angpix: _a.autopick.ANGPIX = None,
        # Topaz
        topaz_particle_diameter: _a.autopick.TOPAZ_PARTICLE_DIAMETER = None,
        topaz_nr_particles: _a.autopick.TOPAZ_NR_PARTICLES = None,
        do_topaz_train_parts: _a.autopick.DO_TOPAZ_TRAIN_PARTS = False,
        topaz_train_picks: _a.autopick.TOPAZ_TRAIN_PICKS = "",
        topaz_train_parts: _a.autopick.TOPAZ_TRAIN_PARTS = "",
        # Autopicking
        gpu_ids: _a.compute.GPU_IDS = "",
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_topaz_train_parts"].changed.connect
        def _on_do_topaz_train_parts_changed(value: bool):
            widgets["topaz_train_parts"].enabled = value
            widgets["topaz_train_picks"].enabled = not value

        _on_do_topaz_train_parts_changed(widgets["do_topaz_train_parts"].value)

    @classmethod
    def prerun_check(cls, **kwargs) -> None:
        if shutil.which(cmd := _configs.get_topaz_exe()) is None:
            raise ValueError(
                command_not_found_err_msg(f"Topaz executable not found: {cmd}")
            )


class AutoPickTopazPick(_AutoPickJob):
    @classmethod
    def type_label(cls) -> str:
        return "relion.autopick.topaz.pick"

    @classmethod
    def job_title(cls):
        return "Topaz Pick"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_topaz"] = True
        kwargs["do_topaz_pick"] = True
        kwargs["fn_topaz_exe"] = _configs.get_topaz_exe()
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("fn_topaz_exe", None)
        keys_to_pop = [
            "angpix_ref", "continue_manual", "do_ctf_autopick",
            "do_ignore_first_ctfpeak_autopick", "do_invert_refs", "do_log", "do_ref3d",
            "do_refs", "fn_ref3d_autopick", "fn_refs_autopick", "highpass", "lowpass",
            "minavgnoise_autopick", "psi_sampling_autopick", "ref3d_sampling",
            "ref3d_symmetry",
        ]  # fmt: skip
        for key in kwargs:
            if key.startswith(("do_topaz", "topaz_", "log_")):
                keys_to_pop.append(key)
        for key in keys_to_pop:
            kwargs.pop(key, None)
        return kwargs

    def run(
        self,
        fn_input_autopick: _a.io.IN_MICROGRAPHS = "",
        angpix: _a.autopick.ANGPIX = None,
        # Topaz
        topaz_particle_diameter: _a.autopick.TOPAZ_PARTICLE_DIAMETER = None,
        topaz_model: _a.autopick.TOPAZ_MODEL = "",
        do_topaz_filaments: _a.autopick.DO_TOPAZ_FILAMENTS = False,
        topaz_filament_threshold: _a.autopick.TOPAZ_FILAMENT_THRESHOLD = -5,
        topaz_hough_length: _a.autopick.TOPAZ_HOUGH_LENGTH = -1,
        topaz_other_args: _a.autopick.TOPAZ_OTHER_ARGS = "",
        # Autopicking
        threshold_autopick: _a.autopick.THRESHOLD_AUTOPICK = 0.05,
        mindist_autopick: _a.autopick.MINDIST_AUTOPICK = 100,
        maxstddevnoise_autopick: _a.autopick.MAXSTDDEVNOISE_AUTOPICK = 1.1,
        do_write_fom_maps: _a.autopick.DO_WHITE_FOM_MAPS = False,
        do_read_fom_maps: _a.autopick.DO_READ_FOM_MAPS = False,
        shrink: _a.autopick.SHRINK = 0,
        gpu_ids: _a.compute.GPU_IDS = "",
        # Helical
        do_pick_helical_segments: _a.autopick.DO_PICK_HELICAL_SEGMENTS = False,
        helical_tube_outer_diameter: _a.helix.HELICAL_TUBE_DIAMETER = 200,
        helical_tube_length_min: _a.autopick.HELICAL_TUBE_LENGTH_MIN = -1,
        helical_tube_kappa_max: _a.autopick.HELICAL_TUBE_KAPPA_MAX = 0.1,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_rise: _a.helix.HELICAL_RISE = -1,
        do_amyloid: _a.autopick.DO_AMYLOID = False,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        _autopick_helix_setup(widgets)

        @widgets["do_topaz_filaments"].changed.connect
        def _on_do_topaz_filaments_changed(value: bool):
            for name in ["topaz_filament_threshold", "topaz_hough_length"]:
                if (widget := widgets.get(name, None)) is not None:
                    widget.enabled = value

        _on_do_topaz_filaments_changed(widgets["do_topaz_filaments"].value)

    @classmethod
    def prerun_check(cls, **kwargs) -> None:
        if shutil.which(cmd := _configs.get_topaz_exe()) is None:
            raise ValueError(
                command_not_found_err_msg(f"Topaz executable not found: {cmd}")
            )


class _ExtractJobBase(_Relion5SpaJob):
    @classmethod
    def menu_id(cls) -> str:
        return MenuId.RELION_EXTRACT_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)

        # common defaults
        for key, value in [
            ("star_mics", ""),
            ("coords_suffix", ""),
            ("do_reextract", False),
            ("fndata_reextract", ""),
            ("do_reset_offsets", False),
            ("do_recenter", True),
        ]:
            kwargs.setdefault(key, value)

        kwargs["recenter_x"], kwargs["recenter_y"], kwargs["recenter_z"] = (0, 0, 0)

        # normalize
        kwargs["do_fom_threshold"] = kwargs.get("minimum_pick_fom", None) is not None
        if kwargs.get("minimum_pick_fom", None) is None:
            kwargs["minimum_pick_fom"] = 0.0
        for name in ["bg_diameter", "white_dust", "black_dust"]:
            if kwargs.get(name, None) is None:
                kwargs[name] = -1
        if (_rescale := kwargs.get("rescale", None)) is None:
            kwargs["rescale"] = kwargs["extract_size"]
        kwargs["do_rescale"] = _rescale != kwargs["extract_size"]

        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        if kwargs.pop("do_fom_threshold", "No") == "No":
            kwargs["minimum_pick_fom"] = None
        if not kwargs.get("do_rescale", False):
            kwargs["rescale"] = None
        for name in ["bg_diameter", "white_dust", "black_dust"]:
            if float(kwargs.get(name, -1)) < 0:
                kwargs[name] = None
        return kwargs

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_extract_helix"].changed.connect
        def _on_do_extract_helix_changed(value: bool):
            for name in [
                "helical_tube_outer_diameter",
                "helical_bimodal_angular_priors",
                "do_extract_helical_tubes",
                "do_cut_into_segments",
                "helical_nr_asu",
                "helical_rise",
            ]:
                if (widget := widgets.get(name, None)) is not None:
                    widget.enabled = value

        _on_do_extract_helix_changed(widgets["do_extract_helix"].value)  # initialize


class ExtractJob(_ExtractJobBase):
    """Particle extraction from micrographs."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.extract"

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in [
            "fndata_reextract",
            "do_reset_offsets",
            "do_recenter",
            "recenter_x",
            "recenter_y",
            "recenter_z",
            "do_rescale",
            "do_reextract",
            "do_recenter",
        ]:
            kwargs.pop(name, None)
        return kwargs

    def run(
        self,
        # I/O
        star_mics: _a.io.IN_MICROGRAPHS = "",
        coords_suffix: _a.io.IN_COORDINATES = "",
        do_float16: _a.io.DO_F16 = True,
        # Extract
        extract_size: _a.extract.SIZE = 128,
        rescale: _a.extract.RESCALE = None,
        do_invert: _a.extract.DO_INVERT = True,
        do_norm: _a.extract.DO_NORM = True,
        bg_diameter: _a.extract.DIAMETER = None,
        white_dust: _a.extract.WIGHT_DUST = None,
        black_dust: _a.extract.BLACK_DUST = None,
        minimum_pick_fom: _a.extract.MINIMUM_PICK_FOM = None,
        # Helix
        do_extract_helix: _a.helix.DO_HELIX = False,
        helical_tube_outer_diameter: _a.helix.HELICAL_TUBE_DIAMETER = 200,
        helical_bimodal_angular_priors: _a.extract.HELICAL_BIMODAL_ANGULAR_PRIORS = True,
        do_extract_helical_tubes: _a.extract.DO_EXTRACT_HELICAL_TUBES = True,
        do_cut_into_segments: _a.extract.DO_CUT_INTO_SEGMENTS = True,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_rise: _a.helix.HELICAL_RISE = 1,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class ReExtractJob(_ExtractJobBase):
    """Particle re-extraction from micrographs."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.extract.reextract"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        recenter = kwargs.pop("recenter", (0.0, 0.0, 0.0))
        kwargs["recenter_x"], kwargs["recenter_y"], kwargs["recenter_z"] = recenter
        kwargs["do_reextract"] = True
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in ["coords_suffix", "do_rescale"]:
            kwargs.pop(name, None)
        kwargs["recenter"] = tuple(kwargs.pop(f"recenter_{x}", 0) for x in "xyz")
        kwargs.pop("do_reextract", None)
        return kwargs

    def run(
        self,
        # I/O
        star_mics: _a.io.IN_MICROGRAPHS = "",
        fndata_reextract: _a.io.IN_PARTICLES = "",
        do_reset_offsets: _a.extract.DO_RESET_OFFSET = False,
        do_recenter: _a.extract.DO_RECENTER = True,
        recenter: _a.extract.RECENTER = (0, 0, 0),
        do_float16: _a.io.DO_F16 = True,
        # Extract
        extract_size: _a.extract.SIZE = 128,
        rescale: _a.extract.RESCALE = None,
        do_invert: _a.extract.DO_INVERT = True,
        do_norm: _a.extract.DO_NORM = True,
        bg_diameter: _a.extract.DIAMETER = None,
        white_dust: _a.extract.WIGHT_DUST = None,
        black_dust: _a.extract.BLACK_DUST = None,
        minimum_pick_fom: _a.extract.MINIMUM_PICK_FOM = None,
        # Helix
        do_extract_helix: _a.helix.DO_HELIX = False,
        helical_tube_outer_diameter: _a.helix.HELICAL_TUBE_DIAMETER = 200,
        helical_bimodal_angular_priors: _a.extract.HELICAL_BIMODAL_ANGULAR_PRIORS = True,
        do_extract_helical_tubes: _a.extract.DO_EXTRACT_HELICAL_TUBES = True,
        do_cut_into_segments: _a.extract.DO_CUT_INTO_SEGMENTS = True,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_rise: _a.helix.HELICAL_RISE = 1,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class Class2DJob(_Relion5SpaJob):
    @classmethod
    def type_label(cls) -> str:
        return "relion.class2d"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_FILTER_PARTICLES_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["fn_cont"] = ""

        if "offset_range_step" in kwargs:
            rng, step = kwargs.pop("offset_range_step")
            kwargs["offset_range"], kwargs["offset_step"] = rng, step

        algo = kwargs.pop("algorithm")
        if algo["algorithm"] == "EM":
            kwargs["do_em"] = True
            kwargs["do_grad"] = False
            kwargs["nr_iter_em"] = algo["niter"]
            kwargs.setdefault("nr_iter_grad", 200)
        else:
            kwargs["do_em"] = False
            kwargs["do_grad"] = True
            kwargs["nr_iter_grad"] = algo["niter"]
            kwargs.setdefault("nr_iter_em", 25)
            # if int(kwargs.get("nr_mpi", 1)) > 1:
            #     # VDAM with MPI is not supported.
            #     warnings.warn(
            #         "MPI parallelisation is not supported with VDAM. Setting number of "
            #         "MPI processes to 1.",
            #         UserWarning,
            #     )
            #     kwargs["nr_mpi"] = 1
        if kwargs.get("highres_limit", None) is None:
            kwargs["highres_limit"] = -1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        nr_iter_em = kwargs.pop("nr_iter_em", 25)
        nr_iter_grad = kwargs.pop("nr_iter_grad", 200)
        if kwargs.pop("do_em", "No") == "Yes":
            kwargs["algorithm"] = {
                "algorithm": "EM",
                "niter": nr_iter_em,
            }
        else:
            kwargs["algorithm"] = {
                "algorithm": "VDAM",
                "niter": nr_iter_grad,
            }

        kwargs["offset_range_step"] = (
            kwargs.pop("offset_range", 5),
            kwargs.pop("offset_step", 1),
        )
        if "highres_limit" in kwargs and float(kwargs["highres_limit"]) < 0:
            kwargs["highres_limit"] = None
        # remove internal
        kwargs.pop("do_grad", None)
        kwargs.pop("fn_cont", None)
        return kwargs

    def run(
        self,
        # I/O
        fn_img: _a.io.IN_PARTICLES = "",
        # CTF
        do_ctf_correction: _a.misc.DO_CTF = True,
        ctf_intact_first_peak: _a.misc.IGNORE_CTF = False,
        # Optimisation
        nr_classes: _a.class_.NUM_CLASS = 50,
        tau_fudge: _a.misc.TAU_FUDGE = 2,
        algorithm: _a.class_.OPTIM_ALGORIGHM = {"algorithm": "VDAM", "niter": 200},
        particle_diameter: _a.misc.MASK_DIAMETER = 200,
        do_zero_mask: _a.misc.MASK_WITH_ZEROS = True,
        highres_limit: _a.class_.HIGH_RES_LIMIT = None,
        do_center: _a.class_.DO_CENTER = True,
        # Sampling
        dont_skip_align: _a.sampling.DONT_SKIP_ALIGN = True,
        psi_sampling: _a.class_.PSI_SAMPLING = 6,
        offset_range_step: _a.sampling.OFFSET_RANGE_STEP = (5, 1),
        allow_coarser: _a.sampling.ALLOW_COARSER_SAMPLING = False,
        # Helix
        do_helix: _a.class_.DO_HELIX = False,
        helical_tube_outer_diameter: _a.helix.HELICAL_TUBE_DIAMETER = 200,
        do_bimodal_psi: _a.class_.DO_BIMODAL_PSI = True,
        range_psi: _a.class_.RANGE_PSI = 6.0,
        do_restrict_xoff: _a.class_.DO_RESTRICT_XOFF = True,
        helical_rise: _a.helix.HELICAL_RISE = 4.75,
        # Compute
        do_parallel_discio: _a.compute.USE_PARALLEL_DISC_IO = True,
        nr_pool: _a.compute.NUM_POOL = 3,
        do_preread_images: _a.compute.DO_PREREAD = False,
        use_scratch: _a.compute.USE_SCRATCH = False,
        do_combine_thru_disc: _a.compute.DO_COMBINE_THRU_DISC = False,
        gpu_ids: _a.compute.GPU_IDS = "",
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_helix"].changed.connect
        def _on_do_helix_changed(value: bool):
            for name in [
                "helical_tube_outer_diameter",
                "do_bimodal_psi",
                "range_psi",
                "do_restrict_xoff",
                "helical_rise",
            ]:
                if (widget := widgets.get(name, None)) is not None:
                    widget.enabled = value

        _on_do_helix_changed(widgets["do_helix"].value)  # initialize


class InitialModelJob(_Relion5SpaJob):
    @classmethod
    def type_label(cls) -> str:
        return "relion.initialmodel"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_RECONSTRUCTION_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs["fn_cont"] = ""
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs.pop("fn_cont", None)
        return super().normalize_kwargs_inv(**kwargs)

    def run(
        self,
        fn_img: _a.io.IN_PARTICLES = None,
        # CTF
        do_ctf_correction: _a.misc.DO_CTF = True,
        ctf_intact_first_peak: _a.misc.IGNORE_CTF = False,
        # Optimisation
        nr_iter: _a.inimodel.NUM_ITER = 200,
        tau_fudge: _a.misc.TAU_FUDGE = 4,
        nr_classes: _a.inimodel.NUM_CLASS = 1,
        particle_diameter: _a.misc.MASK_DIAMETER = 200,
        do_solvent: _a.inimodel.DO_SOLVENT = True,
        sym_name: _a.inimodel.SYM_NAME = "C1",
        do_run_C1: _a.inimodel.DO_RUN_C1 = True,
        # Compute
        do_parallel_discio: _a.compute.USE_PARALLEL_DISC_IO = True,
        nr_pool: _a.compute.NUM_POOL = 3,
        do_preread_images: _a.compute.DO_PREREAD = False,
        use_scratch: _a.compute.USE_SCRATCH = False,
        do_combine_thru_disc: _a.compute.DO_COMBINE_THRU_DISC = False,
        gpu_ids: _a.compute.GPU_IDS = "",
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_ctf_correction"].changed.connect
        def _on_do_ctf_correction_changed(value: bool):
            widgets["ctf_intact_first_peak"].enabled = value

        widgets["ctf_intact_first_peak"].enabled = widgets["do_ctf_correction"].value
        # widgets["nr_mpi"].enabled = False  # VDAM does not support MPI


class _Class3DJobBase(_Relion5SpaJob):
    """3D classification."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.class3d"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_RECONSTRUCTION_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        if "helical_twist_range" in kwargs:
            (
                kwargs["helical_twist_min"],
                kwargs["helical_twist_max"],
                kwargs["helical_twist_inistep"],
            ) = kwargs.pop("helical_twist_range")
        if "helical_rise_range" in kwargs:
            (
                kwargs["helical_rise_min"],
                kwargs["helical_rise_max"],
                kwargs["helical_rise_inistep"],
            ) = kwargs.pop("helical_rise_range")
        if "rot_tilt_psi_range" in kwargs:
            kwargs["range_rot"], kwargs["range_tilt"], kwargs["range_psi"] = kwargs.pop(
                "rot_tilt_psi_range"
            )
        if "helical_tube_diameter_range" in kwargs:
            (
                kwargs["helical_tube_inner_diameter"],
                kwargs["helical_tube_outer_diameter"],
            ) = kwargs.pop("helical_tube_diameter_range")
        if "offset_range_step" in kwargs:
            kwargs["offset_range"], kwargs["offset_step"] = kwargs.pop(
                "offset_range_step"
            )
        kwargs["fn_cont"] = ""
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs["helical_twist_range"] = (
            kwargs.pop("helical_twist_min", 0),
            kwargs.pop("helical_twist_max", 0),
            kwargs.pop("helical_twist_inistep", 0),
        )
        kwargs["helical_rise_range"] = (
            kwargs.pop("helical_rise_min", 0),
            kwargs.pop("helical_rise_max", 0),
            kwargs.pop("helical_rise_inistep", 0),
        )
        kwargs["rot_tilt_psi_range"] = (
            kwargs.pop("range_rot", -1),
            kwargs.pop("range_tilt", 15),
            kwargs.pop("range_psi", 10),
        )
        kwargs["helical_tube_diameter_range"] = (
            kwargs.pop("helical_tube_inner_diameter", -1),
            kwargs.pop("helical_tube_outer_diameter", -1),
        )
        if "offset_range" in kwargs and "offset_step" in kwargs:
            kwargs["offset_range_step"] = (
                kwargs.pop("offset_range", 5),
                kwargs.pop("offset_step", 1),
            )
        kwargs.pop("fn_cont", None)
        return super().normalize_kwargs_inv(**kwargs)

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_ctf_correction"].changed.connect
        def _on_do_ctf_correction_changed(value: bool):
            widgets["ctf_intact_first_peak"].enabled = value

        _on_do_ctf_correction_changed(widgets["do_ctf_correction"].value)
        _setup_helix_params(widgets)
        # widgets["nr_mpi"].enabled = False  # VDAM does not support MPI


class Class3DNoAlignmentJob(_Class3DJobBase):
    @classmethod
    def command_id(cls):
        return super().command_id() + ".noalignment"

    @classmethod
    def param_matches(cls, job_params: dict[str, str]) -> bool:
        return job_params.get("dont_skip_align", "Yes") == "No"

    @classmethod
    def job_title(cls):
        return "3D Class (No Alignment)"

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        # force no alignment
        kwargs["dont_skip_align"] = False
        kwargs["highres_limit"] = -1
        kwargs["do_local_ang_searches"] = False
        kwargs["sampling"] = 0
        kwargs["relax_sym"] = ""
        kwargs["offset_range_step"] = (5, 1)
        kwargs["do_local_search_helical_symmetry"] = False
        kwargs["helical_twist_range"] = (0, 0, 0)
        kwargs["helical_rise_range"] = (0, 0, 0)
        kwargs["rot_tilt_psi_range"] = (-1, 15, 10)
        kwargs["sigma_angles"] = 5
        kwargs["allow_coarser"] = False
        kwargs["gpu_ids"] = ""
        kwargs = norm_blush_reg(kwargs)
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in [
            "dont_skip_align", "highres_limit", "sigma_angles", "offset_range_step",
            "relax_sym", "sampling", "do_local_ang_searches", "allow_coarser",
            "rot_tilt_psi_range", "do_local_search_helical_symmetry",
            "helical_twist_range", "helical_rise_range", "gpu_ids",
        ]:  # fmt: skip
            kwargs.pop(name, None)
        kwargs = norm_blush_reg_inv(kwargs)
        return kwargs

    def run(
        self,
        fn_img: _a.io.IN_PARTICLES = "",
        fn_ref: _a.io.REF_TYPE = "",
        fn_mask: _a.io.IN_MASK = "",
        # Reference
        ref_correct_greyscale: _a.misc.REF_CORRECT_GRAY = False,
        trust_ref_size: _a.misc.TRUST_REF_SIZE = True,
        ini_high: _a.misc.INITIAL_LOWPASS = 60,
        sym_name: _a.misc.REF_SYMMETRY = "C1",
        # CTF
        do_ctf_correction: _a.misc.DO_CTF = True,
        ctf_intact_first_peak: _a.misc.IGNORE_CTF = False,
        # Optimisation
        nr_classes: _a.class_.NUM_CLASS = 1,
        nr_iter: _a.class_.NUM_ITER = 25,
        tau_fudge: _a.misc.TAU_FUDGE = 1,
        particle_diameter: _a.misc.MASK_DIAMETER = 200,
        do_zero_mask: _a.misc.MASK_WITH_ZEROS = True,
        blush_reg: _a.misc.BLUSH_REGULARISATION = "No",
        # Helix
        do_helix: _a.helix.DO_HELIX = False,
        helical_tube_diameter_range: _a.helix.HELICAL_TUBE_DIAMETER_RANGE = (-1, -1),
        helical_range_distance: _a.helix.HELICAL_RANGE_DIST = -1,
        keep_tilt_prior_fixed: _a.helix.KEEP_TILT_PRIOR_FIXED = True,
        do_apply_helical_symmetry: _a.helix.DO_APPLY_HELICAL_SYMMETRY = True,
        helical_twist_initial: _a.helix.HELICAL_TWIST_INITIAL = 0,
        helical_rise_initial: _a.helix.HELICAL_RISE_INITIAL = 0,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_z_percentage: _a.helix.HELICAL_Z_PERCENTAGE = 30,
        # Compute
        do_fast_subsets: _a.compute.USE_FAST_SUBSET = False,
        do_parallel_discio: _a.compute.USE_PARALLEL_DISC_IO = True,
        use_scratch: _a.compute.USE_SCRATCH = False,
        nr_pool: _a.compute.NUM_POOL = 3,
        do_pad1: _a.compute.DO_PAD1 = False,
        do_preread_images: _a.compute.DO_PREREAD = False,
        do_combine_thru_disc: _a.compute.DO_COMBINE_THRU_DISC = False,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class Class3DJob(_Class3DJobBase):
    @classmethod
    def command_id(cls):
        return super().command_id() + ".alignment"

    @classmethod
    def param_matches(cls, job_params: dict[str, str]) -> bool:
        return job_params.get("dont_skip_align", "Yes") == "Yes"

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        # force alignment
        kwargs["dont_skip_align"] = True
        if kwargs.get("highres_limit", None) is None:
            kwargs["highres_limit"] = -1
        kwargs = norm_blush_reg(kwargs)
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("dont_skip_align", None)
        if "highres_limit" in kwargs and float(kwargs["highres_limit"]) < 0:
            kwargs["highres_limit"] = None
        kwargs = norm_blush_reg_inv(kwargs)
        return kwargs

    def run(
        self,
        fn_img: _a.io.IN_PARTICLES = "",
        fn_ref: _a.io.REF_TYPE = "",
        fn_mask: _a.io.IN_MASK = "",
        # Reference
        ref_correct_greyscale: _a.misc.REF_CORRECT_GRAY = False,
        trust_ref_size: _a.misc.TRUST_REF_SIZE = True,
        ini_high: _a.misc.INITIAL_LOWPASS = 60,
        sym_name: _a.misc.REF_SYMMETRY = "C1",
        # CTF
        do_ctf_correction: _a.misc.DO_CTF = True,
        ctf_intact_first_peak: _a.misc.IGNORE_CTF = False,
        # Optimisation
        nr_classes: _a.class_.NUM_CLASS = 1,
        nr_iter: _a.class_.NUM_ITER = 25,
        tau_fudge: _a.misc.TAU_FUDGE = 1,
        particle_diameter: _a.misc.MASK_DIAMETER = 200,
        do_zero_mask: _a.misc.MASK_WITH_ZEROS = True,
        highres_limit: _a.class_.HIGH_RES_LIMIT = None,
        blush_reg: _a.misc.BLUSH_REGULARISATION = "No",
        # Sampling
        sampling: _a.sampling.ANG_SAMPLING = "7.5 degrees",
        offset_range_step: _a.sampling.OFFSET_RANGE_STEP = (5, 1),
        do_local_ang_searches: _a.sampling.LOCAL_ANG_SEARCH = False,
        sigma_angles: _a.sampling.SIGMA_ANGLES = 5,
        relax_sym: _a.sampling.RELAX_SYMMETRY = "",
        allow_coarser: _a.sampling.ALLOW_COARSER_SAMPLING = False,
        # Helix
        do_helix: _a.helix.DO_HELIX = False,
        helical_tube_diameter_range: _a.helix.HELICAL_TUBE_DIAMETER_RANGE = (-1, -1),
        rot_tilt_psi_range: _a.helix.ROT_TILT_PSI_RANGE = (-1, 15, 10),
        helical_range_distance: _a.helix.HELICAL_RANGE_DIST = -1,
        keep_tilt_prior_fixed: _a.helix.KEEP_TILT_PRIOR_FIXED = True,
        do_apply_helical_symmetry: _a.helix.DO_APPLY_HELICAL_SYMMETRY = True,
        helical_twist_initial: _a.helix.HELICAL_TWIST_INITIAL = 0,
        helical_rise_initial: _a.helix.HELICAL_RISE_INITIAL = 0,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_z_percentage: _a.helix.HELICAL_Z_PERCENTAGE = 30,
        do_local_search_helical_symmetry: _a.helix.DO_LOCAL_SEARCH_H_SYM = False,
        helical_twist_range: _a.helix.HELICAL_TWIST_RANGE = (0, 0, 0),
        helical_rise_range: _a.helix.HELICAL_RISE_RANGE = (0, 0, 0),
        # Compute
        do_fast_subsets: _a.compute.USE_FAST_SUBSET = False,
        do_parallel_discio: _a.compute.USE_PARALLEL_DISC_IO = True,
        use_scratch: _a.compute.USE_SCRATCH = False,
        nr_pool: _a.compute.NUM_POOL = 3,
        do_pad1: _a.compute.DO_PAD1 = False,
        do_preread_images: _a.compute.DO_PREREAD = False,
        do_combine_thru_disc: _a.compute.DO_COMBINE_THRU_DISC = False,
        gpu_ids: _a.compute.GPU_IDS = "",
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        super().setup_widgets(widgets)

        @widgets["do_local_ang_searches"].changed.connect
        def _on_do_local_ang_searches_changed(value: bool):
            for name in ["sigma_angles", "relax_sym"]:
                if (widget := widgets.get(name, None)) is not None:
                    widget.enabled = value

        _on_do_local_ang_searches_changed(widgets["do_local_ang_searches"].value)


class Refine3DJob(_Relion5SpaJob):
    """3D auto-refinement of pre-aligned particles."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.refine3d"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_RECONSTRUCTION_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        if "helical_twist_range" in kwargs:
            (
                kwargs["helical_twist_min"],
                kwargs["helical_twist_max"],
                kwargs["helical_twist_inistep"],
            ) = kwargs.pop("helical_twist_range")
        if "helical_rise_range" in kwargs:
            (
                kwargs["helical_rise_min"],
                kwargs["helical_rise_max"],
                kwargs["helical_rise_inistep"],
            ) = kwargs.pop("helical_rise_range")
        if "rot_tilt_psi_range" in kwargs:
            kwargs["range_rot"], kwargs["range_tilt"], kwargs["range_psi"] = kwargs.pop(
                "rot_tilt_psi_range"
            )
        if "helical_tube_diameter_range" in kwargs:
            (
                kwargs["helical_tube_inner_diameter"],
                kwargs["helical_tube_outer_diameter"],
            ) = kwargs.pop("helical_tube_diameter_range")
        if "offset_range_step" in kwargs:
            kwargs["offset_range"], kwargs["offset_step"] = kwargs.pop(
                "offset_range_step"
            )
        kwargs["fn_cont"] = ""
        kwargs = norm_blush_reg(kwargs)
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs["helical_twist_range"] = (
            kwargs.pop("helical_twist_min", 0),
            kwargs.pop("helical_twist_max", 0),
            kwargs.pop("helical_twist_inistep", 0),
        )
        kwargs["helical_rise_range"] = (
            kwargs.pop("helical_rise_min", 0),
            kwargs.pop("helical_rise_max", 0),
            kwargs.pop("helical_rise_inistep", 0),
        )
        kwargs["rot_tilt_psi_range"] = (
            kwargs.pop("range_rot", -1),
            kwargs.pop("range_tilt", 15),
            kwargs.pop("range_psi", 10),
        )
        kwargs["helical_tube_diameter_range"] = (
            kwargs.pop("helical_tube_inner_diameter", -1),
            kwargs.pop("helical_tube_outer_diameter", -1),
        )
        kwargs["offset_range_step"] = (
            kwargs.pop("offset_range", 5),
            kwargs.pop("offset_step", 1),
        )
        kwargs.pop("fn_cont", None)
        kwargs = norm_blush_reg_inv(kwargs)
        return super().normalize_kwargs_inv(**kwargs)

    def run(
        self,
        fn_img: _a.io.IN_PARTICLES = "",
        fn_ref: _a.io.REF_TYPE = "",
        fn_mask: _a.io.IN_MASK = "",
        # Reference
        ref_correct_greyscale: _a.misc.REF_CORRECT_GRAY = False,
        trust_ref_size: _a.misc.TRUST_REF_SIZE = True,
        ini_high: _a.misc.INITIAL_LOWPASS = 60,
        sym_name: _a.misc.REF_SYMMETRY = "C1",
        # CTF
        do_ctf_correction: _a.misc.DO_CTF = True,
        ctf_intact_first_peak: _a.misc.IGNORE_CTF = False,
        # Optimisation
        particle_diameter: _a.misc.MASK_DIAMETER = 200,
        do_zero_mask: _a.misc.MASK_WITH_ZEROS = True,
        do_solvent_fsc: _a.misc.SOLVENT_FLATTEN_FSC = False,
        blush_reg: _a.misc.BLUSH_REGULARISATION = "No",
        # Sampling
        sampling: _a.sampling.ANG_SAMPLING = "7.5 degrees",
        offset_range_step: _a.sampling.OFFSET_RANGE_STEP = (5, 1),
        auto_local_sampling: _a.sampling.LOC_ANG_SAMPLING = "1.8 degrees",
        relax_sym: _a.sampling.RELAX_SYMMETRY = "",
        auto_faster: _a.sampling.AUTO_FASTER = False,
        # Helix
        do_helix: _a.helix.DO_HELIX = False,
        helical_tube_diameter_range: _a.helix.HELICAL_TUBE_DIAMETER_RANGE = (-1, -1),
        rot_tilt_psi_range: _a.helix.ROT_TILT_PSI_RANGE = (-1, 15, 10),
        helical_range_distance: _a.helix.HELICAL_RANGE_DIST = -1,
        keep_tilt_prior_fixed: _a.helix.KEEP_TILT_PRIOR_FIXED = True,
        do_apply_helical_symmetry: _a.helix.DO_APPLY_HELICAL_SYMMETRY = True,
        helical_nr_asu: _a.helix.HELICAL_NR_ASU = 1,
        helical_twist_initial: _a.helix.HELICAL_TWIST_INITIAL = 0,
        helical_rise_initial: _a.helix.HELICAL_RISE_INITIAL = 0,
        helical_z_percentage: _a.helix.HELICAL_Z_PERCENTAGE = 30,
        do_local_search_helical_symmetry: _a.helix.DO_LOCAL_SEARCH_H_SYM = False,
        helical_twist_range: _a.helix.HELICAL_TWIST_RANGE = (0, 0, 0),
        helical_rise_range: _a.helix.HELICAL_RISE_RANGE = (0, 0, 0),
        # Compute
        do_parallel_discio: _a.compute.USE_PARALLEL_DISC_IO = True,
        nr_pool: _a.compute.NUM_POOL = 3,
        use_scratch: _a.compute.USE_SCRATCH = False,
        do_pad1: _a.compute.DO_PAD1 = False,
        do_preread_images: _a.compute.DO_PREREAD = False,
        do_combine_thru_disc: _a.compute.DO_COMBINE_THRU_DISC = False,
        gpu_ids: _a.compute.GPU_IDS = "",
        # Running
        nr_mpi: _a.running.NR_MPI = 3,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_ctf_correction"].changed.connect
        def _on_do_ctf_correction_changed(value: bool):
            widgets["ctf_intact_first_peak"].enabled = value

        widgets["ctf_intact_first_peak"].enabled = widgets["do_ctf_correction"].value
        _setup_helix_params(widgets)


class MultiBodyJob(_Relion5SpaJob):
    """3D multibody refinement."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.multibody"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_REFINE_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs["fn_cont"] = ""
        if eigenval_range := kwargs.pop("eigenval_range", None):
            kwargs["eigenval_min"], kwargs["eigenval_max"] = eigenval_range
        kwargs = norm_blush_reg(kwargs)
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        eigenval_min = kwargs.pop("eigenval_min", -999)
        eigenval_max = kwargs.pop("eigenval_max", 999)
        kwargs["eigenval_range"] = (eigenval_min, eigenval_max)
        kwargs = norm_blush_reg_inv(kwargs)
        kwargs.pop("fn_cont", None)
        return super().normalize_kwargs_inv(**kwargs)

    def run(
        self,
        fn_in: _a.multibody.FN_IN = "",
        fn_bodies: _a.multibody.FN_BODIES = "",
        do_subtracted_bodies: _a.multibody.DO_SUBTRACTED_BODIES = True,
        blush_reg: _a.misc.BLUSH_REGULARISATION = "No",
        # Auto-sampling
        sampling: _a.multibody.SAMPING = "1.8 degrees",
        offset_range: _a.multibody.OFFSET_RANGE = 3,
        offset_step: _a.multibody.OFFSET_STEP = 0.75,
        # Analyse
        do_analyse: _a.multibody.DO_ANALYSE = True,
        nr_movies: _a.multibody.NR_MOVIES = 3,
        do_select: _a.multibody.DO_SELECT = False,
        select_eigenval: _a.multibody.SELECT_EIGENVAL = 1,
        eigenval_range: _a.multibody.EIGENVAL_RANGE = (-999, 999),
        # Compute
        do_parallel_discio: _a.compute.USE_PARALLEL_DISC_IO = True,
        nr_pool: _a.compute.NUM_POOL = 3,
        use_scratch: _a.compute.USE_SCRATCH = False,
        do_pad1: _a.compute.DO_PAD1 = False,
        do_preread_images: _a.compute.DO_PREREAD = False,
        do_combine_thru_disc: _a.compute.DO_COMBINE_THRU_DISC = False,
        gpu_ids: _a.compute.GPU_IDS = "",
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_select"].changed.connect
        def _on_do_select_changed(value: bool):
            widgets["select_eigenval"].enabled = value
            widgets["eigenval_range"].enabled = value

        _on_do_select_changed(widgets["do_select"].value)


class _SelectJob(_Relion5Job):
    @classmethod
    def type_label(cls):
        return "relion.select"

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        for name, default in [
            ("fn_model", ""),  # select class
            ("fn_mic", ""),  # select micrographs
            ("fn_data", ""),  # select particles
            ("do_class_ranker", False),
            ("do_discard", False),
            ("do_filaments", False),
            ("do_queue", False),
            ("do_random", False),
            ("do_recenter", False),
            ("do_regroup", False),
            ("do_select_values", False),
            ("do_split", False),
            ("do_remove_duplicates", False),
            ("select_label", "rlnCtfMaxResolution"),
            ("select_minval", -9999.0),
            ("select_maxval", 9999.0),
            ("duplicate_threshold", 30.0),
            ("image_angpix", -1.0),
            ("rank_threshold", 0.5),
            ("nr_groups", 1),
            ("dendrogram_threshold", 0.85),
            ("dendrogram_minclass", -1000),
            ("min_dedicated", 1),
            ("discard_label", "rlnImageName"),
            ("discard_sigma", 4),
        ]:
            kwargs.setdefault(name, default)

        # set unset integer/float params to -1
        for name in [
            "select_nr_parts", "select_nr_classes", "image_angpix", "split_size",
            "nr_split"
        ]:  # fmt: skip
            if kwargs.get(name, None) is None:
                kwargs[name] = -1
        return super().normalize_kwargs(**kwargs)

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        params = cls._signature().parameters
        for name in list(kwargs.keys()):
            if name not in params:
                kwargs.pop(name)
            if name in [
                "select_nr_parts", "select_nr_classes", "image_angpix", "split_size",
                "nr_split"
            ]:  # fmt: skip
                if name in kwargs and float(kwargs[name]) < 0:
                    kwargs[name] = None
        return kwargs


class SelectClassesInteractiveJob(_SelectJob):
    @classmethod
    def type_label(cls):
        return "relion.select.interactive"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_FILTER_PARTICLES_JOB

    def run(self, fn_model: _a.io.IN_OPTIMISER = ""):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def _search_parent_class3d(cls, path: Path) -> JobDirectory | None:
        job = JobDirectory(path)
        for p in job.parent_jobs():
            if p.job_type_label() == "relion.class3d":
                return p
        else:
            return None

    @classmethod
    def _search_mics(cls, path: Path) -> str | None:
        """Only used for inspect particles of tomo extension."""
        if job_class3d := cls._search_parent_class3d(path):
            params = job_class3d.get_job_params_as_dict()
            if opt_path := params.get("in_optimisation", None):
                opt_path = job_class3d.relion_project_dir / opt_path
                opt = OptimisationSetModel.validate_file(opt_path)
                return opt.tomogram_star
            elif in_tomo := params.get("in_tomograms", None):
                return in_tomo
        return None


class SelectClassesAutoJob(_SelectJob):
    @classmethod
    def type_label(cls):
        return "relion.select.class2dauto"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_FILTER_PARTICLES_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_class_ranker"] = True
        return super().normalize_kwargs(**kwargs)

    def run(
        self,
        fn_model: _a.io.IN_OPTIMISER = "",
        rank_threshold: _a.select.RANK_THRESHOLD = 0.5,
        select_nr_parts: _a.select.SELECT_NR_PARTS = None,
        select_nr_classes: _a.select.SELECT_NR_CLASSES = None,
        do_recenter: _a.select.DO_RECENTER = False,
        do_regroup: _a.select.DO_REGROUP = False,
        nr_groups: _a.select.NR_GROUPS = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class _SelectValuesJob(_SelectJob):
    @classmethod
    def type_label(cls):
        return "relion.select.onvalue"

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_select_values"] = True
        return super().normalize_kwargs(**kwargs)


class SelectParticlesJob(_SelectValuesJob):
    @classmethod
    def param_matches(cls, job_params):
        return job_params["fn_data"] != ""

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_FILTER_PARTICLES_JOB

    @classmethod
    def command_id(cls):
        return super().command_id() + "-particles"

    @classmethod
    def job_title(cls):
        return "Select Particles by Value"

    def run(
        self,
        fn_data: _a.io.IN_PARTICLES = "",
        select_label: _a.select.SELECT_LABEL = "rlnCtfMaxResolution",
        select_minval: _a.select.SELECT_MINVAL = -9999,
        select_maxval: _a.select.SELECT_MAXVAL = 9999,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class SelectMicrographsJob(_SelectValuesJob):
    @classmethod
    def menu_id(cls):
        return MenuId.RELION_PREPROCESS_JOB

    @classmethod
    def param_matches(cls, job_params):
        return job_params["fn_data"] == "" and job_params["fn_mic"]

    @classmethod
    def command_id(cls):
        return super().command_id() + "-micrographs"

    @classmethod
    def job_title(cls):
        return "Select Micrographs by Value"

    def run(
        self,
        fn_mic: _a.io.IN_MICROGRAPHS = "",
        select_label: _a.select.SELECT_LABEL = "rlnCtfMaxResolution",
        select_minval: _a.select.SELECT_MINVAL = -9999,
        select_maxval: _a.select.SELECT_MAXVAL = 9999,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class SelectRemoveDuplicatesJob(_SelectJob):
    """Remove duplicate particles based on their coordinates."""

    @classmethod
    def type_label(cls):
        return "relion.select.removeduplicates"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_FILTER_PARTICLES_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_remove_duplicates"] = True
        return kwargs

    def run(
        self,
        fn_data: _a.io.IN_PARTICLES = "",
        duplicate_threshold: _a.select.DUPLICATE_THRESHOLD = 30,
        image_angpix: _a.select.IMAGE_ANGPIX = None,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class SelectSplitJob(_SelectJob):
    """Split particles into subsets."""

    @classmethod
    def type_label(cls):
        return "relion.select.split"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_FILTER_PARTICLES_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_split"] = True
        if int(kwargs["split_size"]) < 0 and int(kwargs["nr_split"]) < 0:
            raise ValueError("Either split_size or nr_split must be set.")
        return kwargs

    def run(
        self,
        fn_data: _a.io.IN_PARTICLES = "",
        do_random: _a.select.DO_RANDOM = False,
        split_size: _a.select.SPLIT_SIZE = None,
        nr_split: _a.select.NR_SPLIT = None,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class SelectFilamentsJob(_SelectJob):
    @classmethod
    def type_label(cls):
        return "relion.select.filamentsdendrogram"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_FILTER_PARTICLES_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_filaments"] = True
        return kwargs

    def run(
        self,
        fn_model: _a.io.IN_OPTIMISER = "",
        dendrogram_threshold: _a.select.DENDROGRAM_THRESHOLD = 0.85,
        dendrogram_minclass: _a.select.DENDROGRAM_MINCLASS = -1000,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class MaskCreationJob(_Relion5Job):
    """Create a 3D mask from a reconstructed map."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.maskcreate"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_UTILS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        if kwargs.get("angpix", None) is None:
            kwargs["angpix"] = -1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        if float(kwargs.get("angpix", -1)) < 0:
            kwargs["angpix"] = None
        return kwargs

    def run(
        self,
        fn_in: _a.io.MAP_TYPE = "",
        lowpass_filter: _a.post.LOWPASS_FILTER = 15,
        angpix: _a.post.ANGPIX_MASK = None,
        inimask_threshold: _a.post.INIMASK_THRESHOLD = 0.02,
        extend_inimask: _a.post.EXTEND_INIMASK = 3,
        width_mask_edge: _a.post.WIDTH_MASK_EDGE = 3,
        do_helix: _a.helix.DO_HELIX = False,
        helical_z_percentage: _a.helix.HELICAL_Z_PERCENTAGE = 30,
        # Running
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_helix"].changed.connect
        def _on_helical(value: bool):
            widgets["helical_z_percentage"].enabled = value

        widgets["helical_z_percentage"].enabled = False


class PostProcessJob(_Relion5SpaJob):
    @classmethod
    def type_label(cls) -> str:
        return "relion.postprocess"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_POSTPROCESS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        b_factor = kwargs.pop("b_factor", {})
        assert isinstance(b_factor, dict), f"b_factor must be a dict, got {b_factor!r}"
        kwargs["do_auto_bfac"] = b_factor.get("do_auto_bfac", True)
        kwargs["autob_lowres"] = b_factor.get("autob_lowres", 10)
        kwargs["do_adhoc_bfac"] = b_factor.get("do_adhoc_bfac", False)
        kwargs["adhoc_bfac"] = b_factor.get("adhoc_bfac", -1000)
        if kwargs.get("angpix", None) is None:
            kwargs["angpix"] = -1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        do_auto_bfac = kwargs.pop("do_auto_bfac", True)
        autob_lowres = kwargs.pop("autob_lowres", 10)
        do_adhoc_bfac = kwargs.pop("do_adhoc_bfac", False)
        adhoc_bfac = kwargs.pop("adhoc_bfac", -1000)
        kwargs["b_factor"] = {
            "do_auto_bfac": parse_string(do_auto_bfac, bool),
            "autob_lowres": parse_string(autob_lowres, float),
            "do_adhoc_bfac": parse_string(do_adhoc_bfac, bool),
            "adhoc_bfac": parse_string(adhoc_bfac, float),
        }
        if float(kwargs.get("angpix", -1)) < 0:
            kwargs["angpix"] = None
        return kwargs

    def run(
        self,
        # I/O
        fn_in: _a.io.HALFMAP_TYPE = "",
        fn_mask: _a.io.IN_MASK = "",
        angpix: _a.post.ANGPIX_POST = None,
        # Sharpen
        b_factor: _a.misc.B_FACTOR = None,
        do_skip_fsc_weighting: _a.post.DO_SKIP_FSC_WEIGHTING = False,
        low_pass: _a.post.LOW_PASS = 5,
        fn_mtf: _a.post.FN_MTF = "",
        mtf_angpix: _a.post.MTF_ANGPIX = 1,
        # Running
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


FIT_CTF_CHOICES = Literal["No", "Per-micrograph", "Per-particle"]


class _CtfRefineJobBase(_Relion5SpaJob):
    _do_ctf_args = ("do_defocus", "do_astig", "do_bfactor", "do_phase")

    @classmethod
    def type_label(cls) -> str:
        return "relion.ctfrefine"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_REFINE_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_ctf"] = any(
            kwargs.get(name, "No") != "No" for name in cls._do_ctf_args
        )
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        do_ctf = kwargs.pop("do_ctf", False)
        if not do_ctf:
            for name in cls._do_ctf_args:
                kwargs[name] = "No"
        return kwargs


class CtfRefineJob(_CtfRefineJobBase):
    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_aniso_mag"] = False
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("do_aniso_mag", None)
        return kwargs

    def run(
        self,
        fn_data: _a.io.IN_PARTICLES = "",
        fn_post: _a.io.PROCESS_TYPE = "",
        # Fit
        do_defocus: _a.ctfrefine.DO_DEFOCUS = "Per-micrograph",
        do_astig: _a.ctfrefine.DO_ASTIG = "No",
        do_bfactor: _a.ctfrefine.DO_BFACTOR = "No",
        do_phase: _a.ctfrefine.DO_PHASE = "No",
        do_tilt: _a.ctfrefine.DO_TILT = False,
        do_trefoil: _a.ctfrefine.DO_TREFOIL = False,
        do_4thorder: _a.ctfrefine.DO_4THORDER = False,
        minres: _a.ctfrefine.MINRES = 30,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class CtfRefineAnisoMagJob(_CtfRefineJobBase):
    _not_used = ["do_ctf", "do_bfactor", "do_4thorder", "do_defocus",
        "do_tilt", "do_trefoil", "do_phase", "do_astig"]  # fmt: skip

    @classmethod
    def type_label(cls) -> str:
        return "relion.ctfrefine.anisomag"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_aniso_mag"] = True
        for name in cls._not_used:
            kwargs[name] = "No"
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in cls._not_used:
            kwargs.pop(name, None)
        kwargs.pop("do_aniso_mag", None)
        return kwargs

    def run(
        self,
        fn_data: _a.io.IN_PARTICLES = "",
        fn_post: _a.io.PROCESS_TYPE = "",
        # Fit
        minres: _a.ctfrefine.MINRES = 30,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class _JoinStarBase(_Relion5Job):
    @classmethod
    def menu_id(cls):
        return MenuId.RELION_UTILS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        for do in ["do_mic", "do_mov", "do_part"]:
            kwargs.setdefault(do, False)
        for i in [1, 2, 3, 4]:
            kwargs.setdefault(f"fn_mic{i}", "")
            kwargs.setdefault(f"fn_mov{i}", "")
            kwargs.setdefault(f"fn_part{i}", "")
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        params = cls._signature().parameters
        for do in ["do_mic", "do_mov", "do_part"]:
            if do not in params:
                kwargs.pop(do, None)
        for i in [1, 2, 3, 4]:
            for prefix in ["fn_mic", "fn_mov", "fn_part"]:
                if f"{prefix}{i}" not in params:
                    kwargs.pop(f"{prefix}{i}", None)
        return kwargs


class JoinParticlesJob(_JoinStarBase):
    """Join multiple particle star files into one."""

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_part"] = True
        return kwargs

    @classmethod
    def type_label(cls):
        return "relion.joinstar.particles"

    def run(
        self,
        fn_part1: _a.io.IN_PARTICLES = "",
        fn_part2: _a.io.IN_PARTICLES = "",
        fn_part3: _a.io.IN_PARTICLES = "",
        fn_part4: _a.io.IN_PARTICLES = "",
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class JoinMicrographsJob(_JoinStarBase):
    """Join multiple micrograph star files into one."""

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_mic"] = True
        return kwargs

    @classmethod
    def type_label(cls):
        return "relion.joinstar.micrographs"

    def run(
        self,
        fn_mic1: _a.io.IN_MICROGRAPHS = "",
        fn_mic2: _a.io.IN_MICROGRAPHS = "",
        fn_mic3: _a.io.IN_MICROGRAPHS = "",
        fn_mic4: _a.io.IN_MICROGRAPHS = "",
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class JoinMoviesJob(_JoinStarBase):
    """Join multiple movie star files into one."""

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_mov"] = True
        return kwargs

    @classmethod
    def type_label(cls):
        return "relion.joinstar.movies"

    def run(
        self,
        fn_mov1: _a.io.IN_MOVIES = "",
        fn_mov2: _a.io.IN_MOVIES = "",
        fn_mov3: _a.io.IN_MOVIES = "",
        fn_mov4: _a.io.IN_MOVIES = "",
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class _LocalResolutionJobBase(_Relion5Job):
    @classmethod
    def menu_id(cls):
        return MenuId.RELION_POSTPROCESS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["fn_resmap"] = _configs.get_resmap_exe()
        if kwargs.get("angpix", None) is None:
            kwargs["angpix"] = -1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("fn_resmap", None)
        kwargs.pop("do_relion_locres", None)
        kwargs.pop("do_resmap_locres", None)
        if float(kwargs.get("angpix", -1)) < 0:
            kwargs["angpix"] = None
        return kwargs


class LocalResolutionResmapJob(_LocalResolutionJobBase):
    """Local resolution estimation using ResMap."""

    @classmethod
    def type_label(cls):
        return "relion.localres.resmap"

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_resmap_locres"] = True
        kwargs["do_relion_locres"] = False
        kwargs["adhoc_bfac"] = -100
        kwargs["fn_mtf"] = ""
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in ["adhoc_bfac", "fn_mtf"]:
            kwargs.pop(name, None)
        return kwargs

    def run(
        self,
        fn_in: _a.io.HALFMAP_TYPE = "",
        fn_mask: _a.io.IN_MASK = "",
        angpix: _a.localres.ANGPIX = None,
        # ResMap parameters
        pval: _a.localres.PVAL = 0.05,
        minres: _a.localres.MINRES = 0,
        maxres: _a.localres.MAXRES = 0,
        stepres: _a.localres.STEPRES = 1,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def prerun_check(cls, **kwargs) -> None:
        if shutil.which(cmd := _configs.get_resmap_exe()) is None:
            raise ValueError(
                command_not_found_err_msg(f"ResMap executable not found: {cmd}")
            )


class LocalResolutionOwnJob(_LocalResolutionJobBase):
    """Local resolution estimation using RELION's own algorithm."""

    @classmethod
    def type_label(cls):
        return "relion.localres.own"

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_resmap_locres"] = False
        kwargs["do_relion_locres"] = True
        kwargs["maxres"] = 0
        kwargs["minres"] = 0
        kwargs["pval"] = 0.05
        kwargs["stepres"] = 1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in ["maxres", "minres", "pval", "stepres"]:
            kwargs.pop(name, None)
        return kwargs

    def run(
        self,
        fn_in: _a.io.HALFMAP_TYPE = "",
        fn_mask: _a.io.IN_MASK = "",
        angpix: _a.localres.ANGPIX = None,
        # Relion parameters
        adhoc_bfac: _a.localres.ADHOC_BFAC = -100,
        fn_mtf: _a.localres.FN_MTF = "",
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class ParticleSubtractionJob(_Relion5SpaJob):
    """Particle subtraction based on a 3D mask and a reference map."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.subtract"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_UTILS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["center_x"], kwargs["center_y"], kwargs["center_z"] = kwargs.pop(
            "center"
        )
        kwargs["do_data"] = kwargs["fn_data"].strip() != ""
        if kwargs["center_method"] == "Mask center":
            kwargs["do_center_mask"] = "Yes"
            kwargs["do_center_xyz"] = "No"
        elif kwargs["center_method"] == "User-defined":
            kwargs["do_center_mask"] = "No"
            kwargs["do_center_xyz"] = "Yes"
        else:
            kwargs["do_center_mask"] = "No"
            kwargs["do_center_xyz"] = "No"
        if kwargs.get("new_box", None) is None:
            kwargs["new_box"] = -1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs) -> dict[str, Any]:
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("do_data", None)
        center = (
            kwargs.pop("center_x", 0),
            kwargs.pop("center_y", 0),
            kwargs.pop("center_z", 0),
        )
        do_center_mask = kwargs.pop("do_center_mask", "Yes") == "Yes"
        do_center_xyz = kwargs.pop("do_center_xyz", "No") == "Yes"
        if do_center_mask:
            kwargs["center_method"] = "Mask center"
        elif do_center_xyz:
            kwargs["center_method"] = "User-defined"
            kwargs["center"] = center
        else:
            kwargs["center_method"] = "No"
        if "new_box" in kwargs and float(kwargs["new_box"]) < 0:
            kwargs["new_box"] = None
        return kwargs

    def run(
        self,
        fn_opt: _a.io.IN_OPTIMISER = "",
        fn_mask: _a.io.IN_MASK_SUBTRACT = "",
        fn_data: _a.io.IN_PARTICELS_SUBTRACT = "",
        do_float16: _a.io.DO_F16 = True,
        # Centering
        center_method: _a.misc.CENTER_METHOD = "No",
        center: _a.misc.CENTER = (0.0, 0.0, 0.0),
        new_box: _a.misc.NEW_BOX = None,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["center_method"].changed.connect
        def _on_center_method_changed(value: str):
            widgets["center"].enabled = value == "User-defined"

        _on_center_method_changed(widgets["center_method"].value == "User-defined")


class BayesianPolishTrainJob(_Relion5SpaJob):
    """Train Bayesian polishing model."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.polish.train"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_REFINE_JOB

    @classmethod
    def job_title(cls) -> str:
        return "Bayesian Polish (Train)"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_polish"] = False
        kwargs["do_float16"] = True
        kwargs["do_param_optim"] = True
        kwargs["do_own_params"] = True
        kwargs["opt_params"] = ""
        kwargs["sigma_vel"] = 0.2
        kwargs["sigma_div"] = 5000
        kwargs["sigma_acc"] = 2
        kwargs["minres"] = 20
        kwargs["maxres"] = -1
        for f in ["extract_size", "rescale"]:
            if f in kwargs and kwargs[f] is None:
                kwargs[f] = -1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in [
            "do_own_params", "opt_params", "sigma_vel", "sigma_div", "sigma_acc",
            "minres", "maxres", "do_polish", "do_param_optim", "do_float16",
        ]:  # fmt: skip
            kwargs.pop(name, None)
        for name in ["extract_size", "rescale"]:
            if name in kwargs and float(kwargs[name]) < 0:
                kwargs[name] = None
        return kwargs

    def run(
        self,
        # I/O
        fn_data: _a.io.IN_PARTICLES = "",
        fn_mic: _a.io.IN_MICROGRAPHS = "",
        fn_post: _a.io.PROCESS_TYPE = "",
        # TODO: do we need following parameters?
        first_frame: _a.polish.FIRST_FRAME = 1,
        last_frame: _a.polish.LAST_FRAME = -1,
        extract_size: _a.polish.EXTRACT_SIZE = None,
        rescale: _a.polish.RESCALE = None,
        # Train
        eval_frac: _a.polish.EVAL_FRAC = 0.5,
        optim_min_part: _a.polish.OPTIM_MIN_PART = 10000,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")


class BayesianPolishJob(_Relion5SpaJob):
    """Apply Bayesian polishing to particles."""

    @classmethod
    def type_label(cls) -> str:
        return "relion.polish"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_REFINE_JOB

    @classmethod
    def job_title(cls) -> str:
        return "Bayesian Polish"

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["do_polish"] = True
        kwargs["do_param_optim"] = False
        kwargs["eval_frac"] = 0.5
        kwargs["optim_min_part"] = 10000
        for f in ["extract_size", "rescale"]:
            if f in kwargs and kwargs[f] is None:
                kwargs[f] = -1
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        for name in ["do_polish", "do_param_optim", "eval_frac", "optim_min_part"]:
            kwargs.pop(name, None)
        for f in ["extract_size", "rescale"]:
            if f in kwargs and float(kwargs[f]) < 0:
                kwargs[f] = None
        return kwargs

    def run(
        self,
        # I/O
        fn_data: _a.io.IN_PARTICLES = "",
        fn_mic: _a.io.IN_MICROGRAPHS = "",
        fn_post: _a.io.PROCESS_TYPE = "",
        first_frame: _a.polish.FIRST_FRAME = 1,
        last_frame: _a.polish.LAST_FRAME = -1,
        extract_size: _a.polish.EXTRACT_SIZE = None,
        rescale: _a.polish.RESCALE = None,
        do_float16: _a.io.DO_F16 = True,
        # Polish
        do_own_params: _a.polish.DO_OWN_PARAMS = True,
        opt_params: _a.polish.OPT_PARAMS = "",
        sigma_vel: _a.polish.SIGMA_VEL = 0.2,
        sigma_div: _a.polish.SIGMA_DIV = 5000,
        sigma_acc: _a.polish.SIGMA_ACC = 2,
        minres: _a.polish.MINRES = 20,
        maxres: _a.polish.MAXRES = None,
        # Running
        nr_mpi: _a.running.NR_MPI = 1,
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_own_params"].changed.connect
        def _on_do_own_params_changed(value: bool):
            widgets["opt_params"].enabled = value
            widgets["sigma_vel"].enabled = not value
            widgets["sigma_div"].enabled = not value
            widgets["sigma_acc"].enabled = not value

        _on_do_own_params_changed(widgets["do_own_params"].value)


class DynaMightJob(_Relion5Job):
    """Run DynaMight for analysis of molecular motions and flexibility."""

    @classmethod
    def type_label(cls) -> str:
        return "dynamight"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_POSTPROCESS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["fn_dynamight_exe"] = _configs.get_dynamight_exe()
        kwargs["do_visualize"] = False
        kwargs["do_inverse"] = False
        kwargs["do_reconstruct"] = False
        kwargs["fn_checkpoint"] = ""
        kwargs["halfset"] = ""
        kwargs["do_store_deform"] = False
        kwargs["backproject_batchsize"] = 10
        kwargs["nr_epochs"] = 200
        if kwargs.get("initial_threshold", None) is None:
            kwargs["initial_threshold"] = ""
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("fn_dynamight_exe", None)
        if kwargs.get("initial_threshold", "") == "":
            kwargs["initial_threshold"] = None
        for name in [
            "do_visualize", "do_inverse", "do_reconstruct", "fn_checkpoint", "halfset",
            "do_store_deform", "backproject_batchsize", "nr_epochs",
        ]:  # fmt: skip
            kwargs.pop(name, None)
        return kwargs

    def run(
        self,
        # I/O
        fn_star: _a.dynamight.FN_STAR = "",
        fn_map: _a.dynamight.FN_MAP = "",
        nr_gaussians: _a.dynamight.NR_GAUSSIANS = 10000,
        initial_threshold: _a.dynamight.INITIAL_THRESHOLD = None,
        reg_factor: _a.dynamight.REG_FACTOR = 1,
        gpu_id: _a.dynamight.GPU_ID = 0,
        do_preload: _a.dynamight.DO_PRELOAD = False,
        # Running
        nr_threads: _a.running.NR_THREADS = 1,
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def prerun_check(cls, **kwargs) -> None:
        if shutil.which(cmd := _configs.get_dynamight_exe()) is None:
            raise ValueError(
                command_not_found_err_msg(f"DynaMight executable not found: {cmd}")
            )


class ModelAngeloJob(_Relion5Job):
    """ModelAngelo job placeholder."""

    @classmethod
    def type_label(cls) -> str:
        return "modelangelo"

    @classmethod
    def menu_id(cls):
        return MenuId.RELION_POSTPROCESS_JOB

    @classmethod
    def normalize_kwargs(cls, **kwargs):
        kwargs = super().normalize_kwargs(**kwargs)
        kwargs["fn_modelangelo_exe"] = _configs.get_modelangelo_exe()
        return kwargs

    @classmethod
    def normalize_kwargs_inv(cls, **kwargs):
        kwargs = super().normalize_kwargs_inv(**kwargs)
        kwargs.pop("fn_modelangelo_exe", None)
        return kwargs

    def run(
        self,
        # I/O
        fn_map: _a.modelangelo.FN_MAP = "",
        p_seq: _a.modelangelo.P_SEQ = "",
        d_seq: _a.modelangelo.D_SEQ = "",
        r_seq: _a.modelangelo.R_SEQ = "",
        # Compute
        gpu_id: _a.modelangelo.GPU_ID = 0,
        # HMMer
        do_hhmer: _a.modelangelo.DO_HHMER = False,
        fn_lib: _a.modelangelo.FN_LIB = "",
        alphabet: _a.modelangelo.ALPHABET = "amino",
        F1: _a.modelangelo.F1 = 10,
        F2: _a.modelangelo.F2 = 0.002,
        F3: _a.modelangelo.F3 = 1e-05,
        E: _a.modelangelo.E = 0.02,
        # Running
        do_queue: _a.running.DO_QUEUE = False,
        min_dedicated: _a.running.MIN_DEDICATED = 1,
    ):
        raise NotImplementedError("This is a builtin job placeholder.")

    @classmethod
    def setup_widgets(cls, widgets):
        @widgets["do_hhmer"].changed.connect
        def _on_do_hhmer_changed(value: bool):
            for name in ["fn_lib", "alphabet", "F1", "F2", "F3", "E"]:
                widgets[name].enabled = value

        _on_do_hhmer_changed(widgets["do_hhmer"].value)

    @classmethod
    def prerun_check(cls, **kwargs) -> None:
        if shutil.which(cmd := _configs.get_modelangelo_exe()) is None:
            raise ValueError(
                command_not_found_err_msg(f"ModelAngelo executable not found: {cmd}")
            )


def _autopick_helix_setup(widgets: dict[str, ValueWidget]) -> None:
    @widgets["do_pick_helical_segments"].changed.connect
    def _on_do_pick_helical_segments_changed(value: bool):
        widgets["helical_tube_outer_diameter"].enabled = value
        widgets["helical_tube_length_min"].enabled = value
        widgets["helical_tube_kappa_max"].enabled = value
        widgets["helical_nr_asu"].enabled = value
        widgets["helical_rise"].enabled = value
        widgets["do_amyloid"].enabled = value

    _on_do_pick_helical_segments_changed(widgets["do_pick_helical_segments"].value)


def _setup_helix_params(widgets: dict[str, ValueWidget]) -> None:
    helical_names = [
        "helical_tube_diameter_range",
        "rot_tilt_psi_range",
        "do_apply_helical_symmetry",
        "do_local_search_helical_symmetry",
        "helical_range_distance",
        "helical_twist_initial",
        "helical_twist_range",
        "helical_rise_initial",
        "helical_rise_range",
        "helical_nr_asu",
        "helical_z_percentage",
        "keep_tilt_prior_fixed",
    ]

    @widgets["do_helix"].changed.connect
    def _on_helical(value: bool):
        for name in helical_names:
            widgets[name].enabled = value
        if "do_local_search_helical_symmetry" in widgets:
            _on_do_local_search_helical_symmetry(
                widgets["do_local_search_helical_symmetry"].value
            )

    for name in helical_names:
        if name in widgets:
            widgets[name].enabled = False

    if "do_local_search_helical_symmetry" in widgets:

        @widgets["do_local_search_helical_symmetry"].changed.connect
        def _on_do_local_search_helical_symmetry(value: bool):
            if "helical_twist_range" in widgets:
                widgets["helical_twist_range"].enabled = value
            if "helical_rise_range" in widgets:
                widgets["helical_rise_range"].enabled = value

    if "helical_twist_range" in widgets:
        widgets["helical_twist_range"].enabled = False
    if "helical_rise_range" in widgets:
        widgets["helical_rise_range"].enabled = False
