from __future__ import annotations
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Literal, NamedTuple
from himena import StandardType, WidgetDataModel
import numpy as np
from numpy.typing import NDArray
from qtpy import QtWidgets as QtW, QtCore, QtGui
from superqt import ensure_main_thread
from vispy.color import ColorArray
from vispy.scene.visuals import Rectangle
from himena.widgets import current_instance
from himena.qt._qlineedit import QIntLineEdit, QDoubleLineEdit
from himena.qt.magicgui import ToggleButtons
from himena.plugins import validate_protocol
from himena._utils import doc_to_whats_this
from himena_builtins.qt.widgets._shared import labeled
from himena_builtins.qt.widgets._image_components import (
    QHistogramView,
    QAutoContrastButton,
)

from himena_relion._image_readers import ArrayFilteredView
from himena_relion._widgets._spinbox import QIntWidget
from himena_relion._widgets._vispy import (
    Vispy2DViewer,
    Vispy3DViewer,
    Vispy3DTomogramViewer,
    IsoSurface,
)
from himena_relion import _utils


class SliceResult(NamedTuple):
    image: NDArray[np.float32]
    clim: tuple[float, float]
    points: NDArray[np.float32]
    sizes: NDArray[np.float32]
    face_colors: NDArray[np.float32]
    edge_colors: NDArray[np.float32]


class QViewer(QtW.QWidget):
    _always_force_sync: bool = False  # for testing

    def set_background_color(self, color):
        self._canvas._scene.bgcolor = color

    def _show_usage(self):
        current_instance()._backend_main_window._add_whats_this(
            doc_to_whats_this(self.__doc__), style="markdown"
        )

    def _make_context_menu(self):
        menu = QtW.QMenu(self)
        menu.addAction("Usage", self._show_usage)
        menu.addAction("Auto Fit", lambda: self.auto_fit())
        menu.addAction("Copy Screenshot", self._canvas.copy_screenshot)
        menu.addAction("Save Screenshot", self._canvas.save_screenshot)
        return menu

    def _show_context_menu(self):
        menu = self._make_context_menu()
        pos = menu.mapFromGlobal(QtGui.QCursor.pos())
        menu.exec(pos)


class Q2DViewerBase(QViewer):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._canvas = Vispy2DViewer(self)
        self._canvas._scene.bgcolor = "#242424"
        self._canvas._viewbox.border_color = "#4A4A4A"
        self._canvas.right_clicked.connect(self._show_context_menu)

    def auto_fit(self):
        """Automatically fit the camera to the image."""
        self._canvas.auto_fit()
        self._canvas.update_canvas()

    def _show_context_menu(self):
        menu = self._make_context_menu()
        pos = menu.mapFromGlobal(QtGui.QCursor.pos())
        menu.exec(pos)


class Q2DSimpleViewer(Q2DViewerBase):
    """A 2D viewer for displaying a static 2D image."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._border_rect = None
        layout = QtW.QVBoxLayout(self)
        layout.addWidget(self._canvas.native)
        self._canvas.markers_visual.scaling = False

    def set_image(self, image: np.ndarray | None, cmap: str = "gray", clim=None):
        self._canvas.image = image
        self._canvas._image.cmap = cmap
        if clim is not None:
            self._canvas.contrast_limits = clim

    def set_points(
        self,
        points_xy: np.ndarray,
        size: float = 12.0,
        face_color="lime",
        edge_color="black",
    ):
        face_colors = _norm_color(face_color, len(points_xy))
        edge_colors = _norm_color(edge_color, len(points_xy))
        if points_xy.shape[0] > 0:
            self._canvas.markers_visual.set_data(
                points_xy,
                face_color=face_colors,
                edge_color=edge_colors,
                edge_width_rel=0.1 * self.devicePixelRatioF(),
                size=size / self.devicePixelRatioF(),
            )
            self._canvas.markers_visual.visible = True
        else:
            self._canvas.markers_visual.set_data(
                np.ones((1, 2), dtype=np.float32),
                face_color=np.zeros(4),
                edge_color=np.zeros(4),
                size=0.01,
            )
            self._canvas.markers_visual.visible = False
        self._canvas.update_canvas()

    def set_border(self, shape: tuple[int, int]):
        if self._border_rect is not None:
            self._border_rect.parent = None
        self._border_rect = Rectangle(
            center=(shape[1] / 2 - 0.5, shape[0] / 2 - 0.5),
            color="#00000000",
            border_color="gray",
            height=shape[0],
            width=shape[1],
            parent=self._canvas._viewbox.scene,
        )
        self._border_rect.set_gl_state("additive")

    def auto_fit(self):
        """Automatically fit the camera to the image."""
        if self._border_rect:
            self._canvas._viewbox.camera.set_range(
                x=(-0.5, self._border_rect.width - 0.5),
                y=(-0.5, self._border_rect.height - 0.5),
            )
        else:
            self._canvas.auto_fit()
        self._canvas.update_canvas()


class Q2DViewer(Q2DViewerBase):
    """2D Viewer.

    ## Mouse interactions:

    - Left drag ... pan
    - Right drag ... zoom
    - Wheel ... zoom
    """

    _executor = ThreadPoolExecutor(max_workers=2)

    def __init__(self, zlabel: str = "z", parent=None):
        super().__init__(parent)
        self._last_future: Future[SliceResult] | None = None
        self._last_clim: tuple[float, float] | None = None
        self._canvas.native.setMinimumSize(200, 200)
        layout = QtW.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._canvas.native)
        layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignHCenter)
        self._array_view = None
        self._points = np.empty((0, 3), dtype=np.float32)
        self._point_size = 12.0
        self._face_colors = np.zeros((0, 4), dtype=np.float32)
        self._edge_colors = np.zeros((0, 4), dtype=np.float32)
        self._dims_slider = QtW.QSlider(QtCore.Qt.Orientation.Horizontal, self)
        self._dims_slider.setMaximum(0)
        self._dims_slider.setMinimumWidth(150)
        self._histogram_view = QHistogramView()
        self._histogram_view.clim_changed.connect(self._on_clim_changed)
        self._histogram_view.setFixedHeight(32)
        self._histogram_view.setValueFormat(".2f", always_show=True)
        self._auto_contrast_btn = QAutoContrastButton(self._auto_contrast)
        self._auto_contrast_btn.qminmax = (0.0001, 0.9999)
        self._auto_contrast_btn.update_color("gray")
        self._zpos_box = QIntWidget("", label_width=0)
        self._zpos_box.valueChanged.connect(self._on_zpos_box_changed)
        self._zpos_box.setFixedWidth(90)
        self._zpos_box.setMaximum(0)
        self._dims_slider_widget = labeled(zlabel, self._dims_slider, self._zpos_box)
        layout.addWidget(self._dims_slider_widget)
        hlayout = QtW.QHBoxLayout()
        hlayout.addWidget(self._auto_contrast_btn)
        hlayout.addWidget(self._histogram_view)
        hlayout.setContentsMargins(8, 0, 8, 0)
        layout.addLayout(hlayout)
        self._dims_slider.valueChanged.connect(self._on_slider_changed)
        self._out_of_slice = True

    def clear(self):
        self._array_view = None
        self._points = np.empty((0, 3), dtype=np.float32)
        self.redraw()

    @property
    def has_image(self) -> bool:
        return self._array_view is not None

    def set_array_view(
        self,
        image: np.ndarray | ArrayFilteredView,
        clim: tuple[float, float] | None = None,
    ):
        """Set the 3D image to be displayed."""
        had_image = self.has_image
        if isinstance(image, np.ndarray):
            self._array_view = ArrayFilteredView.from_array(image)
        elif isinstance(image, ArrayFilteredView):
            self._array_view = image
        else:
            raise TypeError("image must be a numpy array or ArrayFilteredView.")
        self._last_clim = clim
        num_slices = self._array_view.num_slices()
        with QtCore.QSignalBlocker(self._dims_slider):
            self._dims_slider_widget.setVisible(bool(num_slices > 1))
            self._dims_slider.setRange(0, num_slices - 1)
            self._dims_slider.setValue(num_slices // 2)
            self._zpos_box.setRange(0, num_slices - 1)
            self.redraw()
        if not had_image:
            self._auto_contrast(force_update_view_range=True)
            self.auto_fit()
            m0, m1 = self._histogram_view._minmax
            fmt = _format_for_minmax(m0, m1)
            self._histogram_view.setValueFormat(fmt, always_show=True)

    def set_points(
        self,
        points: np.ndarray,
        out_of_slice: bool = True,
        size: float | None = None,
        face_color: NDArray[np.float32] = [0, 0, 0, 0],
        edge_color: NDArray[np.float32] = "lime",
    ):
        """Set the 3D points to be displayed.

        Parameters
        ----------
        points : (N, 3) array
            The 3D points (ZYX order) to be displayed.
        out_of_slice : bool
            Whether to show points that are out of the current slice as smaller symbols.
        size : float | None
            The size of the points. If None, the previous size is used.
        face_color : (4,) or (N, 4) array-like
            The face color of the points.
        edge_color : (4,) or (N, 4) array-like
            The edge color of the points.
        """
        self._points = points
        self._out_of_slice = out_of_slice
        self._face_colors = _norm_color(face_color, len(points))
        self._edge_colors = _norm_color(edge_color, len(points))
        if size is not None:
            self._point_size = size

    def redraw(self):
        self._on_slider_changed(self._dims_slider.value(), force_sync=True)

    def _on_zpos_box_changed(self, value: int):
        """Update the slider when the z position box changes."""
        with QtCore.QSignalBlocker(self._zpos_box):
            self._dims_slider.setValue(value)

    def _on_slider_changed(self, value: int, *, force_sync: bool = False):
        """Update the displayed slice based on the slider value."""
        self._zpos_box.setValue(value)
        if self._last_future:
            self._last_future.cancel()  # cancel last task
        if self._array_view is not None:
            if force_sync or self._always_force_sync:
                val = self._get_image_slice(value)
                future = Future()
                future.set_result(val)
                self._on_calc_slice_done(future)
            else:
                self._last_future = self._executor.submit(self._get_image_slice, value)
                self._last_future.add_done_callback(self._on_calc_slice_done)
        else:
            self._canvas.image = np.zeros((0, 0), dtype=np.float32)
            self._histogram_view.set_hist_for_array(
                np.zeros((2, 2), dtype=np.float32), (0.0, 1.0)
            )

    def _get_image_slice(self, slider_value: int) -> SliceResult | None:
        try:
            _sliced = self._array_view.get_slice(slider_value)
        except Exception:
            # This may happen if the image is being written in another thread so the
            # header size and the actual data size are inconsistent.
            return None
        slice_image = np.asarray(_sliced)
        if self._last_clim is None:
            min_ = slice_image.min()
            max_ = slice_image.max()
            self._last_clim = (min_, max_)
        else:
            min_, max_ = self._last_clim

        point_size = self._point_size_normed()
        if self._dims_slider.isVisible():
            zs = self._points[:, 0]
            thickness = point_size if self._out_of_slice else 0.01
            zdiff = zs - slider_value
            mask = np.abs(zdiff) < thickness / 2
            sizes = np.sqrt(point_size**2 - (zdiff[mask] * 2) ** 2)
        else:
            mask = slice(None)
            sizes = point_size
        return SliceResult(
            slice_image,
            (min_, max_),
            points=self._points[mask],
            sizes=sizes,
            face_colors=self._face_colors[mask],
            edge_colors=self._edge_colors[mask],
        )

    @ensure_main_thread
    def _on_calc_slice_done(self, future: Future[SliceResult | None]):
        self._last_future = None
        if future.cancelled():
            return
        result = future.result()
        if result is None:
            return
        self._histogram_view.set_hist_for_array(result.image, result.clim)
        self._canvas.image = result.image
        self._canvas.contrast_limits = result.clim
        self._last_clim = result.clim
        if result.points.shape[0] > 0:
            if result.points.shape[1] == 3:
                pos = result.points[:, [2, 1]]
            elif result.points.shape[1] == 2:
                pos = result.points[:, ::-1]
            else:
                raise ValueError("Points array must have shape (N, 2) or (N, 3).")
            self._canvas.markers_visual.set_data(
                pos,
                face_color=result.face_colors,
                edge_color=result.edge_colors,
                edge_width_rel=0.1 * self.devicePixelRatioF(),
                size=result.sizes,
            )
            self._canvas.markers_visual.visible = True
        else:
            self._canvas.markers_visual.set_data(
                np.ones((1, 2), dtype=np.float32),
                face_color=np.zeros(4),
                edge_color=np.zeros(4),
                size=self._point_size_normed(),
            )
            self._canvas.markers_visual.visible = False
        self._canvas.update_canvas()

    def _point_size_normed(self) -> float:
        # vispy point size is not scaled by device pixel ratio.
        return self._point_size / self.devicePixelRatioF()

    def _auto_contrast(self, *, force_update_view_range: bool = False):
        """Automatically adjust the contrast based on the histogram."""
        auto_contrast_by_hist(
            self._histogram_view,
            self._auto_contrast_btn.qminmax,
            force_update_view_range=force_update_view_range,
        )

    def _on_clim_changed(self, clim: tuple[float, float]):
        """Update the contrast limits based on the histogram view."""
        self._canvas.contrast_limits = clim
        self._last_clim = clim
        self._canvas.update_canvas()


class Q3DViewerBase(QViewer):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._canvas = Vispy3DViewer(self)
        self._canvas._scene.bgcolor = "#242424"
        self._canvas._viewbox.border_color = "#4A4A4A"
        self._canvas.native.setMaximumSize(400, 400)
        self._canvas.native.setMinimumSize(300, 300)
        self.setSizePolicy(
            QtW.QSizePolicy.Policy.Expanding,
            QtW.QSizePolicy.Policy.Expanding,
        )
        self._canvas.right_clicked.connect(self._show_context_menu)


class Q3DViewer(Q3DViewerBase):
    """3D Viewer.

    ## Mouse interactions:

    - Left drag ... rotate view
    - Right drag ... zoom
    - Middle drag ... pan
    - Wheel ... zoom
    - Shift + Left drag ... pan
    - Shift + Right drag ... change camera perspective
    """

    __himena_widget_id__ = "himena-relion:Q3DViewer"
    __himena_display_name__ = "3D volume viewer"

    def __init__(self, parent=None):
        super().__init__(parent)
        self._control_widget: Q3DViewerControl | None = None  # delayed
        self._rendering_mgui = ToggleButtons(
            value="Surface",
            choices=[("Surf", "Surface"), ("Max", "Maximum"), ("Avg", "Average")],
            orientation="horizontal",
            tooltip=(
                "3D rendering mode.\n"
                " * 'Surf': Iso-surface rendering.\n"
                " * 'Max': Maximum intensity projection.\n"
                " * 'Avg': Average intensity projection."
            ),
        )
        self._rendering_mgui.changed.connect(self.set_rendering_mode)
        self._rendering_mgui.max_height = 24

        self._hist_view = QHistogramView(mode="thresh")
        self._hist_view.set_hist_scale("log")
        self._hist_view.setFixedHeight(32)
        self._hist_view.setValueFormat(".2f", always_show=True)
        self._hist_view.threshold_changed.connect(self._on_iso_changed)
        self._hist_view.clim_changed.connect(self._on_clim_changed)
        self._auto_thresh_btn = QtW.QPushButton("Auto")
        self._auto_thresh_btn.setFixedWidth(40)
        self._auto_thresh_btn.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self._auto_thresh_btn.clicked.connect(lambda: self.auto_threshold())
        self._auto_thresh_btn.setToolTip("Automatically set the iso-surface threshold")
        self._has_image = False
        self._footer = _thresh = QtW.QWidget()
        _thresh.setSizePolicy(
            QtW.QSizePolicy.Policy.MinimumExpanding,
            QtW.QSizePolicy.Policy.Fixed,
        )
        _thresh_layout = QtW.QHBoxLayout(_thresh)
        _thresh_layout.setContentsMargins(0, 0, 0, 0)
        _thresh_layout.addWidget(self._rendering_mgui.native)
        _thresh_layout.addWidget(self._hist_view)
        _thresh_layout.addWidget(self._auto_thresh_btn)
        _thresh.setMaximumWidth(400)
        _thresh.setMinimumWidth(300)
        _thresh.setMinimumHeight(36)

        layout = QtW.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._canvas.native)
        layout.addWidget(_thresh)

        self.setMinimumHeight(
            _thresh.minimumHeight()
            + self._canvas.native.minimumHeight()
            + layout.spacing()
        )

    @property
    def has_image(self) -> bool:
        return self._has_image

    def set_image(self, image: np.ndarray | None, update_now: bool = True):
        """Set the 3D image to be displayed."""
        had_image = self.has_image
        if image is None:
            self._canvas.image = image = np.zeros((2, 2, 2))
            self._canvas.image_visual.visible = False
            self._has_image = False
        else:
            self._canvas.image = image
            self._canvas.image_visual.visible = True
            self._has_image = True
        view_min, view_max = self._canvas._lims
        if not had_image:
            self.auto_threshold(update_now=False)
            self.auto_fit(update_now=False)
            th_min, th_max = view_min, view_max
        else:
            th_min, th_max = image.min(), image.max()
            cur_th = self._hist_view.threshold()
            if cur_th < view_min or cur_th > view_max:
                self._hist_view.set_threshold((view_min + view_max) / 2)
        fmt = _format_for_minmax(th_min, th_max)
        self._hist_view.setValueFormat(fmt, always_show=True)

        if self._has_image:
            self._hist_view.set_view_range(view_min, view_max)

        self._hist_view.set_hist_for_array(image, (view_min, view_max))
        self._hist_view.set_minmax((th_min, th_max))

        self._canvas.set_iso_threshold(self._hist_view.threshold())
        if self._control_widget is not None:
            self._control_widget.set_info(image)
        if update_now:
            self._canvas.update_canvas()

    def set_rendering_mode(self, mode: Literal["Surface", "Maximum", "Average"]):
        """Set the rendering mode of the 3D viewer."""
        if mode not in ["Surface", "Maximum", "Average"]:
            raise ValueError("mode must be 'Surface' or 'Maximum'.")
        self._canvas.set_rendering_mode(mode)
        self._hist_view.set_mode("thresh" if mode == "Surface" else "clim")
        self._canvas.update_canvas()

    def auto_threshold(self, thresh: float | None = None, update_now: bool = True):
        """Automatically set the threshold based on the image data."""
        img = self._canvas.image
        if self._canvas.image_visual.visible:
            if thresh is None:
                thresh = _utils.threshold_yen(_utils.bin_image(img, 4))
            self._hist_view.set_threshold(thresh)
            self._hist_view.set_minmax(self._canvas._lims)
        if update_now:
            self._canvas.update_canvas()

    def auto_fit(self, update_now: bool = True):
        """Automatically fit the camera to the image."""
        img = self._canvas.image
        self._canvas.camera.center = np.array(img.shape) / 2
        self._canvas.camera.scale_factor = max(img.shape)
        self._canvas.camera.update()
        if update_now:
            self._canvas.update_canvas()

    def _on_iso_changed(self, value: float):
        self._canvas.set_iso_threshold(value)
        self._canvas.update_canvas()

    def _on_clim_changed(self, clim: tuple[float, float]):
        self._canvas.contrast_limits = clim
        self._canvas.update_canvas()

    @validate_protocol
    def update_model(self, model: WidgetDataModel):
        arr = np.asarray(model.value, dtype=np.float32)
        if arr.ndim != 3:
            raise ValueError("Input array must be 3D.")
        self.set_image(arr, update_now=True)

    @validate_protocol
    def model_type(self) -> str:
        return StandardType.IMAGE

    @validate_protocol
    def to_model(self) -> WidgetDataModel:
        return WidgetDataModel(
            value=self._canvas.image,
            type=StandardType.IMAGE,
        )

    @validate_protocol
    def size_hint(self):
        return (330, 360)

    @validate_protocol
    def control_widget(self) -> Q3DViewerControl:
        if self._control_widget is None:
            self._control_widget = Q3DViewerControl()
            if self.has_image:
                self._control_widget.set_info(self._canvas.image)
        return self._control_widget

    @validate_protocol
    def widget_added_callback(self):
        # if this widget is added as a subwindow in a himena tab, user may want to
        # expand the canvas. Allow this widget to expand.
        self._canvas.native.setMaximumSize(6000, 6000)


class Q3DViewerControl(QtW.QWidget):
    def __init__(self):
        super().__init__()
        self._image_info_label = QtW.QLabel("")

    def set_info(self, img: np.ndarray):
        size_str = _utils.bytes_to_size_str(img.nbytes)
        txt = f"{img.shape}, {img.dtype}, {size_str}"
        self._image_info_label.setText(txt)


class Q3DTomogramViewer(QViewer):
    """3D viewer for displaying tomogram with components.

    ## Mouse interactions:

    - Left drag ... rotate view
    - Right drag ... zoom
    - Middle drag ... pan
    - Wheel ... zoom
    - Shift + Left drag ... pan
    - Shift + Right drag ... change camera perspective
    - Ctrl + Left drag ... move z slice
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._canvas = Vispy3DTomogramViewer(self)
        self._canvas._scene.bgcolor = "#242424"
        self._canvas._viewbox.border_color = "#4A4A4A"
        self.setSizePolicy(
            QtW.QSizePolicy.Policy.Expanding,
            QtW.QSizePolicy.Policy.Expanding,
        )

        self._clim_widget = QHistogramView(mode="clim")
        self._clim_widget.setFixedHeight(32)
        self._clim_widget.setValueFormat(".2f", always_show=True)
        self._clim_widget.clim_changed.connect(self._on_clim_changed)
        self._auto_contrast_btn = QAutoContrastButton(self._auto_contrast)
        self._auto_contrast_btn.qminmax = (0.0001, 0.9999)
        self._auto_contrast_btn.update_color("gray")
        layout = QtW.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._canvas.native)
        hlayout = QtW.QHBoxLayout()
        hlayout.addWidget(self._auto_contrast_btn)
        hlayout.addWidget(self._clim_widget)
        hlayout.setContentsMargins(8, 0, 8, 0)
        layout.addLayout(hlayout)
        self._last_clim: tuple[float, float] | None = None

        self._canvas.plane_position_changed.connect(self._on_plane_position_changed)
        self._canvas.right_clicked.connect(self._show_context_menu)

    def set_array_view(
        self,
        array_view: ArrayFilteredView,
        clim=None,
        update_now: bool = True,
    ):
        """Set the 3D tomogram to be displayed."""
        self._canvas.set_array_view(array_view, clim)
        c0, c1 = self._canvas.contrast_limits
        arr_2d = self._canvas._current_image_slice
        assert arr_2d is not None
        self._clim_widget.set_hist_for_array(arr_2d, (c0, c1))
        crange = c1 - c0
        margin = crange * 0.1
        self._clim_widget.set_view_range(c0 - margin, c1 + margin)
        ndigits = max(1, -int(np.floor(np.log10(crange))) + 1)
        self._clim_widget.setValueFormat(f".{ndigits}f", always_show=True)
        if update_now:
            self._canvas.update_canvas()

    def auto_fit(self, update_now: bool = True):
        """Automatically fit the camera to the image."""
        self._canvas.auto_fit()
        if update_now:
            self._canvas.update_canvas()

    def set_points(self, points, size=5.0, face_color="lime", edge_color="black"):
        """Set the 3D points to be displayed."""
        points = np.asarray(points)
        face_colors = _norm_color(face_color, len(points))
        edge_colors = _norm_color(edge_color, len(points))
        if points.shape[0] > 0:
            self._canvas.markers_visual.set_data(
                points[:, ::-1],
                face_color=face_colors,
                edge_color=edge_colors,
                edge_width_rel=0.1 * self.devicePixelRatioF(),
                size=size / self.devicePixelRatioF(),
            )
            self._canvas.markers_visual.visible = True
        else:
            self._canvas.markers_visual.set_data(
                np.ones((1, 3), dtype=np.float32),
                face_color=np.zeros(4),
                edge_color=np.zeros(4),
                size=0.01,
            )
            self._canvas.markers_visual.visible = False
        self._canvas.update_canvas()

    def set_motion_paths(self, motion, color=None):
        self._canvas.motion_visual.set_data(motion)
        self._canvas.motion_visual.visible = True

    def clear(self):
        self._canvas.image = np.zeros((2, 2, 2), dtype=np.float32)
        self._canvas.image_visual.visible = False
        self._canvas.markers_visual.set_data(
            np.ones((1, 3), dtype=np.float32),
            size=0.01,
            face_color=np.zeros(4),
            edge_color=np.zeros(4),
        )
        self._canvas.markers_visual.visible = False
        self._canvas.motion_visual.set_data([])
        self._canvas.update_canvas()
        self._last_clim = None

    def _auto_contrast(self, *, force_update_view_range: bool = False):
        """Automatically adjust the contrast based on the histogram."""
        auto_contrast_by_hist(
            self._clim_widget,
            self._auto_contrast_btn.qminmax,
            force_update_view_range=force_update_view_range,
        )

    def _on_clim_changed(self, clim: tuple[float, float]):
        """Update the contrast limits based on the histogram view."""
        self._canvas.contrast_limits = clim
        self._canvas.update_canvas()

    def _on_plane_position_changed(self, zpos: int):
        """Update the histogram when the plane position changes."""
        slice_image = self._canvas._current_image_slice
        c0, c1 = self._canvas.contrast_limits
        self._clim_widget.set_hist_for_array(slice_image, (c0, c1))

    def _show_context_menu(self):
        menu = self._make_context_menu()
        pos = menu.mapFromGlobal(QtGui.QCursor.pos())
        menu.exec(pos)


class Q3DLocalResViewer(Q3DViewerBase):
    """A 3D viewer for displaying local resolution maps with iso-surface.

    ## Mouse interactions:

    - Left drag ... rotate view
    - Right drag ... zoom
    - Middle drag ... pan
    - Wheel ... zoom
    - Shift + Left drag ... pan
    - Shift + Right drag ... change camera perspective
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._iso_slider = QHistogramView(mode="thresh")
        self._iso_slider.setFixedHeight(32)
        self._iso_slider.threshold_changed.connect(self._on_iso_changed)
        self._iso_slider.set_hist_scale("log")
        self._auto_threshold_btn = QtW.QPushButton("Auto")
        self._auto_threshold_btn.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
        self._auto_threshold_btn.setFixedWidth(40)
        self._auto_threshold_btn.clicked.connect(lambda: self.auto_threshold())
        self._clim_slider = QHistogramView(mode="clim")
        self._clim_slider.setFixedHeight(32)
        self._clim_slider.clim_changed.connect(self._on_clim_changed)

        self._surface = IsoSurface(parent=self._canvas._viewbox.scene)
        _thresh = labeled("Threshold", self._iso_slider, self._auto_threshold_btn)
        _thresh.setMaximumWidth(400)
        _thresh.setMinimumWidth(300)
        clim_slider = labeled("Resolution (A)", self._clim_slider)
        clim_slider.setMaximumWidth(400)
        clim_slider.setMinimumWidth(300)
        self._shading = QtW.QComboBox()
        self._shading.setSizePolicy(
            QtW.QSizePolicy.Policy.Expanding,
            QtW.QSizePolicy.Policy.Fixed,
        )
        self._shading.addItems(["none", "flat", "smooth"])
        self._shading.setCurrentText("smooth")
        self._shading.currentTextChanged.connect(self._on_shading_changed)

        shading_widget = labeled("Shading", self._shading)
        shading_widget.setMinimumWidth(300)
        shading_widget.setMaximumWidth(400)

        layout = QtW.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._canvas.native)
        layout.addWidget(_thresh)
        layout.addWidget(clim_slider)
        layout.addWidget(shading_widget)

        self._iso_slider.setValueFormat(".2f", always_show=True)

        # mesh lighting
        self._canvas.camera.changed.connect(self._on_camera_change)

    def _on_camera_change(self):
        if self._surface.shading_filter is not None:
            # Set light direction parallel to camera view direction
            view_direction = self._canvas.camera.view_direction()
            self._surface.shading_filter.light_dir = -view_direction

    def auto_threshold(self, thresh: float | None = None, update_now: bool = True):
        """Automatically set the threshold based on the image data."""
        img = self._surface._data
        mask = self._surface._mask
        if self._surface.visible:
            if thresh is None:
                if mask is not None:
                    sample_data = img[mask]
                else:
                    sample_data = img
                thresh = _utils.threshold_yen(sample_data)
            self._iso_slider.set_threshold(thresh)
            self._iso_slider.set_minmax(self._canvas._lims)
        if update_now:
            self._canvas.update_canvas()

    def auto_fit(self, update_now: bool = True):
        """Automatically fit the camera to the image."""
        img = self._surface._data
        self._canvas.camera.center = np.array(img.shape) / 2
        self._canvas.camera.scale_factor = max(img.shape)
        self._canvas.camera.update()
        if update_now:
            self._canvas.update_canvas()

    def set_images(
        self,
        image: NDArray[np.float32],
        locres: NDArray[np.float32],
        mask: NDArray[np.bool_] | None = None,
        *,
        update_now: bool = True,
    ):
        if mask is None:
            mask_sl = slice(None)
        else:
            mask_sl = mask
        image_masked = image[mask_sl]
        im_min0, im_max0 = np.min(image_masked), np.max(image_masked)
        self._iso_slider.set_minmax((im_min0, im_max0))
        self._iso_slider.set_threshold((im_min0 + im_max0) / 2)
        fmt = _format_for_minmax(im_min0, im_max0)
        self._iso_slider.setValueFormat(fmt, always_show=True)

        locres_masked = locres[mask_sl]
        locres_masked = locres_masked[locres_masked > 0.001]
        self._surface.set_data(image, mask, clim=None, color_array=locres)
        self._surface.init_surface()
        with QtCore.QSignalBlocker(self._clim_slider):
            self._clim_slider.set_clim(self._surface.clim)
        self._on_shading_changed(self._shading.currentText())
        self._iso_slider.set_hist_for_array(image, (im_min0, im_max0))
        self._iso_slider.set_view_range(im_min0, im_max0)

        min0, max0 = np.min(locres_masked), np.max(locres_masked)
        self._clim_slider.set_minmax((min0, max0))
        self._clim_slider.set_hist_for_array(locres, (min0, max0))
        self._clim_slider.set_view_range(min0, max0)
        self._clim_slider.setValueFormat(".2f", always_show=True)

        if update_now:
            self._canvas.update_canvas()

    def _on_iso_changed(self, value: float):
        self._surface.level = value
        self._canvas.update_canvas()

    def _on_clim_changed(self, clim: tuple[float, float]):
        self._surface.clim = clim
        self._canvas.update_canvas()

    def _on_shading_changed(self, shading: str):
        if shading == "none":
            shading = None
        self._surface.shading = shading
        self._surface.update()
        self._canvas.update_canvas()


class Q2DFilterWidget(QtW.QWidget):
    value_changed = QtCore.Signal()

    def __init__(self, parent=None, bin_default: int = 4, lowpass_default: float = 10):
        super().__init__(parent)
        layout = QtW.QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        self._bin_factor = QIntLineEdit(str(bin_default))
        self._bin_factor.setFixedWidth(60)
        self._bin_factor.setMinimum(1)
        self._bin_factor.setMaximum(20)
        self._lowpass_cutoff = QDoubleLineEdit(str(lowpass_default))
        self._lowpass_cutoff.setMinimum(0.0)
        self._lowpass_cutoff.setMaximum(200.0)
        self._lowpass_cutoff.setFixedWidth(80)
        self._spacer = QtW.QLabel()
        self._spacer.setSizePolicy(
            QtW.QSizePolicy.Policy.Expanding, QtW.QSizePolicy.Policy.Expanding
        )
        self._spacer.setAlignment(
            QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter
        )
        layout.addWidget(labeled("Binning factor:", self._bin_factor))
        layout.addWidget(labeled("Lowpass cutoff (Å):", self._lowpass_cutoff))
        layout.addWidget(self._spacer)
        self._image_scale = 1.0
        self._bin_factor.textChanged.connect(self.value_changed)
        self._lowpass_cutoff.textChanged.connect(self.value_changed)

    def image_scale(self) -> float:
        """Get the image scale in Å/pixel."""
        return self._image_scale

    def set_image_scale(self, scale: float):
        """Set the image scale in Å/pixel."""
        self._image_scale = scale

    def bin_factor(self) -> int:
        """Get the binning factor from the input."""
        return int(self._bin_factor.text())

    def lowpass_cutoff(self) -> float:
        """Get the lowpass cutoff frequency from the input."""
        return float(self._lowpass_cutoff.text())

    def apply(self, img: np.ndarray, index=None) -> np.ndarray:
        """Apply the binning and lowpass filter to the input image."""
        # Binning
        factor = self.bin_factor()
        cutoff = self.lowpass_cutoff()
        if factor > 1:
            img = _utils.bin_image(img, factor)
        if cutoff > 0.0:
            cutoff_rel = self._image_scale / cutoff * factor
            img = _utils.lowpass_filter(img, cutoff_rel)

        return img

    def set_params(self, bin_factor: int, lowpass_cutoff: float):
        """Set the binning factor and lowpass cutoff frequency."""
        self._bin_factor.setText(str(bin_factor))
        self._lowpass_cutoff.setText(str(lowpass_cutoff))

    def set_label_text(self, text: str):
        """Set the label text to the spacer widget."""
        self._spacer.setText(text)


def _norm_color(color, num: int) -> NDArray[np.float32]:
    """Normalize color input to an array of RGBA colors."""
    carr = ColorArray(color)
    if len(carr) == 1:
        carr = np.tile(carr.rgba, (num, 1))
    else:
        if len(carr) != num:
            raise ValueError("Color array length does not match number of points.")
        carr = carr.rgba
    return carr.astype(np.float32, copy=False)


def _format_for_minmax(m0, m1):
    prec = np.log10(m1 - m0 + 1e-8)
    n_decimals = max(0, -int(np.floor(prec)) + 3)
    return f".{n_decimals}f"


def auto_contrast_by_hist(
    hist_view: QHistogramView,
    qminmax: tuple[float, float],
    *,
    force_update_view_range: bool = False,
):
    range_min, range_max = hist_view._view_range
    minmax = hist_view.calc_contrast_limits(*qminmax)
    if minmax is None:
        return
    min_new, max_new = minmax

    min_old, max_old = hist_view.clim()
    hist_view.set_clim((min_new, max_new))

    # ensure both end is visible
    changed = False
    if min_new < min_old:
        range_min = min_new
        changed = True
    if max_new > max_old:
        range_max = max_new
        changed = True
    if changed or force_update_view_range:
        hist_view.set_view_range(range_min, range_max)
