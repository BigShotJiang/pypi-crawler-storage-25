"""
Task handlers for biliTickerBuy.
"""
