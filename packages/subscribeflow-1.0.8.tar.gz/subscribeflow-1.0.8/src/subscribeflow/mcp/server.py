"""SubscribeFlow MCP Server.

This module implements a Model Context Protocol (MCP) server that enables
LLM agents to interact with the SubscribeFlow API for subscriber and tag management.

Environment Variables:
    SUBSCRIBEFLOW_API_KEY: Required. Your SubscribeFlow API key.
    SUBSCRIBEFLOW_BASE_URL: Optional. API base URL (default: https://api.subscribeflow.net)
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from subscribeflow import SubscribeFlowClient
from subscribeflow.exceptions import (
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    NotFoundError,
    RateLimitError,
    SubscribeFlowError,
    ValidationError,
)
from subscribeflow.mcp.tools import get_all_tools

logger = logging.getLogger(__name__)

# Server instance
server = Server("subscribeflow")

# Lazy-initialized client
_client: SubscribeFlowClient | None = None


def _get_client() -> SubscribeFlowClient:
    """Get or create the SubscribeFlow client.

    Returns:
        Configured SubscribeFlowClient instance.

    Raises:
        ValueError: If SUBSCRIBEFLOW_API_KEY is not set.
    """
    global _client
    if _client is None:
        api_key = os.environ.get("SUBSCRIBEFLOW_API_KEY")
        if not api_key:
            raise ValueError(
                "SUBSCRIBEFLOW_API_KEY environment variable is required. "
                "Set it in your MCP server configuration."
            )
        base_url = os.environ.get("SUBSCRIBEFLOW_BASE_URL", "https://api.subscribeflow.net")
        _client = SubscribeFlowClient(api_key=api_key, base_url=base_url)
    return _client


def _format_subscriber(subscriber: Any) -> str:
    """Format a subscriber for text output."""
    tags = ", ".join(t.name for t in subscriber.tags) if subscriber.tags else "none"
    return (
        f"- {subscriber.email}\n"
        f"  ID: {subscriber.id}\n"
        f"  Status: {subscriber.status}\n"
        f"  Tags: {tags}"
    )


def _format_tag(tag: Any) -> str:
    """Format a tag for text output."""
    return (
        f"- {tag.name}\n"
        f"  ID: {tag.id}\n"
        f"  Description: {tag.description or 'none'}\n"
        f"  Category: {tag.category or 'none'}\n"
        f"  Public: {tag.is_public}"
    )


def _format_template(template: Any) -> str:
    """Format a template for text output."""
    return (
        f"- {template.name}\n"
        f"  Slug: {template.slug}\n"
        f"  Subject: {template.subject}\n"
        f"  Category: {template.category}\n"
        f"  Active: {template.is_active}"
    )


def _format_campaign(campaign: Any) -> str:
    """Format a campaign for text output."""
    stats = ""
    if campaign.stats:
        stats = (
            f"\n  Sent: {campaign.stats.sent_count}"
            f"/{campaign.stats.total_recipients}"
            f" ({campaign.stats.send_progress:.0%})"
        )
    return (
        f"- {campaign.name}\n"
        f"  ID: {campaign.id}\n"
        f"  Status: {campaign.status}\n"
        f"  Template: {campaign.template_id}"
        f"{stats}"
    )


def _format_trigger(trigger: Any) -> str:
    """Format a trigger for text output."""
    return (
        f"- {trigger.event_type}\n"
        f"  ID: {trigger.id}\n"
        f"  Template: {trigger.template_id}\n"
        f"  Description: {trigger.description or 'none'}\n"
        f"  Active: {trigger.is_active}"
    )


def _format_webhook(webhook: Any) -> str:
    """Format a webhook for text output."""
    events = ", ".join(webhook.events) if webhook.events else "none"
    return f"- {webhook.url}\n  ID: {webhook.id}\n  Events: {events}\n  Active: {webhook.is_active}"


def _format_delivery(delivery: Any) -> str:
    """Format a webhook delivery for text output."""
    return (
        f"- Delivery {delivery.id}\n"
        f"  Event: {delivery.event_type}\n"
        f"  Status: {delivery.status}\n"
        f"  Attempts: {delivery.attempt_count}\n"
        f"  Response: {delivery.response_status_code or 'N/A'}\n"
        f"  Created: {delivery.created_at}"
    )


def _format_delivery_stats(stats: Any) -> str:
    """Format webhook delivery statistics for text output."""
    avg_time = (
        f"{stats.avg_response_time_ms:.0f}ms" if stats.avg_response_time_ms is not None else "N/A"
    )
    return (
        f"Total: {stats.total_deliveries}\n"
        f"Successful: {stats.successful_deliveries}\n"
        f"Failed: {stats.failed_deliveries}\n"
        f"Pending: {stats.pending_deliveries}\n"
        f"Success rate: {stats.success_rate:.1f}%\n"
        f"Avg response time: {avg_time}"
    )


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Return all available MCP tools."""
    return get_all_tools()


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls from the LLM.

    Args:
        name: Tool name to execute.
        arguments: Tool arguments.

    Returns:
        List of TextContent with the result.

    Raises:
        ValueError: If tool name is unknown.
    """
    client = _get_client()

    try:
        result = await _execute_tool(client, name, arguments)
        return [TextContent(type="text", text=result)]
    except AuthenticationError:
        return [
            TextContent(
                type="text",
                text="Authentication failed: the configured API key is invalid "
                "or expired. Update SUBSCRIBEFLOW_API_KEY and restart.",
            )
        ]
    except AuthorizationError as e:
        return [
            TextContent(
                type="text",
                text=f"Permission denied: {e}. Check that your API key has the required scopes.",
            )
        ]
    except NotFoundError as e:
        return [TextContent(type="text", text=f"Not found: {e}")]
    except ValidationError as e:
        detail = f"Validation error: {e}"
        if e.errors:
            fields = "; ".join(
                f"{err.get('field', 'unknown')}: {err.get('message', str(err))}" for err in e.errors
            )
            detail += f"\nDetails: {fields}"
        return [TextContent(type="text", text=detail)]
    except ConflictError as e:
        return [TextContent(type="text", text=f"Conflict: {e}")]
    except RateLimitError as e:
        return [TextContent(type="text", text=f"Rate limit exceeded: {e}")]
    except SubscribeFlowError as e:
        return [TextContent(type="text", text=f"API error ({e.status}): {e}")]
    except Exception as e:
        logger.error("Unexpected error in MCP tool %s", name, exc_info=True)
        return [TextContent(type="text", text=f"Unexpected error: {type(e).__name__}: {e}")]


async def _execute_tool(client: SubscribeFlowClient, name: str, args: dict[str, Any]) -> str:
    """Execute a tool and return the result as a formatted string."""

    # === SUBSCRIBER TOOLS ===

    if name == "list_subscribers":
        result = await client.subscribers.list(
            status=args.get("status"),
            tag=args.get("tag"),
            limit=args.get("limit", 50),
        )
        if not result.items:
            return "No subscribers found."
        subscribers = "\n".join(_format_subscriber(s) for s in result.items)
        return f"Found {result.total} subscribers:\n\n{subscribers}"

    if name == "get_subscriber":
        subscriber = await client.subscribers.get(args["subscriber_id"])
        return f"Subscriber details:\n\n{_format_subscriber(subscriber)}"

    if name == "get_subscriber_by_email":
        subscriber = await client.subscribers.get_by_email(args["email"])
        return f"Subscriber details:\n\n{_format_subscriber(subscriber)}"

    if name == "create_subscriber":
        subscriber = await client.subscribers.create(
            email=args["email"],
            tags=args.get("tags"),
            metadata=args.get("metadata"),
        )
        return f"Created subscriber:\n\n{_format_subscriber(subscriber)}"

    if name == "get_or_create_subscriber":
        subscriber, created = await client.subscribers.get_or_create(
            email=args["email"],
            tags=args.get("tags"),
            metadata=args.get("metadata"),
        )
        action = "Created new" if created else "Found existing"
        return f"{action} subscriber:\n\n{_format_subscriber(subscriber)}"

    if name == "update_subscriber":
        subscriber = await client.subscribers.update(
            subscriber_id=args["subscriber_id"],
            metadata=args.get("metadata"),
            status=args.get("status"),
        )
        return f"Updated subscriber:\n\n{_format_subscriber(subscriber)}"

    if name == "delete_subscriber":
        await client.subscribers.delete(args["subscriber_id"])
        return f"Deleted subscriber {args['subscriber_id']}"

    if name == "generate_preference_token":
        token_response = await client.subscribers.generate_token(args["subscriber_id"])
        return (
            f"Generated preference center token:\n\n"
            f"Token: {token_response.token}\n"
            f"Expires: {token_response.expires_at}"
        )

    if name == "add_subscriber_tags":
        result = await client.subscribers.add_tags(
            args["subscriber_id"],
            args["tag_ids"],
        )
        tags = ", ".join(t.name for t in result.tags)
        return (
            f"Tags added to subscriber {args['subscriber_id']}. "
            f"Current tags: {tags} (total: {result.total})"
        )

    if name == "remove_subscriber_tag":
        await client.subscribers.remove_tag(
            args["subscriber_id"],
            args["tag_id"],
        )
        return f"Tag {args['tag_id']} removed from subscriber {args['subscriber_id']}."

    # === NOTE TOOLS ===

    if name == "create_note":
        note = await client.notes.create(
            subscriber_id=args["subscriber_id"],
            content=args["content"],
            source=args.get("source", "api"),
            subject=args.get("subject"),
            metadata=args.get("metadata"),
        )
        return (
            f"Created note:\n\n"
            f"ID: {note.id}\n"
            f"Subscriber: {note.subscriber_id}\n"
            f"Source: {note.source}\n"
            f"Subject: {note.subject or '(none)'}\n"
            f"Content: {note.content[:200]}{'...' if len(note.content) > 200 else ''}\n"
            f"Created: {note.created_at}"
        )

    if name == "list_notes":
        result = await client.notes.list(
            subscriber_id=args["subscriber_id"],
            source=args.get("source"),
            search=args.get("search"),
            created_after=args.get("created_after"),
            created_before=args.get("created_before"),
            sort=args.get("sort", "desc"),
            limit=args.get("limit", 50),
            cursor=args.get("cursor"),
        )
        if not result.items:
            return "No notes found."
        notes = "\n---\n".join(
            f"ID: {n.id}\n"
            f"Source: {n.source}\n"
            f"Subject: {n.subject or '(none)'}\n"
            f"Content: {n.content[:200]}{'...' if len(n.content) > 200 else ''}\n"
            f"Created: {n.created_at}"
            for n in result.items
        )
        return f"Found {result.total} notes:\n\n{notes}"

    if name == "get_note":
        note = await client.notes.get(
            subscriber_id=args["subscriber_id"],
            note_id=args["note_id"],
        )
        return (
            f"Note details:\n\n"
            f"ID: {note.id}\n"
            f"Subscriber: {note.subscriber_id}\n"
            f"Source: {note.source}\n"
            f"Subject: {note.subject or '(none)'}\n"
            f"Content: {note.content}\n"
            f"Metadata: {note.metadata}\n"
            f"Created: {note.created_at}\n"
            f"Updated: {note.updated_at}"
        )

    if name == "update_note":
        note = await client.notes.update(
            subscriber_id=args["subscriber_id"],
            note_id=args["note_id"],
            content=args.get("content"),
            subject=args.get("subject"),
            metadata=args.get("metadata"),
        )
        return (
            f"Updated note:\n\n"
            f"ID: {note.id}\n"
            f"Content: {note.content[:200]}{'...' if len(note.content) > 200 else ''}\n"
            f"Updated: {note.updated_at}"
        )

    if name == "delete_note":
        await client.notes.delete(
            subscriber_id=args["subscriber_id"],
            note_id=args["note_id"],
        )
        return f"Deleted note {args['note_id']}"

    # === TAG TOOLS ===

    if name == "list_tags":
        result = await client.tags.list(limit=args.get("limit", 50))
        if not result.items:
            return "No tags found."
        tags = "\n".join(_format_tag(t) for t in result.items)
        return f"Found {result.total} tags:\n\n{tags}"

    if name == "get_tag":
        tag = await client.tags.get(args["tag_id"])
        return f"Tag details:\n\n{_format_tag(tag)}"

    if name == "get_tag_by_name":
        tag = await client.tags.get_by_name(args["name"])
        return f"Tag details:\n\n{_format_tag(tag)}"

    if name == "create_tag":
        tag = await client.tags.create(
            name=args["name"],
            description=args.get("description"),
            category=args.get("category"),
            is_public=args.get("is_public", True),
        )
        return f"Created tag:\n\n{_format_tag(tag)}"

    if name == "get_or_create_tag":
        tag, created = await client.tags.get_or_create(
            name=args["name"],
            description=args.get("description"),
            category=args.get("category"),
            is_public=args.get("is_public", True),
        )
        action = "Created new" if created else "Found existing"
        return f"{action} tag:\n\n{_format_tag(tag)}"

    if name == "update_tag":
        tag = await client.tags.update(
            tag_id=args["tag_id"],
            name=args.get("name"),
            description=args.get("description"),
            category=args.get("category"),
            is_public=args.get("is_public"),
        )
        return f"Updated tag:\n\n{_format_tag(tag)}"

    if name == "delete_tag":
        await client.tags.delete(args["tag_id"])
        return f"Deleted tag {args['tag_id']}"

    # === WEBHOOK TOOLS ===

    if name == "list_webhooks":
        result = await client.webhooks.list(limit=args.get("limit", 50))
        if not result.items:
            return "No webhooks found."
        webhooks = "\n".join(_format_webhook(w) for w in result.items)
        return f"Found {result.total} webhooks:\n\n{webhooks}"

    if name == "get_webhook":
        webhook = await client.webhooks.get(args["webhook_id"])
        return f"Webhook details:\n\n{_format_webhook(webhook)}"

    if name == "create_webhook":
        webhook = await client.webhooks.create(
            url=args["url"],
            events=args["events"],
            description=args.get("description"),
        )
        return (
            f"Created webhook:\n\n{_format_webhook(webhook)}\n\n"
            f"Secret: {webhook.secret} (save this - it won't be shown again)"
        )

    if name == "delete_webhook":
        await client.webhooks.delete(args["webhook_id"])
        return f"Deleted webhook {args['webhook_id']}"

    if name == "test_webhook":
        test_result = await client.webhooks.test(args["webhook_id"])
        status = "Success" if test_result.success else "Failed"
        return (
            f"Webhook test {status}:\n\n"
            f"Status code: {test_result.status_code}\n"
            f"Response time: {test_result.response_time_ms}ms"
        )

    # === WEBHOOK EXTENDED TOOLS ===

    if name == "update_webhook":
        webhook = await client.webhooks.update(
            endpoint_id=args["endpoint_id"],
            url=args.get("url"),
            description=args.get("description"),
            events=args.get("events"),
            is_active=args.get("is_active"),
        )
        return f"Updated webhook:\n\n{_format_webhook(webhook)}"

    if name == "regenerate_webhook_secret":
        webhook = await client.webhooks.regenerate_secret(args["endpoint_id"])
        return (
            f"Regenerated secret for webhook:\n\n"
            f"{_format_webhook(webhook)}\n\n"
            f"New secret: {webhook.secret} "
            f"(save this - it won't be shown again)"
        )

    if name == "list_webhook_deliveries":
        result = await client.webhooks.list_deliveries(
            endpoint_id=args["endpoint_id"],
            event_type=args.get("event_type"),
            status=args.get("status"),
            limit=args.get("limit", 50),
        )
        if not result.items:
            return "No deliveries found."
        deliveries = "\n".join(_format_delivery(d) for d in result.items)
        return f"Found {result.total} deliveries:\n\n{deliveries}"

    if name == "get_webhook_delivery":
        delivery = await client.webhooks.get_delivery(
            endpoint_id=args["endpoint_id"],
            delivery_id=args["delivery_id"],
        )
        payload_raw = str(delivery.payload)
        payload_str = payload_raw[:500]
        if len(payload_raw) > 500:
            payload_str += " [truncated]"
        return (
            f"Delivery details:\n\n"
            f"{_format_delivery(delivery)}\n"
            f"  Payload: {payload_str}\n"
            f"  Response body: "
            f"{delivery.response_body or 'N/A'}"
        )

    if name == "retry_webhook_delivery":
        result = await client.webhooks.retry_delivery(
            endpoint_id=args["endpoint_id"],
            delivery_id=args["delivery_id"],
        )
        status = "Success" if result.success else "Failed"
        return (
            f"Delivery retry {status}:\n\n"
            f"Status code: {result.status_code}\n"
            f"Response time: {result.response_time_ms}ms"
        )

    if name == "get_webhook_stats":
        stats = await client.webhooks.get_stats(
            endpoint_id=args["endpoint_id"],
            days=args.get("days", 30),
        )
        return f"Webhook delivery stats:\n\n{_format_delivery_stats(stats)}"

    if name == "list_all_webhook_deliveries":
        result = await client.webhooks.list_all_deliveries(
            event_type=args.get("event_type"),
            status=args.get("status"),
            limit=args.get("limit", 50),
        )
        if not result.items:
            return "No deliveries found."
        deliveries = "\n".join(_format_delivery(d) for d in result.items)
        return f"Found {result.total} deliveries (all endpoints):\n\n{deliveries}"

    if name == "get_global_webhook_stats":
        stats = await client.webhooks.get_global_stats(
            days=args.get("days", 30),
        )
        return f"Global webhook delivery stats:\n\n{_format_delivery_stats(stats)}"

    if name == "list_webhook_event_types":
        event_types = await client.webhooks.list_event_types()
        if isinstance(event_types, dict):
            lines = []
            for key, val in event_types.items():
                if isinstance(val, str):
                    lines.append(f"- {key}: {val}")
                else:
                    lines.append(f"- {key}")
            return f"Available event types:\n\n{chr(10).join(lines)}"
        return f"Available event types:\n\n{event_types}"

    # === TEMPLATE TOOLS ===

    if name == "list_templates":
        result = await client.templates.list(
            skip=args.get("skip", 0),
            category=args.get("category"),
            limit=args.get("limit", 50),
        )
        if not result.items:
            return "No templates found."
        templates = "\n".join(_format_template(t) for t in result.items)
        return f"Found {result.total} templates:\n\n{templates}"

    if name == "get_template":
        template = await client.templates.get(args["slug"])
        return f"Template details:\n\n{_format_template(template)}"

    if name == "create_template":
        template = await client.templates.create(
            name=args["name"],
            subject=args["subject"],
            mjml_content=args["mjml_content"],
            category=args.get("category", "transactional"),
        )
        return f"Created template:\n\n{_format_template(template)}"

    if name == "update_template":
        template = await client.templates.update(
            slug=args["slug"],
            name=args.get("name"),
            subject=args.get("subject"),
            mjml_content=args.get("mjml_content"),
            category=args.get("category"),
        )
        return f"Updated template:\n\n{_format_template(template)}"

    if name == "delete_template":
        await client.templates.delete(args["slug"])
        return f"Deleted template '{args['slug']}'"

    if name == "preview_template":
        preview = await client.templates.preview(
            slug=args["slug"],
            variables=args.get("variables"),
        )
        return f"Template preview:\n\nSubject: {preview.subject}\n\n{preview.html}"

    # === EMAIL TOOLS ===

    if name == "send_email":
        result = await client.emails.send(
            template_slug=args["template_slug"],
            to=args["to"],
            variables=args.get("variables"),
            idempotency_key=args.get("idempotency_key"),
        )
        return (
            f"Email queued:\n\n"
            f"ID: {result.id}\n"
            f"Status: {result.status}\n"
            f"To: {result.to}\n"
            f"Template: {result.template}"
        )

    # === CAMPAIGN TOOLS ===

    if name == "list_campaigns":
        result = await client.campaigns.list(
            status=args.get("status"),
            sort_by=args.get("sort_by"),
            sort_desc=args.get("sort_desc", True),
            limit=args.get("limit", 50),
        )
        if not result.items:
            return "No campaigns found."
        campaigns = "\n".join(_format_campaign(c) for c in result.items)
        return f"Found {result.total} campaigns:\n\n{campaigns}"

    if name == "get_campaign":
        campaign = await client.campaigns.get(args["campaign_id"])
        return f"Campaign details:\n\n{_format_campaign(campaign)}"

    if name == "create_campaign":
        campaign = await client.campaigns.create(
            name=args["name"],
            template_id=args["template_id"],
            tag_filter=args.get("tag_filter"),
        )
        return f"Created campaign:\n\n{_format_campaign(campaign)}"

    if name == "update_campaign":
        campaign = await client.campaigns.update(
            campaign_id=args["campaign_id"],
            name=args.get("name"),
            template_id=args.get("template_id"),
            tag_filter=args.get("tag_filter"),
        )
        return f"Updated campaign:\n\n{_format_campaign(campaign)}"

    if name == "send_campaign":
        result = await client.campaigns.send(
            campaign_id=args["campaign_id"],
            batch_size=args.get("batch_size", 50),
        )
        return (
            f"Campaign send triggered:\n\n"
            f"Campaign: {result.campaign_id}\n"
            f"Status: {result.status}\n"
            f"Recipients: {result.total_recipients}\n"
            f"Message: {result.message}"
        )

    if name == "cancel_campaign":
        campaign = await client.campaigns.cancel(args["campaign_id"])
        return f"Campaign cancelled:\n\n{_format_campaign(campaign)}"

    if name == "count_campaign_recipients":
        count = await client.campaigns.count_recipients(
            include_tags=args.get("include_tags"),
            exclude_tags=args.get("exclude_tags"),
            match=args.get("match", "any"),
        )
        return f"Matching recipients: {count}"

    if name == "retry_campaign":
        result = await client.campaigns.retry(args["campaign_id"])
        return (
            f"Campaign retry triggered:\n\n"
            f"Campaign: {result.campaign_id}\n"
            f"Status: {result.status}\n"
            f"Recipients: {result.total_recipients}\n"
            f"Message: {result.message}"
        )

    if name == "duplicate_campaign":
        campaign = await client.campaigns.duplicate(args["campaign_id"])
        return f"Created campaign:\n\n{_format_campaign(campaign)}"

    # === TRIGGER TOOLS ===

    if name == "list_triggers":
        triggers = await client.triggers.list()
        if not triggers:
            return "No triggers found."
        formatted = "\n".join(_format_trigger(t) for t in triggers)
        return f"Found {len(triggers)} triggers:\n\n{formatted}"

    if name == "get_trigger":
        trigger = await client.triggers.get(args["trigger_id"])
        return f"Trigger details:\n\n{_format_trigger(trigger)}"

    if name == "create_trigger":
        trigger = await client.triggers.create(
            event_type=args["event_type"],
            template_id=args["template_id"],
            description=args.get("description"),
            is_active=args.get("is_active", True),
        )
        return f"Created trigger:\n\n{_format_trigger(trigger)}"

    if name == "update_trigger":
        trigger = await client.triggers.update(
            trigger_id=args["trigger_id"],
            event_type=args.get("event_type"),
            template_id=args.get("template_id"),
            description=args.get("description"),
            is_active=args.get("is_active"),
        )
        return f"Updated trigger:\n\n{_format_trigger(trigger)}"

    if name == "delete_trigger":
        await client.triggers.delete(args["trigger_id"])
        return f"Deleted trigger {args['trigger_id']}"

    # === PREFERENCE CENTER TOOLS ===

    if name == "get_preferences":
        pc = client.preference_center(args["token"])
        result = await pc.get_preferences()
        tags = "\n".join(f"  - {t.get('name', 'unknown')}" for t in result.subscribed_tags)
        available = "\n".join(f"  - {t.get('name', 'unknown')}" for t in result.available_tags)
        return (
            f"Subscriber preferences:\n\n"
            f"Subscribed tags:\n{tags or '  (none)'}\n\n"
            f"Available tags:\n{available or '  (none)'}"
        )

    if name == "subscribe_to_tag":
        pc = client.preference_center(args["token"])
        result = await pc.subscribe_tag(args["tag_id"])
        return f"Tag subscription: {result.message}"

    if name == "unsubscribe_from_tag":
        pc = client.preference_center(args["token"])
        result = await pc.unsubscribe_tag(args["tag_id"])
        return f"Tag unsubscription: {result.message}"

    if name == "export_subscriber_data":
        pc = client.preference_center(args["token"])
        result = await pc.export_data()
        return (
            f"Data export completed at {result.exported_at}:\n\n"
            f"Tags: {len(result.subscribed_tags)}\n"
            f"History entries: {len(result.subscription_history)}\n"
            f"Audit log entries: {len(result.audit_log)}"
        )

    if name == "delete_subscriber_account":
        pc = client.preference_center(args["token"])
        result = await pc.delete_account()
        return f"Account deletion: {result.message}"

    raise ValueError(f"Unknown tool: {name}")


def main() -> None:
    """Run the MCP server."""

    async def run_server() -> None:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    asyncio.run(run_server())


if __name__ == "__main__":
    main()
