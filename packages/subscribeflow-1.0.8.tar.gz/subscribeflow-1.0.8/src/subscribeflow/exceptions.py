"""Exception classes for SubscribeFlow SDK."""

from typing import Any


class SubscribeFlowError(Exception):
    """Base exception for SubscribeFlow SDK errors.

    Attributes:
        status: HTTP status code
        type: Error type URI
        title: Short error title
        detail: Detailed error message
        instance: Request path that caused the error
        errors: Validation errors (for 422 responses)
    """

    def __init__(
        self,
        message: str,
        *,
        status: int = 500,
        type: str = "https://subscribeflow.net/errors/unknown",
        title: str = "Unknown Error",
        detail: str | None = None,
        instance: str | None = None,
        errors: list[dict[str, Any]] | None = None,
    ) -> None:
        super().__init__(message)
        self.status = status
        self.type = type
        self.title = title
        self.detail = detail or message
        self.instance = instance
        self.errors = errors or []

    @classmethod
    def from_response(cls, data: dict[str, Any], status: int) -> "SubscribeFlowError":
        """Create an exception from an API error response.

        Args:
            data: Response JSON data (RFC 7807 format)
            status: HTTP status code

        Returns:
            Appropriate exception instance based on status code
        """
        error_class = _STATUS_TO_EXCEPTION.get(status, cls)
        return error_class(
            message=data.get("detail", "An error occurred"),
            status=status,
            type=data.get("type", ""),
            title=data.get("title", "Error"),
            detail=data.get("detail"),
            instance=data.get("instance"),
            errors=data.get("errors"),
        )


class AuthenticationError(SubscribeFlowError):
    """Raised when authentication fails (401)."""

    pass


class AuthorizationError(SubscribeFlowError):
    """Raised when access is denied (403)."""

    pass


class NotFoundError(SubscribeFlowError):
    """Raised when a resource is not found (404)."""

    pass


class ConflictError(SubscribeFlowError):
    """Raised when there's a resource conflict (409)."""

    pass


class ValidationError(SubscribeFlowError):
    """Raised when request validation fails (422).

    The `errors` attribute contains detailed validation errors.
    """

    pass


class RateLimitError(SubscribeFlowError):
    """Raised when rate limit is exceeded (429)."""

    pass


# Map status codes to exception classes
_STATUS_TO_EXCEPTION: dict[int, type[SubscribeFlowError]] = {
    401: AuthenticationError,
    403: AuthorizationError,
    404: NotFoundError,
    409: ConflictError,
    422: ValidationError,
    429: RateLimitError,
}
