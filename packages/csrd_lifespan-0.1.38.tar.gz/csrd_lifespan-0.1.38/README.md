# csrd-lifespan

Composable lifespan stack for FastAPI applications.

**Package**: `csrd.lifespan` · **Import**: `from csrd.lifespan import lifespan_stack`

## What's included

- `lifespan_stack` — register multiple async context managers as a single FastAPI lifespan
- Merges yielded state dicts from all lifespan functions
- Supports nested lists of lifespan functions

## Installation

```bash
uv pip install "csrd-lifespan @ git+ssh://git@github.com/csrd-api/fastapi-common.git#subdirectory=packages/lifespan"
```

## Dependencies

None (Tier 1 — standalone)
