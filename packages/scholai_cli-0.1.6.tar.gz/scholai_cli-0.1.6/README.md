# scholai-cli

scholai 课件生成管线的 Python CLI。

由 `@scholai/openclaw-scholai` plugin 的 skill 通过 `metadata.openclaw.install: [kind: uv]` 自动安装;也可独立使用:

```bash
uv tool install scholai-cli
scholai course vfd-url --run-id 260422-abc12345-article-01
```

## 管线 atom 列表

- `scholai course vfd-url` — URL → VFD.json
- `scholai course iod` — VFD → IOD.json
- `scholai course pd` — IOD + VFD → PD.md
- `scholai course txd-gen` — 含图占位符的 TXD.md
- `scholai course txd-imagegen` — 生成占位图 + TXD_final.md
- `scholai course txd-render-html` — TXD_final → output/article.html
- `scholai course publish` — POST 到 scholai 平台

## Token 用量查询

运行 `scholai usage <subcommand>` 查询 LLM 调用用量。

### 命令

```bash
scholai usage today                          # 今天的用量
scholai usage yesterday                      # 昨天的用量
scholai usage range --from 2026-05-01 --to 2026-05-06   # 日期区间
scholai usage run <run_id>                   # 单次 run 的用量

# 可选：按 skill 过滤（today / yesterday / range）
scholai usage today --skill article
```

### 配置价格（可选）

创建 `~/.openclaw/scholai-usage/pricing.toml`（dev 模式为 `~/.openclaw-dev/scholai-usage/pricing.toml`）：

```toml
[chat."deepseek-chat"]
prompt = 2.0          # 元/百万 token，cache miss
prompt_cached = 0.5   # 元/百万 token，cache hit（可省略，省略回落到 prompt 价）
completion = 8.0

[chat."glm-4-plus"]
prompt = 5.0
completion = 5.0

[image."cogview-3"]
per_call = 0.06       # 元/张
```

没有此文件时，命令仍可用，只显示 token 数量，不计算金额。

### 数据文件位置

| 文件 | 路径 |
|---|---|
| per-run 用量 | `<openclaw_home>/agents/<bot_id>/workspace/runs/<run_id>/logs/usage.jsonl` |
| 按天汇总 | `<openclaw_home>/scholai-usage/<YYYY-MM-DD>.jsonl` |
| 价格配置 | `<openclaw_home>/scholai-usage/pricing.toml` |

`<openclaw_home>` 由 openclaw 注入的 `OPENCLAW_STATE_DIR` 确定（dev 模式为 `~/.openclaw-dev`）。

## 开发

```bash
cd packages/scholai-cli
uv sync --all-extras
uv run pytest
```
