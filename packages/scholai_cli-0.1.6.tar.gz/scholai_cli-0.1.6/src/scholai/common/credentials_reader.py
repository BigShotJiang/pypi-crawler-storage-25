"""env-only credentials reader for atoms.

Centralizes scholai env var names + URL default. Atoms call these
getters instead of os.environ.get(...) so the env contract lives in
one file. No file fallback — operators must inject env vars (e.g. via
openclaw skills.entries.<skill>.env mechanism).
"""
from __future__ import annotations

import os

DEFAULT_SCHOLAI_API_URL = "https://api.scholai.io"


def get_llm_api_key() -> str | None:
    """读 LLM_API_KEY env，缺则 None。"""
    return os.environ.get("LLM_API_KEY")


def get_llm_base_url() -> str | None:
    """读 LLM_BASE_URL env，缺则 None（openai SDK 默认用官方地址）。"""
    return os.environ.get("LLM_BASE_URL") or None


def get_llm_text_model() -> str | None:
    """读 LLM_TEXT_MODEL env，缺则 None（调用方使用内置 DEFAULT_TEXT_MODEL）。"""
    return os.environ.get("LLM_TEXT_MODEL") or None


def get_llm_vision_model() -> str | None:
    """读 LLM_VISION_MODEL env，缺则 None。"""
    return os.environ.get("LLM_VISION_MODEL") or None


def get_llm_image_model() -> str | None:
    """读 LLM_IMAGE_MODEL env，缺则 None。"""
    return os.environ.get("LLM_IMAGE_MODEL") or None


def get_scholai_api_key() -> str | None:
    """读 SCHOLAI_API_KEY env，缺则 None。"""
    return os.environ.get("SCHOLAI_API_KEY")


def get_scholai_api_url() -> str:
    """读 SCHOLAI_API_URL env，缺则默认。返回值不以 `/` 结尾，方便调用方拼接。"""
    return (os.environ.get("SCHOLAI_API_URL") or DEFAULT_SCHOLAI_API_URL).rstrip("/")
