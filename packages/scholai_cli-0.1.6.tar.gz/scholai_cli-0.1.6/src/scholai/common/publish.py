"""publish atom: POST workspace artifact to scholai 平台。MVP 仅支持 kind=article。"""
from __future__ import annotations

import argparse
import json
import sys

import requests
from urllib.parse import urljoin

from scholai.common.credentials_reader import get_scholai_api_key, get_scholai_api_url
from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger


_PUBLISH_PATH = "/api/document"


def _resolve_content(run_id: str, kind: str) -> dict:
    """MVP 仅支持 article。其他 kind 抛 ValueError（白名单原则）。"""
    if kind != "article":
        raise ValueError(f"MVP only supports kind=article, got {kind!r}")
    ws = workspace_path(run_id)
    content = (ws / "output" / "article.html").read_text(encoding="utf-8")
    return {"kind": "article", "content": content}


def run(run_id: str, kind: str) -> dict:
    log = get_run_logger(run_id, "publish")
    try:
        payload = _resolve_content(run_id, kind)
        log.info("resolved content: kind=%s, size=%d bytes", kind, len(payload["content"].encode()))

        api_key = get_scholai_api_key()
        if not api_key:
            raise RuntimeError("SCHOLAI_API_KEY not set")

        endpoint = f"{get_scholai_api_url()}{_PUBLISH_PATH}"
        log.info("POST %s", endpoint)
        resp = requests.post(
            endpoint,
            json=payload,
            headers={"x-api-key": api_key},
            timeout=60,
        )
        log.info("response: HTTP %d", resp.status_code)
        resp.raise_for_status()
        body = resp.json()
        url = body.get("url", "")
        if url.startswith("/"):
            url = urljoin(get_scholai_api_url(), url)
        log.info("published → %s", url)
        out = {"status": "done", "url": url}
        ws = workspace_path(run_id)
        (ws / "output" / "publish.json").write_text(
            json.dumps(out, ensure_ascii=False), encoding="utf-8"
        )
        return out
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    ap.add_argument("--kind", required=True, help="article (only kind in MVP)")
    args = ap.parse_args()
    result = run(args.run_id, args.kind)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
