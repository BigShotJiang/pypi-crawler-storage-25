"""Typer subcommand group: `scholai course <atom> --run-id <id>`.

薄壳,把 CLI 参数映射到 atom 的 run() 纯函数,打印 JSON,按 status 设 exit code。
"""
from __future__ import annotations

import json
import os
import sys

import typer

from scholai.course.atoms.vfd_url import run as vfd_url_run
from scholai.course.atoms.iod import run as iod_run
from scholai.course.atoms.pd import run as pd_run
from scholai.course.atoms.txd_gen import run as txd_gen_run
from scholai.course.atoms.txd_imagegen import run as txd_imagegen_run
from scholai.course.atoms.txd_render_html import run as txd_render_html_run
from scholai.common.publish import run as publish_run


course_app = typer.Typer(
    name="course",
    help="Courseware pipeline atoms (vfd/iod/pd/txd/publish).",
    no_args_is_help=True,
)


def _emit(result: dict) -> None:
    typer.echo(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result.get("status") == "done" else 1)


def _enter_atom(run_id: str, skill: str, atom: str) -> None:
    os.environ["SCHOLAI_RUN_ID"] = run_id
    os.environ["SCHOLAI_SKILL"] = skill
    os.environ["SCHOLAI_ATOM"] = atom


@course_app.command("vfd-url")
def cmd_vfd_url(run_id: str = typer.Option(..., "--run-id", help="Run identifier")):
    """Extract VFD.json from input/url.txt."""
    _enter_atom(run_id, "article", "vfd_url")
    _emit(vfd_url_run(run_id))


@course_app.command("iod")
def cmd_iod(run_id: str = typer.Option(..., "--run-id")):
    """Generate IOD.json from VFD.json (Gemini structured output)."""
    _enter_atom(run_id, "article", "iod")
    _emit(iod_run(run_id))


@course_app.command("pd")
def cmd_pd(run_id: str = typer.Option(..., "--run-id")):
    """Generate PD.md (teacher-facing design) from VFD + IOD."""
    _enter_atom(run_id, "article", "pd")
    _emit(pd_run(run_id))


@course_app.command("txd-gen")
def cmd_txd_gen(run_id: str = typer.Option(..., "--run-id")):
    """Generate TXD.md with image-slot placeholders."""
    _enter_atom(run_id, "article", "txd_gen")
    _emit(txd_gen_run(run_id))


@course_app.command("txd-imagegen")
def cmd_txd_imagegen(run_id: str = typer.Option(..., "--run-id")):
    """Fill image slots in TXD.md -> TXD_final.md + intermediate/images/*.jpg."""
    _enter_atom(run_id, "article", "txd_imagegen")
    _emit(txd_imagegen_run(run_id))


@course_app.command("txd-render-html")
def cmd_txd_render_html(run_id: str = typer.Option(..., "--run-id")):
    """Render TXD_final.md -> output/article.html with inline base64 images."""
    _enter_atom(run_id, "article", "txd_render_html")
    _emit(txd_render_html_run(run_id))


@course_app.command("publish")
def cmd_publish(
    run_id: str = typer.Option(..., "--run-id"),
    kind: str = typer.Option(..., "--kind", help="article (only kind in MVP)"),
):
    """POST workspace artifact to scholai backend by kind."""
    _emit(publish_run(run_id, kind))
