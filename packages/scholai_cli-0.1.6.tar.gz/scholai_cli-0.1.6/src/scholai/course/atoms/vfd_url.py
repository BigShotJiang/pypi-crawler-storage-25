"""vfd_url atom: 从 input/url.txt 抓网页 → VFD.json。"""
from __future__ import annotations

import argparse
import json
import sys

from curl_cffi import requests
from bs4 import BeautifulSoup

from scholai.runtime.workspace import workspace_path
from scholai.runtime.run_logger import get_run_logger
from scholai.course.schemas.vfd import VFD, VFDFragment


# baike.baidu.com (and other IDC-strict sites) gate on TLS / HTTP2 fingerprint,
# not just headers — vanilla `requests` shows OpenSSL's JA3, not Chrome's, and
# returns 403 + a "百度安全验证" page from non-residential IPs even with full
# browser headers. curl_cffi's `impersonate` aligns the TLS hello, ALPN, and
# HTTP/2 frame ordering with real Chrome 124, which is what gets through.
def _fetch_html(url: str) -> str:
    r = requests.get(
        url,
        impersonate="chrome124",
        timeout=30,
        headers={"Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8"},
    )
    r.raise_for_status()
    return r.text


def _parse_html(url: str, html: str) -> VFD:
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.string.strip() if soup.title and soup.title.string else url
    paragraphs = [p.get_text(strip=True) for p in soup.find_all(["p", "h1", "h2", "h3", "li"])]
    paragraphs = [p for p in paragraphs if p]
    fragments = [
        VFDFragment(ref=f"section={i}", content=p)
        for i, p in enumerate(paragraphs)
    ]
    summary = " ".join(paragraphs[:3])[:300] if paragraphs else ""
    return VFD(
        source_type="url", source_uri=url, subject=title,
        summary=summary, fragments=fragments,
    )


def run(run_id: str) -> dict:
    log = get_run_logger(run_id, "vfd_url")
    ws = workspace_path(run_id)
    url_file = ws / "input" / "url.txt"
    out_path = ws / "intermediate" / "VFD.json"
    try:
        url = url_file.read_text(encoding="utf-8").strip()
        log.info("fetching %s", url)
        html = _fetch_html(url)
        log.info("fetched %d bytes", len(html))
        vfd = _parse_html(url, html)
        log.info("parsed %d fragments, subject=%r", len(vfd.fragments), vfd.subject)
        out_path.write_text(vfd.model_dump_json(indent=2), encoding="utf-8")
        log.info("done → %s", out_path.relative_to(ws))
        return {"status": "done", "path": "intermediate/VFD.json"}
    except Exception as e:
        log.error("failed: %s: %s", type(e).__name__, e)
        return {"status": "failed", "error": f"{type(e).__name__}: {e}"}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-id", required=True)
    args = ap.parse_args()
    result = run(args.run_id)
    print(json.dumps(result, ensure_ascii=False))
    sys.exit(0 if result["status"] == "done" else 1)


if __name__ == "__main__":
    main()
