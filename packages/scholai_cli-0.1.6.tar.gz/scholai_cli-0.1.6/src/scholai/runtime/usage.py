"""Best-effort token/image usage recorder.

Writes two JSONL files per call:
  - per-run:  <openclaw_home>/agents/<bot_id>/workspace/runs/<run_id>/logs/usage.jsonl
  - central:  <openclaw_home>/usage/<YYYY-MM-DD>.jsonl

All public functions swallow every exception — recording must never break the main flow.
"""
from __future__ import annotations

import json
import logging
import os
from datetime import date, datetime, timezone
from pathlib import Path

_log = logging.getLogger("scholai.usage")


def _openclaw_home() -> Path:
    return Path(
        os.environ.get("OPENCLAW_STATE_DIR")
        or os.environ.get("OPENCLAW_HOME")
        or (Path.home() / ".openclaw")
    )


def _event_paths() -> tuple[Path, Path] | None:
    run_id = os.environ.get("SCHOLAI_RUN_ID")
    if not run_id:
        return None
    bot_id = os.environ.get("OPENCLAW_AGENT_ID", "default")
    home = _openclaw_home()
    per_run = home / "agents" / bot_id / "workspace" / "runs" / run_id / "logs" / "usage.jsonl"
    central = home / "scholai-usage" / f"{date.today().isoformat()}.jsonl"
    return per_run, central


def _extract_cached_tokens(usage_obj) -> int:
    v = getattr(usage_obj, "prompt_cache_hit_tokens", None)
    if v is not None:
        return int(v)
    details = getattr(usage_obj, "prompt_tokens_details", None)
    if details:
        v = getattr(details, "cached_tokens", None)
        if v is not None:
            return int(v)
    return 0


def _append_jsonl(path: Path, event: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, mode="a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def record_chat(model: str, response) -> None:
    try:
        paths = _event_paths()
        if paths is None:
            return
        usage = getattr(response, "usage", None)
        if usage is None:
            return
        event = {
            "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "kind": "chat",
            "run_id": os.environ.get("SCHOLAI_RUN_ID", ""),
            "bot_id": os.environ.get("OPENCLAW_AGENT_ID", "default"),
            "skill": os.environ.get("SCHOLAI_SKILL", ""),
            "atom": os.environ.get("SCHOLAI_ATOM", ""),
            "model": model,
            "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
            "cached_tokens": _extract_cached_tokens(usage),
            "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
            "total_tokens": getattr(usage, "total_tokens", 0) or 0,
        }
        per_run, central = paths
        _append_jsonl(per_run, event)
        _append_jsonl(central, event)
        _log.debug("usage recorded: %s", event)
    except Exception:
        pass


def record_image(model: str, size: str, count: int = 1) -> None:
    try:
        paths = _event_paths()
        if paths is None:
            return
        event = {
            "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "kind": "image",
            "run_id": os.environ.get("SCHOLAI_RUN_ID", ""),
            "bot_id": os.environ.get("OPENCLAW_AGENT_ID", "default"),
            "skill": os.environ.get("SCHOLAI_SKILL", ""),
            "atom": os.environ.get("SCHOLAI_ATOM", ""),
            "model": model,
            "size": size,
            "count": count,
        }
        per_run, central = paths
        _append_jsonl(per_run, event)
        _append_jsonl(central, event)
        _log.debug("usage recorded: %s", event)
    except Exception:
        pass
