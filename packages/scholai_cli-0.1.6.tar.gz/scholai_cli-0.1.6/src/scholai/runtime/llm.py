"""OpenAI-compatible LLM client. All calls go through the openai SDK."""
from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import TypeVar

from pydantic import BaseModel

from scholai.common.credentials_reader import (
    get_llm_api_key,
    get_llm_base_url,
    get_llm_image_model,
    get_llm_text_model,
    get_llm_vision_model,
)
from scholai.runtime import usage

T = TypeVar("T", bound=BaseModel)


class LLMError(RuntimeError):
    """Wraps openai SDK errors so atom layer only catches LLMError."""
    pass


def _get_api_key(api_key: str | None = None) -> str:
    key = api_key or get_llm_api_key()
    if not key:
        raise LLMError("LLM_API_KEY not set; 跑 `scholai setup` 或 export LLM_API_KEY。")
    return key


def _get_text_model(model: str | None) -> str:
    resolved = model or get_llm_text_model()
    if not resolved:
        raise LLMError("LLM_TEXT_MODEL not set; 跑 `scholai setup` 或 export LLM_TEXT_MODEL。")
    return resolved


def _get_vision_model(model: str | None) -> str:
    resolved = model or get_llm_vision_model()
    if not resolved:
        raise LLMError("LLM_VISION_MODEL not set; 跑 `scholai setup` 或 export LLM_VISION_MODEL。")
    return resolved


def _get_image_model() -> str:
    resolved = get_llm_image_model()
    if not resolved:
        raise LLMError("LLM_IMAGE_MODEL not set; 跑 `scholai setup` 或 export LLM_IMAGE_MODEL。")
    return resolved


def _get_base_url() -> str:
    resolved = get_llm_base_url()
    if not resolved:
        raise LLMError("LLM_BASE_URL not set; 跑 `scholai setup` 或 export LLM_BASE_URL。")
    return resolved


def _make_client(api_key: str):
    from openai import OpenAI
    return OpenAI(api_key=api_key, base_url=_get_base_url())


def _llm_chat(*, messages: list[dict], model: str, temperature: float,
              api_key: str, response_format: dict | None = None):
    """Single SDK call entry point — mock this in tests."""
    kwargs: dict = {"model": model, "messages": messages, "temperature": temperature}
    if response_format:
        kwargs["response_format"] = response_format
    resp = _make_client(api_key).chat.completions.create(**kwargs)
    usage.record_chat(model, resp)
    return resp


def _llm_image_generate(*, prompt: str, model: str, api_key: str, size: str) -> bytes:
    """Image generation entry point — mock this in tests.

    Handles both response formats:
    - b64_json: OpenAI / providers that honour response_format="b64_json"
    - url: GLM CogView and other providers that always return a URL
    """
    resp = _make_client(api_key).images.generate(
        model=model,
        prompt=prompt,
        n=1,
        size=size,
        response_format="b64_json",  # hint only; some providers ignore and return url
    )
    item = resp.data[0] if resp.data else None
    if not item:
        raise LLMError("image generation: empty response")
    if item.b64_json:
        data = base64.b64decode(item.b64_json)
    elif item.url:
        import urllib.request
        with urllib.request.urlopen(item.url, timeout=30) as r:
            data = r.read()
    else:
        raise LLMError("image generation: no b64_json or url in response")
    usage.record_image(model, size, 1)
    return data


def llm_structured(prompt: str, response_schema: type[T],
                   model: str | None = None,
                   temperature: float = 0.3,
                   api_key: str | None = None) -> T:
    """返回 response_schema 实例，使用 json_object 模式约束输出。

    将 Pydantic schema 注入 prompt 末尾，避免模型自行包裹额外键。
    """
    schema_str = json.dumps(response_schema.model_json_schema(), ensure_ascii=False, indent=2)
    augmented = (
        f"{prompt}\n\n"
        f"请严格按以下 JSON Schema 输出顶层字段，不要用任何额外键包裹：\n{schema_str}"
    )
    resp = _llm_chat(
        messages=[{"role": "user", "content": augmented}],
        model=_get_text_model(model),
        temperature=temperature,
        api_key=_get_api_key(api_key),
        response_format={"type": "json_object"},
    )
    return response_schema.model_validate_json(resp.choices[0].message.content)


def llm_text(prompt: str, model: str | None = None,
             temperature: float = 0.5,
             api_key: str | None = None) -> str:
    resp = _llm_chat(
        messages=[{"role": "user", "content": prompt}],
        model=_get_text_model(model),
        temperature=temperature,
        api_key=_get_api_key(api_key),
    )
    return resp.choices[0].message.content


def llm_vision(prompt: str, images: list[Path],
               model: str | None = None,
               temperature: float = 0.3,
               api_key: str | None = None) -> str:
    content: list[dict] = [{"type": "text", "text": prompt}]
    for p in images:
        b64 = base64.b64encode(p.read_bytes()).decode()
        content.append({"type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{b64}"}})
    resp = _llm_chat(
        messages=[{"role": "user", "content": content}],
        model=_get_vision_model(model),
        temperature=temperature,
        api_key=_get_api_key(api_key),
    )
    return resp.choices[0].message.content


def llm_image_gen(prompt: str, aspect_ratio: str = "1:1",
                  api_key: str | None = None) -> bytes:
    model = _get_image_model()
    if model.startswith("doubao"):
        size = "2k"
    elif model.startswith("cogView"):
        size = "512x512"
    else:
        size = "2k"
    return _llm_image_generate(
        prompt=f"{prompt}\n\n(aspect ratio: {aspect_ratio})",
        model=model,
        api_key=_get_api_key(api_key),
        size=size,
    )
