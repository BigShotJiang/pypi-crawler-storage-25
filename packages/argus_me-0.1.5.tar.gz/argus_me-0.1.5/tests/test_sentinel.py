"""Tests for sentinel — stats preamble + cognitive debt scanning."""

from datetime import date, timedelta

from conftest import insert_matter, insert_run


def _make_db(tmp_path):
    from argus_me.models import ensure_self, init_db

    db_path = str(tmp_path / "memory.db")
    init_db(db_path)
    ensure_self(db_path, "Wang Yu")
    return db_path


class TestGeneratePreamble:
    """Stats preamble for LLM prompt injection."""

    def test_should_include_emotion_trend(self, tmp_path):
        from argus_me.sentinel import generate_preamble

        db_path = _make_db(tmp_path)
        today = date.today()
        for i in range(7):
            d = (today - timedelta(days=i)).isoformat()
            insert_run(db_path, run_date=d, valence=-0.1 * i)

        preamble = generate_preamble(db_path)
        assert "emotion_trend" in preamble
        assert "direction" in preamble["emotion_trend"]

    def test_should_include_matter_staleness(self, tmp_path):
        from argus_me.sentinel import generate_preamble

        db_path = _make_db(tmp_path)
        old_date = (date.today() - timedelta(days=14)).isoformat()
        insert_matter(db_path, "Stale task", opened_date=old_date)
        insert_run(db_path, run_date=old_date, summary="Mentioned stale task")

        preamble = generate_preamble(db_path)
        assert "matter_staleness" in preamble
        assert len(preamble["matter_staleness"]) >= 1

    def test_should_handle_empty_db(self, tmp_path):
        from argus_me.sentinel import generate_preamble

        db_path = _make_db(tmp_path)
        assert isinstance(generate_preamble(db_path), dict)


class TestScanDebts:
    """Cognitive debt detection."""

    def test_should_detect_stale_matter(self, tmp_path):
        from argus_me.sentinel import scan_debts

        db_path = _make_db(tmp_path)
        old_date = (date.today() - timedelta(days=10)).isoformat()
        insert_matter(db_path, "Forgotten task", opened_date=old_date)
        insert_run(db_path, run_date=old_date, summary="Mentioned forgotten task")

        stale = [i for i in scan_debts(db_path) if i["type"] == "stale_matter"]
        assert len(stale) >= 1
        assert "Forgotten task" in stale[0]["description"]

    def test_should_detect_emotion_inflection(self, tmp_path):
        from argus_me.sentinel import scan_debts

        db_path = _make_db(tmp_path)
        today = date.today()
        for i in range(4):
            d = (today - timedelta(days=3 - i)).isoformat()
            insert_run(db_path, run_date=d, valence=-0.2 * i)

        inflections = [i for i in scan_debts(db_path) if i["type"] == "emotion_inflection"]
        assert len(inflections) >= 1

    def test_should_handle_empty_db(self, tmp_path):
        from argus_me.sentinel import scan_debts

        assert isinstance(scan_debts(_make_db(tmp_path)), list)


class TestWriteInsights:
    """Insight queue writes with dedup."""

    def test_should_insert_to_queue(self, tmp_path):
        from argus_me.models import connect
        from argus_me.sentinel import write_insights

        db_path = _make_db(tmp_path)
        write_insights(
            db_path,
            [
                {
                    "type": "stale_matter",
                    "description": "Task X inactive 10 days",
                    "priority": "medium",
                }
            ],
        )

        conn = connect(db_path)
        rows = conn.execute("SELECT * FROM insight_queue").fetchall()
        assert len(rows) == 1
        assert rows[0]["type"] == "stale_matter"
        conn.close()

    def test_should_dedup_within_7_days(self, tmp_path):
        from argus_me.models import connect
        from argus_me.sentinel import write_insights

        db_path = _make_db(tmp_path)
        insight = {"type": "stale_matter", "description": "Task X inactive", "priority": "medium"}
        write_insights(db_path, [insight])
        write_insights(db_path, [insight])

        conn = connect(db_path)
        assert conn.execute("SELECT COUNT(*) FROM insight_queue").fetchone()[0] == 1
        conn.close()


class TestAntibiasScanning:
    """Anti-bias detection scanners."""

    def test_should_detect_echo_chamber_risk(self, tmp_path):
        from datetime import date, timedelta

        from argus_me.models import write_fragment
        from argus_me.sentinel import scan_antibias

        db_path = _make_db(tmp_path)
        today = date.today()
        insert_entity_helper(db_path, "Tom")
        for i in range(10):
            d = (today - timedelta(days=i)).isoformat()
            write_fragment(db_path, text=f"Met Tom again on day {i}", date=d)

        assert isinstance(scan_antibias(db_path), list)

    def test_should_handle_empty_db(self, tmp_path):
        from argus_me.sentinel import scan_antibias

        assert isinstance(scan_antibias(_make_db(tmp_path)), list)


def insert_entity_helper(db_path, name):
    from conftest import insert_entity

    insert_entity(db_path, name, date=date.today().isoformat())
