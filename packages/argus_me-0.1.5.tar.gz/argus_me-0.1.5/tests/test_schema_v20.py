"""Tests for schema v20 migration — epochs + observations + runs.epoch_id."""

import sqlite3


def _make_v19_db(tmp_path):
    """Create a v19 database with test data."""
    from argus_me.models import _SCHEMA_SQL, connect

    db_path = str(tmp_path / "memory.db")
    conn = connect(db_path)
    conn.executescript(_SCHEMA_SQL)
    conn.execute("INSERT INTO meta (key, value) VALUES ('schema_version', '19')")
    conn.execute(
        "INSERT INTO entities"
        " (id, canonical_name, first_seen, last_seen, created_at, updated_at)"
        " VALUES ('self', 'Wang Yu', '2026-01-01', '2026-03-30', '2026-01-01', '2026-03-30')"
    )
    conn.execute(
        "INSERT INTO runs (date, run_id, summary, created_at)"
        " VALUES ('2026-03-28', 'run-001', 'Test run', '2026-03-28')"
    )
    conn.commit()
    conn.close()
    return db_path


class TestSchemaV20Migration:
    """Migration from v19 to v20."""

    def test_should_create_epochs_table(self, tmp_path):
        from argus_me.models import connect, init_db

        db_path = _make_v19_db(tmp_path)
        init_db(db_path)

        conn = connect(db_path)
        tables = {
            r["name"]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        assert "epochs" in tables
        conn.close()

    def test_should_create_observations_table(self, tmp_path):
        from argus_me.models import connect, init_db

        db_path = _make_v19_db(tmp_path)
        init_db(db_path)

        conn = connect(db_path)
        tables = {
            r["name"]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        assert "observations" in tables
        conn.close()

    def test_should_add_epoch_id_to_runs(self, tmp_path):
        from argus_me.models import connect, init_db

        db_path = _make_v19_db(tmp_path)
        init_db(db_path)

        conn = connect(db_path)
        cols = {
            r["name"]
            for r in conn.execute("PRAGMA table_info(runs)").fetchall()
        }
        assert "epoch_id" in cols
        conn.close()

    def test_should_update_schema_version_to_20(self, tmp_path):
        from argus_me.models import connect, init_db

        db_path = _make_v19_db(tmp_path)
        init_db(db_path)

        conn = connect(db_path)
        version = conn.execute(
            "SELECT value FROM meta WHERE key='schema_version'"
        ).fetchone()["value"]
        assert version == "20"
        conn.close()

    def test_should_preserve_existing_data(self, tmp_path):
        from argus_me.models import connect, init_db

        db_path = _make_v19_db(tmp_path)
        init_db(db_path)

        conn = connect(db_path)
        entity = conn.execute(
            "SELECT canonical_name FROM entities WHERE id='self'"
        ).fetchone()
        assert entity["canonical_name"] == "Wang Yu"

        run = conn.execute("SELECT summary FROM runs").fetchone()
        assert run["summary"] == "Test run"
        conn.close()

    def test_should_be_idempotent(self, tmp_path):
        from argus_me.models import connect, init_db

        db_path = _make_v19_db(tmp_path)
        init_db(db_path)
        init_db(db_path)  # second call

        conn = connect(db_path)
        version = conn.execute(
            "SELECT value FROM meta WHERE key='schema_version'"
        ).fetchone()["value"]
        assert version == "20"
        conn.close()

    def test_should_set_v20_for_fresh_db(self, tmp_path):
        from argus_me.models import connect, init_db

        db_path = str(tmp_path / "fresh.db")
        init_db(db_path)

        conn = connect(db_path)
        version = conn.execute(
            "SELECT value FROM meta WHERE key='schema_version'"
        ).fetchone()["value"]
        assert version == "20"

        tables = {
            r["name"]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        assert "epochs" in tables
        assert "observations" in tables
        conn.close()

    def test_existing_runs_should_have_null_epoch_id(self, tmp_path):
        from argus_me.models import connect, init_db

        db_path = _make_v19_db(tmp_path)
        init_db(db_path)

        conn = connect(db_path)
        run = conn.execute("SELECT epoch_id FROM runs").fetchone()
        assert run["epoch_id"] is None
        conn.close()
