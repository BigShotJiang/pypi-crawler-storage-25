"""Tests for pipeline context injection — preamble, insights, user notes."""

from datetime import date, timedelta

from argus_me.models import connect, write_fragment
from conftest import insert_matter, insert_run, make_mock_llm


def _seed_and_run(me):
    """Build history so sentinel produces preamble + insights."""
    today = date.today()
    insert_matter(
        me.db_path,
        "Old project",
        opened_date=(today - timedelta(days=15)).isoformat(),
    )
    insert_run(
        me.db_path,
        run_date=(today - timedelta(days=15)).isoformat(),
        summary="Worked on old project",
        valence=-0.2,
    )
    for i in range(3):
        insert_run(
            me.db_path,
            run_date=(today - timedelta(days=2 - i)).isoformat(),
            summary=f"Day {i} activities",
            valence=-0.1 * (i + 1),
        )
    write_fragment(
        me.db_path,
        text="User dismissed: Old project",
        date=(today - timedelta(days=1)).isoformat(),
        fragment_type="action",
        source="user_action",
    )


class TestUserNotesInjection:
    """Recent action fragments should be injected into Call 2."""

    def test_should_inject_user_notes_into_call2(self, me, monkeypatch):
        _seed_and_run(me)

        # First understand to generate insights
        me.ingest("New day.")
        monkeypatch.setattr("argus_me.etl.call_llm", make_mock_llm())
        me.understand()

        # Second understand — fresh mock to capture prompts
        me.ingest("Another day.")
        prompts = []
        monkeypatch.setattr("argus_me.etl.call_llm", make_mock_llm(capture=prompts))
        me.understand()

        call2 = prompts[1]
        assert "dismissed" in call2.lower() or "Old project" in call2


class TestInsightsProperty:
    """me.insights should expose pending insights."""

    def test_should_return_pending_insights(self, me, mock_llm):
        _seed_and_run(me)
        me.ingest("Testing.")
        me.understand()
        assert isinstance(me.insights, list)

    def test_should_return_empty_when_no_insights(self, me):
        assert me.insights == []


class TestAnswer:
    """me.answer(gap_id, response)."""

    def test_should_record_fragment(self, me):
        me.answer("gap-001", "Yes, that project is still active.")

        conn = connect(me.db_path)
        frags = conn.execute("SELECT * FROM fragments WHERE type='action'").fetchall()
        assert len(frags) == 1
        assert "still active" in frags[0]["transcript"]
        conn.close()


class TestIntentionSurfacing:
    """High-confidence intentions should surface as insights."""

    def test_should_surface_when_confidence_crosses_threshold(self, me):
        from argus_me.sentinel import (
            get_active_intentions,
            run_subconscious,
            write_intention,
        )

        write_intention(
            me.db_path,
            content="Abandoning old project",
            intention_type="implicit",
            confidence=0.75,
        )
        run_subconscious(me.db_path)

        conn = connect(me.db_path)
        insights = conn.execute(
            "SELECT * FROM insight_queue WHERE type='implicit_intention'"
        ).fetchall()
        assert len(insights) >= 1
        assert "Abandoning" in insights[0]["description"]

        surfaced = [
            i for i in get_active_intentions(me.db_path) if i.get("surfaced_at") is not None
        ]
        assert len(surfaced) >= 1
        conn.close()

    def test_should_not_surface_low_confidence(self, me):
        from argus_me.sentinel import run_subconscious, write_intention

        write_intention(
            me.db_path,
            content="Maybe avoiding something",
            intention_type="implicit",
            confidence=0.3,
        )
        run_subconscious(me.db_path)

        conn = connect(me.db_path)
        insights = conn.execute(
            "SELECT * FROM insight_queue WHERE type='implicit_intention'"
        ).fetchall()
        assert len(insights) == 0
        conn.close()
