"""Tests for Me class — constructor and ingest."""

import sqlite3


class TestMeConstructor:
    """Me class instantiation."""

    def test_should_create_db_when_path_not_exists(self, tmp_path):
        from argus_me import Me

        db_path = str(tmp_path / "new.db")
        Me(
            name="Wang Yu",
            db_path=db_path,
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
        )
        conn = sqlite3.connect(db_path)
        tables = {
            r[0]
            for r in conn.execute(
                "SELECT name FROM sqlite_master" " WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        }
        assert "fragments" in tables
        assert "entities" in tables
        conn.close()

    def test_should_create_self_entity_when_instantiated(self, tmp_path):
        from argus_me import Me

        db_path = str(tmp_path / "memory.db")
        Me(
            name="Wang Yu",
            db_path=db_path,
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
        )
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        row = conn.execute("SELECT canonical_name FROM entities WHERE id='self'").fetchone()
        assert row["canonical_name"] == "Wang Yu"
        conn.close()

    def test_should_store_config_when_instantiated(self, tmp_path):
        from argus_me import Me

        db_path = str(tmp_path / "memory.db")
        me = Me(
            name="Wang Yu",
            db_path=db_path,
            llm_base_url="http://localhost:11434/v1",
            llm_model="qwen2.5:32b",
            redact=True,
            prompt_dir="./prompts",
        )
        assert me.name == "Wang Yu"
        assert me.db_path == db_path
        assert me.redact is True


class TestMeIngest:
    """Me.ingest() method."""

    def test_should_create_fragment_when_text_provided(self, me):
        fid = me.ingest("Had coffee with Tom today.")
        assert isinstance(fid, str)
        assert len(fid) > 0

    def test_should_use_today_when_no_date_provided(self, me):
        from datetime import date

        me.ingest("Some text.")
        conn = sqlite3.connect(me.db_path)
        row = conn.execute("SELECT date FROM fragments").fetchone()
        assert row[0] == date.today().isoformat()
        conn.close()

    def test_should_use_custom_date_when_provided(self, me):
        me.ingest("Old conversation.", date="2026-01-15")
        conn = sqlite3.connect(me.db_path)
        row = conn.execute("SELECT date FROM fragments").fetchone()
        assert row[0] == "2026-01-15"
        conn.close()

    def test_should_accumulate_fragments_when_multiple_ingests(self, me):
        me.ingest("Fragment 1.")
        me.ingest("Fragment 2.")
        me.ingest("Fragment 3.")
        conn = sqlite3.connect(me.db_path)
        count = conn.execute("SELECT COUNT(*) FROM fragments WHERE processed=0").fetchone()[0]
        assert count == 3
        conn.close()
