"""Tests for argus-redact integration."""

import json

import pytest
from argus_me.redact import is_available

_requires_redact = pytest.mark.skipif(not is_available(), reason="argus-redact not installed")


@pytest.fixture(autouse=True)
def _force_fast_redact(monkeypatch):
    """Force fast mode to avoid NER loading in tests."""
    if not is_available():
        return
    from argus_me.redact import redact_text as _original

    def _fast_redact(text, *, names=None, mode="auto"):
        return _original(text, names=names, mode="fast")

    monkeypatch.setattr("argus_me.redact.redact_text", _fast_redact)


def _make_me(tmp_path, *, redact=True):
    from argus_me import Me

    db_path = str(tmp_path / "memory.db")
    return Me(
        name="Wang Yu",
        db_path=db_path,
        llm_base_url="http://localhost:11434/v1",
        llm_model="qwen2.5:32b",
        redact=redact,
    )


@_requires_redact
class TestRedactIntegration:
    """PII redaction in the understand() pipeline."""

    def test_should_redact_before_llm_and_restore_after(self, tmp_path, monkeypatch):
        me = _make_me(tmp_path, redact=True)
        me.ingest("和王五聊了聊，他的手机是13812345678")

        prompts_seen = []

        def mock_call_llm(client, model, prompt, **kwargs):
            prompts_seen.append(prompt)
            responses = [
                json.dumps({"resolutions": [], "self_profile_delta": []}),
                json.dumps(
                    {
                        "summary": "Had a chat with P-001.",
                        "conflict": "",
                        "emotion": "neutral",
                        "valence": 0.0,
                        "arousal": 0.3,
                        "persons": [{"name": "P-001", "role": "friend", "dynamics": 0.0}],
                        "new_matters": [],
                        "dismissed": [],
                        "gaps": [],
                    }
                ),
                json.dumps({"conflict": "", "gaps": [], "self_observations": []}),
                json.dumps([]),
            ]
            idx = len(prompts_seen) - 1
            return responses[min(idx, len(responses) - 1)], {
                "model": "mock",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "duration_s": 0,
            }

        monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)

        result = me.understand()

        # LLM should NOT see real PII
        for prompt in prompts_seen:
            assert "13812345678" not in prompt
            assert "王五" not in prompt

        assert result["fragments_processed"] == 1

    def test_should_skip_redaction_when_redact_false(self, tmp_path, monkeypatch):
        me = _make_me(tmp_path, redact=False)
        me.ingest("和王五聊了聊，他的手机是13812345678")

        prompts_seen = []

        def mock_call_llm(client, model, prompt, **kwargs):
            prompts_seen.append(prompt)
            responses = [
                json.dumps({"resolutions": [], "self_profile_delta": []}),
                json.dumps(
                    {
                        "summary": "Chatted with 王五.",
                        "conflict": "",
                        "emotion": "neutral",
                        "valence": 0.0,
                        "arousal": 0.3,
                        "persons": [],
                        "new_matters": [],
                        "dismissed": [],
                        "gaps": [],
                    }
                ),
                json.dumps({"conflict": "", "gaps": [], "self_observations": []}),
                json.dumps([]),
            ]
            idx = len(prompts_seen) - 1
            return responses[min(idx, len(responses) - 1)], {
                "model": "mock",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "duration_s": 0,
            }

        monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)
        me.understand()

        # Without redaction, LLM sees real text
        assert any("王五" in p for p in prompts_seen)


@_requires_redact
class TestRedactModule:
    """argus_me.redact wrapper module."""

    def test_should_redact_and_return_key(self):
        from argus_me.redact import redact_text

        text = "王五的手机是13812345678"
        redacted, key = redact_text(text, names=["王五"], mode="fast")
        assert "13812345678" not in redacted
        assert isinstance(key, dict)

    def test_should_restore_from_key(self):
        from argus_me.redact import redact_text, restore_text

        text = "王五的手机是13812345678"
        redacted, key = redact_text(text, names=["王五"], mode="fast")
        restored = restore_text(redacted, key)
        assert "13812345678" in restored

    def test_should_return_original_when_no_pii(self):
        from argus_me.redact import redact_text

        text = "今天天气不错"
        redacted, key = redact_text(text, mode="fast")
        assert redacted == text
        assert key == {}
