"""Shared fixtures, helpers, and mock data for all tests."""

import json

import pytest
import uuid6

# ── Fixtures ───────────────────────────────────────────────


@pytest.fixture
def tmp_db(tmp_path):
    """Return a path string for a fresh temporary database."""
    return str(tmp_path / "memory.db")


@pytest.fixture
def memory_db(tmp_db):
    """Return an initialized memory.db path (schema applied)."""
    from argus_me.models import init_db

    init_db(tmp_db)
    return tmp_db


@pytest.fixture
def conn(memory_db):
    """Return a connection to an initialized memory.db (same settings as production)."""
    from argus_me.models import connect

    c = connect(memory_db)
    yield c
    c.close()


@pytest.fixture
def me(tmp_path):
    """Return a fresh Me instance with default config."""
    from argus_me import Me

    return Me(
        name="Wang Yu",
        db_path=str(tmp_path / "memory.db"),
        llm_base_url="http://localhost:11434/v1",
        llm_model="qwen2.5:32b",
    )


@pytest.fixture
def me_redact(tmp_path):
    """Return a fresh Me instance with redact=True."""
    from argus_me import Me

    return Me(
        name="Wang Yu",
        db_path=str(tmp_path / "memory.db"),
        llm_base_url="http://localhost:11434/v1",
        llm_model="qwen2.5:32b",
        redact=True,
    )


# ── Mock LLM data ─────────────────────────────────────────

MOCK_CALL1 = {
    "resolutions": [
        {"mention": "Tom", "resolved_to": "Tom", "confidence": 0.95},
    ],
    "self_profile_delta": ["Called 'team lead' by Tom"],
}

MOCK_CALL2 = {
    "summary": "Met with Tom about product launch.",
    "conflict": "Timeline vs quality",
    "emotion": "anxious",
    "valence": -0.3,
    "arousal": 0.6,
    "persons": [{"name": "Tom", "role": "colleague", "dynamics": 0.4}],
    "new_matters": [
        {"name": "Product launch", "current": "Design phase", "who": ["Tom"]},
    ],
    "dismissed": [],
    "gaps": [
        {
            "type": "open_loop",
            "description": "Tom's timeline estimate",
            "size": "medium",
            "impact": "high",
        }
    ],
}

MOCK_CALL3 = {
    "conflict": "Deeper tension: wanting perfection but running out of time",
    "gaps": [
        {
            "type": "self_identity",
            "description": "Am I a perfectionist or pragmatist?",
            "size": "medium",
            "impact": "medium",
        }
    ],
    "self_observations": ["Tends to delay decisions under pressure"],
}

MOCK_CALL4 = [
    {
        "matter_id": None,
        "event": "Design approved by Friday",
        "narrative": "Tom pushes through review quickly",
        "confidence": "high",
        "historical_precedent": "Similar to Q1 rush",
    },
]

MOCK_METRICS = {
    "model": "qwen2.5:32b",
    "prompt_tokens": 500,
    "completion_tokens": 200,
    "duration_s": 3.0,
}

MOCK_RESPONSES = [
    json.dumps(MOCK_CALL1),
    json.dumps(MOCK_CALL2),
    json.dumps(MOCK_CALL3),
    json.dumps([]),  # Call 4 default empty
]


# ── Mock LLM fixture ──────────────────────────────────────


def make_mock_llm(responses=None, capture=None):
    """Create a mock call_llm function.

    Args:
        responses: list of JSON strings, one per call. Defaults to MOCK_RESPONSES.
        capture: if a list is passed, prompts are appended to it.
    Returns:
        A function suitable for monkeypatch.setattr("argus_me.etl.call_llm", ...)
    """
    if responses is None:
        responses = list(MOCK_RESPONSES)
    call_count = {"i": 0}

    def mock_call_llm(client, model, prompt, **kwargs):
        if capture is not None:
            capture.append(prompt)
        idx = min(call_count["i"], len(responses) - 1)
        call_count["i"] += 1
        return responses[idx], MOCK_METRICS

    return mock_call_llm


@pytest.fixture
def mock_llm(monkeypatch):
    """Fixture that mocks call_llm and returns captured prompts list."""
    prompts = []
    monkeypatch.setattr("argus_me.etl.call_llm", make_mock_llm(capture=prompts))
    return prompts


# ── Data helpers ───────────────────────────────────────────


def insert_run(db_path, *, run_date, summary="", valence=0.0, arousal=0.5, emotion="neutral"):
    """Insert a run record directly into the DB."""
    from argus_me.models import connect

    conn = connect(db_path)
    conn.execute(
        "INSERT INTO runs (date, run_id, summary, valence, arousal,"
        " emotion_word, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?, ?)",
        (run_date, str(uuid6.uuid7()), summary, valence, arousal, emotion, run_date),
    )
    conn.commit()
    conn.close()


def insert_matter(db_path, name, *, opened_date, status="open"):
    """Insert a matter directly into the DB."""
    from argus_me.models import connect

    conn = connect(db_path)
    conn.execute(
        "INSERT INTO matters (name, current, status, opened_date,"
        " created_at, updated_at)"
        " VALUES (?, '', ?, ?, ?, ?)",
        (name, status, opened_date, opened_date, opened_date),
    )
    conn.commit()
    conn.close()


def insert_entity(db_path, name, *, dynamics=0.0, date="2026-01-01"):
    """Insert an entity directly into the DB."""
    from argus_me.models import write_entities

    write_entities(db_path, [{"name": name, "role": "", "dynamics": dynamics}], date=date)


def get_matter_id(db_path, name):
    """Get a matter's ID by name."""
    from argus_me.models import connect

    conn = connect(db_path)
    row = conn.execute("SELECT id FROM matters WHERE name=?", (name,)).fetchone()
    conn.close()
    return row["id"] if row else None


def get_entity_id(db_path, name):
    """Get an entity's ID by canonical_name."""
    from argus_me.models import connect

    conn = connect(db_path)
    row = conn.execute("SELECT id FROM entities WHERE canonical_name=?", (name,)).fetchone()
    conn.close()
    return row["id"] if row else None


def count_action_fragments(db_path):
    """Count action-type fragments in the DB."""
    from argus_me.models import connect

    conn = connect(db_path)
    count = conn.execute("SELECT COUNT(*) FROM fragments WHERE type='action'").fetchone()[0]
    conn.close()
    return count


def seed_history(db_path):
    """Pre-populate DB with entities + runs for context tests."""
    from argus_me.models import write_entities, write_matters, write_run

    write_entities(
        db_path,
        [
            {"name": "Tom", "role": "colleague", "dynamics": 0.3},
            {"name": "Judy", "role": "friend", "dynamics": -0.2},
        ],
        date="2026-03-28",
    )
    write_matters(
        db_path,
        [{"name": "Product launch", "current": "Design phase", "who": ["Tom"]}],
        date="2026-03-28",
    )
    write_run(
        db_path,
        {
            "summary": "Discussed product direction with Tom.",
            "valence": 0.2,
            "arousal": 0.5,
            "emotion_word": "focused",
            "conflict": "Timeline pressure",
            "gaps": [],
        },
        date="2026-03-28",
    )
    write_run(
        db_path,
        {
            "summary": "Judy shared concerns about BigCorp.",
            "valence": -0.3,
            "arousal": 0.6,
            "emotion_word": "worried",
            "conflict": "",
            "gaps": [],
        },
        date="2026-03-29",
    )
