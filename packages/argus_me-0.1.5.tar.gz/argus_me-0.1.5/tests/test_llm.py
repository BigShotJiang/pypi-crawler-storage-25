"""Tests for LLM utilities — pure functions (no LLM calls)."""


class TestDetectSourceType:
    """Detect whether transcript is conversation or diary."""

    def test_should_detect_conv_when_multiple_speakers(self):
        from argus_me.llm import detect_source_type

        transcript = "Judy\n我刚被auditor三个小时\n\nme\n是吗\n\nJudy\n对啊很累"
        assert detect_source_type(transcript) == "conv"

    def test_should_detect_diary_when_no_speaker_labels(self):
        from argus_me.llm import detect_source_type

        transcript = "今天感觉特别累，产品方向还是没想清楚。晚上和Tom聊了一下，他建议我先做MVP。"
        assert detect_source_type(transcript) == "diary"

    def test_should_detect_diary_when_single_speaker(self):
        from argus_me.llm import detect_source_type

        transcript = "me\n今天去了趟医院\n\nme\n检查结果还好"
        assert detect_source_type(transcript) == "diary"

    def test_should_handle_empty_string(self):
        from argus_me.llm import detect_source_type

        assert detect_source_type("") == "diary"


class TestCompressTranscript:
    """Oral transcript compression."""

    def test_should_return_original_when_no_speaker_labels(self):
        from argus_me.llm import compress_transcript

        text = "今天感觉不错"
        compressed, stats = compress_transcript(text)
        assert compressed == text

    def test_should_remove_filler_words(self):
        from argus_me.llm import compress_transcript

        transcript = "me\n嗯 就是说 今天开会了\n\nTom\n对 然后 我们讨论了方案"
        compressed, stats = compress_transcript(transcript)
        assert "就是说" not in compressed
        assert "开会" in compressed

    def test_should_remove_ack_only_turns(self):
        from argus_me.llm import compress_transcript

        transcript = "me\n今天开会了\n\nTom\n嗯嗯\n\nme\n讨论了新方案"
        compressed, stats = compress_transcript(transcript)
        assert stats["turns_removed"] >= 1
        assert "嗯嗯" not in compressed

    def test_should_merge_consecutive_same_speaker(self):
        from argus_me.llm import compress_transcript

        transcript = "me\n第一段话\n\nme\n第二段话"
        compressed, stats = compress_transcript(transcript)
        assert compressed.count("me\n") == 1

    def test_should_return_stats(self):
        from argus_me.llm import compress_transcript

        transcript = "me\n今天开会\n\nTom\n嗯\n\nme\n结束了"
        compressed, stats = compress_transcript(transcript)
        assert "original_chars" in stats
        assert "compressed_chars" in stats
        assert "turns_removed" in stats
        assert "ratio" in stats

    def test_should_handle_empty_string(self):
        from argus_me.llm import compress_transcript

        compressed, stats = compress_transcript("")
        assert compressed == ""


class TestStripThinkTags:
    """Remove reasoning model <think> blocks."""

    def test_should_strip_think_block(self):
        from argus_me.llm import strip_think_tags

        raw = '<think>Let me analyze this...</think>{"summary": "hello"}'
        assert strip_think_tags(raw) == '{"summary": "hello"}'

    def test_should_handle_multiline_think(self):
        from argus_me.llm import strip_think_tags

        raw = '<think>\nStep 1: ...\nStep 2: ...\n</think>\n{"result": true}'
        result = strip_think_tags(raw)
        assert "<think>" not in result
        assert '{"result": true}' in result

    def test_should_return_unchanged_when_no_think_tags(self):
        from argus_me.llm import strip_think_tags

        raw = '{"summary": "hello"}'
        assert strip_think_tags(raw) == raw


class TestParseJson:
    """Robust JSON extraction from LLM output."""

    def test_should_parse_clean_json(self):
        from argus_me.llm import parse_json

        raw = '{"summary": "hello", "valence": -0.3}'
        result = parse_json(raw)
        assert result["summary"] == "hello"
        assert result["valence"] == -0.3

    def test_should_extract_json_from_surrounding_text(self):
        from argus_me.llm import parse_json

        raw = 'Here is my analysis:\n{"summary": "test"}\nDone.'
        result = parse_json(raw)
        assert result["summary"] == "test"

    def test_should_handle_think_tags_before_json(self):
        from argus_me.llm import parse_json

        raw = '<think>reasoning here</think>{"summary": "after think"}'
        result = parse_json(raw)
        assert result["summary"] == "after think"

    def test_should_return_default_when_unparseable(self):
        from argus_me.llm import parse_json

        default = {"fallback": True}
        result = parse_json("this is not json at all", default=default)
        assert result == default

    def test_should_return_empty_default_when_no_default_given(self):
        from argus_me.llm import parse_json

        result = parse_json("not json")
        assert isinstance(result, dict)


class TestParseJsonArray:
    """JSON array extraction from LLM output."""

    def test_should_parse_clean_array(self):
        from argus_me.llm import parse_json_array

        raw = '[{"event": "test", "prob": 0.7}]'
        result = parse_json_array(raw)
        assert len(result) == 1
        assert result[0]["event"] == "test"

    def test_should_extract_array_from_surrounding_text(self):
        from argus_me.llm import parse_json_array

        raw = 'Possibilities:\n[{"event": "a"}, {"event": "b"}]\nEnd.'
        result = parse_json_array(raw)
        assert len(result) == 2

    def test_should_return_empty_list_when_unparseable(self):
        from argus_me.llm import parse_json_array

        result = parse_json_array("no array here")
        assert result == []


class TestLoadTemplate:
    """Jinja2 template loading with fallback."""

    def test_should_load_builtin_template(self):
        from argus_me.llm import load_template

        tmpl = load_template("call1_identity")
        assert tmpl is not None
        rendered = tmpl.render(transcript="test", known_entities="none", self_profile="")
        assert len(rendered) > 0

    def test_should_load_custom_template_when_prompt_dir_set(self, tmp_path):
        from argus_me.llm import load_template

        custom = tmp_path / "call1_identity.j2"
        custom.write_text("CUSTOM: {{ transcript }}")
        tmpl = load_template("call1_identity", prompt_dir=str(tmp_path))
        rendered = tmpl.render(transcript="hello")
        assert rendered == "CUSTOM: hello"

    def test_should_fallback_to_builtin_when_custom_not_found(self, tmp_path):
        from argus_me.llm import load_template

        tmpl = load_template("call1_identity", prompt_dir=str(tmp_path))
        assert tmpl is not None
