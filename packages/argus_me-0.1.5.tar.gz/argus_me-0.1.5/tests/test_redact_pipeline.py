"""Tests for full PII redaction in pipeline — all prompt context redacted.

Uses mode='fast' (regex only) to avoid NER model loading overhead in tests.
"""

import json

import pytest
from argus_me.redact import is_available

_requires_redact = pytest.mark.skipif(not is_available(), reason="argus-redact not installed")


@pytest.fixture(autouse=True)
def _force_fast_redact(monkeypatch):
    """Force fast mode in pipeline redaction to avoid NER loading in tests."""
    if not is_available():
        return
    from argus_me.redact import redact_text as _original

    def _fast_redact(text, *, names=None, mode="auto"):
        return _original(text, names=names, mode="fast")

    monkeypatch.setattr("argus_me.redact.redact_text", _fast_redact)


def _make_me(tmp_path, *, redact=True):
    from argus_me import Me

    db_path = str(tmp_path / "memory.db")
    me = Me(
        name="Wang Yu",
        db_path=db_path,
        llm_base_url="http://localhost:11434/v1",
        llm_model="qwen2.5:32b",
        redact=redact,
    )
    return me


def _seed_entities(me):
    """Pre-populate DB with known entities so they appear in prompts."""
    from argus_me.models import (
        append_self_profile,
        write_entities,
        write_matters,
    )

    write_entities(
        me.db_path,
        [
            {"name": "Tom", "role": "colleague", "dynamics": 0.3},
            {"name": "Judy", "role": "friend", "dynamics": 0.1},
        ],
        date="2026-03-30",
    )
    write_matters(
        me.db_path,
        [{"name": "Tom's promotion", "current": "Under review", "who": ["Tom"]}],
        date="2026-03-30",
    )
    append_self_profile(me.db_path, ["Works with Tom at BigCorp"])


@_requires_redact
class TestFullRedactionCoverage:
    """All prompt components should be redacted, not just transcript."""

    def test_should_redact_entity_names_in_call1_prompt(self, tmp_path, monkeypatch):
        me = _make_me(tmp_path)
        _seed_entities(me)
        me.ingest("和Tom聊了聊，他的手机是13812345678")

        prompts_seen = []

        def mock_call_llm(client, model, prompt, **kwargs):
            prompts_seen.append(prompt)
            responses = [
                json.dumps({"resolutions": [], "self_profile_delta": []}),
                json.dumps(
                    {
                        "summary": "Chat.",
                        "conflict": "",
                        "emotion": "neutral",
                        "valence": 0.0,
                        "arousal": 0.3,
                        "persons": [],
                        "new_matters": [],
                        "dismissed": [],
                        "gaps": [],
                    }
                ),
                json.dumps({"conflict": "", "gaps": [], "self_observations": []}),
                json.dumps([]),
            ]
            idx = len(prompts_seen) - 1
            return responses[min(idx, len(responses) - 1)], {
                "model": "mock",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "duration_s": 0,
            }

        monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)
        me.understand()

        # Call 1 prompt should NOT contain real entity names
        call1_prompt = prompts_seen[0]
        assert (
            "Tom" not in call1_prompt
        ), f"Call 1 prompt contains real name 'Tom': {call1_prompt[:200]}"

    def test_should_redact_matter_names_in_call2_prompt(self, tmp_path, monkeypatch):
        me = _make_me(tmp_path)
        _seed_entities(me)
        me.ingest("讨论了Tom的升职")

        prompts_seen = []

        def mock_call_llm(client, model, prompt, **kwargs):
            prompts_seen.append(prompt)
            responses = [
                json.dumps({"resolutions": [], "self_profile_delta": []}),
                json.dumps(
                    {
                        "summary": "Discussed.",
                        "conflict": "",
                        "emotion": "neutral",
                        "valence": 0.0,
                        "arousal": 0.3,
                        "persons": [],
                        "new_matters": [],
                        "dismissed": [],
                        "gaps": [],
                    }
                ),
                json.dumps({"conflict": "", "gaps": [], "self_observations": []}),
                json.dumps([]),
            ]
            idx = len(prompts_seen) - 1
            return responses[min(idx, len(responses) - 1)], {
                "model": "mock",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "duration_s": 0,
            }

        monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)
        me.understand()

        # Call 2 prompt should NOT contain real names in matters
        call2_prompt = prompts_seen[1]
        assert "Tom" not in call2_prompt, f"Call 2 prompt contains 'Tom': {call2_prompt[:300]}"

    def test_should_redact_self_profile_in_call3_prompt(self, tmp_path, monkeypatch):
        me = _make_me(tmp_path)
        _seed_entities(me)
        me.ingest("今天心情不错")

        prompts_seen = []

        def mock_call_llm(client, model, prompt, **kwargs):
            prompts_seen.append(prompt)
            responses = [
                json.dumps({"resolutions": [], "self_profile_delta": []}),
                json.dumps(
                    {
                        "summary": "Good day.",
                        "conflict": "",
                        "emotion": "happy",
                        "valence": 0.5,
                        "arousal": 0.3,
                        "persons": [],
                        "new_matters": [],
                        "dismissed": [],
                        "gaps": [],
                    }
                ),
                json.dumps({"conflict": "", "gaps": [], "self_observations": []}),
                json.dumps([]),
            ]
            idx = len(prompts_seen) - 1
            return responses[min(idx, len(responses) - 1)], {
                "model": "mock",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "duration_s": 0,
            }

        monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)
        me.understand()

        # Call 3 prompt should NOT contain real names from self_profile
        call3_prompt = prompts_seen[2]
        assert "Tom" not in call3_prompt, f"Call 3 prompt contains 'Tom': {call3_prompt[:300]}"
        # Note: "BigCorp" is an org name — detected by argus-redact Layer 2 (NER)
        # not Layer 1 (regex). In fast mode, org names may not be redacted.

    def test_should_pass_entity_names_to_redact(self, tmp_path, monkeypatch):
        """redact_text should receive known entity names for redaction."""
        me = _make_me(tmp_path)
        _seed_entities(me)
        me.ingest("Tom来了")

        redact_calls = []

        from argus_me.redact import redact_text as original_redact

        def spy_redact(text, *, names=None):
            redact_calls.append({"text": text, "names": names})
            return original_redact(text, names=names)

        monkeypatch.setattr("argus_me.redact.redact_text", spy_redact)

        def mock_call_llm(client, model, prompt, **kwargs):
            return json.dumps(
                {
                    "resolutions": [],
                    "self_profile_delta": [],
                    "summary": "",
                    "conflict": "",
                    "emotion": "neutral",
                    "valence": 0.0,
                    "arousal": 0.3,
                    "persons": [],
                    "new_matters": [],
                    "dismissed": [],
                    "gaps": [],
                    "self_observations": [],
                }
            ), {
                "model": "mock",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "duration_s": 0,
            }

        monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)
        me.understand()

        # Should have passed entity names to redact
        assert len(redact_calls) >= 1
        first_call_names = redact_calls[0].get("names", [])
        assert "Tom" in first_call_names
        assert "Judy" in first_call_names

    def test_should_restore_real_names_in_final_output(self, tmp_path, monkeypatch):
        me = _make_me(tmp_path)
        _seed_entities(me)
        me.ingest("和Tom聊了聊升职的事")

        def mock_call_llm(client, model, prompt, **kwargs):
            # LLM responds with pseudonyms (it never saw real names)
            responses = [
                json.dumps({"resolutions": [], "self_profile_delta": []}),
                json.dumps(
                    {
                        "summary": "Discussed promotion.",
                        "conflict": "",
                        "emotion": "neutral",
                        "valence": 0.0,
                        "arousal": 0.3,
                        "persons": [{"name": "Tom", "role": "colleague", "dynamics": 0.3}],
                        "new_matters": [],
                        "dismissed": [],
                        "gaps": [],
                    }
                ),
                json.dumps({"conflict": "", "gaps": [], "self_observations": []}),
                json.dumps([]),
            ]
            idx = mock_call_llm.count
            mock_call_llm.count += 1
            return responses[min(idx, len(responses) - 1)], {
                "model": "mock",
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "duration_s": 0,
            }

        mock_call_llm.count = 0
        monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)

        result = me.understand()
        # Pipeline should complete without errors
        assert result["fragments_processed"] == 1
