"""Tests for snapshot() and live query properties."""

import json


def _seed_data(me, monkeypatch):
    """Ingest + understand with mocked LLM to populate DB."""
    me.ingest("Met Tom about the product launch.")

    responses = [
        json.dumps({"resolutions": [], "self_profile_delta": ["Software engineer"]}),
        json.dumps(
            {
                "summary": "Met with Tom about launch.",
                "conflict": "Timeline pressure",
                "emotion": "focused",
                "valence": 0.2,
                "arousal": 0.5,
                "persons": [{"name": "Tom", "role": "partner", "dynamics": 0.3}],
                "new_matters": [
                    {"name": "Product launch", "current": "Design phase", "who": ["Tom"]},
                ],
                "dismissed": [],
                "gaps": [
                    {
                        "type": "open_loop",
                        "description": "Design deadline",
                        "size": "medium",
                        "impact": "high",
                    },
                ],
            }
        ),
        json.dumps({"conflict": "Quality vs speed", "gaps": [], "self_observations": []}),
        json.dumps(
            [
                {
                    "matter_id": None,
                    "event": "Launch on time",
                    "narrative": "Team delivers under pressure",
                    "confidence": "high",
                },
            ]
        ),
    ]

    def mock_call_llm(client, model, prompt, **kwargs):
        resp = responses[mock_call_llm.i]
        mock_call_llm.i += 1
        if mock_call_llm.i == 4:
            from argus_me.models import get_open_matters

            matters = get_open_matters(me.db_path)
            if matters:
                arr = json.loads(resp)
                for p in arr:
                    p["matter_id"] = matters[0]["id"]
                resp = json.dumps(arr)
        return resp, {"model": "mock", "prompt_tokens": 0, "completion_tokens": 0, "duration_s": 0}

    mock_call_llm.i = 0
    monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)
    me.understand()


class TestSnapshot:
    """me.snapshot() — point-in-time cognitive freeze."""

    def test_should_return_dict_with_required_keys(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        snap = me.snapshot()
        for key in (
            "timestamp",
            "self_profile",
            "matters",
            "entities",
            "possibilities",
            "emotion",
            "gaps",
            "summary",
            "conflict",
        ):
            assert key in snap

    def test_should_include_self_profile(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        assert "Software engineer" in me.snapshot()["self_profile"]

    def test_should_include_open_matters(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        names = [m["name"] for m in me.snapshot()["matters"]]
        assert "Product launch" in names

    def test_should_include_entities(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        names = [e["canonical_name"] for e in me.snapshot()["entities"]]
        assert "Tom" in names

    def test_should_include_possibilities(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        snap = me.snapshot()
        assert len(snap["possibilities"]) >= 1
        assert snap["possibilities"][0]["event"] == "Launch on time"

    def test_should_include_latest_emotion(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        assert me.snapshot()["emotion"]["word"] == "focused"

    def test_should_return_empty_snapshot_when_no_data(self, me):
        snap = me.snapshot()
        assert snap["matters"] == []
        assert snap["entities"] == []
        assert snap["possibilities"] == []


class TestLiveProperties:
    """me.matters, me.entities, me.possibilities, etc."""

    def test_matters_should_return_open_matters(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        assert len(me.matters) >= 1
        assert me.matters[0]["name"] == "Product launch"

    def test_entities_should_return_non_self_entities(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        names = {e["canonical_name"] for e in me.entities}
        assert "Tom" in names
        assert "Wang Yu" not in names

    def test_possibilities_should_return_active(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        assert len(me.possibilities) >= 1

    def test_self_profile_should_return_text(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        assert "Software engineer" in me.self_profile

    def test_gaps_should_return_from_latest_run(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        assert isinstance(me.gaps, list)

    def test_runs_should_return_recent_runs(self, me, monkeypatch):
        _seed_data(me, monkeypatch)
        assert len(me.runs) >= 1
        assert me.runs[0]["emotion_word"] == "focused"
