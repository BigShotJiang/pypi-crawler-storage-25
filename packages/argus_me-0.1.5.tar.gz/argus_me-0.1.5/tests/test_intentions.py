"""Tests for intention scanner — implicit intention detection."""

from datetime import date, timedelta

from conftest import insert_entity, insert_matter, insert_run


def _make_db(tmp_path):
    from argus_me.models import ensure_self, init_db

    db_path = str(tmp_path / "memory.db")
    init_db(db_path)
    ensure_self(db_path, "Wang Yu")
    return db_path


class TestScanIntentions:
    """Detect implicit intentions from behavioral patterns."""

    def test_should_detect_matter_avoidance(self, tmp_path):
        from argus_me.sentinel import scan_intentions

        db_path = _make_db(tmp_path)
        today = date.today()
        old = (today - timedelta(days=20)).isoformat()
        insert_matter(db_path, "Stale project", opened_date=old)
        insert_run(db_path, run_date=old, summary="Working on stale project")
        for i in range(5):
            d = (today - timedelta(days=i)).isoformat()
            insert_run(db_path, run_date=d, summary="Did other things")

        avoidance = [i for i in scan_intentions(db_path) if i["type"] == "implicit"]
        assert len(avoidance) >= 1
        assert "Stale project" in avoidance[0]["content"]

    def test_should_detect_entity_dynamics_drift(self, tmp_path):
        from argus_me.sentinel import scan_intentions

        db_path = _make_db(tmp_path)
        insert_entity(db_path, "Tom", dynamics=-0.5)
        assert isinstance(scan_intentions(db_path), list)

    def test_should_handle_empty_db(self, tmp_path):
        from argus_me.sentinel import scan_intentions

        assert scan_intentions(_make_db(tmp_path)) == []


class TestWriteIntentions:
    """Intention persistence to DB."""

    def test_should_write_intention_to_db(self, tmp_path):
        from argus_me.models import connect
        from argus_me.sentinel import write_intention

        db_path = _make_db(tmp_path)
        write_intention(
            db_path,
            content="May be abandoning the stale project",
            intention_type="implicit",
            confidence=0.4,
            related_matters="[1]",
        )
        conn = connect(db_path)
        row = conn.execute("SELECT * FROM intentions").fetchone()
        assert row["content"] == "May be abandoning the stale project"
        assert row["confidence"] == 0.4
        assert row["status"] == "active"
        conn.close()

    def test_should_dedup_similar_intention(self, tmp_path):
        from argus_me.models import connect
        from argus_me.sentinel import write_intention

        db_path = _make_db(tmp_path)
        write_intention(
            db_path, content="Abandoning stale project", intention_type="implicit", confidence=0.3
        )
        write_intention(
            db_path, content="Abandoning stale project", intention_type="implicit", confidence=0.4
        )

        conn = connect(db_path)
        assert conn.execute("SELECT COUNT(*) FROM intentions").fetchone()[0] == 1
        assert conn.execute("SELECT confidence FROM intentions").fetchone()["confidence"] == 0.4
        conn.close()


class TestIntentionInjection:
    """Active intentions for Call 3/4 injection."""

    def test_should_read_active_intentions(self, tmp_path):
        from argus_me.sentinel import get_active_intentions, write_intention

        db_path = _make_db(tmp_path)
        write_intention(
            db_path, content="Moving away from project X", intention_type="implicit", confidence=0.5
        )
        active = get_active_intentions(db_path)
        assert len(active) == 1
        assert active[0]["content"] == "Moving away from project X"

    def test_should_exclude_dissolved_intentions(self, tmp_path):
        from argus_me.models import connect
        from argus_me.sentinel import get_active_intentions, write_intention

        db_path = _make_db(tmp_path)
        write_intention(db_path, content="Old intention", intention_type="implicit", confidence=0.3)
        conn = connect(db_path)
        conn.execute("UPDATE intentions SET status='dissolved'")
        conn.commit()
        conn.close()

        assert get_active_intentions(db_path) == []
