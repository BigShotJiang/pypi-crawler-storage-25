"""Tests for observations CRUD — typed self-knowledge atoms."""


class TestWriteObservation:
    """Insert observations into the DB."""

    def test_should_insert_observation(self, memory_db):
        from argus_me.models import connect, write_observation

        write_observation(
            memory_db,
            source="call_3",
            content="Tends to delay decisions under pressure",
            observation_type="behavior",
        )
        conn = connect(memory_db)
        row = conn.execute("SELECT * FROM observations").fetchone()
        assert row is not None
        assert row["content"] == "Tends to delay decisions under pressure"
        assert row["source"] == "call_3"
        assert row["observation_type"] == "behavior"
        assert row["confidence"] == 0.5
        conn.close()

    def test_should_accept_evidence_fragments(self, memory_db):
        from argus_me.models import connect, write_observation

        write_observation(
            memory_db,
            source="call_3",
            content="Pattern observed",
            observation_type="pattern",
            evidence_fragments=["frag-001", "frag-002"],
        )
        conn = connect(memory_db)
        row = conn.execute("SELECT evidence_fragments FROM observations").fetchone()
        import json

        frags = json.loads(row["evidence_fragments"])
        assert frags == ["frag-001", "frag-002"]
        conn.close()

    def test_should_accept_custom_confidence(self, memory_db):
        from argus_me.models import connect, write_observation

        write_observation(
            memory_db,
            source="user",
            content="I am decisive",
            confidence=1.0,
        )
        conn = connect(memory_db)
        row = conn.execute("SELECT confidence FROM observations").fetchone()
        assert row["confidence"] == 1.0
        conn.close()

    def test_should_accept_tags(self, memory_db):
        from argus_me.models import connect, write_observation

        write_observation(
            memory_db,
            source="call_1",
            content="Called team lead by Tom",
            tags=["identity", "role"],
        )
        conn = connect(memory_db)
        row = conn.execute("SELECT tags FROM observations").fetchone()
        import json

        assert json.loads(row["tags"]) == ["identity", "role"]
        conn.close()


class TestGetCurrentObservations:
    """Query non-superseded observations."""

    def test_should_return_all_when_none_superseded(self, memory_db):
        from argus_me.models import get_current_observations, write_observation

        write_observation(memory_db, source="call_3", content="Obs 1")
        write_observation(memory_db, source="call_3", content="Obs 2")
        obs = get_current_observations(memory_db)
        assert len(obs) == 2

    def test_should_exclude_superseded(self, memory_db):
        from argus_me.models import (
            connect,
            get_current_observations,
            write_observation,
        )

        id1 = write_observation(memory_db, source="call_3", content="Old view")
        id2 = write_observation(memory_db, source="call_3", content="New view")

        # Supersede old with new
        conn = connect(memory_db)
        conn.execute(
            "UPDATE observations SET superseded_by=? WHERE id=?",
            (id2, id1),
        )
        conn.commit()
        conn.close()

        obs = get_current_observations(memory_db)
        assert len(obs) == 1
        assert obs[0]["content"] == "New view"

    def test_should_return_empty_when_no_observations(self, memory_db):
        from argus_me.models import get_current_observations

        assert get_current_observations(memory_db) == []


class TestEditProfileObservation:
    """me.edit_profile() should create a user-sourced observation."""

    def test_should_create_user_observation(self, me):
        from argus_me.models import get_current_observations

        me.edit_profile("I am a decisive person.")
        obs = get_current_observations(me.db_path)
        user_obs = [o for o in obs if o["source"] == "user"]
        assert len(user_obs) == 1
        assert user_obs[0]["content"] == "I am a decisive person."
        assert user_obs[0]["confidence"] == 1.0
        assert user_obs[0]["observation_type"] == "trait"
