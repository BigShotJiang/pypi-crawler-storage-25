"""Tests for user interaction methods — each auto-records a cognitive fragment."""

from conftest import (
    count_action_fragments,
    get_entity_id,
    get_matter_id,
    insert_entity,
    insert_matter,
)


def _seed_matter(me):
    insert_matter(me.db_path, "Product launch", opened_date="2026-03-30")


def _seed_entity(me):
    insert_entity(me.db_path, "Tom", dynamics=0.3, date="2026-03-30")


class TestDismiss:
    """me.dismiss(matter_id)"""

    def test_should_dismiss_matter(self, me):
        from argus_me.models import connect

        _seed_matter(me)
        mid = get_matter_id(me.db_path, "Product launch")
        me.dismiss(mid)

        conn = connect(me.db_path)
        row = conn.execute("SELECT status FROM matters WHERE id=?", (mid,)).fetchone()
        assert row["status"] == "dismissed"
        conn.close()

    def test_should_record_fragment(self, me):
        _seed_matter(me)
        mid = get_matter_id(me.db_path, "Product launch")
        me.dismiss(mid)
        assert count_action_fragments(me.db_path) == 1


class TestExpect:
    """me.expect(possibility_id)"""

    def test_should_mark_possibility_as_expected(self, me):
        from argus_me.models import connect, write_possibilities

        _seed_matter(me)
        mid = get_matter_id(me.db_path, "Product launch")
        write_possibilities(
            me.db_path,
            [{"matter_id": mid, "event": "Launch on time", "confidence": "high"}],
            run_id="run-001",
        )
        conn = connect(me.db_path)
        pid = conn.execute("SELECT id FROM possibilities").fetchone()["id"]
        conn.close()

        me.expect(pid)

        conn = connect(me.db_path)
        row = conn.execute("SELECT status FROM possibilities WHERE id=?", (pid,)).fetchone()
        assert row["status"] == "expected"
        conn.close()

    def test_should_record_fragment(self, me):
        from argus_me.models import connect, write_possibilities

        _seed_matter(me)
        mid = get_matter_id(me.db_path, "Product launch")
        write_possibilities(
            me.db_path,
            [{"matter_id": mid, "event": "Test event", "confidence": "low"}],
            run_id="run-001",
        )
        conn = connect(me.db_path)
        pid = conn.execute("SELECT id FROM possibilities").fetchone()["id"]
        conn.close()

        me.expect(pid)
        assert count_action_fragments(me.db_path) == 1


class TestAlias:
    """me.alias(name, entity_id)"""

    def test_should_register_alias_for_self(self, me):
        from argus_me.models import connect

        me.alias("Professor Wang")
        conn = connect(me.db_path)
        row = conn.execute(
            "SELECT entity_id FROM entity_aliases" " WHERE alias='Professor Wang'"
        ).fetchone()
        assert row["entity_id"] == "self"
        conn.close()

    def test_should_register_alias_for_entity(self, me):
        from argus_me.models import connect

        _seed_entity(me)
        eid = get_entity_id(me.db_path, "Tom")
        me.alias("Tommy", entity_id=eid)

        conn = connect(me.db_path)
        row = conn.execute("SELECT entity_id FROM entity_aliases WHERE alias='Tommy'").fetchone()
        assert row["entity_id"] == eid
        conn.close()

    def test_should_record_fragment(self, me):
        me.alias("Professor Wang")
        assert count_action_fragments(me.db_path) == 1


class TestMerge:
    """me.merge(keep_id, absorb_id)"""

    def test_should_transfer_aliases(self, me):
        from argus_me.models import connect

        _seed_entity(me)
        insert_entity(me.db_path, "Thomas", dynamics=0.0, date="2026-03-30")
        keep_id = get_entity_id(me.db_path, "Tom")
        absorb_id = get_entity_id(me.db_path, "Thomas")

        me.merge(keep_id, absorb_id)

        conn = connect(me.db_path)
        aliases = [
            r["alias"]
            for r in conn.execute(
                "SELECT alias FROM entity_aliases WHERE entity_id=?",
                (keep_id,),
            ).fetchall()
        ]
        assert "Thomas" in aliases
        conn.close()

    def test_should_record_fragment(self, me):
        _seed_entity(me)
        insert_entity(me.db_path, "Thomas", dynamics=0.0, date="2026-03-30")
        keep_id = get_entity_id(me.db_path, "Tom")
        absorb_id = get_entity_id(me.db_path, "Thomas")
        me.merge(keep_id, absorb_id)
        assert count_action_fragments(me.db_path) == 1


class TestNote:
    """me.note(entity_id, text)"""

    def test_should_append_note_to_entity(self, me):
        from argus_me.models import connect

        _seed_entity(me)
        eid = get_entity_id(me.db_path, "Tom")
        me.note(eid, "Sharp on distributed systems.")

        conn = connect(me.db_path)
        row = conn.execute("SELECT note FROM entities WHERE id=?", (eid,)).fetchone()
        assert "distributed systems" in row["note"]
        conn.close()

    def test_should_record_fragment(self, me):
        _seed_entity(me)
        eid = get_entity_id(me.db_path, "Tom")
        me.note(eid, "Met at conference.")
        assert count_action_fragments(me.db_path) == 1


class TestEditProfile:
    """me.edit_profile(text)"""

    def test_should_replace_self_profile(self, me):
        me.edit_profile("Software engineer. Father of two.")
        assert "Father of two" in me.self_profile

    def test_should_record_fragment(self, me):
        me.edit_profile("New profile text.")
        assert count_action_fragments(me.db_path) == 1


class TestPrioritize:
    """me.prioritize(matter_ids)"""

    def test_should_set_priority_order(self, me):
        from argus_me.models import connect

        insert_matter(me.db_path, "A", opened_date="2026-03-30")
        insert_matter(me.db_path, "B", opened_date="2026-03-30")

        conn = connect(me.db_path)
        ids = [r["id"] for r in conn.execute("SELECT id FROM matters ORDER BY id").fetchall()]
        conn.close()

        me.prioritize(ids)

        conn = connect(me.db_path)
        a = conn.execute("SELECT priority FROM matters WHERE id=?", (ids[0],)).fetchone()
        b = conn.execute("SELECT priority FROM matters WHERE id=?", (ids[1],)).fetchone()
        assert a["priority"] > b["priority"]
        conn.close()

    def test_should_record_fragment(self, me):
        me.prioritize([])
        assert count_action_fragments(me.db_path) == 1
