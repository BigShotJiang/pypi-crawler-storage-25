"""Tests for epoch CRUD and telescoping context."""

from conftest import insert_run


def _make_db(tmp_path):
    from argus_me.models import ensure_self, init_db

    db_path = str(tmp_path / "memory.db")
    init_db(db_path)
    ensure_self(db_path, "Wang Yu")
    return db_path


class TestEpochCRUD:
    """Epoch write and read operations."""

    def test_should_write_epoch(self, tmp_path):
        from argus_me.models import get_epochs, write_epoch

        db_path = _make_db(tmp_path)
        eid = write_epoch(
            db_path,
            start_date="2026-01-01",
            end_date="2026-01-14",
            run_count=14,
            summary="First two weeks of the year.",
            themes=["product", "team"],
            avg_valence=0.2,
        )
        epochs = get_epochs(db_path)
        assert len(epochs) == 1
        assert epochs[0]["summary"] == "First two weeks of the year."
        assert epochs[0]["run_count"] == 14
        assert eid > 0

    def test_should_return_epochs_newest_first(self, tmp_path):
        from argus_me.models import write_epoch, get_epochs

        db_path = _make_db(tmp_path)
        write_epoch(db_path, start_date="2026-01-01",
                     end_date="2026-01-14", run_count=14,
                     summary="Epoch 1")
        write_epoch(db_path, start_date="2026-01-15",
                     end_date="2026-01-28", run_count=14,
                     summary="Epoch 2")
        epochs = get_epochs(db_path)
        assert epochs[0]["summary"] == "Epoch 2"
        assert epochs[1]["summary"] == "Epoch 1"

    def test_should_respect_limit(self, tmp_path):
        from argus_me.models import write_epoch, get_epochs

        db_path = _make_db(tmp_path)
        for i in range(5):
            write_epoch(db_path, start_date=f"2026-0{i+1}-01",
                         end_date=f"2026-0{i+1}-14", run_count=14,
                         summary=f"Epoch {i+1}")
        assert len(get_epochs(db_path, limit=3)) == 3


class TestUnconsolidatedRuns:
    """Query runs not assigned to an epoch."""

    def test_should_return_runs_without_epoch_id(self, tmp_path):
        from argus_me.models import get_unconsolidated_runs

        db_path = _make_db(tmp_path)
        insert_run(db_path, run_date="2026-03-28", summary="Run 1")
        insert_run(db_path, run_date="2026-03-29", summary="Run 2")
        runs = get_unconsolidated_runs(db_path)
        assert len(runs) == 2

    def test_should_exclude_consolidated_runs(self, tmp_path):
        from argus_me.models import (
            connect,
            get_unconsolidated_runs,
            write_epoch,
        )

        db_path = _make_db(tmp_path)
        insert_run(db_path, run_date="2026-03-28", summary="Run 1")
        insert_run(db_path, run_date="2026-03-29", summary="Run 2")
        eid = write_epoch(db_path, start_date="2026-03-28",
                           end_date="2026-03-29", run_count=2,
                           summary="Epoch")
        # Mark first run as consolidated
        conn = connect(db_path)
        conn.execute(
            "UPDATE runs SET epoch_id=? WHERE summary='Run 1'", (eid,)
        )
        conn.commit()
        conn.close()

        runs = get_unconsolidated_runs(db_path)
        assert len(runs) == 1
        assert runs[0]["summary"] == "Run 2"

    def test_should_return_count(self, tmp_path):
        from argus_me.models import get_unconsolidated_run_count

        db_path = _make_db(tmp_path)
        insert_run(db_path, run_date="2026-03-28")
        insert_run(db_path, run_date="2026-03-29")
        insert_run(db_path, run_date="2026-03-30")
        assert get_unconsolidated_run_count(db_path) == 3


class TestSetRunEpoch:
    """Tag runs with epoch_id."""

    def test_should_set_epoch_id_on_run(self, tmp_path):
        from argus_me.models import connect, set_run_epoch, write_epoch

        db_path = _make_db(tmp_path)
        insert_run(db_path, run_date="2026-03-28", summary="Test")
        eid = write_epoch(db_path, start_date="2026-03-28",
                           end_date="2026-03-28", run_count=1,
                           summary="Epoch")
        conn = connect(db_path)
        run_pk = conn.execute("SELECT id FROM runs").fetchone()["id"]
        conn.close()

        set_run_epoch(db_path, run_pk, eid)

        conn = connect(db_path)
        row = conn.execute(
            "SELECT epoch_id FROM runs WHERE id=?", (run_pk,)
        ).fetchone()
        assert row["epoch_id"] == eid
        conn.close()


class TestTelescopingContext:
    """build_network_context uses epochs + unconsolidated runs."""

    def test_should_include_epochs_when_available(self, tmp_path):
        from argus_me.etl import build_network_context
        from argus_me.models import write_epoch

        db_path = _make_db(tmp_path)
        write_epoch(db_path, start_date="2026-01-01",
                     end_date="2026-01-14", run_count=14,
                     summary="Product direction decided")
        insert_run(db_path, run_date="2026-03-28",
                    summary="Recent activity")

        ctx = build_network_context(db_path)
        assert "Product direction decided" in ctx
        assert "Recent activity" in ctx

    def test_should_fallback_when_no_epochs(self, tmp_path):
        from argus_me.etl import build_network_context

        db_path = _make_db(tmp_path)
        insert_run(db_path, run_date="2026-03-28",
                    summary="Just a run")

        ctx = build_network_context(db_path)
        assert "Just a run" in ctx
