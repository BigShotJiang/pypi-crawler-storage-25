"""Tests for ETL pipeline — understand() orchestration with mocked LLM."""

import json

from conftest import MOCK_CALL1, MOCK_CALL2, MOCK_CALL3, MOCK_CALL4, MOCK_METRICS


class TestPipelineOrchestration:
    """Full pipeline with mocked LLM calls."""

    def test_should_return_immediately_when_no_fragments(self, me):
        result = me.understand()
        assert result["fragments_processed"] == 0

    def test_should_process_fragments_through_4_calls(self, me, monkeypatch):
        me.ingest("Had coffee with Tom. He's worried about the launch.")

        calls_made = []

        def mock_call1(client, model, prompt, **kw):
            calls_made.append("call1")
            return json.dumps(MOCK_CALL1), MOCK_METRICS

        def mock_call2(client, model, prompt, **kw):
            calls_made.append("call2")
            return json.dumps(MOCK_CALL2), MOCK_METRICS

        def mock_call3(client, model, prompt, **kw):
            calls_made.append("call3")
            return json.dumps(MOCK_CALL3), MOCK_METRICS

        def mock_call4(client, model, prompt, **kw):
            calls_made.append("call4")
            from argus_me.models import get_open_matters

            matters = get_open_matters(me.db_path)
            result = []
            for p in MOCK_CALL4:
                entry = dict(p)
                if matters:
                    entry["matter_id"] = matters[0]["id"]
                result.append(entry)
            return json.dumps(result), MOCK_METRICS

        call_index = {"i": 0}
        mock_fns = [mock_call1, mock_call2, mock_call3, mock_call4]

        def mock_call_llm(client, model, prompt, **kwargs):
            fn = mock_fns[call_index["i"]]
            call_index["i"] += 1
            return fn(client, model, prompt, **kwargs)

        monkeypatch.setattr("argus_me.etl.call_llm", mock_call_llm)

        result = me.understand()

        assert calls_made == ["call1", "call2", "call3", "call4"]
        assert result["fragments_processed"] == 1
        assert result["run_id"] is not None

    def test_should_write_entities_to_db(self, me, mock_llm):
        from argus_me.models import connect

        me.ingest("Met Tom today.")
        me.understand()

        conn = connect(me.db_path)
        tom = conn.execute("SELECT * FROM entities WHERE canonical_name='Tom'").fetchone()
        assert tom is not None
        assert tom["dynamics"] == 0.4
        conn.close()

    def test_should_write_matters_to_db(self, me, mock_llm):
        from argus_me.models import connect

        me.ingest("Discussed product launch with Tom.")
        me.understand()

        conn = connect(me.db_path)
        matter = conn.execute("SELECT * FROM matters WHERE name='Product launch'").fetchone()
        assert matter is not None
        assert matter["status"] == "open"
        conn.close()

    def test_should_write_run_to_db(self, me, mock_llm):
        from argus_me.models import connect

        me.ingest("A productive day.")
        result = me.understand()

        conn = connect(me.db_path)
        run = conn.execute("SELECT * FROM runs WHERE run_id=?", (result["run_id"],)).fetchone()
        assert run is not None
        assert run["emotion_word"] == "anxious"
        conn.close()

    def test_should_mark_fragments_processed(self, me, mock_llm):
        from argus_me.models import get_unprocessed_fragments

        me.ingest("Fragment one.")
        me.ingest("Fragment two.")
        me.understand()

        remaining = get_unprocessed_fragments(me.db_path)
        assert len(remaining) == 0

    def test_should_append_self_profile_deltas(self, me, mock_llm):
        from argus_me.models import read_self_profile

        me.ingest("Tom called me team lead today.")
        me.understand()

        profile = read_self_profile(me.db_path)
        assert "team lead" in profile
        assert "delay decisions" in profile
