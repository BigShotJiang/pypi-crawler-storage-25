"""Tests for Call 1/3 dual-write — self_profile + observations table."""

from conftest import make_mock_llm

from argus_me.models import connect, get_current_observations, read_self_profile


class TestDualWrite:
    """After understand(), observations table should have entries alongside self_profile."""

    def test_should_write_call1_deltas_to_observations(self, me, mock_llm):
        me.ingest("Tom called me team lead today.")
        me.understand()

        obs = get_current_observations(me.db_path)
        call1_obs = [o for o in obs if o["source"] == "call_1"]
        assert len(call1_obs) >= 1
        assert any("team lead" in o["content"] for o in call1_obs)

    def test_should_write_call3_observations_to_observations(self, me, mock_llm):
        me.ingest("Feeling uncertain about direction.")
        me.understand()

        obs = get_current_observations(me.db_path)
        call3_obs = [o for o in obs if o["source"] == "call_3"]
        assert len(call3_obs) >= 1
        assert any("delay decisions" in o["content"] for o in call3_obs)

    def test_should_still_write_to_self_profile(self, me, mock_llm):
        me.ingest("Had a productive day.")
        me.understand()

        profile = read_self_profile(me.db_path)
        # MOCK_CALL1 has "Called 'team lead' by Tom"
        # MOCK_CALL3 has "Tends to delay decisions under pressure"
        assert "team lead" in profile
        assert "delay decisions" in profile

    def test_should_set_observation_type_for_call1(self, me, mock_llm):
        me.ingest("Testing.")
        me.understand()

        obs = get_current_observations(me.db_path)
        call1_obs = [o for o in obs if o["source"] == "call_1"]
        for o in call1_obs:
            assert o["observation_type"] == "trait"

    def test_should_set_observation_type_for_call3(self, me, mock_llm):
        me.ingest("Testing.")
        me.understand()

        obs = get_current_observations(me.db_path)
        call3_obs = [o for o in obs if o["source"] == "call_3"]
        for o in call3_obs:
            assert o["observation_type"] == "behavior"
