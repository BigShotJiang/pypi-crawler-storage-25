"""Tests for epoch consolidation — trigger logic + Call 0 + self-profile rebuild."""

import json
from datetime import date, timedelta

from conftest import insert_run, make_mock_llm

from argus_me.models import (
    connect,
    get_epoch_count,
    get_epochs,
    get_unconsolidated_run_count,
    read_self_profile,
    write_observation,
)


def _make_db(tmp_path):
    from argus_me.models import ensure_self, init_db

    db_path = str(tmp_path / "memory.db")
    init_db(db_path)
    ensure_self(db_path, "Wang Yu")
    return db_path


def _seed_runs(db_path, count, *, start_days_ago=30):
    """Insert N runs spread across days."""
    today = date.today()
    for i in range(count):
        d = (today - timedelta(days=start_days_ago - i)).isoformat()
        insert_run(db_path, run_date=d, summary=f"Day {i} summary", valence=-0.1 + i * 0.02)


class TestShouldConsolidate:
    """Trigger logic for epoch creation."""

    def test_should_not_trigger_below_min_runs(self, tmp_path):
        from argus_me.etl import should_consolidate

        db_path = _make_db(tmp_path)
        _seed_runs(db_path, 5)
        assert should_consolidate(db_path) is False

    def test_should_trigger_at_max_runs(self, tmp_path):
        from argus_me.etl import should_consolidate

        db_path = _make_db(tmp_path)
        _seed_runs(db_path, 20)
        assert should_consolidate(db_path) is True

    def test_should_trigger_on_time_gap(self, tmp_path):
        from argus_me.etl import should_consolidate

        db_path = _make_db(tmp_path)
        today = date.today()
        # 8 runs, but last two are 10 days apart
        for i in range(7):
            insert_run(
                db_path,
                run_date=(today - timedelta(days=20 - i)).isoformat(),
                summary=f"Old run {i}",
            )
        insert_run(
            db_path,
            run_date=(today - timedelta(days=1)).isoformat(),
            summary="Recent run after gap",
        )
        assert should_consolidate(db_path) is True

    def test_should_not_trigger_without_gap(self, tmp_path):
        from argus_me.etl import should_consolidate

        db_path = _make_db(tmp_path)
        today = date.today()
        for i in range(10):
            insert_run(
                db_path,
                run_date=(today - timedelta(days=10 - i)).isoformat(),
                summary=f"Run {i}",
            )
        assert should_consolidate(db_path) is False


class TestRunConsolidation:
    """Call 0 execution — create epoch from unconsolidated runs."""

    def test_should_create_epoch(self, tmp_path, monkeypatch):
        from argus_me.etl import run_consolidation

        db_path = _make_db(tmp_path)
        _seed_runs(db_path, 14)

        mock_response = json.dumps({
            "summary": "Two weeks of product development",
            "themes": ["product", "team"],
            "avg_valence": 0.1,
            "self_model_delta": "Became more decisive",
            "boundary_start": {"trigger": "max_runs", "context_shift": ""},
            "boundary_end": {
                "closing_state": "Focused on MVP",
                "unresolved": ["fundraising"],
            },
            "continuing_threads": [],
        })
        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            make_mock_llm(responses=[mock_response]),
        )

        epoch_id = run_consolidation(db_path, "http://localhost:11434/v1", "qwen2.5:32b")

        assert epoch_id is not None
        assert get_epoch_count(db_path) == 1
        assert get_unconsolidated_run_count(db_path) == 0

        epochs = get_epochs(db_path)
        assert epochs[0]["summary"] == "Two weeks of product development"

    def test_should_tag_runs_with_epoch_id(self, tmp_path, monkeypatch):
        from argus_me.etl import run_consolidation

        db_path = _make_db(tmp_path)
        _seed_runs(db_path, 10)

        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            make_mock_llm(responses=[json.dumps({
                "summary": "Test epoch",
                "themes": [],
            })]),
        )

        epoch_id = run_consolidation(db_path, "http://localhost:11434/v1", "qwen2.5:32b")

        conn = connect(db_path)
        untagged = conn.execute(
            "SELECT COUNT(*) FROM runs WHERE epoch_id IS NULL"
        ).fetchone()[0]
        tagged = conn.execute(
            "SELECT COUNT(*) FROM runs WHERE epoch_id=?", (epoch_id,)
        ).fetchone()[0]
        conn.close()
        assert untagged == 0
        assert tagged == 10


class TestSelfProfileRebuild:
    """Self-profile rebuild from observations at epoch creation."""

    def test_should_rebuild_profile_from_observations(self, tmp_path, monkeypatch):
        from argus_me.etl import rebuild_self_profile

        db_path = _make_db(tmp_path)
        write_observation(db_path, source="call_3", content="Software engineer", confidence=0.8)
        write_observation(db_path, source="call_3", content="Values autonomy", confidence=0.7)
        write_observation(db_path, source="call_1", content="Team lead role", confidence=0.6)
        write_observation(db_path, source="call_3", content="Father of two", confidence=0.6)
        write_observation(db_path, source="call_3", content="Based in Shanghai", confidence=0.5)

        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            make_mock_llm(responses=[json.dumps({
                "self_profile": "Software engineer who values autonomy. Recently took on team lead role.",
            })]),
        )

        rebuild_self_profile(db_path, "http://localhost:11434/v1", "qwen2.5:32b")
        profile = read_self_profile(db_path)
        assert "autonomy" in profile

    def test_should_skip_rebuild_when_few_observations(self, tmp_path, monkeypatch):
        from argus_me.etl import rebuild_self_profile

        db_path = _make_db(tmp_path)
        # Only 2 observations — below threshold
        write_observation(db_path, source="call_3", content="Obs 1")
        write_observation(db_path, source="call_3", content="Obs 2")

        # Should not call LLM
        call_count = {"n": 0}

        def counting_llm(client, model, prompt, **kw):
            call_count["n"] += 1
            return "{}", {"model": "mock", "prompt_tokens": 0, "completion_tokens": 0, "duration_s": 0}

        monkeypatch.setattr("argus_me.etl.call_llm", counting_llm)

        rebuild_self_profile(db_path, "http://localhost:11434/v1", "qwen2.5:32b")
        assert call_count["n"] == 0


class TestPipelineTriggersConsolidation:
    """understand() should trigger Call 0 when conditions are met."""

    def test_should_trigger_consolidation_in_pipeline(self, me, monkeypatch):
        _seed_runs(me.db_path, 20)
        me.ingest("New fragment after many runs.")

        # Mock responses: Call 0 (consolidation) + Call 1-4
        consolidation_resp = json.dumps({
            "summary": "Epoch from pipeline",
            "themes": ["work"],
        })
        call1 = json.dumps({"resolutions": [], "self_profile_delta": []})
        call2 = json.dumps({
            "summary": "New day.",
            "conflict": "",
            "emotion": "neutral",
            "valence": 0.0,
            "arousal": 0.3,
            "persons": [],
            "new_matters": [],
            "dismissed": [],
            "gaps": [],
        })
        call3 = json.dumps({"conflict": "", "gaps": [], "self_observations": []})
        call4 = json.dumps([])

        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            make_mock_llm(responses=[consolidation_resp, call1, call2, call3, call4]),
        )
        result = me.understand()

        assert get_epoch_count(me.db_path) >= 1
        assert result["fragments_processed"] == 1
