"""Tests for database models and schema."""

import sqlite3


class TestInitDb:
    """Database initialization and schema."""

    def test_should_create_all_tables_when_fresh_db(self, memory_db):
        conn = sqlite3.connect(memory_db)
        conn.row_factory = sqlite3.Row
        tables = {
            r["name"]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        }
        expected = {
            "meta",
            "fragments",
            "entities",
            "entity_aliases",
            "matters",
            "matter_entities",
            "runs",
            "possibilities",
            "intentions",
            "insight_queue",
            "epochs",
            "observations",
        }
        assert tables == expected
        conn.close()

    def test_should_set_schema_version_when_fresh_db(self, memory_db):
        conn = sqlite3.connect(memory_db)
        version = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]
        assert version == "20"
        conn.close()

    def test_should_enable_wal_mode_when_connecting(self, memory_db):
        conn = sqlite3.connect(memory_db)
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        assert mode == "wal"
        conn.close()

    def test_should_be_idempotent_when_called_twice(self, tmp_db):
        from argus_me.models import init_db

        init_db(tmp_db)
        init_db(tmp_db)
        conn = sqlite3.connect(tmp_db)
        version = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0]
        assert version == "20"
        conn.close()


class TestSelfEntity:
    """Self entity creation and management."""

    def test_should_create_self_entity_when_init(self, memory_db):
        from argus_me.models import connect, ensure_self

        ensure_self(memory_db, "Wang Yu")
        conn = connect(memory_db)
        row = conn.execute("SELECT id, canonical_name FROM entities WHERE id='self'").fetchone()
        assert row is not None
        assert row["canonical_name"] == "Wang Yu"
        conn.close()

    def test_should_create_default_aliases_when_init(self, memory_db):
        from argus_me.models import connect, ensure_self

        ensure_self(memory_db, "Wang Yu")
        conn = connect(memory_db)
        aliases = [
            r["alias"]
            for r in conn.execute(
                "SELECT alias FROM entity_aliases WHERE entity_id='self'"
            ).fetchall()
        ]
        assert "Wang Yu" in aliases
        conn.close()

    def test_should_be_idempotent_when_called_twice(self, memory_db):
        from argus_me.models import connect, ensure_self

        ensure_self(memory_db, "Wang Yu")
        ensure_self(memory_db, "Wang Yu")
        conn = connect(memory_db)
        count = conn.execute("SELECT COUNT(*) FROM entities WHERE id='self'").fetchone()[0]
        assert count == 1
        conn.close()


class TestFragments:
    """Fragment write and read operations."""

    def test_should_insert_fragment_when_ingest(self, memory_db):
        from argus_me.models import connect, write_fragment

        fid = write_fragment(memory_db, text="Had coffee with Tom.", date="2026-03-30")
        conn = connect(memory_db)
        row = conn.execute("SELECT * FROM fragments WHERE id=?", (fid,)).fetchone()
        assert row is not None
        assert row["transcript"] == "Had coffee with Tom."
        assert row["type"] == "text"
        assert row["date"] == "2026-03-30"
        assert row["processed"] == 0
        conn.close()

    def test_should_create_action_fragment_when_user_acts(self, memory_db):
        from argus_me.models import connect, write_fragment

        fid = write_fragment(
            memory_db,
            text="User no longer tracking: Q2 fundraising",
            date="2026-03-30",
            fragment_type="action",
            source="user_action",
        )
        conn = connect(memory_db)
        row = conn.execute("SELECT * FROM fragments WHERE id=?", (fid,)).fetchone()
        assert row["type"] == "action"
        assert row["source"] == "user_action"
        conn.close()

    def test_should_return_unprocessed_fragments_when_queried(self, memory_db):
        from argus_me.models import get_unprocessed_fragments, write_fragment

        write_fragment(memory_db, text="Fragment 1", date="2026-03-30")
        write_fragment(memory_db, text="Fragment 2", date="2026-03-30")
        fragments = get_unprocessed_fragments(memory_db)
        assert len(fragments) == 2

    def test_should_exclude_processed_fragments_when_queried(self, memory_db):
        from argus_me.models import connect, get_unprocessed_fragments, write_fragment

        fid = write_fragment(memory_db, text="Already done", date="2026-03-30")
        conn = connect(memory_db)
        conn.execute("UPDATE fragments SET processed=1 WHERE id=?", (fid,))
        conn.commit()
        conn.close()
        write_fragment(memory_db, text="Still pending", date="2026-03-30")
        fragments = get_unprocessed_fragments(memory_db)
        assert len(fragments) == 1
        assert fragments[0]["transcript"] == "Still pending"


class TestConnect:
    """Database connection helper."""

    def test_should_return_row_factory_when_connecting(self, memory_db):
        from argus_me.models import connect

        conn = connect(memory_db)
        assert conn.row_factory == sqlite3.Row
        conn.close()

    def test_should_enable_foreign_keys_when_connecting(self, memory_db):
        from argus_me.models import connect

        conn = connect(memory_db)
        fk = conn.execute("PRAGMA foreign_keys").fetchone()[0]
        assert fk == 1
        conn.close()
