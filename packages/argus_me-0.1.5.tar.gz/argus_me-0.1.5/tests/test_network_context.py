"""Tests for network context — entities + recent runs injected into prompts."""

import json

from conftest import seed_history


class TestNetworkContextFormat:
    """Network context formatting for prompt injection."""

    def test_should_include_entity_names_and_dynamics(self, me):
        from argus_me.etl import build_network_context

        seed_history(me.db_path)
        ctx = build_network_context(me.db_path)
        assert "Tom" in ctx
        assert "Judy" in ctx

    def test_should_include_recent_run_summaries(self, me):
        from argus_me.etl import build_network_context

        seed_history(me.db_path)
        ctx = build_network_context(me.db_path)
        assert "Tom" in ctx

    def test_should_return_empty_when_no_data(self, me):
        from argus_me.etl import build_network_context

        assert build_network_context(me.db_path) == ""


class TestNetworkContextInPipeline:
    """Network context should be injected into Call 2 and Call 4 prompts."""

    def test_should_inject_context_into_call2_prompt(self, me, mock_llm, monkeypatch):
        seed_history(me.db_path)
        me.ingest("Today was productive.")
        me.understand()

        call2_prompt = mock_llm[1]
        assert "Tom" in call2_prompt

    def test_should_inject_context_into_call4_prompt(self, me, monkeypatch):
        from conftest import make_mock_llm

        seed_history(me.db_path)
        me.ingest("Planning next steps.")

        prompts = []
        responses = [
            json.dumps({"resolutions": [], "self_profile_delta": []}),
            json.dumps(
                {
                    "summary": "Planning.",
                    "conflict": "",
                    "emotion": "neutral",
                    "valence": 0.0,
                    "arousal": 0.3,
                    "persons": [],
                    "new_matters": [
                        {"name": "Next steps", "current": "Planning", "who": []},
                    ],
                    "dismissed": [],
                    "gaps": [],
                }
            ),
            json.dumps({"conflict": "", "gaps": [], "self_observations": []}),
            json.dumps([]),
        ]
        monkeypatch.setattr(
            "argus_me.etl.call_llm",
            make_mock_llm(responses=responses, capture=prompts),
        )
        me.understand()

        if len(prompts) >= 4:
            assert "Tom" in prompts[3] or len(prompts[3]) > 100
