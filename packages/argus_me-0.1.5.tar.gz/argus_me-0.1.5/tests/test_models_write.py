"""Tests for models write operations — entities, matters, runs, possibilities."""


class TestWriteEntities:
    """Entity upsert with EWMA dynamics."""

    def test_should_insert_new_entity_when_not_exists(self, memory_db):
        from argus_me.models import connect, write_entities

        persons = [{"name": "Tom", "role": "colleague", "dynamics": 0.5}]
        write_entities(memory_db, persons, date="2026-03-30")
        conn = connect(memory_db)
        row = conn.execute(
            "SELECT canonical_name, dynamics, interaction_count"
            " FROM entities WHERE canonical_name='Tom'"
        ).fetchone()
        assert row is not None
        assert row["dynamics"] == 0.5
        assert row["interaction_count"] == 1
        conn.close()

    def test_should_apply_ewma_when_updating_dynamics(self, memory_db):
        from argus_me.models import connect, write_entities

        write_entities(memory_db, [{"name": "Tom", "role": "", "dynamics": 1.0}], date="2026-03-29")
        write_entities(memory_db, [{"name": "Tom", "role": "", "dynamics": 0.0}], date="2026-03-30")
        conn = connect(memory_db)
        row = conn.execute(
            "SELECT dynamics, interaction_count FROM entities WHERE canonical_name='Tom'"
        ).fetchone()
        # EWMA: 0.7 * 1.0 + 0.3 * 0.0 = 0.7
        assert round(row["dynamics"], 1) == 0.7
        assert row["interaction_count"] == 2
        conn.close()

    def test_should_create_alias_when_new_entity(self, memory_db):
        from argus_me.models import connect, write_entities

        write_entities(memory_db, [{"name": "Tom", "role": "", "dynamics": 0.0}], date="2026-03-30")
        conn = connect(memory_db)
        alias = conn.execute("SELECT alias FROM entity_aliases WHERE alias='Tom'").fetchone()
        assert alias is not None
        conn.close()

    def test_should_skip_self_when_writing(self, memory_db):
        from argus_me.models import connect, ensure_self, write_entities

        ensure_self(memory_db, "Wang Yu")
        write_entities(
            memory_db,
            [{"name": "我", "role": "", "dynamics": 0.5}],
            date="2026-03-30",
        )
        conn = connect(memory_db)
        # Self entity dynamics should not be updated by write_entities
        row = conn.execute("SELECT dynamics FROM entities WHERE id='self'").fetchone()
        assert row["dynamics"] == 0.0
        conn.close()


class TestWriteMatters:
    """Matter upsert with mention counting."""

    def test_should_insert_new_matter_when_not_exists(self, memory_db):
        from argus_me.models import connect, write_matters

        matters = [{"name": "Q2 fundraising", "current": "Waiting for TS", "who": ["Tom"]}]
        write_matters(memory_db, matters, date="2026-03-30")
        conn = connect(memory_db)
        row = conn.execute("SELECT * FROM matters WHERE name='Q2 fundraising'").fetchone()
        assert row is not None
        assert row["current"] == "Waiting for TS"
        assert row["status"] == "open"
        conn.close()

    def test_should_increment_mention_count_when_same_name(self, memory_db):
        from argus_me.models import connect, write_matters

        matters = [{"name": "Q2 fundraising", "current": "Starting", "who": []}]
        write_matters(memory_db, matters, date="2026-03-29")
        matters = [{"name": "Q2 fundraising", "current": "In progress", "who": []}]
        write_matters(memory_db, matters, date="2026-03-30")
        conn = connect(memory_db)
        row = conn.execute(
            "SELECT mention_count, current FROM matters WHERE name='Q2 fundraising'"
        ).fetchone()
        assert row["mention_count"] == 2
        assert row["current"] == "In progress"
        conn.close()

    def test_should_not_overwrite_user_source_when_llm_updates(self, memory_db):
        from argus_me.models import connect, write_matters

        conn = connect(memory_db)
        now = "2026-03-30T00:00:00"
        conn.execute(
            "INSERT INTO matters"
            " (name, current, status, source, opened_date, created_at, updated_at)"
            " VALUES ('My task', 'User set this', 'open', 'user', ?, ?, ?)",
            (now, now, now),
        )
        conn.commit()
        conn.close()
        write_matters(
            memory_db,
            [{"name": "My task", "current": "LLM wants this", "who": []}],
            date="2026-03-30",
        )
        conn = connect(memory_db)
        row = conn.execute("SELECT current FROM matters WHERE name='My task'").fetchone()
        assert row["current"] == "User set this"
        conn.close()


class TestDismissMatters:
    """Matter dismissal from LLM output."""

    def test_should_dismiss_matter_when_in_dismissed_list(self, memory_db):
        from argus_me.models import connect, dismiss_matters, write_matters

        write_matters(
            memory_db, [{"name": "Old task", "current": "Done", "who": []}], date="2026-03-30"
        )
        dismiss_matters(memory_db, ["Old task"])
        conn = connect(memory_db)
        row = conn.execute("SELECT status FROM matters WHERE name='Old task'").fetchone()
        assert row["status"] == "dismissed"
        conn.close()


class TestWriteRun:
    """Run record creation."""

    def test_should_insert_run_when_called(self, memory_db):
        from argus_me.models import connect, write_run

        result = {
            "summary": "Productive day, met with Tom.",
            "valence": 0.3,
            "arousal": 0.5,
            "emotion_word": "satisfied",
            "conflict": "Timeline pressure",
            "gaps": [{"type": "open_loop", "description": "Tom's decision"}],
        }
        run_id = write_run(memory_db, result, date="2026-03-30", model_version="qwen2.5:32b")
        conn = connect(memory_db)
        row = conn.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
        assert row is not None
        assert row["summary"] == "Productive day, met with Tom."
        assert row["valence"] == 0.3
        assert row["emotion_word"] == "satisfied"
        conn.close()


class TestWritePossibilities:
    """Possibility writes."""

    def test_should_insert_possibilities_when_called(self, memory_db):
        from argus_me.models import connect, write_matters, write_possibilities

        write_matters(
            memory_db, [{"name": "Launch", "current": "Planning", "who": []}], date="2026-03-30"
        )
        conn = connect(memory_db)
        matter_id = conn.execute("SELECT id FROM matters WHERE name='Launch'").fetchone()["id"]
        conn.close()

        possibilities = [
            {
                "matter_id": matter_id,
                "event": "Design approved",
                "narrative": "Review goes smoothly",
                "confidence": "high",
            }
        ]
        write_possibilities(memory_db, possibilities, run_id="run-001")
        conn = connect(memory_db)
        rows = conn.execute(
            "SELECT * FROM possibilities WHERE matter_id=?", (matter_id,)
        ).fetchall()
        assert len(rows) == 1
        assert rows[0]["event"] == "Design approved"
        conn.close()


class TestGetOpenMatters:
    """Query open matters."""

    def test_should_return_only_open_matters(self, memory_db):
        from argus_me.models import dismiss_matters, get_open_matters, write_matters

        write_matters(
            memory_db, [{"name": "Active", "current": "In progress", "who": []}], date="2026-03-30"
        )
        write_matters(
            memory_db, [{"name": "Done", "current": "Finished", "who": []}], date="2026-03-30"
        )
        dismiss_matters(memory_db, ["Done"])
        matters = get_open_matters(memory_db)
        assert len(matters) == 1
        assert matters[0]["name"] == "Active"


class TestGetEntitiesWithAliases:
    """Query entities with aliases for Call 1."""

    def test_should_return_entities_with_aliases(self, memory_db):
        from argus_me.models import ensure_self, get_all_entities_with_aliases, write_entities

        ensure_self(memory_db, "Wang Yu")
        write_entities(
            memory_db, [{"name": "Tom", "role": "colleague", "dynamics": 0.0}], date="2026-03-30"
        )
        entities = get_all_entities_with_aliases(memory_db)
        names = {e["canonical_name"] for e in entities}
        assert "Tom" in names
        assert "Wang Yu" in names


class TestSelfProfile:
    """Self-profile read/write."""

    def test_should_return_empty_when_no_profile(self, memory_db):
        from argus_me.models import ensure_self, read_self_profile

        ensure_self(memory_db, "Wang Yu")
        assert read_self_profile(memory_db) == ""

    def test_should_append_deltas(self, memory_db):
        from argus_me.models import append_self_profile, ensure_self, read_self_profile

        ensure_self(memory_db, "Wang Yu")
        append_self_profile(memory_db, ["Software engineer", "Father of two"])
        profile = read_self_profile(memory_db)
        assert "Software engineer" in profile
        assert "Father of two" in profile

    def test_should_accumulate_across_calls(self, memory_db):
        from argus_me.models import append_self_profile, ensure_self, read_self_profile

        ensure_self(memory_db, "Wang Yu")
        append_self_profile(memory_db, ["First observation"])
        append_self_profile(memory_db, ["Second observation"])
        profile = read_self_profile(memory_db)
        assert "First observation" in profile
        assert "Second observation" in profile
