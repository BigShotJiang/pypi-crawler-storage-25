"""Integration tests — real LLM calls via local Ollama.

Requires: Ollama running with qwen3:8b loaded.
Run with: pytest tests/test_integration.py -v -m slow
"""

import pytest

pytestmark = pytest.mark.slow

LLM_BASE_URL = "http://localhost:11434/v1"
LLM_MODEL = "qwen3:8b"


def _is_ollama_available():
    try:
        import httpx

        r = httpx.get("http://localhost:11434/api/tags", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


skip_no_ollama = pytest.mark.skipif(not _is_ollama_available(), reason="Ollama not running")


def _make_me(tmp_path):
    from argus_me import Me

    return Me(
        name="Wang Yu",
        db_path=str(tmp_path / "memory.db"),
        llm_base_url=LLM_BASE_URL,
        llm_model=LLM_MODEL,
    )


@skip_no_ollama
class TestFullCycle:
    """End-to-end: ingest → understand → snapshot."""

    def test_should_complete_full_cycle_with_conversation(self, tmp_path):
        me = _make_me(tmp_path)

        me.ingest(
            "Tom\n最近产品方向有点纠结，你觉得先做B端还是C端？\n\n"
            "me\n我倾向B端，变现快一些，但C端用户量大\n\n"
            "Tom\n那先做B端MVP试试水吧"
        )

        result = me.understand()

        assert result["fragments_processed"] == 1
        assert result["run_id"] is not None
        assert len(result["summary"]) > 0
        print(f"\n  summary: {result['summary'][:100]}")
        print(f"  emotion: {result['emotion']}")
        print(f"  conflict: {result['conflict'][:80]}")
        print(f"  entities: {result['entities_updated']}")
        print(f"  matters: {result['matters_updated']}")
        print(f"  possibilities: {result['possibilities_generated']}")

    def test_should_complete_full_cycle_with_diary(self, tmp_path):
        me = _make_me(tmp_path)

        me.ingest(
            "今天和Tom开会讨论了产品方向，决定先做B端MVP。"
            "心里还是有点犹豫，C端的想象空间更大。"
            "晚上回家路上想了想，觉得先活下来再说。"
        )

        result = me.understand()

        assert result["fragments_processed"] == 1
        assert result["run_id"] is not None
        print(f"\n  summary: {result['summary'][:100]}")
        print(f"  emotion: {result['emotion']}")

    def test_should_produce_valid_snapshot_after_understand(self, tmp_path):
        me = _make_me(tmp_path)

        me.ingest("和Tom确认了B端MVP的技术方案，下周开始开发。")
        me.understand()

        snap = me.snapshot()

        assert snap["self_profile"] is not None
        assert isinstance(snap["matters"], list)
        assert isinstance(snap["entities"], list)
        assert isinstance(snap["possibilities"], list)

        print(f"\n  self_profile: {snap['self_profile'][:80]}")
        print(f"  matters: {[m['name'] for m in snap['matters']]}")
        print(f"  entities: {[e['canonical_name'] for e in snap['entities']]}")
        print(f"  possibilities: {len(snap['possibilities'])}")
        print(f"  emotion: {snap['emotion']}")
        print(f"  gaps: {len(snap['gaps'])}")

    def test_should_accumulate_across_multiple_ingests(self, tmp_path):
        me = _make_me(tmp_path)

        me.ingest(
            "上午和Tom讨论了技术选型，决定用Python + SQLite。",
            date="2026-03-29",
        )
        me.ingest(
            "下午Judy来找我聊了她在BigCorp的困境，考虑跳槽。",
            date="2026-03-29",
        )

        result = me.understand()

        assert result["fragments_processed"] == 2
        # Should have extracted at least Tom and Judy
        entities = me.entities
        names = {e["canonical_name"] for e in entities}
        print(f"\n  entities found: {names}")
        print(f"  matters: {[m['name'] for m in me.matters]}")

    def test_should_handle_user_interactions_in_feedback_loop(self, tmp_path):
        me = _make_me(tmp_path)

        # First cycle
        me.ingest("和Tom讨论了融资的事情，他觉得时机还不成熟。")
        me.understand()

        # User interacts
        matters = me.matters
        if matters:
            me.dismiss(matters[0]["id"])
            print(f"\n  dismissed: {matters[0]['name']}")

        # Second cycle — should see the dismiss action as a fragment
        me.ingest("今天心情不错，觉得产品方向清晰了很多。")
        result = me.understand()

        assert result["fragments_processed"] >= 1
        print(f"  second cycle processed: {result['fragments_processed']} fragments")
        print(f"  open matters: {[m['name'] for m in me.matters]}")
