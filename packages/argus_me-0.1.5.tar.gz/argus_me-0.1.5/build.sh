#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-default}"

echo "=== format ==="
ruff check --fix src/ tests/
ruff format src/ tests/

echo ""
echo "=== lint ==="
ruff check src/ tests/
ruff format --check src/ tests/

echo ""
case "$MODE" in
    integration)
        echo "=== test (all, including slow) ==="
        pytest -q
        ;;
    *)
        echo "=== test (fast, skip slow) ==="
        pytest -q -m "not slow"
        ;;
esac

echo ""
echo "=== build ==="
python -m build --wheel -q

echo ""
echo "✅ all good"
