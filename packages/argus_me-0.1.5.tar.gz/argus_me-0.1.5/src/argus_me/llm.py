"""LLM client — prompt loading, transcript processing, and API calls."""

import copy
import json
import os
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import jinja2

# ── Prompt template loading ────────────────────────────────

_BUILTIN_PROMPT_DIR = Path(__file__).parent / "prompts"


def load_template(name: str, prompt_dir: str | None = None) -> jinja2.Template:
    """Load a Jinja2 prompt template by name (without .j2 extension).

    If prompt_dir is set, checks there first. Falls back to built-in templates.
    """
    filename = f"{name}.j2"
    if prompt_dir:
        custom_path = Path(prompt_dir) / filename
        if custom_path.exists():
            return jinja2.Template(custom_path.read_text(encoding="utf-8"))
    builtin_path = _BUILTIN_PROMPT_DIR / filename
    return jinja2.Template(builtin_path.read_text(encoding="utf-8"))


# ── Source type detection ──────────────────────────────────


def detect_source_type(transcript: str) -> str:
    """Detect whether transcript is a conversation or diary.

    Returns 'conv' if 2+ distinct speaker labels found, else 'diary'.
    """
    turns = _parse_turns(transcript)
    speakers = {t["speaker"].lower() for t in turns if t["speaker"]}
    return "conv" if len(speakers) >= 2 else "diary"


# ── Transcript compression ─────────────────────────────────

_FILLERS = re.compile(
    r"(?:^|\s)(?:"
    r"那个|就是说|然后就是|然后|反正|对吧|嗯+|啊+|哦+|呃+|就是|所以说|怎么说呢|"
    r"你知道吧|你懂的|我跟你说|就是这样|是这样的|基本上就是"
    r")(?=\s|$)"
)

_ACK_ONLY = re.compile(
    r"^(?:对+|嗯+|好+|好的|可以|是的?|是吧|OK|ok|Ok|没错|对对对|嗯嗯|行|哈哈+|哈)$"
)


def _parse_turns(transcript: str) -> list[dict]:
    """Parse transcript into speaker turns."""
    blocks = [b.strip() for b in re.split(r"\n\s*\n", transcript) if b.strip()]
    turns = []
    for block in blocks:
        lines = block.splitlines()
        if len(lines) < 2:
            turns.append({"speaker": "", "text": lines[0].strip(), "raw": block})
            continue
        first = lines[0].strip()
        if 1 <= len(first) <= 30 and not re.search(r'[。！？.!?，,；：:"""()]', first):
            speaker = first
            text = "\n".join(line.strip() for line in lines[1:] if line.strip())
        else:
            speaker = ""
            text = "\n".join(line.strip() for line in lines if line.strip())
        turns.append({"speaker": speaker, "text": text, "raw": block})
    return turns


def _turns_to_text(turns: list[dict]) -> str:
    """Reconstruct text from turn dicts."""
    parts = []
    for t in turns:
        if t["speaker"]:
            parts.append(f"{t['speaker']}\n{t['text']}")
        else:
            parts.append(t["text"])
    return "\n\n".join(parts)


def compress_transcript(transcript: str) -> tuple[str, dict]:
    """Compress oral transcript: remove fillers, ack-only turns, merge same-speaker runs."""
    original_chars = len(transcript)
    turns = _parse_turns(transcript)
    if not turns:
        return transcript, {
            "original_chars": original_chars,
            "compressed_chars": original_chars,
            "turns_removed": 0,
            "ratio": 1.0,
        }

    removed = 0

    for t in turns:
        t["text"] = _FILLERS.sub(" ", t["text"]).strip()
        t["text"] = re.sub(r"\s{2,}", " ", t["text"])

    filtered = []
    for t in turns:
        if t["speaker"] and _ACK_ONLY.match(t["text"]):
            removed += 1
            continue
        if not t["text"]:
            removed += 1
            continue
        filtered.append(t)

    merged = []
    for t in filtered:
        if merged and t["speaker"] and t["speaker"] == merged[-1]["speaker"]:
            merged[-1]["text"] += " " + t["text"]
        else:
            merged.append(dict(t))

    compressed = _turns_to_text(merged)
    compressed_chars = len(compressed)
    ratio = compressed_chars / original_chars if original_chars > 0 else 1.0

    return compressed, {
        "original_chars": original_chars,
        "compressed_chars": compressed_chars,
        "turns_removed": removed,
        "ratio": ratio,
    }


# ── Chunking ───────────────────────────────────────────────

_CHUNK_TARGET = int(os.environ.get("ARGUS_CHUNK_SIZE", "8000"))


def chunk_turns(
    turns: list[dict], target_size: int = _CHUNK_TARGET, overlap_turns: int = 3
) -> list[str]:
    """Split turns into chunks of approximately target_size chars with overlap."""
    if not turns:
        return [""]

    chunks: list[str] = []
    current_turns: list[dict] = []
    current_size = 0

    for t in turns:
        turn_text = f"{t['speaker']}\n{t['text']}" if t["speaker"] else t["text"]
        turn_size = len(turn_text) + 2

        if current_size + turn_size > target_size and current_turns:
            chunks.append(_turns_to_text(current_turns))
            overlap = (
                current_turns[-overlap_turns:]
                if len(current_turns) >= overlap_turns
                else current_turns[:]
            )
            current_turns = [dict(t) for t in overlap]
            current_size = sum(len(f"{x['speaker']}\n{x['text']}") + 2 for x in current_turns)

        current_turns.append(t)
        current_size += turn_size

    if current_turns:
        chunks.append(_turns_to_text(current_turns))

    return chunks


# ── JSON parsing ───────────────────────────────────────────

_DEFAULT_PARSE_RESULT: dict = {
    "summary": "",
    "conflict": "",
    "emotion": "unknown",
    "valence": 0.0,
    "arousal": 0.0,
    "persons": [],
    "new_matters": [],
    "dismissed": [],
    "gaps": [],
}


def strip_think_tags(raw: str) -> str:
    """Remove <think>...</think> blocks from reasoning model output."""
    return re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()


def parse_json(raw: str, default: dict | None = None) -> dict:
    """Extract JSON object from LLM output with tolerance for imperfect formatting."""
    cleaned = strip_think_tags(raw)

    try:
        return json.loads(cleaned)
    except (json.JSONDecodeError, TypeError):
        pass

    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass

    match = re.search(r"\{.*\}", raw, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            pass

    if default is not None:
        return default
    return copy.deepcopy(_DEFAULT_PARSE_RESULT)


def parse_json_array(raw: str) -> list[dict]:
    """Extract JSON array from LLM output."""
    cleaned = strip_think_tags(raw)
    for text in (cleaned, raw):
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
        match = re.search(r"\[.*\]", text, re.DOTALL)
        if match:
            try:
                parsed = json.loads(match.group())
                if isinstance(parsed, list):
                    return parsed
            except json.JSONDecodeError:
                pass
    return []


# ── LLM client ─────────────────────────────────────────────

_LLM_POOL = ThreadPoolExecutor(max_workers=1)


def create_client(base_url: str, api_key: str = "ollama", timeout: float = 900.0):
    """Create an OpenAI-compatible client."""
    import httpx
    from openai import OpenAI

    return OpenAI(
        base_url=base_url,
        api_key=api_key,
        timeout=httpx.Timeout(timeout, connect=10.0),
    )


def call_llm(
    client,
    model: str,
    prompt: str,
    *,
    temperature: float,
    max_tokens: int,
    timeout_s: float = 600.0,
) -> tuple[str, dict]:
    """Execute one LLM call. Returns (raw_text, metrics).

    Raises TimeoutError if the call exceeds wall_timeout_s (2x timeout_s).
    """
    import time
    from concurrent.futures import TimeoutError as FuturesTimeoutError

    wall_timeout_s = timeout_s * 2
    t0 = time.time()

    def _do_call():
        return client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=timeout_s,
        )

    try:
        future = _LLM_POOL.submit(_do_call)
        response = future.result(timeout=wall_timeout_s)
    except (FuturesTimeoutError, TimeoutError):
        raise TimeoutError(f"LLM call timeout after {time.time() - t0:.0f}s")

    duration_s = time.time() - t0
    usage = response.usage
    metrics = {
        "model": model,
        "prompt_tokens": usage.prompt_tokens if usage else 0,
        "completion_tokens": usage.completion_tokens if usage else 0,
        "duration_s": duration_s,
    }
    return response.choices[0].message.content, metrics
