"""Database operations for memory.db."""

import json as _json
import sqlite3
from datetime import datetime, timezone

import uuid6

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS fragments (
    id          TEXT PRIMARY KEY,
    type        TEXT NOT NULL,
    date        TEXT NOT NULL,
    source      TEXT,
    raw         TEXT,
    transcript  TEXT,
    metadata    TEXT DEFAULT '{}',
    processed   INTEGER DEFAULT 0,
    run_id      TEXT,
    created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS entities (
    id               TEXT PRIMARY KEY,
    canonical_name   TEXT NOT NULL UNIQUE,
    dynamics         REAL DEFAULT 0.0,
    interaction_count INTEGER DEFAULT 1,
    first_seen       TEXT NOT NULL,
    last_seen        TEXT NOT NULL,
    note             TEXT DEFAULT '',
    self_profile     TEXT DEFAULT '',
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS entity_aliases (
    alias      TEXT PRIMARY KEY,
    entity_id  TEXT NOT NULL REFERENCES entities(id),
    confidence REAL DEFAULT 1.0,
    source     TEXT DEFAULT 'system',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS matters (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT,
    current          TEXT,
    status           TEXT DEFAULT 'open',
    source           TEXT DEFAULT 'llm',
    priority         REAL DEFAULT 0.5,
    opened_date      TEXT NOT NULL,
    mention_count    INTEGER DEFAULT 1,
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS matter_entities (
    matter_id      INTEGER NOT NULL REFERENCES matters(id),
    entity_id      TEXT NOT NULL REFERENCES entities(id),
    role_in_matter TEXT,
    UNIQUE(matter_id, entity_id)
);

CREATE TABLE IF NOT EXISTS runs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    date         TEXT NOT NULL,
    run_id       TEXT NOT NULL,
    summary      TEXT NOT NULL,
    valence      REAL,
    arousal      REAL,
    emotion_word TEXT,
    conflict     TEXT DEFAULT '',
    gaps         TEXT DEFAULT '[]',
    model_version TEXT,
    created_at   TEXT NOT NULL,
    epoch_id     INTEGER REFERENCES epochs(id)
);

CREATE TABLE IF NOT EXISTS possibilities (
    id                    TEXT PRIMARY KEY,
    matter_id             INTEGER REFERENCES matters(id),
    event                 TEXT NOT NULL,
    narrative             TEXT DEFAULT '',
    confidence            TEXT DEFAULT 'medium',
    prob                  REAL,
    historical_precedent  TEXT DEFAULT '',
    status                TEXT DEFAULT '',
    run_id                TEXT,
    created_at            TEXT NOT NULL,
    validated_at          TEXT
);

CREATE TABLE IF NOT EXISTS intentions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    content         TEXT NOT NULL,
    type            TEXT NOT NULL,
    confidence      REAL NOT NULL,
    status          TEXT DEFAULT 'active',
    formed_date     TEXT NOT NULL,
    last_reinforced TEXT,
    related_matters TEXT,
    evidence        TEXT,
    surfaced_at     TEXT,
    run_id          TEXT,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS insight_queue (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    type        TEXT NOT NULL,
    description TEXT NOT NULL,
    evidence    TEXT,
    priority    TEXT DEFAULT 'medium',
    status      TEXT DEFAULT 'pending',
    run_id      TEXT,
    detected_at TEXT NOT NULL,
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fragments_unprocessed
    ON fragments(processed, date) WHERE processed = 0;
CREATE INDEX IF NOT EXISTS idx_matter_entities_entity
    ON matter_entities(entity_id);
CREATE INDEX IF NOT EXISTS idx_possibilities_matter
    ON possibilities(matter_id, status);
CREATE INDEX IF NOT EXISTS idx_intentions_active
    ON intentions(status) WHERE status = 'active';
CREATE INDEX IF NOT EXISTS idx_insight_queue_pending
    ON insight_queue(status) WHERE status = 'pending';

CREATE TABLE IF NOT EXISTS epochs (
    id                       INTEGER PRIMARY KEY AUTOINCREMENT,
    start_date               TEXT NOT NULL,
    end_date                 TEXT NOT NULL,
    run_count                INTEGER NOT NULL,
    summary                  TEXT NOT NULL,
    themes                   TEXT DEFAULT '[]',
    avg_valence              REAL,
    self_model_delta         TEXT DEFAULT '',
    boundary_start_trigger   TEXT,
    boundary_start_run_id    INTEGER,
    boundary_start_context_shift TEXT,
    boundary_end_state       TEXT,
    boundary_end_run_id      INTEGER,
    boundary_end_unresolved  TEXT DEFAULT '[]',
    continuing_threads       TEXT DEFAULT '[]',
    created_at               TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS observations (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    date               TEXT NOT NULL,
    source             TEXT NOT NULL,
    content            TEXT NOT NULL,
    tags               TEXT DEFAULT '[]',
    confidence         REAL DEFAULT 0.5,
    observation_type   TEXT DEFAULT 'behavior',
    evidence_fragments TEXT DEFAULT '[]',
    superseded_by      INTEGER REFERENCES observations(id),
    run_id             TEXT,
    created_at         TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_observations_source
    ON observations(source);
CREATE INDEX IF NOT EXISTS idx_observations_type
    ON observations(observation_type);
CREATE INDEX IF NOT EXISTS idx_observations_confidence
    ON observations(confidence);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def connect(path: str) -> sqlite3.Connection:
    """Open a connection with WAL mode and foreign keys enabled."""
    conn = sqlite3.connect(path, timeout=5)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.row_factory = sqlite3.Row
    return conn


def init_db(path: str) -> None:
    """Create all tables, set schema version, and migrate if needed. Idempotent."""
    conn = connect(path)
    try:
        conn.executescript(_SCHEMA_SQL)
        existing = conn.execute(
            "SELECT value FROM meta WHERE key='schema_version'"
        ).fetchone()
        if existing is None:
            conn.execute(
                "INSERT INTO meta (key, value) VALUES ('schema_version', '20')"
            )
            conn.commit()
        else:
            version = int(existing["value"])
            if version < 20:
                _migrate_to_v20(conn)
    finally:
        conn.close()


def _migrate_to_v20(conn: sqlite3.Connection) -> None:
    """Migrate schema from v19 to v20. Adds epochs, observations, runs.epoch_id."""
    cols = {r["name"] for r in conn.execute("PRAGMA table_info(runs)").fetchall()}
    if "epoch_id" not in cols:
        conn.execute(
            "ALTER TABLE runs ADD COLUMN epoch_id"
            " INTEGER REFERENCES epochs(id)"
        )
    conn.execute(
        "UPDATE meta SET value='20' WHERE key='schema_version'"
    )
    conn.commit()


def ensure_self(path: str, name: str) -> None:
    """Create the self entity and default aliases if not present. Idempotent."""
    conn = connect(path)
    try:
        now = _now()
        existing = conn.execute("SELECT id FROM entities WHERE id='self'").fetchone()
        if existing is None:
            conn.execute(
                "INSERT INTO entities"
                " (id, canonical_name, first_seen, last_seen, created_at, updated_at)"
                " VALUES ('self', ?, ?, ?, ?, ?)",
                (name, now, now, now, now),
            )
            conn.execute(
                "INSERT INTO entity_aliases (alias, entity_id, confidence, source, created_at)"
                " VALUES (?, 'self', 1.0, 'system', ?)",
                (name, now),
            )
            conn.commit()
    finally:
        conn.close()


def write_fragment(
    path: str,
    *,
    text: str,
    date: str,
    fragment_type: str = "text",
    source: str = "ingest",
) -> str:
    """Insert a fragment and return its ID."""
    conn = connect(path)
    try:
        fid = str(uuid6.uuid7())
        now = _now()
        conn.execute(
            "INSERT INTO fragments (id, type, date, source, transcript, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (fid, fragment_type, date, source, text, now),
        )
        conn.commit()
        return fid
    finally:
        conn.close()


def get_unprocessed_fragments(path: str) -> list[dict]:
    """Return all unprocessed fragments ordered by date."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM fragments WHERE processed=0 ORDER BY date, created_at"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def mark_fragments_processed(path: str, fragment_ids: list[str], run_id: str) -> None:
    """Mark fragments as processed by a run."""
    conn = connect(path)
    try:
        conn.executemany(
            "UPDATE fragments SET processed=1, run_id=? WHERE id=?",
            [(run_id, fid) for fid in fragment_ids],
        )
        conn.commit()
    finally:
        conn.close()


# ── Self aliases that should be skipped during entity writes ──

_SELF_NAMES = frozenset({"我", "自己", "本人", "me"})


def _is_self_name(name: str, path: str, *, conn: sqlite3.Connection | None = None) -> bool:
    """Check if a name refers to self (by alias or known self-names)."""
    if name.lower() in _SELF_NAMES:
        return True
    _conn = conn or connect(path)
    try:
        row = _conn.execute(
            "SELECT entity_id FROM entity_aliases WHERE alias=?", (name,)
        ).fetchone()
        return row is not None and row["entity_id"] == "self"
    finally:
        if conn is None:
            _conn.close()


# ── Entity writes ──────────────────────────────────────────

_EWMA_ALPHA = 0.3


def write_entities(path: str, persons: list[dict], *, date: str) -> None:
    """Upsert entities from LLM output. Applies EWMA to dynamics. Skips self."""
    conn = connect(path)
    try:
        now = _now()
        for p in persons:
            name = p.get("name", "").strip()
            if not name or _is_self_name(name, path, conn=conn):
                continue
            dynamics = float(p.get("dynamics", 0.0))

            existing = conn.execute(
                "SELECT id, dynamics, interaction_count FROM entities WHERE canonical_name=?",
                (name,),
            ).fetchone()

            if existing is None:
                eid = str(uuid6.uuid7())
                conn.execute(
                    "INSERT INTO entities"
                    " (id, canonical_name, dynamics, interaction_count,"
                    " first_seen, last_seen, created_at, updated_at)"
                    " VALUES (?, ?, ?, 1, ?, ?, ?, ?)",
                    (eid, name, dynamics, date, date, now, now),
                )
                conn.execute(
                    "INSERT OR IGNORE INTO entity_aliases"
                    " (alias, entity_id, confidence, source, created_at)"
                    " VALUES (?, ?, 1.0, 'llm', ?)",
                    (name, eid, now),
                )
            else:
                new_dyn = round(
                    (1 - _EWMA_ALPHA) * existing["dynamics"] + _EWMA_ALPHA * dynamics, 3
                )
                conn.execute(
                    "UPDATE entities SET dynamics=?,"
                    " interaction_count=interaction_count+1,"
                    " last_seen=?, updated_at=? WHERE id=?",
                    (new_dyn, date, now, existing["id"]),
                )
        conn.commit()
    finally:
        conn.close()


# ── Matter writes ──────────────────────────────────────────


def write_matters(path: str, matters: list[dict], *, date: str) -> None:
    """Upsert matters from LLM output. Increments mention_count. Respects user source."""
    conn = connect(path)
    try:
        now = _now()
        for m in matters:
            name = m.get("name", "").strip()
            if not name:
                continue
            current = m.get("current", "")

            existing = conn.execute(
                "SELECT id, source FROM matters WHERE name=? AND status='open'",
                (name,),
            ).fetchone()

            if existing is None:
                conn.execute(
                    "INSERT INTO matters"
                    " (name, current, status, source, opened_date,"
                    " created_at, updated_at)"
                    " VALUES (?, ?, 'open', 'llm', ?, ?, ?)",
                    (name, current, date, now, now),
                )
            else:
                if existing["source"] == "user":
                    conn.execute(
                        "UPDATE matters SET mention_count=mention_count+1,"
                        " updated_at=? WHERE id=?",
                        (now, existing["id"]),
                    )
                else:
                    conn.execute(
                        "UPDATE matters SET current=?,"
                        " mention_count=mention_count+1,"
                        " updated_at=? WHERE id=?",
                        (current, now, existing["id"]),
                    )
        conn.commit()
    finally:
        conn.close()


def dismiss_matters(path: str, names: list[str]) -> None:
    """Dismiss matters by name."""
    if not names:
        return
    conn = connect(path)
    try:
        now = _now()
        for name in names:
            conn.execute(
                "UPDATE matters SET status='dismissed', updated_at=?"
                " WHERE name=? AND status='open'",
                (now, name),
            )
        conn.commit()
    finally:
        conn.close()


def get_open_matters(path: str) -> list[dict]:
    """Return all open matters."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM matters WHERE status='open' ORDER BY priority DESC, mention_count DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Run writes ─────────────────────────────────────────────


def write_run(path: str, result: dict, *, date: str, model_version: str = "") -> str:
    """Insert a run record. Returns run_id."""
    conn = connect(path)
    try:
        run_id = str(uuid6.uuid7())
        now = _now()
        gaps = result.get("gaps", [])
        conn.execute(
            "INSERT INTO runs"
            " (date, run_id, summary, valence, arousal,"
            " emotion_word, conflict, gaps, model_version, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                date,
                run_id,
                result.get("summary", ""),
                result.get("valence"),
                result.get("arousal"),
                result.get("emotion_word", ""),
                result.get("conflict", ""),
                _json.dumps(gaps, ensure_ascii=False),
                model_version,
                now,
            ),
        )
        conn.commit()
        return run_id
    finally:
        conn.close()


# ── Possibility writes ─────────────────────────────────────


def write_possibilities(path: str, possibilities: list[dict], *, run_id: str) -> None:
    """Insert possibilities for a run."""
    conn = connect(path)
    try:
        now = _now()
        for p in possibilities:
            pid = str(uuid6.uuid7())
            conn.execute(
                "INSERT INTO possibilities"
                " (id, matter_id, event, narrative, confidence,"
                " prob, historical_precedent, run_id, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    pid,
                    p.get("matter_id"),
                    p.get("event", ""),
                    p.get("narrative", ""),
                    p.get("confidence", "medium"),
                    p.get("prob"),
                    p.get("historical_precedent", ""),
                    run_id,
                    now,
                ),
            )
        conn.commit()
    finally:
        conn.close()


# ── Entity queries ─────────────────────────────────────────


def get_all_entities_with_aliases(path: str) -> list[dict]:
    """Return all entities with their aliases (for Call 1 identity resolution)."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT e.*, ea.alias"
            " FROM entities e"
            " LEFT JOIN entity_aliases ea ON ea.entity_id = e.id"
            " ORDER BY e.id"
        ).fetchall()
        entities: dict[str, dict] = {}
        for r in rows:
            eid = r["id"]
            if eid not in entities:
                d = dict(r)
                d.pop("alias", None)
                d["aliases"] = []
                entities[eid] = d
            if r["alias"] is not None:
                entities[eid]["aliases"].append(r["alias"])
        return list(entities.values())
    finally:
        conn.close()


# ── Self-profile ───────────────────────────────────────────


def read_self_profile(path: str) -> str:
    """Read the self entity's profile text."""
    conn = connect(path)
    try:
        row = conn.execute("SELECT self_profile FROM entities WHERE id='self'").fetchone()
        return row["self_profile"] if row else ""
    finally:
        conn.close()


def append_self_profile(path: str, deltas: list[str]) -> None:
    """Append observation lines to the self-profile."""
    if not deltas:
        return
    conn = connect(path)
    try:
        current = conn.execute("SELECT self_profile FROM entities WHERE id='self'").fetchone()[
            "self_profile"
        ]
        new_lines = "\n".join(f"- {d}" for d in deltas)
        updated = f"{current}\n{new_lines}" if current else new_lines
        conn.execute(
            "UPDATE entities SET self_profile=?, updated_at=? WHERE id='self'",
            (updated, _now()),
        )
        conn.commit()
    finally:
        conn.close()


# ── Snapshot & live queries ────────────────────────────────


def get_all_entities(path: str) -> list[dict]:
    """Return all non-self entities."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM entities WHERE id != 'self'" " ORDER BY interaction_count DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_active_possibilities(path: str) -> list[dict]:
    """Return active possibilities (not dismissed/expired)."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM possibilities"
            " WHERE status = '' OR status IS NULL"
            " ORDER BY created_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_recent_runs(path: str, limit: int = 10) -> list[dict]:
    """Return recent runs ordered by date descending."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM runs ORDER BY date DESC, created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_latest_gaps(path: str) -> list:
    """Return gaps from the most recent run."""
    conn = connect(path)
    try:
        row = conn.execute(
            "SELECT gaps FROM runs" " ORDER BY date DESC, created_at DESC LIMIT 1"
        ).fetchone()
        if row and row["gaps"]:
            return _json.loads(row["gaps"])
        return []
    finally:
        conn.close()


def get_latest_emotion(path: str) -> dict:
    """Return emotion from the most recent run."""
    conn = connect(path)
    try:
        row = conn.execute(
            "SELECT emotion_word, valence, arousal"
            " FROM runs ORDER BY date DESC, created_at DESC LIMIT 1"
        ).fetchone()
        if row:
            return {
                "word": row["emotion_word"] or "",
                "valence": row["valence"],
                "arousal": row["arousal"],
            }
        return {"word": "", "valence": None, "arousal": None}
    finally:
        conn.close()


# ── User interaction DB ops ────────────────────────────────


def dismiss_matter_by_id(path: str, matter_id: int) -> str:
    """Dismiss a matter by ID. Returns matter name."""
    conn = connect(path)
    try:
        row = conn.execute("SELECT name FROM matters WHERE id=?", (matter_id,)).fetchone()
        name = row["name"] if row else str(matter_id)
        conn.execute(
            "UPDATE matters SET status='dismissed', updated_at=? WHERE id=?",
            (_now(), matter_id),
        )
        conn.commit()
        return name
    finally:
        conn.close()


def expect_possibility(path: str, possibility_id: str) -> str:
    """Mark a possibility as expected. Returns event text."""
    conn = connect(path)
    try:
        row = conn.execute(
            "SELECT event, matter_id FROM possibilities WHERE id=?",
            (possibility_id,),
        ).fetchone()
        event = row["event"] if row else ""
        # Clear other expectations for same matter
        if row and row["matter_id"]:
            conn.execute(
                "UPDATE possibilities SET status=''" " WHERE matter_id=? AND status='expected'",
                (row["matter_id"],),
            )
        conn.execute(
            "UPDATE possibilities SET status='expected', validated_at=?" " WHERE id=?",
            (_now(), possibility_id),
        )
        conn.commit()
        return event
    finally:
        conn.close()


def register_alias(path: str, alias: str, entity_id: str = "self") -> None:
    """Register a name alias for an entity."""
    conn = connect(path)
    try:
        conn.execute(
            "INSERT OR REPLACE INTO entity_aliases"
            " (alias, entity_id, confidence, source, created_at)"
            " VALUES (?, ?, 1.0, 'user', ?)",
            (alias, entity_id, _now()),
        )
        conn.commit()
    finally:
        conn.close()


def merge_entities(path: str, keep_id: str, absorb_id: str) -> tuple[str, str]:
    """Merge absorb entity into keep. Returns (keep_name, absorb_name)."""
    if keep_id == absorb_id:
        return ("", "")
    conn = connect(path)
    try:
        keep = conn.execute("SELECT canonical_name FROM entities WHERE id=?", (keep_id,)).fetchone()
        absorb = conn.execute(
            "SELECT canonical_name FROM entities WHERE id=?", (absorb_id,)
        ).fetchone()
        keep_name = keep["canonical_name"] if keep else keep_id
        absorb_name = absorb["canonical_name"] if absorb else absorb_id

        # Transfer aliases
        conn.execute(
            "UPDATE entity_aliases SET entity_id=? WHERE entity_id=?",
            (keep_id, absorb_id),
        )
        # Transfer matter connections (skip duplicates)
        conn.execute(
            "UPDATE OR IGNORE matter_entities SET entity_id=?" " WHERE entity_id=?",
            (keep_id, absorb_id),
        )
        conn.execute(
            "DELETE FROM matter_entities WHERE entity_id=?",
            (absorb_id,),
        )
        # If merging into self, enrich self_profile
        if keep_id == "self" and absorb:
            note = conn.execute("SELECT note FROM entities WHERE id=?", (absorb_id,)).fetchone()
            if note and note["note"]:
                current = conn.execute(
                    "SELECT self_profile FROM entities WHERE id='self'"
                ).fetchone()["self_profile"]
                addition = f"- (merged from {absorb_name}) {note['note']}"
                updated = f"{current}\n{addition}" if current else addition
                conn.execute(
                    "UPDATE entities SET self_profile=?, updated_at=?" " WHERE id='self'",
                    (updated, _now()),
                )
        # Remove absorbed entity
        conn.execute("DELETE FROM entities WHERE id=?", (absorb_id,))
        conn.commit()
        return keep_name, absorb_name
    finally:
        conn.close()


def update_entity_note(path: str, entity_id: str, text: str) -> str:
    """Append a note to an entity. Returns entity name."""
    conn = connect(path)
    try:
        row = conn.execute(
            "SELECT canonical_name, note FROM entities WHERE id=?",
            (entity_id,),
        ).fetchone()
        name = row["canonical_name"] if row else entity_id
        current_note = row["note"] if row else ""
        updated = f"{current_note}\n{text}" if current_note else text
        conn.execute(
            "UPDATE entities SET note=?, updated_at=? WHERE id=?",
            (updated, _now(), entity_id),
        )
        conn.commit()
        return name
    finally:
        conn.close()


def update_self_profile(path: str, text: str) -> None:
    """Replace the self-profile text (user-authoritative)."""
    conn = connect(path)
    try:
        conn.execute(
            "UPDATE entities SET self_profile=?, updated_at=?" " WHERE id='self'",
            (text, _now()),
        )
        conn.commit()
    finally:
        conn.close()


def set_matter_priorities(path: str, matter_ids: list[int]) -> None:
    """Set display priority: first ID = highest."""
    conn = connect(path)
    try:
        total = len(matter_ids)
        for i, mid in enumerate(matter_ids):
            priority = round(1.0 - i / max(total, 1), 3)
            conn.execute(
                "UPDATE matters SET priority=?, updated_at=? WHERE id=?",
                (priority, _now(), mid),
            )
        conn.commit()
    finally:
        conn.close()


def get_pending_insights(path: str) -> list[dict]:
    """Return pending insights from the insight queue."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM insight_queue WHERE status='pending'"
            " ORDER BY priority DESC, detected_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Observations CRUD ──────────────────────────────────────


def write_observation(
    path: str,
    *,
    source: str,
    content: str,
    observation_type: str = "behavior",
    tags: list[str] | None = None,
    confidence: float = 0.5,
    evidence_fragments: list[str] | None = None,
    run_id: str | None = None,
) -> int:
    """Insert an observation. Returns observation ID."""
    conn = connect(path)
    try:
        now = _now()
        from datetime import date as _date

        today = _date.today().isoformat()
        cursor = conn.execute(
            "INSERT INTO observations"
            " (date, source, content, tags, confidence,"
            " observation_type, evidence_fragments, run_id, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                today,
                source,
                content,
                _json.dumps(tags or []),
                confidence,
                observation_type,
                _json.dumps(evidence_fragments or []),
                run_id,
                now,
            ),
        )
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()


def get_current_observations(path: str) -> list[dict]:
    """Return non-superseded observations, most recent first."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM observations"
            " WHERE superseded_by IS NULL"
            " ORDER BY created_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Epoch CRUD ─────────────────────────────────────────────


def write_epoch(
    path: str,
    *,
    start_date: str,
    end_date: str,
    run_count: int,
    summary: str,
    themes: list[str] | None = None,
    avg_valence: float | None = None,
    self_model_delta: str = "",
    boundary_start_trigger: str | None = None,
    boundary_end_state: str | None = None,
    boundary_end_unresolved: list[str] | None = None,
    continuing_threads: list | None = None,
) -> int:
    """Insert an epoch. Returns epoch ID."""
    conn = connect(path)
    try:
        now = _now()
        cursor = conn.execute(
            "INSERT INTO epochs"
            " (start_date, end_date, run_count, summary, themes,"
            " avg_valence, self_model_delta,"
            " boundary_start_trigger, boundary_end_state,"
            " boundary_end_unresolved, continuing_threads, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                start_date,
                end_date,
                run_count,
                summary,
                _json.dumps(themes or []),
                avg_valence,
                self_model_delta,
                boundary_start_trigger,
                boundary_end_state,
                _json.dumps(boundary_end_unresolved or []),
                _json.dumps(continuing_threads or []),
                now,
            ),
        )
        conn.commit()
        return cursor.lastrowid
    finally:
        conn.close()


def get_epochs(path: str, *, limit: int = 10) -> list[dict]:
    """Return epochs ordered by end_date descending."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM epochs ORDER BY end_date DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_epoch_count(path: str) -> int:
    """Return total number of epochs."""
    conn = connect(path)
    try:
        return conn.execute("SELECT COUNT(*) FROM epochs").fetchone()[0]
    finally:
        conn.close()


def get_unconsolidated_runs(path: str) -> list[dict]:
    """Return runs not yet assigned to an epoch, ordered by date."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM runs WHERE epoch_id IS NULL"
            " ORDER BY date, created_at"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def get_unconsolidated_run_count(path: str) -> int:
    """Count of runs not yet assigned to an epoch."""
    conn = connect(path)
    try:
        return conn.execute(
            "SELECT COUNT(*) FROM runs WHERE epoch_id IS NULL"
        ).fetchone()[0]
    finally:
        conn.close()


def set_run_epoch(path: str, run_pk: int, epoch_id: int) -> None:
    """Assign a run to an epoch."""
    conn = connect(path)
    try:
        conn.execute(
            "UPDATE runs SET epoch_id=? WHERE id=?",
            (epoch_id, run_pk),
        )
        conn.commit()
    finally:
        conn.close()


def get_recent_action_fragments(path: str, days: int = 7) -> list[dict]:
    """Return action fragments from the last N days."""
    from datetime import date, timedelta

    cutoff = (date.today() - timedelta(days=days)).isoformat()
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM fragments"
            " WHERE type='action' AND date >= ?"
            " ORDER BY date, created_at",
            (cutoff,),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()
