"""PII redaction wrapper — delegates to argus-redact when available."""

try:
    from argus_redact import redact as _argus_redact
    from argus_redact import restore as _argus_restore

    _HAS_ARGUS_REDACT = True
except ImportError:
    _HAS_ARGUS_REDACT = False


def redact_text(
    text: str, *, names: list[str] | None = None, mode: str = "auto"
) -> tuple[str, dict]:
    """Redact PII from text. Returns (redacted_text, key).

    mode: 'auto' (regex + NER if available), 'fast' (regex only), 'ner' (NER only)
    Key maps pseudonyms to original values for later restoration.
    If argus-redact is not installed, returns original text with empty key.
    """
    if not _HAS_ARGUS_REDACT:
        return text, {}
    redacted, key = _argus_redact(text, names=names or [], mode=mode)
    return redacted, dict(key)


def restore_text(text: str, key: dict) -> str:
    """Restore redacted text using a key from redact_text().

    If argus-redact is not installed or key is empty, returns text unchanged.
    """
    if not key:
        return text
    if not _HAS_ARGUS_REDACT:
        return text
    return _argus_restore(text, key)


def is_available() -> bool:
    """Check if argus-redact is installed."""
    return _HAS_ARGUS_REDACT
