"""Subconscious — stats preamble, cognitive debt scanning, anti-bias.

Pure statistics + heuristics. Never calls LLMs.
Runs inline at the end of every understand() call.
"""

from datetime import date, datetime, timedelta, timezone

from .models import connect


def _today() -> str:
    return date.today().isoformat()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Stats preamble ─────────────────────────────────────────


def generate_preamble(path: str) -> dict:
    """Generate stats preamble for LLM prompt injection. Read-only."""
    conn = connect(path)
    try:
        preamble: dict = {}

        # Emotion trend: 7d vs 30d valence mean
        today = date.today()
        d7 = (today - timedelta(days=7)).isoformat()
        d30 = (today - timedelta(days=30)).isoformat()

        rows_7d = conn.execute(
            "SELECT valence FROM runs WHERE date >= ? AND valence IS NOT NULL",
            (d7,),
        ).fetchall()
        rows_30d = conn.execute(
            "SELECT valence FROM runs WHERE date >= ? AND valence IS NOT NULL",
            (d30,),
        ).fetchall()

        if rows_7d:
            mean_7d = round(sum(r["valence"] for r in rows_7d) / len(rows_7d), 2)
            mean_30d = (
                round(sum(r["valence"] for r in rows_30d) / len(rows_30d), 2)
                if rows_30d
                else mean_7d
            )
            if mean_7d > mean_30d + 0.1:
                direction = "rising"
            elif mean_7d < mean_30d - 0.1:
                direction = "falling"
            else:
                direction = "stable"
            preamble["emotion_trend"] = {
                "7d_mean": mean_7d,
                "30d_mean": mean_30d,
                "direction": direction,
            }

        # Matter staleness: open matters with days since last run mention
        open_matters = conn.execute(
            "SELECT id, name, opened_date FROM matters WHERE status='open'"
        ).fetchall()
        staleness = []
        for m in open_matters:
            last_run = conn.execute(
                "SELECT MAX(date) as last_date FROM runs" " WHERE summary LIKE ?",
                (f"%{m['name']}%",),
            ).fetchone()
            last_date = last_run["last_date"] if last_run else m["opened_date"]
            if last_date:
                try:
                    days = (today - date.fromisoformat(last_date)).days
                except (ValueError, TypeError):
                    days = 0
                staleness.append(
                    {
                        "name": m["name"],
                        "days_since_mention": days,
                    }
                )
        if staleness:
            staleness.sort(key=lambda x: x["days_since_mention"], reverse=True)
            preamble["matter_staleness"] = staleness

        return preamble
    finally:
        conn.close()


# ── Cognitive debt scanning ────────────────────────────────


def scan_debts(path: str) -> list[dict]:
    """Detect cognitive debts. Returns insight dicts (does not write)."""
    insights: list[dict] = []
    insights.extend(_scan_stale_matters(path))
    insights.extend(_scan_emotion_inflection(path))
    return insights


def _scan_stale_matters(path: str) -> list[dict]:
    """Open matters not mentioned in runs for >7 days."""
    conn = connect(path)
    try:
        today = date.today()
        matters = conn.execute(
            "SELECT id, name, opened_date FROM matters WHERE status='open'"
        ).fetchall()
        insights = []
        for m in matters:
            last_run = conn.execute(
                "SELECT MAX(date) as last_date FROM runs WHERE summary LIKE ?",
                (f"%{m['name']}%",),
            ).fetchone()
            last_date = last_run["last_date"] if last_run else m["opened_date"]
            if last_date:
                try:
                    days = (today - date.fromisoformat(last_date)).days
                except (ValueError, TypeError):
                    continue
                if days >= 7:
                    priority = "high" if days >= 14 else "medium"
                    insights.append(
                        {
                            "type": "stale_matter",
                            "description": (f"{m['name']} inactive for {days} days"),
                            "priority": priority,
                        }
                    )
        return insights
    finally:
        conn.close()


def _scan_emotion_inflection(path: str) -> list[dict]:
    """3+ consecutive days of same-direction valence change."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT date, valence FROM runs"
            " WHERE valence IS NOT NULL"
            " ORDER BY date DESC LIMIT 7"
        ).fetchall()
        if len(rows) < 3:
            return []

        # Check for monotonic decline or rise
        vals = [r["valence"] for r in reversed(rows)]
        declining = all(vals[i] > vals[i + 1] for i in range(min(3, len(vals) - 1)))
        rising = all(vals[i] < vals[i + 1] for i in range(min(3, len(vals) - 1)))

        insights = []
        if declining:
            priority = "high" if vals[-1] < -0.3 else "medium"
            insights.append(
                {
                    "type": "emotion_inflection",
                    "description": "Emotional valence declining for 3+ consecutive days",
                    "priority": priority,
                }
            )
        elif rising:
            insights.append(
                {
                    "type": "emotion_inflection",
                    "description": "Emotional valence rising for 3+ consecutive days",
                    "priority": "low",
                }
            )
        return insights
    finally:
        conn.close()


# ── Anti-bias scanning ─────────────────────────────────────


def scan_antibias(path: str) -> list[dict]:
    """Bias-specific detections. Returns insight dicts."""
    insights: list[dict] = []
    insights.extend(_scan_echo_chamber(path))
    insights.extend(_scan_emotion_granularity(path))
    return insights


def _scan_echo_chamber(path: str) -> list[dict]:
    """>80% of recent fragments involve only 1-2 entities (14-day window)."""
    conn = connect(path)
    try:
        d14 = (date.today() - timedelta(days=14)).isoformat()
        fragments = conn.execute(
            "SELECT transcript FROM fragments WHERE date >= ? AND type='text'",
            (d14,),
        ).fetchall()
        if len(fragments) < 5:
            return []

        entities = conn.execute("SELECT canonical_name FROM entities WHERE id != 'self'").fetchall()
        if not entities:
            return []

        entity_names = [e["canonical_name"] for e in entities]
        mention_counts: dict[str, int] = {}
        for f in fragments:
            text = f["transcript"] or ""
            for name in entity_names:
                if name in text:
                    mention_counts[name] = mention_counts.get(name, 0) + 1

        if not mention_counts:
            return []

        total_mentions = sum(mention_counts.values())
        top_2 = sorted(mention_counts.values(), reverse=True)[:2]
        top_2_sum = sum(top_2)

        if total_mentions > 0 and top_2_sum / total_mentions > 0.8:
            return [
                {
                    "type": "echo_chamber_risk",
                    "description": ("Most recent fragments involve only 1-2 people"),
                    "priority": "medium",
                }
            ]
        return []
    finally:
        conn.close()


def _scan_emotion_granularity(path: str) -> list[dict]:
    """<3 distinct emotion words in 30 days."""
    conn = connect(path)
    try:
        d30 = (date.today() - timedelta(days=30)).isoformat()
        rows = conn.execute(
            "SELECT DISTINCT emotion_word FROM runs"
            " WHERE date >= ? AND emotion_word IS NOT NULL"
            " AND emotion_word != ''",
            (d30,),
        ).fetchall()
        distinct = len(rows)
        if distinct > 0 and distinct < 3:
            return [
                {
                    "type": "low_emotion_granularity",
                    "description": (f"Only {distinct} distinct emotion words in 30 days"),
                    "priority": "medium",
                }
            ]
        return []
    finally:
        conn.close()


# ── Insight queue writes ───────────────────────────────────


def write_insights(path: str, insights: list[dict]) -> None:
    """Write insights to queue with 7-day dedup."""
    if not insights:
        return
    conn = connect(path)
    try:
        now = _now()
        d7 = (date.today() - timedelta(days=7)).isoformat()
        for ins in insights:
            # Dedup: same type + description within 7 days
            existing = conn.execute(
                "SELECT id FROM insight_queue"
                " WHERE type=? AND description=? AND detected_at >= ?",
                (ins["type"], ins["description"], d7),
            ).fetchone()
            if existing:
                continue
            conn.execute(
                "INSERT INTO insight_queue"
                " (type, description, priority, status, detected_at, created_at)"
                " VALUES (?, ?, ?, 'pending', ?, ?)",
                (ins["type"], ins["description"], ins.get("priority", "medium"), now, now),
            )
        conn.commit()
    finally:
        conn.close()


# ── Intention scanning ─────────────────────────────────────


def scan_intentions(path: str) -> list[dict]:
    """Detect implicit intentions from behavioral patterns."""
    intentions: list[dict] = []
    intentions.extend(_scan_matter_avoidance(path))
    intentions.extend(_scan_dynamics_drift(path))
    return intentions


def _scan_matter_avoidance(path: str) -> list[dict]:
    """Open matter not mentioned in runs for 14+ days → avoidance signal."""
    conn = connect(path)
    try:
        today = date.today()
        matters = conn.execute(
            "SELECT id, name, opened_date FROM matters WHERE status='open'"
        ).fetchall()
        results = []
        for m in matters:
            last_run = conn.execute(
                "SELECT MAX(date) as last_date FROM runs WHERE summary LIKE ?",
                (f"%{m['name']}%",),
            ).fetchone()
            last_date = last_run["last_date"] if last_run else m["opened_date"]
            if last_date:
                try:
                    days = (today - date.fromisoformat(last_date)).days
                except (ValueError, TypeError):
                    continue
                if days >= 14:
                    results.append(
                        {
                            "content": (
                                f"May be unconsciously avoiding '{m['name']}'"
                                f" (not mentioned in {days} days)"
                            ),
                            "type": "implicit",
                            "confidence": min(0.3 + (days - 14) * 0.02, 0.7),
                            "related_matters": f"[{m['id']}]",
                        }
                    )
        return results
    finally:
        conn.close()


def _scan_dynamics_drift(path: str) -> list[dict]:
    """Entity with strongly negative dynamics → distancing signal."""
    conn = connect(path)
    try:
        entities = conn.execute(
            "SELECT canonical_name, dynamics, interaction_count"
            " FROM entities WHERE id != 'self' AND dynamics < -0.3"
            " AND interaction_count >= 3"
        ).fetchall()
        results = []
        for e in entities:
            results.append(
                {
                    "content": (
                        f"Relationship with {e['canonical_name']} declining"
                        f" (dynamics: {e['dynamics']:.2f})"
                    ),
                    "type": "implicit",
                    "confidence": min(abs(e["dynamics"]) * 0.7, 0.6),
                }
            )
        return results
    finally:
        conn.close()


def write_intention(
    path: str,
    *,
    content: str,
    intention_type: str = "implicit",
    confidence: float = 0.3,
    related_matters: str = "",
) -> None:
    """Write or update an intention. Dedup by content."""
    conn = connect(path)
    try:
        now = _now()
        today_str = date.today().isoformat()
        existing = conn.execute(
            "SELECT id FROM intentions WHERE content=? AND status='active'",
            (content,),
        ).fetchone()
        if existing:
            conn.execute(
                "UPDATE intentions SET confidence=?," " last_reinforced=?, updated_at=? WHERE id=?",
                (confidence, today_str, now, existing["id"]),
            )
        else:
            conn.execute(
                "INSERT INTO intentions"
                " (content, type, confidence, status, formed_date,"
                " related_matters, created_at, updated_at)"
                " VALUES (?, ?, ?, 'active', ?, ?, ?, ?)",
                (content, intention_type, confidence, today_str, related_matters, now, now),
            )
        conn.commit()
    finally:
        conn.close()


def get_active_intentions(path: str) -> list[dict]:
    """Return active intentions for Call 3/4 injection."""
    conn = connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM intentions WHERE status='active'" " ORDER BY confidence DESC"
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


# ── Main entry point ───────────────────────────────────────


_INTENTION_SURFACE_THRESHOLD = 0.7


def _surface_intentions(path: str) -> int:
    """Surface high-confidence intentions as insights. Returns count surfaced."""
    conn = connect(path)
    try:
        now = _now()
        rows = conn.execute(
            "SELECT id, content, confidence FROM intentions"
            " WHERE status='active' AND confidence >= ?"
            " AND surfaced_at IS NULL",
            (_INTENTION_SURFACE_THRESHOLD,),
        ).fetchall()
        for r in rows:
            # Write as insight
            conn.execute(
                "INSERT INTO insight_queue"
                " (type, description, priority, status, detected_at, created_at)"
                " VALUES ('implicit_intention', ?, 'high', 'pending', ?, ?)",
                (r["content"], now, now),
            )
            # Mark intention as surfaced
            conn.execute(
                "UPDATE intentions SET surfaced_at=?, updated_at=? WHERE id=?",
                (now, now, r["id"]),
            )
        conn.commit()
        return len(rows)
    finally:
        conn.close()


def run_subconscious(path: str) -> dict:
    """Run all subconscious scanners. Called at end of understand()."""
    preamble = generate_preamble(path)

    debts = scan_debts(path)
    antibias = scan_antibias(path)
    intentions = scan_intentions(path)

    all_insights = debts + antibias
    write_insights(path, all_insights)

    # Write detected intentions
    for intent in intentions:
        write_intention(
            path,
            content=intent["content"],
            intention_type=intent.get("type", "implicit"),
            confidence=intent.get("confidence", 0.3),
            related_matters=intent.get("related_matters", ""),
        )

    # Surface high-confidence intentions as insights
    surfaced = _surface_intentions(path)

    return {
        "preamble": preamble,
        "insights_found": len(all_insights),
        "intentions_updated": len(intentions),
        "intentions_surfaced": surfaced,
    }
