"""ETL pipeline — 4-call LLM flow + DB writes."""

from .llm import (
    call_llm,
    compress_transcript,
    create_client,
    detect_source_type,
    load_template,
    parse_json,
    parse_json_array,
)
from .models import (
    append_self_profile,
    dismiss_matters,
    get_all_entities,
    get_all_entities_with_aliases,
    get_current_observations,
    get_epoch_count,
    get_epochs,
    get_open_matters,
    get_pending_insights,
    get_recent_action_fragments,
    get_recent_runs,
    get_unconsolidated_run_count,
    get_unconsolidated_runs,
    get_unprocessed_fragments,
    mark_fragments_processed,
    read_self_profile,
    set_run_epoch,
    update_self_profile,
    write_entities,
    write_epoch,
    write_matters,
    write_observation,
    write_possibilities,
    write_run,
)
from .sentinel import generate_preamble, get_active_intentions, run_subconscious


# ── Epoch consolidation ───────────────────────────────────

_MIN_RUNS = 8
_MAX_RUNS = 20
_TIME_GAP_DAYS = 7
_MIN_OBSERVATIONS_FOR_REBUILD = 5


def should_consolidate(path: str) -> bool:
    """Check if epoch consolidation should trigger."""
    count = get_unconsolidated_run_count(path)
    if count < _MIN_RUNS:
        return False
    if count >= _MAX_RUNS:
        return True
    if time_gap_days(path) > _TIME_GAP_DAYS:
        return True
    return False


def time_gap_days(path: str) -> int:
    """Days between the two most recent unconsolidated runs."""
    runs = get_unconsolidated_runs(path)
    if len(runs) < 2:
        return 0
    from datetime import date

    try:
        last = date.fromisoformat(runs[-1]["date"])
        second_last = date.fromisoformat(runs[-2]["date"])
        return (last - second_last).days
    except (ValueError, TypeError):
        return 0


def run_consolidation(
    path: str,
    llm_base_url: str,
    llm_model: str,
    llm_api_key: str = "ollama",
    prompt_dir: str | None = None,
) -> int | None:
    """Execute Call 0: consolidate unconsolidated runs into an epoch."""
    runs = get_unconsolidated_runs(path)
    if not runs:
        return None

    client = create_client(llm_base_url, api_key=llm_api_key)
    previous_epochs = get_epochs(path, limit=3)

    prompt = load_template("call0_consolidate", prompt_dir).render(
        runs=[
            {
                "date": r["date"],
                "summary": r["summary"],
                "emotion": r.get("emotion_word", ""),
                "valence": r.get("valence", 0),
                "conflict": r.get("conflict", ""),
            }
            for r in runs
        ],
        previous_epochs=previous_epochs,
    )

    raw, _ = call_llm(
        client, llm_model, prompt, temperature=0.1, max_tokens=4000
    )
    result = parse_json(raw, default={"summary": "Epoch summary", "themes": []})

    # Calculate stats
    valences = [r.get("valence", 0) for r in runs if r.get("valence") is not None]
    avg_valence = round(sum(valences) / len(valences), 2) if valences else None

    epoch_id = write_epoch(
        path,
        start_date=runs[0]["date"],
        end_date=runs[-1]["date"],
        run_count=len(runs),
        summary=result.get("summary", ""),
        themes=result.get("themes", []),
        avg_valence=avg_valence,
        self_model_delta=result.get("self_model_delta", ""),
        boundary_start_trigger=result.get("boundary_start", {}).get("trigger", ""),
        boundary_end_state=result.get("boundary_end", {}).get("closing_state", ""),
        boundary_end_unresolved=result.get("boundary_end", {}).get("unresolved", []),
        continuing_threads=result.get("continuing_threads", []),
    )

    # Tag all consolidated runs
    from .models import connect

    conn = connect(path)
    try:
        for r in runs:
            conn.execute(
                "UPDATE runs SET epoch_id=? WHERE id=?",
                (epoch_id, r["id"]),
            )
        conn.commit()
    finally:
        conn.close()

    return epoch_id


def rebuild_self_profile(
    path: str,
    llm_base_url: str,
    llm_model: str,
    llm_api_key: str = "ollama",
    prompt_dir: str | None = None,
) -> None:
    """Rebuild self_profile from observations. Skip if too few observations."""
    observations = get_current_observations(path)
    if len(observations) < _MIN_OBSERVATIONS_FOR_REBUILD:
        return

    client = create_client(llm_base_url, api_key=llm_api_key)
    prompt = load_template("rebuild_self_profile", prompt_dir).render(
        observations=observations,
    )
    raw, _ = call_llm(
        client, llm_model, prompt, temperature=0.1, max_tokens=2000
    )
    result = parse_json(raw, default={})
    new_profile = result.get("self_profile", "")
    if new_profile:
        update_self_profile(path, new_profile)


# ── Main pipeline ─────────────────────────────────────────


def run_pipeline(
    path: str,
    *,
    llm_base_url: str,
    llm_model: str,
    llm_api_key: str = "ollama",
    prompt_dir: str | None = None,
    redact: bool = False,
) -> dict:
    """Run the 4-call LLM pipeline on unprocessed fragments.

    Returns a result summary dict.
    """
    fragments = get_unprocessed_fragments(path)
    if not fragments:
        return {
            "run_id": None,
            "fragments_processed": 0,
            "entities_updated": 0,
            "matters_updated": 0,
            "possibilities_generated": 0,
        }

    client = create_client(llm_base_url, api_key=llm_api_key)
    date = fragments[-1]["date"]

    # ── Pre-pipeline: epoch consolidation ──────────────────
    if should_consolidate(path):
        run_consolidation(
            path, llm_base_url, llm_model, llm_api_key, prompt_dir
        )
        rebuild_self_profile(
            path, llm_base_url, llm_model, llm_api_key, prompt_dir
        )

    # Combine all fragment transcripts
    transcript = "\n\n".join(f["transcript"] for f in fragments if f["transcript"])
    source_type = detect_source_type(transcript)

    # Compress transcript
    compressed, _ = compress_transcript(transcript)

    # Redact PII if enabled (one key for the entire understand() call)
    redact_key: dict = {}
    if redact:
        from .redact import redact_text

        # Collect all known entity names + context for redaction
        all_entities = get_all_entities_with_aliases(path)
        known_names = []
        for e in all_entities:
            known_names.append(e["canonical_name"])
            known_names.extend(e.get("aliases", []))

        # Redact transcript + all context together to build a complete key
        # (names not in transcript won't get a pseudonym otherwise)
        self_profile_raw = read_self_profile(path)
        matters_raw = "\n".join(m.get("name", "") for m in get_open_matters(path))
        full_text = f"{compressed}\n{self_profile_raw}\n{matters_raw}"
        _, redact_key = redact_text(full_text, names=known_names)

        # Now redact transcript using the complete key
        if redact_key:
            for pseudonym, real in redact_key.items():
                compressed = compressed.replace(real, pseudonym)

    def _redact_prompt(text: str) -> str:
        """Replace real names with pseudonyms using the shared key."""
        if not redact_key:
            return text
        for pseudonym, real in redact_key.items():
            text = text.replace(real, pseudonym)
        return text

    def _restore_output(text: str) -> str:
        """Restore pseudonyms to real names."""
        if not redact_key:
            return text
        from .redact import restore_text

        return restore_text(text, redact_key)

    # ── Call 1: Identity (WHO) ──────────────────────────────
    entities_with_aliases = get_all_entities_with_aliases(path)
    self_profile = read_self_profile(path)

    call1_prompt = _redact_prompt(
        load_template("call1_identity", prompt_dir).render(
            transcript=compressed[:5000],
            known_entities=_format_entities_block(entities_with_aliases),
            self_profile=self_profile,
        )
    )

    raw1, _ = call_llm(client, llm_model, call1_prompt, temperature=0.1, max_tokens=4000)
    call1 = parse_json(_restore_output(raw1), default={"resolutions": [], "self_profile_delta": []})

    # Persist self-profile deltas from Call 1 (dual-write)
    deltas1 = [d for d in call1.get("self_profile_delta", []) if isinstance(d, str)]
    if deltas1:
        append_self_profile(path, deltas1)
        for delta in deltas1:
            write_observation(
                path,
                source="call_1",
                content=delta,
                observation_type="trait",
            )

    # ── Call 2: Facts (WHAT) ────────────────────────────────
    open_matters = get_open_matters(path)
    network_ctx = build_network_context(path)
    user_notes = _format_user_notes(get_recent_action_fragments(path))
    pending_insights = get_pending_insights(path)
    stats_preamble = _format_preamble(generate_preamble(path))

    call2_prompt = _redact_prompt(
        load_template("call2_facts", prompt_dir).render(
            transcript=compressed,
            open_matters=_format_matters_block(open_matters),
            source_type=source_type,
            network_context=network_ctx,
            user_notes=user_notes,
            stats_preamble=stats_preamble,
            pending_insights=pending_insights,
        )
    )

    raw2, _ = call_llm(client, llm_model, call2_prompt, temperature=0.3, max_tokens=4000)
    call2 = parse_json(_restore_output(raw2))

    # Write entities and matters from Call 2
    persons = call2.get("persons", [])
    write_entities(path, persons, date=date)

    new_matters = call2.get("new_matters", [])
    write_matters(path, new_matters, date=date)

    dismissed = call2.get("dismissed", [])
    if dismissed:
        dismiss_matters(path, dismissed)

    # ── Call 3: Insights (MEANING) ──────────────────────────
    self_profile = read_self_profile(path)  # re-read after Call 1 deltas

    entities_summary = (
        ", ".join(f"{p.get('name', '')}({p.get('role', '')})" for p in persons if p.get("name"))
        or "(none)"
    )

    merged_summary = call2.get("summary", "")
    emotion = call2.get("emotion", "")
    if emotion:
        merged_summary += f"\nEmotion: {emotion} (valence: {call2.get('valence', 0)})"

    active_intentions = get_active_intentions(path)

    call3_prompt = _redact_prompt(
        load_template("call3_insights", prompt_dir).render(
            merged_summary=merged_summary,
            entities_summary=entities_summary,
            self_profile=self_profile,
            stats_preamble=stats_preamble,
            pending_insights=pending_insights,
            active_intentions=active_intentions,
        )
    )

    raw3, _ = call_llm(client, llm_model, call3_prompt, temperature=0.3, max_tokens=4000)
    call3 = parse_json(
        _restore_output(raw3),
        default={"conflict": "", "gaps": [], "self_observations": []},
    )

    # Merge Call 3 into Call 2 results (Call 3 conflict overrides)
    if call3.get("conflict"):
        call2["conflict"] = call3["conflict"]
    call2["gaps"] = call3.get("gaps", call2.get("gaps", []))

    # Persist self-observations from Call 3 (dual-write)
    for obs in call3.get("self_observations", []):
        if isinstance(obs, str):
            append_self_profile(path, [obs])
            write_observation(
                path,
                source="call_3",
                content=obs,
                observation_type="behavior",
            )
        elif isinstance(obs, dict) and obs.get("content"):
            append_self_profile(path, [obs["content"]])
            write_observation(
                path,
                source="call_3",
                content=obs["content"],
                observation_type=obs.get("type", "behavior"),
                evidence_fragments=obs.get("evidence_fragments", []),
            )

    # Write run record
    run_id = write_run(
        path,
        {
            "summary": call2.get("summary", ""),
            "valence": call2.get("valence"),
            "arousal": call2.get("arousal"),
            "emotion_word": call2.get("emotion", ""),
            "conflict": call2.get("conflict", ""),
            "gaps": call2.get("gaps", []),
        },
        date=date,
        model_version=llm_model,
    )

    # ── Call 4: Possibilities (WHAT MIGHT HAPPEN) ───────────
    open_matters = get_open_matters(path)  # refresh after writes

    possibilities_generated = 0
    if open_matters:
        call4_prompt = _redact_prompt(
            load_template("call4_possibilities", prompt_dir).render(
                open_matters=_format_matters_block(open_matters),
                merged_summary=merged_summary,
                network_context=build_network_context(path),
                active_intentions=active_intentions,
            )
        )

        raw4, _ = call_llm(client, llm_model, call4_prompt, temperature=0.4, max_tokens=8000)
        call4 = parse_json_array(_restore_output(raw4))

        # Validate matter_ids
        valid_ids = {m["id"] for m in open_matters}
        validated = [p for p in call4 if p.get("matter_id") in valid_ids]

        if validated:
            write_possibilities(path, validated, run_id=run_id)
            possibilities_generated = len(validated)

    # Mark fragments as processed
    fragment_ids = [f["id"] for f in fragments]
    mark_fragments_processed(path, fragment_ids, run_id)

    # ── Subconscious (sentinel + antibias) ──────────────────
    subconscious = run_subconscious(path)

    return {
        "run_id": run_id,
        "date": date,
        "summary": call2.get("summary", ""),
        "emotion": {
            "word": call2.get("emotion", ""),
            "valence": call2.get("valence"),
            "arousal": call2.get("arousal"),
        },
        "conflict": call2.get("conflict", ""),
        "fragments_processed": len(fragments),
        "entities_updated": len(persons),
        "matters_updated": len(new_matters),
        "possibilities_generated": possibilities_generated,
        "insights_found": subconscious.get("insights_found", 0),
    }


def _format_entities_block(entities: list[dict]) -> str:
    """Format entities with aliases for Call 1 prompt."""
    parts = []
    for e in entities:
        name = e["canonical_name"]
        aliases = [a for a in e.get("aliases", []) if a != name]
        alias_str = f" aliases: {', '.join(aliases)}" if aliases else ""
        parts.append(f"- {name}{alias_str}")
    return "\n".join(parts) if parts else "(none)"


def _format_matters_block(matters: list[dict]) -> str:
    """Format open matters for prompt injection."""
    if not matters:
        return "(none)"
    return "\n".join(f"- ID={m['id']}: {m['name']} ({m.get('current', '')})" for m in matters)


def build_network_context(path: str) -> str:
    """Build network context string from entities + recent runs for prompt injection."""
    lines = []

    entities = get_all_entities(path)
    if entities:
        lines.append("[Known network]")
        parts = []
        for e in entities:
            name = e["canonical_name"]
            dyn = e.get("dynamics", 0.0)
            count = e.get("interaction_count", 1)
            note = e.get("note", "")
            dyn_str = f"+{dyn:.2f}" if dyn >= 0 else f"{dyn:.2f}"
            desc = f"dynamics {dyn_str}, interactions {count}"
            if note:
                desc += f", note: {note}"
            parts.append(f"{name} ({desc})")
        lines.append("Entities: " + ", ".join(parts))

    # Telescoping: epochs (compressed long-term) + unconsolidated runs (detailed recent)
    epochs = get_epochs(path, limit=10)
    unconsolidated = get_unconsolidated_runs(path)

    if epochs:
        lines.append("[Long-term memory (epoch summaries)]")
        for ep in epochs:
            boundary = ""
            if ep.get("boundary_end_state"):
                boundary = f" | closing: {ep['boundary_end_state'][:80]}"
            lines.append(
                f"- Epoch {ep['id']}"
                f" ({ep['start_date']}→{ep['end_date']}):"
                f" {ep['summary']}{boundary}"
            )

    if unconsolidated:
        lines.append("[Recent memory (unconsolidated)]")
        for r in unconsolidated:
            lines.append(f"- {r['date']}: {r['summary']}")
    elif not epochs:
        # Fallback: no epochs, no unconsolidated → show recent runs
        runs = get_recent_runs(path, limit=5)
        if runs:
            lines.append("Recent memory (by date):")
            for r in reversed(runs):
                lines.append(f"- {r['date']}: {r['summary']}")

    return "\n".join(lines) if lines else ""


def _format_user_notes(fragments: list[dict]) -> str:
    """Format recent action fragments for prompt injection."""
    if not fragments:
        return ""
    lines = ["[User actions (recent)]"]
    for f in fragments:
        lines.append(f"- {f['transcript']}")
    return "\n".join(lines)


def _format_preamble(preamble: dict) -> str:
    """Format sentinel stats preamble for prompt injection."""
    if not preamble:
        return ""
    lines = ["[Stats (factual baseline)]"]
    et = preamble.get("emotion_trend")
    if et:
        lines.append(
            f"Emotion: 7d mean {et.get('7d_mean', 0):.1f},"
            f" 30d mean {et.get('30d_mean', 0):.1f},"
            f" direction {et.get('direction', 'stable')}"
        )
    staleness = preamble.get("matter_staleness", [])
    stale = [m for m in staleness if m.get("days_since_mention", 0) >= 7]
    if stale:
        parts = [f"{m['name']} ({m['days_since_mention']}d silent)" for m in stale[:3]]
        lines.append(f"Stale matters: {', '.join(parts)}")
    return "\n".join(lines) if len(lines) > 1 else ""
