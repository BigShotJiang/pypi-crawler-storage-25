"""argus-me — personal cognitive engine library."""

__version__ = "0.1.5"

from .me import Me

__all__ = ["Me"]
