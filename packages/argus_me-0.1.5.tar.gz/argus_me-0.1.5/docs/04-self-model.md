# Self Model

The Self Model is the system's evolving understanding of **who the user is**. It's not a one-time configuration — it accumulates with every `me.understand()`, every `me.edit_profile()`, every interaction.

## Current Implementation (v0.1)

Self-profile is stored as a TEXT column on the `entities` table where `id='self'`. Append-only bullet list maintained by two functions:

- `append_self_profile(deltas)` — Call 1 and Call 3 write observations
- `update_self_profile(text)` — User replaces full text via `me.edit_profile(text)`
- `read_self_profile()` — Injected into Call 1 and Call 3 prompts

### Learning Sources

The self model learns from multiple channels, not just explicit profile edits:

| Source | What it captures | Mechanism |
|--------|-----------------|-----------|
| Call 1 (identity) | New names/roles/facets | `self_profile_delta` -> `append_self_profile()` |
| Call 3 (insights) | Behavioral patterns ("tendency to avoid conflict") | `self_observations` -> `append_self_profile()` |
| `me.edit_profile(text)` | Direct self-description | `update_self_profile()` + fragment recorded |
| `me.merge(keep='self', absorb=eid)` | Absorbed entity's context becomes self-knowledge | Entity merge into self |
| All user actions | Indirect self-revelation (what you dismiss, expect, prioritize) | Action fragments -> LLM reads next understand() |
| Intention layer | Implicit patterns the user may not be aware of | Hidden intentions inform Call 3 self_observations |

### The Merge-as-Learning Pattern

When an entity is merged into 'self' (e.g., a misidentified mention that is actually the user), the absorbed entity's notes and interaction history become self-knowledge:

```
me.merge(keep_id='self', absorb_id='entity-uuid')
  -> self_profile gains absorbed entity's context
  -> All aliases of absorbed entity now resolve to 'self'
```

## Planned: Four-Layer Architecture (v0.3+)

Based on cognitive science research, the flat text profile will evolve into a structured JSON with four layers + metacognition:

### Layer 1: Schema (Markus, 1977)

Relatively stable core self-knowledge. The user's strong self-concept dimensions.

```json
{
  "strong_dimensions": ["entrepreneur", "tech-oriented"],
  "weak_dimensions": ["social confidence"]
}
```

**Cognitive science**: Self-schemas accelerate processing of schema-consistent information [A-grade]. But they also resist contradictory evidence (confirmation bias) — the system must periodically challenge them.

### Layer 2: Motivation (Markus & Nurius, 1986 + Higgins, 1987)

Who the user wants to become, fears becoming, and expects to become.

```json
{
  "hoped_for": ["successful product founder"],
  "feared": ["stuck in meaningless work"],
  "expected": ["independent developer"],
  "discrepancies": [
    {"stated_value": "health", "actual_pattern": "sedentary/late nights", "gap": "large"}
  ]
}
```

**Cognitive science**: Possible selves serve as "behavioral blueprints" guiding current action [B+-grade]. Discrepancies between actual and ideal self correlate with emotional distress [B+-grade].

### Layer 3: Narrative (McAdams, 2013)

The user's evolving life story — current chapter, themes, turning points.

```json
{
  "current_chapter": "transitioning from corporate to independent",
  "themes": {"agency": "rising", "redemption": "present"},
  "turning_points": ["left BigCorp 2025-06", "first client 2025-09"]
}
```

**Cognitive science**: Narrative identity is an internalized, evolving life story [A-grade]. Narrative coherence correlates with psychological well-being [B+-grade]. Agency themes predict better mental health.

### Layer 4: External View (Cooley, 1902)

How others see the user, inferred from relationship fragments. Blind spots between self-perception and external feedback.

```json
{
  "others_see_as": ["reliable technical person", "sometimes distant"],
  "blind_spots": ["thinks they communicate well; colleagues find them terse"]
}
```

### Metacognition Layer

What the system knows it doesn't know.

```json
{
  "known_unknowns": ["unclear about product-market fit"],
  "info_sparse_areas": ["financial planning", "long-term health goals"]
}
```

## Migration Strategy

1. v0.1: `self_profile` TEXT column — flat append-only text
2. v0.3: Future migration converts existing bullet-list text into structured JSON, placing all existing entries in `raw_observations`
3. `read_self_profile()` handles both formats: raw text -> treated as `raw_observations`; JSON -> parsed into layers
4. Structured layers are auto-populated by LLM in Call 1/3. Users edit via `me.edit_profile(text)` — they don't manually fill four layers.

## Update Triggers (v0.3+)

| Trigger | What changes |
|---------|-------------|
| 3+ fragments contradict a schema dimension | Schema layer flagged for re-evaluation |
| Role change detected (new job, new relationship) | Possible selves layer re-evaluated |
| Major life event | Narrative `current_chapter` updated |
| External feedback diverges from self-view | Blind spot generated |
| Intention surfaces with high confidence | May reveal a motivation the user wasn't tracking |
