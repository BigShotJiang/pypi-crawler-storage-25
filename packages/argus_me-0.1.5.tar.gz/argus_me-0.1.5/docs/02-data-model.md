# Data Model

Single SQLite database (`memory.db`), WAL mode, 10 tables.

## Four Primitives

| Primitive | Table | What it is |
|-----------|-------|-----------|
| **Self** | `entities` (id='self') | The center node. Self-profile lives here. |
| **Entity** | `entities` | Anything in my cognitive world — person, team, org, concept. No type column, no role column. |
| **Matter** | `matters` | A current concern that connects me to entities. Either open or dismissed. Never deleted. |
| **Fragment** | `fragments` | Atomic input from any source. Immutable after creation. |

Everything else is derived: emotions are properties of runs, relationships are derived from matter_entities co-occurrence, possibilities are forward projections of matters, intentions are inferred by the subconscious.

## Schema

### fragments — Raw input stream (immutable)

```sql
CREATE TABLE fragments (
    id          TEXT PRIMARY KEY,        -- UUID v7
    type        TEXT NOT NULL,           -- 'text' / 'action'
    date        TEXT NOT NULL,           -- YYYY-MM-DD (content date, not processing date)
    source      TEXT,                    -- 'ingest' / 'user_action'
    raw         TEXT,                    -- original content
    transcript  TEXT,                    -- preprocessed text (what the LLM sees)
    metadata    TEXT DEFAULT '{}',       -- JSON, type-specific fields
    processed   INTEGER DEFAULT 0,      -- 0=pending, 1=consumed
    run_id      TEXT,                    -- which run consumed this fragment
    created_at  TEXT NOT NULL
);
```

Pipeline only reads `transcript`. Fragment **content** (raw, transcript, metadata) is immutable after creation. Administrative fields (`processed`, `run_id`) are updated by the pipeline.

### entities — Nodes in my cognitive world

```sql
CREATE TABLE entities (
    id               TEXT PRIMARY KEY,      -- UUID; 'self' for the user
    canonical_name   TEXT NOT NULL UNIQUE,
    dynamics         REAL DEFAULT 0.0,      -- overall relationship temperature (-1 to 1)
    interaction_count INTEGER DEFAULT 1,
    first_seen       TEXT NOT NULL,
    last_seen        TEXT NOT NULL,
    note             TEXT DEFAULT '',        -- user's notes
    self_profile     TEXT DEFAULT '',        -- only used for id='self'
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);
```

**No `type` column.** An entity's meaning comes from which matters it participates in, not from a category label.

**No `role` column.** Role is on `matter_entities.role_in_matter`. The same entity can play different roles in different matters.

### entity_aliases — Name resolution

```sql
CREATE TABLE entity_aliases (
    alias      TEXT PRIMARY KEY,
    entity_id  TEXT NOT NULL REFERENCES entities(id),
    confidence REAL DEFAULT 1.0,
    source     TEXT DEFAULT 'system',   -- 'system' / 'llm' / 'user'
    created_at TEXT NOT NULL
);
```

### matters — Current concerns

```sql
CREATE TABLE matters (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    name             TEXT,                    -- 4-8 char short title
    current          TEXT,                    -- current status description
    status           TEXT DEFAULT 'open',     -- open / dismissed (only two states)
    source           TEXT DEFAULT 'llm',      -- 'llm' / 'user' (user edits never overwritten)
    priority         REAL DEFAULT 0.5,        -- user-set display priority
    opened_date      TEXT NOT NULL,
    mention_count    INTEGER DEFAULT 1,
    created_at       TEXT NOT NULL,
    updated_at       TEXT NOT NULL
);
```

**Only two statuses**: `open` and `dismissed`. No close/complete/planned/abandoned. A dismissed matter stops sensitizing attention; an open matter keeps doing so.

**No `has_plan`.** Plans are expressed as user-expected possibilities (`me.expect(possibility_id)`).

**No `commitment_level`.** The system infers commitment from fragment patterns.

### matter_entities — Connections

```sql
CREATE TABLE matter_entities (
    matter_id      INTEGER NOT NULL REFERENCES matters(id),
    entity_id      TEXT NOT NULL REFERENCES entities(id),
    role_in_matter TEXT,                 -- "advisor" / "partner" / "bank"
    UNIQUE(matter_id, entity_id)
);
```

Same entity, different matters, different roles.

### runs — Pipeline output

```sql
CREATE TABLE runs (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    date         TEXT NOT NULL,
    run_id       TEXT NOT NULL,               -- UUID v7
    summary      TEXT NOT NULL,               -- "Today's overview from my perspective..."
    valence      REAL,                        -- emotion: pleasure-displeasure (-1 to 1)
    arousal      REAL,                        -- emotion: activation (0 to 1)
    emotion_word TEXT,                        -- LLM-inferred emotion label
    conflict     TEXT DEFAULT '',             -- core tension
    gaps         TEXT DEFAULT '[]',           -- JSON array of cognitive gaps
    model_version TEXT,                       -- which LLM model was used
    created_at   TEXT NOT NULL
);
```

A run is the output of one `me.understand()` invocation. Not an input record — a processing result.

### possibilities — Forward scenarios per matter

```sql
CREATE TABLE possibilities (
    id                    TEXT PRIMARY KEY,   -- UUID v7
    matter_id             INTEGER REFERENCES matters(id),
    event                 TEXT NOT NULL,       -- what might happen (short title)
    narrative             TEXT DEFAULT '',     -- detailed scenario: why, triggers, consequences
    confidence            TEXT DEFAULT 'medium', -- high / medium / low
    prob                  REAL,                -- internal sorting only, not shown to users
    historical_precedent  TEXT DEFAULT '',     -- similar past pattern
    status                TEXT DEFAULT '',     -- '' / 'expected' / 'happened' / 'dismissed'
    run_id                TEXT,
    created_at            TEXT NOT NULL,
    validated_at          TEXT                 -- user action timestamp
);
```

**No categorization.** Possibilities are not labeled by agency (choices vs events). All possibilities expand the user's vision. The user finds their own agency.

### intentions — Hidden cognitive layer

```sql
CREATE TABLE intentions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    content         TEXT NOT NULL,           -- intention description (one sentence)
    type            TEXT NOT NULL,           -- 'explicit' (user stated) / 'implicit' (system inferred)
    confidence      REAL NOT NULL,           -- 0.0-1.0
    status          TEXT DEFAULT 'active',   -- 'active' / 'surfaced' / 'dissolved'
    formed_date     TEXT NOT NULL,
    last_reinforced TEXT,                    -- last date behavior reinforced this intention
    related_matters TEXT,                    -- JSON: [matter_id, ...]
    evidence        TEXT,                    -- JSON: supporting evidence summary
    surfaced_at     TEXT,                    -- when confidence crossed threshold and was shown
    run_id          TEXT,
    created_at      TEXT NOT NULL,
    updated_at      TEXT NOT NULL
);
```

Intentions are **not exposed** through `me.snapshot()` or `me.matters` by default. They silently improve possibility quality by providing deeper context to the LLM. When confidence crosses a configurable threshold, they surface as insights via `me.insights`. See [Subconscious: Intention Scanning](./05-subconscious.md#intention-scanning).

### insight_queue — Subconscious findings

```sql
CREATE TABLE insight_queue (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    type        TEXT NOT NULL,               -- 'stale_matter' / 'emotion_inflection' /
                                             -- 'high_freq_entity' / 'relationship_gap' /
                                             -- 'implicit_intention' / 'echo_chamber_risk' / ...
    description TEXT NOT NULL,
    evidence    TEXT,                         -- JSON: supporting data
    priority    TEXT DEFAULT 'medium',        -- 'high' / 'medium' / 'low'
    status      TEXT DEFAULT 'pending',       -- 'pending' / 'consumed' / 'expired'
    run_id      TEXT,                         -- which run consumed this insight
    detected_at TEXT NOT NULL,
    created_at  TEXT NOT NULL
);
```

### meta — Schema versioning

```sql
CREATE TABLE meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
-- Preset: ('schema_version', '1')
```

## What's NOT a Table

| Concept | Where it lives | Why not a separate table |
|---------|---------------|------------------------|
| Emotions | `runs.valence` / `runs.arousal` / `runs.emotion_word` | Emotion is a property of a processing run, not a standalone record |
| Relationships | Derived by subconscious from `matter_entities` co-occurrence | Not user input — it's a statistical computation |
| User actions | `fragments` with `type='action'` | An action is just another fragment |
| Self profile | `entities.self_profile` where `id='self'` | Self is just an entity with a richer description |

## Recommended Indexes

```sql
CREATE INDEX idx_fragments_unprocessed ON fragments(processed, date) WHERE processed = 0;
CREATE INDEX idx_matter_entities_entity ON matter_entities(entity_id);
CREATE INDEX idx_possibilities_matter ON possibilities(matter_id, status);
CREATE INDEX idx_intentions_active ON intentions(status) WHERE status = 'active';
CREATE INDEX idx_insight_queue_pending ON insight_queue(status) WHERE status = 'pending';
```

## The Feedback Loop

Every user action (via Me class methods) creates a fragment:

| Action | Fragment created |
|--------|-----------------|
| Register alias | type='action', transcript="User confirmed: '{name}' is {entity}" |
| Dismiss a matter | type='action', transcript="User no longer tracking: {name}" |
| Expect a possibility | type='action', transcript="User expects: {event}" |
| Edit self-profile | type='action', transcript="User edited self-portrait" |
| Respond to gap | type='action', transcript="User answered: {response}" |
| Add note to entity | type='action', transcript="User noted on {name}: {text}" |
| Merge entities | type='action', transcript="User merged {absorbed} into {kept}" |
| Set priorities | type='action', transcript="User prioritized matters: {ids}" |

Next `me.understand()` reads these fragments and updates its understanding.
