# Subconscious (Sentinel + AntiBias + Intentions)

The subconscious is a lightweight statistics engine that runs **inside `me.understand()`**, after the 4-call LLM pipeline completes. It scans `memory.db` for patterns, anomalies, and cognitive debts — then writes findings to `insight_queue` for the next pipeline run to consume.

**Key principle**: The subconscious never calls LLMs. It's pure statistics + heuristics. This keeps it fast and deterministic.

**Not a separate process**: It runs inline at the end of every `me.understand()` call. No separate invocation needed.

## What It Does

Three engines run in sequence:
1. **Sentinel** — stats preamble + cognitive debt scanning
2. **Intention Scanner** — implicit intention detection from behavioral patterns
3. **AntiBias** — bias-specific detections

All write to the same `insight_queue` table.

---

## 1. Sentinel

### Stats Preamble

`generate_preamble()` produces a JSON summary of memory state, injected into Call 2 and Call 3 prompts on the next run:

| Section | What it computes |
|---------|-----------------|
| `entity_freq` | Per-entity mention counts across 7d/30d/90d windows |
| `emotion_trend` | 7-day vs 30-day valence mean -> direction (rising/falling/stable) |
| `matter_staleness` | Open matters ranked by days since last mention in runs |
| `relationship_gaps` | Entities whose current interaction gap exceeds avg + 2sigma |

### Cognitive Debt Scanning

`scan_debts()` detects situations that deserve attention. Each finding is an insight dict written to `insight_queue` with 7-day deduplication.

| Scanner | Insight Type | Trigger |
|---------|-------------|---------|
| `_scan_stale_matters` | `stale_matter` | Open matter not mentioned in runs for >7 days |
| `_scan_emotion_inflection` | `emotion_inflection` | 3+ consecutive days of same-direction valence change |
| `_scan_unconfirmed_entities` | `unconfirmed_entity` | Entity with >=3 interactions but no `note` and not in any matter |
| `_scan_high_freq_entities` | `high_freq_entity` | This week's mentions >2.5x historical weekly average |
| `_scan_relationship_gaps` | `relationship_gap` | Current gap > avg_interval + 2sigma and >3 days |

### Priority Levels

- **high**: stale matters >=14 days, emotion valence dropped below -0.3
- **medium**: most detections (default)
- **low**: positive emotion trend (informational)

### Insight Lifecycle

```
Subconscious detects pattern -> writes to insight_queue (status='pending')
    |
Next me.understand(): pipeline reads pending insights
    |
Insights injected into LLM prompt (Call 2 and Call 3)
    |
After pipeline completes: insights marked 'consumed' with run_id
```

---

## 2. Intention Scanner

The intention scanner detects **implicit intentions** — behavioral patterns suggesting the user is moving toward a decision or direction they haven't explicitly stated.

### Detection Signals

| Signal | What it detects | Example |
|--------|----------------|---------|
| Matter avoidance | Open matter repeatedly not mentioned despite being high-priority | User may be unconsciously abandoning it |
| Entity dynamics drift | Steady decline in dynamics score for an entity over 30+ days | User may be distancing from this relationship |
| Fragment topic clustering | Same topic appearing across unrelated fragments | An emerging concern not yet articulated as a matter |
| Dismiss-but-revisit | A dismissed matter's entities keep appearing in new fragments | User dismissed it cognitively but behaviorally hasn't let go |
| Energy shift | Fragments about a matter shift from neutral/negative to positive (or vice versa) | Emotional alignment or misalignment with stated concerns |

### Lifecycle

```
Intention scanner detects pattern
    |
    v
Write to intentions table (type='implicit', confidence=low)
    |
    v
Each subsequent understand(): re-evaluate evidence
    |-- Evidence strengthens -> confidence rises
    |-- Evidence weakens -> confidence decays
    |-- Contradicted by user action -> dissolved
    |
    v
Confidence crosses threshold (default: 0.7)
    |
    v
Surface as insight: write to insight_queue (type='implicit_intention')
    |
    v
Next pipeline run: LLM sees it, may generate related possibilities or self_observations
```

### Injection Rules

- **Below threshold**: Intentions are injected into Call 3 and Call 4 as internal context. The LLM uses them to generate deeper insights and more relevant possibilities, but they do not appear in user-facing output.
- **Above threshold**: Intentions surface as insights through `me.insights`. The consumer decides how to present them.
- **User-stated intentions**: When a user explicitly says "I want to..." in a fragment, it's captured as `type='explicit'` with `confidence >= 0.8`. These are also injected into Call 3/4.

### Confidence Dynamics

- EWMA with alpha=0.05 (very slow — intentions are slow variables)
- Explicit intentions start at 0.8+
- Implicit intentions start at 0.3-0.5
- Reinforcement: +0.05 per supporting fragment pattern
- Decay: -0.02 per understand() cycle without reinforcing evidence
- User contradiction (dismiss related matter, opposing action): immediate drop to 0.2

---

## 3. AntiBias Engine

Module `antibias.py` — extends scanning with bias-specific detections. Same pattern: returns insight dicts, uses `write_insights()` with dedup.

### Scanners

| Scanner | Insight Type | Trigger | Cognitive Science Basis |
|---------|-------------|---------|----------------------|
| `_scan_insight_diversity` | `insight_concentration` | >60% of recent possibilities focus on same matter (14-day window) | Echo chamber: system learns to produce what user confirms |
| `_scan_emotion_granularity` | `low_emotion_granularity` | <3 distinct `emotion_word` values in 30 days | Barrett: low granularity correlates with poorer emotional regulation [B+-grade] |
| `_scan_echo_chamber` | `echo_chamber_risk` | >80% of recent fragments involve only 1-2 entities (14-day window) | Granovetter: weak ties provide more novel information [A-grade] |

### Design Rationale

The anti-bias approach is **statistical, not prescriptive**. It doesn't tell users they're wrong — it surfaces patterns they might not notice:

- "Your recent insights are concentrated on one topic" (not "you're biased")
- "Your emotion vocabulary has been limited lately" (not "you should feel differently")
- "Most of your fragments come from the same 2 people" (not "you need more friends")

This aligns with the design principle: **accelerate with brakes**.

---

## Subconscious vs Pipeline: Division of Labor

| | Subconscious | Pipeline (4 LLM calls) |
|---|---------|---------------|
| **When** | End of `me.understand()` | Beginning of `me.understand()` |
| **Uses LLM** | Never | Yes (4 calls) |
| **Reads DB** | Yes (read-only for preamble + intention evidence) | Yes |
| **Writes DB** | insight_queue + intentions | runs, entities, matters, possibilities |
| **Resource needs** | Minimal (pure Python, no GPU) | LLM inference (GPU recommended) |
| **Purpose** | Detect patterns over time | Process new input |
