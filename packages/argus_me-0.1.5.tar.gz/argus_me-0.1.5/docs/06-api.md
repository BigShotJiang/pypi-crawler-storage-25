# Me Class — Public API Reference

argus-me exposes a single class. All interaction goes through `Me`.

```python
from argus_me import Me

me = Me(
    name="Your Name",
    db_path="~/data/memory.db",
    llm_base_url="http://localhost:11434/v1",
    llm_model="qwen2.5:32b",
    redact=True,
)
```

## Constructor

```python
Me(name, db_path, llm_base_url, llm_model, redact=False, prompt_dir=None)
```

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `name` | str | Yes | User's name (creates self entity on first run) |
| `db_path` | str | Yes | Path to memory.db (created if missing, migrations auto-applied) |
| `llm_base_url` | str | Yes | OpenAI-compatible API base URL |
| `llm_model` | str | Yes | Model name for LLM calls |
| `redact` | bool | No | When True, PII is stripped before LLM calls via argus-redact. Default: False |
| `prompt_dir` | str | No | Path to custom prompt templates. Overrides built-in defaults per-file. Default: None (use built-in) |

On instantiation:
1. Opens (or creates) `memory.db` at `db_path`
2. Applies any pending migrations automatically
3. Creates self entity (`id='self'`, `canonical_name=name`) if not present
4. Validates LLM connectivity (optional health check)

---

## Input

### me.ingest(text, date=None)

Feed a text fragment into the system. Creates an unprocessed fragment in memory.db.

```python
me.ingest("Had coffee with Tom. He's leaving BigCorp next month.")
me.ingest("Diary: feeling stuck on the product direction lately.")
me.ingest("Meeting notes from last Tuesday...", date="2026-03-25")
```

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `text` | str | Yes | Fragment content. Any text: conversation, diary, notes. |
| `date` | str | No | Content date (YYYY-MM-DD). Defaults to today. Use this when content is from a past date. |

- Text only. No structured data. Body state enters through natural language.
- Each call creates one fragment with `processed=0`.
- Fragments are consumed by the next `me.understand()` call.
- Returns: fragment ID (str)

---

## Processing

### me.understand()

Process all unprocessed fragments through the 4-call LLM pipeline + subconscious scanning.

```python
result = me.understand()
```

**Cost**: Each call makes 4+ LLM API requests. Expect 5-15 minutes depending on fragment volume and model. Designed for batch processing ("sleep computing"), but can be called anytime. With 0 unprocessed fragments, returns immediately (no LLM calls, subconscious still runs).

**Returns**:
```python
{
    "run_id": "019d2b07-...",
    "date": "2026-03-29",
    "summary": "Today's key developments from my perspective...",
    "emotion": {"word": "anxious", "valence": -0.3, "arousal": 0.6},
    "conflict": "Product direction vs timeline pressure",
    "matters_updated": 3,
    "entities_updated": 5,
    "possibilities_generated": 8,
    "insights_found": 2,
    "intentions_updated": 1,
    "fragments_processed": 4,
}
```

**Partial failure**: If Call 3 fails, Call 2 results are used. If Call 4 fails, no possibilities generated. Fragments are marked processed only after ALL writes complete — if the process crashes mid-flight, fragments stay unprocessed and will be reprocessed next run. Entity/matter writes use upsert-by-name to avoid duplicates on reprocessing.

Internals: Call 1 (Identity) -> Call 2 (Facts) -> Call 3 (Insights) -> Call 4 (Possibilities) -> Subconscious. See [Pipeline](./03-pipeline.md).

---

## Identity

### me.alias(name, entity_id=None)

Register a name alias. If `entity_id` is None, the alias points to self.

```python
me.alias("Professor Wang")                       # "Professor Wang" is me
me.alias("Xiao Li", entity_id="entity-uuid")     # "Xiao Li" is this entity
```

Four layers of identity resolution:
- **Automatic**: Call 1 learns aliases from high-confidence matches during understand()
- **Proactive**: `me.alias()` — user registers aliases upfront
- **Corrective**: `me.merge()` — fix wrong entity splits, transfer all aliases
- **Contextual**: `me.note()` — add context for ambiguous names

**Edge cases**: If alias already exists pointing to a different entity, it is **reassigned** (user intent overrides). Empty string raises ValueError. Non-existent entity_id raises KeyError. Alias matching is exact (case-sensitive).

---

## User Interactions

Each method below auto-creates a cognitive fragment (`type='action'`), which feeds back into the next `me.understand()`.

### me.dismiss(matter_id)

Mark a matter as dismissed. The user is no longer tracking this concern.

```python
me.dismiss(matter_id=12)
```

No "close" or "complete" — only dismiss. Matters are either `open` or `dismissed`.

### me.expect(possibility_id)

Mark a possibility as user-expected. This is how users express plans and intentions — by expecting specific possibilities.

```python
me.expect(possibility_id="poss-uuid-123")
```

Sets `possibilities.status = 'expected'`. If another possibility for the same matter was previously expected, its status is cleared first (one expectation per matter).

### me.merge(keep_id, absorb_id)

Merge two entities. The absorbed entity's aliases, matter connections, and notes transfer to the kept entity.

```python
me.merge(keep_id="entity-uuid-1", absorb_id="entity-uuid-2")
```

Special case: merging into `'self'` makes absorbed entity's context into self-knowledge.

**Data integrity**: Duplicate matter_entities (same matter_id) are skipped. Self-merge (keep_id == absorb_id) is a no-op.

### me.answer(gap_id, response)

Respond to a cognitive gap surfaced by the pipeline.

```python
me.answer(gap_id="gap-uuid", response="Yes, that project is still active.")
```

### me.prioritize(matter_ids)

Set display priority for matters by providing an ordered list.

```python
me.prioritize([5, 12, 3])  # matter 5 highest priority
```

### me.edit_profile(text)

Replace the self-profile text. User edits are authoritative — LLM will not overwrite.

```python
me.edit_profile("Software engineer, transitioning to indie products. Father of two.")
```

### me.note(entity_id, text)

Add a user note to an entity.

```python
me.note(entity_id="entity-uuid", text="Met at the conference. Sharp on distributed systems.")
```

---

## Output

### me.snapshot()

Cognitive snapshot — a point-in-time freeze. Everything changes; a snapshot captures one moment.

```python
snap = me.snapshot()
```

Returns:
```python
{
    "timestamp": "2026-03-29T22:30:00",
    "self_profile": "Software engineer, transitioning to indie...",
    "matters": [
        {"id": 5, "name": "Product launch", "current": "Waiting for design review",
         "status": "open", "priority": 0.8,
         "entities": [{"id": "uuid", "name": "Tom", "role_in_matter": "partner"}]}
    ],
    "entities": [
        {"id": "uuid", "canonical_name": "Tom", "dynamics": 0.3, "interaction_count": 12}
    ],
    "possibilities": [
        {"id": "uuid", "matter_id": 5, "event": "Design review approved",
         "narrative": "...", "confidence": "high", "status": ""}
    ],
    "emotion": {"word": "satisfied", "valence": 0.4, "arousal": 0.5},
    "gaps": [
        {"type": "open_loop", "description": "Tom's position on the delay is unknown",
         "impact": "high"}
    ],
}
```

Note: `intentions` are **not included** in snapshot by default. They are an internal cognitive layer.

### Live Queries (Properties)

For consumers that need real-time access, Me exposes live properties that query memory.db on each access:

| Property | Return type | Content |
|----------|-------------|---------|
| `me.matters` | `list[dict]` | Open matters with entities and roles |
| `me.entities` | `list[dict]` | All entities with dynamics, interaction count, notes |
| `me.possibilities` | `list[dict]` | Active possibilities per matter |
| `me.self_profile` | `str` | Current self-understanding text |
| `me.gaps` | `list[dict]` | Unresolved gaps from latest run |
| `me.runs` | `list[dict]` | Recent run summaries with emotion |
| `me.insights` | `list[dict]` | Pending insights (including surfaced intentions) |

**snapshot() vs live queries**: snapshot() is a photo — frozen, timestamped, for export or comparison. Live queries are a mirror — always current.

---

## Cognitive Fragment Auto-Recording

All user interaction methods automatically record a cognitive fragment:

| Method | Fragment transcript |
|--------|-------------------|
| `alias(name)` | "User confirmed: '{name}' is me" |
| `alias(name, entity_id)` | "User confirmed: '{name}' is {entity_name}" |
| `dismiss(matter_id)` | "User no longer tracking: {matter_name}" |
| `expect(possibility_id)` | "User expects: {event}" |
| `merge(keep_id, absorb_id)` | "User merged {absorbed} into {kept}" |
| `answer(gap_id, response)` | "User answered: {response}" |
| `prioritize(ids)` | "User prioritized matters: {ids}" |
| `edit_profile(text)` | "User edited self-portrait" |
| `note(entity_id, text)` | "User noted on {name}: {text}" |

This is the mechanism behind the [Cognitive Fragment Principle](./00-philosophy.md#the-cognitive-fragment-principle).
