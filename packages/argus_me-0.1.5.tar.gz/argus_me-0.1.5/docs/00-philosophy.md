# Philosophy

## Core Idea

argus-me is a **cognitive exoskeleton** — it grows on the user, amplifying what they can perceive and understand about their own life.

It is not an AI agent (it never acts autonomously), not an assistant (it never does tasks for you), not a note-taking app (it doesn't store things). It processes your fragments into an evolving understanding, and illuminates possibilities you might not see on your own. But it's always the human who walks — the exoskeleton just makes you stronger.

argus-me is a **Python library**. It provides a `Me` class that consumers import. No CLI, no web UI, no API endpoints.

## Two Core Systems

### System 1: Fragment Assembly (Fragment -> Network)

User input is always fragmented — a conversation recording, a diary entry, a quick note. System 1 assembles these into an increasingly complete information network.

1. **Receive fragments** -> extract people, matters, emotions, relationships
2. **Connect to existing network** -> link with known context ("when did this person last appear?")
3. **Identify gaps** -> which connections are missing, ambiguous, contradictory?
4. **Request supplementation** -> surface critical gaps for user confirmation

**Cognitive science**: Maps to Klein's Data/Frame model — data (fragments) and frames (existing understanding) drive meaning construction bidirectionally. Weick's sensemaking theory confirms: humans naturally work with fragments, seeking not accuracy but **explanations plausible enough to guide action** [A-grade evidence].

### System 2: Possibility Engine (Network -> Possibilities)

Using System 1's assembled network, generates a possibility space — interconnected scenarios that expand what the user can see. Possibility quality depends entirely on System 1's network completeness.

**Cognitive science**: Humans don't do probability estimation — they simulate future scenarios from past fragments (constructive episodic simulation [A-grade]), match patterns to precedents (RPD [A-grade]), and understand possibilities through stories. argus-me therefore outputs **scenario narratives**, not raw probabilities.

## Design Principles

| Principle | Meaning | Source |
|-----------|---------|--------|
| **Plausibility > accuracy** | Insights don't need to be "correct", just "plausible enough to act on" | Weick sensemaking + abductive reasoning |
| **Scenario > probability** | Leverage humans' natural strength in understanding stories. Scenarios describe *what might happen and why*, never *when*. Time belongs to history (fragments), not to forecasting. | Constructive episodic simulation + RPD + premortem |
| **Framework-guided > passive accumulation** | self_profile and concerns serve as organizing frameworks | Gestalt + Data/Frame |
| **Iterative revision > linear stacking** | New fragments can overturn old insights | Abductive reasoning + memory reconstruction |
| **Accelerate with brakes** | Every cognitive mechanism has a fixation risk; anti-bias counters it | Confirmation bias + echo chamber research |
| **No deletion** | Matters are never deleted or closed — only `open` or `dismissed`. History is preserved. | Cognitive continuity — concerns don't vanish, they fade |
| **Expand possibilities, don't limit** | Possibilities are not categorized by agency. All possibilities expand the user's vision. The user finds their own agency. | Autonomy + sensemaking |
| **Customizable cognition** | Prompt templates are overridable — consumers tune the cognitive style | Separation of framework vs implementation |

## The Cognitive Fragment Principle

**Every user action feeds back into the system's understanding.**

User operations are not the endpoint of a database write — they are the **starting point** of assembling a possibility network. Every action — dismissing a matter, editing self-profile, responding to a cognitive gap — is automatically recorded as a cognitive fragment.

On the next `me.understand()`, the LLM reads recent fragments (7-day window) and uses them to update its understanding. This creates a closed cognitive loop:

```
User acts (dismiss matter, edit profile, expect possibility)
    |
Fragment recorded (fragments table, type='action')
    |
Next me.understand(): LLM reads recent fragments
    |
Updated understanding (insights, self_profile, possibilities)
    |
User sees updated view, acts again...
```

This means the system gets smarter not just from new input, but from **every interaction the user has with the system itself**.

## Privacy: Ephemeral Redaction

When `redact=True`, Me strips PII before sending to the LLM (via [argus-redact](https://github.com/wan9yu/argus-redact)). Real names become random pseudonyms, locations become categories. The LLM reasons on redacted text; Me restores real names in the output.

The redaction key (real name <-> pseudonym mapping) is **ephemeral** — born at the start of `understand()`, discarded when it ends. Each run generates fresh random pseudonyms. This works because Me injects the full context (entities, matters, self_profile) into every LLM call — the LLM doesn't need cross-run pseudonym consistency. Ephemeral keys are more secure: even if one leaks, it reveals nothing about other runs.

## User Data Authority

LLM inference is probabilistic. User edits are authoritative. When they conflict:

> **User-edited values always take precedence. LLM only fills fields the user has not set.**

Implementation: user-editable fields have a `source` flag column (values `'llm'` or `'user'`). Write logic checks source before LLM updates. Entity fields edited by the user are authoritative — LLM only fills what the user has not set.

## On Matters: Klinger's Current Concerns Theory

Early designs cited the Zeigarnik Effect ("unfinished tasks occupy cognitive resources") as the theoretical basis for matters. A 2025 meta-analysis found the memory advantage claim "lacks universal validity" [A-grade].

**Current theoretical basis**: Klinger's Current Concerns Theory — the motivational state between committing to a goal and achieving/abandoning it, which continuously sensitizes attention and thinking [A-grade, 40 years of validation]. Key difference: a concern terminates not only by completion, but also by **abandonment** — which in argus-me maps to `dismissed`. There is no separate "closed" or "planned" state. A dismissed matter stops sensitizing attention; an open matter keeps doing so.

Matters have no `has_plan` or `commitment_level`. Plans are expressed as user-expected possibilities (`me.expect(possibility_id)`). The system infers commitment from fragment patterns, not from explicit flags.

## On Intentions: The Hidden Layer

Beyond explicit matters (what the user consciously tracks), people carry **implicit intentions** they may not be aware of. A user who repeatedly postpones a matter, or whose dynamics with a certain person steadily decline, may be unconsciously moving toward a decision they haven't articulated.

argus-me detects these patterns through its subconscious engine and maintains them as hidden intentions — not surfaced to the user until confidence is high enough. Hidden intentions silently improve possibility quality by providing deeper context to the LLM. When confidence crosses a threshold, they surface as insights: *"You may not have noticed, but over the past two months you've been gradually distancing from X."*

This aligns with the core philosophy: **illuminate what you might not see**.
