# Migration Guide

## Fresh Install

```python
from argus_me import Me

me = Me(
    name="Your Name",
    db_path="~/data/memory.db",
    llm_base_url="http://localhost:11434/v1",
    llm_model="qwen2.5:32b",
)
```

This creates `memory.db` at the specified path with all tables and the self entity registered.

## Migrating from Existing Argus Database

If you have an existing `memory.db` from the original argus system (schema versions 1-18), argus-me provides a one-time migration path to the new four-primitive data model.

### What Changes

| Before (Argus schema) | After (argus-me schema) | Migration |
|----------------------|----------------------|-----------|
| `persons` table | `entities` table | Rename + restructure: `speaker_id` -> UUID `id`, `name` -> `canonical_name` |
| `persons.role` | `matter_entities.role_in_matter` | Role moves from entity to connection (same entity, different roles per matter) |
| `persons.type` | *(removed)* | Entity meaning comes from matter participation, not labels |
| `person_aliases` | `entity_aliases` | Rename, same structure |
| `sessions` + `emotions` | `runs` | Merge: session summary + emotion data = one run record |
| `user_notes` | `fragments` (type='action') | User notes become action fragments in the unified input stream |
| `matters.status` (open/closed/abandoned/planned) | `matters.status` (open/dismissed) | All non-open statuses collapse to `dismissed` |
| `matters.has_plan` | *(removed)* | Plans expressed via `me.expect(possibility_id)` |
| `matters.commitment_level` | *(removed)* | Inferred from fragment patterns |
| `matters.closed_date` | *(removed)* | Matters are never closed |
| `matter_persons` | `matter_entities` | Rename to match entity terminology |
| `relationships` | *(removed)* | Derived at query time from `matter_entities` co-occurrence |
| `micro_triggers` | *(removed from core)* | Consumer-specific; can be ingested as text fragments |
| `energy` | *(removed from core)* | Consumer-specific; body state enters through natural language |
| `rhythms` | *(removed from core)* | Consumer-specific |
| `context` | *(removed from core)* | Consumer-specific |
| `semantic` | *(removed from core)* | Long-term memory compression planned for v0.3+ |
| `intentions` (if present) | `intentions` | Schema aligned, data preserved |
| *(new)* | `fragments` | New unified input table |
| *(new)* | `intentions` | Hidden cognitive layer |

### Step-by-Step Migration

#### 1. Backup

```bash
cp /path/to/argus/memory.db /path/to/argus/memory.db.bak
```

This is critical. The migration is destructive to the old schema (tables are renamed/restructured).

#### 2. Check Current Schema Version

```bash
sqlite3 /path/to/memory.db "SELECT value FROM meta WHERE key='schema_version'"
```

Expected: a number between 1 and 18.

#### 3. Run Migration

```python
from argus_me import Me

me = Me(
    name="Your Name",
    db_path="/path/to/memory.db",
    llm_base_url="http://localhost:11434/v1",
    llm_model="qwen2.5:32b",
)
```

`Me()` instantiation automatically detects the old schema and applies all pending migrations in order. The migration sequence:

| Migration | What it does |
|-----------|-------------|
| 019 | Creates `fragments` table; migrates `user_notes` data into fragments (type='action') |
| 020 | Renames `persons` -> `entities`; restructures PKs from speaker_id to UUID; moves role to `matter_entities`; renames `person_aliases` -> `entity_aliases` |
| 021 | Merges `sessions` + `emotions` into `runs` table |
| 022 | Simplifies `matters`: drops `has_plan`, `commitment_level`, `closed_date`; collapses all non-open statuses to `dismissed` |
| 023 | Creates `intentions` table |

#### 4. Verify

```bash
sqlite3 memory.db "SELECT value FROM meta WHERE key='schema_version'"
# Expected: latest version number

sqlite3 memory.db "SELECT COUNT(*) FROM entities"
sqlite3 memory.db "SELECT COUNT(*) FROM runs"
sqlite3 memory.db "SELECT COUNT(*) FROM matters WHERE status='open'"
sqlite3 memory.db "SELECT COUNT(*) FROM fragments"
sqlite3 memory.db "SELECT COUNT(*) FROM possibilities"
```

Entity count should match your previous persons count. Run count should match sessions count. All data is preserved.

#### 5. Update Consumer Code

If you have code that imports from the old argus package:

```python
# Before
from argus.models import get_persons, get_sessions
# ...

# After
from argus_me import Me
me = Me(name="...", db_path="...", llm_base_url="...", llm_model="...")
me.entities      # replaces get_persons()
me.runs          # replaces get_sessions()
me.matters       # replaces get_matters()
me.understand()  # replaces the entire ETL pipeline
```

### Data That Doesn't Migrate

The following Argus-specific tables are **not migrated** into argus-me's schema. They remain in the database file but are not read by argus-me:

- `energy` — Apple Watch / biometric data (consumer-specific)
- `micro_triggers` — behavioral micro-signals (consumer-specific)
- `rhythms` — temporal patterns (consumer-specific)
- `context` — calendar/weather/location (consumer-specific)
- `semantic` — long-term compressed memory (planned for v0.3+)
- `relationships` — now derived from matter_entities co-occurrence

Consumers that need this data can continue reading these tables directly from memory.db. argus-me will not modify or delete them.

### Migration Safety

- **Idempotent**: Running migrations twice has no effect (existence checks on every operation)
- **Data-preserving**: All user data is preserved. Restructured via INSERT...SELECT, never deleted.
- **Backward-compatible rendering**: Old data renders correctly through fallback logic
- **Python migrations**: Complex transforms (e.g., persons -> entities PK restructure) use `.py` migration files with the same `migrate(db_path)` interface

### Troubleshooting

**"self_profile column not found"**: Your DB predates migration 018. Instantiate `Me` — migrations will auto-apply all pending steps including 018.

**"No such table: fragments"**: Your DB predates migration 019. Same fix — instantiate `Me`.

**Entities have wrong IDs**: Migration 020 generates new UUIDs for entities. The old `speaker_id` values are preserved in `entity_aliases` as aliases, so identity resolution still works.

**Matter statuses changed**: Migration 022 collapses `closed`, `abandoned`, `planned` to `dismissed`. This is by design — argus-me only has two states.
