# Roadmap & Vision

Me is a cognitive exoskeleton — it grows on the user, amplifying what they can perceive and understand. It never acts autonomously, never replaces human judgment, never talks to other systems on the user's behalf.

The exoskeleton gets better through use, not through version upgrades. Prompt improvements, fragment accumulation, deeper self-model — these happen continuously, invisibly. Version numbers mark **capability boundaries expanding**, not feature checklists.

## v0.1 — The Exoskeleton Exists

**North star**: A person feeds their daily fragments into Me and gets back a structured understanding of their world that they couldn't see on their own.

Core cognitive cycle works: `ingest -> understand -> snapshot`. One person, text input, single database.

**Must-do before release**:

- [ ] Four-primitive data model (fragments, entities, matters, runs + intentions + insight_queue + possibilities)
- [ ] Me class implementation (me.py) with full public API
- [ ] 4-call LLM pipeline (identity -> facts -> insights -> possibilities)
- [ ] Subconscious: sentinel stats + cognitive debt scanning
- [ ] Intention scanner (hidden layer, not exposed in snapshot)
- [ ] argus-redact integration (redact=True)
- [ ] Prompt templates (Jinja2, overridable via prompt_dir)
- [ ] Migration path from existing Argus schema (019-023)
- [ ] Package: `pip install argus-me`
- [ ] README, docs, .gitignore, LICENSE

**Acceptance criteria**:

1. `Me(name, db_path, llm_base_url, llm_model)` creates memory.db with self entity
2. `me.ingest(text)` creates a fragment; `me.understand()` processes it into a run
3. All interaction methods (alias/dismiss/expect/merge/answer/prioritize/edit_profile/note) create cognitive fragments
4. `me.snapshot()` returns typed cognitive snapshot; live queries work
5. Subconscious runs after pipeline: stats preamble, cognitive debts, intention scanning
6. Intentions silently improve Call 3/4 output quality
7. `prompt_dir` parameter allows full prompt customization
8. Migration from existing Argus schema (v1-v18) preserves all data

## v0.2 — Deeper Understanding

**North star**: Me understands patterns across time, not just today's fragments.

- [ ] Anti-bias engine (insight concentration, emotion granularity, echo chamber detection)
- [ ] Intention surfacing: high-confidence implicit intentions surface as insights
- [ ] Stats preamble enrichment (relationship strength derivation, entity lifecycle tracking)
- [ ] Long transcript handling: improved chunking with semantic boundaries
- [ ] Better identity resolution: cross-fragment entity linking improvements
- [ ] Prompt template refinement based on accumulated real-world usage

## v0.3 — Structured Self

**North star**: Me knows who I am as a structured model, not just a text blob.

- [ ] Four-layer self-model (Schema, Motivation, Narrative, External View + Metacognition)
- [ ] Self-model auto-population from Call 1/3 observations
- [ ] Long-term memory compression (fragments -> semantic summaries after 30+ days)
- [ ] Memory pruning: subconscious identifies and archives low-value fragments
- [ ] Richer possibility generation: historical precedent matching from semantic memory

## v1.0+ — Long-term Direction

**Direction**: Deeper understanding -> richer input modalities -> broader applicability.

Each step expands the boundary of what Me can perceive and who it can serve.

**Richer input**:
- Structured data ingestion helpers (preprocessors that convert non-text into text fragments)
- Multi-language fragment handling improvements
- Temporal anchoring: fragments with precise timestamps for time-series patterns

**Deeper cognition**:
- Multi-model support: primary LLM + challenger LLM for calibration
- Self-calibrating predictions: track prediction accuracy, adjust confidence over time
- Narrative coherence scoring: how well does the user's story hold together?

**Broader reach**:
- Team/organizational use: multiple Me instances with shared entity namespaces
- Export/import: cognitive snapshots as portable data
- Integration patterns: documented recipes for common consumer architectures

## Design Invariants

These hold regardless of version:

- **Exoskeleton, not agent**: Amplifies understanding, never acts autonomously
- **Library, not app**: Me class is the only public API
- **Local-first**: Core runs without network (except LLM API)
- **Single file**: One `memory.db`
- **Text-first**: Non-text data enters through preprocessors as text fragments
- **No deletion**: Matters are open or dismissed, never deleted or closed
- **Expand possibilities**: No agency labels. All possibilities expand vision
- **User authority**: User edits override LLM inference
- **Cognitive fragment loop**: Every action feeds back
- **Accelerate with brakes**: Every personalization has an anti-bias check
- **No built-in sync**: Consumers handle sync externally
- **Customizable cognition**: Prompt templates are overridable
