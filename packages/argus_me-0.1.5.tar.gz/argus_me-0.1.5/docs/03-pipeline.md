# Cognitive Pipeline

`me.understand()` processes unprocessed fragments through a 4-call LLM pipeline, then runs the subconscious. Each call builds on the previous — you can't understand "what it means" without first knowing "what happened", and you can't know "what happened" without knowing "who is who".

```
Unprocessed fragments from memory.db
    |
    v
Call 1 - Identity (WHO)        "Who is who? Who am I in this context?"
    |
    v
Call 2 - Facts (WHAT)          "What happened? What changed?"
    |
    v
Call 3 - Insights (MEANING)    "What does it mean? What am I not seeing?"
    |
    v
Call 4 - Possibilities (WHAT MIGHT HAPPEN)   "What could happen next?"
    |
    v
Subconscious                   Sentinel stats + cognitive debt + intention scanning + anti-bias
```

All prompt templates are Jinja2 files in `argus_me/prompts/`, overridable via `Me(prompt_dir=...)`. See [Architecture: Prompt Customization](./01-architecture.md#prompt-customization).

## Call 1 - Identity (WHO)

**Function**: `resolve_identities()` in `llm.py`

**Purpose**: Resolve name mentions to known entities. Update the system's understanding of the user (self_profile).

**Template**: `call1_identity.j2`

**Input variables**:

| Variable | Source |
|----------|--------|
| `transcript` | Raw transcript (compressed, truncated to 5000 chars) |
| `known_entities` | All entities with aliases from `get_all_entities_with_aliases()` |
| `self_profile` | Current self_profile text |

**Output**:
```json
{
  "resolutions": [
    {"mention": "name", "resolved_to": "canonical_name", "confidence": 0.95}
  ],
  "self_profile_delta": [
    "In this conversation, user was called 'X' — may relate to Y circle"
  ]
}
```

**Key behaviors**:
- High-confidence resolutions (>=0.8) are persisted as new aliases in `entity_aliases`
- `self_profile_delta` lines are appended to the self entity's profile
- First-person references are excluded from resolutions
- Transcript is compressed before sending (filler removal, ack-turn elimination, same-speaker merging)
- Temperature: 0.1 (low — identity resolution needs precision)

## Call 2 - Facts (WHAT)

**Function**: `analyze_transcript()` in `llm.py`

**Purpose**: Extract structured cognitive content from the input. This is the primary extraction call.

**Template**: `call2_facts.j2` (with variant `call2_facts_diary.j2` for diary entries)

**Input variables**:

| Variable | Source |
|----------|--------|
| `transcript` | Compressed + chunked if >8000 chars (3-turn overlap between chunks) |
| `open_matters` | Active matters list |
| `network_context` | Entities with dynamics + recent important runs |
| `user_notes` | Cognitive fragments from user actions (past 7 days) |
| `stats_preamble` | Subconscious stats preamble (if available from previous run) |
| `pending_insights` | Pending insights from insight_queue |

**Output**:
```json
{
  "summary": "Today's overview from my perspective",
  "conflict": "Core tension, or empty string",
  "emotion": "emotion word", "valence": -0.4, "arousal": 0.6,
  "persons": [{"name": "...", "role": "...", "dynamics": 0.5}],
  "new_matters": [{"name": "title", "current": "status", "who": ["name"]}],
  "dismissed": ["matter names user is no longer tracking"],
  "gaps": [{"type": "open_loop", "description": "...", "size": "medium", "impact": "high"}]
}
```

**Key behaviors**:
- Two prompt variants: conversation vs diary (auto-detected from speaker labels)
- Long transcripts chunked with overlap, results merged
- User notes injected into prompt — this is how user actions feed back into understanding
- Gaps limited to 3, only medium/high impact
- New matters only for things related to the user, not other people's affairs
- Temperature: 0.3

**Gap types**: `relation_gap` | `open_loop` | `contradiction` | `info_gap` | `subjective`

## Call 3 - Insights (MEANING)

**Function**: `analyze_understanding()` in `llm.py`

**Purpose**: Deep analysis of Call 2's facts. Looks for patterns, contradictions, and things the user might not be aware of.

**Template**: `call3_insights.j2`

**Input variables**:

| Variable | Source |
|----------|--------|
| `merged_summary` | Call 2 merged summary + emotion |
| `entities_summary` | Entity digest |
| `self_profile` | Current self-understanding |
| `stats_preamble` | Subconscious stats preamble |
| `pending_insights` | Pending insights from insight_queue |
| `active_intentions` | Hidden intentions (internal context, not shown to user) |

**Output**:
```json
{
  "conflict": "Core tension (deeper than Call 2's)",
  "gaps": [{"type": "self_identity", "description": "...", "size": "...", "impact": "..."}],
  "self_observations": ["Pattern observed about user's behavior"]
}
```

**Key behaviors**:
- Call 3 results override Call 2's conflict (deeper analysis)
- Adds `self_identity` gap type (about "who am I")
- `self_observations` written to self_profile
- Active intentions injected as internal context — LLM uses them for deeper analysis without exposing them in output
- Temperature: 0.3

## Call 4 - Possibilities (WHAT MIGHT HAPPEN)

**Function**: `generate_possibilities()` in `llm.py`

**Purpose**: Generate specific, verifiable scenarios for each open matter. All possibilities expand the user's vision — no agency labels, no choices vs events categorization.

**Template**: `call4_possibilities.j2`

**Input variables**:

| Variable | Source |
|----------|--------|
| `open_matters` | All open matters (refreshed after Call 2 writes) |
| `merged_summary` | Call 2 merged summary + conflict + emotion |
| `network_context` | Entities + recent runs |
| `active_intentions` | Hidden intentions (internal context for better predictions) |

**Output**:
```json
[
  {
    "matter_id": 24,
    "event": "title",
    "narrative": "Detailed scenario: why, triggers, consequences",
    "confidence": "high",
    "historical_precedent": "Similar to when X happened last month",
    "prob": 0.7
  }
]
```

**Key behaviors**:
- 1-4 possibilities per matter (complexity-driven, not forced)
- Validated: only entries with valid `matter_id` are kept
- Previous possibilities for same matters deactivated before writing new ones
- `prob` field kept internally for sorting/ranking but hidden from users in snapshot
- Temperature: 0.4 (slightly higher — exploring possibilities benefits from diversity)

**Cognitive science**: Humans don't estimate probabilities — they construct scenarios. Call 4 aligns with constructive episodic simulation [A-grade] and premortem technique [B+-grade]. Scenarios describe *what might happen and why* — never *when*. Time in ME is always historical (fragment dates), never predictive. Assigning time horizons to possibilities would imply a forecasting precision that neither the LLM nor the fragment data can support.

## Subconscious

After the 4-call pipeline completes, `me.understand()` runs the **subconscious** — sentinel stats + cognitive debt scanning + intention scanning + anti-bias checks. This is not a separate process; it runs inline at the end of every `understand()` call.

The subconscious:
1. Generates stats preamble (entity frequencies, emotion trends, stale matters, relationship gaps)
2. Scans for cognitive debts (stale matters, emotion inflections, unconfirmed entities)
3. Scans for implicit intentions (from behavioral patterns in fragments and matter dynamics)
4. Runs anti-bias scanners (insight concentration, emotion granularity, echo chamber risk)
5. Writes findings to `insight_queue` for injection into the next `understand()` call

See [Subconscious](./05-subconscious.md) for full details.

## Pipeline Orchestration

`me.understand()` orchestrates the full flow:

1. Read unprocessed fragments from memory.db
2. For each fragment: Call 1 -> Call 2 -> DB writes
3. After all fragments: Call 3 (on merged results) -> Call 4 (on refreshed matters)
4. Run subconscious (sentinel + antibias + intention scanning)
5. Mark fragments as processed
6. Return result summary

**Error handling**: Each call is wrapped in try/except. If Call 1 fails, pipeline continues without identity resolution. If Call 3 fails, Call 2 results are used. If Call 4 fails, no possibilities are generated but everything else succeeds. Subconscious failure does not block the pipeline.

## Prompt Injection Map

The LLM sees the user's full context through these injection points:

| Injection | Source | Calls |
|-----------|--------|-------|
| Network context | entities + recent runs from memory.db | 2, 4 |
| Open matters | active matters list | 2, 4 |
| Action fragments | user actions from fragments table (past 7 days) | 2 |
| Self profile | evolving self-understanding | 1, 3 |
| Stats preamble + pending insights | entity frequencies, emotion trends, cognitive debts | 2, 3 |
| Known entities + aliases | entities table for identity resolution | 1 |
| Active intentions | hidden intention layer (internal context) | 3, 4 |
