# Architecture

## Library, Not an App

argus-me is a pure Python library. No CLI, no web UI, no API endpoints, no CGI handlers. It provides a single entry point — the `Me` class — that consumers import and use.

```python
from argus_me import Me

me = Me(name="...", db_path="...", llm_base_url="...", llm_model="...", redact=True)
```

Consumers decide how to present the output — web app, CLI, mobile, desktop, or silent background process. argus-me doesn't care.

## Module Overview

```
argus_me/
├── me.py           Me class: public API, orchestrates everything
├── etl.py          Pipeline: 4-call LLM flow + DB writes
├── llm.py          LLM client: prompt loading, calls, compression, chunking
├── models.py       Database ops: memory.db reads/writes
├── render.py       Output: cognitive snapshot formatting
├── sentinel.py     Subconscious: stats engine + cognitive debt + intention scanning
├── antibias.py     Anti-bias: diversity + granularity + echo chamber detection
├── redact.py       PII redaction (wraps argus-redact when redact=True)
├── migrate.py      Migration runner: SQL + Python migrations
├── config.py       Configuration dataclass
└── prompts/        Default prompt templates (Jinja2, overridable)
    ├── call1_identity.j2
    ├── call2_facts.j2
    ├── call3_insights.j2
    └── call4_possibilities.j2
```

## Data Flow

```
Consumer calls me.ingest("text")
    |
    v
  fragments table          <- unified pool of unprocessed input (memory.db)
    |
    v
Consumer calls me.understand()
    |-- Call 1 - Identity (WHO)
    |-- Call 2 - Facts (WHAT)
    |-- Call 3 - Insights (MEANING)
    |-- Call 4 - Possibilities (WHAT MIGHT HAPPEN)
    |-- Subconscious (sentinel + antibias + intention scanning)
    |-- DB writes (runs/entities/matters/possibilities)
    v
  result object               <- summary of what was understood
```

The pipeline only sees `fragment.transcript` — it doesn't care about input source. When `redact=True`, PII is stripped before LLM calls via integrated argus-redact.

### The Feedback Loop

The pipeline is not one-directional. User interactions via `Me` methods generate **cognitive fragments** that feed back into the next `understand()`:

```
me.understand() -> result -> consumer shows to user
    -> user acts -> me.dismiss() / me.expect() / me.note()
    -> fragment recorded -> next understand() reads it
```

See [Philosophy: Cognitive Fragment Principle](./00-philosophy.md#the-cognitive-fragment-principle).

## Prompt Customization

argus-me ships with default prompt templates in `argus_me/prompts/`. These are functional and demonstrate the full cognitive pipeline. Consumers can override any or all templates:

```python
me = Me(
    ...,
    prompt_dir="./my_prompts/",  # override directory
)
```

**Loading priority**: If `prompt_dir` is set, `llm.py` checks for a same-named `.j2` file there first. If found, uses the external template. If not found for a given call, falls back to the built-in default.

**Template contract**: Each template receives a defined set of variables (documented in [Pipeline](./03-pipeline.md)). The variable interface is stable across versions; template content is freely replaceable.

This design enables:
- Open-source users get a complete, working system out of the box
- Advanced users tune prompts for their specific LLM, language, or cognitive style
- Consumers (like private systems built on argus-me) maintain optimized prompts separately

## No Built-in Sync

argus-me operates on a local `memory.db` only. It has no built-in sync or remote awareness. Consumers handle sync externally — rsync, SCP, Syncthing, cloud storage, whatever fits their architecture.

## LLM Layer

Uses OpenAI-compatible API:

```python
me = Me(
    llm_base_url="http://localhost:11434/v1",  # Ollama default
    llm_model="qwen2.5:32b",
    ...
)
# Works with: Ollama, OpenAI API, Anthropic (via compat), vLLM, LM Studio
```

No code changes needed to switch providers — just constructor parameters.

## Storage

| Database | Purpose | Location |
|----------|---------|----------|
| `memory.db` | Everything: fragments, cognitive data, LLM metrics | `db_path` parameter |

Single database file. SQLite, WAL mode. Fragments table replaces file tracking; LLM metrics stored alongside cognitive data.

Migrations in `src/migrations/memory/`, supporting `.sql` and `.py` formats. `migrate.py` auto-applies pending migrations by numeric filename prefix on `Me()` instantiation.

## Dependencies

**Required**: `openai`, `jinja2`, `uuid6`, `httpx`

**Optional**: `argus-redact` (PII redaction, used when `redact=True`), `pytest` (testing)
