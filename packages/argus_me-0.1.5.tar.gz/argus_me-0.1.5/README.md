# argus-me

[![Tests](https://github.com/wan9yu/argus-me/actions/workflows/test.yml/badge.svg)](https://github.com/wan9yu/argus-me/actions/workflows/test.yml)
[![codecov](https://codecov.io/gh/wan9yu/argus-me/graph/badge.svg)](https://codecov.io/gh/wan9yu/argus-me)
[![PyPI](https://img.shields.io/pypi/v/argus-me)](https://pypi.org/project/argus-me/)
[![HF Space](https://img.shields.io/badge/HF-Demo-yellow)](https://huggingface.co/spaces/wan9yu/argus-me)

> Give Me fragments. I give you understanding.

Personal cognitive engine library — ingest fragments, build memory, generate insights, expand possibilities.

Sister project: [argus-redact](https://github.com/wan9yu/argus-redact) — encrypt PII, not meaning. When `redact=True`, Me strips real names before sending to the LLM via argus-redact.

## What It Is

You live in fragments — conversations, diary entries, decisions, changes of mind. Your brain loosely connects them, but you can't see the full picture.

argus-me is a **cognitive exoskeleton**. It processes your fragments into an evolving understanding, and illuminates possibilities you might not see on your own. But it's always you who walks.

## Quick Start

```python
from argus_me import Me

me = Me(
    name="Your Name",
    db_path="~/data/memory.db",
    llm_base_url="http://localhost:11434/v1",
    llm_model="qwen2.5:32b",
    redact=True,
)

# Feed fragments (text only)
me.ingest("Had coffee with Tom today. He's thinking about leaving BigCorp.")
me.ingest("Diary: feeling stuck on the product direction lately.")

# Overnight batch: 4-call pipeline + subconscious
result = me.understand()

# What does Me see right now?
snap = me.snapshot()
me.matters        # what I care about
me.entities       # who's in my world
me.possibilities  # what might happen
```

One class. Six parameters. A name, a memory, a brain, a privacy setting, and an optional cognitive style.

## Four Primitives

Me's world has only four things:

**Fragment** — what happened. A conversation, a diary entry, a user action. Immutable.

**Entity** — what's in my world. A person, a company, a team, a concept. No type labels — meaning comes from which matters it participates in.

**Matter** — what I care about. A current concern. Either open or dismissed. Never "completed" — cognition doesn't complete, it shifts.

**Self** — who I am. Evolving self-understanding, updated with every `understand()`.

Everything else — emotions, relationships, possibilities, intentions — is derived from these four.

## The Cognitive Loop

The deepest design: **every interaction feeds back.**

```
Fragments accumulate (conversations, diary, user actions)
    |
me.understand() — batch processing, 4-call LLM pipeline + subconscious
    |
Updated understanding (entities, matters, possibilities, self-profile)
    |
User sees new perspective, acts (dismiss, expect, merge, note...)
    |
Actions become new fragments
    |
Next understand() reads them...
```

Me gets smarter not just from new input, but from **every interaction you have with it**. Dismissing a matter tells Me what you no longer care about. Expecting a possibility tells Me which direction you're heading. Editing your profile tells Me you've re-examined yourself.

## Possibilities

Not predictions. Not recommendations.

Possibilities **illuminate** — they show you what might happen, expanding your field of vision. Me doesn't label them as "choices" or "events." It doesn't know where your agency begins and ends — you do.

**Me expands what you can see. You decide where to go.**

## Privacy

When `redact=True`, Me strips real names before sending to the LLM (via [argus-redact](https://github.com/wan9yu/argus-redact)). The LLM reasons on redacted text; Me restores real names in the output. The redaction key is ephemeral — born and discarded within each `understand()` call.

## Customizable Cognition

Me ships with default prompt templates that power the 4-call LLM pipeline. You can override any or all templates to tune the cognitive style:

```python
me = Me(..., prompt_dir="./my_prompts/")
```

Framework is open. Cognitive style is yours to shape.

## What It's Not

- Not an **agent** — never acts autonomously
- Not an **assistant** — never does tasks for you
- Not a **note-taking app** — doesn't store things
- Not an **application** — it's a Python library, no CLI, no web UI

## Documentation

| # | Document | Content |
|---|----------|---------|
| 00 | [Philosophy](./docs/00-philosophy.md) | Core principles, cognitive science basis, design rationale |
| 01 | [Architecture](./docs/01-architecture.md) | Library structure, modules, prompt customization, LLM layer |
| 02 | [Data Model](./docs/02-data-model.md) | SQLite schema, 4 primitives, 10 tables, feedback loop |
| 03 | [Pipeline](./docs/03-pipeline.md) | `me.understand()` internals: 4-call LLM pipeline + subconscious |
| 04 | [Self Model](./docs/04-self-model.md) | Four-layer self-profile architecture (current + planned) |
| 05 | [Subconscious](./docs/05-subconscious.md) | Sentinel stats + cognitive debt + intention scanning + anti-bias |
| 06 | [API Reference](./docs/06-api.md) | Me class public API |
| 07 | [Migration Guide](./docs/07-migration-guide.md) | Migrating existing data to argus-me |
| 08 | [Roadmap](./docs/08-roadmap.md) | v0.1 -> v0.2 -> v0.3 -> v1.0+ |

## Cognitive Science Basis

| Design Choice | Theory | Grade |
|--------------|--------|-------|
| Matters as cognitive attractors | Klinger Current Concerns Theory | A |
| Fragment -> meaning assembly | Klein Data/Frame + Weick Sensemaking | A |
| Scenario narratives over probabilities | Constructive episodic simulation + RPD | A |
| No deletion, only dismissal | Cognitive continuity | - |
| Expand possibilities, don't limit | Autonomy + sensemaking | - |
| Hidden intention detection | Klinger implicit concerns + behavioral pattern analysis | B+ |
| Anti-bias subconscious | Confirmation bias + echo chamber research | B+ |

## Install

```bash
pip install argus-me
```

**Dependencies**: `openai`, `jinja2`, `uuid6`, `httpx`

**Optional**: `argus-redact` (PII redaction, used when `redact=True`)

**LLM**: Any OpenAI-compatible API (Ollama, OpenAI, Anthropic via compat, vLLM, LM Studio)

## License

Apache 2.0
