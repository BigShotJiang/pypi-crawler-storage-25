"""
Cache server implementation.

This module provides the HTTP server that handles cache storage and retrieval
on each node in the distributed cache cluster.

Metrics are:
1. Collected via Prometheus counters/gauges (in-memory)
2. Periodically written to a local file (Prometheus format)
3. Periodically pushed to central gRPC/Prometheus server
"""

import os
import logging
import shutil
import asyncio
import threading
from pathlib import Path
from typing import Optional, Dict, Any, List
import time
import socket

from aiohttp import web
import diskcache

from ramjetio.serialization import serialize_object, deserialize_object

# Prometheus metrics (optional - graceful fallback if not installed)
try:
    from prometheus_client import Counter, Gauge, Histogram, generate_latest
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False

logger = logging.getLogger(__name__)

# Initialize Prometheus metrics (if available)
if PROMETHEUS_AVAILABLE:
    # Get node name from environment or hostname
    NODE_NAME = os.environ.get('RAMJET_NODE_NAME', socket.gethostname())
    
    # Counters
    CACHE_HITS = Counter(
        'ramjet_cache_hits_total', 
        'Total number of cache hits',
        ['node']
    )
    CACHE_MISSES = Counter(
        'ramjet_cache_misses_total', 
        'Total number of cache misses',
        ['node']
    )
    CACHE_SETS = Counter(
        'ramjet_cache_sets_total', 
        'Total number of cache sets',
        ['node']
    )
    CACHE_DELETES = Counter(
        'ramjet_cache_deletes_total', 
        'Total number of cache deletes',
        ['node']
    )
    CACHE_ERRORS = Counter(
        'ramjet_cache_errors_total', 
        'Total number of cache errors',
        ['node']
    )
    
    # Gauges
    CACHE_SIZE_BYTES = Gauge(
        'ramjet_cache_size_bytes', 
        'Current cache size in bytes',
        ['node']
    )
    CACHE_FILES_COUNT = Gauge(
        'ramjet_cache_files_count', 
        'Number of files in cache',
        ['node']
    )
    CACHE_HIT_RATIO = Gauge(
        'ramjet_cache_hit_ratio', 
        'Cache hit ratio (hits / total requests)',
        ['node']
    )
    DISK_USAGE_BYTES = Gauge(
        'ramjet_disk_usage_bytes',
        'Disk usage in bytes',
        ['node', 'type']  # type: total, used, free
    )
    
    # Histogram for request latency
    REQUEST_LATENCY = Histogram(
        'ramjet_request_duration_seconds',
        'Request latency in seconds',
        ['node', 'operation'],  # operation: get, set, delete
        buckets=[.001, .005, .01, .025, .05, .1, .25, .5, 1.0, 2.5, 5.0]
    )


class MetricsExporter:
    """
    Background exporter for metrics.
    
    Periodically:
    1. Writes metrics to local file (Prometheus format)
    2. Pushes metrics to central server (gRPC or Prometheus Pushgateway)
    """
    
    def __init__(
        self,
        node_name: str,
        metrics_file: str = "/tmp/ramjet_metrics.prom",
        push_url: Optional[str] = None,
        push_interval: float = 2.0,
        file_interval: float = 2.0,
    ):
        """
        Initialize metrics exporter.
        
        Args:
            node_name: Name of this node (for labeling)
            metrics_file: Path to write Prometheus metrics file
            push_url: URL to push metrics (Prometheus Pushgateway or gRPC backend)
            push_interval: Interval in seconds between pushes to remote
            file_interval: Interval in seconds between file writes
        """
        self.node_name = node_name
        self.metrics_file = Path(metrics_file)
        self.push_url = push_url
        self.push_interval = push_interval
        self.file_interval = file_interval
        
        self._running = False
        self._file_thread: Optional[threading.Thread] = None
        self._push_thread: Optional[threading.Thread] = None
        
        logger.info(f"MetricsExporter initialized: file={metrics_file}, push_url={push_url}")
    
    def start(self) -> None:
        """Start background export threads."""
        if self._running:
            return
        
        self._running = True
        
        # Thread for writing to file
        self._file_thread = threading.Thread(target=self._file_write_loop, daemon=True)
        self._file_thread.start()
        
        # Thread for pushing to remote (if configured)
        if self.push_url:
            self._push_thread = threading.Thread(target=self._push_loop, daemon=True)
            self._push_thread.start()
        
        logger.info("MetricsExporter started")
    
    def stop(self) -> None:
        """Stop background export threads."""
        self._running = False
        logger.info("MetricsExporter stopped")
    
    def _file_write_loop(self) -> None:
        """Background loop to write metrics to file."""
        while self._running:
            try:
                self._write_metrics_to_file()
            except Exception as e:
                logger.warning(f"Failed to write metrics to file: {e}")
            time.sleep(self.file_interval)
    
    def _push_loop(self) -> None:
        """Background loop to push metrics to remote server."""
        while self._running:
            try:
                self._push_metrics()
            except Exception as e:
                logger.warning(f"Failed to push metrics: {e}")
            time.sleep(self.push_interval)
    
    def _write_metrics_to_file(self) -> None:
        """Write current metrics to file in Prometheus format."""
        if not PROMETHEUS_AVAILABLE:
            return
        
        metrics_data = generate_latest()
        
        # Write atomically (write to temp, then rename)
        temp_file = self.metrics_file.with_suffix('.tmp')
        temp_file.write_bytes(metrics_data)
        temp_file.rename(self.metrics_file)
        
        logger.debug(f"Metrics written to {self.metrics_file}")
    
    def _push_metrics(self) -> None:
        """Push metrics to remote server."""
        if not self.push_url:
            return
        
        if not PROMETHEUS_AVAILABLE:
            return
        
        metrics_data = generate_latest()
        
        # Determine push method based on URL
        if self.push_url.startswith("http"):
            self._push_to_pushgateway(metrics_data)
        elif self.push_url.startswith("grpc://"):
            self._push_to_grpc(metrics_data)
        else:
            logger.warning(f"Unknown push URL scheme: {self.push_url}")
    
    def _push_to_pushgateway(self, metrics_data: bytes) -> None:
        """Push metrics to Prometheus Pushgateway."""
        try:
            import urllib.request
            
            # Pushgateway expects POST to /metrics/job/<job_name>/instance/<instance>
            url = f"{self.push_url}/metrics/job/ramjet/instance/{self.node_name}"
            
            req = urllib.request.Request(
                url,
                data=metrics_data,
                method='POST',
                headers={'Content-Type': 'text/plain'}
            )
            
            with urllib.request.urlopen(req, timeout=5) as response:
                if response.status == 200:
                    logger.debug(f"Metrics pushed to {self.push_url}")
                else:
                    logger.warning(f"Pushgateway returned status {response.status}")
                    
        except Exception as e:
            logger.warning(f"Failed to push to Pushgateway: {e}")
    
    def _push_to_grpc(self, metrics_data: bytes) -> None:
        """Push metrics to gRPC backend."""
        # TODO: Implement gRPC push when backend is ready
        # For now, just log
        logger.debug(f"gRPC push not yet implemented (would send {len(metrics_data)} bytes)")


class CacheServer:
    """
    HTTP server for distributed cache node.
    
    Each cache server manages local disk storage and responds to HTTP requests
    for caching operations (get, set, delete, etc.).
    
    Automatically connects to RAMJET backend if RAMJET_API_KEY is set.
    
    Args:
        host: Server host address (default: "0.0.0.0")
        port: Server port (default: 9000)
        storage_path: Path to disk storage directory
        max_capacity: Maximum storage capacity in bytes (default: 10TB)
    """
    
    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 9000,
        storage_path: str = "/tmp/ramjet_cache",
        max_capacity: int = 0,  # 0 = auto (80% of available disk)
        metrics_file: Optional[str] = None,
        metrics_push_url: Optional[str] = None,
        metrics_push_interval: float = 10.0,
    ):
        """Initialize the cache server."""
        self.host = host
        self.port = port
        self.storage_path = Path(storage_path)
        
        # Create storage directory
        self.storage_path.mkdir(parents=True, exist_ok=True)
        
        # Smart default: use 80% of available disk if not specified
        if max_capacity <= 0:
            try:
                usage = shutil.disk_usage(self.storage_path)
                max_capacity = int(usage.free * 0.8)
                logger.info(f"Auto-detected cache size limit: {max_capacity / (1024**3):.1f} GB (80% of free disk)")
            except Exception:
                max_capacity = 100 * 1024 * 1024 * 1024  # Fallback: 100GB
        
        self.max_capacity = max_capacity
        
        # Initialize disk cache
        self.cache = diskcache.Cache(
            str(self.storage_path),
            size_limit=max_capacity,
            eviction_policy='least-recently-used'
        )
        
        # Default TTL (seconds) — 0 means no expiry. Updated from cluster config.
        self._default_ttl: int = 0
        
        # Auto-eviction toggle — if False, diskcache size_limit is set to 0 (unlimited).
        # Updated from cluster config.
        self._auto_eviction: bool = True
        
        # Statistics (protected by _stats_lock for thread-safe access)
        self.stats_data = {
            "hits": 0,
            "misses": 0,
            "sets": 0,
            "deletes": 0,
            "errors": 0,
            "start_time": time.time(),
        }
        self._stats_lock = threading.Lock()
        
        # Throughput tracking with exponential moving average
        self._bytes_transferred = 0  # Total bytes in last interval
        self._bytes_lock = threading.Lock()
        self._last_throughput_calc = time.time()
        self._current_throughput_mbps = 0.0
        self._throughput_ema = 0.0  # Exponential moving average
        self._throughput_alpha = 0.3  # EMA smoothing factor (0.3 = moderate smoothing)
        self._avg_latency_samples: List[float] = []
        self._latency_ema = 0.0  # EMA for latency
        self._latency_lock = threading.Lock()
        
        # Initialize metrics exporter (runs in background)
        node_name = os.environ.get('RAMJET_NODE_NAME', f"{socket.gethostname()}:{port}")
        default_metrics_file = f"/tmp/ramjet_metrics_{port}.prom"
        
        self.metrics_exporter = MetricsExporter(
            node_name=node_name,
            metrics_file=metrics_file or default_metrics_file,
            push_url=metrics_push_url or os.environ.get('RAMJET_METRICS_PUSH_URL'),
            push_interval=metrics_push_interval,
        )
        
        # Backend client for registration and heartbeat
        self._backend_client: Optional['BackendClient'] = None
        
        logger.info(f"Initialized CacheServer at {storage_path} with capacity {max_capacity / (1024**3):.1f} GB")
    
    def _init_backend_connection(self) -> None:
        """Initialize connection to RAMJET backend (if API key is configured)."""
        try:
            from ramjetio.backend_client import BackendClient
            from ramjetio.config import get_api_key
            
            api_key = get_api_key()
            if not api_key:
                logger.info(
                    "RAMJET_API_KEY not set. Running in standalone mode. "
                    "Set RAMJET_API_KEY to enable backend integration."
                )
                return
            
            self._backend_client = BackendClient(node_port=self.port)
            
            if self._backend_client.connect():
                # Apply cluster config (e.g. max_cache_size_bytes) if provided
                cluster_config = self._backend_client.get_cluster_config()
                if cluster_config:
                    self._apply_cluster_config(cluster_config)
                
                # Start heartbeat with metrics
                self._backend_client.start_heartbeat(
                    self._get_metrics_for_backend,
                    on_config_changed=self._apply_cluster_config,
                )
                logger.info("✓ Connected to RAMJET backend. Metrics will be reported.")
            else:
                logger.warning("Failed to connect to backend. Running in standalone mode.")
                self._backend_client = None
                
        except ImportError as e:
            logger.debug(f"Backend client not available: {e}")
        except Exception as e:
            logger.warning(f"Failed to initialize backend connection: {e}")
    
    def _apply_cluster_config(self, config: Dict[str, Any]) -> None:
        """Apply cluster configuration from backend to local cache settings."""
        # 1. Max cache size
        max_size = config.get('max_cache_size_bytes', 0)
        if max_size > 0:
            self.cache.reset('size_limit', max_size)
            self.max_capacity = max_size
            logger.info(f"Applied cluster cache size limit: {max_size / (1024**3):.1f} GB")
        
        # 2. Default TTL
        ttl = config.get('ttl_seconds', 0)
        if ttl > 0:
            self._default_ttl = ttl
            logger.info(f"Applied cluster default TTL: {ttl}s")
        
        # 3. Auto-eviction toggle
        auto_eviction = config.get('auto_eviction', True)
        if not auto_eviction and self._auto_eviction:
            # Disable eviction by setting size_limit to 0 (unlimited in diskcache)
            self.cache.reset('size_limit', 0)
            self._auto_eviction = False
            logger.info("Auto-eviction disabled by cluster config (size_limit set to unlimited)")
        elif auto_eviction and not self._auto_eviction:
            # Re-enable eviction with the configured max capacity
            self.cache.reset('size_limit', self.max_capacity)
            self._auto_eviction = True
            logger.info(f"Auto-eviction re-enabled (size_limit: {self.max_capacity / (1024**3):.1f} GB)")

    def _get_metrics_for_backend(self) -> Dict[str, Any]:
        """Get current metrics for backend heartbeat."""
        import shutil
        
        try:
            usage = shutil.disk_usage(self.storage_path)
            with self._stats_lock:
                stats_snapshot = dict(self.stats_data)
            total_requests = stats_snapshot["hits"] + stats_snapshot["misses"]
            hit_ratio = stats_snapshot["hits"] / total_requests if total_requests > 0 else 0.0
            
            # Calculate throughput (MB/s) since last call with EMA smoothing
            now = time.time()
            with self._bytes_lock:
                elapsed = now - self._last_throughput_calc
                if elapsed > 0.5:  # Only update if at least 0.5 sec passed
                    # Calculate instantaneous throughput (bytes to MB)
                    instant_throughput = (self._bytes_transferred / 1_000_000) / elapsed
                    
                    # Apply exponential moving average for smooth transitions
                    if self._bytes_transferred > 0:
                        # New data: blend with current EMA
                        self._throughput_ema = (self._throughput_alpha * instant_throughput + 
                                               (1 - self._throughput_alpha) * self._throughput_ema)
                    else:
                        # No new data: decay slowly (keep 90% of previous value)
                        self._throughput_ema *= 0.95
                        # Floor to zero when negligible (prevents 1.48e-302 artifacts)
                        if self._throughput_ema < 0.001:
                            self._throughput_ema = 0.0
                    
                    self._current_throughput_mbps = self._throughput_ema
                    self._bytes_transferred = 0
                    self._last_throughput_calc = now
            
            # Calculate average latency (ms) with EMA
            with self._latency_lock:
                if self._avg_latency_samples:
                    # Calculate current average from samples
                    current_avg = sum(self._avg_latency_samples) / len(self._avg_latency_samples) * 1000  # to ms
                    # Apply EMA
                    self._latency_ema = 0.3 * current_avg + 0.7 * self._latency_ema
                    self._avg_latency_samples = []  # Clear after processing
                else:
                    # No new samples: decay latency toward zero
                    self._latency_ema *= 0.95
                    if self._latency_ema < 0.001:
                        self._latency_ema = 0.0
            avg_latency = self._latency_ema

            # Report 0 when cache is empty to avoid diskcache SQLite overhead noise
            cache_len = len(self.cache)
            cache_vol = self.cache.volume() if hasattr(self.cache, 'volume') else 0
            cache_size = cache_vol if cache_len > 0 else 0
            
            metrics = {
                "hit_ratio": hit_ratio,
                "cache_size_bytes": cache_size,
                "cache_items": cache_len,
                "hits": stats_snapshot["hits"],
                "misses": stats_snapshot["misses"],
                "sets": stats_snapshot["sets"],
                "throughput_mbps": self._current_throughput_mbps,
                "avg_latency_ms": avg_latency,
                "disk_total": usage.total,
                "disk_used": usage.used,
                "disk_free": usage.free,
            }
            
            # Add RAM metrics using psutil
            try:
                import psutil
                mem = psutil.virtual_memory()
                metrics["ram_total"] = mem.total
                metrics["ram_used"] = mem.used
                metrics["ram_free"] = mem.available
            except ImportError:
                pass
            
            # Add GPU metrics — try pynvml first (works without torch), fallback to torch.cuda
            gpu_detected = False
            try:
                import pynvml
                pynvml.nvmlInit()
                gpu_count = pynvml.nvmlDeviceGetCount()
                if gpu_count > 0:
                    metrics["gpu_count"] = gpu_count
                    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
                    metrics["gpu_name"] = pynvml.nvmlDeviceGetName(handle)
                    if isinstance(metrics["gpu_name"], bytes):
                        metrics["gpu_name"] = metrics["gpu_name"].decode("utf-8")
                    # Aggregate memory across all GPUs
                    mem_total = 0
                    mem_used = 0
                    for i in range(gpu_count):
                        h = pynvml.nvmlDeviceGetHandleByIndex(i)
                        info = pynvml.nvmlDeviceGetMemoryInfo(h)
                        mem_total += info.total
                        mem_used += info.used
                    metrics["gpu_memory_total"] = mem_total
                    metrics["gpu_memory_used"] = mem_used
                    metrics["gpu_memory_free"] = mem_total - mem_used
                    gpu_detected = True
                pynvml.nvmlShutdown()
            except (ImportError, Exception):
                pass

            if not gpu_detected:
                try:
                    import torch
                    if torch.cuda.is_available():
                        metrics["gpu_count"] = torch.cuda.device_count()
                        if metrics["gpu_count"] > 0:
                            metrics["gpu_name"] = torch.cuda.get_device_name(0)
                            # Aggregate memory across all GPUs
                            mem_total = 0
                            mem_used = 0
                            for i in range(torch.cuda.device_count()):
                                props = torch.cuda.get_device_properties(i)
                                mem_total += props.total_memory
                                mem_used += torch.cuda.memory_reserved(i)
                            metrics["gpu_memory_total"] = mem_total
                            metrics["gpu_memory_used"] = mem_used
                            metrics["gpu_memory_free"] = mem_total - mem_used
                except ImportError:
                    pass
                except Exception as e:
                    logger.debug(f"Failed to get GPU metrics: {e}")
            
            return metrics
        except Exception as e:
            logger.warning(f"Failed to collect metrics: {e}")
            return {}
    
    async def handle_get(self, request: web.Request) -> web.Response:
        """Handle GET/HEAD request to retrieve cached data."""
        start_time = time.time()
        key = request.query.get("key")
        
        if not key:
            return web.Response(status=400, text="Missing 'key' parameter")
        
        # HEAD request: just check existence without returning body
        is_head = request.method == "HEAD"
        
        try:
            data = self.cache.get(key)
            
            if data is None:
                with self._stats_lock:
                    self.stats_data["misses"] += 1
                # Track latency
                latency = time.time() - start_time
                with self._latency_lock:
                    self._avg_latency_samples.append(latency)
                if PROMETHEUS_AVAILABLE:
                    CACHE_MISSES.labels(node=NODE_NAME).inc()
                    REQUEST_LATENCY.labels(node=NODE_NAME, operation='get_miss').observe(latency)
                return web.Response(status=404, text="Key not found")
            
            # For HEAD requests, return 200 with Content-Length but no body
            if is_head:
                data_size = len(data) if data else 0
                return web.Response(
                    status=200,
                    headers={"Content-Length": str(data_size)}
                )
            
            # Track throughput (bytes transferred)
            data_size = len(data) if data else 0
            with self._bytes_lock:
                self._bytes_transferred += data_size
            
            with self._stats_lock:
                self.stats_data["hits"] += 1
            # Track latency
            latency = time.time() - start_time
            with self._latency_lock:
                self._avg_latency_samples.append(latency)
            if PROMETHEUS_AVAILABLE:
                CACHE_HITS.labels(node=NODE_NAME).inc()
                REQUEST_LATENCY.labels(node=NODE_NAME, operation='get_hit').observe(latency)
                self._update_hit_ratio()
            return web.Response(body=data, status=200)
            
        except Exception as e:
            with self._stats_lock:
                self.stats_data["errors"] += 1
            if PROMETHEUS_AVAILABLE:
                CACHE_ERRORS.labels(node=NODE_NAME).inc()
            logger.error(f"Error retrieving key '{key}': {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_set(self, request: web.Request) -> web.Response:
        """Handle POST request to store data in cache."""
        start_time = time.time()
        key = request.query.get("key")
        
        if not key:
            return web.Response(status=400, text="Missing 'key' parameter")
        
        try:
            # Read data from request body
            data = await request.read()
            
            # Track throughput (bytes received)
            data_size = len(data) if data else 0
            with self._bytes_lock:
                self._bytes_transferred += data_size
            
            # Get TTL if provided, otherwise use default from cluster config
            ttl = request.query.get("ttl")
            if ttl:
                expire = int(ttl)
            elif self._default_ttl > 0:
                expire = self._default_ttl
            else:
                expire = None
            
            # Store in cache
            self.cache.set(key, data, expire=expire)
            
            with self._stats_lock:
                self.stats_data["sets"] += 1
            # Track latency
            latency = time.time() - start_time
            with self._latency_lock:
                self._avg_latency_samples.append(latency)
            if PROMETHEUS_AVAILABLE:
                CACHE_SETS.labels(node=NODE_NAME).inc()
                REQUEST_LATENCY.labels(node=NODE_NAME, operation='set').observe(latency)
                self._update_cache_metrics()
            return web.Response(status=200, text="OK")
            
        except Exception as e:
            with self._stats_lock:
                self.stats_data["errors"] += 1
            if PROMETHEUS_AVAILABLE:
                CACHE_ERRORS.labels(node=NODE_NAME).inc()
            logger.error(f"Error storing key '{key}': {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_delete(self, request: web.Request) -> web.Response:
        """Handle DELETE request to remove cached data."""
        start_time = time.time()
        key = request.query.get("key")
        
        if not key:
            return web.Response(status=400, text="Missing 'key' parameter")
        
        try:
            deleted = self.cache.delete(key)
            
            if deleted:
                with self._stats_lock:
                    self.stats_data["deletes"] += 1
                if PROMETHEUS_AVAILABLE:
                    CACHE_DELETES.labels(node=NODE_NAME).inc()
                    REQUEST_LATENCY.labels(node=NODE_NAME, operation='delete').observe(time.time() - start_time)
                    self._update_cache_metrics()
                return web.Response(status=200, text="OK")
            else:
                return web.Response(status=404, text="Key not found")
                
        except Exception as e:
            with self._stats_lock:
                self.stats_data["errors"] += 1
            if PROMETHEUS_AVAILABLE:
                CACHE_ERRORS.labels(node=NODE_NAME).inc()
            logger.error(f"Error deleting key '{key}': {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_clear(self, request: web.Request) -> web.Response:
        """Handle POST request to clear all cached data."""
        try:
            self.cache.clear()
            return web.Response(status=200, text="OK")
            
        except Exception as e:
            with self._stats_lock:
                self.stats_data["errors"] += 1
            logger.error(f"Error clearing cache: {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_stats(self, request: web.Request) -> web.Response:
        """Handle GET request to retrieve server statistics."""
        try:
            # Get disk usage
            usage = shutil.disk_usage(self.storage_path)
            
            with self._stats_lock:
                stats_snapshot = dict(self.stats_data)
            
            stats = {
                **stats_snapshot,
                "uptime": time.time() - stats_snapshot["start_time"],
                "items": len(self.cache),
                "cache_size": self.cache.volume() if (hasattr(self.cache, 'volume') and len(self.cache) > 0) else 0,
                "disk_total": usage.total,
                "disk_used": usage.used,
                "disk_free": usage.free,
                "disk_percent": (usage.used / usage.total) * 100,
            }
            
            return web.json_response(stats)
            
        except Exception as e:
            logger.error(f"Error retrieving stats: {e}")
            return web.Response(status=500, text=str(e))
    
    async def handle_health(self, request: web.Request) -> web.Response:
        """Handle GET request for health check."""
        return web.Response(status=200, text="OK")
    
    async def handle_metrics(self, request: web.Request) -> web.Response:
        """Handle GET request for Prometheus metrics."""
        if not PROMETHEUS_AVAILABLE:
            return web.Response(
                status=501, 
                text="Prometheus client not installed. Run: pip install prometheus-client"
            )
        
        try:
            # Update metrics before serving
            self._update_cache_metrics()
            self._update_hit_ratio()
            
            # Generate Prometheus format output
            output = generate_latest()
            # Use plain content type (aiohttp doesn't like charset in content_type)
            return web.Response(
                body=output,
                content_type="text/plain; version=0.0.4"
            )
        except Exception as e:
            logger.error(f"Error generating metrics: {e}")
            return web.Response(status=500, text=str(e))
    
    def _update_cache_metrics(self) -> None:
        """Update cache size and file count metrics."""
        if not PROMETHEUS_AVAILABLE:
            return
        
        try:
            # Get cache volume (total size of cached data)
            cache_volume = self.cache.volume()
            CACHE_SIZE_BYTES.labels(node=NODE_NAME).set(cache_volume)
            
            # Get number of items in cache
            cache_count = len(self.cache)
            CACHE_FILES_COUNT.labels(node=NODE_NAME).set(cache_count)
            
            # Update disk usage
            usage = shutil.disk_usage(self.storage_path)
            DISK_USAGE_BYTES.labels(node=NODE_NAME, type='total').set(usage.total)
            DISK_USAGE_BYTES.labels(node=NODE_NAME, type='used').set(usage.used)
            DISK_USAGE_BYTES.labels(node=NODE_NAME, type='free').set(usage.free)
            
        except Exception as e:
            logger.warning(f"Failed to update cache metrics: {e}")
    
    def _update_hit_ratio(self) -> None:
        """Update cache hit ratio metric."""
        if not PROMETHEUS_AVAILABLE:
            return
        
        try:
            with self._stats_lock:
                total = self.stats_data["hits"] + self.stats_data["misses"]
                hits = self.stats_data["hits"]
            if total > 0:
                ratio = hits / total
                CACHE_HIT_RATIO.labels(node=NODE_NAME).set(ratio)
        except Exception as e:
            logger.warning(f"Failed to update hit ratio: {e}")
    
    def create_app(self) -> web.Application:
        """Create the aiohttp web application."""
        # Set max request size to 500MB to handle large tensors/checkpoints
        app = web.Application(client_max_size=500 * 1024 * 1024)
        
        # Add routes (add_get auto-registers HEAD as well)
        app.router.add_get("/get", self.handle_get)
        app.router.add_post("/set", self.handle_set)
        app.router.add_delete("/delete", self.handle_delete)
        app.router.add_post("/clear", self.handle_clear)
        app.router.add_get("/stats", self.handle_stats)
        app.router.add_get("/health", self.handle_health)
        app.router.add_get("/metrics", self.handle_metrics)
        
        return app
    
    def run(self) -> None:
        """Start the cache server."""
        app = self.create_app()
        
        # Start metrics exporter (background threads)
        self.metrics_exporter.start()
        
        # Connect to backend (if RAMJET_API_KEY is set)
        self._init_backend_connection()
        
        logger.info(f"Starting cache server on {self.host}:{self.port}")
        web.run_app(app, host=self.host, port=self.port)
    
    def close(self) -> None:
        """Clean up resources."""
        self.metrics_exporter.stop()
        
        # Disconnect from backend
        if self._backend_client:
            self._backend_client.stop()
        
        self.cache.close()
