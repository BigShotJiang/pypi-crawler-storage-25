"""
Distributed cache client implementation.

This module provides the main DistributedCache class that coordinates
caching operations across multiple cache servers using consistent hashing.
"""

import io
import logging
import pickle
from typing import Any, List, Optional, Dict
import warnings

import requests
import torch

from ramjetio.consistent_hash import ConsistentHash
from ramjetio.serialization import serialize_tensor, deserialize_tensor

logger = logging.getLogger(__name__)


class DistributedCache:
    """
    Distributed cache client with consistent hashing.
    
    Distributes cached data across multiple cache servers using consistent
    hashing for efficient load balancing and minimal key redistribution.
    
    Args:
        nodes: List of cache server addresses (e.g., ["host1:9000", "host2:9000"])
        virtual_nodes: Number of virtual nodes per physical node (default: 150)
        timeout: Request timeout in seconds (default: 30)
        retry_attempts: Number of retry attempts for failed requests (default: 3)
        compression: Enable compression for cached data (default: False)
        replication_factor: Number of replicas for each key (default: 1, no replication)
    
    Example:
        >>> cache = DistributedCache(["node1:9000", "node2:9000"])
        >>> cache.set("key1", torch.randn(10, 10))
        >>> data = cache.get("key1")
        >>> cache.delete("key1")
    """
    
    def __init__(
        self,
        nodes: List[str],
        virtual_nodes: int = 150,
        timeout: int = 30,
        retry_attempts: int = 3,
        compression: bool = False,
        replication_factor: int = 1,
    ):
        """Initialize the distributed cache client."""
        if not nodes:
            raise ValueError("At least one cache node must be provided")
        
        self.nodes = nodes
        self.timeout = timeout
        self.retry_attempts = retry_attempts
        self.compression = compression
        self.replication_factor = replication_factor
        
        # Initialize consistent hash ring
        self.hash_ring = ConsistentHash(nodes=nodes, virtual_nodes=virtual_nodes)
        
        # Persistent HTTP session for connection pooling.
        # Lazy-initialized per process for fork-safety with DataLoader workers.
        self._session: Optional[requests.Session] = None
        self._session_pid: Optional[int] = None
        self._node_count = len(nodes)
        
        logger.info(f"Initialized DistributedCache with {len(nodes)} nodes")
    
    @property
    def session(self) -> requests.Session:
        """Get or create a fork-safe requests.Session (one per process)."""
        import os
        pid = os.getpid()
        if self._session is None or self._session_pid != pid:
            self._session = requests.Session()
            adapter = requests.adapters.HTTPAdapter(
                pool_connections=self._node_count,
                pool_maxsize=self._node_count * 2,
                max_retries=0,
            )
            self._session.mount('http://', adapter)
            self._session_pid = pid
        return self._session
    
    def _get_url(self, node: str, endpoint: str) -> str:
        """Construct full URL for a cache server endpoint."""
        return f"http://{node}/{endpoint}"
    
    def _request(
        self, 
        method: str, 
        url: str, 
        data: Optional[bytes] = None,
        params: Optional[Dict[str, Any]] = None
    ) -> Optional[requests.Response]:
        """
        Make HTTP request to cache server with retries.
        
        Args:
            method: HTTP method (GET, POST, DELETE, etc.)
            url: Full URL to request
            data: Binary data to send
            params: URL parameters
            
        Returns:
            Response object, or None if all attempts fail
        """
        for attempt in range(self.retry_attempts):
            try:
                if method == "GET":
                    response = self.session.get(url, params=params, timeout=self.timeout)
                elif method == "HEAD":
                    response = self.session.head(url, params=params, timeout=self.timeout)
                elif method == "POST":
                    response = self.session.post(url, data=data, params=params, timeout=self.timeout)
                elif method == "DELETE":
                    response = self.session.delete(url, params=params, timeout=self.timeout)
                else:
                    raise ValueError(f"Unsupported HTTP method: {method}")
                
                if response.status_code == 200:
                    return response
                elif response.status_code == 404:
                    return None
                else:
                    logger.warning(f"Request failed with status {response.status_code}: {url}")
                    
            except requests.exceptions.RequestException as e:
                logger.warning(f"Request attempt {attempt + 1} failed: {e}")
                if attempt == self.retry_attempts - 1:
                    logger.error(f"All retry attempts failed for {url}")
        
        return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """
        Store a value in the distributed cache.
        
        Args:
            key: Cache key
            value: Value to cache (can be torch.Tensor or any picklable object)
            ttl: Time-to-live in seconds (optional)
            
        Returns:
            True if successful, False otherwise
        """
        # Serialize the value
        if isinstance(value, torch.Tensor):
            data = serialize_tensor(value, compress=self.compression)
        else:
            data = pickle.dumps(value)
        
        # Get target nodes (primary + replicas)
        target_nodes = self.hash_ring.get_nodes(key, self.replication_factor)
        
        if not target_nodes:
            logger.error("No nodes available for caching")
            return False
        
        success = False
        params = {"key": key}
        if ttl:
            params["ttl"] = ttl
        
        # Try to store on all replica nodes
        for node in target_nodes:
            url = self._get_url(node, "set")
            response = self._request("POST", url, data=data, params=params)
            
            if response:
                success = True
                logger.debug(f"Stored key '{key}' on node {node}")
            else:
                logger.warning(f"Failed to store key '{key}' on node {node}")
        
        return success
    
    def get(self, key: str) -> Optional[Any]:
        """
        Retrieve a value from the distributed cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value, or None if not found
        """
        # Get target nodes (try replicas if primary fails)
        target_nodes = self.hash_ring.get_nodes(key, self.replication_factor)
        
        if not target_nodes:
            logger.error("No nodes available for cache lookup")
            return None
        
        # Try each replica node until we find the data
        for node in target_nodes:
            url = self._get_url(node, "get")
            response = self._request("GET", url, params={"key": key})
            
            if response and response.content:
                try:
                    # Try to deserialize as tensor first
                    value = deserialize_tensor(response.content)
                    logger.debug(f"Retrieved key '{key}' from node {node}")
                    return value
                except Exception:
                    # Fall back to pickle
                    try:
                        value = pickle.loads(response.content)
                        logger.debug(f"Retrieved key '{key}' from node {node}")
                        return value
                    except Exception as e:
                        logger.error(f"Failed to deserialize value: {e}")
        
        logger.debug(f"Key '{key}' not found in cache")
        return None
    
    def delete(self, key: str) -> bool:
        """
        Delete a value from the distributed cache.
        
        Args:
            key: Cache key
            
        Returns:
            True if successful, False otherwise
        """
        # Get target nodes (delete from all replicas)
        target_nodes = self.hash_ring.get_nodes(key, self.replication_factor)
        
        if not target_nodes:
            logger.error("No nodes available for cache deletion")
            return False
        
        success = False
        
        for node in target_nodes:
            url = self._get_url(node, "delete")
            response = self._request("DELETE", url, params={"key": key})
            
            if response:
                success = True
                logger.debug(f"Deleted key '{key}' from node {node}")
        
        return success
    
    def exists(self, key: str) -> bool:
        """
        Check if a key exists in the cache using a lightweight HEAD request.
        
        Args:
            key: Cache key
            
        Returns:
            True if key exists, False otherwise
        """
        nodes = self.hash_ring.get_nodes(key, count=self.replication_factor)
        
        for node in nodes:
            url = self._get_url(node, "get")
            response = self._request("HEAD", url, params={"key": key})
            if response is not None:
                return True
        
        return False
    
    def clear(self) -> bool:
        """
        Clear all data from all cache nodes.
        
        Warning: This operation clears ALL data from the cache cluster.
        
        Returns:
            True if successful on all nodes, False otherwise
        """
        success = True
        
        for node in self.hash_ring.get_all_nodes():
            url = self._get_url(node, "clear")
            response = self._request("POST", url)
            
            if response:
                logger.info(f"Cleared cache on node {node}")
            else:
                logger.error(f"Failed to clear cache on node {node}")
                success = False
        
        return success
    
    def stats(self) -> Dict[str, Any]:
        """
        Get statistics from all cache nodes.
        
        Returns:
            Dictionary with statistics from each node
        """
        stats = {}
        
        for node in self.hash_ring.get_all_nodes():
            url = self._get_url(node, "stats")
            response = self._request("GET", url)
            
            if response:
                try:
                    stats[node] = response.json()
                except Exception as e:
                    logger.error(f"Failed to parse stats from node {node}: {e}")
                    stats[node] = {"error": str(e)}
            else:
                stats[node] = {"error": "Failed to retrieve stats"}
        
        return stats
    
    def add_node(self, node: str) -> None:
        """
        Add a new cache node to the cluster.
        
        Args:
            node: Node address (e.g., "host:port")
        """
        self.hash_ring.add_node(node)
        self.nodes.append(node)
        logger.info(f"Added node {node} to cache cluster")
    
    def remove_node(self, node: str) -> None:
        """
        Remove a cache node from the cluster.
        
        Args:
            node: Node address to remove
        """
        self.hash_ring.remove_node(node)
        if node in self.nodes:
            self.nodes.remove(node)
        logger.info(f"Removed node {node} from cache cluster")
    
    def close(self) -> None:
        """Close the HTTP session and release connection pool resources."""
        if self._session:
            self._session.close()
        logger.info("DistributedCache session closed")

    def __repr__(self) -> str:
        """String representation of the cache."""
        return f"DistributedCache(nodes={len(self.nodes)}, replication={self.replication_factor})"
