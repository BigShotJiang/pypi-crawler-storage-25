#!/usr/bin/env python
"""
Command-line interface for cache server.

Start a distributed cache server node.
"""

import argparse
import logging
import sys

from ramjetio.server import CacheServer


def parse_size(size_str: str) -> int:
    """
    Parse size string with units (e.g., "10GB", "1TB").
    
    Args:
        size_str: Size string with optional unit suffix
        
    Returns:
        Size in bytes
    """
    # Check units from largest to smallest to avoid substring issues
    units = [
        ("PB", 1024 ** 5),
        ("TB", 1024 ** 4),
        ("GB", 1024 ** 3),
        ("MB", 1024 ** 2),
        ("KB", 1024),
        ("B", 1),
    ]
    
    size_str = size_str.upper().strip()
    
    for unit, multiplier in units:
        if size_str.endswith(unit):
            number = float(size_str[:-len(unit)])
            return int(number * multiplier)
    
    # No unit, assume bytes
    return int(size_str)


def main():
    """Main entry point for cache server CLI."""
    parser = argparse.ArgumentParser(
        description="RAMJET Distributed Cache Server",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    
    parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Server host address",
    )
    
    parser.add_argument(
        "--port",
        type=int,
        default=9000,
        help="Server port",
    )
    
    parser.add_argument(
        "--storage-path",
        type=str,
        default="/tmp/ramjet_cache",
        help="Path to disk storage directory",
    )
    
    parser.add_argument(
        "--capacity",
        type=str,
        default="0",
        help="Maximum storage capacity (e.g., 10GB, 1TB). Default: auto (80%% of available disk)",
    )
    
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Logging level",
    )
    
    # Metrics options
    parser.add_argument(
        "--metrics-file",
        type=str,
        default=None,
        help="Path to write metrics file (Prometheus format). Default: /tmp/ramjet_metrics_<port>.prom",
    )
    
    parser.add_argument(
        "--metrics-push-url",
        type=str,
        default=None,
        help="URL to push metrics (Prometheus Pushgateway or grpc://host:port). Can also use RAMJET_METRICS_PUSH_URL env var.",
    )
    
    parser.add_argument(
        "--metrics-push-interval",
        type=float,
        default=2.0,
        help="Interval in seconds between metric pushes to remote server",
    )
    
    args = parser.parse_args()
    
    # Configure logging
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    
    # Parse capacity
    try:
        capacity = parse_size(args.capacity)
    except ValueError as e:
        print(f"Error: Invalid capacity format: {args.capacity}", file=sys.stderr)
        sys.exit(1)
    
    # Create and start server
    server = None
    try:
        server = CacheServer(
            host=args.host,
            port=args.port,
            storage_path=args.storage_path,
            max_capacity=capacity,
            metrics_file=args.metrics_file,
            metrics_push_url=args.metrics_push_url,
            metrics_push_interval=args.metrics_push_interval,
        )
        
        print(f"Starting RAMJET cache server on {args.host}:{args.port}")
        print(f"Storage path: {args.storage_path}")
        print(f"Max capacity: {args.capacity} ({capacity:,} bytes)")
        if args.metrics_push_url:
            print(f"Metrics push: {args.metrics_push_url} (every {args.metrics_push_interval}s)")
        print("Press Ctrl+C to stop the server")
        
        server.run()
        
    except KeyboardInterrupt:
        print("\nShutting down server...")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        if server:
            server.close()
            print("Server stopped.")


if __name__ == "__main__":
    main()
