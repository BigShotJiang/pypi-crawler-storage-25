#!/usr/bin/env python
"""
Command-line interface for cache client.

Interact with distributed cache from command line.
"""

import argparse
import json
import logging
import sys

from ramjetio.cache import DistributedCache


def main():
    """Main entry point for cache client CLI."""
    parser = argparse.ArgumentParser(
        description="RAMJET Distributed Cache Client",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    
    parser.add_argument(
        "--nodes",
        type=str,
        required=True,
        help="Comma-separated list of cache nodes (e.g., node1:9000,node2:9000)",
    )
    
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help="Logging level",
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Set command
    set_parser = subparsers.add_parser("set", help="Store a value in cache")
    set_parser.add_argument("key", type=str, help="Cache key")
    set_parser.add_argument("value", type=str, help="Value to store")
    set_parser.add_argument("--ttl", type=int, help="Time-to-live in seconds")
    
    # Get command
    get_parser = subparsers.add_parser("get", help="Retrieve a value from cache")
    get_parser.add_argument("key", type=str, help="Cache key")
    
    # Delete command
    delete_parser = subparsers.add_parser("delete", help="Delete a value from cache")
    delete_parser.add_argument("key", type=str, help="Cache key")
    
    # Exists command
    exists_parser = subparsers.add_parser("exists", help="Check if a key exists")
    exists_parser.add_argument("key", type=str, help="Cache key")
    
    # Stats command
    subparsers.add_parser("stats", help="Get cache statistics")
    
    # Clear command
    subparsers.add_parser("clear", help="Clear all cache data")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Configure logging
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )
    
    # Parse nodes
    nodes = [node.strip() for node in args.nodes.split(",")]
    
    # Create cache client
    try:
        cache = DistributedCache(nodes=nodes)
    except Exception as e:
        print(f"Error: Failed to initialize cache: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Execute command
    try:
        if args.command == "set":
            success = cache.set(args.key, args.value, ttl=args.ttl)
            if success:
                print(f"Successfully stored key '{args.key}'")
            else:
                print(f"Failed to store key '{args.key}'", file=sys.stderr)
                sys.exit(1)
        
        elif args.command == "get":
            value = cache.get(args.key)
            if value is not None:
                print(value)
            else:
                print(f"Key '{args.key}' not found", file=sys.stderr)
                sys.exit(1)
        
        elif args.command == "delete":
            success = cache.delete(args.key)
            if success:
                print(f"Successfully deleted key '{args.key}'")
            else:
                print(f"Failed to delete key '{args.key}'", file=sys.stderr)
                sys.exit(1)
        
        elif args.command == "exists":
            exists = cache.exists(args.key)
            print("yes" if exists else "no")
            sys.exit(0 if exists else 1)
        
        elif args.command == "stats":
            stats = cache.stats()
            print(json.dumps(stats, indent=2))
        
        elif args.command == "clear":
            success = cache.clear()
            if success:
                print("Successfully cleared all cache data")
            else:
                print("Failed to clear cache data", file=sys.stderr)
                sys.exit(1)
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
