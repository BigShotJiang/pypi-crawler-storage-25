"""
Serialization utilities for PyTorch tensors and other objects.

This module provides efficient serialization/deserialization for PyTorch
tensors, with optional compression support.
"""

import io
import pickle
import gzip
from typing import Any

import torch


def serialize_tensor(tensor: torch.Tensor, compress: bool = False) -> bytes:
    """
    Serialize a PyTorch tensor to bytes.
    
    Args:
        tensor: PyTorch tensor to serialize
        compress: Whether to compress the serialized data
        
    Returns:
        Serialized tensor as bytes
    """
    buffer = io.BytesIO()
    torch.save(tensor, buffer)
    data = buffer.getvalue()
    
    if compress:
        data = gzip.compress(data)
    
    return data


def deserialize_tensor(data: bytes) -> torch.Tensor:
    """
    Deserialize bytes to a PyTorch tensor.
    
    Automatically detects and decompresses gzip-compressed data.
    Uses weights_only=True for security — no unsafe deserialization
    is allowed in a distributed cache context.
    
    Args:
        data: Serialized tensor bytes
        
    Returns:
        Deserialized PyTorch tensor
        
    Raises:
        RuntimeError: If deserialization fails with weights_only=True
    """
    # Try to decompress if data is gzip-compressed
    try:
        data = gzip.decompress(data)
    except (gzip.BadGzipFile, OSError):
        # Not compressed, use as is
        pass
    
    buffer = io.BytesIO(data)
    # Always use weights_only=True — weights_only=False is an RCE vector
    # in a distributed cache where any node can write data.
    return torch.load(buffer, weights_only=True)


def serialize_object(obj: Any, compress: bool = False) -> bytes:
    """
    Serialize a Python object to bytes using pickle.
    
    Args:
        obj: Python object to serialize
        compress: Whether to compress the serialized data
        
    Returns:
        Serialized object as bytes
    """
    data = pickle.dumps(obj)
    
    if compress:
        data = gzip.compress(data)
    
    return data


def deserialize_object(data: bytes) -> Any:
    """
    Deserialize bytes to a Python object using pickle.
    
    Automatically detects and decompresses gzip-compressed data.
    
    Args:
        data: Serialized object bytes
        
    Returns:
        Deserialized Python object
    """
    # Try to decompress if data is gzip-compressed
    try:
        data = gzip.decompress(data)
    except (gzip.BadGzipFile, OSError):
        # Not compressed, use as is
        pass
    
    obj = pickle.loads(data)
    
    return obj
