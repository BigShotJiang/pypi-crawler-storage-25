"""
RAMJET Protocol Buffer definitions.

Auto-generates Python code from ramjet.proto on first import.
This ensures compatibility with the user's installed protobuf version.
"""

import os
import sys
import logging

logger = logging.getLogger(__name__)

_PROTO_DIR = os.path.dirname(os.path.abspath(__file__))
_PROTO_FILE = os.path.join(_PROTO_DIR, "ramjet.proto")
_PB2_FILE = os.path.join(_PROTO_DIR, "ramjet_pb2.py")
_GRPC_FILE = os.path.join(_PROTO_DIR, "ramjet_pb2_grpc.py")


def _generate_proto_files():
    """Generate pb2 files from .proto file using grpc_tools."""
    try:
        from grpc_tools import protoc
        
        # Generate protobuf and grpc files
        result = protoc.main([
            'grpc_tools.protoc',
            f'-I{_PROTO_DIR}',
            f'--python_out={_PROTO_DIR}',
            f'--grpc_python_out={_PROTO_DIR}',
            _PROTO_FILE,
        ])
        
        if result != 0:
            logger.warning(f"protoc returned non-zero exit code: {result}")
            return False
        
        # Fix import in grpc file (change "import ramjet_pb2" to "from ramjetio.proto import ramjet_pb2")
        if os.path.exists(_GRPC_FILE):
            with open(_GRPC_FILE, 'r') as f:
                content = f.read()
            content = content.replace(
                'import ramjet_pb2 as ramjet__pb2',
                'from ramjetio.proto import ramjet_pb2 as ramjet__pb2'
            )
            with open(_GRPC_FILE, 'w') as f:
                f.write(content)
        
        logger.debug("Proto files generated successfully")
        return True
        
    except ImportError:
        logger.debug("grpc_tools not installed, cannot generate proto files")
        return False
    except Exception as e:
        logger.warning(f"Failed to generate proto files: {e}")
        return False


def _try_import():
    """Try to import generated proto files."""
    try:
        from ramjetio.proto import ramjet_pb2, ramjet_pb2_grpc
        return ramjet_pb2, ramjet_pb2_grpc
    except (ImportError, TypeError) as e:
        # TypeError: "Couldn't parse file content!" - protobuf version mismatch
        return None, None


def _load_proto():
    """Load proto files, regenerating if necessary."""
    # First try to import existing files
    pb2, grpc = _try_import()
    if pb2 is not None:
        return pb2, grpc
    
    # If import failed, try to regenerate
    logger.debug("Proto import failed, attempting to regenerate...")
    
    if not os.path.exists(_PROTO_FILE):
        logger.warning(f"Proto file not found: {_PROTO_FILE}")
        return None, None
    
    # Remove old generated files to force regeneration
    for f in [_PB2_FILE, _GRPC_FILE]:
        if os.path.exists(f):
            try:
                os.remove(f)
            except:
                pass
    
    # Clear any cached imports
    for mod_name in list(sys.modules.keys()):
        if 'ramjet_pb2' in mod_name:
            del sys.modules[mod_name]
    
    # Generate new files
    if not _generate_proto_files():
        return None, None
    
    # Try import again
    return _try_import()


# Auto-load on import
ramjet_pb2, ramjet_pb2_grpc = _load_proto()

# Export for convenience
if ramjet_pb2 is not None:
    # Re-export all message types
    from ramjetio.proto.ramjet_pb2 import *
    from ramjetio.proto.ramjet_pb2_grpc import *
