"""
RAMJET Framework Integrations

Auto-detects and hooks into popular ML frameworks to report
training progress to the RAMJET dashboard automatically.

Supported frameworks:
- ultralytics (YOLO): auto-hooks on_train_batch_end, on_train_epoch_end, etc.
- (future) HuggingFace Transformers: TrainerCallback
- (future) PyTorch Lightning: Callback
"""

import logging

logger = logging.getLogger(__name__)


def detect_frameworks():
    """Detect which ML frameworks are available."""
    available = {}

    try:
        import ultralytics
        available['ultralytics'] = ultralytics.__version__
    except ImportError:
        pass

    try:
        import transformers
        available['transformers'] = transformers.__version__
    except ImportError:
        pass

    try:
        import lightning
        available['lightning'] = lightning.__version__
    except ImportError:
        try:
            import pytorch_lightning
            available['pytorch_lightning'] = pytorch_lightning.__version__
        except ImportError:
            pass

    return available


def attach(model):
    """
    Auto-detect framework from model type and attach progress hooks.

    Args:
        model: A model instance (e.g., ultralytics.YOLO)

    Returns:
        True if hooks were attached, False otherwise.
    """
    # Ultralytics YOLO
    try:
        from ultralytics import YOLO
        if isinstance(model, YOLO):
            from ramjetio.integrations.ultralytics import attach as attach_ultralytics
            attach_ultralytics(model)
            return True
    except ImportError:
        pass

    logger.warning(f"No integration available for model type: {type(model).__name__}")
    return False
