"""
Universal Dataset for RAMJET

Supports multiple data sources and formats:

Data Sources:
- S3/MinIO: Object storage with AWS-compatible API
- HTTP/HTTPS: Web URLs with optional auth
- Local: Filesystem paths (NFS, CIFS, local SSD)

Formats:
  Vision:
  - YOLO: All tasks (detect, segment, pose, obb, classify)
  - COCO: Detection/segmentation (images/ + annotations.json)  
  - ImageFolder: Classification (class_name/image.jpg)
  - SemanticSeg: Semantic segmentation (images/ + masks/)
  
  NLP:
  - Text: Classification, NER, Seq2Seq (CSV/JSONL/JSON)
  
  Tabular:
  - Tabular: Regression/classification (CSV/Parquet)

Data source is configured via RAMJET dashboard, not hardcoded.
"""

import io
import os
import json
import logging
from pathlib import Path
from typing import Optional, List, Dict, Any, Callable, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset

logger = logging.getLogger(__name__)

# RAMJET integration
try:
    import ramjetio
    RAMJET_AVAILABLE = True
except ImportError:
    RAMJET_AVAILABLE = False

# Image processing
try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False
    
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# S3 client
try:
    import boto3
    from botocore.client import Config
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

# HTTP
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


# =============================================================================
# Data Source Clients
# =============================================================================

class S3Client:
    """S3/MinIO client for fetching data."""
    
    def __init__(self, config: Dict[str, Any]):
        if not BOTO3_AVAILABLE:
            raise ImportError("boto3 required for S3. Run: pip install boto3")
        
        endpoint = config.get('s3_endpoint', '')
        use_ssl = config.get('s3_use_ssl', True)
        
        # Handle endpoint URL
        if not endpoint.startswith(('http://', 'https://')):
            endpoint_url = f"{'https' if use_ssl else 'http'}://{endpoint}"
        else:
            endpoint_url = endpoint
        
        self.bucket = config.get('s3_bucket', '')
        self.prefix = config.get('prefix', '')
        
        self.client = boto3.client(
            's3',
            endpoint_url=endpoint_url,
            aws_access_key_id=config.get('s3_access_key', ''),
            aws_secret_access_key=config.get('s3_secret_key', ''),
            config=Config(
                signature_version='s3v4',
                s3={'addressing_style': 'path' if config.get('s3_path_style') else 'virtual'}
            ),
            region_name=config.get('s3_region') or 'us-east-1',
        )
        
        logger.info(f"S3Client initialized: {endpoint_url}/{self.bucket}")
    
    def list_files(self, prefix: str = '', suffix: str = '') -> List[str]:
        """List files in bucket with optional prefix and suffix filter."""
        full_prefix = f"{self.prefix}{prefix}" if self.prefix else prefix
        
        files = []
        paginator = self.client.get_paginator('list_objects_v2')
        
        for page in paginator.paginate(Bucket=self.bucket, Prefix=full_prefix):
            if 'Contents' in page:
                for obj in page['Contents']:
                    key = obj['Key']
                    if not suffix or key.lower().endswith(suffix):
                        files.append(key)
        
        return files
    
    def get_bytes(self, key: str) -> bytes:
        """Get file content as bytes. Auto-prepends prefix if key doesn't already include it."""
        if self.prefix and not key.startswith(self.prefix):
            full_key = f"{self.prefix}{key}"
        else:
            full_key = key
        response = self.client.get_object(Bucket=self.bucket, Key=full_key)
        return response['Body'].read()
    
    def get_text(self, key: str) -> str:
        """Get file content as text."""
        return self.get_bytes(key).decode('utf-8')


class HTTPClient:
    """HTTP client for fetching data from URLs."""
    
    def __init__(self, config: Dict[str, Any]):
        if not REQUESTS_AVAILABLE:
            raise ImportError("requests required for HTTP. Run: pip install requests")
        
        self.base_url = config.get('http_url', '').rstrip('/')
        self.prefix = config.get('prefix', '')
        self.headers = {}
        
        auth_header = config.get('http_auth_header', '')
        if auth_header:
            self.headers['Authorization'] = auth_header
        
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
        logger.info(f"HTTPClient initialized: {self.base_url}")
    
    def get_bytes(self, path: str) -> bytes:
        """Get file content as bytes."""
        url = f"{self.base_url}/{self.prefix}{path}" if self.prefix else f"{self.base_url}/{path}"
        response = self.session.get(url, timeout=30)
        response.raise_for_status()
        return response.content
    
    def get_text(self, path: str) -> str:
        """Get file content as text."""
        return self.get_bytes(path).decode('utf-8')
    
    def get_json(self, path: str) -> Any:
        """Get JSON file content."""
        return json.loads(self.get_text(path))


class LocalClient:
    """Local filesystem client."""
    
    def __init__(self, config: Dict[str, Any]):
        self.base_path = Path(config.get('local_path', ''))
        self.prefix = config.get('prefix', '')
        
        if self.prefix:
            self.base_path = self.base_path / self.prefix
        
        logger.info(f"LocalClient initialized: {self.base_path}")
    
    def list_files(self, prefix: str = '', suffix: str = '') -> List[str]:
        """List files with optional prefix and suffix filter."""
        search_path = self.base_path / prefix
        
        if not search_path.exists():
            return []
        
        files = []
        for f in search_path.rglob('*'):
            if f.is_file():
                if not suffix or f.suffix.lower() in suffix:
                    files.append(str(f.relative_to(self.base_path)))
        
        return files
    
    def get_bytes(self, path: str) -> bytes:
        """Get file content as bytes."""
        return (self.base_path / path).read_bytes()
    
    def get_text(self, path: str) -> str:
        """Get file content as text."""
        return (self.base_path / path).read_text()


# =============================================================================
# Dataset Formats
# =============================================================================

class YOLOFormat:
    """
    YOLO format - supports all YOLO tasks.
    
    Tasks detected automatically by label format:
        - detect: class x y w h (5 values)
        - segment: class x y w h p1x p1y p2x p2y ... (5 + polygon pairs)
        - pose: class x y w h kp1x kp1y kp1v ... (5 + keypoint triplets)
        - obb: class x1 y1 x2 y2 x3 y3 x4 y4 (9 values, oriented bbox)
        - classify: folder structure only (no labels file)
    
    Expected structure:
        {prefix}/data.yaml (optional, contains class names)
        {prefix}/{split}/images/*.jpg
        {prefix}/{split}/labels/*.txt
    
    data.yaml format:
        names:
          0: person
          1: car
          ...  
        # or
        names: ['person', 'car', ...]
        
        # optional task hint
        task: detect  # detect, segment, pose, obb, classify
        
        # for pose: keypoint names
        kpt_shape: [17, 3]  # 17 keypoints, 3 values each (x, y, visibility)
    
    Label format per task:
        detect:   class_id x_center y_center width height
        segment:  class_id x y w h polygon_x1 polygon_y1 polygon_x2 ...
        pose:     class_id x y w h kp1_x kp1_y kp1_vis kp2_x kp2_y kp2_vis ...
        obb:      class_id x1 y1 x2 y2 x3 y3 x4 y4
    """
    
    def __init__(self, client, split: str = None):
        self.client = client
        self.split = split
        self.task = 'detect'  # Default task
        self.kpt_shape = None  # For pose: [num_keypoints, values_per_kpt]
        self.class_names = {}
        self._load_config()
    
    def _load_config(self):
        """Load config from data.yaml including class names and task."""
        yaml_paths = ['data.yaml', 'dataset.yaml', 'config.yaml']
        
        for yaml_path in yaml_paths:
            try:
                yaml_text = self.client.get_text(yaml_path)
                self._parse_yaml(yaml_text)
                if self.class_names:
                    logger.info(f"Loaded config from {yaml_path}: task={self.task}, {len(self.class_names)} classes")
                    return
            except:
                continue
        
        logger.warning("No data.yaml found, using defaults")
    
    def _parse_yaml(self, yaml_text: str):
        """Parse YAML config without pyyaml dependency."""
        lines = yaml_text.split('\n')
        
        for line in lines:
            line = line.strip()
            
            # Parse task
            if line.startswith('task:'):
                self.task = line.split(':', 1)[1].strip().strip("'\"")
            
            # Parse kpt_shape
            if line.startswith('kpt_shape:'):
                # kpt_shape: [17, 3]
                if '[' in line:
                    list_str = line.split('[', 1)[1].rsplit(']', 1)[0]
                    parts = [int(x.strip()) for x in list_str.split(',')]
                    if len(parts) == 2:
                        self.kpt_shape = parts
        
        # Parse class names
        self.class_names = self._parse_names_from_yaml(yaml_text)
    
    def _parse_names_from_yaml(self, yaml_text: str) -> Dict[int, str]:
        """Parse names section from YAML without pyyaml."""
        names = {}
        in_names = False
        
        for line in yaml_text.split('\n'):
            line = line.rstrip()
            
            # Check for names section
            if line.startswith('names:'):
                in_names = True
                # Check for inline list: names: ['a', 'b']
                if '[' in line:
                    list_str = line.split('[', 1)[1].rsplit(']', 1)[0]
                    items = [s.strip().strip("'\"") for s in list_str.split(',')]
                    return {i: name for i, name in enumerate(items) if name}
                continue
            
            if in_names:
                # Stop at next top-level key
                if line and not line.startswith(' ') and not line.startswith('\t'):
                    break
                
                # Parse "  0: person" or "  - person"
                stripped = line.strip()
                if ':' in stripped:
                    # Format: 0: person
                    parts = stripped.split(':', 1)
                    try:
                        idx = int(parts[0].strip())
                        name = parts[1].strip().strip("'\"")
                        names[idx] = name
                    except ValueError:
                        pass
                elif stripped.startswith('- '):
                    # Format: - person (list style)
                    name = stripped[2:].strip().strip("'\"")
                    names[len(names)] = name
        
        return names
    
    def scan_images(self) -> List[str]:
        """Scan for images."""
        return self._scan_images_static(self.client, self.split)
    
    @staticmethod
    def _scan_images_static(client, split: str) -> List[str]:
        """Scan for images."""
        if hasattr(client, 'list_files'):
            image_dir = f"{split}/images/"
            files = client.list_files(prefix=image_dir)
            # Filter to images only
            return [f for f in files if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp'))]
        return []
    
    def get_class_name(self, class_id: int) -> str:
        """Get class name by ID."""
        return self.class_names.get(class_id, f"class_{class_id}")
    
    @property
    def num_classes(self) -> int:
        """Get number of classes."""
        if self.class_names:
            return max(self.class_names.keys()) + 1
        return 0
    
    @staticmethod
    def get_label_path(image_path: str) -> str:
        """Convert image path to label path."""
        # images/xxx.jpg -> labels/xxx.txt
        return image_path.replace('/images/', '/labels/').rsplit('.', 1)[0] + '.txt'
    
    def parse_labels(self, label_text: str) -> Dict[str, Any]:
        """
        Parse YOLO label file (any task).
        
        Returns dict with:
            - 'boxes': np.ndarray (N, 4) [x, y, w, h] normalized
            - 'classes': np.ndarray (N,) class indices
            - 'segments': list of np.ndarray polygon points (for segment task)
            - 'keypoints': np.ndarray (N, K, 3) keypoints (for pose task)
            - 'obb': np.ndarray (N, 8) oriented bbox corners (for obb task)
        """
        result = {
            'boxes': [],
            'classes': [],
            'segments': [],
            'keypoints': [],
            'obb': [],
        }
        
        for line in label_text.strip().split('\n'):
            if not line.strip():
                continue
            
            parts = line.strip().split()
            if not parts:
                continue
            
            class_id = int(parts[0])
            result['classes'].append(class_id)
            values = list(map(float, parts[1:]))
            
            # Detect task based on value count and task hint
            n_values = len(values)
            task = self.task
            
            if n_values == 4:
                # Detection: x, y, w, h
                result['boxes'].append(values[:4])
                
            elif n_values == 8 and task == 'obb':
                # OBB: x1 y1 x2 y2 x3 y3 x4 y4 (4 corner points)
                result['boxes'].append(self._obb_to_xywh(values))
                result['obb'].append(values)
                
            elif n_values >= 6 and n_values % 2 == 0 and task in ('segment', 'auto'):
                # Segmentation: polygon points only (no bbox)
                # Format: class x1 y1 x2 y2 x3 y3 ...
                polygon = np.array(values).reshape(-1, 2)
                result['segments'].append(polygon)
                # Calculate bounding box from polygon
                x_coords = polygon[:, 0]
                y_coords = polygon[:, 1]
                x_min, x_max = x_coords.min(), x_coords.max()
                y_min, y_max = y_coords.min(), y_coords.max()
                x_center = (x_min + x_max) / 2
                y_center = (y_min + y_max) / 2
                width = x_max - x_min
                height = y_max - y_min
                result['boxes'].append([x_center, y_center, width, height])
                
            elif n_values > 4 and self.kpt_shape:
                # Pose: bbox + keypoints
                # Format: class x y w h kp1_x kp1_y kp1_vis ...
                bbox = values[:4]
                extra = values[4:]
                result['boxes'].append(bbox)
                
                n_kpts = self.kpt_shape[0]
                kpt_dim = self.kpt_shape[1] if len(self.kpt_shape) > 1 else 3
                expected = n_kpts * kpt_dim
                
                if len(extra) >= expected:
                    kpts = np.array(extra[:expected]).reshape(n_kpts, kpt_dim)
                    result['keypoints'].append(kpts)
                else:
                    # Pad with zeros
                    result['keypoints'].append(np.zeros((n_kpts, kpt_dim), dtype=np.float32))
                    
            elif n_values > 4:
                # Unknown extra data, treat as detection with extra ignored
                result['boxes'].append(values[:4])
            else:
                # Not enough values, skip
                result['classes'].pop()  # Remove the class we added
                continue
        
        # Convert to numpy arrays
        n = len(result['classes'])
        
        if result['boxes']:
            result['boxes'] = np.array(result['boxes'], dtype=np.float32)
        else:
            result['boxes'] = np.zeros((0, 4), dtype=np.float32)
        
        result['classes'] = np.array(result['classes'], dtype=np.int64) if result['classes'] else np.array([], dtype=np.int64)
        
        if result['keypoints']:
            result['keypoints'] = np.array(result['keypoints'], dtype=np.float32)
        
        if result['obb']:
            result['obb'] = np.array(result['obb'], dtype=np.float32)
        
        return result
    
    @staticmethod
    def _obb_to_xywh(obb: List[float]) -> List[float]:
        """Convert OBB corners to xywh bbox."""
        # obb = [x1, y1, x2, y2, x3, y3, x4, y4]
        xs = [obb[i] for i in range(0, 8, 2)]
        ys = [obb[i] for i in range(1, 8, 2)]
        x_center = sum(xs) / 4
        y_center = sum(ys) / 4
        width = max(xs) - min(xs)
        height = max(ys) - min(ys)
        return [x_center, y_center, width, height]
    
    @staticmethod
    def parse_labels_simple(label_text: str) -> np.ndarray:
        """
        Parse YOLO detection labels (simple format).
        
        Returns:
            np.ndarray of shape (N, 5) with [class_id, x, y, w, h]
        """
        labels = []
        for line in label_text.strip().split('\n'):
            if line.strip():
                parts = line.strip().split()
                if len(parts) >= 5:
                    class_id = int(parts[0])
                    x, y, w, h = map(float, parts[1:5])
                    labels.append([class_id, x, y, w, h])
        
        if labels:
            return np.array(labels, dtype=np.float32)
        return np.zeros((0, 5), dtype=np.float32)


class ImageFolderFormat:
    """
    ImageFolder classification format.
    
    Expected structure:
        {prefix}/{split}/{class_name}/*.jpg
    """
    
    def __init__(self, client, split: str):
        self.client = client
        self.split = split
        self.class_names = {}  # Will be populated during scan
    
    def scan_images(self) -> List[Tuple[str, int]]:
        """Scan for images with class labels."""
        result, self.class_names = self._scan_images_static(self.client, self.split)
        return result
    
    def get_class_name(self, class_id: int) -> str:
        """Get class name by ID."""
        return self.class_names.get(class_id, f"class_{class_id}")
    
    @property
    def num_classes(self) -> int:
        """Get number of classes."""
        return len(self.class_names)
    
    @staticmethod
    def _scan_images_static(client, split: str) -> Tuple[List[Tuple[str, int]], Dict[int, str]]:
        """Scan for images with class labels. Returns (samples, idx_to_class)."""
        if hasattr(client, 'list_files'):
            files = client.list_files(prefix=f"{split}/")
            
            # Group by class (folder name)
            class_name_set = set()
            for f in files:
                if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                    # split/class_name/image.jpg
                    parts = f.split('/')
                    if len(parts) >= 2:
                        class_name_set.add(parts[1])
            
            # Sort classes for consistent indices
            sorted_classes = sorted(class_name_set)
            class_to_idx = {name: idx for idx, name in enumerate(sorted_classes)}
            idx_to_class = {idx: name for idx, name in enumerate(sorted_classes)}
            
            # Build list of (path, class_idx)
            result = []
            for f in files:
                if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                    parts = f.split('/')
                    if len(parts) >= 2:
                        class_name = parts[1]
                        result.append((f, class_to_idx[class_name]))
            
            return result, idx_to_class
        return [], {}


class COCOFormat:
    """
    COCO detection/segmentation format.
    
    Expected structure:
        {prefix}/{split}/images/*.jpg
        {prefix}/{split}/annotations.json (or instances_{split}.json)
    
    JSON format:
        {
            "images": [{"id": 1, "file_name": "xxx.jpg", "width": 640, "height": 480}, ...],
            "annotations": [{"id": 1, "image_id": 1, "category_id": 1, "bbox": [x, y, w, h], ...}, ...],
            "categories": [{"id": 1, "name": "cat"}, ...]
        }
    """
    
    def __init__(self, client, split: str):
        self.client = client
        self.split = split
        self.annotations = None
        self.images = {}
        self.image_to_anns = {}
        self._load_annotations()
    
    def _load_annotations(self):
        """Load COCO annotations JSON."""
        # Try different annotation file locations
        annotation_files = [
            f"{self.split}/annotations.json",
            f"annotations/instances_{self.split}.json",
            f"annotations/{self.split}.json",
        ]
        
        for ann_file in annotation_files:
            try:
                ann_text = self.client.get_text(ann_file)
                self.annotations = json.loads(ann_text)
                logger.info(f"Loaded COCO annotations from {ann_file}")
                break
            except:
                continue
        
        if not self.annotations:
            raise ValueError(f"Could not find COCO annotations for split '{self.split}'")
        
        # Index images by ID
        for img in self.annotations.get('images', []):
            self.images[img['id']] = img
        
        # Group annotations by image_id
        for ann in self.annotations.get('annotations', []):
            img_id = ann['image_id']
            if img_id not in self.image_to_anns:
                self.image_to_anns[img_id] = []
            self.image_to_anns[img_id].append(ann)
        
        logger.info(f"COCO: {len(self.images)} images, {len(self.annotations.get('annotations', []))} annotations")
        
        # Build class names from categories
        self.class_names = {}
        for cat in self.annotations.get('categories', []):
            self.class_names[cat['id']] = cat['name']
        
        logger.info(f"COCO: {len(self.class_names)} categories")
    
    def get_class_name(self, class_id: int) -> str:
        """Get class name by ID."""
        return self.class_names.get(class_id, f"class_{class_id}")
    
    @property
    def num_classes(self) -> int:
        """Get number of classes."""
        if self.class_names:
            return max(self.class_names.keys()) + 1
        return 0
    
    def get_image_ids(self) -> List[int]:
        """Get list of image IDs."""
        return list(self.images.keys())
    
    def get_image_path(self, image_id: int) -> str:
        """Get image file path."""
        img_info = self.images[image_id]
        return f"{self.split}/images/{img_info['file_name']}"
    
    def get_annotations(self, image_id: int) -> np.ndarray:
        """
        Get annotations for image.
        
        Returns:
            np.ndarray of shape (N, 5) with [class_id, x_center, y_center, width, height]
            Normalized to 0-1 (YOLO format) for compatibility
        """
        anns = self.image_to_anns.get(image_id, [])
        img_info = self.images[image_id]
        img_w, img_h = img_info['width'], img_info['height']
        
        labels = []
        for ann in anns:
            if 'bbox' in ann:
                # COCO bbox is [x, y, width, height] (top-left)
                x, y, w, h = ann['bbox']
                # Convert to YOLO format (center, normalized)
                x_center = (x + w / 2) / img_w
                y_center = (y + h / 2) / img_h
                w_norm = w / img_w
                h_norm = h / img_h
                class_id = ann.get('category_id', 0)
                labels.append([class_id, x_center, y_center, w_norm, h_norm])
        
        if labels:
            return np.array(labels, dtype=np.float32)
        return np.zeros((0, 5), dtype=np.float32)


class SemanticSegFormat:
    """
    Semantic Segmentation format.
    
    Expected structure:
        {prefix}/{split}/images/*.jpg
        {prefix}/{split}/masks/*.png (or labels/*.png)
    
    Mask format:
        - PNG with pixel values = class indices (0-255)
        - Or RGB where each color maps to a class
    
    Optional config (data.yaml):
        names:
          0: background
          1: road
          2: building
        palette:  # RGB colors for visualization
          0: [0, 0, 0]
          1: [128, 64, 128]
    """
    
    def __init__(self, client, split: str):
        self.client = client
        self.split = split
        self.class_names = {}
        self.palette = {}
        self._load_config()
    
    def _load_config(self):
        """Load config from data.yaml."""
        yaml_paths = ['data.yaml', 'dataset.yaml', 'config.yaml']
        
        for yaml_path in yaml_paths:
            try:
                yaml_text = self.client.get_text(yaml_path)
                self._parse_config(yaml_text)
                if self.class_names:
                    logger.info(f"SemanticSeg: loaded {len(self.class_names)} classes from {yaml_path}")
                    return
            except:
                continue
    
    def _parse_config(self, yaml_text: str):
        """Parse config without pyyaml dependency."""
        in_names = False
        in_palette = False
        
        for line in yaml_text.split('\n'):
            line = line.rstrip()
            
            if line.startswith('names:'):
                in_names = True
                in_palette = False
                if '[' in line:
                    list_str = line.split('[', 1)[1].rsplit(']', 1)[0]
                    items = [s.strip().strip("'\"") for s in list_str.split(',')]
                    self.class_names = {i: name for i, name in enumerate(items) if name}
                continue
            
            if line.startswith('palette:'):
                in_palette = True
                in_names = False
                continue
            
            if in_names and line.strip() and (line.startswith(' ') or line.startswith('\t')):
                stripped = line.strip()
                if ':' in stripped:
                    parts = stripped.split(':', 1)
                    try:
                        idx = int(parts[0].strip())
                        name = parts[1].strip().strip("'\"")
                        self.class_names[idx] = name
                    except ValueError:
                        pass
            
            if in_palette and line.strip() and (line.startswith(' ') or line.startswith('\t')):
                stripped = line.strip()
                if ':' in stripped and '[' in stripped:
                    parts = stripped.split(':', 1)
                    try:
                        idx = int(parts[0].strip())
                        colors = parts[1].strip()
                        if '[' in colors:
                            color_str = colors.split('[', 1)[1].rsplit(']', 1)[0]
                            rgb = [int(c.strip()) for c in color_str.split(',')]
                            self.palette[idx] = tuple(rgb)
                    except:
                        pass
    
    def scan_images(self) -> List[str]:
        """Scan for images."""
        if hasattr(self.client, 'list_files'):
            image_dir = f"{self.split}/images/"
            files = self.client.list_files(prefix=image_dir)
            return [f for f in files if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp'))]
        return []
    
    def get_mask_path(self, image_path: str) -> str:
        """Convert image path to mask path."""
        # Try masks/ first, then labels/
        mask_path = image_path.replace('/images/', '/masks/')
        mask_path = mask_path.rsplit('.', 1)[0] + '.png'
        return mask_path
    
    def get_class_name(self, class_id: int) -> str:
        return self.class_names.get(class_id, f"class_{class_id}")
    
    @property
    def num_classes(self) -> int:
        if self.class_names:
            return max(self.class_names.keys()) + 1
        return 0


class TextDatasetFormat:
    """
    Text dataset format for NLP tasks.
    
    Supports:
        - CSV: text,label columns
        - JSONL: {"text": "...", "label": "..."}
        - JSON: [{"text": "...", "label": "..."}, ...]
    
    Expected structure:
        {prefix}/{split}.csv
        {prefix}/{split}.jsonl  
        {prefix}/{split}.json
    
    For sequence-to-sequence:
        {prefix}/{split}.jsonl with {"input": "...", "output": "..."}
    
    Config (data.yaml):
        task: classification  # classification, ner, seq2seq
        text_column: text
        label_column: label
        names:
          0: negative
          1: positive
    """
    
    def __init__(self, client, split: str):
        self.client = client
        self.split = split
        self.task = 'classification'
        self.text_column = 'text'
        self.label_column = 'label'
        self.input_column = 'input'
        self.output_column = 'output'
        self.class_names = {}
        self.samples = []
        self._load_config()
        self._load_data()
    
    def _load_config(self):
        """Load config from data.yaml."""
        try:
            yaml_text = self.client.get_text('data.yaml')
            for line in yaml_text.split('\n'):
                line = line.strip()
                if line.startswith('task:'):
                    self.task = line.split(':', 1)[1].strip().strip("'\"")
                elif line.startswith('text_column:'):
                    self.text_column = line.split(':', 1)[1].strip().strip("'\"")
                elif line.startswith('label_column:'):
                    self.label_column = line.split(':', 1)[1].strip().strip("'\"")
                elif line.startswith('input_column:'):
                    self.input_column = line.split(':', 1)[1].strip().strip("'\"")
                elif line.startswith('output_column:'):
                    self.output_column = line.split(':', 1)[1].strip().strip("'\"")
        except:
            pass
    
    def _load_data(self):
        """Load dataset from file."""
        # Try different formats
        for ext in ['.jsonl', '.json', '.csv']:
            try:
                content = self.client.get_text(f"{self.split}{ext}")
                
                if ext == '.jsonl':
                    self.samples = [json.loads(line) for line in content.strip().split('\n') if line.strip()]
                elif ext == '.json':
                    self.samples = json.loads(content)
                elif ext == '.csv':
                    self.samples = self._parse_csv(content)
                
                if self.samples:
                    logger.info(f"TextDataset: loaded {len(self.samples)} samples from {self.split}{ext}")
                    self._build_class_names()
                    return
            except:
                continue
        
        logger.warning(f"TextDataset: no data found for split '{self.split}'")
    
    def _parse_csv(self, content: str) -> List[Dict]:
        """Parse CSV content."""
        lines = content.strip().split('\n')
        if not lines:
            return []
        
        # First line is header
        header = [h.strip().strip('"') for h in lines[0].split(',')]
        
        samples = []
        for line in lines[1:]:
            if not line.strip():
                continue
            # Simple CSV parsing (doesn't handle quoted commas)
            values = [v.strip().strip('"') for v in line.split(',')]
            if len(values) == len(header):
                samples.append(dict(zip(header, values)))
        
        return samples
    
    def _build_class_names(self):
        """Build class names from data."""
        if self.task == 'classification' and self.samples:
            labels = set()
            for s in self.samples:
                label = s.get(self.label_column)
                if label is not None:
                    labels.add(str(label))
            
            sorted_labels = sorted(labels)
            self.class_names = {i: name for i, name in enumerate(sorted_labels)}
    
    def __len__(self) -> int:
        return len(self.samples)
    
    def get_item(self, idx: int) -> Dict[str, Any]:
        """Get item by index."""
        sample = self.samples[idx]
        
        if self.task == 'seq2seq':
            return {
                'input': sample.get(self.input_column, ''),
                'output': sample.get(self.output_column, ''),
            }
        elif self.task == 'ner':
            return {
                'text': sample.get(self.text_column, ''),
                'entities': sample.get('entities', []),
            }
        else:  # classification
            text = sample.get(self.text_column, '')
            label = sample.get(self.label_column, '')
            # Convert label to index
            label_idx = None
            for idx, name in self.class_names.items():
                if name == str(label):
                    label_idx = idx
                    break
            return {
                'text': text,
                'label': label_idx if label_idx is not None else label,
            }
    
    def get_class_name(self, class_id: int) -> str:
        return self.class_names.get(class_id, f"class_{class_id}")
    
    @property
    def num_classes(self) -> int:
        return len(self.class_names)


class TabularFormat:
    """
    Tabular dataset format for regression/classification.
    
    Supports:
        - CSV files
        - Parquet files (requires pyarrow)
    
    Expected structure:
        {prefix}/{split}.csv
        {prefix}/{split}.parquet
    
    Config (data.yaml):
        task: regression  # regression, classification
        target_column: price
        feature_columns: [col1, col2, col3]  # optional, uses all if not specified
        categorical_columns: [cat1, cat2]
    """
    
    def __init__(self, client, split: str):
        self.client = client
        self.split = split
        self.task = 'regression'
        self.target_column = 'target'
        self.feature_columns = None
        self.categorical_columns = []
        self.class_names = {}
        self.data = []
        self.columns = []
        self._load_config()
        self._load_data()
    
    def _load_config(self):
        """Load config from data.yaml."""
        try:
            yaml_text = self.client.get_text('data.yaml')
            for line in yaml_text.split('\n'):
                line = line.strip()
                if line.startswith('task:'):
                    self.task = line.split(':', 1)[1].strip().strip("'\"")
                elif line.startswith('target_column:'):
                    self.target_column = line.split(':', 1)[1].strip().strip("'\"")
                elif line.startswith('feature_columns:') and '[' in line:
                    cols_str = line.split('[', 1)[1].rsplit(']', 1)[0]
                    self.feature_columns = [c.strip().strip("'\"") for c in cols_str.split(',')]
                elif line.startswith('categorical_columns:') and '[' in line:
                    cols_str = line.split('[', 1)[1].rsplit(']', 1)[0]
                    self.categorical_columns = [c.strip().strip("'\"") for c in cols_str.split(',')]
        except:
            pass
    
    def _load_data(self):
        """Load tabular data."""
        # Try CSV first
        try:
            content = self.client.get_text(f"{self.split}.csv")
            self._parse_csv(content)
            if self.data:
                logger.info(f"Tabular: loaded {len(self.data)} rows from {self.split}.csv")
                return
        except:
            pass
        
        # Try Parquet
        try:
            import pyarrow.parquet as pq
            content = self.client.get_bytes(f"{self.split}.parquet")
            table = pq.read_table(io.BytesIO(content))
            self.columns = table.column_names
            self.data = table.to_pydict()
            logger.info(f"Tabular: loaded {len(self.data)} rows from {self.split}.parquet")
        except:
            pass
    
    def _parse_csv(self, content: str):
        """Parse CSV into columnar format."""
        lines = content.strip().split('\n')
        if not lines:
            return
        
        self.columns = [h.strip().strip('"') for h in lines[0].split(',')]
        self.data = {col: [] for col in self.columns}
        
        for line in lines[1:]:
            if not line.strip():
                continue
            values = [v.strip().strip('"') for v in line.split(',')]
            if len(values) == len(self.columns):
                for col, val in zip(self.columns, values):
                    # Try to convert to number
                    try:
                        val = float(val)
                        if val == int(val):
                            val = int(val)
                    except:
                        pass
                    self.data[col].append(val)
    
    def __len__(self) -> int:
        if self.data and self.columns:
            return len(self.data[self.columns[0]])
        return 0
    
    def get_item(self, idx: int) -> Dict[str, Any]:
        """Get item by index."""
        # Get features
        feature_cols = self.feature_columns or [c for c in self.columns if c != self.target_column]
        
        features = []
        for col in feature_cols:
            val = self.data[col][idx]
            if isinstance(val, (int, float)):
                features.append(float(val))
            else:
                # Categorical - would need encoding
                features.append(0.0)
        
        # Get target
        target = self.data.get(self.target_column, [None] * len(self))[idx]
        if self.task == 'classification' and isinstance(target, str):
            # Convert to index
            if target not in self.class_names.values():
                self.class_names[len(self.class_names)] = target
            for idx, name in self.class_names.items():
                if name == target:
                    target = idx
                    break
        
        return {
            'features': np.array(features, dtype=np.float32),
            'target': target,
        }
    
    def get_class_name(self, class_id: int) -> str:
        return self.class_names.get(class_id, f"class_{class_id}")
    
    @property
    def num_classes(self) -> int:
        return len(self.class_names) if self.task == 'classification' else 0


# =============================================================================
# Universal Dataset
# =============================================================================

class UniversalDataset(Dataset):
    """
    Universal dataset that works with multiple data sources and formats.
    
    Automatically uses RAMJET caching when available.
    
    Args:
        data_source: Data source config dict (from ramjetio.get_data_source())
        split: 'train', 'valid', or 'test'
        format: 'yolo', 'coco', 'imagefolder', or 'auto' (auto-detect)
        img_size: Target image size
        transform: Optional transform function
        cache: Optional RAMJET cache instance
    
    Supported formats:
        Vision:
        - yolo: YOLO all tasks (detect/segment/pose/obb/classify)
        - coco: COCO detection/segmentation
        - imagefolder: Classification (class_name/image.jpg)
        - semantic_seg: Semantic segmentation (images/ + masks/)
        
        NLP:
        - text: Text classification/NER/seq2seq (CSV/JSONL)
        
        Tabular:
        - tabular: Regression/classification from CSV/Parquet
    
    Example:
        >>> import ramjet
        >>> ramjet.init()
        >>> dataset = ramjet.UniversalDataset(split='train')  # auto-detect
        >>> loader = DataLoader(dataset)
    """
    
    def __init__(
        self,
        data_source: Optional[Dict[str, Any]] = None,
        split: str = 'train',
        format: str = 'auto',
        img_size: int = 640,
        transform: Optional[Callable] = None,
        cache = None,
    ):
        self.split = split
        self.img_size = img_size
        self.transform = transform
        self.format = format
        self._format_handler = None  # Format handler (YOLOFormat, COCOFormat, etc.)
        
        # Get data source from RAMJET if not provided
        if data_source is None:
            if RAMJET_AVAILABLE:
                data_source = ramjetio.get_data_source()
            if not data_source:
                raise ValueError(
                    "data_source required. Either pass it explicitly or "
                    "configure in RAMJET dashboard and call ramjet.init() first."
                )
        
        self.data_source = data_source
        
        # Initialize client based on data source type
        ds_type = data_source.get('type', 0)
        if ds_type == 1:  # S3
            self._client = S3Client(data_source)
        elif ds_type == 2:  # Local
            self._client = LocalClient(data_source)
        elif ds_type == 3:  # HTTP
            self._client = HTTPClient(data_source)
        else:
            raise ValueError(f"Unknown data source type: {ds_type}")
        
        # Initialize cache
        self._cache = cache
        if self._cache is None and RAMJET_AVAILABLE:
            self._cache = ramjetio.get_cache()
        
        # Scan for files
        self.samples = []
        self._scan_files()
        
        logger.info(f"UniversalDataset: {len(self.samples)} samples ({split}, {self.format})")
    
    def _scan_files(self):
        """Scan data source for files."""
        # Auto-detect format
        if self.format == 'auto':
            self.format = self._detect_format()
        
        if self.format == 'yolo':
            self._format_handler = YOLOFormat(self._client, self.split)
            self.samples = self._format_handler.scan_images()
        elif self.format == 'coco':
            self._format_handler = COCOFormat(self._client, self.split)
            self.samples = self._format_handler.get_image_ids()
        elif self.format == 'imagefolder':
            self._format_handler = ImageFolderFormat(self._client, self.split)
            self.samples = self._format_handler.scan_images()
        elif self.format == 'semantic_seg':
            self._format_handler = SemanticSegFormat(self._client, self.split)
            self.samples = self._format_handler.scan_images()
        elif self.format == 'text':
            self._format_handler = TextDatasetFormat(self._client, self.split)
            self.samples = list(range(len(self._format_handler)))
        elif self.format == 'tabular':
            self._format_handler = TabularFormat(self._client, self.split)
            self.samples = list(range(len(self._format_handler)))
        else:
            raise ValueError(
                f"Unknown format: {self.format}. Supported: "
                "yolo, coco, imagefolder, semantic_seg, text, tabular"
            )
    
    def _detect_format(self) -> str:
        """Auto-detect dataset format."""
        try:
            # Check for text/tabular files first (they don't have split/ prefix structure)
            try:
                for ext in ['.jsonl', '.json', '.csv']:
                    self._client.get_text(f"{self.split}{ext}")
                    # Check if it's tabular (has numeric columns) or text
                    return 'text'  # Default to text, can be overridden
            except:
                pass
            
            if hasattr(self._client, 'list_files'):
                files = self._client.list_files(prefix=f"{self.split}/")
                
                # Check for YOLO structure (images/ and labels/ folders)
                has_images = any('/images/' in f for f in files[:100])
                has_labels = any('/labels/' in f for f in files[:100])
                if has_images and has_labels:
                    return 'yolo'
                
                # Check for semantic segmentation (images/ and masks/)
                has_masks = any('/masks/' in f for f in files[:100])
                if has_images and has_masks:
                    return 'semantic_seg'
                
                # Check for COCO structure (annotations.json)
                ann_files = [f for f in files if 'annotations' in f.lower() and f.endswith('.json')]
                if ann_files:
                    return 'coco'
            
            # Default to imagefolder for image datasets
            return 'imagefolder'
        except:
            return 'imagefolder'
    
    def __len__(self) -> int:
        return len(self.samples)
    
    @property
    def class_names(self) -> Dict[int, str]:
        """Get class names mapping (class_id -> class_name)."""
        if self._format_handler:
            return getattr(self._format_handler, 'class_names', {})
        return {}
    
    @property
    def num_classes(self) -> int:
        """Get number of classes."""
        if self._format_handler:
            return getattr(self._format_handler, 'num_classes', 0)
        return 0
    
    def get_class_name(self, class_id: int) -> str:
        """Get class name by ID."""
        if self._format_handler and hasattr(self._format_handler, 'get_class_name'):
            return self._format_handler.get_class_name(class_id)
        return f"class_{class_id}"
    
    @property
    def task(self) -> str:
        """Get YOLO task type (detect, segment, pose, obb, classify)."""
        if self._format_handler and hasattr(self._format_handler, 'task'):
            return self._format_handler.task
        if self.format == 'imagefolder':
            return 'classify'
        return 'detect'
    
    def export_local(self, path: str, rank: int = 0, world_size: int = 1) -> str:
        """
        Export dataset to local filesystem for frameworks that require local files.
        
        Each rank exports its shard in parallel for distributed caching.
        Automatically reports caching progress to RAMJET dashboard.
        
        Args:
            path: Local directory to export to
            rank: Current process rank (for distributed sharding)
            world_size: Total number of processes
            
        Returns:
            Path to data.yaml (for YOLO) or root directory path
        """
        import time
        
        if self.format == 'yolo':
            return self._export_yolo_local(path, rank, world_size)
        else:
            raise NotImplementedError(
                f"export_local not yet supported for format '{self.format}'. "
                "Currently supports: yolo"
            )

    def _export_yolo_local(self, path: str, rank: int, world_size: int) -> str:
        """Export YOLO dataset to local filesystem."""
        import time

        os.makedirs(f"{path}/{self.split}/images", exist_ok=True)
        os.makedirs(f"{path}/{self.split}/labels", exist_ok=True)

        num_samples = len(self.samples)
        my_indices = list(range(rank, num_samples, world_size))

        # Report caching phase with total across all ranks
        if RAMJET_AVAILABLE:
            ramjetio.set_caching_phase(current=0, total=num_samples)

        logger.info(f"[Rank {rank}] Exporting {len(my_indices)}/{num_samples} YOLO samples to {path}")

        start_time = time.time()
        exported = 0
        skipped = 0
        for idx in my_indices:
            image_path = self.samples[idx]
            local_img = f"{path}/{self.split}/images/{idx:06d}.jpg"
            local_lbl = f"{path}/{self.split}/labels/{idx:06d}.txt"

            # Skip if already exported
            if os.path.exists(local_img) and os.path.exists(local_lbl):
                skipped += 1
                exported += 1
                if exported % 100 == 0:
                    logger.info(f"[Rank {rank}] Progress {exported}/{len(my_indices)} ({skipped} cached)")
                if exported % 10 == 0 and RAMJET_AVAILABLE:
                    ramjetio.set_caching_phase(current=exported * world_size, total=num_samples)
                continue

            # Download image bytes and write to disk
            try:
                image_bytes = self._client.get_bytes(image_path)

                # Write as-is if already JPEG, otherwise decode+encode
                if image_path.lower().endswith(('.jpg', '.jpeg')):
                    with open(local_img, 'wb') as f:
                        f.write(image_bytes)
                else:
                    img = self._decode_image(image_bytes)
                    if CV2_AVAILABLE:
                        import cv2
                        cv2.imwrite(local_img, cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
                    elif PIL_AVAILABLE:
                        Image.fromarray(img).save(local_img)

                # Download and write label
                label_path = YOLOFormat.get_label_path(image_path)
                try:
                    label_text = self._client.get_text(label_path)
                    with open(local_lbl, 'w') as f:
                        f.write(label_text)
                except Exception:
                    # No label file — create empty
                    with open(local_lbl, 'w') as f:
                        pass

                exported += 1
                if exported % 100 == 0:
                    logger.info(f"[Rank {rank}] Exported {exported}/{len(my_indices)}")
                if exported % 10 == 0 and RAMJET_AVAILABLE:
                    ramjetio.set_caching_phase(current=exported * world_size, total=num_samples)

            except Exception as e:
                logger.warning(f"[Rank {rank}] Failed to export sample {idx}: {e}")

        elapsed = time.time() - start_time
        logger.info(f"[Rank {rank}] Exported {exported} samples in {elapsed:.1f}s ({skipped} cached, {exported - skipped} downloaded)")

        if RAMJET_AVAILABLE:
            ramjetio.set_caching_phase(current=num_samples, total=num_samples)

        # Barrier if DDP is active
        try:
            import torch.distributed as dist
            if dist.is_initialized():
                dist.barrier()
        except (ImportError, RuntimeError):
            pass

        # Rank 0 writes data.yaml
        data_yaml_path = f"{path}/data.yaml"
        if rank == 0:
            import yaml
            class_names = self.class_names or {0: 'object'}
            data_yaml = {
                'path': os.path.abspath(path),
                'train': f'{self.split}/images',
                'val': f'{self.split}/images',
                'names': class_names,
                'nc': len(class_names),
            }
            with open(data_yaml_path, 'w') as f:
                yaml.dump(data_yaml, f)
            logger.info(f"data.yaml created: {data_yaml_path}")

        # Second barrier to ensure data.yaml is ready
        try:
            import torch.distributed as dist
            if dist.is_initialized():
                dist.barrier()
        except (ImportError, RuntimeError):
            pass

        return data_yaml_path

    def __getitem__(self, idx: int):
        """Get item by index."""
        if self.format == 'yolo':
            return self._get_yolo_item(idx)
        elif self.format == 'coco':
            return self._get_coco_item(idx)
        elif self.format == 'imagefolder':
            return self._get_imagefolder_item(idx)
        elif self.format == 'semantic_seg':
            return self._get_semantic_seg_item(idx)
        elif self.format == 'text':
            return self._get_text_item(idx)
        elif self.format == 'tabular':
            return self._get_tabular_item(idx)
        else:
            raise ValueError(f"Unknown format: {self.format}")
    
    def _get_yolo_item(self, idx: int) -> Dict[str, Any]:
        """
        Get YOLO item (any task).
        
        Returns dict with:
            - 'image': np.ndarray CHW float32 normalized
            - 'boxes': np.ndarray (N, 4) [x, y, w, h]
            - 'classes': np.ndarray (N,) class indices
            - 'segments': list of polygons (for segment task)
            - 'keypoints': np.ndarray (N, K, 3) (for pose task)
            - 'obb': np.ndarray (N, 8) (for obb task)
        """
        image_path = self.samples[idx]
        cache_key = f"yolo_{self.split}_{idx}"
        
        # Try cache first
        if self._cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached
        
        # Load image
        image_bytes = self._client.get_bytes(image_path)
        image = self._decode_image(image_bytes)
        image = self._resize_image(image, self.img_size)
        
        # Load labels
        label_path = YOLOFormat.get_label_path(image_path)
        try:
            label_text = self._client.get_text(label_path)
            labels = self._format_handler.parse_labels(label_text)
        except Exception as e:
            logger.debug(f"No labels for {image_path}: {e}")
            labels = {
                'boxes': np.zeros((0, 4), dtype=np.float32),
                'classes': np.array([], dtype=np.int64),
                'segments': [],
                'keypoints': [],
                'obb': [],
            }
        
        # Apply transform
        if self.transform:
            image, labels = self.transform(image, labels)
        
        # Normalize image to CHW float32
        if isinstance(image, np.ndarray):
            image = image.astype(np.float32) / 255.0
            image = np.transpose(image, (2, 0, 1))  # HWC -> CHW
        
        result = {
            'image': image,
            **labels,
        }
        
        # Cache result
        if self._cache:
            try:
                self._cache.set(cache_key, result)
            except Exception as e:
                logger.debug(f"Cache set failed: {e}")
        
        return result
    
    def _get_coco_item(self, idx: int) -> Tuple[np.ndarray, np.ndarray]:
        """Get COCO detection item."""
        image_id = self.samples[idx]
        cache_key = f"coco_{self.split}_{image_id}"
        
        # Try cache first
        if self._cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached
        
        # Load image
        image_path = self._format_handler.get_image_path(image_id)
        image_bytes = self._client.get_bytes(image_path)
        image = self._decode_image(image_bytes)
        image = self._resize_image(image, self.img_size)
        
        # Get annotations (already in YOLO format)
        labels = self._format_handler.get_annotations(image_id)
        
        # Apply transform
        if self.transform:
            image, labels = self.transform(image, labels)
        
        # Normalize image to CHW float32
        if isinstance(image, np.ndarray):
            image = image.astype(np.float32) / 255.0
            image = np.transpose(image, (2, 0, 1))  # HWC -> CHW
        
        result = (image, labels)
        
        # Cache result
        if self._cache:
            try:
                self._cache.set(cache_key, result)
            except Exception as e:
                logger.debug(f"Cache set failed: {e}")
        
        return result

    def _get_imagefolder_item(self, idx: int) -> Tuple[np.ndarray, int]:
        """Get ImageFolder classification item."""
        image_path, label = self.samples[idx]
        cache_key = f"imgfolder_{self.split}_{idx}"
        
        # Try cache first
        if self._cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached
        
        # Load image
        image_bytes = self._client.get_bytes(image_path)
        image = self._decode_image(image_bytes)
        image = self._resize_image(image, self.img_size)
        
        # Apply transform
        if self.transform:
            image = self.transform(image)
        
        # Normalize image to CHW float32
        if isinstance(image, np.ndarray):
            image = image.astype(np.float32) / 255.0
            image = np.transpose(image, (2, 0, 1))  # HWC -> CHW
        
        result = (image, label)
        
        # Cache result
        if self._cache:
            try:
                self._cache.set(cache_key, result)
            except Exception as e:
                logger.debug(f"Cache set failed: {e}")
        
        return result
    
    def _get_semantic_seg_item(self, idx: int) -> Dict[str, Any]:
        """
        Get semantic segmentation item.
        
        Returns dict with:
            - 'image': np.ndarray CHW float32 normalized
            - 'mask': np.ndarray HW int64 class indices
        """
        image_path = self.samples[idx]
        cache_key = f"semseg_{self.split}_{idx}"
        
        # Try cache first
        if self._cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached
        
        # Load image
        image_bytes = self._client.get_bytes(image_path)
        image = self._decode_image(image_bytes)
        orig_h, orig_w = image.shape[:2]
        image = self._resize_image(image, self.img_size)
        
        # Load mask
        mask_path = self._format_handler.get_mask_path(image_path)
        try:
            mask_bytes = self._client.get_bytes(mask_path)
            mask = self._decode_mask(mask_bytes)
            # Resize mask to match image
            mask = self._resize_mask(mask, self.img_size, orig_h, orig_w)
        except Exception as e:
            logger.debug(f"No mask for {image_path}: {e}")
            mask = np.zeros((self.img_size, self.img_size), dtype=np.int64)
        
        # Apply transform
        if self.transform:
            image, mask = self.transform(image, mask)
        
        # Normalize image to CHW float32
        if isinstance(image, np.ndarray):
            image = image.astype(np.float32) / 255.0
            image = np.transpose(image, (2, 0, 1))  # HWC -> CHW
        
        result = {'image': image, 'mask': mask}
        
        # Cache result
        if self._cache:
            try:
                self._cache.set(cache_key, result)
            except Exception as e:
                logger.debug(f"Cache set failed: {e}")
        
        return result
    
    def _decode_mask(self, data: bytes) -> np.ndarray:
        """Decode mask from bytes (PNG with class indices)."""
        if CV2_AVAILABLE:
            arr = np.frombuffer(data, dtype=np.uint8)
            mask = cv2.imdecode(arr, cv2.IMREAD_GRAYSCALE)
            return mask.astype(np.int64)
        elif PIL_AVAILABLE:
            mask = Image.open(io.BytesIO(data))
            return np.array(mask, dtype=np.int64)
        else:
            raise ImportError("cv2 or PIL required")
    
    def _resize_mask(self, mask: np.ndarray, size: int, orig_h: int, orig_w: int) -> np.ndarray:
        """Resize mask with nearest neighbor interpolation."""
        scale = size / max(orig_h, orig_w)
        new_h, new_w = int(orig_h * scale), int(orig_w * scale)
        
        if CV2_AVAILABLE:
            mask = cv2.resize(mask.astype(np.uint8), (new_w, new_h), interpolation=cv2.INTER_NEAREST)
        elif PIL_AVAILABLE:
            pil_mask = Image.fromarray(mask.astype(np.uint8))
            pil_mask = pil_mask.resize((new_w, new_h), Image.NEAREST)
            mask = np.array(pil_mask)
        
        # Letterbox
        canvas = np.zeros((size, size), dtype=np.int64)
        pad_h = (size - new_h) // 2
        pad_w = (size - new_w) // 2
        canvas[pad_h:pad_h+new_h, pad_w:pad_w+new_w] = mask
        
        return canvas
    
    def _get_text_item(self, idx: int) -> Dict[str, Any]:
        """
        Get text dataset item.
        
        Returns dict based on task:
            Classification: {'text': str, 'label': int}
            NER: {'text': str, 'entities': list}
            Seq2Seq: {'input': str, 'output': str}
        """
        cache_key = f"text_{self.split}_{idx}"
        
        # Try cache first
        if self._cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached
        
        result = self._format_handler.get_item(idx)
        
        # Cache result
        if self._cache:
            try:
                self._cache.set(cache_key, result)
            except Exception as e:
                logger.debug(f"Cache set failed: {e}")
        
        return result
    
    def _get_tabular_item(self, idx: int) -> Dict[str, Any]:
        """
        Get tabular dataset item.
        
        Returns dict with:
            - 'features': np.ndarray (n_features,) float32
            - 'target': float or int (depending on task)
        """
        cache_key = f"tabular_{self.split}_{idx}"
        
        # Try cache first
        if self._cache:
            cached = self._cache.get(cache_key)
            if cached is not None:
                return cached
        
        result = self._format_handler.get_item(idx)
        
        # Cache result
        if self._cache:
            try:
                self._cache.set(cache_key, result)
            except Exception as e:
                logger.debug(f"Cache set failed: {e}")
        
        return result
    
    def _decode_image(self, data: bytes) -> np.ndarray:
        """Decode image from bytes."""
        if CV2_AVAILABLE:
            arr = np.frombuffer(data, dtype=np.uint8)
            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
            return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        elif PIL_AVAILABLE:
            img = Image.open(io.BytesIO(data)).convert('RGB')
            return np.array(img)
        else:
            raise ImportError("cv2 or PIL required. Run: pip install opencv-python")
    
    def _resize_image(self, image: np.ndarray, size: int) -> np.ndarray:
        """Resize image maintaining aspect ratio with letterbox."""
        h, w = image.shape[:2]
        scale = size / max(h, w)
        new_h, new_w = int(h * scale), int(w * scale)
        
        if CV2_AVAILABLE:
            image = cv2.resize(image, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        elif PIL_AVAILABLE:
            pil_img = Image.fromarray(image)
            pil_img = pil_img.resize((new_w, new_h), Image.BILINEAR)
            image = np.array(pil_img)
        
        # Letterbox to square
        canvas = np.full((size, size, 3), 114, dtype=np.uint8)
        pad_h = (size - new_h) // 2
        pad_w = (size - new_w) // 2
        canvas[pad_h:pad_h+new_h, pad_w:pad_w+new_w] = image
        
        return canvas


def yolo_collate_fn(batch):
    """
    Collate function for YOLO dataset.
    Handles variable-length labels.
    """
    images = []
    labels = []
    
    for img, label in batch:
        if isinstance(img, np.ndarray):
            img = torch.from_numpy(img)
        images.append(img)
        
        if isinstance(label, np.ndarray):
            label = torch.from_numpy(label)
        labels.append(label)
    
    images = torch.stack(images, 0)
    
    return images, labels
