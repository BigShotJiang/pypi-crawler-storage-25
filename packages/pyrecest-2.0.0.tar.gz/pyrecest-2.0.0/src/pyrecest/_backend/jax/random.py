"""
Jax-based random backend.
Based on random.py by emilemathieu on
https://github.com/oxcsml/geomstats/blob/master/geomstats/_backend/jax/random.py
who says he was in inspired by https://github.com/wesselb/lab/blob/master/lab/jax/random.py
"""

import sys

import jax
import numpy as _np

backend = sys.modules[__name__]


def create_random_state(seed=0):
    return jax.random.PRNGKey(seed=seed)


def seed(seed=None):
    """Reset both the NumPy and JAX RNG state used by this backend."""
    if seed is None:
        seed = int(_np.random.SeedSequence().generate_state(1, dtype=_np.uint32)[0])

    seed_sequence = _np.random.SeedSequence(seed)
    jax_seed = int(seed_sequence.generate_state(1, dtype=_np.uint32)[0])
    backend.jax_global_random_state = create_random_state(jax_seed)
    _np.random.seed(seed)


backend.jax_global_random_state = jax.random.PRNGKey(seed=0)


def global_random_state():
    return backend.jax_global_random_state


def set_global_random_state(state):
    backend.jax_global_random_state = state


get_state = global_random_state
set_state = set_global_random_state


def _get_state(**kwargs):
    has_state = 'state' in kwargs
    state = kwargs.pop('state', backend.jax_global_random_state)
    return state, has_state, kwargs


def set_state_return(has_state, state, res):
    if has_state:
        return state, res
    else:
        backend.jax_global_random_state = state
        return res


def _rand(state, size, *args, **kwargs):
    state, key = jax.random.split(state)
    return state, jax.random.uniform(key, size, *args, **kwargs)


def rand(size, *args, **kwargs):
    size = size if hasattr(size, "__iter__") else (size,)
    state, has_state, kwargs = _get_state(**kwargs)
    state, res = _rand(state, size, *args, **kwargs)
    return set_state_return(has_state, state, res)


uniform = rand


def _randint(state, size, *args, **kwargs):
    state, key = jax.random.split(state)
    return state, jax.random.randint(key, size, *args, **kwargs)


def randint(size, *args, **kwargs):
    size = size if hasattr(size, "__iter__") else (size,)
    state, has_state, kwargs = _get_state(**kwargs)
    state, res = _randint(state, size, *args, **kwargs)
    return set_state_return(has_state, state, res)


def _normal(state, size, *args, **kwargs):
    state, key = jax.random.split(state)
    return state, jax.random.normal(key, size, *args, **kwargs)


def normal(size, *args, **kwargs):
    size = size if hasattr(size, "__iter__") else (size,)
    state, has_state, kwargs = _get_state(**kwargs)

    # Check and remove 'mean' and 'cov' from kwargs
    mean = kwargs.pop('mean', None)
    cov = kwargs.pop('cov', None)

    # Verify that 'mean' and 'cov' have the expected values
    if mean is not None and mean != 0.0:
        raise ValueError(f"Expected mean to be 0.0, but got {mean}")
    if cov is not None and cov != 1.0:
        raise ValueError(f"Expected cov to be 1.0, but got {cov}")

    state, res = _normal(state, size, *args, **kwargs)
    return set_state_return(has_state, state, res)


def _choice(state, a, n, *args, **kwargs):
    state, key = jax.random.split(state)
    inds = jax.random.choice(key, a.shape[0], (n,), replace=True, *args, **kwargs)
    choices = a[inds]
    return state, choices[0] if n == 1 else choices


def choice(a, n, *args, **kwargs):
    state, has_state, kwargs = _get_state(**kwargs)
    state, res = _choice(state, a, n, *args, **kwargs)
    return set_state_return(has_state, state, res)


def _multivariate_normal(state, size, *args, **kwargs):
    state, key = jax.random.split(state)
    return state, jax.random.multivariate_normal(key, shape=size, *args, **kwargs)


def multivariate_normal(size, *args, **kwargs):
    size = size if hasattr(size, "__iter__") else (size,)
    state, has_state, kwargs = _get_state(**kwargs)
    state, res = _multivariate_normal(state, size, *args, **kwargs)
    return set_state_return(has_state, state, res)


def multinomial(n, pvals):
    """Sample from a multinomial distribution using JAX."""
    import jax.numpy as _jnp

    state, has_state, _ = _get_state()
    state, key = jax.random.split(state)
    backend.jax_global_random_state = state
    pvals = _jnp.asarray(pvals, dtype=_jnp.float32)
    pvals = pvals / pvals.sum()
    samples = jax.random.categorical(key, _jnp.log(pvals), shape=(n,))
    return _jnp.bincount(samples, minlength=len(pvals))
