"""Public API for MemScale.

This is the user-facing interface. Most users only need:

    import memscale
    trainer = memscale.wrap(your_trainer)

Or for custom training loops:

    with memscale.optimize(model, optimizer):
        for batch in dataloader:
            ...
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Any, Optional

import torch
import torch.nn as nn

from memscale.core.config import Config
from memscale.core.decision_engine import DecisionEngine
from memscale.core.executor import Executor
from memscale.core.profiler import MemoryProfiler
from memscale.observability.logger import get_logger

logger = logging.getLogger(__name__)


def wrap(
    target: Any,
    config: Optional[Config] = None,
    sample_input: Optional[torch.Tensor] = None,
) -> Any:
    """Wrap a trainer or model with MemScale optimizations.

    Args:
        target: Either a HuggingFace Trainer, Lightning Trainer, or PyTorch Module
        config: Optional configuration. Defaults to balanced mode.
        sample_input: Sample input tensor (improves profiling accuracy)

    Returns:
        The same trainer/model with optimization hooks attached.

    Example:
        >>> from transformers import Trainer
        >>> import memscale
        >>>
        >>> trainer = Trainer(model=model, args=args, ...)
        >>> trainer = memscale.wrap(trainer)
        >>> trainer.train()  # VRAM optimized automatically
    """
    if config is None:
        config = Config()

    # Initialize observability
    obs_logger = get_logger(config)
    obs_logger.info("MemScale initialized", version="0.1.0", mode=config.mode.value)

    # Detect what we're wrapping
    if hasattr(target, "model") and hasattr(target, "train"):
        # HuggingFace Trainer
        from memscale.integrations.huggingface import wrap_hf_trainer

        return wrap_hf_trainer(target, config, sample_input)

    if isinstance(target, nn.Module):
        # Raw PyTorch module — return wrapped model
        return _wrap_module(target, config, sample_input)

    raise TypeError(
        f"Cannot wrap object of type {type(target).__name__}. "
        f"Supported: HuggingFace Trainer, PyTorch Module, Lightning Trainer."
    )


def _wrap_module(
    model: nn.Module,
    config: Config,
    sample_input: Optional[torch.Tensor],
) -> nn.Module:
    """Wrap a raw nn.Module with optimization hooks."""
    profiler = MemoryProfiler(
        prefer_static=config.use_static_profiling,
        fallback_empirical=config.use_empirical_fallback,
    )

    # Profile
    hw = profiler.detect_hardware()
    logger.info(f"Detected hardware: {hw}")

    graph = profiler.profile(model, sample_input)
    logger.info(graph.summary())

    # Decide
    engine = DecisionEngine(config)
    plan = engine.decide(graph, hw)
    logger.info(plan.summary())

    # Execute
    executor = Executor(model, plan, config)
    executor.attach()

    # Attach executor reference so user can detach later
    model._memscale_executor = executor
    return model


@contextmanager
def optimize(
    model: nn.Module,
    optimizer: Optional[torch.optim.Optimizer] = None,
    config: Optional[Config] = None,
    sample_input: Optional[torch.Tensor] = None,
):
    """Context manager for MemScale optimization.

    Use this for custom training loops where you don't have a Trainer object.

    Example:
        >>> import memscale
        >>>
        >>> with memscale.optimize(model, optimizer) as ms:
        ...     for batch in dataloader:
        ...         loss = model(batch).loss
        ...         loss.backward()
        ...         optimizer.step()
        ...         optimizer.zero_grad()
    """
    if config is None:
        config = Config()

    profiler = MemoryProfiler(
        prefer_static=config.use_static_profiling,
        fallback_empirical=config.use_empirical_fallback,
    )

    hw = profiler.detect_hardware()
    graph = profiler.profile(model, sample_input)
    engine = DecisionEngine(config)
    plan = engine.decide(graph, hw)

    logger.info(plan.summary())

    executor = Executor(model, plan, config)
    executor.attach()

    try:
        yield executor
    finally:
        executor.detach()


def detach(model: nn.Module) -> None:
    """Remove MemScale optimization from a model.

    Args:
        model: Module previously wrapped with memscale.wrap()
    """
    if hasattr(model, "_memscale_executor"):
        model._memscale_executor.detach()
        delattr(model, "_memscale_executor")
        logger.info("MemScale detached from model")
    else:
        logger.warning("Model was not wrapped with MemScale — nothing to detach")