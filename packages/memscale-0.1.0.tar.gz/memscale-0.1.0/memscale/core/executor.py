"""Executor: applies optimization plan to a PyTorch model.

Uses PyTorch hooks to inject optimization behaviors without
modifying the model's forward code.
"""
from __future__ import annotations

import logging
from typing import Dict, List, Optional

import torch
import torch.nn as nn

from memscale.core.config import Config
from memscale.core.decision_engine import OptimizationPlan, Technique
from memscale.techniques.checkpointing import apply_checkpointing
from memscale.techniques.offloading import OffloadHook
from memscale.techniques.tiling import apply_tiling

logger = logging.getLogger(__name__)


class Executor:
    """Apply an optimization plan to a model via hooks.

    The executor is reversible — call detach() to remove all hooks
    and restore the model to its original state.
    """

    def __init__(self, model: nn.Module, plan: OptimizationPlan, config: Config):
        self.model = model
        self.plan = plan
        self.config = config

        # Track applied hooks/transformations so we can undo them
        self._hook_handles: List = []
        self._original_forwards: Dict[str, callable] = {}
        self._offload_hooks: List[OffloadHook] = []
        self._is_attached = False

    def attach(self) -> None:
        """Apply the optimization plan to the model.

        After calling this, the model's training behavior will use
        the configured optimization techniques.
        """
        if self._is_attached:
            logger.warning("Executor already attached — skipping")
            return

        checkpoint_count = 0
        offload_count = 0
        tile_count = 0

        for name, technique in self.plan.layer_techniques.items():
            if technique == Technique.KEEP:
                continue

            try:
                module = self._get_submodule(name)
            except AttributeError:
                logger.warning(f"Layer {name} not found in model — skipping")
                continue

            if technique == Technique.CHECKPOINT:
                self._apply_checkpoint(name, module)
                checkpoint_count += 1
            elif technique == Technique.OFFLOAD:
                self._apply_offload(name, module)
                offload_count += 1
            elif technique == Technique.TILE:
                self._apply_tile(name, module)
                tile_count += 1

        self._is_attached = True

        logger.info(
            f"MemScale attached: "
            f"{checkpoint_count} checkpointed, "
            f"{offload_count} offloaded, "
            f"{tile_count} tiled"
        )

    def detach(self) -> None:
        """Remove all hooks and restore the model to its original state."""
        if not self._is_attached:
            return

        # Remove forward hooks
        for handle in self._hook_handles:
            handle.remove()
        self._hook_handles.clear()

        # Restore original forward methods
        for name, original_forward in self._original_forwards.items():
            try:
                module = self._get_submodule(name)
                module.forward = original_forward
            except AttributeError:
                pass
        self._original_forwards.clear()

        # Cleanup offload hooks (restore tensors to GPU)
        for offload in self._offload_hooks:
            offload.cleanup()
        self._offload_hooks.clear()

        self._is_attached = False
        logger.info("MemScale detached")

    def _get_submodule(self, name: str) -> nn.Module:
        """Get a submodule by its dotted name."""
        return self.model.get_submodule(name)

    def _apply_checkpoint(self, name: str, module: nn.Module) -> None:
        """Apply activation checkpointing to a layer."""
        original_forward = module.forward
        self._original_forwards[name] = original_forward
        apply_checkpointing(module)

    def _apply_offload(self, name: str, module: nn.Module) -> None:
        """Apply CPU offloading to a layer."""
        offload = OffloadHook(module, name)
        offload.attach()
        self._offload_hooks.append(offload)
        self._hook_handles.extend(offload.handles)

    def _apply_tile(self, name: str, module: nn.Module) -> None:
        """Apply activation tiling to a layer."""
        original_forward = module.forward
        self._original_forwards[name] = original_forward
        apply_tiling(module)

    def __enter__(self):
        self.attach()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.detach()
        return False