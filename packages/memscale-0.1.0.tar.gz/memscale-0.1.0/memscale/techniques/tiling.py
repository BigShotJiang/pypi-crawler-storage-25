"""Activation tiling.

Splits a large activation tensor into chunks, processes them sequentially,
and concatenates the results. Reduces peak memory at the cost of slightly
less parallelism.

Most useful for attention layers and large feedforward networks where
the activation tensor is the dominant memory consumer.

Note: This is a simplified MVP implementation. Full implementation requires
layer-specific knowledge (attention vs FFN tile differently).
"""
from __future__ import annotations

import logging
from functools import wraps

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


def apply_tiling(module: nn.Module, num_tiles: int = 4) -> None:
    """Wrap a module's forward to process input in tiles.

    Best for layers where the first dimension (typically batch or seq) is large.

    Args:
        module: PyTorch module to wrap
        num_tiles: Number of tiles to split the batch dimension into
    """
    original_forward = module.forward

    @wraps(original_forward)
    def tiled_forward(*args, **kwargs):
        # Find the first tensor argument
        tensor_arg = None
        tensor_idx = -1
        for i, arg in enumerate(args):
            if isinstance(arg, torch.Tensor) and arg.dim() >= 2:
                tensor_arg = arg
                tensor_idx = i
                break

        if tensor_arg is None or tensor_arg.shape[0] < num_tiles:
            # Can't tile (no tensor or batch too small)
            return original_forward(*args, **kwargs)

        # Split along batch dimension
        chunks = torch.chunk(tensor_arg, num_tiles, dim=0)
        outputs = []

        for chunk in chunks:
            # Replace the tiled arg with the chunk
            new_args = list(args)
            new_args[tensor_idx] = chunk
            chunk_output = original_forward(*new_args, **kwargs)
            outputs.append(chunk_output)

        # Concatenate results
        if isinstance(outputs[0], torch.Tensor):
            return torch.cat(outputs, dim=0)
        elif isinstance(outputs[0], (tuple, list)):
            # Handle layers that return multiple outputs (e.g., attention)
            return tuple(
                torch.cat([o[i] for o in outputs], dim=0)
                if isinstance(outputs[0][i], torch.Tensor)
                else outputs[0][i]
                for i in range(len(outputs[0]))
            )
        else:
            return outputs[-1]

    module.forward = tiled_forward
    module._memscale_tiled = True
    logger.debug(f"Applied tiling (num_tiles={num_tiles}) to {type(module).__name__}")