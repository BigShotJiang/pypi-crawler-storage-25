"""Optimization techniques applied per-layer."""

from memscale.techniques.checkpointing import apply_checkpointing
from memscale.techniques.offloading import OffloadHook
from memscale.techniques.tiling import apply_tiling

__all__ = [
    "apply_checkpointing",
    "OffloadHook",
    "apply_tiling",
]