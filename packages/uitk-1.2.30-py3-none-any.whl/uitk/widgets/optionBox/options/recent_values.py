# !/usr/bin/python
# coding=utf-8
"""Recent Values option for OptionBox — shows a selectable history list."""

import os
from qtpy import QtWidgets, QtCore, QtGui
import pythontk as ptk
from ._options import ButtonOption


def _is_filesystem_path(value):
    """Return True if *value* looks like a filesystem path."""
    s = str(value)
    # Drive letter (C:/) or UNC (\\server) or absolute unix (/home)
    if len(s) >= 2 and s[1] == ":":
        return True
    if s.startswith("//") or s.startswith("\\\\"):
        return True
    if s.startswith("/"):
        return True
    return False


def _build_display_map_smart_path(values):
    """Build a display map by stripping the common directory prefix.

    Only engages when *all* values look like filesystem paths and there
    are at least two of them.  Falls back to ``None`` (use default
    truncation) otherwise.
    """
    str_values = [str(v) for v in values]
    if len(str_values) < 2 or not all(_is_filesystem_path(v) for v in str_values):
        return None

    normalized = [ptk.format_path(v) for v in str_values]
    try:
        prefix = os.path.commonpath(normalized)
    except ValueError:
        return None

    if not prefix:
        return None

    display_map = {}
    for raw, norm in zip(values, normalized):
        tail = norm[len(prefix) :].lstrip("/")
        display_map[raw] = f"\u2026/{tail}" if tail else str(raw)
    return display_map


def _normalize_value(value):
    """Normalize a value for comparison.

    Strips whitespace and, for path-like strings, normalizes separators
    and case so that ``C:/Dir`` and ``c:\\dir`` compare equal.
    """
    if isinstance(value, str):
        value = value.strip()
        if "/" in value or "\\" in value:
            value = ptk.format_path(value).lower()
    return value


class RecentValuesPopup(QtCore.QObject):
    """Popup that displays recent values using the Menu widget.

    Shows a list of previously used values that can be clicked to restore.
    """

    _MAX_DISPLAY_LENGTH = 120

    def __init__(self, parent=None, text_align="center"):
        super().__init__(parent)
        from uitk.widgets.menu import Menu

        self._parent_widget = parent
        self._text_align = text_align

        self._menu = Menu(
            parent=parent,
            trigger_button="none",
            position=None,
            add_header=False,
            add_footer=False,
            add_apply_button=False,
            hide_on_leave=True,
            match_parent_width=False,
        )
        self._menu.setMinimumWidth(150)
        menu_layout = self._menu._layout
        if menu_layout:
            menu_layout.setContentsMargins(1, 1, 1, 1)

        self._install_visibility_filters()

        self._on_value_selected = None
        self._on_value_removed = None

    @property
    def menu(self):
        """Get the underlying Menu widget."""
        return self._menu

    def _install_visibility_filters(self):
        """Install event filters on parent and ancestors to detect hide events."""
        self._watched_widgets = []
        widget = self._parent_widget
        while widget is not None:
            widget.installEventFilter(self)
            self._watched_widgets.append(widget)
            widget = widget.parent()

    def _remove_visibility_filters(self):
        """Remove event filters from watched widgets."""
        for widget in self._watched_widgets:
            try:
                widget.removeEventFilter(self)
            except RuntimeError:
                pass
        self._watched_widgets.clear()

    def eventFilter(self, watched, event):
        """Close popup when any parent widget is hidden or a window-ancestor moves."""
        et = event.type()
        if et == QtCore.QEvent.Hide:
            self.close()
        elif et == QtCore.QEvent.Move:
            try:
                if watched.isWindow():
                    self.close()
            except RuntimeError:
                pass
        return False

    def connect_signals(self, on_value_selected=None, on_value_removed=None):
        """Connect signal handlers."""
        self._on_value_selected = on_value_selected
        self._on_value_removed = on_value_removed

    def clear(self):
        self._menu.clear()

    def show(self):
        self._menu.show()

    def close(self):
        self._remove_visibility_filters()
        self._menu.hide()

    def move(self, pos):
        self._menu.move(pos)

    def adjustSize(self):
        self._menu.adjustSize()

    def width(self):
        return self._menu.width()

    def add_recent_value(self, value, is_current=False, display_text=None):
        """Add a recent-value row.

        Args:
            value: The raw value to store/restore.
            is_current: Whether this is the current widget value.
            display_text: Override text shown on the button.
                If ``None``, falls back to default truncation.
        """
        row = self._create_value_row(
            value, is_current=is_current, display_text=display_text
        )
        self._menu.add(row)

    def add_separator(self):
        separator = QtWidgets.QFrame()
        separator.setObjectName("recentValuesSeparator")
        separator.setFrameShape(QtWidgets.QFrame.HLine)
        separator.setFrameShadow(QtWidgets.QFrame.Sunken)
        separator.setFixedHeight(1)
        self._menu.add(separator)

    def add_empty_message(self):
        label = QtWidgets.QLabel("No recent values")
        label.setObjectName("recentValuesEmptyLabel")
        label.setAlignment(QtCore.Qt.AlignCenter)
        self._menu.add(label)

    def _create_value_row(self, value, is_current=False, display_text=None):
        from uitk.widgets.mixins.icon_manager import IconManager

        full_text = str(value)
        if display_text is None:
            display_text = ptk.truncate(
                full_text, self._MAX_DISPLAY_LENGTH, mode="middle"
            )

        container = QtWidgets.QWidget()
        container.setAttribute(QtCore.Qt.WA_TransparentForMouseEvents, False)
        container.setObjectName(
            "recentValueRow_current" if is_current else "recentValueRow"
        )
        layout = QtWidgets.QHBoxLayout(container)
        layout.setContentsMargins(1, 0, 8, 0)
        layout.setSpacing(4)

        # Value button — click to restore
        value_btn = QtWidgets.QPushButton(display_text)
        value_btn.setObjectName("recentValueButton")
        value_btn.setFlat(True)
        value_btn.setCursor(QtCore.Qt.PointingHandCursor)
        value_btn.clicked.connect(lambda: self._on_value_clicked(value))
        value_btn.setToolTip(full_text)
        if self._text_align == "left":
            value_btn.setStyleSheet("text-align: left; padding-left: 4px;")
        elif self._text_align == "right":
            value_btn.setStyleSheet("text-align: right; padding-right: 4px;")
        layout.addWidget(value_btn, 1)

        # Remove button
        remove_btn = QtWidgets.QPushButton()
        remove_btn.setObjectName("recentValueRemoveButton")
        remove_btn.setFixedSize(18, 18)
        remove_btn.setCursor(QtCore.Qt.PointingHandCursor)
        remove_btn.setFlat(True)
        IconManager.set_icon(remove_btn, "close", size=(10, 10))
        remove_btn.setToolTip("Remove from recent values")
        remove_btn.clicked.connect(lambda: self._on_remove_clicked(value))
        layout.addWidget(remove_btn)

        return container

    def _on_value_clicked(self, value):
        if self._on_value_selected:
            self._on_value_selected(value)
        self.close()

    def _on_remove_clicked(self, value):
        if self._on_value_removed:
            self._on_value_removed(value)


class RecentValuesOption(ButtonOption):
    """A history button that manages recent widget values.

    Clicking the button shows a dropdown of previously used values
    that can be restored with a single click.

    The list is populated automatically when ``record()`` is called
    (typically after a successful action like export), or values
    can be seeded programmatically via ``add_recent_value()``.

    Example::

        line_edit = QtWidgets.QLineEdit()
        recent = RecentValuesOption(line_edit, settings_key="my_recent")
        option_box = OptionBox(options=[recent])
        option_box.wrap(line_edit)

        # After user action:
        recent.record()  # saves current widget value
    """

    value_selected = QtCore.Signal(object)
    """Emitted when the user clicks a recent value to restore it."""

    def __init__(
        self,
        wrapped_widget=None,
        settings_key=None,
        max_recent=10,
        display_format="auto",
        popup_align="right",
        text_align="center",
        auto_record=False,
    ):
        """Initialize the recent values option.

        Args:
            wrapped_widget: The widget whose values to track.
            settings_key: Key for persistent storage.  If provided,
                recent values survive across sessions.
            max_recent: Maximum number of entries to keep.
            display_format: Controls how values appear in the popup.
                ``"auto"`` — strip common directory prefix when all
                values are filesystem paths; otherwise truncate.
                ``"truncate"`` — always use simple start-truncation
                (previous default behaviour).
                ``"basename"`` — show only the last path component.
                A callable ``(value) -> str`` for arbitrary formatting.
            popup_align: Horizontal alignment of the popup.
                ``"right"`` — align popup's right edge to the parent
                window's right edge (default).
                ``"left"`` — align popup's left edge to the wrapped widget.
            text_align: Text alignment for value labels in the popup.
                ``"center"`` (default), ``"left"``, or ``"right"``.
            auto_record: When True, automatically call ``record()`` when
                the wrapped widget commits a value:
                  - ``QLineEdit``: on ``editingFinished``
                  - widgets exposing a ``validated(bool, str)`` signal
                    (e.g. ``uitk.LineEdit`` with ``set_validator()``):
                    only when ``is_valid`` is True
                  - ``QComboBox``: on ``editTextChanged`` only when the
                    text matches an item (avoids per-keystroke noise).
                Off by default — callers must invoke ``record()`` from
                their own commit path (e.g. browse success, action).
        """
        super().__init__(
            wrapped_widget=wrapped_widget,
            icon="clock",
            tooltip="Recent values",
            callback=self._show_popup,
            checkable=True,
        )
        self._recent_values: list = []
        self._settings_key = settings_key
        self._max_recent = max_recent
        self._display_format = display_format
        self._popup_align = popup_align
        self._text_align = text_align
        self._popup = None
        self._settings = None
        self._auto_record = bool(auto_record)
        self._auto_record_connected = False

        if self._settings_key:
            self._init_settings()
            self._load_recent_values()

        if self._auto_record and wrapped_widget is not None:
            self._install_auto_record(wrapped_widget)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _init_settings(self):
        if self._settings is None and self._settings_key:
            from uitk.widgets.mixins.settings_manager import SettingsManager

            self._settings = SettingsManager(
                org="uitk", app="RecentValues", namespace=self._settings_key
            )

    def _save_recent_values(self):
        if not self._settings:
            return
        self._settings.setValue("entries", list(self._recent_values))
        self._settings.sync()

    def _load_recent_values(self):
        if not self._settings:
            return
        data = self._settings.value("entries", [])
        if not data:
            return
        # Deduplicate on load (keeps first occurrence = most recent)
        seen = set()
        deduped = []
        for v in data:
            if v is None:
                continue
            n = _normalize_value(v)
            if n not in seen:
                seen.add(n)
                deduped.append(v)
        self._recent_values = deduped
        if self._widget:
            self._update_button_tooltip()

    # ------------------------------------------------------------------
    # Widget creation
    # ------------------------------------------------------------------

    def create_widget(self):
        button = super().create_widget()
        if not button.objectName():
            button.setObjectName("recentButton")
        button.setProperty("class", "RecentButton")
        QtCore.QTimer.singleShot(0, self._update_button_tooltip)
        return button

    # ------------------------------------------------------------------
    # Popup
    # ------------------------------------------------------------------

    def _on_popup_hidden(self):
        self._popup = None
        self.block_next_click()
        self.set_checked(False)

    def _show_popup(self):
        if not self._widget.isChecked():
            if self._popup is not None:
                try:
                    self._popup.close()
                except RuntimeError:
                    pass
                self._popup = None
            return

        self._popup = RecentValuesPopup(
            parent=self.wrapped_widget, text_align=self._text_align
        )
        self._popup.menu.on_hidden.connect(self._on_popup_hidden)
        self._popup.connect_signals(
            on_value_selected=self._restore_value,
            on_value_removed=self._remove_value,
        )

        self._populate_popup()

        # Let the menu size to its natural sizeHint, clamped to the screen so
        # it can't run off-screen for very long values.
        window = self._find_parent_window()
        self._popup.menu.setMaximumWidth(self._screen_width_cap(window))
        self._popup.adjustSize()

        if self._widget:
            wrapped = self.wrapped_widget
            if wrapped:
                widget_rect = wrapped.rect()
                if self._popup_align == "right" and window:
                    # Align popup's right edge to the window's right edge
                    win_right = window.mapToGlobal(QtCore.QPoint(window.width(), 0)).x()
                    popup_x = win_right - self._popup.width() - 8
                    popup_y = wrapped.mapToGlobal(
                        QtCore.QPoint(0, widget_rect.height())
                    ).y()
                    global_pos = QtCore.QPoint(popup_x, popup_y)
                else:
                    global_pos = wrapped.mapToGlobal(
                        QtCore.QPoint(0, widget_rect.height())
                    )
            else:
                button_rect = self._widget.rect()
                global_pos = self._widget.mapToGlobal(
                    QtCore.QPoint(button_rect.right(), button_rect.bottom())
                )
                global_pos.setX(global_pos.x() - self._popup.width())

            self._popup.move(self._clamp_to_screen(global_pos, window))

        self._popup.show()

    def _screen_for_window(self, window):
        """Return the QScreen the popup will appear on (best effort)."""
        if window is not None:
            handle = window.windowHandle()
            if handle is not None and handle.screen() is not None:
                return handle.screen()
            screen = QtGui.QGuiApplication.screenAt(window.mapToGlobal(window.rect().center()))
            if screen is not None:
                return screen
        return QtGui.QGuiApplication.primaryScreen()

    def _screen_width_cap(self, window):
        """Maximum popup width — a little less than the target screen's width."""
        screen = self._screen_for_window(window)
        if screen is None:
            return 16777215  # Qt's QWIDGETSIZE_MAX
        return max(150, screen.availableGeometry().width() - 32)

    def _clamp_to_screen(self, global_pos, window):
        """Keep the popup inside the screen's available geometry."""
        screen = self._screen_for_window(window)
        if screen is None:
            return global_pos
        geo = screen.availableGeometry()
        w = self._popup.width()
        h = self._popup.menu.sizeHint().height()
        x = max(geo.left() + 4, min(global_pos.x(), geo.right() - w - 4))
        y = max(geo.top() + 4, min(global_pos.y(), geo.bottom() - h - 4))
        return QtCore.QPoint(x, y)

    def _populate_popup(self):
        if not self._popup:
            return

        self._popup.clear()

        current_value = self._get_widget_value()
        normalized_current = _normalize_value(current_value)
        has_current = current_value is not None and str(current_value).strip()

        # Recent values excluding the current one
        others = [
            v for v in self._recent_values if _normalize_value(v) != normalized_current
        ]

        # Build a display map for all visible values
        all_values = ([current_value] if has_current else []) + others
        display_map = self._resolve_display_map(all_values)

        # Show current value at the top if not empty
        if has_current:
            self._popup.add_recent_value(
                current_value,
                is_current=True,
                display_text=display_map.get(current_value),
            )
            self._popup.add_separator()

        for v in others:
            self._popup.add_recent_value(v, display_text=display_map.get(v))

        if not has_current and not others:
            self._popup.add_empty_message()

    def _resolve_display_map(self, values):
        """Return ``{raw_value: display_string}`` or empty dict."""
        fmt = self._display_format

        if callable(fmt):
            return {v: fmt(v) for v in values}

        if fmt == "basename":
            return {v: os.path.basename(str(v)) for v in values}

        if fmt == "auto":
            dm = _build_display_map_smart_path(values)
            if dm is not None:
                return dm
            # Fall through to default truncation (display_text=None)

        # "truncate" or auto-fallback — let the popup use its default
        return {}

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def _restore_value(self, value):
        self._set_widget_value(value)
        self.value_selected.emit(value)

    def _remove_value(self, value):
        normalized = _normalize_value(value)
        self._recent_values = [
            v for v in self._recent_values if _normalize_value(v) != normalized
        ]
        self._save_recent_values()
        self._update_button_tooltip()
        # Refresh popup in-place
        QtCore.QTimer.singleShot(0, self._refresh_popup_deferred)

    def _refresh_popup_deferred(self):
        if self._popup and self._popup.menu.isVisible():
            self._populate_popup()
            self._popup.adjustSize()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def record(self, value=None):
        """Record a value into the recent list.

        If *value* is ``None`` the current widget value is used.
        Duplicates are moved to the front (most-recent-first order).
        """
        if value is None:
            value = self._get_widget_value()
        if value is None or not str(value).strip():
            return

        normalized = _normalize_value(value)
        # Remove existing duplicate
        self._recent_values = [
            v for v in self._recent_values if _normalize_value(v) != normalized
        ]
        # Insert at front
        self._recent_values.insert(0, value)
        # Trim
        self._recent_values = self._recent_values[: self._max_recent]

        self._save_recent_values()
        self._update_button_tooltip()

    def add_recent_value(self, value):
        """Programmatically seed a recent value (appends if not duplicate)."""
        if value is None or not str(value).strip():
            return
        normalized = _normalize_value(value)
        if any(_normalize_value(v) == normalized for v in self._recent_values):
            return
        self._recent_values.append(value)
        if len(self._recent_values) > self._max_recent:
            self._recent_values = self._recent_values[-self._max_recent :]
        self._save_recent_values()
        self._update_button_tooltip()

    def set_wrapped_widget(self, widget):
        """Set or update the wrapped widget, re-installing auto-record if enabled."""
        super().set_wrapped_widget(widget)
        if self._auto_record and widget is not None and not self._auto_record_connected:
            self._install_auto_record(widget)

    def _install_auto_record(self, widget):
        """Wire up commit-time auto-recording for *widget*.

        Always prefers a true commit signal (``editingFinished`` or
        equivalent) over the live ``validated`` signal — recording on
        ``validated`` would still produce one entry per valid prefix as
        the user types (e.g. ``C:/Users``, ``C:/Users/foo``, ...).

        When the widget also exposes an ``is_valid`` property (e.g.
        ``uitk.LineEdit`` with a validator installed) the value is only
        recorded when it is not ``False``.  ``True`` and ``None`` (no
        validator set) both pass.

        Signals tried, in order:
            - ``editingFinished()`` (QLineEdit/QSpinBox/...)
            - ``activated(str)`` (QComboBox — fired on user selection)
        """
        if self._auto_record_connected:
            return

        editing_finished = getattr(widget, "editingFinished", None)
        if editing_finished is not None and hasattr(editing_finished, "connect"):
            editing_finished.connect(self._on_editing_finished_record)
            self._auto_record_connected = True
            return

        activated = getattr(widget, "activated", None)
        if activated is not None and hasattr(activated, "connect"):
            activated.connect(self._on_combo_activated_record)
            self._auto_record_connected = True
            return

    def _on_editing_finished_record(self):
        widget = self.wrapped_widget
        if widget is None:
            return
        # Flush any pending validator debounce so is_valid reflects current text
        validate_now = getattr(widget, "validate_now", None)
        if callable(validate_now):
            validate_now()
        if getattr(widget, "is_valid", None) is False:
            return
        self.record()

    def _on_combo_activated_record(self, *args):
        widget = self.wrapped_widget
        if widget is None:
            return
        # activated emits str in newer Qt, int in older; just use widget text
        text = widget.currentText() if hasattr(widget, "currentText") else None
        if text:
            self.record(text)

    @property
    def recent_values(self):
        """Return a copy of the recent values list (most-recent first)."""
        return list(self._recent_values)

    def clear_recent_values(self):
        """Clear all recent values."""
        self._recent_values.clear()
        self._save_recent_values()
        self._update_button_tooltip()

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _update_button_tooltip(self, *_args):
        if self._widget is None:
            return
        n = len(self._recent_values)
        if n:
            self._widget.setToolTip(f"Recent values ({n})")
        else:
            self._widget.setToolTip("Recent values")
