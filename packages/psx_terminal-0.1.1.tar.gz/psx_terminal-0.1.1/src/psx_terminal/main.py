"""
PSX Trading Terminal (CLI)

Realtime market feed dashboard for L1/L2 data using curses.
"""

from __future__ import annotations

import argparse
import curses
import json
import os
import socket
import threading
import time
import requests
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Set

# --- CONFIGURATION ---
HOST = "110.39.172.70"
PORT = 8484
DEFAULT_SYMBOLS = ["EFERT"]

FEED_CHOICES: Dict[str, List[str]] = {
    "1": ["L1"],
    "2": ["MBP"],
    "3": ["MBO"],
    "4": ["L1", "MBP", "MBO"],
}

import pathlib

DATA_DIR = pathlib.Path.home() / ".psx_terminal"
DATA_DIR.mkdir(parents=True, exist_ok=True)

WATCHLIST_FILE = DATA_DIR / "watchlist.json"
SYMBOL_CACHE_FILE = DATA_DIR / "symbol_cache.json"
SCRIP_URL = "http://web.ahletrade.com/pero/ScripServlet"

class SymbolManager:
    """Manages fetching, caching, and searching of valid symbols."""
    def __init__(self):
        self.symbols: List[dict] = []
        self.symbol_set: Set[str] = set()
        self.last_fetch = 0
        
    def load(self):
        """Load from cache or fetch from URL."""
        if os.path.exists(SYMBOL_CACHE_FILE):
            try:
                with open(SYMBOL_CACHE_FILE, 'r') as f:
                    data = json.load(f)
                    self.symbols = [s for s in data.get("symbols", []) if s.get("market") in ("REG", "ODL")]
                    self.symbol_set = {s["symbol"] for s in self.symbols}
                    self.last_fetch = data.get("timestamp", 0)
            except Exception:
                pass
        
        # Refresh if cache is older than 24 hours or empty
        if not self.symbols or (time.time() - self.last_fetch > 86400):
            threading.Thread(target=self.fetch, daemon=True).start()

    def fetch(self):
        """Fetch symbols from the API and save to cache."""
        try:
            resp = requests.get(SCRIP_URL, timeout=10)
            if resp.status_code == 200:
                raw_symbols = resp.json()
                self.symbols = [s for s in raw_symbols if s.get("market") in ("REG", "ODL")]
                self.symbol_set = {s["symbol"] for s in self.symbols}
                self.last_fetch = time.time()
                with open(SYMBOL_CACHE_FILE, 'w') as f:
                    json.dump({"symbols": self.symbols, "timestamp": self.last_fetch}, f)
        except Exception:
            pass

    def search(self, query: str) -> List[dict]:
        """Filter symbols based on query."""
        if not query:
            return []
        query = query.upper()
        matches = []
        for s in self.symbols:
            if s.get("market") not in ("REG", "ODL"):
                continue
            if s["symbol"].startswith(query) or query in s["symbolName"].upper():
                matches.append(s)
            if len(matches) >= 10: # Limit result count
                break
        return matches

    def is_valid(self, symbol: str) -> bool:
        return symbol.upper() in self.symbol_set

def save_watchlist(symbols: List[str]) -> None:
    """Save the watchlist to a JSON file."""
    try:
        with open(WATCHLIST_FILE, 'w') as f:
            json.dump(symbols, f)
    except Exception as e:
        # Silently fail for now, could add logging later
        pass

def load_watchlist() -> List[str]:
    """Load the watchlist from a JSON file."""
    if os.path.exists(WATCHLIST_FILE):
        try:
            with open(WATCHLIST_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return DEFAULT_SYMBOLS.copy()

TAB_LABELS = ["[1] Watchlist", "[2] Market Depth", "[3] Movers & Alerts"]

MKT_FIELDS = [
    "symbol", "market", "buy_volume", "buy", "sell", "sell_volume",
    "status", "dir", "change", "time", "last", "flag",
    "average", "high", "low", "trades", "volume",
    "last_trade_volume", "close", "open"
]

HTTP_FEED_BASE = "http://feed.ahletrade.com/HTTPFeedServer/FeedFetcher"

@dataclass
class Quote:
    time: str
    bid: float
    ask: float

@dataclass
class Trade:
    time: str
    price: float
    volume: int

def _parse_http_feed(raw: str) -> List[List[str]]:
    return [p.strip().split(";") for p in raw.split("|") if len(p.strip().split(";")) >= 3 and p.strip().split(";")[0]]

def fetch_quotes(symbol: str, market: str = "REG") -> List[Quote]:
    # NOTE: server uses identifier=BuySell for bid/ask quotes (counterintuitive naming)
    url = f"{HTTP_FEED_BASE}?action=Market&identifier=BuySell&market={market}&symbol={symbol}"
    raw = requests.get(url, timeout=10).text
    return [Quote(p[0], float(p[1]), float(p[2])) for p in _parse_http_feed(raw)]

def fetch_trades(symbol: str, market: str = "REG") -> List[Trade]:
    # NOTE: server uses identifier=PriceVolume for trade tape (counterintuitive naming)
    url = f"{HTTP_FEED_BASE}?action=Market&identifier=PriceVolume&market={market}&symbol={symbol}"
    raw = requests.get(url, timeout=10).text
    trades, prev = [], None
    for p in _parse_http_feed(raw):
        t = Trade(p[0], float(p[1]), int(float(p[2])))  # volume may arrive as float string
        if prev and t.price == prev.price and t.volume == prev.volume:
            continue
        trades.append(t)
        prev = t
    return trades


# --- STATE MODELS ---
@dataclass
class AppState:
    stop: bool = False
    connected: bool = False
    l1: Dict[str, dict] = field(default_factory=dict)
    mbp: Dict[str, dict] = field(default_factory=dict)
    mbo: Dict[str, dict] = field(default_factory=dict)
    stats: Dict[str, dict] = field(default_factory=dict)
    movers: Dict[str, list] = field(default_factory=dict)
    caps: List[str] = field(default_factory=list)
    error: str = ""
    symbol_manager: SymbolManager = field(default_factory=SymbolManager)
    # HTTP analytics feeds (keyed by symbol)
    quotes: Dict[str, List[Quote]] = field(default_factory=dict)
    trades: Dict[str, List[Trade]] = field(default_factory=dict)

@dataclass
class AppConfig:
    host: str
    port: int
    symbols: List[str]
    feeds: List[str]


# --- PARSING LOGIC ---
class FeedParser:
    """Handles parsing of all raw packet formats sent by the PSX Feed Server."""
    
    @staticmethod
    def parse_mkt_feed(payload: str) -> List[dict]:
        results = []
        for entry in payload.split("||"):
            entry = entry.strip()
            if entry:
                results.append(dict(zip(MKT_FIELDS, entry.split(";"))))
        return results

    @staticmethod
    def parse_mbp_feed(payload: str) -> Optional[dict]:
        parts = payload.split(";", 4)
        if len(parts) < 5:
            return None

        def parse_levels(s: str) -> List[dict]:
            s = s.split("|", 1)[0]
            levels = []
            for level in s.split("$"):
                p = level.split(",")
                if len(p) == 3:
                    try:
                        levels.append({"orders": int(p[0]), "qty": int(p[1]), "price": float(p[2])})
                    except (ValueError, IndexError):
                        continue
            return levels

        return {
            "symbol": parts[0], "market": parts[1],
            "bids": parse_levels(parts[3]),
            "asks": parse_levels(parts[4]),
        }

    @staticmethod
    def parse_mbo_feed(payload: str) -> Optional[dict]:
        parts = payload.split(";", 4)
        if len(parts) < 5:
            return None

        def parse_orders(s: str, side: str) -> List[dict]:
            s = s.split("|", 1)[0]
            orders = []
            for entry in s.split("$"):
                p = entry.split(",")
                if len(p) == 4:
                    try:
                        orders.append({
                            "price": float(p[0]), "qty": int(p[1]),
                            "flag": p[2], "side": side, "order_id": p[3]
                        })
                    except (ValueError, IndexError):
                        continue
            return orders

        return {
            "symbol": parts[0], "market": parts[1],
            "bids": parse_orders(parts[3], "bid"),
            "asks": parse_orders(parts[4], "ask"),
        }

    @staticmethod
    def parse_mkt_movers(payload: str) -> Dict[str, List[str]]:
        categories = payload.split("|")
        labels = ["top_volume_gainers", "top_price_gainers", "top_value", "most_traded", "top_losers"]
        result = {}
        for i, cat in enumerate(categories):
            cat = cat.strip()
            if cat:
                # Format is SYM:MKT;SYM:MKT...
                symbols = []
                for entry in cat.split(";"):
                    if ":" in entry:
                        sym, mkt = entry.split(":", 1)
                        if mkt in ("REG", "ODL"):
                            symbols.append(sym)
                if symbols:
                    label = labels[i] if i < len(labels) else f"category_{i}"
                    result[label] = symbols
        return result

    @staticmethod
    def parse_mkt_stats(payload: str) -> List[dict]:
        stats = []
        for segment in payload.rstrip("|").split("|"):
            parts = segment.split(";")
            if len(parts) >= 5:
                try:
                    mkt = parts[0]
                    if mkt in ("REG", "ODL"):
                        stats.append({
                            "market": mkt,
                            "status": parts[1],
                            "volume": float(parts[2]),
                            "trades": float(parts[3]),
                            "value": float(parts[4]),
                        })
                except (ValueError, IndexError):
                    continue
        return stats


# --- NETWORK CLIENT ---
class PSXClient:
    """Manages the TCP socket connection, subscriptions, and data ingestion."""
    
    def __init__(self, config: AppConfig, state: AppState):
        self.config = config
        self.state = state
        self.sock: Optional[socket.socket] = None
        self._threads: List[threading.Thread] = []

    def start(self) -> None:
        """Starts background threads for heartbeat and reading network streams."""
        self.connect()
        t1 = threading.Thread(target=self._heartbeat_loop, daemon=True)
        t2 = threading.Thread(target=self._receive_loop, daemon=True)
        t3 = threading.Thread(target=self._analytics_poll_loop, daemon=True)
        t1.start()
        t2.start()
        t3.start()
        self._threads.extend([t1, t2, t3])

    def _analytics_poll_loop(self) -> None:
        """Polls HTTP feed for quotes+trades for each symbol every 30s."""
        while not self.state.stop:
            for sym in list(self.config.symbols):
                base = sym.split(":")[0]
                market = sym.split(":")[1] if ":" in sym else "REG"
                try:
                    self.state.quotes[base] = fetch_quotes(base, market)
                except Exception:
                    pass
                try:
                    self.state.trades[base] = fetch_trades(base, market)
                except Exception:
                    pass
            # Sleep in small increments so stop flag is checked promptly
            for _ in range(30):
                if self.state.stop:
                    break
                time.sleep(1)

    def connect(self) -> None:
        try:
            self.sock = socket.create_connection((self.config.host, self.config.port), timeout=15)
            self.sock.settimeout(2)
            self.state.connected = True
            self.state.error = ""
        except Exception as e:
            self.state.connected = False
            self.state.error = f"Connection failed: {e}"

    def send(self, msg: str) -> None:
        if self.sock and self.state.connected:
            try:
                self.sock.sendall((msg + "%").encode())
            except Exception as e:
                self.state.connected = False
                self.state.error = f"Send error: {e}"

    def _heartbeat_loop(self) -> None:
        n = 1
        while not self.state.stop:
            if self.state.connected:
                self.send("HELLO|")
                self.send(f"MKT-COUNTER|{n}")
                n += 1
            time.sleep(3)

    def _receive_loop(self) -> None:
        buf = ""
        while not self.state.stop:
            if not self.state.connected:
                time.sleep(2)
                self.connect()  # Auto-reconnection logic
                continue

            try:
                if self.sock is None:
                    continue
                data = self.sock.recv(4096)
                if not data:
                    self.state.connected = False
                    self.state.error = "Connection dropped by server."
                    continue

                buf += data.decode("utf-8", errors="ignore")
                
                while "%" in buf:
                    msg, buf = buf.split("%", 1)
                    msg = msg.strip()
                    if not msg:
                        continue
                    self._handle_message(msg)

            except socket.timeout:
                continue
            except Exception as e:
                self.state.connected = False
                self.state.error = f"Receive error: {e}"

    def _handle_message(self, msg: str) -> None:
        if msg.startswith("Welcome"):
            # Subscribe to each symbol with its specified/default market
            sym_list = []
            for s in self.config.symbols:
                if ":" in s:
                    sym_list.append(s)
                else:
                    sym_list.append(f"{s}:REG")
            sym_str = ";".join(sym_list) + ";"
            
            if "L1" in self.config.feeds:
                self.send(f"MKT-FEED|{sym_str}")
            if "MBP" in self.config.feeds:
                self.send(f"MBP-FEED|{sym_str}")
            if "MBO" in self.config.feeds:
                self.send(f"MBO-FEED|{sym_str}")

        elif "L1" in self.config.feeds and msg.startswith("MKT-FEED*"):
            for e in FeedParser.parse_mkt_feed(msg[9:]):
                full_key = f"{e['symbol']}:{e['market']}"
                if full_key in self.config.symbols or e["symbol"] in self.config.symbols:
                    self.state.l1[full_key] = e
                    # For compatibility with existing UI code that uses just symbol name
                    if e["market"] == "REG":
                        self.state.l1[e["symbol"]] = e

        elif "MBP" in self.config.feeds and msg.startswith("MBP-FEED*"):
            for entry in msg[9:].split("||"):
                entry = entry.strip()
                if not entry: continue
                d = FeedParser.parse_mbp_feed(entry)
                if d:
                    full_key = f"{d['symbol']}:{d['market']}"
                    if full_key in self.config.symbols or d["symbol"] in self.config.symbols:
                        self.state.mbp[full_key] = d
                        if d["market"] == "REG":
                            self.state.mbp[d["symbol"]] = d

        elif "MBO" in self.config.feeds and msg.startswith("MBO-FEED*"):
            for entry in msg[9:].split("||"):
                entry = entry.strip()
                if not entry: continue
                d = FeedParser.parse_mbo_feed(entry)
                if d:
                    full_key = f"{d['symbol']}:{d['market']}"
                    if full_key in self.config.symbols or d["symbol"] in self.config.symbols:
                        self.state.mbo[full_key] = d
                        if d["market"] == "REG":
                            self.state.mbo[d["symbol"]] = d

        elif msg.startswith("MKT-Movers*") or msg.startswith("MKT-Shariah-Movers*"):
            offset = 19 if msg.startswith("MKT-Shariah") else 11
            movers = FeedParser.parse_mkt_movers(msg[offset:])
            for k, v in movers.items():
                self.state.movers[k] = v

        elif msg.startswith("MKT-STATS*") or msg.startswith("MKT-Shariah-STATS*"):
            offset = 18 if msg.startswith("MKT-Shariah") else 10
            stats = FeedParser.parse_mkt_stats(msg[offset:])
            for s in stats:
                self.state.stats[s["market"]] = s

        elif msg.startswith(("ADDUCAP*", "ADDLCAP*", "RUCAP*", "RLCAP*")):
            tag, rest = msg.split("*", 1)
            parts = rest.split(";")
            sym = parts[0] if parts else "?"
            
            # Filter alerts to only show for REG/ODL symbols
            if not self.state.symbol_manager.is_valid(sym):
                return
                
            price = parts[1] if len(parts) > 1 else "?"
            labels = {
                "ADDUCAP": "ALERT  UPPER CAP HIT",
                "RUCAP":   "INFO   UPPER CAP REM.",
                "ADDLCAP": "ALERT  LOWER LOCK HIT",
                "RLCAP":   "INFO   LOWER LOCK REM.",
            }
            alert = f"[{time.strftime('%H:%M:%S')}] {labels.get(tag, tag)} {sym} @ {price}"
            self.state.caps.insert(0, alert)
            if len(self.state.caps) > 50:
                self.state.caps.pop()

    def add_symbols(self, symbols: List[str]) -> None:
        processed_syms = []
        for s in symbols:
            s = s.strip().upper()
            if not s: continue
            # If no market specified, default to REG
            if ":" not in s: s = f"{s}:REG"
            processed_syms.append(s)
            
        if not processed_syms:
            return
            
        added = False
        for s in processed_syms:
            if s not in self.config.symbols:
                self.config.symbols.append(s)
                added = True
        
        sym_str = ";".join(processed_syms) + ";"
        if "L1" in self.config.feeds:
            self.send(f"MKT-FEED|{sym_str}")
        if "MBP" in self.config.feeds:
            self.send(f"MBP-FEED|{sym_str}")
        if "MBO" in self.config.feeds:
            self.send(f"MBO-FEED|{sym_str}")
        
        if added:
            save_watchlist(self.config.symbols)

    def remove_symbols(self, symbols: List[str]) -> None:
        removed = False
        for s in symbols:
            s = s.strip().upper()
            if s in self.config.symbols:
                self.config.symbols.remove(s)
                # Cleanup state
                self.state.l1.pop(s, None)
                self.state.mbp.pop(s, None)
                self.state.mbo.pop(s, None)
                if ":" in s:
                    base = s.split(":")[0]
                    # Only cleanup base key if no other market of same symbol is left
                    if not any(x.startswith(f"{base}:") for x in self.config.symbols):
                        self.state.l1.pop(base, None)
                        self.state.mbp.pop(base, None)
                        self.state.mbo.pop(base, None)
                removed = True
        
        if removed:
            save_watchlist(self.config.symbols)


# --- TERMINAL UI ---
class DashboardUI:
    """Encapsulates all curses drawing logic for the terminal interface."""
    
    def __init__(self, stdscr, state: AppState, config: AppConfig, client: PSXClient):
        self.stdscr = stdscr
        self.state = state
        self.config = config
        self.client = client
        self.feeds = config.feeds
        self.symbols = config.symbols
        self.active_tab = 0
        self.selected_idx = 0
        self.analytics_sub_tab = 0  # 0=Ladder 1=Chart 2=Summary 3=Flow
        self.tabs = ["[1] Overview", "[2] Watchlist", "[3] Symbol Details", "[4] Analytics", "[5] Movers & Alerts"]
        self.show_help = False
        
        self._setup_curses()

    def _setup_curses(self) -> None:
        # Some terminals (or non-interactive runs) do not support cursor changes.
        try:
            curses.curs_set(0) # Hide cursor
        except curses.error:
            pass
        self.stdscr.nodelay(1)  # Non-blocking input
        self.stdscr.timeout(200) # Auto refresh every 200ms
        self.stdscr.keypad(True)  # Enable arrow keys and function keys
        
        if curses.has_colors():
            curses.start_color()
            curses.use_default_colors()
            curses.init_pair(1, curses.COLOR_GREEN, -1)   # Positive / Buy
            curses.init_pair(2, curses.COLOR_RED, -1)     # Negative / Sell
            curses.init_pair(3, curses.COLOR_CYAN, -1)    # Highlights
            curses.init_pair(4, curses.COLOR_BLACK, curses.COLOR_WHITE) # Selected Item
            curses.init_pair(5, curses.COLOR_BLACK, curses.COLOR_YELLOW) # Warnings
            curses.init_pair(6, curses.COLOR_WHITE, curses.COLOR_BLUE)   # Header
            curses.init_pair(7, curses.COLOR_BLACK, curses.COLOR_CYAN)   # Active Tab
            curses.init_pair(8, curses.COLOR_WHITE, -1)                  # Neutral

    def safe_addstr(self, y: int, x: int, s: str, attr: int = 0) -> None:
        max_y, max_x = self.stdscr.getmaxyx()
        if 0 <= y < max_y and 0 <= x < max_x:
            avail = max_x - x - 1
            if avail <= 0:
                return
            try:
                self.stdscr.addstr(y, x, str(s)[:avail], attr)
            except curses.error:
                pass

    def _truncate(self, s: str, width: int) -> str:
        if width <= 0:
            return ""
        if len(s) <= width:
            return s
        if width <= 3:
            return s[:width]
        return s[: max(0, width - 3)] + "..."

    def _fmt_num(self, value: Optional[float], width: int, dec: int = 2, comma: bool = False) -> str:
        if value is None:
            return "".rjust(width)
        fmt = f"{{:{',' if comma else ''}.{dec}f}}"
        s = fmt.format(value)
        return s.rjust(width)

    def run(self) -> None:
        while not self.state.stop:
            self.handle_input()
            if self.state.stop:
                break
            self.draw()

    def handle_input(self) -> None:
        char = self.stdscr.getch()
        if char in (ord('q'), ord('Q'), 3):  # 3 is Ctrl+C
            self.state.stop = True
        elif char in (curses.KEY_RIGHT, 9): # 9 is Tab
            self.active_tab = (self.active_tab + 1) % len(self.tabs)
        elif char == curses.KEY_LEFT:
            self.active_tab = (self.active_tab - 1) % len(self.tabs)
        elif char == ord('1'): self.active_tab = 0
        elif char == ord('2'): self.active_tab = 1
        elif char == ord('3'): self.active_tab = 2
        elif char == ord('4'): self.active_tab = 3
        elif char == ord('5'): self.active_tab = 4
        elif self.active_tab == 3 and char in (ord('a'), ord('A')):
            self.analytics_sub_tab = 0
        elif self.active_tab == 3 and char in (ord('b'), ord('B')):
            self.analytics_sub_tab = 1
        elif self.active_tab == 3 and char in (ord('c'), ord('C')):
            self.analytics_sub_tab = 2
        elif self.active_tab == 3 and char in (ord('d'), ord('D')):
            self.analytics_sub_tab = 3
        elif self.active_tab == 3 and char in (ord('<'), ord(','), ord('[')):
            self.analytics_sub_tab = (self.analytics_sub_tab - 1) % 4
        elif self.active_tab == 3 and char in (ord('>'), ord('.'), ord(']')):
            self.analytics_sub_tab = (self.analytics_sub_tab + 1) % 4
        elif char in (curses.KEY_DOWN, ord('j'), ord('J')):
            if self.symbols:
                old_idx = self.selected_idx
                self.selected_idx = min(self.selected_idx + 1, len(self.symbols) - 1)
                if old_idx != self.selected_idx:
                    self.client.add_symbols([self.symbols[self.selected_idx]])
        elif char in (curses.KEY_UP, ord('k'), ord('K')):
            if self.symbols:
                old_idx = self.selected_idx
                self.selected_idx = max(self.selected_idx - 1, 0)
                if old_idx != self.selected_idx:
                    self.client.add_symbols([self.symbols[self.selected_idx]])
        elif char in (ord('/'), ord('s'), ord('S')):
            self._prompt_symbol()
        elif char in (ord('x'), ord('X')):
            if self.symbols and 0 <= self.selected_idx < len(self.symbols):
                target = self.symbols[self.selected_idx]
                self.client.remove_symbols([target])
                # Adjust selection if we're now out of bounds
                if self.selected_idx >= len(self.symbols):
                    self.selected_idx = max(0, len(self.symbols) - 1)
        elif char in (ord('?'), ord('h'), ord('H')):
            self.show_help = not self.show_help

    def draw(self) -> None:
        self.stdscr.erase()
        max_y, max_x = self.stdscr.getmaxyx()
        focus_sym = self.symbols[self.selected_idx] if self.symbols else None

        if max_x < 80 or max_y < 22:
            self.safe_addstr(0, 0, "Terminal too small. Resize to at least 80x22.", curses.color_pair(5) | curses.A_BOLD)
            self.safe_addstr(2, 0, f"Current size: {max_x}x{max_y}", curses.color_pair(3))
            self.stdscr.refresh()
            return
        
        self._draw_header(max_x)
        self._draw_tabs(max_x)
        
        row_y = 6
        if self.active_tab == 0:
            self._draw_overview(row_y, max_y, max_x, focus_sym)
        elif self.active_tab == 1:
            self._draw_watchlist(row_y, max_x)
        elif self.active_tab == 2:
            self._draw_symbol_details(row_y, max_y, max_x, focus_sym)
        elif self.active_tab == 3:
            self._draw_analytics(row_y, max_y, max_x, focus_sym)
        elif self.active_tab == 4:
            self._draw_movers_alerts(row_y, max_y, max_x)

        self._draw_footer(max_y, max_x)
        if self.show_help:
            self._draw_help(max_y, max_x)
        self.stdscr.refresh()

    def _draw_header(self, max_x: int) -> None:
        pak_time = time.strftime('%H:%M:%S', time.gmtime(time.time() + 5 * 3600))
        status_attr = curses.color_pair(6) | curses.A_BOLD if self.state.connected else curses.color_pair(5) | curses.A_BOLD

        left = "PSX TRADING TERMINAL"
        mid = f"Local: {time.strftime('%H:%M:%S')}"
        right = f"PSX: {pak_time}"
        header = f" {left} | {mid} | {right} "
        self.safe_addstr(0, 0, header.ljust(max_x), status_attr)

        stats_line = ""
        if self.state.stats:
            stats_line = " | ".join(
                f"{s['market']}: Vol {s.get('volume', 0):>9,.0f} Val {s.get('value', 0):>11,.0f}"
                for s in self.state.stats.values()
                if s.get("market") in ("REG", "ODL")
            )
        if self.state.error and not self.state.connected:
            stats_line = f"ERROR: {self.state.error}"
            
        self.safe_addstr(1, 0, stats_line, curses.A_DIM)
        self.safe_addstr(2, 0, "-" * max_x, curses.A_DIM)

    def _draw_tabs(self, max_x: int) -> None:
        tab_x = 0
        for i, t in enumerate(self.tabs):
            attr = curses.color_pair(7) | curses.A_BOLD if i == self.active_tab else curses.color_pair(3)
            self.safe_addstr(3, tab_x, f" {t} ", attr)
            tab_x += len(t) + 3
        self.safe_addstr(4, 0, "=" * max_x, curses.A_DIM)

    def _draw_watchlist(self, start_y: int, max_x: int) -> None:
        row_y = start_y
        col_sym = 10
        col_last = 9
        col_chg = 7
        col_bid = 9
        col_ask = 9
        col_vol = 11
        col_hi = 9
        col_lo = 9

        header = (
            f" {'SYMBOL':<{col_sym}} |"
            f" {'LAST':>{col_last}} {'CHG':>{col_chg}} |"
            f" {'BID':>{col_bid}} {'ASK':>{col_ask}} |"
            f" {'VOL':>{col_vol}} |"
            f" {'HIGH':>{col_hi}} {'LOW':>{col_lo}}"
        )
        self.safe_addstr(row_y, 0, header, curses.color_pair(3) | curses.A_BOLD)
        row_y += 1
        self.safe_addstr(row_y, 0, " " + "-" * (min(max_x - 2, 78)), curses.A_DIM)
        row_y += 1
        
        for i, sym in enumerate(self.symbols):
            is_sel = (i == self.selected_idx)
            base_attr = curses.color_pair(4) if is_sel else (curses.A_DIM if i % 2 else curses.A_NORMAL)
            e = self.state.l1.get(sym)
            
            if e:
                try:
                    last = float(e.get('last', 0) or 0)
                    chg = float(e.get('change', 0) or 0)
                    buy = float(e.get('buy', 0) or 0)
                    sell = float(e.get('sell', 0) or 0)
                    vol = float(e.get('volume', 0) or 0)
                    high = float(e.get('high', 0) or 0)
                    low = float(e.get('low', 0) or 0)
                    
                    sym_attr = base_attr
                    if not is_sel:
                        if chg > 0: sym_attr = curses.color_pair(1)
                        elif chg < 0: sym_attr = curses.color_pair(2)
                        
                    line = (
                        f" {sym:<{col_sym}} |"
                        f" {last:>{col_last}.2f} {chg:>{col_chg}.2f} |"
                        f" {buy:>{col_bid}.2f} {sell:>{col_ask}.2f} |"
                        f" {vol:>{col_vol},.0f} |"
                        f" {high:>{col_hi}.2f} {low:>{col_lo}.2f}"
                    )
                    self.safe_addstr(row_y, 0, line, sym_attr)
                except Exception:
                    self.safe_addstr(row_y, 0, f" {sym:<10} | Data parse error", base_attr)
            else:
                status = "Waiting for data..." if self.state.connected else "Offline"
                self.safe_addstr(row_y, 0, f" {sym:<10} | {status}", base_attr)
            row_y += 1

    def _draw_symbol_details(self, start_y: int, max_y: int, max_x: int, focus_sym: Optional[str]) -> None:
        row_y = start_y
        if not focus_sym:
            self.safe_addstr(row_y, 2, "No symbols configured. Press / to add one.", curses.color_pair(5) | curses.A_BOLD)
            return

        self.safe_addstr(row_y, 2, f"SYMBOL FOCUS: {focus_sym}  (Press / to change)", curses.color_pair(3) | curses.A_BOLD)
        row_y += 2
        
        e = self.state.l1.get(focus_sym)
        if e:
            try:
                last = float(e.get('last', 0) or 0)
                chg = float(e.get('change', 0) or 0)
                buy = float(e.get('buy', 0) or 0)
                sell = float(e.get('sell', 0) or 0)
                vol = float(e.get('volume', 0) or 0)
                high = float(e.get('high', 0) or 0)
                low = float(e.get('low', 0) or 0)
                trades = float(e.get('trades', 0) or 0)
                open_px = float(e.get('open', 0) or 0)
                
                attr = curses.color_pair(1) if chg > 0 else (curses.color_pair(2) if chg < 0 else curses.A_NORMAL)
                summary = f"Last: {last:.2f} | Chg: {chg:.2f} | Open: {open_px:.2f} | High: {high:.2f} | Low: {low:.2f}"
                summary2 = f"Vol: {vol:,.0f} | Trades: {trades:,.0f} | Best Bid: {buy:.2f} | Best Ask: {sell:.2f}"
                self.safe_addstr(row_y, 2, summary, attr)
                row_y += 1
                self.safe_addstr(row_y, 2, summary2, curses.A_DIM)
            except Exception:
                self.safe_addstr(row_y, 2, "Data parse error", curses.color_pair(5))
        else:
            self.safe_addstr(row_y, 2, "Waiting for L1 data...", curses.A_DIM)
        row_y += 2

        has_mbo = "MBO" in self.feeds and focus_sym in self.state.mbo
        has_mbp = "MBP" in self.feeds and focus_sym in self.state.mbp
        
        d_mbp = self.state.mbp.get(focus_sym) if has_mbp else None
        d_mbo = self.state.mbo.get(focus_sym) if has_mbo else None

        show_side_by_side = (has_mbo and has_mbp and max_x >= 110)

        if not has_mbo and not has_mbp:
            self.safe_addstr(row_y, 2, "Waiting for Order Book Data... Ensure MBO or MBP feed is selected.", curses.A_DIM)
            return

        book_y = row_y
        
        if show_side_by_side:
            self.safe_addstr(book_y, 2, "MARKET BY PRICE (AGGREGATED)", curses.color_pair(3) | curses.A_BOLD)
            self.safe_addstr(book_y, 55, "MARKET BY ORDER (GRANULAR)", curses.color_pair(3) | curses.A_BOLD)
            book_y += 1
            
            mbp_hdr = f"{'Orders':>6} {'Shares':>8} {'Bid':>10}  |  {'Ask':>10} {'Shares':>8} {'Orders':>6}"
            mbo_hdr = f"{'Flag':>4} {'Shares':>8} {'Bid':>10}  |  {'Ask':>10} {'Shares':>8} {'Flag':>4}"
            
            self.safe_addstr(book_y, 2, mbp_hdr, curses.A_DIM)
            self.safe_addstr(book_y, 55, mbo_hdr, curses.A_DIM)
            book_y += 1
            
            self.safe_addstr(book_y, 2, "-" * 51, curses.A_DIM)
            self.safe_addstr(book_y, 55, "-" * 49, curses.A_DIM)
            book_y += 1
            
            max_lvl_mbp = max(len(d_mbp["bids"]), len(d_mbp["asks"])) if d_mbp else 0
            max_lvl_mbo = max(len(d_mbo["bids"]), len(d_mbo["asks"])) if d_mbo else 0
            lines_to_draw = min(max(max_lvl_mbp, max_lvl_mbo), max_y - book_y - 2)
            
            for i in range(lines_to_draw):
                row_attr = curses.A_DIM if i % 2 else curses.A_NORMAL
                
                if i < max_lvl_mbp:
                    b = d_mbp["bids"][i] if i < len(d_mbp["bids"]) else None
                    a = d_mbp["asks"][i] if i < len(d_mbp["asks"]) else None
                    if b: 
                        self.safe_addstr(book_y, 2, f"{b['orders']:>6} {b['qty']:>8} ")
                        self.safe_addstr(book_y, 17, f"{b['price']:>10.2f}", curses.color_pair(1) | row_attr)
                    if b or a: self.safe_addstr(book_y, 27, "  |  ", row_attr)
                    if a:
                        self.safe_addstr(book_y, 32, f"{a['price']:>10.2f}", curses.color_pair(2) | row_attr)
                        self.safe_addstr(book_y, 42, f" {a['qty']:>8} {a['orders']:>6}", row_attr)
                        
                if i < max_lvl_mbo:
                    b = d_mbo["bids"][i] if i < len(d_mbo["bids"]) else None
                    a = d_mbo["asks"][i] if i < len(d_mbo["asks"]) else None
                    if b: 
                        self.safe_addstr(book_y, 55, f"{b['flag']:>4} {b['qty']:>8} ")
                        self.safe_addstr(book_y, 68, f"{b['price']:>10.2f}", curses.color_pair(1) | row_attr)
                    if b or a: self.safe_addstr(book_y, 78, "  |  ", row_attr)
                    if a:
                        self.safe_addstr(book_y, 83, f"{a['price']:>10.2f}", curses.color_pair(2) | row_attr)
                        self.safe_addstr(book_y, 93, f" {a['qty']:>8} {a['flag']:>4}", row_attr)
                        
                book_y += 1
                
        else:
            if has_mbp:
                self.safe_addstr(book_y, 2, "MARKET BY PRICE (AGGREGATED LVL 2)", curses.color_pair(3) | curses.A_BOLD)
                book_y += 1
                self.safe_addstr(book_y, 2, f"{'Orders':>6} {'Shares':>8} {'Bid':>10}    |    {'Ask':>10} {'Shares':>8} {'Orders':>6}", curses.A_DIM)
                book_y += 1
                self.safe_addstr(book_y, 2, "-" * 60, curses.A_DIM)
                book_y += 1
                
                max_lvl = max(len(d_mbp["bids"]), len(d_mbp["asks"]))
                space_avail = (max_y - book_y - 2)
                mbp_space = (space_avail // 2 - 2) if has_mbo else space_avail
                lines = min(max_lvl, max(2, mbp_space))
                
                for i in range(lines):
                    if book_y >= max_y - 2: break
                    b = d_mbp["bids"][i] if i < len(d_mbp["bids"]) else None
                    a = d_mbp["asks"][i] if i < len(d_mbp["asks"]) else None
                    row_attr = curses.A_DIM if i % 2 else curses.A_NORMAL
                    
                    if b: 
                        self.safe_addstr(book_y, 2, f"{b['orders']:>6} {b['qty']:>8} ")
                        self.safe_addstr(book_y, 17, f"{b['price']:>10.2f}", curses.color_pair(1) | row_attr)
                    if b or a: self.safe_addstr(book_y, 27, "    |    ", row_attr)
                    if a:
                        self.safe_addstr(book_y, 36, f"{a['price']:>10.2f}", curses.color_pair(2) | row_attr)
                        self.safe_addstr(book_y, 46, f" {a['qty']:>8} {a['orders']:>6}", row_attr)
                    book_y += 1
                
                book_y += 1

            if has_mbo:
                if book_y < max_y - 5:
                    self.safe_addstr(book_y, 2, "MARKET BY ORDER (GRANULAR LVL 3)", curses.color_pair(3) | curses.A_BOLD)
                    book_y += 1
                    self.safe_addstr(book_y, 2, f"{'Flag':>4} {'Shares':>8} {'Bid':>10}      |      {'Ask':>10} {'Shares':>8} {'Flag':>4}", curses.A_DIM)
                    book_y += 1
                    self.safe_addstr(book_y, 2, "-" * 60, curses.A_DIM)
                    book_y += 1
                    
                    max_lvl = max(len(d_mbo["bids"]), len(d_mbo["asks"]))
                    space_avail = max_y - book_y - 2
                    
                    for i in range(min(max_lvl, space_avail)):
                        b = d_mbo["bids"][i] if i < len(d_mbo["bids"]) else None
                        a = d_mbo["asks"][i] if i < len(d_mbo["asks"]) else None
                        row_attr = curses.A_DIM if i % 2 else curses.A_NORMAL
                        
                        if b: 
                            self.safe_addstr(book_y, 2, f"{b['flag']:>4} {b['qty']:>8} ")
                            self.safe_addstr(book_y, 15, f"{b['price']:>10.2f}", curses.color_pair(1) | row_attr)
                        if b or a: self.safe_addstr(book_y, 25, "      |      ", row_attr)
                        if a:
                            self.safe_addstr(book_y, 38, f"{a['price']:>10.2f}", curses.color_pair(2) | row_attr)
                            self.safe_addstr(book_y, 48, f" {a['qty']:>8} {a['flag']:>4}", row_attr)
                        book_y += 1

    def _draw_movers_alerts(self, start_y: int, max_y: int, max_x: int) -> None:
        row_y = start_y
        col1 = 2
        col2 = int(max_x / 2)
        
        self.safe_addstr(row_y, col1, "MARKET MOVERS", curses.color_pair(3) | curses.A_BOLD)
        self.safe_addstr(row_y, col2, "CIRCUIT BREAKERS & ALERTS", curses.color_pair(3) | curses.A_BOLD)
        row_y += 2
        
        r = row_y
        for cat, syms in self.state.movers.items():
            if r >= max_y - 3: break
            self.safe_addstr(r, col1, f"{cat.replace('_', ' ').title()}:")
            r += 1
            self.safe_addstr(r, col1 + 2, ", ".join(syms[:6]), curses.A_BOLD)
            r += 2
            
        r = row_y
        for alert in self.state.caps:
            if r >= max_y - 3: break
            attr = curses.color_pair(2) if "HIT" in alert else curses.color_pair(1)
            self.safe_addstr(r, col2, alert, attr)
            r += 1

    def _draw_analytics(self, start_y: int, max_y: int, max_x: int, focus_sym: Optional[str]) -> None:
        if not focus_sym:
            self.safe_addstr(start_y, 2, "No symbol selected.", curses.A_DIM)
            return
        base = focus_sym.split(":")[0]
        trades = self.state.trades.get(base, [])
        quotes = self.state.quotes.get(base, [])

        # Sub-tab bar
        sub_labels = ["[A] Price Ladder", "[B] Intraday Chart", "[C] Session Summary", "[D] Trade Flow"]
        x = 2
        for i, lbl in enumerate(sub_labels):
            attr = curses.color_pair(7) | curses.A_BOLD if i == self.analytics_sub_tab else curses.color_pair(3)
            self.safe_addstr(start_y, x, f" {lbl} ", attr)
            x += len(lbl) + 3
        self.safe_addstr(start_y, x, " — Press [A]-[D] or use [<]/[>] to cycle", curses.A_DIM)
        self.safe_addstr(start_y + 1, 2, f"{'─' * (max_x - 4)}", curses.A_DIM)

        content_y = start_y + 2
        if not trades and not quotes:
            self.safe_addstr(content_y, 2, "Fetching data... (refreshes every 30s)", curses.A_DIM)
            return

        if self.analytics_sub_tab == 0:
            self._draw_price_ladder(content_y, max_y, max_x, base, trades, quotes)
        elif self.analytics_sub_tab == 1:
            self._draw_intraday_chart(content_y, max_y, max_x, base, trades)
        elif self.analytics_sub_tab == 2:
            self._draw_session_summary(content_y, max_y, max_x, base, trades, quotes)
        else:
            self._draw_trade_flow(content_y, max_y, max_x, base, trades)

    def _draw_price_ladder(self, y: int, max_y: int, max_x: int, base: str,
                           trades: List[Trade], quotes: List[Quote]) -> None:
        if not quotes:
            self.safe_addstr(y, 2, "No quote data.", curses.A_DIM); return

        last_q = next((q for q in reversed(quotes) if q.bid > 0 and q.ask >= q.bid), None)
        if not last_q:
            self.safe_addstr(y, 2, "No valid quotes.", curses.A_DIM); return

        mid_price = (last_q.bid + last_q.ask) / 2
        tick = 0.01
        rows = max_y - y - 3
        half = rows // 2

        # Build volume-at-price map — use round(,2) to avoid float precision issues
        vap: Dict[float, int] = {}
        for t in trades:
            k = round(t.price, 2)
            vap[k] = vap.get(k, 0) + t.volume
        max_vap = max(vap.values()) if vap else 1

        bar_w = (max_x - 30) // 2
        self.safe_addstr(y, 2, f"{'BID VOL':>{bar_w}}  {'PRICE':^8}  {'ASK VOL':<{bar_w}}  TRADED", curses.A_DIM)
        y += 1

        for i in range(rows):
            price = round((mid_price + (half - i) * tick) / tick) * tick
            price = round(price, 2)
            is_bid = price <= last_q.bid
            is_ask = price >= last_q.ask
            traded_vol = vap.get(round(price, 2), 0)

            bar_len = int(traded_vol / max_vap * bar_w) if traded_vol else 0
            traded_bar = "█" * bar_len

            if is_bid:
                price_attr = curses.color_pair(1) | curses.A_BOLD
                bid_bar = "▓" * min(bar_w, max(1, bar_len or 2))
                ask_bar = ""
            elif is_ask:
                price_attr = curses.color_pair(2) | curses.A_BOLD
                bid_bar = ""
                ask_bar = "▓" * min(bar_w, max(1, bar_len or 2))
            else:
                price_attr = curses.A_DIM
                bid_bar = ask_bar = ""

            self.safe_addstr(y, 2, f"{bid_bar:>{bar_w}}", curses.color_pair(1))
            self.safe_addstr(y, 2 + bar_w + 1, f"{price:^8.2f}", price_attr)
            self.safe_addstr(y, 2 + bar_w + 10, f"{ask_bar:<{bar_w}}", curses.color_pair(2))
            if traded_vol:
                self.safe_addstr(y, 2 + bar_w * 2 + 12, f"{traded_vol:,}", curses.A_DIM)
            y += 1
            if y >= max_y - 2: break

    def _draw_intraday_chart(self, y: int, max_y: int, max_x: int, base: str,
                             trades: List[Trade]) -> None:
        if not trades:
            self.safe_addstr(y, 2, "No trade data.", curses.A_DIM); return

        total_vol = sum(t.volume for t in trades)
        vwap = sum(t.price * t.volume for t in trades) / total_vol if total_vol else 0
        prices = [t.price for t in trades]
        p_min, p_max = min(prices), max(prices)
        p_range = p_max - p_min or 0.01

        chart_h = max_y - y - 5
        chart_w = max_x - 10
        if chart_h < 4 or chart_w < 10:
            self.safe_addstr(y, 2, "Terminal too small for chart.", curses.A_DIM); return

        # Sample prices and vwap to chart_w columns
        step = max(1, len(trades) // chart_w)
        sampled = trades[::step][:chart_w]

        def to_row(price: float) -> int:
            return chart_h - 1 - int((price - p_min) / p_range * (chart_h - 1))

        # Build grid
        grid = [[" "] * chart_w for _ in range(chart_h)]
        running_pv = running_v = 0.0
        for col, t in enumerate(sampled):
            running_pv += t.price * t.volume
            running_v += t.volume
            row = max(0, min(chart_h - 1, to_row(t.price)))
            grid[row][col] = "•"
            vwap_here = running_pv / running_v if running_v else vwap
            vrow = max(0, min(chart_h - 1, to_row(vwap_here)))
            if grid[vrow][col] == " ":
                grid[vrow][col] = "─"

        # Draw y-axis labels + grid
        for r in range(chart_h):
            price_at_row = p_max - (r / (chart_h - 1)) * p_range
            label = f"{price_at_row:>7.2f} │"
            self.safe_addstr(y + r, 0, label, curses.A_DIM)
            row_str = "".join(grid[r])
            for col, ch in enumerate(row_str):
                attr = curses.color_pair(1) if ch == "•" else curses.color_pair(3) if ch == "─" else curses.A_DIM
                self.safe_addstr(y + r, 9 + col, ch, attr)

        # X-axis time labels
        ax_y = y + chart_h
        self.safe_addstr(ax_y, 9, "─" * chart_w, curses.A_DIM)
        if sampled:
            self.safe_addstr(ax_y + 1, 9, sampled[0].time, curses.A_DIM)
            if len(sampled) > 1:
                mid_lbl = sampled[len(sampled) // 2].time
                self.safe_addstr(ax_y + 1, 9 + chart_w // 2 - 4, mid_lbl, curses.A_DIM)
                self.safe_addstr(ax_y + 1, 9 + chart_w - 8, sampled[-1].time, curses.A_DIM)
        self.safe_addstr(ax_y + 2, 2,
            f"● price   ─ VWAP {vwap:.2f}   range {p_min:.2f}─{p_max:.2f}", curses.A_DIM)

    def _draw_session_summary(self, y: int, max_y: int, max_x: int, base: str,
                              trades: List[Trade], quotes: List[Quote]) -> None:
        col2 = max_x // 2

        def row(label: str, value: str, cy: int, cx: int = 2, attr: int = curses.A_NORMAL) -> None:
            self.safe_addstr(cy, cx, f"{label:<28}", curses.A_DIM)
            self.safe_addstr(cy, cx + 28, value, attr)

        self.safe_addstr(y, 2, f"SESSION SUMMARY  —  {base}", curses.color_pair(3) | curses.A_BOLD)
        y += 2

        if trades:
            total_vol = sum(t.volume for t in trades)
            vwap = sum(t.price * t.volume for t in trades) / total_vol if total_vol else 0
            prices = [t.price for t in trades]
            hi, lo = max(prices), min(prices)
            hi_time = next(t.time for t in trades if t.price == hi)
            lo_time = next(t.time for t in trades if t.price == lo)
            open_p, close_p = trades[0].price, trades[-1].price
            avg_size = total_vol / len(trades)
            largest = max(trades, key=lambda t: t.volume)
            chg = close_p - open_p
            chg_attr = curses.color_pair(1) if chg >= 0 else curses.color_pair(2)

            row("Open",            f"{open_p:.2f}",                  y);     y += 1
            row("Close (last)",    f"{close_p:.2f}",                 y);     y += 1
            row("Change",         f"{chg:+.2f}  ({chg/open_p*100:+.2f}%)", y, attr=chg_attr); y += 1
            row("High",           f"{hi:.2f}  @ {hi_time}",          y, attr=curses.color_pair(1)); y += 1
            row("Low",            f"{lo:.2f}  @ {lo_time}",          y, attr=curses.color_pair(2)); y += 1
            row("VWAP",           f"{vwap:.2f}",                     y, attr=curses.A_BOLD); y += 1
            row("Total Volume",   f"{total_vol:,}",                  y);     y += 1
            row("Total Trades",   f"{len(trades):,}",                y);     y += 1
            row("Avg Trade Size", f"{avg_size:,.1f}",                y);     y += 1
            row("Largest Trade",  f"{largest.volume:,} @ {largest.price:.2f}  {largest.time}", y, attr=curses.A_BOLD); y += 1

        y += 1
        if quotes:
            valid_q = [q for q in quotes if q.bid > 0 and q.ask > 0]
            if valid_q:
                # Exclude pre-open crossed markets (bid > ask) from spread stats
                spreads = [q.ask - q.bid for q in valid_q if q.ask >= q.bid]
                self.safe_addstr(y, 2, "QUOTE STATS", curses.color_pair(3) | curses.A_BOLD); y += 1
                row("Avg Spread",  f"{sum(spreads)/len(spreads):.3f}", y); y += 1
                row("Min Spread",  f"{min(spreads):.3f}",              y); y += 1
                row("Max Spread",  f"{max(spreads):.3f}",              y); y += 1
                row("Quote Updates", f"{len(valid_q):,}",              y); y += 1
                last_q = valid_q[-1]
                row("Last Bid/Ask", f"{last_q.bid:.2f} / {last_q.ask:.2f}", y); y += 1

    def _draw_trade_flow(self, y: int, max_y: int, max_x: int, base: str,
                         trades: List[Trade]) -> None:
        if not trades:
            self.safe_addstr(y, 2, "No trade data.", curses.A_DIM); return

        self.safe_addstr(y, 2, "TRADE FLOW HEATMAP  (5-min buckets)", curses.color_pair(3) | curses.A_BOLD)
        y += 2

        # Build 5-min buckets
        buckets: Dict[str, dict] = {}
        for t in trades:
            h, m, s = t.time.split(":")
            bucket_min = (int(m) // 5) * 5
            key = f"{h}:{bucket_min:02d}"
            if key not in buckets:
                buckets[key] = {"vol": 0, "pv": 0.0, "first": t.price, "last": t.price}
            buckets[key]["vol"] += t.volume
            buckets[key]["pv"] += t.price * t.volume
            buckets[key]["last"] = t.price

        sorted_keys = sorted(buckets.keys())
        if not sorted_keys: return

        max_vol = max(b["vol"] for b in buckets.values())
        shades_up   = " ░▒▓█"
        shades_down = " ░▒▓█"

        # How many buckets fit per row
        per_row = max_x - 12
        chunks = [sorted_keys[i:i+per_row] for i in range(0, len(sorted_keys), per_row)]

        for chunk in chunks:
            if y >= max_y - 5: break
            # Color row
            for k in chunk:
                b = buckets[k]
                vwap_b = b["pv"] / b["vol"] if b["vol"] else b["first"]
                intensity = min(4, int(b["vol"] / max_vol * 4))
                going_up = b["last"] >= b["first"]
                ch = (shades_up if going_up else shades_down)[intensity]
                attr = curses.color_pair(1) if going_up else curses.color_pair(2)
                self.safe_addstr(y, 10 + chunk.index(k), ch, attr)

            # Volume bar row below
            self.safe_addstr(y + 1, 10, "")
            vol_blocks = "▁▂▃▄▅▆▇█"
            for i, k in enumerate(chunk):
                b = buckets[k]
                vi = min(7, int(b["vol"] / max_vol * 7))
                self.safe_addstr(y + 1, 10 + i, vol_blocks[vi], curses.A_DIM)

            # Time labels
            self.safe_addstr(y + 2, 10, chunk[0], curses.A_DIM)
            if len(chunk) > 1:
                self.safe_addstr(y + 2, 10 + len(chunk) - 8, chunk[-1], curses.A_DIM)
            y += 4

        # Legend
        if y < max_y - 3:
            self.safe_addstr(y, 2, "█ green=up  █ red=down  intensity=volume  ▁▂▃▄▅▆▇█ vol bar", curses.A_DIM)


    def _draw_footer(self, max_y: int, max_x: int) -> None:
        footer_text = " [1-5] Tabs  |  Left/Right  |  Up/Down Symbol  |  / Search  |  X Remove  |  ? Help  |  Q Quit "
        self.safe_addstr(max_y - 1, 0, footer_text.center(max_x), curses.A_REVERSE)

    def _draw_overview(self, start_y: int, max_y: int, max_x: int, focus_sym: Optional[str]) -> None:
        row_y = start_y
        self.safe_addstr(row_y, 2, "MARKET OVERVIEW", curses.color_pair(3) | curses.A_BOLD)
        row_y += 2

        # Market stats summary
        if self.state.stats:
            self.safe_addstr(row_y, 2, "MARKET STATS", curses.A_BOLD)
            row_y += 1
            for s in self.state.stats.values():
                if s.get("market") not in ("REG", "ODL"):
                    continue
                line = f"{s['market']:<6} Vol {s.get('volume', 0):>12,.0f}  Trades {s.get('trades', 0):>8,.0f}  Val {s.get('value', 0):>12,.0f}"
                self.safe_addstr(row_y, 4, line)
                row_y += 1
            row_y += 1
        else:
            self.safe_addstr(row_y, 2, "Waiting for market stats...", curses.A_DIM)
            row_y += 2

        # Movers snapshot
        if self.state.movers:
            self.safe_addstr(row_y, 2, "TOP MOVERS", curses.A_BOLD)
            row_y += 1
            count = 0
            for cat, syms in self.state.movers.items():
                if row_y >= max_y - 3:
                    break
                self.safe_addstr(row_y, 4, f"{cat.replace('_', ' ').title()}: {', '.join(syms[:6])}")
                row_y += 1
                count += 1
                if count >= 3:
                    break
        else:
            self.safe_addstr(row_y, 2, "Waiting for movers...", curses.A_DIM)

        # Onboarding cue
        if max_y - row_y > 4:
            row_y += 2
            self.safe_addstr(row_y, 2, "QUICK START", curses.A_BOLD)
            row_y += 1
            self.safe_addstr(row_y, 4, "Press / to add a symbol (e.g., HUBC)")
            row_y += 1
            self.safe_addstr(row_y, 4, "Use 1-5 to switch tabs, Up/Down to change focus")

    def _prompt_symbol(self) -> None:
        max_y, max_x = self.stdscr.getmaxyx()
        prompt = "Search Symbol: "
        query = ""
        suggestion_idx = 0
        
        try:
            self.stdscr.nodelay(False)
            self.stdscr.timeout(-1)
            try:
                curses.curs_set(1)
            except curses.error:
                pass
                
            while True:
                # Clear input area
                self.safe_addstr(max_y - 3, 0, " " * (max_x - 1))
                self.safe_addstr(max_y - 2, 0, " " * (max_x - 1))
                self.safe_addstr(max_y - 1, 0, " " * (max_x - 1))
                
                # Draw prompt and current query
                self.safe_addstr(max_y - 2, 2, f"{prompt}{query}", curses.A_BOLD)
                
                # Get suggestions
                matches = self.state.symbol_manager.search(query)
                if matches:
                    suggestion_idx = min(suggestion_idx, len(matches) - 1)
                    # Draw suggestions
                    for i, m in enumerate(matches):
                        attr = curses.A_REVERSE if i == suggestion_idx else curses.A_DIM
                        label = f" {m['symbol']:<8} ({m.get('market', 'REG')}) | {m['symbolName'][:30]}"
                        self.safe_addstr(max_y - 4 - i, 2, label, attr)
                
                self.stdscr.refresh()
                ch = self.stdscr.getch()
                
                if ch in (27, ord('q')): # ESC
                    return
                elif ch in (curses.KEY_ENTER, 10, 13):
                    if matches:
                        selected = matches[suggestion_idx]
                        selected_sym = f"{selected['symbol']}:{selected.get('market', 'REG')}"
                        self.client.add_symbols([selected_sym])
                        try:
                            self.selected_idx = self.symbols.index(selected_sym)
                        except ValueError:
                            # If it was a new symbol added to self.symbols
                            self.selected_idx = len(self.symbols) - 1
                        return
                    elif self.state.symbol_manager.is_valid(query):
                        self.client.add_symbols([query])
                        try:
                            self.selected_idx = self.symbols.index(query)
                        except ValueError:
                            self.selected_idx = 0
                        return
                elif ch in (curses.KEY_BACKSPACE, 127, 8):
                    query = query[:-1]
                    suggestion_idx = 0
                elif ch == curses.KEY_DOWN:
                    if matches: suggestion_idx = (suggestion_idx + 1) % len(matches)
                elif ch == curses.KEY_UP:
                    if matches: suggestion_idx = (suggestion_idx - 1) % len(matches)
                elif 32 <= ch <= 126:
                    query += chr(ch).upper()
                    suggestion_idx = 0

        except Exception:
            pass
        finally:
            self.stdscr.nodelay(True)
            self.stdscr.timeout(200)
            try:
                curses.curs_set(0)
            except curses.error:
                pass

    def _draw_help(self, max_y: int, max_x: int) -> None:
        width = min(70, max_x - 4)
        height = 11
        top = max(2, (max_y - height) // 2)
        left = max(2, (max_x - width) // 2)
        lines = [
            "HELP / SHORTCUTS",
            "",
            "1-5        Switch tabs",
            "Left/Right Cycle tabs",
            "Up/Down    Change focused symbol",
            "/          Add or jump to symbol",
            "X          Remove selected symbol from watchlist",
            "? or H     Toggle this help",
            "Q          Quit",
        ]
        border = "+" + "-" * (width - 2) + "+"
        self.safe_addstr(top, left, border, curses.A_BOLD)
        for i in range(1, height - 1):
            self.safe_addstr(top + i, left, "|" + " " * (width - 2) + "|")
        self.safe_addstr(top + height - 1, left, border, curses.A_BOLD)
        for i, line in enumerate(lines):
            if i + 1 >= height - 1:
                break
            self.safe_addstr(top + 1 + i, left + 2, line, curses.A_BOLD if i == 0 else curses.A_NORMAL)


# --- ENTRY POINT & CLI ---
def parse_args() -> Tuple[Optional[List[str]], Optional[List[str]]]:
    parser = argparse.ArgumentParser(description="PSX Trading Terminal")
    parser.add_argument("-s", "--symbols", type=str, help="Comma-separated symbols (e.g. HUBC,EFERT)")
    parser.add_argument("-f", "--feeds", type=str, choices=['1', '2', '3', '4'], help="1=L1, 2=MBP, 3=MBO, 4=All")
    args = parser.parse_args()
    
    symbols = [s.strip().upper() for s in args.symbols.split(",")] if args.symbols else None
    feeds = FEED_CHOICES.get(args.feeds, FEED_CHOICES["4"]) if args.feeds else None
    return symbols, feeds


def main() -> None:
    symbols_arg, feeds_arg = parse_args()
    symbols = symbols_arg if symbols_arg is not None else load_watchlist()
    feeds = feeds_arg or FEED_CHOICES["4"]

    # Save the current watchlist for persistence
    save_watchlist(symbols)

    state = AppState()
    state.symbol_manager.load()
    config = AppConfig(host=HOST, port=PORT, symbols=symbols, feeds=feeds)
    client = PSXClient(config, state)
    client.start()

    try:
        curses.wrapper(lambda stdscr: DashboardUI(stdscr, state, config, client).run())
    except KeyboardInterrupt:
        pass
    finally:
        state.stop = True


if __name__ == "__main__":
    main()
