# AhleTrade HTTP Feed API

Base URL: `http://feed.ahletrade.com/HTTPFeedServer/FeedFetcher`

## Endpoints

Both endpoints share the same base URL with query parameters:

| Parameter    | Description                                      |
|-------------|--------------------------------------------------|
| `action`    | Always `Market` for market data                  |
| `identifier`| Feed type: `PriceVolume` or `BuySell`            |
| `market`    | Market segment, e.g. `REG` (Regular)             |
| `symbol`    | Stock ticker, e.g. `EFERT`, `HUBC`               |

---

## `identifier=BuySell` — Best Bid/Ask (L1 Quote Feed)

> **Note:** Despite the name, `BuySell` returns bid/ask quote snapshots, not individual trades. The identifier names are counterintuitive.

**URL example:**
```
http://feed.ahletrade.com/HTTPFeedServer/FeedFetcher?action=Market&identifier=BuySell&market=REG&symbol=EFERT
```

### Response Format

Plain text. Each record is separated by `| ` (pipe + space):

```
HH:MM:SS;bid;ask;| HH:MM:SS;bid;ask;| ...
```

### Fields

| Field       | Type   | Description                        |
|------------|--------|------------------------------------|
| `timestamp` | string | Time of quote update (`HH:MM:SS`)  |
| `bid`       | float  | Best bid price                     |
| `ask`       | float  | Best ask price                     |

### Sample Records

```
09:00:00;200.0;223.89;|   ← pre-open call auction (wide spread)
09:15:00;204.13;204.9;|   ← market opens, spread tightens
09:17:50;203.9;204.0;|    ← normal trading
13:50:00;0.0;0.0;|        ← end-of-session sentinel
```

### Behaviour Notes

- **Pre-open (09:00–09:15 PKT):** Data is present but bid/ask spread is very wide — this is the call auction phase. Prices reflect indicative order book levels, not tradeable quotes.
- **Market open (09:15 PKT):** Spread tightens sharply to normal trading levels.
- **End of session:** A final record with `bid=0.0` and `ask=0.0` marks session close.
- **Update frequency:** Irregular; records are emitted only when the best bid or ask changes. Gaps of several seconds to minutes are normal during quiet periods.
- **Locked market:** Occasionally `bid == ask` (e.g. `203.42;203.42`) — this can appear near session end or during low-liquidity periods.

---

## `identifier=PriceVolume` — Trade Tape (Time & Sales)

> **Note:** Despite the name, `PriceVolume` returns individual trade executions, not bid/ask quotes.

**URL example:**
```
http://feed.ahletrade.com/HTTPFeedServer/FeedFetcher?action=Market&identifier=PriceVolume&market=REG&symbol=EFERT
```

### Response Format

Plain text. Same delimiter as PriceVolume:

```
HH:MM:SS;price;volume;| HH:MM:SS;price;volume;| ...
```

### Fields

| Field       | Type   | Description                          |
|------------|--------|--------------------------------------|
| `timestamp` | string | Time of trade execution (`HH:MM:SS`) |
| `price`     | float  | Trade execution price                |
| `volume`    | int    | Number of shares traded              |

### Sample Records

```
09:15:00;204.13;1;|      ← first trade at market open
09:27:00;204.0;5000;|    ← large block trade
13:29:52;202.89;50;|     ← last real trade
13:35:00;202.89;50;|     ← heartbeat (repeating, same price/vol)
```

### Behaviour Notes

- **No pre-open trades:** BuySell data starts at 09:15:00 (market open). The call auction period (09:00–09:15) does not appear here.
- **Heartbeat / keepalive:** After the last real trade, the server continues emitting records with the same price and volume at regular intervals. These are identifiable because the price and volume remain constant across many ticks.
- **Volume unit:** Shares (not lots). PSX standard lot is 500 shares, but odd-lot trades appear frequently.
- **No trade direction:** The feed does not indicate whether a trade was buyer- or seller-initiated.

---

## Session Timing (PKT = UTC+5)

| Phase              | Approx. Time (PKT) | Notes                                  |
|-------------------|-------------------|----------------------------------------|
| Pre-open / Auction | 09:00 – 09:15     | PriceVolume only, wide spread          |
| Regular Trading    | 09:15 – ~13:30    | Both feeds active                      |
| Post-close         | After ~13:30      | BuySell heartbeats; PriceVolume → 0/0  |

> **Note:** The session end time observed in sample data (~13:30–13:50) may reflect a specific market segment or trading day. PSX regular session is officially 09:15–15:30 PKT.

---

## Parsing

See [`feed_parser.py`](src/psx_terminal/feed_parser.py) for a minimal Python parser for both feed types.

---

## Known Quirks

- The response is **not** JSON or XML — it is raw delimited text.
- The trailing `|` after the last record means splitting on `|` produces an empty final element; strip/filter it.
- Timestamps are **time-only** (no date). The date must be inferred from context (the feed appears to return the current trading day's data).
- Prices use `.` as decimal separator regardless of locale.
