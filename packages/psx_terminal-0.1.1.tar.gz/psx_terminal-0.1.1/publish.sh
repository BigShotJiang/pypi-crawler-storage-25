#!/usr/bin/env bash
# Build and publish psx-terminal to PyPI.
# Reference: https://packaging.python.org/en/latest/guides/section-build-and-publish/
set -euo pipefail

# ── Extract version from pyproject.toml ──────────────────────────────────────
VERSION=$(python3 -c "
import re, pathlib
text = pathlib.Path('pyproject.toml').read_text()
m = re.search(r'version\s*=\s*\"([^\"]+)\"', text)
print(m.group(1) if m else 'unknown')
")
echo "🚀 Preparing to build and publish psx-terminal v${VERSION} to PyPI..."

# ── Step 1: Ensure build tools are installed ─────────────────────────────────
echo ""
echo "📥 Installing / upgrading build tools (build, twine)..."
python3 -m pip install --upgrade pip build twine --quiet

# ── Step 2: Clean old distribution artifacts ─────────────────────────────────
echo ""
echo "🧹 Cleaning old distribution artifacts..."
rm -rf dist/ build/
find . -path './*.egg-info' -type d -exec rm -rf {} + 2>/dev/null || true
find ./src -path './*.egg-info' -type d -exec rm -rf {} + 2>/dev/null || true

# ── Step 3: Build source distribution + wheel ────────────────────────────────
echo ""
echo "📦 Building source distribution and wheel..."
python3 -m build

echo ""
echo "✅ Build completed. Contents of dist/:"
ls -lh dist/

# ── Step 4: Check metadata with twine ────────────────────────────────────────
echo ""
echo "🔍 Checking distribution metadata with twine..."
if ! python3 -m twine check dist/*; then
  echo ""
  echo "⚠️  twine check reported issues (see above)."
  echo "   This is often a false positive for PEP 639 license metadata."
  echo "   PyPI itself accepts this metadata fine."
  read -rp "   Continue with upload anyway? [y/N] " answer
  if [[ ! "$answer" =~ ^[Yy]$ ]]; then
    echo "❌ Aborted."
    exit 1
  fi
fi

# ── Step 5: Upload to PyPI ───────────────────────────────────────────────────
echo ""
echo "🌐 Uploading to PyPI via twine..."
echo "   (Credentials are read from ~/.pypirc if configured,"
echo "    otherwise you will be prompted for your API token.)"
python3 -m twine upload dist/*

echo ""
echo "🎉 Successfully published psx-terminal v${VERSION} to PyPI!"
echo "   View at: https://pypi.org/project/psx-terminal/${VERSION}/"
