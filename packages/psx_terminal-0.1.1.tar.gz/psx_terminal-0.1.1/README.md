# psx-terminal

A fast, data‑dense terminal dashboard for Pakistan Stock Exchange market feeds. This is a read‑only trading terminal focusing on realtime data visibility (L1, MBP, MBO), designed to be highly accessible right from your command line.

## Highlights
- **Realtime L1 + L2**: Watchlist, market depth (MBP/MBO), and movers.
- **Curses UI**: Clean, high‑contrast layout designed for long sessions.
- **Keyboard‑first navigation**: Tabs and symbol selection optimized for speed.
- **Resilient networking**: Auto‑reconnect and safe parsing for noisy feeds.

## Installation

You can install `psx-terminal` securely and easily using `pip`:

```bash
pip install psx-terminal
```

To update `psx-terminal` to the latest version, run:
```bash
pip install --upgrade psx-terminal
```

## Quickstart

Once installed, simply type `psx-terminal` in your terminal to launch the interface:

```bash
psx-terminal
```

## CLI Usage (Advanced)

```bash
psx-terminal -s HUBC,EFERT -f 4
```

### Flags
- `-s`, `--symbols` Comma‑separated symbols (default: loaded from your saved watchlist or EFERT if none).
- `-f`, `--feeds` Feed mode: `1`=L1, `2`=MBP, `3`=MBO, `4`=All

## Controls
- `1`, `2`, `3`, `4`, `5` Switch main tabs
- `Left/Right` Cycle main tabs
- `Up/Down` Change focused symbol
- `/` Add a symbol to watchlist (persisted safely to `~/.psx_terminal/`)
- `X` Remove selected symbol
- `Q` Quit
- In Analytics (`4`): Press `A`-`D` or use `<`/`>` to cycle subtabs.

## Data Panels
- **Watchlist (L1)**: Last, change, bid/ask, volume, high/low
- **Market Depth (L2)**: MBP or MBO with best bid/ask + spread
- **Movers & Alerts**: Market movers and circuit breaker notices
- **Analytics**: Session summary, price ladder, trade flow, and intraday.

## Design Goals
- Data density without sacrificing scan‑ability
- Clear bid/ask contrast and change emphasis
- Safe behavior on small terminals with graceful resizing

## Development & Publishing
This project is authored by **nordixsoft**. 
For documentation on publishing updates to PyPI, refer to `PUBLISHING.md`.

## Notes
- Requires network access to the PSX feed host.
- This project does not place trades. It is display‑only.

## License
MIT License
