import unittest

from pilot_status.webhooks.parse import WebhookParseError, is_customer_webhook_event, parse_customer_webhook


class TestWebhooks(unittest.TestCase):
    def test_parse_message_failed(self):
        payload = {
            "event": "message.failed",
            "data": {
                "messageId": "m_123",
                "internalMessageId": "ps_123",
                "environment": "TEST",
                "destinationNumber": "+5511999999999",
                "content": "hello",
                "status": "FAILED",
                "failedAt": "2026-01-01T00:00:00.000Z",
                "errorMessage": "oops",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "message.failed")
        self.assertEqual(event["data"]["status"], "FAILED")

    def test_is_customer_webhook_event_true(self):
        payload = {
            "event": "message.sent",
            "data": {
                "messageId": "m_123",
                "internalMessageId": "ps_123",
                "environment": "LIVE",
                "destinationNumber": "+5511999999999",
                "content": "hello",
                "status": "SENT",
                "sentAt": "2026-01-01T00:00:00.000Z",
            },
        }
        self.assertTrue(is_customer_webhook_event(payload))

    def test_parse_message_received(self):
        payload = {
            "event": "message.received",
            "data": {
                "fromMe": False,
                "from": "5511999999999",
                "environment": "LIVE",
                "destinationNumber": "5511888888888",
                "content": "oi",
                "receivedAt": "2026-01-01T00:00:00.000Z",
                "messageId": "msg_in_1",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "message.received")
        self.assertEqual(event["data"]["fromMe"], False)

    def test_parse_optin_created(self):
        payload = {
            "event": "optin.created",
            "data": {
                "projectId": "p_1",
                "environment": "LIVE",
                "whatsappInstanceName": "Pilot Status",
                "destinationNumber": "",
                "destinationHash": "hash",
                "isFirstOptIn": True,
                "firstOptInAt": "2026-01-01T00:00:00.000Z",
                "lastSeenAt": "2026-01-01T00:00:00.000Z",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "optin.created")
        self.assertEqual(event["data"]["projectId"], "p_1")

    def test_parse_message_group(self):
        payload = {
            "event": "message.group",
            "data": {
                "fromNumber": "5511999999999",
                "fromName": "Ismael Ash",
                "fromMe": False,
                "groupName": "My Group",
                "content": "Boa",
                "environment": "LIVE",
                "messageId": "k_in",
            },
        }
        event = parse_customer_webhook(payload)
        self.assertEqual(event["event"], "message.group")
        self.assertEqual(event["data"]["groupName"], "My Group")

    def test_parse_invalid_payload_raises(self):
        with self.assertRaises(WebhookParseError) as ctx:
            parse_customer_webhook({"event": "message.sent", "data": {}})
        self.assertGreaterEqual(len(ctx.exception.issues), 1)


if __name__ == "__main__":
    unittest.main()
