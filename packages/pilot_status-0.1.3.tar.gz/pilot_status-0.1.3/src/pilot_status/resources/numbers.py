from __future__ import annotations

from typing import Any

from ..http import HttpClient
from ..types import CreateNumberInput, CreateNumberResult, NumberStatusResult


class NumbersResource:
    def __init__(self, http: HttpClient):
        self._http = http

    def create(self, input: CreateNumberInput) -> CreateNumberResult:
        body: dict[str, Any] = {
            "name": input["name"],
            "number": input["number"],
        }
        if "linkToApiKey" in input:
            body["linkToApiKey"] = input["linkToApiKey"]
        return self._http.request_json(method="POST", path="/v1/numbers", body=body)

    def get_status(self, id: str) -> NumberStatusResult:
        return self._http.request_json(
            method="GET",
            path=f"/v1/numbers/{id}/status",
        )
