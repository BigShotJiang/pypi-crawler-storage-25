from __future__ import annotations

from typing import Literal, Optional, TypedDict, Union

from ..types import Environment


class MessageSentData(TypedDict):
    messageId: Optional[str]
    internalMessageId: str
    environment: Environment
    destinationNumber: str
    content: str
    status: Literal["SENT"]
    sentAt: str


class MessageSentEvent(TypedDict):
    event: Literal["message.sent"]
    data: MessageSentData


class MessageDeliveredData(TypedDict):
    messageId: Optional[str]
    internalMessageId: str
    environment: Environment
    destinationNumber: str
    content: str
    status: Literal["DELIVERED"]
    deliveredAt: str


class MessageDeliveredEvent(TypedDict):
    event: Literal["message.delivered"]
    data: MessageDeliveredData


class MessageReadData(TypedDict):
    messageId: Optional[str]
    internalMessageId: str
    environment: Environment
    destinationNumber: str
    content: str
    status: Literal["READ"]
    readAt: str


class MessageReadEvent(TypedDict):
    event: Literal["message.read"]
    data: MessageReadData


class MessageFailedData(TypedDict):
    messageId: Optional[str]
    internalMessageId: str
    environment: Environment
    destinationNumber: str
    content: str
    status: Literal["FAILED"]
    failedAt: str
    errorMessage: str


class MessageFailedEvent(TypedDict):
    event: Literal["message.failed"]
    data: MessageFailedData


MessageReplyData = TypedDict(
    "MessageReplyData",
    {
        "from": str,
        "destinationNumber": str,
        "content": str,
        "replyContent": str,
        "receivedAt": str,
        "messageId": Optional[str],
        "quotedMessageId": Optional[str],
        "messageRepliedId": Optional[str],
        "environment": Environment,
        "buttonId": Optional[str],
    },
)


class MessageReplyEvent(TypedDict):
    event: Literal["message.reply"]
    data: MessageReplyData


MessageReceivedData = TypedDict(
    "MessageReceivedData",
    {
        "fromMe": bool,
        "from": str,
        "destinationNumber": str,
        "content": str,
        "receivedAt": str,
        "messageId": Optional[str],
        "environment": Environment,
        "whatsappInstanceName": Optional[str],
    },
)


class MessageReceivedEvent(TypedDict):
    event: Literal["message.received"]
    data: MessageReceivedData


MessageGroupData = TypedDict(
    "MessageGroupData",
    {
        "fromNumber": Optional[str],
        "fromName": Optional[str],
        "fromMe": bool,
        "groupName": Optional[str],
        "content": str,
        "environment": Environment,
        "messageId": Optional[str],
    },
)


class MessageGroupEvent(TypedDict):
    event: Literal["message.group"]
    data: MessageGroupData


class OptinCreatedData(TypedDict):
    projectId: str
    environment: Environment
    whatsappInstanceName: str
    destinationNumber: str
    destinationHash: str
    isFirstOptIn: bool
    firstOptInAt: str
    lastSeenAt: str


class OptinCreatedEvent(TypedDict):
    event: Literal["optin.created"]
    data: OptinCreatedData


CustomerWebhookEvent = Union[
    MessageSentEvent,
    MessageDeliveredEvent,
    MessageReadEvent,
    MessageFailedEvent,
    MessageReplyEvent,
    MessageReceivedEvent,
    MessageGroupEvent,
    OptinCreatedEvent,
]
