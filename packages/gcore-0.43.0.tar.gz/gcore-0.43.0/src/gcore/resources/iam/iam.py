# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .users import (
    UsersResource,
    AsyncUsersResource,
    UsersResourceWithRawResponse,
    AsyncUsersResourceWithRawResponse,
    UsersResourceWithStreamingResponse,
    AsyncUsersResourceWithStreamingResponse,
)
from ..._types import Body, Query, Headers, NotGiven, not_given
from ..._compat import cached_property
from .api_tokens import (
    APITokensResource,
    AsyncAPITokensResource,
    APITokensResourceWithRawResponse,
    AsyncAPITokensResourceWithRawResponse,
    APITokensResourceWithStreamingResponse,
    AsyncAPITokensResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.iam.account_overview import AccountOverview

__all__ = ["IamResource", "AsyncIamResource"]


class IamResource(SyncAPIResource):
    """
    Account management operations including authentication, password management, and account details.
    """

    @cached_property
    def api_tokens(self) -> APITokensResource:
        """
        Use permanent API tokens for regular automated requests to services.
        You can either set its validity period when creating it or issue a token for an unlimited time.
        Please address the API documentation of the specific product in order to check if it supports API tokens.

        Newer endpoints under `/v2/…` issue tokens using `_` (underscore) as the separator
        (for example `42_a1b2c3d4e5f6...`) and are the recommended way to create new tokens.
        Legacy endpoints that issue `$`-separated tokens are marked deprecated and will be removed
        on **2026-07-17**; tokens that were already issued keep authenticating.

        Provide your APIKey in the Authorization header.

        Example: ```curl -H "Authorization: APIKey 42_a1b2c3d4e5f6..." https://api.gcore.com/iam/users/me```

        Please note: When authorizing via SAML SSO, our system does not have any
        information about permissions given to the user by the identity provider.
        Even if the provider revokes the user's access rights, their tokens remain active.
        Therefore, if necessary, the token will need to be deleted manually.
        """
        return APITokensResource(self._client)

    @cached_property
    def users(self) -> UsersResource:
        return UsersResource(self._client)

    @cached_property
    def with_raw_response(self) -> IamResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/G-Core/gcore-python#accessing-raw-response-data-eg-headers
        """
        return IamResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> IamResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/G-Core/gcore-python#with_streaming_response
        """
        return IamResourceWithStreamingResponse(self)

    def get_account_overview(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AccountOverview:
        """Get information about your profile, users and other account details."""
        return self._get(
            "/iam/clients/me",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AccountOverview,
        )


class AsyncIamResource(AsyncAPIResource):
    """
    Account management operations including authentication, password management, and account details.
    """

    @cached_property
    def api_tokens(self) -> AsyncAPITokensResource:
        """
        Use permanent API tokens for regular automated requests to services.
        You can either set its validity period when creating it or issue a token for an unlimited time.
        Please address the API documentation of the specific product in order to check if it supports API tokens.

        Newer endpoints under `/v2/…` issue tokens using `_` (underscore) as the separator
        (for example `42_a1b2c3d4e5f6...`) and are the recommended way to create new tokens.
        Legacy endpoints that issue `$`-separated tokens are marked deprecated and will be removed
        on **2026-07-17**; tokens that were already issued keep authenticating.

        Provide your APIKey in the Authorization header.

        Example: ```curl -H "Authorization: APIKey 42_a1b2c3d4e5f6..." https://api.gcore.com/iam/users/me```

        Please note: When authorizing via SAML SSO, our system does not have any
        information about permissions given to the user by the identity provider.
        Even if the provider revokes the user's access rights, their tokens remain active.
        Therefore, if necessary, the token will need to be deleted manually.
        """
        return AsyncAPITokensResource(self._client)

    @cached_property
    def users(self) -> AsyncUsersResource:
        return AsyncUsersResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncIamResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/G-Core/gcore-python#accessing-raw-response-data-eg-headers
        """
        return AsyncIamResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncIamResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/G-Core/gcore-python#with_streaming_response
        """
        return AsyncIamResourceWithStreamingResponse(self)

    async def get_account_overview(
        self,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AccountOverview:
        """Get information about your profile, users and other account details."""
        return await self._get(
            "/iam/clients/me",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=AccountOverview,
        )


class IamResourceWithRawResponse:
    def __init__(self, iam: IamResource) -> None:
        self._iam = iam

        self.get_account_overview = to_raw_response_wrapper(
            iam.get_account_overview,
        )

    @cached_property
    def api_tokens(self) -> APITokensResourceWithRawResponse:
        """
        Use permanent API tokens for regular automated requests to services.
        You can either set its validity period when creating it or issue a token for an unlimited time.
        Please address the API documentation of the specific product in order to check if it supports API tokens.

        Newer endpoints under `/v2/…` issue tokens using `_` (underscore) as the separator
        (for example `42_a1b2c3d4e5f6...`) and are the recommended way to create new tokens.
        Legacy endpoints that issue `$`-separated tokens are marked deprecated and will be removed
        on **2026-07-17**; tokens that were already issued keep authenticating.

        Provide your APIKey in the Authorization header.

        Example: ```curl -H "Authorization: APIKey 42_a1b2c3d4e5f6..." https://api.gcore.com/iam/users/me```

        Please note: When authorizing via SAML SSO, our system does not have any
        information about permissions given to the user by the identity provider.
        Even if the provider revokes the user's access rights, their tokens remain active.
        Therefore, if necessary, the token will need to be deleted manually.
        """
        return APITokensResourceWithRawResponse(self._iam.api_tokens)

    @cached_property
    def users(self) -> UsersResourceWithRawResponse:
        return UsersResourceWithRawResponse(self._iam.users)


class AsyncIamResourceWithRawResponse:
    def __init__(self, iam: AsyncIamResource) -> None:
        self._iam = iam

        self.get_account_overview = async_to_raw_response_wrapper(
            iam.get_account_overview,
        )

    @cached_property
    def api_tokens(self) -> AsyncAPITokensResourceWithRawResponse:
        """
        Use permanent API tokens for regular automated requests to services.
        You can either set its validity period when creating it or issue a token for an unlimited time.
        Please address the API documentation of the specific product in order to check if it supports API tokens.

        Newer endpoints under `/v2/…` issue tokens using `_` (underscore) as the separator
        (for example `42_a1b2c3d4e5f6...`) and are the recommended way to create new tokens.
        Legacy endpoints that issue `$`-separated tokens are marked deprecated and will be removed
        on **2026-07-17**; tokens that were already issued keep authenticating.

        Provide your APIKey in the Authorization header.

        Example: ```curl -H "Authorization: APIKey 42_a1b2c3d4e5f6..." https://api.gcore.com/iam/users/me```

        Please note: When authorizing via SAML SSO, our system does not have any
        information about permissions given to the user by the identity provider.
        Even if the provider revokes the user's access rights, their tokens remain active.
        Therefore, if necessary, the token will need to be deleted manually.
        """
        return AsyncAPITokensResourceWithRawResponse(self._iam.api_tokens)

    @cached_property
    def users(self) -> AsyncUsersResourceWithRawResponse:
        return AsyncUsersResourceWithRawResponse(self._iam.users)


class IamResourceWithStreamingResponse:
    def __init__(self, iam: IamResource) -> None:
        self._iam = iam

        self.get_account_overview = to_streamed_response_wrapper(
            iam.get_account_overview,
        )

    @cached_property
    def api_tokens(self) -> APITokensResourceWithStreamingResponse:
        """
        Use permanent API tokens for regular automated requests to services.
        You can either set its validity period when creating it or issue a token for an unlimited time.
        Please address the API documentation of the specific product in order to check if it supports API tokens.

        Newer endpoints under `/v2/…` issue tokens using `_` (underscore) as the separator
        (for example `42_a1b2c3d4e5f6...`) and are the recommended way to create new tokens.
        Legacy endpoints that issue `$`-separated tokens are marked deprecated and will be removed
        on **2026-07-17**; tokens that were already issued keep authenticating.

        Provide your APIKey in the Authorization header.

        Example: ```curl -H "Authorization: APIKey 42_a1b2c3d4e5f6..." https://api.gcore.com/iam/users/me```

        Please note: When authorizing via SAML SSO, our system does not have any
        information about permissions given to the user by the identity provider.
        Even if the provider revokes the user's access rights, their tokens remain active.
        Therefore, if necessary, the token will need to be deleted manually.
        """
        return APITokensResourceWithStreamingResponse(self._iam.api_tokens)

    @cached_property
    def users(self) -> UsersResourceWithStreamingResponse:
        return UsersResourceWithStreamingResponse(self._iam.users)


class AsyncIamResourceWithStreamingResponse:
    def __init__(self, iam: AsyncIamResource) -> None:
        self._iam = iam

        self.get_account_overview = async_to_streamed_response_wrapper(
            iam.get_account_overview,
        )

    @cached_property
    def api_tokens(self) -> AsyncAPITokensResourceWithStreamingResponse:
        """
        Use permanent API tokens for regular automated requests to services.
        You can either set its validity period when creating it or issue a token for an unlimited time.
        Please address the API documentation of the specific product in order to check if it supports API tokens.

        Newer endpoints under `/v2/…` issue tokens using `_` (underscore) as the separator
        (for example `42_a1b2c3d4e5f6...`) and are the recommended way to create new tokens.
        Legacy endpoints that issue `$`-separated tokens are marked deprecated and will be removed
        on **2026-07-17**; tokens that were already issued keep authenticating.

        Provide your APIKey in the Authorization header.

        Example: ```curl -H "Authorization: APIKey 42_a1b2c3d4e5f6..." https://api.gcore.com/iam/users/me```

        Please note: When authorizing via SAML SSO, our system does not have any
        information about permissions given to the user by the identity provider.
        Even if the provider revokes the user's access rights, their tokens remain active.
        Therefore, if necessary, the token will need to be deleted manually.
        """
        return AsyncAPITokensResourceWithStreamingResponse(self._iam.api_tokens)

    @cached_property
    def users(self) -> AsyncUsersResourceWithStreamingResponse:
        return AsyncUsersResourceWithStreamingResponse(self._iam.users)
