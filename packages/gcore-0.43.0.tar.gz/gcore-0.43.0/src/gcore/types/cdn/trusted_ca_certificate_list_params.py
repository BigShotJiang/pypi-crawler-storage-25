# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["TrustedCaCertificateListParams"]


class TrustedCaCertificateListParams(TypedDict, total=False):
    automated: bool
    """How the certificate was issued.

    Possible values:

    - **true** – Certificate was issued automatically.
    - **false** – Certificate was added by a user.
    """

    limit: int
    """Maximum number of items to return in the response. Cannot exceed 1000."""

    offset: int
    """Number of items to skip from the beginning of the list."""

    resource_id: int
    """CDN resource ID for which the certificates are requested."""

    validity_not_after_lte: str
    """
    Date and time when the certificate become untrusted (ISO 8601/RFC 3339 format,
    UTC.)

    Response will contain certificates valid until the specified time.
    """
