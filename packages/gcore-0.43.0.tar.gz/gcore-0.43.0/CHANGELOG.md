# Changelog

## 0.43.0 (2026-04-22)

Full Changelog: [v0.42.0...v0.43.0](https://github.com/G-Core/gcore-python/compare/v0.42.0...v0.43.0)

### Features

* **api:** aggregated API specs update ([7d70fe4](https://github.com/G-Core/gcore-python/commit/7d70fe4b2ef3fc2ba54cb8f2a195a5b0f09514bc))
* **api:** aggregated API specs update ([2e269b6](https://github.com/G-Core/gcore-python/commit/2e269b6f17a504250715f6f33316818e25ce6d70))
* **api:** aggregated API specs update ([96cd4c9](https://github.com/G-Core/gcore-python/commit/96cd4c96ff40b2d2bfc0d220309eadbc88b0dbb3))
* **api:** aggregated API specs update ([8b6d277](https://github.com/G-Core/gcore-python/commit/8b6d2777aa8967ba88788145440b9e6e94c7c7f7))
* **cloud:** add examples for GPU baremetal cluster images ([7279536](https://github.com/G-Core/gcore-python/commit/7279536d11b4163c445e270180da5de8582709ee))
* **cloud:** add polling methods for K8s clusters and pools ([76bd4c9](https://github.com/G-Core/gcore-python/commit/76bd4c9a97c4da20f7dcf4f04f87e195278527a0))
* **cloud:** add runnable K8s cluster example ([030f335](https://github.com/G-Core/gcore-python/commit/030f335f902c3cb2b29792b22b9e9c0a2f6f6de7))
* **storage:** support Terraform generation for locations ([063f1f4](https://github.com/G-Core/gcore-python/commit/063f1f40ee0d10153f5437a69f227936516cf8e7))


### Bug Fixes

* add rule to omit doc-only changes from release notes ([45bae59](https://github.com/G-Core/gcore-python/commit/45bae593f219bc62fd3773b97db603b4859500d7))


### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([2fd1bcb](https://github.com/G-Core/gcore-python/commit/2fd1bcbd057214f9fb494484e99d203a24c04c29))


### Chores

* suppress deprecation warning on IAM api_tokens.create usage ([9b2f4a4](https://github.com/G-Core/gcore-python/commit/9b2f4a4ff19039df9dc1aac3dfdc5eba000de025))
* **tests:** bump steady to v0.22.1 ([6ac2648](https://github.com/G-Core/gcore-python/commit/6ac2648d93f24b1f23544dac36d979575c763f3c))

## 0.42.0 (2026-04-17)

Full Changelog: [v0.41.0...v0.42.0](https://github.com/G-Core/gcore-python/compare/v0.41.0...v0.42.0)

### ⚠ BREAKING CHANGES

* **cloud:** remove deprecated cloud.inference.deployments.get_api_key

### Features

* **api:** aggregated API specs update ([284df4c](https://github.com/G-Core/gcore-python/commit/284df4cedcfac4b86c746c963fc69b5af183d014))
* **api:** aggregated API specs update ([0110236](https://github.com/G-Core/gcore-python/commit/0110236e7efb9269398475d2500e078c599037f6))
* **api:** aggregated API specs update ([51ad9c9](https://github.com/G-Core/gcore-python/commit/51ad9c97608b81a0358c3c8e06b3321cb331a06b))
* **api:** aggregated API specs update ([eda0539](https://github.com/G-Core/gcore-python/commit/eda0539c7bac06e3451703469aabf50fb5290467))
* **api:** aggregated API specs update ([01be2f5](https://github.com/G-Core/gcore-python/commit/01be2f5ba1c94daeff5e61a4672b9ff8b0bac7cc))
* **api:** aggregated API specs update ([7beaf49](https://github.com/G-Core/gcore-python/commit/7beaf49ae0cd289d6a60a79de18ed722a9cbf088))
* **api:** aggregated API specs update ([2f8fb0a](https://github.com/G-Core/gcore-python/commit/2f8fb0a0a1493b19a84a8d4fcb863ddfc2f66db8))
* **api:** fix(cdn): harmonize pagination across CDN list endpoints ([c95a0b8](https://github.com/G-Core/gcore-python/commit/c95a0b8b047bb8f7370934fe35576648163e3a3e))
* **cloud:** add delete_and_poll and examples for GPU baremetal clusters ([adc8f40](https://github.com/G-Core/gcore-python/commit/adc8f408f925862f13e19ac30c96684f40395aca))
* **cloud:** add polling methods and examples for GPU virtual clusters ([1ed9b85](https://github.com/G-Core/gcore-python/commit/1ed9b85b772bd52971503e21a7e484af6812f5b4))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([0971eaa](https://github.com/G-Core/gcore-python/commit/0971eaa023789ebaf5baeae39f4977cba3cbab1d))
* **cloud:** align polling methods with underlying base method ([4b99901](https://github.com/G-Core/gcore-python/commit/4b999011b48a859a6f95649246ac3a5ba67ff62e))
* **dns:** update network-mappings get_by_name to new endpoint path ([de11047](https://github.com/G-Core/gcore-python/commit/de110478944f7c9dc61ac3481dba876912e05ff6))
* ensure file data are only sent as 1 parameter ([16f4262](https://github.com/G-Core/gcore-python/commit/16f4262f6ca89edcefe0315c13963e2d84f945c2))
* **examples:** update baremetal image examples to use BaremetalImage type ([7e924f8](https://github.com/G-Core/gcore-python/commit/7e924f830c234be00e8c6cb940fe59ff4629a626))


### Chores

* **cloud:** remove deprecated cloud.inference.deployments.get_api_key ([1bf3513](https://github.com/G-Core/gcore-python/commit/1bf3513b19eda2cd35230947dd36a1b09f66e419))


### Documentation

* update examples ([fa05d93](https://github.com/G-Core/gcore-python/commit/fa05d9370764f706015b7628abd3ba0f12f880d7))


### Refactors

* **cloud:** split instance and baremetal image models ([fce124a](https://github.com/G-Core/gcore-python/commit/fce124a98b3eb6cec5bbcb46e60e424b4c6da298))

## 0.41.0 (2026-04-03)

Full Changelog: [v0.40.0...v0.41.0](https://github.com/G-Core/gcore-python/compare/v0.40.0...v0.41.0)

### Features

* **api:** aggregated API specs update ([0a6812c](https://github.com/G-Core/gcore-python/commit/0a6812cd7efd5906a2e93c5e5fdf9daa3818a957))
* **api:** aggregated API specs update ([6cee9d3](https://github.com/G-Core/gcore-python/commit/6cee9d3e8554f0417a635be879e7e316440b3b8f))
* **api:** aggregated API specs update ([d40d2c7](https://github.com/G-Core/gcore-python/commit/d40d2c7b9713e6efd8b006134eaa51cf5f457d81))
* **api:** aggregated API specs update ([7c3f529](https://github.com/G-Core/gcore-python/commit/7c3f5294def02deee6f7f0dfef7292873ae9b5a1))
* **cloud:** add support for Baremetal servers in Terraform ([33f5cc2](https://github.com/G-Core/gcore-python/commit/33f5cc29ad63e5d9b0d6ab7c12a85059ffc1d985))


### Bug Fixes

* **iam:** inject default limit on users list to ensure paginated response ([6b2bf6a](https://github.com/G-Core/gcore-python/commit/6b2bf6ace50dd041db352ee575ccfae496e6d92e))


### Chores

* **tests:** bump steady to v0.20.1 ([5b0b1de](https://github.com/G-Core/gcore-python/commit/5b0b1de4864f44973f6c48ba38f35a84b3a8e37b))
* **tests:** bump steady to v0.20.2 ([7f62464](https://github.com/G-Core/gcore-python/commit/7f62464cbf6c388fbb56d0f038353c1c976614a2))

## 0.40.0 (2026-03-30)

Full Changelog: [v0.39.0...v0.40.0](https://github.com/G-Core/gcore-python/compare/v0.39.0...v0.40.0)

### ⚠ BREAKING CHANGES

* **api:** storage resource restructured — methods moved from storage.* to storage.object_storages.* and storage.sftp_storages.*, credentials.recreate replaced by access_keys CRUD, bucket subresources (cors, lifecycle, policy) removed in favor of buckets.update, link_ssh_key/unlink_ssh_key removed in favor of ssh_keys resource.

### Features

* **api:** aggregated API specs update ([d45ea8c](https://github.com/G-Core/gcore-python/commit/d45ea8c11bf7bd8c583df0261721e2e9c5424984))
* **api:** aggregated API specs update ([473a08b](https://github.com/G-Core/gcore-python/commit/473a08b6bd90d7f7b134060b389a622b1659a13d))
* **api:** aggregated API specs update ([07228a2](https://github.com/G-Core/gcore-python/commit/07228a2d29b1fb8f4c2b1a41c0369f944ba503ed))
* **api:** feat(storage)!: migrate storage endpoints from v1-v3 to v4 ([ee3dd69](https://github.com/G-Core/gcore-python/commit/ee3dd69632d57395fcc1fce3b954ff20765df9f1))
* **cdn:** enable terraform support for cdn_rule_template ([e6e4283](https://github.com/G-Core/gcore-python/commit/e6e428388751914c243d937c152cd28ea19d8320))
* **cloud:** enable Terraform data source for inference flavors ([aa3b08d](https://github.com/G-Core/gcore-python/commit/aa3b08d8777b307b79982eaa55dd98a0c61cda6d))
* **examples:** update storage examples for v4 API ([422c9c9](https://github.com/G-Core/gcore-python/commit/422c9c97a6afb8ae226af315ff8870440712de4e))
* **fastedge:** enable fastedge_template for Terraform ([5e9dab6](https://github.com/G-Core/gcore-python/commit/5e9dab60da36beb8438b295fabbef4e2ad2e220e))
* **internal:** implement indices array format for query and form serialization ([270614e](https://github.com/G-Core/gcore-python/commit/270614e31a2d6bb7cc31d4182b1f4544e0f3ec5a))


### Chores

* **ci:** skip lint on metadata-only changes ([5277f95](https://github.com/G-Core/gcore-python/commit/5277f95a3de9c67fa39dc5e611d8315a624bae45))
* **tests:** bump steady to v0.19.6 ([ba47f6b](https://github.com/G-Core/gcore-python/commit/ba47f6be3548421482c401a94c2f8ea481ffcb0d))
* **tests:** bump steady to v0.19.7 ([7767e13](https://github.com/G-Core/gcore-python/commit/7767e1315ca81c246fa32663455731f9191a5d12))
* **tests:** skip tests failing due to OpenAPI spec issues ([0e83fd1](https://github.com/G-Core/gcore-python/commit/0e83fd19bb738c95d4f563257d2d29bba560c26e))

## 0.39.0 (2026-03-23)

Full Changelog: [v0.38.0...v0.39.0](https://github.com/G-Core/gcore-python/compare/v0.38.0...v0.39.0)

### ⚠ BREAKING CHANGES

* **waap:** replace deprecated domain-scoped traffic/requests endpoints with account-scoped analytics

### Features

* **api:** aggregated API specs update ([998707e](https://github.com/G-Core/gcore-python/commit/998707ec275cc269044a347c5b858d460e2ae491))
* **api:** aggregated API specs update ([1617eb3](https://github.com/G-Core/gcore-python/commit/1617eb374498f1b445a8466163d42c4b49ff4ca5))
* **api:** aggregated API specs update ([938f4ae](https://github.com/G-Core/gcore-python/commit/938f4aedb8f61a95628ceb111df6e716f3f8ca70))
* **api:** Revert "feat(cdn): enable terraform support for cdn_rule_template" ([893f007](https://github.com/G-Core/gcore-python/commit/893f007fa4eb3323367748b55c21925e715de62a))
* **cdn:** enable terraform support for cdn_rule_template ([bae5faf](https://github.com/G-Core/gcore-python/commit/bae5faff732a79d6bba81563075b61f7f4d450dd))
* **cloud:** add create_and_poll and delete_and_poll methods for volume snapshots ([1c06cca](https://github.com/G-Core/gcore-python/commit/1c06ccaaf7d3256a1c33b53c6ca913700ed1da68))
* **cloud:** add notification_threshold subresource to quotas ([7a2de37](https://github.com/G-Core/gcore-python/commit/7a2de3750cd3737cbbbc0ba0d3317c08368345a8))
* **waap:** replace deprecated domain-scoped traffic/requests endpoints with account-scoped analytics ([4321632](https://github.com/G-Core/gcore-python/commit/43216323d5aa93acb990d6db686e785f730a9323))


### Bug Fixes

* **deps:** bump minimum typing-extensions version ([b31cabd](https://github.com/G-Core/gcore-python/commit/b31cabd05d4a00b17843e50cb04cd19b213c7841))
* **pydantic:** do not pass `by_alias` unless set ([5c6f9bc](https://github.com/G-Core/gcore-python/commit/5c6f9bcfbd18fc5e22a4afeafe91c8d6a9587cb1))
* sanitize endpoint path params ([c4dbd22](https://github.com/G-Core/gcore-python/commit/c4dbd22cb198bc087fa998a4b090997dc4078103))


### Chores

* **internal:** tweak CI branches ([9d190fe](https://github.com/G-Core/gcore-python/commit/9d190fe9d244981df99f5b9bd2183de0b8f0bd1b))
* **internal:** update gitignore ([7aa0b60](https://github.com/G-Core/gcore-python/commit/7aa0b600257cc4c9ddf0d8ce3af1ac709a11f3ec))
* **tests:** bump steady to v0.19.4 ([379eb58](https://github.com/G-Core/gcore-python/commit/379eb58258a9f5e24d9108ed1efdeb3c68f2a4f4))
* **tests:** bump steady to v0.19.5 ([660410f](https://github.com/G-Core/gcore-python/commit/660410fc9038c0dc349911ba9def7e1fa2aad3a7))


### Refactors

* **tests:** switch from prism to steady ([28a7208](https://github.com/G-Core/gcore-python/commit/28a7208e84d438e550556f8b41c1dca8f6283b95))

## 0.38.0 (2026-03-16)

Full Changelog: [v0.37.0...v0.38.0](https://github.com/G-Core/gcore-python/compare/v0.37.0...v0.38.0)

### ⚠ BREAKING CHANGES

* **cloud:** make kubeconfig as k8s cluster subresource

### Features

* **api:** aggregated API specs update ([7750517](https://github.com/G-Core/gcore-python/commit/775051786c7e0518c8c921582738756aa1736192))
* **api:** aggregated API specs update ([b150a8b](https://github.com/G-Core/gcore-python/commit/b150a8b912a9f3253f2d8138fa8c93f5530c331d))
* **api:** aggregated API specs update ([c1fb24e](https://github.com/G-Core/gcore-python/commit/c1fb24e6132dcd89b9b84a2e369d327a57f187e2))
* **api:** aggregated API specs update ([eb53954](https://github.com/G-Core/gcore-python/commit/eb5395427eae979ee0f64ebcc79aa11455cd3d62))
* **api:** aggregated API specs update ([152f7b0](https://github.com/G-Core/gcore-python/commit/152f7b010e3de9e11b74fa0e9d25c2e3c46edd7c))
* **api:** aggregated API specs update ([e203f21](https://github.com/G-Core/gcore-python/commit/e203f2110410c15524fabbf45c813cd7b7113308))
* **cloud:** add get, update, delete methods to baremetal servers ([46de113](https://github.com/G-Core/gcore-python/commit/46de113fe4f394a353ea06199533b30c9fa42df9))
* **cloud:** add update method to GPU Baremetal clusters ([3aaae61](https://github.com/G-Core/gcore-python/commit/3aaae61423f266ceca10a2a44aab05fb11875b9f))
* **cloud:** make kubeconfig as k8s cluster subresource ([c918c1d](https://github.com/G-Core/gcore-python/commit/c918c1d4714daeab5da12c698c60f3830d7d675d))


### Bug Fixes

* **fastedge:** rename path parameters to match updated OpenAPI spec ([2c17154](https://github.com/G-Core/gcore-python/commit/2c17154346bd0f1663ecccadf5a444e0b21c6134))


### Chores

* **examples:** suppress pyright deprecation warnings in storage examples ([81806bb](https://github.com/G-Core/gcore-python/commit/81806bbe78c871a60e6ca613e7b24c3442293f90))
* remove .vscode/ ([8490ade](https://github.com/G-Core/gcore-python/commit/8490ade7834974693fa6e9df0dd44edabe4050e7))

## 0.37.0 (2026-03-09)

Full Changelog: [v0.36.0...v0.37.0](https://github.com/G-Core/gcore-python/compare/v0.36.0...v0.37.0)

### Features

* add descriptions for all Terraform-enabled resources ([d802ff9](https://github.com/G-Core/gcore-python/commit/d802ff9777ba4f84ec0c7119745ba16d4b3415a3))
* **api:** aggregated API specs update ([990421e](https://github.com/G-Core/gcore-python/commit/990421e11d813a6808af59712a8c48655cd15b34))
* **api:** aggregated API specs update ([471fef6](https://github.com/G-Core/gcore-python/commit/471fef6b01e2dac4a54482d376cdb7613b0bc8da))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([f27a1a5](https://github.com/G-Core/gcore-python/commit/f27a1a59c629c1437e61e49dd352ca424610adc1))
* **test:** do not count install time for mock server timeout ([fca27a6](https://github.com/G-Core/gcore-python/commit/fca27a6157f527eb6171149db7d6b1133877df2e))
* update placeholder string ([5eacc92](https://github.com/G-Core/gcore-python/commit/5eacc925d581b8dd856329d815c94d4d40f0f355))

## 0.36.0 (2026-03-03)

Full Changelog: [v0.35.0...v0.36.0](https://github.com/G-Core/gcore-python/compare/v0.35.0...v0.36.0)

### ⚠ BREAKING CHANGES

* **cloud:** update gpu baremetal endpoints to latest versions

### Features

* **api:** aggregated API specs update ([a93c782](https://github.com/G-Core/gcore-python/commit/a93c7824afaeafd8b1bc641fc7145ed38d3049fb))
* **api:** aggregated API specs update ([394275c](https://github.com/G-Core/gcore-python/commit/394275c5f5937961bbd0fad0dc2d0b9ab22b8230))
* **api:** aggregated API specs update ([b484f9c](https://github.com/G-Core/gcore-python/commit/b484f9c9aa4d3e54b42b49fbb06805d290ec2264))
* **api:** aggregated API specs update ([0e36db9](https://github.com/G-Core/gcore-python/commit/0e36db93402657340c5c9f38263662ba0c905593))
* **cloud:** update gpu baremetal endpoints to latest versions ([14512b9](https://github.com/G-Core/gcore-python/commit/14512b9907e7201e6b3f6a934dd84d0f277fc55c))


### Bug Fixes

* **cloud:** restore custom polling methods and missing wrappers for gpu baremetal ([3321a2f](https://github.com/G-Core/gcore-python/commit/3321a2f287f4a94aa88c738f09c5677e2c670ca9))


### Chores

* **docs:** add missing descriptions ([caa4cb6](https://github.com/G-Core/gcore-python/commit/caa4cb6e2a36f9c3ab7213480020421385c86e4e))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([cdfe354](https://github.com/G-Core/gcore-python/commit/cdfe3544b44f065624b5d7054873b291a54da836))

## 0.35.0 (2026-02-24)

Full Changelog: [v0.34.0...v0.35.0](https://github.com/G-Core/gcore-python/compare/v0.34.0...v0.35.0)

### Features

* add /release skill ([90db06d](https://github.com/G-Core/gcore-python/commit/90db06dccfcfd8dcc044818d89f851d97df4b7be))
* **api:** aggregated API specs update ([46ef334](https://github.com/G-Core/gcore-python/commit/46ef3348dcfd5ca7c1ecd8dd5f8ea9f8d46d230d))


### Bug Fixes

* **cloud:** get cluster_id from task created_resources.clusters ([b0d1b0d](https://github.com/G-Core/gcore-python/commit/b0d1b0dc11b92176083d7d467e28d1e52c253c7f))

## 0.34.0 (2026-02-23)

Full Changelog: [v0.33.0...v0.34.0](https://github.com/G-Core/gcore-python/compare/v0.33.0...v0.34.0)

### ⚠ BREAKING CHANGES

* **iam:** rename models and update examples
* **iam:** rename models and update examples
* **waap:** move domains.toggle_policy to domains.policies.toggle
* **waap:** split api_discovery methods into scan_results, openapi, and settings subresources
* **streaming:** move streams clip methods to streams.clips
* **streaming:** move playlists.list_videos to playlists.videos.list
* **cdn:** move ip_ranges.list_ips to ips.list

### Features

* **api:** aggregated API specs update ([39acbb8](https://github.com/G-Core/gcore-python/commit/39acbb811cad1725b4396ef6ede094ef4c4c5e02))
* **api:** aggregated API specs update ([ebf5798](https://github.com/G-Core/gcore-python/commit/ebf57985fa967cc5f8abd167ba09110a7c832950))
* **api:** aggregated API specs update ([0deadd1](https://github.com/G-Core/gcore-python/commit/0deadd1591cdf99fa6c8dc62d3c239b5d7aa7587))
* **api:** aggregated API specs update ([507f04d](https://github.com/G-Core/gcore-python/commit/507f04d10f8307628092b91d0333fb1682d829eb))
* **api:** aggregated API specs update ([dc25cc7](https://github.com/G-Core/gcore-python/commit/dc25cc76e4dd199daa6ff8128d1e03ee8f42ffbf))
* **api:** aggregated API specs update ([34d65c1](https://github.com/G-Core/gcore-python/commit/34d65c17e2438ba6ab5d60907936eb5d12181a31))
* **api:** aggregated API specs update ([079e24c](https://github.com/G-Core/gcore-python/commit/079e24cd6522792e9d841a2e0f408e21e617e05e))
* **api:** aggregated API specs update ([9255354](https://github.com/G-Core/gcore-python/commit/925535479aea739b6abbd1fa76ea892d342fc355))
* **api:** manual updates ([15d9e1a](https://github.com/G-Core/gcore-python/commit/15d9e1aaa61c40d63fbe4d7a7e62c5b81ddebe7d))
* **cdn:** enable terraform generation for cdn rules ([4724ee3](https://github.com/G-Core/gcore-python/commit/4724ee3468cadb989bdc0b99e79de4b243e870f8))
* **cloud:** add create_and_poll/delete_and_poll for security group rules ([#151](https://github.com/G-Core/gcore-python/issues/151)) ([b0934b4](https://github.com/G-Core/gcore-python/commit/b0934b4bdcf62c3af24356dcf28aedb10e5c175a))
* **cloud:** enable terraform for security group rules (v2) ([9cd0f53](https://github.com/G-Core/gcore-python/commit/9cd0f536ca121d44af097dda1a1f14f77f3293bf))


### Bug Fixes

* **api:** revert unnecessary changes to additionalProperties ([fd60fa5](https://github.com/G-Core/gcore-python/commit/fd60fa500bfbcfd29d77da460801a2b45c7c416f))
* **client:** mark count in offset pagination as required ([889d7fd](https://github.com/G-Core/gcore-python/commit/889d7fd6d71b00e549a1f31a09ccc1cf7797540c))
* **cloud:** keep v1 replace method for security group rules ([6611ee4](https://github.com/G-Core/gcore-python/commit/6611ee4adae0a5c428e147c8cc56b363d4f789b0))
* **cloud:** unset correct envs in scripts/test ([7443a58](https://github.com/G-Core/gcore-python/commit/7443a589d5daccf5bb96e44703126299b0af405d))
* **storage:** update storage type and ignore deprecation in examples ([df7fbed](https://github.com/G-Core/gcore-python/commit/df7fbed9dca33894eaf3111bf7d87b0a1aa16977))
* **waap:** split api_discovery methods into scan_results, openapi, and settings subresources ([b1c884f](https://github.com/G-Core/gcore-python/commit/b1c884f463f33289b820eb5565ac9d7d74afbb2f))


### Chores

* **internal:** add request options to SSE classes ([7c4bdc6](https://github.com/G-Core/gcore-python/commit/7c4bdc6cbcfa8d8fa1a366c0f6090d290499a6f6))
* **internal:** make `test_proxy_environment_variables` more resilient ([9e8214f](https://github.com/G-Core/gcore-python/commit/9e8214f50ae018ccd50ffaca2e5c6ca516f2a4a6))
* **streaming:** skip Clip tests ([da190a9](https://github.com/G-Core/gcore-python/commit/da190a97f8f42fc930c4381b62e6e2230e9961a1))
* update mock server docs ([4e4a1f8](https://github.com/G-Core/gcore-python/commit/4e4a1f8ea185a3f84be9c68839569002b8c08e2f))


### Refactors

* **cdn:** move ip_ranges.list_ips to ips.list ([d86c213](https://github.com/G-Core/gcore-python/commit/d86c21322c7ea98ba5ada8ddb6e93843ac2c7719))
* **iam:** rename models and update examples ([2da7f85](https://github.com/G-Core/gcore-python/commit/2da7f85bd5944349aec34c473638a3c30f3a9f23))
* **iam:** rename models and update examples ([9dce180](https://github.com/G-Core/gcore-python/commit/9dce180a6be142c2a75e12ce2978565d438694f9))
* **streaming:** move playlists.list_videos to playlists.videos.list ([c156758](https://github.com/G-Core/gcore-python/commit/c156758df6af4bc9516794adf1ab984d7f17d29e))
* **streaming:** move streams clip methods to streams.clips ([3618fc7](https://github.com/G-Core/gcore-python/commit/3618fc747692a6b6921ec82cba39180b6d99021a))
* **waap:** move domains.toggle_policy to domains.policies.toggle ([e17429a](https://github.com/G-Core/gcore-python/commit/e17429ad3e37a2eef866b61833b1176cfac5b6d1))

## 0.33.0 (2026-02-16)

Full Changelog: [v0.32.0...v0.33.0](https://github.com/G-Core/gcore-python/compare/v0.32.0...v0.33.0)

### Features

* **api:** aggregated API specs update ([13374b4](https://github.com/G-Core/gcore-python/commit/13374b4ad22fe8709ae1cd0ab9d31c2ec9714a0b))
* **api:** aggregated API specs update ([55f0747](https://github.com/G-Core/gcore-python/commit/55f07478fb5b343efac0d43b0e0a1a5c1fdb8918))
* **api:** aggregated API specs update ([d6b782c](https://github.com/G-Core/gcore-python/commit/d6b782c24f6534edc3c2013d644e0d5f9fdffac5))
* **api:** revert(cdn): remove client_config subresource ([#207](https://github.com/G-Core/gcore-python/issues/207)) ([6bc418a](https://github.com/G-Core/gcore-python/commit/6bc418acdcfed56957b6c571ee2f6f29efa3663e))
* **cdn:** add client_config subresource for terraform ([5359417](https://github.com/G-Core/gcore-python/commit/535941718238395cdfc524c0bc5b59b4109fd8d1))


### Chores

* **cloud:** suppress deprecation warnings for security group rules ([d263a2e](https://github.com/G-Core/gcore-python/commit/d263a2e356d317f3cb4301ee0b10b1863a888178))
* format all `api.md` files ([6f7ec77](https://github.com/G-Core/gcore-python/commit/6f7ec778e65dce7a413619b85df204268f26d178))

## 0.32.0 (2026-02-11)

Full Changelog: [v0.31.0...v0.32.0](https://github.com/G-Core/gcore-python/compare/v0.31.0...v0.32.0)

### Features

* **api:** aggregated API specs update ([a87437e](https://github.com/G-Core/gcore-python/commit/a87437e0d582d22c1f4f29bd585c7f757dcb4021))
* **api:** aggregated API specs update ([c9079e1](https://github.com/G-Core/gcore-python/commit/c9079e1461f0e43df0bae0150a37c48febe557aa))
* **api:** aggregated API specs update ([d0391a2](https://github.com/G-Core/gcore-python/commit/d0391a2bc77db00787ab6ebdaa46540f0a09fb4f))
* **api:** aggregated API specs update ([65973ea](https://github.com/G-Core/gcore-python/commit/65973ea8e16ca432498ef3772e47e9927c92a03d))
* **api:** aggregated API specs update ([732e36f](https://github.com/G-Core/gcore-python/commit/732e36f7509e3036b7800a809f14f364d47d9138))
* **api:** aggregated API specs update ([3b5292a](https://github.com/G-Core/gcore-python/commit/3b5292a5403a6cfa880072fbbb8dde2ca311f0bd))
* **api:** aggregated API specs update ([9bf5580](https://github.com/G-Core/gcore-python/commit/9bf55800ab1b90ac5f82e406b31fd61a5225afd9))


### Bug Fixes

* **cloud:** fix type in create_and_poll signature of load balancer listeners ([#146](https://github.com/G-Core/gcore-python/issues/146)) ([f99858a](https://github.com/G-Core/gcore-python/commit/f99858a1864e0142781c51f877c080a3b3f417cd))
* **fastedge:** remove readOnly name from app_store required fields ([b373e1a](https://github.com/G-Core/gcore-python/commit/b373e1a1b1dcc27962f61af8fc11047f79938801))
* **types:** correctly define false enum ([d5b033c](https://github.com/G-Core/gcore-python/commit/d5b033ca9bd2e52d248b979f739124b5a5c4de72))


### Chores

* **api:** minor updates ([b999f2c](https://github.com/G-Core/gcore-python/commit/b999f2c9623fa690a14fbc826aa51cb030121e47))
* **internal:** bump dependencies ([e5a7288](https://github.com/G-Core/gcore-python/commit/e5a7288a0957da491df6c2cedb2275cbe7d99e11))
* **internal:** fix lint error on Python 3.14 ([60245d0](https://github.com/G-Core/gcore-python/commit/60245d056b32bc23783f135102fe2acfe6627f88))

## 0.31.0 (2026-01-30)

Full Changelog: [v0.30.0...v0.31.0](https://github.com/G-Core/gcore-python/compare/v0.30.0...v0.31.0)

### ⚠ BREAKING CHANGES

* **cdn:** rename resource to cdn_resource
* **api:** change type casing from Cdn* to CDN*

### Features

* **api:** aggregated API specs update ([cd35cbf](https://github.com/G-Core/gcore-python/commit/cd35cbf266cf598045a8a4f8ebf3cf7cd8340092))
* **api:** aggregated API specs update ([a7076d0](https://github.com/G-Core/gcore-python/commit/a7076d04fa78e4ea71b148ef8c10d0013536e904))
* **api:** manual upload of aggregated API specs ([47734d2](https://github.com/G-Core/gcore-python/commit/47734d2b4fcd22875d2ec80b2b0453600b912eca))
* **api:** refactor(cdn)!: change type casing from Cdn* to CDN* ([4ea3f5c](https://github.com/G-Core/gcore-python/commit/4ea3f5c23afe085bf5c8b25dadfb1bcd1899edfe))
* **client:** add custom JSON encoder for extended type support ([b0c58f9](https://github.com/G-Core/gcore-python/commit/b0c58f9f042c3e67b63d99bded8179c943d29711))


### Bug Fixes

* **client:** internal references to CDN types ([13f5d35](https://github.com/G-Core/gcore-python/commit/13f5d3512b170ee9db3757768cbafb44831c61c4))


### Chores

* **ci:** upgrade `actions/github-script` ([a2328c0](https://github.com/G-Core/gcore-python/commit/a2328c02b6d94f8af8cdeb7dbc72d81f1e2d17d0))


### Refactors

* **cdn:** rename resource to cdn_resource ([aff2220](https://github.com/G-Core/gcore-python/commit/aff2220ee6c6d14566007e54136de563fa5df3e8))

## 0.30.0 (2026-01-22)

Full Changelog: [v0.29.0...v0.30.0](https://github.com/G-Core/gcore-python/compare/v0.29.0...v0.30.0)

### ⚠ BREAKING CHANGES

* **cloud:** use create and update v2 endpoints for security groups
* **cloud:** use v2 endpoint for floating IPs updates

### Features

* **api:** aggregated API specs update ([fa26406](https://github.com/G-Core/gcore-python/commit/fa264060cead49f546830f072683f4cd06f3351e))
* **cloud:** add create_and_poll and update_and_poll methods for security groups ([a0f8a75](https://github.com/G-Core/gcore-python/commit/a0f8a759796951e084b318e91a95ba413fa3b349))
* **cloud:** add update_and_poll method for floating IPs ([26bfe18](https://github.com/G-Core/gcore-python/commit/26bfe184ecda853f88b7ba13f4eb4f2153237a7b))
* **cloud:** use create and update v2 endpoints for security groups ([31501d3](https://github.com/G-Core/gcore-python/commit/31501d36608339851da4b8982bb32bf18a7518cb))
* **cloud:** use v2 endpoint for floating IPs updates ([31ef098](https://github.com/G-Core/gcore-python/commit/31ef0984768bca7f1aa8b2fa5eb8249fca7af36f))

## 0.29.0 (2026-01-19)

Full Changelog: [v0.28.0...v0.29.0](https://github.com/G-Core/gcore-python/compare/v0.28.0...v0.29.0)

### ⚠ BREAKING CHANGES

* **cloud:** rename instance flavor model

### Features

* **api:** aggregated API specs update ([02468c1](https://github.com/G-Core/gcore-python/commit/02468c1c9e318746cd3b251f0250bdc94e1ea6c0))
* **api:** aggregated API specs update ([34ed205](https://github.com/G-Core/gcore-python/commit/34ed205d304b9fb6606629ff42c4112739a102e8))
* **api:** aggregated API specs update ([5e0ea7b](https://github.com/G-Core/gcore-python/commit/5e0ea7be815dddcaeace5af49d07d3d74dff3224))
* **api:** aggregated API specs update ([3350bb9](https://github.com/G-Core/gcore-python/commit/3350bb9ec9d12d9299b505f62e5e335deaf37421))
* **api:** aggregated API specs update ([d2e76de](https://github.com/G-Core/gcore-python/commit/d2e76de6e6e070d6253ba6ee5102cbadb9fc1ff4))
* **api:** aggregated API specs update ([667f129](https://github.com/G-Core/gcore-python/commit/667f129c821808b2f2a250a90d4fb6adb36195e9))
* **api:** aggregated API specs update ([e4f64fd](https://github.com/G-Core/gcore-python/commit/e4f64fd76cb32caa28782a171a4cf1cb4c47674d))
* **api:** aggregated API specs update ([9f567f9](https://github.com/G-Core/gcore-python/commit/9f567f9268490b9c1b403a502ddd5f5e7a617534))
* **api:** aggregated API specs update ([43225eb](https://github.com/G-Core/gcore-python/commit/43225eb53397a63c3b44c518a20e665561d1a86e))
* **api:** aggregated API specs update ([3dc71fe](https://github.com/G-Core/gcore-python/commit/3dc71fe42e2466ae8040af28c77153383609e041))
* **api:** aggregated API specs update ([3c15807](https://github.com/G-Core/gcore-python/commit/3c15807ac8fdc5c0ca42421896f829054eaa82cf))
* **client:** add support for binary request streaming ([e5a58a3](https://github.com/G-Core/gcore-python/commit/e5a58a3024caa8212a2dd9e86c78087185fc798c))
* **client:** add support for binary request streaming ([780229b](https://github.com/G-Core/gcore-python/commit/780229bb9a47ad9b822e1bd3df576a6918a177ed))
* **cloud:** add support for volume snapshots ([19103d9](https://github.com/G-Core/gcore-python/commit/19103d9b95b37e597d545052d957d2593810307c))


### Bug Fixes

* **cloud:** rename instance flavor model ([3374f91](https://github.com/G-Core/gcore-python/commit/3374f91b05a70fbc617ef2e070b8fec96e0b08b8))
* **cloud:** update type for instance flavor in examples ([fabf3fb](https://github.com/G-Core/gcore-python/commit/fabf3fb6c466d52a3df10bcf46c7cbdcf82242cf))
* **examples:** ignore deprecated warnings for floating IPs ([9101b4f](https://github.com/G-Core/gcore-python/commit/9101b4f3204029c75a0dfd8e984436883a941baf))
* **examples:** ignore deprecated warnings for security groups ([823f421](https://github.com/G-Core/gcore-python/commit/823f421a34f787b95099f1dec06b5b64cc206cf4))
* use correct collection models ([31379f2](https://github.com/G-Core/gcore-python/commit/31379f2467ba06d4a049ce786d84f0c4dbb3d7c1))


### Chores

* **internal:** update `actions/checkout` version ([a407b00](https://github.com/G-Core/gcore-python/commit/a407b00b9771801ce82d55b0edd9a85c271fa7e2))

## 0.28.0 (2025-12-30)

Full Changelog: [v0.27.0...v0.28.0](https://github.com/G-Core/gcore-python/compare/v0.27.0...v0.28.0)

### ⚠ BREAKING CHANGES

* change naming for POST, PUT, PATCH, DELETE models

### Bug Fixes

* **cloud:** fix SSH keys examples ([4e79f57](https://github.com/G-Core/gcore-python/commit/4e79f578b04fbca2126a46aded663246c449eb64))


### Chores

* change naming for POST, PUT, PATCH, DELETE models ([ae21e7c](https://github.com/G-Core/gcore-python/commit/ae21e7c61096ade39749c39a7c4c7572516980e9))

## 0.27.0 (2025-12-30)

Full Changelog: [v0.26.0...v0.27.0](https://github.com/G-Core/gcore-python/compare/v0.26.0...v0.27.0)

### Features

* **api:** manual updates ([e6fec4e](https://github.com/G-Core/gcore-python/commit/e6fec4e8c85de66bd2557833cd03f38c30b19ecd))

## 0.26.0 (2025-12-23)

Full Changelog: [v0.25.0...v0.26.0](https://github.com/G-Core/gcore-python/compare/v0.25.0...v0.26.0)

### ⚠ BREAKING CHANGES

* **cloud:** move methods to gpu_baremetal_clusters.interfaces.attach()/detach()
* **cloud:** restructure to be gpu_virtual.clusters

### Features

* **api:** aggregated API specs update ([3a272e8](https://github.com/G-Core/gcore-python/commit/3a272e8b9a0399be48094ce82cc9127e59a2867a))
* **api:** aggregated API specs update ([789277a](https://github.com/G-Core/gcore-python/commit/789277a61a3ead490d9b8b0f439e0e21100036ba))
* **cloud:** add k8s cluster pools check quotas method ([326786c](https://github.com/G-Core/gcore-python/commit/326786cd4d499fffe760f308326bbd79003e4856))


### Bug Fixes

* **cloud:** move methods to gpu_baremetal_clusters.interfaces.attach()/detach() ([053ebcf](https://github.com/G-Core/gcore-python/commit/053ebcfdf462a66c3edc929e052b75d8afd51a20))
* **cloud:** restructure to be gpu_virtual.clusters ([36b7b63](https://github.com/G-Core/gcore-python/commit/36b7b63d98a20c3927069bb396154b068304f321))
* **examples:** make code consistent with comment ([85a0331](https://github.com/G-Core/gcore-python/commit/85a03310d31fa3ac6b74897b8754a19bd905df75))
* use async_to_httpx_files in patch method ([88c4050](https://github.com/G-Core/gcore-python/commit/88c4050f59d8a55796ab553a60b1e55aaadc81ca))


### Chores

* **internal:** add missing files argument to base client ([7d81efb](https://github.com/G-Core/gcore-python/commit/7d81efb323f72cdcaed3faa59a4fc5182f0fedab))
* **internal:** codegen related update ([3c38f42](https://github.com/G-Core/gcore-python/commit/3c38f4280bc1b57f987ff984c7504c4781d74ab8))
* speedup initial import ([ff1db23](https://github.com/G-Core/gcore-python/commit/ff1db23e58ffc5e118bd1fed3585ffc0cd04855e))

## 0.25.0 (2025-12-12)

Full Changelog: [v0.24.0...v0.25.0](https://github.com/G-Core/gcore-python/compare/v0.24.0...v0.25.0)

### ⚠ BREAKING CHANGES

* **cloud:** streamline vip connected and candidate ports

### Bug Fixes

* **cloud:** fix vip examples ([f4f6c46](https://github.com/G-Core/gcore-python/commit/f4f6c46f6352fb55eae9d91a2060f24289ed4dda))
* **cloud:** streamline vip connected and candidate ports ([958b2a7](https://github.com/G-Core/gcore-python/commit/958b2a735265407c29cc2ccd4b06566f9151dd15))

## 0.24.0 (2025-12-10)

Full Changelog: [v0.23.0...v0.24.0](https://github.com/G-Core/gcore-python/compare/v0.23.0...v0.24.0)

### ⚠ BREAKING CHANGES

* **cloud:** replace PUT /cloud/v1/l7policies with PATCH
* **cdn:** streamline audit_logs naming
* **cloud:** rename load balancer pool member methods to create/delete
* streamline naming for create/replace models

### Features

* **api:** aggregated API specs update ([67dc79f](https://github.com/G-Core/gcore-python/commit/67dc79fea2b041b24b212a02e927ccbd243e4522))
* **api:** aggregated API specs update ([7656563](https://github.com/G-Core/gcore-python/commit/7656563fc5dd17e35f6818812ca099251cdda258))
* **api:** aggregated API specs update ([a1d51b8](https://github.com/G-Core/gcore-python/commit/a1d51b8ff11dc70e5f8f534cb45e87e1eba2cc14))
* **api:** aggregated API specs update ([c5159ef](https://github.com/G-Core/gcore-python/commit/c5159efb03e551f71ed83f7efd3a9b73f5017d1d))
* **api:** aggregated API specs update ([61299ed](https://github.com/G-Core/gcore-python/commit/61299edb52f077ab1cd4ac198b3ce59283fe779c))
* **api:** aggregated API specs update ([b745f43](https://github.com/G-Core/gcore-python/commit/b745f43a066be1d41dd690c0e767d60e495c4a6c))
* **dns:** enable terraform code generation for gcore_dns_network_mapping ([145f10c](https://github.com/G-Core/gcore-python/commit/145f10ce4125be5a97ec6f092e4056ff78b2f3b1))


### Bug Fixes

* **cdn:** streamline audit_logs naming ([cb075f5](https://github.com/G-Core/gcore-python/commit/cb075f51ee3bda135fbeb9eae1957ad0cda1c22a))
* **cloud:** fix types in examples ([8b73b2a](https://github.com/G-Core/gcore-python/commit/8b73b2ae7a25cd187f5eeeb8e264c8ea6b22aaa1))
* **cloud:** rename load balancer pool member methods to create/delete ([86346d4](https://github.com/G-Core/gcore-python/commit/86346d4fd0f464f120dd0ed6c1e7fb2b0107a625))
* **cloud:** replace PUT /cloud/v1/l7policies with PATCH ([310c86d](https://github.com/G-Core/gcore-python/commit/310c86dfebff83232844a7bed4b8c8094f0f38a6))
* **cloud:** use PATCH /cloud/v1/projects ([de29040](https://github.com/G-Core/gcore-python/commit/de29040774e27e8fd6ea552d6f47ca60a1992976))
* streamline naming for create/replace models ([06e1dc3](https://github.com/G-Core/gcore-python/commit/06e1dc32499533ad16b88458164ec5a9ea385cc5))
* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([616698d](https://github.com/G-Core/gcore-python/commit/616698d4f75cd79685904b3ff5cf7a4057525332))


### Chores

* add missing docstrings ([91761cb](https://github.com/G-Core/gcore-python/commit/91761cb4af0ee9824166a9b4eb966f981547d9ec))
* **docs:** use environment variables for authentication in code snippets ([2c2fa17](https://github.com/G-Core/gcore-python/commit/2c2fa1790799aab90409f65669bcb7f48659a7cb))
* update lockfile ([ece4535](https://github.com/G-Core/gcore-python/commit/ece45355779bfa9a8d3c68783cd3512236f83f96))

## 0.23.0 (2025-12-01)

Full Changelog: [v0.22.0...v0.23.0](https://github.com/G-Core/gcore-python/compare/v0.22.0...v0.23.0)

### ⚠ BREAKING CHANGES

* **cloud:** change *_and_poll signature types to correspond to regular methods

### Features

* **api:** aggregated API specs update ([66af572](https://github.com/G-Core/gcore-python/commit/66af57201d06fc54c6b79a59690982bcc107fbfa))
* **api:** aggregated API specs update ([8e6e84f](https://github.com/G-Core/gcore-python/commit/8e6e84f26b4dfc56558641e3996529f7552a7b9f))


### Bug Fixes

* **cloud:** change *_and_poll signature types to correspond to regular methods ([d58e9b4](https://github.com/G-Core/gcore-python/commit/d58e9b48d2aa104beef736c57b6170886bea6072))
* ensure streams are always closed ([e2716cb](https://github.com/G-Core/gcore-python/commit/e2716cbc3b7de2b3fe7eef68fa1c07dcf4014385))


### Chores

* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([7703d53](https://github.com/G-Core/gcore-python/commit/7703d534a550a9465212e391aeeef906cf589dd0))

## 0.22.0 (2025-11-25)

Full Changelog: [v0.21.0...v0.22.0](https://github.com/G-Core/gcore-python/compare/v0.21.0...v0.22.0)

### ⚠ BREAKING CHANGES

* **cloud:** k8s references from k8 to k8s
* **cloud:** updates to get/list LB l7 policy/rules models

### Features

* **api:** aggregated API specs update ([49ac2ae](https://github.com/G-Core/gcore-python/commit/49ac2ae5ff6575877adfc16d46454c1ddf9b4160))
* **api:** aggregated API specs update ([299adc0](https://github.com/G-Core/gcore-python/commit/299adc06cba63fb89bd3cd5f17d10188db08c735))
* **api:** aggregated API specs update ([fff1d1e](https://github.com/G-Core/gcore-python/commit/fff1d1e981d3c286288c77c0a9a7c3fa146abd80))
* **cloud:** updates to get/list LB l7 policy/rules models ([95a4cf1](https://github.com/G-Core/gcore-python/commit/95a4cf12132dc638e3a0994e3b5a5249b079e5ad))


### Bug Fixes

* add overloads to L7 policy polling methods to match create/replace signatures ([ecd63d8](https://github.com/G-Core/gcore-python/commit/ecd63d8704925bb86d232ea97e90bf7b45bb6e0b))
* add overloads to L7 policy polling methods to match create/replace signatures ([44d657e](https://github.com/G-Core/gcore-python/commit/44d657e515ffd4c65bdcd82a419f85db138ceeba))
* **cloud:** add overloads to L7 policy polling methods ([a639930](https://github.com/G-Core/gcore-python/commit/a639930e1d18b1a95ba4dfff4b847efc9093f5ef))
* **cloud:** k8s references from k8 to k8s ([96211ea](https://github.com/G-Core/gcore-python/commit/96211ea00c49baddd1ada6c26af994181bcd50de))
* resolve type errors in L7 policy/rule polling methods ([30e648f](https://github.com/G-Core/gcore-python/commit/30e648f9d9a5f6ed0ad7bb9b34272819d85fb594))


### Chores

* **internal:** codegen related update ([a6fbaff](https://github.com/G-Core/gcore-python/commit/a6fbaffe05cbdd3dac367525266a736d6b633ec1))

## 0.21.0 (2025-11-17)

Full Changelog: [v0.20.0...v0.21.0](https://github.com/G-Core/gcore-python/compare/v0.20.0...v0.21.0)

### Features

* **api:** aggregated API specs update ([0d13f58](https://github.com/G-Core/gcore-python/commit/0d13f58d129067316254f9907aebf3057495ca8d))

## 0.20.0 (2025-11-11)

Full Changelog: [v0.19.0...v0.20.0](https://github.com/G-Core/gcore-python/compare/v0.19.0...v0.20.0)

### Features

* **api:** aggregated API specs update ([767fdd5](https://github.com/G-Core/gcore-python/commit/767fdd5d74846369e3331efba210aff12a43e802))
* **cloud:** add support for GPU virtual clusters ([c406d97](https://github.com/G-Core/gcore-python/commit/c406d97d04db03f5c4d105f2e9761e9b8c2d96c8))


### Bug Fixes

* compat with Python 3.14 ([90bfffe](https://github.com/G-Core/gcore-python/commit/90bfffeed8b28a360e1489162d4dc6a28745b411))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([70e1cc8](https://github.com/G-Core/gcore-python/commit/70e1cc8404668e008c236881c5819eeff91725d6))


### Chores

* **package:** drop Python 3.8 support ([99955b9](https://github.com/G-Core/gcore-python/commit/99955b9208b2810fcbafbf5f8d941b5981faebbe))

## 0.19.0 (2025-11-07)

Full Changelog: [v0.18.0...v0.19.0](https://github.com/G-Core/gcore-python/compare/v0.18.0...v0.19.0)

### Features

* **api:** aggregated API specs update ([7c0231a](https://github.com/G-Core/gcore-python/commit/7c0231aa3836ea9ab69769c2c06fe3fb70ca4a7b))
* **api:** aggregated API specs update ([00be2a9](https://github.com/G-Core/gcore-python/commit/00be2a9da75503640bb2ce1383162c48170ef819))
* **api:** aggregated API specs update ([8469462](https://github.com/G-Core/gcore-python/commit/846946265537791605e00dd260d5bd1a8eb7bddf))
* **api:** aggregated API specs update ([2c780f3](https://github.com/G-Core/gcore-python/commit/2c780f329064bcabb64492d7a237f9865feffd14))

## 0.18.0 (2025-11-04)

Full Changelog: [v0.17.0...v0.18.0](https://github.com/G-Core/gcore-python/compare/v0.17.0...v0.18.0)

### Features

* **api:** aggregated API specs update ([c69f622](https://github.com/G-Core/gcore-python/commit/c69f622f4d085d5c93978edbf4deb2ecbe4279d6))
* **api:** aggregated API specs update ([e008291](https://github.com/G-Core/gcore-python/commit/e008291499f90553d12deffbcef5c4a9b6752f61))
* **api:** aggregated API specs update ([7e17f98](https://github.com/G-Core/gcore-python/commit/7e17f98624fecfb8d1ad5a53a001dcd20ca15214))
* **api:** aggregated API specs update ([01c7469](https://github.com/G-Core/gcore-python/commit/01c746977c89d813e54b97c87513960a5cba42c3))
* **api:** aggregated API specs update ([3ef8586](https://github.com/G-Core/gcore-python/commit/3ef8586481df9533a0627310458bb72b9b458d2f))
* **api:** aggregated API specs update ([af54c88](https://github.com/G-Core/gcore-python/commit/af54c886222ea41e6ef57d8683fbb64e2b688a15))
* **api:** aggregated API specs update ([4e62953](https://github.com/G-Core/gcore-python/commit/4e629534e07db80d93c46e5ccc5e3d2ba48d9eb4))
* **api:** aggregated API specs update ([18614cb](https://github.com/G-Core/gcore-python/commit/18614cb786fd3ea9020cee18c2a23c4c81f116f3))
* **api:** aggregated API specs update ([926c0dd](https://github.com/G-Core/gcore-python/commit/926c0ddfcef420ba47eca7b399ea43462a18371a))
* **cloud:** add support for postgres ([2802edf](https://github.com/G-Core/gcore-python/commit/2802edf3bbac88b644ba8ff4d5b83dc0606e4b48))


### Bug Fixes

* **client:** close streams without requiring full consumption ([cd7152c](https://github.com/G-Core/gcore-python/commit/cd7152cd959a9984e5c60edb41d16fa2db342012))
* **cloud:** members not optional in lb pools create_and_poll ([27bc07a](https://github.com/G-Core/gcore-python/commit/27bc07acab63505e03f4a5b51e21544fe84877ec))


### Chores

* **cloud:** add *_and_poll() to *WithRawResponse and *WithStreaming ([d8886ce](https://github.com/G-Core/gcore-python/commit/d8886ce4abeadd3d260c3f533e72b778d521482c))
* **internal/tests:** avoid race condition with implicit client cleanup ([67e4c77](https://github.com/G-Core/gcore-python/commit/67e4c77936fca0b2192b931ec71003dd62383c81))
* **internal:** grammar fix (it's -&gt; its) ([9bf8a18](https://github.com/G-Core/gcore-python/commit/9bf8a18f42a2122f43d9084ff3287e4d1aa7dd95))

## 0.17.0 (2025-10-21)

Full Changelog: [v0.16.0...v0.17.0](https://github.com/G-Core/gcore-python/compare/v0.16.0...v0.17.0)

### ⚠ BREAKING CHANGES

* **cloud:** rename to projects update
* **cloud:** use new PATCH files shares endpoint

### Features

* **api:** aggregated API specs update ([c9d6195](https://github.com/G-Core/gcore-python/commit/c9d6195649fd18c9c32107a978e0d40032b285be))
* **cdn:** add methods to list aws and alibaba regions ([0d1d290](https://github.com/G-Core/gcore-python/commit/0d1d290d11626ac0128329c005d048f0ab2f25dc))
* **client:** add client opt for cloud polling timeout ([bad7ecb](https://github.com/G-Core/gcore-python/commit/bad7ecbb58f0decc31e4091c5bdb0585b7471b09))
* **cloud:** add polling_timeout_seconds parameter to polling methods ([8b556ae](https://github.com/G-Core/gcore-python/commit/8b556aefc279caddaad9782747b2d6f65a523067))
* **cloud:** enable TF for placement groups ([63abaa7](https://github.com/G-Core/gcore-python/commit/63abaa7156d2a79bf27f9ba0d3fa2abb3a31aafd))
* **cloud:** support polling timeout in tasks.poll() ([3f8a419](https://github.com/G-Core/gcore-python/commit/3f8a419a48677e5f443248c963e045dd5169979a))


### Chores

* bump `httpx-aiohttp` version to 0.1.9 ([e906ee6](https://github.com/G-Core/gcore-python/commit/e906ee6224833181a4618bcd63671d9a131bca94))
* **cloud:** fix file shares examples ([c5cc6fa](https://github.com/G-Core/gcore-python/commit/c5cc6fa74b5678d08d1ed750872e424edd6f5377))
* **cloud:** rename to projects update ([f3f52da](https://github.com/G-Core/gcore-python/commit/f3f52da58998f8ce2637b99d1c944fd692861b48))
* **cloud:** use new PATCH files shares endpoint ([2ac6bce](https://github.com/G-Core/gcore-python/commit/2ac6bce8afbe4783620060964359d01ab105979e))


### Refactors

* **spec:** remove CDN deprecated endpoints ([193a257](https://github.com/G-Core/gcore-python/commit/193a257bcf3e00d85179809e63fa47b021323f65))

## 0.16.0 (2025-10-17)

Full Changelog: [v0.15.0...v0.16.0](https://github.com/G-Core/gcore-python/compare/v0.15.0...v0.16.0)

### ⚠ BREAKING CHANGES

* **cloud:** remove get and update list method for billing reservations
* **cloud:** use load_balancer_id in poll methods
* **cloud:** rename to load_balancer_id path param
* **cloud:** rename inference applications deployments update method

### Features

* **api:** aggregated API specs update ([ca4cbba](https://github.com/G-Core/gcore-python/commit/ca4cbbabc6c143e6a1c54e861cafbd38f906ebda))
* **api:** aggregated API specs update ([0d92524](https://github.com/G-Core/gcore-python/commit/0d92524c16aeac6e96b0360c49de70a7912a8485))
* **api:** aggregated API specs update ([7a58cae](https://github.com/G-Core/gcore-python/commit/7a58cae302e7a3818a11e616f967719db076fd25))
* **api:** aggregated API specs update ([c62d748](https://github.com/G-Core/gcore-python/commit/c62d7487ca76b74c8919c438b7d50979e75527cf))
* **api:** aggregated API specs update ([2a0347f](https://github.com/G-Core/gcore-python/commit/2a0347fbb670a29ca3cf0418637cd843bd8d535d))
* **api:** aggregated API specs update ([1dc8993](https://github.com/G-Core/gcore-python/commit/1dc8993163988b192d1f7bcedd2b4df4259f60d0))
* **api:** aggregated API specs update ([555824b](https://github.com/G-Core/gcore-python/commit/555824be97e936b2a20077870dfd50a186446e40))
* **api:** aggregated API specs update ([c8e06a9](https://github.com/G-Core/gcore-python/commit/c8e06a9c4db67838c190b7f985fa99e2ee1bc9f4))
* **api:** aggregated API specs update ([8eedd02](https://github.com/G-Core/gcore-python/commit/8eedd0251f0519932ccc9034383e56bbf385d4a4))
* **cloude:** remove cloud_lbmember name ([0c3df8e](https://github.com/G-Core/gcore-python/commit/0c3df8e1330f518b13457f5a3db8e7fcf963ea42))
* **cloud:** remove get and update list method for billing reservations ([b030ed6](https://github.com/G-Core/gcore-python/commit/b030ed6e7f2b26e396ebd2852df3e915b425a761))


### Bug Fixes

* **cloud:** rename to load_balancer_id path param ([ab273aa](https://github.com/G-Core/gcore-python/commit/ab273aadd364dc22a1fc8538c8b39c916fd002df))
* **cloud:** use load_balancer_id in poll methods ([6b55df9](https://github.com/G-Core/gcore-python/commit/6b55df953a0695b0047b947ab898063df9cba044))
* **examples:** suppress deprecation warnings for file shares update method ([#104](https://github.com/G-Core/gcore-python/issues/104)) ([0b3c21b](https://github.com/G-Core/gcore-python/commit/0b3c21b3f1f971a9d22623ae03c136e3aad84611))


### Chores

* add pull request template ([2e2997b](https://github.com/G-Core/gcore-python/commit/2e2997b1591f489581b6568c7adf9a4d39d5501c))
* **ci:** add fossa ([289bea8](https://github.com/G-Core/gcore-python/commit/289bea8c56d1b1e185dc1374628115b708aedcfa))
* **cloud:** rename inference applications deployments update method ([c672843](https://github.com/G-Core/gcore-python/commit/c6728438a3bba4d47de59bbdf30fe4d1c82a3d97))
* **internal:** detect missing future annotations with ruff ([9b55e6e](https://github.com/G-Core/gcore-python/commit/9b55e6e072e0f4210545e5fb91d5b628a8512cf8))

## 0.15.0 (2025-10-02)

Full Changelog: [v0.14.0...v0.15.0](https://github.com/G-Core/gcore-python/compare/v0.14.0...v0.15.0)

### Features

* **api:** Add missing reserved_fixed_ips update method ([b7b8db0](https://github.com/G-Core/gcore-python/commit/b7b8db03bd75a4889601a6da2fd5aa2e8004a141))
* **api:** aggregated API specs update ([8c59ffa](https://github.com/G-Core/gcore-python/commit/8c59ffa34fe9d77a585d53b9243fb0ec752de5c4))
* **api:** aggregated API specs update ([6281066](https://github.com/G-Core/gcore-python/commit/6281066df4e5cc479f7f53f731e4ecd59f41e7a4))
* **api:** aggregated API specs update ([0a2f63b](https://github.com/G-Core/gcore-python/commit/0a2f63b1a5dd2dfc26cfa9b3e5ad4e4e997e4988))


### Bug Fixes

* **examples:** remove unnecessary None checks in quota examples ([#97](https://github.com/G-Core/gcore-python/issues/97)) ([ff71c83](https://github.com/G-Core/gcore-python/commit/ff71c83bb97e5fabf25efc32e0e2f6b60addbe64))

## 0.14.0 (2025-09-30)

Full Changelog: [v0.13.0...v0.14.0](https://github.com/G-Core/gcore-python/compare/v0.13.0...v0.14.0)

### Features

* **api:** aggregated API specs update ([0e7967b](https://github.com/G-Core/gcore-python/commit/0e7967b1f6be77cac807f5a1e3d3483c9151902b))
* **api:** aggregated API specs update ([0199b8c](https://github.com/G-Core/gcore-python/commit/0199b8ccce3fc74ba60586b9cbe6411b29bf9ece))
* **api:** aggregated API specs update ([0784cf9](https://github.com/G-Core/gcore-python/commit/0784cf918ef8d820a7a5ecfd9dc5b185829041a1))
* **api:** aggregated API specs update ([f1ff659](https://github.com/G-Core/gcore-python/commit/f1ff65992ff4992554d00f10b1b17794155cc129))
* **api:** aggregated API specs update ([fc88cbd](https://github.com/G-Core/gcore-python/commit/fc88cbd66531167d50927d4a87c53d5f05fbdce1))
* **cdn:** add API support ([e07d4e7](https://github.com/G-Core/gcore-python/commit/e07d4e7427042c2996c6dae86f70f0cc86a8d6d5))
* **cloud:** enable TF for floating IPs ([634f34b](https://github.com/G-Core/gcore-python/commit/634f34b96fb7e74f7566493af8716f90d85016b9))


### Bug Fixes

* **client:** correctly generate K8sClusterSlurmAddonV2Serializers ([e5961ca](https://github.com/G-Core/gcore-python/commit/e5961ca7683a89bf6e551bd4bedd82c1b76e4052))


### Chores

* do not install brew dependencies in ./scripts/bootstrap by default ([9482c47](https://github.com/G-Core/gcore-python/commit/9482c4755e629b9411290d189efc5f1de4bbbec1))
* improve example values ([2560541](https://github.com/G-Core/gcore-python/commit/25605419cf1878d28e77251f44246b68212efb8a))
* **internal:** update pydantic dependency ([adf8df6](https://github.com/G-Core/gcore-python/commit/adf8df69810c6e978395aefe12b4ba6f88772d16))
* **types:** change optional parameter type from NotGiven to Omit ([24bebe1](https://github.com/G-Core/gcore-python/commit/24bebe1a809b38732c6b960f5cc6703fa2d6d1be))
* use Omit in more places ([2a4abf1](https://github.com/G-Core/gcore-python/commit/2a4abf1aa6f07c9c9f8d16150caed76e8e35a146))

## 0.13.0 (2025-09-16)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/G-Core/gcore-python/compare/v0.12.0...v0.13.0)

### ⚠ BREAKING CHANGES

* **waap:** model references

### Features

* **api:** aggregated API specs update ([2954990](https://github.com/G-Core/gcore-python/commit/295499000a8e2b1ef24ae497cb34fafbf38f2149))
* **api:** aggregated API specs update ([09db4dd](https://github.com/G-Core/gcore-python/commit/09db4dde07cbec7bb8e94348c6ef78578c3022d3))
* **api:** aggregated API specs update ([a2de60c](https://github.com/G-Core/gcore-python/commit/a2de60c773c01aeb6223001a0d8bff5463fa82ef))
* **api:** aggregated API specs update ([ccf4739](https://github.com/G-Core/gcore-python/commit/ccf4739750f27e01ece2ff147458dd7fe9305437))
* **api:** aggregated API specs update ([484ee11](https://github.com/G-Core/gcore-python/commit/484ee1144558b56f40d5bc41b9613370dc74c42e))
* **cloud:** support floating IPs update ([28a8882](https://github.com/G-Core/gcore-python/commit/28a888260878577e697004da02077ef96a8616ad))
* **dns:** replace post with get in check delegation status ([ddd12bd](https://github.com/G-Core/gcore-python/commit/ddd12bd4782b8883d82b97a45d043ad3970ee31a))


### Bug Fixes

* **cloud:** floating ips examples ([bf8a5dd](https://github.com/G-Core/gcore-python/commit/bf8a5ddff3e777441db47163dc03b73052d99ecd))
* **waap:** model references ([4f69e7e](https://github.com/G-Core/gcore-python/commit/4f69e7e5aa778cf82357d7d097e874100bfa9e0d))

## 0.12.0 (2025-09-11)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/G-Core/gcore-python/compare/v0.11.0...v0.12.0)

### Features

* **api:** aggregated API specs update ([3fbc8f1](https://github.com/G-Core/gcore-python/commit/3fbc8f1a6126f4cb6d9e6a0aff7f35f67f77ec6f))
* **cloud:** add create_and_poll() and delete_and_poll() to reserved fixed ips ([6e6efc0](https://github.com/G-Core/gcore-python/commit/6e6efc03de62b895199a043e0cf1b396aefb0d01))
* **cloud:** add polling methods to volumes ([3537e8c](https://github.com/G-Core/gcore-python/commit/3537e8c5b6ebd0500868dfc2b14bfeba735fe1f5))


### Refactors

* **storage:** use v2 endpoint ([4a00499](https://github.com/G-Core/gcore-python/commit/4a00499c3bc80a6f06e476bd1c0d544bd1c46cef))

## 0.11.0 (2025-09-09)

Full Changelog: [v0.10.0...v0.11.0](https://github.com/G-Core/gcore-python/compare/v0.10.0...v0.11.0)

### ⚠ BREAKING CHANGES

* **cloud:** update polling methods signatures
* **cloud:** migrate baremetal gpu cluster from v1 to v3
* **cloud:** support inference applications

### Features

* **api:** aggregated API specs update ([931c594](https://github.com/G-Core/gcore-python/commit/931c5941afceba9f8cc84e0bfccd727f5d40bd78))
* **api:** aggregated API specs update ([f6d4e0b](https://github.com/G-Core/gcore-python/commit/f6d4e0b2f721b6dfa531e6246fb7f4ea270df75e))
* **api:** aggregated API specs update ([86b63d4](https://github.com/G-Core/gcore-python/commit/86b63d43a1197c77ae6d6df4f92d32a78db5f211))
* **api:** aggregated API specs update ([09eeb95](https://github.com/G-Core/gcore-python/commit/09eeb95a33f70d79cab833c0e1c599fa13599e69))
* **api:** aggregated API specs update ([72414c5](https://github.com/G-Core/gcore-python/commit/72414c5f92c2af4a7fbc01871271900b5a69ac88))
* **api:** aggregated API specs update ([ac889a3](https://github.com/G-Core/gcore-python/commit/ac889a31107fb2c9525a8a3e9c889bdf718b2b8b))
* **api:** aggregated API specs update ([98f84bc](https://github.com/G-Core/gcore-python/commit/98f84bce3cba455432f94aa21de179c385dc2e19))
* **api:** aggregated API specs update ([86d8c4f](https://github.com/G-Core/gcore-python/commit/86d8c4fdc885691c89c385f275c5fc389d81c349))
* **api:** aggregated API specs update ([ba76405](https://github.com/G-Core/gcore-python/commit/ba76405912b3514cd9836c49d41b564ca911e8f5))
* **api:** aggregated API specs update ([d14eac7](https://github.com/G-Core/gcore-python/commit/d14eac7b754be27c008f44462cc965292ab99e95))
* **api:** aggregated API specs update ([6a790b7](https://github.com/G-Core/gcore-python/commit/6a790b71e6dbd81e33aba81612c305240624062d))
* **api:** aggregated API specs update ([e7e2da7](https://github.com/G-Core/gcore-python/commit/e7e2da79cf39dc75aa4178267b7ee5a4c31189ae))
* **api:** aggregated API specs update ([165290f](https://github.com/G-Core/gcore-python/commit/165290f51e1c0913b9b324e03472e4134f9c7a31))
* **api:** aggregated API specs update ([a56f7d1](https://github.com/G-Core/gcore-python/commit/a56f7d17b74d5c4489024edf5f3eb26eef802ee1))
* **api:** aggregated API specs update ([12bae5a](https://github.com/G-Core/gcore-python/commit/12bae5ae6cbdf0d73da465fd7b1382c36ff0d00a))
* **api:** aggregated API specs update ([2576f9c](https://github.com/G-Core/gcore-python/commit/2576f9cc8143fae02367e94e693cafd8954209c4))
* **api:** aggregated API specs update ([5de1f95](https://github.com/G-Core/gcore-python/commit/5de1f95503f39a215839a6d86d9f692904ee0267))
* **api:** api update ([602ef7d](https://github.com/G-Core/gcore-python/commit/602ef7daaecd2c5af65a73adba4055e4a74c8c24))
* **api:** manual updates ([fca7094](https://github.com/G-Core/gcore-python/commit/fca709450327ddeaaa6d9bc70a15f4ac3f46d30c))
* **api:** manual upload of aggregated API specs ([45843a3](https://github.com/G-Core/gcore-python/commit/45843a39873202bec9e0874526379cce0beb5f4e))
* **api:** manual upload of aggregated API specs ([aad5c71](https://github.com/G-Core/gcore-python/commit/aad5c71696d2940cd3f443208c02acc55d5224e3))
* **api:** update field_value type ([2095ccc](https://github.com/G-Core/gcore-python/commit/2095ccc238b559e5e048bc86ddd8e93ba372f88c))
* **cloud:** add create_and_poll() and delete_and_poll() for floating ips ([e645a83](https://github.com/G-Core/gcore-python/commit/e645a83cde29fe50dfed87d1a9210134ec4b8e7b))
* **cloud:** add create_and_poll() for subnets ([d537d4e](https://github.com/G-Core/gcore-python/commit/d537d4ed2dfda9d051d327a9bf55726f04f35104))
* **cloud:** add managed k8s ([9b88526](https://github.com/G-Core/gcore-python/commit/9b885262b12c18f0f7ac17accebbb7e8d4ad4d48))
* **cloud:** add new_and_poll() and delete_and_poll() for networks ([fda3191](https://github.com/G-Core/gcore-python/commit/fda3191c4680f62d2eb089db258e6c9e084303ed))
* **cloud:** add polling for instance action and interfaces attach/detach ([ee59347](https://github.com/G-Core/gcore-python/commit/ee593474fe8f788d09b40e46995af7f993a32dcd))
* **cloud:** fetch client_id from iam in cloud quotas examples ([daaf5e1](https://github.com/G-Core/gcore-python/commit/daaf5e10afe359e74d93fb9ac96061a38be107e0))
* **cloud:** migrate baremetal gpu cluster from v1 to v3 ([064b2a1](https://github.com/G-Core/gcore-python/commit/064b2a1b4d56ff3ab8a1ed34e2dca64c9713d0b6))
* **cloud:** remove inference model examples ([958a08e](https://github.com/G-Core/gcore-python/commit/958a08e51577f6e5d95fee19500e8f96bd552c95))
* **cloud:** support inference applications ([dcf34ac](https://github.com/G-Core/gcore-python/commit/dcf34acdce70518d2bf119d7ca5ae50bec1521bd))
* **cloud:** use PATCH /v2/lbpools ([6da421d](https://github.com/G-Core/gcore-python/commit/6da421dc9d1d3206b5e2275a84432cd0ce1b9d3b))
* improve future compat with pydantic v3 ([cc3a79f](https://github.com/G-Core/gcore-python/commit/cc3a79f2268c3ced2cd0c3634844d01f2657c69d))
* **s3:** add object storage ([7e1ed77](https://github.com/G-Core/gcore-python/commit/7e1ed7740b7a41454bc2779a0937f0c5ca5d4349))
* **storage:** make list storage locations paginated ([eeef646](https://github.com/G-Core/gcore-python/commit/eeef64689a62cb5cc0546a616097f35e85492803))
* **types:** replace List[str] with SequenceNotStr in params ([be5d331](https://github.com/G-Core/gcore-python/commit/be5d331430334b7e779510f99a4b6a0cddbb1859))


### Bug Fixes

* avoid newer type syntax ([adc20b7](https://github.com/G-Core/gcore-python/commit/adc20b7bc65b75be4d105cf05a886f7db299b2c4))
* **cloud:** update polling methods signatures ([a5ecf6a](https://github.com/G-Core/gcore-python/commit/a5ecf6ac3957532628de955bd12b9f8c688861c4))
* **dns:** fix dns methods ([58f23c0](https://github.com/G-Core/gcore-python/commit/58f23c07ac519f9ba1c181bce131a140e2151001))
* **types:** add missing types to method arguments ([bec1dff](https://github.com/G-Core/gcore-python/commit/bec1dff935fa6f933c7ac3118e0e4e5cb463da72))
* **waap:** fix component name ([fabb616](https://github.com/G-Core/gcore-python/commit/fabb616f3fe3c61a262275d7e359c7eafc324c8c))


### Chores

* formatting ([d739b03](https://github.com/G-Core/gcore-python/commit/d739b037fdfdee9dd86a283434b4d8c2e2c9b53b))
* **internal:** add Sequence related utils ([daed5dc](https://github.com/G-Core/gcore-python/commit/daed5dc7a9f6bd8472da9bcad00bf4521f13efe8))
* **internal:** change ci workflow machines ([cf13b4e](https://github.com/G-Core/gcore-python/commit/cf13b4e5b16ce2f6921e65fd780d780e83e95ff5))
* **internal:** codegen related update ([0c6db9d](https://github.com/G-Core/gcore-python/commit/0c6db9d80d32327c271a81355319dea0c01b3836))
* **internal:** codegen related update ([835fc54](https://github.com/G-Core/gcore-python/commit/835fc543e274454f92ee81b2af8ff5a203a14571))
* **internal:** codegen related update ([04ce18a](https://github.com/G-Core/gcore-python/commit/04ce18ae770a17fe93fdec4c594d8e1ff03b0b4a))
* **internal:** detect breaking changes when removing endpoints ([1fdb544](https://github.com/G-Core/gcore-python/commit/1fdb544c80140e5133cc272d5b1c1f2de897ce0f))
* **internal:** improve breaking change detection ([cf699e9](https://github.com/G-Core/gcore-python/commit/cf699e9bc204256be2984ed0d6bb42ec168d0f79))
* **internal:** minor formatting change ([48573ba](https://github.com/G-Core/gcore-python/commit/48573ba1f69b104a005f35595b8f7829790c75bc))
* **internal:** move mypy configurations to `pyproject.toml` file ([1961ffc](https://github.com/G-Core/gcore-python/commit/1961ffc1434500cf47ef776b947d5eff18307502))
* **internal:** update comment in script ([e11594e](https://github.com/G-Core/gcore-python/commit/e11594e226edc21949a7e319434a6032271f7119))
* **internal:** update pyright exclude list ([5b2e640](https://github.com/G-Core/gcore-python/commit/5b2e640a05b46321c6d0438a89a39b5f3e0f2678))
* **tests:** simplify `get_platform` test ([ebdb1e8](https://github.com/G-Core/gcore-python/commit/ebdb1e8ed0ab19745e41cd354196368cff14ef20))
* **tests:** unskip tests failing due to wrong Prism routing ([6d24ccb](https://github.com/G-Core/gcore-python/commit/6d24ccb1b2927f54e4ca795a484c9c924c2f50d4))
* update @stainless-api/prism-cli to v5.15.0 ([bed3f36](https://github.com/G-Core/gcore-python/commit/bed3f36e6b0ec73ae01f595e45ffad0052721df2))
* update github action ([13f7cfd](https://github.com/G-Core/gcore-python/commit/13f7cfdd9e914d9b65bd3758b812f08a8a6f24cb))

## 0.10.0 (2025-08-07)

Full Changelog: [v0.9.0...v0.10.0](https://github.com/G-Core/gcore-python/compare/v0.9.0...v0.10.0)

### ⚠ BREAKING CHANGES

* **security:** rename bgp_announces change() to toggle()
* **waap:** refactor WAAP models

### Features

* add example snippet to invite user and assign cloud role ([4baccef](https://github.com/G-Core/gcore-python/commit/4baccef0422ea20f5abbfc9808f447cc0df02e30))
* **api:** aggregated API specs update ([70ea19b](https://github.com/G-Core/gcore-python/commit/70ea19b8c9cd53810565c71dba1fc62e03a81090))
* **api:** aggregated API specs update ([163edcb](https://github.com/G-Core/gcore-python/commit/163edcb6b3ed69edf0e7c6711217433a73564e10))


### Bug Fixes

* **security:** rename bgp_announces change() to toggle() ([070f06a](https://github.com/G-Core/gcore-python/commit/070f06ad558afb0d608c4de45e4ce8e7d118dccd))


### Chores

* **internal:** fix ruff target version ([c91b1b3](https://github.com/G-Core/gcore-python/commit/c91b1b38e01a3a65b3b82e01bf6babd6a73ac233))


### Refactors

* **waap:** refactor WAAP models ([fb20add](https://github.com/G-Core/gcore-python/commit/fb20add86c0b2d8e122afe9216d5b84bcd59fb11))

## 0.9.0 (2025-07-31)

Full Changelog: [v0.8.0...v0.9.0](https://github.com/G-Core/gcore-python/compare/v0.8.0...v0.9.0)

### Features

* **api:** aggregated API specs update ([bf2d683](https://github.com/G-Core/gcore-python/commit/bf2d683bf679eb9412ebd278f9ca4eceb2f4ba6e))
* **api:** aggregated API specs update ([95d8011](https://github.com/G-Core/gcore-python/commit/95d8011132b86e8bf5311c14d43aea7a416d778c))
* **client:** support file upload requests ([980b86d](https://github.com/G-Core/gcore-python/commit/980b86dfcc7697fcc2e856bf030c971c54a509f1))
* **fastedge:** add binaries create method ([04bd754](https://github.com/G-Core/gcore-python/commit/04bd754a175b1d3e3bfcef2abdd1c96081c535df))
* **security:** add security api ([7e85df3](https://github.com/G-Core/gcore-python/commit/7e85df337055265317c988f67f6b0a4831dbdf73))

## 0.8.0 (2025-07-29)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/G-Core/gcore-python/compare/v0.7.0...v0.8.0)

### Features

* **api:** aggregated API specs update ([7296a44](https://github.com/G-Core/gcore-python/commit/7296a445ea8d692bcc212a91f1e6f2ea7c100789))
* **api:** aggregated API specs update ([bdd85b5](https://github.com/G-Core/gcore-python/commit/bdd85b5413ad87e01c6fca896c7160f6ee854491))


### Bug Fixes

* **iam:** remove obsolete pagination scheme ([85723b3](https://github.com/G-Core/gcore-python/commit/85723b333ed196f3501fdf84d7a7155bf0f700b7))
* **iam:** user model path ([e5429bb](https://github.com/G-Core/gcore-python/commit/e5429bb95df2710c7937e1125af25a268e8428e0))

## 0.7.0 (2025-07-25)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/G-Core/gcore-python/compare/v0.6.0...v0.7.0)

### Features

* **api:** aggregated API specs update ([56f5995](https://github.com/G-Core/gcore-python/commit/56f5995eafb29076d88fc586a2a05954399b6a30))
* **api:** aggregated API specs update ([7c593d2](https://github.com/G-Core/gcore-python/commit/7c593d2e5a95b1b67182535dc7510c602f5d2108))
* **api:** aggregated API specs update ([fdc5efd](https://github.com/G-Core/gcore-python/commit/fdc5efd0654c53fdfd29aba3a22072f001b0296e))
* **cloud:** add cost and usage reports ([bd8f648](https://github.com/G-Core/gcore-python/commit/bd8f648c6f97121eede374cdd4aea754317f718b))
* **streaming:** add streaming api ([025ee94](https://github.com/G-Core/gcore-python/commit/025ee94a20aed69abac1ffd608950f88dd6b4cda))


### Bug Fixes

* **parsing:** ignore empty metadata ([b64a2b6](https://github.com/G-Core/gcore-python/commit/b64a2b6bef89b3ec2075fa4f0ed3545a52cec0c9))
* **parsing:** parse extra field types ([fc9c2a6](https://github.com/G-Core/gcore-python/commit/fc9c2a6795202626e23f5303d0d2617b41ed9557))


### Chores

* **project:** add settings file for vscode ([e1a685b](https://github.com/G-Core/gcore-python/commit/e1a685b1719cb6d856fb088e56d7a384e7eca795))


### Refactors

* **cloud:** ignore deprecation warn in gpu baremetal polling methods ([6d8ae98](https://github.com/G-Core/gcore-python/commit/6d8ae9830f788b0b9fa49d9ef41ab9e06cd8485d))

## 0.6.0 (2025-07-18)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/G-Core/gcore-python/compare/v0.5.0...v0.6.0)

### Features

* **api:** aggregated API specs update ([ce31169](https://github.com/G-Core/gcore-python/commit/ce311695bbea628175adc51f9f1a2545eb213d01))
* clean up environment call outs ([2842d39](https://github.com/G-Core/gcore-python/commit/2842d3970f535d9095065ca681eaad809ea792e1))
* **cloud:** add audit logs ([2b0fe4c](https://github.com/G-Core/gcore-python/commit/2b0fe4cd8e7e125958c2784fb1a8f26209457e2d))
* **cloud:** add baremetal examples ([1193361](https://github.com/G-Core/gcore-python/commit/1193361f59f54de3ba454c4d23bb16c9ea87ac4b))
* **cloud:** add inference api_keys subresource ([4857d4e](https://github.com/G-Core/gcore-python/commit/4857d4eae79e51969c80e28309a4b452e4a8a597))

## 0.5.0 (2025-07-14)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/G-Core/gcore-python/compare/v0.4.0...v0.5.0)

### ⚠ BREAKING CHANGES

* **cloud:** refactor cloud inference models

### Features

* **api:** aggregated API specs update ([d1ae8cd](https://github.com/G-Core/gcore-python/commit/d1ae8cd01bc978e9afc8cefaae2799178a3c1e35))
* **api:** aggregated API specs update ([a182213](https://github.com/G-Core/gcore-python/commit/a182213096bdf7338261105c95c8b1e399d0f408))
* **api:** manual updates ([3ba0065](https://github.com/G-Core/gcore-python/commit/3ba0065f84e200ad4ae981e4189ae68a9cf3fff6))
* **api:** manual upload of aggregated API specs ([354a103](https://github.com/G-Core/gcore-python/commit/354a103447e5a3e9c69b11b871e9dec0e9ee7dc8))
* **cloud:** add inference examples ([2fe1536](https://github.com/G-Core/gcore-python/commit/2fe153665d086ee5c80ae99935b4d222065525a1))
* **cloud:** update secrets examples with pagination ([2909ae2](https://github.com/G-Core/gcore-python/commit/2909ae2e9d352fa07c70fdf64346db76d379f10e))
* **fastedge:** add api ([bec64b0](https://github.com/G-Core/gcore-python/commit/bec64b0db3ac113a875908ab5cb5041f4b1ed4aa))


### Bug Fixes

* **client:** don't send Content-Type header on GET requests ([1640b0b](https://github.com/G-Core/gcore-python/commit/1640b0b861aaf560c09b1cc651e3e1ffbb9b0095))
* **cloud:** update polling signatures after refactor ([1ee9ef9](https://github.com/G-Core/gcore-python/commit/1ee9ef98c604959f724c5c72317893089674debc))
* **parsing:** correctly handle nested discriminated unions ([3d16223](https://github.com/G-Core/gcore-python/commit/3d16223c06ee81a46657f37fb43621d095d4d9e5))


### Chores

* **client:** set default timeout to be 2 mins ([17159a0](https://github.com/G-Core/gcore-python/commit/17159a03ed71b64f03fde8cbf85d92ec0db29b31))
* **internal:** bump pinned h11 dep ([d0da186](https://github.com/G-Core/gcore-python/commit/d0da186d6203a09c7aec841287c02455b9c3b6df))
* **package:** mark python 3.13 as supported ([1440f43](https://github.com/G-Core/gcore-python/commit/1440f43464c3f5cbfb68df908792ab503656c63b))
* **readme:** fix version rendering on pypi ([8a8281c](https://github.com/G-Core/gcore-python/commit/8a8281c749792394c73b4d38f89d43fd0b6b1573))


### Refactors

* **cloud:** refactor cloud inference models ([3886c6d](https://github.com/G-Core/gcore-python/commit/3886c6d8244c58424cf09eb4514441e7e0afa7a1))

## 0.4.0 (2025-07-04)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/G-Core/gcore-python/compare/v0.3.0...v0.4.0)

### ⚠ BREAKING CHANGES

* **cloud:** remove list suitable from bm flavors
* remove list suitable and list for resize from instance flavors

### Features

* **api:** aggregated API specs update ([7395880](https://github.com/G-Core/gcore-python/commit/7395880c1291632db977714b43de1ab7061c23ed))
* **api:** aggregated API specs update ([dd87a63](https://github.com/G-Core/gcore-python/commit/dd87a630497b9dd478330bb190920da41fc6b6da))
* **api:** aggregated API specs update ([d4b4f22](https://github.com/G-Core/gcore-python/commit/d4b4f221489c1047b8e92752a1da014f1af59af9))
* **api:** aggregated API specs update ([a942886](https://github.com/G-Core/gcore-python/commit/a9428867b76afd4e3e0adb5892c007c3b8922fca))
* **api:** aggregated API specs update ([8b5d094](https://github.com/G-Core/gcore-python/commit/8b5d094f732e0c5f236f8bfc32fe069a6fd412ed))
* **api:** aggregated API specs update ([c86820e](https://github.com/G-Core/gcore-python/commit/c86820e1ca68185902d8e5e3cb911fca6d4dc10b))
* **api:** aggregated API specs update ([26b81bd](https://github.com/G-Core/gcore-python/commit/26b81bdeb1d84c2bc72a34e046db8fb1b1e5fcd1))
* **api:** update via SDK Studio ([96a27dd](https://github.com/G-Core/gcore-python/commit/96a27dd845f5fe9128b111171feb6c065f0c2916))
* **api:** update via SDK Studio ([1da4aa3](https://github.com/G-Core/gcore-python/commit/1da4aa370b1e633b002e1be99b7c5f3cf785ebc7))
* **client:** add support for aiohttp ([a983aee](https://github.com/G-Core/gcore-python/commit/a983aee8dd4ddf7d111f4798c89cfd3f341568d4))
* **cloud:** add floating IPs examples ([9010134](https://github.com/G-Core/gcore-python/commit/90101344d7fdf1ba0c8f55bc290ffe7839cb6af0))
* **cloud:** add instances examples ([a38f100](https://github.com/G-Core/gcore-python/commit/a38f10024534ab8c65ff72e96f49100bfaeb17a1))
* **cloud:** add load balancers examples ([#50](https://github.com/G-Core/gcore-python/issues/50)) ([c73f5d1](https://github.com/G-Core/gcore-python/commit/c73f5d1b84dbd2c96c9383100a93c89c8cf5e498))
* **cloud:** add networks examples ([5f32d6f](https://github.com/G-Core/gcore-python/commit/5f32d6f75aec5a7ff33729c65984f8b171910f8b))
* **cloud:** add reserved fixed ips examples ([a42b974](https://github.com/G-Core/gcore-python/commit/a42b974dde0d61edd9efa8f5929c0cbd967eebf8))
* **cloud:** add routers examples ([aba1f63](https://github.com/G-Core/gcore-python/commit/aba1f6343d40a6c6181929923b80a31d0bae332c))
* **cloud:** add security groups examples ([5c4f2a5](https://github.com/G-Core/gcore-python/commit/5c4f2a57603a5940c13220770e363c1e597ec48d))
* **cloud:** add volumes examples ([57ddcba](https://github.com/G-Core/gcore-python/commit/57ddcba83e1664b765c1c16e9ee314f6af74c38b))
* **iam:** add IAM ([1507ac3](https://github.com/G-Core/gcore-python/commit/1507ac37f5d588a999880cf5f51c94293f65b039))
* **images:** add instance images examples ([ecc8d91](https://github.com/G-Core/gcore-python/commit/ecc8d91c94df8c09ab4aeb5f89c966f03924caed))


### Bug Fixes

* **ci:** correct conditional ([b8d8b92](https://github.com/G-Core/gcore-python/commit/b8d8b9275a3c0d0864cfbd0d396a68cfd07c0b7b))
* **ci:** release-doctor — report correct token name ([0bf3b18](https://github.com/G-Core/gcore-python/commit/0bf3b1850e85aa8d9b635dcee9aeaf416f35df6c))
* **cloud:** linting on load balancer examples ([3534bea](https://github.com/G-Core/gcore-python/commit/3534beaed71a9fb5fe61df6a8b9aa76b9c3913c8))
* **cloud:** update tags type for gpu baremetal clusters and images, instances, load balancers ([6634a74](https://github.com/G-Core/gcore-python/commit/6634a74d3106f25476bd6bce98d12249f07dd8a6))
* **tests:** fix: tests which call HTTP endpoints directly with the example parameters ([3d88ae5](https://github.com/G-Core/gcore-python/commit/3d88ae5a7df41b7e9e88d0520a9586c1240da54c))
* **waap:** remove duplicate method for acct overview ([85766ca](https://github.com/G-Core/gcore-python/commit/85766ca7a1a3848cf6e252a55d7cc7ef384a4f94))


### Chores

* **ci:** change upload type ([960a44b](https://github.com/G-Core/gcore-python/commit/960a44ba2f255ad2bf8f571de381b06e5f1fffbd))
* **ci:** only run for pushes and fork pull requests ([7df32ec](https://github.com/G-Core/gcore-python/commit/7df32eca9f58a777487a2d00e2bfd41ccdd6a518))
* **cloud:** reorder ([0441c52](https://github.com/G-Core/gcore-python/commit/0441c52c6407e2ae427b70fdd22881bde8ea8191))
* **cloud:** reorder example functions ([7c3a568](https://github.com/G-Core/gcore-python/commit/7c3a5683c8482ca7398e6863c77fdae350b3e711))
* **cloud:** skip load balancer test statuses ([8dd7ccb](https://github.com/G-Core/gcore-python/commit/8dd7ccb677a41455d0c3ee6407e21271485669aa))
* **cloud:** streamline envs in examples ([e26746f](https://github.com/G-Core/gcore-python/commit/e26746fd50a2fee2157c88244b737352f07dd55c))
* **cloud:** unify examples format ([32446c4](https://github.com/G-Core/gcore-python/commit/32446c4e9bb385f68b0a24637f731ff93ee0eb5a))
* format ([fbe3508](https://github.com/G-Core/gcore-python/commit/fbe3508482950455f4ccd02b6941bb0273b2fdf6))
* **internal:** updates ([2377589](https://github.com/G-Core/gcore-python/commit/237758929ed119a1780c5a0cf9d60c72f6c70b8a))
* **internal:** updates ([054c374](https://github.com/G-Core/gcore-python/commit/054c374d0b02ec85d6702ecfded1362e827cf655))
* **readme:** update badges ([6ba343d](https://github.com/G-Core/gcore-python/commit/6ba343d802d353c4df42e4e7f6cc4f693fe9734a))
* **tests:** skip some failing tests on the latest python versions ([4b45142](https://github.com/G-Core/gcore-python/commit/4b45142d7fe138a5f0a030bdd27f9de26df533b9))
* **tests:** skip some failing tests on the latest python versions ([272ce51](https://github.com/G-Core/gcore-python/commit/272ce51ed26d568e181dee26205448d35184e015))


### Documentation

* **client:** fix httpx.Timeout documentation reference ([1f4c28f](https://github.com/G-Core/gcore-python/commit/1f4c28f252df42a703a60ed2901391167296ecc7))


### Refactors

* **cloud:** remove list suitable from bm flavors ([2626938](https://github.com/G-Core/gcore-python/commit/262693876592601fa5a07dd088033037c7eae9b6))
* remove list suitable and list for resize from instance flavors ([24b00fe](https://github.com/G-Core/gcore-python/commit/24b00fec390f141457c98334b302dab5a8b1d480))

## 0.3.0 (2025-06-17)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/G-Core/gcore-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** aggregated API specs update ([cc09f05](https://github.com/G-Core/gcore-python/commit/cc09f0514d7fdaf4be53bc0a9c6c83bc51d15c8e))
* **api:** aggregated API specs update ([bb1cd39](https://github.com/G-Core/gcore-python/commit/bb1cd39ca5b0fe5fdcaa27cc7c4010652ec63bd7))
* **api:** manual upload of aggregated API specs ([5cc5748](https://github.com/G-Core/gcore-python/commit/5cc5748cd293cf9fc82b869300942ebc185acba4))
* **api:** manual upload of aggregated API specs ([bcb9528](https://github.com/G-Core/gcore-python/commit/bcb9528ac00d87793c1482fbae29ccad530d98d1))
* **client:** add follow_redirects request option ([5e174cd](https://github.com/G-Core/gcore-python/commit/5e174cd6d8b9ff289e41470876e6fa606b577d9d))
* **cloud:** add file shares examples ([861ee72](https://github.com/G-Core/gcore-python/commit/861ee72d59ab0a6b5ce30fb3d3d1c1e8827c3dc8))
* **cloud:** add quotas examples ([353fe46](https://github.com/G-Core/gcore-python/commit/353fe4673252ae21c30d35217b2a8431ff23f1dc))
* **waap:** add domain analytics, api_paths, insights and insight_silences; and ip_info ([5bf944d](https://github.com/G-Core/gcore-python/commit/5bf944dcb78eb969dc6d0cca2fcec60cf8ad29d4))
* **waap:** add domain custom, firewall and advanced rules; custom page sets, advanced rules and tags ([c87c991](https://github.com/G-Core/gcore-python/commit/c87c99120593ce8fbc4ad6c17cdafee26980261b))


### Bug Fixes

* **client:** correctly parse binary response | stream ([4266555](https://github.com/G-Core/gcore-python/commit/42665557859017c7978aa9bae5e0e9f4f86369f9))


### Chores

* **change-detection:** filter newly generated files ([6afae28](https://github.com/G-Core/gcore-python/commit/6afae286af9d73e8c709761bcdb204aecf0b1fd8))
* **ci:** enable for pull requests ([dc1b8d6](https://github.com/G-Core/gcore-python/commit/dc1b8d60856032734dbd4fc398de8dacdc0d1005))
* **cloud:** fix lint ([47beba7](https://github.com/G-Core/gcore-python/commit/47beba75971064ab94d8741f4d1c676850700021))
* **docs:** remove reference to rye shell ([46c6ddf](https://github.com/G-Core/gcore-python/commit/46c6ddf669a7e9ee58e6629455c3d83029bee626))
* **internal:** update conftest.py ([dc9134b](https://github.com/G-Core/gcore-python/commit/dc9134b3ea02980aea2cdcde0775c0ad19101ef5))
* **tests:** add tests for httpx client instantiation & proxies ([d5913dd](https://github.com/G-Core/gcore-python/commit/d5913dde70db8a76542e48af5bcc62a14c2c52a4))
* **tests:** run tests in parallel ([b73e6f9](https://github.com/G-Core/gcore-python/commit/b73e6f906e21e58993645e7060dead8edaf2b6cd))

## 0.2.0 (2025-05-30)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/G-Core/gcore-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** aggregated API specs update ([8396748](https://github.com/G-Core/gcore-python/commit/83967485975f181b79166c5ab6ae6533a77ff414))
* **api:** aggregated API specs update ([f3e527b](https://github.com/G-Core/gcore-python/commit/f3e527bba66b98a5e3d58b604bff1a7d772fd504))
* **api:** aggregated API specs update ([8f63298](https://github.com/G-Core/gcore-python/commit/8f63298756d8de3df98788b640c33dbf9cbd4c0c))
* **api:** aggregated API specs update ([ec4a6bd](https://github.com/G-Core/gcore-python/commit/ec4a6bdd8cce948d0b3bb279b42a020d20b3fceb))
* **api:** aggregated API specs update ([e270005](https://github.com/G-Core/gcore-python/commit/e27000533d742531397c34435a60a9f816c5d559))


### Bug Fixes

* **ci:** do not always skip breaking change detection ([018e357](https://github.com/G-Core/gcore-python/commit/018e357a11cfd863973fbd29f1f1867d3851b342))
* **inference:** make poll method consistent with latest api changes ([0ea64f9](https://github.com/G-Core/gcore-python/commit/0ea64f92b47e914d980ba0fd2208dd44e1119903))
* **instances,baremetal,loadbalancers,inference,gpu_cloud:** don't fail if nr tasks gt 1 ([760226e](https://github.com/G-Core/gcore-python/commit/760226eddee2cf1c66ab5dfcca86ea7130de382b))


### Chores

* **api:** mark some methods as deprecated ([726ef80](https://github.com/G-Core/gcore-python/commit/726ef8008d1bc67aea4884dcc48718fd94d738c3))
* **docs:** grammar improvements ([cd7a162](https://github.com/G-Core/gcore-python/commit/cd7a16205cad089539ab3d7f6871d564691e3f40))
* **internal:** codegen related update ([fb451ad](https://github.com/G-Core/gcore-python/commit/fb451ada041dce34bd134274969b29c474c6d094))
* **internal:** version bump ([69cc570](https://github.com/G-Core/gcore-python/commit/69cc570d3cd366763c4506990ae886abe3a3d734))


### Refactors

* **loadbalancers:** change oas schema names ([422d5c2](https://github.com/G-Core/gcore-python/commit/422d5c2c03155b9d136f15ddd087e175a4af00aa))
* **loadbalancers:** use correct schema for loadbalancer pool ([6a285dd](https://github.com/G-Core/gcore-python/commit/6a285dd1683f30f8aee24ddd20ec5b1684ace304))

## 0.1.0 (2025-05-20)

Full Changelog: [v0.1.0-alpha.2...v0.1.0](https://github.com/G-Core/gcore-python/compare/v0.1.0-alpha.2...v0.1.0)

### Features

* **api:** aggregated API specs update ([8173c1e](https://github.com/G-Core/gcore-python/commit/8173c1ea495b7b27876fa8b777070e3a28407f0d))
* **api:** aggregated API specs update ([22e6e90](https://github.com/G-Core/gcore-python/commit/22e6e90558ebaa7e4d5b50000ef0a8706037ab3f))
* **baremetal:** add polling methods ([#38](https://github.com/G-Core/gcore-python/issues/38)) ([0423186](https://github.com/G-Core/gcore-python/commit/0423186035ceb14e772adf585ec3664755c4902f))
* **gpu_cloud:** add polling methods ([#40](https://github.com/G-Core/gcore-python/issues/40)) ([b209a4d](https://github.com/G-Core/gcore-python/commit/b209a4d6bf565559503462a4d28a8d6ed45c18b8))
* **instances:** add polling methods ([#36](https://github.com/G-Core/gcore-python/issues/36)) ([64ec95d](https://github.com/G-Core/gcore-python/commit/64ec95d62a0ee4ca69ad7df78ef875eb3dd81ecf))
* **load_balancers, inference, gpu_cloud, instances:** add polling methods ([#44](https://github.com/G-Core/gcore-python/issues/44)) ([ba106ad](https://github.com/G-Core/gcore-python/commit/ba106adf1b54b9109574da93e9617e777f6890cc))
* **loadbalancers,inference:** add polling methods ([#39](https://github.com/G-Core/gcore-python/issues/39)) ([55bbc2f](https://github.com/G-Core/gcore-python/commit/55bbc2f56049f10b6360e53fcaed25ec343ce6fa))


### Bug Fixes

* **package:** support direct resource imports ([74d6f0d](https://github.com/G-Core/gcore-python/commit/74d6f0d5763de81c2017943d3a39633f32ee20c4))


### Chores

* **ci:** fix installation instructions ([8dc3dcf](https://github.com/G-Core/gcore-python/commit/8dc3dcf9beda9745d64f906a2d386d930e04bbe2))
* **ci:** upload sdks to package manager ([370efcf](https://github.com/G-Core/gcore-python/commit/370efcfd392562b1fbc28ef9b87dc9c65ba8363c))
* **internal:** avoid errors for isinstance checks on proxies ([6ccc750](https://github.com/G-Core/gcore-python/commit/6ccc7507b9882b0c9eb5b0ac2d5ec57035d6f959))
* **internal:** codegen related update ([67c1836](https://github.com/G-Core/gcore-python/commit/67c183613a3c3ac4ecc6a7c2a17ca09b80838a8e))


### Documentation

* remove or fix invalid readme examples ([457d409](https://github.com/G-Core/gcore-python/commit/457d4091f05eee8bd4862c262cce7bef5c071e7e))

## 0.1.0-alpha.2 (2025-05-06)

Full Changelog: [v0.1.0-alpha.1...v0.1.0-alpha.2](https://github.com/G-Core/gcore-python/compare/v0.1.0-alpha.1...v0.1.0-alpha.2)

### Documentation

* enable pypi publishing ([6fd398f](https://github.com/G-Core/gcore-python/commit/6fd398f307673c521d41acef7ee6833977d8b108))

## 0.1.0-alpha.1 (2025-05-06)

Full Changelog: [v0.0.1-alpha.0...v0.1.0-alpha.1](https://github.com/G-Core/gcore-python/compare/v0.0.1-alpha.0...v0.1.0-alpha.1)

### Features

* **api:** add nested_params readme example ([6ee8d52](https://github.com/G-Core/gcore-python/commit/6ee8d52fb55f54a07380696b27e5db42298dd39f))
* **api:** aggregated API specs update ([2813f87](https://github.com/G-Core/gcore-python/commit/2813f879dd9276506139471c7c12d8160f159924))
* **api:** aggregated API specs update ([2469a5f](https://github.com/G-Core/gcore-python/commit/2469a5f97c5e07cd9b74a3af2688a9fbb963b86a))
* **api:** aggregated API specs update ([84eac69](https://github.com/G-Core/gcore-python/commit/84eac69a9ba19fece92100b53864252d183d20df))
* **api:** aggregated API specs update ([d3569ad](https://github.com/G-Core/gcore-python/commit/d3569add7e2dff9f3580bc4557ae65095bedf39b))
* **api:** aggregated API specs update ([f3cf87c](https://github.com/G-Core/gcore-python/commit/f3cf87cb01ae9ff0f92ea85ceab2133a69017827))
* **api:** aggregated API specs update ([1e9b9c8](https://github.com/G-Core/gcore-python/commit/1e9b9c8a2504eceefdaf666be1bec98874e322e7))
* **api:** aggregated API specs update ([0006431](https://github.com/G-Core/gcore-python/commit/00064311320c0fe23330cebe0879099d7819b4eb))
* **api:** aggregated API specs update ([a342c37](https://github.com/G-Core/gcore-python/commit/a342c37d2882dc47109c6b8aead1e72b3a1a6188))
* **api:** aggregated API specs update ([f09d378](https://github.com/G-Core/gcore-python/commit/f09d378224a50075ae24e2a70212a20a3631ee11))
* **api:** aggregated API specs update ([0357ef7](https://github.com/G-Core/gcore-python/commit/0357ef75d82cdf567492fe02ca688aecdb9836d2))
* **api:** aggregated API specs update ([5e1e67a](https://github.com/G-Core/gcore-python/commit/5e1e67a95ac08931d14a1a29a85262eb6df1c4ee))
* **api:** aggregated API specs update ([7fc187b](https://github.com/G-Core/gcore-python/commit/7fc187ba11c0ef604da22f70ade6aacd4c5ce090))
* **api:** aggregated API specs update ([1963fee](https://github.com/G-Core/gcore-python/commit/1963fee15dd6877e69584758595dbd160ae696f8))
* **api:** aggregated API specs update ([4f397d1](https://github.com/G-Core/gcore-python/commit/4f397d124fc6da07bd03e7c8b539e6db284d39b4))
* **api:** Config update for algis-dumbris/cloud-quotas ([38d5cd6](https://github.com/G-Core/gcore-python/commit/38d5cd68ec8dee8d00a7327e5231520aa00403d8))
* **api:** manual updates ([4815004](https://github.com/G-Core/gcore-python/commit/481500416f100dee03be8e7d884ca232eb6fa5fc))
* **api:** manual updates ([9828118](https://github.com/G-Core/gcore-python/commit/9828118404382abefbaeba2553d0e799781d425d))
* **api:** manual updates ([4d67833](https://github.com/G-Core/gcore-python/commit/4d67833a7f4b88bec825841bf89c88a461a8f1e8))
* **api:** manual upload of aggregated API specs ([19202b1](https://github.com/G-Core/gcore-python/commit/19202b1ceccbc317d3b6d15c4403370141340037))
* **api:** remove duplicates ([3ed9f67](https://github.com/G-Core/gcore-python/commit/3ed9f6797b48ccc326cb536ddb2487848e22bcbd))
* **api:** remove quotas ([ff784b5](https://github.com/G-Core/gcore-python/commit/ff784b5ef5dad16dceee3ab70dd8a59c2e379ccd))
* **api:** rename regions.retrieve() to rregions.get() ([5823e81](https://github.com/G-Core/gcore-python/commit/5823e8121bd2ce949f16e1ec1c24fb71e6766d1f))
* **api:** simplify env vars ([161e7c4](https://github.com/G-Core/gcore-python/commit/161e7c48c4d7923f6c263558c239a0d6d99be980))
* **api:** trigger codegen ([c66f1ab](https://github.com/G-Core/gcore-python/commit/c66f1ab7645b8deee2d2fc10fbcfc76254855549))
* changes for loadbalancers-renaming ([4785701](https://github.com/G-Core/gcore-python/commit/47857019e5ca8b21efd41157175c7ee349ecf3ea))
* **oas:** update to v14.150.0 ([c0fdf81](https://github.com/G-Core/gcore-python/commit/c0fdf81d61fe9054d0dd0524560c6019e27a70f7))
* **opts:** polling interval in secs ([9abb721](https://github.com/G-Core/gcore-python/commit/9abb72182049081ba16fbd5f2b4fd371ccb61ec4))
* **projects:** add cloud projects ([#1](https://github.com/G-Core/gcore-python/issues/1)) ([abc2b1c](https://github.com/G-Core/gcore-python/commit/abc2b1c600ae63694604a8ed9ca3564577618e39))
* **tasks:** make polling interval in secs ([#34](https://github.com/G-Core/gcore-python/issues/34)) ([b29fe33](https://github.com/G-Core/gcore-python/commit/b29fe3359588dfb7f3226cb6c37709aa9aa5db3a))


### Bug Fixes

* **api:** update regions.retrieve() to regions.get() in async and sync examples ([#33](https://github.com/G-Core/gcore-python/issues/33)) ([8f14234](https://github.com/G-Core/gcore-python/commit/8f142340a731a19666917e5d7e30cf0e2e0c76b9))
* **client:** correct path param return type ([3436e9d](https://github.com/G-Core/gcore-python/commit/3436e9d5fc453ee21b68a32781e51846fece99a0))
* **cloud:** move and/or rename models ([1022e65](https://github.com/G-Core/gcore-python/commit/1022e65d85e9398d993edfc86f1a5af0a483ea07))
* **cloud:** remove workaround ([70c3bd0](https://github.com/G-Core/gcore-python/commit/70c3bd0c6b77083df0a3e0f1fa897caf585f80a3))
* **examples:** client opts rename ([#30](https://github.com/G-Core/gcore-python/issues/30)) ([7d62a64](https://github.com/G-Core/gcore-python/commit/7d62a6403b357c3298bf8b37c2167e05b38671f0))
* **examples:** update examples after model rename ([#21](https://github.com/G-Core/gcore-python/issues/21)) ([2000922](https://github.com/G-Core/gcore-python/commit/2000922b4e6c99e6bdbffcaf8e102256bfcc1413))
* **floating_ips:** workaround ([4517d6e](https://github.com/G-Core/gcore-python/commit/4517d6e7c0564dc20d40ae1c5ba37514d360645f))
* **ipranges:** add examples ([#14](https://github.com/G-Core/gcore-python/issues/14)) ([a77b150](https://github.com/G-Core/gcore-python/commit/a77b15074507bdf8d39cfbe21b71c2b1533be49e))
* **perf:** optimize some hot paths ([dfdb2cb](https://github.com/G-Core/gcore-python/commit/dfdb2cbdaa75f45a760680d65a5540c1aae2ccc5))
* **perf:** skip traversing types for NotGiven values ([c8beef9](https://github.com/G-Core/gcore-python/commit/c8beef965db0c8eac4f68d32fe5dccf356227140))
* **pydantic v1:** more robust ModelField.annotation check ([d2feb9f](https://github.com/G-Core/gcore-python/commit/d2feb9f7dff5092550811bbe8fc8252b85da68cd))
* **ssh_keys:** add examples ([#13](https://github.com/G-Core/gcore-python/issues/13)) ([7c19fc6](https://github.com/G-Core/gcore-python/commit/7c19fc6b1e7cf3eec829e622f01e473d10041848))
* **tests:** unset region env var during tests ([#10](https://github.com/G-Core/gcore-python/issues/10)) ([194ef5c](https://github.com/G-Core/gcore-python/commit/194ef5cd7af25a2278460e747502b2d637d896df))


### Chores

* broadly detect json family of content-type headers ([f78af6d](https://github.com/G-Core/gcore-python/commit/f78af6db49a301121dd1bb28cdb88119cc169081))
* **ci:** add timeout thresholds for CI jobs ([aabedbd](https://github.com/G-Core/gcore-python/commit/aabedbd9886425f15eca1c5a83e23e234abb97ed))
* **ci:** fix formatting for debug mode ([376ed6b](https://github.com/G-Core/gcore-python/commit/376ed6bb4302a92efc5290b93bfc2a223c1299ac))
* **ci:** only use depot for staging repos ([12782f0](https://github.com/G-Core/gcore-python/commit/12782f034862557585dcaed07ecd073da6b91996))
* **client:** minor internal fixes ([c605c1c](https://github.com/G-Core/gcore-python/commit/c605c1c816d74d4a01ec8dc0689ea7f226892e0e))
* configure new SDK language ([5559374](https://github.com/G-Core/gcore-python/commit/5559374feffdb8eca7f20f0bcc4af83ad1bf49eb))
* **internal:** base client updates ([c3782cc](https://github.com/G-Core/gcore-python/commit/c3782cc4660beaaa8eed7560118e2bbe60ab6506))
* **internal:** bump pyright version ([a59f39b](https://github.com/G-Core/gcore-python/commit/a59f39b5393e9a0af05e9c520b3a40e06b3708c6))
* **internal:** codegen related update ([1e5e4a4](https://github.com/G-Core/gcore-python/commit/1e5e4a43c02d64079c771c05171e159a5a70a9e7))
* **internal:** expand CI branch coverage ([832a5a0](https://github.com/G-Core/gcore-python/commit/832a5a0ebf1bd13aae23ce31212d374199779661))
* **internal:** fix list file params ([f9dbece](https://github.com/G-Core/gcore-python/commit/f9dbecefee3db3d903f1eb43a8f96dac4571f013))
* **internal:** import reformatting ([a160ca4](https://github.com/G-Core/gcore-python/commit/a160ca4084342039946258c36f163ede88afe4ec))
* **internal:** minor formatting changes ([c7958d2](https://github.com/G-Core/gcore-python/commit/c7958d278347c0294fdd08d5315597d9885d9d89))
* **internal:** reduce CI branch coverage ([e4e582c](https://github.com/G-Core/gcore-python/commit/e4e582c604e3bea37bf53f530c162b978e427a29))
* **internal:** refactor retries to not use recursion ([b1b2600](https://github.com/G-Core/gcore-python/commit/b1b26009317ab59938990bb3604677007f58f0fe))
* **internal:** slight transform perf improvement ([c826d0d](https://github.com/G-Core/gcore-python/commit/c826d0d042c55b034a488eb76fb23ae42a927349))
* **internal:** update models test ([e3550d8](https://github.com/G-Core/gcore-python/commit/e3550d80dc73520576ce16cc0c7259b7a4d7ffac))
* **internal:** update pyright settings ([3c14296](https://github.com/G-Core/gcore-python/commit/3c142960c5b7b0bb81919e8337c8bb6428676e1d))
* **tests:** improve enum examples ([a10cbfa](https://github.com/G-Core/gcore-python/commit/a10cbfa870a42cae4f75beae90f185ce068c14fa))
* update SDK settings ([81d0161](https://github.com/G-Core/gcore-python/commit/81d0161b6651e00fe9be43faef815c31a17361b1))
* update SDK settings ([0f4877e](https://github.com/G-Core/gcore-python/commit/0f4877e87435d053c2038dd11590caad6ad90700))


### Documentation

* update links ([edb2a76](https://github.com/G-Core/gcore-python/commit/edb2a766f451b9dfa798e620d01bb7ba5299e33d))


### Refactors

* **tasks:** rename retrieve methods to get to fix polling ([#16](https://github.com/G-Core/gcore-python/issues/16)) ([61fc9a9](https://github.com/G-Core/gcore-python/commit/61fc9a9e0ab9f998c9fd303ff6cea3ff6e03a345))
