"""Render Entities to markdown."""
