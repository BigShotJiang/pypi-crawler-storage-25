#!/usr/bin/env python3
"""
Tests for v3.0.88:
- Finding description renders markdown (was rendering literal **bold**)
- Generic per-severity remediation boilerplate skipped when description
  is substantive (>=300 chars)
- Detection Method block included in tls_check + dmarc_check finding
  descriptions (shows what souleyez ran during the scan, distinct from
  How to manually verify)

Background: report user reported that descriptions showed raw markdown
syntax (literal `**`, raw fenced code blocks), and the report appended
a generic per-severity remediation list ("Address within 30 days as
part of regular patching cycle...") on top of finding-specific
remediation guidance, making the report look templated.
"""

from souleyez.handlers.dmarc_check_handler import DmarcCheckHandler
from souleyez.handlers.tls_check_handler import TlsCheckHandler
from souleyez.reporting.formatters import HTMLFormatter


# ---------------------------------------------------------------------------
# Generic remediation skipped when description is substantive
# ---------------------------------------------------------------------------


def test_generic_remediation_skipped_for_long_description():
    """
    A finding with a 300+ char description (specific remediation
    embedded inline) should NOT get the generic per-severity
    boilerplate appended.
    """
    fmt = HTMLFormatter()
    finding = {
        "title": "SPF record missing on example.com",
        "tool": "dmarc_check",
        "description": (
            "No SPF record found. " * 30  # ~600 chars
        ),
    }
    out = fmt._generate_default_remediation(finding, severity="medium")
    assert out == "", (
        "Substantive descriptions should not trigger generic boilerplate"
    )


def test_generic_remediation_kept_for_short_description():
    """
    A finding with a sparse description still benefits from the
    generic safety-net guidance.
    """
    fmt = HTMLFormatter()
    finding = {
        "title": "Some short title",
        "tool": "unknown",
        "description": "Brief.",  # <300 chars
    }
    out = fmt._generate_default_remediation(finding, severity="medium")
    # Generic medium boilerplate still produced
    assert "Address within 30 days" in out


def test_specific_classifier_remediation_takes_priority():
    """
    Even with a long description, classify_finding_remediation matches
    take priority — the nikto classifier produces highly-specific
    remediation that's better than what's typically embedded in
    descriptions.
    """
    fmt = HTMLFormatter()
    finding = {
        "title": "Missing X-Content-Type-Options header",
        "tool": "nikto",
        "description": "x" * 500,  # long description
    }
    out = fmt._generate_default_remediation(finding, severity="medium")
    # Classifier returned something specific (not the empty bypass
    # and not the generic). Just assert it's substantive.
    assert len(out) > 0
    assert "Address within 30 days" not in out


# ---------------------------------------------------------------------------
# Detection Method blocks in handler descriptions
# ---------------------------------------------------------------------------


class _RecordingFM:
    def __init__(self):
        self.added = []

    def add_finding(self, **kwargs):
        self.added.append(kwargs)


def test_tls_hsts_finding_has_detection_method():
    handler = TlsCheckHandler()
    fm = _RecordingFM()
    parsed = {"hostname": "x.example.com", "hsts": {"present": False}}
    handler._check_hsts(99, 1, "x.example.com", parsed, fm)
    desc = fm.added[0]["description"]
    assert "Detection Method (during scan)" in desc
    assert "HTTP HEAD `https://x.example.com/`" in desc
    assert "Strict-Transport-Security" in desc
    # Both detection AND verify still present
    assert "How to manually verify" in desc


def test_dmarc_spf_missing_has_detection_method():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {"apex": "freshpaint.io", "spf": {"present": False}}
    handler._check_spf(99, 1, "freshpaint.io", parsed, fm)
    desc = fm.added[0]["description"]
    assert "Detection Method (during scan)" in desc
    assert "DNS TXT query for `freshpaint.io`" in desc
    assert "v=spf1" in desc
    assert "How to manually verify" in desc


def test_dmarc_record_missing_has_detection_method():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {"apex": "freshpaint.io", "dmarc": {"present": False}}
    handler._check_dmarc(99, 1, "freshpaint.io", parsed, fm)
    desc = fm.added[0]["description"]
    assert "Detection Method (during scan)" in desc
    assert "_dmarc.freshpaint.io" in desc
    assert "v=DMARC1" in desc


def test_dmarc_dnssec_missing_has_detection_method():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "freshpaint.io",
        "dnssec": {"dnskey_present": False, "ad_flag": False},
    }
    handler._check_dnssec(99, 1, "freshpaint.io", parsed, fm)
    desc = fm.added[0]["description"]
    assert "Detection Method (during scan)" in desc
    assert "DNS DNSKEY query for `freshpaint.io`" in desc
    assert "DNSSEC is not enabled" in desc


def test_detection_method_distinct_from_verify():
    """
    Both blocks should be present and distinct — Detection Method
    describes what souleyez ran; How to manually verify gives the
    operator a command to reproduce. Different framings, both useful.
    """
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {"apex": "x.com", "spf": {"present": False}}
    handler._check_spf(99, 1, "x.com", parsed, fm)
    desc = fm.added[0]["description"]
    detection_idx = desc.index("Detection Method")
    verify_idx = desc.index("How to manually verify")
    assert detection_idx < verify_idx
    # Detection before verify (chronological order in the finding)


# ---------------------------------------------------------------------------
# Description description-length triggers the substantive-skip
# ---------------------------------------------------------------------------


def test_tls_handler_description_is_substantive():
    """
    Sanity: tls_check HSTS description is now long enough (Detection
    Method + Manual Verify + remediation guidance) that the generic
    overlay skip kicks in.
    """
    handler = TlsCheckHandler()
    fm = _RecordingFM()
    parsed = {"hostname": "x.example.com", "hsts": {"present": False}}
    handler._check_hsts(99, 1, "x.example.com", parsed, fm)
    desc = fm.added[0]["description"]
    assert len(desc) >= 300, (
        f"Expected substantive description (>=300 chars), got {len(desc)}"
    )


def test_dmarc_handler_description_is_substantive():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {"apex": "x.com", "spf": {"present": False}}
    handler._check_spf(99, 1, "x.com", parsed, fm)
    desc = fm.added[0]["description"]
    assert len(desc) >= 300


# ---------------------------------------------------------------------------
# End-to-end: handler + formatter render correctly
# ---------------------------------------------------------------------------


def test_substantive_handler_finding_skips_generic_remediation():
    """
    Round-trip: handler creates a finding with a substantive
    description (Detection Method + Manual Verify + remediation
    guidance), and _generate_default_remediation correctly returns
    empty so no generic boilerplate appears in the report.
    """
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {"apex": "x.com", "spf": {"present": False}}
    handler._check_spf(99, 1, "x.com", parsed, fm)
    finding = fm.added[0]

    fmt = HTMLFormatter()
    out = fmt._generate_default_remediation(finding, severity="medium")
    assert out == ""
