#!/usr/bin/env python3
"""
Tests for v3.0.87:
- Audit-evidence OSINT appendix (renders passive-recon data)
- Information-disclosure finding for CSP-exposed S3 bucket names

The appendix is internal-only (audit-evidence report mode) — proves
discovery methodology and surfaces what's externally visible. The
finding is auto-created when http_fingerprint discovers S3 buckets
in CSP, severity LOW (the buckets themselves are tested separately
via s3_check; this finding is about the name-disclosure itself).
"""

from souleyez.reporting.formatters import HTMLFormatter


# ---------------------------------------------------------------------------
# OSINT appendix rendering
# ---------------------------------------------------------------------------


def _osint_records_for_engagement_11():
    """Realistic OSINT record set matching what http_fingerprint
    produces from CSP parsing on the Freshpaint engagement."""
    return [
        {"data_type": "csp_domain", "value": "*.freshpaint-staging.com",
         "source": "http_fingerprint", "target": "app.freshpaint-staging.com"},
        {"data_type": "csp_domain", "value": "apis.google.com",
         "source": "http_fingerprint", "target": "app.freshpaint-staging.com"},
        {"data_type": "csp_cdn", "value": "d1xv9akss4wau0.cloudfront.net",
         "source": "http_fingerprint", "target": "app.freshpaint-staging.com"},
        {"data_type": "csp_s3_bucket",
         "value": "freshpaint-baa-uploads.s3.us-west-2.amazonaws.com",
         "source": "http_fingerprint", "target": "app.freshpaint-staging.com"},
        {"data_type": "csp_s3_bucket",
         "value": "freshpaint-audience-lists.s3.us-west-2.amazonaws.com",
         "source": "http_fingerprint", "target": "app.freshpaint-staging.com"},
        {"data_type": "csp_api_gateway",
         "value": "b3yabdl4m8.execute-api.us-west-2.amazonaws.com",
         "source": "http_fingerprint", "target": "app.freshpaint-staging.com"},
        {"data_type": "csp_service", "value": "sentry.io",
         "source": "http_fingerprint", "target": "app.freshpaint-staging.com"},
    ]


def test_appendix_renders_section_with_categories():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_osint_appendix(_osint_records_for_engagement_11())
    assert "audit-osint-appendix" in out
    assert "Appendix: Passive Recon (OSINT) Data" in out
    # Category labels rendered
    assert "S3 buckets exposed via CSP" in out
    assert "CDN providers in CSP" in out
    assert "API gateways in CSP" in out
    assert "Third-party services in CSP" in out
    assert "CSP-referenced domains" in out


def test_appendix_includes_raw_values():
    """The whole point of the appendix is to surface raw values for
    internal review. Bucket names, CDN domains, etc. all appear."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_osint_appendix(_osint_records_for_engagement_11())
    assert "freshpaint-baa-uploads.s3.us-west-2.amazonaws.com" in out
    assert "freshpaint-audience-lists.s3.us-west-2.amazonaws.com" in out
    assert "d1xv9akss4wau0.cloudfront.net" in out
    assert "sentry.io" in out


def test_appendix_includes_internal_only_warning():
    """The appendix should explicitly tell the reader this is
    internal-only and customer-shareable versions should omit it."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_osint_appendix(_osint_records_for_engagement_11())
    assert "Internal use only" in out
    assert "redacted" in out.lower()


def test_appendix_displays_count_per_category():
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_osint_appendix(_osint_records_for_engagement_11())
    # 2 S3 buckets, 1 CDN, 1 API gateway, 1 service, 2 generic domains
    # The counts should appear as `(N)` next to each category header
    assert "osint-count" in out
    assert "(2)" in out  # at least one category has 2


def test_appendix_orders_high_value_categories_first():
    """S3 buckets and API gateways come before generic CDN/service/
    domain categories — they're the highest-impact disclosures."""
    fmt = HTMLFormatter()
    out = fmt.audit_evidence_osint_appendix(_osint_records_for_engagement_11())
    s3_idx = out.find("S3 buckets exposed via CSP")
    cdn_idx = out.find("CDN providers in CSP")
    domains_idx = out.find("CSP-referenced domains")
    assert s3_idx < cdn_idx
    assert cdn_idx < domains_idx


def test_appendix_handles_empty_records():
    fmt = HTMLFormatter()
    assert fmt.audit_evidence_osint_appendix([]) == ""


def test_appendix_handles_unknown_data_type():
    """A new OSINT type not in the type_labels map should still render
    using the raw data_type string. Defense against parser-version
    churn introducing new categories."""
    fmt = HTMLFormatter()
    records = [
        {"data_type": "linkfinder_endpoint",
         "value": "/api/v2/admin", "source": "js_analysis",
         "target": "app.example.com"},
    ]
    out = fmt.audit_evidence_osint_appendix(records)
    # Falls back to title-cased raw type
    assert "Linkfinder Endpoint" in out
    assert "/api/v2/admin" in out


def test_appendix_html_escapes_values():
    """Defensive: a CSP entry containing HTML special characters
    shouldn't break the rendered page."""
    fmt = HTMLFormatter()
    records = [
        {"data_type": "csp_domain",
         "value": "<script>alert(1)</script>.example.com",
         "source": "http_fingerprint",
         "target": "app.example.com"},
    ]
    out = fmt.audit_evidence_osint_appendix(records)
    assert "<script>" not in out  # escaped
    assert "&lt;script&gt;" in out  # rendered as text


def test_appendix_orders_values_alphabetically_within_category():
    fmt = HTMLFormatter()
    records = [
        {"data_type": "csp_s3_bucket", "value": "zzz-bucket.s3.amazonaws.com",
         "source": "http_fingerprint", "target": "x"},
        {"data_type": "csp_s3_bucket", "value": "aaa-bucket.s3.amazonaws.com",
         "source": "http_fingerprint", "target": "x"},
        {"data_type": "csp_s3_bucket", "value": "mmm-bucket.s3.amazonaws.com",
         "source": "http_fingerprint", "target": "x"},
    ]
    out = fmt.audit_evidence_osint_appendix(records)
    a_idx = out.index("aaa-bucket")
    m_idx = out.index("mmm-bucket")
    z_idx = out.index("zzz-bucket")
    assert a_idx < m_idx < z_idx


# ---------------------------------------------------------------------------
# CSP S3 info-disclosure finding (created in result_handler.py)
# ---------------------------------------------------------------------------


def _simulate_csp_finding_creation(csp_s3_buckets, target_host, target):
    """
    Mirrors the v3.0.87 finding-creation logic inside result_handler.
    Lifted into a helper so we can test the description shape and
    severity without wiring up the full job-result pipeline.
    """
    if not csp_s3_buckets:
        return None
    bucket_lines = "\n".join(
        f"- {b['hostname']} (directive: {b['directive']}, "
        f"variant: {b['variant']})"
        for b in csp_s3_buckets
    )
    bucket_summary = ", ".join(b["hostname"] for b in csp_s3_buckets)
    return {
        "title": (
            f"S3 bucket hostnames exposed in CSP "
            f"({len(csp_s3_buckets)} bucket(s))"
        ),
        "finding_type": "info_disclosure_csp_bucket_names",
        "severity": "low",
        "description": (
            f"The Content-Security-Policy header on {target_host} references "
            f"{len(csp_s3_buckets)} S3 bucket hostname(s)."
            f"\n\n**Buckets exposed:**\n{bucket_lines}\n\n"
            "**How to manually verify:**\n```\n"
            f"curl -sI https://{target_host}/ | "
            "grep -i content-security-policy\n```"
        ),
        "evidence": f"CSP-extracted S3 buckets: {bucket_summary}",
    }


def test_csp_finding_created_when_buckets_present():
    finding = _simulate_csp_finding_creation(
        [
            {"hostname": "freshpaint-baa-uploads.s3.us-west-2.amazonaws.com",
             "directive": "img-src", "variant": "enforced"},
        ],
        "app.freshpaint-staging.com",
        "https://app.freshpaint-staging.com",
    )
    assert finding is not None
    assert finding["severity"] == "low"
    assert finding["finding_type"] == "info_disclosure_csp_bucket_names"
    assert "1 bucket(s)" in finding["title"]


def test_csp_finding_aggregates_multiple_buckets():
    finding = _simulate_csp_finding_creation(
        [
            {"hostname": "freshpaint-baa-uploads.s3...", "directive": "img-src",
             "variant": "enforced"},
            {"hostname": "freshpaint-audience-lists.s3...",
             "directive": "img-src", "variant": "enforced"},
            {"hostname": "freshpaint-video-hosting.s3...",
             "directive": "img-src", "variant": "enforced"},
        ],
        "app.freshpaint-staging.com",
        "https://app.freshpaint-staging.com",
    )
    assert finding is not None
    assert "3 bucket(s)" in finding["title"]
    # All three appear in the description
    assert "freshpaint-baa-uploads" in finding["description"]
    assert "freshpaint-audience-lists" in finding["description"]
    assert "freshpaint-video-hosting" in finding["description"]


def test_csp_finding_includes_validation_command():
    finding = _simulate_csp_finding_creation(
        [
            {"hostname": "x.s3.amazonaws.com", "directive": "img-src",
             "variant": "enforced"},
        ],
        "app.example.com",
        "https://app.example.com",
    )
    desc = finding["description"]
    assert "How to manually verify" in desc
    assert "curl -sI https://app.example.com/" in desc
    assert "content-security-policy" in desc.lower()


def test_no_finding_when_no_csp_buckets():
    finding = _simulate_csp_finding_creation([], "x", "x")
    assert finding is None
