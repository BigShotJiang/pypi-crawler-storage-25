#!/usr/bin/env python3
"""
TLS Check handler.

Parses tls_check plugin output and creates findings for deprecated
protocols, weak certificates, and missing HSTS. Mirrors the
s3_check / origin_check pure-Python plugin pattern.

Severity mapping:
- Cert expired                       -> critical
- TLS 1.0 / 1.1 accepted             -> high
- Cert expires within 14 days        -> high
- SHA-1 / MD5 signature on cert      -> high
- Cert expires within 30 days        -> medium
- Self-signed cert                   -> medium
- HSTS missing                       -> medium
- HSTS max-age < 1 year              -> low
"""

import json
import logging
import os
import re
from typing import Any, Dict, Optional

import click

from souleyez.engine.job_status import (STATUS_DONE, STATUS_ERROR,
                                        STATUS_NO_RESULTS, STATUS_WARNING)
from souleyez.handlers.base import BaseToolHandler

logger = logging.getLogger(__name__)


def _parse_log(log_path: str) -> Dict[str, Any]:
    if not log_path or not os.path.exists(log_path):
        return {}
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception:
        return {}
    m = re.search(
        r"=== JSON_RESULT ===\n(.+?)\n=== END_JSON_RESULT ===",
        text,
        re.DOTALL,
    )
    if not m:
        return {}
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return {}


_HSTS_ONE_YEAR_SECONDS = 365 * 24 * 3600


class TlsCheckHandler(BaseToolHandler):
    """Handler for tls_check plugin jobs."""

    tool_name = "tls_check"
    display_name = "TLS Check"

    has_error_handler = True
    has_warning_handler = True
    has_no_results_handler = True
    has_done_handler = True

    def parse_job(
        self,
        engagement_id: int,
        log_path: str,
        job: Dict[str, Any],
        host_manager: Optional[Any] = None,
        findings_manager: Optional[Any] = None,
        credentials_manager: Optional[Any] = None,
    ) -> Dict[str, Any]:
        try:
            if (
                not log_path
                or not os.path.exists(log_path)
                or os.path.getsize(log_path) == 0
            ):
                return {
                    "tool": self.tool_name,
                    "status": STATUS_NO_RESULTS,
                    "summary": "Empty output (plugin produced no log)",
                }

            parsed = _parse_log(log_path)
            target = job.get("target", "")
            hostname = parsed.get("hostname")

            if not parsed or not hostname:
                err = parsed.get("error") if parsed else "Unparseable tls_check output"
                return {
                    "tool": self.tool_name,
                    "status": STATUS_WARNING,
                    "target": target,
                    "summary": err or "Could not parse target as hostname",
                }

            host_id = self._upsert_host(engagement_id, hostname, host_manager)

            from souleyez.storage.findings import FindingsManager

            fm = findings_manager or FindingsManager()
            findings_added = 0

            findings_added += self._check_deprecated_protocols(
                engagement_id, host_id, hostname, parsed, fm
            )
            findings_added += self._check_certificate(
                engagement_id, host_id, hostname, parsed, fm
            )
            findings_added += self._check_hsts(
                engagement_id, host_id, hostname, parsed, fm
            )

            err = parsed.get("error")
            if err and findings_added == 0:
                return {
                    "tool": self.tool_name,
                    "status": STATUS_WARNING,
                    "target": target,
                    "summary": err,
                    "findings_added": 0,
                }

            if findings_added > 0:
                summary = self._build_summary(parsed, findings_added)
                status = STATUS_DONE
            else:
                summary = "TLS configuration looks healthy"
                status = STATUS_NO_RESULTS

            return {
                "tool": self.tool_name,
                "status": status,
                "target": target,
                "hostname": hostname,
                "findings_added": findings_added,
                "summary": summary,
            }

        except Exception as e:
            logger.error(f"Error parsing tls_check job: {e}")
            return {
                "tool": self.tool_name,
                "status": STATUS_ERROR,
                "error": str(e),
                "summary": f"Parse error: {e}",
            }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _upsert_host(
        self, engagement_id: int, hostname: str, host_manager: Optional[Any]
    ) -> Optional[int]:
        if host_manager is None:
            from souleyez.storage.hosts import HostManager

            host_manager = HostManager()
        try:
            rec = host_manager.add_or_update_host(
                engagement_id,
                {
                    "ip": hostname,
                    "hostname": hostname,
                    "status": "up",
                    "notes": "TLS configuration audited via tls_check",
                },
            )
            if isinstance(rec, int):
                return rec
            if isinstance(rec, dict):
                return rec.get("id")
            found = host_manager.get_host_by_ip(engagement_id, hostname)
            return found["id"] if found else None
        except Exception as e:
            logger.debug(f"TLS check: host upsert failed: {e}")
            return None

    def _check_deprecated_protocols(
        self,
        engagement_id: int,
        host_id: Optional[int],
        hostname: str,
        parsed: Dict[str, Any],
        fm: Any,
    ) -> int:
        if host_id is None:
            return 0
        added = 0
        for proto in parsed.get("deprecated_protocols") or []:
            name = proto.get("name", "deprecated TLS")
            sev = proto.get("severity", "high")
            try:
                fm.add_finding(
                    engagement_id=engagement_id,
                    host_id=host_id,
                    title=f"Deprecated TLS protocol accepted: {name}",
                    finding_type="tls_misconfiguration",
                    severity=sev,
                    description=(
                        f"The server at {hostname} accepts handshakes at "
                        f"{name}. This protocol version is deprecated and "
                        "vulnerable to known weaknesses (BEAST, POODLE-class "
                        "attacks). Modern compliance frameworks (PCI-DSS 4.0, "
                        "NIST SP 800-52 Rev 2) require TLS 1.2 or higher. "
                        "Disable TLS 1.0 and TLS 1.1 at the load balancer / "
                        "reverse proxy / cloud provider TLS policy."
                        "\n\n**How to manually verify:**\n```\n"
                        f"openssl s_client -{name.lower().replace(' ', '_').replace('.', '_')} "
                        f"-connect {hostname}:443 </dev/null 2>&1 | "
                        "grep -iE 'protocol|cipher|verify return code'"
                        "\n```\n"
                        "If the handshake completes (no `ssl handshake failure`), "
                        "the protocol is accepted."
                    ),
                    tool=self.tool_name,
                    path=hostname,
                    evidence=f"{name} handshake accepted by {hostname}:{parsed.get('port')}",
                )
                added += 1
            except Exception as e:
                logger.warning(f"Failed to add tls deprecated-protocol finding: {e}")
        return added

    def _check_certificate(
        self,
        engagement_id: int,
        host_id: Optional[int],
        hostname: str,
        parsed: Dict[str, Any],
        fm: Any,
    ) -> int:
        if host_id is None:
            return 0
        cert = parsed.get("certificate") or {}
        if not cert or "error" in cert:
            return 0
        added = 0

        days = cert.get("days_until_expiry")
        if isinstance(days, int):
            if days < 0:
                added += self._add_finding(
                    fm, engagement_id, host_id, hostname, parsed,
                    severity="critical",
                    title=f"Certificate expired ({-days} day(s) ago)",
                    finding_type="tls_cert_expired",
                    description=(
                        f"The TLS certificate for {hostname} expired "
                        f"{-days} day(s) ago. Browsers and clients will "
                        "reject connections. Renew immediately and audit "
                        "the cert auto-renewal pipeline (Let's Encrypt / "
                        "ACM) to determine why it lapsed."
                        "\n\n**How to manually verify:**\n```\n"
                        f"openssl s_client -connect {hostname}:443 -servername "
                        f"{hostname} </dev/null 2>&1 | openssl x509 -noout -dates"
                        "\n```\n"
                        "Compare `notAfter` against today's date."
                    ),
                    evidence=f"Certificate not_after: {cert.get('not_after_iso')}",
                )
            elif days < 14:
                added += self._add_finding(
                    fm, engagement_id, host_id, hostname, parsed,
                    severity="high",
                    title=f"Certificate expires in {days} day(s)",
                    finding_type="tls_cert_expiring",
                    description=(
                        f"The TLS certificate for {hostname} expires in "
                        f"{days} day(s). Renew now to avoid an outage. "
                        "Verify the auto-renewal job is healthy."
                        "\n\n**How to manually verify:**\n```\n"
                        f"openssl s_client -connect {hostname}:443 -servername "
                        f"{hostname} </dev/null 2>&1 | openssl x509 -noout -dates"
                        "\n```"
                    ),
                    evidence=f"Certificate not_after: {cert.get('not_after_iso')}",
                )
            elif days < 30:
                added += self._add_finding(
                    fm, engagement_id, host_id, hostname, parsed,
                    severity="medium",
                    title=f"Certificate expires in {days} day(s)",
                    finding_type="tls_cert_expiring",
                    description=(
                        f"The TLS certificate for {hostname} expires in "
                        f"{days} day(s). Plan renewal in the next two weeks. "
                        "Monitor your cert-management automation."
                        "\n\n**How to manually verify:**\n```\n"
                        f"openssl s_client -connect {hostname}:443 -servername "
                        f"{hostname} </dev/null 2>&1 | openssl x509 -noout -dates"
                        "\n```"
                    ),
                    evidence=f"Certificate not_after: {cert.get('not_after_iso')}",
                )

        if cert.get("signature_is_weak"):
            sig = cert.get("signature_algorithm") or "weak"
            added += self._add_finding(
                fm, engagement_id, host_id, hostname, parsed,
                severity="high",
                title=f"Certificate uses weak signature algorithm ({sig})",
                finding_type="tls_weak_signature",
                description=(
                    f"The TLS certificate for {hostname} is signed with "
                    f"{sig}. SHA-1 has been deprecated since 2017 (NIST "
                    "SP 800-131A). MD5-based signatures are completely "
                    "broken. Reissue the certificate with SHA-256 or "
                    "stronger from your CA."
                    "\n\n**How to manually verify:**\n```\n"
                    f"openssl s_client -connect {hostname}:443 -servername "
                    f"{hostname} </dev/null 2>&1 | openssl x509 -noout -text "
                    "| grep -i 'signature algorithm'"
                    "\n```"
                ),
                evidence=f"Signature algorithm: {sig}",
            )

        if cert.get("self_signed"):
            added += self._add_finding(
                fm, engagement_id, host_id, hostname, parsed,
                severity="medium",
                title=f"Self-signed TLS certificate on {hostname}",
                finding_type="tls_self_signed",
                description=(
                    f"The TLS certificate for {hostname} is self-signed "
                    f"(subject == issuer: {cert.get('subject')}). Browsers "
                    "and most HTTP clients reject self-signed certs by "
                    "default, breaking trust. Replace with a CA-issued "
                    "certificate (Let's Encrypt is free) or document why "
                    "this host is exempt (e.g., internal-only with mTLS)."
                    "\n\n**How to manually verify:**\n```\n"
                    f"openssl s_client -connect {hostname}:443 -servername "
                    f"{hostname} </dev/null 2>&1 | openssl x509 -noout -issuer -subject"
                    "\n```\n"
                    "If `issuer=` and `subject=` are identical, the cert is self-signed."
                ),
                evidence=f"Subject: {cert.get('subject')} | Issuer: {cert.get('issuer')}",
            )

        return added

    def _check_hsts(
        self,
        engagement_id: int,
        host_id: Optional[int],
        hostname: str,
        parsed: Dict[str, Any],
        fm: Any,
    ) -> int:
        if host_id is None:
            return 0
        hsts = parsed.get("hsts") or {}
        if "error" in hsts:
            return 0
        added = 0

        if not hsts.get("present"):
            added += self._add_finding(
                fm, engagement_id, host_id, hostname, parsed,
                severity="medium",
                title=f"HSTS header missing on {hostname}",
                finding_type="tls_hsts_missing",
                description=(
                    f"{hostname} does not return a Strict-Transport-Security "
                    "(HSTS) response header. Without HSTS, an attacker on "
                    "the network path can downgrade a victim's HTTPS "
                    "connection to HTTP via an SSL-strip attack. Add "
                    "`Strict-Transport-Security: max-age=31536000; "
                    "includeSubDomains; preload` at the load balancer or "
                    "application layer."
                    "\n\n**Detection Method (during scan):**\n"
                    f"- HTTP HEAD `https://{hostname}/`\n"
                    "- Inspected response headers for "
                    "`Strict-Transport-Security`\n"
                    "- Result: header not present\n"
                    "\n**How to manually verify:**\n```\n"
                    f"curl -sI https://{hostname}/ | grep -i strict-transport-security"
                    "\n```\n"
                    "Empty output = HSTS missing. A correct response shows "
                    "`Strict-Transport-Security: max-age=...`."
                ),
                evidence="No Strict-Transport-Security header in response",
            )
        else:
            max_age = hsts.get("max_age_seconds") or 0
            if max_age < _HSTS_ONE_YEAR_SECONDS:
                added += self._add_finding(
                    fm, engagement_id, host_id, hostname, parsed,
                    severity="low",
                    title=f"HSTS max-age below 1 year on {hostname}",
                    finding_type="tls_hsts_weak",
                    description=(
                        f"{hostname} returns HSTS with max-age={max_age} "
                        "seconds, which is less than the recommended one "
                        "year (31536000). Short max-age windows give "
                        "attackers more opportunity to downgrade fresh "
                        "clients. Increase to 31536000 and add `preload` "
                        "if you want HSTS pre-baked into browsers."
                        "\n\n**How to manually verify:**\n```\n"
                        f"curl -sI https://{hostname}/ | grep -i strict-transport-security"
                        "\n```"
                    ),
                    evidence=f"HSTS header: {hsts.get('raw')}",
                )

        return added

    def _add_finding(
        self,
        fm: Any,
        engagement_id: int,
        host_id: int,
        hostname: str,
        parsed: Dict[str, Any],
        severity: str,
        title: str,
        finding_type: str,
        description: str,
        evidence: str,
    ) -> int:
        try:
            fm.add_finding(
                engagement_id=engagement_id,
                host_id=host_id,
                title=title,
                finding_type=finding_type,
                severity=severity,
                description=description,
                tool=self.tool_name,
                path=hostname,
                evidence=evidence,
            )
            return 1
        except Exception as e:
            logger.warning(f"Failed to add tls finding: {e}")
            return 0

    def _build_summary(self, parsed: Dict[str, Any], count: int) -> str:
        bits = []
        deprecated = parsed.get("deprecated_protocols") or []
        if deprecated:
            bits.append(
                f"{len(deprecated)} deprecated protocol(s): "
                + ", ".join(d.get("name", "") for d in deprecated)
            )
        cert = parsed.get("certificate") or {}
        if cert.get("days_until_expiry") is not None and cert.get("days_until_expiry") < 30:
            bits.append(f"cert expires in {cert['days_until_expiry']}d")
        if cert.get("signature_is_weak"):
            bits.append(f"weak signature ({cert.get('signature_algorithm')})")
        if cert.get("self_signed"):
            bits.append("self-signed cert")
        hsts = parsed.get("hsts") or {}
        if not hsts.get("present"):
            bits.append("HSTS missing")
        elif (hsts.get("max_age_seconds") or 0) < _HSTS_ONE_YEAR_SECONDS:
            bits.append("HSTS max-age weak")
        return f"{count} finding(s): " + " | ".join(bits) if bits else f"{count} finding(s)"

    # ------------------------------------------------------------------
    # Display methods
    # ------------------------------------------------------------------

    def display_done(
        self,
        job: Dict[str, Any],
        log_path: str,
        show_all: bool = False,
        show_passwords: bool = False,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo(click.style("TLS / SSL AUDIT", bold=True, fg="cyan"))
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo()
        click.echo(f"  Hostname: {parsed.get('hostname')}")
        click.echo(f"  Port: {parsed.get('port')}")
        deprecated = parsed.get("deprecated_protocols") or []
        if deprecated:
            click.echo(
                click.style(
                    f"  ⚠ Deprecated protocols accepted: {len(deprecated)}",
                    fg="red",
                    bold=True,
                )
            )
            for d in deprecated:
                click.echo(f"    - {d.get('name')}")
        cert = parsed.get("certificate") or {}
        if cert and "error" not in cert:
            days = cert.get("days_until_expiry")
            if days is not None:
                color = (
                    "red"
                    if days < 14
                    else "yellow"
                    if days < 30
                    else "green"
                )
                click.echo(
                    click.style(f"  Cert expires in {days} day(s)", fg=color)
                )
            if cert.get("signature_is_weak"):
                click.echo(
                    click.style(
                        f"  ⚠ Weak signature: {cert.get('signature_algorithm')}",
                        fg="red",
                    )
                )
            if cert.get("self_signed"):
                click.echo(
                    click.style("  ⚠ Self-signed certificate", fg="yellow")
                )
        hsts = parsed.get("hsts") or {}
        if "error" not in hsts:
            if not hsts.get("present"):
                click.echo(click.style("  ⚠ HSTS missing", fg="yellow"))
            else:
                ma = hsts.get("max_age_seconds") or 0
                if ma < _HSTS_ONE_YEAR_SECONDS:
                    click.echo(
                        click.style(
                            f"  HSTS present but max-age={ma}s (< 1 year)",
                            fg="yellow",
                        )
                    )
                else:
                    click.echo(
                        click.style(
                            f"  ✓ HSTS present (max-age={ma}s)", fg="green"
                        )
                    )
        click.echo()

    def display_warning(
        self,
        job: Dict[str, Any],
        log_path: str,
        log_content: Optional[str] = None,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="yellow"))
        click.echo(click.style("[WARNING] TLS CHECK", bold=True, fg="yellow"))
        click.echo(click.style("=" * 70, fg="yellow"))
        click.echo()
        if parsed.get("error"):
            click.echo(f"  {parsed['error']}")
        else:
            click.echo("  Audit completed with warnings. Check raw logs.")
        click.echo()

    def display_error(
        self,
        job: Dict[str, Any],
        log_path: str,
        log_content: Optional[str] = None,
    ) -> None:
        click.echo(click.style("=" * 70, fg="red"))
        click.echo(click.style("[ERROR] TLS CHECK FAILED", bold=True, fg="red"))
        click.echo(click.style("=" * 70, fg="red"))
        click.echo("  Audit failed - see raw logs for details (press 'r')")
        click.echo()

    def display_no_results(
        self,
        job: Dict[str, Any],
        log_path: str,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo(click.style("TLS / SSL AUDIT", bold=True, fg="cyan"))
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo()
        click.echo(f"  Hostname: {parsed.get('hostname') or '(unknown)'}")
        click.echo(
            click.style(
                "  Result: TLS configuration looks healthy", fg="green", bold=True
            )
        )
        click.echo()
