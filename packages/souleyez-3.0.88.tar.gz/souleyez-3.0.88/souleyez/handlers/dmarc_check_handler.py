#!/usr/bin/env python3
"""
DMARC Check handler.

Parses dmarc_check plugin output and creates findings for missing
or weak email-security DNS records.

Severity mapping:
- SPF +all (open relay)            -> high
- SPF missing                       -> medium
- SPF >10 lookups (RFC 7208 §4.6.4) -> low
- DMARC missing                     -> medium
- DMARC p=none (monitor only)       -> low
- DMARC missing rua= reporting      -> low
- DNSSEC not enabled                -> low
"""

import json
import logging
import os
import re
from typing import Any, Dict, Optional

import click

from souleyez.engine.job_status import (STATUS_DONE, STATUS_ERROR,
                                        STATUS_NO_RESULTS, STATUS_WARNING)
from souleyez.handlers.base import BaseToolHandler

logger = logging.getLogger(__name__)


def _parse_log(log_path: str) -> Dict[str, Any]:
    if not log_path or not os.path.exists(log_path):
        return {}
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except Exception:
        return {}
    m = re.search(
        r"=== JSON_RESULT ===\n(.+?)\n=== END_JSON_RESULT ===",
        text,
        re.DOTALL,
    )
    if not m:
        return {}
    try:
        return json.loads(m.group(1))
    except json.JSONDecodeError:
        return {}


class DmarcCheckHandler(BaseToolHandler):
    """Handler for dmarc_check plugin jobs."""

    tool_name = "dmarc_check"
    display_name = "DMARC Check"

    has_error_handler = True
    has_warning_handler = True
    has_no_results_handler = True
    has_done_handler = True

    def parse_job(
        self,
        engagement_id: int,
        log_path: str,
        job: Dict[str, Any],
        host_manager: Optional[Any] = None,
        findings_manager: Optional[Any] = None,
        credentials_manager: Optional[Any] = None,
    ) -> Dict[str, Any]:
        try:
            if (
                not log_path
                or not os.path.exists(log_path)
                or os.path.getsize(log_path) == 0
            ):
                return {
                    "tool": self.tool_name,
                    "status": STATUS_NO_RESULTS,
                    "summary": "Empty output (plugin produced no log)",
                }

            parsed = _parse_log(log_path)
            target = job.get("target", "")
            apex = parsed.get("apex")

            if not parsed or not apex:
                err = parsed.get("error") if parsed else "Unparseable dmarc_check output"
                return {
                    "tool": self.tool_name,
                    "status": STATUS_WARNING,
                    "target": target,
                    "summary": err or "Could not extract apex domain",
                }

            host_id = self._upsert_host(engagement_id, apex, host_manager)

            from souleyez.storage.findings import FindingsManager

            fm = findings_manager or FindingsManager()

            findings_added = 0
            findings_added += self._check_spf(
                engagement_id, host_id, apex, parsed, fm
            )
            findings_added += self._check_dmarc(
                engagement_id, host_id, apex, parsed, fm
            )
            findings_added += self._check_dnssec(
                engagement_id, host_id, apex, parsed, fm
            )

            err = parsed.get("error")
            if err and findings_added == 0:
                return {
                    "tool": self.tool_name,
                    "status": STATUS_WARNING,
                    "target": target,
                    "summary": err,
                    "findings_added": 0,
                }

            if findings_added > 0:
                summary = self._build_summary(parsed, findings_added)
                status = STATUS_DONE
            else:
                summary = "Email-security DNS posture looks healthy"
                status = STATUS_NO_RESULTS

            return {
                "tool": self.tool_name,
                "status": status,
                "target": target,
                "apex": apex,
                "findings_added": findings_added,
                "summary": summary,
            }

        except Exception as e:
            logger.error(f"Error parsing dmarc_check job: {e}")
            return {
                "tool": self.tool_name,
                "status": STATUS_ERROR,
                "error": str(e),
                "summary": f"Parse error: {e}",
            }

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _upsert_host(
        self, engagement_id: int, apex: str, host_manager: Optional[Any]
    ) -> Optional[int]:
        if host_manager is None:
            from souleyez.storage.hosts import HostManager

            host_manager = HostManager()
        try:
            rec = host_manager.add_or_update_host(
                engagement_id,
                {
                    "ip": apex,
                    "hostname": apex,
                    "status": "up",
                    "notes": "Apex domain audited via dmarc_check",
                },
            )
            if isinstance(rec, int):
                return rec
            if isinstance(rec, dict):
                return rec.get("id")
            found = host_manager.get_host_by_ip(engagement_id, apex)
            return found["id"] if found else None
        except Exception as e:
            logger.debug(f"DMARC check: host upsert failed: {e}")
            return None

    def _check_spf(
        self, engagement_id: int, host_id: Optional[int],
        apex: str, parsed: Dict[str, Any], fm: Any,
    ) -> int:
        if host_id is None:
            return 0
        spf = parsed.get("spf") or {}
        added = 0
        if not spf.get("present"):
            added += self._add_finding(
                fm, engagement_id, host_id, apex,
                severity="medium",
                title=f"SPF record missing on {apex}",
                finding_type="email_security_spf_missing",
                description=(
                    f"No SPF (Sender Policy Framework) TXT record found at "
                    f"{apex}. Without SPF, attackers can spoof email "
                    "claiming to come from your domain. Publish a TXT "
                    f"record at {apex} starting `v=spf1` listing your "
                    "authorized senders, ending with `-all` (hard fail) "
                    "or `~all` (soft fail) for unauthorized senders."
                    "\n\n**Detection Method (during scan):**\n"
                    f"- DNS TXT query for `{apex}`\n"
                    "- Inspected results for records starting with `v=spf1`\n"
                    "- Result: no `v=spf1` record returned\n"
                    "\n**How to manually verify:**\n```\n"
                    f"dig +short TXT {apex} | grep -i 'v=spf1'"
                    "\n```\n"
                    "Empty output = SPF missing."
                ),
                evidence=f"DNS TXT lookup at {apex} returned no v=spf1 record",
            )
            return added
        qualifier = spf.get("ends_with_all")
        if qualifier == "+all":
            added += self._add_finding(
                fm, engagement_id, host_id, apex,
                severity="high",
                title=f"SPF record on {apex} permits all senders (+all)",
                finding_type="email_security_spf_open",
                description=(
                    f"The SPF record on {apex} ends with `+all`, meaning "
                    "the domain authorizes ANY sender to send mail as "
                    "this domain. This completely defeats SPF and "
                    "enables trivial spoofing. Replace `+all` with "
                    "`-all` (hard fail) after auditing your authorized "
                    "senders."
                    "\n\n**How to manually verify:**\n```\n"
                    f"dig +short TXT {apex} | grep -i 'v=spf1'"
                    "\n```\n"
                    "Look for `+all` at the end of the SPF string."
                ),
                evidence=f"SPF record: {spf.get('raw')}",
            )
        elif qualifier == "?all":
            added += self._add_finding(
                fm, engagement_id, host_id, apex,
                severity="low",
                title=f"SPF record on {apex} uses neutral (?all)",
                finding_type="email_security_spf_neutral",
                description=(
                    "The SPF record ends with `?all` (neutral), which "
                    "provides no enforcement against spoofers. Tighten "
                    "to `-all` or `~all` after confirming authorized "
                    "senders are listed."
                    "\n\n**How to manually verify:**\n```\n"
                    f"dig +short TXT {apex} | grep -i 'v=spf1'"
                    "\n```"
                ),
                evidence=f"SPF record: {spf.get('raw')}",
            )
        if (spf.get("lookup_count") or 0) > 10:
            added += self._add_finding(
                fm, engagement_id, host_id, apex,
                severity="low",
                title=f"SPF record on {apex} exceeds 10-lookup limit",
                finding_type="email_security_spf_lookup_limit",
                description=(
                    f"The SPF record on {apex} has "
                    f"{spf.get('lookup_count')} lookup-causing terms "
                    "(include / a / mx / exists / redirect). RFC 7208 "
                    "§4.6.4 caps SPF at 10 lookups; some receivers will "
                    "PermError and treat the record as missing. "
                    "Consolidate includes or use SPF flattening to "
                    "stay under the limit."
                    "\n\n**How to manually verify:**\n```\n"
                    f"dig +short TXT {apex} | grep -i 'v=spf1' | "
                    "grep -oE 'include:|redirect=|exists:|\\ba\\b|\\bmx\\b|ptr' | wc -l"
                    "\n```\n"
                    "If the count is >10, the record exceeds the lookup limit."
                ),
                evidence=f"SPF record: {spf.get('raw')}",
            )
        return added

    def _check_dmarc(
        self, engagement_id: int, host_id: Optional[int],
        apex: str, parsed: Dict[str, Any], fm: Any,
    ) -> int:
        if host_id is None:
            return 0
        dmarc = parsed.get("dmarc") or {}
        added = 0
        if not dmarc.get("present"):
            added += self._add_finding(
                fm, engagement_id, host_id, apex,
                severity="medium",
                title=f"DMARC record missing on {apex}",
                finding_type="email_security_dmarc_missing",
                description=(
                    f"No DMARC record found at _dmarc.{apex}. DMARC "
                    "tells receivers what to do with mail that fails "
                    "SPF/DKIM authentication, and provides reporting "
                    "back to the domain owner. Publish a TXT record at "
                    f"_dmarc.{apex} starting `v=DMARC1` with at least "
                    "`p=quarantine` or `p=reject` and a `rua=mailto:...` "
                    "address for aggregate reports."
                    "\n\n**Detection Method (during scan):**\n"
                    f"- DNS TXT query for `_dmarc.{apex}`\n"
                    "- Inspected results for records starting with "
                    "`v=DMARC1`\n"
                    "- Result: no `v=DMARC1` record returned\n"
                    "\n**How to manually verify:**\n```\n"
                    f"dig +short TXT _dmarc.{apex}"
                    "\n```\n"
                    "Empty output = DMARC missing."
                ),
                evidence=f"DNS TXT lookup at _dmarc.{apex} returned no record",
            )
            return added
        policy = (dmarc.get("policy") or "").lower()
        if policy == "none":
            added += self._add_finding(
                fm, engagement_id, host_id, apex,
                severity="low",
                title=f"DMARC policy on {apex} is monitor-only (p=none)",
                finding_type="email_security_dmarc_no_enforcement",
                description=(
                    "The DMARC policy is set to `p=none`, which only "
                    "monitors and reports — it does not instruct "
                    "receivers to reject or quarantine spoofed mail. "
                    "After observing aggregate reports (rua=) for a "
                    "few weeks and confirming no legit senders are "
                    "missing, tighten to `p=quarantine` then `p=reject`."
                    "\n\n**How to manually verify:**\n```\n"
                    f"dig +short TXT _dmarc.{apex} | grep -oE 'p=[a-z]+'"
                    "\n```\n"
                    "Output `p=none` confirms monitor-only enforcement."
                ),
                evidence=f"DMARC record: {dmarc.get('raw')}",
            )
        if not dmarc.get("rua"):
            added += self._add_finding(
                fm, engagement_id, host_id, apex,
                severity="low",
                title=f"DMARC record on {apex} missing aggregate reporting (rua=)",
                finding_type="email_security_dmarc_no_reporting",
                description=(
                    "The DMARC record does not specify a `rua=` mailto "
                    "for aggregate reports. Without reporting you can't "
                    "see spoofing attempts or audit your authorized "
                    "senders' SPF/DKIM alignment. Add "
                    "`rua=mailto:dmarc-reports@yourdomain` to the record."
                    "\n\n**How to manually verify:**\n```\n"
                    f"dig +short TXT _dmarc.{apex} | grep -oE 'rua=[^;]+'"
                    "\n```\n"
                    "Empty output = no rua= configured."
                ),
                evidence=f"DMARC record: {dmarc.get('raw')}",
            )
        return added

    def _check_dnssec(
        self, engagement_id: int, host_id: Optional[int],
        apex: str, parsed: Dict[str, Any], fm: Any,
    ) -> int:
        if host_id is None:
            return 0
        dnssec = parsed.get("dnssec") or {}
        if dnssec.get("dnskey_present"):
            return 0
        return self._add_finding(
            fm, engagement_id, host_id, apex,
            severity="low",
            title=f"DNSSEC not enabled on {apex}",
            finding_type="email_security_dnssec_missing",
            description=(
                f"No DNSKEY records found for {apex}. Without DNSSEC, "
                "an attacker who can manipulate the DNS path "
                "(cache-poisoning, on-path attacker) can redirect "
                "queries for the domain. Enable DNSSEC at your DNS "
                "provider; most major providers (Route 53, Cloudflare, "
                "Google) support it with one-click enablement."
                "\n\n**Detection Method (during scan):**\n"
                f"- DNS DNSKEY query for `{apex}`\n"
                "- Result: no DNSKEY records returned, indicating "
                "DNSSEC is not enabled\n"
                "\n**How to manually verify:**\n```\n"
                f"dig +short DNSKEY {apex}"
                "\n```\n"
                "Empty output = DNSSEC not enabled. A correct response "
                "shows DNSKEY records with key data."
            ),
            evidence=f"DNSKEY query at {apex} returned no records",
        )

    def _add_finding(
        self, fm, engagement_id, host_id, apex,
        severity, title, finding_type, description, evidence,
    ) -> int:
        try:
            fm.add_finding(
                engagement_id=engagement_id,
                host_id=host_id,
                title=title,
                finding_type=finding_type,
                severity=severity,
                description=description,
                tool=self.tool_name,
                path=apex,
                evidence=evidence,
            )
            return 1
        except Exception as e:
            logger.warning(f"Failed to add dmarc finding: {e}")
            return 0

    def _build_summary(self, parsed: Dict[str, Any], count: int) -> str:
        bits = []
        spf = parsed.get("spf") or {}
        if not spf.get("present"):
            bits.append("SPF missing")
        elif spf.get("ends_with_all") == "+all":
            bits.append("SPF +all (open)")
        dmarc = parsed.get("dmarc") or {}
        if not dmarc.get("present"):
            bits.append("DMARC missing")
        elif (dmarc.get("policy") or "").lower() == "none":
            bits.append("DMARC p=none")
        dnssec = parsed.get("dnssec") or {}
        if not dnssec.get("dnskey_present"):
            bits.append("DNSSEC off")
        return f"{count} finding(s): " + " | ".join(bits) if bits else f"{count} finding(s)"

    # ------------------------------------------------------------------
    # Display methods
    # ------------------------------------------------------------------

    def display_done(
        self,
        job: Dict[str, Any],
        log_path: str,
        show_all: bool = False,
        show_passwords: bool = False,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo(click.style("EMAIL SECURITY DNS AUDIT", bold=True, fg="cyan"))
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo()
        click.echo(f"  Apex: {parsed.get('apex')}")
        spf = parsed.get("spf") or {}
        if spf.get("present"):
            click.echo(
                click.style(
                    f"  SPF: {spf.get('ends_with_all')} "
                    f"(lookups={spf.get('lookup_count')})",
                    fg="green" if spf.get("ends_with_all") in ("-all", "~all") else "yellow",
                )
            )
        else:
            click.echo(click.style("  ⚠ SPF: MISSING", fg="red"))
        dmarc = parsed.get("dmarc") or {}
        if dmarc.get("present"):
            policy = dmarc.get("policy") or "?"
            color = "green" if policy in ("quarantine", "reject") else "yellow"
            click.echo(click.style(f"  DMARC: p={policy}", fg=color))
        else:
            click.echo(click.style("  ⚠ DMARC: MISSING", fg="red"))
        dkim = parsed.get("dkim") or {}
        found = dkim.get("selectors_found") or []
        click.echo(
            f"  DKIM: {len(found)} selector(s) found "
            f"(probed {len(dkim.get('selectors_probed') or [])})"
        )
        dnssec = parsed.get("dnssec") or {}
        if dnssec.get("dnskey_present"):
            click.echo(click.style("  ✓ DNSSEC: enabled", fg="green"))
        else:
            click.echo(click.style("  ⚠ DNSSEC: not enabled", fg="yellow"))
        click.echo()

    def display_warning(
        self,
        job: Dict[str, Any],
        log_path: str,
        log_content: Optional[str] = None,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="yellow"))
        click.echo(click.style("[WARNING] DMARC CHECK", bold=True, fg="yellow"))
        click.echo(click.style("=" * 70, fg="yellow"))
        click.echo()
        if parsed.get("error"):
            click.echo(f"  {parsed['error']}")
        else:
            click.echo("  Audit completed with warnings. Check raw logs.")
        click.echo()

    def display_error(
        self,
        job: Dict[str, Any],
        log_path: str,
        log_content: Optional[str] = None,
    ) -> None:
        click.echo(click.style("=" * 70, fg="red"))
        click.echo(click.style("[ERROR] DMARC CHECK FAILED", bold=True, fg="red"))
        click.echo(click.style("=" * 70, fg="red"))
        click.echo("  Audit failed - see raw logs for details (press 'r')")
        click.echo()

    def display_no_results(
        self,
        job: Dict[str, Any],
        log_path: str,
    ) -> None:
        parsed = _parse_log(log_path)
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo(click.style("EMAIL SECURITY DNS AUDIT", bold=True, fg="cyan"))
        click.echo(click.style("=" * 70, fg="cyan"))
        click.echo()
        click.echo(f"  Apex: {parsed.get('apex') or '(unknown)'}")
        click.echo(
            click.style(
                "  Result: email-security DNS posture looks healthy",
                fg="green",
                bold=True,
            )
        )
        click.echo()
