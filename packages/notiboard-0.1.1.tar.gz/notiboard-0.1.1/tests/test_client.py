"""Tests for NotiClient — uses httpx MockTransport to avoid real HTTP calls."""

import json
import time
import threading
from typing import Any

import httpx
import pytest

from notiboard.config import NotiConfig
from notiboard.client import NotiClient


# ─── Helpers ─────────────────────────────────────────────────────────────────

def _ok_response(data: Any = None) -> httpx.Response:
    body = json.dumps({"code": 0, "message": "success", "data": data or {}})
    return httpx.Response(200, content=body.encode(), headers={"content-type": "application/json"})


def _error_response(status: int) -> httpx.Response:
    body = json.dumps({"code": status * 100, "message": "error"})
    return httpx.Response(status, content=body.encode(), headers={"content-type": "application/json"})


class _MockTransport(httpx.MockTransport):
    """Records all requests and returns configurable responses."""

    def __init__(self, responses: list[httpx.Response] | None = None, default_status: int = 200):
        self.requests: list[httpx.Request] = []
        self._responses = list(responses or [])
        self._default_status = default_status
        self._lock = threading.Lock()

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        with self._lock:
            self.requests.append(request)
            if self._responses:
                return self._responses.pop(0)
            return _ok_response()


def _make_client(transport: _MockTransport, run_id: str = "test-run-id") -> NotiClient:
    cfg = NotiConfig(api_key="nk_test", server_url="http://test-server", max_retries=2)
    client = NotiClient(cfg, run_id)
    # Replace the httpx client transport
    client._http = httpx.Client(
        base_url="http://test-server",
        headers={"X-Noti-Key": "nk_test"},
        transport=transport,
    )
    return client


# ─── Tests ───────────────────────────────────────────────────────────────────

class TestNotiClientEnqueue:
    def test_enqueue_scalar_puts_item_on_queue(self):
        transport = _MockTransport()
        client = _make_client(transport)
        client._stop_event = threading.Event()  # prevent background thread interference
        client.enqueue_scalar(tag="loss", step=1, value=0.5)
        assert client._queue.qsize() >= 1

    def test_flush_sends_scalars_to_server(self):
        transport = _MockTransport()
        client = _make_client(transport)

        client.enqueue_scalar("loss", 1, 0.5)
        client.enqueue_scalar("acc", 1, 0.9)

        # Manually flush
        client._flush_batch_from_queue()

        assert len(transport.requests) == 1
        body = json.loads(transport.requests[0].content)
        assert body["run_id"] == "test-run-id"
        assert len(body["scalars"]) == 2

    def test_flush_sends_mixed_metric_types(self):
        transport = _MockTransport()
        client = _make_client(transport)

        client.enqueue_scalar("loss", 1, 0.5)
        client.enqueue_text("log", 1, "hello")
        client.enqueue_histogram("weights", 1, {
            "min": 0.0, "max": 1.0, "num": 100, "sum": 50.0, "sum_squares": 33.0,
            "bucket_limits": [0.0, 0.5, 1.0], "bucket_counts": [50, 50],
            "wall_time": 1000.0,
        })

        client._flush_batch_from_queue()

        assert len(transport.requests) == 1
        body = json.loads(transport.requests[0].content)
        assert len(body["scalars"]) == 1
        assert len(body["texts"]) == 1
        assert len(body["histograms"]) == 1

    def test_no_request_when_queue_empty(self):
        transport = _MockTransport()
        client = _make_client(transport)
        client._flush_batch_from_queue()
        assert len(transport.requests) == 0


class TestNotiClientRetry:
    def test_retries_on_5xx(self):
        responses = [_error_response(500), _ok_response()]
        transport = _MockTransport(responses=responses)
        cfg = NotiConfig(api_key="nk_test", server_url="http://test", max_retries=3)
        client = NotiClient(cfg, "test-run")
        client._http = httpx.Client(
            base_url="http://test",
            headers={"X-Noti-Key": "nk_test"},
            transport=transport,
        )

        items: list[dict] = [{"tag": "loss", "step": 1, "value": 0.5, "wall_time": None}]
        client._post_with_retry("/api/v1/metrics/batch", {"run_id": "r", "scalars": items, "histograms": [], "texts": []}, items)

        assert len(transport.requests) == 2  # 1 failure + 1 success

    def test_does_not_retry_on_4xx(self):
        responses = [_error_response(400)]
        transport = _MockTransport(responses=responses)
        cfg = NotiConfig(api_key="nk_test", server_url="http://test", max_retries=3)
        client = NotiClient(cfg, "test-run")
        client._http = httpx.Client(
            base_url="http://test",
            headers={"X-Noti-Key": "nk_test"},
            transport=transport,
        )

        items: list[dict] = [{"tag": "loss", "step": 1, "value": 0.5}]
        client._post_with_retry("/api/v1/metrics/batch", {"run_id": "r", "scalars": items, "histograms": [], "texts": []}, items)

        assert len(transport.requests) == 1  # No retry

    def test_drops_data_after_max_retries(self, caplog):
        import logging
        responses = [_error_response(500)] * 5
        transport = _MockTransport(responses=responses)
        cfg = NotiConfig(api_key="nk_test", server_url="http://test", max_retries=2)
        client = NotiClient(cfg, "test-run")
        client._http = httpx.Client(
            base_url="http://test",
            headers={"X-Noti-Key": "nk_test"},
            transport=transport,
        )
        items: list[dict] = [{"tag": "loss", "step": 1, "value": 0.5}]
        with caplog.at_level(logging.WARNING, logger="noti"):
            client._post_with_retry("/api/v1/metrics/batch", {"run_id": "r", "scalars": items, "histograms": [], "texts": []}, items)
        assert "dropped" in caplog.text.lower()


class TestNotiClientStatusMethods:
    def test_send_progress_calls_put(self):
        transport = _MockTransport()
        client = _make_client(transport)
        client.send_progress(50, 100, "halfway")
        assert len(transport.requests) == 1
        req = transport.requests[0]
        assert req.method == "PUT"
        assert "/progress/" in req.url.path
        body = json.loads(req.content)
        assert body["current_step"] == 50
        assert body["total_steps"] == 100

    def test_send_notification_calls_post(self):
        transport = _MockTransport()
        client = _make_client(transport)
        client.send_notification("Done", "loss=0.01", "Training complete!")
        assert len(transport.requests) == 1
        req = transport.requests[0]
        assert req.method == "POST"
        body = json.loads(req.content)
        assert body["title"] == "Done"

    def test_mark_run_status_calls_patch(self):
        transport = _MockTransport()
        client = _make_client(transport)
        client.mark_run_status("completed")
        assert len(transport.requests) == 1
        req = transport.requests[0]
        assert req.method == "PATCH"
        assert "/status" in req.url.path
        body = json.loads(req.content)
        assert body["status"] == "completed"


class TestNotiClientFlushAndClose:
    def test_flush_and_close_sends_remaining_items(self):
        transport = _MockTransport()
        client = _make_client(transport)

        # Enqueue some items
        for i in range(5):
            client.enqueue_scalar("loss", i, float(i))

        # Close — should flush + mark completed (2 requests: batch + PATCH status)
        client.flush_and_close(complete_on_close=True)

        paths = [r.url.path for r in transport.requests]
        assert any("/metrics/batch" in p for p in paths)
        assert any("/status" in p for p in paths)

    def test_flush_and_close_no_complete_when_flag_false(self):
        transport = _MockTransport()
        client = _make_client(transport)
        client.enqueue_scalar("loss", 1, 0.5)
        client.flush_and_close(complete_on_close=False)
        paths = [r.url.path for r in transport.requests]
        assert not any("/status" in p for p in paths)
