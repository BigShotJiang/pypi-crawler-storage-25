"""Tests for NotiConfig validation and environment variable handling."""

import os
import pytest
from notiboard.config import NotiConfig, DEFAULT_SERVER_URL


class TestNotiConfigDefaults:
    def test_default_server_url(self):
        cfg = NotiConfig()
        assert cfg.server_url == DEFAULT_SERVER_URL

    def test_env_overrides_server_url(self, monkeypatch):
        monkeypatch.setenv("NOTI_SERVER", "http://my-server:9000")
        cfg = NotiConfig()
        assert cfg.server_url == "http://my-server:9000"

    def test_env_overrides_api_key(self, monkeypatch):
        monkeypatch.setenv("NOTI_API_KEY", "nk_env_key")
        cfg = NotiConfig()
        assert cfg.api_key == "nk_env_key"

    def test_constructor_overrides_env(self, monkeypatch):
        monkeypatch.setenv("NOTI_API_KEY", "nk_env_key")
        cfg = NotiConfig(api_key="nk_explicit_key")
        assert cfg.api_key == "nk_explicit_key"

    def test_enabled_default_is_true(self):
        cfg = NotiConfig()
        assert cfg.enabled is True

    def test_enabled_false_via_env(self, monkeypatch):
        monkeypatch.setenv("NOTI_ENABLED", "0")
        cfg = NotiConfig()
        assert cfg.enabled is False

    def test_complete_on_close_default_true(self):
        cfg = NotiConfig()
        assert cfg.complete_on_close is True


class TestNotiConfigValidation:
    def test_validate_passes_with_api_key(self):
        cfg = NotiConfig(api_key="nk_test_key")
        cfg.validate()  # Should not raise

    def test_validate_raises_without_api_key(self):
        cfg = NotiConfig(api_key=None)
        with pytest.raises(ValueError, match="API key"):
            cfg.validate()

    def test_validate_skips_when_disabled(self):
        cfg = NotiConfig(api_key=None, enabled=False)
        cfg.validate()  # Should not raise

    def test_validate_requires_key_not_empty_string(self):
        cfg = NotiConfig(api_key="")
        with pytest.raises(ValueError, match="API key"):
            cfg.validate()
