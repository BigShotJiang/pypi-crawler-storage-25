# notiboard

`notiboard` is both the PyPI distribution name and the Python import package.

Monitor your AI training on your phone with a drop-in replacement for TensorBoard's `SummaryWriter`.

## Installation

```bash
pip install notiboard
```

## Quick Start

```python
from notiboard import NotiWriter

writer = NotiWriter(
    log_dir="runs/experiment1",
    noti_api_key="nk_your_key_here",   # from the Noti app: Settings > API Keys
    noti_project="my-project",
    noti_run_name="experiment-001",    # optional, auto-generated if not set
)

for step in range(1000):
    loss = train_step()
    writer.add_scalar("loss/train", loss, step)
    writer.set_progress(step, 1000, f"Step {step}/1000")

writer.send_notification("Training complete", "Final loss: 0.001", "Done.")
writer.close()
```

All standard TensorBoard `SummaryWriter` methods are preserved. If PyTorch is installed,
`NotiWriter` uses `torch.utils.tensorboard`. Otherwise it falls back to `tensorboardX`,
which is included as a package dependency.

## Configuration

| Argument | Env Variable | Default | Description |
|---|---|---|---|
| `noti_api_key` | `NOTI_API_KEY` | — | API key from the Noti app (required) |
| `noti_server` | `NOTI_SERVER` | `https://notiapi.tech-webs.com` | Noti server URL |
| `noti_project` | — | `"default"` | Project name |
| `noti_run_name` | — | Auto-generated | Run name |
| `noti_enabled` | `NOTI_ENABLED` | `1` | Set `0` to disable Noti sync |
| `noti_complete_on_close` | — | `True` | Mark the run as completed when `close()` is called |

## Release Files

This package is configured for standard PyPI release tooling:

```bash
python -m build
python -m twine check dist/*
python -m twine upload dist/*
```

There are helper scripts under `sdk/scripts/` and a release checklist in `sdk/RELEASING.md`.

## License

MIT
