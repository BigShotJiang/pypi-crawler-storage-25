"""
HTTP client for communicating with the Noti server.

Runs a background daemon thread with an internal queue.
All public enqueue_* methods are thread-safe and non-blocking from the caller.

Reliability guarantees:
- Failed batches are retried with exponential backoff (up to max_retries).
- If a batch ultimately fails, it is dropped and a warning is logged.
  (Persistent disk-based queue is out of scope for v0.1.)
- close() / flush_and_close() waits up to close_timeout for in-flight uploads.
"""

from __future__ import annotations

import logging
import queue
import threading
import time
from typing import Any

import httpx

from notiboard.config import NotiConfig

logger = logging.getLogger("noti")

# Sentinel to tell the background thread to exit after draining the queue.
_STOP = object()


class NotiClient:
    """
    Manages HTTP communication with the Noti server.

    Architecture:
      caller → enqueue_* → _queue → background thread → _flush() → HTTP POST
    """

    def __init__(self, config: NotiConfig, run_id: str) -> None:
        self._config = config
        self._run_id = run_id

        # Items are dicts with a 'type' key; _STOP is used as a stop sentinel.
        self._queue: queue.Queue[Any] = queue.Queue()

        # Pending progress update — only the latest value matters.
        # Written by the caller thread, read+cleared by the background thread.
        self._pending_progress: tuple[int, int, str | None] | None = None
        self._progress_lock = threading.Lock()

        self._http = httpx.Client(
            base_url=config.server_url,
            headers={"X-Noti-Key": config.api_key or ""},
            timeout=config.request_timeout,
        )
        self._thread = threading.Thread(
            target=self._flush_loop, daemon=True, name="noti-uploader"
        )
        self._thread.start()

    # ─── Public API ──────────────────────────────────────────────────────────

    def enqueue_scalar(
        self, tag: str, step: int, value: float, wall_time: float | None = None
    ) -> None:
        self._queue.put_nowait(
            {"type": "scalar", "tag": tag, "step": step, "value": value, "wall_time": wall_time}
        )
        self._maybe_flush()

    def enqueue_histogram(
        self, tag: str, step: int, histogram_data: dict[str, Any]
    ) -> None:
        self._queue.put_nowait(
            {"type": "histogram", "tag": tag, "step": step, **histogram_data}
        )
        self._maybe_flush()

    def enqueue_text(
        self, tag: str, step: int, content: str, wall_time: float | None = None
    ) -> None:
        self._queue.put_nowait(
            {"type": "text", "tag": tag, "step": step, "content": content, "wall_time": wall_time}
        )
        self._maybe_flush()

    def send_progress(
        self, current_step: int, total_steps: int, message: str | None = None
    ) -> None:
        """Buffer a progress update; the background thread sends it every flush_interval seconds.

        Only the most recent value is kept — intermediate calls within the same
        flush window are silently superseded, reducing server load from N calls/s
        down to 1 call per flush_interval (default 5 s).
        """
        with self._progress_lock:
            self._pending_progress = (current_step, total_steps, message)

    def _flush_progress(self) -> None:
        """Send the buffered progress update (if any) to the server."""
        with self._progress_lock:
            pending = self._pending_progress
            self._pending_progress = None
        if pending is None:
            return
        current_step, total_steps, message = pending
        try:
            resp = self._http.put(
                f"/api/v1/progress/{self._run_id}",
                json={
                    "current_step": current_step,
                    "total_steps": total_steps,
                    "message": message,
                },
            )
            resp.raise_for_status()
        except Exception as exc:
            logger.warning("Noti: failed to send progress update: %s", exc)

    def send_notification(
        self,
        title: str,
        preview: str,
        content: str,
        notification_type: str = "info",
    ) -> None:
        """Synchronously send a push notification and store it in the inbox."""
        try:
            resp = self._http.post(
                "/api/v1/notifications",
                json={
                    "title": title,
                    "preview": preview,
                    "content": content,
                    "run_id": self._run_id,
                    "notification_type": notification_type,
                },
            )
            resp.raise_for_status()
        except Exception as exc:
            logger.warning("Noti: failed to send notification: %s", exc)

    def send_error(self, title: str, preview: str | None = None, content: str | None = None) -> None:
        """Send an error/exception notification (red ❌ indicator in the inbox)."""
        self.send_notification(
            title=title,
            preview=preview or title,
            content=content or title,
            notification_type="error",
        )

    def send_alert(self, title: str, preview: str | None = None, content: str | None = None) -> None:
        """Send a milestone/alert notification (yellow ⚡ indicator in the inbox)."""
        self.send_notification(
            title=title,
            preview=preview or title,
            content=content or title,
            notification_type="alert",
        )

    def upload_image(
        self,
        tag: str,
        step: int,
        image_bytes: bytes,
        *,
        width: int,
        height: int,
        fmt: str = "PNG",
        wall_time: float | None = None,
    ) -> None:
        """
        Upload a single image to the Noti server (synchronous, fires immediately).

        Args:
            tag: Metric tag name.
            step: Training step.
            image_bytes: Raw image bytes (PNG or JPEG).
            width: Image width in pixels.
            height: Image height in pixels.
            fmt: Image format string, e.g. "PNG" or "JPEG".
            wall_time: Optional epoch timestamp.
        """
        ext = fmt.lower()
        content_type = f"image/{'jpeg' if ext in ('jpg', 'jpeg') else ext}"
        try:
            resp = self._http.post(
                "/api/v1/metrics/images/upload",
                data={
                    "run_id": self._run_id,
                    "tag": tag,
                    "step": step,
                    "wall_time": wall_time,
                    "width": width,
                    "height": height,
                    "format": fmt.upper(),
                },
                files={"file": (f"{step}.{ext}", image_bytes, content_type)},
            )
            if resp.status_code == 401:
                logger.warning("Noti: image upload rejected (401). Check API key.")
                return
            resp.raise_for_status()
        except Exception as exc:
            logger.warning("Noti: failed to upload image '%s' step %d: %s", tag, step, exc)

    def mark_run_status(self, status: str) -> None:
        """
        Update the run status on the server.

        Args:
            status: One of 'running', 'completed', 'failed', 'stopped'.
        """
        try:
            resp = self._http.patch(
                f"/api/v1/runs/{self._run_id}/status",
                json={"status": status},
            )
            resp.raise_for_status()
            logger.info("Noti: run %s marked as %s", self._run_id, status)
        except Exception as exc:
            logger.warning("Noti: failed to mark run status '%s': %s", status, exc)

    def flush_and_close(self, complete_on_close: bool = True) -> None:
        """
        Flush all pending metrics, optionally mark the run as completed, then close.

        Blocks up to config.close_timeout seconds for in-flight uploads to finish.
        """
        # Enqueue sentinel so the background thread exits after draining
        self._queue.put(_STOP)
        self._thread.join(timeout=self._config.close_timeout)
        if self._thread.is_alive():
            logger.warning(
                "Noti: background upload thread did not finish within %ss. "
                "Some metrics may have been dropped.",
                self._config.close_timeout,
            )

        if complete_on_close:
            self.mark_run_status("completed")

        self._http.close()

    # ─── Internal ────────────────────────────────────────────────────────────

    def _maybe_flush(self) -> None:
        """Trigger an immediate flush if the queue has reached batch_size."""
        if self._queue.qsize() >= self._config.batch_size:
            # Signal flush by waking the thread (it drains on each wake)
            self._flush_now()

    def _flush_loop(self) -> None:
        """Background thread: flush every flush_interval seconds, or on stop."""
        while True:
            try:
                # Wait up to flush_interval for something to appear in the queue
                item = self._queue.get(timeout=self._config.flush_interval)
            except queue.Empty:
                # Periodic flush — metrics and progress together
                self._flush_batch_from_queue()
                self._flush_progress()
                continue

            if item is _STOP:
                # Drain remaining items then exit
                self._flush_batch_from_queue()
                self._flush_progress()
                break

            # Put the item back (we peeked) and flush everything
            self._queue.put(item)
            self._flush_batch_from_queue()
            self._flush_progress()

    def _flush_batch_from_queue(self) -> None:
        """Drain all items currently in the queue and POST them as one batch."""
        scalars: list[dict[str, Any]] = []
        histograms: list[dict[str, Any]] = []
        texts: list[dict[str, Any]] = []

        while True:
            try:
                item = self._queue.get_nowait()
            except queue.Empty:
                break
            if item is _STOP:
                # Re-enqueue the stop sentinel so the caller's join() still works
                self._queue.put(_STOP)
                break
            item_type = item.pop("type", None)
            if item_type == "scalar":
                scalars.append(item)
            elif item_type == "histogram":
                histograms.append(item)
            elif item_type == "text":
                texts.append(item)

        if not scalars and not histograms and not texts:
            return

        payload = {
            "run_id": self._run_id,
            "scalars": scalars,
            "histograms": histograms,
            "texts": texts,
        }
        self._post_with_retry("/api/v1/metrics/batch", payload, scalars + histograms + texts)

    def _post_with_retry(
        self, path: str, payload: dict[str, Any], original_items: list[dict[str, Any]]
    ) -> None:
        """POST with exponential backoff. Re-enqueues items if all retries fail."""
        for attempt in range(self._config.max_retries):
            try:
                resp = self._http.post(path, json=payload)
                if resp.status_code == 401:
                    logger.warning(
                        "Noti: authentication failed (401). Check your API key. Metrics dropped."
                    )
                    return
                resp.raise_for_status()
                return
            except httpx.HTTPStatusError as exc:
                if exc.response.status_code < 500:
                    # 4xx (other than 401) → don't retry
                    logger.warning(
                        "Noti: server rejected batch (HTTP %d). Metrics dropped.",
                        exc.response.status_code,
                    )
                    return
                wait = min(2**attempt, 30)
                logger.debug(
                    "Noti: upload attempt %d/%d failed (HTTP %d), retrying in %ds",
                    attempt + 1, self._config.max_retries, exc.response.status_code, wait,
                )
            except Exception as exc:
                wait = min(2**attempt, 30)
                logger.debug(
                    "Noti: upload attempt %d/%d failed (%s), retrying in %ds",
                    attempt + 1, self._config.max_retries, exc, wait,
                )
            if attempt < self._config.max_retries - 1:
                time.sleep(wait)

        total = len(original_items)
        logger.warning(
            "Noti: failed to upload %d item(s) after %d attempts. Data dropped.",
            total,
            self._config.max_retries,
        )

    # Compatibility alias for callers that call _flush_now directly
    def _flush_now(self) -> None:
        pass  # Flush is handled lazily by the background thread on next cycle
