"""
notiboard - Monitor AI training on your phone.

Drop-in replacement for TensorBoard's SummaryWriter with Noti server sync.

Quick start:
    from notiboard import NotiWriter

    writer = NotiWriter(
        log_dir="runs/experiment1",
        noti_api_key="nk_your_key_here",       # from the Noti app
        noti_project="my-project",
        noti_run_name="experiment-001",         # optional
    )

    for step in range(1000):
        loss = train_step()
        writer.add_scalar("loss/train", loss, step)
        writer.set_progress(step, 1000, f"Step {step}/1000")

    writer.send_notification(
        title="Training Complete",
        preview="Loss: 0.001",
        content="Training finished after 1000 steps. Final loss: 0.001",
    )
    writer.close()
"""

from notiboard.config import NotiConfig
from notiboard.writer import NotiWriter

__all__ = ["NotiWriter", "NotiConfig"]
__version__ = "0.1.0"
