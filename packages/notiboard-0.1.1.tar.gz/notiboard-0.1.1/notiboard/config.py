"""Configuration management for the Noti SDK."""

from __future__ import annotations

import os
from dataclasses import dataclass, field

#: Default server URL — can be overridden by NOTI_SERVER env var or constructor arg.
DEFAULT_SERVER_URL = "https://notiapi.tech-webs.com"


@dataclass
class NotiConfig:
    """
    Holds all configuration for a NotiWriter instance.

    Priority: constructor argument > environment variable > built-in default.
    """

    #: Noti server base URL. Defaults to NOTI_SERVER env var or the official server.
    server_url: str = field(
        default_factory=lambda: os.getenv("NOTI_SERVER", DEFAULT_SERVER_URL)
    )

    #: Your Noti API key (starts with 'nk_'). Shown once when created in the app.
    api_key: str | None = field(default_factory=lambda: os.getenv("NOTI_API_KEY"))

    #: Project name. Creates the project if it doesn't exist.
    project: str = "default"

    #: Run name. Auto-generated timestamp-based name if not provided.
    run_name: str | None = None

    #: Set False to disable Noti sync (TensorBoard still works normally).
    enabled: bool = field(
        default_factory=lambda: os.getenv("NOTI_ENABLED", "1") != "0"
    )

    #: Automatically mark the run as 'completed' when writer.close() is called.
    complete_on_close: bool = True

    #: Number of metrics to buffer before triggering an immediate upload.
    batch_size: int = 100

    #: Seconds between automatic batch uploads.
    flush_interval: float = 5.0

    #: Maximum attempts for each failed upload before the batch is dropped.
    max_retries: int = 5

    #: Timeout (seconds) for HTTP requests to the Noti server.
    request_timeout: float = 10.0

    #: Maximum seconds to wait for in-flight uploads when close() is called.
    close_timeout: float = 30.0

    def validate(self) -> None:
        """Raise ValueError if required fields are missing when Noti is enabled."""
        if not self.enabled:
            return
        if not self.api_key:
            raise ValueError(
                "Noti API key is required. Pass noti_api_key= or set the NOTI_API_KEY "
                "environment variable. Create an API key in the Noti app under Settings > API Keys."
            )
