"""
NotiWriter — drop-in replacement for torch.utils.tensorboard.SummaryWriter.

All original TensorBoard methods are preserved and work identically.
Metric data is also asynchronously mirrored to the Noti server.
"""

from __future__ import annotations

import datetime
import logging
import time
from typing import Any

from notiboard.client import NotiClient
from notiboard.config import NotiConfig

logger = logging.getLogger("noti")


class NotiWriter:
    """
    A drop-in replacement for TensorBoard's SummaryWriter that also syncs data
    to the Noti server for mobile viewing.

    Usage:
        from notiboard import NotiWriter

        writer = NotiWriter(
            log_dir="runs/exp1",
            noti_api_key="nk_your_key_here",
            noti_project="my-project",
            noti_run_name="experiment-001",    # optional
        )

        for step in range(1000):
            writer.add_scalar("loss/train", loss, step)
            writer.set_progress(step, 1000)

        writer.send_notification("Done!", "loss=0.001", "Training complete.")
        writer.close()  # marks run as completed and flushes remaining metrics

    All keyword arguments not listed below are forwarded to SummaryWriter.
    """

    def __init__(
        self,
        log_dir: str | None = None,
        *,
        noti_api_key: str | None = None,
        noti_server: str | None = None,
        noti_project: str = "default",
        noti_run_name: str | None = None,
        noti_enabled: bool = True,
        noti_complete_on_close: bool = True,
        **kwargs: Any,
    ) -> None:
        # ─── Build config ─────────────────────────────────────────────────
        self._config = NotiConfig(
            api_key=noti_api_key,
            server_url=noti_server or NotiConfig.__dataclass_fields__["server_url"].default_factory(),  # type: ignore[attr-defined]
            project=noti_project,
            run_name=noti_run_name,
            enabled=noti_enabled,
            complete_on_close=noti_complete_on_close,
        )

        # ─── Initialize TensorBoard SummaryWriter ─────────────────────────
        try:
            from torch.utils.tensorboard import SummaryWriter as _TorchWriter
            self._tb: Any = _TorchWriter(log_dir=log_dir, **kwargs)
        except ImportError:
            try:
                from tensorboardX import SummaryWriter as _TXWriter  # type: ignore[import]
                self._tb = _TXWriter(log_dir=log_dir, **kwargs)
            except ImportError as exc:
                raise ImportError(
                    "NotiWriter requires either 'torch' (PyTorch) or 'tensorboardX'. "
                    "Install with: pip install torch  OR  pip install tensorboardX"
                ) from exc

        # ─── Initialize Noti client ───────────────────────────────────────
        self._client: NotiClient | None = None
        self._run_id: str | None = None

        if self._config.enabled:
            try:
                self._config.validate()
                self._run_id = self._create_run()
                if self._run_id:
                    self._client = NotiClient(self._config, self._run_id)
                    logger.info(
                        "Noti: syncing to %s (run=%s, project=%s)",
                        self._config.server_url,
                        self._run_id,
                        self._config.project,
                    )
            except Exception as exc:
                logger.warning(
                    "Noti: failed to initialize — %s. Falling back to TensorBoard only.", exc
                )

    # ─── Noti-specific methods ────────────────────────────────────────────

    @property
    def run_id(self) -> str | None:
        """The Noti server run ID for this writer, or None if Noti is disabled."""
        return self._run_id

    def set_progress(
        self,
        current_step: int,
        total_steps: int,
        message: str | None = None,
    ) -> None:
        """
        Update the training progress bar in the Noti app.

        Args:
            current_step: Current training step (0-indexed is fine).
            total_steps: Total number of training steps.
            message: Optional status message, e.g. "Epoch 3/10".
        """
        if self._client:
            self._client.send_progress(current_step, total_steps, message)

    def send_notification(
        self,
        title: str,
        preview: str | None = None,
        content: str | None = None,
    ) -> None:
        """
        Send a push notification to the user's Noti app and store in inbox.

        Args:
            title: Notification title (required).
            preview: Short summary shown in the notification banner.
            content: Full notification body shown in the inbox detail view.
        """
        if self._client:
            self._client.send_notification(
                title=title,
                preview=preview or title,
                content=content or title,
            )

    def send_error(
        self,
        title: str,
        preview: str | None = None,
        content: str | None = None,
    ) -> None:
        """
        Send an error/exception notification (displayed with a red ❌ badge).

        Use this when training crashes, a NaN/Inf is detected, or an exception
        occurs during training that the user should be aware of immediately.

        Args:
            title:   Short error summary, e.g. "Training crashed — CUDA OOM".
            preview: One-line description shown in the notification banner.
            content: Full error detail (stack trace, error message, etc.).
        """
        if self._client:
            self._client.send_error(
                title=title,
                preview=preview,
                content=content,
            )

    def send_alert(
        self,
        title: str,
        preview: str | None = None,
        content: str | None = None,
    ) -> None:
        """
        Send a milestone / best-result alert (displayed with a yellow ⚡ badge).

        Use this when the model achieves a new best validation score, a
        checkpoint is saved, or any positive milestone you want highlighted.

        Args:
            title:   Short summary, e.g. "New best val accuracy: 94.3%".
            preview: One-line description shown in the notification banner.
            content: Full detail (metrics, epoch number, checkpoint path, etc.).
        """
        if self._client:
            self._client.send_alert(
                title=title,
                preview=preview,
                content=content,
            )

    def mark_completed(self) -> None:
        """Explicitly mark this run as completed on the Noti server."""
        if self._client:
            self._client.mark_run_status("completed")

    def mark_failed(self, message: str | None = None) -> None:
        """
        Mark this run as failed on the Noti server.

        Args:
            message: Optional failure description sent as a notification.
        """
        if self._client:
            self._client.mark_run_status("failed")
            if message:
                self._client.send_notification(
                    title="Run Failed",
                    preview=message[:100],
                    content=message,
                )

    def mark_stopped(self) -> None:
        """Mark this run as stopped (interrupted) on the Noti server."""
        if self._client:
            self._client.mark_run_status("stopped")

    # ─── TensorBoard method overrides ────────────────────────────────────

    def add_scalar(
        self,
        tag: str,
        scalar_value: float,
        global_step: int | None = None,
        walltime: float | None = None,
        new_style: bool = False,
        double_precision: bool = False,
    ) -> None:
        # PyTorch SummaryWriter supports new_style/double_precision;
        # tensorboardX does not — fall back gracefully.
        try:
            self._tb.add_scalar(
                tag,
                scalar_value,
                global_step=global_step,
                walltime=walltime,
                new_style=new_style,
                double_precision=double_precision,
            )
        except TypeError:
            self._tb.add_scalar(
                tag,
                scalar_value,
                global_step=global_step,
                walltime=walltime,
            )
        if self._client and global_step is not None:
            self._client.enqueue_scalar(
                tag=tag,
                step=global_step,
                value=float(scalar_value),
                wall_time=walltime or time.time(),
            )

    def add_scalars(
        self,
        main_tag: str,
        tag_scalar_dict: dict[str, float],
        global_step: int | None = None,
        walltime: float | None = None,
    ) -> None:
        self._tb.add_scalars(
            main_tag, tag_scalar_dict, global_step=global_step, walltime=walltime
        )
        if self._client and global_step is not None:
            wt = walltime or time.time()
            for sub_tag, value in tag_scalar_dict.items():
                self._client.enqueue_scalar(
                    tag=f"{main_tag}/{sub_tag}",
                    step=global_step,
                    value=float(value),
                    wall_time=wt,
                )

    def add_histogram(
        self,
        tag: str,
        values: Any,
        global_step: int | None = None,
        bins: str = "tensorflow",
        walltime: float | None = None,
        max_bins: int | None = None,
    ) -> None:
        self._tb.add_histogram(
            tag, values, global_step=global_step, bins=bins,
            walltime=walltime, max_bins=max_bins,
        )
        if self._client and global_step is not None:
            try:
                import numpy as np

                arr = np.asarray(values, dtype=float).flatten()
                num_bins = min(max_bins or 30, 30)
                hist, edges = np.histogram(arr, bins=num_bins)
                self._client.enqueue_histogram(
                    tag=tag,
                    step=global_step,
                    histogram_data={
                        "min": float(arr.min()),
                        "max": float(arr.max()),
                        "num": int(arr.size),
                        "sum": float(arr.sum()),
                        "sum_squares": float((arr**2).sum()),
                        "bucket_limits": edges.tolist(),
                        "bucket_counts": hist.tolist(),
                        "wall_time": walltime or time.time(),
                    },
                )
            except Exception as exc:
                logger.debug("Noti: failed to serialize histogram '%s': %s", tag, exc)

    def add_text(
        self,
        tag: str,
        text_string: str,
        global_step: int | None = None,
        walltime: float | None = None,
    ) -> None:
        self._tb.add_text(tag, text_string, global_step=global_step, walltime=walltime)
        if self._client and global_step is not None:
            self._client.enqueue_text(
                tag=tag,
                step=global_step,
                content=text_string,
                wall_time=walltime or time.time(),
            )

    def add_image(
        self,
        tag: str,
        img_tensor: Any,
        global_step: int | None = None,
        walltime: float | None = None,
        dataformats: str = "CHW",
    ) -> None:
        self._tb.add_image(
            tag,
            img_tensor,
            global_step=global_step,
            walltime=walltime,
            dataformats=dataformats,
        )
        if self._client and global_step is not None:
            try:
                import io as _io

                import numpy as np

                arr = np.asarray(img_tensor)
                # Normalise layout to HWC
                if dataformats.upper() == "CHW":
                    arr = np.transpose(arr, (1, 2, 0))
                elif dataformats.upper() == "HW":
                    arr = arr[:, :, None]  # grayscale → HW1

                # Scale to uint8 if float
                if arr.dtype != np.uint8:
                    arr = (np.clip(arr, 0, 1) * 255).astype(np.uint8)

                # Encode as PNG via PIL
                from PIL import Image as _PIL

                h, w = arr.shape[:2]
                mode = "RGB" if arr.ndim == 3 and arr.shape[2] == 3 else (
                    "RGBA" if arr.ndim == 3 and arr.shape[2] == 4 else "L"
                )
                pil_img = _PIL.fromarray(
                    arr.squeeze() if mode == "L" else arr, mode
                )
                buf = _io.BytesIO()
                pil_img.save(buf, format="PNG")
                buf.seek(0)

                self._client.upload_image(
                    tag=tag,
                    step=global_step,
                    image_bytes=buf.read(),
                    width=w,
                    height=h,
                    fmt="PNG",
                    wall_time=walltime or time.time(),
                )
            except Exception as exc:
                logger.debug(
                    "Noti: failed to upload image '%s' step %d: %s", tag, global_step, exc
                )

    def add_images(self, *args: Any, **kwargs: Any) -> None:
        self._tb.add_images(*args, **kwargs)

    def add_figure(self, *args: Any, **kwargs: Any) -> None:
        self._tb.add_figure(*args, **kwargs)

    def add_graph(self, *args: Any, **kwargs: Any) -> None:
        self._tb.add_graph(*args, **kwargs)

    def add_embedding(self, *args: Any, **kwargs: Any) -> None:
        self._tb.add_embedding(*args, **kwargs)

    def add_pr_curve(self, *args: Any, **kwargs: Any) -> None:
        self._tb.add_pr_curve(*args, **kwargs)

    def add_custom_scalars(self, *args: Any, **kwargs: Any) -> None:
        self._tb.add_custom_scalars(*args, **kwargs)

    def add_mesh(self, *args: Any, **kwargs: Any) -> None:
        self._tb.add_mesh(*args, **kwargs)

    def add_hparams(self, *args: Any, **kwargs: Any) -> None:
        self._tb.add_hparams(*args, **kwargs)

    def flush(self) -> None:
        self._tb.flush()

    def close(self) -> None:
        """Flush remaining queued metrics, optionally mark run as completed, then close."""
        if self._client:
            self._client.flush_and_close(
                complete_on_close=self._config.complete_on_close
            )
        self._tb.close()

    def __enter__(self) -> NotiWriter:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if exc_type is not None:
            # Exception in the `with` block → mark as failed
            self._config.complete_on_close = False  # Don't mark completed
            if self._client:
                self._client.mark_run_status("failed")
        self.close()

    # ─── Helpers ─────────────────────────────────────────────────────────

    def _create_run(self) -> str | None:
        """Call POST /api/v1/runs to register the run; return the run_id."""
        import httpx as _httpx

        run_name = (
            self._config.run_name
            or datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        )
        try:
            resp = _httpx.post(
                f"{self._config.server_url}/api/v1/runs",
                headers={"X-Noti-Key": self._config.api_key or ""},
                json={
                    "project_name": self._config.project,
                    "run_name": run_name,
                    "config": None,
                },
                timeout=self._config.request_timeout,
            )
            if resp.status_code == 401:
                raise PermissionError(
                    "Invalid API key (401). Check your noti_api_key= value or "
                    "the NOTI_API_KEY environment variable."
                )
            resp.raise_for_status()
            return resp.json()["data"]["id"]
        except PermissionError:
            raise
        except Exception as exc:
            logger.warning("Noti: failed to create run on server: %s", exc)
            return None
