"""
SIWX (Sign-In-With-X) authentication for ChainStream API.

Standard authentication using EIP-4361 (SIWE for EVM, SIWS for Solana).
Sign once, reuse token for 1 hour. Replaces legacy X-Wallet-* headers.
"""

import base64
import secrets
import time
import threading
from datetime import datetime, timezone, timedelta
from typing import Optional, Tuple

from .wallet_auth import WalletSigner

SIWX_DOMAIN = "api.chainstream.io"
SIWX_URI = "https://api.chainstream.io"
SIWX_VERSION = "1"
DEFAULT_CHAIN_ID = "8453"
DEFAULT_EXPIRES_IN_SECONDS = 3600
REFRESH_BEFORE_SECONDS = 60


def build_siwx_message(
    address: str,
    chain: str,
    nonce: str,
    issued_at: datetime,
    expires_at: datetime,
) -> str:
    """Build an EIP-4361 (SIWE/SIWS) formatted message."""
    chain_label = "Solana" if chain == "solana" else "Ethereum"
    chain_id = "mainnet" if chain == "solana" else DEFAULT_CHAIN_ID

    return (
        f"{SIWX_DOMAIN} wants you to sign in with your {chain_label} account:\n"
        f"{address}\n"
        f"\n"
        f"Sign in to ChainStream API\n"
        f"\n"
        f"URI: {SIWX_URI}\n"
        f"Version: {SIWX_VERSION}\n"
        f"Chain ID: {chain_id}\n"
        f"Nonce: {nonce}\n"
        f"Issued At: {issued_at.isoformat()}\n"
        f"Expiration Time: {expires_at.isoformat()}"
    )


async def create_siwx_token(
    signer: WalletSigner,
    expires_in_seconds: int = DEFAULT_EXPIRES_IN_SECONDS,
) -> Tuple[str, datetime]:
    """Create a SIWX token: base64(message).signature"""
    nonce = secrets.token_hex(16)
    issued_at = datetime.now(timezone.utc)
    expires_at = issued_at + timedelta(seconds=expires_in_seconds)

    message = build_siwx_message(signer.address, signer.chain, nonce, issued_at, expires_at)
    signature = await signer.sign_message(message)

    message_b64 = base64.b64encode(message.encode()).decode()
    token = f"{message_b64}.{signature}"
    return token, expires_at


class SiwxTokenCache:
    """Thread-safe SIWX token cache with automatic refresh."""

    def __init__(self, signer: WalletSigner):
        self._signer = signer
        self._token: Optional[str] = None
        self._expires_at: Optional[datetime] = None
        self._lock = threading.Lock()

    async def get_token(self) -> str:
        with self._lock:
            now = datetime.now(timezone.utc)
            if self._token and self._expires_at:
                refresh_threshold = self._expires_at - timedelta(seconds=REFRESH_BEFORE_SECONDS)
                if now < refresh_threshold:
                    return self._token

        token, expires_at = await create_siwx_token(self._signer)
        with self._lock:
            self._token = token
            self._expires_at = expires_at
        return token

    def clear(self):
        with self._lock:
            self._token = None
            self._expires_at = None
