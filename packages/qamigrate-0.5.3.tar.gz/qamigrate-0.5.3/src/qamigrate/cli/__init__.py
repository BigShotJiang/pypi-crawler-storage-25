"""CLI module for QAMigrate."""

from qamigrate.cli.main import app

__all__ = ["app"]
