"""
LLM-related exceptions.

Agents catch these by base class when they need to react to an LLM
failure; concrete providers raise specific subclasses so users get
actionable error messages (especially for "Ollama isn't running",
"ANTHROPIC_API_KEY missing", etc.).
"""

from __future__ import annotations


class LLMError(Exception):
    """Base class for all LLM provider errors."""


class LLMConfigError(LLMError):
    """Raised when a provider is misconfigured (missing API key, bad URL...).

    Should be raised eagerly, ideally during `build_provider()` rather than
    at the first `generate_structured()` call, so users find out before the
    pipeline spends time on generation.
    """


class LLMUnavailable(LLMError):
    """Raised when the provider's service can't be reached.

    Wraps connection errors from underlying SDKs so callers can catch a
    single type regardless of which provider failed.
    """


class LLMMalformedOutput(LLMError):
    """Raised when the provider returned something that doesn't match the tool schema.

    Providers should retry once internally before raising this -- agents
    should treat it as fatal for a single file but not the whole run.
    """

    def __init__(self, message: str, raw_text: str | None = None) -> None:
        super().__init__(message)
        self.raw_text = raw_text
