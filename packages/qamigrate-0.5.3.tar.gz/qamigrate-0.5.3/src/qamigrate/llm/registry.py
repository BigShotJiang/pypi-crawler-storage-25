"""
Provider registry.

Maps short provider names (as used in config files and `--provider` CLI
flags) to provider classes. Agents and config code look providers up
through this registry so there's exactly one place to register a new one.
"""

from __future__ import annotations

from typing import Callable

from qamigrate.llm.base import LLMProvider
from qamigrate.llm.errors import LLMConfigError


# Provider factories. Each returns a ready-to-use LLMProvider.
# We store factories (not classes) so providers that need non-standard
# construction (e.g. OpenAI with base_url overrides) can still register.
_ProviderFactory = Callable[..., LLMProvider]

_PROVIDERS: dict[str, _ProviderFactory] = {}


def register_provider(name: str, factory: _ProviderFactory) -> None:
    """Register a provider factory under a short name."""
    _PROVIDERS[name] = factory


def get_provider_factory(name: str) -> _ProviderFactory:
    """Look up a provider factory. Raises LLMConfigError if unknown."""
    factory = _PROVIDERS.get(name)
    if factory is None:
        known = ", ".join(sorted(_PROVIDERS.keys())) or "(none registered)"
        raise LLMConfigError(
            f"Unknown LLM provider {name!r}. Known: {known}."
        )
    return factory


def list_providers() -> list[str]:
    """All registered provider names, sorted alphabetically."""
    return sorted(_PROVIDERS.keys())


# Register the built-in providers at import time. We wrap each class
# constructor in a lazy factory that only imports the SDK when the
# provider is actually used -- that way importing qamigrate doesn't
# fail when the openai package isn't installed but the user only uses
# Anthropic.
def _register_builtins() -> None:
    def _make_anthropic(**kwargs):
        from qamigrate.llm.providers.anthropic import AnthropicProvider
        return AnthropicProvider(**kwargs)

    def _make_openai(**kwargs):
        from qamigrate.llm.providers.openai import OpenAIProvider
        return OpenAIProvider(**kwargs)

    register_provider("anthropic", _make_anthropic)
    register_provider("openai", _make_openai)


_register_builtins()
