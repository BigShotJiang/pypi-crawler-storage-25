"""
Build a provider from a QAMigrateConfig + agent name.

This is the one place that knows how to translate the user's YAML
config into a concrete LLMProvider. Agents call this indirectly via
`pipeline.run_migration` / `run_project_migration`; they never import
SDKs directly.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from qamigrate.llm.base import LLMProvider
from qamigrate.llm.errors import LLMConfigError
from qamigrate.llm.registry import get_provider_factory

if TYPE_CHECKING:
    from qamigrate.core.config import QAMigrateConfig


def build_provider_for_agent(config: "QAMigrateConfig", agent: str) -> LLMProvider:
    """
    Construct the LLMProvider for a specific agent ("coder" or "fixer").

    Reads both the agent-level config (provider + model) and the
    provider-level config (api_key_env, base_url, host) and merges them
    into the right kwargs for the provider factory.

    Raises:
        LLMConfigError: agent name unknown, provider unknown, or provider
            misconfigured (e.g. missing API key).
    """
    if agent == "coder":
        agent_cfg = config.coder
    elif agent == "fixer":
        agent_cfg = config.fixer
    else:
        raise LLMConfigError(f"Unknown agent name: {agent!r}")

    provider_name = getattr(agent_cfg, "provider", "anthropic")
    model = agent_cfg.model
    kwargs = _provider_kwargs(config, provider_name, model)

    factory = get_provider_factory(provider_name)
    return factory(**kwargs)


def _provider_kwargs(
    config: "QAMigrateConfig",
    provider_name: str,
    model: str,
) -> dict:
    """Translate provider-specific QAMigrateConfig fields into provider kwargs."""
    base: dict = {"model": model}
    providers = config.llm.providers

    if provider_name == "anthropic":
        base["api_key_env"] = providers.anthropic.api_key_env
    elif provider_name == "openai":
        base["api_key_env"] = providers.openai.api_key_env
        if providers.openai.base_url:
            base["base_url"] = providers.openai.base_url
    elif provider_name == "ollama":
        base["host"] = providers.ollama.host
        base["request_timeout_s"] = providers.ollama.request_timeout_s
    # Unknown providers: pass nothing extra. The factory may accept
    # whatever it wants via kwargs, but we only wire the ones we ship.

    return base
