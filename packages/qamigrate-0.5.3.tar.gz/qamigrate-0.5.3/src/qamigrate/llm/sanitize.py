"""
Provider-agnostic cleanup for LLM output quirks.

Every provider can produce the same garbage classes -- we centralize the
fixes here so agents get consistent behavior no matter which LLM ran.

Two quirks covered today:

1. **Double-escaped strings.** Sometimes the JSON-over-tool-use round-trip
   yields strings containing literal backslash-n sequences instead of real
   newlines. We detect this heuristically and unescape.

2. **Stray markdown fences.** Models occasionally wrap code output in
   ```java ... ``` fences despite being told not to. Strip them.
"""

from __future__ import annotations

from typing import Any


def unescape_llm_string(value: Any) -> Any:
    """
    Unescape stray backslash sequences that leak through LLM tool-use output.

    The model sometimes double-escapes string fields: we see literal
    `\\n`, `\\t`, `\\"` instead of real control characters. This helper
    unescapes only when the string contains the two-char sequences *and*
    lacks the corresponding real characters, so clean strings pass
    through untouched.
    """
    if not isinstance(value, str):
        return value

    needs_unescape = False
    if "\\n" in value and "\n" not in value:
        needs_unescape = True
    # \" is never legitimate in generated Java source, so unescape it
    # whenever we see it regardless of whether real quotes are present.
    if '\\"' in value:
        needs_unescape = True

    if not needs_unescape:
        return value

    return (
        value.replace("\\n", "\n")
             .replace("\\t", "\t")
             .replace('\\"', '"')
             .replace("\\'", "'")
    )


def sanitize_fields(data: dict) -> dict:
    """
    Recursively unescape stray backslash sequences in every string leaf
    of a dict. Used on provider-returned tool-use payloads before handing
    them to agent code.
    """
    result: dict = {}
    for k, v in data.items():
        if isinstance(v, str):
            result[k] = unescape_llm_string(v)
        elif isinstance(v, list):
            result[k] = [
                sanitize_fields(item) if isinstance(item, dict)
                else unescape_llm_string(item)
                for item in v
            ]
        elif isinstance(v, dict):
            result[k] = sanitize_fields(v)
        else:
            result[k] = v
    return result


def strip_stray_markdown(text: str) -> str:
    """
    Remove opening/closing ```  or ```java fences from text.

    Used by the Fixer when the model wraps its Java source in a code
    fence despite instructions. Non-destructive: text without fences
    passes through unchanged.
    """
    text = text.strip()
    if text.startswith("```"):
        # Drop the opening fence line entirely
        text = text.split("\n", 1)[1] if "\n" in text else ""
        # Drop the closing fence if present
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-3].rstrip()
    return text


def escape_for_code_fence(source: str) -> str:
    """
    Neutralize backticks in `source` so it can't break out of a markdown
    code-fenced region in an LLM prompt.

    The threat model is NOT attacker-controlled input -- users only
    migrate their own test suites. But a legitimate test file can have
    ``` inside a Java text block (e.g. `String md = "`\u200b``markdown";`),
    which would confuse the model and produce malformed output.

    Fix: replace every run of 3+ backticks with the same count of ` chars
    joined by zero-width spaces. The Java meaning is lost (in a Java text
    block the zero-width space is visible), but since this is only for
    the PROMPT and the model outputs a full rewrite anyway, it doesn't
    leak into the generated Playwright code.

    If the input contains no backtick sequences, returns it unchanged.
    """
    if "```" not in source:
        return source
    # Insert a zero-width space between every pair of backticks to break
    # any run of 3+ backticks without changing the visual length.
    return source.replace("```", "`\u200b`\u200b`")
