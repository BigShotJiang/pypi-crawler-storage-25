"""
LLMProvider abstract base.

QAMigrate only ever asks the LLM for one thing: "read this system + user
prompt, then emit a JSON object matching this tool schema." Every provider
(Anthropic, OpenAI, Ollama, etc.) speaks a different protocol under the
hood, but they all owe us the same thing: a Python dict whose shape
matches the tool's `input_schema`.

Keeping this interface narrow is deliberate. If we ever need "chat",
"streaming", "vision", etc., we add new methods — but `generate_structured`
covers both of our current call sites (Coder and Fixer).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ToolSchema:
    """
    Describes the shape the provider must produce.

    - `name`: the "tool name" in provider parlance. For Anthropic it's the
      `name` field on the tool; for OpenAI it's the function name.
    - `description`: shown to the model so it knows when/why to emit this.
    - `input_schema`: a JSON Schema dict. Providers translate this to
      whatever the underlying SDK expects.
    """

    name: str
    description: str
    input_schema: dict[str, Any]


@dataclass(frozen=True)
class StructuredResponse:
    """
    What every provider returns.

    - `data` is the parsed dict matching the tool's input_schema.
    - `raw_text` is optional — useful for debugging when a response
      violates the schema and we need to see what the model actually said.
    - `provider` / `model` are populated for telemetry and the migration
      report (so users can see which provider/model produced each file).
    """

    data: dict[str, Any]
    raw_text: str | None = None
    provider: str = ""
    model: str = ""
    usage: dict[str, int] = field(default_factory=dict)  # input_tokens, output_tokens, etc.


class LLMProvider(ABC):
    """
    The single contract agents depend on.

    Implementations live under `qamigrate.llm.providers` and are registered
    in `qamigrate.llm.registry.PROVIDERS`. Agents never import a concrete
    provider directly -- they receive one via dependency injection so they
    can be unit-tested with a FakeProvider and credit-free.
    """

    # Canonical short name (e.g. "anthropic", "openai", "ollama").
    # Also used as the dict key in the provider registry.
    name: str = ""

    # Model identifier as the user / config specified it. Kept verbatim so
    # it shows up correctly in logs and the migration report.
    model: str = ""

    # Advisory flag: does this provider have native tool-use / function-
    # calling? Used only for logging and diagnostic messages. Agent code
    # MUST NOT branch on this -- the provider is responsible for producing
    # a valid dict regardless of the underlying mechanism.
    supports_tool_use: bool = False

    @abstractmethod
    def generate_structured(
        self,
        system: str,
        user: str,
        tool: ToolSchema,
        *,
        max_tokens: int = 4096,
        temperature: float = 0.0,
    ) -> StructuredResponse:
        """
        Run the LLM and return a dict matching `tool.input_schema`.

        Concrete providers decide how to honor this:
          - native tool-use with forced `tool_choice` (Anthropic, OpenAI)
          - JSON-mode with the schema embedded in the prompt (Ollama fallback)

        Raises:
          LLMMalformedOutput: the model returned something we can't parse
            as the expected shape, even after provider-level retries.
          LLMUnavailable: the provider service can't be reached.
          LLMConfigError: misconfiguration (missing API key, bad URL, etc.).
        """
        raise NotImplementedError
