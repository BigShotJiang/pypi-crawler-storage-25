"""
Build the project's class-level dependency graph.

We look at each parsed ClassInfo and emit DependencyEdge entries for:

- `extends` / `implements` declarations
- Field types that point at in-project classes
- `new OtherClass(...)` instantiations inside method bodies
- `OtherClass.someStaticMethod(...)` calls inside method bodies

Imports are ALSO emitted as IMPORT edges only when we can't identify a
stronger relationship -- so the graph stays compact but complete.

Scope rule: edges are only emitted for TARGETS that belong to the same
project (`fqn` exists in the classes dict). External calls like
`driver.findElement(...)` or JDK references are ignored -- they're not
architecturally interesting for a migration plan.
"""

from __future__ import annotations

import re

from qamigrate.intelligence.project_map import (
    ClassInfo,
    DependencyEdge,
    DependencyKind,
)


# =====================================================================
# Public API
# =====================================================================


def build_edges(classes: dict[str, ClassInfo]) -> list[DependencyEdge]:
    """Return all dependency edges for the given classes dict.

    Caller ensures `classes` is the FULL set of project classes (so we
    can distinguish in-project targets from external libraries).
    """
    # Index: simple_name -> fqn. When we see `new LoginPage(...)`, we
    # resolve "LoginPage" -> "com.example.pages.LoginPage" by this lookup.
    # If two classes share a simple name we don't know which one is meant
    # without a full import table; fall back to the first one found.
    simple_to_fqn: dict[str, str] = {}
    for fqn, c in classes.items():
        simple_to_fqn.setdefault(c.name, fqn)

    edges: list[DependencyEdge] = []

    for source_fqn, source in classes.items():
        # Collect targets we've already emitted so we don't double-count
        # (e.g. "extends Foo" AND "field type Foo" AND "new Foo()" only
        # need distinct edges when the KIND differs).
        seen: set[tuple[str, DependencyKind, str | None]] = set()

        def emit(target_fqn: str, kind: DependencyKind, symbol: str | None = None) -> None:
            key = (target_fqn, kind, symbol)
            if key in seen:
                return
            seen.add(key)
            edges.append(DependencyEdge(
                source=source_fqn,
                target=target_fqn,
                kind=kind,
                symbol=symbol,
            ))

        _emit_structural_edges(source, simple_to_fqn, emit)
        _emit_field_type_edges(source, simple_to_fqn, emit)
        _emit_method_body_edges(source, simple_to_fqn, emit)
        _emit_import_edges(source, classes, simple_to_fqn, edges, seen)

    return edges


# =====================================================================
# Structural: extends / implements
# =====================================================================


def _emit_structural_edges(
    source: ClassInfo,
    simple_to_fqn: dict[str, str],
    emit,
) -> None:
    if source.extends:
        target_fqn = simple_to_fqn.get(source.extends)
        if target_fqn and target_fqn != source.fqn:
            emit(target_fqn, DependencyKind.EXTENDS)

    for iface in source.implements:
        target_fqn = simple_to_fqn.get(iface)
        if target_fqn and target_fqn != source.fqn:
            emit(target_fqn, DependencyKind.IMPLEMENTS)


# =====================================================================
# Field types
# =====================================================================


def _emit_field_type_edges(
    source: ClassInfo,
    simple_to_fqn: dict[str, str],
    emit,
) -> None:
    for f in source.fields:
        for simple_name in _extract_type_names(f.type):
            target_fqn = simple_to_fqn.get(simple_name)
            if target_fqn and target_fqn != source.fqn:
                emit(target_fqn, DependencyKind.FIELD_TYPE, symbol=f.name)


# Match a Java type identifier. Captures things like:
#   LoginPage
#   List<LoginPage>
#   Map<String, LoginPage>
#   LoginPage[]
# and returns every CamelCase token (very rough but effective for our
# purpose: we then filter by which ones exist as in-project classes).
_TYPE_TOKEN_RE = re.compile(r"\b([A-Z][A-Za-z0-9_]*)\b")


def _extract_type_names(type_str: str) -> list[str]:
    """Return every capitalized identifier inside a type string."""
    return _TYPE_TOKEN_RE.findall(type_str or "")


# =====================================================================
# Method bodies: instantiations + static calls
# =====================================================================


# `new LoginPage(...)` — captures class name
_NEW_RE = re.compile(r"\bnew\s+([A-Z][A-Za-z0-9_]*)\s*\(")

# `SomeClass.methodName(`  — captures class + method
# Heuristic: class starts with uppercase, method lowercase/camelCase.
_STATIC_CALL_RE = re.compile(
    r"\b([A-Z][A-Za-z0-9_]*)\s*\.\s*([a-z_][A-Za-z0-9_]*)\s*\("
)


def _emit_method_body_edges(
    source: ClassInfo,
    simple_to_fqn: dict[str, str],
    emit,
) -> None:
    for m in source.public_methods + source.private_methods:
        body = m.body or ""
        if not body:
            continue

        for name in _NEW_RE.findall(body):
            target_fqn = simple_to_fqn.get(name)
            if target_fqn and target_fqn != source.fqn:
                emit(target_fqn, DependencyKind.INSTANTIATES, symbol=m.name)

        for cls, method_name in _STATIC_CALL_RE.findall(body):
            target_fqn = simple_to_fqn.get(cls)
            if target_fqn and target_fqn != source.fqn:
                emit(target_fqn, DependencyKind.STATIC_CALL, symbol=method_name)


# =====================================================================
# Imports: fallback edges for classes we imported but didn't otherwise reference
# =====================================================================


def _emit_import_edges(
    source: ClassInfo,
    classes: dict[str, ClassInfo],
    simple_to_fqn: dict[str, str],
    edges: list[DependencyEdge],
    seen: set,
) -> None:
    """Emit an IMPORT edge only when we imported an in-project class but
    didn't classify the relationship more specifically.

    This keeps the graph meaningful: imports we already captured as
    EXTENDS / INSTANTIATES / STATIC_CALL don't show up as duplicate IMPORT
    edges.
    """
    # Gather all "better" targets already emitted FOR THIS SOURCE
    already_related = {
        e.target
        for e in edges
        if e.source == source.fqn
    }

    for imp in source.imports:
        # Imports come as the full FQN string, e.g.
        # "com.qastarter.utils.Log" or "java.util.List".
        imp_stripped = imp.strip().rstrip(";")
        if imp_stripped in classes and imp_stripped != source.fqn:
            if imp_stripped not in already_related:
                key = (imp_stripped, DependencyKind.IMPORT, None)
                if key not in seen:
                    seen.add(key)
                    edges.append(DependencyEdge(
                        source=source.fqn,
                        target=imp_stripped,
                        kind=DependencyKind.IMPORT,
                    ))
