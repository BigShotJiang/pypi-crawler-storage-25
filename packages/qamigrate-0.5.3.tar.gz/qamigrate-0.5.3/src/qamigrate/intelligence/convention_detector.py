"""
Detect project-wide conventions by looking across all parsed classes.

A "convention" is a pattern the project consistently follows. We only
mark one as detected when we see it in enough places to be confident --
typically in at least one base class and one subclass, or across multiple
utility methods.

Every detector is pure Python, zero LLM calls, operates on ClassInfo data
already parsed by the Scanner.
"""

from __future__ import annotations

import re

from qamigrate.intelligence.project_map import (
    ClassInfo,
    ClassRole,
    MethodInfo,
    ProjectConventions,
)


# =====================================================================
# Public API
# =====================================================================


def detect_conventions(classes: dict[str, ClassInfo]) -> ProjectConventions:
    """Return a populated ProjectConventions by looking across all classes."""
    conv = ProjectConventions()

    _detect_method_chaining(conv, classes)
    _detect_logger(conv, classes)
    _detect_logs_every_action(conv, classes)
    _detect_assertion_style(conv, classes)
    _detect_driver_access(conv, classes)
    _detect_implicit_waits(conv, classes)
    _detect_wait_helpers(conv, classes)
    _detect_password_masking(conv, classes)
    _detect_retry_and_listeners(conv, classes)
    _detect_config_override(conv, classes)

    return conv


# =====================================================================
# Method chaining (Page Object fluent style: methods return `this`)
# =====================================================================


def _detect_method_chaining(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """Chaining is detected when >= 2 page object methods return `this`.

    We deliberately only look at page objects because a BasePage or a
    utility class returning `this` would be noise.
    """
    page_methods = [
        m
        for c in classes.values()
        if c.role == ClassRole.PAGE
        for m in c.public_methods
    ]
    if not page_methods:
        return

    returning_this = 0
    for m in page_methods:
        body = (m.body or "").strip()
        if not body:
            continue
        # Heuristic: body ends with `return this;` before the closing brace.
        # Also catches formatting like `    return this;\n}`.
        if re.search(r"\breturn\s+this\s*;\s*\}?\s*$", body):
            returning_this += 1

    conv.method_chaining_detected = True
    conv.method_chaining = returning_this >= 2


# =====================================================================
# Logging
# =====================================================================

# Ordered -- more specific first. The FIRST match wins so Log4j-backed
# project wrappers get credit over java.util.Logger.
_LOGGER_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    # Custom facade classes commonly called Log, Logger, LogUtil...
    ("Log.info",        re.compile(r"\bLog\s*\.\s*(info|debug|warn|error|trace|step|action)\s*\(")),
    ("logger.info",     re.compile(r"\blogger\s*\.\s*(info|debug|warn|error|trace)\s*\(")),
    ("LOG.info",        re.compile(r"\bLOG\s*\.\s*(info|debug|warn|error|trace)\s*\(")),
    ("log.info",        re.compile(r"\blog\s*\.\s*(info|debug|warn|error|trace)\s*\(")),
    ("LoggerFactory",   re.compile(r"LoggerFactory\.getLogger")),
    ("System.out",      re.compile(r"System\s*\.\s*out\s*\.\s*println\s*\(")),
]


def _detect_logger(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """Detect the most common logger call pattern in the project."""
    counts: dict[str, int] = {}
    for c in classes.values():
        for m in c.public_methods + c.private_methods:
            body = m.body or ""
            for name, pattern in _LOGGER_PATTERNS:
                if pattern.search(body):
                    counts[name] = counts.get(name, 0) + 1
                    break  # first match wins per-method

    if counts:
        conv.logger_call_pattern = max(counts.items(), key=lambda kv: kv[1])[0]


def _detect_logs_every_action(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """If BasePage's `click` / `type` / `getText` log before acting,
    the whole project convention is "log every action"."""
    # We look for *any* BASE class whose action-like methods log.
    bases = [c for c in classes.values() if c.role == ClassRole.BASE]
    if not bases:
        return

    action_method_names = {"click", "type", "sendKeys", "submit", "select"}
    logged = 0
    total = 0
    for base in bases:
        for m in base.public_methods + base.private_methods:
            if m.name in action_method_names:
                total += 1
                body = (m.body or "").strip()
                if not body:
                    continue
                # Body begins (after the opening brace) with a logger call
                first_statements = body[:300]  # keep the match cheap
                for _, pattern in _LOGGER_PATTERNS:
                    if pattern.search(first_statements):
                        logged += 1
                        break

    conv.logs_every_action_detected = total > 0
    # Convention holds when AT LEAST HALF of action methods log up front.
    # (Real projects sometimes forget one.)
    if total > 0:
        conv.logs_every_action = (logged * 2) >= total


# =====================================================================
# Assertion style
# =====================================================================


def _detect_assertion_style(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """TestNG vs JUnit5 vs AssertJ vs nothing."""
    joined_imports = " ".join(
        imp for c in classes.values() for imp in c.imports
    )
    joined_bodies = "\n".join(
        m.body or ""
        for c in classes.values()
        for m in c.public_methods + c.private_methods
    )

    if "org.testng.Assert" in joined_imports or "org.testng.asserts" in joined_imports:
        conv.assertion_style = "testng"
    elif "org.assertj" in joined_imports or "assertThat(" in joined_bodies:
        conv.assertion_style = "assertj"
    elif "org.junit.jupiter.api.Assertions" in joined_imports:
        conv.assertion_style = "junit5"
    elif "org.junit.Assert" in joined_imports:
        conv.assertion_style = "junit4"
    # else: leave None (the Coder prompt layer will pick a sensible default)


# =====================================================================
# Driver access style
# =====================================================================


def _detect_driver_access(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """Look at the driver manager's field declarations."""
    for c in classes.values():
        if c.role != ClassRole.DRIVER_MANAGER:
            continue

        field_types = " ".join(f.type for f in c.fields)
        field_mods = " ".join(" ".join(f.modifiers) for f in c.fields)

        if "ThreadLocal" in field_types:
            conv.driver_access = "ThreadLocal"
            conv.parallel_safe = True
        elif "static" in field_mods:
            conv.driver_access = "static_field"
            conv.parallel_safe = False
        else:
            conv.driver_access = "instance_field"
            conv.parallel_safe = False
        return


# =====================================================================
# Implicit waits
# =====================================================================


_IMPLICIT_WAIT_PATTERN = re.compile(
    r"\bmanage\s*\(\s*\)\s*\.\s*timeouts\s*\(\s*\)\s*\.\s*implicitlyWait\b"
)


def _detect_implicit_waits(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """True if any method body calls driver.manage().timeouts().implicitlyWait."""
    for c in classes.values():
        for m in c.public_methods + c.private_methods:
            if _IMPLICIT_WAIT_PATTERN.search(m.body or ""):
                conv.implicit_waits_used = True
                return


# =====================================================================
# Wait helpers
# =====================================================================


def _detect_wait_helpers(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """List the explicit wait-helper methods exposed by utility classes."""
    helpers: list[str] = []
    for c in classes.values():
        if c.role != ClassRole.UTILITY:
            continue
        for m in c.public_methods:
            if m.name.startswith("waitFor"):
                helpers.append(f"{c.name}.{m.name}")

    conv.explicit_wait_helpers = sorted(set(helpers))


# =====================================================================
# Password masking
# =====================================================================


_PASSWORD_MASK_PATTERN = re.compile(
    r"password|credentials", re.IGNORECASE
)


def _detect_password_masking(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """A utility is doing password masking if it has a method body that
    mentions 'password' AND contains a repeat / masking call like `repeat(`,
    `"*"`, `mask(`, or `asterisk`.
    """
    mask_hints = ("repeat(", "\"*\"", "mask(", "***", "asterisk")
    for c in classes.values():
        if c.role != ClassRole.UTILITY:
            continue
        for m in c.public_methods:
            body = m.body or ""
            if _PASSWORD_MASK_PATTERN.search(body) and any(h in body for h in mask_hints):
                conv.password_masking = True
                conv.password_masking_class = c.name
                return


# =====================================================================
# Retry analyzer + @Listeners
# =====================================================================


def _detect_retry_and_listeners(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    # Retry analyzer: any class implementing IRetryAnalyzer (we already
    # classified as LISTENER) OR any @Test(retryAnalyzer=...) in tests.
    retry_detected = any(
        "IRetryAnalyzer" in c.implements for c in classes.values()
    )
    if not retry_detected:
        # Look for retryAnalyzer in test method annotations
        for c in classes.values():
            if c.role != ClassRole.TEST:
                continue
            for m in c.public_methods + c.private_methods:
                for a in m.annotations:
                    if "retryAnalyzer" in a:
                        retry_detected = True
                        break
                if retry_detected:
                    break
            if retry_detected:
                break
    conv.uses_retry_analyzer = retry_detected

    # @Listeners(...) usages: surface the listener class names
    listener_names: set[str] = set()
    for c in classes.values():
        for raw in _class_level_annotations(c):
            m = re.match(r"@Listeners\s*\(\s*\{?([^)}]*)\}?\s*\)", raw)
            if m:
                for part in m.group(1).split(","):
                    name = part.strip().replace(".class", "").rsplit(".", 1)[-1]
                    if name:
                        listener_names.add(name)
    conv.uses_listeners = sorted(listener_names)


def _class_level_annotations(c: ClassInfo) -> list[str]:
    """We didn't model class-level annotations separately (yet). Detect by
    scanning the top of the file's raw source would be cleaner, but a
    cheap proxy is to look at `modifiers` which today contain strings like
    '@Listeners(TestListener.class)'."""
    result: list[str] = []
    for mod in c.modifiers:
        if mod.startswith("@"):
            result.append(mod)
    return result


# =====================================================================
# Config override hierarchy
# =====================================================================


def _detect_config_override(
    conv: ProjectConventions, classes: dict[str, ClassInfo],
) -> None:
    """If a CONFIG class calls System.getProperty first and a property
    lookup second, record the hierarchy so the Coder preserves it."""
    for c in classes.values():
        if c.role != ClassRole.CONFIG:
            continue
        for m in c.public_methods + c.private_methods:
            body = m.body or ""
            has_system = "System.getProperty" in body or "System.getenv" in body
            # "Properties instance" is anything like `props.getProperty` OR
            # the java.util.Properties class reference itself.
            has_props_lookup = bool(
                re.search(r"\.getProperty\s*\(", body)
            ) and "System.getProperty" not in body.split(".getProperty", 1)[-1]
            # Quick pattern to catch both: the method mentions BOTH
            # System.getProperty AND a non-system getProperty call.
            if has_system and has_props_lookup:
                conv.config_override_hierarchy = ["System.getProperty", "properties_file"]
                return
            if has_system:
                conv.config_override_hierarchy = ["System.getProperty"]
            elif has_props_lookup:
                conv.config_override_hierarchy = ["properties_file"]
