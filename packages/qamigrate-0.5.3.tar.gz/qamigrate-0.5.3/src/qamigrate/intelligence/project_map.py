"""
ProjectMap: a frozen snapshot of what the project IS.

Built once by `ProjectAnalyzer`, then read-only for the rest of the run.
Every other part of v0.5+ (the `analyze` report, the Coder's prompt,
the migration plan) is a projection of this data.

Design notes:
    - Dataclasses only -- no behavior. Side-effect-free so it's trivial to
      serialize, cache on disk as .qamigrate/project-map.json, and pass
      into LLM prompts.
    - Method BODIES are stored (`MethodInfo.body`) because Q3 in the design
      doc chose "deep": the Coder sees what sibling methods actually do,
      not just signatures. The prompt layer decides how much to include.
    - Every field is optional where reasonable so a partial map (e.g. a
      project with no listeners) still validates.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


# =====================================================================
# Role classification
# =====================================================================


class ClassRole(str, Enum):
    """What KIND of class this is in the project's architecture.

    Inferred by role_inference.py from structural signals (extends, fields,
    naming, package location). A class has exactly one role.
    """

    BASE = "base"                    # Abstract / extended by others (BasePage, BaseTest)
    UTILITY = "utility"              # Static-method facade (Log, WaitUtils, ScreenshotUtils)
    PAGE = "page"                    # Page Object (@FindBy, extends BasePage, /pages/)
    TEST = "test"                    # Has @Test methods
    LISTENER = "listener"            # Implements ITestListener / IRetryAnalyzer
    DRIVER_MANAGER = "driver_mgr"    # Owns the WebDriver lifecycle
    CONFIG = "config"                # Configuration reader / properties loader
    ENUM = "enum"                    # Plain enum (Environment, etc.)
    MODEL = "model"                  # POJO / data class
    OTHER = "other"                  # Couldn't be classified cleanly


# =====================================================================
# Dependency graph
# =====================================================================


class DependencyKind(str, Enum):
    """How class A depends on class B."""

    EXTENDS = "extends"              # A extends B
    IMPLEMENTS = "implements"        # A implements B
    INSTANTIATES = "instantiates"    # A has `new B(...)`
    STATIC_CALL = "static_call"      # A calls B.someMethod()
    IMPORT = "import"                # A imports B but usage not otherwise classifiable
    FIELD_TYPE = "field_type"        # A has a field of type B


@dataclass(frozen=True)
class DependencyEdge:
    """Directed edge: `source` class depends on `target` class."""

    source: str                      # fully-qualified class name
    target: str                      # fully-qualified class name
    kind: DependencyKind
    # For STATIC_CALL / INSTANTIATES, the specific method or constructor used.
    # None for EXTENDS / IMPLEMENTS / IMPORT.
    symbol: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "source": self.source,
            "target": self.target,
            "kind": self.kind.value,
            "symbol": self.symbol,
        }


# =====================================================================
# Class-level shape
# =====================================================================


@dataclass(frozen=True)
class ParameterInfo:
    """One parameter of a method signature."""

    name: str
    type: str                        # as written in source, e.g. "String", "By", "WebElement"


@dataclass(frozen=True)
class MethodInfo:
    """A class method, with body when available.

    `body` is captured for Q3 "deep" convention: the prompt layer uses it
    to show the Coder what sibling methods actually do, not just their
    signatures. For utility classes this is especially valuable -- seeing
    that `Log.action` formats a prefix string is critical to preserving
    the convention during migration.
    """

    name: str
    modifiers: list[str]             # ["public", "static", "final", ...]
    return_type: str                 # "void" | "String" | "LoginPage" | ...
    parameters: list[ParameterInfo]
    annotations: list[str]           # ["@Test", "@BeforeMethod", ...]
    body: str | None = None          # Full method body (curly braces included) when captured
    line: int = 0                    # Line in source where the method starts

    @property
    def signature(self) -> str:
        """The public signature string, annotation-free."""
        mods = " ".join(self.modifiers)
        params = ", ".join(f"{p.type} {p.name}" for p in self.parameters)
        return f"{mods} {self.return_type} {self.name}({params})".strip()


@dataclass(frozen=True)
class FieldInfo:
    """A class field, with its annotations preserved.

    @FindBy, @Autowired, @Inject etc. matter for role inference and for
    the Coder to understand the project's DI/locator style.
    """

    name: str
    type: str                        # "By", "WebElement", "Locator", ...
    modifiers: list[str]
    annotations: list[str]           # preserved verbatim, e.g. '@FindBy(id = "user-name")'
    line: int = 0


@dataclass(frozen=True)
class ClassRef:
    """Lightweight pointer used when we don't need the full ClassInfo.

    Equal to (fqn,) for hashability -- two refs to the same fqn are
    interchangeable.
    """

    fqn: str                         # fully-qualified class name
    simple_name: str                 # just "LoginPage"
    file_path: str                   # absolute path as string (dataclass frozen friendly)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class ClassInfo:
    """Everything we know about one class.

    Mutable (not frozen) because the analyzer populates fields in phases
    -- we parse structure first, then infer the role, then wire up edges.
    """

    # Identity
    name: str                        # simple name
    fqn: str                         # fully-qualified
    file_path: str
    package: str

    # Structure
    extends: str | None
    implements: list[str]
    modifiers: list[str]             # ["public", "abstract", "final", ...]
    imports: list[str]

    # Role (filled by role_inference after initial parse)
    role: ClassRole = ClassRole.OTHER

    # Members
    public_methods: list[MethodInfo] = field(default_factory=list)
    private_methods: list[MethodInfo] = field(default_factory=list)
    fields: list[FieldInfo] = field(default_factory=list)

    # Free-text doc: one-line role summary the analyzer can generate for
    # prompt context. Example: "Base class for page objects; provides
    # click/type/waitForElement helpers backed by ThreadLocal driver."
    role_summary: str = ""

    def to_ref(self) -> ClassRef:
        return ClassRef(
            fqn=self.fqn,
            simple_name=self.name,
            file_path=self.file_path,
        )


# =====================================================================
# Conventions the project consistently follows
# =====================================================================


@dataclass
class ProjectConventions:
    """Patterns the project consistently follows across multiple files.

    These are DETECTED empirically by convention_detector.py -- not
    assumed. A convention is only recorded when we see it in at least
    two independent locations (or when there's only one possible example,
    e.g. a single BasePage).

    Every field has a boolean 'detected' sibling so the prompt layer can
    distinguish "we checked and it's false" from "we couldn't tell".
    """

    # Page-object style
    method_chaining: bool = False                 # page methods return `this`
    method_chaining_detected: bool = False

    # Logging
    logs_every_action: bool = False               # BasePage.click() calls Log.action() before acting
    logs_every_action_detected: bool = False
    logger_call_pattern: str | None = None        # e.g. "Log.action" | "logger.info" | "System.out.println"

    # Assertion style
    assertion_style: str | None = None            # "testng" | "junit5" | "assertj" | "custom"

    # Driver management
    driver_access: str | None = None              # "ThreadLocal" | "static_field" | "instance_field"
    parallel_safe: bool = False

    # Waits
    implicit_waits_used: bool = False             # project uses driver.manage().timeouts()
    explicit_wait_helpers: list[str] = field(default_factory=list)  # e.g. ["WaitUtils.waitForVisibility"]

    # Password masking + security hygiene
    password_masking: bool = False                # does any util mask passwords in logs?
    password_masking_class: str | None = None     # which utility does the masking

    # TestNG specifics (if applicable)
    uses_retry_analyzer: bool = False
    uses_listeners: list[str] = field(default_factory=list)          # ["TestListener", ...]

    # Configuration / environment
    config_override_hierarchy: list[str] = field(default_factory=list)  # e.g. ["System.getProperty", "properties file"]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# =====================================================================
# Infrastructure (libraries + versions, from pom.xml / build.gradle)
# =====================================================================


@dataclass
class Infrastructure:
    """Detected libraries, frameworks, and versions."""

    build_tool: str                              # "maven" | "gradle" | "unknown"
    build_file: str                              # path to pom.xml / build.gradle

    # Core testing.  Default 'unknown' when we can't tell from deps alone
    # (caller may refine by looking at resources / test code).
    test_framework: str = "unknown"              # "testng" | "junit5" | "junit4" | "unknown"
    test_framework_version: str | None = None

    # Browser layer
    selenium_version: str | None = None
    playwright_version: str | None = None        # may already exist if user ran `init --yes`

    # Logging / reporting
    logging_library: str | None = None           # "log4j2" | "slf4j" | "logback" | "jul" | None
    logging_library_version: str | None = None
    reporting_libraries: list[str] = field(default_factory=list)  # ["ExtentReports", "Allure", ...]

    # Assertion library (if different from test framework's default)
    assertion_library: str | None = None

    # Configuration
    config_source: str | None = None             # "properties" | "yaml" | "json" | "env" | "mixed"
    env_profiles: list[str] = field(default_factory=list)  # ["dev", "qa", "stg", "prod"] if detected

    # Execution
    parallel_execution: bool = False             # testng.xml parallel=... or similar

    # Java / JVM
    java_version: str | None = None              # source compat target, e.g. "17"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# =====================================================================
# The top-level map
# =====================================================================


@dataclass
class ProjectMap:
    """A deep understanding of the whole project, built once before migration.

    Consumers:
        - `qamigrate analyze` renders this to HTML/Markdown/JSON
        - `qamigrate migrate` passes it into Coder prompts so generation
          matches the project's architecture

    Serialization: `to_dict()` + json roundtrip. The `.qamigrate/project-map.json`
    file is a cache so repeated migrations of the same project don't re-parse.
    """

    project_path: str
    project_name: str

    # Structure (flat dicts for O(1) lookup)
    classes: dict[str, ClassInfo] = field(default_factory=dict)    # fqn -> ClassInfo
    packages: dict[str, list[str]] = field(default_factory=dict)   # package -> [fqn, fqn, ...]

    # Classification: refs into `classes`
    base_classes: list[ClassRef] = field(default_factory=list)
    utility_classes: list[ClassRef] = field(default_factory=list)
    page_objects: list[ClassRef] = field(default_factory=list)
    test_classes: list[ClassRef] = field(default_factory=list)
    listeners: list[ClassRef] = field(default_factory=list)
    driver_manager: ClassRef | None = None
    config_reader: ClassRef | None = None

    # Edges
    edges: list[DependencyEdge] = field(default_factory=list)

    # Projections of the above
    conventions: ProjectConventions = field(default_factory=ProjectConventions)
    infrastructure: Infrastructure | None = None

    # Warnings raised during analysis (e.g. "couldn't parse listeners/TestListener.java")
    warnings: list[str] = field(default_factory=list)

    # --- Query helpers ---

    def classes_with_role(self, role: ClassRole) -> list[ClassInfo]:
        """All ClassInfo entries with the given role."""
        return [c for c in self.classes.values() if c.role == role]

    def lookup(self, fqn: str) -> ClassInfo | None:
        return self.classes.get(fqn)

    def lookup_by_simple_name(self, simple_name: str) -> ClassInfo | None:
        """Find a class by its simple name. Returns the first match."""
        for c in self.classes.values():
            if c.name == simple_name:
                return c
        return None

    def dependencies_of(self, fqn: str) -> list[DependencyEdge]:
        """All edges originating from `fqn`."""
        return [e for e in self.edges if e.source == fqn]

    def dependents_of(self, fqn: str) -> list[DependencyEdge]:
        """All edges pointing AT `fqn` (who depends on this class)."""
        return [e for e in self.edges if e.target == fqn]

    # --- Summary for at-a-glance output ---

    @property
    def file_count(self) -> int:
        return len(self.classes)

    @property
    def total_edges(self) -> int:
        return len(self.edges)

    # --- Serialization ---

    def to_dict(self) -> dict[str, Any]:
        return {
            "project_path": self.project_path,
            "project_name": self.project_name,
            "classes": {fqn: _class_to_dict(c) for fqn, c in self.classes.items()},
            "packages": self.packages,
            "base_classes": [r.to_dict() for r in self.base_classes],
            "utility_classes": [r.to_dict() for r in self.utility_classes],
            "page_objects": [r.to_dict() for r in self.page_objects],
            "test_classes": [r.to_dict() for r in self.test_classes],
            "listeners": [r.to_dict() for r in self.listeners],
            "driver_manager": self.driver_manager.to_dict() if self.driver_manager else None,
            "config_reader": self.config_reader.to_dict() if self.config_reader else None,
            "edges": [e.to_dict() for e in self.edges],
            "conventions": self.conventions.to_dict(),
            "infrastructure": self.infrastructure.to_dict() if self.infrastructure else None,
            "warnings": self.warnings,
            "summary": {
                "file_count": self.file_count,
                "total_edges": self.total_edges,
                "base_class_count": len(self.base_classes),
                "utility_class_count": len(self.utility_classes),
                "page_object_count": len(self.page_objects),
                "test_class_count": len(self.test_classes),
            },
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)


# =====================================================================
# Internal helpers (dataclass-serialization plumbing)
# =====================================================================


def _class_to_dict(c: ClassInfo) -> dict[str, Any]:
    """Serialize a ClassInfo.  Helper because asdict() on a nested mutable
    dataclass eats memory on larger projects; we want a predictable shape."""
    return {
        "name": c.name,
        "fqn": c.fqn,
        "file_path": c.file_path,
        "package": c.package,
        "extends": c.extends,
        "implements": c.implements,
        "modifiers": c.modifiers,
        "imports": c.imports,
        "role": c.role.value,
        "role_summary": c.role_summary,
        "public_methods": [
            {
                "name": m.name,
                "modifiers": m.modifiers,
                "return_type": m.return_type,
                "parameters": [asdict(p) for p in m.parameters],
                "annotations": m.annotations,
                "body": m.body,
                "line": m.line,
                "signature": m.signature,
            }
            for m in c.public_methods
        ],
        "private_methods": [
            {
                "name": m.name,
                "return_type": m.return_type,
                "signature": m.signature,
            }
            for m in c.private_methods
        ],
        "fields": [asdict(f) for f in c.fields],
    }
