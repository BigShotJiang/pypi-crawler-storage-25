"""
Render a ProjectMap as a human-readable architecture report.

Three formats:

- HTML: standalone, styled; drop in a PR / share with a stakeholder
- Markdown: fits in a git commit message or GitHub issue
- JSON: machine-readable; feed into CI or another tool

Same structure as `qamigrate migrate --report`: HTML for people,
Markdown for PRs, JSON for automation.
"""

from __future__ import annotations

import html
import json
from pathlib import Path

from qamigrate.intelligence.project_map import (
    ClassRole,
    DependencyKind,
    ProjectMap,
)


# =====================================================================
# JSON
# =====================================================================


def write_json(pm: ProjectMap, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(pm.to_json(), encoding="utf-8")
    return path


# =====================================================================
# Markdown
# =====================================================================


def render_markdown(pm: ProjectMap) -> str:
    lines: list[str] = []

    lines.append(f"# Architecture Report -- {pm.project_name}")
    lines.append("")
    lines.append(f"**Project path:** `{pm.project_path}`")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- **Total classes:** {pm.file_count}")
    lines.append(f"- **Dependency edges:** {pm.total_edges}")
    lines.append(f"- **Base classes:** {len(pm.base_classes)}")
    lines.append(f"- **Utility classes:** {len(pm.utility_classes)}")
    lines.append(f"- **Page objects:** {len(pm.page_objects)}")
    lines.append(f"- **Test classes:** {len(pm.test_classes)}")
    lines.append(f"- **Listeners:** {len(pm.listeners)}")
    if pm.driver_manager:
        lines.append(f"- **Driver manager:** `{pm.driver_manager.simple_name}`")
    if pm.config_reader:
        lines.append(f"- **Config reader:** `{pm.config_reader.simple_name}`")
    lines.append("")

    # Infrastructure
    if pm.infrastructure:
        i = pm.infrastructure
        lines.append("## Infrastructure")
        lines.append("")
        lines.append(f"- **Build tool:** {i.build_tool}")
        lines.append(f"- **Test framework:** {i.test_framework}"
                     + (f" {i.test_framework_version}" if i.test_framework_version else ""))
        if i.selenium_version:
            lines.append(f"- **Selenium:** {i.selenium_version}")
        if i.playwright_version:
            lines.append(f"- **Playwright:** {i.playwright_version}")
        if i.logging_library:
            lines.append(f"- **Logging:** {i.logging_library}")
        if i.reporting_libraries:
            lines.append(f"- **Reporting:** {', '.join(i.reporting_libraries)}")
        if i.assertion_library:
            lines.append(f"- **Assertion library:** {i.assertion_library}")
        if i.env_profiles:
            lines.append(f"- **Env profiles:** {', '.join(i.env_profiles)}")
        if i.java_version:
            lines.append(f"- **Java:** {i.java_version}")
        if i.parallel_execution:
            lines.append("- **Parallel execution enabled**")
        lines.append("")

    # Conventions
    c = pm.conventions
    lines.append("## Project conventions")
    lines.append("")
    lines.append("| Convention | Detected |")
    lines.append("|------------|----------|")
    lines.append(f"| Method chaining (page objects return `this`) | {_yes_no(c.method_chaining)} |")
    lines.append(f"| Logs every action (BasePage.click logs first) | {_yes_no(c.logs_every_action)} |")
    lines.append(f"| Logger pattern | `{c.logger_call_pattern or '-'}` |")
    lines.append(f"| Assertion style | `{c.assertion_style or '-'}` |")
    lines.append(f"| Driver access | `{c.driver_access or '-'}` |")
    lines.append(f"| Parallel-safe | {_yes_no(c.parallel_safe)} |")
    lines.append(f"| Implicit waits used | {_yes_no(c.implicit_waits_used)} |")
    lines.append(f"| Password masking | {_yes_no(c.password_masking)} |")
    lines.append(f"| Retry analyzer | {_yes_no(c.uses_retry_analyzer)} |")
    if c.uses_listeners:
        lines.append(f"| TestNG `@Listeners` | `{', '.join(c.uses_listeners)}` |")
    if c.config_override_hierarchy:
        lines.append(f"| Config lookup order | `{' -> '.join(c.config_override_hierarchy)}` |")
    lines.append("")

    if c.explicit_wait_helpers:
        lines.append("**Explicit wait helpers:**")
        for h in c.explicit_wait_helpers:
            lines.append(f"- `{h}`")
        lines.append("")

    # Classes by role
    lines.append("## Classes by role")
    lines.append("")
    for role in (
        ClassRole.BASE, ClassRole.DRIVER_MANAGER, ClassRole.CONFIG,
        ClassRole.UTILITY, ClassRole.PAGE, ClassRole.LISTENER,
        ClassRole.TEST, ClassRole.ENUM, ClassRole.OTHER,
    ):
        in_role = pm.classes_with_role(role)
        if not in_role:
            continue
        lines.append(f"### {role.value.replace('_', ' ').title()} ({len(in_role)})")
        lines.append("")
        for c in in_role:
            line = f"- **`{c.name}`** ({c.package})"
            if c.role_summary:
                line += f" -- {c.role_summary}"
            lines.append(line)
        lines.append("")

    # Dependency graph highlights
    if pm.edges:
        lines.append("## Key dependencies")
        lines.append("")
        # Show EXTENDS/IMPLEMENTS first, then INSTANTIATES -- that's the most
        # architecturally meaningful subset.
        highlighted = [
            e for e in pm.edges
            if e.kind in {DependencyKind.EXTENDS, DependencyKind.IMPLEMENTS, DependencyKind.INSTANTIATES}
        ]
        if highlighted:
            lines.append("| Source | Kind | Target |")
            lines.append("|--------|------|--------|")
            for e in highlighted[:50]:
                src = _short_name(e.source)
                tgt = _short_name(e.target)
                lines.append(f"| `{src}` | `{e.kind.value}` | `{tgt}` |")
            lines.append("")

    # Warnings
    if pm.warnings:
        lines.append("## Warnings")
        lines.append("")
        for w in pm.warnings:
            lines.append(f"- {w}")
        lines.append("")

    return "\n".join(lines)


def write_markdown(pm: ProjectMap, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_markdown(pm), encoding="utf-8")
    return path


# =====================================================================
# HTML
# =====================================================================


def render_html(pm: ProjectMap) -> str:
    c = pm.conventions
    i = pm.infrastructure

    def esc(x) -> str:
        return html.escape(str(x)) if x is not None else ""

    convention_rows = []
    for label, value in [
        ("Method chaining", _yes_no(c.method_chaining)),
        ("Logs every action", _yes_no(c.logs_every_action)),
        ("Logger pattern", esc(c.logger_call_pattern or "-")),
        ("Assertion style", esc(c.assertion_style or "-")),
        ("Driver access", esc(c.driver_access or "-")),
        ("Parallel-safe", _yes_no(c.parallel_safe)),
        ("Implicit waits", _yes_no(c.implicit_waits_used)),
        ("Password masking", _yes_no(c.password_masking)),
        ("Retry analyzer", _yes_no(c.uses_retry_analyzer)),
    ]:
        convention_rows.append(f"<tr><td>{label}</td><td><code>{value}</code></td></tr>")

    def class_rows(role: ClassRole) -> str:
        in_role = pm.classes_with_role(role)
        if not in_role:
            return ""
        rows = "".join(
            f'<tr><td><code>{esc(cl.name)}</code></td>'
            f'<td class="pkg">{esc(cl.package)}</td>'
            f'<td>{esc(cl.role_summary)}</td></tr>'
            for cl in in_role
        )
        return (
            f'<h3>{esc(role.value.replace("_", " ").title())} '
            f'<span class="count">({len(in_role)})</span></h3>'
            f'<table class="classes">'
            f'<thead><tr><th>Class</th><th>Package</th><th>Summary</th></tr></thead>'
            f'<tbody>{rows}</tbody></table>'
        )

    all_role_sections = "".join(
        class_rows(r) for r in (
            ClassRole.BASE, ClassRole.DRIVER_MANAGER, ClassRole.CONFIG,
            ClassRole.UTILITY, ClassRole.PAGE, ClassRole.LISTENER,
            ClassRole.TEST, ClassRole.ENUM, ClassRole.OTHER,
        )
    )

    edge_rows = ""
    if pm.edges:
        highlighted = [
            e for e in pm.edges
            if e.kind in {
                DependencyKind.EXTENDS, DependencyKind.IMPLEMENTS,
                DependencyKind.INSTANTIATES,
            }
        ]
        edge_rows = "".join(
            f'<tr><td><code>{esc(_short_name(e.source))}</code></td>'
            f'<td><span class="kind">{esc(e.kind.value)}</span></td>'
            f'<td><code>{esc(_short_name(e.target))}</code></td></tr>'
            for e in highlighted[:100]
        )

    infrastructure_block = ""
    if i:
        rows = []
        rows.append(f"<tr><td>Build tool</td><td><code>{esc(i.build_tool)}</code></td></tr>")
        tf = i.test_framework + (f" {i.test_framework_version}" if i.test_framework_version else "")
        rows.append(f"<tr><td>Test framework</td><td><code>{esc(tf)}</code></td></tr>")
        if i.selenium_version:
            rows.append(f"<tr><td>Selenium</td><td><code>{esc(i.selenium_version)}</code></td></tr>")
        if i.playwright_version:
            rows.append(f"<tr><td>Playwright</td><td><code>{esc(i.playwright_version)}</code></td></tr>")
        if i.logging_library:
            rows.append(f"<tr><td>Logging</td><td><code>{esc(i.logging_library)}</code></td></tr>")
        if i.reporting_libraries:
            rows.append(f"<tr><td>Reporting</td><td><code>{esc(', '.join(i.reporting_libraries))}</code></td></tr>")
        if i.env_profiles:
            rows.append(f"<tr><td>Env profiles</td><td><code>{esc(', '.join(i.env_profiles))}</code></td></tr>")
        if i.java_version:
            rows.append(f"<tr><td>Java</td><td><code>{esc(i.java_version)}</code></td></tr>")
        if i.parallel_execution:
            rows.append("<tr><td>Parallel execution</td><td><code>enabled</code></td></tr>")

        infrastructure_block = (
            '<h2>Infrastructure</h2>'
            '<table class="kv"><tbody>' + "".join(rows) + "</tbody></table>"
        )

    body = f"""
<header>
    <h1>{esc(pm.project_name)}</h1>
    <div class="sub">QAMigrate architecture report</div>
    <code class="path">{esc(pm.project_path)}</code>
</header>

<section class="summary">
    <div class="card"><div class="label">Classes</div><div class="value">{pm.file_count}</div></div>
    <div class="card"><div class="label">Edges</div><div class="value">{pm.total_edges}</div></div>
    <div class="card"><div class="label">Pages</div><div class="value">{len(pm.page_objects)}</div></div>
    <div class="card"><div class="label">Tests</div><div class="value">{len(pm.test_classes)}</div></div>
    <div class="card"><div class="label">Utilities</div><div class="value">{len(pm.utility_classes)}</div></div>
    <div class="card"><div class="label">Listeners</div><div class="value">{len(pm.listeners)}</div></div>
</section>

{infrastructure_block}

<h2>Project conventions</h2>
<table class="kv">
    <tbody>{''.join(convention_rows)}</tbody>
</table>

<h2>Classes by role</h2>
{all_role_sections}

{"<h2>Key dependencies</h2>" + '<table class="classes"><thead><tr><th>From</th><th>Kind</th><th>To</th></tr></thead><tbody>' + edge_rows + "</tbody></table>" if edge_rows else ""}
"""

    return _HTML_TEMPLATE.format(title=esc(pm.project_name), body=body)


def write_html(pm: ProjectMap, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_html(pm), encoding="utf-8")
    return path


# =====================================================================
# Helpers
# =====================================================================


def _yes_no(v: bool) -> str:
    return "YES" if v else "no"


def _short_name(fqn: str) -> str:
    return fqn.rsplit(".", 1)[-1]


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>QAMigrate report -- {title}</title>
    <style>
        body {{ font: 14px -apple-system, "Segoe UI", Roboto, sans-serif;
                max-width: 1100px; margin: 2rem auto; padding: 0 1.5rem;
                color: #1f2328; background: #f6f8fa; }}
        header h1 {{ margin: 0; font-size: 1.8rem; }}
        header .sub {{ color: #57606a; margin-bottom: .4rem; }}
        header .path {{ color: #57606a; font-size: .85rem; }}
        h2 {{ margin-top: 2rem; border-bottom: 1px solid #d0d7de; padding-bottom: .3rem; }}
        h3 {{ margin-top: 1.2rem; }}
        h3 .count {{ color: #57606a; font-weight: normal; font-size: .85em; }}
        section.summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
                          gap: 1rem; margin-top: 1.2rem; }}
        .card {{ background: white; border: 1px solid #d0d7de; border-radius: 6px;
                 padding: 1rem; text-align: center; }}
        .card .label {{ color: #57606a; font-size: .8rem; text-transform: uppercase; }}
        .card .value {{ font-size: 2rem; font-weight: 600; color: #0969da; }}
        table {{ border-collapse: collapse; width: 100%; background: white;
                 border: 1px solid #d0d7de; border-radius: 6px; overflow: hidden; margin-top: .6rem; }}
        th, td {{ padding: .5rem .8rem; border-bottom: 1px solid #d0d7de; text-align: left; }}
        tbody tr:last-child td {{ border-bottom: none; }}
        th {{ background: #f6f8fa; font-weight: 600; font-size: .9em; }}
        code {{ background: #f6f8fa; padding: .1em .4em; border-radius: 4px;
                font-size: .9em; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }}
        .classes td.pkg {{ color: #57606a; font-size: .85em; }}
        .kv td:first-child {{ width: 40%; color: #57606a; }}
        .kind {{ background: #ddf4ff; color: #0969da; padding: .1em .5em; border-radius: 4px; font-size: .8em; }}
    </style>
</head>
<body>
{body}
</body>
</html>
"""
