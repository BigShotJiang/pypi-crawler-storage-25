"""
Classify a ClassInfo into its architectural role.

No LLM, no tree-sitter -- pure rules over the parsed structure. The signals
we use are empirical: they come from looking at what actual Selenium
projects do. Add new heuristics here when you see a pattern the rules miss.
"""

from __future__ import annotations

from qamigrate.intelligence.project_map import ClassInfo, ClassRole


# Keyword hints. Lowercased for matching.
PAGE_PACKAGE_HINTS = ("/pages/", "/page/", ".pages.", ".page.")
TEST_PACKAGE_HINTS = ("/tests/", "/test/", ".tests.", ".test.")
UTILITY_PACKAGE_HINTS = ("/utils/", "/util/", "/helpers/", ".utils.", ".util.", ".helpers.")
LISTENER_PACKAGE_HINTS = ("/listeners/", ".listeners.")
CONFIG_PACKAGE_HINTS = ("/config/", ".config.")

# Interface names that mark listener/hook classes.
LISTENER_INTERFACES = {
    "ITestListener",
    "IInvokedMethodListener",
    "ISuiteListener",
    "IReporter",
    "IRetryAnalyzer",
    "IAnnotationTransformer",
    "IExecutionListener",
    # JUnit 5 extension API
    "TestWatcher",
    "BeforeEachCallback",
    "AfterEachCallback",
}

# Common names that strongly suggest the class is the driver lifecycle owner.
DRIVER_MANAGER_NAMES = {
    "DriverManager",
    "DriverFactory",
    "WebDriverManager",
    "DriverHolder",
}

# Common config reader names.
CONFIG_READER_NAMES = {
    "ConfigurationReader",
    "ConfigReader",
    "PropertyReader",
    "TestConfig",
    "EnvConfig",
}


def infer_role(info: ClassInfo) -> ClassRole:
    """Return the class's ClassRole based on structural rules.

    Rule order matters: we check the most specific signals first.
    A class is assigned exactly one role -- first matching rule wins.
    """

    # --- 1. Explicit listener interfaces win immediately ---
    if any(i in LISTENER_INTERFACES for i in info.implements):
        return ClassRole.LISTENER

    # --- 2. Known-name shortcuts ---
    if info.name in DRIVER_MANAGER_NAMES:
        return ClassRole.DRIVER_MANAGER
    if info.name in CONFIG_READER_NAMES:
        return ClassRole.CONFIG

    # --- 3. Enum ---
    # The parser today marks enums as class_declaration too; we check the
    # modifiers / body later when we add enum-specific parsing. For now,
    # rely on file content: if every field is the enum type itself, this
    # is an enum-like class. (Keep conservative -- return OTHER otherwise.)
    if "enum" in info.modifiers:
        return ClassRole.ENUM

    # --- 4. Test class: has a method annotated with @Test / @TestTemplate ---
    test_annotations = {"@Test", "@TestTemplate", "@ParameterizedTest"}
    if any(
        _method_has_any_annotation(m, test_annotations)
        for m in info.public_methods
    ):
        return ClassRole.TEST

    # Same for the case where @Test annotations survived on private/package methods
    if any(
        _method_has_any_annotation(m, test_annotations)
        for m in info.private_methods
    ):
        return ClassRole.TEST

    # --- 5. Base class ---
    # Strong signal: class is abstract OR its name starts with "Base" and
    # it isn't itself derived from BasePage/BaseTest (those are THE bases).
    if "abstract" in info.modifiers:
        return ClassRole.BASE
    if (
        info.name.startswith("Base")
        and not info.extends  # A class extending "Base*" is a subclass, not itself the base
        and _has_protected_helpers(info)
    ):
        return ClassRole.BASE

    # --- 6. Page object ---
    # Either lives in a /pages/ package, or has @FindBy fields, or extends
    # a BasePage-like class.
    if _is_in_any_path_hint(info, PAGE_PACKAGE_HINTS):
        return ClassRole.PAGE
    if info.extends and info.extends.startswith("Base") and "Page" in info.extends:
        return ClassRole.PAGE
    if any("@FindBy" in a for f in info.fields for a in f.annotations):
        return ClassRole.PAGE

    # --- 7. Utility class ---
    # All public methods are static AND there are no non-static fields.
    # Or the class is in /utils/ / /helpers/ and has mostly static members.
    if _is_in_any_path_hint(info, UTILITY_PACKAGE_HINTS):
        if _mostly_static(info):
            return ClassRole.UTILITY
    # All-static even without the /utils/ hint
    if info.public_methods and all(
        "static" in m.modifiers for m in info.public_methods
    ):
        if not any(
            "static" not in f.modifiers for f in info.fields
        ):
            return ClassRole.UTILITY

    # --- 8. Config (based on package) ---
    if _is_in_any_path_hint(info, CONFIG_PACKAGE_HINTS):
        return ClassRole.CONFIG

    # --- 9. Listener (based on package alone) ---
    if _is_in_any_path_hint(info, LISTENER_PACKAGE_HINTS):
        return ClassRole.LISTENER

    # --- 10. Fallback ---
    return ClassRole.OTHER


# =====================================================================
# Helpers
# =====================================================================


def _method_has_any_annotation(method, targets: set[str]) -> bool:
    """True if any annotation on the method matches one of `targets`
    after stripping parameters.

    '@Test(priority=1)' matches '@Test'.
    """
    for raw in method.annotations:
        # Strip anything after '(' and whitespace
        head = raw.split("(", 1)[0].strip()
        if head in targets:
            return True
    return False


def _is_in_any_path_hint(info: ClassInfo, hints: tuple[str, ...]) -> bool:
    """Match hints against both the file path AND the package name.

    Path-based hints use forward slashes; we normalize both sides before
    comparing so Windows paths with backslashes also match.
    """
    normalized_path = info.file_path.replace("\\", "/")
    for hint in hints:
        if hint in normalized_path:
            return True
        if hint in info.package:
            return True
    return False


def _has_protected_helpers(info: ClassInfo) -> bool:
    """Base classes typically expose protected helper methods subclasses call.
    We look for at least one protected method as evidence.
    """
    for m in info.public_methods + info.private_methods:
        if "protected" in m.modifiers:
            return True
    return False


def _mostly_static(info: ClassInfo) -> bool:
    """True if >= 75% of public methods are static and at least one is."""
    pub = info.public_methods
    if not pub:
        return False
    static_count = sum(1 for m in pub if "static" in m.modifiers)
    return static_count >= 1 and static_count / len(pub) >= 0.75
