"""
Project Intelligence layer.

Builds a `ProjectMap` from a Selenium codebase that captures structure,
roles, conventions, dependencies, and infrastructure -- everything the
Coder needs to produce migrations that match the project's architecture
instead of generic Playwright output.

Public entry points:
    - `ProjectAnalyzer.build(project_path)` -> ProjectMap
    - `render_html_report(project_map)` / `render_markdown_report(project_map)`
"""

from __future__ import annotations

from qamigrate.intelligence.analyzer import ProjectAnalyzer
from qamigrate.intelligence.project_map import (
    ClassInfo,
    ClassRef,
    ClassRole,
    DependencyEdge,
    DependencyKind,
    FieldInfo,
    Infrastructure,
    MethodInfo,
    ParameterInfo,
    ProjectConventions,
    ProjectMap,
)

__all__ = [
    "ClassInfo",
    "ClassRef",
    "ClassRole",
    "DependencyEdge",
    "DependencyKind",
    "FieldInfo",
    "Infrastructure",
    "MethodInfo",
    "ParameterInfo",
    "ProjectAnalyzer",
    "ProjectConventions",
    "ProjectMap",
]
