"""
Compiler Agent.

Validates generated code through actual compilation,
extracting structured error information on failure.
"""

import re
import subprocess
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

import structlog

from qamigrate.core.config import CompilerConfig

logger = structlog.get_logger(__name__)


class ErrorType(str, Enum):
    """Categories of compilation errors."""

    SYNTAX = "syntax"
    TYPE_MISMATCH = "type_mismatch"
    MISSING_IMPORT = "missing_import"
    MISSING_METHOD = "missing_method"
    MISSING_CLASS = "missing_class"
    AMBIGUOUS_REFERENCE = "ambiguous_reference"
    UNKNOWN = "unknown"


@dataclass
class CompilerError:
    """Structured representation of a compilation error."""

    file_path: str
    line_number: int
    column: int
    error_type: ErrorType
    message: str
    code_context: str

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "file_path": self.file_path,
            "line_number": self.line_number,
            "column": self.column,
            "error_type": self.error_type.value,
            "message": self.message,
            "code_context": self.code_context,
        }


@dataclass
class CompilationResult:
    """Complete compilation attempt result."""

    success: bool
    exit_code: int
    errors: list[CompilerError]
    warnings: list[str]
    build_time_ms: int
    stdout: str
    stderr: str

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "success": self.success,
            "exit_code": self.exit_code,
            "errors": [e.to_dict() for e in self.errors],
            "warnings": self.warnings,
            "build_time_ms": self.build_time_ms,
        }


class CompilerAgent:
    """
    Deterministic build validation.

    No LLM required - invokes actual compiler.
    """

    # Patterns to categorize errors
    ERROR_PATTERNS = {
        ErrorType.MISSING_IMPORT: r"cannot find symbol.*class (\w+)|package .+ does not exist",
        ErrorType.TYPE_MISMATCH: r"incompatible types:.*found:.*required:",
        ErrorType.SYNTAX: r"';' expected|illegal start of|unclosed|expected",
        ErrorType.MISSING_METHOD: r"cannot find symbol.*method (\w+)",
        ErrorType.MISSING_CLASS: r"cannot find symbol.*class (\w+)",
        ErrorType.AMBIGUOUS_REFERENCE: r"reference to \w+ is ambiguous",
    }

    def __init__(self, config: CompilerConfig | None = None) -> None:
        """Initialize compiler agent with configuration."""
        self.config = config or CompilerConfig()
        self.build_tool = self.config.build_tool
        self.timeout = self.config.timeout_seconds

    def compile(
        self,
        project_path: Path,
        target_file: Path | None = None,
    ) -> CompilationResult:
        """
        Execute compilation and return structured result.

        Args:
            project_path: Root path of the project
            target_file: Optional specific file being compiled

        Returns:
            CompilationResult with success/failure and error details
        """
        logger.info(
            "Starting compilation",
            project=str(project_path),
            build_tool=self.build_tool,
        )

        start_time = time.time()

        if self.build_tool == "maven":
            result = self._run_maven(project_path)
        else:
            result = self._run_gradle(project_path)

        build_time = int((time.time() - start_time) * 1000)

        if result.returncode == 0:
            logger.info("Compilation successful", build_time_ms=build_time)
            return CompilationResult(
                success=True,
                exit_code=0,
                errors=[],
                warnings=self._extract_warnings(result.stdout),
                build_time_ms=build_time,
                stdout=result.stdout,
                stderr=result.stderr,
            )

        errors = self._parse_errors(result.stderr, target_file)
        logger.warning(
            "Compilation failed",
            error_count=len(errors),
            build_time_ms=build_time,
        )

        return CompilationResult(
            success=False,
            exit_code=result.returncode,
            errors=errors,
            warnings=[],
            build_time_ms=build_time,
            stdout=result.stdout,
            stderr=result.stderr,
        )

    def compile_single_file(
        self,
        file_path: Path,
        classpath: list[Path] | None = None,
    ) -> CompilationResult:
        """
        Compile a single Java file with javac.

        Args:
            file_path: Path to the Java file
            classpath: Optional list of classpath entries

        Returns:
            CompilationResult
        """
        logger.info("Compiling single file", file=str(file_path))

        start_time = time.time()

        cmd = ["javac"]

        if classpath:
            cp = ";".join(str(p) for p in classpath)  # Windows uses ;
            cmd.extend(["-cp", cp])

        cmd.append(str(file_path))

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
            )
        except subprocess.TimeoutExpired:
            return CompilationResult(
                success=False,
                exit_code=-1,
                errors=[
                    CompilerError(
                        file_path=str(file_path),
                        line_number=0,
                        column=0,
                        error_type=ErrorType.UNKNOWN,
                        message="Compilation timed out",
                        code_context="",
                    )
                ],
                warnings=[],
                build_time_ms=int((time.time() - start_time) * 1000),
                stdout="",
                stderr="Compilation timed out",
            )
        except FileNotFoundError:
            return CompilationResult(
                success=False,
                exit_code=-1,
                errors=[
                    CompilerError(
                        file_path=str(file_path),
                        line_number=0,
                        column=0,
                        error_type=ErrorType.UNKNOWN,
                        message="javac not found in PATH",
                        code_context="",
                    )
                ],
                warnings=[],
                build_time_ms=0,
                stdout="",
                stderr="javac not found",
            )

        build_time = int((time.time() - start_time) * 1000)

        if result.returncode == 0:
            return CompilationResult(
                success=True,
                exit_code=0,
                errors=[],
                warnings=self._extract_warnings(result.stdout),
                build_time_ms=build_time,
                stdout=result.stdout,
                stderr=result.stderr,
            )

        errors = self._parse_errors(result.stderr, file_path)

        return CompilationResult(
            success=False,
            exit_code=result.returncode,
            errors=errors,
            warnings=[],
            build_time_ms=build_time,
            stdout=result.stdout,
            stderr=result.stderr,
        )

    def compile_batch(
        self,
        files: list[Path],
        classpath: list[Path] | None = None,
        source_root: Path | None = None,
    ) -> CompilationResult:
        """
        Compile multiple Java files together.

        Compiles all files in a single javac invocation so that inter-file
        references (e.g. LoginPage extends BasePage) resolve. Uses
        `os.pathsep` so the classpath separator works on both Windows and
        POSIX.

        Args:
            files: List of Java files to compile together.
            classpath: Optional classpath entries (e.g. resolved JARs).
            source_root: Source root for package resolution.

        Returns:
            CompilationResult with combined errors (one CompilerError per
            javac error, each with its own file_path).
        """
        import os
        import tempfile

        if not files:
            return CompilationResult(
                success=True,
                exit_code=0,
                errors=[],
                warnings=[],
                build_time_ms=0,
                stdout="No files to compile",
                stderr="",
            )

        logger.info("Batch compiling files", file_count=len(files))

        start_time = time.time()

        cmd = ["javac", "-Xlint:none"]

        if classpath:
            cp = os.pathsep.join(str(p) for p in classpath)
            cmd.extend(["-cp", cp])

        if source_root:
            cmd.extend(["-sourcepath", str(source_root)])

        # Output to a temp directory so we don't pollute the source tree.
        # IMPORTANT: javac must run INSIDE the `with` block so the temp
        # directory still exists when the subprocess fires.
        with tempfile.TemporaryDirectory() as temp_dir:
            cmd.extend(["-d", temp_dir])
            cmd.extend(str(f) for f in files)

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                )
            except subprocess.TimeoutExpired:
                return CompilationResult(
                    success=False,
                    exit_code=-1,
                    errors=[
                        CompilerError(
                            file_path="batch",
                            line_number=0,
                            column=0,
                            error_type=ErrorType.UNKNOWN,
                            message=f"Batch compilation timed out ({len(files)} files)",
                            code_context="",
                        )
                    ],
                    warnings=[],
                    build_time_ms=int((time.time() - start_time) * 1000),
                    stdout="",
                    stderr="Compilation timed out",
                )
            except FileNotFoundError:
                return CompilationResult(
                    success=False,
                    exit_code=-1,
                    errors=[
                        CompilerError(
                            file_path="batch",
                            line_number=0,
                            column=0,
                            error_type=ErrorType.UNKNOWN,
                            message="javac not found in PATH",
                            code_context="",
                        )
                    ],
                    warnings=[],
                    build_time_ms=0,
                    stdout="",
                    stderr="javac not found",
                )

            build_time = int((time.time() - start_time) * 1000)

            if result.returncode == 0:
                logger.info(
                    "Batch compilation successful",
                    file_count=len(files),
                    build_time_ms=build_time,
                )
                return CompilationResult(
                    success=True,
                    exit_code=0,
                    errors=[],
                    warnings=self._extract_warnings(result.stdout),
                    build_time_ms=build_time,
                    stdout=result.stdout,
                    stderr=result.stderr,
                )

            errors = self._parse_errors(result.stderr)
            logger.warning(
                "Batch compilation failed",
                file_count=len(files),
                error_count=len(errors),
                build_time_ms=build_time,
            )

            return CompilationResult(
                success=False,
                exit_code=result.returncode,
                errors=errors,
                warnings=[],
                build_time_ms=build_time,
                stdout=result.stdout,
                stderr=result.stderr,
            )

    @staticmethod
    def group_errors_by_file(
        result: CompilationResult,
    ) -> dict[str, list[CompilerError]]:
        """
        Bucket the errors from a (batch) compile result by file_path.

        Useful when invoking the Fixer per file after a project-level
        compile: each file only sees its own errors, so the LLM isn't
        confused by messages from other files.
        """
        groups: dict[str, list[CompilerError]] = {}
        for err in result.errors:
            groups.setdefault(err.file_path, []).append(err)
        return groups

    def _run_maven(self, project_path: Path) -> subprocess.CompletedProcess:
        """Execute Maven compilation."""
        cmd = ["mvn", "compile", "-q", "-f", str(project_path / "pom.xml")]

        try:
            return subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                cwd=str(project_path),
            )
        except subprocess.TimeoutExpired:
            # Create a fake result for timeout
            return subprocess.CompletedProcess(
                args=cmd,
                returncode=-1,
                stdout="",
                stderr="Build timed out",
            )
        except FileNotFoundError:
            return subprocess.CompletedProcess(
                args=cmd,
                returncode=-1,
                stdout="",
                stderr="Maven not found in PATH",
            )

    def _run_gradle(self, project_path: Path) -> subprocess.CompletedProcess:
        """Execute Gradle compilation."""
        # Use gradlew if available
        gradlew = project_path / "gradlew.bat"  # Windows
        if not gradlew.exists():
            gradlew = project_path / "gradlew"

        if gradlew.exists():
            cmd = [str(gradlew), "compileJava", "-q"]
        else:
            cmd = ["gradle", "compileJava", "-q"]

        try:
            return subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                cwd=str(project_path),
            )
        except subprocess.TimeoutExpired:
            return subprocess.CompletedProcess(
                args=cmd,
                returncode=-1,
                stdout="",
                stderr="Build timed out",
            )
        except FileNotFoundError:
            return subprocess.CompletedProcess(
                args=cmd,
                returncode=-1,
                stdout="",
                stderr="Gradle not found in PATH",
            )

    def _parse_errors(
        self,
        stderr: str,
        target_file: Path | None = None,
    ) -> list[CompilerError]:
        """
        Parse javac error output into structured errors.

        Args:
            stderr: Compiler error output
            target_file: Optional specific file to focus on

        Returns:
            List of CompilerError objects
        """
        errors: list[CompilerError] = []
        current_error: CompilerError | None = None
        context_lines: list[str] = []

        for line in stderr.split("\n"):
            # Match error line: /path/File.java:42: error: message
            # Or: /path/File.java:42:15: error: message
            match = re.match(r"(.+\.java):(\d+):(?:(\d+):)?\s*error:\s*(.+)", line)

            if match:
                # Save previous error if exists
                if current_error:
                    current_error.code_context = "\n".join(context_lines)
                    errors.append(current_error)

                file_path = match.group(1)
                line_num = int(match.group(2))
                column = int(match.group(3)) if match.group(3) else 0
                message = match.group(4)

                error_type = self._categorize_error(message)

                current_error = CompilerError(
                    file_path=file_path,
                    line_number=line_num,
                    column=column,
                    error_type=error_type,
                    message=message,
                    code_context="",
                )
                context_lines = []

            elif current_error and line.strip():
                context_lines.append(line)

        # Don't forget the last error
        if current_error:
            current_error.code_context = "\n".join(context_lines)
            errors.append(current_error)

        return errors

    def _categorize_error(self, message: str) -> ErrorType:
        """Categorize error for targeted fixing."""
        for error_type, pattern in self.ERROR_PATTERNS.items():
            if re.search(pattern, message, re.IGNORECASE):
                return error_type
        return ErrorType.UNKNOWN

    def _extract_warnings(self, stdout: str) -> list[str]:
        """Extract warning messages from stdout."""
        warnings: list[str] = []

        for line in stdout.split("\n"):
            if "warning:" in line.lower():
                warnings.append(line.strip())

        return warnings
