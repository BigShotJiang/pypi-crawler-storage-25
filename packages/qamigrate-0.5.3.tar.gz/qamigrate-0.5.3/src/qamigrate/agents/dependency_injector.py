"""
Dependency injector.

When a user runs `qamigrate init` on a Maven or Gradle project that doesn't
yet depend on Playwright + JUnit 5, we offer to add the needed coordinates.
This keeps compile validation working out of the box without forcing the
user to edit their build file manually.

Idempotent: re-running is a no-op when the dependencies are already present.
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path

import structlog

logger = structlog.get_logger(__name__)


# Pin to known-good versions. Users can bump later in their own pom/gradle.
PLAYWRIGHT_VERSION = "1.48.0"
JUNIT_VERSION = "5.11.3"
PLAYWRIGHT_ASSERTIONS_SCOPE = "test"


MAVEN_NS = {"m": "http://maven.apache.org/POM/4.0.0"}


@dataclass
class InjectionResult:
    """What we did to the build file."""

    changed: bool
    added: list[str]
    already_present: list[str]
    build_file: Path | None = None
    warning: str | None = None


class DependencyInjector:
    """
    Adds Playwright + JUnit 5 dependencies to a Maven or Gradle project.

    Usage:
        injector = DependencyInjector(project_path)
        result = injector.ensure_playwright_deps(build_tool="maven")
        if result.changed:
            print(f"Added: {result.added}")
    """

    def __init__(self, project_path: Path) -> None:
        self.project_path = project_path

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def ensure_playwright_deps(self, build_tool: str) -> InjectionResult:
        """Add Playwright + JUnit 5 deps if missing. Returns what changed."""
        if build_tool == "maven":
            return self._ensure_maven()
        if build_tool == "gradle":
            return self._ensure_gradle()
        return InjectionResult(
            changed=False, added=[], already_present=[],
            warning=f"Unsupported build tool: {build_tool!r}",
        )

    # ------------------------------------------------------------------
    # Maven
    # ------------------------------------------------------------------

    def _ensure_maven(self) -> InjectionResult:
        """
        Add Playwright + JUnit 5 to pom.xml if missing.

        We use ElementTree for READING (detect existing deps) but do the
        WRITE surgically as text so we don't strip comments, the XML
        declaration, or formatting from the user's file. Rewriting pom.xml
        through ET.tostring produces a disruptive git diff.
        """
        pom = self.project_path / "pom.xml"
        if not pom.exists():
            return InjectionResult(
                changed=False, added=[], already_present=[],
                warning="pom.xml not found",
            )

        raw = pom.read_text(encoding="utf-8")

        # Parse only to check existing deps; we'll write via text surgery.
        try:
            root = ET.fromstring(raw)
        except ET.ParseError as e:
            return InjectionResult(
                changed=False, added=[], already_present=[],
                build_file=pom,
                warning=f"pom.xml could not be parsed: {e}",
            )

        ns = self._detect_maven_namespace(root)
        existing = self._collect_maven_deps(root, ns)

        to_add: list[dict[str, str]] = []
        already_present: list[str] = []
        for dep in self._needed_deps():
            key = (dep["group"], dep["artifact"])
            if key in existing:
                already_present.append(f"{dep['group']}:{dep['artifact']}")
            else:
                to_add.append(dep)

        if not to_add:
            return InjectionResult(
                changed=False, added=[], already_present=already_present,
                build_file=pom,
            )

        new_content, warning = self._insert_maven_deps_textually(raw, to_add)
        if warning is not None:
            return InjectionResult(
                changed=False, added=[], already_present=already_present,
                build_file=pom, warning=warning,
            )

        pom.write_text(new_content, encoding="utf-8")

        added_labels = [f"{d['group']}:{d['artifact']}:{d['version']}" for d in to_add]
        return InjectionResult(
            changed=True,
            added=added_labels,
            already_present=already_present,
            build_file=pom,
        )

    def _insert_maven_deps_textually(
        self,
        content: str,
        deps_to_add: list[dict[str, str]],
    ) -> tuple[str, str | None]:
        """
        Insert new <dependency> blocks into the existing pom.xml text.

        Returns (new_content, warning). If warning is non-None the caller
        must bail out without writing.

        Strategy:
          1. If there's a `</dependencies>` tag, insert new deps right before it.
          2. If there's no `<dependencies>` block at all, insert one right before `</project>`.
          3. Otherwise (e.g. truncated file), bail out.

        We use regex with re.search (not re.sub) and manually slice the
        string so we never reformat anything outside the insertion point.
        """
        # Figure out the indent used by existing <dependency> blocks so our
        # inserts look at home. If we can't detect, default to 8 spaces
        # (typical for children of <dependencies> under <project>).
        indent = self._detect_dep_indent(content)

        new_blocks = "\n".join(
            self._format_dep_block(dep, indent) for dep in deps_to_add
        )

        # Case 1: existing </dependencies> -- insert before it
        close_re = re.compile(r"[ \t]*</dependencies>", re.MULTILINE)
        match = close_re.search(content)
        if match:
            insertion_point = match.start()
            # Ensure there's a newline right before our insertion so the
            # new blocks don't land on the same line as a previous dep's
            # closing tag.
            prefix = content[:insertion_point]
            if not prefix.endswith("\n"):
                prefix = prefix + "\n"
            return (
                prefix
                + new_blocks
                + "\n"
                + content[insertion_point:]
            ), None

        # Case 2: no <dependencies> block -- create one before </project>
        project_close_re = re.compile(r"[ \t]*</project>\s*$", re.MULTILINE)
        match = project_close_re.search(content)
        if match:
            # 4-space indent for <dependencies>, 8-space for <dependency>
            deps_block = (
                "    <dependencies>\n"
                + new_blocks
                + "\n    </dependencies>\n"
            )
            prefix = content[:match.start()]
            if not prefix.endswith("\n"):
                prefix = prefix + "\n"
            return (
                prefix
                + deps_block
                + content[match.start():]
            ), None

        return content, "Could not find </dependencies> or </project> in pom.xml"

    def _detect_dep_indent(self, content: str) -> str:
        """
        Return the whitespace prefix used on the first `<dependency>` tag
        found in the file. Falls back to 8 spaces when none exists yet.
        """
        match = re.search(r"^([ \t]*)<dependency>", content, re.MULTILINE)
        if match:
            return match.group(1)
        return "        "

    def _format_dep_block(self, dep: dict[str, str], indent: str) -> str:
        """Render a single <dependency> block with a consistent indent."""
        child_indent = indent + "    "
        lines = [
            f"{indent}<dependency>",
            f"{child_indent}<groupId>{dep['group']}</groupId>",
            f"{child_indent}<artifactId>{dep['artifact']}</artifactId>",
            f"{child_indent}<version>{dep['version']}</version>",
        ]
        if "scope" in dep:
            lines.append(f"{child_indent}<scope>{dep['scope']}</scope>")
        lines.append(f"{indent}</dependency>")
        return "\n".join(lines)

    def _detect_maven_namespace(self, root: ET.Element) -> str:
        """Return the Maven XML namespace found in the root tag, or ''."""
        if root.tag.startswith("{"):
            return root.tag.split("}", 1)[0][1:]
        return ""

    def _collect_maven_deps(
        self, root: ET.Element, ns: str,
    ) -> set[tuple[str, str]]:
        """Return (groupId, artifactId) tuples for all declared deps."""
        deps: set[tuple[str, str]] = set()
        prefix = f"{{{ns}}}" if ns else ""

        for dep in root.iter(f"{prefix}dependency"):
            group_el = dep.find(f"{prefix}groupId")
            artifact_el = dep.find(f"{prefix}artifactId")
            if group_el is not None and artifact_el is not None:
                deps.add((group_el.text or "", artifact_el.text or ""))
        return deps

    # ------------------------------------------------------------------
    # Gradle (Groovy DSL only; .kts ships in a follow-up)
    # ------------------------------------------------------------------

    def _ensure_gradle(self) -> InjectionResult:
        build_gradle = self.project_path / "build.gradle"
        if not build_gradle.exists():
            # Check for Kotlin DSL and warn -- unsupported in v0.3.0
            if (self.project_path / "build.gradle.kts").exists():
                return InjectionResult(
                    changed=False, added=[], already_present=[],
                    build_file=self.project_path / "build.gradle.kts",
                    warning="Gradle Kotlin DSL (build.gradle.kts) not yet supported; "
                            "please add Playwright + JUnit 5 manually.",
                )
            return InjectionResult(
                changed=False, added=[], already_present=[],
                warning="build.gradle not found",
            )

        content = build_gradle.read_text(encoding="utf-8")
        needed = self._needed_deps()

        to_add = []
        already_present = []
        for dep in needed:
            coord = f"{dep['group']}:{dep['artifact']}"
            if coord in content:
                already_present.append(coord)
            else:
                to_add.append(dep)

        if not to_add:
            return InjectionResult(
                changed=False, added=[], already_present=already_present,
                build_file=build_gradle,
            )

        # Find `dependencies {` block and append our lines before the closing `}`.
        pattern = re.compile(r"(dependencies\s*\{)([\s\S]*?)(\n\})", re.MULTILINE)
        match = pattern.search(content)

        new_lines = "\n".join(
            f'    {"testImplementation" if dep.get("scope") == "test" else "implementation"} '
            f'"{dep["group"]}:{dep["artifact"]}:{dep["version"]}"'
            for dep in to_add
        )

        if match:
            new_content = (
                content[:match.start()]
                + match.group(1)
                + match.group(2).rstrip("\n")
                + "\n"
                + new_lines
                + match.group(3)
                + content[match.end():]
            )
        else:
            # No dependencies block at all -- append one.
            new_content = content.rstrip() + "\n\ndependencies {\n" + new_lines + "\n}\n"

        build_gradle.write_text(new_content, encoding="utf-8")

        added_labels = [f"{d['group']}:{d['artifact']}:{d['version']}" for d in to_add]
        return InjectionResult(
            changed=True,
            added=added_labels,
            already_present=already_present,
            build_file=build_gradle,
        )

    # ------------------------------------------------------------------
    # Shared
    # ------------------------------------------------------------------

    def _needed_deps(self) -> list[dict[str, str]]:
        """The canonical list of deps required for Playwright + JUnit 5 migration.

        v0.5.3 scope fix: Playwright has NO scope (= compile/main scope)
        because QAMigrate generates page-object and base-class files into
        src/main/java that import com.microsoft.playwright.*. Declaring
        <scope>test</scope> on the Playwright JAR makes it invisible to the
        Maven compiler when processing main-scope sources, causing
        "package com.microsoft.playwright does not exist" for every file.

        JUnit 5 keeps <scope>test</scope> -- test annotations never appear
        in main-scope production code.
        """
        return [
            {
                "group": "com.microsoft.playwright",
                "artifact": "playwright",
                "version": PLAYWRIGHT_VERSION,
                # No scope = default compile scope, visible to src/main/java.
            },
            {
                "group": "org.junit.jupiter",
                "artifact": "junit-jupiter",
                "version": JUNIT_VERSION,
                "scope": "test",
            },
        ]
