"""
Classpath resolver.

Reads a Maven or Gradle project's declared dependencies and returns the
resolved JAR paths that need to be on `javac -cp`. Caches the result in
`.qamigrate/classpath.txt` so we don't shell out to `mvn` twice in the
same run.

Designed to gracefully degrade: if Maven isn't installed, or the resolve
times out, or the project is misconfigured, returns `None` and the
pipeline falls back to skipping compile validation.
"""

from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from pathlib import Path

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class ClasspathResult:
    """Outcome of a classpath resolution attempt."""

    entries: list[Path]  # Empty list when unresolved
    cached: bool  # True if result came from .qamigrate/classpath.txt
    reason: str | None = None  # Populated when we fall back

    @property
    def ok(self) -> bool:
        return bool(self.entries)


class ClasspathResolver:
    """
    Resolve the compile classpath for a Maven or Gradle project.

    Public entry point: `resolve(project_path, build_tool, timeout_seconds)`.
    """

    CACHE_SUBDIR = ".qamigrate"
    CACHE_FILE = "classpath.txt"

    def __init__(self, timeout_seconds: int = 60) -> None:
        self.timeout_seconds = timeout_seconds

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def resolve(
        self,
        project_path: Path,
        build_tool: str,
        *,
        use_cache: bool = True,
    ) -> ClasspathResult:
        """Resolve classpath. Returns entries=[] on any failure."""
        if use_cache:
            cached = self._read_cache(project_path)
            if cached is not None:
                return ClasspathResult(entries=cached, cached=True)

        if build_tool == "maven":
            result = self._resolve_maven(project_path)
        elif build_tool == "gradle":
            result = self._resolve_gradle(project_path)
        else:
            return ClasspathResult(
                entries=[], cached=False,
                reason=f"Unsupported build tool: {build_tool}",
            )

        if result.ok:
            self._write_cache(project_path, result.entries)
        return result

    def clear_cache(self, project_path: Path) -> None:
        """Invalidate the cached classpath (e.g. after editing pom.xml)."""
        cache = project_path / self.CACHE_SUBDIR / self.CACHE_FILE
        if cache.exists():
            cache.unlink()

    # ------------------------------------------------------------------
    # Cache
    # ------------------------------------------------------------------

    def _read_cache(self, project_path: Path) -> list[Path] | None:
        cache = project_path / self.CACHE_SUBDIR / self.CACHE_FILE
        if not cache.exists():
            return None
        try:
            entries = [Path(line) for line in cache.read_text(encoding="utf-8").splitlines() if line.strip()]
            # Sanity check: at least one entry should still exist on disk.
            if entries and any(p.exists() for p in entries):
                return entries
        except (OSError, UnicodeDecodeError) as e:
            logger.warning("Classpath cache unreadable", error=str(e))
        return None

    def _write_cache(self, project_path: Path, entries: list[Path]) -> None:
        cache_dir = project_path / self.CACHE_SUBDIR
        cache_dir.mkdir(exist_ok=True)
        cache = cache_dir / self.CACHE_FILE
        try:
            cache.write_text("\n".join(str(p) for p in entries), encoding="utf-8")
        except OSError as e:  # pragma: no cover
            logger.warning("Failed to write classpath cache", error=str(e))

    # ------------------------------------------------------------------
    # Maven
    # ------------------------------------------------------------------

    def _resolve_maven(self, project_path: Path) -> ClasspathResult:
        """
        Use `mvn -q dependency:build-classpath -Dmdep.outputFile=...` to
        dump the resolved classpath into a file. Read and return it.
        """
        # Write output to a temp file inside the project's .qamigrate/ dir
        # so Maven can actually write to it regardless of cwd.
        workdir = project_path / self.CACHE_SUBDIR
        workdir.mkdir(exist_ok=True)
        output_file = workdir / "mvn-classpath.tmp"
        if output_file.exists():
            output_file.unlink()

        mvn_cmd = "mvn.cmd" if os.name == "nt" else "mvn"
        cmd = [
            mvn_cmd, "-q",
            "dependency:build-classpath",
            f"-Dmdep.outputFile={output_file}",
            "-DincludeScope=test",  # include test-scope deps (junit, etc.)
        ]

        try:
            proc = subprocess.run(
                cmd,
                cwd=str(project_path),
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
            )
        except FileNotFoundError:
            return ClasspathResult(
                entries=[], cached=False,
                reason="Maven (mvn) not found on PATH",
            )
        except subprocess.TimeoutExpired:
            return ClasspathResult(
                entries=[], cached=False,
                reason=f"Maven classpath resolve timed out after {self.timeout_seconds}s",
            )
        except OSError as e:  # pragma: no cover
            return ClasspathResult(
                entries=[], cached=False,
                reason=f"Failed to run Maven: {e}",
            )

        if proc.returncode != 0 or not output_file.exists():
            return ClasspathResult(
                entries=[], cached=False,
                reason=f"Maven exit {proc.returncode}: {proc.stderr[:200].strip()}",
            )

        try:
            content = output_file.read_text(encoding="utf-8").strip()
        except OSError as e:  # pragma: no cover
            return ClasspathResult(
                entries=[], cached=False,
                reason=f"Could not read Maven classpath output: {e}",
            )
        finally:
            # Tidy up the temp file (cached version is separate).
            try:
                output_file.unlink()
            except OSError:
                pass

        # Maven writes one line with OS-specific separator (; on Windows, : on Unix).
        entries = [Path(p) for p in content.split(os.pathsep) if p.strip()]
        return ClasspathResult(entries=entries, cached=False)

    # ------------------------------------------------------------------
    # Gradle (deferred to v0.3.1+)
    # ------------------------------------------------------------------

    def _resolve_gradle(self, project_path: Path) -> ClasspathResult:
        """
        Gradle classpath resolution is deferred to a follow-up release --
        it requires either a custom init script or a helper task in the
        user's build file, both of which are invasive.

        For now, return None so the pipeline falls back to skip-compile.
        """
        return ClasspathResult(
            entries=[], cached=False,
            reason="Gradle classpath resolution is not yet supported (planned for v0.3.1). "
                   "Run `./gradlew dependencies --configuration testCompileClasspath` manually "
                   "and re-run QAMigrate with --no-batch-compile if you need compile validation.",
        )
