"""
Scanner Agent.

Performs deterministic analysis of the source Selenium codebase using
Tree-sitter for AST extraction and pattern detection.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

from qamigrate.core.config import ScannerConfig
from qamigrate.core.parser import JavaParser, QueryMatch, get_parser
from qamigrate.core.patterns import SELENIUM_PATTERNS, SeleniumPattern

logger = structlog.get_logger(__name__)


@dataclass
class DetectedPattern:
    """A detected Selenium pattern in the source code."""

    pattern_type: str
    category: str
    file_path: str
    line_number: int
    code_snippet: str
    migration_strategy: str
    playwright_equivalent: str
    complexity_score: int


@dataclass
class FileAnalysis:
    """Analysis results for a single file."""

    file_path: str
    class_info: dict[str, Any]
    patterns: list[DetectedPattern]
    complexity_score: int
    is_page_object: bool
    is_test_class: bool


@dataclass
class ScanResult:
    """Complete scan output for a project."""

    project_path: str
    project_manifest: dict[str, Any]
    file_analyses: list[FileAnalysis]
    patterns: list[DetectedPattern]
    dependency_graph: dict[str, list[str]]
    complexity_scores: dict[str, int]

    # Summary statistics
    file_count: int = 0
    page_object_count: int = 0
    test_class_count: int = 0
    pattern_summary: dict[str, int] = field(default_factory=dict)
    complexity_distribution: dict[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Calculate summary statistics."""
        self.file_count = len(self.file_analyses)
        self.page_object_count = sum(1 for f in self.file_analyses if f.is_page_object)
        self.test_class_count = sum(1 for f in self.file_analyses if f.is_test_class)

        # Pattern summary
        for pattern in self.patterns:
            self.pattern_summary[pattern.pattern_type] = (
                self.pattern_summary.get(pattern.pattern_type, 0) + 1
            )

        # Complexity distribution
        low = medium = high = 0
        for score in self.complexity_scores.values():
            if score <= 3:
                low += 1
            elif score <= 6:
                medium += 1
            else:
                high += 1
        self.complexity_distribution = {"low": low, "medium": medium, "high": high}

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "project_path": self.project_path,
            "project_manifest": self.project_manifest,
            "file_count": self.file_count,
            "page_object_count": self.page_object_count,
            "test_class_count": self.test_class_count,
            "pattern_summary": self.pattern_summary,
            "complexity_distribution": self.complexity_distribution,
            "patterns": [
                {
                    "pattern_type": p.pattern_type,
                    "category": p.category,
                    "file_path": p.file_path,
                    "line_number": p.line_number,
                    "code_snippet": p.code_snippet[:100],  # Truncate for JSON
                    "migration_strategy": p.migration_strategy,
                    "complexity_score": p.complexity_score,
                }
                for p in self.patterns
            ],
            "files": [
                {
                    "file_path": f.file_path,
                    "class_name": f.class_info.get("class_name"),
                    "is_page_object": f.is_page_object,
                    "is_test_class": f.is_test_class,
                    "complexity_score": f.complexity_score,
                    "pattern_count": len(f.patterns),
                }
                for f in self.file_analyses
            ],
            "dependency_graph": self.dependency_graph,
        }


class ScannerAgent:
    """
    Deterministic code analysis using Tree-sitter.

    No LLM required - pure symbolic parsing.
    """

    def __init__(self, config: ScannerConfig | None = None) -> None:
        """Initialize scanner with configuration."""
        self.config = config or ScannerConfig()
        self.parser: JavaParser = get_parser()
        self.patterns = SELENIUM_PATTERNS

    def scan_project(self, project_path: Path) -> ScanResult:
        """
        Complete project analysis entry point.

        Args:
            project_path: Root path of the Selenium project

        Returns:
            ScanResult with complete analysis
        """
        logger.info("Starting project scan", project_path=str(project_path))

        # Parse project configuration
        manifest = self._parse_project_config(project_path)

        # Find all Java files
        java_files = self._find_java_files(project_path)
        logger.info("Found Java files", count=len(java_files))

        # Analyze each file
        file_analyses: list[FileAnalysis] = []
        all_patterns: list[DetectedPattern] = []
        complexity_scores: dict[str, int] = {}

        for java_file in java_files:
            try:
                analysis = self._analyze_file(java_file)
                file_analyses.append(analysis)
                all_patterns.extend(analysis.patterns)
                complexity_scores[str(java_file)] = analysis.complexity_score
            except Exception as e:
                logger.warning("Failed to analyze file", file=str(java_file), error=str(e))

        # Build dependency graph
        dependency_graph = self._build_dependency_graph(file_analyses)

        result = ScanResult(
            project_path=str(project_path),
            project_manifest=manifest,
            file_analyses=file_analyses,
            patterns=all_patterns,
            dependency_graph=dependency_graph,
            complexity_scores=complexity_scores,
        )

        logger.info(
            "Scan complete",
            files=result.file_count,
            patterns=len(all_patterns),
            page_objects=result.page_object_count,
            test_classes=result.test_class_count,
        )

        return result

    def scan_file(self, file_path: Path) -> FileAnalysis:
        """
        Analyze a single Java file.

        Args:
            file_path: Path to the Java file

        Returns:
            FileAnalysis with patterns and class info
        """
        return self._analyze_file(file_path)

    def _find_java_files(self, project_path: Path) -> list[Path]:
        """Find all Java files matching include/exclude patterns."""
        java_files: list[Path] = []

        for pattern in self.config.include_patterns:
            for file_path in project_path.rglob(pattern.replace("**/", "")):
                if file_path.suffix == ".java":
                    # Check exclusions
                    excluded = False
                    for exclude in self.config.exclude_patterns:
                        exclude_part = exclude.replace("**/", "").replace("/**", "")
                        if exclude_part in str(file_path):
                            excluded = True
                            break

                    if not excluded:
                        # Check file size
                        if file_path.stat().st_size <= self.config.max_file_size_kb * 1024:
                            java_files.append(file_path)

        return java_files

    def _analyze_file(self, file_path: Path) -> FileAnalysis:
        """Analyze a single Java file."""
        # Extract class information
        class_info = self.parser.extract_class_info(file_path)

        # Detect Selenium patterns
        patterns = self._detect_patterns(file_path)

        # Determine file type
        is_page_object = self._is_page_object(class_info, patterns)
        is_test_class = self._is_test_class(class_info)

        # Calculate complexity
        complexity = self._calculate_complexity(patterns, class_info)

        return FileAnalysis(
            file_path=str(file_path),
            class_info=class_info,
            patterns=patterns,
            complexity_score=complexity,
            is_page_object=is_page_object,
            is_test_class=is_test_class,
        )

    def _detect_patterns(self, file_path: Path) -> list[DetectedPattern]:
        """Detect Selenium patterns in a file."""
        detected: list[DetectedPattern] = []
        source = file_path.read_bytes()

        for name, pattern in self.patterns.items():
            try:
                matches = self.parser.query(source, pattern.query)
                for node, _ in matches:
                    detected.append(
                        DetectedPattern(
                            pattern_type=name,
                            category=pattern.category.value,
                            file_path=str(file_path),
                            line_number=node.start_point[0] + 1,
                            code_snippet=node.text.decode("utf-8") if node.text else "",
                            migration_strategy=pattern.migration_strategy,
                            playwright_equivalent=pattern.playwright_equivalent,
                            complexity_score=pattern.complexity,
                        )
                    )
            except Exception:
                # Skip patterns with query errors
                continue

        return detected

    def _is_page_object(
        self, class_info: dict[str, Any], patterns: list[DetectedPattern]
    ) -> bool:
        """Determine if a class is a Page Object."""
        # Check for @FindBy annotations
        has_findby = any(p.pattern_type == "FindBy" for p in patterns)
        if has_findby:
            return True

        # Check for Page in class name
        class_name = class_info.get("class_name", "")
        if class_name and ("Page" in class_name or "page" in class_name.lower()):
            return True

        # Check for PageFactory usage
        has_page_factory = any(
            p.pattern_type == "PageFactory_initElements" for p in patterns
        )
        if has_page_factory:
            return True

        return False

    def _is_test_class(self, class_info: dict[str, Any]) -> bool:
        """Determine if a class is a test class."""
        # Check class name
        class_name = class_info.get("class_name", "")
        if class_name and ("Test" in class_name or "test" in class_name.lower()):
            return True

        # Check for test annotations
        annotations = class_info.get("annotations", [])
        test_annotations = ["@Test", "@BeforeTest", "@AfterTest", "@BeforeMethod", "@AfterMethod"]
        for annotation in annotations:
            if any(ta in annotation for ta in test_annotations):
                return True

        # Check method annotations
        for method in class_info.get("methods", []):
            for annotation in method.get("annotations", []):
                if "@Test" in annotation:
                    return True

        return False

    def _calculate_complexity(
        self, patterns: list[DetectedPattern], class_info: dict[str, Any]
    ) -> int:
        """Calculate migration complexity score for a file."""
        # Base complexity from patterns
        pattern_complexity = sum(p.complexity_score for p in patterns)

        # Method count factor
        method_count = len(class_info.get("methods", []))
        method_factor = min(method_count // 5, 3)

        # Field count factor
        field_count = len(class_info.get("fields", []))
        field_factor = min(field_count // 10, 2)

        total = pattern_complexity + method_factor + field_factor

        # Normalize to 1-10 scale
        return min(max(total // 5, 1), 10)

    def _build_dependency_graph(
        self, analyses: list[FileAnalysis]
    ) -> dict[str, list[str]]:
        """Build dependency graph between classes."""
        graph: dict[str, list[str]] = {}
        class_to_file: dict[str, str] = {}

        # Map class names to file paths
        for analysis in analyses:
            class_name = analysis.class_info.get("class_name")
            if class_name:
                class_to_file[class_name] = analysis.file_path

        # Build dependency edges from imports
        for analysis in analyses:
            dependencies: list[str] = []
            imports = analysis.class_info.get("imports", [])

            for imp in imports:
                # Get class name from import
                class_name = imp.split(".")[-1]
                if class_name in class_to_file:
                    dependencies.append(class_to_file[class_name])

            graph[analysis.file_path] = dependencies

        return graph

    def _parse_project_config(self, project_path: Path) -> dict[str, Any]:
        """Parse project build configuration."""
        manifest: dict[str, Any] = {
            "name": project_path.name,
            "build_tool": "unknown",
            "java_version": None,
            "test_framework": None,
            "selenium_version": None,
            "dependencies": [],
        }

        # Check for Maven
        pom_xml = project_path / "pom.xml"
        if pom_xml.exists():
            manifest["build_tool"] = "maven"
            manifest.update(self._parse_pom_xml(pom_xml))

        # Check for Gradle
        build_gradle = project_path / "build.gradle"
        if build_gradle.exists():
            manifest["build_tool"] = "gradle"
            manifest.update(self._parse_build_gradle(build_gradle))

        return manifest

    def _parse_pom_xml(self, pom_path: Path) -> dict[str, Any]:
        """Parse Maven pom.xml for dependencies."""
        import xml.etree.ElementTree as ET

        result: dict[str, Any] = {"dependencies": []}

        try:
            tree = ET.parse(pom_path)
            root = tree.getroot()

            # Handle namespace
            ns = {"m": "http://maven.apache.org/POM/4.0.0"}

            # Find dependencies (with or without Maven namespace)
            deps = root.findall(".//m:dependency", ns)
            if not deps:
                deps = root.findall(".//dependency")
            for dep in deps:
                group = dep.find("m:groupId", ns)
                if group is None:
                    group = dep.find("groupId")
                artifact = dep.find("m:artifactId", ns)
                if artifact is None:
                    artifact = dep.find("artifactId")
                version = dep.find("m:version", ns)
                if version is None:
                    version = dep.find("version")

                if group is not None and artifact is not None:
                    dep_info = {
                        "group": group.text,
                        "artifact": artifact.text,
                        "version": version.text if version is not None else None,
                    }
                    result["dependencies"].append(dep_info)

                    # Check for Selenium
                    if artifact.text and "selenium" in artifact.text:
                        result["selenium_version"] = version.text if version is not None else "unknown"

                    # Check for TestNG/JUnit
                    if artifact.text:
                        if "testng" in artifact.text:
                            result["test_framework"] = "testng"
                        elif "junit" in artifact.text:
                            result["test_framework"] = "junit"

        except Exception as e:
            logger.warning("Failed to parse pom.xml", error=str(e))

        return result

    def _parse_build_gradle(self, gradle_path: Path) -> dict[str, Any]:
        """Parse Gradle build.gradle for dependencies."""
        result: dict[str, Any] = {"dependencies": []}

        try:
            content = gradle_path.read_text()

            # Simple regex-based parsing for dependencies
            import re

            dep_pattern = r"(implementation|testImplementation)\s+['\"]([^'\"]+)['\"]"
            matches = re.findall(dep_pattern, content)

            for scope, dep in matches:
                parts = dep.split(":")
                if len(parts) >= 2:
                    dep_info = {
                        "group": parts[0],
                        "artifact": parts[1],
                        "version": parts[2] if len(parts) > 2 else None,
                    }
                    result["dependencies"].append(dep_info)

                    # Check for Selenium
                    if "selenium" in dep:
                        result["selenium_version"] = dep_info.get("version", "unknown")

                    # Check for TestNG/JUnit
                    if "testng" in dep:
                        result["test_framework"] = "testng"
                    elif "junit" in dep:
                        result["test_framework"] = "junit"

        except Exception as e:
            logger.warning("Failed to parse build.gradle", error=str(e))

        return result
