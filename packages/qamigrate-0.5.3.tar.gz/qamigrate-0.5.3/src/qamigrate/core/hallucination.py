"""
Cross-file hallucination detector.

Scans generated Java code for method calls on sibling classes that do not
exist in those classes' public APIs. We flag these as `Hallucination`s so
the user sees them in the report, even if we can't auto-fix them yet.

v0.5.1 extends this to CSS selectors: when a test uses
`page.locator("#x")` directly, we verify `#x` was declared in one of the
page objects the test imports. Otherwise the LLM has invented a selector
that doesn't exist on the page.

v0.5.2(b) further extends this to `.getByTestId("...")`. We deliberately
do NOT extend to `getByRole/Text/Label/Placeholder/AltText/Title` --
those validate against ARIA / accessible-name semantics, not a
declarative inventory in the page object, so cross-file comparison
produces false-positive noise that erodes trust in the detector.
Test-ids are the one case where the page object declares a specific
string and tests should reuse it verbatim.
"""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field

from qamigrate.core.report import Hallucination

# Matches `variableOrType.methodName(` in Java source.
# Examples that match:  loginPage.getErrorMessage(  page.locator(  Assert.assertTrue(
# This is intentionally loose -- we filter to the interesting targets
# afterwards using the sibling class list.
_METHOD_CALL_RE = re.compile(r"([A-Za-z_]\w*)\s*\.\s*([A-Za-z_]\w*)\s*\(")

# Matches `page.locator("<selector>")` -- captures the selector literal.
# Intentionally only matches double-quoted string literals; Playwright Java
# always uses String, so this is exhaustive in practice.
_LOCATOR_CALL_RE = re.compile(r"""\.\s*locator\s*\(\s*"([^"\\]*(?:\\.[^"\\]*)*)"\s*[),]""")

# v0.5.2(b): matches `page.getByTestId("<id>")`. Same-shape regex, different verb.
_TESTID_CALL_RE = re.compile(r"""\.\s*getByTestId\s*\(\s*"([^"\\]*(?:\\.[^"\\]*)*)"\s*[),]""")


@dataclass(frozen=True)
class DeclaredSelectors:
    """Per-class catalogue of selector strings the page object declares.

    Split by entry point (CSS vs test-id) because they must NEVER be
    cross-validated -- a test-id literal `submit-btn` is not a CSS
    selector, and vice versa.
    """

    css: set[str] = field(default_factory=set)
    testids: set[str] = field(default_factory=set)

    @property
    def is_empty(self) -> bool:
        return not self.css and not self.testids


def _extract_method_names(signatures: list[str]) -> set[str]:
    """Pull just the method names out of a list of Java signatures."""
    names: set[str] = set()
    for sig in signatures:
        # grab the last token before `(`
        match = re.search(r"([A-Za-z_]\w*)\s*\(", sig)
        if match:
            names.add(match.group(1))
    return names


def _find_variables_of_type(source: str, class_name: str) -> set[str]:
    """
    Find local variables / fields in `source` that are declared as `class_name`.
    Returns the set of variable names.

    Only considers declarations where `ClassName` and the variable name appear
    on the same statement (separated by horizontal whitespace only), followed
    by `=`, `;`, `,`, `)`, or `<` (generics). This avoids false positives on
    comments or unrelated text that just happen to contain the class name.
    """
    names: set[str] = set()
    escaped = re.escape(class_name)
    # Same-line declaration: `ClassName varName[=;,)<]`
    # [^\S\n] = "whitespace but not newline" = just spaces/tabs
    pattern = rf"\b{escaped}[^\S\n]+([a-zA-Z_]\w*)\s*[=;,)<]"
    for m in re.finditer(pattern, source):
        names.add(m.group(1))
    return names


def detect_hallucinations(
    generated_code: str,
    sibling_signatures: dict[str, list[str]],
) -> list[Hallucination]:
    """
    Scan `generated_code` for method calls on variables whose types appear in
    `sibling_signatures`, and flag any calls that are not in the known
    signatures for that class.

    This is conservative: we only flag calls on variables we've confidently
    typed. Calls on unknown receivers (like `page.foo()` where `page` has no
    declaration in the file) are ignored -- we can't tell what class that is.
    """
    if not sibling_signatures or not generated_code:
        return []

    results: list[Hallucination] = []

    # For each sibling class, build (variable names that hold it, allowed methods)
    for cls, sigs in sibling_signatures.items():
        var_names = _find_variables_of_type(generated_code, cls)
        if not var_names:
            continue

        allowed_methods = _extract_method_names(sigs)
        if not allowed_methods:
            # If we have no signatures at all, we can't validate -- skip.
            continue

        for match in _METHOD_CALL_RE.finditer(generated_code):
            receiver, called = match.group(1), match.group(2)
            if receiver not in var_names:
                continue
            if called in allowed_methods:
                continue
            # Hallucination candidate: find closest real method for a hint.
            close = difflib.get_close_matches(called, allowed_methods, n=1, cutoff=0.6)
            similar = close[0] if close else None
            results.append(
                Hallucination(
                    called_method=f"{cls}.{called}()",
                    on_class=cls,
                    similar_to=f"{cls}.{similar}()" if similar else None,
                )
            )

    # De-duplicate preserving order
    seen: set[tuple[str, str]] = set()
    unique: list[Hallucination] = []
    for h in results:
        key = (h.on_class, h.called_method)
        if key not in seen:
            seen.add(key)
            unique.append(h)
    return unique


def extract_declared_locators(generated_code: str) -> set[str]:
    """
    Return the set of CSS/XPath selectors inside `.locator("...")` calls.

    Kept for backward compatibility. New callers should prefer
    `extract_declared_selectors` which also captures test-ids.
    """
    if not generated_code:
        return set()
    return {m.group(1) for m in _LOCATOR_CALL_RE.finditer(generated_code)}


def extract_declared_selectors(generated_code: str) -> DeclaredSelectors:
    """v0.5.2(b): return both `.locator(...)` and `.getByTestId(...)`
    strings from a page object, keyed by entry point."""
    if not generated_code:
        return DeclaredSelectors()
    return DeclaredSelectors(
        css={m.group(1) for m in _LOCATOR_CALL_RE.finditer(generated_code)},
        testids={m.group(1) for m in _TESTID_CALL_RE.finditer(generated_code)},
    )


def _imported_page_classes(source: str, sibling_locators) -> set[str]:
    """
    Return the subset of `sibling_locators` keys that appear to be used by
    this source file. A class is considered "in use" if it appears in an
    import or as a field/variable type.

    Accepts any dict-like whose keys are class names (the values aren't
    inspected here).
    """
    used: set[str] = set()
    for cls in sibling_locators:
        escaped = re.escape(cls)
        # Import statement or type appearance (word-boundary match)
        if re.search(rf"\b{escaped}\b", source):
            used.add(cls)
    return used


def detect_selector_hallucinations(
    generated_code: str,
    sibling_locators: dict[str, set[str]] | dict[str, DeclaredSelectors],
) -> list[Hallucination]:
    """
    Flag `page.locator(...)` and `page.getByTestId(...)` calls whose
    string isn't declared in any sibling page object the file uses.

    Accepts two shapes for backward compatibility:
    - `dict[str, set[str]]` (v0.5.1): CSS-only, treats the set as CSS selectors.
    - `dict[str, DeclaredSelectors]` (v0.5.2): split by kind.

    Catches the v0.5.0 failure mode where the Coder invents CSS
    selectors (`#success-indicator`) or test-ids (`submit-btn` when the
    page declares `submit`) that don't exist on the page object.

    Conservative: only flags selectors when the file clearly references
    a sibling class with at least one declared selector. Never
    cross-compares CSS against test-ids (categorically different).
    """
    if not generated_code or not sibling_locators:
        return []

    # Normalize input to dict[str, DeclaredSelectors].
    normalized: dict[str, DeclaredSelectors] = {}
    for cls, value in sibling_locators.items():
        if isinstance(value, DeclaredSelectors):
            normalized[cls] = value
        elif isinstance(value, set):
            # Legacy: treat bare sets as CSS selectors only.
            normalized[cls] = DeclaredSelectors(css=value, testids=set())
        else:  # pragma: no cover - defensive
            continue

    used_classes = _imported_page_classes(generated_code, normalized)
    if not used_classes:
        return []

    # Union per kind across page objects this file touches.
    known_css: set[str] = set()
    known_testids: set[str] = set()
    for cls in used_classes:
        known_css |= normalized[cls].css
        known_testids |= normalized[cls].testids

    if not known_css and not known_testids:
        return []

    blamed_class = sorted(used_classes)[0]
    results: list[Hallucination] = []

    if known_css:
        results.extend(
            _detect_invented_selectors(
                generated_code=generated_code,
                pattern=_LOCATOR_CALL_RE,
                known=known_css,
                verb="locator",
                on_class=blamed_class,
                verifiable=_selector_is_verifiable,
            )
        )

    if known_testids:
        # Test-ids are ALWAYS verifiable (no "bare tag" case exists) --
        # page objects declare them explicitly as arbitrary strings.
        results.extend(
            _detect_invented_selectors(
                generated_code=generated_code,
                pattern=_TESTID_CALL_RE,
                known=known_testids,
                verb="getByTestId",
                on_class=blamed_class,
                verifiable=lambda s: bool(s) and "${" not in s and "%s" not in s,
            )
        )

    return results


def _detect_invented_selectors(
    *,
    generated_code: str,
    pattern: re.Pattern[str],
    known: set[str],
    verb: str,
    on_class: str,
    verifiable,
) -> list[Hallucination]:
    """Shared body for CSS-selector and test-id detection."""
    results: list[Hallucination] = []
    seen: set[str] = set()
    for m in pattern.finditer(generated_code):
        value = m.group(1)
        if value in known or value in seen:
            continue
        seen.add(value)
        if not verifiable(value):
            continue
        close = difflib.get_close_matches(value, known, n=1, cutoff=0.6)
        similar = close[0] if close else None
        results.append(
            Hallucination(
                called_method=f'page.{verb}("{value}")',
                on_class=on_class,
                similar_to=f'page.{verb}("{similar}")' if similar else None,
            )
        )
    return results


def _selector_is_verifiable(selector: str) -> bool:
    """
    Decide whether a locator string is specific enough that we can assert
    it should match a declared selector. We skip generic selectors (bare
    tag names) and anything with template/interpolation markers.
    """
    if not selector or "${" in selector or "%s" in selector:
        return False
    stripped = selector.strip()
    # Specific enough: id, class, attribute, xpath, or Playwright engine.
    return any(stripped.startswith(p) for p in ("#", ".", "[", "//", "xpath=", "text=", "role="))
