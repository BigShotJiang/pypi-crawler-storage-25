"""
Confidence gate (v0.5.2c).

Opt-in post-run quality gate for the `migrate` command. When a threshold
is supplied, the CLI exits with code 2 if the gate breaches -- distinct
from the exit-1 "migration broke" code so CI can react differently to
"quality below bar" vs "tool failed".

Two modes:
- `any` (default, strict): any single file below threshold fails the run.
  Good default for CI on a PR: one bad file blocks merge.
- `avg`: only the project-wide average must clear the bar. Useful for
  large migrations where a handful of hard files is tolerable if the
  overall quality is good.

We put this in `core/` (not `cli/`) so the logic is unit-testable
without Typer's CliRunner.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from qamigrate.core.report import MigrationRecord, MigrationReport


@dataclass(frozen=True)
class GateResult:
    """Outcome of evaluating the confidence gate."""

    passed: bool
    message: str
    offending_records: list[MigrationRecord] = field(default_factory=list)
    error: str | None = None  # set when inputs were invalid


def evaluate_confidence_gate(
    report: MigrationReport,
    *,
    threshold: int,
    mode: str = "any",
) -> GateResult:
    """
    Return a GateResult describing whether the report clears `threshold`.

    `mode` must be "any" or "avg". Any other value returns an error
    result (the CLI surfaces this as a usage error, not a gate breach).

    A passing result has `passed=True` and `offending_records=[]`.
    A failing result has `passed=False` and `offending_records` set
    when mode="any" (empty when mode="avg" -- the problem is systemic).
    """
    normalized = mode.lower().strip() if isinstance(mode, str) else ""
    if normalized not in ("any", "avg"):
        return GateResult(
            passed=False,
            message="",
            error=(
                f"Invalid --confidence-mode {mode!r}. Expected 'any' or 'avg'."
            ),
        )

    if normalized == "avg":
        avg = report.average_confidence
        if avg < threshold:
            return GateResult(
                passed=False,
                message=(
                    f"project average {avg}% is below threshold {threshold}%."
                ),
            )
        return GateResult(passed=True, message="ok")

    # mode == "any"
    below = [
        r for r in report.records
        if r.success and r.confidence < threshold
    ]
    if below:
        return GateResult(
            passed=False,
            message=(
                f"{len(below)} file(s) below threshold {threshold}%:"
            ),
            offending_records=below,
        )
    return GateResult(passed=True, message="ok")
