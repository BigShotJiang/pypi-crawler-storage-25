"""Core configuration module for QAMigrate."""

from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# Load .env file from current directory or project root
load_dotenv()


class PipelineConfig(BaseModel):
    """Pipeline orchestration settings."""

    max_retries: int = Field(default=3, description="Maximum fix attempts before failing")
    batch_compile: bool = Field(
        default=True,
        description="Compile all generated files together (v0.3+). Set False "
                    "to fall back to the v0.2 per-file compile loop.",
    )


class ClasspathConfig(BaseModel):
    """Build-system classpath resolution settings (v0.3+)."""

    timeout_seconds: int = Field(default=60, description="Max time for `mvn dependency:build-classpath`")
    use_cache: bool = Field(default=True, description="Reuse .qamigrate/classpath.txt if present")


class ScannerConfig(BaseModel):
    """Configuration for the Scanner Agent."""

    include_patterns: list[str] = Field(default=["**/*.java"])
    exclude_patterns: list[str] = Field(default=["**/target/**", "**/build/**", "**/playwright/**"])
    max_file_size_kb: int = Field(default=500)


class CoderConfig(BaseModel):
    """Configuration for the Coder Agent."""

    provider: str = Field(
        default="anthropic",
        description="LLM provider name: 'anthropic', 'openai', etc. Must be registered in qamigrate.llm.registry.",
    )
    model: str = Field(default="claude-sonnet-4-20250514")
    temperature: float = Field(default=0.1)
    max_tokens: int = Field(default=8192)


class CompilerConfig(BaseModel):
    """Configuration for the Compiler Agent."""

    build_tool: str = Field(default="maven")
    timeout_seconds: int = Field(default=120)
    java_version: str = Field(default="17")
    skip: bool = Field(default=False, description="Skip compilation validation (useful when Playwright JARs not available locally)")


class FixerConfig(BaseModel):
    """Configuration for the Fixer Agent."""

    provider: str = Field(
        default="anthropic",
        description="LLM provider name: 'anthropic', 'openai', etc. Must be registered in qamigrate.llm.registry.",
    )
    model: str = Field(default="claude-sonnet-4-20250514")
    max_fix_attempts: int = Field(default=3)
    use_rule_based_first: bool = Field(default=True)
    group_similar_errors: bool = Field(default=True)


class AnthropicProviderSettings(BaseModel):
    """Provider-specific settings for Anthropic."""

    api_key_env: str = Field(default="ANTHROPIC_API_KEY")


class OpenAIProviderSettings(BaseModel):
    """Provider-specific settings for OpenAI (including Azure/proxy setups)."""

    api_key_env: str = Field(default="OPENAI_API_KEY")
    base_url: str | None = Field(
        default=None,
        description="Override the OpenAI base URL (e.g. for Azure OpenAI or a proxy).",
    )


class OllamaProviderSettings(BaseModel):
    """Provider-specific settings for Ollama (local models)."""

    host: str = Field(default="http://localhost:11434")
    request_timeout_s: int = Field(default=120)


class LLMProvidersConfig(BaseModel):
    """
    Top-level settings for each supported LLM provider.

    Users customize auth / base URL / host here; agent-level config picks
    which provider+model to use. Every provider has a sensible default
    that works out of the box for the standard setup.
    """

    anthropic: AnthropicProviderSettings = Field(default_factory=AnthropicProviderSettings)
    openai: OpenAIProviderSettings = Field(default_factory=OpenAIProviderSettings)
    ollama: OllamaProviderSettings = Field(default_factory=OllamaProviderSettings)


class LLMConfig(BaseModel):
    """Top-level LLM settings (provider-specific auth, URLs, etc.)."""

    providers: LLMProvidersConfig = Field(default_factory=LLMProvidersConfig)


class LoggingConfig(BaseModel):
    """Configuration for logging."""

    level: str = Field(default="INFO")
    format: str = Field(default="json")
    file: str | None = Field(default=None)


class ArtifactConfig(BaseModel):
    """Configuration for artifact management."""

    output_dir: str = Field(default="./qamigrate-output")
    retention_days: int = Field(default=7)
    compress: bool = Field(default=True)


class QAMigrateConfig(BaseSettings):
    """Complete configuration for QAMigrate."""

    model_config = SettingsConfigDict(
        env_prefix="QAMIGRATE_",
        env_nested_delimiter="__",
    )

    pipeline: PipelineConfig = Field(default_factory=PipelineConfig)
    scanner: ScannerConfig = Field(default_factory=ScannerConfig)
    coder: CoderConfig = Field(default_factory=CoderConfig)
    compiler: CompilerConfig = Field(default_factory=CompilerConfig)
    fixer: FixerConfig = Field(default_factory=FixerConfig)
    classpath: ClasspathConfig = Field(default_factory=ClasspathConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    artifacts: ArtifactConfig = Field(default_factory=ArtifactConfig)

    # API Keys (loaded from environment)
    anthropic_api_key: str | None = Field(default=None, alias="ANTHROPIC_API_KEY")

    @classmethod
    def load(cls, config_path: Path | None = None) -> "QAMigrateConfig":
        """Load configuration from YAML file and environment variables."""
        config_data: dict[str, Any] = {}

        if config_path is None:
            config_path = Path.cwd() / "qamigrate.yaml"

        if config_path.exists():
            with open(config_path) as f:
                config_data = yaml.safe_load(f) or {}

        return cls(**config_data)


def get_config(config_path: Path | None = None) -> QAMigrateConfig:
    """Get configuration instance."""
    return QAMigrateConfig.load(config_path)
