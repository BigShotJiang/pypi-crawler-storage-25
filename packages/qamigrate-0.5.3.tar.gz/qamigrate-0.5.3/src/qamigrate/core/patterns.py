"""
Selenium Pattern Definitions for Detection.

Tree-sitter queries and migration strategies for common Selenium patterns.
"""

from dataclasses import dataclass
from enum import Enum


class PatternCategory(str, Enum):
    """Categories of Selenium patterns."""

    LOCATOR = "locator"
    WAIT = "wait"
    ACTION = "action"
    ASSERTION = "assertion"
    DRIVER = "driver"
    PAGE_FACTORY = "page_factory"


@dataclass
class SeleniumPattern:
    """Definition of a Selenium pattern to detect."""

    name: str
    category: PatternCategory
    query: str  # Tree-sitter query
    migration_strategy: str
    playwright_equivalent: str
    complexity: int  # 1-10 scale


# Tree-sitter queries for Selenium pattern detection
SELENIUM_PATTERNS: dict[str, SeleniumPattern] = {
    # Page Factory Patterns
    "FindBy": SeleniumPattern(
        name="FindBy",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "FindBy"))',
        migration_strategy="Convert to page.locator() with CSS/XPath selector stored as Locator field",
        playwright_equivalent="private Locator element = page.locator(selector);",
        complexity=3,
    ),
    "FindBys": SeleniumPattern(
        name="FindBys",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "FindBys"))',
        migration_strategy="Convert to chained page.locator() calls",
        playwright_equivalent="page.locator(parent).locator(child)",
        complexity=4,
    ),
    "FindAll": SeleniumPattern(
        name="FindAll",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "FindAll"))',
        migration_strategy="Convert to page.locator() returning multiple elements",
        playwright_equivalent="page.locator(selector).all()",
        complexity=4,
    ),
    "PageFactory_initElements": SeleniumPattern(
        name="PageFactory.initElements",
        category=PatternCategory.PAGE_FACTORY,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "PageFactory") name: (identifier) @method (#eq? @method "initElements"))',
        migration_strategy="Remove entirely - Playwright uses direct Page injection",
        playwright_equivalent="// Removed - Page injected via constructor",
        complexity=2,
    ),
    # Wait Patterns
    "WebDriverWait": SeleniumPattern(
        name="WebDriverWait",
        category=PatternCategory.WAIT,
        query='(object_creation_expression type: (type_identifier) @type (#eq? @type "WebDriverWait"))',
        migration_strategy="Remove explicit wait - Playwright auto-waits for actionability",
        playwright_equivalent="// Removed - Playwright auto-waits",
        complexity=2,
    ),
    "FluentWait": SeleniumPattern(
        name="FluentWait",
        category=PatternCategory.WAIT,
        query='(object_creation_expression type: (generic_type (type_identifier) @type) (#eq? @type "FluentWait"))',
        migration_strategy="Replace with Playwright's expect() for polling assertions",
        playwright_equivalent="expect(locator).toBeVisible({ timeout: 10000 });",
        complexity=4,
    ),
    "ExpectedConditions": SeleniumPattern(
        name="ExpectedConditions",
        category=PatternCategory.WAIT,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "ExpectedConditions"))',
        migration_strategy="Replace with Playwright assertions or locator methods",
        playwright_equivalent="assertThat(locator).isVisible();",
        complexity=3,
    ),
    "Thread_sleep": SeleniumPattern(
        name="Thread.sleep",
        category=PatternCategory.WAIT,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "Thread") name: (identifier) @method (#eq? @method "sleep"))',
        migration_strategy="Remove or replace with page.waitForTimeout() only if absolutely necessary",
        playwright_equivalent="// Removed - use Playwright auto-wait instead",
        complexity=1,
    ),
    # Driver Patterns
    "WebDriver": SeleniumPattern(
        name="WebDriver",
        category=PatternCategory.DRIVER,
        query='(local_variable_declaration type: (type_identifier) @type (#eq? @type "WebDriver"))',
        migration_strategy="Replace with Playwright Page and BrowserContext",
        playwright_equivalent="Page page; BrowserContext context;",
        complexity=5,
    ),
    "ChromeDriver": SeleniumPattern(
        name="ChromeDriver",
        category=PatternCategory.DRIVER,
        query='(object_creation_expression type: (type_identifier) @type (#eq? @type "ChromeDriver"))',
        migration_strategy="Replace with Playwright browser launch",
        playwright_equivalent="Browser browser = playwright.chromium().launch();",
        complexity=5,
    ),
    "FirefoxDriver": SeleniumPattern(
        name="FirefoxDriver",
        category=PatternCategory.DRIVER,
        query='(object_creation_expression type: (type_identifier) @type (#eq? @type "FirefoxDriver"))',
        migration_strategy="Replace with Playwright Firefox",
        playwright_equivalent="Browser browser = playwright.firefox().launch();",
        complexity=5,
    ),
    "RemoteWebDriver": SeleniumPattern(
        name="RemoteWebDriver",
        category=PatternCategory.DRIVER,
        query='(object_creation_expression type: (type_identifier) @type (#eq? @type "RemoteWebDriver"))',
        migration_strategy="Replace with Playwright connect() for remote browsers",
        playwright_equivalent="Browser browser = playwright.chromium().connect(wsEndpoint);",
        complexity=6,
    ),
    # Locator Patterns
    "By_id": SeleniumPattern(
        name="By.id",
        category=PatternCategory.LOCATOR,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "By") name: (identifier) @method (#eq? @method "id"))',
        migration_strategy="Convert to CSS selector with #id",
        playwright_equivalent='page.locator("#elementId")',
        complexity=1,
    ),
    "By_className": SeleniumPattern(
        name="By.className",
        category=PatternCategory.LOCATOR,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "By") name: (identifier) @method (#eq? @method "className"))',
        migration_strategy="Convert to CSS selector with .class",
        playwright_equivalent='page.locator(".className")',
        complexity=1,
    ),
    "By_cssSelector": SeleniumPattern(
        name="By.cssSelector",
        category=PatternCategory.LOCATOR,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "By") name: (identifier) @method (#eq? @method "cssSelector"))',
        migration_strategy="Direct conversion to page.locator()",
        playwright_equivalent='page.locator("css=selector")',
        complexity=1,
    ),
    "By_xpath": SeleniumPattern(
        name="By.xpath",
        category=PatternCategory.LOCATOR,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "By") name: (identifier) @method (#eq? @method "xpath"))',
        migration_strategy="Convert to page.locator() with xpath= prefix",
        playwright_equivalent='page.locator("xpath=//div[@id=\'test\']")',
        complexity=2,
    ),
    "By_name": SeleniumPattern(
        name="By.name",
        category=PatternCategory.LOCATOR,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "By") name: (identifier) @method (#eq? @method "name"))',
        migration_strategy="Convert to CSS attribute selector",
        playwright_equivalent='page.locator("[name=\'fieldName\']")',
        complexity=1,
    ),
    "By_linkText": SeleniumPattern(
        name="By.linkText",
        category=PatternCategory.LOCATOR,
        query='(method_invocation object: (identifier) @obj (#eq? @obj "By") name: (identifier) @method (#eq? @method "linkText"))',
        migration_strategy="Convert to getByRole or text locator",
        playwright_equivalent='page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("text"))',
        complexity=2,
    ),
    # Action Patterns
    "Actions": SeleniumPattern(
        name="Actions",
        category=PatternCategory.ACTION,
        query='(object_creation_expression type: (type_identifier) @type (#eq? @type "Actions"))',
        migration_strategy="Replace with Playwright keyboard/mouse APIs",
        playwright_equivalent="locator.hover(); page.keyboard().press(key);",
        complexity=4,
    ),
    "sendKeys": SeleniumPattern(
        name="sendKeys",
        category=PatternCategory.ACTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "sendKeys"))',
        migration_strategy="Replace with locator.fill() for inputs or type() for special keys",
        playwright_equivalent='locator.fill("text"); // or locator.press("Enter");',
        complexity=2,
    ),
    "click": SeleniumPattern(
        name="click",
        category=PatternCategory.ACTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "click"))',
        migration_strategy="Direct conversion to locator.click()",
        playwright_equivalent="locator.click();",
        complexity=1,
    ),
    "clear": SeleniumPattern(
        name="clear",
        category=PatternCategory.ACTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "clear"))',
        migration_strategy="Remove - Playwright's fill() clears first",
        playwright_equivalent="// Removed - fill() clears automatically",
        complexity=1,
    ),
    "Select": SeleniumPattern(
        name="Select",
        category=PatternCategory.ACTION,
        query='(object_creation_expression type: (type_identifier) @type (#eq? @type "Select"))',
        migration_strategy="Replace with locator.selectOption()",
        playwright_equivalent='locator.selectOption("value");',
        complexity=3,
    ),
    "JavascriptExecutor": SeleniumPattern(
        name="JavascriptExecutor",
        category=PatternCategory.ACTION,
        query='(cast_expression type: (type_identifier) @type (#eq? @type "JavascriptExecutor"))',
        migration_strategy="Replace with page.evaluate()",
        playwright_equivalent='page.evaluate("return document.title");',
        complexity=5,
    ),
    # Assertion Patterns
    "assertTrue": SeleniumPattern(
        name="assertTrue",
        category=PatternCategory.ASSERTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "assertTrue"))',
        migration_strategy="Replace with Playwright expect assertions",
        playwright_equivalent="assertThat(locator).isVisible();",
        complexity=2,
    ),
    "assertEquals": SeleniumPattern(
        name="assertEquals",
        category=PatternCategory.ASSERTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "assertEquals"))',
        migration_strategy="Replace with Playwright expect assertions",
        playwright_equivalent='assertThat(locator).hasText("expected");',
        complexity=2,
    ),
    "assertThat_hamcrest": SeleniumPattern(
        name="assertThat",
        category=PatternCategory.ASSERTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "assertThat"))',
        migration_strategy="Replace with Playwright assertThat",
        playwright_equivalent="assertThat(locator).hasAttribute(name, value);",
        complexity=3,
    ),
    # JUnit 4 Lifecycle Patterns
    "JUnit4_Before": SeleniumPattern(
        name="@Before",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "Before"))',
        migration_strategy="Convert to JUnit 5 @BeforeEach",
        playwright_equivalent="@BeforeEach void setUp() { }",
        complexity=2,
    ),
    "JUnit4_After": SeleniumPattern(
        name="@After",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "After"))',
        migration_strategy="Convert to JUnit 5 @AfterEach",
        playwright_equivalent="@AfterEach void tearDown() { }",
        complexity=2,
    ),
    "JUnit4_BeforeClass": SeleniumPattern(
        name="@BeforeClass",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "BeforeClass"))',
        migration_strategy="Convert to JUnit 5 @BeforeAll static method",
        playwright_equivalent="@BeforeAll static void beforeAll() { }",
        complexity=3,
    ),
    "JUnit4_AfterClass": SeleniumPattern(
        name="@AfterClass",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "AfterClass"))',
        migration_strategy="Convert to JUnit 5 @AfterAll static method",
        playwright_equivalent="@AfterAll static void afterAll() { }",
        complexity=3,
    ),
    "JUnit4_Test": SeleniumPattern(
        name="@Test (JUnit4)",
        category=PatternCategory.ASSERTION,
        query='(annotation name: (identifier) @name (#eq? @name "Test"))',
        migration_strategy="Convert to JUnit 5 @Test with updated import",
        playwright_equivalent="@Test void testName() { }",
        complexity=1,
    ),
    # TestNG Lifecycle Patterns
    "TestNG_BeforeMethod": SeleniumPattern(
        name="@BeforeMethod",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "BeforeMethod"))',
        migration_strategy="Convert to JUnit 5 @BeforeEach",
        playwright_equivalent="@BeforeEach void setUp() { }",
        complexity=2,
    ),
    "TestNG_AfterMethod": SeleniumPattern(
        name="@AfterMethod",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "AfterMethod"))',
        migration_strategy="Convert to JUnit 5 @AfterEach",
        playwright_equivalent="@AfterEach void tearDown() { }",
        complexity=2,
    ),
    "TestNG_BeforeClass": SeleniumPattern(
        name="@BeforeClass (TestNG)",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "BeforeClass"))',
        migration_strategy="Convert to JUnit 5 @BeforeAll",
        playwright_equivalent="@BeforeAll static void beforeAll() { }",
        complexity=3,
    ),
    "TestNG_AfterClass": SeleniumPattern(
        name="@AfterClass (TestNG)",
        category=PatternCategory.PAGE_FACTORY,
        query='(annotation name: (identifier) @name (#eq? @name "AfterClass"))',
        migration_strategy="Convert to JUnit 5 @AfterAll",
        playwright_equivalent="@AfterAll static void afterAll() { }",
        complexity=3,
    ),
    # Additional Action Patterns
    "hover": SeleniumPattern(
        name="hover/moveToElement",
        category=PatternCategory.ACTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "moveToElement"))',
        migration_strategy="Replace with locator.hover()",
        playwright_equivalent="locator.hover();",
        complexity=2,
    ),
    "doubleClick": SeleniumPattern(
        name="doubleClick",
        category=PatternCategory.ACTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "doubleClick"))',
        migration_strategy="Replace with locator.dblclick()",
        playwright_equivalent="locator.dblclick();",
        complexity=2,
    ),
    "rightClick": SeleniumPattern(
        name="contextClick",
        category=PatternCategory.ACTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "contextClick"))',
        migration_strategy="Replace with locator.click({ button: 'right' })",
        playwright_equivalent="locator.click(new Locator.ClickOptions().setButton(MouseButton.RIGHT));",
        complexity=3,
    ),
    "dragAndDrop": SeleniumPattern(
        name="dragAndDrop",
        category=PatternCategory.ACTION,
        query='(method_invocation name: (identifier) @method (#eq? @method "dragAndDrop"))',
        migration_strategy="Replace with locator.dragTo(targetLocator)",
        playwright_equivalent="source.dragTo(target);",
        complexity=4,
    ),
}


def get_patterns_by_category(category: PatternCategory) -> list[SeleniumPattern]:
    """Get all patterns in a specific category."""
    return [p for p in SELENIUM_PATTERNS.values() if p.category == category]


def get_all_queries() -> dict[str, str]:
    """Get all tree-sitter queries indexed by pattern name."""
    return {name: pattern.query for name, pattern in SELENIUM_PATTERNS.items()}
