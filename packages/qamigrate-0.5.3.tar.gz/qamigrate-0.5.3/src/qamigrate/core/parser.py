"""
Tree-sitter Java Parsing Utilities.

Provides AST extraction and querying for Java source files.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import tree_sitter_java as tsjava
from tree_sitter import Language, Node, Parser, Query, QueryCursor

# Initialize Java language
JAVA_LANGUAGE = Language(tsjava.language())

# Java modifier keywords we recognize when walking a tree-sitter `modifiers`
# node. Tree-sitter-java emits each keyword as a node whose `type` is the
# keyword itself. Keep this list in sync with the Java grammar.
_JAVA_MODIFIER_KEYWORDS = {
    "public", "private", "protected",
    "static", "final", "abstract", "native",
    "synchronized", "transient", "volatile",
    "strictfp", "default", "sealed", "non-sealed",
}


@dataclass
class ASTNode:
    """Simplified AST node representation."""

    type: str
    text: str | None
    start_line: int
    end_line: int
    start_column: int
    end_column: int
    children: list["ASTNode"] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "type": self.type,
            "text": self.text,
            "start_point": {"row": self.start_line, "col": self.start_column},
            "end_point": {"row": self.end_line, "col": self.end_column},
            "children": [child.to_dict() for child in self.children],
        }


@dataclass
class QueryMatch:
    """Result of a tree-sitter query match."""

    pattern_name: str
    node_type: str
    text: str
    start_line: int
    end_line: int
    file_path: str


class JavaParser:
    """Tree-sitter based Java parser."""

    def __init__(self) -> None:
        """Initialize the parser with Java language."""
        self.parser = Parser(JAVA_LANGUAGE)
        self.language = JAVA_LANGUAGE

    def parse_file(self, file_path: Path) -> tuple[ASTNode, bytes]:
        """
        Parse a Java file and return its AST.

        Args:
            file_path: Path to the Java file

        Returns:
            Tuple of (AST root node, source bytes)
        """
        source = file_path.read_bytes()
        tree = self.parser.parse(source)
        ast = self._node_to_ast(tree.root_node, source)
        return ast, source

    def parse_source(self, source: str | bytes) -> ASTNode:
        """
        Parse Java source code string.

        Args:
            source: Java source code

        Returns:
            AST root node
        """
        if isinstance(source, str):
            source = source.encode("utf-8")
        tree = self.parser.parse(source)
        return self._node_to_ast(tree.root_node, source)

    def query(self, source: bytes, query_string: str) -> list[tuple[Node, str]]:
        """
        Execute a tree-sitter query on source code.

        Args:
            source: Source code bytes
            query_string: Tree-sitter query pattern

        Returns:
            List of (node, capture_name) tuples
        """
        tree = self.parser.parse(source)
        try:
            q = Query(self.language, query_string)
            cursor = QueryCursor(q)
            # captures() returns dict[str, list[Node]] in tree-sitter 0.25+
            captures_dict = cursor.captures(tree.root_node)
            # Flatten to list of (node, capture_name) for backwards compatibility
            results: list[tuple[Node, str]] = []
            for capture_name, nodes in captures_dict.items():
                for node in nodes:
                    results.append((node, capture_name))
            return results
        except Exception:
            # Query syntax error - return empty
            return []

    def find_patterns(
        self, file_path: Path, patterns: dict[str, str]
    ) -> list[QueryMatch]:
        """
        Find all pattern matches in a file.

        Args:
            file_path: Path to Java file
            patterns: Dict of pattern_name -> query_string

        Returns:
            List of QueryMatch objects
        """
        source = file_path.read_bytes()
        matches: list[QueryMatch] = []

        for pattern_name, query_string in patterns.items():
            try:
                captures = self.query(source, query_string)
                for node, _ in captures:
                    matches.append(
                        QueryMatch(
                            pattern_name=pattern_name,
                            node_type=node.type,
                            text=node.text.decode("utf-8") if node.text else "",
                            start_line=node.start_point[0] + 1,
                            end_line=node.end_point[0] + 1,
                            file_path=str(file_path),
                        )
                    )
            except Exception:
                # Skip invalid queries
                continue

        return matches

    def extract_class_info(self, file_path: Path) -> dict[str, Any]:
        """
        Extract class-level information from a Java file.

        Returns:
            Dict with package, class_name, imports, fields, methods
        """
        source = file_path.read_bytes()
        tree = self.parser.parse(source)
        root = tree.root_node

        info: dict[str, Any] = {
            "package": None,
            "class_name": None,
            "imports": [],
            "extends": None,
            "implements": [],
            "fields": [],
            "methods": [],
            "annotations": [],
        }

        for child in root.children:
            if child.type == "package_declaration":
                info["package"] = self._extract_text(child, source, "scoped_identifier")

            elif child.type == "import_declaration":
                import_text = self._get_node_text(child, source)
                # Clean up import statement
                import_text = import_text.replace("import ", "").replace(";", "").strip()
                info["imports"].append(import_text)

            elif child.type == "class_declaration":
                info.update(self._extract_class_declaration(child, source))

            elif child.type == "enum_declaration":
                info.update(self._extract_enum_declaration(child, source))

        return info

    def _node_to_ast(self, node: Node, source: bytes) -> ASTNode:
        """Convert tree-sitter node to ASTNode."""
        text = None
        if node.child_count == 0:
            text = node.text.decode("utf-8") if node.text else None

        children = [self._node_to_ast(child, source) for child in node.children]

        return ASTNode(
            type=node.type,
            text=text,
            start_line=node.start_point[0],
            end_line=node.end_point[0],
            start_column=node.start_point[1],
            end_column=node.end_point[1],
            children=children,
        )

    def _get_node_text(self, node: Node, source: bytes) -> str:
        """Get the text content of a node."""
        return source[node.start_byte : node.end_byte].decode("utf-8")

    def _extract_text(self, node: Node, source: bytes, child_type: str) -> str | None:
        """Extract text from a specific child node type."""
        for child in node.children:
            if child.type == child_type:
                return self._get_node_text(child, source)
            # Recurse for nested structures
            result = self._extract_text(child, source, child_type)
            if result:
                return result
        return None

    def _extract_class_declaration(self, node: Node, source: bytes) -> dict[str, Any]:
        """Extract information from a class declaration node."""
        info: dict[str, Any] = {
            "class_name": None,
            "extends": None,
            "implements": [],
            "fields": [],
            "methods": [],
            "annotations": [],
            "modifiers": [],
        }

        for child in node.children:
            if child.type == "identifier":
                info["class_name"] = self._get_node_text(child, source)

            elif child.type == "superclass":
                info["extends"] = self._extract_text(child, source, "type_identifier")

            elif child.type == "super_interfaces":
                for interface in child.children:
                    if interface.type == "type_list":
                        for type_node in interface.children:
                            if type_node.type == "type_identifier":
                                info["implements"].append(
                                    self._get_node_text(type_node, source)
                                )

            elif child.type == "class_body":
                info.update(self._extract_class_body(child, source))

            elif child.type == "modifiers":
                for modifier in child.children:
                    if modifier.type == "annotation":
                        info["annotations"].append(self._get_node_text(modifier, source))
                    elif modifier.type in _JAVA_MODIFIER_KEYWORDS:
                        info["modifiers"].append(modifier.type)

        return info

    def _extract_enum_declaration(self, node: Node, source: bytes) -> dict[str, Any]:
        """Extract info from an enum declaration.

        v0.5.2: passthrough-copied enums still get scanned so downstream
        consumers (sibling_signatures, Coder prompt) know the enum's
        constants and methods. Enums that test code depends on MUST
        expose their constants -- otherwise the Coder hallucinates
        `Environment.DEVELOPMENT` when the real constant is `Environment.DEV`.

        Shape mirrors `_extract_class_declaration`: class_name, modifiers,
        annotations, methods, fields. We also populate a synthetic field
        per enum constant so the existing signature extractor picks them
        up as `public static final Environment DEV`.
        """
        info: dict[str, Any] = {
            "class_name": None,
            "extends": None,
            "implements": [],
            "fields": [],
            "methods": [],
            "annotations": [],
            "modifiers": [],
            "is_enum": True,
        }

        for child in node.children:
            if child.type == "identifier":
                info["class_name"] = self._get_node_text(child, source)

            elif child.type == "super_interfaces":
                for interface in child.children:
                    if interface.type == "type_list":
                        for type_node in interface.children:
                            if type_node.type == "type_identifier":
                                info["implements"].append(
                                    self._get_node_text(type_node, source)
                                )

            elif child.type == "modifiers":
                for modifier in child.children:
                    if modifier.type == "annotation":
                        info["annotations"].append(self._get_node_text(modifier, source))
                    elif modifier.type in _JAVA_MODIFIER_KEYWORDS:
                        info["modifiers"].append(modifier.type)

            elif child.type == "enum_body":
                info.update(self._extract_enum_body(child, source, info["class_name"]))

        return info

    def _extract_enum_body(
        self, node: Node, source: bytes, enum_name: str | None,
    ) -> dict[str, Any]:
        """Extract enum constants (as synthetic fields) + declared methods."""
        info: dict[str, Any] = {"fields": [], "methods": [], "enum_constants": []}

        for child in node.children:
            if child.type == "enum_constant":
                const_name: str | None = None
                for sub in child.children:
                    if sub.type == "identifier":
                        const_name = self._get_node_text(sub, source)
                        break
                if const_name:
                    info["enum_constants"].append(const_name)
                    # Emit a synthetic field so sibling_signatures picks it
                    # up via the existing field->signature path.
                    info["fields"].append({
                        "name": const_name,
                        "type": enum_name or "Enum",
                        "modifiers": ["public", "static", "final"],
                        "annotations": [],
                        "line": child.start_point[0] + 1,
                    })

            elif child.type == "enum_body_declarations":
                # Methods, fields, constructors declared inside the enum body.
                for decl in child.children:
                    if decl.type == "method_declaration":
                        method_info = self._extract_method(decl, source)
                        if method_info:
                            info["methods"].append(method_info)
                    elif decl.type == "field_declaration":
                        field_info = self._extract_field(decl, source)
                        if field_info:
                            info["fields"].append(field_info)

        return info

    def _extract_class_body(self, node: Node, source: bytes) -> dict[str, Any]:
        """Extract fields and methods from class body."""
        info: dict[str, Any] = {"fields": [], "methods": []}

        for child in node.children:
            if child.type == "field_declaration":
                field_info = self._extract_field(child, source)
                if field_info:
                    info["fields"].append(field_info)

            elif child.type == "method_declaration":
                method_info = self._extract_method(child, source)
                if method_info:
                    info["methods"].append(method_info)

        return info

    def _extract_field(self, node: Node, source: bytes) -> dict[str, Any] | None:
        """Extract field information."""
        field: dict[str, Any] = {
            "name": None,
            "type": None,
            "modifiers": [],
            "annotations": [],
            "line": node.start_point[0] + 1,
        }

        for child in node.children:
            if child.type == "type_identifier" or child.type == "generic_type":
                field["type"] = self._get_node_text(child, source)
            elif child.type == "variable_declarator":
                for var_child in child.children:
                    if var_child.type == "identifier":
                        field["name"] = self._get_node_text(var_child, source)
            elif child.type == "modifiers":
                for modifier in child.children:
                    if modifier.type == "annotation":
                        field["annotations"].append(self._get_node_text(modifier, source))
                    elif modifier.type in _JAVA_MODIFIER_KEYWORDS:
                        field["modifiers"].append(modifier.type)

        return field if field["name"] else None

    def _extract_method(self, node: Node, source: bytes) -> dict[str, Any] | None:
        """Extract method information."""
        method: dict[str, Any] = {
            "name": None,
            "return_type": None,
            "parameters": [],
            "modifiers": [],
            "annotations": [],
            "start_line": node.start_point[0] + 1,
            "end_line": node.end_point[0] + 1,
            "body": None,
        }

        for child in node.children:
            if child.type == "identifier":
                method["name"] = self._get_node_text(child, source)
            elif child.type in ("type_identifier", "void_type", "generic_type"):
                method["return_type"] = self._get_node_text(child, source)
            elif child.type == "formal_parameters":
                method["parameters"] = self._extract_parameters(child, source)
            elif child.type == "modifiers":
                for modifier in child.children:
                    if modifier.type == "annotation":
                        method["annotations"].append(self._get_node_text(modifier, source))
                    elif modifier.type in _JAVA_MODIFIER_KEYWORDS:
                        method["modifiers"].append(modifier.type)
            elif child.type == "block":
                method["body"] = self._get_node_text(child, source)

        return method if method["name"] else None

    def _extract_parameters(self, node: Node, source: bytes) -> list[dict[str, str]]:
        """Extract method parameters."""
        params: list[dict[str, str]] = []

        for child in node.children:
            if child.type == "formal_parameter":
                param: dict[str, str] = {"name": "", "type": ""}
                for param_child in child.children:
                    if param_child.type in ("type_identifier", "generic_type"):
                        param["type"] = self._get_node_text(param_child, source)
                    elif param_child.type == "identifier":
                        param["name"] = self._get_node_text(param_child, source)
                if param["name"]:
                    params.append(param)

        return params


# Singleton parser instance
_parser: JavaParser | None = None


def get_parser() -> JavaParser:
    """Get singleton parser instance."""
    global _parser
    if _parser is None:
        _parser = JavaParser()
    return _parser
