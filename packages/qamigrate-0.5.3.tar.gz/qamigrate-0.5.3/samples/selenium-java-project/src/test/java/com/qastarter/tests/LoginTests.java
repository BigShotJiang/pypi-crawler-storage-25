package com.qastarter.tests;

import com.qastarter.config.ConfigurationReader;
import com.qastarter.core.BaseTest;
import com.qastarter.pages.LoginPage;
import com.qastarter.utils.Log;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
* Login Tests - Example test class for SauceDemo.
*
* Demonstrates:
* - Simple tests using ConfigurationReader (properties file)
* - Data-driven tests using TestDataReader (CSV file)
*/
public class LoginTests extends BaseTest {

// ===========================================
// SIMPLE TESTS (using properties file)
// ===========================================

@Test(priority = 1, description = "Verify successful login with valid credentials")
public void testValidLogin() {
Log.step("Testing valid login from properties file");
LoginPage loginPage = new LoginPage();

// Get credentials from dev.properties
String username = ConfigurationReader.getProperty("username");
String password = ConfigurationReader.getProperty("password");

loginPage.login(username, password);

Assert.assertTrue(loginPage.isLoginSuccessful(), "Login should be successful");
Log.info("Valid login test passed");
}

@Test(priority = 2, description = "Verify error message with invalid credentials")
public void testInvalidLogin() {
Log.step("Testing invalid login");
LoginPage loginPage = new LoginPage();

loginPage.login("invalid_user", "wrong_password");

Assert.assertTrue(loginPage.isErrorDisplayed(), "Error message should be displayed");
Log.info("Invalid login test passed - error displayed as expected");
}

    // ===========================================
    // DATA-DRIVEN TESTS (using CSV file)
    // ===========================================

    }