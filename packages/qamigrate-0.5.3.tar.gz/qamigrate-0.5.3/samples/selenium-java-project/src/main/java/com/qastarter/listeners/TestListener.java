package com.qastarter.listeners;

import com.qastarter.utils.Log;
import com.qastarter.utils.ScreenshotUtils;
import com.qastarter.utils.ExtentManager;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.MediaEntityBuilder;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.util.Base64;
import java.nio.file.Files;

/**
 * TestNG Listener - Handles test events, logging, and reporting.
 */
public class TestListener implements ITestListener {

    @Override
    public void onStart(ITestContext context) {
        Log.info("TEST SUITE: " + context.getName());
        ExtentManager.getInstance();
    }

    @Override
    public void onFinish(ITestContext context) {
        Log.info("Suite finished: " + context.getName());
        ExtentManager.flush();
    }

    @Override
    public void onTestStart(ITestResult result) {
        Log.testStart(getTestName(result));
        ExtentManager.createTest(getTestName(result), result.getMethod().getDescription());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        Log.testEnd(getTestName(result), "PASSED");
        if (ExtentManager.getTest() != null) {
            ExtentManager.getTest().log(Status.PASS, "Test passed");
        }
    }

    @Override
    public void onTestFailure(ITestResult result) {
        Log.error("TEST FAILED: " + getTestName(result));
        Log.error("Reason: " + result.getThrowable().getMessage());

        String screenshotPath = ScreenshotUtils.capture("FAILED_" + getTestName(result));

        if (ExtentManager.getTest() != null) {
            ExtentManager.getTest().log(Status.FAIL, result.getThrowable().getMessage());
            
            // Attach screenshot as Base64 for reliable embedding
            if (screenshotPath != null) {
                try {
                    byte[] fileContent = Files.readAllBytes(new File(screenshotPath).toPath());
                    String base64 = Base64.getEncoder().encodeToString(fileContent);
                    ExtentManager.getTest().addScreenCaptureFromBase64String(base64, "Screenshot on Failure");
                } catch (Exception e) {
                    Log.error("Failed to attach screenshot to report: " + e.getMessage());
                }
            }
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        Log.warn("TEST SKIPPED: " + getTestName(result));
        if (ExtentManager.getTest() != null) {
            ExtentManager.getTest().log(Status.SKIP, "Test skipped");
        }
    }

    private String getTestName(ITestResult result) {
        return result.getTestClass().getRealClass().getSimpleName() + "." + result.getMethod().getMethodName();
    }
}