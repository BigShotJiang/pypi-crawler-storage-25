package com.qastarter.core;

import com.qastarter.config.ConfigurationReader;
import com.qastarter.listeners.TestListener;
import com.qastarter.utils.Log;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;

/**
 * Base Test - Extend this in all your test classes.
 * 
 * Handles browser lifecycle automatically.
 */
@Listeners({TestListener.class})
public class BaseTest {

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite() {
        Log.info("========================================");
        Log.info(" TEST SUITE STARTED");
        Log.info("========================================");
        Log.info("Environment: " + ConfigurationReader.getCurrentEnvironment());
        Log.info("Browser: " + ConfigurationReader.getBrowser());
        Log.info("Headless: " + ConfigurationReader.isHeadless());
        Log.info("Base URL: " + ConfigurationReader.getBaseUrl());
    }

    @AfterSuite(alwaysRun = true)
    public void afterSuite() {
        Log.info("========================================");
        Log.info(" TEST SUITE COMPLETED");
        Log.info("========================================");
    }

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        Log.info("--- Test Setup Started ---");
        DriverManager.initializeDriver();

        String baseUrl = ConfigurationReader.getBaseUrl();
        if (baseUrl != null && !baseUrl.isEmpty()) {
            getDriver().get(baseUrl);
            Log.info("Navigated to: " + baseUrl);
        }
        Log.info("--- Test Setup Completed ---");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        Log.info("--- Test Teardown Started ---");
        DriverManager.quitDriver();
        Log.info("--- Test Teardown Completed ---");
    }

    protected WebDriver getDriver() {
        return DriverManager.getDriver();
    }

    protected void navigateTo(String url) {
        Log.step("Navigating to: " + url);
        getDriver().get(url);
    }
}