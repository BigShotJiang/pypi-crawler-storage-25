package com.qastarter.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ExtentReports Manager - HTML reporting integration.
 * 
 * Reports saved to: reports/ExtentReport_{timestamp}.html
 */
public class ExtentManager {

    private static ExtentReports extentReports;
    private static final ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();
    private static final String REPORT_DIR = "reports";

    private ExtentManager() {}

    public static ExtentReports getInstance() {
        if (extentReports == null) {
            synchronized (ExtentManager.class) {
                if (extentReports == null) {
                    // Create reports directory if it doesn't exist
                    File reportsDir = new File(REPORT_DIR);
                    if (!reportsDir.exists()) {
                        reportsDir.mkdirs();
                        System.out.println("[ExtentManager] Created reports directory: " + reportsDir.getAbsolutePath());
                    }

                    String timestamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new Date());
                    String reportPath = REPORT_DIR + "/ExtentReport_" + timestamp + ".html";

                    ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);
                    sparkReporter.config().setTheme(Theme.DARK);
                    sparkReporter.config().setDocumentTitle("selenium-java-project Test Report");
                    sparkReporter.config().setReportName("Automation Test Results");
                    sparkReporter.config().setTimelineEnabled(true);

                    extentReports = new ExtentReports();
                    extentReports.attachReporter(sparkReporter);
                    extentReports.setSystemInfo("Environment", System.getProperty("env", "dev"));
                    extentReports.setSystemInfo("Browser", System.getProperty("browser", "chrome"));
                    extentReports.setSystemInfo("OS", System.getProperty("os.name"));
                    extentReports.setSystemInfo("Java Version", System.getProperty("java.version"));

                    System.out.println("[ExtentManager] Report will be saved to: " + new File(reportPath).getAbsolutePath());
                    Log.info("ExtentReports initialized: " + reportPath);
                }
            }
        }
        return extentReports;
    }

    public static void createTest(String testName, String description) {
        ExtentTest test = getInstance().createTest(testName, description);
        extentTest.set(test);
    }

    public static ExtentTest getTest() {
        return extentTest.get();
    }

    public static void flush() {
        if (extentReports != null) {
            extentReports.flush();
            System.out.println("[ExtentManager] Report saved successfully!");
            Log.info("ExtentReports flushed");
        }
    }

    public static void removeTest() {
        extentTest.remove();
    }
}