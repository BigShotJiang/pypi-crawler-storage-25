"""Tests for the cross-file hallucination detector."""

from qamigrate.core.hallucination import (
    detect_hallucinations,
    detect_selector_hallucinations,
    extract_declared_locators,
)

REAL_LOGIN_PAGE_API = [
    "public LoginPage(Page page)",
    "public boolean isLoaded()",
    "public LoginPage enterUsername(String username)",
    "public LoginPage enterPassword(String password)",
    "public void clickLogin()",
    "public void login(String username, String password)",
    "public String getErrorMessage()",
    "public boolean isErrorDisplayed()",
    "public boolean isLoginSuccessful()",
]


class TestHallucinationDetector:
    def test_flags_invented_method(self) -> None:
        code = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        assertThat(loginPage.getSuccessIndicator()).isVisible();
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert len(results) == 1
        assert results[0].called_method == "LoginPage.getSuccessIndicator()"
        assert results[0].on_class == "LoginPage"
        # "getSuccessIndicator" has no close real method so similar_to may
        # be None or something else; don't assert on it strictly.

    def test_suggests_close_match(self) -> None:
        code = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        System.out.println(loginPage.getErrorMessge());  // typo
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert len(results) == 1
        assert results[0].similar_to is not None
        assert "getErrorMessage" in results[0].similar_to

    def test_real_calls_are_not_flagged(self) -> None:
        code = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        loginPage.enterUsername("u");
        loginPage.enterPassword("p");
        loginPage.clickLogin();
        assertTrue(loginPage.isLoginSuccessful());
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert results == []

    def test_unknown_receiver_is_ignored(self) -> None:
        """Calls on types we don't have signatures for (e.g. Page, Playwright
        built-ins) should not be flagged."""
        code = """
public class LoginTests {
    Page page;
    public void foo() {
        page.navigate("x");  // page is not a LoginPage
        page.locator("#x").click();
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert results == []

    def test_deduplicates_repeated_calls(self) -> None:
        code = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        loginPage.getFoo();
        loginPage.getFoo();
        loginPage.getFoo();
    }
}
"""
        results = detect_hallucinations(code, {"LoginPage": REAL_LOGIN_PAGE_API})
        assert len(results) == 1

    def test_empty_inputs_return_empty(self) -> None:
        assert detect_hallucinations("", {"LoginPage": REAL_LOGIN_PAGE_API}) == []
        assert detect_hallucinations("some code", {}) == []

    def test_sensitivity_after_real_method_renamed(self) -> None:
        """
        Concrete scenario the user asked about: rename `isLoginSuccessful`
        in LoginPage -> `didLoginSucceed`, then re-migrate LoginTests alone.
        LoginTests still calls the old name. The detector must flag it.
        """
        login_tests_source = """
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        assertTrue(loginPage.isLoginSuccessful(), "Login failed");
    }
}
"""
        # Simulate a LoginPage that has been renamed -- "isLoginSuccessful"
        # no longer exists; it's "didLoginSucceed" now.
        renamed_api = [
            s.replace("isLoginSuccessful", "didLoginSucceed")
            for s in REAL_LOGIN_PAGE_API
        ]

        results = detect_hallucinations(login_tests_source, {"LoginPage": renamed_api})

        assert len(results) == 1
        assert results[0].called_method == "LoginPage.isLoginSuccessful()"
        # Should suggest the closest match (difflib.get_close_matches)
        assert results[0].similar_to is not None
        assert "didLoginSucceed" in results[0].similar_to


class TestExtractDeclaredLocators:
    def test_extracts_css_id(self) -> None:
        code = '''
public class LoginPage {
    public LoginPage(Page page) {
        this.usernameInput = page.locator("#username");
        this.passwordInput = page.locator("#password");
    }
}
'''
        assert extract_declared_locators(code) == {"#username", "#password"}

    def test_ignores_non_locator_strings(self) -> None:
        code = '''
System.out.println("#username");
String foo = "#not-a-selector";
page.click("#real");
'''
        # Only `.locator(...)` calls count.
        # (In real code, .click comes from a Locator; but we don't want
        # to treat bare string literals as declared selectors.)
        assert extract_declared_locators(code) == set()

    def test_handles_multiple_forms(self) -> None:
        code = '''
page.locator("#id");
page.locator(".cls");
page.locator("[data-test='foo']");
page.locator("xpath=//div");
'''
        assert extract_declared_locators(code) == {
            "#id",
            ".cls",
            "[data-test='foo']",
            "xpath=//div",
        }

    def test_empty_source(self) -> None:
        assert extract_declared_locators("") == set()


class TestDetectSelectorHallucinations:
    LOGIN_PAGE_LOCATORS = {"#username", "#password", "button[type='submit']"}

    def test_flags_invented_selector_in_test(self) -> None:
        code = '''
public class LoginTests {
    @Test
    public void testLogin() {
        LoginPage loginPage = new LoginPage(page);
        loginPage.login("admin", "pass");
        assertThat(page.locator("#success-indicator")).isVisible();
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": self.LOGIN_PAGE_LOCATORS}
        )
        assert len(results) == 1
        assert '"#success-indicator"' in results[0].called_method
        assert results[0].on_class == "LoginPage"

    def test_accepts_known_selector(self) -> None:
        code = '''
public class LoginTests {
    @Test
    public void testLogin() {
        LoginPage loginPage = new LoginPage(page);
        assertThat(page.locator("#username")).isVisible();
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": self.LOGIN_PAGE_LOCATORS}
        )
        assert results == []

    def test_silent_when_no_page_objects_referenced(self) -> None:
        # If the test doesn't use any class we have locator info for, we
        # can't validate anything -- stay quiet.
        code = '''
public class SmokeTest {
    public void foo() {
        assertThat(page.locator("#anything")).isVisible();
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": self.LOGIN_PAGE_LOCATORS}
        )
        assert results == []

    def test_skips_unverifiable_selectors(self) -> None:
        # Bare tag names and interpolated selectors should NOT be flagged.
        code = '''
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        page.locator("body");
        page.locator("${dynamic}");
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": self.LOGIN_PAGE_LOCATORS}
        )
        assert results == []

    def test_suggests_similar_selector(self) -> None:
        # "#usernam" is a typo of "#username" -- similar_to should hint it.
        code = '''
public class LoginTests {
    public void foo() {
        LoginPage loginPage = new LoginPage(page);
        page.locator("#usernam");
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": self.LOGIN_PAGE_LOCATORS}
        )
        assert len(results) == 1
        assert results[0].similar_to is not None
        assert "#username" in results[0].similar_to

    def test_empty_inputs(self) -> None:
        assert detect_selector_hallucinations("", {"X": {"#a"}}) == []
        assert detect_selector_hallucinations("page.locator(\"#x\")", {}) == []


# ---- v0.5.2(b): getByTestId detection ----


class TestExtractDeclaredSelectors:
    def test_splits_css_and_testids(self) -> None:
        from qamigrate.core.hallucination import extract_declared_selectors
        code = '''
public class LoginPage {
    public LoginPage(Page page) {
        this.usernameInput = page.locator("#username");
        this.submitBtn = page.getByTestId("submit");
        this.loginForm = page.getByTestId("login-form");
        this.errorMsg = page.locator(".error");
    }
}
'''
        d = extract_declared_selectors(code)
        assert d.css == {"#username", ".error"}
        assert d.testids == {"submit", "login-form"}
        assert d.is_empty is False

    def test_empty_source_returns_empty(self) -> None:
        from qamigrate.core.hallucination import extract_declared_selectors
        d = extract_declared_selectors("")
        assert d.is_empty


class TestDetectTestIdHallucinations:
    def _page_locators(self):
        from qamigrate.core.hallucination import DeclaredSelectors
        return DeclaredSelectors(
            css={"#username"},
            testids={"submit-btn", "user-email"},
        )

    def test_flags_invented_testid(self) -> None:
        from qamigrate.core.hallucination import detect_selector_hallucinations
        code = '''
public class LoginTests {
    @Test
    public void test() {
        LoginPage loginPage = new LoginPage(page);
        page.getByTestId("success-badge").click();
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": self._page_locators()}
        )
        assert len(results) == 1
        assert 'getByTestId("success-badge")' in results[0].called_method

    def test_accepts_known_testid(self) -> None:
        from qamigrate.core.hallucination import detect_selector_hallucinations
        code = '''
public class LoginTests {
    public void test() {
        LoginPage loginPage = new LoginPage(page);
        page.getByTestId("submit-btn").click();
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": self._page_locators()}
        )
        assert results == []

    def test_suggests_similar_testid(self) -> None:
        from qamigrate.core.hallucination import detect_selector_hallucinations
        # "submit-button" is close to "submit-btn"
        code = '''
public class LoginTests {
    public void test() {
        LoginPage loginPage = new LoginPage(page);
        page.getByTestId("submit-button").click();
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": self._page_locators()}
        )
        assert len(results) == 1
        assert results[0].similar_to is not None
        assert "submit-btn" in results[0].similar_to

    def test_never_cross_compares_css_and_testid(self) -> None:
        """A CSS selector '#submit-btn' is NOT the same as a testid
        'submit-btn'. The detector must not accept the CSS as a valid
        test-id (or vice versa)."""
        from qamigrate.core.hallucination import detect_selector_hallucinations
        code = '''
public class LoginTests {
    public void test() {
        LoginPage loginPage = new LoginPage(page);
        page.getByTestId("#username").click();
    }
}
'''
        # Page has CSS `#username` but no test-id `#username`. Must flag.
        results = detect_selector_hallucinations(
            code, {"LoginPage": self._page_locators()}
        )
        assert len(results) == 1
        assert "getByTestId" in results[0].called_method

    def test_legacy_dict_set_input_still_works(self) -> None:
        """v0.5.1 callers passed dict[str, set[str]] -- must stay working."""
        from qamigrate.core.hallucination import detect_selector_hallucinations
        code = '''
public class LoginTests {
    public void test() {
        LoginPage loginPage = new LoginPage(page);
        page.locator("#invented").click();
    }
}
'''
        results = detect_selector_hallucinations(
            code, {"LoginPage": {"#username", "#password"}}
        )
        assert len(results) == 1
        assert 'locator("#invented")' in results[0].called_method
