"""
Regression tests for v0.5.3 bugs found in the v0.5.1 real-project test report.

Bug #1: Generated files declare wrong package (no .playwright suffix).
Bug #2: Playwright dep injected with <scope>test</scope> -- invisible to main sources.
Bug #3: Internal compile check missed duplicate-class collisions with originals.
"""

from __future__ import annotations

from pathlib import Path

from qamigrate.agents.dependency_injector import DependencyInjector

# =============================================================================
# Bug #1 -- package name must end with .playwright
# =============================================================================


class TestPackageNameFix:
    """assemble_file() must guarantee the .playwright suffix regardless of
    what the LLM returns in the package_name field."""

    def _assemble(self, package_name: str) -> str:
        from qamigrate.agents.coder import CoderAgent, PlaywrightCode
        code = PlaywrightCode(
            package_name=package_name,
            imports=[],
            class_declaration="public class Dummy",
            fields=[],
            constructor="public Dummy(Page page) {}",
            methods=[],
        )
        coder = CoderAgent.__new__(CoderAgent)
        return coder.assemble_file(code)

    def test_no_suffix_gets_playwright_appended(self) -> None:
        output = self._assemble("com.example.pages")
        assert "package com.example.pages.playwright;" in output

    def test_correct_suffix_not_doubled(self) -> None:
        # If the LLM DID get it right, we must not add .playwright twice.
        output = self._assemble("com.example.pages.playwright")
        assert output.count("package com.example.pages.playwright;") == 1
        assert "playwright.playwright" not in output

    def test_default_package_gets_playwright(self) -> None:
        # Root package (no dots) -- edge case in small demo projects.
        output = self._assemble("com")
        assert "package com.playwright;" in output

    def test_tool_schema_description_mentions_playwright(self) -> None:
        from qamigrate.agents.coder import CoderAgent
        schema = CoderAgent._TOOL_SCHEMA
        pkg_desc = schema["input_schema"]["properties"]["package_name"]["description"]
        assert "playwright" in pkg_desc.lower()

    def test_system_prompt_mentions_playwright_suffix(self) -> None:
        from qamigrate.agents.coder import SYSTEM_PROMPT
        assert ".playwright" in SYSTEM_PROMPT


# =============================================================================
# Bug #2 -- Playwright dependency must NOT have <scope>test</scope>
# =============================================================================


class TestDependencyScopeFix:
    """Playwright JAR must be injected WITHOUT <scope>test</scope>.

    Generated page-object and base-class files live in src/main/java and
    import com.microsoft.playwright.*. <scope>test</scope> makes the JAR
    invisible to the Maven compiler when compiling main sources.
    """

    _MINIMAL_POM = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
    <dependencies>
        <dependency>
            <groupId>org.seleniumhq.selenium</groupId>
            <artifactId>selenium-java</artifactId>
            <version>4.15.0</version>
        </dependency>
    </dependencies>
</project>
"""

    def test_playwright_dep_has_no_scope(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(self._MINIMAL_POM)

        DependencyInjector(tmp_path).ensure_playwright_deps("maven")
        content = pom.read_text()

        # Find the Playwright block and assert there's no <scope> immediately
        # following the playwright artifactId.
        import re
        pw_block = re.search(
            r"<groupId>com\.microsoft\.playwright</groupId>.*?</dependency>",
            content,
            re.DOTALL,
        )
        assert pw_block, "Playwright dependency not found in pom.xml"
        pw_text = pw_block.group(0)
        assert "<scope>" not in pw_text, (
            f"Playwright dep must not have <scope>. Found:\n{pw_text}"
        )

    def test_junit5_dep_keeps_test_scope(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(self._MINIMAL_POM)

        DependencyInjector(tmp_path).ensure_playwright_deps("maven")
        content = pom.read_text()

        import re
        junit_block = re.search(
            r"<groupId>org\.junit\.jupiter</groupId>.*?</dependency>",
            content,
            re.DOTALL,
        )
        assert junit_block, "JUnit5 dependency not found in pom.xml"
        junit_text = junit_block.group(0)
        assert "<scope>test</scope>" in junit_text, (
            "JUnit5 dep must keep <scope>test</scope>."
        )

    def test_needed_deps_playwright_has_no_scope_key(self) -> None:
        inj = DependencyInjector(Path("."))
        deps = inj._needed_deps()
        pw = next(d for d in deps if d["artifact"] == "playwright")
        assert "scope" not in pw, (
            "Playwright dep dict must not contain a 'scope' key. "
            f"Got: {pw}"
        )


# =============================================================================
# Bug #3 -- package-collision warning fires when generated == original package
# =============================================================================


class TestPackageCollisionDetection:
    """_warn_package_collisions must log a warning when a generated file
    declares the same package as its original source. This is the diagnostic
    that tells the user WHY they get ~150 mvn errors."""

    def _make_gen(
        self,
        tmp_path: Path,
        original_pkg: str,
        generated_pkg: str,
    ):
        from qamigrate.agents.pipeline import GenerationResult

        orig = tmp_path / "LoginPage.java"
        orig.write_text(
            f"package {original_pkg};\npublic class LoginPage {{}}", encoding="utf-8"
        )
        out = tmp_path / "playwright" / "LoginPage.java"
        out.parent.mkdir(parents=True)
        out.write_text(
            f"package {generated_pkg};\npublic class LoginPage {{}}", encoding="utf-8"
        )
        return GenerationResult(
            source_path=orig,
            output_path=out,
            success=True,
            error=None,
            class_name="LoginPage",
            signatures=[],
            analysis_patterns=[],
            original_code=orig.read_text(),
            generated_code=out.read_text(),
            duration_seconds=0.5,
        )

    def test_collision_triggers_warning(self, tmp_path: Path, capsys) -> None:
        from qamigrate.agents.pipeline import _warn_package_collisions

        gen = self._make_gen(tmp_path, "com.example.pages", "com.example.pages")
        _warn_package_collisions([gen])

        # structlog writes to stdout; check the captured output.
        out = capsys.readouterr().out
        assert "collision" in out.lower() or "playwright" in out.lower()

    def test_no_collision_when_playwright_suffix_present(
        self, tmp_path: Path, capsys
    ) -> None:
        from qamigrate.agents.pipeline import _warn_package_collisions

        gen = self._make_gen(
            tmp_path, "com.example.pages", "com.example.pages.playwright"
        )
        _warn_package_collisions([gen])
        out = capsys.readouterr().out
        # No collision-warning text when generated package is correct.
        assert "collision" not in out.lower()

    def test_failed_generations_are_skipped(self, tmp_path: Path, capsys) -> None:
        from qamigrate.agents.pipeline import GenerationResult, _warn_package_collisions

        gen = GenerationResult(
            source_path=tmp_path / "Foo.java",
            output_path=None,
            success=False,
            error="LLM failed",
            class_name=None,
            signatures=[],
            analysis_patterns=[],
            original_code="",
            generated_code="",
            duration_seconds=0.0,
        )
        _warn_package_collisions([gen])  # Must not raise
        out = capsys.readouterr().out
        assert "collision" not in out.lower()
