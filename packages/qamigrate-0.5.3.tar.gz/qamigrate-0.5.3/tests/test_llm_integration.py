"""Integration tests for the LLM provider injection path.

We use FakeProvider throughout to keep tests fast and credit-free.
This is the proof that agents + pipeline actually respect the provider
abstraction -- not just that the abstraction compiles.
"""

from qamigrate.agents.coder import CoderAgent
from qamigrate.agents.fixer import FixerAgent
from qamigrate.core.config import CoderConfig, FixerConfig

from tests.helpers.fake_provider import FakeProvider


class TestProviderInjection:
    def test_coder_uses_injected_provider(self) -> None:
        """CoderAgent must delegate to the provider we pass in, not
        instantiate its own AnthropicProvider."""
        # A realistic tool_use response shape for the coder tool schema.
        scripted_response = {
            "package_name": "com.example.pages",
            "imports": ["com.microsoft.playwright.Page"],
            "class_declaration": "public class LoginPage",
            "fields": ["private final Page page;"],
            "constructor": "public LoginPage(Page page) { this.page = page; }",
            "methods": [
                {
                    "name": "navigate",
                    "signature": "public void navigate(String url)",
                    "implementation": "public void navigate(String url) { page.navigate(url); }",
                    "migration_note": "direct port",
                }
            ],
        }
        fake = FakeProvider([scripted_response])

        coder = CoderAgent(CoderConfig(), llm_provider=fake)
        result = coder.generate_from_class_info(
            class_info={"class_name": "LoginPage", "package": "com.example"},
            original_code="public class LoginPage {}",
            patterns=[],
        )

        # FakeProvider was called; result reflects scripted response.
        assert len(fake.calls) == 1
        assert result.package_name == "com.example.pages"
        assert result.class_declaration == "public class LoginPage"
        assert len(result.methods) == 1
        assert result.methods[0].name == "navigate"

    def test_fixer_uses_injected_provider(self) -> None:
        """FixerAgent routes LLM fallback through the injected provider."""
        # The fixer rejects output that's drastically shorter than the input,
        # so make the reply a reasonable-sized Java file with the marker
        # token we'll assert on.
        scripted_response = {
            "source": (
                "package com.example;\n\n"
                "public class Foo {\n"
                "    private final String fixedMarker = \"fixed\";\n"
                "    public Foo() {\n"
                "        System.out.println(fixedMarker);\n"
                "    }\n"
                "    public void bar() {\n"
                "        System.out.println(\"bar done\");\n"
                "    }\n"
                "    public void baz() {\n"
                "        System.out.println(\"baz done\");\n"
                "    }\n"
                "}\n"
            )
        }
        fake = FakeProvider([scripted_response])

        fixer = FixerAgent(FixerConfig(), llm_provider=fake)
        # Synthesize an error that WON'T be fixable by rule-based paths
        # so the LLM path actually runs.
        from qamigrate.agents.compiler import CompilerError, ErrorType

        errors = [
            CompilerError(
                file_path="Foo.java", line_number=3, column=5,
                error_type=ErrorType.UNKNOWN,
                message="some complex error only the LLM can handle",
                code_context="context",
            )
        ]

        buggy_code = (
            "package com.example;\n\n"
            "public class Foo {\n"
            "    public void bar() {\n"
            "        // the LLM will replace this\n"
            "    }\n"
            "}\n"
        )
        fixed_code, changes = fixer.fix(code=buggy_code, errors=errors, retry_count=0)

        assert len(fake.calls) == 1
        # The fixer accepted the LLM's output (it parses as Java).
        assert "fixedMarker" in fixed_code

    def test_fixer_handles_provider_unavailable(self) -> None:
        """When the provider raises, fixer returns unchanged code, not a crash."""
        from qamigrate.agents.compiler import CompilerError, ErrorType
        from qamigrate.llm.errors import LLMUnavailable

        fake = FakeProvider([LLMUnavailable("simulated outage")])
        fixer = FixerAgent(FixerConfig(), llm_provider=fake)

        errors = [
            CompilerError(
                file_path="Foo.java", line_number=1, column=1,
                error_type=ErrorType.UNKNOWN, message="bad", code_context="",
            )
        ]
        original = "public class Foo {}"

        fixed, changes = fixer.fix(code=original, errors=errors, retry_count=0)

        assert fixed == original
        assert changes == []
