"""A scripted LLMProvider for tests. Zero API calls, no credits burned."""

from __future__ import annotations

from typing import Any

from qamigrate.llm.base import LLMProvider, StructuredResponse, ToolSchema
from qamigrate.llm.errors import LLMMalformedOutput


class FakeProvider(LLMProvider):
    """
    LLMProvider that returns pre-scripted responses in order.

    Usage:
        fake = FakeProvider([{"source": "public class X {}"}, {"source": "..."}])
        fixer = FixerAgent(config, llm_provider=fake)

    On each call to `generate_structured`, pops the next dict from the
    script and returns it wrapped in a StructuredResponse. Raises
    LLMMalformedOutput if you exhaust the script but more calls happen.

    For tests that need to simulate an error, put an Exception subclass
    in the script; the FakeProvider raises it instead of returning.
    """

    name = "fake"
    model = "fake"
    supports_tool_use = True

    def __init__(
        self,
        responses: list[dict[str, Any] | Exception] | None = None,
    ) -> None:
        self._responses: list[dict[str, Any] | Exception] = list(responses or [])
        self.calls: list[tuple[str, str, ToolSchema]] = []  # for assertion

    def generate_structured(
        self,
        system: str,
        user: str,
        tool: ToolSchema,
        *,
        max_tokens: int = 4096,
        temperature: float = 0.0,
    ) -> StructuredResponse:
        self.calls.append((system, user, tool))

        if not self._responses:
            raise LLMMalformedOutput(
                "FakeProvider script exhausted. Set more responses in the test setup."
            )

        nxt = self._responses.pop(0)
        if isinstance(nxt, Exception):
            raise nxt

        return StructuredResponse(
            data=nxt,
            raw_text=None,
            provider="fake",
            model="fake",
            usage={},
        )

    @property
    def remaining(self) -> int:
        """How many scripted responses are left."""
        return len(self._responses)
