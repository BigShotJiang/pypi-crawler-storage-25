"""Tests for ClassRole inference.

These tests synthesize ClassInfo fixtures instead of parsing real files
so the rules are pinned independently of the parser."""

from __future__ import annotations

from qamigrate.intelligence.project_map import (
    ClassInfo,
    ClassRole,
    FieldInfo,
    MethodInfo,
    ParameterInfo,
)
from qamigrate.intelligence.role_inference import infer_role


def _ci(
    name: str = "Foo",
    package: str = "com.example",
    file_path: str = "/project/src/main/java/com/example/Foo.java",
    extends: str | None = None,
    implements: list[str] | None = None,
    modifiers: list[str] | None = None,
    public_methods: list[MethodInfo] | None = None,
    private_methods: list[MethodInfo] | None = None,
    fields: list[FieldInfo] | None = None,
) -> ClassInfo:
    return ClassInfo(
        name=name,
        fqn=f"{package}.{name}",
        file_path=file_path,
        package=package,
        extends=extends,
        implements=implements or [],
        modifiers=modifiers or ["public"],
        imports=[],
        public_methods=public_methods or [],
        private_methods=private_methods or [],
        fields=fields or [],
    )


def _method(
    name: str,
    modifiers: list[str] | None = None,
    annotations: list[str] | None = None,
    return_type: str = "void",
    parameters: list[ParameterInfo] | None = None,
) -> MethodInfo:
    return MethodInfo(
        name=name,
        modifiers=modifiers or ["public"],
        return_type=return_type,
        parameters=parameters or [],
        annotations=annotations or [],
    )


def _field(
    name: str,
    type_: str = "String",
    modifiers: list[str] | None = None,
    annotations: list[str] | None = None,
) -> FieldInfo:
    return FieldInfo(
        name=name,
        type=type_,
        modifiers=modifiers or ["private"],
        annotations=annotations or [],
    )


class TestListenerDetection:
    def test_itestlistener_wins(self) -> None:
        ci = _ci(implements=["ITestListener"])
        assert infer_role(ci) == ClassRole.LISTENER

    def test_iretryanalyzer_wins(self) -> None:
        ci = _ci(name="RetryAnalyzer", implements=["IRetryAnalyzer"])
        assert infer_role(ci) == ClassRole.LISTENER

    def test_junit5_testwatcher(self) -> None:
        ci = _ci(implements=["TestWatcher"])
        assert infer_role(ci) == ClassRole.LISTENER

    def test_package_only_listener(self) -> None:
        """Class in .listeners. package without marker interface still qualifies."""
        ci = _ci(
            name="CustomListener",
            package="com.example.listeners",
            file_path="/x/src/main/java/com/example/listeners/CustomListener.java",
        )
        assert infer_role(ci) == ClassRole.LISTENER


class TestDriverManagerDetection:
    def test_by_name(self) -> None:
        ci = _ci(name="DriverManager")
        assert infer_role(ci) == ClassRole.DRIVER_MANAGER

    def test_factory_name(self) -> None:
        ci = _ci(name="DriverFactory")
        assert infer_role(ci) == ClassRole.DRIVER_MANAGER


class TestConfigReaderDetection:
    def test_by_name(self) -> None:
        ci = _ci(name="ConfigurationReader")
        assert infer_role(ci) == ClassRole.CONFIG

    def test_by_package_fallback(self) -> None:
        ci = _ci(
            name="SomeConfig",
            package="com.example.config",
            file_path="/x/src/main/java/com/example/config/SomeConfig.java",
        )
        assert infer_role(ci) == ClassRole.CONFIG


class TestTestClassDetection:
    def test_has_test_annotation(self) -> None:
        ci = _ci(
            name="LoginTests",
            public_methods=[
                _method("testValidLogin", annotations=["@Test(priority = 1)"])
            ],
        )
        assert infer_role(ci) == ClassRole.TEST

    def test_junit5_testtemplate(self) -> None:
        ci = _ci(
            name="ParamTests",
            public_methods=[_method("runIt", annotations=["@TestTemplate"])],
        )
        assert infer_role(ci) == ClassRole.TEST

    def test_no_test_annotation_not_a_test_class(self) -> None:
        """Class named 'TestSomething' but no @Test method is NOT a test."""
        ci = _ci(
            name="TestHelper",
            public_methods=[_method("doStuff")],
        )
        # With no @Test annotation and name doesn't match utility heuristics
        # strongly, should fall through. Not asserting TEST here.
        role = infer_role(ci)
        assert role != ClassRole.TEST


class TestBaseClassDetection:
    def test_abstract_wins(self) -> None:
        ci = _ci(modifiers=["public", "abstract"])
        assert infer_role(ci) == ClassRole.BASE

    def test_base_prefix_with_protected_helpers(self) -> None:
        ci = _ci(
            name="BasePage",
            public_methods=[_method("navigate", modifiers=["protected"])],
        )
        assert infer_role(ci) == ClassRole.BASE

    def test_base_prefix_without_helpers_not_base(self) -> None:
        """A class named 'BaseFoo' but with no protected methods isn't classified as BASE."""
        ci = _ci(name="BaseModel")  # no methods at all
        role = infer_role(ci)
        assert role != ClassRole.BASE


class TestPageObjectDetection:
    def test_pages_package(self) -> None:
        ci = _ci(
            name="LoginPage",
            package="com.example.pages",
            file_path="/x/src/main/java/com/example/pages/LoginPage.java",
        )
        assert infer_role(ci) == ClassRole.PAGE

    def test_extends_basepage(self) -> None:
        ci = _ci(name="DashboardPage", extends="BasePage")
        assert infer_role(ci) == ClassRole.PAGE

    def test_findby_field(self) -> None:
        ci = _ci(
            name="CartPage",
            fields=[
                _field("loginBtn", type_="By", annotations=['@FindBy(id = "login")'])
            ],
        )
        assert infer_role(ci) == ClassRole.PAGE


class TestUtilityDetection:
    def test_all_static_methods_is_utility(self) -> None:
        ci = _ci(
            name="Log",
            public_methods=[
                _method("info", modifiers=["public", "static"]),
                _method("debug", modifiers=["public", "static"]),
            ],
        )
        assert infer_role(ci) == ClassRole.UTILITY

    def test_utils_package_mostly_static(self) -> None:
        ci = _ci(
            name="WaitUtils",
            package="com.example.utils",
            file_path="/x/src/main/java/com/example/utils/WaitUtils.java",
            public_methods=[
                _method("waitForElement", modifiers=["public", "static"]),
                _method("waitForClickability", modifiers=["public", "static"]),
                _method("internalHelper"),  # instance method, < 25% non-static
            ],
        )
        # 2 of 3 static == 67%, below 75% threshold, so the all-static
        # fallback doesn't fire. But the utils-package rule also needs
        # >= 75%. So this should NOT match utility -- let's assert that
        # and document it.
        role = infer_role(ci)
        # With 67% static, we DON'T call it a utility (safer default).
        assert role != ClassRole.UTILITY

    def test_mixed_class_not_utility(self) -> None:
        """A class with instance methods is not a utility."""
        ci = _ci(
            public_methods=[
                _method("doThing", modifiers=["public"]),
                _method("staticHelper", modifiers=["public", "static"]),
            ],
        )
        assert infer_role(ci) != ClassRole.UTILITY


class TestFallback:
    def test_unclassified_returns_other(self) -> None:
        ci = _ci(
            name="Random",
            public_methods=[_method("doStuff")],
        )
        assert infer_role(ci) == ClassRole.OTHER
