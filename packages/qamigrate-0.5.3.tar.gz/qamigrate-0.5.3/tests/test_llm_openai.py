"""Tests for OpenAIProvider.

All tests mock the OpenAI SDK client so we never hit the network.
Integration tests that actually call OpenAI live under
`tests/integration/` and are gated by env var (out of scope for v0.4.0).
"""

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from qamigrate.llm.base import ToolSchema
from qamigrate.llm.errors import LLMConfigError, LLMMalformedOutput


# Reusable tool schema for tests
TOOL = ToolSchema(
    name="emit_thing",
    description="Emit a thing",
    input_schema={"type": "object", "required": ["x"], "properties": {"x": {"type": "string"}}},
)


def _mock_openai_response(arguments_json: str):
    """Build a fake OpenAI response object that looks like the real SDK shape."""
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(
                    tool_calls=[
                        SimpleNamespace(
                            function=SimpleNamespace(
                                name="emit_thing",
                                arguments=arguments_json,
                            )
                        )
                    ],
                    content=None,
                )
            )
        ],
        usage=SimpleNamespace(prompt_tokens=10, completion_tokens=20),
    )


class TestOpenAIProvider:
    def test_requires_api_key(self, monkeypatch) -> None:
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        from qamigrate.llm.providers.openai import OpenAIProvider

        with pytest.raises(LLMConfigError, match="API key"):
            OpenAIProvider()

    def test_honors_explicit_api_key(self) -> None:
        from qamigrate.llm.providers.openai import OpenAIProvider

        # Just verify construction succeeds when a key is passed.
        provider = OpenAIProvider(api_key="sk-fake-key")
        assert provider.model == "gpt-4o"
        assert provider.name == "openai"
        assert provider.supports_tool_use is True

    def test_parses_tool_call(self, monkeypatch) -> None:
        """Successful call returns a dict matching the schema."""
        from qamigrate.llm.providers.openai import OpenAIProvider

        provider = OpenAIProvider(api_key="sk-fake")
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = _mock_openai_response(
            '{"x": "hello world"}'
        )
        provider._client = mock_client

        response = provider.generate_structured(
            system="sys",
            user="usr",
            tool=TOOL,
        )

        assert response.data == {"x": "hello world"}
        assert response.provider == "openai"
        assert response.usage["input_tokens"] == 10
        assert response.usage["output_tokens"] == 20

    def test_sanitizes_escaped_strings(self) -> None:
        """OpenAI sometimes double-escapes inside arguments; sanitizer must fix."""
        from qamigrate.llm.providers.openai import OpenAIProvider

        provider = OpenAIProvider(api_key="sk-fake")
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = _mock_openai_response(
            '{"x": "line1\\\\nline2"}'  # JSON-encoded -> Python string "line1\\nline2"
        )
        provider._client = mock_client

        response = provider.generate_structured(system="", user="", tool=TOOL)
        # After sanitize, the `\\n` two-char escape becomes a real newline.
        assert response.data["x"] == "line1\nline2"

    def test_malformed_json_raises(self) -> None:
        from qamigrate.llm.providers.openai import OpenAIProvider

        provider = OpenAIProvider(api_key="sk-fake")
        mock_client = MagicMock()
        mock_client.chat.completions.create.return_value = _mock_openai_response(
            "not valid json {{{"
        )
        provider._client = mock_client

        with pytest.raises(LLMMalformedOutput, match="JSON"):
            provider.generate_structured(system="", user="", tool=TOOL)

    def test_missing_tool_calls_raises(self) -> None:
        from qamigrate.llm.providers.openai import OpenAIProvider

        provider = OpenAIProvider(api_key="sk-fake")
        mock_client = MagicMock()
        # Build a response with no tool_calls (model returned text instead)
        mock_client.chat.completions.create.return_value = SimpleNamespace(
            choices=[SimpleNamespace(
                message=SimpleNamespace(tool_calls=[], content="Here is your answer..."),
            )],
            usage=None,
        )
        provider._client = mock_client

        with pytest.raises(LLMMalformedOutput, match="no tool_calls"):
            provider.generate_structured(system="", user="", tool=TOOL)

    def test_base_url_override_for_azure_or_proxy(self) -> None:
        """Passing base_url should be stored for visibility."""
        from qamigrate.llm.providers.openai import OpenAIProvider

        provider = OpenAIProvider(
            api_key="sk-fake",
            base_url="http://localhost:1234/v1",
        )
        assert provider._base_url == "http://localhost:1234/v1"
