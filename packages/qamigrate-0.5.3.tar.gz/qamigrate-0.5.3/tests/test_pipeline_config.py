"""Tests for v0.3+ pipeline switches: batch_compile flag behavior."""

from qamigrate.core.config import PipelineConfig, QAMigrateConfig


class TestPipelineConfig:
    def test_batch_compile_defaults_to_true(self) -> None:
        """The v0.3+ whole-project batch compile is the default."""
        cfg = PipelineConfig()
        assert cfg.batch_compile is True

    def test_batch_compile_can_be_disabled(self) -> None:
        """--no-batch-compile must map to batch_compile=False for the v0.2
        per-file fallback."""
        cfg = PipelineConfig(batch_compile=False)
        assert cfg.batch_compile is False

    def test_max_retries_default(self) -> None:
        cfg = PipelineConfig()
        assert cfg.max_retries == 3

    def test_qamigrate_config_composes_pipeline(self) -> None:
        cfg = QAMigrateConfig()
        assert cfg.pipeline.batch_compile is True
        assert cfg.classpath.timeout_seconds == 60
        assert cfg.classpath.use_cache is True

    def test_config_honors_env_override_for_batch_compile(self, monkeypatch) -> None:
        """QAMIGRATE_PIPELINE__BATCH_COMPILE=false should disable it without
        code changes."""
        monkeypatch.setenv("QAMIGRATE_PIPELINE__BATCH_COMPILE", "false")
        cfg = QAMigrateConfig()
        assert cfg.pipeline.batch_compile is False
