"""Tests for ClasspathResolver -- mock subprocess so no real mvn needed."""

import subprocess
from pathlib import Path
from unittest.mock import patch

from qamigrate.agents.classpath import ClasspathResolver, ClasspathResult


class TestClasspathResolver:
    def test_maven_success_writes_output_file(self, tmp_path: Path) -> None:
        """Simulate mvn success by writing the expected output file ourselves."""
        resolver = ClasspathResolver(timeout_seconds=5)

        def fake_run(cmd, **kwargs):  # noqa: ANN001
            # Find the output file arg and write a fake classpath to it.
            out_arg = next((a for a in cmd if a.startswith("-Dmdep.outputFile=")), "")
            out_file = Path(out_arg.split("=", 1)[1])
            out_file.write_text("/jars/playwright.jar;/jars/junit.jar")

            class FakeProc:
                returncode = 0
                stdout = ""
                stderr = ""
            return FakeProc()

        with patch("qamigrate.agents.classpath.subprocess.run", side_effect=fake_run):
            result = resolver.resolve(tmp_path, "maven", use_cache=False)

        assert result.ok
        # Either ; or : was the separator depending on os.pathsep; both paths
        # should be present.
        assert any("playwright" in str(p) for p in result.entries)

    def test_maven_not_installed(self, tmp_path: Path) -> None:
        resolver = ClasspathResolver(timeout_seconds=5)

        with patch(
            "qamigrate.agents.classpath.subprocess.run",
            side_effect=FileNotFoundError("no mvn"),
        ):
            result = resolver.resolve(tmp_path, "maven", use_cache=False)

        assert not result.ok
        assert result.entries == []
        assert "not found" in (result.reason or "").lower()

    def test_maven_timeout(self, tmp_path: Path) -> None:
        resolver = ClasspathResolver(timeout_seconds=1)

        with patch(
            "qamigrate.agents.classpath.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd=["mvn"], timeout=1),
        ):
            result = resolver.resolve(tmp_path, "maven", use_cache=False)

        assert not result.ok
        assert "timed out" in (result.reason or "").lower()

    def test_maven_nonzero_exit(self, tmp_path: Path) -> None:
        resolver = ClasspathResolver(timeout_seconds=5)

        def fake_run(cmd, **kwargs):  # noqa: ANN001
            class FakeProc:
                returncode = 1
                stdout = ""
                stderr = "[ERROR] Could not resolve dependencies"
            return FakeProc()

        with patch("qamigrate.agents.classpath.subprocess.run", side_effect=fake_run):
            result = resolver.resolve(tmp_path, "maven", use_cache=False)

        assert not result.ok
        assert "exit" in (result.reason or "").lower()

    def test_gradle_returns_unsupported(self, tmp_path: Path) -> None:
        resolver = ClasspathResolver(timeout_seconds=5)
        result = resolver.resolve(tmp_path, "gradle", use_cache=False)
        assert not result.ok
        assert "gradle" in (result.reason or "").lower()

    def test_cache_is_used_when_present(self, tmp_path: Path) -> None:
        resolver = ClasspathResolver(timeout_seconds=5)
        cache_dir = tmp_path / ".qamigrate"
        cache_dir.mkdir()
        jar_path = tmp_path / "fake.jar"
        jar_path.write_text("fake jar content")
        (cache_dir / "classpath.txt").write_text(str(jar_path))

        # subprocess.run should NOT be called because cache is fresh
        with patch("qamigrate.agents.classpath.subprocess.run") as mock_run:
            result = resolver.resolve(tmp_path, "maven")

        assert result.ok
        assert result.cached
        mock_run.assert_not_called()

    def test_cache_ignored_with_use_cache_false(self, tmp_path: Path) -> None:
        resolver = ClasspathResolver(timeout_seconds=5)
        cache_dir = tmp_path / ".qamigrate"
        cache_dir.mkdir()
        (cache_dir / "classpath.txt").write_text(str(tmp_path / "cached.jar"))

        with patch(
            "qamigrate.agents.classpath.subprocess.run",
            side_effect=FileNotFoundError(),
        ):
            result = resolver.resolve(tmp_path, "maven", use_cache=False)

        # Falls through to subprocess call which we made fail
        assert not result.ok
        assert not result.cached

    def test_clear_cache(self, tmp_path: Path) -> None:
        resolver = ClasspathResolver()
        cache_dir = tmp_path / ".qamigrate"
        cache_dir.mkdir()
        cache_file = cache_dir / "classpath.txt"
        cache_file.write_text("x")

        resolver.clear_cache(tmp_path)
        assert not cache_file.exists()
