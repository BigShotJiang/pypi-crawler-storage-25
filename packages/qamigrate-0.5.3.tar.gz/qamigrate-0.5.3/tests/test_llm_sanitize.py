"""Tests for the shared LLM output sanitizers.

These used to live in CoderAgent / FixerAgent. Moving them to
qamigrate.llm.sanitize means every provider benefits -- but we need
regression tests proving the move was faithful.
"""

from qamigrate.llm.sanitize import (
    sanitize_fields,
    strip_stray_markdown,
    unescape_llm_string,
)


class TestUnescapeLLMString:
    def test_non_string_passes_through(self) -> None:
        assert unescape_llm_string(42) == 42
        assert unescape_llm_string(None) is None
        assert unescape_llm_string(True) is True

    def test_clean_string_untouched(self) -> None:
        s = 'public class Foo { void bar() {} }'
        assert unescape_llm_string(s) == s

    def test_literal_backslash_n_becomes_newline(self) -> None:
        s = "line1\\nline2"
        assert unescape_llm_string(s) == "line1\nline2"

    def test_real_newlines_not_double_unescaped(self) -> None:
        """If the string already has a real newline, leave the `\\n` alone."""
        s = "line1\nline2 and literal\\nhere"
        # "\\n" present, "\n" also present -> skip entirely
        assert unescape_llm_string(s) == s

    def test_literal_backslash_quote_always_unescaped(self) -> None:
        """`\\"` is never valid in generated Java source, so always unescape."""
        s = 'page.locator(\\"#foo\\")'
        assert unescape_llm_string(s) == 'page.locator("#foo")'


class TestSanitizeFields:
    def test_shallow_strings(self) -> None:
        out = sanitize_fields({"a": "x\\nY", "b": 1})
        assert out["a"] == "x\nY"
        assert out["b"] == 1

    def test_nested_dict(self) -> None:
        out = sanitize_fields({"outer": {"inner": "x\\nY"}})
        assert out["outer"]["inner"] == "x\nY"

    def test_list_of_strings(self) -> None:
        out = sanitize_fields({"items": ["a\\nb", "c"]})
        assert out["items"] == ["a\nb", "c"]

    def test_list_of_dicts(self) -> None:
        out = sanitize_fields({"items": [{"k": "a\\nb"}, {"k": "c"}]})
        assert out["items"][0]["k"] == "a\nb"
        assert out["items"][1]["k"] == "c"


class TestStripStrayMarkdown:
    def test_no_fence_passthrough(self) -> None:
        s = "public class Foo {}"
        assert strip_stray_markdown(s) == s

    def test_java_fence(self) -> None:
        s = "```java\npublic class Foo {}\n```"
        assert strip_stray_markdown(s) == "public class Foo {}"

    def test_bare_fence(self) -> None:
        s = "```\npublic class Foo {}\n```"
        assert strip_stray_markdown(s) == "public class Foo {}"

    def test_leading_whitespace_tolerated(self) -> None:
        s = "   \n\n```java\nx\n```"
        # strip() in the function removes leading whitespace first
        assert strip_stray_markdown(s) == "x"


class TestEscapeForCodeFence:
    """Ensure Java source with stray ``` can't break out of prompt fences."""

    def test_clean_source_unchanged(self) -> None:
        from qamigrate.llm.sanitize import escape_for_code_fence
        s = "public class Foo { void bar() {} }"
        assert escape_for_code_fence(s) == s

    def test_backticks_in_text_block_are_neutralized(self) -> None:
        """Java 15+ text blocks can legitimately contain ``` and should
        be neutralized before embedding in a markdown-fenced prompt."""
        from qamigrate.llm.sanitize import escape_for_code_fence
        # Simulate a Java text block with markdown content
        s = 'String md = """\n# Heading\n```java\ncode\n```\n""";'
        out = escape_for_code_fence(s)
        # Zero-width spaces break the 3-backtick run
        assert "```" not in out
        # Original structure otherwise preserved
        assert "String md" in out
        assert "# Heading" in out

    def test_triple_backtick_breaks_into_parts(self) -> None:
        from qamigrate.llm.sanitize import escape_for_code_fence
        s = "before ``` after"
        out = escape_for_code_fence(s)
        assert "```" not in out
        assert "before" in out
        assert "after" in out

    def test_single_backtick_unchanged(self) -> None:
        """`foo` (inline code) is allowed; only ``` fences are risky."""
        from qamigrate.llm.sanitize import escape_for_code_fence
        s = "See `Locator.click()` for details"
        assert escape_for_code_fence(s) == s
