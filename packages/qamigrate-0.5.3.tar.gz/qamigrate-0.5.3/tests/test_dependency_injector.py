"""Tests for DependencyInjector (Maven pom.xml + Gradle build.gradle)."""

from pathlib import Path

from qamigrate.agents.dependency_injector import (
    JUNIT_VERSION,
    PLAYWRIGHT_VERSION,
    DependencyInjector,
)

POM_NO_DEPS = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
</project>
"""

POM_WITH_OTHER_DEPS = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
    <dependencies>
        <dependency>
            <groupId>org.seleniumhq.selenium</groupId>
            <artifactId>selenium-java</artifactId>
            <version>4.15.0</version>
        </dependency>
    </dependencies>
</project>
"""

POM_WITH_PLAYWRIGHT = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
    <dependencies>
        <dependency>
            <groupId>com.microsoft.playwright</groupId>
            <artifactId>playwright</artifactId>
            <version>1.40.0</version>
        </dependency>
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>5.10.0</version>
        </dependency>
    </dependencies>
</project>
"""


class TestMavenInjector:
    def test_adds_deps_to_empty_pom(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(POM_NO_DEPS)

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("maven")

        assert result.changed is True
        assert len(result.added) == 2
        content = pom.read_text()
        assert "com.microsoft.playwright" in content
        assert PLAYWRIGHT_VERSION in content
        assert "org.junit.jupiter" in content
        assert JUNIT_VERSION in content

    def test_appends_to_existing_deps_block(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(POM_WITH_OTHER_DEPS)

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("maven")

        assert result.changed is True
        content = pom.read_text()
        # Existing selenium dep should be preserved
        assert "selenium-java" in content
        assert "com.microsoft.playwright" in content

    def test_idempotent(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(POM_WITH_PLAYWRIGHT)

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("maven")

        assert result.changed is False
        assert len(result.added) == 0
        assert len(result.already_present) == 2

    def test_missing_pom_returns_warning(self, tmp_path: Path) -> None:
        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("maven")

        assert result.changed is False
        assert result.warning is not None
        assert "pom.xml" in result.warning

    def test_malformed_pom_returns_warning(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text("<project>this is not closed<dependencies>")

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("maven")

        assert result.changed is False
        assert result.warning is not None
        assert "could not be parsed" in result.warning.lower() or "parse" in result.warning.lower()

    def test_preserves_xml_declaration_and_comments(self, tmp_path: Path) -> None:
        """Regression for v0.3.0 bug: ElementTree.tostring() stripped
        comments and the XML declaration."""
        pom_with_comments = """<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright (c) QATonic 2026 -->
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>

    <!-- We pin Selenium to 4.15 because of the bug in 4.16 -->
    <dependencies>
        <!-- Core UI driver -->
        <dependency>
            <groupId>org.seleniumhq.selenium</groupId>
            <artifactId>selenium-java</artifactId>
            <version>4.15.0</version>
        </dependency>
    </dependencies>
</project>
"""
        pom = tmp_path / "pom.xml"
        pom.write_text(pom_with_comments)

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("maven")

        assert result.changed is True
        content = pom.read_text()

        # XML declaration preserved
        assert content.startswith('<?xml version="1.0" encoding="UTF-8"?>')
        # All four original comments preserved
        assert "<!-- Copyright (c) QATonic 2026 -->" in content
        assert "<!-- We pin Selenium to 4.15 because of the bug in 4.16 -->" in content
        assert "<!-- Core UI driver -->" in content
        # Multi-line <project> attributes preserved (not collapsed)
        assert "xmlns:xsi=" in content
        assert "xsi:schemaLocation=" in content
        # Existing selenium dep preserved verbatim
        assert "<artifactId>selenium-java</artifactId>" in content
        # New deps added
        assert "<artifactId>playwright</artifactId>" in content
        assert "<artifactId>junit-jupiter</artifactId>" in content

    def test_no_dependencies_block_creates_one(self, tmp_path: Path) -> None:
        """If the pom has no <dependencies> block, we should add one before </project>."""
        pom = tmp_path / "pom.xml"
        pom.write_text(POM_NO_DEPS)

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("maven")

        assert result.changed is True
        content = pom.read_text()
        # XML declaration preserved
        assert content.startswith('<?xml version="1.0" encoding="UTF-8"?>')
        # A <dependencies> block was added
        assert "<dependencies>" in content
        assert "</dependencies>" in content
        # </project> still closes properly
        assert content.rstrip().endswith("</project>")

    def test_idempotent_byte_for_byte(self, tmp_path: Path) -> None:
        """A second injection must leave the file BYTE-FOR-BYTE identical.
        This is what users want so that `git diff` after re-running init
        is empty."""
        pom_with_everything = """<?xml version="1.0" encoding="UTF-8"?>
<!-- Copyright 2026 -->
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
    <!-- Keep these pinned -->
    <dependencies>
        <dependency>
            <groupId>com.microsoft.playwright</groupId>
            <artifactId>playwright</artifactId>
            <version>1.48.0</version>
            <scope>test</scope>
        </dependency>
        <dependency>
            <groupId>org.junit.jupiter</groupId>
            <artifactId>junit-jupiter</artifactId>
            <version>5.11.3</version>
            <scope>test</scope>
        </dependency>
    </dependencies>
</project>
"""
        pom = tmp_path / "pom.xml"
        pom.write_text(pom_with_everything)
        before = pom.read_bytes()

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("maven")
        assert result.changed is False

        after = pom.read_bytes()
        assert before == after

    def test_line_count_grows_predictably(self, tmp_path: Path) -> None:
        """Adding two deps should add 12 lines (6 per dependency block),
        not reformat the whole file as ElementTree used to."""
        original = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
    <dependencies>
        <dependency>
            <groupId>org.seleniumhq.selenium</groupId>
            <artifactId>selenium-java</artifactId>
            <version>4.15.0</version>
        </dependency>
    </dependencies>
</project>
"""
        pom = tmp_path / "pom.xml"
        pom.write_text(original)
        original_lines = original.count("\n")

        injector = DependencyInjector(tmp_path)
        injector.ensure_playwright_deps("maven")

        new_lines = pom.read_text().count("\n")
        # v0.5.3: Playwright has no <scope> (5 lines), JUnit5 keeps
        # <scope>test</scope> (6 lines). Total: 11 new lines.
        assert new_lines - original_lines == 11


GRADLE_NO_DEPS = """plugins {
    id 'java'
}

repositories {
    mavenCentral()
}
"""

GRADLE_WITH_DEPS = """plugins {
    id 'java'
}

repositories {
    mavenCentral()
}

dependencies {
    testImplementation "org.seleniumhq.selenium:selenium-java:4.15.0"
}
"""

GRADLE_WITH_PLAYWRIGHT = """plugins {
    id 'java'
}

dependencies {
    testImplementation "com.microsoft.playwright:playwright:1.40.0"
    testImplementation "org.junit.jupiter:junit-jupiter:5.10.0"
}
"""


class TestGradleInjector:
    def test_adds_deps_when_no_block_exists(self, tmp_path: Path) -> None:
        gradle = tmp_path / "build.gradle"
        gradle.write_text(GRADLE_NO_DEPS)

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("gradle")

        assert result.changed is True
        content = gradle.read_text()
        assert "dependencies {" in content
        assert "com.microsoft.playwright" in content
        assert "org.junit.jupiter" in content

    def test_appends_to_existing_block(self, tmp_path: Path) -> None:
        gradle = tmp_path / "build.gradle"
        gradle.write_text(GRADLE_WITH_DEPS)

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("gradle")

        assert result.changed is True
        content = gradle.read_text()
        # Must preserve the selenium line
        assert "selenium-java" in content
        # Must contain exactly one dependencies block
        assert content.count("dependencies {") == 1
        assert "com.microsoft.playwright" in content

    def test_idempotent(self, tmp_path: Path) -> None:
        gradle = tmp_path / "build.gradle"
        gradle.write_text(GRADLE_WITH_PLAYWRIGHT)

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("gradle")

        assert result.changed is False
        assert len(result.added) == 0

    def test_kotlin_dsl_unsupported(self, tmp_path: Path) -> None:
        (tmp_path / "build.gradle.kts").write_text("dependencies {}")

        injector = DependencyInjector(tmp_path)
        result = injector.ensure_playwright_deps("gradle")

        assert result.changed is False
        assert result.warning is not None
        assert "Kotlin DSL" in result.warning or "build.gradle.kts" in result.warning
