"""Tests for migration state management."""

from qamigrate.agents.state import (
    Phase,
    _utcnow_iso,
    add_error_to_state,
    create_initial_state,
    update_state_timestamp,
)


class TestMigrationState:
    """Tests for MigrationState lifecycle."""

    def test_create_initial_state(self) -> None:
        state = create_initial_state(
            file_path="/path/to/LoginPage.java",
            project_path="/path/to/project",
        )

        assert state["file_path"] == "/path/to/LoginPage.java"
        assert state["project_path"] == "/path/to/project"
        assert state["phase"] == Phase.INIT
        assert state["retry_count"] == 0
        assert state["errors"] == []

    def test_update_timestamp(self) -> None:
        state = create_initial_state("/test.java", "/project")
        original_time = state["updated_at"]

        import time
        time.sleep(0.01)

        state = update_state_timestamp(state)
        assert state["updated_at"] != original_time

    def test_add_error(self) -> None:
        state = create_initial_state("/test.java", "/project")

        state = add_error_to_state(
            state,
            error_type="TestError",
            message="Something went wrong",
        )

        assert len(state["errors"]) == 1
        assert state["errors"][0]["error_type"] == "TestError"
        assert state["errors"][0]["message"] == "Something went wrong"

    def test_utcnow_is_timezone_aware(self) -> None:
        """Regression: datetime.utcnow() was deprecated in Python 3.12."""
        from datetime import datetime
        ts = _utcnow_iso()
        parsed = datetime.fromisoformat(ts)
        assert parsed.tzinfo is not None
