"""Tests for the cross-class dependency graph builder."""

from __future__ import annotations

from qamigrate.intelligence.dependency_graph import build_edges
from qamigrate.intelligence.project_map import (
    ClassInfo,
    DependencyKind,
    FieldInfo,
    MethodInfo,
)


def _ci(
    name: str,
    package: str = "com.example",
    extends: str | None = None,
    implements: list[str] | None = None,
    imports: list[str] | None = None,
    fields: list[FieldInfo] | None = None,
    methods: list[MethodInfo] | None = None,
) -> ClassInfo:
    return ClassInfo(
        name=name,
        fqn=f"{package}.{name}",
        file_path=f"/x/{name}.java",
        package=package,
        extends=extends,
        implements=implements or [],
        modifiers=["public"],
        imports=imports or [],
        public_methods=methods or [],
        fields=fields or [],
    )


def _m(name: str, body: str = "") -> MethodInfo:
    return MethodInfo(
        name=name, modifiers=["public"], return_type="void",
        parameters=[], annotations=[], body=body,
    )


def _f(name: str, type_: str) -> FieldInfo:
    return FieldInfo(
        name=name, type=type_, modifiers=["private"], annotations=[],
    )


def _kinds(edges, source: str) -> dict[str, DependencyKind]:
    """Collect a {target: kind} map of all edges from `source`."""
    return {e.target: e.kind for e in edges if e.source == source}


class TestStructuralEdges:
    def test_extends(self) -> None:
        base = _ci("BasePage")
        page = _ci("LoginPage", extends="BasePage")
        edges = build_edges({base.fqn: base, page.fqn: page})
        kinds = _kinds(edges, page.fqn)
        assert kinds["com.example.BasePage"] == DependencyKind.EXTENDS

    def test_implements(self) -> None:
        listener_iface = _ci("ITestListener")
        tl = _ci("TestListener", implements=["ITestListener"])
        edges = build_edges({listener_iface.fqn: listener_iface, tl.fqn: tl})
        kinds = _kinds(edges, tl.fqn)
        assert kinds["com.example.ITestListener"] == DependencyKind.IMPLEMENTS

    def test_no_self_edges(self) -> None:
        """A class should never emit an edge targeting itself."""
        foo = _ci("Foo", extends="Foo")
        edges = build_edges({foo.fqn: foo})
        assert [e for e in edges if e.source == e.target] == []


class TestFieldTypeEdges:
    def test_simple_type(self) -> None:
        base = _ci("BasePage")
        page = _ci(
            "LoginPage",
            fields=[_f("base", "BasePage")],
        )
        edges = build_edges({base.fqn: base, page.fqn: page})
        kinds = _kinds(edges, page.fqn)
        assert kinds["com.example.BasePage"] == DependencyKind.FIELD_TYPE

    def test_generic_type(self) -> None:
        dm = _ci("DriverManager")
        page = _ci(
            "Holder",
            fields=[_f("dms", "List<DriverManager>")],
        )
        edges = build_edges({dm.fqn: dm, page.fqn: page})
        kinds = _kinds(edges, page.fqn)
        assert kinds["com.example.DriverManager"] == DependencyKind.FIELD_TYPE

    def test_external_type_ignored(self) -> None:
        """String, List, WebElement aren't in-project -> no edge."""
        page = _ci("LoginPage",
                   fields=[_f("name", "String"), _f("el", "WebElement")])
        edges = build_edges({page.fqn: page})
        assert edges == []


class TestMethodBodyEdges:
    def test_new_instantiation(self) -> None:
        page = _ci("LoginPage")
        test = _ci("LoginTests",
                   methods=[_m("testIt", body="{ LoginPage p = new LoginPage(driver); }")])
        edges = build_edges({page.fqn: page, test.fqn: test})
        kinds = _kinds(edges, test.fqn)
        assert kinds["com.example.LoginPage"] == DependencyKind.INSTANTIATES

    def test_static_call(self) -> None:
        log = _ci("Log")
        page = _ci("BasePage",
                   methods=[_m("click", body="{ Log.action(\"Click\"); }")])
        edges = build_edges({log.fqn: log, page.fqn: page})
        kinds = _kinds(edges, page.fqn)
        assert kinds["com.example.Log"] == DependencyKind.STATIC_CALL

    def test_static_call_records_method_symbol(self) -> None:
        log = _ci("Log")
        page = _ci("BasePage",
                   methods=[_m("click", body="{ Log.action(\"Click\"); }")])
        edges = build_edges({log.fqn: log, page.fqn: page})
        call_edges = [
            e for e in edges
            if e.source == page.fqn and e.kind == DependencyKind.STATIC_CALL
        ]
        assert call_edges[0].symbol == "action"


class TestImportEdges:
    def test_import_only_no_deduper(self) -> None:
        """Imported in-project class with no other relationship -> IMPORT edge."""
        util = _ci("Log")
        foo = _ci("Foo", imports=["com.example.Log"])  # imports but never calls
        edges = build_edges({util.fqn: util, foo.fqn: foo})
        kinds = _kinds(edges, foo.fqn)
        assert kinds["com.example.Log"] == DependencyKind.IMPORT

    def test_import_deduped_when_stronger_edge_exists(self) -> None:
        """If we already emitted STATIC_CALL for Log, we shouldn't also emit IMPORT."""
        util = _ci("Log")
        foo = _ci(
            "Foo",
            imports=["com.example.Log"],
            methods=[_m("bar", body="{ Log.info(\"x\"); }")],
        )
        edges = build_edges({util.fqn: util, foo.fqn: foo})
        import_edges = [
            e for e in edges
            if e.source == foo.fqn
            and e.target == util.fqn
            and e.kind == DependencyKind.IMPORT
        ]
        assert import_edges == []

    def test_external_imports_ignored(self) -> None:
        """java.util.List is not in-project -> no IMPORT edge."""
        foo = _ci("Foo", imports=["java.util.List"])
        edges = build_edges({foo.fqn: foo})
        assert edges == []


class TestRealisticSampleGraph:
    """One integrated test mirroring the sample project's real shape."""

    def test_login_tests_login_page_basepage_driver_manager(self) -> None:
        driver = _ci("DriverManager", package="com.example.core")
        base = _ci(
            "BasePage",
            package="com.example.pages",
            methods=[_m("click", body="{ DriverManager.getDriver(); }")],
        )
        page = _ci(
            "LoginPage",
            package="com.example.pages",
            extends="BasePage",
            methods=[_m("login", body="{ this.click(); }")],
        )
        test = _ci(
            "LoginTests",
            package="com.example.tests",
            methods=[_m(
                "testValidLogin",
                body="{ LoginPage p = new LoginPage(driver); p.login(); }",
            )],
        )

        classes = {
            driver.fqn: driver,
            base.fqn: base,
            page.fqn: page,
            test.fqn: test,
        }
        edges = build_edges(classes)

        # LoginTests --INSTANTIATES--> LoginPage
        assert any(
            e.source == test.fqn and e.target == page.fqn
            and e.kind == DependencyKind.INSTANTIATES
            for e in edges
        )
        # LoginPage --EXTENDS--> BasePage
        assert any(
            e.source == page.fqn and e.target == base.fqn
            and e.kind == DependencyKind.EXTENDS
            for e in edges
        )
        # BasePage --STATIC_CALL--> DriverManager (via getDriver)
        assert any(
            e.source == base.fqn and e.target == driver.fqn
            and e.kind == DependencyKind.STATIC_CALL
            for e in edges
        )
