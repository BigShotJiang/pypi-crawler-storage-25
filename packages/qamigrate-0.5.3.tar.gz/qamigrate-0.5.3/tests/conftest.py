"""Test configuration and fixtures for QAMigrate."""

from pathlib import Path
from typing import Generator

import pytest


@pytest.fixture
def sample_selenium_code() -> str:
    """Sample Selenium Java code for testing."""
    return '''package com.example.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage {
    
    private WebDriver driver;
    
    @FindBy(id = "username")
    private WebElement usernameField;
    
    @FindBy(id = "password")
    private WebElement passwordField;
    
    @FindBy(css = "button[type='submit']")
    private WebElement submitButton;
    
    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void login(String username, String password) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOf(usernameField));
        
        usernameField.clear();
        usernameField.sendKeys(username);
        passwordField.sendKeys(password);
        submitButton.click();
    }
    
    public boolean isLoginSuccessful() {
        return driver.findElement(By.className("dashboard")).isDisplayed();
    }
}
'''


@pytest.fixture
def sample_selenium_test() -> str:
    """Sample Selenium test class for testing."""
    return '''package com.example.tests;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import static org.testng.Assert.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.example.pages.LoginPage;

public class LoginTest {
    
    private WebDriver driver;
    private LoginPage loginPage;
    
    @BeforeMethod
    public void setUp() {
        driver = new ChromeDriver();
        driver.get("https://example.com/login");
        loginPage = new LoginPage(driver);
    }
    
    @Test
    public void testValidLogin() {
        loginPage.login("admin", "password123");
        assertTrue(loginPage.isLoginSuccessful());
    }
    
    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
'''


@pytest.fixture
def temp_project(tmp_path: Path, sample_selenium_code: str) -> Path:
    """Create a temporary project structure for testing."""
    # Create directory structure
    src_dir = tmp_path / "src" / "test" / "java" / "com" / "example" / "pages"
    src_dir.mkdir(parents=True)
    
    # Write sample file
    login_page = src_dir / "LoginPage.java"
    login_page.write_text(sample_selenium_code)
    
    # Create pom.xml
    pom_xml = tmp_path / "pom.xml"
    pom_xml.write_text('''<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>selenium-tests</artifactId>
    <version>1.0.0</version>
    <dependencies>
        <dependency>
            <groupId>org.seleniumhq.selenium</groupId>
            <artifactId>selenium-java</artifactId>
            <version>4.15.0</version>
        </dependency>
        <dependency>
            <groupId>org.testng</groupId>
            <artifactId>testng</artifactId>
            <version>7.8.0</version>
        </dependency>
    </dependencies>
</project>
''')
    
    return tmp_path
