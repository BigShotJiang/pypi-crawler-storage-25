"""Tests for project-wide convention detection."""

from __future__ import annotations

from qamigrate.intelligence.convention_detector import detect_conventions
from qamigrate.intelligence.project_map import (
    ClassInfo,
    ClassRole,
    FieldInfo,
    MethodInfo,
    ParameterInfo,
)


def _ci(
    name: str,
    role: ClassRole = ClassRole.OTHER,
    methods: list[MethodInfo] | None = None,
    fields: list[FieldInfo] | None = None,
    imports: list[str] | None = None,
    implements: list[str] | None = None,
    modifiers: list[str] | None = None,
) -> ClassInfo:
    return ClassInfo(
        name=name, fqn=f"com.example.{name}",
        file_path=f"/x/{name}.java", package="com.example",
        extends=None, implements=implements or [],
        modifiers=modifiers or ["public"], imports=imports or [],
        role=role,
        public_methods=methods or [], fields=fields or [],
    )


def _m(name: str, body: str = "", annotations: list[str] | None = None,
       return_type: str = "void", modifiers: list[str] | None = None) -> MethodInfo:
    return MethodInfo(
        name=name, modifiers=modifiers or ["public"], return_type=return_type,
        parameters=[], annotations=annotations or [], body=body,
    )


class TestMethodChaining:
    def test_detected_when_two_page_methods_return_this(self) -> None:
        page = _ci(
            "LoginPage", role=ClassRole.PAGE,
            methods=[
                _m("enterUsername", body="{ usernameInput.fill(u); return this; }",
                   return_type="LoginPage"),
                _m("enterPassword", body="{ passwordInput.fill(p); return this; }",
                   return_type="LoginPage"),
                _m("clickLogin", body="{ loginButton.click(); }"),
            ],
        )
        conv = detect_conventions({"LoginPage": page})
        assert conv.method_chaining is True
        assert conv.method_chaining_detected is True

    def test_not_detected_with_only_one_return_this(self) -> None:
        page = _ci(
            "LoginPage", role=ClassRole.PAGE,
            methods=[
                _m("enterUsername", body="{ u(); return this; }", return_type="LoginPage"),
                _m("clickLogin", body="{ loginButton.click(); }"),
            ],
        )
        conv = detect_conventions({"LoginPage": page})
        assert conv.method_chaining is False


class TestLoggerDetection:
    def test_log_info_pattern(self) -> None:
        c = _ci(
            "Foo", role=ClassRole.OTHER,
            methods=[_m("bar", body="{ Log.info(\"hi\"); }")],
        )
        conv = detect_conventions({"Foo": c})
        assert conv.logger_call_pattern == "Log.info"

    def test_logger_pattern(self) -> None:
        c = _ci(
            "Foo", role=ClassRole.OTHER,
            methods=[_m("bar", body="{ logger.info(\"hi\"); }")],
        )
        conv = detect_conventions({"Foo": c})
        assert conv.logger_call_pattern == "logger.info"

    def test_system_out_fallback(self) -> None:
        c = _ci(
            "Foo", role=ClassRole.OTHER,
            methods=[_m("bar", body="{ System.out.println(\"hi\"); }")],
        )
        conv = detect_conventions({"Foo": c})
        assert conv.logger_call_pattern == "System.out"


class TestLogsEveryAction:
    def test_base_page_click_logs_first(self) -> None:
        base = _ci(
            "BasePage", role=ClassRole.BASE,
            methods=[
                _m("click", body="{ Log.action(\"Click\"); driver.click(); }"),
                _m("type",  body="{ Log.action(\"Type\"); driver.type(); }"),
            ],
        )
        conv = detect_conventions({"BasePage": base})
        assert conv.logs_every_action is True

    def test_when_no_base_class_not_detected(self) -> None:
        # No BASE class in the project -> can't detect convention
        c = _ci("Foo", role=ClassRole.OTHER,
                methods=[_m("click", body="{ driver.click(); }")])
        conv = detect_conventions({"Foo": c})
        assert conv.logs_every_action is False
        assert conv.logs_every_action_detected is False


class TestAssertionStyle:
    def test_testng_import(self) -> None:
        c = _ci("T", imports=["org.testng.Assert"])
        conv = detect_conventions({"T": c})
        assert conv.assertion_style == "testng"

    def test_junit5_import(self) -> None:
        c = _ci("T", imports=["org.junit.jupiter.api.Assertions"])
        conv = detect_conventions({"T": c})
        assert conv.assertion_style == "junit5"

    def test_assertj_body(self) -> None:
        c = _ci("T",
                methods=[_m("bar", body="{ assertThat(x).isTrue(); }")])
        conv = detect_conventions({"T": c})
        assert conv.assertion_style == "assertj"


class TestDriverAccess:
    def test_threadlocal_detected(self) -> None:
        dm = _ci(
            "DriverManager", role=ClassRole.DRIVER_MANAGER,
            fields=[FieldInfo(
                name="driver", type="ThreadLocal<WebDriver>",
                modifiers=["private", "static", "final"], annotations=[],
            )],
        )
        conv = detect_conventions({"DriverManager": dm})
        assert conv.driver_access == "ThreadLocal"
        assert conv.parallel_safe is True

    def test_static_field(self) -> None:
        dm = _ci(
            "DriverManager", role=ClassRole.DRIVER_MANAGER,
            fields=[FieldInfo(
                name="driver", type="WebDriver",
                modifiers=["private", "static"], annotations=[],
            )],
        )
        conv = detect_conventions({"DriverManager": dm})
        assert conv.driver_access == "static_field"
        assert conv.parallel_safe is False


class TestImplicitWaits:
    def test_detected(self) -> None:
        c = _ci(
            "BaseTest",
            methods=[_m("setUp",
                        body="{ driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); }")],
        )
        conv = detect_conventions({"BaseTest": c})
        assert conv.implicit_waits_used is True


class TestWaitHelpers:
    def test_listed_in_order(self) -> None:
        utils = _ci(
            "WaitUtils", role=ClassRole.UTILITY,
            methods=[
                _m("waitForVisibility", modifiers=["public", "static"]),
                _m("waitForClickability", modifiers=["public", "static"]),
                _m("foo",               modifiers=["public", "static"]),  # not wait*
            ],
        )
        conv = detect_conventions({"WaitUtils": utils})
        assert conv.explicit_wait_helpers == [
            "WaitUtils.waitForClickability",
            "WaitUtils.waitForVisibility",
        ]


class TestPasswordMasking:
    def test_detected_in_utility(self) -> None:
        utils = _ci(
            "WebActions", role=ClassRole.UTILITY,
            methods=[_m("type",
                        body='{ if (selector.contains("password")) { masked = "*".repeat(text.length()); } }')],
        )
        conv = detect_conventions({"WebActions": utils})
        assert conv.password_masking is True
        assert conv.password_masking_class == "WebActions"


class TestRetryAnalyzer:
    def test_detected_when_class_implements_IRetryAnalyzer(self) -> None:
        c = _ci("RetryAnalyzer", implements=["IRetryAnalyzer"])
        conv = detect_conventions({"R": c})
        assert conv.uses_retry_analyzer is True

    def test_detected_in_test_annotation(self) -> None:
        t = _ci(
            "LoginTests", role=ClassRole.TEST,
            methods=[_m("testValidLogin",
                        annotations=["@Test(retryAnalyzer = RetryAnalyzer.class)"])],
        )
        conv = detect_conventions({"LoginTests": t})
        assert conv.uses_retry_analyzer is True


class TestConfigOverride:
    def test_system_prop_over_properties(self) -> None:
        c = _ci(
            "ConfigurationReader", role=ClassRole.CONFIG,
            methods=[_m("getProperty",
                        body='{ String v = System.getProperty(key); if (v == null) v = props.getProperty(key); return v; }')],
        )
        conv = detect_conventions({"CR": c})
        assert conv.config_override_hierarchy == ["System.getProperty", "properties_file"]
