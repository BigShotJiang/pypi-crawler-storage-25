"""Tests for prompt_context.format_project_context and inherited helpers callout."""

from __future__ import annotations

from qamigrate.intelligence.project_map import (
    ClassInfo,
    ClassRole,
    DependencyEdge,
    DependencyKind,
    MethodInfo,
    ProjectMap,
)
from qamigrate.intelligence.prompt_context import format_project_context


def _method(name: str, return_type: str, modifiers: list[str] | None = None) -> MethodInfo:
    return MethodInfo(
        name=name,
        modifiers=modifiers or ["public"],
        return_type=return_type,
        parameters=[],
        annotations=[],
        body="{ return null; }",
        line=1,
    )


def _make_class(
    *, fqn: str, name: str, package: str, file_path: str,
    role: ClassRole, role_summary: str = "",
    extends: str | None = None,
    public_methods: list[MethodInfo] | None = None,
) -> ClassInfo:
    return ClassInfo(
        name=name,
        fqn=fqn,
        file_path=file_path,
        package=package,
        extends=extends,
        implements=[],
        modifiers=["public"],
        imports=[],
        role=role,
        public_methods=public_methods or [],
        role_summary=role_summary,
    )


def _make_map_with_base_and_child() -> ProjectMap:
    base = _make_class(
        fqn="com.example.base.BaseTest",
        name="BaseTest",
        package="com.example.base",
        file_path="src/BaseTest.java",
        role=ClassRole.BASE,
        role_summary="shared test setup",
        public_methods=[
            _method("getPage", "Page"),
            _method("getDriver", "WebDriver"),
            _method("tearDown", "void"),  # not an infra accessor
        ],
    )
    child = _make_class(
        fqn="com.example.tests.LoginTests",
        name="LoginTests",
        package="com.example.tests",
        file_path="src/LoginTests.java",
        role=ClassRole.TEST,
        role_summary="test",
        extends="com.example.base.BaseTest",
    )
    pm = ProjectMap(
        project_path=".",
        project_name="sample",
        classes={base.fqn: base, child.fqn: child},
        edges=[
            DependencyEdge(
                source=child.fqn,
                target=base.fqn,
                kind=DependencyKind.EXTENDS,
            ),
        ],
    )
    return pm


def test_inherited_helpers_callout_lists_infra_accessors() -> None:
    pm = _make_map_with_base_and_child()
    out = format_project_context(pm, migrating_fqn="com.example.tests.LoginTests")
    assert "Inherited from `BaseTest`" in out
    assert "getPage" in out
    assert "getDriver" in out
    # tearDown returns void -- must not appear in the callout list
    # (it may still appear elsewhere as a signature, so scope the check)
    callout_start = out.find("Inherited from `BaseTest`")
    callout_end = out.find("\n\n", callout_start + 1)
    callout = out[callout_start:callout_end if callout_end != -1 else len(out)]
    assert "tearDown" not in callout


def test_inherited_helpers_callout_mentions_driver_manager_antipattern() -> None:
    pm = _make_map_with_base_and_child()
    out = format_project_context(pm, migrating_fqn="com.example.tests.LoginTests")
    assert "DriverManager" in out
    assert "bypassing it breaks per-test isolation" in out


def test_no_inherited_callout_when_no_parent() -> None:
    # Build a project where LoginTests extends nothing.
    standalone = _make_class(
        fqn="com.example.tests.StandaloneTest",
        name="StandaloneTest",
        package="com.example.tests",
        file_path="src/StandaloneTest.java",
        role=ClassRole.TEST,
        role_summary="standalone",
    )
    pm = ProjectMap(
        project_path=".",
        project_name="sample",
        classes={standalone.fqn: standalone},
        edges=[],
    )
    out = format_project_context(pm, migrating_fqn=standalone.fqn)
    assert "Inherited from" not in out


def test_no_inherited_callout_when_parent_has_no_infra_accessors() -> None:
    base = _make_class(
        fqn="com.example.base.BaseThing",
        name="BaseThing",
        package="com.example.base",
        file_path="src/BaseThing.java",
        role=ClassRole.BASE,
        role_summary="base",
        public_methods=[_method("helperThing", "String")],  # no Page/WebDriver
    )
    child = _make_class(
        fqn="com.example.tests.Child",
        name="Child",
        package="com.example.tests",
        file_path="src/Child.java",
        role=ClassRole.TEST,
        extends="com.example.base.BaseThing",
    )
    pm = ProjectMap(
        project_path=".",
        project_name="sample",
        classes={base.fqn: base, child.fqn: child},
        edges=[
            DependencyEdge(
                source=child.fqn, target=base.fqn, kind=DependencyKind.EXTENDS,
            ),
        ],
    )
    out = format_project_context(pm, migrating_fqn=child.fqn)
    assert "Inherited from" not in out
