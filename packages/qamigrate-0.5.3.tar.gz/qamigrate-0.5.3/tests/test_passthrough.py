"""Tests for the passthrough detector (v0.5.1 Bug #1)."""

from __future__ import annotations

from pathlib import Path

from qamigrate.core.parser import JavaParser
from qamigrate.intelligence.passthrough import (
    build_signatures_from_class_info,
    is_passthrough,
)


def _write(tmp_path: Path, name: str, body: str) -> Path:
    p = tmp_path / name
    p.write_text(body, encoding="utf-8")
    return p


def test_clean_enum_is_passthrough(tmp_path: Path) -> None:
    src = """package com.qastarter.config;

public enum Environment {
    DEV("dev"),
    QA("qa"),
    STG("stg"),
    PROD("prod");

    private final String name;

    Environment(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static Environment fromString(String value) {
        for (Environment e : values()) {
            if (e.name.equalsIgnoreCase(value)) {
                return e;
            }
        }
        throw new IllegalArgumentException("Unknown environment: " + value);
    }
}
"""
    path = _write(tmp_path, "Environment.java", src)
    passthrough, reason = is_passthrough(path)
    assert passthrough is True
    assert reason is not None
    assert "enum" in reason


def test_enum_with_selenium_marker_is_not_passthrough(tmp_path: Path) -> None:
    # An enum that imports Selenium (unlikely but possible) must still be
    # migrated -- don't silently skip it.
    src = """package com.example;

import org.openqa.selenium.By;

public enum Locator {
    USERNAME(By.id("username")),
    PASSWORD(By.id("password"));

    private final By by;

    Locator(By by) {
        this.by = by;
    }
}
"""
    path = _write(tmp_path, "Locator.java", src)
    passthrough, reason = is_passthrough(path)
    assert passthrough is False
    assert reason is None


def test_page_object_is_not_passthrough(tmp_path: Path) -> None:
    src = """package com.example.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
    @FindBy(id = "username")
    private WebElement username;

    public LoginPage(WebDriver driver) {}
}
"""
    path = _write(tmp_path, "LoginPage.java", src)
    passthrough, reason = is_passthrough(path)
    assert passthrough is False
    assert reason is None


def test_testng_test_is_not_passthrough(tmp_path: Path) -> None:
    src = """package com.example.tests;

import org.testng.annotations.Test;

public class SmokeTest {
    @Test
    public void trivial() {}
}
"""
    path = _write(tmp_path, "SmokeTest.java", src)
    passthrough, reason = is_passthrough(path)
    assert passthrough is False


def test_plain_dto_class_is_not_passthrough(tmp_path: Path) -> None:
    # Plain DTOs with no enum keyword and no Selenium markers are ambiguous;
    # we intentionally do NOT passthrough them -- better to let the LLM
    # produce something than to silently skip a file the user expected us
    # to touch. This test pins the conservative behavior.
    src = """package com.example.data;

public class User {
    private String name;
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
"""
    path = _write(tmp_path, "User.java", src)
    passthrough, reason = is_passthrough(path)
    assert passthrough is False


def test_missing_file_returns_false(tmp_path: Path) -> None:
    missing = tmp_path / "does-not-exist.java"
    passthrough, reason = is_passthrough(missing)
    assert passthrough is False
    assert reason is None


def test_package_scoped_enum_is_passthrough(tmp_path: Path) -> None:
    # No modifier in front of `enum`.
    src = """package com.example;

enum Status {
    OPEN, CLOSED;
}
"""
    path = _write(tmp_path, "Status.java", src)
    passthrough, reason = is_passthrough(path)
    assert passthrough is True


# ---- v0.5.2(a): sibling-context signatures for passthrough enums ----


def test_build_signatures_from_enum(tmp_path: Path) -> None:
    """Enum constants and methods surface in sibling signatures so tests
    that import this enum don't hallucinate `Environment.DEVELOPMENT`."""
    src = """package com.example.config;

public enum Environment {
    DEV("dev"),
    QA("qa"),
    STG("stg"),
    PROD("prod");

    private final String name;

    Environment(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static Environment fromString(String value) {
        for (Environment e : values()) {
            if (e.name.equalsIgnoreCase(value)) {
                return e;
            }
        }
        throw new IllegalArgumentException("Unknown: " + value);
    }
}
"""
    path = _write(tmp_path, "Environment.java", src)
    parser = JavaParser()
    info = parser.extract_class_info(path)

    assert info["class_name"] == "Environment"
    assert info["is_enum"] is True
    assert info["enum_constants"] == ["DEV", "QA", "STG", "PROD"]

    sigs = build_signatures_from_class_info(info)

    # All four constants must appear as synthetic public static final fields.
    for const in ("DEV", "QA", "STG", "PROD"):
        assert any(const in s and "Environment" in s for s in sigs), (
            f"missing constant {const} in signatures: {sigs}"
        )

    # Declared methods must appear with parentheses so the hallucination
    # detector's `_extract_method_names` picks them up.
    assert any("getName()" in s for s in sigs)
    assert any("fromString(String value)" in s for s in sigs)


def test_build_signatures_from_empty_class_info() -> None:
    """Degrade gracefully when parser returns nothing."""
    assert build_signatures_from_class_info({}) == []
    assert build_signatures_from_class_info({"fields": [], "methods": []}) == []


def test_build_signatures_skips_fields_without_name() -> None:
    info = {
        "fields": [{"name": None, "type": "String"}, {"name": "FOO", "type": "Env"}],
        "methods": [],
    }
    sigs = build_signatures_from_class_info(info)
    assert len(sigs) == 1
    assert "FOO" in sigs[0]
