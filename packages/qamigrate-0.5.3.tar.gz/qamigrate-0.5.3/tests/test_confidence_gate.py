"""Tests for the v0.5.2(c) confidence gate."""

from __future__ import annotations

from qamigrate.core.confidence_gate import evaluate_confidence_gate
from qamigrate.core.report import Hallucination, MigrationRecord, MigrationReport


def _record(
    source: str,
    *,
    success: bool = True,
    compiled: bool | None = True,
    hallucinations: int = 0,
) -> MigrationRecord:
    """
    Build a record with a controlled confidence value.

    The `confidence` property is computed from (success, compiled,
    hallucinations, compilation_attempts). We set compilation_attempts=0
    to get base=100, then subtract 10 per hallucination.
    """
    return MigrationRecord(
        source_path=source,
        output_path=f"{source}.out" if success else None,
        success=success,
        duration_seconds=1.0,
        compilation_attempts=0,
        compiled=compiled,
        hallucinations=[
            Hallucination(called_method="X.foo()", on_class="X")
            for _ in range(hallucinations)
        ],
    )


def _make_report(records: list[MigrationRecord]) -> MigrationReport:
    r = MigrationReport()
    for rec in records:
        r.add(rec)
    r.finish()
    return r


# ---- Mode 'any' ---------------------------------------------------------


def test_any_mode_passes_when_all_above_threshold() -> None:
    # confidence = 100 across the board.
    report = _make_report([_record("a.java"), _record("b.java")])
    result = evaluate_confidence_gate(report, threshold=80, mode="any")
    assert result.passed is True
    assert result.offending_records == []
    assert result.error is None


def test_any_mode_fails_when_single_file_below_threshold() -> None:
    # One clean file (100), one noisy file (60 = 100 - 40).
    report = _make_report([
        _record("good.java"),
        _record("bad.java", hallucinations=4),
    ])
    result = evaluate_confidence_gate(report, threshold=80, mode="any")
    assert result.passed is False
    assert len(result.offending_records) == 1
    assert result.offending_records[0].source_path == "bad.java"
    assert "1 file(s)" in result.message
    assert "80%" in result.message


def test_any_mode_ignores_failed_records() -> None:
    # Failed records have no output and shouldn't count toward the gate
    # -- they already triggered the exit-1 failure path upstream.
    report = _make_report([
        _record("ok.java"),
        _record("broken.java", success=False, compiled=None),
    ])
    result = evaluate_confidence_gate(report, threshold=80, mode="any")
    assert result.passed is True


# ---- Mode 'avg' ---------------------------------------------------------


def test_avg_mode_passes_when_average_clears_threshold() -> None:
    # 100 and 60 average to 80 -- exactly at the threshold passes.
    report = _make_report([
        _record("a.java"),
        _record("b.java", hallucinations=4),
    ])
    result = evaluate_confidence_gate(report, threshold=80, mode="avg")
    assert result.passed is True


def test_avg_mode_fails_when_average_below_threshold() -> None:
    # Three files averaging well below 80.
    report = _make_report([
        _record("a.java", hallucinations=5),  # 50
        _record("b.java", hallucinations=5),  # 50
        _record("c.java", hallucinations=5),  # 50
    ])
    result = evaluate_confidence_gate(report, threshold=80, mode="avg")
    assert result.passed is False
    # avg mode doesn't list individual offenders -- the problem is systemic.
    assert result.offending_records == []
    assert "average" in result.message.lower()


# ---- Validation ---------------------------------------------------------


def test_invalid_mode_returns_error() -> None:
    report = _make_report([_record("a.java")])
    result = evaluate_confidence_gate(report, threshold=80, mode="strict")
    assert result.error is not None
    assert "strict" in result.error
    assert result.passed is False


def test_mode_case_insensitive() -> None:
    report = _make_report([_record("a.java")])
    assert evaluate_confidence_gate(report, threshold=80, mode="ANY").passed
    assert evaluate_confidence_gate(report, threshold=80, mode="Avg").passed


def test_empty_report_passes() -> None:
    # No records -> nothing below threshold -> gate passes.
    report = _make_report([])
    result = evaluate_confidence_gate(report, threshold=80, mode="any")
    assert result.passed is True
