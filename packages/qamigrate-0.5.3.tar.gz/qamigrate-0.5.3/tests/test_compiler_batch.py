"""Tests for compiler batch mode and the group_errors_by_file helper."""

from qamigrate.agents.compiler import (
    CompilationResult,
    CompilerAgent,
    CompilerError,
    ErrorType,
)


class TestGroupErrorsByFile:
    def test_empty_result_returns_empty_dict(self) -> None:
        result = CompilationResult(
            success=True, exit_code=0, errors=[], warnings=[],
            build_time_ms=0, stdout="", stderr="",
        )
        assert CompilerAgent.group_errors_by_file(result) == {}

    def test_groups_by_file_path(self) -> None:
        errors = [
            CompilerError(
                file_path="/x/A.java", line_number=1, column=1,
                error_type=ErrorType.SYNTAX, message="oops", code_context="",
            ),
            CompilerError(
                file_path="/x/A.java", line_number=2, column=1,
                error_type=ErrorType.SYNTAX, message="also oops", code_context="",
            ),
            CompilerError(
                file_path="/x/B.java", line_number=1, column=1,
                error_type=ErrorType.MISSING_IMPORT, message="nope", code_context="",
            ),
        ]
        result = CompilationResult(
            success=False, exit_code=1, errors=errors, warnings=[],
            build_time_ms=0, stdout="", stderr="",
        )

        groups = CompilerAgent.group_errors_by_file(result)
        assert set(groups.keys()) == {"/x/A.java", "/x/B.java"}
        assert len(groups["/x/A.java"]) == 2
        assert len(groups["/x/B.java"]) == 1


class TestCompileBatchPlumbing:
    """We don't actually invoke javac; just make sure it doesn't crash
    on the empty case and handles missing javac gracefully."""

    def test_empty_file_list(self) -> None:
        compiler = CompilerAgent()
        result = compiler.compile_batch([])
        assert result.success
        assert result.errors == []
