# LuaSkills Python SDK Examples

English documentation is the default example documentation. For Chinese, see [README_cn.md](README_cn.md).

Main LuaSkills repository: [LuaSkills/luaskills](https://github.com/LuaSkills/luaskills)

These examples use the published SDK package shape and are intended to be copied into host applications.

## Runtime Preparation

Install runtime assets before running examples:

```powershell
luaskills install-runtime --database none --runtime-root .\examples\fixture_runtime
```

If you already manage the native library yourself, set `LUASKILLS_LIB` instead:

```powershell
$env:LUASKILLS_LIB = "D:\runtime\luaskills\libs\luaskills.dll"
```

## Example Index

`basic.py` queries the JSON FFI version through `LuaSkillsClient.version`.

```powershell
python .\examples\basic.py
```

`query.py` loads the bundled USER-layer fixture skill, lists delegated-visible entries, checks `is_skill`, resolves `skill_name_for_tool`, and reads help/completion surfaces.

```powershell
python .\examples\query.py
```

`call.py` demonstrates `call_skill` and `run_lua` with an invocation context.

```powershell
python .\examples\call.py
```

`host_tool_callback.py` registers a mock `model.embed` host-tool callback and exercises `vulcan.host.list`, `vulcan.host.has`, and `vulcan.host.call` from inline Lua.

```powershell
python .\examples\host_tool_callback.py
```

`lifecycle.py` demonstrates `disable` and `enable` through the ordinary Skills plane.

```powershell
python .\examples\lifecycle.py
```

`runtime_session.py` demonstrates one persistent runtime lease, authority-bound system queries, and repeated `eval` calls that reuse one interactive child-process handle.

```powershell
python .\examples\runtime_session.py
```

`provider_callback.py` registers a JSON SQLite provider callback before engine creation.

```powershell
python .\examples\provider_callback.py
```

Model callback integration is documented in the main [SDK README](../README.md#model-callback). The generic examples do not call a real model provider because model credentials, provider choice, budgets, and redaction policy are host-owned.

## Wheel Examples

The wheel also ships module examples for quick smoke tests:

```powershell
python -m luaskills.examples.basic
python -m luaskills.examples.host_tool_callback
python -m luaskills.examples.provider_callback
python -m luaskills.examples.runtime_session
```

## Fixture Skill

The fixture skill is stored at `examples/fixture_runtime/user_skills/demo-standard-ffi-skill`. It intentionally lives in USER so delegated-query examples can see it without System authority.

## Release Package

The repository workflow **Examples Release** creates `luaskills-sdk-python-examples-{VERSION}.zip` after the matching PyPI package is published. The workflow installs `luaskills-sdk=={VERSION}` from PyPI and runs the examples before uploading the asset.

The release tag is `examples-v{VERSION}` so example assets stay separate from SDK package versions.
