from setuptools import find_packages, setup

setup(
    package_dir={"": "src"},
    packages=find_packages(where="src", include=["smx_youtube_app*"]),
    include_package_data=True,
)