"""Tests for the quick tweak feature."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

from researchloop.core.config import (
    ClusterConfig,
    Config,
    StudyConfig,
)
from researchloop.core.models import generate_tweak_id
from researchloop.db import queries
from researchloop.sprints.manager import SprintManager
from researchloop.studies.manager import StudyManager


def _tweak_config(tmp_path: Path) -> Config:
    """Config with slurm scheduler (has a job template)."""
    return Config(
        studies=[
            StudyConfig(
                name="test-study",
                cluster="local",
                sprints_dir=str(tmp_path / "sprints"),
            ),
        ],
        clusters=[
            ClusterConfig(
                name="local",
                host="localhost",
                scheduler_type="slurm",
                working_dir=str(tmp_path / "work"),
            ),
        ],
        db_path=":memory:",
        artifact_dir=str(tmp_path / "artifacts"),
        shared_secret="test",
        orchestrator_url="http://localhost:8080",
    )


# ---------------------------------------------------------------------------
# Model helpers
# ---------------------------------------------------------------------------


class TestTweakId:
    def test_generate_tweak_id_format(self):
        tid = generate_tweak_id()
        assert tid.startswith("tw-")
        assert len(tid) == 9  # tw- + 6 hex chars

    def test_generate_tweak_id_unique(self):
        ids = {generate_tweak_id() for _ in range(100)}
        assert len(ids) == 100


# ---------------------------------------------------------------------------
# Database queries
# ---------------------------------------------------------------------------


class TestTweakQueries:
    async def test_create_tweak(self, db_with_study, sample_config):
        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.update_sprint(db_with_study, sprint.id, status="completed")

        row = await queries.create_tweak(
            db_with_study, "tw-abc123", sprint.id, "fix the plots"
        )
        assert row["id"] == "tw-abc123"
        assert row["sprint_id"] == sprint.id
        assert row["instruction"] == "fix the plots"
        assert row["status"] == "pending"

    async def test_get_tweak(self, db_with_study, sample_config):
        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(db_with_study, "tw-get001", sprint.id, "instruction")
        row = await queries.get_tweak(db_with_study, "tw-get001")
        assert row is not None
        assert row["id"] == "tw-get001"

    async def test_get_tweak_nonexistent(self, db_with_study):
        assert await queries.get_tweak(db_with_study, "tw-nope") is None

    async def test_list_tweaks(self, db_with_study, sample_config):
        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(db_with_study, "tw-list01", sprint.id, "first")
        await queries.create_tweak(db_with_study, "tw-list02", sprint.id, "second")
        tweaks = await queries.list_tweaks(db_with_study, sprint.id)
        assert len(tweaks) == 2

    async def test_update_tweak(self, db_with_study, sample_config):
        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(db_with_study, "tw-upd001", sprint.id, "instruction")
        await queries.update_tweak(
            db_with_study, "tw-upd001", status="completed", job_id="12345"
        )
        row = await queries.get_tweak(db_with_study, "tw-upd001")
        assert row is not None
        assert row["status"] == "completed"
        assert row["job_id"] == "12345"


# ---------------------------------------------------------------------------
# SprintManager tweak methods
# ---------------------------------------------------------------------------


class TestSubmitTweak:
    async def test_submit_tweak_on_completed_sprint(self, db_with_study, tmp_path):
        """Happy path: submit a tweak on a completed sprint."""
        config = _tweak_config(tmp_path)
        ssh_mock = AsyncMock()
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock

        scheduler = AsyncMock()
        scheduler.submit.return_value = "999"

        study_mgr = StudyManager(db_with_study, config)

        mgr = SprintManager(
            db=db_with_study,
            config=config,
            ssh_manager=ssh_mgr,
            schedulers={"slurm": scheduler},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "original idea")
        await queries.update_sprint(db_with_study, sprint.id, status="completed")

        tweak_id = await mgr.submit_tweak(sprint.id, "fix the axis labels")

        assert tweak_id.startswith("tw-")
        tweak = await queries.get_tweak(db_with_study, tweak_id)
        assert tweak is not None
        assert tweak["status"] == "submitted"
        assert tweak["job_id"] == "999"
        assert tweak["instruction"] == "fix the axis labels"

        # Verify SSH calls were made.
        assert ssh_mock.run.call_count >= 2  # write script + chmod
        scheduler.submit.assert_called_once()

    async def test_submit_tweak_rejects_non_terminal_sprint(
        self, db_with_study, sample_config
    ):
        """Should raise ValueError when the sprint is still pending/running."""
        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        # Sprint is in "pending" status.
        try:
            await mgr.submit_tweak(sprint.id, "some tweak")
            assert False, "Expected ValueError"
        except ValueError as e:
            assert "terminal" in str(e)

    async def test_submit_tweak_on_failed_sprint(self, db_with_study, tmp_path):
        """Failed sprints accept tweaks too — useful for "retry with X"."""
        config = _tweak_config(tmp_path)
        ssh_mock = AsyncMock()
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock
        scheduler = AsyncMock()
        scheduler.submit.return_value = "888"
        study_mgr = StudyManager(db_with_study, config)

        mgr = SprintManager(
            db=db_with_study,
            config=config,
            ssh_manager=ssh_mgr,
            schedulers={"slurm": scheduler},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "original idea")
        await queries.update_sprint(db_with_study, sprint.id, status="failed")

        tweak_id = await mgr.submit_tweak(sprint.id, "retry with smaller batch size")

        tweak = await queries.get_tweak(db_with_study, tweak_id)
        assert tweak is not None
        assert tweak["status"] == "submitted"

    async def test_submit_tweak_on_cancelled_sprint(self, db_with_study, tmp_path):
        """Cancelled sprints accept tweaks too."""
        config = _tweak_config(tmp_path)
        ssh_mock = AsyncMock()
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock
        scheduler = AsyncMock()
        scheduler.submit.return_value = "777"
        study_mgr = StudyManager(db_with_study, config)

        mgr = SprintManager(
            db=db_with_study,
            config=config,
            ssh_manager=ssh_mgr,
            schedulers={"slurm": scheduler},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "original idea")
        await queries.update_sprint(db_with_study, sprint.id, status="cancelled")

        tweak_id = await mgr.submit_tweak(sprint.id, "pick up where you left off")

        tweak = await queries.get_tweak(db_with_study, tweak_id)
        assert tweak is not None
        assert tweak["status"] == "submitted"

    async def test_submit_tweak_defaults_to_study_time_limit(
        self, db_with_study, tmp_path
    ):
        """Without an explicit time_limit, the study's default is used."""
        import base64

        config = _tweak_config(tmp_path)
        # Set a distinctive max duration to verify propagation.
        config.studies[0].max_sprint_duration_hours = 6

        ssh_mock = AsyncMock()
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock

        scheduler = AsyncMock()
        scheduler.submit.return_value = "777"

        study_mgr = StudyManager(db_with_study, config)

        mgr = SprintManager(
            db=db_with_study,
            config=config,
            ssh_manager=ssh_mgr,
            schedulers={"slurm": scheduler},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.update_sprint(db_with_study, sprint.id, status="completed")

        await mgr.submit_tweak(sprint.id, "fix plots")

        # Find the job script written via base64 and decode it.
        script_content = None
        for call in ssh_mock.run.call_args_list:
            cmd = call.args[0] if call.args else ""
            if "run_tweak_" in cmd and "base64 -d" in cmd:
                start = cmd.index("'") + 1
                end = cmd.index("'", start)
                script_content = base64.b64decode(cmd[start:end]).decode("utf-8")
                break

        assert script_content is not None
        assert "6:00:00" in script_content  # Study's max_sprint_duration_hours
        assert "2:00:00" not in script_content  # NOT the old hardcoded default

    async def test_submit_tweak_rejects_active_tweak(self, db_with_study, tmp_path):
        """Should reject if there's already an active tweak."""
        config = _tweak_config(tmp_path)
        ssh_mock = AsyncMock()
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock

        scheduler = AsyncMock()
        scheduler.submit.return_value = "999"

        study_mgr = StudyManager(db_with_study, config)

        mgr = SprintManager(
            db=db_with_study,
            config=config,
            ssh_manager=ssh_mgr,
            schedulers={"slurm": scheduler},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.update_sprint(db_with_study, sprint.id, status="completed")

        # First tweak succeeds.
        await mgr.submit_tweak(sprint.id, "first tweak")

        # Second tweak should be rejected.
        try:
            await mgr.submit_tweak(sprint.id, "second tweak")
            assert False, "Expected ValueError"
        except ValueError as e:
            assert "active tweak" in str(e)


class TestHandleTweakCompletion:
    async def test_handle_tweak_completion(self, db_with_study, sample_config):
        """Tweak completion updates the tweak record."""
        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(db_with_study, "tw-comp01", sprint.id, "fix plots")

        await mgr.handle_tweak_completion(
            tweak_id="tw-comp01",
            sprint_id=sprint.id,
            status="completed",
        )

        tweak = await queries.get_tweak(db_with_study, "tw-comp01")
        assert tweak is not None
        assert tweak["status"] == "completed"
        assert tweak["completed_at"] is not None

    async def test_handle_tweak_completion_failed(self, db_with_study, sample_config):
        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(db_with_study, "tw-fail01", sprint.id, "bad tweak")

        await mgr.handle_tweak_completion(
            tweak_id="tw-fail01",
            sprint_id=sprint.id,
            status="failed",
            error="Claude crashed",
        )

        tweak = await queries.get_tweak(db_with_study, "tw-fail01")
        assert tweak is not None
        assert tweak["status"] == "failed"
        assert tweak["error"] == "Claude crashed"

    async def test_handle_tweak_completion_notifies_on_success(
        self, db_with_study, sample_config
    ):
        """Completed tweaks fire a sprint-completed notification."""
        from researchloop.comms.router import NotificationRouter

        router = NotificationRouter()
        mock_notifier = AsyncMock()
        router.add_notifier(mock_notifier)

        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
            notification_router=router,
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(
            db_with_study, "tw-ntf01", sprint.id, "add a histogram"
        )

        await mgr.handle_tweak_completion(
            tweak_id="tw-ntf01",
            sprint_id=sprint.id,
            status="completed",
        )

        mock_notifier.notify_sprint_completed.assert_called_once()
        call = mock_notifier.notify_sprint_completed.call_args
        args = call.args
        kwargs = call.kwargs
        sid = args[0] if args else kwargs.get("sprint_id")
        summary = args[2] if len(args) > 2 else kwargs.get("summary", "")
        assert sid == sprint.id
        assert "add a histogram" in summary

    async def test_handle_tweak_completion_notifies_on_failure(
        self, db_with_study, sample_config
    ):
        """Failed tweaks fire a sprint-failed notification."""
        from researchloop.comms.router import NotificationRouter

        router = NotificationRouter()
        mock_notifier = AsyncMock()
        router.add_notifier(mock_notifier)

        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
            notification_router=router,
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(db_with_study, "tw-ntf02", sprint.id, "broken thing")

        await mgr.handle_tweak_completion(
            tweak_id="tw-ntf02",
            sprint_id=sprint.id,
            status="failed",
            error="Claude timed out",
        )

        mock_notifier.notify_sprint_failed.assert_called_once()
        call = mock_notifier.notify_sprint_failed.call_args
        args = call.args
        kwargs = call.kwargs
        sid = args[0] if args else kwargs.get("sprint_id")
        err = args[2] if len(args) > 2 else kwargs.get("error", "")
        assert sid == sprint.id
        assert "Claude timed out" in err
        assert "broken thing" in err

    async def test_handle_tweak_completion_fetches_results(
        self, db_with_study, sample_config
    ):
        """Tweak completion should re-fetch sprint results from cluster."""
        ssh_mock = AsyncMock()

        async def fake_run(cmd: str) -> tuple[str, str, int]:
            if "report.md" in cmd:
                return ("# Updated Report", "", 0)
            if "findings.md" in cmd:
                return ("Updated findings", "", 0)
            if "test -f" in cmd and "report.pdf" in cmd:
                return ("", "", 1)
            return ("", "", 0)

        ssh_mock.run = AsyncMock(side_effect=fake_run)
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock

        study_mgr = StudyManager(db_with_study, sample_config)

        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=ssh_mgr,
            schedulers={},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(
            db_with_study, "tw-fetch1", sprint.id, "fix something"
        )

        await mgr.handle_tweak_completion(
            tweak_id="tw-fetch1",
            sprint_id=sprint.id,
            status="completed",
        )

        row = await queries.get_sprint(db_with_study, sprint.id)
        assert row is not None
        assert row["metadata_json"] is not None
        meta = json.loads(row["metadata_json"])
        assert "Updated Report" in meta.get("report", "")


class TestRefreshTweakStatus:
    async def test_refresh_marks_completed_when_job_done(self, db_with_study, tmp_path):
        """Polling a finished cluster job marks tweak as completed."""
        config = _tweak_config(tmp_path)
        ssh_mock = AsyncMock()

        async def fake_run(cmd: str) -> tuple[str, str, int]:
            return ("", "", 0)

        ssh_mock.run = AsyncMock(side_effect=fake_run)
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock

        scheduler = AsyncMock()
        scheduler.status = AsyncMock(return_value="completed")

        study_mgr = StudyManager(db_with_study, config)

        mgr = SprintManager(
            db=db_with_study,
            config=config,
            ssh_manager=ssh_mgr,
            schedulers={"slurm": scheduler},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.update_sprint(db_with_study, sprint.id, status="completed")
        await queries.create_tweak(db_with_study, "tw-rfsh1", sprint.id, "fix")
        await queries.update_tweak(
            db_with_study, "tw-rfsh1", status="submitted", job_id="555"
        )

        result = await mgr.refresh_tweak_status("tw-rfsh1")

        assert result == "completed"
        tweak = await queries.get_tweak(db_with_study, "tw-rfsh1")
        assert tweak is not None
        assert tweak["status"] == "completed"
        assert tweak["completed_at"] is not None

    async def test_refresh_keeps_running_status(self, db_with_study, tmp_path):
        """Polling an in-progress job leaves tweak in running state."""
        config = _tweak_config(tmp_path)
        ssh_mock = AsyncMock()
        ssh_mock.run = AsyncMock(return_value=("", "", 0))
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock

        scheduler = AsyncMock()
        scheduler.status = AsyncMock(return_value="running")

        study_mgr = StudyManager(db_with_study, config)

        mgr = SprintManager(
            db=db_with_study,
            config=config,
            ssh_manager=ssh_mgr,
            schedulers={"slurm": scheduler},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.update_sprint(db_with_study, sprint.id, status="completed")
        await queries.create_tweak(db_with_study, "tw-rfsh2", sprint.id, "fix")
        await queries.update_tweak(
            db_with_study, "tw-rfsh2", status="submitted", job_id="666"
        )

        result = await mgr.refresh_tweak_status("tw-rfsh2")

        assert result == "running"
        tweak = await queries.get_tweak(db_with_study, "tw-rfsh2")
        assert tweak is not None
        assert tweak["status"] == "running"
        assert tweak["completed_at"] is None

    async def test_refresh_skips_terminal_tweak(self, db_with_study, sample_config):
        """A tweak that's already completed shouldn't be re-polled."""
        mgr = SprintManager(
            db=db_with_study,
            config=sample_config,
            ssh_manager=AsyncMock(),
            schedulers={},
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.create_tweak(db_with_study, "tw-rfsh3", sprint.id, "done")
        await queries.update_tweak(db_with_study, "tw-rfsh3", status="completed")

        result = await mgr.refresh_tweak_status("tw-rfsh3")
        assert result == "completed"


class TestCancelTweak:
    async def test_cancel_tweak(self, db_with_study, tmp_path):
        """Cancelling a running tweak marks it as cancelled."""
        config = _tweak_config(tmp_path)
        ssh_mock = AsyncMock()
        ssh_mock.run = AsyncMock(return_value=("", "", 0))
        ssh_mgr = AsyncMock()
        ssh_mgr.get_connection.return_value = ssh_mock

        scheduler = AsyncMock()
        scheduler.cancel = AsyncMock(return_value=True)

        study_mgr = StudyManager(db_with_study, config)

        mgr = SprintManager(
            db=db_with_study,
            config=config,
            ssh_manager=ssh_mgr,
            schedulers={"slurm": scheduler},
            study_manager=study_mgr,
        )
        sprint = await mgr.create_sprint("test-study", "idea")
        await queries.update_sprint(db_with_study, sprint.id, status="completed")
        await queries.create_tweak(db_with_study, "tw-cnl01", sprint.id, "fix")
        await queries.update_tweak(
            db_with_study, "tw-cnl01", status="running", job_id="777"
        )

        result = await mgr.cancel_tweak("tw-cnl01")
        assert result is True

        tweak = await queries.get_tweak(db_with_study, "tw-cnl01")
        assert tweak is not None
        assert tweak["status"] == "cancelled"
        assert tweak["completed_at"] is not None
        scheduler.cancel.assert_called_once()


# ---------------------------------------------------------------------------
# Dashboard routes
# ---------------------------------------------------------------------------


class TestTweakDashboard:
    """Test tweak-related dashboard routes."""

    async def test_tweak_form_visible_on_completed_sprint(
        self, db_with_study, sample_config
    ):
        """The tweak form should appear on completed sprint detail pages."""
        import tempfile

        from fastapi.testclient import TestClient

        from researchloop.core.config import DashboardConfig
        from researchloop.core.orchestrator import Orchestrator, create_app

        config = Config(
            studies=sample_config.studies,
            clusters=sample_config.clusters,
            db_path=":memory:",
            artifact_dir=tempfile.mkdtemp(),
            dashboard=DashboardConfig(password_hash=None),
        )
        orch = Orchestrator(config)
        app = create_app(orch)
        client = TestClient(app)

        with client:
            assert orch.db is not None
            # Set up dashboard password and login.
            from researchloop.dashboard.auth import hash_password

            pw_hash = hash_password("testpass123")
            await orch.db.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                ("dashboard_password_hash", pw_hash),
            )
            resp = client.post(
                "/dashboard/login",
                data={"password": "testpass123"},
                follow_redirects=False,
            )
            cookies = dict(resp.cookies)

            # Create a completed sprint.
            await queries.create_sprint(
                orch.db, "sp-twk-vis", "test-study", "some idea"
            )
            await queries.update_sprint(orch.db, "sp-twk-vis", status="completed")

            resp = client.get(
                "/dashboard/sprints/sp-twk-vis",
                cookies=cookies,
            )
            assert resp.status_code == 200
            assert "Quick Tweak" in resp.text
            assert 'name="instruction"' in resp.text

    async def test_tweak_form_visible_on_failed_sprint(
        self, db_with_study, sample_config
    ):
        """The tweak form must appear on failed/cancelled sprints too —
        users iterate on partial state with instructions like "retry with
        smaller batch size".
        """
        import tempfile

        from fastapi.testclient import TestClient

        from researchloop.core.config import DashboardConfig
        from researchloop.core.orchestrator import Orchestrator, create_app

        config = Config(
            studies=sample_config.studies,
            clusters=sample_config.clusters,
            db_path=":memory:",
            artifact_dir=tempfile.mkdtemp(),
            dashboard=DashboardConfig(password_hash=None),
        )
        orch = Orchestrator(config)
        app = create_app(orch)
        client = TestClient(app)

        with client:
            assert orch.db is not None
            from researchloop.dashboard.auth import hash_password

            pw_hash = hash_password("testpass123")
            await orch.db.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                ("dashboard_password_hash", pw_hash),
            )
            resp = client.post(
                "/dashboard/login",
                data={"password": "testpass123"},
                follow_redirects=False,
            )
            cookies = dict(resp.cookies)

            for sid, status in [
                ("sp-twk-fail", "failed"),
                ("sp-twk-canc", "cancelled"),
            ]:
                await queries.create_sprint(orch.db, sid, "test-study", "idea")
                await queries.update_sprint(orch.db, sid, status=status)
                resp = client.get(
                    f"/dashboard/sprints/{sid}",
                    cookies=cookies,
                )
                assert resp.status_code == 200, status
                assert "Quick Tweak" in resp.text, (
                    f"Tweak form missing for {status} sprint"
                )
                assert 'name="instruction"' in resp.text

    async def test_tweak_form_hidden_on_running_sprint(
        self, db_with_study, sample_config
    ):
        """The tweak form should NOT appear on non-completed sprints."""
        import tempfile

        from fastapi.testclient import TestClient

        from researchloop.core.config import DashboardConfig
        from researchloop.core.orchestrator import Orchestrator, create_app

        config = Config(
            studies=sample_config.studies,
            clusters=sample_config.clusters,
            db_path=":memory:",
            artifact_dir=tempfile.mkdtemp(),
            dashboard=DashboardConfig(password_hash=None),
        )
        orch = Orchestrator(config)
        app = create_app(orch)
        client = TestClient(app)

        with client:
            assert orch.db is not None
            from researchloop.dashboard.auth import hash_password

            pw_hash = hash_password("testpass123")
            await orch.db.execute(
                "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
                ("dashboard_password_hash", pw_hash),
            )
            resp = client.post(
                "/dashboard/login",
                data={"password": "testpass123"},
                follow_redirects=False,
            )
            cookies = dict(resp.cookies)

            # Create a running sprint.
            await queries.create_sprint(
                orch.db, "sp-twk-run", "test-study", "running idea"
            )
            await queries.update_sprint(orch.db, "sp-twk-run", status="running")

            resp = client.get(
                "/dashboard/sprints/sp-twk-run",
                cookies=cookies,
            )
            assert resp.status_code == 200
            assert "Quick Tweak" not in resp.text


# ---------------------------------------------------------------------------
# Webhook routing
# ---------------------------------------------------------------------------


class TestTweakWebhook:
    async def test_tweak_completion_webhook(self, db_with_study, sample_config):
        """Webhook with tweak_id should route to tweak completion."""
        import tempfile

        from fastapi.testclient import TestClient

        from researchloop.core.config import DashboardConfig
        from researchloop.core.orchestrator import Orchestrator, create_app

        config = Config(
            studies=sample_config.studies,
            clusters=sample_config.clusters,
            db_path=":memory:",
            artifact_dir=tempfile.mkdtemp(),
            dashboard=DashboardConfig(password_hash=None),
        )
        orch = Orchestrator(config)
        app = create_app(orch)
        client = TestClient(app)

        with client:
            assert orch.db is not None
            row = await queries.create_sprint(
                orch.db, "sp-twk-wh", "test-study", "idea"
            )
            token = row["webhook_token"]

            await queries.create_tweak(orch.db, "tw-wh-001", "sp-twk-wh", "fix labels")

            resp = client.post(
                "/api/webhook/sprint-complete",
                json={
                    "sprint_id": "sp-twk-wh",
                    "tweak_id": "tw-wh-001",
                    "status": "completed",
                },
                headers={"x-webhook-token": token},
            )
            assert resp.status_code == 200
            data = resp.json()
            assert data["ok"] is True
            assert data["tweak_id"] == "tw-wh-001"

            tweak = await queries.get_tweak(orch.db, "tw-wh-001")
            assert tweak is not None
            assert tweak["status"] == "completed"
            assert tweak["completed_at"] is not None
