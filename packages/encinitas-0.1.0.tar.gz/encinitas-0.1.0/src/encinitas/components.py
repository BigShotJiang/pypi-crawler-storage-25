"""Reusable Dash dashboard components.

This module exposes small, CSS-backed component factory functions for KPI
cards, bullet charts, and sparklines. Each public function returns a Dash
``html.Div`` that can be used directly in a Dash layout.

Load the packaged stylesheet with ``Dash(..., assets_folder=assets_path())``.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from importlib.resources import files
from typing import Any, Literal
from urllib.parse import quote

from dash import html

DeltaDirection = Literal["up", "down", "flat"]
FavorableDirection = Literal["higher", "lower"]
ValueTone = Literal["positive", "negative", "neutral", "warning"]
TooltipPlacement = Literal["top", "right", "bottom", "left"]

Style = dict[str, Any]
StyleMapping = Mapping[str, Any] | None
ValueFormatter = Callable[[float | int], str]
PercentFormatter = Callable[[float], str]
DEFAULT_ASSET_FOLDER = "assets"


DEFAULT_TONE_COLORS: dict[ValueTone, str] = {
    "positive": "#16a34a",
    "negative": "#dc2626",
    "neutral": "#64748b",
    "warning": "#d97706",
}


def kpi_card(
    title: Any,
    value: Any,
    *,
    delta: float | int | None = None,
    delta_text: Any | None = None,
    delta_tone: ValueTone | None = None,
    delta_direction: DeltaDirection | None = None,
    delta_tooltip: Any | None = None,
    subtitle: Any | None = None,
    tone: ValueTone | None = None,
    tone_thresholds: tuple[float, float] = (0, 0),
    show_border_tone: bool = False,
    tooltip: Any | None = None,
    tooltip_id: str | None = None,
    tooltip_max_width: str | int | None = None,
    tooltip_placement: TooltipPlacement = "top",
    tooltip_style: StyleMapping = None,
    colors: Mapping[ValueTone, str] | None = None,
    id: str | dict[str, Any] | None = None,
    class_name: str | None = None,
    style: StyleMapping = None,
    title_style: StyleMapping = None,
    value_style: StyleMapping = None,
    subtitle_style: StyleMapping = None,
    delta_style: StyleMapping = None,
    children: Sequence[Any] | None = None,
    **props: Any,
) -> html.Div:
    """Create a reusable KPI card.

    Args:
        title: Label displayed in the card header.
        value: Primary KPI value. Can be text or any Dash-renderable content.
        delta: Numeric change used to derive card tone and delta direction.
        delta_text: Text displayed beside the delta icon.
        delta_tone: Optional color tone for the delta row, independent from
            arrow direction.
        delta_direction: Force the delta icon direction: ``"up"``, ``"down"``,
            or ``"flat"``.
        delta_tooltip: Backwards-compatible alias for card-level tooltip
            content.
        subtitle: Optional secondary text below the KPI.
        tone: Optional card tone override: ``"positive"``, ``"negative"``,
            ``"neutral"``, or ``"warning"``.
        tone_thresholds: ``(negative, positive)`` cutoffs used when deriving
            tone from ``delta``.
        show_border_tone: Show a tone-colored left border. Defaults to
            ``False``.
        tooltip: Card-level hover/focus content. Accepts strings or Dash
            components.
        tooltip_id: Optional DOM id for the tooltip element.
        tooltip_max_width: Tooltip max width as pixels or a CSS size string.
        tooltip_placement: Tooltip placement: ``"top"``, ``"right"``,
            ``"bottom"``, or ``"left"``.
        tooltip_style: Inline style overrides for the tooltip.
        colors: Optional tone color overrides.
        id: Optional Dash component id.
        class_name: Extra CSS class names for the card.
        style: Inline style overrides for the card root.
        title_style: Inline style overrides for the title.
        value_style: Inline style overrides for the value.
        subtitle_style: Inline style overrides for the subtitle.
        delta_style: Inline style overrides for the delta row.
        children: Extra Dash components appended inside the card.
        **props: Additional Dash props passed to the root ``html.Div``.

    Returns:
        A Dash ``html.Div`` KPI card.
    """

    palette = {**DEFAULT_TONE_COLORS, **(colors or {})}
    resolved_tone = tone or tone_from_value(delta, thresholds=tone_thresholds)
    border_color = palette[resolved_tone]

    card_style = _merge_style({"--encinitas-tone-color": border_color}, style)
    card_class_name = _join_class_names(
        "encinitas-kpi-card",
        f"encinitas-kpi-card--{resolved_tone}",
        "encinitas-kpi-card--border-tone" if show_border_tone else None,
        class_name,
    )
    tooltip_content = tooltip if tooltip is not None else delta_tooltip
    header_content = [
        html.P(
            title,
            className="encinitas-kpi-card__title",
            style=_merge_style(title_style),
        )
    ]
    if tooltip_content is not None:
        header_content.append(_info_icon())

    content: list[Any] = [
        html.Div(
            header_content,
            className="encinitas-kpi-card__header",
        ),
        html.Div(value, className="encinitas-kpi-card__value", style=_merge_style(value_style)),
    ]

    if delta is not None or delta_text is not None:
        content.append(
            delta_indicator(
                delta,
                text=delta_text,
                direction=delta_direction,
                tone=delta_tone or tone or resolved_tone,
                colors=palette,
                style=delta_style,
            )
        )

    if subtitle is not None:
        content.append(
            html.P(
                subtitle,
                className="encinitas-kpi-card__subtitle",
                style=_merge_style(subtitle_style),
            )
        )

    if children:
        content.extend(children)

    tooltip_dom_id = tooltip_id or _tooltip_id_from_card_id(id)

    if tooltip_content is not None:
        tooltip_css_vars = {}
        if tooltip_max_width is not None:
            tooltip_css_vars["--encinitas-tooltip-max-width"] = _css_size(
                tooltip_max_width
            )
        tooltip_props: dict[str, Any] = {
            "className": _join_class_names(
                "encinitas-kpi-card__tooltip",
                f"encinitas-kpi-card__tooltip--{tooltip_placement}",
            ),
            "role": "tooltip",
            "style": _merge_style(tooltip_css_vars, tooltip_style),
        }
        if tooltip_dom_id is not None:
            tooltip_props["id"] = tooltip_dom_id
        content.append(html.Div(tooltip_content, **tooltip_props))

    component_props = {**props, "style": card_style}
    if id is not None:
        component_props["id"] = id
    if tooltip_content is not None:
        component_props.setdefault("tabIndex", 0)
    if tooltip_content is not None and tooltip_dom_id is not None:
        component_props["aria-describedby"] = tooltip_dom_id
    component_props["className"] = card_class_name

    return html.Div(content, **component_props)


def assets_path() -> str:
    """Return the packaged assets directory for Dash.

    Pass this value to ``Dash(..., assets_folder=assets_path())`` so Dash loads
    the bundled ``encinitas.css`` stylesheet.

    Returns:
        Absolute path to the package ``assets`` directory.
    """

    return str(files("encinitas").joinpath(DEFAULT_ASSET_FOLDER))


def bullet_chart(
    actual: float | int,
    target: float | int,
    *,
    prior_year: float | int | None = None,
    maximum: float | int | None = None,
    background: float | int | None = None,
    favorable_direction: FavorableDirection = "higher",
    tolerance: float | int = 0,
    actual_tone: ValueTone | None = None,
    tooltip: Any | None = None,
    tooltip_id: str | None = None,
    tooltip_max_width: str | int | None = None,
    tooltip_placement: TooltipPlacement = "top",
    tooltip_style: StyleMapping = None,
    value_formatter: ValueFormatter | None = None,
    percent_formatter: PercentFormatter | None = None,
    colors: Mapping[ValueTone, str] | None = None,
    id: str | dict[str, Any] | None = None,
    class_name: str | None = None,
    style: StyleMapping = None,
    background_style: StyleMapping = None,
    actual_style: StyleMapping = None,
    target_style: StyleMapping = None,
    aria_label: str | None = None,
    **props: Any,
) -> html.Div:
    """Create a horizontal bullet chart with no axes or tick marks.

    Args:
        actual: Actual value represented by the foreground bar.
        target: Target value represented by the vertical marker.
        prior_year: Optional comparison value. When provided, a generated
            tooltip shows actual, prior year, target, and percent deltas.
        maximum: Scale maximum. If omitted, the scale is derived from data.
        background: Wider grey comparison bar. If omitted, it fills the scale.
        favorable_direction: Whether higher or lower actuals are favorable.
        tolerance: Neutral band around target before positive/negative tone is
            applied.
        actual_tone: Optional foreground bar tone override.
        tooltip: Custom tooltip content, or ``False`` to disable generated
            tooltip content.
        tooltip_id: Optional DOM id for the tooltip element.
        tooltip_max_width: Tooltip max width as pixels or a CSS size string.
        tooltip_placement: Tooltip placement.
        tooltip_style: Inline style overrides for the tooltip.
        value_formatter: Formatter for generated tooltip values.
        percent_formatter: Formatter for generated tooltip percent deltas.
        colors: Optional tone color overrides.
        id: Optional Dash component id.
        class_name: Extra CSS class names for the chart.
        style: Inline style overrides for the chart root.
        background_style: Inline style overrides for the background bar.
        actual_style: Inline style overrides for the actual bar.
        target_style: Inline style overrides for the target marker.
        aria_label: Accessible label override.
        **props: Additional Dash props passed to the root ``html.Div``.

    Returns:
        A Dash ``html.Div`` containing the bullet chart.
    """

    palette = {**DEFAULT_TONE_COLORS, **(colors or {})}
    resolved_tone = actual_tone or tone_from_actual_target(
        actual,
        target,
        favorable_direction=favorable_direction,
        tolerance=tolerance,
    )
    scale_max = _resolve_bullet_maximum(actual, target, maximum, background)
    background_value = scale_max if background is None else background

    chart_style = _merge_style(
        {
            "--encinitas-bullet-actual-color": palette[resolved_tone],
            "--encinitas-bullet-actual-width": _percentage(actual, scale_max),
            "--encinitas-bullet-background-width": _percentage(
                background_value, scale_max
            ),
            "--encinitas-bullet-target-left": _percentage(target, scale_max),
        },
        style,
    )
    tooltip_content = tooltip
    if tooltip_content is None and prior_year is not None:
        tooltip_content = _default_bullet_tooltip(
            actual=actual,
            prior_year=prior_year,
            target=target,
            value_formatter=value_formatter,
            percent_formatter=percent_formatter,
        )
    if tooltip_content is False:
        tooltip_content = None
    tooltip_dom_id = tooltip_id or _tooltip_id_from_card_id(id)

    component_props = {
        **props,
        "className": _join_class_names(
            "encinitas-bullet-chart",
            f"encinitas-bullet-chart--{resolved_tone}",
            class_name,
        ),
        "role": "img",
        "style": chart_style,
        **{"aria-label": aria_label or _bullet_aria_label(actual, target)},
    }
    if id is not None:
        component_props["id"] = id
    if tooltip_content is not None:
        component_props.setdefault("tabIndex", 0)
    if tooltip_content is not None and tooltip_dom_id is not None:
        component_props["aria-describedby"] = tooltip_dom_id

    children = [
        html.Div(
            [
                html.Div(
                    className="encinitas-bullet-chart__background",
                    style=_merge_style(background_style),
                ),
                html.Div(
                    className="encinitas-bullet-chart__actual",
                    style=_merge_style(actual_style),
                ),
                html.Div(
                    className="encinitas-bullet-chart__target",
                    style=_merge_style(target_style),
                ),
            ],
            className="encinitas-bullet-chart__track",
        )
    ]

    if tooltip_content is not None:
        tooltip_css_vars = {}
        if tooltip_max_width is not None:
            tooltip_css_vars["--encinitas-tooltip-max-width"] = _css_size(
                tooltip_max_width
            )
        tooltip_props: dict[str, Any] = {
            "className": _join_class_names(
                "encinitas-bullet-chart__tooltip",
                f"encinitas-bullet-chart__tooltip--{tooltip_placement}",
            ),
            "role": "tooltip",
            "style": _merge_style(tooltip_css_vars, tooltip_style),
        }
        if tooltip_dom_id is not None:
            tooltip_props["id"] = tooltip_dom_id
        children.append(html.Div(tooltip_content, **tooltip_props))

    return html.Div(children, **component_props)


def bullet_chart_stack(
    rows: Sequence[Mapping[str, Any]],
    *,
    maximum: float | int | None = None,
    background: float | int | None = None,
    favorable_direction: FavorableDirection = "higher",
    tolerance: float | int = 0,
    colors: Mapping[ValueTone, str] | None = None,
    headers: Sequence[Any] | None = None,
    show_values: bool = False,
    tooltip_placement: TooltipPlacement = "top",
    tooltip_max_width: str | int | None = None,
    tooltip_style: StyleMapping = None,
    value_formatter: ValueFormatter | None = None,
    percent_formatter: PercentFormatter | None = None,
    id: str | dict[str, Any] | None = None,
    class_name: str | None = None,
    style: StyleMapping = None,
    header_style: StyleMapping = None,
    row_style: StyleMapping = None,
    label_style: StyleMapping = None,
    value_style: StyleMapping = None,
    chart_style: StyleMapping = None,
    aria_label: str | None = None,
    **props: Any,
) -> html.Div:
    """Create labeled bullet chart rows on a shared horizontal scale.

    Args:
        rows: Row mappings. Each row requires ``label``, ``actual``, and
            ``target``. Optional row keys include ``prior_year``, ``background``,
            ``tooltip``, ``value``, ``favorable_direction``, ``actual_tone``,
            ``tooltip_placement``, ``tooltip_max_width``, ``class_name``, and
            ``style``.
        maximum: Shared scale maximum. If omitted, derived from all rows.
        background: Default background value for rows.
        favorable_direction: Default row target direction.
        tolerance: Default neutral band around target.
        colors: Optional tone color overrides.
        headers: Optional column headers.
        show_values: Show a trailing value column. Defaults to ``False``.
        tooltip_placement: Default row tooltip placement.
        tooltip_max_width: Default row tooltip max width.
        tooltip_style: Default row tooltip style overrides.
        value_formatter: Default formatter for generated tooltip values.
        percent_formatter: Default formatter for generated tooltip percents.
        id: Optional Dash component id.
        class_name: Extra CSS class names for the stack.
        style: Inline style overrides for the stack root.
        header_style: Inline style overrides for the header row.
        row_style: Inline style overrides for each row.
        label_style: Inline style overrides for row labels.
        value_style: Inline style overrides for visible row values.
        chart_style: Inline style overrides for row charts.
        aria_label: Accessible label override.
        **props: Additional Dash props passed to the root ``html.Div``.

    Returns:
        A Dash ``html.Div`` containing labeled bullet chart rows.
    """

    shared_maximum = maximum or _resolve_bullet_stack_maximum(rows, background)
    stack_children = []
    if headers is not None:
        stack_children.append(
            _bullet_stack_header(
                headers,
                show_values=show_values,
                header_style=header_style,
            )
        )

    row_components = [
        _bullet_chart_row(
            row,
            shared_maximum=shared_maximum,
            default_background=background,
            default_favorable_direction=favorable_direction,
            default_tolerance=tolerance,
            colors=colors,
            show_values=show_values,
            default_tooltip_placement=tooltip_placement,
            default_tooltip_max_width=tooltip_max_width,
            default_tooltip_style=tooltip_style,
            default_value_formatter=value_formatter,
            default_percent_formatter=percent_formatter,
            row_style=row_style,
            label_style=label_style,
            value_style=value_style,
            chart_style=chart_style,
        )
        for row in rows
    ]
    stack_children.extend(row_components)

    component_props = {
        **props,
        "className": _join_class_names("encinitas-bullet-stack", class_name),
        "role": "group",
        "style": _merge_style(style),
        **{"aria-label": aria_label or "Bullet chart"},
    }
    if id is not None:
        component_props["id"] = id

    return html.Div(stack_children, **component_props)


def sparkline(
    values: Sequence[float | int],
    *,
    width: int = 96,
    height: int = 24,
    display_width: str | int | None = None,
    padding: float | int = 3,
    y_min: float | int | None = None,
    y_max: float | int | None = None,
    tone: ValueTone | None = None,
    line_color: str | None = None,
    colors: Mapping[ValueTone, str] | None = None,
    stroke_width: float | int = 2,
    show_endpoint: bool = False,
    tooltip: Any | None = None,
    tooltip_id: str | None = None,
    tooltip_max_width: str | int | None = None,
    tooltip_placement: TooltipPlacement = "top",
    tooltip_style: StyleMapping = None,
    value_formatter: ValueFormatter | None = None,
    percent_formatter: PercentFormatter | None = None,
    id: str | dict[str, Any] | None = None,
    class_name: str | None = None,
    style: StyleMapping = None,
    svg_style: StyleMapping = None,
    line_style: StyleMapping = None,
    endpoint_style: StyleMapping = None,
    aria_label: str | None = None,
    **props: Any,
) -> html.Div:
    """Create a compact time-series sparkline with no axes or tick marks.

    Args:
        values: Numeric time-series values.
        width: SVG coordinate width.
        height: SVG coordinate height.
        display_width: Rendered CSS width. Numbers become pixels; strings pass
            through unchanged.
        padding: Internal SVG padding to avoid clipped strokes.
        y_min: Optional explicit vertical scale minimum.
        y_max: Optional explicit vertical scale maximum.
        tone: Optional tone override for default line color.
        line_color: Direct stroke color override.
        colors: Optional tone color overrides.
        stroke_width: SVG line stroke width.
        show_endpoint: Whether to draw an endpoint marker. Defaults to
            ``False``.
        tooltip: Custom tooltip content, or ``False`` to disable generated
            tooltip content.
        tooltip_id: Optional DOM id for the tooltip element.
        tooltip_max_width: Tooltip max width as pixels or a CSS size string.
        tooltip_placement: Tooltip placement.
        tooltip_style: Inline style overrides for the tooltip.
        value_formatter: Formatter for generated tooltip values.
        percent_formatter: Formatter for generated tooltip percent change.
        id: Optional Dash component id.
        class_name: Extra CSS class names for the sparkline.
        style: Inline style overrides for the root.
        svg_style: Inline style overrides for the rendered image.
        line_style: Backwards-compatible style hook applied to the rendered
            image element.
        endpoint_style: Backwards-compatible style hook applied to the rendered
            image element.
        aria_label: Accessible label override.
        **props: Additional Dash props passed to the root ``html.Div``.

    Returns:
        A Dash ``html.Div`` containing a compact sparkline.
    """

    if not values:
        raise ValueError("sparkline requires at least one value")

    palette = {**DEFAULT_TONE_COLORS, **(colors or {})}
    resolved_tone = tone or tone_from_value(values[-1] - values[0])
    resolved_line_color = line_color or palette[resolved_tone]
    points = _sparkline_points(
        values,
        width=width,
        height=height,
        padding=padding,
        y_min=y_min,
        y_max=y_max,
    )
    tooltip_content = tooltip
    if tooltip_content is None:
        tooltip_content = _default_sparkline_tooltip(
            values,
            value_formatter=value_formatter,
            percent_formatter=percent_formatter,
        )
    if tooltip_content is False:
        tooltip_content = None
    tooltip_dom_id = tooltip_id or _tooltip_id_from_card_id(id)

    component_props = {
        **props,
        "className": _join_class_names(
            "encinitas-sparkline",
            f"encinitas-sparkline--{resolved_tone}",
            class_name,
        ),
        "role": "img",
        "style": _merge_style(
            {
                "--encinitas-sparkline-color": resolved_line_color,
                "--encinitas-sparkline-display-width": _css_size(
                    display_width if display_width is not None else width
                ),
                "--encinitas-sparkline-stroke-width": stroke_width,
            },
            style,
        ),
        **{"aria-label": aria_label or _sparkline_aria_label(values)},
    }
    if id is not None:
        component_props["id"] = id
    if tooltip_content is not None:
        component_props.setdefault("tabIndex", 0)
    if tooltip_content is not None and tooltip_dom_id is not None:
        component_props["aria-describedby"] = tooltip_dom_id

    sparkline_svg = _sparkline_svg(
        points,
        width=width,
        height=height,
        color=resolved_line_color,
        stroke_width=stroke_width,
        show_endpoint=show_endpoint,
    )

    children: list[Any] = [
        html.Img(
            alt="",
            className="encinitas-sparkline__img",
            src=f"data:image/svg+xml,{quote(sparkline_svg)}",
            style=_merge_style(svg_style, line_style, endpoint_style),
        )
    ]
    if tooltip_content is not None:
        tooltip_css_vars = {}
        if tooltip_max_width is not None:
            tooltip_css_vars["--encinitas-tooltip-max-width"] = _css_size(
                tooltip_max_width
            )
        tooltip_props: dict[str, Any] = {
            "className": _join_class_names(
                "encinitas-sparkline__tooltip",
                f"encinitas-sparkline__tooltip--{tooltip_placement}",
            ),
            "role": "tooltip",
            "style": _merge_style(tooltip_css_vars, tooltip_style),
        }
        if tooltip_dom_id is not None:
            tooltip_props["id"] = tooltip_dom_id
        children.append(html.Div(tooltip_content, **tooltip_props))

    return html.Div(
        children,
        **component_props,
    )


def sparkline_stack(
    rows: Sequence[Mapping[str, Any]],
    *,
    width: int = 96,
    height: int = 24,
    display_width: str | int | None = None,
    padding: float | int = 3,
    shared_scale: bool = True,
    show_delta: bool = False,
    colors: Mapping[ValueTone, str] | None = None,
    headers: Sequence[Any] | None = None,
    tooltip_placement: TooltipPlacement = "top",
    tooltip_max_width: str | int | None = None,
    tooltip_style: StyleMapping = None,
    value_formatter: ValueFormatter | None = None,
    percent_formatter: PercentFormatter | None = None,
    id: str | dict[str, Any] | None = None,
    class_name: str | None = None,
    style: StyleMapping = None,
    header_style: StyleMapping = None,
    row_style: StyleMapping = None,
    label_style: StyleMapping = None,
    chart_style: StyleMapping = None,
    delta_style: StyleMapping = None,
    aria_label: str | None = None,
    **props: Any,
) -> html.Div:
    """Create labeled time-series sparkline rows.

    Args:
        rows: Row mappings. Each row requires ``label`` and ``values``. Optional
            row keys include ``line_color``, ``tone``, ``tooltip``,
            ``display_width``, ``width``, ``height``, ``y_min``, ``y_max``,
            ``delta_text``, ``delta_tone``, ``class_name``, and ``style``.
        width: Default SVG coordinate width for row sparklines.
        height: Default SVG coordinate height for row sparklines.
        display_width: Default rendered CSS width for row sparklines.
        padding: Default internal SVG padding.
        shared_scale: Use one vertical scale across all rows. Defaults to
            ``True``.
        show_delta: Show a visible delta column. Defaults to ``False``; change
            is still available in generated tooltips.
        colors: Optional tone color overrides.
        headers: Optional column headers.
        tooltip_placement: Default row tooltip placement.
        tooltip_max_width: Default row tooltip max width.
        tooltip_style: Default row tooltip style overrides.
        value_formatter: Default formatter for generated tooltip values.
        percent_formatter: Default formatter for generated tooltip percents.
        id: Optional Dash component id.
        class_name: Extra CSS class names for the stack.
        style: Inline style overrides for the stack root.
        header_style: Inline style overrides for the header row.
        row_style: Inline style overrides for each row.
        label_style: Inline style overrides for row labels.
        chart_style: Inline style overrides for row charts.
        delta_style: Inline style overrides for visible delta rows.
        aria_label: Accessible label override.
        **props: Additional Dash props passed to the root ``html.Div``.

    Returns:
        A Dash ``html.Div`` containing labeled sparkline rows.
    """

    y_min, y_max = _resolve_sparkline_stack_domain(rows) if shared_scale else (None, None)
    stack_children = []
    if headers is not None:
        stack_children.append(
            _sparkline_stack_header(headers, header_style=header_style)
        )

    stack_children.extend(
        _sparkline_row(
            row,
            width=width,
            height=height,
            display_width=display_width,
            padding=padding,
            y_min=y_min,
            y_max=y_max,
            show_delta=show_delta,
            colors=colors,
            default_tooltip_placement=tooltip_placement,
            default_tooltip_max_width=tooltip_max_width,
            default_tooltip_style=tooltip_style,
            default_value_formatter=value_formatter,
            default_percent_formatter=percent_formatter,
            row_style=row_style,
            label_style=label_style,
            chart_style=chart_style,
            delta_style=delta_style,
        )
        for row in rows
    )

    component_props = {
        **props,
        "className": _join_class_names("encinitas-sparkline-stack", class_name),
        "role": "group",
        "style": _merge_style(style),
        **{"aria-label": aria_label or "Sparkline chart"},
    }
    if id is not None:
        component_props["id"] = id

    return html.Div(stack_children, **component_props)


def delta_indicator(
    value: float | int | None = None,
    *,
    text: Any | None = None,
    direction: DeltaDirection | None = None,
    tone: ValueTone | None = None,
    tooltip: str | None = None,
    colors: Mapping[ValueTone, str] | None = None,
    style: StyleMapping = None,
    icon_style: StyleMapping = None,
    text_style: StyleMapping = None,
) -> html.Div:
    """Create a delta indicator row.

    Args:
        value: Numeric value used to derive direction and default text.
        text: Optional display text override.
        direction: Force ``"up"``, ``"down"``, or ``"flat"``.
        tone: Optional tone override.
        tooltip: Native title tooltip for the delta row.
        colors: Optional tone color overrides.
        style: Inline style overrides for the row.
        icon_style: Inline style overrides for the icon.
        text_style: Inline style overrides for the text.

    Returns:
        A Dash ``html.Div`` delta indicator.
    """

    palette = {**DEFAULT_TONE_COLORS, **(colors or {})}
    resolved_direction = direction or direction_from_value(value)
    resolved_tone = tone or _tone_from_direction(resolved_direction)
    color = palette[resolved_tone]
    label = text if text is not None else _format_delta(value)

    indicator_style = _merge_style(
        {"--encinitas-delta-color": color},
        style,
    )

    return html.Div(
        [
            html.Span(
                _icon_for_direction(resolved_direction),
                className="encinitas-kpi-card__delta-icon",
                style=_merge_style(icon_style),
                **{"aria-hidden": "true"},
            ),
            html.Span(
                label,
                className="encinitas-kpi-card__delta-text",
                style=_merge_style(text_style),
            ),
        ],
        className=_join_class_names(
            "encinitas-kpi-card__delta",
            f"encinitas-kpi-card__delta--{resolved_direction}",
            f"encinitas-kpi-card__delta--{resolved_tone}",
        ),
        style=indicator_style,
        **_optional_attrs(
            {"aria-label": f"{resolved_direction} delta"},
            {"title": tooltip},
        ),
    )


def tone_from_value(
    value: float | int | None,
    *,
    thresholds: tuple[float, float] = (0, 0),
) -> ValueTone:
    """Return a tone for a numeric value.

    Args:
        value: Numeric value to classify. ``None`` returns ``"neutral"``.
        thresholds: ``(negative, positive)`` cutoffs.

    Returns:
        ``"positive"``, ``"negative"``, or ``"neutral"``.
    """

    if value is None:
        return "neutral"

    negative_threshold, positive_threshold = thresholds
    if value > positive_threshold:
        return "positive"
    if value < negative_threshold:
        return "negative"
    return "neutral"


def tone_from_actual_target(
    actual: float | int,
    target: float | int,
    *,
    favorable_direction: FavorableDirection = "higher",
    tolerance: float | int = 0,
) -> ValueTone:
    """Return a tone from actual-vs-target performance.

    Args:
        actual: Actual metric value.
        target: Target metric value.
        favorable_direction: ``"higher"`` when higher actuals are better, or
            ``"lower"`` when lower actuals are better.
        tolerance: Neutral band around target.

    Returns:
        ``"positive"``, ``"negative"``, or ``"neutral"``.
    """

    if abs(actual - target) <= tolerance:
        return "neutral"
    if favorable_direction == "lower":
        return "positive" if actual < target else "negative"
    return "positive" if actual > target else "negative"


def direction_from_value(value: float | int | None) -> DeltaDirection:
    """Return delta direction for a numeric value.

    Args:
        value: Numeric delta value. ``None`` and zero return ``"flat"``.

    Returns:
        ``"up"``, ``"down"``, or ``"flat"``.
    """

    if value is None or value == 0:
        return "flat"
    if value > 0:
        return "up"
    return "down"


def _tone_from_direction(direction: DeltaDirection) -> ValueTone:
    if direction == "up":
        return "positive"
    if direction == "down":
        return "negative"
    return "neutral"


def _icon_for_direction(direction: DeltaDirection) -> str:
    if direction == "up":
        return "\u25b2"
    if direction == "down":
        return "\u25bc"
    return "\u25ac"


def _format_delta(value: float | int | None) -> str:
    if value is None:
        return "No change"
    if value > 0:
        return f"+{value:g}"
    return f"{value:g}"


def _resolve_bullet_maximum(
    actual: float | int,
    target: float | int,
    maximum: float | int | None,
    background: float | int | None,
) -> float:
    candidates = [float(actual), float(target), 1.0]
    if maximum is not None:
        candidates.append(float(maximum))
    if background is not None:
        candidates.append(float(background))
    return max(candidates)


def _resolve_bullet_stack_maximum(
    rows: Sequence[Mapping[str, Any]],
    background: float | int | None,
) -> float:
    candidates = [1.0]
    if background is not None:
        candidates.append(float(background))
    for row in rows:
        candidates.append(float(row["actual"]))
        candidates.append(float(row["target"]))
        if row.get("background") is not None:
            candidates.append(float(row["background"]))
        if row.get("maximum") is not None:
            candidates.append(float(row["maximum"]))
    return max(candidates)


def _bullet_stack_header(
    headers: Sequence[Any],
    *,
    show_values: bool,
    header_style: StyleMapping,
) -> html.Div:
    header_cells = list(headers)
    expected_count = 3 if show_values else 2
    if len(header_cells) < expected_count:
        header_cells.extend([""] * (expected_count - len(header_cells)))

    children = [
        html.Div(
            header_cells[0],
            className="encinitas-bullet-stack__header-label",
        ),
        html.Div(
            header_cells[1],
            className="encinitas-bullet-stack__header-chart",
        ),
    ]
    if show_values:
        children.append(
            html.Div(
                header_cells[2],
                className="encinitas-bullet-stack__header-value",
            )
        )

    return html.Div(
        children,
        className="encinitas-bullet-stack__header",
        style=_merge_style(header_style),
    )


def _bullet_chart_row(
    row: Mapping[str, Any],
    *,
    shared_maximum: float | int,
    default_background: float | int | None,
    default_favorable_direction: FavorableDirection,
    default_tolerance: float | int,
    colors: Mapping[ValueTone, str] | None,
    show_values: bool,
    default_tooltip_placement: TooltipPlacement,
    default_tooltip_max_width: str | int | None,
    default_tooltip_style: StyleMapping,
    default_value_formatter: ValueFormatter | None,
    default_percent_formatter: PercentFormatter | None,
    row_style: StyleMapping,
    label_style: StyleMapping,
    value_style: StyleMapping,
    chart_style: StyleMapping,
) -> html.Div:
    actual = row["actual"]
    target = row["target"]
    prior_year = row.get("prior_year")
    label = row["label"]
    value = row.get("value", _format_bullet_value(actual, target))
    chart = bullet_chart(
        actual,
        target,
        prior_year=prior_year,
        maximum=row.get("maximum", shared_maximum),
        background=row.get("background", default_background),
        favorable_direction=row.get(
            "favorable_direction", default_favorable_direction
        ),
        tolerance=row.get("tolerance", default_tolerance),
        actual_tone=row.get("actual_tone"),
        colors=colors,
        tooltip=False,
        style=chart_style,
        aria_label=row.get("aria_label"),
    )

    children: list[Any] = [
        html.Div(
            label,
            className="encinitas-bullet-stack__label",
            style=_merge_style(label_style),
        ),
        html.Div(
            chart,
            className="encinitas-bullet-stack__chart",
        ),
    ]
    if show_values:
        children.append(
            html.Div(
                value,
                className="encinitas-bullet-stack__value",
                style=_merge_style(value_style),
            )
        )

    tooltip_content = row.get("tooltip")
    if tooltip_content is None and prior_year is not None:
        tooltip_content = _default_bullet_tooltip(
            actual=actual,
            prior_year=prior_year,
            target=target,
            value_formatter=row.get("value_formatter", default_value_formatter),
            percent_formatter=row.get(
                "percent_formatter", default_percent_formatter
            ),
        )
    if tooltip_content is False:
        tooltip_content = None
    row_id = row.get("id")
    tooltip_id = row.get("tooltip_id") or _tooltip_id_from_card_id(row_id)
    tooltip_placement = row.get("tooltip_placement", default_tooltip_placement)
    tooltip_max_width = row.get("tooltip_max_width", default_tooltip_max_width)

    if tooltip_content is not None:
        tooltip_css_vars = {}
        if tooltip_max_width is not None:
            tooltip_css_vars["--encinitas-tooltip-max-width"] = _css_size(
                tooltip_max_width
            )
        tooltip_props: dict[str, Any] = {
            "className": _join_class_names(
                "encinitas-bullet-stack__tooltip",
                f"encinitas-bullet-stack__tooltip--{tooltip_placement}",
            ),
            "role": "tooltip",
            "style": _merge_style(tooltip_css_vars, default_tooltip_style),
        }
        if tooltip_id is not None:
            tooltip_props["id"] = tooltip_id
        children.append(html.Div(tooltip_content, **tooltip_props))

    row_props: dict[str, Any] = {
        "className": _join_class_names("encinitas-bullet-stack__row", row.get("class_name")),
        "style": _merge_style(row_style, row.get("style")),
    }
    if row_id is not None:
        row_props["id"] = row_id
    if tooltip_content is not None:
        row_props["tabIndex"] = row.get("tabIndex", 0)
    if tooltip_content is not None and tooltip_id is not None:
        row_props["aria-describedby"] = tooltip_id

    return html.Div(children, **row_props)


def _percentage(value: float | int, maximum: float) -> str:
    if maximum <= 0:
        return "0%"
    return f"{_clamp((float(value) / maximum) * 100):g}%"


def _sparkline_points(
    values: Sequence[float | int],
    *,
    width: int,
    height: int,
    padding: float | int = 0,
    y_min: float | int | None = None,
    y_max: float | int | None = None,
) -> list[tuple[float, float]]:
    minimum = min(values) if y_min is None else y_min
    maximum = max(values) if y_max is None else y_max
    inner_width = max(width - (float(padding) * 2), 0)
    inner_height = max(height - (float(padding) * 2), 0)
    x_step = inner_width / (len(values) - 1) if len(values) > 1 else 0
    y_midpoint = float(padding) + (inner_height / 2)

    points: list[tuple[float, float]] = []
    for index, value in enumerate(values):
        x = float(padding) + (index * x_step)
        if maximum == minimum:
            y = y_midpoint
        else:
            y = (
                height
                - float(padding)
                - (
                    (float(value) - float(minimum))
                    / (float(maximum) - float(minimum))
                )
                * inner_height
            )
        points.append((x, y))
    return points


def _resolve_sparkline_stack_domain(
    rows: Sequence[Mapping[str, Any]],
) -> tuple[float | int, float | int]:
    values = [
        value
        for row in rows
        for value in row["values"]
    ]
    if not values:
        return 0, 0
    return min(values), max(values)


def _sparkline_stack_header(
    headers: Sequence[Any],
    *,
    header_style: StyleMapping,
) -> html.Div:
    header_cells = list(headers)
    if len(header_cells) < 2:
        header_cells.extend([""] * (2 - len(header_cells)))
    return html.Div(
        [
            html.Div(
                header_cells[0],
                className="encinitas-sparkline-stack__header-label",
            ),
            html.Div(
                header_cells[1],
                className="encinitas-sparkline-stack__header-chart",
            ),
        ],
        className="encinitas-sparkline-stack__header",
        style=_merge_style(header_style),
    )


def _sparkline_row(
    row: Mapping[str, Any],
    *,
    width: int,
    height: int,
    display_width: str | int | None,
    padding: float | int,
    y_min: float | int | None,
    y_max: float | int | None,
    show_delta: bool,
    colors: Mapping[ValueTone, str] | None,
    default_tooltip_placement: TooltipPlacement,
    default_tooltip_max_width: str | int | None,
    default_tooltip_style: StyleMapping,
    default_value_formatter: ValueFormatter | None,
    default_percent_formatter: PercentFormatter | None,
    row_style: StyleMapping,
    label_style: StyleMapping,
    chart_style: StyleMapping,
    delta_style: StyleMapping,
) -> html.Div:
    values = row["values"]
    label = row["label"]
    row_id = row.get("id")
    tooltip = row.get("tooltip")
    chart = sparkline(
        values,
        width=row.get("width", width),
        height=row.get("height", height),
        display_width=row.get("display_width", display_width),
        padding=row.get("padding", padding),
        y_min=row.get("y_min", y_min),
        y_max=row.get("y_max", y_max),
        tone=row.get("tone"),
        line_color=row.get("line_color"),
        colors=colors,
        stroke_width=row.get("stroke_width", 2),
        show_endpoint=row.get("show_endpoint", False),
        tooltip=tooltip,
        tooltip_id=row.get("tooltip_id"),
        tooltip_max_width=row.get("tooltip_max_width", default_tooltip_max_width),
        tooltip_placement=row.get("tooltip_placement", default_tooltip_placement),
        tooltip_style=_merge_style(default_tooltip_style, row.get("tooltip_style")),
        value_formatter=row.get("value_formatter", default_value_formatter),
        percent_formatter=row.get("percent_formatter", default_percent_formatter),
        class_name=row.get("chart_class_name"),
        style=chart_style,
        aria_label=row.get("aria_label"),
    )

    row_props: dict[str, Any] = {
        "className": _join_class_names("encinitas-sparkline-stack__row", row.get("class_name")),
        "style": _merge_style(row_style, row.get("style")),
    }
    if row_id is not None:
        row_props["id"] = row_id

    children = [
            html.Div(
                label,
                className="encinitas-sparkline-stack__label",
                style=_merge_style(label_style),
            ),
            html.Div(chart, className="encinitas-sparkline-stack__chart"),
    ]
    if show_delta:
        delta = row.get("delta", values[-1] - values[0])
        children.append(
            delta_indicator(
                delta,
                text=row.get("delta_text", _format_delta(delta)),
                tone=row.get("delta_tone"),
                style=delta_style,
            )
        )

    return html.Div(children, **row_props)


def _sparkline_svg(
    points: Sequence[tuple[float, float]],
    *,
    width: int,
    height: int,
    color: str,
    stroke_width: float | int,
    show_endpoint: bool,
) -> str:
    point_values = " ".join(f"{x:g},{y:g}" for x, y in points)
    endpoint = points[-1]
    endpoint_markup = ""
    if show_endpoint:
        endpoint_markup = (
            f'<circle cx="{endpoint[0]:g}" cy="{endpoint[1]:g}" r="2.5" '
            f'fill="#ffffff" stroke="{color}" stroke-width="{stroke_width}" />'
        )
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width:g} {height:g}" '
        'preserveAspectRatio="none">'
        f'<polyline points="{point_values}" fill="none" stroke="{color}" '
        f'stroke-width="{stroke_width}" stroke-linecap="round" '
        f'stroke-linejoin="round" vector-effect="non-scaling-stroke" />'
        f"{endpoint_markup}</svg>"
    )


def _clamp(value: float, minimum: float = 0, maximum: float = 100) -> float:
    return min(max(value, minimum), maximum)


def _bullet_aria_label(actual: float | int, target: float | int) -> str:
    return f"Actual {actual:g}; target {target:g}"


def _format_bullet_value(actual: float | int, target: float | int) -> str:
    return f"{actual:g} / {target:g}"


def _sparkline_aria_label(values: Sequence[float | int]) -> str:
    return f"Sparkline from {values[0]:g} to {values[-1]:g}"


def _default_bullet_tooltip(
    *,
    actual: float | int,
    prior_year: float | int,
    target: float | int,
    value_formatter: ValueFormatter | None = None,
    percent_formatter: PercentFormatter | None = None,
) -> html.Div:
    format_value = value_formatter or _format_number
    format_percent = percent_formatter or _format_percent
    return html.Div(
        [
            _bullet_tooltip_row("Actual", format_value(actual)),
            _bullet_tooltip_row("Prior year", format_value(prior_year)),
            _bullet_tooltip_row("Target", format_value(target)),
            _bullet_tooltip_row(
                "Vs prior year",
                _format_percent_change(
                    actual,
                    prior_year,
                    percent_formatter=format_percent,
                ),
            ),
            _bullet_tooltip_row(
                "Vs target",
                _format_percent_change(
                    actual,
                    target,
                    percent_formatter=format_percent,
                ),
            ),
        ],
        className="encinitas-bullet-tooltip-detail",
    )


def _default_sparkline_tooltip(
    values: Sequence[float | int],
    *,
    value_formatter: ValueFormatter | None = None,
    percent_formatter: PercentFormatter | None = None,
) -> html.Div:
    format_value = value_formatter or _format_number
    format_percent = percent_formatter or _format_percent
    return html.Div(
        [
            _bullet_tooltip_row("Start", format_value(values[0])),
            _bullet_tooltip_row("End", format_value(values[-1])),
            _bullet_tooltip_row("Min", format_value(min(values))),
            _bullet_tooltip_row("Max", format_value(max(values))),
            _bullet_tooltip_row(
                "Change",
                _format_percent_change(
                    values[-1],
                    values[0],
                    percent_formatter=format_percent,
                ),
            ),
        ],
        className="encinitas-bullet-tooltip-detail",
    )


def _bullet_tooltip_row(label: str, value: str) -> html.Div:
    return html.Div(
        [
            html.Span(label, className="encinitas-bullet-tooltip-detail__label"),
            html.Span(value, className="encinitas-bullet-tooltip-detail__value"),
        ],
        className="encinitas-bullet-tooltip-detail__row",
    )


def _format_percent_change(
    value: float | int,
    baseline: float | int,
    *,
    percent_formatter: PercentFormatter,
) -> str:
    if baseline == 0:
        return "n/a"
    return percent_formatter(
        ((float(value) - float(baseline)) / abs(float(baseline))) * 100
    )


def _format_number(value: float | int) -> str:
    return f"{value:g}"


def _format_percent(value: float) -> str:
    return f"{value:+.1f}%"


def _css_size(value: str | int) -> str:
    if isinstance(value, int):
        return f"{value}px"
    return value


def _merge_style(*styles: StyleMapping) -> Style:
    merged: Style = {}
    for style in styles:
        if style:
            merged.update(style)
    return merged


def _join_class_names(*class_names: str | None) -> str:
    return " ".join(class_name for class_name in class_names if class_name)


def _tooltip_id_from_card_id(id: str | dict[str, Any] | None) -> str | None:
    if isinstance(id, str):
        return f"{id}-tooltip"
    return None


def _info_icon() -> html.Span:
    return html.Span(
        "i",
        className="encinitas-kpi-card__info-icon",
        **{"aria-hidden": "true"},
    )


def _optional_attrs(*attrs: Mapping[str, Any]) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    for attr in attrs:
        merged.update({key: value for key, value in attr.items() if value is not None})
    return merged
