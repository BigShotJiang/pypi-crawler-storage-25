import time,re,requests,json,os,hashlib,subprocess,base64
from requests.exceptions import TooManyRedirects
import urllib.parse 
import datetime,timeit
from pathlib import Path
import cv2
import csv
from PIL import Image
from PIL.ExifTags import TAGS
from piexif import ImageIFD
import traceback
from bs4 import BeautifulSoup
import chardet
import ast
from collections import deque
import piexif
from mutagen.mp4 import MP4
import stat
from tencentcloud.common import credential
from tencentcloud.common.profile.client_profile import ClientProfile
from tencentcloud.common.profile.http_profile import HttpProfile
from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException
from tencentcloud.dnspod.v20210323 import dnspod_client, models
from PIL import Image
from PIL import JpegImagePlugin
import os
import stat
from mutagen.mp4 import MP4
import socket


# import pandas as pd
G_verify=True
def get_current_ipv6():
    try:
        s = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        s.connect(("2400:3200::1", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return None

def update_dns(ipv6,SECRET_ID='AKIDGXimeMs...',SECRET_KEY='KRWSCnCU...',DOMAIN="pilcs.asia",SUB_DOMAIN="g1"):
    try:
        cred = credential.Credential(SECRET_ID, SECRET_KEY)
        httpProfile = HttpProfile()
        httpProfile.endpoint = "dnspod.tencentcloudapi.com"

        clientProfile = ClientProfile()
        clientProfile.httpProfile = httpProfile
        client = dnspod_client.DnspodClient(cred, "", clientProfile)

        # ======================
        # 【核心修复】先查 -> 有就删 -> 再加新的
        # ======================
        try:
            req = models.DescribeRecordListRequest()
            req.Domain = DOMAIN
            req.Subdomain = SUB_DOMAIN
            req.RecordType = "AAAA"
            resp = client.DescribeRecordList(req)
            records = resp.RecordList

            # 如果有旧记录，先删除！
            if records:
                for record in records:
                    del_req = models.DeleteRecordRequest()
                    del_req.Domain = DOMAIN
                    del_req.RecordId = record.RecordId
                    client.DeleteRecord(del_req)
                print("🗑️ 已清理旧的IPv6解析")

        except Exception as e:
            pass

        # 重新创建新记录
        req_add = models.CreateRecordRequest()
        req_add.Domain = DOMAIN
        req_add.SubDomain = SUB_DOMAIN
        req_add.RecordType = "AAAA"
        req_add.RecordLine = "默认"
        req_add.Value = ipv6
        req_add.TTL = 600
        client.CreateRecord(req_add)

        print("\n🎉 解析更新成功！")
        print(f"域名：{SUB_DOMAIN}.{DOMAIN}")
        print(f"IPv6：{ipv6}")

    except TencentCloudSDKException as err:
        print(f"❌ 错误：{err}")

def 目录检测(directory_path):
    """
    确保指定的目录存在。如果目录不存在，创建它。
    
    :param directory_path: 需要检查或创建的目录路径
    """
    try:
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
            return directory_path
        else:
            return directory_path
    except Exception as e:
        print(f"{'[目录检测]'}Error creating directory: {e}")
        return ''
    
def 时间解析(date_str):
    """
    解析多种格式的日期字符串为 datetime 对象
    支持的格式：2025年01月12日、2025-01-12、2025年1月2日、2025-1-2 等
    """
    # 定义所有可能的日期格式
    date_formats = [
        '%Y年%m月%d日',
        '%Y-%m-%d',
        '%Y年%m月%d',
        '%Y-%m-%d日',
        '%Y年%m%d',
        '%Y%m%d',
        '%Y年%m-%d',
        '%Y-%m月%d'
    ]
    
    # 依次尝试每种格式解析
    for fmt in date_formats:
        try:
            return datetime.datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    
    # 如果所有格式都匹配失败，返回 None 或抛出异常
    raise ValueError(f"无法解析日期：{date_str}，请检查日期格式")

def safe_value(val):
    return val if val is not None else ''

def is_pinyin(text):
    """
    判断输入的文本是否为纯拼音（仅包含字母、数字、空格，无中文）
    返回 True/False
    """
    # 匹配是否包含中文字符
    has_chinese = re.search(r'[\u4e00-\u9fff]', text)
    # 拼音通常是字母（大小写）、数字、空格组成，无中文
    return not has_chinese and bool(re.search(r'[a-zA-Z]', text))
    
def 字典解析(data_str):
    """
    尝试将字符串解析为字典，最多解析2次
    若最终无法解析为字典，返回原始字符串
    """
    # 先判断输入是否为字符串，不是则直接返回
    if not isinstance(data_str, str):
        return data_str
    
    data = data_str
    # 最多尝试解析2次
    for _ in range(2):
        if isinstance(data, str):
            try:
                # 尝试JSON解析
                data = json.loads(data)
            except json.JSONDecodeError as e:
                # 解析失败，记录错误但不中断，继续返回当前结果
                print(f"解析失败: {e}")
                break
            except Exception as e:
                # 捕获其他可能的异常
                print(f"解析时发生错误: {e}")
                break
        else:
            # 已不是字符串，无需继续解析
            break
    
    # 最终检查是否为字典，不是则返回原始字符串
    if isinstance(data, dict):
        return data
    else:
        return data_str


def gint(s: str) -> int:
    if not s:  # 直接处理字符串，无需参数列表
        return 0

    # 符号处理
    sign = 1
    if s[0] == '-':
        sign = -1
        s = s[1:]
    elif s[0] == '+':
        s = s[1:]

    # 数值计算
    result = 0
    for char in s:
        if not char.isdigit():  # 更安全的数字判断
            break
        result = result * 10 + (ord(char) - ord('0'))
    
    return sign * result

def 文件检查(full_path):
    """检查文件是否有效（存在、不是目录、大小不为0）"""
    if not os.path.exists(full_path):
        return True
    
    if os.path.isdir(full_path):
        print(f"错误：路径是目录而不是文件 - {full_path}")
        return False
    
    try:
        if os.path.getsize(full_path) == 0:
            print(f"错误：文件大小为0 - {full_path}")
            return True
    except OSError as e:
        print(f"错误：获取文件大小失败 - {full_path} ({str(e)})")
        return False
    
    return True

def 果心时间():
    current_time = time.strftime("%H:%M:%S", time.localtime())
    return current_time
def 取网络文件大小(url, max_redirects=5):
    return get_url_size_and_response(url, max_redirects)

def 取网页变量(html: str, 变量名: str = "__APOLLO_STATE__") -> dict:
    """
    通用提取网页中的 window.变量名 = {...}
    :param html: 网页源码
    :param 变量名: 要提取的变量名，如 __APOLLO_STATE__
    :return: 解析后的字典
    """
    # 自动拼接正则（动态匹配变量名）
    pattern = rf'window\.{re.escape(变量名)}\s*=\s*({{.*?}});\s*(?:$|\n|\()'
    
    match = re.search(pattern, html, re.DOTALL)
    if not match:
        return {}
    
    try:
        return json.loads(match.group(1))
    except:
        return {}
    
def get_url_size(url, cookies=None, max_redirects=2, verify=False):
    """
    改进版文件大小获取函数，支持多级重定向、携带Cookie、异常处理
    :param url: 原始文件URL
    :param cookies: 可选，传入字典格式的cookie，如 {"sessionid": "xxx", "ttwid": "xxx"}
    :param max_redirects: 最大重定向次数（默认2层）
    :param verify: SSL验证开关
    :return: 文件大小（字节），失败返回0
    """
    # 第一次请求的请求头（你提供的完整头）
    first_headers = {
        "Connection": "keep-alive",
        "sec-ch-ua": "\"Chromium\";v=\"146\", \"Not-A.Brand\";v=\"24\", \"Microsoft Edge\";v=\"146\"",
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": "\"Windows\"",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win66; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Sec-Fetch-Site": "none",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-User": "?1",
        "Sec-Fetch-Dest": "document",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6"
    }
    # 第二次及以后请求的头（多了 Accept-Encoding）
    redirect_headers = first_headers.copy()
    redirect_headers["Accept-Encoding"] = "gzip, deflate"

    session_oj = requests.Session()
    current_url = url
    redirect_count = 0

    try:
        while redirect_count < max_redirects:
            # 第一次用 first_headers，重定向用 redirect_headers
            use_headers = first_headers if redirect_count == 0 else redirect_headers

            response = session_oj.get(
                current_url,
                headers=use_headers,
                cookies=cookies,  # <--- 这里自动携带传入的cookie
                allow_redirects=False,
                stream=True,
                timeout=15,
                verify=verify,
            )

            if 200 <= response.status_code < 300:
                content_length = response.headers.get('Content-Length')
                if content_length and int(content_length) > 0:
                    return int(content_length)
                return 0

            elif 300 <= response.status_code < 400:
                location = response.headers.get('Location')
                if not location:
                    break
                current_url = urllib.parse.urljoin(response.url, location)
                redirect_count += 1
                response.close()
            else:
                break

        return 0

    except (requests.Timeout, requests.ConnectionError) as e:
        print(f"Network error: {str(e)}")
        return 0
    except requests.RequestException as e:
        print(f"Request failed: {str(e)}")
        return 0
    except Exception as e:
        print(f"Unknown error: {str(e)}")
        return 0
    finally:
        session_oj.close()
def get_url_size_and_response(url, max_redirects=5):
    """
    改进版：获取文件大小 + 返回有效响应对象（支持继续下载，无需重复请求）
    :param url: 原始文件URL
    :param max_redirects: 最大重定向次数（默认5层）
    :return: tuple(文件大小（字节）, 响应对象)；失败时返回 (0, None)
    """
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "Connection": "keep-alive",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0"
    }

    session_oj = requests.Session()
    current_url = url
    redirect_count = 0
    final_response = None

    try:
        print(f"Fetching URL info for: {url}")
        while redirect_count < max_redirects:
            # 发起请求（stream=True 不下载完整正文，仅获取响应头+保持连接）
            response = session_oj.get(
                current_url,
                headers=headers,
                allow_redirects=False,  # 手动处理重定向，便于跟踪URL
                stream=True,
                timeout=5,
                verify=G_verify
            )
            final_response = response  # 保存当前响应（无论状态码）

            # 处理成功响应（2xx）：获取大小并返回响应
            if 200 <= response.status_code < 300:
                content_length = response.headers.get('Content-Length')
                file_size = int(content_length) if content_length and content_length.isdigit() else 0
                print(f"获取文件大小成功：{file_size} 字节")
                return file_size, response  # 关键：返回响应对象，供后续下载

            # 处理重定向（3xx）：更新URL继续请求
            elif 300 <= response.status_code < 400:
                location = response.headers.get('Location')
                if not location:
                    print("重定向但未找到 Location 头")
                    break

                # 构建绝对URL（避免相对路径问题）
                current_url = urllib.parse.urljoin(response.url, location)
                redirect_count += 1
                print(f"重定向到第 {redirect_count} 层：{current_url}")
                # 不关闭响应，session会自动复用连接（但手动关闭也可，不影响）
                # response.close()

            # 其他状态码（4xx/5xx）：直接失败
            else:
                print(f"请求失败，状态码：{response.status_code}")
                break

        # 超过最大重定向次数
        if redirect_count >= max_redirects:
            raise TooManyRedirects(f"超过最大重定向次数（{max_redirects}）")

        return 0, None

    except (requests.Timeout, requests.ConnectionError) as e:
        print(f"网络错误：{str(e)}")
        return 0, None
    except TooManyRedirects as e:
        print(f"重定向错误：{str(e)}")
        return 0, None
    except Exception as e:
        print(f"未知错误：{str(e)}")
        return 0, None
def 修复双重转义JSON(content_or_file_path):
    """
    修复双重转义的JSON内容
    
    参数:
        content_or_file_path: 可以是JSON文本内容，也可以是文件路径
    
    返回:
        修复后的JSON数据对象，如果失败返回None
    """
    # 判断输入是文件路径还是文本内容
    if isinstance(content_or_file_path, str):
        # 检查是否是文件路径（包含文件扩展名或路径分隔符）
        if ('.json' in content_or_file_path or 
            '\\' in content_or_file_path or 
            '/' in content_or_file_path):
            try:
                # 尝试作为文件路径读取
                with open(content_or_file_path, 'r', encoding='utf-8') as f:
                    original_content = f.read().strip()
                print(f"📊 从文件读取内容: {content_or_file_path}")
                print(f"📁 文件大小: {len(original_content)} 字符")
            except (FileNotFoundError, IOError):
                # 如果文件读取失败，则当作文本内容处理
                original_content = content_or_file_path.strip()
                print("📝 输入为JSON文本内容")
                print(f"📁 内容大小: {len(original_content)} 字符")
        else:
            # 直接作为文本内容处理
            original_content = content_or_file_path.strip()
            print("📝 输入为JSON文本内容")
            print(f"📁 内容大小: {len(original_content)} 字符")
    else:
        # 如果不是字符串，转换为字符串
        original_content = str(content_or_file_path).strip()
        print("📝 输入已转换为文本内容")
        print(f"📁 内容大小: {len(original_content)} 字符")
    
    print(f"🔍 原始内容前100字符: {original_content[:100]}")
    
    # 方法1: 直接解析（如果已经是有效JSON）
    try:
        data = json.loads(original_content)
        print("✅ 方法1成功: 直接解析")
        return data
    except json.JSONDecodeError as e:
        print(f"⚠️ 方法1失败: {e}")
    
    # 方法2: 处理双重转义 - 先解析为字符串，再解析为JSON
    try:
        # 先解析外层的JSON字符串
        string_content = json.loads(original_content)
        # 再解析内层的JSON
        data = json.loads(string_content)
        print("✅ 方法2成功: 双重解析")
        return data
    except (json.JSONDecodeError, TypeError) as e:
        print(f"⚠️ 方法2失败: {e}")
    
    # 方法3: 手动处理转义字符
    try:
        # 移除外层的双引号（如果存在）
        if original_content.startswith('"') and original_content.endswith('"'):
            content = original_content[1:-1]
        else:
            content = original_content
        
        # 替换转义字符
        content = content.replace('\\"', '"')
        content = content.replace('\\\\', '\\')
        content = content.replace('\\n', '\n')
        content = content.replace('\\t', '\t')
        content = content.replace('\\r', '\r')
        
        # 处理$undefined值
        content = re.sub(r'"\$undefined"', 'null', content)
        
        data = json.loads(content)
        print("✅ 方法3成功: 手动处理转义字符")
        return data
    except json.JSONDecodeError as e:
        print(f"⚠️ 方法3失败: {e}")
        print(f"🔍 处理后内容前100字符: {content[:100]}")
    
    # 方法4: 使用ast.literal_eval作为最后手段
    try:
        # 先尝试解析为Python字面量
        python_obj = ast.literal_eval(original_content)
        # 如果是字符串，再尝试解析为JSON
        if isinstance(python_obj, str):
            data = json.loads(python_obj)
        else:
            data = python_obj
        print("✅ 方法4成功: 使用ast.literal_eval")
        return data
    except (ValueError, SyntaxError, json.JSONDecodeError) as e:
        print(f"⚠️ 方法4失败: {e}")
    
    # 方法5: 逐步修复（最激进的方法）
    try:
        content = original_content
        
        # 步骤1: 确保是有效的JSON字符串格式
        if not content.startswith('{'):
            # 尝试找到第一个{和最后一个}
            start = content.find('{')
            end = content.rfind('}')
            if start != -1 and end != -1:
                content = content[start:end+1]
        
        # 步骤2: 修复转义字符
        content = re.sub(r'\\(.)', lambda m: m.group(1) if m.group(1) in ['"', '\\'] else m.group(0), content)
        
        # 步骤3: 修复$undefined
        content = re.sub(r'"\$undefined"', 'null', content)
        
        # 步骤4: 修复可能的尾随逗号
        content = re.sub(r',\s*([}\]])', r'\1', content)
        
        data = json.loads(content)
        print("✅ 方法5成功: 逐步修复")
        return data
    except json.JSONDecodeError as e:
        print(f"❌ 方法5失败: {e}")
        print(f"🔍 最终尝试内容前100字符: {content[:100]}")
    
    print("❌ 所有修复方法均失败")
    return None

def 链接_提取链接(text: str, max_length: int = None) -> str:
    """
    提取文本中的首个链接，支持 http/https/ftp/file 协议
    :param text: 原始文本
    :param max_length: 保留链接长度（可选）
    :return: 提取的链接或空字符串
    """
    # 优化后的正则表达式（兼容中文字符和复杂URL）
    pattern = r"https?://[-A-Za-z0-9+&@#/%?=~_|!:,.;]+[-A-Za-z0-9+&@#/%=~_|]"
    matches = re.findall(pattern, text, re.X | re.UNICODE)
    
    if matches:
        first_url = matches[0]
        # 长度处理逻辑
        if max_length and max_length > 0:
            return first_url[:max_length]
        return first_url
    return ""

def 取文件名(url, Gext=True):
    """
    从URL或本地路径中精准提取文件名（处理URL参数、正确控制扩展名）
    :param url: 目标URL链接或本地文件路径
    :param Gext: 是否保留文件扩展名，True保留（默认），False仅返回文件名主体
    :return: 提取出的文件名（无则返回空字符串）
    """
    # 空值处理，避免传入空字符串/None时报错
    if not url:
        return ""
    
    # 处理URL场景
    if "http" in url or "https" in url:
        # 1. 解析URL，分离路径和参数（去掉?后的所有内容）
        parsed_url = urllib.parse.urlparse(url)
        path = parsed_url.path  # 此时path是 /media/Gv9WUUEWYAAE9ZZ.jpg
        
        # 2. 分割路径，取最后一部分作为原始文件名（Gv9WUUEWYAAE9ZZ.jpg）
        filename = path.split('/')[-1]
        # 解码URL编码（处理%20、中文等）
        filename = urllib.parse.unquote(filename)
        
        # 3. 空文件名处理（如URL仅为 https://example.com/）
        if not filename:
            return ""
        
        # 4. 根据Gext参数控制是否保留扩展名
        if not Gext:
            filename = os.path.splitext(filename)[0]  # 去掉扩展名，得到Gv9WUUEWYAAE9ZZ
        return filename

    # 处理本地路径场景
    else:
        filename = os.path.basename(url)
        if not Gext:
            return os.path.splitext(filename)[0]
        return filename

def modify_image_metadata(image_path, author, comment=""):
    """修改图片元数据（重点：备注字段）"""
    if not os.path.exists(image_path):
        print(f"错误：文件 {image_path} 不存在！")
        return False
    
    try:
        img = Image.open(image_path)
        # 初始化EXIF字典（无数据则创建空字典）
        exif_dict = piexif.load(img.info.get("exif", b"")) if "exif" in img.info else {"0th": {}, "Exif": {}, "GPS": {}, "1st": {}, "thumbnail": None}
        
        # ========== 重点：设置备注 ==========
        # ImageDescription 就是备注/图片描述字段
        # exif_dict["0th"][piexif.ImageIFD.ImageDescription] = comment.encode("utf-8")
        # 设置作者（可选）
        exif_dict["0th"][piexif.ImageIFD.Artist] = author.encode("utf-8")
        
        # 写入修改后的元数据并保存
        exif_bytes = piexif.dump(exif_dict)
        img.save(image_path, exif=exif_bytes)
        img.close()
        
        # print(f"✅ 备注已修改为：{comment}")
        print(f"✅ 作者已修改为：{author}")
        return True
    except Exception as e:
        print(f"❌ 修改失败：{str(e)}")
        return False

def check_comment_metadata(image_path):
    """专门读取并验证备注字段"""
    if not os.path.exists(image_path):
        print("文件不存在！")
        return
    
    try:
        img = Image.open(image_path)
        exif_dict = piexif.load(img.info.get("exif", b""))
        img.close()
        
        # ========== 重点：读取备注 ==========
        comment = exif_dict["0th"].get(piexif.ImageIFD.ImageDescription, b"").decode("utf-8", errors="ignore")
        author = exif_dict["0th"].get(piexif.ImageIFD.Artist, b"").decode("utf-8", errors="ignore")
        
        print("\n📌 图片当前元数据：")
        print(f"备注（ImageDescription）：{comment if comment else '无'}")
        print(f"作者（Artist）：{author if author else '无'}")
    except Exception as e:
        print(f"❌ 读取失败：{str(e)}")

def 取重定向地址(url):
        response = requests.get(url, allow_redirects=False)
        redirected_url=''
        # 检查是否是重定向响应
        if response.status_code in [200,301, 302, 303, 307, 308]:  # 常见的重定向状态码
            redirected_url = response.headers.get('Location')
        return redirected_url   



def 读取文件数据(file_path):
    decoded_data = 取文件编码(file_path)
    data = []
    for line_num, line in enumerate(decoded_data.splitlines(), 1):
        data.append(line.split('\t'))
    return data
    # try:
    #     # 设置 quoting 参数为 3，即 csv.QUOTE_NONE，表示不将双引号作为特殊字符处理
    #     # 设置 header=None 表示文件没有表头
    #     df = pd.read_csv(file_path, sep='\t', encoding='utf-8', keep_default_na=False, quoting=3, header=None)
    #     fields = df.values.tolist()
    #     return fields
    # except Exception as e:
    #     print(f"读取文件时出错: {e}")
    #     return []

def 取文件编码2(file_path):
    with open(file_path, 'rb') as f:
        rawdata = f.read()
        result = chardet.detect(rawdata)
        return result['encoding']
pattern = re.compile(r'(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})----(\d+_\d+)----  (\d{8} \d{6})(（\d+）)\.(\w{3,4})')
pattern2= re.compile(r'(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})----(.*?)----(.*?)(（\d+）)\.(\w{3,4})')
pattern3=re.compile(r'(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})丨----  (\d{8} \d{6})----(.*?)--------(（\d+）)\.(\w+)')
pattern4=re.compile(r'(.*?)----(.*?)----(.*?)----(\d{18,})丨----  (\d{8} \d{6})----(.*?)--------(（\d+）)\.(\w+)')


def 去除特殊符号(text, sensitive_words=None):
    """
    清理文本：先去除特殊符号，再过滤敏感词汇（一次性替换/删除）
    Args:
        text (str): 待清理的原始文本
        sensitive_words (list): 敏感词列表（可选），如 ["敏感词1", "敏感词2"]
                                不传则仅去除特殊符号，不传则不过滤敏感词
    Returns:
        str: 清理后的文本
    """
    if not isinstance(text, str):
        text = str(text)  # 兼容非字符串输入
    
    # ========== 第一步：去除特殊符号（保留原有逻辑） ==========
    # 规则：删除Windows非法字符、控制字符、替换字符�、扩展ASCII控制字符等
    special_char_pattern = r'[\\\/:*?"<>|\n\x85\u0000-\u001F\u007F\u0080-\u009F]|[\uFFFD]'
    text_clean = re.sub(special_char_pattern, '', text)
    
    # ========== 第二步：过滤敏感词汇（新增） ==========
    if sensitive_words and isinstance(sensitive_words, list) and len(sensitive_words) > 0:
        # 构建敏感词正则（支持多词匹配，忽略大小写）
        # 转义敏感词中的特殊字符（如*、?、.等），避免正则报错
        escaped_words = [re.escape(word) for word in sensitive_words]
        sensitive_pattern = r'|'.join(escaped_words)
        # 一次性替换所有敏感词为空（也可替换为*，根据需求调整）
        text_clean = re.sub(sensitive_pattern, '', text_clean, flags=re.IGNORECASE)
    
    return text_clean
def parse_aria2_output(output):
    # 使用正则表达式匹配每一行数据
    pattern = re.compile(r'(\w+)\s+\|(\w+)\s+\|(\w+\.?\w+MiB/s)\s+\|(.+)')
    # 按行分割并过滤空行
    lines = [line.strip() for line in output.split('\n') if line.strip()]
    
    # 跳过表头行（含"gid"和分隔行"===="）
    data_lines = [line for line in lines if not line.startswith(('gid', '==='))]
    
    results = []
    for line in data_lines:
        print(line)
        # 使用正则表达式分割列（兼容列间空格）
        columns = re.split(r'\s*\|\s*', line)
        if len(columns) >= 3:

            # 结构化数据
            result = {
                "gid": columns[0],
                "status": columns[1].strip(),
                "average_speed": columns[2],
                "path": columns[3]
            }
            results.append(result)
    
    return results


def aria2_download(url, path, filename, progress_callback=None):
    try:
        # path = path.replace("/","\\\\")
        process = subprocess.Popen(
            [
                "aria2c_137",
                url,  # 完整URL
                "-o", filename,
                "--log-level=warn",
                "--summary-interval=1"  # 关键参数：每秒刷新进度
            ],
            cwd=path, 
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            encoding='utf-8',
            errors='replace'
        )
        print("Started aria2c process with PID:", process.pid)
        input_results = False
        # 实时解析输出流
        while True:
            
            output = process.stdout.readline()
            if not output and process.poll() is not None:
                break
            if output:

                # 提取进度百分比（正则匹配示例）
                if "%)" in output:
                    pattern = r'\[#(\w+)\s([\d\.]+MiB)/([\d\.]+MiB)\((\d+)%\)\sCN:(\d+)\sDL:([\d\.]+MiB)\sETA:(\d+s)\]'
                    match = re.match(pattern, output)
                    if match:

                        download_info = {
                            "gid": match.group(1),
                            "downloaded": match.group(2),
                            "total_size": match.group(3),
                            "percentage": f"{match.group(4)}%",
                            "connections": int(match.group(5)),
                            "download_speed": match.group(6),
                            "eta": match.group(7)
                        }
                    # 如果传入了回调函数，就调用它
                        if progress_callback:
                            progress_callback(download_info)
                elif "Download Results" in output:
                    input_results=True
                    # 提取下载结果
                elif input_results:
                    pattern = r'(\w+)\|(\w+)\s*\|\s(.*?)\|(.+)'
                    match = re.match(pattern, output)
                    if match:
                        result = {
                            "gid": match.group(1).strip(),
                            "status": match.group(2).strip(),
                            "download_speed": match.group(3).strip(),
                            "filename": match.group(4).strip()
                        }
                        
        if process.returncode == 0:
            print("\n下载成功")
            return {"result": True, "message": result}
        else:
            print(f"\n下载失败！错误码：{process.returncode}")
            return {"result": False, "message": "下载失败"}

    except Exception as e:
        print(f"\n下载失败！错误信息：{str(e)}")
        return {"result": False, "message": str(e)}


def calculate_md5(file_path):
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def get_rows(data,end_count=99999999999):
    result = ""
    displayed_count=0
    for row in data:
        if displayed_count >= end_count:
            remaining_count = len(data) - displayed_count
            result += f"查询结果超过4项，未展示的项数: {remaining_count}\n"
            break
        result += str(row['serial']) + '丨' + row['username'] + '丨' + row['videoid'] + '丨' + row['filesizestr'] + '丨' + row['download_time'].strftime("%Y-%m-%d %H:%M:%S") + '\n'
        displayed_count += 1
    return result
def get_rows_view(context, end_count=11):
    # 直接返回数据，不再进行时间类型判断或转换
    result = context[1:]  # 跳过索引为 0 的项
    
    if len(result) < end_count:
        result.extend([''] * (end_count - len(result)))  # 补充空项
    
    return result

def get_rows_mysql(context,columns):
    return [
        [
        row[column].strftime('%Y-%m-%d %H:%M:%S') if 5 <= i <= 8 and type(row[column]) == datetime.datetime else row[column]
        for i, column in enumerate(columns)
        ]
        for row in context
        ]
def str_cookie(cookies_dict):
# Convert the dictionary to a string in the format key=value; key=value; ...
    return "; ".join([f"{key}={value}" for key, value in cookies_dict.items()])


def 目录创建(file_path):
    if not file_path:
        file_path = os.getcwd()
    else:
        if not os.path.exists(file_path):
            try:
                os.makedirs(file_path)
            except Exception as e:
                print(f"Failed to create directory {file_path}: {e}")
                file_path = os.getcwd()
    return file_path


def extract_path_info(input_string):
    # 正则表达式：匹配 ['key'] 和 数字索引
    pattern = r"\['([^']+)'\]|\[(\d+)\]"
    matches = re.findall(pattern, input_string)
    
    # 合并提取到的信息
    path_info = []
    for match in matches:
        # match[0] 是字符串匹配，match[1] 是数字匹配
        path_info.append(match[0] if match[0] else int(match[1]))
    
    return path_info
def 取文件编码(file_path):

        with open(file_path, 'rb') as f:
            raw_data = f.read()
        try:
            return raw_data.decode('utf-8')
        except UnicodeDecodeError:
            return raw_data.decode('gbk')
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
            raise
def is_utf8(data: bytes) -> bool:
    """
    验证字节数据是否符合UTF-8编码规范
    :param data: 待验证的字节数据
    :return: 符合规范返回True，否则False
    """
    n_bytes = 0  # 需要验证的后续字节数
    for byte in data:
        # 将字节转换为0-255的整数
        current = byte
        
        if n_bytes == 0:
            # 单字节字符（ASCII）
            if (current & 0x80) == 0x00:
                continue
            # 两字节字符
            if (current & 0xE0) == 0xC0:
                n_bytes = 1
            # 三字节字符
            elif (current & 0xF0) == 0xE0:
                n_bytes = 2
            # 四字节字符
            elif (current & 0xF8) == 0xF0:
                n_bytes = 3
            else:
                return False
        else:
            # 验证后续字节格式(10xxxxxx)
            if (current & 0xC0) != 0x80:
                return False
            n_bytes -= 1
            
    # 最终需完成所有多字节验证
    return n_bytes == 0
def 混淆前1MB_(file_path):
    """对文件前1MB进行可逆混淆，改变MD5但不影响内容"""
    with open(file_path, 'r+b') as f:
        data = f.read(1024*1024)
        modified_data = bytearray(data)
        
        # 每隔1024字节修改1个字节（示例：XOR操作）
        for i in range(0, len(modified_data), 1024):
            modified_data[i] = modified_data[i] ^ 0x55  # 简单XOR混淆
            
        f.seek(0)
        f.write(bytes(modified_data))
        
    return True

def 混淆前1MB(file_path, operation_type = "混淆", position=1):
    """处理文件（混淆或修复）前1MB或后1MB，并处理时间戳"""
    try:
        prefix = "改时"
        prefix_bytes = prefix.encode('utf-8')  # 使用UTF-8编码
        max_timestamp_size = 30  # 最大可能的时间戳长度
        file_size = os.path.getsize(file_path)
        
        with open(file_path, 'r+b') as f:
            # 检查文件尾部是否存在"改时"前缀
            has_prefix = False
            new_mtime = None
            timestamp_bytes = b''
            
            # 至少需要足够的空间存储前缀和一个数字字符
            if file_size >= len(prefix_bytes) + 1:
                # 从文件末尾读取足够的数据以查找前缀
                read_size = min(file_size, len(prefix_bytes) + max_timestamp_size)
                f.seek(-read_size, 2)
                check_bytes = f.read(read_size)
                
                # 查找前缀位置
                prefix_pos = check_bytes.find(prefix_bytes)
                if prefix_pos != -1:
                    has_prefix = True
                    # 从找到前缀的位置开始提取时间戳
                    timestamp_bytes = check_bytes[prefix_pos + len(prefix_bytes):]
                    timestamp_str = timestamp_bytes.decode('utf-8', errors='ignore').strip()
                    
                    try:
                        # 尝试解析为浮点数
                        new_mtime = float(timestamp_str)
                        # 验证时间戳是否合理
                        current_time = time.time()
                        if new_mtime < 0 or new_mtime > current_time + 315360000:
                            new_mtime = None
                    except ValueError:
                        new_mtime = None
            
            if operation_type == '混淆':
                # 混淆操作
                
                if not has_prefix:
                    # 获取当前文件修改时间（浮点数）
                    original_mtime = os.path.getmtime(file_path)
                    
                    # 保存原始修改时间到文件尾部
                    timestamp_str = f"{prefix}{original_mtime}"
                    f.seek(0, 2)  # 移动到文件末尾
                    f.write(timestamp_str.encode('utf-8'))  # 使用UTF-8编码写入
                
                # 处理数据块（保持原有逻辑不变）
                block_size = 1024 * 1024  # 1MB
                
                if position == 1:  # 前1MB
                    f.seek(0)
                    data = f.read(min(block_size, file_size))
                    seek_pos = 0
                else:  # 后1MB（不包括时间戳）
                    # 计算有效数据大小，排除可能的时间戳
                    effective_size = file_size - (len(prefix_bytes) + len(timestamp_bytes) if has_prefix else 0)
                    if effective_size <= 0:
                        # 文件太小，不执行混淆
                        return True
                    
                    start_pos = max(0, effective_size - block_size)
                    f.seek(start_pos)
                    data = f.read(effective_size - start_pos)
                    seek_pos = start_pos
                
                modified_data = bytearray(data)
                
                # 执行混淆操作（XOR 0x55）
                for i in range(0, len(modified_data), 1024):
                    modified_data[i] = modified_data[i] ^ 0x55
                
                # 写回修改后的数据
                f.seek(seek_pos)
                f.write(bytes(modified_data))
                
            else:
                # 修复操作
                
                # 处理数据块（保持原有逻辑不变）
                block_size = 1024 * 1024  # 1MB
                
                if position == 1:  # 前1MB
                    f.seek(0)
                    data = f.read(min(block_size, file_size))
                    seek_pos = 0
                else:  # 后1MB（不包括时间戳）
                    # 计算有效数据大小，排除可能的时间戳
                    effective_size = file_size - (len(prefix_bytes) + len(timestamp_bytes) if has_prefix else 0)
                    if effective_size <= 0:
                        # 文件太小，不执行修复
                        return True
                    
                    start_pos = max(0, effective_size - block_size)
                    f.seek(start_pos)
                    data = f.read(effective_size - start_pos)
                    seek_pos = start_pos
                
                modified_data = bytearray(data)
                
                # 执行修复操作（XOR 0x55）
                for i in range(0, len(modified_data), 1024):
                    modified_data[i] = modified_data[i] ^ 0x55
                
                # 写回修改后的数据
                f.seek(seek_pos)
                f.write(bytes(modified_data))
                
                # 如果存在有效时间戳，移除它并恢复文件时间
                if has_prefix and new_mtime is not None:
                    # 计算时间戳的实际长度（包括前缀）
                    timestamp_total_len = len(prefix_bytes) + len(timestamp_bytes)
                    # 截断文件，移除时间戳
                    f.truncate(file_size - timestamp_total_len)
                    # 更新文件修改时间（使用浮点数时间戳）
                    os.utime(file_path, (os.path.getatime(file_path), new_mtime))
            
        return True
    except Exception as e:
        print(f"操作失败: {file_path} - {str(e)}")
        return False  


def 追加随机数据(file_path):
    """在文件末尾追加随机数据以改变MD5值"""
    try:
        # 生成16-64字节的随机数据
        # random_data = bytes(random.getrandbits(8) for _ in range(random.randint(16, 64)))
        # 要追加的字节值列表（十进制）
        bytes_to_append = [110, 110, 110]  # 对应 ASCII 字符 'n', 'n', 'n'

        # 转换为字节流（两种方式）
        # 方式1：使用 bytes() 直接转换列表
        byte_data = bytes(bytes_to_append)  # 结果为 b'nnn'

        # # 方式2：使用列表推导式（适用于复杂逻辑）
        # byte_data = bytes([x for x in bytes_to_append])  # 同上


        # 追加到文件末尾
        with open(file_path, 'ab') as f:
            f.write(byte_data)
        
        # 计算新的MD5（仅用于调试）
        new_md5 = 计算文件MD5(file_path)
        print(f"文件MD5已修改为: {new_md5}")
        return True
    except Exception as e:
        print(f"修改MD5失败: {e}")
        return False

def 计算文件MD5(file_path):
    """计算文件的MD5值"""
    hash_md5 = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()
def get_file_md5(file_path):

    return 计算文件MD5(file_path)
def 修改JPEGMD5(file_path):
    """修改JPEG文件的MD5，通过添加APP14段"""

    
    try:
        img = Image.open(file_path)
        # 添加一些EXIF信息
        img.save(file_path, "JPEG", quality=img.quality, 
                 subsampling=img.subsampling, 
                 exif=img.info.get('exif', b''))
        print("JPEG文件MD5已修改")
    except Exception as e:
        print(f"修改JPEG失败: {e}")

def element_to_dom(data):
    """
    将 HTML 字符串转换为 BeautifulSoup 对象
    :param data: HTML 字符串
    :return: BeautifulSoup 对象
    """
    if data is None:
        return None
    return BeautifulSoup(data, 'html.parser')
def 文本_取左边(file_id):
    try:
        if not isinstance(file_id, str):
            return ''
        if file_id is None:
            return ''
        i = file_id.find('!')
        if i != -1:
            return file_id[:i]
        else:
            return ''
    except Exception as e:
        return ''
def 文本_取右边(file_id):
    try:
        if file_id is None:
            return ''
        index = file_id.index('!')
        return file_id[:index]
    except ValueError:
        return ''

def 取中间文本(text, start_str, end_str):
    start_index = text.find(start_str)
    if start_index == -1:
        return ""
    start_index += len(start_str)
    end_index = text.find(end_str, start_index)
    if end_index == -1:
        return ""
    return text[start_index:end_index]

def 毫秒转时分秒(ms):
    # 将毫秒转为秒
    seconds = ms / 1000
    
    # 计算小时、分钟和秒
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = int(seconds % 60)
    
    # 格式化为时:分:秒格式
    return f"{hours:02}:{minutes:02}:{seconds:02}"
def format_timestamp(timestamp):
    ts_num = float(timestamp)
    # 第二步：自动判断毫秒戳/秒戳（13位=毫秒，除以1000转秒）
    if len(str(int(ts_num))) == 13:
        ts_num = ts_num / 1000
    return datetime.datetime.fromtimestamp(ts_num).strftime('%Y-%m-%d %H:%M:%S')
def format_file_timestamp(timestamp):
    ts_num = float(timestamp)
    # 第二步：自动判断毫秒戳/秒戳（13位=毫秒，除以1000转秒）
    if len(str(int(ts_num))) == 13:
        ts_num = ts_num / 1000
    return datetime.datetime.fromtimestamp(ts_num).strftime('%Y%m%d_%H%M%S')
# def get_filetime(file_path):
#     return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getctime(file_path)))
def get_file_creation_time(full_path):
    # 获取文件的创建时间戳
    timestamp = int(os.path.getctime(full_path))
    
    # 转换为 datetime 对象
    creation_time_obj = datetime.datetime.fromtimestamp(timestamp)
    
    # 格式化为字符串
    creation_time_str = creation_time_obj.strftime("%Y-%m-%d %H:%M:%S")
    
    # 返回字典形式
    return {
        "datetime_obj": creation_time_obj,
        "datetime_str": creation_time_str
    }
def get_file_type(file_path):
    try:
        with open(file_path, 'rb') as f:
            file_header = f.read(20)
    except FileNotFoundError:
        print(f"文件 {file_path} 未找到。")
        return None
    except PermissionError:
        print(f"没有权限读取文件 {file_path}。")
        return None

    if file_header.startswith(b'\xFF\xD8'):
        return 'jpg'
    elif file_header.startswith(b'\x89PNG'):
        return 'png'
    elif file_header.startswith(b'GIF'):
        return 'gif'
    elif file_header.startswith(b'\x25\x50\x44\x46'):
        return 'pdf'
    elif file_header[:4] == b'\x00\x00\x00\x18' and file_header[4:8] == b'ftyp':
        return 'mp4'
    else:
        return None

x_patterns = [

    {"r": r'(.*?)----(.*?)----(.*?)https.*?丨(.*?)----(\d{18,})----(\d+_\d{18,})----(.*?)(\（\d+\）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})----(\d+_\d{18,})----(.*?)(\（\d+\）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)丨(.*?)----(.*?)----(\d+_\d{18,})----(.*?)(\（\d+\）)\.(\w+)', "num": 0},
    {"r": r"(.*?)----(.*?)----(.*?)丨(.*?)丨----(\d{18,})--------(.*?)(\（\d+\）)\.(.*?)$", "num": 0},
    {"r": r"(.*?)----(.*?)----(.*?)https.*?丨(.*?)----(\d{18,})--------(.*?)(\（\d+\）)\.(.*?)$", "num": 0},
    {"r": r"(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})--------(.*?)(\（\d+\）)\.(.*?)$", "num": 0},
    {"r": r"^([^\-]+)----([^\-]+)----([^丨]+)http([^丨]+)丨([^丨]+)丨----(\d+)-+（(\d+)）\.(\w+)$", "num": 0},
    {"r": r'(.*?) ----(.*?)---- (.*?) 丨(.*?)----s(.*?)------------(.*?)\.(\d{18,})(\（\d+\）)_(\d+)_(\d{1,3})', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})(\（\d{1,3}\）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)----(\d+_\d{18,})----(.*?)(\（\d{1,3}\）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)http.*?丨(.*?)----(\d{18,})(\（\d{1,3}\）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)http.*?----(\d{18,})(\（\d{1,3}\）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)----(\d{18,})(\（\d{1,3}\）)\.(\w+)', "num": 0},
    {"r": r"(.*?)----(.*?)----(.*?)http(.*?)----(\d{18,})(\（\d+\）)_(.*?)_(.*?)\.(.*?)$", "num": 0},
    {"r": r"(.*?)----(.*?)----(.*?)https.*?----(\d{18,})\.(\w+)", "num": 0},
    {"r": r"(.*?)----(.*?)----(\d{18,})\.(\w+)", "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)丨(.*?)----s   t.co(.*?)------------(\（\d+\）)\.(\d{18,})', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)丨(.*?)----(.*?)--------(\d{8} \d{6})\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})------------(\（\d+\）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})--------(\d{1,3})\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)http.*?----(\d{18,})----(.*?)----  (\d{8} \d{6})(（\d{1,3}）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)----(\d{18,})----(.*?)----  (\d{8} \d{6})(（\d{1,3}）)\.(\w+)', "num": 0}, 
    {"r": r'(.*?)----(.*?)----(.*?)http.*?----(\d{18,})(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)丨(.*?)----(\d{18,})（\d+）\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)http(.*?)丨(.*?)----(\d{18,})----(\d{1,3}_\d{16,})(.*?)( \d{8} \d{6})(\（\d+\）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)http(.*?)----(.*?)\.(\w+)', "num": 0}
]
def x_rename_file(file_path,result):
    try:
        if os.path.isdir(file_path):
            return ''
        id = ''
        file_dir, file_name = os.path.split(file_path)
        
        for pattern in x_patterns:
            match_result = re.match(pattern["r"], file_name)
            if match_result:
                pattern["num"] += 1
                groups = match_result.groups()
                if len(groups) == 10 and groups[6].isdigit() and groups[8].isdigit():
                    id = groups[6]
                    timestamp = int(groups[8]) // 1000
                    formatted_time = time.strftime('%Y%m%d %H%M%S', time.localtime(timestamp))
                    file_type = get_file_type(file_path) or groups[-1]
                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨{groups[3]}----{groups[6]}--------{formatted_time}{groups[7]}.{file_type}"
                elif len(groups) == 8 and groups[4].isdigit() and re.match(r'^\s*(\d{8} \d{6})', groups[5]):
                    id = groups[4]
                    result['已存在'] += 1
                    
                elif len(groups) == 8 and groups[4].isdigit():
                    id = groups[4]
                    file_type = get_file_type(file_path) or groups[7]
                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨{groups[3]}----{groups[4]}--------{groups[5]}{groups[6]}.{file_type}"
                elif len(groups) == 9 and groups[4].isdigit():
                    id = groups[4]
                    date_format =r'^\s*(\d{8} \d{6})'
                    if re.match(date_format, groups[6]):
                        # 直接格式化为 'YYYYMMDD HHMMSS'
                        formatted_time = groups[6]
                        # result['已存在'] += 1

                        file_type = get_file_type(file_path) or groups[8]
                        new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨{groups[3]}----{groups[4]}----{groups[5]}----{groups[6]}{groups[7]}.{file_type}"
                    else:
                        timestamp = int(groups[6]) // 1000
                        formatted_time = time.strftime('%Y%m%d %H%M%S', time.localtime(timestamp))
                        file_type = get_file_type(file_path) or groups[8]
                        new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨----{groups[4]}--------{formatted_time}{groups[5]}.{file_type}"
                elif len(groups) == 6 and groups[4].isdigit():
                    id = groups[4]
                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨----{groups[4]}--------（1）.{groups[5]}"
                elif len(groups) == 6 and groups[3].isdigit():
                    id = groups[3]
                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨----{groups[3]}--------  {groups[4]}.{groups[5]}"
                elif len(groups) == 4:
                    id = groups[2]
                    new_file_name = f"{groups[0]}----{groups[1]}----丨----{groups[2]}--------（1）.{groups[3]}"
                elif len(groups) == 5:
                    id = groups[3]
                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨----{groups[3]}--------（1）.{groups[4]}"
                elif len(groups) == 7 and groups[6].isdigit():
                    id = groups[6]
                    file_type = get_file_type(file_path) or groups[-1]
                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨{groups[3]}----{groups[6]}--------{groups[5]}.{file_type}"
                elif len(groups) == 7 and groups[4].isdigit():
                    id = groups[4]
                    file_type = get_file_type(file_path) or groups[6]
                    if groups[3].isdigit():
                        new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨----{groups[4]}----{groups[3]}----  {groups[5]}.{file_type}"
                    else:
                        new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨{groups[3]}----{groups[4]}--------  {groups[5]}.{file_type}"
                elif len(groups) == 11:
                    id = groups[5]
                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}丨{groups[4]}----{groups[3]}----{groups[5]}----{groups[6]}----{groups[8]}{groups[9]}.{groups[10]}"
                else:
                    
                    result['失败'] += 1
                    continue
                if new_file_name==file_name:
                    result['已存在'] += 1
                    return id
                new_file_path = os.path.join(file_dir, new_file_name)
                if os.path.exists(new_file_path):
                    new_file_size = os.path.getsize(new_file_path)
                    old_file_size = os.path.getsize(file_path)
                    if abs(new_file_size - old_file_size) <= 100 * 1024:
                        os.remove(file_path)
                        print(f"文件 {file_path} 已删除，因为 {new_file_path} 已存在且大小相近。")
                    elif old_file_size > new_file_size + 100 * 1024:
                        os.remove(new_file_path)
                        print(f"文件 {new_file_path} 已删除，因为 {file_path} 大于 {new_file_path} 100KB。")
                    elif old_file_size < new_file_size - 100 * 1024:
                        os.remove(file_path)
                        print(f"文件 {file_path} 已删除，因为 {new_file_path} 大于 {file_path} 100KB。")
                    else:
                        print(f"文件 {new_file_path} 已存在。")
                        result['重复'] += 1
                    
                    if os.path.exists(new_file_path):
                        result['已存在'] += 1
                        return ''
                try:
                    os.rename(file_path, new_file_path)
                    with open('renamed_files.txt', 'a', encoding='utf-8') as log_file:
                        log_file.write(f"{file_path} -> {new_file_path}\n")
                    result['成功'] += 1
                except FileNotFoundError:
                    print(f"文件 {file_path} 未找到。")
                    result['失败'] += 1
                except PermissionError:
                    print(f"没有权限修改文件 {file_path}。")
                    result['失败'] += 1
                except OSError as e:
                    print(f"重命名文件时出现错误：{e}")
                    result['失败'] += 1
                return id
        if "----" in file_path:
            result['失败'] += 1
            print(f"文件 {file_path} 不符合命名规则。")
        return id
    except Exception as e:
        print(f"重命名文件 {file_path} 时出现错误：{e}")
        return ''
dy_patterns = [
    {"r": r'(.*?)----(.*?)----(.*?)----(.*?)----(\d{8}_\d{6})----(\d{18,})(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)----(.*?)----(\d{8} \d{6})----(\d{18,})(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)----(.*?)----(\d{4}-\d{2}-\d{2} \d{6})----(\d{18,})(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(\d{18,}.*?_评论.*?)----(.*?)----(?:uid)?(\w+)----(.*?)----(.*?)----(\d{8}_\d{6})----(\d{18,})(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)----(.*?)----(\d{4}-\d{2}-\d{2}_\d{6})----(\d{18,})(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)----(.*?)----(.*?)----(\d{18,})(（\d+）)\.(\w+)', "num": 0}
]
def dy_rename_file(file_path,result):
    try:
        if os.path.isdir(file_path):
            return ''
        id = ''
        file_dir, file_name = os.path.split(file_path)
        new_file_name=''
        for pattern in dy_patterns:
            match_result =  re.match(pattern["r"], file_name)
            if match_result:
                pattern["num"] += 1
                groups = match_result.groups()
                if len(groups) == 8 and groups[5].isdigit() :
                    id = groups[5]
                    file_type = get_file_type(file_path) or groups[-1]
                    发布时间=groups[4].replace(' ', '_').replace('-', '')
                    if 发布时间=='':
                        发布时间='19000101_000000' 
                        # 将元组转换为列表进行修改，然后重新赋值给groups变量
                        groups_list = list(groups)
                        groups_list[4] = 发布时间
                        groups = tuple(groups_list)
                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}----{groups[3]}----{发布时间}----{groups[5]}{groups[6]}.{file_type}"
                elif len(groups) != 8 :
                    print(f"文件名 {file_name} 不符合规则")
                else:
                    
                    result['失败'] += 1
                    continue
                if new_file_name==file_name:
                    result['已存在'] += 1
                    return new_file_name
                new_file_path = os.path.join(file_dir, new_file_name)
                if os.path.exists(new_file_path):
                    new_file_size = os.path.getsize(new_file_path)
                    old_file_size = os.path.getsize(file_path)
                    if abs(new_file_size - old_file_size) <= 100 * 1024:
                        os.remove(file_path)
                        print(f"文件 {file_path} 已删除，因为 {new_file_path} 已存在且大小相近。")
                    elif old_file_size > new_file_size + 100 * 1024:
                        os.remove(new_file_path)
                        print(f"文件 {new_file_path} 已删除，因为 {file_path} 大于 {new_file_path} 100KB。")
                    elif old_file_size < new_file_size - 100 * 1024:
                        os.remove(file_path)
                        print(f"文件 {file_path} 已删除，因为 {new_file_path} 大于 {file_path} 100KB。")
                    else:
                        print(f"文件 {new_file_path} 已存在。")
                        result['重复'] += 1
                    
                    if os.path.exists(new_file_path):
                        result['已存在'] += 1
                        return new_file_name
                try:
                    os.rename(file_path, new_file_path)
                    with open('renamed_files.txt', 'a', encoding='utf-8') as log_file:
                        log_file.write(f"{file_path} -> {new_file_path}\n")
                    result['成功'] += 1
                    return new_file_name
                except FileNotFoundError:
                    print(f"文件 {file_path} 未找到。")
                    result['失败'] += 1
                except PermissionError:
                    print(f"没有权限修改文件 {file_path}。")
                    result['失败'] += 1
                except OSError as e:
                    print(f"重命名文件时出现错误：{e}")
                    result['失败'] += 1
                return id
        if "----" in file_path:
            result['失败'] += 1
            print(f"文件 {file_path} 不符合命名规则。")
        return id
    except Exception as e:
        result['失败'] += 1
        print(f"重命名文件 {file_path} 时出现错误：{e}")
        return ''
xy_patterns = [
    {"r": r'(.*?)_(\d+)----(原价.*?)----(.*?)----(\d{8}_\d{6})?([\u4e00-\u9fa5]+)?----(.*?)----(\d+)(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)_(\d+)----(原价.*?)----(.*?)----(.*?)----(.*?)----(\d+)(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(.*?)----(.*?)----(\d{4}-\d{2}-\d{2} \d{2} \d{2} \d{2})?([\u4e00-\u9fa5]+)?----(.*?)----(\d+)(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(原价.*?)----(.*?)----(\d{4}-\d{2}-\d{2} \d{2}\d{2}\d{2})?([\u4e00-\u9fa5]+)?----(\d+)(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(原价.*?)----(.*?)----(\d{4}-\d{2}-\d{2} \d{2}\d{2}\d{2})?([\u4e00-\u9fa5]+)?----(.*?)----(\d+)(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(原价.*?)----(.*?)----(\d{4}\d{2}\d{2}_\d{2}\d{2}\d{2})?([\u4e00-\u9fa5]+)?----(.*?)----(\d+)(（\d+）)\.(\w+)', "num": 0},
    {"r": r'(.*?)----(原价.*?)----(.*?)----(\d{4}\d{2}\d{2}_\d{2}\d{2}\d{2})?([\u4e00-\u9fa5]+)?----(\d+)(（\d+）)\.(\w+)', "num": 0}
]
tb_patterns = [
    {"r": r'(.*?)----(\w+)?----(.*?)----(.*?)----([\u4e00-\u9fa5]+)?_(\d{4}-\d{2}-\d{2} \d{4,6})?----(\w+)?\.(\w+)?', "num": 0},
    {"r": r'(.*?)----(\w+)?----(.*?)----(.*?)----([\u4e00-\u9fa5]+)?_(\d{4}\d{2}\d{2}_\d{4,6})?----(\w+)?\.(\w+)?', "num": 0},

]
xhs_patterns = [
    {"r": r'([A-Z]:\\[^ ]+)?(.*?)----(\w{18,})----(.*?)----(\w{18,})(----(.*?))?----(\d{1,4}.*?\d{1,2}.*?\d{1,2}.*?\d{1,2}\s*\d{1,2}\s*\d{1,2}).*?([\u4e00-\u9fa5]+)?(（\d+）)?\.(\w+)', "num": 0},
    {"r": r'([A-Z]:\\[^ ]+)?(.*?)-(\w{24})-(.*?)----(\w{24})----(.*?)----(\d{4}.*?\d{1,2}.*?\d{1,2}.*?\d{1,6}).*?([\u4e00-\u9fa5]+)?(（\d+）)?\.(\w+)', "num": 0},
    {"r": r'([A-Z]:\\[^ ]+)?(.*?)----(\w{18,})----(.*?)----(\w{18,})----(.*?)----(\d{1,4}\d{1,2}\d{1,2}.*?\d{1,2}\s*\d{1,2}\s*\d{1,2})\s*(（\d+）)\.(\w+)', "num": 0},
    {"r": r'([A-Z]:\\[^ ]+)?(.*?)----(\w{18,})----(.*?)----(\w{18,})----(\w{32,})----(\d{4}-\d{1,2}-\d{1,2}_\d{1,6})_([\u4e00-\u9fa5]+)?\.(\w+)', "num": 0},
]
def xy_rename_file(file_path,result):
    try:
        if os.path.isdir(file_path):
            return ''
        id = ''
        file_dir, file_name = os.path.split(file_path)
        
        for pattern in dy_patterns:
            match_result =  re.match(pattern["r"], file_name)
            if match_result:
                pattern["num"] += 1
                groups = match_result.groups()
                if len(groups) == 8 and groups[5].isdigit() :
                    id = groups[5]
                    file_type = get_file_type(file_path) or groups[-1]
                    发布时间=groups[4].replace(' ', '_').replace('-', '')

                    new_file_name = f"{groups[0]}----{groups[1]}----{groups[2]}----{groups[3]}----{发布时间}----{groups[5]}{groups[6]}.{file_type}"
                elif len(groups) != 8 :
                    print(f"文件名 {file_name} 不符合规则")
                else:
                    
                    result['失败'] += 1
                    continue
                if new_file_name==file_name:
                    result['已存在'] += 1
                    return new_file_name
                new_file_path = os.path.join(file_dir, new_file_name)
                if os.path.exists(new_file_path):
                    new_file_size = os.path.getsize(new_file_path)
                    old_file_size = os.path.getsize(file_path)
                    if abs(new_file_size - old_file_size) <= 100 * 1024:
                        os.remove(file_path)
                        print(f"文件 {file_path} 已删除，因为 {new_file_path} 已存在且大小相近。")
                    elif old_file_size > new_file_size + 100 * 1024:
                        os.remove(new_file_path)
                        print(f"文件 {new_file_path} 已删除，因为 {file_path} 大于 {new_file_path} 100KB。")
                    elif old_file_size < new_file_size - 100 * 1024:
                        os.remove(file_path)
                        print(f"文件 {file_path} 已删除，因为 {new_file_path} 大于 {file_path} 100KB。")
                    else:
                        print(f"文件 {new_file_path} 已存在。")
                        result['重复'] += 1
                    
                    if os.path.exists(new_file_path):
                        result['已存在'] += 1
                        return new_file_name
                try:
                    os.rename(file_path, new_file_path)
                    with open('renamed_files.txt', 'a', encoding='utf-8') as log_file:
                        log_file.write(f"{file_path} -> {new_file_path}\n")
                    result['成功'] += 1
                    return new_file_name
                except FileNotFoundError:
                    print(f"文件 {file_path} 未找到。")
                    result['失败'] += 1
                except PermissionError:
                    print(f"没有权限修改文件 {file_path}。")
                    result['失败'] += 1
                except OSError as e:
                    print(f"重命名文件时出现错误：{e}")
                    result['失败'] += 1
                return id
        if "----" in file_path:
            result['失败'] += 1
            print(f"文件 {file_path} 不符合命名规则。")
        return id
    except Exception as e:
        result['失败'] += 1
        print(f"重命名文件 {file_path} 时出现错误：{e}")
        return ''

def file_info(file,文件格式='',log_event=None,item=None):
    try:
        分辨率,文件md5 = '',''
        if not item:
            fsize = os.path.getsize(file)
            文件大小 = f"{fsize / (1024 * 1024):.2f}MB"  # 转换为MB
            下载时间 = get_file_creation_time(file)

            下载时间_str=下载时间['datetime_str']
            下载时间= 下载时间['datetime_obj']
        else:
            
            fsize = item['size']
            文件大小 = 字节到比特(fsize)
            
            下载时间 = item['date_modified']
            下载时间_str=下载时间.strftime('%Y-%m-%d %H:%M:%S')
            下载时间_str2=下载时间.strftime('%Y%m%d_%H%M%S')
        文件md5 = get_file_md5(file)
        if 文件格式:
            if 文件格式.lower() in ['.mp4', '.avi', '.mov', '.mkv']:
                # 获取视频分辨率
                分辨率=get_video_resolution(file)
            elif 文件格式.lower() in ['.jpg', '.jpeg', '.png', '.bmp']:
                # 获取图片分辨率
                分辨率 = get_image_resolution(file)
            else:
                分辨率 = "未知"
        return {
            "fsize": fsize,
            "文件大小": 文件大小,
            "文件格式": 文件格式,
            "下载时间": 下载时间,
            "下载时间_str": 下载时间_str,
            "文件md5": 文件md5,
            "分辨率": 分辨率
        }
    except Exception as e:
        if log_event:
            log_event.error(f"Error occurred while getting file info: {e}")
        else:
            print(f"Error occurred while getting file info: {e}")
        return ''
def convert_method1(value):
    match = re.match(r"(\d+)(GB|MB|KB)", value)
    num, unit = int(match.group(1)), match.group(2)
    units = {'GB': 1024**3, 'MB': 1024**2, 'KB': 1024}
    return num * units[unit]


def convert_method2(value):
    num, unit = int(value[:-2]), value[-2:]
    units = {'GB': 1024**3, 'MB': 1024**2, 'KB': 1024}
    return num * units[unit]


def convert_method3(value):
    num = int(value[:-2])
    unit = value[-2:]
    unit_dict = {'GB': 1024**3, 'MB': 1024**2, 'KB': 1024}
    return num * unit_dict[unit]

def convert_method4(value):
    num, unit = value[:-2], value[-2:]
    return int(num) * {'GB': 1024**3, 'MB': 1024**2, 'KB': 1024}[unit]
def 字节到比特(bytes_count):
    return f"{round((bytes_count / (1024 * 1024)), 3)}MB"
def 比特到字节(value):
    num = int(value[:-2].replace(' ', ''))
    unit = value[-2:]
    if unit == 'GB':
        return num * 1024**3
    elif unit == 'MB':
        return num * 1024**2
    elif unit == 'KB':
        return num * 1024
def get_image_resolution(file_path):
    try:
        with Image.open(file_path) as img:
            width, height = img.size
            分辨率 = f"{width}x{height}"
    except Exception as e:
        分辨率 = ""
    return 分辨率
def get_video_resolution(file_path):
    try:
        video = cv2.VideoCapture(file_path)
        width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
        分辨率 = f"{width}x{height}"
        video.release()
    except Exception as e:
        分辨率 = ""
        print(f"获取视频分辨率时出错: {e}_{file_path}")

    return 分辨率
def get_filetime(full_path):
    return datetime.datetime.fromtimestamp(int(os.path.getctime(full_path))).strftime("%Y-%m-%d %H:%M:%S")
def load_data_open(file_path):
    """加载并解析数据文件"""
    data = []
    try:
        start_time = time.time()
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                fields = [field.strip() for field in line.split('\t')]
                if len(fields) >= 14:  # 根据你的数据调整验证条件
                    data.append(fields)
        end_time = time.time()
        print(f"文件加载用时: {end_time - start_time:.2f} 秒")
    except Exception as e:
        pass
    return data
def load_data(file_path):
    """加载并解析数据文件"""
    data = []
    try:
        start_time = time.time()
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f, delimiter='\t')  # 指定tab分隔符
            for line in reader:
                if len(line) >= 14:  # 根据你的数据调整验证条件
                    data.append(line)
        end_time = time.time()
        print(f"文件加载用时: {end_time - start_time:.2f} 秒")
    except Exception as e:
        print(f"加载数据时出错: {e}")
    return data
# class douyin_process():
def test_string_replace(input_string):
    # 1. 先去除所有单引号和双引号
    result = input_string.replace("'", "").replace('"', "")
    # 2. 将 ][ 替换为 /（统一分隔符）
    result = result.replace("][", "/")
    # 3. 去掉首尾的 [ 和 ]
    result = result.strip("[]")
    # 4. 按 / 分割
    return result.split("/")
# 自定义访问方法：通过路径字符串逐层访问

def 时间戳格式化(timestamp, format_type):
    # 将时间戳转换为datetime对象
    dt_object = datetime.datetime.fromtimestamp(timestamp)
    
    # 格式化字符串变量
    formatted_time = ""
    
    # 根据格式类型选择返回格式
    if format_type == 1:
        formatted_time = dt_object.strftime('%Y-%m-%d %H:%M:%S').replace('-0', '-').replace(':0', ':')
    elif format_type == 2:
        formatted_time = dt_object.strftime('%Y-%m-%d %H:%M:%S')
    elif format_type == 3:
        formatted_time = dt_object.strftime('%Y年%m月%d日 %H:%M:%S').replace('-0', '年').replace(':0', '日')
    elif format_type == 4:
        formatted_time = dt_object.strftime('%Y年%m月%d日 %H:%M:%S')
    elif format_type == 5:
        formatted_time = dt_object.strftime('%Y%m%d %H%M%S')
    elif format_type == 6:
        formatted_time = dt_object.strftime('%Y%m%d_%H%M%S')
    else:
        raise ValueError("Invalid format type. Please use an integer between 1 and 6.")
    
    # 返回不同的数据类型
    return {
        'formatted_str': formatted_time,           # 返回格式化后的字符串
        'formatted_obj': dt_object,                 # 返回datetime对象
        'timestamp': timestamp                      # 返回原始时间戳
    }

def is_mobile_device(request):
    """检测是否为手机端设备"""
    user_agent = request.headers.get('User-Agent', '').lower()
    mobile_keywords = [
        'mobile', 'android', 'iphone', 'ipad', 'ipod', 'blackberry', 
        'iemobile', 'opera mini', 'windows phone', 'webos', 'kindle'
    ]
    return any(keyword in user_agent for keyword in mobile_keywords)

def split_path_clean(path_segment):
    """辅助函数：按.分割单个路径段，清理空值、空格、多余的点"""
    if not path_segment:
        return []
    # 替换连续的.为单个. → 清理首尾. → 按.分割 → 过滤空值/空格
    cleaned = re.sub(r'\.+', '.', path_segment.strip()).strip('.')
    return [part.strip() for part in cleaned.split('.') if part.strip()]
def parse_path_keys(path):
    """
    终极版：完整解析所有风格路径，包括中括号/点/斜杠分隔的内容
    支持的路径格式：
    - data.items[0].originalPrice → ["data", "items", "0", "originalPrice"]
    - ['user_list']['asd'][0] → ["user_list", "asd", "0"]
    - user_list/asd/[0] → ["user_list", "asd", "0"]
    """
    if not isinstance(path, str) or path.strip() == "":
        return []
    
    # 步骤1：预处理 - 统一格式（处理['xxx']→[xxx]，去掉单双引号）
    processed_path = path.strip()
    # 去掉所有单双引号（处理['user_list']→[user_list]）
    processed_path = re.sub(r'["\']', '', processed_path)
    # 处理连续的/，去掉首尾/，并将/转为.（兼容原有逻辑）
    processed_path = re.sub(r'/+', '/', processed_path).strip('/').replace('/', '.')
    # 处理[]和.的衔接（比如user_list.[0]→user_list[0]，[0].asd→[0]asd）
    processed_path = re.sub(r'\.\[', '[', processed_path)
    processed_path = re.sub(r'\]\.', ']', processed_path)
    
    # 步骤2：拆分路径为「中括号段」和「普通段」（适配['xxx']风格）
    # 正则优化：匹配 [xxx] 格式的块，或非[]的普通块
    path_blocks = re.findall(r'(\[.+?\])|([^\[\]]+)', processed_path)
    
    # 步骤3：遍历所有块，逐段解析
    keys = []
    for bracket_block, normal_block in path_blocks:
        if bracket_block:  # 处理中括号块（如[user_list]、[asd]、[0]）
            # 提取中括号内的内容（去掉[]）
            inner = bracket_block.strip('[]').strip()
            if inner:
                keys.append(inner)
        elif normal_block:  # 处理普通块（如data.items、user_list等）
            normal_keys = split_path_clean(normal_block)
            keys.extend(normal_keys)
    
    return keys

def 取文本(data, path, default=''):
    return get_nested_value(data, path, default=default)
def get_nested_value(data, path, default=''):
    # 将路径字符串分割成各个部分
    keys = parse_path_keys(path)
    
    # keys = path.split(".")
    result = data
    for key in keys:
        if isinstance(result, list):
            # 处理列表的索引
            try:
                key = int(key)
                result = result[key]
            except (ValueError, IndexError):
                return default
        elif isinstance(result, dict):
            result = result.get(key, default)
        else:
            return default

        # 如果 result 是 None，直接退出循环
        if result is default:
            break
    
    return result
# def split_path_clean(path):
#     """拆分路径并返回无空值的层级列表（跨平台）"""
#     normal_path = os.path.normpath(path)
#     return [p for p in normal_path.split(os.sep) if p]
def 寻找键值(data,
          target_key, # 目标键名
          find_first=False, # 是否只返回第一个匹配项
          current_only=False, # 是否只返回当前层级的匹配项
          fuzzy_match=False, # 是否开启模糊匹配
          ):
    """
    广度优先遍历嵌套的字典/列表结构，查找指定键名的匹配项（路径分隔符为/，避免与键名中的.冲突）
    支持精确匹配和模糊匹配
    """
    # 检查输入参数
    if not target_key:
        raise ValueError("目标键名不能为空")
    
    result = []
    queue = deque()
    if isinstance(data, (dict, list)):
        queue.append((data, [], ""))  # 根节点：数据、路径数组、路径字符串
    else:
        return result
    
    while queue:
        current_data, current_path_parts, parent_path_str = queue.popleft()
        
        # 处理字典类型
        if isinstance(current_data, dict):
            for key, value in current_data.items():
                # 构建新的路径数组和路径字符串
                new_path_parts = current_path_parts + [key]
                if parent_path_str == "":
                    new_path_str = key
                else:
                    new_path_str = f"{parent_path_str}/{key}"
                
                # 检查是否匹配目标键名
                is_match = False
                if fuzzy_match:
                    # 模糊匹配：检查目标键名是否包含在键名中
                    is_match = target_key in key
                else:
                    # 精确匹配
                    is_match = key == target_key
                
                if is_match:
                    if current_only:
                        # 只返回当前路径信息，不append到结果列表
                        return {
                            "path_parts": new_path_parts,  # 完整路径数组
                            "key": key,
                            "value": value,
                            "path": parent_path_str,  # 父路径字符串
                            "current_full_path": new_path_str  # 当前完整路径字符串
                        }
                    else:
                        result.append({
                            "path_parts": new_path_parts,  # 完整路径数组
                            "key": key,
                            "value": value,
                            "path": parent_path_str,  # 父路径字符串
                            "current_full_path": new_path_str  # 当前完整路径字符串
                        })
                        if find_first:
                            return result
                
                # 处理嵌套容器
                if isinstance(value, (dict, list)):
                    queue.append((value, new_path_parts, new_path_str))
        
        # 处理列表类型
        elif isinstance(current_data, list):
            for idx, item in enumerate(current_data):
                # 构建新的路径数组和路径字符串
                new_path_parts = current_path_parts + [idx]  # 列表索引为数字类型
                if parent_path_str == "":
                    new_path_str = f"[{idx}]"
                else:
                    new_path_str = f"{parent_path_str}[{idx}]"
                
                # 处理嵌套容器
                if isinstance(item, (dict, list)):
                    queue.append((item, new_path_parts, new_path_str))
    
    if current_only:
        # 如果没有找到匹配项，返回空字典
        return {}
    return result

def 寻找键值_递归(data, target_key, find_first=False, current_only=False, fuzzy_match=False, path_parts=None, parent_path=""):
    """
    递归版本，支持精确匹配和模糊匹配
    """
    # 检查输入参数
    if not target_key:
        raise ValueError("目标键名不能为空")
    
    if path_parts is None:
        path_parts = []
    
    result = []
    
    if isinstance(data, dict):
        for key, value in data.items():
            current_path = path_parts + [key]
            current_full_path = parent_path + ("/" if parent_path else "") + key
            
            # 检查是否匹配目标键名
            is_match = False
            if fuzzy_match:
                # 模糊匹配：检查目标键名是否包含在键名中
                is_match = target_key in key
            else:
                # 精确匹配
                is_match = key == target_key
            
            if is_match:
                if current_only:
                    return {
                        "path_parts": current_path,
                        "key": key,
                        "value": value,
                        "path": parent_path,
                        "current_full_path": current_full_path
                    }
                else:
                    result.append({
                        "path_parts": current_path,
                        "key": key,
                        "value": value,
                        "path": parent_path,
                        "current_full_path": current_full_path
                    })
                    if find_first:
                        return result
            
            # 递归处理嵌套结构
            if isinstance(value, (dict, list)):
                sub_result = 寻找键值_递归(
                    value, target_key, find_first, current_only, fuzzy_match,
                    current_path, current_full_path
                )
                if current_only and sub_result:
                    return sub_result
                if find_first and sub_result:
                    return sub_result
                result.extend(sub_result)
    
    elif isinstance(data, list):
        for idx, item in enumerate(data):
            current_path = path_parts + [idx]
            current_full_path = parent_path + f"[{idx}]"
            
            if isinstance(item, (dict, list)):
                sub_result = 寻找键值_递归(
                    item, target_key, find_first, current_only, fuzzy_match,
                    current_path, current_full_path
                )
                if current_only and sub_result:
                    return sub_result
                if find_first and sub_result:
                    return sub_result
                result.extend(sub_result)
    
    if current_only:
        return {}
    return result

def 智能寻找键值(data, chinese_key, fuzzy_key=None):
    """
    智能查找键值：先尝试精确匹配中文键名，如果为空则尝试模糊匹配，如果都为空则返回错误
    """
    # 检查chinese_key是否为空
    if not chinese_key:
        # 如果chinese_key为空，尝试使用模糊键名
        if not fuzzy_key:
            raise ValueError("中文键名和模糊键名都不能为空")
        
        # 使用模糊匹配
        result = 寻找键值(data, fuzzy_key, fuzzy_match=True)
        if not result:
            raise ValueError(f"未找到包含'{fuzzy_key}'的键名")
        return result
    
    # 先尝试精确匹配
    result = 寻找键值(data, chinese_key, fuzzy_match=False)
    if result:
        return result
    
    # 如果精确匹配失败，尝试模糊匹配
    if fuzzy_key:
        result = 寻找键值(data, fuzzy_key, fuzzy_match=True)
        if result:
            return result
    
    # 如果都找不到，返回错误
    error_msg = f"未找到键名'{chinese_key}'"
    if fuzzy_key:
        error_msg += f"或包含'{fuzzy_key}'的键名"
    raise ValueError(error_msg)

def format_time(time_str,f=''):
    match = re.match(r'^(\d{4})-(\d{2})-(\d{2}) (\d{2})[:]?(\d{2})$', time_str)
    if match:
        # 提取各部分时间
        year, month, day, hour, minute = match.groups()
        # 秒如果不存在则补00
        second = '00'
        # 拼接成目标格式（注意这里你示例的"2025111_"可能是笔误，应为"20251112_"）
        return f"{year}-{month}-{day} {hour}:{minute}:{second}"
    # 匹配 "YYYY-MM-DD HH:MM" 或 "YYYY-MM-DD HH:MM:SS" 格式
    match = re.match(r'^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})(?::(\d{2}))?$', time_str)
    if match:
        # 提取各部分时间
        year, month, day, hour, minute, second = match.groups()
        # 秒如果不存在则补00
        second = second or '00'
        # 拼接成目标格式（注意这里你示例的"2025111_"可能是笔误，应为"20251112_"）
        return f"{year}-{month}-{day} {hour}:{minute}:{second}"
    
    else: 
        match = re.match(r'^(\d{4})-(\d{2})-(\d{2}) (\d{2})[:]?(\d{2})$', time_str)
        if match:
            # 提取各部分时间
            year, month, day, hour, minute = match.groups()
            # 秒如果不存在则补00
            second = '00'
            # 拼接成目标格式（注意这里你示例的"2025111_"可能是笔误，应为"20251112_"）
            return f"{year}-{month}-{day} {hour}:{minute}:{second}"
        else: 
            match = re.match(r'^(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})$', time_str)
            if match:
                # 提取各部分时间
                year, month, day, hour, minute, second = match.groups()
                # 秒如果不存在则补00
                second = '00'
                # 拼接成目标格式（注意这里你示例的"2025111_"可能是笔误，应为"20251112_"）
                return f"{year}-{month}-{day} {hour}:{minute}:{second}"
    # 不匹配则返回原字符串
    return time_str

CUSTOM_METADATA_KEY = "UserCustomMetadata"
META_EXT = ".meta"  # 外置元数据文件
# ==============================================================================
# 【1】图片 自定义元数据（仅操作你的私有数据，原生EXIF完全不动）
# ==============================================================================
def write_image_metadata(file_path, metadata_dict):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在：{file_path}")
    ext = file_path.lower()
    if not ext.endswith(('.jpg', '.jpeg', '.png', '.webp')):
        raise ValueError("仅支持 JPG/PNG/WebP 图片")

    try:
        img = Image.open(file_path)
        exif_dict = piexif.load(img.info.get("exif", b""))

        # 仅写入【你的自定义数据】，原生EXIF标签完全保留
        custom_data_str = base64.b64encode(str(metadata_dict).encode("utf-8")).decode("utf-8")
        exif_dict["Exif"][piexif.ExifIFD.UserComment] = f"[{CUSTOM_METADATA_KEY}]{custom_data_str}".encode("utf-8")

        # 保存（只更新自定义数据）
        exif_bytes = piexif.dump(exif_dict)
        img.save(file_path, exif=exif_bytes)
        return True
    except Exception as e:
        raise Exception(f"图片自定义元数据写入失败：{str(e)}")

def read_image_metadata(file_path):
    """只读取你自定义的元数据，原生EXIF不返回、不修改"""
    img = Image.open(file_path)
    try:
        exif_dict = piexif.load(img.info.get("exif", b""))
        comment = exif_dict["Exif"].get(piexif.ExifIFD.UserComment, b"").decode("utf-8", errors="ignore")

        if comment.startswith(f"[{CUSTOM_METADATA_KEY}]"):
            data_b64 = comment.replace(f"[{CUSTOM_METADATA_KEY}]", "")
            data_str = base64.b64decode(data_b64).decode("utf-8")
            return eval(data_str)  # 安全：仅解析你自己写入的数据
    except:
        pass
    return {}

def clear_image_metadata(file_path):
    """只清除【你自定义的元数据】，原生EXIF 100%保留"""
    try:
        img = Image.open(file_path)
        exif_dict = piexif.load(img.info.get("exif", b""))

        # 只删除自定义数据
        if piexif.ExifIFD.UserComment in exif_dict["Exif"]:
            del exif_dict["Exif"][piexif.ExifIFD.UserComment]

        exif_bytes = piexif.dump(exif_dict)
        img.save(file_path, exif=exif_bytes)
    except:
        pass

# ==============================================================================
# 【2】MP4 自定义元数据（仅操作你的私有数据，原生标签不动）
# ==============================================================================
def read_mp4_metadata(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在：{file_path}")
    if not file_path.lower().endswith(('.mp4', '.m4v', '.mov')):
        raise ValueError("仅支持MP4/M4V/MOV格式")

    try:
        mp4 = MP4(file_path)
        tag = f"----:com.apple.iTunes:{CUSTOM_METADATA_KEY}"
        if tag in mp4 and mp4[tag]:
            data_str = mp4[tag][0]
            return eval(data_str)
    except:
        pass
    return {}



# 你自己的自定义 key（保持不变）
CUSTOM_METADATA_KEY = "MyCustomData"

def write_mp4_metadata(file_path, metadata_dict, set_readonly_after=False):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在：{file_path}")
    if not file_path.lower().endswith(('.mp4', '.m4v', '.mov')):
        raise ValueError("仅支持MP4/M4V/MOV格式")

    try:
        os.chmod(file_path, stat.S_IWRITE)
        mp4 = MP4(file_path)

        # 关键修复：把字典转字符串 → 再 encode 成 bytes
        tag = f"----:com.apple.iTunes:{CUSTOM_METADATA_KEY}"
        data_str = str(metadata_dict)
        data_bytes = data_str.encode("utf-8")  # 这一步解决报错
        
        mp4[tag] = [data_bytes]  # 写入 bytes
        mp4.save()

        if set_readonly_after:
            os.chmod(file_path, stat.S_IREAD)
        return True

    except PermissionError:
        raise PermissionError("权限不足，请关闭播放器")
    except Exception as e:
        raise Exception(f"写入MP4失败：{str(e)}")

def clear_mp4_metadata(file_path):
    """只清除视频自定义数据，原生标签不动"""
    try:
        mp4 = MP4(file_path)
        tag = f"----:com.apple.iTunes:{CUSTOM_METADATA_KEY}"
        if tag in mp4:
            del mp4[tag]
            mp4.save()
    except:
        pass

# ==============================================================================
# 【3】通用尾部隐藏数据（不变）
# ==============================================================================
def append_data_to_any_file(file_path, custom_data, encode_base64=True):
    if not os.path.exists(file_path):
        raise FileNotFoundError("文件不存在")
    if isinstance(custom_data, dict):
        data_str = str(custom_data).encode("utf-8")
    else:
        data_str = str(custom_data).encode("utf-8")
    if encode_base64:
        data_str = base64.b64encode(data_str)
    tail = b"\n###MY_DATA###" + data_str + b"###END###\n"
    with open(file_path, "a+b") as f:
        f.write(tail)
    return True

def read_hidden_data_from_file(file_path, decode_base64=True):
    if not os.path.exists(file_path):
        raise FileNotFoundError("文件不存在")
    with open(file_path, "rb") as f:
        try:
            f.seek(-10240, 2)
        except:
            f.seek(0)
        tail = f.read()
    start, end = b"###MY_DATA###", b"###END###"
    if start in tail and end in tail:
        data = tail.split(start)[1].split(end)[0]
        if decode_base64:
            data = base64.b64decode(data).decode("utf-8")
        return data
    return "未找到隐藏数据"

# ==============================================================================
# 🔥 核心智能入口（调用方式完全不变）
# ==============================================================================
def file_metadata(file_path, action="read", metadata=None, readonly=False, modify_file=False):
    """
    🔥 关键参数：modify_file
    False = 不修改原文件，哈希不变（默认推荐）
    True  = 直接修改图片EXIF，哈希会变
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError("文件不存在")

    # ======================
    # 外置模式（不碰原图）
    # ======================
    if not modify_file:
        if action == "read":
            return read_external_metadata(file_path)
        elif action == "write":
            return write_external_metadata(file_path, metadata)
        elif action == "clear":
            return clear_external_metadata(file_path)

    # ======================
    # 如果你一定要修改文件本身（哈希会变）
    # 下面是你原来的代码，完全不变
    # ======================
    ext = file_path.lower()
    is_image = ext.endswith(('.jpg', '.jpeg', '.png', '.webp'))
    is_video = ext.endswith(('.mp4', '.m4v', '.mov'))

    if action == "read":
        if is_image:
            return read_image_metadata(file_path)
        elif is_video:
            return read_mp4_metadata(file_path)
    elif action == "write":
        if is_image:
            return write_image_metadata(file_path, metadata)
        elif is_video:
            return write_mp4_metadata(file_path, metadata, readonly)
    elif action == "clear":
        if is_image:
            clear_image_metadata(file_path)
        elif is_video:
            clear_mp4_metadata(file_path)
        return True

    raise ValueError(f"不支持的操作：{action}")
def _get_meta_file(file_path):
    """获取对应元数据文件路径"""
    return file_path + META_EXT

def write_external_metadata(file_path, metadata_dict):
    """写入外置元数据 → 不修改原文件 → 哈希不变"""
    meta_file = _get_meta_file(file_path)
    with open(meta_file, 'w', encoding='utf-8') as f:
        json.dump(metadata_dict, f, ensure_ascii=False, indent=2)
    return True

def read_external_metadata(file_path):
    """读取外置元数据 → 原文件完全不动"""
    meta_file = _get_meta_file(file_path)
    if os.path.exists(meta_file):
        with open(meta_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}

def clear_external_metadata(file_path):
    """清除外置元数据 → 原文件完全不动"""
    meta_file = _get_meta_file(file_path)
    if os.path.exists(meta_file):
        os.remove(meta_file)
    return True

def calculate_file_hash(file_path, hash_algorithm='sha256', chunk_size=8192):
    """
    计算文件的哈希值，支持指定哈希算法
    
    Args:
        file_path: 文件路径
        hash_algorithm: 哈希算法，默认sha256（可选md5/sha1/sha512等）
        chunk_size: 读取文件的块大小，平衡内存占用和效率
    
    Returns:
        哈希值的十六进制字符串
    """
    # 验证文件是否存在
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    # 验证文件是否可读
    if not os.access(file_path, os.R_OK):
        raise PermissionError(f"无读取权限: {file_path}")
    
    # 创建哈希对象
    try:
        hash_obj = hashlib.new(hash_algorithm)
    except ValueError:
        raise ValueError(f"不支持的哈希算法: {hash_algorithm}")
    
    # 分块读取文件并更新哈希（避免大文件占用过多内存）
    with open(file_path, 'rb') as f:
        while chunk := f.read(chunk_size):
            hash_obj.update(chunk)
    
    return hash_obj.hexdigest()

def calculate_partial_hash(file_path, part='front', size=1024*1024, hash_algorithm='sha256'):
    """
    计算文件指定部分的哈希（前1MB/后1MB）
    
    Args:
        file_path: 文件路径
        part: 'front'（前1MB）/'back'（后1MB）
        size: 要读取的字节数，默认1MB（1024*1024）
        hash_algorithm: 哈希算法
    
    Returns:
        对应部分的哈希值十六进制字符串
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")
    
    file_size = os.path.getsize(file_path)
    hash_obj = hashlib.new(hash_algorithm)
    
    with open(file_path, 'rb') as f:
        if part == 'front':
            # 读取前size字节（如果文件小于size，就读全部）
            read_size = min(size, file_size)
            data = f.read(read_size)
        elif part == 'back':
            # 读取后size字节（如果文件小于size，就读全部）
            if file_size <= size:
                f.seek(0)
                data = f.read()
            else:
                f.seek(file_size - size)
                data = f.read(size)
        else:
            raise ValueError("part参数只能是'front'或'back'")
        
        hash_obj.update(data)
    
    return hash_obj.hexdigest()

def append_data_to_mp4_tail(file_path, custom_data, encode_base64=True):
    """
    在MP4文件尾部追加自定义数据（片尾位置，规避检测）
    Args:
        file_path: MP4文件路径
        custom_data: 要追加的自定义数据（字典/字符串/数字均可）
        encode_base64: 是否Base64编码（避免特殊字符破坏文件结构，推荐True）
    Returns:
        bool: 追加成功返回True
    """
    # 1. 基础校验（确保文件是MP4且存在）
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在：{file_path}")
    if not file_path.lower().endswith('.mp4'):
        raise ValueError("仅支持MP4文件")
    
    # 2. 处理自定义数据（转字符串+可选Base64编码）
    if isinstance(custom_data, dict):
        # 字典转字符串（方便解析）
        data_str = str(custom_data).encode('utf-8')
    else:
        data_str = str(custom_data).encode('utf-8')
    
    # Base64编码（避免特殊字符导致播放器识别异常）
    if encode_base64:
        data_str = base64.b64encode(data_str)
    
    # 3. 关键：在文件尾部追加数据（以特定标识开头，方便后续读取）
    # 加自定义标识（如"###CUSTOM_DATA###"），方便后续识别和提取
    tail_data = b"\n###CUSTOM_DATA###" + data_str + b"###END###\n"
    
    try:
        # 以"追加模式"打开文件（a+b：二进制追加，不修改原有内容）
        with open(file_path, 'a+b') as f:
            f.seek(0, 2)  # 定位到文件末尾（2=SEEK_END）
            f.write(tail_data)
        
        print(f"✅ 自定义数据已追加到MP4片尾：{file_path}")
        print(f"追加数据大小：{len(tail_data)} 字节")
        return True
    
    except PermissionError:
        raise RuntimeError("权限不足！请关闭占用文件的程序（如播放器）")
    except Exception as e:
        raise RuntimeError(f"追加失败：{str(e)}")

def read_tail_data_from_mp4(file_path, decode_base64=True):
    """
    读取MP4文件尾部追加的自定义数据（配套上面的追加函数）
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在：{file_path}")
    
    # 读取文件末尾的内容（取最后10240字节，足够容纳自定义数据）
    read_size = 10240
    with open(file_path, 'rb') as f:
        f.seek(-read_size, 2)  # 从末尾往前定位
        tail_content = f.read(read_size)
    
    # 提取自定义数据（按标识分割）
    start_flag = b"###CUSTOM_DATA###"
    end_flag = b"###END###"
    if start_flag in tail_content and end_flag in tail_content:
        # 截取标识之间的内容
        data = tail_content.split(start_flag)[1].split(end_flag)[0]
        # 解码Base64
        if decode_base64:
            data = base64.b64decode(data).decode('utf-8')
        return data
    else:
        return "未找到自定义尾部数据"
    
def 文件哈希计算(target_file):
        front_1m_sha256 = calculate_partial_hash(target_file, part='front', size=1024*1024)
        # 2. 计算后1MB SHA256 哈希
        back_1m_sha256 = calculate_partial_hash(target_file, part='back', size=1024*1024)
        # 3. 计算完整文件的 SHA256 哈希
        full_sha256 = calculate_file_hash(target_file)
        
        # MD5 相关哈希计算
        # 1. 计算前1MB MD5 哈希
        front_1m_md5 = calculate_partial_hash(target_file, part='front', size=1024*1024, hash_algorithm='md5')
        # 2. 计算后1MB MD5 哈希
        back_1m_md5 = calculate_partial_hash(target_file, part='back', size=1024*1024, hash_algorithm='md5')
        # 3. 计算完整文件的 MD5 哈希
        full_md5 = calculate_file_hash(target_file, hash_algorithm='md5')
        
        print("\n===== 哈希计算结果 =====")
        print(f"文件路径: {target_file}")
        
        # 输出 SHA256 哈希
        print("\n--- SHA256 哈希 ---")
        print(f"前1MB哈希: {front_1m_sha256}")
        print(f"后1MB哈希: {back_1m_sha256}")
        print(f"完整内容哈希: {full_sha256}")
        
        # 输出 MD5 哈希
        print("\n--- MD5 哈希 ---")
        print(f"前1MB哈希: {front_1m_md5}")
        print(f"后1MB哈希: {back_1m_md5}")
        print(f"完整内容哈希: {full_md5}")

class chucun:
    # 创建一个大文本，包含多个分隔符
    file_id = "abc!123" * 10**5

    # 方法 1：使用 split()
    def method_split():
        return
        return file_id.split('!')[0]


    # 方法 2：使用正则表达式
    def method_regex():
        match = re.match(r"([^!]+)", chucun.file_id)
        if match:
            return match.group(1)


    # 方法 3：使用 find() 和切片
    def method_find_slice():
        index = chucun.file_id.find('!')
        if index != -1:
            return chucun.file_id[:index]


    # 方法 4：使用 partition()
    def method_partition():
        left_part, sep, right_part = chucun.file_id.partition('!')
        return left_part


    # 方法 5：使用 index() 和切片
    def method_index_slice():
        try:
            index = chucun.file_id.index('!')
            return chucun.file_id[:index]
        except ValueError:
            return None


    # 测试性能
    def test_performance():
        methods = [chucun.method_split, chucun.method_regex, chucun.method_find_slice, chucun.method_partition, chucun.method_index_slice]
        results = {}
        for method in methods:
            time_taken = timeit.timeit(method, number=1000)
            results[method.__name__] = time_taken
        return results

class MainWindow:
    def __init__(self, fr,searcher):
        self.frame = fr
        global log_event
        log_event =fr.log_event
        if hasattr(fr, 'SetStatusText'):
            self.SetStatusText = fr.SetStatusText
            self.searcher=searcher
        if hasattr(self, 'query_combobox'):
            self.query_combobox = self.frame.query_Box
        
    def local_查找索引( self,keyword, column_index=2):
        num=len(self.frame.down_tableView.model.search(keyword, column_index))
        return num>0
    def local_查找索引2( self,keyword, column_index=2):
        data=self.frame.down_tableView.model.search(keyword, column_index)
        return data
    def local_查找索引_index( self,keyword, column_index=2,matching_rows = []):
        data=self.frame.down_tableView.model.search_with_index(keyword, column_index,matching_rows =matching_rows)
        return data
    def local_updateRow(self,row_index,row_data):
        self.frame.down_tableView.model.updateRow(row_index,row_data)
    def on_localsearch_rows(self,column_index):
        start_time = time.time()
        keyword = self.frame.search_data.text()
        if  keyword.strip() == "":
            self.SetStatusText(self.frame,"请输入搜索关键词")
            return
        # column_index = self.query_combobox.currentIndex()
        # frame.file_list.model.search(keyword, column_index)
        # print(f"搜索用时: {time.time() - start_time:.2f} 秒")
        matching_rows=self.frame.down_tableView.model.search_row(keyword, column_index)
        if hasattr(self, 'SetStatusText'):
            self.SetStatusText(self.frame,f"搜索关键词: {keyword}，找到 {len(matching_rows)} 条记录,用时: {time.time() - start_time:.2f} 秒")
        # print(matching_rows)
        if hasattr(self.frame.down_tableView, 'select_cells') and (len(matching_rows)<30):
            self.frame.down_tableView.select_cells(matching_rows,[column_index])
    

    def add_data_to_table(self):
        start_time = time.time()
        result = {'成功': 0, '失败': 0, "重复": 0, "已存在": 0}
        result_array = []
        lisview = None
        if hasattr(self.frame, 'down_tableView'):
            lisview = self.frame.down_tableView
        count=self.searcher.everything_searchW(self.frame.add_data.text(), result_array)
        print(f"搜索用时: {time.time() - start_time:.2f} 秒,找到 {count} 条记录")
        for i,item in enumerate(result_array):
            self.xy_handle_media_file(item['full_path'], result, lisview, item=item,cplumns=8)

    def taoxi_process_File(self,file, result, list=None, sorce=0,mq=None):
        try:
            if sorce == 2:
                list = self.frame.down_tableView
            result2 = {'成功': 0, '失败': 0, "重复": 0, "已存在": 0}
            
            if file.endswith('.txt'):
                start_time = time.time()
                decoded_data = 取文件编码(file)
                data = []
                
                for line_num, line in enumerate(decoded_data.splitlines(), 1):
                    data.append(line.split('\t'))
                # data=读取文件数据(file)
                print(f"读取文件耗时2: {time.time() - start_time}秒")
                list.update_data(data)
                
            elif list == None and sorce == 0:
                return
            elif file.endswith(('.avi', '.mp4', '.jpg', '.jpeg', '.live')):
                if "闲鱼" in file or "贴吧" in file:
                    self.xy_handle_media_file(file, result, list,mq=mq)
        except Exception as e:
            traceback.print_exc()
            if sorce == 2:
                log_event(2, "加载文件", f"文件加载失败: {file} - {str(e)}")
            else:
                log_event(2, "添加记录", f"处理文件失败: {file} - {str(e)}")
            result['失败'] += 1
    def process_filename(self,文件名):
        isup, 文件ID,  文件格式, 用户名, 用户ID, 发布时间, ip, search_text, 处理,videoid,search_text = False, "", "", "", "", "", "", "", False, "", ""

        match = re.match(xy_patterns[0]['r'], 文件名)
        
        if not match:  # 如果文件名不匹配，则尝试使用其他模式
            match = re.match(xy_patterns[1]['r'], 文件名)
            if match:
                groups = match.groups()
                ip=''
                
                发布时间 = '1970-01-01 00:00:00'
                处理 = True
            else:
                match = re.match(xy_patterns[2]['r'], 文件名)
                if match:
                    groups = match.groups()
                    ip = groups[4]
                    
                    发布时间 = groups[3]

                    处理 = True
                else:
                    match = re.match(xy_patterns[3]['r'], 文件名)
                    if match:
                        groups = match.groups()
                        ip = groups[4]
                        文件ID= ''
                        发布时间 = groups[3] if groups[3] else '1970-01-01 00:00:00'
                        videoid = groups[5] + groups[6]
                        search_text = videoid 
                        处理 = True
                    else:
                        match = re.match(xy_patterns[4]['r'], 文件名)
                        if match:
                            groups = match.groups()
                            ip = groups[4]

                            发布时间 = groups[3] if groups[3] else '1970-01-01 00:00:00'
 
                            处理 = True
                        else:
                            match = re.match(xy_patterns[5]['r'], 文件名)
                            if match:
                                groups = match.groups()
                                ip = groups[4]if groups[4] else ''

                                发布时间 = groups[3]if groups[3] else '1970-01-01 00:00:00'
                                videoid = groups[6] + groups[7]
                                search_text = videoid  
                                处理 = True
                            else:
                                match = re.match(xy_patterns[6]['r'], 文件名)
                                if match:
                                    groups = match.groups()
                                    ip = groups[4]if groups[4] else ''

                                    发布时间 = groups[3]if groups[3] else '1970-01-01 00:00:00'
                                    videoid = groups[5] + groups[6]
                                    search_text = videoid  
                                    处理 = True
                                else:
                                    match = re.match(tb_patterns[0]['r'], 文件名)
                                    if match:
                                        groups = match.groups()
                                        ip = groups[4]if groups[4] else ''

                                        发布时间 = groups[5]if groups[5] else '1970-01-01 00:00:00'
                                        # 应用转换
                                        发布时间 = format_time(发布时间,' ')     
                                        videoid  = groups[1] 
                                        用户名 = groups[3]if groups[3] else ''
                                        用户ID = 用户名
                                        文件ID = groups[6]if groups[6] else ''
                                        search_text = videoid  
                                        处理 = True
                                    else:
                                        match = re.match(tb_patterns[1]['r'], 文件名)
                                        if match:
                                            groups = match.groups()
                                            ip = groups[4]if groups[4] else ''

                                            发布时间 = groups[5]if groups[5] else '1970-01-01 00:00:00'
                                            # 应用转换
                                            发布时间 = format_time(发布时间,' ')     
                                            videoid  = groups[1] 
                                            用户名 = groups[3]if groups[3] else ''
                                            用户ID = 用户名
                                            文件ID = groups[6]if groups[6] else ''
                                            search_text = videoid  
                                            处理 = True
                                        else:
                                            print(f"文件名 {文件名} 不符合规则")
                                            
                                            return isup,文件ID, 用户名, 用户ID, ip, search_text, videoid, 发布时间, 文件格式  
            文件格式 = f".{groups[-1]}"  # 获取文件扩展名
            if 文件ID == '':
                文件ID = groups[5]
            if 用户名 == '':
                用户名 = groups[0]
            if 用户ID == '':
                用户ID = groups[1]
            if search_text == '':
                videoid = groups[6] + groups[7]
                search_text = videoid                    
        else:
            
            groups = match.groups()
            if ip == '':
                ip = groups[5]
            
            发布时间 = time.strftime('%Y-%m-%d %H:%M:%S', time.strptime(groups[4], '%Y%m%d_%H%M%S'))if groups[4] else '1970-01-01 00:00:00'
            处理 = True
        
        if 处理:
            文件格式 = f".{groups[-1]}"  # 获取文件扩展名
            if 文件ID == '':
                文件ID = groups[6]
            if 用户名 == '':
                用户名 = groups[0]
            if 用户ID == '':
                用户ID = groups[1]
            if search_text == '':
                videoid = groups[7] + groups[8]
                search_text = videoid
        isup=True
        return isup,文件ID, 用户名, 用户ID, ip, search_text, videoid, 发布时间, 文件格式        
    
    def xy_handle_media_file(self,file, result, listview,item=None,cplumns = 8,mq=None):
        """
        处理媒体文件 (.avi, .mp4, .jpg, .jpeg, .live) 的逻辑
        """
        columns = 8  # '文章id'
        
        
        if item:
            文件名 = item['filename']
            目录路径 = item['path']
        else:
            文件名 = os.path.basename(file)
            目录路径 = os.path.dirname(file)
        if "\n" in file:
            
            try:
                os.rename(file, file.replace("\n", ""))
                file = file.replace("\n", "")
                文件名 = file.replace("\n", "")
            except Exception as e:
                print(f"重命名文件失败: {file} - {str(e)}")
                result['失败'] += 1
                return
    

        isup,文件ID, 用户名, 用户ID, ip, search_text, videoid, 发布时间, 文件格式  =self.process_filename(文件名)
        if not isup:
            return
        info = file_info(file, 文件格式, log_event,item)
        行数=len(listview.model.table_data) + 1
        new_data = [
            行数, file, f"{info['文件大小']}", 文件格式, info['文件md5'], info['下载时间_str'],
            文件ID, 发布时间,videoid, '闲鱼', "", ip,''
        ]
        matching_rows = []
        start_time=time.time()
        data = self.local_查找索引_index( search_text, column_index=columns,matching_rows=matching_rows )
        # if len(data) == 1:
        #     # print(file)
            
        #     # result['重复'] += 1
        #     # return
        #print('搜索耗时',time.time()-start_time,matching_rows)
        if len(data) == 1:
            result['重复'] += 1
            return
            start_time=time.time()
            column_names = []
            new_datas=[]
            for i, value in enumerate(data[0]):
                if 0<=i<2:
                    continue
                if  value!=new_data[i] and  new_data[i]:
                    # print(value,new_data[i])
                    column_name = self.frame.table_columns[i]
                    new_datas.append(new_data[i])   
                    column_names.append(column_name) 
            if len(new_datas)>0:
                self.local_updateRow(matching_rows[0],new_data)
                #print('判断数据',time.time()-start_time,matching_rows)
                return
                # print(column_names,new_datas)
                # set_clause = ', '.join([f"{col} = %s" for col in column_names])
                # # 生成完整的 UPDATE 语句
                # query = f"UPDATE {self.frame.TABLES.text()} SET {set_clause} WHERE 文章ID = %s"
                # params = new_datas + [search_text]
                # data=mysql_x_qt.execute_query(self.frame.connection, query, params)
                # if data['success']:
                #     log_event(0,"更新表项成功")
            
            else:
                #print(time.time()-start_time,matching_rows)
                result['重复'] += 1
                return
        if len(data) >1:
            result['重复'] += 1
            return
        if mq.查找索引2(self.frame.TABLES.text(),search_text,search_column=self.frame.table_columns[columns] )['result']:
                            print(file)
                            result['重复'] += 1
                            end_time=time.time()-start_time
                            return
        行数 = len(listview.model.table_data) + 1

        
        listview.adddate_data(new_data)
        
        db_result = mq.添加表项_dy( new_data, self.frame.TABLES.text(), self.frame.table_columns)
        if db_result['success']:
            result['成功'] += 1
        else:
            log_event(0, "添加记录", f"插入数据失败：{videoid}{db_result['error']}")
            result['失败'] += 1

 # 定义时间格式转换函数
