#!/usr/bin/env python3
"""
smart_decode.py – Decode a Library coordinate (recursive), automatically handling manifests.
Usage: python3 smart_decode.py <coord_file> <output_file>
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
from libobsh.lob import retrieve_file_recursive

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 smart_decode.py <coord_file> <output_file>")
        sys.exit(1)

    coord_file = sys.argv[1]
    output_file = sys.argv[2]

    if not output_file:
        print("Error: output file name is empty")
        sys.exit(1)

    if not os.path.exists(coord_file):
        print(f"Error: coordinate file not found: {coord_file}")
        sys.exit(1)

    with open(coord_file, 'r') as f:
        coord = f.read().strip()

    retrieve_file_recursive(coord, output_file)

if __name__ == "__main__":
    main()
