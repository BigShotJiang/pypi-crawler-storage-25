#!/usr/bin/env python3
"""
smart_encode.py – Encode any file to a single Library coordinate (recursive).
For large files, stores a tree of manifests and returns the top coordinate.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))
from libobsh.lob import store_file_recursive

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 smart_encode.py <filename>")
        sys.exit(1)

    filename = sys.argv[1]
    print(f"Encoding {filename} ...")
    coord = store_file_recursive(filename)

    # Save coordinate to .coord file
    coord_file = filename + '.coord'
    with open(coord_file, 'w') as cf:
        cf.write(coord)
    print(f"Coordinate saved to {coord_file}")
    print(f"First 60 chars: {coord[:60]}...")

if __name__ == "__main__":
    main()
