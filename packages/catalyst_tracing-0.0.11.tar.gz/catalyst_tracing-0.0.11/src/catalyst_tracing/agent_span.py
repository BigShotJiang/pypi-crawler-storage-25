""":func:`agent_span` — context manager that wraps work in an
OpenInference-flavored AGENT span.

Use this when you have a chunk of "agent work" — a CLI subprocess
call, a multi-step Pydantic AI run, the outer wrapper around an
``agents-sdk`` ``Runner.run()`` — and you want it to show up in
the trace viewer as a single AGENT-kind row with input/output and
optional token counts.

The context manager:

* Sets ``openinference.span.kind=AGENT``, ``agent.name``,
  ``gen_ai.system`` automatically.
* Runs the body inside the span's active OTel context, so child
  spans created by instrumented LLM SDKs auto-parent to this
  AGENT span. (That's how a full trace tree forms.)
* Ends with ``OK`` on success, records the exception and ends with
  ``ERROR`` on failure (re-raising so the caller's error handling
  is unaffected).

Example
-------
Wrapping a CLI subprocess::

    from catalyst_tracing import agent_span, setup

    tracing = setup()
    with agent_span(tracing.tracer, name="ClaudeCode", system="anthropic") as span:
        span.set_input(prompt)
        answer = run_cli(prompt)
        span.set_output(answer)
        span.record_tokens(prompt=120, completion=40)

Wrapping an `openai-agents` runner so its LLM-call spans nest
under the AGENT span::

    from catalyst_tracing import agent_span, setup
    from agents import Agent, Runner

    tracing = setup()
    agent = Agent(name="SupportAgent", instructions=..., tools=[...])

    with agent_span(tracing.tracer, name="SupportAgent", system="openai") as span:
        span.set_input(user_message)
        result = await Runner.run(agent, input=user_message)
        span.set_output(str(result.final_output))
"""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any

from opentelemetry.trace import Span, SpanKind, Status, StatusCode, Tracer

from .semconv import Attr, SpanKindValues
from .span_helpers import (
    record_span_usage,
    set_span_attribute,
    set_span_attributes,
    stringify_value,
)


@dataclass
class AgentSpanHandle:
    """The handle yielded by :func:`agent_span`.

    Provides type-safe helpers for the OI attribute set the agent
    span should carry, plus a ``span`` escape hatch for callers
    that need the underlying OTel span (e.g. to add custom
    attributes outside the OI vocabulary).
    """

    #: The underlying OTel span — escape hatch for advanced use.
    span: Span

    def set_input(self, value: Any) -> None:
        """Record the agent's input.

        Strings are stored as-is on ``input.value``. Non-strings
        are JSON-stringified.
        """
        self.span.set_attribute(Attr.INPUT_VALUE, stringify_value(value))

    def set_output(self, value: Any) -> None:
        """Record the agent's final output.

        Same string-vs-JSON rule as :meth:`set_input`.
        """
        self.span.set_attribute(Attr.OUTPUT_VALUE, stringify_value(value))

    def record_tokens(
        self,
        *,
        prompt: int | None = None,
        completion: int | None = None,
        total: int | None = None,
    ) -> None:
        """Record token usage on the agent span.

        Any of ``prompt``, ``completion``, ``total`` may be omitted;
        only the provided fields are written. Use this when you have
        aggregated counts across multiple LLM calls inside the agent
        loop — per-call counts get captured by the LLM-level
        instrumentation separately.
        """
        if prompt is not None:
            self.span.set_attribute(Attr.TOKEN_COUNT_PROMPT, prompt)
        if completion is not None:
            self.span.set_attribute(Attr.TOKEN_COUNT_COMPLETION, completion)
        if total is not None:
            self.span.set_attribute(Attr.TOKEN_COUNT_TOTAL, total)

    def record_usage(self, usage: Any) -> None:
        """Record token usage from a provider-shaped usage object.

        Accepts OpenAI-style ``prompt_tokens`` / ``completion_tokens`` /
        ``total_tokens``, newer ``input_tokens`` / ``output_tokens`` spellings,
        and Anthropic cache token fields. Unsupported shapes are ignored.
        """

        record_span_usage(self.span, usage)

    def set_model(self, model: str) -> None:
        """Record the model name (becomes ``llm.model_name``)."""
        self.span.set_attribute(Attr.MODEL_NAME, model)

    def set_tool(self, *, name: str, call_id: str | None = None) -> None:
        """Record tool identity on a TOOL span."""

        self.span.set_attribute(Attr.TOOL_NAME, name)
        if call_id is not None:
            self.span.set_attribute(Attr.TOOL_CALL_ID, call_id)

    def set_attribute(self, key: str, value: Any) -> None:
        """Set one span attribute with OTel-safe value normalization."""

        set_span_attribute(self.span, key, value)

    def set_attributes(self, attributes: Mapping[str, Any]) -> None:
        """Set many span attributes with OTel-safe value normalization."""

        set_span_attributes(self.span, attributes)


@contextmanager
def manual_span(
    tracer: Tracer,
    *,
    name: str,
    system: str | None = None,
    span_kind: SpanKindValues | str = SpanKindValues.CHAIN,
    otel_kind: SpanKind = SpanKind.INTERNAL,
    span_name: str | None = None,
    agent_name: str | None = None,
    input: Any | None = None,
    output: Any | None = None,
    model: str | None = None,
    usage: Any | None = None,
    tool_name: str | None = None,
    tool_call_id: str | None = None,
    attributes: Mapping[str, Any] | None = None,
    metadata: Mapping[str, Any] | None = None,
    tags: list[str] | tuple[str, ...] | None = None,
) -> Iterator[AgentSpanHandle]:
    """Wrap custom work in an OpenInference-shaped manual span.

    This is the general-purpose helper for framework gaps: custom routers,
    provider failover attempts, tool executors, evaluators, postprocessors, or
    high-level agent loops. It sets the OpenInference span kind, normalizes
    input/output values, accepts provider-shaped usage payloads, and keeps the
    body inside the active OTel context so SDK auto-instrumentation nests under
    it.
    """

    resolved_span_name = span_name or name
    resolved_kind_value = (
        span_kind.value if isinstance(span_kind, SpanKindValues) else span_kind
    )

    span_attributes: dict[str, Any] = {
        Attr.SPAN_KIND: resolved_kind_value,
    }
    if agent_name is not None:
        span_attributes[Attr.AGENT_NAME] = agent_name
    if system is not None:
        span_attributes[Attr.SYSTEM] = system
    if tool_name is not None:
        span_attributes[Attr.TOOL_NAME] = tool_name
    if tool_call_id is not None:
        span_attributes[Attr.TOOL_CALL_ID] = tool_call_id
    if attributes:
        span_attributes.update(attributes)
    if metadata:
        span_attributes["metadata"] = metadata
    if tags:
        span_attributes["tags"] = list(tags)

    with tracer.start_as_current_span(
        resolved_span_name,
        kind=otel_kind,
        attributes={},
    ) as span:
        set_span_attributes(span, span_attributes)
        handle = AgentSpanHandle(span=span)
        if input is not None:
            handle.set_input(input)
        if output is not None:
            handle.set_output(output)
        if model is not None:
            handle.set_model(model)
        if usage is not None:
            handle.record_usage(usage)
        try:
            yield handle
            span.set_status(Status(StatusCode.OK))
        except Exception as err:
            span.record_exception(err)
            span.set_status(Status(StatusCode.ERROR, str(err)))
            raise


@contextmanager
def agent_span(
    tracer: Tracer,
    *,
    name: str,
    system: str | None = None,
    span_kind: SpanKindValues | str = SpanKindValues.AGENT,
    otel_kind: SpanKind = SpanKind.INTERNAL,
    span_name: str | None = None,
) -> Iterator[AgentSpanHandle]:
    """Wrap a chunk of agent work in an OI-shaped AGENT span.

    Parameters
    ----------
    tracer : Tracer
        OpenTelemetry tracer to author the span from. Use the one
        on :class:`CatalystTracing.tracer`.
    name : str
        Logical agent name — e.g. ``"ClaudeCode"``,
        ``"WeatherAgent"``. Becomes the ``agent.name`` attribute
        and the prefix of the default span name.
    system : str, optional
        Identifier of the LLM provider this agent runs on, e.g.
        ``"openai"`` or ``"anthropic"``. Becomes the
        ``gen_ai.system`` attribute. Optional — omit if the agent
        is provider-agnostic.
    span_kind : SpanKindValues or str, default AGENT
        OpenInference span kind. Pass another
        :class:`SpanKindValues` (e.g. ``CHAIN``) when this helper
        is used outside a strictly agent context.
    otel_kind : SpanKind, default INTERNAL
        OTel-level span kind. ``INTERNAL`` because the work itself
        is internal to this process; the LLM-call children get
        their own ``CLIENT`` kind from the per-SDK patchers.
    span_name : str, optional
        Override the auto-generated span name (``f"{name}.run"``).
        Useful when "run" doesn't fit — e.g. our examples use
        ``"claude-code.invocation"`` for one-shot CLI calls.

    Yields
    ------
    AgentSpanHandle
        Helpers to set input/output/tokens/model on the span.

    Notes
    -----
    The span is closed automatically when the ``with`` block
    exits. On unhandled exceptions the span ends with ``ERROR``
    status and an ``exception`` event recording the traceback,
    then the exception re-raises so caller error handling is
    unaffected.
    """
    with manual_span(
        tracer,
        name=span_name or f"{name}.run",
        system=system,
        span_kind=span_kind,
        otel_kind=otel_kind,
        agent_name=name,
    ) as span:
        yield span
