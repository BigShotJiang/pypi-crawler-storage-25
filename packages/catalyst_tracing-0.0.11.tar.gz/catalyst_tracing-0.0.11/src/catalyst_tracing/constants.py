"""Package-level constants shared across setup, installers, and patchers."""

from __future__ import annotations

PACKAGE_VERSION = "0.0.6"


class DefaultConfig:
    OTLP_ENDPOINT = "http://localhost:8799"
    SERVICE_NAME_PREFIX = "catalyst-app"
    SERVICE_VERSION = PACKAGE_VERSION


class EnvVar:
    CATALYST_OTLP_ENDPOINT = "CATALYST_OTLP_ENDPOINT"
    LEGACY_OTLP_ENDPOINT = "OTLP_ENDPOINT"
    CATALYST_OTLP_TOKEN = "CATALYST_OTLP_TOKEN"
    LEGACY_OTLP_INGEST_TOKEN = "OTLP_INGEST_TOKEN"
    CATALYST_SERVICE_NAME = "CATALYST_SERVICE_NAME"
    LEGACY_SERVICE_NAME = "SERVICE_NAME"
    CATALYST_SERVICE_VERSION = "CATALYST_SERVICE_VERSION"
    CATALYST_DEBUG = "CATALYST_DEBUG"


class MimeType:
    JSON = "application/json"


class HttpHeader:
    AUTHORIZATION = "Authorization"
    CONTENT_TYPE = "Content-Type"


class OtlpPath:
    TRACES = "/v1/traces"


class BatchingMode:
    BATCH = "batch"
    SIMPLE = "simple"


class SpanProcessorDefaults:
    MAX_EXPORT_BATCH_SIZE = 64
    SCHEDULE_DELAY_MILLIS = 1000


class ResourceAttribute:
    SERVICE_NAME = "service.name"
    SERVICE_VERSION = "service.version"


class OpenTelemetryRuntime:
    PROXY_TRACER_PROVIDER = "ProxyTracerProvider"


class IntegrationId:
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LANGCHAIN = "langchain"
    LANGGRAPH = "langgraph"
    LANGSMITH = "langsmith"
    OPENAI_AGENTS = "openai-agents"
    CLAUDE_AGENT_SDK = "claude-agent-sdk"
    PYDANTIC_AI = "pydantic-ai"
    ELEVENLABS = "elevenlabs"


class InstallerId:
    """Function-name-compatible integration identifiers for errors."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LANGCHAIN = "langchain"
    LANGGRAPH = "langgraph"
    LANGSMITH = "langsmith"
    OPENAI_AGENTS = "openai_agents"
    CLAUDE_AGENT_SDK = "claude_agent_sdk"
    PYDANTIC_AI = "pydantic_ai"
    ELEVENLABS = "elevenlabs"


class ImportName:
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LANGCHAIN_CORE = "langchain_core"
    LANGGRAPH = "langgraph"
    LANGSMITH = "langsmith"
    LANGSMITH_CLIENT = "langsmith.client"
    OPENAI_AGENTS = "agents"
    CLAUDE_AGENT_SDK = "claude_agent_sdk"
    CLAUDE_AGENT_SDK_QUERY = "claude_agent_sdk.query"
    PYDANTIC_AI = "pydantic_ai"
    ELEVENLABS = "elevenlabs"
    ELEVENLABS_CONVERSATION = "elevenlabs.conversational_ai.conversation"


class GenAISystem:
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    ELEVENLABS = "elevenlabs"


class TracerName:
    ROOT = "catalyst_tracing"
    OPENAI = "catalyst_tracing.openai"
    ANTHROPIC = "catalyst_tracing.anthropic"
    LANGCHAIN = "catalyst_tracing.langchain"
    CLAUDE_AGENT_SDK = "catalyst_tracing.claude_agent_sdk"
    ELEVENLABS = "catalyst_tracing.elevenlabs"


class SpanName:
    OPENAI_CHAT_COMPLETIONS = "OpenAI Chat Completions"
    OPENAI_RESPONSES = "OpenAI Responses"
    ANTHROPIC_MESSAGES = "Anthropic Messages"
    CLAUDE_AGENT_QUERY = "ClaudeAgentSDK.query"
    ELEVENLABS_CONVERSATION = "ElevenLabs Conversation"


class AgentName:
    CLAUDE_AGENT_SDK = "ClaudeAgentSDK"
    ELEVENLABS = "ElevenLabsAgent"


class PatchedMethod:
    CREATE = "create"


PATCH_MARKER_ATTR = "_catalyst_wrapped"
