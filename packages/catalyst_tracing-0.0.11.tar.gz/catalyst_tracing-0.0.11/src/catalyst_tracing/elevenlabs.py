"""``catalyst_tracing.elevenlabs`` granular entry point."""

from __future__ import annotations

from .installers.elevenlabs import install_elevenlabs

__all__ = ["install_elevenlabs"]
