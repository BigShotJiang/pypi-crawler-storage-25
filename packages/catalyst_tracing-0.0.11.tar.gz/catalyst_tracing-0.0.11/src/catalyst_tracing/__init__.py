"""``catalyst_tracing`` — first-party tracing for LLM apps.

Drop-in OpenInference-shaped instrumentation for the SDKs your app
uses (openai, anthropic, langchain, langgraph, langsmith,
openai-agents, claude-agent-sdk, pydantic-ai, elevenlabs), plus a
small ergonomic helper layer for cases where you need to author spans
by hand.

Quick start::

    from catalyst_tracing import setup
    from openai import OpenAI

    tracing = setup()
    client = OpenAI(api_key=...)
    client.chat.completions.create(model=..., messages=...)
    tracing.shutdown()

What this package owns
----------------------

- **OTLP plumbing** — endpoint, token, service-name resource, batch
  vs. simple processor selection, env-var resolution with sensible
  defaults including legacy ``OTLP_*`` fallback.
- **First-party OpenInference instrumentation** for openai, anthropic,
  langchain, langgraph, openai-agents, claude-agent-sdk, elevenlabs,
  plus bridges for langsmith and pydantic-ai's native OTel. No
  ``openinference-instrumentation-*`` runtime dependency.
- **Helpers**: :func:`manual_span` for custom CHAIN/TOOL/AGENT spans,
  :func:`agent_span` for manual AGENT spans;
  :class:`Attr` and :class:`SpanKindValues` for the OI semantic-
  convention constants you'd want when authoring custom spans.

What this package doesn't own
-----------------------------

- The SDKs themselves. They're optional extras — pull in only the
  ones you use::

      pip install 'catalyst-tracing[openai,anthropic]'

- Shipping spans somewhere other than OTLP/HTTP/JSON. If you need a
  different transport, build your own exporter and add it to
  ``tracing.provider``.

Public API
----------

* :func:`setup` — bootstrap tracing, returns a
  :class:`CatalystTracing` handle.
* :func:`manual_span` — context manager that wraps custom work in an
  OI-shaped CHAIN/TOOL/AGENT span.
* :func:`agent_span` — backwards-compatible context manager that wraps
  work in an OI-shaped AGENT span.
* :class:`Attr`, :class:`SpanKindValues` — wire-format constants
  shared across instrumentation and consumer-authored spans.
"""

from .agent_span import AgentSpanHandle, agent_span, manual_span
from .errors import (
    CatalystTracingError,
    CatalystTracingErrorCode,
    CatalystTracingErrorCodes,
    InvalidSdkInputError,
    InvalidTracerProviderError,
)
from .semconv import Attr, MessageRole, OpenInferenceAttribute, SpanKindValues
from .setup import CatalystTracing, InstrumentResult, setup
from .span_helpers import (
    TokenUsage,
    normalize_usage,
    record_span_usage,
    set_span_attribute,
    set_span_attributes,
    stringify_value,
)

__version__ = "0.0.11"
PACKAGE_NAME = "catalyst-tracing"
IMPORT_NAME = "catalyst_tracing"
COMPANY_NAME = "Inference"
PLATFORM_NAME = "Catalyst"
PRODUCT_NAME = "Catalyst by Inference.net"

__all__ = [
    "AgentSpanHandle",
    "Attr",
    "CatalystTracing",
    "CatalystTracingError",
    "CatalystTracingErrorCode",
    "CatalystTracingErrorCodes",
    "COMPANY_NAME",
    "IMPORT_NAME",
    "InstrumentResult",
    "InvalidSdkInputError",
    "InvalidTracerProviderError",
    "MessageRole",
    "OpenInferenceAttribute",
    "PACKAGE_NAME",
    "PLATFORM_NAME",
    "PRODUCT_NAME",
    "SpanKindValues",
    "TokenUsage",
    "__version__",
    "agent_span",
    "manual_span",
    "normalize_usage",
    "record_span_usage",
    "set_span_attribute",
    "set_span_attributes",
    "setup",
    "stringify_value",
]
