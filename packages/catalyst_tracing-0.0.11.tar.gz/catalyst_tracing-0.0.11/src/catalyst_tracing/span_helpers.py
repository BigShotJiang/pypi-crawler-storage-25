"""Public helpers for authoring rich manual spans.

The SDK's auto-instrumentations normalize JSON-ish values, usage objects, and
OTel-safe attributes internally. These helpers expose the same ergonomics to
manual span authors so applications do not have to copy small coercion utilities
into every integration.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Any

from opentelemetry.trace import Span

from .semconv import Attr

AttributeValue = (
    str
    | bool
    | int
    | float
    | Sequence[str]
    | Sequence[bool]
    | Sequence[int]
    | Sequence[float]
)


@dataclass(frozen=True)
class TokenUsage:
    """Normalized token usage extracted from provider-shaped usage payloads."""

    prompt: int | None = None
    completion: int | None = None
    total: int | None = None
    prompt_cache_write: int | None = None
    prompt_cache_read: int | None = None
    completion_reasoning: int | None = None


def stringify_value(value: Any) -> str:
    """Return the string representation used for OpenInference IO attributes."""

    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str)
    except Exception:
        return str(value)


def set_span_attribute(span: Span, key: str, value: Any) -> None:
    """Set one OTel attribute, JSON-encoding unsupported structured values."""

    coerced_value = _coerce_attribute_value(value)
    if coerced_value is not None:
        span.set_attribute(key, coerced_value)


def set_span_attributes(span: Span, attributes: Mapping[str, Any]) -> None:
    """Set several OTel attributes with the same normalization as one value."""

    for key, value in attributes.items():
        if value is not None:
            set_span_attribute(span, key, value)


def record_span_usage(span: Span, usage: Mapping[str, Any] | Any) -> TokenUsage:
    """Record token attributes from OpenAI- and Anthropic-shaped usage objects.

    Supported input keys include OpenAI Chat Completions/Responses style
    ``prompt_tokens`` / ``completion_tokens`` / ``total_tokens``, newer
    ``input_tokens`` / ``output_tokens`` spellings, OpenAI detail objects such
    as ``prompt_tokens_details.cached_tokens`` and
    ``completion_tokens_details.reasoning_tokens``, and Anthropic cache
    accounting keys such as ``cache_creation_input_tokens`` and
    ``cache_read_input_tokens``.
    """

    normalized = normalize_usage(usage)
    if normalized.prompt is not None:
        span.set_attribute(Attr.TOKEN_COUNT_PROMPT, normalized.prompt)
    if normalized.completion is not None:
        span.set_attribute(Attr.TOKEN_COUNT_COMPLETION, normalized.completion)
    if normalized.total is not None:
        span.set_attribute(Attr.TOKEN_COUNT_TOTAL, normalized.total)
    if normalized.prompt_cache_write is not None:
        span.set_attribute(
            Attr.TOKEN_COUNT_PROMPT_CACHE_WRITE,
            normalized.prompt_cache_write,
        )
    if normalized.prompt_cache_read is not None:
        span.set_attribute(
            Attr.TOKEN_COUNT_PROMPT_CACHE_READ,
            normalized.prompt_cache_read,
        )
    if normalized.completion_reasoning is not None:
        span.set_attribute(
            Attr.TOKEN_COUNT_COMPLETION_REASONING,
            normalized.completion_reasoning,
        )
    return normalized


def normalize_usage(usage: Mapping[str, Any] | Any) -> TokenUsage:
    """Normalize common provider usage payloads without touching a span."""

    if not isinstance(usage, Mapping):
        return TokenUsage()

    prompt = _first_int(usage, "prompt_tokens", "input_tokens")
    completion = _first_int(usage, "completion_tokens", "output_tokens")
    total = _first_int(usage, "total_tokens")

    prompt_details = _first_mapping(
        usage,
        "prompt_tokens_details",
        "input_tokens_details",
    )
    completion_details = _first_mapping(
        usage,
        "completion_tokens_details",
        "output_tokens_details",
    )

    prompt_cache_write = _first_int(usage, "cache_creation_input_tokens")
    prompt_cache_read = _first_int(usage, "cache_read_input_tokens") or _first_int(
        prompt_details, "cached_tokens"
    )
    completion_reasoning = _first_int(completion_details, "reasoning_tokens")

    if _has_anthropic_cache_usage(usage) and prompt is not None:
        prompt = prompt + (prompt_cache_write or 0) + (prompt_cache_read or 0)

    if total is None and prompt is not None and completion is not None:
        total = prompt + completion

    return TokenUsage(
        prompt=prompt,
        completion=completion,
        total=total,
        prompt_cache_write=prompt_cache_write,
        prompt_cache_read=prompt_cache_read,
        completion_reasoning=completion_reasoning,
    )


def _coerce_attribute_value(value: Any) -> AttributeValue | str | None:
    if isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray, str)):
        values = list(value)
        if not values:
            return []
        if all(isinstance(item, str) for item in values):
            return values
        if all(isinstance(item, bool) for item in values):
            return values
        if all(isinstance(item, int) and not isinstance(item, bool) for item in values):
            return values
        if all(isinstance(item, float) for item in values):
            return values
        return stringify_value(values)
    if isinstance(value, Mapping):
        return stringify_value(dict(value))
    return stringify_value(value)


def _first_mapping(
    mapping: Mapping[str, Any],
    *keys: str,
) -> Mapping[str, Any]:
    for key in keys:
        value = mapping.get(key)
        if isinstance(value, Mapping):
            return value
    return {}


def _first_int(mapping: Mapping[str, Any], *keys: str) -> int | None:
    for key in keys:
        value = mapping.get(key)
        coerced = _coerce_int(value)
        if coerced is not None:
            return coerced
    return None


def _coerce_int(value: Any) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float) and value.is_integer():
        return int(value)
    if isinstance(value, str):
        stripped = value.strip()
        if stripped and stripped.lstrip("-").isdigit():
            return int(stripped)
    return None


def _has_anthropic_cache_usage(usage: Mapping[str, Any]) -> bool:
    return (
        usage.get("cache_creation_input_tokens") is not None
        or usage.get("cache_read_input_tokens") is not None
    )
