"""OpenAI auto-instrumentation adapter (first-party impl).

Public surface: :func:`install_openai` — call once with a
``TracerProvider`` and every existing and future ``OpenAI(...)``
client emits OpenInference-shaped LLM spans.
"""

from __future__ import annotations

import importlib

from opentelemetry.sdk.trace import TracerProvider

from ..constants import (
    PACKAGE_VERSION,
    ImportName,
    InstallerId,
    IntegrationId,
    TracerName,
)
from ..errors import InvalidTracerProviderError
from ..instrumentation.openai import install_openai_instrumentation
from .base import InstrumentResult, InstrumentResultCodes


def install_openai(provider: TracerProvider) -> InstrumentResult:
    """Install OpenAI auto-instrumentation.

    :param provider: An OTel ``TracerProvider`` (typically the one
        returned from :func:`catalyst_tracing.setup`'s
        ``tracing.provider``).
    :raises InvalidTracerProviderError: if ``provider`` isn't a
        ``TracerProvider``.
    :returns: An :class:`InstrumentResult` describing the outcome.
        ``installed=True`` on success; ``installed=False`` with code
        ``SDK_NOT_INSTALLED`` if the ``openai`` package isn't on
        ``PYTHONPATH``, or ``SDK_VERSION_INCOMPATIBLE`` if the resource
        classes we patch aren't present (very old SDK versions).
    """
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.OPENAI, provider)
    try:
        importlib.import_module(ImportName.OPENAI)
    except ImportError:
        return InstrumentResult(
            IntegrationId.OPENAI,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "openai not installed",
        )
    tracer = provider.get_tracer(TracerName.OPENAI, PACKAGE_VERSION)
    if not install_openai_instrumentation(tracer):
        return InstrumentResult(
            IntegrationId.OPENAI,
            False,
            InstrumentResultCodes.SDK_VERSION_INCOMPATIBLE,
            "could not locate OpenAI resource classes (chat.Completions, "
            "responses.Responses) — your `openai` version may be too old.",
        )
    return InstrumentResult(IntegrationId.OPENAI, True)
