"""LangSmith OpenTelemetry bridge installer."""

from __future__ import annotations

import importlib
import inspect
import os
from collections.abc import MutableMapping, Sequence
from functools import wraps
from typing import Any

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SpanProcessor

from ..constants import ImportName, InstallerId, IntegrationId, MimeType
from ..errors import InvalidTracerProviderError
from ..semconv import Attr, SpanKindValues
from ..span_helpers import stringify_value
from .base import InstrumentResult, InstrumentResultCodes

_PATCH_ATTR = "_catalyst_langsmith_client_patch"
_ENRICHMENT_PROCESSOR_ATTR = "_catalyst_langsmith_enrichment_processor"


class LangSmithEnvVar:
    LANGSMITH_TRACING = "LANGSMITH_TRACING"
    LANGCHAIN_TRACING_V2 = "LANGCHAIN_TRACING_V2"
    LANGSMITH_TRACING_MODE = "LANGSMITH_TRACING_MODE"
    OTEL_ENABLED = "OTEL_ENABLED"
    OTEL_ONLY = "OTEL_ONLY"
    LANGSMITH_OTEL_ENABLED = "LANGSMITH_OTEL_ENABLED"
    LANGSMITH_OTEL_ONLY = "LANGSMITH_OTEL_ONLY"


def install_langsmith(provider: TracerProvider) -> InstrumentResult:
    """Bridge LangSmith traceable runs into the active OTel provider.

    LangSmith only emits OTel spans when its client runs in ``otel`` or
    ``hybrid`` tracing mode. If an app already enabled LangSmith tracing
    but did not choose a mode, default to ``hybrid`` so traces continue
    going to LangSmith while also flowing through Catalyst's provider.
    """
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.LANGSMITH, provider)
    try:
        client_module = importlib.import_module(ImportName.LANGSMITH_CLIENT)
        importlib.import_module(ImportName.LANGSMITH)
    except ImportError:
        return InstrumentResult(
            IntegrationId.LANGSMITH,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "langsmith not installed",
        )

    Client = getattr(client_module, "Client", None)
    if Client is None:
        return InstrumentResult(
            IntegrationId.LANGSMITH,
            False,
            InstrumentResultCodes.SDK_VERSION_INCOMPATIBLE,
            "langsmith.client does not expose Client",
        )

    bridge_langsmith_tracing_env(os.environ)
    _install_langsmith_span_enrichment(provider)
    original_init = getattr(Client, "__init__", None)
    if not callable(original_init):
        return InstrumentResult(
            IntegrationId.LANGSMITH,
            False,
            InstrumentResultCodes.SDK_VERSION_INCOMPATIBLE,
            "langsmith Client does not expose a callable __init__",
        )

    existing = getattr(Client, _PATCH_ATTR, None)
    if existing is not None:
        existing["provider"] = provider
        return InstrumentResult(IntegrationId.LANGSMITH, True)

    state: dict[str, TracerProvider] = {"provider": provider}
    init_parameters = inspect.signature(original_init).parameters
    supports_tracing_mode = "tracing_mode" in init_parameters
    supports_otel_enabled = "otel_enabled" in init_parameters

    @wraps(original_init)
    def patched_init(self: Any, *args: Any, **kwargs: Any) -> None:
        mode = kwargs.get("tracing_mode") or _env_tracing_mode(os.environ)
        if (
            mode is None
            and kwargs.get("otel_enabled") is None
            and _langsmith_tracing_enabled(os.environ)
        ):
            mode = "hybrid"
            if supports_tracing_mode:
                kwargs["tracing_mode"] = mode
            elif supports_otel_enabled:
                kwargs["otel_enabled"] = True
        if _mode_wants_otel(mode):
            _bridge_langsmith_otel_env(os.environ, mode)
            if supports_tracing_mode and kwargs.get("tracing_mode") is None:
                kwargs["tracing_mode"] = mode
            if (
                not supports_tracing_mode
                and supports_otel_enabled
                and kwargs.get("otel_enabled") is None
            ):
                kwargs["otel_enabled"] = True
            if kwargs.get("otel_tracer_provider") is None:
                kwargs["otel_tracer_provider"] = state["provider"]
        original_init(self, *args, **kwargs)

    Client.__init__ = patched_init
    setattr(Client, _PATCH_ATTR, state)
    return InstrumentResult(IntegrationId.LANGSMITH, True)


class _LangSmithSpanEnrichmentProcessor(SpanProcessor):
    """Normalize LangSmith OTel spans into OpenInference-shaped Catalyst spans."""

    def _on_ending(self, span: Any) -> None:
        attributes = dict(getattr(span, "attributes", {}) or {})
        if not _is_langsmith_span(attributes):
            return

        span_kind = _openinference_span_kind(attributes)
        if span_kind is not None:
            _set_ending_span_attribute(span, Attr.SPAN_KIND, span_kind)

        input_value = attributes.get("gen_ai.prompt")
        if input_value is not None and Attr.INPUT_VALUE not in attributes:
            _set_ending_span_attribute(span, Attr.INPUT_VALUE, input_value)
            _set_ending_span_attribute(span, Attr.INPUT_MIME_TYPE, MimeType.JSON)

        output_value = attributes.get("gen_ai.completion")
        if output_value is not None and Attr.OUTPUT_VALUE not in attributes:
            _set_ending_span_attribute(span, Attr.OUTPUT_VALUE, output_value)
            _set_ending_span_attribute(span, Attr.OUTPUT_MIME_TYPE, MimeType.JSON)

        trace_name = attributes.get("langsmith.trace.name")
        if span_kind == SpanKindValues.TOOL.value and trace_name is not None:
            _set_ending_span_attribute(span, Attr.TOOL_NAME, trace_name)
        if span_kind == SpanKindValues.AGENT.value and trace_name is not None:
            _set_ending_span_attribute(span, Attr.AGENT_NAME, trace_name)

        model_name = (
            attributes.get("langsmith.metadata.ls_model_name")
            or attributes.get("langsmith.metadata.model")
            or attributes.get("langsmith.metadata.model_name")
        )
        if model_name is not None:
            _set_ending_span_attribute(span, Attr.MODEL_NAME, model_name)

        provider = attributes.get("langsmith.metadata.ls_provider") or attributes.get(
            "langsmith.metadata.provider"
        )
        if provider is not None:
            _set_ending_span_attribute(span, Attr.LLM_PROVIDER, provider)


def _install_langsmith_span_enrichment(provider: TracerProvider) -> None:
    if getattr(provider, _ENRICHMENT_PROCESSOR_ATTR, None) is not None:
        return
    processor = _LangSmithSpanEnrichmentProcessor()
    provider.add_span_processor(processor)
    setattr(provider, _ENRICHMENT_PROCESSOR_ATTR, processor)


def _is_langsmith_span(attributes: dict[str, Any]) -> bool:
    return any(
        key.startswith("langsmith.")
        or key in {"gen_ai.prompt", "gen_ai.completion", "gen_ai.operation.name"}
        for key in attributes
    )


def _openinference_span_kind(attributes: dict[str, Any]) -> str | None:
    raw_kind = (
        attributes.get("langsmith.span.kind")
        or attributes.get("gen_ai.operation.name")
        or ""
    )
    normalized_kind = str(raw_kind).strip().lower()
    if normalized_kind == "llm":
        return SpanKindValues.LLM.value
    if normalized_kind == "tool":
        return SpanKindValues.TOOL.value
    if normalized_kind == "retriever":
        return SpanKindValues.RETRIEVER.value
    if normalized_kind == "embedding":
        return SpanKindValues.EMBEDDING.value
    if normalized_kind == "agent":
        return SpanKindValues.AGENT.value
    if normalized_kind:
        return SpanKindValues.CHAIN.value
    return None


def _set_ending_span_attribute(span: Any, key: str, value: Any) -> None:
    if value is None:
        return
    attributes = getattr(span, "_attributes", None)
    if attributes is None:
        return
    attributes[key] = _coerce_ending_attribute_value(value)


def _coerce_ending_attribute_value(value: Any) -> Any:
    if isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray, str)):
        values = list(value)
        if not values:
            return []
        if all(isinstance(item, str) for item in values):
            return values
        if all(isinstance(item, bool) for item in values):
            return values
        if all(isinstance(item, int) for item in values):
            return values
        if all(isinstance(item, float) for item in values):
            return values
    return stringify_value(value)


def bridge_langsmith_tracing_env(env: MutableMapping[str, str]) -> None:
    tracing_mode = _env_tracing_mode(env)
    if tracing_mode is not None:
        _bridge_langsmith_otel_env(env, tracing_mode)
        return
    if _langsmith_tracing_enabled(env):
        tracing_mode = "hybrid"
        env[LangSmithEnvVar.LANGSMITH_TRACING_MODE] = tracing_mode
        _bridge_langsmith_otel_env(env, tracing_mode)


def _bridge_langsmith_otel_env(env: MutableMapping[str, str], tracing_mode: str) -> None:
    if not _mode_wants_otel(tracing_mode):
        return
    env.setdefault(LangSmithEnvVar.OTEL_ENABLED, "true")
    env.setdefault(LangSmithEnvVar.LANGSMITH_OTEL_ENABLED, "true")
    if tracing_mode.lower() == "otel":
        env.setdefault(LangSmithEnvVar.OTEL_ONLY, "true")
        env.setdefault(LangSmithEnvVar.LANGSMITH_OTEL_ONLY, "true")


def _env_tracing_mode(env: MutableMapping[str, str]) -> str | None:
    explicit = env.get(LangSmithEnvVar.LANGSMITH_TRACING_MODE)
    if explicit:
        return explicit.lower()
    if _truthy(env.get(LangSmithEnvVar.OTEL_ONLY)):
        return "otel"
    if _truthy(env.get(LangSmithEnvVar.OTEL_ENABLED)):
        return "hybrid"
    return None


def _langsmith_tracing_enabled(env: MutableMapping[str, str]) -> bool:
    return _truthy(env.get(LangSmithEnvVar.LANGSMITH_TRACING)) or _truthy(
        env.get(LangSmithEnvVar.LANGCHAIN_TRACING_V2)
    )


def _mode_wants_otel(mode: Any) -> bool:
    return isinstance(mode, str) and mode.lower() in {"otel", "hybrid"}


def _truthy(value: str | None) -> bool:
    if value is None or value == "":
        return False
    return value.lower() not in {"0", "false", "no"}
