"""Shared types for per-SDK instrumentation install functions.

Each ``install_*`` helper returns an :class:`InstrumentResult`
describing what happened. The result is non-throwing — "the SDK
isn't installed" is a normal condition, not an error. Bad call sites
(missing TracerProvider, wrong-shape arguments) DO raise — see
``catalyst_tracing.errors``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

#: Stable, machine-readable reasons for ``installed=False``. The
#: string ``reason`` is human-readable; the ``code`` is for
#: programmatic branching.
InstrumentResultCode = Literal[
    "INSTALLED",
    "SDK_NOT_INSTALLED",
    "SDK_VERSION_INCOMPATIBLE",
]


class InstrumentResultCodes:
    INSTALLED: Literal["INSTALLED"] = "INSTALLED"
    SDK_NOT_INSTALLED: Literal["SDK_NOT_INSTALLED"] = "SDK_NOT_INSTALLED"
    SDK_VERSION_INCOMPATIBLE: Literal["SDK_VERSION_INCOMPATIBLE"] = (
        "SDK_VERSION_INCOMPATIBLE"
    )


@dataclass(frozen=True)
class InstrumentResult:
    """Outcome of an ``install_*`` call.

    Attributes:
        name: The integration name, e.g. ``"openai"``.
        installed: Whether instrumentation took.
        code: Stable enum-like code suitable for programmatic checks.
        reason: Human-readable reason, populated when ``installed`` is
            ``False``. ``None`` on success.
    """

    name: str
    installed: bool
    code: InstrumentResultCode = InstrumentResultCodes.INSTALLED
    reason: str | None = None
