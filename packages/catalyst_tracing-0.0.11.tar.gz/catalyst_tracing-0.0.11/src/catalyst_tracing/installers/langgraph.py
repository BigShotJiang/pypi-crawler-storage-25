"""LangGraph auto-instrumentation adapter."""

from __future__ import annotations

import importlib

from opentelemetry.sdk.trace import TracerProvider

from ..constants import (
    PACKAGE_VERSION,
    ImportName,
    InstallerId,
    IntegrationId,
    TracerName,
)
from ..errors import InvalidTracerProviderError
from ..instrumentation.langchain import install_langchain_instrumentation
from .base import InstrumentResult, InstrumentResultCodes


def install_langgraph(provider: TracerProvider) -> InstrumentResult:
    """Install LangGraph tracing through the LangChain callback manager."""
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.LANGGRAPH, provider)
    try:
        importlib.import_module(ImportName.LANGGRAPH)
    except ImportError:
        return InstrumentResult(
            IntegrationId.LANGGRAPH,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "langgraph not installed",
        )
    tracer = provider.get_tracer(TracerName.LANGCHAIN, PACKAGE_VERSION)
    if not install_langchain_instrumentation(tracer):
        return InstrumentResult(
            IntegrationId.LANGGRAPH,
            False,
            InstrumentResultCodes.SDK_VERSION_INCOMPATIBLE,
            "could not patch `langchain_core` callback manager",
        )
    return InstrumentResult(IntegrationId.LANGGRAPH, True)
