"""Pydantic-AI passthrough adapter.

Pydantic-AI ships first-party OTel support. We just call
``Agent.instrument_all()`` so it picks up the global ``TracerProvider``
we registered.
"""

from __future__ import annotations

import importlib
from typing import Any

from opentelemetry.sdk.trace import TracerProvider

from ..constants import ImportName, InstallerId, IntegrationId
from ..errors import InvalidTracerProviderError
from .base import InstrumentResult, InstrumentResultCodes


def install_pydantic_ai(provider: TracerProvider) -> InstrumentResult:
    """Install Pydantic-AI's first-party OTel pipeline.

    :raises InvalidTracerProviderError: if ``provider`` isn't a
        ``TracerProvider``. (We don't actually consume ``provider``
        directly — Pydantic-AI uses
        ``opentelemetry.trace.get_tracer_provider()`` — but we keep
        the same signature as every other ``install_*`` so users can
        swap them freely.)
    """
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.PYDANTIC_AI, provider)
    try:
        pa = importlib.import_module(ImportName.PYDANTIC_AI)
    except ImportError:
        return InstrumentResult(
            IntegrationId.PYDANTIC_AI,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "pydantic-ai not installed",
        )
    agent_cls: Any = pa.Agent
    agent_cls.instrument_all()
    return InstrumentResult(IntegrationId.PYDANTIC_AI, True)
