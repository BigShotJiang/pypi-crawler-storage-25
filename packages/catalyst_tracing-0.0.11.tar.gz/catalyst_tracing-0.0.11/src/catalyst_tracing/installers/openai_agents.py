"""OpenAI Agents auto-instrumentation adapter.

The agents SDK calls the openai client under the hood, so the LLM-call
capture flows from the first-party openai patch. For the agent-level
AGENT span, the example wraps the Runner.run() call with
catalyst-tracing's agent_span helper. This avoids a custom
TraceProcessor in the agents SDK path.
"""

from __future__ import annotations

import importlib

from opentelemetry.sdk.trace import TracerProvider

from ..constants import (
    PACKAGE_VERSION,
    ImportName,
    InstallerId,
    IntegrationId,
    TracerName,
)
from ..errors import InvalidTracerProviderError
from ..instrumentation.openai import install_openai_instrumentation
from .base import InstrumentResult, InstrumentResultCodes


def install_openai_agents(provider: TracerProvider) -> InstrumentResult:
    """Install instrumentation for the ``agents`` (``@openai/agents``)
    SDK.

    Internally this just instruments the ``openai`` client the agents
    SDK calls under the hood — every LLM turn shows up as a nested
    ``OpenAI Responses`` span. Pair with :func:`agent_span` in your
    code to wrap ``Runner.run()`` calls with an outer AGENT span.

    :raises InvalidTracerProviderError: if ``provider`` isn't a
        ``TracerProvider``.
    """
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.OPENAI_AGENTS, provider)
    try:
        importlib.import_module(ImportName.OPENAI_AGENTS)
    except ImportError:
        return InstrumentResult(
            IntegrationId.OPENAI_AGENTS,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "openai-agents not installed",
        )
    try:
        importlib.import_module(ImportName.OPENAI)
    except ImportError:
        return InstrumentResult(
            IntegrationId.OPENAI_AGENTS,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "openai is required for LLM-call capture but isn't installed",
        )
    tracer = provider.get_tracer(TracerName.OPENAI, PACKAGE_VERSION)
    install_openai_instrumentation(tracer)
    return InstrumentResult(IntegrationId.OPENAI_AGENTS, True)
