"""Anthropic auto-instrumentation adapter (first-party impl)."""

from __future__ import annotations

import importlib

from opentelemetry.sdk.trace import TracerProvider

from ..constants import (
    PACKAGE_VERSION,
    ImportName,
    InstallerId,
    IntegrationId,
    TracerName,
)
from ..errors import InvalidTracerProviderError
from ..instrumentation.anthropic import install_anthropic_instrumentation
from .base import InstrumentResult, InstrumentResultCodes


def install_anthropic(provider: TracerProvider) -> InstrumentResult:
    """Install Anthropic auto-instrumentation.

    :param provider: An OTel ``TracerProvider``.
    :raises InvalidTracerProviderError: if ``provider`` isn't a
        ``TracerProvider``.
    :returns: An :class:`InstrumentResult` describing the outcome.
    """
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.ANTHROPIC, provider)
    try:
        importlib.import_module(ImportName.ANTHROPIC)
    except ImportError:
        return InstrumentResult(
            IntegrationId.ANTHROPIC,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "anthropic not installed",
        )
    tracer = provider.get_tracer(TracerName.ANTHROPIC, PACKAGE_VERSION)
    if not install_anthropic_instrumentation(tracer):
        return InstrumentResult(
            IntegrationId.ANTHROPIC,
            False,
            InstrumentResultCodes.SDK_VERSION_INCOMPATIBLE,
            "could not locate Anthropic Messages resource — your "
            "`anthropic` version may be too old.",
        )
    return InstrumentResult(IntegrationId.ANTHROPIC, True)
