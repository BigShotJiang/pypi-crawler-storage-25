"""Claude Agent SDK auto-instrumentation adapter (first-party impl)."""

from __future__ import annotations

import importlib

from opentelemetry.sdk.trace import TracerProvider

from ..constants import (
    PACKAGE_VERSION,
    ImportName,
    InstallerId,
    IntegrationId,
    TracerName,
)
from ..errors import InvalidTracerProviderError
from ..instrumentation.claude_agent_sdk import install_claude_agent_sdk_instrumentation
from .base import InstrumentResult, InstrumentResultCodes


def install_claude_agent_sdk(provider: TracerProvider) -> InstrumentResult:
    """Install Claude Agent SDK auto-instrumentation.

    Patches both ``claude_agent_sdk.query.query`` and the package-
    level ``claude_agent_sdk.query`` snapshot binding so consumers see
    the wrapped function regardless of import style.

    :raises InvalidTracerProviderError: if ``provider`` isn't a
        ``TracerProvider``.
    """
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.CLAUDE_AGENT_SDK, provider)
    try:
        importlib.import_module(ImportName.CLAUDE_AGENT_SDK)
    except ImportError:
        return InstrumentResult(
            IntegrationId.CLAUDE_AGENT_SDK,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "claude-agent-sdk not installed",
        )
    tracer = provider.get_tracer(TracerName.CLAUDE_AGENT_SDK, PACKAGE_VERSION)
    if not install_claude_agent_sdk_instrumentation(tracer):
        return InstrumentResult(
            IntegrationId.CLAUDE_AGENT_SDK,
            False,
            InstrumentResultCodes.SDK_VERSION_INCOMPATIBLE,
            "could not patch `claude_agent_sdk.query` — module layout "
            "differs from the version we support.",
        )
    return InstrumentResult(IntegrationId.CLAUDE_AGENT_SDK, True)
