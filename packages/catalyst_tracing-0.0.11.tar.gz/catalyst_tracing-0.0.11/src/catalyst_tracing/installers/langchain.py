"""LangChain auto-instrumentation adapter (first-party impl)."""

from __future__ import annotations

import importlib

from opentelemetry.sdk.trace import TracerProvider

from ..constants import (
    PACKAGE_VERSION,
    ImportName,
    InstallerId,
    IntegrationId,
    TracerName,
)
from ..errors import InvalidTracerProviderError
from ..instrumentation.langchain import install_langchain_instrumentation
from .base import InstrumentResult, InstrumentResultCodes


def install_langchain(provider: TracerProvider) -> InstrumentResult:
    """Install LangChain auto-instrumentation.

    :param provider: An OTel ``TracerProvider``.
    :raises InvalidTracerProviderError: if ``provider`` isn't a
        ``TracerProvider``.
    :returns: An :class:`InstrumentResult` describing the outcome.
    """
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.LANGCHAIN, provider)
    try:
        importlib.import_module(ImportName.LANGCHAIN_CORE)
    except ImportError:
        return InstrumentResult(
            IntegrationId.LANGCHAIN,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "langchain-core not installed",
        )
    tracer = provider.get_tracer(TracerName.LANGCHAIN, PACKAGE_VERSION)
    if not install_langchain_instrumentation(tracer):
        return InstrumentResult(
            IntegrationId.LANGCHAIN,
            False,
            InstrumentResultCodes.SDK_VERSION_INCOMPATIBLE,
            "could not locate `BaseCallbackManager` to patch — your "
            "`langchain-core` version may be unsupported.",
        )
    return InstrumentResult(IntegrationId.LANGCHAIN, True)
