"""ElevenLabs Agents SDK auto-instrumentation adapter."""

from __future__ import annotations

import importlib

from opentelemetry.sdk.trace import TracerProvider

from ..constants import (
    PACKAGE_VERSION,
    ImportName,
    InstallerId,
    IntegrationId,
    TracerName,
)
from ..errors import InvalidTracerProviderError
from ..instrumentation.elevenlabs import install_elevenlabs_instrumentation
from .base import InstrumentResult, InstrumentResultCodes


def install_elevenlabs(provider: TracerProvider) -> InstrumentResult:
    """Install ElevenLabs Agents SDK auto-instrumentation."""
    if not isinstance(provider, TracerProvider):
        raise InvalidTracerProviderError(InstallerId.ELEVENLABS, provider)
    try:
        importlib.import_module(ImportName.ELEVENLABS)
    except ImportError:
        return InstrumentResult(
            IntegrationId.ELEVENLABS,
            False,
            InstrumentResultCodes.SDK_NOT_INSTALLED,
            "elevenlabs not installed",
        )
    tracer = provider.get_tracer(TracerName.ELEVENLABS, PACKAGE_VERSION)
    if not install_elevenlabs_instrumentation(tracer):
        return InstrumentResult(
            IntegrationId.ELEVENLABS,
            False,
            InstrumentResultCodes.SDK_VERSION_INCOMPATIBLE,
            "could not patch ElevenLabs Conversation classes",
        )
    return InstrumentResult(IntegrationId.ELEVENLABS, True)
