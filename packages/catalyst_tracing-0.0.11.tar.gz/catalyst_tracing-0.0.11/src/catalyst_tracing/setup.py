"""``setup()`` entry point and the :class:`CatalystTracing` handle.

The functions here are the front door of the package — most
consumers only need :func:`setup` and the returned handle's
``tracer`` and ``shutdown()``.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from opentelemetry import trace as trace_api
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    SimpleSpanProcessor,
    SpanProcessor,
)
from opentelemetry.trace import Tracer

from .constants import (
    PACKAGE_VERSION,
    BatchingMode,
    HttpHeader,
    OtlpPath,
    ResourceAttribute,
    SpanProcessorDefaults,
    TracerName,
)
from .env import resolve_config
from .exporter import OTLPJsonHttpSpanExporter
from .installers.anthropic import install_anthropic
from .installers.base import InstrumentResult
from .installers.claude_agent_sdk import install_claude_agent_sdk
from .installers.elevenlabs import install_elevenlabs
from .installers.langchain import install_langchain
from .installers.langgraph import install_langgraph
from .installers.langsmith import install_langsmith
from .installers.openai import install_openai
from .installers.openai_agents import install_openai_agents
from .installers.pydantic_ai import install_pydantic_ai

_LOG = logging.getLogger("catalyst_tracing")


def _shutdown_warn(msg: str) -> None:
    """Emit a debug warning during shutdown without raising."""
    _LOG.debug(msg)


_INSTALLERS = [
    install_openai,
    install_anthropic,
    install_langchain,
    install_langgraph,
    install_langsmith,
    install_openai_agents,
    install_claude_agent_sdk,
    install_pydantic_ai,
    install_elevenlabs,
]


@dataclass
class CatalystTracing:
    """The handle returned by :func:`setup`.

    Hold this for the lifetime of the process and call
    :meth:`shutdown` before exit so the exporter can flush any
    in-flight spans queued by ``BatchSpanProcessor``.

    Attributes
    ----------
    provider : TracerProvider
        The underlying provider. Reach for this only when you need
        an escape hatch — e.g. registering a custom span processor
        for log-shipping or building a sub-tracer for a specific
        module.
    tracer : Tracer
        A pre-configured tracer ready for manual span authoring.
        Pass to :func:`agent_span`, or call ``tracer.start_as_current_span(...)``
        directly for fine-grained control.
    service_name : str
        Resolved ``service.name`` resource attribute. Print this at
        startup; it's the easiest grep handle in the trace viewer.
    endpoint : str
        Resolved OTLP base URL the exporter is shipping to. Doesn't
        include the ``/v1/traces`` suffix.
    installed : list[InstrumentResult]
        Per-SDK install reports. Each entry shows whether the
        instrumentation took (``installed=True``) and, if not, why.
        Useful for debugging in CI / staging when something isn't
        being captured.
    """

    provider: TracerProvider
    tracer: Tracer
    service_name: str
    endpoint: str
    installed: list[InstrumentResult] = field(default_factory=list)

    def shutdown(self) -> None:
        """Force-flush the exporter and tear down the provider.

        Call before your process exits — without it,
        ``BatchSpanProcessor`` may drop the last batch of spans.

        Tolerates transport failures (collector down, network partition,
        etc.) by swallowing exceptions and logging when ``debug=True``.
        The alternative is a process-level uncaught exception at exit,
        which is much worse than a dropped span.
        """
        try:
            self.provider.force_flush()
        except Exception as exc:  # noqa: BLE001 - intentional swallow
            _shutdown_warn(f"flush failed at shutdown: {exc!r}")
        try:
            self.provider.shutdown()
        except Exception as exc:  # noqa: BLE001 - intentional swallow
            _shutdown_warn(f"provider shutdown failed: {exc!r}")


def setup(
    *,
    endpoint: str | None = None,
    token: str | None = None,
    service_name: str | None = None,
    service_version: str | None = None,
    debug: bool | None = None,
    batching: str = BatchingMode.BATCH,
) -> CatalystTracing:
    """Bootstrap catalyst-tracing for a CPython process.

    Resolves config, builds an OTLP/JSON HTTP trace exporter,
    registers a global :class:`TracerProvider`, and installs
    first-party OpenInference-shaped instrumentation for every
    supported LLM/agent SDK that's importable in the current
    environment.

    Every span this package emits carries OpenInference attribute
    keys (``openinference.span.kind``, ``input.value``,
    ``output.value``, ``llm.input_messages.{i}.message.*``,
    ``llm.output_messages.{i}.message.*``, ``llm.token_count.*``,
    ``llm.model_name``, ``llm.system``, ``gen_ai.system``, etc.) so
    OI-aware viewers can render our spans without configuration.

    Parameters
    ----------
    endpoint : str, optional
        OTLP collector URL. Programmatic value beats
        ``CATALYST_OTLP_ENDPOINT`` which beats legacy
        ``OTLP_ENDPOINT`` which falls back to
        ``http://localhost:8799``.
    token : str, optional
        Bearer token for the ingest. Sent as
        ``Authorization: Bearer <token>``. Programmatic > env
        ``CATALYST_OTLP_TOKEN`` > legacy ``OTLP_INGEST_TOKEN``.
    service_name : str, optional
        Resource attribute. Auto-generated as
        ``catalyst-app-<8-hex>`` if not supplied. Programmatic >
        env ``CATALYST_SERVICE_NAME`` > legacy ``SERVICE_NAME``.
    service_version : str, optional
        Resource attribute. Defaults to the SDK package version. Programmatic
        > env ``CATALYST_SERVICE_VERSION``.
    debug : bool, optional
        When True, raises Python's logging level to WARNING so
        OTel warnings (export failures, etc.) become visible.
        Programmatic > env ``CATALYST_DEBUG`` (truthy values:
        ``1``, ``true``, ``yes``).
    batching : {"batch", "simple"}, default "batch"
        Span processor flavor. ``"batch"`` (the default) buffers
        spans for up to 1 second / 64 spans before exporting —
        responsive in scripts but amortizes export overhead in
        production. ``"simple"`` exports synchronously on
        ``span.end()``, useful in tests where you assert on spans
        without waiting for a flush.

    Returns
    -------
    CatalystTracing
        Handle wrapping the provider, a pre-built tracer, and
        ``shutdown()``.

    Examples
    --------
    Bare-minimum setup with one SDK::

        from catalyst_tracing import setup
        from openai import OpenAI

        tracing = setup()
        client = OpenAI(api_key=...)
        client.chat.completions.create(model="gpt-4o-mini", ...)
        tracing.shutdown()

    Production app with explicit config::

        tracing = setup(
            service_name="checkout-api",
            service_version=os.environ["GIT_SHA"],
            endpoint=os.environ["CATALYST_OTLP_ENDPOINT"],
            token=os.environ["CATALYST_OTLP_TOKEN"],
        )
        try:
            run_app()
        finally:
            tracing.shutdown()

    Test setup with synchronous flushes::

        tracing = setup(service_name="test", batching="simple")

    Notes
    -----
    * Calling ``setup()`` twice in the same process logs a warning
      and replaces the existing global provider. This is a
      process-init function; don't call it in a hot path.
    * Auto-detect is the default behavior — at startup ``setup()``
      probes every supported SDK (``openai``, ``anthropic``,
      ``langchain_core``, ``langgraph``, ``langsmith``, ``agents``,
      ``claude_agent_sdk``, ``pydantic_ai``, ``elevenlabs``) and
      installs instrumentation for whichever packages it finds in the import path.
      The result list at
      ``tracing.installed`` shows what got installed and what
      didn't (with a typed ``code`` you can branch on:
      ``"INSTALLED"`` / ``"SDK_NOT_INSTALLED"`` /
      ``"SDK_VERSION_INCOMPATIBLE"``).
    * If you want to skip a specific SDK that *is* installed,
      uninstall the package or use the granular entry-point imports
      (``catalyst_tracing.openai``, etc.) and call them yourself
      against your own ``TracerProvider`` rather than going
      through ``setup()``.
    """
    config = resolve_config(
        endpoint=endpoint,
        token=token,
        service_name=service_name,
        service_version=service_version,
        debug=debug,
    )

    if config.debug:
        logging.basicConfig(level=logging.WARNING)

    headers = (
        {HttpHeader.AUTHORIZATION: f"Bearer {config.token}"} if config.token else None
    )
    exporter = OTLPJsonHttpSpanExporter(
        endpoint=f"{config.endpoint.rstrip('/')}{OtlpPath.TRACES}",
        headers=headers,
    )

    processor: SpanProcessor
    if batching == BatchingMode.SIMPLE:
        processor = SimpleSpanProcessor(exporter)
    else:
        processor = BatchSpanProcessor(
            exporter,
            max_export_batch_size=SpanProcessorDefaults.MAX_EXPORT_BATCH_SIZE,
            schedule_delay_millis=SpanProcessorDefaults.SCHEDULE_DELAY_MILLIS,
        )

    resource = Resource.create(
        {
            ResourceAttribute.SERVICE_NAME: config.service_name,
            ResourceAttribute.SERVICE_VERSION: config.service_version,
        }
    )
    provider = TracerProvider(resource=resource)
    provider.add_span_processor(processor)

    existing = trace_api.get_tracer_provider()
    if not isinstance(existing, trace_api.ProxyTracerProvider):
        _LOG.warning(
            "[catalyst_tracing] a global TracerProvider was already registered; overwriting",
        )
    trace_api.set_tracer_provider(provider)

    installed = [installer(provider) for installer in _INSTALLERS]

    tracer = provider.get_tracer(TracerName.ROOT, PACKAGE_VERSION)

    return CatalystTracing(
        provider=provider,
        tracer=tracer,
        service_name=config.service_name,
        endpoint=config.endpoint,
        installed=installed,
    )
