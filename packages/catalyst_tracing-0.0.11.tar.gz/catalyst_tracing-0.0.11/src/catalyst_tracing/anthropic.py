"""``catalyst_tracing.anthropic`` — granular entry-point import for the
Anthropic integration.

Example::

    from catalyst_tracing import setup
    from catalyst_tracing.anthropic import install_anthropic

    tracing = setup()
    install_anthropic(tracing.provider)
"""

from __future__ import annotations

from .installers.anthropic import install_anthropic

__all__ = ["install_anthropic"]
