"""Wire-format-compatible subset of the OpenInference semantic conventions.

Every catalyst-tracing span carries attributes from this module.
Values are **byte-identical** to the upstream OpenInference
conventions so OI-aware viewers can render our spans without
configuration.

If you're authoring custom spans alongside ours and want them to
appear in the same UI, set these attributes on your span. The
:func:`agent_span` helper does this for you when you wrap a
chunk of work as an AGENT span; for lower-level work, pull from
:class:`Attr` and :class:`SpanKindValues` directly.

Example
-------
Attach OI-shaped attributes to a manual span::

    from opentelemetry import trace
    from catalyst_tracing import Attr, SpanKindValues

    span = trace.get_tracer("my-app").start_span(
        "my-llm-call",
        attributes={
            Attr.SPAN_KIND: SpanKindValues.LLM.value,
            Attr.MODEL_NAME: "gpt-4o-mini",
            Attr.INPUT_VALUE: prompt,
        },
    )
    try:
        out = call_my_llm(prompt)
        span.set_attribute(Attr.OUTPUT_VALUE, out)
        span.set_attribute(Attr.TOKEN_COUNT_TOTAL, 42)
    finally:
        span.end()
"""

from __future__ import annotations

from enum import Enum


class Attr:
    """OpenInference attribute keys our spans carry.

    Class-level constants — use as ``Attr.MODEL_NAME``, etc. The
    string values are the wire keys; downstream viewers index on
    them, so any rename is a wire-format break.
    """

    #: ``openinference.span.kind`` — span kind in OI vocabulary.
    #: See :class:`SpanKindValues` for the canonical string values.
    SPAN_KIND = "openinference.span.kind"
    #: ``input.value`` — full input to the operation as a string.
    #: For LLM spans typically the JSON-stringified request body;
    #: for AGENT spans the user-facing prompt; for TOOL spans the
    #: tool's arguments.
    INPUT_VALUE = "input.value"
    #: ``output.value`` — full output of the operation as a string.
    #: JSON-stringified response body for LLM spans, final text for
    #: AGENT spans.
    OUTPUT_VALUE = "output.value"
    #: ``llm.token_count.prompt`` — prompt token count.
    TOKEN_COUNT_PROMPT = "llm.token_count.prompt"
    #: ``llm.token_count.completion`` — completion token count.
    TOKEN_COUNT_COMPLETION = "llm.token_count.completion"
    #: ``llm.token_count.total`` — combined token count.
    TOKEN_COUNT_TOTAL = "llm.token_count.total"
    #: ``llm.model_name`` — effective model identifier (e.g.
    #: ``"gpt-4o-mini-2024-07-18"``). Prefer the model the API
    #: echoed back over what the consumer requested.
    MODEL_NAME = "llm.model_name"
    #: ``gen_ai.system`` — LLM provider identifier
    #: (``"openai"``, ``"anthropic"``, ``"cohere"``, ...).
    SYSTEM = "gen_ai.system"
    #: ``agent.name`` — logical agent name. Set on AGENT-kind spans
    #: by :func:`agent_span` and the per-SDK wrappers.
    AGENT_NAME = "agent.name"
    #: ``input.mime_type`` — MIME type for ``input.value``.
    INPUT_MIME_TYPE = "input.mime_type"
    #: ``output.mime_type`` — MIME type for ``output.value``.
    OUTPUT_MIME_TYPE = "output.mime_type"
    #: ``llm.invocation_parameters`` — JSON invocation params.
    INVOCATION_PARAMETERS = "llm.invocation_parameters"
    #: ``llm.system`` — provider system on LLM spans.
    LLM_SYSTEM = "llm.system"
    #: ``llm.provider`` — provider identifier on LLM spans.
    LLM_PROVIDER = "llm.provider"
    #: ``llm.streaming`` — whether the call streamed.
    STREAMING = "llm.streaming"
    #: ``llm.finish_reason`` — model finish reason.
    FINISH_REASON = "llm.finish_reason"
    #: ``llm.token_count.prompt_details.cache_write``.
    TOKEN_COUNT_PROMPT_CACHE_WRITE = "llm.token_count.prompt_details.cache_write"
    #: ``llm.token_count.prompt_details.cache_read``.
    TOKEN_COUNT_PROMPT_CACHE_READ = "llm.token_count.prompt_details.cache_read"
    #: ``llm.token_count.completion_details.reasoning``.
    TOKEN_COUNT_COMPLETION_REASONING = "llm.token_count.completion_details.reasoning"
    #: ``tool.name`` — tool span name attribute.
    TOOL_NAME = "tool.name"
    #: ``tool_call.id`` — correlation id for tool-call spans.
    TOOL_CALL_ID = "tool_call.id"
    #: ``agent.tool_call_count`` — aggregate tool call count.
    AGENT_TOOL_CALL_COUNT = "agent.tool_call_count"
    #: ``agent.llm_call_count`` — aggregate LLM call count.
    AGENT_LLM_CALL_COUNT = "agent.llm_call_count"


class SpanKindValues(str, Enum):
    """Canonical string values for :attr:`Attr.SPAN_KIND`.

    Inherits ``str`` so ``SpanKindValues.AGENT == "AGENT"`` —
    convenient for direct use in attribute dicts. Use ``.value``
    when you need the raw string explicitly (e.g. for type
    checkers that flag the enum cast).

    Example
    -------
    ::

        span.set_attribute(Attr.SPAN_KIND, SpanKindValues.AGENT.value)
    """

    #: Top-of-tree span for an agent run.
    AGENT = "AGENT"
    #: A single LLM call (chat completion, embedding, etc.).
    LLM = "LLM"
    #: A tool invocation made by an agent.
    TOOL = "TOOL"
    #: A chain step (LangChain Runnable, Pydantic AI graph node, etc.).
    CHAIN = "CHAIN"
    #: A retriever / vector-search call.
    RETRIEVER = "RETRIEVER"
    #: An embedding-model call.
    EMBEDDING = "EMBEDDING"


class MessageRole:
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    FUNCTION = "function"
    UNKNOWN = "unknown"


class OpenInferenceAttribute:
    @staticmethod
    def input_message_prefix(index: int) -> str:
        return f"llm.input_messages.{index}.message"

    @staticmethod
    def output_message_prefix(index: int) -> str:
        return f"llm.output_messages.{index}.message"

    @staticmethod
    def role(message_prefix: str) -> str:
        return f"{message_prefix}.role"

    @staticmethod
    def content(message_prefix: str) -> str:
        return f"{message_prefix}.content"

    @staticmethod
    def tool_call_id(message_prefix: str) -> str:
        return f"{message_prefix}.tool_call_id"

    @staticmethod
    def tool_call_prefix(message_prefix: str, index: int) -> str:
        return f"{message_prefix}.tool_calls.{index}.tool_call"

    @staticmethod
    def tool_call_function_name(tool_call_prefix: str) -> str:
        return f"{tool_call_prefix}.function.name"

    @staticmethod
    def tool_call_function_arguments(tool_call_prefix: str) -> str:
        return f"{tool_call_prefix}.function.arguments"

    @staticmethod
    def tool_call_identifier(tool_call_prefix: str) -> str:
        return f"{tool_call_prefix}.id"
