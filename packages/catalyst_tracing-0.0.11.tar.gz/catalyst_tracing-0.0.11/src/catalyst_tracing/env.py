"""Resolve catalyst-tracing config from kwargs + env vars."""

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass

from .constants import DefaultConfig, EnvVar


@dataclass(frozen=True)
class ResolvedConfig:
    endpoint: str
    token: str | None
    service_name: str
    service_version: str
    debug: bool


def _truthy(value: str | None) -> bool:
    if value is None or value == "":
        return False
    return value.lower() not in {"0", "false", "no"}


def resolve_config(
    *,
    endpoint: str | None = None,
    token: str | None = None,
    service_name: str | None = None,
    service_version: str | None = None,
    debug: bool | None = None,
) -> ResolvedConfig:
    env = os.environ
    resolved_endpoint = (
        endpoint
        or env.get(EnvVar.CATALYST_OTLP_ENDPOINT)
        or env.get(EnvVar.LEGACY_OTLP_ENDPOINT)
        or DefaultConfig.OTLP_ENDPOINT
    )
    resolved_token = (
        token
        or env.get(EnvVar.CATALYST_OTLP_TOKEN)
        or env.get(EnvVar.LEGACY_OTLP_INGEST_TOKEN)
    )
    resolved_service_name = (
        service_name
        or env.get(EnvVar.CATALYST_SERVICE_NAME)
        or env.get(EnvVar.LEGACY_SERVICE_NAME)
        or f"{DefaultConfig.SERVICE_NAME_PREFIX}-{uuid.uuid4().hex[:8]}"
    )
    resolved_service_version = (
        service_version
        or env.get(EnvVar.CATALYST_SERVICE_VERSION)
        or DefaultConfig.SERVICE_VERSION
    )
    resolved_debug = (
        debug if debug is not None else _truthy(env.get(EnvVar.CATALYST_DEBUG))
    )
    return ResolvedConfig(
        endpoint=resolved_endpoint,
        token=resolved_token,
        service_name=resolved_service_name,
        service_version=resolved_service_version,
        debug=resolved_debug,
    )
