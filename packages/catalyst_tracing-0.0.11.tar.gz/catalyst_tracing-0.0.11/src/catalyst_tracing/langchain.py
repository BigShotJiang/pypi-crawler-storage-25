"""``catalyst_tracing.langchain`` — granular entry-point import for the
LangChain integration.

Example::

    from catalyst_tracing import setup
    from catalyst_tracing.langchain import install_langchain

    tracing = setup()
    install_langchain(tracing.provider)
"""

from __future__ import annotations

from .installers.langchain import install_langchain

__all__ = ["install_langchain"]
