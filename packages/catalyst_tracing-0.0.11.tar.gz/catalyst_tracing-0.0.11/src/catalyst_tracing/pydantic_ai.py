"""``catalyst_tracing.pydantic_ai`` — granular entry-point import for
the Pydantic-AI passthrough.

Pydantic-AI ships first-party OTel; this helper just calls
``Agent.instrument_all()`` after our :func:`setup` registers the
TracerProvider.

Example::

    from catalyst_tracing import setup
    from catalyst_tracing.pydantic_ai import install_pydantic_ai

    tracing = setup()
    install_pydantic_ai(tracing.provider)
"""

from __future__ import annotations

from .installers.pydantic_ai import install_pydantic_ai

__all__ = ["install_pydantic_ai"]
