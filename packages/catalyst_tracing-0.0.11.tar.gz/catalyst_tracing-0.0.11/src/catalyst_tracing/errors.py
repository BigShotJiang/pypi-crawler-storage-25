"""Catalyst-tracing error types.

Errors raised by this package always extend :class:`CatalystTracingError`
and carry a stable :attr:`~CatalystTracingError.code` string for
programmatic handling. Messages are written for humans — they say what
went wrong AND how to fix it.

Use ``isinstance(err, CatalystTracingError)`` for catch-and-log
policies and the ``code`` field for fine-grained branching.

Example::

    from catalyst_tracing import CatalystTracingError, install_openai

    try:
        install_openai(provider)
    except CatalystTracingError as err:
        if err.code == "ERR_INVALID_TRACER_PROVIDER":
            ...  # actionable handling
        raise
"""

from __future__ import annotations

from typing import Any, Final, Literal

from .constants import InstallerId

CatalystTracingErrorCode = Literal[
    "ERR_INVALID_TRACER_PROVIDER",
    "ERR_INVALID_SDK_INPUT",
]


class CatalystTracingErrorCodes:
    INVALID_TRACER_PROVIDER: CatalystTracingErrorCode = "ERR_INVALID_TRACER_PROVIDER"
    INVALID_SDK_INPUT: CatalystTracingErrorCode = "ERR_INVALID_SDK_INPUT"


class CatalystTracingError(Exception):
    """Base class for every error raised by ``catalyst_tracing``.

    Catch this when you only need "did the package raise?". Subclasses
    exist for the specific failure modes.
    """

    #: Stable, machine-readable code for ``except``-and-branch logic.
    code: CatalystTracingErrorCode

    def __init__(self, code: CatalystTracingErrorCode, message: str) -> None:
        super().__init__(message)
        self.code = code


class InvalidTracerProviderError(CatalystTracingError):
    """Raised when an ``install_*`` helper is given something that
    isn't a TracerProvider.

    The Python install helpers consistently take a TracerProvider
    (matching the OTel SDK's idiom). If you pass a Tracer, a string,
    or ``None``, you get this error pointing at the call site rather
    than a confusing AttributeError deep in the patcher.
    """

    INTEGRATION_HINTS: Final[dict[str, str]] = {
        InstallerId.OPENAI: "install_openai(provider)",
        InstallerId.ANTHROPIC: "install_anthropic(provider)",
        InstallerId.LANGCHAIN: "install_langchain(provider)",
        InstallerId.LANGGRAPH: "install_langgraph(provider)",
        InstallerId.LANGSMITH: "install_langsmith(provider)",
        InstallerId.OPENAI_AGENTS: "install_openai_agents(provider)",
        InstallerId.CLAUDE_AGENT_SDK: "install_claude_agent_sdk(provider)",
        InstallerId.PYDANTIC_AI: "install_pydantic_ai(provider)",
    }

    def __init__(self, integration: str, received: Any) -> None:
        hint = self.INTEGRATION_HINTS.get(
            integration,
            f"install_{integration}(provider)",
        )
        super().__init__(
            CatalystTracingErrorCodes.INVALID_TRACER_PROVIDER,
            f"install_{integration}: expected a TracerProvider "
            f"(from `opentelemetry.sdk.trace`), got {_describe(received)}.\n"
            f"Hint: pass `tracing.provider` from `setup()`, or your own "
            f"`TracerProvider`: `{hint}`.",
        )
        self.integration = integration


class InvalidSdkInputError(CatalystTracingError):
    """Raised when an ``install_*`` helper that takes an SDK module
    is given a non-module / wrong-shape argument."""

    def __init__(
        self,
        *,
        integration: str,
        expectation: str,
        received: Any,
        fix_hint: str,
    ) -> None:
        super().__init__(
            CatalystTracingErrorCodes.INVALID_SDK_INPUT,
            f"install_{integration}: {expectation}, got {_describe(received)}.\n"
            f"Hint: {fix_hint}",
        )
        self.integration = integration


def _describe(value: Any) -> str:
    """Short, human-friendly description of a value for error text.

    We avoid logging the full value (potentially huge / contains
    secrets); just enough context for the user to recognize what they
    passed.
    """
    if value is None:
        return "None"
    if isinstance(value, type):
        return f"class {value.__name__}"
    if callable(value):
        name = getattr(value, "__name__", None) or "anonymous"
        return f"callable `{name}`"
    if isinstance(value, dict):
        keys = list(value)[:4]
        if not keys:
            return "an empty dict"
        suffix = ", ..." if len(value) > 4 else ""
        return f"dict with keys {keys}{suffix}"
    type_name = type(value).__name__
    if isinstance(value, (str, int, float, bool)):
        return f"{type_name} {value!r}"
    return type_name
