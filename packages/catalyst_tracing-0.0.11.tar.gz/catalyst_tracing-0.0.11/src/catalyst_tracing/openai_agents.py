"""``catalyst_tracing.openai_agents`` — granular entry-point import for
the ``@openai/agents`` integration.

Example::

    from catalyst_tracing import setup, agent_span
    from catalyst_tracing.openai_agents import install_openai_agents

    tracing = setup()
    install_openai_agents(tracing.provider)

    with agent_span(tracing.tracer, name="MyAgent", system="openai") as span:
        result = Runner.run_sync(my_agent, prompt)
        span.set_output(result.final_output)
"""

from __future__ import annotations

from .installers.openai_agents import install_openai_agents

__all__ = ["install_openai_agents"]
