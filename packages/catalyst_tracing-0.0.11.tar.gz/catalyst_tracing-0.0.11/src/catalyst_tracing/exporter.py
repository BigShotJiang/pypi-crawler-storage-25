"""OTLP/JSON HTTP span exporter.

The upstream ``opentelemetry-exporter-otlp-proto-http`` package only speaks
OTLP/protobuf. The catalyst ingest server currently accepts OTLP/JSON only.
We bridge the gap by encoding spans with the stock protobuf encoder and
re-emitting the canonical proto3 JSON form via ``google.protobuf.json_format``.

This used to live as ``otlp_json.py`` copy-pasted into every example; it
moves here so consumers don't need to know it exists.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence

import requests
from google.protobuf.json_format import MessageToJson
from opentelemetry.exporter.otlp.proto.common.trace_encoder import encode_spans
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

from .constants import HttpHeader, MimeType


class OTLPJsonHttpSpanExporter(SpanExporter):
    def __init__(
        self,
        *,
        endpoint: str,
        headers: Mapping[str, str] | None = None,
        timeout_seconds: float = 10.0,
    ) -> None:
        self._endpoint = endpoint
        self._headers = {
            **(headers or {}),
            HttpHeader.CONTENT_TYPE: MimeType.JSON,
        }
        self._timeout = timeout_seconds

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        request = encode_spans(spans)
        body = MessageToJson(request).encode("utf-8")
        try:
            response = requests.post(
                self._endpoint,
                data=body,
                headers=self._headers,
                timeout=self._timeout,
            )
            if 200 <= response.status_code < 300:
                return SpanExportResult.SUCCESS
            return SpanExportResult.FAILURE
        except requests.RequestException:
            return SpanExportResult.FAILURE

    def shutdown(self) -> None:
        return None

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        return True
