"""Defensive streaming-response accumulators.

Every read from upstream stream chunks is wrapped in a type guard +
``try``/``except`` boundary so unexpected shapes — a renamed field, a
type change, a removed property, an extra unknown property — never
escape into the user's iterator.

The contract this module enforces, with property-based tests:

  * **Removed expected property** → no error, we keep accumulating
    whatever else the chunk carries.
  * **Added unexpected property** → silently ignored (we never
    enumerate keys, we read the ones we know about).
  * **Type change on an expected field** → type-checked on every
    read, the field is skipped if it isn't the type we can handle.
    No coercion, no crash.
  * **Internal accumulator bug** → caught at the per-chunk boundary
    so the user's stream keeps flowing.

The Python and TS implementations track each other closely so traces
look the same regardless of which language emitted them.
"""

from __future__ import annotations

import logging
from typing import Any

from opentelemetry.trace import Span, Status, StatusCode

from ..semconv import Attr, MessageRole, OpenInferenceAttribute

_LOG = logging.getLogger("catalyst_tracing.streaming")


class OpenAIStreamAccumulator:
    """Accumulates one streaming chat-completions response."""

    def __init__(self) -> None:
        self._text = ""
        self._tool_calls: dict[int, dict[str, Any]] = {}
        self._finish_reason: str | None = None
        self._model: str | None = None
        self._prompt_tokens: int | None = None
        self._completion_tokens: int | None = None
        self._total_tokens: int | None = None

    def ingest(self, chunk: Any) -> None:
        """Read whatever fields we know about; swallow any failure."""
        try:
            self._ingest_unchecked(chunk)
        except Exception as exc:  # noqa: BLE001 - intentional swallow
            _LOG.debug("ingest swallowed exception: %r", exc)

    def _ingest_unchecked(self, chunk: Any) -> None:
        body = _to_dict_or_none(chunk)
        if body is None:
            return
        model = body.get("model")
        if isinstance(model, str):
            self._model = model
        usage = body.get("usage")
        if isinstance(usage, dict):
            pt = usage.get("prompt_tokens")
            ct = usage.get("completion_tokens")
            tt = usage.get("total_tokens")
            if isinstance(pt, int):
                self._prompt_tokens = pt
            if isinstance(ct, int):
                self._completion_tokens = ct
            if isinstance(tt, int):
                self._total_tokens = tt
        choices = body.get("choices")
        if not isinstance(choices, list):
            return
        for choice in choices:
            self._ingest_choice(choice)

    def _ingest_choice(self, choice: Any) -> None:
        ch = _to_dict_or_none(choice)
        if ch is None:
            return
        fr = ch.get("finish_reason")
        if isinstance(fr, str):
            self._finish_reason = fr
        delta = ch.get("delta")
        d = _to_dict_or_none(delta)
        if d is None:
            return
        content = d.get("content")
        if isinstance(content, str):
            self._text += content
        tcs = d.get("tool_calls")
        if isinstance(tcs, list):
            for tc in tcs:
                self._ingest_tool_call(tc)

    def _ingest_tool_call(self, tc: Any) -> None:
        t = _to_dict_or_none(tc)
        if t is None:
            return
        idx_raw = t.get("index")
        idx = idx_raw if isinstance(idx_raw, int) else 0
        entry = self._tool_calls.setdefault(idx, {"arguments": ""})
        if isinstance(t.get("id"), str):
            entry["id"] = t["id"]
        fn = _to_dict_or_none(t.get("function"))
        if fn is not None:
            if isinstance(fn.get("name"), str):
                entry["name"] = fn["name"]
            if isinstance(fn.get("arguments"), str):
                entry["arguments"] += fn["arguments"]

    def apply_to(self, span: Span) -> None:
        """Apply accumulated state as OI attributes. Never raises."""
        try:
            self._apply_unchecked(span)
        except Exception as exc:  # noqa: BLE001 - intentional swallow
            _LOG.debug("apply_to swallowed exception: %r", exc)

    def _apply_unchecked(self, span: Span) -> None:
        if self._model is not None:
            span.set_attribute(Attr.MODEL_NAME, self._model)
        if self._text:
            prefix = OpenInferenceAttribute.output_message_prefix(0)
            span.set_attribute(OpenInferenceAttribute.role(prefix), MessageRole.ASSISTANT)
            span.set_attribute(OpenInferenceAttribute.content(prefix), self._text)
        if self._finish_reason is not None:
            span.set_attribute(Attr.FINISH_REASON, self._finish_reason)
        if self._prompt_tokens is not None:
            span.set_attribute(Attr.TOKEN_COUNT_PROMPT, self._prompt_tokens)
        if self._completion_tokens is not None:
            span.set_attribute(Attr.TOKEN_COUNT_COMPLETION, self._completion_tokens)
        if self._total_tokens is not None:
            span.set_attribute(Attr.TOKEN_COUNT_TOTAL, self._total_tokens)
        for i, tc in enumerate(self._tool_calls.values()):
            prefix = OpenInferenceAttribute.tool_call_prefix(
                OpenInferenceAttribute.output_message_prefix(0),
                i,
            )
            if "name" in tc:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_function_name(prefix),
                    tc["name"],
                )
            args = tc.get("arguments", "")
            if isinstance(args, str) and args:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_function_arguments(prefix),
                    args,
                )
            if "id" in tc:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_identifier(prefix),
                    tc["id"],
                )


class AnthropicStreamAccumulator:
    """Accumulates one streaming Messages response (event-typed)."""

    def __init__(self) -> None:
        self._model: str | None = None
        self._text = ""
        self._tool_uses: dict[int, dict[str, Any]] = {}
        self._stop_reason: str | None = None
        self._input_tokens: int | None = None
        self._output_tokens: int | None = None
        self._cache_creation: int | None = None
        self._cache_read: int | None = None

    def ingest(self, event: Any) -> None:
        try:
            self._ingest_unchecked(event)
        except Exception as exc:  # noqa: BLE001
            _LOG.debug("anthropic ingest swallowed: %r", exc)

    def _ingest_unchecked(self, event: Any) -> None:
        e = _to_dict_or_none(event)
        if e is None:
            return
        t = e.get("type")
        if t == "message_start":
            msg = _to_dict_or_none(e.get("message"))
            if msg is None:
                return
            if isinstance(msg.get("model"), str):
                self._model = msg["model"]
            self._ingest_usage(msg.get("usage"))
            return
        if t == "content_block_start":
            idx_raw = e.get("index")
            idx = idx_raw if isinstance(idx_raw, int) else 0
            block = _to_dict_or_none(e.get("content_block"))
            if block is None:
                return
            if block.get("type") == "tool_use":
                entry = self._tool_uses.setdefault(idx, {"partial_json": ""})
                if isinstance(block.get("id"), str):
                    entry["id"] = block["id"]
                if isinstance(block.get("name"), str):
                    entry["name"] = block["name"]
            return
        if t == "content_block_delta":
            idx_raw = e.get("index")
            idx = idx_raw if isinstance(idx_raw, int) else 0
            delta = _to_dict_or_none(e.get("delta"))
            if delta is None:
                return
            dt = delta.get("type")
            if dt == "text_delta" and isinstance(delta.get("text"), str):
                self._text += delta["text"]
                return
            if dt == "input_json_delta" and isinstance(
                delta.get("partial_json"),
                str,
            ):
                entry = self._tool_uses.setdefault(idx, {"partial_json": ""})
                entry["partial_json"] += delta["partial_json"]
                return
            return
        if t == "message_delta":
            delta = _to_dict_or_none(e.get("delta"))
            if delta is not None and isinstance(delta.get("stop_reason"), str):
                self._stop_reason = delta["stop_reason"]
            self._ingest_usage(e.get("usage"))
            return

    def _ingest_usage(self, u: Any) -> None:
        ud = _to_dict_or_none(u)
        if ud is None:
            return
        if isinstance(ud.get("input_tokens"), int):
            self._input_tokens = ud["input_tokens"]
        if isinstance(ud.get("output_tokens"), int):
            self._output_tokens = ud["output_tokens"]
        if isinstance(ud.get("cache_creation_input_tokens"), int):
            self._cache_creation = ud["cache_creation_input_tokens"]
        if isinstance(ud.get("cache_read_input_tokens"), int):
            self._cache_read = ud["cache_read_input_tokens"]

    def apply_to(self, span: Span) -> None:
        try:
            self._apply_unchecked(span)
        except Exception as exc:  # noqa: BLE001
            _LOG.debug("anthropic apply_to swallowed: %r", exc)

    def _apply_unchecked(self, span: Span) -> None:
        if self._model is not None:
            span.set_attribute(Attr.MODEL_NAME, self._model)
        if self._text:
            prefix = OpenInferenceAttribute.output_message_prefix(0)
            span.set_attribute(OpenInferenceAttribute.role(prefix), MessageRole.ASSISTANT)
            span.set_attribute(OpenInferenceAttribute.content(prefix), self._text)
        if self._stop_reason is not None:
            span.set_attribute(Attr.FINISH_REASON, self._stop_reason)
        cache_write = self._cache_creation or 0
        cache_read = self._cache_read or 0
        if self._input_tokens is not None:
            span.set_attribute(
                Attr.TOKEN_COUNT_PROMPT,
                self._input_tokens + cache_write + cache_read,
            )
        if self._output_tokens is not None:
            span.set_attribute(Attr.TOKEN_COUNT_COMPLETION, self._output_tokens)
        if self._input_tokens is not None and self._output_tokens is not None:
            span.set_attribute(
                Attr.TOKEN_COUNT_TOTAL,
                self._input_tokens + cache_write + cache_read + self._output_tokens,
            )
        if self._cache_creation is not None:
            span.set_attribute(
                Attr.TOKEN_COUNT_PROMPT_CACHE_WRITE,
                self._cache_creation,
            )
        if self._cache_read is not None:
            span.set_attribute(
                Attr.TOKEN_COUNT_PROMPT_CACHE_READ,
                self._cache_read,
            )
        for i, tu in enumerate(self._tool_uses.values()):
            prefix = OpenInferenceAttribute.tool_call_prefix(
                OpenInferenceAttribute.output_message_prefix(0),
                i,
            )
            if "name" in tu:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_function_name(prefix),
                    tu["name"],
                )
            partial = tu.get("partial_json", "")
            if isinstance(partial, str) and partial:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_function_arguments(prefix),
                    partial,
                )
            if "id" in tu:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_identifier(prefix),
                    tu["id"],
                )


def wrap_stream_iter(upstream: Any, span: Span, accumulator: Any) -> Any:
    """Generator wrapper for SYNC iterables — yields each chunk after
    feeding it to the accumulator. On stream end (success or error)
    the accumulator is applied to the span and the span is closed.
    """

    def _generator():  # type: ignore[no-untyped-def]
        errored = False
        try:
            for chunk in upstream:
                accumulator.ingest(chunk)
                yield chunk
        except Exception as err:
            errored = True
            accumulator.apply_to(span)
            span.record_exception(err)
            span.set_status(Status(StatusCode.ERROR, str(err)))
            raise
        finally:
            if not errored:
                accumulator.apply_to(span)
                span.set_status(Status(StatusCode.OK))
            span.end()

    return _generator()


async def wrap_async_stream_iter(
    upstream: Any,
    span: Span,
    accumulator: Any,
):
    """Async-iterable variant of :func:`wrap_stream_iter`."""
    errored = False
    try:
        async for chunk in upstream:
            accumulator.ingest(chunk)
            yield chunk
    except Exception as err:
        errored = True
        accumulator.apply_to(span)
        span.record_exception(err)
        span.set_status(Status(StatusCode.ERROR, str(err)))
        raise
    finally:
        if not errored:
            accumulator.apply_to(span)
            span.set_status(Status(StatusCode.OK))
        span.end()


def _to_dict_or_none(value: Any) -> dict[str, Any] | None:
    """Return a dict view of ``value`` if possible, else None.

    Accepts:
      * raw dicts → returned as-is
      * pydantic models with ``.model_dump()`` → dumped to dict
      * objects with ``.to_dict()`` → converted
      * everything else → ``None`` (we won't try to read it)

    Never raises. Cyclic dicts are handled (we read top-level keys
    only without recursing).
    """
    if isinstance(value, dict):
        return value
    if value is None:
        return None
    dump = getattr(value, "model_dump", None)
    if callable(dump):
        try:
            d = dump()
            if isinstance(d, dict):
                return d
        except Exception:  # noqa: BLE001
            return None
    to_dict = getattr(value, "to_dict", None)
    if callable(to_dict):
        try:
            d = to_dict()
            if isinstance(d, dict):
                return d
        except Exception:  # noqa: BLE001
            return None
    return None
