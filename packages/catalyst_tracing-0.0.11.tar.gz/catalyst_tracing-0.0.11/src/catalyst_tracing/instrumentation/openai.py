"""First-party OpenAI auto-instrumentation.

Replaces ``openinference-instrumentation-openai`` for the methods our
examples and the openai-agents SDK exercise: chat.completions.create
and responses.create (sync + async).

Wire format matches OpenInference conventions byte-for-byte
(``openinference.span.kind=LLM``, ``input.value`` /
``llm.input_messages.*``, ``output.value`` /
``llm.output_messages.*``, ``llm.invocation_parameters``,
``llm.model_name``, ``llm.token_count.*``) so OI-aware viewers
keep rendering catalyst spans unchanged.

Strategy: patch the resource classes' ``create`` methods on the
class itself (Python class methods are mutable). Every existing and
future ``OpenAI(...)`` client instance shares those classes via the
attribute access ``client.chat.completions`` / ``client.responses``.
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from typing import Any

from opentelemetry.trace import (
    SpanKind,
    Status,
    StatusCode,
    Tracer,
)

from ..constants import (
    PATCH_MARKER_ATTR,
    GenAISystem,
    MimeType,
    PatchedMethod,
    SpanName,
)
from ..semconv import Attr, MessageRole, OpenInferenceAttribute, SpanKindValues
from .stream_accumulator import (
    OpenAIStreamAccumulator,
    wrap_async_stream_iter,
    wrap_stream_iter,
)

# Per-class tracer registry. The wrap closures look up the tracer
# at call time, so re-installing with a different tracer (typically
# in tests with InMemorySpanExporter) updates the registry entry
# without re-wrapping the class method. That avoids a double-wrap
# stack where the second wrap's `original` is the first wrap and
# the first wrap's tracer points at a torn-down provider.
#
# We mark the wrapped method itself with a `_catalyst_wrapped`
# attribute so we can detect "already patched" without a separate
# global set — that way callers can't accidentally cause a
# double-wrap by clearing a side-channel set.
_TRACERS: dict[int, Tracer] = {}
# Kept as an alias for backwards-compat with tests that referenced
# `_PATCHED` directly. New code should use `_TRACERS` and the
# function-attribute marker.
_PATCHED: set[int] = set()


def install_openai_instrumentation(tracer: Tracer) -> bool:
    """Patch OpenAI's resource classes. Returns True if anything was patched."""
    installed_any = False

    try:
        from openai.resources.chat.completions import (
            AsyncCompletions,
            Completions,
        )

        installed_any |= _patch_class(
            Completions,
            PatchedMethod.CREATE,
            SpanName.OPENAI_CHAT_COMPLETIONS,
            tracer,
            "chat",
            is_async=False,
        )
        installed_any |= _patch_class(
            AsyncCompletions,
            PatchedMethod.CREATE,
            SpanName.OPENAI_CHAT_COMPLETIONS,
            tracer,
            "chat",
            is_async=True,
        )
    except ImportError:
        pass

    try:
        from openai.resources.responses import AsyncResponses, Responses

        installed_any |= _patch_class(
            Responses,
            PatchedMethod.CREATE,
            SpanName.OPENAI_RESPONSES,
            tracer,
            "responses",
            is_async=False,
        )
        installed_any |= _patch_class(
            AsyncResponses,
            PatchedMethod.CREATE,
            SpanName.OPENAI_RESPONSES,
            tracer,
            "responses",
            is_async=True,
        )
    except ImportError:
        pass

    return installed_any


def _patch_class(
    cls: type,
    method_name: str,
    span_name: str,
    tracer: Tracer,
    shape: str,
    *,
    is_async: bool,
) -> bool:
    # Always update the tracer registry — re-installation rebinds
    # where spans flow without re-wrapping.
    _TRACERS[id(cls)] = tracer
    current = getattr(cls, method_name, None)
    if current is None:
        return False
    # Already wrapped by a previous install? Just rebind tracer above
    # and we're done — the wrap closure reads from _TRACERS at call
    # time, so this single side effect propagates everywhere.
    if getattr(current, PATCH_MARKER_ATTR, False):
        _PATCHED.add(id(cls))
        return True
    if not callable(current):
        return False
    if is_async:
        wrapped = _wrap_async(current, span_name, cls, shape)
    else:
        wrapped = _wrap_sync(current, span_name, cls, shape)
    setattr(wrapped, PATCH_MARKER_ATTR, True)
    setattr(cls, method_name, wrapped)
    _PATCHED.add(id(cls))
    return True


def _wrap_sync(
    original: Callable[..., Any],
    span_name: str,
    cls: type,
    shape: str,
) -> Callable[..., Any]:
    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = _TRACERS.get(id(cls))
        if tracer is None:
            return original(self, *args, **kwargs)
        is_stream = bool(kwargs.get("stream"))
        attrs = _request_attributes(kwargs, shape, is_stream)

        if is_stream:
            # Streaming path: span lives until the iterator drains.
            # Don't use `with start_as_current_span` (it would close
            # the span when this wrapper returns, before the user has
            # consumed any chunks).
            span = tracer.start_span(
                span_name,
                kind=SpanKind.CLIENT,
                attributes=attrs,
            )
            try:
                upstream = original(self, *args, **kwargs)
            except Exception as err:
                span.record_exception(err)
                span.set_status(Status(StatusCode.ERROR, str(err)))
                span.end()
                raise
            if _called_from_streaming_response_wrapper(kwargs):
                return _wrap_raw_streaming_response_parse(
                    upstream,
                    span,
                    OpenAIStreamAccumulator(),
                )
            return wrap_stream_iter(upstream, span, OpenAIStreamAccumulator())

        with tracer.start_as_current_span(
            span_name,
            kind=SpanKind.CLIENT,
            attributes=attrs,
        ) as span:
            try:
                resp = original(self, *args, **kwargs)
                _apply_response(span, resp, shape)
                span.set_status(Status(StatusCode.OK))
                return resp
            except Exception as err:
                span.record_exception(err)
                span.set_status(Status(StatusCode.ERROR, str(err)))
                raise

    return wrapped


def _wrap_async(
    original: Callable[..., Awaitable[Any]],
    span_name: str,
    cls: type,
    shape: str,
) -> Callable[..., Awaitable[Any]]:
    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = _TRACERS.get(id(cls))
        if tracer is None:
            return await original(self, *args, **kwargs)
        is_stream = bool(kwargs.get("stream"))
        attrs = _request_attributes(kwargs, shape, is_stream)

        if is_stream:
            span = tracer.start_span(
                span_name,
                kind=SpanKind.CLIENT,
                attributes=attrs,
            )
            try:
                upstream = await original(self, *args, **kwargs)
            except Exception as err:
                span.record_exception(err)
                span.set_status(Status(StatusCode.ERROR, str(err)))
                span.end()
                raise
            if _called_from_streaming_response_wrapper(kwargs):
                return _wrap_async_raw_streaming_response_parse(
                    upstream,
                    span,
                    OpenAIStreamAccumulator(),
                )
            return wrap_async_stream_iter(
                upstream,
                span,
                OpenAIStreamAccumulator(),
            )

        with tracer.start_as_current_span(
            span_name,
            kind=SpanKind.CLIENT,
            attributes=attrs,
        ) as span:
            try:
                resp = await original(self, *args, **kwargs)
                _apply_response(span, resp, shape)
                span.set_status(Status(StatusCode.OK))
                return resp
            except Exception as err:
                span.record_exception(err)
                span.set_status(Status(StatusCode.ERROR, str(err)))
                raise

    return wrapped


def _called_from_streaming_response_wrapper(kwargs: dict[str, Any]) -> bool:
    extra_headers = kwargs.get("extra_headers")
    if not isinstance(extra_headers, dict):
        return False
    return extra_headers.get("X-Stainless-Raw-Response") == "stream"


def _wrap_raw_streaming_response_parse(
    response: Any,
    span: Any,
    accumulator: Any,
) -> Any:
    parse = getattr(response, "parse", None)
    if not callable(parse):
        span.end()
        return response

    ended = False

    def end_once() -> None:
        nonlocal ended
        if not ended:
            ended = True
            span.end()

    def parse_wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            upstream = parse(*args, **kwargs)
        except Exception as err:
            accumulator.apply_to(span)
            span.record_exception(err)
            span.set_status(Status(StatusCode.ERROR, str(err)))
            end_once()
            raise
        return _wrap_stream_iter_once(upstream, span, accumulator, end_once)

    close = getattr(response, "close", None)
    if callable(close):

        def close_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return close(*args, **kwargs)
            finally:
                end_once()

        response.close = close_wrapper

    response.parse = parse_wrapper
    return response


def _wrap_stream_iter_once(
    upstream: Any,
    span: Any,
    accumulator: Any,
    end_once: Callable[[], None],
) -> Any:
    def _generator():  # type: ignore[no-untyped-def]
        errored = False
        try:
            for chunk in upstream:
                accumulator.ingest(chunk)
                yield chunk
        except Exception as err:
            errored = True
            accumulator.apply_to(span)
            span.record_exception(err)
            span.set_status(Status(StatusCode.ERROR, str(err)))
            raise
        finally:
            if not errored:
                accumulator.apply_to(span)
                span.set_status(Status(StatusCode.OK))
            end_once()

    return _generator()


def _wrap_async_raw_streaming_response_parse(
    response: Any,
    span: Any,
    accumulator: Any,
) -> Any:
    parse = getattr(response, "parse", None)
    if not callable(parse):
        span.end()
        return response

    ended = False

    def end_once() -> None:
        nonlocal ended
        if not ended:
            ended = True
            span.end()

    async def parse_wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            upstream = await parse(*args, **kwargs)
        except Exception as err:
            accumulator.apply_to(span)
            span.record_exception(err)
            span.set_status(Status(StatusCode.ERROR, str(err)))
            end_once()
            raise
        return _wrap_async_stream_iter_once(upstream, span, accumulator, end_once)

    close = getattr(response, "close", None)
    if callable(close):

        async def close_wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return await close(*args, **kwargs)
            finally:
                end_once()

        response.close = close_wrapper

    response.parse = parse_wrapper
    return response


async def _wrap_async_stream_iter_once(
    upstream: Any,
    span: Any,
    accumulator: Any,
    end_once: Callable[[], None],
):
    errored = False
    try:
        async for chunk in upstream:
            accumulator.ingest(chunk)
            yield chunk
    except Exception as err:
        errored = True
        accumulator.apply_to(span)
        span.record_exception(err)
        span.set_status(Status(StatusCode.ERROR, str(err)))
        raise
    finally:
        if not errored:
            accumulator.apply_to(span)
            span.set_status(Status(StatusCode.OK))
        end_once()


_PARAM_KEYS = (
    "model",
    "max_tokens",
    "max_completion_tokens",
    "temperature",
    "top_p",
    "tools",
    "tool_choice",
    "response_format",
)


def _request_attributes(
    kwargs: dict[str, Any],
    shape: str,
    is_stream: bool,
) -> dict[str, Any]:
    out: dict[str, Any] = {
        Attr.SPAN_KIND: SpanKindValues.LLM.value,
        Attr.LLM_SYSTEM: GenAISystem.OPENAI,
        Attr.LLM_PROVIDER: GenAISystem.OPENAI,
        Attr.INPUT_VALUE: json.dumps(kwargs, default=str),
        Attr.INPUT_MIME_TYPE: MimeType.JSON,
    }
    model = kwargs.get("model")
    if model is not None:
        out[Attr.MODEL_NAME] = str(model)
    if is_stream:
        out[Attr.STREAMING] = "true"
    params = {k: kwargs[k] for k in _PARAM_KEYS if k in kwargs and kwargs[k] is not None}
    if params:
        out[Attr.INVOCATION_PARAMETERS] = json.dumps(params, default=str)
    if shape == "chat":
        for i, m in enumerate(kwargs.get("messages") or []):
            role = m.get("role") if isinstance(m, dict) else getattr(m, "role", None)
            content = (
                m.get("content") if isinstance(m, dict) else getattr(m, "content", None)
            )
            if role is not None:
                prefix = OpenInferenceAttribute.input_message_prefix(i)
                out[OpenInferenceAttribute.role(prefix)] = str(role)
            if content is not None:
                prefix = OpenInferenceAttribute.input_message_prefix(i)
                out[OpenInferenceAttribute.content(prefix)] = _stringify(content)
            # Echo tool_calls / tool_call_id on the input messages so
            # multi-turn agent loops show what the model called and
            # which tool result corresponds to which call.
            tool_calls = (
                m.get("tool_calls")
                if isinstance(m, dict)
                else getattr(m, "tool_calls", None)
            )
            if tool_calls:
                _write_tool_calls(
                    out,
                    OpenInferenceAttribute.input_message_prefix(i),
                    tool_calls,
                )
            tool_call_id = (
                m.get("tool_call_id")
                if isinstance(m, dict)
                else getattr(m, "tool_call_id", None)
            )
            if tool_call_id is not None:
                prefix = OpenInferenceAttribute.input_message_prefix(i)
                out[OpenInferenceAttribute.tool_call_id(prefix)] = str(tool_call_id)
    elif shape == "responses":
        inp = kwargs.get("input")
        if inp is not None:
            prefix = OpenInferenceAttribute.input_message_prefix(0)
            out[OpenInferenceAttribute.role(prefix)] = MessageRole.USER
            out[OpenInferenceAttribute.content(prefix)] = _stringify(inp)
    return out


def _apply_response(span: Any, resp: Any, shape: str) -> None:
    if resp is None:
        return
    body = _to_dict(resp)
    span.set_attribute(Attr.OUTPUT_VALUE, json.dumps(body, default=str))
    span.set_attribute(Attr.OUTPUT_MIME_TYPE, MimeType.JSON)
    model = body.get("model") if isinstance(body, dict) else None
    if model is not None:
        span.set_attribute(Attr.MODEL_NAME, str(model))
    usage = body.get("usage") if isinstance(body, dict) else None
    if isinstance(usage, dict):
        if "prompt_tokens" in usage and usage["prompt_tokens"] is not None:
            span.set_attribute(Attr.TOKEN_COUNT_PROMPT, usage["prompt_tokens"])
        elif "input_tokens" in usage and usage["input_tokens"] is not None:
            span.set_attribute(Attr.TOKEN_COUNT_PROMPT, usage["input_tokens"])
        if "completion_tokens" in usage and usage["completion_tokens"] is not None:
            span.set_attribute(Attr.TOKEN_COUNT_COMPLETION, usage["completion_tokens"])
        elif "output_tokens" in usage and usage["output_tokens"] is not None:
            span.set_attribute(Attr.TOKEN_COUNT_COMPLETION, usage["output_tokens"])
        if "total_tokens" in usage and usage["total_tokens"] is not None:
            span.set_attribute(Attr.TOKEN_COUNT_TOTAL, usage["total_tokens"])
        prompt_details = usage.get("prompt_tokens_details")
        if not isinstance(prompt_details, dict):
            prompt_details = usage.get("input_tokens_details")
        if (
            isinstance(prompt_details, dict)
            and prompt_details.get("cached_tokens") is not None
        ):
            span.set_attribute(
                Attr.TOKEN_COUNT_PROMPT_CACHE_READ,
                prompt_details["cached_tokens"],
            )
        completion_details = usage.get("completion_tokens_details")
        if not isinstance(completion_details, dict):
            completion_details = usage.get("output_tokens_details")
        if (
            isinstance(completion_details, dict)
            and completion_details.get("reasoning_tokens") is not None
        ):
            span.set_attribute(
                Attr.TOKEN_COUNT_COMPLETION_REASONING,
                completion_details["reasoning_tokens"],
            )
    if shape == "chat":
        choices = body.get("choices") if isinstance(body, dict) else None
        if isinstance(choices, list):
            for i, c in enumerate(choices):
                msg = c.get("message", {}) if isinstance(c, dict) else {}
                role = msg.get("role")
                content = msg.get("content")
                if role is not None:
                    prefix = OpenInferenceAttribute.output_message_prefix(i)
                    span.set_attribute(OpenInferenceAttribute.role(prefix), str(role))
                if content is not None:
                    prefix = OpenInferenceAttribute.output_message_prefix(i)
                    span.set_attribute(
                        OpenInferenceAttribute.content(prefix),
                        _stringify(content),
                    )
                tool_calls = msg.get("tool_calls")
                if tool_calls:
                    _write_tool_calls_to_span(
                        span,
                        OpenInferenceAttribute.output_message_prefix(i),
                        tool_calls,
                    )
                fr = c.get("finish_reason") if isinstance(c, dict) else None
                if fr is not None:
                    span.set_attribute(Attr.FINISH_REASON, str(fr))
    elif shape == "responses":
        # Prefer the SDK-derived `output_text` (a string) when it's
        # present on the dict. It often isn't — `output_text` is a
        # computed property on the Pydantic model that doesn't survive
        # `model_dump()`. Fall back to walking the `output` array and
        # collecting text from `output_text` content blocks under any
        # `message`-typed item, which is what the SDK does internally.
        output = body.get("output") if isinstance(body, dict) else None
        ot = body.get("output_text") if isinstance(body, dict) else None
        if isinstance(ot, str) and ot != "":
            prefix = OpenInferenceAttribute.output_message_prefix(0)
            span.set_attribute(OpenInferenceAttribute.role(prefix), MessageRole.ASSISTANT)
            span.set_attribute(OpenInferenceAttribute.content(prefix), ot)
        else:
            text = _extract_responses_text(output)
            if text is not None:
                prefix = OpenInferenceAttribute.output_message_prefix(0)
                span.set_attribute(
                    OpenInferenceAttribute.role(prefix),
                    MessageRole.ASSISTANT,
                )
                span.set_attribute(OpenInferenceAttribute.content(prefix), text)
            elif output is not None:
                # No text blocks — fall back to stringifying the whole
                # output array so something is captured.
                prefix = OpenInferenceAttribute.output_message_prefix(0)
                span.set_attribute(
                    OpenInferenceAttribute.role(prefix),
                    MessageRole.ASSISTANT,
                )
                span.set_attribute(
                    OpenInferenceAttribute.content(prefix),
                    _stringify(output),
                )
        # Capture function_call items from the Responses output as
        # tool_calls under the same OI prefix as chat completions, so
        # the trace viewer renders both shapes the same way.
        if isinstance(output, list):
            fc_idx = 0
            for item in output:
                if not isinstance(item, dict):
                    continue
                if item.get("type") != "function_call":
                    continue
                prefix = OpenInferenceAttribute.tool_call_prefix(
                    OpenInferenceAttribute.output_message_prefix(0),
                    fc_idx,
                )
                if item.get("name") is not None:
                    span.set_attribute(
                        OpenInferenceAttribute.tool_call_function_name(prefix),
                        str(item["name"]),
                    )
                if item.get("arguments") is not None:
                    span.set_attribute(
                        OpenInferenceAttribute.tool_call_function_arguments(prefix),
                        str(item["arguments"]),
                    )
                call_id = item.get("call_id") or item.get("id")
                if call_id is not None:
                    span.set_attribute(
                        OpenInferenceAttribute.tool_call_identifier(prefix),
                        str(call_id),
                    )
                fc_idx += 1


def _extract_responses_text(output: Any) -> str | None:
    """Walk an OpenAI Responses-API `output` array and concatenate
    every `output_text` content block. Returns None if the structure
    doesn't match the expected shape."""
    if not isinstance(output, list):
        return None
    parts: list[str] = []
    for item in output:
        if not isinstance(item, dict):
            continue
        if item.get("type") != "message":
            continue
        for block in item.get("content") or []:
            if not isinstance(block, dict):
                continue
            if block.get("type") == "output_text" and isinstance(block.get("text"), str):
                parts.append(block["text"])
    return "".join(parts) if parts else None


def _to_dict(value: Any) -> Any:
    """Best-effort conversion to a serializable dict. OpenAI v1 returns
    Pydantic models with a model_dump() helper."""
    if hasattr(value, "model_dump"):
        try:
            return value.model_dump()
        except Exception:
            pass
    if hasattr(value, "to_dict"):
        try:
            return value.to_dict()
        except Exception:
            pass
    if isinstance(value, dict):
        return value
    return value


def _stringify(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, default=str)


def _write_tool_calls(
    out: dict[str, Any],
    prefix: str,
    tool_calls: Any,
) -> None:
    """Mirror tool_calls onto a request-attribute dict at ``prefix``.

    Used when emitting `llm.input_messages.{i}.message.tool_calls.*`
    from request kwargs (where the wrap closure builds attributes
    before the span exists).
    """
    if not isinstance(tool_calls, list):
        return
    for j, tc in enumerate(tool_calls):
        if not isinstance(tc, dict):
            # Pydantic model — fall back to attribute access.
            tc = _to_dict(tc) if hasattr(tc, "model_dump") else None
            if not isinstance(tc, dict):
                continue
        fn = tc.get("function") if isinstance(tc, dict) else None
        tool_call_prefix = OpenInferenceAttribute.tool_call_prefix(prefix, j)
        if isinstance(fn, dict):
            if fn.get("name") is not None:
                out[OpenInferenceAttribute.tool_call_function_name(tool_call_prefix)] = (
                    str(fn["name"])
                )
            if fn.get("arguments") is not None:
                out[
                    OpenInferenceAttribute.tool_call_function_arguments(tool_call_prefix)
                ] = str(fn["arguments"])
        if tc.get("id") is not None:
            out[OpenInferenceAttribute.tool_call_identifier(tool_call_prefix)] = str(
                tc["id"]
            )


def _write_tool_calls_to_span(span: Any, prefix: str, tool_calls: Any) -> None:
    """Same as :func:`_write_tool_calls` but writes to a live span.

    Used when emitting `llm.output_messages.{i}.message.tool_calls.*`
    after the response has come back.
    """
    if not isinstance(tool_calls, list):
        return
    for j, tc in enumerate(tool_calls):
        if not isinstance(tc, dict):
            tc = _to_dict(tc) if hasattr(tc, "model_dump") else None
            if not isinstance(tc, dict):
                continue
        fn = tc.get("function") if isinstance(tc, dict) else None
        tool_call_prefix = OpenInferenceAttribute.tool_call_prefix(prefix, j)
        if isinstance(fn, dict):
            if fn.get("name") is not None:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_function_name(tool_call_prefix),
                    str(fn["name"]),
                )
            if fn.get("arguments") is not None:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_function_arguments(tool_call_prefix),
                    str(fn["arguments"]),
                )
        if tc.get("id") is not None:
            span.set_attribute(
                OpenInferenceAttribute.tool_call_identifier(tool_call_prefix),
                str(tc["id"]),
            )
