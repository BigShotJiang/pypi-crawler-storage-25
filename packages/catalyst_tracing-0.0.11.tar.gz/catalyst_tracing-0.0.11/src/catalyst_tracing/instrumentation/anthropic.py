"""First-party Anthropic auto-instrumentation.

Replaces ``openinference-instrumentation-anthropic`` for the
methods our examples and the LangChain ``ChatAnthropic`` wrapper
exercise: ``messages.create`` (sync + async).
"""

from __future__ import annotations

import json
from collections.abc import Awaitable, Callable
from typing import Any

from opentelemetry.trace import (
    SpanKind,
    Status,
    StatusCode,
    Tracer,
)

from ..constants import (
    PATCH_MARKER_ATTR,
    GenAISystem,
    MimeType,
    PatchedMethod,
    SpanName,
)
from ..semconv import Attr, MessageRole, OpenInferenceAttribute, SpanKindValues
from .stream_accumulator import (
    AnthropicStreamAccumulator,
    wrap_async_stream_iter,
    wrap_stream_iter,
)

_PATCHED: set[int] = set()
# Per-class tracer registry — same pattern as openai.
_TRACERS: dict[int, Tracer] = {}


def install_anthropic_instrumentation(tracer: Tracer) -> bool:
    try:
        from anthropic.resources.messages import AsyncMessages, Messages
    except ImportError:
        return False
    installed_any = False
    installed_any |= _patch_class(
        Messages,
        PatchedMethod.CREATE,
        SpanName.ANTHROPIC_MESSAGES,
        tracer,
        is_async=False,
    )
    installed_any |= _patch_class(
        AsyncMessages,
        PatchedMethod.CREATE,
        SpanName.ANTHROPIC_MESSAGES,
        tracer,
        is_async=True,
    )
    return installed_any


def _patch_class(
    cls: type,
    method_name: str,
    span_name: str,
    tracer: Tracer,
    *,
    is_async: bool,
) -> bool:
    _TRACERS[id(cls)] = tracer
    current = getattr(cls, method_name, None)
    if current is None:
        return False
    if getattr(current, PATCH_MARKER_ATTR, False):
        _PATCHED.add(id(cls))
        return True
    if not callable(current):
        return False
    if is_async:
        wrapped = _wrap_async(current, span_name, cls)
    else:
        wrapped = _wrap_sync(current, span_name, cls)
    setattr(wrapped, PATCH_MARKER_ATTR, True)
    setattr(cls, method_name, wrapped)
    _PATCHED.add(id(cls))
    return True


def _wrap_sync(
    original: Callable[..., Any],
    span_name: str,
    cls: type,
) -> Callable[..., Any]:
    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = _TRACERS.get(id(cls))
        if tracer is None:
            return original(self, *args, **kwargs)
        is_stream = bool(kwargs.get("stream"))
        attrs = _request_attributes(kwargs, is_stream)

        if is_stream:
            span = tracer.start_span(
                span_name,
                kind=SpanKind.CLIENT,
                attributes=attrs,
            )
            try:
                upstream = original(self, *args, **kwargs)
            except Exception as err:
                span.record_exception(err)
                span.set_status(Status(StatusCode.ERROR, str(err)))
                span.end()
                raise
            return wrap_stream_iter(upstream, span, AnthropicStreamAccumulator())

        with tracer.start_as_current_span(
            span_name,
            kind=SpanKind.CLIENT,
            attributes=attrs,
        ) as span:
            try:
                resp = original(self, *args, **kwargs)
                _apply_response(span, resp)
                span.set_status(Status(StatusCode.OK))
                return resp
            except Exception as err:
                span.record_exception(err)
                span.set_status(Status(StatusCode.ERROR, str(err)))
                raise

    return wrapped


def _wrap_async(
    original: Callable[..., Awaitable[Any]],
    span_name: str,
    cls: type,
) -> Callable[..., Awaitable[Any]]:
    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = _TRACERS.get(id(cls))
        if tracer is None:
            return await original(self, *args, **kwargs)
        is_stream = bool(kwargs.get("stream"))
        attrs = _request_attributes(kwargs, is_stream)

        if is_stream:
            span = tracer.start_span(
                span_name,
                kind=SpanKind.CLIENT,
                attributes=attrs,
            )
            try:
                upstream = await original(self, *args, **kwargs)
            except Exception as err:
                span.record_exception(err)
                span.set_status(Status(StatusCode.ERROR, str(err)))
                span.end()
                raise
            return wrap_async_stream_iter(
                upstream,
                span,
                AnthropicStreamAccumulator(),
            )

        with tracer.start_as_current_span(
            span_name,
            kind=SpanKind.CLIENT,
            attributes=attrs,
        ) as span:
            try:
                resp = await original(self, *args, **kwargs)
                _apply_response(span, resp)
                span.set_status(Status(StatusCode.OK))
                return resp
            except Exception as err:
                span.record_exception(err)
                span.set_status(Status(StatusCode.ERROR, str(err)))
                raise

    return wrapped


_PARAM_KEYS = (
    "model",
    "max_tokens",
    "temperature",
    "top_p",
    "top_k",
    "tools",
    "tool_choice",
)


def _request_attributes(kwargs: dict[str, Any], is_stream: bool) -> dict[str, Any]:
    out: dict[str, Any] = {
        Attr.SPAN_KIND: SpanKindValues.LLM.value,
        Attr.LLM_SYSTEM: GenAISystem.ANTHROPIC,
        Attr.LLM_PROVIDER: GenAISystem.ANTHROPIC,
        Attr.INPUT_VALUE: json.dumps(kwargs, default=str),
        Attr.INPUT_MIME_TYPE: MimeType.JSON,
    }
    model = kwargs.get("model")
    if model is not None:
        out[Attr.MODEL_NAME] = str(model)
    if is_stream:
        out[Attr.STREAMING] = "true"

    params = {k: kwargs[k] for k in _PARAM_KEYS if k in kwargs and kwargs[k] is not None}
    if params:
        out[Attr.INVOCATION_PARAMETERS] = json.dumps(params, default=str)

    offset = 0
    system = kwargs.get("system")
    if system is not None:
        prefix = OpenInferenceAttribute.input_message_prefix(0)
        out[OpenInferenceAttribute.role(prefix)] = MessageRole.SYSTEM
        out[OpenInferenceAttribute.content(prefix)] = _stringify(system)
        offset = 1
    for i, m in enumerate(kwargs.get("messages") or []):
        idx = offset + i
        role = m.get("role") if isinstance(m, dict) else getattr(m, "role", None)
        content = m.get("content") if isinstance(m, dict) else getattr(m, "content", None)
        if role is not None:
            prefix = OpenInferenceAttribute.input_message_prefix(idx)
            out[OpenInferenceAttribute.role(prefix)] = str(role)
        _write_anthropic_input_content(out, idx, content)
    return out


def _write_anthropic_input_content(
    out: dict[str, Any],
    idx: int,
    content: Any,
) -> None:
    """Write content + nested tool_use / tool_result attributes.

    Anthropic accepts ``content`` as a string OR an array of blocks
    (text / tool_use / tool_result). When it's a block array we split
    out the structured pieces so multi-turn agent traces show:
      - assistant tool_use ids/args under ``tool_calls.*``
      - user tool_result echoes via ``tool_call_id``
    """
    prefix = OpenInferenceAttribute.input_message_prefix(idx)
    if isinstance(content, str):
        out[OpenInferenceAttribute.content(prefix)] = content
        return
    if not isinstance(content, list):
        if content is not None:
            out[OpenInferenceAttribute.content(prefix)] = _stringify(content)
        return
    text_bits: list[str] = []
    tool_idx = 0
    for block in content:
        if not isinstance(block, dict):
            continue
        bt = block.get("type")
        if bt == "text" and isinstance(block.get("text"), str):
            text_bits.append(block["text"])
        elif bt == "tool_use":
            tc_prefix = OpenInferenceAttribute.tool_call_prefix(prefix, tool_idx)
            if block.get("name") is not None:
                out[OpenInferenceAttribute.tool_call_function_name(tc_prefix)] = str(
                    block["name"]
                )
            if block.get("input") is not None:
                out[OpenInferenceAttribute.tool_call_function_arguments(tc_prefix)] = (
                    json.dumps(
                        block["input"],
                        default=str,
                    )
                )
            if block.get("id") is not None:
                out[OpenInferenceAttribute.tool_call_identifier(tc_prefix)] = str(
                    block["id"]
                )
            tool_idx += 1
        elif bt == "tool_result":
            if block.get("tool_use_id") is not None:
                out[OpenInferenceAttribute.tool_call_id(prefix)] = str(
                    block["tool_use_id"]
                )
            inner = block.get("content")
            if inner is not None:
                text_bits.append(_stringify(inner))
    if text_bits:
        out[OpenInferenceAttribute.content(prefix)] = "".join(text_bits)


def _apply_response(span: Any, resp: Any) -> None:
    if resp is None:
        return
    body = _to_dict(resp)
    span.set_attribute(Attr.OUTPUT_VALUE, json.dumps(body, default=str))
    span.set_attribute(Attr.OUTPUT_MIME_TYPE, MimeType.JSON)
    if not isinstance(body, dict):
        return
    model = body.get("model")
    if model is not None:
        span.set_attribute(Attr.MODEL_NAME, str(model))
    usage = body.get("usage")
    if isinstance(usage, dict):
        # Prompt total sums input + cache_write + cache_read so it
        # matches Anthropic's billing semantics (cached tokens ARE
        # input tokens, just at different rates). The breakdown
        # lives under `prompt_details.*` per the OpenInference
        # canonical convention.
        cache_write = int(usage.get("cache_creation_input_tokens") or 0)
        cache_read = int(usage.get("cache_read_input_tokens") or 0)
        if usage.get("input_tokens") is not None:
            span.set_attribute(
                Attr.TOKEN_COUNT_PROMPT,
                int(usage["input_tokens"]) + cache_write + cache_read,
            )
        if usage.get("output_tokens") is not None:
            span.set_attribute(Attr.TOKEN_COUNT_COMPLETION, usage["output_tokens"])
        if (
            usage.get("input_tokens") is not None
            and usage.get("output_tokens") is not None
        ):
            span.set_attribute(
                Attr.TOKEN_COUNT_TOTAL,
                int(usage["input_tokens"])
                + cache_write
                + cache_read
                + int(usage["output_tokens"]),
            )
        if usage.get("cache_creation_input_tokens") is not None:
            span.set_attribute(
                Attr.TOKEN_COUNT_PROMPT_CACHE_WRITE,
                usage["cache_creation_input_tokens"],
            )
        if usage.get("cache_read_input_tokens") is not None:
            span.set_attribute(
                Attr.TOKEN_COUNT_PROMPT_CACHE_READ,
                usage["cache_read_input_tokens"],
            )
    if body.get("stop_reason") is not None:
        span.set_attribute(Attr.FINISH_REASON, str(body["stop_reason"]))
    if body.get("role") is not None:
        prefix = OpenInferenceAttribute.output_message_prefix(0)
        span.set_attribute(OpenInferenceAttribute.role(prefix), str(body["role"]))

    blocks = body.get("content")
    if not isinstance(blocks, list):
        return
    text_bits: list[str] = []
    tool_idx = 0
    for b in blocks:
        if not isinstance(b, dict):
            continue
        t = b.get("type")
        if t == "text" and isinstance(b.get("text"), str):
            text_bits.append(b["text"])
        elif t == "tool_use":
            tc_prefix = OpenInferenceAttribute.tool_call_prefix(
                OpenInferenceAttribute.output_message_prefix(0),
                tool_idx,
            )
            span.set_attribute(
                OpenInferenceAttribute.tool_call_function_name(tc_prefix),
                str(b.get("name", "")),
            )
            inp = b.get("input")
            if inp is not None:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_function_arguments(tc_prefix),
                    json.dumps(inp, default=str),
                )
            if b.get("id") is not None:
                span.set_attribute(
                    OpenInferenceAttribute.tool_call_identifier(tc_prefix),
                    str(b["id"]),
                )
            tool_idx += 1
    if text_bits:
        prefix = OpenInferenceAttribute.output_message_prefix(0)
        span.set_attribute(OpenInferenceAttribute.content(prefix), "".join(text_bits))


def _to_dict(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        try:
            return value.model_dump()
        except Exception:
            pass
    if hasattr(value, "to_dict"):
        try:
            return value.to_dict()
        except Exception:
            pass
    if isinstance(value, dict):
        return value
    return value


def _stringify(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, default=str)
