"""First-party claude-agent-sdk auto-instrumentation.

Replaces ``openinference-instrumentation-claude-agent-sdk``. Patches
``claude_agent_sdk.query.query`` (and the package-level snapshot of
the same function) to wrap the async iterator in an AGENT span and
emit per-tool_use TOOL child spans as the message stream flows.

Beyond the basic AGENT shape, this wrapper:
  - holds each TOOL span open until the matching ``tool_result``
    block arrives, then sets ``output.value`` on the TOOL span and
    closes it. The TOOL span carries the actual tool output, not just
    the request args.
  - aggregates per-message ``usage`` totals onto the AGENT span,
    including Anthropic ``cache_creation_input_tokens`` and
    ``cache_read_input_tokens`` under the
    ``llm.token_count.prompt_details.cache_*`` namespace.
"""

from __future__ import annotations

import importlib
import json
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass, field
from typing import Any

from opentelemetry import context as otel_context
from opentelemetry.trace import (
    Span,
    SpanKind,
    Status,
    StatusCode,
    Tracer,
    set_span_in_context,
)

from ..constants import AgentName, GenAISystem, ImportName, MimeType, SpanName
from ..semconv import Attr, SpanKindValues

_PATCHED: bool = False


def install_claude_agent_sdk_instrumentation(tracer: Tracer) -> bool:
    """Patch ``claude_agent_sdk.query`` so every call emits OI spans.

    ``claude_agent_sdk`` has two ``query`` bindings that both need to
    be patched so consumers get the wrapped function regardless of
    which import style they use:

      * ``claude_agent_sdk.query.query`` — the submodule attribute, what
        ``from claude_agent_sdk.query import query`` reads.
      * ``claude_agent_sdk.query`` — the top-level package attribute, a
        snapshot taken when ``claude_agent_sdk/__init__.py`` runs
        ``from .query import query``. ``from claude_agent_sdk import
        query`` reads this.

    In practice the two bindings are independent: patching only the
    submodule leaves the top-level binding pointing at the original. We
    patch both.
    """
    global _PATCHED
    if _PATCHED:
        return True

    try:
        query_module = importlib.import_module(ImportName.CLAUDE_AGENT_SDK_QUERY)
    except ImportError:
        return False
    original = getattr(query_module, "query", None)
    if not callable(original):
        return False
    wrapped = _wrap(original, tracer)
    query_module.query = wrapped  # type: ignore[attr-defined]

    # Re-bind the package-level attribute so the ``from claude_agent_sdk
    # import query`` import path also picks up the wrapped function.
    # Subtle pitfall: importing ``claude_agent_sdk.query`` above clobbers
    # the package's own attribute (Python sets ``package.submodule = the
    # submodule`` after a successful import), so we always rewrite it.
    try:
        package = importlib.import_module(ImportName.CLAUDE_AGENT_SDK)
        package.query = wrapped  # type: ignore[attr-defined]
    except ImportError:
        pass

    _PATCHED = True
    return True


def _wrap(
    original: Callable[..., Any],
    tracer: Tracer,
) -> Callable[..., AsyncIterator[Any]]:
    def wrapped(*args: Any, **kwargs: Any) -> AsyncIterator[Any]:
        prompt = kwargs.get("prompt", args[0] if args else "")
        attrs = {
            Attr.SPAN_KIND: SpanKindValues.AGENT.value,
            Attr.AGENT_NAME: AgentName.CLAUDE_AGENT_SDK,
            Attr.SYSTEM: GenAISystem.ANTHROPIC,
            Attr.INPUT_VALUE: (
                prompt if isinstance(prompt, str) else json.dumps(prompt, default=str)
            ),
            Attr.INPUT_MIME_TYPE: MimeType.JSON,
        }
        span = tracer.start_span(
            SpanName.CLAUDE_AGENT_QUERY,
            kind=SpanKind.INTERNAL,
            attributes=attrs,
        )
        ctx = set_span_in_context(span)
        token = otel_context.attach(ctx)
        upstream = original(*args, **kwargs)
        return _wrap_iter(upstream, span, tracer, token)

    return wrapped


@dataclass
class _State:
    """Aggregates assistant/user messages onto AGENT-level totals.

    Held by the per-iteration wrapper as it fans messages out to spans.
    Pulled out so the iterator's own logic stays linear.
    """

    last_text: str = ""
    tool_calls: int = 0
    llm_calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cache_write_tokens: int = 0
    cache_read_tokens: int = 0
    pending_tool_spans: dict[str, Span] = field(default_factory=dict)


async def _wrap_iter(
    upstream: AsyncIterator[Any],
    span: Span,
    tracer: Tracer,
    ctx_token: object,
) -> AsyncIterator[Any]:
    state = _State()
    try:
        async for msg in upstream:
            _handle_message(msg, state, tracer)
            yield msg
        _finalize_agent(span, state)
    except Exception as err:
        for s in state.pending_tool_spans.values():
            s.record_exception(err)
            s.set_status(Status(StatusCode.ERROR, str(err)))
            s.end()
        state.pending_tool_spans.clear()
        span.record_exception(err)
        span.set_status(Status(StatusCode.ERROR, str(err)))
        raise
    finally:
        span.end()
        otel_context.detach(ctx_token)  # type: ignore[arg-type]


def _handle_message(msg: Any, state: _State, tracer: Tracer) -> None:
    cls_name = type(msg).__name__
    if cls_name == "AssistantMessage":
        state.llm_calls += 1
        for block in getattr(msg, "content", None) or []:
            _handle_assistant_block(block, state, tracer)
        _add_usage(state, getattr(msg, "usage", None))
    elif cls_name == "UserMessage":
        for block in getattr(msg, "content", None) or []:
            _handle_user_block(block, state)


def _handle_assistant_block(block: Any, state: _State, tracer: Tracer) -> None:
    b_cls = type(block).__name__
    if b_cls == "TextBlock":
        text = getattr(block, "text", None)
        if isinstance(text, str):
            state.last_text = text
        return
    if b_cls != "ToolUseBlock":
        return
    state.tool_calls += 1
    name = str(getattr(block, "name", "") or "")
    inp = getattr(block, "input", None)
    block_id = getattr(block, "id", None)
    attrs: dict[str, Any] = {
        Attr.SPAN_KIND: SpanKindValues.TOOL.value,
        Attr.TOOL_NAME: name,
        Attr.INPUT_VALUE: json.dumps(inp, default=str) if inp is not None else "",
    }
    if block_id is not None:
        attrs[Attr.TOOL_CALL_ID] = str(block_id)
    child = tracer.start_span(
        f"tool_use {name}",
        kind=SpanKind.INTERNAL,
        attributes=attrs,
    )
    if block_id is not None:
        # Hold the TOOL span open so we can apply output.value when the
        # matching tool_result block arrives in a follow-up user msg.
        state.pending_tool_spans[str(block_id)] = child
    else:
        # No id to correlate against — close immediately.
        child.end()


def _handle_user_block(block: Any, state: _State) -> None:
    if type(block).__name__ != "ToolResultBlock":
        return
    tool_use_id = getattr(block, "tool_use_id", None)
    if tool_use_id is None:
        return
    child = state.pending_tool_spans.pop(str(tool_use_id), None)
    if child is None:
        return
    content = getattr(block, "content", None)
    if content is not None:
        if isinstance(content, str):
            child.set_attribute(Attr.OUTPUT_VALUE, content)
        else:
            child.set_attribute(Attr.OUTPUT_VALUE, json.dumps(content, default=str))
            child.set_attribute(Attr.OUTPUT_MIME_TYPE, MimeType.JSON)
    if getattr(block, "is_error", False):
        child.set_status(Status(StatusCode.ERROR))
    else:
        child.set_status(Status(StatusCode.OK))
    child.end()


def _add_usage(state: _State, usage: Any) -> None:
    if not isinstance(usage, dict):
        return
    if (it := usage.get("input_tokens")) is not None:
        state.input_tokens += int(it)
    if (ot := usage.get("output_tokens")) is not None:
        state.output_tokens += int(ot)
    if (cw := usage.get("cache_creation_input_tokens")) is not None:
        state.cache_write_tokens += int(cw)
    if (cr := usage.get("cache_read_input_tokens")) is not None:
        state.cache_read_tokens += int(cr)


def _finalize_agent(span: Span, state: _State) -> None:
    # Any tool spans that never got a matching tool_result — close them
    # OK so they appear in the trace tree (better than orphaning).
    for child in state.pending_tool_spans.values():
        child.set_status(Status(StatusCode.OK))
        child.end()
    state.pending_tool_spans.clear()

    span.set_attribute(Attr.OUTPUT_VALUE, state.last_text)
    if state.input_tokens > 0:
        span.set_attribute(Attr.TOKEN_COUNT_PROMPT, state.input_tokens)
    if state.output_tokens > 0:
        span.set_attribute(Attr.TOKEN_COUNT_COMPLETION, state.output_tokens)
    if state.input_tokens or state.output_tokens:
        span.set_attribute(
            Attr.TOKEN_COUNT_TOTAL,
            state.input_tokens + state.output_tokens,
        )
    if state.cache_write_tokens > 0:
        span.set_attribute(
            Attr.TOKEN_COUNT_PROMPT_CACHE_WRITE,
            state.cache_write_tokens,
        )
    if state.cache_read_tokens > 0:
        span.set_attribute(
            Attr.TOKEN_COUNT_PROMPT_CACHE_READ,
            state.cache_read_tokens,
        )
    span.set_attribute(Attr.AGENT_TOOL_CALL_COUNT, state.tool_calls)
    span.set_attribute(Attr.AGENT_LLM_CALL_COUNT, state.llm_calls)
    span.set_status(Status(StatusCode.OK))
