"""First-party LangChain auto-instrumentation.

Replaces ``openinference-instrumentation-langchain``. Same idea as the
TS version: register a callback handler that translates LangChain's
chain/llm/tool/retriever events into OI-shaped OTel spans.

Strategy: monkey-patch ``BaseCallbackManager.__init__`` so every
manager that LangChain constructs automatically picks up our handler.
"""

from __future__ import annotations

import importlib
import json
from typing import Any
from uuid import UUID

from opentelemetry import context as context_api
from opentelemetry import trace as trace_api
from opentelemetry.trace import (
    Span,
    SpanKind,
    Status,
    StatusCode,
    Tracer,
)

from ..constants import ImportName, MimeType
from ..semconv import Attr, MessageRole, OpenInferenceAttribute, SpanKindValues

_PATCHED = False
# Single mutable handler whose tracer can be re-bound. Subsequent
# install_langchain_instrumentation calls (typically only happens in tests)
# update this handler's tracer rather than re-patching __init__,
# which would double-wrap and create handler leaks across tests.
_HANDLER: CatalystLangChainHandler | None = None


def install_langchain_instrumentation(tracer: Tracer) -> bool:
    global _PATCHED, _HANDLER
    try:
        callbacks_base = importlib.import_module(
            f"{ImportName.LANGCHAIN_CORE}.callbacks.base"
        )
        BaseCallbackManager = callbacks_base.BaseCallbackManager
    except ImportError:
        return False

    if _HANDLER is None:
        _HANDLER = CatalystLangChainHandler(tracer)
    else:
        # Tracer re-bind: keeps the same handler instance (still
        # registered on every CallbackManager) but redirects spans to
        # the new tracer.
        _HANDLER._tracer = tracer

    if _PATCHED:
        return True

    handler = _HANDLER
    original_init = BaseCallbackManager.__init__

    def patched_init(self: Any, *args: Any, **kwargs: Any) -> None:  # type: ignore[no-untyped-def]
        original_init(self, *args, **kwargs)
        # Avoid duplicate adds when langchain copies a manager.
        for h in getattr(self, "inheritable_handlers", []) or []:
            if isinstance(h, CatalystLangChainHandler):
                return
        self.add_handler(handler, True)

    BaseCallbackManager.__init__ = patched_init  # type: ignore[method-assign]
    _PATCHED = True
    return True


class CatalystLangChainHandler:
    """Plain callback handler. We don't extend
    ``langchain_core.callbacks.BaseCallbackHandler`` so the package
    has no hard dependency on a specific langchain-core version's
    BaseCallbackHandler shape — duck-typing on method names is enough
    for the manager's dispatcher.
    """

    raise_error: bool = False
    run_inline: bool = False
    ignore_llm: bool = False
    ignore_chain: bool = False
    ignore_agent: bool = False
    ignore_retriever: bool = False
    ignore_chat_model: bool = False
    ignore_custom_event: bool = False

    def __init__(self, tracer: Tracer) -> None:
        self._tracer = tracer
        self._spans: dict[str, Span] = {}

    # --- chain ----------------------------------------------------------

    def on_chain_start(
        self,
        serialized: dict[str, Any] | None,
        inputs: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        run_type: str | None = None,
        name: str | None = None,
        **_: Any,
    ) -> None:
        self._start(
            run_id,
            name=name or _guess_name(serialized) or run_type or "chain",
            kind=SpanKindValues.CHAIN.value,
            input_=inputs,
            parent_run_id=parent_run_id,
        )

    def on_chain_end(self, outputs: Any, *, run_id: UUID, **_: Any) -> None:
        self._end(run_id, outputs)

    def on_chain_error(self, err: BaseException, *, run_id: UUID, **_: Any) -> None:
        self._err(run_id, err)

    # --- llm / chat model ----------------------------------------------

    def on_llm_start(
        self,
        serialized: dict[str, Any] | None,
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        invocation_params: dict[str, Any] | None = None,
        name: str | None = None,
        **_: Any,
    ) -> None:
        self._start(
            run_id,
            name=name or _guess_name(serialized) or "LLM",
            kind=SpanKindValues.LLM.value,
            input_={"prompts": prompts},
            parent_run_id=parent_run_id,
            extra=invocation_params,
        )

    def on_chat_model_start(
        self,
        serialized: dict[str, Any] | None,
        messages: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        invocation_params: dict[str, Any] | None = None,
        name: str | None = None,
        **_: Any,
    ) -> None:
        span = self._start(
            run_id,
            name=name or _guess_name(serialized) or "ChatModel",
            kind=SpanKindValues.LLM.value,
            input_=messages,
            parent_run_id=parent_run_id,
            extra=invocation_params,
        )
        if (
            span is not None
            and isinstance(messages, list)
            and messages
            and isinstance(messages[0], list)
        ):
            for i, m in enumerate(messages[0][:32]):
                raw_role = (
                    getattr(m, "type", None) or getattr(m, "role", None) or "unknown"
                )
                content = getattr(m, "content", None)
                prefix = OpenInferenceAttribute.input_message_prefix(i)
                span.set_attribute(
                    OpenInferenceAttribute.role(prefix),
                    _canonical_role(str(raw_role)),
                )
                if content is not None:
                    span.set_attribute(
                        OpenInferenceAttribute.content(prefix),
                        _stringify(content),
                    )

    def on_llm_end(self, response: Any, *, run_id: UUID, **_: Any) -> None:
        span = self._spans.get(str(run_id))
        if span is not None:
            usage = getattr(response, "llm_output", None) or {}
            tokens = (usage or {}).get("token_usage") if isinstance(usage, dict) else None
            if isinstance(tokens, dict):
                if tokens.get("prompt_tokens") is not None:
                    span.set_attribute(Attr.TOKEN_COUNT_PROMPT, tokens["prompt_tokens"])
                if tokens.get("completion_tokens") is not None:
                    span.set_attribute(
                        Attr.TOKEN_COUNT_COMPLETION,
                        tokens["completion_tokens"],
                    )
                if tokens.get("total_tokens") is not None:
                    span.set_attribute(Attr.TOKEN_COUNT_TOTAL, tokens["total_tokens"])
            generations = getattr(response, "generations", None)
            if (
                isinstance(generations, list)
                and generations
                and isinstance(generations[0], list)
            ):
                for i, g in enumerate(generations[0]):
                    text = getattr(g, "text", None)
                    if text is not None:
                        prefix = OpenInferenceAttribute.output_message_prefix(i)
                        span.set_attribute(
                            OpenInferenceAttribute.role(prefix),
                            MessageRole.ASSISTANT,
                        )
                        span.set_attribute(
                            OpenInferenceAttribute.content(prefix),
                            str(text),
                        )
                    # AIMessage tool_calls — mirror to OI for parity with
                    # native chat-completions agent spans.
                    msg = getattr(g, "message", None)
                    if msg is not None:
                        _write_chat_output_tool_calls(span, i, msg)
        self._end(run_id, response)

    def on_llm_error(self, err: BaseException, *, run_id: UUID, **_: Any) -> None:
        self._err(run_id, err)

    # --- tool ----------------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any] | None,
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        name: str | None = None,
        **_: Any,
    ) -> None:
        self._start(
            run_id,
            name=name or _guess_name(serialized) or "tool",
            kind=SpanKindValues.TOOL.value,
            input_=input_str,
            parent_run_id=parent_run_id,
        )

    def on_tool_end(self, output: Any, *, run_id: UUID, **_: Any) -> None:
        self._end(run_id, output)

    def on_tool_error(self, err: BaseException, *, run_id: UUID, **_: Any) -> None:
        self._err(run_id, err)

    # --- retriever -----------------------------------------------------

    def on_retriever_start(
        self,
        serialized: dict[str, Any] | None,
        query: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        name: str | None = None,
        **_: Any,
    ) -> None:
        self._start(
            run_id,
            name=name or _guess_name(serialized) or "retriever",
            kind=SpanKindValues.RETRIEVER.value,
            input_=query,
            parent_run_id=parent_run_id,
        )

    def on_retriever_end(
        self,
        documents: Any,
        *,
        run_id: UUID,
        **_: Any,
    ) -> None:
        self._end(run_id, documents)

    def on_retriever_error(
        self,
        err: BaseException,
        *,
        run_id: UUID,
        **_: Any,
    ) -> None:
        self._err(run_id, err)

    # --- shims (langchain calls these on every handler) ----------------

    def on_text(self, *_: Any, **__: Any) -> None:  # noqa: D401
        return None

    def on_agent_action(self, *_: Any, **__: Any) -> None:
        return None

    def on_agent_finish(self, *_: Any, **__: Any) -> None:
        return None

    def on_llm_new_token(self, *_: Any, **__: Any) -> None:
        return None

    def on_custom_event(self, *_: Any, **__: Any) -> None:
        return None

    # --- internals -----------------------------------------------------

    def _start(
        self,
        run_id: UUID,
        *,
        name: str,
        kind: str,
        input_: Any,
        parent_run_id: UUID | None = None,
        extra: dict[str, Any] | None = None,
    ) -> Span | None:
        key = str(run_id)
        if key in self._spans:
            return self._spans[key]
        attrs: dict[str, Any] = {
            Attr.SPAN_KIND: kind,
            Attr.INPUT_VALUE: _stringify(input_),
            Attr.INPUT_MIME_TYPE: MimeType.JSON,
        }
        if extra:
            attrs[Attr.INVOCATION_PARAMETERS] = _stringify(extra)
            model = extra.get("model") or extra.get("model_name")
            if model is not None:
                attrs[Attr.MODEL_NAME] = str(model)
        parent_span = (
            self._spans.get(str(parent_run_id)) if parent_run_id is not None else None
        )
        parent_context = (
            trace_api.set_span_in_context(parent_span, context_api.get_current())
            if parent_span is not None
            else None
        )
        span = self._tracer.start_span(
            name,
            context=parent_context,
            kind=SpanKind.INTERNAL,
            attributes=attrs,
        )
        self._spans[key] = span
        return span

    def _end(self, run_id: UUID, output: Any) -> None:
        key = str(run_id)
        span = self._spans.pop(key, None)
        if span is None:
            return
        span.set_attribute(Attr.OUTPUT_VALUE, _stringify(output))
        span.set_attribute(Attr.OUTPUT_MIME_TYPE, MimeType.JSON)
        span.set_status(Status(StatusCode.OK))
        span.end()

    def _err(self, run_id: UUID, err: BaseException) -> None:
        key = str(run_id)
        span = self._spans.pop(key, None)
        if span is None:
            return
        span.record_exception(err)
        span.set_status(Status(StatusCode.ERROR, str(err)))
        span.end()


_ROLE_MAP = {
    "human": MessageRole.USER,
    "ai": MessageRole.ASSISTANT,
    "system": MessageRole.SYSTEM,
    "tool": MessageRole.TOOL,
    "function": MessageRole.FUNCTION,
}


def _canonical_role(raw: str) -> str:
    """Map LangChain ``_get_type()`` names to OI canonical roles.

    LangChain returns ``"human"`` / ``"ai"`` for chat messages; the OI
    convention (and what every other provider's spans use) is
    ``"user"`` / ``"assistant"``. Keep them aligned at the OI boundary
    so viewers render these spans the same way as OpenAI / Anthropic.
    """
    return _ROLE_MAP.get(raw, raw)


def _write_chat_output_tool_calls(span: Span, msg_idx: int, message: Any) -> None:
    """Mirror ``AIMessage.tool_calls`` onto OI ``tool_calls.*`` attrs.

    LangChain's AIMessage exposes tool calls via either
    ``.tool_calls`` (v1 shape ``{name, args, id}``) or
    ``.additional_kwargs.tool_calls`` (legacy OpenAI shape
    ``{id, function: {name, arguments}}``). We normalize both into the
    OI attribute layout.
    """
    calls = (
        getattr(message, "tool_calls", None)
        or getattr(
            getattr(message, "additional_kwargs", None) or {}, "get", lambda _k: None
        )(
            "tool_calls",
        )
        or (
            message.additional_kwargs.get("tool_calls")
            if hasattr(message, "additional_kwargs")
            and isinstance(message.additional_kwargs, dict)
            else None
        )
    )
    if not calls:
        return
    for j, tc in enumerate(calls):
        prefix = OpenInferenceAttribute.tool_call_prefix(
            OpenInferenceAttribute.output_message_prefix(msg_idx),
            j,
        )
        # v1 shape: {name, args, id}
        name = tc.get("name") if isinstance(tc, dict) else getattr(tc, "name", None)
        args = tc.get("args") if isinstance(tc, dict) else getattr(tc, "args", None)
        tc_id = tc.get("id") if isinstance(tc, dict) else getattr(tc, "id", None)
        # Legacy: {id, function: {name, arguments}}
        fn = tc.get("function") if isinstance(tc, dict) else getattr(tc, "function", None)
        if name is None and fn is not None:
            name = fn.get("name") if isinstance(fn, dict) else getattr(fn, "name", None)
        if args is None and fn is not None:
            args = (
                fn.get("arguments")
                if isinstance(fn, dict)
                else getattr(fn, "arguments", None)
            )
        if name is not None:
            span.set_attribute(
                OpenInferenceAttribute.tool_call_function_name(prefix),
                str(name),
            )
        if args is not None:
            span.set_attribute(
                OpenInferenceAttribute.tool_call_function_arguments(prefix),
                _stringify(args),
            )
        if tc_id is not None:
            span.set_attribute(
                OpenInferenceAttribute.tool_call_identifier(prefix),
                str(tc_id),
            )


def _guess_name(serialized: dict[str, Any] | None) -> str | None:
    if not serialized:
        return None
    sid = serialized.get("id")
    if isinstance(sid, list) and sid:
        return str(sid[-1])
    name = serialized.get("name")
    if isinstance(name, str):
        return name
    return None


def _stringify(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str)
    except Exception:
        return str(value)
