"""First-party ElevenLabs Agents SDK instrumentation.

Patches the real ``elevenlabs.conversational_ai.conversation``
classes so each ``Conversation.start_session`` /
``AsyncConversation.start_session`` call emits one OpenInference
AGENT span for the session. Client-side tools registered through
``ClientTools`` emit TOOL child spans correlated by ``tool_call_id``.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from opentelemetry.trace import (
    Span,
    SpanKind,
    Status,
    StatusCode,
    Tracer,
    set_span_in_context,
)

from ..constants import (
    PATCH_MARKER_ATTR,
    AgentName,
    GenAISystem,
    MimeType,
    SpanName,
)
from ..semconv import Attr, MessageRole, OpenInferenceAttribute, SpanKindValues

_TRACER: Tracer | None = None
_PATCHED = False
_STATE_ATTR = "_catalyst_elevenlabs_state"
_CLIENT_TOOLS_STATE: dict[int, _ConversationState] = {}


@dataclass
class _ConversationState:
    span: Span
    tracer: Tracer
    context: object
    input_messages: int = 0
    output_messages: int = 0
    tool_calls: int = 0
    last_output: str | None = None
    ended: bool = False
    failed: bool = False


def install_elevenlabs_instrumentation(tracer: Tracer) -> bool:
    """Patch ElevenLabs conversation lifecycle classes."""
    global _PATCHED, _TRACER
    _TRACER = tracer
    if _PATCHED:
        return True
    try:
        from elevenlabs.conversational_ai.conversation import (  # type: ignore[import-not-found]
            AsyncConversation,
            ClientTools,
            Conversation,
        )
    except ImportError:
        return False

    installed = False
    installed |= _patch_conversation_class(Conversation, is_async=False)
    installed |= _patch_conversation_class(AsyncConversation, is_async=True)
    installed |= _patch_client_tools(ClientTools)
    _PATCHED = installed
    return installed


def _patch_conversation_class(cls: type, *, is_async: bool) -> bool:
    ok = True
    ok &= _patch_method(
        cls, "start_session", _wrap_start_async if is_async else _wrap_start
    )
    ok &= _patch_method(cls, "end_session", _wrap_end_async if is_async else _wrap_end)
    ok &= _patch_method(
        cls,
        "wait_for_session_end",
        _wrap_wait_async if is_async else _wrap_wait,
    )
    ok &= _patch_method(
        cls,
        "_handle_message",
        _wrap_handle_message_async if is_async else _wrap_handle_message,
    )
    ok &= _patch_method(
        cls, "send_user_message", _wrap_send_text_async if is_async else _wrap_send_text
    )
    ok &= _patch_method(
        cls,
        "send_contextual_update",
        _wrap_send_context_async if is_async else _wrap_send_context,
    )
    ok &= _patch_method(
        cls,
        "send_multimodal_message",
        _wrap_send_multimodal_async if is_async else _wrap_send_multimodal,
    )
    return ok


def _patch_client_tools(cls: type) -> bool:
    return _patch_method(cls, "execute_tool", _wrap_execute_tool)


def _patch_method(
    cls: type,
    method_name: str,
    factory: Callable[[Callable[..., Any]], Callable[..., Any]],
) -> bool:
    current = getattr(cls, method_name, None)
    if not callable(current):
        return False
    if getattr(current, PATCH_MARKER_ATTR, False):
        return True
    wrapped = factory(current)
    setattr(wrapped, PATCH_MARKER_ATTR, True)
    setattr(cls, method_name, wrapped)
    return True


def _wrap_start(original: Callable[..., Any]) -> Callable[..., Any]:
    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        state = _start_state(self)
        try:
            return original(self, *args, **kwargs)
        except Exception as exc:
            _mark_state_error(state, exc)
            _finish_state(self, state)
            raise

    return wrapped


def _wrap_start_async(original: Callable[..., Any]) -> Callable[..., Any]:
    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        state = _start_state(self)
        try:
            return await original(self, *args, **kwargs)
        except Exception as exc:
            _mark_state_error(state, exc)
            _finish_state(self, state)
            raise

    return wrapped


def _wrap_end(original: Callable[..., Any]) -> Callable[..., Any]:
    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        state = _state_for(self)
        try:
            return original(self, *args, **kwargs)
        except Exception as exc:
            if state:
                _mark_state_error(state, exc)
            raise
        finally:
            if state:
                _finish_state(self, state)

    return wrapped


def _wrap_end_async(original: Callable[..., Any]) -> Callable[..., Any]:
    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        state = _state_for(self)
        try:
            return await original(self, *args, **kwargs)
        except Exception as exc:
            if state:
                _mark_state_error(state, exc)
            raise
        finally:
            if state:
                _finish_state(self, state)

    return wrapped


def _wrap_wait(original: Callable[..., Any]) -> Callable[..., Any]:
    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        state = _state_for(self)
        try:
            return original(self, *args, **kwargs)
        finally:
            if state:
                _finish_state(self, state)

    return wrapped


def _wrap_wait_async(original: Callable[..., Any]) -> Callable[..., Any]:
    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        state = _state_for(self)
        try:
            return await original(self, *args, **kwargs)
        finally:
            if state:
                _finish_state(self, state)

    return wrapped


def _wrap_handle_message(original: Callable[..., Any]) -> Callable[..., Any]:
    def wrapped(self: Any, message: dict[str, Any], *args: Any, **kwargs: Any) -> Any:
        result = original(self, message, *args, **kwargs)
        state = _state_for(self)
        if state:
            _record_event(state, message)
        return result

    return wrapped


def _wrap_handle_message_async(original: Callable[..., Any]) -> Callable[..., Any]:
    async def wrapped(
        self: Any, message: dict[str, Any], *args: Any, **kwargs: Any
    ) -> Any:
        result = await original(self, message, *args, **kwargs)
        state = _state_for(self)
        if state:
            _record_event(state, message)
        return result

    return wrapped


def _wrap_send_text(original: Callable[..., Any]) -> Callable[..., Any]:
    def wrapped(self: Any, text: str, *args: Any, **kwargs: Any) -> Any:
        if state := _state_for(self):
            _record_input_message(state, text)
        return original(self, text, *args, **kwargs)

    return wrapped


def _wrap_send_text_async(original: Callable[..., Any]) -> Callable[..., Any]:
    async def wrapped(self: Any, text: str, *args: Any, **kwargs: Any) -> Any:
        if state := _state_for(self):
            _record_input_message(state, text)
        return await original(self, text, *args, **kwargs)

    return wrapped


def _wrap_send_context(original: Callable[..., Any]) -> Callable[..., Any]:
    def wrapped(self: Any, text: str, *args: Any, **kwargs: Any) -> Any:
        if state := _state_for(self):
            _record_input_message(state, json.dumps({"contextual_update": text}))
        return original(self, text, *args, **kwargs)

    return wrapped


def _wrap_send_context_async(original: Callable[..., Any]) -> Callable[..., Any]:
    async def wrapped(self: Any, text: str, *args: Any, **kwargs: Any) -> Any:
        if state := _state_for(self):
            _record_input_message(state, json.dumps({"contextual_update": text}))
        return await original(self, text, *args, **kwargs)

    return wrapped


def _wrap_send_multimodal(original: Callable[..., Any]) -> Callable[..., Any]:
    def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        if state := _state_for(self):
            _record_input_message(state, _json({"args": args, "kwargs": kwargs}))
        return original(self, *args, **kwargs)

    return wrapped


def _wrap_send_multimodal_async(original: Callable[..., Any]) -> Callable[..., Any]:
    async def wrapped(self: Any, *args: Any, **kwargs: Any) -> Any:
        if state := _state_for(self):
            _record_input_message(state, _json({"args": args, "kwargs": kwargs}))
        return await original(self, *args, **kwargs)

    return wrapped


def _wrap_execute_tool(original: Callable[..., Any]) -> Callable[..., Any]:
    def wrapped(
        self: Any,
        tool_name: str,
        parameters: dict[str, Any],
        callback: Callable[[dict[str, Any]], None],
    ) -> Any:
        state = _CLIENT_TOOLS_STATE.get(id(self))
        if not state:
            return original(self, tool_name, parameters, callback)

        state.tool_calls += 1
        attrs: dict[str, Any] = {
            Attr.SPAN_KIND: SpanKindValues.TOOL.value,
            Attr.TOOL_NAME: str(tool_name),
            Attr.INPUT_VALUE: _json(parameters),
        }
        if parameters.get("tool_call_id") is not None:
            attrs[Attr.TOOL_CALL_ID] = str(parameters["tool_call_id"])
        span = state.tracer.start_span(
            f"client_tool {tool_name}",
            kind=SpanKind.INTERNAL,
            context=state.context,  # type: ignore[arg-type]
            attributes=attrs,
        )
        lock = threading.Lock()
        ended = False

        def finish(response: dict[str, Any], *, is_error: bool = False) -> None:
            nonlocal ended
            with lock:
                if ended:
                    return
                if "result" in response:
                    span.set_attribute(Attr.OUTPUT_VALUE, _json(response["result"]))
                if response.get("is_error") or is_error:
                    span.set_status(Status(StatusCode.ERROR))
                else:
                    span.set_status(Status(StatusCode.OK))
                span.end()
                ended = True

        def wrapped_callback(response: dict[str, Any]) -> None:
            finish(response)
            callback(response)

        try:
            return original(self, tool_name, parameters, wrapped_callback)
        except Exception as exc:
            _record_error(span, exc)
            span.end()
            raise

    return wrapped


def _start_state(conversation: Any) -> _ConversationState:
    tracer = _TRACER
    if tracer is None:
        raise RuntimeError("ElevenLabs instrumentation installed without a tracer")

    attrs: dict[str, Any] = {
        Attr.SPAN_KIND: SpanKindValues.AGENT.value,
        Attr.AGENT_NAME: AgentName.ELEVENLABS,
        Attr.SYSTEM: GenAISystem.ELEVENLABS,
        Attr.INPUT_MIME_TYPE: MimeType.JSON,
        Attr.INPUT_VALUE: _json(_safe_conversation_input(conversation)),
    }
    if getattr(conversation, "agent_id", None):
        attrs["elevenlabs.agent_id"] = str(conversation.agent_id)
    if getattr(conversation, "user_id", None):
        attrs["elevenlabs.user_id"] = str(conversation.user_id)
    attrs["elevenlabs.requires_auth"] = bool(
        getattr(conversation, "requires_auth", False)
    )
    attrs["elevenlabs.text_only"] = getattr(conversation, "audio_interface", None) is None

    span = tracer.start_span(
        SpanName.ELEVENLABS_CONVERSATION,
        kind=SpanKind.INTERNAL,
        attributes=attrs,
    )
    ctx = set_span_in_context(span)
    state = _ConversationState(span=span, tracer=tracer, context=ctx)
    setattr(conversation, _STATE_ATTR, state)
    _CLIENT_TOOLS_STATE[id(conversation.client_tools)] = state
    return state


def _state_for(conversation: Any) -> _ConversationState | None:
    return getattr(conversation, _STATE_ATTR, None)


def _safe_conversation_input(conversation: Any) -> dict[str, Any]:
    config = getattr(conversation, "config", None)
    return {
        "agent_id": getattr(conversation, "agent_id", None),
        "user_id": getattr(conversation, "user_id", None),
        "requires_auth": getattr(conversation, "requires_auth", None),
        "text_only": getattr(conversation, "audio_interface", None) is None,
        "environment": getattr(conversation, "environment", None),
        "conversation_config_override": getattr(
            config, "conversation_config_override", None
        ),
        "dynamic_variables": getattr(config, "dynamic_variables", None),
    }


def _record_event(state: _ConversationState, message: dict[str, Any]) -> None:
    event_type = message.get("type")
    if event_type == "conversation_initiation_metadata":
        event = message.get("conversation_initiation_metadata_event") or {}
        if event.get("conversation_id"):
            state.span.set_attribute(
                "elevenlabs.conversation_id", str(event["conversation_id"])
            )
    elif event_type == "agent_response":
        event = message.get("agent_response_event") or {}
        text = str(event.get("agent_response", "")).strip()
        if text:
            _record_output_message(state, text)
    elif event_type == "agent_response_correction":
        event = message.get("agent_response_correction_event") or {}
        text = str(event.get("corrected_agent_response", "")).strip()
        if text:
            _record_output_message(state, text)
    elif event_type == "agent_chat_response_part":
        event = message.get("text_response_part") or {}
        text = str(event.get("text", "")).strip()
        if text:
            _record_output_message(state, text)
    elif event_type == "user_transcript":
        event = message.get("user_transcription_event") or {}
        text = str(event.get("user_transcript", "")).strip()
        if text:
            _record_input_message(state, text)


def _record_input_message(state: _ConversationState, text: str) -> None:
    prefix = OpenInferenceAttribute.input_message_prefix(state.input_messages)
    state.input_messages += 1
    state.span.set_attribute(OpenInferenceAttribute.role(prefix), MessageRole.USER)
    state.span.set_attribute(OpenInferenceAttribute.content(prefix), text)


def _record_output_message(state: _ConversationState, text: str) -> None:
    prefix = OpenInferenceAttribute.output_message_prefix(state.output_messages)
    state.output_messages += 1
    state.span.set_attribute(OpenInferenceAttribute.role(prefix), MessageRole.ASSISTANT)
    state.span.set_attribute(OpenInferenceAttribute.content(prefix), text)
    state.span.set_attribute(Attr.OUTPUT_VALUE, text)
    state.last_output = text


def _finish_state(conversation: Any, state: _ConversationState) -> None:
    if state.ended:
        return
    conversation_id = getattr(conversation, "_conversation_id", None)
    if conversation_id:
        state.span.set_attribute("elevenlabs.conversation_id", str(conversation_id))
    if state.last_output is not None:
        state.span.set_attribute(Attr.OUTPUT_VALUE, state.last_output)
    state.span.set_attribute(Attr.AGENT_TOOL_CALL_COUNT, state.tool_calls)
    state.span.set_attribute(Attr.AGENT_LLM_CALL_COUNT, state.output_messages)
    if not state.failed:
        state.span.set_status(Status(StatusCode.OK))
    state.span.end()
    state.ended = True
    _CLIENT_TOOLS_STATE.pop(id(conversation.client_tools), None)


def _record_error(span: Span, exc: BaseException) -> None:
    span.record_exception(exc)
    span.set_status(Status(StatusCode.ERROR, str(exc)))


def _mark_state_error(state: _ConversationState, exc: BaseException) -> None:
    state.failed = True
    _record_error(state.span, exc)


def _json(value: Any) -> str:
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str)
    except Exception:
        return str(value)
