"""``catalyst_tracing.langgraph`` granular entry-point import."""

from __future__ import annotations

from .installers.langgraph import install_langgraph

__all__ = ["install_langgraph"]
