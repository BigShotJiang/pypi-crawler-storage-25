"""``catalyst_tracing.claude_agent_sdk`` — granular entry-point import
for the Claude Agent SDK integration.

Example::

    from catalyst_tracing import setup
    from catalyst_tracing.claude_agent_sdk import install_claude_agent_sdk

    tracing = setup()
    install_claude_agent_sdk(tracing.provider)

    # `from claude_agent_sdk import query` continues to read the
    # wrapped function. The patch covers both the package-level and
    # submodule bindings.
"""

from __future__ import annotations

from .installers.claude_agent_sdk import install_claude_agent_sdk

__all__ = ["install_claude_agent_sdk"]
