"""``catalyst_tracing.openai`` — granular entry-point import for the
OpenAI integration.

Mirror of the TS ``@inference/tracing/openai`` entry point: import this
when you only need the OpenAI patcher and want to skip the
multi-SDK :func:`catalyst_tracing.setup` orchestration.

Example::

    from catalyst_tracing import setup
    from catalyst_tracing.openai import install_openai

    tracing = setup()
    install_openai(tracing.provider)
"""

from __future__ import annotations

from .installers.openai import install_openai

__all__ = ["install_openai"]
