"""``catalyst_tracing.langsmith`` granular entry-point import."""

from __future__ import annotations

from .installers.langsmith import install_langsmith

__all__ = ["install_langsmith"]
