"""Tests for CLDPM."""
