from __future__ import annotations

from pathlib import Path

from huggingface_hub import hf_hub_download

DEFAULT_HF_REPO = "lemondouble/lemon-manga-translator"
DEFAULT_CACHE_DIR = "lemon_manga_translator_cache"

CTD_ONNX_PATH = "onnx/comic-text-detector/ctd.onnx"
AOT_ONNX_PATH = "onnx/aot-inpainting/aot_folded.onnx"
AOT_CONFIG_PATH = "pytorch/aot-inpainting/config.json"


def _resolve_local(model_source: str | Path) -> dict[str, Path]:
    root = Path(model_source)
    return {
        "ctd_onnx": root / CTD_ONNX_PATH,
        "aot_onnx": root / AOT_ONNX_PATH,
        "aot_config": root / AOT_CONFIG_PATH,
    }


def _resolve_hf(
    repo_id: str,
    cache_dir: str | Path | None = None,
    token: str | None = None,
) -> dict[str, Path]:
    files = {
        "ctd_onnx": CTD_ONNX_PATH,
        "aot_onnx": AOT_ONNX_PATH,
        "aot_config": AOT_CONFIG_PATH,
    }
    resolved: dict[str, Path] = {}
    for key, filename in files.items():
        local = hf_hub_download(
            repo_id=repo_id,
            filename=filename,
            cache_dir=str(cache_dir) if cache_dir else None,
            token=token,
        )
        resolved[key] = Path(local)
    return resolved


def resolve_model_paths(
    model_source: str | Path = DEFAULT_HF_REPO,
    cache_dir: str | Path | None = None,
    hf_token: str | None = None,
) -> dict[str, Path]:
    source = str(model_source)
    source_path = Path(source)
    if source_path.is_dir():
        return _resolve_local(source_path)
    return _resolve_hf(source, cache_dir=cache_dir, token=hf_token)
