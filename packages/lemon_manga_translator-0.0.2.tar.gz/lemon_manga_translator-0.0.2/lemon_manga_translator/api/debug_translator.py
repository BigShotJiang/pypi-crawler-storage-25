from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
from PIL import Image
from pydantic import ConfigDict

from ..debug import PipelineDebugRecorder
from ..detection import ComicTextDetection
from ..pipeline import run_pipeline
from ..translation import VisionBlockResult
from .result import TranslationResult
from .translator import MangaTranslator


class DebugResult(TranslationResult):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    detection: ComicTextDetection
    inpainted: Image.Image
    vision_results: list[VisionBlockResult]
    mask_final: np.ndarray

    def save_all(self, dir: str | Path) -> None:
        d = Path(dir)
        d.mkdir(parents=True, exist_ok=True)
        self.image.save(d / "final.png")
        self.inpainted.save(d / "inpainted.png")
        Image.fromarray(self.mask_final, mode="L").save(d / "mask_final.png")


class DebugTranslator(MangaTranslator):
    def translate(
        self,
        image: Image.Image,
        *,
        debug_dir: str | Path | None = None,
    ) -> DebugResult:
        if not self._prepared:
            raise RuntimeError(
                "DebugTranslator.prepare()를 먼저 호출하세요."
            )

        rgb = image.convert("RGB")
        recorder = None
        if debug_dir is not None:
            out_path = Path(debug_dir)
            out_path.mkdir(parents=True, exist_ok=True)
            recorder = PipelineDebugRecorder(out_path)

        result = run_pipeline(
            image=rgb,
            ctd=self._ctd,
            aot=self._aot,
            client=self._client,
            stack=self._stack,
            recorder=recorder,
        )

        if recorder is not None:
            recorder.record_final(result.final)

        return DebugResult(
            image=result.final,
            detection=result.detection,
            inpainted=result.inpainted,
            vision_results=result.vision_results,
            mask_final=result.mask_final,
        )
