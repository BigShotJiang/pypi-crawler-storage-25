from __future__ import annotations

from pathlib import Path
from typing import Any

from PIL import Image
from pydantic import BaseModel, ConfigDict


class TranslationResult(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    image: Image.Image

    def save(self, path: str | Path) -> None:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        self.image.save(str(p))
