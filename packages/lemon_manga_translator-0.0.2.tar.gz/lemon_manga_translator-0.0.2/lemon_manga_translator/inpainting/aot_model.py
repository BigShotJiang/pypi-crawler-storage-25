"""AOT generator — zyddnys/manga-image-translator inpainting_aot.py를 포팅.

state_dict 키는 manga-image-translator beta-0.3의 ``inpainting.ckpt``
(sha256: 878d541c…)와 mayocream/aot-inpainting safetensors 양쪽과 호환.
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def relu_nf(x: torch.Tensor) -> torch.Tensor:
    return F.relu(x) * 1.7139588594436646


class LambdaLayer(nn.Module):
    def __init__(self, f):
        super().__init__()
        self.f = f

    def forward(self, x):
        return self.f(x)


class ScaledWSConv2d(nn.Conv2d):
    # Scaled Weight Standardization (NFNet 스타일)

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size,
        stride: int = 1,
        padding: int = 0,
        dilation: int = 1,
        groups: int = 1,
        bias: bool = True,
        gain: bool = True,
        eps: float = 1e-4,
    ):
        super().__init__(
            in_channels, out_channels, kernel_size, stride, padding, dilation, groups, bias
        )
        if gain:
            self.gain = nn.Parameter(torch.ones(self.out_channels, 1, 1, 1))
        else:
            self.gain = None
        self.eps = eps

    def get_weight(self) -> torch.Tensor:
        fan_in = np.prod(self.weight.shape[1:])
        var, mean = torch.var_mean(self.weight, dim=(1, 2, 3), keepdims=True)
        scale = torch.rsqrt(
            torch.max(var * fan_in, torch.tensor(self.eps, device=var.device))
        ) * self.gain.view_as(var)
        shift = mean * scale
        return self.weight * scale - shift

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.conv2d(
            x, self.get_weight(), self.bias, self.stride, self.padding, self.dilation, self.groups
        )


class ScaledWSTransposeConv2d(nn.ConvTranspose2d):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size,
        stride: int = 1,
        padding: int = 0,
        output_padding: int = 0,
        groups: int = 1,
        bias: bool = True,
        dilation: int = 1,
        gain: bool = True,
        eps: float = 1e-4,
    ):
        super().__init__(
            in_channels,
            out_channels,
            kernel_size,
            stride,
            padding,
            output_padding,
            groups,
            bias,
            dilation,
            "zeros",
        )
        if gain:
            self.gain = nn.Parameter(torch.ones(self.in_channels, 1, 1, 1))
        else:
            self.gain = None
        self.eps = eps

    def get_weight(self) -> torch.Tensor:
        fan_in = np.prod(self.weight.shape[1:])
        var, mean = torch.var_mean(self.weight, dim=(1, 2, 3), keepdims=True)
        scale = torch.rsqrt(
            torch.max(var * fan_in, torch.tensor(self.eps, device=var.device))
        ) * self.gain.view_as(var)
        shift = mean * scale
        return self.weight * scale - shift

    def forward(self, x: torch.Tensor, output_size: Optional[List[int]] = None) -> torch.Tensor:
        output_padding = self._output_padding(
            x, output_size, self.stride, self.padding, self.kernel_size, 2, self.dilation
        )
        return F.conv_transpose2d(
            x,
            self.get_weight(),
            self.bias,
            self.stride,
            self.padding,
            output_padding,
            self.groups,
            self.dilation,
        )


class GatedWSConvPadded(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, ks: int, stride: int = 1, dilation: int = 1):
        super().__init__()
        self.padding = nn.ReflectionPad2d(((ks - 1) * dilation) // 2)
        self.conv = ScaledWSConv2d(in_ch, out_ch, kernel_size=ks, stride=stride, dilation=dilation)
        self.conv_gate = ScaledWSConv2d(
            in_ch, out_ch, kernel_size=ks, stride=stride, dilation=dilation
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.padding(x)
        signal = self.conv(x)
        gate = torch.sigmoid(self.conv_gate(x))
        return signal * gate * 1.8


class GatedWSTransposeConvPadded(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, ks: int, stride: int = 1):
        super().__init__()
        self.conv = ScaledWSTransposeConv2d(
            in_ch, out_ch, kernel_size=ks, stride=stride, padding=(ks - 1) // 2
        )
        self.conv_gate = ScaledWSTransposeConv2d(
            in_ch, out_ch, kernel_size=ks, stride=stride, padding=(ks - 1) // 2
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        signal = self.conv(x)
        gate = torch.sigmoid(self.conv_gate(x))
        return signal * gate * 1.8


def my_layer_norm(feat: torch.Tensor) -> torch.Tensor:
    mean = feat.mean((2, 3), keepdim=True)
    std = feat.std((2, 3), keepdim=True) + 1e-9
    feat = 2 * (feat - mean) / std - 1
    feat = 5 * feat
    return feat


class AOTBlock(nn.Module):
    def __init__(self, dim: int, rates: List[int]):
        super().__init__()
        self.rates = list(rates)
        for i, rate in enumerate(self.rates):
            self.__setattr__(
                f"block{str(i).zfill(2)}",
                nn.Sequential(
                    nn.ReflectionPad2d(rate),
                    nn.Conv2d(dim, dim // 4, 3, padding=0, dilation=rate),
                    nn.ReLU(True),
                ),
            )
        self.fuse = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(dim, dim, 3, padding=0, dilation=1),
        )
        self.gate = nn.Sequential(
            nn.ReflectionPad2d(1),
            nn.Conv2d(dim, dim, 3, padding=0, dilation=1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = [self.__getattr__(f"block{str(i).zfill(2)}")(x) for i in range(len(self.rates))]
        out = torch.cat(out, 1)
        out = self.fuse(out)
        mask = my_layer_norm(self.gate(x))
        mask = torch.sigmoid(mask)
        return x * (1 - mask) + out * mask


class AOTGenerator(nn.Module):
    # 기본값은 mayocream/aot-inpainting/config.json과 일치

    def __init__(
        self,
        in_ch: int = 4,
        out_ch: int = 3,
        ch: int = 32,
        num_blocks: int = 10,
        dilation_rates: Optional[List[int]] = None,
    ):
        super().__init__()
        if dilation_rates is None:
            dilation_rates = [2, 4, 8, 16]

        self.head = nn.Sequential(
            GatedWSConvPadded(in_ch, ch, 3, stride=1),
            LambdaLayer(relu_nf),
            GatedWSConvPadded(ch, ch * 2, 4, stride=2),
            LambdaLayer(relu_nf),
            GatedWSConvPadded(ch * 2, ch * 4, 4, stride=2),
        )

        self.body_conv = nn.Sequential(
            *[AOTBlock(ch * 4, rates=dilation_rates) for _ in range(num_blocks)]
        )

        self.tail = nn.Sequential(
            GatedWSConvPadded(ch * 4, ch * 4, 3, 1),
            LambdaLayer(relu_nf),
            GatedWSConvPadded(ch * 4, ch * 4, 3, 1),
            LambdaLayer(relu_nf),
            GatedWSTransposeConvPadded(ch * 4, ch * 2, 4, 2),
            LambdaLayer(relu_nf),
            GatedWSTransposeConvPadded(ch * 2, ch, 4, 2),
            LambdaLayer(relu_nf),
            GatedWSConvPadded(ch, out_ch, 3, stride=1),
        )

    def forward(self, img: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        x = torch.cat([mask, img], dim=1)
        x = self.head(x)
        conv = self.body_conv(x)
        x = self.tail(conv)
        if self.training:
            return x
        return torch.clip(x, -1, 1)
