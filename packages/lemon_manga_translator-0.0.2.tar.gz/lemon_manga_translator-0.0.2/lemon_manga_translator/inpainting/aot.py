from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import onnxruntime as ort
from PIL import Image

MASK_REBINARIZE_THRESHOLD = 127


def _make_session(path: str, device: str) -> ort.InferenceSession:
    d = device.lower()
    providers = (
        ["CUDAExecutionProvider", "CPUExecutionProvider"]
        if d in ("cuda", "gpu")
        else ["CPUExecutionProvider"]
    )
    opts = ort.SessionOptions()
    opts.enable_cpu_mem_arena = False
    return ort.InferenceSession(path, sess_options=opts, providers=providers)


@dataclass
class AotConfig:
    input_channels: int = 4
    output_channels: int = 3
    base_channels: int = 32
    num_blocks: int = 10
    dilation_rates: tuple[int, ...] = (2, 4, 8, 16)
    pad_multiple: int = 8
    default_max_side: int = 1024

    @classmethod
    def from_json(cls, path: Path) -> "AotConfig":
        data = json.loads(Path(path).read_text())
        if data.get("model_type") != "manga-image-translator-aot":
            raise ValueError(f"unexpected model_type: {data.get('model_type')}")
        return cls(
            input_channels=data["input_channels"],
            output_channels=data["output_channels"],
            base_channels=data["base_channels"],
            num_blocks=data["num_blocks"],
            dilation_rates=tuple(data["dilation_rates"]),
            pad_multiple=data["pad_multiple"],
            default_max_side=data["default_max_side"],
        )


def _round_up_multiple(value: int, multiple: int) -> int:
    if value % multiple == 0:
        return value
    return value + (multiple - value % multiple)


def _resize_keep_aspect(w: int, h: int, max_side: int) -> tuple[int, int]:
    ratio = max_side / max(w, h)
    return (max(1, round(w * ratio)), max(1, round(h * ratio)))


class AotInpainter:
    def __init__(self, session: ort.InferenceSession, config: AotConfig):
        self.session = session
        self.config = config

    @classmethod
    def load(
        cls,
        weights_path: str | Path,
        config_path: str | Path,
        device: str = "cpu",
    ) -> "AotInpainter":
        config = AotConfig.from_json(Path(config_path))
        session = _make_session(str(weights_path), device)
        return cls(session=session, config=config)

    def infer(
        self,
        image: Image.Image,
        mask: Image.Image,
        max_side: Optional[int] = None,
    ) -> Image.Image:
        if image.size != mask.size:
            raise ValueError(f"image/mask size mismatch: {image.size} vs {mask.size}")

        max_side = max_side or self.config.default_max_side
        original_rgb = image.convert("RGB")
        original_mask = mask.convert("L")

        mask_np = np.asarray(original_mask, dtype=np.uint8)
        mask_bin = np.where(mask_np >= MASK_REBINARIZE_THRESHOLD, 255, 0).astype(np.uint8)
        original_mask_bin = Image.fromarray(mask_bin, mode="L")

        w, h = original_rgb.size
        work_rgb = original_rgb
        work_mask = original_mask_bin

        if max(w, h) > max_side:
            new_w, new_h = _resize_keep_aspect(w, h, max_side)
            work_rgb = work_rgb.resize((new_w, new_h), Image.BILINEAR)
            work_mask = work_mask.resize((new_w, new_h), Image.BILINEAR)

        mw = _round_up_multiple(work_rgb.width, self.config.pad_multiple)
        mh = _round_up_multiple(work_rgb.height, self.config.pad_multiple)
        if (mw, mh) != work_rgb.size:
            work_rgb = work_rgb.resize((mw, mh), Image.BILINEAR)
            work_mask = work_mask.resize((mw, mh), Image.BILINEAR)

        # bilinear 리사이즈가 중간값을 만들기 때문에 재이진화 필요
        work_mask_np = np.asarray(work_mask, dtype=np.uint8)
        work_mask_np = np.where(
            work_mask_np >= MASK_REBINARIZE_THRESHOLD, 255, 0
        ).astype(np.uint8)

        img_np = np.asarray(work_rgb, dtype=np.float32) / 127.5 - 1.0
        mask_f = work_mask_np.astype(np.float32) / 255.0

        img_chw = np.transpose(img_np, (2, 0, 1))[None, ...]  # (1, 3, H, W)
        mask_chw = mask_f[None, None, ...]  # (1, 1, H, W)

        # manga-image-translator 규약: 모델은 마스킹된(0) 입력을 본다
        masked_img = img_chw * (1.0 - mask_chw)

        # ONNX 모델은 내부에서 clip(-1, 1)까지 수행한다.
        out = self.session.run(
            None, {"image": masked_img.astype(np.float32), "mask": mask_chw.astype(np.float32)}
        )[0]

        out_np = ((out.squeeze(0).transpose(1, 2, 0) + 1.0) * 127.5).clip(0, 255)
        predicted = Image.fromarray(out_np.astype(np.uint8), mode="RGB")

        if predicted.size != original_rgb.size:
            predicted = predicted.resize(original_rgb.size, Image.BILINEAR)

        composed = _composite(original_rgb, predicted, original_mask_bin)
        return composed


def _composite(original: Image.Image, predicted: Image.Image, mask: Image.Image) -> Image.Image:
    orig_np = np.asarray(original, dtype=np.uint8)
    pred_np = np.asarray(predicted, dtype=np.uint8)
    mask_np = np.asarray(mask, dtype=np.uint8)
    out = np.where(mask_np[..., None] > 0, pred_np, orig_np)
    return Image.fromarray(out, mode="RGB")
