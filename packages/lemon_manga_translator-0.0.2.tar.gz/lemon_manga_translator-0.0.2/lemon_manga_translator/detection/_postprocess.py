"""CTD 후처리(YOLO NMS)를 torch 없이 수행하는 numpy 구현.

CTD 파이프라인은 `CONFIDENCE_THRESHOLD=0.1` / `NMS_THRESHOLD=0.2`로
기본 경로(classes=None, multi_label=False, labels=())만 사용한다. 따라서
manga-image-translator 벤더 구현의 multi-label / apriori labels 갈래는 포팅하지 않고,
``torchvision.ops.nms``만 greedy numpy NMS로 대체한다.
"""

from __future__ import annotations

import numpy as np


MAX_WH_OFFSET = 4096  # 클래스별 NMS 분리용(원본 yolov5 규약과 동일)


def _xywh2xyxy(x: np.ndarray) -> np.ndarray:
    y = np.empty_like(x)
    y[:, 0] = x[:, 0] - x[:, 2] / 2
    y[:, 1] = x[:, 1] - x[:, 3] / 2
    y[:, 2] = x[:, 0] + x[:, 2] / 2
    y[:, 3] = x[:, 1] + x[:, 3] / 2
    return y


def _nms_greedy(boxes: np.ndarray, scores: np.ndarray, iou_thres: float) -> np.ndarray:
    """표준 greedy NMS. torchvision.ops.nms와 동일 규약(score 내림차순, IoU ≤ 유지)."""
    if boxes.size == 0:
        return np.empty(0, dtype=np.int64)
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    areas = (x2 - x1) * (y2 - y1)
    order = scores.argsort()[::-1]

    keep: list[int] = []
    while order.size > 0:
        i = int(order[0])
        keep.append(i)
        if order.size == 1:
            break
        rest = order[1:]
        xx1 = np.maximum(x1[i], x1[rest])
        yy1 = np.maximum(y1[i], y1[rest])
        xx2 = np.minimum(x2[i], x2[rest])
        yy2 = np.minimum(y2[i], y2[rest])
        w = np.maximum(0.0, xx2 - xx1)
        h = np.maximum(0.0, yy2 - yy1)
        inter = w * h
        union = areas[i] + areas[rest] - inter
        # union=0은 이론상 발생 안 하나(양수 area) 안전장치.
        iou = np.where(union > 0, inter / np.maximum(union, 1e-9), 0.0)
        order = rest[iou <= iou_thres]

    return np.asarray(keep, dtype=np.int64)


def non_max_suppression_numpy(
    prediction: np.ndarray,
    conf_thres: float = 0.25,
    iou_thres: float = 0.45,
    max_nms: int = 30000,
    max_det: int = 300,
) -> list[np.ndarray]:
    """YOLOv5 출력(shape=(B, N, 5+nc))에 conf 필터 + 클래스별 NMS 적용.

    반환: 배치별 (n, 6) 배열 [x1, y1, x2, y2, conf, cls].
    """
    if prediction.ndim != 3 or prediction.shape[2] < 6:
        raise ValueError(f"expected (B, N, 5+nc) prediction, got {prediction.shape}")

    output: list[np.ndarray] = []
    xc = prediction[..., 4] > conf_thres  # (B, N)

    for i, x in enumerate(prediction):
        x = x[xc[i]]
        if x.shape[0] == 0:
            output.append(np.zeros((0, 6), dtype=np.float32))
            continue

        # conf = obj_conf * cls_conf
        x[:, 5:] *= x[:, 4:5]
        boxes = _xywh2xyxy(x[:, :4])

        # best class only
        cls_scores = x[:, 5:]
        best_cls = cls_scores.argmax(axis=1)
        best_conf = cls_scores[np.arange(cls_scores.shape[0]), best_cls]
        keep = best_conf > conf_thres
        if not keep.any():
            output.append(np.zeros((0, 6), dtype=np.float32))
            continue

        boxes = boxes[keep]
        confs = best_conf[keep]
        clses = best_cls[keep].astype(np.float32)
        n = boxes.shape[0]
        if n > max_nms:
            top = confs.argsort()[::-1][:max_nms]
            boxes, confs, clses = boxes[top], confs[top], clses[top]

        # 클래스별로 분리된 batched NMS: 각 박스를 class_id * MAX_WH_OFFSET만큼 평행이동해
        # 다른 클래스끼리 IoU가 0이 되도록 한다.
        offsets = clses.reshape(-1, 1) * MAX_WH_OFFSET
        nms_boxes = boxes + offsets
        keep_idx = _nms_greedy(nms_boxes, confs, iou_thres)
        if keep_idx.size > max_det:
            keep_idx = keep_idx[:max_det]

        det = np.concatenate(
            [boxes[keep_idx], confs[keep_idx, None], clses[keep_idx, None]], axis=1
        ).astype(np.float32)
        output.append(det)

    return output
