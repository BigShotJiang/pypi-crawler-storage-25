"""Vendored torch 코드(모델 정의 + NMS)를 담는 하위 패키지.

런타임에서는 ONNX만 쓰므로 이 패키지를 직접 import하지 않는다. 내용은 ONNX
export 스크립트(``scripts/export_ctd_onnx.py``)에서 모델 재구성용으로만 쓰인다.

의도적으로 top-level에서 torch 의존 모듈을 끌어오지 않는다(런타임이 torch 없이
로드되도록). 필요한 심볼은 구체 모듈 경로에서 직접 import하라.
"""
