"""CTD 백본 + 마스크 헤드만 (DBNet 라인 헤드 제거).

원본은 manga-image-translator의 ``manga_translator/detection/ctd_utils/basemodel.py``.
우리 파이프라인은 Vision LLM이 OCR을 직접 하므로 라인 단위 폴리곤(DBHead 출력)이
필요 없어, ``DBHead`` / ``TextDetector`` / ``TextDetBaseDNN`` 등은 제거했다.
``TextDetBase``는 YOLO bbox + UNet 마스크만 반환한다.
"""

import torch
import torch.nn as nn

from .utils.yolov5_utils import fuse_conv_and_bn
from .yolov5.yolo import load_yolov5_ckpt
from .yolov5.common import C3, Conv


class double_conv_up_c3(nn.Module):
    def __init__(self, in_ch, mid_ch, out_ch, act=True):
        super().__init__()
        self.conv = nn.Sequential(
            C3(in_ch + mid_ch, mid_ch, act=act),
            nn.ConvTranspose2d(mid_ch, out_ch, kernel_size=4, stride=2, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.conv(x)


class double_conv_c3(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1, act=True):
        super().__init__()
        self.down = nn.AvgPool2d(2, stride=2) if stride > 1 else None
        self.conv = C3(in_ch, out_ch, act=act)

    def forward(self, x):
        if self.down is not None:
            x = self.down(x)
        return self.conv(x)


class UnetHead(nn.Module):
    def __init__(self, act=True) -> None:
        super().__init__()
        self.down_conv1 = double_conv_c3(512, 512, 2, act=act)
        self.upconv0 = double_conv_up_c3(0, 512, 256, act=act)
        self.upconv2 = double_conv_up_c3(256, 512, 256, act=act)
        self.upconv3 = double_conv_up_c3(0, 512, 256, act=act)
        self.upconv4 = double_conv_up_c3(128, 256, 128, act=act)
        self.upconv5 = double_conv_up_c3(64, 128, 64, act=act)
        self.upconv6 = nn.Sequential(
            nn.ConvTranspose2d(64, 1, kernel_size=4, stride=2, padding=1, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, f160, f80, f40, f20, f3):
        d10 = self.down_conv1(f3)
        u20 = self.upconv0(d10)
        u40 = self.upconv2(torch.cat([f20, u20], dim=1))
        u80 = self.upconv3(torch.cat([f40, u40], dim=1))
        u160 = self.upconv4(torch.cat([f80, u80], dim=1))
        u320 = self.upconv5(torch.cat([f160, u160], dim=1))
        return self.upconv6(u320)


def get_base_det_models(model_path, device="cpu", act="leaky"):
    """체크포인트에서 YOLO 백본 + UNet 마스크 헤드만 로드. text_det는 무시."""
    textdetector_dict = torch.load(model_path, map_location=device)
    blk_det = load_yolov5_ckpt(textdetector_dict["blk_det"], map_location=device)
    text_seg = UnetHead(act=act)
    text_seg.load_state_dict(textdetector_dict["text_seg"])
    return blk_det.eval().to(device), text_seg.eval().to(device)


class TextDetBase(nn.Module):
    """YOLO bbox + UNet 마스크만 반환하는 경량 래퍼."""

    def __init__(self, model_path, device="cpu", fuse=False, act="leaky"):
        super().__init__()
        self.blk_det, self.text_seg = get_base_det_models(model_path, device, act=act)
        if fuse:
            self.fuse()

    def fuse(self):
        for m in self.text_seg.modules():
            if isinstance(m, Conv) and hasattr(m, "bn"):
                m.conv = fuse_conv_and_bn(m.conv, m.bn)
                delattr(m, "bn")
                m.forward = m.forward_fuse
        return self

    def forward(self, features):
        blks, features = self.blk_det(features, detect=True)
        mask = self.text_seg(*features)
        return blks[0], mask
