from lemon_manga_translator.detection.ctd import ComicTextDetection, ComicTextDetector

__all__ = ["ComicTextDetector", "ComicTextDetection"]
