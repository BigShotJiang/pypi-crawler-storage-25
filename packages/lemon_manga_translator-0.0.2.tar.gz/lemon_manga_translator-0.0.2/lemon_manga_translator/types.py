from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class BBox:
    x: float
    y: float
    width: float
    height: float

    @property
    def x1(self) -> float:
        return self.x + self.width

    @property
    def y1(self) -> float:
        return self.y + self.height

    def clip_to_image(
        self, image_w: int, image_h: int, pad: int = 0
    ) -> tuple[int, int, int, int]:
        x0 = max(0, int(round(self.x - pad)))
        y0 = max(0, int(round(self.y - pad)))
        x1 = min(image_w, int(round(self.x1 + pad)))
        y1 = min(image_h, int(round(self.y1 + pad)))
        if x1 <= x0 or y1 <= y0:
            return 0, 0, 0, 0
        return x0, y0, x1, y1


@dataclass
class TextBlock:
    bbox: BBox
    translation: Optional[str] = None
    # None이면 렌더러가 bbox를 그대로 사용
    render_bbox: Optional[BBox] = None
