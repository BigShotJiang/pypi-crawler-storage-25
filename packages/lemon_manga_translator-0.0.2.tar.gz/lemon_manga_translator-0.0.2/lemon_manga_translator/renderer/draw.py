"""Pillow의 ImageDraw.text()가 stroke_width/stroke_fill을 지원하므로
별도 2-pass 없이 아웃라인을 그릴 수 있다. FontStack 폴백 때문에 글자
단위로 폰트를 바꿔가며 draw.text()를 호출한다.
"""

from __future__ import annotations

from PIL import Image, ImageDraw

from .fonts import FontStack


def draw_line(
    draw: ImageDraw.ImageDraw,
    text: str,
    x: float,
    y: float,
    stack: FontStack,
    fill: tuple[int, int, int],
    stroke_fill: tuple[int, int, int] | None,
    stroke_width: int,
) -> None:
    pen_x = x
    for ch in text:
        font = stack.pick(ch)
        draw.text(
            (pen_x, y),
            ch,
            font=font,
            fill=fill,
            stroke_fill=stroke_fill,
            stroke_width=stroke_width,
        )
        pen_x += font.getlength(ch)


def draw_centered(
    image: Image.Image,
    box_x: float,
    box_y: float,
    box_w: float,
    box_h: float,
    lines: list[str],
    stack: FontStack,
    fill: tuple[int, int, int],
    stroke_fill: tuple[int, int, int] | None,
    stroke_width: int,
) -> None:
    draw = ImageDraw.Draw(image)
    line_h = stack.line_height
    # 마지막 줄엔 baseline 간격이 붙지 않으므로 glyph_height만 더함
    total_h = (len(lines) - 1) * line_h + stack.glyph_height if lines else 0.0

    start_y = box_y + (box_h - total_h) / 2.0
    for i, line in enumerate(lines):
        line_w = stack.measure(line)
        x = box_x + (box_w - line_w) / 2.0
        y = start_y + i * line_h
        draw_line(draw, line, x, y, stack, fill, stroke_fill, stroke_width)
