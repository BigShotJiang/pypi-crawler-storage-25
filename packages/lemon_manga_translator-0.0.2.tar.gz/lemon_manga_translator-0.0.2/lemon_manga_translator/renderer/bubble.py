"""Flood-fill로 말풍선 내부 영역을 찾아 렌더용 bbox로 확장.

나레이션 등 말풍선이 없는 텍스트는 flood가 페이지 배경까지 퍼지므로,
결과 면적이 ``max_area_ratio``를 넘거나 원본 bbox보다 작으면 원본을 유지.
"""

from __future__ import annotations

import cv2
import numpy as np

from ..types import BBox, TextBlock

# flood fill 색상 허용 오차 (BGR 각 채널)
FLOOD_TOLERANCE = (8, 8, 8)
# flood 결과 면적이 이미지 전체의 이 비율을 넘으면 말풍선이 아니라고 판단
DEFAULT_MAX_AREA_RATIO = 0.10
# flood 결과 면적이 원본 bbox의 이 배수를 넘으면 말풍선이 아니라고 판단
DEFAULT_MAX_EXPANSION_RATIO = 4.0
# 두 render_bbox가 이 비율 이상 겹치면 둘 다 원본 bbox로 되돌림
DEFAULT_OVERLAP_THRESHOLD = 0.5


def _flood_bbox(
    image_bgr: np.ndarray,
    seed: tuple[int, int],
) -> tuple[int, int, int, int] | None:
    h, w = image_bgr.shape[:2]
    sx, sy = seed
    if not (0 <= sx < w and 0 <= sy < h):
        return None
    ff_mask = np.zeros((h + 2, w + 2), dtype=np.uint8)
    # 원본 이미지 컬러 기준으로 비교하기 위해 복사본에 fill
    work = image_bgr.copy()
    flags = 4 | cv2.FLOODFILL_MASK_ONLY | (255 << 8)
    num, _, _, rect = cv2.floodFill(
        work,
        ff_mask,
        (sx, sy),
        newVal=0,
        loDiff=FLOOD_TOLERANCE,
        upDiff=FLOOD_TOLERANCE,
        flags=flags,
    )
    if num <= 0:
        return None
    x, y, rw, rh = rect
    if rw <= 0 or rh <= 0:
        return None
    return x, y, rw, rh


def compute_render_bbox(
    inpainted: np.ndarray,
    bbox: BBox,
    image_area: float,
    max_area_ratio: float = DEFAULT_MAX_AREA_RATIO,
    max_expansion_ratio: float = DEFAULT_MAX_EXPANSION_RATIO,
) -> BBox:
    H, W = inpainted.shape[:2]
    if inpainted.ndim == 3 and inpainted.shape[2] == 3:
        image_bgr = cv2.cvtColor(inpainted, cv2.COLOR_RGB2BGR)
    else:
        image_bgr = inpainted

    cx = int(round(bbox.x + bbox.width / 2))
    cy = int(round(bbox.y + bbox.height / 2))
    cx = max(0, min(W - 1, cx))
    cy = max(0, min(H - 1, cy))

    result = _flood_bbox(image_bgr, (cx, cy))
    if result is None:
        return bbox

    fx, fy, fw, fh = result
    flood_area = float(fw * fh)
    orig_area = float(bbox.width * bbox.height)

    if flood_area >= image_area * max_area_ratio:
        return bbox
    if orig_area > 0 and flood_area > orig_area * max_expansion_ratio:
        return bbox
    if orig_area >= flood_area:
        return bbox

    return BBox(x=float(fx), y=float(fy), width=float(fw), height=float(fh))


def _overlap_ratio(a: BBox, b: BBox) -> float:
    # IoMin(Intersection over Min). IoU 대신 작은 bbox가 먹힌 비율을 봐야
    # 큰 bbox가 작은 bbox를 거의 포함한 케이스까지 잡을 수 있다.
    ix0 = max(a.x, b.x)
    iy0 = max(a.y, b.y)
    ix1 = min(a.x1, b.x1)
    iy1 = min(a.y1, b.y1)
    iw = ix1 - ix0
    ih = iy1 - iy0
    if iw <= 0 or ih <= 0:
        return 0.0
    inter = iw * ih
    a_area = a.width * a.height
    b_area = b.width * b.height
    denom = min(a_area, b_area)
    if denom <= 0:
        return 0.0
    return inter / denom


def attach_render_bboxes(
    inpainted: np.ndarray,
    blocks: list[TextBlock],
    max_area_ratio: float = DEFAULT_MAX_AREA_RATIO,
    overlap_threshold: float = DEFAULT_OVERLAP_THRESHOLD,
) -> None:
    # 두 render_bbox가 overlap_threshold 이상 겹치면 양쪽 다 원본으로 되돌림.
    # O(n^2)지만 페이지당 블록 수가 적어 문제 없음.
    if not blocks:
        return
    H, W = inpainted.shape[:2]
    image_area = float(H * W)

    targets: list[int] = []
    for i, block in enumerate(blocks):
        if not (block.translation or "").strip():
            continue
        block.render_bbox = compute_render_bbox(
            inpainted, block.bbox, image_area, max_area_ratio=max_area_ratio
        )
        targets.append(i)

    reverted: set[int] = set()
    for ai_idx, i in enumerate(targets):
        for j in targets[ai_idx + 1 :]:
            a = blocks[i].render_bbox
            b = blocks[j].render_bbox
            if a is None or b is None:
                continue
            if _overlap_ratio(a, b) >= overlap_threshold:
                reverted.add(i)
                reverted.add(j)

    for i in reverted:
        blocks[i].render_bbox = blocks[i].bbox


__all__ = ["attach_render_bboxes", "compute_render_bbox"]
