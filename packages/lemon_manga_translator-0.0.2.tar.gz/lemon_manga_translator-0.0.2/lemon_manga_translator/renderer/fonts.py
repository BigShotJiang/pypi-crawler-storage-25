"""primary가 글자를 렌더하는지 판단은 getmask(ch) 결과를 notdef(U+FFFD)
마스크와 비교해서 확인한다. PIL이 커버리지 API를 안 주기 때문.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from PIL import ImageFont
from PIL.ImageFont import FreeTypeFont

_NOTDEF_PROBE = "\uFFFD"
LINE_SPACING_RATIO = 1.2


@dataclass
class _SizedFonts:
    primary: FreeTypeFont
    fallback: FreeTypeFont
    tofu: bytes  # size별 notdef 마스크 바이트


@dataclass
class FontStack:
    primary_path: Path
    fallback_path: Path
    size: int = 16
    # fit_font_size의 이진탐색이 같은 사이즈를 반복 요청하므로 사이즈별로 캐시
    _fonts: dict[int, _SizedFonts] = field(init=False, repr=False, default_factory=dict)
    # primary가 ch를 렌더할 수 있는지 여부. 폰트 내부 커버리지는 사이즈 무관
    _coverage: dict[str, bool] = field(init=False, repr=False, default_factory=dict)

    def __post_init__(self) -> None:
        self._ensure(self.size)

    def _ensure(self, size: int) -> _SizedFonts:
        cached = self._fonts.get(size)
        if cached is not None:
            return cached
        primary = ImageFont.truetype(str(self.primary_path), size)
        fallback = ImageFont.truetype(str(self.fallback_path), size)
        tofu = bytes(primary.getmask(_NOTDEF_PROBE))
        sized = _SizedFonts(primary=primary, fallback=fallback, tofu=tofu)
        self._fonts[size] = sized
        return sized

    def resize(self, size: int) -> None:
        self._ensure(size)
        self.size = size

    def _primary_has(self, ch: str) -> bool:
        if not ch:
            return True
        cached = self._coverage.get(ch)
        if cached is not None:
            return cached
        current = self._fonts[self.size]
        result = bytes(current.primary.getmask(ch)) != current.tofu
        self._coverage[ch] = result
        return result

    def pick(self, ch: str) -> FreeTypeFont:
        current = self._fonts[self.size]
        return current.primary if self._primary_has(ch) else current.fallback

    def char_width(self, ch: str) -> float:
        return self.pick(ch).getlength(ch)

    def measure(self, text: str) -> float:
        return sum(self.char_width(ch) for ch in text)

    @property
    def glyph_height(self) -> float:
        ascent, descent = self._fonts[self.size].primary.getmetrics()
        return ascent + descent

    @property
    def line_height(self) -> float:
        return self.glyph_height * LINE_SPACING_RATIO
