from lemon_manga_translator.api.result import TranslationResult
from lemon_manga_translator.api.translator import MangaTranslator

__all__ = ["MangaTranslator", "TranslationResult"]
