# SPDX-License-Identifier: AGPL-3.0-or-later
"""Deprecated alias. Use aiking.body.policy instead. Removal in persona-api 3.0.0 (~2026-11-01)."""
import warnings
from aiking.body.policy import *  # noqa: F401, F403

try:
    from aiking.body.policy import __all__  # noqa: F401
except ImportError:
    __all__ = []

warnings.warn(
    "persona.policy is deprecated; use aiking.body.policy. "
    "Removal in persona-api 3.0.0 (~2026-11-01).",
    DeprecationWarning, stacklevel=2,
)

def __getattr__(name):
    # PEP 562: handle `from persona.policy import X` for X not in __all__.
    import importlib
    mod = importlib.import_module('aiking.body.policy')
    return getattr(mod, name)
