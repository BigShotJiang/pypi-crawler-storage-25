# SPDX-License-Identifier: AGPL-3.0-or-later
"""Deprecated alias. Use aiking.body.middleware instead. Removal in persona-api 3.0.0 (~2026-11-01)."""
import warnings
from aiking.body.middleware import *  # noqa: F401, F403

try:
    from aiking.body.middleware import __all__  # noqa: F401
except ImportError:
    __all__ = []

warnings.warn(
    "persona.middleware is deprecated; use aiking.body.middleware. "
    "Removal in persona-api 3.0.0 (~2026-11-01).",
    DeprecationWarning, stacklevel=2,
)

def __getattr__(name):
    # PEP 562: handle `from persona.middleware import X` for X not in __all__.
    import importlib
    mod = importlib.import_module('aiking.body.middleware')
    return getattr(mod, name)
