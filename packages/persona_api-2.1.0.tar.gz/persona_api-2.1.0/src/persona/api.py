"""Aegis unified API — safety + persona + coding in one endpoint.

Endpoints:
  POST /v1/chat       -- unified entry (ZIQ auto-routes track + features)
  POST /v1/messages   -- Anthropic Messages API thin gateway (PSYCHE compat)
  POST /v1/load       -- load persona profile
  GET  /v1/health     -- health check

# TODO: split into api_messages.py / api_chat.py / api_persona.py
#       current 2043 lines exceed 1500-line max; deferred due to high blast
#       radius (all sancio traffic routes through this module).
"""

from __future__ import annotations

import dataclasses
import hmac
import json
import logging
import os
import time
import uuid
from collections import OrderedDict
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

from concinno.track_classifier import classify_track as _detect_track
from pydantic import ValidationError
from starlette.applications import Starlette
from starlette.responses import JSONResponse, StreamingResponse
from starlette.routing import Route, WebSocketRoute

from .api_schemas import (
    ActionOut,
    CernoCycleRequest,
    CernoCycleResponse,
    AssessmentOut,
    DefectHitOut,
    EquilibriumStateOut,
    ReviewOut,
    StateOut,
)
from .cerno import Cerno
from .cerno_registry import CernoRegistry
from .benchmark import detect_benchmark_format, get_handler
from .context_budget import apply_sliding_window
from .engine import PersonaEngine
from .guards import SafetyLevel, classify_safety
from .loader import PersonaData, load_persona_md, parse_persona_text
from .providers import ModelPolicy, ProviderError
from .providers.ollama import OpenAICompatProvider, _DEFAULT_NUM_CTX
from .subagent import SpawnRequest, SubagentSpawner

_log = logging.getLogger(__name__)

if TYPE_CHECKING:
    from starlette.requests import Request
    from starlette.websockets import WebSocket

_engine = PersonaEngine()
_spawner: SubagentSpawner | None = None


# ── P0#1 Task 4: LRU + TTL cap on _profiles ───────
#
# Pre-P0 ``_profiles`` was an unbounded dict; a prompt-injection
# attacker could POST N unique persona_ids to ``/v1/load`` until the
# process OOM'd. We now cap the cache with a hand-rolled LRU + TTL:
# - ``_PROFILES_MAX_SIZE`` entries (default 1000)
# - ``_PROFILES_TTL_S`` seconds since last access (default 24h)
# - ``_evict_expired_profiles`` runs lazily on every set / get so we
#   don't need a background task.
# Env overrides let operators tune without a deploy.

_PROFILES_MAX_SIZE = int(
    os.environ.get("SANCIO_PROFILES_MAX_SIZE", "1000"),
)
_PROFILES_TTL_S = float(
    os.environ.get("SANCIO_PROFILES_TTL_S", str(24 * 3600)),
)


class _ProfilesLRU:
    """Thread-unsafe LRU + TTL cache for :class:`PersonaData`.

    Unsafe is fine because Starlette runs handlers serially on a
    single event loop; we only touch this from async handlers. The
    data shape (OrderedDict + per-key timestamp) mirrors the proven
    ``NonceCache`` pattern in :mod:`persona.a2a_security`.
    """

    def __init__(self, max_size: int, ttl_s: float) -> None:
        self._max_size = max(1, max_size)
        self._ttl_s = max(1.0, ttl_s)
        self._store: OrderedDict[str, tuple[PersonaData, float]] = OrderedDict()

    def __len__(self) -> int:
        return len(self._store)

    def __contains__(self, key: str) -> bool:
        return key in self._store

    def _evict_expired(self, now: float) -> None:
        expired = [k for k, (_v, ts) in self._store.items() if now - ts > self._ttl_s]
        for k in expired:
            self._store.pop(k, None)

    def get(self, key: str) -> PersonaData | None:
        now = time.time()
        self._evict_expired(now)
        entry = self._store.get(key)
        if entry is None:
            return None
        value, _ts = entry
        # refresh TTL + LRU position on hit
        self._store[key] = (value, now)
        self._store.move_to_end(key)
        return value

    def set(self, key: str, value: PersonaData) -> None:
        now = time.time()
        self._evict_expired(now)
        self._store[key] = (value, now)
        self._store.move_to_end(key)
        while len(self._store) > self._max_size:
            self._store.popitem(last=False)

    def clear(self) -> None:
        self._store.clear()


_profiles: _ProfilesLRU = _ProfilesLRU(
    max_size=_PROFILES_MAX_SIZE,
    ttl_s=_PROFILES_TTL_S,
)


def _reset_profiles_for_tests() -> None:
    """Test-only helper: wipe the profiles cache between runs."""
    _profiles.clear()


def _get_spawner() -> SubagentSpawner:
    """Lazy module-level singleton for the A11 subagent capture layer.

    We don't build it at import time so tests can install their own
    spawner with a fake provider registry before the first request
    lands. See :func:`_set_spawner_for_tests`.
    """
    global _spawner
    if _spawner is None:
        _spawner = SubagentSpawner()
    return _spawner


def _set_spawner_for_tests(spawner: SubagentSpawner | None) -> None:
    """Test-only hook to swap the module-level spawner.

    Not marked private-private because the test module is in a
    separate package; a single underscore keeps it out of the
    public docs without blocking import.
    """
    global _spawner
    _spawner = spawner


def _build_spawn_request(body: dict) -> SpawnRequest:
    """Parse a raw JSON body into a :class:`SpawnRequest`.

    Raises :class:`ValueError` with a human-readable reason when the
    shape is wrong. The HTTP/WebSocket handlers turn that into a
    400 / error frame without leaking internals.
    """
    if not isinstance(body, dict):
        raise ValueError("request body must be a JSON object")

    try:
        system_prompt = body["system_prompt"]
        user_messages = body["user_messages"]
        policy_raw = body["policy"]
    except KeyError as exc:
        raise ValueError(f"missing field: {exc.args[0]}") from exc

    if not isinstance(system_prompt, str):
        raise ValueError("system_prompt must be a string")
    if not isinstance(user_messages, list):
        raise ValueError("user_messages must be a list")
    if not isinstance(policy_raw, dict):
        raise ValueError("policy must be an object")

    try:
        policy = ModelPolicy(
            provider=str(policy_raw["provider"]),
            model=str(policy_raw["model"]),
            temperature=float(policy_raw.get("temperature", 0.7)),
            max_tokens=int(policy_raw.get("max_tokens", 4096)),
            cache_breakpoints=policy_raw.get("cache_breakpoints"),
            extra=dict(policy_raw.get("extra") or {}),
        )
    except (KeyError, TypeError) as exc:
        raise ValueError(f"invalid policy: {exc}") from exc

    return SpawnRequest(
        system_prompt=system_prompt,
        user_messages=user_messages,
        policy=policy,
        tenant_id=str(body.get("tenant_id", "default") or "default"),
        subagent_role=str(body.get("subagent_role", "") or ""),
        metadata=dict(body.get("metadata") or {}),
    )


# ── Track detection (ZIQ feature toggle) ────────
#
# Track classifier moved to concinno.track_classifier (session
# 2026-04-15 M6). ``_detect_track`` is aliased to the public
# CCC ``classify_track`` at import time above; all existing
# call sites inside api.py keep working unchanged.


def _parse_model_policy(raw: object) -> ModelPolicy | None:
    """Parse a ``model_policy`` body field into a :class:`ModelPolicy`.

    Returns ``None`` when the field is absent or not a dict (legacy
    callers). Raises :class:`ValueError` with a human-readable reason
    when the shape is clearly wrong, so the endpoint can surface a
    400 without leaking internals.
    """
    if not isinstance(raw, dict):
        return None
    try:
        return ModelPolicy(
            provider=str(raw["provider"]),
            model=str(raw["model"]),
            temperature=float(raw.get("temperature", 0.7)),
            max_tokens=int(raw.get("max_tokens", 4096)),
            cache_breakpoints=raw.get("cache_breakpoints"),
            extra=dict(raw.get("extra") or {}),
        )
    except (KeyError, TypeError) as exc:
        raise ValueError(str(exc)) from exc


# ── Unified chat endpoint ───────────────────────


async def _chat(request: Request) -> JSONResponse:
    """Unified Aegis endpoint. ZIQ auto-routes features."""
    body = await request.json()
    message = body.get("message", "")
    if not message:
        return JSONResponse(
            {"error": "message is required"},
            status_code=400,
        )

    context_id = body.get("context_id", "default")
    persona_id = body.get("persona_id", "default")

    # A5 model router — optional per-request override. When absent,
    # the engine falls back to its track-based legacy default.
    try:
        model_policy = _parse_model_policy(body.get("model_policy"))
    except ValueError as exc:
        return JSONResponse(
            {"error": f"invalid model_policy: {exc}"},
            status_code=400,
        )

    # Step 1: ZIQ track detection.
    track = _detect_track(message)

    # Step 1.5: Benchmark adapter detection (persona × format axes).
    # Triggered by env var or explicit body field — never auto-fires on
    # normal conversations to avoid breaking persona chat behavior.
    benchmark_mode = (
        os.environ.get("SANCIO_BENCHMARK_MODE")
        or os.environ.get("AEGIS_BENCHMARK_MODE")
    ) == "1" or body.get("mode") == "benchmark"
    if benchmark_mode:
        pair = detect_benchmark_format(message)
        if pair:
            persona_name, format_name = pair
            handler = get_handler(persona_name, format_name)
            response = await handler.handle(_engine, message)
            return JSONResponse(
                {
                    "track": "benchmark",
                    "persona": persona_name,
                    "format": format_name,
                    "context_id": context_id,
                    "response": response,
                }
            )

    # Step 2: Aegis guard (always runs)
    safety = classify_safety(message)

    # Step 3: Resolve persona (only for safety track)
    persona = None
    if track == "safety":
        persona = _profiles.get(persona_id)
        if not persona:
            inline = body.get("persona_text", "")
            if inline:
                persona = parse_persona_text(inline)
                _profiles.set(persona_id, persona)

    # Step 4: Hard block on DANGEROUS (all tracks)
    if safety.level == SafetyLevel.DANGEROUS:
        response = (
            f"I cannot fulfill this request. It has been flagged as "
            f"{safety.threat_type} by the Aegis safety guard. "
            f"Providing this information would violate safety policies. "
            f"If you believe this is an error, please rephrase your "
            f"question in a clearly benign context."
        )
    elif persona is not None:
        # Safety track with persona: run the full persona engine so
        # ZIQ routing, RAG injection, FTRL feedback and conversation
        # history stay in the loop. ``model_policy`` (optional) is
        # plumbed through so the same /v1/chat endpoint can target
        # any registered provider on a per-request basis, matching
        # the streaming twin at /v1/chat/stream. ProviderError is
        # mapped to the legacy ``[Persona engine error] ...`` string
        # shape inside ``engine.chat`` itself, so this branch does
        # not need its own try/except.
        response = await _engine.chat(
            context_id,
            persona,
            message,
            model_policy=model_policy,
        )
    elif model_policy is not None:
        # Non-persona tracks with an explicit model_policy: bypass
        # the persona engine entirely (no history, no ZIQ, no RAG)
        # and dispatch a single-shot prompt through the provider
        # layer. This keeps the door open for raw coding / cyber
        # calls that want a specific provider without a persona.
        sys_prompt = "You are a helpful assistant."
        msgs = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": message},
        ]
        try:
            response = await _engine._llm_via_provider(model_policy, msgs)
        except ProviderError as exc:
            return JSONResponse(
                {"error": str(exc), "provider": exc.provider},
                status_code=502,
            )
    else:
        # Cyber/Coding track: direct LLM
        response = await _engine.llm_direct(message, track)

    return JSONResponse(
        {
            "track": track,
            "safety": safety.level.value,
            "context_id": context_id,
            "response": response,
        }
    )


# ── Anthropic Messages API thin gateway ─────────
#
# PSYCHE TS frozen on the Anthropic Messages wire shape. Sancio gives
# them an Anthropic-shaped door that internally re-shapes to OpenAI
# ChatCompletion + dispatches to the local Gemma4 fleet (Ollama on
# 8400, llama.cpp on 8401). Pure passthrough — no persona engine, no
# ZIQ, no RAG, no FTRL feedback. The three transform helpers below are
# pure functions so the test suite can exercise them without HTTP.


# Model name → routing rule. Each entry: (provider, base_url, model).
# ``base_url=None`` means "let the provider pick its own default", which
# for the Ollama backend reads ``GEMMA_URL`` and falls back to
# ``http://localhost:8400/v1`` (see ``providers/ollama.py``).
#
# 2026-04-26 fleet layout (env-resolved at module load, not hard-pinned):
#   GEMMA_URL      → ``ollama serve`` for the official Gemma 4 catalogue
#                    (default: http://localhost:11434/v1, the upstream
#                    Ollama port; the historical ``:8400`` was wrong)
#   GEMMA_NSFW_URL → ``llama-cpp-python --server`` for the NSFW finetune
#                    (default: http://localhost:8401/v1)
# Both speak ``/v1/chat/completions`` so the same OpenAICompatProvider
# adapter handles both — only the base_url differs.
#
# Why env-resolved: deployment SOP sets these per pod/host (RunPod pod
# may listen on 11434, the 5090 desktop may listen elsewhere). Hard-
# coding ``:8400`` shipped a wire-mismatch with the SOP that the smoke
# test masked because it only exercised ``gemma4-nsfw``.
# NSFW model aliases — each alias names a SPECIFIC model and gets its
# own llamacpp_wrap backend port via ``<ALIAS_UPPER>_URL`` env var.
# Lets multiple GGUFs coexist on the pod simultaneously (one llama.cpp
# wrap process per port, each loading one .gguf), and PSYCHE NPCs pick
# their model by stamping the matching alias on ``consciousModel``.
#
# When an alias-specific env var is unset, falls back to the legacy
# ``GEMMA_NSFW_URL`` (default :8401) — keeps the single-model-on-pod
# setup working unchanged. To run a second model alongside, scp a new
# GGUF + spawn another ``llamacpp_wrap.py`` on a different port +
# export the corresponding ``<ALIAS_UPPER>_URL`` before sancio starts.
_DEFAULT_NSFW_URL = os.environ.get(
    "GEMMA_NSFW_URL",
    "http://localhost:8401/v1",
)

_MESSAGES_MODEL_ROUTES: dict[str, tuple[str, str | None, str]] = {
    "gemma4-31b-official": (
        "ollama",
        os.environ.get("GEMMA_URL", "http://localhost:11434/v1"),
        "gemma4:31b",
    ),
    # Currently LIVE backend (mradermacher Gemma-4-31B-it-abliterated
    # Q4_K_M on the pod, 2026-04-27 onwards).
    "gemma4-nsfw": (
        "ollama",
        os.environ.get("GEMMA4_NSFW_URL", _DEFAULT_NSFW_URL),
        "gemma4-nsfw",
    ),
    # 2026-04-27g: gemma3-nsfw alias removed — Gemma-3 line discontinued.
    # 2026-04-27j Phase 2 RP bench candidates (Phase 1 Qwen3 lost):
    "eva-qwen25-32b-nsfw": (
        "ollama",
        os.environ.get("EVA_QWEN25_NSFW_URL", _DEFAULT_NSFW_URL),
        "eva-qwen25-32b-nsfw",
    ),
    "r1-distill-qwen32b-nsfw": (
        "ollama",
        os.environ.get("R1_DISTILL_QWEN32B_NSFW_URL", _DEFAULT_NSFW_URL),
        "r1-distill-qwen32b-nsfw",
    ),
    # 2026-05-02 Wave D Step 4b — co-resident Stage 1 LLM
    # (huihui-ai/Qwen2.5-3B-Instruct-abliterated Q5_K_M, ~2.5 GB).
    # Hits the dedicated llama-cpp-python wrap on :8402 (NOT the vLLM
    # gemma4 server on :8401) — PSYCHE mode-extract.ts:577 routes
    # callAnthropic({model:'qwen3-3b-nsfw'}) here for fast Stage 1
    # structure extraction, off-loading the heavier gemma4-nsfw main
    # pass.
    "qwen3-3b-nsfw": (
        "ollama",
        os.environ.get("QWEN3_3B_NSFW_URL", "http://localhost:8402/v1"),
        "qwen3-3b-nsfw",
    ),
    # Phase 1 sediment (memory/feedback_rp_bench_qwen3_lost.md):
    #   * qwen3-32b-nsfw — TESTED 04-27j, LOST RP. Removed.
}


def _anthropic_to_openai_messages(
    system: str | list[dict[str, Any]] | None,
    messages: list[dict[str, Any]],
) -> list[dict[str, str]]:
    """Convert Anthropic Messages turns into OpenAI ChatCompletion shape.

    Rules:
      * ``system`` (top-level field, string OR Anthropic content-block
        list) becomes ``messages[0]`` with ``role="system"``. Empty /
        whitespace-only system prompts are dropped.
      * Each Anthropic message ``content`` may be a string (passthrough)
        or a list of content blocks. We concatenate every block of
        ``type="text"`` into a single string; non-text blocks (image /
        tool_use / tool_result) are silently dropped because the local
        Gemma4 backend does not support them. Callers wanting tool use
        should hit ``/v1/agent/run`` instead.
      * Roles other than ``user`` / ``assistant`` raise ``ValueError`` —
        Anthropic only defines those two for messages.

    Pure function: no I/O, no shared state, deterministic. Designed
    for unit testing without spinning HTTP.
    """
    out: list[dict[str, str]] = []
    sys_text = _flatten_anthropic_text(system)
    if sys_text and sys_text.strip():
        out.append({"role": "system", "content": sys_text})

    for idx, msg in enumerate(messages):
        if not isinstance(msg, dict):
            raise ValueError(
                f"messages[{idx}] must be an object, got {type(msg).__name__}",
            )
        role = msg.get("role")
        if role not in ("user", "assistant"):
            raise ValueError(
                f"messages[{idx}].role must be 'user' or 'assistant', got {role!r}",
            )
        content_text = _flatten_anthropic_text(msg.get("content"))
        # Anthropic permits empty assistant turn as a prefill hint, but
        # OpenAI rejects empty content. Keep at least an empty string.
        out.append({"role": role, "content": content_text or ""})

    return out


def _flatten_anthropic_text(
    content: str | list[dict[str, Any]] | None,
) -> str:
    """Flatten Anthropic ``content`` (str or block list) into plain text.

    Returns ``""`` when ``content`` is ``None``. Non-text blocks are
    skipped — see :func:`_anthropic_to_openai_messages` for rationale.
    """
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if not isinstance(content, list):
        # Defensive: Anthropic spec only allows str | list. Stringify
        # anything else so we don't crash the whole request.
        return str(content)
    parts: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "text":
            text = block.get("text")
            if isinstance(text, str):
                parts.append(text)
    return "".join(parts)


# OpenAI ``finish_reason`` → Anthropic ``stop_reason`` mapping. The
# Anthropic spec lists end_turn / max_tokens / stop_sequence /
# tool_use; ``error`` is our own sentinel for provider-side failure.
_OPENAI_STOP_TO_ANTHROPIC: dict[str, str] = {
    "stop": "end_turn",
    "length": "max_tokens",
    "tool_calls": "tool_use",
    "content_filter": "end_turn",
}


def _approx_token_count(text: str) -> int:
    """Approximate token count: ceil(len/4) with floor 1 for non-empty text.

    Local Ollama / llama.cpp backends do not expose usage stats through the
    OpenAI ``/v1/chat/completions`` surface, so /v1/messages estimates from
    string length. The previous ``len(text) // 4`` estimate returned 0 for
    any text < 4 chars (e.g. "收到" = 2 chars → 0). OpenAI compat clients
    (鬼谷 mod, OpenClaw, langchain_openai, etc.) reject responses with
    ``usage.completion_tokens == 0`` while content is non-empty as a sanity
    check, surfacing as "AI 測試失敗" on the mod side. Switch to ceil + min-1.
    """
    if not text:
        return 0
    return max(1, (len(text) + 3) // 4)


def _openai_to_anthropic_response(
    text: str,
    model: str,
    *,
    stop_reason: str = "stop",
    input_tokens: int = 0,
    output_tokens: int = 0,
) -> dict[str, Any]:
    """Wrap a plain text completion in the Anthropic Messages response shape.

    The local Ollama / llama.cpp backends do not expose usage stats
    through the ``/v1/chat/completions`` surface (see provider
    docstring), so callers may pass ``input_tokens=0`` /
    ``output_tokens=0``. PSYCHE TS treats those as "unknown" already.

    Pure function: deterministic IDs are generated by the caller, not
    here, so the unit test can pin them.
    """
    return {
        "id": f"msg_{uuid.uuid4().hex[:24]}",
        "type": "message",
        "role": "assistant",
        "content": [{"type": "text", "text": text}],
        "model": model,
        "stop_reason": _OPENAI_STOP_TO_ANTHROPIC.get(
            stop_reason,
            "end_turn",
        ),
        "stop_sequence": None,
        "usage": {
            "input_tokens": int(input_tokens),
            "output_tokens": int(output_tokens),
        },
    }


def _resolve_model_route(
    model: str,
) -> tuple[str, str | None, str]:
    """Look up the routing rule for a requested model name.

    Returns ``(provider, base_url, backend_model)``. Raises
    :class:`KeyError` for unknown models so the endpoint can return a
    clean 404, and :class:`PermissionError` for ``claude-*`` so the
    endpoint can return a 400 with the "use Anthropic directly"
    message. Splitting the two error types keeps the HTTP layer thin
    (one ``except KeyError`` / ``except PermissionError``).
    """
    if not isinstance(model, str) or not model:
        raise KeyError("model field is required and must be a string")
    if model.startswith("claude-"):
        raise PermissionError(
            "Sancio gateway does not proxy claude-* models. Call "
            "https://api.anthropic.com/v1/messages directly with your "
            "Anthropic API key.",
        )
    try:
        return _MESSAGES_MODEL_ROUTES[model]
    except KeyError as exc:
        known = sorted(_MESSAGES_MODEL_ROUTES.keys())
        raise KeyError(
            f"unknown model {model!r}; known: {known}",
        ) from exc


def _resolve_num_ctx(
    body: dict[str, Any],
    headers: Any,
) -> int:
    """Pick the num_ctx for one /v1/messages call.

    Precedence (first wins): request body field ``num_ctx`` →
    ``X-Num-Ctx`` request header → ``GEMMA_NUM_CTX`` env var →
    :data:`_DEFAULT_NUM_CTX`. Anything that does not parse as a
    positive int is silently skipped so we fall through to the next
    source rather than 400-ing the whole call.
    """
    candidates: list[Any] = [
        body.get("num_ctx"),
        headers.get("x-num-ctx") if hasattr(headers, "get") else None,
        os.environ.get("GEMMA_NUM_CTX"),
    ]
    for raw in candidates:
        if raw is None:
            continue
        try:
            value = int(raw)
        except (TypeError, ValueError):
            continue
        if value > 0:
            return value
    return _DEFAULT_NUM_CTX


def _check_messages_auth(headers: Any) -> JSONResponse | None:
    """Verify the gateway auth header.

    Accepts EITHER of two header shapes — both carry the same secret,
    only the wire convention differs:

    * ``Authorization: Bearer <key>`` — Anthropic-native convention.
    * ``X-Sancio-Key: <key>`` — PSYCHE TS legacy convention.
      ``src/anthropic.ts`` ships ``authHeader: 'X-Sancio-Key'`` because
      that file is on a frozen Anthropic Messages wire and the team
      did not want to touch it for this gateway. Sancio is the new
      layer; it adapts.

    Returns ``None`` when the call may proceed, or a
    :class:`JSONResponse` with status 401 when neither header carries
    the right secret.

    When ``SANCIO_API_KEY`` is unset we log a warning and let the call
    through — keeps the dev workflow frictionless. In production the
    operator MUST set the env var for the gateway to be private.

    We use :func:`hmac.compare_digest` to dodge timing attacks even on
    a tiny token comparison; the cost is negligible and the habit
    matters when this code gets copy-pasted into the next gateway.
    """
    expected = os.environ.get("SANCIO_API_KEY", "").strip()
    if not expected:
        _log.warning(
            "SANCIO_API_KEY is unset; /v1/messages is open to anyone "
            "who can reach the port. Set it before exposing the "
            "service publicly.",
        )
        return None

    presented: str | None = None
    if hasattr(headers, "get"):
        # Try Authorization: Bearer <key> first (Anthropic convention).
        auth = headers.get("authorization", "") or ""
        if auth.lower().startswith("bearer "):
            presented = auth[7:].strip()
        else:
            # Fallback: X-Sancio-Key: <key> (PSYCHE TS legacy).
            x_key = headers.get("x-sancio-key", "") or ""
            if x_key.strip():
                presented = x_key.strip()

    if presented is None:
        return JSONResponse(
            {
                "type": "error",
                "error": {
                    "type": "authentication_error",
                    "message": (
                        "missing auth header; expected 'Authorization: "
                        "Bearer <key>' or 'X-Sancio-Key: <key>'"
                    ),
                },
            },
            status_code=401,
        )
    if not hmac.compare_digest(presented, expected):
        return JSONResponse(
            {
                "type": "error",
                "error": {
                    "type": "authentication_error",
                    "message": "invalid auth token",
                },
            },
            status_code=401,
        )
    return None


def _messages_error(
    err_type: str,
    message: str,
    status_code: int,
) -> JSONResponse:
    """Build the Anthropic-shaped error envelope.

    Anthropic returns ``{"type": "error", "error": {"type": ..., "message": ...}}``
    on every failure regardless of HTTP status. Centralising the
    shape here keeps the gateway's error paths consistent with what
    PSYCHE TS expects and shrinks each branch to a single line.
    """
    return JSONResponse(
        {
            "type": "error",
            "error": {
                "type": err_type,
                "message": message,
            },
        },
        status_code=status_code,
    )


def _apply_constraint_extras(
    body: dict[str, Any], policy_extra: dict[str, Any],
) -> None:
    """Extract sampling-time constraint fields from body into policy_extra.

    Phase E (2026-04-30) — ``grammar`` (GBNF source string) and
    ``response_format`` (OpenAI structured-output dict) lift into
    policy.extra so :class:`OpenAICompatProvider` forwards them to the
    llama.cpp wrap layer. Unset / wrong-type values are silently skipped
    (no-op rather than 400) — caller can always omit constraint.
    """
    grammar = body.get("grammar")
    if isinstance(grammar, str) and grammar.strip():
        policy_extra["grammar"] = grammar
    response_format = body.get("response_format")
    if isinstance(response_format, dict):
        policy_extra["response_format"] = response_format


def _parse_messages_body(
    body: object,
) -> (
    tuple[
        str,
        list[dict[str, Any]],
        int,
        float,
        str | int | None,
    ]
    | JSONResponse
):
    """Validate the Anthropic request body and pull every typed field.

    Returns ``(requested_model, raw_messages, max_tokens, temperature,
    seed)`` on success, or an Anthropic-shaped error
    :class:`JSONResponse` on any validation failure. Splitting parse
    out of the route handler keeps the handler's branching narrow
    enough to fit under the function-length budget.

    ``seed`` is left as ``None`` when absent so the caller can decide
    whether to forward it into ``ModelPolicy.extra`` — the provider
    layer ignores ``seed=None`` already.
    """
    if not isinstance(body, dict):
        return _messages_error(
            "invalid_request_error",
            "request body must be a JSON object",
            400,
        )

    raw_messages = body.get("messages")
    if not isinstance(raw_messages, list) or not raw_messages:
        return _messages_error(
            "invalid_request_error",
            "`messages` is required and must be a non-empty array",
            400,
        )

    requested_model = body.get("model", "")
    if not isinstance(requested_model, str) or not requested_model:
        return _messages_error(
            "invalid_request_error",
            "`model` is required and must be a non-empty string",
            400,
        )

    try:
        max_tokens = int(body.get("max_tokens", 1024))
    except (TypeError, ValueError):
        return _messages_error(
            "invalid_request_error",
            "`max_tokens` must be an integer",
            400,
        )
    try:
        temperature = float(body.get("temperature", 0.7))
    except (TypeError, ValueError):
        return _messages_error(
            "invalid_request_error",
            "`temperature` must be a number",
            400,
        )

    return requested_model, raw_messages, max_tokens, temperature, body.get("seed")


async def _messages_anthropic_compat(request: Request) -> JSONResponse:
    """POST /v1/messages — Anthropic Messages API thin gateway.

    Accepts the Anthropic wire shape, transforms to OpenAI
    ChatCompletion, dispatches to the local Gemma4 fleet (Ollama 8400
    / llama.cpp 8401), and returns the Anthropic response shape.

    Why this lives outside ``/v1/chat``: PSYCHE TS is frozen on the
    Anthropic Messages wire and we MUST NOT rewrite it. This endpoint
    is a strict shape adapter — no persona engine, no ZIQ routing,
    no RAG injection, no FTRL feedback. If you need any of that, hit
    ``/v1/chat`` instead.
    """
    # Step 1: auth gate runs before body parse so an attacker spamming
    # huge bodies pays the parse cost only once we've validated them.
    auth_resp = _check_messages_auth(request.headers)
    if auth_resp is not None:
        return auth_resp

    # Step 2: parse JSON body.
    try:
        body = await request.json()
    except (ValueError, TypeError) as exc:
        return _messages_error(
            "invalid_request_error",
            f"request body must be valid JSON: {exc}",
            400,
        )

    # Step 3: shape-validate via dedicated parser; bail early on error.
    parsed = _parse_messages_body(body)
    if isinstance(parsed, JSONResponse):
        return parsed
    requested_model, raw_messages, max_tokens, temperature, seed = parsed

    # Step 4: model routing. Splits 404 (unknown) vs 400 (claude-*).
    try:
        provider_name, base_url, backend_model = _resolve_model_route(
            requested_model,
        )
    except PermissionError as exc:
        return _messages_error("invalid_request_error", str(exc), 400)
    except KeyError as exc:
        return _messages_error(
            "not_found_error",
            str(exc).strip("'"),
            404,
        )

    # Step 5: shape transform (Anthropic → OpenAI).
    try:
        openai_messages = _anthropic_to_openai_messages(
            body.get("system"),
            raw_messages,
        )
    except ValueError as exc:
        return _messages_error("invalid_request_error", str(exc), 400)

    # Step 5.5: context-budget guard (last-resort sliding window).
    # PSYCHE TS owns the smart hierarchical summary upstream; this is
    # the floor that protects against passthrough mode and any
    # caller that did not (or could not) compress before the wire.
    # See :mod:`persona.context_budget` for the full design rationale.
    #
    # Hard ceiling: regardless of what the caller requests via body /
    # header, the *actual* llama N_CTX on the local pod caps things.
    # If a request asks for n_ctx > _DEFAULT_NUM_CTX we still trim to
    # the hardware capability — otherwise the trimmed prompt would
    # blow the wrap server's `n_ctx_train` cap and 500.
    requested_num_ctx = _resolve_num_ctx(body, request.headers)
    resolved_num_ctx = min(requested_num_ctx, _DEFAULT_NUM_CTX)
    openai_messages, _dropped = apply_sliding_window(
        openai_messages,
        n_ctx=resolved_num_ctx,
        max_reply=max_tokens or 1024,
    )
    if not openai_messages:
        return _messages_error(
            "invalid_request_error",
            f"context_budget guard rejected: prompt exceeds n_ctx="
            f"{resolved_num_ctx} after applying max_reply={max_tokens or 1024} "
            "+ safety_margin=512. Reduce input size or raise n_ctx.",
            400,
        )

    # Step 6: build ModelPolicy. ``num_ctx`` resolution honours body /
    # header / env / default precedence (see :func:`_resolve_num_ctx`).
    policy_extra: dict[str, Any] = {
        "num_ctx": resolved_num_ctx,
    }
    if seed is not None:
        policy_extra["seed"] = seed
    _apply_constraint_extras(body, policy_extra)
    policy = ModelPolicy(
        provider=provider_name,
        model=backend_model,
        temperature=temperature,
        max_tokens=max_tokens,
        extra=policy_extra,
    )

    # Step 7: dispatch. We bypass the engine's provider router because
    # that registry caches one Ollama instance keyed by name; we need a
    # per-request base_url so the same Sancio process can talk to both
    # 8400 (official) and 8401 (NSFW). Building a fresh
    # OpenAICompatProvider here is cheap (one httpx.AsyncClient).
    vendor = "llamacpp" if base_url and ":8401" in base_url else "ollama"
    backend = OpenAICompatProvider(base_url=base_url, vendor=vendor)
    try:
        text = await backend.generate(openai_messages, policy)
    except ProviderError as exc:
        return _messages_error(
            "api_error",
            f"backend provider {exc.provider!r} failed: {exc.detail}",
            502,
        )

    # Step 8: shape transform (OpenAI → Anthropic).
    # Token estimate: ceil(len/4) with a floor of 1 whenever the side has
    # any text. OpenAI compat clients (鬼谷 mod, OpenClaw, etc.) reject
    # responses with usage.completion_tokens == 0 when content is non-empty
    # as a sanity check — the previous floor-division estimate returned 0
    # for any reply shorter than 4 chars (e.g. "收到" = 2 chars), causing
    # mod-side "AI 測試失敗" even though content was correct.
    return JSONResponse(
        _openai_to_anthropic_response(
            text=text,
            model=requested_model,
            stop_reason=(
                "length" if max_tokens and len(text) >= max_tokens else "stop"
            ),
            input_tokens=sum(
                _approx_token_count(m.get("content", "")) for m in openai_messages
            ),
            output_tokens=_approx_token_count(text),
        )
    )


# ── Streaming chat endpoint ─────────────────────
#
# Mirrors ``/v1/chat`` but opens an SSE stream back to the caller so
# tokens land on the wire as the provider emits them. The non-stream
# endpoint above stays untouched — callers opt in explicitly.


def _sse_data(payload: dict) -> bytes:
    """Encode one dict as a single SSE ``data:`` frame.

    One frame = one ``data: {json}\\n\\n`` block. We keep the wire
    format in one place so the endpoint, tests, and any future
    client all agree on the bytes.
    """
    return (f"data: {json.dumps(payload, ensure_ascii=False)}\n\n").encode("utf-8")


async def _stream_chat_frames(
    persona: PersonaData | None,
    context_id: str,
    message: str,
    model_policy: ModelPolicy | None,
) -> AsyncIterator[bytes]:
    """Produce the SSE byte stream for one ``/v1/chat/stream`` call.

    Emits one ``{"text": chunk}`` frame per provider token, then a
    single ``{"type": "done", "total_tokens": N}`` terminator. On
    :class:`ProviderError` we flush a ``{"type": "error", ...}``
    frame and close — HTTP status stays 200 because SSE clients
    expect transport-level errors to come through the stream, not
    as 5xx responses.

    When ``persona`` is ``None`` (cyber/coding tracks) we wrap the
    plain message in a minimal system prompt and dispatch through
    ``_llm_via_provider_stream`` directly. When a persona exists we
    delegate to :meth:`PersonaEngine.chat_stream` so dynamic persona
    switching, ZIQ routing, RAG retrieval and FTRL feedback all run
    the same way as the non-streaming endpoint.
    """
    total_len = 0
    try:
        if persona is not None:
            stream = _engine.chat_stream(
                context_id=context_id,
                persona=persona,
                user_message=message,
                model_policy=model_policy,
            )
        else:
            # Minimal fallback for non-persona tracks: synthetic
            # system prompt + user turn, straight to provider stream.
            policy = model_policy or ModelPolicy(
                provider="ollama",
                model=os.environ.get("GEMMA_MODEL", "gemma-4-27b"),
            )
            sys_prompt = "You are a helpful assistant."
            msgs = [
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": message},
            ]
            stream = _engine._llm_via_provider_stream(
                policy,
                msgs,
                session_id=context_id,
            )

        async for chunk in stream:
            if not chunk:
                continue
            total_len += len(chunk)
            yield _sse_data({"text": chunk})

        yield _sse_data({"type": "done", "total_tokens": total_len})
    except ProviderError as exc:
        yield _sse_data(
            {
                "type": "error",
                "provider": exc.provider,
                "detail": exc.detail,
            }
        )
    except Exception as exc:  # noqa: BLE001 — never leak tracebacks
        yield _sse_data({"type": "error", "detail": str(exc)[:500]})


async def _chat_stream(request: Request) -> StreamingResponse | JSONResponse:
    """Unified Aegis streaming endpoint. Same shape as ``/v1/chat``.

    Opens a ``text/event-stream`` on success. Body shape mirrors
    ``/v1/chat`` one-for-one so an existing client only has to
    swap the endpoint path and consume SSE frames instead of a
    single JSON blob.

    Returns a synchronous 400 ``JSONResponse`` on the early
    validation errors (missing message, malformed ``model_policy``)
    because the stream has not yet started and returning a real
    HTTP error is still possible. Once the generator runs, every
    failure becomes an SSE ``error`` frame.
    """
    body = await request.json()
    message = body.get("message", "")
    if not message:
        return JSONResponse(
            {"error": "message is required"},
            status_code=400,
        )

    context_id = body.get("context_id", "default")
    persona_id = body.get("persona_id", "default")

    try:
        model_policy = _parse_model_policy(body.get("model_policy"))
    except ValueError as exc:
        return JSONResponse(
            {"error": f"invalid model_policy: {exc}"},
            status_code=400,
        )

    # Track detection (same as _chat). Benchmark modes stay on
    # /v1/chat until someone wires a streaming-aware adapter.
    track = _detect_track(message)

    # Aegis safety guard: hard-block DANGEROUS as a single-frame
    # stream so the client still sees a well-formed SSE response.
    safety = classify_safety(message)
    if safety.level == SafetyLevel.DANGEROUS:
        blocked = (
            f"I cannot fulfill this request. It has been flagged as "
            f"{safety.threat_type} by the Aegis safety guard."
        )

        async def _blocked_stream() -> AsyncIterator[bytes]:
            yield _sse_data({"text": blocked})
            yield _sse_data(
                {
                    "type": "done",
                    "total_tokens": len(blocked),
                }
            )

        return StreamingResponse(
            _blocked_stream(),
            media_type="text/event-stream",
        )

    # Resolve persona only for the safety track, same ordering as
    # the non-stream endpoint.
    persona: PersonaData | None = None
    if track == "safety":
        persona = _profiles.get(persona_id)
        if not persona:
            inline = body.get("persona_text", "")
            if inline:
                persona = parse_persona_text(inline)
                _profiles.set(persona_id, persona)

    return StreamingResponse(
        _stream_chat_frames(
            persona=persona,
            context_id=context_id,
            message=message,
            model_policy=model_policy,
        ),
        media_type="text/event-stream",
    )


# ── Load persona ────────────────────────────────


async def _load(request: Request) -> JSONResponse:
    """Load a persona profile."""
    body = await request.json()
    pid = body.get("persona_id", "")
    if not pid:
        return JSONResponse(
            {"error": "persona_id is required"},
            status_code=400,
        )

    text = body.get("persona_text", "")
    path = body.get("persona_path", "")

    if text:
        persona = parse_persona_text(text)
    elif path:
        # P0#1 Task 6: sandbox persona_path to SANCIO_WORKSPACE_ROOT
        # so the endpoint cannot double as an exfil channel (pre-P0
        # any Cloudflare Tunnel caller could POST persona_path=
        # ``/etc/shadow`` and read the file).
        from pathlib import Path as _Path

        root_str = os.environ.get(
            "SANCIO_WORKSPACE_ROOT",
            "/opt/persona-api/runtime_workspace",
        )
        root = _Path(root_str).expanduser().resolve()
        try:
            candidate = _Path(path).expanduser()
            candidate = (
                candidate.resolve()
                if candidate.is_absolute()
                else (root / candidate).resolve()
            )
            if not candidate.is_relative_to(root):
                return JSONResponse(
                    {
                        "error": "bad path",
                        "detail": (
                            "persona_path must resolve inside SANCIO_WORKSPACE_ROOT"
                        ),
                    },
                    status_code=400,
                )
        except (OSError, ValueError) as exc:
            return JSONResponse(
                {"error": "bad path", "detail": str(exc)[:120]},
                status_code=400,
            )
        if not candidate.exists():
            return JSONResponse(
                {"error": f"file not found: {path}"},
                status_code=404,
            )
        persona = load_persona_md(str(candidate))
    else:
        return JSONResponse(
            {"error": "persona_text or persona_path required"},
            status_code=400,
        )

    _profiles.set(pid, persona)
    return JSONResponse(
        {
            "persona_id": pid,
            "name": persona.identity.name,
            "ocean": persona.ocean_labels,
        }
    )


# ── Health ──────────────────────────────────────


async def _health(_request: Request) -> JSONResponse:
    """Return Aegis health status."""
    return JSONResponse(
        {
            "status": "ok",
            "service": "sancio",
            "profiles_loaded": len(_profiles),
        }
    )


# ── /v1/persona — persona metadata + guard wiring status ────────────
#
# Wave-3 ROI #1: expose a lightweight introspection endpoint so
# external consumers (Concinno persona module HTTPBackend, PSYCHE,
# integration tests) can query:
#
#   GET /v1/persona                   → service-level wiring status
#   GET /v1/persona?persona_id=<id>   → per-profile identity snapshot
#
# The endpoint does NOT load new personas (use POST /v1/load for
# that). It reads from the _profiles LRU cache which is already
# populated by /v1/load or /v1/chat auto-load.
#
# ``guard_wiring`` reports which extra guards are active in the
# ChatGuardRouter so external callers know the current security
# posture without reading source code.


async def _persona_info(request: Request) -> JSONResponse:
    """GET /v1/persona — persona metadata and guard wiring status.

    Query parameters
    ----------------
    persona_id : str, optional
        When provided, returns the identity snapshot for that profile
        if it is loaded in the LRU cache.  Returns 404 when the
        profile is not cached (caller should POST /v1/load first).

    Response shape (service-level, no persona_id)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    .. code-block:: json

        {
            "service": "sancio",
            "profiles_loaded": 3,
            "guard_wiring": {
                "chat_guard_router": true,
                "extras": ["SecretScanGuard", "ThreatPatternsGuard"]
            }
        }

    Response shape (per-profile, with persona_id)
    ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    .. code-block:: json

        {
            "persona_id": "purple",
            "identity": {
                "name": "Aegis",
                "age": "28",
                "gender": "Non-binary",
                "nationality": "International",
                "mbti": "INTJ",
                "language": "English (native), ...",
                "appearance": "..."
            },
            "ocean": {
                "Openness": 0.7,
                "Conscientiousness": 0.85,
                "Extraversion": 0.5,
                "Agreeableness": 0.6,
                "Neuroticism": 0.2
            },
            "locked_values_count": 2,
            "guard_wiring": {
                "chat_guard_router": true,
                "extras": ["SecretScanGuard", "ThreatPatternsGuard"]
            }
        }
    """
    from .concinno_wire import get_chat_guard_router

    router = get_chat_guard_router()
    guard_wiring = {
        "chat_guard_router": True,
        "extras": [type(g).__name__ for g in router._extras],
    }

    persona_id: str = request.query_params.get("persona_id", "")
    if not persona_id:
        return JSONResponse(
            {
                "service": "sancio",
                "profiles_loaded": len(_profiles),
                "guard_wiring": guard_wiring,
            }
        )

    profile = _profiles.get(persona_id)
    if profile is None:
        return JSONResponse(
            {
                "error": "persona_not_loaded",
                "detail": (
                    f"Profile '{persona_id}' is not in the cache. POST /v1/load first."
                ),
            },
            status_code=404,
        )

    identity = profile.identity
    return JSONResponse(
        {
            "persona_id": persona_id,
            "identity": {
                "name": identity.name,
                "age": identity.age,
                "gender": identity.gender,
                "nationality": identity.nationality,
                "mbti": identity.mbti,
                "language": identity.language,
                "appearance": identity.appearance,
            },
            "ocean": profile.ocean_labels,
            "locked_values_count": len(profile.locked_values),
            "guard_wiring": guard_wiring,
        }
    )


# ── Cerno cycle endpoint (Phase 1 P1.2 — LIVE) ─
#
# Stateful per-child registry: consecutive_denies, equilibrium pressure
# and recent_scores live on the Cerno instance, so a fresh instance
# per request would erase the ceiling-breaker #4 semantics. We key by
# ``child_id`` and lazy-construct the first time we see a new child.
#
# Lifecycle (session 2026-04-15 P3.1):
#   * OrderedDict + LRU: every read AND write calls ``move_to_end`` so
#     a hot child_id survives a flood of cold newcomers.
#   * Soft cap ``_CERNO_REGISTRY_CAP`` (env ``AEGIS_CERNO_CAP``,
#     default 256): over-cap triggers ``popitem(last=False)`` to evict
#     the least-recently-used entry.
#   * Explicit DELETE /v1/cerno/cycle/{child_id} for deterministic
#     teardown — we do NOT add a background prune task yet; TTL +
#     persistence are next session's scope.

_CERNO_REGISTRY_CAP = int(
    os.environ.get("SANCIO_CERNO_CAP")
    or os.environ.get("SANCIO_CERNO_CAP")
    or os.environ.get("AEGIS_CERNO_CAP", "256"),
)
_CERNO_TTL_SECONDS = float(
    os.environ.get("SANCIO_CERNO_TTL_S") or os.environ.get("AEGIS_CERNO_TTL_S", "3600"),
)
_CERNO_PRUNE_INTERVAL_S = float(
    os.environ.get("SANCIO_CERNO_PRUNE_INTERVAL_S")
    or os.environ.get("AEGIS_CERNO_PRUNE_INTERVAL_S", "60"),
)
_CERNO_PERSIST_PATH = (
    os.environ.get("SANCIO_CERNO_PERSIST_PATH")
    or os.environ.get("AEGIS_CERNO_PERSIST_PATH")
    or None
)


def _build_registry() -> CernoRegistry:
    """Factory — honours the current module-level tunables.

    Tests monkeypatch ``_CERNO_REGISTRY_CAP`` at runtime, so the
    registry must pick up the latest value every time the fixture
    resets. Reading the attributes here (rather than at import
    time) keeps the old monkeypatch contract intact.
    """
    return CernoRegistry(
        max_size=_CERNO_REGISTRY_CAP,
        ttl_seconds=_CERNO_TTL_SECONDS,
        persist_path=_CERNO_PERSIST_PATH,
        prune_interval_s=_CERNO_PRUNE_INTERVAL_S,
    )


_REGISTRY: CernoRegistry = _build_registry()


def _sync_registry_cap() -> None:
    """Re-read ``_CERNO_REGISTRY_CAP`` onto the live registry.

    The existing lifecycle tests monkeypatch the module-level cap
    after the registry has already been constructed. We honour that
    contract by pushing the latest value onto ``_REGISTRY._max_size``
    before every get_or_create call.
    """
    _REGISTRY._max_size = max(1, int(_CERNO_REGISTRY_CAP))  # noqa: SLF001


def _get_or_create_cerno(
    child_id: str,
    config_override: dict | None = None,
    *,
    tenant: str = "default",
) -> Cerno:
    """Return the Cerno instance for ``child_id``, creating it once.

    Delegates to the module-level :class:`CernoRegistry`. A
    ``config_override`` dict is merged on top of
    :data:`DEFAULT_CERNO_CONFIG` only at construction time — the
    registry silently drops unknown keys so arbitrary client JSON
    is safe to forward. Subsequent calls with a different
    ``config_override`` are ignored on an existing instance.
    """
    _sync_registry_cap()
    return _REGISTRY.get_or_create(
        child_id,
        tenant=tenant,
        config_overrides=config_override,
    )


def _set_cernos_for_tests(
    registry: dict[str, Cerno] | OrderedDict[str, Cerno] | None,
) -> None:
    """Test hook: reset the module-level registry state.

    The legacy shape accepted an ``OrderedDict`` of pre-built
    :class:`Cerno` instances and swapped it in wholesale. The
    new :class:`CernoRegistry` owns richer state (TTL clocks,
    stats counters, background task, persistence path), so we
    accept the same inputs but translate them into operations on
    a fresh registry:

    * ``None`` — replace with an empty registry.
    * ``dict``/``OrderedDict[str, Cerno]`` — wipe the registry,
      then insert every entry under the ``default`` tenant with a
      synthetic ``last_used_at`` of now. Insertion order is
      preserved so LRU semantics match the old contract.
    """
    global _REGISTRY
    _REGISTRY = _build_registry()
    if registry:
        store = _REGISTRY._store_for("default")  # noqa: SLF001
        for child_id, arb in registry.items():
            # Bypass ``get_or_create`` so we keep the caller's
            # pre-built Cerno instance unchanged (tests rely on
            # identity equality).
            from .cerno_registry import _Entry  # local import avoids cycle

            store[child_id] = _Entry(cerno=arb)


def _reset_registry_for_tests() -> None:
    """Clean-slate helper — equivalent to ``_set_cernos_for_tests(None)``.

    Tests that don't need the legacy dict shape can call this
    directly for clarity.
    """
    _set_cernos_for_tests(None)


def _format_pydantic_detail(first_err: dict) -> str:
    """Turn the first pydantic error dict into a wire-safe ``detail``.

    The pre-pydantic handler returned hand-written strings like
    ``"`intent` is required and must be a non-empty string"``. We
    try to reproduce that shape for the common cases (missing field,
    string too short, wrong type) while falling back to pydantic's
    own message for anything unexpected.
    """
    loc = first_err.get("loc") or ()
    field = loc[0] if loc else "<body>"
    kind = first_err.get("type", "")
    if kind == "missing":
        return f"`{field}` is required"
    if kind == "string_too_short":
        return f"`{field}` must be a non-empty string"
    if kind.endswith("_type"):
        return f"`{field}` has the wrong type"
    if kind == "extra_forbidden":
        return f"unknown field `{field}`"
    return first_err.get("msg", str(first_err))


def _cerno_cycle_400_from_pydantic(exc: ValidationError) -> str:
    """Map a pydantic ``ValidationError`` to one of the 400 codes.

    The legacy wire contract exposes exactly three strings:

    * ``missing_field`` — a required field was absent or empty.
      Covers pydantic ``missing`` + ``string_too_short`` (our
      ``min_length=1`` rules on ``intent`` / ``child_id``).
    * ``invalid_field`` — a field was present but the wrong type,
      or an unknown field was sent with ``extra="forbid"``.
    * ``invalid_body`` — the outer body was not JSON or not a dict.
      This code is NEVER produced by pydantic; the caller handles
      that branch before ``model_validate`` runs.

    We key off the **first** error only because the legacy endpoint
    also short-circuited on the first failing ``isinstance`` check.
    Keeping a single error per 400 response preserves the existing
    assertion surface in ``test_api_cerno_endpoint.py``.
    """
    first = exc.errors()[0]
    kind = first.get("type", "")
    if kind in {"missing", "string_too_short"}:
        return "missing_field"
    return "invalid_field"


def _defect_hit_to_out(hit: object) -> DefectHitOut:
    """Dataclass ``DefectHit`` → pydantic ``DefectHitOut``.

    We accept ``object`` rather than ``DefectHit`` so this helper
    can also swallow an already-serialized dict (as produced by
    ``dataclasses.asdict``) without importing the type here — the
    wire shape is the source of truth, not the import graph.
    """
    if dataclasses.is_dataclass(hit):
        data = dataclasses.asdict(hit)
    elif isinstance(hit, dict):
        data = hit
    else:
        data = dict(hit.__dict__)  # type: ignore[attr-defined]
    return DefectHitOut.model_validate(data)


def _build_cerno_cycle_response(
    arb: Cerno,
    action: object,
) -> CernoCycleResponse:
    """Assemble a typed :class:`CernoCycleResponse` from live state.

    Keeps all dataclass → pydantic marshalling in one place so the
    endpoint handler stays focused on request handling, and so the
    test suite can exercise the builder in isolation via fake
    Cerno fixtures.
    """
    state = arb.state

    # Action → ActionOut. ``action`` is one of four dataclasses; we
    # dump to dict and let pydantic validate the discriminator.
    action_dict = dataclasses.asdict(action)  # type: ignore[arg-type]
    # HandoffRecord on a Transfer action must nest, not stringify.
    handoff_obj = action_dict.pop("handoff", None)
    action_out = ActionOut.model_validate({**action_dict, "handoff": handoff_obj})

    # Review → ReviewOut. DefectHit list round-trips through the
    # helper so both dataclass and dict inputs are handled.
    review_out: ReviewOut | None = None
    if state.review is not None:
        review_out = ReviewOut(
            defects_found=[_defect_hit_to_out(d) for d in state.review.defects_found],
            quality_score=state.review.quality_score,
            aligned_with_assessment=state.review.aligned_with_assessment,
            sycophancy_risk=state.review.sycophancy_risk,
            reviewed_at=state.review.reviewed_at,
        )

    assessment_out: AssessmentOut | None = None
    if state.assessment is not None:
        assessment_out = AssessmentOut.model_validate(
            dataclasses.asdict(state.assessment),
        )

    equilibrium_out = EquilibriumStateOut.model_validate(
        dataclasses.asdict(state.equilibrium),
    )
    state_out = StateOut(
        child_id=state.child_id,
        consecutive_denies=state.consecutive_denies,
        current_identity=state.current_identity,
        equilibrium=equilibrium_out,
        recent_scores=list(state.recent_scores),
    )

    return CernoCycleResponse(
        action=action_out,
        review=review_out,
        assessment=assessment_out,
        state=state_out,
    )


async def _cerno_cycle(request: Request) -> JSONResponse:
    """Cerno 7-step meta-supervisor cycle — LIVE (Phase 1 P1.2).

    Runs one Cerno cycle over ``(intent, child_output)`` and returns
    the resulting :class:`CernoAction` together with the review /
    assessment / state snapshot. Preserves per-``child_id`` state
    across calls via the module-level :data:`_cernos` registry.

    Request body::

        {
          "intent": "the original user request the child was trying to serve",
          "child_output": "what the child produced (possibly empty on pre-check)",
          "child_id": "stable id for this child agent (used as state key)",
          "config": { ... optional CernoConfig field overrides ... }
        }

    Response (200)::

        {
          "action": {"type": "allow" | "deny" | "transfer" | "recalibrate", ...},
          "review": {"quality_score": int, "defects_found": [...], ...},
          "state": {
            "child_id": str,
            "consecutive_denies": int,
            "current_identity": str,
            "equilibrium": {"pressure": float, ...},
            "recent_scores": [int, ...]
          }
        }

    Error shapes:
      * 400 — body is not a JSON object, missing ``intent``/``child_id``
      * 500 — :meth:`Cerno.cycle` raised an unexpected exception

    The previous implementation returned 501 while the port was
    pending; that contract is now replaced. Tests at
    ``tests/test_api_cerno_endpoint.py`` cover the new happy-path
    + error shapes.
    """
    # Step 1: Raw body → JSON. Parse failures stay on the
    # ``invalid_body`` error code (pydantic never sees the bytes).
    try:
        raw = await request.body()
    except Exception:  # noqa: BLE001 — transport-level failure
        return JSONResponse(
            {"error": "invalid_body", "detail": "failed to read request body"},
            status_code=400,
        )
    if not raw:
        return JSONResponse(
            {"error": "invalid_body", "detail": "request body is empty"},
            status_code=400,
        )
    try:
        body = json.loads(raw)
    except (ValueError, TypeError):
        return JSONResponse(
            {"error": "invalid_body", "detail": "request body must be valid JSON"},
            status_code=400,
        )
    if not isinstance(body, dict):
        return JSONResponse(
            {"error": "invalid_body", "detail": "request body must be a JSON object"},
            status_code=400,
        )

    # Step 2: Pydantic contract validation. On failure we translate
    # the first ValidationError back into the existing 400 error-code
    # set (``missing_field`` / ``invalid_field``) so live clients see
    # the identical wire shape they have always seen.
    try:
        req_model = CernoCycleRequest.model_validate(body)
    except ValidationError as exc:
        err_kind = _cerno_cycle_400_from_pydantic(exc)
        first_err = exc.errors()[0]
        detail = _format_pydantic_detail(first_err)
        return JSONResponse(
            {"error": err_kind, "detail": detail},
            status_code=400,
        )

    intent = req_model.intent
    child_id = req_model.child_id
    child_output = req_model.child_output
    config_override = req_model.config

    # Second-layer defense — the pydantic schema above already
    # enforces every one of these predicates, so these branches are
    # dead today. They stay in place intentionally as a safety net
    # in case the schema ever regresses: the wire contract tests
    # still cover the error codes, so any change that breaks one
    # layer would still be caught by the other.
    if not isinstance(intent, str) or not intent.strip():
        return JSONResponse(
            {
                "error": "missing_field",
                "detail": "`intent` is required and must be a non-empty string",
            },
            status_code=400,
        )
    if not isinstance(child_id, str) or not child_id.strip():
        return JSONResponse(
            {
                "error": "missing_field",
                "detail": "`child_id` is required and must be a non-empty string",
            },
            status_code=400,
        )
    if not isinstance(child_output, str):
        return JSONResponse(
            {
                "error": "invalid_field",
                "detail": "`child_output` must be a string when provided",
            },
            status_code=400,
        )
    if config_override is not None and not isinstance(config_override, dict):
        return JSONResponse(
            {
                "error": "invalid_field",
                "detail": "`config` must be a JSON object when provided",
            },
            status_code=400,
        )

    tenant_id = req_model.tenant_id if hasattr(req_model, "tenant_id") else "default"
    if not isinstance(tenant_id, str) or not tenant_id:
        tenant_id = "default"
    arb = _get_or_create_cerno(
        child_id,
        config_override,
        tenant=tenant_id,
    )
    # ``get_or_create`` already moved the key to MRU + refreshed
    # its ``last_used_at``, so no second touch is needed here. The
    # LRU-on-read guarantee now lives inside ``CernoRegistry``.

    try:
        action = arb.cycle(intent, child_output)
    except Exception as exc:  # noqa: BLE001 — surface as 500 with shape
        return JSONResponse(
            {"error": "cycle_failed", "detail": f"{type(exc).__name__}: {exc}"},
            status_code=500,
        )

    # Marshal the live Cerno state through the pydantic response
    # model. ``model_dump(mode="json")`` produces JSON-safe primitives
    # (no datetimes, no Enum instances) that JSONResponse can send
    # unchanged, and is the single place that pins the wire shape
    # for OpenAPI / client codegen consumers.
    resp_model = _build_cerno_cycle_response(arb, action)
    return JSONResponse(resp_model.model_dump(mode="json"))


async def _cerno_delete(request: Request) -> JSONResponse:
    """DELETE /v1/cerno/cycle/{child_id} — explicit lifecycle teardown.

    Removes the per-child Cerno instance from the module-level
    registry. A long-running server without DELETE would leak one
    Cerno per unique ``child_id`` forever; this handler is the
    deterministic counterpart to :func:`_get_or_create_cerno`.

    Responses
    ---------
    * **200** — child existed and was removed::

          {"deleted": true, "child_id": "<child_id>"}

    * **404** — no such child in the registry::

          {"error": "not_found", "child_id": "<child_id>"}

    The response body uses the same flat error shape as
    :func:`_cerno_cycle` so clients only need one parser.
    """
    child_id = request.path_params.get("child_id", "")
    if not child_id:
        return JSONResponse(
            {"error": "missing_field", "detail": "`child_id` path param is required"},
            status_code=400,
        )

    # Delete path currently uses the ``default`` tenant to match the
    # legacy single-tenant wire contract. A tenant-scoped DELETE is
    # intentionally NOT surfaced here yet — the handoff scope asks
    # for additive multi-tenancy on POST only. Clients that want to
    # drop a non-default tenant can call the registry directly or
    # wait for the dedicated endpoint.
    tenant_param = request.query_params.get("tenant_id", "default") or "default"
    if _REGISTRY.delete(child_id, tenant=tenant_param):
        return JSONResponse({"deleted": True, "child_id": child_id})

    return JSONResponse(
        {"error": "not_found", "child_id": child_id},
        status_code=404,
    )


async def _cerno_registry_list(_request: Request) -> JSONResponse:
    """GET /v1/cerno/registry — lightweight registry snapshot.

    Returns one summary row per child in **LRU order** (least-recently-
    used first, most-recently-used last). We intentionally do NOT
    serialize the full Cerno state: ``recent_scores`` can hold up
    to ``CernoConfig.max_recent_scores`` ints and assessment / review
    hold nested dataclasses that are expensive to dump on every poll.
    Callers that need the full state should hit /v1/cerno/cycle
    instead.

    Shape::

        {
          "count": N,
          "cap": <_CERNO_REGISTRY_CAP>,
          "children": [
            {
              "child_id": str,
              "consecutive_denies": int,
              "recent_score_count": int,
              "current_identity": str
            },
            ...
          ]
        }
    """
    children: list[dict[str, object]] = []
    # Walk tenants in insertion order and flatten. Same tenant = LRU
    # order preserved via the per-tenant OrderedDict. The legacy
    # single-tenant contract is unchanged because the default
    # tenant is always present first when clients omit the field.
    for _tenant, child_id, arb in _REGISTRY.iter_entries():
        children.append(
            {
                "child_id": child_id,
                "consecutive_denies": arb.state.consecutive_denies,
                "recent_score_count": len(arb.state.recent_scores),
                "current_identity": arb.state.current_identity,
            }
        )

    return JSONResponse(
        {
            "count": _REGISTRY.size(),
            "cap": _CERNO_REGISTRY_CAP,
            "children": children,
        }
    )


# ── A11 Subagent spawn endpoints ────────────────
#
# These endpoints are the Aegis side of ceiling-breaker #4: Claude
# Code's SubagentStart hook only surfaces an ``agent_type`` keyword,
# so a parent agent cannot audit, intervene, or replay a child's
# prompt. Aegis *is* the spawner, so we capture the whole request
# synchronously before the provider round-trip begins.


async def _subagent_spawn(request: Request) -> JSONResponse:
    """POST /v1/subagent/spawn — synchronous spawn with capture.

    P0#1 Task 3: budget gate runs before the provider round-trip so
    a blown daily cap rejects with 429 instead of spending more.
    """
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001 — malformed body
        return JSONResponse(
            {"error": "request body must be valid JSON"},
            status_code=400,
        )

    try:
        req = _build_spawn_request(body)
    except ValueError as exc:
        return JSONResponse(
            {"error": f"invalid request: {exc}"},
            status_code=400,
        )

    # Budget pre-check (P0#1 Task 3). Prefer the JWT ``sub`` claim
    # over tenant_id for budget keying so the same JWT hits the
    # same bucket regardless of the tenant_id body field.
    from .auth import verify_token
    from .budget import BudgetExceeded, get_budget_gate

    user_id = req.tenant_id
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        token = auth[7:].strip()
        claims = verify_token(token)
        if claims:
            user_id = str(claims.get("sub") or req.tenant_id)

    estimated = int(getattr(req.policy, "max_tokens", 4096) or 4096)
    try:
        get_budget_gate().check(user_id=user_id, estimated_tokens=estimated)
    except BudgetExceeded as exc:
        return JSONResponse(
            {
                "error": "budget_exceeded",
                "detail": str(exc),
                "window": exc.window,
                "spent_usd": round(exc.spent_usd, 4),
                "cap_usd": round(exc.cap_usd, 4),
                "retry_after": exc.retry_after,
            },
            status_code=exc.code,
            headers={"Retry-After": str(exc.retry_after)},
        )

    spawner = _get_spawner()
    record = await spawner.spawn(req)

    # Record actual spend. ``tokens_estimated`` from the spawner is a
    # rough proxy; real usage stats will flow when providers thread
    # them through ``ProviderResponse``.
    try:
        get_budget_gate().record(
            user_id=user_id,
            actual_tokens=int(record.tokens_estimated or 0),
        )
    except Exception:  # noqa: BLE001 — never break the response
        pass

    return JSONResponse(
        {
            "spawn_id": record.spawn_id,
            "status": "error" if record.error else "ok",
            "response": record.response,
            "error": record.error,
            "started_at": record.started_at,
            "completed_at": record.completed_at,
            "tokens_estimated": record.tokens_estimated,
            "tenant_id": record.request.tenant_id,
            "subagent_role": record.request.subagent_role,
        }
    )


async def _subagent_get(request: Request) -> JSONResponse:
    """GET /v1/subagent/{spawn_id} — cross-session replay lookup."""
    spawn_id = request.path_params.get("spawn_id", "")
    if not spawn_id:
        return JSONResponse(
            {"error": "spawn_id path param required"},
            status_code=400,
        )

    spawner = _get_spawner()
    record = spawner.get_record(spawn_id)
    if record is None:
        return JSONResponse(
            {"error": f"spawn_id not found: {spawn_id}"},
            status_code=404,
        )

    # Pydantic-free dataclass → dict. Nested dataclasses unwind.
    from dataclasses import asdict

    return JSONResponse(asdict(record))


async def _subagent_list(request: Request) -> JSONResponse:
    """GET /v1/subagent — list recent records for one tenant."""
    tenant_id = request.query_params.get("tenant_id", "default") or "default"
    try:
        limit = int(request.query_params.get("limit", "50"))
    except ValueError:
        return JSONResponse(
            {"error": "limit must be an integer"},
            status_code=400,
        )
    limit = max(1, min(limit, 500))

    spawner = _get_spawner()
    records = spawner.list_records(tenant_id=tenant_id, limit=limit)

    from dataclasses import asdict

    return JSONResponse(
        {
            "tenant_id": tenant_id,
            "count": len(records),
            "records": [asdict(r) for r in records],
        }
    )


async def _subagent_spawn_stream(websocket: WebSocket) -> None:
    """WS /v1/subagent/spawn/stream — streaming spawn events.

    Current implementation chunks the final string into ``token``
    frames; the API shape (``start``/``token``/``end``/``error``)
    is forward-compatible with a real SSE provider once A5 gains
    one.
    """
    await websocket.accept()
    try:
        try:
            body = await websocket.receive_json()
        except Exception:  # noqa: BLE001
            await websocket.send_json(
                {
                    "type": "error",
                    "detail": "request body must be valid JSON",
                }
            )
            return

        try:
            req = _build_spawn_request(body)
        except ValueError as exc:
            await websocket.send_json(
                {
                    "type": "error",
                    "detail": f"invalid request: {exc}",
                }
            )
            return

        spawner = _get_spawner()
        async for event in spawner.spawn_stream(req):
            await websocket.send_json(event)
    finally:
        # Closing an already-closed socket is a no-op on Starlette.
        try:
            await websocket.close()
        except Exception:  # noqa: BLE001 — socket may already be gone
            pass


# ── App factory ─────────────────────────────────


def create_sancio_routes() -> list[Route | WebSocketRoute]:
    """Return unified Sancio routes.

    Both HTTP and WebSocket routes are returned in one list because
    Starlette accepts a mixed sequence on ``Starlette(routes=...)``.
    """
    # Lazy import avoids a circular reference — ``agent_api`` imports
    # ``api`` back to look up the per-child Cerno registry when
    # building the ``aegis`` stack's post-hook chain.
    from .a2a import create_a2a_routes
    from .agent_api import (
        _provider_backed_llm_call,
        create_agent_run_routes,
        set_llm_call,
    )
    from .auth import create_auth_routes
    from .gdpr import create_gdpr_routes

    # Wire the production LLM adapter on first route build so
    # ``/v1/agent/run`` dispatches through the real provider registry
    # instead of the module-level echo stub. Tests override this via
    # ``set_llm_call`` in their fixtures — this line only runs once
    # per app factory call and never again.
    set_llm_call(_provider_backed_llm_call(_engine))

    return [
        *create_agent_run_routes(),
        Route("/v1/chat", _chat, methods=["POST"]),
        Route(
            "/v1/chat/stream",
            _chat_stream,
            methods=["POST"],
        ),
        Route(
            "/v1/messages",
            _messages_anthropic_compat,
            methods=["POST"],
        ),
        Route("/v1/load", _load, methods=["POST"]),
        Route("/v1/persona", _persona_info, methods=["GET"]),
        Route("/v1/health", _health, methods=["GET"]),
        Route("/v1/cerno/cycle", _cerno_cycle, methods=["POST"]),
        Route(
            "/v1/cerno/cycle/{child_id}",
            _cerno_delete,
            methods=["DELETE"],
        ),
        Route(
            "/v1/cerno/registry",
            _cerno_registry_list,
            methods=["GET"],
        ),
        Route(
            "/v1/subagent/spawn",
            _subagent_spawn,
            methods=["POST"],
        ),
        Route(
            "/v1/subagent",
            _subagent_list,
            methods=["GET"],
        ),
        Route(
            "/v1/subagent/{spawn_id}",
            _subagent_get,
            methods=["GET"],
        ),
        WebSocketRoute(
            "/v1/subagent/spawn/stream",
            _subagent_spawn_stream,
        ),
        *create_a2a_routes(),
        *create_auth_routes(),
        *create_gdpr_routes(),
    ]


def _resolve_config_watch_paths() -> list[Any]:
    """Discover config files to watch for the ConfigWatcher (Sancio 2.0.0).

    Resolution order (later wins):

    1. Env var ``SANCIO_CONFIG_PATHS`` — ``os.pathsep``-separated list
       of file paths. Empty / unset = fall through to defaults.
    2. Default candidates: ``~/.sancio/policy.yaml``,
       ``~/.sancio/skills.yaml``. Only existing files are returned.

    Returning an empty list signals the caller to skip watcher startup.
    """
    from pathlib import Path

    raw = os.environ.get("SANCIO_CONFIG_PATHS", "").strip()
    if raw:
        candidates = [Path(p).expanduser() for p in raw.split(os.pathsep) if p]
    else:
        home = Path.home()
        candidates = [
            home / ".sancio" / "policy.yaml",
            home / ".sancio" / "skills.yaml",
        ]
    return [p for p in candidates if p.exists()]


def _classify_config_source(path: Any) -> str:
    """Map a watched :class:`Path` to a CC SDK ``ConfigChangeSource`` literal.

    Sancio's default layout uses file stems as the discriminator:

    * ``policy.*``   → ``policy_settings``
    * ``skills.*``   → ``skills``
    * ``settings.*`` → ``user_settings``
    * anything else  → ``project_settings``

    Plugins that need a different layout can subclass via the
    ``SANCIO_CONFIG_PATHS`` env var + their own watcher (the runtime
    helper functions are public so the lifecycle stays composable).
    """
    stem = getattr(path, "stem", str(path)).lower()
    if stem == "policy":
        return "policy_settings"
    if stem == "skills":
        return "skills"
    if stem == "settings":
        return "user_settings"
    return "project_settings"


def create_standalone_app() -> Starlette:
    """Create standalone Sancio API app.

    Mounts :class:`AuthMiddleware` (P0#1) so every protected endpoint
    (``/v1/agent/run`` etc.) denies anonymous callers by default. The
    middleware is wired here rather than per-route so the app factory
    is the single source of truth for the security perimeter.

    Also wires the Sancio SessionStart/Stop fanout (1.3.0) into the
    Starlette ``on_startup`` / ``on_shutdown`` events so registered
    subscribers (in-process + entry_points) fire once per app
    lifecycle. The fanout is fail-open — a misbehaving subscriber
    cannot prevent the runtime from coming up or going down.
    """
    from pathlib import Path

    from starlette.middleware import Middleware

    from .auth import AuthMiddleware
    from .hooks.fanout import fire_session_start, fire_session_stop
    from .middleware import GeoBlockMiddleware
    from .runtime import attach_config_watcher, detach_config_watcher

    # GeoBlockMiddleware runs FIRST (outermost) so a blocked-region
    # request never reaches auth. Order: request → GeoBlock → Auth →
    # Route.
    app_session_id = f"sancio-app-{uuid.uuid4().hex[:12]}"

    async def _on_startup() -> None:
        try:
            await fire_session_start(app_session_id, extra={"source": "starlette"})
        except Exception:  # noqa: BLE001 — fanout is fail-open
            _log.exception("SessionStart fanout raised (ignored)")

        # Sancio 2.0.0 — wire the ConfigWatcher into the app lifecycle
        # so config-file mutations fire ConfigChange events to
        # subscribers (RED Opus FATAL-1, 2026-05-01: without this the
        # 310-LoC ConfigWatcher module is dead code in production).
        # Caller-owned reload semantics: Sancio just emits the event;
        # plugins wire actual reload via the entry-point group
        # ``sancio.hooks.config_change``. The reload_callback here is
        # a no-op log so the watcher loop can still exercise its own
        # reload path even when no plugin is registered.
        try:
            paths = _resolve_config_watch_paths()
            if not paths:
                _log.info(
                    "ConfigWatcher startup: no config files to watch — skipping"
                )
            else:
                from .hooks.config_watcher import ConfigWatcher

                async def _noop_reload(path: Path) -> None:
                    _log.info(
                        "ConfigChange reload signalled for %s "
                        "(no-op default; plugins handle via entry_points)",
                        path,
                    )

                watcher = ConfigWatcher(
                    paths=paths,
                    reload_callback=_noop_reload,
                    source_resolver=_classify_config_source,
                    session_id=app_session_id,
                )
                await attach_config_watcher(watcher)
                _log.info(
                    "ConfigWatcher started for %d path(s): %s",
                    len(paths),
                    [str(p) for p in paths],
                )
        except Exception:  # noqa: BLE001 — observability feature, fail-open
            _log.exception(
                "ConfigWatcher startup raised (ignored — server boot continues)"
            )

    async def _on_shutdown() -> None:
        # Stop the watcher BEFORE firing session_stop so subscribers
        # see a quiescent watch state.
        try:
            await detach_config_watcher()
        except Exception:  # noqa: BLE001 — shutdown must always succeed
            _log.exception("ConfigWatcher shutdown raised (ignored)")

        try:
            await fire_session_stop(app_session_id, extra={"source": "starlette"})
        except Exception:  # noqa: BLE001
            _log.exception("SessionStop fanout raised (ignored)")

    return Starlette(
        routes=create_sancio_routes(),
        middleware=[
            Middleware(GeoBlockMiddleware),
            Middleware(AuthMiddleware),
        ],
        on_startup=[_on_startup],
        on_shutdown=[_on_shutdown],
    )


# Backward compat alias.
create_aegis_routes = create_sancio_routes
