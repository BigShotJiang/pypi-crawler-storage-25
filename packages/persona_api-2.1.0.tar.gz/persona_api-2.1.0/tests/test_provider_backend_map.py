"""Regression tests for Wave D Step 4a — multi-backend routing.

``OpenAICompatProvider`` resolves ``policy.model`` → upstream base URL
via either ``GEMMA_BACKEND_MAP`` env (preferred for ops) or the
``backend_map=`` constructor kwarg (preferred for tests / DI). Default
empty map preserves legacy single-backend behaviour (every model
forwards to ``_base_url``).

Covers all four resolution paths:

1. Legacy: no env, no kwarg → all models route to ``_base_url``.
2. Env-driven: `GEMMA_BACKEND_MAP` JSON parsed → per-model URL.
3. Kwarg-driven: `backend_map=` passed at construction, no env.
4. Env wins over kwarg (consistent with ``GEMMA_VENDOR`` precedent).

Plus URL resolution exercised through every method path:
``generate``, ``generate_with_tools``, ``generate_stream``.

Hits the wire via ``httpx.MockTransport`` so assertion is on the
exact target URL — same pattern as ``test_ollama_num_ctx.py``.
"""

from __future__ import annotations

import logging
from typing import Any

import httpx
import pytest

from persona.providers.base import ModelPolicy
from persona.providers.ollama import (
    OpenAICompatProvider,
    _parse_backend_map,
)


# ───────────────────────────── _parse_backend_map unit tests ──────


def test_parse_backend_map_empty():
    assert _parse_backend_map("") == {}
    assert _parse_backend_map("   ") == {}


def test_parse_backend_map_valid():
    raw = (
        '{"gemma4-nsfw":"http://localhost:8401/v1",'
        '"qwen3-3b-nsfw":"http://localhost:8402/v1"}'
    )
    out = _parse_backend_map(raw)
    assert out == {
        "gemma4-nsfw": "http://localhost:8401/v1",
        "qwen3-3b-nsfw": "http://localhost:8402/v1",
    }


def test_parse_backend_map_strips_trailing_slash():
    out = _parse_backend_map('{"a":"http://h/v1/"}')
    assert out == {"a": "http://h/v1"}


def test_parse_backend_map_bad_json_logs_warning_returns_empty(caplog):
    with caplog.at_level(logging.WARNING, logger="persona.providers.ollama"):
        assert _parse_backend_map("not json") == {}
    assert any("parse failed" in rec.message for rec in caplog.records)


def test_parse_backend_map_array_logs_warning_returns_empty(caplog):
    with caplog.at_level(logging.WARNING, logger="persona.providers.ollama"):
        assert _parse_backend_map("[1,2]") == {}
    assert any("not a dict" in rec.message for rec in caplog.records)


def test_parse_backend_map_drops_non_string(caplog):
    with caplog.at_level(logging.WARNING, logger="persona.providers.ollama"):
        out = _parse_backend_map(
            '{"a":123,"b":"http://h/v1","c":null,"d":""}'
        )
    assert out == {"b": "http://h/v1"}
    # Three skipped entries → three warnings (a/c/d).
    skipped = [r for r in caplog.records if "entry skipped" in r.message]
    assert len(skipped) == 3


# ───────────────────────────── _resolve_base_url unit tests ──────


def test_resolve_base_url_legacy_single_backend(monkeypatch):
    """No env, no kwarg → all models route to _base_url (legacy)."""
    monkeypatch.delenv("GEMMA_BACKEND_MAP", raising=False)
    p = OpenAICompatProvider(base_url="http://default/v1")
    assert p._resolve_base_url("gemma4-nsfw") == "http://default/v1"
    assert p._resolve_base_url("qwen3-3b-nsfw") == "http://default/v1"
    assert p._resolve_base_url(None) == "http://default/v1"


def test_resolve_base_url_wave_d_env(monkeypatch):
    monkeypatch.setenv(
        "GEMMA_BACKEND_MAP",
        '{"gemma4-nsfw":"http://h:8401/v1","qwen3-3b-nsfw":"http://h:8402/v1"}',
    )
    p = OpenAICompatProvider(base_url="http://default/v1")
    assert p._resolve_base_url("gemma4-nsfw") == "http://h:8401/v1"
    assert p._resolve_base_url("qwen3-3b-nsfw") == "http://h:8402/v1"
    # Unknown model falls back
    assert p._resolve_base_url("unknown-model") == "http://default/v1"


def test_resolve_base_url_kwarg_only_no_env(monkeypatch):
    """Constructor kwarg works in absence of env (DI for tests / unit)."""
    monkeypatch.delenv("GEMMA_BACKEND_MAP", raising=False)
    p = OpenAICompatProvider(
        base_url="http://default/v1",
        backend_map={"a": "http://kw-a/v1", "b": "http://kw-b/v1"},
    )
    assert p._resolve_base_url("a") == "http://kw-a/v1"
    assert p._resolve_base_url("b") == "http://kw-b/v1"
    assert p._resolve_base_url("unknown") == "http://default/v1"


def test_env_overrides_kwarg(monkeypatch):
    """Env wins over constructor kwarg.

    Consistent with the existing GEMMA_VENDOR precedent at
    ``ollama.py:144-146`` where env overrides the constructor vendor
    kwarg. Operators flip routing without code redeploy.
    """
    monkeypatch.setenv("GEMMA_BACKEND_MAP", '{"a":"http://from-env/v1"}')
    p = OpenAICompatProvider(
        base_url="http://default/v1",
        backend_map={"a": "http://from-kwarg/v1"},
    )
    assert p._resolve_base_url("a") == "http://from-env/v1"


# ───────────────────────────── wire-level routing tests ───────────


def _ok_response() -> httpx.Response:
    return httpx.Response(
        200,
        json={
            "choices": [{
                "message": {"content": "ok", "role": "assistant"},
                "finish_reason": "stop",
            }],
        },
    )


def _capture_url_client(capture: dict[str, Any]) -> httpx.AsyncClient:
    def _handler(req: httpx.Request) -> httpx.Response:
        capture["url"] = str(req.url)
        return _ok_response()
    return httpx.AsyncClient(transport=httpx.MockTransport(_handler))


@pytest.mark.asyncio
async def test_generate_routes_to_per_model_backend(monkeypatch):
    """generate() posts to the URL resolved from backend_map, not _base_url."""
    monkeypatch.delenv("GEMMA_BACKEND_MAP", raising=False)
    capture: dict[str, Any] = {}
    p = OpenAICompatProvider(
        base_url="http://default/v1",
        client=_capture_url_client(capture),
        backend_map={"qwen3-3b-nsfw": "http://qwen-host:8402/v1"},
    )
    await p.generate(
        messages=[{"role": "user", "content": "hi"}],
        policy=ModelPolicy(provider="ollama", model="qwen3-3b-nsfw"),
    )
    assert capture["url"] == "http://qwen-host:8402/v1/chat/completions"


@pytest.mark.asyncio
async def test_generate_unknown_model_falls_back(monkeypatch):
    """Unknown model routes through _base_url legacy path."""
    monkeypatch.delenv("GEMMA_BACKEND_MAP", raising=False)
    capture: dict[str, Any] = {}
    p = OpenAICompatProvider(
        base_url="http://default/v1",
        client=_capture_url_client(capture),
        backend_map={"qwen3-3b-nsfw": "http://qwen-host:8402/v1"},
    )
    await p.generate(
        messages=[{"role": "user", "content": "hi"}],
        policy=ModelPolicy(provider="ollama", model="something-unmapped"),
    )
    assert capture["url"] == "http://default/v1/chat/completions"


@pytest.mark.asyncio
async def test_generate_with_tools_routes_to_per_model_backend(monkeypatch):
    monkeypatch.delenv("GEMMA_BACKEND_MAP", raising=False)
    capture: dict[str, Any] = {}
    p = OpenAICompatProvider(
        base_url="http://default/v1",
        client=_capture_url_client(capture),
        backend_map={"gemma4-nsfw": "http://vllm-host:8401/v1"},
    )
    await p.generate_with_tools(
        messages=[{"role": "user", "content": "hi"}],
        policy=ModelPolicy(provider="ollama", model="gemma4-nsfw"),
        tools=[],
    )
    assert capture["url"] == "http://vllm-host:8401/v1/chat/completions"


@pytest.mark.asyncio
async def test_generate_stream_routes_to_per_model_backend(monkeypatch):
    """Streaming path also honours backend_map (red-team FATAL-1 fix)."""
    monkeypatch.delenv("GEMMA_BACKEND_MAP", raising=False)
    capture: dict[str, Any] = {}

    sse_body = (
        b'data: {"choices":[{"delta":{"content":"hello"}}]}\n\n'
        b'data: [DONE]\n\n'
    )

    def _handler(req: httpx.Request) -> httpx.Response:
        capture["url"] = str(req.url)
        return httpx.Response(
            200,
            content=sse_body,
            headers={"Content-Type": "text/event-stream"},
        )

    client = httpx.AsyncClient(transport=httpx.MockTransport(_handler))
    p = OpenAICompatProvider(
        base_url="http://default/v1",
        client=client,
        backend_map={"qwen3-3b-nsfw": "http://qwen-host:8402/v1"},
    )
    chunks: list[str] = []
    async for chunk in p.generate_stream(
        messages=[{"role": "user", "content": "hi"}],
        policy=ModelPolicy(provider="ollama", model="qwen3-3b-nsfw"),
    ):
        chunks.append(chunk)
    assert capture["url"] == "http://qwen-host:8402/v1/chat/completions"
    # We don't strictly assert chunk content (parse_openai_sse_line
    # behaviour is exercised in test_providers_stream.py); the URL is
    # the regression we own here.
