import os
import sys
import numpy
from setuptools import setup, Extension

ext_modules = []
pyx_path = os.path.join("build_src", "_core.pyx")
c_path = os.path.join("build_src", "_core.c")

def try_make_ext():
    if os.path.exists(pyx_path):
        from Cython.Build import cythonize
        args = []
        if sys.platform == "win32":
            args.extend(["/Od", "/Zm2000", "/bigobj"])
        else:
            args.extend(["-O2"])
        return cythonize([
            Extension(
                "datapruning._core", [pyx_path],
                include_dirs=[numpy.get_include()],
                extra_compile_args=args,
            )
        ], language_level=3)
    if os.path.exists(c_path):
        args = []
        if sys.platform == "win32":
            args.extend(["/Od", "/Zm2000", "/bigobj"])
        else:
            args.extend(["-O2"])
        return [
            Extension(
                "datapruning._core", [c_path],
                include_dirs=[numpy.get_include()],
                extra_compile_args=args,
            )
        ]
    return []

ext_modules = try_make_ext()

setup(
    name="datapruning",
    ext_modules=ext_modules,
)
