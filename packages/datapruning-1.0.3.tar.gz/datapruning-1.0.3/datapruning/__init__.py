MIN_ROWS = 1000
MAX_ROWS = 300_000

from ._core import Pruner as _Pruner, prune_dataframe as _prune_dataframe


def prune_dataframe(df, target_col=None, keep_ratio=0.5, **kwargs):
    if len(df) < MIN_ROWS:
        raise ValueError(
            f"Dataset too small for pruning. Minimum {MIN_ROWS:,} rows required, "
            f"got {len(df):,}. DataPruning needs enough samples to identify "
            f"redundant and high-signal patterns reliably."
        )
    if len(df) > MAX_ROWS:
        raise ValueError(
            f"Dataset exceeds maximum of {MAX_ROWS:,} rows (got {len(df):,})."
        )
    return _prune_dataframe(df, target_col=target_col, keep_ratio=keep_ratio, **kwargs)


class Pruner(_Pruner):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
