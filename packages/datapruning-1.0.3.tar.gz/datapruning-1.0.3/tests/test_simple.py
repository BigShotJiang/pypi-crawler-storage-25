import numpy as np
import pandas as pd
from datapruning import Pruner


def test_prune_classification():
    np.random.seed(42)
    n = 500
    df = pd.DataFrame({
        "a": np.random.randn(n),
        "b": np.random.randn(n),
        "label": np.random.randint(0, 2, size=n)
    })
    p = Pruner(df)
    result = p.prune(target_col="label", keep_ratio=0.5, num_steps=300)
    assert 350 < len(result) < 450
    assert list(result.columns) == ["a", "b", "label"]


def test_prune_regression():
    np.random.seed(42)
    n = 500
    df = pd.DataFrame({
        "x1": np.random.randn(n),
        "x2": np.random.randn(n),
        "target": np.random.randn(n)
    })
    p = Pruner(df)
    result = p.prune(target_col="target", keep_ratio=0.6, num_steps=300)
    assert len(result) >= 300
    assert list(result.columns) == ["x1", "x2", "target"]


def test_invalid_input():
    p = Pruner(pd.DataFrame({"a": [1, 2, 3]}))
    try:
        p.prune(target_col="bogus")
        assert False, "should have raised"
    except ValueError:
        pass


def test_not_dataframe():
    try:
        Pruner([1, 2, 3])
        assert False, "should have raised"
    except TypeError:
        pass
