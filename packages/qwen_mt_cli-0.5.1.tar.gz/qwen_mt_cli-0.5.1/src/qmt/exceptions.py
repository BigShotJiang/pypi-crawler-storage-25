"""Custom exceptions for qmt CLI."""


class QMTError(Exception):
    """Base exception for qmt."""


class APIKeyMissingError(QMTError):
    def __init__(self):
        super().__init__(
            "API Key 未设置。请通过以下任一方式配置:\n"
            "  1. --api-key 参数\n"
            "  2. 环境变量 DASHSCOPE_API_KEY\n"
            "  3. qmt config set --api-key <KEY>"
        )


class StreamingNotSupportedError(QMTError):
    def __init__(self, model: str):
        super().__init__(f"模型 {model} 不支持流式输出，已回退到非流式模式")


class FileReadError(QMTError):
    def __init__(self, path: str, reason: str = ""):
        msg = f"无法读取文件: {path}"
        if reason:
            msg += f" ({reason})"
        super().__init__(msg)


class ParseError(QMTError):
    def __init__(self, detail: str):
        super().__init__(f"解析错误: {detail}")


class APIError(QMTError):
    def __init__(self, detail: str):
        super().__init__(f"API 调用失败: {detail}")


class EmbeddingError(QMTError):
    def __init__(self, detail: str):
        super().__init__(f"向量嵌入失败: {detail}")
