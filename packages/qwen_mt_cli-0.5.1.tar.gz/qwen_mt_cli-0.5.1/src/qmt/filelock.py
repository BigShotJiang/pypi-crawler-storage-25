"""Cross-process file locking for concurrent CSV access."""

import fcntl
from contextlib import contextmanager
from pathlib import Path


@contextmanager
def shared_lock(path: Path):
    """Acquire a shared (read) lock on a file's companion .lock file."""
    lock_path = path.with_suffix(path.suffix + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with open(lock_path, "a") as lock_fd:
        fcntl.flock(lock_fd, fcntl.LOCK_SH)
        try:
            yield
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)


@contextmanager
def exclusive_lock(path: Path):
    """Acquire an exclusive (write) lock on a file's companion .lock file."""
    lock_path = path.with_suffix(path.suffix + ".lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    with open(lock_path, "a") as lock_fd:
        fcntl.flock(lock_fd, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_fd, fcntl.LOCK_UN)
