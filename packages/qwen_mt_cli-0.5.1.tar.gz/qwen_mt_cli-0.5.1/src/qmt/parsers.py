"""Input parsing utilities for qmt CLI."""

import csv
import io
import sys
from pathlib import Path

from qmt.exceptions import FileReadError, ParseError
from qmt.models import MemoryPair, TermPair


def read_file_with_encoding_fallback(path: Path) -> str:
    """Read file content with UTF-8, falling back to GBK."""
    p = Path(path)
    if not p.exists():
        raise FileReadError(str(p), "文件不存在")
    try:
        return p.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            return p.read_text(encoding="gbk")
        except Exception:
            raise FileReadError(str(p), "文件编码无法识别，请使用 UTF-8 编码")


def parse_inline_terms(text: str) -> list[TermPair]:
    """Parse inline terminology pairs from format: '源词1:译词1,源词2:译词2'."""
    if not text.strip():
        return []
    pairs = []
    for item in text.split(","):
        item = item.strip()
        if ":" not in item:
            raise ParseError(f"术语格式错误: '{item}'，应为 '源词:译词' 格式")
        parts = item.split(":", 1)
        source = parts[0].strip()
        target = parts[1].strip()
        if not source or not target:
            raise ParseError(f"术语不能为空: '{item}'")
        pairs.append(TermPair(source=source, target=target))
    return pairs


def _detect_delimiter(file_path: Path) -> str:
    if file_path.suffix.lower() == ".tsv":
        return "\t"
    try:
        with open(file_path, encoding="utf-8") as f:
            sample = f.read(4096)
        dialect = csv.Sniffer().sniff(sample, delimiters=",\t")
        return dialect.delimiter
    except csv.Error:
        return ","


def _parse_pair_file(file_path: Path) -> list[tuple[str, str]]:
    path = Path(file_path)
    content = read_file_with_encoding_fallback(path)

    if not content.strip():
        raise ParseError(f"文件为空: {path}")

    delimiter = _detect_delimiter(path)
    reader = csv.reader(io.StringIO(content), delimiter=delimiter)
    rows = list(reader)
    if not rows:
        raise ParseError(f"文件为空: {path}")

    has_header = False
    try:
        has_header = csv.Sniffer().has_header(content)
    except csv.Error:
        pass

    start = 1 if has_header else 0
    pairs = []
    for i, row in enumerate(rows[start:], start=start + 1):
        if not row or all(not cell.strip() for cell in row):
            continue
        if len(row) < 2:
            raise ParseError(f"第 {i} 行格式错误: 需要至少两列 (source, target)")
        source = row[0].strip()
        target = row[1].strip()
        if source and target:
            pairs.append((source, target))

    if not pairs:
        raise ParseError(f"文件中没有有效的数据行: {path}")
    return pairs


def parse_terms_file(file_path: Path) -> list[TermPair]:
    return [TermPair(source=s, target=t) for s, t in _parse_pair_file(file_path)]


def parse_memory_file(file_path: Path) -> list[MemoryPair]:
    return [MemoryPair(source=s, target=t) for s, t in _parse_pair_file(file_path)]


def read_file_content(file_path: Path) -> str:
    """Read entire file content for translation."""
    content = read_file_with_encoding_fallback(file_path)
    content = content.strip()
    if not content:
        raise FileReadError(str(file_path), "文件内容为空")
    return content


def read_csv_raw(file_path: Path) -> tuple[list[list[str]], str]:
    """Read CSV file preserving all columns. Returns (all_rows, delimiter)."""
    content = read_file_with_encoding_fallback(file_path)
    if not content.strip():
        raise ParseError(f"文件为空: {file_path}")
    delimiter = _detect_delimiter(Path(file_path))
    reader = csv.reader(io.StringIO(content), delimiter=delimiter)
    rows = list(reader)
    if not rows:
        raise ParseError(f"文件为空: {file_path}")
    return rows, delimiter


def read_stdin() -> str | None:
    if sys.stdin.isatty():
        return None
    content = sys.stdin.read().strip()
    return content if content else None
