"""Interactive REPL mode for qmt CLI."""

from prompt_toolkit import PromptSession
from prompt_toolkit.history import InMemoryHistory

from qmt.client import QwenMTClient
from qmt.constants import DEFAULT_TOP_K, MODEL_CHOICES, SMART_MATCH_THRESHOLD, STREAMING_MODELS
from qmt.exceptions import QMTError
from qmt.formatters import (
    console,
    create_spinner,
    print_error,
    print_info,
    print_interactive_banner,
    print_stream_chunk,
    print_stream_end,
    print_success,
    print_warning,
)
from qmt.models import MemoryPair, TermPair, TranslationRequest
from qmt import store

HELP_TEXT = """\
[bold]可用命令:[/bold]
  [cyan]/target <lang>[/cyan]   切换目标语言
  [cyan]/source <lang>[/cyan]   切换源语言
  [cyan]/model <name>[/cyan]    切换模型 (plus/flash/lite)
  [cyan]/stream[/cyan]          切换流式输出
  [cyan]/domain <domain>[/cyan] 设置领域提示 (clear 清除, save 保存为默认)
  [cyan]/topk <n>[/cyan]        设置语义匹配 Top-K (当前: {top_k})
  [cyan]/learn[/cyan]           切换翻译记忆自动学习 (当前: {learn})
  [cyan]/info[/cyan]            显示当前设置
  [cyan]/help[/cyan]            显示此帮助
  [cyan]exit / quit[/cyan]      退出
"""


def run_interactive(
    client: QwenMTClient,
    target_lang: str,
    source_lang: str,
    model: str,
    stream: bool,
    domain: str | None,
    store_terms: list[TermPair],
    extra_terms: list[TermPair],
    store_memory: list[MemoryPair],
    extra_memory: list[MemoryPair],
    api_key: str = "",
    top_k: int = DEFAULT_TOP_K,
    threshold: int = SMART_MATCH_THRESHOLD,
    learn: bool = False,
):
    print_interactive_banner(target_lang, source_lang, model)
    session: PromptSession[str] = PromptSession(history=InMemoryHistory())

    while True:
        try:
            user_input = session.prompt("qmt> ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Bye![/dim]")
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit"):
            console.print("[dim]Bye![/dim]")
            break

        if user_input.startswith("/"):
            parts = user_input.split(maxsplit=1)
            cmd = parts[0].lower()
            arg = parts[1].strip() if len(parts) > 1 else ""

            if cmd == "/help":
                console.print(HELP_TEXT.format(top_k=top_k, learn="开启" if learn else "关闭"))
            elif cmd == "/target":
                if not arg:
                    print_error("用法: /target <语言名>")
                else:
                    target_lang = arg
                    print_info(f"目标语言已切换为: {target_lang}")
            elif cmd == "/source":
                if not arg:
                    print_error("用法: /source <语言名>")
                else:
                    source_lang = arg
                    print_info(f"源语言已切换为: {source_lang}")
            elif cmd == "/model":
                if not arg:
                    print_error(f"用法: /model <{'|'.join(MODEL_CHOICES)}>")
                else:
                    full_name = arg if arg.startswith("qwen-mt-") else f"qwen-mt-{arg}"
                    if full_name in MODEL_CHOICES:
                        model = full_name
                        print_info(f"模型已切换为: {model}")
                    else:
                        print_error(f"无效模型: {arg}，可选: {', '.join(MODEL_CHOICES)}")
            elif cmd == "/stream":
                stream = not stream
                print_info(f"流式输出已{'开启' if stream else '关闭'}")
            elif cmd == "/domain":
                if not arg:
                    print_error("用法: /domain <领域名> 或 /domain clear|save")
                elif arg.lower() == "clear":
                    domain = None
                    print_info("领域提示已清除")
                elif arg.lower().startswith("save"):
                    save_parts = arg.split(maxsplit=1)
                    is_global = len(save_parts) > 1 and save_parts[1].lower() == "global"
                    if domain:
                        store.save_domain(domain, global_=is_global)
                        level = "全局" if is_global else "项目"
                        print_success(f"当前领域已保存为{level}默认值")
                    else:
                        print_error("当前无领域设置，无法保存")
                else:
                    domain = arg
                    print_info(f"领域提示已设置为: {domain}")
            elif cmd == "/topk":
                if not arg:
                    print_info(f"当前 Top-K: {top_k}")
                else:
                    try:
                        new_k = int(arg)
                        if new_k < 1:
                            raise ValueError
                        top_k = new_k
                        print_info(f"Top-K 已设置为: {top_k}")
                    except ValueError:
                        print_error("用法: /topk <正整数>")
            elif cmd == "/learn":
                learn = not learn
                print_info(f"翻译记忆自动学习已{'开启' if learn else '关闭'}")
            elif cmd == "/info":
                console.print(f"[dim]模型: {model}[/dim]")
                console.print(f"[dim]{source_lang} -> {target_lang}[/dim]")
                console.print(f"[dim]流式输出: {'开启' if stream else '关闭'}[/dim]")
                console.print(f"[dim]领域: {domain or '未设置'}[/dim]")
                total_terms = len(store_terms) + len(extra_terms)
                total_memory = len(store_memory) + len(extra_memory)
                if total_terms:
                    console.print(f"[dim]术语对: {total_terms} 条[/dim]")
                if total_memory:
                    console.print(f"[dim]翻译记忆: {total_memory} 条[/dim]")
                console.print(f"[dim]Top-K: {top_k}, 阈值: {threshold}[/dim]")
                console.print(f"[dim]自动学习: {'开启' if learn else '关闭'}[/dim]")
            else:
                print_error(f"未知命令: {cmd}，输入 /help 查看帮助")
            continue

        # Semantic filtering per input
        filtered_terms = extra_terms[:]
        filtered_memory = extra_memory[:]
        try:
            from qmt.matcher import select_relevant_memory, select_relevant_terms

            matched_terms = select_relevant_terms(
                query_text=user_input,
                store_terms=store_terms,
                api_key=api_key,
                top_k=top_k,
                threshold=threshold,
            )
            filtered_terms.extend(matched_terms)
        except Exception:
            filtered_terms.extend(store_terms)

        try:
            from qmt.matcher import select_relevant_memory

            matched_memory = select_relevant_memory(
                query_text=user_input,
                store_memory=store_memory,
                api_key=api_key,
                top_k=top_k,
                threshold=threshold,
            )
            filtered_memory.extend(matched_memory)
        except Exception:
            filtered_memory.extend(store_memory)

        request = TranslationRequest(
            text=user_input,
            source_lang=source_lang,
            target_lang=target_lang,
            model=model,
            stream=stream,
            domain=domain,
            terms=filtered_terms,
            tm_list=filtered_memory,
        )

        try:
            result_text = None
            if stream and model in STREAMING_MODELS:
                chunks = []
                for chunk in client.translate_stream(request):
                    print_stream_chunk(chunk)
                    chunks.append(chunk)
                print_stream_end()
                result_text = "".join(chunks)
            else:
                if stream and model not in STREAMING_MODELS:
                    print_warning(f"模型 {model} 不支持流式输出，使用非流式模式")
                with create_spinner():
                    result_text = client.translate(request)
                console.print(f"[green]{result_text}[/green]")

            # Learn: write to memory
            if learn and result_text:
                try:
                    from qmt.matcher import learn_memory

                    learn_memory(user_input, result_text, api_key)
                except Exception:
                    pass
        except QMTError as e:
            print_error(str(e))
        except Exception as e:
            print_error(f"翻译失败: {e}")
