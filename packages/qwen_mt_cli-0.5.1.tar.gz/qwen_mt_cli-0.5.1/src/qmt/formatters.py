"""Terminal output formatting for qmt CLI."""

import sys

from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
)
from rich.text import Text

console = Console(stderr=True)
output_console = Console()


def print_translation(
    text: str, verbose: bool = False, model: str = "", source: str = "", target: str = ""
):
    output_console.print(text, highlight=False)
    if verbose and model:
        info_parts = [f"模型: {model}"]
        if source and source != "auto":
            info_parts.append(f"源语言: {source}")
        info_parts.append(f"目标语言: {target}")
        console.print(f"[dim]{'  |  '.join(info_parts)}[/dim]")


def print_stream_chunk(chunk: str):
    sys.stdout.write(chunk)
    sys.stdout.flush()


def print_stream_end():
    sys.stdout.write("\n")
    sys.stdout.flush()


def print_error(message: str):
    console.print(f"[bold red]x[/bold red] {message}")


def print_warning(message: str):
    console.print(f"[bold yellow]![/bold yellow] {message}")


def print_info(message: str):
    console.print(f"[dim]{message}[/dim]")


def print_success(message: str):
    console.print(f"[bold green]v[/bold green] {message}")


def create_spinner(message: str = "翻译中..."):
    return console.status(f"[bold cyan]{message}[/bold cyan]", spinner="dots")


def print_interactive_banner(target_lang: str, source_lang: str, model: str):
    content = Text()
    content.append("Qwen-MT Interactive Translator\n", style="bold cyan")
    content.append(f"模型: {model}\n", style="dim")
    content.append(f"{source_lang} -> {target_lang}\n", style="dim")
    content.append("输入 /help 查看命令", style="dim italic")
    console.print(Panel(content, border_style="cyan", expand=False))


def create_batch_progress(total: int, description: str = "翻译中") -> Progress:
    """Create a Rich progress bar for batch translation."""
    progress = Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeRemainingColumn(),
        console=console,
    )
    progress.add_task(description, total=total)
    return progress


def print_batch_summary(result) -> None:
    """Print batch translation summary panel."""
    from qmt.models import BatchResult

    assert isinstance(result, BatchResult)
    lines = [
        f"总行数: {result.total}",
        f"[green]成功: {result.succeeded}[/green]",
    ]
    if result.failed > 0:
        lines.append(f"[red]失败: {result.failed}[/red]")
    if result.skipped > 0:
        lines.append(f"[yellow]跳过 (已恢复): {result.skipped}[/yellow]")
    lines.append(f"\n输出文件: {result.output_path}")
    console.print(Panel("\n".join(lines), title="批量翻译完成", border_style="green"))


def print_rate_limit_wait(seconds: int, attempt: int, max_attempts: int) -> None:
    """Print rate limit wait message."""
    console.print(
        f"[bold yellow]![/bold yellow] 触发限流，等待 {seconds}s 后重试 ({attempt}/{max_attempts})"
    )
