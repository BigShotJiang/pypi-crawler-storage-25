"""Qwen-MT API client using OpenAI SDK."""

from collections.abc import Generator

from openai import OpenAI

from qmt.constants import API_BASE_URL, STREAMING_MODELS
from qmt.exceptions import APIError, StreamingNotSupportedError
from qmt.models import TranslationRequest


class QwenMTClient:
    """Client for Qwen-MT translation API."""

    def __init__(self, api_key: str):
        self._client = OpenAI(api_key=api_key, base_url=API_BASE_URL)

    def _build_translation_options(self, request: TranslationRequest) -> dict:
        options: dict = {
            "source_lang": request.source_lang,
            "target_lang": request.target_lang,
        }
        if request.domain:
            options["domains"] = request.domain
        if request.terms:
            options["terms"] = [{"source": t.source, "target": t.target} for t in request.terms]
        if request.tm_list:
            options["tm_list"] = [{"source": m.source, "target": m.target} for m in request.tm_list]
        return options

    def translate(self, request: TranslationRequest) -> str:
        translation_options = self._build_translation_options(request)
        try:
            completion = self._client.chat.completions.create(
                model=request.model,
                messages=[{"role": "user", "content": request.text}],
                extra_body={"translation_options": translation_options},
            )
            return completion.choices[0].message.content or ""
        except Exception as e:
            raise APIError(str(e)) from e

    def translate_stream(self, request: TranslationRequest) -> Generator[str, None, None]:
        if request.model not in STREAMING_MODELS:
            raise StreamingNotSupportedError(request.model)
        translation_options = self._build_translation_options(request)
        try:
            stream = self._client.chat.completions.create(
                model=request.model,
                messages=[{"role": "user", "content": request.text}],
                stream=True,
                extra_body={"translation_options": translation_options},
            )
            for chunk in stream:
                if chunk.choices:
                    content = chunk.choices[0].delta.content
                    if content:
                        yield content
        except StreamingNotSupportedError:
            raise
        except Exception as e:
            raise APIError(str(e)) from e
