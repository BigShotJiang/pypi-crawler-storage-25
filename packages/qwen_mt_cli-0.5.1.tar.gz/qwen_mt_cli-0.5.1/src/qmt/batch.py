"""Batch translation for CSV and Excel files with async concurrency."""

import asyncio
import csv
import io
import json
from pathlib import Path

import pandas as pd

from qmt.async_client import AsyncQwenMTClient
from qmt.cache import get_cache, _hash_list
from qmt.constants import BATCH_CONCURRENCY, DEFAULT_TOP_K, SMART_MATCH_THRESHOLD
from qmt.formatters import (
    create_batch_progress,
    print_error,
    print_info,
    print_warning,
)
from qmt.models import BatchResult, TranslationRequest
from qmt.parsers import read_csv_raw, read_file_with_encoding_fallback


def _filter_terms_memory(
    source_text: str,
    store_terms: list,
    extra_terms: list,
    store_memory: list,
    extra_memory: list,
    api_key: str,
    top_k: int,
    threshold: int,
    query_embedding: list[float] | None = None,
    verbose: bool = False,
) -> tuple[list, list]:
    """Filter store terms/memory via semantic matching, merge with extras."""
    from qmt.matcher import select_relevant_memory, select_relevant_terms

    filtered_terms = extra_terms[:]
    try:
        matched = select_relevant_terms(
            query_text=source_text,
            store_terms=store_terms,
            api_key=api_key,
            top_k=top_k,
            threshold=threshold,
            query_embedding=query_embedding,
            verbose=verbose,
        )
        filtered_terms.extend(matched)
    except Exception:
        if len(store_terms) > threshold:
            filtered_terms.extend(store_terms[:top_k])
        else:
            filtered_terms.extend(store_terms)

    filtered_memory = extra_memory[:]
    try:
        matched = select_relevant_memory(
            query_text=source_text,
            store_memory=store_memory,
            api_key=api_key,
            top_k=top_k,
            threshold=threshold,
            query_embedding=query_embedding,
            verbose=verbose,
        )
        filtered_memory.extend(matched)
    except Exception:
        if len(store_memory) > threshold:
            filtered_memory.extend(store_memory[:top_k])
        else:
            filtered_memory.extend(store_memory)

    return filtered_terms, filtered_memory


def _needs_smart_match(store_terms: list, store_memory: list, threshold: int) -> bool:
    """Check if semantic matching should be attempted."""
    return len(store_terms) > threshold or len(store_memory) > threshold


def _warmup_vector_indices() -> None:
    """Pre-load vector indices into memory so first search is fast."""
    try:
        from qmt import store
        from qmt.vectorstore import VectorIndex

        for vec_path in (store.terms_vec_path(), store.memory_vec_path()):
            if vec_path.exists():
                idx = VectorIndex(vec_path, read_only=True)
                idx.load()
    except Exception:
        pass


def _pre_embed_batch(
    source_texts: list[str],
    store_terms: list,
    store_memory: list,
    api_key: str,
    threshold: int,
    verbose: bool,
) -> dict[str, list[float]]:
    """Pre-embed all source texts for batch efficiency. Returns text->embedding dict."""
    if not _needs_smart_match(store_terms, store_memory, threshold):
        return {}

    # Warm up vector indices in parallel with embedding (they'll be needed later)
    _warmup_vector_indices()

    try:
        from qmt.matcher import batch_embed_queries

        if verbose:
            print_info("正在预计算源文本向量嵌入 (5路并发)...")
        return batch_embed_queries(api_key, source_texts)
    except Exception:
        if verbose:
            print_warning("批量嵌入失败，将逐行回退到全量匹配")
        return {}


# ─── Adaptive concurrency control ──────────────────────────────────────────────


class _AdaptiveSemaphore:
    """Semaphore that adjusts its limit based on rate-limit feedback."""

    def __init__(self, initial: int, floor: int = 1):
        self._limit = initial
        self._initial = initial
        self._floor = floor
        self._semaphore = asyncio.Semaphore(initial)
        self._consecutive_429 = 0

    async def acquire(self):
        await self._semaphore.acquire()

    def release(self, got_429: bool = False):
        if got_429:
            self._consecutive_429 += 1
            if self._consecutive_429 >= 2 and self._limit > self._floor:
                self._limit = max(self._floor, self._limit - 1)
                # Rebuild semaphore with new limit on next cycle
        else:
            if self._consecutive_429 > 0:
                self._consecutive_429 = 0
            # Gradually recover after sustained success
            if self._limit < self._initial:
                self._limit = min(self._initial, self._limit + 1)
        self._semaphore.release()

    @property
    def current_limit(self) -> int:
        return self._limit


# ─── Async batch translation core ─────────────────────────────────────────────


async def _translate_one(
    async_client: AsyncQwenMTClient,
    semaphore: _AdaptiveSemaphore,
    source_text: str,
    source_lang: str,
    target_lang: str,
    model: str,
    domain: str | None,
    store_terms: list,
    extra_terms: list,
    store_memory: list,
    extra_memory: list,
    api_key: str,
    top_k: int,
    threshold: int,
    embeddings_map: dict,
) -> str:
    """Translate a single text with adaptive concurrency control and caching."""
    row_terms, row_memory = _filter_terms_memory(
        source_text,
        store_terms,
        extra_terms,
        store_memory,
        extra_memory,
        api_key,
        top_k,
        threshold,
        query_embedding=embeddings_map.get(source_text),
        verbose=False,
    )

    terms_hash = _hash_list(row_terms)
    memory_hash = _hash_list(row_memory)

    # Check cache
    cache = get_cache()
    cached = cache.get(source_text, source_lang, target_lang, model, domain, terms_hash, memory_hash)
    if cached is not None:
        return cached

    request = TranslationRequest(
        text=source_text,
        source_lang=source_lang,
        target_lang=target_lang,
        model=model,
        domain=domain,
        terms=row_terms,
        tm_list=row_memory,
    )

    await semaphore.acquire()
    got_429 = False
    try:
        result = await async_client.translate_with_retry(request)
    except Exception as e:
        err_msg = str(e).lower()
        if "429" in err_msg or "rate" in err_msg or "throttl" in err_msg:
            got_429 = True
        raise
    finally:
        semaphore.release(got_429=got_429)

    # Write to cache
    cache.put(source_text, source_lang, target_lang, model, result, domain, terms_hash, memory_hash)
    return result


async def _run_batch_translations(
    texts: list[str],
    source_lang: str,
    target_lang: str,
    model: str,
    domain: str | None,
    store_terms: list,
    extra_terms: list,
    store_memory: list,
    extra_memory: list,
    api_key: str,
    top_k: int,
    threshold: int,
    embeddings_map: dict,
    concurrency: int,
    progress_callback=None,
) -> list[str | Exception]:
    """Run batch translations concurrently with adaptive rate control."""
    semaphore = _AdaptiveSemaphore(concurrency)
    async_client = AsyncQwenMTClient(api_key)
    results: list[str | Exception] = [None] * len(texts)

    async def _do_one(idx: int, text: str):
        try:
            result = await _translate_one(
                async_client,
                semaphore,
                text,
                source_lang,
                target_lang,
                model,
                domain,
                store_terms,
                extra_terms,
                store_memory,
                extra_memory,
                api_key,
                top_k,
                threshold,
                embeddings_map,
            )
            results[idx] = result
        except Exception as e:
            results[idx] = e
        finally:
            if progress_callback:
                progress_callback()

    # Warm up HTTP connection before launching tasks
    await async_client.warmup()

    tasks = [asyncio.create_task(_do_one(i, t)) for i, t in enumerate(texts)]

    try:
        await asyncio.gather(*tasks)
    except asyncio.CancelledError:
        pass
    finally:
        await async_client.close()

    return results


# ─── CSV Batch ──────────────────────────────────────────────────────────────


def translate_csv(
    client,
    input_path: Path,
    output_path: Path,
    source_lang: str,
    target_lang: str,
    model: str,
    domain: str | None = None,
    store_terms: list | None = None,
    extra_terms: list | None = None,
    store_memory: list | None = None,
    extra_memory: list | None = None,
    has_header: bool = True,
    resume: bool = False,
    api_key: str = "",
    top_k: int = DEFAULT_TOP_K,
    threshold: int = SMART_MATCH_THRESHOLD,
    learn: bool = False,
    verbose: bool = False,
    concurrency: int = BATCH_CONCURRENCY,
) -> BatchResult:
    """Translate CSV file with concurrent API calls."""
    store_terms = store_terms or []
    extra_terms = extra_terms or []
    store_memory = store_memory or []
    extra_memory = extra_memory or []

    rows, delimiter = read_csv_raw(input_path)
    total_rows = len(rows)

    data_start = 1 if has_header else 0
    translatable = total_rows - data_start

    if translatable <= 0:
        print_warning("文件中没有可翻译的数据行")
        return BatchResult(total=0, succeeded=0, failed=0, skipped=0, output_path=output_path)

    # Resume: count rows already written in output
    completed = 0
    if resume and output_path.exists():
        try:
            existing = read_file_with_encoding_fallback(output_path)
            existing_rows = list(csv.reader(io.StringIO(existing), delimiter=delimiter))
            completed = len(existing_rows) - (1 if has_header else 0)
            completed = max(completed, 0)
            if completed > 0 and verbose:
                print_info(f"恢复模式: 跳过已翻译的 {completed} 行")
        except Exception:
            completed = 0

    # Collect all pending rows (preserving row index for output ordering)
    pending_rows: list[tuple[int, str]] = []  # (row_index, source_text)
    for i in range(data_start, total_rows):
        data_index = i - data_start
        if data_index < completed:
            continue
        source_text = rows[i][0].strip() if rows[i] else ""
        if source_text:
            pending_rows.append((i, source_text))

    pending_texts = [t for _, t in pending_rows]

    # Pre-embed source texts for smart matching
    embeddings_map = _pre_embed_batch(
        pending_texts,
        store_terms,
        store_memory,
        api_key,
        threshold,
        verbose,
    )

    # Chunk size for progressive flush (write every N translated rows)
    FLUSH_CHUNK = max(concurrency * 4, 20)

    # Split pending into chunks for progressive flush
    chunks: list[list[tuple[int, str]]] = []
    for i in range(0, len(pending_rows), FLUSH_CHUNK):
        chunks.append(pending_rows[i : i + FLUSH_CHUNK])

    # Run concurrent translations with progress, flushing per chunk
    progress = create_batch_progress(translatable)
    task_id = list(progress.task_ids)[0]

    succeeded = 0
    failed = 0
    skipped = completed
    learn_pairs: list[tuple[str, str]] = []

    # Open output file for writing
    mode = "a" if completed > 0 else "w"
    f = open(output_path, mode, newline="", encoding="utf-8")
    writer = csv.writer(f, delimiter=delimiter)
    if mode == "w" and has_header:
        writer.writerow(rows[0] + ["translation"])
        f.flush()

    with progress:
        if completed > 0:
            progress.advance(task_id, completed)
        # Advance for empty rows
        empty_count = (translatable - completed) - len(pending_texts)
        if empty_count > 0:
            progress.advance(task_id, empty_count)

        for chunk in chunks:
            chunk_texts = [t for _, t in chunk]
            chunk_indices = [i for i, _ in chunk]

            def _on_progress():
                progress.advance(task_id)

            results = asyncio.run(
                _run_batch_translations(
                    texts=chunk_texts,
                    source_lang=source_lang,
                    target_lang=target_lang,
                    model=model,
                    domain=domain,
                    store_terms=store_terms,
                    extra_terms=extra_terms,
                    store_memory=store_memory,
                    extra_memory=extra_memory,
                    api_key=api_key,
                    top_k=top_k,
                    threshold=threshold,
                    embeddings_map=embeddings_map,
                    concurrency=concurrency,
                    progress_callback=_on_progress,
                )
            )

            # Write this chunk's results immediately
            # We need to write all rows in order (including empty ones between chunks)
            result_map: dict[int, str] = {}
            for idx, (row_i, source_text) in enumerate(chunk):
                r = results[idx]
                if isinstance(r, Exception):
                    result_map[row_i] = f"[ERROR: {r}]"
                    failed += 1
                    if verbose:
                        print_error(f"第 {row_i + 1} 行翻译失败: {r}")
                else:
                    result_map[row_i] = r
                    succeeded += 1
                    if learn and r:
                        learn_pairs.append((source_text, r))

            # Write rows for this chunk's range (including any empty rows)
            range_start = chunk_indices[0]
            range_end = chunk_indices[-1] + 1
            for i in range(range_start, range_end):
                row = rows[i]
                source_text = row[0].strip() if row else ""
                if source_text and i in result_map:
                    writer.writerow(row + [result_map[i]])
                else:
                    writer.writerow(row + [result_map.get(i, "")])
            # Also write any trailing empty rows before next chunk
            if chunks.index(chunk) < len(chunks) - 1:
                next_start = chunks[chunks.index(chunk) + 1][0][0]
                for i in range(range_end, next_start):
                    writer.writerow(rows[i] + [""])
            f.flush()

    # Write any remaining empty rows after last chunk
    if pending_rows:
        last_pending = pending_rows[-1][0]
        for i in range(last_pending + 1, total_rows):
            writer.writerow(rows[i] + [""])
        f.flush()

    f.close()

    # Batch learn
    if learn_pairs:
        try:
            from qmt.matcher import batch_learn_memory

            batch_learn_memory(learn_pairs, api_key)
            if verbose:
                print_info(f"已将 {len(learn_pairs)} 条翻译结果写入翻译记忆")
        except Exception:
            if verbose:
                print_warning("翻译记忆批量回写失败")

    return BatchResult(
        total=translatable,
        succeeded=succeeded,
        failed=failed,
        skipped=skipped,
        output_path=output_path,
    )


# ─── Excel Batch ────────────────────────────────────────────────────────────

_PROGRESS_FILE = ".qmt/batch_progress.json"


def _load_excel_progress(input_path: Path) -> dict:
    """Load progress checkpoint for an Excel batch job."""
    pf = Path(_PROGRESS_FILE)
    if not pf.exists():
        return {}
    try:
        data = json.loads(pf.read_text(encoding="utf-8"))
        if data.get("input") == str(input_path):
            return data.get("sheets", {})
        return {}
    except Exception:
        return {}


def _save_excel_progress(input_path: Path, sheets: dict) -> None:
    """Save progress checkpoint for an Excel batch job."""
    pf = Path(_PROGRESS_FILE)
    pf.parent.mkdir(parents=True, exist_ok=True)
    pf.write_text(
        json.dumps({"input": str(input_path), "sheets": sheets}, ensure_ascii=False),
        encoding="utf-8",
    )


def _clear_excel_progress() -> None:
    pf = Path(_PROGRESS_FILE)
    if pf.exists():
        pf.unlink()


def translate_excel(
    client,
    input_path: Path,
    output_path: Path,
    source_lang: str,
    target_lang: str,
    model: str,
    domain: str | None = None,
    store_terms: list | None = None,
    extra_terms: list | None = None,
    store_memory: list | None = None,
    extra_memory: list | None = None,
    has_header: bool = True,
    resume: bool = False,
    api_key: str = "",
    top_k: int = DEFAULT_TOP_K,
    threshold: int = SMART_MATCH_THRESHOLD,
    learn: bool = False,
    verbose: bool = False,
    concurrency: int = BATCH_CONCURRENCY,
) -> BatchResult:
    """Translate Excel file with concurrent API calls."""
    store_terms = store_terms or []
    extra_terms = extra_terms or []
    store_memory = store_memory or []
    extra_memory = extra_memory or []

    # Read all sheets
    all_sheets: dict[str, pd.DataFrame] = pd.read_excel(
        input_path,
        sheet_name=None,
        header=0 if has_header else None,
        dtype=str,
    )

    if not all_sheets:
        print_warning("Excel 文件中没有工作表")
        return BatchResult(total=0, succeeded=0, failed=0, skipped=0, output_path=output_path)

    total = sum(len(df) for df in all_sheets.values())
    if total == 0:
        print_warning("Excel 文件中没有可翻译的数据行")
        return BatchResult(total=0, succeeded=0, failed=0, skipped=0, output_path=output_path)

    # Pre-embed all source texts
    all_sources: list[str] = []
    for df in all_sheets.values():
        for row_idx in range(len(df)):
            val = str(df.iloc[row_idx, 0]).strip()
            if val and val != "nan":
                all_sources.append(val)

    embeddings_map = _pre_embed_batch(
        all_sources,
        store_terms,
        store_memory,
        api_key,
        threshold,
        verbose,
    )

    # Load resume progress
    sheet_progress: dict = {}
    if resume:
        sheet_progress = _load_excel_progress(input_path)
        if sheet_progress and verbose:
            print_info("恢复模式: 加载已有进度")

    succeeded = 0
    failed = 0
    skipped = 0
    result_sheets: dict[str, pd.DataFrame] = {}
    learn_pairs: list[tuple[str, str]] = []

    progress = create_batch_progress(total)
    task_id = list(progress.task_ids)[0]

    with progress:
        for sheet_name, df in all_sheets.items():
            completed_in_sheet = int(sheet_progress.get(sheet_name, 0))

            # Collect pending texts for this sheet
            pending_indices: list[int] = []
            pending_texts: list[str] = []
            for row_idx in range(len(df)):
                if row_idx < completed_in_sheet:
                    skipped += 1
                    progress.advance(task_id)
                    continue
                source_text = str(df.iloc[row_idx, 0]).strip()
                if source_text and source_text != "nan":
                    pending_indices.append(row_idx)
                    pending_texts.append(source_text)
                else:
                    progress.advance(task_id)

            # Run concurrent translations for this sheet
            if pending_texts:

                def _on_progress():
                    progress.advance(task_id)

                results = asyncio.run(
                    _run_batch_translations(
                        texts=pending_texts,
                        source_lang=source_lang,
                        target_lang=target_lang,
                        model=model,
                        domain=domain,
                        store_terms=store_terms,
                        extra_terms=extra_terms,
                        store_memory=store_memory,
                        extra_memory=extra_memory,
                        api_key=api_key,
                        top_k=top_k,
                        threshold=threshold,
                        embeddings_map=embeddings_map,
                        concurrency=concurrency,
                        progress_callback=_on_progress,
                    )
                )
            else:
                results = []

            # Build translations list for this sheet
            translations = [""] * len(df)
            result_idx = 0
            for row_idx in range(len(df)):
                if row_idx < completed_in_sheet:
                    translations[row_idx] = None  # placeholder for resume merge
                    continue
                source_text = str(df.iloc[row_idx, 0]).strip()
                if source_text and source_text != "nan" and result_idx < len(results):
                    result = results[result_idx]
                    result_idx += 1
                    if isinstance(result, Exception):
                        translations[row_idx] = f"[ERROR: {result}]"
                        failed += 1
                        if verbose:
                            print_error(f"[{sheet_name}] 第 {row_idx + 1} 行翻译失败: {result}")
                    else:
                        translations[row_idx] = result
                        succeeded += 1
                        if learn and result:
                            learn_pairs.append((source_text, result))

            # Save progress
            sheet_progress[sheet_name] = len(df)
            _save_excel_progress(input_path, sheet_progress)

            # Resume: merge translations from existing output
            if resume and completed_in_sheet > 0 and output_path.exists():
                try:
                    existing = pd.read_excel(
                        output_path,
                        sheet_name=sheet_name,
                        header=0 if has_header else None,
                        dtype=str,
                    )
                    if "translation" in (existing.columns if has_header else []):
                        col = existing["translation"]
                    elif not has_header and len(existing.columns) > len(df.columns):
                        col = existing.iloc[:, -1]
                    else:
                        col = pd.Series([""] * len(existing))

                    for j in range(min(completed_in_sheet, len(col))):
                        val = col.iloc[j]
                        translations[j] = "" if pd.isna(val) else str(val)
                except Exception:
                    for j in range(completed_in_sheet):
                        if translations[j] is None:
                            translations[j] = ""

            translations = ["" if t is None else t for t in translations]

            df_result = df.copy()
            df_result["translation"] = translations
            result_sheets[sheet_name] = df_result

    # Write output
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        for sheet_name, df_out in result_sheets.items():
            df_out.to_excel(writer, sheet_name=sheet_name, index=False)

    # Batch learn
    if learn_pairs:
        try:
            from qmt.matcher import batch_learn_memory

            batch_learn_memory(learn_pairs, api_key)
            if verbose:
                print_info(f"已将 {len(learn_pairs)} 条翻译结果写入翻译记忆")
        except Exception:
            if verbose:
                print_warning("翻译记忆批量回写失败")

    if failed == 0:
        _clear_excel_progress()

    return BatchResult(
        total=total,
        succeeded=succeeded,
        failed=failed,
        skipped=skipped,
        output_path=output_path,
    )
