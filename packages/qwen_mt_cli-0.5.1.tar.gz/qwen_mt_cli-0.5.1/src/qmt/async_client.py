"""Async Qwen-MT API client for concurrent batch translation."""

import asyncio

from openai import AsyncOpenAI

from qmt.constants import API_BASE_URL
from qmt.exceptions import APIError
from qmt.models import TranslationRequest

MAX_RETRIES = 5
INITIAL_BACKOFF = 2


class AsyncQwenMTClient:
    """Async client for Qwen-MT translation API."""

    def __init__(self, api_key: str):
        self._client = AsyncOpenAI(api_key=api_key, base_url=API_BASE_URL)

    def _build_translation_options(self, request: TranslationRequest) -> dict:
        options: dict = {
            "source_lang": request.source_lang,
            "target_lang": request.target_lang,
        }
        if request.domain:
            options["domains"] = request.domain
        if request.terms:
            options["terms"] = [{"source": t.source, "target": t.target} for t in request.terms]
        if request.tm_list:
            options["tm_list"] = [{"source": m.source, "target": m.target} for m in request.tm_list]
        return options

    async def translate(self, request: TranslationRequest) -> str:
        translation_options = self._build_translation_options(request)
        try:
            completion = await self._client.chat.completions.create(
                model=request.model,
                messages=[{"role": "user", "content": request.text}],
                extra_body={"translation_options": translation_options},
            )
            return completion.choices[0].message.content or ""
        except Exception as e:
            raise APIError(str(e)) from e

    async def translate_with_retry(
        self, request: TranslationRequest, max_retries: int = MAX_RETRIES
    ) -> str:
        for attempt in range(max_retries + 1):
            try:
                return await self.translate(request)
            except APIError as e:
                err_msg = str(e).lower()
                is_rate_limit = "rate" in err_msg or "429" in err_msg or "throttl" in err_msg
                if is_rate_limit and attempt < max_retries:
                    wait = INITIAL_BACKOFF * (2**attempt)
                    await asyncio.sleep(wait)
                else:
                    raise
        raise APIError("重试次数已用尽")

    async def warmup(self) -> None:
        """Establish HTTP connection pool (TLS handshake) before real work."""
        try:
            await self._client.models.list()
        except Exception:
            pass  # Connection is warmed up even if the request fails

    async def close(self):
        await self._client.close()
