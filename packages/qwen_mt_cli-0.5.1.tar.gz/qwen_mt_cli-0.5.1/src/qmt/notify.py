"""Email notification for batch translation completion.

Uses Python stdlib smtplib + email.mime. No external dependencies.
"""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from qmt.formatters import print_info, print_warning
from qmt.models import BatchResult

_SMTP_TIMEOUT = 30


def try_send_batch_notification(result: BatchResult, metadata: dict) -> None:
    """Send email notification after batch translation (best-effort).

    Silently skips if SMTP is not configured. Prints warning on send failure.

    Args:
        result: BatchResult with translation statistics.
        metadata: dict with keys: input_file, target_lang, elapsed_seconds.
    """
    from qmt import store

    if not store.smtp_configured():
        return

    config = store.load_smtp_config()
    subject = _build_subject(result, metadata)
    plain, html = _build_body(result, metadata)

    try:
        _send_email(subject, plain, html, config)
        recipient = config.get("notify_email", "")
        print_info(f"通知邮件已发送至 {recipient}")
    except Exception as e:
        print_warning(f"邮件通知发送失败: {e}")


def _build_subject(result: BatchResult, metadata: dict) -> str:
    """Build email subject line."""
    filename = metadata.get("input_file", "batch")
    lang = metadata.get("target_lang", "")
    total = result.total
    succeeded = result.succeeded

    if result.failed > 0:
        return (
            f"[qmt] 批量翻译完成 (有失败) — {filename} → {lang} "
            f"({succeeded}/{total} 成功, {result.failed} 失败)"
        )
    return f"[qmt] 批量翻译完成 — {filename} → {lang} ({succeeded}/{total} 成功)"


def _build_body(result: BatchResult, metadata: dict) -> tuple[str, str]:
    """Build email body in both plain text and HTML formats."""
    filename = metadata.get("input_file", "")
    lang = metadata.get("target_lang", "")
    elapsed = metadata.get("elapsed_seconds", 0)
    elapsed_str = _format_elapsed(elapsed)

    # Plain text version
    plain_lines = [
        "批量翻译已完成",
        "",
        f"输入文件: {filename}",
        f"目标语言: {lang}",
        f"总行数:   {result.total}",
        f"成功:     {result.succeeded}",
        f"失败:     {result.failed}",
        f"跳过:     {result.skipped}",
        f"耗时:     {elapsed_str}",
        f"输出文件: {result.output_path}",
    ]
    plain = "\n".join(plain_lines)

    # HTML version
    rows_html = "".join([
        _html_row("输入文件", filename),
        _html_row("目标语言", lang),
        _html_row("总行数", str(result.total)),
        _html_row("成功", str(result.succeeded), color="#22c55e"),
        _html_row("失败", str(result.failed), color="#ef4444" if result.failed else None),
        _html_row("跳过", str(result.skipped)),
        _html_row("耗时", elapsed_str),
        _html_row("输出文件", str(result.output_path)),
    ])

    html = f"""\
<html>
<body style="font-family: -apple-system, sans-serif; padding: 20px;">
<h2 style="color: #1a1a1a;">批量翻译完成</h2>
<table style="border-collapse: collapse; width: 100%; max-width: 500px;">
{rows_html}
</table>
<p style="color: #666; font-size: 12px; margin-top: 20px;">— qmt CLI</p>
</body>
</html>"""

    return plain, html


def _html_row(label: str, value: str, color: str | None = None) -> str:
    """Build a single HTML table row."""
    style_val = f' style="color: {color}; font-weight: bold;"' if color else ""
    return (
        f'<tr style="border-bottom: 1px solid #eee;">'
        f'<td style="padding: 8px 12px; color: #666;">{label}</td>'
        f'<td style="padding: 8px 12px;"{style_val}>{value}</td>'
        f'</tr>\n'
    )


def _format_elapsed(seconds: float) -> str:
    """Format seconds into human-readable duration."""
    s = int(seconds)
    if s < 60:
        return f"{s}s"
    if s < 3600:
        return f"{s // 60}m {s % 60}s"
    h = s // 3600
    m = (s % 3600) // 60
    return f"{h}h {m}m"


def _send_email(subject: str, plain: str, html: str, config: dict) -> None:
    """Send email via SMTP. Raises on failure."""
    host = config["smtp_host"]
    port = int(config.get("smtp_port", "465"))
    user = config["smtp_user"]
    password = config["smtp_pass"]
    recipient = config["notify_email"]

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = user
    msg["To"] = recipient
    msg.attach(MIMEText(plain, "plain", "utf-8"))
    msg.attach(MIMEText(html, "html", "utf-8"))

    if port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=_SMTP_TIMEOUT) as server:
            server.login(user, password)
            server.sendmail(user, [recipient], msg.as_string())
    else:
        with smtplib.SMTP(host, port, timeout=_SMTP_TIMEOUT) as server:
            server.starttls()
            server.login(user, password)
            server.sendmail(user, [recipient], msg.as_string())
