"""Qwen-MT CLI - Command-line translation tool powered by Qwen-MT."""

__version__ = "0.5.1"
