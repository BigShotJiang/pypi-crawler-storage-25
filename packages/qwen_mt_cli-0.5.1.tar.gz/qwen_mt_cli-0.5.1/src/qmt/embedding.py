"""DashScope text-embedding API wrapper using OpenAI-compatible endpoint."""

from concurrent.futures import ThreadPoolExecutor, as_completed

from openai import OpenAI

from qmt.constants import (
    API_BASE_URL,
    EMBEDDING_BATCH_SIZE,
    EMBEDDING_CONCURRENCY,
    EMBEDDING_DIM,
    EMBEDDING_MODEL,
)
from qmt.exceptions import EmbeddingError


def get_embeddings(
    api_key: str,
    texts: list[str],
    batch_size: int = EMBEDDING_BATCH_SIZE,
) -> list[list[float]]:
    """Batch-embed texts via DashScope text-embedding API (sequential).

    Returns a list of embedding vectors in the same order as input texts.
    Raises EmbeddingError on failure.
    """
    if not texts:
        return []

    client = OpenAI(api_key=api_key, base_url=API_BASE_URL)
    all_embeddings: list[list[float]] = []

    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        try:
            response = client.embeddings.create(
                model=EMBEDDING_MODEL,
                input=batch,
                dimensions=EMBEDDING_DIM,
            )
            sorted_data = sorted(response.data, key=lambda d: d.index)
            all_embeddings.extend([d.embedding for d in sorted_data])
        except Exception as e:
            raise EmbeddingError(str(e)) from e

    return all_embeddings


def get_embeddings_concurrent(
    api_key: str,
    texts: list[str],
    batch_size: int = EMBEDDING_BATCH_SIZE,
    max_workers: int = EMBEDDING_CONCURRENCY,
    on_progress: "callable | None" = None,
) -> list[list[float]]:
    """Batch-embed texts with concurrent API calls for faster throughput.

    Args:
        api_key: DashScope API key.
        texts: List of texts to embed.
        batch_size: Texts per API request (max 10 for DashScope).
        max_workers: Number of concurrent threads.
        on_progress: Optional callback(completed_count, total_count) for progress reporting.

    Returns a list of embedding vectors in the same order as input texts.
    Raises EmbeddingError on failure.
    """
    if not texts:
        return []

    # Split into batches with their original index
    batches: list[tuple[int, list[str]]] = []
    for i in range(0, len(texts), batch_size):
        batches.append((i, texts[i : i + batch_size]))

    total = len(texts)
    results: dict[int, list[list[float]]] = {}
    completed = 0

    def _embed_batch(batch_index: int, batch_texts: list[str]) -> tuple[int, list[list[float]]]:
        client = OpenAI(api_key=api_key, base_url=API_BASE_URL)
        response = client.embeddings.create(
            model=EMBEDDING_MODEL,
            input=batch_texts,
            dimensions=EMBEDDING_DIM,
        )
        sorted_data = sorted(response.data, key=lambda d: d.index)
        return batch_index, [d.embedding for d in sorted_data]

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(_embed_batch, idx, batch): idx
            for idx, batch in batches
        }

        for future in as_completed(futures):
            try:
                batch_idx, embeddings = future.result()
                results[batch_idx] = embeddings
                completed += len(embeddings)
                if on_progress:
                    on_progress(completed, total)
            except Exception as e:
                # Cancel remaining futures on error
                for f in futures:
                    f.cancel()
                raise EmbeddingError(str(e)) from e

    # Reassemble in original order
    all_embeddings: list[list[float]] = []
    for idx, _ in batches:
        all_embeddings.extend(results[idx])

    return all_embeddings
