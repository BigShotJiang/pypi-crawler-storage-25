"""Data models for qmt CLI."""

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class TermPair:
    """A terminology mapping pair."""

    source: str
    target: str


@dataclass
class MemoryPair:
    """A translation memory pair."""

    source: str
    target: str


@dataclass
class TranslationRequest:
    """Bundles all parameters for a single translation call."""

    text: str
    source_lang: str
    target_lang: str
    model: str
    stream: bool = False
    domain: str | None = None
    terms: list[TermPair] = field(default_factory=list)
    tm_list: list[MemoryPair] = field(default_factory=list)


@dataclass
class BatchResult:
    """Result summary for batch translation."""

    total: int
    succeeded: int
    failed: int
    skipped: int  # rows skipped during resume
    output_path: Path
