"""Vector index storage using zvec (HNSW + binary persistence).

Replaces the previous JSON + numpy implementation for better performance
at scale (25K+ entries).

Supports read-only mode for concurrent access: multiple readers can query
simultaneously while a writer (rebuild) holds an exclusive lock.
"""

import fcntl
import hashlib
import json
import os
import shutil
import tempfile
from pathlib import Path

import zvec

from qmt.constants import EMBEDDING_DIM, EMBEDDING_MODEL


_INDEX_VERSION = 2


def _make_id(source: str) -> str:
    """Generate a deterministic doc ID from source text."""
    return hashlib.sha256(source.encode("utf-8")).hexdigest()[:16]


def _build_schema(name: str) -> zvec.CollectionSchema:
    """Build the zvec collection schema."""
    return zvec.CollectionSchema(
        name=name,
        fields=zvec.FieldSchema("source", zvec.DataType.STRING),
        vectors=zvec.VectorSchema(
            "embedding",
            zvec.DataType.VECTOR_FP32,
            dimension=EMBEDDING_DIM,
            index_param=zvec.HnswIndexParam(metric_type=zvec.MetricType.COSINE),
        ),
    )


class VectorIndex:
    """zvec-backed vector index with HNSW similarity search.

    Supports two modes:
      - read_only=True:  concurrent reads, no writes (default for search)
      - read_only=False: exclusive access for writes (rebuild/sync)
    """

    def __init__(self, path: Path, read_only: bool = False):
        self._path = Path(path)
        self._manifest_path = self._path.with_suffix(self._path.suffix + ".manifest")
        self._collection: zvec.Collection | None = None
        self._source_to_id: dict[str, str] = {}
        self._model: str = EMBEDDING_MODEL
        self._loaded = False
        self._read_only = read_only
        self._manifest_mtime: float = 0.0

    # ─── Persistence ────────────────────────────────────────────────────

    def load(self) -> None:
        """Load or initialize the vector index."""
        # Load manifest (source -> id mapping + metadata)
        if self._manifest_path.exists():
            try:
                self._manifest_mtime = self._manifest_path.stat().st_mtime
                data = json.loads(self._manifest_path.read_text(encoding="utf-8"))
                self._source_to_id = data.get("sources", {})
                self._model = data.get("model", EMBEDDING_MODEL)
            except (json.JSONDecodeError, KeyError):
                self._source_to_id = {}

        # Open zvec collection if it exists
        if self._path.exists() and self._path.is_dir():
            self._collection = self._try_open_collection()
        else:
            self._collection = None

        self._loaded = True

    def _is_lock_stale(self, lock_file: Path) -> bool:
        """Check if a LOCK file is stale (not held by any live process)."""
        try:
            fd = os.open(str(lock_file), os.O_RDWR)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                fcntl.flock(fd, fcntl.LOCK_UN)
                return True  # Lock acquired → no process holds it → stale
            except OSError:
                return False  # Another process holds the lock → not stale
            finally:
                os.close(fd)
        except OSError:
            return True  # Can't open file → treat as stale

    def _try_open_collection(self) -> "zvec.Collection | None":
        """Try to open zvec collection, handling stale/missing LOCK issues.

        If read_only=False and write lock is unavailable (held by another process),
        automatically falls back to read-only mode.
        """
        lock_file = self._path / "LOCK"
        option = zvec.CollectionOption(read_only=1 if self._read_only else 0)

        # Ensure LOCK file exists (zvec requires it even for read-only)
        if not lock_file.exists():
            lock_file.touch()

        try:
            return zvec.open(str(self._path), option)
        except RuntimeError:
            if not self._read_only:
                # Write lock unavailable — fallback to read-only
                try:
                    self._read_only = True
                    ro_option = zvec.CollectionOption(read_only=1)
                    return zvec.open(str(self._path), ro_option)
                except Exception:
                    pass
            # Only reset LOCK if confirmed stale (no live process holds it)
            if self._is_lock_stale(lock_file):
                lock_file.unlink(missing_ok=True)
                lock_file.touch()
                try:
                    return zvec.open(str(self._path), option)
                except Exception:
                    return None
            return None
        except Exception:
            return None

    def save(self) -> None:
        """Persist current state (flush zvec + write manifest atomically)."""
        if self._collection is not None:
            self._collection.flush()

        # Atomic write: tmp file + os.replace to prevent partial manifest on crash
        self._manifest_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "version": _INDEX_VERSION,
            "model": self._model,
            "sources": self._source_to_id,
        }
        tmp_fd, tmp_path = tempfile.mkstemp(
            dir=str(self._manifest_path.parent), suffix=".tmp"
        )
        try:
            with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            os.replace(tmp_path, str(self._manifest_path))
        except BaseException:
            os.unlink(tmp_path)
            raise

    # ─── Query ──────────────────────────────────────────────────────────

    def is_stale(self) -> bool:
        """Check if underlying manifest has been modified since last load."""
        if not self._manifest_path.exists():
            return bool(self._source_to_id)
        try:
            return self._manifest_path.stat().st_mtime != self._manifest_mtime
        except OSError:
            return False

    def sources(self) -> set[str]:
        """Return set of all indexed source texts."""
        return set(self._source_to_id.keys())

    def model_name(self) -> str | None:
        """Return the embedding model name stored in this index."""
        return self._model if self._source_to_id else None

    def is_empty(self) -> bool:
        return len(self._source_to_id) == 0

    # ─── Mutation ───────────────────────────────────────────────────────

    def _ensure_collection(self) -> zvec.Collection:
        """Lazily create the zvec collection on first write."""
        if self._collection is None:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            col_name = self._path.stem  # e.g. "terms" or "memory"
            schema = _build_schema(col_name)
            self._collection = zvec.create_and_open(str(self._path), schema)
        return self._collection

    _WRITE_BATCH_SIZE = 1000  # zvec max is 1024, use 1000 for safety

    def add_entries(self, entries: list[tuple[str, list[float]]]) -> None:
        """Add (source_text, vector) pairs to the index."""
        if not entries:
            return
        col = self._ensure_collection()
        docs = []
        for source, vector in entries:
            doc_id = _make_id(source)
            docs.append(zvec.Doc(
                id=doc_id,
                fields={"source": source},
                vectors={"embedding": vector},
            ))
            self._source_to_id[source] = doc_id

        # zvec limits insert to 1024 docs per call, batch accordingly
        for i in range(0, len(docs), self._WRITE_BATCH_SIZE):
            col.insert(docs[i : i + self._WRITE_BATCH_SIZE])

    def upsert_entry(self, source: str, vector: list[float]) -> None:
        """Add or update a single entry by source text."""
        col = self._ensure_collection()
        doc_id = _make_id(source)
        doc = zvec.Doc(
            id=doc_id,
            fields={"source": source},
            vectors={"embedding": vector},
        )
        col.upsert([doc])
        self._source_to_id[source] = doc_id

    def remove_by_sources(self, to_remove: set[str]) -> None:
        """Remove entries whose source text is in the given set."""
        if not to_remove or self._collection is None:
            return
        ids_to_delete = [
            self._source_to_id[s] for s in to_remove if s in self._source_to_id
        ]
        if ids_to_delete:
            self._collection.delete(ids_to_delete)
        for s in to_remove:
            self._source_to_id.pop(s, None)

    def clear(self) -> None:
        """Empty the index and delete all files."""
        if self._collection is not None:
            try:
                self._collection.destroy()
            except Exception:
                pass
            self._collection = None

        self._source_to_id = {}

        # Remove directory and manifest file
        if self._path.exists():
            shutil.rmtree(self._path, ignore_errors=True)
        if self._manifest_path.exists():
            self._manifest_path.unlink(missing_ok=True)

    # ─── Search ─────────────────────────────────────────────────────────

    def search(
        self, query_vector: list[float], top_k: int, min_score: float = 0.0
    ) -> list[tuple[str, float]]:
        """Return top-k (source_text, similarity_score) pairs by cosine similarity.

        Results with similarity score below min_score are excluded.
        """
        if self._collection is None or not self._source_to_id:
            return []

        k = min(top_k, len(self._source_to_id))
        if k == 0:
            return []

        try:
            query = zvec.VectorQuery("embedding", vector=query_vector)
            results = self._collection.query(query, topk=k)
        except Exception:
            return []

        output = []
        for doc in results:
            source = doc.fields.get("source", "")
            # zvec returns cosine distance (0=identical), convert to similarity
            score = 1.0 - (doc.score if doc.score is not None else 1.0)
            if source and score >= min_score:
                output.append((source, score))

        return output
