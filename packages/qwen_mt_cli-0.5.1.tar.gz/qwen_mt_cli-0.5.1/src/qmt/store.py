"""Persistent storage for terms, translation memory, and domain prompt.

Data is stored at two levels:
  - Root project level: topmost .qmt/ found walking up from cwd
      - terms.csv, memory.csv, terms.zvec, memory.zvec (shared across subprojects)
  - Local project level: nearest .qmt/ found walking up from cwd
      - domain.md, batch_progress.json (per-subproject)
  - Global level:  ~/.qmt/  (user home directory)
      - domain.md

Project root discovery: walks up from cwd to find ALL .qmt/ directories,
uses the topmost one for shared data (terms/memory/vectors).
Domain resolution: local project > global > None
"""

import csv
import os
from functools import lru_cache
from pathlib import Path

from qmt.filelock import exclusive_lock, shared_lock

from qmt.constants import (
    CONFIG_FILENAME,
    DEFAULT_SMTP_PORT,
    ENV_API_KEY,
    NOTIFY_EMAIL_KEY,
    SMTP_HOST_KEY,
    SMTP_PASS_KEY,
    SMTP_PORT_KEY,
    SMTP_REQUIRED_KEYS,
    SMTP_USER_KEY,
)
from qmt.models import MemoryPair, TermPair


def _find_qmt_dir() -> Path:
    """Walk up from cwd to find the nearest .qmt/ directory.

    Returns the found .qmt/ path, or cwd/.qmt as default (for new projects).
    Used for local data: domain.md, batch_progress.json
    """
    current = Path.cwd().resolve()
    while True:
        candidate = current / ".qmt"
        if candidate.is_dir():
            return candidate
        parent = current.parent
        if parent == current:
            # Reached filesystem root, fall back to cwd
            break
        current = parent
    return Path.cwd() / ".qmt"


def _find_root_qmt_dir() -> Path:
    """Walk up from cwd to find the topmost (root) project .qmt/ directory.

    Finds the highest .qmt/ that contains terms.csv (indicating a project,
    not the global ~/.qmt config). If no parent has terms.csv, falls back
    to the nearest .qmt/.
    """
    current = Path.cwd().resolve()
    found: Path | None = None
    home_qmt = Path.home() / ".qmt"
    while True:
        candidate = current / ".qmt"
        if candidate.is_dir() and candidate.resolve() != home_qmt.resolve():
            # Only consider project .qmt dirs (not global ~/.qmt)
            if (candidate / "terms.csv").exists():
                found = candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    if found is not None:
        return found
    # No parent with terms.csv — fall back to nearest .qmt/
    return _find_qmt_dir()


@lru_cache(maxsize=1)
def _qmt_dir() -> Path:
    """Nearest .qmt/ — for local data (domain, batch_progress)."""
    return _find_qmt_dir()


@lru_cache(maxsize=1)
def _root_qmt_dir() -> Path:
    """Root (topmost) .qmt/ — for shared data (terms, memory, vectors)."""
    return _find_root_qmt_dir()


def _terms_file() -> Path:
    return _root_qmt_dir() / "terms.csv"


def _memory_file() -> Path:
    return _root_qmt_dir() / "memory.csv"


def terms_vec_path() -> Path:
    """Return path to terms vector index (zvec collection directory).

    Always stored in the root .qmt/ alongside terms.csv.
    """
    return _root_qmt_dir() / "terms.zvec"


def memory_vec_path() -> Path:
    """Return path to memory vector index (zvec collection directory).

    Always stored in the root .qmt/ alongside memory.csv.
    """
    return _root_qmt_dir() / "memory.zvec"


def _ensure_dir():
    _root_qmt_dir().mkdir(parents=True, exist_ok=True)


_csv_cache: dict[str, tuple[float, list[tuple[str, str]]]] = {}


def _read_csv(path: Path) -> list[tuple[str, str]]:
    if not path.exists():
        return []
    key = str(path)
    # Quick cache check before acquiring lock
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return []
    cached = _csv_cache.get(key)
    if cached and cached[0] == mtime:
        return cached[1]
    with shared_lock(path):
        # Re-read mtime under lock to avoid stale cache
        mtime = path.stat().st_mtime
        cached = _csv_cache.get(key)
        if cached and cached[0] == mtime:
            return cached[1]
        pairs = []
        with open(path, encoding="utf-8", newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) >= 2 and row[0].strip() and row[1].strip():
                    pairs.append((row[0].strip(), row[1].strip()))
    _csv_cache[key] = (mtime, pairs)
    return pairs


def _write_csv(path: Path, pairs: list[tuple[str, str]]):
    _ensure_dir()
    with exclusive_lock(path):
        with open(path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            for pair in pairs:
                writer.writerow(pair)
    _csv_cache[str(path)] = (path.stat().st_mtime, pairs)


# ---- Terms ----


def load_terms() -> list[TermPair]:
    return [TermPair(source=s, target=t) for s, t in _read_csv(_terms_file())]


def add_term(source: str, target: str) -> bool:
    """Add a term pair. Returns False if it already exists."""
    pairs = _read_csv(_terms_file())
    for s, t in pairs:
        if s == source and t == target:
            return False
    pairs.append((source, target))
    _write_csv(_terms_file(), pairs)
    return True


def remove_term(source: str) -> bool:
    """Remove term(s) by source word. Returns False if not found."""
    pairs = _read_csv(_terms_file())
    new_pairs = [(s, t) for s, t in pairs if s != source]
    if len(new_pairs) == len(pairs):
        return False
    _write_csv(_terms_file(), new_pairs)
    return True


def clear_terms():
    f = _terms_file()
    if f.exists():
        f.unlink()
    # Clean up vector index (zvec directory + manifest)
    import shutil
    vf = terms_vec_path()
    if vf.exists():
        shutil.rmtree(vf, ignore_errors=True)
    manifest = vf.with_suffix(vf.suffix + ".manifest")
    if manifest.exists():
        manifest.unlink(missing_ok=True)


def get_store_path() -> Path:
    """Return the root store directory path (shared terms/memory)."""
    return _root_qmt_dir()


# ---- Memory ----


def load_memory() -> list[MemoryPair]:
    return [MemoryPair(source=s, target=t) for s, t in _read_csv(_memory_file())]


def add_memory(source: str, target: str) -> bool:
    """Add a memory pair. Returns False if it already exists."""
    pairs = _read_csv(_memory_file())
    for s, t in pairs:
        if s == source and t == target:
            return False
    pairs.append((source, target))
    _write_csv(_memory_file(), pairs)
    return True


def remove_memory(source: str) -> bool:
    """Remove memory pair(s) by source text. Returns False if not found."""
    pairs = _read_csv(_memory_file())
    new_pairs = [(s, t) for s, t in pairs if s != source]
    if len(new_pairs) == len(pairs):
        return False
    _write_csv(_memory_file(), new_pairs)
    return True


def clear_memory():
    f = _memory_file()
    if f.exists():
        f.unlink()
    # Clean up vector index (zvec directory + manifest)
    import shutil
    vf = memory_vec_path()
    if vf.exists():
        shutil.rmtree(vf, ignore_errors=True)
    manifest = vf.with_suffix(vf.suffix + ".manifest")
    if manifest.exists():
        manifest.unlink(missing_ok=True)


def upsert_memory(source: str, target: str) -> None:
    """Add or update a memory pair. If source exists, overwrite target."""
    pairs = _read_csv(_memory_file())
    new_pairs = [(s, t) for s, t in pairs if s != source]
    new_pairs.append((source, target))
    _write_csv(_memory_file(), new_pairs)


# ---- Domain ----


def _global_qmt_dir() -> Path:
    return Path.home() / ".qmt"


def _global_domain_file() -> Path:
    return _global_qmt_dir() / "domain.md"


def _project_domain_file() -> Path:
    return _qmt_dir() / "domain.md"


def load_domain() -> str | None:
    """Load domain prompt. Project level takes priority over global."""
    for f in (_project_domain_file(), _global_domain_file()):
        if f.exists():
            content = f.read_text(encoding="utf-8").strip()
            if content:
                return content
    return None


def save_domain(text: str, global_: bool = False):
    """Save domain prompt to project or global level."""
    if global_:
        _global_qmt_dir().mkdir(parents=True, exist_ok=True)
        _global_domain_file().write_text(text, encoding="utf-8")
    else:
        _ensure_dir()
        _project_domain_file().write_text(text, encoding="utf-8")


def clear_domain(global_: bool = False):
    """Remove domain prompt file."""
    f = _global_domain_file() if global_ else _project_domain_file()
    if f.exists():
        f.unlink()


def domain_info() -> dict:
    """Return current domain configuration status."""
    result: dict = {"project": None, "global": None, "active": None, "active_source": None}
    pf = _project_domain_file()
    if pf.exists():
        content = pf.read_text(encoding="utf-8").strip()
        if content:
            result["project"] = content
    gf = _global_domain_file()
    if gf.exists():
        content = gf.read_text(encoding="utf-8").strip()
        if content:
            result["global"] = content
    if result["project"]:
        result["active"] = result["project"]
        result["active_source"] = "project"
    elif result["global"]:
        result["active"] = result["global"]
        result["active_source"] = "global"
    return result


# ---- Config ----


def _project_config_file() -> Path:
    return _root_qmt_dir() / CONFIG_FILENAME


def _global_config_file() -> Path:
    return _global_qmt_dir() / CONFIG_FILENAME


def _read_config(path: Path) -> dict[str, str]:
    """Read a key=value config file. Skips comments (#) and blank lines."""
    if not path.exists():
        return {}
    data: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            data[key.strip()] = value.strip()
    return data


def _write_config(path: Path, data: dict[str, str]) -> None:
    """Write key=value config file with restricted permissions."""
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# qmt config\n"]
    for key, value in data.items():
        lines.append(f"{key} = {value}\n")
    path.write_text("".join(lines), encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass  # Windows or restricted filesystem


def load_api_key() -> str | None:
    """Load API key from config files. Project level takes priority over global."""
    for path in (_project_config_file(), _global_config_file()):
        data = _read_config(path)
        key = data.get("api_key", "").strip()
        if key:
            return key
    return None


def save_api_key(key: str, global_: bool = False) -> Path:
    """Save API key to project or global config file. Returns the file path."""
    path = _global_config_file() if global_ else _project_config_file()
    data = _read_config(path)
    data["api_key"] = key
    _write_config(path, data)
    return path


def clear_config(global_: bool = False) -> bool:
    """Remove api_key from config file. Returns False if not found."""
    path = _global_config_file() if global_ else _project_config_file()
    data = _read_config(path)
    if "api_key" not in data:
        return False
    del data["api_key"]
    if data:
        _write_config(path, data)
    else:
        path.unlink(missing_ok=True)
    return True


def resolve_api_key(cli_value: str | None = None) -> str | None:
    """Resolve API key with priority: CLI param > env var > config file."""
    if cli_value:
        return cli_value
    env_key = os.environ.get(ENV_API_KEY)
    if env_key:
        return env_key
    return load_api_key()


def config_info() -> dict:
    """Return current config status (keys and sources)."""
    result: dict = {
        "project_path": None,
        "global_path": None,
        "project_key": None,
        "global_key": None,
        "active_source": None,
    }
    pf = _project_config_file()
    data = _read_config(pf)
    if data.get("api_key"):
        result["project_path"] = str(pf)
        result["project_key"] = data["api_key"]
    gf = _global_config_file()
    data = _read_config(gf)
    if data.get("api_key"):
        result["global_path"] = str(gf)
        result["global_key"] = data["api_key"]
    if result["project_key"]:
        result["active_source"] = "project"
    elif result["global_key"]:
        result["active_source"] = "global"
    return result


# ---- SMTP / Email Notification ----


def save_smtp_config(key: str, value: str, global_: bool = False) -> Path:
    """Save a single SMTP config key to project or global config file."""
    path = _global_config_file() if global_ else _project_config_file()
    data = _read_config(path)
    data[key] = value
    _write_config(path, data)
    return path


def load_smtp_config() -> dict[str, str]:
    """Load SMTP config. Project level takes priority over global per-key."""
    result: dict[str, str] = {}
    all_keys = (SMTP_HOST_KEY, SMTP_PORT_KEY, SMTP_USER_KEY, SMTP_PASS_KEY, NOTIFY_EMAIL_KEY)
    # Global as base
    gdata = _read_config(_global_config_file())
    for k in all_keys:
        if gdata.get(k):
            result[k] = gdata[k]
    # Project overrides
    pdata = _read_config(_project_config_file())
    for k in all_keys:
        if pdata.get(k):
            result[k] = pdata[k]
    # Default port if not set
    if not result.get(SMTP_PORT_KEY):
        result[SMTP_PORT_KEY] = DEFAULT_SMTP_PORT
    return result


def smtp_configured() -> bool:
    """Check if all required SMTP keys are present for email notification."""
    config = load_smtp_config()
    return all(config.get(k) for k in SMTP_REQUIRED_KEYS)


def clear_smtp_config(global_: bool = False) -> bool:
    """Remove all SMTP keys from config. Returns False if none were found."""
    path = _global_config_file() if global_ else _project_config_file()
    data = _read_config(path)
    all_keys = (SMTP_HOST_KEY, SMTP_PORT_KEY, SMTP_USER_KEY, SMTP_PASS_KEY, NOTIFY_EMAIL_KEY)
    removed = False
    for k in all_keys:
        if k in data:
            del data[k]
            removed = True
    if not removed:
        return False
    if data:
        _write_config(path, data)
    else:
        path.unlink(missing_ok=True)
    return True
