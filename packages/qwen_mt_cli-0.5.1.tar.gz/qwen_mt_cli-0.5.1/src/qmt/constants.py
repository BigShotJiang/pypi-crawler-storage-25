"""Constants for qmt CLI."""

API_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"

ENV_API_KEY = "DASHSCOPE_API_KEY"

DEFAULT_MODEL = "qwen-mt-plus"
DEFAULT_SOURCE = "auto"
DEFAULT_TARGET = "Chinese"

MODELS = {
    "qwen-mt-plus": {
        "description": "最高翻译质量，适用于专业领域",
        "streaming": False,
        "languages": 92,
    },
    "qwen-mt-flash": {
        "description": "通用首选，效果/速度/成本平衡",
        "streaming": True,
        "languages": 92,
    },
    "qwen-mt-lite": {
        "description": "最快响应速度，适用于实时场景",
        "streaming": True,
        "languages": 31,
    },
}

STREAMING_MODELS = {name for name, info in MODELS.items() if info["streaming"]}

MODEL_CHOICES = list(MODELS.keys())

# ─── Embedding / Vector Matching ────────────────────────────────────────────

EMBEDDING_MODEL = "text-embedding-v4"
EMBEDDING_DIM = 1024
EMBEDDING_BATCH_SIZE = 10  # DashScope API 单次请求上限
EMBEDDING_CONCURRENCY = 5  # 并发请求数（rebuild 时使用）
BATCH_CONCURRENCY = 5  # 批量翻译默认并发数
SMART_MATCH_THRESHOLD = 20  # 超过此数启用向量匹配
DEFAULT_TOP_K = 10
DEFAULT_MIN_SCORE = 0.35  # 语义匹配最低相似度，低于此分数的结果被过滤

# ─── Config ─────────────────────────────────────────────────────────────────

CONFIG_FILENAME = "config"

# ─── SMTP / Email Notification ──────────────────────────────────────────────

SMTP_HOST_KEY = "smtp_host"
SMTP_PORT_KEY = "smtp_port"
SMTP_USER_KEY = "smtp_user"
SMTP_PASS_KEY = "smtp_pass"
NOTIFY_EMAIL_KEY = "notify_email"
DEFAULT_SMTP_PORT = "465"
SMTP_REQUIRED_KEYS = (SMTP_HOST_KEY, SMTP_USER_KEY, SMTP_PASS_KEY, NOTIFY_EMAIL_KEY)
