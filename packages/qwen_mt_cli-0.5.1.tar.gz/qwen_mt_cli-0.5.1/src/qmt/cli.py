"""CLI entry point for qmt.

Usage:
  qmt "text" -t English              # translate text (default command)
  qmt -B input.csv -t English        # batch translate CSV
  qmt -B input.xlsx -O out.xlsx      # batch translate Excel
  qmt terms add "源词" "译词"         # add a term pair
  qmt terms list                     # list saved terms
  qmt memory add "源文" "译文"        # add translation memory
  qmt memory list                    # list saved memory
  qmt domain set "tech"              # set default domain prompt
  qmt domain show                    # show domain config
"""

import sys
from pathlib import Path

import click

from qmt import __version__
from qmt.client import QwenMTClient
from qmt.constants import (
    DEFAULT_MODEL,
    DEFAULT_SOURCE,
    DEFAULT_TARGET,
    DEFAULT_TOP_K,
    MODEL_CHOICES,
    SMART_MATCH_THRESHOLD,
    STREAMING_MODELS,
)
from qmt.exceptions import QMTError
from qmt.formatters import (
    console,
    create_spinner,
    print_error,
    print_info,
    print_stream_chunk,
    print_stream_end,
    print_success,
    print_translation,
    print_warning,
)
from qmt.models import TranslationRequest
from qmt.parsers import (
    parse_inline_terms,
    parse_memory_file,
    parse_terms_file,
    read_file_content,
    read_stdin,
)
from qmt import store


# ─── Main group ──────────────────────────────────────────────────────────────


class QMTGroup(click.Group):
    """Custom group that falls through to 'translate' when no subcommand matches."""

    def parse_args(self, ctx, args):
        # If first arg is not a known subcommand, treat it as translate
        if args and args[0] not in self.commands and not args[0].startswith("-"):
            args = ["translate"] + args
        # If no args at all, or first arg is an option flag, default to translate
        elif not args or (
            args[0].startswith("-") and args[0] not in ("--help", "-h", "--version", "-V")
        ):
            args = ["translate"] + args
        return super().parse_args(ctx, args)


@click.group(cls=QMTGroup, context_settings={"help_option_names": ["-h", "--help"]})
@click.version_option(version=__version__, prog_name="qmt")
def main():
    """Qwen-MT CLI - 基于通义千问的命令行翻译工具

    \b
    翻译:
      qmt "你好世界" -t English
      qmt "Hello" -t Chinese -m qwen-mt-plus
      qmt -f doc.txt -t English --stream
      echo "你好" | qmt -t English
      qmt -i -t English
    \b
    批量翻译 (CSV/Excel):
      qmt -B input.csv -t English            # 翻译 CSV，输出 input_translated.csv
      qmt -B input.csv -O out.csv -t English  # 指定输出文件
      qmt -B input.xlsx -t English            # 翻译 Excel 所有 sheet
      qmt -B input.csv -t English --no-header # 首行也翻译 (无表头)
      qmt -B input.csv -t English --resume    # 断点恢复
    \b
    领域提示:
      qmt domain set "technology"             # 设置项目级领域
      qmt domain set "medical" --global       # 设置全局领域
      qmt domain show                         # 查看领域配置
      qmt domain clear                        # 清除项目级领域
    \b
    术语管理:
      qmt terms add "React" "React"
      qmt terms list
      qmt terms remove "React"
      qmt terms clear
    \b
    翻译记忆:
      qmt memory add "你好世界" "Hello World"
      qmt memory list
      qmt memory remove "你好世界"
      qmt memory clear
    \b
    向量索引:
      qmt vectordb status                   # 查看索引状态
      qmt vectordb rebuild                  # 重建全部向量索引
      qmt vectordb query "文本"              # 测试语义匹配命中
      qmt vectordb clear                    # 清除向量索引
    \b
    配置管理:
      qmt config set --api-key <KEY>        # 保存 API Key (项目级)
      qmt config set --api-key <KEY> --global  # 保存到全局
      qmt config show                       # 查看配置状态
      qmt config clear                      # 清除项目级配置
    """


# ─── Translate command (default) ─────────────────────────────────────────────


@main.command(name="translate", hidden=True)
@click.argument("text", required=False)
@click.option("-t", "--target", default=DEFAULT_TARGET, show_default=True, help="目标语言")
@click.option(
    "-s", "--source", default=DEFAULT_SOURCE, show_default=True, help="源语言 (auto 自动检测)"
)
@click.option(
    "-m",
    "--model",
    type=click.Choice(MODEL_CHOICES, case_sensitive=False),
    default=DEFAULT_MODEL,
    show_default=True,
    help="翻译模型",
)
@click.option("--stream", is_flag=True, default=False, help="流式输出 (仅 flash/lite)")
@click.option("-d", "--domain", default=None, help="领域提示 (如 technology, medical)")
@click.option("--terms", "inline_terms", default=None, help="内联术语: '源词1:译词1,源词2:译词2'")
@click.option(
    "--terms-file",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="术语文件 (CSV/TSV)",
)
@click.option(
    "--memory-file",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="记忆文件 (CSV/TSV)",
)
@click.option(
    "-f",
    "--file",
    "input_file",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="待翻译文件",
)
@click.option("-i", "--interactive", is_flag=True, default=False, help="交互式 REPL 模式")
@click.option(
    "-B",
    "--batch",
    "batch_file",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="批量翻译输入文件 (CSV/Excel)",
)
@click.option(
    "-O",
    "--output",
    "output_file",
    type=click.Path(path_type=Path),
    default=None,
    help="批量翻译输出文件 (默认自动生成)",
)
@click.option("--no-header", is_flag=True, default=False, help="CSV/Excel 首行也翻译 (无表头)")
@click.option("--resume", is_flag=True, default=False, help="断点恢复: 从上次中断处继续")
@click.option("--top-k", type=int, default=None, help=f"语义匹配返回条目数 (默认 {DEFAULT_TOP_K})")
@click.option(
    "--threshold",
    type=int,
    default=None,
    help=f"语义匹配启用阈值 (默认 {SMART_MATCH_THRESHOLD}，术语/记忆超过此数启用)",
)
@click.option("--learn", is_flag=True, default=False, help="翻译结果自动写入翻译记忆")
@click.option("--api-key", default=None, help="API Key (或环境变量/配置文件)")
@click.option("-v", "--verbose", is_flag=True, default=False, help="显示详细信息")
@click.option("--no-store", is_flag=True, default=False, help="不加载本地术语/记忆库")
@click.option(
    "-C",
    "--concurrency",
    type=click.IntRange(1, 20),
    default=None,
    help="批量翻译并发数 (默认 5，范围 1-20)",
)
@click.pass_context
def translate_cmd(
    ctx,
    text,
    target,
    source,
    model,
    stream,
    domain,
    inline_terms,
    terms_file,
    memory_file,
    input_file,
    interactive,
    batch_file,
    output_file,
    no_header,
    resume,
    top_k,
    threshold,
    learn,
    api_key,
    verbose,
    no_store,
    concurrency,
):
    """翻译文本 (默认命令，可省略 translate)"""
    try:
        # Resolve API key
        resolved_api_key = store.resolve_api_key(api_key)
        if not resolved_api_key:
            from qmt.exceptions import APIKeyMissingError

            raise APIKeyMissingError()

        # Resolve domain: explicit -d > project domain.md > global domain.md
        from click.core import ParameterSource

        if ctx.get_parameter_source("domain") == ParameterSource.DEFAULT:
            if not no_store:
                loaded = store.load_domain()
                if loaded:
                    domain = loaded
                    if verbose:
                        info = store.domain_info()
                        src = "项目级" if info["active_source"] == "project" else "全局级"
                        print_info(f"已加载{src}领域提示")

        # Resolve smart-match parameters
        resolved_top_k = top_k if top_k is not None else DEFAULT_TOP_K
        resolved_threshold = threshold if threshold is not None else SMART_MATCH_THRESHOLD

        # Collect terms: separate store (subject to vector filtering) vs extra (always pass)
        store_terms = [] if no_store else store.load_terms()
        extra_terms: list = []
        if inline_terms:
            extra_terms.extend(parse_inline_terms(inline_terms))
        if terms_file:
            extra_terms.extend(parse_terms_file(terms_file))

        # Collect memory: separate store vs extra
        store_memory = [] if no_store else store.load_memory()
        extra_memory: list = []
        if memory_file:
            extra_memory.extend(parse_memory_file(memory_file))

        # Show what's loaded in verbose mode
        total_terms = len(store_terms) + len(extra_terms)
        total_memory = len(store_memory) + len(extra_memory)
        if verbose and (total_terms or total_memory):
            if total_terms:
                print_info(f"已加载 {total_terms} 条术语")
            if total_memory:
                print_info(f"已加载 {total_memory} 条翻译记忆")

        # Create client
        client = QwenMTClient(api_key=resolved_api_key)

        # Check vector index consistency before batch (non-blocking, verbose only)
        if batch_file and not no_store:
            from qmt.matcher import check_index_consistency

            check_index_consistency(verbose=verbose)

        # Batch mode
        if batch_file:
            _handle_batch(
                client=client,
                batch_file=batch_file,
                output_file=output_file,
                source=source,
                target=target,
                model=model,
                domain=domain,
                store_terms=store_terms,
                extra_terms=extra_terms,
                store_memory=store_memory,
                extra_memory=extra_memory,
                has_header=not no_header,
                resume=resume,
                api_key=resolved_api_key,
                top_k=resolved_top_k,
                threshold=resolved_threshold,
                learn=learn,
                verbose=verbose,
                concurrency=concurrency,
            )
            return

        # Interactive mode
        if interactive:
            from qmt.interactive import run_interactive

            run_interactive(
                client=client,
                target_lang=target,
                source_lang=source,
                model=model,
                stream=stream,
                domain=domain,
                store_terms=store_terms,
                extra_terms=extra_terms,
                store_memory=store_memory,
                extra_memory=extra_memory,
                api_key=resolved_api_key,
                top_k=resolved_top_k,
                threshold=resolved_threshold,
                learn=learn,
            )
            return

        # Resolve input text
        resolved_text = text
        if not resolved_text and input_file:
            resolved_text = read_file_content(input_file)
        if not resolved_text:
            resolved_text = read_stdin()
        if not resolved_text:
            click.echo(main.get_help(click.Context(main)))
            sys.exit(1)

        # Smart-match: filter terms/memory by semantic relevance
        from qmt.matcher import select_relevant_memory, select_relevant_terms

        filtered_terms = extra_terms[:]
        try:
            matched_terms = select_relevant_terms(
                query_text=resolved_text,
                store_terms=store_terms,
                api_key=resolved_api_key,
                top_k=resolved_top_k,
                threshold=resolved_threshold,
                verbose=verbose,
            )
            filtered_terms.extend(matched_terms)
        except Exception:
            # Fallback: if too many terms, truncate to avoid API overload
            if len(store_terms) > resolved_threshold:
                filtered_terms.extend(store_terms[:resolved_top_k])
                if verbose:
                    print_warning(
                        f"术语语义匹配失败，截取前 {resolved_top_k} 条术语"
                    )
            else:
                filtered_terms.extend(store_terms)
                if verbose:
                    print_warning("术语语义匹配失败，使用全部术语")

        filtered_memory = extra_memory[:]
        try:
            matched_memory = select_relevant_memory(
                query_text=resolved_text,
                store_memory=store_memory,
                api_key=resolved_api_key,
                top_k=resolved_top_k,
                threshold=resolved_threshold,
                verbose=verbose,
            )
            filtered_memory.extend(matched_memory)
        except Exception:
            if len(store_memory) > resolved_threshold:
                filtered_memory.extend(store_memory[:resolved_top_k])
                if verbose:
                    print_warning(
                        f"翻译记忆语义匹配失败，截取前 {resolved_top_k} 条记忆"
                    )
            else:
                filtered_memory.extend(store_memory)
                if verbose:
                    print_warning("翻译记忆语义匹配失败，使用全部翻译记忆")

        # Build request
        request = TranslationRequest(
            text=resolved_text,
            source_lang=source,
            target_lang=target,
            model=model,
            stream=stream,
            domain=domain,
            terms=filtered_terms,
            tm_list=filtered_memory,
        )

        # Execute
        if stream:
            if model not in STREAMING_MODELS:
                print_warning(f"模型 {model} 不支持流式输出，回退到非流式模式")
                result_text = _translate_sync(client, request, verbose)
            else:
                result_text = _translate_stream(client, request)
        else:
            result_text = _translate_sync(client, request, verbose)

        # Learn: write translation result to memory
        if learn and result_text:
            try:
                from qmt.matcher import learn_memory

                learn_memory(resolved_text, result_text, resolved_api_key)
                if verbose:
                    print_info("已将翻译结果写入翻译记忆")
            except Exception:
                if verbose:
                    print_warning("翻译记忆回写失败")

    except QMTError as e:
        print_error(str(e))
        sys.exit(1)
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        print_error(f"未知错误: {e}")
        sys.exit(2)


def _translate_sync(client, request, verbose):
    with create_spinner():
        result = client.translate(request)
    print_translation(
        result,
        verbose=verbose,
        model=request.model,
        source=request.source_lang,
        target=request.target_lang,
    )
    return result


def _translate_stream(client, request):
    chunks = []
    for chunk in client.translate_stream(request):
        print_stream_chunk(chunk)
        chunks.append(chunk)
    print_stream_end()
    return "".join(chunks)


_BATCH_EXTENSIONS_CSV = {".csv", ".tsv"}
_BATCH_EXTENSIONS_EXCEL = {".xlsx", ".xls"}


def _auto_output_path(input_path: Path, output_ext: str | None = None) -> Path:
    """Generate default output path: input_translated.ext"""
    ext = output_ext or input_path.suffix
    return input_path.with_name(f"{input_path.stem}_translated{ext}")


def _handle_batch(
    client,
    batch_file,
    output_file,
    source,
    target,
    model,
    domain,
    store_terms,
    extra_terms,
    store_memory,
    extra_memory,
    has_header,
    resume,
    api_key,
    top_k,
    threshold,
    learn,
    verbose,
    concurrency=None,
):
    """Route batch translation to CSV or Excel handler."""
    import time as _time

    from qmt.batch import translate_csv, translate_excel
    from qmt.formatters import print_batch_summary

    input_path = Path(batch_file)
    ext = input_path.suffix.lower()

    from qmt.constants import BATCH_CONCURRENCY

    resolved_concurrency = concurrency if concurrency is not None else BATCH_CONCURRENCY

    batch_kwargs = dict(
        client=client,
        input_path=input_path,
        source_lang=source,
        target_lang=target,
        model=model,
        domain=domain,
        store_terms=store_terms,
        extra_terms=extra_terms,
        store_memory=store_memory,
        extra_memory=extra_memory,
        has_header=has_header,
        resume=resume,
        api_key=api_key,
        top_k=top_k,
        threshold=threshold,
        learn=learn,
        verbose=verbose,
        concurrency=resolved_concurrency,
    )

    start_time = _time.time()
    result = None

    if ext in _BATCH_EXTENSIONS_CSV:
        out = Path(output_file) if output_file else _auto_output_path(input_path)
        result = translate_csv(output_path=out, **batch_kwargs)
        print_batch_summary(result)
    elif ext in _BATCH_EXTENSIONS_EXCEL:
        out = Path(output_file) if output_file else _auto_output_path(input_path)
        result = translate_excel(output_path=out, **batch_kwargs)
        print_batch_summary(result)
    else:
        print_error(f"不支持的批量文件格式: {ext}\n  支持: .csv, .tsv, .xlsx, .xls")
        sys.exit(1)

    # Email notification (best-effort)
    if result is not None:
        elapsed = _time.time() - start_time
        from qmt.notify import try_send_batch_notification

        try_send_batch_notification(
            result=result,
            metadata={
                "input_file": input_path.name,
                "target_lang": target,
                "elapsed_seconds": elapsed,
            },
        )


# ─── Terms subcommand group ─────────────────────────────────────────────────


def _sync_term_to_vector(source: str) -> None:
    """Embed and upsert a single term into the vector index (best-effort)."""
    api_key = store.resolve_api_key()
    if not api_key:
        return
    vec_path = store.terms_vec_path()
    if not vec_path.exists():
        return  # 索引未构建，跳过
    try:
        from qmt.embedding import get_embeddings
        from qmt.vectorstore import VectorIndex

        embeddings = get_embeddings(api_key, [source])
        index = VectorIndex(vec_path)
        index.load()
        index.upsert_entry(source, embeddings[0])
        index.save()
    except Exception:
        pass  # 非致命：CSV 已写入，向量同步可后续 rebuild


@main.group()
def terms():
    """管理固定术语表 (保存在当前目录 .qmt/terms.csv)"""


@terms.command(name="add")
@click.argument("source")
@click.argument("target")
def terms_add(source, target):
    """添加术语对: qmt terms add "源词" "译词" """
    if store.add_term(source, target):
        print_success(f"已添加术语: {source} -> {target}")
        _sync_term_to_vector(source)
    else:
        print_warning(f"术语已存在: {source} -> {target}")


@terms.command(name="list")
def terms_list():
    """列出所有已保存的术语"""
    pairs = store.load_terms()
    if not pairs:
        print_info('暂无术语。使用 qmt terms add "源词" "译词" 添加')
        return
    console.print(f"[bold]共 {len(pairs)} 条术语:[/bold]")
    for p in pairs:
        console.print(f"  {p.source} -> {p.target}")


@terms.command(name="remove")
@click.argument("source")
def terms_remove(source):
    """删除术语: qmt terms remove "源词" """
    if store.remove_term(source):
        print_success(f"已删除术语: {source}")
    else:
        print_error(f"未找到术语: {source}")


@terms.command(name="clear")
@click.confirmation_option(prompt="确定要清空所有术语吗?")
def terms_clear():
    """清空所有术语"""
    store.clear_terms()
    print_success("术语表已清空")


@terms.command(name="import")
@click.argument("file_path", type=click.Path(exists=True, path_type=Path))
def terms_import(file_path):
    """从 CSV/TSV 文件批量导入术语"""
    imported = parse_terms_file(file_path)
    count = 0
    for t in imported:
        if store.add_term(t.source, t.target):
            count += 1
    print_success(f"导入完成: 新增 {count} 条，跳过 {len(imported) - count} 条重复")


# ─── Memory subcommand group ────────────────────────────────────────────────


@main.group()
def memory():
    """管理翻译记忆库 (保存在当前目录 .qmt/memory.csv)"""


@memory.command(name="add")
@click.argument("source")
@click.argument("target")
def memory_add(source, target):
    """添加翻译记忆: qmt memory add "源文" "译文" """
    if store.add_memory(source, target):
        print_success(f"已添加记忆: {source} -> {target}")
    else:
        print_warning(f"记忆已存在: {source} -> {target}")


@memory.command(name="list")
def memory_list():
    """列出所有已保存的翻译记忆"""
    pairs = store.load_memory()
    if not pairs:
        print_info('暂无翻译记忆。使用 qmt memory add "源文" "译文" 添加')
        return
    console.print(f"[bold]共 {len(pairs)} 条翻译记忆:[/bold]")
    for p in pairs:
        console.print(f"  {p.source} -> {p.target}")


@memory.command(name="remove")
@click.argument("source")
def memory_remove(source):
    """删除翻译记忆: qmt memory remove "源文" """
    if store.remove_memory(source):
        print_success(f"已删除记忆: {source}")
    else:
        print_error(f"未找到记忆: {source}")


@memory.command(name="clear")
@click.confirmation_option(prompt="确定要清空所有翻译记忆吗?")
def memory_clear():
    """清空所有翻译记忆"""
    store.clear_memory()
    print_success("翻译记忆已清空")


@memory.command(name="import")
@click.argument("file_path", type=click.Path(exists=True, path_type=Path))
def memory_import(file_path):
    """从 CSV/TSV 文件批量导入翻译记忆"""
    imported = parse_memory_file(file_path)
    count = 0
    for m in imported:
        if store.add_memory(m.source, m.target):
            count += 1
    print_success(f"导入完成: 新增 {count} 条，跳过 {len(imported) - count} 条重复")


# ─── Domain subcommand group ────────────────────────────────────────────────


@main.group()
def domain():
    """管理默认领域提示 (保存在 .qmt/domain.md 或 ~/.qmt/domain.md)"""


@domain.command(name="set")
@click.argument("text", required=False)
@click.option("--global", "global_", is_flag=True, default=False, help="保存到全局 (~/.qmt/)")
def domain_set(text, global_):
    """设置领域提示: qmt domain set "technology" [--global]"""
    if not text:
        if sys.stdin.isatty():
            print_error('用法: qmt domain set "领域文本" 或通过管道输入')
            sys.exit(1)
        text = sys.stdin.read().strip()
    if not text:
        print_error("领域提示不能为空")
        sys.exit(1)
    store.save_domain(text, global_=global_)
    level = "全局" if global_ else "项目"
    print_success(f"已保存{level}领域提示")


@domain.command(name="show")
def domain_show():
    """显示当前领域配置"""
    info = store.domain_info()
    if not info["project"] and not info["global"]:
        print_info('未设置领域提示。使用 qmt domain set "领域" 设置')
        return
    if info["project"]:
        console.print("[bold]项目级[/bold] (.qmt/domain.md):")
        console.print(f"  {info['project']}")
    if info["global"]:
        console.print("[bold]全局级[/bold] (~/.qmt/domain.md):")
        console.print(f"  {info['global']}")
    if info["active"]:
        source_label = "项目级" if info["active_source"] == "project" else "全局级"
        console.print(f"\n[dim]当前生效: {source_label}[/dim]")


@domain.command(name="clear")
@click.option("--global", "global_", is_flag=True, default=False, help="清除全局领域")
def domain_clear(global_):
    """清除领域提示: qmt domain clear [--global]"""
    store.clear_domain(global_=global_)
    level = "全局" if global_ else "项目"
    print_success(f"已清除{level}领域提示")


# ─── Config subcommand group ────────────────────────────────────────────────


@main.group()
def config():
    """管理配置 (API Key 等，保存在 .qmt/config 或 ~/.qmt/config)"""


@config.command(name="set")
@click.option("--api-key", default=None, help="DashScope API Key")
@click.option("--smtp-host", default=None, help="SMTP 服务器地址")
@click.option("--smtp-port", default=None, help="SMTP 端口 (默认 465)")
@click.option("--smtp-user", default=None, help="SMTP 用户名/邮箱")
@click.option("--smtp-pass", default=None, help="SMTP 密码/应用密码")
@click.option("--notify-email", default=None, help="通知接收邮箱")
@click.option("--global", "global_", is_flag=True, default=False, help="保存到全局 (~/.qmt/)")
def config_set(api_key, smtp_host, smtp_port, smtp_user, smtp_pass, notify_email, global_):
    """保存配置项: qmt config set --api-key <KEY> [--smtp-host ...] [--global]"""
    from qmt.constants import (
        NOTIFY_EMAIL_KEY,
        SMTP_HOST_KEY,
        SMTP_PASS_KEY,
        SMTP_PORT_KEY,
        SMTP_USER_KEY,
    )

    has_any = False
    level = "全局" if global_ else "项目"

    if api_key:
        store.save_api_key(api_key, global_=global_)
        masked = api_key[:4] + "****" + api_key[-4:] if len(api_key) > 8 else "****"
        print_success(f"已保存{level} API Key: {masked}")
        has_any = True

    smtp_options = [
        (smtp_host, SMTP_HOST_KEY, "smtp_host"),
        (smtp_port, SMTP_PORT_KEY, "smtp_port"),
        (smtp_user, SMTP_USER_KEY, "smtp_user"),
        (smtp_pass, SMTP_PASS_KEY, "smtp_pass"),
        (notify_email, NOTIFY_EMAIL_KEY, "notify_email"),
    ]
    for value, key, display_name in smtp_options:
        if value:
            store.save_smtp_config(key, value, global_=global_)
            display_val = "****" if "pass" in display_name else value
            print_success(f"已保存{level} {display_name}: {display_val}")
            has_any = True

    if not has_any:
        print_error("请至少提供一个配置项 (--api-key, --smtp-host, --notify-email 等)")
        sys.exit(1)

    # Warn about .gitignore
    if not global_:
        gitignore = Path.cwd() / ".gitignore"
        needs_warning = True
        if gitignore.exists():
            content = gitignore.read_text(encoding="utf-8", errors="ignore")
            if ".qmt/config" in content or ".qmt/" in content or ".qmt" in content:
                needs_warning = False
        if needs_warning:
            print_warning("建议将 .qmt/config 添加到 .gitignore 以避免泄露密钥")


@config.command(name="show")
def config_show():
    """显示当前配置状态"""
    info = store.config_info()
    has_content = False

    if info["project_key"] or info["global_key"]:
        has_content = True
        if info["project_key"]:
            key = info["project_key"]
            masked = key[:4] + "****" + key[-4:] if len(key) > 8 else "****"
            console.print("[bold]API Key[/bold] (项目级):")
            console.print(f"  api_key = {masked}")
        if info["global_key"]:
            key = info["global_key"]
            masked = key[:4] + "****" + key[-4:] if len(key) > 8 else "****"
            console.print("[bold]API Key[/bold] (全局级):")
            console.print(f"  api_key = {masked}")

    # SMTP config
    smtp = store.load_smtp_config()
    from qmt.constants import DEFAULT_SMTP_PORT, SMTP_REQUIRED_KEYS

    has_smtp = any(
        v for k, v in smtp.items() if v and v != DEFAULT_SMTP_PORT
    )
    if has_smtp:
        has_content = True
        console.print("\n[bold]邮件通知配置:[/bold]")
        console.print(f"  smtp_host    = {smtp.get('smtp_host') or '(未设置)'}")
        console.print(f"  smtp_port    = {smtp.get('smtp_port', '465')}")
        console.print(f"  smtp_user    = {smtp.get('smtp_user') or '(未设置)'}")
        pwd = smtp.get("smtp_pass", "")
        masked_pwd = pwd[:2] + "****" + pwd[-2:] if len(pwd) > 4 else "****" if pwd else "(未设置)"
        console.print(f"  smtp_pass    = {masked_pwd}")
        console.print(f"  notify_email = {smtp.get('notify_email') or '(未设置)'}")
        if store.smtp_configured():
            console.print("  [green]状态: 已配置 (批量翻译后自动发送通知)[/green]")
        else:
            missing = [k for k in SMTP_REQUIRED_KEYS if not smtp.get(k)]
            console.print(f"  [yellow]状态: 缺少 {', '.join(missing)}[/yellow]")

    if not has_content:
        print_info(
            "未配置。使用 qmt config set --api-key <KEY> 或 --smtp-host 等设置"
        )


@config.command(name="clear")
@click.option("--global", "global_", is_flag=True, default=False, help="清除全局配置")
@click.option("--smtp", is_flag=True, default=False, help="清除 SMTP 邮件通知配置")
def config_clear(global_, smtp):
    """清除配置: qmt config clear [--smtp] [--global]"""
    level = "全局" if global_ else "项目"
    if smtp:
        if store.clear_smtp_config(global_=global_):
            print_success(f"已清除{level} SMTP 邮件通知配置")
        else:
            print_info(f"{level}配置中未找到 SMTP 配置")
    else:
        if store.clear_config(global_=global_):
            print_success(f"已清除{level} API Key 配置")
        else:
            print_info(f"{level}配置中未找到 API Key")


# ─── Vectordb subcommand group ──────────────────────────────────────────────


@main.group()
def vectordb():
    """管理向量索引 (语义搜索加速)"""


@vectordb.command(name="rebuild")
@click.option("--api-key", default=None, help="API Key (或环境变量/配置文件)")
def vectordb_rebuild(api_key):
    """从 CSV 重建全部向量索引 (术语 + 翻译记忆)"""
    resolved_key = store.resolve_api_key(api_key)
    if not resolved_key:
        print_error("需要 API Key。请设置 DASHSCOPE_API_KEY 或通过 --api-key / qmt config set 传入")
        sys.exit(1)

    from qmt.embedding import get_embeddings_concurrent
    from qmt.vectorstore import VectorIndex

    # Rebuild terms
    terms = store.load_terms()
    if terms:
        console.print(f"[bold]构建术语向量索引...[/bold] ({len(terms)} 条)")
        vec_path = store.terms_vec_path()
        index = VectorIndex(vec_path)
        index.load()
        index.clear()
        index = VectorIndex(vec_path)
        index.load()

        sources = list(dict.fromkeys(t.source for t in terms))  # dedupe, preserve order
        total = len(sources)

        with console.status(
            f"[bold cyan]嵌入术语中... 0/{total} (5路并发)[/bold cyan]", spinner="dots"
        ) as status:

            def _on_progress(done, _total):
                status.update(
                    f"[bold cyan]嵌入术语中... {done}/{_total} (5路并发)[/bold cyan]"
                )

            try:
                vectors = get_embeddings_concurrent(
                    resolved_key, sources, on_progress=_on_progress
                )
            except Exception as e:
                print_error(f"嵌入失败: {e}")
                sys.exit(1)

        index.add_entries(list(zip(sources, vectors)))
        index.save()
        print_success(f"术语索引已构建: {total} 条")
    else:
        print_info("暂无术语")

    # Rebuild memory
    memory = store.load_memory()
    if memory:
        console.print(f"[bold]构建翻译记忆向量索引...[/bold] ({len(memory)} 条)")
        vec_path = store.memory_vec_path()
        index = VectorIndex(vec_path)
        index.load()
        index.clear()
        index = VectorIndex(vec_path)
        index.load()

        sources = list(dict.fromkeys(m.source for m in memory))
        total = len(sources)

        with console.status(
            f"[bold cyan]嵌入记忆中... 0/{total} (5路并发)[/bold cyan]", spinner="dots"
        ) as status:

            def _on_progress(done, _total):
                status.update(
                    f"[bold cyan]嵌入记忆中... {done}/{_total} (5路并发)[/bold cyan]"
                )

            try:
                vectors = get_embeddings_concurrent(
                    resolved_key, sources, on_progress=_on_progress
                )
            except Exception as e:
                print_error(f"嵌入失败: {e}")
                sys.exit(1)

        index.add_entries(list(zip(sources, vectors)))
        index.save()
        print_success(f"翻译记忆索引已构建: {total} 条")
    else:
        print_info("暂无翻译记忆")


@vectordb.command(name="status")
def vectordb_status():
    """查看向量索引状态"""
    from qmt.vectorstore import VectorIndex

    terms = store.load_terms()
    memory = store.load_memory()

    terms_vec = store.terms_vec_path()
    memory_vec = store.memory_vec_path()

    console.print("[bold]向量索引状态:[/bold]")

    # Terms
    if terms_vec.exists():
        idx = VectorIndex(terms_vec, read_only=True)
        idx.load()
        indexed = len(idx.sources())
        total = len(terms)
        synced = "✓ 已同步" if indexed == total else f"⚠ 不同步 ({indexed}/{total})"
        console.print(f"  术语: {indexed} 条已索引 (CSV: {total} 条) {synced}")
    else:
        console.print(f"  术语: 未构建 (CSV: {len(terms)} 条)")

    # Memory
    if memory_vec.exists():
        idx = VectorIndex(memory_vec, read_only=True)
        idx.load()
        indexed = len(idx.sources())
        total = len(memory)
        synced = "✓ 已同步" if indexed == total else f"⚠ 不同步 ({indexed}/{total})"
        console.print(f"  记忆: {indexed} 条已索引 (CSV: {total} 条) {synced}")
    else:
        console.print(f"  记忆: 未构建 (CSV: {len(memory)} 条)")

    console.print(f"\n  存储: {store.get_store_path()}")


@vectordb.command(name="clear")
@click.confirmation_option(prompt="确定要清除所有向量索引吗?")
def vectordb_clear():
    """清除所有向量索引 (不影响 CSV 数据)"""
    import shutil

    for vec_path in (store.terms_vec_path(), store.memory_vec_path()):
        if vec_path.exists():
            shutil.rmtree(vec_path, ignore_errors=True)
        manifest = vec_path.with_suffix(vec_path.suffix + ".manifest")
        if manifest.exists():
            manifest.unlink(missing_ok=True)

    print_success("向量索引已清除")


@vectordb.command(name="query")
@click.argument("query_text")
@click.option(
    "--type",
    "query_type",
    type=click.Choice(["terms", "memory", "both"]),
    default="both",
    help="查询类型 (默认 both)",
)
@click.option("--top-k", default=10, help="返回条数 (默认 10)")
@click.option("--api-key", default=None, help="API Key (或环境变量/配置文件)")
def vectordb_query(query_text, query_type, top_k, api_key):
    """测试向量语义匹配 — 查看文本会命中哪些术语/记忆"""
    from rich.table import Table

    from qmt.embedding import get_embeddings
    from qmt.vectorstore import VectorIndex

    resolved_key = store.resolve_api_key(api_key)
    if not resolved_key:
        print_error("需要 API Key。请设置 DASHSCOPE_API_KEY 或通过 --api-key / qmt config set 传入")
        sys.exit(1)

    # Embed query text once
    try:
        query_embedding = get_embeddings(resolved_key, [query_text])[0]
    except Exception as e:
        print_error(f"嵌入查询文本失败: {e}")
        sys.exit(1)

    def _query_index(vec_path, items, label):
        """Query a vector index and display results as a table."""
        if not vec_path.exists():
            print_info(f"{label}: 索引未构建，请先执行 qmt vectordb rebuild")
            return
        if not items:
            print_info(f"{label}: 无数据")
            return

        index = VectorIndex(vec_path, read_only=True)
        index.load()

        if index.is_empty():
            print_info(f"{label}: 索引为空，请先执行 qmt vectordb rebuild")
            return

        results = index.search(query_embedding, top_k)
        if not results:
            print_info(f"{label}: 无匹配结果")
            return

        # Build source -> target lookup
        target_map = {item.source: item.target for item in items}

        table = Table(title=f"{label} (Top {len(results)} / 共 {len(items)} 条)")
        table.add_column("#", style="dim", width=4)
        table.add_column("源词", style="cyan")
        table.add_column("译词", style="green")
        table.add_column("相似度", style="yellow", justify="right")

        for i, (source, score) in enumerate(results, 1):
            target = target_map.get(source, "—")
            table.add_row(str(i), source, target, f"{score:.4f}")

        console.print(table)

    if query_type in ("terms", "both"):
        terms = store.load_terms()
        _query_index(store.terms_vec_path(), terms, "术语")

    if query_type in ("memory", "both"):
        memory = store.load_memory()
        _query_index(store.memory_vec_path(), memory, "翻译记忆")


if __name__ == "__main__":
    main()
