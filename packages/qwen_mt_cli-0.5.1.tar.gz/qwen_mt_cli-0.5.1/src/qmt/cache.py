"""Translation result cache using SQLite for persistence.

Cache key: (text, source_lang, target_lang, model, domain, terms_hash, memory_hash)
This ensures cache hits only when all translation parameters match exactly.
"""

import hashlib
import json
import sqlite3
from pathlib import Path


def _cache_db_path() -> Path:
    """Return path to the cache database (alongside store data)."""
    from qmt.store import _root_qmt_dir

    return _root_qmt_dir() / "cache.db"


def _hash_list(items: list) -> str:
    """Create a short hash of a sorted list of term/memory pairs."""
    if not items:
        return ""
    serialized = json.dumps(
        [(getattr(i, "source", ""), getattr(i, "target", "")) for i in items],
        ensure_ascii=False,
        sort_keys=True,
    )
    return hashlib.md5(serialized.encode()).hexdigest()[:12]


class TranslationCache:
    """SQLite-backed translation cache."""

    def __init__(self):
        self._conn: sqlite3.Connection | None = None

    def _ensure_db(self) -> sqlite3.Connection:
        if self._conn is not None:
            return self._conn
        db_path = _cache_db_path()
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path), timeout=5)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS translations (
                cache_key TEXT PRIMARY KEY,
                result TEXT NOT NULL,
                created_at REAL DEFAULT (julianday('now'))
            )
        """)
        self._conn.commit()
        return self._conn

    def _make_key(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        model: str,
        domain: str | None,
        terms_hash: str,
        memory_hash: str,
    ) -> str:
        raw = f"{text}|{source_lang}|{target_lang}|{model}|{domain or ''}|{terms_hash}|{memory_hash}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def get(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        model: str,
        domain: str | None = None,
        terms_hash: str = "",
        memory_hash: str = "",
    ) -> str | None:
        """Look up cached translation. Returns None on miss."""
        conn = self._ensure_db()
        key = self._make_key(text, source_lang, target_lang, model, domain, terms_hash, memory_hash)
        row = conn.execute(
            "SELECT result FROM translations WHERE cache_key = ?", (key,)
        ).fetchone()
        return row[0] if row else None

    def put(
        self,
        text: str,
        source_lang: str,
        target_lang: str,
        model: str,
        result: str,
        domain: str | None = None,
        terms_hash: str = "",
        memory_hash: str = "",
    ) -> None:
        """Store translation result in cache."""
        conn = self._ensure_db()
        key = self._make_key(text, source_lang, target_lang, model, domain, terms_hash, memory_hash)
        conn.execute(
            "INSERT OR REPLACE INTO translations (cache_key, result) VALUES (?, ?)",
            (key, result),
        )
        conn.commit()

    def put_many(self, entries: list[tuple[str, str, str, str, str, str | None, str, str]]) -> None:
        """Batch insert: list of (text, source_lang, target_lang, model, result, domain, terms_hash, memory_hash)."""
        if not entries:
            return
        conn = self._ensure_db()
        rows = []
        for text, source_lang, target_lang, model, result, domain, terms_hash, memory_hash in entries:
            key = self._make_key(text, source_lang, target_lang, model, domain, terms_hash, memory_hash)
            rows.append((key, result))
        conn.executemany(
            "INSERT OR REPLACE INTO translations (cache_key, result) VALUES (?, ?)",
            rows,
        )
        conn.commit()

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None


# Module-level singleton
_cache: TranslationCache | None = None


def get_cache() -> TranslationCache:
    global _cache
    if _cache is None:
        _cache = TranslationCache()
    return _cache
