"""Semantic matching orchestration: sync, threshold, Top-K selection, learn."""

from __future__ import annotations

from pathlib import Path

from qmt.constants import (
    DEFAULT_MIN_SCORE,
    DEFAULT_TOP_K,
    EMBEDDING_MODEL,
    SMART_MATCH_THRESHOLD,
)
from qmt.embedding import get_embeddings
from qmt.exceptions import EmbeddingError
from qmt.formatters import print_info
from qmt.models import MemoryPair, TermPair
from qmt.vectorstore import VectorIndex

# Module-level caches to avoid reloading from disk within a process
# Single cache per type (read-write mode for sync/learn capability)
# Read-only mode is only used by CLI commands (status/query) in separate processes
_terms_index_cache: VectorIndex | None = None
_memory_index_cache: VectorIndex | None = None


# ─── Public API ─────────────────────────────────────────────────────────────


def select_relevant_terms(
    query_text: str,
    store_terms: list[TermPair],
    api_key: str,
    top_k: int = DEFAULT_TOP_K,
    threshold: int = SMART_MATCH_THRESHOLD,
    query_embedding: list[float] | None = None,
    verbose: bool = False,
) -> list[TermPair]:
    """Select the most relevant terms for query_text via vector similarity.

    If len(store_terms) <= threshold, returns all (no vector work).
    """
    if len(store_terms) <= threshold:
        return store_terms

    from qmt import store

    return _select_relevant(
        query_text=query_text,
        items=store_terms,
        source_fn=lambda t: t.source,
        vec_path=store.terms_vec_path(),
        api_key=api_key,
        top_k=top_k,
        query_embedding=query_embedding,
        cache_key="terms",
        verbose=verbose,
    )


def select_relevant_memory(
    query_text: str,
    store_memory: list[MemoryPair],
    api_key: str,
    top_k: int = DEFAULT_TOP_K,
    threshold: int = SMART_MATCH_THRESHOLD,
    query_embedding: list[float] | None = None,
    verbose: bool = False,
) -> list[MemoryPair]:
    """Select the most relevant memory pairs for query_text via vector similarity."""
    if len(store_memory) <= threshold:
        return store_memory

    from qmt import store

    return _select_relevant(
        query_text=query_text,
        items=store_memory,
        source_fn=lambda m: m.source,
        vec_path=store.memory_vec_path(),
        api_key=api_key,
        top_k=top_k,
        query_embedding=query_embedding,
        cache_key="memory",
        verbose=verbose,
    )


def check_index_consistency(verbose: bool = False) -> dict[str, int]:
    """Check if vector indices are consistent with CSV data.

    Returns a dict with counts of missing entries per index type.
    Does NOT call any embedding API — just compares CSV sources vs indexed sources.
    """
    from qmt import store
    from qmt.formatters import print_warning

    result = {"terms_missing": 0, "memory_missing": 0}

    terms = store.load_terms()
    terms_vec = store.terms_vec_path()
    if terms and terms_vec.exists():
        idx = VectorIndex(terms_vec, read_only=True)
        idx.load()
        indexed = idx.sources()
        csv_sources = {t.source for t in terms}
        missing = csv_sources - indexed
        result["terms_missing"] = len(missing)
        if missing and verbose:
            print_warning(
                f"术语索引不一致: {len(missing)} 条术语未被索引，"
                f"建议运行 qmt vectordb rebuild"
            )

    memory = store.load_memory()
    memory_vec = store.memory_vec_path()
    if memory and memory_vec.exists():
        idx = VectorIndex(memory_vec, read_only=True)
        idx.load()
        indexed = idx.sources()
        csv_sources = {m.source for m in memory}
        missing = csv_sources - indexed
        result["memory_missing"] = len(missing)
        if missing and verbose:
            print_warning(
                f"翻译记忆索引不一致: {len(missing)} 条记忆未被索引，"
                f"建议运行 qmt vectordb rebuild"
            )

    return result


def batch_embed_queries(api_key: str, texts: list[str]) -> dict[str, list[float]]:
    """Pre-compute embeddings for a batch of query texts using concurrent API calls.

    Returns a dict mapping text -> embedding vector.
    Deduplicates texts before calling the API.
    """
    from qmt.embedding import get_embeddings_concurrent

    unique = list(dict.fromkeys(texts))  # preserve order, dedupe
    if not unique:
        return {}
    embeddings = get_embeddings_concurrent(api_key, unique)
    return dict(zip(unique, embeddings))


def learn_memory(source: str, target: str, api_key: str) -> None:
    """Write translation result to memory.csv and sync vector index immediately."""
    from qmt import store

    store.upsert_memory(source, target)

    # Embed and upsert into vector index (needs write mode)
    try:
        embeddings = get_embeddings(api_key, [source])
        vec_path = store.memory_vec_path()
        rw_index = VectorIndex(vec_path, read_only=False)
        rw_index.load()
        if rw_index._read_only:
            return  # Write lock unavailable, skip vector sync
        rw_index.upsert_entry(source, embeddings[0])
        rw_index.save()
    except EmbeddingError:
        pass
    except Exception:
        pass


def batch_learn_memory(pairs: list[tuple[str, str]], api_key: str) -> None:
    """Batch write translation results to memory.csv + sync vectors.

    Uses file lock to prevent concurrent writes from corrupting memory.csv.
    Calls _write_csv directly (which handles its own locking) to avoid double-lock.
    """
    from qmt import store

    if not pairs:
        return

    # Read-modify-write under a single exclusive lock to prevent interleaving
    from qmt.filelock import exclusive_lock

    memory_path = store._memory_file()
    with exclusive_lock(memory_path):
        # Read current pairs without acquiring shared lock (we already hold exclusive)
        current = []
        if memory_path.exists():
            import csv as _csv

            with open(memory_path, encoding="utf-8", newline="") as f:
                for row in _csv.reader(f):
                    if len(row) >= 2 and row[0].strip() and row[1].strip():
                        current.append((row[0].strip(), row[1].strip()))
        # Upsert each pair
        source_map = {s: t for s, t in current}
        for source, target in pairs:
            source_map[source] = target
        new_pairs = list(source_map.items())
        # Write directly (skip _write_csv to avoid double locking)
        store._ensure_dir()
        with open(memory_path, "w", encoding="utf-8", newline="") as f:
            writer = _csv.writer(f)
            for pair in new_pairs:
                writer.writerow(pair)
    # Update cache
    from qmt.store import _csv_cache
    _csv_cache[str(memory_path)] = (memory_path.stat().st_mtime, new_pairs)

    # Batch embed all sources (needs write mode)
    try:
        sources = [s for s, _ in pairs]
        embeddings = get_embeddings(api_key, sources)
        vec_path = store.memory_vec_path()
        rw_index = VectorIndex(vec_path, read_only=False)
        rw_index.load()
        if rw_index._read_only:
            return
        for source, emb in zip(sources, embeddings):
            rw_index.upsert_entry(source, emb)
        rw_index.save()
    except EmbeddingError:
        pass
    except Exception:
        pass


# ─── Internal ───────────────────────────────────────────────────────────────


def _get_cached_index(cache_key: str, vec_path: Path) -> VectorIndex:
    """Get or load a cached VectorIndex (read-only mode for search).

    Opens in read-only mode by default to avoid lock conflicts.
    Automatically reloads if the underlying manifest has changed on disk.
    Write mode is only used explicitly in _sync_index when changes are needed.
    """
    global _terms_index_cache, _memory_index_cache

    if cache_key == "terms":
        if (
            _terms_index_cache is None
            or _terms_index_cache._path != vec_path
            or _terms_index_cache.is_stale()
        ):
            _terms_index_cache = VectorIndex(vec_path, read_only=True)
            _terms_index_cache.load()
        return _terms_index_cache
    else:
        if (
            _memory_index_cache is None
            or _memory_index_cache._path != vec_path
            or _memory_index_cache.is_stale()
        ):
            _memory_index_cache = VectorIndex(vec_path, read_only=True)
            _memory_index_cache.load()
        return _memory_index_cache


def _sync_index(
    vec_path: Path,
    current_sources: list[str],
    api_key: str,
    cache_key: str,
) -> VectorIndex:
    """Return the vector index for search, without blocking on embedding API calls.

    Only removes stale entries (cheap, no API call). Adding new entries is NOT done
    here — it happens at write time (add_term, learn_memory) or via `qmt vectordb rebuild`.
    This ensures queries have predictable latency.
    """
    index = _get_cached_index(cache_key, vec_path)

    # Model change → full rebuild needed
    if not index.is_empty() and index.model_name() != EMBEDDING_MODEL:
        raise EmbeddingError("嵌入模型已变更，请先运行: qmt vectordb rebuild")

    current_set = set(current_sources)
    indexed_set = index.sources()

    to_remove = indexed_set - current_set

    # No removals needed — return as-is
    if not to_remove:
        return index

    # Only remove stale entries (no API call needed, fast operation)
    try:
        rw_index = VectorIndex(vec_path, read_only=False)
        rw_index.load()
        if rw_index._read_only:
            return index
    except Exception:
        return index

    rw_index.remove_by_sources(to_remove)
    rw_index.save()

    # Invalidate read-only cache
    global _terms_index_cache, _memory_index_cache
    if cache_key == "terms":
        _terms_index_cache = None
    else:
        _memory_index_cache = None

    return _get_cached_index(cache_key, vec_path)


def _select_relevant(
    query_text: str,
    items: list,
    source_fn,
    vec_path: Path,
    api_key: str,
    top_k: int,
    query_embedding: list[float] | None,
    cache_key: str,
    verbose: bool,
) -> list:
    """Generic Top-K selection for terms or memory."""
    current_sources = [source_fn(item) for item in items]

    # Sync index
    index = _sync_index(vec_path, current_sources, api_key, cache_key)

    # Embed query
    if query_embedding is None:
        query_embedding = get_embeddings(api_key, [query_text])[0]

    # Search with min_score filter to exclude irrelevant low-similarity matches
    results = index.search(query_embedding, top_k, min_score=DEFAULT_MIN_SCORE)
    matched_sources = {source for source, _score in results}

    if verbose:
        label = "术语" if cache_key == "terms" else "翻译记忆"
        msg = f"语义匹配: 从 {len(items)} 条{label}中选择了 {len(matched_sources)} 条"
        print_info(msg)

    return [item for item in items if source_fn(item) in matched_sources]
