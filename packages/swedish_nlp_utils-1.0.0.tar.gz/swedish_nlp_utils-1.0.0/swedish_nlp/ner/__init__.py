# Filepath: swedish_nlp/ner/__init__.py
from swedish_nlp.ner.ner import SwedishNER, SwedishEntities
__all__ = ["SwedishNER", "SwedishEntities"]
