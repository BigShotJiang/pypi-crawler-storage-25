# Filepath: swedish_nlp/ner/ner.py
# Condensed Description: Swedish NER — extracts authorities, laws, courts, persons,
#   organisations, dates, and case references. Rule-based core; spaCy optional upgrade.
# Architecture Layer: Utility
# Environment: Both
# Script Hierarchy:
#    - Classes: SwedishEntities, SwedishNER
#    - Methods: extract, extract_authorities, extract_law_refs, extract_persons,
#               extract_organisations, extract_case_refs, extract_all_entities

from __future__ import annotations

import re
from dataclasses import dataclass, field


# ── Entity data class ─────────────────────────────────────────────────────────

@dataclass
class SwedishEntities:
    """Container for all entity types extracted from a Swedish text."""

    # Government / administrative authorities
    authorities: list[str] = field(default_factory=list)

    # Courts
    courts: list[str] = field(default_factory=list)

    # Law references — both short codes and SFS numbers
    law_refs: list[str] = field(default_factory=list)

    # Case/diary numbers
    case_refs: list[str] = field(default_factory=list)
    diarienummer: list[str] = field(default_factory=list)

    # Person names (capitalised bi-grams heuristic)
    persons: list[str] = field(default_factory=list)

    # Organisations (AB, ideella föreningar, myndigheter)
    organisations: list[str] = field(default_factory=list)

    # Named locations (kommuner, regioner, stadsdelar)
    locations: list[str] = field(default_factory=list)

    # Dates (ISO-formatted)
    dates: list[str] = field(default_factory=list)

    # Roles / titles found
    roles: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "authorities":  self.authorities,
            "courts":       self.courts,
            "law_refs":     self.law_refs,
            "case_refs":    self.case_refs,
            "diarienummer": self.diarienummer,
            "persons":      self.persons,
            "organisations": self.organisations,
            "locations":    self.locations,
            "dates":        self.dates,
            "roles":        self.roles,
        }

    @property
    def all_entities(self) -> list[str]:
        return (
            self.authorities + self.courts + self.law_refs +
            self.persons + self.organisations + self.locations
        )


# ── Pattern library ────────────────────────────────────────────────────────────

# Known authority names — order matters (longer first to avoid partial hits)
_AUTHORITY_PATTERNS = [
    r"Justitieombudsmannen", r"\bJO\b",
    r"Justitiekanslern", r"\bJK\b",
    r"Inspektionen för vård och omsorg", r"\bIVO\b",
    r"Integritetsskyddsmyndigheten", r"\bIMY\b",
    r"Datainspektionen",
    r"Skolinspektionen",
    r"Socialstyrelsen",
    r"Folkhälsomyndigheten",
    r"Försäkringskassan",
    r"Migrationsverket",
    r"Skatteverket",
    r"Kronofogdemyndigheten", r"Kronofogden",
    r"Diskrimineringsombudsmannen", r"\bDO\b",
    r"Barnombudsmannen", r"\bBO\b",
    r"Riksrevisionen",
    r"Statskontoret",
    r"Upphandlingsmyndigheten",
    r"Länsstyrelsen(?:\s+i\s+[A-ZÅÄÖ][a-zåäö]+ (?:län|region))?",
    r"[A-ZÅÄÖ][a-zåäö]+\s+(?:socialnämnd(?:en)?|bildningsnämnd(?:en)?|"
    r"kommunstyrelse(?:n)?|fullmäktige|förvaltning(?:en)?|nämnd(?:en)?)",
    r"Socialnämnden", r"Kommunfullmäktige", r"Kommunstyrelsen",
]
_AUTHORITY_RE = re.compile(
    "|".join(f"(?:{p})" for p in _AUTHORITY_PATTERNS)
)

# Courts
_COURT_PATTERNS = [
    r"Högsta domstolen", r"\bHD\b",
    r"Högsta förvaltningsdomstolen", r"\bHFD\b",
    r"Kammarrätten(?:\s+i\s+[A-ZÅÄÖ][a-zåäö]+)?",
    r"[A-ZÅÄÖ][a-zåäö]* (?:tingsrätt|hovrätt|förvaltningsrätt|kammarrätt)",
    r"Arbetsdomstolen", r"\bAD\b",
    r"Migrationsöverdomstolen", r"\bMigrÖD\b",
    r"Mark- och miljödomstolen",
    r"Mark- och miljööverdomstolen", r"\bMÖD\b",
    r"Patent- och marknadsdomstolen",
]
_COURT_RE = re.compile("|".join(f"(?:{p})" for p in _COURT_PATTERNS))

# Law references — short codes, SFS, chapter/section patterns
_LAW_SHORTCODE_RE = re.compile(
    r"\b(SoL|FB|LVU|FL|RF|BrB|OSL|LSS|HSL|LOU|PBL|MB|ÄktB|EKMR|BK|KL|"
    r"KomL|DL|PDL|PSL|LPT|ABL|IL|ML|BFL|GDPR|PUL|PL|SFS)\b"
)
_SFS_RE = re.compile(r"\bSFS\s+\d{4}:\d+\b")
_CHAPTER_RE = re.compile(
    r"\d+\s*kap\.?\s*\d+\s*[a-z]?\s*§(?:\s*\d+\s*mom\.?)?"
    r"(?:\s+(?:FB|SoL|FL|LVU|LOU|MB|PBL|RF|BrB|ÄktB|LSS|HSL|OSL|KL))?",
    re.IGNORECASE,
)

# Case references (court docket numbers)
_CASE_REF_RE = re.compile(
    r"\b(?:Mål\s+(?:nr\.?\s*)?|T|B|Ö|FT|FÖ|Ä)?\d{1,5}[-–]\d{2,6}\b"
    r"|\b(?:HFD|HovR|TR|FR|KamR|AD|MÖD)\s+\d{4}:?\d*\b",
    re.IGNORECASE,
)

# Diarienummer
_DIARIENR_RE = re.compile(
    r"(?:[Dd]iarienummer?|[Dd]nr)[:\s]+([A-Z0-9][A-Z0-9\-/\. ]{2,25})"
)

# Person names — capitalised bi-grams (Förnamn Efternamn)
# Deliberately conservative to reduce false positives.
_PERSON_RE = re.compile(
    r"\b([A-ZÅÄÖ][a-zåäö]{1,20})\s+([A-ZÅÄÖ][a-zåäö]{1,20})\b"
)
_TITLE_NOISE = {
    "Socialnämnden", "Kommunstyrelsen", "Stockholms", "Göteborgs",
    "Malmö", "Uppsala", "Linköpings", "Västra", "Norra", "Södra",
    "Östra", "Västra", "Centrala", "Svenska", "Statens", "Riksdagens",
}
_PERSON_PRECEDING_TITLES = re.compile(
    r"(?:handläggare|utredare|socialsekreterare|enhetschef|avdelningschef|"
    r"ordförande|sekreterare|rektor|läkare|sjuksköterska|advokat|jurist|"
    r"direktör|chef|revisor|inspektör)[:\s]+([A-ZÅÄÖ][a-zåäö]+ [A-ZÅÄÖ][a-zåäö]+)",
    re.IGNORECASE,
)

# Roles / titles
_ROLE_RE = re.compile(
    r"\b(handläggare|utredare|socialsekreterare|enhetschef|avdelningschef|"
    r"ordförande|sekreterare|rektor|leg\.?\s*läkare|leg\.?\s*sjuksköterska|"
    r"advokat|jurist|direktör|kommunalråd|oppositionsråd|revisor|inspektör|"
    r"förvaltningschef|socialchef|biträdande\s+chef)\b",
    re.IGNORECASE,
)

# Organisations (AB, HB, ideella, stiftelse)
_ORG_RE = re.compile(
    r"\b([A-ZÅÄÖ][a-zåäö]{1,30}(?:\s+[A-ZÅÄÖ][a-zåäö]{1,30})*)\s+"
    r"(?:AB|HB|KB|ideell\s+förening|stiftelse|ekonomisk\s+förening|"
    r"kooperativ)\b"
)

# Swedish municipalities and regions (partial list — known entities)
_LOCATION_RE = re.compile(
    r"\b(Stockholm|Göteborg|Malmö|Uppsala|Västerås|Örebro|Linköping|"
    r"Helsingborg|Jönköping|Norrköping|Lund|Umeå|Gävle|Borås|Södertälje|"
    r"Eskilstuna|Halmstad|Växjö|Karlstad|Sundsvall|Östersund|Trollhättan|"
    r"Luleå|Kalmar|Mölndal|Borlänge|Falun|Skellefteå|Kristianstad|"
    r"Skåne|Blekinge|Halland|Dalarna|Gävleborg|Jämtland|Västernorrland|"
    r"Västmanland|Sörmland|Östergötland|Småland|Värmland|Uppland|"
    r"Norrbotten|Västerbotten|Västra Götaland|Region Stockholm)\b"
)

# ISO and Swedish-format dates
_DATE_ISO_RE = re.compile(r"\b(\d{4}[-./]\d{2}[-./]\d{2})\b")
_DATE_WORD_RE = re.compile(
    r"\b(\d{1,2})\s+"
    r"(januari|februari|mars|april|maj|juni|juli|augusti|"
    r"september|oktober|november|december)\s+(\d{4})\b",
    re.IGNORECASE,
)
_MONTH_MAP = {
    "januari": "01", "februari": "02", "mars": "03", "april": "04",
    "maj": "05", "juni": "06", "juli": "07", "augusti": "08",
    "september": "09", "oktober": "10", "november": "11", "december": "12",
}


class SwedishNER:
    """
    Swedish Named Entity Recogniser — rule-based, zero-dependency core.

    Extracts: authorities, courts, law references, case numbers, diarienummer,
    person names, organisations, locations, dates, and roles.

    Optional spaCy upgrade::

        ner = SwedishNER(use_spacy=True)   # requires: pip install spacy
                                           # + python -m spacy download sv_core_news_sm

    Usage::

        ner = SwedishNER()
        entities = ner.extract("Socialnämnden fattade beslut enligt SoL 4 kap. 1 §")

        print(entities.authorities)  # ["Socialnämnden"]
        print(entities.law_refs)     # ["SoL", "4 kap. 1 § SoL"]
    """

    def __init__(self, use_spacy: bool = False):
        self._spacy_nlp = None
        if use_spacy:
            self._spacy_nlp = self._load_spacy()

    # ── Main extraction method ────────────────────────────────────────────────

    def extract(self, text: str) -> SwedishEntities:
        """Run full NER pipeline on text. Returns SwedishEntities."""
        e = SwedishEntities(
            authorities  = self.extract_authorities(text),
            courts       = self.extract_courts(text),
            law_refs     = self.extract_law_refs(text),
            case_refs    = self.extract_case_refs(text),
            diarienummer = self.extract_diarienummer(text),
            persons      = self.extract_persons(text),
            organisations= self.extract_organisations(text),
            locations    = self.extract_locations(text),
            dates        = self.extract_dates(text),
            roles        = self.extract_roles(text),
        )

        # Upgrade persons list with spaCy if available
        if self._spacy_nlp:
            e.persons = list(dict.fromkeys(e.persons + self._spacy_persons(text)))
            e.organisations = list(dict.fromkeys(e.organisations + self._spacy_orgs(text)))

        return e

    # ── Individual extractors ─────────────────────────────────────────────────

    def extract_authorities(self, text: str) -> list[str]:
        return _dedupe(_AUTHORITY_RE.findall(text))

    def extract_courts(self, text: str) -> list[str]:
        return _dedupe(_COURT_RE.findall(text))

    def extract_law_refs(self, text: str) -> list[str]:
        refs: list[str] = []
        refs += _CHAPTER_RE.findall(text)
        refs += _SFS_RE.findall(text)
        refs += _LAW_SHORTCODE_RE.findall(text)
        return _dedupe(refs)

    def extract_case_refs(self, text: str) -> list[str]:
        return _dedupe(_CASE_REF_RE.findall(text))

    def extract_diarienummer(self, text: str) -> list[str]:
        return _dedupe(_DIARIENR_RE.findall(text))

    def extract_persons(self, text: str) -> list[str]:
        # Priority 1: names following known title patterns
        titled = _dedupe(_PERSON_PRECEDING_TITLES.findall(text))

        # Priority 2: capitalised bi-grams not in title-noise set
        bi_grams: list[str] = []
        for m in _PERSON_RE.finditer(text):
            first, last = m.group(1), m.group(2)
            full = f"{first} {last}"
            if first not in _TITLE_NOISE and last not in _TITLE_NOISE:
                bi_grams.append(full)

        return _dedupe(titled + bi_grams)

    def extract_organisations(self, text: str) -> list[str]:
        return _dedupe(_ORG_RE.findall(text))

    def extract_locations(self, text: str) -> list[str]:
        return _dedupe(_LOCATION_RE.findall(text))

    def extract_dates(self, text: str) -> list[str]:
        dates: list[str] = []
        for m in _DATE_ISO_RE.finditer(text):
            dates.append(m.group(1).replace(".", "-").replace("/", "-"))
        for m in _DATE_WORD_RE.finditer(text):
            month = _MONTH_MAP.get(m.group(2).lower(), "00")
            dates.append(f"{m.group(3)}-{month}-{int(m.group(1)):02d}")
        return _dedupe(dates)

    def extract_roles(self, text: str) -> list[str]:
        return _dedupe(_ROLE_RE.findall(text))

    # ── spaCy helpers (optional) ──────────────────────────────────────────────

    def _load_spacy(self):
        try:
            import spacy
            try:
                return spacy.load("sv_core_news_sm")
            except OSError:
                import subprocess, sys
                subprocess.run(
                    [sys.executable, "-m", "spacy", "download", "sv_core_news_sm"],
                    check=True, capture_output=True,
                )
                return spacy.load("sv_core_news_sm")
        except ImportError:
            raise ImportError(
                "spaCy required for use_spacy=True: pip install spacy "
                "then: python -m spacy download sv_core_news_sm"
            )

    def _spacy_persons(self, text: str) -> list[str]:
        doc = self._spacy_nlp(text[:50_000])
        return [ent.text for ent in doc.ents if ent.label_ == "PER"]

    def _spacy_orgs(self, text: str) -> list[str]:
        doc = self._spacy_nlp(text[:50_000])
        return [ent.text for ent in doc.ents if ent.label_ == "ORG"]


# ── Helper ────────────────────────────────────────────────────────────────────

def _dedupe(items: list[str]) -> list[str]:
    """Deduplicate preserving insertion order, stripping whitespace."""
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        clean = item.strip()
        if clean and clean not in seen:
            seen.add(clean)
            out.append(clean)
    return out
