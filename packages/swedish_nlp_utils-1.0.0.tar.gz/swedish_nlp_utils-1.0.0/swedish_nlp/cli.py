# Filepath: swedish_nlp/cli.py
# Condensed Description: CLI entry point for quick Swedish NLP analysis
# Architecture Layer: CLI
# Exposes:
#    - CLI Commands: swe-nlp analyze, swe-nlp chunk, swe-nlp normalize

from __future__ import annotations

import argparse
import json
import sys


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="swe-nlp",
        description="Swedish NLP utilities — analyze, chunk, and normalize Swedish text.",
    )
    sub = p.add_subparsers(dest="command", required=True)

    # ── analyze ──────────────────────────────────────────────────────────────
    ana = sub.add_parser("analyze", help="Run full NER + entity extraction on text")
    ana.add_argument("text", nargs="?", help="Text to analyze (or pipe via stdin)")
    ana.add_argument("--file", "-f", help="Read text from file")
    ana.add_argument("--format", choices=["json", "pretty"], default="pretty")

    # ── chunk ─────────────────────────────────────────────────────────────────
    chk = sub.add_parser("chunk", help="Split text into vector-ready chunks")
    chk.add_argument("text", nargs="?")
    chk.add_argument("--file", "-f")
    chk.add_argument("--size", type=int, default=512, help="Target tokens per chunk")
    chk.add_argument("--overlap", type=int, default=50, help="Overlap tokens")
    chk.add_argument("--show-tokens", action="store_true")

    # ── normalize ─────────────────────────────────────────────────────────────
    nor = sub.add_parser("normalize", help="Normalize Swedish text (OCR fix, law refs, etc.)")
    nor.add_argument("text", nargs="?")
    nor.add_argument("--file", "-f")
    nor.add_argument("--municipality", action="store_true", help="Also normalize municipality names")

    return p


def _read_input(args) -> str:
    if args.file:
        with open(args.file, encoding="utf-8") as f:
            return f.read()
    if args.text:
        return args.text
    if not sys.stdin.isatty():
        return sys.stdin.read()
    print("ERROR: Provide text as argument, --file, or pipe via stdin.", file=sys.stderr)
    sys.exit(1)


def cmd_analyze(args) -> None:
    from swedish_nlp import SwedishNER, SwedishFormats
    text = _read_input(args)
    ner = SwedishNER()
    entities = ner.extract(text)
    amounts = SwedishFormats.extract_sek_amounts(text)
    dates = SwedishFormats.extract_dates(text)

    if args.format == "json":
        output = entities.to_dict()
        output["amounts_sek"] = amounts
        output["dates_extracted"] = dates
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        d = entities.to_dict()
        for key, vals in d.items():
            if vals:
                print(f"{key:20s}: {', '.join(str(v) for v in vals)}")
        if amounts:
            print(f"{'amounts_sek':20s}: {', '.join(str(a) for a in amounts)}")
        if dates:
            print(f"{'dates':20s}: {', '.join(dates)}")


def cmd_chunk(args) -> None:
    from swedish_nlp import SwedishChunker
    from swedish_nlp.chunker.chunker import ChunkConfig
    text = _read_input(args)
    chunker = SwedishChunker(ChunkConfig(chunk_size=args.size, chunk_overlap=args.overlap))
    chunks = chunker.chunk(text)
    print(f"Produced {len(chunks)} chunks (target={args.size} tokens, overlap={args.overlap})")
    print()
    for i, chunk in enumerate(chunks):
        tok = f"  [~{chunk.token_estimate} tokens]" if args.show_tokens else ""
        print(f"── Chunk {i + 1}/{len(chunks)}{tok} ──────────────────")
        print(chunk.text[:200] + ("…" if len(chunk.text) > 200 else ""))
        print()


def cmd_normalize(args) -> None:
    from swedish_nlp import SwedishNormalizer
    text = _read_input(args)
    n = SwedishNormalizer()
    result = n.normalize(text)
    if args.municipality:
        # Replace municipality names on a best-effort basis
        import re
        muni_pattern = re.compile(
            r"[A-ZÅÄÖ][a-zåäö]+\s+(?:stad|kommuns?|region)(?:en)?", re.IGNORECASE
        )
        result = muni_pattern.sub(
            lambda m: n.normalize_municipality(m.group()), result
        )
    print(result)


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "analyze":
        cmd_analyze(args)
    elif args.command == "chunk":
        cmd_chunk(args)
    elif args.command == "normalize":
        cmd_normalize(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
