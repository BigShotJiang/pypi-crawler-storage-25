# Filepath: swedish_nlp/normalizer/__init__.py
from swedish_nlp.normalizer.normalizer import SwedishNormalizer
__all__ = ["SwedishNormalizer"]
