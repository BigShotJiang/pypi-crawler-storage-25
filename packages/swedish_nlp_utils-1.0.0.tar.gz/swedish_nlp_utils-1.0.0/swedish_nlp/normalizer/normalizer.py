# Filepath: swedish_nlp/normalizer/normalizer.py
# Condensed Description: Normalises Swedish legal terminology, municipality names,
#   authority names, law short codes, and OCR artefacts
# Architecture Layer: Utility
# Environment: Both
# Script Hierarchy:
#    - Classes: SwedishNormalizer
#    - Methods: normalize, normalize_municipality, normalize_authority,
#               normalize_law_reference, normalize_ocr, ascii_fold

from __future__ import annotations

import re
import unicodedata


# ── Municipality name normalisation ───────────────────────────────────────────
# Maps common variants and suffixes → canonical name.
_MUNICIPALITY_SUFFIXES = re.compile(
    r"s?\s+(?:stad(?:s)?|kommune?[tn]?|region(?:en)?|landsting(?:et)?|"
    r"kommuns|kommunen|stadsdel(?:en)?)\s*$",
    re.IGNORECASE,
)
_MUNICIPALITY_ALIASES: dict[str, str] = {
    "gbg": "Göteborg",
    "göteborgs stad": "Göteborg",
    "göteborgs kommun": "Göteborg",
    "stockholms stad": "Stockholm",
    "stockholms kommun": "Stockholm",
    "malmö stad": "Malmö",
    "malmö kommun": "Malmö",
    "stockholms läns landsting": "Region Stockholm",
    "västra götalandsregionen": "Västra Götaland",
    "region västra götaland": "Västra Götaland",
}

# ── Authority name normalisation ───────────────────────────────────────────────
# Maps all common variants → canonical short form.
_AUTHORITY_CANONICAL: dict[str, str] = {
    # Full name → canonical short
    "justitieombudsmannen": "JO",
    "riksdagens ombudsmän": "JO",
    "justitiekanslern": "JK",
    "inspektionen för vård och omsorg": "IVO",
    "integritetsskyddsmyndigheten": "IMY",
    "datainspektionen": "IMY",      # old name
    "skolinspektionen": "Skolinspektionen",
    "socialstyrelsen": "Socialstyrelsen",
    "folkhälsomyndigheten": "Folkhälsomyndigheten",
    "försäkringskassan": "Försäkringskassan",
    "migrationsverket": "Migrationsverket",
    "skatteverket": "Skatteverket",
    "länsstyrelsen": "Länsstyrelsen",
    "kronofogdemyndigheten": "Kronofogden",
    "kronofogden": "Kronofogden",
    "diskrimineringsombudsmannen": "DO",
    "barnombudsmannen": "BO",
    "konsumentverket": "Konsumentverket",
    "kammarkollegiet": "Kammarkollegiet",
    "riksrevisionen": "Riksrevisionen",
    "statskontoret": "Statskontoret",
    "upphandlingsmyndigheten": "Upphandlingsmyndigheten",
    # Courts
    "högsta domstolen": "HD",
    "högsta förvaltningsdomstolen": "HFD",
    "hovrätten": "HovR",
    "förvaltningsrätten": "FR",
    "kammarrätten": "KamR",
    "mark- och miljödomstolen": "MÖD",
    "mark- och miljööverdomstolen": "MÖD",
    "arbetsdomstolen": "AD",
    "migrationsdomstolen": "MigrD",
    "migrationsöverdomstolen": "MigrÖD",
}

# ── Law short-code normalisation ──────────────────────────────────────────────
# Maps OCR variants and long names → canonical abbreviations.
_LAW_ALIASES: dict[str, str] = {
    "socialtjänstlagen": "SoL",
    "socialtjänstlag": "SoL",
    "sol": "SoL",
    "föräldrabalken": "FB",
    "föräldrabalk": "FB",
    "förvaltningslagen": "FL",
    "förvaltningslag": "FL",
    "lag med särskilda bestämmelser om vård av unga": "LVU",
    "lagen om vård av unga": "LVU",
    "kommunallagen": "KL",
    "kommunallag": "KL",
    "regeringsformen": "RF",
    "brottsbalken": "BrB",
    "brottsbalk": "BrB",
    "offentlighets- och sekretesslagen": "OSL",
    "offentlighets och sekretesslagen": "OSL",
    "lag om stöd och service till vissa funktionshindrade": "LSS",
    "hälso- och sjukvårdslagen": "HSL",
    "hälso och sjukvårdslagen": "HSL",
    "lagen om offentlig upphandling": "LOU",
    "plan- och bygglagen": "PBL",
    "plan och bygglagen": "PBL",
    "miljöbalken": "MB",
    "äktenskapsbalken": "ÄktB",
    "diskrimineringslagen": "DL",
    "barnkonventionen": "BK",
    "fn:s barnkonvention": "BK",
    "europeiska konventionen om skydd för de mänskliga rättigheterna": "EKMR",
    "europakonventionen": "EKMR",
    "patientdatalagen": "PDL",
    "patientlagen": "PL",
    "patientsäkerhetslagen": "PSL",
    "lag om psykiatrisk tvångsvård": "LPT",
    "personuppgiftslagen": "PUL",
    "dataskyddsförordningen": "GDPR",
    "gdpr": "GDPR",
    "inkomstskattelagen": "IL",
    "mervärdesskattelagen": "ML",
    "bokföringslagen": "BFL",
    "aktiebolagslagen": "ABL",
}

# ── OCR correction patterns ────────────────────────────────────────────────────
# Common OCR errors in Swedish administrative documents.
_OCR_CORRECTIONS: list[tuple[re.Pattern, str]] = [
    # l→I and I→1 confusions
    (re.compile(r"\bI(?=[a-zåäö])"), "l"),          # word-initial I before lowercase
    (re.compile(r"(?<=[a-zåäö])I\b"), "l"),          # word-final I after lowercase
    # Ligature fi / fl → fi / fl
    (re.compile(r"\ufb00"), "ff"),
    (re.compile(r"\ufb01"), "fi"),
    (re.compile(r"\ufb02"), "fl"),
    (re.compile(r"\ufb03"), "ffi"),
    (re.compile(r"\ufb04"), "ffl"),
    # Soft hyphen (U+00AD) — remove it
    (re.compile(r"\xad"), ""),
    # Non-breaking space → regular space
    (re.compile(r"\u00a0"), " "),
    # Em/en dash → hyphen in number ranges
    (re.compile(r"(\d)\s*[–—]\s*(\d)"), r"\1-\2"),
    # Double-space cleanup
    (re.compile(r"  +"), " "),
    # Spurious line breaks inside sentences (word mid-break)
    (re.compile(r"([a-zåäö])-\n([a-zåäö])"), r"\1\2"),
    # Fix § followed by number (OCR sometimes adds extra space)
    (re.compile(r"§\s{2,}(\d)"), r"§ \1"),
    # Common Swedish word OCR mistakes
    (re.compile(r"\bOch\b"), "och"),
    (re.compile(r"\bAtt\b(?! )"), "att"),
    (re.compile(r"\bTill\b(?! )"), "till"),
]


class SwedishNormalizer:
    """
    Normalises Swedish text, legal references, municipality names,
    authority names, and OCR artefacts.

    Usage::

        n = SwedishNormalizer()

        # Municipality
        n.normalize_municipality("Göteborgs stad")      → "Göteborg"
        n.normalize_municipality("Stockholms kommun")   → "Stockholm"

        # Authority
        n.normalize_authority("Justitieombudsmannen")   → "JO"
        n.normalize_authority("Inspektionen för vård och omsorg") → "IVO"

        # Law references
        n.normalize_law_reference("Socialtjänstlagen")  → "SoL"
        n.normalize_law_reference("Sol")                → "SoL"

        # OCR artefacts
        n.normalize_ocr("§  12 nämndens beslut")        → "§ 12 nämndens beslut"

        # Full pipeline
        n.normalize("råtext från OCR, sol 4 kap, göteborgs stad")
    """

    def __init__(self):
        self._muni_aliases = {k.lower(): v for k, v in _MUNICIPALITY_ALIASES.items()}
        self._auth_canonical = {k.lower(): v for k, v in _AUTHORITY_CANONICAL.items()}
        self._law_aliases = {k.lower(): v for k, v in _LAW_ALIASES.items()}

    # ── Municipality normalisation ────────────────────────────────────────────

    def normalize_municipality(self, name: str) -> str:
        """
        Strips common suffixes and maps aliases to canonical municipality name.

        Examples:
            "Göteborgs stad"     → "Göteborg"
            "malmö kommun"       → "Malmö"
            "Region Skåne"       → "Region Skåne"   (regions kept as-is)
        """
        stripped = name.strip()
        alias = self._muni_aliases.get(stripped.lower())
        if alias:
            return alias
        # Remove suffix
        cleaned = _MUNICIPALITY_SUFFIXES.sub("", stripped).strip()
        # Title-case if all-lowercase
        if cleaned == cleaned.lower():
            cleaned = cleaned.title()
        return cleaned

    # ── Authority normalisation ───────────────────────────────────────────────

    def normalize_authority(self, name: str) -> str:
        """
        Maps Swedish authority long-names to canonical short form.

        Examples:
            "Justitieombudsmannen"              → "JO"
            "Inspektionen för vård och omsorg"  → "IVO"
            "Högsta förvaltningsdomstolen"      → "HFD"
        """
        key = name.strip().lower()
        return self._auth_canonical.get(key, name.strip())

    def is_authority(self, name: str) -> bool:
        return name.strip().lower() in self._auth_canonical

    # ── Law reference normalisation ───────────────────────────────────────────

    def normalize_law_reference(self, ref: str) -> str:
        """
        Maps full law names and OCR variants to canonical abbreviations.

        Examples:
            "Socialtjänstlagen"   → "SoL"
            "sol"                 → "SoL"
            "förvaltningslagen"   → "FL"
            "GDPR"                → "GDPR"
        """
        key = ref.strip().lower()
        return self._law_aliases.get(key, ref.strip())

    def normalize_law_references_in_text(self, text: str) -> str:
        """
        Replace all known long-form law names with their abbreviations in text.
        Longest matches applied first to avoid partial replacement.
        """
        sorted_laws = sorted(self._law_aliases.keys(), key=len, reverse=True)
        for long_form in sorted_laws:
            abbrev = self._law_aliases[long_form]
            pattern = re.compile(re.escape(long_form), re.IGNORECASE)
            text = pattern.sub(abbrev, text)
        return text

    # ── OCR artefact correction ───────────────────────────────────────────────

    def normalize_ocr(self, text: str) -> str:
        """Apply OCR correction rules to Swedish administrative text."""
        for pattern, replacement in _OCR_CORRECTIONS:
            text = pattern.sub(replacement, text)
        return text.strip()

    # ── NFC / character normalisation ─────────────────────────────────────────

    @staticmethod
    def nfc(text: str) -> str:
        """NFC-normalise preserving å/ä/ö as composed characters."""
        return unicodedata.normalize("NFC", text)

    @staticmethod
    def ascii_fold(text: str) -> str:
        """
        Fold Swedish characters to ASCII equivalents.
        Useful for slug generation and fuzzy key matching.

            å → a,  ä → a,  ö → o
            Å → A,  Ä → A,  Ö → O
        """
        return (
            text
            .replace("å", "a").replace("ä", "a").replace("ö", "o")
            .replace("Å", "A").replace("Ä", "A").replace("Ö", "O")
        )

    @staticmethod
    def to_slug(text: str) -> str:
        """Generate a URL/filename-safe slug from Swedish text."""
        text = SwedishNormalizer.ascii_fold(text.lower())
        text = re.sub(r"[^a-z0-9]+", "-", text)
        return text.strip("-")

    # ── Full normalisation pipeline ───────────────────────────────────────────

    def normalize(self, text: str) -> str:
        """
        Apply the full normalisation pipeline in order:
          1. NFC unicode normalisation
          2. OCR artefact correction
          3. Law reference expansion
        """
        text = self.nfc(text)
        text = self.normalize_ocr(text)
        text = self.normalize_law_references_in_text(text)
        return text
