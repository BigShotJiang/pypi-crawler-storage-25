# Filepath: swedish_nlp/vectors/vectors.py
# Condensed Description: End-to-end Pinecone vector pipeline tuned for Swedish documents.
#   Handles embedding (OpenAI), upsert, search, and namespace management.
# Architecture Layer: Adapter / Utility
# Environment: Both
# Dependencies:
#    - External: pinecone-client, openai, tiktoken (all optional — raises ImportError if missing)
# Environment Variables: PINECONE_API_KEY, PINECONE_INDEX_NAME, OPENAI_API_KEY
# Script Hierarchy:
#    - Classes: VectorSearchResult, SwedishVectorPipeline
#    - Methods: embed, embed_batch, upsert_chunks, search, search_with_filter,
#               delete_by_doc_id, get_index_stats, chunk_and_upsert

from __future__ import annotations

import hashlib
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Optional

log = logging.getLogger(__name__)

# Embedding model defaults — Swedish text works well with multilingual models
_DEFAULT_EMBED_MODEL = "text-embedding-3-small"   # OpenAI, 1536 dims, cost-effective
_DEFAULT_EMBED_DIM   = 1536
_DEFAULT_NAMESPACE   = "swedish_documents"
_BATCH_SIZE          = 100    # Pinecone upsert batch limit
_EMBED_BATCH_SIZE    = 100    # OpenAI embeddings batch limit


@dataclass
class VectorSearchResult:
    """Single search result from Pinecone with Swedish document metadata."""
    vector_id: str
    score: float
    text: str
    doc_id: str = ""
    doc_type: str = ""
    municipality: str = ""
    chunk_index: int = 0
    page_number: Optional[int] = None
    section_title: Optional[str] = None
    year: Optional[int] = None
    extra_metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_pinecone_match(cls, match) -> "VectorSearchResult":
        meta = match.metadata or {}
        return cls(
            vector_id     = match.id,
            score         = match.score,
            text          = meta.get("text", ""),
            doc_id        = meta.get("doc_id", ""),
            doc_type      = meta.get("doc_type", ""),
            municipality  = meta.get("municipality", ""),
            chunk_index   = int(meta.get("index", 0)),
            page_number   = meta.get("page_number"),
            section_title = meta.get("section_title"),
            year          = meta.get("year"),
            extra_metadata = {
                k: v for k, v in meta.items()
                if k not in {"text", "doc_id", "doc_type", "municipality",
                             "index", "page_number", "section_title", "year"}
            },
        )


class SwedishVectorPipeline:
    """
    End-to-end vector pipeline for Swedish documents using Pinecone + OpenAI.

    Designed for SocKartan, DocFlow, ScrapeAssistant, and RevisionsUpproret.

    Usage::

        from swedish_nlp.vectors import SwedishVectorPipeline

        pipeline = SwedishVectorPipeline(
            index_name="sockartan-docs",
            namespace="protokoll",
        )

        # Index a document
        pipeline.chunk_and_upsert(
            text       = full_document_text,
            doc_id     = "protokoll-göteborg-2024-03",
            doc_type   = "protokoll",
            municipality = "Göteborg",
            year       = 2024,
        )

        # Search
        results = pipeline.search("socialtjänstens insatser för barn", top_k=5)
        for r in results:
            print(r.score, r.text[:100])

        # Search with filter
        results = pipeline.search_with_filter(
            "budget underskott",
            doc_type="årsredovisning",
            municipality="Göteborg",
            year=2023,
        )

    Requires::
        pip install pinecone-client openai tiktoken
        export PINECONE_API_KEY=...
        export OPENAI_API_KEY=...
    """

    def __init__(
        self,
        index_name: Optional[str] = None,
        namespace: str = _DEFAULT_NAMESPACE,
        embed_model: str = _DEFAULT_EMBED_MODEL,
        embed_dim: int = _DEFAULT_EMBED_DIM,
        chunk_size: int = 512,
        chunk_overlap: int = 50,
    ):
        self._index_name = index_name or os.getenv("PINECONE_INDEX_NAME", "swedish-docs")
        self._namespace  = namespace
        self._embed_model = embed_model
        self._embed_dim  = embed_dim
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap

        self._pc    = None   # Pinecone client (lazy)
        self._index = None   # Pinecone index (lazy)
        self._openai = None  # OpenAI client (lazy)

    # ── Lazy initialisation ───────────────────────────────────────────────────

    def _get_index(self):
        if self._index is not None:
            return self._index
        try:
            from pinecone import Pinecone, ServerlessSpec
        except ImportError as e:
            raise ImportError(
                "Install pinecone-client: pip install 'swedish-nlp-utils[vectors]'"
            ) from e

        api_key = os.getenv("PINECONE_API_KEY")
        if not api_key:
            raise EnvironmentError("PINECONE_API_KEY environment variable not set.")

        self._pc = Pinecone(api_key=api_key)

        # Create index if it doesn't exist
        existing = [idx.name for idx in self._pc.list_indexes()]
        if self._index_name not in existing:
            log.info("Creating Pinecone index '%s' (dim=%d)", self._index_name, self._embed_dim)
            self._pc.create_index(
                name=self._index_name,
                dimension=self._embed_dim,
                metric="cosine",
                spec=ServerlessSpec(cloud="aws", region="us-east-1"),
            )

        self._index = self._pc.Index(self._index_name)
        return self._index

    def _get_openai(self):
        if self._openai is not None:
            return self._openai
        try:
            from openai import OpenAI
        except ImportError as e:
            raise ImportError("Install openai: pip install 'swedish-nlp-utils[vectors]'") from e
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise EnvironmentError("OPENAI_API_KEY environment variable not set.")
        self._openai = OpenAI(api_key=api_key)
        return self._openai

    # ── Embedding ─────────────────────────────────────────────────────────────

    def embed(self, text: str) -> list[float]:
        """Embed a single text string."""
        return self.embed_batch([text])[0]

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """
        Embed a list of texts. Automatically batches to stay within OpenAI limits.
        Prepends a Swedish context hint to improve multilingual model performance.
        """
        client = self._get_openai()

        # Swedish hint improves multilingual embedding quality
        def _hint(t: str) -> str:
            return f"Swedish document: {t}" if not t.startswith("Swedish") else t

        results: list[list[float]] = []
        for i in range(0, len(texts), _EMBED_BATCH_SIZE):
            batch = [_hint(t) for t in texts[i:i + _EMBED_BATCH_SIZE]]
            response = client.embeddings.create(model=self._embed_model, input=batch)
            results.extend(item.embedding for item in response.data)

        return results

    # ── Upsert ────────────────────────────────────────────────────────────────

    def upsert_chunks(
        self,
        chunks,              # list[Chunk] from SwedishChunker
        doc_id: str = "",
    ) -> int:
        """
        Embed and upsert a list of Chunk objects into Pinecone.
        Returns the number of vectors upserted.
        """
        if not chunks:
            return 0

        index = self._get_index()
        texts = [c.text for c in chunks]
        embeddings = self.embed_batch(texts)

        vectors = []
        for chunk, embedding in zip(chunks, embeddings):
            vid = _make_vector_id(doc_id, chunk.index)
            meta = {
                "text":          chunk.text[:1000],
                "index":         chunk.index,
                "doc_id":        doc_id,
                "page_number":   chunk.page_number,
                "section_title": chunk.section_title,
                **{k: v for k, v in chunk.metadata.items() if v is not None},
            }
            vectors.append({"id": vid, "values": embedding, "metadata": meta})

        # Batch upsert
        total = 0
        for i in range(0, len(vectors), _BATCH_SIZE):
            batch = vectors[i:i + _BATCH_SIZE]
            index.upsert(vectors=batch, namespace=self._namespace)
            total += len(batch)
            log.debug("Upserted batch %d/%d (%d vectors)", i // _BATCH_SIZE + 1,
                      -(-len(vectors) // _BATCH_SIZE), len(batch))

        return total

    def chunk_and_upsert(
        self,
        text: str,
        doc_id: str,
        doc_type: str = "",
        municipality: str = "",
        year: Optional[int] = None,
        extra_metadata: Optional[dict] = None,
    ) -> int:
        """
        Full pipeline: chunk → embed → upsert.
        Returns vector count upserted.
        """
        from swedish_nlp.chunker import SwedishChunker, ChunkConfig

        chunker = SwedishChunker(
            ChunkConfig(chunk_size=self._chunk_size, chunk_overlap=self._chunk_overlap)
        )
        chunks = chunker.chunk_document(
            text,
            doc_id=doc_id,
            doc_type=doc_type,
            municipality=municipality,
            year=year,
            extra_metadata=extra_metadata,
        )
        return self.upsert_chunks(chunks, doc_id=doc_id)

    # ── Search ────────────────────────────────────────────────────────────────

    def search(
        self,
        query: str,
        top_k: int = 5,
        namespace: Optional[str] = None,
    ) -> list[VectorSearchResult]:
        """
        Semantic search — returns top_k most similar chunks.

        Args:
            query:     Swedish query text.
            top_k:     Number of results.
            namespace: Override instance namespace.
        """
        index = self._get_index()
        query_vec = self.embed(query)
        ns = namespace or self._namespace

        response = index.query(
            vector=query_vec,
            top_k=top_k,
            namespace=ns,
            include_metadata=True,
        )
        return [VectorSearchResult.from_pinecone_match(m) for m in response.matches]

    def search_with_filter(
        self,
        query: str,
        top_k: int = 5,
        doc_type: Optional[str] = None,
        municipality: Optional[str] = None,
        year: Optional[int] = None,
        doc_id: Optional[str] = None,
        extra_filter: Optional[dict] = None,
        namespace: Optional[str] = None,
    ) -> list[VectorSearchResult]:
        """
        Semantic search with Pinecone metadata filters.

        Swedish document filters:
            doc_type      — "protokoll" | "årsredovisning" | etc.
            municipality  — "Göteborg" | "Stockholm" | etc.
            year          — 2023
            doc_id        — exact document ID

        Example::

            results = pipeline.search_with_filter(
                "underskott i socialnämnden",
                doc_type="årsredovisning",
                municipality="Göteborg",
                year=2023,
            )
        """
        filter_dict: dict[str, Any] = {}
        if doc_type:
            filter_dict["doc_type"] = {"$eq": doc_type}
        if municipality:
            filter_dict["municipality"] = {"$eq": municipality}
        if year:
            filter_dict["year"] = {"$eq": year}
        if doc_id:
            filter_dict["doc_id"] = {"$eq": doc_id}
        if extra_filter:
            filter_dict.update(extra_filter)

        index = self._get_index()
        query_vec = self.embed(query)
        ns = namespace or self._namespace

        response = index.query(
            vector=query_vec,
            top_k=top_k,
            namespace=ns,
            filter=filter_dict or None,
            include_metadata=True,
        )
        return [VectorSearchResult.from_pinecone_match(m) for m in response.matches]

    # ── Management ────────────────────────────────────────────────────────────

    def delete_by_doc_id(self, doc_id: str) -> None:
        """Delete all vectors for a given document ID."""
        index = self._get_index()
        # Pinecone requires fetch-then-delete pattern for metadata filtering
        results = index.query(
            vector=[0.0] * self._embed_dim,
            top_k=1000,
            namespace=self._namespace,
            filter={"doc_id": {"$eq": doc_id}},
            include_values=False,
        )
        ids = [m.id for m in results.matches]
        if ids:
            index.delete(ids=ids, namespace=self._namespace)
            log.info("Deleted %d vectors for doc_id=%s", len(ids), doc_id)

    def get_index_stats(self) -> dict[str, Any]:
        """Return Pinecone index stats including vector counts per namespace."""
        index = self._get_index()
        stats = index.describe_index_stats()
        return {
            "total_vectors": stats.total_vector_count,
            "namespaces": {
                ns: info.vector_count
                for ns, info in (stats.namespaces or {}).items()
            },
            "dimension": stats.dimension,
        }


# ── Helper ────────────────────────────────────────────────────────────────────

def _make_vector_id(doc_id: str, chunk_index: int) -> str:
    """Generate a stable, unique vector ID from doc_id + chunk position."""
    base = f"{doc_id}::chunk::{chunk_index}"
    return hashlib.md5(base.encode()).hexdigest()[:16] + f"_c{chunk_index}"
