# Filepath: swedish_nlp/__init__.py
# Condensed Description: Public API surface for swedish-nlp-utils
# Architecture Layer: Utility (standalone Python package)
# Environment: Both

"""
swedish-nlp-utils
=================
Swedish NLP utilities for text processing, entity extraction, and vector pipelines.

Quick start::

    from swedish_nlp import (
        SwedishStopwords, SwedishNormalizer, SwedishNER,
        SwedishFormats, SwedishChunker
    )

    normalizer = SwedishNormalizer()
    print(normalizer.normalize_municipality("Göteborgs stad"))  # "Göteborg"

    ner = SwedishNER()
    entities = ner.extract("Socialnämnden fattade beslut enligt SoL 4 kap. 1 §")
    print(entities.authorities)   # ["Socialnämnden"]
    print(entities.law_refs)      # ["SoL 4 kap. 1 §"]
"""

from swedish_nlp.stopwords.stopwords import SwedishStopwords
from swedish_nlp.normalizer.normalizer import SwedishNormalizer
from swedish_nlp.ner.ner import SwedishNER, SwedishEntities
from swedish_nlp.formats.formats import SwedishFormats
from swedish_nlp.chunker.chunker import SwedishChunker, Chunk

__version__ = "1.0.0"
__author__ = "Trollfabriken AITrix AB"

__all__ = [
    "SwedishStopwords",
    "SwedishNormalizer",
    "SwedishNER",
    "SwedishEntities",
    "SwedishFormats",
    "SwedishChunker",
    "Chunk",
]
