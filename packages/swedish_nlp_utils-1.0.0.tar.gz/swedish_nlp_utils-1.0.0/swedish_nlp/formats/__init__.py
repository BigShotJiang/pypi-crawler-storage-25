# Filepath: swedish_nlp/formats/__init__.py
from swedish_nlp.formats.formats import SwedishFormats
__all__ = ["SwedishFormats"]
