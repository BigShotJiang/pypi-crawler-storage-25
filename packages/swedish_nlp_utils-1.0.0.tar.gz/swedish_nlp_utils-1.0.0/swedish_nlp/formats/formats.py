# Filepath: swedish_nlp/formats/formats.py
# Condensed Description: Parse and format Swedish dates, numbers, currencies,
#   personnummer, orgnummer, and postal codes
# Architecture Layer: Utility
# Environment: Both
# Script Hierarchy:
#    - Classes: SwedishFormats
#    - Methods: parse_date, format_date, parse_number, format_number,
#               parse_sek, format_sek, validate_personnummer,
#               pseudonymize_personnummer, validate_orgnummer,
#               parse_postal_code, extract_all_numbers

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Optional


# ── Month name maps ────────────────────────────────────────────────────────────
_MONTH_SWE_TO_NUM: dict[str, int] = {
    "januari": 1, "februari": 2, "mars": 3, "april": 4,
    "maj": 5, "juni": 6, "juli": 7, "augusti": 8,
    "september": 9, "oktober": 10, "november": 11, "december": 12,
    # Short forms
    "jan": 1, "feb": 2, "mar": 3, "apr": 4,
    "jun": 6, "jul": 7, "aug": 8,
    "sep": 9, "okt": 10, "nov": 11, "dec": 12,
}
_MONTH_NUM_TO_SWE: dict[int, str] = {
    1: "januari", 2: "februari", 3: "mars", 4: "april",
    5: "maj", 6: "juni", 7: "juli", 8: "augusti",
    9: "september", 10: "oktober", 11: "november", 12: "december",
}

# ── Patterns ──────────────────────────────────────────────────────────────────
_DATE_ISO        = re.compile(r"(\d{4})[-./](\d{2})[-./](\d{2})")
_DATE_WORD       = re.compile(
    r"(\d{1,2})\s+(januari|februari|mars|april|maj|juni|juli|augusti|"
    r"september|oktober|november|december|"
    r"jan|feb|mar|apr|jun|jul|aug|sep|okt|nov|dec)\s+(\d{4})",
    re.IGNORECASE,
)
_DATE_REVERSE    = re.compile(r"(\d{4})\s+(januari|februari|mars|april|maj|juni|juli|augusti|"
                               r"september|oktober|november|december)\s+(\d{1,2})", re.IGNORECASE)

# Swedish numbers: 1 234 567,89  or  1.234.567,89  or  1 234 567.89
_NUMBER_SWE      = re.compile(r"-?\d[\d\s]*(?:[,\.]\d{1,4})?")
_SEK_AMOUNT      = re.compile(
    r"(-?[\d\s]+(?:[,\.]\d{1,2})?)\s*(?:kr(?:onor)?|SEK)\b",
    re.IGNORECASE,
)

# Personnummer  YYYYMMDD-XXXX  or  YYMMDD-XXXX  or  YYYYMMDDXXXX
_PERSONNR_LONG   = re.compile(r"\b((?:19|20)\d{6})[-–](\d{4})\b")
_PERSONNR_SHORT  = re.compile(r"\b(\d{6})[-–](\d{4})\b")
_PERSONNR_CONCAT = re.compile(r"\b((?:19|20)\d{6})(\d{4})\b")

# Orgnummer  XXXXXX-XXXX
_ORGNR           = re.compile(r"\b(\d{6})[-–](\d{4})\b")

# Postal code  XXX XX
_POSTAL          = re.compile(r"\b(\d{3})\s*(\d{2})\b")

# Phone  +46 XX XXX XX XX  or  0X-XX XX XX
_PHONE           = re.compile(
    r"(?:\+46|0)[\s-]?\d{1,3}[\s-]?\d{2,4}[\s-]?\d{2,4}(?:[\s-]?\d{2})?"
)


class SwedishFormats:
    """
    Parse and format Swedish dates, numbers, currencies, and identity numbers.

    All methods are stateless — can be called as class or instance methods.

    Usage::

        f = SwedishFormats()

        # Dates
        f.parse_date("15 mars 2024")        → date(2024, 3, 15)
        f.parse_date("2024-03-15")          → date(2024, 3, 15)
        f.format_date(date(2024, 3, 15))    → "2024-03-15"
        f.format_date_long(date(2024,3,15)) → "15 mars 2024"

        # Numbers
        f.parse_number("1 234 567,89")      → 1234567.89
        f.format_number(1234567.89)         → "1 234 567,89"

        # SEK
        f.parse_sek("1 234 kr")             → 1234.0
        f.format_sek(1234.0)                → "1 234 kr"
        f.format_sek(1234567.0, unit="tkr") → "1 234 567 tkr"

        # Personnummer
        f.validate_personnummer("19850312-4567") → True
        f.pseudonymize_personnummer("19850312-4567") → "1985-XX-XXXX"

        # Orgnummer
        f.validate_orgnummer("556000-0000")  → True
    """

    # ── Date parsing ──────────────────────────────────────────────────────────

    @staticmethod
    def parse_date(text: str) -> Optional[date]:
        """
        Parse a Swedish date string into a Python date object.
        Handles ISO (2024-03-15), word (15 mars 2024), and dotted (15.03.2024) formats.
        """
        text = text.strip()

        # ISO / dotted / slashed
        m = _DATE_ISO.match(text)
        if m:
            try:
                return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            except ValueError:
                pass

        # Word format: 15 mars 2024
        m = _DATE_WORD.match(text)
        if m:
            month = _MONTH_SWE_TO_NUM.get(m.group(2).lower())
            if month:
                try:
                    return date(int(m.group(3)), month, int(m.group(1)))
                except ValueError:
                    pass

        # Reverse word: 2024 mars 15
        m = _DATE_REVERSE.match(text)
        if m:
            month = _MONTH_SWE_TO_NUM.get(m.group(2).lower())
            if month:
                try:
                    return date(int(m.group(1)), month, int(m.group(3)))
                except ValueError:
                    pass

        return None

    @staticmethod
    def format_date(d: date) -> str:
        """Format a date as ISO 8601 (YYYY-MM-DD) — the Swedish standard."""
        return d.strftime("%Y-%m-%d")

    @staticmethod
    def format_date_long(d: date) -> str:
        """Format a date in long Swedish form: '15 mars 2024'."""
        month_name = _MONTH_NUM_TO_SWE[d.month]
        return f"{d.day} {month_name} {d.year}"

    @staticmethod
    def extract_dates(text: str) -> list[str]:
        """Extract all date-like strings from text, returned as ISO strings."""
        results: list[str] = []
        for m in _DATE_ISO.finditer(text):
            results.append(f"{m.group(1)}-{m.group(2)}-{m.group(3)}")
        for m in _DATE_WORD.finditer(text):
            month = _MONTH_SWE_TO_NUM.get(m.group(2).lower())
            if month:
                results.append(f"{m.group(3)}-{month:02d}-{int(m.group(1)):02d}")
        seen: set[str] = set()
        return [d for d in results if not (d in seen or seen.add(d))]  # type: ignore

    # ── Number parsing / formatting ───────────────────────────────────────────

    @staticmethod
    def parse_number(text: str) -> Optional[float]:
        """
        Parse a Swedish-formatted number string to float.
        Handles space-thousands separators and comma decimals.

        Examples:
            "1 234 567,89"  → 1234567.89
            "1.234.567,89"  → 1234567.89
            "1234.56"       → 1234.56     (dot decimal, no thousands)
        """
        text = text.strip()
        # Detect format: if last separator is comma, treat comma as decimal
        if re.search(r",\d{1,2}$", text):
            # European format: 1 234,56 or 1.234,56
            cleaned = re.sub(r"[\s.]", "", text).replace(",", ".")
        else:
            # Either plain integer with spaces, or dot decimal
            cleaned = re.sub(r"[\s]", "", text)

        try:
            return float(cleaned)
        except ValueError:
            return None

    @staticmethod
    def format_number(
        value: float,
        decimals: int = 2,
        decimal_sep: str = ",",
        thousands_sep: str = "\u00a0",  # non-breaking space
    ) -> str:
        """
        Format a float as a Swedish number string.

        Examples:
            format_number(1234567.89)  → "1\u00a0234\u00a0567,89"
            format_number(1234567.89, decimals=0) → "1\u00a0234\u00a0568"
        """
        if decimals > 0:
            formatted = f"{value:,.{decimals}f}"
        else:
            formatted = f"{round(value):,}"
        # Python uses comma as thousands — swap to Swedish convention
        result = formatted.replace(",", thousands_sep).replace(".", decimal_sep)
        return result

    # ── SEK / currency ────────────────────────────────────────────────────────

    @staticmethod
    def parse_sek(text: str) -> Optional[float]:
        """
        Parse a Swedish SEK amount string to float.

        Examples:
            "1 234 567 kr"  → 1234567.0
            "45 678,50 SEK" → 45678.50
            "123 000 kronor"→ 123000.0
        """
        m = _SEK_AMOUNT.search(text)
        if not m:
            return None
        return SwedishFormats.parse_number(m.group(1))

    @staticmethod
    def format_sek(
        amount: float,
        unit: str = "kr",
        decimals: int = 0,
    ) -> str:
        """
        Format a float as a Swedish SEK string.

        Args:
            amount:   Numeric value.
            unit:     "kr" | "SEK" | "tkr" | "mkr" | "kronor"
            decimals: Decimal places (0 for whole numbers, 2 for öre).

        Examples:
            format_sek(1234567.0)          → "1 234 567 kr"
            format_sek(1234.50, decimals=2) → "1 234,50 kr"
            format_sek(1234567.0, "tkr")   → "1 234 567 tkr"
        """
        num = SwedishFormats.format_number(amount, decimals=decimals)
        return f"{num}\u00a0{unit}"

    @staticmethod
    def extract_sek_amounts(text: str) -> list[float]:
        """Extract all SEK amounts from text as a list of floats."""
        results: list[float] = []
        for m in _SEK_AMOUNT.finditer(text):
            v = SwedishFormats.parse_number(m.group(1))
            if v is not None:
                results.append(v)
        return results

    # ── Personnummer ──────────────────────────────────────────────────────────

    @staticmethod
    def validate_personnummer(pnr: str) -> bool:
        """
        Validate a Swedish personnummer using the Luhn algorithm.
        Accepts formats: YYYYMMDD-XXXX, YYMMDD-XXXX, YYYYMMDDXXXX.
        """
        clean = re.sub(r"[-–\s]", "", pnr)
        # Normalise 12-digit → 10-digit (strip century prefix for Luhn check)
        if len(clean) == 12:
            clean = clean[2:]
        if len(clean) != 10 or not clean.isdigit():
            return False
        return _luhn_check(clean)

    @staticmethod
    def pseudonymize_personnummer(pnr: str) -> str:
        """
        Replace all but birth-year with X for GDPR-safe storage.

        Examples:
            "19850312-4567" → "1985-XX-XXXX"
            "850312-4567"   → "19XX-XX-XXXX"   (century unknown)
        """
        m = _PERSONNR_LONG.search(pnr)
        if m:
            return f"{m.group(1)[:4]}-XX-XXXX"
        m = _PERSONNR_SHORT.search(pnr)
        if m:
            return "19XX-XX-XXXX"
        return "XXXX-XX-XXXX"

    @staticmethod
    def extract_personnummer(text: str) -> list[str]:
        """Extract personnummer as pseudonymised strings."""
        results: list[str] = []
        for m in _PERSONNR_LONG.finditer(text):
            results.append(f"{m.group(1)[:4]}-XX-XXXX")
        if not results:
            for m in _PERSONNR_SHORT.finditer(text):
                results.append("19XX-XX-XXXX")
        return list(dict.fromkeys(results))

    # ── Organisationsnummer ───────────────────────────────────────────────────

    @staticmethod
    def validate_orgnummer(orgnr: str) -> bool:
        """
        Validate a Swedish organisationsnummer (Luhn check on 10-digit form).
        Accepts: XXXXXX-XXXX or XXXXXXXXXX.
        """
        clean = re.sub(r"[-–\s]", "", orgnr)
        if len(clean) != 10 or not clean.isdigit():
            return False
        # Third digit must be ≥ 2 (distinguishes from personnummer)
        if int(clean[2]) < 2:
            return False
        return _luhn_check(clean)

    @staticmethod
    def extract_orgnummer(text: str) -> list[str]:
        """Extract organisationsnummer from text."""
        pattern = re.compile(
            r"(?:org(?:anisations)?\.?\s*nr\.?|orgnr)[:\s]+(\d{6}[-–]\d{4})",
            re.IGNORECASE,
        )
        return list(dict.fromkeys(m.group(1) for m in pattern.finditer(text)))

    # ── Postal codes ──────────────────────────────────────────────────────────

    @staticmethod
    def parse_postal_code(text: str) -> Optional[str]:
        """
        Extract and normalise a Swedish 5-digit postal code.

        Returns canonical form "XXX XX" or None.
        """
        m = _POSTAL.search(text)
        if m:
            return f"{m.group(1)} {m.group(2)}"
        return None

    # ── Phone numbers ─────────────────────────────────────────────────────────

    @staticmethod
    def extract_phone_numbers(text: str) -> list[str]:
        """Extract Swedish phone number strings from text."""
        return list(dict.fromkeys(m.group() for m in _PHONE.finditer(text)))


# ── Luhn algorithm ────────────────────────────────────────────────────────────

def _luhn_check(number: str) -> bool:
    """Standard Luhn check — used for both personnummer and orgnummer."""
    digits = [int(c) for c in number]
    total = 0
    for i, d in enumerate(digits[:-1]):
        if i % 2 == 0:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return (total + digits[-1]) % 10 == 0
