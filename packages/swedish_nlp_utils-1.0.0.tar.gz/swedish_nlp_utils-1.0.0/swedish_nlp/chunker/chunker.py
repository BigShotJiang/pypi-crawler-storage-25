# Filepath: swedish_nlp/chunker/chunker.py
# Condensed Description: Swedish-optimised text chunker for RAG / vector indexing pipelines.
#   Respects paragraph, sentence, and section boundaries. Produces Chunk objects
#   with metadata for Pinecone upsert.
# Architecture Layer: Utility
# Environment: Both
# Script Hierarchy:
#    - Classes: Chunk, ChunkConfig, SwedishChunker
#    - Methods: chunk, chunk_by_paragraphs, chunk_by_sentences, chunk_by_tokens,
#               chunk_document, estimate_tokens

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional


# ── Data classes ──────────────────────────────────────────────────────────────

@dataclass
class Chunk:
    """A single text chunk ready for embedding."""
    text: str
    index: int                           # Position in the source document
    char_start: int = 0
    char_end: int = 0
    token_estimate: int = 0
    page_number: Optional[int] = None
    section_title: Optional[str] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_pinecone_dict(self, vector_id: str, embedding: list[float]) -> dict:
        """Format for Pinecone upsert."""
        return {
            "id": vector_id,
            "values": embedding,
            "metadata": {
                "text": self.text[:1000],   # Pinecone metadata limit
                "index": self.index,
                "page_number": self.page_number,
                "section_title": self.section_title,
                **self.metadata,
            },
        }


@dataclass
class ChunkConfig:
    """Configuration for SwedishChunker."""
    # Target chunk sizes
    chunk_size: int = 512                # target tokens per chunk
    chunk_overlap: int = 50              # overlap tokens between chunks
    min_chunk_size: int = 50             # drop chunks smaller than this
    max_chunk_size: int = 1024           # hard ceiling (split if exceeded)

    # Splitting preferences
    respect_paragraphs: bool = True      # prefer splitting on \n\n
    respect_sentences: bool = True       # prefer splitting on ". " / "! " / "? "
    respect_sections: bool = True        # detect § and heading boundaries

    # Swedish-specific
    preserve_law_references: bool = True # don't split "6 kap. 13 a § FB" across chunks
    preserve_numbered_lists: bool = True # keep "1. ... 2. ..." items together

    # Token estimation
    chars_per_token: float = 4.0        # rough estimate for Swedish (≈ 4 chars/token)


# ── Patterns for boundary detection ──────────────────────────────────────────

_PARAGRAPH_SPLIT = re.compile(r"\n{2,}")
_SENTENCE_END = re.compile(r"(?<=[.!?])\s+(?=[A-ZÅÄÖ\"'])")
_SECTION_HEADING = re.compile(
    r"(?m)^(?:§\s*\d+|[A-ZÅÄÖ]{2,}[A-ZÅÄÖ\s]{3,}|"  # § 12 or ALL-CAPS headings
    r"\d+\.\s+[A-ZÅÄÖ]|"                               # 1. Heading
    r"[A-ZÅÄÖ][a-zåäö]+(?:\s+[a-zåäö]+){0,3}\n[-=]{3,})"  # Underlined heading
)
_LAW_REF = re.compile(
    r"\d+\s*kap\.?\s*\d+\s*[a-z]?\s*§[^\n]{0,40}"
)
_NUMBERED_ITEM = re.compile(r"^\d+\.\s+", re.MULTILINE)


class SwedishChunker:
    """
    Text chunker optimised for Swedish administrative, legal, and municipal documents.

    Splitting priority:
      1. Document sections (§ boundaries, headings)
      2. Paragraph breaks (\\n\\n)
      3. Sentence boundaries
      4. Token-count hard split (last resort)

    Usage::

        chunker = SwedishChunker()
        chunks = chunker.chunk(text)

        # With document metadata embedded in each chunk
        chunks = chunker.chunk_document(
            text,
            doc_id="arsredovisning-2023",
            doc_type="årsredovisning",
            municipality="Göteborg",
        )

        # Customised config
        cfg = ChunkConfig(chunk_size=256, chunk_overlap=30)
        chunker = SwedishChunker(config=cfg)
    """

    def __init__(self, config: ChunkConfig | None = None):
        self.config = config or ChunkConfig()

    # ── Main entry points ─────────────────────────────────────────────────────

    def chunk(self, text: str) -> list[Chunk]:
        """
        Split text into Chunk objects using Swedish-aware boundary detection.
        Automatically selects the best splitting strategy.
        """
        text = text.strip()
        if not text:
            return []

        # Try section-aware split first for structured documents
        if self.config.respect_sections and _SECTION_HEADING.search(text):
            raw_chunks = self._split_by_sections(text)
        elif self.config.respect_paragraphs:
            raw_chunks = self._split_by_paragraphs(text)
        else:
            raw_chunks = [text]

        # Sub-split any over-sized chunks
        refined: list[str] = []
        for chunk_text in raw_chunks:
            if self._estimate_tokens(chunk_text) > self.config.max_chunk_size:
                refined.extend(self._split_by_sentences(chunk_text))
            else:
                refined.append(chunk_text)

        # Final token-level split for anything still too large
        final: list[str] = []
        for chunk_text in refined:
            if self._estimate_tokens(chunk_text) > self.config.max_chunk_size:
                final.extend(self._split_by_tokens(chunk_text))
            else:
                final.append(chunk_text)

        # Apply overlap
        overlapped = self._apply_overlap(final)

        # Filter and convert to Chunk objects
        return self._to_chunks(overlapped, text)

    def chunk_document(
        self,
        text: str,
        doc_id: str = "",
        doc_type: str = "",
        municipality: str = "",
        year: Optional[int] = None,
        extra_metadata: dict[str, Any] | None = None,
    ) -> list[Chunk]:
        """
        Chunk with document-level metadata attached to every chunk.
        Metadata is embedded into each Chunk.metadata for Pinecone filtering.
        """
        chunks = self.chunk(text)
        meta = {
            "doc_id": doc_id,
            "doc_type": doc_type,
            "municipality": municipality,
        }
        if year:
            meta["year"] = year
        if extra_metadata:
            meta.update(extra_metadata)
        for chunk in chunks:
            chunk.metadata.update(meta)
        return chunks

    # ── Strategy implementations ──────────────────────────────────────────────

    def _split_by_sections(self, text: str) -> list[str]:
        """Split on § numbers and major section headings."""
        parts = _SECTION_HEADING.split(text)
        headings = _SECTION_HEADING.findall(text)
        result: list[str] = []
        for i, part in enumerate(parts):
            heading = headings[i - 1].strip() if i > 0 and i - 1 < len(headings) else ""
            combined = f"{heading}\n{part.strip()}" if heading else part.strip()
            if combined.strip():
                result.append(combined)
        return result or [text]

    def _split_by_paragraphs(self, text: str) -> list[str]:
        """Split on double newlines (paragraph breaks)."""
        parts = _PARAGRAPH_SPLIT.split(text)
        # Merge very short paragraphs with the following one
        merged: list[str] = []
        buffer = ""
        for part in parts:
            part = part.strip()
            if not part:
                continue
            if buffer:
                combined = buffer + "\n\n" + part
                if self._estimate_tokens(combined) <= self.config.chunk_size:
                    buffer = combined
                else:
                    merged.append(buffer)
                    buffer = part
            else:
                buffer = part
        if buffer:
            merged.append(buffer)
        return merged or [text]

    def _split_by_sentences(self, text: str) -> list[str]:
        """Split on Swedish sentence boundaries."""
        sentences = _SENTENCE_END.split(text)
        chunks: list[str] = []
        current = ""
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            candidate = (current + " " + sentence).strip() if current else sentence
            if self._estimate_tokens(candidate) <= self.config.chunk_size:
                current = candidate
            else:
                if current:
                    chunks.append(current)
                current = sentence
        if current:
            chunks.append(current)
        return chunks or [text]

    def _split_by_tokens(self, text: str) -> list[str]:
        """Hard token-count split — last resort when semantic splitting fails."""
        target = int(self.config.chunk_size * self.config.chars_per_token)
        overlap_chars = int(self.config.chunk_overlap * self.config.chars_per_token)

        chunks: list[str] = []
        start = 0
        while start < len(text):
            end = start + target
            if end < len(text):
                # Prefer a word boundary
                boundary = text.rfind(" ", start, end)
                if boundary > start:
                    end = boundary
            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)
            start = end - overlap_chars if overlap_chars else end
            if start >= len(text) - 10:
                break
        return chunks or [text]

    def _apply_overlap(self, chunks: list[str]) -> list[str]:
        """Prepend a short tail from the previous chunk to each chunk."""
        if self.config.chunk_overlap <= 0 or len(chunks) <= 1:
            return chunks

        overlap_chars = int(self.config.chunk_overlap * self.config.chars_per_token)
        result: list[str] = [chunks[0]]
        for i in range(1, len(chunks)):
            tail = chunks[i - 1][-overlap_chars:].strip()
            # Find a clean word boundary in the tail
            space = tail.find(" ")
            if space > 0:
                tail = tail[space:].strip()
            result.append((tail + " " + chunks[i]).strip() if tail else chunks[i])
        return result

    # ── Utilities ─────────────────────────────────────────────────────────────

    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count from character count."""
        return max(1, int(len(text) / self.config.chars_per_token))

    @staticmethod
    def estimate_tokens(text: str, chars_per_token: float = 4.0) -> int:
        """Static utility: rough token estimate without instantiation."""
        return max(1, int(len(text) / chars_per_token))

    @staticmethod
    def estimate_tokens_tiktoken(text: str, model: str = "text-embedding-3-small") -> int:
        """
        Precise token count using tiktoken (requires: pip install tiktoken).
        Falls back to char estimate if tiktoken is not installed.
        """
        try:
            import tiktoken
            enc = tiktoken.encoding_for_model(model)
            return len(enc.encode(text))
        except (ImportError, KeyError):
            return SwedishChunker.estimate_tokens(text)

    def _to_chunks(self, texts: list[str], original_text: str) -> list[Chunk]:
        chunks = []
        pos = 0
        for i, text in enumerate(texts):
            text = text.strip()
            if len(text) < self.config.min_chunk_size:
                continue
            char_start = original_text.find(text[:min(50, len(text))], max(0, pos - 100))
            char_end = char_start + len(text) if char_start >= 0 else pos + len(text)
            pos = char_end

            chunks.append(Chunk(
                text=text,
                index=i,
                char_start=max(0, char_start),
                char_end=char_end,
                token_estimate=self._estimate_tokens(text),
            ))
        return chunks
