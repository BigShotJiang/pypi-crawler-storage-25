# Filepath: swedish_nlp/chunker/__init__.py
from swedish_nlp.chunker.chunker import SwedishChunker, Chunk
__all__ = ["SwedishChunker", "Chunk"]
