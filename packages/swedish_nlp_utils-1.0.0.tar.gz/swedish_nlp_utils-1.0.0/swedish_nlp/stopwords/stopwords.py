# Filepath: swedish_nlp/stopwords/stopwords.py
# Condensed Description: Swedish stopword sets — general, legal, municipal, and social services domains
# Architecture Layer: Utility
# Environment: Both
# Script Hierarchy:
#    - Classes: SwedishStopwords
#    - Methods: get, filter_tokens, filter_text, is_stopword, add_domain

from __future__ import annotations

import re
from enum import Enum


class Domain(str, Enum):
    GENERAL   = "general"
    LEGAL     = "legal"       # Court rulings, legislation
    MUNICIPAL = "municipal"   # Municipal documents, protocols
    SOCIAL    = "social"      # Social services, BBIC, welfare
    MEDICAL   = "medical"     # Medical/clinical records


# ── Core Swedish stopwords ─────────────────────────────────────────────────────
# Drawn from spaCy sv_core_news + curated additions for administrative Swedish.
_GENERAL: set[str] = {
    "och", "det", "att", "i", "en", "jag", "hon", "som", "han", "på",
    "den", "med", "var", "sig", "för", "så", "till", "är", "men", "ett",
    "om", "hade", "de", "av", "icke", "mig", "du", "henne", "då", "sin",
    "nu", "har", "inte", "hans", "honom", "skulle", "efter", "när", "upp",
    "vi", "dem", "vara", "vad", "över", "oss", "ska", "några", "vilket",
    "dessa", "samt", "kan", "eller", "vid", "mot", "sina", "dessa", "dock",
    "från", "ju", "se", "ta", "ut", "in", "där", "här", "under", "utan",
    "än", "ännu", "också", "redan", "bara", "just", "mycket", "mer", "mest",
    "alla", "allt", "aldrig", "alltid", "ibland", "ofta", "sällan", "kanske",
    "nog", "ändå", "annars", "dessutom", "emellertid", "exempelvis", "exkl",
    "förutom", "genom", "givet", "gäller", "hur", "vilket", "vem", "vars",
    "varför", "varje", "varken", "vart", "åt", "åtminstone", "även", "ej",
    "ex", "etc", "inkl", "m.m.", "bl.a.", "dvs", "osv", "pga", "ang",
    "ang.", "ca", "resp", "s.k.", "s.k", "t.ex", "t.o.m", "f.o.m",
    "the", "and", "of", "to", "in",   # common English OCR bleed-through
}

# ── Legal domain stopwords ─────────────────────────────────────────────────────
# Words frequent in Swedish court and legislative texts that add no signal.
_LEGAL: set[str] = {
    "enligt", "innebär", "avser", "framgår", "anges", "angivet",
    "gäller", "tillämpas", "stadgas", "föreskrivs", "bestäms",
    "regleras", "framgår", "hänvisas", "anmärkts", "konstateras",
    "bedömt", "bedöms", "finner", "funnit", "anser", "anses",
    "skäl", "grund", "anledning", "avseende", "avser", "beträffande",
    "därav", "däri", "därtill", "härigenom", "härav", "härmed",
    "härvidlag", "ovan", "nedan", "nämnda", "angiven", "angett",
    "ovanstående", "nedanstående", "ifrågavarande", "såvitt",
    "emellertid", "vidare", "slutligen", "sammanfattningsvis",
    "oaktat", "trots", "likväl", "varjämte", "ävensom",
}

# ── Municipal domain stopwords ─────────────────────────────────────────────────
# Words saturating meeting minutes and annual reports with no semantic lift.
_MUNICIPAL: set[str] = {
    "nämnden", "styrelsen", "fullmäktige", "förvaltningen",
    "mötet", "sammanträdet", "ärendet", "ärendenummer", "diarienummer",
    "protokoll", "beslutade", "beslutar", "godkänner", "noterar",
    "uppdrar", "uppdrag", "informerades", "redogjordes", "föredrogs",
    "föreligger", "bifogat", "bilagt", "bilaga", "handling", "handlingar",
    "föreslår", "föreslogs", "föreslagen", "föreslog",
    "yrkade", "yrkanden", "proposition", "votering",
    "punkten", "dagordningen", "föredragningslistan",
    "redovisning", "rapport", "information", "informations",
    "tkr", "kkr", "mnkr", "msek", "sek", "kr",
}

# ── Social services domain stopwords ──────────────────────────────────────────
# High-frequency boilerplate in social services investigations.
_SOCIAL: set[str] = {
    "utredning", "utredningen", "utredaren", "handläggaren", "handläggare",
    "insats", "insatser", "stöd", "hjälp", "bistånd",
    "bedömning", "bedömer", "bedömdes", "beaktat", "beaktas",
    "socialtjänsten", "socialsekreterare", "socialnämnden",
    "barnets", "barnet", "föräldrarna", "föräldern", "vårdnadshavaren",
    "familjen", "hemmet", "hemförhållandena",
    "anmälan", "anmälare", "anmält",
    "kontakt", "kontaktades", "kontaktat",
    "uppföljning", "uppföljdes", "uppföljer",
    "akt", "akten", "journalen", "journalanteckning",
    "genomförts", "genomföra", "genomfört",
}

# ── Medical domain stopwords ───────────────────────────────────────────────────
_MEDICAL: set[str] = {
    "patient", "patienten", "besöket", "besök", "kontakten",
    "läkaren", "sjuksköterskan", "läkare", "sjuksköterska",
    "journalen", "anteckning", "antecknat", "dokumenterat",
    "behandling", "behandlades", "ordination", "ordinerades",
    "symtom", "symtomen", "besvär", "klagar",
    "anamnes", "status", "bedömning", "diagnos",
    "remiss", "remitteras", "remitterades", "återbesök",
    "datum", "klockan", "tidpunkt",
}

_DOMAIN_MAP: dict[Domain, set[str]] = {
    Domain.GENERAL:   _GENERAL,
    Domain.LEGAL:     _LEGAL,
    Domain.MUNICIPAL: _MUNICIPAL,
    Domain.SOCIAL:    _SOCIAL,
    Domain.MEDICAL:   _MEDICAL,
}


class SwedishStopwords:
    """
    Swedish stopword manager with domain-specific extensions.

    Usage::

        sw = SwedishStopwords()                         # general only
        sw = SwedishStopwords([Domain.GENERAL, Domain.LEGAL])
        sw = SwedishStopwords.for_domain("municipal")   # convenience

        # Filter a token list
        tokens = ["socialnämnden", "beslutade", "att", "bevilja", "insats"]
        clean  = sw.filter_tokens(tokens)               # ["bevilja"]

        # Filter raw text, returns cleaned string
        clean_text = sw.filter_text("nämnden beslutade att godkänna rapporten")
    """

    def __init__(self, domains: list[Domain | str] | None = None):
        if domains is None:
            domains = [Domain.GENERAL]
        self._words: set[str] = set()
        for d in domains:
            self._words |= _DOMAIN_MAP[Domain(d)]
        self._custom: set[str] = set()

    # ── Constructors ──────────────────────────────────────────────────────────

    @classmethod
    def for_domain(cls, domain: str | Domain) -> "SwedishStopwords":
        return cls([Domain(domain)])

    @classmethod
    def all_domains(cls) -> "SwedishStopwords":
        return cls(list(Domain))

    @classmethod
    def for_legal(cls) -> "SwedishStopwords":
        return cls([Domain.GENERAL, Domain.LEGAL])

    @classmethod
    def for_municipal(cls) -> "SwedishStopwords":
        return cls([Domain.GENERAL, Domain.MUNICIPAL])

    @classmethod
    def for_social_services(cls) -> "SwedishStopwords":
        return cls([Domain.GENERAL, Domain.LEGAL, Domain.SOCIAL])

    # ── Core API ──────────────────────────────────────────────────────────────

    @property
    def words(self) -> frozenset[str]:
        return frozenset(self._words | self._custom)

    def is_stopword(self, token: str) -> bool:
        return token.lower().strip(".,;:!?()[]\"'") in self.words

    def add(self, *words: str) -> "SwedishStopwords":
        """Fluently add custom stopwords."""
        self._custom.update(w.lower() for w in words)
        return self

    def add_domain(self, domain: Domain | str) -> "SwedishStopwords":
        """Fluently add an entire domain."""
        self._words |= _DOMAIN_MAP[Domain(domain)]
        return self

    def remove(self, *words: str) -> "SwedishStopwords":
        """Remove words that shouldn't be treated as stopwords."""
        for w in words:
            self._words.discard(w.lower())
            self._custom.discard(w.lower())
        return self

    def filter_tokens(
        self,
        tokens: list[str],
        min_length: int = 2,
        keep_numbers: bool = False,
    ) -> list[str]:
        """
        Remove stopwords from a list of string tokens.

        Args:
            tokens:       List of word strings.
            min_length:   Drop tokens shorter than this.
            keep_numbers: If False, also drops pure-digit tokens.
        """
        result = []
        for t in tokens:
            cleaned = t.strip(".,;:!?()[]\"'")
            lower = cleaned.lower()
            if len(cleaned) < min_length:
                continue
            if not keep_numbers and lower.isdigit():
                continue
            if lower not in self.words:
                result.append(t)
        return result

    def filter_text(
        self,
        text: str,
        min_length: int = 2,
        keep_numbers: bool = False,
    ) -> str:
        """Tokenise on whitespace, filter, rejoin."""
        tokens = text.split()
        filtered = self.filter_tokens(tokens, min_length=min_length, keep_numbers=keep_numbers)
        return " ".join(filtered)

    def __len__(self) -> int:
        return len(self.words)

    def __contains__(self, item: str) -> bool:
        return self.is_stopword(item)
