# Filepath: swedish_nlp/stopwords/__init__.py
from swedish_nlp.stopwords.stopwords import SwedishStopwords
__all__ = ["SwedishStopwords"]
