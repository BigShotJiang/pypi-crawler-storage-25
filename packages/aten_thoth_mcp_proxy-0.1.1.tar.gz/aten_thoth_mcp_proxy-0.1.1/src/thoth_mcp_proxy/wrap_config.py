# thoth_mcp_proxy/wrap_config.py
"""
Pure JSON transform: wrap every mcpServer entry with thoth run.
"""

from __future__ import annotations

from typing import Any


def _is_already_governed(entry: dict[str, Any]) -> bool:
    """Return True if the entry is already wrapped by any thoth deployment method."""
    cmd = entry.get("command", "")
    args = entry.get("args") or []

    # Pattern 1: native thoth install
    if cmd == "thoth" and args and args[0] == "run":
        return True

    # Pattern 2: old thoth-mcp-proxy alias
    if cmd == "thoth-mcp-proxy" and args and args[0] == "run":
        return True

    # Pattern 3: uvx-deployed proxy (aten-thoth-mcp-proxy appears before --)
    if cmd == "uvx":
        try:
            sep = args.index("--")
            pre_sep = args[:sep]
        except ValueError:
            pre_sep = args
        if "aten-thoth-mcp-proxy" in pre_sep:
            return True

    return False


def wrap_config(
    config: dict[str, Any],
    *,
    tenant_id: str,
    agent_id: str | None = None,
    api_key: str | None = None,
    enforcer_url: str | None = None,
    enforcement_mode: str = "progressive",
    session_intent: str | None = None,
    intent_map: dict[str, str] | None = None,
) -> dict[str, Any]:
    """
    Transform a claude_desktop_config dict, wrapping each mcpServer entry
    with ``thoth run``.  Already-governed entries are skipped (idempotent).

    Args:
        config: The parsed claude_desktop_config.json dict.
        tenant_id: Thoth tenant identifier (required).
        agent_id: Global agent-id override. When None, each server uses its own name.
        api_key: Thoth API key. When None, omitted from output args.
        enforcer_url: Enforcer URL override. When None, omitted from output args.
        enforcement_mode: Enforcement mode.
        session_intent: Global session intent for all servers not in intent_map.
        intent_map: Mapping of server name -> session_intent (overrides global).
    """
    servers: dict[str, Any] = config.get("mcpServers") or {}
    wrapped: dict[str, Any] = {}

    for name, entry in servers.items():
        if _is_already_governed(entry):
            wrapped[name] = entry
            continue

        upstream_cmd = entry.get("command", "")
        upstream_args: list[str] = list(entry.get("args") or [])

        # Build thoth run args
        run_args: list[str] = ["run"]
        run_args += ["--agent-id", agent_id if agent_id is not None else name]
        run_args += ["--tenant-id", tenant_id]

        # Per-server intent: intent_map takes precedence over global session_intent
        intent: str | None = None
        if intent_map and name in intent_map:
            intent = intent_map[name]
        elif session_intent:
            intent = session_intent
        if intent:
            run_args += ["--session-intent", intent]

        run_args += ["--enforcement-mode", enforcement_mode]

        if api_key:
            run_args += ["--api-key", api_key]
        if enforcer_url:
            run_args += ["--enforcer-url", enforcer_url]

        # Append original command after --
        run_args += ["--", upstream_cmd, *upstream_args]

        new_entry: dict[str, Any] = {"command": "thoth", "args": run_args}
        if "env" in entry:
            new_entry["env"] = entry["env"]

        wrapped[name] = new_entry

    return {**config, "mcpServers": wrapped}
