"""Endpoint registration and heartbeat helpers for govapi fleet telemetry."""

from __future__ import annotations

from dataclasses import dataclass
import logging
import os
import platform
import random
import socket
from typing import Callable

import anyio
import httpx

from thoth_mcp_proxy.credentials import resolve_credential
from thoth_mcp_proxy.tls import TLSCertPinVerifier, TLSConfig, httpx_verify_value, resolve_tls_config

logger = logging.getLogger(__name__)


def _env_bool(name: str, *, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def _env_float(name: str, *, default: float) -> float:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _env_int(name: str, *, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def resolve_govapi_url(default: str | None = None) -> str | None:
    url = os.getenv("THOTH_GOVAPI_URL") or default
    if not url:
        return None
    return url.rstrip("/")


def build_govapi_headers(*, fallback_api_key: str | None = None, fallback_api_key_id: str | None = None) -> dict[str, str]:
    headers: dict[str, str] = {}
    bearer = os.getenv("THOTH_GOVAPI_BEARER_TOKEN", "").strip()
    credential = resolve_credential(
        explicit_value=fallback_api_key,
        explicit_key_id=fallback_api_key_id,
        value_env="THOTH_GOVAPI_API_KEY",
        file_env="THOTH_GOVAPI_API_KEY_FILE",
        key_id_env="THOTH_GOVAPI_API_KEY_ID",
        expires_env="THOTH_GOVAPI_API_KEY_EXPIRES_AT",
    )
    api_key = credential.value or ""
    if bearer:
        headers["Authorization"] = f"Bearer {bearer}"
    if api_key:
        headers["x-api-key"] = api_key
    if credential.key_id:
        headers["x-api-key-id"] = credential.key_id
    return headers


def normalize_os_name(raw: str) -> str:
    value = raw.strip().lower()
    if value == "darwin":
        return "macos"
    if value.startswith("win"):
        return "windows"
    if value.startswith("linux"):
        return "linux"
    return value or "unknown"


@dataclass(frozen=True)
class EndpointIdentity:
    endpoint_id: str
    hostname: str
    os_name: str
    os_version: str
    enrollment: str
    environment: str
    fleet_id: str | None
    provider: str | None
    employee_name: str | None
    employee_email: str | None
    department: str | None


def resolve_endpoint_identity() -> EndpointIdentity:
    hostname = os.getenv("THOTH_ENDPOINT_HOSTNAME", "").strip() or socket.gethostname()
    endpoint_id = os.getenv("THOTH_ENDPOINT_ID", "").strip() or hostname
    enrollment = os.getenv("THOTH_ENROLLMENT_SOURCE", "manual").strip().lower()
    environment = os.getenv("THOTH_ENV", "prod").strip().lower()
    provider = os.getenv("THOTH_PROVIDER", "").strip() or enrollment
    fleet_id = os.getenv("THOTH_FLEET_ID", "").strip() or None

    os_name = normalize_os_name(os.getenv("THOTH_ENDPOINT_OS", "") or platform.system())
    os_version = os.getenv("THOTH_ENDPOINT_OS_VERSION", "").strip() or platform.release()

    employee_name = os.getenv("THOTH_EMPLOYEE_NAME", "").strip() or None
    employee_email = os.getenv("THOTH_EMPLOYEE_EMAIL", "").strip() or None
    department = os.getenv("THOTH_DEPARTMENT", "").strip() or None

    return EndpointIdentity(
        endpoint_id=endpoint_id,
        hostname=hostname,
        os_name=os_name,
        os_version=os_version,
        enrollment=enrollment,
        environment=environment,
        fleet_id=fleet_id,
        provider=provider,
        employee_name=employee_name,
        employee_email=employee_email,
        department=department,
    )


@dataclass(frozen=True)
class CheckinTelemetry:
    proxy_version: str
    agent_ids: list[str]
    risk_score: float
    violations_today: int
    sessions_today: int
    policy_version: int | None = None
    policy_source: str | None = None
    policy_profile_id: str | None = None
    policy_signature_valid: bool | None = None
    policy_rollback_active: bool | None = None
    api_key_id: str | None = None
    api_key_source: str | None = None
    api_key_expired: bool | None = None
    api_key_revoked: bool | None = None


class FleetReporter:
    """Handles endpoint registration and periodic check-ins to govapi."""

    def __init__(
        self,
        *,
        govapi_url: str | None,
        tenant_id: str,
        endpoint: EndpointIdentity,
        proxy_version: str,
        enforcement_mode: str,
        headers: dict[str, str] | None = None,
        timeout: httpx.Timeout | None = None,
        tls_config: TLSConfig | None = None,
    ) -> None:
        self.govapi_url = govapi_url.rstrip("/") if govapi_url else None
        self.tenant_id = tenant_id
        self.endpoint = endpoint
        self.proxy_version = proxy_version
        self.enforcement_mode = enforcement_mode
        self._tls_config = tls_config or resolve_tls_config()
        self._tls_pin_verifier = TLSCertPinVerifier(self._tls_config)
        self._enabled = bool(self.govapi_url and tenant_id) and _env_bool("THOTH_ENDPOINT_REGISTRATION_ENABLED", default=True)
        self._http = httpx.AsyncClient(
            base_url=self.govapi_url or "http://localhost",
            headers=headers or {},
            timeout=timeout or httpx.Timeout(connect=3.0, read=5.0, write=3.0, pool=3.0),
            verify=httpx_verify_value(self._tls_config),
        )

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def endpoint_id(self) -> str:
        return self.endpoint.endpoint_id

    async def register(self) -> bool:
        """Upsert endpoint metadata in govapi (idempotent re-registration)."""
        if not self._enabled:
            return False
        if self._tls_pin_verifier.enabled:
            self._tls_pin_verifier.verify(self.govapi_url or "")

        payload = {
            "endpoint_id": self.endpoint.endpoint_id,
            "hostname": self.endpoint.hostname,
            "employee_name": self.endpoint.employee_name or "",
            "employee_email": self.endpoint.employee_email or "",
            "department": self.endpoint.department or "",
            "os": self.endpoint.os_name,
            "os_version": self.endpoint.os_version,
            "enrollment": self.endpoint.enrollment,
            "environment": self.endpoint.environment,
            "proxy_version": self.proxy_version,
            "enforcement_mode": self.enforcement_mode,
            "fleet_id": self.endpoint.fleet_id or "",
            "provider": self.endpoint.provider or "",
        }
        resp = await self._http.post(f"/{self.tenant_id}/thoth/endpoints", json=payload)
        resp.raise_for_status()
        return True

    async def checkin(self, telemetry: CheckinTelemetry) -> bool:
        """
        Send a heartbeat check-in. If endpoint is missing, re-register once then retry.
        """
        if not self._enabled:
            return False
        if self._tls_pin_verifier.enabled:
            self._tls_pin_verifier.verify(self.govapi_url or "")

        payload = {
            "proxy_version": telemetry.proxy_version,
            "agent_ids": telemetry.agent_ids,
            "risk_score": telemetry.risk_score,
            "violations_today": telemetry.violations_today,
            "sessions_today": telemetry.sessions_today,
        }
        if telemetry.policy_version is not None:
            payload["policy_version"] = telemetry.policy_version
        if telemetry.policy_source:
            payload["policy_source"] = telemetry.policy_source
        if telemetry.policy_profile_id:
            payload["policy_profile_id"] = telemetry.policy_profile_id
        if telemetry.policy_signature_valid is not None:
            payload["policy_signature_valid"] = telemetry.policy_signature_valid
        if telemetry.policy_rollback_active is not None:
            payload["policy_rollback_active"] = telemetry.policy_rollback_active
        if telemetry.api_key_id:
            payload["api_key_id"] = telemetry.api_key_id
        if telemetry.api_key_source:
            payload["api_key_source"] = telemetry.api_key_source
        if telemetry.api_key_expired is not None:
            payload["api_key_expired"] = telemetry.api_key_expired
        if telemetry.api_key_revoked is not None:
            payload["api_key_revoked"] = telemetry.api_key_revoked

        checkin_path = f"/{self.tenant_id}/thoth/endpoints/{self.endpoint.endpoint_id}/checkin"
        try:
            resp = await self._http.post(checkin_path, json=payload)
            resp.raise_for_status()
            return True
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code != 404:
                raise
            await self.register()
            retry = await self._http.post(checkin_path, json=payload)
            retry.raise_for_status()
            return True

    async def checkin_loop(self, stop_event: anyio.Event, telemetry_fn: Callable[[], CheckinTelemetry]) -> None:
        """Periodic check-in loop with jitter and exponential backoff."""
        if not self._enabled:
            return

        base_interval = max(15, _env_int("THOTH_HEARTBEAT_INTERVAL_SECONDS", default=60))
        jitter_pct = max(0.0, min(0.9, _env_float("THOTH_HEARTBEAT_JITTER_PCT", default=0.2)))
        max_backoff = max(base_interval, _env_int("THOTH_HEARTBEAT_MAX_BACKOFF_SECONDS", default=300))
        failures = 0

        while not stop_event.is_set():
            try:
                await self.checkin(telemetry_fn())
                failures = 0
                delay = float(base_interval)
            except Exception:
                failures = min(failures + 1, 8)
                delay = float(min(max_backoff, base_interval * (2**failures)))
                logger.warning("thoth-proxy: endpoint check-in failed (attempt=%s)", failures, exc_info=True)

            jitter = delay * jitter_pct
            next_delay = max(1.0, delay + random.uniform(-jitter, jitter))
            with anyio.move_on_after(next_delay):
                await stop_event.wait()

    async def aclose(self) -> None:
        await self._http.aclose()

    def update_headers(self, headers: dict[str, str]) -> None:
        self._http.headers.clear()
        self._http.headers.update(headers)
