"""Smoke tests for the scoped settings Django admin (C8).

These are intentionally minimal — the admin surface is operators'
emergency-access view onto the data, not a user-facing UI. Verify:

- ScopedSetting and Device are registered with the admin site.
- list_display columns render without crashing for every scope type.
- Custom `ref_display` column returns the right label per scope.
"""

import pytest
from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group

from conjunto.settings.admin import DeviceAdmin, ScopedSettingAdmin
from conjunto.settings.scoped.models import Device, Scope, ScopedSetting
from conjunto.tenants.models import Tenant


pytestmark = pytest.mark.django_db


def test_scopedsetting_and_device_registered():
    assert ScopedSetting in admin.site._registry
    assert isinstance(admin.site._registry[ScopedSetting], ScopedSettingAdmin)
    assert Device in admin.site._registry
    assert isinstance(admin.site._registry[Device], DeviceAdmin)


def test_ref_display_user_scope():
    user = get_user_model().objects.create_user(username="alice", password="x")
    row = ScopedSetting.objects.create(
        namespace="core", key="k", scope=Scope.USER, user=user, value="v"
    )
    admin_inst = admin.site._registry[ScopedSetting]
    assert admin_inst.ref_display(row) == str(user)


def test_ref_display_group_scope():
    g = Group.objects.create(name="doctors")
    row = ScopedSetting.objects.create(
        namespace="core", key="k", scope=Scope.GROUP, group=g, value="v"
    )
    admin_inst = admin.site._registry[ScopedSetting]
    assert admin_inst.ref_display(row) == "doctors"


def test_ref_display_device_scope():
    d = Device.objects.create()
    row = ScopedSetting.objects.create(
        namespace="core", key="k", scope=Scope.DEVICE, device=d, value="v"
    )
    admin_inst = admin.site._registry[ScopedSetting]
    assert admin_inst.ref_display(row) == f"device#{d.pk}"


def test_ref_display_tenant_scope():
    t = Tenant.objects.create(name="Acme", slug="acme")
    row = ScopedSetting.objects.create(
        namespace="core", key="k", scope=Scope.TENANT, tenant=t, value="v"
    )
    admin_inst = admin.site._registry[ScopedSetting]
    assert admin_inst.ref_display(row) == "Acme"


def test_ref_display_vendor_scope_returns_empty():
    row = ScopedSetting.objects.create(
        namespace="core", key="k", scope=Scope.VENDOR, value="v"
    )
    admin_inst = admin.site._registry[ScopedSetting]
    assert admin_inst.ref_display(row) == ""


def test_scope_label_uses_enum_name():
    row = ScopedSetting.objects.create(
        namespace="core", key="k", scope=Scope.VENDOR, value="v"
    )
    admin_inst = admin.site._registry[ScopedSetting]
    assert admin_inst.scope_label(row) == "Vendor"
