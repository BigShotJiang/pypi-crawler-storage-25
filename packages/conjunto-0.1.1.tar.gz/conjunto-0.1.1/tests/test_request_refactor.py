import pytest
from django.test import RequestFactory
from django.contrib.auth.models import AnonymousUser
from conjunto.menu import IMenuItem, Menus


class RequestRequiredItem(IMenuItem):
    menu = "test"
    title = "Test Item"

    @staticmethod
    def check(request):
        return getattr(request, "allow", False)


def test_request_not_in_init():
    # This test should pass after our changes
    # MenuItem should be instantiable without a request
    item = RequestRequiredItem()
    assert item.title == "Test Item"

    rf = RequestFactory()
    request = rf.get("/")
    request.user = AnonymousUser()
    request.allow = True

    menu = Menus(request)
    # The item should be visible because we passed request to Menu,
    # and Menu sets request on all items.
    items = menu["test"]
    assert any(i.title == "Test Item" for i in items)

    request.allow = False
    items = menu["test"]
    assert not any(i.title == "Test Item" for i in items)


def test_dynamic_slug():
    class DynamicSlugItem(IMenuItem):
        menu = "test"
        title = lambda r: "Dynamic " + getattr(r, "val", "Default")

    rf = RequestFactory()
    request = rf.get("/")
    request.user = AnonymousUser()
    request.val = "Title"

    item = DynamicSlugItem(request=request)
    assert item.get_slug() == "dynamic-title"

    request.val = "Other"
    assert item.get_slug() == "dynamic-other"
