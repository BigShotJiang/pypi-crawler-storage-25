import pytest
from conjunto.menu import Menus, IMenuItem
from django.contrib.auth.models import AnonymousUser


@pytest.fixture
def mock_request(rf):
    request = rf.get("/")
    request.user = AnonymousUser()
    return request


@pytest.mark.django_db
def test_menu_initialization(mock_request):
    menu = Menus(mock_request)
    assert menu.request == mock_request
    assert isinstance(menu._items, dict)


@pytest.mark.django_db
def test_menu_getitem_returns_list(mock_request):
    menu = Menus(mock_request)
    items = menu["main"]
    assert isinstance(items, list)


@pytest.mark.django_db
def test_menu_sorts_items_by_weight(mock_request, monkeypatch):
    class TestMenuItem1(IMenuItem):
        menu = "test_menu"
        title = "Item 1"
        weight = 10

    class TestMenuItem2(IMenuItem):
        menu = "test_menu"
        title = "Item 2"
        weight = 5

    monkeypatch.setattr(IMenuItem, "enabled_plugins",
                        lambda: [TestMenuItem1, TestMenuItem2])

    menu = Menus(mock_request)
    items = menu._items.get("test_menu", [])
    if len(items) >= 2:
        assert items[0].weight <= items[1].weight


@pytest.mark.django_db
def test_menu_getitem_empty_menu_returns_empty_list(mock_request):
    menu = Menus(mock_request)
    items = menu["nonexistent_menu"]
    assert items == []


@pytest.mark.django_db
def test_menu_hierarchical_parent_child(mock_request, monkeypatch):
    """Test parent-child relationships with explicit parent reference."""
    class ParentItem(IMenuItem):
        menu = "nav_test"
        title = "Parent"
        slug = "parent"

    class ChildItem(IMenuItem):
        title = "Child"
        slug = "child"
        parent = "parent"  # menu is inherited from parent

    monkeypatch.setattr(IMenuItem, "enabled_plugins",
                        lambda: [ParentItem, ChildItem])

    menu = Menus(mock_request)
    items = menu["nav_test"]

    # Find the parent item (should be top-level)
    parent_items = [i for i in items if i.title == "Parent"]
    assert len(parent_items) == 1
    parent = parent_items[0]

    # Child should not be in top-level items
    child_items = [i for i in items if i.title == "Child"]
    assert len(child_items) == 0

    # Parent should have children
    assert parent.has_children()
    children = list(parent.children())
    assert len(children) == 1
    assert children[0].title == "Child"

    # Child should have parent
    assert children[0].has_parent()
    assert children[0].get_parent() == parent


@pytest.mark.django_db
def test_menu_hierarchical_no_children(mock_request, monkeypatch):
    """Test that items without children return empty list."""
    class StandaloneItem(IMenuItem):
        menu = "nav_standalone"
        title = "Standalone"
        slug = "standalone"

    monkeypatch.setattr(IMenuItem, "enabled_plugins",
                        lambda: [StandaloneItem])

    menu = Menus(mock_request)
    items = menu["nav_standalone"]
    standalone_items = [i for i in items if i.title == "Standalone"]
    assert len(standalone_items) == 1
    item = standalone_items[0]

    assert not item.has_children()
    assert list(item.children()) == []
    assert not item.has_parent()


@pytest.mark.django_db
def test_menu_children_sorted_by_weight(mock_request, monkeypatch):
    """Test that children are sorted by weight."""
    class ParentItem(IMenuItem):
        menu = "nav_weight"
        title = "Parent Weight"
        slug = "parent_w"

    class Child1(IMenuItem):
        title = "Child 1"
        slug = "child1"
        parent = "parent_w"  # menu is inherited from parent
        weight = 20

    class Child2(IMenuItem):
        title = "Child 2"
        slug = "child2"
        parent = "parent_w"  # menu is inherited from parent
        weight = 10

    monkeypatch.setattr(IMenuItem, "enabled_plugins",
                        lambda: [ParentItem, Child1, Child2])

    menu = Menus(mock_request)
    items = menu["nav_weight"]
    parent_items = [i for i in items if i.title == "Parent Weight"]
    assert len(parent_items) == 1
    parent = parent_items[0]

    children = list(parent.children())
    assert len(children) == 2
    assert children[0].weight == 10
    assert children[1].weight == 20


@pytest.mark.django_db
def test_menu_deep_nesting(mock_request, monkeypatch):
    """Test deep nesting (3+ levels) is now supported."""
    class Level1Item(IMenuItem):
        menu = "deep_nav"
        title = "Level 1"
        slug = "level1"

    class Level2Item(IMenuItem):
        title = "Level 2"
        slug = "level2"
        parent = "level1"  # menu is inherited from parent

    class Level3Item(IMenuItem):
        title = "Level 3"
        slug = "level3"
        parent = "level2"  # menu is inherited from parent

    class Level4Item(IMenuItem):
        title = "Level 4"
        slug = "level4"
        parent = "level3"  # menu is inherited from parent

    monkeypatch.setattr(IMenuItem, "enabled_plugins",
                        lambda: [Level1Item, Level2Item, Level3Item, Level4Item])

    menu = Menus(mock_request)
    items = menu["deep_nav"]

    # Only Level 1 should be at top level
    assert len(items) == 1
    assert items[0].title == "Level 1"

    # Navigate through the hierarchy
    level1 = items[0]
    assert level1.has_children()
    assert not level1.has_parent()

    level2_children = list(level1.children())
    assert len(level2_children) == 1
    level2 = level2_children[0]
    assert level2.title == "Level 2"
    assert level2.has_parent()
    assert level2.get_parent() == level1

    level3_children = list(level2.children())
    assert len(level3_children) == 1
    level3 = level3_children[0]
    assert level3.title == "Level 3"
    assert level3.has_parent()
    assert level3.get_parent() == level2

    level4_children = list(level3.children())
    assert len(level4_children) == 1
    level4 = level4_children[0]
    assert level4.title == "Level 4"
    assert level4.has_parent()
    assert level4.get_parent() == level3
    assert not level4.has_children()


@pytest.mark.django_db
def test_menu_parent_by_class_reference(mock_request, monkeypatch):
    """Test parent can be referenced by class."""
    class ParentItem(IMenuItem):
        menu = "class_ref"
        title = "Parent"
        slug = "parent"

    class ChildItem(IMenuItem):
        title = "Child"
        slug = "child"
        parent = ParentItem  # menu is inherited from parent

    monkeypatch.setattr(IMenuItem, "enabled_plugins",
                        lambda: [ParentItem, ChildItem])

    menu = Menus(mock_request)
    items = menu["class_ref"]

    # Only parent should be at top level
    assert len(items) == 1
    parent = items[0]
    assert parent.title == "Parent"

    # Parent should have child
    assert parent.has_children()
    children = list(parent.children())
    assert len(children) == 1
    assert children[0].title == "Child"
    assert children[0].get_parent() == parent


@pytest.mark.django_db
def test_menu_missing_parent_warning(mock_request, monkeypatch):
    """Test that missing parent references produce a warning."""
    import warnings

    class OrphanItem(IMenuItem):
        title = "Orphan"
        slug = "orphan"
        parent = "nonexistent-parent"  # This parent doesn't exist, no menu defined

    monkeypatch.setattr(IMenuItem, "enabled_plugins",
                        lambda: [OrphanItem])

    # Capture warnings
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        menu = Menus(mock_request)

        # Should have produced a warning
        assert len(w) == 1
        assert issubclass(w[0].category, UserWarning)
        assert "OrphanItem" in str(w[0].message)
        assert "nonexistent-parent" in str(w[0].message)
        assert "not found" in str(w[0].message)

    # Item has no parent and no menu defined — it does not appear in any menu
    assert not menu._items
