import pytest
import uuid
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from django.utils import timezone
from conjunto.audit_log.models import ModelLogEntry
from conjunto.audit_log.registry import log_action_registry, LogActionResult
from conjunto.audit_log.log_actions import log_action
from conjunto.audit_log.context import LogContext
from tests.test_app.models import Person

User = get_user_model()


@pytest.mark.django_db
class TestAuditLog:

    @pytest.fixture
    def user(self):
        return User.objects.create_user(username="testuser")

    @pytest.fixture
    def person(self):
        return Person.objects.create(name="John Doe")

    def test_log_action_basic(self, person, user):
        """Test basic log_action functionality."""
        entry = log_action(instance=person, action="create", user=user)

        assert isinstance(entry, ModelLogEntry)
        assert entry.content_type == ContentType.objects.get_for_model(person)
        assert entry.object_id == str(person.pk)
        assert entry.action == "create"
        assert entry.user == user
        assert entry.label == str(person)

    def test_log_action_with_context(self, person, user):
        """Test log_action using LogContext."""
        with LogContext(user=user) as context:
            entry = log_action(instance=person, action="create")
            assert entry.user == user
            assert entry.uuid == context.uuid

    def test_log_action_explicit_user_overrides_context(self, person, user):
        """Test that explicit user overrides context user."""
        other_user = User.objects.create_user(username="otheruser")
        with LogContext(user=user):
            entry = log_action(instance=person, action="create", user=other_user)
            assert entry.user == other_user

    def test_log_action_with_data_and_result(self, person, user):
        """Test log_action with extra data and result."""
        data = {"key": "value"}
        entry = log_action(
            instance=person,
            action="update",
            user=user,
            data=data,
            result=LogActionResult.SUCCESS,
        )

        assert entry.data == data
        assert entry.result == LogActionResult.SUCCESS

    def test_fallback_title_logic(self, user):
        """Test that a fallback title is used when str(instance) is empty."""

        class EmptyStrPerson(Person):
            class Meta:
                proxy = True
                app_label = "test_app"

            def __str__(self):
                return ""

        person = EmptyStrPerson.objects.create(name="No Name")
        entry = log_action(instance=person, action="update", user=user)

        expected_title = f"{person._meta.verbose_name.title()} {person.pk}"
        assert entry.label == expected_title

    def test_log_action_with_explicit_title(self, person, user):
        """Test log_action with an explicit title."""
        entry = log_action(
            instance=person, action="update", user=user, title="Custom Title"
        )
        assert entry.label == "Custom Title"

    def test_queryset_public(self, person, user):
        """Test the public() method of LogEntryQuerySet."""
        log_action(instance=person, action="create", user=user, public=True)
        log_action(instance=person, action="update", user=user, public=False)

        assert ModelLogEntry.objects.all().count() == 2
        assert ModelLogEntry.objects.all().public().count() == 1

    def test_queryset_get_actions(self, person, user):
        """Test get_actions() returns distinct actions."""
        log_action(instance=person, action="create", user=user)
        log_action(instance=person, action="update", user=user)
        log_action(instance=person, action="update", user=user)

        actions = ModelLogEntry.objects.all().get_actions()
        assert actions == {"create", "update"}

    def test_queryset_get_users(self, person, user):
        """Test get_users() returns distinct users who performed actions."""
        other_user = User.objects.create_user(username="otheruser")
        log_action(instance=person, action="create", user=user)
        log_action(instance=person, action="update", user=other_user)

        users = ModelLogEntry.objects.all().get_users()
        assert users.count() == 2
        assert user in users
        assert other_user in users

    def test_queryset_with_instances(self, person, user):
        """Test with_instances() returns (entry, instance) tuples."""
        log_action(instance=person, action="create", user=user)

        entries_with_instances = list(ModelLogEntry.objects.all().with_instances())
        assert len(entries_with_instances) == 1
        entry, instance = entries_with_instances[0]
        assert isinstance(entry, ModelLogEntry)
        assert instance == person

    def test_queryset_with_instances_deleted_model(self, person, user, mocker):
        """Test with_instances() when the model no longer exists."""
        log_action(instance=person, action="create", user=user)

        # Mock ContentType to return None for model_class
        mocker.patch(
            "django.contrib.contenttypes.models.ContentType.model_class",
            return_value=None,
        )

        entries_with_instances = list(ModelLogEntry.objects.all().with_instances())
        entry, instance = entries_with_instances[0]
        assert instance is None

    def test_user_display_name(self, person, user):
        """Test user_display_name property."""
        entry = log_action(instance=person, action="create", user=user)
        assert entry.user_display_name == user.get_username()

        # System action
        entry_system = log_action(instance=person, action="create", user=None)
        assert entry_system.user_display_name == "system"

    def test_object_verbose_name(self, person, user):
        """Test object_verbose_name property."""
        entry = log_action(instance=person, action="create", user=user)
        assert entry.object_verbose_name == "Person"

    def test_message_and_comment(self, person, user):
        """Test message and comment properties using formatters."""
        entry = log_action(instance=person, action="create", user=user)
        # From gdaps_hooks.py: actions.register_action("create", _("Create"), _("Created"))
        # LogFormatter.message is "Created"
        assert entry.message == "Created"
        assert entry.comment == ""

    def test_unregistered_action_validation(self, person, user):
        """Test that saving an unregistered action raises ValidationError."""
        entry = ModelLogEntry(
            content_type=ContentType.objects.get_for_model(person),
            object_id=str(person.pk),
            action="unregistered_action",
            timestamp=timezone.now(),
        )
        with pytest.raises(
            pytest.importorskip("django.core.exceptions").ValidationError
        ):
            entry.save()

    def test_get_logs_for_instance(self, person, user):
        """Test log_action_registry.get_logs_for_instance."""
        log_action(instance=person, action="create", user=user)
        logs = log_action_registry.get_logs_for_instance(person)
        assert logs.count() == 1
        assert logs[0].action == "create"
