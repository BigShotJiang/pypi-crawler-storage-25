import pytest
from django.utils import timezone


def assert_created_equal(created1, created2):
    if timezone.is_aware(created1):
        created1 = timezone.make_naive(created1, timezone.get_current_timezone())
    if timezone.is_aware(created2):
        created2 = timezone.make_naive(created2, timezone.get_current_timezone())
    assert created1 == created2


# ---------------------------------------------------------------------------
# HistoryVersionedModel fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def history_model(db):
    from tests.test_app.models import HistoryVersionedTestModel

    return HistoryVersionedTestModel


@pytest.fixture
def create_history_instance(history_model):
    def _create(title="Test", content="Test content"):
        obj = history_model(title=title, content=content)
        obj.save()
        return obj

    return _create


# ---------------------------------------------------------------------------
# HistoryVersionedModel tests
# ---------------------------------------------------------------------------


class TestHistoryVersionedModel:
    def test_first_save_creates_version_1_no_snapshot(
        self, history_model, create_history_instance
    ):
        obj = create_history_instance()
        assert obj.version == 1
        assert obj.pk is not None
        assert obj.get_history().count() == 0

    def test_second_save_increments_version_and_snapshots(
        self, create_history_instance
    ):
        obj = create_history_instance()
        original_pk = obj.pk

        obj.content = "Version 2"
        obj.save()

        assert obj.pk == original_pk  # PK is stable
        assert obj.version == 2
        assert obj.get_history().count() == 1

    def test_snapshot_preserves_previous_content(self, create_history_instance):
        obj = create_history_instance()

        obj.content = "Version 2"
        obj.save()

        snapshot = obj.get_history().first()
        assert snapshot.version == 1
        assert snapshot.snapshot["content"] == "Test content"

    def test_multiple_versions_accumulate_snapshots(self, create_history_instance):
        obj = create_history_instance()

        obj.content = "Version 2"
        obj.save()

        obj.content = "Version 3"
        obj.save()

        assert obj.version == 3
        history = list(obj.get_history())
        assert len(history) == 2
        assert history[0].snapshot["content"] == "Test content"
        assert history[1].snapshot["content"] == "Version 2"

    def test_stable_pk_across_versions(self, create_history_instance):
        obj = create_history_instance()
        pk = obj.pk

        for i in range(3):
            obj.content = f"Version {i + 2}"
            obj.save()

        assert obj.pk == pk

    def test_created_at_unchanged_across_versions(self, create_history_instance):
        obj = create_history_instance()
        created_at = obj.created_at

        obj.content = "Version 2"
        obj.save()

        obj.refresh_from_db()
        assert_created_equal(obj.created_at, created_at)
