import pytest
from django.contrib.auth.models import User, AnonymousUser, Permission
from django.contrib.contenttypes.models import ContentType
from django.test import RequestFactory
from conjunto.menu import IMenuItem, Menus


@pytest.mark.django_db
def test_selected_method_exact_match():
    """Test selected() method with exact_url=True."""

    class TestItem(IMenuItem):
        menu = "nav"
        title = "Test"
        url = "/test/path/"
        exact_url = True

    rf = RequestFactory()
    request = rf.get("/test/path/")
    request.user = AnonymousUser()

    menu = Menus(request)
    items = menu["nav"]
    item = next((i for i in items if i.title == "Test"), None)

    if item:
        assert item.selected()

    # Should not match sub-paths
    request2 = rf.get("/test/path/sub/")
    request2.user = AnonymousUser()
    menu2 = Menus(request2)
    items2 = menu2["nav"]
    item2 = next((i for i in items2 if i.title == "Test"), None)

    if item2:
        assert not item2.selected()


@pytest.mark.django_db
def test_selected_method_prefix_match():
    """Test selected() method with exact_url=False (default)."""

    class TestItem(IMenuItem):
        menu = "nav_prefix"
        title = "Test Prefix"
        url = "/test"
        exact_url = False

    rf = RequestFactory()
    # Test exact match
    request = rf.get("/test")
    request.user = AnonymousUser()

    menu = Menus(request)
    items = menu["nav_prefix"]
    item = next((i for i in items if i.title == "Test Prefix"), None)

    if item:
        assert item.selected()

    # Test prefix match (re.match matches from start)
    request2 = rf.get("/test/sub/path/")
    request2.user = AnonymousUser()
    menu2 = Menus(request2)
    items2 = menu2["nav_prefix"]
    item2 = next((i for i in items2 if i.title == "Test Prefix"), None)

    if item2:
        assert item2.selected()


@pytest.mark.django_db
def test_badge_static():
    """Test that badge can be a static string."""

    class BadgeItem(IMenuItem):
        menu = "nav_badge"
        title = "New Feature"
        badge = "Beta"

    rf = RequestFactory()
    request = rf.get("/")
    request.user = AnonymousUser()

    menu = Menus(request)
    items = menu["nav_badge"]
    item = next((i for i in items if i.title == "New Feature"), None)

    if item:
        assert hasattr(item, "badge")
        assert item.badge == "Beta"


@pytest.mark.django_db
def test_separator_attribute():
    """Test separator attribute is accessible."""

    class SeparatorItem(IMenuItem):
        menu = "nav"
        title = "Item"
        separator_before = True

    rf = RequestFactory()
    request = rf.get("/")
    request.user = AnonymousUser()

    menu = Menus(request)
    items = menu["nav"]
    item = next((i for i in items if i.title == "Item"), None)

    if item:
        assert item.separator_before is True


@pytest.mark.django_db
def test_collapsed_attribute():
    """Test collapsed attribute is accessible."""

    class CollapsedItem(IMenuItem):
        menu = "nav"
        title = "Collapsed Menu"
        collapsed = False

    rf = RequestFactory()
    request = rf.get("/")
    request.user = AnonymousUser()

    menu = Menus(request)
    items = menu["nav"]
    item = next((i for i in items if i.title == "Collapsed Menu"), None)

    if item:
        assert item.collapsed is False


@pytest.mark.django_db
def test_permissions_required_single(monkeypatch):
    """Test that visible property checks single permission."""

    class ProtectedItem(IMenuItem):
        menu = "admin"
        title = "Admin Panel"
        permissions_required = ["auth.add_user"]

    monkeypatch.setattr(IMenuItem, "enabled_plugins", lambda: [ProtectedItem])

    rf = RequestFactory()

    # Test with user without permission
    request = rf.get("/")
    user = User.objects.create_user(username="test", password="test")
    request.user = user

    menu = Menus(request)
    items = menu["admin"]
    assert len([i for i in items if i.title == "Admin Panel"]) == 0

    # Test with user with permission
    content_type = ContentType.objects.get_for_model(User)
    perm = Permission.objects.get(codename="add_user", content_type=content_type)
    user.user_permissions.add(perm)
    user = User.objects.get(pk=user.pk)  # Refresh permissions cache

    request2 = rf.get("/")
    request2.user = user
    menu2 = Menus(request2)
    items2 = menu2["admin"]
    assert len([i for i in items2 if i.title == "Admin Panel"]) == 1


@pytest.mark.django_db
def test_permissions_required_multiple(monkeypatch):
    """Test that visible property checks multiple permissions."""

    class ProtectedItem(IMenuItem):
        menu = "admin_multi"
        title = "Admin Panel Multi"
        permissions_required = ["auth.add_user", "auth.change_user"]

    monkeypatch.setattr(IMenuItem, "enabled_plugins", lambda: [ProtectedItem])

    rf = RequestFactory()
    user = User.objects.create_user(username="test_multi", password="test")

    # Add only one permission
    content_type = ContentType.objects.get_for_model(User)
    perm = Permission.objects.get(codename="add_user", content_type=content_type)
    user.user_permissions.add(perm)
    user = User.objects.get(pk=user.pk)

    request = rf.get("/")
    request.user = user

    menu = Menus(request)
    items = menu["admin_multi"]
    # Should not be visible - needs both permissions
    assert len([i for i in items if i.title == "Admin Panel Multi"]) == 0

    # Add second permission
    perm2 = Permission.objects.get(codename="change_user", content_type=content_type)
    user.user_permissions.add(perm2)
    user = User.objects.get(pk=user.pk)

    request2 = rf.get("/")
    request2.user = user
    menu2 = Menus(request2)
    items2 = menu2["admin_multi"]
    # Now should be visible
    assert len([i for i in items2 if i.title == "Admin Panel Multi"]) == 1
