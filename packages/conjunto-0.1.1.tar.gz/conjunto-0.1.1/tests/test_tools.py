import pytest
from django.contrib.auth.models import Group

from conjunto.tools import create_group_permissions


@pytest.mark.django_db
def test_correct_permissions():
    errors = create_group_permissions(
        {"group1": {"test_app.Person": ["view", "add", "change", "delete"]}}
    )
    assert errors == []
    permissions = Group.objects.get(name="group1").permissions
    assert permissions.filter(codename="view_person").exists()
    assert permissions.filter(codename="add_person").exists()
    assert permissions.filter(codename="change_person").exists()
    assert permissions.filter(codename="delete_person").exists()


@pytest.mark.django_db
def test_schema_is_authoritative():
    """A second call replaces — not augments — the group's permissions."""
    create_group_permissions(
        {"group2": {"test_app.Person": ["view", "add", "change"]}}
    )
    permissions = Group.objects.get(name="group2").permissions
    assert permissions.filter(codename="delete_person").count() == 0

    create_group_permissions({"group2": {"test_app.Person": ["delete"]}})
    assert permissions.filter(codename="view_person").count() == 0
    assert permissions.filter(codename="add_person").count() == 0
    assert permissions.filter(codename="change_person").count() == 0
    assert permissions.filter(codename="delete_person").count() == 1


@pytest.mark.django_db
def test_unknown_model_raises():
    with pytest.raises(LookupError):
        create_group_permissions(
            {"group3": {"common.XYZ_does_not_exist": ["view", "add", "change"]}}
        )


@pytest.mark.django_db
def test_unknown_permission_is_reported():
    errors = create_group_permissions(
        {"group4": {"test_app.Person": ["view", "nonexistent"]}}
    )
    assert len(errors) == 1
    assert "nonexistent_person" in errors[0]
    # The valid permission was still applied.
    permissions = Group.objects.get(name="group4").permissions
    assert permissions.filter(codename="view_person").exists()
