
import pytest
from django.contrib.auth.models import User, AnonymousUser, Permission
from django.contrib.contenttypes.models import ContentType
from django.test import RequestFactory
from conjunto.menu import IMenuItem, Menus


@pytest.mark.django_db
def test_menu_item_visibility_with_permissions(monkeypatch):
    """Test that menu items are hidden when user lacks required permissions."""
    class PermissionProtectedItem(IMenuItem):
        menu = "test_menu"
        title = "Protected Item"
        url = "/test/"
        permissions_required = ["auth.add_user"]

    monkeypatch.setattr(IMenuItem, "enabled_plugins", lambda: [PermissionProtectedItem])

    rf = RequestFactory()
    request = rf.get("/")

    # Test with anonymous user
    request.user = AnonymousUser()
    menu = Menus(request)
    items = list(menu["test_menu"])
    visible_items = [item for item in items if item.title == "Protected Item"]
    assert len(visible_items) == 0, "Item should not be visible to anonymous user"

    # Test with user without permission
    user = User.objects.create_user(username="test", password="test")
    request.user = user
    menu = Menus(request)
    items = list(menu["test_menu"])
    visible_items = [item for item in items if item.title == "Protected Item"]
    assert len(visible_items) == 0, "Item should not be visible without permission"

    # Test with user with permission
    content_type = ContentType.objects.get_for_model(User)
    perm = Permission.objects.get(codename="add_user", content_type=content_type)
    user.user_permissions.add(perm)
    user = User.objects.get(pk=user.pk)  # Refresh permissions cache

    request.user = user
    menu = Menus(request)
    items = list(menu["test_menu"])
    visible_items = [item for item in items if item.title == "Protected Item"]
    assert len(visible_items) == 1, "Item should be visible with permission"


@pytest.mark.django_db
def test_menu_item_visible_property(monkeypatch):
    """Test that visible property works correctly."""
    class VisibleItem(IMenuItem):
        menu = "test_visible"
        title = "Always Visible"
        url = "/test/"

    monkeypatch.setattr(IMenuItem, "enabled_plugins", lambda: [VisibleItem])

    rf = RequestFactory()
    request = rf.get("/")
    request.user = AnonymousUser()

    menu = Menus(request)
    items = list(menu["test_visible"])
    assert len(items) > 0
    test_item = next(item for item in items if item.title == "Always Visible")
    assert test_item.visible is True


@pytest.mark.django_db
def test_dynamic_title_via_get_title(monkeypatch):
    """Test dynamic titles via get_title() method override."""
    class DynamicTitleItem(IMenuItem):
        menu = "test_dynamic"
        title = "Default Title"
        url = "/test/"

        def get_title(self):
            return getattr(self._request, "dynamic_title", "Default Title")

    monkeypatch.setattr(IMenuItem, "enabled_plugins", lambda: [DynamicTitleItem])

    rf = RequestFactory()
    request = rf.get("/")
    request.user = AnonymousUser()
    request.dynamic_title = "Initial Title"

    menu = Menus(request)
    items = list(menu["test_dynamic"])
    item = items[0]
    assert item.get_title() == "Initial Title"

    request.dynamic_title = "Changed Title"
    # It should be dynamic
    assert item.get_title() == "Changed Title"


@pytest.mark.django_db
def test_custom_visibility_via_is_visible_override(monkeypatch):
    """Test custom visibility logic via _is_visible() override."""
    class CustomVisibilityItem(IMenuItem):
        menu = "test_custom"
        title = "Custom Visibility"
        url = "/test/"

        def _is_visible(self):
            # First check parent visibility (permissions)
            if not super()._is_visible():
                return False
            # Then custom check
            return getattr(self._request, "show_item", True)

    monkeypatch.setattr(IMenuItem, "enabled_plugins", lambda: [CustomVisibilityItem])

    rf = RequestFactory()
    request = rf.get("/")
    request.user = AnonymousUser()
    request.show_item = True

    menu = Menus(request)
    items = list(menu["test_custom"])
    assert len([item for item in items if item.title == "Custom Visibility"]) == 1

    # Change visibility condition
    request.show_item = False
    # Re-instantiate menu to get new visibility check
    menu = Menus(request)
    items = list(menu["test_custom"])
    assert len([item for item in items if item.title == "Custom Visibility"]) == 0
