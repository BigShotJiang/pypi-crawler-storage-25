"""Acceptance test for the ScopedSettings cutover (C9).

Exercises the maintenance-mode flow end-to-end on the new scoped
settings subsystem. If this test passes, the cutover is real:

- Before: ``maintenance_mode`` lived on the old ``AbstractSettings``
  model, loaded onto ``request.app_settings`` by the old
  ``ConjuntoMiddleware``.
- After: ``conjunto.maintenance_mode`` is a VENDOR-scoped setting,
  registered via ``conjunto.scoped_settings``, resolved through
  ``request.scoped_settings`` by the rewritten ``ConjuntoMiddleware``.

Covers:
- Maintenance off → normal request is not redirected.
- Maintenance on → non-staff user is redirected to /maintenance/.
- Maintenance on → staff user bypasses the redirect.
- Maintenance on + request already on /maintenance/ → no redirect loop.
"""

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser
from django.http import HttpResponse
from django.test import RequestFactory

from conjunto.middleware import ConjuntoMiddleware
from conjunto.settings.scoped.models import Scope, ScopedSetting


pytestmark = pytest.mark.django_db


def _noop(request):
    return HttpResponse("ok")


@pytest.fixture
def rf():
    return RequestFactory()


def test_maintenance_off_lets_request_through(rf):
    request = rf.get("/")
    request.user = AnonymousUser()
    response = ConjuntoMiddleware(_noop)(request)
    assert response.status_code == 200
    assert response.content == b"ok"


def test_maintenance_on_redirects_anonymous(rf):
    ScopedSetting.objects.create(
        namespace="conjunto",
        key="maintenance_mode",
        scope=Scope.VENDOR,
        value=True,
    )
    request = rf.get("/")
    request.user = AnonymousUser()
    response = ConjuntoMiddleware(_noop)(request)
    assert response.status_code == 302
    assert response["Location"] == "/maintenance/"


def test_maintenance_on_redirects_non_staff_user(rf):
    ScopedSetting.objects.create(
        namespace="conjunto",
        key="maintenance_mode",
        scope=Scope.VENDOR,
        value=True,
    )
    user = get_user_model().objects.create_user(
        username="alice", password="x", is_staff=False
    )
    request = rf.get("/")
    request.user = user
    response = ConjuntoMiddleware(_noop)(request)
    assert response.status_code == 302
    assert response["Location"] == "/maintenance/"


def test_maintenance_on_lets_staff_through(rf):
    ScopedSetting.objects.create(
        namespace="conjunto",
        key="maintenance_mode",
        scope=Scope.VENDOR,
        value=True,
    )
    staff = get_user_model().objects.create_user(
        username="admin", password="x", is_staff=True
    )
    request = rf.get("/")
    request.user = staff
    response = ConjuntoMiddleware(_noop)(request)
    assert response.status_code == 200


def test_maintenance_on_does_not_redirect_on_maintenance_page(rf):
    """The /maintenance/ URL itself must stay reachable — otherwise
    the redirect loops forever."""
    ScopedSetting.objects.create(
        namespace="conjunto",
        key="maintenance_mode",
        scope=Scope.VENDOR,
        value=True,
    )
    request = rf.get("/maintenance/")
    request.user = AnonymousUser()
    response = ConjuntoMiddleware(_noop)(request)
    assert response.status_code == 200
