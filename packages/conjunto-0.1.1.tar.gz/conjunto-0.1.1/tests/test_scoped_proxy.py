"""Tests for ScopedSettingsProxy + middleware wiring (C7).

Covers:
- proxy.get() strict mode (KeyError on missing spec)
- proxy.get() lenient mode (default fallback)
- Per-request cache: same key read twice → one DB query
- Namespace attribute-access sugar: ``proxy.core.theme``
- Namespace tolerates missing specs by returning empty string
- Middleware attaches ``request.scoped_settings`` on every request
- End-to-end: template-style access through middleware-wired proxy
"""

from types import SimpleNamespace

import pytest
from django.contrib.auth.models import AnonymousUser
from django.http import HttpResponse
from django.template import Context, Template
from django.test import RequestFactory

from conjunto.middleware import ConjuntoMiddleware
from conjunto.settings.scoped.models import Scope, ScopedSetting
from conjunto.settings.scoped.proxy import ScopedSettingsProxy
from conjunto.settings.scoped.registry import SettingRegistry
from conjunto.settings.scoped.testing import unfreeze_registry


pytestmark = pytest.mark.django_db


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def rf():
    return RequestFactory()


@pytest.fixture
def registry_with_theme():
    with unfreeze_registry() as reg:
        reg.register(
            "core",
            "theme",
            type="str",
            default="light",
            writable_scopes=[Scope.VENDOR],
        )
        yield reg


@pytest.fixture
def proxy_request(rf):
    request = rf.get("/")
    request.user = AnonymousUser()
    request.site = None
    request.device = None
    request.tenant = None
    request.session = {}
    return request


# ---------------------------------------------------------------------------
# proxy.get() — strict vs. lenient
# ---------------------------------------------------------------------------


def test_get_strict_raises_keyerror_for_missing_spec(proxy_request):
    with unfreeze_registry():
        proxy = ScopedSettingsProxy(proxy_request)
        with pytest.raises(KeyError, match="not registered"):
            proxy.get("unknown", "key")


def test_get_lenient_returns_default_for_missing_spec(proxy_request):
    with unfreeze_registry():
        proxy = ScopedSettingsProxy(proxy_request)
        assert proxy.get("unknown", "key", default="fallback") == "fallback"


def test_get_returns_registered_default(registry_with_theme, proxy_request):
    proxy = ScopedSettingsProxy(proxy_request)
    assert proxy.get("core", "theme") == "light"


def test_get_returns_stored_value(registry_with_theme, proxy_request):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="dark"
    )
    proxy = ScopedSettingsProxy(proxy_request)
    assert proxy.get("core", "theme") == "dark"


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------


def test_cache_hit_avoids_db_on_repeated_reads(
    registry_with_theme, proxy_request, django_assert_num_queries
):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="dark"
    )
    proxy = ScopedSettingsProxy(proxy_request)
    with django_assert_num_queries(1):
        assert proxy.get("core", "theme") == "dark"
        assert proxy.get("core", "theme") == "dark"
        assert proxy.get("core", "theme") == "dark"


def test_invalidate_clears_cache(registry_with_theme, proxy_request):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="dark"
    )
    proxy = ScopedSettingsProxy(proxy_request)
    assert proxy.get("core", "theme") == "dark"

    # Underlying row changed; proxy still caches the old value.
    ScopedSetting.objects.filter(namespace="core", key="theme").update(value="neon")
    assert proxy.get("core", "theme") == "dark"  # cache still old

    proxy.invalidate("core", "theme")
    assert proxy.get("core", "theme") == "neon"


def test_invalidate_namespace_only(registry_with_theme, proxy_request):
    with unfreeze_registry() as reg:
        # Re-register theme inside this block (unfreeze wipes specs).
        reg.register(
            "core", "theme", type="str", default="light",
            writable_scopes=[Scope.VENDOR],
        )
        reg.register(
            "other", "k", type="str", default="x",
            writable_scopes=[Scope.VENDOR],
        )
        proxy = ScopedSettingsProxy(proxy_request)
        proxy.get("core", "theme")
        proxy.get("other", "k")
        assert len(proxy._cache) == 2

        proxy.invalidate("core")
        assert ("core", "theme") not in proxy._cache
        assert ("other", "k") in proxy._cache


# ---------------------------------------------------------------------------
# Namespace attribute-access sugar
# ---------------------------------------------------------------------------


def test_namespace_attribute_access(registry_with_theme, proxy_request):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="dark"
    )
    proxy = ScopedSettingsProxy(proxy_request)
    assert proxy.core.theme == "dark"


def test_namespace_missing_key_returns_empty_string(
    registry_with_theme, proxy_request
):
    proxy = ScopedSettingsProxy(proxy_request)
    # "missing" is not registered → template-friendly empty string.
    assert proxy.core.missing == ""


def test_namespace_item_access(registry_with_theme, proxy_request):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="dark"
    )
    proxy = ScopedSettingsProxy(proxy_request)
    assert proxy.core["theme"] == "dark"


# ---------------------------------------------------------------------------
# Middleware integration
# ---------------------------------------------------------------------------


def test_middleware_attaches_scoped_settings(rf):
    request = rf.get("/")
    request.user = AnonymousUser()

    captured = {}

    def get_response(req):
        captured["scoped_settings"] = getattr(req, "scoped_settings", None)
        return HttpResponse("ok")

    ConjuntoMiddleware(get_response)(request)
    assert isinstance(captured["scoped_settings"], ScopedSettingsProxy)


def test_template_access_through_middleware(registry_with_theme, rf):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="dark"
    )

    def get_response(req):
        template = Template("{{ request.scoped_settings.core.theme }}")
        rendered = template.render(Context({"request": req}))
        return HttpResponse(rendered)

    request = rf.get("/")
    request.user = AnonymousUser()
    response = ConjuntoMiddleware(get_response)(request)
    assert response.content == b"dark"
