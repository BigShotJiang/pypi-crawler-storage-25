import pytest
from django.test import RequestFactory
from django.contrib.auth.models import AnonymousUser
from conjunto.menu import IMenuItem, Menus


class TestSlugs:

    def test_fixed_slug(self):
        class FixedSlugItem(IMenuItem):
            slug = "fixed_slug"
            title = "Some Title"

        rf = RequestFactory()
        request = rf.get("/")
        request.user = AnonymousUser()
        item = FixedSlugItem(request=request)
        assert item.get_slug() == "fixed_slug"

    def test_slug_from_title(self):
        class TitleSlugItem(IMenuItem):
            title = "Oh My God"

        rf = RequestFactory()
        request = rf.get("/")
        request.user = AnonymousUser()
        item = TitleSlugItem(request=request)
        assert item.get_slug() == "oh-my-god"

    def test_slug_from_dynamic_title_no_request(self):
        """Titles are now static strings, not callables."""
        class DynamicTitleItem(IMenuItem):
            title = "Dynamic Title"

        rf = RequestFactory()
        request = rf.get("/")
        request.user = AnonymousUser()
        item = DynamicTitleItem(request=request)
        assert item.get_slug() == "dynamic-title"

    def test_slug_from_dynamic_title_with_request(self):
        """Test get_title() override for dynamic titles."""
        class DynamicTitleItem(IMenuItem):
            title = "Dynamic Default"

            def get_title(self):
                return "Dynamic " + getattr(self._request, "val", "Default")

        rf = RequestFactory()
        request = rf.get("/")
        request.user = AnonymousUser()
        request.val = "Title"

        item = DynamicTitleItem(request=request)
        assert item.get_slug() == "dynamic-title"

    def test_slug_override_in_subclass(self):
        class BaseItem(IMenuItem):
            title = "Base Title"

        class SubItem(BaseItem):
            slug = "overridden_slug"

        rf = RequestFactory()
        request = rf.get("/")
        request.user = AnonymousUser()
        item = SubItem(request=request)
        assert item.get_slug() == "overridden_slug"
        assert item.get_title() == "Base Title"

    def test_slug_change_with_dynamic_title(self):
        """Test slug updates when dynamic title changes."""
        class DynamicTitleItem(IMenuItem):
            title = "Dynamic Default"

            def get_title(self):
                return "Dynamic " + getattr(self._request, "val", "Default")

        rf = RequestFactory()
        request = rf.get("/")
        request.user = AnonymousUser()
        request.val = "One"

        item = DynamicTitleItem(request=request)
        assert item.get_slug() == "dynamic-one"

        request.val = "Two"
        assert item.get_slug() == "dynamic-two"
