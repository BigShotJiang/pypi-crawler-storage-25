"""Tests for the five built-in IScope implementations (C4).

Covers per-scope:
- resolve() with applicable / non-applicable requests
- filter_kwargs() shape
- can_edit() permission + ownership logic
- ref_display() fallbacks

And the registry-level check that all five are picked up by
``IScope.enabled_plugins()``.
"""

from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser, Group, Permission
from django.contrib.contenttypes.models import ContentType

from conjunto.settings.scoped.interfaces import IScope
from conjunto.settings.scoped.models import Device, Scope, ScopedSetting
from conjunto.settings.scoped.scopes import (
    IDeviceScope,
    IGroupScope,
    ITenantScope,
    IUserScope,
    IVendorScope,
)
from conjunto.tenants.models import Tenant


pytestmark = pytest.mark.django_db


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def user():
    return get_user_model().objects.create_user(username="alice", password="x")


@pytest.fixture
def other_user():
    return get_user_model().objects.create_user(username="bob", password="x")


@pytest.fixture
def change_perm():
    """The built-in ``change_scopedsetting`` Django permission."""
    ct = ContentType.objects.get_for_model(ScopedSetting)
    return Permission.objects.get(codename="change_scopedsetting", content_type=ct)


@pytest.fixture
def user_with_change(user, change_perm):
    user.user_permissions.add(change_perm)
    return user


def make_request(user=None, device=None, tenant=None, session=None):
    """Build a Mock request with the attributes the scopes read."""
    return SimpleNamespace(
        user=user or AnonymousUser(),
        device=device,
        tenant=tenant,
        session=session or {},
    )


# ---------------------------------------------------------------------------
# Plugin registration
# ---------------------------------------------------------------------------


def test_all_five_scopes_are_registered():
    """Verify that all five scope classes exist and have distinct scope_ids."""
    scopes = [IVendorScope, ITenantScope, IGroupScope, IDeviceScope, IUserScope]
    scope_ids = {s.scope_id for s in scopes}
    assert len(scope_ids) == 5, "All five scopes must have distinct scope_ids"


def test_scope_ids_match_enum():
    assert IVendorScope.scope_id == Scope.VENDOR
    assert ITenantScope.scope_id == Scope.TENANT
    assert IGroupScope.scope_id == Scope.GROUP
    assert IDeviceScope.scope_id == Scope.DEVICE
    assert IUserScope.scope_id == Scope.USER


def test_weights_reflect_priority_order():
    """Priority order: USER > DEVICE > GROUP > TENANT > VENDOR."""
    assert (
        IVendorScope.weight
        < ITenantScope.weight
        < IGroupScope.weight
        < IDeviceScope.weight
        < IUserScope.weight
    )


# ---------------------------------------------------------------------------
# IVendorScope
# ---------------------------------------------------------------------------


def test_vendor_always_applies():
    req = make_request()
    assert IVendorScope.resolve(req) == [None]


def test_vendor_filter_kwargs_excludes_all_fks():
    kwargs = IVendorScope.filter_kwargs(None)
    assert kwargs["scope"] == Scope.VENDOR
    assert kwargs["user__isnull"] is True
    assert kwargs["group__isnull"] is True
    assert kwargs["device__isnull"] is True
    assert kwargs["tenant__isnull"] is True


def test_vendor_can_edit_requires_permission(user_with_change):
    req = make_request(user=user_with_change)
    assert IVendorScope.can_edit(req, None) is False  # no manage_vendor_settings

    manage_perm = Permission.objects.get(codename="manage_vendor_settings")
    user_with_change.user_permissions.add(manage_perm)
    # Refresh perm cache
    user_with_change = get_user_model().objects.get(pk=user_with_change.pk)
    req2 = make_request(user=user_with_change)
    assert IVendorScope.can_edit(req2, None) is True


def test_vendor_can_edit_anonymous_false():
    req = make_request()
    assert IVendorScope.can_edit(req, None) is False


# ---------------------------------------------------------------------------
# IUserScope
# ---------------------------------------------------------------------------


def test_user_resolves_to_own_pk(user):
    req = make_request(user=user)
    assert IUserScope.resolve(req) == [user.pk]


def test_user_anonymous_returns_none():
    req = make_request()
    assert IUserScope.resolve(req) is None


def test_user_filter_kwargs(user):
    kwargs = IUserScope.filter_kwargs(user.pk)
    assert kwargs == {"scope": Scope.USER, "user_id": user.pk}


def test_user_can_edit_only_own_rows(user_with_change, other_user):
    req = make_request(user=user_with_change)
    assert IUserScope.can_edit(req, user_with_change.pk) is True
    assert IUserScope.can_edit(req, other_user.pk) is False


def test_user_can_edit_requires_change_permission(user):
    req = make_request(user=user)
    assert IUserScope.can_edit(req, user.pk) is False  # no perm


# ---------------------------------------------------------------------------
# IDeviceScope
# ---------------------------------------------------------------------------


def test_device_resolves_to_request_device():
    device = Device.objects.create()
    req = make_request(device=device)
    assert IDeviceScope.resolve(req) == [device.pk]


def test_device_no_device_returns_none():
    req = make_request()
    assert IDeviceScope.resolve(req) is None


def test_device_filter_kwargs():
    kwargs = IDeviceScope.filter_kwargs(42)
    assert kwargs == {"scope": Scope.DEVICE, "device_id": 42}


def test_device_can_edit_only_current_device():
    d1 = Device.objects.create()
    d2 = Device.objects.create()
    req = make_request(device=d1)
    assert IDeviceScope.can_edit(req, d1.pk) is True
    assert IDeviceScope.can_edit(req, d2.pk) is False


# ---------------------------------------------------------------------------
# IGroupScope
# ---------------------------------------------------------------------------


def test_group_resolves_to_users_groups_sorted_asc(user):
    g1 = Group.objects.create(name="aaa")
    g2 = Group.objects.create(name="bbb")
    g3 = Group.objects.create(name="ccc")
    # Add in random order; resolve() must sort by pk ASC.
    user.groups.add(g3, g1, g2)
    req = make_request(user=user)
    pks = IGroupScope.resolve(req)
    assert pks == sorted([g1.pk, g2.pk, g3.pk])


def test_group_empty_returns_none(user):
    req = make_request(user=user)
    assert IGroupScope.resolve(req) is None


def test_group_anonymous_returns_none():
    req = make_request()
    assert IGroupScope.resolve(req) is None


def test_group_filter_kwargs():
    kwargs = IGroupScope.filter_kwargs(3)
    assert kwargs == {"scope": Scope.GROUP, "group_id": 3}


def test_group_can_edit_only_members(user_with_change, other_user):
    g = Group.objects.create(name="team")
    user_with_change.groups.add(g)
    req = make_request(user=user_with_change)
    assert IGroupScope.can_edit(req, g.pk) is True

    # other_user is not in the group
    req2 = make_request(user=other_user)
    assert IGroupScope.can_edit(req2, g.pk) is False


def test_group_ref_display_returns_name():
    g = Group.objects.create(name="doctors")
    assert IGroupScope.ref_display(g.pk) == "doctors"


# ---------------------------------------------------------------------------
# ITenantScope
# ---------------------------------------------------------------------------


def test_tenant_resolves_from_request_tenant():
    tenant = Tenant.objects.create(name="Acme", slug="acme")
    req = make_request(tenant=tenant)
    assert ITenantScope.resolve(req) == [tenant.pk]


def test_tenant_resolves_from_request_tenant_set_by_middleware(user):
    """After the middleware refactor, ITenantScope.resolve() only reads
    request.tenant (set by ConjuntoMiddleware from session / membership).
    Without request.tenant it returns None — the middleware is responsible
    for populating it."""
    tenant = Tenant.objects.create(name="Acme", slug="acme")
    # No request.tenant → None
    req = make_request(user=user)
    assert ITenantScope.resolve(req) is None
    # With request.tenant → resolved
    req2 = make_request(user=user, tenant=tenant)
    assert ITenantScope.resolve(req2) == [tenant.pk]


def test_tenant_request_tenant_takes_precedence_over_session():
    t1 = Tenant.objects.create(name="Primary", slug="primary")
    t2 = Tenant.objects.create(name="Secondary", slug="secondary")
    req = make_request(tenant=t1, session={"cj_tenant_id": t2.pk})
    assert ITenantScope.resolve(req) == [t1.pk]


def test_tenant_no_source_returns_none():
    req = make_request()
    assert ITenantScope.resolve(req) is None


def test_tenant_filter_kwargs():
    kwargs = ITenantScope.filter_kwargs(7)
    assert kwargs == {"scope": Scope.TENANT, "tenant_id": 7}


def test_tenant_can_edit_requires_admin_group_membership(user_with_change):
    tenant = Tenant.objects.create(name="Acme", slug="acme")
    # User has change_scopedsetting but is NOT in the tenant's admin_group.
    req = make_request(user=user_with_change)
    assert ITenantScope.can_edit(req, tenant.pk) is False

    # Add user to the auto-created admin group.
    tenant.admin_group.user_set.add(user_with_change)
    assert ITenantScope.can_edit(req, tenant.pk) is True


def test_tenant_can_edit_without_change_perm_false(user):
    tenant = Tenant.objects.create(name="Acme", slug="acme")
    tenant.admin_group.user_set.add(user)
    req = make_request(user=user)
    # Missing change_scopedsetting perm.
    assert ITenantScope.can_edit(req, tenant.pk) is False


def test_tenant_ref_display_returns_name():
    tenant = Tenant.objects.create(name="Acme Clinic", slug="acme")
    assert ITenantScope.ref_display(tenant.pk) == "Acme Clinic"
