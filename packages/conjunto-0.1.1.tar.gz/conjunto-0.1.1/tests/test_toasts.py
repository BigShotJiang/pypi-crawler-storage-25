"""Tests for the HTMX-based toast delivery system.

Covers:

- ``ConjuntoMessagesMiddleware`` drains ``django.contrib.messages`` on
  HTMX responses and attaches a ``conjunto:toasts`` event to the
  ``HX-Trigger`` header.
- Full-page (non-HTMX) responses leave the messages in storage so the
  template's ``conjunto/includes/toasts.html`` can render them into
  the ``#cj-initial-toasts`` JSON block.
- ``conjunto.http.add_toast`` attaches a ``showToast`` event.
- ``extra_tags="dismissible"`` propagates into the payload.
"""

import json

import pytest
from django.contrib import messages
from django.contrib.messages.storage.fallback import FallbackStorage
from django.http import HttpResponse
from django.test import RequestFactory
from django_htmx.middleware import HtmxMiddleware

from conjunto.http import add_toast
from conjunto.middleware import ConjuntoMessagesMiddleware


def _make_request(factory, *, htmx: bool):
    """Build a request with session + messages storage attached."""
    request = factory.get("/")
    # Minimal session dict — FallbackStorage writes into it.
    request.session = {}
    setattr(request, "_messages", FallbackStorage(request))
    if htmx:
        request.META["HTTP_HX_REQUEST"] = "true"
    return request


def _run_through_middlewares(request, add_messages_fn):
    """Run the HTMX + toasts middleware pair over ``request``.

    ``add_messages_fn`` is called between HtmxMiddleware (which sets
    ``request.htmx``) and the downstream response, so it can populate
    the messages storage exactly as a view would.
    """

    def view(req):
        add_messages_fn(req)
        return HttpResponse("ok")

    def htmx_then_view(req):
        # Emulate HtmxMiddleware's request-side effect by calling it
        # around ``view``.
        return HtmxMiddleware(view)(req)

    middleware = ConjuntoMessagesMiddleware(htmx_then_view)
    return middleware(request)


def _hx_trigger_payload(response) -> dict:
    raw = response.headers.get("HX-Trigger")
    assert raw, "expected HX-Trigger header on response"
    return json.loads(raw)


@pytest.mark.django_db
def test_htmx_response_emits_conjunto_toasts_event():
    factory = RequestFactory()
    request = _make_request(factory, htmx=True)

    def add(req):
        messages.success(req, "Saved")
        messages.error(req, "Kaboom")

    response = _run_through_middlewares(request, add)

    payload = _hx_trigger_payload(response)
    assert "conjunto:toasts" in payload
    toasts = payload["conjunto:toasts"]["toasts"]
    assert [t["message"] for t in toasts] == ["Saved", "Kaboom"]
    assert [t["level"] for t in toasts] == ["success", "error"]
    assert all(t["dismissible"] is False for t in toasts)


@pytest.mark.django_db
def test_dismissible_extra_tag_sets_flag():
    factory = RequestFactory()
    request = _make_request(factory, htmx=True)

    def add(req):
        messages.error(req, "Fatal", extra_tags="dismissible")

    response = _run_through_middlewares(request, add)
    toasts = _hx_trigger_payload(response)["conjunto:toasts"]["toasts"]
    assert len(toasts) == 1
    assert toasts[0]["dismissible"] is True
    assert toasts[0]["level"] == "error"


@pytest.mark.django_db
def test_non_htmx_response_leaves_messages_in_storage():
    factory = RequestFactory()
    request = _make_request(factory, htmx=False)

    def add(req):
        messages.info(req, "Hello")

    response = _run_through_middlewares(request, add)

    # No HX-Trigger header — messages are delivered via the template,
    # not via a client event.
    assert response.headers.get("HX-Trigger") is None

    # Storage still contains the message so the template can render it.
    stored = list(messages.get_messages(request))
    assert len(stored) == 1
    assert str(stored[0].message) == "Hello"


def test_add_toast_helper_sets_show_toast_trigger():
    response = HttpResponse()
    add_toast(response, "Done", level="success", dismissible=True, delay=4000)

    payload = _hx_trigger_payload(response)
    assert "showToast" in payload
    event = payload["showToast"]
    assert event == {
        "message": "Done",
        "level": "success",
        "dismissible": True,
        "delay": 4000,
    }


def test_add_toast_helper_defaults():
    response = HttpResponse()
    add_toast(response, "Hi")

    event = _hx_trigger_payload(response)["showToast"]
    assert event == {
        "message": "Hi",
        "level": "info",
        "dismissible": False,
    }
