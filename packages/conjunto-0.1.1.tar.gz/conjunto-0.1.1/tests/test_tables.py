"""Tests for the CRUD row-action table machinery."""

from __future__ import annotations

import django_tables2 as tables
import pytest
from django.contrib.auth.models import AnonymousUser, Permission, User
from django.http import HttpRequest
from django.urls import path

from conjunto.tables import (
    CrudTableMixin,
    IRowAction,
    RowAction,
    standard_delete_action,
    standard_edit_action,
)
from tests.test_app.models import Person


# --------------------------------------------------------------------------- #
# URL setup: we need concrete URL names `person_update` / `person_delete`     #
# so that the standard actions can `reverse()` them without a real view.      #
# --------------------------------------------------------------------------- #

def _noop(request, pk):  # pragma: no cover - routing only
    from django.http import HttpResponse

    return HttpResponse("")


urlpatterns = [
    path("person/<int:pk>/edit/", _noop, name="person_update"),
    path("person/<int:pk>/delete/", _noop, name="person_delete"),
]


@pytest.fixture(autouse=True)
def _urls(settings):
    settings.ROOT_URLCONF = "tests.test_tables"


# --------------------------------------------------------------------------- #
# Fixtures                                                                    #
# --------------------------------------------------------------------------- #


@pytest.fixture
def request_factory(db):
    def _make(user=None):
        req = HttpRequest()
        req.method = "GET"
        req.user = user or AnonymousUser()
        return req

    return _make


@pytest.fixture
def person(db):
    return Person.objects.create(name="Alice")


class PersonTable(CrudTableMixin, tables.Table):
    crud_url_namespace = "person"
    name = tables.Column()

    class Meta:
        model = Person
        fields = ("name",)


# --------------------------------------------------------------------------- #
# RowAction unit tests                                                         #
# --------------------------------------------------------------------------- #


class TestRowAction:
    def test_resolve_url_static(self):
        a = RowAction(name="x", label="X", url="/foo/")
        assert a.resolve_url(object()) == "/foo/"

    def test_resolve_url_callable(self, person):
        a = RowAction(name="x", label="X", url=lambda r: f"/p/{r.pk}/")
        assert a.resolve_url(person) == f"/p/{person.pk}/"

    def test_is_allowed_permission_string(self, person, request_factory):
        req = request_factory()
        a = RowAction(name="x", label="X", permission="auth.change_user")
        assert a.is_allowed(person, req) is False

        user = User.objects.create(username="u")
        user.user_permissions.add(Permission.objects.get(codename="change_user"))
        req2 = request_factory(User.objects.get(pk=user.pk))
        assert a.is_allowed(person, req2) is True

    def test_is_allowed_permission_callable(self, person, request_factory):
        a = RowAction(
            name="x",
            label="X",
            permission=lambda rec, req: rec.name == "Alice",
        )
        assert a.is_allowed(person, request_factory()) is True

    def test_is_allowed_visible(self, person, request_factory):
        a = RowAction(name="x", label="X", visible=lambda rec, req: False)
        assert a.is_allowed(person, request_factory()) is False

    def test_render_attrs_htmx_default(self, person):
        a = RowAction(
            name="x", label="X", icon="pencil", url=lambda r: f"/p/{r.pk}/edit/"
        )
        attrs = a.render_attrs(person)
        assert attrs["hx-get"] == f"/p/{person.pk}/edit/"
        assert attrs["hx-target"] == "#cj-dialog"
        assert attrs["hx-swap"] == "innerHTML"
        assert "btn-icon" in attrs["class"]

    def test_render_attrs_plain_navigation(self, person):
        a = RowAction(
            name="x", label="X", htmx=False, url=lambda r: f"/p/{r.pk}/"
        )
        attrs = a.render_attrs(person)
        assert attrs["href"] == f"/p/{person.pk}/"
        assert "hx-get" not in attrs

    def test_render_attrs_inline_confirm(self, person):
        a = standard_delete_action("person", confirm_style="inline")
        attrs = a.render_attrs(person)
        assert "hx-post" in attrs
        assert attrs["hx-confirm"]  # non-empty

    def test_render_attrs_modal_confirm(self, person):
        a = standard_delete_action("person", confirm_style="modal")
        attrs = a.render_attrs(person)
        # Modal confirm fetches the confirm URL into the dialog.
        assert "hx-get" in attrs
        assert attrs["hx-target"] == "#cj-dialog"
        assert "hx-post" not in attrs


# --------------------------------------------------------------------------- #
# CrudTableMixin tests                                                         #
# --------------------------------------------------------------------------- #


class TestCrudTableMixin:
    def test_missing_namespace_raises(self):
        class Broken(CrudTableMixin, tables.Table):
            class Meta:
                model = Person
                fields = ("name",)

        with pytest.raises(AttributeError, match="crud_url_namespace"):
            Broken([])

    def test_actions_column_is_last(self, person, request_factory):
        table = PersonTable([person], request=request_factory())
        assert list(table.columns.iterall())[-1].name == "actions"

    def test_standard_actions_rendered(self, person, request_factory):
        table = PersonTable([person], request=request_factory())
        html = str(table.rows[0].get_cell("actions"))
        assert "ti-pencil" in html
        assert "ti-trash" in html
        assert f"/person/{person.pk}/edit/" in html

    def test_actions_sorted_by_weight(self, person, request_factory):
        class Weighted(PersonTable):
            def get_standard_actions(self):
                return [
                    RowAction(name="late", label="L", icon="a", url="/a", weight=999),
                    RowAction(name="early", label="E", icon="b", url="/b", weight=1),
                ]

        table = Weighted([person], request=request_factory())
        html = str(table.rows[0].get_cell("actions"))
        assert html.index("ti-b") < html.index("ti-a")

    def test_permission_filters_edit(self, person, request_factory):
        class PermTable(PersonTable):
            edit_permission = "auth.change_user"  # user has none
            crud_actions = ("edit",)

        table = PermTable([person], request=request_factory())
        html = str(table.rows[0].get_cell("actions"))
        assert "ti-pencil" not in html

    def test_listen_events_default(self, request_factory):
        table = PersonTable([], request=request_factory())
        events = table.get_listen_events()
        assert "person:created" in events
        assert "person:changed" in events
        assert "person:deleted" in events

    def test_listen_events_respect_crud_actions(self, request_factory):
        class ReadOnly(PersonTable):
            crud_actions = ()

        table = ReadOnly([], request=request_factory())
        # :created always fires; :changed/:deleted only when enabled
        assert table.get_listen_events() == ["person:created"]

    def test_hx_trigger_joins_events(self, request_factory):
        table = PersonTable([], request=request_factory())
        trig = table.hx_trigger
        assert "person:created from:body" in trig
        assert trig.count(",") == 2

    def test_wrapper_id(self, request_factory):
        table = PersonTable([], request=request_factory())
        assert table.wrapper_id == "cj-table-person"


# --------------------------------------------------------------------------- #
# IRowAction plugin integration                                                #
# --------------------------------------------------------------------------- #


class TestIRowActionPlugin:
    def test_extra_action_from_plugin(self, person, request_factory, monkeypatch):
        class MyExtra(IRowAction):
            menu = "person_row"
            weight = 5

            def to_row_action(self, request, record):
                return RowAction(
                    name="archive",
                    label="Archive",
                    icon="archive",
                    url=f"/p/{record.pk}/archive/",
                )

        class PluginTable(PersonTable):
            extra_actions_menu = "person_row"

        monkeypatch.setattr(IRowAction, "enabled_plugins", classmethod(lambda cls: [MyExtra]))

        table = PluginTable([person], request=request_factory())
        html = str(table.rows[0].get_cell("actions"))
        assert "ti-archive" in html
        # Plugin weight 5 should place archive before edit/delete (10/20)
        assert html.index("ti-archive") < html.index("ti-pencil")

    def test_plugin_returning_none_is_skipped(
        self, person, request_factory, monkeypatch
    ):
        class SkipAction(IRowAction):
            menu = "person_row"

            def to_row_action(self, request, record):
                return None

        class PluginTable(PersonTable):
            extra_actions_menu = "person_row"

        monkeypatch.setattr(
            IRowAction, "enabled_plugins", classmethod(lambda cls: [SkipAction])
        )

        table = PluginTable([person], request=request_factory())
        html = str(table.rows[0].get_cell("actions"))
        # Only the two standard icons render.
        assert html.count("<button") == 2


# --------------------------------------------------------------------------- #
# standard_*_action unit tests                                                 #
# --------------------------------------------------------------------------- #


class TestStandardActions:
    def test_edit_uses_update_url_name(self, person):
        a = standard_edit_action("person")
        assert a.resolve_url(person).endswith(f"/person/{person.pk}/edit/")

    def test_delete_uses_delete_url_name(self, person):
        a = standard_delete_action("person")
        assert a.resolve_url(person).endswith(f"/person/{person.pk}/delete/")
