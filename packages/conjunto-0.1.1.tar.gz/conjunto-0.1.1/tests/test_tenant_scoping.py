"""Tests for TenantModelMixin / OptionalTenantModelMixin auto-scoping.

Covers:
- ``objects`` filters by the tenant bound on the ContextVar
- ``objects.create`` / ``objects.bulk_create`` inject the bound tenant
- ``objects`` raises TenantScopeMissing when no tenant is bound
- ``all_objects`` bypasses the filter and is used as ``_base_manager``
- ``OptionalTenantModelMixin`` surfaces global (tenant=NULL) rows to
  every tenant
- OptionalTenant does **not** auto-inject tenant on create
"""

import pytest

from conjunto.tenants.context import override_tenant
from conjunto.tenants.managers import TenantScopeMissing
from conjunto.tenants.models import Tenant

from tests.test_app.models import OptionalTenantDoc, TenantDoc


pytestmark = pytest.mark.django_db


@pytest.fixture
def tenants():
    acme = Tenant.objects.create(name="Acme", slug="acme")
    globex = Tenant.objects.create(name="Globex", slug="globex")
    return acme, globex


# ---------------------------------------------------------------------------
# TenantModelMixin
# ---------------------------------------------------------------------------


def test_objects_filters_by_bound_tenant(tenants):
    acme, globex = tenants
    with override_tenant(acme):
        a = TenantDoc.objects.create(title="A")
    with override_tenant(globex):
        g = TenantDoc.objects.create(title="G")

    with override_tenant(acme):
        assert list(TenantDoc.objects.all()) == [a]
    with override_tenant(globex):
        assert list(TenantDoc.objects.all()) == [g]


def test_create_auto_injects_tenant(tenants):
    acme, _ = tenants
    with override_tenant(acme):
        doc = TenantDoc.objects.create(title="A")
    assert doc.tenant_id == acme.pk


def test_bulk_create_auto_injects_tenant(tenants):
    acme, _ = tenants
    with override_tenant(acme):
        TenantDoc.objects.bulk_create(
            [TenantDoc(title="x"), TenantDoc(title="y")]
        )
    assert TenantDoc.all_objects.filter(tenant=acme).count() == 2


def test_create_explicit_tenant_is_respected(tenants):
    acme, globex = tenants
    with override_tenant(acme):
        doc = TenantDoc.objects.create(title="x", tenant=globex)
    assert doc.tenant_id == globex.pk


def test_objects_raises_without_bound_tenant(tenants):
    with pytest.raises(TenantScopeMissing):
        list(TenantDoc.objects.all())
    with pytest.raises(TenantScopeMissing):
        TenantDoc.objects.create(title="x")


def test_all_objects_is_unscoped(tenants):
    acme, globex = tenants
    with override_tenant(acme):
        TenantDoc.objects.create(title="a")
    with override_tenant(globex):
        TenantDoc.objects.create(title="g")

    # No tenant bound here — all_objects must still work.
    assert TenantDoc.all_objects.count() == 2


def test_all_objects_is_base_manager():
    assert TenantDoc._meta.base_manager.__class__ is type(TenantDoc.all_objects)
    assert TenantDoc._meta.base_manager_name == "all_objects"


# ---------------------------------------------------------------------------
# OptionalTenantModelMixin
# ---------------------------------------------------------------------------


def test_optional_shows_global_rows_to_every_tenant(tenants):
    acme, globex = tenants
    # Global row — no tenant bound, use all_objects to create it.
    global_doc = OptionalTenantDoc.all_objects.create(title="global", tenant=None)
    with override_tenant(acme):
        acme_doc = OptionalTenantDoc.objects.create(title="acme", tenant=acme)

    with override_tenant(acme):
        titles = set(OptionalTenantDoc.objects.values_list("title", flat=True))
        assert titles == {"global", "acme"}
    with override_tenant(globex):
        titles = set(OptionalTenantDoc.objects.values_list("title", flat=True))
        assert titles == {"global"}


def test_optional_create_does_not_auto_inject(tenants):
    acme, _ = tenants
    with override_tenant(acme):
        doc = OptionalTenantDoc.objects.create(title="x")
    assert doc.tenant_id is None


def test_optional_without_bound_tenant_returns_globals_only(tenants):
    acme, _ = tenants
    OptionalTenantDoc.all_objects.create(title="global", tenant=None)
    OptionalTenantDoc.all_objects.create(title="acme-only", tenant=acme)

    # No tenant bound — degrades to global rows only, does NOT raise.
    titles = set(OptionalTenantDoc.objects.values_list("title", flat=True))
    assert titles == {"global"}
