"""Tests for TenantPickView (POST-only) and tenant_badge template tag."""

import pytest
from django.contrib.auth import get_user_model
from django.test import RequestFactory
from django.views.generic import View

from conjunto.tenants.mixins import TenantRequiredMixin
from conjunto.tenants.models import Tenant, TenantMembership
from conjunto.tenants.views import SESSION_KEY


pytestmark = pytest.mark.django_db
User = get_user_model()


# ---------------------------------------------------------------------------
# TenantRequiredMixin
# ---------------------------------------------------------------------------


class _Probe(TenantRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        from django.http import HttpResponse

        return HttpResponse("ok")


def _attach_session_messages(request):
    from django.contrib.messages.storage.fallback import FallbackStorage
    from django.contrib.sessions.backends.db import SessionStore

    request.session = SessionStore()
    setattr(request, "_messages", FallbackStorage(request))
    return request


def test_mixin_redirects_when_no_tenant_bound():
    request = RequestFactory().get("/secret/")
    request.tenant = None
    _attach_session_messages(request)

    response = _Probe.as_view()(request)
    assert response.status_code == 302
    assert response["Location"] == "/"


def test_mixin_passes_through_when_tenant_bound():
    request = RequestFactory().get("/secret/")
    request.tenant = Tenant.objects.create(name="Acme", slug="acme")
    _attach_session_messages(request)

    response = _Probe.as_view()(request)
    assert response.status_code == 200
    assert response.content == b"ok"


# ---------------------------------------------------------------------------
# TenantPickView — POST
# ---------------------------------------------------------------------------


def test_pick_post_stores_selection_in_session_and_redirects(client):
    acme = Tenant.objects.create(name="Acme", slug="acme")
    admin = User.objects.create_superuser(username="root", password="x")
    client.force_login(admin)

    response = client.post(
        "/tenants/pick/", {"tenant": str(acme.pk), "next": "/dashboard/"}
    )
    assert response.status_code == 302
    assert response["Location"] == "/dashboard/"
    assert client.session[SESSION_KEY] == acme.pk


def test_pick_post_rejects_tenant_user_is_not_allowed_on(client):
    forbidden = Tenant.objects.create(name="Globex", slug="globex")
    user = User.objects.create_user(username="alice", password="x")
    client.force_login(user)

    response = client.post("/tenants/pick/", {"tenant": str(forbidden.pk)})
    assert response.status_code == 302
    assert response["Location"].endswith("/tenants/pick/")
    assert SESSION_KEY not in client.session


def test_pick_post_rejects_open_redirect(client):
    acme = Tenant.objects.create(name="Acme", slug="acme")
    admin = User.objects.create_superuser(username="root", password="x")
    client.force_login(admin)

    response = client.post(
        "/tenants/pick/",
        {"tenant": str(acme.pk), "next": "https://evil.example/"},
    )
    assert response.status_code == 302
    assert response["Location"] == "/"


def test_pick_post_htmx_returns_hx_refresh(client):
    acme = Tenant.objects.create(name="Acme", slug="acme")
    admin = User.objects.create_superuser(username="root", password="x")
    client.force_login(admin)

    response = client.post(
        "/tenants/pick/",
        {"tenant": str(acme.pk)},
        HTTP_HX_REQUEST="true",
    )
    assert response.status_code == 204
    assert response["HX-Refresh"] == "true"
    assert client.session[SESSION_KEY] == acme.pk


def test_pick_get_not_allowed(client):
    admin = User.objects.create_superuser(username="root", password="x")
    client.force_login(admin)
    response = client.get("/tenants/pick/")
    assert response.status_code == 405


# ---------------------------------------------------------------------------
# tenant_badge template tag
# ---------------------------------------------------------------------------


def test_badge_can_switch_includes_tenants():
    from conjunto.tenants.templatetags.tenant_tags import tenant_badge

    acme = Tenant.objects.create(name="Acme", slug="acme")
    globex = Tenant.objects.create(name="Globex", slug="globex")
    admin = User.objects.create_superuser(username="root", password="x")

    factory = RequestFactory()
    request = factory.get("/")
    request.user = admin
    request.tenant = acme
    request.session = {SESSION_KEY: acme.pk}

    ctx = tenant_badge({"request": request})
    assert ctx["tenant"] == acme
    assert ctx["can_switch"] is True
    assert set(ctx["tenants"]) == {acme, globex}
    assert ctx["current_tenant_id"] == acme.pk


def test_badge_no_switch_when_single_tenant():
    from conjunto.tenants.templatetags.tenant_tags import tenant_badge

    only = Tenant.objects.create(name="Acme", slug="acme")
    user = User.objects.create_user(username="alice", password="x")
    TenantMembership.objects.create(user=user, tenant=only, role="admin")

    factory = RequestFactory()
    request = factory.get("/")
    request.user = user
    request.tenant = only
    request.session = {}

    ctx = tenant_badge({"request": request})
    assert ctx["tenant"] == only
    assert ctx["can_switch"] is False
    assert list(ctx["tenants"]) == []
    assert ctx["current_tenant_id"] == only.pk
