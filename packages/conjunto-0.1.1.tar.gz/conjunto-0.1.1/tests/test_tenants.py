"""Tests for conjunto.tenants — AbstractTenant, swappable Tenant, helpers.

Covers:
- save() materializes the ``tenant:<slug>:tenant_admin`` role group
- ``admin_group`` property returns the materialized group
- save() is idempotent (no duplicate groups)
- natural_key returns slug tuple
- __str__ returns name
- is_active filtering
- get_tenant_model() returns the concrete default model
- get_tenant_model() honors CONJUNTO_TENANT_MODEL override
- get_tenant_model() raises ImproperlyConfigured on bad settings
"""

import pytest
from django.contrib.auth.models import Group
from django.core.exceptions import ImproperlyConfigured

from conjunto.tenants.models import Tenant
from conjunto.tenants.utils import get_tenant_model


pytestmark = pytest.mark.django_db


# ---------------------------------------------------------------------------
# AbstractTenant / Tenant behavior
# ---------------------------------------------------------------------------


def test_save_materializes_admin_role_group():
    """Saving a Tenant materializes ``tenant:<slug>:tenant_admin`` as an auth.Group."""
    tenant = Tenant.objects.create(name="Acme Clinic", slug="acme")
    assert Group.objects.filter(name="tenant:acme:tenant_admin").count() == 1
    # The admin_group property returns the same group.
    assert tenant.admin_group.name == "tenant:acme:tenant_admin"


def test_save_reuses_existing_role_group():
    """If a role group already exists (e.g. created out-of-band),
    materialization picks it up instead of erroring."""
    Group.objects.create(name="tenant:reused:tenant_admin")
    tenant = Tenant.objects.create(name="Reused Clinic", slug="reused")
    assert Group.objects.filter(name="tenant:reused:tenant_admin").count() == 1
    assert tenant.admin_group.name == "tenant:reused:tenant_admin"


def test_save_is_idempotent():
    """Re-saving a Tenant doesn't create duplicate role groups."""
    tenant = Tenant.objects.create(name="Idempotent Clinic", slug="idem")
    tenant.name = "Idempotent Clinic Renamed"
    tenant.save()
    assert Group.objects.filter(name="tenant:idem:tenant_admin").count() == 1


def test_slug_is_immutable_after_first_save():
    """save() must reject a slug change on an existing row."""
    tenant = Tenant.objects.create(name="Slug Clinic", slug="slugone")
    tenant.slug = "slugtwo"
    with pytest.raises(ValueError, match="immutable"):
        tenant.save()


def test_natural_key_is_slug_tuple():
    tenant = Tenant.objects.create(name="NatKey Clinic", slug="natkey")
    assert tenant.natural_key() == ("natkey",)


def test_str_returns_name():
    tenant = Tenant.objects.create(name="Display Name Clinic", slug="display")
    assert str(tenant) == "Display Name Clinic"


def test_is_active_default_true_and_filter():
    active = Tenant.objects.create(name="A", slug="a")
    inactive = Tenant.objects.create(name="B", slug="b", is_active=False)
    active_ids = set(Tenant.objects.filter(is_active=True).values_list("id", flat=True))
    assert active.pk in active_ids
    assert inactive.pk not in active_ids


def test_uuid_is_unique_and_auto_populated():
    a = Tenant.objects.create(name="A", slug="a")
    b = Tenant.objects.create(name="B", slug="b")
    assert a.uuid is not None
    assert b.uuid is not None
    assert a.uuid != b.uuid


# ---------------------------------------------------------------------------
# get_tenant_model() helper
# ---------------------------------------------------------------------------


def test_get_tenant_model_returns_default():
    """With CONJUNTO_TENANT_MODEL unset, returns the default concrete Tenant."""
    model = get_tenant_model()
    assert model is Tenant
    assert model._meta.label_lower == "conjunto_tenants.tenant"


def test_get_tenant_model_malformed_label(settings):
    settings.CONJUNTO_TENANT_MODEL = "not_a_valid_label"
    with pytest.raises(ImproperlyConfigured, match="app_label.ModelName"):
        get_tenant_model()


def test_get_tenant_model_missing_app(settings):
    settings.CONJUNTO_TENANT_MODEL = "nonexistent_app.Tenant"
    with pytest.raises(ImproperlyConfigured, match="has not been installed"):
        get_tenant_model()
