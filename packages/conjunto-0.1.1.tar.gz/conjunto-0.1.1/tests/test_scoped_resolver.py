"""Tests for ``conjunto.settings.scoped.resolver.get_effective`` (C6).

The resolver is the heart of the scoped settings subsystem. This file
is deliberately the biggest in the suite:

- **Base priority walk**: each single-scope row is the winner when
  alone.
- **Overlay chain**: multi-scope rows override correctly.
- **Locks**: each scope can pin a value; lowest-priority lock wins.
- **Site filter**: site-specific beats site-null within a tier; cross-
  site rows don't bleed.
- **IGroupScope multiplicity**: normal highest-pk wins; locked lowest-pk
  wins.
- **Strict missing spec**: unregistered key → KeyError.
- **Default fallback**: no rows → spec.default.
"""

from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser, Group
from django.contrib.sites.models import Site

from conjunto.settings.scoped.models import Device, Scope, ScopedSetting
from conjunto.settings.scoped.registry import SettingRegistry
from conjunto.settings.scoped.resolver import get_effective
from conjunto.settings.scoped.testing import unfreeze_registry
from conjunto.tenants.models import Tenant


pytestmark = pytest.mark.django_db


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def registry():
    """Unfreeze the registry and register a default `core.theme` spec."""
    with unfreeze_registry() as reg:
        reg.register(
            "core",
            "theme",
            type="str",
            default="DEFAULT",
            writable_scopes=[
                Scope.VENDOR, Scope.TENANT, Scope.GROUP, Scope.DEVICE, Scope.USER,
            ],
            lockable_scopes=[
                Scope.VENDOR, Scope.TENANT, Scope.GROUP, Scope.DEVICE, Scope.USER,
            ],
        )
        yield reg


@pytest.fixture
def user():
    return get_user_model().objects.create_user(username="alice", password="x")


@pytest.fixture
def device():
    return Device.objects.create()


@pytest.fixture
def tenant():
    return Tenant.objects.create(name="Acme", slug="acme")


@pytest.fixture
def group():
    return Group.objects.create(name="team")


@pytest.fixture
def site_a():
    return Site.objects.create(domain="a.test", name="A")


def make_request(user=None, device=None, tenant=None, site=None, session=None):
    return SimpleNamespace(
        user=user or AnonymousUser(),
        device=device,
        tenant=tenant,
        site=site,
        session=session or {},
    )


def _row(scope, value, *, locked=False, user=None, group=None, device=None,
         tenant=None, site=None, key="theme"):
    return ScopedSetting.objects.create(
        namespace="core",
        key=key,
        scope=scope,
        value=value,
        locked=locked,
        user=user,
        group=group,
        device=device,
        tenant=tenant,
        site=site,
    )


# ---------------------------------------------------------------------------
# Default fallback + strict spec
# ---------------------------------------------------------------------------


def test_no_rows_returns_spec_default(registry):
    req = make_request()
    assert get_effective("core", "theme", req) == "DEFAULT"


def test_missing_spec_raises_keyerror(registry):
    req = make_request()
    with pytest.raises(KeyError, match="not registered"):
        get_effective("core", "nonexistent", req)


# ---------------------------------------------------------------------------
# Single-scope baseline (each scope wins when alone)
# ---------------------------------------------------------------------------


def test_vendor_only(registry):
    _row(Scope.VENDOR, "V")
    req = make_request()
    assert get_effective("core", "theme", req) == "V"


def test_tenant_only(registry, tenant):
    _row(Scope.TENANT, "T", tenant=tenant)
    req = make_request(tenant=tenant)
    assert get_effective("core", "theme", req) == "T"


def test_group_only(registry, user, group):
    user.groups.add(group)
    _row(Scope.GROUP, "G", group=group)
    req = make_request(user=user)
    assert get_effective("core", "theme", req) == "G"


def test_device_only(registry, device):
    _row(Scope.DEVICE, "D", device=device)
    req = make_request(device=device)
    assert get_effective("core", "theme", req) == "D"


def test_user_only(registry, user):
    _row(Scope.USER, "U", user=user)
    req = make_request(user=user)
    assert get_effective("core", "theme", req) == "U"


# ---------------------------------------------------------------------------
# Priority overlay (no locks)
# ---------------------------------------------------------------------------


def test_user_overrides_vendor(registry, user):
    _row(Scope.VENDOR, "V")
    _row(Scope.USER, "U", user=user)
    req = make_request(user=user)
    assert get_effective("core", "theme", req) == "U"


def test_device_overrides_group(registry, user, group, device):
    user.groups.add(group)
    _row(Scope.GROUP, "G", group=group)
    _row(Scope.DEVICE, "D", device=device)
    req = make_request(user=user, device=device)
    assert get_effective("core", "theme", req) == "D"


def test_user_overrides_device_overrides_group_overrides_tenant_overrides_vendor(
    registry, user, group, device, tenant
):
    user.groups.add(group)
    _row(Scope.VENDOR, "V")
    _row(Scope.TENANT, "T", tenant=tenant)
    _row(Scope.GROUP, "G", group=group)
    _row(Scope.DEVICE, "D", device=device)
    _row(Scope.USER, "U", user=user)
    req = make_request(user=user, device=device, tenant=tenant)
    assert get_effective("core", "theme", req) == "U"


def test_missing_highest_falls_to_next(registry, user, device, tenant):
    _row(Scope.VENDOR, "V")
    _row(Scope.TENANT, "T", tenant=tenant)
    _row(Scope.DEVICE, "D", device=device)
    # No USER row.
    req = make_request(user=user, device=device, tenant=tenant)
    assert get_effective("core", "theme", req) == "D"


def test_anonymous_user_skips_user_scope(registry):
    """Anonymous request: USER scope returns refs=None, skipped entirely."""
    _row(Scope.VENDOR, "V")
    req = make_request()  # AnonymousUser, no device
    assert get_effective("core", "theme", req) == "V"


# ---------------------------------------------------------------------------
# Locks
# ---------------------------------------------------------------------------


def test_vendor_lock_blocks_user(registry, user):
    _row(Scope.VENDOR, "V", locked=True)
    _row(Scope.USER, "U", user=user)
    req = make_request(user=user)
    assert get_effective("core", "theme", req) == "V"


def test_tenant_lock_blocks_higher_scopes(registry, user, device, tenant):
    _row(Scope.VENDOR, "V")
    _row(Scope.TENANT, "T", tenant=tenant, locked=True)
    _row(Scope.DEVICE, "D", device=device)
    _row(Scope.USER, "U", user=user)
    req = make_request(user=user, device=device, tenant=tenant)
    assert get_effective("core", "theme", req) == "T"


def test_group_lock_blocks_user_and_device(registry, user, group, device):
    user.groups.add(group)
    _row(Scope.GROUP, "G", group=group, locked=True)
    _row(Scope.DEVICE, "D", device=device)
    _row(Scope.USER, "U", user=user)
    req = make_request(user=user, device=device)
    assert get_effective("core", "theme", req) == "G"


def test_user_lock_does_not_block_itself(registry, user):
    """A USER-scope lock wins simply because USER is the highest tier."""
    _row(Scope.USER, "U", user=user, locked=True)
    req = make_request(user=user)
    assert get_effective("core", "theme", req) == "U"


def test_lowest_priority_lock_wins_over_higher_lock(registry, user, tenant):
    """Two locks → the one at lower priority (VENDOR) wins."""
    _row(Scope.VENDOR, "V", locked=True)
    _row(Scope.TENANT, "T", tenant=tenant, locked=True)
    _row(Scope.USER, "U", user=user, locked=True)
    req = make_request(user=user, tenant=tenant)
    assert get_effective("core", "theme", req) == "V"


def test_tenant_lock_beats_group_lock(registry, user, group, tenant):
    user.groups.add(group)
    _row(Scope.TENANT, "T", tenant=tenant, locked=True)
    _row(Scope.GROUP, "G", group=group, locked=True)
    req = make_request(user=user, tenant=tenant)
    assert get_effective("core", "theme", req) == "T"


# ---------------------------------------------------------------------------
# Site filter
# ---------------------------------------------------------------------------


def test_site_specific_beats_site_null_same_scope(registry, site_a):
    _row(Scope.VENDOR, "global")
    _row(Scope.VENDOR, "site_a", site=site_a)
    req = make_request(site=site_a)
    assert get_effective("core", "theme", req) == "site_a"


def test_site_null_used_when_no_site_specific_match(registry, site_a):
    _row(Scope.VENDOR, "global")
    req = make_request(site=site_a)
    assert get_effective("core", "theme", req) == "global"


def test_other_site_row_does_not_bleed(registry):
    other_site = Site.objects.create(domain="other.test", name="Other")
    _row(Scope.VENDOR, "other_site", site=other_site)
    # Request with no site → filter matches only site IS NULL rows.
    req = make_request()
    assert get_effective("core", "theme", req) == "DEFAULT"


def test_cross_site_rows_isolated(registry, site_a):
    other_site = Site.objects.create(domain="other.test", name="Other")
    _row(Scope.VENDOR, "for_a", site=site_a)
    _row(Scope.VENDOR, "for_other", site=other_site)
    req = make_request(site=site_a)
    assert get_effective("core", "theme", req) == "for_a"


def test_site_specific_user_row_wins_over_site_null_user_row(
    registry, user, site_a
):
    _row(Scope.USER, "user_global", user=user)
    _row(Scope.USER, "user_site_a", user=user, site=site_a)
    req = make_request(user=user, site=site_a)
    assert get_effective("core", "theme", req) == "user_site_a"


# ---------------------------------------------------------------------------
# IGroupScope multiplicity
# ---------------------------------------------------------------------------


def test_group_multiplicity_highest_pk_wins_unlocked(registry, user):
    g1 = Group.objects.create(name="aaa")
    g2 = Group.objects.create(name="bbb")
    g3 = Group.objects.create(name="ccc")
    user.groups.add(g1, g2, g3)
    _row(Scope.GROUP, "G1", group=g1)
    _row(Scope.GROUP, "G2", group=g2)
    _row(Scope.GROUP, "G3", group=g3)
    req = make_request(user=user)
    # Highest-pk group wins in normal walk.
    assert get_effective("core", "theme", req) == "G3"


def test_group_multiplicity_locked_lowest_pk_wins(registry, user):
    g1 = Group.objects.create(name="aaa")
    g2 = Group.objects.create(name="bbb")
    g3 = Group.objects.create(name="ccc")
    user.groups.add(g1, g2, g3)
    _row(Scope.GROUP, "G1", group=g1, locked=True)
    _row(Scope.GROUP, "G2", group=g2, locked=True)
    _row(Scope.GROUP, "G3", group=g3)  # unlocked
    req = make_request(user=user)
    # Among locked rows (g1, g2), lowest-pk wins → G1.
    assert get_effective("core", "theme", req) == "G1"


def test_group_locked_beats_unlocked_in_same_tier(registry, user):
    g1 = Group.objects.create(name="aaa")
    g2 = Group.objects.create(name="bbb")
    user.groups.add(g1, g2)
    _row(Scope.GROUP, "G1", group=g1, locked=True)  # lowest-pk, locked
    _row(Scope.GROUP, "G2", group=g2)  # highest-pk, unlocked
    _row(Scope.USER, "U", user=user)  # would normally win
    req = make_request(user=user)
    # Lock in GROUP tier short-circuits → G1 wins.
    assert get_effective("core", "theme", req) == "G1"


def test_user_not_in_target_group_does_not_match(registry, user):
    g = Group.objects.create(name="outsider")
    _row(Scope.GROUP, "OUTSIDE", group=g)
    req = make_request(user=user)
    # user is not in g → IGroupScope.resolve returns None → skip
    assert get_effective("core", "theme", req) == "DEFAULT"


# ---------------------------------------------------------------------------
# JSON native-type values round-trip through the resolver
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "stored_value",
    [
        42,
        True,
        ["a", "b"],
        {"nested": 1},
    ],
)
def test_resolver_returns_native_json_types(registry, stored_value):
    _row(Scope.VENDOR, stored_value)
    req = make_request()
    assert get_effective("core", "theme", req) == stored_value
