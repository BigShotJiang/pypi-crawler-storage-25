"""Tests for ScopedSetting DB-level constraints (C3).

Every CheckConstraint and partial UniqueConstraint branch must fail
loudly. These tests assert IntegrityError on every structural violation
so a future refactor that breaks the SQL can't ship silently.

Covers:
- CheckConstraint "scope_ref_matches": each of the 5 scopes accepts only
  its own FK set.
- UniqueConstraint per scope: duplicate rows at the same (ns, key,
  scope, ref, site) raise IntegrityError.
- Coalesce(site_id, 0) collapses NULL site into a single slot for the
  uniqueness check (so duplicates with site=NULL also fail).
- JSONField accepts native types (str, int, bool, None, list, dict).
- Locked flag stores and round-trips.
"""

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.sites.models import Site
from django.db import IntegrityError, transaction

from conjunto.settings.scoped.models import Device, Scope, ScopedSetting
from conjunto.tenants.models import Tenant


pytestmark = pytest.mark.django_db


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def user():
    return get_user_model().objects.create_user(username="alice", password="x")


@pytest.fixture
def group():
    return Group.objects.create(name="testers")


@pytest.fixture
def device():
    return Device.objects.create()


@pytest.fixture
def tenant():
    return Tenant.objects.create(name="Acme", slug="acme")


@pytest.fixture
def site():
    return Site.objects.create(domain="example.test", name="Example")


# ---------------------------------------------------------------------------
# Happy-path: one valid row per scope
# ---------------------------------------------------------------------------


def test_vendor_row_accepts_all_null_fks():
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="dark"
    )


def test_user_row_requires_user(user):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.USER, user=user, value="dark"
    )


def test_group_row_requires_group(group):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.GROUP, group=group, value="dark"
    )


def test_device_row_requires_device(device):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.DEVICE, device=device, value="dark"
    )


def test_tenant_row_requires_tenant(tenant):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.TENANT, tenant=tenant, value="dark"
    )


# ---------------------------------------------------------------------------
# CheckConstraint: scope ↔ FK exclusivity
# ---------------------------------------------------------------------------


def test_vendor_rejects_user_fk(user):
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core",
            key="x",
            scope=Scope.VENDOR,
            user=user,
            value="x",
        )


def test_user_scope_requires_user_fk():
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core", key="x", scope=Scope.USER, value="x"
        )


def test_user_scope_rejects_extra_group_fk(user, group):
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core",
            key="x",
            scope=Scope.USER,
            user=user,
            group=group,
            value="x",
        )


def test_tenant_scope_rejects_user_fk(user, tenant):
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core",
            key="x",
            scope=Scope.TENANT,
            tenant=tenant,
            user=user,
            value="x",
        )


def test_group_scope_requires_group_fk():
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core", key="x", scope=Scope.GROUP, value="x"
        )


def test_device_scope_requires_device_fk():
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core", key="x", scope=Scope.DEVICE, value="x"
        )


# ---------------------------------------------------------------------------
# UniqueConstraint per scope
# ---------------------------------------------------------------------------


def test_duplicate_vendor_row_site_null_rejected():
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="a"
    )
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core", key="theme", scope=Scope.VENDOR, value="b"
        )


def test_duplicate_vendor_row_same_site_rejected(site):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, site=site, value="a"
    )
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core", key="theme", scope=Scope.VENDOR, site=site, value="b"
        )


def test_vendor_rows_distinct_sites_allowed(site):
    """A vendor row with site=NULL and a vendor row with site=X coexist."""
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.VENDOR, value="global"
    )
    ScopedSetting.objects.create(
        namespace="core",
        key="theme",
        scope=Scope.VENDOR,
        site=site,
        value="site_specific",
    )
    assert ScopedSetting.objects.filter(key="theme").count() == 2


def test_duplicate_user_row_same_user_site_null_rejected(user):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.USER, user=user, value="a"
    )
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core", key="theme", scope=Scope.USER, user=user, value="b"
        )


def test_user_rows_for_different_users_allowed(user):
    other = get_user_model().objects.create_user(username="bob", password="x")
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.USER, user=user, value="a"
    )
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.USER, user=other, value="b"
    )
    assert ScopedSetting.objects.count() == 2


def test_duplicate_group_row_rejected(group):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.GROUP, group=group, value="a"
    )
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core", key="theme", scope=Scope.GROUP, group=group, value="b"
        )


def test_duplicate_device_row_rejected(device):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.DEVICE, device=device, value="a"
    )
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core",
            key="theme",
            scope=Scope.DEVICE,
            device=device,
            value="b",
        )


def test_duplicate_tenant_row_rejected(tenant):
    ScopedSetting.objects.create(
        namespace="core", key="theme", scope=Scope.TENANT, tenant=tenant, value="a"
    )
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core",
            key="theme",
            scope=Scope.TENANT,
            tenant=tenant,
            value="b",
        )


# ---------------------------------------------------------------------------
# JSONField: native type round-trip
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "native_value",
    [
        "string",
        42,
        3.14,
        True,
        False,
        ["a", "b", 1],
        {"nested": {"key": "value"}, "list": [1, 2]},
    ],
)
def test_jsonfield_roundtrips_native_types(native_value):
    row = ScopedSetting.objects.create(
        namespace="core",
        key=f"k_{type(native_value).__name__}",
        scope=Scope.VENDOR,
        value=native_value,
    )
    row.refresh_from_db()
    assert row.value == native_value


def test_value_cannot_be_none():
    """Row absence is the only way to express 'no value at this scope'.
    Writing Python None is rejected by the NOT NULL constraint."""
    with pytest.raises(IntegrityError), transaction.atomic():
        ScopedSetting.objects.create(
            namespace="core", key="theme", scope=Scope.VENDOR, value=None
        )


def test_locked_flag_stores_and_retrieves():
    row = ScopedSetting.objects.create(
        namespace="core",
        key="theme",
        scope=Scope.VENDOR,
        value="dark",
        locked=True,
    )
    row.refresh_from_db()
    assert row.locked is True
