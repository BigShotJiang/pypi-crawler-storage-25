"""Tests for tenant role inheritance, membership, and the auth backend.

Covers the full chain:

- :mod:`conjunto.tenants.roles` — collection, merging, inheritance,
  error detection.
- :class:`conjunto.tenants.models.TenantMembership` — group sync on
  save/delete.
- :class:`conjunto.tenants.backends.TenantAwareModelBackend` — same
  user in two tenants sees different permission sets depending on
  the current tenant context.
"""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import patch

import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType

from conjunto.tenants.backends import TenantAwareModelBackend
from conjunto.tenants.context import override_tenant
from conjunto.tenants.models import Tenant, TenantMembership
from conjunto.tenants.roles import (
    RoleSchemaError,
    collect_raw_schema,
    flatten_inheritance,
    get_flat_schema,
)

pytestmark = pytest.mark.django_db

User = get_user_model()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fake_apps(schema_by_label: dict[str, dict]):
    """Return a list of fake AppConfig-like objects with role schemas."""
    return [
        SimpleNamespace(label=label, tenant_role_permissions=schema)
        for label, schema in schema_by_label.items()
    ]


def _grant_to_role_group(tenant: Tenant, role: str, perm_codename: str) -> None:
    """Add a real auth.Permission to the materialized role group."""
    group = tenant.get_role_group(role)
    # Pick the first matching permission by codename; good enough for tests.
    perm = Permission.objects.filter(codename=perm_codename).first()
    assert perm is not None, f"permission {perm_codename!r} not found"
    group.permissions.add(perm)


# ---------------------------------------------------------------------------
# Schema collection + merging
# ---------------------------------------------------------------------------


def test_collect_merges_permissions_across_apps():
    apps = _fake_apps(
        {
            "app_a": {
                "editor": {"permissions": {"auth.User": ["view"]}},
            },
            "app_b": {
                "editor": {"permissions": {"auth.User": ["change"]}},
            },
        }
    )
    raw = collect_raw_schema(apps)
    assert set(raw["editor"]["permissions"]["auth.User"]) == {"view", "change"}


def test_collect_extends_must_be_consistent():
    apps = _fake_apps(
        {
            "app_a": {"editor": {"extends": "viewer", "permissions": {}}},
            "app_b": {"editor": {"extends": "manager", "permissions": {}}},
        }
    )
    with pytest.raises(RoleSchemaError, match="conflicting 'extends'"):
        collect_raw_schema(apps)


def test_collect_extends_null_and_explicit_is_fine():
    """One app may declare extends while another just adds permissions."""
    apps = _fake_apps(
        {
            "app_a": {
                "viewer": {"permissions": {"auth.User": ["view"]}},
                "editor": {
                    "extends": "viewer",
                    "permissions": {"auth.User": ["change"]},
                },
            },
            "app_b": {
                "editor": {"permissions": {"auth.User": ["add"]}},
            },
        }
    )
    raw = collect_raw_schema(apps)
    assert raw["editor"]["extends"] == "viewer"
    assert set(raw["editor"]["permissions"]["auth.User"]) == {"add", "change"}


def test_flatten_inheritance_propagates_parent_perms():
    apps = _fake_apps(
        {
            "app_a": {
                "viewer": {"permissions": {"auth.User": ["view"]}},
                "editor": {
                    "extends": "viewer",
                    "permissions": {"auth.User": ["change"]},
                },
                "admin": {
                    "extends": "editor",
                    "permissions": {"auth.User": ["delete"]},
                },
            },
        }
    )
    flat = get_flat_schema(apps)
    assert flat["viewer"]["auth.User"] == ["view"]
    assert set(flat["editor"]["auth.User"]) == {"view", "change"}
    assert set(flat["admin"]["auth.User"]) == {"view", "change", "delete"}


def test_flatten_detects_cycles():
    apps = _fake_apps(
        {
            "app_a": {
                "a": {"extends": "b", "permissions": {}},
                "b": {"extends": "a", "permissions": {}},
            },
        }
    )
    with pytest.raises(RoleSchemaError, match="Cyclic"):
        get_flat_schema(apps)


def test_flatten_detects_unknown_parent():
    apps = _fake_apps(
        {
            "app_a": {
                "editor": {"extends": "ghost", "permissions": {}},
            },
        }
    )
    with pytest.raises(RoleSchemaError, match="not declared"):
        flatten_inheritance(collect_raw_schema(apps))


# ---------------------------------------------------------------------------
# TenantMembership — group sync
# ---------------------------------------------------------------------------


def test_membership_save_adds_user_to_role_group():
    tenant = Tenant.objects.create(name="Acme", slug="acme")
    user = User.objects.create_user(username="alice", password="x")

    TenantMembership.objects.create(user=user, tenant=tenant, role="admin")

    assert user.groups.filter(name="tenant:acme:admin").exists()


def test_membership_delete_removes_user_from_role_group():
    tenant = Tenant.objects.create(name="Acme", slug="acme")
    user = User.objects.create_user(username="alice", password="x")
    membership = TenantMembership.objects.create(user=user, tenant=tenant, role="admin")

    membership.delete()

    assert not user.groups.filter(name="tenant:acme:admin").exists()


def test_membership_unique_per_user_tenant_role():
    tenant = Tenant.objects.create(name="Acme", slug="acme")
    user = User.objects.create_user(username="alice", password="x")
    TenantMembership.objects.create(user=user, tenant=tenant, role="admin")

    with pytest.raises(Exception):
        TenantMembership.objects.create(user=user, tenant=tenant, role="admin")


# ---------------------------------------------------------------------------
# TenantAwareModelBackend — tenant-scoped permission checks
# ---------------------------------------------------------------------------


def test_backend_filters_groups_by_current_tenant():
    """Same user in two tenants with two roles → different perms."""
    acme = Tenant.objects.create(name="Acme", slug="acme")
    globex = Tenant.objects.create(name="Globex", slug="globex")
    # Seed each tenant with a dummy user so auto-assign of
    # tenant_admin doesn't kick in for the test user.
    dummy = User.objects.create_user(username="dummy", password="x")
    TenantMembership.objects.create(user=dummy, tenant=acme, role="editor")
    TenantMembership.objects.create(user=dummy, tenant=globex, role="editor")

    user = User.objects.create_user(username="alice", password="x")

    # Acme: alice is editor with full change_user permission.
    # Globex: alice is editor, but we only grant view_user on that group.
    TenantMembership.objects.create(user=user, tenant=acme, role="editor")
    TenantMembership.objects.create(user=user, tenant=globex, role="editor")
    _grant_to_role_group(acme, "editor", "change_user")
    _grant_to_role_group(globex, "editor", "view_user")

    backend = TenantAwareModelBackend()

    with override_tenant(acme):
        assert backend.has_perm(user, "auth.change_user")
        assert not backend.has_perm(user, "auth.view_user")

    # Fresh user fetch to reset the backend's per-instance cache.
    user = User.objects.get(pk=user.pk)
    with override_tenant(globex):
        assert backend.has_perm(user, "auth.view_user")
        assert not backend.has_perm(user, "auth.change_user")


def test_backend_non_tenant_groups_always_contribute():
    """Groups without the ``tenant:`` prefix act as global roles."""
    acme = Tenant.objects.create(name="Acme", slug="acme")
    user = User.objects.create_user(username="bob", password="x")

    global_group = Group.objects.create(name="vendor:support")
    perm = Permission.objects.get(codename="view_user")
    global_group.permissions.add(perm)
    user.groups.add(global_group)

    backend = TenantAwareModelBackend()

    # No tenant bound → global groups still apply.
    assert backend.has_perm(user, "auth.view_user")

    user = User.objects.get(pk=user.pk)
    with override_tenant(acme):
        assert backend.has_perm(user, "auth.view_user")


def test_backend_returns_empty_without_tenant_for_tenant_groups():
    """With no tenant bound, tenant-prefixed groups don't contribute."""
    acme = Tenant.objects.create(name="Acme", slug="acme")
    user = User.objects.create_user(username="carol", password="x")
    TenantMembership.objects.create(user=user, tenant=acme, role="admin")
    _grant_to_role_group(acme, "admin", "view_user")

    backend = TenantAwareModelBackend()

    # No override_tenant() around this call.
    assert not backend.has_perm(user, "auth.view_user")
