"""Tests for SettingRegistry / SettingSpec (C5).

Covers:
- register() happy path + returned SettingSpec shape
- Duplicate registration raises ValueError
- lockable_scopes must be a subset of writable_scopes
- Frozen registry rejects new registrations with RuntimeError
- get_spec() triggers freeze as side effect
- get_spec() raises KeyError for missing specs
- all_for_namespace / all helpers
- unfreeze_registry() test helper snapshots and restores state
"""

import pytest

from conjunto.settings.scoped.models import Scope
from conjunto.settings.scoped.registry import SettingRegistry, SettingSpec
from conjunto.settings.scoped.testing import unfreeze_registry


# ---------------------------------------------------------------------------
# register()
# ---------------------------------------------------------------------------


def test_register_returns_spec_with_expected_fields():
    with unfreeze_registry():
        spec = SettingRegistry.register(
            "core",
            "theme",
            type="str",
            default="light",
            help_text="Color theme",
            icon="palette",
            writable_scopes=[Scope.VENDOR, Scope.USER],
            lockable_scopes=[Scope.VENDOR],
        )
    assert isinstance(spec, SettingSpec)
    assert spec.namespace == "core"
    assert spec.key == "theme"
    assert spec.type == "str"
    assert spec.default == "light"
    assert spec.help_text == "Color theme"
    assert spec.icon == "palette"
    assert spec.writable_scopes == frozenset({Scope.VENDOR, Scope.USER})
    assert spec.lockable_scopes == frozenset({Scope.VENDOR})
    assert spec.dotted == "core.theme"


def test_register_duplicate_raises():
    with unfreeze_registry():
        SettingRegistry.register(
            "core", "theme", type="str", default="light",
            writable_scopes=[Scope.VENDOR],
        )
        with pytest.raises(ValueError, match="already registered"):
            SettingRegistry.register(
                "core", "theme", type="str", default="dark",
                writable_scopes=[Scope.VENDOR],
            )


def test_register_lockable_must_be_subset_of_writable():
    with unfreeze_registry():
        with pytest.raises(ValueError, match="subset of writable_scopes"):
            SettingRegistry.register(
                "core",
                "theme",
                type="str",
                default="light",
                writable_scopes=[Scope.VENDOR],
                lockable_scopes=[Scope.VENDOR, Scope.USER],
            )


def test_register_allows_empty_scopes():
    """A read-only key (default only, no writes anywhere) is valid."""
    with unfreeze_registry():
        spec = SettingRegistry.register(
            "core", "constant", type="str", default="hello"
        )
    assert spec.writable_scopes == frozenset()
    assert spec.lockable_scopes == frozenset()


# ---------------------------------------------------------------------------
# Freeze semantics
# ---------------------------------------------------------------------------


def test_register_after_freeze_raises():
    with unfreeze_registry():
        SettingRegistry.freeze()
        with pytest.raises(RuntimeError, match="frozen"):
            SettingRegistry.register(
                "core", "late", type="str", default="too_late"
            )


def test_get_spec_triggers_freeze():
    with unfreeze_registry():
        SettingRegistry.register(
            "core", "theme", type="str", default="light",
            writable_scopes=[Scope.VENDOR],
        )
        assert SettingRegistry.is_frozen() is False
        SettingRegistry.get_spec("core", "theme")
        assert SettingRegistry.is_frozen() is True


def test_freeze_is_idempotent():
    with unfreeze_registry():
        SettingRegistry.freeze()
        SettingRegistry.freeze()  # should not raise
        assert SettingRegistry.is_frozen() is True


# ---------------------------------------------------------------------------
# Lookup
# ---------------------------------------------------------------------------


def test_get_spec_missing_raises_keyerror():
    with unfreeze_registry():
        with pytest.raises(KeyError, match="not registered"):
            SettingRegistry.get_spec("core", "nonexistent")


def test_all_for_namespace_returns_sorted_keys():
    with unfreeze_registry():
        SettingRegistry.register(
            "core", "zebra", type="str", default="",
            writable_scopes=[Scope.VENDOR],
        )
        SettingRegistry.register(
            "core", "alpha", type="str", default="",
            writable_scopes=[Scope.VENDOR],
        )
        SettingRegistry.register(
            "other", "beta", type="str", default="",
            writable_scopes=[Scope.VENDOR],
        )
        specs = SettingRegistry.all_for_namespace("core")
    assert [s.key for s in specs] == ["alpha", "zebra"]


def test_all_returns_all_sorted():
    with unfreeze_registry():
        SettingRegistry.register(
            "b", "x", type="str", default="",
            writable_scopes=[Scope.VENDOR],
        )
        SettingRegistry.register(
            "a", "y", type="str", default="",
            writable_scopes=[Scope.VENDOR],
        )
        SettingRegistry.register(
            "a", "x", type="str", default="",
            writable_scopes=[Scope.VENDOR],
        )
        specs = SettingRegistry.all()
    assert [(s.namespace, s.key) for s in specs] == [("a", "x"), ("a", "y"), ("b", "x")]


# ---------------------------------------------------------------------------
# unfreeze_registry() helper
# ---------------------------------------------------------------------------


def test_unfreeze_registry_restores_state_after_block():
    # Pre-populate outside the block.
    with unfreeze_registry():
        SettingRegistry.register(
            "outer", "k", type="str", default="v",
            writable_scopes=[Scope.VENDOR],
        )
        outer_specs = dict(SettingRegistry._specs)
        outer_frozen = SettingRegistry._frozen

    # Now run a test that mutates the registry.
    with unfreeze_registry():
        SettingRegistry.register(
            "inner", "k", type="int", default=42,
            writable_scopes=[Scope.VENDOR],
        )
        assert ("inner", "k") in SettingRegistry._specs

    # Nothing from inside the block leaked.
    assert ("inner", "k") not in SettingRegistry._specs


def test_unfreeze_registry_can_register_after_freeze_in_outer():
    SettingRegistry.freeze()  # simulate "production" frozen state
    with unfreeze_registry():
        # Inside the block, the registry is unfrozen again.
        assert SettingRegistry.is_frozen() is False
        SettingRegistry.register(
            "t", "k", type="bool", default=False,
            writable_scopes=[Scope.VENDOR],
        )
    # After the block, original frozen state is restored.
    assert SettingRegistry.is_frozen() is True
