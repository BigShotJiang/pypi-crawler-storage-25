"""Tests for the Device model + ScopedSettingsMiddleware (C2).

Covers:
- Fresh request → new Device created, cookie written.
- Returning request → existing Device loaded, cookie NOT re-written.
- Stale/malformed cookie → new Device created, cookie overwritten.
- Authenticated request with unbound device → device.user bound.
- Authenticated request with device already bound to same user → no change.
- Authenticated request with device bound to DIFFERENT user → new Device,
  new cookie, old row preserved with previous user.
- last_seen debounce: within 5 minutes → no update; after 5 minutes → update.
- User agent captured on creation.
"""

import uuid
from datetime import timedelta
from unittest.mock import patch

import pytest
from django.contrib.auth import get_user_model
from django.http import HttpResponse
from django.test import RequestFactory
from django.utils import timezone

from conjunto.middleware import (
    ConjuntoMiddleware,
    DEVICE_COOKIE_MAX_AGE,
    DEVICE_COOKIE_NAME,
)
from conjunto.settings.scoped.models import Device


pytestmark = pytest.mark.django_db


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _noop_get_response(request):
    return HttpResponse("ok")


def _run(request, get_response=_noop_get_response):
    mw = ConjuntoMiddleware(get_response)
    return mw(request)


@pytest.fixture
def rf():
    return RequestFactory()


@pytest.fixture
def user():
    User = get_user_model()
    return User.objects.create_user(username="alice", password="pw")


@pytest.fixture
def other_user():
    User = get_user_model()
    return User.objects.create_user(username="bob", password="pw")


# ---------------------------------------------------------------------------
# Cookie lifecycle
# ---------------------------------------------------------------------------


def test_fresh_request_creates_device_and_sets_cookie(rf):
    request = rf.get("/", HTTP_USER_AGENT="TestAgent/1.0")
    request.user = AnonymousUserStub()
    assert Device.objects.count() == 0

    response = _run(request)

    assert Device.objects.count() == 1
    device = Device.objects.get()
    assert request.device == device
    assert device.user is None
    assert device.user_agent == "TestAgent/1.0"

    # Cookie was set on the response.
    cookie = response.cookies.get(DEVICE_COOKIE_NAME)
    assert cookie is not None
    assert cookie.value == str(device.cookie_id)
    assert cookie["max-age"] == DEVICE_COOKIE_MAX_AGE
    assert cookie["httponly"] is True
    assert cookie["samesite"] == "Lax"


def test_returning_request_reuses_device_and_no_cookie_write(rf):
    existing = Device.objects.create()
    request = rf.get("/")
    request.user = AnonymousUserStub()
    request.COOKIES[DEVICE_COOKIE_NAME] = str(existing.cookie_id)

    response = _run(request)

    assert Device.objects.count() == 1
    assert request.device.pk == existing.pk
    # Cookie already in request → no Set-Cookie in response.
    assert DEVICE_COOKIE_NAME not in response.cookies


def test_stale_cookie_triggers_new_device(rf):
    request = rf.get("/")
    request.user = AnonymousUserStub()
    # Valid UUID but not backed by a row in DB.
    request.COOKIES[DEVICE_COOKIE_NAME] = str(uuid.uuid4())

    response = _run(request)

    assert Device.objects.count() == 1
    device = Device.objects.get()
    assert response.cookies.get(DEVICE_COOKIE_NAME).value == str(device.cookie_id)


def test_malformed_cookie_triggers_new_device(rf):
    request = rf.get("/")
    request.user = AnonymousUserStub()
    request.COOKIES[DEVICE_COOKIE_NAME] = "not-a-uuid-at-all"

    response = _run(request)

    assert Device.objects.count() == 1
    device = Device.objects.get()
    assert response.cookies.get(DEVICE_COOKIE_NAME).value == str(device.cookie_id)


# ---------------------------------------------------------------------------
# User binding
# ---------------------------------------------------------------------------


def test_authenticated_request_binds_unbound_device(rf, user):
    request = rf.get("/")
    request.user = user

    _run(request)

    device = Device.objects.get()
    assert device.user_id == user.pk


def test_same_user_second_request_does_not_rebind(rf, user):
    # First request creates + binds.
    request1 = rf.get("/")
    request1.user = user
    _run(request1)
    first_device = Device.objects.get()

    # Second request with the same cookie + same user.
    request2 = rf.get("/")
    request2.user = user
    request2.COOKIES[DEVICE_COOKIE_NAME] = str(first_device.cookie_id)
    _run(request2)

    assert Device.objects.count() == 1
    assert Device.objects.get().pk == first_device.pk


def test_different_user_on_same_browser_creates_new_device(rf, user, other_user):
    # User alice logs in and gets a device.
    request1 = rf.get("/")
    request1.user = user
    _run(request1)
    alice_device = Device.objects.get()

    # Bob logs in on the same browser (same cookie).
    request2 = rf.get("/")
    request2.user = other_user
    request2.COOKIES[DEVICE_COOKIE_NAME] = str(alice_device.cookie_id)
    response = _run(request2)

    # Two devices now, alice's intact, bob on a fresh one.
    assert Device.objects.count() == 2
    alice_device.refresh_from_db()
    assert alice_device.user_id == user.pk

    bob_device = Device.objects.exclude(pk=alice_device.pk).get()
    assert bob_device.user_id == other_user.pk
    assert request2.device.pk == bob_device.pk
    # Cookie rewritten to bob's device.
    assert response.cookies.get(DEVICE_COOKIE_NAME).value == str(bob_device.cookie_id)


# ---------------------------------------------------------------------------
# last_seen debounce
# ---------------------------------------------------------------------------


def test_last_seen_not_updated_within_debounce_window(rf):
    device = Device.objects.create()
    original_last_seen = device.last_seen

    request = rf.get("/")
    request.user = AnonymousUserStub()
    request.COOKIES[DEVICE_COOKIE_NAME] = str(device.cookie_id)
    _run(request)

    device.refresh_from_db()
    assert device.last_seen == original_last_seen


def test_last_seen_updated_after_debounce_window(rf):
    device = Device.objects.create()
    # Backdate the row by 10 minutes.
    stale_time = timezone.now() - timedelta(minutes=10)
    Device.objects.filter(pk=device.pk).update(last_seen=stale_time)

    request = rf.get("/")
    request.user = AnonymousUserStub()
    request.COOKIES[DEVICE_COOKIE_NAME] = str(device.cookie_id)
    _run(request)

    device.refresh_from_db()
    assert device.last_seen > stale_time


# ---------------------------------------------------------------------------
# Stub for anonymous user (avoids loading auth middleware for a unit test).
# ---------------------------------------------------------------------------


class AnonymousUserStub:
    is_authenticated = False
    pk = None
