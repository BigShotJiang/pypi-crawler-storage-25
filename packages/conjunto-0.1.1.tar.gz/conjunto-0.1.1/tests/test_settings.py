"""Tests for conjunto.settings.

Covers:
- anonymous → login redirect
- authenticated full-page GET (finds User group, Profile section, Name form)
- HTMX pane-swap GET (partial only, no <html>)
- POST success → 204, HX-Trigger with settings:changed + showToast,
  HX-Reswap: none, DB updated
- POST invalid → 200 with single-form partial and bound errors, no trigger,
  DB unchanged
- permission-gated section hidden for unprivileged users, form POST → 403
"""

import json

import pytest
from django.contrib.auth import get_user_model
from django.test import Client
from django.urls import reverse

from conjunto.settings.interfaces import ISettingsSection


pytestmark = pytest.mark.django_db


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def user():
    User = get_user_model()
    return User.objects.create_user(
        username="alice",
        password="pw",
        first_name="Alice",
        last_name="Smith",
    )


@pytest.fixture
def client_logged_in(user):
    c = Client()
    c.force_login(user)
    return c


@pytest.fixture
def permission_gated_section():
    """Register a test section gated by a permission the fixture user lacks."""

    class _SecretSection(ISettingsSection):
        name = "secret"
        group = _section_group()
        title = "Secret"
        icon = "lock"
        weight = 100
        permission_required = "auth.view_user"

    yield _SecretSection

    # Clean up: remove from implementations registry so other tests don't
    # see the leftover class.
    _drop_plugin(ISettingsSection, _SecretSection)


def _section_group():
    # Reuse the built-in UserGroup to avoid having to register a new group.
    from conjunto.settings.menus import UserGroup

    return UserGroup


def _drop_plugin(interface_cls, plugin):
    """Remove ``plugin`` from ``interface_cls._implementations`` (and from
    all its base interfaces)."""
    for cls in [interface_cls, *interface_cls.__mro__]:
        impls = getattr(cls, "_implementations", None)
        if impls is not None:
            impls.discard(plugin)


# ---------------------------------------------------------------------------
# Access control
# ---------------------------------------------------------------------------


def test_anonymous_redirects_to_login():
    resp = Client().get(reverse("settings:index"))
    assert resp.status_code == 302
    assert "/accounts/login/" in resp["Location"]


def test_pane_partial_renders_profile(client_logged_in):
    """Exercise the section/form discovery path via the HTMX partial endpoint.

    The full-page flow extends ``conjunto/base.html``, which needs the full
    request middleware stack (``request.menus``, ``request.app_settings``,
    site metadata). The partial path only renders the ``settings-pane``
    partialdef, which is the path we care about testing here.
    """
    resp = client_logged_in.get(
        reverse("settings:index") + "?section=profile",
        HTTP_HX_REQUEST="true",
        HTTP_HX_TARGET="cj-settings-pane",
    )
    assert resp.status_code == 200
    body = resp.content.decode()
    # Active section title and built-in Name form with prefilled first_name
    assert "Profile" in body
    assert 'name="first_name"' in body
    assert "Alice" in body


def test_defaults_to_first_section_when_no_query(client_logged_in):
    """Without ``?section=...`` the view falls back to the first section."""
    resp = client_logged_in.get(
        reverse("settings:index"),
        HTTP_HX_REQUEST="true",
        HTTP_HX_TARGET="cj-settings-pane",
    )
    assert resp.status_code == 200
    assert "Profile" in resp.content.decode()


# ---------------------------------------------------------------------------
# HTMX partial
# ---------------------------------------------------------------------------


def test_htmx_pane_swap_returns_partial_only(client_logged_in):
    resp = client_logged_in.get(
        reverse("settings:index") + "?section=profile",
        HTTP_HX_REQUEST="true",
        HTTP_HX_TARGET="cj-settings-pane",
    )
    assert resp.status_code == 200
    body = resp.content.decode()
    # partial: no <html>, no <body>
    assert "<html" not in body
    assert "<body" not in body
    # but should contain the active section title and form
    assert "Profile" in body
    assert 'name="first_name"' in body


# ---------------------------------------------------------------------------
# POST success / failure
# ---------------------------------------------------------------------------


def test_post_valid_returns_204_with_triggers(client_logged_in, user):
    resp = client_logged_in.post(
        reverse("settings:form", kwargs={"form_name": "user_name"}),
        data={"first_name": "Alicia", "last_name": "Jones"},
        HTTP_HX_REQUEST="true",
    )
    assert resp.status_code == 204
    assert resp.content == b""
    assert resp["HX-Reswap"] == "none"

    triggers = json.loads(resp["HX-Trigger"])
    assert "settings:changed" in triggers
    assert "showToast" in triggers
    assert triggers["showToast"]["type"] == "success"

    # DB updated
    user.refresh_from_db()
    assert user.first_name == "Alicia"
    assert user.last_name == "Jones"


def test_post_invalid_renders_form_partial_with_errors(client_logged_in, user):
    too_long = "x" * 200  # Django User.first_name max_length = 150
    resp = client_logged_in.post(
        reverse("settings:form", kwargs={"form_name": "user_name"}),
        data={"first_name": too_long, "last_name": "Smith"},
        HTTP_HX_REQUEST="true",
    )
    assert resp.status_code == 200
    body = resp.content.decode()
    # partial only — no full page
    assert "<html" not in body
    # the single form section is rendered
    assert 'id="cj-settings-form-user_name"' in body
    # no success trigger on error
    assert "HX-Trigger" not in resp or "settings:changed" not in resp.get(
        "HX-Trigger", ""
    )
    # DB unchanged
    user.refresh_from_db()
    assert user.first_name == "Alice"


def test_unknown_form_404(client_logged_in):
    resp = client_logged_in.post(
        reverse("settings:form", kwargs={"form_name": "nope"}),
        data={},
        HTTP_HX_REQUEST="true",
    )
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Permission gating
# ---------------------------------------------------------------------------


def test_permission_gated_section_hidden_from_unprivileged(
    client_logged_in, permission_gated_section
):
    resp = client_logged_in.get(
        reverse("settings:index") + "?section=profile",
        HTTP_HX_REQUEST="true",
        HTTP_HX_TARGET="cj-settings-pane",
    )
    assert resp.status_code == 200
    assert "Secret" not in resp.content.decode()


def test_permission_gated_section_visible_to_privileged(
    client_logged_in, permission_gated_section, user
):
    from django.contrib.auth.models import Permission

    user.user_permissions.add(Permission.objects.get(codename="view_user"))
    # The gated section should now show up in the rail. We still render via
    # the HTMX partial route to keep the test self-contained (no base.html).
    resp = client_logged_in.get(
        reverse("settings:index") + "?section=secret",
        HTTP_HX_REQUEST="true",
        HTTP_HX_TARGET="cj-settings-pane",
    )
    assert resp.status_code == 200
    assert "Secret" in resp.content.decode()
