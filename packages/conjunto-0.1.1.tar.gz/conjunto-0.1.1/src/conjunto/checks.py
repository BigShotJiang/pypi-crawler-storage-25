from django.core.checks import Error, Warning, register
from django.urls import reverse, NoReverseMatch
from django.conf import settings


@register()
def check_django_tomselect(app_configs, **kwargs):
    errors = []
    if "django_tomselect" not in settings.INSTALLED_APPS:
        errors.append(
            Warning(
                "'django_tomselect' is not in INSTALLED_APPS.",
                hint=(
                    "Make sure 'django_tomselect' is installed and in INSTALLED_APPS so that "
                    "its static files and templates are discoverable. "
                    "This is required for AutocompleteField and AutocompleteMultipleField."
                ),
                id="conjunto.W001",
            )
        )
    return errors


@register()
def check_settings(app_configs, **kwargs):
    errors = []
    if not hasattr(settings, "PROJECT_TITLE"):
        errors.append(
            Error(
                "The setting 'PROJECT_TITLE' is not defined.",
                hint="Add a human readable 'PROJECT_TITLE' to your settings.",
                id="conjunto.E001",
            )
        )
    if not hasattr(settings, "PROJECT_NAME"):
        errors.append(
            Error(
                "The setting 'PROJECT_NAME' is not defined.",
                hint="Add a machine readable 'PROJECT_NAME' to your settings.",
                id="conjunto.E002",
            )
        )
    return errors


@register()
def check_auth_urls(app_configs, **kwargs):
    errors = []
    for url_name in ["login", "logout"]:
        try:
            reverse(url_name)
        except NoReverseMatch:
            errors.append(
                Error(
                    f"The named URL '{url_name}' is not defined in our project.",
                    hint=f"Add a '{url_name}' URL to your URLconf.",
                    id=f"conjunto.E00{3 if url_name == 'login' else 4}",
                )
            )

    return errors
