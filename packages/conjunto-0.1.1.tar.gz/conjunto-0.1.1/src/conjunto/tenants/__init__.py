default_app_config = "conjunto.tenants.apps.TenantsConfig"
