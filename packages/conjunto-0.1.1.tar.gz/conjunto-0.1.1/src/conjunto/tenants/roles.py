"""Tenant role schema collection, merging and inheritance resolution.

A *role* is a named bundle of permissions that gets materialized as a
``tenant:<slug>:<role>`` ``auth.Group`` for every tenant. Roles are
declared via an ``AppConfig.tenant_role_permissions`` dict — any number
of apps may contribute to the same role.

Schema shape declared on each AppConfig:

.. code-block:: python

    class MyAppConfig(AppConfig):
        tenant_role_permissions = {
            "viewer": {
                "permissions": {"cms.StaticPage": ["view"]},
            },
            "editor": {
                "extends": "viewer",
                "permissions": {"cms.StaticPage": ["add", "change"]},
            },
            "admin": {
                "extends": "editor",
                "permissions": {"cms.StaticPage": ["delete"]},
            },
        }

Merge rules across apps:

- ``permissions`` are unioned per role / per model.
- ``extends`` must be consistent: if two apps both declare
  ``extends`` for the same role they must agree, otherwise
  :class:`RoleSchemaError` is raised.
- The resolved inheritance DAG must be acyclic.
- ``extends`` may reference a role declared in a different app
  (e.g. one declared by conjunto itself).
"""

from __future__ import annotations

from collections import defaultdict
from typing import Iterable

from django.apps import apps as django_apps


class RoleSchemaError(Exception):
    """Raised when tenant role declarations across apps are inconsistent."""


# Shape after merging across apps but before inheritance flattening.
# role_name -> {
#     "extends": str | None,
#     "permissions": {model_ref: set(perm_verbs)},
# }
RawRoleSchema = dict[str, dict]

# Shape after inheritance flattening — same as raw minus "extends".
FlatRoleSchema = dict[str, dict[str | type, list[str]]]


def collect_raw_schema(app_configs: Iterable | None = None) -> RawRoleSchema:
    """Walk AppConfigs, merge every ``tenant_role_permissions`` declaration.

    Returns the raw (unflattened) schema. Raises :class:`RoleSchemaError`
    on ``extends`` conflicts.
    """
    if app_configs is None:
        app_configs = django_apps.get_app_configs()

    merged: RawRoleSchema = {}

    for app in app_configs:
        schema = getattr(app, "tenant_role_permissions", None)
        if not schema:
            continue

        for role_name, role_def in schema.items():
            if not isinstance(role_def, dict):
                raise RoleSchemaError(
                    f"{app.label}.tenant_role_permissions[{role_name!r}] must "
                    f"be a dict with 'permissions' and optional 'extends'."
                )

            slot = merged.setdefault(
                role_name,
                {"extends": None, "permissions": defaultdict(set)},
            )

            # Inheritance: both None or identical, else conflict.
            new_extends = role_def.get("extends")
            if new_extends is not None:
                if slot["extends"] is None:
                    slot["extends"] = new_extends
                elif slot["extends"] != new_extends:
                    raise RoleSchemaError(
                        f"Role '{role_name}' has conflicting 'extends' "
                        f"declarations: {slot['extends']!r} vs "
                        f"{new_extends!r} (in {app.label})."
                    )

            # Permissions: union per model.
            for model_ref, verbs in role_def.get("permissions", {}).items():
                slot["permissions"][model_ref].update(verbs)

    return merged


def flatten_inheritance(raw: RawRoleSchema) -> FlatRoleSchema:
    """Resolve ``extends`` chains; returns a flat role → permissions map.

    Detects cycles and unknown parents. The returned mapping has the
    shape expected by :func:`conjunto.tools.create_group_permissions`
    for each individual role.
    """
    resolved: FlatRoleSchema = {}
    resolving: set[str] = set()

    def resolve(role_name: str) -> dict[str | type, list[str]]:
        if role_name in resolved:
            return resolved[role_name]
        if role_name in resolving:
            raise RoleSchemaError(
                f"Cyclic tenant role inheritance detected involving " f"'{role_name}'."
            )
        if role_name not in raw:
            raise RoleSchemaError(
                f"Role '{role_name}' is referenced as a parent but is not "
                f"declared anywhere."
            )

        resolving.add(role_name)

        merged_perms: dict[str | type, set[str]] = defaultdict(set)

        parent_name = raw[role_name]["extends"]
        if parent_name is not None:
            for model_ref, verbs in resolve(parent_name).items():
                merged_perms[model_ref].update(verbs)

        for model_ref, verbs in raw[role_name]["permissions"].items():
            merged_perms[model_ref].update(verbs)

        resolving.discard(role_name)

        # Convert sets to sorted lists so the output is deterministic.
        flat = {ref: sorted(verbs) for ref, verbs in merged_perms.items()}
        resolved[role_name] = flat
        return flat

    for name in list(raw):
        resolve(name)

    return resolved


def get_flat_schema(app_configs: Iterable | None = None) -> FlatRoleSchema:
    """Convenience: collect + flatten in one call."""
    return flatten_inheritance(collect_raw_schema(app_configs))


# ---------------------------------------------------------------------------
# Seeding / querying TenantRole records
# ---------------------------------------------------------------------------


def seed_system_roles(tenant) -> None:
    """Ensure a :class:`~conjunto.tenants.models.TenantRole` row exists for
    every role declared in the current ``tenant_role_permissions`` schema.

    - New roles are created with ``is_system=True``.
    - Existing system roles whose name no longer appears in the schema
      are demoted to ``is_system=False`` (they become custom roles the
      admin may keep or delete).
    - Already-existing rows are left unchanged apart from the
      ``is_system`` flag.

    Called from :meth:`AbstractTenant.save` (after ``materialize_roles``)
    and from the ``update_permissions`` management command.
    """
    from conjunto.tenants.models import TenantRole

    schema = get_flat_schema()
    declared_names = set(schema.keys())

    for role_name in declared_names:
        TenantRole.objects.update_or_create(
            tenant=tenant,
            name=role_name,
            defaults={
                "is_system": True,
                "label": role_name.replace("_", " ").title(),
            },
        )

    # Demote system roles that are no longer in the schema.
    TenantRole.objects.filter(
        tenant=tenant,
        is_system=True,
    ).exclude(name__in=declared_names).update(is_system=False)


def available_roles_for_tenant(tenant):
    """Return all :class:`TenantRole` instances for *tenant*, ordered by name.

    This includes both system roles (seeded from ``tenant_role_permissions``)
    and custom roles created by the tenant admin.
    """
    from conjunto.tenants.models import TenantRole

    return TenantRole.objects.filter(tenant=tenant).order_by("name")
