"""Tenant-scoping managers for :class:`TenantModelMixin`.

Every queryset obtained from a tenant-scoped model's ``objects`` manager
is implicitly filtered to the tenant currently bound on the
:mod:`conjunto.tenants.context` ContextVar. Accessing ``objects`` with
no tenant bound raises :class:`TenantScopeMissing` — the contract is
deliberately loud so that Celery tasks, management commands and shell
sessions don't silently return empty querysets.

Escape hatches:

- Every tenant-scoped model also exposes an unscoped ``all_objects``
  manager (a plain :class:`~django.db.models.Manager`) for code that
  legitimately needs to cross tenants (backups, migrations, admin
  superuser views, global reports).
- Django's own internals (FK validation, cascade deletes, admin
  autocomplete, ``get_profile``-style reverse access) use
  ``_base_manager``, which is wired to ``all_objects`` via
  ``Meta.base_manager_name`` so those code paths are never tenant-
  filtered.
- :func:`conjunto.tenants.context.override_tenant` binds a tenant for
  the duration of a ``with`` block — the idiomatic way to run
  tenant-scoped code out of the HTTP request cycle.
"""

from django.db import models
from django.db.models import Q

from .context import get_current_tenant


class TenantScopeMissing(RuntimeError):
    """Raised when a tenant-scoped manager is used without a bound tenant."""


def _require_tenant(model):
    tenant = get_current_tenant()
    if tenant is None:
        raise TenantScopeMissing(
            f"{model.__name__} was accessed without a bound tenant. "
            f"Wrap the call in `conjunto.tenants.context.override_tenant(...)` "
            f"or use `{model.__name__}.all_objects` for an unscoped queryset."
        )
    return tenant


class TenantQuerySet(models.QuerySet):
    """QuerySet that injects the bound tenant on ``create``/``bulk_create``."""

    def create(self, **kwargs):
        if "tenant" not in kwargs and "tenant_id" not in kwargs:
            kwargs["tenant"] = _require_tenant(self.model)
        return super().create(**kwargs)

    def bulk_create(self, objs, *args, **kwargs):
        objs = list(objs)
        tenant = None
        for obj in objs:
            if getattr(obj, "tenant_id", None) is None:
                if tenant is None:
                    tenant = _require_tenant(self.model)
                obj.tenant = tenant
        return super().bulk_create(objs, *args, **kwargs)


class TenantManager(models.Manager.from_queryset(TenantQuerySet)):
    """Manager that auto-filters every queryset by the bound tenant.

    Raises :class:`TenantScopeMissing` when accessed with no tenant
    bound. Use the sibling ``all_objects`` manager (or
    :func:`~conjunto.tenants.context.override_tenant`) to opt out.
    """

    def get_queryset(self):
        tenant = _require_tenant(self.model)
        return super().get_queryset().filter(tenant=tenant)


class OptionalTenantQuerySet(models.QuerySet):
    """QuerySet for models where ``tenant`` is nullable.

    ``create``/``bulk_create`` do **not** auto-inject the current tenant —
    passing no tenant is a legitimate way to create a global row that
    is visible to every tenant.
    """


class OptionalTenantManager(
    models.Manager.from_queryset(OptionalTenantQuerySet)
):
    """Like :class:`TenantManager`, but also surfaces global
    (``tenant IS NULL``) rows to every tenant.

    Unlike :class:`TenantManager`, accessing this manager with **no**
    tenant bound is *not* an error — it degrades gracefully to
    "global rows only" (``tenant IS NULL``). That matches the
    semantics of the ``Optional`` variant: the model is allowed to
    exist without a tenant at all, so a tenant-less caller is a
    legitimate state rather than a scoping bug.
    """

    def get_queryset(self):
        qs = super().get_queryset()
        tenant = get_current_tenant()
        if tenant is None:
            return qs.filter(tenant__isnull=True)
        return qs.filter(Q(tenant=tenant) | Q(tenant__isnull=True))
