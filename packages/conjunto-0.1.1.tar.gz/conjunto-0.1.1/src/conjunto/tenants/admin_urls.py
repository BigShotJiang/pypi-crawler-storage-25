"""URL patterns for tenant-scoped permission administration.

Consumers include these patterns in their admin URL tree, e.g.:

.. code-block:: python

    from conjunto.tenants.admin_urls import urlpatterns as tenant_admin_urls

    adm_urlpatterns += [
        path("tenant/", include((tenant_admin_urls, "tenant_admin"))),
    ]

All views require an authenticated user with a tenant bound on the
request (via :class:`conjunto.middleware.ConjuntoMiddleware`). Consumers
should additionally gate access using their own admin-permission mixin
(e.g. ``TenantAdminRequiredMixin``) by subclassing the views.
"""

from django.urls import path

from conjunto.tenants.views.memberships import ManageUserRolesView, UserRoleListView
from conjunto.tenants.views.roles import (
    TenantRoleCreateView,
    TenantRoleDeleteView,
    TenantRoleListView,
    TenantRoleUpdateView,
)
from conjunto.tenants.views.users import (
    TenantUserCreateView,
    TenantUserListView,
    TenantUserRemoveView,
    TenantUserUpdateView,
)

app_name = "tenant_admin"

urlpatterns = [
    # Roles
    path("roles/", TenantRoleListView.as_view(), name="role-list"),
    path("roles/add/", TenantRoleCreateView.as_view(), name="role-add"),
    path("roles/<int:pk>/edit/", TenantRoleUpdateView.as_view(), name="role-edit"),
    path(
        "roles/<int:pk>/delete/",
        TenantRoleDeleteView.as_view(),
        name="role-delete",
    ),
    # Users
    path("users/", TenantUserListView.as_view(), name="user-list"),
    path("users/add/", TenantUserCreateView.as_view(), name="user-add"),
    path("users/<int:pk>/edit/", TenantUserUpdateView.as_view(), name="user-edit"),
    path(
        "users/<int:pk>/remove/",
        TenantUserRemoveView.as_view(),
        name="user-remove",
    ),
    # User-role assignment
    path("user-roles/", UserRoleListView.as_view(), name="user-role-list"),
    path(
        "user-roles/<int:pk>/manage/",
        ManageUserRolesView.as_view(),
        name="user-role-manage",
    ),
]
