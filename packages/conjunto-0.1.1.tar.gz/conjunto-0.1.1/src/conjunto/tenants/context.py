"""Current-tenant context variable.

The tenant-aware authentication backend and any code path that needs to
know "which tenant is this operation happening in" reads the tenant from
a :class:`contextvars.ContextVar`. In the HTTP request/response cycle
:class:`conjunto.middleware.ConjuntoMiddleware` populates it from
``request.tenant``. For out-of-request work (Celery tasks, management
commands, shell sessions) use :func:`override_tenant` as a context
manager or call :func:`set_current_tenant` directly.

``ContextVar`` — not ``threading.local`` — is used deliberately so that
async code and task runners that reuse threads get the correct
isolation semantics.
"""

from contextlib import contextmanager
from contextvars import ContextVar
from typing import Optional

_current_tenant: ContextVar[Optional[object]] = ContextVar(
    "conjunto_current_tenant", default=None
)


def get_current_tenant():
    """Return the current tenant, or ``None`` if no tenant is bound."""
    return _current_tenant.get()


def set_current_tenant(tenant):
    """Bind ``tenant`` as the current tenant. Returns a reset token."""
    return _current_tenant.set(tenant)


def reset_current_tenant(token) -> None:
    """Undo a previous :func:`set_current_tenant` using its reset token."""
    _current_tenant.reset(token)


@contextmanager
def override_tenant(tenant):
    """Bind ``tenant`` for the duration of a ``with`` block.

    Example:
        >>> with override_tenant(acme):
        ...     user.has_perm("cms.change_staticpage")
    """
    token = _current_tenant.set(tenant)
    try:
        yield tenant
    finally:
        _current_tenant.reset(token)
