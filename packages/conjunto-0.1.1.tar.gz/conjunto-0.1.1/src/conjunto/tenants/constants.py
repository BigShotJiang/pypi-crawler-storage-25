"""Tenant constants with zero runtime dependencies.

This module is deliberately stdlib-only so it can be imported safely
from any stage of Django app loading — both from
:mod:`conjunto.tenants.models` (which gets pulled in early by
consumer code importing :class:`AbstractTenant`) and from
:mod:`conjunto.tenants.backends` (which pulls in ``django.contrib.auth``).
Keeping the shared constant here breaks an import cycle that would
otherwise appear under early-import orderings.
"""

#: Prefix every materialized tenant-role group name starts with.
#:
#: A group named ``tenant:acme:editor`` represents the ``editor`` role
#: for the tenant with slug ``acme``.
TENANT_GROUP_PREFIX = "tenant:"
