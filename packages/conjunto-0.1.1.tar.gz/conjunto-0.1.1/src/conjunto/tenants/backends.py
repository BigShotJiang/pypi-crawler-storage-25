"""Tenant-aware authentication backend.

:class:`TenantAwareModelBackend` is a drop-in replacement for Django's
:class:`~django.contrib.auth.backends.ModelBackend`. It changes one
thing: permissions contributed by tenant-prefixed groups
(``tenant:<slug>:<role>``) are only counted when ``<slug>`` matches the
currently active tenant, read from
:mod:`conjunto.tenants.context`.

Groups whose name does **not** start with ``tenant:`` behave like
regular global groups — they always contribute. Use those for roles
that must span all tenants (vendor support, system-wide admins, …).

Wire it up in your Django settings:

.. code-block:: python

    AUTHENTICATION_BACKENDS = [
        "conjunto.tenants.backends.TenantAwareModelBackend",
    ]

Out-of-request code (Celery, shell) must bind the tenant explicitly via
:func:`conjunto.tenants.context.override_tenant` — otherwise only
non-tenant groups contribute.
"""

from __future__ import annotations

from django.contrib.auth.backends import ModelBackend
from django.contrib.auth.models import Permission

from .constants import TENANT_GROUP_PREFIX
from .context import get_current_tenant


def _tenant_slug_from_group_name(name: str) -> str | None:
    """Return the tenant slug embedded in ``tenant:<slug>:<role>`` or ``None``."""
    if not name.startswith(TENANT_GROUP_PREFIX):
        return None
    parts = name.split(":", 2)
    if len(parts) != 3:
        return None
    return parts[1]


class TenantAwareModelBackend(ModelBackend):
    """ModelBackend variant that filters tenant-prefixed groups by context."""

    def get_group_permissions(self, user_obj, obj=None):
        if not user_obj.is_active or user_obj.is_anonymous or obj is not None:
            return set()

        tenant = get_current_tenant()
        current_slug = getattr(tenant, "slug", None) if tenant is not None else None

        # Cache keyed by tenant slug on the user object so repeated
        # has_perm() calls within a single request don't re-query.
        cache = user_obj.__dict__.setdefault("_cj_tenant_perm_cache", {})
        if current_slug in cache:
            return cache[current_slug]

        groups = user_obj.groups.all().values_list("pk", "name")
        eligible_group_ids: list[int] = []
        for group_pk, group_name in groups:
            group_slug = _tenant_slug_from_group_name(group_name)
            if group_slug is None:
                eligible_group_ids.append(group_pk)
            elif group_slug == current_slug:
                eligible_group_ids.append(group_pk)

        perms = (
            Permission.objects.filter(group__pk__in=eligible_group_ids)
            .values_list("content_type__app_label", "codename")
            .order_by()
        )
        result = {f"{app_label}.{codename}" for app_label, codename in perms}
        cache[current_slug] = result
        return result

    def get_all_permissions(self, user_obj, obj=None):
        if not user_obj.is_active or user_obj.is_anonymous or obj is not None:
            return set()

        # Reuse ModelBackend's user-permissions cache behavior but swap
        # in our tenant-aware group permissions.
        if not hasattr(user_obj, "_cj_tenant_all_perm_cache"):
            user_obj._cj_tenant_all_perm_cache = {}
        tenant = get_current_tenant()
        current_slug = getattr(tenant, "slug", None) if tenant is not None else None
        cache = user_obj._cj_tenant_all_perm_cache
        if current_slug not in cache:
            cache[current_slug] = {
                *self.get_user_permissions(user_obj),
                *self.get_group_permissions(user_obj),
            }
        return cache[current_slug]

    def has_perm(self, user_obj, perm, obj=None):
        if not user_obj.is_active:
            return False
        return perm in self.get_all_permissions(user_obj, obj)
