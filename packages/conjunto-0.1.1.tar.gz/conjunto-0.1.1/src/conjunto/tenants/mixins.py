"""View mixins for tenant-aware request handling."""

from django.contrib import messages
from django.shortcuts import redirect
from django.utils.translation import gettext_lazy as _


class TenantRequiredMixin:
    """Redirect to ``/`` if no tenant is bound on the request.

    Tenant-scoped views should inherit from this mixin. If
    ``request.tenant`` is ``None``, the user is redirected to the root
    URL with a message prompting them to pick a tenant via the statusbar
    dropdown.
    """

    #: Where to redirect when no tenant is bound.
    tenant_missing_redirect_url = "/"

    def dispatch(self, request, *args, **kwargs):
        if getattr(request, "tenant", None) is None:
            messages.info(request, _("Please select a tenant to continue."))
            return redirect(self.tenant_missing_redirect_url)
        return super().dispatch(request, *args, **kwargs)
