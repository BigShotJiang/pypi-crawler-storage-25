"""Helpers for the swappable Tenant model.

Consumers and framework code should always resolve the active Tenant
model through :func:`get_tenant_model` instead of hard-importing
``conjunto.tenants.models.Tenant`` — same pattern as Django's
``django.contrib.auth.get_user_model``.
"""

from django.apps import apps
from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

DEFAULT_TENANT_MODEL = "conjunto_tenants.Tenant"

_ALLOWED_CACHE_ATTR = "_cj_allowed_tenants"


def get_allowed_tenants(request):
    """Return the queryset of tenants ``request.user`` is allowed to pick.

    Superusers see every active tenant; everyone else is filtered to
    the tenants they hold a
    :class:`~conjunto.tenants.models.TenantMembership` on. The result is
    cached on ``request`` so repeat calls from the template layer (e.g.
    the statusbar tenant badge) don't re-hit the database.

    Returns an empty queryset for anonymous users.
    """
    cached = getattr(request, _ALLOWED_CACHE_ATTR, None)
    if cached is not None:
        return cached

    Tenant = get_tenant_model()
    user = getattr(request, "user", None)
    if user is None or not user.is_authenticated:
        qs = Tenant.objects.none()
    else:
        qs = Tenant.objects.filter(is_active=True).order_by("name")
        if not user.is_superuser:
            qs = qs.filter(memberships__user=user).distinct()

    setattr(request, _ALLOWED_CACHE_ATTR, qs)
    return qs


def get_tenant_model():
    """Return the active Tenant model.

    Reads ``settings.CONJUNTO_TENANT_MODEL`` and falls back to the
    default ``conjunto_tenants.Tenant`` if unset. Raises
    :class:`ImproperlyConfigured` if the configured label is malformed.
    """
    model_label = getattr(settings, "CONJUNTO_TENANT_MODEL", DEFAULT_TENANT_MODEL)
    try:
        return apps.get_model(model_label, require_ready=False)
    except ValueError as exc:
        raise ImproperlyConfigured(
            f"CONJUNTO_TENANT_MODEL must be of the form 'app_label.ModelName' "
            f"(got {model_label!r})."
        ) from exc
    except LookupError as exc:
        raise ImproperlyConfigured(
            f"CONJUNTO_TENANT_MODEL refers to model {model_label!r} "
            f"that has not been installed."
        ) from exc
