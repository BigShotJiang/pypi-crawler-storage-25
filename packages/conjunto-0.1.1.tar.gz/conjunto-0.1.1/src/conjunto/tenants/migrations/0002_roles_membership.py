from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ("conjunto_tenants", "0001_initial"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        migrations.swappable_dependency(
            getattr(settings, "CONJUNTO_TENANT_MODEL", "conjunto_tenants.Tenant")
        ),
    ]

    operations = [
        migrations.RemoveField(
            model_name="tenant",
            name="admin_group",
        ),
        migrations.CreateModel(
            name="TenantMembership",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                ("role", models.CharField(max_length=64, verbose_name="Role")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                (
                    "tenant",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="memberships",
                        to=(
                            settings.CONJUNTO_TENANT_MODEL
                            if hasattr(settings, "CONJUNTO_TENANT_MODEL")
                            else "conjunto_tenants.Tenant"
                        ),
                        verbose_name="Tenant",
                    ),
                ),
                (
                    "user",
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name="tenant_memberships",
                        to=settings.AUTH_USER_MODEL,
                        verbose_name="User",
                    ),
                ),
            ],
            options={
                "verbose_name": "Tenant membership",
                "verbose_name_plural": "Tenant memberships",
            },
        ),
        migrations.AddConstraint(
            model_name="tenantmembership",
            constraint=models.UniqueConstraint(
                fields=("user", "tenant", "role"),
                name="conjunto_tenant_membership_unique",
            ),
        ),
    ]
