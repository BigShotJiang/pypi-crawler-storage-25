import uuid
from collections import defaultdict

from django.conf import settings
from django.db import models
from django.utils.translation import gettext_lazy as _

from .constants import TENANT_GROUP_PREFIX
from .managers import OptionalTenantManager, TenantManager


def _role_group_name(slug: str, role: str) -> str:
    """Return the canonical ``tenant:<slug>:<role>`` group name."""
    return f"{TENANT_GROUP_PREFIX}{slug}:{role}"


class AbstractTenant(models.Model):
    """Abstract base class for a multi-tenancy tenant.

    A tenant is an abstract business entity — a workspace, a clinic, a
    practice, a customer organization — **not** a person. Domain-specific
    attributes (e.g. a practice owner's name, sex, address, phone, email)
    belong in a consumer-level subclass that also sets
    ``CONJUNTO_TENANT_MODEL`` in Django settings.

    Carries only framework-level concepts:

    - ``uuid``: stable external identifier.
    - ``name``: human-readable display name.
    - ``slug``: URL-safe identifier. **Immutable after first save**.
      The slug is baked into every materialized ``tenant:<slug>:<role>``
      group name, and renaming it would orphan every user's role
      memberships. The field stays ``editable=True`` so create-forms
      can still include it; immutability is enforced in :meth:`save`,
      which raises ``ValueError`` if the slug of an existing row
      changes.
    - ``is_active``: soft deactivation flag.
    - audit timestamps.

    Every declared tenant role (see ``AppConfig.tenant_role_permissions``)
    is materialized on :meth:`save` as a ``tenant:<slug>:<role>``
    ``auth.Group``, fully populated with the role's aggregated
    permissions. Re-saving re-applies the current schema authoritatively.
    """

    uuid = models.UUIDField(
        _("UUID"),
        default=uuid.uuid4,
        unique=True,
        editable=False,
    )
    name = models.CharField(
        _("Name"),
        max_length=200,
    )
    slug = models.SlugField(
        _("Slug"),
        unique=True,
        max_length=100,
    )
    is_active = models.BooleanField(
        _("Active"),
        default=True,
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True
        ordering = ["name"]

    def __str__(self):
        return self.name

    def natural_key(self):
        return (self.slug,)

    def save(self, *args, **kwargs):
        if self.pk is not None:
            previous_slug = (
                type(self)
                ._base_manager.filter(pk=self.pk)
                .values_list("slug", flat=True)
                .first()
            )
            if previous_slug is not None and previous_slug != self.slug:
                raise ValueError(
                    f"Tenant.slug is immutable after first save "
                    f"(attempted to change {previous_slug!r} → {self.slug!r})."
                )
        super().save(*args, **kwargs)
        if self.slug:
            self.materialize_roles()

    # ------------------------------------------------------------------
    # Role helpers
    # ------------------------------------------------------------------

    def get_role_group_name(self, role: str) -> str:
        """Return the ``tenant:<slug>:<role>`` group name for this tenant."""
        return _role_group_name(self.slug, role)

    def get_role_group(self, role: str):
        """Return the materialized ``auth.Group`` for ``role``.

        Raises ``Group.DoesNotExist`` if the role has not been
        materialized yet (e.g. it was declared after the last
        ``update_permissions`` run).
        """
        from django.contrib.auth.models import Group

        return Group.objects.get(name=self.get_role_group_name(role))

    @property
    def admin_group(self):
        """Shortcut for the materialized ``tenant_admin`` role group."""
        return self.get_role_group("tenant_admin")

    def materialize_roles(self) -> None:
        """Create/update this tenant's ``tenant:<slug>:<role>`` groups.

        Walks the aggregated :mod:`conjunto.tenants.roles` schema across
        every installed app and assigns the resolved permission set to
        each role's group **authoritatively** (permissions not in the
        current schema are revoked).

        Also seeds :class:`TenantRole` rows for every schema-declared
        role and materializes any custom (DB-only) roles that are not
        part of the AppConfig schema.
        """
        from conjunto.tenants.roles import get_flat_schema, seed_system_roles
        from conjunto.tools import create_group_permissions

        schema = get_flat_schema()

        # 1. Materialize AppConfig-declared roles.
        if schema:
            group_permissions = {
                self.get_role_group_name(role): perms
                for role, perms in schema.items()
            }
            create_group_permissions(group_permissions)

        # 2. Seed TenantRole rows for schema-declared roles.
        seed_system_roles(self)

        # 3. Materialize custom (DB-only) roles.
        for role in TenantRole.objects.filter(
            tenant=self, is_system=False
        ):
            role.materialize()


class Tenant(AbstractTenant):
    """Default concrete Tenant.

    Swap via ``CONJUNTO_TENANT_MODEL = "myapp.Tenant"`` in Django
    settings. Must be set **before** the first migration — swapping
    after initial migration is treated as destructive by Django.
    """

    class Meta(AbstractTenant.Meta):
        swappable = "CONJUNTO_TENANT_MODEL"
        verbose_name = _("Tenant")
        verbose_name_plural = _("Tenants")


class TenantMembership(models.Model):
    """Binds a user to a role within a tenant.

    Creating (or saving) a membership ensures that the
    ``tenant:<slug>:<role>`` group exists and that the user is a
    member of it. Deleting a membership removes the user from that
    group. All permission checks then flow through the normal
    ``user.groups`` → ``Permission`` chain, filtered to the current
    tenant by :class:`~conjunto.tenants.backends.TenantAwareModelBackend`.

    Uniqueness is enforced on ``(user, tenant, role)``: the same user
    can hold different roles in the same tenant, or the same role in
    different tenants, but each combination exists at most once.
    """

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="tenant_memberships",
        verbose_name=_("User"),
    )
    tenant = models.ForeignKey(
        (
            settings.CONJUNTO_TENANT_MODEL
            if hasattr(settings, "CONJUNTO_TENANT_MODEL")
            else "conjunto_tenants.Tenant"
        ),
        on_delete=models.CASCADE,
        related_name="memberships",
        verbose_name=_("Tenant"),
    )
    role = models.CharField(
        _("Role"),
        max_length=64,
        help_text=_(
            "Name of a role declared in an app's " "`tenant_role_permissions`."
        ),
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = _("Tenant membership")
        verbose_name_plural = _("Tenant memberships")
        constraints = [
            models.UniqueConstraint(
                fields=("user", "tenant", "role"),
                name="conjunto_tenant_membership_unique",
            ),
        ]

    def __str__(self):
        return f"{self.user} @ {self.tenant} ({self.role})"

    #: The default administration role that is automatically granted to
    #: the first user assigned to a tenant.
    TENANT_ADMIN_ROLE = "tenant_admin"

    def save(self, *args, **kwargs):
        is_new = self._state.adding
        super().save(*args, **kwargs)
        self._sync_user_group(add=True)
        if is_new:
            self._auto_assign_tenant_admin()

    def delete(self, *args, **kwargs):
        self._sync_user_group(add=False)
        return super().delete(*args, **kwargs)

    # ------------------------------------------------------------------

    def _auto_assign_tenant_admin(self) -> None:
        """Grant the ``tenant_admin`` role to the first user of a tenant.

        When the very first membership for a tenant is created and its
        role is *not* already ``tenant_admin``, an additional
        ``tenant_admin`` membership is created automatically. This
        ensures every tenant always has at least one admin.
        """
        if self.role == self.TENANT_ADMIN_ROLE:
            return
        # Check if this user is the only member of the tenant.
        other_memberships = (
            TenantMembership.objects.filter(tenant=self.tenant)
            .exclude(user=self.user)
            .exists()
        )
        if not other_memberships:
            TenantMembership.objects.get_or_create(
                user=self.user,
                tenant=self.tenant,
                role=self.TENANT_ADMIN_ROLE,
            )

    def _sync_user_group(self, *, add: bool) -> None:
        """Add or remove the user from the ``tenant:<slug>:<role>`` group."""
        from django.contrib.auth.models import Group

        group_name = _role_group_name(self.tenant.slug, self.role)
        if add:
            group, _created = Group.objects.get_or_create(name=group_name)
            self.user.groups.add(group)
        else:
            try:
                group = Group.objects.get(name=group_name)
            except Group.DoesNotExist:
                return
            self.user.groups.remove(group)


class TenantRole(models.Model):
    """A role definition for a tenant.

    Roles come in two flavours:

    - **System roles** (``is_system=True``) are seeded from
      ``AppConfig.tenant_role_permissions`` declarations. Their base
      permissions are always derived from the schema; admins can add
      *extra* permissions on top via the :attr:`permissions` M2M.
      System roles cannot be deleted through the UI.

    - **Custom roles** (``is_system=False``) are created by tenant
      admins at runtime. Their entire permission set comes from the
      :attr:`permissions` M2M.

    Saving a ``TenantRole`` automatically materializes the corresponding
    ``tenant:<slug>:<name>`` ``auth.Group`` with the resolved permission
    set so that Django's standard ``user.has_perm()`` checks work.
    """

    tenant = models.ForeignKey(
        (
            settings.CONJUNTO_TENANT_MODEL
            if hasattr(settings, "CONJUNTO_TENANT_MODEL")
            else "conjunto_tenants.Tenant"
        ),
        on_delete=models.CASCADE,
        related_name="roles",
        verbose_name=_("Tenant"),
    )
    name = models.CharField(
        _("Name"),
        max_length=64,
        help_text=_("Machine-readable role identifier (e.g. 'admin', 'editor')."),
    )
    label = models.CharField(
        _("Label"),
        max_length=200,
        help_text=_("Human-readable display name."),
    )
    description = models.TextField(
        _("Description"),
        blank=True,
        default="",
    )
    is_system = models.BooleanField(
        _("System role"),
        default=False,
        help_text=_(
            "System roles are seeded from plugin declarations and "
            "cannot be deleted."
        ),
    )
    permissions = models.ManyToManyField(
        "auth.Permission",
        blank=True,
        verbose_name=_("Permissions"),
        help_text=_(
            "Extra permissions beyond those inherited from plugin "
            "declarations (system roles) or the full permission set "
            "(custom roles)."
        ),
    )

    class Meta:
        verbose_name = _("Tenant role")
        verbose_name_plural = _("Tenant roles")
        ordering = ["name"]
        constraints = [
            models.UniqueConstraint(
                fields=["tenant", "name"],
                name="cj_tenant_role_unique",
            ),
        ]

    def __str__(self):
        return f"{self.label} ({self.name})"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self.materialize()

    def delete(self, *args, **kwargs):
        """Remove the materialized group before deleting the role."""
        from django.contrib.auth.models import Group

        group_name = _role_group_name(self.tenant.slug, self.name)
        Group.objects.filter(name=group_name).delete()
        return super().delete(*args, **kwargs)

    def materialize(self) -> None:
        """Create/update the ``tenant:<slug>:<name>`` auth.Group.

        Resolves the full permission set by merging AppConfig-declared
        permissions (for system roles) with any DB-stored extras, then
        delegates to :func:`conjunto.tools.create_group_permissions`.
        """
        from conjunto.tools import create_group_permissions

        group_name = _role_group_name(self.tenant.slug, self.name)
        perms = self._resolved_permissions()
        create_group_permissions({group_name: perms})

    def _resolved_permissions(self) -> dict[str, list[str]]:
        """Return the merged permission map for this role.

        Returns:
            ``{model_ref: [verb, ...]}`` suitable for
            :func:`~conjunto.tools.create_group_permissions`.
        """
        merged: dict[str, set[str]] = defaultdict(set)

        # For system roles, start with the AppConfig-declared permissions.
        if self.is_system:
            from conjunto.tenants.roles import get_flat_schema

            schema = get_flat_schema()
            schema_perms = schema.get(self.name, {})
            for model_ref, verbs in schema_perms.items():
                merged[model_ref].update(verbs)

        # Add DB-stored permissions (extra for system roles, everything
        # for custom roles).
        if self.pk:
            for perm in self.permissions.select_related("content_type").all():
                ct = perm.content_type
                model_ref = f"{ct.app_label}.{ct.model_class().__name__}"
                # Extract the verb from the codename. Django codenames
                # follow ``<verb>_<model>``; strip the ``_<model>`` suffix.
                model_name = ct.model
                codename = perm.codename
                if codename.endswith(f"_{model_name}"):
                    verb = codename[: -(len(model_name) + 1)]
                else:
                    verb = codename
                merged[model_ref].add(verb)

        return {ref: sorted(verbs) for ref, verbs in merged.items()}

    @property
    def member_count(self) -> int:
        """Number of users holding this role in the tenant."""
        return TenantMembership.objects.filter(
            tenant=self.tenant, role=self.name
        ).count()


class TenantModelMixin(models.Model):
    """Mixin marking a model as belonging to exactly one tenant.

    Adds a mandatory ``tenant`` ForeignKey **and** wires up a
    tenant-scoping ``objects`` manager: every queryset is implicitly
    filtered to the tenant bound on the
    :mod:`conjunto.tenants.context` ContextVar, and ``objects.create``
    / ``objects.bulk_create`` auto-populate ``tenant`` from the same
    context.

    Accessing ``objects`` with no tenant bound raises
    :class:`~conjunto.tenants.managers.TenantScopeMissing` — the
    contract is deliberately loud so that Celery tasks, management
    commands and shell sessions never silently return empty querysets.

    Two escape hatches are available:

    - ``Model.all_objects`` — an unscoped plain
      :class:`~django.db.models.Manager`. Also used as Django's
      ``_base_manager`` (via ``Meta.base_manager_name``) so FK
      validation, cascade deletes and admin autocomplete are never
      tenant-filtered.
    - :func:`conjunto.tenants.context.override_tenant` — context
      manager that binds a tenant for out-of-request code paths.
    """

    class Meta:
        abstract = True
        base_manager_name = "all_objects"

    tenant = models.ForeignKey(
        settings.CONJUNTO_TENANT_MODEL,
        verbose_name=_("Tenant"),
        on_delete=models.CASCADE,
    )

    objects = TenantManager()
    all_objects = models.Manager()


class OptionalTenantModelMixin(models.Model):
    """Mixin marking a model as optionally belonging to a tenant.

    Adds a nullable ``tenant`` ForeignKey. The ``objects`` manager
    auto-filters querysets to the bound tenant **plus** global
    (``tenant IS NULL``) rows, so global entries are visible to every
    tenant. ``create``/``bulk_create`` do not auto-inject the tenant —
    omitting it is the idiomatic way to create a global row.

    Unlike :class:`TenantModelMixin`, accessing ``objects`` with **no**
    tenant bound is not an error — it degrades to "global rows only"
    (``tenant IS NULL``), matching the semantics of an optional tenant.
    ``all_objects`` remains available as an unscoped escape hatch.
    """

    class Meta:
        abstract = True
        base_manager_name = "all_objects"

    tenant = models.ForeignKey(
        settings.CONJUNTO_TENANT_MODEL,
        verbose_name=_("Tenant"),
        on_delete=models.CASCADE,
        blank=True,
        null=True,
    )

    objects = OptionalTenantManager()
    all_objects = models.Manager()
