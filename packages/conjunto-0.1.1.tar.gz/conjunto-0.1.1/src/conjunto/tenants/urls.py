from django.urls import path

from .views import TenantPickView

# Auto-mounted by GDAPS ``PluginManager.urlpatterns()`` at ``/tenants/``
# in the consuming project's root URL conf.
app_name = "tenants"

urlpatterns = [
    path("pick/", TenantPickView.as_view(), name="pick"),
]
