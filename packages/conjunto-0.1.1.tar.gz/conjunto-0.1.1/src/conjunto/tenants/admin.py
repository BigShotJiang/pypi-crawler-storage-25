from django.contrib import admin

from .utils import get_tenant_model


@admin.register(get_tenant_model())
class TenantAdmin(admin.ModelAdmin):
    list_display = ("name", "slug", "admin_group", "is_active", "updated_at")
    list_filter = ("is_active",)
    search_fields = ("name", "slug", "uuid")
    readonly_fields = ("uuid", "created_at", "updated_at")
    prepopulated_fields = {"slug": ("name",)}
