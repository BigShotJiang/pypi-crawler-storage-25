import logging
from collections import defaultdict

from django.apps import apps as django_apps
from django.contrib.auth import get_user_model
from django_extensions.management.commands.update_permissions import (
    Command as UpdatePermissionsCommand,
)

import conjunto.tools
from conjunto.tenants.roles import RoleSchemaError, get_flat_schema, seed_system_roles
from conjunto.tenants.utils import get_tenant_model

User = get_user_model()
logger = logging.getLogger(__name__)


class Command(UpdatePermissionsCommand):
    """Reload permissions of all (given) apps.

    After running django-extensions' ``update_permissions`` to ensure every
    model's permissions exist, this command walks all (given) apps for two
    attributes and applies them **authoritatively** — permissions not
    listed are removed from the group on the next run:

    - ``group_permissions`` — flat dict of ``{group_name: {model: [verbs]}}``
      for vendor-wide / tenant-agnostic groups. Multiple apps contributing
      to the same group have their permission lists unioned.

    - ``tenant_role_permissions`` — role template dict that is
      materialized as ``tenant:<slug>:<role>`` groups for every existing
      tenant. Supports inheritance via ``extends``; see
      :mod:`conjunto.tenants.roles`.

    Example:

    .. code-block:: python

        class MyAppConfig(AppConfig):
            name = "my_package"

            group_permissions = {
                "vendor:support": {"my_package.Ticket": ["view"]},
            }

            tenant_role_permissions = {
                "viewer": {
                    "permissions": {"my_package.Article": ["view"]},
                },
                "editor": {
                    "extends": "viewer",
                    "permissions": {
                        "my_package.Article": ["add", "change"],
                    },
                },
            }
    """

    help = (
        "Reloads permissions for specified apps (or all apps if no args are "
        "given), applies each app's `group_permissions` schema, and "
        "materializes `tenant_role_permissions` for every existing tenant."
    )

    def handle(self, *args, **options):
        super().handle(*args, **options)

        if options["apps"]:
            app_names = options["apps"].split(",")
            apps = [django_apps.get_app_config(x) for x in app_names]
        else:
            apps = list(django_apps.get_app_configs())

        verbosity = options["verbosity"]
        total_errors: list[str] = []

        # ---- Global groups (tenant-agnostic) ----
        merged_global = _merge_group_permissions(apps)
        if merged_global:
            total_errors.extend(conjunto.tools.create_group_permissions(merged_global))
            if verbosity >= 2:
                self.stdout.write(
                    self.style.SUCCESS(
                        f"Applied group_permissions for "
                        f"{len(merged_global)} global group(s)."
                    )
                )

        # ---- Tenant role groups ----
        try:
            flat_roles = get_flat_schema(apps)
        except RoleSchemaError as exc:
            self.stderr.write(self.style.ERROR(f"Role schema error: {exc}"))
            raise SystemExit(1)

        TenantModel = get_tenant_model()
        tenants = list(TenantModel.objects.all())

        if flat_roles:
            per_tenant_schema: dict[str, dict] = {}
            for tenant in tenants:
                for role, perms in flat_roles.items():
                    group_name = f"tenant:{tenant.slug}:{role}"
                    per_tenant_schema[group_name] = perms

            if per_tenant_schema:
                total_errors.extend(
                    conjunto.tools.create_group_permissions(per_tenant_schema)
                )
                if verbosity >= 2:
                    self.stdout.write(
                        self.style.SUCCESS(
                            f"Materialized {len(flat_roles)} role(s) "
                            f"across {len(tenants)} tenant(s)."
                        )
                    )

        # ---- Seed TenantRole rows & materialize custom roles ----
        for tenant in tenants:
            seed_system_roles(tenant)
            # Materialize custom (non-system) roles from the DB.
            from conjunto.tenants.models import TenantRole

            for role in TenantRole.objects.filter(
                tenant=tenant, is_system=False
            ):
                role.materialize()

        if verbosity >= 2 and tenants:
            self.stdout.write(
                self.style.SUCCESS(
                    f"Seeded TenantRole rows for {len(tenants)} tenant(s)."
                )
            )

        for message in total_errors:
            self.stderr.write(self.style.ERROR(message))
        if total_errors:
            raise SystemExit(1)


def _merge_group_permissions(app_configs) -> dict:
    """Merge ``group_permissions`` from every AppConfig.

    Permissions contributed by different apps to the same group/model
    are unioned, so two apps can both declare the ``"vendor:support"``
    group and each add their own model permissions to it.
    """
    merged: dict[str, dict[str, set[str]]] = defaultdict(lambda: defaultdict(set))
    for app in app_configs:
        schema = getattr(app, "group_permissions", None)
        if not schema:
            continue
        for group_name, models in schema.items():
            for model_ref, verbs in models.items():
                # create_group_permissions accepts both str and model class
                # keys, but keying by (hashable) model_ref here loses the
                # class form; collapse to str for cross-app dedup.
                if not isinstance(model_ref, str):
                    model_ref = f"{model_ref._meta.app_label}." f"{model_ref.__name__}"
                merged[group_name][model_ref].update(verbs)

    # Convert inner defaultdicts/sets to the shape create_group_permissions
    # expects (plain dict of list[str], with deterministic order).
    return {
        group: {model_ref: sorted(verbs) for model_ref, verbs in models.items()}
        for group, models in merged.items()
    }
