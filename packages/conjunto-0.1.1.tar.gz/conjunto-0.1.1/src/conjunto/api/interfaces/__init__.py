from django.utils.translation import gettext_lazy as _
from gdaps import hooks
from gdaps.api import Interface

from conjunto.audit_log.registry import LogActionRegistry

hooks.define("register_log_actions", (LogActionRegistry,))


class IElementGroup(Interface):
    """A group of pluggable elements.

    Implementations of this interface should provide a name, title, and weight
    of the group. You can use this group then in IElements to separate concerns.
    """

    name: str = ""
    title: str = ""
    weight: int = 0


class GeneralGroup(IElementGroup):
    """A default group for all elements without a specified group."""

    name = "general"
    title = _("General settings")


class IElement(Interface):
    """A metadata interface for pluggable, listable elements.

    IElement provides plugin discovery (via GDAPS ``enabled_plugins()``) and
    standardized metadata (``name``, ``title``, ``icon``, ``weight``, ``group``)
    plus the :meth:`enabled` hook for conditional activation.

    **Rendering is NOT the interface's responsibility.** A consuming view —
    see :class:`conjunto.settings.views.SettingsView` for the canonical
    example — iterates ``enabled_plugins()`` and assembles the UI, typically
    with Django 6's ``partials`` feature. This keeps plugin registration and
    presentation decoupled: one view can render many plugin instances as a
    list, grid, tab set, or anything else.

    **Optional HTMX lazy-load convention.** Subinterfaces or concrete plugins
    may declare an ``hx_url`` classmethod/property returning a URL. Consuming
    templates can then emit an ``hx-get`` stub
    (``<div hx-get="..." hx-trigger="load">``) to load the element lazily.
    This is a convention, not a contract — ``ISettingsSection`` /
    ``ISettingsForm`` do not use it because ``SettingsView`` renders
    them directly.

    Example:
        See ``conjunto/settings/interfaces.py`` for ``ISettingsSection``
        and ``ISettingsForm``, which are the idiomatic IElement subclasses:
        pure metadata, rendered by a dedicated view.
    """

    __abstract__ = True
    __instantiate_plugins__ = False

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # If this is a plugin (not the interface itself), require a name.
        if hasattr(self, "_interface") and not getattr(self, "name", None):
            raise AttributeError(
                f"{self.__class__.__name__} must have a 'name' attribute."
            )

    name: str
    """The unique identifier of the element. Used in URLs and HTML attributes."""

    title: str = ""
    """The human-readable title. How it is displayed is up to the consuming view."""

    icon: str = ""
    """Optional icon name, used when the element is listed with icons."""

    weight: int = 0
    """Sort weight — higher values sink the element further down the list."""

    group: type[IElementGroup] = GeneralGroup
    """The group this element belongs to. Can be used to render group headers."""

    @classmethod
    def enabled(cls) -> bool:
        """Hook for implementations to define if the element is enabled.

        Returns:
            True if the element is enabled (default), False if not.
        """
        return True
