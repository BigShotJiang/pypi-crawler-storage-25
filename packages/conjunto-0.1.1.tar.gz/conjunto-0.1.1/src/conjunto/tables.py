"""Reusable table machinery with consistent CRUD row actions.

This module provides three building blocks for tables that need
recognizable, system-wide row actions:

- `RowAction`: declarative description of a single row-level action
  (label, icon, URL, HTMX attributes, permission, visibility, confirm
  modal, weight). Everything a button needs, with no template fragments.
- `ActionsColumn`: a `django_tables2.Column` that renders a list of
  `RowAction`s into a Tabler `btn-list` via the
  `conjunto/tables/_row_actions.html` template.
- `CrudTableMixin`: a `tables.Table` mixin that wires up the "actions"
  column, assembles the standard edit/delete actions from a URL
  namespace, pulls in extra actions contributed by `IRowAction` GDAPS
  plugins, and attaches the table wrapper to HTMX `hx-trigger` listen
  events so it auto-refreshes on CRUD success events.

The design is intentionally dataclass-first: consumer code builds
`RowAction` instances or registers `IRowAction` plugins, and the table
knows how to render them. There is no metaclass magic, no string
templating, and no `format_html` calls in Python.

HTMX vs. plain navigation is a per-action flag (`htmx=True` by default).
The delete action opens a modal confirmation dialog by default
(targets `#cj-dialog`); individual actions can override this with
`confirm_style="inline"` (browser-native `hx-confirm`) or by providing
their own `confirm_url`.

Listen events follow the convention `"<namespace>:created"`,
`"<namespace>:changed"`, `"<namespace>:deleted"`. A `CrudTableMixin`
table listens for these by default on its wrapper element, which has
`id="cj-table-<slug>"` and `hx-trigger="<event> from:body"`.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Callable, Iterable, Optional

import django_tables2 as tables
from django.http import HttpRequest
from django.template.loader import render_to_string
from django.urls import reverse
from django.utils.html import format_html
from django.utils.safestring import SafeString, mark_safe
from django.utils.text import slugify
from django.utils.translation import gettext_lazy as _
from gdaps.api import Interface

__all__ = [
    "RowAction",
    "IRowAction",
    "ActionsColumn",
    "CrudTableMixin",
    "standard_edit_action",
    "standard_delete_action",
]


#: Default HTMX target for modal dialogs opened from a row action.
#: Override by setting `RowAction.target` or `CrudTableMixin.dialog_target`.
DEFAULT_DIALOG_TARGET = "#cj-dialog"


@dataclass
class RowAction:
    """Declarative description of one row-level action button.

    A `RowAction` is the only thing a table needs to render one button.
    It carries both the display data (label, icon, CSS variant) and the
    behavior (URL, HTTP method, HTMX attributes, confirm flow,
    permission check). `CrudTableMixin.get_row_actions` builds a list
    of these per record and hands them to `ActionsColumn`.

    Two helpers exist to resolve dynamic values against a record:

    - `url` may be a string (used as-is) or a callable
      `(record) -> str`. Use `reverse(...)` for static URL names and
      a lambda for anything that needs the record's pk.
    - `visible` may be `None` (always visible) or a callable
      `(record, request) -> bool`. It runs *after* the permission
      check; both must pass.

    The `confirm` attribute triggers either a browser-native
    `hx-confirm` (`confirm_style="inline"`) or an HTMX modal fetch
    (`confirm_style="modal"`, default). In modal mode the button
    issues `hx-get` against `confirm_url` — typically a
    `ModalDeleteView` URL — and the server returns the confirmation
    form; the actual delete happens on POST from inside the modal. If
    `confirm_url` is not set, the action's own `url` is used.
    """

    name: str
    label: str
    icon: str = ""
    url: str | Callable[[Any], str] = ""
    method: str = "get"
    htmx: bool = True
    target: str = DEFAULT_DIALOG_TARGET
    swap: str = "innerHTML"
    confirm: str = ""
    confirm_style: str = "modal"
    confirm_url: str | Callable[[Any], str] = ""
    variant: str = "btn-ghost-secondary"
    permission: Optional[str | Callable[[Any, HttpRequest], bool]] = None
    visible: Optional[Callable[[Any, HttpRequest], bool]] = None
    weight: int = 100
    extra_attrs: dict[str, str] = field(default_factory=dict)

    def resolve_url(self, record: Any) -> str:
        return self.url(record) if callable(self.url) else str(self.url)

    def resolve_confirm_url(self, record: Any) -> str:
        if self.confirm_url:
            return (
                self.confirm_url(record)
                if callable(self.confirm_url)
                else str(self.confirm_url)
            )
        return self.resolve_url(record)

    def is_allowed(self, record: Any, request: HttpRequest) -> bool:
        """Return True if this action should render for (record, request).

        Combines `permission` (Django perm string or callable) and
        `visible` (callable). Both must pass. Missing `request.user`
        is treated as unauthenticated.
        """
        perm = self.permission
        if perm is not None:
            if callable(perm):
                if not perm(record, request):
                    return False
            else:
                user = getattr(request, "user", None)
                if user is None or not user.has_perm(perm):
                    return False
        if self.visible is not None and not self.visible(record, request):
            return False
        return True

    def render_attrs(self, record: Any) -> dict[str, str]:
        """Build the HTML attribute dict for this action's button."""
        attrs: dict[str, str] = {
            "class": f"btn btn-sm btn-icon {self.variant}".strip(),
            "title": str(self.label),
            "aria-label": str(self.label),
        }
        url = self.resolve_url(record)

        if self.confirm and self.confirm_style == "modal":
            # Modal-based confirm: GET the confirm URL into the dialog.
            attrs["hx-get"] = self.resolve_confirm_url(record)
            attrs["hx-target"] = self.target
            attrs["hx-swap"] = self.swap
        elif self.htmx:
            attrs[f"hx-{self.method}"] = url
            attrs["hx-target"] = self.target
            attrs["hx-swap"] = self.swap
            if self.confirm and self.confirm_style == "inline":
                attrs["hx-confirm"] = str(self.confirm)
        else:
            # Plain navigation. For POST we still fall back to HTMX,
            # because plain POST needs a wrapping form.
            attrs["href"] = url

        attrs.update({k: str(v) for k, v in self.extra_attrs.items()})
        return attrs


class IRowAction(Interface):
    """GDAPS interface for pluggable row actions.

    Implement this in a consumer app to contribute extra row actions
    to tables that declare a matching `extra_actions_menu`. One plugin
    class represents one action; `to_row_action(request, record)`
    returns a fully-built `RowAction` or `None` to skip rendering.

    Attributes:
        menu: Slot name this action attaches to. Tables with
            `extra_actions_menu = "<menu>"` pick up all plugins that
            share that value.
        weight: Sort weight among actions in the same row (ascending).
    """

    menu: str = ""
    weight: int = 100

    def to_row_action(
        self, request: HttpRequest, record: Any
    ) -> Optional[RowAction]:  # pragma: no cover - interface
        raise NotImplementedError


def standard_edit_action(
    url_namespace: str,
    *,
    target: str = DEFAULT_DIALOG_TARGET,
    permission: Optional[str] = None,
    weight: int = 10,
) -> RowAction:
    """Build the standard 'edit' row action for a URL namespace.

    Expects a URL named `<namespace>_update` that accepts a `pk`
    kwarg. Opens the edit form in the modal dialog by default.
    """
    return RowAction(
        name="edit",
        label=_("Edit"),
        icon="pencil",
        url=lambda record: reverse(f"{url_namespace}_update", kwargs={"pk": record.pk}),
        method="get",
        htmx=True,
        target=target,
        permission=permission,
        weight=weight,
    )


def standard_delete_action(
    url_namespace: str,
    *,
    target: str = DEFAULT_DIALOG_TARGET,
    permission: Optional[str] = None,
    weight: int = 20,
    confirm_style: str = "modal",
    inline_confirm_text: str = "",
) -> RowAction:
    """Build the standard 'delete' row action for a URL namespace.

    Expects a URL named `<namespace>_delete` that accepts a `pk`
    kwarg. With `confirm_style="modal"` (default) the button GETs
    the delete view into the dialog, where a confirmation form then
    POSTs back. With `confirm_style="inline"` the click uses a
    browser-native `hx-confirm` prompt and issues the delete request
    directly.
    """
    return RowAction(
        name="delete",
        label=_("Delete"),
        icon="trash",
        url=lambda record: reverse(f"{url_namespace}_delete", kwargs={"pk": record.pk}),
        method="post" if confirm_style == "inline" else "get",
        htmx=True,
        target=target,
        variant="btn-ghost-danger",
        confirm=inline_confirm_text or _("Really delete this item?"),
        confirm_style=confirm_style,
        permission=permission,
        weight=weight,
    )


class ActionsColumn(tables.Column):
    """A `django_tables2.Column` that renders a row's action buttons.

    The column does not carry the list of actions itself — the parent
    `CrudTableMixin.render_actions` builds the per-record list and
    passes it in via `render_to_string`. This keeps the column
    stateless and lets each row resolve permissions against the
    current request.
    """

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("verbose_name", _("Actions"))
        kwargs.setdefault("empty_values", ())
        kwargs.setdefault("orderable", False)
        attrs = kwargs.setdefault("attrs", {})
        attrs.setdefault("td", {"class": "text-end cj-row-actions"})
        attrs.setdefault("th", {"class": "text-end cj-row-actions"})
        super().__init__(*args, **kwargs)


class CrudTableMixin:
    """Mixin that adds an "actions" column with CRUD row actions.

    Declare this alongside `django_tables2.Table` and set at least
    `crud_url_namespace`. The mixin then:

    - appends an `actions` column at the end of `Meta.sequence`;
    - builds standard edit/delete actions via
      `standard_edit_action` / `standard_delete_action` using the
      namespace's `<ns>_update` / `<ns>_delete` URL names;
    - appends extra actions contributed by `IRowAction` plugins whose
      `menu` equals `extra_actions_menu`;
    - sorts the combined list by weight and renders the buttons;
    - exposes `listen_events` so the calling template can wire the
      table wrapper to `hx-trigger` and refresh itself on
      `<ns>:created|changed|deleted` success events.

    Class attributes:
        crud_url_namespace: Required. Base name for CRUD URLs, e.g.
            `"projects:project"`. Expected routes:
            `{namespace}_update`, `{namespace}_delete`.
        crud_actions: Names of standard actions to include. Defaults
            to `("edit", "delete")`. Set to `()` to opt out.
        extra_actions_menu: GDAPS menu slot for `IRowAction` plugins
            that should appear *additionally* to the standard actions.
        edit_permission / delete_permission: Django permission strings
            gating the standard actions. `None` means "always allow".
        delete_confirm_style: `"modal"` (default) or `"inline"`.
        dialog_target: HTMX target for actions that open the modal.
            Defaults to `#cj-dialog`.
        listen_events: Explicit list of events. If unset, defaults to
            `["<namespace>:created", "<namespace>:changed",
            "<namespace>:deleted"]` (only the ones whose standard
            actions are enabled, plus always `:created`).
    """

    crud_url_namespace: str = ""
    crud_actions: Iterable[str] = ("edit", "delete")
    extra_actions_menu: str = ""
    edit_permission: Optional[str] = None
    delete_permission: Optional[str] = None
    delete_confirm_style: str = "modal"
    dialog_target: str = DEFAULT_DIALOG_TARGET
    listen_events: Optional[list[str]] = None

    def __init__(self, *args, request: Optional[HttpRequest] = None, **kwargs):
        if not self.crud_url_namespace:
            raise AttributeError(
                f"{type(self).__name__} must set 'crud_url_namespace' "
                f"(e.g. 'projects:project')."
            )

        # Inject the actions column. `CrudTableMixin` is not a
        # `tables.Table` subclass, so its class-level `Column` attrs
        # are invisible to django-tables2's declarative metaclass.
        # `extra_columns` is the documented hook for this.
        extra = list(kwargs.pop("extra_columns", []))
        if not any(name == "actions" for name, _ in extra):
            extra.append(("actions", ActionsColumn()))
        kwargs["extra_columns"] = extra

        # Ensure "actions" stays at the end of the column sequence.
        sequence = kwargs.get("sequence") or getattr(
            getattr(self, "Meta", object), "sequence", ("...",)
        )
        sequence = tuple(c for c in sequence if c != "actions") + ("actions",)
        kwargs["sequence"] = sequence

        super().__init__(*args, **kwargs)

        # Table carries the request for per-row permission checks.
        self._cj_request: Optional[HttpRequest] = request or getattr(
            self, "request", None
        )

    # ---- action assembly ------------------------------------------------

    def get_standard_actions(self) -> list[RowAction]:
        """Build the configured standard actions (edit/delete)."""
        actions: list[RowAction] = []
        ns = self.crud_url_namespace
        if "edit" in self.crud_actions:
            actions.append(
                standard_edit_action(
                    ns,
                    target=self.dialog_target,
                    permission=self.edit_permission,
                )
            )
        if "delete" in self.crud_actions:
            actions.append(
                standard_delete_action(
                    ns,
                    target=self.dialog_target,
                    permission=self.delete_permission,
                    confirm_style=self.delete_confirm_style,
                )
            )
        return actions

    def get_extra_actions(
        self, request: HttpRequest, record: Any
    ) -> list[RowAction]:
        """Collect `IRowAction` plugins for this table's menu slot."""
        if not self.extra_actions_menu:
            return []
        result: list[RowAction] = []
        for plugin_cls in IRowAction.enabled_plugins():
            if getattr(plugin_cls, "menu", "") != self.extra_actions_menu:
                continue
            plugin = plugin_cls()
            action = plugin.to_row_action(request, record)
            if action is None:
                continue
            # Default the action's weight to its plugin class weight.
            if action.weight == 100 and getattr(plugin_cls, "weight", 100) != 100:
                action = replace(action, weight=plugin_cls.weight)
            result.append(action)
        return result

    def get_row_actions(
        self, record: Any, request: HttpRequest
    ) -> list[RowAction]:
        """Return the ordered, permission-filtered actions for one row.

        Override this to inject per-row logic without touching the
        rendering machinery.
        """
        actions = self.get_standard_actions() + self.get_extra_actions(
            request, record
        )
        actions = [a for a in actions if a.is_allowed(record, request)]
        actions.sort(key=lambda a: a.weight)
        return actions

    def render_actions(self, record) -> SafeString:
        request = self._get_request()
        if request is None:
            return mark_safe("")
        actions = self.get_row_actions(record, request)
        if not actions:
            return mark_safe("")
        buttons = [
            {"attrs": action.render_attrs(record), "icon": action.icon, "name": action.name}
            for action in actions
        ]
        return render_to_string(
            "conjunto/tables/_row_actions.html",
            {"buttons": buttons},
            request=request,
        )

    # ---- wrapper + listen events ---------------------------------------

    def get_listen_events(self) -> list[str]:
        """Return the HTMX listen events for the table wrapper."""
        if self.listen_events is not None:
            return list(self.listen_events)
        ns = self.crud_url_namespace
        events = [f"{ns}:created"]
        if "edit" in self.crud_actions:
            events.append(f"{ns}:changed")
        if "delete" in self.crud_actions:
            events.append(f"{ns}:deleted")
        return events

    @property
    def wrapper_id(self) -> str:
        """Stable DOM id for the table wrapper, used by templates."""
        return f"cj-table-{slugify(self.crud_url_namespace).replace(':', '-')}"

    @property
    def hx_trigger(self) -> str:
        """`hx-trigger` value joining all listen events."""
        return ", ".join(f"{e} from:body" for e in self.get_listen_events())

    # ---- helpers --------------------------------------------------------

    def _get_request(self) -> Optional[HttpRequest]:
        # django-tables2 sets `self.request` from the template tag's
        # context; fall back to the one passed into __init__.
        return getattr(self, "request", None) or self._cj_request
