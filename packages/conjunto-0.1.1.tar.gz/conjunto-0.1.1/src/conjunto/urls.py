from django.urls import path, include

from .views import MaintenanceView, ModelAutocompleteView, SaveSidebarWidthView

app_name = "conjunto"

urlpatterns = [
    path("maintenance/", MaintenanceView.as_view(), name="maintenance"),
    path("autocomplete/", ModelAutocompleteView.as_view(), name="autocomplete"),
    path("sidebar-width/", SaveSidebarWidthView.as_view(), name="sidebar-width"),
]
