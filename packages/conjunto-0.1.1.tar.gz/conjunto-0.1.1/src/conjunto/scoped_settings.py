"""Framework-level scoped setting registrations.

Auto-discovered by
:meth:`conjunto.settings.apps.SettingsConfig.ready` via
``autodiscover_modules("scoped_settings")``. Consumers add their own
``scoped_settings.py`` at the top level of their apps to register
additional keys.

The four keys here replace the old ``AbstractSettings`` fields that
used to drive layout and maintenance mode:

- ``conjunto.layout_style`` — ``"fluid"`` or ``"boxed"``.
- ``conjunto.topbar_fixed`` — fixed vs. sticky topbar.
- ``conjunto.sidebar_width`` — CSS length.
- ``conjunto.maintenance_mode`` — boolean; ``True`` redirects non-staff
  users to the ``/maintenance/`` page.

Defaults come from the ``CONJUNTO_*`` Django settings when set, with
hard-coded fallbacks otherwise. Consumers override per-request via the
normal scope chain (``USER > DEVICE > GROUP > TENANT > VENDOR``).
"""

from django.conf import settings as django_settings

from conjunto.settings.scoped.models import Scope
from conjunto.settings.scoped.registry import SettingRegistry

SettingRegistry.register(
    "conjunto",
    "layout_style",
    type="str",
    default=getattr(django_settings, "CONJUNTO_LAYOUT", "fluid"),
    help_text="Page layout: 'fluid' (container-fluid) or 'boxed' (container-xl).",
    icon="layout",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "topbar_fixed",
    type="bool",
    default=getattr(django_settings, "CONJUNTO_TOPBAR_FIXED", True),
    help_text="Whether the topbar uses position:fixed (True) or position:sticky (False).",
    icon="layout-navbar",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "sidebar_width",
    type="str",
    default=getattr(django_settings, "CONJUNTO_SIDEBAR_WIDTH", "15rem"),
    help_text="CSS length of the left sidebar (e.g. '15rem', '240px').",
    icon="layout-sidebar",
    writable_scopes=[Scope.VENDOR, Scope.TENANT, Scope.USER],
    lockable_scopes=[Scope.VENDOR, Scope.TENANT],
)

SettingRegistry.register(
    "conjunto",
    "maintenance_mode",
    type="bool",
    default=False,
    help_text="When True, non-staff users are redirected to /maintenance/.",
    icon="tool",
    writable_scopes=[Scope.VENDOR],
    lockable_scopes=[Scope.VENDOR],
)
