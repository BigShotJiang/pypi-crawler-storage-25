import locale
import secrets
import string
import subprocess

from django.conf import settings
from django.db.models import Model
from django.utils.translation import gettext_lazy as _

import logging

logger = logging.getLogger(__name__)


def str_to_bool(bool_str: str) -> bool:
    """returns True if bool_str is "true", else False."""
    return bool_str.lower() == "true"


def snake_case2spaces(value: str | None):
    """Converts a snake_case string to spaces."""
    value = value or ""
    return value.replace("_", " ")


def spaces2snake_case(value: str | None):
    """Converts a space separated string to snake_case."""
    value = value or ""
    return value.lower().strip().replace(" ", "_")


def camel_case2snake(camel_str: str | None, separator="_"):
    """Converts a CamelCase string to snake_case."""
    if camel_str is None:
        camel_str = ""
    snake_str = ""
    for index, char in enumerate(camel_str):
        if char.islower() or index == 0:
            snake_str += char.lower()
        else:
            snake_str += f"{separator}{char.lower()}"
    return snake_str


def country_code_from_locale(loc: tuple[str, str] | str) -> str:
    """Extracts an (uppercase) country code from a locale"""
    language, country_code, encoding = _split_locale(loc)
    return country_code.upper()


def country_name_from_code(iso3166_code: str) -> str:
    """Returns the country name from a ISO 3166 Alpha2 country code."""

    # TODO: this assumes that LANGUAGES is defined in settings.py
    for code, language in settings.LANGUAGES:
        # if code is in xx-xx format, use the first part only
        if "-" in code:
            code = code.split("-", 1)[0]
        if code == iso3166_code:
            return language
    else:
        return f"{iso3166_code} ({_('not supported')})"


def _split_locale(loc: tuple[str, str] | str) -> tuple[str, str, str]:
    """returns language, country_code, encoding from a locale string."""
    if isinstance(loc, str):
        loc = locale.normalize(loc)
        if "." in loc:
            locale_name, encoding = loc.split(".")
        else:
            locale_name = loc
            encoding = ""
    else:
        locale_name, encoding = loc
    # here we can be sure that loc is in the format "de_AT.UTF8"
    if "_" in locale_name:
        language, country_code = locale_name.split("_")
    else:
        language, country_code = locale_name, ""
    return language, country_code, encoding


def language_from_locale(loc: tuple[str, str] | str) -> str:
    """Extracts a language code from a locale"""
    language, country_code, encoding = _split_locale(loc)
    return language


def get_system_locales(strip_c: bool = True) -> list[str]:
    """Finds locales installed on a POSIX system and returns a list.

    Params:
        strip_c: if True(default), remove C.* and POSIX from result
    """
    # https://stackoverflow.com/a/54787951/818131

    out = subprocess.run(["locale", "-a"], stdout=subprocess.PIPE).stdout
    try:
        res = out.decode("utf-8")
    except UnicodeDecodeError:
        res = out.decode("latin-1")
    locales = res.rstrip("\n").splitlines()
    if strip_c:
        locales = [
            line for line in locales if not line.startswith("C") and not line == "POSIX"
        ]
    return locales


def create_group_permissions(
    group_permissions: dict[str, dict[type[Model] | str, list[str]]],
) -> list[str]:
    """Create groups and assign their permissions from the given schema.

    The schema is authoritative: each group's permission set is **replaced**
    with the permissions listed for it, so removing an entry from the dict
    also revokes the permission on the next run. Groups not mentioned in the
    dict are left untouched.

    Args:
        group_permissions: mapping of group name → model → list of permission
            verbs (``"view"``, ``"add"``, ``"change"``, ``"delete"``, or any
            custom verb). Models may be given either as a class or as an
            ``"app_label.ModelName"`` string.

    Returns:
        A list of human-readable error messages for permissions that could
        not be resolved. An empty list means every entry was applied.
    """
    from django.apps import apps
    from django.contrib.auth.models import Group, Permission
    from django.contrib.contenttypes.models import ContentType

    errors: list[str] = []

    for group_name, models in group_permissions.items():
        group, _created = Group.objects.get_or_create(name=group_name)

        desired: list[Permission] = []
        for model, perm_names in models.items():
            model_class = apps.get_model(model) if isinstance(model, str) else model
            content_type = ContentType.objects.get_for_model(model_class)
            model_name = model_class._meta.model_name

            for perm_name in perm_names:
                codename = f"{perm_name}_{model_name}"
                try:
                    desired.append(
                        Permission.objects.get(
                            content_type=content_type, codename=codename
                        )
                    )
                except Permission.DoesNotExist:
                    errors.append(
                        f"Permission '{content_type.app_label}.{codename}' "
                        f"not found (group '{group_name}')."
                    )

        group.permissions.set(desired)
        logger.info(
            "Set %d permission(s) on group '%s'", len(desired), group_name
        )

    return errors


def generate_password(length=12, human_usable=False, with_punctuation=True) -> str:
    min_length = getattr(settings, "PASSWORD_MIN_LENGTH", 8)
    if not isinstance(length, int) or length < min_length:
        raise ValueError(f"password must have positive length > {min_length}")
    characters = string.ascii_letters + string.digits
    if human_usable:
        if with_punctuation:
            # only use punctuation that is safe for humans to read and write,
            # omit chars like `'
            # characters += r"""!"#$%&()*+-./=?@[]_{|}~"""
            characters += r"""!#$%&()*+-./=?@"""
            # remove characters that can be mixed easily with others when printed in the
            # wrong font, like O/0 or i/l/1
            # This reduces security a bit, but let's face it: Users tend to use the
            # name of their children as passwords, so we don't need to worry about that.
            # Using a strong password with slightly reduced complexity is a good
            # trade-off to human-generated passwords which tend to be very bad.
        characters = characters.replace("O", "")
        characters = characters.replace("o", "")
        characters = characters.replace("0", "")
        characters = characters.replace("l", "")
        characters = characters.replace("i", "")
        characters = characters.replace("1", "")
    else:
        if with_punctuation:
            characters += string.punctuation
    characters = characters.replace("\\", "")
    return "".join(secrets.choice(characters) for _ in range(length))
