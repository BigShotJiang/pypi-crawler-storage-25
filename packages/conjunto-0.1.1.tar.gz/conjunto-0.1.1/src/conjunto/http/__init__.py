from django.http import HttpResponse, HttpResponseRedirect
from django_htmx.http import trigger_client_event


class HttpResponseEmpty(HttpResponse):
    """An HTTP response that has no content.

    Used for HTMX requests that should not return anything, like delete requests.
    The returned status code is **204** (No Content).
    """

    status_code = 204


class HttpResponseHXRedirect(HttpResponseRedirect):
    """A Http response that redirects a HTMX request to the location given in
    `redirect_to`"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self["HX-Redirect"] = self["Location"]

    status_code = 200


def add_toast(
    response: HttpResponse,
    message: str,
    level: str = "info",
    dismissible: bool = False,
    delay: int | None = None,
) -> HttpResponse:
    """Attach a single toast to an HTMX response.

    Fires a ``showToast`` client event via the ``HX-Trigger`` header.
    Use this from HTMX views that return an ``HttpResponse`` directly
    and don't want to go through the ``django.contrib.messages``
    framework.

    Args:
        response: The response to decorate (returned unchanged).
        message: Toast body text.
        level: One of ``"info"``, ``"success"``, ``"warning"``,
            ``"error"``, ``"debug"``. Maps to a Tabler soft color.
        dismissible: If ``True``, the toast stays visible until the
            user closes it via the ``×`` button.
        delay: Per-toast auto-hide delay in milliseconds. Ignored when
            ``dismissible`` is ``True``. Defaults to the container's
            ``data-cj-toast-delay`` value.

    Returns:
        The same response, with the ``HX-Trigger`` header updated.
    """
    payload: dict = {
        "message": str(message),
        "level": level,
        "dismissible": bool(dismissible),
    }
    if delay is not None:
        payload["delay"] = int(delay)
    trigger_client_event(response, "showToast", params=payload)
    return response
