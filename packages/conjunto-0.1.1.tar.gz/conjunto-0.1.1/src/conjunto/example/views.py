"""
Example views for the Conjunto template system.

These views demonstrate how to use the Conjunto templates with
different layout configurations and menu items.
"""

from django.shortcuts import render
from django.views.generic import TemplateView


class ExampleDashboardView(TemplateView):
    """
    Example dashboard view using the Tabler base template.

    This view demonstrates how to use the base template with
    all the available blocks and context variables.
    """

    template_name = "conjunto/example/dashboard.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "page_title": "Dashboard",
                "page_pretitle": "Home",
                # You can add more context variables here
            }
        )
        return context


def example_page_view(request):
    """
    Simple function-based view example.

    Demonstrates minimal usage of the Tabler template.
    """
    context = {
        "page_title": "Example Page",
        "page_pretitle": "Examples / Page",
    }
    return render(request, "conjunto/example/page.html", context)
