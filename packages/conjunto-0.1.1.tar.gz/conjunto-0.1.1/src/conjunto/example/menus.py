"""
Example menu items for the Conjunto Tabler template system.

These are example implementations of IMenuItem that demonstrate
how to use the various menu locations in the Tabler templates.

To use these examples, import them in your app or create similar
menu items in your own code.
"""

from django.urls import reverse_lazy
from django.utils.text import format_lazy
from django.utils.translation import gettext_lazy as _

from conjunto.menu import IMenuItem

# ============================================================================
# Main Navigation Menu (Horizontal Navbar)
# ============================================================================


class DashboardMenuItem(IMenuItem):
    """Dashboard menu item in main navigation."""

    menu = "main"
    title = _("Dashboard")
    slug = "dashboard"
    url = "/"
    icon = "home"
    weight = 0


class UsersMenuItem(IMenuItem):
    """Users menu item with dropdown in main navigation."""

    menu = "main"
    title = _("Users")
    slug = "users"
    icon = "users"
    weight = 10


class UserListMenuItem(IMenuItem):
    """User list submenu item."""

    title = _("User List")
    slug = "user-list"
    parent = "users"
    url = "/users/"
    icon = "list"


class UserAddMenuItem(IMenuItem):
    """Add user submenu item."""

    title = _("Add User")
    slug = "user-add"
    parent = "users"
    url = "/users/add/"
    icon = "user-plus"


# ============================================================================
# Sidebar Menu (Vertical Navigation)
# ============================================================================


class SidebarDashboardMenuItem(IMenuItem):
    """Dashboard in sidebar."""

    menu = "sidebar"
    title = _("Dashboard")
    slug = "sidebar-dashboard"
    url = "/"
    icon = "home"
    weight = 0


class SidebarContentMenuItem(IMenuItem):
    """Content management parent item in sidebar."""

    menu = "sidebar"
    title = _("Content")
    slug = "content"
    icon = "file-text"
    weight = 10


class SidebarPagesMenuItem(IMenuItem):
    """Pages submenu item."""

    title = _("Pages")
    slug = "pages"
    parent = "content"
    url = "/pages/"
    icon = "file"


class SidebarMediaMenuItem(IMenuItem):
    """Media submenu item."""

    title = _("Media")
    slug = "media"
    parent = "content"
    url = "/media/"
    icon = "photo"


class SidebarSettingsMenuItem(IMenuItem):
    """Settings in sidebar."""

    menu = "sidebar"
    title = _("Settings")
    slug = "sidebar-settings"
    url = "/settings/"
    icon = "settings"
    weight = 100


# ============================================================================
# User Menu (Dropdown in Navbar)
# ============================================================================


class ProfileMenuItem(IMenuItem):
    """User profile menu item — points at the settings page's profile section."""

    menu = "user"
    title = _("Profile")
    slug = "profile"
    url = format_lazy("{}?section=profile", reverse_lazy("settings:index"))
    icon = "user"
    weight = 0


class AccountSettingsMenuItem(IMenuItem):
    """Account settings menu item."""

    menu = "user"
    title = _("Settings")
    slug = "account-settings"
    url = "/account/settings/"
    icon = "settings"
    weight = 10


# ============================================================================
# Notifications Menu
# ============================================================================


class NotificationExampleMenuItem(IMenuItem):
    """Example notification menu item."""

    menu = "notifications"
    title = _("New message received")
    slug = "notification-1"
    url = "/notifications/1/"
    icon = "mail"
    badge = "New"
    badge_class = "bg-blue"


# ============================================================================
# Page Actions (Buttons next to page title)
# ============================================================================


class AddPageActionMenuItem(IMenuItem):
    """Add new item action button."""

    menu = "page_actions"
    title = _("Add New")
    slug = "add-action"
    url = "/add/"
    icon = "plus"
    weight = 0

    # Custom attribute for button styling
    style = "primary"


class ExportPageActionMenuItem(IMenuItem):
    """Export action button."""

    menu = "page_actions"
    title = _("Export")
    slug = "export-action"
    url = "/export/"
    icon = "download"
    weight = 10

    style = "secondary"
