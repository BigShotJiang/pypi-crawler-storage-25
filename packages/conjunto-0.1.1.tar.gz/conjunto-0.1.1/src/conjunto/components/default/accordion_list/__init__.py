import random
from typing import Optional

from .. import AccordionType
from ..accordion import Accordion


class AccordionList(Accordion):
    """Tabler.io Accordion with a list of items.

    Attributes:
        items: list of dictionaries with keys 'title' and 'text':
            `{'title': 'Item 1', 'text': 'Some content for Item 1' }`
        id: optional id for the accordion, if not provided, a default one will be used
        type_: The type of the accordion: FLUSH, TABS, INVERTED
    """

    items: dict
    type_: AccordionType

    def load(
        self,
        id: str = "",
        items: Optional[dict] = None,
        type_: AccordionType = AccordionType.FLUSH,
        *args,
        **kwargs,
    ):
        if not id and not self.id:
            id = f"accordion_list_{random.randint(1000,9999)}"
        self.id = id
        self.items = items or {}
        self.type_ = type_
