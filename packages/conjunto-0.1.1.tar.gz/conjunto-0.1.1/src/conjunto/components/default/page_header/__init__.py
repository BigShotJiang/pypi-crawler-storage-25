from tetra import BasicComponent


class PageHeader(BasicComponent):
    """A tabler Page header.

    Slots:
        title_actions: the actions to be displayed in the title bar.
    """

    # TODO: make PageHeader a Component, and allow flexible @public title_actions
    title: str = ""
    pretitle: str = ""

    def load(self, title: str = "", pretitle: str = ""):
        self.title = title
        self.pretitle = pretitle
