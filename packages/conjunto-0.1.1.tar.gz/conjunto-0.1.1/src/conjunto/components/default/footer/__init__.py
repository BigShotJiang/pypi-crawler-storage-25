from django.template import RequestContext
from tetra import Component


class Footer(Component):
    pass
