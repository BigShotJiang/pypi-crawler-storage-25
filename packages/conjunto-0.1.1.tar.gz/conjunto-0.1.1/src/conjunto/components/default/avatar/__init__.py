from tetra import BasicComponent


class Avatar(BasicComponent):
    image_url: str = ""

    def load(self, image_url):
        self.image_url = image_url
