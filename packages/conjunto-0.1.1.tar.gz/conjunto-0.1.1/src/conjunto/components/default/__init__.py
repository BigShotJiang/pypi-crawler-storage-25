# Legacy Tetra components — removed.
#
# This module previously declared Tetra-based UI components (Alert, Card,
# Modal, AbstractTabCard, ...). Tetra has been removed from the project;
# these components are now reimplemented as Django template partials under
# templates/conjunto/. The sibling subdirectories in this package still
# contain the old Tetra source and should be cleaned up in a follow-up.
