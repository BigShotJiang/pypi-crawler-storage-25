from django.contrib import messages
from tetra import BasicComponent


class Alert(BasicComponent):
    title: str = ""
    icon: str = None
    text: str = None
    message_level: int = messages.INFO
    dismissible: bool = False

    def load(self, icon=None, dismissible=False, level=messages.INFO, *args, **kwargs):
        self.icon = icon
        self.dismissible = dismissible
        self.message_level = level
        self.level_tag = messages.DEFAULT_TAGS[level]
