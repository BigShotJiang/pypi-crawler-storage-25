import random

from tetra import BasicComponent


class AccordionItem(BasicComponent):
    id: str = ""

    def load(self, id: str = None, *args, **kwargs):
        if not id and not self.id:
            id = f"accordion_item_{random.randint(1000,9999)}"
        self.id = id
