from tetra import BasicComponent


class ModalButton(BasicComponent):
    """Basically a button that opens a modal dialog.

    Attributes:
        target (str): The id of the modal to open.

    The default block is the content of the button.
    """

    target_id: str = ""
    link: bool = False

    def load(self, target: str, link: bool = False, *args, **kwargs):
        # take target with and without leading "#"
        if target and target.startswith("#"):
            self.target_id = target[1:]
        else:
            self.target_id = target
        if link:
            self.link = True
