import random

from tetra import BasicComponent


class Accordion(BasicComponent):

    id: str = ""
    type_: str = ""
    show_icon: bool = True
    icon: str = "link"
    toggle_icon: str = "chevron-down"

    def load(self, id: str = "", *args, **kwargs):
        if not id and not self.id:
            id = f"accordion_{random.randint(1000,9999)}"
        self.id = id


# class SimpleAccordion(BasicComponent):
#     """Simple Accordion with a list of items.
#
#     Attributes:
#         items: list of dictionaries with keys 'title' and 'text':
#             `{'title': 'Item 1', 'text': 'Some content for Item 1' }`
#         id: optional id for the accordion, if not provided, a default one will be used
#     """
#
#
#     items: dict = {}
#
#     def load(self, id: str = None, items: dict = None, *args, **kwargs):
#         if not id:
#             id = "accordion-component"
#         self.id = id
#         items = items
#
#     # language=html
#     template: django_html = """
#     <div class="accordion"
#     {% ... id=id|if:id|else:"accordion-component" %}>
#       {% for item in items %}
#         <div class="accordion-item">
#           <h2 class="accordion-header" id="heading-1">
#             <button class="accordion-button" type="button" data-bs-toggle="collapse"
#            data-bs-target="#collapse-{{forloop.counter}}" aria-expanded="true">
#               {{item.title }}
#             </button>
#           </h2>
#           <div id="collapse-{{forloop.counter}}"
#                 class="accordion-collapse collapse show"
#                 data-bs-parent="#{{id}}"
#                 style="">
#             <div class="accordion-body pt-0">
#               {{ item.text }}
#             </div>
#           </div>
#         </div>
#       {% endfor %}
#     </div>
#     """
