from tetra import Component


class Page(Component):

    title: str = ""

    def load(self, title: str = "", *args, **kwargs):
        self.title = title
