from tetra import Component, public


class NotificationsMenu(Component):
    new_notifications: bool = public(False)
    extra_context = ["user"]
