from typing import TYPE_CHECKING

from django import forms

if TYPE_CHECKING:
    from django.utils.functional import _StrPromise


class DatePickerInput(forms.widgets.DateInput):
    """A DateInput that uses a date picker.

    It adds Litepicker.js for that input field.
    Additionally, you can specify another field with "end_field_name"
    that is used for date ranges by Litepicker then.
    """

    class Media:
        js = ("conjunto/js/datepicker.js",)

    template_name = "conjunto/widgets/datepicker_input.html"

    def __init__(self, attrs=None, end_field_name=None):
        if attrs is None:
            attrs = {}
        attrs.update({"autocomplete": "off"})
        if end_field_name:
            attrs.update({"data-end-field": end_field_name})
        super().__init__(attrs)


class SelectGroup(forms.widgets.ChoiceWidget):
    """A SelectGroup widget that resembles the Tabler.io form-selectgroup."""

    template_name = "conjunto/widgets/selectgroup.html"
    option_template_name = None  # We handle options in the main template

    def __init__(self, attrs=None, choices=(), multiple=False, as_btn_group=False):
        super().__init__(attrs, choices)
        self.multiple = multiple
        self.as_btn_group = as_btn_group

    def get_context(self, name, value, attrs):
        context = super().get_context(name, value, attrs)
        context["widget"]["multiple"] = self.multiple
        context["widget"]["as_btn_group"] = self.as_btn_group
        # Ensure correct classes for the input element.
        # We don't want 'form-control' or other classes inherited from the field.
        input_class = "btn-check" if self.as_btn_group else "form-selectgroup-input"
        for group, options, index in context["widget"]["optgroups"]:
            for option in options:
                option["attrs"]["class"] = input_class
        return context


class SelectGroupMultiple(SelectGroup):
    """A convenience SelectGroup widget for multiple choices."""

    def __init__(self, attrs=None, choices=(), as_btn_group=False):
        super().__init__(attrs, choices, multiple=True, as_btn_group=as_btn_group)

    def value_from_datadict(self, data, files, name):
        return data.getlist(name)

    def value_omitted_from_data(self, data, files, name):
        return name not in data
