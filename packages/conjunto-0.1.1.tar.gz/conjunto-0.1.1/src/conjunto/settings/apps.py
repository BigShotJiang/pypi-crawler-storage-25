from django.utils.translation import gettext_lazy as _
from gdaps import api


class SettingsConfig(api.PluginConfig):
    """GDAPS plugin providing a plugin-extensible settings page."""

    label = "conjunto_settings"
    name = "conjunto.settings"
    verbose_name = _("Settings")

    class PluginMeta:
        verbose_name = _("Settings")
        author = "Christian González"
        author_email = "christian.gonzalez@nerdocs.at"
        description = _("Plugin-extensible settings page.")
        version = "1.0.0"
        category = "Conjunto"
        obligatory = True

    def ready(self):
        from django.utils.module_loading import autodiscover_modules

        # Import the built-in settings plugins so the InterfaceMeta
        # metaclass registers them.
        from . import menus  # noqa: F401

        # Import the built-in scope plugins for the scoped-settings
        # subsystem so GDAPS discovers them.
        from .scoped import scopes  # noqa: F401

        # Auto-discover ``scoped_settings.py`` modules across every
        # installed app so consumer-level SettingRegistry.register()
        # calls fire during startup. Mirrors Django's admin / checks
        # autodiscovery pattern.
        autodiscover_modules("scoped_settings")
