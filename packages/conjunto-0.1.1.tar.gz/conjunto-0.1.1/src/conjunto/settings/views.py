"""Views for the conjunto settings page.

:class:`SettingsView` renders the full page and — when HTMX targets
``#cj-settings-pane`` — only the right pane partial. :class:`SettingsFormView`
handles a single :class:`ISettingsForm` POST. On success it returns an
empty 204 response decorated with the ``settings:changed`` and
``showToast`` HTMX triggers and ``HX-Reswap: none`` so the client-side form
element is left in place; a pane-level listener reloads the whole pane to
pick up the canonical state. On validation errors the view renders the
single-form partial (``page.html#settings-form``) with the bound form.
"""

from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.exceptions import PermissionDenied
from django.http import Http404
from django.utils.translation import gettext_lazy as _
from django.views.generic import FormView, TemplateView
from django_htmx.http import trigger_client_event

from conjunto.htmx.views import HtmxFormViewMixin

from .interfaces import (
    ISettingsForm,
    ISettingsSection,
    find_form_by_name,
    resolve_section,
)

PANE_ID = "cj-settings-pane"


class SettingsView(LoginRequiredMixin, TemplateView):
    """Full settings page, with HTMX partial support for pane swaps."""

    template_name = "conjunto/settings/page.html"
    htmx_partial_template = "conjunto/settings/page.html#settings-pane"

    def get_template_names(self):
        # HTMX pane swap (either from a rail click or from the pane's
        # ``settings:changed`` self-refresh) → return only the partial.
        if self.request.htmx and self.request.htmx.target == PANE_ID:
            return [self.htmx_partial_template]
        return [self.template_name]

    # ------------------------------------------------------------------
    # data assembly
    # ------------------------------------------------------------------
    def _build_groups(self):
        """Return ``[(group_cls, [section_cls, ...]), ...]``, permission-filtered.

        Groups and sections are each sorted by their ``weight`` attribute.
        """
        sections_by_group: dict = {}
        for section_cls in ISettingsSection.enabled_plugins():
            if not section_cls.has_permission(self.request):
                continue
            group = getattr(section_cls, "group", None)
            if group is None:
                continue
            sections_by_group.setdefault(group, []).append(section_cls)

        groups = []
        for group in sorted(sections_by_group, key=lambda g: getattr(g, "weight", 0)):
            sections = sorted(
                sections_by_group[group],
                key=lambda s: getattr(s, "weight", 0),
            )
            groups.append((group, sections))
        return groups

    def _pick_active(self, groups):
        """Pick the active section from ``?section=<name>`` or fall back to
        the first available."""
        requested = self.request.GET.get("section")
        flat = [s for _, sections in groups for s in sections]
        if requested:
            for section_cls in flat:
                if getattr(section_cls, "name", None) == requested:
                    return section_cls
        return flat[0] if flat else None

    def _forms_for(self, active_section):
        """Build bound (unbound) form instances for each matching form plugin.

        Plugins may omit ``form_class`` when they supply a custom
        ``template`` — in that case the form value is ``None`` and the
        subsection is rendered purely via the custom template.
        """
        out = []
        active_name = getattr(active_section, "name", None)
        for form_cls in ISettingsForm.enabled_plugins():
            plugin = form_cls()
            target = resolve_section(getattr(plugin, "section", None))
            if target is None or getattr(target, "name", None) != active_name:
                continue
            form_class = plugin.get_form_class()
            if form_class is None:
                if plugin.get_template() is None:
                    continue
                out.append((plugin, None))
                continue
            kwargs = {"initial": plugin.get_initial(self.request)}
            instance = plugin.get_instance(self.request)
            if instance is not None:
                kwargs["instance"] = instance
            out.append((plugin, form_class(**kwargs)))
        return out

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        groups = self._build_groups()
        active = self._pick_active(groups)
        ctx["groups"] = groups
        ctx["active_section"] = active
        ctx["forms"] = self._forms_for(active) if active is not None else []
        ctx["pane_id"] = PANE_ID
        return ctx


class SettingsFormView(LoginRequiredMixin, HtmxFormViewMixin, FormView):
    """POST handler for a single :class:`ISettingsForm` plugin.

    Success: 204 empty body, ``HX-Trigger`` carries ``settings:changed``
    and ``showToast``, ``HX-Reswap: none`` keeps the client form in place.

    Error: renders the ``page.html#settings-form`` partial with the bound
    invalid form; HTMX replaces only the single ``<section>`` element.
    """

    template_name = "conjunto/settings/page.html#settings-form"
    # Empty on purpose: HtmxFormViewMixin converts the default redirect
    # into an empty 204 response when success_event is set.
    success_url = ""
    success_event = "settings:changed"
    enforce_htmx = True

    plugin: ISettingsForm
    active_section: type[ISettingsSection]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Track whether the current request actually validated. Used by
        # ``get_success_event`` so that SuccessEventMixin does not fire the
        # success event on ``form_invalid`` (which still returns 200 and
        # would otherwise look like a success to the mixin).
        self._form_was_valid = False

    def get_success_event(self) -> str:
        return self.success_event if self._form_was_valid else ""

    # ------------------------------------------------------------------
    # dispatch: load plugin + permission check
    # ------------------------------------------------------------------
    def dispatch(self, request, *args, form_name=None, **kwargs):
        plugin_cls = find_form_by_name(form_name) if form_name else None
        if plugin_cls is None:
            raise Http404(f"Unknown settings form '{form_name}'")
        self.plugin = plugin_cls()
        section = resolve_section(getattr(self.plugin, "section", None))
        if section is None:
            raise Http404(f"Settings form '{form_name}' has no resolvable section.")
        if not section.has_permission(request):
            raise PermissionDenied
        self.active_section = section
        return super().dispatch(request, *args, **kwargs)

    # ------------------------------------------------------------------
    # form plumbing delegated to the plugin
    # ------------------------------------------------------------------
    def get_form_class(self):
        return self.plugin.get_form_class()

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        instance = self.plugin.get_instance(self.request)
        if instance is not None:
            kwargs["instance"] = instance
        # Plugin-supplied initial is a weaker default than POSTed data,
        # which ``super().get_form_kwargs`` already added under "data".
        plugin_initial = self.plugin.get_initial(self.request)
        if plugin_initial:
            kwargs["initial"] = {**plugin_initial, **kwargs.get("initial", {})}
        return kwargs

    # ------------------------------------------------------------------
    # success / error responses
    # ------------------------------------------------------------------
    def form_valid(self, form):
        self._form_was_valid = True
        self.plugin.save(form, self.request)
        # HtmxFormViewMixin converts the empty success_url to HttpResponseEmpty
        # (204); SuccessEventMixin.dispatch then adds the HX-Trigger header
        # for ``success_event``.
        response = super().form_valid(form)
        # Prevent HTMX from applying the form's outerHTML swap to the
        # empty body — otherwise the client form element disappears.
        response["HX-Reswap"] = "none"
        # Additional trigger: show a toast via the conjunto toast pattern.
        trigger_client_event(
            response,
            "showToast",
            params={
                "message": str(_("Saved successfully")),
                "type": "success",
            },
        )
        return response

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx["plugin"] = self.plugin
        ctx["active_section"] = self.active_section
        return ctx
