"""Models for the scoped settings subsystem.

Lives under ``conjunto.settings.scoped`` for logical grouping, but the
models are re-imported into ``conjunto.settings.models`` so Django's
``conjunto_settings`` AppConfig discovers them as part of that app
(no separate AppConfig or app_label juggling needed).
"""

import uuid

from django.conf import settings
from django.db import models
from django.db.models import CheckConstraint, Q, UniqueConstraint, Value
from django.db.models.functions import Coalesce
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

# Lazy default for the swappable tenant model — mirrors the AUTH_USER_MODEL
# pattern but with a conjunto-shipped concrete default.
_TENANT_MODEL = getattr(settings, "CONJUNTO_TENANT_MODEL", "conjunto_tenants.Tenant")


class Scope(models.IntegerChoices):
    """Priority chain: higher values win in the normal walk. Locks
    short-circuit the walk starting from the lowest priority (VENDOR)."""

    VENDOR = 1, _("Vendor")
    TENANT = 2, _("Tenant")
    GROUP = 3, _("Group")
    DEVICE = 4, _("Device")
    USER = 5, _("User")


class Device(models.Model):
    """A client browser/device identified by a long-lived cookie.

    The ``cookie_id`` UUID is the value stored in the ``cj_device_id``
    cookie. Devices are persistent across sessions and are used as the
    anchor for DEVICE-scoped settings.

    Binding rules (enforced by :class:`ScopedSettingsMiddleware`):

    - On the first authenticated request where ``user`` is NULL, the
      device is bound to ``request.user``.
    - A device is **never rebound** across users. If a different user
      logs in on the same browser, a new Device row is created; the old
      one stays in history linked to the previous user.
    """

    cookie_id = models.UUIDField(
        default=uuid.uuid4,
        unique=True,
        editable=False,
    )
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="devices",
    )
    name = models.CharField(max_length=100, blank=True)
    user_agent = models.CharField(max_length=500, blank=True)
    first_seen = models.DateTimeField(auto_now_add=True)
    # last_seen is updated explicitly by ScopedSettingsMiddleware via
    # QuerySet.update() (debounced to at most once per 5 minutes), so
    # no auto_now — admin edits must not bump the field either.
    last_seen = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ["-last_seen"]

    def __str__(self):
        label = self.name or f"Device {self.cookie_id}"
        if self.user_id:
            return f"{label} ({self.user})"
        return label


class ScopedSetting(models.Model):
    """A single setting row at one scope level.

    The effective value of a (namespace, key) for a request is the
    overlay of all rows matching that request along the chain
    ``VENDOR → TENANT → GROUP → DEVICE → USER`` (lowest-to-highest
    priority). A ``locked=True`` row short-circuits the walk at its own
    scope, making it a "floor" that higher scopes cannot dig under.
    Because the walk runs lowest-to-highest, the **lowest-priority lock
    wins** when multiple locks exist at different scopes (VENDOR lock is
    the ultimate authority).

    ``site`` is an **orthogonal filter**, not a sixth scope. Every
    query filters by ``site = request.site OR site IS NULL``; a
    site-specific row beats a site-null row at the same scope tier.

    Each row points at exactly one of ``{user, group, device, tenant}``
    except for VENDOR, where all four FKs are NULL. A CheckConstraint
    enforces this at the DB level.
    """

    namespace = models.CharField(max_length=64, db_index=True)
    key = models.CharField(max_length=255)
    scope = models.PositiveSmallIntegerField(choices=Scope.choices, db_index=True)

    # Per-scope FKs. Exactly one is non-null except for VENDOR (all null).
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="+",
    )
    group = models.ForeignKey(
        "auth.Group",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="+",
    )
    device = models.ForeignKey(
        "conjunto_settings.Device",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="+",
    )
    tenant = models.ForeignKey(
        _TENANT_MODEL,
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="+",
    )

    # Orthogonal dimension — not part of the priority chain.
    site = models.ForeignKey(
        "sites.Site",
        null=True,
        blank=True,
        on_delete=models.CASCADE,
        related_name="+",
    )

    value = models.JSONField()
    locked = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        permissions = [
            (
                "manage_vendor_settings",
                _("Can edit or lock settings at the VENDOR scope"),
            ),
        ]
        indexes = [
            models.Index(fields=["namespace", "key"]),
        ]
        constraints = [
            # Scope ↔ FK exclusivity: exactly one of {user, group,
            # device, tenant} non-null for non-VENDOR scopes; all four
            # null for VENDOR.
            CheckConstraint(
                condition=(
                    (
                        Q(scope=Scope.VENDOR)
                        & Q(user__isnull=True)
                        & Q(group__isnull=True)
                        & Q(device__isnull=True)
                        & Q(tenant__isnull=True)
                    )
                    | (
                        Q(scope=Scope.USER)
                        & Q(user__isnull=False)
                        & Q(group__isnull=True)
                        & Q(device__isnull=True)
                        & Q(tenant__isnull=True)
                    )
                    | (
                        Q(scope=Scope.GROUP)
                        & Q(user__isnull=True)
                        & Q(group__isnull=False)
                        & Q(device__isnull=True)
                        & Q(tenant__isnull=True)
                    )
                    | (
                        Q(scope=Scope.DEVICE)
                        & Q(user__isnull=True)
                        & Q(group__isnull=True)
                        & Q(device__isnull=False)
                        & Q(tenant__isnull=True)
                    )
                    | (
                        Q(scope=Scope.TENANT)
                        & Q(user__isnull=True)
                        & Q(group__isnull=True)
                        & Q(device__isnull=True)
                        & Q(tenant__isnull=False)
                    )
                ),
                name="conjunto_settings_scopedsetting_scope_ref_matches",
            ),
            # Partial UNIQUE per scope. Each uses Coalesce(site_id, 0)
            # so NULL sites collapse into a single uniqueness slot —
            # SQL NULLs are otherwise distinct and would allow duplicates.
            UniqueConstraint(
                "namespace",
                "key",
                "user",
                Coalesce("site_id", Value(0)),
                condition=Q(scope=Scope.USER),
                name="conjunto_settings_scopedsetting_unique_user",
            ),
            UniqueConstraint(
                "namespace",
                "key",
                "group",
                Coalesce("site_id", Value(0)),
                condition=Q(scope=Scope.GROUP),
                name="conjunto_settings_scopedsetting_unique_group",
            ),
            UniqueConstraint(
                "namespace",
                "key",
                "device",
                Coalesce("site_id", Value(0)),
                condition=Q(scope=Scope.DEVICE),
                name="conjunto_settings_scopedsetting_unique_device",
            ),
            UniqueConstraint(
                "namespace",
                "key",
                "tenant",
                Coalesce("site_id", Value(0)),
                condition=Q(scope=Scope.TENANT),
                name="conjunto_settings_scopedsetting_unique_tenant",
            ),
            UniqueConstraint(
                "namespace",
                "key",
                Coalesce("site_id", Value(0)),
                condition=Q(scope=Scope.VENDOR),
                name="conjunto_settings_scopedsetting_unique_vendor",
            ),
        ]

    def __str__(self):
        scope_label = Scope(self.scope).label
        ref = self._scope_ref_display()
        lock = " [LOCKED]" if self.locked else ""
        return f"{self.namespace}.{self.key} [{scope_label}{ref}]{lock} = {self.value!r}"

    def _scope_ref_display(self) -> str:
        if self.scope == Scope.USER and self.user_id:
            return f": {self.user}"
        if self.scope == Scope.GROUP and self.group_id:
            return f": {self.group}"
        if self.scope == Scope.DEVICE and self.device_id:
            return f": device#{self.device_id}"
        if self.scope == Scope.TENANT and self.tenant_id:
            return f": {self.tenant}"
        return ""
