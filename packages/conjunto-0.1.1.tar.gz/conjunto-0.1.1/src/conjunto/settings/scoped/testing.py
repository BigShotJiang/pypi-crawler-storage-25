"""Test utilities for the scoped settings subsystem.

The registry freezes lazily at first read and is a class-level
singleton — so naive tests that register specs for one test case leak
state into the next. :func:`unfreeze_registry` is a context manager
that snapshots and restores the registry around a test block.
"""

from contextlib import contextmanager

from .registry import SettingRegistry


@contextmanager
def unfreeze_registry():
    """Snapshot the registry, unfreeze it, restore on exit.

    Usage::

        def test_foo():
            with unfreeze_registry():
                SettingRegistry.register(
                    "core", "theme", type="str", default="light", ...
                )
                # ... exercise code that reads the spec ...
            # registry state is restored here
    """
    snapshot_specs = dict(SettingRegistry._specs)
    snapshot_frozen = SettingRegistry._frozen
    SettingRegistry._specs = {}
    SettingRegistry._frozen = False
    try:
        yield SettingRegistry
    finally:
        SettingRegistry._specs = snapshot_specs
        SettingRegistry._frozen = snapshot_frozen
