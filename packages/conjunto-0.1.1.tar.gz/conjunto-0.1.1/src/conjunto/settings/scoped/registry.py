"""In-memory registry for :class:`SettingSpec` entries.

Every (namespace, key) a consumer wants to expose through the scoped
settings subsystem must be registered at startup, typically in an
app-level ``scoped_settings.py`` module that is auto-imported by
:meth:`conjunto.settings.apps.SettingsConfig.ready`.

The registry is **frozen** after the first read via
:meth:`SettingRegistry.get_spec`. Subsequent calls to
:meth:`SettingRegistry.register` raise ``RuntimeError`` so accidental
late registrations (e.g. from view code or signal handlers) are caught
loudly. Tests can temporarily lift the freeze via the
:func:`unfreeze_registry` context manager exposed from
:mod:`conjunto.settings.scoped.testing`.
"""

from dataclasses import dataclass, field
from typing import Any, Literal, Optional

from .models import Scope

SettingType = Literal["str", "int", "bool", "text", "json"]


@dataclass(frozen=True)
class SettingSpec:
    """Metadata for a registered (namespace, key) setting.

    - ``type``: hint for UI widget selection and form conversion. The
      scoped settings subsystem does NOT enforce type at the storage
      layer (values are JSONField); type is advisory.
    - ``default``: value returned by the resolver when no row matches.
    - ``writable_scopes``: set of Scope values where rows for this key
      may be written at all. Pre-flight check before insert/update.
    - ``lockable_scopes``: subset of ``writable_scopes`` where
      ``locked=True`` is permitted. E.g. a per-user shortcut key is
      writable at USER but not lockable at USER (users can't lock
      themselves).
    - ``ui_widget``: optional hint string for a custom form widget.
    """

    namespace: str
    key: str
    type: SettingType
    default: Any
    help_text: str = ""
    icon: str = ""
    writable_scopes: frozenset[Scope] = field(default_factory=frozenset)
    lockable_scopes: frozenset[Scope] = field(default_factory=frozenset)
    ui_widget: Optional[str] = None

    @property
    def dotted(self) -> str:
        return f"{self.namespace}.{self.key}"


class SettingRegistry:
    """Class-level registry of :class:`SettingSpec` entries.

    State lives in two class attributes that are mutated by
    :meth:`register` and :meth:`freeze`. This is a deliberate singleton
    — there is exactly one logical registry per Django process.
    """

    _specs: dict[tuple[str, str], SettingSpec] = {}
    _frozen: bool = False

    def __init__(self):
        raise TypeError(
            f"{type(self).__name__} is a class-level registry and should not "
            f"be instantiated."
        )

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    @classmethod
    def register(
        cls,
        namespace: str,
        key: str,
        *,
        type: SettingType,
        default: Any,
        help_text: str = "",
        icon: str = "",
        writable_scopes: frozenset[Scope] | set[Scope] | list[Scope] = (),
        lockable_scopes: frozenset[Scope] | set[Scope] | list[Scope] = (),
        ui_widget: Optional[str] = None,
    ) -> SettingSpec:
        """Register a setting spec.

        Raises:
            RuntimeError: if the registry is already frozen.
            ValueError: on duplicate registration or when
                ``lockable_scopes`` is not a subset of ``writable_scopes``.
        """
        if cls._frozen:
            raise RuntimeError(
                f"SettingRegistry is frozen; cannot register {namespace}.{key}. "
                f"Registrations must happen during AppConfig.ready()."
            )
        lookup_key = (namespace, key)
        if lookup_key in cls._specs:
            raise ValueError(
                f"Setting {namespace}.{key} is already registered."
            )
        writable = frozenset(writable_scopes)
        lockable = frozenset(lockable_scopes)
        if not lockable <= writable:
            raise ValueError(
                f"{namespace}.{key}: lockable_scopes ({lockable}) must be a "
                f"subset of writable_scopes ({writable})."
            )
        spec = SettingSpec(
            namespace=namespace,
            key=key,
            type=type,
            default=default,
            help_text=help_text,
            icon=icon,
            writable_scopes=writable,
            lockable_scopes=lockable,
            ui_widget=ui_widget,
        )
        cls._specs[lookup_key] = spec
        return spec

    # ------------------------------------------------------------------
    # Freeze / unfreeze
    # ------------------------------------------------------------------

    @classmethod
    def freeze(cls) -> None:
        """Mark the registry as frozen. Idempotent."""
        cls._frozen = True

    @classmethod
    def is_frozen(cls) -> bool:
        return cls._frozen

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    @classmethod
    def get_spec(cls, namespace: str, key: str) -> SettingSpec:
        """Return the registered spec, or raise ``KeyError``.

        Triggers :meth:`freeze` as a side effect so that any late
        registration attempts after the first read fail loudly.
        """
        if not cls._frozen:
            cls.freeze()
        try:
            return cls._specs[(namespace, key)]
        except KeyError as exc:
            raise KeyError(
                f"Scoped setting {namespace}.{key} is not registered."
            ) from exc

    @classmethod
    def all_for_namespace(cls, namespace: str) -> list[SettingSpec]:
        """Return all registered specs within ``namespace``, sorted by key."""
        return sorted(
            (spec for (ns, _), spec in cls._specs.items() if ns == namespace),
            key=lambda s: s.key,
        )

    @classmethod
    def all(cls) -> list[SettingSpec]:
        """Return every registered spec, sorted by (namespace, key)."""
        return sorted(cls._specs.values(), key=lambda s: (s.namespace, s.key))
