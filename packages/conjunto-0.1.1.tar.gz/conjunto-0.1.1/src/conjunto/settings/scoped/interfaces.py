"""GDAPS interface for pluggable settings scopes.

Each scope level in the priority chain is represented by an
:class:`IScope` plugin. Conjunto ships five built-in implementations
(Vendor, Tenant, Group, Device, User); consumers can register
additional scopes if their domain needs them (e.g. an Organization
scope between Tenant and User).

``resolve(request)`` returns the list of FK pks that the current
request matches at this scope — or ``None`` if the scope is not
applicable (e.g. anonymous user → IUserScope returns None). A single
entry of ``None`` in the returned list means "this scope applies but
has no FK reference" (the VENDOR case).
"""

from typing import Optional

from gdaps.api import Interface


class IScope(Interface):
    """Plugin interface for a scope level in the settings priority chain.

    Subclasses must set:

    - ``scope_id``: the :class:`conjunto.settings.scoped.models.Scope`
      enum value this plugin implements.
    - ``name``: stable slug.
    - ``title``: human-readable label (translatable).
    - ``icon``: Tabler icon name.
    - ``weight``: priority in the normal walk. Higher wins.

    And override:

    - :meth:`resolve` — turn a request into a list of FK refs.
    - :meth:`filter_kwargs` — ORM filter kwargs for one ref.
    - :meth:`can_edit` / :meth:`can_lock` — permission checks.
    - :meth:`ref_display` — human-readable label for a ref (UI).
    """

    __abstract__ = True
    __instantiate_plugins__ = False

    scope_id: int
    name: str
    title: str = ""
    icon: str = ""
    weight: int = 0

    @classmethod
    def resolve(cls, request) -> Optional[list[Optional[int]]]:
        """Return the list of FK pks this request matches at this scope.

        Returns:
            A list of integer pks (e.g. ``[42]`` for a single-ref scope,
            ``[3, 7, 12]`` for IGroupScope with a user in multiple groups),
            or ``[None]`` for VENDOR-style scopes with no FK reference,
            or ``None`` if the scope is not applicable to this request.
        """
        raise NotImplementedError

    @classmethod
    def filter_kwargs(cls, ref: Optional[int]) -> dict:
        """ORM filter kwargs selecting rows at this scope with the given ref.

        Default implementation returns ``{"scope": cls.scope_id}`` —
        subclasses add their FK filter (e.g. ``user_id=ref``).
        """
        return {"scope": cls.scope_id}

    @classmethod
    def can_edit(cls, request, ref: Optional[int]) -> bool:
        """Whether the current request's user may write a row at this
        scope level targeting ``ref``."""
        raise NotImplementedError

    @classmethod
    def can_lock(cls, request, ref: Optional[int]) -> bool:
        """Whether the current request's user may set ``locked=True`` at
        this scope level. Defaults to :meth:`can_edit`."""
        return cls.can_edit(request, ref)

    @classmethod
    def ref_display(cls, ref: Optional[int]) -> str:
        """Human-readable label for a ref, for UI display."""
        return str(ref) if ref is not None else ""
