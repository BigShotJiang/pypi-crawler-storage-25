"""Effective-value resolver for scoped settings.

Given ``(namespace, key, request)``, compute the value that wins the
priority overlay across all scope levels, obeying:

1. **Priority chain** (higher wins in the normal walk):
   ``USER > DEVICE > GROUP > TENANT > VENDOR``.

2. **Locks are floors** (``locked=True`` pins a value against higher
   scopes). The walk runs **lowest-to-highest**, so the first lock
   encountered wins — equivalently, the **lowest-priority** lock wins
   when multiple locks exist. A VENDOR lock is the ultimate authority;
   a TENANT lock blocks GROUP/DEVICE/USER but yields to a VENDOR lock.

3. **Site filter** is orthogonal to the scope chain. Queries match
   ``site = request.site OR site IS NULL``. Within a tier, a
   site-specific row beats a site-null row at the same scope ref.

4. **IGroupScope tie-breaks** when the user is in multiple groups:
   - Among locked rows, the **lowest-pk** group wins.
   - Among unlocked rows, the **highest-pk** group wins.

5. **Missing spec is strict**: ``SettingRegistry.get_spec`` raises
   ``KeyError``. This is intentional — a stale DB row without a
   registered spec is a code/data drift and should be visible.
"""

from collections import defaultdict
from typing import Any, Optional

from django.db.models import Q

from .models import Scope, ScopedSetting
from .registry import SettingRegistry
from .scopes import IDeviceScope, IGroupScope, ITenantScope, IUserScope, IVendorScope

# Walk order: lowest-priority first, so that locks short-circuit at
# the lowest level and the lowest-priority lock wins.
_SCOPES_LOWEST_FIRST = [IVendorScope, ITenantScope, IGroupScope, IDeviceScope, IUserScope]


_MISSING = object()


def get_effective(namespace: str, key: str, request) -> Any:
    """Return the effective value of ``(namespace, key)`` for the request.

    Raises:
        KeyError: if the key is not registered in
            :class:`SettingRegistry` (strict mode).
    """
    spec = SettingRegistry.get_spec(namespace, key)

    current_site = getattr(request, "site", None)
    if current_site is not None and getattr(current_site, "pk", None) is None:
        current_site = None

    rows = ScopedSetting.objects.filter(namespace=namespace, key=key)
    if current_site is not None:
        rows = rows.filter(Q(site=current_site) | Q(site__isnull=True))
    else:
        rows = rows.filter(site__isnull=True)

    # Bucket rows by scope for per-tier lookup. Materialize the queryset
    # exactly once.
    by_scope: dict[int, list[ScopedSetting]] = defaultdict(list)
    for row in rows:
        by_scope[row.scope].append(row)

    resolved: Any = _MISSING
    for scope_cls in _SCOPES_LOWEST_FIRST:
        refs = scope_cls.resolve(request)
        if refs is None:
            continue
        tier_rows = by_scope.get(scope_cls.scope_id, [])
        if not tier_rows:
            continue
        winner = _pick_winner(tier_rows, scope_cls, refs, current_site)
        if winner is None:
            continue
        if winner.locked:
            return winner.value  # lowest-priority lock short-circuits
        resolved = winner.value

    if resolved is _MISSING:
        return spec.default
    return resolved


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _row_fk_for(scope_id: int, row: ScopedSetting) -> Optional[int]:
    """Return the FK pk this row uses for the given scope, or None."""
    if scope_id == Scope.VENDOR:
        return None
    if scope_id == Scope.USER:
        return row.user_id
    if scope_id == Scope.GROUP:
        return row.group_id
    if scope_id == Scope.DEVICE:
        return row.device_id
    if scope_id == Scope.TENANT:
        return row.tenant_id
    return None


def _site_id(row: ScopedSetting) -> Optional[int]:
    return row.site_id


def _pick_winner(
    tier_rows: list[ScopedSetting],
    scope_cls,
    refs: list,
    current_site,
) -> Optional[ScopedSetting]:
    """Pick the winning row for one tier, applying site + group rules.

    For each ``ref`` in ``refs`` we collect matching rows and prefer a
    site-specific row over a site-null row. Then we apply the tier's
    tie-break rule:

    - VENDOR / TENANT / DEVICE / USER tiers: at most one ref → at most
      one candidate after site tie-break → that row is the winner.
    - GROUP tier: one candidate per group the user belongs to. Within
      locked candidates, lowest-pk group wins; within unlocked, highest.
    """
    current_site_id = current_site.pk if current_site is not None else None

    # Per ref, pick the site-specific row if present else the site-null one.
    per_ref_winners: list[tuple[Optional[int], ScopedSetting]] = []
    for ref in refs:
        matching = [r for r in tier_rows if _row_fk_for(scope_cls.scope_id, r) == ref]
        if not matching:
            continue
        site_specific = [r for r in matching if _site_id(r) == current_site_id and current_site_id is not None]
        if site_specific:
            per_ref_winners.append((ref, site_specific[0]))
        else:
            site_null = [r for r in matching if _site_id(r) is None]
            if site_null:
                per_ref_winners.append((ref, site_null[0]))

    if not per_ref_winners:
        return None

    if scope_cls.scope_id != Scope.GROUP:
        # Single-ref tiers: there's only one candidate.
        return per_ref_winners[0][1]

    # GROUP tie-break: prefer locked rows (lowest-pk group wins among
    # them), else highest-pk group among unlocked.
    locked = [(ref, row) for ref, row in per_ref_winners if row.locked]
    if locked:
        locked.sort(key=lambda pair: pair[0])  # lowest pk first
        return locked[0][1]
    per_ref_winners.sort(key=lambda pair: pair[0])  # lowest to highest
    return per_ref_winners[-1][1]
