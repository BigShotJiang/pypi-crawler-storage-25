"""Plugin interfaces for the conjunto settings page.

Design notes
------------

The interfaces are deliberately flat, mirroring the `IMenuItem` pattern in
`conjunto/menu/__init__.py`:

- :class:`ISettingsGroup` — top-level category ("User", "Tenant", …).
- :class:`ISettingsSection` — second-level entry under a group; selecting
  it loads its forms on the right pane.
- :class:`ISettingsForm` — a single form subsection rendered on the right
  pane. Each form plugin self-declares its target section via the
  ``section`` attribute, so there is no need for a per-section sub-interface.
"""

from typing import Optional

from conjunto.api.interfaces import IElement, IElementGroup


class ISettingsGroup(IElementGroup):
    """Top-level category on the settings page left rail."""


class ISettingsSection(IElement):
    """Second-level entry under a :class:`ISettingsGroup`.

    Selecting a section swaps the right pane with the forms targeting it.

    Attributes:
        name: Unique slug used in the ``?section=<name>`` query parameter.
        group: An :class:`ISettingsGroup` subclass — the category this
            section belongs to.
        title, icon, weight: Inherited from :class:`IElement`.
        permission_required: Optional Django permission gating visibility.
    """

    __sort_attribute__ = "weight"

    group: type[ISettingsGroup]
    permission_required: Optional[str] = None

    @classmethod
    def has_permission(cls, request) -> bool:
        """Whether the given request's user may see this section."""
        if not cls.permission_required:
            return True
        return request.user.has_perm(cls.permission_required)


class ISettingsForm(IElement):
    """A form subsection rendered on the right pane of a section.

    Each plugin self-declares its target section via the ``section``
    attribute (class reference preferred; a slug string also works — same
    dual lookup as ``IMenuItem.parent``).

    Subclasses typically set ``form_class`` and optionally override
    :meth:`get_initial`, :meth:`get_instance`, and :meth:`save`.

    To render a custom subsection layout instead of the default form
    rendering, set ``template`` to a template path (e.g.
    ``"myapp/settings/my_subsection.html"`` or a partial reference like
    ``"myapp/settings/page.html#my_subsection"``). The template receives
    the same context as the default subsection partial (``plugin`` and,
    if a form class is configured, ``form``).
    """

    __sort_attribute__ = "weight"

    # Class reference or slug string of an ISettingsSection.
    section: type[ISettingsSection] | str

    # Django Form or ModelForm class. Optional when ``template`` is set.
    form_class = None

    # Optional custom template (or partial reference) to render this
    # subsection instead of the default form layout.
    template: Optional[str] = None

    def get_form_class(self):
        return self.form_class

    def get_template(self) -> Optional[str]:
        return self.template

    def get_initial(self, request) -> dict:
        return {}

    def get_instance(self, request):
        """Return a model instance for ModelForms, or None."""
        return None

    def save(self, form, request) -> None:
        """Persist the validated form. Default: ``form.save()``."""
        form.save()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def resolve_section(ref) -> Optional[type[ISettingsSection]]:
    """Resolve a section reference (class or slug string) to the class.

    Mirrors the dual-lookup pattern used by ``IMenuItem.parent``.
    """
    if ref is None:
        return None
    if isinstance(ref, str):
        return find_section_by_name(ref)
    return ref


def find_section_by_name(name: str) -> Optional[type[ISettingsSection]]:
    """Return the enabled :class:`ISettingsSection` plugin with the given
    ``name``, or ``None``.

    (``Interface.get`` from GDAPS looks up interfaces, not implementations,
    so we iterate manually.)
    """
    for section_cls in ISettingsSection.enabled_plugins():
        if getattr(section_cls, "name", None) == name:
            return section_cls
    return None


def find_form_by_name(name: str) -> Optional[type[ISettingsForm]]:
    """Return the enabled :class:`ISettingsForm` plugin with the given
    ``name``, or ``None``."""
    for form_cls in ISettingsForm.enabled_plugins():
        if getattr(form_cls, "name", None) == name:
            return form_cls
    return None
