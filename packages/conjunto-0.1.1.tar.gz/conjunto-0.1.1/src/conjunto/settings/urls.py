from django.urls import path

from .views import SettingsFormView, SettingsView

# Required by GDAPS ``PluginManager.urlpatterns()`` — this module is
# auto-mounted at ``/settings/`` by the consuming project's root
# ``urls.py`` when it calls ``PluginManager.urlpatterns()``.
app_name = "settings"

urlpatterns = [
    path("", SettingsView.as_view(), name="index"),
    path(
        "form/<slug:form_name>/",
        SettingsFormView.as_view(),
        name="form",
    ),
]
