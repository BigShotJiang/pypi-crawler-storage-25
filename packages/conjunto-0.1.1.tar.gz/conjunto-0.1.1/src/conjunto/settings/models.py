# Re-export concrete models from the scoped subpackage so Django's
# conjunto_settings AppConfig discovers them.
from .scoped.models import Device, Scope, ScopedSetting  # noqa: F401
