"""Django admin registrations for the scoped settings subsystem."""

from django.contrib import admin

from .scoped.models import Device, Scope, ScopedSetting


@admin.register(ScopedSetting)
class ScopedSettingAdmin(admin.ModelAdmin):
    list_display = (
        "namespace",
        "key",
        "scope_label",
        "ref_display",
        "locked",
        "value",
        "site",
        "updated_at",
    )
    list_filter = ("namespace", "scope", "locked", "site")
    search_fields = ("namespace", "key")
    readonly_fields = ("created_at", "updated_at")
    fieldsets = (
        (None, {"fields": ("namespace", "key", "value", "locked")}),
        ("Scope", {"fields": ("scope", "user", "group", "device", "tenant", "site")}),
        ("Audit", {"fields": ("created_at", "updated_at")}),
    )
    # raw_id_fields (not autocomplete_fields) so conjunto does not impose
    # a hidden requirement that every consumer register an admin with
    # `search_fields` for their AUTH_USER_MODEL / tenant model / etc.
    raw_id_fields = ("user", "group", "device", "tenant", "site")

    @admin.display(description="Scope", ordering="scope")
    def scope_label(self, obj: ScopedSetting) -> str:
        try:
            return Scope(obj.scope).label
        except ValueError:
            return str(obj.scope)

    @admin.display(description="Ref")
    def ref_display(self, obj: ScopedSetting) -> str:
        # Show whichever FK is set for this scope.
        if obj.scope == Scope.USER and obj.user_id:
            return str(obj.user)
        if obj.scope == Scope.GROUP and obj.group_id:
            return obj.group.name
        if obj.scope == Scope.DEVICE and obj.device_id:
            return f"device#{obj.device_id}"
        if obj.scope == Scope.TENANT and obj.tenant_id:
            return str(obj.tenant)
        return ""


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = ("cookie_id", "user", "name", "last_seen", "first_seen")
    list_filter = ("user",)
    search_fields = ("name", "user__username", "user_agent")
    readonly_fields = ("cookie_id", "first_seen", "last_seen")
    fieldsets = (
        (None, {"fields": ("cookie_id", "user", "name")}),
        ("Client info", {"fields": ("user_agent",)}),
        ("Timestamps", {"fields": ("first_seen", "last_seen")}),
    )
