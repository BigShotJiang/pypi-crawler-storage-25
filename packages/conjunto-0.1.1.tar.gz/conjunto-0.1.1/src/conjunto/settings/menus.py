"""Built-in settings plugins.

This module holds the default ``User → Profile → Name`` plugin stack that
ships with conjunto. Follows the project convention that plugin
implementations live in ``menus.py`` (same as the menu system).
"""

from django import forms
from django.contrib.auth import get_user_model
from django.utils.translation import gettext_lazy as _

from .interfaces import ISettingsForm, ISettingsGroup, ISettingsSection


# ---------------------------------------------------------------------------
# Groups
# ---------------------------------------------------------------------------


class UserGroup(ISettingsGroup):
    """User-scoped settings (profile, account, notifications, …)."""

    name = "user"
    title = _("User")
    weight = 0


# ---------------------------------------------------------------------------
# Sections
# ---------------------------------------------------------------------------


class UserProfileSection(ISettingsSection):
    """The default "Profile" section under the User group."""

    name = "profile"
    group = UserGroup
    title = _("Profile")
    icon = "user"
    weight = 0


# ---------------------------------------------------------------------------
# Forms
# ---------------------------------------------------------------------------


class _UserNameForm(forms.ModelForm):
    """Edits the authenticated user's first and last name."""

    class Meta:
        model = get_user_model()
        fields = ["first_name", "last_name"]


class UserNameFormPlugin(ISettingsForm):
    """Name subsection under ``User → Profile``."""

    section = UserProfileSection
    name = "user_name"
    title = _("Name")
    weight = 0
    form_class = _UserNameForm

    def get_instance(self, request):
        return request.user
