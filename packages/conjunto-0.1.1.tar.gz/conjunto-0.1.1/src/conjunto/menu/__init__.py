import logging
import re
import warnings
from typing import Iterable, Optional, Union, Callable

from django.http import HttpRequest
from django.utils.text import slugify
from gdaps.api import Interface

logger = logging.getLogger(__name__)


class MenuItemInterfaceMixin:
    """A mixin that provides common functionality for menu items or action buttons.

    This class is meant to be used as base class for `Interface`s, not implementations.

    Menu items are instantiated once per request and store the request context internally
    to allow template access to dynamic properties without parameter passing.

    Attributes:
        title: The (translatable) title that should be displayed in the menu.
            Can be a string or a callable that accepts (request) and returns string.
        menu: The menu name where this MenuItem should be rendered. Can be any string.
            This menuitem is then found in templates under the `menu.<this-menu-attr>`
            menu. If you don't specify a menu, "main" is used.
        weight: The "weight" of the menu. The higher the weight, the more it "sinks"
            down in the menu. Default: 0
        icon: The (Bootstrap) icon name to display, if the menu shows icons.
            Can be a string or a callable that accepts (request) and returns string.
        slug: The slug (machine name) of the item, used for css classes etc.
            If not provided, it is auto-generated from the title.
        parent: The parent menu item. Can be either:
            - A slug string (e.g. "settings") to reference parent by slug
            - An IMenuItem class to reference parent directly
            - None (default) for top-level items
            This creates a tree hierarchy that supports unlimited nesting depth.
        permissions_required: List of permission strings necessary to view this menu item.
            Note: This only controls menu visibility. View permissions must be
            checked separately in the view itself.
    """

    weight: int = 0
    parent: Optional[Union[str, type["MenuItemInterfaceMixin"]]] = None
    permissions_required: Optional[list[str]] = None

    # dynamically overridable attributes (by get_* methods)
    title: str | Callable[[HttpRequest], str] = ""
    slug: str = ""
    icon: str | Callable[[HttpRequest], str] = ""
    check: Optional[Callable[[HttpRequest], bool]] = None

    def __init__(self, request: Optional[HttpRequest] = None, *args, **kwargs):
        """Menu item is initialized during Menu construction.

        Args:
            request: The HTTP request object for this menu item's context.
                Optional; some operations (visibility checks, dynamic attributes)
                require a request to function correctly.
        """
        self._children: list[MenuItemInterfaceMixin] = []
        self._parent_item: Optional[MenuItemInterfaceMixin] = None
        self._request: Optional[HttpRequest] = request

    def get_title(self) -> str:
        """Returns the title of this menu item."""
        if callable(self.__class__.title):
            return self.__class__.title(self.request)
        return self.title

    def get_icon(self) -> str:
        """The icon name for this menu item."""
        if callable(self.__class__.icon):
            return self.__class__.icon(self.request)
        return self.icon

    @property
    def disabled(self) -> bool:
        return False

    def _is_visible(self) -> bool:
        """Internal method to check if the item should be visible.

        An item is normally visible, and if any of the checks fail, it is not.

        Returns:
            bool: True if item should be visible, False otherwise
        """
        # check permissions
        perms = self.permissions_required
        if perms:
            if isinstance(perms, str):
                perms = [perms]
            if not self._request or not self._request.user.has_perms(perms):
                return False

        if callable(self.__class__.check):
            if not self._request or not self.__class__.check(self._request):
                return False

        return not self.disabled

    @property
    def request(self) -> Optional[HttpRequest]:
        """Get the stored request context."""
        return self._request

    @request.setter
    def request(self, value: Optional[HttpRequest]) -> None:
        self._request = value

    def get_slug(self) -> str:
        # instance override
        if self.slug:
            return self.slug

        # fallback
        title = self.get_title()
        return slugify(title) if title else ""

    @property
    def visible(self) -> bool:
        """Check if this menu item should be visible.

        Returns:
            bool: True if item should be visible, False otherwise
        """
        return self._is_visible()

    @property
    def full_path(self) -> str:
        """Returns the full hierarchical path of this menu item.

        For top-level items, returns just the slug.
        For nested items, returns <parent path>.<slug> (e.g., "settings.users").
        This provides a unique identifier for items in the hierarchy.

        Returns:
            str: The full path using "." as separator
        """
        if self._parent_item:
            parent_path = self._parent_item.full_path
            return f"{parent_path}.{self.get_slug()}"
        return self.get_slug()

    @property
    def menu(self) -> Optional[str]:
        if "menu" in self.__class__.__dict__:
            return self.__class__.__dict__["menu"]
        parent = self.get_parent()
        if parent:
            return parent.menu
        return None

    def has_children(self) -> bool:
        """Returns `True` if this menu item has children, `False` otherwise."""
        return len(self._children) > 0

    def has_parent(self) -> bool:
        """Returns `True` if this menu item has a parent, `False` otherwise."""
        return self._parent_item is not None

    def get_parent(self) -> Optional["MenuItemInterfaceMixin"]:
        """Returns the parent menu item, or None if this is a top-level item."""
        return self._parent_item

    def children(self) -> Iterable["MenuItemInterfaceMixin"]:
        """Returns an iterable of all children of this menu item.

        Yields:
            MenuItemInterfaceMixin: Child menu items
        """
        for item in self._children:
            yield item

    def _underline_to_hyphen(self, attr: str) -> str:
        return attr.replace("_", "-")

    @classmethod
    def filter(cls: "MenuItemInterfaceMixin", menu_name: str):
        """Filter the menu items by the 'menu' key name."""
        return filter(lambda item: item.menu == menu_name, cls.enabled_plugins())


class InlineAction:
    title: str = ""
    icon: str = ""
    url: str = ""


class IMenuItem(MenuItemInterfaceMixin, Interface):
    """An extendable and versatile MenuItem Interface

    You can use IMenuItem for creating menu items in a named menu:
    ```python
    class AddUserAction(IMenuItem)
        menu = "page_actions"
        title = _("Add user")
        url = reverse_lazy("user:delete")  # or "users/delete"
        icon = "user-delete"
    ```

    You can then use the menu in your template:
    ```django
    <ul class="list-inline">
    {% for item in menus.page_actions %}
        <li class="list-inline-item">
            <a href="{{ item.url }}"{% if item.selected %} class="active"{% endif %}>
                <i class="ti ti-{{ item.icon }} me-2"></i>
                {{ item.title }}
            </a>
        </li>
    {% endfor %}
    </ul>
    ```

    Attributes:
        url: the URL to call when this menu item is clicked.
        separator_{before|after}: if `True`, this menu item shows a separator AFTER it.
        badge: a callable that returns a string to be displayed in a badge.
        badge_class (optional): the CSS classes that are added to the badge.
        exact_url: if `True`, the `active` class will only get added on the menu item
            if the browser path exactly matches the MenuItem URL.
            If `False` (default), it also is active when child items are selected.
        collapsed: If `True`, this menu item is collapsed by default.
    """

    __instantiate_plugins__ = False
    url: str = ""
    separator_before: bool = False
    separator_after: bool = False
    exact_url: bool = False
    collapsed: bool = True
    inline_action: type[InlineAction] | None = None
    _attrs: dict = {}

    def __init_subclass__(cls, **kwargs):
        if not cls.title:
            raise ValueError(f"MenuItem class '{cls.__name__}' must define a title.")
        if "menu" in cls.__dict__ and "parent" in cls.__dict__:
            raise ValueError(
                f"MenuItem class '{cls.__name__}': 'menu' and 'parent' are mutually "
                f"exclusive — menu is determined by the parent chain."
            )
        super().__init_subclass__(**kwargs)

    def selected(self) -> bool:
        """Check if current URL matches this item.

        Can be called as item.selected() or accessed as item.selected in templates.
        """
        if self._request is None:
            return False

        url = str(self.url)
        # if item has children, it's selected if any of its children are selected
        if self.has_children():
            for child in self.children():
                if child.selected():
                    return True

        if not url:
            return False

        if self.exact_url:
            # Match URL exactly
            return bool(re.match(f"{re.escape(url)}$", self._request.path))
        else:
            # Match URL as prefix, but only full path components
            return bool(re.match(f"{re.escape(url)}(/|$)", self._request.path))


class Menus:
    """Represents named menus during a request.

    Its attributes are menus that are found from all `IMenuItem` classes throughout
    the application.

    The `Menus` object is automatically constructed by the ConjuntoMiddleware for
    each request as lazy object and available as `request.menus`.

    Additionally, Django templates can access `{% menus.<name> %}` which is a list of
    ``MenuItem``s with their matching `menu` name attribute:

    ```django
    <ul>
    {% for item in menus.user %}
        <li><a href="{{ item.url }}">{{ item.title }}</a></li>
    {% endfor %}
    </ul>
    ```
    """

    def __init__(self, request: HttpRequest):
        self.request = request
        self._items: dict[str, list[MenuItemInterfaceMixin]] = {}
        self._all_items: dict[type, MenuItemInterfaceMixin] = {}
        # First pass: Instantiate all menu items and index them by class
        for item_class in IMenuItem.enabled_plugins():
            item = item_class(request=self.request)
            self._all_items[item_class] = item

        # Second pass: Build parent-child relationships
        for item_class, item in self._all_items.items():
            parent_ref = getattr(item_class, "parent", None)

            if parent_ref is not None:
                # Resolve parent reference
                parent_item = None
                if isinstance(parent_ref, type):
                    # Parent specified by class - direct lookup
                    parent_item = self._all_items.get(parent_ref)
                elif isinstance(parent_ref, str):
                    # Parent specified by slug string - scan for matching slug
                    for potential_parent in self._all_items.values():
                        if potential_parent.get_slug() == parent_ref:
                            parent_item = potential_parent
                            break
                    else:
                        # TODO: better ignore the item?
                        # item.visible = False
                        warnings.warn(
                            f"MenuItem '{item.__class__.__name__}' (slug='{item.slug}') references "
                            f"parent '{parent_ref}' which was not found. "
                            f"This menu item will not appear in any menu.",
                            stacklevel=2,
                        )

                if parent_item is not None:
                    item._parent_item = parent_item
                    parent_item._children.append(item)

        # Third pass: Sort children and build menu structure (only top-level items)
        for item in self._all_items.values():
            # Sort children by weight
            if item._children:
                item._children.sort(key=lambda child: child.weight)

            # Only add top-level items (no parent) to the menu structure
            if not item.has_parent():
                menu_name = item.menu
                if menu_name is None:
                    continue
                if menu_name not in self._items:
                    self._items[menu_name] = []
                self._items[menu_name].append(item)

        # Sort top-level items by weight
        for menu_name in self._items:
            self._items[menu_name].sort(key=lambda x: x.weight)

    def __getitem__(self, name) -> list[MenuItemInterfaceMixin]:
        """Returns filtered and validated menu items for the given menu name."""
        return [item for item in self._items.get(name, []) if item.visible]
