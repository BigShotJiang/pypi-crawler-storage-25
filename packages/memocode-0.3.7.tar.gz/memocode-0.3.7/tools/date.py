"""
Built-in tool: date_calc
Convert relative date expressions to absolute YYYY-MM-DD strings.
Call this BEFORE memory_search when the user asks about time-relative events.
"""
import re
from datetime import date, timedelta
from .registry import Tool, ToolSchema


def _date_calc(expression: str) -> str:
    """
    Convert a relative date expression to an absolute date (YYYY-MM-DD).

    Supports Chinese and English expressions such as:
      今天, 昨天, 前天, 3天前, 上周, 两周前, 上个月,
      today, yesterday, 2 days ago, last week, last month, etc.
    """
    today = date.today()
    expr = expression.strip().lower()

    # Exact matches — Chinese
    if expr in ("今天", "today"):
        return str(today)
    if expr in ("昨天", "yesterday"):
        return str(today - timedelta(days=1))
    if expr in ("前天", "the day before yesterday"):
        return str(today - timedelta(days=2))
    if expr in ("明天", "tomorrow"):
        return str(today + timedelta(days=1))

    # N天前 / N days ago
    m = re.match(r"(\d+)\s*天前", expr)
    if not m:
        m = re.match(r"(\d+)\s*days?\s*ago", expr)
    if m:
        return str(today - timedelta(days=int(m.group(1))))

    # N天后 / in N days
    m = re.match(r"(\d+)\s*天后", expr)
    if not m:
        m = re.match(r"in\s*(\d+)\s*days?", expr)
    if m:
        return str(today + timedelta(days=int(m.group(1))))

    # 上周 / last week  (Monday of last week)
    if expr in ("上周", "上个星期", "last week"):
        monday = today - timedelta(days=today.weekday() + 7)
        return str(monday)

    # 这周 / this week (Monday)
    if expr in ("这周", "本周", "this week"):
        monday = today - timedelta(days=today.weekday())
        return str(monday)

    # N周前 / N weeks ago
    m = re.match(r"(\d+)\s*周前", expr)
    if not m:
        m = re.match(r"(\d+)\s*weeks?\s*ago", expr)
    if m:
        return str(today - timedelta(weeks=int(m.group(1))))

    # 上个月 / last month (1st of last month)
    if expr in ("上个月", "上月", "last month"):
        first = today.replace(day=1)
        last_month = first - timedelta(days=1)
        return str(last_month.replace(day=1))

    # 这个月 / this month
    if expr in ("这个月", "本月", "this month"):
        return str(today.replace(day=1))

    # N个月前 / N months ago (approximate, 30 days each)
    m = re.match(r"(\d+)\s*个?月前", expr)
    if not m:
        m = re.match(r"(\d+)\s*months?\s*ago", expr)
    if m:
        return str(today - timedelta(days=int(m.group(1)) * 30))

    return f"[date_calc] Unrecognized expression: {expression!r}. Today is {today}."


DATE_CALC_TOOL = Tool(
    schema=ToolSchema(
        name="date_calc",
        description=(
            "Convert a relative date expression into an absolute YYYY-MM-DD date. "
            "ALWAYS call this first when the user asks about something that happened on a relative date "
            "(e.g. '昨天', '前天', '3天前', 'last week', 'yesterday'). "
            "Use the returned absolute date as the time filter in your memory_search query.\n"
            "将相对日期表达式转换为 YYYY-MM-DD 绝对日期。"
            "当用户提到相对时间（如昨天、前天、3天前）时，必须先调用此工具，"
            "然后用返回的绝对日期作为 memory_search 的时间过滤条件。"
        ),
        parameters={
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": (
                        "The relative date expression to convert. "
                        "Examples: '昨天', '前天', '3天前', '上周', 'yesterday', '2 days ago', 'last week'"
                    ),
                }
            },
            "required": ["expression"],
        },
    ),
    fn=_date_calc,
)
