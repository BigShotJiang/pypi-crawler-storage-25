"""
Brain: control layer entry point.
Agentic tool-use loop — LLM decides when/which tools to call.
"""
from __future__ import annotations
import sys
import os
import json
import threading
import time

# Insert paths first so control/chatmem/ (bundled) takes priority
_ROOT = os.path.dirname(os.path.dirname(__file__))
_CONTROL = os.path.dirname(__file__)
_DATA_DIR = os.path.expanduser("~/.mcode")
sys.path.insert(0, _ROOT)
sys.path.insert(0, _CONTROL)

from prompt_toolkit import prompt as _pt_prompt
from chatmem import ContextManager, ContextConfig
from .llm import make_adapter, ToolCall
from .planner import Task  # Task dataclass used for safety interface
from .audit import AuditLog
from .project_manager import ProjectManager
from .fmt import p_dim, p_info, p_warn, p_ok, p_err, dim, cyan, yellow, green, red
from tools.registry import ToolRegistry
from tools.shell import SHELL_TOOL
from tools.file import FILE_READ_TOOL, FILE_WRITE_TOOL, FILE_EDIT_TOOL, GLOB_TOOL, GREP_TOOL
from tools.web import WEB_FETCH_TOOL
from tools.date import DATE_CALC_TOOL
from tools.loader import load_external_tools
import safety.safety as _safety


_CODE_BLOCK_RE = __import__("re").compile(r"```[^\n]*\n(.*?)```", __import__("re").DOTALL)
_THINK_RE = __import__("re").compile(r"<think>.*?</think>", __import__("re").DOTALL)
_MAX_CODE_LINES = 20


def _content_to_text(content) -> str:
    """Extract plain text from a message content value (str or list of content blocks)."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(p.get("text", "") for p in content if p.get("type") == "text")
    return ""


def _truncate_code_blocks(text: str) -> str:
    """Replace code blocks exceeding _MAX_CODE_LINES with a truncation notice."""
    def _replace(m):
        lang_line = m.group(0).split("\n", 1)[0]  # e.g. ```python
        body = m.group(1)
        lines = body.splitlines()
        if len(lines) <= _MAX_CODE_LINES:
            return m.group(0)
        return (
            f"{lang_line}\n"
            + "\n".join(lines[:_MAX_CODE_LINES])
            + f"\n```\n> ⚠️  代码已截断（共 {len(lines)} 行）。请让我用 file_write 写入文件。"
        )
    return _CODE_BLOCK_RE.sub(_replace, text)


def _tool_hint(name: str, args: dict) -> str:
    """Return a one-line dim hint shown after the tool name."""
    if name == "shell_exec":
        cmd = args.get("command", "")
        first = next((l for l in cmd.splitlines() if l.strip()), cmd)
        return dim(f"$ {first}")
    if name in ("file_read", "file_write", "file_edit"):
        return dim(args.get("path", ""))
    if name == "grep":
        pattern = args.get("pattern", "")
        path = args.get("path", "") or args.get("directory", "")
        return dim(f'"{pattern}"' + (f"  {path}" if path else ""))
    if name == "glob":
        return dim(args.get("pattern", ""))
    if name == "web_fetch":
        return dim(args.get("url", ""))
    if name == "memory_search":
        return dim(args.get("query", ""))
    return ""


def _print_tool_header(call: ToolCall):
    """Print tool call header + full multiline command if applicable."""
    hint = _tool_hint(call.name, call.args)
    print(cyan(f"▶  {call.name}") + (f"  {hint}" if hint else ""))
    if call.name == "shell_exec":
        lines = call.args.get("command", "").splitlines()
        if len(lines) > 1:
            for extra in lines[1:]:
                print(dim(f"   {extra}"))


def _print_tool_header_simple(name: str, args: dict):
    """Print tool call header for parsed tool calls (non-ToolCall object)."""
    hint = _tool_hint(name, args)
    print(cyan(f"▶  {name}") + (f"  {hint}" if hint else ""))
    if name == "shell_exec":
        lines = args.get("command", "").splitlines()
        if len(lines) > 1:
            for extra in lines[1:]:
                print(dim(f"   {extra}"))




_PROJECT_MEMORY_JSON = os.path.join(_DATA_DIR, "project_memory.json")

_DEFAULT_PROJECT_MEMORY = {
    "dimensions": {
        "architecture": {"label": "Tech stack, modules, structure",             "stability": 40.0},
        "decisions":    {"label": "Confirmed design decisions and rationale",   "stability": 35.0},
        "conventions":  {"label": "Naming, interface, format conventions",      "stability": 35.0},
        "context":      {"label": "Project background, goals, constraints",     "stability": 30.0},
        "progress":     {"label": "Current phase, pending key tasks",           "stability": 20.0},
        "completed":    {"label": "Completed tasks and milestones",             "stability": 25.0},
    },
}

def _build_project_judge_prompt(dimensions: dict) -> str:
    dim_lines = "\n".join(f"- {name}: {cfg.label}" for name, cfg in dimensions.items())
    dim_names = ", ".join(f'"{name}"' for name in dimensions)
    return f"""You are a project memory editor. Review the conversation and update the project's knowledge base.

Project memory dimensions:
{dim_lines}

Existing project memory:
{{existing}}

New conversation:
{{text}}

Rules:
- One entry per dimension. Key must equal the dimension name (e.g. key="decisions").
- For each dimension, choose one action:
  SKIP       — no new project-relevant information for this dimension.
  SUPPLEMENT — new info extends existing (merge into one updated value).
  UPDATE     — existing info is clearly superseded or corrected.
  DELETE     — the entire dimension entry is explicitly invalidated with nothing to replace it
               (e.g. "we're dropping the X feature entirely", "forget everything about the old auth system").
               Use DELETE only when UPDATE with a replacement value is not possible.
- Special rules by dimension:
  completed: always SUPPLEMENT (append new completions, never erase old ones). Never DELETE.
  progress:  UPDATE freely when the current phase or pending tasks change.
             ONLY record what the user explicitly stated. Do NOT infer, extrapolate,
             or add typical/expected follow-up tasks not mentioned in the conversation.
  decisions: SUPPLEMENT by default; UPDATE only if the user makes an explicit statement reversing a prior decision
             (e.g. "we're switching from X to Y", "decided to drop X"). Do NOT update based on the assistant
             discussing alternatives, or the user asking hypothetical questions about other options.
  architecture/conventions: SUPPLEMENT by default; UPDATE on explicit refactor or migration.
- Return ONLY entries that changed. Omit SKIPped ones.
- Exclude: user personal preferences, one-time questions, reasoning processes.
- Never fabricate or infer information not present in the conversation.
- VALUE FORMAT RULES (critical for later retrieval):
  * Rejected/abandoned options: write "abandoned X — reason" or "rejected X: reason" inline.
    e.g. "Use JWT HS256. Rejected RS256: performance. Rejected Redis sessions: deployment complexity."
  * Reversed decisions: write "changed from X to Y — reason" inline.
    e.g. "Port: 8080 (changed from 3000 — conflicts with existing service)."
  * Active choices: state plainly without hedging.
  These markers must appear in the value text itself so retrieval can surface them directly.

Return a JSON array (empty if nothing changed):
[{{"key": "<dimension_name>", "value": "<merged or new value>", "dimension": "<dimension_name>", "action": "supplement|update|delete"}}]
Dimension name must be one of: {dim_names}

Output JSON only:"""


def _build_project_judge_prompt_zh(dimensions: dict) -> str:
    dim_lines = "\n".join(f"- {name}: {cfg.label}" for name, cfg in dimensions.items())
    dim_names = ", ".join(f'"{name}"' for name in dimensions)
    return f"""你是一个项目记忆编辑器。审查对话内容，更新项目知识库。

项目记忆维度：
{dim_lines}

当前项目记忆：
{{existing}}

新对话：
{{text}}

规则：
- 每个维度只有一条记录，key 等于维度名（如 key="decisions"）。
- 对每个维度，选择以下操作之一：
  跳过 — 该维度没有新的项目相关信息。
  补充 — 新信息扩展了已有内容（合并为一个更新后的 value）。
  修正 — 已有信息被明确推翻或替换。
  删除 — 整个维度条目被明确作废且无替代内容
         （如"我们整个X功能都不做了"、"忘掉旧认证系统的一切"）。
         仅在无法用修正+新值替代时才使用删除。
- 各维度特殊规则：
  completed：始终补充（追加新完成内容，不删除旧记录）。不可删除。
  progress：当前阶段或待办任务变化时，直接修正。
            只记录用户明确说出的内容，严禁推断、外推或添加"典型后续任务"。
            用户未提及的待办事项一律不写。
  decisions：默认补充；仅当用户明确陈述推翻先前决策时才修正
             （如"我们从X换成Y了"、"决定放弃X"）。不得因为
             AI 讨论替代方案、或用户询问假设性问题而修正。
  architecture/conventions：默认补充；仅在明确重构或迁移时修正。
- 只返回发生变化的条目，跳过的不返回。
- 不包括：用户个人偏好、一次性问题、推理过程。
- 严禁捏造或推断对话中未出现的信息。
- VALUE 格式要求（影响后续检索质量，必须遵守）：
  * 已放弃/拒绝的方案：在 value 文字中直接写明"放弃X——原因"或"拒绝X：原因"。
    例："使用 JWT HS256。放弃 RS256——性能问题。放弃 Redis 会话——部署复杂度。"
  * 发生变更的决策：写明"从X改为Y——原因"。
    例："端口：8080（从3000改过来——与已有服务冲突）。"
  * 当前有效的选择：直接陈述，不加模糊措辞。
  这些标记必须写在 value 文字本身中，便于检索时直接获取语义。

返回JSON数组（无变化则返回空数组）：
[{{"key": "<维度名>", "value": "<合并后或新的内容>", "dimension": "<维度名>", "action": "supplement|update|delete"}}]
维度名必须是以下之一：{dim_names}

只输出JSON："""


_DEFAULT_CHATMEM = {
    "llm": {},
    "dimensions": {
        "communication": {"label": "Expression style, language preference, tone, detail level",                                        "stability": 45.0},
        "autonomy":      {"label": "How much decision authority delegated to LLM: executes directly vs presents options vs validates", "stability": 40.0},
    },
}

_DEFAULT_AGENT = {
    "auto_mode": False,
    "verbose": False,
    "parallel_tasks": True,
    "llm_timeout": 30,
    "max_tool_iter": 40,
    "auto_max_tool_iter": 100,
    "max_tool_output": 20000,
    "require_confirm_on_irreversible": True,
    "active_model": "",
    "models": {
        "minimax": {
            "provider": "openai",
            "model": "MiniMax-M2.7",
            "base_url": "https://api.minimaxi.com/v1",
            "api_key_env": "MINIMAX_API_KEY",
            "context_window": 1000000,
            "extra_body": {
                "reasoning_split": True
            }
        },
        "kimi": {
            "provider": "openai",
            "model": "moonshot-v1-8k",
            "base_url": "https://api.moonshot.cn/v1",
            "api_key_env": "MOONSHOT_API_KEY",
            "context_window": 128000,
            "compress_model": "moonshot-v1-32k",
            "extra_body": {
                "thinking": {
                    "type": "disabled"
                }
            }
        }
    },
}


def _init_data_dir() -> tuple[str, str, str]:
    """
    Ensure ~/.mcode/ exists with agent.json, chatmem.json, project_memory.json.
    Migrates from control/ if old files exist and new ones don't.
    Returns (agent_json_path, chatmem_json_path, project_memory_json_path).
    """
    import json as _json
    import shutil as _shutil

    os.makedirs(_DATA_DIR, exist_ok=True)
    os.makedirs(os.path.join(_DATA_DIR, "tools"), exist_ok=True)

    agent_path = os.path.join(_DATA_DIR, "agent.json")
    chatmem_path = os.path.join(_DATA_DIR, "chatmem.json")
    project_memory_path = _PROJECT_MEMORY_JSON

    # Migrate agent.json from old location
    old_agent = os.path.join(_CONTROL, "agent.json")
    if not os.path.exists(agent_path):
        if os.path.exists(old_agent):
            _shutil.copy2(old_agent, agent_path)
        else:
            with open(agent_path, "w") as f:
                _json.dump(_DEFAULT_AGENT, f, indent=2, ensure_ascii=False)
                f.write("\n")

    # Migrate chatmem.json from old location (only dimensions, llm is auto-managed)
    old_chatmem = os.path.join(_CONTROL, "chatmem.json")
    if not os.path.exists(chatmem_path):
        if os.path.exists(old_chatmem):
            _shutil.copy2(old_chatmem, chatmem_path)
        else:
            with open(chatmem_path, "w") as f:
                _json.dump(_DEFAULT_CHATMEM, f, indent=2, ensure_ascii=False)
                f.write("\n")

    # Create project_memory.json with default project dimensions
    if not os.path.exists(project_memory_path):
        with open(project_memory_path, "w") as f:
            _json.dump(_DEFAULT_PROJECT_MEMORY, f, indent=2, ensure_ascii=False)
            f.write("\n")

    return agent_path, chatmem_path, project_memory_path


def _sync_active_model(agent_cfg: dict, chatmem_json_path: str | None):
    """Write the active model profile into chatmem.json's llm section."""
    import os as _os

    if not chatmem_json_path or not os.path.exists(chatmem_json_path):
        return
    models = agent_cfg.get("models", {})
    active = agent_cfg.get("active_model", "")
    profile = models.get(active)

    # Auto-detect: if active_model is empty, find the first model with a valid API key
    if not active or not profile:
        for model_name, model_cfg in models.items():
            api_key_env = model_cfg.get("api_key_env", "")
            if api_key_env and _os.environ.get(api_key_env):
                active = model_name
                profile = model_cfg
                agent_cfg["active_model"] = active
                # Save the updated active_model back to agent.json
                agent_path, *_ = _init_data_dir()
                with open(agent_path) as f:
                    import json as _json
                    data = _json.load(f)
                data["active_model"] = active
                with open(agent_path, "w") as f:
                    _json.dump(data, f, indent=2, ensure_ascii=False)
                    f.write("\n")
                break

    if not profile:
        return

    import json as _json
    with open(chatmem_json_path) as f:
        data = _json.load(f)
    # Replace llm section with profile entirely (don't merge — avoids stale keys from previous model)
    # Preserve non-LLM keys in existing llm section that aren't model-specific (none currently)
    data["llm"] = dict(profile)
    with open(chatmem_json_path, "w") as f:
        _json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


class Brain:
    def __init__(
        self,
        config_path: str | None = None,
        verbose: bool | None = None,
        project: str | None = None,
        no_lock: bool = False,
    ):
        # Ensure ~/.mcode/ exists; migrate old files if needed
        agent_path, chatmem_path, project_memory_path = _init_data_dir()

        self._agent_cfg_path = agent_path
        self._config_path = config_path or chatmem_path

        import json as _json
        agent_cfg: dict = {}
        if os.path.exists(self._agent_cfg_path):
            with open(self._agent_cfg_path) as f:
                agent_cfg = _json.load(f)

        # Sync active model profile → chatmem.json before loading ContextConfig
        _sync_active_model(agent_cfg, chatmem_path)

        cfg = ContextConfig.from_json(chatmem_path)

        # Agent-level config (CLI args override chatmem.json)
        self.auto_mode: bool = agent_cfg.get("auto_mode", False)
        self.bypass_safety: bool = False  # session-only, never persisted
        self.tool_choice: str = "auto"  # "auto" | "required"; first-iteration only, session-only
        self.verbose = verbose if verbose is not None else agent_cfg.get("verbose", False)
        llm_timeout: int = agent_cfg.get("llm_timeout", 30)
        self._agent_cfg = agent_cfg

        # Inject api_key_env from agent_cfg into cfg.llm so make_adapter can resolve it
        active = agent_cfg.get("active_model", "")
        profile = agent_cfg.get("models", {}).get(active, {})
        if profile.get("api_key_env"):
            cfg.llm.api_key_env = profile["api_key_env"]
        if profile.get("api_key"):
            cfg.llm.api_key = profile["api_key"]
        if profile.get("base_url"):
            cfg.llm.base_url = profile["base_url"]

        # Validate API key is resolvable (fail fast with a clear message)
        _api_key = cfg.llm.resolve_api_key()
        if not _api_key:
            if not active:
                raise RuntimeError(
                    "Your agent.json is missing 'active_model' configuration.\n"
                    "Please configure your LLM model in ~/.mcode/agent.json:\n"
                    "  1. Set 'active_model' to your desired model name (e.g., 'minimax')\n"
                    "  2. Configure the corresponding model in 'models' section\n"
                    "  3. Set the required API key environment variable"
                )
            env_var = profile.get("api_key_env", "")
            msg = f"API key not found for model '{active}'."
            if env_var:
                msg += f" Set the {env_var} environment variable."
            raise RuntimeError(msg)

        self.llm = make_adapter(cfg, timeout=llm_timeout)

        # Project/session management
        self.projects = ProjectManager()
        if project:
            self.projects.switch_project(project)
        else:
            self.projects.find_or_create_for_cwd()

        # Project memory — per-project CoreMemory in the same project DB
        self.project_memory = self._make_project_memory(
            cfg, _api_key, project_memory_path
        )

        # Memory layer — one DB per project, core DB shared
        self.memory = ContextManager.create(
            config=cfg,
            api_key=_api_key,
            db_path=self.projects.project_db_path,
            core_db_path=self.projects.core_db_path,
            no_lock=no_lock,
            extra_context_fn=(
                self.project_memory.to_context_string if self.project_memory else None
            ),
            on_compress_fn=(
                self._run_project_judge if self.project_memory else None
            ),
            auto_recall=False,
        )

        # Audit log
        self.audit = AuditLog(os.path.join(_DATA_DIR, "audit.db"))

        # Tool registry — built-ins + auto-discovered externals
        self.registry = ToolRegistry()
        self.registry.register(SHELL_TOOL)
        self.registry.register(FILE_READ_TOOL)
        self.registry.register(FILE_WRITE_TOOL)
        self.registry.register(FILE_EDIT_TOOL)
        self.registry.register(GLOB_TOOL)
        self.registry.register(GREP_TOOL)
        self.registry.register(WEB_FETCH_TOOL)
        self.registry.register(DATE_CALC_TOOL)
        self.registry.register(self._make_memory_search_tool())
        self.registry.register(self._make_project_query_tool())
        load_external_tools(self.registry)

        self._max_tool_iter: int = agent_cfg.get("max_tool_iter", 40)
        self._auto_max_tool_iter: int = agent_cfg.get("auto_max_tool_iter", 100)
        self._max_tool_output: int = agent_cfg.get("max_tool_output", 20000)

        # Interrupt support
        self._stop_event = threading.Event()
        self._last_was_action = False
        self._spinner_stop: threading.Event | None = None  # set by run.py before each turn
        self._judge_thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def run(self, user_input: str) -> str:
        """Process one user turn. Returns response string."""
        return "".join(self.stream_run(user_input))

    def stream_run(self, user_input: str):
        """Generator for the REPL. Yields text chunks."""
        self._stop_event.clear()
        yield from self._agent_loop(user_input)


    def _agent_loop(self, user_input: str):
        """
        Tool-use agentic loop using native function calling (OpenAI / Anthropic).
        Generator — yields text chunks for the final response.
        """
        from .llm import LLMResponse
        from safety.backup import backup_file as _backup_file
        if self.auto_mode:
            _system = (
                "You are an autonomous coding agent. Complete the user's task fully and independently.\n\n"
                "EXECUTION RULES:\n"
                "- Use tools to do everything: read files, write files, run commands, search code, fetch URLs.\n"
                "- NEVER guess, fabricate, or recall information that must come from a tool. "
                "If the task requires fetching a URL, reading a file, or running a command — call the tool. "
                "Do not invent the result.\n"
                "- To fetch any URL or HTTP endpoint, always call web_fetch. Never guess the response.\n"
                "- Do NOT output text mid-task. Keep calling tools until the task is 100% done.\n"
                "- Before editing a file, always read it first with file_read.\n"
                "- For targeted changes use file_edit; for new files use file_write.\n"
                "- If a tool fails, diagnose the error from the output and retry with a corrected approach.\n"
                "- Verify your work: run tests, check command output, re-read files after editing.\n"
                "- Only output text ONCE at the very end: a concise summary of what was done. "
                "Do not output diffs, patch format, or full file contents — describe changes in plain text.\n\n"
                "DECISION RULES:\n"
                "- When multiple approaches exist, pick the most direct one and execute it.\n"
                "- Do not ask for clarification. Make a reasonable assumption and proceed.\n"
                "- If genuinely blocked (missing credentials, hardware dependency, etc.), "
                "stop and explain clearly why."
            )
        else:
            _system = (
                "You are a coding assistant with access to tools. "
                "ALWAYS use tools to perform actions — never describe, simulate, or guess the result of an operation. "
                "If the user asks you to run a command, call shell_exec. "
                "If the user asks you to read a file, call file_read. "
                "If the user asks you to write or create a file, call file_write. "
                "If the user asks you to edit a file, call file_edit. "
                "If the user asks you to fetch a URL or HTTP endpoint, call web_fetch — never fabricate the response. "
                "Before editing a file, always read it first with file_read, then proceed to make the edit without stopping. "
                "For targeted changes use file_edit; for new files use file_write. "
                "If a task requires multiple tool calls, keep calling tools until the task is fully done — do not report completion until all actions have been executed via tools. "
                "If the user asks about something that may have been discussed in a previous session and you don't have that information in the current context, call memory_search before concluding it is unknown or undecided. "
                "When reading project memory, entries include an age marker like (14d ago) — if an entry is older than a few weeks and the topic is sensitive, consider calling memory_search to check for more recent updates. "
                "Entries with 'Rejected X' or 'abandoned X' or '放弃X' mean that option was explicitly ruled out — do not suggest it as a viable alternative."
            )
        user_msg = [
            {"role": "system", "content": _system},
            {"role": "user", "content": user_input},
        ]
        enriched = self.memory._build_context(user_msg)
        loop_msgs = list(enriched)
        tools = self.registry.to_openai_tools()

        any_tool_called = False
        final_text = ""
        tool_log = []
        _interrupted = False

        max_iter = self._auto_max_tool_iter if self.auto_mode else self._max_tool_iter
        # Stuck detection: track last seen (tool, args_repr) per iteration
        _stuck_streak = 0
        _last_call_sig: str | None = None
        _STUCK_THRESHOLD = 3  # abort if same call repeated this many times
        for iteration in range(max_iter):
            if self._stop_event.is_set():
                break

            # Stream with native function calling; collect text, capture final LLMResponse
            text_chunks: list[str] = []
            llm_response: LLMResponse | None = None
            try:
                # Enforce tool_choice only on the first iteration.
                # Subsequent iterations must stay "auto" so the model can
                # give a final text response after completing multi-step tasks.
                tc = self.tool_choice if iteration == 0 else "auto"
                for item in self.llm.stream_with_tools(loop_msgs, tools,
                                                       tool_choice=tc):
                    if self._stop_event.is_set():
                        break
                    if isinstance(item, str):
                        text_chunks.append(item)
                    else:
                        llm_response = item
            except KeyboardInterrupt:
                self._stop_event.set()
                _interrupted = True
                print()
                break

            if self._stop_event.is_set():
                break

            if llm_response is None:
                # Unexpected — treat accumulated text as final response
                full_text = "".join(text_chunks)
                if full_text.strip():
                    clean = _THINK_RE.sub("", full_text).strip()
                    final_text = _truncate_code_blocks(clean)
                    yield final_text
                break

            calls = llm_response.tool_calls

            if not calls:
                # No tool calls — final text response
                self._last_was_action = any_tool_called
                text = llm_response.text or "".join(text_chunks)
                clean = _THINK_RE.sub("", text).strip()
                final_text = _truncate_code_blocks(clean)
                yield final_text
                break

            # Stuck detection: if all calls in this iteration are identical to last, count streak
            call_sig = "|".join(f"{tc.name}:{json.dumps(tc.args, sort_keys=True)}" for tc in calls)
            if call_sig == _last_call_sig:
                _stuck_streak += 1
            else:
                _stuck_streak = 0
            _last_call_sig = call_sig

            if _stuck_streak >= _STUCK_THRESHOLD:
                final_text = (
                    f"(agent stuck: same tool call repeated {_stuck_streak + 1} times — "
                    f"aborting to prevent infinite loop)"
                )
                yield red(final_text)
                break

            # Append the assistant message (contains tool_calls in OpenAI format)
            if llm_response.assistant_msg:
                loop_msgs.append(llm_response.assistant_msg)
            any_tool_called = True

            tool_results = []
            _aborted = False
            for i, tc in enumerate(calls):
                if self._stop_event.is_set():
                    _aborted = True
                    break

                print()  # blank line before each tool call

                # Build Task for safety interface
                task = Task(
                    id=iteration * 100 + i,
                    tool=tc.name,
                    args=tc.args,
                    description=f"{tc.name}({tc.args})",
                    depends_on=[],
                )
                # Inject work_dir for path resolution
                exec_args = dict(tc.args)
                work_dir = self.projects.work_dir
                if work_dir:
                    if tc.name == "shell_exec" and "cwd" not in exec_args:
                        exec_args["cwd"] = work_dir
                    elif tc.name in ("file_read", "file_write", "file_edit", "grep"):
                        p = exec_args.get("path", "")
                        if p and not os.path.isabs(p) and not p.startswith("~"):
                            exec_args["path"] = os.path.join(work_dir, p)
                    elif tc.name == "glob":
                        if "base_dir" not in exec_args:
                            exec_args["base_dir"] = work_dir

                # Stop spinner before any user-visible output or confirmation prompt
                if self._spinner_stop and not self._spinner_stop.is_set():
                    self._spinner_stop.set()
                    time.sleep(0.05)

                if not self._confirm_tool_call(task):
                    # User said no — stop the loop
                    self._stop_event.set()
                    _aborted = True
                    yield "\n" + yellow("Operation cancelled. What would you like to do instead?")
                    break

                # Backup file before destructive edits (enables /undo)
                _backup_map: dict[str, str] = {}
                if tc.name in ("file_write", "file_edit"):
                    _target = exec_args.get("path", "")
                    if _target:
                        _bp = _backup_file(_target, self.projects.backup_dir)
                        if _bp:
                            _backup_map[_target] = _bp

                # Show file_write/file_edit diff before executing
                if tc.name == "file_write":
                    self._show_write_diff(tc.args)
                elif tc.name == "file_edit":
                    self._show_edit_diff(exec_args)

                _print_tool_header_simple(tc.name, tc.args)

                try:
                    result = self.registry.call(
                        tc.name, exec_args,
                        output_cb=lambda line: print(f"  {line}"),
                    )
                except KeyboardInterrupt:
                    self._stop_event.set()
                    _aborted = True
                    print(red("\n🚫  interrupted"))
                    break

                icon = green("✓") if result.success else red("✗")
                summary = (result.output if result.success else result.error)[:120].splitlines()[0]
                backup_hint = dim(f"  💾 backup saved") if _backup_map else ""
                print(f"{icon}  {dim(summary)}{backup_hint}")
                content = result.output if result.success else f"ERROR: {result.error}"

                if len(content) > self._max_tool_output:
                    omitted = len(content) - self._max_tool_output
                    content = content[:self._max_tool_output] + f"\n... [truncated, {omitted} chars omitted]"
                entry: dict = {
                    "tool": tc.name, "args": tc.args,
                    "success": result.success, "output": content[:500],
                }
                if _backup_map:
                    entry["backups"] = _backup_map
                tool_log.append(entry)
                tool_results.append({
                    "role": "tool",
                    "tool_call_id": tc.id,
                    "content": content,
                })

            if _aborted:
                # Remove the assistant message we already appended — loop_msgs stays consistent
                if llm_response.assistant_msg and loop_msgs and loop_msgs[-1] is llm_response.assistant_msg:
                    loop_msgs.pop()
            else:
                loop_msgs.extend(tool_results)
        else:
            # Hit max iterations
            final_text = f"(stopped after {max_iter} iterations)"
            yield final_text

        # Capture turn count before _post_turn adds the current turn
        _turn_idx = len(self.memory.list_turns())

        # Save to memory — skip if interrupted (avoid empty/partial turn polluting context)
        if not _interrupted:
            self.memory._post_turn(_content_to_text(user_input), final_text, user_msg)

        if any_tool_called:
            _user_text = _content_to_text(user_input)
            self.audit.record(_user_text, _user_text, [], True, tool_log,
                              project=self.projects.current_project,
                              turn_idx=_turn_idx)

    # ------------------------------------------------------------------
    # Per-tool safety + confirmation
    # ------------------------------------------------------------------

    def _confirm_tool_call(self, task: Task) -> bool:
        from safety.backup import backup_files

        work_dir = self.projects.work_dir

        # ── Auto mode: hard boundaries, zero prompts ───────────────────────────
        # ── Bypass safety: skip all checks ────────────────────────────────────
        if self.bypass_safety:
            return True

        if self.auto_mode:
            user_wl = self._agent_cfg.get("auto_whitelist", None)
            whitelist = list(set(_safety.DEFAULT_AUTO_WHITELIST) | set(user_wl)) if user_wl else None
            result = _safety.check_auto(task, work_dir=work_dir, whitelist=whitelist)
            if result.violation:
                print(red(f"\n🛑  AUTO-BLOCKED  {result.reason}"))
                return False
            if result.backup_paths:
                backed_up = backup_files(result.backup_paths, backup_dir=self.projects.backup_dir)
                for orig, bp in backed_up.items():
                    print(dim(f"💾  backup → {bp}"))
            return True

        # ── Human mode: zone checks + confirmation prompts ─────────────────────
        from safety.policy import is_always_allowed, remember_always, get_allowed_paths

        result = _safety.check(task, work_dir=work_dir, allowed_paths=get_allowed_paths())

        if result.violation:
            print(red(f"\n🛑  BLOCKED  {task.description}"))
            print(dim(f"   {result.reason}"))
            return False

        if result.backup_paths:
            backed_up = backup_files(result.backup_paths, backup_dir=self.projects.backup_dir)
            for orig, bp in backed_up.items():
                print(dim(f"💾  backup → {bp}"))

        if result.requires_confirmation:
            op = result.operation_class
            if op and is_always_allowed(op):
                return True

            if result.script_path and os.path.isfile(result.script_path):
                try:
                    content = open(result.script_path).read()
                    print(yellow(f"\n📄  Script: {result.script_path}"))
                    print(dim("─" * 60))
                    for line in content.splitlines()[:40]:
                        print(dim(f"   {line}"))
                    print(dim("─" * 60))
                except OSError:
                    pass

            print(yellow(f"\n⚠️   {result.reason}"))
            print(dim(f"    {task.description}"))

            if result.can_always:
                raw = _pt_prompt("    Proceed? [y]es  [n]o  [a]lways ❯ ").strip().lower()
            else:
                raw = _pt_prompt("    Proceed? [y]es  [n]o ❯ ").strip().lower()

            if raw in ("a", "always") and result.can_always:
                remember_always(op)
                print(cyan(f"📌  policy saved: always allow [{op}]"))
            elif raw not in ("y", "yes"):
                print(red("🚫  cancelled"))
                return False
            return True

        return True

    # ------------------------------------------------------------------
    # File write/edit diff
    # ------------------------------------------------------------------

    def _print_diff(self, old_content: str, new_content: str, path: str):
        import difflib
        if old_content == new_content:
            print(dim("  (no changes)"))
            return
        diff = list(difflib.unified_diff(
            old_content.splitlines(keepends=True),
            new_content.splitlines(keepends=True),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            lineterm="",
        ))
        print()
        for line in diff[:60]:
            if line.startswith("+"):
                print(green(f"  {line}"))
            elif line.startswith("-"):
                print(red(f"  {line}"))
            else:
                print(dim(f"  {line}"))
        if len(diff) > 60:
            print(dim(f"  ... ({len(diff)-60} more lines)"))
        print()

    def _resolve_full_path(self, path: str) -> str | None:
        full = os.path.expanduser(path)
        if not os.path.isabs(full):
            full = os.path.join(self.projects.work_dir, full)
        return full if os.path.isfile(full) else None

    def _show_write_diff(self, args: dict):
        path = args.get("path", "")
        new_content = args.get("content", "")
        if not path:
            return
        full_path = self._resolve_full_path(path)
        if not full_path:
            return  # new file, no diff needed
        try:
            old_content = open(full_path).read()
        except OSError:
            return
        self._print_diff(old_content, new_content, path)

    def _show_edit_diff(self, args: dict):
        path = args.get("path", "")
        old_str = args.get("old_str", "")
        if not path or not old_str:
            return
        full_path = self._resolve_full_path(path)
        if not full_path:
            return
        try:
            old_content = open(full_path).read()
        except OSError:
            return
        new_content = old_content.replace(old_str, args.get("new_str", ""), 1)
        self._print_diff(old_content, new_content, path)

    # ------------------------------------------------------------------
    # Model switching
    # ------------------------------------------------------------------

    def list_models(self) -> dict:
        """Return the models dict from agent.json."""
        return self._agent_cfg.get("models", {})

    def switch_model(self, name: str):
        """Switch to a named model profile. Updates agent.json + chatmem.json + live adapters."""
        import json as _json
        models = self._agent_cfg.get("models", {})
        if name not in models:
            raise KeyError(f"Model '{name}' not found in agent.json models")
        # Update agent.json
        self._agent_cfg["active_model"] = name
        with open(self._agent_cfg_path, "w") as f:
            _json.dump(self._agent_cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        # Sync to chatmem.json and rebuild adapters
        _sync_active_model(self._agent_cfg, self._config_path)
        cfg = ContextConfig.from_json(self._config_path) if self._config_path else ContextConfig()
        key = cfg.llm.resolve_api_key()
        if not key:
            profile = models.get(name, {})
            env_var = profile.get("api_key_env", "")
            msg = f"API key not found for model '{name}'."
            if env_var:
                msg += f" Set the {env_var} environment variable."
            raise RuntimeError(msg)
        timeout = self._agent_cfg.get("llm_timeout", 30)
        self.llm = make_adapter(cfg, timeout=timeout)
        self._reinit_memory()

    # ------------------------------------------------------------------
    # Project / session switching
    # ------------------------------------------------------------------

    def switch_project(self, name: str):
        self.end_session()
        self.projects.switch_project(name)
        self._reinit_memory()

    def _make_memory_search_tool(self):
        """Build a memory_search Tool that searches recent_memory for relevant past context."""
        from tools.registry import Tool, ToolSchema
        recent_memory = self.memory.recent_memory

        def _search(query: str, top_k: int = 5) -> str:
            results = recent_memory.search(query, top_k=top_k, min_score=0.0)
            if not results:
                return "No relevant memory found."
            return "\n\n---\n\n".join(results)

        return Tool(
            schema=ToolSchema(
                name="memory_search",
                description=(
                    "Search compressed summaries of past conversation sessions for relevant context. "
                    "ALWAYS call this before saying something is unknown, undecided, or not recorded — "
                    "the information may exist in a previous session even if it is not in the current context. "
                    "Use key terms from the user's question as the query.\n"
                    "搜索过去对话的压缩摘要，获取相关上下文。"
                    "在说某事未知、未决定或未记录之前，必须先调用此工具——"
                    "即使当前上下文中没有该信息，它也可能存在于之前的会话中。"
                    "用用户问题中的关键词作为查询词。"
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Key terms to search for (e.g. '8080 端口', 'authentication design')",
                        },
                        "top_k": {
                            "type": "integer",
                            "description": "Max results to return (default 5)",
                            "default": 5,
                        },
                    },
                    "required": ["query"],
                },
            ),
            fn=_search,
        )

    def _make_project_query_tool(self):
        """Build a project_query Tool that reads structured project_memory entries directly."""
        from tools.registry import Tool, ToolSchema

        brain = self  # capture for closure

        def _query(keyword: str = "", include_history: bool = False) -> str:
            pm = brain.project_memory
            if pm is None:
                return "No project memory available for this project."
            entries = pm.get_all()
            if not entries:
                return "Project memory is empty."
            kw = keyword.strip().lower()
            if kw:
                entries = [
                    e for e in entries
                    if kw in e.get("key", "").lower() or kw in e.get("value", "").lower()
                ]
            if not entries:
                return f"No project memory entries matching '{keyword}'."
            lines = []
            for e in entries:
                lines.append(f"[{e.get('dimension', '?')}] {e['key']}: {e['value']}")
            if include_history:
                hist = pm.get_history(key=keyword.strip() if keyword.strip() else None)
                if hist:
                    lines.append("\n[History — previous values, newest first]")
                    for h in hist:
                        from datetime import datetime
                        dt = datetime.fromtimestamp(h["archived_at"]).strftime("%Y-%m-%d")
                        lines.append(f"  {dt}  [{h['key']}]: {h['value']}")
            return "\n".join(lines)

        return Tool(
            schema=ToolSchema(
                name="project_query",
                description=(
                    "Read structured project memory — decisions, architecture choices, conventions, "
                    "and progress tracked for this project. "
                    "Use this for questions about current state, decisions made, or project conventions. "
                    "Prefer this over memory_search for questions about decisions, tech stack, or architecture. "
                    "Set include_history=true to see previous values for a key (useful for 'what changed' questions).\n"
                    "读取结构化的项目记忆——本项目的决策、架构选择、约定和进展。"
                    "对于决策、技术栈、架构等问题，优先调用此工具，而非 memory_search。"
                    "include_history=true 可查看某个条目的历史变更记录（适用于【之前是什么/改了什么】类问题）。"
                ),
                parameters={
                    "type": "object",
                    "properties": {
                        "keyword": {
                            "type": "string",
                            "description": (
                                "Optional keyword to filter entries (case-insensitive substring match on key and value). "
                                "Leave empty to return all project memory entries."
                            ),
                        },
                        "include_history": {
                            "type": "boolean",
                            "description": "If true, append the history of previous values (newest first). Use for 'what changed' or 'what was it before' questions.",
                        },
                    },
                    "required": [],
                },
            ),
            fn=_query,
        )

    def _make_project_memory(self, cfg: "ContextConfig", api_key: str, project_memory_path: str):
        """Instantiate a CoreMemory for project-scoped knowledge."""
        import json as _json
        from chatmem.memory.core_memory import CoreMemory
        from chatmem.config import DimensionConfig

        try:
            with open(project_memory_path) as f:
                pm_data = _json.load(f)
            dims = {
                k: DimensionConfig(label=v["label"], stability=float(v["stability"]))
                for k, v in pm_data.get("dimensions", {}).items()
            }
        except Exception:
            dims = {}
        if not dims:
            return None

        compress_model = cfg.llm.compress_model or cfg.llm.model
        _THINKING_KEYS = {"reasoning_split", "thinking", "reasoning_effort"}
        extra_body = (
            {k: v for k, v in cfg.llm.extra_body.items() if k not in _THINKING_KEYS}
            if cfg.llm.extra_body else None
        ) or None
        provider = getattr(cfg.llm, "provider", "openai") or "openai"

        pm = CoreMemory(
            db_path=self.projects.project_db_path,
            api_key=api_key,
            model=compress_model,
            base_url=cfg.llm.base_url,
            dimensions=dims,
            extra_body=extra_body,
            provider=provider,
            context_label="Project Memory",
            enable_history=True,
        )

        # Override judge prompts with project-specific framing
        pm._judge_prompt_en = _build_project_judge_prompt(dims)
        pm._judge_prompt_zh = _build_project_judge_prompt_zh(dims)
        return pm

    def _reinit_memory(self):
        if getattr(self, "memory", None) is not None:
            self.memory.close()
        cfg = ContextConfig.from_json(self._config_path) if self._config_path else ContextConfig()
        api_key = cfg.llm.resolve_api_key()
        self.project_memory = self._make_project_memory(cfg, api_key, _PROJECT_MEMORY_JSON)
        self.memory = ContextManager.create(
            config=cfg,
            api_key=api_key,
            db_path=self.projects.project_db_path,
            core_db_path=self.projects.core_db_path,
            extra_context_fn=(
                self.project_memory.to_context_string if self.project_memory else None
            ),
            on_compress_fn=(
                self._run_project_judge if self.project_memory else None
            ),
            auto_recall=False,
        )
        self.registry.register(self._make_memory_search_tool())
        self.registry.register(self._make_project_query_tool())

    def _save_agent_cfg(self):
        """Persist current _agent_cfg to agent.json."""
        import json as _json
        with open(self._agent_cfg_path, "w") as f:
            _json.dump(self._agent_cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    def _run_project_judge(self, text: str):
        if not self.project_memory:
            return
        import logging as _logging
        logger = _logging.getLogger("chatmem")
        try:
            written = self.project_memory.judge_and_update(text)
            if written:
                for e in written:
                    if e.get("action") == "delete":
                        logger.info("[project] judge deleted  key=%r", e["key"])
                    else:
                        logger.info("[project] judge wrote  key=%r  dim=%s  value=%r",
                                    e["key"], e.get("dimension"), e["value"][:60])
            else:
                logger.info("[project] judge returned empty")
        except Exception as exc:
            logger.warning("[project] judge error: %s", exc)

    def end_session(self):
        # Capture verbatim history before end_session clears it
        verbatim = [m for m in self.memory._history if not m.get("_is_summary")]
        conv_text = "\n".join(
            f"{m['role']}: {m.get('content', '')}" for m in verbatim
        ) if verbatim else ""

        self.memory.end_session()

        if conv_text:
            self._judge_thread = threading.Thread(
                target=self._run_project_judge, args=(conv_text,), daemon=True
            )
            self._judge_thread.start()
