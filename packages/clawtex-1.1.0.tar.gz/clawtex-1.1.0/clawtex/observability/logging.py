# ClawTex — Observability: Structured Logging
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Structured JSON logging for ClawTex agents.

Provides a JSON log formatter and a helper to configure structured logging
across the entire ClawTex runtime. When CLAWTEX_LOG_FORMAT=json, all log
output is machine-parseable — ready for CloudWatch, Datadog, GCP Logging, etc.

Usage:
    from clawtex.observability.logging import setup_logging
    setup_logging()  # reads CLAWTEX_LOG_FORMAT and CLAWTEX_LOG_LEVEL from env
"""

from __future__ import annotations

import json
import logging
import os
import sys
import time
from typing import Any


class StructuredFormatter(logging.Formatter):
    """Emit log records as single-line JSON objects.

    Output fields:
      - timestamp (ISO 8601)
      - level (DEBUG/INFO/WARNING/ERROR/CRITICAL)
      - logger (logger name)
      - message
      - agent (from CLAWTEX_NAME env var)
      - Any extra fields passed via `extra={}` on log calls
    """

    def __init__(self, agent_name: str = "") -> None:
        super().__init__()
        self.agent_name = agent_name or os.environ.get("CLAWTEX_NAME", "clawtex")

    def format(self, record: logging.LogRecord) -> str:
        doc: dict[str, Any] = {
            "timestamp": self.formatTime(record, "%Y-%m-%dT%H:%M:%S.") + f"{int(record.msecs):03d}Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "agent": self.agent_name,
        }

        # Include exception info if present
        if record.exc_info and record.exc_info[1]:
            doc["exception"] = {
                "type": type(record.exc_info[1]).__name__,
                "message": str(record.exc_info[1]),
            }

        # Include any extra fields (span_id, cost_usd, model, etc.)
        for key in ("span_id", "duration_ms", "model", "tokens", "cost_usd",
                     "action_type", "decision", "namespace", "tool", "channel",
                     "user_id", "tenant_id", "error"):
            val = getattr(record, key, None)
            if val is not None:
                doc[key] = val

        return json.dumps(doc, default=str, ensure_ascii=False)


def setup_logging(
    level: str | None = None,
    format: str | None = None,
    agent_name: str = "",
) -> None:
    """Configure logging for the ClawTex runtime.

    Args:
        level: Log level (DEBUG/INFO/WARNING/ERROR). Default: from CLAWTEX_LOG_LEVEL or INFO.
        format: 'json' for structured JSON, 'text' for human-readable. Default: from CLAWTEX_LOG_FORMAT or text.
        agent_name: Agent name for log context. Default: from CLAWTEX_NAME.
    """
    log_level = level or os.environ.get("CLAWTEX_LOG_LEVEL", "INFO")
    log_format = format or os.environ.get("CLAWTEX_LOG_FORMAT", "text")

    root = logging.getLogger()
    root.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # Clear existing handlers
    root.handlers.clear()

    handler = logging.StreamHandler(sys.stderr)

    if log_format.lower() == "json":
        handler.setFormatter(StructuredFormatter(agent_name=agent_name))
    else:
        handler.setFormatter(logging.Formatter(
            "%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        ))

    root.addHandler(handler)
