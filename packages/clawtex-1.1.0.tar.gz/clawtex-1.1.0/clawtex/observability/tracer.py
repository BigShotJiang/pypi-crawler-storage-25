# ClawTex — Observability: Tracer
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Lightweight tracing for ClawTex agents.

Tracks the lifecycle of every message through the agent:
  - LLM calls (model, tokens, latency)
  - Tool executions (name, governance decision, latency)
  - Memory operations (recall, ingest)
  - Full request spans

No external dependencies — pure Python. Exportable to JSON for analysis.

Usage:

    tracer = Tracer(agent_name="mybot")

    with tracer.span("handle_message") as s:
        s.set_tag("user_id", "u123")

        with tracer.span("llm_call") as llm:
            llm.set_tag("model", "claude-sonnet-4-20250514")
            # ... call LLM ...
            llm.set_tag("input_tokens", 500)
            llm.set_tag("output_tokens", 150)

        with tracer.span("tool_exec") as tool:
            tool.set_tag("tool", "web_search")
            tool.set_tag("decision", "ALLOW")

    tracer.export()  # → list of span dicts
"""

from __future__ import annotations

import logging
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Generator

logger = logging.getLogger(__name__)


@dataclass
class Span:
    """A single traced operation."""

    name: str
    span_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    parent_id: str | None = None
    agent_name: str = ""
    start_time: float = 0.0
    end_time: float = 0.0
    duration_ms: float = 0.0
    tags: dict[str, Any] = field(default_factory=dict)
    status: str = "ok"  # "ok" | "error"

    def set_tag(self, key: str, value: Any) -> None:
        self.tags[key] = value

    def set_error(self, error: str) -> None:
        self.status = "error"
        self.tags["error"] = error

    def finish(self) -> None:
        self.end_time = time.time()
        self.duration_ms = (self.end_time - self.start_time) * 1000

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "span_id": self.span_id,
            "parent_id": self.parent_id,
            "agent": self.agent_name,
            "start": self.start_time,
            "end": self.end_time,
            "duration_ms": round(self.duration_ms, 2),
            "status": self.status,
            "tags": dict(self.tags),
        }


class Tracer:
    """Collects spans for an agent's operations.

    Thread-safe for single-agent use. Each message gets its own trace.
    Spans are stored in memory and can be exported for analysis.
    """

    def __init__(
        self,
        agent_name: str = "",
        max_spans: int = 10000,
        enabled: bool = True,
    ) -> None:
        self.agent_name = agent_name
        self._spans: list[Span] = []
        self._max_spans = max_spans
        self._active_span: Span | None = None
        self.enabled = enabled

    @contextmanager
    def span(self, name: str) -> Generator[Span, None, None]:
        """Create and track a timed span."""
        if not self.enabled:
            yield Span(name=name)
            return

        s = Span(
            name=name,
            agent_name=self.agent_name,
            parent_id=self._active_span.span_id if self._active_span else None,
            start_time=time.time(),
        )

        prev_active = self._active_span
        self._active_span = s

        try:
            yield s
        except Exception as exc:
            s.set_error(str(exc))
            raise
        finally:
            s.finish()
            self._active_span = prev_active
            self._record(s)

    def _record(self, span: Span) -> None:
        """Store a completed span."""
        self._spans.append(span)
        if len(self._spans) > self._max_spans:
            self._spans = self._spans[-self._max_spans:]

    def export(self, last_n: int | None = None) -> list[dict[str, Any]]:
        """Export spans as dicts."""
        spans = self._spans[-last_n:] if last_n else self._spans
        return [s.to_dict() for s in spans]

    def clear(self) -> None:
        """Clear all recorded spans."""
        self._spans.clear()

    @property
    def span_count(self) -> int:
        return len(self._spans)

    def export_otlp(self) -> list[dict[str, Any]]:
        """Export spans in OTLP-compatible format.

        Returns a list of span dicts matching the OpenTelemetry data model,
        suitable for sending to any OTLP collector (Jaeger, Tempo, Datadog, etc.).
        """
        otlp_spans = []
        for s in self._spans:
            otlp_spans.append({
                "traceId": s.span_id[:16].ljust(32, "0"),
                "spanId": s.span_id,
                "parentSpanId": s.parent_id or "",
                "operationName": s.name,
                "serviceName": s.agent_name or self.agent_name,
                "startTimeUnixNano": int(s.start_time * 1_000_000_000),
                "endTimeUnixNano": int(s.end_time * 1_000_000_000),
                "durationMs": round(s.duration_ms, 2),
                "status": {"code": 2 if s.status == "error" else 1},
                "attributes": [
                    {"key": k, "value": {"stringValue": str(v)}}
                    for k, v in s.tags.items()
                ],
            })
        return otlp_spans

    def export_json(self, filepath: str) -> int:
        """Export spans to a JSON file. Returns the number of spans written."""
        import json
        data = self.export()
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        return len(data)

    def summary(self) -> dict[str, Any]:
        """Aggregate stats across all spans."""
        if not self._spans:
            return {"total_spans": 0}

        by_name: dict[str, list[float]] = {}
        errors = 0
        for s in self._spans:
            by_name.setdefault(s.name, []).append(s.duration_ms)
            if s.status == "error":
                errors += 1

        breakdown = {}
        for name, durations in by_name.items():
            breakdown[name] = {
                "count": len(durations),
                "total_ms": round(sum(durations), 2),
                "avg_ms": round(sum(durations) / len(durations), 2),
                "max_ms": round(max(durations), 2),
                "min_ms": round(min(durations), 2),
            }

        return {
            "agent": self.agent_name,
            "total_spans": len(self._spans),
            "errors": errors,
            "breakdown": breakdown,
        }
