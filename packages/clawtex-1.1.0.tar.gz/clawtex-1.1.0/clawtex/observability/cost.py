# ClawTex — Observability: Cost Tracker
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Token usage and cost tracking for ClawTex agents.

Tracks tokens per LLM call, calculates USD cost, and aggregates
by agent, model, and time period.

Pricing (per 1M tokens, as of 2026):
  Anthropic Claude Sonnet 4:   input=$3,  output=$15
  Anthropic Claude Opus 4:     input=$15, output=$75
  Anthropic Claude Haiku 3.5:  input=$0.80, output=$4
  OpenAI GPT-4o:               input=$2.50, output=$10
  OpenAI GPT-4o-mini:          input=$0.15, output=$0.60
  OpenAI o3:                   input=$10, output=$40
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


# Cost per 1M tokens (input, output) in USD
MODEL_PRICING: dict[str, tuple[float, float]] = {
    # Anthropic
    "claude-sonnet-4-20250514": (3.0, 15.0),
    "claude-opus-4-20250514": (15.0, 75.0),
    "claude-haiku-4-5-20251001": (0.80, 4.0),
    "claude-3-5-sonnet-20241022": (3.0, 15.0),
    "claude-3-5-haiku-20241022": (0.80, 4.0),
    # OpenAI
    "gpt-4o": (2.50, 10.0),
    "gpt-4o-mini": (0.15, 0.60),
    "o3": (10.0, 40.0),
    "o3-mini": (1.10, 4.40),
    # Embeddings
    "text-embedding-3-small": (0.02, 0.0),
    "text-embedding-3-large": (0.13, 0.0),
}


@dataclass
class UsageRecord:
    """A single LLM usage event."""

    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    agent_name: str = ""
    timestamp: float = 0.0
    operation: str = ""  # "chat", "tool_use", "embedding", etc.

    def to_dict(self) -> dict[str, Any]:
        return {
            "model": self.model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cost_usd": round(self.cost_usd, 6),
            "agent": self.agent_name,
            "timestamp": self.timestamp,
            "operation": self.operation,
        }


class CostTracker:
    """Tracks token usage and costs across LLM calls.

    Usage:
        tracker = CostTracker(agent_name="mybot")
        tracker.record("claude-sonnet-4-20250514", input_tokens=500, output_tokens=150)
        print(tracker.total_cost_usd)  # 0.00375
        print(tracker.summary())
    """

    def __init__(self, agent_name: str = "", max_records: int = 50000) -> None:
        self.agent_name = agent_name
        self._records: list[UsageRecord] = []
        self._max_records = max_records

    def record(
        self,
        model: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        operation: str = "chat",
    ) -> UsageRecord:
        """Record a usage event and calculate cost."""
        cost = self._calculate_cost(model, input_tokens, output_tokens)
        rec = UsageRecord(
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost,
            agent_name=self.agent_name,
            timestamp=time.time(),
            operation=operation,
        )
        self._records.append(rec)
        if len(self._records) > self._max_records:
            self._records = self._records[-self._max_records:]
        return rec

    @staticmethod
    def _calculate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
        """Calculate USD cost for a given model and token count."""
        pricing = MODEL_PRICING.get(model)
        if pricing is None:
            # Try prefix matching for model variants
            for key, val in MODEL_PRICING.items():
                if model.startswith(key.rsplit("-", 1)[0]):
                    pricing = val
                    break
        if pricing is None:
            return 0.0

        input_cost_per_token = pricing[0] / 1_000_000
        output_cost_per_token = pricing[1] / 1_000_000
        return (input_tokens * input_cost_per_token) + (output_tokens * output_cost_per_token)

    @property
    def total_cost_usd(self) -> float:
        return sum(r.cost_usd for r in self._records)

    @property
    def total_input_tokens(self) -> int:
        return sum(r.input_tokens for r in self._records)

    @property
    def total_output_tokens(self) -> int:
        return sum(r.output_tokens for r in self._records)

    @property
    def record_count(self) -> int:
        return len(self._records)

    def summary(self) -> dict[str, Any]:
        """Aggregate usage stats."""
        if not self._records:
            return {
                "agent": self.agent_name,
                "total_cost_usd": 0.0,
                "total_input_tokens": 0,
                "total_output_tokens": 0,
                "calls": 0,
            }

        by_model: dict[str, dict[str, Any]] = {}
        for r in self._records:
            if r.model not in by_model:
                by_model[r.model] = {
                    "calls": 0,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cost_usd": 0.0,
                }
            m = by_model[r.model]
            m["calls"] += 1
            m["input_tokens"] += r.input_tokens
            m["output_tokens"] += r.output_tokens
            m["cost_usd"] += r.cost_usd

        # Round costs
        for m in by_model.values():
            m["cost_usd"] = round(m["cost_usd"], 6)

        return {
            "agent": self.agent_name,
            "total_cost_usd": round(self.total_cost_usd, 6),
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "calls": len(self._records),
            "by_model": by_model,
        }

    def export(self, last_n: int | None = None) -> list[dict[str, Any]]:
        """Export usage records as dicts."""
        records = self._records[-last_n:] if last_n else self._records
        return [r.to_dict() for r in records]

    def clear(self) -> None:
        self._records.clear()
