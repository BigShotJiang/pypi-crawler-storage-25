# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Unified configuration loader for ClawTex.

Priority order (highest → lowest):
  1. Environment variables (CLAWTEX_* prefix)
  2. .clawtex.toml in current directory
  3. .clawtex.toml in home directory (~/.clawtex.toml)
  4. Defaults

This module is the single source of truth for all ClawTex configuration.
Import `cfg` and use it everywhere instead of reading env vars directly.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ── TOML loader (stdlib in 3.11+, fallback to tomli) ─────

try:
    import tomllib  # Python 3.11+
except ModuleNotFoundError:
    try:
        import tomli as tomllib  # type: ignore[no-redef]
    except ModuleNotFoundError:
        tomllib = None  # type: ignore[assignment]

TOML_PATH_LOCAL = Path(".clawtex.toml")
TOML_PATH_HOME = Path.home() / ".clawtex.toml"


@dataclass
class ClawTexConfig:
    """All ClawTex configuration in one place."""

    # ── Identity ──────────────────────────────────────────
    name: str = "ClawTex"
    soul: str = "./SOUL.md"

    # ── LLM ───────────────────────────────────────────────
    llm_provider: str = "anthropic"  # anthropic | openai
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    openai_model: str = "gpt-4o"

    # ── Memory / Eidetic ──────────────────────────────────
    eidetic_url: str = ""
    eidetic_key: str = ""
    eidetic_namespace: str = "default"
    eidetic_gcloud_account: str = ""

    # ── Vector Backend ────────────────────────────────────
    vector_backend: str = "chroma"  # chroma | pinecone | pgvector | supabase
    pinecone_api_key: str = ""
    pinecone_index: str = ""
    pgvector_url: str = ""
    supabase_url: str = ""
    supabase_key: str = ""

    # ── Channels ──────────────────────────────────────────
    telegram_bot_token: str = ""
    slack_bot_token: str = ""
    slack_app_token: str = ""

    # ── Governance ────────────────────────────────────────
    warden_mode: str = "enforce"  # enforce | audit | off
    warden_policy: str = "./clawtex/governance/policies/default.yaml"

    # ── Dream Cycle ───────────────────────────────────────
    dream_interval_hours: int = 6

    # ── Skills ────────────────────────────────────────────
    skills_dir: str = "./skills"

    def to_env(self) -> dict[str, str]:
        """Export as environment variables (for subprocess/channel compat)."""
        env: dict[str, str] = {}
        if self.name:
            env["CLAWTEX_NAME"] = self.name
        if self.soul:
            env["CLAWTEX_SOUL"] = self.soul
        if self.llm_provider:
            env["LLM_PROVIDER"] = self.llm_provider
        if self.anthropic_api_key:
            env["ANTHROPIC_API_KEY"] = self.anthropic_api_key
        if self.openai_api_key:
            env["OPENAI_API_KEY"] = self.openai_api_key
        if self.openai_model:
            env["OPENAI_MODEL"] = self.openai_model
        if self.eidetic_url:
            env["CLAWTEX_EIDETIC_URL"] = self.eidetic_url
        if self.eidetic_key:
            env["CLAWTEX_EIDETIC_KEY"] = self.eidetic_key
        if self.eidetic_namespace:
            env["CLAWTEX_EIDETIC_NAMESPACE"] = self.eidetic_namespace
        if self.eidetic_gcloud_account:
            env["CLAWTEX_EIDETIC_GCLOUD_ACCOUNT"] = self.eidetic_gcloud_account
        if self.telegram_bot_token:
            env["TELEGRAM_BOT_TOKEN"] = self.telegram_bot_token
        if self.slack_bot_token:
            env["SLACK_BOT_TOKEN"] = self.slack_bot_token
        if self.slack_app_token:
            env["SLACK_APP_TOKEN"] = self.slack_app_token
        if self.warden_mode:
            env["WARDEN_MODE"] = self.warden_mode
        if self.warden_policy:
            env["WARDEN_POLICY"] = self.warden_policy
        env["DREAM_INTERVAL_HOURS"] = str(self.dream_interval_hours)
        if self.skills_dir:
            env["CLAWTEX_SKILLS_DIR"] = self.skills_dir
        return env

    def inject_env(self) -> None:
        """Push config values into os.environ (for legacy code paths)."""
        for k, v in self.to_env().items():
            if k not in os.environ:
                os.environ[k] = v


# ── ENV → field mapping ──────────────────────────────────

_ENV_MAP: dict[str, str] = {
    "CLAWTEX_NAME": "name",
    "CLAWTEX_SOUL": "soul",
    "LLM_PROVIDER": "llm_provider",
    "ANTHROPIC_API_KEY": "anthropic_api_key",
    "OPENAI_API_KEY": "openai_api_key",
    "OPENAI_MODEL": "openai_model",
    "CLAWTEX_EIDETIC_URL": "eidetic_url",
    "CLAWTEX_EIDETIC_KEY": "eidetic_key",
    "CLAWTEX_EIDETIC_NAMESPACE": "eidetic_namespace",
    "CLAWTEX_EIDETIC_GCLOUD_ACCOUNT": "eidetic_gcloud_account",
    "CLAWTEX_MEMORY_URL": "eidetic_url",       # legacy
    "CLAWTEX_MEMORY_KEY": "eidetic_key",       # legacy
    "MANDELDB_URL": "eidetic_url",             # legacy
    "MANDELDB_API_KEY": "eidetic_key",         # legacy
    "MANDELDB_NAMESPACE": "eidetic_namespace", # legacy
    "VECTOR_BACKEND": "vector_backend",
    "PINECONE_API_KEY": "pinecone_api_key",
    "PINECONE_INDEX": "pinecone_index",
    "PGVECTOR_URL": "pgvector_url",
    "SUPABASE_URL": "supabase_url",
    "SUPABASE_KEY": "supabase_key",
    "TELEGRAM_BOT_TOKEN": "telegram_bot_token",
    "SLACK_BOT_TOKEN": "slack_bot_token",
    "SLACK_APP_TOKEN": "slack_app_token",
    "WARDEN_MODE": "warden_mode",
    "WARDEN_POLICY": "warden_policy",
    "DREAM_INTERVAL_HOURS": "dream_interval_hours",
    "CLAWTEX_SKILLS_DIR": "skills_dir",
}

# ── TOML section → field mapping ─────────────────────────

_TOML_MAP: dict[str, dict[str, str]] = {
    "identity": {"name": "name", "soul": "soul"},
    "llm": {
        "provider": "llm_provider",
        "anthropic_api_key": "anthropic_api_key",
        "openai_api_key": "openai_api_key",
        "openai_model": "openai_model",
    },
    "memory": {
        "url": "eidetic_url",
        "key": "eidetic_key",
        "namespace": "eidetic_namespace",
        "gcloud_account": "eidetic_gcloud_account",
    },
    "vector": {
        "backend": "vector_backend",
        "pinecone_api_key": "pinecone_api_key",
        "pinecone_index": "pinecone_index",
        "pgvector_url": "pgvector_url",
        "supabase_url": "supabase_url",
        "supabase_key": "supabase_key",
    },
    "channels": {
        "telegram_bot_token": "telegram_bot_token",
        "slack_bot_token": "slack_bot_token",
        "slack_app_token": "slack_app_token",
    },
    "governance": {
        "warden_mode": "warden_mode",
        "warden_policy": "warden_policy",
    },
    "agent": {
        "dream_interval_hours": "dream_interval_hours",
        "skills_dir": "skills_dir",
    },
}


def _load_toml(path: Path) -> dict[str, Any]:
    """Load a TOML file, returning {} on any failure."""
    if tomllib is None or not path.exists():
        return {}
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except Exception:
        return {}


def load_config() -> ClawTexConfig:
    """Load config with priority: env vars > local toml > home toml > defaults."""
    cfg = ClawTexConfig()

    # Layer 1: Home-level .clawtex.toml (lowest priority)
    _apply_toml(cfg, _load_toml(TOML_PATH_HOME))

    # Layer 2: Project-level .clawtex.toml
    _apply_toml(cfg, _load_toml(TOML_PATH_LOCAL))

    # Layer 3: Environment variables (highest priority)
    for env_key, field_name in _ENV_MAP.items():
        val = os.environ.get(env_key)
        if val:
            if field_name == "dream_interval_hours":
                try:
                    setattr(cfg, field_name, int(val))
                except ValueError:
                    pass
            else:
                setattr(cfg, field_name, val)

    return cfg


def _apply_toml(cfg: ClawTexConfig, data: dict[str, Any]) -> None:
    """Apply parsed TOML data to config object."""
    for section, mapping in _TOML_MAP.items():
        section_data = data.get(section, {})
        if isinstance(section_data, dict):
            for toml_key, field_name in mapping.items():
                val = section_data.get(toml_key)
                if val is not None:
                    setattr(cfg, field_name, val)


def write_toml(cfg: ClawTexConfig, path: Path | None = None) -> Path:
    """Write config to .clawtex.toml file."""
    target = path or TOML_PATH_LOCAL
    lines = [
        "# ClawTex Configuration",
        "# BB4C — Breath Before Code · AN2B LLC",
        "# Generated by: clawtex init",
        "",
        "[identity]",
        f'name = "{cfg.name}"',
        f'soul = "{cfg.soul}"',
        "",
        "[llm]",
        f'provider = "{cfg.llm_provider}"',
    ]

    if cfg.llm_provider == "anthropic" and cfg.anthropic_api_key:
        lines.append(f'anthropic_api_key = "{cfg.anthropic_api_key}"')
    elif cfg.llm_provider == "openai":
        if cfg.openai_api_key:
            lines.append(f'openai_api_key = "{cfg.openai_api_key}"')
        lines.append(f'openai_model = "{cfg.openai_model}"')

    lines += [
        "",
        "[memory]",
        f'url = "{cfg.eidetic_url}"',
    ]
    if cfg.eidetic_key:
        lines.append(f'key = "{cfg.eidetic_key}"')
    lines.append(f'namespace = "{cfg.eidetic_namespace}"')
    if cfg.eidetic_gcloud_account:
        lines.append(f'gcloud_account = "{cfg.eidetic_gcloud_account}"')

    lines += [
        "",
        "[vector]",
        f'backend = "{cfg.vector_backend}"',
    ]
    if cfg.vector_backend == "pinecone":
        if cfg.pinecone_api_key:
            lines.append(f'pinecone_api_key = "{cfg.pinecone_api_key}"')
        if cfg.pinecone_index:
            lines.append(f'pinecone_index = "{cfg.pinecone_index}"')
    elif cfg.vector_backend == "pgvector":
        if cfg.pgvector_url:
            lines.append(f'pgvector_url = "{cfg.pgvector_url}"')
    elif cfg.vector_backend == "supabase":
        if cfg.supabase_url:
            lines.append(f'supabase_url = "{cfg.supabase_url}"')
        if cfg.supabase_key:
            lines.append(f'supabase_key = "{cfg.supabase_key}"')

    if cfg.telegram_bot_token or cfg.slack_bot_token:
        lines += ["", "[channels]"]
        if cfg.telegram_bot_token:
            lines.append(f'telegram_bot_token = "{cfg.telegram_bot_token}"')
        if cfg.slack_bot_token:
            lines.append(f'slack_bot_token = "{cfg.slack_bot_token}"')
        if cfg.slack_app_token:
            lines.append(f'slack_app_token = "{cfg.slack_app_token}"')

    lines += [
        "",
        "[governance]",
        f'warden_mode = "{cfg.warden_mode}"',
        f'warden_policy = "{cfg.warden_policy}"',
        "",
        "[agent]",
        f"dream_interval_hours = {cfg.dream_interval_hours}",
        f'skills_dir = "{cfg.skills_dir}"',
        "",
    ]

    target.write_text("\n".join(lines), encoding="utf-8")
    return target
