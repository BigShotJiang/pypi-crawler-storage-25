# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
MandelDB HTTP client — semantic memory backend for ClawTex agents.

Provides:
  recall(query, top_k=5)     → POST /v2/recall     — fetch relevant memories
  ingest(content, metadata)  → POST /v2/memory      — store new memory
  dream(namespace)           → POST /v2/brain/dream — trigger consolidation

All methods are async. Retries on 429 (backoff) and 5xx (up to 3 attempts).
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_RETRY_STATUSES = {429, 500, 502, 503, 504}
_MAX_RETRIES = 3
_BASE_BACKOFF = 1.0  # seconds

UPGRADE_URL = "https://clawtex.ai/upgrade"


class MemoryLimitError(Exception):
    """Raised when the free-tier memory limit is reached."""
    def __init__(self) -> None:
        super().__init__(
            f"🧠 Memory limit reached on the free tier.\n"
            f"   Upgrade your plan to continue: {UPGRADE_URL}\n"
            f"   Plans start at $19/mo — unlimited memory, full speed."
        )


class MandelDBClient:
    """Async client for the MandelDB memory API."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        # Unified env vars: CLAWTEX_EIDETIC_* preferred, legacy fallbacks supported
        self.base_url = (
            base_url
            or os.environ.get("CLAWTEX_EIDETIC_URL", "")
            or os.environ.get("CLAWTEX_MEMORY_URL", "")  # legacy
        ).rstrip("/")
        self.api_key = (
            api_key
            or os.environ.get("CLAWTEX_EIDETIC_KEY", "")
            or os.environ.get("CLAWTEX_MEMORY_KEY", "")  # legacy
        )
        self._admin_key = os.environ.get("MANDELDB_ADMIN_KEY", "")
        _gcp_env = (
            os.environ.get("CLAWTEX_EIDETIC_GCLOUD_ACCOUNT", "")
            or os.environ.get("CLAWTEX_GCP_AUTH", "")
        )
        self._gcp_auth = _gcp_env.lower() in ("1", "true", "yes") or bool(_gcp_env and _gcp_env not in ("0", "false", "no"))

        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        if self._admin_key:
            headers["X-Admin-Key"] = self._admin_key

        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
        )

    _cached_token: str | None = None
    _token_expiry: float = 0

    async def _get_gcp_token(self) -> str | None:
        """Get a GCP identity token for Cloud Run auth (if running on GCP)."""
        import time
        # Cache token for 50 minutes (they expire at 60)
        if self._cached_token and time.time() < self._token_expiry:
            return self._cached_token

        # Try metadata server (works inside Cloud Run / GCE)
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                resp = await c.get(
                    "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/identity"
                    f"?audience={self.base_url}",
                    headers={"Metadata-Flavor": "Google"},
                )
                if resp.status_code == 200:
                    self._cached_token = resp.text.strip()
                    self._token_expiry = time.time() + 3000  # 50 min cache
                    return self._cached_token
        except Exception:
            pass

        # Fallback: gcloud CLI
        try:
            import subprocess
            result = subprocess.run(
                "gcloud auth print-identity-token",
                capture_output=True, text=True, shell=True, timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                self._cached_token = result.stdout.strip()
                self._token_expiry = time.time() + 3000
                return self._cached_token
        except Exception:
            pass
        return None

    async def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute an HTTP request with exponential-backoff retry."""
        last_exc: Exception | None = None

        # Add GCP identity token if needed.
        # Use X-Serverless-Authorization (NOT Authorization) to avoid collision
        # with MandelDB's JWT auth layer — Cloud Run's IAM proxy consumes and
        # strips X-Serverless-Authorization before the request reaches the app.
        extra_headers = {}
        if self._gcp_auth or self.base_url.endswith(".run.app"):
            token = await self._get_gcp_token()
            if token:
                extra_headers["X-Serverless-Authorization"] = f"Bearer {token}"

        for attempt in range(_MAX_RETRIES):
            try:
                response = await self._client.request(method, path, json=payload, headers=extra_headers)
                if response.status_code in _RETRY_STATUSES:
                    wait = _BASE_BACKOFF * (2 ** attempt)
                    # Honour Retry-After if present
                    retry_after = response.headers.get("Retry-After")
                    if retry_after:
                        try:
                            wait = float(retry_after)
                        except ValueError:
                            pass
                    logger.warning(
                        "MandelDB %s %s → %d, retrying in %.1fs (attempt %d/%d)",
                        method,
                        path,
                        response.status_code,
                        wait,
                        attempt + 1,
                        _MAX_RETRIES,
                    )
                    await asyncio.sleep(wait)
                    continue
                if response.status_code == 402:
                    raise MemoryLimitError()
                response.raise_for_status()
                return response.json()
            except httpx.RequestError as exc:
                last_exc = exc
                wait = _BASE_BACKOFF * (2 ** attempt)
                logger.warning(
                    "MandelDB request error: %s — retrying in %.1fs", exc, wait
                )
                await asyncio.sleep(wait)

        raise RuntimeError(
            f"MandelDB request failed after {_MAX_RETRIES} attempts"
        ) from last_exc

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def recall(
        self,
        query: str,
        top_k: int = 5,
        namespace: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Retrieve the top-k semantically similar memories for *query*.

        Returns a list of memory objects (content, score, metadata).
        """
        payload: dict[str, Any] = {"query": query, "top_k": top_k}
        if namespace:
            payload["namespace"] = namespace
        result = await self._request("POST", "/v2/recall", payload)
        return result.get("memories", result if isinstance(result, list) else [])

    async def ingest(
        self,
        content: str,
        metadata: dict[str, Any] | None = None,
        namespace: str | None = None,
    ) -> dict[str, Any]:
        """
        Store *content* as a new memory entry.

        *metadata* can include agent_name, session_id, timestamp, source, etc.
        Returns the created memory record.
        """
        payload: dict[str, Any] = {
            "content": content,
            "metadata": metadata or {},
        }
        if namespace:
            payload["namespace"] = namespace
        return await self._request("POST", "/v2/memory", payload)

    async def dream(self, namespace: str) -> dict[str, Any]:
        """
        Trigger memory consolidation (dreaming) for the given namespace.

        This allows MandelDB to cluster, summarise, and compress memories
        — analogous to REM sleep in biological memory systems.
        Returns the dream job status.
        """
        return await self._request(
            "POST", "/v2/brain/dream", {"namespace": namespace}
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "MandelDBClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()
