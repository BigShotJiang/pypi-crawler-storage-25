# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
pgvector backend — direct Postgres memory for ClawTex personal advisors.

A drop-in replacement for MandelDBClient that talks directly to a Postgres
database with the pgvector extension. No GCP IAM, no service-to-service
auth, no Cloud Run. Just a connection string.

Designed for personal advisor instances (Shepherd, Joey, etc.) where:
- Each user gets their own schema (schema-level isolation)
- Memories are stored as text + 1536-dim embeddings (OpenAI compatible)
- Semantic search via cosine distance
- Works from anywhere — laptop, Mac Mini, Cloud Run, all the same

Usage:
    client = PgVectorClient(
        connection_string="postgresql://...",
        schema="pastor_scott",
    )
    await client.ingest("Scott shared he's been struggling with patience")
    results = await client.recall("patience", top_k=3)

Schema setup (run once per user):
    CREATE SCHEMA IF NOT EXISTS pastor_scott;
    CREATE EXTENSION IF NOT EXISTS vector;
    CREATE TABLE pastor_scott.memories (
        id BIGSERIAL PRIMARY KEY,
        content TEXT NOT NULL,
        embedding vector(1536) NOT NULL,
        metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX ON pastor_scott.memories
        USING hnsw (embedding vector_cosine_ops);
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

# Default to OpenAI text-embedding-3-small (1536 dimensions)
EMBEDDING_DIM = 1536


class PgVectorClient:
    """Async Postgres + pgvector memory client. MandelDBClient-compatible interface."""

    def __init__(
        self,
        connection_string: str | None = None,
        schema: str | None = None,
        openai_api_key: str | None = None,
        embedding_model: str = "text-embedding-3-small",
    ) -> None:
        self.connection_string = (
            connection_string
            or os.environ.get("PGVECTOR_URL", "")
            or os.environ.get("VECTOR_DB_URL", "")
            or os.environ.get("DATABASE_URL", "")
        )
        if not self.connection_string:
            raise ValueError(
                "PgVectorClient: no connection string. Set PGVECTOR_URL "
                "(or pass connection_string=...)."
            )

        self.schema = (
            schema
            or os.environ.get("INSTANCE_SCHEMA", "")
            or os.environ.get("PGVECTOR_SCHEMA", "public")
        )

        self.openai_api_key = openai_api_key or os.environ.get("OPENAI_API_KEY", "")
        self.embedding_model = embedding_model

        self._pool = None  # asyncpg.Pool, lazy-initialized
        self._openai_client = None  # openai.AsyncOpenAI, lazy-initialized

    # ------------------------------------------------------------------
    # Lazy initialization
    # ------------------------------------------------------------------

    async def _get_pool(self):
        if self._pool is None:
            try:
                import asyncpg
            except ImportError as exc:
                raise ImportError(
                    "asyncpg not installed. Run: pip install asyncpg"
                ) from exc

            self._pool = await asyncpg.create_pool(
                self.connection_string,
                min_size=1,
                max_size=5,
                command_timeout=30,
            )
            logger.info(
                "pgvector pool created (schema=%s)", self.schema
            )
        return self._pool

    def _get_openai(self):
        if self._openai_client is None:
            try:
                from openai import AsyncOpenAI
            except ImportError as exc:
                raise ImportError(
                    "openai not installed. Run: pip install openai"
                ) from exc

            if not self.openai_api_key:
                raise ValueError(
                    "PgVectorClient needs OPENAI_API_KEY for embeddings."
                )
            self._openai_client = AsyncOpenAI(api_key=self.openai_api_key)
        return self._openai_client

    async def _embed(self, text: str) -> list[float]:
        """Generate an embedding vector for *text* via OpenAI."""
        client = self._get_openai()
        response = await client.embeddings.create(
            model=self.embedding_model,
            input=text,
        )
        return response.data[0].embedding

    # ------------------------------------------------------------------
    # Setup — ensure schema + table exist (idempotent)
    # ------------------------------------------------------------------

    async def ensure_schema(self) -> None:
        """Create schema, enable pgvector, create table + index. Idempotent."""
        pool = await self._get_pool()
        async with pool.acquire() as conn:
            # Enable pgvector (no-op if already enabled)
            await conn.execute("CREATE EXTENSION IF NOT EXISTS vector")

            # Create schema
            await conn.execute(f'CREATE SCHEMA IF NOT EXISTS "{self.schema}"')

            # Create memories table
            await conn.execute(f'''
                CREATE TABLE IF NOT EXISTS "{self.schema}".memories (
                    id BIGSERIAL PRIMARY KEY,
                    content TEXT NOT NULL,
                    embedding vector({EMBEDDING_DIM}) NOT NULL,
                    metadata JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            ''')

            # Create HNSW vector index (works from first record, no training needed)
            await conn.execute(f'''
                CREATE INDEX IF NOT EXISTS memories_embedding_idx
                ON "{self.schema}".memories
                USING hnsw (embedding vector_cosine_ops)
            ''')
        logger.info("Schema ready: %s", self.schema)

    # ------------------------------------------------------------------
    # Public API — matches MandelDBClient interface
    # ------------------------------------------------------------------

    async def recall(
        self,
        query: str,
        top_k: int = 5,
        namespace: str | None = None,
        recent_count: int = 5,
    ) -> list[dict[str, Any]]:
        """
        Hybrid retrieval: top-k semantic matches + N most recent memories.

        Why hybrid? Pure semantic search fails on questions like
        "What did I just tell you?" — the embedding for that query has
        near-zero similarity to the embedding of "I'm working on patience."
        Recent-N catches the conversational continuity that semantic
        search alone misses.

        Returns a deduplicated list ordered with semantic matches first,
        then any recent memories not already in the semantic results.

        *namespace* is accepted for interface compatibility but ignored —
        pgvector uses schema-level isolation set at client init time.
        """
        embedding = await self._embed(query)
        embedding_str = "[" + ",".join(str(x) for x in embedding) + "]"

        pool = await self._get_pool()
        async with pool.acquire() as conn:
            # Query 1: top-k semantic matches
            semantic_rows = await conn.fetch(
                f'''
                SELECT
                    id,
                    content,
                    metadata,
                    created_at,
                    1 - (embedding <=> $1::vector) AS score
                FROM "{self.schema}".memories
                ORDER BY embedding <=> $1::vector
                LIMIT $2
                ''',
                embedding_str,
                top_k,
            )

            # Query 2: N most recent memories (recency window)
            recent_rows = await conn.fetch(
                f'''
                SELECT
                    id,
                    content,
                    metadata,
                    created_at,
                    NULL::float AS score
                FROM "{self.schema}".memories
                ORDER BY created_at DESC
                LIMIT $1
                ''',
                recent_count,
            )

        # Merge: semantic first, then recents not already seen
        seen_ids: set = set()
        results: list[dict[str, Any]] = []

        for row in semantic_rows:
            seen_ids.add(row["id"])
            results.append({
                "memory_id": str(row["id"]),
                "content": row["content"],
                "score": float(row["score"]),
                "metadata": json.loads(row["metadata"]) if isinstance(row["metadata"], str) else (row["metadata"] or {}),
                "timestamp": row["created_at"].isoformat() if row["created_at"] else None,
                "source": "semantic",
            })

        for row in recent_rows:
            if row["id"] in seen_ids:
                continue
            seen_ids.add(row["id"])
            results.append({
                "memory_id": str(row["id"]),
                "content": row["content"],
                "score": None,
                "metadata": json.loads(row["metadata"]) if isinstance(row["metadata"], str) else (row["metadata"] or {}),
                "timestamp": row["created_at"].isoformat() if row["created_at"] else None,
                "source": "recent",
            })

        return results

    async def ingest(
        self,
        content: str,
        metadata: dict[str, Any] | None = None,
        namespace: str | None = None,
    ) -> dict[str, Any]:
        """
        Store *content* as a new memory entry.

        *namespace* is accepted for interface compatibility but ignored —
        pgvector uses schema-level isolation set at client init time.
        Returns the created memory record.
        """
        embedding = await self._embed(content)
        embedding_str = "[" + ",".join(str(x) for x in embedding) + "]"
        metadata_json = json.dumps(metadata or {})

        pool = await self._get_pool()
        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                f'''
                INSERT INTO "{self.schema}".memories (content, embedding, metadata)
                VALUES ($1, $2::vector, $3::jsonb)
                RETURNING id, created_at
                ''',
                content,
                embedding_str,
                metadata_json,
            )

        return {
            "memory_id": str(row["id"]),
            "namespace": self.schema,
            "node_type": "memory",
            "timestamp": row["created_at"].isoformat(),
            "deduplicated": False,
        }

    async def dream(self, namespace: str | None = None) -> dict[str, Any]:
        """
        Memory consolidation — no-op for pgvector backend.

        pgvector is a simple vector store. Dream cycles (Hebbian
        consolidation) are a MandelDB feature. For personal advisors,
        this isn't needed — the embeddings + semantic search are enough.
        """
        return {"status": "noop", "backend": "pgvector"}

    async def close(self) -> None:
        """Close the connection pool."""
        if self._pool is not None:
            await self._pool.close()
            self._pool = None

    async def __aenter__(self) -> "PgVectorClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()
