# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Secret + PII redactor — scrubs sensitive content before it reaches MandelDB.

Vector memory is forever: once a secret is embedded, it can be retrieved by
future recall queries across sessions and agents. This module runs over every
piece of text before ingest so API keys, bearer tokens, and similar never
get written to the brain.

The redactor is deliberately fail-open for availability (any regex error
falls back to the original input) but defaults to aggressive patterns for
the shapes that matter: provider API keys, JWTs, AWS keys, GitHub tokens.

Configuration
-------------
  CLAWTEX_REDACT_DISABLED=1     — turn redaction OFF entirely (debug only)
  CLAWTEX_REDACT_PII=1          — also redact email addresses + long digit runs
  CLAWTEX_REDACT_EXTRA=a|b|c    — extra regex alternation applied as-is

Every match is replaced with [REDACTED:<label>] so the redaction is visible
in the memory text (and downstream recall doesn't pull up a fake key).
"""

from __future__ import annotations

import logging
import os
import re
from typing import Pattern

logger = logging.getLogger(__name__)

# Label → compiled regex. Order matters: first match wins for overlapping
# candidates, so list the most specific patterns first.
_BUILTIN_PATTERNS: list[tuple[str, str]] = [
    # Anthropic
    ("ANTHROPIC_KEY", r"sk-ant-[A-Za-z0-9_\-]{20,}"),
    # OpenAI (new project keys + legacy)
    ("OPENAI_KEY",    r"sk-proj-[A-Za-z0-9_\-]{20,}"),
    ("OPENAI_KEY",    r"sk-[A-Za-z0-9]{32,}"),
    # MandelDB bot keys
    ("MANDELDB_KEY",  r"ek_bot_[A-Za-z0-9_\-]{16,}"),
    # GitHub
    ("GITHUB_TOKEN",  r"gh[pousr]_[A-Za-z0-9]{36,}"),
    # AWS
    ("AWS_ACCESS_KEY", r"AKIA[0-9A-Z]{16}"),
    ("AWS_SECRET",     r"(?i)aws(.{0,20})?(secret|access)?(.{0,20})?['\"]?[0-9a-zA-Z/+=]{40}['\"]?"),
    # Google API key
    ("GCP_API_KEY",   r"AIza[0-9A-Za-z_\-]{35}"),
    # Slack tokens
    ("SLACK_TOKEN",   r"xox[abprs]-[A-Za-z0-9\-]{10,}"),
    # JWT (three base64-url segments, 20+ chars each)
    ("JWT",           r"eyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"),
    # Generic Bearer token in a header-like context
    ("BEARER",        r"(?i)bearer\s+[A-Za-z0-9._\-]{20,}"),
    # PEM blocks
    ("PEM",           r"-----BEGIN [A-Z ]+-----[\s\S]+?-----END [A-Z ]+-----"),
]

# Optional PII patterns — only on when CLAWTEX_REDACT_PII=1.
_PII_PATTERNS: list[tuple[str, str]] = [
    ("EMAIL", r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}"),
    # Very long digit runs — phone/SSN/card catch-all (conservative).
    ("DIGITS", r"\b\d{9,16}\b"),
]


def _is_truthy(v: str) -> bool:
    return v.strip().lower() in ("1", "true", "yes", "on")


def _build_patterns() -> list[tuple[str, Pattern[str]]]:
    pairs: list[tuple[str, str]] = list(_BUILTIN_PATTERNS)
    if _is_truthy(os.environ.get("CLAWTEX_REDACT_PII", "")):
        pairs.extend(_PII_PATTERNS)

    extra = os.environ.get("CLAWTEX_REDACT_EXTRA", "").strip()
    if extra:
        pairs.append(("EXTRA", extra))

    compiled: list[tuple[str, Pattern[str]]] = []
    for label, src in pairs:
        try:
            compiled.append((label, re.compile(src)))
        except re.error as exc:
            logger.warning("Redactor skipping invalid regex %r (%s): %s", label, src, exc)
    return compiled


# Compile once per process; callers can force a refresh via reset().
_PATTERNS: list[tuple[str, Pattern[str]]] = _build_patterns()


def reset() -> None:
    """Re-read env vars and rebuild the pattern list. Mostly for tests."""
    global _PATTERNS
    _PATTERNS = _build_patterns()


def redact(text: str) -> tuple[str, dict[str, int]]:
    """
    Scrub sensitive patterns from *text*.

    Returns (cleaned_text, counts_by_label). Fail-open: on any unexpected
    error the original text is returned with an empty counts dict.
    """
    if not text or not isinstance(text, str):
        return text, {}
    if _is_truthy(os.environ.get("CLAWTEX_REDACT_DISABLED", "")):
        return text, {}

    try:
        counts: dict[str, int] = {}
        cleaned = text
        for label, pat in _PATTERNS:
            def _sub(match: re.Match[str]) -> str:
                counts[label] = counts.get(label, 0) + 1
                return f"[REDACTED:{label}]"
            cleaned = pat.sub(_sub, cleaned)
        return cleaned, counts
    except Exception as exc:  # noqa: BLE001
        logger.warning("Redactor error (returning original): %s", exc)
        return text, {}


def redact_silent(text: str) -> str:
    """Convenience wrapper when you don't need the counts."""
    cleaned, _ = redact(text)
    return cleaned
