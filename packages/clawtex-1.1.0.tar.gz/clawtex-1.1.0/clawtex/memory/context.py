# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Memory context builder — assembles recalled memories into prompt context.

Usage:
    ctx = MemoryContext(mandeldb_client, namespace="myagent")
    context_block = await ctx.build(user_message)   # returns formatted string
    await ctx.record_exchange(user_message, assistant_reply)
"""

from __future__ import annotations

import datetime
import logging
import os
import uuid
from pathlib import Path
from typing import Any

from .mandeldb import MandelDBClient
from .redactor import redact

logger = logging.getLogger(__name__)


def _utc_now_z() -> str:
    """Timezone-aware UTC timestamp in ISO-8601 with a Z suffix."""
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def _resolve_namespace(given: str | None = None) -> str:
    """
    Resolve a stable, unique namespace for this agent instance.

    Priority:
    1. Explicitly passed ``namespace`` argument
    2. ``CLAWTEX_NAME`` env var (if set and non-empty)
    3. ``.clawtex-id`` file in cwd (persisted auto-generated ID)
    4. Auto-generate ``bot:<6-char-uuid>`` and save to ``.clawtex-id``

    This ensures every new ClawTex deployment gets its own isolated
    MandelDB namespace without any manual configuration required.
    """
    if given:
        return given

    env_name = os.environ.get("CLAWTEX_NAME", "").strip()
    if env_name:
        return env_name

    id_file = Path(".clawtex-id")
    if id_file.exists():
        stored = id_file.read_text().strip()
        if stored:
            return stored

    # First run — generate and persist
    new_id = "bot:" + uuid.uuid4().hex[:6]
    try:
        id_file.write_text(new_id + "\n")
        logger.info("Auto-generated namespace '%s' → saved to .clawtex-id", new_id)
    except OSError as exc:
        logger.warning("Could not persist namespace to .clawtex-id: %s", exc)

    return new_id


class MemoryContext:
    """Wraps MandelDB to provide recall-before / ingest-after semantics."""

    def __init__(
        self,
        client: MandelDBClient | None = None,
        namespace: str | None = None,
        top_k: int = 5,
    ) -> None:
        self._client = client or MandelDBClient()
        self.namespace = _resolve_namespace(namespace)
        self.top_k = top_k

    # ------------------------------------------------------------------
    # Pre-response: recall relevant context
    # ------------------------------------------------------------------

    async def build(self, query: str) -> str:
        """
        Recall memories relevant to *query* and return a formatted context block
        ready for insertion into the system prompt.
        """
        try:
            memories = await self._client.recall(
                query=query,
                top_k=self.top_k,
                namespace=self.namespace,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Memory recall failed (continuing without context): %s", exc)
            return ""

        if not memories:
            return ""

        # Split memories by source so the model sees recent context distinctly
        # from semantic matches. Hybrid backends (pgvector) tag each memory with
        # source="recent" or source="semantic"; older backends just lump them.
        recent_mems = [m for m in memories if m.get("source") == "recent"]
        semantic_mems = [m for m in memories if m.get("source") != "recent"]

        lines: list[str] = []

        if recent_mems:
            lines.append("## Recent Conversations (most recent first)")
            lines.append("These are the most recent things this user has shared with you. Reference them naturally when relevant.\n")
            for i, mem in enumerate(recent_mems, 1):
                content = mem.get("content", str(mem))
                ts = mem.get("timestamp") or mem.get("metadata", {}).get("timestamp", "")
                ts_str = f" ({ts})" if ts else ""
                lines.append(f"{i}. {content.strip()}{ts_str}")
            lines.append("")

        if semantic_mems:
            lines.append("## Relevant Memory Context")
            lines.append("Older memories that may be relevant to the current question.\n")
            for i, mem in enumerate(semantic_mems, 1):
                content = mem.get("content", str(mem))
                score = mem.get("score") or mem.get("similarity")
                score_str = f" [relevance: {score:.2f}]" if score is not None else ""
                ts = mem.get("timestamp") or mem.get("metadata", {}).get("timestamp", "")
                ts_str = f" ({ts})" if ts else ""
                lines.append(f"{i}. {content.strip()}{score_str}{ts_str}")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Post-response: ingest the exchange
    # ------------------------------------------------------------------

    async def record_exchange(
        self,
        user_message: str,
        assistant_reply: str,
        extra_metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        Persist the user↔assistant exchange to MandelDB for future recall.

        Both the user message and the assistant reply pass through the
        redactor first. Vector memory is forever — a leaked API key
        pasted into a message must never become an embedded, recallable
        artifact.
        """
        clean_user, user_counts = redact(user_message)
        clean_reply, reply_counts = redact(assistant_reply)
        total = {k: user_counts.get(k, 0) + reply_counts.get(k, 0)
                 for k in set(user_counts) | set(reply_counts)}

        if total:
            logger.warning(
                "Redacted %d secret/PII match(es) before memory ingest: %s",
                sum(total.values()), total,
            )

        content = f"User: {clean_user}\nAssistant: {clean_reply}"
        metadata: dict[str, Any] = {
            "timestamp": _utc_now_z(),
            "agent": self.namespace,
            "type": "exchange",
        }
        if total:
            metadata["redactions"] = total
        if extra_metadata:
            metadata.update(extra_metadata)

        try:
            await self._client.ingest(
                content=content,
                metadata=metadata,
                namespace=self.namespace,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Memory ingest failed (non-fatal): %s", exc)

    async def ingest_fact(
        self, content: str, metadata: dict[str, Any] | None = None
    ) -> None:
        """Store an arbitrary fact or note in memory — redacted first."""
        clean, counts = redact(content)
        if counts:
            logger.warning(
                "Redacted %d secret/PII match(es) before fact ingest: %s",
                sum(counts.values()), counts,
            )
        base: dict[str, Any] = {
            "timestamp": _utc_now_z(),
            "agent": self.namespace,
            "type": "fact",
        }
        if counts:
            base["redactions"] = counts
        if metadata:
            base.update(metadata)
        try:
            await self._client.ingest(
                content=clean, metadata=base, namespace=self.namespace
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Fact ingest failed (non-fatal): %s", exc)

    async def trigger_dream(self) -> dict[str, Any]:
        """Trigger MandelDB memory consolidation for this agent's namespace."""
        return await self._client.dream(self.namespace)
