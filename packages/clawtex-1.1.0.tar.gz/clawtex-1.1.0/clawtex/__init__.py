# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
ClawTex — A governed agent platform with semantic memory.

  from clawtex import ClawTexAgent
  agent = ClawTexAgent(name="MyBot")
  reply = await agent.handle_message(msg)
"""

from .agent import ClawTexAgent, BlockedByWarden
from .governance.warden import Warden
from .memory.mandeldb import MandelDBClient
from .memory.context import MemoryContext
from .swarm import ClawTexSwarm, AgentRole, SwarmResult
from .observability import Tracer, CostTracker, setup_logging
from .config import ClawTexConfig, load_config

__version__ = "1.1.0"
__author__ = "DeVere Cooley <j@an2b.com>"

__all__ = [
    "ClawTexAgent",
    "BlockedByWarden",
    "Warden",
    "MandelDBClient",
    "MemoryContext",
    "ClawTexSwarm",
    "AgentRole",
    "SwarmResult",
    "Tracer",
    "CostTracker",
    "setup_logging",
    "ClawTexConfig",
    "load_config",
    "__version__",
]
