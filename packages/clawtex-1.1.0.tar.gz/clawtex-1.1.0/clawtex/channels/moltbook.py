# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Moltbook channel adapter — connects a ClawTex agent to Moltbook (moltbook.com),
the social network for AI agents.

Requires: httpx (already a core dependency) and MOLTBOOK_API_KEY env var.

Usage:
    channel = MoltbookChannel(handler=agent.handle_message)
    await channel.start()          # begins 30-minute heartbeat loop
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from typing import Any

import httpx

from .base import BaseChannel, InboundMessage, MessageHandler, OutboundMessage

logger = logging.getLogger(__name__)

BASE_URL = "https://www.moltbook.com/api/v1"
HEARTBEAT_INTERVAL = 30 * 60  # 30 minutes in seconds
RATE_LIMIT_BACKOFF = 60        # seconds to wait on 429


class MoltbookChannel(BaseChannel):
    """
    Moltbook channel adapter.

    Polls the Moltbook API on a 30-minute heartbeat:
      - Checks activity on your posts (new comments → reply)
      - Checks direct messages → reply
      - Reads feed for content to engage with
      - Uses semantic search to find relevant conversations
    """

    name = "moltbook"

    def __init__(
        self,
        handler: MessageHandler,
        api_key: str | None = None,
        agent_name: str | None = None,
        heartbeat_interval: int = HEARTBEAT_INTERVAL,
    ) -> None:
        super().__init__(handler)
        self._api_key = api_key or os.environ.get("MOLTBOOK_API_KEY", "")
        self._agent_name = agent_name or os.environ.get("MOLTBOOK_AGENT_NAME", "AN2B")
        self._heartbeat_interval = heartbeat_interval
        self._client: httpx.AsyncClient | None = None
        self._seen_comment_ids: set[str] = set()
        self._seen_dm_ids: set[str] = set()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        if not self._api_key:
            raise ValueError(
                "MOLTBOOK_API_KEY is not set. "
                "Set it in your .env file to enable the Moltbook channel."
            )

        self._client = httpx.AsyncClient(
            base_url=BASE_URL,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )

        self._running = True
        logger.info("Moltbook channel starting (heartbeat every %ds)…", self._heartbeat_interval)

        try:
            while self._running:
                try:
                    await self._heartbeat()
                except Exception as exc:
                    logger.error("Moltbook heartbeat error: %s", exc, exc_info=True)
                await asyncio.sleep(self._heartbeat_interval)
        finally:
            await self._client.aclose()
            self._client = None

    async def stop(self) -> None:
        self._running = False
        logger.info("Moltbook channel stopped.")

    async def send(self, message: OutboundMessage) -> None:
        """Send a reply — routes to comment or DM based on metadata."""
        if not self._client:
            logger.warning("Moltbook send called before start()")
            return

        post_id = message.metadata.get("post_id")
        dm_thread_id = message.metadata.get("dm_thread_id")

        if post_id:
            await self.comment(post_id, message.text)
        elif dm_thread_id:
            await self._send_dm(dm_thread_id, message.text)
        else:
            logger.warning("Moltbook send: no post_id or dm_thread_id in metadata — dropping message")

    # ------------------------------------------------------------------
    # Heartbeat
    # ------------------------------------------------------------------

    async def _heartbeat(self) -> None:
        logger.info("Moltbook heartbeat — checking home…")
        home = await self._get("/home")
        if not home:
            return

        activity = home.get("activity_on_your_posts", [])
        dms = home.get("your_direct_messages", [])

        await self._handle_post_activity(activity)
        await self._handle_dms(dms)
        await self._read_feed()

    # ------------------------------------------------------------------
    # Activity on posts — new comments → reply
    # ------------------------------------------------------------------

    async def _handle_post_activity(self, activity: list[dict[str, Any]]) -> None:
        for item in activity:
            comment_id = str(item.get("id", ""))
            if not comment_id or comment_id in self._seen_comment_ids:
                continue

            self._seen_comment_ids.add(comment_id)

            author = item.get("author", "someone")
            body = item.get("body") or item.get("content", "")
            post_id = str(item.get("post_id", ""))

            if not body or not post_id:
                continue

            logger.info("Moltbook new comment on post %s from @%s", post_id, author)

            msg = InboundMessage(
                text=body,
                user_id=author,
                channel=self.name,
                thread_id=post_id,
                metadata={"post_id": post_id, "comment_id": comment_id, "author": author},
            )
            reply_text = await self.handle(msg)
            await self.comment(post_id, reply_text)

    # ------------------------------------------------------------------
    # Direct messages
    # ------------------------------------------------------------------

    async def _handle_dms(self, dms: list[dict[str, Any]]) -> None:
        for dm in dms:
            dm_id = str(dm.get("id", ""))
            if not dm_id or dm_id in self._seen_dm_ids:
                continue

            self._seen_dm_ids.add(dm_id)

            sender = dm.get("sender") or dm.get("from", "unknown")
            body = dm.get("body") or dm.get("content", "")
            thread_id = str(dm.get("thread_id") or dm_id)

            if not body:
                continue

            logger.info("Moltbook DM from @%s", sender)

            msg = InboundMessage(
                text=body,
                user_id=sender,
                channel=self.name,
                thread_id=thread_id,
                metadata={"dm_thread_id": thread_id, "dm_id": dm_id, "sender": sender},
            )
            reply_text = await self.handle(msg)
            await self._send_dm(thread_id, reply_text)

    async def _send_dm(self, thread_id: str, content: str) -> None:
        await self._post("/direct_messages", {"thread_id": thread_id, "content": content})

    # ------------------------------------------------------------------
    # Feed reading
    # ------------------------------------------------------------------

    async def _read_feed(self) -> None:
        feed = await self._get("/feed", params={"sort": "hot"})
        if not feed:
            return

        posts = feed if isinstance(feed, list) else feed.get("posts", [])
        logger.info("Moltbook feed: %d posts returned", len(posts))
        # Feed content is available to the heartbeat runner for engagement decisions.
        # Actual upvoting / commenting is left to run_moltbook.py logic.

    # ------------------------------------------------------------------
    # Public actions
    # ------------------------------------------------------------------

    async def post(self, submolt: str, title: str, content: str) -> dict[str, Any] | None:
        """Create a new post on Moltbook, handling the verification challenge."""
        payload = {"submolt": submolt, "title": title, "content": content}
        response = await self._post_raw("/posts", payload)
        if response is None:
            return None

        if response.status_code == 200 or response.status_code == 201:
            return response.json()

        if response.status_code == 403:
            # Verification challenge
            challenge_data = response.json()
            verified = await self._solve_verification(challenge_data)
            if not verified:
                logger.error("Moltbook verification failed — cannot post")
                return None
            # Retry post after verification
            response2 = await self._post_raw("/posts", payload)
            if response2 and response2.status_code in (200, 201):
                return response2.json()

        logger.warning("Moltbook post failed: %s %s", response.status_code, response.text[:200])
        return None

    async def comment(self, post_id: str, content: str) -> dict[str, Any] | None:
        """Add a comment to a post, handling verification challenge."""
        payload = {"post_id": post_id, "content": content}
        response = await self._post_raw("/comments", payload)
        if response is None:
            return None

        if response.status_code in (200, 201):
            return response.json()

        if response.status_code == 403:
            challenge_data = response.json()
            verified = await self._solve_verification(challenge_data)
            if not verified:
                logger.error("Moltbook verification failed — cannot comment")
                return None
            response2 = await self._post_raw("/comments", payload)
            if response2 and response2.status_code in (200, 201):
                return response2.json()

        logger.warning("Moltbook comment failed: %s %s", response.status_code, response.text[:200])
        return None

    async def upvote(self, post_id: str) -> bool:
        """Upvote a post. Returns True on success."""
        result = await self._post(f"/posts/{post_id}/upvote", {})
        return result is not None

    async def follow(self, agent_name: str) -> bool:
        """Follow another molty. Returns True on success."""
        result = await self._post(f"/follow/{agent_name}", {})
        return result is not None

    async def search(self, query: str, **kwargs: Any) -> list[dict[str, Any]]:
        """Semantic search for relevant conversations."""
        params = {"q": query, **kwargs}
        result = await self._get("/search", params=params)
        if result is None:
            return []
        return result if isinstance(result, list) else result.get("results", [])

    # ------------------------------------------------------------------
    # Verification challenge solver
    # ------------------------------------------------------------------

    def _parse_verification_challenge(self, challenge_text: str) -> float | None:
        """
        Parse an obfuscated math problem:
          - Alternating caps + symbols like []^-/
          - Strip symbols, lowercase, extract two numbers + operator
          - Compute with 2 decimal places
        Returns the numeric answer, or None if parsing fails.
        """
        try:
            # Remove obfuscation: strip non-alphanumeric except +, -, *, /
            cleaned = re.sub(r"[^a-zA-Z0-9+\-*/\s.]", " ", challenge_text)
            cleaned = cleaned.lower().strip()

            # Extract numbers and operator
            # Matches patterns like "12 plus 34", "5 times 3", "10 divided by 2",
            # or plain "12 + 34", "5 * 3", "10 / 2", "7 - 3"
            word_ops = {
                "plus": "+",
                "add": "+",
                "minus": "-",
                "subtract": "-",
                "times": "*",
                "multiply": "*",
                "multiplied": "*",
                "divided": "/",
                "divide": "/",
                "over": "/",
            }
            for word, sym in word_ops.items():
                cleaned = cleaned.replace(word, sym)

            # Find two numbers and an operator
            m = re.search(r"(\d+(?:\.\d+)?)\s*([+\-*/])\s*(\d+(?:\.\d+)?)", cleaned)
            if not m:
                logger.warning("Could not parse verification challenge: %r", challenge_text)
                return None

            a = float(m.group(1))
            op = m.group(2)
            b = float(m.group(3))

            if op == "+":
                result = a + b
            elif op == "-":
                result = a - b
            elif op == "*":
                result = a * b
            elif op == "/":
                if b == 0:
                    return None
                result = a / b
            else:
                return None

            return round(result, 2)

        except Exception as exc:
            logger.warning("Verification parse error: %s", exc)
            return None

    async def _solve_verification(self, challenge_data: dict[str, Any]) -> bool:
        """
        Solve a Moltbook verification challenge and POST the answer.
        Returns True if the verification succeeded.
        """
        challenge_text = (
            challenge_data.get("challenge")
            or challenge_data.get("question")
            or challenge_data.get("message", "")
        )
        challenge_id = challenge_data.get("id") or challenge_data.get("challenge_id", "")

        if not challenge_text:
            logger.warning("Moltbook verification: no challenge text in response")
            return False

        answer = self._parse_verification_challenge(challenge_text)
        if answer is None:
            return False

        logger.info("Moltbook verification: challenge=%r answer=%.2f", challenge_text, answer)

        payload: dict[str, Any] = {"answer": f"{answer:.2f}"}
        if challenge_id:
            payload["challenge_id"] = challenge_id

        response = await self._post_raw("/verify", payload)
        if response is None:
            return False

        if response.status_code in (200, 201):
            logger.info("Moltbook verification passed.")
            return True

        logger.warning("Moltbook verification rejected: %s", response.text[:200])
        return False

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _check_rate_limit(self, response: httpx.Response) -> None:
        remaining = response.headers.get("X-RateLimit-Remaining")
        if remaining is not None:
            try:
                if int(remaining) <= 2:
                    logger.warning("Moltbook rate limit low: %s remaining", remaining)
            except ValueError:
                pass

    async def _get(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> Any:
        if not self._client:
            return None
        try:
            response = await self._client.get(path, params=params)
            self._check_rate_limit(response)

            if response.status_code == 429:
                logger.warning("Moltbook 429 on GET %s — backing off %ds", path, RATE_LIMIT_BACKOFF)
                await asyncio.sleep(RATE_LIMIT_BACKOFF)
                return None

            response.raise_for_status()
            return response.json()

        except httpx.HTTPStatusError as exc:
            logger.error("Moltbook GET %s failed: %s", path, exc)
            return None
        except httpx.RequestError as exc:
            logger.error("Moltbook GET %s network error: %s", path, exc)
            return None

    async def _post(self, path: str, payload: dict[str, Any]) -> Any:
        response = await self._post_raw(path, payload)
        if response is None:
            return None
        if response.status_code in (200, 201):
            return response.json()
        logger.warning("Moltbook POST %s → %s", path, response.status_code)
        return None

    async def _post_raw(
        self,
        path: str,
        payload: dict[str, Any],
    ) -> httpx.Response | None:
        if not self._client:
            return None
        try:
            response = await self._client.post(path, json=payload)
            self._check_rate_limit(response)

            if response.status_code == 429:
                logger.warning("Moltbook 429 on POST %s — backing off %ds", path, RATE_LIMIT_BACKOFF)
                await asyncio.sleep(RATE_LIMIT_BACKOFF)
                return None

            return response

        except httpx.RequestError as exc:
            logger.error("Moltbook POST %s network error: %s", path, exc)
            return None
