"""Telegram channel adapter — raw HTTP polling (no python-telegram-bot dependency).

Simple, reliable, zero event loop conflicts. Uses httpx directly.
"""

from __future__ import annotations

import asyncio
import logging
import os

import httpx

from .base import BaseChannel, InboundMessage, MessageHandler, OutboundMessage

logger = logging.getLogger(__name__)


class TelegramChannel(BaseChannel):
    name = "telegram"

    def __init__(self, handler: MessageHandler, token: str | None = None) -> None:
        super().__init__(handler)
        self._token = token or os.environ.get("TELEGRAM_BOT_TOKEN", "")
        self._base = f"https://api.telegram.org/bot{self._token}"
        self._running = False
        self._offset = 0

    async def start(self) -> None:
        if not self._token:
            raise ValueError("TELEGRAM_BOT_TOKEN is not set.")

        # Verify bot
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(f"{self._base}/getMe")
            data = resp.json()
            if not data.get("ok"):
                raise ValueError(f"Telegram bot token invalid: {data}")
            bot_name = data["result"].get("username", "unknown")
            logger.info("Telegram connected: @%s", bot_name)

        self._running = True
        logger.info("Telegram polling started")

        async with httpx.AsyncClient(timeout=35) as client:
            while self._running:
                try:
                    resp = await client.get(
                        f"{self._base}/getUpdates",
                        params={
                            "offset": self._offset,
                            "timeout": 30,
                            "allowed_updates": '["message"]',
                        },
                    )
                    data = resp.json()

                    if not data.get("ok"):
                        logger.warning("Telegram getUpdates error: %s", data)
                        await asyncio.sleep(5)
                        continue

                    for update in data.get("result", []):
                        self._offset = update["update_id"] + 1
                        message = update.get("message")
                        if not message or not message.get("text"):
                            continue

                        user = message.get("from", {})
                        chat_id = message["chat"]["id"]
                        text = message["text"]

                        logger.info(
                            "Telegram message from @%s: %s",
                            user.get("username", "unknown"),
                            text[:50],
                        )

                        msg = InboundMessage(
                            text=text,
                            user_id=str(user.get("id", "unknown")),
                            channel="telegram",
                            thread_id=str(chat_id),
                            metadata={
                                "chat_id": chat_id,
                                "username": user.get("username"),
                                "first_name": user.get("first_name"),
                            },
                        )

                        try:
                            reply = await self.handle(msg)
                            logger.info("Reply: %s", reply[:100])
                            await client.post(
                                f"{self._base}/sendMessage",
                                json={"chat_id": chat_id, "text": reply},
                            )
                        except Exception as exc:
                            logger.error("Handle/reply error: %s", exc, exc_info=True)
                            await client.post(
                                f"{self._base}/sendMessage",
                                json={
                                    "chat_id": chat_id,
                                    "text": f"Sorry, I hit an error: {exc}",
                                },
                            )

                except httpx.ReadTimeout:
                    # Normal — long polling timeout, just retry
                    continue
                except Exception as exc:
                    logger.error("Telegram poll error: %s", exc, exc_info=True)
                    await asyncio.sleep(5)

    async def stop(self) -> None:
        self._running = False
        logger.info("Telegram channel stopped")

    async def send(self, message: OutboundMessage) -> None:
        chat_id = message.metadata.get("chat_id") or message.user_id
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                f"{self._base}/sendMessage",
                json={"chat_id": chat_id, "text": message.text},
            )
