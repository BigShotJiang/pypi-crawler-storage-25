# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Tool registry — maps tool names to callable implementations.

Tools are registered with @registry.register("tool_name") and
retrieved by the agent at call time.  Each tool must declare its
action_type so the Warden can gate it.

Trust model
-----------
Any Python module that imports this registry can call register().
Without a trust model, a malicious or careless third-party package
could register `exec` under action_type="web.search" and bypass the
Warden entirely — the governance pitch is only as strong as the link
between a tool's behavior and its declared action_type.

Every ToolDefinition now carries a `source` field (the module that
registered it, captured via the call stack). The environment variable
CLAWTEX_TRUSTED_TOOL_MODULES controls what's accepted:

  - Unset (default) — all registrations accepted; untrusted sources
    are logged at WARNING. Compatible with existing deployments.
  - Set to a comma-separated list of module prefixes — only matching
    sources may register tools. Everything else is rejected with
    UntrustedToolSource.
  - Set to "strict:<prefixes>" — same as above but raises on violation
    rather than just refusing the single tool.

Example:
  CLAWTEX_TRUSTED_TOOL_MODULES=clawtex.tools,an2b_tools
"""

from __future__ import annotations

import inspect
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine

logger = logging.getLogger(__name__)

ToolFn = Callable[..., Coroutine[Any, Any, Any]]


class UntrustedToolSource(Exception):
    """Raised when a tool registration violates CLAWTEX_TRUSTED_TOOL_MODULES."""


@dataclass
class ToolDefinition:
    name: str
    action_type: str  # used by Warden (e.g. "web.search", "exec", "file.read")
    description: str
    fn: ToolFn
    parameters: dict[str, Any] = field(default_factory=dict)
    source: str = "unknown"  # Python module that called register()
    trusted: bool = True  # False if source is outside CLAWTEX_TRUSTED_TOOL_MODULES


def _resolve_source() -> str:
    """
    Walk the call stack to find the first caller outside this module.
    That's the module that invoked register() — the tool's source of truth.
    """
    for frame_info in inspect.stack()[1:]:
        module = inspect.getmodule(frame_info.frame)
        if module is None:
            continue
        mod_name = getattr(module, "__name__", "")
        if not mod_name or mod_name == __name__:
            continue
        return mod_name
    return "unknown"


def _parse_trusted_modules() -> tuple[list[str], bool]:
    """
    Returns (prefix_list, strict_mode).

    Env var formats:
      ""                         → ([], False)  permissive; warn on untrusted
      "clawtex.tools,an2b_tools" → (["clawtex.tools", "an2b_tools"], False)
      "strict:clawtex.tools"     → (["clawtex.tools"], True)  hard-reject
    """
    raw = os.environ.get("CLAWTEX_TRUSTED_TOOL_MODULES", "").strip()
    if not raw:
        return [], False
    strict = False
    if raw.startswith("strict:"):
        strict = True
        raw = raw[len("strict:"):]
    prefixes = [p.strip() for p in raw.split(",") if p.strip()]
    return prefixes, strict


def _is_trusted(source: str, prefixes: list[str]) -> bool:
    """A source is trusted if it matches any prefix (exact or dotted child)."""
    if not prefixes:
        return True  # no policy configured — everything's trusted by default
    return any(source == p or source.startswith(p + ".") for p in prefixes)


class ToolRegistry:
    """Central registry for all ClawTex tools."""

    def __init__(self) -> None:
        self._tools: dict[str, ToolDefinition] = {}

    def register(
        self,
        name: str,
        action_type: str,
        description: str,
        parameters: dict[str, Any] | None = None,
    ) -> Callable[[ToolFn], ToolFn]:
        """Decorator factory for registering a tool."""
        source = _resolve_source()
        trusted_prefixes, strict = _parse_trusted_modules()
        trusted = _is_trusted(source, trusted_prefixes)

        def decorator(fn: ToolFn) -> ToolFn:
            if not trusted:
                msg = (
                    f"Tool '{name}' registered from untrusted source '{source}' "
                    f"(action_type={action_type}). "
                    f"Trusted prefixes: {trusted_prefixes or 'NONE — all sources allowed'}."
                )
                if strict:
                    logger.error("[REGISTRY/REJECT] %s", msg)
                    raise UntrustedToolSource(msg)
                logger.warning("[REGISTRY/UNTRUSTED] %s", msg)

            defn = ToolDefinition(
                name=name,
                action_type=action_type,
                description=description,
                fn=fn,
                parameters=parameters or {},
                source=source,
                trusted=trusted,
            )
            self._tools[name] = defn
            logger.debug(
                "Tool registered: %s (action_type=%s, source=%s, trusted=%s)",
                name, action_type, source, trusted,
            )
            return fn

        return decorator

    def untrusted(self) -> list[ToolDefinition]:
        """Return the set of tools whose source is outside the trusted prefix list."""
        return [t for t in self._tools.values() if not t.trusted]

    def get(self, name: str) -> ToolDefinition | None:
        return self._tools.get(name)

    def all(self) -> list[ToolDefinition]:
        return list(self._tools.values())

    def to_openai_schema(self) -> list[dict[str, Any]]:
        """Return tools in OpenAI function-calling schema format."""
        schema = []
        for t in self._tools.values():
            schema.append(
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.parameters
                        or {"type": "object", "properties": {}},
                    },
                }
            )
        return schema

    def to_anthropic_schema(self) -> list[dict[str, Any]]:
        """Return tools in Anthropic tool-use schema format."""
        schema = []
        for t in self._tools.values():
            schema.append(
                {
                    "name": t.name,
                    "description": t.description,
                    "input_schema": t.parameters
                    or {"type": "object", "properties": {}},
                }
            )
        return schema


# Module-level singleton registry
registry = ToolRegistry()
