# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""ClawTex tools — registry + built-in tool implementations."""

from .registry import ToolDefinition, ToolRegistry, registry

# Import tool modules so their @registry.register decorators fire on import
from . import web_search, file_ops, exec_tool  # noqa: F401

__all__ = ["registry", "ToolRegistry", "ToolDefinition"]
