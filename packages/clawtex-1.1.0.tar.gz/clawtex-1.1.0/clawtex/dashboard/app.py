# ClawTex Dashboard — Lightweight governance & memory UI
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
FastAPI dashboard for ClawTex agent framework.

Serves HTML pages for monitoring governance decisions, browsing memories,
and viewing agent configuration. No heavy frontend — Jinja2 + vanilla CSS.
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

logger = logging.getLogger(__name__)

_DIR = Path(__file__).parent
_TEMPLATES_DIR = _DIR / "templates"
_STATIC_DIR = _DIR / "static"

app = FastAPI(title="ClawTex Dashboard", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")
templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))


# ---------------------------------------------------------------------------
# Helpers — lazy-loaded so the dashboard works even without full ClawTex setup
# ---------------------------------------------------------------------------

def _get_audit_logger():
    """Return an AuditLogger instance, or None if unavailable."""
    try:
        from clawtex.governance.audit_logger import AuditLogger
        return AuditLogger()
    except Exception:
        logger.debug("AuditLogger not available")
        return None


def _get_mandeldb_client():
    """Return a MandelDBClient instance, or None if env vars missing."""
    try:
        from clawtex.memory.mandeldb import MandelDBClient
        return MandelDBClient()
    except Exception:
        logger.debug("MandelDBClient not available (env vars missing?)")
        return None


def _find_file(*candidates: str) -> str | None:
    """Return the content of the first file found from a list of candidates."""
    for path_str in candidates:
        p = Path(path_str)
        if p.exists():
            try:
                return p.read_text(encoding="utf-8")
            except Exception:
                pass
    return None


def _get_soul_content() -> str | None:
    """Read SOUL.md from common locations."""
    return _find_file(
        os.environ.get("CLAWTEX_SOUL_PATH", "SOUL.md"),
        "SOUL.md",
        "soul.md",
        os.path.join(os.environ.get("CLAWTEX_CONFIG_DIR", "."), "SOUL.md"),
    )


def _get_warden_policy() -> str | None:
    """Read Warden policy YAML from common locations."""
    return _find_file(
        os.environ.get("CLAWTEX_WARDEN_POLICY", "warden_policy.yaml"),
        "warden_policy.yaml",
        "warden_policy.yml",
        "policy.yaml",
        os.path.join(os.environ.get("CLAWTEX_CONFIG_DIR", "."), "warden_policy.yaml"),
    )


def _get_skills() -> list[dict[str, str]]:
    """List installed skills from the skills directory."""
    skills_dir = Path(os.environ.get("CLAWTEX_SKILLS_DIR", "./skills"))
    skills = []
    if skills_dir.exists():
        for item in skills_dir.iterdir():
            if item.is_dir() and (item / "manifest.yaml").exists():
                skills.append({"name": item.name, "path": str(item)})
            elif item.is_dir() and (item / "manifest.yml").exists():
                skills.append({"name": item.name, "path": str(item)})
    return skills


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def overview(request: Request):
    """Overview page — agent status, memory stats, recent governance decisions."""
    audit = _get_audit_logger()
    all_entries = audit.query(limit=1000) if audit else []
    recent = all_entries[-10:] if all_entries else []
    recent.reverse()

    namespace = os.environ.get("CLAWTEX_EIDETIC_NAMESPACE", "") or os.environ.get("CLAWTEX_NAMESPACE", "default")
    memory_count = "N/A"

    # Try to get memory stats via MandelDB
    client = _get_mandeldb_client()
    if client:
        try:
            import httpx
            stats_url = f"{client.base_url}/v2/brain/stats"
            async with httpx.AsyncClient(
                headers=dict(client._client.headers),
                timeout=10.0,
            ) as http:
                resp = await http.get(stats_url, params={"namespace": namespace})
                if resp.status_code == 200:
                    data = resp.json()
                    memory_count = data.get("total_memories", data.get("count", "N/A"))
        except Exception as e:
            logger.debug("Could not fetch memory stats: %s", e)
        finally:
            await client.close()

    return templates.TemplateResponse("overview.html", {
        "request": request,
        "active": "overview",
        "audit_count": len(all_entries),
        "recent_decisions": recent,
        "namespace": namespace,
        "memory_count": memory_count,
    })


@app.get("/audit", response_class=HTMLResponse)
async def audit_trail(
    request: Request,
    decision: str = Query(default="", alias="decision"),
    tenant: str = Query(default="", alias="tenant"),
):
    """Audit trail page — governance log viewer with filtering."""
    audit = _get_audit_logger()
    entries = []
    if audit:
        entries = audit.query(
            decision=decision if decision else None,
            tenant_id=tenant if tenant else None,
            limit=200,
        )
        entries.reverse()  # Most recent first

    return templates.TemplateResponse("audit.html", {
        "request": request,
        "active": "audit",
        "entries": entries,
        "filter_decision": decision,
        "filter_tenant": tenant,
    })


@app.get("/memory", response_class=HTMLResponse)
async def memory_browser(
    request: Request,
    q: str = Query(default="", alias="q"),
    namespace: str = Query(default="", alias="namespace"),
):
    """Memory browser — search and browse MandelDB memories."""
    ns = namespace or os.environ.get("CLAWTEX_EIDETIC_NAMESPACE", "") or os.environ.get("CLAWTEX_NAMESPACE", "default")
    memories: list[dict[str, Any]] = []
    stats: dict[str, Any] | None = None
    error: str | None = None

    client = _get_mandeldb_client()
    if client:
        try:
            # Fetch brain stats
            import httpx
            stats_url = f"{client.base_url}/v2/brain/stats"
            async with httpx.AsyncClient(
                headers=dict(client._client.headers),
                timeout=10.0,
            ) as http:
                resp = await http.get(stats_url, params={"namespace": ns})
                if resp.status_code == 200:
                    stats = resp.json()

            # Search if query provided
            if q:
                memories = await client.recall(query=q, top_k=20, namespace=ns)
        except Exception as e:
            error = str(e)
        finally:
            await client.close()
    elif q:
        error = (
            "Memory not configured. "
            "Run `clawtex init` or set CLAWTEX_EIDETIC_URL and CLAWTEX_EIDETIC_KEY."
        )

    return templates.TemplateResponse("memory.html", {
        "request": request,
        "active": "memory",
        "query": q,
        "namespace": ns,
        "memories": memories,
        "stats": stats,
        "error": error,
    })


@app.get("/config", response_class=HTMLResponse)
async def config_view(request: Request):
    """Config page — view SOUL.md, Warden policy, loaded skills."""
    return templates.TemplateResponse("config.html", {
        "request": request,
        "active": "config",
        "soul_content": _get_soul_content(),
        "warden_content": _get_warden_policy(),
        "skills": _get_skills(),
    })


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_dashboard(host: str = "0.0.0.0", port: int = 8080) -> None:
    """Start the dashboard server."""
    import uvicorn
    print(f"\n  ClawTex Dashboard starting on http://{host}:{port}\n")
    uvicorn.run(app, host=host, port=port, log_level="info")
