# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Factory — stamps out new ClawTex instances from the template.

Usage:
    clawtex new-instance shepherd
    clawtex new-instance joey --template deployments/custom-template

Creates deployments/<name>/ with all files parameterized.
The only creative work left is writing SOUL.md and adding skills.
"""

from __future__ import annotations

import os
import shutil
from pathlib import Path


def _find_template_dir(custom: str | None = None) -> Path:
    """Locate the factory template directory."""
    if custom:
        p = Path(custom)
        if p.is_dir():
            return p
        raise FileNotFoundError(f"Template dir not found: {custom}")

    # Walk up from this file to find the repo root with deployments/_template
    candidates = [
        Path(__file__).parent.parent / "deployments" / "_template",
        Path.cwd() / "deployments" / "_template",
    ]
    for c in candidates:
        if c.is_dir():
            return c

    raise FileNotFoundError(
        "Could not find deployments/_template/. "
        "Run this from the clawtex repo root, or use --template."
    )


def _slugify(name: str) -> str:
    """Convert instance name to a safe slug for dirs and env vars."""
    return name.lower().strip().replace(" ", "-").replace("_", "-")


def _env_name(name: str) -> str:
    """Convert instance name to a display name (title case)."""
    return name.replace("-", " ").replace("_", " ").title()


def stamp_instance(name: str, template_dir: str | None = None) -> bool:
    """
    Stamp out a new ClawTex instance from the factory template.

    Creates deployments/<name>/ with all template placeholders replaced.
    Returns True on success, False on failure.
    """
    slug = _slugify(name)
    display = _env_name(name)

    try:
        template = _find_template_dir(template_dir)
    except FileNotFoundError as exc:
        print(f"  Error: {exc}")
        return False

    dest = template.parent / slug
    if dest.exists():
        print(f"  Error: {dest} already exists. Delete it first or choose a different name.")
        return False

    # Copy template
    shutil.copytree(template, dest)

    # Template substitutions
    replacements = {
        "{{INSTANCE_NAME}}": slug,
        "{{DISPLAY_NAME}}": display,
        "{{INSTANCE_SCHEMA}}": slug.replace("-", "_"),
        "my-instance": slug,
        "my_instance": slug.replace("-", "_"),
        "MyInstance": display.replace(" ", ""),
    }

    # Process all text files
    text_extensions = {".md", ".py", ".yaml", ".yml", ".sh", ".env", ".example", ".txt"}
    for fpath in dest.rglob("*"):
        if not fpath.is_file():
            continue
        if fpath.suffix not in text_extensions and fpath.name not in (".env.example",):
            continue

        try:
            content = fpath.read_text(encoding="utf-8")
            original = content
            for placeholder, value in replacements.items():
                content = content.replace(placeholder, value)
            if content != original:
                fpath.write_text(content, encoding="utf-8")
        except (UnicodeDecodeError, PermissionError):
            continue

    print(f"\n  ClawTex instance '{slug}' created at:")
    print(f"  {dest}\n")
    print(f"  Next steps:")
    print(f"  1. Edit SOUL.md — define the personality (the creative work)")
    print(f"  2. Add skills to skills/ — domain-specific SKILL.md files")
    print(f"  3. Copy .env.example to .env and fill in API keys")
    print(f"  4. Test locally: cd {dest} && python serve.py")
    print(f"  5. Deploy: ./deploy.sh")
    print(f"\n  BB4C.\n")
    return True
