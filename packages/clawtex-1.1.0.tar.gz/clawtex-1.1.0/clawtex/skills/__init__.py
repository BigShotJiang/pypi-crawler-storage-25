# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""ClawTex skills subsystem — loader and skill registry."""

from .loader import Skill, SkillLoader

__all__ = ["SkillLoader", "Skill"]
