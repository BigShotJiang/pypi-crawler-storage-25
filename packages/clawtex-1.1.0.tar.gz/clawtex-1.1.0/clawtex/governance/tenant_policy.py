"""
Multi-tenant policy composition for ClawTex governance.

Implements 3-layer policy composition:
  base (AN2B safety invariants) + vertical (industry template) + customer (tenant overrides)
  = final composed policy

Key principle: DENY ALWAYS WINS.
  - Base DENY rules are immutable (cannot be overridden)
  - Customers can only ADD restrictions (DENY/REVIEW), never remove base restrictions
  - When in doubt, the more restrictive decision wins
"""

from __future__ import annotations

import fnmatch
import logging
from pathlib import Path
from typing import Any

import yaml

from clawtex.governance.warden import Policy, PolicyRule, Decision

logger = logging.getLogger(__name__)


def _restrictiveness(decision: str) -> int:
    """Higher number = more restrictive."""
    return {"DENY": 3, "REVIEW": 2, "ALLOW": 1}.get(decision.upper(), 0)


def _patterns_overlap(pattern_a: str, pattern_b: str) -> bool:
    """Check if two glob patterns could match the same action string."""
    return (
        fnmatch.fnmatch(pattern_a, pattern_b)
        or fnmatch.fnmatch(pattern_b, pattern_a)
        or pattern_a == pattern_b
    )


class PolicyConflict:
    """A detected conflict between policy rules."""
    def __init__(self, severity: str, message: str, rule_a: PolicyRule, rule_b: PolicyRule):
        self.severity = severity  # "CRITICAL", "WARNING", "INFO"
        self.message = message
        self.rule_a = rule_a
        self.rule_b = rule_b

    def __repr__(self):
        return f"PolicyConflict({self.severity}: {self.message})"


class ComposedPolicy:
    """A policy composed from base + vertical + customer layers."""

    def __init__(self, rules: list[PolicyRule], default: Decision, conflicts: list[PolicyConflict]):
        self.rules = rules
        self.default = default
        self.conflicts = conflicts

    def evaluate(self, action_type: str) -> Decision:
        """Evaluate action against the composed rule set (first-match-wins)."""
        for rule in self.rules:
            if rule.matches(action_type):
                return rule.decision
        return self.default

    @staticmethod
    def compose(
        base: Policy,
        vertical: Policy | None = None,
        customer: Policy | None = None,
    ) -> "ComposedPolicy":
        """Compose 3 policy layers into a single policy.

        Composition order (first match wins):
        1. Base DENY rules (immutable safety invariants)
        2. Customer DENY rules (customer can restrict themselves)
        3. Customer REVIEW rules
        4. Vertical rules (in order)
        5. Base ALLOW/REVIEW rules (lowest priority)

        Default: most restrictive of all layers.
        """
        conflicts: list[PolicyConflict] = []
        final_rules: list[PolicyRule] = []

        # Phase 1: Base DENY rules — immutable safety invariants
        for rule in base.rules:
            if rule.decision == "DENY":
                final_rules.append(rule)

        # Phase 2: Detect conflicts if customer tries to weaken base DENYs
        if customer:
            for cust_rule in customer.rules:
                for base_rule in base.rules:
                    if _patterns_overlap(cust_rule.action, base_rule.action):
                        if cust_rule.decision == "ALLOW" and base_rule.decision == "DENY":
                            conflicts.append(PolicyConflict(
                                severity="CRITICAL",
                                message=f"Customer cannot ALLOW '{cust_rule.action}' — base policy DENYs it",
                                rule_a=base_rule,
                                rule_b=cust_rule,
                            ))

        # Phase 3: Customer DENY rules
        if customer:
            for rule in customer.rules:
                if rule.decision == "DENY":
                    final_rules.append(rule)

        # Phase 4: Customer REVIEW rules
        if customer:
            for rule in customer.rules:
                if rule.decision == "REVIEW":
                    final_rules.append(rule)

        # Phase 5: Vertical rules
        if vertical:
            for rule in vertical.rules:
                final_rules.append(rule)

        # Phase 6: Base ALLOW/REVIEW rules
        for rule in base.rules:
            if rule.decision != "DENY":
                final_rules.append(rule)

        # Default: most restrictive
        defaults = [base.default]
        if vertical:
            defaults.append(vertical.default)
        if customer:
            defaults.append(customer.default)
        composed_default = max(defaults, key=_restrictiveness)

        return ComposedPolicy(final_rules, composed_default, conflicts)


class TenantPolicyLoader:
    """Load and compose policies for a specific tenant."""

    def __init__(self, policies_dir: str | Path):
        self.policies_dir = Path(policies_dir)
        self._cache: dict[str, ComposedPolicy] = {}

    def _load_policy_file(self, path: Path) -> Policy | None:
        """Load a policy file, returning None if not found."""
        if not path.exists():
            return None
        return Policy(path)

    def load_composed(
        self,
        tenant_id: str,
        vertical: str | None = None,
    ) -> ComposedPolicy:
        """Load and compose the policy for a tenant.

        Looks for:
          - {policies_dir}/base.yaml (required)
          - {policies_dir}/verticals/{vertical}.yaml (optional)
          - {policies_dir}/tenants/{tenant_id}.yaml (optional)
        """
        cache_key = f"{tenant_id}:{vertical or 'none'}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        base_path = self.policies_dir / "base.yaml"
        if not base_path.exists():
            # Fall back to default.yaml if base.yaml doesn't exist
            base_path = self.policies_dir / "default.yaml"

        base = Policy(base_path)

        vertical_policy = None
        if vertical:
            vertical_path = self.policies_dir / "verticals" / f"{vertical}.yaml"
            vertical_policy = self._load_policy_file(vertical_path)

        customer_policy = None
        customer_path = self.policies_dir / "tenants" / f"{tenant_id}.yaml"
        customer_policy = self._load_policy_file(customer_path)

        composed = ComposedPolicy.compose(base, vertical_policy, customer_policy)
        self._cache[cache_key] = composed

        logger.info(
            "Composed policy for tenant=%s vertical=%s: %d rules, %d conflicts, default=%s",
            tenant_id, vertical, len(composed.rules), len(composed.conflicts), composed.default,
        )
        return composed

    def invalidate(self, tenant_id: str | None = None):
        """Clear cached policies. Call after policy file changes."""
        if tenant_id:
            keys = [k for k in self._cache if k.startswith(f"{tenant_id}:")]
            for k in keys:
                del self._cache[k]
        else:
            self._cache.clear()
