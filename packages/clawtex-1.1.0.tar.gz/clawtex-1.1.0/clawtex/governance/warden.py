# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Warden — governance layer for ClawTex.

Every tool call passes through Warden.check() before execution.
Decisions: ALLOW | DENY | REVIEW

Policy is loaded from a YAML file (default: ./clawtex/governance/policies/default.yaml).
The policy file path is resolved from the WARDEN_POLICY env var or the constructor argument.

WARDEN_MODE:
  enforce  — DENY blocks execution, REVIEW pauses for approval callback (default)
  audit    — log decisions but always allow (useful for testing)
  strict   — treat REVIEW the same as DENY (no human-in-the-loop)
"""

from __future__ import annotations

import datetime
import fnmatch
import logging
import os
from pathlib import Path
from typing import Any, Callable, Coroutine, Literal

import yaml

logger = logging.getLogger(__name__)

Decision = Literal["ALLOW", "DENY", "REVIEW"]
Mode = Literal["enforce", "audit", "strict"]

# Type alias for an optional async approval callback
ApprovalCallback = Callable[[str, dict[str, Any]], Coroutine[Any, Any, bool]]

# Action types that must NEVER be silently allowed by audit mode.
# Even when the Warden is configured to log-and-continue, these actions
# retain enforce-mode semantics — a DENY blocks, a REVIEW requires approval.
#
# This closes a sharp edge: flipping WARDEN_MODE=audit (advertised as "useful
# for testing") must not become a backdoor to RCE or destructive data loss.
# Supports fnmatch globs just like policy rules.
NEVER_AUDIT_BYPASS: frozenset[str] = frozenset({
    "exec",
    "exec.*",
    "file.delete",
    "email.delete",
    "db.drop",
    "db.truncate",
})


def _matches_never_audit(action_type: str) -> bool:
    """True if this action_type must enforce decisions regardless of mode."""
    return any(fnmatch.fnmatch(action_type, pat) for pat in NEVER_AUDIT_BYPASS)


def _utc_now_z() -> str:
    """Timezone-aware UTC timestamp in ISO-8601 with a Z suffix."""
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def _dig(obj: Any, dotted_key: str) -> Any:
    """
    Resolve a dotted key against a nested mapping.

    >>> _dig({"input": {"path": "/tmp/x"}}, "input.path")
    '/tmp/x'
    >>> _dig({"a": {}}, "a.missing") is None
    True
    """
    cur = obj
    for part in dotted_key.split("."):
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
        if cur is None:
            return None
    return cur


def _url_host(url: str) -> str:
    """Best-effort URL hostname extraction, lowercased. Empty string on failure."""
    import urllib.parse
    try:
        return (urllib.parse.urlparse(url).hostname or "").lower()
    except Exception:  # noqa: BLE001
        return ""


def _as_list(v: Any) -> list[Any]:
    return v if isinstance(v, list) else [v]


def _condition_matches(value: Any, operators: dict[str, Any]) -> bool:
    """
    Evaluate a dict of operators against a single context value.

    Supported operators:
      equals:      exact ==
      not_equals:  exact !=
      in:          value in [list]
      not_in:      value not in [list]
      glob:        fnmatch(value, pattern) — pattern may be str or [str]
      regex:       re.search(pattern, value)
      host_in:     urlparse(value).hostname in [list] (case-insensitive)
      host_suffix: urlparse(value).hostname ends with any suffix (case-insensitive)

    Multiple operators AND together. A value of None only matches
    not_equals/not_in/glob (no match), never equals/in/regex.
    """
    import re as _re

    for op, expected in operators.items():
        if op == "equals":
            if value != expected:
                return False
        elif op == "not_equals":
            if value == expected:
                return False
        elif op == "in":
            if value not in _as_list(expected):
                return False
        elif op == "not_in":
            if value in _as_list(expected):
                return False
        elif op == "glob":
            if value is None or not any(
                fnmatch.fnmatch(str(value), p) for p in _as_list(expected)
            ):
                return False
        elif op == "regex":
            if value is None or not _re.search(str(expected), str(value)):
                return False
        elif op == "host_in":
            host = _url_host(str(value or ""))
            wanted = [str(h).lower() for h in _as_list(expected)]
            if host == "" or host not in wanted:
                return False
        elif op == "host_suffix":
            host = _url_host(str(value or ""))
            suffixes = [str(s).lower() for s in _as_list(expected)]
            if host == "" or not any(host == s or host.endswith("." + s) for s in suffixes):
                return False
        else:
            logger.warning("Unknown policy condition operator: %r — rule won't match", op)
            return False
    return True


class PolicyRule:
    """
    A single action→decision rule.

    Supports:
      - glob patterns on action_type (file.*, email.*)
      - optional `when:` conditions on context (path, url, recipient, etc.)

    If `when` is set and the context doesn't match, the rule is skipped
    entirely — evaluation falls through to the next rule. This lets you
    write layered policies (ALLOW for safe subset, REVIEW for the rest).
    """

    def __init__(
        self,
        action: str,
        decision: Decision,
        when: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        self.action = action
        self.decision = decision
        self.when = when or {}

    def matches(self, action_type: str, context: dict[str, Any] | None = None) -> bool:
        if not fnmatch.fnmatch(action_type, self.action):
            return False
        if not self.when:
            return True
        ctx = context or {}
        for key, operators in self.when.items():
            value = _dig(ctx, key)
            if not _condition_matches(value, operators):
                return False
        return True


class Policy:
    """Parsed YAML policy — a list of rules plus a default decision."""

    def __init__(self, path: str | Path) -> None:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"Warden policy file not found: {path}")
        with path.open() as fh:
            raw = yaml.safe_load(fh)

        self.version: int = raw.get("version", 1)
        self.default: Decision = raw.get("default", "ALLOW").upper()  # type: ignore[assignment]
        self.rules: list[PolicyRule] = [
            PolicyRule(
                action=r["action"],
                decision=r["decision"].upper(),  # type: ignore[arg-type]
                when=r.get("when"),
            )
            for r in raw.get("rules", [])
        ]

    def evaluate(
        self,
        action_type: str,
        context: dict[str, Any] | None = None,
    ) -> Decision:
        """Return the first matching rule's decision, or the default."""
        for rule in self.rules:
            if rule.matches(action_type, context):
                return rule.decision  # type: ignore[return-value]
        return self.default  # type: ignore[return-value]


class Warden:
    """
    Governance engine — loads a policy and enforces it on tool calls.

    Usage:
        warden = Warden()
        decision = warden.check("file.delete", {"path": "/etc/passwd"})
        # → "DENY"
    """

    def __init__(
        self,
        policy_path: str | Path | None = None,
        mode: Mode | None = None,
        approval_callback: ApprovalCallback | None = None,
        audit_logger: "AuditLogger | None" = None,
        tenant_id: str | None = None,
    ) -> None:
        resolved_path = policy_path or os.environ.get(
            "WARDEN_POLICY",
            Path(__file__).parent / "policies" / "default.yaml",
        )
        self.policy = Policy(resolved_path)
        self.mode: Mode = (
            mode or os.environ.get("WARDEN_MODE", "enforce")
        ).lower()  # type: ignore[assignment]
        self._approval_callback = approval_callback
        self._log: list[dict[str, Any]] = []
        self._audit_logger = audit_logger
        self._tenant_id = tenant_id

        logger.info(
            "Warden initialised — policy v%d, mode=%s, default=%s, rules=%d",
            self.policy.version,
            self.mode,
            self.policy.default,
            len(self.policy.rules),
        )

    # ------------------------------------------------------------------
    # Core check — synchronous path
    # ------------------------------------------------------------------

    def check(self, action_type: str, context: dict[str, Any] | None = None) -> Decision:
        """
        Evaluate *action_type* against the loaded policy.

        Returns "ALLOW", "DENY", or "REVIEW".
        DENY and REVIEW decisions are always logged.

        In *audit* mode all decisions return as-evaluated but execution is never
        blocked — the caller is responsible for honouring the decision.
        """
        context = context or {}
        decision = self.policy.evaluate(action_type, context)

        # Audit mode: report the real decision but don't expect the caller to
        # block — except for NEVER_AUDIT_BYPASS action_types, which must always
        # enforce. See enforce_decision() for the authoritative caller rule.
        if self.mode == "audit" and not _matches_never_audit(action_type):
            if decision != "ALLOW":
                self._record(action_type, decision, context)
                logger.info(
                    "[WARDEN/audit] %s → %s (would block in enforce mode)",
                    action_type,
                    decision,
                )
            return decision

        if self.mode == "strict":
            # Treat REVIEW the same as DENY
            if decision == "REVIEW":
                decision = "DENY"

        if decision in ("DENY", "REVIEW"):
            self._record(action_type, decision, context)
            if decision == "DENY":
                logger.warning(
                    "[WARDEN/DENY] action=%s context=%s", action_type, context
                )
            else:
                logger.warning(
                    "[WARDEN/REVIEW] action=%s context=%s (awaiting approval)",
                    action_type,
                    context,
                )

        return decision

    # ------------------------------------------------------------------
    # Async check — supports approval callbacks for REVIEW
    # ------------------------------------------------------------------

    async def check_async(
        self,
        action_type: str,
        context: dict[str, Any] | None = None,
    ) -> Decision:
        """
        Async variant of check().

        If the decision is REVIEW and an approval_callback was registered,
        the callback is awaited.  If it returns True the final decision is
        ALLOW; otherwise DENY.
        """
        decision = self.check(action_type, context)

        if decision == "REVIEW" and self._approval_callback is not None:
            approved = await self._approval_callback(action_type, context or {})
            if approved:
                logger.info(
                    "[WARDEN/REVIEW] action=%s approved by callback", action_type
                )
                return "ALLOW"
            else:
                logger.warning(
                    "[WARDEN/REVIEW] action=%s denied by callback", action_type
                )
                return "DENY"

        return decision

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _record(
        self, action_type: str, decision: Decision, context: dict[str, Any]
    ) -> None:
        entry = {
            "timestamp": _utc_now_z(),
            "action": action_type,
            "decision": decision,
            "context": context,
        }
        self._log.append(entry)

        # Persist to audit logger if available
        if self._audit_logger:
            self._audit_logger.record(action_type, decision, context, self._tenant_id)

    @property
    def audit_log(self) -> list[dict[str, Any]]:
        """Return all recorded DENY/REVIEW decisions."""
        return list(self._log)

    def enforce_decision(self, action_type: str, decision: Decision) -> bool:
        """
        Authoritative answer to: should the caller block on this decision?

        Callers (like agent.breathe()) should treat this as the contract —
        never independently reinterpret mode + decision, since that's how
        bypass bugs creep in.

        Rules:
          - DENY       → always block
          - REVIEW     → block in enforce/strict mode, or when the action
                         is in NEVER_AUDIT_BYPASS (even in audit mode)
          - ALLOW      → never block
        """
        if decision == "DENY":
            return True
        if decision == "REVIEW":
            if self.mode in ("enforce", "strict"):
                return True
            # audit mode: block only for never-bypass actions
            return _matches_never_audit(action_type)
        return False

    def reload_policy(self, path: str | Path | None = None) -> bool:
        """
        Hot-reload the policy file.

        Safe against malformed YAML: on any error, the previous policy
        remains in effect and the failure is logged. Returns True on
        successful reload, False if the new file was rejected.
        """
        resolved = path or os.environ.get(
            "WARDEN_POLICY",
            Path(__file__).parent / "policies" / "default.yaml",
        )
        try:
            new_policy = Policy(resolved)
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "Warden policy reload FAILED — keeping previous policy in effect: %s",
                exc,
            )
            return False

        self.policy = new_policy
        logger.info("Warden policy reloaded from %s", resolved)
        return True
