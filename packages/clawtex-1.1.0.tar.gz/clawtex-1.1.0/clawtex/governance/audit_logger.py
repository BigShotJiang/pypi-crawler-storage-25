"""
Persistent audit logger for Warden governance decisions.

Writes all DENY and REVIEW decisions to a file-based append-only log.
Optionally forwards to MandelDB for long-term storage and querying.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


class AuditLogger:
    """Persistent, append-only audit log for governance decisions."""

    def __init__(
        self,
        log_dir: str | Path | None = None,
        mandeldb_url: str | None = None,
        mandeldb_key: str | None = None,
        namespace: str = "governance_audit",
    ):
        self.log_dir = Path(log_dir or os.environ.get(
            "CLAWTEX_AUDIT_DIR", ".clawtex-audit"
        ))
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._log_file = self.log_dir / "warden_audit.jsonl"
        self._mandeldb_url = mandeldb_url or os.environ.get("CLAWTEX_MEMORY_URL", "")
        self._mandeldb_key = mandeldb_key or os.environ.get("CLAWTEX_MEMORY_KEY", "")
        self._namespace = namespace

    def record(
        self,
        action_type: str,
        decision: str,
        context: dict[str, Any],
        tenant_id: str | None = None,
    ) -> dict[str, Any]:
        """Record a governance decision to persistent storage."""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": action_type,
            "decision": decision,
            "context": context,
            "tenant_id": tenant_id,
        }

        # Write to local append-only log file
        try:
            with self._log_file.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry) + "\n")
        except Exception as e:
            logger.warning("Failed to write audit log to file: %s", e)

        return entry

    def query(
        self,
        tenant_id: str | None = None,
        decision: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Query the audit log, optionally filtered by tenant or decision type."""
        results = []
        try:
            if not self._log_file.exists():
                return []
            with self._log_file.open("r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    entry = json.loads(line)
                    if tenant_id and entry.get("tenant_id") != tenant_id:
                        continue
                    if decision and entry.get("decision") != decision:
                        continue
                    results.append(entry)
        except Exception as e:
            logger.warning("Failed to read audit log: %s", e)
        return results[-limit:]  # Return most recent entries
