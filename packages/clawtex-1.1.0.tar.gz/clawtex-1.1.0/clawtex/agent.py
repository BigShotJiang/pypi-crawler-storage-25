# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
ClawTex Agent — the core runtime.

Loop (per message):
  1. receive message
  2. recall memories from MandelDB   (memory before action)
  3. build prompt (SOUL.md + memories + skills context + message)
  4. call LLM  (Anthropic or OpenAI, based on LLM_PROVIDER)
  5. for each tool call:
       breathe()  →  Warden checks policy  →  ALLOW / DENY / REVIEW
       execute or block accordingly
  6. ingest exchange to MandelDB     (memory after action)
  7. return final response

The method is named breathe() because governance isn't a gate —
it's a pause, a breath, a moment of intentionality before every action.
BB4C: Breath Before Code.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any

from .channels.base import InboundMessage
from .governance.warden import Decision, Warden
from .memory.context import MemoryContext
from .memory.mandeldb import MandelDBClient
from .memory.startup import on_start as brain_on_start


def _build_memory_client():
    """
    Select the memory backend based on MEMORY_BACKEND env var.

    - "pgvector": direct Postgres + pgvector (for personal advisors)
    - "mandeldb" or unset: MandelDB Cloud Run service (default)
    """
    backend = os.environ.get("MEMORY_BACKEND", "mandeldb").lower()
    if backend == "pgvector":
        from .memory.pgvector_backend import PgVectorClient
        return PgVectorClient()
    return MandelDBClient()

from .routing import IntentRouter, IntentTier
from .skills.loader import SkillLoader
from .observability.tracer import Tracer
from .observability.cost import CostTracker
from .tools.registry import ToolDefinition, registry as tool_registry

logger = logging.getLogger(__name__)

_SOUL_PATH = os.environ.get("CLAWTEX_SOUL", "./SOUL.md")
_LLM_PROVIDER = os.environ.get("LLM_PROVIDER", "anthropic").lower()
_CLAWTEX_NAME = os.environ.get("CLAWTEX_NAME", "ClawTex")


def _load_soul() -> str:
    path = Path(_SOUL_PATH)
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    return (
        f"You are {_CLAWTEX_NAME}, a governed AI agent with persistent memory. "
        "You act with intention, governed by policy, and remember what matters."
    )


class BlockedByWarden(Exception):
    """Raised when the Warden denies a tool call."""
    def __init__(self, action_type: str, tool_name: str) -> None:
        self.action_type = action_type
        self.tool_name = tool_name
        super().__init__(
            f"Warden DENIED tool '{tool_name}' (action_type={action_type})"
        )


class ClawTexAgent:
    """
    The ClawTex agent runtime.

    All tool executions pass through breathe() — the Warden governance check.
    Memory is recalled before every response and ingested after every exchange.
    """

    def __init__(
        self,
        name: str | None = None,
        warden: Warden | None = None,
        memory: MemoryContext | None = None,
        skills_dir: str | None = None,
    ) -> None:
        self.name = name or _CLAWTEX_NAME
        self.warden = warden or Warden()
        self._memory_client = _build_memory_client()
        self.memory = memory or MemoryContext(
            client=self._memory_client, namespace=self.name.lower().replace(" ", "_")
        )
        self._skill_loader = SkillLoader(skills_dir or os.environ.get("CLAWTEX_SKILLS_DIR", "./skills"))
        self._skills = self._skill_loader.load_all()
        self._soul = _load_soul()
        self._startup_context: str = ""  # populated by start()
        self._dream_task: asyncio.Task | None = None  # type: ignore[type-arg]
        self.router = IntentRouter(agent_name=self.name)
        self.tracer = Tracer(agent_name=self.name)
        self.cost_tracker = CostTracker(agent_name=self.name)

        logger.info(
            "ClawTex agent '%s' initialised — provider=%s, skills=%d, tools=%d",
            self.name,
            _LLM_PROVIDER,
            len(self._skills),
            len(tool_registry.all()),
        )

    # ------------------------------------------------------------------
    # 🧠 start() — Brain reconnect on session startup
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """
        Initialize the agent's brain — pull recent memories from MandelDB.

        Call this once after construction (or after a blackout) to restore
        context from the last session. The recalled memories are injected
        into every subsequent system prompt automatically.

        Fail-open: if MandelDB is unreachable, the agent continues without
        startup context (degraded but functional).

        BB4C: memory before action. Always.
        """
        logger.info("Brain startup — recalling recent context for '%s'…", self.name)
        try:
            self._startup_context = await brain_on_start(
                client=self._memory_client,
                namespace=self.name.lower().replace(" ", "_"),
            )
            if self._startup_context:
                logger.info("Brain reconnect successful — context injected into system prompt.")
            else:
                logger.info("Brain reconnect: no prior memories found (clean slate).")
        except Exception as exc:  # noqa: BLE001
            logger.warning("Brain startup failed (fail-open, continuing): %s", exc)
            self._startup_context = ""

    # ------------------------------------------------------------------
    # 🫁 breathe() — Warden governance gate
    # ------------------------------------------------------------------

    async def breathe(
        self,
        tool: ToolDefinition,
        tool_input: dict[str, Any],
    ) -> Decision:
        """
        Pause and consult the Warden before executing any tool call.

        This is the philosophical core of ClawTex: every action is preceded
        by a breath — a moment of intentional governance.  BB4C.

        Returns the Warden's decision: "ALLOW", "DENY", or "REVIEW".
        Raises BlockedByWarden if the decision is DENY.
        """
        context = {
            "tool": tool.name,
            "input": tool_input,
            "agent": self.name,
        }
        decision = await self.warden.check_async(tool.action_type, context)

        # Delegate the "should I block?" question to the Warden. This keeps
        # the mode/never-bypass logic in one place — agent just honors the
        # contract. BB4C: the breath itself doesn't decide, it consults.
        if self.warden.enforce_decision(tool.action_type, decision):
            logger.warning(
                "[breathe] BLOCKED — tool=%s action_type=%s decision=%s mode=%s",
                tool.name,
                tool.action_type,
                decision,
                self.warden.mode,
            )
            raise BlockedByWarden(tool.action_type, tool.name)

        if decision == "REVIEW":
            # We're here because enforce_decision said "don't block" — i.e.
            # audit mode and action is not in NEVER_AUDIT_BYPASS.
            logger.info(
                "[breathe] REVIEW (audit mode) — allowing tool=%s", tool.name
            )

        return decision

    # ------------------------------------------------------------------
    # Main handle loop
    # ------------------------------------------------------------------

    async def handle_message(self, message: InboundMessage) -> str:
        """
        Full agent loop for a single inbound message.

        The Intent Router classifies the message first — cheap messages
        get cheap responses. BB4C: don't overthink a handshake.

        Tiers:
          INSTANT  → canned reply, no LLM, no memory (< 1ms)
          LIGHT    → LLM with SOUL only, skip memory recall
          STANDARD → full pipeline (recall + LLM + ingest)
          DEEP     → full pipeline + extended token budget
        """
        with self.tracer.span("handle_message") as trace:
            trace.set_tag("channel", message.channel)
            trace.set_tag("user_id", message.user_id)

            user_text = message.text

            # Step 0 — classify intent (synchronous, ~0ms)
            routing = self.router.classify(user_text)
            trace.set_tag("intent_tier", routing.tier.value)
            trace.set_tag("intent_reason", routing.reason)
            logger.info("Intent: tier=%s reason=%s", routing.tier.value, routing.reason)

            # ── INSTANT: canned reply, skip everything ──
            if routing.tier == IntentTier.INSTANT:
                reply = routing.instant_reply or "I'm here."
                # Fire-and-forget ingest — don't block the response on network I/O
                asyncio.create_task(self.memory.record_exchange(
                    user_message=user_text,
                    assistant_reply=reply,
                    extra_metadata={
                        "channel": message.channel,
                        "user_id": message.user_id,
                        "intent_tier": "instant",
                    },
                ))
                return reply

            # ── LIGHT: LLM with SOUL + memory, but no skills/tools ──
            # Memory IS the product for personal advisors. We skip skills
            # (expensive context) and tools, but always pull memory so the
            # bot remembers what was just said. Hybrid recall (semantic +
            # recent) keeps this cheap and contextual.
            if routing.tier == IntentTier.LIGHT:
                with self.tracer.span("memory_recall"):
                    memory_context = await self.memory.build(user_text)
                system_prompt = self._build_system_prompt(memory_context, skill_content=None, tier=IntentTier.LIGHT)
                try:
                    reply = await self._llm_loop(system_prompt, user_text, tier=IntentTier.LIGHT)
                except Exception as exc:  # noqa: BLE001
                    logger.error("LLM error: %s", exc)
                    trace.set_error(str(exc))
                    reply = f"I encountered an error processing your message: {exc}"

                with self.tracer.span("memory_ingest"):
                    await self.memory.record_exchange(
                        user_message=user_text,
                        assistant_reply=reply,
                        extra_metadata={
                            "channel": message.channel,
                            "user_id": message.user_id,
                            "intent_tier": "light",
                        },
                    )
                return reply

            # ── STANDARD / DEEP: full pipeline ──

            # Step 1 — recall relevant memories
            with self.tracer.span("memory_recall"):
                memory_context = await self.memory.build(user_text)

            # Step 1b — check if a skill applies to this message
            matched_skill_name = self._skill_loader.match_skill(user_text)
            skill_content: str | None = None
            if matched_skill_name:
                skill_content = self._skill_loader.get_skill(matched_skill_name)
                logger.info("Skill matched for message: %s", matched_skill_name)
                trace.set_tag("skill", matched_skill_name)

            # Step 2 — build system prompt
            system_prompt = self._build_system_prompt(memory_context, skill_content=skill_content, tier=routing.tier)

            # Step 3 — call LLM (with tool-use loop)
            try:
                reply = await self._llm_loop(system_prompt, user_text, tier=routing.tier)
            except Exception as exc:  # noqa: BLE001
                logger.error("LLM error: %s", exc)
                trace.set_error(str(exc))
                reply = f"I encountered an error processing your message: {exc}"

            # Step 4 — ingest exchange to memory
            with self.tracer.span("memory_ingest"):
                await self.memory.record_exchange(
                    user_message=user_text,
                    assistant_reply=reply,
                    extra_metadata={
                        "channel": message.channel,
                        "user_id": message.user_id,
                        "intent_tier": routing.tier.value,
                    },
                )

            return reply

    # ------------------------------------------------------------------
    # LLM dispatch — Anthropic or OpenAI
    # ------------------------------------------------------------------

    # Token budgets per tier — LIGHT is cheap, DEEP gets room to think
    _MAX_TOKENS = {
        IntentTier.LIGHT: 1024,
        IntentTier.STANDARD: 4096,
        IntentTier.DEEP: 8192,
    }

    async def _llm_loop(self, system_prompt: str, user_text: str, tier: IntentTier = IntentTier.STANDARD) -> str:
        """Dispatch to the configured LLM provider and handle tool-use loops."""
        if _LLM_PROVIDER == "anthropic":
            return await self._anthropic_loop(system_prompt, user_text, tier=tier)
        elif _LLM_PROVIDER in ("openai", "openai-compatible"):
            return await self._openai_loop(system_prompt, user_text, tier=tier)
        else:
            raise ValueError(f"Unknown LLM_PROVIDER: {_LLM_PROVIDER!r}")

    async def _anthropic_loop(self, system_prompt: str, user_text: str, tier: IntentTier = IntentTier.STANDARD) -> str:
        try:
            import anthropic
        except ImportError as exc:
            raise ImportError("anthropic package not installed. pip install anthropic") from exc

        client = anthropic.AsyncAnthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        model = os.environ.get("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
        # LIGHT tier: no tools (faster, cheaper). STANDARD/DEEP: full tools.
        tools_schema = tool_registry.to_anthropic_schema() if tier != IntentTier.LIGHT else []
        max_tokens = self._MAX_TOKENS.get(tier, 4096)
        messages: list[dict[str, Any]] = [{"role": "user", "content": user_text}]

        while True:
            response = await client.messages.create(
                model=model,
                max_tokens=max_tokens,
                system=system_prompt,
                tools=tools_schema if tools_schema else anthropic.NOT_GIVEN,
                messages=messages,
            )

            # Collect text from the response
            text_parts = [
                block.text for block in response.content if hasattr(block, "text")
            ]

            if response.stop_reason == "tool_use":
                # Append assistant message with the full content
                messages.append({"role": "assistant", "content": response.content})

                # Execute tool calls (each gated by breathe())
                tool_results = []
                for block in response.content:
                    if block.type != "tool_use":
                        continue
                    result = await self._execute_tool(block.name, block.input)
                    tool_results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": json.dumps(result),
                        }
                    )

                messages.append({"role": "user", "content": tool_results})
                continue  # loop for follow-up response

            # stop_reason == "end_turn" or similar
            return "\n".join(text_parts).strip() or "(no response)"

    async def _openai_loop(self, system_prompt: str, user_text: str, tier: IntentTier = IntentTier.STANDARD) -> str:
        try:
            from openai import AsyncOpenAI
        except ImportError as exc:
            raise ImportError("openai package not installed. pip install openai") from exc

        client = AsyncOpenAI(
            api_key=os.environ.get("OPENAI_API_KEY", ""),
            base_url=os.environ.get("OPENAI_BASE_URL"),  # supports compatible APIs
        )
        model = os.environ.get("OPENAI_MODEL", "gpt-4o")
        # LIGHT tier: no tools. STANDARD/DEEP: full tools.
        tools_schema = tool_registry.to_openai_schema() if tier != IntentTier.LIGHT else []
        max_tokens = self._MAX_TOKENS.get(tier, 4096)
        messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_text},
        ]

        while True:
            kwargs: dict[str, Any] = {
                "model": model,
                "messages": messages,
                "max_tokens": max_tokens,
            }
            if tools_schema:
                kwargs["tools"] = tools_schema

            response = await client.chat.completions.create(**kwargs)
            msg = response.choices[0].message

            if msg.tool_calls:
                messages.append(msg)  # assistant message with tool_calls
                for tc in msg.tool_calls:
                    tool_input = json.loads(tc.function.arguments)
                    result = await self._execute_tool(tc.function.name, tool_input)
                    messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": json.dumps(result),
                        }
                    )
                continue  # loop for follow-up response

            return (msg.content or "").strip() or "(no response)"

    # ------------------------------------------------------------------
    # Tool execution — always gated by breathe()
    # ------------------------------------------------------------------

    async def _execute_tool(
        self, tool_name: str, tool_input: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Look up the tool, call breathe() for governance, then execute.

        Returns the tool's result dict, or an error dict if blocked/failed.
        """
        tool = tool_registry.get(tool_name)
        if tool is None:
            logger.warning("Unknown tool requested: %s", tool_name)
            return {"error": f"Unknown tool: {tool_name}"}

        with self.tracer.span("tool_exec") as tool_span:
            tool_span.set_tag("tool", tool_name)
            tool_span.set_tag("action_type", tool.action_type)

            try:
                decision = await self.breathe(tool, tool_input)
                tool_span.set_tag("decision", str(decision))
            except BlockedByWarden as exc:
                tool_span.set_tag("decision", "DENY")
                logger.info("Tool blocked by Warden: %s", exc)
                return {
                    "error": f"Action blocked by governance policy (action_type={exc.action_type})",
                    "blocked": True,
                }

            logger.debug("breathe() → %s for tool=%s", decision, tool_name)

            try:
                result = await tool.fn(**tool_input)
                return result if isinstance(result, dict) else {"result": result}
            except Exception as exc:  # noqa: BLE001
                tool_span.set_error(str(exc))
                logger.error("Tool execution error (%s): %s", tool_name, exc)
                return {"error": str(exc)}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_system_prompt(
        self,
        memory_context: str,
        skill_content: str | None = None,
        tier: IntentTier = IntentTier.STANDARD,
    ) -> str:
        parts = [self._soul]

        # Memory context — ALWAYS include if provided. For personal advisors,
        # memory is the product. We never strip it. Even LIGHT tier gets
        # memory; only INSTANT (canned reply) skips it.
        if self._startup_context:
            parts.append(self._startup_context)
        if memory_context:
            parts.append(memory_context)

        # Skills — skip for LIGHT (no need to route to skills for simple questions)
        if tier not in (IntentTier.LIGHT,):
            skills_block = self._skill_loader.to_context_block()
            if skills_block:
                parts.append(
                    skills_block + "\n\n"
                    "Before responding, check if a skill applies. "
                    "If one clearly matches the user's request, read its full content "
                    "(provided below as <active_skill>) and follow its instructions."
                )
            if skill_content:
                parts.append(f"<active_skill>\n{skill_content}\n</active_skill>")

        parts.append(
            "## Governance\n"
            "Every tool call you make is reviewed by the Warden governance layer. "
            "Destructive or outbound actions may be blocked or queued for human approval. "
            "Act with intention. BB4C — Breath Before Code."
        )
        return "\n\n".join(parts)

    # ------------------------------------------------------------------
    # Dream scheduler — periodic memory consolidation
    # ------------------------------------------------------------------

    async def start_dream_scheduler(self) -> None:
        """
        Periodically trigger MandelDB memory consolidation (dreaming).
        Interval is controlled by DREAM_INTERVAL_HOURS (default 6h).
        """
        interval_hours = float(os.environ.get("DREAM_INTERVAL_HOURS", "6"))
        interval_secs = interval_hours * 3600

        async def _dream_loop() -> None:
            while True:
                await asyncio.sleep(interval_secs)
                try:
                    logger.info("Triggering MandelDB dream for namespace=%s…", self.memory.namespace)
                    result = await self.memory.trigger_dream()
                    logger.info("Dream complete: %s", result)
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Dream failed (non-fatal): %s", exc)

        self._dream_task = asyncio.create_task(_dream_loop())
        logger.info("Dream scheduler started (interval=%.1fh)", interval_hours)

    async def close(self) -> None:
        if self._dream_task:
            self._dream_task.cancel()
        await self._memory_client.close()
