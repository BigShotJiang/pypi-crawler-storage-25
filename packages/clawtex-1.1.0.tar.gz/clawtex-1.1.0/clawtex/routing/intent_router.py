# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
Intent Router — The Arrow Filter.

Classifies inbound messages by depth so the agent loop can skip
expensive steps (memory recall, full LLM, tool schemas) when they
aren't needed.

Tiers:
  INSTANT  — greetings, thanks, emoji, social fluff → canned response, no LLM
  LIGHT    — simple questions, status checks        → small LLM call, no memory recall
  STANDARD — business questions, data lookups       → full pipeline (current default)
  DEEP     — multi-step analysis, trend comparisons → full pipeline + extended budget

Classification is intentionally cheap:
  1. Regex/keyword match handles INSTANT (zero cost)
  2. Heuristics (word count, question markers) separate LIGHT from STANDARD
  3. Depth markers (comparisons, time ranges, "analyze") escalate to DEEP
  4. Optional Haiku classifier for ambiguous cases (off by default)
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class IntentTier(str, Enum):
    INSTANT = "instant"
    LIGHT = "light"
    STANDARD = "standard"
    DEEP = "deep"


@dataclass
class RoutingResult:
    """Result of intent classification."""
    tier: IntentTier
    reason: str
    instant_reply: str | None = None  # pre-built reply for INSTANT tier


# ------------------------------------------------------------------
# Pattern banks
# ------------------------------------------------------------------

# Greeting / farewell / social — immediate canned response
_INSTANT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"^(hey|hi|hello|yo|sup|what'?s? ?up|howdy|hola|morning|evening|afternoon)\s*(norman|norm|buddy|boss|man|bro|dude)?[!.\s?]*$", re.IGNORECASE),
    re.compile(r"^(good\s+)?(morning|evening|afternoon|night)\s*(norman|norm)?[!.\s]*$", re.IGNORECASE),
    re.compile(r"^(thanks?|thank\s*you|thx|ty|appreciate\s*it|nice|perfect|great|awesome|cool|ok|okay|got\s*it|noted|bet|word|dope|sweet|solid|love\s*it)[!.\s]*$", re.IGNORECASE),
    re.compile(r"^(bye|goodbye|later|peace|see\s*ya|ttyl|gotta\s*go|talk\s*soon|signing\s*off)[!.\s]*$", re.IGNORECASE),
    re.compile(r"^(lol|haha|heh|😂|🤣|👍|👋|🙏|💪|🔥|❤️|✅|💯)[!.\s]*$", re.IGNORECASE),
    re.compile(r"^(yes|no|yep|nope|yeah|nah|sure|absolutely|definitely|correct)[!.\s]*$", re.IGNORECASE),
    re.compile(r"^(you\s*there|norman|norm)\s*\??[!.\s]*$", re.IGNORECASE),
]

# Instant reply templates — keyed by which pattern group matched
_INSTANT_REPLIES: dict[str, list[str]] = {
    "greeting": [
        "Hey there. What can I help with?",
        "I'm here. What's on your mind?",
        "Hi. What do you need?",
    ],
    "thanks": [
        "You got it.",
        "Anytime.",
        "👍",
    ],
    "farewell": [
        "Later, James. I'll be here.",
        "✌️ I'll keep watch.",
    ],
    "reaction": [
        "👍",
    ],
    "affirmative": [
        "Got it.",
        "Understood.",
    ],
    "ping": [
        "I'm here. What do you need?",
        "Right here. What's up?",
    ],
}

# Map pattern index → reply category
_PATTERN_CATEGORIES = [
    "greeting",    # 0: hey/hi/hello
    "greeting",    # 1: good morning/evening
    "thanks",      # 2: thanks/great/cool
    "farewell",    # 3: bye/later
    "reaction",    # 4: lol/emoji
    "affirmative", # 5: yes/no/sure
    "ping",        # 6: you there?/norman?
]

# Deep analysis markers — presence of these escalates to DEEP
_DEEP_MARKERS: list[re.Pattern[str]] = [
    re.compile(r"\b(analy[sz]e|compare|trend|correlat|forecast|predict|project|breakdown|deep\s*dive)\b", re.IGNORECASE),
    re.compile(r"\b(across\s+all|every\s+salon|all\s+\d+|all\s+locations?|quarter|q[1-4]|year[\s-]over[\s-]year|yoy|month[\s-]over[\s-]month|mom)\b", re.IGNORECASE),
    re.compile(r"\b(recommend|strategy|plan|optimize|restructure|why\s+are|root\s+cause|what\s+should)\b", re.IGNORECASE),
    re.compile(r"\b(vs\.?|versus|compared?\s+to|relative\s+to|benchmark)\b", re.IGNORECASE),
]

# Memory-question markers — questions that require recall of previous context.
# Even if the message is short, these MUST get full pipeline (not LIGHT) because
# the user is explicitly asking the bot to remember something.
_MEMORY_QUESTION_MARKERS: list[re.Pattern[str]] = [
    re.compile(r"\b(remember|recall|forgot|forget)\b", re.IGNORECASE),
    re.compile(r"\b(what\s+did\s+i|what\s+did\s+we|what\s+have\s+i|what\s+have\s+we)\b", re.IGNORECASE),
    re.compile(r"\b(you\s+said|i\s+said|we\s+talked|we\s+discussed|we\s+were\s+talking|i\s+told\s+you|i\s+mentioned)\b", re.IGNORECASE),
    re.compile(r"\b(earlier|before|previously|yesterday|last\s+(?:time|week|month))\b", re.IGNORECASE),
    re.compile(r"\b(do\s+you\s+know|did\s+i\s+tell|did\s+we|have\s+i\s+(?:told|shared|mentioned))\b", re.IGNORECASE),
]


# ------------------------------------------------------------------
# Router
# ------------------------------------------------------------------

class IntentRouter:
    """
    Classifies messages into tiers before they hit the agent pipeline.

    Usage:
        router = IntentRouter()
        result = router.classify("hey Norman")
        if result.tier == IntentTier.INSTANT:
            return result.instant_reply  # skip everything
    """

    def __init__(self, agent_name: str = "Norman") -> None:
        self.agent_name = agent_name
        self._use_haiku = os.environ.get("INTENT_ROUTER_USE_HAIKU", "").lower() in ("1", "true", "yes")
        self._instant_counter = 0  # rotate replies so Norman doesn't sound robotic
        logger.info("IntentRouter initialized (haiku_classifier=%s)", self._use_haiku)

    def classify(self, text: str) -> RoutingResult:
        """
        Classify a message into an intent tier. Synchronous and fast.

        Returns RoutingResult with tier, reason, and optional instant_reply.
        """
        stripped = text.strip()

        # Empty or whitespace-only
        if not stripped:
            return RoutingResult(
                tier=IntentTier.INSTANT,
                reason="empty message",
                instant_reply="I'm here if you need something.",
            )

        # ------ INSTANT tier: regex match ------
        for i, pattern in enumerate(_INSTANT_PATTERNS):
            if pattern.match(stripped):
                category = _PATTERN_CATEGORIES[i] if i < len(_PATTERN_CATEGORIES) else "greeting"
                replies = _INSTANT_REPLIES.get(category, _INSTANT_REPLIES["greeting"])
                reply = replies[self._instant_counter % len(replies)]
                self._instant_counter += 1

                logger.debug("INSTANT match: pattern=%d category=%s", i, category)
                return RoutingResult(
                    tier=IntentTier.INSTANT,
                    reason=f"pattern:{category}",
                    instant_reply=reply,
                )

        # ------ Word count heuristics ------
        words = stripped.split()
        word_count = len(words)

        # ------ Business context markers — force at least STANDARD ------
        has_business_context = bool(re.search(
            r"\b(salon|revenue|sales|staffing|schedule|employee|stylist|"
            r"red\s*flag|metric|customer|appointment|payroll|inventory|"
            r"profit|loss|cost|budget|performance|numbers?|data|report)\b",
            stripped, re.IGNORECASE,
        ))

        # ------ Memory-question marker — force STANDARD ------
        # Even short messages like "What did I just tell you?" must get the
        # full pipeline because the user is asking the bot to remember.
        # LIGHT tier skips skills/tools but still has memory recall, but
        # for memory-explicit questions we want full processing including
        # skill matching (e.g. "remember when I asked about Salon 14?").
        is_memory_question = any(p.search(stripped) for p in _MEMORY_QUESTION_MARKERS)
        if is_memory_question:
            return RoutingResult(
                tier=IntentTier.STANDARD,
                reason="memory_question",
            )

        # ------ DEEP tier: analysis markers ------
        deep_hits = sum(1 for p in _DEEP_MARKERS if p.search(stripped))
        if deep_hits >= 2 or (deep_hits >= 1 and word_count > 20):
            return RoutingResult(
                tier=IntentTier.DEEP,
                reason=f"deep_markers={deep_hits}, words={word_count}",
            )

        # ------ LIGHT tier: short, simple questions (no business keywords) ------
        if word_count <= 6 and not has_business_context and not any(p.search(stripped) for p in _DEEP_MARKERS):
            return RoutingResult(
                tier=IntentTier.LIGHT,
                reason=f"short_message, words={word_count}",
            )

        # ------ Default: STANDARD ------
        return RoutingResult(
            tier=IntentTier.STANDARD,
            reason=f"default, words={word_count}",
        )

    async def classify_with_fallback(self, text: str) -> RoutingResult:
        """
        Classify with optional Haiku LLM fallback for ambiguous cases.

        Currently just wraps classify(). When INTENT_ROUTER_USE_HAIKU=true,
        ambiguous STANDARD-tier messages get a cheap Haiku call to confirm.
        """
        result = self.classify(text)

        # For now, Haiku classifier is a future enhancement.
        # The regex + heuristic approach handles 80%+ of messages correctly.
        # When enabled, it would only fire for STANDARD tier to confirm
        # whether the message is actually LIGHT or DEEP.

        return result
