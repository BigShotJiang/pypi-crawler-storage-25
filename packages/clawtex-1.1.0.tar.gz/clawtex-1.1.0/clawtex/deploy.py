# ClawTex — Deploy to Cloud Run
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
clawtex deploy — one-command deployment to Google Cloud Run.

Generates a Dockerfile (if needed), builds the container image via
Cloud Build, and deploys to Cloud Run with the right env vars.

Usage:
  clawtex deploy                           Deploy with defaults
  clawtex deploy --name my-agent           Custom service name
  clawtex deploy --project my-gcp-project  Specific GCP project
  clawtex deploy --region us-central1      Specific region
  clawtex deploy --env-file .env.prod      Load env vars from file
  clawtex deploy --dry-run                 Show what would happen

Requirements:
  - gcloud CLI installed and authenticated
  - A GCP project with Cloud Run and Cloud Build APIs enabled
"""

from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path

logger = logging.getLogger("clawtex.deploy")

_DOCKERFILE_TEMPLATE = """\
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt* pyproject.toml* ./
RUN pip install --no-cache-dir clawtex[all] || pip install --no-cache-dir -r requirements.txt

# Copy agent code
COPY . .

# ClawTex listens on PORT (Cloud Run provides this)
ENV PORT=8080
EXPOSE 8080

# Start the agent
CMD ["python", "-m", "clawtex", "start", "--channel", "all"]
"""

_DOCKERIGNORE_TEMPLATE = """\
__pycache__
*.pyc
.env
.env.*
!.env.example
.git
.venv
venv
node_modules
.pytest_cache
dist
*.egg-info
"""


def _run(cmd: list[str], dry_run: bool = False, check: bool = True) -> subprocess.CompletedProcess:
    """Run a shell command, or just print it in dry-run mode."""
    cmd_str = " ".join(cmd)
    if dry_run:
        print(f"  [dry-run] {cmd_str}")
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    logger.info("Running: %s", cmd_str)
    return subprocess.run(cmd, check=check, capture_output=True, text=True, timeout=300)


def _detect_gcloud() -> str | None:
    """Find gcloud binary."""
    gcloud = "gcloud.cmd" if os.name == "nt" else "gcloud"
    if shutil.which(gcloud):
        return gcloud
    return None


def _get_project(gcloud: str) -> str:
    """Get the current GCP project."""
    result = subprocess.run(
        [gcloud, "config", "get-value", "project"],
        capture_output=True, text=True, timeout=15,
    )
    return result.stdout.strip()


def deploy(
    name: str = "clawtex-agent",
    project: str | None = None,
    region: str = "us-east1",
    env_file: str | None = None,
    memory: str = "512Mi",
    cpu: str = "1",
    min_instances: int = 0,
    max_instances: int = 3,
    allow_unauthenticated: bool = False,
    dry_run: bool = False,
) -> bool:
    """Deploy a ClawTex agent to Google Cloud Run.

    Returns True on success.
    """
    print("\n  ClawTex Deploy — Cloud Run\n")

    # 1. Check gcloud
    gcloud = _detect_gcloud()
    if gcloud is None:
        print("  [ERR] gcloud CLI not found. Install: https://cloud.google.com/sdk/docs/install")
        return False
    print("  [OK] gcloud found")

    # 2. Resolve project
    if not project:
        project = _get_project(gcloud)
    if not project:
        print("  [ERR] No GCP project set. Run: gcloud config set project YOUR_PROJECT")
        return False
    print(f"  [OK] Project: {project}")
    print(f"  [OK] Region: {region}")
    print(f"  [OK] Service: {name}")

    # 3. Ensure Dockerfile exists
    cwd = Path.cwd()
    dockerfile = cwd / "Dockerfile"
    created_dockerfile = False
    if not dockerfile.exists():
        print("  --> Generating Dockerfile...")
        if not dry_run:
            dockerfile.write_text(_DOCKERFILE_TEMPLATE)
        created_dockerfile = True
        print("  [OK] Dockerfile created")
    else:
        print("  [OK] Dockerfile exists")

    # Ensure .dockerignore
    dockerignore = cwd / ".dockerignore"
    if not dockerignore.exists():
        if not dry_run:
            dockerignore.write_text(_DOCKERIGNORE_TEMPLATE)
        print("  [OK] .dockerignore created")

    # 4. Load env vars for Cloud Run
    env_vars: dict[str, str] = {}
    env_keys_to_forward = [
        "CLAWTEX_NAME", "LLM_PROVIDER",
        "ANTHROPIC_API_KEY", "OPENAI_API_KEY",
        "MANDELDB_URL", "MANDELDB_API_KEY",
        "TELEGRAM_BOT_TOKEN", "SLACK_BOT_TOKEN", "SLACK_APP_TOKEN",
        "BRAVE_API_KEY", "WARDEN_MODE",
    ]

    if env_file:
        env_path = Path(env_file)
        if env_path.exists():
            for line in env_path.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    env_vars[key.strip()] = value.strip().strip('"').strip("'")
            print(f"  [OK] Loaded {len(env_vars)} vars from {env_file}")

    # Forward current env vars if not in file
    for key in env_keys_to_forward:
        if key not in env_vars and os.environ.get(key):
            env_vars[key] = os.environ[key]

    # 5. Build image via Cloud Build
    image = f"gcr.io/{project}/{name}"
    print(f"\n  Building image: {image}")
    _run([gcloud, "builds", "submit", "--tag", image, "--project", project, "."], dry_run=dry_run)
    print("  [OK] Image built")

    # 6. Deploy to Cloud Run
    deploy_cmd = [
        gcloud, "run", "deploy", name,
        "--image", image,
        "--region", region,
        "--project", project,
        "--memory", memory,
        "--cpu", cpu,
        "--min-instances", str(min_instances),
        "--max-instances", str(max_instances),
        "--platform", "managed",
    ]

    if allow_unauthenticated:
        deploy_cmd.append("--allow-unauthenticated")

    # Add env vars
    if env_vars:
        env_str = ",".join(f"{k}={v}" for k, v in env_vars.items())
        deploy_cmd.extend(["--set-env-vars", env_str])

    print(f"  Deploying to Cloud Run...")
    result = _run(deploy_cmd, dry_run=dry_run)

    if not dry_run and result.returncode == 0:
        # Extract service URL
        url_result = subprocess.run(
            [gcloud, "run", "services", "describe", name,
             "--region", region, "--project", project,
             "--format", "value(status.url)"],
            capture_output=True, text=True, timeout=15,
        )
        url = url_result.stdout.strip()
        print(f"\n  [OK] Deployed successfully!")
        print(f"  --> URL: {url}")
        print(f"\n  BB4C.\n")
    elif dry_run:
        print(f"\n  [OK] Dry run complete — no changes made.")
    else:
        print(f"\n  [ERR] Deployment failed.")
        if result.stderr:
            print(f"  Error: {result.stderr[:500]}")
        return False

    return True
