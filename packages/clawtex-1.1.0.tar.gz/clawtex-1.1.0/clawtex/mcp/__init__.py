"""MandelDB MCP Server — gives Claude Code a persistent brain."""

__all__ = ["create_server"]

from clawtex.mcp.server import create_server
