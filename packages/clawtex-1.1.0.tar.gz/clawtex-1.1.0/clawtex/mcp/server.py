"""
MandelDB MCP Server — 7 tools that give any LLM a persistent brain.

Tools:
  remember  — Store a memory (auto-linked to related memories)
  recall    — Semantic search over stored memories
  chat      — RAG-powered conversation with the brain
  upload    — Ingest a document as chunked memories
  groom     — Auto-discover connections between memories
  dream     — Synthesize higher-order insights
  inspect   — Check brain stats (memory count, GQI, health)

Usage:
  claude mcp add mandeldb -- python -m clawtex.mcp

Env vars (CLAWTEX_EIDETIC_* preferred, MANDELDB_* accepted as fallback):
  CLAWTEX_EIDETIC_URL            — Eidetic API base URL (required)
  CLAWTEX_EIDETIC_KEY            — API key (ek_ prefix) or admin key
  CLAWTEX_EIDETIC_NAMESPACE      — Default namespace (default: "default")
  CLAWTEX_EIDETIC_GCLOUD_ACCOUNT — GCP account for identity token auth (optional)
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import time

import httpx
from fastmcp import FastMCP

logger = logging.getLogger(__name__)

# ── Configuration ─────────────────────────────────────────
# CLAWTEX_EIDETIC_* takes precedence, MANDELDB_* is legacy fallback


def _env(clawtex_key: str, legacy_key: str, default: str = "") -> str:
    return os.environ.get(clawtex_key, "") or os.environ.get(legacy_key, "") or default


API_URL = _env("CLAWTEX_EIDETIC_URL", "MANDELDB_URL")
API_KEY = _env("CLAWTEX_EIDETIC_KEY", "MANDELDB_API_KEY")
DEFAULT_NAMESPACE = _env("CLAWTEX_EIDETIC_NAMESPACE", "MANDELDB_NAMESPACE", "default")
GCLOUD_ACCOUNT = _env("CLAWTEX_EIDETIC_GCLOUD_ACCOUNT", "MANDELDB_GCLOUD_ACCOUNT")

# ── Token cache for gcloud identity tokens ────────────────

_token_cache: dict[str, str | float] = {"token": "", "expires": 0.0}


def _get_identity_token() -> str:
    """Get a gcloud identity token, cached for 50 minutes.

    Returns empty string on failure instead of hanging — callers should
    fall through to API key auth or raise a clear error.
    """
    now = time.time()
    if _token_cache["token"] and now < _token_cache["expires"]:
        return str(_token_cache["token"])

    # On Windows, gcloud is a .cmd script
    gcloud = "gcloud.cmd" if os.name == "nt" else "gcloud"
    cmd = [gcloud, "auth", "print-identity-token"]
    if GCLOUD_ACCOUNT:
        cmd.extend(["--account", GCLOUD_ACCOUNT])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=10,
            # On Windows, CREATE_NO_WINDOW prevents console popups
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if result.returncode != 0:
            logger.warning("gcloud auth failed (rc=%d): %s", result.returncode, result.stderr.strip())
            return ""

        token = result.stdout.strip()
        if not token:
            logger.warning("gcloud returned empty token")
            return ""

        _token_cache["token"] = token
        _token_cache["expires"] = now + 3000  # 50 min cache
        return token

    except subprocess.TimeoutExpired:
        logger.warning("gcloud auth timed out after 10s — falling back to API key")
        return ""
    except FileNotFoundError:
        logger.warning("gcloud CLI not found — falling back to API key")
        return ""
    except Exception as exc:
        logger.warning("gcloud auth error: %s — falling back to API key", exc)
        return ""


# ── HTTP Client ───────────────────────────────────────────

async def _request(method: str, path: str, body: dict | None = None) -> dict:
    """Make an authenticated request to the MandelDB API."""
    if not API_URL:
        raise RuntimeError(
            "CLAWTEX_EIDETIC_URL (or MANDELDB_URL) not set. "
            "Run `clawtex init` or set the environment variable."
        )

    headers: dict[str, str] = {
        "Content-Type": "application/json",
    }

    # Auth strategy: API key first (fast, reliable), gcloud as fallback
    if API_KEY:
        if API_KEY.startswith("ek_"):
            headers["X-API-Key"] = API_KEY
        else:
            headers["X-Admin-Key"] = API_KEY

    if GCLOUD_ACCOUNT:
        token = _get_identity_token()
        if token:
            headers["Authorization"] = f"Bearer {token}"

    if not API_KEY and not GCLOUD_ACCOUNT:
        raise RuntimeError(
            "No auth configured. Set CLAWTEX_EIDETIC_KEY (or MANDELDB_API_KEY) "
            "or CLAWTEX_EIDETIC_GCLOUD_ACCOUNT (or MANDELDB_GCLOUD_ACCOUNT)."
        )

    url = f"{API_URL.rstrip('/')}{path}"

    async with httpx.AsyncClient(timeout=60.0) as client:
        response = await client.request(method, url, json=body, headers=headers)
        if response.status_code >= 400:
            text = response.text
            raise RuntimeError(f"MandelDB API {response.status_code}: {text}")
        return response.json()


def _ns(namespace: str | None) -> str:
    """Resolve namespace with fallback to default."""
    return namespace or DEFAULT_NAMESPACE


def _chunk_text(text: str, max_chars: int = 2000) -> list[str]:
    """Split text into paragraph-aware chunks."""
    chunks: list[str] = []
    paragraphs = text.split("\n\n")
    current = ""

    for para in paragraphs:
        if len(current) + len(para) + 2 > max_chars and current:
            chunks.append(current.strip())
            current = ""
        current += ("\n\n" if current else "") + para

    if current.strip():
        chunks.append(current.strip())
    return chunks if chunks else [text]


# ── Server Factory ────────────────────────────────────────

def create_server() -> FastMCP:
    """Create and configure the MandelDB MCP server."""

    mcp = FastMCP(
        "mandeldb",
        instructions=(
            "MandelDB is a semantic memory backend. Use 'remember' to store important "
            "information, 'recall' to search for relevant context, and 'inspect' to check "
            "the brain's current state. Memories are automatically linked by meaning."
        ),
    )

    # ── Tool: remember ────────────────────────────────────

    @mcp.tool()
    async def remember(
        content: str,
        namespace: str | None = None,
        node_type: str = "memory",
        metadata: dict | None = None,
    ) -> str:
        """Store a memory in the brain. Memories are automatically linked to similar
        existing memories via Hebbian synapses.

        Args:
            content: The content to remember (1-50000 chars)
            namespace: Brain namespace (uses default if omitted)
            node_type: Type of node — memory, insight, principle, or hypothesis
            metadata: Optional metadata dict to attach
        """
        result = await _request("POST", "/v2/memory", {
            "content": content,
            "namespace": _ns(namespace),
            "node_type": node_type,
            "metadata": metadata or {},
            "auto_link": True,
        })
        return json.dumps(result, indent=2, default=str)

    # ── Tool: recall ──────────────────────────────────────

    @mcp.tool()
    async def recall(
        query: str,
        namespace: str | None = None,
        top_k: int = 5,
    ) -> str:
        """Search the brain for memories semantically similar to a query.
        Returns ranked results with similarity scores and graph-connected context.

        Args:
            query: What to search for (semantic search, 1-10000 chars)
            namespace: Brain namespace (uses default if omitted)
            top_k: Number of results to return (1-20)
        """
        result = await _request("POST", "/v2/recall", {
            "query": query,
            "namespace": _ns(namespace),
            "top_k": min(max(top_k, 1), 20),
            "include_context": True,
        })
        return json.dumps(result, indent=2, default=str)

    # ── Tool: chat ────────────────────────────────────────

    @mcp.tool()
    async def chat(
        message: str,
        namespace: str | None = None,
        mode: str = "reflex",
        system_prompt: str | None = None,
    ) -> str:
        """Ask the brain a question. Retrieves relevant memories, then synthesizes
        an answer grounded in stored knowledge.

        Args:
            message: Question or message to the brain (1-10000 chars)
            namespace: Brain namespace (uses default if omitted)
            mode: 'reflex' (fast, single-pass) or 'deep_think' (multi-step reasoning)
            system_prompt: Optional system prompt override
        """
        result = await _request("POST", "/v2/chat", {
            "message": message,
            "namespace": _ns(namespace),
            "mode": mode,
            "system_prompt": system_prompt,
            "top_k": 10 if mode == "deep_think" else 5,
        })
        return json.dumps(result, indent=2, default=str)

    # ── Tool: upload ──────────────────────────────────────

    @mcp.tool()
    async def upload(
        content: str,
        filename: str,
        namespace: str | None = None,
    ) -> str:
        """Ingest a document into the brain. The content is automatically chunked
        into paragraph-sized memories, each linked to its neighbors.

        Args:
            content: Full text content of the document
            filename: Name of the source file (for metadata)
            namespace: Brain namespace (uses default if omitted)
        """
        ns = _ns(namespace)
        chunks = _chunk_text(content)
        result = await _request("POST", "/v2/memory/bulk", {
            "memories": [
                {
                    "content": chunk,
                    "namespace": ns,
                    "node_type": "memory",
                    "metadata": {"source_file": filename, "chunk_index": i},
                    "auto_link": True,
                }
                for i, chunk in enumerate(chunks)
            ],
        })
        return json.dumps(result, indent=2, default=str)

    # ── Tool: groom ───────────────────────────────────────

    @mcp.tool()
    async def groom(
        namespace: str | None = None,
        batch_size: int = 20,
    ) -> str:
        """Trigger grooming — the brain scans recent memories and auto-discovers
        connections between related concepts. Creates typed edges (supports,
        contradicts, synthesizes, etc.).

        Args:
            namespace: Brain namespace (uses default if omitted)
            batch_size: Number of memories to process (1-100)
        """
        result = await _request("POST", "/v2/brain/groom", {
            "namespace": _ns(namespace),
            "batch_size": min(max(batch_size, 1), 100),
        })
        return json.dumps(result, indent=2, default=str)

    # ── Tool: dream ───────────────────────────────────────

    @mcp.tool()
    async def dream(
        namespace: str | None = None,
    ) -> str:
        """Trigger dreaming — the brain analyzes clusters of connected memories
        and synthesizes new insight nodes. These are higher-order patterns
        the brain discovers autonomously.

        Args:
            namespace: Brain namespace (uses default if omitted)
        """
        result = await _request("POST", "/v2/brain/dream", {
            "namespace": _ns(namespace),
        })
        return json.dumps(result, indent=2, default=str)

    # ── Tool: inspect ─────────────────────────────────────

    @mcp.tool()
    async def inspect(
        namespace: str | None = None,
    ) -> str:
        """Check the brain's vital stats: total memories, insights, principles,
        edge count, and Graph Quality Index (GQI).

        Args:
            namespace: Brain namespace (uses default if omitted)
        """
        ns = _ns(namespace)
        result = await _request(
            "GET", f"/v2/brain/stats?namespace={ns}"
        )
        return json.dumps(result, indent=2, default=str)

    return mcp
