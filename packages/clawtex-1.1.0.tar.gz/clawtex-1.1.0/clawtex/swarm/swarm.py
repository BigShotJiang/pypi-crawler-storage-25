# ClawTex Swarm — Multi-Agent Orchestration
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
ClawTexSwarm — coordinate multiple ClawTexAgents.

Patterns:
  route     — coordinator picks the best agent for a message
  delegate  — any agent hands a subtask to a named peer
  fan_out   — broadcast to N agents in parallel, aggregate results
  pipeline  — chain agents sequentially, each output feeds the next

Every agent in the swarm keeps its own SOUL, tools, and Warden policy.
The swarm adds a shared memory namespace for cross-agent context.

Usage:

    swarm = ClawTexSwarm(name="ops-team")

    swarm.add(AgentRole(
        agent=researcher,
        role="researcher",
        description="Finds information and answers factual questions",
        handles=["research", "lookup", "find", "search"],
    ))

    swarm.add(AgentRole(
        agent=writer,
        role="writer",
        description="Drafts documents, emails, and summaries",
        handles=["write", "draft", "summarize", "compose"],
    ))

    result = await swarm.route(message)
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any

from clawtex.agent import ClawTexAgent
from clawtex.channels.base import InboundMessage
from clawtex.memory.context import MemoryContext
from clawtex.memory.mandeldb import MandelDBClient

logger = logging.getLogger(__name__)


@dataclass
class AgentRole:
    """An agent registered in the swarm with its role metadata."""

    agent: ClawTexAgent
    role: str
    description: str
    handles: list[str] = field(default_factory=list)

    def matches(self, text: str) -> float:
        """Score how well this agent matches a message (0.0–1.0).

        Uses keyword overlap as a fast, deterministic first pass.
        The swarm coordinator can override with LLM-based routing.
        """
        text_lower = text.lower()
        if not self.handles:
            return 0.0
        hits = sum(1 for kw in self.handles if kw in text_lower)
        return min(hits / max(len(self.handles), 1), 1.0)


@dataclass
class SwarmResult:
    """Result from a swarm operation."""

    reply: str
    agent_role: str
    pattern: str  # "route", "delegate", "fan_out", "pipeline"
    duration_ms: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)


class ClawTexSwarm:
    """
    Orchestrator for multiple ClawTexAgents.

    The swarm does not replace individual agent governance — every tool call
    still passes through each agent's own Warden. The swarm adds coordination:
    who handles what, and how agents collaborate.
    """

    def __init__(
        self,
        name: str = "swarm",
        shared_namespace: str | None = None,
    ) -> None:
        self.name = name
        self._agents: dict[str, AgentRole] = {}
        self._shared_namespace = shared_namespace or f"swarm_{name}"
        self._shared_memory: MemoryContext | None = None
        self._started = False

        logger.info("ClawTexSwarm '%s' created (shared_ns=%s)", name, self._shared_namespace)

    # ------------------------------------------------------------------
    # Agent management
    # ------------------------------------------------------------------

    def add(self, role: AgentRole) -> None:
        """Register an agent with the swarm."""
        if role.role in self._agents:
            raise ValueError(f"Role '{role.role}' already registered in swarm")
        self._agents[role.role] = role
        logger.info(
            "Swarm '%s': added agent '%s' as '%s' (keywords=%s)",
            self.name, role.agent.name, role.role, role.handles,
        )

    def remove(self, role_name: str) -> None:
        """Remove an agent from the swarm by role name."""
        if role_name not in self._agents:
            raise KeyError(f"No agent with role '{role_name}' in swarm")
        del self._agents[role_name]
        logger.info("Swarm '%s': removed role '%s'", self.name, role_name)

    def get(self, role_name: str) -> AgentRole | None:
        """Get an agent role by name."""
        return self._agents.get(role_name)

    @property
    def roles(self) -> list[str]:
        """List all registered role names."""
        return list(self._agents.keys())

    @property
    def agents(self) -> dict[str, AgentRole]:
        """All registered agents."""
        return dict(self._agents)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start all agents in the swarm and initialize shared memory."""
        if self._started:
            return

        # Initialize shared memory for cross-agent context
        client = MandelDBClient()
        self._shared_memory = MemoryContext(
            client=client, namespace=self._shared_namespace
        )

        # Start all agents concurrently
        start_tasks = [role.agent.start() for role in self._agents.values()]
        await asyncio.gather(*start_tasks, return_exceptions=True)

        self._started = True
        logger.info(
            "Swarm '%s' started — %d agents ready", self.name, len(self._agents)
        )

    async def close(self) -> None:
        """Shut down all agents."""
        close_tasks = [role.agent.close() for role in self._agents.values()]
        await asyncio.gather(*close_tasks, return_exceptions=True)
        self._started = False
        logger.info("Swarm '%s' shut down", self.name)

    # ------------------------------------------------------------------
    # Pattern: ROUTE — pick the best agent for a message
    # ------------------------------------------------------------------

    async def route(self, message: InboundMessage) -> SwarmResult:
        """Route a message to the best-matching agent.

        Scoring:
          1. Keyword matching (fast, deterministic)
          2. Falls back to first registered agent if no match

        Returns SwarmResult with the agent's reply.
        """
        t0 = time.monotonic()

        best_role = self._pick_agent(message.text)
        if best_role is None:
            return SwarmResult(
                reply="No agent available to handle this message.",
                agent_role="none",
                pattern="route",
                duration_ms=_elapsed(t0),
            )

        logger.info(
            "Swarm '%s': routing to '%s' (%s)",
            self.name, best_role.role, best_role.agent.name,
        )

        reply = await best_role.agent.handle_message(message)

        # Record the routing decision in shared memory
        if self._shared_memory:
            await self._shared_memory.record_exchange(
                user_message=f"[routed to {best_role.role}] {message.text}",
                assistant_reply=reply,
                extra_metadata={"pattern": "route", "agent_role": best_role.role},
            )

        return SwarmResult(
            reply=reply,
            agent_role=best_role.role,
            pattern="route",
            duration_ms=_elapsed(t0),
        )

    # ------------------------------------------------------------------
    # Pattern: DELEGATE — one agent hands a subtask to another
    # ------------------------------------------------------------------

    async def delegate(
        self,
        from_role: str,
        to_role: str,
        task: str,
        context: str = "",
    ) -> SwarmResult:
        """Delegate a subtask from one agent to another.

        The delegating agent provides a task description and optional context.
        The target agent handles it as a normal message.
        """
        t0 = time.monotonic()

        target = self._agents.get(to_role)
        if target is None:
            return SwarmResult(
                reply=f"Cannot delegate: no agent with role '{to_role}'",
                agent_role=to_role,
                pattern="delegate",
                duration_ms=_elapsed(t0),
            )

        # Build delegation message with context
        delegation_text = f"[Delegated from {from_role}]\n\n{task}"
        if context:
            delegation_text = f"[Delegated from {from_role}]\nContext: {context}\n\nTask: {task}"

        message = InboundMessage(
            text=delegation_text,
            user_id=f"swarm:{from_role}",
            channel="swarm",
            metadata={"pattern": "delegate", "from_role": from_role},
        )

        reply = await target.agent.handle_message(message)

        # Record delegation in shared memory
        if self._shared_memory:
            await self._shared_memory.record_exchange(
                user_message=f"[{from_role} → {to_role}] {task}",
                assistant_reply=reply,
                extra_metadata={
                    "pattern": "delegate",
                    "from_role": from_role,
                    "to_role": to_role,
                },
            )

        return SwarmResult(
            reply=reply,
            agent_role=to_role,
            pattern="delegate",
            duration_ms=_elapsed(t0),
            metadata={"from_role": from_role},
        )

    # ------------------------------------------------------------------
    # Pattern: FAN-OUT — broadcast to N agents in parallel
    # ------------------------------------------------------------------

    async def fan_out(
        self,
        message: InboundMessage,
        roles: list[str] | None = None,
    ) -> list[SwarmResult]:
        """Send a message to multiple agents in parallel.

        Args:
            message: The message to broadcast
            roles: Specific roles to target (default: all agents)

        Returns list of SwarmResult, one per agent.
        """
        t0 = time.monotonic()

        targets = (
            [self._agents[r] for r in roles if r in self._agents]
            if roles
            else list(self._agents.values())
        )

        if not targets:
            return [SwarmResult(
                reply="No agents to fan out to.",
                agent_role="none",
                pattern="fan_out",
                duration_ms=_elapsed(t0),
            )]

        async def _run(role: AgentRole) -> SwarmResult:
            agent_t0 = time.monotonic()
            try:
                reply = await role.agent.handle_message(message)
                return SwarmResult(
                    reply=reply,
                    agent_role=role.role,
                    pattern="fan_out",
                    duration_ms=_elapsed(agent_t0),
                )
            except Exception as exc:
                logger.error("Fan-out error for '%s': %s", role.role, exc)
                return SwarmResult(
                    reply=f"Error: {exc}",
                    agent_role=role.role,
                    pattern="fan_out",
                    duration_ms=_elapsed(agent_t0),
                    metadata={"error": str(exc)},
                )

        results = await asyncio.gather(*[_run(r) for r in targets])

        # Record aggregated results in shared memory
        if self._shared_memory:
            summary = "\n".join(
                f"[{r.agent_role}]: {r.reply[:200]}" for r in results
            )
            await self._shared_memory.record_exchange(
                user_message=f"[fan_out to {[r.agent_role for r in results]}] {message.text}",
                assistant_reply=summary,
                extra_metadata={"pattern": "fan_out", "agent_count": len(results)},
            )

        return list(results)

    # ------------------------------------------------------------------
    # Pattern: PIPELINE — chain agents sequentially
    # ------------------------------------------------------------------

    async def pipeline(
        self,
        message: InboundMessage,
        roles: list[str],
    ) -> SwarmResult:
        """Chain agents sequentially — each agent's output becomes the next agent's input.

        Args:
            message: The initial message
            roles: Ordered list of role names to chain through

        Returns the final agent's result.
        """
        t0 = time.monotonic()
        current_text = message.text
        last_role = "none"

        for i, role_name in enumerate(roles):
            target = self._agents.get(role_name)
            if target is None:
                return SwarmResult(
                    reply=f"Pipeline broken: no agent with role '{role_name}'",
                    agent_role=role_name,
                    pattern="pipeline",
                    duration_ms=_elapsed(t0),
                    metadata={"failed_at_step": i},
                )

            step_msg = InboundMessage(
                text=current_text,
                user_id=message.user_id,
                channel="swarm",
                thread_id=message.thread_id,
                metadata={
                    **message.metadata,
                    "pattern": "pipeline",
                    "step": i,
                    "total_steps": len(roles),
                },
            )

            current_text = await target.agent.handle_message(step_msg)
            last_role = role_name

            logger.info(
                "Pipeline step %d/%d complete — agent='%s' output=%d chars",
                i + 1, len(roles), role_name, len(current_text),
            )

        # Record pipeline in shared memory
        if self._shared_memory:
            await self._shared_memory.record_exchange(
                user_message=f"[pipeline {' → '.join(roles)}] {message.text}",
                assistant_reply=current_text,
                extra_metadata={"pattern": "pipeline", "steps": roles},
            )

        return SwarmResult(
            reply=current_text,
            agent_role=last_role,
            pattern="pipeline",
            duration_ms=_elapsed(t0),
            metadata={"steps": roles},
        )

    # ------------------------------------------------------------------
    # Internal routing
    # ------------------------------------------------------------------

    def _pick_agent(self, text: str) -> AgentRole | None:
        """Pick the best agent for a message using keyword scoring."""
        if not self._agents:
            return None

        scored = [(role, role.matches(text)) for role in self._agents.values()]
        scored.sort(key=lambda x: x[1], reverse=True)

        best_role, best_score = scored[0]

        # If no keywords matched, fall back to first registered agent
        if best_score == 0.0:
            fallback = next(iter(self._agents.values()))
            logger.info(
                "No keyword match — falling back to '%s'", fallback.role
            )
            return fallback

        return best_role


def _elapsed(t0: float) -> float:
    return (time.monotonic() - t0) * 1000
