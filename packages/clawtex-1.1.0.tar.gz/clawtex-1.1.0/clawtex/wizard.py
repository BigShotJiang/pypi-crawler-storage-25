# ClawTex — Governed Agent with Genetic Memory
# Built by DeVere Cooley / AN2B LLC · an2b.com
# BB4C — Breath Before Code

"""
ClawTex setup wizard — interactive first-run configuration.

Usage:
    clawtex init     (preferred)
    clawtex setup    (alias)

Writes .clawtex.toml (canonical config) and .env (legacy compat).
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from clawtex.config import ClawTexConfig, write_toml

ENV_PATH = Path(".env")

BLUE  = "\033[0;34m"
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
BOLD  = "\033[1m"
NC    = "\033[0m"


def banner():
    print(f"""
{BLUE}  ██████╗██╗      █████╗ ██╗    ██╗████████╗███████╗██╗  ██╗
 ██╔════╝██║     ██╔══██╗██║    ██║╚══██╔══╝██╔════╝╚██╗██╔╝
 ██║     ██║     ███████║██║ █╗ ██║   ██║   █████╗   ╚███╔╝
 ██║     ██║     ██╔══██║██║███╗██║   ██║   ██╔══╝   ██╔██╗
 ╚██████╗███████╗██║  ██║╚███╔███╔╝   ██║   ███████╗██╔╝ ██╗
  ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝    ╚═╝   ╚══════╝╚═╝  ╚═╝{NC}

  {BOLD}Governed Agent · Genetic Memory · BB4C{NC}
  Built by DeVere Cooley / AN2B LLC · an2b.com
""")


def ask(prompt: str, default: str = "", secret: bool = False) -> str:
    display = f"  {BOLD}{prompt}{NC}"
    if default:
        display += f" [{default}]"
    display += ": "
    try:
        if secret:
            import getpass
            val = getpass.getpass(display)
        else:
            val = input(display).strip()
        return val if val else default
    except (EOFError, KeyboardInterrupt):
        print("\n\n  Setup cancelled.")
        sys.exit(0)


def ask_choice(prompt: str, choices: list[str], default: str) -> str:
    options = "/".join(f"{BOLD}{c}{NC}" if c == default else c for c in choices)
    result = ask(f"{prompt} ({options})", default=default)
    if result not in choices:
        return default
    return result


def ok(msg: str):
    print(f"  {GREEN}✓{NC}  {msg}")


def warn(msg: str):
    print(f"  {YELLOW}!{NC}  {msg}")


def _provision_mandeldb(mandeldb_url: str, agent_name: str) -> str:
    """Auto-provision a free MandelDB bot key via /v2/provision."""
    import urllib.request
    import json as _json

    print(f"  {BLUE}→{NC}  Provisioning memory brain...", end="", flush=True)
    try:
        payload = _json.dumps({"agent_name": agent_name}).encode("utf-8")
        req = urllib.request.Request(
            f"{mandeldb_url}/v2/provision",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read().decode("utf-8"))
        key = data["bot_key"]
        print(f"\r  {GREEN}✓{NC}  Brain provisioned. Free tier: 500 memories, 10 messages/day.")
        print(f"  {BLUE}→{NC}  Upgrade anytime at {data.get('upgrade_url', mandeldb_url + '/upgrade')}")
        return key
    except Exception as e:
        print(f"\r  {YELLOW}!{NC}  Auto-provision failed ({e}).")
        print(f"  {YELLOW}!{NC}  Get a free key at {mandeldb_url} and enter it below.")
        import getpass
        return getpass.getpass(f"  {BOLD}MandelDB API key (ek_bot_...):{NC} ").strip()


def run_wizard() -> None:
    banner()
    print(f"  {BOLD}Welcome to ClawTex setup.{NC}")
    print("  This wizard will configure your agent in under 2 minutes.\n")

    cfg = ClawTexConfig()

    # ── Identity ────────────────────────────────────────────────────
    print(f"\n  {BLUE}── Identity{NC}")
    cfg.name = ask("Agent name", default="ClawTex")
    cfg.soul = ask("Path to SOUL.md", default="./SOUL.md")

    # ── LLM Provider ────────────────────────────────────────────────
    print(f"\n  {BLUE}── LLM Provider{NC}")
    cfg.llm_provider = ask_choice("Provider", ["anthropic", "openai"], default="anthropic")

    if cfg.llm_provider == "anthropic":
        cfg.anthropic_api_key = ask("Anthropic API key (sk-ant-...)", secret=True)
    else:
        cfg.openai_api_key = ask("OpenAI API key (sk-...)", secret=True)
        cfg.openai_model = ask("Model", default="gpt-4o")

    # ── Memory (MandelDB / Eidetic) ─────────────────────────────────
    print(f"\n  {BLUE}── Memory (Eidetic){NC}")
    memory_choice = ask_choice(
        "Memory backend",
        ["eidetic-cloud", "self-hosted", "skip"],
        default="eidetic-cloud",
    )

    if memory_choice == "eidetic-cloud":
        print("  Setting up your agent's memory brain...")
        mandeldb_url = "https://eidetic-v3-51247736393.us-east1.run.app"
        cfg.eidetic_key = _provision_mandeldb(mandeldb_url, cfg.name)
        cfg.eidetic_url = mandeldb_url
        cfg.eidetic_namespace = ask("Memory namespace", default=cfg.name.lower().replace(" ", "_"))
    elif memory_choice == "self-hosted":
        cfg.eidetic_url = ask("Eidetic API URL")
        cfg.eidetic_key = ask("Eidetic API key (ek_...)", secret=True)
        cfg.eidetic_namespace = ask("Memory namespace", default=cfg.name.lower().replace(" ", "_"))
        gcloud = ask("GCP service account (optional, press Enter to skip)")
        if gcloud:
            cfg.eidetic_gcloud_account = gcloud
    else:
        warn("Memory disabled — agent will have no persistent memory.")

    # ── Vector Backend ──────────────────────────────────────────────
    if memory_choice != "skip":
        print(f"\n  {BLUE}── Vector Backend{NC}")
        print("  Choose where vector embeddings are stored.")
        cfg.vector_backend = ask_choice(
            "Backend",
            ["chroma", "pinecone", "pgvector", "supabase"],
            default="chroma",
        )
        if cfg.vector_backend == "chroma":
            ok("Chroma selected — zero config, local-first. Great for dev.")
        elif cfg.vector_backend == "pinecone":
            cfg.pinecone_api_key = ask("Pinecone API key", secret=True)
            cfg.pinecone_index = ask("Pinecone index name", default=f"clawtex-{cfg.name.lower()}")
        elif cfg.vector_backend == "pgvector":
            cfg.pgvector_url = ask("pgvector connection URL (postgresql://...)")
        elif cfg.vector_backend == "supabase":
            cfg.supabase_url = ask("Supabase project URL")
            cfg.supabase_key = ask("Supabase service key", secret=True)

    # ── Channels ─────────────────────────────────────────────────────
    print(f"\n  {BLUE}── Channels{NC}")
    print("  Configure at least one channel (press Enter to skip).")

    tg = ask("Telegram bot token (or skip)")
    if tg:
        cfg.telegram_bot_token = tg

    sl = ask("Slack bot token (xoxb-... or skip)")
    if sl:
        cfg.slack_bot_token = sl
        cfg.slack_app_token = ask("Slack app token (xapp-...)")

    if not tg and not sl:
        warn("No channels configured — agent will run in CLI mode only.")

    # ── Governance ───────────────────────────────────────────────────
    print(f"\n  {BLUE}── Governance{NC}")
    cfg.warden_mode = ask_choice(
        "Warden mode",
        ["enforce", "audit", "off"],
        default="enforce",
    )

    if cfg.warden_mode == "off":
        warn("Governance is OFF — all actions will execute without policy checks.")

    # ── Dream cycle ──────────────────────────────────────────────────
    dream_hrs = ask("Memory dream cycle (hours)", default="6")
    try:
        cfg.dream_interval_hours = int(dream_hrs)
    except ValueError:
        cfg.dream_interval_hours = 6

    # ── Write config files ──────────────────────────────────────────
    print(f"\n  {BLUE}── Writing configuration{NC}")

    # Primary: .clawtex.toml
    toml_path = write_toml(cfg)
    ok(f"{toml_path} written (canonical config)")

    # Legacy: .env (for dotenv compat)
    _write_env(cfg.to_env())
    ok(".env written (legacy compat)")

    # ── Summary ──────────────────────────────────────────────────────
    print(f"""
  {GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{NC}
  {GREEN}  ClawTex is configured.  BB4C — Breath Before Code.{NC}
  {GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━{NC}

  Start your agent:

    {BOLD}clawtex start{NC}

  Verify governance:

    {BOLD}clawtex check{NC}

  Connect to Claude Code (MCP):

    {BOLD}claude mcp add mandeldb -- python -m clawtex.mcp{NC}

  Docs: https://github.com/an2b-llc/clawtex
""")


def _write_env(config: dict[str, str]) -> None:
    """Write config to .env, preserving any existing values not in config."""
    existing: dict[str, str] = {}

    if ENV_PATH.exists():
        for line in ENV_PATH.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                existing[k.strip()] = v.strip()

    existing.update(config)

    lines = [
        "# ClawTex configuration",
        "# BB4C — Breath Before Code · AN2B LLC",
        "# Generated by: clawtex init",
        "",
    ]

    sections = {
        "Identity": ["CLAWTEX_NAME", "CLAWTEX_SOUL"],
        "LLM Provider": ["LLM_PROVIDER", "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "OPENAI_MODEL"],
        "Memory (Eidetic)": ["CLAWTEX_EIDETIC_URL", "CLAWTEX_EIDETIC_KEY", "CLAWTEX_EIDETIC_NAMESPACE", "CLAWTEX_EIDETIC_GCLOUD_ACCOUNT"],
        "Channels": ["TELEGRAM_BOT_TOKEN", "SLACK_BOT_TOKEN", "SLACK_APP_TOKEN"],
        "Governance": ["WARDEN_POLICY", "WARDEN_MODE"],
        "Agent": ["DREAM_INTERVAL_HOURS", "CLAWTEX_SKILLS_DIR"],
    }

    written: set[str] = set()
    for section, keys in sections.items():
        section_lines = []
        for key in keys:
            if key in existing:
                section_lines.append(f"{key}={existing[key]}")
                written.add(key)
        if section_lines:
            lines.append(f"# {section}")
            lines.extend(section_lines)
            lines.append("")

    # Any remaining keys not in sections
    remainder = [f"{k}={v}" for k, v in existing.items() if k not in written]
    if remainder:
        lines.append("# Other")
        lines.extend(remainder)
        lines.append("")

    ENV_PATH.write_text("\n".join(lines))
