"""Simple dimension resource factory."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, ClassVar

from sqlalchemy import Column, DateTime, Table, select

from pgcraft.factory.base import ResourceFactory
from pgcraft.plugin import Plugin, produces, requires, singleton
from pgcraft.plugins.check import TableCheckPlugin
from pgcraft.plugins.fk import TableFKPlugin
from pgcraft.plugins.index import TableIndexPlugin
from pgcraft.plugins.protect import RawTableProtectionPlugin
from pgcraft.plugins.trigger import InsteadOfTriggerPlugin, TriggerOp
from pgcraft.plugins.view import ViewPlugin
from pgcraft.utils.naming import resolve_name
from pgcraft.utils.query import compile_query
from pgcraft.utils.template import load_template

if TYPE_CHECKING:
    from collections.abc import Callable

    from pgcraft.factory.context import FactoryContext

_TEMPLATES = (
    Path(__file__).resolve().parents[2] / "plugins" / "templates" / "simple"
)

_NAMING_DEFAULTS = {
    "simple_raw_table": "%(table_name)s_raw",
    "simple_function": "%(schema)s_%(table_name)s_%(op)s",
    "simple_trigger": "%(schema)s_%(table_name)s_%(op)s",
}


def _build_simple_ops_with_columns(
    columns: list[str] | None,
    table_key: str = "raw_table",
) -> Callable[[FactoryContext], list[TriggerOp]]:
    """Return an ops_builder that respects a column subset.

    Args:
        columns: Writable columns for the triggers.
            When ``None``, uses all dim columns from ctx.
        table_key: Key in ``ctx`` for the backing raw table.

    Returns:
        A callable suitable for ``InsteadOfTriggerPlugin``.

    """

    def builder(ctx: FactoryContext) -> list[TriggerOp]:
        primary = ctx[table_key]
        base_fullname = f"{ctx.schemaname}.{primary.name}"
        if columns is not None:
            dim_cols = columns
        elif "writable_columns" in ctx:
            dim_cols = ctx["writable_columns"]
        else:
            dim_cols = ctx.dim_column_names

        set_parts = [f"{c} = NEW.{c}" for c in dim_cols]
        if "updated_at_column" in ctx:
            updated_at_col = ctx["updated_at_column"]
            set_parts.append(f"{updated_at_col} = now()")

        if columns is not None:
            pk_name = ctx.pk_column_name
            ret_cols = [pk_name, *dim_cols]
            if "updated_at_column" in ctx:
                ret_cols.append(ctx["updated_at_column"])
            ret = ", ".join(ret_cols)
        else:
            ret = "*"

        template_vars = {
            "base_table": base_fullname,
            "cols": ", ".join(dim_cols),
            "new_cols": ", ".join(f"NEW.{c}" for c in dim_cols),
            "set_clause": ", ".join(set_parts),
            "returning_cols": ret,
        }

        return [
            TriggerOp(
                "insert",
                load_template(_TEMPLATES / "insert.plpgsql.mako").render(
                    **template_vars
                ),
            ),
            TriggerOp(
                "update",
                load_template(_TEMPLATES / "update.plpgsql.mako").render(
                    **template_vars
                ),
            ),
            TriggerOp(
                "delete",
                load_template(_TEMPLATES / "delete.plpgsql.mako").render(
                    **template_vars
                ),
            ),
        ]

    return builder


@produces("raw_table")
@requires("pk_columns")
@singleton("__table__")
class SimpleTablePlugin(Plugin):
    """Create a single backing table for a simple dimension.

    Creates ``{tablename}_raw`` and stores it in ``ctx["raw_table"]``.
    The writable view ``{tablename}`` is created by
    :func:`SimpleViewPlugin`.

    """

    def run(self, ctx: FactoryContext) -> None:
        """Create the raw table and store it in ctx."""
        raw_name = resolve_name(
            ctx.metadata,
            "simple_raw_table",
            {
                "table_name": ctx.tablename,
                "schema": ctx.schemaname,
            },
            _NAMING_DEFAULTS,
        )
        pk_columns = ctx["pk_columns"]
        updated_at_cols: list[Column] = []
        if "updated_at_column" in ctx:
            updated_at_cols = [
                Column(
                    ctx["updated_at_column"],
                    DateTime(timezone=True),
                    server_default="now()",
                )
            ]
        table = Table(
            raw_name,
            ctx.metadata,
            *pk_columns,
            *ctx.table_items,
            *updated_at_cols,
            schema=ctx.schemaname,
        )
        ctx["raw_table"] = table


def SimpleViewPlugin() -> ViewPlugin:  # noqa: N802
    """Create a configured ViewPlugin for simple dimensions.

    Registers ``{tablename}`` as a view over ``{tablename}_raw``
    and stores the proxy in ``ctx["primary"]``.

    Returns:
        A :class:`~pgcraft.plugins.view.ViewPlugin` configured
        for simple passthrough views.

    """

    def _query(ctx: FactoryContext) -> str:
        raw = ctx["raw_table"]
        return compile_query(select(raw))

    def _proxy(ctx: FactoryContext) -> list[Column]:
        raw = ctx["raw_table"]
        return [
            Column(c.name, c.type, primary_key=c.primary_key)
            for c in raw.columns
        ]

    return ViewPlugin(
        query_builder=_query,
        proxy_builder=_proxy,
        extra_requires=["raw_table", "pk_columns"],
    )


class PGCraftSimple(ResourceFactory):
    """Create a simple dimension: one table with optional checks.

    Internal plugins (always present):

    1. :class:`SimpleTablePlugin` -- raw backing table
       (``{tablename}_raw``).
    2. :class:`SimpleViewPlugin` -- writable view (``{tablename}``).
    3. :class:`~pgcraft.plugins.check.TableCheckPlugin` --
       check constraints on the raw table.
    4. :class:`~pgcraft.plugins.index.TableIndexPlugin` --
       indexes on the raw table.
    5. :class:`~pgcraft.plugins.fk.TableFKPlugin` --
       foreign keys on the raw table.
    6. :class:`~pgcraft.plugins.protect.RawTableProtectionPlugin` --
       blocks direct DML on the raw table.
    7. :class:`~pgcraft.plugins.trigger.InsteadOfTriggerPlugin`
       -- INSTEAD OF triggers on the dimension view.

    A :class:`~pgcraft.plugins.pk.SerialPKPlugin` is auto-added
    when no user plugin produces ``pk_columns``.

    Pass a
    :class:`~pgcraft.extensions.postgrest.plugin.PostgRESTPlugin`
    via ``extra_plugins`` to expose this dimension through a
    PostgREST API view with CRUD triggers.

    Args:
        tablename: Name of the dimension table.
        schemaname: PostgreSQL schema for generated objects.
        metadata: SQLAlchemy ``MetaData`` to register on.
        schema_items: Column and constraint definitions.
        plugins: Behaviour-modifying plugins (e.g.
            ``UUIDV4PKPlugin``).
        extra_plugins: Appended to the resolved plugin list.

    """

    _FK_TARGET_KEY: ClassVar[str] = "raw_table"

    _INTERNAL_PLUGINS: ClassVar[list[Plugin]] = [
        SimpleTablePlugin(),
        SimpleViewPlugin(),
        TableCheckPlugin("raw_table"),
        TableIndexPlugin("raw_table"),
        TableFKPlugin("raw_table"),
        RawTableProtectionPlugin("raw_table"),
        InsteadOfTriggerPlugin(
            ops_builder=_build_simple_ops_with_columns(None),
            naming_defaults=_NAMING_DEFAULTS,
            function_key="simple_function",
            trigger_key="simple_trigger",
            view_key="primary",
            extra_requires=["raw_table"],
        ),
    ]
