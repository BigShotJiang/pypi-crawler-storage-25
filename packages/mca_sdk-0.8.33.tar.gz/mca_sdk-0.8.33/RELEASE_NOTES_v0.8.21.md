# Release Notes - MCA SDK v0.8.21

## Overview

Version 0.8.21 contains important fixes addressing security and architectural findings from adversarial reviews. It also includes improvements to GCP authentication and packaging.

## What's New

### Security and Architecture
- Addressed adversarial review security and architectural findings (high-cardinality issue).
- Addressed adversarial review findings for Go SDK packaging.

### GCP Authentication
- Pass `token_audience` to standalone `RegistryClient` for GCP auth.
- Add logging to verify `MCA_GCP_TOKEN_AUDIENCE` value.
- Add `gcp_token_audience` to enable GCP auth with IP-based registry.

### Dependencies
- Updated requirements files.

## Upgrade Instructions

```bash
pip install --upgrade mca-sdk==0.8.21
```
