#!/usr/bin/env bash
# Generate a text GoDoc snapshot for the MCA Go SDK.
#
# The canonical, browsable Go API reference lives on pkg.go.dev once the
# module is published. This script writes a plain-text snapshot of
# `go doc -all ./...` to docs/api-reference/go/godoc.txt so the same
# content is available from the GitLab Pages site even when pkg.go.dev
# indexing is unavailable (e.g. private repos).
#
# Usage:
#   bash scripts/gen-godoc.sh
#
# Invoked from: .gitlab-ci.yml :docs:go

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
REPO_ROOT="$(cd "${SDK_DIR}/../.." && pwd)"
OUT_DIR="${REPO_ROOT}/docs/api-reference/go"

mkdir -p "${OUT_DIR}"

cd "${SDK_DIR}"

{
  echo "# MCA SDK for Go - GoDoc snapshot"
  echo
  echo "Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "Module: $(awk '/^module / {print $2; exit}' go.mod)"
  echo
  echo "Canonical API reference: https://pkg.go.dev/$(awk '/^module / {print $2; exit}' go.mod)"
  echo
  echo "---"
  echo
  go doc -all ./... 2>&1 || true
} > "${OUT_DIR}/godoc.txt"

echo "Wrote $(wc -l < "${OUT_DIR}/godoc.txt") lines to ${OUT_DIR}/godoc.txt"
