// Package mca provides OpenTelemetry instrumentation for ML models.
package mca

// Version is the current version of the MCA Go SDK.
// This constant is used for telemetry resource attributes.
// Go SDK versioning is independent of other language SDKs.
//
// IMPORTANT: This version string must be manually updated to match git tags.
// Git tags are the source of truth for Go modules (e.g., mca-prototype/mca-sdk-go/v0.1.0).
// This constant is duplicated here for runtime telemetry attribution.
//
// Release process:
// 1. Update this constant to match the intended version (e.g., "0.2.0")
// 2. Create git tag: git tag mca-prototype/mca-sdk-go/v0.2.0
// 3. Push both commit and tag to GitLab
const Version = "0.1.0"
