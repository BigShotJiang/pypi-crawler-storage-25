"""Provider setup functions for OpenTelemetry.

This module provides functions to initialize MeterProvider, LoggerProvider,
and TracerProvider with proper configuration and exporters.

Prometheus Metrics Exported
----------------------------

When prometheus_enabled=True, the following metric types are exposed on the
configured HTTP endpoint (default: http://127.0.0.1:9464/metrics):

**Model Prediction Metrics:**
- model_predictions_total (counter) - Total number of predictions made
- model_latency_seconds (histogram) - Prediction latency distribution
- model_errors_total (counter) - Total prediction errors
- model_accuracy_ratio (gauge) - Model accuracy metrics

**LLM/GenAI Metrics (when using LLM integrations):**
- llm_tokens_total (counter) - Token usage (input/output)
- llm_latency_seconds (histogram) - LLM API call latency
- llm_cost_total (counter) - Cumulative LLM API costs
- llm_errors_total (counter) - LLM API errors

**Resource Attributes (as labels):**
All metrics include resource attributes as Prometheus labels:
- service_name - Service/model name
- model_id - Model identifier
- model_version - Model version
- model_category - "internal" or "vendor"
- model_type - "regression", "classification", "generative", etc.
- team_name - Team responsible for the model

**Configuration:**
Environment Variables:
- MCA_PROMETHEUS_ENABLED (default: false) - Enable Prometheus exporter
- MCA_PROMETHEUS_PORT (default: 9464) - HTTP server port
- MCA_PROMETHEUS_HOST (default: 127.0.0.1) - Bind address

Security Note: Default binding to 127.0.0.1 (localhost) prevents network exposure.
For Kubernetes deployments, explicitly set MCA_PROMETHEUS_HOST=0.0.0.0 and secure
the endpoint with NetworkPolicies or a service mesh.

**Port Conflict Behavior:**
If the configured port is already in use, the exporter will log a warning and
gracefully degrade to OTLP-only mode. No exception is raised.
"""

import logging
import os
import re
import socket
import uuid
import warnings
import threading
from typing import Dict, Optional, Any, Callable, Tuple, TYPE_CHECKING, Sequence, Union

if TYPE_CHECKING:
    from ..config.settings import LoggingConfig
    from ..exporters.gcp_trace_exporter import GCPCloudTraceExporter
from wsgiref.simple_server import make_server, WSGIServer

from opentelemetry import metrics, trace
from opentelemetry.sdk.metrics import (
    MeterProvider,
    Counter,
    UpDownCounter,
    ObservableCounter,
    ObservableUpDownCounter,
    Histogram,
)
from opentelemetry.sdk.metrics.export import (
    PeriodicExportingMetricReader,
    AggregationTemporality,
)
from opentelemetry.sdk.metrics.view import View, ExplicitBucketHistogramAggregation
from opentelemetry.sdk.metrics._internal.aggregation import DropAggregation
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.sdk.resources import Resource

from ..version import __version__
from ..config.settings import DEFAULT_METRIC_EXPORT_INTERVAL_MS
from opentelemetry._logs import set_logger_provider, get_logger_provider
from opentelemetry.sdk._logs import LoggerProvider
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

# Import buffered exporters for retry logic
from ..buffering.exporters import (
    BufferedOTLPMetricExporter,
    BufferedOTLPLogExporter,
    BufferedOTLPSpanExporter,
)
from ..buffering.retry import RetryPolicy

import weakref

# Module-level logger
logger = logging.getLogger(__name__)

# Registry for reference counting and config matching
# NOTE: WeakKeyDictionary does NOT automatically clean up providers in practice
# because OpenTelemetry's global state (metrics._internal._METER_PROVIDER) holds
# a strong reference. Cleanup is manual via unregister_provider(). The weak
# semantics prevent id() collision vulnerabilities and guard against memory leaks
# if a provider is somehow orphaned without being set as the global provider.
_MCA_PROVIDER_REGISTRY: "weakref.WeakKeyDictionary[MeterProvider, Dict[str, Any]]" = (
    weakref.WeakKeyDictionary()
)
_MCA_PROVIDER_REGISTRY_LOCK = threading.RLock()

# Double-checked locking primitives
# _PROVIDER_INIT_LOCKS: Event keyed by config tuple - signals initialization completion
# _PROVIDER_INIT_ERRORS: Dict storing initialization failures to propagate to waiting threads
_PROVIDER_INIT_LOCKS: Dict[Tuple[Any, ...], threading.Event] = {}
_PROVIDER_INIT_ERRORS: Dict[Tuple[Any, ...], Exception] = {}
_PROVIDER_INIT_LOCKS_LOCK = threading.RLock()

# Story 8.7: Default metric filtering patterns (optimized as module-level constants)
# These patterns drop high-volume auto-instrumentation metrics to reduce Cloud Monitoring costs
DEFAULT_DROPPED_PATTERNS = [
    "process.*",  # Process CPU, memory metrics
    "system.*",  # System-level metrics
    "asyncio.*",  # AsyncIO internals
    "cpython.*",  # CPython VM metrics
    "http.client.*",  # HTTP client auto-instrumentation
    "otel.sdk.*",  # OpenTelemetry SDK internals
    "test.*",  # Test metrics (pre-production/sandbox)
    "rpc.*",  # RPC client metrics
]

# Pre-built Views for dropping metrics (evaluated once at module import)
DEFAULT_DROP_VIEWS = [
    View(instrument_name=pattern, aggregation=DropAggregation())
    for pattern in DEFAULT_DROPPED_PATTERNS
]

# DP-16: Explicit bucket boundaries for seconds-scale latency histograms.
# OTel's default histogram boundaries are millisecond-tuned, so the SDK's
# seconds-based latencies (50ms-2s typical for ML inference) collapse into
# the single [0, 5) bucket and p95 cannot be reconstructed. These tuples
# pair with the Views below to reshape aggregation at the MeterProvider.
_LATENCY_SHORT_TAIL_BOUNDARIES_DEFAULT = (
    0.005,
    0.01,
    0.025,
    0.05,
    0.1,
    0.25,
    0.5,
    1.0,
    2.5,
    5.0,
    10.0,
)
_LATENCY_LONG_TAIL_BOUNDARIES_DEFAULT = (
    1.0,
    5.0,
    30.0,
    60.0,
    300.0,
    600.0,
    1800.0,
    3600.0,
    7200.0,
    21600.0,
    86400.0,
)

_LATENCY_SHORT_TAIL_ENV = "MCA_LATENCY_SHORT_TAIL_BOUNDARIES"
_LATENCY_LONG_TAIL_ENV = "MCA_LATENCY_LONG_TAIL_BOUNDARIES"


def _resolve_latency_boundaries(
    env_var: str,
    default: Tuple[float, ...],
    *,
    name: str,
) -> Tuple[float, ...]:
    """Resolve a histogram bucket boundary tuple from an environment override.

    Mirrors the validation contract of ``_resolve_temporality_preference``:
    when the environment variable is unset the default tuple is returned;
    when set the value is parsed as comma-separated floats and the result
    must be strictly ascending and contain only finite values. Any parse
    or validation failure logs a WARNING and falls back to ``default`` —
    this function MUST NOT raise (``BaseException`` subclasses still
    propagate so ``KeyboardInterrupt`` / ``SystemExit`` are not swallowed).

    Args:
        env_var: Environment variable name to read.
        default: Default boundary tuple if env var is unset or invalid.
        name: Human-readable boundary name (e.g. ``"short-tail"``) used
            only in the WARNING messages.

    Returns:
        A tuple of strictly ascending finite floats.
    """
    raw = os.environ.get(env_var)
    if raw is None:
        return default

    stripped = raw.strip()
    if not stripped:
        logger.warning(
            "%s is set but empty; falling back to default %s boundaries.",
            env_var,
            name,
        )
        return default

    try:
        parts = [piece.strip() for piece in stripped.split(",")]
        if any(p == "" for p in parts):
            logger.warning(
                "%s=%r contains an empty value between commas; falling back "
                "to default %s boundaries.",
                env_var,
                raw,
                name,
            )
            return default

        parsed: Tuple[float, ...] = tuple(float(p) for p in parts)
    except (ValueError, TypeError) as exc:
        logger.warning(
            "%s=%r could not be parsed as comma-separated floats (%s: %s); "
            "falling back to default %s boundaries.",
            env_var,
            raw,
            type(exc).__name__,
            exc,
            name,
        )
        return default

    if len(parsed) < 2:
        logger.warning(
            "%s=%r must define at least 2 boundaries; falling back to " "default %s boundaries.",
            env_var,
            raw,
            name,
        )
        return default

    import math

    for value in parsed:
        if not math.isfinite(value):
            logger.warning(
                "%s=%r contains non-finite value %r; falling back to " "default %s boundaries.",
                env_var,
                raw,
                value,
                name,
            )
            return default

    for previous, current in zip(parsed, parsed[1:]):
        if current <= previous:
            logger.warning(
                "%s=%r is not strictly ascending (%r >= %r); falling back "
                "to default %s boundaries.",
                env_var,
                raw,
                previous,
                current,
                name,
            )
            return default

    return parsed


# Public boundary tuples — re-exported from mca_sdk.__init__ so operators
# composing custom Views can reuse the SDK defaults verbatim. Resolved at
# module import time from the corresponding env-var overrides.
LATENCY_SHORT_TAIL_BOUNDARIES: Tuple[float, ...] = _resolve_latency_boundaries(
    _LATENCY_SHORT_TAIL_ENV,
    _LATENCY_SHORT_TAIL_BOUNDARIES_DEFAULT,
    name="short-tail",
)
LATENCY_LONG_TAIL_BOUNDARIES: Tuple[float, ...] = _resolve_latency_boundaries(
    _LATENCY_LONG_TAIL_ENV,
    _LATENCY_LONG_TAIL_BOUNDARIES_DEFAULT,
    name="long-tail",
)

# Round-2: enumerated SDK-managed histogram names that get short-tail
# boundaries. Wildcard patterns were rejected because they would silently
# overwrite any user-created custom histogram named "*latency_seconds"
# registered via MCAClient.record_metric. The list below comes from a full
# audit of every meter.create_histogram(...) site in this package; custom
# user histograms intentionally retain OTel default boundaries.
_SDK_SHORT_TAIL_HISTOGRAM_NAMES = (
    # MCAClient core (mca_sdk/core/client.py:1348) - prefix in {model, genai, agentic, vendor}
    "model.latency_seconds",
    "genai.latency_seconds",
    "agentic.latency_seconds",
    "vendor.latency_seconds",
    # GenAI shared instruments (mca_sdk/integrations/genai.py:153)
    "model.embedding_latency_seconds",
    "genai.embedding_latency_seconds",
    "agentic.embedding_latency_seconds",
    "vendor.embedding_latency_seconds",
    # Agent tool latency (mca_sdk/core/client.py:1637)
    "agent.tool_latency_seconds",
    # Registry telemetry (mca_sdk/registry/telemetry.py:47)
    "mca.registry.refresh_latency_seconds",
)

# DP-16 architectural deviation: AC-1 literal text mandates
# explicit_bucket_boundaries_advisory on each create_histogram call. We use
# Views instead because (a) ~7+ create_histogram sites in client.py / genai.py /
# registry/telemetry.py would diverge under future edits if hints were per-call,
# (b) Views centralize the contract in one auditable list — the round-2 wildcard
# regression and its pinning test were only possible because the contract is
# data-driven, (c) caller-supplied views in setup_meter_provider can pre-empt
# specific names without forking the per-call sites.
DEFAULT_HISTOGRAM_BOUNDARY_VIEWS = [
    *(
        View(
            instrument_name=name,
            aggregation=ExplicitBucketHistogramAggregation(
                boundaries=LATENCY_SHORT_TAIL_BOUNDARIES
            ),
        )
        for name in _SDK_SHORT_TAIL_HISTOGRAM_NAMES
    ),
    View(
        instrument_name="agent.goal_duration_seconds",
        aggregation=ExplicitBucketHistogramAggregation(boundaries=LATENCY_LONG_TAIL_BOUNDARIES),
    ),
    View(
        instrument_name="agent.intervention_wait_time_seconds",
        aggregation=ExplicitBucketHistogramAggregation(boundaries=LATENCY_LONG_TAIL_BOUNDARIES),
    ),
]


# Sum-type instruments (Counter, UpDownCounter, ObservableCounter,
# ObservableUpDownCounter) are flipped to DELTA to prevent the
# googlecloud exporter's "Duplicate TimeSeries" rejections on cumulative
# (metric, label-set) datapoints batched into a single WriteTimeSeries
# request. Histograms are intentionally left at OTel's default
# (CUMULATIVE) because PromQL `histogram_quantile()` mathematically
# requires cumulative buckets — see docs/api-contracts.md §9.1 and §9.4.
_TEMPORALITY_DELTA_FULL: Dict[type, AggregationTemporality] = {
    Counter: AggregationTemporality.DELTA,
    UpDownCounter: AggregationTemporality.DELTA,
    ObservableCounter: AggregationTemporality.DELTA,
    ObservableUpDownCounter: AggregationTemporality.DELTA,
}

# Post-#3 / post-#4: lowmemory must include the async counters or the
# duplicate-TimeSeries problem returns for any async instrument.
# Histogram is omitted for the same reason as _TEMPORALITY_DELTA_FULL.
# After dropping Histogram from both maps, "lowmemory" and "delta" are
# operationally identical; the alias is retained for parity with the
# OTel `OTEL_EXPORTER_OTLP_METRICS_TEMPORALITY_PREFERENCE=lowmemory`
# preset semantics.
_TEMPORALITY_DELTA_LOWMEMORY: Dict[type, AggregationTemporality] = {
    Counter: AggregationTemporality.DELTA,
    UpDownCounter: AggregationTemporality.DELTA,
    ObservableCounter: AggregationTemporality.DELTA,
    ObservableUpDownCounter: AggregationTemporality.DELTA,
}

# Explicit cumulative map for the rollback branch. We do not return None
# and rely on OTel's library default forever being cumulative — a future
# upstream change to that default would silently break the rollback path.
_TEMPORALITY_CUMULATIVE_FULL: Dict[type, AggregationTemporality] = {
    Counter: AggregationTemporality.CUMULATIVE,
    UpDownCounter: AggregationTemporality.CUMULATIVE,
    ObservableCounter: AggregationTemporality.CUMULATIVE,
    ObservableUpDownCounter: AggregationTemporality.CUMULATIVE,
    Histogram: AggregationTemporality.CUMULATIVE,
}

# Standard OTel env var. Read with lower precedence than the proprietary
# MCA_OTEL_TEMPORALITY (project-explicit override wins) but honored
# instead of being silently overridden when the proprietary var is unset.
_OTEL_STANDARD_TEMPORALITY_ENV = "OTEL_EXPORTER_OTLP_METRICS_TEMPORALITY_PREFERENCE"
_MCA_TEMPORALITY_ENV = "MCA_OTEL_TEMPORALITY"


def _resolve_temporality_preference() -> Optional[Dict[type, AggregationTemporality]]:
    """Resolve the OTLP exporter temporality preference.

    Reads two environment variables with the following precedence:
        1. ``MCA_OTEL_TEMPORALITY`` (proprietary, explicit project override).
        2. ``OTEL_EXPORTER_OTLP_METRICS_TEMPORALITY_PREFERENCE`` (OTel standard).
        3. Default ``delta``.

    A WARNING is logged when both variables are set with conflicting
    values; the proprietary value still wins. The proprietary variable is
    scheduled for removal one minor release after the dual-read window —
    operators on the standard var see no behavior change at that point.

    Values (case-insensitive, whitespace tolerated):
        - ``delta`` (default): DELTA map for sync + async sum-type
          instruments only. Histogram is intentionally absent — see
          ``_TEMPORALITY_DELTA_FULL`` docstring.
        - ``cumulative``: explicit cumulative map for the rollback path
          (does not rely on OTel implicit default).
        - ``lowmemory``: parity with the OTel preset; identical to delta
          after histogram was dropped from both maps.
        - any other string: log WARNING and fall back to the delta map.

    Honors a MUST NOT raise contract: ``BaseException`` subclasses
    (``KeyboardInterrupt``, ``SystemExit``) propagate, but realistic
    failure modes for ``os.environ.get`` and string ops are caught,
    logged at WARNING, and the default delta map is returned so SDK
    setup never crashes the host application.
    """
    try:
        mca_raw = os.environ.get(_MCA_TEMPORALITY_ENV)
        otel_raw = os.environ.get(_OTEL_STANDARD_TEMPORALITY_ENV)

        mca_value = mca_raw.strip().lower() if mca_raw else None
        otel_value = otel_raw.strip().lower() if otel_raw else None

        if mca_value and otel_value and mca_value != otel_value:
            logger.warning(
                "Both %s=%r and %s=%r are set with conflicting values; "
                "%s takes precedence. Note: %s is scheduled for removal — "
                "prefer the OTel standard variable.",
                _MCA_TEMPORALITY_ENV,
                mca_raw,
                _OTEL_STANDARD_TEMPORALITY_ENV,
                otel_raw,
                _MCA_TEMPORALITY_ENV,
                _MCA_TEMPORALITY_ENV,
            )

        if mca_value is not None:
            value = mca_value
            source_var = _MCA_TEMPORALITY_ENV
            source_raw = mca_raw
        elif otel_value is not None:
            value = otel_value
            source_var = _OTEL_STANDARD_TEMPORALITY_ENV
            source_raw = otel_raw
            logger.info(
                "Honoring %s=%r for metric temporality preference.",
                _OTEL_STANDARD_TEMPORALITY_ENV,
                otel_raw,
            )
        else:
            value = "delta"
            source_var = None
            source_raw = None

        if value == "delta":
            return dict(_TEMPORALITY_DELTA_FULL)
        if value == "cumulative":
            return dict(_TEMPORALITY_CUMULATIVE_FULL)
        if value == "lowmemory":
            return dict(_TEMPORALITY_DELTA_LOWMEMORY)

        logger.warning(
            "Unrecognized %s value %r; falling back to 'delta'.",
            source_var or _MCA_TEMPORALITY_ENV,
            source_raw,
        )
        return dict(_TEMPORALITY_DELTA_FULL)
    except (OSError, KeyError, ValueError, TypeError, AttributeError) as exc:
        logger.warning(
            "Failed to resolve metric temporality preference (%s: %s); "
            "falling back to default delta map.",
            type(exc).__name__,
            exc,
        )
        return dict(_TEMPORALITY_DELTA_FULL)


class ProviderAlreadySetWarning(UserWarning):
    """Warning when attempting to set a provider that's already configured."""


# Prometheus label name normalization: non-alphanumeric (except underscore) → "_"
_PROM_LABEL_NORMALIZE_RE = re.compile(r"[^a-zA-Z0-9_]")

# Resource attribute keys the SDK itself populates. extra_resource entries whose
# names collide with any of these after Prometheus normalization are dropped to
# prevent "duplicate label names in constant and variable labels" errors in the
# Prometheus exporter (resource_to_telemetry_conversion path).
_SDK_RESERVED_RESOURCE_KEYS = frozenset(
    {
        "service.name",
        "service.namespace",
        "service.instance.id",
        "model.version",
        "model.category",
        "model.type",
        "model.id",
        "team.name",
        "mca.sdk.version",
        "telemetry.sdk.version",
        "telemetry.sdk.name",
        "telemetry.sdk.language",
    }
)

# Stable per-process identity. Used as service.instance.id so the googlecloud
# exporter maps each producer to a distinct generic_task rather than collapsing
# every workload into generic_node with an empty node_id (which triggers
# "Duplicate TimeSeries" rejections from Cloud Monitoring).
_SDK_INSTANCE_ID = f"{socket.gethostname()}:{os.getpid()}:{uuid.uuid4().hex[:8]}"


def _prom_normalize(key: str) -> str:
    return _PROM_LABEL_NORMALIZE_RE.sub("_", key).lower()


def create_resource_attributes(
    service_name: str,
    model_id: Optional[str] = None,
    model_version: str = "0.3.0",
    team_name: Optional[str] = None,
    model_category: str = "internal",
    model_type: str = "regression",
    extra_resource: Optional[Dict[str, str]] = None,
    **kwargs: Any,
) -> Resource:
    """Create OpenTelemetry Resource with model metadata.

    Uses the two-field taxonomy (model_category + model_type) to provide
    complete model classification as resource attributes.

    Args:
        service_name: Name of the service
        model_id: Unique model identifier
        model_version: Model version string
        team_name: Team responsible for the model
        model_category: High-level category ("internal" or "vendor")
        model_type: Specific type ("regression", "time-series", "classification", "generative", "agentic")
        extra_resource: Additional resource attributes from registry
        **kwargs: Additional resource attributes

    Returns:
        Resource instance with model metadata
    """
    # Base attributes (always included)
    attributes = {
        "service.name": service_name,
        "model.version": model_version,
        "model.category": model_category,
        "model.type": model_type,
    }

    # Optional attributes
    if model_id:
        attributes["model.id"] = model_id
    if team_name:
        attributes["team.name"] = team_name

    # Merge extra_resource attributes from registry, dropping any key that
    # collides with an SDK-reserved key or a previously-accepted extra key
    # after Prometheus label normalization. Without this guard, two resource
    # attributes whose names only differ in punctuation (e.g. "model.version"
    # vs "model_version") both end up on exported metrics and the Prometheus
    # exporter rejects the metric with "duplicate label names in constant
    # and variable labels".
    if extra_resource:
        reserved_normalized = {_prom_normalize(k): k for k in _SDK_RESERVED_RESOURCE_KEYS}
        accepted_normalized: Dict[str, str] = {}
        for key, value in extra_resource.items():
            normalized = _prom_normalize(key)
            reserved_collision = reserved_normalized.get(normalized)
            if reserved_collision is not None:
                logger.warning(
                    "Dropping extra_resource key %r because it collides with "
                    "reserved resource key %r after Prometheus normalization",
                    key,
                    reserved_collision,
                )
                continue
            prior = accepted_normalized.get(normalized)
            if prior is not None:
                logger.warning(
                    "Dropping extra_resource key %r because it collides with "
                    "previously-accepted extra_resource key %r after Prometheus normalization",
                    key,
                    prior,
                )
                continue
            accepted_normalized[normalized] = key
            attributes[key] = value

    # Add any additional attributes
    attributes.update(kwargs)

    # Force critical system attributes last to prevent tampering
    attributes["mca.sdk.version"] = __version__
    attributes["telemetry.sdk.version"] = __version__
    attributes["service.instance.id"] = _SDK_INSTANCE_ID

    return Resource.create(attributes)


def unregister_provider(provider: Any) -> bool:
    """Unregister a provider with reference counting.

    Properly cleans up Prometheus HTTP server daemon thread if this is the
    last reference to the provider. Also clears the OTel global state to
    allow fresh initialization afterward.

    Args:
        provider: The provider to unregister.

    Returns:
        True if the provider refcount reached 0 (meaning it should be shut down), False otherwise.
    """
    if provider is None:
        return False

    with _MCA_PROVIDER_REGISTRY_LOCK:
        if provider not in _MCA_PROVIDER_REGISTRY:
            return True

        entry = _MCA_PROVIDER_REGISTRY[provider]
        entry["refcount"] -= 1

        if entry["refcount"] <= 0:
            # Shutdown Prometheus HTTP server before removing from registry
            prometheus_shutdown = entry.get("prometheus_shutdown")
            if prometheus_shutdown:
                try:
                    prometheus_shutdown()
                except Exception as e:
                    logger.warning(f"Failed to shutdown Prometheus HTTP server: {e}")

            del _MCA_PROVIDER_REGISTRY[provider]

            # Clear OTel global state to allow fresh initialization
            # This prevents the "MeterProvider has been shut down" crash loop
            try:
                from opentelemetry.metrics import _internal as metrics_internal

                metrics_internal._METER_PROVIDER = None
            except (ImportError, AttributeError):
                # Fallback for older OTel versions
                try:
                    metrics._METER_PROVIDER = None  # type: ignore[attr-defined]
                except AttributeError:
                    pass

            return True

        return False


def setup_meter_provider(
    resource: Resource,
    endpoint: str = "http://localhost:4318/v1/metrics",
    export_interval_ms: int = DEFAULT_METRIC_EXPORT_INTERVAL_MS,
    use_buffering: bool = False,
    retry_policy: Optional[RetryPolicy] = None,
    persist_queue: bool = False,
    persist_path: Optional[str] = None,
    persist_min_disk_space_mb: float = 10.0,
    prometheus_enabled: bool = False,
    prometheus_port: int = 9464,
    prometheus_host: str = "127.0.0.1",
    views: Optional[Sequence[View]] = None,
) -> Tuple[
    MeterProvider,
    Optional["BufferedOTLPMetricExporter"],
    Optional[Any],
    Optional[Callable[[], None]],
]:
    """Set up and configure MeterProvider for metrics collection.

    By default, this provider applies OpenTelemetry Views that drop high-volume
    auto-instrumentation metrics (e.g., process.*, system.*, test.*) to reduce
    Cloud Monitoring costs. This filtering is defined by DEFAULT_DROPPED_PATTERNS:
    - process.* - Process CPU, memory metrics
    - system.* - System-level metrics
    - asyncio.* - AsyncIO internals
    - cpython.* - CPython VM metrics
    - http.client.* - HTTP client auto-instrumentation
    - otel.sdk.* - OpenTelemetry SDK internals
    - test.* - Test metrics (pre-production/sandbox environments)
    - rpc.* - RPC client metrics

    To disable this filtering, set the environment variable MCA_DISABLE_METRIC_FILTERING=true.
    You may also pass custom `views` which will be appended to the active list.

    DP-16 view precedence: caller-supplied `views` take precedence over the SDK's
    default histogram boundary views. When a caller view targets the same
    `instrument_name` as one of the entries in `DEFAULT_HISTOGRAM_BOUNDARY_VIEWS`,
    that SDK boundary view is suppressed so the caller's aggregation wins
    cleanly. Pass `views=None` (default) to inherit SDK boundary shapes.

    Args:
        resource: OpenTelemetry Resource with metadata
        endpoint: OTLP HTTP endpoint for metrics
        export_interval_ms: Interval for periodic metric export
        use_buffering: Whether to use buffered exporter with retry logic
        retry_policy: RetryPolicy for retries (used if use_buffering=True)
        persist_queue: Whether to persist queue to disk (default: False)
        persist_path: Path for queue persistence (required if persist_queue=True)
        persist_min_disk_space_mb: Minimum free disk space (MB) for persistence (default: 10.0)
        prometheus_enabled: Whether to enable Prometheus exporter
        prometheus_port: Port for Prometheus HTTP server
        prometheus_host: Host to bind Prometheus HTTP server
        views: Optional list of custom OpenTelemetry Views to apply

    Returns:
        Tuple of (MeterProvider, BufferedExporter or None, PrometheusReader or None, ShutdownCallback or None)

    Note:
        If a MeterProvider is already set globally, a warning is issued and
        the new provider overwrites it. Creating multiple MCAClient instances
        will overwrite the global provider configuration.
    """
    from ..utils.exceptions import ConfigurationError

    # Comprehensive config key includes ALL parameters that affect provider behavior
    # to prevent silent feature loss when reusing providers
    config_key = (
        endpoint,
        export_interval_ms,
        use_buffering,
        prometheus_enabled,
        prometheus_port,
        prometheus_host,
        persist_queue,
        bool(retry_policy),  # Just presence, not identity
        tuple(views) if views else (),
    )

    with _PROVIDER_INIT_LOCKS_LOCK:
        existing_provider = metrics.get_meter_provider()

        # Don't warn on default NoOp/Proxy providers, only concrete MeterProvider
        if isinstance(existing_provider, MeterProvider):
            if getattr(existing_provider, "_shutdown", False):
                raise ConfigurationError(
                    "Global MeterProvider has been shut down. Cannot initialize new MCAClient "
                    "in this process. Restart the application or ensure clients are not used "
                    "after shutdown()."
                )

            with _MCA_PROVIDER_REGISTRY_LOCK:
                if existing_provider in _MCA_PROVIDER_REGISTRY:
                    entry = _MCA_PROVIDER_REGISTRY[existing_provider]
                    if entry["config_key"] == config_key:
                        logger.debug("Reusing existing MCA MeterProvider for identical config.")
                    else:
                        warnings.warn(
                            "Global MeterProvider has conflicting configuration. "
                            "Reusing the existing provider to maintain OTel global state immutability, "
                            "but telemetry behavior may not match requested config.",
                            ProviderAlreadySetWarning,
                            stacklevel=2,
                        )
                    entry["refcount"] += 1
                    return (
                        existing_provider,
                        entry.get("buffered_exporter"),
                        entry.get("prometheus_reader"),
                        entry.get("prometheus_shutdown"),
                    )

        # Provider initialization lock
        init_event = _PROVIDER_INIT_LOCKS.get(config_key)
        if init_event is None:
            init_event = threading.Event()
            _PROVIDER_INIT_LOCKS[config_key] = init_event
            is_initializing = True
        else:
            is_initializing = False

    if not is_initializing:
        # Wait for the other thread to initialize
        init_event.wait()

        # Check if initialization failed in the first thread
        with _PROVIDER_INIT_LOCKS_LOCK:
            if config_key in _PROVIDER_INIT_ERRORS:
                exc = _PROVIDER_INIT_ERRORS.pop(config_key)
                raise ConfigurationError(
                    f"MeterProvider initialization failed in another thread: {exc}"
                ) from exc

        # After waiting, the provider MUST be in the registry or we failed
        existing_provider = metrics.get_meter_provider()

        # Re-verify it's a valid MCA provider, not a dead or third-party provider
        if isinstance(existing_provider, MeterProvider):
            if getattr(existing_provider, "_shutdown", False):
                raise ConfigurationError(
                    "Global MeterProvider was shut down during concurrent initialization. "
                    "Cannot create new MCAClient. Restart the application."
                )

            with _MCA_PROVIDER_REGISTRY_LOCK:
                if existing_provider in _MCA_PROVIDER_REGISTRY:
                    entry = _MCA_PROVIDER_REGISTRY[existing_provider]
                    entry["refcount"] += 1
                    return (
                        existing_provider,
                        entry.get("buffered_exporter"),
                        entry.get("prometheus_reader"),
                        entry.get("prometheus_shutdown"),
                    )

        # Initialization failed in the other thread, or a non-MCA provider was set.
        # Raise explicit error instead of silently overwriting.
        raise ConfigurationError(
            "Concurrent MeterProvider initialization failed or was overridden by non-MCA code. "
            "Global provider is not in MCA registry. Cannot safely proceed."
        )

    try:
        # Story 8.7: Build final views list with configurable filtering.
        # DP-16 finding #11: caller-supplied views take precedence over the
        # SDK's default boundary views. OTel Python evaluates ALL matching
        # views (no built-in precedence), so two views targeting the same
        # instrument name produce conflicting metric streams plus a runtime
        # warning. To give callers a clean override path, the SDK's default
        # boundary views are filtered to exclude any instrument_name already
        # targeted by a caller-supplied view before being appended.
        final_views = list(views) if views else []
        caller_targeted_names = {
            getattr(v, "_instrument_name", None)
            for v in final_views
            if getattr(v, "_instrument_name", None)
        }
        disable_filtering = (
            os.environ.get("MCA_DISABLE_METRIC_FILTERING", "false").lower() == "true"
        )

        if not disable_filtering:
            logger.debug(
                "Applying default metric drop views for patterns: %s",
                DEFAULT_DROPPED_PATTERNS,
            )
            final_views.extend(DEFAULT_DROP_VIEWS)
        else:
            logger.info(
                "Metric filtering disabled via MCA_DISABLE_METRIC_FILTERING. All metrics will be exported."
            )

        # DP-16: Always apply seconds-scale histogram boundary views. They
        # reshape aggregation rather than drop, so MCA_DISABLE_METRIC_FILTERING
        # does not gate them. Drops are appended first; boundary views second.
        # Round-2 escape hatch: operators with in-flight Grafana dashboards
        # depending on the old [0, 5) bucket can set
        # MCA_DISABLE_HISTOGRAM_BOUNDARY_VIEWS=true to fall back to OTel
        # default boundaries for one release. The env var will be removed
        # in the next minor.
        disable_boundary_views = (
            os.environ.get("MCA_DISABLE_HISTOGRAM_BOUNDARY_VIEWS", "false").lower() == "true"
        )
        if not disable_boundary_views:
            sdk_boundary_views = [
                v
                for v in DEFAULT_HISTOGRAM_BOUNDARY_VIEWS
                if getattr(v, "_instrument_name", None) not in caller_targeted_names
            ]
            suppressed = len(DEFAULT_HISTOGRAM_BOUNDARY_VIEWS) - len(sdk_boundary_views)
            if suppressed:
                logger.info(
                    "DP-16: caller supplied %d view(s) overriding SDK boundary defaults; "
                    "%d SDK boundary view(s) suppressed.",
                    len(caller_targeted_names),
                    suppressed,
                )
            final_views.extend(sdk_boundary_views)
        else:
            logger.info(
                "DP-16 histogram boundary views disabled via "
                "MCA_DISABLE_HISTOGRAM_BOUNDARY_VIEWS=true. Histograms will use OTel default boundaries."
            )

        # Create OTLP metric exporter (buffered or standard)
        buffered_exporter: Optional[BufferedOTLPMetricExporter] = None
        exporter: Union[BufferedOTLPMetricExporter, OTLPMetricExporter]
        temporality = _resolve_temporality_preference()
        if use_buffering and retry_policy:
            buffered_kwargs: Dict[str, Any] = dict(
                endpoint=endpoint,
                retry_policy=retry_policy,
                persist_queue=persist_queue,
                persist_path=persist_path,
                persist_min_disk_space_mb=persist_min_disk_space_mb,
            )
            if temporality is not None:
                buffered_kwargs["preferred_temporality"] = temporality
            exporter = BufferedOTLPMetricExporter(**buffered_kwargs)
            exporter.start_background_worker()
            buffered_exporter = exporter
        else:
            otlp_kwargs: Dict[str, Any] = {"endpoint": endpoint}
            if temporality is not None:
                otlp_kwargs["preferred_temporality"] = temporality
            exporter = OTLPMetricExporter(**otlp_kwargs)

        # Create OTLP reader (existing code)
        otlp_reader = PeriodicExportingMetricReader(
            exporter,  # type: ignore[arg-type]
            export_interval_millis=export_interval_ms,
        )

        # Create Prometheus reader if enabled (NEW)
        prometheus_reader, prometheus_shutdown = setup_prometheus_exporter(
            prometheus_enabled=prometheus_enabled,
            prometheus_port=prometheus_port,
            prometheus_host=prometheus_host,
        )

        # Build readers list - always include OTLP, optionally add Prometheus
        readers = [otlp_reader]
        if prometheus_reader:
            readers.append(prometheus_reader)

        # Initialize meter provider with all readers and views
        provider = MeterProvider(resource=resource, metric_readers=readers, views=final_views)

        # CRITICAL: Register provider in MCA registry BEFORE setting global state
        # This prevents race condition where another thread fetches the global provider
        # but finds nothing in the registry
        with _MCA_PROVIDER_REGISTRY_LOCK:
            _MCA_PROVIDER_REGISTRY[provider] = {
                "refcount": 1,
                "config_key": config_key,
                "buffered_exporter": buffered_exporter,
                "prometheus_reader": prometheus_reader,
                "prometheus_shutdown": prometheus_shutdown,
            }

            # Set global meter provider AFTER registry assignment (atomic within lock)
            metrics.set_meter_provider(provider)

        return provider, buffered_exporter, prometheus_reader, prometheus_shutdown

    except Exception as e:
        # Store exception for waiting threads
        if is_initializing:
            with _PROVIDER_INIT_LOCKS_LOCK:
                _PROVIDER_INIT_ERRORS[config_key] = e
        raise
    finally:
        if is_initializing:
            with _PROVIDER_INIT_LOCKS_LOCK:
                if config_key in _PROVIDER_INIT_LOCKS:
                    del _PROVIDER_INIT_LOCKS[config_key]
                init_event.set()


def setup_logger_provider(
    resource: Resource,
    endpoint: str = "http://localhost:4318/v1/logs",
    batch_size: int = 512,
    use_buffering: bool = False,
    retry_policy: Optional[RetryPolicy] = None,
    persist_queue: bool = False,
    persist_path: Optional[str] = None,
    persist_min_disk_space_mb: float = 10.0,
    gcp_config: Optional["LoggingConfig"] = None,
) -> tuple[LoggerProvider, Optional["BufferedOTLPLogExporter"]]:
    """Set up and configure LoggerProvider for structured logging.

    Args:
        resource: OpenTelemetry Resource with metadata
        endpoint: OTLP HTTP endpoint for logs
        batch_size: Maximum batch size for log export
        use_buffering: Whether to use buffered exporter with retry logic
        retry_policy: RetryPolicy for retries (used if use_buffering=True)
        persist_queue: Whether to persist queue to disk (default: False)
        persist_path: Path for queue persistence (required if persist_queue=True)
        persist_min_disk_space_mb: Minimum free disk space (MB) for persistence (default: 10.0)
        gcp_config: Optional LoggingConfig for GCP Cloud Logging integration

    Returns:
        Tuple of (LoggerProvider, BufferedExporter or None)

    Note:
        If a LoggerProvider is already set globally, a warning is issued and
        the new provider overwrites it. Creating multiple MCAClient instances
        will overwrite the global provider configuration.
    """
    # Check if logger provider already set
    try:
        existing_provider = get_logger_provider()
        if existing_provider is not None and hasattr(existing_provider, "_resource"):
            warnings.warn(
                "LoggerProvider is already set globally. Creating multiple MCAClient "
                "instances will overwrite the global provider. Consider reusing a "
                "single MCAClient instance across your application.",
                ProviderAlreadySetWarning,
                stacklevel=3,
            )
    except Exception:
        # get_logger_provider() may not be available in all OpenTelemetry versions
        pass

    # Create OTLP log exporter (buffered or standard)
    buffered_exporter: Optional[BufferedOTLPLogExporter] = None
    log_exporter: Union[BufferedOTLPLogExporter, OTLPLogExporter]
    if use_buffering and retry_policy:
        log_exporter = BufferedOTLPLogExporter(
            endpoint=endpoint,
            retry_policy=retry_policy,
            persist_queue=persist_queue,
            persist_path=persist_path,
            persist_min_disk_space_mb=persist_min_disk_space_mb,
        )
        log_exporter.start_background_worker()
        buffered_exporter = log_exporter
    else:
        log_exporter = OTLPLogExporter(endpoint=endpoint)

    # Create batch log processor with configured batch size
    log_processor = BatchLogRecordProcessor(
        log_exporter,  # type: ignore[arg-type]
        max_export_batch_size=batch_size,
    )

    # Initialize logger provider
    logger_provider = LoggerProvider(resource=resource)
    logger_provider.add_log_record_processor(log_processor)

    # Add GCP Cloud Logging exporter if enabled (Story 6.2)
    if gcp_config and gcp_config.gcp_logging_enabled:
        # mypy-strict surfaced latent bug: project_id/log_name could be None even
        # when GCP logging is enabled. Fail fast with an actionable message.
        if gcp_config.gcp_project_id is None or gcp_config.gcp_log_name is None:
            from ..utils.exceptions import ConfigurationError

            raise ConfigurationError(
                "GCP Cloud Logging enabled but gcp_project_id or gcp_log_name is unset. "
                "Set both via MCAConfig or environment variables "
                "(MCA_GCP_PROJECT_ID, MCA_GCP_LOG_NAME)."
            )

        gcp_exporter: Any
        if use_buffering and retry_policy:
            from ..exporters.gcp_logging import BufferedCloudLoggingExporter

            gcp_exporter = BufferedCloudLoggingExporter(
                project_id=gcp_config.gcp_project_id,
                log_name=gcp_config.gcp_log_name,
                resource_type=gcp_config.gcp_resource_type,
                credentials=gcp_config.gcp_credentials,
                timeout=gcp_config.gcp_log_timeout,
                retry_policy=retry_policy,
            )
            gcp_exporter.start_background_worker()
        else:
            from ..exporters.gcp_logging import CloudLoggingExporter

            gcp_exporter = CloudLoggingExporter(
                project_id=gcp_config.gcp_project_id,
                log_name=gcp_config.gcp_log_name,
                resource_type=gcp_config.gcp_resource_type,
                credentials=gcp_config.gcp_credentials,
                timeout=gcp_config.gcp_log_timeout,
            )

        gcp_processor = BatchLogRecordProcessor(gcp_exporter, max_export_batch_size=batch_size)
        logger_provider.add_log_record_processor(gcp_processor)

    # Set global logger provider
    set_logger_provider(logger_provider)

    return logger_provider, buffered_exporter


def setup_tracer_provider(
    resource: Resource,
    endpoint: str = "http://localhost:4318/v1/traces",
    batch_size: int = 512,
    use_buffering: bool = False,
    retry_policy: Optional[RetryPolicy] = None,
    persist_queue: bool = False,
    persist_path: Optional[str] = None,
    persist_min_disk_space_mb: float = 10.0,
) -> tuple[TracerProvider, Optional["BufferedOTLPSpanExporter"]]:
    """Set up and configure TracerProvider for distributed tracing.

    Args:
        resource: OpenTelemetry Resource with metadata
        endpoint: OTLP HTTP endpoint for traces
        batch_size: Maximum batch size for trace export
        use_buffering: Whether to use buffered exporter with retry logic
        retry_policy: RetryPolicy for retries (used if use_buffering=True)
        persist_queue: Whether to persist queue to disk (default: False)
        persist_path: Path for queue persistence (required if persist_queue=True)
        persist_min_disk_space_mb: Minimum free disk space (MB) for persistence (default: 10.0)

    Returns:
        Tuple of (TracerProvider, BufferedExporter or None)

    Note:
        If a TracerProvider is already set globally, a warning is issued and
        the new provider overwrites it. Creating multiple MCAClient instances
        will overwrite the global provider configuration.
    """
    # Check if tracer provider already set
    existing_provider = trace.get_tracer_provider()
    if existing_provider is not None and hasattr(existing_provider, "_resource"):
        warnings.warn(
            "TracerProvider is already set globally. Creating multiple MCAClient "
            "instances will overwrite the global provider. Consider reusing a "
            "single MCAClient instance across your application.",
            ProviderAlreadySetWarning,
            stacklevel=3,
        )

    # Create OTLP trace exporter (buffered or standard)
    buffered_exporter: Optional[BufferedOTLPSpanExporter] = None
    trace_exporter: Union[BufferedOTLPSpanExporter, OTLPSpanExporter]
    if use_buffering and retry_policy:
        trace_exporter = BufferedOTLPSpanExporter(
            endpoint=endpoint,
            retry_policy=retry_policy,
            persist_queue=persist_queue,
            persist_path=persist_path,
            persist_min_disk_space_mb=persist_min_disk_space_mb,
        )
        trace_exporter.start_background_worker()
        buffered_exporter = trace_exporter
    else:
        trace_exporter = OTLPSpanExporter(endpoint=endpoint)

    # Create batch span processor with configured batch size
    span_processor = BatchSpanProcessor(
        trace_exporter,  # type: ignore[arg-type]
        max_export_batch_size=batch_size,
    )

    # Initialize tracer provider
    tracer_provider = TracerProvider(resource=resource)
    tracer_provider.add_span_processor(span_processor)

    # Set global tracer provider
    trace.set_tracer_provider(tracer_provider)

    return tracer_provider, buffered_exporter


def setup_gcp_trace_exporter(
    config: Any,
    resource: Resource,
    batch_size: int = 512,
) -> Optional["GCPCloudTraceExporter"]:
    """Set up GCP Cloud Trace exporter if enabled.

    Args:
        config: MCAConfig instance
        resource: OpenTelemetry Resource
        batch_size: Batch size for span processing

    Returns:
        GCPCloudTraceExporter instance or None if not enabled

    Raises:
        ConfigurationError: If GCP credentials are unavailable or invalid
    """
    if not config.gcp_trace_enabled:
        return None

    from ..core.gcp_auth import get_google_credentials, get_credentials_for_config
    from ..exporters.gcp_trace_exporter import GCPCloudTraceExporter
    from ..utils.exceptions import ConfigurationError

    # Get GCP credentials
    credentials = get_google_credentials(config)
    if not credentials:
        raise ConfigurationError(
            "GCP Cloud Trace enabled but no credentials available. "
            "Configure gcp_credentials_path, gcp_credentials_json, or ensure ADC is available."
        )

    # Determine project ID
    project_id = config.gcp_project_id
    if not project_id:
        # Extract from credentials
        creds = get_credentials_for_config(config)
        if creds:
            project_id = creds.project_id
        else:
            raise ConfigurationError(
                "Could not determine GCP project_id for Cloud Trace. "
                "Set gcp_project_id in config or use credentials with project_id."
            )

    # Create GCP Cloud Trace exporter
    trace_exporter = GCPCloudTraceExporter(
        project_id=project_id, credentials=credentials, resource=resource
    )

    import logging

    logger = logging.getLogger(__name__)
    logger.info("GCP Cloud Trace exporter enabled for project: %s", project_id)

    return trace_exporter


def setup_prometheus_exporter(
    prometheus_enabled: bool,
    prometheus_port: int = 9464,
    prometheus_host: str = "127.0.0.1",
) -> Tuple[Optional[Any], Optional[Callable[[], None]]]:
    """Set up Prometheus MetricReader with HTTP server for scraping.

    Creates a PrometheusMetricReader that exposes metrics on an HTTP endpoint
    for Prometheus to scrape. The HTTP server runs in a daemon thread and
    can be stopped via the returned callback.

    Architecture:
        This function integrates OpenTelemetry's PrometheusMetricReader with
        prometheus_client's WSGI app. The PrometheusMetricReader collects OTel
        metrics and writes them to the default prometheus_client REGISTRY, which
        the WSGI app reads to serve /metrics endpoint.

    Port Conflict Strategy:
        If the port is already in use (OSError), the function logs a warning and
        returns (None, None). This allows graceful degradation to OTLP-only export.
        The SDK will continue to operate normally without Prometheus metrics.
        This is intentional fail-soft behavior - no retries, no random ports.

    Lifecycle:
        - HTTP server starts immediately in a daemon thread
        - Server can be stopped by calling the returned shutdown callback
        - Daemon thread ensures process exit isn't blocked by the server
        - For batch jobs, consider using OTLP push instead of Prometheus pull

    Args:
        prometheus_enabled: Whether to enable Prometheus exporter
        prometheus_port: Port for Prometheus HTTP server (default: 9464)
        prometheus_host: Host to bind HTTP server (default: 127.0.0.1)

    Returns:
        Tuple of (PrometheusMetricReader or None, ShutdownCallback or None)
        Both are None if disabled or if initialization fails.

    Raises:
        No exceptions raised. All errors are caught and logged, returning (None, None).
    """
    if not prometheus_enabled:
        return None, None

    try:
        from opentelemetry.exporter.prometheus import PrometheusMetricReader
        from prometheus_client import make_wsgi_app
    except ImportError:
        logging.error(
            "opentelemetry-exporter-prometheus not installed. "
            "Cannot enable Prometheus exporter. "
            "Install with pip install mca-sdk[prometheus]"
        )
        return None, None

    try:
        # Create WSGI app for Prometheus metrics
        app = make_wsgi_app()

        # Create HTTP server
        # Allow reuse address to minimize "Address already in use" issues on quick restarts
        WSGIServer.allow_reuse_address = True
        httpd = make_server(prometheus_host, prometheus_port, app)

        # Start server in a daemon thread
        thread = threading.Thread(target=httpd.serve_forever)
        thread.daemon = True
        thread.start()

        # Define shutdown callback
        def shutdown_server() -> None:
            logging.debug("Shutting down Prometheus HTTP server...")
            httpd.shutdown()
            httpd.server_close()
            thread.join(timeout=2.0)
            logging.debug("Prometheus HTTP server stopped.")

        # Create PrometheusMetricReader
        # No need to pass registry explicitly, it uses default registry which make_wsgi_app uses
        reader = PrometheusMetricReader()

        logging.info(
            f"Prometheus metrics exposed on http://{prometheus_host}:{prometheus_port}/metrics"
        )
        return reader, shutdown_server

    except OSError as e:
        # Finding 8 fix: Fail-fast for port conflicts (production safety)
        # errno 98 = EADDRINUSE (Linux); winerror 10013/10048 = WSAEACCES/WSAEADDRINUSE (Windows)
        _port_conflict = (
            "Address already in use" in str(e)
            or getattr(e, "errno", None) == 98
            or getattr(e, "winerror", None) in (10013, 10048)
        )
        if _port_conflict:
            from ..utils.exceptions import ConfigurationError

            raise ConfigurationError(
                f"Prometheus port {prometheus_port} already in use. "
                f"Another service may be bound to this port. "
                "Change MCA_PROMETHEUS_PORT or disable with MCA_PROMETHEUS_ENABLED=false"
            ) from e
        else:
            # Other OS errors - log and continue
            logging.error(f"Failed to start Prometheus exporter: {e}")
            return None, None
    except Exception as e:
        # Other errors (import issues, etc.) - log and continue
        logging.error(f"Unexpected error initializing Prometheus exporter: {e}")
        return None, None


def setup_all_providers(
    service_name: str,
    model_id: Optional[str] = None,
    model_version: str = "0.3.0",
    team_name: Optional[str] = None,
    model_category: str = "internal",
    model_type: str = "regression",
    collector_endpoint: str = "http://localhost:4318",
    metric_export_interval_ms: int = 5000,
    log_batch_size: int = 100,
    trace_batch_size: int = 100,
    extra_resource: Optional[Dict[str, str]] = None,
    use_buffering: bool = False,
    retry_policy: Optional[RetryPolicy] = None,
    persist_queue: bool = False,
    persist_path: Optional[str] = None,
    persist_min_disk_space_mb: float = 10.0,
    gcp_logging_enabled: bool = False,
    gcp_project_id: Optional[str] = None,
    gcp_log_name: Optional[str] = None,
    gcp_resource_type: str = "global",
    gcp_credentials: Any = None,
    gcp_log_timeout: float = 60.0,
    prometheus_enabled: bool = False,
    prometheus_port: int = 9464,
    prometheus_host: str = "127.0.0.1",
    **resource_kwargs: Any,
) -> tuple[
    MeterProvider,
    LoggerProvider,
    TracerProvider,
    Resource,
    Optional["BufferedOTLPMetricExporter"],
    Optional["BufferedOTLPLogExporter"],
    Optional["BufferedOTLPSpanExporter"],
    Optional[Any],
    Optional[Callable[[], None]],
]:
    """Set up all OpenTelemetry providers with consistent configuration.

    This is a convenience function that sets up metrics, logs, and traces
    with a single call. Uses two-field taxonomy for model classification.

    Args:
        service_name: Name of the service
        model_id: Unique model identifier
        model_version: Model version string
        team_name: Team responsible for the model
        model_category: High-level category ("internal" or "vendor")
        model_type: Specific type ("regression", "time-series", "classification", "generative", "agentic")
        collector_endpoint: Base OTLP collector endpoint (without /v1/metrics suffix)
        metric_export_interval_ms: Interval for metric export in milliseconds
        log_batch_size: Batch size for log export
        trace_batch_size: Batch size for trace export
        extra_resource: Additional resource attributes from registry
        use_buffering: Whether to use buffered exporters with retry logic
        retry_policy: RetryPolicy for retries (used if use_buffering=True)
        persist_queue: Whether to persist queue to disk (default: False)
        persist_path: Path for queue persistence (required if persist_queue=True)
        persist_min_disk_space_mb: Minimum free disk space (MB) for persistence (default: 10.0)
        prometheus_enabled: Whether to enable Prometheus exporter
        prometheus_port: Port for Prometheus HTTP server
        prometheus_host: Host to bind Prometheus HTTP server
        **resource_kwargs: Additional resource attributes

    Returns:
        Tuple of (MeterProvider, LoggerProvider, TracerProvider, Resource,
                  BufferedMetricExporter, BufferedLogExporter, BufferedSpanExporter,
                  PrometheusMetricReader, PrometheusShutdownCallback)
        The buffered exporters are None if buffering is disabled.
        PrometheusMetricReader is None if Prometheus is disabled.
    """
    # Create resource with model metadata
    resource = create_resource_attributes(
        service_name=service_name,
        model_id=model_id,
        model_version=model_version,
        team_name=team_name,
        model_category=model_category,
        model_type=model_type,
        extra_resource=extra_resource,
        **resource_kwargs,
    )

    # Setup providers (with optional buffering and persistence)
    meter_provider, metric_exporter, prometheus_reader, prometheus_shutdown = setup_meter_provider(
        resource=resource,
        endpoint=f"{collector_endpoint}/v1/metrics",
        export_interval_ms=metric_export_interval_ms,
        use_buffering=use_buffering,
        retry_policy=retry_policy,
        persist_queue=persist_queue,
        persist_path=persist_path,
        persist_min_disk_space_mb=persist_min_disk_space_mb,
        prometheus_enabled=prometheus_enabled,
        prometheus_port=prometheus_port,
        prometheus_host=prometheus_host,
    )

    # Create GCP logging config if enabled
    from ..config.settings import LoggingConfig

    gcp_config = None
    if gcp_logging_enabled:
        gcp_config = LoggingConfig(
            gcp_logging_enabled=gcp_logging_enabled,
            gcp_project_id=gcp_project_id,
            gcp_log_name=gcp_log_name,
            gcp_resource_type=gcp_resource_type,
            gcp_credentials=gcp_credentials,
            gcp_log_timeout=gcp_log_timeout,
        )

    logger_provider, log_exporter = setup_logger_provider(
        resource=resource,
        endpoint=f"{collector_endpoint}/v1/logs",
        batch_size=log_batch_size,
        use_buffering=use_buffering,
        retry_policy=retry_policy,
        persist_queue=persist_queue,
        persist_path=persist_path,
        persist_min_disk_space_mb=persist_min_disk_space_mb,
        gcp_config=gcp_config,
    )

    tracer_provider, span_exporter = setup_tracer_provider(
        resource=resource,
        endpoint=f"{collector_endpoint}/v1/traces",
        batch_size=trace_batch_size,
        use_buffering=use_buffering,
        retry_policy=retry_policy,
        persist_queue=persist_queue,
        persist_path=persist_path,
        persist_min_disk_space_mb=persist_min_disk_space_mb,
    )

    return (
        meter_provider,
        logger_provider,
        tracer_provider,
        resource,
        metric_exporter,
        log_exporter,
        span_exporter,
        prometheus_reader,
        prometheus_shutdown,
    )
