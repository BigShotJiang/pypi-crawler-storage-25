"""Main MCA SDK client for model instrumentation.

This module provides the MCAClient class, the primary developer-facing API
for instrumenting models with OpenTelemetry.
"""

import atexit
import contextvars
import functools
import inspect
import json
import logging
import logging.handlers
import math
import os
import queue
import re
import signal
import sys
import tempfile
import threading
import time
import uuid
from contextlib import contextmanager
from types import FrameType
from typing import Any, Callable, Dict, Optional, Union

from opentelemetry import trace
from opentelemetry.sdk._logs import LoggingHandler

from ..config import MCAConfig
from .providers import setup_all_providers

# Module logger
from ..validation import validate_resource_attributes, MetricNamingConvention
from ..validation.telemetry_attributes import TelemetryAttributeValidator
from ..security.phi_filter import (
    is_enabled as _phi_enabled,
    filter_attributes as _phi_filter_attributes,
    warn_if_disabled as _phi_warn_if_disabled,
)
from ..security.secret_filter import (
    is_disabled as _secret_disabled,
    filter_attributes as _secret_filter_attributes,
)
from ..registry import RegistryClient, RegistryTelemetry, ModelConfig
from ..utils.exceptions import RegistryConnectionError, RegistryAuthError
from ..utils.version_check import check_version
from ..utils.serialization import extract_model_payload
from .. import __version__

# Module logger
logger = logging.getLogger(__name__)


# Reserved LogRecord attribute names — used to separate "extra" fields from
# the stdlib LogRecord fields when serializing to spillover.
_LOGRECORD_RESERVED_KEYS = frozenset(
    {
        "name",
        "msg",
        "args",
        "levelname",
        "levelno",
        "pathname",
        "filename",
        "module",
        "exc_info",
        "exc_text",
        "stack_info",
        "lineno",
        "funcName",
        "created",
        "msecs",
        "relativeCreated",
        "thread",
        "threadName",
        "processName",
        "process",
        "message",
    }
)


def _extra_from_record(record: logging.LogRecord) -> Dict[str, Any]:
    return {k: v for k, v in record.__dict__.items() if k not in _LOGRECORD_RESERVED_KEYS}


class _AuditSpilloverFile:
    """Append-only JSON-lines spillover for HIPAA audit records.

    When the primary async queue is saturated, records are written here so
    that log aggregators can ingest them from disk (HIPAA-compliant — unlike
    stderr, a JSON-lines file is structured and aggregator-ingestible).
    On drain, the listener replays each line as a LogRecord through the OTel
    handler, then truncates the file. Rotated at 10MB.
    """

    _MAX_BYTES = 10 * 1024 * 1024  # 10 MiB
    _MAX_ROTATIONS = 5

    def __init__(self, directory: Optional[str] = None) -> None:
        self._dir = (
            directory
            or os.environ.get("MCA_AUDIT_SPILL_DIR")
            or os.path.join(tempfile.gettempdir(), "mca_sdk_audit")
        )
        self._lock = threading.Lock()
        self._path: Optional[str] = None
        self._disabled = False
        try:
            os.makedirs(self._dir, exist_ok=True)
            self._path = os.path.join(
                self._dir,
                f"audit-spill-{os.getpid()}-{int(time.time())}.jsonl",
            )
        except Exception:
            self._disabled = True

    @property
    def path(self) -> Optional[str]:
        return self._path

    def is_available(self) -> bool:
        return not self._disabled and self._path is not None

    def _rotate_if_needed_locked(self) -> None:
        if not self._path:
            return
        try:
            if os.path.exists(self._path) and os.path.getsize(self._path) >= self._MAX_BYTES:
                for i in range(self._MAX_ROTATIONS - 1, 0, -1):
                    src = f"{self._path}.{i}"
                    dst = f"{self._path}.{i + 1}"
                    if os.path.exists(src):
                        os.replace(src, dst)
                os.replace(self._path, f"{self._path}.1")
        except Exception:
            pass

    def write(self, record: logging.LogRecord) -> bool:
        if self._disabled or not self._path:
            return False
        try:
            extra = _extra_from_record(record)
            safe_extra: Dict[str, Any] = {}
            for k, v in extra.items():
                try:
                    json.dumps(v)
                    safe_extra[k] = v
                except (TypeError, ValueError):
                    safe_extra[k] = repr(v)
            payload = {
                "timestamp_ns": time.time_ns(),
                "level": record.levelname,
                "name": record.name,
                "message": record.getMessage(),
                "extra": safe_extra,
            }
            line = json.dumps(payload, default=str) + "\n"
            with self._lock:
                self._rotate_if_needed_locked()
                with open(self._path, "a", encoding="utf-8") as f:
                    f.write(line)
            return True
        except Exception:
            return False

    def drain(self, emitter: Callable[[logging.LogRecord], None]) -> int:
        """Replay each spillover line through `emitter` and truncate the file.

        Returns the number of records emitted.
        """
        if self._disabled or not self._path:
            return 0
        count = 0
        with self._lock:
            if not os.path.exists(self._path):
                return 0
            try:
                with open(self._path, "r", encoding="utf-8") as f:
                    lines = f.readlines()
            except Exception:
                return 0
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except Exception:
                    continue
                try:
                    level = logging.getLevelName(payload.get("level", "INFO"))
                    if isinstance(level, str):
                        level = logging.INFO
                    record = logging.LogRecord(
                        name=payload.get("name", "mca_sdk.audit"),
                        level=level,
                        pathname="",
                        lineno=0,
                        msg=payload.get("message", ""),
                        args=None,
                        exc_info=None,
                    )
                    for k, v in (payload.get("extra") or {}).items():
                        record.__dict__[k] = v
                    emitter(record)
                    count += 1
                except Exception:
                    continue
            try:
                os.remove(self._path)
            except Exception:
                try:
                    with open(self._path, "w", encoding="utf-8") as f:
                        f.truncate(0)
                except Exception:
                    pass
        return count


class _AuditQueueHandler(logging.handlers.QueueHandler):
    """QueueHandler variant with HIPAA-compliant overflow.

    Story 6-42 remediation: records are a plan-level invariant. If the bounded
    audit queue is saturated, we:
      1. Write the record to a JSON-lines spillover file (aggregator-ingestible).
      2. If spillover fails, block on `put(timeout=5.0)` as a last resort.
    No silent drops, no unstructured stderr writes that bypass log pipelines.
    """

    def __init__(
        self,
        q: "queue.Queue[logging.LogRecord]",
        spillover: Optional[_AuditSpilloverFile] = None,
    ) -> None:
        super().__init__(q)
        self._spillover = spillover

    def set_spillover(self, spillover: _AuditSpilloverFile) -> None:
        self._spillover = spillover

    def enqueue(self, record: logging.LogRecord) -> None:
        try:
            self.queue.put_nowait(record)
            return
        except queue.Full:
            pass
        if self._spillover is not None and self._spillover.write(record):
            return
        try:
            self.queue.put(record, timeout=5.0)  # type: ignore[attr-defined]
            return
        except queue.Full:
            pass
        try:
            sys.stderr.write(
                f"[mca_sdk.audit] CRITICAL: audit record could not be enqueued "
                f"or spilled: {record.levelname}: {record.getMessage()}\n"
            )
        except Exception:
            pass


class _AuditPayload:
    """Lightweight payload pushed on the hot path.

    Avoids LogRecord construction on the calling thread (makeRecord ~23ms /
    1000 calls per the diagnostic profile). The drain thread reconstructs a
    LogRecord off-thread.
    """

    __slots__ = ("timestamp_ns", "level", "message", "extra")

    def __init__(
        self,
        level: int,
        message: str,
        extra: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.timestamp_ns = time.time_ns()
        self.level = level
        self.message = message
        self.extra = extra


class _AuditDrainThread(threading.Thread):
    """Drains `_AuditPayload` entries off-thread, constructs `LogRecord`, emits.

    Runs as a daemon. Also drains the spillover file on each wake-up and on
    stop() (called during shutdown or SIGTERM).
    """

    _SENTINEL = object()

    def __init__(
        self,
        payload_queue: "queue.SimpleQueue[Any]",
        otel_handler: logging.Handler,
        logger_name: str,
        spillover: Optional[_AuditSpilloverFile] = None,
        poll_interval: float = 0.1,
    ) -> None:
        super().__init__(
            name=f"mca-audit-drain-{logger_name}",
            daemon=True,
        )
        self._q = payload_queue
        self._handler = otel_handler
        self._logger_name = logger_name
        self._spillover = spillover
        self._poll_interval = poll_interval
        self._stopped = threading.Event()

    def _emit(self, record: logging.LogRecord) -> None:
        try:
            self._handler.emit(record)
        except Exception:
            pass

    def _payload_to_record(self, payload: _AuditPayload) -> logging.LogRecord:
        record = logging.LogRecord(
            name=self._logger_name,
            level=payload.level,
            pathname="",
            lineno=0,
            msg=payload.message,
            args=None,
            exc_info=None,
        )
        record.created = payload.timestamp_ns / 1e9
        extra = payload.extra
        # Story 6-31 round-2 (finding #8): run PHI filter off the hot path.
        # Enqueue stays cheap; the drain thread redacts before OTel emit so
        # "nothing matching PHI leaves the process" still holds. This moves
        # ~10-20us per call off the caller thread so the p99 SLO is met even
        # when every attribute is a PHI string.
        #
        # Story 6-32: also redact credential material. Order matches the
        # validator hot path: secret filter first (cheap key-name check),
        # PHI filter second.
        if extra:
            if not _secret_disabled():
                extra = _secret_filter_attributes(extra)
            if _phi_enabled():
                extra = _phi_filter_attributes(extra)
        if extra:
            for k, v in extra.items():
                if k not in _LOGRECORD_RESERVED_KEYS:
                    record.__dict__[k] = v
        return record

    def run(self) -> None:
        while True:
            try:
                item = self._q.get(timeout=self._poll_interval)
            except queue.Empty:
                if self._spillover is not None:
                    self._spillover.drain(self._emit)
                if self._stopped.is_set():
                    # Double-check queue emptied after signal.
                    try:
                        while True:
                            item = self._q.get_nowait()
                            if item is self._SENTINEL:
                                return
                            self._emit(self._payload_to_record(item))
                    except queue.Empty:
                        pass
                    if self._spillover is not None:
                        self._spillover.drain(self._emit)
                    return
                continue
            if item is self._SENTINEL:
                # Drain anything pending, then spillover, then exit.
                try:
                    while True:
                        pending = self._q.get_nowait()
                        if pending is self._SENTINEL:
                            continue
                        self._emit(self._payload_to_record(pending))
                except queue.Empty:
                    pass
                if self._spillover is not None:
                    self._spillover.drain(self._emit)
                return
            self._emit(self._payload_to_record(item))

    def stop(self, timeout: float = 5.0) -> None:
        self._stopped.set()
        try:
            self._q.put(self._SENTINEL)
        except Exception:
            pass
        self.join(timeout=timeout)


# Context variable for thread-safe prediction ID tracking
_prediction_context: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "prediction_context", default=None
)

# Context variable for tracking nested tool call depth
_tool_call_depth: contextvars.ContextVar[int] = contextvars.ContextVar("tool_call_depth", default=0)


# ============================================================================
# CREDENTIAL MASKING: Prevent SDK from exposing credentials in telemetry
# ============================================================================
#
# The SDK automatically masks technical credentials in error messages and
# telemetry to prevent accidental exposure. This is an SDK security concern.
#
# CREDENTIAL MASKING (SDK Security):
#    - AWS keys, GCP keys, GitHub tokens, JWT, Bearer tokens, etc.
#    - Prevents SDK from exposing credentials in error messages/traces
#
# PHI/PII HANDLING (Application Responsibility):
#    - The SDK performs NO PHI/PII masking or sanitization
#    - Applications MUST sanitize all PHI/PII data BEFORE passing to SDK methods
#    - The SDK cannot know domain-specific PHI context
#    - See SECURITY.md for detailed PHI handling guidance
#
# CRITICAL: Credentials MUST be masked in input_data and output payloads.
# ============================================================================

# Credential patterns (SDK security - ALWAYS mask these)
CREDENTIAL_PATTERNS = [
    # AWS Access Keys: AKIA followed by 16 alphanumeric chars
    ("aws_access_key", r"\bAKIA[0-9A-Z]{16}\b", "[AWS-KEY-REDACTED]"),
    # GCP API Keys: AIzaSy followed by 33 chars
    ("gcp_api_key", r"\bAIzaSy[A-Za-z0-9_-]{33}\b", "[GCP-KEY-REDACTED]"),
    # GitHub Personal Access Tokens: ghp_ prefix
    ("github_pat", r"\bghp_[A-Za-z0-9]{36}\b", "[GITHUB-TOKEN-REDACTED]"),
    # JWT Tokens: three base64 segments separated by dots
    (
        "jwt",
        r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b",
        "[JWT-REDACTED]",
    ),
    # Bearer Tokens
    ("bearer_token", r"Bearer\s+[A-Za-z0-9._+/=-]{20,}", "Bearer [TOKEN-REDACTED]"),
    # Basic Auth
    ("basic_auth", r"Basic\s+[A-Za-z0-9+/=_-]{20,}", "Basic [REDACTED]"),
    # TAX ID / SSN patterns (NNN-NN-NNNN format)
    ("ssn", r"\bSSN\s+\d{3}-\d{2}-\d{4}\b", "[SSN-REDACTED]"),
    ("tax_id", r"\bTAX_ID\s+\d{3}-\d{2}-\d{4}\b", "[TAX_ID-REDACTED]"),
]

# Combined patterns: Only credentials are masked by the SDK
ALL_SENSITIVE_PATTERNS = CREDENTIAL_PATTERNS


def _sanitize_json_credentials(data: Dict[str, Any]) -> Dict[str, Any]:
    """Safely sanitize credentials in parsed JSON/dict structures.

    This structural approach is safer than regex-based parsing of JSON strings,
    which was identified as "fundamentally flawed" in the adversarial review.

    Args:
        data: Parsed dictionary (from json.loads())

    Returns:
        Dictionary with credential values masked
    """
    credential_keys = {
        "token",
        "secret",
        "password",
        "api_key",
        "apikey",
        "access_key",
        "secret_key",
        "private_key",
        "auth_token",
        "bearer_token",
        "jwt",
        "client_secret",
        "api_secret",
        "aws_access_key_id",
        "aws_secret_access_key",
    }

    sanitized: Dict[str, Any] = {}
    for key, value in data.items():
        key_lower = key.lower()

        # Check if key indicates a credential
        is_credential = any(cred_key in key_lower for cred_key in credential_keys)

        if is_credential and isinstance(value, str) and len(value) >= 8:
            # Mask credential value
            sanitized[key] = "[REDACTED]"
        elif isinstance(value, dict):
            # Recursively sanitize nested dicts
            sanitized[key] = _sanitize_json_credentials(value)
        elif isinstance(value, list):
            # Recursively sanitize lists
            sanitized[key] = [
                _sanitize_json_credentials(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            # Pass through other values
            sanitized[key] = value

    return sanitized


def _sanitize_error_message(error_message: str, max_length: int = 200) -> str:
    """Sanitize error message to prevent credential leakage.

    Masks credentials (AWS keys, GCP keys, tokens) to prevent exposure in logs/traces.

    IMPORTANT: This function does NOT mask PHI/PII. Applications must sanitize PHI
    before passing data to SDK methods.

    Args:
        error_message: Raw error message from exception
        max_length: Maximum allowed message length (default: 200 chars)

    Returns:
        Sanitized error message with credentials masked and truncated if necessary
    """
    sanitized = error_message

    # Apply credential patterns
    for pattern_type, regex, replacement in ALL_SENSITIVE_PATTERNS:
        sanitized = re.sub(regex, replacement, sanitized)

    # Truncate if still too long after masking
    if len(sanitized) > max_length:
        return sanitized[:max_length] + "...[truncated]"

    return sanitized


def _sanitize_data_recursive(data: Any, max_value_length: int = 1024) -> Any:
    """Recursively sanitize credentials in nested data structures.

    CRITICAL: This function masks CREDENTIALS in input_data and output payloads
    to prevent credential leakage (identified as security regression in review).

    IMPORTANT: This function does NOT mask PHI/PII. Applications must sanitize PHI
    before passing data to SDK methods.

    Args:
        data: Data to sanitize (dict, list, str, or primitive)
        max_value_length: Maximum string length before rejection

    Returns:
        Sanitized data with credentials masked

    Raises:
        ValidationError: If string exceeds max_value_length
    """
    from ..utils.exceptions import ValidationError

    if isinstance(data, str):
        # Apply credential patterns to strings
        sanitized = data
        for pattern_type, regex, replacement in ALL_SENSITIVE_PATTERNS:
            sanitized = re.sub(regex, replacement, sanitized)

        # Enforce length limit (no silent truncation)
        if len(sanitized) > max_value_length:
            raise ValidationError(
                f"String value exceeds maximum length of {max_value_length} characters "
                f"(got {len(sanitized)} characters). Please reduce data size before instrumentation."
            )

        return sanitized

    elif isinstance(data, dict):
        # PHASE 1.3 FIX: Use structural parsing for credential masking (safer than regex)
        # First, apply structural credential sanitization
        sanitized_dict = _sanitize_json_credentials(data)
        # Then recursively sanitize remaining values
        return {k: _sanitize_data_recursive(v, max_value_length) for k, v in sanitized_dict.items()}

    elif isinstance(data, (list, tuple)):
        # Recursively sanitize list/tuple items (preserve type)
        sanitized_items = [_sanitize_data_recursive(item, max_value_length) for item in data]
        return type(data)(sanitized_items)

    elif isinstance(data, (int, float, bool, type(None))):
        # Primitives pass through unchanged
        return data

    else:
        # For custom objects, attempt conversion to dict
        import logging
        from dataclasses import is_dataclass, asdict

        logger = logging.getLogger("mca_sdk")

        # Try Pydantic v2
        if hasattr(data, "model_dump") and callable(getattr(data, "model_dump")):
            try:
                data_dict = data.model_dump()
                return _sanitize_data_recursive(data_dict, max_value_length)
            except Exception as e:
                logger.warning(f"Failed to convert Pydantic v2 model: {e}")

        # Try Pydantic v1
        if hasattr(data, "dict") and callable(getattr(data, "dict")):
            try:
                data_dict = data.dict()
                return _sanitize_data_recursive(data_dict, max_value_length)
            except Exception as e:
                logger.warning(f"Failed to convert Pydantic v1 model: {e}")

        # Try dataclasses
        if is_dataclass(data) and not isinstance(data, type):
            try:
                data_dict = asdict(data)
                return _sanitize_data_recursive(data_dict, max_value_length)
            except Exception as e:
                logger.warning(f"Failed to convert dataclass: {e}")

        # Try __dict__
        if hasattr(data, "__dict__"):
            try:
                data_dict = data.__dict__
                return _sanitize_data_recursive(data_dict, max_value_length)
            except Exception as e:
                logger.warning(f"Failed to access __dict__: {e}")

        # Try dict() constructor
        try:
            data_dict = dict(data)
            return _sanitize_data_recursive(data_dict, max_value_length)
        except Exception:
            pass

        # If all conversions fail, raise error
        raise ValidationError(
            f"Cannot sanitize object of type {type(data).__name__}. "
            f"Please convert to dict before instrumentation."
        )


class MCAClient:
    """Main client for MCA SDK instrumentation.

    This class provides a simple API for instrumenting models with metrics,
    logs, and traces. It handles provider setup, validation, and buffering
    automatically.

    IMPORTANT: Configuration is immutable after initialization. Runtime modifications
    to client.config are unsupported and may cause inconsistent behavior. Create a
    new client instance if configuration needs to change.

    Attributes:
        meter: The underlying OpenTelemetry ``Meter`` used to create custom
            instruments beyond the convenience recorders.
        logger: The OpenTelemetry ``Logger`` used for structured log export.
        tracer: The OpenTelemetry ``Tracer`` used to create spans. Wrap code
            blocks with :meth:`trace` for the common case.
        thresholds: Dictionary of ``metric_name -> threshold_value`` hydrated
            from the registry on startup. Empty when no registry is configured.
        service_name: The resolved service name. Matches the OTel resource
            attribute ``service.name``.
        prometheus_endpoint: URL of the local Prometheus scrape endpoint when
            Prometheus routing is enabled; ``None`` otherwise.
        buffer_stats: Dictionary of buffering/queue metrics, including queue
            depth and retry counters.

    Examples:
        Minimal usage (v0.7.0+ default - service_name only):
        >>> client = MCAClient(service_name="my-model")
        >>> client.record_prediction(latency=0.15)
        >>> client.shutdown()

        Production usage with full metadata:
        >>> client = MCAClient(
        ...     service_name="readmission-model",
        ...     model_id="mdl-001",
        ...     model_version="1.0.0",
        ...     team_name="clinical-ai",
        ...     strict_validation=True  # Explicitly enable strict validation
        ... )
        >>> def predict(data):
        ...     with client.trace("model.predict"):
        ...         result = model.predict(data)
        ...         client.record_prediction(data, result, latency=0.15)
        ...         return result
        >>> client.shutdown()

        Custom metrics:
        >>> counter = client.meter.create_counter("model.false_positives_total")
        >>> counter.add(1, {"threshold": "0.7"})

        Auto-instrumentation with decorator:
        >>> @client.predict()
        ... def predict(data):
        ...     return model.predict(data)
        >>> result = predict(input_data)

        Use as a context manager to guarantee ``shutdown()`` on exit:
        >>> with MCAClient(service_name="my-model") as client:
        ...     client.record_prediction(latency=0.15)
    """

    # Singleton instance for autolog() support
    _instance: Optional["MCAClient"] = None
    _instance_lock = threading.Lock()
    _MISSING = object()

    def __init__(
        self,
        service_name: Optional[str] = None,
        model_id: Optional[str] = None,
        model_version: Any = _MISSING,
        team_name: Optional[str] = None,
        model_type: str = "internal",
        collector_endpoint: Optional[str] = None,
        strict_validation: Optional[
            bool
        ] = None,  # v0.7.0: None = auto-detect, False = relaxed, True = strict
        auto_sanitize: bool = True,
        data_sanitizer_hook: Optional[Callable[[Dict[str, Any]], Dict[str, Any]]] = None,
        config: Optional[MCAConfig] = None,
        **kwargs: Any,
    ) -> None:
        """Initialize MCA SDK client.

        May take 2-5 seconds due to version check (2s timeout) and optional
        registry hydration (with circuit breaker and timeouts).

        Args:
            service_name: Name of the service (required if config not provided)
            model_id: Unique model identifier (required in strict mode)
            model_version: Model version string (required in strict mode)
            team_name: Team responsible for the model (required in strict mode)
            model_type: Type of model (internal, generative, vendor)
            collector_endpoint: OTLP collector endpoint
            strict_validation: Validation mode (default=None in v0.7.0+). None = auto-detect
                (strict if registry_url set, relaxed otherwise), False = minimal validation
                (service_name only), True = strict validation (all model-type fields required).
            auto_sanitize: DEPRECATED. Always True. Credential sanitization is now
                always enabled to prevent security regressions. This parameter will
                be removed in the next major version. Applications should still
                sanitize PHI before calling SDK methods.
            data_sanitizer_hook: Optional callback for application-specific PHI masking.
                Function signature: Callable[[dict], dict]. Called on input_data and
                output before SDK sanitization. Allows applications to inject their
                own domain-specific PHI masking logic.
                Example:
                    def sanitize_phi(data):
                        sanitized = data.copy()
                        sanitized.pop('patient_name', None)
                        sanitized.pop('ssn', None)
                        return sanitized
                    client = MCAClient(..., data_sanitizer_hook=sanitize_phi)
            config: MCAConfig instance (if provided, overrides other args)
            **kwargs: Additional configuration options including:
                - allow_insecure_collector (bool): Allow HTTP for collector
                - allow_insecure_registry (bool): Allow HTTP for registry
                - tls_insecure_registry (bool): Bypass SSL verification for registry
                - use_gcp_auth (bool): Use GCP ID token authentication

        Raises:
            ConfigurationError: If required configuration is missing
        """
        # FIXED (Round 13): Initialize ALL state variables FIRST to guarantee safe state
        # This ensures the client is always in a valid state even if later initialization fails
        self._cached_metrics: Dict[str, Any] = {}
        self._metrics_lock = threading.Lock()
        self._metric_cardinality: Dict[str, set[str]] = {}
        # Note: Round 14 Issue #2 - removed deque, using attribute tagging instead
        self._shutdown = False  # Tracks whether shutdown() has been called

        # Safe defaults before config is loaded
        self._max_attr_length = 1024
        self._max_attr_count = 128
        self._max_cached_metrics = 1000
        self._max_cardinality = 2000
        self._debug_mode = False
        self._collector_endpoint: Optional[str] = "http://localhost:4318"
        self._metric_export_interval_ms = 60000
        self._strict_validation: Optional[bool] = True

        # Handle deprecated auto_sanitize parameter
        if not auto_sanitize:
            import warnings

            warnings.warn(
                "DeprecationWarning: auto_sanitize=False is deprecated and will be removed "
                "in v1.0.0. Credential sanitization is now always enabled to prevent "
                "security regressions. This parameter no longer has any effect.",
                DeprecationWarning,
                stacklevel=2,
            )
        # Store for backward compatibility (but always sanitize regardless)
        self._auto_sanitize = True  # Always True now
        self._data_sanitizer_hook = data_sanitizer_hook

        # Now proceed with normal initialization
        self._initialize_logging()
        self._load_configuration(
            config,
            service_name,
            model_id,
            model_version,
            team_name,
            model_type,
            collector_endpoint,
            strict_validation,
            **kwargs,
        )

        # Update state with actual config values after config is loaded
        self._max_attr_length = getattr(self.config, "telemetry_max_attribute_length", 1024)
        self._max_attr_count = getattr(self.config, "telemetry_max_attribute_count", 128)
        self._max_cached_metrics = getattr(self.config, "telemetry_max_cached_metrics", 1000)
        self._max_cardinality = getattr(self.config, "telemetry_max_cardinality", 2000)
        self._debug_mode = self.config.debug_mode
        self._collector_endpoint = self.config.collector_endpoint
        self._metric_export_interval_ms = self.config.metric_export_interval_ms
        self._strict_validation = self.config.strict_validation
        # Story 1.18: Input/output capture flags for drift monitoring
        self._capture_input_data = self.config.capture_input_data
        self._capture_output_data = self.config.capture_output_data
        # Story 1.18 Fix #5: Size limit to prevent OTel span overflow
        self._capture_max_size_bytes = self.config.capture_max_size_bytes

        self._initialize_metric_routing()
        self._initialize_registry()
        self._validate_configuration()
        self._initialize_buffering_and_retry()
        self._initialize_providers()
        self._initialize_standard_metrics()
        self._initialize_agentic_tracking()

        # Set singleton instance for autolog() support
        with MCAClient._instance_lock:
            MCAClient._instance = self

    @classmethod
    def get_instance(cls) -> Optional["MCAClient"]:
        """Get the current MCAClient singleton instance.

        This method is used by autolog() and other auto-instrumentation features
        to access the active client without requiring explicit parameter passing.

        Returns:
            The current MCAClient instance, or None if not initialized.

        Examples:
            >>> client = MCAClient(service_name="ml-model", model_id="mdl-001", team_name="ds")
            >>> active_client = MCAClient.get_instance()
            >>> assert active_client is client
        """
        with cls._instance_lock:
            return cls._instance

    def _initialize_logging(self) -> None:
        """Setup SDK logging."""
        sdk_logger = logging.getLogger("mca_sdk")
        self._sdk_logger = sdk_logger

    def _load_configuration(
        self,
        config: Optional[MCAConfig],
        service_name: Optional[str],
        model_id: Optional[str],
        model_version: Any,
        team_name: Optional[str],
        model_type: str,
        collector_endpoint: Optional[str],
        strict_validation: Optional[bool],
        **kwargs: Any,
    ) -> None:
        """Load and validate configuration."""
        if config:
            self.config = config
        else:
            self.config = MCAConfig.load(
                service_name=service_name,
                model_id=model_id,
                model_version=(__version__ if model_version is self._MISSING else model_version),
                team_name=team_name,
                model_type=model_type,
                collector_endpoint=collector_endpoint,
                strict_validation=strict_validation,
                **kwargs,
            )

        # Enable debug logging if debug_mode is set
        if self.config.debug_mode:
            self._sdk_logger.setLevel(logging.DEBUG)
            self._sdk_logger.debug("Debug mode enabled")
            self._sdk_logger.debug(f"MCA SDK version: {__version__}")
            self._sdk_logger.debug(
                f"Configuration loaded - service_name={self.config.service_name}, "
                f"model_type={self.config.model_type}, "
                f"collector_endpoint={self.config.collector_endpoint}"
            )

        # Run version check on startup
        if self.config.debug_mode:
            self._sdk_logger.debug("Running version check...")
        check_version(__version__, timeout=self.config.version_check_timeout)

    def _initialize_metric_routing(self) -> None:
        """Setup metric prefix routing."""
        from ..utils.routing import get_metric_prefix

        self._metric_prefix = get_metric_prefix(self.config.model_category, self.config.model_type)
        if self.config.debug_mode:
            self._sdk_logger.debug(
                f"Metric routing: model_category='{self.config.model_category}', "
                f"model_type='{self.config.model_type}' → prefix='{self._metric_prefix}'"
            )

    def _initialize_registry(self) -> None:
        """Initialize registry client if configured."""
        self._registry_client: Optional[RegistryClient] = None
        self._registry_config: Optional[ModelConfig] = None
        self._thresholds: Dict[str, float] = {}
        self._registry_telemetry: Optional[RegistryTelemetry] = None
        self._refresh_running: bool = False

        # Environment-aware registry validation (Story 8.4, Story 2.7)
        # Validation returns True if hydration should proceed, False otherwise
        should_hydrate = self._validate_registry_requirements()

        if should_hydrate:
            if self.config.debug_mode:
                self._sdk_logger.debug(f"Initializing registry client: {self.config.registry_url}")
            self._hydrate_from_registry()
            # Track whether the background refresh thread was started
            if (
                self._registry_client
                and getattr(self.config, "refresh_interval_secs", 0)
                and self.config.refresh_interval_secs > 0
            ):
                self._refresh_running = True
            if self.config.debug_mode and self._registry_config:
                self._sdk_logger.debug(
                    f"Registry hydration successful - model_id={self._registry_config.model_id}, "
                    f"thresholds={len(self._thresholds)} configured"
                )
        elif self.config.debug_mode and self.config.registry_url:
            # Registry URL was provided but validation failed (e.g., missing auth, incomplete config)
            self._sdk_logger.debug(
                f"Registry URL configured ({self.config.registry_url}) but validation failed - "
                "operating without registry"
            )

    @property
    def _refresh_thread(self) -> Optional[threading.Thread]:
        """Proxy to registry client's refresh thread, or None if not running."""
        if self._refresh_running and self._registry_client:
            return getattr(self._registry_client, "_refresh_thread", None)
        return None

    def _validate_registry_requirements(self) -> bool:
        """Validate registry configuration (optional in all environments).

        Registry is OPTIONAL in all environments (dev/prod/staging).
        Logs informational messages when registry is unavailable or incomplete.

        Returns:
            True if registry hydration should proceed, False otherwise.

        Validation cases:
        1. No registry (no URL, no model_id): Log info, return False
        2. Partial registry (URL without model_id): Log warning, return False
        3. Partial registry (model_id without URL): Log info, return False
        4. Complete registry (URL + model_id): Validate authentication
           - Dev/Prod: Raise error if auth missing
           - Staging: Log warning and return False (prevent doomed 401 network call)
           - With auth: Return True (proceed with hydration)

        Note: Staging environment disables hydration when auth is missing to avoid
        slow startup penalty from doomed network calls.
        """
        has_url = bool(self.config.registry_url)
        has_model_id = bool(self.config.model_id)

        # Case 1: No registry configured at all
        if not has_url and not has_model_id:
            logger.info(
                f"Running in {self.config.environment} environment without registry. "
                "Registry lookups are disabled. SDK will use local configuration only."
            )
            return False

        # Case 2: Partial configuration (URL but no model_id)
        if has_url and not has_model_id:
            logger.warning(
                f"Registry URL provided but model_id missing in {self.config.environment}. "
                "Registry lookups will be disabled. Set MCA_MODEL_ID to enable registry."
            )
            return False

        # Case 3: Partial configuration (model_id but no URL)
        if has_model_id and not has_url:
            logger.info(
                f"Model ID provided but registry URL missing in {self.config.environment}. "
                "Registry lookups will be disabled. This is expected for local-only usage."
            )
            return False

        # Case 4: Both URL and model_id provided - validate authentication
        if has_url and has_model_id:
            has_token = bool(self.config.registry_token)
            using_gcp_auth = self.config.use_gcp_auth

            # Skip auth requirement if bypass enabled (internal unauthenticated dev endpoints)
            if not has_token and not using_gcp_auth and not self.config.tls_insecure_registry:
                if self.config.environment != "staging":
                    # Dev/Prod: Raise error for incomplete registry config
                    from ..utils.exceptions import ConfigurationError

                    raise ConfigurationError(
                        "Registry authentication required when registry URL and model ID are provided. "
                        "Set MCA_REGISTRY_TOKEN environment variable or use_gcp_auth=True."
                    )
                else:
                    # Staging: Disable hydration to prevent slow 401/timeout on startup
                    logger.warning(
                        "Registry URL and model ID provided in staging but authentication is missing. "
                        "Registry hydration disabled to prevent startup delay. Set MCA_REGISTRY_TOKEN to enable."
                    )
                    return False

            # Complete config with auth (or insecure mode) - proceed with hydration
            return True

        # Should never reach here, but default to False for safety
        return False

    def _validate_configuration(self) -> None:
        """Validate resource attributes."""
        if not self.config.strict_validation:
            return

        # Build resource attributes dict for validation
        resource_attrs: Dict[str, Optional[str]] = {"service.name": self.config.service_name}

        # Add prefix-specific attributes (determined by routing)
        if self._metric_prefix == "model":  # Traditional ML models
            resource_attrs.update(
                {
                    "model.id": self.config.model_id,
                    "model.version": self.config.model_version,
                    "team.name": self.config.team_name,
                }
            )
        elif self._metric_prefix == "genai":  # AI/LLM models
            resource_attrs.update(
                {
                    "llm.provider": self.config.llm_provider,
                    "llm.model": self.config.llm_model,
                    "team.name": self.config.team_name,
                }
            )
        elif self._metric_prefix == "agentic":  # Agentic AI models
            resource_attrs.update(
                {
                    "llm.provider": self.config.llm_provider,
                    "llm.model": self.config.llm_model,
                    "team.name": self.config.team_name,
                }
            )
        elif self._metric_prefix == "vendor":  # Vendor models
            resource_attrs.update(
                {
                    "model.type": self.config.model_type,
                    "vendor.name": self.config.vendor_name,
                    "team.name": self.config.team_name,
                }
            )

        validate_resource_attributes(
            resource_attrs,
            model_category=self.config.model_category,
            model_type=self.config.model_type,
            strict=self.config.strict_validation,
        )
        if self.config.debug_mode:
            self._sdk_logger.debug(f"Resource attributes validated: {list(resource_attrs.keys())}")

    def _get_gcp_credentials(self) -> Any:
        """Get GCP credentials for exporters (Story 6.5 integration)."""
        if not self.config.gcp_logging_enabled:
            return None

        try:
            from .gcp_auth import get_google_credentials

            scopes = ["https://www.googleapis.com/auth/logging.write"]
            return get_google_credentials(self.config, scopes=scopes)
        except Exception as e:
            self._sdk_logger.warning(f"Failed to load GCP credentials: {e}")
            return None

    def _initialize_buffering_and_retry(self) -> None:
        """Setup buffering, retry policy, circuit breaker."""
        from ..buffering.retry import RetryPolicy as _RetryPolicy
        from ..resilience.circuit_breaker import (
            CircuitBreakerRetryPolicy as _CircuitBreakerRetryPolicy,
        )

        self._retry_policy: Optional[_RetryPolicy] = None
        self._circuit_breaker_retry_policy: Optional[
            Union[_CircuitBreakerRetryPolicy, _RetryPolicy]
        ] = None
        self._telemetry_queue: Optional[Any] = None

        if not self.config.buffering_enabled:
            return

        # Create a simple queue stats object exposed for test/monitoring access
        max_size = getattr(self.config, "max_queue_size", 1000)

        class _TelemetryQueueStats:
            """Lightweight view of the telemetry queue for tests and monitoring.

            Exposes ``size``, ``max_size``, and ``is_full`` without granting
            callers access to the underlying queue. The object is rebuilt on
            every :class:`MCAClient` init, so it has no persistence semantics.
            """

            def __init__(self, max_size_val: int) -> None:
                """Store the queue capacity and seed ``size`` at zero.

                Args:
                    max_size_val: Configured queue capacity, mirroring
                        :attr:`MCAConfig.max_queue_size`.
                """
                self._max_size = max_size_val
                self._size = 0

            def size(self) -> int:
                """Return the current queue depth.

                Returns:
                    Number of items currently buffered.
                """
                return self._size

            @property
            def max_size(self) -> int:
                """Return the configured maximum queue capacity.

                Returns:
                    Queue capacity as an integer.
                """
                return self._max_size

            @property
            def is_full(self) -> bool:
                """Return ``True`` when the queue has reached capacity.

                Returns:
                    ``True`` if ``size >= max_size``, else ``False``.
                """
                return self._size >= self._max_size

        self._telemetry_queue = _TelemetryQueueStats(max_size)

        from ..buffering.retry import RetryPolicy

        self._retry_policy = RetryPolicy(
            max_attempts=self.config.retry_attempts,
            base_delay=self.config.base_delay,
            max_delay=self.config.max_delay,
            backoff_multiplier=self.config.backoff_multiplier,
        )

        # Wrap with circuit breaker if enabled (Story 3-3)
        if self.config.circuit_breaker_enabled:
            from ..resilience.circuit_breaker import CircuitBreakerRetryPolicy

            self._circuit_breaker_retry_policy = CircuitBreakerRetryPolicy(
                retry_policy=self._retry_policy,
                fail_max=self.config.circuit_breaker_fail_max,
                reset_timeout=self.config.circuit_breaker_timeout,
                name=f"{self.config.service_name}_circuit_breaker",
            )

            if self.config.debug_mode:
                self._sdk_logger.debug(
                    f"Circuit breaker enabled: "
                    f"fail_max={self.config.circuit_breaker_fail_max}, "
                    f"timeout={self.config.circuit_breaker_timeout}s"
                )
        else:
            self._circuit_breaker_retry_policy = self._retry_policy

        if self.config.debug_mode:
            self._sdk_logger.debug(
                f"Buffering enabled: "
                f"retry_attempts={self.config.retry_attempts}, "
                f"max_delay={self.config.max_delay}s"
            )

        # Queue recovery logging (Story 3-4)
        if self.config.persist_queue and self.config.debug_mode:
            self._sdk_logger.debug(
                f"Queue persistence enabled - queues will be recovered "
                f"during exporter initialization from: {self.config.persist_path}"
            )

    def _initialize_providers(self) -> None:
        """Setup OpenTelemetry providers."""
        extra_resource: Dict[str, Any] = {}

        # Merge extra_resource from registry config
        if self._registry_config and self._registry_config.extra_resource:
            extra_resource.update(self._registry_config.extra_resource)

        # Add thresholds as resource attributes (threshold.*)
        # NOTE: Check for collisions to prevent silently overwriting user-provided keys
        if self._thresholds:
            threshold_attributes = self._convert_thresholds_to_attributes(self._thresholds)

            # Prevent silent collision: user-provided extra_resource takes precedence
            collisions = []
            for key, value in threshold_attributes.items():
                if key not in extra_resource:
                    extra_resource[key] = value
                else:
                    collisions.append(key)

            if collisions:
                self._sdk_logger.warning(
                    f"Threshold keys already exist in extra_resource and will NOT be overwritten: "
                    f"{collisions}. User-provided values take precedence over Registry thresholds."
                )

            added_count = len(threshold_attributes) - len(collisions)
            if self.config.debug_mode and added_count > 0:
                self._sdk_logger.debug(
                    f"Added {added_count} threshold attributes to resource "
                    f"({len(collisions)} skipped due to collisions)"
                )

        if self.config.debug_mode:
            self._sdk_logger.debug("Setting up OpenTelemetry providers...")

        (
            self._meter_provider,
            self._logger_provider,
            self._tracer_provider,
            self._resource,
            self._metric_exporter,
            self._log_exporter,
            self._span_exporter,
            self._prometheus_reader,
            self._prometheus_shutdown,
        ) = setup_all_providers(
            service_name=self.config.service_name,
            model_id=self.config.model_id,
            model_version=self.config.model_version,
            team_name=self.config.team_name,
            model_category=self.config.model_category,
            model_type=self.config.model_type,
            collector_endpoint=self.config.collector_endpoint,  # type: ignore[arg-type]
            metric_export_interval_ms=self.config.metric_export_interval_ms,
            log_batch_size=self.config.log_batch_size,
            trace_batch_size=self.config.trace_batch_size,
            extra_resource=extra_resource,
            use_buffering=self.config.buffering_enabled,
            retry_policy=self._circuit_breaker_retry_policy,  # type: ignore[arg-type]
            persist_queue=self.config.persist_queue,
            persist_path=self.config.persist_path,
            persist_min_disk_space_mb=self.config.persist_min_disk_space_mb,
            gcp_logging_enabled=self.config.gcp_logging_enabled,
            gcp_project_id=self.config.gcp_project_id,
            gcp_log_name=self.config.gcp_log_name,
            gcp_resource_type=self.config.gcp_resource_type,
            gcp_credentials=self._get_gcp_credentials(),
            gcp_log_timeout=self.config.gcp_log_timeout,
            prometheus_enabled=self.config.prometheus_enabled,
            prometheus_port=self.config.prometheus_port,
            prometheus_host=self.config.prometheus_host,
        )

        if self.config.debug_mode:
            self._sdk_logger.debug(
                f"OpenTelemetry providers initialized - "
                f"endpoint={self.config.collector_endpoint}, "
                f"metric_interval={self.config.metric_export_interval_ms}ms, "
                f"log_batch_size={self.config.log_batch_size}, "
                f"trace_batch_size={self.config.trace_batch_size}"
            )

        # Setup GCP Cloud Trace exporter if enabled
        self._gcp_trace_exporter = None

        if self.config.gcp_trace_enabled:
            from .providers import setup_gcp_trace_exporter
            from opentelemetry.sdk.trace.export import BatchSpanProcessor

            gcp_exporter = setup_gcp_trace_exporter(
                config=self.config,
                resource=self._resource,
                batch_size=self.config.trace_batch_size,
            )

            if gcp_exporter:
                gcp_processor = BatchSpanProcessor(
                    gcp_exporter,  # type: ignore[arg-type]
                    max_export_batch_size=self.config.trace_batch_size,
                )
                self._tracer_provider.add_span_processor(gcp_processor)
                self._gcp_trace_exporter = gcp_exporter

                if self.config.debug_mode:
                    self._sdk_logger.debug("GCP Cloud Trace exporter added to tracer provider")

        # Get instances for user access
        self._meter = self._meter_provider.get_meter(f"{self.config.service_name}.meter")
        self._tracer = self._tracer_provider.get_tracer(f"{self.config.service_name}.tracer")

        # Initialize circuit breaker metrics if enabled (Story 3-3)
        # Use Protocol for type-safe meter injection
        from ..buffering.exporters import MeterSettable

        if self.config.circuit_breaker_enabled and self._circuit_breaker_retry_policy:
            if isinstance(self._circuit_breaker_retry_policy, MeterSettable):
                self._circuit_breaker_retry_policy.set_meter(self._meter)

        # Initialize persistence metrics for buffered exporters (Story 3-4)
        for exporter in [
            self._metric_exporter,
            self._log_exporter,
            self._span_exporter,
        ]:
            if exporter and isinstance(exporter, MeterSettable):
                exporter.set_meter(self._meter)

        # Setup Python logging integration
        self._setup_logging()

    def _initialize_standard_metrics(self) -> None:
        """Create standard prediction metrics."""
        self._predictions_counter = self._meter.create_counter(
            f"{self._metric_prefix}.predictions_total",
            description="Total number of model predictions",
        )
        self._latency_histogram = self._meter.create_histogram(
            f"{self._metric_prefix}.latency_seconds",
            description="Model prediction latency",
            unit="s",
        )

        # Add dedicated errors counter for dual recording (Issue #10)
        # FIXED (Issue #7): Remove unit="1" for consistency with _predictions_counter
        self._errors_counter = self._meter.create_counter(
            f"emms_{self._metric_prefix}_errors_total",
            description="Total number of prediction errors",
        )

        self._mae_histogram = self._meter.create_histogram(
            f"{self._metric_prefix}.mae",
            description="Mean Absolute Error",
        )

        self._rmse_histogram = self._meter.create_histogram(
            f"{self._metric_prefix}.rmse",
            description="Root Mean Squared Error",
        )

        # FIXED (Round 13): State initialization moved to __init__() to guarantee safe state
        # All _max_* variables, locks, and dicts are now initialized before any complex setup

        if self._debug_mode:
            self._sdk_logger.debug(
                f"Standard metrics created: {self._metric_prefix}.predictions_total (counter), "
                f"{self._metric_prefix}.latency_seconds (histogram), "
                f"{self._metric_prefix}.mae (histogram), "
                f"{self._metric_prefix}.rmse (histogram)"
            )

        # Initialize metric naming validation
        self._strict_validation = self.config.strict_validation
        self._metric_validator = MetricNamingConvention(
            model_category=self.config.model_category,
            model_type=self.config.model_type,
            strict=bool(self._strict_validation),
        )

        # Initialize registry telemetry
        if self._registry_client:
            self._registry_telemetry = RegistryTelemetry(self._meter)

    def _initialize_agentic_tracking(self) -> None:
        """Setup agentic AI metrics and cleanup thread (eager initialization)."""
        self._active_goals: Dict[str, tuple[Any, ...]] = {}
        self._goals_lock = threading.Lock()
        self._cleanup_thread_stop = threading.Event()
        self._cleanup_thread: Optional[threading.Thread] = None

        # Story 1.19: Recovery state tracking for tool retries
        # Maps (goal_id, tool_name) -> {"attempts": int, "first_failed": bool}
        self._tool_execution_state: Dict[tuple[Any, ...], Dict[str, Any]] = {}
        self._tool_state_lock = threading.Lock()

        # Initialize agentic metrics to None first
        self._goals_started_counter: Any = None
        self._goals_completed_counter: Any = None
        self._goals_failed_counter: Any = None
        self._goal_duration_histogram: Any = None
        self._tool_calls_counter: Any = None
        self._tool_latency_histogram: Any = None
        self._tool_errors_counter: Any = None
        self._human_interventions_counter: Any = None
        self._intervention_wait_histogram: Any = None
        self._goal_cleanup_errors_counter: Any = None
        self._reasoning_steps_counter: Any = None

        # Create metrics eagerly
        self._initialize_agentic_metrics()

        # Start background cleanup thread
        self._start_cleanup_thread()

    def _setup_logging(self) -> None:
        """Setup Python logging integration with OpenTelemetry."""
        self._logger = logging.getLogger(f"{self.config.service_name}.logger")

        # HIPAA audit trail requires INFO-level prediction records. Operators who need
        # to reduce volume must do so via the ambient logging config, not via SDK flag.
        self._logger.setLevel(logging.DEBUG if self._debug_mode else logging.INFO)

        # Add OTel handler and store reference for cleanup
        self._otel_handler = LoggingHandler(logger_provider=self._logger_provider)
        self._logger.addHandler(self._otel_handler)

        # PHI attribute filter is opt-in (disabled by default). Emit a
        # one-shot WARNING on first MCAClient init so operators learn the
        # SDK is not redacting PHI on their behalf.
        _phi_warn_if_disabled(self._logger)

        # Story 6-42 / adversarial-round-2: hot-path audit emission.
        #
        # Two parallel paths, both HIPAA-compliant:
        #
        #   1) FAST PATH (used by record_prediction):
        #        _enqueue_audit_fast(msg, extra) pushes a slotted _AuditPayload
        #        onto _audit_payload_queue (queue.SimpleQueue). A dedicated
        #        _AuditDrainThread reconstructs LogRecord and calls
        #        _otel_handler.emit off-thread. This bypasses the stdlib
        #        `Logger.info` -> `makeRecord` -> `callHandlers` -> `QueueHandler.emit`
        #        path (~140ms / 1000 calls per the diagnostic profile).
        #
        #   2) API PATH (used by `_audit_logger.info(...)`):
        #        Existing QueueHandler + QueueListener. Kept intact so callers
        #        using the logger API (and the test suite in
        #        tests/unit/test_audit_log_async.py) continue to work.
        #
        # Both paths share the same spillover file and the same OTel handler.
        # Audit emission can be disabled with MCA_DISABLE_AUDIT_LOG=true for
        # the Block C measurement run in the distribution harness.

        self._audit_disabled = os.environ.get("MCA_DISABLE_AUDIT_LOG", "").lower() in (
            "1",
            "true",
            "yes",
        )

        self._audit_spillover = _AuditSpilloverFile()

        # API-path wiring (unchanged semantics).
        self._audit_queue: "queue.Queue[logging.LogRecord]" = queue.Queue(maxsize=10000)
        self._audit_queue_handler = _AuditQueueHandler(
            self._audit_queue, spillover=self._audit_spillover
        )
        self._audit_logger = logging.getLogger(f"{self.config.service_name}.audit")
        self._audit_logger.setLevel(logging.INFO)
        self._audit_logger.addHandler(self._audit_queue_handler)
        self._audit_logger.propagate = False
        self._audit_listener = logging.handlers.QueueListener(
            self._audit_queue,
            self._otel_handler,
            respect_handler_level=True,
        )
        self._audit_listener.start()

        # Fast-path wiring.
        self._audit_payload_queue: "queue.SimpleQueue[Any]" = queue.SimpleQueue()
        self._audit_drain_thread = _AuditDrainThread(
            payload_queue=self._audit_payload_queue,
            otel_handler=self._otel_handler,
            logger_name=f"{self.config.service_name}.audit",
            spillover=self._audit_spillover,
        )
        self._audit_drain_thread.start()

        # atexit + SIGTERM drain hooks (finding 8). Respect user-installed
        # handlers: only install SIGTERM if no prior handler AND on main
        # thread. MCA_DISABLE_SIGNAL_HANDLERS=true opts out entirely for
        # apps that manage signals themselves.
        self._atexit_registered = False
        self._signal_registered = False
        try:
            atexit.register(self._atexit_shutdown)
            self._atexit_registered = True
        except Exception:
            pass
        if os.environ.get("MCA_DISABLE_SIGNAL_HANDLERS", "").lower() not in (
            "1",
            "true",
            "yes",
        ):
            try:
                if threading.current_thread() is threading.main_thread():
                    prior = signal.getsignal(signal.SIGTERM)
                    if prior in (signal.SIG_DFL, signal.SIG_IGN, None):
                        signal.signal(signal.SIGTERM, self._sigterm_handler)
                        self._signal_registered = True
            except Exception:
                pass

    def _atexit_shutdown(self) -> None:
        try:
            if not getattr(self, "_shutdown", False):
                self.shutdown(timeout_millis=5000)
        except Exception:
            pass

    def _sigterm_handler(self, signum: int, frame: Optional[FrameType]) -> None:
        try:
            if not getattr(self, "_shutdown", False):
                self.shutdown(timeout_millis=5000)
        except Exception:
            pass

    def _enqueue_audit_fast(self, message: str, extra: Optional[Dict[str, Any]] = None) -> None:
        """Hot-path audit emission that bypasses stdlib logger machinery.

        Pushes a slotted payload onto the fast-path SimpleQueue; the drain
        thread constructs the LogRecord and calls _otel_handler.emit
        off-thread. When MCA_DISABLE_AUDIT_LOG is set, this is a no-op
        (used only by the Block C measurement to isolate OTLP exporter cost
        from audit cost).
        """
        if self._audit_disabled:
            return
        # Story 6-31 round-2 (finding #8): PHI redaction is deferred to the
        # drain thread (_payload_to_record) so this enqueue stays off the
        # caller's hot path. The invariant is "no PHI leaves the process",
        # enforced at _otel_handler.emit — the drain redacts before emit.
        # The spillover path below is the only synchronous alternate route
        # to persistence, so it gets its own filter pass before writing.
        payload = _AuditPayload(logging.INFO, message, extra)
        try:
            self._audit_payload_queue.put_nowait(payload)
            return
        except queue.Full:
            # SimpleQueue is unbounded; this branch exists for symmetry in
            # case we swap to a bounded SimpleQueue in future. Fall through
            # to spillover / blocking fallback.
            pass
        # Spillover path — construct a minimal LogRecord to reuse the
        # spillover serializer. Still off the OTel emit hot path.
        # PHI must be redacted before disk write (spillover bypasses the
        # drain thread's filter).
        # Story 6-32: secrets redacted alongside PHI, same ordering as the
        # validator hot path (secret first, then PHI).
        spillover_extra = extra
        if spillover_extra:
            if not _secret_disabled():
                spillover_extra = _secret_filter_attributes(spillover_extra)
            if _phi_enabled():
                spillover_extra = _phi_filter_attributes(spillover_extra)
        try:
            record = logging.LogRecord(
                name=f"{self.config.service_name}.audit",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg=message,
                args=None,
                exc_info=None,
            )
            if spillover_extra:
                for k, v in spillover_extra.items():
                    if k not in _LOGRECORD_RESERVED_KEYS:
                        record.__dict__[k] = v
            if self._audit_spillover.write(record):
                return
        except Exception:
            pass
        # Blocking last resort: keep HIPAA invariant even if spillover failed.
        try:
            self._audit_payload_queue.put(payload)
        except Exception:
            try:
                sys.stderr.write(
                    f"[mca_sdk.audit] CRITICAL: fast-path enqueue failed: " f"{message}\n"
                )
            except Exception:
                pass

    def _initialize_agentic_metrics(self) -> None:
        """Initialize agentic AI metrics (eager initialization).

        Creates all agent.* metrics at client initialization. This ensures
        consistent metric instances are available when agentic features are used.
        """
        if self._goals_started_counter is not None:
            return  # Already initialized

        self._goals_started_counter = self._meter.create_counter(
            "agent.goals_started_total",
            description="Total number of agent goals started",
            unit="1",
        )
        self._goals_completed_counter = self._meter.create_counter(
            "agent.goals_completed_total",
            description="Total number of agent goals completed successfully",
            unit="1",
        )
        self._goals_failed_counter = self._meter.create_counter(
            "agent.goals_failed_total",
            description="Total number of agent goals that failed",
            unit="1",
        )
        self._goal_duration_histogram = self._meter.create_histogram(
            "agent.goal_duration_seconds",
            description="Duration of agent goal execution",
            unit="s",
        )
        self._tool_calls_counter = self._meter.create_counter(
            "agent.tool_calls_total",
            description="Total number of tool calls made by agent",
            unit="1",
        )
        self._tool_latency_histogram = self._meter.create_histogram(
            "agent.tool_latency_seconds",
            description="Latency of tool executions",
            unit="s",
        )
        self._tool_errors_counter = self._meter.create_counter(
            "agent.tool_errors_total",
            description="Total number of tool execution errors",
            unit="1",
        )
        self._human_interventions_counter = self._meter.create_counter(
            "agent.human_interventions_total",
            description="Total number of human interventions requested",
            unit="1",
        )
        self._intervention_wait_histogram = self._meter.create_histogram(
            "agent.intervention_wait_time_seconds",
            description="Time spent waiting for human intervention",
            unit="s",
        )
        self._goal_cleanup_errors_counter = self._meter.create_counter(
            "agent.goal_cleanup_errors_total",
            description="Total number of errors during stale goal cleanup",
            unit="1",
        )
        self._reasoning_steps_counter = self._meter.create_counter(
            "agent.reasoning_steps_total",
            description="Total number of reasoning steps executed by agent",
            unit="1",
        )

    def _start_cleanup_thread(self) -> None:
        """Start background thread for periodic stale goal cleanup.

        The cleanup thread wakes every 300 seconds (5 minutes) to check for
        and remove stale goals, ensuring memory doesn't leak even during
        idle periods.
        """
        self._cleanup_thread = threading.Thread(
            target=self._background_cleanup_loop, daemon=True, name="mca-sdk-cleanup"
        )
        self._cleanup_thread.start()

    def _background_cleanup_loop(self) -> None:
        """Background thread loop that periodically cleans up stale goals.

        Runs independently of agent activity to ensure cleanup happens
        even during idle periods. Wakes every cleanup_thread_poll_interval
        seconds (from config) or when stop event is set.
        """
        while not self._cleanup_thread_stop.wait(timeout=self.config.cleanup_thread_poll_interval):
            try:
                self._cleanup_stale_goals()
            except Exception as e:
                # Log and record metric, but don't crash the cleanup thread
                sdk_logger = logging.getLogger("mca_sdk")
                sdk_logger.error(f"Error in background cleanup thread: {e}")
                # Record cleanup failure for monitoring/alerting
                self._goal_cleanup_errors_counter.add(
                    1, attributes={"error_type": type(e).__name__}
                )

    def _stop_cleanup_thread(self, timeout: float = 5.0) -> None:
        """Stop the background cleanup thread gracefully.

        Args:
            timeout: Maximum time to wait for thread to stop (seconds)
        """
        if self._cleanup_thread and self._cleanup_thread.is_alive():
            self._cleanup_thread_stop.set()
            self._cleanup_thread.join(timeout=timeout)
            if self._cleanup_thread.is_alive():
                sdk_logger = logging.getLogger("mca_sdk")
                sdk_logger.warning("Cleanup thread did not stop within timeout")

    def _ensure_cleanup_thread_alive(self) -> None:
        """Restart cleanup thread if dead (Finding 9 fix).

        Called periodically to detect and recover from thread failures.
        """
        if not self._cleanup_thread or not self._cleanup_thread.is_alive():
            sdk_logger = logging.getLogger("mca_sdk")
            sdk_logger.warning("Cleanup thread died, restarting...")
            self._start_cleanup_thread()

    def _cleanup_stale_goals(self, max_age_seconds: float = 3600) -> None:
        """Clean up stale goals that were never completed to prevent memory leaks.

        This method is called periodically by the background cleanup thread to remove
        goals older than max_age_seconds from the _active_goals dictionary.

        Args:
            max_age_seconds: Maximum age of a goal in seconds before cleanup (default: 1 hour)
        """
        current_time = time.perf_counter()
        stale_goal_ids = []

        # Find stale goals (acquire lock for thread safety)
        with self._goals_lock:
            for goal_id, (
                span,
                start_time,
                context_token,
            ) in self._active_goals.items():
                age = current_time - start_time
                if age > max_age_seconds:
                    stale_goal_ids.append(goal_id)

        # Clean up stale goals (acquire lock again to remove)
        if not stale_goal_ids:
            return

        from opentelemetry import context as otel_context
        from opentelemetry.trace import Status, StatusCode

        with self._goals_lock:
            for goal_id in stale_goal_ids:
                if goal_id not in self._active_goals:
                    continue  # Already completed, skip

                span, start_time, context_token = self._active_goals.pop(goal_id)

                try:
                    # End the stale span with a warning
                    duration = current_time - start_time
                    span.set_attribute("goal_status", "timeout")
                    span.set_attribute("goal_duration_seconds", duration)
                    span.set_attribute("goal_cleanup_reason", "stale_goal_timeout")

                    span.set_status(
                        Status(StatusCode.ERROR, f"Goal timed out after {duration:.1f}s")
                    )
                    span.end()

                    # Record as failed goal
                    # Timeout is considered a failure (AC: 2)
                    self._goals_failed_counter.add(1, attributes={"status": "timeout"})
                    self._goal_duration_histogram.record(duration, attributes={"status": "timeout"})

                    if self.config.debug_mode:
                        sdk_logger = logging.getLogger("mca_sdk")
                        sdk_logger.warning(
                            f"[{goal_id}] Stale goal cleaned up after {duration:.1f}s "
                            f"(max_age={max_age_seconds}s)"
                        )
                finally:
                    # Always detach context even if span operations fail
                    otel_context.detach(context_token)

    @property
    def meter(self) -> Any:
        """Get the OpenTelemetry Meter for creating custom metrics.

        Returns:
            Meter instance for creating counters, histograms, gauges
        """
        return self._meter

    @property
    def logger(self) -> logging.Logger:
        """Get the Python logger with OpenTelemetry integration.

        Returns:
            Logger instance for structured logging
        """
        return self._logger

    @property
    def tracer(self) -> Any:
        """Get the OpenTelemetry Tracer for creating custom spans.

        Returns:
            Tracer instance for distributed tracing
        """
        return self._tracer

    @property
    def thresholds(self) -> Dict[str, float]:
        """Get current thresholds from registry.

        Returns:
            Dictionary of threshold values from registry (refreshed by background thread)
        """
        # Get latest thresholds from registry client's cache (updated by refresh thread)
        if self._registry_client and self._registry_config:
            try:
                # fetch_model_config returns from cache if fresh (updated by refresh thread)
                current_config = self._registry_client.fetch_model_config(
                    model_id=self._registry_config.model_id,
                    version=self._registry_config.model_version,
                )
                return current_config.thresholds.copy()
            except Exception:
                # Fallback to initial config if fetch fails
                return self._registry_config.thresholds.copy()

        # No registry configured
        return {}

    @property
    def service_name(self) -> Optional[str]:
        """Get the configured service name.

        Returns:
            Service name string from config
        """
        return self.config.service_name

    @property
    def prometheus_endpoint(self) -> Optional[str]:
        """Get Prometheus metrics endpoint URL if enabled.

        Returns:
            URL string if Prometheus exporter is running, None otherwise
        """
        if self._prometheus_reader and self.config.prometheus_enabled:
            return f"http://{self.config.prometheus_host}:{self.config.prometheus_port}/metrics"
        return None

    def buffer_stats(self) -> Optional[Dict[str, Any]]:
        """Get telemetry buffer statistics aggregated from all exporters.

        Returns:
            Dictionary with aggregated buffer statistics from all three exporters
            (metrics, logs, spans), including total queue sizes and export metrics.
            Returns None if buffering is not enabled.
        """
        if not self.config.buffering_enabled:
            return None

        # Aggregate stats from all three buffered exporters
        max_size = getattr(self.config, "max_queue_size", 1000)
        queue_size = self._telemetry_queue.size() if self._telemetry_queue else 0
        stats: Dict[str, Any] = {
            "enabled": True,
            "size": queue_size,
            "is_full": queue_size >= max_size,
            "max_size": max_size,
            "per_signal_stats": {},
            "total_queued_items": 0,
            "total_export_attempts": 0,
            "total_export_successes": 0,
            "total_export_failures": 0,
        }

        # Get stats from metrics exporter
        if self._metric_exporter:
            metric_stats = self._metric_exporter.get_stats()
            stats["per_signal_stats"]["metrics"] = metric_stats
            stats["total_queued_items"] += metric_stats.get("items_queued", 0)
            stats["total_export_attempts"] += metric_stats.get("export_attempts", 0)
            stats["total_export_successes"] += metric_stats.get("export_successes", 0)
            stats["total_export_failures"] += metric_stats.get("export_failures", 0)

        # Get stats from log exporter
        if self._log_exporter:
            log_stats = self._log_exporter.get_stats()
            stats["per_signal_stats"]["logs"] = log_stats
            stats["total_queued_items"] += log_stats.get("items_queued", 0)
            stats["total_export_attempts"] += log_stats.get("export_attempts", 0)
            stats["total_export_successes"] += log_stats.get("export_successes", 0)
            stats["total_export_failures"] += log_stats.get("export_failures", 0)

        # Get stats from span exporter
        if self._span_exporter:
            span_stats = self._span_exporter.get_stats()
            stats["per_signal_stats"]["spans"] = span_stats
            stats["total_queued_items"] += span_stats.get("items_queued", 0)
            stats["total_export_attempts"] += span_stats.get("export_attempts", 0)
            stats["total_export_successes"] += span_stats.get("export_successes", 0)
            stats["total_export_failures"] += span_stats.get("export_failures", 0)

        # Get circuit breaker stats (Story 3-3)
        if self._circuit_breaker_retry_policy and hasattr(
            self._circuit_breaker_retry_policy, "get_stats"
        ):
            stats["circuit_breaker"] = self._circuit_breaker_retry_policy.get_stats()
        else:
            stats["circuit_breaker"] = None

        # Get GCP Cloud Trace exporter stats if enabled (Story 6-3 fix)
        if self._gcp_trace_exporter and hasattr(self._gcp_trace_exporter, "get_metrics"):
            gcp_stats = self._gcp_trace_exporter.get_metrics()
            stats["per_signal_stats"]["gcp_trace"] = gcp_stats
            # Add GCP-specific metrics to totals
            stats["total_export_attempts"] += gcp_stats.get("export_attempts_total", 0)
            # GCP exporter doesn't have explicit success counter, infer from spans_exported
            stats["total_export_failures"] += gcp_stats.get("export_failures_total", 0)

        # Add cleanup thread health monitoring (Finding 9)
        stats["cleanup_thread_alive"] = (
            self._cleanup_thread.is_alive() if self._cleanup_thread else False
        )

        return stats

    def _hydrate_from_registry(self) -> None:
        """Fetch config from registry and merge with local config."""
        try:
            self._registry_client = RegistryClient(
                url=self.config.registry_url,  # type: ignore[arg-type]
                token=self.config.registry_token,
                timeout=5.0,
                cache_ttl_secs=600,  # 10 minutes cache TTL
                refresh_interval_secs=self.config.refresh_interval_secs,
                use_gcp_auth=self.config.use_gcp_auth,
                tls_insecure_registry=self.config.tls_insecure_registry,
                token_audience=self.config.gcp_token_audience,
                max_stale_secs=getattr(self.config, "registry_max_stale_secs", 0),
            )

            # Fetch model or deployment config
            if self.config.deployment_id:
                # Deployment indirection: fetch deployment config first
                deployment_config = self._registry_client.fetch_deployment_config(
                    self.config.deployment_id
                )
                # Apply deployment resource overrides
                if deployment_config.resource_overrides:
                    logging.info(f"Applied deployment config for {self.config.deployment_id}")

            # Fetch model config
            # Note: model_id is guaranteed to exist by _validate_registry_requirements()
            registry_config = self._registry_client.fetch_model_config(
                model_id=self.config.model_id,  # type: ignore[arg-type]
                version=self.config.model_version,
            )
            self._registry_config = registry_config

            # Apply registry config based on prefer_registry setting
            if self.config.prefer_registry:
                self._apply_registry_config(registry_config)

            # Store thresholds
            self._thresholds = registry_config.thresholds

            logging.info(
                f"Successfully hydrated config from registry for model {registry_config.model_id}"
            )

        except RegistryAuthError as e:
            # Gracefully fall back to local config on auth failures
            # This allows the application to start even when GCP credentials are missing
            # or when the registry returns 401 Unauthorized
            if self.config.debug_mode:
                self._sdk_logger.debug(
                    f"Registry authentication failed, falling back to local config: {e}"
                )
            logging.warning(
                f"Registry authentication failed: {e}. "
                "Using local configuration. Telemetry will continue with local settings."
            )
        except RegistryConnectionError as e:
            # Log warning but continue with local config
            if self.config.debug_mode:
                self._sdk_logger.debug(
                    f"Registry connection failed, falling back to local config: {e}"
                )
            logging.warning(
                f"Registry unavailable, using local config: {e}. "
                "Telemetry will continue with local configuration."
            )
        except Exception as e:
            # Unexpected errors - log and continue
            if self.config.debug_mode:
                self._sdk_logger.debug(f"Unexpected registry error: {type(e).__name__}: {e}")
            logging.warning(f"Unexpected error during registry hydration: {e}")

    def _apply_registry_config(self, registry_config: ModelConfig) -> None:
        """Apply registry config to local config (mutable fields only).

        Args:
            registry_config: Configuration from registry
        """
        # Only override if local value is default/None and registry has a value
        if not self.config.team_name and registry_config.team_name:
            self.config.team_name = registry_config.team_name

        # Check for identity field changes (warn only)
        if registry_config.service_name != self.config.service_name:
            logging.warning(
                f"service_name in registry ({registry_config.service_name}) differs "
                f"from local ({self.config.service_name}). Using local value. "
                "Restart required to apply registry service_name."
            )

    def _convert_thresholds_to_attributes(
        self, thresholds: Dict[str, Union[int, float]]
    ) -> Dict[str, Union[int, float]]:
        """Convert threshold values to numeric resource attributes.

        OpenTelemetry Resource attributes support native int/float types.
        This method preserves numeric types (int stays int, float stays float)
        enabling downstream systems to perform numeric queries and aggregations.

        NOTE: OpenTelemetry Resources are IMMUTABLE after initialization.
        Thresholds are evaluated ONCE during SDK startup. If the Registry API
        updates thresholds later, they will NOT be reflected until SDK restart.

        Safeguards:
        - Rejects booleans (bool is subclass of int in Python)
        - Rejects None, NaN, and Infinity
        - Enforces max 50 thresholds to prevent payload bloat
        - Sanitizes keys with collision detection
        - Accounts for "threshold." prefix in key length limit

        Args:
            thresholds: Dictionary of threshold names to numeric values

        Returns:
            Dictionary of resource attributes with sanitized "threshold." prefix

        Raises:
            None - Invalid entries are logged and skipped gracefully
        """
        MAX_THRESHOLDS = 50  # Prevent payload bloat
        PREFIX = "threshold."
        # OTel key limit is 63 chars, but we add 10-char prefix, so max name is 53
        MAX_NAME_LENGTH = 63 - len(PREFIX)

        threshold_attrs: Dict[str, Union[int, float]] = {}
        seen_sanitized_keys: Dict[str, str] = {}  # Track collisions: sanitized_key -> original_key

        if not thresholds:
            return threshold_attrs

        for index, (name, value) in enumerate(thresholds.items()):
            # 1. Enforce dictionary size limit (deterministic: first 50 win)
            if index >= MAX_THRESHOLDS:
                dropped_count = len(thresholds) - MAX_THRESHOLDS
                self._sdk_logger.warning(
                    f"Exceeded maximum of {MAX_THRESHOLDS} thresholds. "
                    f"Dropping {dropped_count} thresholds. "
                    "Dictionary iteration order determines which thresholds are kept. "
                    "Consider using fewer thresholds or prioritizing critical ones in Registry."
                )
                break

            # 2. Explicit boolean rejection (bool is subclass of int!)
            if isinstance(value, bool):
                self._sdk_logger.warning(
                    f"Threshold '{name}' is boolean ({value}). Booleans are not valid "
                    "numeric thresholds. Skipping to prevent coercion to 1.0/0.0."
                )
                continue

            # 3. Validate value type and reject None
            if value is None:
                self._sdk_logger.warning(
                    f"Threshold '{name}' has None value. Skipping to prevent "
                    "pollution with string 'None' in telemetry."
                )
                continue

            if not isinstance(value, (int, float)):
                self._sdk_logger.warning(
                    f"Threshold '{name}' has non-numeric value (type={type(value).__name__}). "
                    "Skipping. Expected int or float."
                )
                continue

            # 4. Check for NaN and Infinity (both cause serialization failures)
            if isinstance(value, float):
                if math.isnan(value):
                    self._sdk_logger.warning(
                        f"Threshold '{name}' is NaN. Skipping to prevent invalid telemetry data."
                    )
                    continue

                if math.isinf(value):
                    self._sdk_logger.warning(
                        f"Threshold '{name}' is Infinity. Skipping to prevent "
                        "OpenTelemetry exporter serialization crash."
                    )
                    continue

            # 5. Sanitize key name (remove invalid OTel characters)
            # Valid characters: [a-zA-Z0-9_.-]
            # Slice BEFORE adding prefix to respect total 63-char limit
            safe_name = re.sub(r"[^a-zA-Z0-9_.-]", "_", str(name))[:MAX_NAME_LENGTH]
            attr_name = f"{PREFIX}{safe_name}"

            # 6. Detect sanitization collisions
            if attr_name in seen_sanitized_keys:
                original_colliding = seen_sanitized_keys[attr_name]
                self._sdk_logger.warning(
                    f"Key sanitization collision: '{name}' and '{original_colliding}' "
                    f"both sanitize to '{attr_name}'. Second value will overwrite first. "
                    "Consider renaming thresholds in Registry to avoid special characters."
                )

            seen_sanitized_keys[attr_name] = name

            # 7. Preserve native numeric type (int stays int, float stays float)
            # Do NOT force int to float - OTel supports both natively
            threshold_attrs[attr_name] = value

        if self.config.debug_mode and threshold_attrs:
            self._sdk_logger.debug(
                f"Converted {len(threshold_attrs)} thresholds to resource attributes "
                f"(max: {MAX_THRESHOLDS}, {len(seen_sanitized_keys) - len(threshold_attrs)} collisions)"
            )

        return threshold_attrs

    def _filter_reserved_attributes(
        self, attributes: Dict[str, Any], context: str = "metric"
    ) -> Dict[str, Any]:
        """Filter out resource attribute keys from metric attributes to prevent duplicate labels.

        When OTel Collector's Prometheus exporter has resource_to_telemetry_conversion enabled,
        resource attributes become constant labels. If the same key is passed as a metric
        attribute, Prometheus rejects it with "duplicate label names in constant and variable labels".

        This method dynamically extracts the ACTUAL resource attribute keys from the configured
        OpenTelemetry Resource and filters them from metric attributes. This ensures protection
        against duplicates from registry extra_resource, collector-injected attributes, and
        any other dynamic resource attributes.

        Args:
            attributes: Dictionary of metric attributes to filter
            context: Context for logging (e.g., "record_prediction", "record_counter")

        Returns:
            Filtered dictionary with reserved keys removed
        """
        # Build reserved keys set from actual resource attributes
        reserved_keys = set()

        # Extract actual resource attribute keys if resource is available
        if hasattr(self, "_resource") and self._resource is not None:
            resource_attrs = self._resource.attributes
            if resource_attrs:
                try:
                    for key in resource_attrs.keys():
                        # Add both dotted and underscored versions (Prometheus normalization)
                        reserved_keys.add(str(key))
                        reserved_keys.add(str(key).replace(".", "_"))
                except TypeError:
                    pass

        # Always filter high-cardinality identifiers regardless of resource attributes
        # (defensive filtering to prevent accidental cardinality explosion)
        reserved_keys.update({"prediction_id", "association_id", "user_id", "session_id"})

        # Filter and log removed keys for debugging
        removed_keys = [k for k in attributes.keys() if k in reserved_keys]
        if removed_keys:
            if self._debug_mode:
                self._sdk_logger.debug(
                    f"[{context}] Filtered {len(removed_keys)} reserved resource attribute(s) "
                    f"from metric attributes to prevent duplicate labels: {removed_keys}"
                )

        return {k: v for k, v in attributes.items() if k not in reserved_keys}

    def record_prediction(
        self,
        input_data: Any = None,
        output: Any = None,
        latency: Optional[float] = None,
        prediction_id: Optional[str] = None,
        strict_validation: Optional[bool] = None,
        span_attributes: Optional[Dict[str, Any]] = None,
        *,
        association_id: Optional[str] = None,
        **attributes: Any,
    ) -> None:
        """Record a model prediction with standard metrics.

        This is a convenience method that automatically creates:
        - model.predictions_total counter (incremented with status="success")
        - model.latency_seconds histogram (if latency provided, with status="success")
        - Structured log with prediction details

        Args:
            input_data: Input data for the prediction.
            output: Output from the model.
            latency: Prediction latency in seconds.
            prediction_id: Optional prediction ID for trace correlation
                (auto-generated if ``None``).
            strict_validation: Optional override for strict validation mode.
            span_attributes: Optional dictionary of attributes to append
                directly to the active span (not metrics).
            **attributes: Additional low-cardinality attributes to attach
                to metrics/logs.

        Returns:
            None. Telemetry is dispatched asynchronously through the
            configured exporters.

        Raises:
            ValidationError: In strict validation mode, when ``latency`` is
                negative, attribute keys/values violate OTel constraints, or
                reserved resource attribute keys are passed through
                ``**attributes``. In relaxed mode these are logged as warnings
                and the record is still emitted on a best-effort basis.

        Note:
            All prediction metrics include a 'status' label:
            - status="success" for successful predictions (record_prediction)
            - status="error" for failed predictions (record_error)

            Metric attributes are automatically filtered to remove any keys that match
            resource attributes (e.g., service.name, model.id, environment, etc.) to
            prevent "duplicate label names" errors in the Prometheus exporter when
            resource_to_telemetry_conversion is enabled.

        Example:
            >>> client.record_prediction(
            ...     input_data={"features": [1, 2, 3]},
            ...     output={"label": "positive", "score": 0.92},
            ...     latency=0.15,
            ...     model_version="1.2.0",
            ... )
        """
        # DEFENSIVE: Filter out reserved resource attribute keys to prevent duplicate labels
        attributes = self._filter_reserved_attributes(attributes, context="record_prediction")

        # FIXED (Round 11 Issue #1): Removed dead imports (sys, ValidationError)
        # These imports are unused and add unnecessary overhead

        # FIXED (Round 11 Issue #3): Accept external prediction_id for trace correlation
        if prediction_id is None:
            prediction_id = str(uuid.uuid4())

        # Apply application-specific PHI sanitization hook FIRST
        # This allows applications to inject domain-specific PHI masking
        if self._data_sanitizer_hook and callable(self._data_sanitizer_hook):
            if input_data is not None and isinstance(input_data, dict):
                try:
                    input_data = self._data_sanitizer_hook(input_data)
                except Exception as e:
                    self._sdk_logger.warning(
                        f"[{prediction_id}] data_sanitizer_hook failed on input_data: {e}"
                    )

            if output is not None and isinstance(output, dict):
                try:
                    output = self._data_sanitizer_hook(output)
                except Exception as e:
                    self._sdk_logger.warning(
                        f"[{prediction_id}] data_sanitizer_hook failed on output: {e}"
                    )

        # CRITICAL SECURITY FIX: Sanitize credentials in input_data and output
        if input_data is not None:
            try:
                input_data = _sanitize_data_recursive(input_data)
            except Exception as e:
                self._sdk_logger.warning(f"[{prediction_id}] Failed to sanitize input_data: {e}")

        if output is not None:
            try:
                output = _sanitize_data_recursive(output)
            except Exception as e:
                self._sdk_logger.warning(f"[{prediction_id}] Failed to sanitize output: {e}")

        # FIXED (Round 7/8): Use built-in validator with proper strict mode handling
        # CRITICAL: Assign return value - validator sanitizes in permissive mode
        if attributes:
            _effective_strict = (
                self._strict_validation if strict_validation is None else strict_validation
            )
            attributes = TelemetryAttributeValidator.validate(
                attributes,
                strict=bool(_effective_strict),
                max_value_length=self._max_attr_length,
                max_attribute_count=self._max_attr_count,
            )

        if self._debug_mode:
            self._sdk_logger.debug(
                f"[{prediction_id}] Recording prediction - latency={latency}, attributes={attributes}"
            )

            # Log attribute validation
            attr_count = len(attributes)
            attr_keys = list(attributes.keys())
            self._sdk_logger.debug(
                f"[{prediction_id}] Attribute validation: {attr_count} attributes provided: {attr_keys}"
            )

            # FIXED (Round 11 Issue #9): Removed dead validation loop
            # TelemetryAttributeValidator already truncated strings, this check was always false

        # Add status="success" label for consistency with error recording
        prediction_attributes = {**attributes, "status": "success"}

        # Increment predictions counter
        self._predictions_counter.add(1, attributes=prediction_attributes)

        if self._debug_mode:
            self._sdk_logger.debug(
                f"[{prediction_id}] Metric recorded: model.predictions_total += 1"
            )
            self._sdk_logger.debug(
                f"[{prediction_id}] Export attempt: Metrics will be exported to {self._collector_endpoint}"
            )

        # Record latency if provided
        if latency is not None:
            self._latency_histogram.record(latency, attributes=prediction_attributes)
            if self._debug_mode:
                self._sdk_logger.debug(
                    f"[{prediction_id}] Metric recorded: model.latency_seconds = {latency}s"
                )

        # Log prediction completion for production auditability
        # Always include prediction_id for trace correlation
        # Build log extra fields with input_data and output if provided
        # FIXED (Round 11 Issue #8): Strip system keys from user attributes to prevent spoofing
        safe_attributes = {
            k: v
            for k, v in attributes.items()
            if k
            not in (
                "prediction_id",
                "association_id",
                "latency",
                "input_data",
                "output",
            )
        }
        log_extra = {
            **safe_attributes,
            "prediction_id": prediction_id,
            "latency": latency,
        }
        if association_id is not None:
            log_extra["association_id"] = association_id

        # Story 1.18: Attach input_data if capture enabled (for drift monitoring)
        # Story 8.5: Use unified extract_model_payload() for consistent schema
        # Issue #1 Fix: Import moved to module level to avoid hot-path overhead
        # Issue #2 Fix: Extract once and reuse for logs and spans
        extracted_input = None
        extracted_output = None

        if self._capture_input_data and input_data is not None:
            extracted_input = extract_model_payload(
                input_data, max_size_bytes=self._capture_max_size_bytes
            )
            log_extra["input_data"] = extracted_input["data"]
            if extracted_input["shape"]:
                log_extra["input_shape"] = extracted_input["shape"]
            log_extra["input_truncated"] = extracted_input["truncated"]

        # Story 1.18: Attach output if capture enabled (for drift monitoring)
        # Story 8.5: Use unified extract_model_payload() for consistent schema
        if self._capture_output_data and output is not None:
            extracted_output = extract_model_payload(
                output, max_size_bytes=self._capture_max_size_bytes
            )
            log_extra["output"] = extracted_output["data"]
            if extracted_output["shape"]:
                log_extra["output_shape"] = extracted_output["shape"]
            log_extra["output_truncated"] = extracted_output["truncated"]

        # HIPAA audit log: emit unconditionally at INFO. Applications must sanitize
        # sensitive data before passing it to SDK methods (see CLAUDE.md).
        # Operators silence this by raising the ambient logger level, not by code flag.
        # Story 6-42 adversarial-round-2: emit via fast path. This bypasses
        # stdlib Logger.info/makeRecord/callHandlers/QueueHandler.emit on the
        # calling thread (~140ms/1000 calls per diagnostic profile). The drain
        # thread constructs LogRecord and calls _otel_handler.emit off-thread.
        self._enqueue_audit_fast("Prediction completed", log_extra)

        # Story 1.18 Fix #6: Attach input/output to active OTel span (not just logs)
        # Story 8.5: Use unified schema with shapes for spans
        # Issue #2 Fix: Reuse extracted payloads instead of re-extracting
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            try:
                if association_id is not None:
                    current_span.set_attribute("ml.association.id", association_id)
                # Attach serialized input/output to span attributes with shapes
                if extracted_input is not None:
                    current_span.set_attribute("model.input.data", extracted_input["data"])
                    if extracted_input["shape"]:
                        current_span.set_attribute("model.input.shape", extracted_input["shape"])
                    current_span.set_attribute(
                        "model.input.truncated", extracted_input["truncated"]
                    )

                if extracted_output is not None:
                    current_span.set_attribute("model.output.data", extracted_output["data"])
                    if extracted_output["shape"]:
                        current_span.set_attribute("model.output.shape", extracted_output["shape"])
                    current_span.set_attribute(
                        "model.output.truncated", extracted_output["truncated"]
                    )

                if span_attributes is not None:
                    for k, v in span_attributes.items():
                        current_span.set_attribute(k, v)

            except Exception as e:
                # Don't crash on span attribute errors
                self._sdk_logger.warning(f"Failed to attach input/output to span: {e}")

        if self._debug_mode:
            # Log export information
            metric_count = 2 if latency is not None else 1
            self._sdk_logger.debug(
                f"[{prediction_id}] Export queued: {metric_count} metrics + 1 log to {self._collector_endpoint}/v1/metrics, /v1/logs"
            )
            self._sdk_logger.debug(
                f"[{prediction_id}] Prediction recording completed - metrics will be exported via batch processor (interval: {self._metric_export_interval_ms}ms)"
            )

    def record_evaluation(
        self,
        mae: Optional[float] = None,
        rmse: Optional[float] = None,
        dataset: str = "validation",
        **attributes: Any,
    ) -> None:
        """Record model evaluation metrics (MAE, RMSE).

        Args:
            mae: Mean Absolute Error value. Skipped if ``None``.
            rmse: Root Mean Squared Error value. Skipped if ``None``.
            dataset: Dataset evaluated on (default: ``"validation"``).
            **attributes: Additional low-cardinality attributes to attach
                to the emitted histograms.

        Returns:
            None.

        Raises:
            ValidationError: In strict validation mode, when attributes fail
                OTel validation (reserved keys, oversize values, or too many
                keys). Relaxed mode logs a warning and falls back to
                ``{"dataset": dataset}``.

        Example:
            >>> client.record_evaluation(
            ...     mae=0.08,
            ...     rmse=0.11,
            ...     dataset="holdout-q1",
            ...     model_version="1.2.0",
            ... )
        """
        eval_attributes: Dict[str, Any] = {"dataset": dataset}
        if attributes:
            eval_attributes.update(attributes)

        safe_attributes: Dict[str, Any] = eval_attributes
        if getattr(self, "_strict_validation", True):
            try:
                from ..validation.telemetry_attributes import (
                    TelemetryAttributeValidator,
                )

                safe_attributes = TelemetryAttributeValidator.validate(
                    eval_attributes,
                    strict=bool(self._strict_validation),
                    max_value_length=self._max_attr_length,
                    max_attribute_count=self._max_attr_count,
                )
            except Exception as e:
                if self._strict_validation:
                    raise
                self._sdk_logger.warning(f"Attribute validation failed for evaluation metrics: {e}")
                safe_attributes = {"dataset": dataset}  # fallback

        if mae is not None:
            self._mae_histogram.record(mae, attributes=safe_attributes)
            if self._debug_mode:
                self._sdk_logger.debug(
                    f"Metric recorded: {self._metric_prefix}.mae = {mae} on {dataset}"
                )

        if rmse is not None:
            self._rmse_histogram.record(rmse, attributes=safe_attributes)
            if self._debug_mode:
                self._sdk_logger.debug(
                    f"Metric recorded: {self._metric_prefix}.rmse = {rmse} on {dataset}"
                )

    def record_error(
        self,
        error: Exception,
        latency: Optional[float] = None,
        prediction_id: Optional[str] = None,
        span_attributes: Optional[Dict[str, Any]] = None,
        *,
        association_id: Optional[str] = None,
        **attributes: Any,
    ) -> str:
        """Record a prediction error with dual metrics.

        Records to both:
        - predictions_total{status="error"} for consistency
        - errors_total for dedicated error tracking

        Args:
            error: The exception that occurred
            latency: Optional prediction latency in seconds
            prediction_id: Optional prediction ID for trace correlation (auto-generated if None)
            span_attributes: Optional dictionary of attributes to append directly to the active span
            **attributes: Additional attributes (e.g., function)

        Returns:
            Sanitized error message (for reuse in span attributes, avoiding redundant sanitization)

        Raises:
            ValidationError: If attributes fail validation in strict mode

        Note:
            Metric attributes are automatically filtered to remove any keys that match
            resource attributes to prevent duplicate label errors in Prometheus export.

        Example:
            >>> try:
            ...     result = model.predict(data)
            ... except Exception as e:
            ...     client.record_error(e, latency=0.5, function="predict")
            ...     raise
        """
        # DEFENSIVE: Filter out reserved resource attribute keys to prevent duplicate labels
        attributes = self._filter_reserved_attributes(attributes, context="record_error")

        # FIXED (Round 14 Issue #2): Stop using id() - memory addresses get reused after GC
        # Use attribute tagging instead, with safe handling for read-only exceptions
        if getattr(error, "_mca_recorded", False):
            return _sanitize_error_message(str(error))  # Already recorded

        try:
            # Mark error as recorded to prevent duplicates
            setattr(error, "_mca_recorded", True)
        except Exception:
            # Read-only exception (e.g., built-in exceptions) - accept risk of duplicate
            # This is safer than memory leak from id() reuse
            pass

        # FIXED (Issue #9): Truncate exception class name to prevent unbounded labels
        error_type = type(error).__name__[:64]

        # FIXED (Issue #8): Sanitize once and return for reuse
        error_message = _sanitize_error_message(str(error))

        # FIXED (Round 11 Issue #3): Accept external prediction_id for correlation
        if prediction_id is None:
            prediction_id = attributes.get("prediction_id")
        if not prediction_id:
            prediction_id = str(uuid.uuid4())

        # FIXED (Round 14 Issue #9): Don't let safe_limit fall to 0
        # If _max_attr_count is tiny (e.g., 1), setting safe_limit to 0 drops ALL user attrs
        # Just use the global limit - system attributes will naturally overwrite if needed
        safe_limit = self._max_attr_count

        # Validate and sanitize user attributes
        safe_user_attributes = {}
        if attributes:
            # CRITICAL: Assign return value - validator sanitizes in permissive mode
            safe_user_attributes = TelemetryAttributeValidator.validate(
                attributes,
                strict=bool(self._strict_validation),  # Let validator handle strict vs permissive
                max_value_length=self._max_attr_length,
                max_attribute_count=safe_limit,
            )

        # FIXED (Re-Review Issue #1): System attributes LAST to prevent user spoofing
        # User cannot override status="error" or error_type
        error_attributes = {
            **safe_user_attributes,  # User attributes first
            "status": "error",  # System attribute - cannot be overridden
            "error_type": error_type,  # System attribute - cannot be overridden
        }

        # Dual recording: predictions_total AND errors_total
        self._predictions_counter.add(1, attributes=error_attributes)
        self._errors_counter.add(1, attributes=error_attributes)

        # Record latency if provided
        if latency is not None:
            self._latency_histogram.record(latency, attributes=error_attributes)

        log_extra = {
            **safe_user_attributes,  # MUST be validated attributes!
            # System keys last to overwrite any conflicts
            "prediction_id": prediction_id,
            "error_type": error_type,
            "error_message": error_message,
            "latency": latency,
        }
        if association_id is not None:
            log_extra["association_id"] = association_id

        # Story 6-31 round-2 (finding #5): record_error takes the standard
        # logger.error() path, not _enqueue_audit_fast. error_message is
        # sanitized for credentials but not PHI; prediction_id / association_id
        # are caller-supplied. Redact the full log_extra dict here so PHI
        # buried in the error message or any string-valued user attribute is
        # scrubbed before it reaches the logging pipeline.
        # Story 6-32: apply secret filter alongside PHI so credential material
        # in user attributes (e.g. api_token=...) is masked on the error path
        # as well as the success path.
        if not _secret_disabled():
            log_extra = _secret_filter_attributes(log_extra)
        if _phi_enabled():
            log_extra = _phi_filter_attributes(log_extra)

        # FIXED (Round 7 Issue #1): Use validated safe_user_attributes, not raw attributes
        # This prevents logging bypass that crashes the logging pipeline
        self._logger.error(
            f"Prediction error: {error_type}",
            extra=log_extra,
        )

        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            current_span.record_exception(error)
            from opentelemetry.trace.status import Status, StatusCode

            current_span.set_status(Status(StatusCode.ERROR, str(error)))
            if prediction_id:
                current_span.set_attribute("ml.prediction.id", prediction_id)
            if association_id is not None:
                current_span.set_attribute("ml.association.id", association_id)
            if span_attributes is not None:
                for k, v in span_attributes.items():
                    current_span.set_attribute(k, v)

        # Return sanitized message for reuse (Issue #8)
        return error_message

    def _handle_prediction_success(
        self,
        span: trace.Span,
        input_data: Optional[Dict[str, Any]],
        output_data: Any,
        latency: float,
        prediction_id: str,
        metric_attributes: Dict[str, Any],
        association_id: Optional[str] = None,
    ) -> None:
        """Handle successful prediction - record metrics and set span attributes.

        Args:
            span: Active trace span
            input_data: Serialized input data
            output_data: Serialized output data
            latency: Prediction latency in seconds
            prediction_id: Unique prediction identifier
            metric_attributes: Additional metric attributes
        """
        self.record_prediction(
            input_data=input_data,
            output=output_data,
            latency=latency,
            prediction_id=prediction_id,
            association_id=association_id,
            **metric_attributes,
        )
        span.set_attribute("prediction.id", prediction_id)
        span.set_attribute("prediction.latency_ms", latency * 1000)

    def _handle_prediction_error(
        self,
        span: trace.Span,
        error: Exception,
        latency: float,
        prediction_id: str,
        metric_attributes: Dict[str, Any],
        association_id: Optional[str] = None,
    ) -> None:
        """Handle prediction error - record error metrics, set span attributes.

        Args:
            span: Active trace span
            error: Exception that occurred
            latency: Prediction latency in seconds
            prediction_id: Unique prediction identifier
            metric_attributes: Additional metric attributes
        """
        # FIXED (Issue #8): record_error() now returns sanitized message to avoid double sanitization
        error_message = self.record_error(
            error,
            latency=latency,
            prediction_id=prediction_id,
            association_id=association_id,
            **metric_attributes,
        )

        # Set span error attributes (reuse sanitized message from record_error)
        error_type = type(error).__name__[:64]  # Consistent with record_error truncation
        span.set_attribute("error", True)
        span.set_attribute("error.type", error_type)
        span.set_attribute("error.message", error_message)
        span.set_attribute("prediction.id", prediction_id)
        span.set_attribute("prediction.latency_ms", latency * 1000)

        # Logging now handled by record_error(), don't duplicate

    def _setup_prediction_context(self) -> tuple[str, Any]:
        """Setup prediction context with ID and token.

        Returns:
            Tuple of (prediction_id, context_token)
        """
        prediction_id = str(uuid.uuid4())
        token = _prediction_context.set(prediction_id)
        return prediction_id, token

    def _start_prediction_timer(self) -> float:
        """Start prediction timing.

        Returns:
            Start time for latency calculation
        """
        return time.perf_counter()

    def _capture_prediction_data(
        self,
        capture_input: bool,
        capture_output: bool,
        args: tuple[Any, ...],
        kwargs: Dict[str, Any],
        result: Any,
    ) -> tuple[Any, Any]:
        """Capture and serialize input/output data for telemetry.

        Story 8.5: Smart unwrapping for single-argument functions to match autolog schema.
        Instead of wrapping in {"args": [...], "kwargs": {}}, pass raw data to record_prediction()
        which will handle serialization via extract_model_payload().

        Args:
            capture_input: Whether to capture inputs
            capture_output: Whether to capture outputs
            args: Function positional arguments
            kwargs: Function keyword arguments
            result: Function return value

        Returns:
            Tuple of (input_data, output_data) with raw data (not pre-serialized)
        """
        input_data = None
        output_data = None

        # Story 8.5: Smart unwrapping for unified schema
        if capture_input and (args or kwargs):
            # If single positional arg with no kwargs, pass directly (matches autolog behavior)
            if len(args) == 1 and not kwargs:
                input_data = args[0]
            else:
                # Multiple args or kwargs: wrap in dict
                input_data = {"args": args, "kwargs": kwargs}

        # Story 8.5: Pass raw result (not serialized) to record_prediction()
        if capture_output:
            output_data = result

        return input_data, output_data

    def predict(
        self,
        capture_input: bool = False,
        capture_output: bool = False,
        span_name: Optional[str] = None,
        **metric_attributes: Any,
    ) -> Callable[..., Any]:
        """Decorator for auto-instrumentation of prediction functions.

        Automatically tracks latency, generates prediction_id, and records metrics.
        Supports both sync and async functions with thread-safe operation.

        Args:
            capture_input: Whether to capture function inputs (default: False)
            capture_output: Whether to capture function output (default: False)
            span_name: Custom span name (default: function.__name__)
            **metric_attributes: Additional metric attributes to include

        Returns:
            Decorator function that wraps the prediction function

        Examples:
            Basic usage (no data capture):
            >>> @client.predict()
            ... def predict(data):
            ...     return model.predict(data)

            Explicit data capture (requires PHI sanitization):
            >>> @client.predict(capture_input=True, capture_output=True)
            ... async def predict_async(data):
            ...     # WARNING: Ensure data is sanitized before calling this function
            ...     return await model.predict_async(data)

            Custom span name and attributes:
            >>> @client.predict(span_name="readmission_v2", model_version="2.0")
            ... def predict(data):
            ...     return model.predict(data)

        Warning:
            HIPAA COMPLIANCE: Data capture is DISABLED by default to prevent
            accidental PHI exposure. If you enable capture_input=True or
            capture_output=True, you MUST ensure ALL data passed to the
            decorated function has been sanitized to remove PHI (patient names,
            SSNs, addresses, etc.). The SDK provides NO automatic PHI masking
            for captured data. Failure to sanitize may result in HIPAA violations.
        """

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            name = span_name or func.__name__

            # Detect if function is async or sync
            if inspect.iscoroutinefunction(func):
                # Async wrapper
                @functools.wraps(func)
                async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                    prediction_id, token = self._setup_prediction_context()
                    start_time = self._start_prediction_timer()

                    with self.trace(name) as span:
                        try:
                            # Extract association_id from kwargs if present, but do NOT remove it.
                            # The user's function might actually need this parameter.
                            # If they pass it positionally, it won't be captured here (known limitation of simple decorators).
                            association_id = kwargs.get("association_id", None)
                            result = await func(*args, **kwargs)
                            latency = time.perf_counter() - start_time
                            input_data, output_data = self._capture_prediction_data(
                                capture_input, capture_output, args, kwargs, result
                            )
                            self._handle_prediction_success(
                                span,
                                input_data,
                                output_data,
                                latency,
                                prediction_id,
                                metric_attributes,
                                association_id=association_id,
                            )
                            return result
                        except Exception as e:
                            latency = time.perf_counter() - start_time
                            self._handle_prediction_error(
                                span,
                                e,
                                latency,
                                prediction_id,
                                metric_attributes,
                                association_id=association_id,
                            )
                            raise
                        finally:
                            _prediction_context.reset(token)

                return async_wrapper
            else:
                # Sync wrapper
                @functools.wraps(func)
                def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                    prediction_id, token = self._setup_prediction_context()
                    start_time = self._start_prediction_timer()

                    with self.trace(name) as span:
                        try:
                            # Extract association_id from kwargs if present, but do NOT remove it.
                            # The user's function might actually need this parameter.
                            # If they pass it positionally, it won't be captured here (known limitation of simple decorators).
                            association_id = kwargs.get("association_id", None)
                            result = func(*args, **kwargs)
                            latency = time.perf_counter() - start_time
                            input_data, output_data = self._capture_prediction_data(
                                capture_input, capture_output, args, kwargs, result
                            )
                            self._handle_prediction_success(
                                span,
                                input_data,
                                output_data,
                                latency,
                                prediction_id,
                                metric_attributes,
                                association_id=association_id,
                            )
                            return result
                        except Exception as e:
                            latency = time.perf_counter() - start_time
                            self._handle_prediction_error(
                                span,
                                e,
                                latency,
                                prediction_id,
                                metric_attributes,
                                association_id=association_id,
                            )
                            raise
                        finally:
                            _prediction_context.reset(token)

                return sync_wrapper

        return decorator

    def record_metric(
        self,
        name: Optional[str] = None,
        value: Optional[float] = None,
        strict_validation: Optional[bool] = None,
        **attributes: Any,
    ) -> None:
        """Record a custom metric value with explicit instrument type.

        This is a generic method for recording any metric. For common patterns
        like predictions and latency, use record_prediction() instead.

        IMPORTANT: This method is for one-time metric recording. For counters,
        histograms, or gauges that are updated frequently, use client.meter
        to create the metric once and reuse it for better performance.

        Args:
            name: Metric name (will be validated for safe characters)
            value: Metric value
            strict_validation: Override strict validation for this call (default: use client config)
            instrument_type: Type of OpenTelemetry instrument ("histogram", "counter", "up_down_counter")
            **attributes: Attributes to attach to the metric

        Example:
            >>> # Histogram (default):
            >>> client.record_metric("model.accuracy_ratio", 0.92, dataset="test")
            >>>
            >>> # Counter (explicit):
            >>> client.record_metric("api.requests_total", 1, instrument_type="counter", endpoint="/predict")
            >>>
            >>> # For high-throughput scenarios, create instrument once:
            >>> requests_counter = client.meter.create_counter("api.requests_total")
            >>> requests_counter.add(1, {"endpoint": "/predict"})
        """
        from ..utils.exceptions import ValidationError as _ValidationError

        # FIXED: Extract instrument_type securely from attributes to prevent wrapper mapping bugs
        instrument_type = attributes.pop("instrument_type", "histogram")

        # DEFENSIVE: Filter out reserved resource attribute keys to prevent duplicate labels
        attributes = self._filter_reserved_attributes(attributes, context="record_metric")

        # Support metric_name as alias for name (backward compatibility)
        if name is None:
            name = attributes.pop("metric_name", None)
        if name is None:
            raise TypeError("record_metric() missing required argument: 'name' or 'metric_name'")

        # Determine effective strict mode (kwarg overrides client config)
        effective_strict = (
            self._strict_validation if strict_validation is None else strict_validation
        )

        # Always validate metric name for invalid characters (prevents OTel SDK exceptions)
        if name:
            dangerous_chars = set(
                "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f"
                "\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f"
                "\"'\\/[]{}()<>;|&$`"
            )
            allowed_chars = set("._")
            for c in name:
                if not c.isalnum() and c not in allowed_chars:
                    if c in dangerous_chars or ord(c) < 32 or ord(c) > 126:
                        raise _ValidationError(
                            f"Invalid metric name: '{name}' - contains dangerous character: {repr(c)}"
                        )
                    else:
                        raise _ValidationError(
                            f"Invalid metric name: '{name}' - contains invalid character: {repr(c)}. "
                            "Only alphanumeric, dots, and underscores are allowed."
                        )

        if effective_strict:
            if not name:
                raise _ValidationError(f"Invalid metric name: '{name}' - cannot be empty or None")
            if len(name) > 256:
                raise _ValidationError(
                    f"Invalid metric name: '{name}' - exceeds maximum length of 256 characters "
                    f"(got {len(name)} characters)"
                )
            if name[0].isdigit():
                raise _ValidationError(
                    f"Invalid metric name: '{name}' - must start with a letter or underscore, not a digit"
                )

        # Validate metric structure (protobuf schema) via the existing validator
        metric_data = {"name": name, "value": value, "attributes": attributes}
        try:
            self._metric_validator._validate_metric_structure(metric_data)
        except Exception as e:
            if effective_strict:
                raise
            else:
                self._sdk_logger.warning(
                    f"Metric structure validation failed for '{name}': {e}. "
                    "Recording anyway (non-strict mode)."
                )

        # FIXED (Round 14 Issue #10): Protect attribute validation with try/except
        # Validation can raise in strict mode, must be caught like name validation
        if attributes:
            try:
                # CRITICAL: Assign return value - validator sanitizes in permissive mode
                attributes = TelemetryAttributeValidator.validate(
                    attributes,
                    strict=bool(effective_strict),
                    max_value_length=self._max_attr_length,
                    max_attribute_count=self._max_attr_count,
                )
            except Exception as e:
                if effective_strict:
                    raise  # Re-raise in strict mode
                else:
                    # Permissive mode: drop invalid attributes and continue
                    self._sdk_logger.warning(
                        f"Attribute validation failed for metric '{name}': {e}. "
                        "Dropping invalid attributes (non-strict mode)."
                    )
                    attributes = {}

        # FIXED (Round 14 Issue #6): Strip memory addresses from cardinality signature
        # Objects with __repr__ containing memory addresses cause unique signatures
        if attributes:
            # Normalize values to prevent memory address leaks
            clean_attrs = {
                k: str(v) if not isinstance(v, (int, float, bool, str)) else v
                for k, v in attributes.items()
            }
            attr_sig = str(sorted(clean_attrs.items()))
        else:
            attr_sig = ""

        # FIXED (Round 11 Issue #10): Use cached cardinality limit
        MAX_CARDINALITY = self._max_cardinality
        with self._metrics_lock:
            if name not in self._metric_cardinality:
                self._metric_cardinality[name] = set()

            if attr_sig not in self._metric_cardinality[name]:
                if len(self._metric_cardinality[name]) >= MAX_CARDINALITY:
                    self._sdk_logger.warning(
                        f"Cardinality limit ({MAX_CARDINALITY}) reached for metric '{name}'. "
                        "Using overflow label to prevent explosion."
                    )
                    # FIXED (Round 9 Issue #2): Preserve context with overflow label
                    attributes = {"mca.cardinality_overflow": True}
                    # FIXED (Round 12 Issue #5): DO NOT add overflow signature to set
                    # Just use overflow attributes and stop growing the set
                else:
                    # Only add to set if under the limit
                    self._metric_cardinality[name].add(attr_sig)

        # Validate instrument_type parameter
        valid_types = ("histogram", "counter", "up_down_counter")
        if instrument_type not in valid_types:
            self._sdk_logger.warning(
                f"Invalid instrument_type: '{instrument_type}'. "
                f"Falling back to 'histogram'. Must be one of: {', '.join(valid_types)}"
            )
            instrument_type = "histogram"

        # FIXED (Round 14 Issue #3): Ensure lock covers both check and creation
        # Multiple threads creating instruments causes leaks. Use single lock.
        with self._metrics_lock:
            instrument = self._cached_metrics.get(name)
            if not instrument:
                # Create instrument based on explicit type parameter
                if instrument_type == "counter":
                    instrument = self._meter.create_counter(
                        name, description=f"Custom counter metric: {name}"
                    )
                elif instrument_type == "up_down_counter":
                    instrument = self._meter.create_up_down_counter(
                        name, description=f"Custom up-down counter metric: {name}"
                    )
                else:  # histogram (default)
                    instrument = self._meter.create_histogram(
                        name, description=f"Custom histogram metric: {name}"
                    )
                self._cached_metrics[name] = instrument

        # Record outside the lock for better performance
        # Use safe dynamic dispatch based on instrument capability
        if hasattr(instrument, "add"):
            # Ensure value is valid for counters (they require int/float, not None)
            val = 1 if value is None else value
            instrument.add(val, attributes=attributes)
        elif hasattr(instrument, "record"):
            val = 1.0 if value is None else value
            instrument.record(val, attributes=attributes)
        else:
            self._sdk_logger.error(
                f"Unknown instrument type in cache for metric '{name}'. Unable to record value."
            )

    def record_gauge(self, name: str, value: float, **attributes: Any) -> None:
        """Record a gauge metric (current value that can go up or down).

        Args:
            name: Metric name. Should follow the repo's naming convention
                (see :class:`MetricNamingConvention`).
            value: Current gauge value.
            **attributes: Low-cardinality attributes to attach.

        Returns:
            None.

        Raises:
            ValidationError: In strict validation mode, when ``name`` violates
                the metric-naming convention or attributes fail validation.

        Example:
            >>> client.record_gauge("emms_model_accuracy", 0.92, dataset="test")
        """
        self.record_metric(name, value, instrument_type="up_down_counter", **attributes)

    def record_counter(self, name: str, value: float, **attributes: Any) -> None:
        """Record a counter metric (cumulative value that only increases).

        Args:
            name: Metric name.
            value: Counter value to add. Must be non-negative; passing a
                negative value is validated by the underlying OTel instrument.
            **attributes: Low-cardinality attributes to attach.

        Returns:
            None.

        Raises:
            ValidationError: In strict validation mode, when ``name`` violates
                the metric-naming convention or attributes fail validation.

        Example:
            >>> client.record_counter("model.predictions_total", 100, model_version="1.0")
        """
        self.record_metric(name, value, instrument_type="counter", **attributes)

    @contextmanager
    def trace(self, span_name: str, **attributes: Any) -> Any:
        """Context manager that opens a trace span for a code block.

        The span is closed automatically when the ``with`` block exits. If
        the block raises, the exception is recorded on the span before
        propagating.

        Args:
            span_name: Name of the span. Conventionally dot-separated
                (e.g., ``"model.predict"``, ``"agent.tool.sql_query"``).
            **attributes: Attributes to set on the span. Values are coerced
                to OTel-compatible types by the tracer.

        Yields:
            opentelemetry.trace.Span: The active span. Callers may add
            attributes, events, or status before the block exits.

        Example:
            >>> with client.trace("model.predict", model_version="1.0") as span:
            ...     result = model.predict(data)
            ...     span.set_attribute("input.rows", len(data))
        """
        with self._tracer.start_as_current_span(span_name) as span:
            for key, value in attributes.items():
                span.set_attribute(key, value)
            yield span

    @contextmanager
    def record_llm_generation(
        self,
        model: str,
        provider: Optional[str] = None,
        operation: str = "chat",
        prompt: Any = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        **attributes: Any,
    ) -> Any:
        """Emit a span shaped like a Langfuse GENERATION observation.

        Wraps a direct provider LLM call (e.g., Vertex AI Gemini, Bedrock,
        OpenAI SDK) in a span carrying the ``gen_ai.*`` OpenTelemetry
        semantic-convention attributes Langfuse keys off to promote the
        span to type ``GENERATION`` with populated ``latency_ms``.

        PHI NOTE:
            Per sdk/CLAUDE.md, PHI sanitization is the caller's
            responsibility. Do NOT pass raw prompts or completions that
            contain patient identifiers. Apply masking upstream before
            calling ``set_completion`` / passing ``prompt``.

        Args:
            model: Model identifier (e.g. ``gemini-2.0-flash-001``).
            provider: Provider / system name (``gen_ai.system``). Inferred
                from ``model`` when omitted (``gemini-*`` → ``google``,
                ``claude-*`` → ``anthropic``, etc.).
            operation: Value for ``gen_ai.operation.name`` (default
                ``chat``).
            prompt: Optional request payload. Serialized to the
                ``gen_ai.prompt`` attribute, subject to the SDK's
                telemetry size cap. Caller must mask PHI first.
            temperature: Optional ``gen_ai.request.temperature``.
            max_tokens: Optional ``gen_ai.request.max_tokens``.
            top_p: Optional ``gen_ai.request.top_p``.
            **attributes: Extra attributes appended to the span.

        Yields:
            A ``_LLMGenerationRecorder`` handle with ``set_completion``,
            ``set_usage``, and ``set_cost`` methods. The span is closed
            on context exit; exceptions set ``StatusCode.ERROR``.

        Example:
            >>> with client.record_llm_generation(
            ...     model="gemini-2.0-flash-001",
            ...     provider="google",
            ...     operation="chat",
            ... ) as gen:
            ...     response = model.generate_content(...)
            ...     gen.set_completion(response.text)
            ...     gen.set_usage(
            ...         prompt_tokens=response.usage_metadata.prompt_token_count,
            ...         completion_tokens=response.usage_metadata.candidates_token_count,
            ...     )
            ...     gen.set_cost(0.0001)
        """
        from opentelemetry.trace import Status, StatusCode

        from ..integrations._genai_attrs import (
            build_request_attributes,
            build_usage_attributes,
        )

        # Span-side parity with MCALiteLLMCallback: emit mca.model_id (plus
        # legacy unprefixed model_id) so direct-provider generation spans
        # join cleanly against genai.* metric datapoints. Plain attribute
        # access is sufficient here; only the callback has per-call
        # metadata overrides.
        bound_model_id = getattr(self.config, "model_id", None)

        span_attrs = build_request_attributes(
            model=model,
            provider=provider,
            operation=operation,
            model_id=bound_model_id,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=top_p,
        )

        max_size = getattr(self, "_capture_max_size_bytes", 32768)

        if prompt is not None:
            try:
                from ..utils.serialization import serialize_for_telemetry

                sanitized_prompt = _sanitize_data_recursive(prompt)
                span_attrs["gen_ai.prompt"] = serialize_for_telemetry(
                    sanitized_prompt, max_length=max_size
                )
            except Exception as e:  # pragma: no cover - defensive
                self._sdk_logger.debug(f"Failed to serialize prompt: {e}")

        for k, v in attributes.items():
            if v is not None:
                span_attrs[k] = v

        span = self._tracer.start_span(name=f"llm.{model}", attributes=span_attrs)
        start = time.perf_counter()

        class _LLMGenerationRecorder:
            __slots__ = (
                "_span",
                "_client_ref",
                "_model",
                "_max_size",
                "_completion_captured",
                "_model_id",
            )

            def __init__(
                self,
                span_obj: Any,
                client_ref: Any,
                model_name: str,
                max_size_bytes: int,
                model_id: Optional[str] = None,
            ) -> None:
                self._span = span_obj
                self._client_ref = client_ref
                self._model = model_name
                self._max_size = max_size_bytes
                self._completion_captured = False
                self._model_id = model_id

            @property
            def span(self) -> Any:
                return self._span

            def set_completion(self, text: Any) -> None:
                from ..utils.serialization import serialize_for_telemetry

                if text is None:
                    return
                sanitized = _sanitize_data_recursive(text)
                serialized = serialize_for_telemetry(sanitized, max_length=self._max_size)
                self._span.set_attribute("gen_ai.completion", serialized)
                self._span.set_attribute("genai.completion", serialized)
                self._completion_captured = True

            def set_usage(
                self,
                prompt_tokens: int = 0,
                completion_tokens: int = 0,
                total_tokens: int = 0,
                response_model: Optional[str] = None,
            ) -> None:
                usage_attrs = build_usage_attributes(
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    total_tokens=total_tokens,
                    response_model=response_model or self._model,
                    model_id=self._model_id,
                )
                for k, v in usage_attrs.items():
                    self._span.set_attribute(k, v)

            def set_cost(self, cost_usd: float) -> None:
                if cost_usd is None:
                    return
                self._span.set_attribute("gen_ai.usage.cost_usd", float(cost_usd))
                self._span.set_attribute("genai.cost_usd", float(cost_usd))

            def set_attribute(self, key: str, value: Any) -> None:
                self._span.set_attribute(key, value)

        recorder = _LLMGenerationRecorder(span, self, model, max_size, bound_model_id)
        try:
            yield recorder
        except BaseException as exc:
            try:
                span.set_attribute("error", True)
                span.set_attribute("error.type", type(exc).__name__)
                span.set_status(
                    Status(
                        StatusCode.ERROR,
                        f"LLM generation failed: {type(exc).__name__}",
                    )
                )
            finally:
                latency = time.perf_counter() - start
                span.set_attribute("gen_ai.latency_seconds", latency)
                span.set_attribute("genai.latency_seconds", latency)
                span.end()
            raise
        else:
            latency = time.perf_counter() - start
            span.set_attribute("gen_ai.latency_seconds", latency)
            span.set_attribute("genai.latency_seconds", latency)
            span.set_status(Status(StatusCode.OK))
            span.end()

    @contextmanager
    def record_retrieval(
        self,
        query: str,
        documents: "Any",
        *,
        score_metric: str = "unknown",
        source_system: Optional[str] = None,
        sampling_rate: float = 1.0,
        parent_retrieval_id: Optional[str] = None,
        relevance: Optional["Any"] = None,
        **attributes: Any,
    ) -> Any:
        """Emit a span shaped like a Langfuse RETRIEVAL observation.

        Wraps a RAG retrieval step in a span that carries the parallel-array
        ``gen_ai.rag.*`` attributes pinned in ``docs/api-contracts.md``
        section 9.2. Sets ``langfuse.observation.type="retrieval"`` so
        Langfuse promotes the span to a RETRIEVAL observation. Hybrid
        retrievers MUST emit one ``rag.retrieval`` span per retriever and
        share a caller-supplied ``parent_retrieval_id`` UUID so the
        evaluator can group them.

        PHI NOTE:
            Per sdk/CLAUDE.md, PHI sanitization is the caller's
            responsibility. Do NOT pass raw queries or document fields
            that contain patient identifiers. Apply masking upstream
            before calling ``record_retrieval``.

        Args:
            query: The user's input query that triggered retrieval.
                Serialized to ``gen_ai.rag.query`` under the SDK-wide
                telemetry size cap.
            documents: Sequence of mappings, each with ``id`` and
                ``score`` keys. When ``len(documents) > 50`` the SDK
                truncates to the top-50 by score and sets
                ``gen_ai.rag.documents.truncated=true``.
            score_metric: Original scoring family. One of
                ``cosine`` / ``dot_product`` / ``bm25`` /
                ``reciprocal_rank`` / ``llm_logprob`` / ``unknown``.
                Defaults to ``unknown``.
            source_system: Optional retriever family for hybrid flows.
                One of ``dense`` / ``sparse`` / ``graph`` /
                ``reranker`` / ``other``.
            sampling_rate: Float in ``[0.0, 1.0]`` documenting the
                downstream sampling decision. SDK never drops spans on
                its own; the attribute is a sentinel for the evaluator.
            parent_retrieval_id: Caller-supplied UUID grouping sibling
                ``rag.retrieval`` spans in hybrid retrievers.
            relevance: Optional parallel array of
                ``relevant`` / ``partial`` / ``irrelevant`` labels.
                Length MUST equal ``len(documents)`` if supplied.
            **attributes: Extra attributes appended to the span.

        Yields:
            A ``_RetrievalRecorder`` handle exposing ``span`` and
            ``set_attribute``. The span is closed on context exit;
            exceptions set ``StatusCode.ERROR``.

        Raises:
            ValidationError: If ``relevance`` length disagrees with
                ``documents``, if any score is non-finite, or if
                ``score_metric`` / ``source_system`` / ``sampling_rate``
                / ``relevance`` values fall outside the §9.2 enums.

        Example:
            >>> with client.record_retrieval(
            ...     query="patient readmission risk factors",
            ...     documents=[
            ...         {"id": "doc-1", "score": 0.92},
            ...         {"id": "doc-2", "score": 0.78},
            ...     ],
            ...     score_metric="cosine",
            ...     source_system="dense",
            ... ) as ret:
            ...     pass
        """
        from opentelemetry.trace import Status, StatusCode

        from ..integrations._genai_attrs import build_retrieval_attributes
        from ..utils.exceptions import ValidationError
        from ..utils.serialization import serialize_for_telemetry

        bound_model_id = getattr(self.config, "model_id", None)
        max_size = getattr(self, "_capture_max_size_bytes", 32768)

        # Sanitize and serialize the query under the SDK-wide size cap
        # before handing it to the attribute builder, mirroring the
        # record_llm_generation path.
        try:
            sanitized_query = _sanitize_data_recursive(query) if query is not None else ""
            serialized_query = serialize_for_telemetry(sanitized_query, max_length=max_size)
        except Exception as e:  # pragma: no cover - defensive
            self._sdk_logger.debug(f"Failed to serialize RAG query: {e}")
            serialized_query = ""

        try:
            span_attrs = build_retrieval_attributes(
                query=query if query is not None else "",
                documents=list(documents) if documents is not None else [],
                score_metric=score_metric,
                source_system=source_system,
                sampling_rate=sampling_rate,
                parent_retrieval_id=parent_retrieval_id,
                relevance=list(relevance) if relevance is not None else None,
                model_id=bound_model_id,
                serialized_query=serialized_query,
            )
        except ValueError as exc:
            # Re-raise as the SDK's public ValidationError so callers
            # can catch a single exception type for all input-shape
            # failures, matching record_metric's behavior.
            raise ValidationError(str(exc)) from exc

        constant_score = span_attrs.pop("__mca_internal_constant_score", False)
        if constant_score:
            self._sdk_logger.debug(
                "RAG retrieval scores have zero spread; emitting all-1.0 normalized array"
            )

        for k, v in attributes.items():
            if v is not None:
                span_attrs[k] = v

        span = self._tracer.start_span(name="rag.retrieval", attributes=span_attrs)
        start = time.perf_counter()

        class _RetrievalRecorder:
            __slots__ = ("_span",)

            def __init__(self, span_obj: Any) -> None:
                self._span = span_obj

            @property
            def span(self) -> Any:
                return self._span

            def set_attribute(self, key: str, value: Any) -> None:
                self._span.set_attribute(key, value)

        recorder = _RetrievalRecorder(span)
        try:
            yield recorder
        except BaseException as exc:
            try:
                span.set_attribute("error", True)
                span.set_attribute("error.type", type(exc).__name__)
                span.set_status(
                    Status(
                        StatusCode.ERROR,
                        f"RAG retrieval failed: {type(exc).__name__}",
                    )
                )
            finally:
                latency = time.perf_counter() - start
                span.set_attribute("gen_ai.latency_seconds", latency)
                span.end()
            raise
        else:
            latency = time.perf_counter() - start
            span.set_attribute("gen_ai.latency_seconds", latency)
            span.set_status(Status(StatusCode.OK))
            span.end()

    # Agentic AI tracking methods (Story 1.11)

    def record_goal_started(
        self, goal_description: str, goal_type: str = "general", **attributes: Any
    ) -> str:
        """Start tracking an agent goal.

        Creates a new goal with a unique ID, starts a parent span, and
        increments the goals_started counter. The goal must be completed
        by calling record_goal_completed() with the returned goal_id.

        Args:
            goal_description: Human-readable description of the goal
            goal_type: Category of goal (e.g., "research", "analysis", "general")
            **attributes: Additional attributes to attach to the goal span

        Returns:
            Unique goal_id (UUID string) for tracking and completion

        Warning:
            HIPAA COMPLIANCE: goal_description is truncated but NOT sanitized for PHI.
            Users MUST NOT include patient identifiers, SSNs, names, or other PHI
            in goal descriptions. Use generic descriptions only (e.g., "Research
            treatment options" NOT "Research for patient John Doe SSN 123-45-6789").

        Example:
            >>> goal_id = client.record_goal_started(
            ...     "Research diabetes treatments",
            ...     goal_type="research"
            ... )
            >>> # ... execute goal steps ...
            >>> client.record_goal_completed(goal_id, status="success")
        """
        # Ensure cleanup thread is alive (Finding 9 fix)
        self._ensure_cleanup_thread_alive()

        # Sanitize inputs to prevent high-cardinality issues
        goal_description_sanitized = (
            goal_description[:200] if goal_description else "No description"
        )
        goal_type_sanitized = goal_type[:50] if goal_type else "general"

        goal_id = str(uuid.uuid4())
        start_time = time.perf_counter()

        # Start goal span
        span = self._tracer.start_span(
            "agent.goal",
            attributes={
                "goal_id": goal_id,
                "goal_type": goal_type_sanitized,
                "goal_description": goal_description_sanitized,
                **attributes,
            },
        )

        # Make this span the current context and get the detach token
        from opentelemetry import context as otel_context

        context_token = otel_context.attach(trace.set_span_in_context(span))

        # Store for later completion (cleanup handled by background thread)
        with self._goals_lock:
            self._active_goals[goal_id] = (span, start_time, context_token)

        # Increment counter
        self._goals_started_counter.add(1, attributes={"goal_type": goal_type_sanitized})

        if self.config.debug_mode:
            self._sdk_logger.debug(
                f"[{goal_id}] Goal started: {goal_description_sanitized[:50]}... "
                f"(type={goal_type_sanitized})"
            )

        return goal_id

    def record_goal_completed(
        self, goal_id: str, status: str = "success", **attributes: Any
    ) -> None:
        """Complete tracking of an agent goal.

        Ends the goal span, records duration metrics, and increments the
        goals_completed counter with the specified status.

        Args:
            goal_id: The goal ID returned from record_goal_started()
            status: Completion status - must be one of: "success", "failure", "partial"
            **attributes: Additional attributes to attach to the goal span

        Raises:
            ValueError: If goal_id is not found or status is invalid
        """
        valid_statuses = {"success", "failure", "partial"}
        if status not in valid_statuses:
            raise ValueError(
                f"Invalid goal status: '{status}'. "
                f"Must be one of: {', '.join(sorted(valid_statuses))}"
            )

        with self._goals_lock:
            if goal_id not in self._active_goals:
                raise ValueError(
                    f"Unknown goal_id: '{goal_id}'. "
                    f"Goal may have already been completed or was never started."
                )
            span, start_time, context_token = self._active_goals.pop(goal_id)

        # FIX Issue #1: Clean up tool execution state for this goal to prevent memory leak
        with self._tool_state_lock:
            # Remove all tool state entries for this goal
            keys_to_remove = [key for key in self._tool_execution_state.keys() if key[0] == goal_id]
            for tool_state_key in keys_to_remove:
                del self._tool_execution_state[tool_state_key]
            if keys_to_remove and self.config.debug_mode:
                self._sdk_logger.debug(
                    f"[{goal_id}] Cleaned up {len(keys_to_remove)} tool state entries"
                )

        duration = time.perf_counter() - start_time

        # Set span attributes and status
        span.set_attribute("goal_status", status)
        # FIX Issue #7: Use exact data dictionary name "goal_completion_time"
        span.set_attribute("goal_completion_time", duration)
        for key, value in attributes.items():
            span.set_attribute(key, value)

        from opentelemetry.trace import Status, StatusCode

        if status == "success":
            span.set_status(Status(StatusCode.OK))
        elif status == "failure":
            span.set_status(Status(StatusCode.ERROR, "Goal failed"))
        else:  # partial
            span.set_status(Status(StatusCode.OK, "Goal partially completed"))

        span.end()

        # Detach context
        from opentelemetry import context as otel_context

        otel_context.detach(context_token)

        # Record metrics - use separate counters for success vs failure (AC: 2)
        if status == "failure":
            self._goals_failed_counter.add(1, attributes={"status": status})
        else:
            # Count success and partial as completed
            self._goals_completed_counter.add(1, attributes={"status": status})
        self._goal_duration_histogram.record(duration, attributes={"status": status})

        if self.config.debug_mode:
            self._sdk_logger.debug(
                f"[{goal_id}] Goal completed: status={status}, duration={duration:.3f}s"
            )

    @contextmanager
    def track_tool(self, tool_name: str, goal_id: Optional[str] = None, **attributes: Any) -> Any:
        """Context manager for tracking tool execution.

        NOTE: Token tracking (tool.input_tokens, tool.output_tokens) should be
        implemented when integrating with LLM-based tools. For mock tools or
        non-LLM tools, token attributes are not applicable.

        Automatically captures tool latency, records metrics, and handles
        errors. When used within a goal, the tool span becomes a child of
        the goal span.

        Nested tool calls are supported: only the outermost call records metrics
        to prevent double-counting, but all calls create spans for visibility.

        Args:
            tool_name: Name of the tool being executed
            goal_id: Optional goal ID to correlate this tool call with a specific goal
            **attributes: Additional attributes to attach to the tool span

        Yields:
            The tool span for adding custom attributes

        Example:
            >>> goal_id = client.record_goal_started("Research question")
            >>> with client.track_tool("pubmed_search", goal_id=goal_id, query="diabetes") as span:
            ...     results = pubmed.search("diabetes")
            ...     span.set_attribute("results_count", len(results))
            >>> client.record_goal_completed(goal_id)
        """
        # Track nesting depth using contextvars (thread-safe)
        # Guard against None: test fixtures (reset_global_state) may set ContextVars to None
        current_depth = _tool_call_depth.get() or 0
        _tool_call_depth.set(current_depth + 1)

        # Sanitize tool_name to prevent high-cardinality issues
        tool_name_sanitized = tool_name[:100] if tool_name else "unknown"
        start_time = time.perf_counter()

        # Story 1.19: Check for retry scenario (recovery tracking)
        state_key = (goal_id, tool_name_sanitized) if goal_id else None
        is_retry = False
        if state_key:
            with self._tool_state_lock:
                if state_key in self._tool_execution_state:
                    state = self._tool_execution_state[state_key]
                    if state.get("first_failed"):
                        is_retry = True

        # Add goal_id to span attributes if provided for correlation
        span_attributes = {
            "tool_name": tool_name_sanitized,
            "tool_depth": current_depth + 1,
            **attributes,
        }
        if goal_id:
            span_attributes["goal_id"] = goal_id

        # Story 1.19: Add recovery attributes if retry detected
        if is_retry:
            span_attributes["genai.agent.recovery.attempted"] = True
        else:
            # FIX Issue #5: Set baseline False when not a retry
            span_attributes["genai.agent.recovery.attempted"] = False

        try:
            with self._tracer.start_as_current_span(
                f"agent.tool.{tool_name_sanitized}", attributes=span_attributes
            ) as span:
                try:
                    yield span

                    # Calculate latency for successful tool execution
                    latency = time.perf_counter() - start_time

                    # Story 1.19: Set tool success and recovery success attributes
                    span.set_attribute("genai.agent.tool.success", True)
                    if is_retry:
                        span.set_attribute("genai.agent.recovery_success", True)
                        # Clear recovery state on successful retry
                        if state_key:
                            with self._tool_state_lock:
                                self._tool_execution_state.pop(state_key, None)
                    else:
                        # Set baseline False for non-retry
                        span.set_attribute("genai.agent.recovery_success", False)

                    # Record metrics for ALL tool calls (AC: 3)
                    # NOTE: goal_id is NOT included in metrics (high cardinality - causes OOM)
                    # goal_id is in span attributes (line 2625) for trace correlation
                    metric_attrs = {
                        "tool_name": tool_name_sanitized,
                        "status": "success",
                    }

                    # Latency histogram attributes (low-cardinality labels only)
                    latency_attrs = {"tool_name": tool_name_sanitized}

                    self._tool_calls_counter.add(1, attributes=metric_attrs)
                    self._tool_latency_histogram.record(latency, attributes=latency_attrs)

                    if self.config.debug_mode:
                        goal_info = f" (goal={goal_id[:8]}...)" if goal_id else ""
                        depth_info = f" [depth={current_depth + 1}]" if current_depth > 0 else ""
                        self._sdk_logger.debug(
                            f"Tool '{tool_name_sanitized}' completed: "
                            f"latency={latency:.3f}s{goal_info}{depth_info}"
                        )

                except Exception as e:
                    latency = time.perf_counter() - start_time
                    error_type = type(e).__name__
                    error_message = _sanitize_error_message(str(e), max_length=200)

                    from opentelemetry.trace import Status, StatusCode

                    span.set_status(Status(StatusCode.ERROR, error_message))
                    # NOTE: NOT using span.record_exception(e) to prevent PHI leakage
                    # Only sanitized error information is recorded
                    span.set_attribute("tool_latency_seconds", latency)
                    span.set_attribute("error_type", error_type)
                    span.set_attribute("error_message", error_message)

                    # Story 1.19: Set tool failure and track state for retry detection
                    span.set_attribute("genai.agent.tool.success", False)
                    if is_retry:
                        # Retry also failed
                        span.set_attribute("genai.agent.recovery_success", False)
                    else:
                        # Set baseline False for first failure
                        span.set_attribute("genai.agent.recovery_success", False)

                    # Track failure state for potential retry
                    if state_key:
                        with self._tool_state_lock:
                            if state_key not in self._tool_execution_state:
                                self._tool_execution_state[state_key] = {
                                    "attempts": 1,
                                    "first_failed": True,
                                }
                            else:
                                self._tool_execution_state[state_key]["attempts"] += 1

                    # Record metrics for ALL tool calls (AC: 3)
                    # NOTE: goal_id is NOT included in metrics (high cardinality - causes OOM)
                    # goal_id is in span attributes (line 2625) for trace correlation
                    metric_attrs = {"tool_name": tool_name_sanitized, "status": "error"}

                    error_attrs = {
                        "tool_name": tool_name_sanitized,
                        "error_type": error_type,
                    }

                    # Latency histogram attributes (low-cardinality labels only)
                    latency_attrs = {"tool_name": tool_name_sanitized}

                    self._tool_calls_counter.add(1, attributes=metric_attrs)
                    self._tool_errors_counter.add(1, attributes=error_attrs)
                    self._tool_latency_histogram.record(latency, attributes=latency_attrs)

                    if self.config.debug_mode:
                        goal_info = f" (goal={goal_id[:8]}...)" if goal_id else ""
                        depth_info = f" [depth={current_depth + 1}]" if current_depth > 0 else ""
                        self._sdk_logger.debug(
                            f"Tool '{tool_name_sanitized}' failed: error={error_type}, "
                            f"message={error_message[:50]}, latency={latency:.3f}s{goal_info}{depth_info}"
                        )

                    raise
        finally:
            # Always restore depth, even if exception occurred
            _tool_call_depth.set(current_depth)

    def record_human_intervention(
        self,
        reason: str,
        wait_time: Optional[float] = None,
        intervention_type: str = "review",
        timestamp: Optional[float] = None,
        required: bool = True,
        **attributes: Any,
    ) -> None:
        """Record a human intervention event.

        Tracks when the agent requests or requires human intervention,
        such as approval, review, or clarification.

        This method supports two modes:
        1. Legacy mode (default): Creates a new span (backward compatible)
        2. Event mode (timestamp provided): Adds span event to current span (Story 1.19)

        Args:
            reason: Description of why intervention was needed
            wait_time: Optional time spent waiting for human response (seconds)
            intervention_type: Type of intervention (e.g., "review", "approval",
                              "clarification", "escalation")
            timestamp: Optional event timestamp (seconds since epoch). If provided,
                      records as span event instead of creating new span.
                      WARNING: Must be time.time(), NOT time.perf_counter()
            required: Whether intervention is mandatory (True) or optional (False)
                     FIX Issue #6: Parameterized instead of hardcoded
            **attributes: Additional attributes to attach

        Example (Story 1.19 - span event mode):
            >>> client.record_human_intervention(
            ...     reason="expert_review_needed",
            ...     timestamp=time.time(),
            ...     required=True
            ... )

        Example (Optional intervention):
            >>> client.record_human_intervention(
            ...     reason="optional_clarification",
            ...     timestamp=time.time(),
            ...     required=False
            ... )

        Example (Legacy - span mode):
            >>> client.record_human_intervention(
            ...     reason="approval_required",
            ...     wait_time=120.0
            ... )
        """
        # Sanitize inputs to prevent high-cardinality issues
        reason_sanitized = reason[:200] if reason else "No reason provided"
        intervention_type_sanitized = intervention_type[:50] if intervention_type else "review"

        # Story 1.19: If timestamp provided, use span event mode
        if timestamp is not None:
            # FIX Issue #9: Validate timestamp is reasonable epoch time
            if timestamp < 1e9:  # Before year 2001 - likely perf_counter or invalid
                raise ValueError(
                    f"timestamp appears invalid ({timestamp}). "
                    f"Must be epoch seconds from time.time(), not time.perf_counter(). "
                    f"Current epoch: {time.time()}"
                )

            current_span = trace.get_current_span()

            if current_span and current_span.is_recording():
                # Record as span event per story 1.19 spec
                # FIX Issue #6: Use parameterized 'required' flag
                current_span.add_event(
                    "genai.agent.human_intervention",
                    attributes={
                        "intervention.required": required,
                        "intervention.reason": reason_sanitized,
                    },
                    timestamp=int(timestamp * 1e9),  # Convert to nanoseconds
                )

                # Still record metrics
                self._human_interventions_counter.add(
                    1,
                    attributes={
                        "reason": reason_sanitized,
                        "intervention_type": intervention_type_sanitized,
                    },
                )

                if self.config.debug_mode:
                    self._sdk_logger.debug(
                        f"Human intervention event recorded: reason={reason_sanitized[:50]}..."
                    )
            else:
                self._sdk_logger.warning(
                    "Human intervention requested but no active span to record event"
                )
        else:
            # Legacy mode: Create new span (backward compatible with story 1.11)
            # FIX Issue #8: Use explicit timestamp manipulation to create meaningful span duration
            # WITHOUT blocking the application thread

            if wait_time is not None and wait_time > 0:
                # Calculate synthetic start time in the past to represent wait duration
                current_time = time.time()
                start_time_ns = int((current_time - wait_time) * 1e9)

                # Use start_span with explicit start_time (not start_as_current_span)
                span = self._tracer.start_span(
                    "agent.human_intervention",
                    start_time=start_time_ns,
                    attributes={
                        "intervention_reason": reason_sanitized,
                        "intervention_type": intervention_type_sanitized,
                        "intervention_wait_time_seconds": wait_time,
                        **attributes,
                    },
                )

                # Record metrics
                self._human_interventions_counter.add(
                    1,
                    attributes={
                        "reason": reason_sanitized,
                        "intervention_type": intervention_type_sanitized,
                    },
                )

                self._intervention_wait_histogram.record(
                    wait_time,
                    attributes={
                        "reason": reason_sanitized,
                        "intervention_type": intervention_type_sanitized,
                    },
                )

                # End span at current time, creating duration = wait_time
                span.end()
            else:
                # No wait_time specified - use instant span
                with self._tracer.start_as_current_span(
                    "agent.human_intervention",
                    attributes={
                        "intervention_reason": reason_sanitized,
                        "intervention_type": intervention_type_sanitized,
                        **attributes,
                    },
                ) as span:
                    self._human_interventions_counter.add(
                        1,
                        attributes={
                            "reason": reason_sanitized,
                            "intervention_type": intervention_type_sanitized,
                        },
                    )

            if self.config.debug_mode:
                wait_info = f", wait_time={wait_time:.3f}s" if wait_time else ""
                self._sdk_logger.debug(
                    f"Human intervention recorded: type={intervention_type_sanitized}, "
                    f"reason={reason_sanitized[:50]}...{wait_info}"
                )

    @contextmanager
    def reasoning_step(
        self,
        step_type: str,
        step_description: Optional[str] = None,
        llm_model: Optional[str] = None,
        **attributes: Any,
    ) -> Any:
        """Context manager for tracking an agent reasoning step.

        Tracks duration and metadata of reasoning steps in an agent's decision-making
        process. This allows visibility into planning, evaluation, tool selection,
        and other cognitive processes.

        NOTE: For LLM-based reasoning, add tokens_used attribute within the context:
            >>> with client.reasoning_step("planning") as span:
            ...     response = llm.complete(prompt)
            ...     span.set_attribute("tokens_used", response.usage.total_tokens)

        Args:
            step_type: Type of reasoning step (e.g., "planning", "tool_call",
                      "evaluation", "synthesis")
            step_description: Optional human-readable description of the step
            llm_model: Optional LLM model used for this reasoning step
            **attributes: Additional attributes to attach to the step

        Yields:
            The reasoning step span for adding custom attributes

        Example:
            >>> with client.reasoning_step("planning", "Analyzing query"):
            ...     plan = planner.create_plan(query)
        """
        # Sanitize inputs to prevent high-cardinality issues
        step_type_sanitized = step_type[:50] if step_type else "unknown"
        step_description_sanitized = step_description[:200] if step_description else None
        llm_model_sanitized = llm_model[:50] if llm_model else None
        start_time = time.perf_counter()

        # Build span attributes
        span_attributes = {"reasoning_step_type": step_type_sanitized, **attributes}
        if step_description_sanitized:
            span_attributes["reasoning_step_description"] = step_description_sanitized
        if llm_model_sanitized:
            span_attributes["llm_model"] = llm_model_sanitized

        # Create span for reasoning step
        with self._tracer.start_as_current_span(
            "agent.reasoning_step", attributes=span_attributes
        ) as span:
            try:
                yield span

                # Record successful completion
                self._reasoning_steps_counter.add(
                    1,
                    attributes={"step_type": step_type_sanitized, "status": "success"},
                )

                if self.config.debug_mode:
                    duration = time.perf_counter() - start_time
                    model_info = f", model={llm_model_sanitized}" if llm_model_sanitized else ""
                    self._sdk_logger.debug(
                        f"Reasoning step completed: type={step_type_sanitized}{model_info}, "
                        f"duration={duration:.3f}s"
                    )

            except Exception:
                # Record failure
                self._reasoning_steps_counter.add(
                    1, attributes={"step_type": step_type_sanitized, "status": "error"}
                )
                raise

    def get_current_goal_id(self) -> Optional[str]:
        """Get the currently active goal_id from decorator context.

        Returns the goal_id set by @trace_agent_goal decorator, or None if not
        within a decorated goal context.

        FIX Issue #2: Thread-safe retrieval using ContextVar (safe for concurrent web servers).

        Returns:
            goal_id if within @trace_agent_goal context, None otherwise

        Example:
            >>> @trace_agent_goal(client, "Research", "analysis")
            ... def my_goal():
            ...     goal_id = client.get_current_goal_id()  # Thread-safe retrieval
            ...     with client.track_tool("search", goal_id=goal_id):
            ...         pass
        """
        # Import here to avoid circular dependency
        from ..integrations.decorators import _current_goal_id

        return _current_goal_id.get()

    def record_policy_violation(self, policy_type: str) -> None:
        """Record a security policy violation event (Story 1.19).

        Records a span event when the agent attempts or detects an unauthorized
        action that violates security policies. This is for observability and
        compliance tracking.

        Args:
            policy_type: Type of policy violated (e.g., "data_access", "api_quota",
                        "phi_exposure", "unauthorized_tool_use")

        Example:
            >>> if not user.has_permission("admin"):
            ...     client.record_policy_violation("unauthorized_admin_access")
            ...     raise PermissionError("Admin access denied")

        Warning:
            Do not include PHI or sensitive data in policy_type. Use generic
            policy categories only.
        """
        # Sanitize policy_type to prevent high-cardinality
        policy_type_sanitized = policy_type[:100] if policy_type else "unknown_violation"

        # Get current span (should be within goal/step context)
        current_span = trace.get_current_span()

        if current_span and current_span.is_recording():
            # Record as span event per story 1.19 spec
            # FIX Issue #4: Use exact data dictionary name "unauthorized_action_attempted"
            current_span.add_event(
                "genai.agent.policy_violation",
                attributes={
                    "unauthorized_action_attempted": True,
                    "policy_violated_type": policy_type_sanitized,
                },
            )

            if self.config.debug_mode:
                self._sdk_logger.warning(f"Policy violation recorded: {policy_type_sanitized}")
        else:
            # No active span - log warning
            self._sdk_logger.warning(
                f"Policy violation detected ({policy_type_sanitized}) but no active span to record event"
            )

    def flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush all telemetry providers.

        This method forces all OpenTelemetry providers (metrics, logs, and traces)
        to flush their internal buffers to the configured exporters immediately.
        It is safe to call this mid-lifecycle (e.g., after processing a batch).

        Args:
            timeout_millis: Maximum time to wait for flush in milliseconds.

        Returns:
            ``True`` if every provider flushed cleanly. ``False`` if the
            client is already shut down or any provider raised — errors are
            logged at debug level, never re-raised.

        Note:
            This method never raises. Downstream exporter failures are
            swallowed and surfaced via the return value so the caller can
            continue without a try/except wrapper.

        Example:
            >>> if not client.flush(timeout_millis=5000):
            ...     logger.warning("telemetry flush partially failed")
        """
        if self._shutdown:
            logging.debug("MCA SDK client already shut down — ignoring flush() call")
            return False

        success = True
        try:
            self._meter_provider.force_flush(timeout_millis=timeout_millis)
        except Exception as e:
            logging.debug(f"Error flushing metrics: {e}")
            success = False

        try:
            self._logger_provider.force_flush(timeout_millis=timeout_millis)
        except Exception as e:
            logging.debug(f"Error flushing logs: {e}")
            success = False

        try:
            self._tracer_provider.force_flush(timeout_millis=timeout_millis)
        except Exception as e:
            logging.debug(f"Error flushing traces: {e}")
            success = False

        return success

    def shutdown(self, timeout_millis: int = 30000) -> None:
        """Gracefully shutdown the client and flush all telemetry.

        This should be called when the application is shutting down to ensure
        all metrics, logs, and traces are exported. Idempotent: calling twice
        is safe and logs a debug message on the second call.

        The shutdown sequence: stop background threads (goal cleanup,
        registry refresh, Prometheus server) → force-flush providers →
        shutdown exporters → close registry client.

        Args:
            timeout_millis: Maximum time to wait for each provider's
                ``force_flush`` call, in milliseconds. Applied per provider,
                not globally — total shutdown time can be up to 3× this value
                plus thread-join timeouts.

        Returns:
            None.

        Note:
            ``shutdown()`` never raises. Provider errors are logged at debug
            level and shutdown continues. This is deliberate: the caller is
            usually inside an ``atexit`` handler or a ``finally`` block and
            cannot meaningfully recover.

        Example:
            >>> try:
            ...     client.record_prediction(latency=0.1)
            ... finally:
            ...     client.shutdown(timeout_millis=5000)
        """
        if self._shutdown:
            logging.debug("MCA SDK client already shut down — ignoring duplicate shutdown() call")
            return

        self._logger.info("Shutting down MCA SDK client")

        # Stop background cleanup thread for stale goals
        self._stop_cleanup_thread(timeout=5.0)

        # Stop background refresh thread (if registry client exists)
        self._refresh_running = False
        if self._telemetry_queue is not None and self._telemetry_queue.size() > 0:
            import logging as _logging

            _logging.warning(
                f"Shutting down with {self._telemetry_queue.size()} items still in telemetry buffer"
            )
        if self._registry_client:
            self._registry_client.stop_refresh_thread(timeout=5.0)
            self._registry_client.close()
            logging.debug("Registry client closed")

        # Shutdown Prometheus server if running
        if hasattr(self, "_prometheus_shutdown") and self._prometheus_shutdown:
            self._prometheus_shutdown()

        # Force flush all providers BEFORE shutting down exporters
        # This ensures BatchSpanProcessor drains its queue first
        self._meter_provider.force_flush(timeout_millis=timeout_millis)

        # Story 6-42: stop the audit QueueListener BEFORE logger_provider
        # shutdown so any drained records still have an exporter to flush
        # through. stop() blocks until the background thread has drained the
        # queue; no silent record loss.
        if hasattr(self, "_audit_drain_thread"):
            try:
                self._audit_drain_thread.stop(timeout=5.0)
            except Exception:
                pass
        if hasattr(self, "_audit_spillover"):
            try:
                if hasattr(self, "_otel_handler"):
                    self._audit_spillover.drain(self._otel_handler.emit)
            except Exception:
                pass
        if hasattr(self, "_audit_listener"):
            try:
                self._audit_listener.stop()
            except Exception:
                # Listener stop should not prevent shutdown of other providers.
                pass

        self._logger_provider.force_flush(timeout_millis=timeout_millis)
        self._tracer_provider.force_flush(timeout_millis=timeout_millis)

        # Remove logging handler to prevent resource leak
        if hasattr(self, "_otel_handler"):
            self._logger.removeHandler(self._otel_handler)
        if hasattr(self, "_audit_logger") and hasattr(self, "_audit_queue_handler"):
            self._audit_logger.removeHandler(self._audit_queue_handler)

        # Shutdown providers (this will automatically shut down all registered processors and their exporters)
        # NOTE: GCP Cloud Trace exporter will be shut down by tracer_provider.shutdown()
        # via BatchSpanProcessor.shutdown(), so we don't call exporter.shutdown() directly
        from .providers import unregister_provider

        if unregister_provider(self._meter_provider):
            self._meter_provider.shutdown()

        self._logger_provider.shutdown()
        self._tracer_provider.shutdown()

        self._shutdown = True

        # Clear singleton instance for autolog() support
        with MCAClient._instance_lock:
            if MCAClient._instance is self:
                MCAClient._instance = None

    def __enter__(self) -> "MCAClient":
        """Enter the runtime context and return this client.

        Returns:
            The :class:`MCAClient` instance, so it can be bound via
            ``with MCAClient(...) as client:``.

        Example:
            >>> with MCAClient(service_name="my-model") as client:
            ...     client.record_prediction(latency=0.1)
        """
        return self

    def __exit__(
        self,
        exc_type: Optional[type],
        exc_val: Optional[BaseException],
        exc_tb: Any,
    ) -> None:
        """Flush and shut down the client on context exit.

        Args:
            exc_type: Exception class if the block raised, else ``None``.
            exc_val: Exception instance if the block raised, else ``None``.
            exc_tb: Traceback if the block raised, else ``None``.

        Returns:
            ``None`` — the client never suppresses exceptions raised in the
            ``with`` block. Any exception propagates to the caller.
        """
        self.shutdown()
