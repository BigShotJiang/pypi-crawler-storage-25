"""Shared environment detection helpers.

Provides stateless production-environment detection consumed by
TelemetryQueue and DeadLetterQueue to avoid policy drift between
buffer implementations. Honors MCA_ALLOW_ENV_KEYS_IN_PROD as a
documented escape hatch for dev/test scenarios.
"""

import logging
import os
import re

logger = logging.getLogger(__name__)

# Module-level regex for production markers in K8s namespace / GCP project names.
# Matches "prod" or "production" as a component separated by non-word characters
# (covers "-prod-", "_production_", ".prod.", etc.) so we don't false-positive on
# names like "reproduction-api" or "prodigy-team".
_PROD_MARKER_RE = re.compile(r"(^|[\W_])(prod|production)([\W_]|$)")


def _str_to_bool(value: str) -> bool:
    """Convert string to boolean.

    Accepts: "true", "1", "yes", "on" (case-insensitive).

    Args:
        value: String value to convert.

    Returns:
        True if value matches a truthy string, False otherwise.
    """
    return value.lower() in ("true", "1", "yes", "on")


def is_production_environment() -> bool:
    """Detect if the current process is running in a production environment.

    Stateless heuristic consulted by buffer implementations before loading
    encryption keys from environment variables or enabling unencrypted
    persistence. Sharing the logic here guarantees that TelemetryQueue
    and DeadLetterQueue enforce the same policy.

    Detection priority:
        1. MCA_ALLOW_ENV_KEYS_IN_PROD=true (override; logs CRITICAL warning
           and returns False, matching the historical behavior in
           TelemetryQueue).
        2. MCA_ENVIRONMENT: "production" => True; "development"/"dev"/
           "test"/"testing" => False (explicit dev/test opt-out).
        3. ENV / ENVIRONMENT / DEPLOY_ENV / APP_ENV: any value in
           {"production", "prod", "prd"} => True.
        4. KUBERNETES_NAMESPACE contains "prod" or "production" as a
           component (only considered when KUBERNETES_SERVICE_HOST is set,
           i.e. we're inside a K8s pod).
        5. GCP_PROJECT contains "prod" or "production" as a component.
        6. Default: False (safe for local development).

    Returns:
        True if production environment detected, False otherwise.
    """
    # Read the override env var ONCE. env_key_override_enabled() is called
    # separately by some callers (e.g., DLQ warning log), which results in
    # double-reads if we don't consolidate. The module-level cost is minor
    # but this matters at high TPS construction paths.
    override_value = os.environ.get("MCA_ALLOW_ENV_KEYS_IN_PROD", "")

    # Override first so the CRITICAL warning fires before any other check.
    # Match TelemetryQueue behavior: the override returns False (treat as
    # non-production) and emits a CRITICAL log.
    if _str_to_bool(override_value):
        logger.critical(
            "SECURITY OVERRIDE ACTIVE\n"
            "MCA_ALLOW_ENV_KEYS_IN_PROD=true detected.\n"
            "Environment variable key loading ALLOWED despite production detection.\n"
            "THIS OVERRIDE MUST NEVER BE USED IN ACTUAL PRODUCTION DEPLOYMENTS.\n"
            "This is a security bypass for development/testing only."
        )
        return False

    # Explicit MCA_ENVIRONMENT takes priority over generic markers.
    mca_env = os.environ.get("MCA_ENVIRONMENT", "").lower()
    if mca_env == "production":
        return True
    if mca_env in ("development", "dev", "test", "testing"):
        return False

    # Generic environment markers.
    for marker in ("ENV", "ENVIRONMENT", "DEPLOY_ENV", "APP_ENV"):
        value = os.environ.get(marker, "").lower()
        if value in ("production", "prod", "prd"):
            return True

    # Kubernetes namespace heuristic (only if actually running in K8s).
    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        namespace = os.environ.get("KUBERNETES_NAMESPACE", "").lower()
        if _PROD_MARKER_RE.search(namespace):
            return True

    # GCP project heuristic.
    gcp_project = os.environ.get("GCP_PROJECT", "").lower()
    if _PROD_MARKER_RE.search(gcp_project):
        return True

    return False


def env_key_override_enabled() -> bool:
    """Check whether the MCA_ALLOW_ENV_KEYS_IN_PROD escape hatch is set.

    Separate from :func:`is_production_environment` so callers that detect
    production through other channels can still honor the override (e.g.
    for logging purposes).

    Returns:
        True if MCA_ALLOW_ENV_KEYS_IN_PROD is set to a truthy value.
    """
    return _str_to_bool(os.environ.get("MCA_ALLOW_ENV_KEYS_IN_PROD", ""))
