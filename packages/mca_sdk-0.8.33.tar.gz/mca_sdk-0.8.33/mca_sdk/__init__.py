"""MCA SDK - Model Collector Agent SDK for OpenTelemetry instrumentation.

This SDK simplifies model instrumentation by providing schema validation,
buffering, and resilience features while reducing boilerplate code from
170+ lines to ~10 lines.

Example:
    >>> from mca_sdk import MCAClient
    >>>
    >>> client = MCAClient(
    ...     service_name="readmission-model",
    ...     model_id="mdl-001",
    ...     team_name="clinical-ai"
    ... )
    >>>
    >>> def predict(data):
    ...     with client.trace("model.predict"):
    ...         result = model.predict(data)
    ...         client.record_prediction(data, result, latency=0.15)
    ...         return result
    >>>
    >>> client.shutdown()
"""

from .version import __version__

from .core import MCAClient
from .config import MCAConfig
from .core.providers import (
    LATENCY_SHORT_TAIL_BOUNDARIES,
    LATENCY_LONG_TAIL_BOUNDARIES,
    DEFAULT_HISTOGRAM_BOUNDARY_VIEWS,
)
from .registry import RegistryClient, ModelConfig, DeploymentConfig
from .security.encryption import QueueEncryption, EncryptionManager
from .security.migration import migrate_queue_to_encrypted, verify_encrypted_queue
from .autolog import autolog
from .utils.exceptions import (
    MCASDKError,
    ConfigurationError,
    RegistryError,
    RegistryConnectionError,
    RegistryConfigNotFoundError,
    RegistryAuthError,
    StaleConfigError,
    ValidationError,
    BufferingError,
    SecurityError,
    CertificateError,
    CertificateLoadError,
    CertificateValidationError,
    CertificateExpiredError,
    CertificateNotLoadedError,
)

__all__ = [
    "MCAClient",
    "MCAConfig",
    "LATENCY_SHORT_TAIL_BOUNDARIES",
    "LATENCY_LONG_TAIL_BOUNDARIES",
    "DEFAULT_HISTOGRAM_BOUNDARY_VIEWS",
    "RegistryClient",
    "ModelConfig",
    "DeploymentConfig",
    "QueueEncryption",
    "EncryptionManager",
    "migrate_queue_to_encrypted",
    "verify_encrypted_queue",
    "autolog",
    "MCASDKError",
    "ConfigurationError",
    "RegistryError",
    "RegistryConnectionError",
    "RegistryConfigNotFoundError",
    "RegistryAuthError",
    "StaleConfigError",
    "ValidationError",
    "BufferingError",
    "SecurityError",
    "CertificateError",
    "CertificateLoadError",
    "CertificateValidationError",
    "CertificateExpiredError",
    "CertificateNotLoadedError",
    "__version__",
]
