"""Secret redaction filter for MCA SDK telemetry attribute values (story 6-32).

Masks credential material (API tokens, passwords, bearer tokens, API keys,
JWTs, PEM private-key blocks, ``sk-*`` OpenAI-style tokens) that callers pass
via ``**attributes`` to ``record_*`` methods, before those values reach OTel
span attributes, metric attribute dicts, or HIPAA audit-log extras.

Unlike the PHI filter (story 6-31), which matches by *value content*, this
filter matches on both axes:

  1. **Key-name match** (O(1) suffix/prefix check). If the attribute key
     looks like a credential holder (e.g. ``api_token``, ``password``,
     ``bearer_authorization``, ``*_secret``), the value is replaced with
     ``[REDACTED:SECRET]`` regardless of the value's shape.

  2. **Value-shape match** (compiled regex, gated by length + charset). If
     the value matches a known credential format (OpenAI ``sk-*`` tokens,
     JWT ``eyJ*`` three-part payloads, PEM ``-----BEGIN ... PRIVATE KEY-----``
     blocks), only the matched credential substring is replaced, preserving
     surrounding benign context.

Key-name matching recurses into nested dictionaries so credentials buried in
nested structures (e.g. ``{"context": {"password": "secret"}}``) are caught.

Ordering: the SDK runs the secret filter **before** the PHI filter inside
``TelemetryAttributeValidator.validate``. Secret detection is cheaper (short
key suffix test plus a short regex over bounded-length strings) and it is
always safe to run first: a value already replaced with ``[REDACTED:SECRET]``
contains no PHI pattern that the PHI filter would further mutate.

On redaction the filter logs a WARNING naming the *key only* (never the
value). Warnings are deduplicated per-key within the process lifecycle to
prevent log spam in high-throughput pipelines.

Opt-out: set env var ``MCA_DISABLE_SECRET_FILTER=true`` for test fixtures
that must inspect raw credential material (e.g. negative tests asserting
that production code never imports ``_testing.py``). Never expose this as a
kwarg on ``record_*`` methods.

Non-goals:

  - This filter does NOT inspect ``input_data`` or ``output`` payloads;
    ``_sanitize_data_recursive`` in ``core/client.py`` already handles those.
  - This filter does NOT replace caller-side sanitization. CLAUDE.md is
    explicit that credential hygiene remains an application responsibility;
    this is a defense-in-depth net.
"""

from __future__ import annotations

import logging
import os
import re
from typing import Any, Dict, List, Set, Tuple

logger = logging.getLogger(__name__)

# Attribute key names that unambiguously hold credential material. Matching
# is case-insensitive and suffix/substring based so callers cannot bypass
# with ``user_password``, ``app_api_token``, ``HTTP_AUTHORIZATION``, etc.
#
# Ordered by expected frequency so the first hit short-circuits quickly.
_SECRET_KEY_SUBSTRINGS: Tuple[str, ...] = (
    "password",
    "passwd",
    "secret",
    "token",
    "apikey",
    "api_key",
    "authorization",
    "bearer",
    "credential",
    "private_key",
    "access_key",
    "client_secret",
)

# Keys that *contain* a secret-substring but are documented non-sensitive
# identifiers. These must short-circuit the key-pattern check so the SDK
# does not mask legitimate operational fields.
#
# ``prediction_id`` contains "token" no -- but "id" fields like session_id
# could in theory match "session_id" -> no substring match. These are kept
# for future-proofing if substring list grows to include "id" patterns.
# All entries are stored lowercased; comparison is always case-insensitive.
_SECRET_KEY_ALLOWLIST: frozenset[str] = frozenset(
    {
        "prediction_id",
        "association_id",
        "user_id",
        "session_id",
        "request_id",
        "trace_id",
        "span_id",
    }
)

# Value-shape patterns. Each must be bounded (no catastrophic backtracking)
# and must match formats that are unambiguous enough that false positives
# on ML telemetry are acceptable.
#
# - ``sk-``: OpenAI / Anthropic / similar "sk-" prefix with >=20 url-safe
#   chars after the dash. Commonly 48+ chars in practice; 20 is the floor
#   to reject short operational IDs that happen to start with ``sk-``.
#   Trailing boundary uses lookahead to handle base64url padding (``=``).
# - JWT: three base64url segments separated by dots; the first must start
#   with ``eyJ`` which is the base64 of ``{"`` (the opening of a JWT header
#   JSON object). Minimum segment lengths guard against false positives.
#   Trailing boundary uses lookahead to handle padding characters.
# - PEM: the full ``-----BEGIN ... PRIVATE KEY-----`` block through to
#   ``-----END ... PRIVATE KEY-----``. Uses DOTALL-compatible ``[\s\S]``
#   to match across newlines within the block.
_SECRET_VALUE_PATTERN = re.compile(
    r"(?P<sk>\bsk-[A-Za-z0-9_\-]{20,}[A-Za-z0-9_\-=]*(?=[^A-Za-z0-9_\-=]|$))"
    r"|(?P<jwt>\beyJ[A-Za-z0-9_\-=]{8,}\.[A-Za-z0-9_\-=]{8,}\.[A-Za-z0-9_\-=]{8,}(?=[^A-Za-z0-9_\-=.]|$))"
    r"|(?P<pem>-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]+?-----END [A-Z ]*PRIVATE KEY-----)"
)

_REDACTION_MARKER = "[REDACTED:SECRET]"

_DISABLE_ENV = "MCA_DISABLE_SECRET_FILTER"

# Track keys that have already triggered a warning in this process lifecycle
# to prevent unbounded log spam in high-throughput pipelines.
_warned_keys: Set[str] = set()


def _reset_warned_keys() -> None:
    """Reset the warned-keys deduplication set (for testing only)."""
    _warned_keys.clear()


def is_disabled() -> bool:
    """Return True when the caller has set MCA_DISABLE_SECRET_FILTER to a truthy value."""
    return os.environ.get(_DISABLE_ENV, "").lower() in ("1", "true", "yes")


def _key_matches_secret(key: str) -> bool:
    """Return True when ``key`` looks like a credential holder.

    Case-insensitive substring match against ``_SECRET_KEY_SUBSTRINGS``,
    short-circuited by the non-sensitive allowlist (also case-insensitive).
    """
    key_lower = key.lower()
    if key_lower in _SECRET_KEY_ALLOWLIST:
        return False
    for fragment in _SECRET_KEY_SUBSTRINGS:
        if fragment in key_lower:
            return True
    return False


def _value_matches_secret(value: str) -> bool:
    """Return True when ``value`` matches a known credential shape."""
    return _SECRET_VALUE_PATTERN.search(value) is not None


def _redact_secret_substrings(value: str) -> Tuple[str, bool]:
    """Replace only matched credential substrings, preserving surrounding context.

    Returns the (possibly modified) string and whether any substitution occurred.
    """
    result, count = _SECRET_VALUE_PATTERN.subn(_REDACTION_MARKER, value)
    return result, count > 0


def _redact_value_in_place(
    value: Any, key: str | None = None, _seen: "set[int] | None" = None
) -> Tuple[Any, bool]:
    """Apply key-name and value-shape redaction to a single attribute value.

    Recurses into list/tuple/dict so credentials buried inside nested
    OpenTelemetry array/map attributes cannot bypass redaction. For nested
    dictionaries, the key name of each entry is checked against
    ``_key_matches_secret`` so that credentials keyed by sensitive names
    (e.g. ``{"context": {"password": "secret"}}``) are caught regardless
    of value shape.

    Non-string primitives (int, float, bool) pass through unchanged -- no
    secret shape expresses as those types.

    Objects that are not recognized primitives/collections are stringified
    and the value-shape regex is run over the string representation to catch
    credentials exposed through custom ``__str__``/``__repr__`` serialization.

    ``_seen`` tracks container ``id()`` values already visited on the current
    recursion path so circular references (e.g. ``d['self'] = d``) cannot
    exhaust the call stack. Circular containers are returned unchanged;
    downstream validation (see ``TelemetryAttributeValidator._has_circular_ref``)
    is responsible for rejecting or placeholder-replacing them.
    """
    # If the key itself is a secret-holder, redact the entire value wholesale
    if key is not None and _key_matches_secret(key):
        return _REDACTION_MARKER, True

    if isinstance(value, str):
        return _redact_secret_substrings(value)

    if isinstance(value, (int, float, bool)):
        return value, False

    if isinstance(value, (list, tuple, dict)):
        if _seen is None:
            _seen = set()
        obj_id = id(value)
        if obj_id in _seen:
            return value, False
        _seen.add(obj_id)
        try:
            if isinstance(value, list):
                changed = False
                new_list: List[Any] = []
                for item in value:
                    redacted, item_changed = _redact_value_in_place(item, None, _seen)
                    changed = changed or item_changed
                    new_list.append(redacted)
                return (new_list if changed else value), changed
            if isinstance(value, tuple):
                changed = False
                new_items: List[Any] = []
                for item in value:
                    redacted, item_changed = _redact_value_in_place(item, None, _seen)
                    changed = changed or item_changed
                    new_items.append(redacted)
                return (tuple(new_items) if changed else value), changed
            # dict -- check nested keys for secret-name matches
            changed = False
            new_dict: Dict[Any, Any] = {}
            for k, v in value.items():
                redacted, v_changed = _redact_value_in_place(
                    v, k if isinstance(k, str) else None, _seen
                )
                changed = changed or v_changed
                new_dict[k] = redacted
            return (new_dict if changed else value), changed
        finally:
            _seen.discard(obj_id)

    # Unrecognized object type: stringify and run value-shape regex to catch
    # credentials exposed through custom __str__/__repr__ or __dict__ attrs.
    try:
        # Try __dict__ first for richer inspection (dataclasses, Pydantic models)
        if hasattr(value, "__dict__") and value.__dict__:
            dict_repr = value.__dict__
            redacted_dict, dict_changed = _redact_value_in_place(dict_repr, None, _seen)
            if dict_changed:
                # Return the redacted dict representation since we cannot
                # reconstruct the original object safely
                return redacted_dict, True

        # Fall back to string representation
        str_repr = str(value)
        redacted_str, str_changed = _redact_secret_substrings(str_repr)
        if str_changed:
            return redacted_str, True
    except Exception:
        # If stringification fails, we cannot inspect; return as-is.
        # Downstream serialization will handle or reject the object.
        pass

    return value, False


def filter_attributes(attributes: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of ``attributes`` with credential material redacted.

    Redaction rules (applied in order per-attribute):

      1. If the key name matches ``_SECRET_KEY_SUBSTRINGS`` and is not on
         the allowlist, the entire value is replaced with the redaction
         marker string, regardless of original type.
      2. Otherwise, if the value (or any nested string inside a list/tuple/
         dict value) matches a secret-shape pattern, only the matched
         credential substring is replaced, preserving surrounding context.
      3. For nested dictionaries, key-name matching is applied recursively
         at every level.

    On redaction a WARNING is logged with the *key name only*, deduplicated
    per-key within the process lifecycle to prevent log spam. The original
    ``attributes`` dict is returned unchanged when no match is found,
    avoiding dict churn on the hot path. Opt-out honored via
    ``MCA_DISABLE_SECRET_FILTER``.
    """
    if is_disabled() or not attributes:
        return attributes

    out: Dict[str, Any] = attributes
    allocated = False
    redacted_keys: List[str] = []

    for key, value in attributes.items():
        if _key_matches_secret(key):
            if not allocated:
                out = dict(attributes)
                allocated = True
            out[key] = _REDACTION_MARKER
            redacted_keys.append(key)
            continue

        redacted_value, changed = _redact_value_in_place(value, key)
        if changed:
            if not allocated:
                out = dict(attributes)
                allocated = True
            out[key] = redacted_value
            redacted_keys.append(key)

    if redacted_keys:
        # Deduplicate warnings: only log each key once per process lifecycle
        new_keys = [k for k in redacted_keys if k not in _warned_keys]
        if new_keys:
            _warned_keys.update(new_keys)
            logger.warning(
                "MCA SDK redacted credential material from telemetry attribute(s): %s. "
                "Applications must sanitize credentials before passing attributes to "
                "record_* methods (see CLAUDE.md).",
                new_keys,
            )

    return out
