"""Test-only utilities for ``mca_sdk.security``.

WARNING:
    Never import this module from production code. It exists solely to give
    the test suite controlled access to singleton state (e.g. the
    :class:`SecretManagerClient` instance) so that tests can run in
    isolation. Importing it in a live service risks tearing down shared
    state that callers assume is stable.
"""

import mca_sdk.security.secret_manager as _sm_module


def reset_secret_manager_for_testing() -> None:
    """Reset the SecretManagerClient singleton for test isolation.

    Clears the module-level singleton so each test starts fresh.
    Never import or use this function in production code.
    """
    _sm_module._singleton_client = None
