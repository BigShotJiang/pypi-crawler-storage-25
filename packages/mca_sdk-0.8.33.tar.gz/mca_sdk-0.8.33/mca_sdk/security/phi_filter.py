"""PHI redaction filter for MCA SDK telemetry attribute values (story 6-31).

Applies a compiled regex across string values in the `**attributes` dict
passed to `record_*` methods, replacing SSN / MRN / DOB patterns with
typed redaction markers before the attributes reach OTel spans, metric
attribute dicts, or audit-log extras.

DISABLED BY DEFAULT. PHI sanitization is the caller's responsibility per
CLAUDE.md ("PHI Masking is Application Responsibility"). This module is
retained as an opt-in defense-in-depth utility for callers who want a
backstop on top of their own sanitization.

Opt-in: set ``MCA_ENABLE_PHI_FILTER=true`` (or ``1`` / ``yes`` / ``on``)
to enable redaction. The legacy double-negative env var
``MCA_DISABLE_PHI_FILTER=false`` is also accepted for backward
compatibility but emits a DeprecationWarning. Unrecognized values raise
``ConfigurationError`` rather than being silently treated as falsy. The
toggle is intentionally **not** exposed as a kwarg on `record_*` methods
to keep filter-state decisions out of per-call data-science code.

Pattern coverage (round-2 hardening, 2026-04-29):
  - SSN: ``\\d{3}-\\d{2}-\\d{4}`` and ``\\d{3} \\d{2} \\d{4}``. Bare
    ``\\d{9}`` is deliberately NOT matched: it collides with 9-digit
    numeric IDs/timestamps and would generate unacceptable false
    positives in ML telemetry.
  - MRN: ``MRN[\\s-]?\\d{6,}`` with ``re.IGNORECASE`` so ``mrn123456``,
    ``MRN 123456``, and ``MRN-123456`` all match.
  - DOB: ``MM/DD/YYYY``, ``MM-DD-YYYY``, and ISO ``YYYY-MM-DD``.

Recursion: ``filter_attributes`` descends into lists, tuples, and dicts
so PHI buried inside OpenTelemetry array attributes cannot bypass
redaction (round-2 fix for review finding #1).
"""

import logging
import os
import re
import warnings
from typing import Any, Dict, List, Tuple

from ..utils.exceptions import ConfigurationError

_PHI_PATTERN = re.compile(
    r"(?P<ssn>\b\d{3}[- ]\d{2}[- ]\d{4}\b)"
    r"|(?P<mrn>\bMRN[\s-]?\d{6,}\b)"
    r"|(?P<dob_iso>\b\d{4}-\d{2}-\d{2}\b)"
    r"|(?P<dob>\b\d{2}[/-]\d{2}[/-]\d{4}\b)",
    re.IGNORECASE,
)

# Shortest matchable pattern is 9 chars (MRN + 6 digits). Use 8 as a safe
# floor so sub-pattern-length strings short-circuit the regex engine.
_MIN_LEN = 8

_ENABLE_ENV = "MCA_ENABLE_PHI_FILTER"
_LEGACY_DISABLE_ENV = "MCA_DISABLE_PHI_FILTER"

_TRUE_VALUES = frozenset({"1", "true", "yes", "on"})
_FALSE_VALUES = frozenset({"0", "false", "no", "off", ""})


def _replace(match: "re.Match[str]") -> str:
    if match.group("ssn"):
        return "[REDACTED:SSN]"
    if match.group("mrn"):
        return "[REDACTED:MRN]"
    if match.group("dob") or match.group("dob_iso"):
        return "[REDACTED:DOB]"
    return match.group(0)


def redact_phi(value: str) -> str:
    """Return ``value`` with PHI substrings replaced by typed markers."""
    if len(value) < _MIN_LEN:
        return value
    return _PHI_PATTERN.sub(_replace, value)


def _parse_bool(env_name: str, raw: str) -> bool:
    """Parse a boolean env var value; raise ConfigurationError on garbage.

    Accepts the canonical truthy / falsy spellings only. Anything else
    (e.g. ``enable``, ``yes please``, ``maybe``) is rejected so callers
    learn immediately rather than silently get the wrong default.
    """
    normalized = raw.strip().lower()
    if normalized in _TRUE_VALUES:
        return True
    if normalized in _FALSE_VALUES:
        return False
    raise ConfigurationError(
        f"{env_name} must be one of "
        f"{sorted(_TRUE_VALUES | _FALSE_VALUES - {''})} (case-insensitive); "
        f"got {raw!r}."
    )


def is_enabled() -> bool:
    """Return True when the PHI filter should redact attribute values.

    Disabled by default; PHI sanitization is the caller's responsibility
    per CLAUDE.md. Two opt-in spellings are accepted:

    * ``MCA_ENABLE_PHI_FILTER`` (canonical, positive)
    * ``MCA_DISABLE_PHI_FILTER=false`` (legacy double-negative, deprecated;
      emits a ``DeprecationWarning`` on first read)

    If both env vars are set and disagree, the canonical
    ``MCA_ENABLE_PHI_FILTER`` wins and a ``DeprecationWarning`` is
    emitted naming the conflict.
    """
    enable_raw = os.environ.get(_ENABLE_ENV)
    legacy_raw = os.environ.get(_LEGACY_DISABLE_ENV)

    enable_set = enable_raw is not None
    legacy_set = legacy_raw is not None

    canonical_enabled = _parse_bool(_ENABLE_ENV, enable_raw) if enable_raw is not None else False
    legacy_enabled = (
        (not _parse_bool(_LEGACY_DISABLE_ENV, legacy_raw)) if legacy_raw is not None else False
    )

    if legacy_set and enable_set and canonical_enabled != legacy_enabled:
        warnings.warn(
            f"{_LEGACY_DISABLE_ENV} (deprecated) disagrees with "
            f"{_ENABLE_ENV}; canonical {_ENABLE_ENV} wins. "
            f"Unset {_LEGACY_DISABLE_ENV} to silence this warning.",
            DeprecationWarning,
            stacklevel=2,
        )
    elif legacy_set:
        warnings.warn(
            f"{_LEGACY_DISABLE_ENV} is deprecated; use "
            f"{_ENABLE_ENV}=true to enable the PHI filter instead. "
            "The legacy variable will be removed in a future major release.",
            DeprecationWarning,
            stacklevel=2,
        )

    if enable_set:
        return canonical_enabled
    if legacy_set:
        return legacy_enabled
    return False


def is_disabled() -> bool:
    """Backward-compat shim for callers that gate on ``not is_disabled()``.

    Prefer :func:`is_enabled`. Retained because external callers may
    have imported this helper before the default flipped; semantics are
    preserved (returns ``True`` when the filter should not run).
    """
    return not is_enabled()


# Process-scoped flag so the disabled-state warning fires exactly once per
# Python process even when many MCAClient instances are constructed (one
# per model). The constant is module-private; tests reset it via the
# helper below.
_DISABLED_WARNING_EMITTED = False


def warn_if_disabled(logger: "logging.Logger") -> None:
    """Emit a one-shot WARNING when the PHI filter is off.

    Called from ``MCAClient.__init__`` so operators learn at process start
    that PHI redaction is the application's responsibility. Idempotent
    across MCAClient instances in a single Python process.
    """
    global _DISABLED_WARNING_EMITTED
    if _DISABLED_WARNING_EMITTED or is_enabled():
        return
    logger.warning(
        "MCA SDK PHI attribute filter is DISABLED (default). "
        "PHI sanitization is the caller's responsibility per CLAUDE.md "
        '("PHI Masking is Application Responsibility"). To enable the '
        "optional defense-in-depth filter, set %s=true. To silence this "
        "warning without enabling the filter, the caller must explicitly "
        "acknowledge by sanitizing attributes before passing them to "
        "record_* methods.",
        _ENABLE_ENV,
    )
    _DISABLED_WARNING_EMITTED = True


def _reset_disabled_warning_for_tests() -> None:
    """Test-only: re-arm the one-shot warning so each test can observe it."""
    global _DISABLED_WARNING_EMITTED
    _DISABLED_WARNING_EMITTED = False


def _redact_any(value: Any, _seen: "set[int] | None" = None) -> Tuple[Any, bool]:
    """Return (possibly-redacted value, changed?). Recurses into list/tuple/dict.

    ``_seen`` tracks container ``id()`` values already visited on the current
    recursion path so circular references (e.g. ``d['self'] = d``) cannot
    exhaust the call stack. Circular containers are returned unchanged.
    """
    if isinstance(value, str):
        if len(value) < _MIN_LEN:
            return value, False
        out = _PHI_PATTERN.sub(_replace, value)
        return out, out != value
    if isinstance(value, (list, tuple, dict)):
        if _seen is None:
            _seen = set()
        obj_id = id(value)
        if obj_id in _seen:
            # Circular reference; leave the cycle-forming container untouched.
            return value, False
        _seen.add(obj_id)
        try:
            if isinstance(value, list):
                changed = False
                new_list: List[Any] = []
                for item in value:
                    redacted_item, item_changed = _redact_any(item, _seen)
                    changed = changed or item_changed
                    new_list.append(redacted_item)
                return (new_list if changed else value), changed
            if isinstance(value, tuple):
                changed = False
                new_items: List[Any] = []
                for item in value:
                    redacted_item, item_changed = _redact_any(item, _seen)
                    changed = changed or item_changed
                    new_items.append(redacted_item)
                return (tuple(new_items) if changed else value), changed
            # dict
            changed = False
            new_dict: Dict[Any, Any] = {}
            for k, v in value.items():
                redacted_v, v_changed = _redact_any(v, _seen)
                changed = changed or v_changed
                new_dict[k] = redacted_v
            return (new_dict if changed else value), changed
        finally:
            _seen.discard(obj_id)
    return value, False


def filter_attributes(attributes: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of ``attributes`` with PHI redacted from values.

    Recurses into lists, tuples, and dicts so PHI strings buried inside
    OpenTelemetry array attributes cannot bypass redaction. Non-recursive
    primitives (int, float, bool) pass through unchanged — PHI patterns
    cannot express as those types. The original dict is returned when no
    match is found, avoiding dict churn on the hot path.
    """
    if not is_enabled() or not attributes:
        return attributes

    out: Dict[str, Any] = attributes
    allocated = False
    for k, v in attributes.items():
        redacted, changed = _redact_any(v)
        if changed:
            if not allocated:
                out = dict(attributes)
                allocated = True
            out[k] = redacted
    return out
