"""Shared gen_ai.* attribute builders for Langfuse GENERATION observations.

Used by both MCALiteLLMCallback and MCAClient.record_llm_generation() so both
code paths emit the same OpenTelemetry semantic-convention attributes that
Langfuse recognizes when minting GENERATION-type observations.
"""

import math
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple


def extract_provider(model: str) -> str:
    """Derive a provider string from a model identifier.

    Handles LiteLLM-style ``provider/model`` prefixes and common commercial
    model prefixes. Returns ``"unknown"`` when no mapping can be inferred.
    """
    if not model:
        return "unknown"

    if "/" in model:
        return model.split("/")[0]

    model_lower = model.lower()
    if model_lower.startswith("gpt"):
        return "openai"
    if model_lower.startswith("claude"):
        return "anthropic"
    if model_lower.startswith("gemini"):
        return "google"
    if model_lower.startswith("llama"):
        return "meta"
    if model_lower.startswith("mistral"):
        return "mistral"

    return "unknown"


def build_request_attributes(
    model: str,
    provider: Optional[str] = None,
    operation: str = "chat",
    model_id: Optional[str] = None,
    **request_params: Any,
) -> Dict[str, Any]:
    """Build span attributes for the start of an LLM request.

    Sets the ``gen_ai.*`` keys Langfuse uses to promote a span to a
    GENERATION observation plus legacy ``llm.*`` / ``genai.*`` keys kept
    for backward compatibility with the existing LiteLLM callback.

    Args:
        model: Model identifier (e.g. ``gemini-2.0-flash-001``).
        provider: Provider / system name. Inferred from ``model`` when
            omitted.
        operation: Value for ``gen_ai.operation.name`` (e.g. ``chat``,
            ``text_completion``, ``embeddings``).
        model_id: Optional BHSF-registered model_id. When supplied, emitted
            as ``mca.model_id`` (SDK-internal namespace) and the legacy
            unprefixed ``model_id`` key kept for parity with the metric
            datapoint label that alert-policy-sync already consumes.
        **request_params: Optional request-time knobs. Recognized keys:
            ``temperature``, ``max_tokens``, ``top_p``, ``stream``.

    Returns:
        Dict of OpenTelemetry-compatible attribute values.
    """
    resolved_provider = provider or extract_provider(model)
    attrs: Dict[str, Any] = {
        "gen_ai.system": resolved_provider,
        "gen_ai.request.model": model,
        "gen_ai.operation.name": operation,
        "langfuse.observation.type": "generation",
        # Legacy llm.* keys retained for callers that still scan them.
        "llm.model": model,
        "llm.provider": resolved_provider,
    }

    if model_id is not None:
        attrs["mca.model_id"] = model_id
        attrs["model_id"] = model_id

    if "temperature" in request_params and request_params["temperature"] is not None:
        attrs["gen_ai.request.temperature"] = request_params["temperature"]
        attrs["llm.temperature"] = request_params["temperature"]
    if "max_tokens" in request_params and request_params["max_tokens"] is not None:
        attrs["gen_ai.request.max_tokens"] = request_params["max_tokens"]
        attrs["llm.max_tokens"] = request_params["max_tokens"]
    if "top_p" in request_params and request_params["top_p"] is not None:
        attrs["gen_ai.request.top_p"] = request_params["top_p"]
        attrs["llm.top_p"] = request_params["top_p"]
    if "stream" in request_params and request_params["stream"] is not None:
        attrs["llm.stream"] = request_params["stream"]

    return attrs


def build_usage_attributes(
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
    total_tokens: int = 0,
    cost_usd: Optional[float] = None,
    response_model: Optional[str] = None,
    model_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Build span attributes for token usage and response-time metadata.

    Returns the ``gen_ai.usage.*`` keys Langfuse reads plus legacy
    ``genai.tokens_*`` keys kept for backward compatibility. When
    ``model_id`` is supplied it is emitted as ``mca.model_id`` (SDK-internal
    namespace) plus the legacy unprefixed ``model_id`` key so usage spans
    join cleanly against metric datapoints.
    """
    resolved_total = total_tokens or (prompt_tokens + completion_tokens)
    attrs: Dict[str, Any] = {
        "gen_ai.usage.prompt_tokens": int(prompt_tokens or 0),
        "gen_ai.usage.completion_tokens": int(completion_tokens or 0),
        "gen_ai.usage.total_tokens": int(resolved_total or 0),
        # Legacy names still read by dashboards.
        "genai.tokens_prompt": int(prompt_tokens or 0),
        "genai.tokens_completion": int(completion_tokens or 0),
        "genai.tokens_total": int(resolved_total or 0),
    }
    if cost_usd is not None:
        attrs["gen_ai.usage.cost_usd"] = float(cost_usd)
        attrs["genai.cost_usd"] = float(cost_usd)
    if response_model:
        attrs["gen_ai.response.model"] = response_model
    if model_id is not None:
        attrs["mca.model_id"] = model_id
        attrs["model_id"] = model_id
    return attrs


# RAG / retrieval-observation attribute builder. Shared between
# MCAClient.record_retrieval (manual) and the future LangChain
# auto-instrumentation callback (story 1-20) so both paths emit the
# parallel-array contract pinned in docs/api-contracts.md section 9.2.

# Allowed enum values mirror the §9.2 contract. Kept here (not in the
# client module) so the future LangChain callback consumes the same
# enums without circular imports.
_ALLOWED_SCORE_METRICS = frozenset(
    {"cosine", "dot_product", "bm25", "reciprocal_rank", "llm_logprob", "unknown"}
)
_ALLOWED_SOURCE_SYSTEMS = frozenset({"dense", "sparse", "graph", "reranker", "other"})
_ALLOWED_RELEVANCE_VALUES = frozenset({"relevant", "partial", "irrelevant"})

# Cardinality cap from §9.2: never emit more than 50 documents per call.
RAG_DOCUMENT_CAP = 50


def _normalize_scores_min_max(scores: Sequence[float]) -> Tuple[List[float], bool]:
    """Min-max normalize a score array into [0, 1] per the §9.2 contract.

    Returns a tuple of (normalized_scores, all_constant_flag). When the
    input has no spread (max == min) the returned list is all 1.0 — the
    caller is expected to emit a debug log so operators can spot the
    degenerate case without the SDK silently dropping the trace.
    """
    if not scores:
        return [], False
    smax = max(scores)
    smin = min(scores)
    spread = smax - smin
    if spread == 0:
        return [1.0 for _ in scores], True
    return [(float(s) - smin) / spread for s in scores], False


def build_retrieval_attributes(
    query: str,
    documents: Sequence[Mapping[str, Any]],
    *,
    score_metric: str = "unknown",
    source_system: Optional[str] = None,
    sampling_rate: float = 1.0,
    parent_retrieval_id: Optional[str] = None,
    relevance: Optional[Sequence[str]] = None,
    model_id: Optional[str] = None,
    serialized_query: Optional[str] = None,
) -> Dict[str, Any]:
    """Build span attributes for a RAG retrieval observation.

    Implements the parallel-array contract in docs/api-contracts.md
    section 9.2: caps the document count at 50 (top-by-score), min-max
    normalizes scores into [0, 1], and emits enum metadata so the LLM
    Evaluator can recover the original score semantics. Used by both
    MCAClient.record_retrieval and the future LangChain callback so
    both paths produce identical attribute shapes.

    Args:
        query: Caller's query string. Already-serialized payloads can
            be passed via ``serialized_query`` to avoid double work.
        documents: Sequence of mappings with at least ``id`` and
            ``score`` keys. Order is significant only when truncation
            triggers (top-N by score).
        score_metric: Original scoring family. One of
            ``cosine`` / ``dot_product`` / ``bm25`` /
            ``reciprocal_rank`` / ``llm_logprob`` / ``unknown``.
        source_system: Optional retriever family for hybrid flows. One
            of ``dense`` / ``sparse`` / ``graph`` / ``reranker`` /
            ``other``.
        sampling_rate: Float in ``[0.0, 1.0]`` documenting the
            downstream sampling decision; SDK never drops spans on its
            own.
        parent_retrieval_id: Caller-supplied UUID grouping sibling
            ``rag.retrieval`` spans in hybrid retrievers.
        relevance: Optional parallel array of
            ``relevant`` / ``partial`` / ``irrelevant`` labels. Same
            length as ``documents`` if supplied.
        model_id: BHSF-registered model_id, mirrors the LLM-generation
            attribute shape.
        serialized_query: Pre-serialized query string (already passed
            through ``serialize_for_telemetry``). When omitted the
            caller's raw ``query`` is used directly.

    Returns:
        Dict of OpenTelemetry-compatible attribute values, ready to
        attach to a ``rag.retrieval`` span.

    Raises:
        ValueError: If score_metric / source_system / relevance values
            are out of the contract enum, if relevance length disagrees
            with documents, or if any score is non-finite.
    """
    if score_metric not in _ALLOWED_SCORE_METRICS:
        raise ValueError(f"score_metric={score_metric!r} not in {sorted(_ALLOWED_SCORE_METRICS)}")
    if source_system is not None and source_system not in _ALLOWED_SOURCE_SYSTEMS:
        raise ValueError(
            f"source_system={source_system!r} not in {sorted(_ALLOWED_SOURCE_SYSTEMS)}"
        )
    if not (0.0 <= float(sampling_rate) <= 1.0):
        raise ValueError(f"sampling_rate must be in [0.0, 1.0], got {sampling_rate}")

    # Score-range guard: any non-finite score is rejected up front so
    # the evaluator never has to defend against NaN / inf in the
    # parallel array.
    raw_scores: List[float] = []
    for idx, doc in enumerate(documents):
        score = doc.get("score")
        if score is None:
            raise ValueError(f"documents[{idx}] missing required 'score' field")
        try:
            score_float = float(score)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"documents[{idx}].score not coercible to float: {score!r}") from exc
        if not math.isfinite(score_float):
            raise ValueError(f"documents[{idx}].score must be finite, got {score_float!r}")
        raw_scores.append(score_float)

    # Relevance length guard before truncation so the caller learns
    # about the mismatch on the original arrays, not the truncated set.
    if relevance is not None and len(relevance) != len(documents):
        raise ValueError(f"relevance length {len(relevance)} != documents length {len(documents)}")
    if relevance is not None:
        for idx, label in enumerate(relevance):
            if label not in _ALLOWED_RELEVANCE_VALUES:
                raise ValueError(
                    f"relevance[{idx}]={label!r} not in {sorted(_ALLOWED_RELEVANCE_VALUES)}"
                )

    # Top-N truncation by score (descending) when the source set
    # exceeds the §9.2 cardinality cap. Stable for ties via the index.
    truncated = False
    indices: List[int] = list(range(len(documents)))
    if len(documents) > RAG_DOCUMENT_CAP:
        indices.sort(key=lambda i: (-raw_scores[i], i))
        indices = indices[:RAG_DOCUMENT_CAP]
        truncated = True

    selected_docs = [documents[i] for i in indices]
    selected_scores = [raw_scores[i] for i in indices]
    selected_relevance = [relevance[i] for i in indices] if relevance is not None else None

    normalized_scores, constant_score = _normalize_scores_min_max(selected_scores)

    ids: List[str] = []
    for idx, doc in enumerate(selected_docs):
        doc_id = doc.get("id")
        if doc_id is None:
            raise ValueError(f"documents[{idx}] missing required 'id' field")
        ids.append(str(doc_id))

    attrs: Dict[str, Any] = {
        "gen_ai.rag.query": serialized_query if serialized_query is not None else query,
        "gen_ai.rag.documents.count": len(selected_docs),
        "gen_ai.rag.documents.ids": ids,
        "gen_ai.rag.documents.scores": [float(s) for s in normalized_scores],
        "gen_ai.rag.documents.truncated": truncated,
        "gen_ai.rag.documents.score_metric": score_metric,
        "gen_ai.rag.sampling_rate": float(sampling_rate),
        "langfuse.observation.type": "retrieval",
    }
    if source_system is not None:
        attrs["gen_ai.rag.documents.source_system"] = source_system
    if parent_retrieval_id is not None:
        attrs["gen_ai.rag.parent_retrieval_id"] = str(parent_retrieval_id)
    if selected_relevance is not None:
        attrs["gen_ai.rag.documents.relevance"] = list(selected_relevance)
    if model_id is not None:
        attrs["mca.model_id"] = model_id
        attrs["model_id"] = model_id

    # Annotate the constant-score case so the caller can emit a debug
    # log without re-deriving it. Internal flag, not exposed as a span
    # attribute (would not match the §9.2 allow-list).
    attrs["__mca_internal_constant_score"] = constant_score
    return attrs
