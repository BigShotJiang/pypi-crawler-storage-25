#!/bin/bash
# Maven Dependency Resolution Test Script
# Creates a temporary Maven project to test MCA SDK dependency resolution

set -e

VERSION=${1:-0.3.0}

echo "========================================="
echo "MCA SDK Dependency Resolution Test"
echo "========================================="
echo ""
echo "Testing version: $VERSION"
echo ""

# Check if Maven is available
if ! command -v mvn &> /dev/null; then
    echo "❌ ERROR: Maven is not installed"
    exit 1
fi

# Create temporary directory
TEST_DIR=$(mktemp -d)
echo "Creating test project in: $TEST_DIR"

cd "$TEST_DIR"

# Create minimal pom.xml
cat > pom.xml <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.test</groupId>
    <artifactId>mca-sdk-test</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>11</maven.compiler.source>
        <maven.compiler.target>11</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <dependency>
            <groupId>com.bhsf.mca</groupId>
            <artifactId>mca-sdk-java</artifactId>
            <version>$VERSION</version>
        </dependency>
    </dependencies>
</project>
EOF

echo "✅ Test pom.xml created"
echo ""

# Create simple Java class that uses MCA SDK
mkdir -p src/main/java/com/test
cat > src/main/java/com/test/TestMCA.java <<'EOF'
package com.test;

import com.bhsf.mca.sdk.MCAClient;
import com.bhsf.mca.sdk.RecordPredictionRequest;

public class TestMCA {
    public static void main(String[] args) {
        System.out.println("Testing MCA SDK Java...");

        try (MCAClient client = new MCAClient.Builder()
                .serviceName("test-model")
                .modelId("test-001")
                .build()) {

            client.recordPrediction(RecordPredictionRequest.builder()
                    .latency(0.15)
                    .attribute("test", "true")
                    .build());

            System.out.println("✅ MCA SDK loaded and executed successfully");
        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
}
EOF

echo "✅ Test Java class created"
echo ""

# Test 1: Dependency resolution
echo "Test 1: Resolving dependencies..."
if mvn dependency:resolve -q; then
    echo "✅ Dependency resolution successful"
else
    echo "❌ Dependency resolution failed"
    echo "   Version $VERSION may not be available in Maven Central yet"
    echo "   Wait 2-4 hours after publishing, then try again"
    rm -rf "$TEST_DIR"
    exit 1
fi

echo ""

# Test 2: Dependency tree
echo "Test 2: Checking transitive dependencies..."
echo ""
mvn dependency:tree | grep -A20 "com.bhsf.mca:mca-sdk-java" || true

echo ""

# Test 3: Compilation
echo "Test 3: Compiling test class..."
if mvn compile -q; then
    echo "✅ Compilation successful"
else
    echo "❌ Compilation failed"
    rm -rf "$TEST_DIR"
    exit 1
fi

echo ""

# Test 4: Check OpenTelemetry transitive dependencies
echo "Test 4: Verifying OpenTelemetry dependencies..."
OTEL_COUNT=$(mvn dependency:tree | grep -c "io.opentelemetry" || true)

if [ "$OTEL_COUNT" -gt 0 ]; then
    echo "✅ OpenTelemetry transitive dependencies found ($OTEL_COUNT)"
else
    echo "⚠️  No OpenTelemetry dependencies found (may be shaded)"
fi

echo ""

# Test 5: Version range (if not a specific version)
if [[ ! "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "Test 5: Skipping version range test (specific version provided)"
else
    echo "Test 5: Testing version range..."

    # Extract major.minor from version (e.g., 0.3 from 0.3.0)
    MAJOR_MINOR=$(echo "$VERSION" | cut -d. -f1,2)
    NEXT_MAJOR=$(echo "$VERSION" | cut -d. -f1 | awk '{print $1+1}')

    # Update pom.xml with version range
    sed -i.bak "s/<version>$VERSION<\/version>/<version>[$VERSION,$NEXT_MAJOR.0)<\/version>/" pom.xml

    if mvn dependency:resolve -q; then
        RESOLVED_VERSION=$(mvn dependency:list | grep "com.bhsf.mca:mca-sdk-java" | sed 's/.*:\([0-9.]*\):.*/\1/')
        echo "✅ Version range resolved to: $RESOLVED_VERSION"
    else
        echo "⚠️  Version range resolution failed (may need multiple published versions)"
    fi

    # Restore original pom.xml
    mv pom.xml.bak pom.xml
fi

echo ""

# Cleanup
echo "Cleaning up test directory..."
rm -rf "$TEST_DIR"

echo ""
echo "========================================="
echo "Test Results Summary"
echo "========================================="
echo "✅ All tests passed for version $VERSION"
echo ""
echo "The MCA SDK Java $VERSION is properly published and can be used as a Maven dependency:"
echo ""
echo "  <dependency>"
echo "      <groupId>com.bhsf.mca</groupId>"
echo "      <artifactId>mca-sdk-java</artifactId>"
echo "      <version>$VERSION</version>"
echo "  </dependency>"
echo ""
