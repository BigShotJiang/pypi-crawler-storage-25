package com.bhsf.mca.sdk.exceptions;

import com.bhsf.mca.sdk.security.CredentialMasking;
import java.util.regex.Pattern;

/**
 * Base exception for all MCA SDK errors.
 *
 * <p>SECURITY: Overrides getMessage() to sanitize sensitive data (tokens, passwords)
 * from error messages before they appear in tracebacks or logs.
 *
 * <p>Use this to catch any SDK-related exception.
 *
 * <pre>{@code
 * try {
 *     client = new MCAClient.Builder().build();
 * } catch (MCAException e) {
 *     logger.error("SDK error: {}", e.getMessage());
 * }
 * }</pre>
 */
public class MCAException extends RuntimeException {

    public MCAException(String message) {
        super(message);
    }

    public MCAException(String message, Throwable cause) {
        super(message, cause);
    }

    // Partial masking patterns: preserve prefix, replace remainder with ***
    private static final Pattern AWS_PARTIAL = Pattern.compile("\\b(AKIA|ASIA)([0-9A-Z]{16})\\b");
    private static final Pattern GCP_PARTIAL = Pattern.compile("\\bAIzaSy([A-Za-z0-9_-]{33})\\b");
    private static final Pattern JWT_PARTIAL = Pattern.compile(
        "\\beyJ[A-Za-z0-9_-]{10,5000}\\.eyJ[A-Za-z0-9_-]{10,5000}\\.[A-Za-z0-9_-]{10,5000}\\b");
    private static final Pattern BEARER_PARTIAL = Pattern.compile(
        "Bearer\\s+([A-Za-z0-9._+/=-]{20,})");

    /**
     * Returns sanitized error message with credentials partially masked.
     *
     * <p>Preserves credential type prefixes (AKIA, AIzaSy, eyJ, Bearer) while
     * masking the secret portion with *** to allow identification without exposure.
     *
     * @return sanitized error message
     */
    @Override
    public String getMessage() {
        String message = super.getMessage();
        if (message == null) {
            return null;
        }

        // Sanitize registry token from environment
        String registryToken = System.getenv("MCA_REGISTRY_TOKEN");
        if (registryToken != null && message.contains(registryToken)) {
            message = message.replace(registryToken,
                CredentialMasking.maskRegistryToken(registryToken));
        }

        // Partial masking: preserve prefix so callers can identify credential type
        message = AWS_PARTIAL.matcher(message).replaceAll(mr -> mr.group(1) + "***");
        message = GCP_PARTIAL.matcher(message).replaceAll("AIzaSy***");
        message = JWT_PARTIAL.matcher(message).replaceAll("eyJ***");
        message = BEARER_PARTIAL.matcher(message).replaceAll("Bearer ***");

        return message;
    }
}
