package com.bhsf.mca.sdk.exporters;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import com.google.auth.Credentials;
import com.google.cloud.trace.v2.TraceServiceClient;
import com.google.cloud.trace.v2.TraceServiceSettings;
import com.google.devtools.cloudtrace.v2.AttributeValue;
import com.google.devtools.cloudtrace.v2.ProjectName;
import com.google.devtools.cloudtrace.v2.Span;
import com.google.devtools.cloudtrace.v2.TruncatableString;
import com.google.protobuf.Timestamp;
import com.google.rpc.Status;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.sdk.common.CompletableResultCode;
import io.opentelemetry.sdk.trace.data.EventData;
import io.opentelemetry.sdk.trace.data.LinkData;
import io.opentelemetry.sdk.trace.data.SpanData;
import io.opentelemetry.sdk.trace.export.SpanExporter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Implementation of GCP Cloud Trace exporter with strongly-typed API access.
 *
 * <p>This class is only loaded when the google-cloud-trace library is available.
 * It provides compile-time type safety while supporting optional dependency patterns.
 *
 * <p><strong>Note:</strong> This class uses direct imports from the GCP Trace SDK. It will only
 * be instantiated if the optional dependency is present at runtime. Public access should be
 * through {@link GCPTraceExporterFactory} which handles availability checks.
 */
class GCPTraceExporterImpl implements SpanExporter {
    private static final Logger log = LoggerFactory.getLogger(GCPTraceExporterImpl.class);

    // GCP Cloud Trace limits
    private static final int MAX_SPAN_LINKS = 128;
    private static final int MAX_SPAN_EVENTS = 128;
    private static final int MAX_SPANS_PER_BATCH = 200;
    private static final int MAX_DISPLAY_NAME_LENGTH = 128;
    private static final int MAX_ATTRIBUTE_VALUE_LENGTH = 256;
    private static final int MAX_ATTRIBUTE_KEY_LENGTH = 128;
    private static final int MAX_STATUS_MESSAGE_LENGTH = 2048;
    private static final int MAX_EVENT_NAME_LENGTH = 256;

    // gRPC status codes (per gRPC spec)
    private static final int GRPC_STATUS_OK = 0;
    private static final int GRPC_STATUS_UNKNOWN = 2; // Used for ERROR

    private final TraceServiceClient client;
    private final String projectName;
    private final ReentrantLock exportLock;

    // Metrics for observability
    private long spansExportedTotal = 0;
    private long spansDroppedTotal = 0;
    private long exportAttemptsTotal = 0;
    private long exportFailuresTotal = 0;
    private long retriesTotal = 0;

    /**
     * Create GCP Cloud Trace exporter implementation.
     *
     * @param projectId GCP project ID
     * @param credentials Google Cloud credentials (passed as Object from factory)
     * @return GCPTraceExporterImpl instance
     * @throws ConfigurationException if validation fails
     * @throws IOException if TraceServiceClient cannot be created
     */
    static GCPTraceExporterImpl create(String projectId, Object credentials) throws IOException {
        // Validate credentials type
        if (!(credentials instanceof Credentials)) {
            throw new ConfigurationException(
                    "Invalid credentials type. Expected com.google.auth.Credentials from GCPAuthFactory");
        }

        return new GCPTraceExporterImpl(projectId, (Credentials) credentials);
    }

    /**
     * Private constructor.
     *
     * @param projectId GCP project ID
     * @param credentials Google Cloud credentials
     * @throws IOException if client creation fails
     */
    private GCPTraceExporterImpl(String projectId, Credentials credentials) throws IOException {
        validateProjectId(projectId);

        this.projectName = ProjectName.of(projectId).toString();
        this.exportLock = new ReentrantLock();

        // Initialize GCP Cloud Trace client
        TraceServiceSettings settings = TraceServiceSettings.newBuilder()
                .setCredentialsProvider(() -> credentials)
                .build();

        this.client = TraceServiceClient.create(settings);

        log.debug("GCP Cloud Trace exporter implementation created for project: {}", projectId);
    }

    @Override
    public CompletableResultCode export(Collection<SpanData> spans) {
        if (spans == null || spans.isEmpty()) {
            return CompletableResultCode.ofSuccess();
        }

        exportAttemptsTotal++;

        // Thread-safe export with lock
        exportLock.lock();
        try {
            // Split into batches if needed (GCP limit: 200 spans per request)
            List<List<SpanData>> batches = splitIntoBatches(new ArrayList<>(spans), MAX_SPANS_PER_BATCH);

            if (batches.size() > 1) {
                log.info("Splitting {} spans into {} batches (max {} spans per batch)",
                        spans.size(), batches.size(), MAX_SPANS_PER_BATCH);
            }

            // Export each batch with retry logic
            for (int i = 0; i < batches.size(); i++) {
                List<SpanData> batch = batches.get(i);
                boolean success = exportBatchWithRetry(batch, i + 1, batches.size());

                if (!success) {
                    exportFailuresTotal++;
                    return CompletableResultCode.ofFailure();
                }
            }

            return CompletableResultCode.ofSuccess();

        } catch (Exception e) {
            log.error("Unexpected error exporting spans to GCP Cloud Trace: {}", e.getMessage(), e);
            exportFailuresTotal++;
            return CompletableResultCode.ofFailure();
        } finally {
            exportLock.unlock();
        }
    }

    /**
     * Export a single batch with retry logic for transient errors.
     */
    private boolean exportBatchWithRetry(List<SpanData> batch, int batchNum, int totalBatches) {
        final int MAX_RETRIES = 3;
        final long BASE_DELAY_MS = 1000;

        for (int attempt = 0; attempt < MAX_RETRIES; attempt++) {
            try {
                // Convert OTel spans to Cloud Trace format
                List<Span> gcpSpans = convertSpans(batch);

                if (gcpSpans.isEmpty()) {
                    log.warn("No valid spans in batch {}/{} (all invalid)", batchNum, totalBatches);
                    return true;
                }

                // Write spans to Cloud Trace
                client.batchWriteSpans(projectName, gcpSpans);

                spansExportedTotal += gcpSpans.size();
                log.debug("Exported batch {}/{} ({} spans) to GCP Cloud Trace",
                        batchNum, totalBatches, gcpSpans.size());
                return true;

            } catch (Exception e) {
                // Check if error is retryable
                boolean retryable = isRetryableError(e);

                if (retryable && attempt < MAX_RETRIES - 1) {
                    retriesTotal++;
                    long delay = BASE_DELAY_MS * (long) Math.pow(2, attempt);
                    log.warn("Transient error exporting batch {}/{} (attempt {}/{}): {}. Retrying in {}ms",
                            batchNum, totalBatches, attempt + 1, MAX_RETRIES, e.getMessage(), delay);

                    try {
                        Thread.sleep(delay);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        log.error("Export retry interrupted");
                        return false;
                    }
                } else {
                    log.error("Failed to export batch {}/{} to GCP Cloud Trace after {} attempts: {}",
                            batchNum, totalBatches, attempt + 1, e.getMessage());
                    return false;
                }
            }
        }

        return false;
    }

    /**
     * Check if error is retryable (transient).
     *
     * <p>Note: String-based error detection is used because the GCP SDK wraps exceptions
     * in ApiException/StatusRuntimeException without exposing status codes in a
     * consistent way. This is a pragmatic approach used across GCP SDKs.
     */
    private boolean isRetryableError(Exception e) {
        String message = e.getMessage();
        if (message == null) {
            return false;
        }

        // Transient gRPC status codes that should be retried
        String messageLower = message.toLowerCase();
        return messageLower.contains("unavailable") ||
               messageLower.contains("deadline_exceeded") ||
               messageLower.contains("deadline exceeded") ||
               messageLower.contains("resource_exhausted") ||
               messageLower.contains("resource exhausted") ||
               messageLower.contains("internal") ||
               messageLower.contains("503") ||
               messageLower.contains("504");
    }

    /**
     * Convert OpenTelemetry spans to Cloud Trace format.
     */
    private List<Span> convertSpans(List<SpanData> spans) {
        List<Span> gcpSpans = new ArrayList<>();

        for (SpanData span : spans) {
            try {
                Span gcpSpan = convertSpan(span);
                if (gcpSpan != null) {
                    gcpSpans.add(gcpSpan);
                }
            } catch (Exception e) {
                log.warn("Failed to convert span: {}. Dropping span.", e.getMessage());
                spansDroppedTotal++;
            }
        }

        return gcpSpans;
    }

    /**
     * Convert a single OpenTelemetry span to Cloud Trace format.
     */
    private Span convertSpan(SpanData span) {
        // Validate span has required fields
        if (span.getSpanContext() == null || span.getTraceId().isEmpty()) {
            log.warn("Skipping span: missing context or trace ID");
            return null;
        }

        // Format trace and span IDs
        String traceId = span.getTraceId();
        String spanId = span.getSpanId();

        // Build span name: projects/{project}/traces/{trace_id}/spans/{span_id}
        String spanName = projectName + "/traces/" + traceId + "/spans/" + spanId;

        // Truncate display name to 128 chars
        String displayName = span.getName();
        if (displayName.length() > MAX_DISPLAY_NAME_LENGTH) {
            log.warn("Span name '{}...' truncated from {} to {} chars",
                    displayName.substring(0, 40), displayName.length(), MAX_DISPLAY_NAME_LENGTH);
            displayName = displayName.substring(0, MAX_DISPLAY_NAME_LENGTH);
        }

        // Convert timestamps
        Timestamp startTime = convertTimestamp(span.getStartEpochNanos());
        Timestamp endTime = convertTimestamp(span.getEndEpochNanos());

        // Build span
        Span.Builder spanBuilder = Span.newBuilder()
                .setName(spanName)
                .setSpanId(spanId)
                .setDisplayName(TruncatableString.newBuilder().setValue(displayName).build())
                .setStartTime(startTime)
                .setEndTime(endTime);

        // Map span kind
        spanBuilder.setSpanKind(convertSpanKind(span.getKind()));

        // Map span status
        Status status = convertStatus(span.getStatus());
        if (status != null) {
            spanBuilder.setStatus(status);
        }

        // Convert attributes
        Span.Attributes attributes = convertAttributes(span.getAttributes());
        if (attributes != null) {
            spanBuilder.setAttributes(attributes);
        }

        // Set parent span ID
        if (span.getParentSpanContext() != null && span.getParentSpanContext().isValid()) {
            spanBuilder.setParentSpanId(span.getParentSpanContext().getSpanId());
        }

        // Convert links (max 128)
        if (!span.getLinks().isEmpty()) {
            Span.Links links = convertLinks(span.getLinks());
            if (links != null) {
                spanBuilder.setLinks(links);
            }
        }

        // Convert events (max 128)
        if (!span.getEvents().isEmpty()) {
            Span.TimeEvents timeEvents = convertEvents(span.getEvents());
            if (timeEvents != null) {
                spanBuilder.setTimeEvents(timeEvents);
            }
        }

        return spanBuilder.build();
    }

    /**
     * Convert OTel SpanKind to Cloud Trace SpanKind.
     */
    private Span.SpanKind convertSpanKind(SpanKind kind) {
        switch (kind) {
            case SERVER:
                return Span.SpanKind.SERVER;
            case CLIENT:
                return Span.SpanKind.CLIENT;
            case INTERNAL:
            case PRODUCER:
            case CONSUMER:
            default:
                return Span.SpanKind.SPAN_KIND_UNSPECIFIED;
        }
    }

    /**
     * Convert OTel Status to Cloud Trace Status.
     *
     * <p>Status code mapping (per gRPC spec):
     * <ul>
     *   <li>UNSET -> null (no status)</li>
     *   <li>OK -> 0 (GRPC_STATUS_OK)</li>
     *   <li>ERROR -> 2 (GRPC_STATUS_UNKNOWN)</li>
     * </ul>
     */
    private Status convertStatus(io.opentelemetry.sdk.trace.data.StatusData status) {
        if (status == null || status.getStatusCode() == StatusCode.UNSET) {
            return null;
        }

        // Map OTel StatusCode to gRPC status code
        int code = status.getStatusCode() == StatusCode.OK ? GRPC_STATUS_OK : GRPC_STATUS_UNKNOWN;
        Status.Builder statusBuilder = Status.newBuilder().setCode(code);

        if (status.getDescription() != null && !status.getDescription().isEmpty()) {
            String message = status.getDescription();
            if (message.length() > MAX_STATUS_MESSAGE_LENGTH) {
                log.warn("Status description truncated from {} to {} chars",
                        message.length(), MAX_STATUS_MESSAGE_LENGTH);
                message = message.substring(0, MAX_STATUS_MESSAGE_LENGTH);
            }
            statusBuilder.setMessage(message);
        }

        return statusBuilder.build();
    }

    /**
     * Convert OTel attributes to Cloud Trace attributes.
     */
    private Span.Attributes convertAttributes(io.opentelemetry.api.common.Attributes attributes) {
        if (attributes == null || attributes.isEmpty()) {
            return null;
        }

        Map<String, AttributeValue> attributeMap = new HashMap<>();
        int droppedCount = 0;

        attributes.forEach((key, value) -> {
            try {
                String attrKey = key.getKey();
                if (attrKey.length() > MAX_ATTRIBUTE_KEY_LENGTH) {
                    attrKey = attrKey.substring(0, MAX_ATTRIBUTE_KEY_LENGTH);
                }

                AttributeValue attrValue = convertAttributeValue(value);
                if (attrValue != null) {
                    attributeMap.put(attrKey, attrValue);
                }
            } catch (Exception e) {
                log.debug("Failed to convert attribute '{}': {}", key.getKey(), e.getMessage());
            }
        });

        return Span.Attributes.newBuilder()
                .putAllAttributeMap(attributeMap)
                .setDroppedAttributesCount(droppedCount)
                .build();
    }

    /**
     * Convert attribute value to Cloud Trace AttributeValue.
     *
     * <p>Handles scalar types and converts arrays/lists to comma-separated strings.
     */
    private AttributeValue convertAttributeValue(Object value) {
        if (value == null) {
            return null;
        }

        AttributeValue.Builder builder = AttributeValue.newBuilder();

        // Handle scalar types
        if (value instanceof Boolean) {
            builder.setBoolValue((Boolean) value);
        } else if (value instanceof Long) {
            builder.setIntValue((Long) value);
        } else if (value instanceof Integer) {
            builder.setIntValue((Integer) value);
        } else if (value instanceof Double) {
            // GCP Trace doesn't support double, convert to string
            builder.setStringValue(createTruncatableString(value.toString()));
        } else if (value instanceof Float) {
            // GCP Trace doesn't support float, convert to string
            builder.setStringValue(createTruncatableString(value.toString()));
        } else if (value instanceof List) {
            // Convert list to comma-separated string
            List<?> listValue = (List<?>) value;
            String stringValue = listValue.toString();
            builder.setStringValue(createTruncatableString(stringValue));
        } else if (value.getClass().isArray()) {
            // Convert array to string representation
            String stringValue = arrayToString(value);
            builder.setStringValue(createTruncatableString(stringValue));
        } else {
            // Default: convert to string
            String strValue = value.toString();
            builder.setStringValue(createTruncatableString(strValue));
        }

        return builder.build();
    }

    /**
     * Convert array to string representation.
     */
    private String arrayToString(Object array) {
        if (array instanceof boolean[]) {
            return java.util.Arrays.toString((boolean[]) array);
        } else if (array instanceof byte[]) {
            return java.util.Arrays.toString((byte[]) array);
        } else if (array instanceof short[]) {
            return java.util.Arrays.toString((short[]) array);
        } else if (array instanceof int[]) {
            return java.util.Arrays.toString((int[]) array);
        } else if (array instanceof long[]) {
            return java.util.Arrays.toString((long[]) array);
        } else if (array instanceof float[]) {
            return java.util.Arrays.toString((float[]) array);
        } else if (array instanceof double[]) {
            return java.util.Arrays.toString((double[]) array);
        } else if (array instanceof Object[]) {
            return java.util.Arrays.toString((Object[]) array);
        } else {
            return array.toString();
        }
    }

    /**
     * Create TruncatableString with length limit.
     */
    private TruncatableString createTruncatableString(String value) {
        if (value.length() > MAX_ATTRIBUTE_VALUE_LENGTH) {
            value = value.substring(0, MAX_ATTRIBUTE_VALUE_LENGTH);
        }
        return TruncatableString.newBuilder().setValue(value).build();
    }

    /**
     * Convert OTel links to Cloud Trace links.
     */
    private Span.Links convertLinks(List<LinkData> links) {
        List<Span.Link> gcpLinks = new ArrayList<>();
        int count = Math.min(links.size(), MAX_SPAN_LINKS);

        if (links.size() > MAX_SPAN_LINKS) {
            log.warn("Span has {} links, truncating to GCP limit of {}", links.size(), MAX_SPAN_LINKS);
        }

        for (int i = 0; i < count; i++) {
            LinkData link = links.get(i);
            try {
                Span.Link.Builder linkBuilder = Span.Link.newBuilder()
                        .setTraceId(link.getSpanContext().getTraceId())
                        .setSpanId(link.getSpanContext().getSpanId())
                        .setType(Span.Link.Type.TYPE_UNSPECIFIED);

                if (!link.getAttributes().isEmpty()) {
                    linkBuilder.setAttributes(convertAttributes(link.getAttributes()));
                }

                gcpLinks.add(linkBuilder.build());
            } catch (Exception e) {
                log.warn("Failed to convert span link: {}", e.getMessage());
            }
        }

        return Span.Links.newBuilder()
                .addAllLink(gcpLinks)
                .setDroppedLinksCount(Math.max(0, links.size() - MAX_SPAN_LINKS))
                .build();
    }

    /**
     * Convert OTel events to Cloud Trace time events.
     */
    private Span.TimeEvents convertEvents(List<EventData> events) {
        List<Span.TimeEvent> gcpEvents = new ArrayList<>();
        int count = Math.min(events.size(), MAX_SPAN_EVENTS);

        if (events.size() > MAX_SPAN_EVENTS) {
            log.warn("Span has {} events, truncating to GCP limit of {}", events.size(), MAX_SPAN_EVENTS);
        }

        for (int i = 0; i < count; i++) {
            EventData event = events.get(i);
            try {
                String eventName = event.getName();
                if (eventName.length() > MAX_EVENT_NAME_LENGTH) {
                    eventName = eventName.substring(0, MAX_EVENT_NAME_LENGTH);
                }

                Span.TimeEvent.Annotation.Builder annotationBuilder = Span.TimeEvent.Annotation.newBuilder()
                        .setDescription(TruncatableString.newBuilder().setValue(eventName).build());

                if (!event.getAttributes().isEmpty()) {
                    annotationBuilder.setAttributes(convertAttributes(event.getAttributes()));
                }

                Span.TimeEvent timeEvent = Span.TimeEvent.newBuilder()
                        .setTime(convertTimestamp(event.getEpochNanos()))
                        .setAnnotation(annotationBuilder.build())
                        .build();

                gcpEvents.add(timeEvent);
            } catch (Exception e) {
                log.warn("Failed to convert span event: {}", e.getMessage());
            }
        }

        return Span.TimeEvents.newBuilder()
                .addAllTimeEvent(gcpEvents)
                .setDroppedAnnotationsCount(Math.max(0, events.size() - MAX_SPAN_EVENTS))
                .build();
    }

    /**
     * Convert nanosecond timestamp to Protobuf Timestamp.
     */
    private Timestamp convertTimestamp(long epochNanos) {
        long seconds = TimeUnit.NANOSECONDS.toSeconds(epochNanos);
        int nanos = (int) (epochNanos % 1_000_000_000);
        return Timestamp.newBuilder()
                .setSeconds(seconds)
                .setNanos(nanos)
                .build();
    }

    /**
     * Split collection into batches of specified size.
     */
    private <T> List<List<T>> splitIntoBatches(List<T> items, int batchSize) {
        List<List<T>> batches = new ArrayList<>();
        for (int i = 0; i < items.size(); i += batchSize) {
            batches.add(items.subList(i, Math.min(i + batchSize, items.size())));
        }
        return batches;
    }

    /**
     * Validate GCP project ID format.
     */
    private void validateProjectId(String projectId) {
        if (projectId == null || projectId.trim().isEmpty()) {
            throw new ConfigurationException("GCP project ID is required");
        }

        if (projectId.length() < 6 || projectId.length() > 30) {
            log.warn("GCP project ID '{}' has unusual length (expected 6-30 chars)", projectId);
        }

        if (!projectId.matches("^[a-z][a-z0-9-]*[a-z0-9]$")) {
            log.warn("GCP project ID '{}' has unusual format (expected lowercase letters, numbers, hyphens)", projectId);
        }
    }

    @Override
    public CompletableResultCode flush() {
        return CompletableResultCode.ofSuccess();
    }

    @Override
    public CompletableResultCode shutdown() {
        log.info("Shutting down GCP Cloud Trace exporter");
        try {
            if (client != null) {
                client.close();
            }
            return CompletableResultCode.ofSuccess();
        } catch (Exception e) {
            log.error("Error shutting down GCP Cloud Trace exporter: {}", e.getMessage());
            return CompletableResultCode.ofFailure();
        }
    }

    /**
     * Get internal metrics for observability.
     */
    Map<String, Long> getMetrics() {
        Map<String, Long> metrics = new HashMap<>();
        metrics.put("spans_exported_total", spansExportedTotal);
        metrics.put("spans_dropped_total", spansDroppedTotal);
        metrics.put("export_attempts_total", exportAttemptsTotal);
        metrics.put("export_failures_total", exportFailuresTotal);
        metrics.put("retries_total", retriesTotal);
        return metrics;
    }
}
