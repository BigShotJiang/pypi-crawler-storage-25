package com.bhsf.mca.sdk.gcp;

import com.bhsf.mca.sdk.exceptions.ConfigurationException;
import com.google.auth.oauth2.GoogleCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Implementation of GCP authentication with strongly-typed API access.
 *
 * <p>This class is only loaded when the google-auth-library-oauth2-http library is available.
 * It provides compile-time type safety while supporting optional dependency patterns.
 *
 * <p><strong>Note:</strong> This class uses direct imports from the GCP auth SDK. It will only
 * be instantiated if the optional dependency is present at runtime. Public access should be
 * through {@link GCPAuthFactory} which handles availability checks.
 *
 * <p><strong>Security Note:</strong> Never log credentials or private keys.
 * HIPAA compliance requires secure credential handling.
 */
class GCPAuthImpl {
    private static final Logger log = LoggerFactory.getLogger(GCPAuthImpl.class);

    /**
     * Load Google Cloud credentials with specified scopes.
     *
     * <p>Priority order:
     * <ol>
     *   <li>credentialsPath (if provided)</li>
     *   <li>credentialsJson (if provided)</li>
     *   <li>Application Default Credentials (ADC)</li>
     * </ol>
     *
     * @param credentialsPath Path to service account JSON file (optional)
     * @param credentialsJson Service account JSON as string (optional)
     * @param scopes OAuth2 scopes to request
     * @return GoogleCredentials instance with requested scopes
     * @throws ConfigurationException if credentials cannot be loaded or are invalid
     */
    static GoogleCredentials loadCredentials(String credentialsPath, String credentialsJson, List<String> scopes) {
        try {
            // Priority 1: Load from file
            if (credentialsPath != null && !credentialsPath.trim().isEmpty()) {
                log.debug("Loading GCP credentials from file: {}", credentialsPath);
                return loadFromFile(credentialsPath, scopes);
            }

            // Priority 2: Load from JSON string
            if (credentialsJson != null && !credentialsJson.trim().isEmpty()) {
                log.debug("Loading GCP credentials from JSON string");
                return loadFromJsonString(credentialsJson, scopes);
            }

            // Priority 3: Fall back to ADC
            log.debug("Loading GCP credentials from Application Default Credentials (ADC)");
            return loadFromADC(scopes);

        } catch (ConfigurationException e) {
            // Re-throw ConfigurationException as-is
            throw e;
        } catch (IOException e) {
            throw new ConfigurationException("Failed to load GCP credentials: " + e.getMessage(), e);
        }
    }

    /**
     * Load credentials from service account JSON file.
     *
     * @param filePath Path to JSON file
     * @param scopes OAuth2 scopes
     * @return GoogleCredentials with scopes
     * @throws IOException if file cannot be read
     * @throws ConfigurationException if JSON is invalid
     */
    private static GoogleCredentials loadFromFile(String filePath, List<String> scopes) throws IOException {
        try (InputStream inputStream = new FileInputStream(filePath)) {
            GoogleCredentials credentials = GoogleCredentials.fromStream(inputStream);

            if (scopes != null && !scopes.isEmpty()) {
                credentials = credentials.createScoped(scopes);
            }

            log.info("Successfully loaded GCP credentials from file: {}", filePath);
            return credentials;
        } catch (IOException e) {
            String message = e.getMessage() != null ? e.getMessage() : "";
            if (e instanceof FileNotFoundException || message.contains("No such file")) {
                throw new ConfigurationException("GCP credentials file not found: " + filePath, e);
            } else if (message.contains("Permission denied") || message.contains("Access is denied")) {
                throw new ConfigurationException("Permission denied reading GCP credentials file: " + filePath, e);
            } else if (message.contains("JSON") || message.contains("parse")) {
                throw new ConfigurationException("Invalid JSON in GCP credentials file: " + filePath, e);
            }
            throw e;
        }
    }

    /**
     * Load credentials from service account JSON string.
     *
     * @param json JSON string
     * @param scopes OAuth2 scopes
     * @return GoogleCredentials with scopes
     * @throws IOException if JSON cannot be parsed
     * @throws ConfigurationException if JSON is invalid
     */
    private static GoogleCredentials loadFromJsonString(String json, List<String> scopes) throws IOException {
        try (InputStream inputStream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8))) {
            GoogleCredentials credentials = GoogleCredentials.fromStream(inputStream);

            if (scopes != null && !scopes.isEmpty()) {
                credentials = credentials.createScoped(scopes);
            }

            log.info("Successfully loaded GCP credentials from JSON string");
            return credentials;
        } catch (IOException e) {
            String message = e.getMessage();
            if (message != null && (message.contains("JSON") || message.contains("parse"))) {
                throw new ConfigurationException(
                        "Invalid JSON in GCP credentials string. Ensure it's a valid service account JSON.", e);
            }
            throw e;
        }
    }

    /**
     * Load credentials from Application Default Credentials (ADC).
     *
     * <p>ADC discovery order (per Google Cloud documentation):
     * <ol>
     *   <li>GOOGLE_APPLICATION_CREDENTIALS environment variable</li>
     *   <li>gcloud CLI credentials (user account)</li>
     *   <li>GCE/GKE/Cloud Run metadata service</li>
     * </ol>
     *
     * @param scopes OAuth2 scopes
     * @return GoogleCredentials with scopes
     * @throws IOException if ADC cannot be loaded
     */
    private static GoogleCredentials loadFromADC(List<String> scopes) throws IOException {
        try {
            GoogleCredentials credentials = GoogleCredentials.getApplicationDefault();

            if (scopes != null && !scopes.isEmpty()) {
                credentials = credentials.createScoped(scopes);
            }

            log.info("Successfully loaded GCP credentials from Application Default Credentials (ADC)");
            return credentials;
        } catch (IOException e) {
            throw new ConfigurationException(
                    "Could not load Application Default Credentials (ADC). " +
                    "Ensure GOOGLE_APPLICATION_CREDENTIALS is set, or gcloud CLI is configured, " +
                    "or application is running on GCP (GCE/GKE/Cloud Run). " +
                    "Error: " + e.getMessage(),
                    e
            );
        }
    }

    /**
     * Validate that credentials have required scopes for GCP operations.
     *
     * <p>Note: This is a best-effort check. Some credential types (e.g., user credentials)
     * may not expose their scopes programmatically. When in doubt, attempt the operation
     * and handle 403 Forbidden errors appropriately.
     *
     * @param credentials GoogleCredentials to validate (passed as Object from factory)
     * @param requiredScopes Required OAuth2 scopes
     * @return true if credentials have all required scopes (or if scopes cannot be determined)
     */
    static boolean validateScopes(Object credentials, List<String> requiredScopes) {
        // Note: GoogleCredentials doesn't expose a public API to check scopes.
        // The scopes are set during creation and can't be queried afterwards.
        // This method is a placeholder for future enhancement if the API changes.
        // For now, we trust that credentials were created with correct scopes.

        if (!(credentials instanceof GoogleCredentials)) {
            log.warn("Credentials object is not a GoogleCredentials instance. Scope validation skipped.");
            return true;
        }

        log.debug("Scope validation skipped (GoogleCredentials API limitation). " +
                 "Ensure credentials were created with required scopes: {}", requiredScopes);
        return true;
    }
}
