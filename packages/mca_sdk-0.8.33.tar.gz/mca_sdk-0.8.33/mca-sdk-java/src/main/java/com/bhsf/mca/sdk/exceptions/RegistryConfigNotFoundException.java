package com.bhsf.mca.sdk.exceptions;

/**
 * Exception thrown when model configuration is not found in the registry.
 *
 * <p>This exception indicates that the requested model or deployment
 * configuration does not exist in the registry. Common causes include:
 * <ul>
 *   <li>Model ID does not exist - No model registered with the given ID</li>
 *   <li>Version not found - Requested version has not been registered</li>
 *   <li>Deployment not found - Deployment ID does not exist</li>
 *   <li>Model deleted - Configuration was removed from registry</li>
 * </ul>
 *
 * <p>This typically corresponds to an HTTP 404 response from the registry API.
 *
 * <p>Usage example:
 * <pre>{@code
 * try {
 *     ModelConfig config = registryClient.fetchModelConfig("mdl-001", "2.0.0");
 * } catch (RegistryConfigNotFoundException e) {
 *     logger.warn("Model config not found, using defaults", e);
 *     // Fall back to default configuration or builder values
 * }
 * }</pre>
 */
public class RegistryConfigNotFoundException extends RegistryException implements NonRetryableException {

    /**
     * Create a not-found exception with a message.
     *
     * @param message Error message describing what was not found
     */
    public RegistryConfigNotFoundException(String message) {
        super(message);
    }

    /**
     * Create a not-found exception with a message and cause.
     *
     * @param message Error message describing what was not found
     * @param cause   Underlying cause (e.g., HTTP 404 response)
     */
    public RegistryConfigNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
