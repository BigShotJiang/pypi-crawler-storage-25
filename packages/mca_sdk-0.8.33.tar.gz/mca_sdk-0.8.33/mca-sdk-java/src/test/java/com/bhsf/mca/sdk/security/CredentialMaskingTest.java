package com.bhsf.mca.sdk.security;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for CredentialMasking.
 */
public class CredentialMaskingTest {

    @Test
    public void testMaskAWSKey() {
        String text = "Error: Invalid AWS key AKIAIOSFODNN7EXAMPLE";
        String masked = CredentialMasking.maskCredentials(text);

        assertEquals("Error: Invalid AWS key [AWS-KEY-REDACTED]", masked);
        assertFalse(masked.contains("AKIAIOSFODNN7EXAMPLE"));
    }

    @Test
    public void testMaskAWSTemporaryKey() {
        String text = "Error: Invalid AWS temporary key ASIAIOSFODNN7EXAMPLE";
        String masked = CredentialMasking.maskCredentials(text);

        assertEquals("Error: Invalid AWS temporary key [AWS-KEY-REDACTED]", masked);
        assertFalse(masked.contains("ASIAIOSFODNN7EXAMPLE"));
    }

    @Test
    public void testMaskBothAWSKeyTypes() {
        String text = "Keys: AKIAIOSFODNN7EXAMPLE and ASIAIOSFODNN7EXAMPLE";
        String masked = CredentialMasking.maskCredentials(text);

        assertEquals("Keys: [AWS-KEY-REDACTED] and [AWS-KEY-REDACTED]", masked);
        assertFalse(masked.contains("AKIAIOSFODNN7EXAMPLE"));
        assertFalse(masked.contains("ASIAIOSFODNN7EXAMPLE"));
    }

    @Test
    public void testMaskGCPKey() {
        // AIzaSy (6) + 33 chars = 39 total, matching GCP_KEY pattern \bAIzaSy[A-Za-z0-9_-]{33}\b
        String text = "Failed with key AIzaSyD9Wi4LW-sB9V1XRFNnGw-P3hXkqxFABCD";
        String masked = CredentialMasking.maskCredentials(text);

        assertTrue(masked.contains("[GCP-KEY-REDACTED]"));
        assertFalse(masked.contains("AIzaSyD9Wi4LW-sB9V1XRFNnGw-P3hXkqxFABCD"));
    }

    @Test
    public void testMaskJWT() {
        String text = "Token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
        String masked = CredentialMasking.maskCredentials(text);

        assertTrue(masked.contains("[JWT-REDACTED]"));
        assertFalse(masked.contains("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"));
    }

    @Test
    public void testMaskBearerToken() {
        String text = "Authorization: Bearer abc123def456ghi789jkl012mno345pqr678stu901";
        String masked = CredentialMasking.maskCredentials(text);

        assertEquals("Authorization: Bearer [TOKEN-REDACTED]", masked);
        assertFalse(masked.contains("abc123def456ghi789jkl012mno345pqr678stu901"));
    }

    @Test
    public void testMaskMultipleCredentials() {
        String text = "AWS key AKIAIOSFODNN7EXAMPLE and JWT eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U";
        String masked = CredentialMasking.maskCredentials(text);

        assertTrue(masked.contains("[AWS-KEY-REDACTED]"));
        assertTrue(masked.contains("[JWT-REDACTED]"));
        assertFalse(masked.contains("AKIAIOSFODNN7EXAMPLE"));
        assertFalse(masked.contains("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"));
    }

    @Test
    public void testMaskCredentials_NoCredentials() {
        String text = "This is a normal message with no credentials";
        String masked = CredentialMasking.maskCredentials(text);

        assertEquals(text, masked);
    }

    @Test
    public void testMaskCredentials_Null() {
        String masked = CredentialMasking.maskCredentials(null);
        assertNull(masked);
    }

    @Test
    public void testMaskCredentials_Empty() {
        String masked = CredentialMasking.maskCredentials("");
        assertEquals("", masked);
    }

    @Test
    public void testMaskRegistryToken() {
        String token = "abc123def456gh9789";
        String masked = CredentialMasking.maskRegistryToken(token);

        assertEquals("***9789", masked);
        assertTrue(masked.startsWith("***"));
        assertTrue(masked.endsWith("9789"));
    }

    @Test
    public void testMaskRegistryToken_Short() {
        String token = "abc";
        String masked = CredentialMasking.maskRegistryToken(token);

        assertEquals("***", masked);
    }

    @Test
    public void testMaskRegistryToken_Null() {
        String masked = CredentialMasking.maskRegistryToken(null);
        assertEquals("[TOKEN-REDACTED]", masked);
    }

    @Test
    public void testMaskRegistryToken_Empty() {
        String masked = CredentialMasking.maskRegistryToken("");
        assertEquals("[TOKEN-REDACTED]", masked);
    }

    @Test
    public void testSanitizeErrorMessage() {
        String error = "Authentication failed: Invalid AWS key AKIAIOSFODNN7EXAMPLE";
        String sanitized = CredentialMasking.sanitizeErrorMessage(error);

        assertTrue(sanitized.contains("[AWS-KEY-REDACTED]"));
        assertFalse(sanitized.contains("AKIAIOSFODNN7EXAMPLE"));
    }

    @Test
    public void testSanitizeErrorMessage_Truncates() {
        StringBuilder longMessage = new StringBuilder();
        for (int i = 0; i < 5000; i++) {
            longMessage.append("a");
        }
        String error = longMessage.toString();

        String sanitized = CredentialMasking.sanitizeErrorMessage(error);

        // Updated to 4096 limit to accommodate Java stack traces
        assertTrue(sanitized.length() <= 4112); // 4096 + "... [truncated]"
        assertTrue(sanitized.endsWith("... [truncated]"));
    }

    @Test
    public void testSanitizeErrorMessage_WithCustomMaxLength() {
        String error = "This is a long error message that needs to be truncated";

        String sanitized = CredentialMasking.sanitizeErrorMessage(error, 20);

        assertTrue(sanitized.length() <= 36); // 20 + "... [truncated]"
        assertTrue(sanitized.endsWith("... [truncated]"));
    }

    @Test
    public void testSanitizeErrorMessage_Null() {
        String sanitized = CredentialMasking.sanitizeErrorMessage(null);
        assertNull(sanitized);
    }

    @Test
    public void testSanitizeErrorMessage_InvalidMaxLength() {
        assertThrows(IllegalArgumentException.class, () -> {
            CredentialMasking.sanitizeErrorMessage("error", 0);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            CredentialMasking.sanitizeErrorMessage("error", -1);
        });
    }

    @Test
    public void testNoFalsePositives_SimilarPatterns() {
        String text = "AKIA123 is not a valid AWS key (too short)";
        String masked = CredentialMasking.maskCredentials(text);

        // Should NOT mask because it's too short
        assertEquals(text, masked);
    }

    @Test
    public void testWordBoundaries() {
        String text = "prefixAKIAIOSFODNN7EXAMPLEsuffix should not match";
        String masked = CredentialMasking.maskCredentials(text);

        // Should NOT mask because word boundary \\b won't match
        assertEquals(text, masked);
    }

    @Test
    public void testMultipleSameCredentials() {
        String text = "Key1: AKIAIOSFODNN7EXAMPLE Key2: AKIAIOSFODNN7EXAMPLE";
        String masked = CredentialMasking.maskCredentials(text);

        assertEquals("Key1: [AWS-KEY-REDACTED] Key2: [AWS-KEY-REDACTED]", masked);
    }
}
