# Release Notes - MCA SDK v0.8.30

## Critical Fixes
- **Fixed Cloud Monitoring "Duplicate TimeSeries" rejections** by increasing default `metric_export_interval_ms` from 5000ms to 30000ms, eliminating batch-window collision with the OTel Collector's 5s batch timeout.
- Implement reference-counted _MCA_PROVIDER_REGISTRY to safely share and teardown OTel providers across clients.
- Add Event-based double-checked locking in setup_meter_provider to prevent concurrent initialization races and exception shadowing.
- Ensure unregister_provider cleans up Prometheus daemon threads and resets OTel global state safely.
- Support OTEL_METRIC_EXPORT_INTERVAL fallback for standard configuration.
- Update tests to use clean provider teardown patterns instead of brittle monkey-patching.

## Documentation
- Updated `metric_export_interval_ms` documentation across all guides to reflect the new 30s default.
