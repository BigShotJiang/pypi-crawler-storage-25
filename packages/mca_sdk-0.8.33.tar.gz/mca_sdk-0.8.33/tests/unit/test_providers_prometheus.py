"""Unit tests for setup_prometheus_exporter (live binding, port-conflict
error, and disabled paths) and for the GCP Cloud Trace setup branching
on missing credentials. Covers parts of mca_sdk/core/providers.py that
the existing test_providers.py left stubbed. Added for story 6-33."""

import socket

import pytest

from mca_sdk.core.providers import setup_prometheus_exporter


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class TestSetupPrometheusExporter:
    def test_disabled_returns_none_none(self):
        reader, shutdown = setup_prometheus_exporter(prometheus_enabled=False)
        assert reader is None and shutdown is None

    @pytest.mark.enable_socket
    def test_enabled_success_and_shutdown(self):
        port = _free_port()
        reader, shutdown = setup_prometheus_exporter(prometheus_enabled=True, prometheus_port=port)
        try:
            assert reader is not None
            assert shutdown is not None

            # Scrape should return metrics
            import http.client

            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=2)
            conn.request("GET", "/metrics")
            resp = conn.getresponse()
            assert resp.status == 200
            conn.close()
        finally:
            if shutdown:
                shutdown()

    @pytest.mark.enable_socket
    def test_port_conflict_raises_configuration_error(self):
        from mca_sdk.utils.exceptions import ConfigurationError

        # Bind the port ourselves first
        port = _free_port()
        blocker = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        blocker.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
        blocker.bind(("127.0.0.1", port))
        blocker.listen(1)
        try:
            with pytest.raises(ConfigurationError, match="already in use"):
                setup_prometheus_exporter(prometheus_enabled=True, prometheus_port=port)
        finally:
            blocker.close()

    @pytest.mark.enable_socket
    def test_import_error_returns_none_none(self, monkeypatch):
        import sys

        # Force import failure
        monkeypatch.setitem(sys.modules, "opentelemetry.exporter.prometheus", None)
        reader, shutdown = setup_prometheus_exporter(
            prometheus_enabled=True, prometheus_port=_free_port()
        )
        assert reader is None and shutdown is None

    @pytest.mark.enable_socket
    def test_custom_host(self):
        port = _free_port()
        reader, shutdown = setup_prometheus_exporter(
            prometheus_enabled=True,
            prometheus_port=port,
            prometheus_host="127.0.0.1",
        )
        try:
            assert reader is not None
        finally:
            if shutdown:
                shutdown()


class TestSetupGcpTraceExporter:
    """setup_gcp_trace_exporter returns None when gcp_trace_enabled=False,
    and raises ConfigurationError when credentials are missing."""

    def test_disabled_returns_none(self):
        from unittest.mock import MagicMock

        from mca_sdk.core.providers import setup_gcp_trace_exporter

        config = MagicMock()
        config.gcp_trace_enabled = False

        assert setup_gcp_trace_exporter(config, resource=MagicMock()) is None

    def test_enabled_without_credentials_raises(self, monkeypatch):
        from unittest.mock import MagicMock

        from mca_sdk.core.providers import setup_gcp_trace_exporter
        from mca_sdk.utils.exceptions import ConfigurationError

        monkeypatch.setattr("mca_sdk.core.gcp_auth.get_google_credentials", lambda cfg: None)

        config = MagicMock()
        config.gcp_trace_enabled = True

        with pytest.raises(ConfigurationError, match="no credentials available"):
            setup_gcp_trace_exporter(config, resource=MagicMock())

    def test_enabled_with_credentials_but_no_project_id_raises(self, monkeypatch):
        from unittest.mock import MagicMock

        from mca_sdk.core.providers import setup_gcp_trace_exporter
        from mca_sdk.utils.exceptions import ConfigurationError

        creds = MagicMock()
        monkeypatch.setattr("mca_sdk.core.gcp_auth.get_google_credentials", lambda cfg: creds)
        monkeypatch.setattr("mca_sdk.core.gcp_auth.get_credentials_for_config", lambda cfg: None)

        config = MagicMock()
        config.gcp_trace_enabled = True
        config.gcp_project_id = None

        with pytest.raises(ConfigurationError, match="Could not determine GCP project_id"):
            setup_gcp_trace_exporter(config, resource=MagicMock())
