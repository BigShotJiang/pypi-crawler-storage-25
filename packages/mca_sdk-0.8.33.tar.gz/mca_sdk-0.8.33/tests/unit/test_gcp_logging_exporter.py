"""Unit tests for GCP Cloud Logging exporter.

Story 6-33 merge 2 extends coverage of `BufferedCloudLoggingExporter`
(retry/drain/shutdown/error paths) and the base-exporter `404`/`timeout`
error branches.
"""

import logging
import pytest
import sys
from unittest.mock import Mock, patch, MagicMock
from mca_sdk.exporters.gcp_logging import (
    CloudLoggingExporter,
    BufferedCloudLoggingExporter,
)
from opentelemetry.sdk._logs.export import LogRecordExportResult as LogExportResult


class TestCloudLoggingExporter:
    """Test CloudLoggingExporter functionality."""

    def test_exporter_initialization(self):
        """Test exporter initializes with correct parameters."""
        # Mock the import
        mock_cloud_logging = MagicMock()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(
                project_id="test-project",
                log_name="test-log",
                resource_type="k8s_container",
            )

            assert exporter.project_id == "test-project"
            assert exporter.log_name == "test-log"
            assert exporter.resource_type == "k8s_container"

    def test_exporter_requires_google_cloud_logging(self):
        """Test that ImportError is raised if google-cloud-logging not installed."""
        with patch.dict("sys.modules", {"google.cloud.logging": None}):
            with pytest.raises(ImportError, match="google-cloud-logging is required"):
                CloudLoggingExporter(project_id="test-project", log_name="test-log")

    def test_export_empty_batch(self):
        """Test exporting empty batch returns success."""
        mock_cloud_logging = MagicMock()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            result = exporter.export([])
            assert result == LogExportResult.SUCCESS

    def test_export_single_log_record(self):
        """Test exporting a single log record."""
        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            log_record = Mock()
            log_record.body = Mock(value="Test message")
            log_record.severity_text = "INFO"
            log_record.attributes = {"key": "value"}
            log_record.resource = Mock(attributes={"service.name": "test-service"})

            result = exporter.export([log_record])

            assert result == LogExportResult.SUCCESS
            mock_logger.log_struct.assert_called_once()

    def test_severity_mapping(self):
        """Test OTel severity to Cloud Logging severity mapping."""
        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            severities = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]

            for severity in severities:
                log_record = Mock()
                log_record.body = Mock(value=f"{severity} message")
                log_record.severity_text = severity
                log_record.attributes = {}
                log_record.resource = Mock(attributes={})

                exporter.export([log_record])

            assert mock_logger.log_struct.call_count == len(severities)

    def test_export_with_credentials(self):
        """Test exporter uses provided credentials."""
        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            mock_creds = Mock()
            exporter = CloudLoggingExporter(
                project_id="test-project", log_name="test-log", credentials=mock_creds
            )

            # Trigger client initialization
            exporter._ensure_client()

            mock_cloud_logging.Client.assert_called_once_with(
                project="test-project", credentials=mock_creds
            )

    def test_shutdown(self):
        """Test exporter shutdown."""
        mock_cloud_logging = MagicMock()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            exporter.shutdown()
            # Should not raise any exceptions

    def test_force_flush(self):
        """Test force flush returns True."""
        mock_cloud_logging = MagicMock()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            result = exporter.force_flush()
            assert result is True

    def test_export_returns_failure_on_exception(self):
        """Test export returns FAILURE when exception occurs."""
        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        # Make log_struct raise an exception
        mock_logger.log_struct.side_effect = Exception("Network error")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            log_record = Mock()
            log_record.body = Mock(value="Test message")
            log_record.severity_text = "INFO"
            log_record.attributes = {}
            log_record.resource = Mock(attributes={})

            result = exporter.export([log_record])

            assert result == LogExportResult.FAILURE

    def test_export_handles_auth_failure(self):
        """Test export returns FAILURE and logs auth error on 401."""
        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        # Make log_struct raise 401 Unauthorized
        mock_logger.log_struct.side_effect = Exception("401 Unauthorized")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            log_record = Mock()
            log_record.body = Mock(value="Test message")
            log_record.severity_text = "INFO"
            log_record.attributes = {}
            log_record.resource = Mock(attributes={})

            result = exporter.export([log_record])

            assert result == LogExportResult.FAILURE

    def test_export_handles_permission_denied(self):
        """Test export returns FAILURE and logs permission error on 403."""
        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        # Make log_struct raise 403 Forbidden
        mock_logger.log_struct.side_effect = Exception("403 Forbidden: Permission denied")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            log_record = Mock()
            log_record.body = Mock(value="Test message")
            log_record.severity_text = "INFO"
            log_record.attributes = {}
            log_record.resource = Mock(attributes={})

            result = exporter.export([log_record])

            assert result == LogExportResult.FAILURE

    def test_export_handles_quota_exceeded(self):
        """Test export returns FAILURE and logs quota error on 429."""
        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        # Make log_struct raise 429 Quota exceeded
        mock_logger.log_struct.side_effect = Exception("429 Quota exceeded")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            log_record = Mock()
            log_record.body = Mock(value="Test message")
            log_record.severity_text = "INFO"
            log_record.attributes = {}
            log_record.resource = Mock(attributes={})

            result = exporter.export([log_record])

            assert result == LogExportResult.FAILURE


# ============================================================================
# Story 6-33 merge-2 additions: error-branch + BufferedCloudLoggingExporter
# ============================================================================


def _make_log_record(message="msg", severity="INFO"):
    """Build a Mock log record with the attributes the exporter reads."""
    rec = Mock()
    rec.body = Mock(value=message)
    rec.severity_text = severity
    rec.attributes = {}
    rec.resource = Mock(attributes={})
    return rec


def _patched_module():
    """Return a configured google.cloud.logging mock + the cloud client mock."""
    mock_cloud_logging = MagicMock()
    mock_client = Mock()
    mock_logger = Mock()
    mock_client.logger.return_value = mock_logger
    mock_cloud_logging.Client.return_value = mock_client
    return mock_cloud_logging, mock_client, mock_logger


class TestCloudLoggingExporterErrorBranches:
    """Cover the 404/timeout/generic catchall branches in `export()`."""

    def test_export_handles_project_not_found_404(self, caplog):
        mock_cl, _, mock_logger = _patched_module()
        mock_logger.log_struct.side_effect = Exception("404 Not Found")
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="missing-project", log_name="test-log")
            with caplog.at_level(logging.ERROR, logger="mca_sdk.exporters.gcp_logging"):
                result = exporter.export([_make_log_record()])
            assert result == LogExportResult.FAILURE
            errs = [
                r
                for r in caplog.records
                if r.levelno == logging.ERROR
                and "Project not found" in r.getMessage()
                and "missing-project" in r.getMessage()
            ]
            assert len(errs) == 1

    def test_export_handles_timeout(self, caplog):
        mock_cl, _, mock_logger = _patched_module()
        mock_logger.log_struct.side_effect = Exception("Connection timeout")
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="p", log_name="l")
            with caplog.at_level(logging.ERROR, logger="mca_sdk.exporters.gcp_logging"):
                result = exporter.export([_make_log_record()])
            assert result == LogExportResult.FAILURE
            assert any(
                "API timeout" in r.getMessage() and r.levelno == logging.ERROR
                for r in caplog.records
            )

    def test_export_handles_generic_exception_with_default_message(self, caplog):
        mock_cl, _, mock_logger = _patched_module()
        mock_logger.log_struct.side_effect = RuntimeError("opaque failure")
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="p", log_name="l")
            with caplog.at_level(logging.ERROR, logger="mca_sdk.exporters.gcp_logging"):
                result = exporter.export([_make_log_record()])
            assert result == LogExportResult.FAILURE
            assert any(
                "Failed to export logs" in r.getMessage() and r.levelno == logging.ERROR
                for r in caplog.records
            )

    def test_ensure_client_failure_propagates_and_logs(self, caplog):
        """Failure inside _ensure_client should log ERROR and re-raise inside export()."""
        mock_cl = MagicMock()
        mock_cl.Client.side_effect = RuntimeError("auth boom")
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="p", log_name="l")
            with caplog.at_level(logging.ERROR, logger="mca_sdk.exporters.gcp_logging"):
                # export() catches the re-raised exception via the broad Exception handler
                # and returns FAILURE. The inner _ensure_client error is logged separately.
                result = exporter.export([_make_log_record()])
            assert result == LogExportResult.FAILURE
            init_errs = [
                r
                for r in caplog.records
                if r.levelno == logging.ERROR
                and "Failed to initialize Cloud Logging client" in r.getMessage()
            ]
            assert len(init_errs) == 1

    def test_export_truncates_oversized_message(self):
        """A body > 1000 chars must be truncated and suffixed with `[truncated]`."""
        mock_cl, _, mock_logger = _patched_module()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="p", log_name="l")
            big = "x" * 5000
            exporter.export([_make_log_record(message=big)])
            mock_logger.log_struct.assert_called_once()
            payload = mock_logger.log_struct.call_args[0][0]
            msg = payload["message"]
            assert msg.endswith("...[truncated]")
            assert len(msg) == 1000 + len("...[truncated]")

    def test_export_reads_inner_log_record_when_outer_body_missing(self):
        """LogData wrapper case: outer body=None, but inner_record.body present."""
        mock_cl, _, mock_logger = _patched_module()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="p", log_name="l")
            outer = Mock()
            outer.body = None
            outer.severity_text = "INFO"
            outer.attributes = None
            outer.resource = None
            inner = Mock()
            inner.body = Mock(value="from-inner")
            inner.attributes = {"k": "v"}
            inner.resource = Mock(attributes={"service.name": "svc"})
            outer.log_record = inner
            exporter.export([outer])
            payload = mock_logger.log_struct.call_args[0][0]
            assert payload["message"] == "from-inner"
            assert "k" in payload["labels"]
            assert "resource.service.name" in payload["labels"]

    def test_export_label_truncation_enforced(self):
        """Keys/values > 63 chars must be sliced to MAX_LABEL_*_LENGTH."""
        mock_cl, _, mock_logger = _patched_module()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="p", log_name="l")
            rec = _make_log_record()
            long_key = "k" * 200
            long_val = "v" * 200
            rec.attributes = {long_key: long_val}
            exporter.export([rec])
            labels = mock_logger.log_struct.call_args[0][0]["labels"]
            ((only_k, only_v),) = labels.items()
            assert len(only_k) == 63
            assert len(only_v) == 63

    def test_export_resource_obj_falls_back_on_attribute_error(self):
        """Resource() raising AttributeError is swallowed; resource_obj=None used."""
        mock_cl, _, mock_logger = _patched_module()
        mock_cl.Resource.side_effect = AttributeError("no Resource cls")
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="p", log_name="l")
            result = exporter.export([_make_log_record()])
            assert result == LogExportResult.SUCCESS
            assert mock_logger.log_struct.call_args.kwargs["resource"] is None

    def test_shutdown_with_initialised_client_does_not_raise(self):
        """Shutdown with self._client set takes the live branch (L268-273)."""
        mock_cl, mock_client, _ = _patched_module()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cl}):
            exporter = CloudLoggingExporter(project_id="p", log_name="l")
            exporter._ensure_client()
            assert exporter._client is mock_client
            # Should not raise
            exporter.shutdown()


# ----------------------------------------------------------------------------
# BufferedCloudLoggingExporter — the bulk of the uncovered surface (L362-567)
# ----------------------------------------------------------------------------


@pytest.fixture
def patched_gcl(monkeypatch):
    """Install a mocked `google.cloud.logging` module for the test duration."""
    mock_cl, mock_client, mock_logger = _patched_module()
    monkeypatch.setitem(sys.modules, "google.cloud.logging", mock_cl)
    yield mock_cl, mock_client, mock_logger


class TestBufferedCloudLoggingExporterInit:
    def test_init_stores_args_and_creates_underlying_exporter(self, patched_gcl):
        from mca_sdk.buffering.retry import RetryPolicy

        policy = RetryPolicy(max_attempts=2)
        exp = BufferedCloudLoggingExporter(
            project_id="proj",
            log_name="lg",
            resource_type="k8s_container",
            credentials=None,
            timeout=10.0,
            retry_policy=policy,
            drain_interval=0.1,
            max_retry_queue_size=5,
            max_retry_attempts=2,
        )
        assert isinstance(exp._exporter, CloudLoggingExporter)
        assert exp._exporter.project_id == "proj"
        assert exp._exporter.resource_type == "k8s_container"
        assert exp._max_retry_queue_size == 5
        assert exp._max_retry_attempts == 2
        assert exp._drain_interval == 0.1
        assert exp._retry_policy is policy

    def test_init_creates_default_retry_policy_when_none_provided(self, patched_gcl):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        from mca_sdk.buffering.retry import RetryPolicy

        assert isinstance(exp._retry_policy, RetryPolicy)

    def test_getattr_delegation_to_underlying_exporter(self, patched_gcl):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        # SEVERITY_MAP only exists on CloudLoggingExporter; __getattr__ must forward.
        assert exp.SEVERITY_MAP["FATAL"] == "CRITICAL"


class TestBufferedExportSuccess:
    def test_export_success_increments_success_counter(self, patched_gcl):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        # RetryPolicy.execute returns whatever the underlying call returns.
        # The underlying export with our mocked log_struct succeeds.
        result = exp.export([_make_log_record()])
        assert result == LogExportResult.SUCCESS
        assert exp._export_attempts == 1
        assert exp._export_successes == 1
        assert exp._export_failures == 0


class TestBufferedExportFailureAndQueueing:
    def test_export_failure_result_queues_for_retry(self, patched_gcl, caplog):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", max_retry_queue_size=10)
        # Force the inner exporter to return FAILURE without raising,
        # so the "result != SUCCESS" branch fires.
        with patch.object(exp._exporter, "export", return_value=LogExportResult.FAILURE):
            with caplog.at_level(logging.WARNING, logger="mca_sdk.exporters.gcp_logging"):
                result = exp.export([_make_log_record()])
        assert result == LogExportResult.SUCCESS  # queued counts as success
        assert exp._export_failures == 1
        assert exp._items_queued == 1
        assert exp._queue.size() == 1
        assert any(
            "queueing for retry" in r.getMessage() and r.levelno == logging.WARNING
            for r in caplog.records
        )

    def test_export_exception_path_queues_for_retry(self, patched_gcl, caplog):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        with patch.object(exp._exporter, "export", side_effect=RuntimeError("network down")):
            with caplog.at_level(logging.ERROR, logger="mca_sdk.exporters.gcp_logging"):
                result = exp.export([_make_log_record()])
        assert result == LogExportResult.SUCCESS
        assert exp._items_queued == 1
        assert any(
            "Exception during Cloud Logging export" in r.getMessage() and r.levelno == logging.ERROR
            for r in caplog.records
        )

    def test_queue_drop_when_size_limit_reached_returns_failure(self, patched_gcl, caplog):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", max_retry_queue_size=2)
        # Pre-fill queue at capacity with raw items so the size check fires.
        from mca_sdk.buffering.queued_item import QueuedItem

        exp._queue.enqueue(QueuedItem(data=[], attempt_count=0))
        exp._queue.enqueue(QueuedItem(data=[], attempt_count=0))
        assert exp._queue.size() == 2

        with patch.object(exp._exporter, "export", return_value=LogExportResult.FAILURE):
            with caplog.at_level(logging.WARNING, logger="mca_sdk.exporters.gcp_logging"):
                result = exp.export([_make_log_record()])

        assert result == LogExportResult.FAILURE
        assert any(
            "Queue size limit reached" in r.getMessage() and r.levelno == logging.WARNING
            for r in caplog.records
        )


class TestBufferedDrainQueue:
    def test_drain_queue_noop_when_empty(self, patched_gcl):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        # Should be silent and not raise
        exp._drain_queue()

    def test_drain_queue_succeeds_removes_item(self, patched_gcl):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        from mca_sdk.buffering.queued_item import QueuedItem

        exp._queue.enqueue(QueuedItem(data=[_make_log_record()], attempt_count=0))
        with patch.object(exp._exporter, "export", return_value=LogExportResult.SUCCESS) as m:
            exp._drain_queue()
        m.assert_called_once()
        assert exp._queue.is_empty()
        assert exp._items_retried == 1

    def test_drain_queue_failure_requeues_item(self, patched_gcl):
        """Failures re-enqueue + bump attempt_count until the cap is hit, then drop.

        With max_retry_attempts=3, one item is dequeued/exported/re-enqueued 3
        times within a single drain cycle. The 4th dequeue sees attempt_count
        already at 3 and drops the item.
        """
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", max_retry_attempts=3)
        from mca_sdk.buffering.queued_item import QueuedItem

        exp._queue.enqueue(QueuedItem(data=[_make_log_record()], attempt_count=0))
        with patch.object(exp._exporter, "export", return_value=LogExportResult.FAILURE) as m:
            exp._drain_queue()
        assert m.call_count == 3  # one attempt per allowed retry
        assert exp._queue.is_empty()
        assert exp._items_retried == 3

    def test_drain_queue_drops_after_max_attempts(self, patched_gcl, caplog):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", max_retry_attempts=2)
        from mca_sdk.buffering.queued_item import QueuedItem

        # Item already at the cap — should be dropped, not retried
        exp._queue.enqueue(QueuedItem(data=[_make_log_record()], attempt_count=2))
        with caplog.at_level(logging.WARNING, logger="mca_sdk.exporters.gcp_logging"):
            exp._drain_queue()
        assert exp._queue.is_empty()
        assert any(
            "Max retry attempts" in r.getMessage() and r.levelno == logging.WARNING
            for r in caplog.records
        )

    def test_drain_queue_exception_during_retry_requeues(self, patched_gcl, caplog):
        """Exceptions during retry must be caught, logged at ERROR, and the
        item re-queued for another attempt — until the attempt cap drops it.
        """
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", max_retry_attempts=3)
        from mca_sdk.buffering.queued_item import QueuedItem

        exp._queue.enqueue(QueuedItem(data=[_make_log_record()], attempt_count=0))
        with patch.object(exp._exporter, "export", side_effect=RuntimeError("blow up")) as m:
            with caplog.at_level(logging.ERROR, logger="mca_sdk.exporters.gcp_logging"):
                exp._drain_queue()
        # 3 attempts, 3 ERROR logs, then drop on the 4th dequeue
        assert m.call_count == 3
        assert exp._queue.is_empty()
        err_count = sum(
            1
            for r in caplog.records
            if r.levelno == logging.ERROR and "Exception during retry" in r.getMessage()
        )
        assert err_count == 3

    def test_drain_queue_caps_iterations_at_max_drain(self, patched_gcl):
        """Per-cycle drain is capped at 10; 15 enqueued -> 10 processed."""
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", max_retry_queue_size=20)
        from mca_sdk.buffering.queued_item import QueuedItem

        for _ in range(15):
            exp._queue.enqueue(QueuedItem(data=[_make_log_record()], attempt_count=0))
        with patch.object(exp._exporter, "export", return_value=LogExportResult.SUCCESS) as m:
            exp._drain_queue()
        # Exactly 10 dequeued+exported in one cycle
        assert m.call_count == 10
        assert exp._queue.size() == 5


class TestBufferedWorkerLifecycle:
    def test_start_background_worker_starts_thread(self, patched_gcl):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", drain_interval=0.05)
        exp.start_background_worker()
        assert exp._worker_thread is not None
        assert exp._worker_thread.is_alive()
        exp.shutdown()
        assert not exp._worker_thread.is_alive()

    def test_start_background_worker_warns_if_already_running(self, patched_gcl, caplog):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", drain_interval=0.05)
        exp.start_background_worker()
        try:
            with caplog.at_level(logging.WARNING, logger="mca_sdk.exporters.gcp_logging"):
                exp.start_background_worker()
            assert any(
                "Background worker already running" in r.getMessage()
                and r.levelno == logging.WARNING
                for r in caplog.records
            )
        finally:
            exp.shutdown()

    def test_drain_queue_loop_swallows_exceptions(self, patched_gcl, caplog):
        """Exceptions inside _drain_queue must not kill the worker loop."""
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l", drain_interval=0.01)
        with patch.object(exp, "_drain_queue", side_effect=RuntimeError("drain explosion")):
            with caplog.at_level(logging.ERROR, logger="mca_sdk.exporters.gcp_logging"):
                exp.start_background_worker()
                import time

                time.sleep(0.05)
                # Set stop and join — loop should exit without crashing
                exp._stop_event.set()
                exp._worker_thread.join(timeout=1.0)
        assert any(
            "Error draining Cloud Logging queue" in r.getMessage() and r.levelno == logging.ERROR
            for r in caplog.records
        )

    def test_shutdown_does_final_drain(self, patched_gcl):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        from mca_sdk.buffering.queued_item import QueuedItem

        exp._queue.enqueue(QueuedItem(data=[_make_log_record()], attempt_count=0))
        with patch.object(exp._exporter, "export", return_value=LogExportResult.SUCCESS) as m:
            exp.shutdown()
        m.assert_called_once()
        assert exp._queue.is_empty()

    def test_shutdown_logs_warning_if_final_drain_raises(self, patched_gcl, caplog):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        with patch.object(exp, "_drain_queue", side_effect=RuntimeError("final drain bad")):
            with caplog.at_level(logging.WARNING, logger="mca_sdk.exporters.gcp_logging"):
                exp.shutdown()
        assert any(
            "Error during final queue drain" in r.getMessage() and r.levelno == logging.WARNING
            for r in caplog.records
        )


class TestBufferedForceFlush:
    def test_force_flush_returns_true_on_success(self, patched_gcl):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        assert exp.force_flush() is True

    def test_force_flush_returns_false_on_drain_exception(self, patched_gcl, caplog):
        exp = BufferedCloudLoggingExporter(project_id="p", log_name="l")
        with patch.object(exp, "_drain_queue", side_effect=RuntimeError("nope")):
            with caplog.at_level(logging.ERROR, logger="mca_sdk.exporters.gcp_logging"):
                out = exp.force_flush()
        assert out is False
        assert any(
            "Error during force flush" in r.getMessage() and r.levelno == logging.ERROR
            for r in caplog.records
        )
