"""Tests for uncovered paths in integrations/decorators.py."""

from unittest.mock import MagicMock, Mock, patch, call
from contextlib import contextmanager

import pytest


def _make_mock_client():
    """Create a mock MCAClient with required attributes."""
    client = MagicMock()
    client.record_goal_started.return_value = "goal-001"
    client.record_goal_completed.return_value = None

    # Mock tracer with context manager support
    mock_span = MagicMock()
    mock_span.set_attribute.return_value = None
    mock_span.set_status.return_value = None

    @contextmanager
    def fake_span_ctx(*args, **kwargs):
        yield mock_span

    client._tracer = MagicMock()
    client._tracer.start_as_current_span.side_effect = fake_span_ctx
    client._mock_span = mock_span
    return client


class TestTraceAgentGoalDecorator:
    def test_decorator_calls_record_goal_started(self):
        from mca_sdk.integrations.decorators import trace_agent_goal

        client = _make_mock_client()

        @trace_agent_goal(client, description="Test goal")
        def my_func():
            return "result"

        result = my_func()
        assert result == "result"
        client.record_goal_started.assert_called_once()
        client.record_goal_completed.assert_called_once()

    def test_decorator_marks_failure_on_exception(self):
        from mca_sdk.integrations.decorators import trace_agent_goal

        client = _make_mock_client()

        @trace_agent_goal(client, description="Failing goal")
        def bad_func():
            raise ValueError("oops")

        with pytest.raises(ValueError, match="oops"):
            bad_func()

        call_args = client.record_goal_completed.call_args
        assert call_args is not None
        assert "failure" in str(call_args)

    def test_decorator_with_goal_type(self):
        from mca_sdk.integrations.decorators import trace_agent_goal

        client = _make_mock_client()

        @trace_agent_goal(client, description="Test", goal_type="research")
        def my_func():
            return 42

        result = my_func()
        assert result == 42
        call_kwargs = client.record_goal_started.call_args[1]
        assert call_kwargs.get("goal_type") == "research"


class TestTraceAgentStepDecorator:
    def test_decorator_creates_span_and_executes_func(self):
        from mca_sdk.integrations.decorators import trace_agent_step

        client = _make_mock_client()

        @trace_agent_step(client, step_id="step-001")
        def my_step():
            return "step result"

        result = my_step()
        assert result == "step result"
        client._tracer.start_as_current_span.assert_called_once_with(
            "agent.step",
            attributes={"genai.agent.step.id": "step-001"},
        )
        client._mock_span.set_attribute.assert_any_call("step.status", "success")

    def test_decorator_generates_step_id_when_not_provided(self):
        from mca_sdk.integrations.decorators import trace_agent_step

        client = _make_mock_client()

        @trace_agent_step(client)
        def my_step():
            return "ok"

        result = my_step()
        assert result == "ok"
        # step_id is auto-generated (UUID), just check span was created
        client._tracer.start_as_current_span.assert_called_once()

    def test_decorator_marks_error_on_exception(self):
        from mca_sdk.integrations.decorators import trace_agent_step

        client = _make_mock_client()

        @trace_agent_step(client, step_id="step-err")
        def bad_step():
            raise RuntimeError("step failed")

        with pytest.raises(RuntimeError, match="step failed"):
            bad_step()

        client._mock_span.set_attribute.assert_any_call("step.status", "error")
        client._mock_span.set_attribute.assert_any_call("error.type", "RuntimeError")
