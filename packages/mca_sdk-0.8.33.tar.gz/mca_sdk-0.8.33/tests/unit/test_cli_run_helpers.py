"""Unit tests for mca_sdk/cli/run.py pure-function helpers: build_parser,
inject_env_vars (env-vs-arg precedence), validate_config, and
setup_bootstrap_injection. Does not test run_command (subprocess). Added
for story 6-33 coverage climb."""

import argparse
import os
from pathlib import Path

import pytest

from mca_sdk.cli.run import (
    build_parser,
    inject_env_vars,
    setup_bootstrap_injection,
    validate_config,
)


@pytest.fixture
def parser():
    return build_parser()


class TestInjectEnvVars:
    def test_cli_args_fill_empty_env(self, parser):
        args = parser.parse_args(
            [
                "--model-id",
                "mdl",
                "--team",
                "t",
                "--service-name",
                "svc",
                "--collector-endpoint",
                "http://c:4318",
                "--registry-url",
                "https://r",
            ]
        )
        env = inject_env_vars(args, env={})
        assert env["MCA_MODEL_ID"] == "mdl"
        assert env["MCA_TEAM_NAME"] == "t"
        assert env["MCA_SERVICE_NAME"] == "svc"
        assert env["MCA_COLLECTOR_ENDPOINT"] == "http://c:4318"
        assert env["MCA_REGISTRY_URL"] == "https://r"

    def test_env_vars_take_precedence_over_cli(self, parser):
        args = parser.parse_args(["--model-id", "cli-id", "--team", "cli-team"])
        env = {"MCA_MODEL_ID": "env-id", "MCA_TEAM_NAME": "env-team"}
        result = inject_env_vars(args, env=env)
        assert result["MCA_MODEL_ID"] == "env-id"
        assert result["MCA_TEAM_NAME"] == "env-team"

    def test_service_name_defaults_to_model_id(self, parser):
        args = parser.parse_args(["--model-id", "mdl-only", "--team", "t"])
        env = inject_env_vars(args, env={})
        assert env["MCA_SERVICE_NAME"] == "mdl-only"

    def test_debug_flag_sets_env(self, parser):
        args = parser.parse_args(["--model-id", "m", "--team", "t", "--debug"])
        env = inject_env_vars(args, env={})
        assert env["MCA_DEBUG_MODE"] == "true"

    def test_debug_flag_does_not_override_existing_env(self, parser):
        args = parser.parse_args(["--model-id", "m", "--team", "t", "--debug"])
        env = inject_env_vars(args, env={"MCA_DEBUG_MODE": "false"})
        assert env["MCA_DEBUG_MODE"] == "false"

    def test_defaults_to_os_environ_copy(self, parser, monkeypatch):
        monkeypatch.setenv("MCA_MODEL_ID", "from-os")
        monkeypatch.setenv("MCA_TEAM_NAME", "team-from-os")
        args = parser.parse_args([])
        env = inject_env_vars(args)
        assert env["MCA_MODEL_ID"] == "from-os"
        assert env["MCA_TEAM_NAME"] == "team-from-os"


class TestValidateConfig:
    def test_accepts_valid(self):
        assert validate_config({"MCA_MODEL_ID": "m", "MCA_TEAM_NAME": "t"}) is True

    def test_rejects_missing_model_id(self, capsys):
        assert validate_config({"MCA_TEAM_NAME": "t"}) is False
        err = capsys.readouterr().err
        assert "model ID" in err

    def test_rejects_missing_team_name(self, capsys):
        assert validate_config({"MCA_MODEL_ID": "m"}) is False
        err = capsys.readouterr().err
        assert "team name" in err

    def test_rejects_empty_values(self, capsys):
        assert validate_config({"MCA_MODEL_ID": "", "MCA_TEAM_NAME": ""}) is False
        err = capsys.readouterr().err
        assert "model ID" in err and "team name" in err


class TestSetupBootstrapInjection:
    def test_creates_temp_dir_with_sitecustomize(self, tmp_path):
        env = {}
        temp_dir = setup_bootstrap_injection(env)
        try:
            tp = Path(temp_dir)
            assert tp.exists()
            assert (tp / "sitecustomize.py").exists()
            content = (tp / "sitecustomize.py").read_text()
            assert "mca_sdk.cli._bootstrap" in content
            assert env["PYTHONPATH"].startswith(temp_dir)
        finally:
            import shutil

            shutil.rmtree(temp_dir, ignore_errors=True)

    def test_prepends_to_existing_pythonpath(self):
        env = {"PYTHONPATH": "/existing/path"}
        temp_dir = setup_bootstrap_injection(env)
        try:
            assert env["PYTHONPATH"] == f"{temp_dir}:/existing/path"
        finally:
            import shutil

            shutil.rmtree(temp_dir, ignore_errors=True)
