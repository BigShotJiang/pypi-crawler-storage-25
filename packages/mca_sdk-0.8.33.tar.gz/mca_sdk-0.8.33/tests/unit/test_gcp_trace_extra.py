"""Tests for uncovered paths in gcp_trace_exporter.py and providers.py GCP setup."""

from unittest.mock import Mock, MagicMock, patch

import pytest


def _make_mock_trace_v2():
    mock_module = MagicMock()
    mock_client = MagicMock()
    mock_module.TraceServiceClient.return_value = mock_client
    return mock_module, mock_client


class TestGCPCloudTraceExporterInit:
    def _make_exporter(self, credentials=None, mock_trace_v2=None):
        if mock_trace_v2 is None:
            mock_trace_v2, _ = _make_mock_trace_v2()
        with patch.dict("sys.modules", {"google.cloud.trace_v2": mock_trace_v2}):
            from mca_sdk.exporters.gcp_trace_exporter import GCPCloudTraceExporter

            return GCPCloudTraceExporter(
                project_id="test-project",
                credentials=credentials or Mock(),
            )

    def test_init_sets_project_name(self):
        exporter = self._make_exporter()
        assert exporter._project_name == "projects/test-project"

    def test_init_empty_resource_attrs(self):
        exporter = self._make_exporter()
        assert isinstance(exporter._resource_attrs, dict)

    def test_init_with_resource(self):
        from opentelemetry.sdk.resources import Resource

        mock_trace_v2, _ = _make_mock_trace_v2()
        resource = Resource.create({"service.name": "my-svc"})
        with patch.dict("sys.modules", {"google.cloud.trace_v2": mock_trace_v2}):
            from mca_sdk.exporters.gcp_trace_exporter import GCPCloudTraceExporter

            exporter = GCPCloudTraceExporter(
                project_id="test-project", credentials=Mock(), resource=resource
            )
        assert "service.name" in exporter._resource_attrs

    def test_init_credentials_with_scopes_no_required_scope_logs_warning(self):
        mock_trace_v2, _ = _make_mock_trace_v2()
        creds = Mock()
        creds.scopes = ["https://www.googleapis.com/auth/bigquery"]
        with patch.dict("sys.modules", {"google.cloud.trace_v2": mock_trace_v2}):
            from mca_sdk.exporters.gcp_trace_exporter import GCPCloudTraceExporter

            # Should not raise, just log warning
            exporter = GCPCloudTraceExporter(project_id="test-project", credentials=creds)
        assert exporter._project_id == "test-project"

    def test_init_credentials_with_required_scope(self):
        mock_trace_v2, _ = _make_mock_trace_v2()
        creds = Mock()
        creds.scopes = ["https://www.googleapis.com/auth/trace.append"]
        with patch.dict("sys.modules", {"google.cloud.trace_v2": mock_trace_v2}):
            from mca_sdk.exporters.gcp_trace_exporter import GCPCloudTraceExporter

            exporter = GCPCloudTraceExporter(project_id="test-project", credentials=creds)
        assert exporter._project_id == "test-project"

    def test_init_client_creation_failure_raises(self):
        mock_trace_v2 = MagicMock()
        mock_trace_v2.TraceServiceClient.side_effect = Exception("credentials invalid")
        with patch.dict("sys.modules", {"google.cloud.trace_v2": mock_trace_v2}):
            from mca_sdk.exporters.gcp_trace_exporter import GCPCloudTraceExporter

            with pytest.raises(Exception, match="credentials invalid"):
                GCPCloudTraceExporter(project_id="test-project", credentials=Mock())


class TestGCPCloudTraceExporterExport:
    def _make_exporter(self):
        mock_trace_v2, mock_client = _make_mock_trace_v2()
        with patch.dict("sys.modules", {"google.cloud.trace_v2": mock_trace_v2}):
            from mca_sdk.exporters.gcp_trace_exporter import GCPCloudTraceExporter

            exporter = GCPCloudTraceExporter(project_id="test-project", credentials=Mock())
        return exporter, mock_client

    def test_export_invalid_type_returns_failure(self):
        from opentelemetry.sdk.trace.export import SpanExportResult

        exporter, _ = self._make_exporter()
        result = exporter.export("not-a-list")
        assert result == SpanExportResult.FAILURE

    def test_export_empty_list_returns_success(self):
        from opentelemetry.sdk.trace.export import SpanExportResult

        exporter, _ = self._make_exporter()
        result = exporter.export([])
        assert result == SpanExportResult.SUCCESS

    def test_shutdown_does_not_raise(self):
        exporter, _ = self._make_exporter()
        exporter.shutdown()  # Should not raise

    def test_force_flush_returns_true(self):
        exporter, _ = self._make_exporter()
        assert exporter.force_flush() is True
        assert exporter.force_flush(timeout_millis=5000) is True

    def test_get_metrics_returns_dict(self):
        exporter, _ = self._make_exporter()
        metrics = exporter.get_metrics()
        assert isinstance(metrics, dict)
        assert "spans_exported_total" in metrics
        assert "export_failures_total" in metrics
        assert "last_export_duration_seconds" in metrics


class TestSetupGcpTraceExporter:
    def test_returns_none_when_disabled(self):
        from mca_sdk.core.providers import setup_gcp_trace_exporter
        from opentelemetry.sdk.resources import Resource

        config = Mock()
        config.gcp_trace_enabled = False
        resource = Resource.create({"service.name": "svc"})
        result = setup_gcp_trace_exporter(config, resource)
        assert result is None

    def test_raises_configuration_error_when_no_credentials(self):
        import sys
        from mca_sdk.core.providers import setup_gcp_trace_exporter
        from mca_sdk.utils.exceptions import ConfigurationError
        from opentelemetry.sdk.resources import Resource

        config = Mock()
        config.gcp_trace_enabled = True
        resource = Resource.create({"service.name": "svc"})

        mock_gcp_auth = MagicMock()
        mock_gcp_auth.get_google_credentials.return_value = None
        mock_gcp_auth.get_credentials_for_config.return_value = None

        with patch.dict(sys.modules, {"mca_sdk.core.gcp_auth": mock_gcp_auth}):
            with pytest.raises(ConfigurationError, match="no credentials"):
                setup_gcp_trace_exporter(config, resource)

    def test_raises_configuration_error_when_no_project_id_from_creds(self):
        import sys
        from mca_sdk.core.providers import setup_gcp_trace_exporter
        from mca_sdk.utils.exceptions import ConfigurationError
        from opentelemetry.sdk.resources import Resource

        config = Mock()
        config.gcp_trace_enabled = True
        config.gcp_project_id = None  # No project_id in config
        resource = Resource.create({"service.name": "svc"})

        mock_creds = Mock()
        mock_creds.project_id = None  # No project_id in creds either

        mock_gcp_auth = MagicMock()
        mock_gcp_auth.get_google_credentials.return_value = mock_creds
        mock_gcp_auth.get_credentials_for_config.return_value = None

        with patch.dict(sys.modules, {"mca_sdk.core.gcp_auth": mock_gcp_auth}):
            with pytest.raises(ConfigurationError, match="Could not determine GCP project_id"):
                setup_gcp_trace_exporter(config, resource)

    def test_gets_project_id_from_credentials_when_not_in_config(self):
        import sys
        from unittest.mock import MagicMock, Mock, patch
        from opentelemetry.sdk.resources import Resource

        config = Mock()
        config.gcp_trace_enabled = True
        config.gcp_project_id = None  # No project_id in config
        resource = Resource.create({"service.name": "svc"})

        mock_creds = Mock()
        mock_creds.project_id = "my-project"  # Project from credentials
        mock_creds.scopes = []

        mock_creds_from_config = Mock()
        mock_creds_from_config.project_id = "my-project"

        mock_trace_v2 = MagicMock()
        mock_trace_v2.TraceServiceClient.return_value = MagicMock()

        mock_gcp_auth = MagicMock()
        mock_gcp_auth.get_google_credentials.return_value = mock_creds
        mock_gcp_auth.get_credentials_for_config.return_value = mock_creds_from_config

        with patch.dict(
            sys.modules,
            {
                "mca_sdk.core.gcp_auth": mock_gcp_auth,
                "google.cloud.trace_v2": mock_trace_v2,
            },
        ):
            from mca_sdk.core.providers import setup_gcp_trace_exporter

            result = setup_gcp_trace_exporter(config, resource)

        assert result is not None
