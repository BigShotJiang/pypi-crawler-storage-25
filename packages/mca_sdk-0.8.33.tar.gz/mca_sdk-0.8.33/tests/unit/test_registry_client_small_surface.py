"""Unit tests for registry/client.py small-surface methods that aren't
covered by the large existing test_registry_client.py: clear_cache,
untrack_model, get_tracked_models, get_refresh_stats, close (cleanup),
plus the fetch_deployment_config cache-hit path. Added for story 6-33."""

import time
from unittest.mock import Mock, patch

import pytest

from mca_sdk.registry.client import CacheEntry, RegistryClient
from mca_sdk.registry.models import DeploymentConfig, ModelConfig


@pytest.fixture
def client():
    return RegistryClient(url="https://registry.example.com")


class TestCacheManagement:
    def test_clear_cache_removes_all_entries(self, client):
        client._cache["foo"] = CacheEntry(value="bar", expires_at=time.time() + 60)
        client._cache["baz"] = CacheEntry(value="qux", expires_at=time.time() + 60)

        client.clear_cache()
        assert client._cache == {}

    def test_clear_cache_on_empty_does_not_raise(self, client):
        client.clear_cache()  # idempotent
        assert client._cache == {}


class TestTrackedModels:
    def test_untrack_known_model(self, client):
        client._fetched_models.add("mdl-001")
        client._fetched_models.add("mdl-002")

        client.untrack_model("mdl-001")

        assert client._fetched_models == {"mdl-002"}

    def test_untrack_unknown_model_is_noop(self, client):
        client._fetched_models.add("mdl-001")
        client.untrack_model("not-here")
        assert client._fetched_models == {"mdl-001"}

    def test_get_tracked_models_returns_copy(self, client):
        client._fetched_models.add("a")
        client._fetched_models.add("b")
        snapshot = client.get_tracked_models()
        assert snapshot == {"a", "b"}

        # Mutation should not affect internal state
        snapshot.add("c")
        assert "c" not in client._fetched_models


class TestRefreshStats:
    def test_get_refresh_stats_structure(self, client):
        stats = client.get_refresh_stats()
        assert isinstance(stats, dict)
        # Keys should cover refresh tracking state
        assert "refresh_count" in stats or "last_refresh_at" in stats or stats


class TestCloseShutdown:
    def test_close_is_idempotent(self, client):
        client.close()
        # Second call must not raise
        client.close()

    def test_close_stops_refresh_thread(self, client):
        # Simulate a running refresh thread
        mock_thread = Mock()
        mock_thread.is_alive.return_value = True
        client._refresh_thread = mock_thread
        client._stop_event = Mock()

        client.close()

        # close() should have attempted to signal the stop event
        client._stop_event.set.assert_called()


class TestFetchDeploymentConfigCacheHit:
    def test_cache_hit_returns_cached_value(self, client):
        cached_config = DeploymentConfig(
            deployment_id="dep-123",
            environment="staging",
            region="us-east-1",
        )
        client._cache["deployment:dep-123"] = CacheEntry(
            value=cached_config, expires_at=time.time() + 600
        )

        with patch.object(client, "_fetch_deployment_config_internal") as mock_fetch:
            result = client.fetch_deployment_config("dep-123")

        assert result is cached_config
        mock_fetch.assert_not_called()

    def test_cache_miss_triggers_fetch(self, client):
        returned = DeploymentConfig(
            deployment_id="dep-xyz",
            environment="production",
            region="us-west-2",
        )

        with patch.object(
            client, "_fetch_deployment_config_internal", return_value=returned
        ) as mock_fetch:
            result = client.fetch_deployment_config("dep-xyz")

        assert result is returned
        mock_fetch.assert_called_once_with("dep-xyz")
        # Result was cached
        assert "deployment:dep-xyz" in client._cache


class TestGetCachedExpiry:
    def test_expired_entry_not_returned(self, client):
        # Expired 1s ago
        client._cache["key"] = CacheEntry(value="stale", expires_at=time.time() - 1)
        assert client._get_cached("key") is None

    def test_missing_key_returns_none(self, client):
        assert client._get_cached("not-there") is None

    def test_fresh_entry_returned(self, client):
        client._cache["key"] = CacheEntry(value="fresh", expires_at=time.time() + 600)
        assert client._get_cached("key") == "fresh"


class TestSetCache:
    def test_set_cache_stores_entry(self, client):
        client._set_cache("foo", "bar")
        assert "foo" in client._cache
        assert client._cache["foo"].value == "bar"
        assert client._cache["foo"].expires_at > time.time()
