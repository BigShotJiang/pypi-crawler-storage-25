"""Unit tests for async HIPAA audit log emission (Story 6-42, adversarial round 2).

Verifies the two-path audit wiring in `MCAClient._setup_logging`:
- OTel `LoggingHandler.emit` does not run on the calling thread.
- Records reach the OTel handler via the background listener/drain thread.
- `shutdown()` drains the audit queue and spillover before provider teardown.
- Overflow policy spills to structured JSON-lines file (HIPAA compliant),
  then blocks, then writes CRITICAL-level stderr only as a last resort.
- Fast path bypasses stdlib logger machinery entirely.
- atexit / SIGTERM handlers drain audit records under k8s eviction.
"""

import io
import json
import logging
import logging.handlers
import os
import queue
import signal
import subprocess
import sys
import tempfile
import textwrap
import threading
import time
from unittest.mock import patch

import pytest

from mca_sdk.core.client import (
    MCAClient,
    _AuditPayload,
    _AuditQueueHandler,
    _AuditSpilloverFile,
)


def _make_client(**kwargs):
    defaults = {
        "service_name": f"audit-test-{id(kwargs)}",
        "model_id": "mdl-audit",
        "team_name": "team-audit",
        "model_type": "regression",
        "collector_endpoint": "http://localhost:4318",
        "strict_validation": False,
    }
    defaults.update(kwargs)
    return MCAClient(**defaults)


class TestAuditLoggerWiring:
    def test_audit_logger_attributes_present(self):
        client = _make_client()
        try:
            assert hasattr(client, "_audit_queue")
            assert isinstance(client._audit_queue, queue.Queue)
            assert hasattr(client, "_audit_queue_handler")
            assert isinstance(client._audit_queue_handler, _AuditQueueHandler)
            assert hasattr(client, "_audit_logger")
            assert isinstance(client._audit_logger, logging.Logger)
            assert hasattr(client, "_audit_listener")
            assert isinstance(client._audit_listener, logging.handlers.QueueListener)
        finally:
            client.shutdown()

    def test_audit_logger_does_not_propagate(self):
        client = _make_client()
        try:
            assert client._audit_logger.propagate is False
        finally:
            client.shutdown()

    def test_audit_logger_level_is_info(self):
        client = _make_client()
        try:
            assert client._audit_logger.level == logging.INFO
        finally:
            client.shutdown()

    def test_audit_logger_name_is_scoped(self):
        client = _make_client(service_name="scoped-svc")
        try:
            assert client._audit_logger.name == "scoped-svc.audit"
        finally:
            client.shutdown()

    def test_audit_logger_isolated_from_parent_level(self):
        """Parent logger level bumps must not silence the audit trail."""
        client = _make_client(service_name="isolation-svc")
        try:
            parent = logging.getLogger("isolation-svc")
            parent.setLevel(logging.CRITICAL)
            assert client._audit_logger.isEnabledFor(logging.INFO)
        finally:
            client.shutdown()


class TestCallingThreadOffload:
    def test_otel_emit_not_on_calling_thread(self):
        """logger.info() must not run OTel LoggingHandler.emit synchronously.

        Patch the OTel handler's emit() with a wrapper that captures the
        thread it runs on. Emitting from the main thread and then waiting
        for the listener to drain should show emit() ran on a different
        thread.
        """
        client = _make_client()
        try:
            calling_thread = threading.current_thread()
            emit_threads: list = []
            original_emit = client._otel_handler.emit

            def spy_emit(record):
                emit_threads.append(threading.current_thread())
                return original_emit(record)

            with patch.object(client._otel_handler, "emit", side_effect=spy_emit):
                client._audit_logger.info(
                    "test-emit",
                    extra={"prediction_id": "p-1"},
                )
                for _ in range(50):
                    if emit_threads:
                        break
                    time.sleep(0.02)

            assert emit_threads, "listener never drained the record"
            for t in emit_threads:
                assert (
                    t is not calling_thread
                ), "OTel emit ran on the calling thread; async offload failed"
        finally:
            client.shutdown()

    def test_logger_info_returns_without_blocking_on_emit(self):
        """If the listener is slow, calling-thread info() must still return."""
        client = _make_client()
        try:
            gate = threading.Event()
            original_emit = client._otel_handler.emit

            def slow_emit(record):
                gate.wait(timeout=5)
                return original_emit(record)

            with patch.object(client._otel_handler, "emit", side_effect=slow_emit):
                start = time.perf_counter()
                client._audit_logger.info("slow-emit")
                elapsed = time.perf_counter() - start
                assert elapsed < 0.5, f"info() blocked for {elapsed:.3f}s — expected async"
                gate.set()
        finally:
            client.shutdown()


class TestListenerDelivery:
    def test_records_reach_otel_handler(self):
        client = _make_client()
        try:
            seen: list = []
            original_emit = client._otel_handler.emit

            def capture(record):
                seen.append(record)
                return original_emit(record)

            with patch.object(client._otel_handler, "emit", side_effect=capture):
                for i in range(5):
                    client._audit_logger.info(
                        "r-%d" % i,
                        extra={"prediction_id": f"p-{i}"},
                    )
                deadline = time.time() + 3.0
                while time.time() < deadline and len(seen) < 5:
                    time.sleep(0.02)

            assert len(seen) == 5
            ids = {r.__dict__.get("prediction_id") for r in seen}
            assert ids == {f"p-{i}" for i in range(5)}
        finally:
            client.shutdown()


class TestShutdownDrain:
    def test_shutdown_drains_pending_records(self):
        """All records enqueued before shutdown must be emitted before
        listener teardown; none silently lost."""
        client = _make_client()
        seen: list = []
        original_emit = client._otel_handler.emit

        def capture(record):
            seen.append(record)
            return original_emit(record)

        with patch.object(client._otel_handler, "emit", side_effect=capture):
            for i in range(20):
                client._audit_logger.info(
                    "shutdown-%d" % i,
                    extra={"prediction_id": f"sd-{i}"},
                )
            client.shutdown()

        audit_records = [r for r in seen if r.name.endswith(".audit")]
        assert (
            len(audit_records) == 20
        ), f"expected 20 audit records drained, saw {len(audit_records)}"
        ids = {r.__dict__.get("prediction_id") for r in audit_records}
        assert ids == {f"sd-{i}" for i in range(20)}


class TestOverflowPolicy:
    """New HIPAA-compliant overflow policy: spillover JSON-lines file first,
    blocking put as last resort. Stderr is reserved for critical fallback
    *after* both spillover and blocking fail — no silent drops."""

    def test_queue_full_spills_to_disk(self, tmp_path):
        spill = _AuditSpilloverFile(directory=str(tmp_path))
        q: queue.Queue = queue.Queue(maxsize=1)
        handler = _AuditQueueHandler(q, spillover=spill)
        q.put_nowait(
            logging.LogRecord(
                "seed",
                logging.INFO,
                "",
                0,
                "seed",
                None,
                None,
            )
        )

        rec = logging.LogRecord(
            name="overflow",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="dropped-to-disk",
            args=None,
            exc_info=None,
        )
        rec.prediction_id = "p-overflow"

        handler.enqueue(rec)

        assert spill.path is not None
        assert os.path.exists(spill.path)
        with open(spill.path, "r", encoding="utf-8") as f:
            lines = [json.loads(line) for line in f if line.strip()]
        assert len(lines) == 1
        payload = lines[0]
        assert payload["message"] == "dropped-to-disk"
        assert payload["level"] == "INFO"
        assert payload["extra"]["prediction_id"] == "p-overflow"

    def test_queue_full_does_not_raise(self, tmp_path):
        spill = _AuditSpilloverFile(directory=str(tmp_path))
        q: queue.Queue = queue.Queue(maxsize=1)
        handler = _AuditQueueHandler(q, spillover=spill)
        q.put_nowait(
            logging.LogRecord(
                "seed",
                logging.INFO,
                "",
                0,
                "seed",
                None,
                None,
            )
        )
        rec = logging.LogRecord(
            "overflow",
            logging.INFO,
            "",
            0,
            "x",
            None,
            None,
        )
        handler.enqueue(rec)  # must not raise

    def test_queue_not_full_normal_enqueue(self, tmp_path):
        spill = _AuditSpilloverFile(directory=str(tmp_path))
        q: queue.Queue = queue.Queue(maxsize=10)
        handler = _AuditQueueHandler(q, spillover=spill)
        rec = logging.LogRecord(
            "ok",
            logging.INFO,
            "",
            0,
            "msg",
            None,
            None,
        )
        handler.enqueue(rec)
        assert q.qsize() == 1
        got = q.get_nowait()
        assert got is rec


class TestFastPath:
    """Fast-path hot-path bypass of stdlib logger machinery (finding 2)."""

    def test_hot_path_bypasses_stdlib_logger(self):
        """record_prediction must NOT call `_audit_logger.info` on the hot
        path. If the fast path bypass works, patching the logger to raise
        will not break record_prediction()."""
        client = _make_client()
        try:
            with patch.object(
                client._audit_logger,
                "info",
                side_effect=RuntimeError("hot path must not use logger.info"),
            ):
                client.record_prediction(
                    latency=0.01,
                    prediction_id="pred-fast-1",
                )
        finally:
            client.shutdown()

    def test_enqueue_audit_fast_delivers_record(self):
        """Fast-path payloads must reach _otel_handler.emit on a background
        thread, not on the calling thread."""
        client = _make_client()
        try:
            calling_thread = threading.current_thread()
            emit_threads: list = []
            seen: list = []
            original_emit = client._otel_handler.emit

            def capture(record):
                emit_threads.append(threading.current_thread())
                seen.append(record)
                return original_emit(record)

            with patch.object(client._otel_handler, "emit", side_effect=capture):
                for i in range(5):
                    client._enqueue_audit_fast(f"fast-{i}", {"prediction_id": f"fp-{i}"})
                deadline = time.time() + 3.0
                while time.time() < deadline and len(seen) < 5:
                    time.sleep(0.02)

            assert len(seen) == 5
            ids = {r.__dict__.get("prediction_id") for r in seen}
            assert ids == {f"fp-{i}" for i in range(5)}
            for t in emit_threads:
                assert (
                    t is not calling_thread
                ), "fast-path emit ran on calling thread — offload failed"
        finally:
            client.shutdown()


class TestSpillover:
    """Spillover-file HIPAA overflow path (finding 3)."""

    def test_spillover_on_queue_full_writes_structured_jsonl(self, tmp_path):
        spill = _AuditSpilloverFile(directory=str(tmp_path))
        rec = logging.LogRecord(
            name="svc.audit",
            level=logging.INFO,
            pathname="",
            lineno=0,
            msg="spilled",
            args=None,
            exc_info=None,
        )
        rec.prediction_id = "p-spill"
        rec.model_id = "mdl-x"

        assert spill.write(rec) is True

        assert spill.path is not None
        with open(spill.path, "r", encoding="utf-8") as f:
            payload = json.loads(f.readline())
        assert payload["message"] == "spilled"
        assert payload["level"] == "INFO"
        assert payload["name"] == "svc.audit"
        assert payload["extra"]["prediction_id"] == "p-spill"
        assert payload["extra"]["model_id"] == "mdl-x"
        assert "timestamp_ns" in payload

    def test_spillover_replay_emits_and_truncates(self, tmp_path):
        spill = _AuditSpilloverFile(directory=str(tmp_path))

        for i in range(3):
            rec = logging.LogRecord(
                name="svc.audit",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg=f"replay-{i}",
                args=None,
                exc_info=None,
            )
            rec.prediction_id = f"rp-{i}"
            spill.write(rec)

        emitted: list = []
        count = spill.drain(lambda r: emitted.append(r))

        assert count == 3
        assert {r.getMessage() for r in emitted} == {f"replay-{i}" for i in range(3)}
        assert {r.__dict__.get("prediction_id") for r in emitted} == {f"rp-{i}" for i in range(3)}
        assert not os.path.exists(spill.path)

    def test_blocking_fallback_when_spillover_disabled(self, tmp_path):
        """If spillover is disabled, the handler must block on put() instead
        of dropping — HIPAA invariant."""
        q: queue.Queue = queue.Queue(maxsize=1)
        q.put_nowait(
            logging.LogRecord(
                "seed",
                logging.INFO,
                "",
                0,
                "seed",
                None,
                None,
            )
        )

        # Spillover that always fails (directory cannot be created).
        spill = _AuditSpilloverFile(directory=str(tmp_path))
        spill._disabled = True

        handler = _AuditQueueHandler(q, spillover=spill)
        rec = logging.LogRecord(
            "block",
            logging.INFO,
            "",
            0,
            "must-block",
            None,
            None,
        )

        # Drainer that empties the queue to let the blocking put succeed.
        drained: list = []

        def drainer():
            time.sleep(0.2)
            try:
                drained.append(q.get(timeout=2.0))
            except queue.Empty:
                pass

        t = threading.Thread(target=drainer, daemon=True)
        t.start()

        start = time.perf_counter()
        handler.enqueue(rec)
        elapsed = time.perf_counter() - start
        t.join(timeout=5.0)

        # Must have blocked briefly (drainer sleeps 0.2s) rather than
        # returning immediately like a silent drop.
        assert (
            elapsed >= 0.15
        ), f"handler did not block (elapsed={elapsed:.3f}s); HIPAA invariant violated"
        # And the queue must now contain our record (drained by the thread).
        assert any(r is rec for r in drained) or q.qsize() >= 1

    def test_spillover_rotates_at_size_cap(self, tmp_path):
        spill = _AuditSpilloverFile(directory=str(tmp_path))
        # Shrink the cap for test speed.
        spill._MAX_BYTES = 256
        for i in range(50):
            rec = logging.LogRecord(
                name="svc.audit",
                level=logging.INFO,
                pathname="",
                lineno=0,
                msg="rotate" * 20,
                args=None,
                exc_info=None,
            )
            rec.idx = i
            spill.write(rec)
        # At least one rotation file must exist.
        rotated = [p for p in os.listdir(tmp_path) if p.endswith(".1") or ".jsonl." in p]
        assert rotated, "spillover did not rotate when over size cap"


class TestAuditDisabledFlag:
    """MCA_DISABLE_AUDIT_LOG=true isolates OTLP cost in Block C harness."""

    def test_fast_path_noop_when_audit_disabled(self, monkeypatch):
        monkeypatch.setenv("MCA_DISABLE_AUDIT_LOG", "true")
        client = _make_client(service_name="audit-disabled-svc")
        try:
            seen: list = []
            original_emit = client._otel_handler.emit

            def capture(record):
                seen.append(record)
                return original_emit(record)

            with patch.object(client._otel_handler, "emit", side_effect=capture):
                for i in range(5):
                    client._enqueue_audit_fast(f"x-{i}", {"prediction_id": f"d-{i}"})
                time.sleep(0.3)

            # Nothing should have been emitted via fast path.
            assert not any(r.__dict__.get("prediction_id", "").startswith("d-") for r in seen)
        finally:
            client.shutdown()


class TestSignalHandlers:
    """atexit / SIGTERM drain under Kubernetes-style eviction (finding 8)."""

    def _write_driver_script(self, tmp_path, body: str) -> str:
        script = tmp_path / "driver.py"
        script.write_text(body)
        return str(script)

    def test_atexit_handler_registered(self):
        client = _make_client(service_name="atexit-svc")
        try:
            assert client._atexit_registered is True
        finally:
            client.shutdown()

    def test_sigterm_handler_installed_on_main_thread(self):
        """On main thread with no pre-existing SIGTERM handler, the SDK
        installs one. Reset to default after the test."""
        prior = signal.getsignal(signal.SIGTERM)
        try:
            signal.signal(signal.SIGTERM, signal.SIG_DFL)
            client = _make_client(service_name="sigterm-svc")
            try:
                installed = signal.getsignal(signal.SIGTERM)
                # Must be callable (the bound SDK handler), not SIG_DFL.
                assert callable(installed)
            finally:
                client.shutdown()
        finally:
            signal.signal(signal.SIGTERM, prior)

    def test_sigterm_respects_preexisting_handler(self):
        """If the host app already installed a SIGTERM handler, SDK must not
        clobber it."""
        prior = signal.getsignal(signal.SIGTERM)
        sentinel_called: list = []

        def user_handler(signum, frame):
            sentinel_called.append(True)

        try:
            signal.signal(signal.SIGTERM, user_handler)
            client = _make_client(service_name="preexisting-svc")
            try:
                installed = signal.getsignal(signal.SIGTERM)
                assert installed is user_handler, "SDK clobbered user-installed SIGTERM handler"
                assert client._signal_registered is False
            finally:
                client.shutdown()
        finally:
            signal.signal(signal.SIGTERM, prior)

    def test_disable_signal_handlers_env(self, monkeypatch):
        monkeypatch.setenv("MCA_DISABLE_SIGNAL_HANDLERS", "true")
        prior = signal.getsignal(signal.SIGTERM)
        try:
            signal.signal(signal.SIGTERM, signal.SIG_DFL)
            client = _make_client(service_name="nosig-svc")
            try:
                assert client._signal_registered is False
                assert signal.getsignal(signal.SIGTERM) == signal.SIG_DFL
            finally:
                client.shutdown()
        finally:
            signal.signal(signal.SIGTERM, prior)


class TestShutdownOrdering:
    """Shutdown must drain fast-path queue and spillover before listener stop
    and provider teardown (finding 8 — fragile teardown)."""

    def test_shutdown_drains_fast_path_before_provider_teardown(self):
        client = _make_client(service_name="shutdown-ordering-svc")
        seen: list = []
        original_emit = client._otel_handler.emit

        def capture(record):
            seen.append(record)
            return original_emit(record)

        with patch.object(client._otel_handler, "emit", side_effect=capture):
            for i in range(50):
                client._enqueue_audit_fast(f"so-{i}", {"prediction_id": f"so-{i}"})
            client.shutdown()

        ids = {r.__dict__.get("prediction_id") for r in seen}
        for i in range(50):
            assert (
                f"so-{i}" in ids
            ), f"fast-path record so-{i} was not drained before shutdown completed"
