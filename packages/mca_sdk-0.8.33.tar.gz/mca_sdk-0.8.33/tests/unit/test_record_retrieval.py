"""Behavioral tests for MCAClient.record_retrieval (RAG retrieval observation).

Pins the parallel-array contract from docs/api-contracts.md section 9.2:
- Single span per call with langfuse.observation.type="retrieval"
- 50-doc cardinality cap with truncation flag
- Min-max score normalization to [0, 1]
- Constant-score degenerate case yields all-1.0 with debug log
- Parallel-array length agreement enforced via ValidationError
- Non-finite scores rejected
- Sampling-rate sentinel always emitted
- Hybrid sibling spans share parent_retrieval_id, differ on source_system
- PHI caveat preserved in docstring (parity with record_llm_generation)
- Errors close the span with StatusCode.ERROR
"""

import logging
import uuid

import pytest
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import StatusCode

from mca_sdk.core.client import MCAClient
from mca_sdk.utils.exceptions import ValidationError


def _make_client_with_exporter():
    client = MCAClient(
        service_name="test-rag",
        model_id="mdl-rag-001",
        team_name="test-team",
        model_type="generative",
        model_category="internal",
        llm_provider="google",
        llm_model="gemini-2.0-flash-001",
        collector_endpoint="http://localhost:4318",
        strict_validation=False,
    )
    exporter = InMemorySpanExporter()
    client._tracer_provider.add_span_processor(SimpleSpanProcessor(exporter))
    return client, exporter


class TestRecordRetrievalHappyPath:
    def test_emits_retrieval_observation_attributes(self):
        client, exporter = _make_client_with_exporter()
        try:
            with client.record_retrieval(
                query="patient readmission risk factors",
                documents=[
                    {"id": "doc-1", "score": 0.92},
                    {"id": "doc-2", "score": 0.78},
                    {"id": "doc-3", "score": 0.51},
                ],
                score_metric="cosine",
                source_system="dense",
            ):
                pass

            spans = exporter.get_finished_spans()
            assert len(spans) == 1
            span = spans[0]
            assert span.name == "rag.retrieval"

            attrs = dict(span.attributes)
            assert attrs["langfuse.observation.type"] == "retrieval"
            assert attrs["gen_ai.rag.query"] == "patient readmission risk factors"
            assert attrs["gen_ai.rag.documents.count"] == 3
            assert tuple(attrs["gen_ai.rag.documents.ids"]) == ("doc-1", "doc-2", "doc-3")
            # Min-max normalized: [0.92, 0.78, 0.51] -> [1.0, ~0.659, 0.0]
            scores = list(attrs["gen_ai.rag.documents.scores"])
            assert scores[0] == pytest.approx(1.0)
            assert scores[-1] == pytest.approx(0.0)
            assert 0 < scores[1] < 1
            assert attrs["gen_ai.rag.documents.truncated"] is False
            assert attrs["gen_ai.rag.documents.score_metric"] == "cosine"
            assert attrs["gen_ai.rag.documents.source_system"] == "dense"
            assert attrs["gen_ai.rag.sampling_rate"] == pytest.approx(1.0)
            assert span.status.status_code == StatusCode.OK
            assert "gen_ai.latency_seconds" in attrs
        finally:
            client.shutdown(timeout_millis=2000)


class TestRecordRetrievalTruncation:
    def test_truncates_to_top_50_by_score(self):
        client, exporter = _make_client_with_exporter()
        try:
            # 60 documents with monotonically increasing scores so the
            # top-50 are docs 10..59 — but the SDK keeps insertion order
            # only after sorting by score desc. Easiest assertion: count
            # is 50 and truncated flag is True.
            docs = [{"id": f"doc-{i}", "score": float(i)} for i in range(60)]
            with client.record_retrieval(
                query="q",
                documents=docs,
                score_metric="bm25",
            ):
                pass

            spans = exporter.get_finished_spans()
            assert len(spans) == 1
            attrs = dict(spans[0].attributes)
            assert attrs["gen_ai.rag.documents.count"] == 50
            assert attrs["gen_ai.rag.documents.truncated"] is True
            assert len(attrs["gen_ai.rag.documents.ids"]) == 50
            assert len(attrs["gen_ai.rag.documents.scores"]) == 50
            # Top doc by score (id=59) must lead the truncated set.
            assert attrs["gen_ai.rag.documents.ids"][0] == "doc-59"
        finally:
            client.shutdown(timeout_millis=2000)


class TestRecordRetrievalNormalization:
    def test_min_max_normalizes_scores(self):
        client, exporter = _make_client_with_exporter()
        try:
            with client.record_retrieval(
                query="q",
                documents=[
                    {"id": "a", "score": 10.0},
                    {"id": "b", "score": 5.0},
                    {"id": "c", "score": 1.0},
                ],
                score_metric="dot_product",
            ):
                pass

            spans = exporter.get_finished_spans()
            attrs = dict(spans[0].attributes)
            scores = list(attrs["gen_ai.rag.documents.scores"])
            # Min-max: (10-1)/(10-1)=1, (5-1)/9=0.4444, (1-1)/9=0
            assert scores[0] == pytest.approx(1.0)
            assert scores[1] == pytest.approx(4.0 / 9.0)
            assert scores[2] == pytest.approx(0.0)
        finally:
            client.shutdown(timeout_millis=2000)

    def test_constant_score_yields_all_ones_and_logs_debug(self, caplog):
        client, exporter = _make_client_with_exporter()
        try:
            with caplog.at_level(logging.DEBUG, logger="mca_sdk"):
                with client.record_retrieval(
                    query="q",
                    documents=[
                        {"id": "a", "score": 7.0},
                        {"id": "b", "score": 7.0},
                        {"id": "c", "score": 7.0},
                    ],
                    score_metric="cosine",
                ):
                    pass

            spans = exporter.get_finished_spans()
            attrs = dict(spans[0].attributes)
            scores = list(attrs["gen_ai.rag.documents.scores"])
            assert scores == [pytest.approx(1.0)] * 3
            # Debug log emitted somewhere mentioning "zero spread".
            assert any(
                "zero spread" in record.message.lower()
                for record in caplog.records
                if record.levelno <= logging.DEBUG
            ), "expected debug log about constant-score case"
        finally:
            client.shutdown(timeout_millis=2000)


class TestRecordRetrievalValidation:
    def test_relevance_length_mismatch_raises(self):
        client, _ = _make_client_with_exporter()
        try:
            with pytest.raises(ValidationError, match="relevance length"):
                with client.record_retrieval(
                    query="q",
                    documents=[{"id": "a", "score": 0.9}, {"id": "b", "score": 0.5}],
                    relevance=["relevant"],  # length 1 != docs length 2
                ):
                    pass
        finally:
            client.shutdown(timeout_millis=2000)

    def test_non_finite_score_raises(self):
        client, _ = _make_client_with_exporter()
        try:
            with pytest.raises(ValidationError, match="finite"):
                with client.record_retrieval(
                    query="q",
                    documents=[{"id": "a", "score": float("inf")}],
                ):
                    pass
        finally:
            client.shutdown(timeout_millis=2000)

    def test_invalid_relevance_value_raises(self):
        client, _ = _make_client_with_exporter()
        try:
            with pytest.raises(ValidationError, match="relevance"):
                with client.record_retrieval(
                    query="q",
                    documents=[{"id": "a", "score": 0.5}],
                    relevance=["maybe"],
                ):
                    pass
        finally:
            client.shutdown(timeout_millis=2000)


class TestRecordRetrievalSamplingRate:
    def test_sampling_rate_attribute_always_present(self):
        client, exporter = _make_client_with_exporter()
        try:
            with client.record_retrieval(
                query="q",
                documents=[{"id": "a", "score": 0.5}],
                score_metric="cosine",
                sampling_rate=0.2,
            ):
                pass

            spans = exporter.get_finished_spans()
            attrs = dict(spans[0].attributes)
            assert attrs["gen_ai.rag.sampling_rate"] == pytest.approx(0.2)
        finally:
            client.shutdown(timeout_millis=2000)

    def test_default_sampling_rate_is_one(self):
        client, exporter = _make_client_with_exporter()
        try:
            with client.record_retrieval(
                query="q",
                documents=[{"id": "a", "score": 0.5}],
            ):
                pass
            attrs = dict(exporter.get_finished_spans()[0].attributes)
            assert attrs["gen_ai.rag.sampling_rate"] == pytest.approx(1.0)
        finally:
            client.shutdown(timeout_millis=2000)


class TestRecordRetrievalHybrid:
    def test_sibling_spans_share_parent_id_and_differ_on_source_system(self):
        client, exporter = _make_client_with_exporter()
        try:
            parent_id = str(uuid.uuid4())
            with client.record_retrieval(
                query="q",
                documents=[{"id": "a", "score": 0.9}],
                score_metric="cosine",
                source_system="dense",
                parent_retrieval_id=parent_id,
            ):
                pass
            with client.record_retrieval(
                query="q",
                documents=[{"id": "b", "score": 12.0}],
                score_metric="bm25",
                source_system="sparse",
                parent_retrieval_id=parent_id,
            ):
                pass

            spans = exporter.get_finished_spans()
            assert len(spans) == 2
            attrs0 = dict(spans[0].attributes)
            attrs1 = dict(spans[1].attributes)
            assert attrs0["gen_ai.rag.parent_retrieval_id"] == parent_id
            assert attrs1["gen_ai.rag.parent_retrieval_id"] == parent_id
            assert attrs0["gen_ai.rag.documents.source_system"] == "dense"
            assert attrs1["gen_ai.rag.documents.source_system"] == "sparse"
        finally:
            client.shutdown(timeout_millis=2000)


class TestRecordRetrievalErrorPath:
    def test_exception_closes_span_with_error_status(self):
        client, exporter = _make_client_with_exporter()
        try:
            with pytest.raises(RuntimeError, match="boom"):
                with client.record_retrieval(
                    query="q",
                    documents=[{"id": "a", "score": 0.5}],
                ):
                    raise RuntimeError("boom")

            spans = exporter.get_finished_spans()
            assert len(spans) == 1
            span = spans[0]
            assert span.status.status_code == StatusCode.ERROR
            attrs = dict(span.attributes)
            assert attrs.get("error") is True
            assert attrs.get("error.type") == "RuntimeError"
            assert "gen_ai.latency_seconds" in attrs
        finally:
            client.shutdown(timeout_millis=2000)


class TestRecordRetrievalDocstring:
    def test_docstring_carries_phi_caveat(self):
        # Parity with record_llm_generation: the docstring must warn
        # callers that PHI sanitization is their responsibility before
        # any query / document content is handed to the SDK.
        doc = MCAClient.record_retrieval.__doc__
        assert doc is not None
        assert "PHI" in doc
        assert "caller" in doc.lower()
