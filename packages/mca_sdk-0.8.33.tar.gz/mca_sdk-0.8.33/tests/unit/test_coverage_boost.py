"""Targeted coverage tests for low-coverage modules.

Covers: _version.py, buffering/queued_item.py, validation/result.py,
validation/rules.py, registry/models.py, utils/exceptions.py,
registry/telemetry.py.
"""

import pytest
from unittest.mock import MagicMock


class TestVersionModule:
    def test_version_importable(self):
        from mca_sdk._version import __version__, version, __version_tuple__

        assert isinstance(__version__, str)
        assert len(__version__) > 0
        assert isinstance(__version_tuple__, tuple)

    def test_version_commit_id(self):
        from mca_sdk._version import commit_id, __commit_id__

        # can be str or None
        assert commit_id is None or isinstance(commit_id, str)
        assert __commit_id__ == commit_id

    def test_version_tuple_has_three_parts(self):
        from mca_sdk._version import version_tuple

        assert len(version_tuple) >= 3

    def test_version_consistency(self):
        from mca_sdk._version import __version__, version

        assert __version__ == version


class TestQueuedItem:
    def test_basic_creation(self):
        from mca_sdk.buffering.queued_item import QueuedItem

        item = QueuedItem(data={"key": "value"})
        assert item.data == {"key": "value"}
        assert item.attempt_count == 0
        assert item.first_queued_at is not None
        assert item.last_error is None

    def test_first_queued_at_set_automatically(self):
        from mca_sdk.buffering.queued_item import QueuedItem
        from datetime import datetime, timezone

        before = datetime.now(timezone.utc)
        item = QueuedItem(data="test")
        after = datetime.now(timezone.utc)
        assert before <= item.first_queued_at <= after

    def test_explicit_first_queued_at(self):
        from mca_sdk.buffering.queued_item import QueuedItem
        from datetime import datetime, timezone

        ts = datetime(2026, 1, 1, tzinfo=timezone.utc)
        item = QueuedItem(data="test", first_queued_at=ts)
        assert item.first_queued_at == ts

    def test_attempt_count_increment(self):
        from mca_sdk.buffering.queued_item import QueuedItem

        item = QueuedItem(data="test", attempt_count=3)
        assert item.attempt_count == 3

    def test_last_error_set(self):
        from mca_sdk.buffering.queued_item import QueuedItem

        item = QueuedItem(data="test", last_error="Connection refused")
        assert item.last_error == "Connection refused"


class TestValidationResult:
    def test_valid_result(self):
        from mca_sdk.validation.result import ValidationResult

        result = ValidationResult(is_valid=True)
        assert result.is_valid is True
        assert result.missing_fields == []
        assert result.errors == []

    def test_invalid_result_with_errors(self):
        from mca_sdk.validation.result import ValidationResult

        result = ValidationResult(
            is_valid=False, missing_fields=["model.id"], errors=["model.id is required"]
        )
        assert result.is_valid is False
        assert "model.id" in result.missing_fields
        assert "model.id is required" in result.errors

    def test_str_valid(self):
        from mca_sdk.validation.result import ValidationResult

        result = ValidationResult(is_valid=True)
        assert str(result) == "Validation passed"

    def test_str_invalid(self):
        from mca_sdk.validation.result import ValidationResult

        result = ValidationResult(is_valid=False, errors=["field X missing"])
        assert "field X missing" in str(result)

    def test_contradictory_state_raises(self):
        from mca_sdk.validation.result import ValidationResult

        with pytest.raises(ValueError, match="cannot have missing_fields or errors"):
            ValidationResult(is_valid=True, errors=["some error"])

    def test_valid_with_errors_raises(self):
        from mca_sdk.validation.result import ValidationResult

        with pytest.raises(ValueError):
            ValidationResult(is_valid=True, missing_fields=["field"])


class TestValidationRules:
    def test_get_rules_internal_regression(self):
        from mca_sdk.validation.rules import get_validation_rules

        rules = get_validation_rules("internal", "regression")
        assert "service.name" in rules["required"]
        assert "model.id" in rules["required"]
        assert "service.version" in rules["optional"]

    def test_get_rules_internal_time_series(self):
        from mca_sdk.validation.rules import get_validation_rules

        rules = get_validation_rules("internal", "time-series")
        assert "model.id" in rules["required"]
        assert "team.name" in rules["required"]

    def test_get_rules_internal_classification(self):
        from mca_sdk.validation.rules import get_validation_rules

        rules = get_validation_rules("internal", "classification")
        assert "service.name" in rules["required"]
        assert "model.version" in rules["required"]

    def test_get_rules_internal_generative(self):
        from mca_sdk.validation.rules import get_validation_rules

        rules = get_validation_rules("internal", "generative")
        assert "llm.provider" in rules["required"]
        assert "llm.model" in rules["required"]
        assert "model.id" in rules["optional"]

    def test_get_rules_internal_agentic(self):
        from mca_sdk.validation.rules import get_validation_rules

        rules = get_validation_rules("internal", "agentic")
        assert "llm.provider" in rules["required"]
        assert "team.name" in rules["required"]

    def test_get_rules_vendor_wildcard(self):
        from mca_sdk.validation.rules import get_validation_rules

        rules = get_validation_rules("vendor", "anything")
        assert "vendor.name" in rules["required"]
        assert "service.name" in rules["required"]

    def test_get_rules_vendor_case_insensitive(self):
        from mca_sdk.validation.rules import get_validation_rules

        rules = get_validation_rules("VENDOR", "regression")
        assert "vendor.name" in rules["required"]

    def test_get_rules_returns_deep_copy(self):
        from mca_sdk.validation.rules import get_validation_rules

        rules1 = get_validation_rules("internal", "regression")
        rules2 = get_validation_rules("internal", "regression")
        rules1["required"].append("extra.field")
        assert "extra.field" not in rules2["required"]

    def test_get_rules_invalid_combination(self):
        from mca_sdk.validation.rules import get_validation_rules

        with pytest.raises(ValueError, match="No validation rules"):
            get_validation_rules("internal", "unknown-type")

    def test_constants_accessible(self):
        from mca_sdk.validation.rules import (
            ATTR_SERVICE_NAME,
            ATTR_MODEL_ID,
            ATTR_MODEL_VERSION,
            ATTR_TEAM_NAME,
            ATTR_LLM_PROVIDER,
            ATTR_LLM_MODEL,
            ATTR_VENDOR_NAME,
            VALIDATION_RULES,
        )

        assert ATTR_SERVICE_NAME == "service.name"
        assert ATTR_MODEL_ID == "model.id"
        assert len(VALIDATION_RULES) > 0


class TestRegistryModels:
    def _make_config(self, **kwargs):
        from mca_sdk.registry.models import ModelConfig

        defaults = dict(
            service_name="svc",
            model_id="mdl-001",
            model_version="1.0",
            team_name="team",
            model_type="regression",
            model_category="internal",
        )
        defaults.update(kwargs)
        return ModelConfig(**defaults)

    def test_basic_creation(self):
        config = self._make_config()
        assert config.service_name == "svc"
        assert config.model_type == "regression"
        assert config.model_category == "internal"

    def test_optional_fields_default(self):
        config = self._make_config()
        assert config.registry_id is None
        assert config.deployment_id is None
        assert config.thresholds == {}
        assert config.phi_fields == {}
        assert config.extra_resource == {}
        assert config.association_id_column is None

    def test_full_config(self):
        from mca_sdk.registry.models import ModelConfig

        config = ModelConfig(
            service_name="full-svc",
            model_id="mdl-full",
            model_version="2.0",
            team_name="team",
            model_type="classification",
            model_category="internal",
            registry_id="reg-123",
            deployment_id="dep-456",
            thresholds={"accuracy": 0.9},
            phi_fields={"patient_id": {"criticality": "high"}},
            extra_resource={"env": "prod"},
            association_id_column="encounter_id",
            created_at="2026-01-01",
            updated_at="2026-06-01",
        )
        assert config.registry_id == "reg-123"
        assert config.thresholds == {"accuracy": 0.9}
        assert config.association_id_column == "encounter_id"

    def test_legacy_internal_migration(self):
        from mca_sdk.registry.models import ModelConfig

        config = ModelConfig(
            service_name="s",
            model_id="m",
            model_version="v",
            team_name="t",
            model_type="internal",
            model_category=None,
        )
        assert config.model_category == "internal"
        assert config.model_type == "regression"

    def test_legacy_vendor_migration(self):
        from mca_sdk.registry.models import ModelConfig

        config = ModelConfig(
            service_name="s",
            model_id="m",
            model_version="v",
            team_name="t",
            model_type="vendor",
            model_category=None,
        )
        assert config.model_category == "vendor"
        assert config.model_type == "regression"

    def test_legacy_generative_migration(self):
        from mca_sdk.registry.models import ModelConfig

        config = ModelConfig(
            service_name="s",
            model_id="m",
            model_version="v",
            team_name="t",
            model_type="generative",
            model_category=None,
        )
        assert config.model_category == "internal"
        assert config.model_type == "generative"

    def test_invalid_model_category_without_legacy(self):
        from mca_sdk.registry.models import ModelConfig

        with pytest.raises(ValueError):
            ModelConfig(
                service_name="s",
                model_id="m",
                model_version="v",
                team_name="t",
                model_type="custom-type",
                model_category=None,
            )

    def test_invalid_model_category_with_new_taxonomy(self):
        from mca_sdk.registry.models import ModelConfig

        with pytest.raises(ValueError, match="model_category must be one of"):
            ModelConfig(
                service_name="s",
                model_id="m",
                model_version="v",
                team_name="t",
                model_type="regression",
                model_category="invalid-cat",
            )

    def test_invalid_model_type_with_new_taxonomy(self):
        from mca_sdk.registry.models import ModelConfig

        with pytest.raises(ValueError, match="model_type must be one of"):
            ModelConfig(
                service_name="s",
                model_id="m",
                model_version="v",
                team_name="t",
                model_type="invalid-type",
                model_category="internal",
            )

    def test_legacy_type_as_model_type_with_category_set(self):
        from mca_sdk.registry.models import ModelConfig

        with pytest.raises(ValueError, match="legacy value"):
            ModelConfig(
                service_name="s",
                model_id="m",
                model_version="v",
                team_name="t",
                model_type="internal",
                model_category="internal",
            )

    def test_deployment_config(self):
        from mca_sdk.registry.models import DeploymentConfig

        config = DeploymentConfig(
            deployment_id="dep-001",
            environment="production",
            region="us-east-1",
        )
        assert config.deployment_id == "dep-001"
        assert config.resource_overrides == {}

    def test_deployment_config_with_overrides(self):
        from mca_sdk.registry.models import DeploymentConfig

        config = DeploymentConfig(
            deployment_id="dep-001",
            environment="staging",
            region="us-west-2",
            resource_overrides={"zone": "az-1"},
        )
        assert config.resource_overrides == {"zone": "az-1"}

    def test_valid_model_types_constant(self):
        from mca_sdk.registry.models import VALID_MODEL_TYPES

        assert "regression" in VALID_MODEL_TYPES
        assert "generative" in VALID_MODEL_TYPES
        assert "agentic" in VALID_MODEL_TYPES

    def test_valid_model_categories_constant(self):
        from mca_sdk.registry.models import VALID_MODEL_CATEGORIES

        assert "internal" in VALID_MODEL_CATEGORIES
        assert "vendor" in VALID_MODEL_CATEGORIES


class TestExceptions:
    def test_mca_sdk_error_base(self):
        from mca_sdk.utils.exceptions import MCASDKError

        err = MCASDKError("test error")
        assert "test error" in str(err)

    def test_validation_error(self):
        from mca_sdk.utils.exceptions import ValidationError

        err = ValidationError(
            "validation failed",
            missing_fields=["field1"],
            invalid_fields={"field2": "bad value"},
            model_type="regression",
            model_category="internal",
        )
        assert err.missing_fields == ["field1"]
        assert err.invalid_fields == {"field2": "bad value"}
        assert err.model_type == "regression"
        assert err.model_category == "internal"

    def test_validation_error_defaults(self):
        from mca_sdk.utils.exceptions import ValidationError

        err = ValidationError("simple error")
        assert err.missing_fields == []
        assert err.invalid_fields == {}
        assert err.model_type is None

    def test_buffering_error(self):
        from mca_sdk.utils.exceptions import BufferingError, MCASDKError

        err = BufferingError("buffer full")
        assert isinstance(err, MCASDKError)
        assert "buffer full" in str(err)

    def test_configuration_error(self):
        from mca_sdk.utils.exceptions import ConfigurationError, MCASDKError

        err = ConfigurationError("bad config")
        assert isinstance(err, MCASDKError)

    def test_registry_error(self):
        from mca_sdk.utils.exceptions import RegistryError, MCASDKError

        err = RegistryError("registry issue")
        assert isinstance(err, MCASDKError)

    def test_registry_connection_error(self):
        from mca_sdk.utils.exceptions import RegistryConnectionError, RegistryError

        err = RegistryConnectionError("timeout")
        assert isinstance(err, RegistryError)

    def test_registry_config_not_found_error(self):
        from mca_sdk.utils.exceptions import RegistryConfigNotFoundError, RegistryError

        err = RegistryConfigNotFoundError("model not found")
        assert isinstance(err, RegistryError)

    def test_registry_auth_error(self):
        from mca_sdk.utils.exceptions import RegistryAuthError, RegistryError

        err = RegistryAuthError("unauthorized")
        assert isinstance(err, RegistryError)

    def test_config_not_found_error(self):
        from mca_sdk.utils.exceptions import ConfigNotFoundError, MCASDKError

        err = ConfigNotFoundError("no config")
        assert isinstance(err, MCASDKError)

    def test_security_error(self):
        from mca_sdk.utils.exceptions import SecurityError, MCASDKError

        err = SecurityError("security violation")
        assert isinstance(err, MCASDKError)

    def test_certificate_error_hierarchy(self):
        from mca_sdk.utils.exceptions import (
            CertificateError,
            CertificateLoadError,
            CertificateValidationError,
            CertificateExpiredError,
            CertificateNotLoadedError,
            SecurityError,
        )

        assert issubclass(CertificateError, SecurityError)
        assert issubclass(CertificateLoadError, CertificateError)
        assert issubclass(CertificateValidationError, CertificateError)
        assert issubclass(CertificateExpiredError, CertificateError)
        assert issubclass(CertificateNotLoadedError, CertificateError)

    def test_certificate_load_error(self):
        from mca_sdk.utils.exceptions import CertificateLoadError

        err = CertificateLoadError("file not found")
        assert "file not found" in str(err)

    def test_mca_error_sanitizes_token(self):
        import os
        from mca_sdk.utils.exceptions import MCASDKError

        # Set a fake token in env
        os.environ["MCA_REGISTRY_TOKEN"] = "super-secret-token"
        try:
            err = MCASDKError("failed with token super-secret-token in message")
            msg = str(err)
            assert "super-secret-token" not in msg
        finally:
            del os.environ["MCA_REGISTRY_TOKEN"]

    def test_mca_error_no_token(self):
        import os
        from mca_sdk.utils.exceptions import MCASDKError

        os.environ.pop("MCA_REGISTRY_TOKEN", None)
        err = MCASDKError("normal error message")
        assert "normal error message" in str(err)


class TestRegistryTelemetry:
    def test_init_with_meter(self):
        from mca_sdk.registry.telemetry import RegistryTelemetry

        mock_meter = MagicMock()
        mock_counter = MagicMock()
        mock_histogram = MagicMock()
        mock_meter.create_counter.return_value = mock_counter
        mock_meter.create_histogram.return_value = mock_histogram

        telemetry = RegistryTelemetry(meter=mock_meter)
        assert telemetry._meter is mock_meter
        assert mock_meter.create_counter.call_count == 3
        assert mock_meter.create_histogram.call_count == 1

    def test_record_success(self):
        from mca_sdk.registry.telemetry import RegistryTelemetry

        mock_meter = MagicMock()
        mock_counter = MagicMock()
        mock_histogram = MagicMock()
        mock_meter.create_counter.return_value = mock_counter
        mock_meter.create_histogram.return_value = mock_histogram

        telemetry = RegistryTelemetry(meter=mock_meter)
        telemetry.record_success(latency=0.125)
        mock_counter.add.assert_called()
        mock_histogram.record.assert_called_with(0.125)

    def test_record_error(self):
        from mca_sdk.registry.telemetry import RegistryTelemetry

        mock_meter = MagicMock()
        mock_counter = MagicMock()
        mock_histogram = MagicMock()
        mock_meter.create_counter.return_value = mock_counter
        mock_meter.create_histogram.return_value = mock_histogram

        telemetry = RegistryTelemetry(meter=mock_meter)
        telemetry.record_error("RegistryConnectionError")
        # The error counter should have been called with error_type attribute
        mock_counter.add.assert_called()

    def test_init_without_meter_uses_default(self):
        from mca_sdk.registry.telemetry import RegistryTelemetry
        from unittest.mock import patch

        mock_meter = MagicMock()
        mock_meter.create_counter.return_value = MagicMock()
        mock_meter.create_histogram.return_value = MagicMock()
        with patch("mca_sdk.registry.telemetry.metrics.get_meter", return_value=mock_meter):
            telemetry = RegistryTelemetry()
            assert telemetry._meter is mock_meter
