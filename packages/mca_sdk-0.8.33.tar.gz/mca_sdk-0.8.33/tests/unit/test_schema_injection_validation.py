"""Tests for validate_model_id and validate_service_name injection validation."""

import pytest

from mca_sdk.validation.schema import validate_model_id, validate_service_name
from mca_sdk.utils.exceptions import ValidationError


class TestValidateModelId:
    def test_valid_model_id_alphanumeric(self):
        assert validate_model_id("mdl001") is True

    def test_valid_model_id_with_hyphens(self):
        assert validate_model_id("mdl-001") is True

    def test_valid_model_id_with_underscores(self):
        assert validate_model_id("model_version_2") is True

    def test_empty_model_id_raises(self):
        with pytest.raises(ValidationError, match="cannot be empty"):
            validate_model_id("")

    def test_path_traversal_double_dot(self):
        with pytest.raises(ValidationError, match="path traversal"):
            validate_model_id("../etc/passwd")

    def test_path_traversal_forward_slash(self):
        with pytest.raises(ValidationError, match="path traversal"):
            validate_model_id("model/evil")

    def test_path_traversal_backslash(self):
        with pytest.raises(ValidationError, match="path traversal"):
            validate_model_id("model\\evil")

    def test_sql_injection_single_quote(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("model'001")

    def test_sql_injection_double_quote(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id('model"001')

    def test_sql_injection_semicolon(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("model;DROP TABLE")

    def test_sql_injection_double_dash(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("model--comment")

    def test_sql_injection_block_comment_open(self):
        with pytest.raises(ValidationError):
            validate_model_id("model/*comment")

    def test_sql_injection_block_comment_close(self):
        with pytest.raises(ValidationError):
            validate_model_id("model*/comment")

    def test_sql_injection_xp_prefix(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("xp_cmdshell")

    def test_sql_injection_sp_prefix(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("sp_executesql")

    def test_sql_injection_drop_keyword(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("modelDROP")

    def test_sql_injection_select_keyword(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("modelSELECT")

    def test_sql_injection_insert_keyword(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("modelINSERT")

    def test_sql_injection_update_keyword(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("modelUPDATE")

    def test_sql_injection_delete_keyword(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id("modelDELETE")

    def test_command_injection_pipe(self):
        with pytest.raises(ValidationError, match="command injection"):
            validate_model_id("model|cmd")

    def test_command_injection_ampersand(self):
        with pytest.raises(ValidationError, match="command injection"):
            validate_model_id("model&cmd")

    def test_command_injection_dollar(self):
        with pytest.raises(ValidationError, match="command injection"):
            validate_model_id("model$var")

    def test_command_injection_backtick(self):
        with pytest.raises(ValidationError, match="command injection"):
            validate_model_id("model`cmd`")

    def test_model_id_too_long_raises(self):
        long_id = "a" * 129
        with pytest.raises(ValidationError, match="maximum length"):
            validate_model_id(long_id)

    def test_model_id_exactly_max_length_valid(self):
        max_id = "a" * 128
        assert validate_model_id(max_id) is True

    def test_model_id_invalid_characters(self):
        with pytest.raises(ValidationError, match="alphanumeric"):
            validate_model_id("model@domain")


class TestValidateServiceName:
    def test_valid_service_name(self):
        assert validate_service_name("my-service") is True

    def test_valid_service_name_with_underscores(self):
        assert validate_service_name("my_service_v2") is True

    def test_empty_service_name_raises(self):
        with pytest.raises(ValidationError, match="cannot be empty"):
            validate_service_name("")

    def test_path_traversal_in_service_name(self):
        with pytest.raises(ValidationError, match="path traversal"):
            validate_service_name("../service")

    def test_sql_injection_in_service_name(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_service_name("service'; DROP TABLE users;--")

    def test_sql_injection_double_dash(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_service_name("service--comment")

    def test_sql_injection_block_comment(self):
        with pytest.raises(ValidationError):
            validate_service_name("service/*hack*/")

    def test_sql_injection_select_in_service(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_service_name("serviceSELECT")

    def test_sql_injection_drop_in_service(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_service_name("serviceDROP")

    def test_sql_injection_insert_in_service(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_service_name("serviceINSERT")

    def test_sql_injection_update_in_service(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_service_name("serviceUPDATE")

    def test_sql_injection_delete_in_service(self):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_service_name("serviceDELETE")

    def test_command_injection_pipe_in_service(self):
        with pytest.raises(ValidationError, match="command injection"):
            validate_service_name("service|cmd")

    def test_command_injection_ampersand_in_service(self):
        with pytest.raises(ValidationError, match="command injection"):
            validate_service_name("service&cmd")

    def test_command_injection_dollar_in_service(self):
        with pytest.raises(ValidationError, match="command injection"):
            validate_service_name("service$var")

    def test_command_injection_backtick_in_service(self):
        with pytest.raises(ValidationError, match="command injection"):
            validate_service_name("service`cmd`")
