"""Tests for mca_sdk/cli/run.py uncovered paths."""

import argparse
import os
import sys
from io import StringIO
from unittest.mock import MagicMock, Mock, patch

import pytest


class TestBuildParser:
    def test_parser_returns_argparse_instance(self):
        from mca_sdk.cli.run import build_parser

        parser = build_parser()
        assert isinstance(parser, argparse.ArgumentParser)

    def test_parser_accepts_model_id(self):
        from mca_sdk.cli.run import build_parser

        parser = build_parser()
        args = parser.parse_args(["--model-id", "mdl-001"])
        assert args.model_id == "mdl-001"

    def test_parser_accepts_team(self):
        from mca_sdk.cli.run import build_parser

        parser = build_parser()
        args = parser.parse_args(["--team", "clinical-ai"])
        assert args.team_name == "clinical-ai"

    def test_parser_debug_flag(self):
        from mca_sdk.cli.run import build_parser

        parser = build_parser()
        args = parser.parse_args(["--debug"])
        assert args.debug is True

    def test_parser_no_args(self):
        from mca_sdk.cli.run import build_parser

        parser = build_parser()
        args = parser.parse_args([])
        assert args.model_id is None
        assert args.team_name is None
        assert args.debug is False


class TestInjectEnvVars:
    def test_injects_model_id_from_args(self):
        from mca_sdk.cli.run import inject_env_vars

        args = argparse.Namespace(
            model_id="mdl-001",
            team_name=None,
            service_name=None,
            collector_endpoint=None,
            registry_url=None,
            debug=False,
        )
        env = inject_env_vars(args, env={})
        assert env["MCA_MODEL_ID"] == "mdl-001"

    def test_env_var_takes_precedence_over_args(self):
        from mca_sdk.cli.run import inject_env_vars

        args = argparse.Namespace(
            model_id="mdl-from-args",
            team_name=None,
            service_name=None,
            collector_endpoint=None,
            registry_url=None,
            debug=False,
        )
        env = {"MCA_MODEL_ID": "mdl-from-env"}
        result = inject_env_vars(args, env=env)
        assert result["MCA_MODEL_ID"] == "mdl-from-env"

    def test_service_name_defaults_to_model_id(self):
        from mca_sdk.cli.run import inject_env_vars

        args = argparse.Namespace(
            model_id="mdl-001",
            team_name="clinical-ai",
            service_name=None,
            collector_endpoint=None,
            registry_url=None,
            debug=False,
        )
        env = inject_env_vars(args, env={})
        assert env["MCA_SERVICE_NAME"] == "mdl-001"

    def test_debug_flag_sets_env_var(self):
        from mca_sdk.cli.run import inject_env_vars

        args = argparse.Namespace(
            model_id=None,
            team_name=None,
            service_name=None,
            collector_endpoint=None,
            registry_url=None,
            debug=True,
        )
        env = inject_env_vars(args, env={})
        assert env.get("MCA_DEBUG_MODE") == "true"

    def test_debug_not_set_when_already_in_env(self):
        from mca_sdk.cli.run import inject_env_vars

        args = argparse.Namespace(
            model_id=None,
            team_name=None,
            service_name=None,
            collector_endpoint=None,
            registry_url=None,
            debug=True,
        )
        env = {"MCA_DEBUG_MODE": "false"}
        result = inject_env_vars(args, env=env)
        assert result["MCA_DEBUG_MODE"] == "false"  # Original preserved

    def test_uses_os_environ_when_env_is_none(self):
        from mca_sdk.cli.run import inject_env_vars

        args = argparse.Namespace(
            model_id="mdl-001",
            team_name=None,
            service_name=None,
            collector_endpoint=None,
            registry_url=None,
            debug=False,
        )
        # env=None → uses os.environ.copy()
        result = inject_env_vars(args, env=None)
        assert "MCA_MODEL_ID" in result

    def test_collector_endpoint_injected(self):
        from mca_sdk.cli.run import inject_env_vars

        args = argparse.Namespace(
            model_id=None,
            team_name=None,
            service_name=None,
            collector_endpoint="http://collector:4318",
            registry_url=None,
            debug=False,
        )
        env = inject_env_vars(args, env={})
        assert env.get("MCA_COLLECTOR_ENDPOINT") == "http://collector:4318"


class TestValidateConfig:
    def test_returns_true_when_all_required_set(self):
        from mca_sdk.cli.run import validate_config

        env = {"MCA_MODEL_ID": "mdl-001", "MCA_TEAM_NAME": "clinical-ai"}
        assert validate_config(env) is True

    def test_returns_false_when_model_id_missing(self):
        from mca_sdk.cli.run import validate_config

        env = {"MCA_TEAM_NAME": "clinical-ai"}
        result = validate_config(env)
        assert result is False

    def test_returns_false_when_team_name_missing(self):
        from mca_sdk.cli.run import validate_config

        env = {"MCA_MODEL_ID": "mdl-001"}
        result = validate_config(env)
        assert result is False

    def test_returns_false_when_both_missing(self):
        from mca_sdk.cli.run import validate_config

        result = validate_config({})
        assert result is False

    def test_returns_false_when_value_is_empty_string(self):
        from mca_sdk.cli.run import validate_config

        env = {"MCA_MODEL_ID": "", "MCA_TEAM_NAME": "clinical-ai"}
        result = validate_config(env)
        assert result is False


class TestSetupBootstrapInjection:
    def test_creates_temp_dir_and_sets_pythonpath(self):
        from mca_sdk.cli.run import setup_bootstrap_injection

        env: dict = {}
        temp_dir = setup_bootstrap_injection(env)

        try:
            assert temp_dir is not None
            assert "PYTHONPATH" in env
            assert temp_dir in env["PYTHONPATH"]
        finally:
            import shutil

            shutil.rmtree(temp_dir, ignore_errors=True)

    def test_prepends_to_existing_pythonpath(self):
        from mca_sdk.cli.run import setup_bootstrap_injection

        env = {"PYTHONPATH": "/existing/path"}
        temp_dir = setup_bootstrap_injection(env)

        try:
            assert "/existing/path" in env["PYTHONPATH"]
            assert temp_dir in env["PYTHONPATH"]
        finally:
            import shutil

            shutil.rmtree(temp_dir, ignore_errors=True)


class TestRunCommand:
    def test_file_not_found_returns_127(self):
        from mca_sdk.cli.run import run_command

        result = run_command(["nonexistent_command_xyz_abc"], env={})
        assert result == 127

    def test_successful_command_returns_zero(self):
        from mca_sdk.cli.run import run_command

        result = run_command([sys.executable, "-c", "pass"], env=os.environ.copy())
        assert result == 0

    def test_failing_command_returns_nonzero(self):
        from mca_sdk.cli.run import run_command

        result = run_command([sys.executable, "-c", "raise SystemExit(1)"], env=os.environ.copy())
        assert result == 1

    def test_python_command_triggers_bootstrap_injection(self):
        from mca_sdk.cli.run import run_command

        env = os.environ.copy()
        # python command → triggers setup_bootstrap_injection
        result = run_command([sys.executable, "-c", "pass"], env=env)
        assert result == 0

    def test_exception_returns_1(self):
        from mca_sdk.cli.run import run_command

        with patch("subprocess.Popen", side_effect=PermissionError("denied")):
            result = run_command(["some_cmd"], env={})
        assert result == 1


class TestMain:
    def test_main_no_command_returns_2(self):
        from mca_sdk.cli.run import main

        with patch.object(sys, "argv", ["mca-run", "--model-id", "mdl-001", "--"]):
            result = main()
        assert result == 2

    def test_main_missing_config_returns_2(self):
        from mca_sdk.cli.run import main

        # No model_id → validate_config fails
        with patch.object(sys, "argv", ["mca-run", "--", sys.executable, "-c", "pass"]):
            with patch.dict(os.environ, {}, clear=True):
                result = main()
        assert result == 2

    def test_main_runs_successfully(self):
        from mca_sdk.cli.run import main

        with patch.object(
            sys,
            "argv",
            [
                "mca-run",
                "--model-id",
                "mdl-001",
                "--team",
                "clinical-ai",
                "--",
                sys.executable,
                "-c",
                "pass",
            ],
        ):
            with patch.dict(os.environ, {}, clear=True):
                result = main()
        assert result == 0

    def test_main_no_separator_parses_command(self):
        from mca_sdk.cli.run import main

        # Without --, still parses command
        with patch.object(sys, "argv", ["mca-run", sys.executable, "-c", "pass"]):
            with patch.dict(
                os.environ,
                {"MCA_MODEL_ID": "mdl-001", "MCA_TEAM_NAME": "clinical-ai"},
                clear=False,
            ):
                result = main()
        assert result == 0
