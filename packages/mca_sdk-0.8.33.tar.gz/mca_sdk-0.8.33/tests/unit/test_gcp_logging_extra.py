"""Tests for uncovered paths in gcp_logging.py."""

import threading
from unittest.mock import Mock, MagicMock, patch

import pytest

from opentelemetry.sdk._logs.export import LogRecordExportResult


def _make_exporter(mock_cloud_logging=None):
    """Create a CloudLoggingExporter with mocked google-cloud-logging."""
    if mock_cloud_logging is None:
        mock_cloud_logging = MagicMock()
    with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")
    exporter._cloud_logging = mock_cloud_logging
    return exporter


def _make_log_record(body="Test message", severity="INFO", attributes=None, resource=None):
    record = Mock()
    record.body = Mock(value=body)
    record.severity_text = severity
    record.attributes = attributes or {}
    if resource is not None:
        record.resource = resource
    else:
        record.resource = Mock(attributes={"service.name": "svc"})
    return record


class TestCloudLoggingExporterErrorPaths:
    def test_export_403_forbidden_logs_permission_error(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client
        mock_logger.log_struct.side_effect = Exception("403 Forbidden")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

        exporter._cloud_logging = mock_cloud_logging
        result = exporter.export([_make_log_record()])
        assert result == LogRecordExportResult.FAILURE

    def test_export_401_unauthorized_logs_auth_error(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client
        mock_logger.log_struct.side_effect = Exception("401 Unauthorized")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

        exporter._cloud_logging = mock_cloud_logging
        result = exporter.export([_make_log_record()])
        assert result == LogRecordExportResult.FAILURE

    def test_export_404_not_found_logs_project_error(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client
        mock_logger.log_struct.side_effect = Exception("404 Not Found")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

        exporter._cloud_logging = mock_cloud_logging
        result = exporter.export([_make_log_record()])
        assert result == LogRecordExportResult.FAILURE

    def test_export_429_quota_logs_quota_error(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client
        mock_logger.log_struct.side_effect = Exception("429 Quota exceeded")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

        exporter._cloud_logging = mock_cloud_logging
        result = exporter.export([_make_log_record()])
        assert result == LogRecordExportResult.FAILURE

    def test_export_timeout_logs_timeout_error(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client
        mock_logger.log_struct.side_effect = Exception("timeout connecting to server")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

        exporter._cloud_logging = mock_cloud_logging
        result = exporter.export([_make_log_record()])
        assert result == LogRecordExportResult.FAILURE

    def test_export_generic_error_logs_generic_message(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client
        mock_logger.log_struct.side_effect = RuntimeError("some unexpected error")

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

        exporter._cloud_logging = mock_cloud_logging
        result = exporter.export([_make_log_record()])
        assert result == LogRecordExportResult.FAILURE

    def test_shutdown_when_client_is_set(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

        exporter._cloud_logging = mock_cloud_logging
        exporter._client = mock_client  # Set client directly to test shutdown path
        exporter.shutdown()  # Should not raise

    def test_shutdown_when_client_is_none(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")
        exporter._cloud_logging = mock_cloud_logging
        exporter.shutdown()  # Should not raise

    def test_force_flush_returns_true(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")
        exporter._cloud_logging = mock_cloud_logging
        assert exporter.force_flush() is True


class TestExportLogRecordPaths:
    def _make_exporter(self):
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")
        exporter._cloud_logging = mock_cloud_logging
        return exporter, mock_logger

    def test_body_with_no_value_attr_uses_str(self):
        exporter, mock_logger = self._make_exporter()
        record = Mock()
        record.body = "plain string body"
        record.severity_text = "INFO"
        record.attributes = {}
        record.resource = Mock(attributes={})
        result = exporter.export([record])
        assert result == LogRecordExportResult.SUCCESS

    def test_body_is_none_uses_empty_string(self):
        exporter, mock_logger = self._make_exporter()
        record = Mock()
        record.body = None
        record.log_record = None
        record.severity_text = "INFO"
        record.attributes = {}
        record.resource = Mock(attributes={})
        result = exporter.export([record])
        assert result == LogRecordExportResult.SUCCESS

    def test_long_message_is_truncated(self):
        exporter, mock_logger = self._make_exporter()
        long_msg = "x" * 1500
        record = Mock()
        record.body = Mock(value=long_msg)
        record.severity_text = "WARNING"
        record.attributes = {}
        record.resource = Mock(attributes={})
        result = exporter.export([record])
        assert result == LogRecordExportResult.SUCCESS
        call_args = mock_logger.log_struct.call_args
        assert "...[truncated]" in call_args[0][0]["message"]

    def test_attributes_are_sanitized_to_cloud_logging_limits(self):
        exporter, mock_logger = self._make_exporter()
        record = Mock()
        record.body = Mock(value="msg")
        record.severity_text = "INFO"
        record.attributes = {"key": "value", "k" * 70: "v" * 70}
        record.resource = Mock(attributes={})
        result = exporter.export([record])
        assert result == LogRecordExportResult.SUCCESS

    def test_resource_obj_creation_falls_back_on_error(self):
        exporter, mock_logger = self._make_exporter()
        # Make Resource constructor raise AttributeError
        exporter._cloud_logging.Resource.side_effect = AttributeError("no Resource")
        record = Mock()
        record.body = Mock(value="msg")
        record.severity_text = "INFO"
        record.attributes = {}
        record.resource = Mock(attributes={})
        result = exporter.export([record])
        assert result == LogRecordExportResult.SUCCESS

    def test_none_severity_defaults_to_info(self):
        exporter, mock_logger = self._make_exporter()
        record = Mock()
        record.body = Mock(value="msg")
        record.severity_text = "UNKNOWN_LEVEL"
        record.attributes = {}
        record.resource = Mock(attributes={})
        result = exporter.export([record])
        assert result == LogRecordExportResult.SUCCESS


class TestBufferedCloudLoggingExporter:
    def _make_buffered_exporter(self):
        from mca_sdk.exporters.gcp_logging import BufferedCloudLoggingExporter

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = BufferedCloudLoggingExporter(
                project_id="test-project",
                log_name="test-log",
            )
        exporter._exporter._cloud_logging = mock_cloud_logging
        return exporter, mock_logger

    def test_init_creates_exporter_and_queue(self):
        exporter, _ = self._make_buffered_exporter()
        assert exporter._queue is not None
        assert exporter._retry_policy is not None
        assert exporter._worker_thread is None

    def test_export_success_path(self):
        exporter, mock_logger = self._make_buffered_exporter()
        record = Mock()
        record.body = Mock(value="msg")
        record.severity_text = "INFO"
        record.attributes = {}
        record.resource = Mock(attributes={})
        result = exporter.export([record])
        assert result == LogRecordExportResult.SUCCESS

    def test_export_queues_on_failure(self):
        exporter, mock_logger = self._make_buffered_exporter()
        mock_logger.log_struct.side_effect = Exception("service unavailable")
        record = Mock()
        record.body = Mock(value="msg")
        record.severity_text = "ERROR"
        record.attributes = {}
        record.resource = Mock(attributes={})
        result = exporter.export([record])
        # Should return SUCCESS because it was queued
        assert result in (LogRecordExportResult.SUCCESS, LogRecordExportResult.FAILURE)

    def test_start_background_worker_starts_thread(self):
        exporter, _ = self._make_buffered_exporter()
        exporter.start_background_worker()
        assert exporter._worker_thread is not None
        assert exporter._worker_thread.is_alive()
        exporter.shutdown()

    def test_start_background_worker_noop_if_already_running(self):
        exporter, _ = self._make_buffered_exporter()
        exporter.start_background_worker()
        thread1 = exporter._worker_thread
        exporter.start_background_worker()  # Should be a no-op
        assert exporter._worker_thread is thread1
        exporter.shutdown()

    def test_shutdown_stops_worker_thread(self):
        exporter, _ = self._make_buffered_exporter()
        exporter.start_background_worker()
        assert exporter._worker_thread.is_alive()
        exporter.shutdown()

    def test_force_flush_returns_true(self):
        exporter, _ = self._make_buffered_exporter()
        result = exporter.force_flush()
        assert result is True

    def test_getattr_delegates_to_underlying_exporter(self):
        exporter, _ = self._make_buffered_exporter()
        assert exporter.project_id == "test-project"

    def test_queue_for_retry_when_queue_full(self):
        exporter, mock_logger = self._make_buffered_exporter()
        # Fill up the queue
        exporter._max_retry_queue_size = 0
        record = Mock()
        record.body = Mock(value="msg")
        record.severity_text = "INFO"
        record.attributes = {}
        record.resource = Mock(attributes={})
        # Force exception in underlying exporter so it falls back to queue
        mock_logger.log_struct.side_effect = Exception("down")
        result = exporter.export([record])
        assert result == LogRecordExportResult.FAILURE
