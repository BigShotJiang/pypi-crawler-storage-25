# Boundary regression suite for tests/support/logging_overhead.is_stdlib_logging_frame.
# Pins the predicate against the substring-bug regressions that were inflating
# the logging-overhead SLO measurement, plus the deeper failure modes a naive
# string check is vulnerable to (user dirs named "logging", custom logging.py,
# Windows mixed separators, single-file vs package layouts).
import os

import pytest

from tests.support.logging_overhead import is_stdlib_logging_frame

# Synthetic stdlib path injected into the predicate. The real runtime path
# (logging.__file__) is asserted separately in TestRuntimeIntrospection.
_FAKE_STDLIB_DIR = "/usr/lib/python3.10/logging"
_FAKE_STDLIB_FILE = "/usr/lib/python3.10/logging/__init__.py"


def _frame(*parts: str) -> str:
    return os.sep + os.sep.join(parts)


class TestStdlibPositiveCases:
    """Real stdlib logging frames must match."""

    @pytest.mark.parametrize(
        "filename",
        [
            "/usr/lib/python3.10/logging/__init__.py",
            "/usr/lib/python3.10/logging/handlers.py",
            "/usr/lib/python3.10/logging/config.py",
            "/usr/lib/python3.10/logging/filterer.py",
            # Nested modules in the package (defensive — none exist today,
            # but the predicate must not regress if cpython adds one).
            "/usr/lib/python3.10/logging/_internal/helpers.py",
        ],
    )
    def test_files_inside_stdlib_package_dir_match(self, filename: str) -> None:
        assert (
            is_stdlib_logging_frame(
                filename,
                stdlib_dir=_FAKE_STDLIB_DIR,
                stdlib_file=_FAKE_STDLIB_FILE,
            )
            is True
        )

    def test_single_file_install_matches(self) -> None:
        # Some vendored Python builds ship logging as a flat module.
        assert (
            is_stdlib_logging_frame(
                "/embedded/python/lib/logging.py",
                stdlib_dir="/embedded/python/lib/logging",  # may not exist
                stdlib_file="/embedded/python/lib/logging.py",
            )
            is True
        )


class TestSubstringRegressions:
    """The substring filter `if "log" in func_name.lower()` matched these
    incidental names. The introspection-based predicate must reject them all.
    """

    @pytest.mark.parametrize(
        "filename",
        [
            "/site-packages/sqlalchemy/orm/catalog.py",
            "/usr/lib/python3.10/tkinter/dialog.py",
            "/site-packages/torch/utils/data/dataloader.py",
            "/site-packages/numpy/lib/analog.py",
            "/home/user/project/mylog_helpers.py",
            "/home/user/project/backlog.py",
            "/home/user/project/prologue.py",
            "/home/user/mca-prototype/mca_sdk/core/client.py",
        ],
    )
    def test_lookalike_substrings_rejected(self, filename: str) -> None:
        assert (
            is_stdlib_logging_frame(
                filename,
                stdlib_dir=_FAKE_STDLIB_DIR,
                stdlib_file=_FAKE_STDLIB_FILE,
            )
            is False
        )


class TestUserNamedLoggingBoundaries:
    """Direct boundary cases the original os.sep-based string match got
    wrong: user code in a directory or file *literally named* `logging`
    that has nothing to do with the stdlib package.
    """

    @pytest.mark.parametrize(
        "filename",
        [
            # User app directory named `logging`.
            "/opt/app/logging/main.py",
            "/opt/app/logging/util.py",
            # Custom script literally named logging.py.
            "/app/utils/logging.py",
            "/home/dev/scripts/logging.py",
            # Nested user directory tree containing `logging` as a segment.
            "/dev/logging/script.py",
            "/srv/services/logging/server.py",
            # Mid-segment (string match would have triggered the original bug).
            "/var/lib/mylogging/runtime.py",
            "/opt/loggingd/main.py",
            # Co-located stdlib name in unrelated tree.
            "/projects/foo/logging.py",
        ],
    )
    def test_user_paths_named_logging_rejected(self, filename: str) -> None:
        assert (
            is_stdlib_logging_frame(
                filename,
                stdlib_dir=_FAKE_STDLIB_DIR,
                stdlib_file=_FAKE_STDLIB_FILE,
            )
            is False
        )


class TestWindowsAndMixedSeparators:
    """cProfile occasionally emits paths with mixed separators on Windows
    or under certain emulation layers. The predicate must normalize before
    comparing.
    """

    def test_windows_native_path_matches_stdlib(self) -> None:
        assert (
            is_stdlib_logging_frame(
                r"C:\Python310\Lib\logging\__init__.py",
                stdlib_dir=r"C:\Python310\Lib\logging",
                stdlib_file=r"C:\Python310\Lib\logging\__init__.py",
            )
            is True
        )

    def test_windows_mixed_separators_match_stdlib(self) -> None:
        # cProfile sometimes emits forward-slash paths on Windows.
        assert (
            is_stdlib_logging_frame(
                "C:/Python310/Lib/logging/handlers.py",
                stdlib_dir=r"C:\Python310\Lib\logging",
                stdlib_file=r"C:\Python310\Lib\logging\__init__.py",
            )
            is True
        )

    def test_windows_user_named_logging_rejected(self) -> None:
        # User app dir named logging on Windows must NOT match stdlib.
        assert (
            is_stdlib_logging_frame(
                r"C:\Users\dev\app\logging\main.py",
                stdlib_dir=r"C:\Python310\Lib\logging",
                stdlib_file=r"C:\Python310\Lib\logging\__init__.py",
            )
            is False
        )


class TestDefensiveInputs:
    """Empty strings, cProfile pseudo-paths, and other malformed inputs
    must never raise and must default to False.
    """

    @pytest.mark.parametrize(
        "filename",
        [
            "",
            "<frozen importlib._bootstrap>",
            "<built-in>",
            "<string>",
            "logging.py",  # bare basename, no directory context
            "loggin",  # truncated — should not match
        ],
    )
    def test_malformed_inputs_return_false(self, filename: str) -> None:
        assert (
            is_stdlib_logging_frame(
                filename,
                stdlib_dir=_FAKE_STDLIB_DIR,
                stdlib_file=_FAKE_STDLIB_FILE,
            )
            is False
        )


class TestRuntimeIntrospection:
    """Confirm the predicate uses the actual runtime stdlib path when no
    overrides are passed — guards against the override mechanism silently
    becoming the only code path that works.
    """

    def test_runtime_stdlib_init_matches(self) -> None:
        import logging as stdlib_logging

        assert is_stdlib_logging_frame(stdlib_logging.__file__) is True

    def test_runtime_stdlib_sibling_module_matches(self) -> None:
        import logging.handlers as handlers

        # logging.handlers lives inside the same package directory.
        assert is_stdlib_logging_frame(handlers.__file__) is True

    def test_runtime_unrelated_module_rejected(self) -> None:
        import os as os_mod

        assert is_stdlib_logging_frame(os_mod.__file__) is False
