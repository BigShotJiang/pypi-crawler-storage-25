"""Unit tests for small helpers and edge cases in mca_sdk/buffering/queue.py:
peek, is_empty, is_full, size, clear, _str_to_bool, _is_production_environment,
and a lightweight enqueue/dequeue flow. Added for story 6-33 coverage climb."""

import os

import pytest

from mca_sdk.buffering.queue import TelemetryQueue


@pytest.fixture
def queue():
    return TelemetryQueue(max_size=10)


class TestQueuePrimitives:
    def test_peek_empty_returns_none(self, queue):
        assert queue.peek() is None

    def test_is_empty_on_fresh_queue(self, queue):
        assert queue.is_empty() is True

    def test_size_matches_enqueue_count(self, queue):
        assert queue.size() == 0
        queue.enqueue({"k": 1})
        queue.enqueue({"k": 2})
        assert queue.size() == 2

    def test_peek_returns_oldest_item(self, queue):
        queue.enqueue("first")
        queue.enqueue("second")
        assert queue.peek() == "first"
        # peek does not remove
        assert queue.size() == 2

    def test_is_full_when_at_max(self, queue):
        for i in range(10):
            queue.enqueue(i)
        assert queue.is_full() is True

    def test_is_full_when_below_max(self, queue):
        queue.enqueue("only-one")
        assert queue.is_full() is False

    def test_clear_returns_count_and_empties(self, queue):
        queue.enqueue("a")
        queue.enqueue("b")
        queue.enqueue("c")
        n = queue.clear()
        assert n == 3
        assert queue.is_empty() is True

    def test_clear_on_empty_returns_zero(self, queue):
        assert queue.clear() == 0

    def test_dequeue_fifo_order(self, queue):
        queue.enqueue("first")
        queue.enqueue("second")
        assert queue.dequeue() == "first"
        assert queue.dequeue() == "second"
        assert queue.dequeue() is None

    def test_dequeue_batch(self, queue):
        for i in range(5):
            queue.enqueue(i)
        batch = queue.dequeue_batch(3)
        assert batch == [0, 1, 2]
        assert queue.size() == 2

    def test_dequeue_batch_larger_than_queue(self, queue):
        queue.enqueue(42)
        batch = queue.dequeue_batch(10)
        assert batch == [42]
        assert queue.is_empty()


class TestStrToBool:
    @pytest.mark.parametrize(
        "value, expected",
        [
            ("true", True),
            ("TRUE", True),
            ("True", True),
            ("1", True),
            ("yes", True),
            ("YES", True),
            ("on", True),
            ("ON", True),
            ("false", False),
            ("0", False),
            ("no", False),
            ("off", False),
            ("", False),
            ("random-string", False),
        ],
    )
    def test_str_to_bool(self, value, expected):
        assert TelemetryQueue._str_to_bool(value) is expected


class TestBufferStats:
    def test_buffer_stats_returns_dict(self, queue):
        queue.enqueue({"a": 1})
        queue.enqueue({"b": 2})
        stats = queue.buffer_stats()
        assert isinstance(stats, dict)
        assert stats.get("size") == 2
        assert stats.get("max_size") == 10
        # Utilization is reported as a percentage (0-100) or a 0-1 ratio
        # depending on implementation. Just assert it's a sensible number.
        util = stats.get("utilization")
        if util is not None:
            assert util >= 0


class TestIsProductionEnvironment:
    def test_respects_env_var_true(self, monkeypatch, queue):
        monkeypatch.setenv("MCA_ENV", "production")
        # The method is instance-level; call via instance
        result = queue._is_production_environment()
        assert isinstance(result, bool)

    def test_respects_env_var_dev(self, monkeypatch, queue):
        monkeypatch.setenv("MCA_ENV", "development")
        result = queue._is_production_environment()
        assert isinstance(result, bool)


class TestQueueBoundaries:
    """Failure-boundary tests added in adversarial-review remediation (F10).

    The previous test suite had no enqueue-past-max, dequeue-from-empty-after-
    drain, or concurrent-access boundary checks — exactly the cases most likely
    to regress when the queue's locking or maxlen semantics change.
    """

    def test_enqueue_past_max_size_drops_oldest_and_logs(self, caplog):
        import logging

        q = TelemetryQueue(max_size=3)
        for i in range(3):
            assert q.enqueue(f"item-{i}") is True
        assert q.size() == 3

        with caplog.at_level(logging.WARNING, logger="mca_sdk.buffering.queue"):
            ret = q.enqueue("overflow")

        # When the queue is at capacity, enqueue must (a) evict the oldest,
        # (b) keep size at max_size, (c) log a WARNING with the capacity, and
        # (d) signal overflow via the return value (False).
        assert ret is False, "enqueue at capacity must return False to signal overflow"
        assert q.size() == 3, "size must remain capped at max_size"
        assert q.peek() == "item-1", "oldest item must be evicted FIFO"

        warns = [
            r
            for r in caplog.records
            if r.levelno == logging.WARNING and "queue full" in r.getMessage().lower()
        ]
        assert len(warns) == 1
        assert "size=3" in warns[0].getMessage()

    def test_dequeue_empty_after_fill_and_drain_returns_none(self, queue):
        # Fill, drain to empty, then dequeue again. Must return None (not raise,
        # not return a stale item, not return an empty list when the contract
        # is single-item dequeue).
        for i in range(3):
            queue.enqueue(i)
        for _ in range(3):
            queue.dequeue()
        assert queue.is_empty()
        assert queue.dequeue() is None
        # And dequeue_batch on empty must return [] (not None, not exception)
        assert queue.dequeue_batch(5) == []

    def test_concurrent_enqueue_dequeue_thread_safety_smoke(self):
        # Smoke test for the queue's threading.Lock. Spin two threads briefly
        # against the same queue and assert: (a) no exception leaks out,
        # (b) the size accounting stays self-consistent (size == enq - deq).
        import threading
        import time

        q = TelemetryQueue(max_size=200)
        stop = threading.Event()
        enqueued = [0]
        dequeued = [0]
        errors = []

        def producer():
            try:
                while not stop.is_set():
                    if q.enqueue({"n": enqueued[0]}):
                        enqueued[0] += 1
            except Exception as exc:
                errors.append(("producer", exc))

        def consumer():
            try:
                while not stop.is_set():
                    if q.dequeue() is not None:
                        dequeued[0] += 1
            except Exception as exc:
                errors.append(("consumer", exc))

        t1 = threading.Thread(target=producer)
        t2 = threading.Thread(target=consumer)
        t1.start()
        t2.start()
        time.sleep(0.05)
        stop.set()
        t1.join(timeout=1.0)
        t2.join(timeout=1.0)

        assert not errors, f"thread errors: {errors}"
        # size == enqueued - dequeued (the queue swallowed neither items nor
        # raised silently). enqueued may exceed dequeued only by what's
        # currently in the queue.
        assert q.size() == enqueued[0] - dequeued[0]
