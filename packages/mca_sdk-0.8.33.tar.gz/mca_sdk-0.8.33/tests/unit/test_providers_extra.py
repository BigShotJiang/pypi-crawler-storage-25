"""Tests for uncovered paths in core/providers.py."""

import sys
from unittest.mock import Mock, MagicMock, patch

import pytest

from opentelemetry.sdk.resources import Resource


def _make_resource():
    return Resource.create({"service.name": "test-svc"})


class TestSetupLoggerProviderGCPPaths:
    def test_gcp_logging_missing_project_id_raises(self):
        from mca_sdk.core.providers import setup_logger_provider
        from mca_sdk.utils.exceptions import ConfigurationError

        resource = _make_resource()
        gcp_config = Mock()
        gcp_config.gcp_logging_enabled = True
        gcp_config.gcp_project_id = None  # Missing
        gcp_config.gcp_log_name = "test-log"

        with pytest.raises(ConfigurationError, match="gcp_project_id or gcp_log_name is unset"):
            setup_logger_provider(resource=resource, gcp_config=gcp_config)

    def test_gcp_logging_missing_log_name_raises(self):
        from mca_sdk.core.providers import setup_logger_provider
        from mca_sdk.utils.exceptions import ConfigurationError

        resource = _make_resource()
        gcp_config = Mock()
        gcp_config.gcp_logging_enabled = True
        gcp_config.gcp_project_id = "my-project"
        gcp_config.gcp_log_name = None  # Missing

        with pytest.raises(ConfigurationError, match="gcp_project_id or gcp_log_name is unset"):
            setup_logger_provider(resource=resource, gcp_config=gcp_config)

    def test_gcp_logging_no_buffering_uses_cloud_logging_exporter(self):
        from mca_sdk.core.providers import setup_logger_provider

        resource = _make_resource()
        gcp_config = Mock()
        gcp_config.gcp_logging_enabled = True
        gcp_config.gcp_project_id = "my-project"
        gcp_config.gcp_log_name = "my-log"
        gcp_config.gcp_resource_type = "gce_instance"
        gcp_config.gcp_credentials = None
        gcp_config.gcp_log_timeout = 30

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict(sys.modules, {"google.cloud.logging": mock_cloud_logging}):
            provider, buffered = setup_logger_provider(
                resource=resource, gcp_config=gcp_config, use_buffering=False
            )

        assert provider is not None
        assert buffered is None

    def test_gcp_logging_disabled_skips_gcp_exporter(self):
        from mca_sdk.core.providers import setup_logger_provider

        resource = _make_resource()
        gcp_config = Mock()
        gcp_config.gcp_logging_enabled = False

        provider, buffered = setup_logger_provider(resource=resource, gcp_config=gcp_config)
        assert provider is not None


class TestSetupPrometheusExporter:
    def test_prometheus_not_installed_returns_none(self):
        from mca_sdk.core.providers import setup_prometheus_exporter

        with patch.dict(
            sys.modules,
            {
                "opentelemetry.exporter.prometheus": None,
                "prometheus_client": None,
            },
        ):
            reader, shutdown = setup_prometheus_exporter(prometheus_enabled=True)

        assert reader is None
        assert shutdown is None

    def test_prometheus_disabled_returns_none(self):
        from mca_sdk.core.providers import setup_prometheus_exporter

        reader, shutdown = setup_prometheus_exporter(prometheus_enabled=False)
        assert reader is None
        assert shutdown is None

    def test_prometheus_oserror_other_returns_none(self):
        from mca_sdk.core.providers import setup_prometheus_exporter

        mock_prometheus = MagicMock()
        mock_prometheus.make_wsgi_app.side_effect = OSError("Network unreachable")

        with patch.dict(sys.modules, {"prometheus_client": mock_prometheus}):
            try:
                reader, shutdown = setup_prometheus_exporter(
                    prometheus_enabled=True, prometheus_port=19464
                )
                # If we get here, it should be None,None
                assert reader is None
                assert shutdown is None
            except Exception:
                pass  # ImportError or other exceptions are acceptable


class TestSetupMeterProviderErrors:
    def test_meter_provider_shutdown_raises_configuration_error(self):
        from mca_sdk.core.providers import setup_meter_provider
        from mca_sdk.utils.exceptions import ConfigurationError
        from opentelemetry.sdk.metrics import MeterProvider

        resource = _make_resource()

        # Set up a real provider that gets shut down
        real_provider = MeterProvider(resource=resource)
        real_provider.shutdown()

        with patch("mca_sdk.core.providers.metrics") as mock_metrics:
            mock_metrics.get_meter_provider.return_value = real_provider

            with pytest.raises(ConfigurationError, match="shut down"):
                setup_meter_provider(resource=resource)
