"""Unit tests for genai metric `model_id` attribute parity.

Verifies that ``MCALiteLLMCallback`` attaches the BHSF-registered ``model_id``
to every emitted genai metric datapoint AND to the correlated span on both
the success and failure paths, with a resolution order of (1) per-call
kwargs override, then (2) the cached MCAClient config default, then (3)
the literal string ``"unspecified"`` (config gap) or ``"error"`` (SDK
defect from a misbehaving metadata payload).

The collector in this repo disables ``resource_to_telemetry_conversion``,
so resource-level attributes do not surface as Prometheus labels;
``model_id`` must live on the datapoint attribute set itself. Spans
additionally carry ``mca.model_id`` (SDK-internal namespace) plus the
unprefixed ``model_id`` for parity with the metric label that
alert-policy-sync already keys on.
"""

from datetime import datetime, timedelta
from types import SimpleNamespace
from typing import Any

import pytest
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import InMemoryMetricReader
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
    InMemorySpanExporter,
)

from mca_sdk.integrations.litellm_callback import (
    MCALiteLLMCallback,
    _sanitize_model_id_label,
)


def _make_stub_client(meter, *, model_id="mdl-test-001", tracer_provider=None):
    """Build a minimal MCAClient-shaped stub the callback can bind to."""
    config = SimpleNamespace(
        capture_input_data=False,
        capture_output_data=False,
        model_id=model_id,
    )
    if tracer_provider is None:
        tracer_provider = TracerProvider(resource=Resource.create({"service.name": "stub"}))
    tracer = tracer_provider.get_tracer("stub")
    import logging

    logger = logging.getLogger("mca_test_stub")
    return SimpleNamespace(
        config=config,
        meter=meter,
        tracer=tracer,
        logger=logger,
        _data_sanitizer_hook=None,
        _capture_max_size_bytes=32768,
    )


@pytest.fixture
def reader_provider_meter():
    reader = InMemoryMetricReader()
    provider = MeterProvider(
        resource=Resource.create({"service.name": "litellm-parity-test"}),
        metric_readers=[reader],
    )
    meter = provider.get_meter("test")
    yield reader, provider, meter
    provider.shutdown()


@pytest.fixture
def span_capture():
    """Capture spans from the test tracer into an in-memory exporter."""
    exporter = InMemorySpanExporter()
    tracer_provider = TracerProvider(resource=Resource.create({"service.name": "stub"}))
    tracer_provider.add_span_processor(SimpleSpanProcessor(exporter))
    yield exporter, tracer_provider
    tracer_provider.shutdown()


def _success_response(latency_seconds: float = 0.25):
    """Mock LiteLLM ModelResponse-like object."""
    usage = SimpleNamespace(prompt_tokens=10, completion_tokens=5, total_tokens=15)
    choices = [SimpleNamespace(message=SimpleNamespace(content="hi"), text="hi")]
    return SimpleNamespace(usage=usage, choices=choices)


def _collect_attribute_sets(reader: InMemoryMetricReader) -> dict[str, list[dict]]:
    """Return mapping {metric_name: [attributes_dict, ...]} from the reader."""
    out: dict[str, list[dict]] = {}
    md = reader.get_metrics_data()
    if md is None:
        return out
    for rm in md.resource_metrics:
        for sm in rm.scope_metrics:
            for metric in sm.metrics:
                points = list(metric.data.data_points)
                out.setdefault(metric.name, []).extend(dict(p.attributes) for p in points)
    return out


# ---------------------------------------------------------------------------
# Sanitizer helper unit tests (F6/F7/F8/F1).
# ---------------------------------------------------------------------------


def test_sanitizer_returns_none_for_none():
    assert _sanitize_model_id_label(None) is None


def test_sanitizer_strips_whitespace():
    assert _sanitize_model_id_label("  mdl-001  ") == "mdl-001"


def test_sanitizer_returns_none_for_whitespace_only():
    assert _sanitize_model_id_label("   ") is None
    assert _sanitize_model_id_label("\t\n") is None


def test_sanitizer_truncates_at_64_chars():
    long = "x" * 200
    out = _sanitize_model_id_label(long)
    assert out is not None
    assert len(out) == 64


def test_sanitizer_accepts_zero_int():
    # F1: integer 0 must survive — `if override:` would have discarded it.
    assert _sanitize_model_id_label(0) == "0"


def test_sanitizer_accepts_int_and_bool():
    assert _sanitize_model_id_label(42) == "42"
    assert _sanitize_model_id_label(True) == "True"


def test_sanitizer_rejects_complex_object():
    # F8: a plain object would str() to a memory address; reject it.
    class Foo:
        pass

    assert _sanitize_model_id_label(Foo()) is None
    assert _sanitize_model_id_label([1, 2, 3]) is None
    assert _sanitize_model_id_label({"a": 1}) is None


# ---------------------------------------------------------------------------
# Success / failure metric-path parity tests.
# ---------------------------------------------------------------------------


def test_success_path_attaches_model_id_to_all_metrics(reader_provider_meter):
    reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-test-001")
    cb = MCALiteLLMCallback(client=client)

    start = datetime.now()
    end = start + timedelta(milliseconds=250)
    cb.log_success_event(
        kwargs={"model": "gpt-4", "litellm_call_id": "c1"},
        response_obj=_success_response(),
        start_time=start,
        end_time=end,
    )

    by_name = _collect_attribute_sets(reader)
    for metric_name in (
        "genai.requests_total",
        "genai.tokens_total",
        "genai.latency_seconds",
    ):
        assert metric_name in by_name, f"{metric_name} not emitted"
        for attrs in by_name[metric_name]:
            assert (
                attrs.get("model_id") == "mdl-test-001"
            ), f"{metric_name} missing model_id; attrs={attrs}"


def test_failure_path_attaches_model_id_to_all_metrics(reader_provider_meter):
    reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-test-001")
    cb = MCALiteLLMCallback(client=client)

    start = datetime.now()
    end = start + timedelta(milliseconds=80)
    cb.log_failure_event(
        kwargs={"model": "gpt-4", "litellm_call_id": "c2"},
        response_obj=RuntimeError("boom"),
        start_time=start,
        end_time=end,
    )

    by_name = _collect_attribute_sets(reader)
    for metric_name in (
        "genai.requests_total",
        "genai.requests_failed_total",
        "genai.latency_seconds",
    ):
        assert metric_name in by_name, f"{metric_name} not emitted"
        for attrs in by_name[metric_name]:
            assert (
                attrs.get("model_id") == "mdl-test-001"
            ), f"{metric_name} missing model_id; attrs={attrs}"


def test_per_call_metadata_override_wins(reader_provider_meter):
    reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    start = datetime.now()
    end = start + timedelta(milliseconds=120)
    cb.log_success_event(
        kwargs={
            "model": "gpt-4",
            "litellm_call_id": "c3",
            "metadata": {"mca_model_id": "mdl-override-002"},
        },
        response_obj=_success_response(),
        start_time=start,
        end_time=end,
    )

    by_name = _collect_attribute_sets(reader)
    for attrs in by_name["genai.requests_total"]:
        assert attrs.get("model_id") == "mdl-override-002"
    for attrs in by_name["genai.latency_seconds"]:
        assert attrs.get("model_id") == "mdl-override-002"


def test_resolver_returns_unspecified_when_client_config_is_none(reader_provider_meter):
    """Cached default is computed at __init__ — runtime mutation does not invalidate it.

    Repo policy (CHANGELOG 0.8.x: identity fields immutable after startup)
    makes the cached default the contract. Mutating ``cb._client.config``
    post-init must not change resolution.
    """
    reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-cached-default")
    cb = MCALiteLLMCallback(client=client)
    cb._client.config = None  # post-init mutation must not invalidate cache

    start = datetime.now()
    end = start + timedelta(milliseconds=50)
    cb.log_failure_event(
        kwargs={"model": "gpt-4", "litellm_call_id": "c4"},
        response_obj=ValueError("x"),
        start_time=start,
        end_time=end,
    )

    by_name = _collect_attribute_sets(reader)
    for attrs in by_name["genai.requests_failed_total"]:
        assert attrs.get("model_id") == "mdl-cached-default"


def test_resolver_returns_unspecified_when_model_id_is_none(reader_provider_meter):
    reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id=None)
    cb = MCALiteLLMCallback(client=client)

    start = datetime.now()
    end = start + timedelta(milliseconds=50)
    cb.log_success_event(
        kwargs={"model": "gpt-4", "litellm_call_id": "c5"},
        response_obj=_success_response(),
        start_time=start,
        end_time=end,
    )

    by_name = _collect_attribute_sets(reader)
    for attrs in by_name["genai.requests_total"]:
        # AC mandates the literal string "unspecified", not "" or missing
        assert attrs.get("model_id") == "unspecified"


def test_per_call_pydantic_style_metadata_override_wins(reader_provider_meter):
    """Pydantic-shape / SimpleNamespace metadata is honored too."""
    reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    pydantic_like_metadata = SimpleNamespace(mca_model_id="mdl-pyd-001")

    start = datetime.now()
    end = start + timedelta(milliseconds=100)
    cb.log_success_event(
        kwargs={
            "model": "gpt-4",
            "litellm_call_id": "c-pyd",
            "metadata": pydantic_like_metadata,
        },
        response_obj=_success_response(),
        start_time=start,
        end_time=end,
    )

    by_name = _collect_attribute_sets(reader)
    for attrs in by_name["genai.requests_total"]:
        assert attrs.get("model_id") == "mdl-pyd-001"
    for attrs in by_name["genai.latency_seconds"]:
        assert attrs.get("model_id") == "mdl-pyd-001"


# ---------------------------------------------------------------------------
# New failure-mode tests for the rewritten resolver.
# ---------------------------------------------------------------------------


def test_zero_int_override_wins_over_default(reader_provider_meter):
    """F1: integer 0 is a legitimate override and must survive resolution."""
    _reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    out = cb._resolve_model_id({"metadata": {"mca_model_id": 0}})
    assert out == "0"


def test_whitespace_only_override_falls_through_to_default(reader_provider_meter):
    """F7: whitespace-only override is rejected; cached default wins."""
    _reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    assert cb._resolve_model_id({"metadata": {"mca_model_id": "   "}}) == "mdl-default-001"


def test_oversize_override_is_truncated_to_64_chars(reader_provider_meter):
    """F6: bound the label cardinality to 64 chars after .strip()."""
    _reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    long_id = "x" * 200
    out = cb._resolve_model_id({"metadata": {"mca_model_id": long_id}})
    assert len(out) == 64
    assert out == "x" * 64


def test_complex_object_override_is_rejected(reader_provider_meter):
    """F8: a non-scalar object stringifies to a memory address; reject it."""
    _reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    class Junk:
        pass

    out = cb._resolve_model_id({"metadata": {"mca_model_id": Junk()}})
    assert out == "mdl-default-001"  # falls through to cached default


def test_resolver_returns_error_sentinel_when_metadata_access_raises(reader_provider_meter):
    """F4/F5: a misbehaving metadata object yields the 'error' sentinel.

    Differentiating ``"error"`` from ``"unspecified"`` lets operators tell
    an SDK defect (or buggy caller) apart from a configuration gap.
    """
    _reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    class ExplodingMetadata:
        @property
        def mca_model_id(self):  # noqa: D401
            # TypeError (not AttributeError) — the 3-arg getattr() silently
            # swallows AttributeError and returns the default, which would
            # never reach the resolver's except clause.
            raise TypeError("synthetic metadata access failure")

    out = cb._resolve_model_id({"metadata": ExplodingMetadata()})
    assert out == "error"


def test_resolver_warns_only_once_per_callback_instance(reader_provider_meter, caplog):
    """F4: deduplicated warning — many bad calls yield at most one log line."""
    import logging

    _reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    class ExplodingMetadata:
        @property
        def mca_model_id(self):  # noqa: D401
            # TypeError so 3-arg getattr() doesn't swallow it before the
            # resolver's targeted except handler fires.
            raise TypeError("boom")

    caplog.set_level(logging.WARNING, logger=client.logger.name)
    for _ in range(5):
        cb._resolve_model_id({"metadata": ExplodingMetadata()})

    warnings = [r for r in caplog.records if r.levelno >= logging.WARNING]
    assert len(warnings) == 1


def test_non_dict_kwargs_propagates_attributeerror(reader_provider_meter):
    """F11: the resolver no longer hides upstream type-contract violations.

    The public callback methods type ``kwargs`` as ``Dict[str, Any]``; a
    non-dict argument is a type-contract violation, not a configuration
    gap, and must surface as an AttributeError so the public-callback
    boundary catches it (rather than silently masking it as "unspecified").
    """
    _reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    with pytest.raises(AttributeError):
        cb._resolve_model_id("not-a-dict")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Span-side parity tests (F2, F3, F9).
# ---------------------------------------------------------------------------


def test_success_path_attaches_model_id_to_span(reader_provider_meter, span_capture):
    """F2/F3/F9: spans gain mca.model_id (and legacy unprefixed model_id)."""
    _reader, _provider, meter = reader_provider_meter
    exporter, tracer_provider = span_capture
    client = _make_stub_client(meter, model_id="mdl-test-001", tracer_provider=tracer_provider)
    cb = MCALiteLLMCallback(client=client)

    cb.log_pre_api_call(model="gpt-4", messages=[], kwargs={"litellm_call_id": "c-span-ok"})
    start = datetime.now()
    end = start + timedelta(milliseconds=250)
    cb.log_success_event(
        kwargs={"model": "gpt-4", "litellm_call_id": "c-span-ok"},
        response_obj=_success_response(),
        start_time=start,
        end_time=end,
    )

    spans = exporter.get_finished_spans()
    assert spans, "expected the success span to have been exported"
    span = spans[-1]
    assert span.attributes.get("mca.model_id") == "mdl-test-001"
    assert span.attributes.get("model_id") == "mdl-test-001"


def test_failure_path_attaches_model_id_to_span(reader_provider_meter, span_capture):
    """F2/F9: failure spans gain mca.model_id parity with the metric label."""
    _reader, _provider, meter = reader_provider_meter
    exporter, tracer_provider = span_capture
    client = _make_stub_client(meter, model_id="mdl-test-001", tracer_provider=tracer_provider)
    cb = MCALiteLLMCallback(client=client)

    cb.log_pre_api_call(model="gpt-4", messages=[], kwargs={"litellm_call_id": "c-span-err"})
    start = datetime.now()
    end = start + timedelta(milliseconds=80)
    cb.log_failure_event(
        kwargs={"model": "gpt-4", "litellm_call_id": "c-span-err"},
        response_obj=RuntimeError("boom"),
        start_time=start,
        end_time=end,
    )

    spans = exporter.get_finished_spans()
    assert spans, "expected the failure span to have been exported"
    span = spans[-1]
    assert span.attributes.get("mca.model_id") == "mdl-test-001"
    assert span.attributes.get("model_id") == "mdl-test-001"


# ---------------------------------------------------------------------------
# Direct-resolver branch coverage.
# ---------------------------------------------------------------------------


def test_resolver_unit_returns_string_for_each_branch(reader_provider_meter):
    """Direct unit check on the resolver function across each resolution branch."""
    _reader, _provider, meter = reader_provider_meter
    client = _make_stub_client(meter, model_id="mdl-default-001")
    cb = MCALiteLLMCallback(client=client)

    # Per-call override (dict metadata).
    assert cb._resolve_model_id({"metadata": {"mca_model_id": "mdl-x"}}) == "mdl-x"
    # Per-call override via attribute-style metadata.
    assert (
        cb._resolve_model_id({"metadata": SimpleNamespace(mca_model_id="mdl-attr")}) == "mdl-attr"
    )
    # Bound client default (cached at __init__).
    assert cb._resolve_model_id({}) == "mdl-default-001"
    # Cached default survives runtime mutation of client.config.
    cb._client.config = None
    assert cb._resolve_model_id({}) == "mdl-default-001"
    # Cached default survives runtime mutation of client itself.
    cb._client = None  # type: ignore[assignment]
    assert cb._resolve_model_id({}) == "mdl-default-001"
