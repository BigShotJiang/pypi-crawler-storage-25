"""Unit tests for cli/instrument.py pure-function helpers: build_parser,
inject_env_vars (env-vs-arg precedence, OTEL mapping), find_otel_instrument,
validate_config, and main() arg-parse branching (the -- separator fallback
path). Does not test run_instrumented (subprocess). Added for story 6-33."""

import sys

import pytest

from mca_sdk.cli.instrument import (
    build_parser,
    find_otel_instrument,
    inject_env_vars,
    main,
    validate_config,
)


@pytest.fixture
def parser():
    return build_parser()


class TestInjectEnvVars:
    def test_cli_args_set_all_fields(self, parser, monkeypatch):
        for k in list(__import__("os").environ):
            if k.startswith(("MCA_", "OTEL_")):
                monkeypatch.delenv(k, raising=False)
        args = parser.parse_args(
            [
                "--model-id",
                "m",
                "--team",
                "t",
                "--service-name",
                "svc",
                "--collector-endpoint",
                "http://collector:4318",
                "--registry-url",
                "https://reg",
                "--protocol",
                "grpc",
            ]
        )
        env = inject_env_vars(args, env={})
        assert env["MCA_MODEL_ID"] == "m"
        assert env["MCA_TEAM_NAME"] == "t"
        assert env["MCA_SERVICE_NAME"] == "svc"
        assert env["OTEL_SERVICE_NAME"] == "svc"
        assert env["MCA_COLLECTOR_ENDPOINT"] == "http://collector:4318"
        assert env["OTEL_EXPORTER_OTLP_ENDPOINT"] == "http://collector:4318"
        assert env["MCA_REGISTRY_URL"] == "https://reg"
        assert env["OTEL_EXPORTER_OTLP_PROTOCOL"] == "grpc"
        assert env["OTEL_EXPORTER_OTLP_TRACES_PROTOCOL"] == "grpc"
        assert env["OTEL_EXPORTER_OTLP_METRICS_PROTOCOL"] == "grpc"
        assert env["OTEL_EXPORTER_OTLP_LOGS_PROTOCOL"] == "grpc"

    def test_env_takes_precedence_over_cli(self, parser):
        args = parser.parse_args(["--model-id", "cli", "--team", "cli-team"])
        env = {"MCA_MODEL_ID": "env-id", "MCA_TEAM_NAME": "env-team"}
        result = inject_env_vars(args, env=env)
        assert result["MCA_MODEL_ID"] == "env-id"
        assert result["MCA_TEAM_NAME"] == "env-team"

    def test_service_name_default_to_model_id(self, parser):
        args = parser.parse_args(["--model-id", "only-mdl", "--team", "t"])
        env = inject_env_vars(args, env={})
        assert env["MCA_SERVICE_NAME"] == "only-mdl"
        assert env["OTEL_SERVICE_NAME"] == "only-mdl"

    def test_otel_service_name_not_overridden(self, parser):
        args = parser.parse_args(["--model-id", "m", "--team", "t", "--service-name", "from-cli"])
        env = {"OTEL_SERVICE_NAME": "preset"}
        result = inject_env_vars(args, env=env)
        assert result["OTEL_SERVICE_NAME"] == "preset"

    def test_otel_exporter_endpoint_not_overridden(self, parser):
        args = parser.parse_args(
            [
                "--model-id",
                "m",
                "--team",
                "t",
                "--collector-endpoint",
                "http://from-cli",
            ]
        )
        env = {"OTEL_EXPORTER_OTLP_ENDPOINT": "http://preset"}
        result = inject_env_vars(args, env=env)
        assert result["OTEL_EXPORTER_OTLP_ENDPOINT"] == "http://preset"

    def test_debug_flag_sets_env(self, parser):
        args = parser.parse_args(["--model-id", "m", "--team", "t", "--debug"])
        env = inject_env_vars(args, env={})
        assert env["MCA_DEBUG_MODE"] == "true"

    def test_protocol_component_overrides_respect_preset(self, parser):
        args = parser.parse_args(["--model-id", "m", "--team", "t", "--protocol", "grpc"])
        env = {
            "OTEL_EXPORTER_OTLP_TRACES_PROTOCOL": "http/protobuf",
            "OTEL_EXPORTER_OTLP_METRICS_PROTOCOL": "http/protobuf",
            "OTEL_EXPORTER_OTLP_LOGS_PROTOCOL": "http/protobuf",
        }
        result = inject_env_vars(args, env=env)
        # Preset values preserved
        assert result["OTEL_EXPORTER_OTLP_TRACES_PROTOCOL"] == "http/protobuf"
        assert result["OTEL_EXPORTER_OTLP_METRICS_PROTOCOL"] == "http/protobuf"
        assert result["OTEL_EXPORTER_OTLP_LOGS_PROTOCOL"] == "http/protobuf"


class TestValidateConfig:
    def test_valid(self):
        assert validate_config({"MCA_MODEL_ID": "m", "MCA_TEAM_NAME": "t"}) is True

    def test_missing_model_id(self, capsys):
        assert validate_config({"MCA_TEAM_NAME": "t"}) is False

    def test_missing_both(self, capsys):
        assert validate_config({}) is False
        assert "Missing required" in capsys.readouterr().err


class TestFindOtelInstrument:
    def test_returns_none_when_missing(self, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda _: None)
        assert find_otel_instrument() is None

    def test_returns_path_when_found(self, monkeypatch):
        monkeypatch.setattr("shutil.which", lambda _: "/usr/bin/opentelemetry-instrument")
        assert find_otel_instrument() == "/usr/bin/opentelemetry-instrument"


class TestMainArgSeparation:
    def test_main_with_separator(self, monkeypatch, capsys):
        """main() separates args at '--' and validates config."""
        monkeypatch.setattr(
            sys, "argv", ["mca-instrument", "--model-id", "m", "--team", "t", "--", "echo", "hello"]
        )
        # validate_config passes; run_instrumented will fail because
        # opentelemetry-instrument isn't on PATH in this test env.
        monkeypatch.setattr("mca_sdk.cli.instrument.find_otel_instrument", lambda: None)
        rc = main()
        # missing opentelemetry-instrument → non-zero exit, with a printed
        # error. Exit code is whatever main() chooses in that branch.
        captured = capsys.readouterr()
        assert rc != 0 or "opentelemetry-instrument" in captured.err.lower()
