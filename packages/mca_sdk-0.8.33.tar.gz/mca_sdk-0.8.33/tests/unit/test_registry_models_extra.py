import pytest
from mca_sdk.registry.models import (
    DeploymentConfig,
    ModelConfig,
    VALID_MODEL_TYPES,
    VALID_MODEL_CATEGORIES,
)


def test_model_config_init_valid():
    config = ModelConfig(
        service_name="test-svc",
        model_id="test-id",
        model_version="1.0.0",
        team_name="test-team",
        model_type="regression",
        model_category="internal",
    )
    assert config.service_name == "test-svc"
    assert config.model_type == "regression"


def test_model_config_legacy_migration_internal():
    # internal type -> category: internal, type: regression
    config = ModelConfig(
        service_name="test-svc",
        model_id="test-id",
        model_version="1.0.0",
        team_name="test-team",
        model_type="internal",
        model_category=None,
    )
    assert config.model_category == "internal"
    assert config.model_type == "regression"


def test_model_config_legacy_migration_vendor():
    # vendor type -> category: vendor, type: regression
    config = ModelConfig(
        service_name="test-svc",
        model_id="test-id",
        model_version="1.0.0",
        team_name="test-team",
        model_type="vendor",
        model_category=None,
    )
    assert config.model_category == "vendor"
    assert config.model_type == "regression"


def test_model_config_legacy_migration_generative():
    # generative type -> category: internal, type: generative
    config = ModelConfig(
        service_name="test-svc",
        model_id="test-id",
        model_version="1.0.0",
        team_name="test-team",
        model_type="generative",
        model_category=None,
    )
    assert config.model_category == "internal"
    assert config.model_type == "generative"


def test_model_config_invalid_type_raises():
    with pytest.raises(ValueError, match="model_type must be one of"):
        ModelConfig(
            service_name="test-svc",
            model_id="test-id",
            model_version="1.0.0",
            team_name="test-team",
            model_type="invalid-type",
            model_category="internal",
        )


def test_model_config_invalid_category_raises():
    with pytest.raises(ValueError, match="model_category must be one of"):
        ModelConfig(
            service_name="test-svc",
            model_id="test-id",
            model_version="1.0.0",
            team_name="test-team",
            model_type="regression",
            model_category="invalid-category",
        )


def test_model_config_missing_category_defaults_to_internal():
    # If a valid type is provided but no category, it raises an error now!
    with pytest.raises(ValueError, match="model_category is required"):
        ModelConfig(
            service_name="test-svc",
            model_id="test-id",
            model_version="1.0.0",
            team_name="test-team",
            model_type="classification",
            model_category=None,
        )


def test_model_config_legacy_only_type_with_explicit_category_raises():
    # "internal" and "vendor" are legacy model_type values, not valid in the new
    # taxonomy when model_category is explicitly provided. Triggers the line-126
    # ValueError branch.
    with pytest.raises(ValueError, match="legacy value from the old single-field taxonomy"):
        ModelConfig(
            service_name="test-svc",
            model_id="test-id",
            model_version="1.0.0",
            team_name="test-team",
            model_type="vendor",
            model_category="vendor",
        )


def test_model_config_defaults_and_optional_fields():
    config = ModelConfig(
        service_name="s",
        model_id="m",
        model_version="1",
        team_name="t",
        model_type="agentic",
        model_category="internal",
    )
    assert config.thresholds == {}
    assert config.phi_fields == {}
    assert config.extra_resource == {}
    assert config.association_id_column is None
    assert config.created_at is None
    assert config.updated_at is None
    assert config.registry_id is None
    assert config.deployment_id is None


def test_model_config_preserves_supplied_optional_fields():
    config = ModelConfig(
        service_name="s",
        model_id="m",
        model_version="1",
        team_name="t",
        model_type="time-series",
        model_category="internal",
        thresholds={"mae": 1.0},
        phi_fields={"ssn": {"criticality": "yes"}},
        extra_resource={"deployment.env": "staging"},
        association_id_column="patient_id",
        created_at="2026-01-01",
        updated_at="2026-02-01",
        registry_id="reg-1",
        deployment_id="dep-1",
    )
    assert config.thresholds == {"mae": 1.0}
    assert config.phi_fields == {"ssn": {"criticality": "yes"}}
    assert config.extra_resource == {"deployment.env": "staging"}
    assert config.association_id_column == "patient_id"
    assert config.registry_id == "reg-1"
    assert config.deployment_id == "dep-1"


@pytest.mark.parametrize("mt", VALID_MODEL_TYPES)
@pytest.mark.parametrize("mc", VALID_MODEL_CATEGORIES)
def test_every_valid_type_category_combo_accepted(mt, mc):
    config = ModelConfig(
        service_name="s",
        model_id="m",
        model_version="1",
        team_name="t",
        model_type=mt,
        model_category=mc,
    )
    assert config.model_type == mt
    assert config.model_category == mc


class TestDeploymentConfig:
    def test_minimum_fields(self):
        config = DeploymentConfig(
            deployment_id="dep-1",
            environment="production",
            region="us-east-1",
        )
        assert config.deployment_id == "dep-1"
        assert config.environment == "production"
        assert config.region == "us-east-1"
        assert config.resource_overrides == {}

    def test_with_resource_overrides(self):
        config = DeploymentConfig(
            deployment_id="dep-2",
            environment="staging",
            region="us-west-2",
            resource_overrides={"deployment.zone": "az-1", "cluster.name": "gke-1"},
        )
        assert config.resource_overrides == {
            "deployment.zone": "az-1",
            "cluster.name": "gke-1",
        }

    def test_default_resource_overrides_are_independent_instances(self):
        a = DeploymentConfig(deployment_id="a", environment="e", region="r")
        b = DeploymentConfig(deployment_id="b", environment="e", region="r")
        a.resource_overrides["k"] = "v"
        assert b.resource_overrides == {}
