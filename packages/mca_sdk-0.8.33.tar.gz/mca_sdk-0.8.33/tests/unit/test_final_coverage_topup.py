"""Small top-up tests to close the last few uncovered branches:
- buffering/queued_item.QueuedItem dataclass (force-registration of class body)
- utils/version_check module import smoke
- integrations/state module smoke

Added for story 6-33 coverage climb."""

import pytest


class TestIntegrationsState:
    def test_integrations_state_imports(self):
        from mca_sdk.integrations import state

        # Basic sanity: the module-level classes exist
        assert hasattr(state, "StateManager")
        assert hasattr(state, "SQLiteStateManager")
        assert hasattr(state, "InMemoryStateManager")


class TestBufferingQueuedItemRoundtrip:
    def test_queued_item_defaults_and_timestamp(self):
        from mca_sdk.buffering.queued_item import QueuedItem

        item = QueuedItem(data={"k": "v"})
        assert item.data == {"k": "v"}
        assert item.attempt_count == 0
        assert item.first_queued_at is not None
        assert item.last_error is None

    def test_queued_item_with_explicit_fields(self):
        from datetime import datetime, timezone

        from mca_sdk.buffering.queued_item import QueuedItem

        now = datetime.now(timezone.utc)
        item = QueuedItem(
            data={"x": 1},
            attempt_count=5,
            first_queued_at=now,
            last_error="test",
        )
        assert item.attempt_count == 5
        assert item.first_queued_at == now
        assert item.last_error == "test"


class TestUtilsVersionCheckImport:
    def test_module_imports_without_error(self):
        import mca_sdk.utils.version_check as vc

        assert hasattr(vc, "check_version")


class TestValidationResultImport:
    """Force-import the ValidationResult module body to register lines."""

    def test_validation_result_instantiation_paths(self):
        from mca_sdk.validation.result import ValidationResult

        # Success path
        result = ValidationResult(is_valid=True)
        assert result.is_valid
        assert str(result) == "Validation passed"

        # Failure path with explicit fields
        result = ValidationResult(is_valid=False, missing_fields=["foo"], errors=["foo is missing"])
        assert not result.is_valid
        assert "foo is missing" in str(result)

        # Contradictory state
        with pytest.raises(ValueError):
            ValidationResult(is_valid=True, errors=["cannot happen"])
