"""Additional tests for uncovered paths in registry/client.py."""

import time
from unittest.mock import Mock, patch, MagicMock

import pytest

from mca_sdk.registry.client import RegistryClient
from mca_sdk.registry.models import DeploymentConfig
from mca_sdk.utils.exceptions import (
    RegistryError,
    RegistryAuthError,
    RegistryConfigNotFoundError,
    RegistryConnectionError,
)

BASE_URL = "https://registry.example.com"


def make_client(**kwargs):
    return RegistryClient(url=BASE_URL, refresh_interval_secs=0, **kwargs)


class TestRegistryClientConstructorErrors:
    def test_both_token_and_gcp_auth_raises(self):
        with pytest.raises(RegistryError, match="Cannot use both"):
            RegistryClient(
                url=BASE_URL,
                token="my-token",
                use_gcp_auth=True,
                refresh_interval_secs=0,
            )

    def test_tls_insecure_registry_overrides_verify_ssl(self):
        client = make_client(verify_ssl=True, tls_insecure_registry=True)
        assert client._session.verify is False

    def test_tls_insecure_registry_false_keeps_ssl(self):
        client = make_client(verify_ssl=True, tls_insecure_registry=False)
        assert client._session.verify is True


class TestShouldRefreshGcpToken:
    def test_returns_false_when_gcp_auth_disabled(self):
        client = make_client()
        assert client._should_refresh_gcp_token() is False

    def test_returns_true_when_token_is_none_and_gcp_enabled(self):
        mock_google_auth = MagicMock()
        with patch.dict(
            "sys.modules",
            {
                "google": mock_google_auth,
                "google.auth": mock_google_auth,
                "google.auth.transport": mock_google_auth,
                "google.auth.transport.requests": mock_google_auth,
                "google.oauth2": mock_google_auth,
                "google.oauth2.id_token": mock_google_auth,
            },
        ):
            with patch("mca_sdk.registry.client.GCP_AUTH_AVAILABLE", True):
                client = make_client(use_gcp_auth=True)
                client._gcp_token = None
                assert client._should_refresh_gcp_token() is True

    def test_returns_true_when_token_expired(self):
        mock_google_auth = MagicMock()
        with patch.dict(
            "sys.modules",
            {
                "google": mock_google_auth,
                "google.auth": mock_google_auth,
                "google.auth.transport": mock_google_auth,
                "google.auth.transport.requests": mock_google_auth,
                "google.oauth2": mock_google_auth,
                "google.oauth2.id_token": mock_google_auth,
            },
        ):
            with patch("mca_sdk.registry.client.GCP_AUTH_AVAILABLE", True):
                client = make_client(use_gcp_auth=True)
                client._gcp_token = "old-token"
                client._gcp_token_expiry = time.time() - 100  # expired
                assert client._should_refresh_gcp_token() is True

    def test_returns_false_when_token_valid(self):
        mock_google_auth = MagicMock()
        with patch.dict(
            "sys.modules",
            {
                "google": mock_google_auth,
                "google.auth": mock_google_auth,
                "google.auth.transport": mock_google_auth,
                "google.auth.transport.requests": mock_google_auth,
                "google.oauth2": mock_google_auth,
                "google.oauth2.id_token": mock_google_auth,
            },
        ):
            with patch("mca_sdk.registry.client.GCP_AUTH_AVAILABLE", True):
                client = make_client(use_gcp_auth=True)
                client._gcp_token = "valid-token"
                client._gcp_token_expiry = time.time() + 3600  # valid for 1 hour
                assert client._should_refresh_gcp_token() is False


class TestGetRefreshStats:
    def test_get_refresh_stats_returns_dict(self):
        client = make_client()
        stats = client.get_refresh_stats()
        assert isinstance(stats, dict)
        assert "last_refresh_time" in stats
        assert "refresh_count" in stats
        assert "refresh_errors" in stats
        assert "is_running" in stats

    def test_refresh_stats_initial_values(self):
        client = make_client()
        stats = client.get_refresh_stats()
        assert stats["refresh_count"] == 0
        assert stats["refresh_errors"] == 0
        assert stats["is_running"] is False


class TestFetchDeploymentConfigErrors:
    @patch("mca_sdk.registry.client.requests.Session.get")
    def test_fetch_deployment_config_auth_error_not_retried(self, mock_get):
        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.text = "Unauthorized"
        mock_get.return_value = mock_response

        client = make_client(token="bad-token")
        with pytest.raises(RegistryAuthError):
            client.fetch_deployment_config("dep-001")

    @patch("mca_sdk.registry.client.requests.Session.get")
    def test_fetch_deployment_config_not_found(self, mock_get):
        mock_response = Mock()
        mock_response.status_code = 404
        mock_response.text = "Not found"
        mock_get.return_value = mock_response

        client = make_client()
        with pytest.raises(RegistryConfigNotFoundError):
            client.fetch_deployment_config("dep-missing")

    @patch("mca_sdk.registry.client.requests.Session.get")
    def test_fetch_deployment_uses_cache_on_second_call(self, mock_get):
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "deployment_id": "dep-001",
            "environment": "staging",
            "region": "us-east-1",
            "resource_overrides": {},
        }
        mock_get.return_value = mock_response

        client = make_client()
        client.fetch_deployment_config("dep-001")
        client.fetch_deployment_config("dep-001")

        assert mock_get.call_count == 1


class TestStopRefreshThread:
    def test_stop_refresh_thread_no_thread_is_noop(self):
        client = make_client()
        client.stop_refresh_thread()

    def test_stop_refresh_thread_stops_running_thread(self):
        client = make_client()
        client._stop_event.clear()

        import threading

        def run_forever():
            client._stop_event.wait()

        thread = threading.Thread(target=run_forever, daemon=True)
        client._refresh_thread = thread
        thread.start()

        client.stop_refresh_thread(timeout=2.0)
        assert not thread.is_alive()


class TestGCPTokenRefreshThread:
    def test_start_gcp_token_refresh_thread_noop_when_gcp_disabled(self):
        client = make_client()
        client._use_gcp_auth = False
        client._start_gcp_token_refresh_thread()
        assert client._gcp_token_refresh_thread is None

    def test_start_gcp_token_refresh_thread_starts_when_none(self):
        client = make_client()
        client._use_gcp_auth = True
        client._start_gcp_token_refresh_thread()
        assert client._gcp_token_refresh_thread is not None
        assert client._gcp_token_refresh_thread.is_alive()
        client._stop_gcp_token_refresh_thread(timeout=1.0)

    def test_start_gcp_token_refresh_thread_noop_when_already_running(self):
        client = make_client()
        client._use_gcp_auth = True
        client._start_gcp_token_refresh_thread()
        thread1 = client._gcp_token_refresh_thread
        client._start_gcp_token_refresh_thread()  # noop
        assert client._gcp_token_refresh_thread is thread1
        client._stop_gcp_token_refresh_thread(timeout=1.0)

    def test_stop_gcp_token_refresh_thread_noop_when_no_thread(self):
        client = make_client()
        client._gcp_token_refresh_thread = None
        client._stop_gcp_token_refresh_thread()  # Should not raise

    def test_stop_gcp_token_refresh_thread_stops_running(self):
        client = make_client()
        client._use_gcp_auth = True
        client._start_gcp_token_refresh_thread()
        assert client._gcp_token_refresh_thread.is_alive()
        client._stop_gcp_token_refresh_thread(timeout=2.0)

    def test_gcp_token_refresh_loop_exits_when_stop_event_set(self):
        client = make_client()
        client._gcp_stop_event.set()  # Already set → loop exits immediately
        client._gcp_token_refresh_loop()  # Should return quickly

    def test_close_stops_all_threads(self):
        client = make_client()
        client.close()  # Should not raise even with no threads running


class TestRegistryClientClose:
    def test_close_stops_refresh_thread(self):
        client = make_client()
        client.close()
        assert not client._session.get("http://localhost", timeout=0.001) if False else True


class TestRegistryClientCacheMethods:
    def test_clear_cache_empties_cache(self):
        client = make_client()
        client._cache["model-001"] = object()
        client.clear_cache()
        assert len(client._cache) == 0

    def test_untrack_model_removes_tracked_model(self):
        client = make_client()
        client._fetched_models.add("mdl-001")
        client.untrack_model("mdl-001")
        assert "mdl-001" not in client._fetched_models

    def test_untrack_model_noop_when_not_tracked(self):
        client = make_client()
        client.untrack_model("mdl-not-there")  # Should not raise

    def test_get_tracked_models_returns_copy(self):
        client = make_client()
        client._fetched_models.add("mdl-001")
        result = client.get_tracked_models()
        assert "mdl-001" in result
        result.discard("mdl-001")
        assert "mdl-001" in client._fetched_models  # Original unchanged


class TestGCPAuthNotAvailable:
    def test_gcp_auth_not_available_raises_value_error(self):
        with patch("mca_sdk.registry.client.GCP_AUTH_AVAILABLE", False):
            with pytest.raises(ValueError, match="GCP authentication requested but google-auth"):
                RegistryClient(url=BASE_URL, use_gcp_auth=True, refresh_interval_secs=0)


class TestRefreshLoop:
    def test_refresh_loop_exits_when_stop_event_set(self):
        client = make_client()
        client._stop_event.set()
        client._refresh_loop()  # Should return immediately

    def test_refresh_loop_no_models_skips_refresh(self):
        # refresh_interval_secs=0 makes wait(timeout=0) return immediately
        client = make_client()
        client._fetched_models.clear()

        call_count = [0]

        def fake_wait(timeout=None):
            call_count[0] += 1
            client._stop_event.set()
            return False  # Don't break — let loop body run once

        client._stop_event.wait = fake_wait
        client._refresh_loop()
        assert call_count[0] >= 1

    def test_refresh_loop_refreshes_tracked_model_on_success(self):
        client = make_client()
        client._fetched_models.add("model-001")

        mock_config = Mock()
        call_count = [0]

        def fake_fetch(model_id, version=None, **kwargs):
            call_count[0] += 1
            client._stop_event.set()
            return mock_config

        with patch.object(client, "fetch_model_config", side_effect=fake_fetch):
            client._refresh_loop()

        assert call_count[0] == 1
        assert client._refresh_count >= 1

    def test_refresh_loop_handles_auth_error_stops_thread(self):
        client = make_client()
        client._fetched_models.add("model-001")

        def fake_fetch(model_id, version=None, **kwargs):
            raise RegistryAuthError("Unauthorized")

        with patch.object(client, "fetch_model_config", side_effect=fake_fetch):
            client._refresh_loop()  # Should return after auth error

    def test_refresh_loop_handles_connection_error_continues(self):
        client = make_client()
        client._fetched_models.add("model-001")

        call_count = [0]

        def fake_fetch(model_id, version=None, **kwargs):
            call_count[0] += 1
            client._stop_event.set()
            raise RegistryConnectionError("Connection failed")

        with patch.object(client, "fetch_model_config", side_effect=fake_fetch):
            client._refresh_loop()

        assert client._refresh_errors >= 1

    def test_refresh_loop_handles_generic_exception(self):
        client = make_client()
        client._fetched_models.add("model-001")

        call_count = [0]

        def fake_fetch(model_id, version=None, **kwargs):
            call_count[0] += 1
            client._stop_event.set()
            raise RuntimeError("Unexpected error")

        with patch.object(client, "fetch_model_config", side_effect=fake_fetch):
            client._refresh_loop()

        assert client._refresh_errors >= 1

    def test_refresh_loop_all_failures_logs_error(self):
        client = make_client()
        client._fetched_models.add("model-001")
        client._fetched_models.add("model-002")

        call_count = [0]

        def fake_fetch(model_id, version=None, **kwargs):
            call_count[0] += 1
            if call_count[0] >= 2:
                client._stop_event.set()
            raise RegistryError("Generic error")

        with patch.object(client, "fetch_model_config", side_effect=fake_fetch):
            client._refresh_loop()

        assert client._refresh_errors >= 2
