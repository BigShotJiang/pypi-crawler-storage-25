"""Unit tests for MCAClient.record_llm_generation.

Covers the SDK helper added to close the Langfuse GENERATION latency-coverage
gap for agentic and direct-Vertex genai paths. Asserts the emitted span
carries the gen_ai.* semantic-convention attributes Langfuse uses to classify
an observation as a GENERATION, and that errors close the span with
StatusCode.ERROR.
"""

import pytest
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import StatusCode

from mca_sdk.core.client import MCAClient


def _make_client_with_exporter():
    client = MCAClient(
        service_name="test-genai",
        model_id="mdl-gen-001",
        team_name="test-team",
        model_type="generative",
        model_category="internal",
        llm_provider="google",
        llm_model="gemini-2.0-flash-001",
        collector_endpoint="http://localhost:4318",
        strict_validation=False,
    )
    exporter = InMemorySpanExporter()
    client._tracer_provider.add_span_processor(SimpleSpanProcessor(exporter))
    return client, exporter


class TestRecordLLMGeneration:
    def test_emits_gen_ai_attributes_for_langfuse_generation(self):
        client, exporter = _make_client_with_exporter()
        try:
            with client.record_llm_generation(
                model="gemini-2.0-flash-001",
                provider="google",
                operation="chat",
                prompt=[{"role": "user", "content": "hello"}],
                temperature=0.2,
                max_tokens=512,
            ) as gen:
                gen.set_completion("hi there")
                gen.set_usage(prompt_tokens=10, completion_tokens=5, total_tokens=15)
                gen.set_cost(0.0001)

            spans = exporter.get_finished_spans()
            assert len(spans) == 1
            span = spans[0]
            assert span.name == "llm.gemini-2.0-flash-001"

            attrs = dict(span.attributes)
            # Core Langfuse GENERATION markers
            assert attrs["gen_ai.system"] == "google"
            assert attrs["gen_ai.request.model"] == "gemini-2.0-flash-001"
            assert attrs["gen_ai.operation.name"] == "chat"
            assert attrs["langfuse.observation.type"] == "generation"

            # Request knobs
            assert attrs["gen_ai.request.temperature"] == 0.2
            assert attrs["gen_ai.request.max_tokens"] == 512

            # Usage
            assert attrs["gen_ai.usage.prompt_tokens"] == 10
            assert attrs["gen_ai.usage.completion_tokens"] == 5
            assert attrs["gen_ai.usage.total_tokens"] == 15
            assert attrs["gen_ai.usage.cost_usd"] == pytest.approx(0.0001)

            # Completion captured
            assert "gen_ai.completion" in attrs
            assert "hi there" in str(attrs["gen_ai.completion"])

            # Latency recorded on the span
            assert "gen_ai.latency_seconds" in attrs
            assert attrs["gen_ai.latency_seconds"] >= 0

            # Span status OK on success
            assert span.status.status_code == StatusCode.OK
        finally:
            client.shutdown(timeout_millis=2000)

    def test_provider_inferred_from_model_name(self):
        client, exporter = _make_client_with_exporter()
        try:
            with client.record_llm_generation(model="gemini-1.5-pro-002") as gen:
                gen.set_usage(prompt_tokens=1, completion_tokens=1, total_tokens=2)

            spans = exporter.get_finished_spans()
            assert len(spans) == 1
            attrs = dict(spans[0].attributes)
            assert attrs["gen_ai.system"] == "google"
            assert attrs["gen_ai.request.model"] == "gemini-1.5-pro-002"
        finally:
            client.shutdown(timeout_millis=2000)

    def test_exception_closes_span_with_error_status(self):
        client, exporter = _make_client_with_exporter()
        try:
            with pytest.raises(RuntimeError, match="boom"):
                with client.record_llm_generation(
                    model="gemini-2.0-flash-001",
                    provider="google",
                ):
                    raise RuntimeError("boom")

            spans = exporter.get_finished_spans()
            assert len(spans) == 1
            span = spans[0]
            assert span.status.status_code == StatusCode.ERROR
            attrs = dict(span.attributes)
            assert attrs.get("error") is True
            assert attrs.get("error.type") == "RuntimeError"
            assert "gen_ai.latency_seconds" in attrs
        finally:
            client.shutdown(timeout_millis=2000)
