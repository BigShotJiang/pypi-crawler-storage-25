"""Unit tests for injection-prevention validators in mca_sdk/validation/schema.py
that are not exercised by test_schema_validation.py: validate_model_id
(path traversal, SQL, command injection, XSS, regex format, length) and
validate_service_name (mirrored rules). Added for story 6-33 coverage climb."""

import pytest

from mca_sdk.utils.exceptions import ValidationError
from mca_sdk.validation.schema import (
    validate_model_id,
    validate_service_name,
)


class TestValidateModelId:
    @pytest.mark.parametrize(
        "mid",
        ["mdl-001", "model_123", "a", "A1", "team-ml-model-v2", "abc_xyz_789"],
    )
    def test_valid_ids(self, mid):
        assert validate_model_id(mid) is True

    def test_empty_raises(self):
        with pytest.raises(ValidationError, match="cannot be empty"):
            validate_model_id("")

    @pytest.mark.parametrize("mid", ["../etc/passwd", "..", "a/b", "a\\b"])
    def test_path_traversal_raises(self, mid):
        with pytest.raises(ValidationError, match="path traversal"):
            validate_model_id(mid)

    @pytest.mark.parametrize(
        "mid",
        [
            "mdl'",
            'mdl"',
            "mdl;drop",
            "mdl--comment",
            "xp_sysctl",
            "sp_oacreate",
            "xDROPx",
            "xSELECTx",
            "xINSERTx",
            "xUPDATEx",
            "xDELETEx",
        ],
    )
    def test_sql_injection_raises(self, mid):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_model_id(mid)

    @pytest.mark.parametrize(
        "mid",
        ["mdl|pipe", "mdl&amp", "mdl$", "mdl`backtick`", "mdl$(sub)", "mdl&&or", "mdl||alt"],
    )
    def test_command_injection_raises(self, mid):
        with pytest.raises(ValidationError, match="command injection"):
            validate_model_id(mid)

    @pytest.mark.parametrize("mid", ["mdl<script>", "mdl>arrow"])
    def test_xss_raises(self, mid):
        # ">" and "<" are caught by the cmd-injection check first, so accept
        # either pattern in the error.
        with pytest.raises(ValidationError, match="(XSS|command injection)"):
            validate_model_id(mid)


class TestValidateServiceName:
    @pytest.mark.parametrize(
        "name",
        ["svc", "my-service", "my_service_123", "A1", "a" * 128],
    )
    def test_valid_names(self, name):
        assert validate_service_name(name) is True

    def test_empty_raises(self):
        with pytest.raises(ValidationError, match="cannot be empty"):
            validate_service_name("")

    @pytest.mark.parametrize("name", ["../", "svc/path", "svc\\back", "a..b"])
    def test_path_traversal_raises(self, name):
        with pytest.raises(ValidationError, match="path traversal"):
            validate_service_name(name)

    @pytest.mark.parametrize(
        "name",
        [
            "svc'",
            'svc"',
            "svc;",
            "svc--",
            "svcDROPx",
            "svcSELECTx",
        ],
    )
    def test_sql_injection_raises(self, name):
        with pytest.raises(ValidationError, match="SQL injection"):
            validate_service_name(name)

    @pytest.mark.parametrize(
        "name",
        ["svc|pipe", "svc&amp", "svc$sub", "svc`back`", "svc$(cmd)", "svc&&ok", "svc||alt"],
    )
    def test_command_injection_raises(self, name):
        with pytest.raises(ValidationError, match="command injection"):
            validate_service_name(name)

    @pytest.mark.parametrize("name", ["svc<script>"])
    def test_xss_raises(self, name):
        with pytest.raises(ValidationError, match="(XSS|command injection)"):
            validate_service_name(name)

    def test_invalid_characters_regex(self):
        # Spaces and dots are not in the allowed set and should hit the regex check
        with pytest.raises(ValidationError, match="alphanumeric characters"):
            validate_service_name("svc name")

    def test_length_limit(self):
        with pytest.raises(ValidationError, match="maximum length"):
            validate_service_name("a" * 129)
