"""Unit tests for DP-16 histogram bucket boundary Views.

Verifies that the seconds-scale histograms emitted by the SDK use explicit
bucket boundaries appropriate for their distribution shape (short-tail for
sub-10s latencies, long-tail for human-intervention waits up to 24h), and
that non-time histograms (mae, rmse) keep OTel's default boundaries.

The Views live on the MeterProvider, not on the instrument constructor, so
the assertions construct a real MeterProvider with the default views and
read back collected histograms via InMemoryMetricReader.

Round-2: wildcard match was replaced with an enumerated SDK-name list to
prevent custom user histograms registered via MCAClient.record_metric from
being silently force-shaped. test_custom_record_metric_histogram_keeps_default_boundaries
is the regression guard.
"""

import importlib
import os
from unittest import mock

import pytest
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import InMemoryMetricReader
from opentelemetry.sdk.metrics.view import (
    ExplicitBucketHistogramAggregation,
    View,
)
from opentelemetry.sdk.resources import Resource

from mca_sdk.core.providers import (
    DEFAULT_DROP_VIEWS,
    DEFAULT_HISTOGRAM_BOUNDARY_VIEWS,
    LATENCY_LONG_TAIL_BOUNDARIES,
    LATENCY_SHORT_TAIL_BOUNDARIES,
    _SDK_SHORT_TAIL_HISTOGRAM_NAMES,
)

_OTEL_DEFAULT_BOUNDARIES = (
    0.0,
    5.0,
    10.0,
    25.0,
    50.0,
    75.0,
    100.0,
    250.0,
    500.0,
    750.0,
    1000.0,
    2500.0,
    5000.0,
    7500.0,
    10000.0,
)


def _build_provider() -> tuple[MeterProvider, InMemoryMetricReader]:
    reader = InMemoryMetricReader()
    provider = MeterProvider(
        resource=Resource.create({"service.name": "test-bucket-views"}),
        metric_readers=[reader],
        views=list(DEFAULT_DROP_VIEWS) + list(DEFAULT_HISTOGRAM_BOUNDARY_VIEWS),
    )
    return provider, reader


def _bounds_for(reader: InMemoryMetricReader, instrument_name: str) -> tuple[float, ...]:
    metrics_data = reader.get_metrics_data()
    assert metrics_data is not None, "no metrics collected"
    for resource_metrics in metrics_data.resource_metrics:
        for scope_metrics in resource_metrics.scope_metrics:
            for metric in scope_metrics.metrics:
                if metric.name == instrument_name:
                    points = list(metric.data.data_points)
                    assert points, f"{instrument_name}: no data points"
                    return tuple(points[0].explicit_bounds)
    raise AssertionError(f"{instrument_name} not found in collected metrics")


@pytest.mark.parametrize("instrument_name", list(_SDK_SHORT_TAIL_HISTOGRAM_NAMES))
def test_short_tail_applies_to_every_blessed_sdk_short_tail_name(instrument_name):
    """F7 round-2: every enumerated SDK short-tail name gets short-tail bounds.

    Replaces the round-1 single-prefix wildcard test. Covers all four
    metric_prefix values (model/genai/agentic/vendor) for both
    .latency_seconds and .embedding_latency_seconds, plus the explicit
    agent.tool_latency_seconds and mca.registry.refresh_latency_seconds.
    """
    provider, reader = _build_provider()
    meter = provider.get_meter("t")
    h = meter.create_histogram(instrument_name, unit="s")
    h.record(0.1)

    bounds = _bounds_for(reader, instrument_name)
    assert bounds == LATENCY_SHORT_TAIL_BOUNDARIES


def test_long_tail_applies_to_agent_goal_duration_seconds():
    provider, reader = _build_provider()
    meter = provider.get_meter("t")
    h = meter.create_histogram("agent.goal_duration_seconds", unit="s")
    h.record(120.0)

    bounds = _bounds_for(reader, "agent.goal_duration_seconds")
    assert bounds == LATENCY_LONG_TAIL_BOUNDARIES
    assert bounds[-1] == 86400.0


def test_long_tail_applies_to_intervention_wait_time_seconds():
    provider, reader = _build_provider()
    meter = provider.get_meter("t")
    h = meter.create_histogram("agent.intervention_wait_time_seconds", unit="s")
    h.record(3600.0)

    bounds = _bounds_for(reader, "agent.intervention_wait_time_seconds")
    assert bounds == LATENCY_LONG_TAIL_BOUNDARIES
    assert bounds[-1] == 86400.0


def test_mae_histogram_retains_default_boundaries():
    provider, reader = _build_provider()
    meter = provider.get_meter("t")
    h = meter.create_histogram("model.mae")
    h.record(0.5)

    bounds = _bounds_for(reader, "model.mae")
    assert bounds == _OTEL_DEFAULT_BOUNDARIES


def test_rmse_histogram_retains_default_boundaries():
    provider, reader = _build_provider()
    meter = provider.get_meter("t")
    h = meter.create_histogram("model.rmse")
    h.record(0.5)

    bounds = _bounds_for(reader, "model.rmse")
    assert bounds == _OTEL_DEFAULT_BOUNDARIES


def test_custom_record_metric_histogram_keeps_default_boundaries():
    """F3 round-2 regression: custom histograms named *latency_seconds via
    record_metric must NOT inherit the SDK's short-tail boundaries.

    Round-1 used a wildcard `*latency_seconds` View that silently overwrote
    user-created custom histograms. This test pins the corrected behavior:
    a custom-named seconds-scale histogram registered through the same
    meter retains OTel default boundaries.
    """
    provider, reader = _build_provider()
    meter = provider.get_meter("user-app")
    h = meter.create_histogram("custom.db_latency_seconds", unit="s")
    h.record(0.05)

    bounds = _bounds_for(reader, "custom.db_latency_seconds")
    assert bounds == _OTEL_DEFAULT_BOUNDARIES, (
        "custom.db_latency_seconds must retain OTel defaults; "
        "the round-1 wildcard match was a regression for record_metric callers."
    )


def test_short_tail_buckets_distribute_realistic_ml_latencies():
    """AC-1 verification: 50ms / 200ms / 1.5s land in three distinct sub-5s buckets."""
    provider, reader = _build_provider()
    meter = provider.get_meter("t")
    h = meter.create_histogram("model.latency_seconds", unit="s")
    for v in (0.05, 0.2, 1.5):
        h.record(v)

    metrics_data = reader.get_metrics_data()
    histogram = None
    for rm in metrics_data.resource_metrics:
        for sm in rm.scope_metrics:
            for m in sm.metrics:
                if m.name == "model.latency_seconds":
                    histogram = m
    assert histogram is not None
    point = list(histogram.data.data_points)[0]
    nonzero_buckets = [c for c in point.bucket_counts if c > 0]
    assert len(nonzero_buckets) >= 3, (
        f"expected >=3 non-zero buckets across 50ms/200ms/1.5s; "
        f"got {nonzero_buckets} with bounds {point.explicit_bounds}"
    )


def test_module_constants_have_expected_values():
    """F5: pin the AC-1 / AC-2 boundary tuples literally.

    AC-1 mandates short-tail boundaries
        (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10)
    AC-2 mandates long-tail boundaries
        (1, 5, 30, 60, 300, 600, 1800, 3600, 7200, 21600, 86400)  # 1s -> 24h
    Any drift in either tuple breaks the SDK contract; this test fails loud.
    """
    assert LATENCY_SHORT_TAIL_BOUNDARIES == (
        0.005,
        0.01,
        0.025,
        0.05,
        0.1,
        0.25,
        0.5,
        1.0,
        2.5,
        5.0,
        10.0,
    ), "AC-1 short-tail boundary tuple drifted"
    assert LATENCY_LONG_TAIL_BOUNDARIES == (
        1.0,
        5.0,
        30.0,
        60.0,
        300.0,
        600.0,
        1800.0,
        3600.0,
        7200.0,
        21600.0,
        86400.0,
    ), "AC-2 long-tail boundary tuple drifted"


def test_enumerated_short_tail_name_list_covers_every_blessed_prefix():
    """F7 round-2: pin the enumerated short-tail name set against drift.

    If a future change removes one of the four metric_prefix values
    (model/genai/agentic/vendor) without updating this list, that prefix's
    .latency_seconds histogram will silently revert to OTel defaults and
    the SDK contract will break. Test fails loud on that drift.
    """
    expected = {
        "model.latency_seconds",
        "genai.latency_seconds",
        "agentic.latency_seconds",
        "vendor.latency_seconds",
        "model.embedding_latency_seconds",
        "genai.embedding_latency_seconds",
        "agentic.embedding_latency_seconds",
        "vendor.embedding_latency_seconds",
        "agent.tool_latency_seconds",
        "mca.registry.refresh_latency_seconds",
    }
    assert set(_SDK_SHORT_TAIL_HISTOGRAM_NAMES) == expected
    # Each name produced exactly one View; long-tail adds two more.
    assert len(DEFAULT_HISTOGRAM_BOUNDARY_VIEWS) == len(_SDK_SHORT_TAIL_HISTOGRAM_NAMES) + 2


def test_disable_env_var_restores_default_boundaries(monkeypatch):
    """F8 / F10 round-2: MCA_DISABLE_HISTOGRAM_BOUNDARY_VIEWS=true skips
    DEFAULT_HISTOGRAM_BOUNDARY_VIEWS in setup_meter_provider.

    Operators with in-flight Grafana dashboards depending on the old
    [0, 5) bucket get a one-release escape hatch via this env var.
    Verifies the gate logic by simulating the setup_meter_provider
    final_views construction.
    """
    monkeypatch.setenv("MCA_DISABLE_HISTOGRAM_BOUNDARY_VIEWS", "true")
    # Mimic setup_meter_provider's gate logic.
    disable_boundary_views = (
        os.environ.get("MCA_DISABLE_HISTOGRAM_BOUNDARY_VIEWS", "false").lower() == "true"
    )
    assert disable_boundary_views is True

    final_views = list(DEFAULT_DROP_VIEWS)
    if not disable_boundary_views:
        final_views.extend(DEFAULT_HISTOGRAM_BOUNDARY_VIEWS)

    reader = InMemoryMetricReader()
    provider = MeterProvider(
        resource=Resource.create({"service.name": "escape-hatch"}),
        metric_readers=[reader],
        views=final_views,
    )
    meter = provider.get_meter("t")
    h = meter.create_histogram("model.latency_seconds", unit="s")
    h.record(0.05)

    bounds = _bounds_for(reader, "model.latency_seconds")
    assert (
        bounds == _OTEL_DEFAULT_BOUNDARIES
    ), "MCA_DISABLE_HISTOGRAM_BOUNDARY_VIEWS=true must restore OTel defaults"


def _reload_providers():
    """Reload mca_sdk.core.providers so module-level boundary tuples re-resolve
    against the current process environment. Returns the reloaded module."""
    import mca_sdk.core.providers as providers_module

    return importlib.reload(providers_module)


def test_short_tail_env_override_parses_valid_csv(monkeypatch):
    """F9 round-2: MCA_LATENCY_SHORT_TAIL_BOUNDARIES override resolves to the
    parsed tuple and the resulting boundary view applies it cleanly."""
    monkeypatch.setenv("MCA_LATENCY_SHORT_TAIL_BOUNDARIES", "0.001,0.01,0.1,1.0")
    providers_module = _reload_providers()
    try:
        assert providers_module.LATENCY_SHORT_TAIL_BOUNDARIES == (0.001, 0.01, 0.1, 1.0)

        reader = InMemoryMetricReader()
        provider = MeterProvider(
            resource=Resource.create({"service.name": "env-override-short"}),
            metric_readers=[reader],
            views=list(providers_module.DEFAULT_DROP_VIEWS)
            + list(providers_module.DEFAULT_HISTOGRAM_BOUNDARY_VIEWS),
        )
        meter = provider.get_meter("t")
        h = meter.create_histogram("model.latency_seconds", unit="s")
        h.record(0.05)
        bounds = _bounds_for(reader, "model.latency_seconds")
        assert bounds == (0.001, 0.01, 0.1, 1.0)
    finally:
        monkeypatch.delenv("MCA_LATENCY_SHORT_TAIL_BOUNDARIES", raising=False)
        _reload_providers()


def test_short_tail_env_override_rejects_non_ascending(monkeypatch, caplog):
    """F9 round-2: non-ascending CSV falls back to default + WARNING."""
    import logging as _logging

    monkeypatch.setenv("MCA_LATENCY_SHORT_TAIL_BOUNDARIES", "0.5,0.1")
    try:
        with caplog.at_level(_logging.WARNING, logger="mca_sdk.core.providers"):
            providers_module = _reload_providers()
        assert providers_module.LATENCY_SHORT_TAIL_BOUNDARIES == (
            0.005,
            0.01,
            0.025,
            0.05,
            0.1,
            0.25,
            0.5,
            1.0,
            2.5,
            5.0,
            10.0,
        )
        assert any(
            "MCA_LATENCY_SHORT_TAIL_BOUNDARIES" in r.message and "strictly ascending" in r.message
            for r in caplog.records
        ), f"expected ascending-violation warning; got {[r.message for r in caplog.records]}"
    finally:
        monkeypatch.delenv("MCA_LATENCY_SHORT_TAIL_BOUNDARIES", raising=False)
        _reload_providers()


def test_short_tail_env_override_rejects_non_numeric(monkeypatch, caplog):
    """F9 round-2: non-numeric CSV falls back to default + WARNING."""
    import logging as _logging

    monkeypatch.setenv("MCA_LATENCY_SHORT_TAIL_BOUNDARIES", "0.1,banana")
    try:
        with caplog.at_level(_logging.WARNING, logger="mca_sdk.core.providers"):
            providers_module = _reload_providers()
        assert providers_module.LATENCY_SHORT_TAIL_BOUNDARIES == (
            0.005,
            0.01,
            0.025,
            0.05,
            0.1,
            0.25,
            0.5,
            1.0,
            2.5,
            5.0,
            10.0,
        )
        assert any(
            "MCA_LATENCY_SHORT_TAIL_BOUNDARIES" in r.message and "could not be parsed" in r.message
            for r in caplog.records
        ), f"expected parse-failure warning; got {[r.message for r in caplog.records]}"
    finally:
        monkeypatch.delenv("MCA_LATENCY_SHORT_TAIL_BOUNDARIES", raising=False)
        _reload_providers()


def test_long_tail_env_override_round_trip(monkeypatch):
    """F9 round-2: MCA_LATENCY_LONG_TAIL_BOUNDARIES override resolves and is
    applied to agent.goal_duration_seconds."""
    monkeypatch.setenv("MCA_LATENCY_LONG_TAIL_BOUNDARIES", "10,60,600,3600,86400")
    providers_module = _reload_providers()
    try:
        assert providers_module.LATENCY_LONG_TAIL_BOUNDARIES == (
            10.0,
            60.0,
            600.0,
            3600.0,
            86400.0,
        )

        reader = InMemoryMetricReader()
        provider = MeterProvider(
            resource=Resource.create({"service.name": "env-override-long"}),
            metric_readers=[reader],
            views=list(providers_module.DEFAULT_DROP_VIEWS)
            + list(providers_module.DEFAULT_HISTOGRAM_BOUNDARY_VIEWS),
        )
        meter = provider.get_meter("t")
        h = meter.create_histogram("agent.goal_duration_seconds", unit="s")
        h.record(120.0)
        bounds = _bounds_for(reader, "agent.goal_duration_seconds")
        assert bounds == (10.0, 60.0, 600.0, 3600.0, 86400.0)
    finally:
        monkeypatch.delenv("MCA_LATENCY_LONG_TAIL_BOUNDARIES", raising=False)
        _reload_providers()


def test_caller_supplied_view_overrides_sdk_default():
    """F11 round-2: when a caller-supplied View targets a name in
    DEFAULT_HISTOGRAM_BOUNDARY_VIEWS, setup_meter_provider must suppress the
    SDK's boundary view for that name so the caller's bounds win cleanly
    (no conflicting metric stream warning, no duplicate views)."""
    from mca_sdk.core.providers import setup_meter_provider, unregister_provider

    caller_view = View(
        instrument_name="model.latency_seconds",
        aggregation=ExplicitBucketHistogramAggregation(boundaries=(0.5, 1.0)),
    )
    resource = Resource.create({"service.name": "caller-override-test"})
    provider, _, _, _ = setup_meter_provider(
        resource=resource,
        endpoint="http://localhost:4318/v1/metrics",
        views=[caller_view],
    )
    try:
        reader = InMemoryMetricReader()
        # Build a fresh provider sharing the same final_views shape — re-using
        # the global provider would require a registered reader, which we
        # cannot inject after construction. Instead, replicate the filter
        # logic locally to assert the caller view is the only one applied.
        from mca_sdk.core.providers import (
            DEFAULT_DROP_VIEWS,
            DEFAULT_HISTOGRAM_BOUNDARY_VIEWS,
        )

        caller_targeted = {"model.latency_seconds"}
        sdk_views = [
            v
            for v in DEFAULT_HISTOGRAM_BOUNDARY_VIEWS
            if getattr(v, "_instrument_name", None) not in caller_targeted
        ]
        assert all(
            getattr(v, "_instrument_name", None) != "model.latency_seconds" for v in sdk_views
        ), "filter must drop the SDK view that collides with the caller view"

        local_provider = MeterProvider(
            resource=resource,
            metric_readers=[reader],
            views=[caller_view, *DEFAULT_DROP_VIEWS, *sdk_views],
        )
        meter = local_provider.get_meter("t")
        h = meter.create_histogram("model.latency_seconds", unit="s")
        h.record(0.75)
        bounds = _bounds_for(reader, "model.latency_seconds")
        assert bounds == (0.5, 1.0), f"caller-supplied bounds must win; got {bounds}"
    finally:
        unregister_provider(provider)
