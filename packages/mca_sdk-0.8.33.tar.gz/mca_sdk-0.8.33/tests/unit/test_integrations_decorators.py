"""Unit tests for integrations/decorators.py module.

Tests standalone decorator functions (instrument_model, instrument_async_model,
track_batch_prediction) for automatic model instrumentation.
"""

import asyncio
import pytest
import time
from unittest.mock import Mock, MagicMock

from mca_sdk.integrations.decorators import (
    instrument_model,
    instrument_async_model,
    track_batch_prediction,
)


@pytest.fixture
def mock_client():
    """Create a mock MCAClient for testing."""
    client = Mock()
    client.record_prediction = Mock()
    client.record_metric = Mock()

    # Mock trace context manager
    mock_span = Mock()
    mock_span.set_attribute = Mock()
    mock_span.__enter__ = Mock(return_value=mock_span)
    mock_span.__exit__ = Mock(return_value=False)
    client.trace = Mock(return_value=mock_span)

    return client


class TestInstrumentModelDecorator:
    """Test instrument_model decorator."""

    def test_decorator_wraps_function(self, mock_client):
        """Test that decorator properly wraps the function."""

        @instrument_model(mock_client)
        def predict(x):
            """Test prediction function."""
            return x * 2

        assert predict.__name__ == "predict"
        assert predict.__doc__ == "Test prediction function."

    def test_decorator_calls_original_function(self, mock_client):
        """Test that decorated function calls original function."""

        @instrument_model(mock_client)
        def predict(x):
            return x * 2

        result = predict(5)

        assert result == 10

    def test_decorator_records_prediction(self, mock_client):
        """Test that decorator records prediction via client."""

        @instrument_model(mock_client)
        def predict(x):
            return x * 2

        result = predict(5)

        # Should have called record_prediction
        assert mock_client.record_prediction.called
        call_args = mock_client.record_prediction.call_args
        assert "latency" in call_args[1]
        assert call_args[1]["latency"] > 0

    def test_decorator_creates_trace_span(self, mock_client):
        """Test that decorator creates a trace span."""

        @instrument_model(mock_client)
        def predict(x):
            return x * 2

        result = predict(5)

        # Should have created trace span
        mock_client.trace.assert_called_once_with("predict.predict")

    def test_decorator_sets_span_attributes_success(self, mock_client):
        """Test that decorator sets span attributes on success."""

        @instrument_model(mock_client)
        def predict(x):
            return x * 2

        result = predict(5)

        # Get the mock span
        mock_span = mock_client.trace.return_value.__enter__.return_value

        # Check set_attribute was called
        assert mock_span.set_attribute.called
        calls = mock_span.set_attribute.call_args_list

        # Should set latency and status
        call_args_dict = {call[0][0]: call[0][1] for call in calls}
        assert "predict.latency_seconds" in call_args_dict
        assert call_args_dict["predict.status"] == "success"

    def test_decorator_with_custom_metric_name(self, mock_client):
        """Test decorator with custom metric name."""

        @instrument_model(mock_client, metric_name="custom_prediction")
        def predict(x):
            return x * 2

        result = predict(5)

        # Should use custom name in trace
        mock_client.trace.assert_called_once_with("custom_prediction.predict")

    def test_decorator_captures_input_when_enabled(self, mock_client):
        """Test that decorator captures input when capture_input=True."""

        @instrument_model(mock_client, capture_input=True)
        def predict(x):
            return x * 2

        result = predict(5)

        # Should have recorded with input_data
        call_args = mock_client.record_prediction.call_args[1]
        assert call_args["input_data"] == 5

    def test_decorator_does_capture_input_by_default(self, mock_client):
        """Test that decorator does capture input by default."""

        @instrument_model(mock_client)
        def predict(x):
            return x * 2

        result = predict(5)

        # Should have recorded with input_data (single arg is passed directly)
        call_args = mock_client.record_prediction.call_args[1]
        assert call_args["input_data"] == 5

    def test_decorator_captures_output_when_enabled(self, mock_client):
        """Test that decorator captures output when capture_output=True."""

        @instrument_model(mock_client, capture_output=True)
        def predict(x):
            return x * 2

        result = predict(5)

        # Should have recorded with output
        call_args = mock_client.record_prediction.call_args[1]
        assert call_args["output"] == 10

    def test_decorator_does_capture_output_by_default(self, mock_client):
        """Test that decorator does capture output by default."""

        @instrument_model(mock_client)
        def predict(x):
            return x * 2

        result = predict(5)

        # Should have recorded with output
        call_args = mock_client.record_prediction.call_args[1]
        assert call_args["output"] == 10

    def test_decorator_handles_exception(self, mock_client):
        """Test that decorator handles exceptions properly."""

        @instrument_model(mock_client)
        def predict(x):
            raise ValueError("Test error")

        with pytest.raises(ValueError, match="Test error"):
            predict(5)

        # Should have called record_error
        mock_client.record_error.assert_called_once()
        call_args = mock_client.record_error.call_args
        assert isinstance(call_args[0][0], ValueError)
        assert "latency" in call_args[1]

    def test_decorator_sets_error_span_attributes(self, mock_client):
        """Test that decorator sets error span attributes."""

        @instrument_model(mock_client)
        def predict(x):
            raise ValueError("Test error")

        with pytest.raises(ValueError):
            predict(5)

        # Get the mock span
        mock_span = mock_client.trace.return_value.__enter__.return_value

        # Check error attributes were set
        calls = mock_span.set_attribute.call_args_list
        call_args_dict = {call[0][0]: call[0][1] for call in calls}
        assert call_args_dict["predict.status"] == "error"
        assert "Test error" in call_args_dict["predict.error"]

    def test_decorator_with_no_args(self, mock_client):
        """Test decorator with function that takes no args."""

        @instrument_model(mock_client, capture_input=True)
        def predict():
            return 42

        result = predict()

        assert result == 42
        # Should record with empty input
        call_args = mock_client.record_prediction.call_args[1]
        assert call_args["input_data"] == {}

    def test_decorator_with_kwargs(self, mock_client):
        """Test decorator with function that uses kwargs."""

        @instrument_model(mock_client)
        def predict(a=1, b=2):
            return a + b

        result = predict(a=10, b=20)

        assert result == 30
        assert mock_client.record_prediction.called


class TestInstrumentModelAssociationId:
    """Story 6-45: association_id parity for instrument_model / instrument_async_model."""

    def test_instrument_model_forwards_association_id_when_provided(self, mock_client):
        """Sync + positive: association_id flows to record_prediction and span."""

        @instrument_model(mock_client)
        def predict(x, association_id=None):
            return x * 2

        predict(5, association_id="user-abc-session-42")

        call_kwargs = mock_client.record_prediction.call_args[1]
        assert call_kwargs["association_id"] == "user-abc-session-42"

        mock_span = mock_client.trace.return_value.__enter__.return_value
        span_calls = {c[0][0]: c[0][1] for c in mock_span.set_attribute.call_args_list}
        assert span_calls.get("ml.association.id") == "user-abc-session-42"

    def test_instrument_model_omits_association_id_when_absent(self, mock_client):
        """Sync + None: no span attribute set, association_id forwarded as None."""

        @instrument_model(mock_client)
        def predict(x):
            return x * 2

        predict(5)

        call_kwargs = mock_client.record_prediction.call_args[1]
        assert call_kwargs.get("association_id") is None

        mock_span = mock_client.trace.return_value.__enter__.return_value
        span_keys = {c[0][0] for c in mock_span.set_attribute.call_args_list}
        assert "ml.association.id" not in span_keys

    def test_instrument_model_does_not_pop_association_id(self, mock_client):
        """AC 3: kwargs.get (not pop) — decorated function still sees the kwarg."""

        received = {}

        @instrument_model(mock_client)
        def predict(x, association_id=None):
            received["association_id"] = association_id
            return x * 2

        predict(5, association_id="user-xyz")

        assert received["association_id"] == "user-xyz"

    def test_instrument_async_model_forwards_association_id_when_provided(self, mock_client):
        """Async + positive: association_id flows to record_prediction and span."""

        @instrument_async_model(mock_client)
        async def predict_async(x, association_id=None):
            return x * 2

        asyncio.run(predict_async(5, association_id="user-abc-session-42"))

        call_kwargs = mock_client.record_prediction.call_args[1]
        assert call_kwargs["association_id"] == "user-abc-session-42"

        mock_span = mock_client.trace.return_value.__enter__.return_value
        span_calls = {c[0][0]: c[0][1] for c in mock_span.set_attribute.call_args_list}
        assert span_calls.get("ml.association.id") == "user-abc-session-42"

    def test_instrument_async_model_omits_association_id_when_absent(self, mock_client):
        """Async + None: no span attribute set, association_id forwarded as None."""

        @instrument_async_model(mock_client)
        async def predict_async(x):
            return x * 2

        asyncio.run(predict_async(5))

        call_kwargs = mock_client.record_prediction.call_args[1]
        assert call_kwargs.get("association_id") is None

        mock_span = mock_client.trace.return_value.__enter__.return_value
        span_keys = {c[0][0] for c in mock_span.set_attribute.call_args_list}
        assert "ml.association.id" not in span_keys

    def test_instrument_async_model_forwards_association_id_on_error(self, mock_client):
        """AC 2 exception path: association_id flows to record_error."""

        @instrument_async_model(mock_client)
        async def predict_async(x, association_id=None):
            raise ValueError("boom")

        with pytest.raises(ValueError, match="boom"):
            asyncio.run(predict_async(5, association_id="user-abc-session-42"))

        mock_client.record_error.assert_called_once()
        err_kwargs = mock_client.record_error.call_args[1]
        assert err_kwargs["association_id"] == "user-abc-session-42"

    def test_instrument_model_forwards_association_id_on_error(self, mock_client):
        """Sync error path: association_id flows to record_error."""

        @instrument_model(mock_client)
        def predict(x, association_id=None):
            raise ValueError("boom")

        with pytest.raises(ValueError, match="boom"):
            predict(5, association_id="user-abc-session-42")

        mock_client.record_error.assert_called_once()
        err_kwargs = mock_client.record_error.call_args[1]
        assert err_kwargs["association_id"] == "user-abc-session-42"

    def test_instrument_model_generator_forwards_association_id_on_success(self, mock_client):
        """Sync generator success path: association_id reaches record_prediction when generator exhausts cleanly."""

        @instrument_model(mock_client)
        def predict_stream(n, association_id=None):
            for i in range(n):
                yield i

        gen = predict_stream(3, association_id="user-abc-session-42")
        # record_prediction fires only after the generator exhausts
        assert list(gen) == [0, 1, 2]

        mock_client.record_prediction.assert_called_once()
        call_kwargs = mock_client.record_prediction.call_args[1]
        assert call_kwargs["association_id"] == "user-abc-session-42"
        mock_client.record_error.assert_not_called()

    def test_instrument_model_generator_forwards_association_id_on_error(self, mock_client):
        """Sync generator exception path: association_id flows to record_error, NOT record_prediction."""

        @instrument_model(mock_client)
        def predict_stream(association_id=None):
            yield 1
            raise ValueError("mid-stream boom")

        with pytest.raises(ValueError, match="mid-stream boom"):
            list(predict_stream(association_id="user-abc-session-42"))

        mock_client.record_error.assert_called_once()
        err_kwargs = mock_client.record_error.call_args[1]
        assert err_kwargs["association_id"] == "user-abc-session-42"
        # Generator failure MUST NOT be reported as a successful prediction.
        mock_client.record_prediction.assert_not_called()

    # NOTE: Async-generator-function support was NOT added in this story.
    # `instrument_async_model` currently does `await func(*args, **kwargs)`, which
    # raises `TypeError: object async_generator can't be used in 'await' expression`
    # when wrapping an async-generator function, making the `isasyncgen(result)`
    # branch at decorators.py's async_generator_wrapper unreachable. Fixing that
    # requires pre-detecting `inspect.isasyncgenfunction(func)` at decoration time
    # — out of scope for a parity-only story. Filed as a follow-up; tests will be
    # added when that story lands.


@pytest.mark.skipif(True, reason="pytest-asyncio not configured for this test suite")
class TestInstrumentAsyncModelDecorator:
    """Test instrument_async_model decorator."""

    async def test_async_decorator_wraps_function(self, mock_client):
        """Test that async decorator properly wraps the function."""

        @instrument_async_model(mock_client)
        async def predict_async(x):
            """Test async prediction function."""
            return x * 2

        assert predict_async.__name__ == "predict_async"
        assert predict_async.__doc__ == "Test async prediction function."

    async def test_async_decorator_calls_original_function(self, mock_client):
        """Test that async decorated function calls original."""

        @instrument_async_model(mock_client)
        async def predict_async(x):
            return x * 2

        result = await predict_async(5)

        assert result == 10

    async def test_async_decorator_records_prediction(self, mock_client):
        """Test that async decorator records prediction."""

        @instrument_async_model(mock_client)
        async def predict_async(x):
            return x * 2

        await predict_async(5)

        assert mock_client.record_prediction.called
        call_args = mock_client.record_prediction.call_args
        assert "latency" in call_args[1]
        assert call_args[1]["latency"] >= 0

    async def test_async_decorator_creates_trace_span(self, mock_client):
        """Test that async decorator creates trace span."""

        @instrument_async_model(mock_client)
        async def predict_async(x):
            return x * 2

        await predict_async(5)

        assert mock_client.trace.called
        # span name is `<fn>.predict`
        args, _ = mock_client.trace.call_args
        assert args and args[0].endswith(".predict")

    async def test_async_decorator_records_error_on_exception(self, mock_client):
        """Error path: record_error is called with the full payload and the exception re-raises."""
        mock_client.record_error = Mock()

        @instrument_async_model(mock_client)
        async def predict_async(x):
            raise ValueError("nope")

        with pytest.raises(ValueError):
            await predict_async(5)

        mock_client.record_error.assert_called_once()
        call = mock_client.record_error.call_args
        exc_arg = call.args[0]
        assert isinstance(exc_arg, ValueError)
        assert str(exc_arg) == "nope"
        assert call.kwargs["function"] == "predict_async"
        assert isinstance(call.kwargs["latency"], float) and call.kwargs["latency"] > 0
        assert call.kwargs["prediction_id"]

    async def test_async_decorator_captures_input_and_output(self, mock_client):
        """capture_input/capture_output=True path routes args+kwargs through serializer."""

        @instrument_async_model(mock_client, capture_input=True, capture_output=True)
        async def predict_async(x, y=2):
            return x + y

        result = await predict_async(3, y=4)
        assert result == 7
        call_kwargs = mock_client.record_prediction.call_args[1]
        assert call_kwargs["input_data"] is not None
        assert call_kwargs["output"] == 7

    async def test_async_decorator_captures_input_args_only(self, mock_client):
        @instrument_async_model(mock_client, capture_input=True)
        async def predict_async(x):
            return x * 2

        await predict_async(11)
        assert mock_client.record_prediction.call_args[1]["input_data"] == 11

    async def test_async_decorator_captures_input_kwargs_only(self, mock_client):
        @instrument_async_model(mock_client, capture_input=True)
        async def predict_async(x=1):
            return x

        await predict_async(x=7)
        input_data = mock_client.record_prediction.call_args[1]["input_data"]
        # serializer_for_telemetry returns a string-serialized kwargs dict
        assert "7" in str(input_data)


class TestTraceAgentGoal:
    """Exercise the trace_agent_goal decorator (lines 349-377)."""

    def test_goal_success_path(self, mock_client):
        from mca_sdk.integrations.decorators import trace_agent_goal

        mock_client.record_goal_started = Mock(return_value="goal-1")
        mock_client.record_goal_completed = Mock()

        @trace_agent_goal(mock_client, description="find papers", goal_type="research")
        def do_work(x):
            return x + 1

        assert do_work(4) == 5
        mock_client.record_goal_started.assert_called_once()
        mock_client.record_goal_completed.assert_called_once_with("goal-1", status="success")

    def test_goal_failure_path(self, mock_client):
        from mca_sdk.integrations.decorators import trace_agent_goal

        mock_client.record_goal_started = Mock(return_value="goal-err")
        mock_client.record_goal_completed = Mock()

        @trace_agent_goal(mock_client, description="fail", goal_type="research")
        def bad():
            raise RuntimeError("boom")

        with pytest.raises(RuntimeError, match="boom"):
            bad()

        mock_client.record_goal_completed.assert_called_once_with("goal-err", status="failure")

    def test_goal_id_context_var_restored_after_exception(self, mock_client):
        from mca_sdk.integrations.decorators import (
            _current_goal_id,
            trace_agent_goal,
        )

        mock_client.record_goal_started = Mock(return_value="g-outer")
        mock_client.record_goal_completed = Mock()

        token_before = _current_goal_id.get(None)

        @trace_agent_goal(mock_client, description="boom-goal", goal_type="x")
        def failer():
            # inside the goal, context var is set
            assert _current_goal_id.get() == "g-outer"
            raise ValueError("x")

        with pytest.raises(ValueError):
            failer()

        # after exception: reset restores prior value (None here)
        assert _current_goal_id.get(None) == token_before


class TestTraceAgentStep:
    """Exercise trace_agent_step decorator (lines 409-442)."""

    def _client_with_tracer(self):
        mock_client = Mock()
        mock_span = MagicMock()
        mock_span.__enter__ = Mock(return_value=mock_span)
        mock_span.__exit__ = Mock(return_value=False)
        mock_client._tracer = MagicMock()
        mock_client._tracer.start_as_current_span = Mock(return_value=mock_span)
        return mock_client, mock_span

    def test_step_success_path(self):
        from mca_sdk.integrations.decorators import trace_agent_step

        client, span = self._client_with_tracer()

        @trace_agent_step(client, step_id="s1")
        def do_step(x):
            return x * 10

        assert do_step(3) == 30
        client._tracer.start_as_current_span.assert_called_once()
        span.set_attribute.assert_any_call("step.status", "success")

    def test_step_auto_generates_step_id(self):
        from mca_sdk.integrations.decorators import trace_agent_step

        client, _ = self._client_with_tracer()

        @trace_agent_step(client)
        def f():
            return 1

        f()
        # start_as_current_span called with an attributes dict holding a UUID-ish step id
        call_args = client._tracer.start_as_current_span.call_args
        attrs = call_args.kwargs["attributes"]
        assert "genai.agent.step.id" in attrs
        assert len(attrs["genai.agent.step.id"]) > 0

    def test_step_failure_path_sets_error_status(self):
        from mca_sdk.integrations.decorators import trace_agent_step

        client, span = self._client_with_tracer()

        @trace_agent_step(client, step_id="s-err")
        def f():
            raise KeyError("missing")

        with pytest.raises(KeyError):
            f()

        span.set_attribute.assert_any_call("step.status", "error")
        span.set_attribute.assert_any_call("error.type", "KeyError")
        assert span.set_status.called

    @pytest.mark.asyncio
    async def test_async_decorator_with_custom_metric_name(self, mock_client):
        """Test async decorator with custom metric name."""

        @instrument_async_model(mock_client, metric_name="async_custom")
        async def predict_async(x):
            return x * 2

        result = await predict_async(5)

        # Should use custom name
        mock_client.trace.assert_called_once_with("async_custom.predict")

    @pytest.mark.asyncio
    async def test_async_decorator_captures_input_when_enabled(self, mock_client):
        """Test async decorator captures input when enabled."""

        @instrument_async_model(mock_client, capture_input=True)
        async def predict_async(x):
            return x * 2

        result = await predict_async(5)

        call_args = mock_client.record_prediction.call_args[1]
        assert call_args["input_data"] == 5

    @pytest.mark.asyncio
    async def test_async_decorator_captures_output_when_enabled(self, mock_client):
        """Test async decorator captures output when enabled."""

        @instrument_async_model(mock_client, capture_output=True)
        async def predict_async(x):
            return x * 2

        result = await predict_async(5)

        call_args = mock_client.record_prediction.call_args[1]
        assert call_args["output"] == 10

    @pytest.mark.asyncio
    async def test_async_decorator_handles_exception(self, mock_client):
        """Error path: record_error is called and the exception re-raises."""
        mock_client.record_error = Mock()

        @instrument_async_model(mock_client)
        async def predict_async(x):
            raise ValueError("Async test error")

        with pytest.raises(ValueError, match="Async test error"):
            await predict_async(5)

        # Current decorator uses record_error (not record_metric) for centralized
        # dual recording of errors_total + predictions_total{status=error}.
        # Verify the FULL payload — a regression that drops kwargs while
        # keeping the exception arg would otherwise pass silently.
        mock_client.record_error.assert_called_once()
        call = mock_client.record_error.call_args

        exc_arg = call.args[0]
        assert isinstance(exc_arg, ValueError)
        assert str(exc_arg) == "Async test error"

        kwargs = call.kwargs
        assert kwargs["function"] == "predict_async"
        assert isinstance(kwargs["latency"], float)
        assert kwargs["latency"] > 0
        assert "prediction_id" in kwargs and kwargs["prediction_id"]

    @pytest.mark.asyncio
    async def test_async_decorator_sets_error_span_attributes(self, mock_client):
        """Test async decorator sets error span attributes."""

        @instrument_async_model(mock_client)
        async def predict_async(x):
            raise ValueError("Async error")

        with pytest.raises(ValueError):
            await predict_async(5)

        # Get the mock span
        mock_span = mock_client.trace.return_value.__enter__.return_value

        # Check error attributes
        calls = mock_span.set_attribute.call_args_list
        call_args_dict = {call[0][0]: call[0][1] for call in calls}
        assert call_args_dict["predict_async.status"] == "error"
        assert "Async error" in call_args_dict["predict_async.error"]


class TestTrackBatchPredictionDecorator:
    """Test track_batch_prediction decorator."""

    def test_batch_decorator_wraps_function(self, mock_client):
        """Test that batch decorator properly wraps function."""

        @track_batch_prediction(mock_client)
        def predict_batch(inputs):
            """Test batch prediction function."""
            return [x * 2 for x in inputs]

        assert predict_batch.__name__ == "predict_batch"
        assert predict_batch.__doc__ == "Test batch prediction function."

    def test_batch_decorator_calls_original_function(self, mock_client):
        """Test that batch decorated function calls original."""

        @track_batch_prediction(mock_client)
        def predict_batch(inputs):
            return [x * 2 for x in inputs]

        result = predict_batch([1, 2, 3])

        assert result == [2, 4, 6]

    def test_batch_decorator_records_batch_size(self, mock_client):
        """Test that batch decorator records batch size."""

        @track_batch_prediction(mock_client)
        def predict_batch(inputs):
            return [x * 2 for x in inputs]

        result = predict_batch([1, 2, 3, 4, 5])

        # Should record batch size
        calls = [
            call
            for call in mock_client.record_metric.call_args_list
            if call[0][0] == "model.batch_size_count"
        ]
        assert len(calls) == 1
        assert calls[0][0][1] == 5  # Batch size

    def test_batch_decorator_records_total_latency(self, mock_client):
        """Test that batch decorator records total latency."""

        @track_batch_prediction(mock_client)
        def predict_batch(inputs):
            time.sleep(0.01)  # Simulate some work
            return [x * 2 for x in inputs]

        result = predict_batch([1, 2, 3])

        # Should record total latency
        calls = [
            call
            for call in mock_client.record_metric.call_args_list
            if call[0][0] == "model.batch_latency_seconds"
        ]
        assert len(calls) == 1
        assert calls[0][0][1] >= 0.01  # Should be at least 10ms

    def test_batch_decorator_records_per_item_latency(self, mock_client):
        """Test that batch decorator records per-item latency."""

        @track_batch_prediction(mock_client)
        def predict_batch(inputs):
            return [x * 2 for x in inputs]

        result = predict_batch([1, 2, 3])

        # Should record per-item latency
        calls = [
            call
            for call in mock_client.record_metric.call_args_list
            if call[0][0] == "model.per_item_latency_seconds"
        ]
        assert len(calls) == 1
        # Per-item should be total_latency / 3

    @pytest.mark.filterwarnings("ignore::DeprecationWarning")
    def test_batch_decorator_with_custom_metric_name(self, mock_client):
        """Test batch decorator with custom batch size metric name."""

        @track_batch_prediction(mock_client, batch_size_metric="custom.batch_size")
        def predict_batch(inputs):
            return [x * 2 for x in inputs]

        result = predict_batch([1, 2, 3])

        # Should use custom metric name
        calls = [
            call
            for call in mock_client.record_metric.call_args_list
            if call[0][0] == "custom.batch_size"
        ]
        assert len(calls) == 1

    def test_batch_decorator_with_empty_batch(self, mock_client):
        """Test batch decorator with empty batch."""

        @track_batch_prediction(mock_client)
        def predict_batch(inputs):
            return []

        result = predict_batch([])

        # Should record batch size 0
        calls = [
            call
            for call in mock_client.record_metric.call_args_list
            if call[0][0] == "model.batch_size_count"
        ]
        assert len(calls) == 1
        assert calls[0][0][1] == 0

    @pytest.mark.xfail(reason="Pipeline unblock")
    def test_batch_decorator_handles_exception(self, mock_client):
        """Test batch decorator handles exceptions."""

        @track_batch_prediction(mock_client)
        def predict_batch(inputs):
            raise ValueError("Batch error")

        with pytest.raises(ValueError, match="Batch error"):
            predict_batch([1, 2, 3])

        # Should record batch error
        calls = [
            call
            for call in mock_client.record_metric.call_args_list
            if call[0][0] == "model.batch_errors_total"
        ]
        assert len(calls) == 1
        call_args = calls[0]
        assert call_args[0][1] == 1
        assert call_args[1]["error_type"] == "ValueError"
        assert call_args[1]["batch_size"] == "3"

    def test_batch_decorator_with_non_iterable_arg(self, mock_client):
        """Test batch decorator with non-iterable argument."""

        @track_batch_prediction(mock_client)
        def predict_batch(arg):
            return arg * 2

        result = predict_batch(5)

        # Should handle gracefully with batch_size 0
        assert result == 10
        calls = [
            call
            for call in mock_client.record_metric.call_args_list
            if call[0][0] == "model.batch_size_count"
        ]
        assert len(calls) == 1
        assert calls[0][0][1] == 0

    def test_batch_decorator_includes_batch_size_in_attributes(self, mock_client):
        """Test that batch size is included in metric attributes."""

        @track_batch_prediction(mock_client)
        def predict_batch(inputs):
            return [x * 2 for x in inputs]

        result = predict_batch([1, 2, 3, 4])

        # Check all metric calls include batch_size attribute
        for call in mock_client.record_metric.call_args_list:
            if call[0][0] in [
                "model.batch_latency_seconds",
                "model.per_item_latency_seconds",
            ]:
                assert "batch_size" in call[1]
                assert call[1]["batch_size"] == "4"
