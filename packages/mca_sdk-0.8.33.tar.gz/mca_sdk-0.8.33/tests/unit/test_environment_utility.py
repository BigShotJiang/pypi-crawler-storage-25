"""Tests for the shared production-environment detection utility.

Covers priority order, override flag, K8s namespace regex, GCP project
regex, explicit MCA_ENVIRONMENT precedence, and known false-positive
guards (e.g., "product-team"). This file replaces scattered assertions
that were previously embedded in queue-specific tests and gives DLQ
and TelemetryQueue a single source of truth.
"""

import pytest

from mca_sdk.utils.environment import (
    env_key_override_enabled,
    is_production_environment,
)

PROD_MARKER_VARS = ["ENV", "ENVIRONMENT", "DEPLOY_ENV", "APP_ENV"]

# All env vars the helper reads, for clean-slate fixtures.
ALL_VARS = [
    "MCA_ALLOW_ENV_KEYS_IN_PROD",
    "MCA_ENVIRONMENT",
    "ENV",
    "ENVIRONMENT",
    "DEPLOY_ENV",
    "APP_ENV",
    "KUBERNETES_SERVICE_HOST",
    "KUBERNETES_NAMESPACE",
    "GCP_PROJECT",
]


@pytest.fixture
def clean_env(monkeypatch):
    """Clear every env var is_production_environment consults."""
    for var in ALL_VARS:
        monkeypatch.delenv(var, raising=False)
    return monkeypatch


class TestOverrideFlag:
    """MCA_ALLOW_ENV_KEYS_IN_PROD must short-circuit production detection."""

    @pytest.mark.error_scenario
    @pytest.mark.parametrize("truthy", ["true", "1", "yes", "on", "TRUE", "Yes", "ON"])
    def test_override_truthy_values_return_false(self, clean_env, truthy):
        clean_env.setenv("MCA_ENVIRONMENT", "production")
        clean_env.setenv("MCA_ALLOW_ENV_KEYS_IN_PROD", truthy)
        assert is_production_environment() is False
        assert env_key_override_enabled() is True

    @pytest.mark.parametrize("falsy", ["false", "0", "no", "off", ""])
    def test_override_falsy_values_do_not_short_circuit(self, clean_env, falsy):
        clean_env.setenv("MCA_ENVIRONMENT", "production")
        clean_env.setenv("MCA_ALLOW_ENV_KEYS_IN_PROD", falsy)
        assert is_production_environment() is True
        assert env_key_override_enabled() is False

    @pytest.mark.error_scenario
    def test_override_outranks_k8s_and_gcp(self, clean_env):
        clean_env.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        clean_env.setenv("KUBERNETES_NAMESPACE", "prod-west")
        clean_env.setenv("GCP_PROJECT", "acme-prod")
        clean_env.setenv("MCA_ALLOW_ENV_KEYS_IN_PROD", "true")
        assert is_production_environment() is False


class TestMcaEnvironmentExplicit:
    """MCA_ENVIRONMENT is an explicit opt-in / opt-out."""

    def test_production_value(self, clean_env):
        clean_env.setenv("MCA_ENVIRONMENT", "production")
        assert is_production_environment() is True

    @pytest.mark.parametrize("value", ["development", "dev", "test", "testing"])
    def test_explicit_non_production_values(self, clean_env, value):
        clean_env.setenv("MCA_ENVIRONMENT", value)
        # These explicitly opt out even if OTHER markers say prod - they win
        # over the generic ENV/ENVIRONMENT markers.
        clean_env.setenv("ENV", "production")
        assert is_production_environment() is False

    def test_unknown_value_falls_through(self, clean_env):
        clean_env.setenv("MCA_ENVIRONMENT", "staging")
        clean_env.setenv("ENV", "production")
        # Staging not in the explicit-opt-out list, so ENV=production wins.
        assert is_production_environment() is True


class TestGenericEnvMarkers:
    @pytest.mark.parametrize("var", PROD_MARKER_VARS)
    @pytest.mark.parametrize("value", ["production", "prod", "prd", "PRODUCTION", "Prod"])
    def test_each_marker_detects_production(self, clean_env, var, value):
        clean_env.setenv(var, value)
        assert is_production_environment() is True

    @pytest.mark.parametrize("var", PROD_MARKER_VARS)
    @pytest.mark.parametrize("value", ["staging", "dev", "test", "qa", "", "production-like"])
    def test_each_marker_does_not_falsely_trigger(self, clean_env, var, value):
        clean_env.setenv(var, value)
        assert is_production_environment() is False


class TestKubernetesNamespace:
    def test_k8s_namespace_prod_detected(self, clean_env):
        clean_env.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        clean_env.setenv("KUBERNETES_NAMESPACE", "prod")
        assert is_production_environment() is True

    @pytest.mark.parametrize(
        "namespace",
        [
            "prod",
            "production",
            "my-prod-cluster",
            "cluster.prod.us",
            "acme_prod_main",
            "web-production",
        ],
    )
    def test_k8s_namespace_component_variants(self, clean_env, namespace):
        clean_env.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        clean_env.setenv("KUBERNETES_NAMESPACE", namespace)
        assert is_production_environment() is True

    @pytest.mark.parametrize(
        "namespace",
        [
            "development",
            "staging",
            "reproduction",
            "prodigy",
            "dev-for-product-team",
            "preprod",  # "prod" substring, not component - must NOT trigger
        ],
    )
    def test_k8s_namespace_false_positives_blocked(self, clean_env, namespace):
        clean_env.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        clean_env.setenv("KUBERNETES_NAMESPACE", namespace)
        assert is_production_environment() is False

    def test_k8s_namespace_ignored_without_service_host(self, clean_env):
        # Without KUBERNETES_SERVICE_HOST we're not in a K8s pod, so the
        # namespace env var (which could be set by anything) must be ignored.
        clean_env.setenv("KUBERNETES_NAMESPACE", "prod")
        assert is_production_environment() is False


class TestGcpProject:
    @pytest.mark.parametrize(
        "project",
        [
            "acme-prod",
            "acme_prod_main",
            "my-company_prod.cluster",
            "web-production-us",
            "prod",
            "production",
        ],
    )
    def test_gcp_project_component_variants(self, clean_env, project):
        clean_env.setenv("GCP_PROJECT", project)
        assert is_production_environment() is True

    @pytest.mark.parametrize(
        "project",
        [
            "reproduction-api",
            "prodigy-team",
            "my-staging",
            "dev-for-product-team",
            "",
        ],
    )
    def test_gcp_project_false_positives_blocked(self, clean_env, project):
        clean_env.setenv("GCP_PROJECT", project)
        assert is_production_environment() is False


class TestDefault:
    def test_no_markers_returns_false(self, clean_env):
        assert is_production_environment() is False
        assert env_key_override_enabled() is False
