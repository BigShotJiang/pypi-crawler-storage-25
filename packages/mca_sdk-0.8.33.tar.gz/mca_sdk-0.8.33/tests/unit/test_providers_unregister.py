"""Tests for providers.py unregister_provider and reference counting."""

import weakref
from unittest.mock import MagicMock, patch

import pytest
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.resources import Resource

from mca_sdk.core.providers import unregister_provider


def _make_mock_provider():
    """Create a real-enough MeterProvider to use as registry key."""
    resource = Resource.create({"service.name": "test"})
    provider = MeterProvider(resource=resource)
    return provider


class TestUnregisterProvider:
    def setup_method(self):
        """Inject a fresh WeakKeyDictionary into unregister_provider's module globals.

        Writing directly into __globals__ guarantees the test and unregister_provider
        share the exact same registry object regardless of any module double-import or
        pytest path manipulation that may have produced two provider module instances.
        """
        self._real_registry = unregister_provider.__globals__["_MCA_PROVIDER_REGISTRY"]
        self._test_registry = weakref.WeakKeyDictionary()
        unregister_provider.__globals__["_MCA_PROVIDER_REGISTRY"] = self._test_registry

    def teardown_method(self):
        """Restore original registry so other tests are unaffected."""
        unregister_provider.__globals__["_MCA_PROVIDER_REGISTRY"] = self._real_registry

    def _lock(self):
        return unregister_provider.__globals__["_MCA_PROVIDER_REGISTRY_LOCK"]

    def test_none_provider_returns_false(self):
        assert unregister_provider(None) is False

    def test_unknown_provider_returns_true(self):
        provider = _make_mock_provider()
        result = unregister_provider(provider)
        assert result is True

    def test_provider_with_refcount_one_returns_true_and_removes(self):
        provider = _make_mock_provider()
        with self._lock():
            self._test_registry[provider] = {
                "refcount": 1,
                "config_key": ("endpoint",),
                "prometheus_shutdown": None,
            }
        result = unregister_provider(provider)
        assert result is True
        assert provider not in self._test_registry

    def test_provider_with_refcount_two_returns_false_and_keeps(self):
        provider = _make_mock_provider()
        with self._lock():
            self._test_registry[provider] = {
                "refcount": 2,
                "config_key": ("endpoint",),
                "prometheus_shutdown": None,
            }
        result = unregister_provider(provider)
        assert result is False
        assert provider in self._test_registry
        assert self._test_registry[provider]["refcount"] == 1

    def test_prometheus_shutdown_called_when_last_ref(self):
        provider = _make_mock_provider()
        shutdown_fn = MagicMock()
        with self._lock():
            self._test_registry[provider] = {
                "refcount": 1,
                "config_key": ("endpoint",),
                "prometheus_shutdown": shutdown_fn,
            }
        unregister_provider(provider)
        shutdown_fn.assert_called_once()

    def test_prometheus_shutdown_not_called_when_refs_remain(self):
        provider = _make_mock_provider()
        shutdown_fn = MagicMock()
        with self._lock():
            self._test_registry[provider] = {
                "refcount": 2,
                "config_key": ("endpoint",),
                "prometheus_shutdown": shutdown_fn,
            }
        unregister_provider(provider)
        shutdown_fn.assert_not_called()

    def test_prometheus_shutdown_exception_does_not_propagate(self):
        provider = _make_mock_provider()
        shutdown_fn = MagicMock(side_effect=RuntimeError("shutdown error"))
        with self._lock():
            self._test_registry[provider] = {
                "refcount": 1,
                "config_key": ("endpoint",),
                "prometheus_shutdown": shutdown_fn,
            }
        result = unregister_provider(provider)
        assert result is True

    def test_otel_global_state_cleared_on_last_ref(self):
        provider = _make_mock_provider()
        with self._lock():
            self._test_registry[provider] = {
                "refcount": 1,
                "config_key": ("endpoint",),
                "prometheus_shutdown": None,
            }
        with patch("mca_sdk.core.providers.metrics") as mock_metrics:
            unregister_provider(provider)

    def test_refcount_zero_also_triggers_removal(self):
        provider = _make_mock_provider()
        with self._lock():
            self._test_registry[provider] = {
                "refcount": 0,
                "config_key": ("endpoint",),
                "prometheus_shutdown": None,
            }
        result = unregister_provider(provider)
        assert result is True
        assert provider not in self._test_registry
