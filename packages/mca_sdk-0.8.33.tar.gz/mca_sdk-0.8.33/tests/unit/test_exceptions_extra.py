import pytest


def test_mca_sdk_error_str():
    from mca_sdk.utils.exceptions import MCASDKError

    e = MCASDKError("Some random error")
    assert str(e) == "Some random error"


def test_mca_sdk_error_str_with_token(monkeypatch):
    from mca_sdk.utils.exceptions import MCASDKError

    monkeypatch.setenv("MCA_REGISTRY_TOKEN", "secret-token-12345")
    e = MCASDKError("Error with secret-token-12345 inside")
    # It might use sanitize_token or simple replace, so it should mask it
    assert "secret-token-12345" not in str(e)


def test_mca_sdk_error_str_no_token_env(monkeypatch):
    from mca_sdk.utils.exceptions import MCASDKError

    monkeypatch.delenv("MCA_REGISTRY_TOKEN", raising=False)
    e = MCASDKError("untouched message")
    assert str(e) == "untouched message"


def test_mca_sdk_error_str_token_not_present(monkeypatch):
    from mca_sdk.utils.exceptions import MCASDKError

    monkeypatch.setenv("MCA_REGISTRY_TOKEN", "secret-abc")
    e = MCASDKError("message without any token")
    assert str(e) == "message without any token"


def test_mca_sdk_error_str_import_fallback(monkeypatch):
    import sys

    import mca_sdk.utils.exceptions as exc_mod

    monkeypatch.setenv("MCA_REGISTRY_TOKEN", "secret-token-12345")

    # Stash the real module and override __import__ to force ImportError
    # for the sanitize_token circular import fallback (lines 44-47).
    real_import = __import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "mca_sdk.config.settings":
            raise ImportError("simulated circular import")
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr("builtins.__import__", fake_import)

    e = exc_mod.MCASDKError("Error with secret-token-12345 inside")
    result = str(e)

    assert "secret-token-12345" not in result
    # Fallback masks to ***<last4>
    assert "***2345" in result


def test_mca_sdk_error_str_short_token_fallback(monkeypatch):
    import mca_sdk.utils.exceptions as exc_mod

    monkeypatch.setenv("MCA_REGISTRY_TOKEN", "abc")

    real_import = __import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "mca_sdk.config.settings":
            raise ImportError("simulated")
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr("builtins.__import__", fake_import)

    e = exc_mod.MCASDKError("token abc leaked")
    # Token length <= 4 → masked to "****"
    result = str(e)
    assert "abc" not in result
    assert "****" in result


def test_validation_error_init():
    from mca_sdk.utils.exceptions import ValidationError

    e = ValidationError(
        "test",
        missing_fields=["a"],
        invalid_fields={"b": "c"},
        model_type="t",
        model_category="c",
    )
    assert e.missing_fields == ["a"]
    assert e.invalid_fields == {"b": "c"}
    assert e.model_type == "t"
    assert e.model_category == "c"


def test_validation_error_defaults():
    from mca_sdk.utils.exceptions import ValidationError

    e = ValidationError("just a message")
    assert e.missing_fields == []
    assert e.invalid_fields == {}
    assert e.model_type is None
    assert e.model_category is None
    assert str(e) == "just a message"


def test_all_exceptions():
    from mca_sdk.utils.exceptions import (
        BufferingError,
        CertificateError,
        CertificateExpiredError,
        CertificateLoadError,
        CertificateNotLoadedError,
        CertificateValidationError,
        ConfigNotFoundError,
        ConfigurationError,
        MCASDKError,
        RegistryAuthError,
        RegistryConfigNotFoundError,
        RegistryConnectionError,
        RegistryError,
        SecurityError,
        ValidationError,
    )

    # Every public exception must be an MCASDKError so catch-all handlers work.
    # Instantiate each to force the class body to execute at test time (some
    # coverage tools miss the class-declaration lines when the module was
    # imported before coverage.start()).
    instances = [
        MCASDKError("x"),
        ValidationError("x"),
        BufferingError("x"),
        ConfigurationError("x"),
        ConfigNotFoundError("x"),
        RegistryError("x"),
        RegistryConnectionError("x"),
        RegistryConfigNotFoundError("x"),
        RegistryAuthError("x"),
        SecurityError("x"),
        CertificateError("x"),
        CertificateLoadError("x"),
        CertificateValidationError("x"),
        CertificateExpiredError("x"),
        CertificateNotLoadedError("x"),
    ]
    for e in instances:
        assert str(e) == "x"

    assert issubclass(RegistryConnectionError, Exception)
    assert issubclass(RegistryAuthError, Exception)
    assert issubclass(RegistryConfigNotFoundError, Exception)
    assert issubclass(SecurityError, Exception)
    assert issubclass(CertificateError, Exception)
    assert issubclass(CertificateLoadError, Exception)
    assert issubclass(CertificateValidationError, Exception)
    assert issubclass(CertificateExpiredError, Exception)
    assert issubclass(CertificateNotLoadedError, Exception)

    for cls in (
        ValidationError,
        BufferingError,
        ConfigurationError,
        ConfigNotFoundError,
        RegistryError,
        RegistryConnectionError,
        RegistryConfigNotFoundError,
        RegistryAuthError,
        SecurityError,
        CertificateError,
        CertificateLoadError,
        CertificateValidationError,
        CertificateExpiredError,
        CertificateNotLoadedError,
    ):
        assert issubclass(cls, MCASDKError)

    # Registry subtree
    assert issubclass(RegistryConnectionError, RegistryError)
    assert issubclass(RegistryAuthError, RegistryError)
    assert issubclass(RegistryConfigNotFoundError, RegistryError)

    # Certificate subtree
    assert issubclass(CertificateError, SecurityError)
    for cls in (
        CertificateLoadError,
        CertificateValidationError,
        CertificateExpiredError,
        CertificateNotLoadedError,
    ):
        assert issubclass(cls, CertificateError)


def test_raising_and_catching_roundtrip():
    from mca_sdk.utils.exceptions import (
        CertificateExpiredError,
        CertificateError,
        MCASDKError,
    )

    with pytest.raises(MCASDKError):
        raise CertificateExpiredError("expired 2026-01-01")

    with pytest.raises(CertificateError) as excinfo:
        raise CertificateExpiredError("expired")
    assert "expired" in str(excinfo.value)
