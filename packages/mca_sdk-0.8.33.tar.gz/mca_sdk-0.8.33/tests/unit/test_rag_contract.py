"""Static-check guardrail for the RAG metric contract (AC-5).

This module is the programmatic enforcement of the parallel-array RAG
contract pinned in docs/api-contracts.md section 9.2. There is no SDK
emission code today (story 1-20 is still ready-for-dev), so behavioral
tests against an emission path are not feasible. Instead we scan the
SDK source tree for two failure modes:

1. Indexed-key emission (e.g. ``gen_ai.rag.documents.0.id``,
   ``gen_ai.rag.documents.1.score``). Every unique index value would
   create a new attribute key and blow up backend schema cardinality.
   AC-5 forbids this pattern outright.

2. RAG attribute names that don't match the contract. Any string
   literal of the form ``gen_ai.rag.<X>`` that appears in SDK source
   must be one of the five names enumerated in the spec. This catches
   future drift the moment story 1-20 (or any other PR) introduces a
   non-conforming name.

The check runs in <50ms and is wired into the unit-test gate, so a
non-conforming name fails CI before it lands.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

_SDK_ROOT = Path(__file__).resolve().parents[2] / "mca_sdk"

# AC-5 contract: the only legal gen_ai.rag.* attribute names.
_ALLOWED_RAG_ATTRIBUTE_NAMES = frozenset(
    {
        "gen_ai.rag.query",
        "gen_ai.rag.documents.count",
        "gen_ai.rag.documents.ids",
        "gen_ai.rag.documents.scores",
        "gen_ai.rag.documents.relevance",
        "gen_ai.rag.documents.truncated",
        "gen_ai.rag.documents.source_system",
        "gen_ai.rag.documents.score_metric",
        "gen_ai.rag.sampling_rate",
        "gen_ai.rag.parent_retrieval_id",
    }
)

# Indexed-key cardinality bomb pattern, e.g. ``gen_ai.rag.documents.0.id``.
_INDEXED_KEY_PATTERN = re.compile(r"gen_ai\.rag\.documents\.\d+\.")

# Any gen_ai.rag.* string-literal that appears in source. Captures the
# fully-qualified attribute name. We only flag names appearing inside
# string literals (quoted), since unquoted ``gen_ai.rag`` would be a
# Python attribute access on a hypothetical future helper module that
# doesn't exist today and isn't covered by AC-5.
_RAG_ATTR_LITERAL_PATTERN = re.compile(r'["\'](gen_ai\.rag(?:\.[a-z_][a-z0-9_]*)+)["\']')


def _iter_sdk_python_files() -> list[Path]:
    return sorted(p for p in _SDK_ROOT.rglob("*.py") if "__pycache__" not in p.parts)


def test_sdk_root_resolves():
    """Sanity check that the test is scanning the right tree."""
    assert _SDK_ROOT.is_dir(), f"SDK root not found at {_SDK_ROOT}"
    files = _iter_sdk_python_files()
    assert len(files) > 10, f"expected >10 SDK source files, scanned {len(files)}"


def test_no_indexed_key_rag_attributes_in_sdk_source():
    """AC-5 hard rule: no gen_ai.rag.documents.<int>.<...> in SDK source.

    Indexed-key emission is forbidden because each unique index value
    creates a new attribute key, blowing up backend schema cardinality.
    The contract mandates parallel arrays instead.
    """
    offenders: list[tuple[Path, int, str]] = []
    for path in _iter_sdk_python_files():
        for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if _INDEXED_KEY_PATTERN.search(line):
                offenders.append((path, lineno, line.strip()))

    assert not offenders, (
        "Indexed-key RAG attribute emission found (AC-5 cardinality safety violation):\n"
        + "\n".join(
            f"  {p.relative_to(_SDK_ROOT.parent)}:{lineno}: {snippet}"
            for p, lineno, snippet in offenders
        )
        + "\n\nUse parallel arrays per docs/api-contracts.md section 9.2."
    )


def test_every_gen_ai_rag_string_literal_matches_contract():
    """Any quoted ``gen_ai.rag.<...>`` in SDK source must be a contract name.

    Catches future story 1-20 (or any other PR) introducing a
    non-conforming name before it ships. If the SDK gains a legitimate
    new RAG attribute, update both ``_ALLOWED_RAG_ATTRIBUTE_NAMES`` here
    and docs/api-contracts.md section 9.2 in the same commit.
    """
    offenders: list[tuple[Path, int, str]] = []
    for path in _iter_sdk_python_files():
        for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            for match in _RAG_ATTR_LITERAL_PATTERN.finditer(line):
                name = match.group(1)
                if name not in _ALLOWED_RAG_ATTRIBUTE_NAMES:
                    offenders.append((path, lineno, name))

    assert not offenders, (
        "Non-contract gen_ai.rag.* attribute names found in SDK source:\n"
        + "\n".join(
            f"  {p.relative_to(_SDK_ROOT.parent)}:{lineno}: {name}" for p, lineno, name in offenders
        )
        + "\n\nAllowed names (docs/api-contracts.md section 9.2):\n  "
        + "\n  ".join(sorted(_ALLOWED_RAG_ATTRIBUTE_NAMES))
    )


@pytest.mark.parametrize(
    "snippet",
    [
        '"gen_ai.rag.documents.0.id"',
        "'gen_ai.rag.documents.1.score'",
        '"gen_ai.rag.documents.42.relevance"',
    ],
)
def test_indexed_key_pattern_actually_matches_synthetic_examples(snippet):
    """Self-test the regex so a buggy refactor of the pattern fails loud.

    If the regex stops matching the synthetic examples, the
    test_no_indexed_key_rag_attributes_in_sdk_source check above would
    silently pass even when the SDK gains an indexed-key emission. This
    parametrized test prevents that whole class of false-negative.
    """
    assert _INDEXED_KEY_PATTERN.search(snippet)


def test_indexed_key_pattern_does_not_match_parallel_array_names():
    """Counterpart of the regex self-test: contract names must NOT match
    the indexed-key pattern. If they did, we'd reject our own contract.
    """
    for name in _ALLOWED_RAG_ATTRIBUTE_NAMES:
        assert not _INDEXED_KEY_PATTERN.search(name), (
            f"contract name {name!r} unexpectedly matches the forbidden "
            f"indexed-key pattern; the regex needs tightening"
        )
