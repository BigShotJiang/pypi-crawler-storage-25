"""Tests for uncovered paths in integrations/bridge.py."""

import threading
from unittest.mock import MagicMock, Mock, patch

import pytest


def _make_bridge(fetch_return=None, fetch_side_effect=None, max_iterations=1):
    """Create a concrete VendorBridge subclass with mocked MCAClient."""
    from mca_sdk.integrations.bridge import VendorBridge

    class TestBridge(VendorBridge):
        def fetch_metrics(self):
            if fetch_side_effect:
                raise fetch_side_effect
            return fetch_return or {"predictions": 10}

        def transform_metrics(self, data):
            return {
                "gauges": {"accuracy": 0.95},
                "counters": {"predictions": data.get("predictions", 0)},
            }

    with patch("mca_sdk.integrations.bridge.MCAClient") as mock_client_class:
        mock_client = MagicMock()
        mock_client_class.return_value = mock_client
        bridge = TestBridge(
            service_name="test-svc",
            vendor_name="test-vendor",
            endpoint="https://example.com/metrics",
            poll_interval=0.01,
            max_iterations=max_iterations,
        )
        bridge._mock_client = mock_client
    return bridge


class TestFetchWithRetry:
    def test_returns_data_on_success(self):
        bridge = _make_bridge(fetch_return={"predictions": 5})
        result = bridge._fetch_with_retry()
        assert result == {"predictions": 5}

    def test_returns_none_after_all_attempts_fail(self):
        bridge = _make_bridge(fetch_side_effect=RuntimeError("API down"))
        bridge.retry_max_attempts = 2
        bridge.retry_base_delay = 0.001
        bridge._stop_event.clear()
        result = bridge._fetch_with_retry()
        assert result is None
        assert bridge._retry_count >= 1

    def test_stops_retry_when_stop_event_set(self):
        call_count = [0]

        def bad_fetch():
            call_count[0] += 1
            raise RuntimeError("fail")

        bridge = _make_bridge()
        bridge.retry_max_attempts = 5
        bridge.retry_base_delay = 0.001
        bridge._stop_event.set()  # Pre-set stop event

        # Monkey-patch fetch_metrics
        bridge.fetch_metrics = bad_fetch
        result = bridge._fetch_with_retry()
        # Either None (early exit) or raises – just don't hang
        assert result is None or call_count[0] <= 5


class TestPollLoop:
    def test_poll_loop_single_run_success(self):
        bridge = _make_bridge(fetch_return={"predictions": 10}, max_iterations=None)
        bridge._running = True
        bridge._poll_loop(single_run=True)
        assert bridge._poll_count == 1
        assert bridge._success_count == 1

    def test_poll_loop_single_run_fetch_returns_none(self):
        bridge = _make_bridge(max_iterations=None)
        bridge._running = True
        bridge.retry_max_attempts = 1
        bridge.retry_base_delay = 0.001

        bridge.fetch_metrics = lambda: (_ for _ in ()).throw(RuntimeError("down"))
        bridge._poll_loop(single_run=True)
        assert bridge._error_count >= 1

    def test_poll_loop_max_iterations_stops(self):
        bridge = _make_bridge(fetch_return={"predictions": 1}, max_iterations=2)
        bridge._running = True
        bridge.poll_interval = 0.001

        bridge._poll_loop(single_run=False)
        assert bridge._poll_count == 2

    def test_poll_loop_stop_event_breaks_loop(self):
        bridge = _make_bridge(fetch_return={"predictions": 1}, max_iterations=None)
        bridge._running = True
        bridge.poll_interval = 0.001
        bridge._stop_event.set()  # Pre-set to stop immediately after first wait
        bridge._poll_loop(single_run=False)

    def test_poll_loop_exception_increments_error_count(self):
        bridge = _make_bridge(max_iterations=None)
        bridge._running = True
        bridge.retry_max_attempts = 1
        bridge.retry_base_delay = 0.001

        # fetch_metrics raises, _fetch_with_retry returns None → error_count increments
        bridge.fetch_metrics = lambda: (_ for _ in ()).throw(RuntimeError("boom"))
        bridge._poll_loop(single_run=True)
        assert bridge._error_count >= 1

    def test_poll_loop_consecutive_errors_apply_backoff(self):
        bridge = _make_bridge(max_iterations=None)
        bridge._running = True
        bridge._consecutive_errors = 3  # Already at threshold
        bridge.retry_max_attempts = 1
        bridge.retry_base_delay = 0.001
        bridge._error_backoff_base = 0.001
        bridge._error_backoff_max = 0.01
        bridge._stop_event.set()  # Stop after backoff wait

        bridge.fetch_metrics = lambda: (_ for _ in ()).throw(RuntimeError("boom"))
        bridge._poll_loop(single_run=True)


class TestIsHealthy:
    def test_health_check_false_when_not_running(self):
        bridge = _make_bridge()
        bridge._running = False
        assert bridge.health_check() is False

    def test_health_check_false_when_thread_not_alive(self):
        bridge = _make_bridge()
        bridge._running = True
        bridge._worker_thread = Mock()
        bridge._worker_thread.is_alive.return_value = False
        assert bridge.health_check() is False

    def test_health_check_true_in_grace_period_before_first_success(self):
        bridge = _make_bridge()
        bridge._running = True
        bridge._worker_thread = Mock()
        bridge._worker_thread.is_alive.return_value = True
        bridge._last_successful_poll_time = None
        bridge._poll_count = 1
        result = bridge.health_check()
        assert result is True  # Within grace period (poll_count < 3)

    def test_health_check_false_when_stale_last_success(self):
        import time

        bridge = _make_bridge()
        bridge._running = True
        bridge._worker_thread = Mock()
        bridge._worker_thread.is_alive.return_value = True
        bridge._last_successful_poll_time = time.time() - 1000  # Way past threshold
        bridge.poll_interval = 30.0  # max_allowed_time = 60s; 1000s > 60s → fail
        assert bridge.health_check() is False

    def test_health_check_false_when_high_error_rate(self):
        import time

        bridge = _make_bridge()
        bridge._running = True
        bridge._worker_thread = Mock()
        bridge._worker_thread.is_alive.return_value = True
        bridge._last_successful_poll_time = time.time()  # Recent success
        bridge._poll_count = 10
        bridge._error_count = 8  # 80% error rate → fail
        assert bridge.health_check() is False

    def test_health_check_true_when_healthy(self):
        import time

        bridge = _make_bridge()
        bridge._running = True
        bridge._worker_thread = Mock()
        bridge._worker_thread.is_alive.return_value = True
        bridge._last_successful_poll_time = time.time()
        bridge._poll_count = 10
        bridge._success_count = 9
        bridge._error_count = 1  # 10% error rate → pass
        bridge.poll_interval = 30.0
        assert bridge.health_check() is True


class TestWaitForCompletion:
    def test_wait_for_completion_no_thread_returns_true(self):
        bridge = _make_bridge()
        bridge._worker_thread = None
        result = bridge.wait_for_completion(timeout=1.0)
        assert result is True

    def test_wait_for_completion_with_thread(self):
        bridge = _make_bridge()
        done_event = threading.Event()

        def worker():
            done_event.wait()

        t = threading.Thread(target=worker, daemon=True)
        t.start()
        bridge._worker_thread = t

        done_event.set()
        result = bridge.wait_for_completion(timeout=2.0)
        assert result is True
