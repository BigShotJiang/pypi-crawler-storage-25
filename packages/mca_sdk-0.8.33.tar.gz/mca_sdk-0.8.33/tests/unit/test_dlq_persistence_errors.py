"""Unit tests for DeadLetterQueue _save_to_disk error-handling branches:
ENOSPC (disk full recoverable), generic OSError, non-OSError exception,
consecutive-failure fail-fast threshold, and parent-directory creation
failure. Added for story 6-33 coverage climb."""

import errno
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from mca_sdk.resilience.dead_letter_queue import DeadLetterQueue
from mca_sdk.utils.exceptions import BufferingError


@pytest.fixture
def dlq(tmp_path):
    # Use a tmp_path so we don't collide with real DLQ files
    return DeadLetterQueue(
        max_size=10,
        persist_path=str(tmp_path / "dlq.json"),
    )


def _enqueue_one(dlq):
    """Enqueue a single item so _save_to_disk has something to write."""
    dlq.enqueue(
        item={"event": "test", "data": {"x": 1}},
        error=RuntimeError("test failure"),
        retry_count=1,
    )


class TestSaveToDiskErrorBranches:
    def test_enospc_is_logged_as_warning_without_raising(self, dlq, caplog):
        import logging

        _enqueue_one(dlq)

        with patch(
            "tempfile.mkstemp", side_effect=OSError(errno.ENOSPC, "No space left on device")
        ):
            with caplog.at_level(logging.WARNING, logger="mca_sdk.resilience.dead_letter_queue"):
                dlq._save_to_disk()

        # Should log ENOSPC as a recoverable warning, not raise
        assert any(
            "ENOSPC" in r.getMessage() or "No space left" in r.getMessage() for r in caplog.records
        )
        assert dlq._persist_failure_count >= 1

    def test_generic_os_error_is_logged_as_error(self, dlq, caplog):
        import logging

        _enqueue_one(dlq)

        with patch("tempfile.mkstemp", side_effect=OSError(errno.EACCES, "Permission denied")):
            with caplog.at_level(logging.ERROR, logger="mca_sdk.resilience.dead_letter_queue"):
                dlq._save_to_disk()

        assert any("Failed to persist" in r.getMessage() for r in caplog.records)
        assert dlq._persist_failure_count >= 1

    def test_non_os_error_is_logged_as_error(self, dlq, caplog):
        import logging

        _enqueue_one(dlq)

        with patch("tempfile.mkstemp", side_effect=RuntimeError("oh no")):
            with caplog.at_level(logging.ERROR, logger="mca_sdk.resilience.dead_letter_queue"):
                dlq._save_to_disk()

        assert any("Failed to persist" in r.getMessage() for r in caplog.records)

    def test_consecutive_failures_raise_buffering_error(self, dlq):
        _enqueue_one(dlq)
        dlq._max_consecutive_failures = 2

        with patch("tempfile.mkstemp", side_effect=OSError(errno.EACCES, "denied")):
            # First failure: caught silently, counter=1
            dlq._save_to_disk()
            # Second failure: hits threshold, raises BufferingError
            with pytest.raises(BufferingError, match="persistence failed"):
                dlq._save_to_disk()

    def test_consecutive_failures_on_runtime_error_also_raises(self, dlq):
        _enqueue_one(dlq)
        dlq._max_consecutive_failures = 2

        with patch("tempfile.mkstemp", side_effect=RuntimeError("explosion")):
            dlq._save_to_disk()
            with pytest.raises(BufferingError):
                dlq._save_to_disk()

    def test_parent_directory_creation_failure(self, tmp_path, caplog):
        import logging

        persist_path = str(tmp_path / "sub_dir" / "dlq.json")
        dlq = DeadLetterQueue(max_size=10, persist_path=persist_path)
        _enqueue_one(dlq)

        with patch("os.makedirs", side_effect=OSError("permission denied")):
            with caplog.at_level(logging.ERROR, logger="mca_sdk.resilience.dead_letter_queue"):
                dlq._save_to_disk()

        assert any("Failed to create DLQ directory" in r.getMessage() for r in caplog.records)
        assert dlq._persist_failure_count >= 1
