"""Tests for TelemetryQueue persist+no-encryption gating in production.

Covers the HIPAA-critical gate that converts the existing "unencrypted
persistence" warning into a BufferingError when the process is running
in a detected production environment. Dev/test paths preserve the
historical warning-only behavior so local iteration is not blocked.

Priority order expectations:
    1. MCA_ALLOW_ENV_KEYS_IN_PROD=true escape hatch downgrades to warning
       (the override log is emitted at CRITICAL by the shared helper).
    2. Otherwise, any production marker (MCA_ENVIRONMENT, ENV-family,
       K8s namespace, GCP_PROJECT) causes the fail-closed raise.
"""

import pytest

from mca_sdk.buffering.queue import TelemetryQueue
from mca_sdk.utils.exceptions import BufferingError

# Every env var the shared helper consults. Clean-sheet fixture keeps the
# conftest.py autouse MCA_ENV=staging from leaking into these tests.
ALL_VARS = [
    "MCA_ALLOW_ENV_KEYS_IN_PROD",
    "MCA_ENVIRONMENT",
    "MCA_ENV",
    "ENV",
    "ENVIRONMENT",
    "DEPLOY_ENV",
    "APP_ENV",
    "KUBERNETES_SERVICE_HOST",
    "KUBERNETES_NAMESPACE",
    "GCP_PROJECT",
]


@pytest.fixture
def clean_env(monkeypatch):
    for var in ALL_VARS:
        monkeypatch.delenv(var, raising=False)
    # Ensure _validate_persist_path accepts tmp_path under %TEMP%.
    monkeypatch.setenv("MCA_TESTING", "true")
    return monkeypatch


def _generate_queue_encryption_key_bytes():
    from cryptography.fernet import Fernet

    return Fernet.generate_key()


class TestPersistWithoutEncryptionGating:
    @pytest.mark.error_scenario
    @pytest.mark.parametrize(
        "var,value",
        [
            ("MCA_ENVIRONMENT", "production"),
            ("ENV", "production"),
            ("ENVIRONMENT", "prod"),
            ("DEPLOY_ENV", "prd"),
            ("APP_ENV", "PRODUCTION"),
            ("GCP_PROJECT", "acme-prod"),
        ],
    )
    def test_persist_without_encryption_raises_in_production(self, tmp_path, clean_env, var, value):
        clean_env.setenv(var, value)
        with pytest.raises(BufferingError, match="PRODUCTION HIPAA VIOLATION"):
            TelemetryQueue(
                max_size=10,
                persist=True,
                persist_path=str(tmp_path / "queue.json"),
                encryption_enabled=False,
            )

    @pytest.mark.error_scenario
    def test_kubernetes_namespace_prod_raises(self, tmp_path, clean_env):
        clean_env.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        clean_env.setenv("KUBERNETES_NAMESPACE", "prod-east")
        with pytest.raises(BufferingError, match="PRODUCTION HIPAA VIOLATION"):
            TelemetryQueue(
                max_size=10,
                persist=True,
                persist_path=str(tmp_path / "queue.json"),
                encryption_enabled=False,
            )

    def test_persist_without_encryption_warns_in_dev(self, tmp_path, clean_env, caplog):
        clean_env.setenv("MCA_ENVIRONMENT", "development")
        import logging

        caplog.set_level(logging.WARNING)
        queue = TelemetryQueue(
            max_size=10,
            persist=True,
            persist_path=str(tmp_path / "queue.json"),
            encryption_enabled=False,
        )
        try:
            assert any(
                "HIPAA COMPLIANCE WARNING" in rec.message for rec in caplog.records
            ), f"expected HIPAA warning, got: {[r.message for r in caplog.records]}"
        finally:
            queue.shutdown()

    @pytest.mark.error_scenario
    def test_override_flag_downgrades_to_warning_in_production(self, tmp_path, clean_env, caplog):
        import logging

        clean_env.setenv("MCA_ENVIRONMENT", "production")
        clean_env.setenv("MCA_ALLOW_ENV_KEYS_IN_PROD", "true")
        caplog.set_level(logging.WARNING)

        # Override makes is_production_environment() return False, so the
        # HIPAA gate short-circuits to the warning-only path. The override
        # helper itself logs CRITICAL; the warning should still fire.
        queue = TelemetryQueue(
            max_size=10,
            persist=True,
            persist_path=str(tmp_path / "queue.json"),
            encryption_enabled=False,
        )
        try:
            assert any("HIPAA COMPLIANCE WARNING" in rec.message for rec in caplog.records)
            assert any("SECURITY OVERRIDE ACTIVE" in rec.message for rec in caplog.records)
        finally:
            queue.shutdown()

    def test_persist_with_encryption_succeeds_in_production(self, tmp_path, clean_env):
        from mca_sdk.security.encryption import QueueEncryption

        clean_env.setenv("MCA_ENVIRONMENT", "production")
        enc = QueueEncryption(encryption_keys=[_generate_queue_encryption_key_bytes()])
        queue = TelemetryQueue(
            max_size=10,
            persist=True,
            persist_path=str(tmp_path / "queue.json"),
            encryption=enc,
            encryption_enabled=True,
        )
        try:
            # Sanity: queue actually works.
            queue.enqueue({"metric": "x", "value": 1})
            assert queue.size() == 1
        finally:
            queue.shutdown()

    def test_no_persist_is_not_gated_in_production(self, clean_env):
        """Pure-memory queues have no on-disk PHI risk; gate must not fire."""
        clean_env.setenv("MCA_ENVIRONMENT", "production")
        queue = TelemetryQueue(max_size=10, persist=False, encryption_enabled=False)
        try:
            queue.enqueue({"metric": "x", "value": 1})
            assert queue.size() == 1
        finally:
            queue.shutdown()

    @pytest.mark.error_scenario
    def test_gate_message_mentions_remediation(self, tmp_path, clean_env):
        clean_env.setenv("MCA_ENVIRONMENT", "production")
        with pytest.raises(BufferingError) as exc_info:
            TelemetryQueue(
                max_size=10,
                persist=True,
                persist_path=str(tmp_path / "queue.json"),
                encryption_enabled=False,
            )
        msg = str(exc_info.value)
        assert "QueueEncryption" in msg
        assert "encryption_enabled=True" in msg
        assert "MCA_ALLOW_ENV_KEYS_IN_PROD" in msg
