"""Tests for mca_sdk/integrations/_genai_attrs.py."""

import pytest


class TestExtractProvider:
    def test_empty_model_returns_unknown(self):
        from mca_sdk.integrations._genai_attrs import extract_provider

        assert extract_provider("") == "unknown"

    def test_slash_prefix_extracts_provider(self):
        from mca_sdk.integrations._genai_attrs import extract_provider

        assert extract_provider("openai/gpt-4") == "openai"
        assert extract_provider("anthropic/claude-3") == "anthropic"
        assert extract_provider("ollama/llama2") == "ollama"

    def test_gpt_prefix_returns_openai(self):
        from mca_sdk.integrations._genai_attrs import extract_provider

        assert extract_provider("gpt-4") == "openai"
        assert extract_provider("gpt-3.5-turbo") == "openai"
        assert extract_provider("GPT-4") == "openai"

    def test_claude_prefix_returns_anthropic(self):
        from mca_sdk.integrations._genai_attrs import extract_provider

        assert extract_provider("claude-3-opus") == "anthropic"
        assert extract_provider("Claude-2") == "anthropic"

    def test_gemini_prefix_returns_google(self):
        from mca_sdk.integrations._genai_attrs import extract_provider

        assert extract_provider("gemini-pro") == "google"
        assert extract_provider("GEMINI-1.5") == "google"

    def test_llama_prefix_returns_meta(self):
        from mca_sdk.integrations._genai_attrs import extract_provider

        assert extract_provider("llama-2-70b") == "meta"
        assert extract_provider("LLaMA-3") == "meta"

    def test_mistral_prefix_returns_mistral(self):
        from mca_sdk.integrations._genai_attrs import extract_provider

        assert extract_provider("mistral-7b") == "mistral"
        assert extract_provider("Mistral-Large") == "mistral"

    def test_unknown_model_returns_unknown(self):
        from mca_sdk.integrations._genai_attrs import extract_provider

        assert extract_provider("custom-model-xyz") == "unknown"
        assert extract_provider("bert-base-uncased") == "unknown"


class TestBuildRequestAttributes:
    def test_basic_attributes_set(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4")
        assert attrs["gen_ai.request.model"] == "gpt-4"
        assert attrs["gen_ai.operation.name"] == "chat"
        assert attrs["gen_ai.system"] == "openai"
        assert attrs["llm.model"] == "gpt-4"
        assert attrs["langfuse.observation.type"] == "generation"

    def test_explicit_provider_overrides_inference(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", provider="azure")
        assert attrs["gen_ai.system"] == "azure"
        assert attrs["llm.provider"] == "azure"

    def test_custom_operation(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", operation="embeddings")
        assert attrs["gen_ai.operation.name"] == "embeddings"

    def test_temperature_included_when_provided(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", temperature=0.7)
        assert attrs["gen_ai.request.temperature"] == 0.7
        assert attrs["llm.temperature"] == 0.7

    def test_temperature_excluded_when_none(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", temperature=None)
        assert "gen_ai.request.temperature" not in attrs

    def test_max_tokens_included(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", max_tokens=1000)
        assert attrs["gen_ai.request.max_tokens"] == 1000
        assert attrs["llm.max_tokens"] == 1000

    def test_top_p_included(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", top_p=0.9)
        assert attrs["gen_ai.request.top_p"] == 0.9
        assert attrs["llm.top_p"] == 0.9

    def test_stream_included(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", stream=True)
        assert attrs["llm.stream"] is True

    def test_all_optional_params_excluded_when_none(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4")
        assert "gen_ai.request.temperature" not in attrs
        assert "gen_ai.request.max_tokens" not in attrs
        assert "gen_ai.request.top_p" not in attrs
        assert "llm.stream" not in attrs

    def test_model_id_excluded_when_none(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4")
        assert "mca.model_id" not in attrs
        assert "model_id" not in attrs

    def test_model_id_included_when_provided(self):
        """F2/F9: namespaced span attribute (mca.model_id) plus legacy unprefixed key."""
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", model_id="mdl-abc123")
        assert attrs["mca.model_id"] == "mdl-abc123"
        # Legacy unprefixed key kept for parity with the metric label
        # alert-policy-sync already consumes.
        assert attrs["model_id"] == "mdl-abc123"

    def test_model_id_unspecified_sentinel_passes_through(self):
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", model_id="unspecified")
        assert attrs["mca.model_id"] == "unspecified"
        assert attrs["model_id"] == "unspecified"

    def test_model_id_error_sentinel_passes_through(self):
        """F5: 'error' is a distinct, valid sentinel for SDK-defect signal."""
        from mca_sdk.integrations._genai_attrs import build_request_attributes

        attrs = build_request_attributes("gpt-4", model_id="error")
        assert attrs["mca.model_id"] == "error"
        assert attrs["model_id"] == "error"


class TestBuildUsageAttributes:
    def test_basic_token_counts(self):
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes(prompt_tokens=100, completion_tokens=50)
        assert attrs["gen_ai.usage.prompt_tokens"] == 100
        assert attrs["gen_ai.usage.completion_tokens"] == 50
        assert attrs["gen_ai.usage.total_tokens"] == 150
        assert attrs["genai.tokens_prompt"] == 100
        assert attrs["genai.tokens_completion"] == 50
        assert attrs["genai.tokens_total"] == 150

    def test_explicit_total_tokens_takes_precedence(self):
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes(prompt_tokens=100, completion_tokens=50, total_tokens=200)
        assert attrs["gen_ai.usage.total_tokens"] == 200

    def test_cost_included_when_provided(self):
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes(cost_usd=0.002)
        assert attrs["gen_ai.usage.cost_usd"] == 0.002
        assert attrs["genai.cost_usd"] == 0.002

    def test_cost_excluded_when_none(self):
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes()
        assert "gen_ai.usage.cost_usd" not in attrs
        assert "genai.cost_usd" not in attrs

    def test_response_model_included_when_provided(self):
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes(response_model="gpt-4-0613")
        assert attrs["gen_ai.response.model"] == "gpt-4-0613"

    def test_response_model_excluded_when_none(self):
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes()
        assert "gen_ai.response.model" not in attrs

    def test_defaults_to_zeros(self):
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes()
        assert attrs["gen_ai.usage.prompt_tokens"] == 0
        assert attrs["gen_ai.usage.completion_tokens"] == 0
        assert attrs["gen_ai.usage.total_tokens"] == 0

    def test_model_id_excluded_when_none(self):
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes(prompt_tokens=10, completion_tokens=5)
        assert "mca.model_id" not in attrs
        assert "model_id" not in attrs

    def test_model_id_included_when_provided(self):
        """F3/F9: usage spans gain the same model_id correlation key."""
        from mca_sdk.integrations._genai_attrs import build_usage_attributes

        attrs = build_usage_attributes(prompt_tokens=10, completion_tokens=5, model_id="mdl-abc123")
        assert attrs["mca.model_id"] == "mdl-abc123"
        assert attrs["model_id"] == "mdl-abc123"
