"""Tests for uncovered paths in validation/attributes.py."""

import pytest

from mca_sdk.validation.attributes import (
    MAX_ATTRIBUTE_COUNT,
    MAX_ATTRIBUTE_LENGTH,
    MAX_KEY_LENGTH,
    MAX_NESTING_DEPTH,
    _log_missing_recommended_attributes,
    _validate_minimal_attributes,
    validate_attribute_count,
    validate_attribute_length,
    validate_attribute_structure,
    validate_resource_attributes,
)
from mca_sdk.utils.exceptions import ValidationError
import logging


class TestValidateMinimalAttributes:
    def test_none_service_name_raises(self):
        with pytest.raises(ValidationError, match="service.name"):
            _validate_minimal_attributes({})

    def test_empty_service_name_raises(self):
        with pytest.raises(ValidationError, match="service.name"):
            _validate_minimal_attributes({"service.name": ""})

    def test_non_string_service_name_raises(self):
        with pytest.raises(ValidationError, match="must be a string"):
            _validate_minimal_attributes({"service.name": 12345})

    def test_too_long_service_name_raises(self):
        with pytest.raises(ValidationError, match="exceeds maximum length"):
            _validate_minimal_attributes({"service.name": "x" * 1025})

    def test_valid_service_name_passes(self):
        _validate_minimal_attributes({"service.name": "my-service"})


class TestLogMissingRecommendedAttributes:
    def test_logs_missing_optional_attributes(self, caplog):
        logger = logging.getLogger("test")
        with caplog.at_level(logging.INFO):
            _log_missing_recommended_attributes(
                {"service.name": "svc"}, "internal", "regression", logger
            )

    def test_invalid_taxonomy_raises(self):
        logger = logging.getLogger("test")
        with pytest.raises(ValidationError, match="Invalid model taxonomy"):
            _log_missing_recommended_attributes(
                {"service.name": "svc"}, "invalid_cat", "invalid_type", logger
            )

    def test_no_missing_attributes_no_log(self, caplog):
        logger = logging.getLogger("test")
        attrs = {
            "service.name": "svc",
            "model.id": "mdl-001",
            "model.version": "1.0",
            "team.name": "team",
        }
        with caplog.at_level(logging.INFO):
            _log_missing_recommended_attributes(attrs, "internal", "regression", logger)


class TestValidateAttributeLength:
    def test_key_too_long_raises(self):
        with pytest.raises(ValidationError, match="key exceeds maximum length"):
            validate_attribute_length("k" * (MAX_KEY_LENGTH + 1), "value")

    def test_value_too_long_raises(self):
        with pytest.raises(ValidationError, match="value for"):
            validate_attribute_length("key", "v" * (MAX_ATTRIBUTE_LENGTH + 1))

    def test_valid_key_and_value_returns_true(self):
        assert validate_attribute_length("key", "value") is True

    def test_max_length_key_passes(self):
        assert validate_attribute_length("k" * MAX_KEY_LENGTH, "value") is True

    def test_max_length_value_passes(self):
        assert validate_attribute_length("key", "v" * MAX_ATTRIBUTE_LENGTH) is True


class TestValidateAttributeCount:
    def test_too_many_attributes_raises(self):
        attrs = {f"key_{i}": "val" for i in range(MAX_ATTRIBUTE_COUNT + 1)}
        with pytest.raises(ValidationError, match="Attribute count exceeds"):
            validate_attribute_count(attrs)

    def test_max_count_passes(self):
        attrs = {f"key_{i}": "val" for i in range(MAX_ATTRIBUTE_COUNT)}
        assert validate_attribute_count(attrs) is True

    def test_empty_attrs_passes(self):
        assert validate_attribute_count({}) is True


class TestValidateAttributeStructure:
    def test_deeply_nested_dict_raises(self):
        def make_nested(depth):
            if depth == 0:
                return {"leaf": "value"}
            return {"nested": make_nested(depth - 1)}

        deep_attrs = make_nested(MAX_NESTING_DEPTH + 1)
        with pytest.raises(ValidationError, match="nesting depth"):
            validate_attribute_structure(deep_attrs)

    def test_flat_dict_passes(self):
        assert validate_attribute_structure({"key": "value"}) is True

    def test_nested_within_limit_passes(self):
        attrs = {"a": {"b": {"c": "value"}}}
        assert validate_attribute_structure(attrs) is True

    def test_non_dict_passes(self):
        assert validate_attribute_structure("just_a_string") is True

    def test_empty_dict_passes(self):
        assert validate_attribute_structure({}) is True
