"""Tests for autolog/_lightgbm.py - LightGBM auto-instrumentation.

Story 6-33 (coverage climb) — covers mca_sdk/autolog/_lightgbm.py from the
0% baseline. Combines a mocked branch-coverage suite with a real-lightgbm
integration test (Finding 9 from the adversarial review).

Adversarial-review remediation (2026-05-12):
- Replaced fragile `teardown_method` with an autouse yield fixture so module
  state is restored even on test failure during collection or partial mutation
  (Finding 8).
- Tightened the loose `any("Booster.predict" in r.message ...)` assertion
  to require WARNING level + exact message + count == 1 (Finding 5).
- Added a real-lightgbm integration test that trains a tiny LGBMClassifier and
  exercises the wrapt patcher end-to-end, proving the patch path actually
  works (Finding 9 — heavy mocking previously gave a false 100% claim).
"""

import logging
import sys
from unittest.mock import MagicMock, patch

import pytest

wrapt = pytest.importorskip("wrapt", reason="wrapt not installed")

from mca_sdk.autolog._lightgbm import LightGBMPatcher, patch_lightgbm  # noqa: E402


class TestPatchLightgbm:
    def test_raises_import_error_when_lightgbm_not_installed(self):
        with patch.dict("sys.modules", {"lightgbm": None}):
            with pytest.raises(ImportError, match="lightgbm is not installed"):
                patch_lightgbm()

    def test_creates_patcher_and_calls_patch(self):
        mock_lgbm = MagicMock()
        mock_lgbm.Booster = MagicMock()

        with patch.dict("sys.modules", {"lightgbm": mock_lgbm}):
            from mca_sdk.autolog import _lightgbm

            with patch.object(_lightgbm, "LightGBMPatcher") as MockPatcher:
                patch_lightgbm(capture_input=True, capture_output=True, max_payload_size=5000)
                MockPatcher.assert_called_once_with(True, True, 5000)
                MockPatcher.return_value.patch.assert_called_once()


class TestLightGBMPatcher:
    def test_init_sets_framework_name(self):
        patcher = LightGBMPatcher()
        assert patcher.framework_name == "lightgbm"

    def test_init_defaults(self):
        patcher = LightGBMPatcher()
        assert patcher.capture_input is False
        assert patcher.capture_output is False
        assert patcher.max_payload_size == 10000

    def test_init_with_capture_options(self):
        patcher = LightGBMPatcher(capture_input=True, capture_output=True, max_payload_size=5000)
        assert patcher.capture_input is True
        assert patcher.capture_output is True
        assert patcher.max_payload_size == 5000

    def test_patch_with_mocked_lightgbm(self):
        mock_lgbm = MagicMock()
        mock_lgbm.Booster = MagicMock()
        mock_classifier = MagicMock()
        mock_regressor = MagicMock()
        mock_sklearn = MagicMock()
        mock_sklearn.LGBMClassifier = mock_classifier
        mock_sklearn.LGBMRegressor = mock_regressor

        patcher = LightGBMPatcher()
        with patch.dict(
            "sys.modules",
            {"lightgbm": mock_lgbm, "lightgbm.sklearn": mock_sklearn},
        ):
            with patch.object(patcher, "patch_method"):
                patcher.patch()

    def test_patch_handles_booster_attribute_error(self):
        mock_lgbm = MagicMock()
        mock_lgbm.Booster = MagicMock()
        mock_sklearn = MagicMock()
        mock_sklearn.LGBMClassifier = MagicMock()
        mock_sklearn.LGBMRegressor = MagicMock()

        patcher = LightGBMPatcher()
        with patch.dict(
            "sys.modules",
            {"lightgbm": mock_lgbm, "lightgbm.sklearn": mock_sklearn},
        ):
            with patch.object(patcher, "patch_method") as mock_pm:
                mock_pm.side_effect = AttributeError("Booster.predict not found")
                patcher.patch()

    def test_patch_handles_sklearn_import_error(self):
        mock_lgbm = MagicMock()
        mock_lgbm.Booster = MagicMock()

        patcher = LightGBMPatcher()
        with patch.dict(
            "sys.modules",
            {"lightgbm": mock_lgbm, "lightgbm.sklearn": None},
        ):
            with patch.object(patcher, "patch_method") as mock_pm:
                # Booster patch succeeds, sklearn raises ImportError
                call_count = [0]

                def side_effect(*args, **kwargs):
                    call_count[0] += 1
                    if call_count[0] > 1:
                        raise ImportError("lightgbm.sklearn not available")

                mock_pm.side_effect = side_effect
                patcher.patch()


@pytest.fixture(autouse=True)
def _restore_lightgbm_sys_modules():
    """Snapshot sys.modules entries that the tests below mutate, restore on
    exit regardless of test outcome.

    The previous `teardown_method` only ran on test exit, leaving leaked module
    state when a test errored mid-mutation — exactly the kind of test-ordering
    nondeterminism contributing to the ±4-line coverage variance per run.
    """
    keys = ("lightgbm", "lightgbm.sklearn", "mca_sdk.autolog._lightgbm")
    snapshot = {k: sys.modules.get(k) for k in keys}
    try:
        yield
    finally:
        for k, v in snapshot.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v


def _install_lightgbm_mock(with_sklearn=True):
    lightgbm_module = MagicMock()
    lightgbm_sklearn = MagicMock()

    class MockBooster:
        def predict(self, data):
            return [0.1, 0.9]

    class MockLGBMClassifier:
        def predict(self, X):
            return [0, 1]

        def predict_proba(self, X):
            return [[0.1, 0.9], [0.8, 0.2]]

    class MockLGBMRegressor:
        def predict(self, X):
            return [1.5, 2.5]

    lightgbm_module.Booster = MockBooster
    if with_sklearn:
        lightgbm_sklearn.LGBMClassifier = MockLGBMClassifier
        lightgbm_sklearn.LGBMRegressor = MockLGBMRegressor
        lightgbm_module.sklearn = lightgbm_sklearn
        sys.modules["lightgbm.sklearn"] = lightgbm_sklearn
    sys.modules["lightgbm"] = lightgbm_module

    return MockBooster, MockLGBMClassifier, MockLGBMRegressor


def _mock_client():
    mock_client = MagicMock()
    mock_client.trace = MagicMock(
        return_value=MagicMock(__enter__=MagicMock(), __exit__=MagicMock())
    )
    mock_client.record_prediction = MagicMock()
    return mock_client


class TestLightGBMAutologMocked:
    """Mocked tests — fast unit-level verification of branch coverage."""

    def test_patch_lightgbm_booster(self):
        Booster, _, _ = _install_lightgbm_mock()

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=_mock_client()):
            from mca_sdk.autolog._lightgbm import patch_lightgbm

            patch_lightgbm(capture_input=False, capture_output=False)
            result = Booster().predict(None)

        assert result == [0.1, 0.9]

    def test_patch_lightgbm_sklearn_classifier(self):
        _, LGBMClassifier, _ = _install_lightgbm_mock()
        mock_client = _mock_client()

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog._lightgbm import patch_lightgbm

            patch_lightgbm()

            clf = LGBMClassifier()
            assert clf.predict([[1, 2, 3]]) == [0, 1]
            mock_client.record_prediction.assert_called()

    def test_patch_lightgbm_sklearn_regressor(self):
        _, _, LGBMRegressor = _install_lightgbm_mock()
        mock_client = _mock_client()

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog._lightgbm import patch_lightgbm

            patch_lightgbm()

            reg = LGBMRegressor()
            assert reg.predict([[1, 2, 3]]) == [1.5, 2.5]
            mock_client.record_prediction.assert_called()

    def test_patch_lightgbm_classifier_predict_proba(self):
        _, LGBMClassifier, _ = _install_lightgbm_mock()
        mock_client = _mock_client()

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog._lightgbm import patch_lightgbm

            patch_lightgbm()

            clf = LGBMClassifier()
            out = clf.predict_proba([[1, 2, 3]])

        assert out == [[0.1, 0.9], [0.8, 0.2]]

    def test_patch_lightgbm_raises_when_not_installed(self):
        for name in ("lightgbm", "lightgbm.sklearn"):
            sys.modules.pop(name, None)

        # Make import fail by masking
        import builtins

        real_import = builtins.__import__

        def fake_import(name, *args, **kwargs):
            if name == "lightgbm" or name.startswith("lightgbm."):
                raise ImportError("lightgbm not installed")
            return real_import(name, *args, **kwargs)

        with patch.object(builtins, "__import__", side_effect=fake_import):
            from mca_sdk.autolog._lightgbm import patch_lightgbm

            with pytest.raises(ImportError, match="lightgbm is not installed"):
                patch_lightgbm()

    def test_patch_continues_when_sklearn_api_missing(self):
        # Booster present, sklearn module missing — patch_method calls for
        # LGBMClassifier/LGBMRegressor/predict_proba should log.debug and continue.
        _install_lightgbm_mock(with_sklearn=False)

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=_mock_client()):
            from mca_sdk.autolog._lightgbm import patch_lightgbm

            patch_lightgbm()  # must not raise

    def test_patch_handles_missing_booster_predict(self, caplog):
        # Booster exists but .predict attribute missing → patch_method raises
        # AttributeError, the except branch in _lightgbm.py:78 must fire and
        # log "lightgbm.Booster.predict not found, skipping" at WARNING.
        lightgbm_module = MagicMock()
        lightgbm_sklearn = MagicMock()

        class MockBoosterNoPredict:
            pass

        lightgbm_module.Booster = MockBoosterNoPredict
        lightgbm_module.sklearn = lightgbm_sklearn
        sys.modules["lightgbm"] = lightgbm_module
        sys.modules["lightgbm.sklearn"] = lightgbm_sklearn

        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=_mock_client()):
            from mca_sdk.autolog._lightgbm import (
                LightGBMPatcher,
                patch_lightgbm,
            )

            patcher = LightGBMPatcher(capture_input=True, capture_output=True, max_payload_size=512)
            assert patcher.framework_name == "lightgbm"

            with caplog.at_level(logging.WARNING, logger="mca_sdk.autolog._lightgbm"):
                patch_lightgbm()

        # Tightened (F5): require exact message AND WARNING level AND count == 1.
        # The previous loose `any("Booster.predict" in r.message ...)` would
        # have passed even if the message landed at DEBUG or appeared as a
        # substring of an unrelated record.
        warning_records = [
            r
            for r in caplog.records
            if r.levelno == logging.WARNING
            and r.getMessage() == "lightgbm.Booster.predict not found, skipping"
        ]
        assert len(warning_records) == 1, (
            f"expected exactly one WARNING with the precise message; "
            f"got {len(warning_records)}: {[r.getMessage() for r in caplog.records]}"
        )


# Marker for the real-lightgbm integration test. Skipped automatically if
# the lightgbm package is not installed in this environment, so the suite
# remains green on minimal dev installs while still proving the patcher works
# whenever lightgbm IS available (which is the case in CI per
# `setup.py` extras `genai` / `all`).
lightgbm = pytest.importorskip("lightgbm", reason="real lightgbm required for F9 test")


class TestLightGBMAutologReal:
    """Real-lightgbm integration test (Finding 9).

    Trains a tiny native lightgbm.Booster on a 10×2 toy dataset and asserts
    the wrapt patcher actually intercepts Booster.predict() and reports it
    through the mock MCAClient. The mocked tests above verify branch
    coverage; this test verifies the patcher works against a real lightgbm
    install.

    Native Booster API is used (not LGBMClassifier) so the test doesn't
    require scikit-learn — keeping the dev-test footprint minimal while
    still exercising the patch path on real lightgbm code.
    """

    def test_real_booster_predict_records_telemetry(self):
        # Make sure no leftover lightgbm-mock from earlier tests is hanging
        # around — the autouse fixture restores sys.modules but does not
        # un-patch wrapt'd methods. Drop the autolog module so patch_lightgbm
        # re-runs cleanly here.
        sys.modules.pop("mca_sdk.autolog._lightgbm", None)

        import lightgbm as lgb
        import numpy as np

        # Tiny toy dataset: 10 rows × 2 features, two classes
        X = np.array([[i, i * 2] for i in range(10)], dtype=np.float64)
        y = np.array([i % 2 for i in range(10)], dtype=np.int32)
        dtrain = lgb.Dataset(X, label=y)

        params = {
            "objective": "binary",
            "num_leaves": 3,
            "min_data_in_leaf": 1,
            "min_sum_hessian_in_leaf": 1e-3,
            "verbose": -1,
        }
        booster = lgb.train(params, dtrain, num_boost_round=2)

        mock_client = _mock_client()
        with patch("mca_sdk.core.client.MCAClient.get_instance", return_value=mock_client):
            from mca_sdk.autolog._lightgbm import patch_lightgbm

            patch_lightgbm()

            preds = booster.predict(np.array([[1, 2], [3, 6]], dtype=np.float64))

        # Real lightgbm returned real predictions
        assert len(preds) == 2

        # And the patcher intercepted the call: the mock client's trace()
        # context must have been entered, AND record_prediction must have
        # been invoked at least once with telemetry from the real predict.
        assert mock_client.trace.called, (
            "patcher failed to intercept real Booster.predict — " "wrapt wrapping is not effective"
        )
        assert (
            mock_client.record_prediction.called
        ), "patcher must call record_prediction() on real predict()"
