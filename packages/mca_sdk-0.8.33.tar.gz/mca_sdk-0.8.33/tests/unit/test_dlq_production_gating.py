"""Tests for DeadLetterQueue env-key production gating.

Parity with TelemetryQueue's MCA_QUEUE_ENCRYPTION_KEY policy: the DLQ
must refuse to load MCA_SDK_ENCRYPTION_KEY from the environment when
the process is running in a detected production environment, unless
the MCA_ALLOW_ENV_KEYS_IN_PROD override is explicitly set.

Explicit keys passed via the encryption_key kwarg are always allowed
(that's the production-recommended path - fetch from a secret manager
and pass the bytes in).
"""

import pytest

from mca_sdk.resilience.dead_letter_queue import DeadLetterQueue
from mca_sdk.security.encryption import EncryptionManager
from mca_sdk.utils.exceptions import BufferingError

ALL_VARS = [
    "MCA_ALLOW_ENV_KEYS_IN_PROD",
    "MCA_ENVIRONMENT",
    "MCA_ENV",
    "ENV",
    "ENVIRONMENT",
    "DEPLOY_ENV",
    "APP_ENV",
    "KUBERNETES_SERVICE_HOST",
    "KUBERNETES_NAMESPACE",
    "GCP_PROJECT",
    "MCA_SDK_ENCRYPTION_KEY",
]


@pytest.fixture
def clean_env(monkeypatch):
    for var in ALL_VARS:
        monkeypatch.delenv(var, raising=False)
    return monkeypatch


@pytest.fixture
def dlq_path(tmp_path):
    return str(tmp_path / "dlq.json")


@pytest.fixture
def valid_key_str():
    # EncryptionManager.generate_key returns a urlsafe base64-encoded Fernet key.
    return EncryptionManager.generate_key().decode("ascii")


class TestEnvKeyBlockedInProduction:
    @pytest.mark.error_scenario
    @pytest.mark.parametrize(
        "var,value",
        [
            ("MCA_ENVIRONMENT", "production"),
            ("ENV", "production"),
            ("ENVIRONMENT", "prod"),
            ("DEPLOY_ENV", "prd"),
            ("APP_ENV", "PRODUCTION"),
            ("GCP_PROJECT", "acme-prod"),
        ],
    )
    def test_env_key_blocked_in_production(self, clean_env, dlq_path, valid_key_str, var, value):
        clean_env.setenv(var, value)
        clean_env.setenv("MCA_SDK_ENCRYPTION_KEY", valid_key_str)
        with pytest.raises(BufferingError, match="PRODUCTION SECURITY VIOLATION"):
            DeadLetterQueue(max_size=10, persist_path=dlq_path)

    @pytest.mark.error_scenario
    def test_k8s_namespace_prod_blocks(self, clean_env, dlq_path, valid_key_str):
        clean_env.setenv("KUBERNETES_SERVICE_HOST", "10.0.0.1")
        clean_env.setenv("KUBERNETES_NAMESPACE", "prod-west")
        clean_env.setenv("MCA_SDK_ENCRYPTION_KEY", valid_key_str)
        with pytest.raises(BufferingError, match="PRODUCTION SECURITY VIOLATION"):
            DeadLetterQueue(max_size=10, persist_path=dlq_path)

    @pytest.mark.error_scenario
    def test_error_message_mentions_remediation(self, clean_env, dlq_path, valid_key_str):
        clean_env.setenv("MCA_ENVIRONMENT", "production")
        clean_env.setenv("MCA_SDK_ENCRYPTION_KEY", valid_key_str)
        with pytest.raises(BufferingError) as exc_info:
            DeadLetterQueue(max_size=10, persist_path=dlq_path)
        msg = str(exc_info.value)
        assert "encryption_key=" in msg
        assert "MCA_ALLOW_ENV_KEYS_IN_PROD" in msg
        assert "secret manager" in msg.lower()


class TestDevAllowedWithWarning:
    def test_env_key_allowed_in_dev_with_warning(self, clean_env, dlq_path, valid_key_str, caplog):
        import logging

        clean_env.setenv("MCA_ENVIRONMENT", "development")
        clean_env.setenv("MCA_SDK_ENCRYPTION_KEY", valid_key_str)
        caplog.set_level(logging.WARNING)

        dlq = DeadLetterQueue(max_size=10, persist_path=dlq_path)
        assert dlq._encryption_manager is not None
        assert any("MCA_SDK_ENCRYPTION_KEY" in rec.message for rec in caplog.records)

    def test_env_key_allowed_when_no_prod_markers(self, clean_env, dlq_path, valid_key_str, caplog):
        import logging

        clean_env.setenv("MCA_SDK_ENCRYPTION_KEY", valid_key_str)
        caplog.set_level(logging.WARNING)

        dlq = DeadLetterQueue(max_size=10, persist_path=dlq_path)
        assert dlq._encryption_manager is not None


class TestOverrideFlag:
    @pytest.mark.error_scenario
    def test_override_allows_env_key_in_production(
        self, clean_env, dlq_path, valid_key_str, caplog
    ):
        import logging

        clean_env.setenv("MCA_ENVIRONMENT", "production")
        clean_env.setenv("MCA_ALLOW_ENV_KEYS_IN_PROD", "true")
        clean_env.setenv("MCA_SDK_ENCRYPTION_KEY", valid_key_str)
        caplog.set_level(logging.CRITICAL)

        dlq = DeadLetterQueue(max_size=10, persist_path=dlq_path)
        assert dlq._encryption_manager is not None
        # The shared helper emits the override warning at CRITICAL.
        assert any("SECURITY OVERRIDE ACTIVE" in rec.message for rec in caplog.records)


class TestExplicitKeyBypassesGate:
    def test_explicit_key_allowed_in_production(self, clean_env, dlq_path):
        """Explicit kwargs are the recommended production path."""
        clean_env.setenv("MCA_ENVIRONMENT", "production")
        # Note: no MCA_SDK_ENCRYPTION_KEY is set.
        key = EncryptionManager.generate_key()

        dlq = DeadLetterQueue(
            max_size=10,
            persist_path=dlq_path,
            encryption_key=key,
            require_encryption=True,
        )
        assert dlq._encryption_manager is not None

    def test_explicit_key_not_gated_even_when_env_var_also_set(
        self, clean_env, dlq_path, valid_key_str
    ):
        """Explicit kwarg must NOT be treated as env-loaded."""
        clean_env.setenv("MCA_ENVIRONMENT", "production")
        clean_env.setenv("MCA_SDK_ENCRYPTION_KEY", valid_key_str)
        explicit_key = EncryptionManager.generate_key()

        # No exception - the explicit kwarg short-circuits env lookup entirely.
        dlq = DeadLetterQueue(max_size=10, persist_path=dlq_path, encryption_key=explicit_key)
        assert dlq._encryption_manager is not None


class TestExistingBehaviorPreserved:
    def test_no_key_no_require_encryption_unencrypted_warning(self, clean_env, dlq_path, caplog):
        """No env var, no explicit key, require_encryption=False -> warn path."""
        import logging

        # Note: no production marker, no key.
        caplog.set_level(logging.WARNING)
        dlq = DeadLetterQueue(max_size=10, persist_path=dlq_path, require_encryption=False)
        assert dlq._encryption_manager is None
        assert any("HIPAA COMPLIANCE WARNING" in rec.message for rec in caplog.records)
