"""Unit tests for mca_sdk/cli/_bootstrap.py covering _auto_init env-var
dispatch, _shutdown_with_timeout SIGALRM fallback paths, and the graceful
skip-on-missing-MCA_MODEL_ID guard. Added for story 6-33 coverage climb."""

import importlib
import logging
import os
import sys
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture(autouse=True)
def _clear_mca_env(monkeypatch):
    """Clear all MCA_* env vars before each test via monkeypatch.

    Using monkeypatch (rather than the previous hand-rolled try/finally that
    mutated os.environ directly) means pytest cleans up automatically even on
    test interrupt / crash, and the per-test contract is not silently bypassed.
    """
    for k in list(os.environ):
        if k.startswith("MCA_"):
            monkeypatch.delenv(k, raising=False)
    yield


def _reload_bootstrap_module():
    """Force reload of the bootstrap module so its module-level _auto_init() runs
    against the *current* environment.

    The caller is responsible for setting MCA_* vars via monkeypatch before
    invoking this helper — the previous version of this helper mutated
    os.environ directly inside a try/finally, which silently bypassed pytest's
    per-test cleanup contract.
    """
    sys.modules.pop("mca_sdk.cli._bootstrap", None)
    return importlib.import_module("mca_sdk.cli._bootstrap")


class TestAutoInitSkips:
    def test_skip_when_mca_model_id_unset(self, caplog):
        # No MCA_MODEL_ID → returns None without warning (expected path)
        with caplog.at_level(logging.WARNING, logger="mca_sdk.cli._bootstrap"):
            mod = _reload_bootstrap_module()
            result = mod._auto_init()
        assert result is None
        # No "auto-init skipped" warning since this is the expected no-op path
        assert not any("auto-init" in r.message for r in caplog.records)

    def test_skip_when_team_name_missing(self, caplog, monkeypatch):
        monkeypatch.setenv("MCA_MODEL_ID", "mdl-xyz")
        with caplog.at_level(logging.WARNING, logger="mca_sdk.cli._bootstrap"):
            mod = _reload_bootstrap_module()
            result = mod._auto_init()
        assert result is None
        assert any("missing env vars" in r.message for r in caplog.records)


class TestAutoInitSuccess:
    def test_minimum_required_env_vars_init(self, caplog, monkeypatch):
        # Patch MCAClient so construction doesn't need real collector
        with patch("mca_sdk.MCAClient") as MockClient:
            mock_client = MagicMock()
            MockClient.return_value = mock_client

            monkeypatch.setenv("MCA_MODEL_ID", "mdl-001")
            monkeypatch.setenv("MCA_TEAM_NAME", "clinical-ai")
            monkeypatch.setenv("MCA_SERVICE_NAME", "svc-1")
            monkeypatch.setenv("MCA_DISABLE_AUTOLOG", "true")

            mod = _reload_bootstrap_module()
            caplog.clear()
            with caplog.at_level(logging.INFO, logger="mca_sdk.cli._bootstrap"):
                result = mod._auto_init()

        assert result is mock_client
        assert MockClient.called
        init_kwargs = MockClient.call_args.kwargs
        assert init_kwargs["model_id"] == "mdl-001"
        assert init_kwargs["team_name"] == "clinical-ai"
        assert init_kwargs["service_name"] == "svc-1"
        assert any("autolog disabled" in r.getMessage() for r in caplog.records)

    def test_service_name_falls_back_to_model_id(self, monkeypatch):
        with patch("mca_sdk.MCAClient") as MockClient:
            MockClient.return_value = MagicMock()
            monkeypatch.setenv("MCA_MODEL_ID", "fallback-id")
            monkeypatch.setenv("MCA_TEAM_NAME", "t")
            monkeypatch.setenv("MCA_DISABLE_AUTOLOG", "true")

            mod = _reload_bootstrap_module()
            mod._auto_init()
            assert MockClient.call_args.kwargs["service_name"] == "fallback-id"

    def test_optional_env_vars_forwarded(self, monkeypatch):
        with patch("mca_sdk.MCAClient") as MockClient:
            MockClient.return_value = MagicMock()
            opt_env = {
                "MCA_MODEL_ID": "m",
                "MCA_TEAM_NAME": "t",
                "MCA_COLLECTOR_ENDPOINT": "http://collector:4318",
                "MCA_REGISTRY_URL": "https://registry.example.com",
                "MCA_USE_GCP_AUTH": "TRUE",
                "MCA_ALLOW_INSECURE_COLLECTOR": "true",
                "MCA_MODEL_VERSION": "2.0.0",
                "MCA_MODEL_TYPE": "regression",
                "MCA_MODEL_CATEGORY": "internal",
                "MCA_ENV": "production",
                "MCA_GCP_LOGGING_ENABLED": "true",
                "MCA_GCP_PROJECT_ID": "my-proj",
                "MCA_GCP_LOG_NAME": "mca-log",
                "MCA_GCP_TRACE_ENABLED": "true",
                "MCA_DISABLE_AUTOLOG": "true",
            }
            for k, v in opt_env.items():
                monkeypatch.setenv(k, v)

            mod = _reload_bootstrap_module()
            mod._auto_init()

            kwargs = MockClient.call_args.kwargs
            assert kwargs["collector_endpoint"] == "http://collector:4318"
            assert kwargs["registry_url"] == "https://registry.example.com"
            assert kwargs["use_gcp_auth"] is True
            assert kwargs["allow_insecure_collector"] is True
            assert kwargs["model_version"] == "2.0.0"
            assert kwargs["environment"] == "production"
            assert kwargs["gcp_logging_enabled"] is True
            assert kwargs["gcp_project_id"] == "my-proj"
            assert kwargs["gcp_log_name"] == "mca-log"
            assert kwargs["gcp_trace_enabled"] is True

    def test_mcaclient_constructor_failure_is_caught(self, caplog, monkeypatch):
        monkeypatch.setenv("MCA_MODEL_ID", "m")
        monkeypatch.setenv("MCA_TEAM_NAME", "t")
        monkeypatch.setenv("MCA_DISABLE_AUTOLOG", "true")

        with patch("mca_sdk.MCAClient", side_effect=RuntimeError("collector down")):
            mod = _reload_bootstrap_module()
            caplog.clear()
            with caplog.at_level(logging.WARNING, logger="mca_sdk.cli._bootstrap"):
                result = mod._auto_init()

        assert result is None
        assert any("auto-initialization failed" in r.getMessage() for r in caplog.records)

    def test_autolog_failure_does_not_prevent_init(self, caplog, monkeypatch):
        # Graceful-degradation contract: if autolog raises, _auto_init MUST
        # still return the client AND MUST log a warning so operators can find
        # out the auto-instrumentation failed.
        with patch("mca_sdk.MCAClient") as MockClient:
            mock_client = MagicMock()
            MockClient.return_value = mock_client

            monkeypatch.setenv("MCA_MODEL_ID", "m")
            monkeypatch.setenv("MCA_TEAM_NAME", "t")

            import mca_sdk as mca

            def broken_autolog():
                raise RuntimeError("patch explosion")

            monkeypatch.setattr(mca, "autolog", broken_autolog, raising=False)

            mod = _reload_bootstrap_module()
            caplog.clear()
            with caplog.at_level(logging.WARNING, logger="mca_sdk.cli._bootstrap"):
                result = mod._auto_init()

            assert result is mock_client
            # MUST be visible to operators — see _bootstrap.py:156
            failure_records = [
                r
                for r in caplog.records
                if r.levelno == logging.WARNING
                and "autolog initialization failed" in r.getMessage()
            ]
            assert len(failure_records) == 1, (
                "autolog failure must be logged at WARNING exactly once "
                f"(got {len(failure_records)})"
            )
            assert "patch explosion" in failure_records[0].getMessage()


class TestShutdownWithTimeout:
    def test_shutdown_successful(self):
        from mca_sdk.cli._bootstrap import _shutdown_with_timeout

        client = MagicMock()
        _shutdown_with_timeout(client, timeout=1.0)
        client.shutdown.assert_called_once()

    def test_shutdown_exception_is_swallowed(self, caplog):
        from mca_sdk.cli._bootstrap import _shutdown_with_timeout

        client = MagicMock()
        client.shutdown.side_effect = RuntimeError("cannot shut down")

        with caplog.at_level(logging.WARNING, logger="mca_sdk.cli._bootstrap"):
            # Must not raise even though shutdown() errored
            _shutdown_with_timeout(client, timeout=1.0)

        assert any("shutdown failed" in r.message for r in caplog.records)

    @pytest.mark.timeout(2)
    def test_alarm_handler_logs_warning(self, caplog):
        # Drive the inner _alarm_handler synchronously without any real
        # SIGALRM firing or time.sleep: capture the handler that the
        # bootstrap installs via signal.signal, then invoke it directly.
        # The previous version of this test slept 2 s and waited for a real
        # alarm to fire — slow and clock-flake-prone. This version is
        # ~milliseconds and deterministic.
        import signal as _signal

        from mca_sdk.cli._bootstrap import _shutdown_with_timeout

        captured = {}
        real_signal_signal = _signal.signal

        def capturing_signal(signum, handler):
            if signum == _signal.SIGALRM and callable(handler):
                captured["handler"] = handler
            # Return a benign default — we don't want to actually re-install
            # signal handlers on the running interpreter (pytest-timeout uses
            # SIGALRM internally).
            return _signal.SIG_DFL

        client = MagicMock()

        # Patch signal.signal AND signal.alarm so the bootstrap's
        # alarm-arming is a no-op and the registered handler is captured
        # without ever being delivered to the live process.
        with (
            patch.object(_signal, "signal", side_effect=capturing_signal),
            patch.object(_signal, "alarm"),
        ):
            _shutdown_with_timeout(client, timeout=1.0)

        assert "handler" in captured, "bootstrap must register a SIGALRM handler"

        # Drive the handler directly and assert it logs a warning at WARNING
        # level with the timeout context. This proves the timeout-fallback
        # code path actually emits operator-visible output.
        with caplog.at_level(logging.WARNING, logger="mca_sdk.cli._bootstrap"):
            captured["handler"](_signal.SIGALRM, None)

        warning_records = [
            r
            for r in caplog.records
            if r.levelno == logging.WARNING and "shutdown timed out" in r.getMessage()
        ]
        assert len(warning_records) == 1, (
            f"alarm handler must log exactly one timeout warning, " f"got {len(warning_records)}"
        )
