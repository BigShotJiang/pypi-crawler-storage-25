"""Unit tests for mca_sdk.security.phi_filter (story 6-31).

Covers PHI regex redaction of SSN/MRN/DOB patterns in attribute values,
short-string short-circuit, ``MCA_ENABLE_PHI_FILTER`` opt-in (and the
deprecated ``MCA_DISABLE_PHI_FILTER`` legacy alias), non-string
passthrough, and boundary cases. These run as part of tests/unit/ and
must not require network, Docker, or the OTel Collector.

The PHI filter is DISABLED BY DEFAULT (PHI sanitization is the caller's
responsibility per CLAUDE.md). ``TestFilterAttributes`` explicitly enables
the filter via an autouse fixture so it can verify redaction behavior.
``TestRedactPhi`` calls ``redact_phi`` directly, which is not gated by
the env var.
"""

import os

import pytest

from mca_sdk.security import phi_filter


class TestRedactPhi:
    def test_ssn_pattern_replaced_with_marker(self):
        assert phi_filter.redact_phi("patient 123-45-6789 admitted") == (
            "patient [REDACTED:SSN] admitted"
        )

    def test_mrn_pattern_replaced_with_marker(self):
        assert phi_filter.redact_phi("record MRN123456 exists") == ("record [REDACTED:MRN] exists")

    def test_dob_pattern_replaced_with_marker(self):
        assert phi_filter.redact_phi("dob=01/01/1980 stored") == ("dob=[REDACTED:DOB] stored")

    def test_multiple_patterns_in_one_string(self):
        src = "ssn=123-45-6789 dob=12/31/2000 mrn=MRN987654"
        out = phi_filter.redact_phi(src)
        assert "123-45-6789" not in out
        assert "12/31/2000" not in out
        assert "MRN987654" not in out
        assert "[REDACTED:SSN]" in out
        assert "[REDACTED:DOB]" in out
        assert "[REDACTED:MRN]" in out

    def test_benign_string_unchanged(self):
        value = "this is a perfectly normal attribute value with id abc-42"
        assert phi_filter.redact_phi(value) == value

    def test_short_string_short_circuited(self):
        assert phi_filter.redact_phi("x") == "x"
        assert phi_filter.redact_phi("") == ""

    def test_non_ssn_digit_groups_preserved(self):
        assert phi_filter.redact_phi("model v1-2-3 id 10-20-30") == ("model v1-2-3 id 10-20-30")

    # Round-2 hardening (findings 2-4): broader pattern coverage.

    def test_ssn_space_separated_variant_redacted(self):
        assert phi_filter.redact_phi("patient 123 45 6789 admitted") == (
            "patient [REDACTED:SSN] admitted"
        )

    def test_bare_nine_digit_ssn_NOT_redacted(self):
        # Intentional: 9-digit numeric strings collide with timestamps and
        # opaque IDs. Document the tradeoff by pinning it in a test.
        src = "event 123456789 fired"
        assert phi_filter.redact_phi(src) == src

    def test_mrn_case_insensitive(self):
        assert phi_filter.redact_phi("record mrn123456 exists") == ("record [REDACTED:MRN] exists")

    def test_mrn_with_space_or_dash_separator(self):
        assert phi_filter.redact_phi("record MRN 123456 exists") == ("record [REDACTED:MRN] exists")
        assert phi_filter.redact_phi("record MRN-123456 exists") == ("record [REDACTED:MRN] exists")

    def test_dob_dash_mdY_variant_redacted(self):
        assert phi_filter.redact_phi("dob=01-01-1980 stored") == ("dob=[REDACTED:DOB] stored")

    def test_dob_iso_Ymd_variant_redacted(self):
        assert phi_filter.redact_phi("dob=1980-01-01 stored") == ("dob=[REDACTED:DOB] stored")

    def test_short_mrn_five_digits_not_matched(self):
        # Regex requires 6+ digits after the MRN token. Five-digit tail stays.
        # Proves the short-circuit floor does not swallow near-boundary PHI:
        # we still scan strings >= 8 chars, we just don't match < 6-digit MRNs.
        src = "record MRN12345 stored"
        assert phi_filter.redact_phi(src) == src

    def test_short_circuit_does_not_mask_true_phi(self):
        # All three patterns are longer than _MIN_LEN, so nothing matchable
        # falls under the length floor. This pins the invariant.
        assert phi_filter.redact_phi("12") == "12"
        assert phi_filter.redact_phi("1234567") == "1234567"  # 7 chars


class TestFilterAttributes:
    @pytest.fixture(autouse=True)
    def _enable_filter(self, monkeypatch):
        # Filter is disabled by default; enable it for these tests so we
        # can verify redaction behavior end-to-end through filter_attributes.
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.setenv("MCA_ENABLE_PHI_FILTER", "true")

    def test_redacts_phi_in_string_values(self):
        out = phi_filter.filter_attributes(
            {"ssn_val": "123-45-6789", "safe": "ok", "mrn_val": "MRN123456"}
        )
        assert out["ssn_val"] == "[REDACTED:SSN]"
        assert out["mrn_val"] == "[REDACTED:MRN]"
        assert out["safe"] == "ok"

    def test_non_string_values_passthrough(self):
        src = {"latency": 0.5, "ok": True, "count": 42, "items": [1, 2, 3]}
        assert phi_filter.filter_attributes(src) == src

    def test_empty_dict_returns_empty(self):
        assert phi_filter.filter_attributes({}) == {}

    def test_returns_same_object_when_no_match(self):
        src = {"a": "no phi here", "b": 1}
        out = phi_filter.filter_attributes(src)
        assert out is src


class TestEnvVarParsing:
    """Coverage for the canonical and legacy env vars and unknown-value rejection."""

    @pytest.mark.parametrize("flag", ["1", "true", "TRUE", "yes", "on"])
    def test_enable_var_truthy_values(self, monkeypatch, flag):
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.setenv("MCA_ENABLE_PHI_FILTER", flag)
        assert phi_filter.is_enabled() is True
        assert phi_filter.is_disabled() is False

    @pytest.mark.parametrize("flag", ["0", "false", "FALSE", "no", "off"])
    def test_enable_var_falsy_values(self, monkeypatch, flag):
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.setenv("MCA_ENABLE_PHI_FILTER", flag)
        assert phi_filter.is_enabled() is False
        assert phi_filter.is_disabled() is True

    def test_both_unset_is_disabled(self, monkeypatch):
        monkeypatch.delenv("MCA_ENABLE_PHI_FILTER", raising=False)
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        assert phi_filter.is_enabled() is False
        assert phi_filter.is_disabled() is True

    @pytest.mark.parametrize("garbage", ["enable", "yes please", "maybe", "1.0", "y"])
    def test_unknown_value_raises_configuration_error(self, monkeypatch, garbage):
        from mca_sdk.utils.exceptions import ConfigurationError

        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.setenv("MCA_ENABLE_PHI_FILTER", garbage)
        with pytest.raises(ConfigurationError):
            phi_filter.is_enabled()

    def test_legacy_disable_var_emits_deprecation_warning(self, monkeypatch):
        monkeypatch.delenv("MCA_ENABLE_PHI_FILTER", raising=False)
        monkeypatch.setenv("MCA_DISABLE_PHI_FILTER", "false")
        with pytest.warns(DeprecationWarning, match="MCA_DISABLE_PHI_FILTER is deprecated"):
            assert phi_filter.is_enabled() is True

    def test_legacy_disable_true_keeps_filter_off(self, monkeypatch):
        monkeypatch.delenv("MCA_ENABLE_PHI_FILTER", raising=False)
        monkeypatch.setenv("MCA_DISABLE_PHI_FILTER", "true")
        with pytest.warns(DeprecationWarning):
            assert phi_filter.is_enabled() is False

    def test_canonical_var_wins_when_legacy_disagrees(self, monkeypatch):
        # Canonical says enable; legacy says disable. Canonical must win.
        monkeypatch.setenv("MCA_ENABLE_PHI_FILTER", "true")
        monkeypatch.setenv("MCA_DISABLE_PHI_FILTER", "true")
        with pytest.warns(DeprecationWarning, match="disagrees with"):
            assert phi_filter.is_enabled() is True


class TestFilterAttributesRecursion:
    """Round-2 hardening (finding #1 + #9): recursion into list/tuple/dict."""

    @pytest.fixture(autouse=True)
    def _enable_filter(self, monkeypatch):
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.setenv("MCA_ENABLE_PHI_FILTER", "true")

    def test_redacts_phi_inside_list_attribute(self):
        out = phi_filter.filter_attributes({"notes": ["patient", "ssn 123-45-6789", "ok"]})
        assert out["notes"] == ["patient", "ssn [REDACTED:SSN]", "ok"]

    def test_redacts_phi_inside_tuple_attribute(self):
        out = phi_filter.filter_attributes({"notes": ("patient", "mrn MRN123456")})
        assert out["notes"] == ("patient", "mrn [REDACTED:MRN]")

    def test_redacts_phi_inside_nested_dict_attribute(self):
        out = phi_filter.filter_attributes(
            {"input_data": {"row": {"ssn": "123-45-6789", "age": 40}}}
        )
        assert out["input_data"]["row"]["ssn"] == "[REDACTED:SSN]"
        assert out["input_data"]["row"]["age"] == 40

    def test_redacts_phi_inside_mixed_list_of_dicts(self):
        out = phi_filter.filter_attributes(
            {
                "rows": [
                    {"mrn": "MRN123456"},
                    {"name": "jane"},
                ]
            }
        )
        assert out["rows"][0]["mrn"] == "[REDACTED:MRN]"
        assert out["rows"][1]["name"] == "jane"

    def test_non_matching_list_returns_same_object(self):
        src = {"tags": ["ok", "fine"]}
        out = phi_filter.filter_attributes(src)
        assert out is src
