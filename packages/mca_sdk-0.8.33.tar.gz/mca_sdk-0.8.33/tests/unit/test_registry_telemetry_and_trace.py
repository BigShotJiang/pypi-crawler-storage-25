"""Tests for registry/telemetry.py and gcp_trace_exporter rate limiter."""

import time
from unittest.mock import MagicMock, patch

import pytest


class TestRegistryTelemetry:
    def _make_mock_meter(self):
        meter = MagicMock()
        meter.create_counter.return_value = MagicMock()
        meter.create_histogram.return_value = MagicMock()
        return meter

    def test_init_with_provided_meter(self):
        from mca_sdk.registry.telemetry import RegistryTelemetry

        meter = self._make_mock_meter()
        telemetry = RegistryTelemetry(meter=meter)
        assert telemetry._meter is meter
        meter.create_counter.assert_called()
        meter.create_histogram.assert_called()

    def test_init_without_meter_uses_default(self):
        from mca_sdk.registry.telemetry import RegistryTelemetry

        mock_meter = self._make_mock_meter()
        with patch("mca_sdk.registry.telemetry.metrics") as mock_metrics:
            mock_metrics.get_meter.return_value = mock_meter
            telemetry = RegistryTelemetry()
            mock_metrics.get_meter.assert_called_once_with("mca.registry")
            assert telemetry._meter is mock_meter

    def test_record_success_increments_counter_and_histogram(self):
        from mca_sdk.registry.telemetry import RegistryTelemetry

        meter = self._make_mock_meter()
        telemetry = RegistryTelemetry(meter=meter)
        telemetry.record_success(latency=0.125)
        telemetry.refresh_success_counter.add.assert_called_once_with(1)
        telemetry.refresh_latency_histogram.record.assert_called_once_with(0.125)

    def test_record_error_increments_error_counter(self):
        from mca_sdk.registry.telemetry import RegistryTelemetry

        meter = self._make_mock_meter()
        telemetry = RegistryTelemetry(meter=meter)
        telemetry.record_error("RegistryConnectionError")
        telemetry.errors_counter.add.assert_called_once_with(
            1, {"error_type": "RegistryConnectionError"}
        )


class TestTruncationWarningRateLimiter:
    def test_init_defaults(self):
        from mca_sdk.exporters.gcp_trace_exporter import _TruncationWarningRateLimiter

        limiter = _TruncationWarningRateLimiter()
        assert limiter._max_warnings == 10
        assert limiter._warnings_issued == 0

    def test_init_custom_max(self):
        from mca_sdk.exporters.gcp_trace_exporter import _TruncationWarningRateLimiter

        limiter = _TruncationWarningRateLimiter(max_warnings_per_minute=5)
        assert limiter._max_warnings == 5

    def test_should_warn_returns_true_under_limit(self):
        from mca_sdk.exporters.gcp_trace_exporter import _TruncationWarningRateLimiter

        limiter = _TruncationWarningRateLimiter(max_warnings_per_minute=3)
        assert limiter.should_warn() is True
        assert limiter.should_warn() is True
        assert limiter.should_warn() is True

    def test_should_warn_returns_false_over_limit(self):
        from mca_sdk.exporters.gcp_trace_exporter import _TruncationWarningRateLimiter

        limiter = _TruncationWarningRateLimiter(max_warnings_per_minute=2)
        limiter.should_warn()
        limiter.should_warn()
        assert limiter.should_warn() is False

    def test_should_warn_resets_after_minute(self):
        from mca_sdk.exporters.gcp_trace_exporter import _TruncationWarningRateLimiter

        limiter = _TruncationWarningRateLimiter(max_warnings_per_minute=1)
        limiter.should_warn()
        assert limiter.should_warn() is False
        # Simulate time passing (61 seconds ago)
        limiter._last_reset = time.time() - 61
        assert limiter.should_warn() is True
