"""Tests for Registry cache bounded-staleness (StaleConfigError).

Covers:
- _get_cached raises StaleConfigError when fetched_at is older than the cap
- stale entries are PRESERVED in cache for forensics (not evicted)
- successful refresh clears the stale state via fetched_at reset
- fetch_model_config / fetch_deployment_config propagate the error
- max_stale_secs=0 disables the cap (backward-compat)
- MCAConfig validates registry_max_stale_secs >= refresh_interval_secs
- stale_config_errors_total metric is incremented
- refresh loop catches StaleConfigError and continues (ordering matters
  because StaleConfigError inherits from RegistryError)
"""

import time
from unittest.mock import MagicMock, patch

import pytest

from mca_sdk.config.settings import MCAConfig
from mca_sdk.registry.client import CacheEntry, RegistryClient
from mca_sdk.registry.models import DeploymentConfig, ModelConfig
from mca_sdk.utils.exceptions import (
    ConfigurationError,
    RegistryConnectionError,
    RegistryError,
    StaleConfigError,
)


def _make_model_config(model_id: str = "mdl-001", version: str = "1.0.0") -> ModelConfig:
    return ModelConfig(
        service_name="test-service",
        model_id=model_id,
        model_version=version,
        team_name="test-team",
        model_category="internal",
        model_type="regression",
    )


def _make_deployment_config(
    deployment_id: str = "dep-001",
) -> DeploymentConfig:
    return DeploymentConfig(deployment_id=deployment_id, environment="prod", region="us-central1")


@pytest.fixture
def client():
    """RegistryClient with a 60s stale cap and no network.

    cache_ttl_secs matches max_stale_secs so the tests exercise the
    stale-cap branch without hitting the new ctor-level guard that requires
    max_stale_secs >= cache_ttl_secs.
    """
    c = RegistryClient(
        url="http://localhost:8080",
        cache_ttl_secs=60,
        refresh_interval_secs=0,  # disable background thread for deterministic tests
        max_stale_secs=60,
    )
    yield c
    # Defensive teardown: ensure background thread (if any) is stopped.
    # refresh_interval_secs=0 should prevent the thread from starting, but
    # guard against accidental leaks from future refactors.
    try:
        c.stop_refresh_thread(timeout=1.0)
    except Exception:
        pass


@pytest.fixture
def client_no_cap():
    c = RegistryClient(
        url="http://localhost:8080",
        cache_ttl_secs=60,
        refresh_interval_secs=0,
        max_stale_secs=0,  # disabled
    )
    yield c
    try:
        c.stop_refresh_thread(timeout=1.0)
    except Exception:
        pass


class TestGetCachedStaleCap:
    def test_returns_value_under_cap(self, client):
        key = "model:mdl-001:latest"
        config = _make_model_config()
        client._set_cache(key, config)

        # Entry is fresh.
        assert client._get_cached(key) is config

    @pytest.mark.error_scenario
    def test_raises_stale_config_error_over_cap(self, client):
        key = "model:mdl-001:latest"
        config = _make_model_config()
        client._set_cache(key, config)

        # Age the entry past the 60s cap without modifying expires_at
        # (so we specifically exercise the stale branch, not the TTL branch).
        entry = client._cache[key]
        entry.fetched_at = time.time() - 120  # 2 minutes old
        entry.expires_at = time.time() + 300  # still within TTL

        with pytest.raises(StaleConfigError, match="stale"):
            client._get_cached(key)

    @pytest.mark.error_scenario
    def test_stale_entry_preserved_after_raise(self, client):
        """Forensics: stale branch does NOT evict the entry."""
        key = "model:mdl-001:latest"
        config = _make_model_config()
        client._set_cache(key, config)

        entry = client._cache[key]
        entry.fetched_at = time.time() - 120
        entry.expires_at = time.time() + 300

        with pytest.raises(StaleConfigError):
            client._get_cached(key)

        # Entry remains in cache.
        assert key in client._cache
        assert client._cache[key].value is config

    def test_ttl_expiry_path_still_evicts(self, client):
        """TTL path is unchanged: expired entries are still removed."""
        key = "model:mdl-001:latest"
        config = _make_model_config()
        client._set_cache(key, config)

        # Expire via TTL only (NOT the stale cap).
        entry = client._cache[key]
        entry.expires_at = time.time() - 10
        # Keep fetched_at recent so the stale branch does NOT fire.
        entry.fetched_at = time.time() - 5

        assert client._get_cached(key) is None
        assert key not in client._cache  # TTL path evicts

    def test_successful_refresh_clears_stale_state(self, client):
        key = "model:mdl-001:latest"
        config = _make_model_config()
        client._set_cache(key, config)

        entry = client._cache[key]
        entry.fetched_at = time.time() - 120
        entry.expires_at = time.time() + 300

        with pytest.raises(StaleConfigError):
            client._get_cached(key)

        # Simulate a successful refresh (e.g., by fetch_model_config).
        fresh_config = _make_model_config(version="2.0.0")
        client._set_cache(key, fresh_config)

        # Stale state cleared; new value returned.
        assert client._get_cached(key) is fresh_config

    def test_max_stale_secs_zero_disables_cap(self, client_no_cap):
        """Backward compatibility: cap disabled by default (0)."""
        key = "model:mdl-001:latest"
        config = _make_model_config()
        client_no_cap._set_cache(key, config)

        # Ancient entry - would be stale under any sane cap.
        entry = client_no_cap._cache[key]
        entry.fetched_at = time.time() - 86400  # 1 day
        entry.expires_at = time.time() + 300

        # Still returned; no StaleConfigError.
        assert client_no_cap._get_cached(key) is config


class TestCacheEntryFetchedAt:
    def test_set_cache_stamps_fetched_at(self, client):
        key = "model:mdl-001:latest"
        config = _make_model_config()
        before = time.time()
        client._set_cache(key, config)
        after = time.time()

        entry = client._cache[key]
        assert before <= entry.fetched_at <= after

    def test_cache_entry_default_fetched_at_zero(self):
        """Direct construction without fetched_at still works (backward compat)."""
        entry = CacheEntry(value="x", expires_at=time.time() + 60)
        assert entry.fetched_at == 0.0


class TestFetchPropagation:
    @pytest.mark.error_scenario
    def test_fetch_model_config_raises_stale_config_error(self, client):
        key = "model:mdl-001:latest"
        config = _make_model_config()
        client._set_cache(key, config)

        # Make the cached entry stale.
        entry = client._cache[key]
        entry.fetched_at = time.time() - 120
        entry.expires_at = time.time() + 300

        # No HTTP mock needed: _get_cached raises before any network call.
        with pytest.raises(StaleConfigError):
            client.fetch_model_config("mdl-001")

    @pytest.mark.error_scenario
    def test_fetch_deployment_config_raises_stale_config_error(self, client):
        key = "deployment:dep-001"
        config = _make_deployment_config()
        client._set_cache(key, config)

        entry = client._cache[key]
        entry.fetched_at = time.time() - 120
        entry.expires_at = time.time() + 300

        with pytest.raises(StaleConfigError):
            client.fetch_deployment_config("dep-001")


class TestStaleConfigMetric:
    def test_stale_config_metric_incremented(self):
        """The stale path records via RegistryTelemetry.record_stale_config."""
        # Build a client with a telemetry stub we can inspect.
        c = RegistryClient(
            url="http://localhost:8080",
            cache_ttl_secs=60,
            refresh_interval_secs=0,
            max_stale_secs=60,
        )
        recorded = []
        stub = MagicMock()
        stub.record_stale_config = lambda identifier, config_type: recorded.append(
            (identifier, config_type)
        )
        c._telemetry = stub

        key = "model:mdl-001:latest"
        c._set_cache(key, _make_model_config())
        entry = c._cache[key]
        entry.fetched_at = time.time() - 120
        entry.expires_at = time.time() + 300

        with pytest.raises(StaleConfigError):
            c._get_cached(key)

        assert recorded == [("mdl-001", "model")]

    def test_stale_config_metric_labels_deployment(self):
        c = RegistryClient(
            url="http://localhost:8080",
            cache_ttl_secs=60,
            refresh_interval_secs=0,
            max_stale_secs=60,
        )
        recorded = []
        stub = MagicMock()
        stub.record_stale_config = lambda identifier, config_type: recorded.append(
            (identifier, config_type)
        )
        c._telemetry = stub

        key = "deployment:dep-042"
        c._set_cache(key, _make_deployment_config(deployment_id="dep-042"))
        entry = c._cache[key]
        entry.fetched_at = time.time() - 120
        entry.expires_at = time.time() + 300

        with pytest.raises(StaleConfigError):
            c._get_cached(key)

        assert recorded == [("dep-042", "deployment")]

    def test_registry_telemetry_record_stale_config_real_counter(self):
        """Exercise the actual RegistryTelemetry.record_stale_config method
        (not a stub) so the counter create + add path is covered."""
        from opentelemetry.sdk.metrics import MeterProvider
        from opentelemetry.sdk.metrics.export import InMemoryMetricReader

        from mca_sdk.registry.telemetry import RegistryTelemetry

        reader = InMemoryMetricReader()
        provider = MeterProvider(metric_readers=[reader])
        meter = provider.get_meter("test.registry")
        telemetry = RegistryTelemetry(meter)

        telemetry.record_stale_config(identifier="mdl-xyz", config_type="model")
        telemetry.record_stale_config(identifier="dep-42", config_type="deployment")
        # Also exercise record_success / record_error for coverage parity on
        # the companion methods in the same class body.
        telemetry.record_success(latency=0.01)
        telemetry.record_error("RegistryConnectionError")

        reader.collect()
        metrics_data = reader.get_metrics_data()
        names = []
        for rm in metrics_data.resource_metrics:
            for sm in rm.scope_metrics:
                for m in sm.metrics:
                    names.append(m.name)

        assert "mca.registry.stale_config_errors_total" in names
        assert "mca.registry.refresh_success_total" in names
        assert "mca.registry.errors_total" in names

        provider.shutdown()


class TestRefreshLoopHandlesStaleConfigError:
    """The refresh loop's exception handler order is load-bearing.

    StaleConfigError inherits from RegistryError. The explicit handler
    must come BEFORE the generic RegistryError clause so the CRITICAL
    log fires instead of the WARNING-level "Failed to refresh" message.
    """

    def test_refresh_loop_catches_stale_config_error(self):
        from mca_sdk.registry import client as client_module

        c = RegistryClient(
            url="http://localhost:8080",
            cache_ttl_secs=60,
            refresh_interval_secs=30,  # will be overridden below
            max_stale_secs=60,
        )
        c._fetched_models = {"mdl-001"}

        # Patch fetch_model_config to always raise StaleConfigError.
        with patch.object(c, "fetch_model_config", side_effect=StaleConfigError("stale")):
            # Drive one iteration of the loop manually. Use a stop_event that
            # fires immediately on the SECOND wait call.
            calls = {"n": 0}

            def fake_wait(timeout):
                calls["n"] += 1
                # Pass (False) once so the body runs, then stop.
                return calls["n"] > 1

            c._stop_event = MagicMock()
            c._stop_event.wait = fake_wait
            c._stop_event.is_set = MagicMock(return_value=False)

            c._refresh_loop()

        # The error counter increments; the loop does NOT re-raise.
        assert c._refresh_errors >= 1

    def test_refresh_loop_ordering_stale_handler_before_registry_error(self):
        """Regression guard: ensure StaleConfigError doesn't fall through to the
        generic RegistryError handler (which would log at WARNING only).

        With _force_refresh=True, StaleConfigError should NOT happen. But if
        it does (bug), the explicit handler logs CRITICAL with 'bug' in msg.
        """
        import logging

        from mca_sdk.registry import client as client_module

        c = RegistryClient(
            url="http://localhost:8080",
            cache_ttl_secs=60,
            refresh_interval_secs=30,
            max_stale_secs=60,
        )
        c._fetched_models = {"mdl-001"}

        # Force StaleConfigError even with _force_refresh=True (simulate bug).
        def buggy_fetch(*args, **kwargs):
            raise StaleConfigError("stale-msg")

        with patch.object(c, "fetch_model_config", side_effect=buggy_fetch):
            calls = {"n": 0}

            def fake_wait(timeout):
                calls["n"] += 1
                return calls["n"] > 1

            c._stop_event = MagicMock()
            c._stop_event.wait = fake_wait
            c._stop_event.is_set = MagicMock(return_value=False)

            with patch.object(client_module.logger, "critical") as mock_crit:
                c._refresh_loop()

        # CRITICAL log fired from the explicit StaleConfigError handler.
        assert mock_crit.called
        # Structured logging: model_id is in extra={}, not the positional msg.
        crit_msg = " ".join(str(a) for call in mock_crit.call_args_list for a in call.args)
        crit_extras = [call.kwargs.get("extra", {}) for call in mock_crit.call_args_list]
        assert "bug" in crit_msg.lower()  # "This is a bug" in the message
        assert any(
            e.get("model_id") == "mdl-001" for e in crit_extras
        ), f"Expected model_id=mdl-001 in log extras, got: {crit_extras}"


class TestMCAConfigValidation:
    @pytest.mark.error_scenario
    def test_max_stale_secs_validation_below_cache_ttl_rejected(self):
        """registry_max_stale_secs must be >= max(cache_ttl, refresh_interval)."""
        # cache_ttl is hardcoded to 600 in core/client.py.
        # This config sets refresh=300 but max_stale=400, which is less than
        # the 600s cache_ttl. Should be rejected.
        with pytest.raises(ConfigurationError, match="registry_max_stale_secs"):
            MCAConfig(
                service_name="test",
                model_id="mdl-001",
                team_name="t",
                model_category="internal",
                model_type="regression",
                refresh_interval_secs=300,
                registry_max_stale_secs=400,  # < 600 (hardcoded cache_ttl)
            )

    @pytest.mark.error_scenario
    def test_max_stale_secs_validation_below_refresh_interval_when_refresh_exceeds_ttl(
        self,
    ):
        """When refresh_interval > cache_ttl, max_stale must be >= refresh."""
        # If a user sets refresh=900 (> 600 ttl), the effective cache window
        # is 900. max_stale=700 would be < 900 and should be rejected.
        with pytest.raises(ConfigurationError, match="registry_max_stale_secs"):
            MCAConfig(
                service_name="test",
                model_id="mdl-001",
                team_name="t",
                model_category="internal",
                model_type="regression",
                refresh_interval_secs=900,
                registry_max_stale_secs=700,  # < 900
            )

    def test_max_stale_secs_zero_bypasses_validation(self):
        # No exception: 0 disables the cap and skips the lower-bound check.
        cfg = MCAConfig(
            service_name="test",
            model_id="mdl-001",
            team_name="t",
            model_category="internal",
            model_type="regression",
            refresh_interval_secs=600,
            registry_max_stale_secs=0,
        )
        assert cfg.registry_max_stale_secs == 0

    def test_max_stale_secs_above_cache_ttl_and_refresh_accepted(self):
        """max_stale >= max(cache_ttl=600, refresh=600) should pass."""
        cfg = MCAConfig(
            service_name="test",
            model_id="mdl-001",
            team_name="t",
            model_category="internal",
            model_type="regression",
            refresh_interval_secs=600,
            registry_max_stale_secs=3600,
        )
        assert cfg.registry_max_stale_secs == 3600

    @pytest.mark.error_scenario
    def test_negative_max_stale_secs_rejected(self):
        with pytest.raises(ConfigurationError, match=">= 0"):
            MCAConfig(
                service_name="test",
                model_id="mdl-001",
                team_name="t",
                model_category="internal",
                model_type="regression",
                registry_max_stale_secs=-5,
            )


class TestStaleConfigErrorIsRegistryError:
    """Existing broad catch blocks must still work."""

    def test_inheritance(self):
        assert issubclass(StaleConfigError, RegistryError)

    @pytest.mark.error_scenario
    def test_catchable_as_registry_error(self, client):
        key = "model:mdl-001:latest"
        client._set_cache(key, _make_model_config())
        entry = client._cache[key]
        entry.fetched_at = time.time() - 120
        entry.expires_at = time.time() + 300

        # Broad RegistryError catch still works (per the inheritance contract).
        with pytest.raises(RegistryError):
            client._get_cached(key)


class TestRegistryClientInitValidation:
    @pytest.mark.error_scenario
    def test_negative_max_stale_secs_rejected_at_client_init(self):
        with pytest.raises(ValueError, match="max_stale_secs"):
            RegistryClient(
                url="http://localhost:8080",
                cache_ttl_secs=600,
                refresh_interval_secs=0,
                max_stale_secs=-1,
            )
