"""Targeted tests for helper functions in `mca_sdk.core.client`.

Story 6-33 merge 2 — AC #5 push for `core/client.py`. Covers the
module-level helpers `_extra_from_record`, `_sanitize_json_credentials`,
and `_sanitize_data_recursive` which the existing 850-line
`test_client_core.py` and 1575-line `test_mca_client.py` exercise only
incidentally through high-level client tests. Direct unit coverage on
the helpers protects the documented behaviour against silent regressions.
"""

import logging

import pytest

from mca_sdk.core.client import (
    _extra_from_record,
    _sanitize_data_recursive,
    _sanitize_json_credentials,
)


class TestExtraFromRecord:
    def test_extracts_only_user_provided_extras(self):
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname=__file__,
            lineno=1,
            msg="hello",
            args=(),
            exc_info=None,
        )
        # Stdlib attribute keys must be filtered out
        extra = _extra_from_record(record)
        assert "name" not in extra
        assert "msg" not in extra
        assert "lineno" not in extra
        assert "pathname" not in extra
        assert "exc_info" not in extra

    def test_includes_user_attached_attributes(self):
        record = logging.LogRecord(
            name="t",
            level=logging.INFO,
            pathname=__file__,
            lineno=1,
            msg="m",
            args=(),
            exc_info=None,
        )
        # Add a custom attribute as if via logger.info(msg, extra=...)
        record.prediction_id = "pred-42"
        record.latency_ms = 17.5
        extra = _extra_from_record(record)
        assert extra["prediction_id"] == "pred-42"
        assert extra["latency_ms"] == 17.5


class TestSanitizeJsonCredentials:
    def test_top_level_token_is_redacted(self):
        out = _sanitize_json_credentials({"token": "abcdef12345678", "user": "alice"})
        assert out["token"] == "[REDACTED]"
        assert out["user"] == "alice"

    @pytest.mark.parametrize(
        "key",
        [
            "token",
            "secret",
            "password",
            "api_key",
            "apikey",
            "access_key",
            "secret_key",
            "private_key",
            "auth_token",
            "bearer_token",
            "jwt",
            "client_secret",
            "api_secret",
            "aws_access_key_id",
            "aws_secret_access_key",
        ],
    )
    def test_each_credential_key_is_redacted(self, key):
        out = _sanitize_json_credentials({key: "secret_value_long"})
        assert out[key] == "[REDACTED]"

    def test_short_credential_value_passes_through(self):
        """Credential values shorter than 8 chars are not masked."""
        out = _sanitize_json_credentials({"token": "abc"})
        assert out["token"] == "abc"

    def test_partial_match_in_key_triggers_redaction(self):
        """The matcher is substring-based: `user_token` matches `token`."""
        out = _sanitize_json_credentials({"user_token": "verylongvalue"})
        assert out["user_token"] == "[REDACTED]"

    def test_nested_dict_credentials_redacted(self):
        out = _sanitize_json_credentials({"outer": {"token": "abcdef12345678", "key": "alice"}})
        assert out["outer"]["token"] == "[REDACTED]"
        assert out["outer"]["key"] == "alice"

    def test_list_with_dict_credentials_redacted(self):
        out = _sanitize_json_credentials({"creds": [{"token": "abcdef12345678"}, "raw-string"]})
        assert out["creds"][0]["token"] == "[REDACTED]"
        assert out["creds"][1] == "raw-string"

    def test_non_string_credential_value_pass_through(self):
        """Numeric / non-string credential values are not masked."""
        out = _sanitize_json_credentials({"token": 42})
        assert out["token"] == 42

    def test_case_insensitive_key_match(self):
        out = _sanitize_json_credentials({"TOKEN": "abcdef12345678"})
        assert out["TOKEN"] == "[REDACTED]"


class TestSanitizeDataRecursive:
    def test_str_within_limit_passes(self):
        assert _sanitize_data_recursive("hello", max_value_length=100) == "hello"

    def test_str_over_limit_raises_validation_error(self):
        from mca_sdk.utils.exceptions import ValidationError

        with pytest.raises(ValidationError, match="exceeds maximum length"):
            _sanitize_data_recursive("x" * 1100, max_value_length=1000)

    def test_dict_recursive_credential_masking(self):
        out = _sanitize_data_recursive({"user": "alice", "token": "secret_value_long_enough"})
        assert out["user"] == "alice"
        assert out["token"] == "[REDACTED]"

    def test_list_recursive(self):
        out = _sanitize_data_recursive(["short", {"token": "secret_value_longer"}, "another"])
        assert out[0] == "short"
        assert out[1]["token"] == "[REDACTED]"
        assert out[2] == "another"

    def test_tuple_recursive_preserves_tuple_with_credential_masking(self):
        """Per the docstring, list/tuple iterables preserve their type."""
        out = _sanitize_data_recursive(("a", "b", {"password": "supersecret"}))
        assert isinstance(out, tuple)
        assert out[2]["password"] == "[REDACTED]"

    def test_primitive_int_pass_through(self):
        assert _sanitize_data_recursive(42) == 42

    def test_primitive_none_pass_through(self):
        assert _sanitize_data_recursive(None) is None
