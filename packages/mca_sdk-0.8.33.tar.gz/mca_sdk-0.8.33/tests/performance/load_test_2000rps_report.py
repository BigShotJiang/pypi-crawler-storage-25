# Story 6-39 report writer: consumes raw JSON from load_test_2000rps.py and emits
# a markdown report at _bmad-output/test-artifacts/week1/load-test-report-<ts>.md
# satisfying AC-2 (seven required fields) and AC-3 (p99 vs 6-9 <500us SLO).
#
# The writer enforces a measurement-validity gate before declaring AC-3 PASS or
# FAIL: SDK pipeline healthy (no drops, no export failures) AND Collector pipeline
# healthy (no send_failed delta during the run) AND actual_rps >= 95% of target.
# If any gate trips, the verdict is INCONCLUSIVE — the measurement can't be
# trusted against a microbenchmark SLO until the underlying integrity issue is
# addressed. Exit code is always 0 when the markdown file is written; the
# verdict is data, not an exit status (per review finding #8).

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Tuple

SLO_P99_US = 500.0  # Story 6-9 SLO: p99 prediction latency < 500 microseconds.
# Story 6-39 AC explicitly requires "Strict 1000 RPS enforcement (no 950 RPS
# tolerance)". A hard 1.0 means any undershoot fails the gate. The previous
# 0.95 value silently accepted a 5% undershoot, contradicting the AC.
RPS_TOLERANCE = 1.0


def _fmt(value, spec: str = ".2f", na_label: str = "N/A (scrape unavailable)") -> str:
    if value is None:
        return na_label
    return f"{value:{spec}}"


def _measurement_validity(results: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """Return ``(is_valid, list_of_failed_gates)``.

    Measurement is valid iff all of:
    - SDK pipeline healthy (no drops, no export failures in buffer_stats)
    - Collector pipeline healthy: send_failed delta is zero AND ``_sent_*``
      delta is non-negative (a negative delta means counters reset, i.e. the
      Collector restarted mid-run and the data is unusable)
    - Runner did not report a hung worker (driver completed cleanly)
    - target_rps was recorded (>0) AND actual_rps reached >= target * RPS_TOLERANCE
      (RPS_TOLERANCE=1.0 means strict; anything below target trips the gate)
    """
    failed: List[str] = []

    sdk = results.get("sdk_pipeline") or {}
    if sdk.get("total_items_dropped", 0) > 0:
        failed.append(
            f"SDK dropped {sdk['total_items_dropped']} items "
            f"(per-signal: {sdk.get('per_signal_drops', {})})"
        )
    if sdk.get("total_export_failures", 0) > 0:
        failed.append(f"SDK reported {sdk['total_export_failures']} export failures")

    collector = results.get("collector_pipeline") or {}
    send_failed = collector.get("total_send_failed_delta", 0) or 0
    if send_failed != 0:
        suffix = (
            " (negative delta — Collector counters reset, indicates a "
            "restart mid-run; measurement is unusable)"
            if send_failed < 0
            else ""
        )
        failed.append(
            f"Collector pipeline degraded: send_failed delta = " f"{send_failed:.0f}{suffix}"
        )
    sent_delta = collector.get("total_sent_delta", 0) or 0
    if sent_delta < 0:
        failed.append(
            f"Collector counters went backwards: total_sent delta = "
            f"{sent_delta:.0f} (Collector likely restarted mid-run)"
        )

    runner_state = results.get("runner_state", "ok")
    if runner_state != "ok":
        hung = results.get("hung_worker_ids", [])
        failed.append(
            f"Runner state {runner_state!r} (hung worker ids: {hung}) — "
            "driver did not complete cleanly"
        )

    target = results.get("target_rps")
    actual = results.get("actual_rps")
    if not isinstance(target, (int, float)) or target <= 0:
        failed.append(
            "target_rps not recorded in results JSON — measurement integrity " "unverifiable"
        )
    elif not isinstance(actual, (int, float)) or actual <= 0:
        failed.append(
            "actual_rps not recorded in results JSON — measurement integrity " "unverifiable"
        )
    elif actual < target * RPS_TOLERANCE:
        failed.append(
            f"Actual RPS {actual:.1f} below target {target} "
            f"(strict {RPS_TOLERANCE:.2f} enforcement — no tolerance per AC)"
        )

    return (not failed), failed


def render_report(results: Dict[str, Any], report_path: Path) -> Dict[str, Any]:
    p99_us = results["latency_us"]["p99"]
    valid, failed_gates = _measurement_validity(results)
    slo_pass = p99_us < SLO_P99_US

    if valid:
        verdict_tag = "PASS" if slo_pass else "FAIL"
        overall_pass = slo_pass
    else:
        verdict_tag = "INCONCLUSIVE"
        overall_pass = False

    summary = {
        "measurement_valid": valid,
        "failed_gates": failed_gates,
        "ac1_clean_run": valid,
        "ac2_report_fields_present": True,
        "ac3_p99_vs_slo_pass": slo_pass if valid else None,
        "ac3_verdict": verdict_tag,
        "overall_pass": overall_pass,
        "p99_us": p99_us,
        "slo_us": SLO_P99_US,
    }

    sdk = results.get("sdk_pipeline") or {}
    collector = results.get("collector_pipeline") or {}
    cqd = results.get("collector_queue_depth") or {}

    lines: List[str] = []
    lines.append("# Load Test Report — Story 6-39 (A5 Wave 2)")
    lines.append("")
    lines.append(f"**Generated:** {datetime.now().isoformat(timespec='seconds')}")
    lines.append("**Target:** 2000 req/s sustained for 60s (backlog A5 requirement).")
    lines.append(f"**AC-3 verdict:** {verdict_tag}")
    if not valid:
        lines.append(
            "**Measurement integrity:** compromised — AC-3 verdict is "
            "INCONCLUSIVE. Address the gate failures listed below before "
            "comparing measured p99 to the 6-9 SLO."
        )
        for gate in failed_gates:
            lines.append(f"- Gate failure: {gate}")
    elif not slo_pass:
        lines.append(
            f"**Regression vs 6-9 SLO:** measured p99 = {p99_us:.1f} us "
            f">= {SLO_P99_US:.0f} us SLO threshold. Measurement gates pass, "
            "so this is a real sustained-load regression — do not close 6-39 "
            "without a root-cause note in the Dev Agent Record."
        )
    lines.append("")

    lines.append("## Execution Metadata")
    lines.append(f"- Tool: {results['tool']}")
    lines.append(f"- SDK version: {results['sdk_version']}")
    lines.append(f"- Commit SHA under test: {results['commit_sha']}")
    lines.append(f"- Collector endpoint: {results['collector_endpoint']}")
    lines.append(f"- Prometheus scrape URL: {results['prometheus_url']}")
    lines.append(
        f"- Duration: {results['duration_s']:.2f}s; target RPS: "
        f"{results['target_rps']}; actual RPS: {results['actual_rps']:.1f}"
    )
    workers = results.get("workers")
    if workers is not None:
        lines.append(
            f"- Workers: {workers} (per-worker interval "
            f"{results.get('per_worker_interval_ms', 0):.2f} ms)"
        )
        if "per_worker_counts" in results:
            lines.append(f"- Per-worker request counts: {results['per_worker_counts']}")
    pm = results.get("payload_mix", {})
    lines.append(
        f"- Payload mix: {pm.get('small_no_extras', 0)} small / "
        f"{pm.get('medium_pool_draws', pm.get('medium_10_extras', 0))} medium "
        f"(pool size {pm.get('pool_size', 'n/a')}, seed {pm.get('pool_seed', 'n/a')})"
    )
    lines.append("")

    lines.append("## AC-2 Required Fields")
    lines.append("")
    lines.append("| Field | Value | Source |")
    lines.append("|---|---|---|")
    lines.append(
        f"| p50 latency (us) | {_fmt(results['latency_us']['p50'])} | record_prediction call-site |"
    )
    lines.append(
        f"| p95 latency (us) | {_fmt(results['latency_us']['p95'])} | record_prediction call-site |"
    )
    lines.append(f"| p99 latency (us) | {_fmt(p99_us)} | record_prediction call-site |")
    lines.append(
        f"| Error rate (%) | {_fmt(results['error_rate_pct'], '.4f')} | driver exception counter |"
    )
    queue_max = cqd.get("max_observed")
    lines.append(
        f"| Collector queue depth (max observed) | {_fmt(queue_max)} | `otelcol_exporter_queue_size` on :8889 |"
    )
    lines.append(
        f"| SDK process RSS ceiling (MB) | {_fmt(results['sdk_rss_mb']['ceiling'])} | psutil Process.memory_info.rss |"
    )
    lines.append(f"| Tool + version | {results['tool']} / sdk={results['sdk_version']} | driver |")
    lines.append(f"| Commit SHA under test | {results['commit_sha']} | `git rev-parse HEAD` |")
    lines.append("")

    lines.append("## AC-3 p99 vs 6-9 SLO")
    lines.append(
        f"- SLO threshold: p99 < {SLO_P99_US:.0f} us "
        "(`mca-prototype/tests/performance/test_performance_slo.py`)"
    )
    lines.append(f"- Measured p99: {p99_us:.1f} us")
    if valid:
        lines.append(f"- Verdict: {'PASS' if slo_pass else 'FAIL — regression'}")
        lines.append(
            "- Measurement gates: all passed "
            "(SDK pipeline healthy, Collector pipeline healthy, actual RPS within tolerance)"
        )
    else:
        lines.append("- Verdict: INCONCLUSIVE — measurement gates tripped:")
        for gate in failed_gates:
            lines.append(f"  - {gate}")
    lines.append("")

    lines.append("## Detailed Latency Distribution (microseconds)")
    for key in ("min", "mean", "p50", "p95", "p99", "max"):
        lines.append(f"- {key}: {results['latency_us'][key]:.2f}")
    lines.append("")

    lines.append("## SDK Process Memory")
    rss = results["sdk_rss_mb"]
    lines.append(f"- Start RSS: {rss['start']:.1f} MB")
    lines.append(f"- Ceiling RSS: {rss['ceiling']:.1f} MB")
    lines.append(f"- End RSS: {rss['end']:.1f} MB")
    lines.append(f"- Samples: {rss['samples']}")
    lines.append("")

    lines.append("## SDK Pipeline Health (from MCAClient.buffer_stats())")
    if sdk.get("buffering_enabled") is False:
        lines.append("- Buffering disabled — no SDK-side drop visibility.")
    else:
        healthy = sdk.get("sdk_pipeline_healthy", True)
        lines.append(f"- Pipeline healthy: {'YES' if healthy else 'NO — drops detected'}")
        lines.append(f"- Total items dropped (all signals): {sdk.get('total_items_dropped', 0)}")
        lines.append(f"- Total export failures: {sdk.get('total_export_failures', 0)}")
        per_signal = sdk.get("per_signal_drops") or {}
        if per_signal:
            lines.append("- Per-signal drops:")
            for signal, count in sorted(per_signal.items()):
                lines.append(f"  - `{signal}`: {count}")
        if not healthy:
            lines.append(
                "- **Interpretation:** SDK dropped payloads during the run. "
                "Latency numbers do not reflect full-pipeline cost, and AC-3 "
                "verdict is INCONCLUSIVE until drops reach zero."
            )
    lines.append("")

    lines.append("## Collector Queue Depth")
    lines.append(f"- Max observed: {_fmt(queue_max)}")
    lines.append(f"- Successful scrapes: {cqd.get('samples', 0)}")
    lines.append(f"- Scrape failures: {cqd.get('scrape_failures', 0)}")
    last_reason = cqd.get("last_reason", "unknown")
    if queue_max is None:
        if last_reason == "metric_not_emitted":
            lines.append(
                "- Note: Prometheus endpoint is reachable, but the current "
                "`config/otel-collector-config.yaml` does not configure "
                "`sending_queue` on any exporter, so "
                "`otelcol_exporter_queue_size` is not emitted. AC-2 "
                '"Collector queue depth" cannot be measured until an '
                "exporter enables `sending_queue`. Filed as a follow-up "
                "observability gap."
            )
        elif last_reason == "endpoint_unreachable":
            lines.append(
                "- Note: Prometheus endpoint unreachable during the run. "
                "Re-run once `:8889` is exposed to record a real value."
            )
        else:
            lines.append(f"- Note: queue-depth field marked N/A (reason: {last_reason}).")
    lines.append("")

    lines.append("## Collector Pipeline Health")
    snapshot_order = collector.get("snapshot_order", "unknown")
    lines.append(
        f"- Snapshot order: {snapshot_order} " "(post-shutdown snapshot reflects final SDK flush)"
    )
    if collector:
        healthy = collector.get("pipeline_healthy", True)
        lines.append("- Pipeline healthy during run: " f"{'YES' if healthy else 'NO — degraded'}")
        lines.append(
            "- Total send_failed events (delta during run): "
            f"{collector.get('total_send_failed_delta', 0):.0f}"
        )
        lines.append(
            "- Total sent events (delta during run): " f"{collector.get('total_sent_delta', 0):.0f}"
        )
        deltas = collector.get("deltas") or {}
        if deltas:
            lines.append("- Per-exporter deltas:")
            for exp, metrics in sorted(deltas.items()):
                for name, value in sorted(metrics.items()):
                    if value:
                        lines.append(f"  - `{exp}`: `{name}` += {value:.0f}")
        if not healthy:
            lines.append(
                "- **Interpretation:** nonzero send_failed delta means the "
                "Collector pipeline was degraded during this run. Observed "
                "SDK p99 tail may reflect downstream backpressure rather "
                "than a true SDK regression. Clear the exporter fault before "
                "trusting the AC-3 verdict."
            )
    lines.append("")

    lines.append("## Tool Choice Rationale")
    lines.append(
        "The driver is an in-process Python harness that invokes "
        "`MCAClient.record_prediction` directly — the same call surface that "
        "Story 6-9's <500us p99 SLO is defined against "
        "(`mca-prototype/tests/performance/test_performance_slo.py`). Measuring "
        "the SDK hot path directly means the 6-9 comparison is like-for-like: "
        "both numbers cover the Python-side overhead of the same function on "
        "the same call stack. A load generator that drives the SDK over HTTP "
        "(k6, locust as external workers) would add network + transport "
        "latency to every sample, so the resulting p99 would be a different "
        "surface that can't be compared to the 6-9 microbenchmark SLO. The "
        "in-process driver is also fully reproducible from the repo — the "
        "only external prerequisite is a running OTel Collector."
    )
    lines.append("")

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines) + "\n")
    return summary


def render_inconclusive_stub(report_path: Path, reason: str) -> None:
    """Write a minimal INCONCLUSIVE markdown report when the results JSON is
    unavailable or unparseable.

    Used by the bash runner when the driver crashes mid-write and leaves a
    truncated/invalid JSON. CI still gets a markdown artifact with a clear
    verdict instead of a Python traceback.
    """
    lines: List[str] = [
        "# Load Test Report — Story 6-39 (A5 Wave 2)",
        "",
        f"**Generated:** {datetime.now().isoformat(timespec='seconds')}",
        "**AC-3 verdict:** INCONCLUSIVE",
        "**Measurement integrity:** results JSON missing or unparseable — "
        "no measurement was captured.",
        "",
        "## Failure Reason",
        f"- {reason}",
        "",
        "## Next Steps",
        "- Re-run `tests/performance/run_2000rps_load_test.sh` against a "
        "healthy local Collector.",
        "- If the driver crashed, inspect the runner stdout/stderr captured "
        "by CI for the original traceback.",
        "",
    ]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines) + "\n")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Render Story 6-39 load-test report")
    parser.add_argument("--results-json", type=Path, required=False, default=None)
    parser.add_argument(
        "--report-path",
        type=Path,
        required=True,
        help="Output markdown path, e.g. _bmad-output/test-artifacts/week1/load-test-report-<ts>.md",
    )
    parser.add_argument(
        "--emit-inconclusive-stub",
        action="store_true",
        help="Skip JSON parsing and write an INCONCLUSIVE stub report. Used by "
        "the bash runner when the results JSON is missing or invalid.",
    )
    parser.add_argument(
        "--reason",
        type=str,
        default="",
        help="Human-readable reason recorded in the stub report (use with "
        "--emit-inconclusive-stub).",
    )
    args = parser.parse_args(argv)

    if args.emit_inconclusive_stub:
        render_inconclusive_stub(
            args.report_path,
            args.reason or "results JSON missing or unparseable",
        )
        print(json.dumps({"ac3_verdict": "INCONCLUSIVE", "stub": True}, indent=2))
        return 0

    if args.results_json is None:
        parser.error("--results-json is required unless --emit-inconclusive-stub is set")

    results = json.loads(args.results_json.read_text())
    summary = render_report(results, args.report_path)
    print(json.dumps(summary, indent=2))
    # Per review finding #8: exit 0 whenever the markdown file was written.
    # The verdict is in the report body, not the exit code.
    return 0


if __name__ == "__main__":
    sys.exit(main())
