"""Performance profiling for MCA SDK overhead analysis.

Profiles SDK hot paths to identify optimization opportunities.
Part of Story 6-9: Performance Testing (<50ms overhead).

Story 6-30 (Wave 2): supports --clean mode which swaps the OTLP
exporters for a NoOp implementation so urllib3 retry cost does not
dominate cumulative time in the profile, and writes the artifact
to _bmad-output/test-artifacts/week1/profile-after-clean-<ts>.txt.

Story 6-44: supports --assoc mode which installs NoOp exporters AND
passes association_id on every record_prediction / record_error call so
the `if association_id is not None:` positive branches are executed in
the profile. Writes to profile-after-fastpath-assoc-<ts>.txt.

--clean and --assoc are mutually exclusive; argparse enforces this.

Usage:
    python tests/performance/profile_overhead.py
    python tests/performance/profile_overhead.py --clean
    python tests/performance/profile_overhead.py --assoc
"""

import argparse
import cProfile
import os
import pstats
import sys
import time
from datetime import datetime
from io import StringIO
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from tests.performance.utils import create_benchmark_client


def install_noop_otlp_exporters() -> None:
    """Replace OTLP HTTP exporter export() methods with no-ops.

    Story 6-30 Wave 2: the A1 logging overhead profile must be captured
    against a NoOp exporter so that urllib3 retry/backoff cost (from a
    disconnected collector) does not dominate the profile and mask the
    stdlib logging cumtime the SLO is trying to attribute.

    Monkey-patches the classes in place so every exporter constructed
    afterwards (by setup_all_providers) is effectively a no-op. Must run
    before MCAClient() is constructed.
    """
    from opentelemetry.sdk.trace.export import SpanExportResult
    from opentelemetry.sdk.metrics.export import MetricExportResult
    from opentelemetry.sdk._logs.export import LogExportResult
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.exporter.otlp.proto.http.metric_exporter import (
        OTLPMetricExporter,
    )
    from opentelemetry.exporter.otlp.proto.http._log_exporter import OTLPLogExporter

    def _noop_span_export(self, spans, *args, **kwargs):
        return SpanExportResult.SUCCESS

    def _noop_metric_export(self, metrics_data, *args, **kwargs):
        return MetricExportResult.SUCCESS

    def _noop_log_export(self, batch, *args, **kwargs):
        return LogExportResult.SUCCESS

    def _noop_shutdown(self, *args, **kwargs):
        return None

    def _noop_force_flush(self, *args, **kwargs):
        return True

    OTLPSpanExporter.export = _noop_span_export
    OTLPSpanExporter.shutdown = _noop_shutdown
    OTLPSpanExporter.force_flush = _noop_force_flush

    OTLPMetricExporter.export = _noop_metric_export
    OTLPMetricExporter.shutdown = _noop_shutdown
    OTLPMetricExporter.force_flush = _noop_force_flush

    OTLPLogExporter.export = _noop_log_export
    OTLPLogExporter.shutdown = _noop_shutdown
    OTLPLogExporter.force_flush = _noop_force_flush


def _import_kwargs():
    # Imported lazily so the helper module is resolvable regardless of how
    # this script is invoked (python tests/... vs python -m tests.perf...).
    from tests.performance.assoc_kwargs import prediction_kwargs, error_kwargs

    return prediction_kwargs, error_kwargs


def profile_record_prediction_hot_paths(*, with_association_id: bool = False):
    """Profile record_prediction() to identify hot paths."""
    prediction_kwargs, _ = _import_kwargs()

    print("Profiling record_prediction() hot paths...")

    profiler = cProfile.Profile()
    client = create_benchmark_client()
    profiler.enable()
    for i in range(1000):
        client.record_prediction(**prediction_kwargs(i, with_association_id))
    profiler.disable()
    client.shutdown()

    stream = StringIO()
    stats = pstats.Stats(profiler, stream=stream)
    stats.strip_dirs()
    stats.sort_stats("cumulative")

    stream.write("=" * 80 + "\n")
    if with_association_id:
        stream.write("RECORD_PREDICTION() POSITIVE-PATH HOT PATH ANALYSIS (Story 6-44)\n")
        stream.write(
            "association_id=f'assoc-{i}' supplied on every call; the "
            "`if association_id is not None:` guards in record_prediction "
            "(log_extra + ml.association.id span attribute) are exercised "
            "every iteration.\n"
        )
    else:
        stream.write("RECORD_PREDICTION() HOT PATH ANALYSIS\n")
    stream.write("=" * 80 + "\n\n")
    stream.write("Top 30 functions by cumulative time:\n")
    stream.write("-" * 80 + "\n")
    stats.print_stats(30)
    stream.write("\n" + "=" * 80 + "\n")
    stream.write("OPTIMIZATION OPPORTUNITIES\n")
    stream.write("=" * 80 + "\n\n")
    stream.write("Review functions with high cumulative time:\n")
    stream.write("- Attribute validation\n")
    stream.write("- Metric recording\n")
    stream.write("- OTel span creation\n")
    stream.write("- Serialization\n\n")
    return stream.getvalue()


def profile_record_error_hot_paths(*, with_association_id: bool = False):
    """Profile record_error() to identify hot paths.

    Story 6-44: satisfies the AC 1 requirement that the positive branch
    of the `if association_id is not None:` guard is executed on every
    record_error call, not just record_prediction.
    """
    _, error_kwargs = _import_kwargs()

    print("Profiling record_error() hot paths...")

    profiler = cProfile.Profile()
    client = create_benchmark_client()
    profiler.enable()
    # Fresh exception instance each iteration: record_error sets
    # `_mca_recorded = True` on the passed exception and short-circuits on
    # repeats of the same instance.
    for i in range(1000):
        client.record_error(
            RuntimeError(f"simulated error {i}"),
            **error_kwargs(i, with_association_id),
        )
    profiler.disable()
    client.shutdown()

    stream = StringIO()
    stats = pstats.Stats(profiler, stream=stream)
    stats.strip_dirs()
    stats.sort_stats("cumulative")

    stream.write("\n" + "=" * 80 + "\n")
    if with_association_id:
        stream.write("RECORD_ERROR() POSITIVE-PATH HOT PATH ANALYSIS (Story 6-44)\n")
        stream.write(
            "association_id supplied on every call; the "
            "`if association_id is not None:` guards in record_error "
            "(log_extra + ml.association.id span attribute) are exercised "
            "every iteration.\n"
        )
    else:
        stream.write("RECORD_ERROR() HOT PATH ANALYSIS\n")
    stream.write("=" * 80 + "\n\n")
    stream.write("Top 30 functions by cumulative time:\n")
    stream.write("-" * 80 + "\n")
    stats.print_stats(30)
    return stream.getvalue()


def profile_trace_context_manager():
    """Profile client.trace() span creation overhead."""
    print("Profiling trace() context manager...")

    profiler = cProfile.Profile()
    client = create_benchmark_client()
    profiler.enable()
    for i in range(1000):
        with client.trace(f"operation_{i}"):
            pass
    profiler.disable()
    client.shutdown()

    stream = StringIO()
    stats = pstats.Stats(profiler, stream=stream)
    stats.strip_dirs()
    stats.sort_stats("cumulative")

    stream.write("\n" + "=" * 80 + "\n")
    stream.write("TRACE() CONTEXT MANAGER HOT PATH ANALYSIS\n")
    stream.write("=" * 80 + "\n\n")
    stream.write("Top 20 functions by cumulative time:\n")
    stream.write("-" * 80 + "\n")
    stats.print_stats(20)
    stream.write("\n" + "=" * 80 + "\n")
    stream.write("SPAN CREATION BOTTLENECKS\n")
    stream.write("=" * 80 + "\n\n")
    stream.write("Review OpenTelemetry span creation overhead:\n")
    stream.write("- Span initialization\n")
    stream.write("- Context propagation\n")
    stream.write("- Attribute attachment\n\n")
    return stream.getvalue()


def main():
    """Run all profiling and generate report."""
    parser = argparse.ArgumentParser(description="MCA SDK performance profiling")
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        "--clean",
        action="store_true",
        help=(
            "Story 6-30 Wave 2: install NoOp OTLP exporters and write the artifact "
            "to _bmad-output/test-artifacts/week1/profile-after-clean-<ts>.txt"
        ),
    )
    mode_group.add_argument(
        "--assoc",
        action="store_true",
        help=(
            "Story 6-44: install NoOp OTLP exporters, pass association_id on every "
            "record_prediction / record_error call so the positive-branch guards are "
            "exercised; write artifact to "
            "_bmad-output/test-artifacts/week1/profile-after-fastpath-assoc-<ts>.txt"
        ),
    )
    args = parser.parse_args()

    print("=" * 80)
    print("MCA SDK Performance Profiling (Story 6-9)")
    if args.clean:
        print("  mode: --clean (Story 6-30 Wave 2, NoOp OTLP exporters)")
    elif args.assoc:
        print("  mode: --assoc (Story 6-44, NoOp exporters + association_id positive path)")
    print("=" * 80)
    print()

    week1_dir = (
        Path(__file__).parent.parent.parent.parent / "_bmad-output" / "test-artifacts" / "week1"
    )

    if args.assoc:
        install_noop_otlp_exporters()
        week1_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d-%H%M")
        output_file = week1_dir / f"profile-after-fastpath-assoc-{ts}.txt"
    elif args.clean:
        install_noop_otlp_exporters()
        week1_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d-%H%M")
        output_file = week1_dir / f"profile-after-clean-{ts}.txt"
    else:
        results_dir = Path(__file__).parent / "results"
        results_dir.mkdir(exist_ok=True)
        output_file = results_dir / "overhead_profile.txt"

    report = profile_record_prediction_hot_paths(with_association_id=args.assoc)

    if args.assoc:
        # AC 1 mandates the positive branch on every record_prediction AND
        # every record_error call, so the --assoc profile must include both.
        report += profile_record_error_hot_paths(with_association_id=True)
        # --assoc deliberately omits profile_trace_context_manager. The
        # trace()-overhead profile exercises span creation independent of
        # association_id, so it is covered by the default invocation and
        # would only add noise to the positive-path artifact. Run without
        # --assoc to regenerate the trace-context section.
        report += (
            "\n"
            "NOTE: trace() context-manager profiling omitted under --assoc.\n"
            "The span-creation profile is independent of association_id and is\n"
            "captured by the default invocation of this script. Run without\n"
            "--assoc to regenerate.\n"
        )
    else:
        report += profile_trace_context_manager()

    with open(output_file, "w") as f:
        f.write(report)

    print(f"\nProfiling report saved to: {output_file}")
    print(f"   File size: {output_file.stat().st_size} bytes")
    print()
    print("Next steps:")
    print("1. Review top 30 functions by cumulative time")
    print("2. Confirm urllib3 / http.client entries are absent (--clean / --assoc modes)")
    print("3. Run the logging-overhead SLO test")
    print(
        "   pytest tests/performance/test_performance_slo.py::TestPerformanceSLO::test_logging_overhead_under_10_percent -v"
    )


if __name__ == "__main__":
    main()
