# Story 6-39 driver: 2000 req/s sustained for 60s against a live OTel Collector.
# Multi-threaded worker pool so per-worker cadence stays within time.sleep precision
# (no busy-spin, no CPU starvation of the SDK's background exporter threads).
# Measures per-call record_prediction SDK overhead (microsecond precision), SDK
# process RSS ceiling, Collector exporter totals, and SDK-side drop counts. Emits
# a result dict the sibling report writer consumes. Exit code is 0 whenever the
# JSON artifact was successfully written — pass/fail verdict lives in the report.

import argparse
import json
import logging
import os
import random
import statistics
import string
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import psutil
import requests
from prometheus_client.parser import text_string_to_metric_families

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from mca_sdk import MCAClient  # noqa: E402

from tests.performance.performance_helpers import get_collector_endpoint  # noqa: E402
from tests.performance._load_test_pacing import run_paced_worker  # noqa: E402

logger = logging.getLogger(__name__)

DEFAULT_TARGET_RPS = 2000
DEFAULT_DURATION_S = 60
DEFAULT_WORKERS = 4
PAYLOAD_POOL_SIZE = 32
PAYLOAD_POOL_SEED = 42


def _git_commit_sha() -> str:
    override = os.environ.get("MCA_LOAD_TEST_COMMIT_SHA")
    if override:
        return override
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL, text=True
        ).strip()
    except Exception:
        return "unknown"


def _sdk_version() -> str:
    try:
        import mca_sdk

        return getattr(mca_sdk, "__version__", "unknown")
    except Exception:
        return "unknown"


def _build_medium_attrs_pool(
    size: int = PAYLOAD_POOL_SIZE, seed: int = PAYLOAD_POOL_SEED
) -> List[Dict[str, Any]]:
    # Deterministic pool of distinct medium-shape payloads (~10 attributes each).
    # Exercises the attribute-processing path without allowing the runtime to
    # cache a single static dict across the whole run.
    rng = random.Random(seed)
    regions = ["us-east1", "us-central1", "us-west1", "europe-west4"]
    departments = ["cardiology", "oncology", "pediatrics", "neurology", "emergency"]
    encounter_types = ["inpatient", "outpatient", "observation", "er"]
    age_buckets = ["18-34", "35-44", "45-54", "55-64", "65-74", "75+"]
    pool: List[Dict[str, Any]] = []
    for _ in range(size):
        pool.append(
            {
                "model_version": f"2.{rng.randint(0, 9)}.{rng.randint(0, 20)}",
                "feature_set": rng.choice(["readmission-v1", "readmission-v2", "mortality-v3"]),
                "tenant": "bhsf",
                "region": rng.choice(regions),
                "patient_age_bucket": rng.choice(age_buckets),
                "encounter_type": rng.choice(encounter_types),
                "department": rng.choice(departments),
                "risk_score_bin": rng.randint(0, 9),
                "cohort_id": rng.randint(100, 999),
                # NOTE: ``string.hexdigits`` is "0123456789abcdefABCDEF" — the
                # case-folded form duplicates a-f, which would bias the pool
                # toward letters. Slice to the canonical 16-char alphabet so
                # every digit is equally likely.
                "opaque_token": "".join(rng.choices(string.hexdigits[:16], k=16)),
            }
        )
    return pool


def _iter_prometheus_samples(prometheus_url: str, timeout: float = 2.0):
    """Yield parsed Sample objects from the Collector's Prometheus endpoint.

    Raises ``requests.RequestException`` on HTTP failure so callers can
    distinguish endpoint-unreachable from metric-not-emitted.
    """
    resp = requests.get(prometheus_url, timeout=timeout)
    resp.raise_for_status()
    for family in text_string_to_metric_families(resp.text):
        for sample in family.samples:
            yield sample


def _scrape_queue_size(prometheus_url: str, timeout: float = 2.0):
    """Return ``(value, reason)``.

    - ``(float, "ok")`` when ``otelcol_exporter_queue_size`` is present.
    - ``(None, "endpoint_unreachable")`` when HTTP fails.
    - ``(None, "metric_not_emitted")`` when endpoint responds but the metric is
      absent (typical when no exporter has ``sending_queue`` configured).
    """
    try:
        samples = list(_iter_prometheus_samples(prometheus_url, timeout))
    except requests.RequestException:
        return None, "endpoint_unreachable"
    total = 0.0
    matched = False
    for sample in samples:
        if sample.name == "otelcol_exporter_queue_size":
            try:
                total += float(sample.value)
                matched = True
            except (TypeError, ValueError):
                continue
    if not matched:
        return None, "metric_not_emitted"
    return total, "ok"


def _scrape_exporter_totals(
    prometheus_url: str, timeout: float = 2.0
) -> Dict[str, Dict[str, float]]:
    """Return ``{exporter_name: {metric_name: value}}`` for send_failed_* and sent_* totals.

    Returns an empty dict if the Prometheus endpoint is unreachable. Callers
    should interpret an empty dict as "no collector-side visibility"; nonzero
    ``send_failed_*`` values indicate pipeline degradation that likely inflated
    the measured SDK p99.
    """
    try:
        samples = list(_iter_prometheus_samples(prometheus_url, timeout))
    except requests.RequestException:
        return {}
    totals: Dict[str, Dict[str, float]] = {}
    for sample in samples:
        if not sample.name.startswith("otelcol_exporter_"):
            continue
        if not (
            sample.name.endswith("_total")
            and ("send_failed" in sample.name or "_sent_" in sample.name)
        ):
            continue
        exp = sample.labels.get("exporter")
        if not exp:
            continue
        try:
            totals.setdefault(exp, {})[sample.name] = float(sample.value)
        except (TypeError, ValueError):
            continue
    return totals


class _QueueSampler(threading.Thread):
    """Background thread sampling exporter queue_size at a fixed cadence."""

    def __init__(self, prometheus_url: str, interval_s: float = 0.5):
        super().__init__(daemon=True)
        self.prometheus_url = prometheus_url
        self.interval_s = interval_s
        # NOTE: do not name this `_stop` — shadows threading.Thread._stop().
        self._stop_event = threading.Event()
        self.samples: List[tuple] = []
        self.scrape_failures = 0
        self.last_reason = "unknown"

    def run(self) -> None:
        while not self._stop_event.is_set():
            value, reason = _scrape_queue_size(self.prometheus_url)
            if value is None:
                self.scrape_failures += 1
                self.last_reason = reason
            else:
                self.samples.append((time.time(), value))
                self.last_reason = "ok"
            self._stop_event.wait(self.interval_s)

    def stop(self) -> None:
        self._stop_event.set()

    @property
    def max_queue_depth(self) -> Optional[float]:
        if not self.samples:
            return None
        return max(v for _, v in self.samples)


def _summarise_buffer_stats(buffer_stats: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Extract the fields we care about from MCAClient.buffer_stats().

    Returns a shape that is safe to serialise even when buffering is disabled
    (``buffer_stats()`` returns ``None``) or the SDK returns partial data.
    """
    if not buffer_stats:
        return {
            "buffering_enabled": False,
            "per_signal_drops": {},
            "total_items_dropped": 0,
            "total_export_failures": 0,
            "sdk_pipeline_healthy": True,
        }
    per_signal = buffer_stats.get("per_signal_stats") or {}
    drops = {
        signal: int(stats.get("items_dropped", 0) or 0) for signal, stats in per_signal.items()
    }
    total_drops = sum(drops.values())
    total_failures = int(buffer_stats.get("total_export_failures", 0) or 0)
    return {
        "buffering_enabled": True,
        "per_signal_drops": drops,
        "per_signal_stats": per_signal,
        "total_items_dropped": total_drops,
        "total_export_failures": total_failures,
        "sdk_pipeline_healthy": total_drops == 0 and total_failures == 0,
    }


def _worker_loop(
    worker_id: int,
    client: MCAClient,
    payload_pool: List[Dict[str, Any]],
    per_worker_interval_s: float,
    end_at: float,
    latencies_us: List[float],
    latencies_lock: threading.Lock,
    error_counter: List[int],
    total_workers: int = 1,
) -> int:
    """Run one worker's pacing loop. Returns its request count.

    Thin wrapper around the shared ``run_paced_worker`` helper. Kept as a
    named symbol so existing imports (and the test harness) continue to work.
    The shared helper is the single source of truth for the
    error-records-latency and pacing-debt-reset invariants.
    """

    def _request(payload: Optional[Dict[str, Any]]) -> None:
        if payload is not None:
            client.record_prediction(latency=0.001, **payload)
        else:
            client.record_prediction(latency=0.001)

    return run_paced_worker(
        worker_id=worker_id,
        total_workers=total_workers,
        request_fn=_request,
        payload_pool=payload_pool,
        per_worker_interval_s=per_worker_interval_s,
        end_at=end_at,
        latencies_us=latencies_us,
        latencies_lock=latencies_lock,
        error_counter=error_counter,
    )


def run_2000rps_load_test(
    target_rps: int = DEFAULT_TARGET_RPS,
    duration_s: int = DEFAULT_DURATION_S,
    workers: int = DEFAULT_WORKERS,
    collector_endpoint: Optional[str] = None,
    prometheus_url: str = "http://localhost:8889/metrics",
    tool_name: str = "mca-sdk-inprocess-driver",
) -> Dict[str, Any]:
    """Sustain ``target_rps`` against a live Collector for ``duration_s``.

    ``workers`` controls the multi-threaded pacing pool. At ``workers=4`` and
    ``target_rps=2000``, per-worker interval is 2ms — comfortably above Linux
    ``time.sleep`` precision, so no busy-spin is needed. Reviewers can pass
    ``--workers 1`` to reproduce single-threaded busy-spin behaviour for
    comparison.
    """
    collector_endpoint = collector_endpoint or get_collector_endpoint()
    if workers < 1:
        raise ValueError("workers must be >= 1")
    per_worker_interval_s = workers / target_rps

    payload_pool = _build_medium_attrs_pool()

    client = MCAClient(
        service_name="load_test_2000rps_6_39",
        model_id="load_test_model_6_39",
        team_name="performance_team",
        model_category="internal",
        model_type="regression",
        collector_endpoint=collector_endpoint,
        buffering_enabled=True,
        max_queue_size=20000,
    )

    proc = psutil.Process()
    rss_samples: List[int] = [proc.memory_info().rss]

    queue_sampler = _QueueSampler(prometheus_url, interval_s=0.5)
    queue_sampler.start()

    exporter_totals_before = _scrape_exporter_totals(prometheus_url)

    latencies_us: List[float] = []
    latencies_lock = threading.Lock()
    error_counter = [0]
    per_worker_counts: List[int] = []
    per_worker_counts_lock = threading.Lock()

    end_at = time.time() + duration_s
    start_perf = time.perf_counter()

    # RSS sampler thread: independent of workers so sampling rate doesn't depend
    # on pacing cadence.
    stop_rss_event = threading.Event()

    def _rss_sampler() -> None:
        while not stop_rss_event.wait(0.5):
            rss_samples.append(proc.memory_info().rss)

    rss_thread = threading.Thread(target=_rss_sampler, daemon=True)
    rss_thread.start()

    def _worker_entry(wid: int) -> None:
        count = _worker_loop(
            wid,
            client,
            payload_pool,
            per_worker_interval_s,
            end_at,
            latencies_us,
            latencies_lock,
            error_counter,
            total_workers=workers,
        )
        with per_worker_counts_lock:
            per_worker_counts.append(count)

    worker_threads = [
        threading.Thread(target=_worker_entry, args=(i,), daemon=True) for i in range(workers)
    ]
    for t in worker_threads:
        t.start()

    # Bound join so a single hung SDK call cannot deadlock the runner. Workers
    # already self-terminate at ``end_at``; allow a 30s grace window to let
    # in-flight ``record_prediction`` calls drain. Anything still alive after
    # that is reported as a hung worker — JSON still gets written so the report
    # writer can render INCONCLUSIVE rather than producing nothing.
    JOIN_GRACE_S = 30.0
    join_deadline = time.time() + duration_s + JOIN_GRACE_S
    hung_worker_ids: List[int] = []
    try:
        for idx, t in enumerate(worker_threads):
            remaining = max(0.0, join_deadline - time.time())
            t.join(timeout=remaining)
            if t.is_alive():
                hung_worker_ids.append(idx)
    finally:
        stop_rss_event.set()
        rss_thread.join(timeout=2.0)
        elapsed_s = time.perf_counter() - start_perf
        rss_samples.append(proc.memory_info().rss)
        # Capture SDK-side drop stats BEFORE shutdown — shutdown flushes the
        # queues, which would mask any drops that occurred during the run.
        buffer_stats_pre_shutdown = _summarise_buffer_stats(client.buffer_stats())
        # Let the queue sampler run until shutdown completes so we see the
        # flush-time queue depth spike (if any).
        client.shutdown()
        queue_sampler.stop()
        queue_sampler.join(timeout=5.0)
        # Capture Collector-side totals AFTER shutdown so the final flush's
        # send_failed / sent events are reflected.
        exporter_totals_after = _scrape_exporter_totals(prometheus_url)

    request_count = sum(per_worker_counts)
    errors = error_counter[0]
    actual_rps = request_count / elapsed_s if elapsed_s > 0 else 0.0
    error_rate_pct = (errors / request_count * 100.0) if request_count else 0.0

    sorted_lat = sorted(latencies_us)
    n = len(sorted_lat)

    def percentile(p: float) -> float:
        if n == 0:
            return 0.0
        idx = min(n - 1, max(0, int(round(p * (n - 1)))))
        return sorted_lat[idx]

    collector_pipeline_deltas: Dict[str, Dict[str, float]] = {}
    all_exporters = set(exporter_totals_before.keys()) | set(exporter_totals_after.keys())
    for exp in all_exporters:
        before = exporter_totals_before.get(exp, {})
        after = exporter_totals_after.get(exp, {})
        metric_names = set(before.keys()) | set(after.keys())
        collector_pipeline_deltas[exp] = {
            name: after.get(name, 0.0) - before.get(name, 0.0) for name in metric_names
        }

    total_send_failed_delta = sum(
        v
        for metrics in collector_pipeline_deltas.values()
        for name, v in metrics.items()
        if "send_failed" in name
    )
    total_sent_delta = sum(
        v
        for metrics in collector_pipeline_deltas.values()
        for name, v in metrics.items()
        if "_sent_" in name and name.endswith("_total")
    )

    return {
        "tool": tool_name,
        "sdk_version": _sdk_version(),
        "commit_sha": _git_commit_sha(),
        "collector_endpoint": collector_endpoint,
        "prometheus_url": prometheus_url,
        "target_rps": target_rps,
        "workers": workers,
        "per_worker_interval_ms": per_worker_interval_s * 1000.0,
        "duration_s": elapsed_s,
        "actual_rps": actual_rps,
        "total_requests": request_count,
        "per_worker_counts": per_worker_counts,
        "errors": errors,
        "error_rate_pct": error_rate_pct,
        "runner_state": "worker_hung" if hung_worker_ids else "ok",
        "hung_worker_ids": hung_worker_ids,
        "latency_us": {
            "p50": percentile(0.50),
            "p95": percentile(0.95),
            "p99": percentile(0.99),
            "min": sorted_lat[0] if sorted_lat else 0.0,
            "max": sorted_lat[-1] if sorted_lat else 0.0,
            "mean": statistics.mean(sorted_lat) if sorted_lat else 0.0,
        },
        "sdk_rss_mb": {
            "start": rss_samples[0] / (1024 * 1024),
            "ceiling": max(rss_samples) / (1024 * 1024),
            "end": rss_samples[-1] / (1024 * 1024),
            "samples": len(rss_samples),
        },
        "sdk_pipeline": buffer_stats_pre_shutdown,
        "collector_queue_depth": {
            "max_observed": queue_sampler.max_queue_depth,
            "samples": len(queue_sampler.samples),
            "scrape_failures": queue_sampler.scrape_failures,
            "last_reason": queue_sampler.last_reason,
            "prometheus_url": prometheus_url,
        },
        "collector_pipeline": {
            "deltas": collector_pipeline_deltas,
            "total_send_failed_delta": total_send_failed_delta,
            "total_sent_delta": total_sent_delta,
            "pipeline_healthy": total_send_failed_delta == 0,
            "snapshot_order": "before_start -> after_client_shutdown",
        },
        "payload_mix": {
            "pool_size": PAYLOAD_POOL_SIZE,
            "pool_seed": PAYLOAD_POOL_SEED,
            "small_no_extras": request_count - (request_count // 2),
            "medium_pool_draws": request_count // 2,
        },
    }


def _configure_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(name)s %(message)s")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Story 6-39: 2000 req/s sustained load test")
    parser.add_argument("--target-rps", type=int, default=DEFAULT_TARGET_RPS)
    parser.add_argument("--duration-s", type=int, default=DEFAULT_DURATION_S)
    parser.add_argument(
        "--workers",
        type=int,
        default=DEFAULT_WORKERS,
        help="Number of pacing worker threads (default 4 = 2ms per-worker interval at 2000 rps)",
    )
    parser.add_argument("--collector-endpoint", default=None)
    parser.add_argument("--prometheus-url", default="http://localhost:8889/metrics")
    parser.add_argument(
        "--results-json",
        type=Path,
        required=True,
        help="Where to write the raw measurement JSON (consumed by the report writer)",
    )
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    _configure_logging(args.verbose)
    logger.info(
        "Story 6-39: starting %d req/s x %ds (%d workers) against %s",
        args.target_rps,
        args.duration_s,
        args.workers,
        args.collector_endpoint or get_collector_endpoint(),
    )
    results = run_2000rps_load_test(
        target_rps=args.target_rps,
        duration_s=args.duration_s,
        workers=args.workers,
        collector_endpoint=args.collector_endpoint,
        prometheus_url=args.prometheus_url,
    )

    args.results_json.parent.mkdir(parents=True, exist_ok=True)
    args.results_json.write_text(json.dumps(results, indent=2, default=float))
    logger.info("Wrote raw results: %s", args.results_json)
    logger.info(
        "actual_rps=%.1f p99_us=%.1f rss_mb=%.1f drops=%d pipeline_send_failed_delta=%.0f",
        results["actual_rps"],
        results["latency_us"]["p99"],
        results["sdk_rss_mb"]["ceiling"],
        results["sdk_pipeline"]["total_items_dropped"],
        results["collector_pipeline"]["total_send_failed_delta"],
    )
    # Per review finding #8: exit 0 whenever the JSON was written. Verdict is
    # data, inspected by the report writer.
    return 0


if __name__ == "__main__":
    sys.exit(main())
