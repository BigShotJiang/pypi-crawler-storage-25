"""N=10-run distribution harness for logging-overhead SLO (Story 6-30 Wave 2).

Replaces the single-run 375.1% data point with a statistical distribution
(min / p50 / p95 / p99 / max / mean / stddev). Runs two back-to-back blocks
in the same process:

  1. NoOp OTLP exporters  - isolates stdlib logging + OTel-handler cost
  2. Real OTLP exporter   - production-realistic measurement

Story 6-44 adds two positive-path blocks under --assoc, satisfying AC 1
which mandates "exercise the association_id positive branch on every
record_prediction / record_error call":

  Block D: NoOp exporters, record_prediction with association_id every call
  Block F: NoOp exporters, record_error   with association_id every call

The path filter mirrors tests/performance/test_performance_slo.py: cumtime
is attributed to the stdlib `logging/` package only, so comparisons are
apples-to-apples with the gate SLO.

Writes:
    _bmad-output/test-artifacts/week1/logging-overhead-distribution-<ts>.txt
    _bmad-output/test-artifacts/week1/logging-overhead-distribution-assoc-<ts>.txt  (Blocks D + F)

Usage:
    MCA_ENV=staging MCA_COLLECTOR_ENDPOINT=http://localhost:4318 \\
        python tests/performance/profile_distribution.py
    python tests/performance/profile_distribution.py --assoc   # Blocks D + F
"""

import cProfile
import os
import platform
import pstats
import statistics
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from tests.performance.profile_overhead import install_noop_otlp_exporters
from tests.performance.assoc_kwargs import (
    prediction_kwargs,
    error_kwargs,
    BRANCH_COVERAGE_DESCRIPTION,
)

ITERATIONS = 5000
N_RUNS = 10  # first run discarded as warm-up; 9 scored
WARMUP_RUNS = 1


def _make_client():
    from mca_sdk import MCAClient

    return MCAClient(
        service_name="distribution-bench",
        model_id="mdl-dist-001",
        team_name="performance-team",
        model_category="internal",
        model_type="classification",
        strict_validation=False,
    )


def _block_c_main() -> None:
    """Block C — audit logging disabled (isolates OTLP exporter cost).

    Requires MCA_DISABLE_AUDIT_LOG=true to be set before MCAClient construction.
    Real OTLP exporters (no NoOp monkey-patch) so that the exporter overhead is
    still measured — only the fast-path audit enqueue is short-circuited.
    """
    artifact_dir = (
        Path(__file__).parent.parent.parent.parent / "_bmad-output" / "test-artifacts" / "week1"
    )
    artifact_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    output = artifact_dir / f"logging-overhead-distribution-no-audit-{ts}.txt"

    print("=" * 80)
    print(f"Story 6-30 distribution harness (BLOCK C — audit disabled) — N={N_RUNS}")
    print("=" * 80)

    if os.environ.get("MCA_DISABLE_AUDIT_LOG", "").lower() != "true":
        print("[block C] WARNING: MCA_DISABLE_AUDIT_LOG is not set to 'true'.")
        print("[block C] Set it explicitly before invoking --block-c to isolate OTLP cost.")

    block_c = _run_distribution("Block C — Audit disabled (OTLP exporter cost only)")
    meta = _runner_metadata()

    header_lines = [
        "# Logging-overhead distribution — Block C (Story 6-30 Wave 2 remediation)",
        f"# generated: {datetime.now().isoformat()}",
        "",
        "## Runner metadata",
        f"platform:            {meta['platform']}",
        f"processor:           {meta['processor']}",
        f"cpu_count:           {meta['cpu_count']}",
        f"python:              {meta['python']}",
        f"memory_bytes:        {meta['memory_bytes']}",
        f"MCA_ENV:             {meta['env_MCA_ENV']}",
        f"MCA_COLLECTOR:       {meta['env_MCA_COLLECTOR_ENDPOINT']}",
        f"MCA_DISABLE_AUDIT:   {os.environ.get('MCA_DISABLE_AUDIT_LOG', '')}",
        "",
        "## Distribution",
        "",
    ]
    body = _format_section(block_c)
    output.write_text("\n".join(header_lines) + body)
    print(f"\nWritten: {output}")


def _measure_one_run(
    client, *, method: str = "prediction", with_association_id: bool = False
) -> tuple[float, float]:
    """Run ITERATIONS calls of the chosen client method under cProfile.

    Parameters
    ----------
    method : "prediction" or "error"
        Which hot-path method to exercise each iteration.
    with_association_id : bool
        If True, every call is given a non-None association_id, forcing the
        positive branch of the guard inside the chosen method.
    """
    profiler = cProfile.Profile()
    profiler.enable()
    if method == "prediction":
        for i in range(ITERATIONS):
            client.record_prediction(**prediction_kwargs(i, with_association_id))
    elif method == "error":
        # A fresh exception per iteration is required because record_error
        # sets `_mca_recorded = True` on the passed exception instance and
        # short-circuits on repeated calls with the same instance.
        for i in range(ITERATIONS):
            client.record_error(
                RuntimeError(f"simulated error {i}"),
                **error_kwargs(i, with_association_id),
            )
    else:
        raise ValueError(f"unknown method: {method!r}")
    profiler.disable()

    stats = pstats.Stats(profiler)
    total_time = stats.total_tt
    logging_time = 0.0
    for func, stat in stats.stats.items():
        filename, line, func_name = func
        if os.sep + "logging" + os.sep in filename or filename.endswith(os.sep + "logging.py"):
            logging_time += stat[3]
    ratio = (logging_time / total_time * 100.0) if total_time > 0 else 0.0
    return total_time, ratio


def _run_distribution(
    label: str, *, method: str = "prediction", with_association_id: bool = False
) -> dict:
    client = _make_client()
    try:
        scored: list[float] = []
        totals: list[float] = []
        for i in range(N_RUNS):
            total, ratio = _measure_one_run(
                client, method=method, with_association_id=with_association_id
            )
            if i < WARMUP_RUNS:
                continue
            scored.append(ratio)
            totals.append(total)
    finally:
        client.shutdown()

    scored_sorted = sorted(scored)

    def _pct(p: float) -> float:
        if not scored_sorted:
            return 0.0
        idx = min(len(scored_sorted) - 1, int(round((p / 100.0) * (len(scored_sorted) - 1))))
        return scored_sorted[idx]

    return {
        "label": label,
        "method": method,
        "n_total": N_RUNS,
        "n_warmup_discarded": WARMUP_RUNS,
        "n_scored": len(scored),
        "iterations_per_run": ITERATIONS,
        "min": min(scored) if scored else 0.0,
        "p50": _pct(50),
        "p95": _pct(95),
        "p99": _pct(99),
        "max": max(scored) if scored else 0.0,
        "mean": statistics.fmean(scored) if scored else 0.0,
        "stddev": statistics.stdev(scored) if len(scored) > 1 else 0.0,
        "raw": scored,
        "totals": totals,
    }


def _runner_metadata() -> dict:
    try:
        import psutil  # type: ignore

        mem_total = psutil.virtual_memory().total
    except Exception:
        mem_total = 0
        try:
            with open("/proc/meminfo") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        mem_total = int(line.split()[1]) * 1024
                        break
        except Exception:
            pass

    return {
        "platform": platform.platform(),
        "processor": platform.processor() or "unknown",
        "cpu_count": os.cpu_count() or 0,
        "python": sys.version.replace("\n", " "),
        "memory_bytes": mem_total,
        "env_MCA_ENV": os.environ.get("MCA_ENV", ""),
        "env_MCA_COLLECTOR_ENDPOINT": os.environ.get("MCA_COLLECTOR_ENDPOINT", ""),
    }


def _format_section(block: dict) -> str:
    def pct(v: float) -> str:
        return f"{v:>8.2f}%"

    method_label = block.get("method", "prediction")
    lines = [
        f"--- {block['label']} ---",
        f"runs:          {block['n_total']} total ({block['n_warmup_discarded']} warm-up discarded, {block['n_scored']} scored)",
        f"iterations:    {block['iterations_per_run']} record_{method_label}() calls per run",
        "",
        "logging cumtime / total cumtime (stdlib logging/ path filter):",
        f"  min     {pct(block['min'])}",
        f"  p50     {pct(block['p50'])}",
        f"  p95     {pct(block['p95'])}",
        f"  p99     {pct(block['p99'])}",
        f"  max     {pct(block['max'])}",
        f"  mean    {pct(block['mean'])}",
        f"  stddev  {pct(block['stddev'])}",
        "",
        "raw scored ratios: " + ", ".join(f"{r:.2f}%" for r in block["raw"]),
        "raw total cumtimes (s): " + ", ".join(f"{t:.3f}" for t in block["totals"]),
        "",
    ]
    return "\n".join(lines)


def main_assoc() -> None:
    """Story 6-44 positive-path blocks — NoOp exporters, association_id supplied.

    Block D — record_prediction() positive path.
    Block F — record_error()      positive path.

    Together these satisfy AC 1 which requires the positive branch on
    every record_prediction / record_error call. Apples-to-apples with
    Blocks A and B (NoOp exporters, stdlib logging/ path filter).
    """
    artifact_dir = (
        Path(__file__).parent.parent.parent.parent / "_bmad-output" / "test-artifacts" / "week1"
    )
    artifact_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    output = artifact_dir / f"logging-overhead-distribution-assoc-{ts}.txt"

    print("=" * 80)
    print(f"Story 6-44 distribution harness (BLOCKS D + F — positive path) — N={N_RUNS}")
    print("=" * 80)

    print("\n[blocks D/F] installing NoOp OTLP exporters ...")
    install_noop_otlp_exporters()

    print("[block D] running positive-path record_prediction distribution ...")
    block_d = _run_distribution(
        "Block D — NoOp OTLP exporters, positive path, record_prediction (association_id supplied)",
        method="prediction",
        with_association_id=True,
    )

    print("[block F] running positive-path record_error distribution ...")
    block_f = _run_distribution(
        "Block F — NoOp OTLP exporters, positive path, record_error (association_id supplied)",
        method="error",
        with_association_id=True,
    )

    meta = _runner_metadata()

    header_lines = [
        "# Logging-overhead distribution — Blocks D + F (Story 6-44 positive-path coverage)",
        f"# generated: {datetime.now().isoformat()}",
        "",
        "## Runner metadata",
        f"platform:          {meta['platform']}",
        f"processor:         {meta['processor']}",
        f"cpu_count:         {meta['cpu_count']}",
        f"python:            {meta['python']}",
        f"memory_bytes:      {meta['memory_bytes']}",
        f"MCA_ENV:           {meta['env_MCA_ENV']}",
        f"MCA_COLLECTOR:     {meta['env_MCA_COLLECTOR_ENDPOINT']}",
        "",
        "## Path filter",
        "stdlib `logging/` path only (matches the gate SLO pytest)",
        "",
        "## Positive-path branches exercised",
        BRANCH_COVERAGE_DESCRIPTION,
        "",
        "## Distribution",
        "",
    ]
    body = _format_section(block_d) + _format_section(block_f)
    output.write_text("\n".join(header_lines) + body)
    print(f"\nWritten: {output}")


def main() -> None:
    artifact_dir = (
        Path(__file__).parent.parent.parent.parent / "_bmad-output" / "test-artifacts" / "week1"
    )
    artifact_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    output = artifact_dir / f"logging-overhead-distribution-{ts}.txt"

    print("=" * 80)
    print(f"Story 6-30 distribution harness — N={N_RUNS} (warm-up={WARMUP_RUNS})")
    print("=" * 80)

    # Block A — NoOp exporters (isolated measurement)
    print("\n[block A] installing NoOp OTLP exporters ...")
    install_noop_otlp_exporters()
    print("[block A] running NoOp distribution ...")
    noop = _run_distribution("Block A — NoOp OTLP exporters (isolated)")

    # Block B — Real exporter path
    # Once exporters are patched in-process, reversing the monkey-patch is
    # not safe without reloading modules. Emit block A only if this harness
    # is invoked without --real; otherwise run a second subprocess externally.
    # For Wave 2 we produce block A in this invocation and record block B
    # from a separate invocation (see artifact header).
    print("[block B] skipped in same process (see artifact header for Block B run)")
    block_b = None

    meta = _runner_metadata()

    header_lines = [
        "# Logging-overhead distribution (Story 6-30 Wave 2 remediation)",
        f"# generated: {datetime.now().isoformat()}",
        "",
        "## Runner metadata",
        f"platform:          {meta['platform']}",
        f"processor:         {meta['processor']}",
        f"cpu_count:         {meta['cpu_count']}",
        f"python:            {meta['python']}",
        f"memory_bytes:      {meta['memory_bytes']}",
        f"MCA_ENV:           {meta['env_MCA_ENV']}",
        f"MCA_COLLECTOR:     {meta['env_MCA_COLLECTOR_ENDPOINT']}",
        "",
        "## Path filter",
        "stdlib `logging/` path only (matches the gate SLO pytest)",
        "",
        "## Distribution",
        "",
    ]

    body = _format_section(noop)
    if block_b is not None:
        body += _format_section(block_b)
    else:
        body += (
            "--- Block B — Real OTLP exporter ---\n"
            "Run this harness a second time WITHOUT install_noop_otlp_exporters()\n"
            "(pass --real) to populate Block B. Block A and Block B must be\n"
            "captured in separate processes so the NoOp monkey-patch in Block\n"
            "A cannot leak into Block B's measurement.\n"
            "\n"
        )

    output.write_text("\n".join(header_lines) + body)
    print(f"\nWritten: {output}")


def main_real() -> None:
    """Run only the real-exporter block and append to the latest artifact."""
    artifact_dir = (
        Path(__file__).parent.parent.parent.parent / "_bmad-output" / "test-artifacts" / "week1"
    )
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    output = artifact_dir / f"logging-overhead-distribution-real-{ts}.txt"

    print("=" * 80)
    print(f"Story 6-30 distribution harness (REAL exporter) — N={N_RUNS}")
    print("=" * 80)

    real = _run_distribution("Block B — Real OTLP exporter")
    meta = _runner_metadata()

    header_lines = [
        "# Logging-overhead distribution — Block B (Story 6-30 Wave 2 remediation)",
        f"# generated: {datetime.now().isoformat()}",
        "",
        "## Runner metadata",
        f"platform:          {meta['platform']}",
        f"processor:         {meta['processor']}",
        f"cpu_count:         {meta['cpu_count']}",
        f"python:            {meta['python']}",
        f"memory_bytes:      {meta['memory_bytes']}",
        f"MCA_ENV:           {meta['env_MCA_ENV']}",
        f"MCA_COLLECTOR:     {meta['env_MCA_COLLECTOR_ENDPOINT']}",
        "",
        "## Distribution",
        "",
    ]
    body = _format_section(real)
    output.write_text("\n".join(header_lines) + body)
    print(f"\nWritten: {output}")


if __name__ == "__main__":
    if "--block-c" in sys.argv:
        _block_c_main()
    elif "--assoc" in sys.argv:
        main_assoc()
    elif "--real" in sys.argv:
        main_real()
    else:
        main()
