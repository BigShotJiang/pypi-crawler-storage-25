"""Compare a current load-test summary JSON against historical runs and flag regressions.

Story 6-8 trend-alert helper. Reads the last N entries from a JSONL history file,
computes per-scenario median p95, and fails (exit 1) if either:
  - Current p95 for any scenario regresses > REGRESSION_PCT beyond that median, or
  - Minimum completeness across signals drops below COMPLETENESS_THRESHOLD.

With --append, also appends the current summary to the history JSONL (idempotent;
meant to be run in CI after comparison passes).
"""

import argparse
import json
import statistics
import sys
from pathlib import Path
from typing import Dict, List, Optional

REGRESSION_PCT = 20.0
COMPLETENESS_THRESHOLD = 99.0
HISTORY_WINDOW = 5


def _load_current(path: Path) -> Dict:
    with open(path) as f:
        return json.load(f)


def _load_history(path: Path) -> List[Dict]:
    if not path.exists() or path.stat().st_size == 0:
        return []
    entries: List[Dict] = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            entries.append(json.loads(line))
    return entries


def _p95_per_scenario(entry: Dict) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for row in entry.get("scenarios", []):
        name = row.get("scenario")
        p95 = row.get("p95_ms")
        if name and isinstance(p95, (int, float)):
            out[name] = float(p95)
    return out


def _median_history(history: List[Dict]) -> Dict[str, float]:
    collected: Dict[str, List[float]] = {}
    for entry in history[-HISTORY_WINDOW:]:
        for name, p95 in _p95_per_scenario(entry).items():
            collected.setdefault(name, []).append(p95)
    return {name: statistics.median(values) for name, values in collected.items() if values}


def _evaluate(current: Dict, history: List[Dict]) -> List[str]:
    """Return a list of regression messages. Empty list means PASS."""
    failures: List[str] = []

    if history:
        baselines = _median_history(history)
        for name, current_p95 in _p95_per_scenario(current).items():
            baseline = baselines.get(name)
            if baseline is None or baseline <= 0:
                continue
            pct = (current_p95 - baseline) / baseline * 100.0
            if pct > REGRESSION_PCT:
                failures.append(
                    f"regression: scenario '{name}' p95 {current_p95:.2f}ms exceeds "
                    f"{REGRESSION_PCT:.0f}% over baseline median {baseline:.2f}ms "
                    f"(+{pct:.1f}%)"
                )

    completeness: Optional[float] = current.get("min_completeness_percent")
    if completeness is not None and completeness < COMPLETENESS_THRESHOLD:
        failures.append(
            f"completeness regression: {completeness:.2f}% < "
            f"{COMPLETENESS_THRESHOLD:.2f}% threshold"
        )

    return failures


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--current", type=Path, required=True, help="Path to current summary JSON")
    parser.add_argument("--history", type=Path, required=True, help="Path to summary.jsonl")
    parser.add_argument(
        "--append",
        action="store_true",
        help="Append current summary to history file (only when comparison passes)",
    )
    args = parser.parse_args()

    current = _load_current(args.current)
    history = _load_history(args.history)

    if not history:
        print("no history found - seeding baseline run, skipping comparison")
    else:
        print(f"comparing against last {min(len(history), HISTORY_WINDOW)} historical run(s)")

    failures = _evaluate(current, history)

    if failures:
        print("FAIL")
        for msg in failures:
            print(f"  - {msg}")
        return 1

    print("PASS - no regressions detected")

    if args.append:
        args.history.parent.mkdir(parents=True, exist_ok=True)
        with open(args.history, "a") as f:
            f.write(json.dumps(current) + "\n")
        print(f"appended current summary to {args.history}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
