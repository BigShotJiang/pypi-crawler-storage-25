import pytest
import time
import os
import tracemalloc
from mca_sdk.core.client import MCAClient
import logging

from tests.performance.assoc_kwargs import prediction_kwargs
from tests.support.logging_overhead import is_stdlib_logging_frame

# SLO Thresholds per docs/sdk-testing-plan.md:339
# 1. p99 Latency < 0.5ms (500us)
# 2. Logging Overhead < 10% CPU
# 3. Memory Ceiling < 100MB
# 4. Shutdown Time < 5s
# 5. Throughput 2000 req/s sustained for 60s
#
# Environment scaling: if the test runner is a shared CI runner, the SLO
# targets may need to be multiplied. The multiplier is read from
# MCA_SLO_RUNNER_MULTIPLIER (default 1.0) and recorded in the failure
# message so NFR evidence can cite the chosen value. Do NOT silently relax
# a threshold by hand-editing the literal in the assert.

_SLO_MULTIPLIER = float(os.environ.get("MCA_SLO_RUNNER_MULTIPLIER", "1.0"))


@pytest.mark.slo
class TestPerformanceSLO:

    @pytest.fixture(autouse=True)
    def setup_env(self):
        """Ensure background refresh is disabled for pure request latency measurement.

        Restores any previous env values on teardown so tests do not leak state.
        """
        keys = {
            "MCA_PREFER_REGISTRY": "false",
            "MCA_BACKGROUND_REFRESH_INTERVAL_SECONDS": "0",
        }
        previous = {k: os.environ.get(k) for k in keys}
        for k, v in keys.items():
            os.environ[k] = v
        try:
            yield
        finally:
            for k, prev in previous.items():
                if prev is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = prev

    def test_prediction_p99_latency_under_500us(self):
        """Assert that 99% of predictions complete in under 0.5ms (SLO)."""
        client = MCAClient(
            service_name="test-service",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )

        client.config.telemetry_buffering_enabled = True
        client.config.telemetry_buffer_size = 20000

        latencies = []
        for i in range(100):
            client.record_prediction(latency=0.1, prediction_id=f"warmup-{i}")

        for i in range(10000):
            start = time.perf_counter()
            client.record_prediction(latency=0.1, prediction_id=f"pred-{i}")
            end = time.perf_counter()
            latencies.append((end - start) * 1000)

        latencies.sort()
        p99_idx = int(len(latencies) * 0.99)
        p99_ms = latencies[p99_idx]

        client.shutdown()

        threshold_ms = 0.5 * _SLO_MULTIPLIER
        assert p99_ms < threshold_ms, (
            f"p99 Latency SLO Violated: {p99_ms:.3f}ms "
            f"(Target: <0.5ms, multiplier={_SLO_MULTIPLIER}, threshold={threshold_ms:.3f}ms)"
        )

    def test_prediction_p99_latency_with_phi_strings_under_500us(self):
        """SLO regression test for story 6-31 PHI filter (review finding #8).

        The baseline p99 test only passes numeric / opaque-id attributes, which
        short-circuit the PHI regex at the length-check gate. This variant
        sends the filter's worst case: long string attributes that actually
        match SSN/MRN/DOB patterns, forcing the regex engine to run and
        allocate a redacted copy on every call. p99 must still stay under the
        same 500us budget.
        """
        client = MCAClient(
            service_name="test-service-phi",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )
        client.config.telemetry_buffering_enabled = True
        client.config.telemetry_buffer_size = 20000

        # Warmup.
        for i in range(100):
            client.record_prediction(
                latency=0.1,
                prediction_id=f"warmup-{i}",
                ssn_val="123-45-6789",
                mrn_val="MRN987654",
                dob_val="01/01/1980",
                notes="patient 123-45-6789 admitted 01/01/1980",
            )

        latencies = []
        for i in range(10000):
            start = time.perf_counter()
            client.record_prediction(
                latency=0.1,
                prediction_id=f"pred-{i}",
                ssn_val="123-45-6789",
                mrn_val="MRN987654",
                dob_val="01/01/1980",
                notes="patient 123-45-6789 admitted 01/01/1980",
            )
            end = time.perf_counter()
            latencies.append((end - start) * 1000)

        latencies.sort()
        p99_idx = int(len(latencies) * 0.99)
        p99_ms = latencies[p99_idx]

        client.shutdown()

        threshold_ms = 0.5 * _SLO_MULTIPLIER
        assert p99_ms < threshold_ms, (
            f"PHI-filter p99 Latency SLO Violated: {p99_ms:.3f}ms "
            f"(Target: <0.5ms, multiplier={_SLO_MULTIPLIER}, threshold={threshold_ms:.3f}ms)"
        )

    @pytest.mark.parametrize(
        "supply_association_id",
        [
            pytest.param(False, id="none-path"),
            pytest.param(True, id="positive-path"),
        ],
    )
    def test_logging_overhead_under_10_percent(self, supply_association_id):
        """Assert logging CPU time is under 10% of total SDK overhead (SLO).

        Parametrized across two branches of the `if association_id is not None:`
        guards on the record_prediction hot path (log_extra augmentation and
        span set_attribute). The none-path parameter preserves the original
        SLO baseline; the positive-path parameter closes the coverage gap
        called out in story 6-44 by exercising the positive branch on every
        call. Measurement methodology (path filter, iteration count, cProfile
        setup) is identical across both parameters so comparisons are
        apples-to-apples.
        """
        client = MCAClient(
            service_name="test-service",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )

        # Positive-path execution probe: intercept the fast-path audit enqueue
        # so we can assert after the loop that log_extra['association_id'] was
        # populated every time. Without this, a typo in the branch condition
        # would silently pass the SLO gate on false-branch timing only.
        captured_extras: list = []
        if supply_association_id:
            original_enqueue = client._enqueue_audit_fast

            def _capture(msg, extra=None):
                captured_extras.append(extra)
                return original_enqueue(msg, extra)

            client._enqueue_audit_fast = _capture

        import cProfile
        import pstats

        profiler = cProfile.Profile()
        profiler.enable()

        iterations = 5000
        for i in range(iterations):
            client.record_prediction(**prediction_kwargs(i, supply_association_id))

        profiler.disable()

        if supply_association_id:
            # Positive-branch execution assertion. Every call must have emitted
            # log_extra with association_id populated; anything else means the
            # branch at client.py `if association_id is not None:` did not run.
            assert (
                len(captured_extras) == iterations
            ), f"Expected {iterations} audit-log extras; captured {len(captured_extras)}"
            missing = [
                i for i, e in enumerate(captured_extras) if "association_id" not in (e or {})
            ]
            assert not missing, (
                f"{len(missing)} out of {iterations} captured extras missing association_id; "
                f"positive branch did not execute on every call"
            )

        stats = pstats.Stats(profiler)

        total_time = stats.total_tt
        logging_time = 0.0

        # Attribute cumtime only to frames whose source file lives inside the
        # stdlib logging package, identified via logging.__file__ introspection.
        # See tests/support/logging_overhead.py for the predicate.
        for func, stat in stats.stats.items():
            filename, line, func_name = func
            if is_stdlib_logging_frame(filename):
                logging_time += stat[3]

        overhead_percent = (logging_time / total_time) * 100 if total_time > 0 else 0

        # Emit the numeric result so captured-stdout always carries it.
        branch_label = "positive-path" if supply_association_id else "none-path"
        print(
            f"[logging-overhead {branch_label}] overhead={overhead_percent:.3f}% "
            f"(total_cumtime={total_time:.4f}s, logging_cumtime={logging_time:.4f}s)"
        )

        threshold = 10.0 * _SLO_MULTIPLIER
        assert overhead_percent < threshold, (
            f"Logging Overhead SLO ({branch_label}) Violated: {overhead_percent:.1f}% "
            f"(Target: <10%, multiplier={_SLO_MULTIPLIER}, threshold={threshold:.1f}%)"
        )

    def test_memory_ceiling_under_100mb(self):
        """Assert peak memory does not exceed 100MB during sustained load (SLO).

        Uses tracemalloc peak measurement, not a signed delta, so transient
        spikes are captured. Sustained load is approximated by driving
        predictions continuously and sampling peak at completion.
        """
        tracemalloc.start()

        client = MCAClient(
            service_name="test-service",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )

        tracemalloc.reset_peak()

        for i in range(10000):
            client.record_prediction(
                latency=0.1,
                prediction_id=f"pred-{i}",
                input_data="x" * 100,
                output="y" * 100,
            )

        current, peak = tracemalloc.get_traced_memory()
        peak_mb = peak / (1024 * 1024)

        tracemalloc.stop()
        client.shutdown()

        threshold_mb = 100.0 * _SLO_MULTIPLIER
        assert peak_mb < threshold_mb, (
            f"Memory Ceiling SLO Violated: peak={peak_mb:.1f}MB "
            f"(Target: <100MB, multiplier={_SLO_MULTIPLIER}, threshold={threshold_mb:.1f}MB)"
        )

    def test_shutdown_under_5s_with_inflight_load(self):
        """Assert client.shutdown() completes in under 5s while load is still in flight (SLO).

        The plan required "shutdown under in-flight load", not shutdown after a
        quiet buffer. A background worker keeps record_prediction calls arriving
        while shutdown executes.
        """
        import threading

        client = MCAClient(
            service_name="test-service",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )

        client.config.telemetry_buffering_enabled = True
        client.config.telemetry_buffer_size = 50000

        stop_flag = threading.Event()

        def flood():
            i = 0
            while not stop_flag.is_set():
                try:
                    client.record_prediction(latency=0.1, prediction_id=f"inflight-{i}")
                except Exception:
                    break
                i += 1

        loaders = [threading.Thread(target=flood, daemon=True) for _ in range(2)]
        for t in loaders:
            t.start()

        # Let the buffer fill and the workers reach steady-state before shutdown.
        time.sleep(0.5)

        start_time = time.time()
        client.shutdown()
        duration = time.time() - start_time

        stop_flag.set()
        for t in loaders:
            t.join(timeout=1.0)

        threshold_s = 5.0 * _SLO_MULTIPLIER
        assert duration < threshold_s, (
            f"Shutdown SLO Violated: {duration:.1f}s "
            f"(Target: <5s under in-flight load, multiplier={_SLO_MULTIPLIER}, threshold={threshold_s:.1f}s)"
        )

    def test_throughput_2000_rps_sustained_60s(self):
        """Assert SDK sustains 2000 req/s for 60 seconds without errors (SLO).

        The plan requires a sustained-rate test, not a one-shot burst. The
        test runs for a wall-clock window and measures achieved rate; it
        fails if the achieved rate drops below 2000 req/s or if any worker
        raises.
        """
        import threading

        client = MCAClient(
            service_name="test-service",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )

        client.config.telemetry_buffering_enabled = True
        client.config.telemetry_buffer_size = 500000

        # Sustained-run window. Shortened to 10s by default for CI wall-clock
        # budget; override with MCA_SLO_SUSTAIN_SECONDS=60 for the full SLO.
        duration_target_s = float(os.environ.get("MCA_SLO_SUSTAIN_SECONDS", "10"))
        target_rps = 2000.0
        num_threads = 4
        per_thread_rps = target_rps / num_threads

        errors: list = []
        total_count = [0] * num_threads

        def worker(idx: int):
            end_at = time.time() + duration_target_s
            i = 0
            while time.time() < end_at:
                try:
                    client.record_prediction(
                        latency=0.01, prediction_id=f"pred-{threading.get_ident()}-{i}"
                    )
                    total_count[idx] += 1
                    i += 1
                except Exception as e:
                    errors.append(e)
                    return

        threads = [threading.Thread(target=worker, args=(i,)) for i in range(num_threads)]

        start_time = time.time()
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        actual_duration = time.time() - start_time

        total = sum(total_count)
        achieved_rps = total / actual_duration if actual_duration > 0 else 0

        client.shutdown()

        assert not errors, f"Throughput SLO Violated: worker errors {errors!r}"

        threshold_rps = target_rps / _SLO_MULTIPLIER
        assert achieved_rps >= threshold_rps, (
            f"Throughput SLO Violated: {achieved_rps:.0f} req/s sustained over "
            f"{actual_duration:.1f}s (Target: >=2000 req/s for {duration_target_s:.0f}s, "
            f"multiplier={_SLO_MULTIPLIER}, threshold={threshold_rps:.0f} req/s)"
        )
