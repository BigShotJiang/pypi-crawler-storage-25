#!/usr/bin/env bash
# Story 6-39 runner: health-checks the local OTel Collector, runs the 2000 req/s
# driver, emits the report to _bmad-output/test-artifacts/week1/, prints the path.
#
# Exit behaviour (per review finding #8): this runner exits 0 whenever the report
# artifact was successfully written, regardless of whether AC-3's SLO comparison
# passes or fails. The verdict lives inside the report file; CI is expected to
# parse the report, not infer outcomes from the exit code. Infrastructure
# failures (collector unreachable, dependency missing, report file empty) DO
# exit non-zero so CI halts on real problems.
#
# Per review finding #9: no silent fallbacks. One clean invocation. Pre-flight
# import check fails loudly if a dependency is missing.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MCA_PROTOTYPE_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
REPO_ROOT="$(cd "${MCA_PROTOTYPE_DIR}/.." && pwd)"

COLLECTOR_ENDPOINT="${MCA_TEST_COLLECTOR_ENDPOINT:-http://localhost:4318}"
HEALTH_URL="${MCA_TEST_COLLECTOR_HEALTH_URL:-http://localhost:13133/health/status}"
PROMETHEUS_URL="${MCA_TEST_COLLECTOR_PROMETHEUS_URL:-http://localhost:8889/metrics}"
TARGET_RPS="${MCA_TEST_TARGET_RPS:-2000}"
DURATION_S="${MCA_TEST_DURATION_S:-60}"
WORKERS="${MCA_TEST_WORKERS:-4}"
PYTHON_BIN="${MCA_TEST_PYTHON:-python3}"

ARTIFACT_DIR="${REPO_ROOT}/_bmad-output/test-artifacts/week1"
TS="$(date +%Y%m%d-%H%M%S)"
RESULTS_JSON="${ARTIFACT_DIR}/load-test-results-${TS}.json"
REPORT_MD="${ARTIFACT_DIR}/load-test-report-${TS}.md"

mkdir -p "${ARTIFACT_DIR}"

echo "[6-39] Pre-flight: check Python dependencies"
PYTHONPATH="${MCA_PROTOTYPE_DIR}:${PYTHONPATH:-}" "${PYTHON_BIN}" -c "
import sys
missing = []
for mod in ('prometheus_client', 'psutil', 'requests', 'mca_sdk'):
    try:
        __import__(mod)
    except ImportError as e:
        missing.append((mod, str(e)))
if missing:
    for name, err in missing:
        print(f'MISSING: {name} ({err})', file=sys.stderr)
    sys.exit(1)
print('[6-39] All dependencies importable.')
" || {
  echo "[6-39] FAIL: dependency import failed (see above)." >&2
  exit 10
}

echo "[6-39] Health-check collector: ${HEALTH_URL}"
HEALTH_MAX_WAIT_S="${MCA_TEST_HEALTH_MAX_WAIT_S:-30}"
HEALTH_RETRY_INTERVAL_S="${MCA_TEST_HEALTH_RETRY_INTERVAL_S:-2}"
health_start_ts=$(date +%s)
health_ok=0
while :; do
  # Per review finding #L: check HTTP status, not the response body string.
  # The OTel Collector health extension's payload format is not part of any
  # stable contract — grepping for "Server available" silently breaks if the
  # extension shifts to {"status":"UP"} or any other shape. HTTP 200 is the
  # contract every health endpoint actually honours.
  status="$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "${HEALTH_URL}" 2>/dev/null || echo 000)"
  if [[ "${status}" == "200" ]]; then
    health_ok=1
    echo "[6-39] Health OK (HTTP ${status}) after $(( $(date +%s) - health_start_ts ))s."
    break
  fi
  elapsed=$(( $(date +%s) - health_start_ts ))
  if (( elapsed >= HEALTH_MAX_WAIT_S )); then
    break
  fi
  echo "[6-39] Collector not ready yet (HTTP ${status}) — waiting... (${elapsed}s/${HEALTH_MAX_WAIT_S}s)"
  sleep "${HEALTH_RETRY_INTERVAL_S}"
done
if (( health_ok == 0 )); then
  elapsed=$(( $(date +%s) - health_start_ts ))
  echo "[6-39] FAIL: collector health check failed at ${HEALTH_URL} after ${elapsed}s" >&2
  echo "[6-39]  Ensure 'docker compose up -d otel-collector' is running in ${MCA_PROTOTYPE_DIR}" >&2
  echo "[6-39]  Tune MCA_TEST_HEALTH_MAX_WAIT_S / MCA_TEST_HEALTH_RETRY_INTERVAL_S if this is a cold start" >&2
  exit 2
fi

echo "[6-39] Prometheus probe: ${PROMETHEUS_URL}"
if ! curl -fsS --max-time 5 "${PROMETHEUS_URL}" >/dev/null; then
  echo "[6-39] WARN: Prometheus self-monitor endpoint unreachable; queue-depth will be N/A" >&2
fi

echo "[6-39] Running driver (target=${TARGET_RPS} rps, duration=${DURATION_S}s, workers=${WORKERS})"
PYTHONPATH="${MCA_PROTOTYPE_DIR}:${PYTHONPATH:-}" "${PYTHON_BIN}" \
  "${MCA_PROTOTYPE_DIR}/tests/performance/load_test_2000rps.py" \
  --target-rps "${TARGET_RPS}" \
  --duration-s "${DURATION_S}" \
  --workers "${WORKERS}" \
  --collector-endpoint "${COLLECTOR_ENDPOINT}" \
  --prometheus-url "${PROMETHEUS_URL}" \
  --results-json "${RESULTS_JSON}"

# Per review finding #K: validate the JSON, not just file existence. A
# truncated or invalid file passes the `-s` check but breaks the report
# writer with a JSONDecodeError. Validate by attempting a parse; on failure,
# render an INCONCLUSIVE stub markdown so CI still gets the required artifact.
if [[ ! -s "${RESULTS_JSON}" ]] \
  || ! "${PYTHON_BIN}" -c "import json,sys; json.load(open(sys.argv[1]))" "${RESULTS_JSON}" 2>/dev/null; then
  echo "[6-39] FAIL: results JSON missing or invalid: ${RESULTS_JSON}" >&2
  echo "[6-39] Rendering INCONCLUSIVE stub report so CI gets a markdown artifact" >&2
  PYTHONPATH="${MCA_PROTOTYPE_DIR}:${PYTHONPATH:-}" "${PYTHON_BIN}" \
    "${MCA_PROTOTYPE_DIR}/tests/performance/load_test_2000rps_report.py" \
    --emit-inconclusive-stub \
    --report-path "${REPORT_MD}" \
    --reason "results JSON missing or invalid: ${RESULTS_JSON}" || true
  exit 3
fi

echo "[6-39] Rendering report: ${REPORT_MD}"
PYTHONPATH="${MCA_PROTOTYPE_DIR}:${PYTHONPATH:-}" "${PYTHON_BIN}" \
  "${MCA_PROTOTYPE_DIR}/tests/performance/load_test_2000rps_report.py" \
  --results-json "${RESULTS_JSON}" \
  --report-path "${REPORT_MD}"

if [[ ! -s "${REPORT_MD}" ]]; then
  echo "[6-39] FAIL: report file missing or empty: ${REPORT_MD}" >&2
  exit 4
fi

echo "[6-39] Report path: ${REPORT_MD}"
echo "[6-39] Raw JSON:    ${RESULTS_JSON}"
echo "[6-39] Verdict is in the report; runner exits 0 on successful artifact generation."
