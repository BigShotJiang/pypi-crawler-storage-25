"""Shared per-iteration kwargs for story 6-44 positive-path coverage.

All three callers — tests/performance/test_performance_slo.py,
tests/performance/profile_distribution.py, and
tests/performance/profile_overhead.py — use the same attribute set so the
SLO gate, the distribution harness, and the cProfile artifact exercise
identical validation / serialization paths. Diverging attribute sets
across these would invalidate apples-to-apples comparisons.

The positive branches this covers are:

  record_prediction — `if association_id is not None:`
    - log_extra['association_id'] population
    - span.set_attribute('ml.association.id', ...)
  record_error      — `if association_id is not None:`
    - log_extra['association_id'] population
    - span.set_attribute('ml.association.id', ...)

Line numbers deliberately not hardcoded — they rot the moment somebody
edits client.py. The guard condition and attribute name are the stable
contract.
"""

from typing import Any, Dict

BRANCH_COVERAGE_DESCRIPTION = (
    "Every record_prediction / record_error call passes association_id=f'assoc-{i}',\n"
    "forcing both positive guards to execute every iteration:\n"
    "  - record_prediction  `if association_id is not None:`  log_extra + span attribute\n"
    "  - record_error       `if association_id is not None:`  log_extra + span attribute\n"
    "Span attribute name: ml.association.id"
)


def prediction_kwargs(i: int, with_association_id: bool) -> Dict[str, Any]:
    """Kwargs for client.record_prediction(**prediction_kwargs(i, supply)).

    Attributes chosen to exercise the same validation/serialization paths
    as the legacy baseline (model_version, input_size, output_size) so the
    SLO gate and the profile harnesses measure the same code. Adding a
    parameter here should be mirrored in error_kwargs so both branches
    stay comparable.
    """
    kwargs: Dict[str, Any] = {
        "latency": 0.1,
        "prediction_id": f"pred-{i}",
        "model_version": "v1.0",
        "input_size": 1024,
        "output_size": 512,
        "some_feature": "value",
    }
    if with_association_id:
        kwargs["association_id"] = f"assoc-{i}"
    return kwargs


def error_kwargs(i: int, with_association_id: bool) -> Dict[str, Any]:
    """Kwargs for client.record_error(exc, **error_kwargs(i, supply)).

    Same attribute set as prediction_kwargs (minus fields record_error
    doesn't accept) so the positive branch is measured under the same
    attribute-validation load.
    """
    kwargs: Dict[str, Any] = {
        "latency": 0.1,
        "prediction_id": f"pred-{i}",
        "model_version": "v1.0",
        "input_size": 1024,
        "output_size": 512,
        "some_feature": "value",
    }
    if with_association_id:
        kwargs["association_id"] = f"assoc-{i}"
    return kwargs
