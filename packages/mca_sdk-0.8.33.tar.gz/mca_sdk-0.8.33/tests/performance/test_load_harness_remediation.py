# Tests for the adversarial-review fixes on stories 6-39 / 6-8 load harness.
# Each test name maps to a finding from the review:
#   C: errors must record latency
#   D: payload-pool char distribution must be uniform
#   G: pacing loop must reset after a long pause
#   H: implicit (covered by run-time integration; not unit-tested here)
#   B/E/F: report validity gates (negative pipeline delta, missing target,
#          strict 1.0 RPS tolerance)
#   K: report writer's INCONCLUSIVE stub mode
#   I: scenarios capture buffer_stats before shutdown
#   A: collector_monitor uses prometheus_client parser (no regex)

from __future__ import annotations

import json
import string
import threading
import time
from collections import Counter
from pathlib import Path
from unittest.mock import MagicMock

import pytest

from tests.performance._load_test_pacing import run_paced_worker
from tests.performance.load_test_2000rps import _build_medium_attrs_pool
from tests.performance.load_test_2000rps_report import (
    RPS_TOLERANCE,
    _measurement_validity,
    render_inconclusive_stub,
)

# ---------------------------------------------------------------------------
# Pacing helper (issues C and G)
# ---------------------------------------------------------------------------


def test_pacing_loop_records_errors_in_latency():
    """Issue C: a request that raises must still append a latency sample.

    If error paths skip ``latencies_us.append()`` the p95/p99 distribution
    silently excludes timeouts and the SLO can pass on fraudulent data.
    """
    latencies_us: list = []
    errors = [0]
    lock = threading.Lock()

    def request_fn(_payload):
        raise RuntimeError("simulated SDK timeout")

    end_at = time.time() + 0.05  # 50 ms run; ~25 requests at 2ms interval
    count = run_paced_worker(
        worker_id=0,
        total_workers=1,
        request_fn=request_fn,
        payload_pool=[None],
        per_worker_interval_s=0.002,
        end_at=end_at,
        latencies_us=latencies_us,
        latencies_lock=lock,
        error_counter=errors,
    )

    assert count > 0
    assert errors[0] == count, "every request should be counted as an error"
    assert len(latencies_us) == count, "every error must contribute a latency sample (Issue C)"
    assert all(value > 0 for value in latencies_us), "latencies must be positive"


def test_pacing_loop_resets_on_long_pause():
    """Issue G: a long stall must not produce a burst of catch-up requests.

    Inject a single ``time.sleep(3 * interval)`` inside the request function.
    Without the reset, the worker would fire ~3 instant requests once it
    recovered. With the reset, only the stalled request is logged that interval
    and the loop returns to its normal cadence — i.e. no inter-request gap of
    less than ~25% of the interval right after the stall.
    """
    latencies_us: list = []
    errors = [0]
    lock = threading.Lock()
    interval = 0.01  # 10 ms
    fired_at: list = []
    stalled = [False]

    def request_fn(_payload):
        fired_at.append(time.perf_counter())
        if not stalled[0]:
            stalled[0] = True
            time.sleep(3 * interval)

    end_at = time.time() + 0.2  # 200 ms total
    run_paced_worker(
        worker_id=0,
        total_workers=1,
        request_fn=request_fn,
        payload_pool=[None],
        per_worker_interval_s=interval,
        end_at=end_at,
        latencies_us=latencies_us,
        latencies_lock=lock,
        error_counter=errors,
    )

    # After the stall (which takes ~3 intervals) we expect post-stall gaps to
    # be at least ~50% of the configured interval. A "burst recovery" bug
    # would produce gaps near zero.
    assert len(fired_at) >= 4, "should fire several requests after stall"
    post_stall_gaps = [fired_at[i + 1] - fired_at[i] for i in range(1, len(fired_at) - 1)]
    min_gap = min(post_stall_gaps)
    assert min_gap >= interval * 0.5, (
        f"post-stall gap {min_gap * 1000:.2f}ms < {interval * 500:.2f}ms — "
        "pacing-debt reset is missing (Issue G)"
    )


# ---------------------------------------------------------------------------
# Payload pool (Issue D)
# ---------------------------------------------------------------------------


def test_payload_pool_char_distribution_is_uniform():
    """Issue D: opaque_token characters must be drawn from a 16-char alphabet
    (0-9a-f) with roughly equal probability. The previous
    ``string.hexdigits.lower()`` doubled the letter frequency because
    ``string.hexdigits`` already contains both cases.
    """
    pool = _build_medium_attrs_pool(size=512, seed=42)
    counts = Counter()
    for entry in pool:
        counts.update(entry["opaque_token"])

    alphabet = set(string.hexdigits[:16])
    assert (
        set(counts.keys()) <= alphabet
    ), f"unexpected characters in opaque_token: {set(counts.keys()) - alphabet}"
    # Each character in the 16-char alphabet should appear; with 512 * 16 =
    # 8192 draws the chance any single letter is missing is vanishingly small.
    assert len(counts) == 16, f"expected all 16 hex digits, got {sorted(counts.keys())}"

    mean = sum(counts.values()) / 16
    max_freq = max(counts.values())
    min_freq = min(counts.values())
    # No character may exceed ~1.5x the mean (well above any plausible
    # uniform-sampling noise but well below the 2x bias the old code produced).
    assert max_freq <= mean * 1.5, (
        f"character {max(counts, key=counts.get)!r} too common "
        f"({max_freq} vs mean {mean:.1f}) — payload bias regressed"
    )
    assert min_freq >= mean * 0.5, (
        f"character {min(counts, key=counts.get)!r} too rare "
        f"({min_freq} vs mean {mean:.1f}) — payload distribution is skewed"
    )


# ---------------------------------------------------------------------------
# Report validity gates (issues B, E, F)
# ---------------------------------------------------------------------------


def _base_results(**overrides):
    base = {
        "target_rps": 2000,
        "actual_rps": 2000.0,
        "runner_state": "ok",
        "hung_worker_ids": [],
        "sdk_pipeline": {
            "total_items_dropped": 0,
            "total_export_failures": 0,
        },
        "collector_pipeline": {
            "total_send_failed_delta": 0,
            "total_sent_delta": 100000,
        },
    }
    base.update(overrides)
    return base


def test_validity_gate_strict_rps_tolerance_is_one():
    """Issue F: ``RPS_TOLERANCE`` must be 1.0 to honour the AC's strict
    enforcement requirement."""
    assert RPS_TOLERANCE == 1.0


def test_validity_gate_rps_below_target_fails():
    """Issue F: actual=1999 vs target=2000 must trip the gate."""
    valid, failed = _measurement_validity(_base_results(actual_rps=1999.0))
    assert not valid
    assert any("Actual RPS" in msg for msg in failed)


def test_validity_gate_rps_at_target_passes():
    valid, failed = _measurement_validity(_base_results(actual_rps=2000.0))
    assert valid, f"expected pass, got gates: {failed}"


def test_validity_gate_negative_send_failed_fails():
    """Issue B: a negative send_failed delta means the Collector restarted
    and reset its counters mid-run. Must fail the gate (was silently passing)."""
    results = _base_results(
        collector_pipeline={"total_send_failed_delta": -50, "total_sent_delta": 100000},
    )
    valid, failed = _measurement_validity(results)
    assert not valid
    assert any("send_failed" in msg and "negative" in msg.lower() for msg in failed)


def test_validity_gate_negative_sent_delta_fails():
    """Issue B (companion): a negative ``total_sent_delta`` is also a restart
    symptom and must trip the gate."""
    results = _base_results(
        collector_pipeline={"total_send_failed_delta": 0, "total_sent_delta": -1000},
    )
    valid, failed = _measurement_validity(results)
    assert not valid
    assert any("counters went backwards" in msg for msg in failed)


def test_validity_gate_missing_target_rps_fails():
    """Issue E: target_rps missing from the JSON must NOT silently skip the
    RPS check — it must fail open is the wrong default."""
    results = _base_results()
    results.pop("target_rps")
    valid, failed = _measurement_validity(results)
    assert not valid
    assert any("target_rps not recorded" in msg for msg in failed)


def test_validity_gate_zero_target_rps_fails():
    """Issue E variant: a zero target must also fail rather than passing through."""
    valid, failed = _measurement_validity(_base_results(target_rps=0))
    assert not valid
    assert any("target_rps not recorded" in msg for msg in failed)


def test_validity_gate_runner_state_hung_fails():
    """Issue H: a hung worker is reported as runner_state != 'ok' — the gate
    must trip so the report renders INCONCLUSIVE."""
    results = _base_results(runner_state="worker_hung", hung_worker_ids=[2])
    valid, failed = _measurement_validity(results)
    assert not valid
    assert any("Runner state" in msg for msg in failed)


# ---------------------------------------------------------------------------
# INCONCLUSIVE stub (Issue K)
# ---------------------------------------------------------------------------


def test_render_inconclusive_stub_emits_markdown(tmp_path: Path):
    target = tmp_path / "report.md"
    render_inconclusive_stub(target, "results JSON missing or invalid: foo.json")
    assert target.exists()
    body = target.read_text()
    assert "INCONCLUSIVE" in body
    assert "results JSON missing or invalid" in body
    assert "Story 6-39" in body


# ---------------------------------------------------------------------------
# collector_monitor (Issue A)
# ---------------------------------------------------------------------------


_PROMETHEUS_FIXTURE = """\
# HELP otelcol_receiver_accepted_metric_points Number of metric points successfully pushed into the pipeline.
# TYPE otelcol_receiver_accepted_metric_points counter
otelcol_receiver_accepted_metric_points{receiver="otlp",service_name="otelcol"} 12345
otelcol_receiver_accepted_metric_points{receiver="otlp",service_name="otelcol-2"} 5
# HELP otelcol_exporter_sent_metric_points Number of metric points successfully sent.
# TYPE otelcol_exporter_sent_metric_points counter
otelcol_exporter_sent_metric_points{exporter="googlecloud"} 6789
# HELP otelcol_processor_batch_batch_send_size Histogram of batch send sizes
# TYPE otelcol_processor_batch_batch_send_size histogram
otelcol_processor_batch_batch_send_size_bucket{le="10"} 1
otelcol_processor_batch_batch_send_size_bucket{le="+Inf"} 100
otelcol_processor_batch_batch_send_size_count 100
otelcol_processor_batch_batch_send_size_sum 9876
# HELP process_resident_memory_bytes Resident memory size in bytes.
# TYPE process_resident_memory_bytes gauge
process_resident_memory_bytes 1.234e+08
"""


def test_collector_monitor_parses_real_prometheus_text(monkeypatch):
    """Issue A: parser-based scrape must return correct values, including for
    metrics without labels (regex with ``\\{[^}]*\\}`` silently returned 0.0
    for ``process_resident_memory_bytes``)."""
    from tests.performance.collector_monitor import CollectorMonitor

    monitor = CollectorMonitor()

    fake_response = MagicMock()
    fake_response.text = _PROMETHEUS_FIXTURE
    fake_response.raise_for_status = MagicMock()

    monkeypatch.setattr(
        "tests.performance.collector_monitor.requests.get",
        lambda *a, **kw: fake_response,
    )

    metrics = monitor.scrape_metrics()

    # Sums across all label-set permutations.
    assert metrics["receiver_accepted_metric_points"] == 12350.0
    assert metrics["exporter_sent_metric_points"] == 6789.0
    assert metrics["batch_send_size_count"] == 100.0
    assert metrics["batch_send_size_sum"] == 9876.0
    # The unlabelled gauge must still be parsed correctly — this is what the
    # old regex got wrong because it required ``\{[^}]*\}``.
    assert metrics["process_resident_memory_bytes"] == pytest.approx(1.234e8)


# ---------------------------------------------------------------------------
# Scenarios captures buffer_stats pre-shutdown (Issue I)
# ---------------------------------------------------------------------------


def test_scenarios_captures_buffer_stats_before_shutdown(monkeypatch):
    """Issue I: ``buffer_stats()`` must be invoked BEFORE ``shutdown()`` so
    drops aren't masked by the flush+reset that ``shutdown()`` performs."""
    import tests.performance.load_test_scenarios as lts

    call_order: list = []

    class _FakeClient:
        def __init__(self, *args, **kwargs):
            pass

        def record_prediction(self, **kwargs):
            return None

        def buffer_stats(self):
            call_order.append("buffer_stats")
            return {
                "per_signal_stats": {
                    "metrics": {"items_dropped": 7},
                }
            }

        def shutdown(self):
            call_order.append("shutdown")

    monkeypatch.setattr(lts, "MCAClient", _FakeClient)

    # Tiny scenario so the test runs in a fraction of a second.
    result = lts.run_load_scenario(
        scenario_name="unit_pre_shutdown",
        rps_schedule=[(0.05, 100)],
        collector_endpoint="http://localhost:4318",
        workers_per_phase=1,
    )

    assert call_order, "fake client was not exercised"
    bs_idx = call_order.index("buffer_stats")
    sd_idx = call_order.index("shutdown")
    assert bs_idx < sd_idx, "buffer_stats() must be called before shutdown() — Issue I regression"
    # Drop count from the snapshot must propagate to the scenario result.
    assert result["dropped_count"] == 7


# ---------------------------------------------------------------------------
# JSON validation in runner (Issue K — bash + report-writer integration)
# ---------------------------------------------------------------------------


def test_report_writer_stub_mode_via_argparse(tmp_path: Path, monkeypatch):
    """Drive the report writer's main() through its stub mode the same way
    the bash runner invokes it."""
    from tests.performance import load_test_2000rps_report as report_mod

    target = tmp_path / "stub.md"
    rc = report_mod.main(
        argv=[
            "--emit-inconclusive-stub",
            "--report-path",
            str(target),
            "--reason",
            "results JSON missing or invalid: dummy.json",
        ]
    )
    assert rc == 0
    body = target.read_text()
    assert "INCONCLUSIVE" in body
    assert "dummy.json" in body
