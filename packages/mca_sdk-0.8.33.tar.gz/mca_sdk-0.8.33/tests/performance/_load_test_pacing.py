# Shared pacing loop for the 6-39 (2000 rps multi-threaded driver) and 6-8
# (4-scenario sweep) load tests. Single source of truth so the two tracks can't
# drift on the same correctness fixes (error-latency recording, pacing-debt
# reset). Importers wrap this loop with their own metric collection.

from __future__ import annotations

import threading
import time
from typing import Any, Callable, Dict, List, Optional, Sequence


def run_paced_worker(
    worker_id: int,
    total_workers: int,
    request_fn: Callable[[Optional[Dict[str, Any]]], None],
    payload_pool: Sequence[Optional[Dict[str, Any]]],
    per_worker_interval_s: float,
    end_at: float,
    latencies_us: List[float],
    latencies_lock: threading.Lock,
    error_counter: List[int],
    request_timestamps: Optional[List[float]] = None,
    timestamps_lock: Optional[threading.Lock] = None,
) -> int:
    """Run one worker's pacing loop. Returns its request count.

    Each worker tracks its own ``next_tick`` so sleep jitter doesn't cascade.
    On per-worker interval >= ~2ms ``time.sleep`` precision is sufficient on
    Linux; no busy-spin required.

    Two correctness invariants enforced here:

    1. Errors record latency too. Requests that raise still append the elapsed
       time to ``latencies_us`` so p95/p99 reflect timeout/error tails. Skipping
       them would let the SLO pass on fraudulent data.
    2. Pacing debt is bounded. If a worker falls more than one full interval
       behind (e.g., a long GC pause or SDK call), it resets ``next_tick`` to
       ``perf_counter()`` instead of firing a burst of catch-up requests. That
       prevents micro-bursts that distort the target RPS.
    """
    local_latencies: List[float] = []
    local_timestamps: List[float] = []
    local_count = 0
    local_errors = 0
    pool_size = max(1, len(payload_pool))
    next_tick = time.perf_counter()
    # Stagger worker starts across the first interval so wake-ups stay spread.
    next_tick += (worker_id * per_worker_interval_s) / max(1, total_workers)
    while time.time() < end_at:
        # Alternate small (no extras) and medium payloads. Even local_count -> small.
        use_medium = (local_count & 1) == 1
        payload = payload_pool[(worker_id + local_count) % pool_size] if use_medium else None
        if request_timestamps is not None:
            local_timestamps.append(time.time())
        req_start_ns = time.perf_counter_ns()
        try:
            request_fn(payload)
        except Exception:
            req_end_ns = time.perf_counter_ns()
            local_latencies.append((req_end_ns - req_start_ns) / 1000.0)
            local_errors += 1
            local_count += 1
            next_tick += per_worker_interval_s
            # Fall through to pacing logic below.
        else:
            req_end_ns = time.perf_counter_ns()
            local_latencies.append((req_end_ns - req_start_ns) / 1000.0)
            local_count += 1
            next_tick += per_worker_interval_s

        now = time.perf_counter()
        remaining = next_tick - now
        if remaining > 0:
            time.sleep(remaining)
        elif remaining < -per_worker_interval_s:
            # More than one full interval behind: reset to "now" so we don't
            # fire a burst of catch-up requests once we recover.
            next_tick = now

    with latencies_lock:
        latencies_us.extend(local_latencies)
        error_counter[0] += local_errors
    if request_timestamps is not None and timestamps_lock is not None:
        with timestamps_lock:
            request_timestamps.extend(local_timestamps)
    return local_count
