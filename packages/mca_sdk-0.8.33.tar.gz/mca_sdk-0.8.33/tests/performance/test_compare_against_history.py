"""Tests for compare_against_history helper (Story 6-8 regression alerting)."""

import json
import subprocess
import sys
from pathlib import Path

import pytest

HELPER = Path(__file__).parent / "compare_against_history.py"


def _write_summary(path: Path, scenarios: list, min_completeness: float = 100.0) -> None:
    payload = {
        "generated": "2026-05-11T10:00:00",
        "timestamp_slug": "20260511_100000",
        "scenarios": scenarios,
        "min_completeness_percent": min_completeness,
        "collector_memory_stable": True,
    }
    path.write_text(json.dumps(payload))


def _write_history(path: Path, entries: list) -> None:
    with open(path, "w") as f:
        for entry in entries:
            f.write(json.dumps(entry) + "\n")


def _run(current: Path, history: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        [
            sys.executable,
            str(HELPER),
            "--current",
            str(current),
            "--history",
            str(history),
        ],
        capture_output=True,
        text=True,
    )


def test_exits_zero_when_no_history_exists(tmp_path):
    current = tmp_path / "summary.json"
    _write_summary(current, [{"scenario": "Constant Load", "p95_ms": 5.0}])

    result = _run(current, tmp_path / "missing.jsonl")

    assert result.returncode == 0, result.stderr
    assert "no history" in result.stdout.lower()


def test_exits_zero_when_p95_within_tolerance(tmp_path):
    history = tmp_path / "summary.jsonl"
    _write_history(
        history,
        [
            {"scenarios": [{"scenario": "Constant Load", "p95_ms": 5.0}]},
            {"scenarios": [{"scenario": "Constant Load", "p95_ms": 5.2}]},
            {"scenarios": [{"scenario": "Constant Load", "p95_ms": 4.8}]},
        ],
    )
    current = tmp_path / "summary.json"
    _write_summary(current, [{"scenario": "Constant Load", "p95_ms": 5.5}])

    result = _run(current, history)

    assert result.returncode == 0, result.stderr


def test_exits_nonzero_when_p95_regresses_more_than_twenty_percent(tmp_path):
    history = tmp_path / "summary.jsonl"
    _write_history(
        history,
        [
            {"scenarios": [{"scenario": "Constant Load", "p95_ms": 5.0}]},
            {"scenarios": [{"scenario": "Constant Load", "p95_ms": 5.0}]},
            {"scenarios": [{"scenario": "Constant Load", "p95_ms": 5.0}]},
        ],
    )
    current = tmp_path / "summary.json"
    _write_summary(current, [{"scenario": "Constant Load", "p95_ms": 10.0}])

    result = _run(current, history)

    assert result.returncode != 0
    assert "regression" in (result.stdout + result.stderr).lower()


def test_exits_nonzero_when_completeness_below_threshold(tmp_path):
    history = tmp_path / "summary.jsonl"
    _write_history(
        history,
        [{"scenarios": [{"scenario": "Constant Load", "p95_ms": 5.0}]}],
    )
    current = tmp_path / "summary.json"
    _write_summary(
        current,
        [{"scenario": "Constant Load", "p95_ms": 5.0}],
        min_completeness=97.0,
    )

    result = _run(current, history)

    assert result.returncode != 0
    assert "completeness" in (result.stdout + result.stderr).lower()


def test_append_flag_writes_current_summary_to_history(tmp_path):
    history = tmp_path / "summary.jsonl"
    history.touch()
    current = tmp_path / "summary.json"
    _write_summary(current, [{"scenario": "Constant Load", "p95_ms": 5.0}])

    result = subprocess.run(
        [
            sys.executable,
            str(HELPER),
            "--current",
            str(current),
            "--history",
            str(history),
            "--append",
        ],
        capture_output=True,
        text=True,
    )

    assert result.returncode == 0, result.stderr
    assert history.read_text().strip(), "history was not appended to"
