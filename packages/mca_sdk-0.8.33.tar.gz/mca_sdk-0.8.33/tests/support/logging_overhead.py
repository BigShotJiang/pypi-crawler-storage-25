# Predicate that decides whether a profiled cProfile frame belongs to the
# Python stdlib `logging` package. Used by the logging-overhead SLO test
# to attribute cumulative time. Lives in tests/support so that both
# tests/performance/test_performance_slo.py (caller) and
# tests/unit/test_logging_overhead_filter.py (regression suite) can import
# it without one test domain depending on another.
import logging as _stdlib_logging
import os.path
from typing import Optional


def _canonicalize(path: str) -> str:
    """Lower-case and unify separators so paths emitted with mixed `/` and `\\`
    (a real cProfile quirk on Windows) compare correctly on any host OS.
    """
    return path.replace("\\", "/").lower()


def _default_stdlib_logging_dir() -> str:
    return os.path.dirname(_stdlib_logging.__file__)


def _default_stdlib_logging_file() -> str:
    return _stdlib_logging.__file__


# Snapshot at import time so the predicate is constant for a given interpreter run.
_STDLIB_LOGGING_DIR = _default_stdlib_logging_dir()
_STDLIB_LOGGING_FILE = _default_stdlib_logging_file()


def is_stdlib_logging_frame(
    filename: str,
    *,
    stdlib_dir: Optional[str] = None,
    stdlib_file: Optional[str] = None,
) -> bool:
    """Return True iff a cProfile filename names a frame inside the stdlib logging package.

    Identifies the stdlib logging package via Python introspection
    (``logging.__file__``), not by substring matching the literal word
    ``logging`` in the path. This avoids false positives on user directories
    or scripts named ``logging`` (for example ``/opt/app/logging/main.py`` or
    ``/app/utils/logging.py``).

    Both inputs are canonicalized to a lower-case forward-slash form before
    comparison, so cProfile records emitted with mixed ``/`` and ``\\`` (a
    documented Windows quirk) compare correctly regardless of host OS.

    Args:
        filename: The ``co_filename`` attribute of a profiled frame.
        stdlib_dir: Override for the stdlib logging package directory. Tests
            inject a synthetic path here to exercise the predicate without
            depending on the runtime interpreter's installation layout.
        stdlib_file: Override for the stdlib logging single-file install path.
            Some vendored Python builds ship ``logging`` as a flat
            ``logging.py`` instead of a package directory.

    Returns:
        True if ``filename`` is the stdlib logging single-file install OR
        lives strictly inside the stdlib logging package directory tree.
        False otherwise, including for empty filenames and cProfile pseudo-paths
        such as ``<frozen importlib._bootstrap>``.
    """
    if not filename:
        return False
    if filename.startswith("<") and filename.endswith(">"):
        return False

    sd = stdlib_dir if stdlib_dir is not None else _STDLIB_LOGGING_DIR
    sf = stdlib_file if stdlib_file is not None else _STDLIB_LOGGING_FILE

    name_canon = _canonicalize(filename)
    file_canon = _canonicalize(sf)
    dir_canon = _canonicalize(sd).rstrip("/")

    if name_canon == file_canon:
        return True

    return name_canon.startswith(dir_canon + "/")
