"""Security regression tests for story 6-32 (secret masking in attributes).

Ensures that credential material passed through ``**attributes`` to
``MCAClient.record_prediction`` is redacted before it can reach:

  - OTel span attributes (via ``TelemetryAttributeValidator.validate``),
  - the HIPAA audit-log extras emitted off-thread by ``_enqueue_audit_fast``.

Observation strategy (aligned with ``tests/security/test_attribute_phi_leakage.py``):
the audit logger has ``propagate=False`` (story 6-42), so ``caplog`` cannot
see audit records on its own. We attach a spy to ``client._otel_handler.emit``
so the test sees the exact ``LogRecord`` that would have shipped via OTLP.
"""

import logging
import os
import pathlib
import threading
import time
from unittest.mock import patch

import pytest

from mca_sdk.core.client import MCAClient
from mca_sdk.security.secret_filter import _reset_warned_keys


def _drain(client, seen, min_count=1, deadline_s=3.0):
    deadline = time.time() + deadline_s
    while time.time() < deadline and len(seen) < min_count:
        time.sleep(0.02)


class TestSecretMasking:
    @pytest.fixture(autouse=True)
    def _reset_warning_dedup(self):
        """Reset the warning deduplication set before each test."""
        _reset_warned_keys()

    @pytest.fixture
    def client(self):
        os.environ.pop("MCA_DISABLE_SECRET_FILTER", None)
        os.environ.pop("MCA_DISABLE_PHI_FILTER", None)
        c = MCAClient(
            service_name=f"secret-test-{threading.get_ident()}",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )
        yield c
        c.shutdown()

    def _capture_audit(self, client):
        """Return (seen_records, patch_cm). Caller uses the cm with ``with``."""
        seen = []
        original_emit = client._otel_handler.emit

        def capture(record):
            seen.append(record)
            return original_emit(record)

        return seen, patch.object(client._otel_handler, "emit", side_effect=capture)

    @staticmethod
    def _flatten(record):
        """Concatenate every string-typed field on a LogRecord into one blob.

        Used to assert that a secret *substring* does not appear anywhere on
        the emitted record, regardless of which extra attribute it landed in.
        """
        parts = []
        for v in record.__dict__.values():
            if isinstance(v, str):
                parts.append(v)
            elif isinstance(v, (int, float, bool)):
                parts.append(str(v))
        return " ".join(parts)

    def test_testing_module_not_in_prod_import_graph(self):
        """Assert _testing.py is unused in prod import graph.

        Resolves the mca_sdk package directory from its importable location
        so the check cannot trivially pass when pytest runs from a different
        CWD than the repo root. Matches only real Python ``import`` or
        ``from ... import`` statements, not bare mentions of the module name
        that can appear in docstrings (which are not executable imports).
        """
        import mca_sdk
        import re as _re

        pkg_dir = pathlib.Path(mca_sdk.__file__).parent
        assert pkg_dir.is_dir(), f"mca_sdk package directory not found: {pkg_dir}"

        # Match only real import statements. A line like:
        #   - Testing: Use `reset_secret_manager_for_testing()` from mca_sdk.security._testing
        # is a docstring artifact, not an import, and must not be flagged.
        import_re = _re.compile(
            r"^\s*(?:import\s+\S*_testing"
            r"|from\s+(?:\.|mca_sdk\.security)\._testing\s+import"
            r"|from\s+mca_sdk\.security\s+import\s+_testing)\b"
        )

        offenders = []
        for py_file in pkg_dir.rglob("*.py"):
            if py_file.name == "_testing.py":
                continue
            try:
                text = py_file.read_text(encoding="utf-8")
            except Exception:
                continue
            for lineno, line in enumerate(text.splitlines(), start=1):
                if import_re.match(line):
                    offenders.append(f"{py_file}:{lineno}: {line.strip()}")

        assert not offenders, "Production code must not import _testing. Offenders:\n" + "\n".join(
            offenders
        )

    def test_token_values_never_appear_in_log_records(self, client):
        """AC #1: neither api_token nor password values reach the audit log.

        Verifies the prediction_id is still present (sanity: the capture
        works) while the secret values are redacted.
        """
        seen, cm = self._capture_audit(client)
        with cm:
            with client.trace("test-span"):
                client.record_prediction(
                    latency=0.5,
                    prediction_id="pred-123",
                    api_token="sk-1234567890abcdef",
                    password="super-secret-password",
                )
            _drain(client, seen, min_count=1)

        audit = [r for r in seen if r.name.endswith(".audit")]
        assert audit, "audit record never reached OTel handler"
        rec = audit[-1]
        log_text = self._flatten(rec)

        assert "pred-123" in log_text, "Prediction ID should be logged"
        assert "sk-1234567890abcdef" not in log_text, "API token leaked into logs"
        assert "super-secret-password" not in log_text, "Password leaked into logs"

    def test_key_pattern_match_redacts_value(self, client):
        """AC #2: key-name match triggers redaction regardless of value shape.

        ``api_token`` and ``password`` are not secret-shape values on their
        own (they are short alphanumeric strings); the key name alone must
        drive redaction.
        """
        seen, cm = self._capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-k1",
                api_token="short-opaque-value",
                password="p@ssw0rd",
                client_secret="whatever",
                bearer_authorization="any-bearer-string",
                aws_access_key_id="AKIAIOSFODNN7EXAMPLE",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("api_token") == "[REDACTED:SECRET]"
        assert rec.__dict__.get("password") == "[REDACTED:SECRET]"
        assert rec.__dict__.get("client_secret") == "[REDACTED:SECRET]"
        assert rec.__dict__.get("bearer_authorization") == "[REDACTED:SECRET]"
        assert rec.__dict__.get("aws_access_key_id") == "[REDACTED:SECRET]"

    def test_value_pattern_match_sk_prefix(self, client):
        """AC #3: an ``sk-*`` OpenAI-style token is redacted even when the
        attribute key name is benign (``note``)."""
        seen, cm = self._capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-v1",
                note="sk-abcdefghijklmnopqrstuvwxyz0123456789ABCD",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("note") == "[REDACTED:SECRET]"

    def test_value_pattern_match_jwt(self, client):
        """AC #3: a JWT value is redacted when placed in a benign-named attribute."""
        jwt = (
            "eyJhbGciOiJIUzI1NiJ9"
            ".eyJzdWIiOiIxMjM0NTY3ODkwIn0"
            ".SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        )
        seen, cm = self._capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-j1",
                annotation=jwt,
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        flat = self._flatten(rec)
        assert jwt not in flat, "JWT payload leaked despite value-shape filter"

    def test_value_pattern_match_pem(self, client):
        """AC #3: PEM private-key block is redacted when placed in a
        benign-named attribute."""
        pem_blob = (
            "context-header "
            "-----BEGIN RSA PRIVATE KEY-----\nMIIEvQIBADANBgkq\n-----END RSA PRIVATE KEY-----"
        )
        seen, cm = self._capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-p1",
                debug_info=pem_blob,
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        flat = self._flatten(rec)
        assert "BEGIN RSA PRIVATE KEY" not in flat, "PEM header leaked"
        assert "MIIEvQIBADANBgkq" not in flat, "PEM body leaked"

    def test_benign_attributes_preserved(self, client):
        """AC #4: documented non-sensitive identifiers pass through unchanged.

        ``model_version`` and similar reserved resource-attribute keys are
        scrubbed from metric attributes by ``_filter_reserved_attributes``
        well before the secret filter sees them, so we exercise non-reserved
        operational keys here to isolate the secret-filter contract.
        """
        seen, cm = self._capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-b1",
                build_id="v2.3.4",
                experiment="arm-control",
                feature_flag_cohort="treatment-a",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("prediction_id") == "pred-b1"
        assert rec.__dict__.get("build_id") == "v2.3.4"
        assert rec.__dict__.get("experiment") == "arm-control"
        assert rec.__dict__.get("feature_flag_cohort") == "treatment-a"

    def test_secret_filter_runs_before_phi_filter(self, client):
        """Design decision: secret filter runs first. A credential-keyed
        attribute whose value *also* contains a PHI pattern is replaced
        wholesale with ``[REDACTED:SECRET]``, not re-redacted by the PHI
        filter into a ``[REDACTED:SSN]`` marker."""
        seen, cm = self._capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-o1",
                api_token="leaked-ssn-123-45-6789-in-token",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("api_token") == "[REDACTED:SECRET]"

    def test_disable_flag_bypasses_filter(self, monkeypatch):
        """Opt-out env var honored for legitimate negative tests."""
        monkeypatch.setenv("MCA_DISABLE_SECRET_FILTER", "true")
        client = MCAClient(
            service_name="secret-bypass-test",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )
        try:
            seen, cm = self._capture_audit(client)
            with cm:
                client.record_prediction(
                    latency=0.01,
                    prediction_id="pred-d1",
                    api_token="sk-1234567890abcdef",
                )
                _drain(client, seen, min_count=1)

            rec = [r for r in seen if r.name.endswith(".audit")][-1]
            assert rec.__dict__.get("api_token") == "sk-1234567890abcdef"
        finally:
            client.shutdown()

    def test_redaction_emits_warning_naming_key_only(self, caplog):
        """Design decision: on redaction, SDK emits a warning naming the key
        but never the value, so callers learn they are leaking without the
        warning itself becoming a leak vector."""
        from mca_sdk.security.secret_filter import filter_attributes

        caplog.set_level(logging.WARNING, logger="mca_sdk.security.secret_filter")
        filter_attributes({"api_token": "sk-1234567890abcdef", "benign": "ok"})

        warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
        assert warnings, "expected a WARNING on redaction"
        blob = " ".join(r.getMessage() for r in warnings)
        assert "api_token" in blob, "warning should name the redacted key"
        assert "sk-1234567890abcdef" not in blob, "warning must not echo the value"

    # --- Regression tests for review findings (2026-05-07) ---

    def test_nested_dict_key_redaction(self, client):
        """Review finding #1: nested dictionary keys must be checked.

        ``{"user_context": {"password": "super-secret-password"}}`` must
        redact the nested ``password`` key even though ``user_context`` is
        benign and the value is too short for value-shape matching.
        """
        seen, cm = self._capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-n1",
                user_context={"password": "super-secret-password", "role": "admin"},
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        # The user_context dict should have its nested password redacted
        ctx = rec.__dict__.get("user_context")
        # Could be stringified by the validator; check both dict and string forms
        if isinstance(ctx, dict):
            assert ctx.get("password") == "[REDACTED:SECRET]"
            assert ctx.get("role") == "admin"
        else:
            # Stringified
            assert "super-secret-password" not in str(ctx)

    def test_nested_dict_key_redaction_direct(self):
        """Review finding #1 (direct unit test): verify filter_attributes
        recurses into nested dicts and checks keys."""
        from mca_sdk.security.secret_filter import filter_attributes

        result = filter_attributes(
            {
                "context": {"api_token": "short-val", "safe_key": "safe_val"},
            }
        )
        nested = result["context"]
        assert nested["api_token"] == "[REDACTED:SECRET]"
        assert nested["safe_key"] == "safe_val"

    def test_deeply_nested_dict_key_redaction(self):
        """Review finding #1: multi-level nesting."""
        from mca_sdk.security.secret_filter import filter_attributes

        result = filter_attributes(
            {
                "outer": {"middle": {"password": "deep-secret", "ok": "fine"}},
            }
        )
        assert result["outer"]["middle"]["password"] == "[REDACTED:SECRET]"
        assert result["outer"]["middle"]["ok"] == "fine"

    def test_substring_replacement_preserves_context(self):
        """Review finding #2: value-shape match does substring replacement,
        not wholesale string destruction."""
        from mca_sdk.security.secret_filter import filter_attributes

        long_query = (
            "SELECT * FROM users WHERE token = 'sk-abcdefghijklmnopqrstuvwxyz0123456789ABCD' "
            "AND status = 'active'"
        )
        result = filter_attributes({"sql_debug": long_query})
        val = result["sql_debug"]
        # The sk-* token is redacted
        assert "sk-abcdefghijklmnopqrstuvwxyz0123456789ABCD" not in val
        # The surrounding SQL context is preserved
        assert "SELECT * FROM users WHERE token = '" in val
        assert "AND status = 'active'" in val
        assert "[REDACTED:SECRET]" in val

    def test_jwt_substring_replacement_preserves_context(self):
        """Review finding #2: JWT in a larger string preserves surrounding text."""
        from mca_sdk.security.secret_filter import filter_attributes

        jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        text = f"Authorization header was: Bearer {jwt} for request /api/v1/models"
        result = filter_attributes({"http_log": text})
        val = result["http_log"]
        assert jwt not in val
        assert "Authorization header was: Bearer " in val
        assert " for request /api/v1/models" in val

    def test_pem_full_block_redacted(self):
        """Review finding #3: entire PEM block (header through footer) is
        redacted, not just the header line."""
        from mca_sdk.security.secret_filter import filter_attributes

        pem = (
            "-----BEGIN RSA PRIVATE KEY-----\n"
            "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC7\n"
            "7VVVVVVbase64encodedprivatekeydata\n"
            "-----END RSA PRIVATE KEY-----"
        )
        context_with_pem = f"Debug dump: {pem} --- end of dump"
        result = filter_attributes({"debug_blob": context_with_pem})
        val = result["debug_blob"]
        # PEM body must not leak
        assert "MIIEvQIBADANBgkq" not in val
        assert "base64encodedprivatekeydata" not in val
        assert "BEGIN RSA PRIVATE KEY" not in val
        # Context around the PEM is preserved
        assert "Debug dump: " in val
        assert "--- end of dump" in val

    def test_custom_object_serialization_leak(self):
        """Review finding #4: credentials in custom objects are caught via
        __dict__ inspection or string serialization."""
        from mca_sdk.security.secret_filter import filter_attributes

        class CredentialHolder:
            def __init__(self):
                self.api_token = "sk-leakedtokenvalue12345678901234567890"
                self.name = "safe-value"

        result = filter_attributes({"config_obj": CredentialHolder()})
        val = result["config_obj"]
        # The leaked token must not survive
        if isinstance(val, dict):
            assert "sk-leakedtokenvalue12345678901234567890" not in str(val)
            assert val.get("api_token") == "[REDACTED:SECRET]"
        else:
            assert "sk-leakedtokenvalue12345678901234567890" not in str(val)

    def test_custom_object_str_repr_leak(self):
        """Review finding #4: objects whose __str__ contains credentials."""
        from mca_sdk.security.secret_filter import filter_attributes

        class TokenWrapper:
            def __init__(self, token):
                self._token = token

            def __str__(self):
                return f"TokenWrapper(token={self._token})"

        result = filter_attributes(
            {
                "wrapper": TokenWrapper("sk-abcdefghijklmnopqrstuvwxyz0123456789ABCD"),
            }
        )
        val = str(result["wrapper"])
        assert "sk-abcdefghijklmnopqrstuvwxyz0123456789ABCD" not in val

    def test_allowlist_case_insensitive(self):
        """Review finding #6: allowlist check must be case-insensitive."""
        from mca_sdk.security.secret_filter import filter_attributes

        # These should NOT be redacted despite containing "token" or "id"
        result = filter_attributes(
            {
                "Prediction_ID": "pred-123",
                "SESSION_ID": "sess-456",
            }
        )
        assert result["Prediction_ID"] == "pred-123"
        assert result["SESSION_ID"] == "sess-456"

    def test_warning_deduplication(self, caplog):
        """Review finding #7: repeated redaction of the same key only logs
        a warning once per process lifecycle."""
        from mca_sdk.security.secret_filter import filter_attributes

        caplog.set_level(logging.WARNING, logger="mca_sdk.security.secret_filter")

        # First call should warn
        filter_attributes({"api_token": "value1"})
        first_count = len([r for r in caplog.records if r.levelno == logging.WARNING])
        assert first_count == 1

        # Second call with same key should NOT produce another warning
        filter_attributes({"api_token": "value2"})
        second_count = len([r for r in caplog.records if r.levelno == logging.WARNING])
        assert second_count == 1, "Duplicate warning emitted for same key"

        # Different key should produce a new warning
        filter_attributes({"password": "value3"})
        third_count = len([r for r in caplog.records if r.levelno == logging.WARNING])
        assert third_count == 2

    def test_base64_padding_in_token(self):
        """Review finding #9: tokens ending with base64 padding characters
        (``=``) are fully captured by the regex."""
        from mca_sdk.security.secret_filter import filter_attributes

        # sk-token with padding
        padded_token = "sk-abcdefghijklmnopqrstuvwxyz012345678=="
        result = filter_attributes({"note": padded_token})
        assert padded_token not in result["note"]
        assert "[REDACTED:SECRET]" in result["note"]

    def test_jwt_with_padding(self):
        """Review finding #9: JWT segments with base64 padding."""
        from mca_sdk.security.secret_filter import filter_attributes

        jwt_padded = (
            "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkw==.SflKxwRJSMeKKF2QT4fwpMeJf36POk6y=="
        )
        result = filter_attributes({"data": jwt_padded})
        assert jwt_padded not in result["data"]
        assert "[REDACTED:SECRET]" in result["data"]

    def test_circular_reference_does_not_crash(self):
        """Circular references must not exhaust the stack."""
        from mca_sdk.security.secret_filter import filter_attributes

        d: dict = {"safe": "value"}
        d["self"] = d  # type: ignore[assignment]
        # Should not raise RecursionError
        result = filter_attributes({"nested": d})
        # The filter returns *something* without crashing
        assert result is not None
