"""Security tests documenting that the SDK does NOT redact PHI by default.

PHI sanitization is the caller's responsibility per CLAUDE.md
("PHI Masking is Application Responsibility"). The defense-in-depth
filter introduced by story 6-31 is now disabled by default; this file
exists to make the resulting leak surface explicit and auditable.

Each test in :class:`TestAttributePHILeakageWhenFilterDisabled` is
intentionally named to call out what leaks where, so a reviewer reading
the test names alone can see exactly what the SDK passes through:
SSN/MRN/DOB strings reach the OTel metric attribute dict, the active
span attributes, the audit-log extras, and the synchronous error log.

:class:`TestPHIFilterOptInRedaction` covers the opt-in path. When the
caller sets ``MCA_ENABLE_PHI_FILTER=true``, redaction must still fire on
every code path the disabled-by-default tests document as leaking,
including the synchronous ``record_error`` log path.

We observe the audit log by attaching a capture handler to
``<service_name>.audit`` and spying on ``_otel_handler.emit``. The audit
logger has ``propagate=False`` (story 6-42), so ``caplog`` cannot see it.
"""

import logging
import os
import threading
import time
from unittest.mock import patch

import pytest

from mca_sdk.core.client import MCAClient
from mca_sdk.security import phi_filter


def _drain(client, seen, min_count=1, deadline_s=3.0):
    deadline = time.time() + deadline_s
    while time.time() < deadline and len(seen) < min_count:
        time.sleep(0.02)


def _capture_audit(client):
    """Return (seen_records, patch_cm). Caller uses the cm with ``with``."""
    seen = []
    original_emit = client._otel_handler.emit

    def capture(record):
        seen.append(record)
        return original_emit(record)

    return seen, patch.object(client._otel_handler, "emit", side_effect=capture)


class TestAttributePHILeakageWhenFilterDisabled:
    """When the filter is off (default), PHI flows unredacted into telemetry sinks.

    These tests document the leak surface. They MUST fail loudly if a
    future change re-enables the filter by default without updating
    CLAUDE.md and the SDK contract: a green run here means the SDK is
    passing PHI through, which is the documented behavior, but if these
    tests start failing because PHI is being redacted unexpectedly, the
    redaction was added without updating the documented contract.
    """

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.delenv("MCA_ENABLE_PHI_FILTER", raising=False)
        # Re-arm the one-shot disabled-state warning so each test sees a
        # consistent process-scoped state. The warning itself is logged,
        # not raised, so it does not interfere with assertions below.
        phi_filter._reset_disabled_warning_for_tests()
        c = MCAClient(
            service_name=f"phi-test-{threading.get_ident()}",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )
        yield c
        c.shutdown()

    def test_ssn_mrn_dob_leak_into_audit_log_unredacted(self, client):
        seen, cm = _capture_audit(client)
        with cm:
            with client.trace("test-span"):
                client.record_prediction(
                    latency=0.5,
                    prediction_id="pred-123",
                    ssn_val="123-45-6789",
                    mrn_val="MRN123456789",
                    dob_val="01/01/1980",
                )
            _drain(client, seen, min_count=1)

        audit = [r for r in seen if r.name.endswith(".audit")]
        assert audit, "audit record never reached OTel handler"
        rec = audit[-1]
        extras = rec.__dict__

        assert extras.get("ssn_val") == "123-45-6789", "SSN reaches audit log unredacted"
        assert extras.get("mrn_val") == "MRN123456789", "MRN reaches audit log unredacted"
        assert extras.get("dob_val") == "01/01/1980", "DOB reaches audit log unredacted"

    def test_benign_string_preserved(self, client):
        seen, cm = _capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-b1",
                build_id="v2.3.4",
                experiment="arm-control",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("build_id") == "v2.3.4"
        assert rec.__dict__.get("experiment") == "arm-control"

    def test_non_string_attributes_passthrough(self, client):
        seen, cm = _capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-n1",
                score=0.87,
                count=42,
                ok=True,
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("score") == 0.87
        assert rec.__dict__.get("count") == 42
        assert rec.__dict__.get("ok") is True

    def test_nested_input_data_phi_leaks_unredacted(self, client):
        seen, cm = _capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-l1",
                input_data={"row": {"ssn": "123-45-6789", "age": 40}},
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        extras = rec.__dict__

        combined = " ".join(str(v) for v in extras.values())
        assert "123-45-6789" in combined, "nested SSN reaches audit log unredacted"
        assert "[REDACTED:SSN]" not in combined

    def test_space_separated_ssn_leaks_unredacted(self, client):
        seen, cm = _capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-ss1",
                notes="patient 123 45 6789 admitted",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert "123 45 6789" in rec.__dict__.get("notes", "")
        assert "[REDACTED:SSN]" not in rec.__dict__.get("notes", "")

    def test_iso_dob_leaks_unredacted(self, client):
        seen, cm = _capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-iso1",
                dob_val="1980-01-01",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("dob_val") == "1980-01-01"

    def test_lowercase_mrn_leaks_unredacted(self, client):
        seen, cm = _capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-mrn1",
                mrn_val="mrn123456",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("mrn_val") == "mrn123456"

    def test_record_error_leaks_phi_in_message_unredacted(self, client):
        # record_error logs via the standard logger at ERROR; capture via the
        # service logger. The error_message field carries whatever PHI the
        # caller put in the exception text.
        svc_logger = logging.getLogger(client._logger.name)
        captured: list[logging.LogRecord] = []

        class _H(logging.Handler):
            def emit(self, record):
                captured.append(record)

        h = _H(level=logging.ERROR)
        svc_logger.addHandler(h)
        try:
            with client.trace("err-span"):
                client.record_error(
                    error=ValueError("failure for mrn MRN987654"),
                    latency=0.01,
                    prediction_id="pred-e1",
                )
            time.sleep(0.05)
        finally:
            svc_logger.removeHandler(h)

        err_records = [r for r in captured if r.levelno >= logging.ERROR]
        assert err_records, "no error record captured"
        rec = err_records[-1]
        msg = rec.__dict__.get("error_message", "")
        assert "MRN987654" in msg, "PHI in error message reaches the synchronous error log"
        assert "[REDACTED:MRN]" not in msg


class TestPHIFilterOptInRedaction:
    """When the caller sets MCA_ENABLE_PHI_FILTER=true, redaction must fire.

    Mirrors the leak-surface tests in
    :class:`TestAttributePHILeakageWhenFilterDisabled` so that every
    code path documented as leaking by default is also documented to
    redact under the opt-in. If a code path is added to one class
    without a counterpart in the other, that gap should be the first
    thing a reviewer notices.
    """

    @pytest.fixture
    def client(self, monkeypatch):
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.setenv("MCA_ENABLE_PHI_FILTER", "true")
        phi_filter._reset_disabled_warning_for_tests()
        c = MCAClient(
            service_name=f"phi-enabled-{threading.get_ident()}",
            model_id="mdl-001",
            team_name="test-team",
            strict_validation=False,
        )
        yield c
        c.shutdown()

    def test_record_prediction_redacts_phi_in_audit_log(self, client):
        seen, cm = _capture_audit(client)
        with cm:
            client.record_prediction(
                latency=0.01,
                prediction_id="pred-d1",
                ssn_val="123-45-6789",
                mrn_val="MRN987654",
                dob_val="12/31/2000",
            )
            _drain(client, seen, min_count=1)

        rec = [r for r in seen if r.name.endswith(".audit")][-1]
        assert rec.__dict__.get("ssn_val") == "[REDACTED:SSN]"
        assert rec.__dict__.get("mrn_val") == "[REDACTED:MRN]"
        assert rec.__dict__.get("dob_val") == "[REDACTED:DOB]"

    def test_record_error_redacts_phi_in_message(self, client):
        # Mirror of test_record_error_leaks_phi_in_message_unredacted.
        # Closes the audit-coverage gap flagged by review: opt-in must
        # redact on the synchronous error path too, not only the
        # async audit-drain path.
        svc_logger = logging.getLogger(client._logger.name)
        captured: list[logging.LogRecord] = []

        class _H(logging.Handler):
            def emit(self, record):
                captured.append(record)

        h = _H(level=logging.ERROR)
        svc_logger.addHandler(h)
        try:
            with client.trace("err-span"):
                client.record_error(
                    error=ValueError("failure for mrn MRN987654"),
                    latency=0.01,
                    prediction_id="pred-e1",
                )
            time.sleep(0.05)
        finally:
            svc_logger.removeHandler(h)

        err_records = [r for r in captured if r.levelno >= logging.ERROR]
        assert err_records, "no error record captured"
        msg = err_records[-1].__dict__.get("error_message", "")
        assert "MRN987654" not in msg, "opt-in redaction failed on record_error path"
        assert "[REDACTED:MRN]" in msg


class TestStartupDisabledStateWarning:
    """Operators must learn at process start that PHI redaction is off."""

    def test_mcaclient_init_emits_one_shot_warning_when_disabled(self, monkeypatch, caplog):
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.delenv("MCA_ENABLE_PHI_FILTER", raising=False)
        phi_filter._reset_disabled_warning_for_tests()

        with caplog.at_level(logging.WARNING):
            client = MCAClient(
                service_name="phi-warn-test-1",
                model_id="mdl-001",
                team_name="test-team",
                strict_validation=False,
            )
            try:
                msgs = [r.getMessage() for r in caplog.records if r.levelno >= logging.WARNING]
                assert any(
                    "PHI attribute filter is DISABLED" in m and "MCA_ENABLE_PHI_FILTER" in m
                    for m in msgs
                ), f"expected disabled-state warning, got: {msgs!r}"
            finally:
                client.shutdown()

    def test_warning_is_one_shot_per_process(self, monkeypatch, caplog):
        monkeypatch.delenv("MCA_DISABLE_PHI_FILTER", raising=False)
        monkeypatch.delenv("MCA_ENABLE_PHI_FILTER", raising=False)
        phi_filter._reset_disabled_warning_for_tests()

        clients = []
        try:
            with caplog.at_level(logging.WARNING):
                for i in range(3):
                    clients.append(
                        MCAClient(
                            service_name=f"phi-warn-test-rep-{i}",
                            model_id="mdl-001",
                            team_name="test-team",
                            strict_validation=False,
                        )
                    )
            disabled_msgs = [
                r for r in caplog.records if "PHI attribute filter is DISABLED" in r.getMessage()
            ]
            assert len(disabled_msgs) == 1, (
                f"expected exactly one disabled-state warning across 3 clients, "
                f"got {len(disabled_msgs)}"
            )
        finally:
            for c in clients:
                c.shutdown()

    def test_no_warning_when_filter_explicitly_enabled(self, monkeypatch, caplog):
        monkeypatch.setenv("MCA_ENABLE_PHI_FILTER", "true")
        phi_filter._reset_disabled_warning_for_tests()

        with caplog.at_level(logging.WARNING):
            client = MCAClient(
                service_name="phi-warn-test-enabled",
                model_id="mdl-001",
                team_name="test-team",
                strict_validation=False,
            )
            try:
                disabled_msgs = [
                    r
                    for r in caplog.records
                    if "PHI attribute filter is DISABLED" in r.getMessage()
                ]
                assert (
                    disabled_msgs == []
                ), "no disabled-state warning should fire when filter is on"
            finally:
                client.shutdown()
