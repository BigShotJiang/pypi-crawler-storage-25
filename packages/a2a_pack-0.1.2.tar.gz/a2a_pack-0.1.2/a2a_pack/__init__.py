"""a2a-pack — developer SDK + CLI for the a2a cloud platform.

See https://docs.a2acloud.io for the full reference.
"""

# Single source of truth — pyproject.toml reads this via hatch.version.
__version__ = "0.1.2"

from .a2a_client import (
    A2AClient,
    CallResult,
    HttpA2AClient,
    InMemoryA2AClient,
)
from .agent import (
    A2AAgent,
    ParamSpec,
    SkillInputError,
    SkillInvocationError,
    SkillNotFound,
    SkillSpec,
    skill,
)
from .discovery import (
    ControlPlaneDiscovery,
    DiscoveredAgent,
    DiscoveryClient,
    InMemoryDiscovery,
)
from .grants import Grant, GrantInvalid, mint_grant, sign_grant, verify_grant
from .mcp import (
    MCP_PROTOCOL_VERSION,
    MCPServer,
    build_http_app as build_mcp_http_app,
    mount_http as mount_mcp_http,
    skills_to_tools,
)
from .auth import APIKeyAuth, JWTAuth, NoAuth
from .card import AgentCard, SkillCard
from .context import (
    AgentEvent,
    ArtifactRef,
    CancelledByCaller,
    LLMCreds,
    LocalRunContext,
    MissingScopes,
    RunContext,
)
from .runtime import (
    AgentRuntime,
    EgressPolicy,
    Lifecycle,
    LLMProvisioning,
    Pricing,
    Resources,
    Sandbox,
    SkillPolicy,
    State,
)
from .sandbox import (
    ExecResult,
    SandboxClient,
    SandboxHandle,
    SandboxSpec,
    SandboxUnavailable,
)
from .workspace import (
    FileMatch,
    FileType,
    LocalWorkspaceClient,
    LocalWorkspaceView,
    MinIOWorkspaceClient,
    MinIOWorkspaceView,
    WorkspaceAccess,
    WorkspaceClient,
    WorkspaceDenied,
    WorkspaceGrant,
    WorkspaceMode,
    WorkspacePatch,
    WorkspaceView,
)

__all__ = [
    "A2AAgent",
    "A2AClient",
    "APIKeyAuth",
    "AgentCard",
    "AgentEvent",
    "AgentRuntime",
    "ArtifactRef",
    "CallResult",
    "CancelledByCaller",
    "ControlPlaneDiscovery",
    "DiscoveredAgent",
    "DiscoveryClient",
    "EgressPolicy",
    "ExecResult",
    "FileMatch",
    "FileType",
    "Grant",
    "GrantInvalid",
    "HttpA2AClient",
    "InMemoryA2AClient",
    "InMemoryDiscovery",
    "JWTAuth",
    "LLMCreds",
    "LLMProvisioning",
    "Lifecycle",
    "LocalRunContext",
    "MCP_PROTOCOL_VERSION",
    "MCPServer",
    "build_mcp_http_app",
    "mount_mcp_http",
    "skills_to_tools",
    "LocalWorkspaceClient",
    "LocalWorkspaceView",
    "MinIOWorkspaceClient",
    "MinIOWorkspaceView",
    "MissingScopes",
    "NoAuth",
    "ParamSpec",
    "Pricing",
    "Resources",
    "RunContext",
    "Sandbox",
    "mint_grant",
    "sign_grant",
    "verify_grant",
    "SandboxClient",
    "SandboxHandle",
    "SandboxSpec",
    "SandboxUnavailable",
    "SkillCard",
    "SkillInputError",
    "SkillInvocationError",
    "SkillNotFound",
    "SkillPolicy",
    "SkillSpec",
    "State",
    "WorkspaceAccess",
    "WorkspaceClient",
    "WorkspaceDenied",
    "WorkspaceGrant",
    "WorkspaceMode",
    "WorkspacePatch",
    "WorkspaceView",
    "skill",
]
