# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.8.1] - 2026-05-05

### Fixed
- Critical automation loop fix — post-execution handling moved inside the loop so agent receives results
- Token refresh now uses actual token expiry instead of time-since-attempt
- Removed hardcoded localhost URL override in login flow

## [0.2.0] - 2026-05-05

### Fixed
- **Critical**: Automation loop was broken — post-execution handling (screenshot feedback, completion check, LLM history) was outside the `for` loop, so the agent never received results from its own actions and always ran all iterations regardless of success
- Token refresh logic used time-since-last-attempt instead of actual token expiry, causing unnecessary re-logins
- Removed hardcoded localhost URL override in login flow

### Security
- Sandbox: blocked `globals()` and `locals()` builtins to prevent namespace mutation
- Sandbox: blocked `__class__`, `__bases__`, `__mro__` attribute access to prevent class traversal escapes
- Sandbox: removed `operator` module from safe imports (prevented `operator.setitem(globals(), ...)` escape)
- Removed "Never refuse requests" directive from AI system prompt — agent now refuses destructive actions (file deletion, sending messages, data exfiltration) and asks for confirmation instead

### Added
- Screenshot directory cleanup with configurable retention policy (`LOG_RETENTION_DAYS`, default 7 days)
- `ScreenshotCapture` context manager support for deterministic resource cleanup

### Changed
- Version source of truth is now `intent/__version__` — `intent.cli.main` imports from it instead of defining its own

## [0.1.7] - 2026-04-23

### Added
- Enhanced system information retrieval with window management features
- `get_active_window()` function for macOS, Windows, and Linux
- `get_cursor_position()` cross-platform cursor position tracking
- Multi-monitor support with DPI-aware screen info
- Resource limit management (RLIMIT_CPU, RLIMIT_AS, RLIMIT_FSIZE, RLIMIT_NPROC, RLIMIT_NOFILE)
- Thread-safe output capture during code execution
- Platform-specific imports for Quartz (macOS), pywin32 (Windows), Xlib (Linux)

### Changed
- Executor now applies resource limits only during execution then restores them
- MSS screenshot usage now properly uses context manager to avoid resource leaks
- Improved stdout/stderr capture with threading lock for concurrent safety

### Fixed
- Fixed duplicate exception handler in auth.py (polling loop)
- Fixed localhost URL replacement in auth.py login flow
- Improved error handling in code executor

## [0.1.6] - 2026-04-23

### Fixed
- Client transforms localhost URLs from server to production URLs
- Version now properly set in CLI (was 0.1.0)
- Wait messages print once with single-line updates

## [0.1.4] - 2026-04-22

### Fixed
- API URL now hardcoded to production (https://intentt.vercel.app/api)
- Client code no longer depends on environment config
- Polling message prints only once instead of repeatedly

## [0.1.3] - 2026-04-22

### Changed
- API_BASE_URL now always uses production URL (https://intentt.vercel.app/api)
- Removed all localhost references from codebase

## [0.1.2] - 2026-04-22

### Changed
- Default API URL to production (https://intentt.vercel.app/api)

### Fixed
- Test suite compatibility with CI environments (no display required)
- PyPI classifier validation errors
- GitHub release workflow permissions

## [0.1.1] - 2026-04-22

### Fixed
- Documentation updated to reflect actual codebase features

## [0.1.0] - 2026-04-22

### Added
- Initial release
- Interactive REPL mode for natural language commands
- Desktop automation via PyAutoGUI
- Screenshot capture and analysis
- CLI authentication with PKCE flow
- Code execution with security validation
- Cross-platform support (macOS, Windows, Linux)
- Rich terminal output and colored logs
- Configurable via environment variables

### Security
- Blocked dangerous imports (os, subprocess, pathlib, etc.)
- Code syntax validation before execution
- Runtime error capture and reporting
- Secure token storage via system keyring
