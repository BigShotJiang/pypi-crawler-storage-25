"""
Code executor module for safely running generated automation code.
Performs comprehensive validation and executes Python code with error handling.
"""

import ast
import logging
import re
import sys
from datetime import datetime
from io import StringIO
from typing import Tuple, Set, List
import builtins

_HAS_RESOURCE = False
if sys.platform != 'win32':
    try:
        import resource
        _HAS_RESOURCE = True
    except ImportError:
        pass

from intent.core.config import Config

logger = logging.getLogger("intent.debug")


DANGEROUS_PATTERNS = [
    # Code execution
    r"\bexec\(",
    r"\beval\(",
    r"\b__import__\s*\(",
    r"\bcompile\(",
    r"\bbreakpoint\(",
    # System commands
    r"\bos\.system\(",
    r"\bos\.popen\(",
    r"\bos\.exec",
    r"\bos\.spawn",
    r"\bsubprocess\.",
    r"\bsocket\.",
    r"\burllib\.",
    r"\burllib3\.",
    r"\brequests\.",
    r"\bctypes\.",
    r"\bpickle\.",
    r"\bmarshal\.",
    r"\bshelve\b",
    r"\bdbm\b",
    # Attribute access
    r"\bgetattr\(",
    r"\bsetattr\(",
    r"\bdelattr\(",
    r"\b__getattr__\b",
    r"\b__setattr__\b",
    r"\b__delattr__\b",
    # Object introspection
    r"\b__globals__",
    r"\b__code__",
    r"\b__closure__",
    r"\b__builtins__",
    # File operations
    r"\bopen\(",
    r"\bfile\(",
    r"\binput\(",
    # Class/Object creation
    r"\btype\(.+\)",
    r"\bvars\(",
    r"\bmro\(",
    r"\b__subclasses__\(",
    # Namespace escape
    r"\bglobals\(",
    r"\blocals\(",
]


class SecurityValidator(ast.NodeVisitor):
    """AST-based security validator for Python code."""

    def __init__(self):
        self.blocked_imports: List[str] = []
        self.blocked_calls: List[str] = []
        self.unsafe_attributes: List[str] = []

    def visit_Import(self, node: ast.Import):
        for alias in node.names:
            module_name = alias.name.split(".")[0]
            if module_name in {
                "subprocess",
                "socket",
                "threading",
                "multiprocessing",
                "urllib",
                "urllib3",
                "requests",
                "cryptography",
                "pycryptodome",
                "ctypes",
                "pickle",
                "marshal",
                "os",
                "pathlib",
                "shutil",
                "tempfile",
                "glob",
                "fnmatch",
                "linecache",
                "macpath",
                "ntpath",
                "posixpath",
            }:
                self.blocked_imports.append(alias.name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        module_name = node.module.split(".")[0] if node.module else ""
        if module_name in {
            "subprocess",
            "socket",
            "threading",
            "multiprocessing",
            "urllib",
            "urllib3",
            "requests",
            "cryptography",
            "pycryptodome",
            "ctypes",
            "pickle",
            "marshal",
            "os",
            "pathlib",
            "shutil",
            "tempfile",
            "glob",
            "fnmatch",
            "linecache",
        }:
            self.blocked_imports.append(module_name)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call):
        if isinstance(node.func, ast.Name):
            if node.func.id in {
                "open",
                "file",
                "exec",
                "eval",
                "compile",
                "__import__",
                "breakpoint",
                "getattr",
                "setattr",
                "delattr",
                "type",
                "vars",
                "input",
                "globals",
                "locals",
            }:
                self.blocked_calls.append(node.func.id)
        elif isinstance(node.func, ast.Attribute):
            if node.func.attr in {
                "system",
                "popen",
                "spawn",
                "exec",
                "remove",
                "rmdir",
                "unlink",
                "mkdir",
                "rename",
                "replace",
                "chmod",
                "chown",
                "kill",
            }:
                self.blocked_calls.append(f"{node.func.value}.{node.func.attr}")
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute):
        if node.attr in {
            "__globals__",
            "__code__",
            "__closure__",
            "__builtins__",
            "__subclasses__",
            "__getattribute__",
            "__class__",
            "__bases__",
            "__mro__",
        }:
            self.unsafe_attributes.append(node.attr)
        self.generic_visit(node)


class CodeExecutor:
    """Safely executes generated Python automation code."""

    def __init__(self):
        self.execution_count = 0

    def validate_code(self, code: str) -> Tuple[bool, str]:
        """Validate Python code for syntax and safety."""
        if not code or not code.strip():
            return False, "Empty code provided"

        for pattern in DANGEROUS_PATTERNS:
            if re.search(pattern, code, re.IGNORECASE):
                return False, f"Dangerous pattern detected: {pattern}"

        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return False, f"Syntax error: {e}"

        validator = SecurityValidator()
        validator.visit(tree)

        if validator.blocked_imports:
            return (
                False,
                f"Blocked imports detected: {', '.join(set(validator.blocked_imports))}",
            )

        if validator.blocked_calls:
            return (
                False,
                f"Blocked function calls detected: {', '.join(set(validator.blocked_calls))}",
            )

        if validator.unsafe_attributes:
            return (
                False,
                f"Unsafe attribute access detected: {', '.join(set(validator.unsafe_attributes))}",
            )

        return True, ""

    def _save_resource_limits(self) -> dict:
        if not _HAS_RESOURCE:
            return {}
        saved = {}
        try:
            for rlim in (
                resource.RLIMIT_CPU,
                resource.RLIMIT_AS,
                resource.RLIMIT_FSIZE,
                resource.RLIMIT_NPROC,
                resource.RLIMIT_NOFILE,
            ):
                saved[rlim] = resource.getrlimit(rlim)
        except (ValueError, OSError):
            pass
        return saved

    def _apply_resource_limits(self, timeout: int):
        if not _HAS_RESOURCE:
            return
        try:
            resource.setrlimit(resource.RLIMIT_CPU, (timeout, timeout))
            resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
            resource.setrlimit(resource.RLIMIT_FSIZE, (1 * 1024 * 1024, 1 * 1024 * 1024))
            resource.setrlimit(resource.RLIMIT_NPROC, (10, 10))
            resource.setrlimit(resource.RLIMIT_NOFILE, (50, 50))
        except (ValueError, OSError):
            pass

    def _restore_resource_limits(self, saved: dict):
        if not _HAS_RESOURCE:
            return
        for rlim, limits in saved.items():
            try:
                resource.setrlimit(rlim, limits)
            except (ValueError, OSError):
                pass

    def execute(self, code: str, timeout: int = None) -> Tuple[bool, str, str]:
        """Execute Python code and capture results."""
        timeout = timeout or Config.EXECUTION_TIMEOUT
        self.execution_count += 1

        is_valid, error_msg = self.validate_code(code)
        if not is_valid:
            return False, "", f"Validation failed: {error_msg}"

        # Log before applying resource limits (log writes need file descriptors)
        self._log_code(code)

        capture_stdout = StringIO()
        capture_stderr = StringIO()
        old_stdout = sys.stdout
        old_stderr = sys.stderr

        success = False
        error_msg = ""

        saved_limits = self._save_resource_limits()

        try:
            sys.stdout = capture_stdout
            sys.stderr = capture_stderr

            safe_modules = {
                "time": {"sleep": __import__("time").sleep},
                "json": {"dumps": __import__("json").dumps, "loads": __import__("json").loads},
                "re": {
                    "findall": __import__("re").findall,
                    "search": __import__("re").search,
                    "match": __import__("re").match,
                    "sub": __import__("re").sub,
                    "compile": __import__("re").compile,
                    "split": __import__("re").split,
                    "finditer": __import__("re").finditer,
                },
                "math": {
                    "ceil": __import__("math").ceil,
                    "floor": __import__("math").floor,
                    "sqrt": __import__("math").sqrt,
                    "sin": __import__("math").sin,
                    "cos": __import__("math").cos,
                    "tan": __import__("math").tan,
                    "log": __import__("math").log,
                    "pi": __import__("math").pi,
                    "e": __import__("math").e,
                    "pow": __import__("math").pow,
                    "fabs": __import__("math").fabs,
                    "trunc": __import__("math").trunc,
                    "degrees": __import__("math").degrees,
                    "radians": __import__("math").radians,
                    "isnan": __import__("math").isnan,
                    "isinf": __import__("math").isinf,
                    "factorial": __import__("math").factorial,
                },
                "random": {
                    "random": __import__("random").random,
                    "randint": __import__("random").randint,
                    "choice": __import__("random").choice,
                    "shuffle": __import__("random").shuffle,
                    "sample": __import__("random").sample,
                    "uniform": __import__("random").uniform,
                    "randrange": __import__("random").randrange,
                },
                "datetime": {
                    "datetime": __import__("datetime").datetime,
                    "date": __import__("datetime").date,
                    "time": __import__("datetime").time,
                    "timedelta": __import__("datetime").timedelta,
                },
                "itertools": {
                    "chain": __import__("itertools").chain,
                    "islice": __import__("itertools").islice,
                    "zip_longest": __import__("itertools").zip_longest,
                },
                "collections": {
                    "Counter": __import__("collections").Counter,
                    "OrderedDict": __import__("collections").OrderedDict,
                    "defaultdict": __import__("collections").defaultdict,
                    "deque": __import__("collections").deque,
                    "namedtuple": __import__("collections").namedtuple,
                },
                "io": {
                    "StringIO": __import__("io").StringIO,
                    "BytesIO": __import__("io").BytesIO,
                },
            }

            # operator: only read/comparison ops — no setitem/delitem/getitem to prevent
            # namespace mutation via operator.setitem(globals(), ...)
            _op = __import__("operator")
            safe_modules["operator"] = {
                "add": _op.add,
                "sub": _op.sub,
                "mul": _op.mul,
                "truediv": _op.truediv,
                "floordiv": _op.floordiv,
                "mod": _op.mod,
                "eq": _op.eq,
                "ne": _op.ne,
                "lt": _op.lt,
                "le": _op.le,
                "gt": _op.gt,
                "ge": _op.ge,
                "and_": _op.and_,
                "or_": _op.or_,
                "not_": _op.not_,
                "xor": _op.xor,
                "lshift": _op.lshift,
                "rshift": _op.rshift,
                "concat": _op.concat,
                "contains": _op.contains,
                "index": _op.index,
                "inv": _op.inv,
            }

            try:
                pyautogui = __import__("pyautogui")
                safe_modules["pyautogui"] = {
                    "click": pyautogui.click,
                    "doubleClick": pyautogui.doubleClick,
                    "rightClick": pyautogui.rightClick,
                    "moveTo": pyautogui.moveTo,
                    "moveRel": pyautogui.moveRel,
                    "press": pyautogui.press,
                    "write": pyautogui.write,
                    "keyDown": pyautogui.keyDown,
                    "keyUp": pyautogui.keyUp,
                    "hotkey": pyautogui.hotkey,
                    "screenshot": pyautogui.screenshot,
                    "position": pyautogui.position,
                    "size": pyautogui.size,
                }
            except (ImportError, AttributeError):
                pass

            try:
                mss_module = __import__("mss")
                safe_modules["mss"] = {
                    "Screenshot": mss_module.mss,
                }
            except (ImportError, AttributeError):
                pass

            try:
                PIL = __import__("PIL")
                safe_modules["PIL"] = {
                    "Image": PIL.Image,
                }
            except (ImportError, AttributeError):
                pass

            # Block builtins that allow namespace inspection or unsafe execution.
            # globals() and locals() are blocked to prevent the sandbox namespace
            # from being mutated via operator.setitem(globals(), '__builtins__', ...).
            blocked_builtins = {
                "exec",
                "eval",
                "compile",
                "__import__",
                "breakpoint",
                "getattr",
                "setattr",
                "delattr",
                "open",
                "file",
                "input",
                "type",
                "vars",
                "dir",
                "help",
                "repr",
                "format",
                "slice",
                "globals",
                "locals",
            }

            restricted_builtins = {
                k: getattr(builtins, k)
                for k in dir(builtins)
                if k not in blocked_builtins
            }

            safe_globals = {**restricted_builtins, **safe_modules}

            self._apply_resource_limits(timeout)
            exec(code, safe_globals)  # noqa: S102
            success = True

        except SyntaxError as e:
            error_msg = "Syntax error in generated code"
            logger.debug("SyntaxError: %s", e)
        except IndentationError as e:
            error_msg = "Indentation error in generated code"
            logger.debug("IndentationError: %s", e)
        except TabError as e:
            error_msg = "Formatting error in generated code"
            logger.debug("TabError: %s", e)
        except Exception as e:
            error_msg = "Code execution error"
            logger.debug("%s: %s", type(e).__name__, e)

        finally:
            self._restore_resource_limits(saved_limits)
            stdout_value = capture_stdout.getvalue()
            stderr_value = capture_stderr.getvalue()
            sys.stdout = old_stdout
            sys.stderr = old_stderr

        if not success:
            full_error = stderr_value if stderr_value else ""
            if error_msg:
                full_error = f"{full_error}\n{error_msg}" if full_error else error_msg
            return False, stdout_value, full_error

        return True, stdout_value, stderr_value

    def _log_code(self, code: str):
        """Log executed code to file."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        log_path = Config.get_code_log_path(timestamp)

        try:
            with open(log_path, "w") as f:
                f.write(f"# Execution #{self.execution_count}\n")
                f.write(f"# Timestamp: {datetime.now().isoformat()}\n")
                f.write(f"# {'=' * 60}\n\n")
                f.write(code)
        except Exception as e:
            logger.warning("Could not log code: %s", e)

    def get_execution_count(self) -> int:
        return self.execution_count


def execute_code(code: str) -> Tuple[bool, str, str]:
    """Quick function to execute code."""
    executor = CodeExecutor()
    return executor.execute(code)
