"""
Shared parsing helpers for LLM automation responses.
"""

import re


COMPLETION_PATTERNS = (
    "task_complete",
    "task complete",
    "automation complete",
    "# done",
    "# complete",
    "# task_complete",
    "task_complete:",
)


def check_completion_marker(text: str) -> bool:
    """Return True when the response indicates task completion."""
    if not text:
        return False
    text_lower = text.lower()
    return any(pattern in text_lower for pattern in COMPLETION_PATTERNS)


def extract_python_code(text: str) -> str:
    """Extract Python code from an LLM response string.

    Handles various code block formats including:
    - ```python ... ``` (with language specifier)
    - ``` ... ``` (generic code block)
    - Case-insensitive language specifier (Python, PYTHON, python)
    - Code blocks without newlines after opening/closing backticks
    - Multi-line code blocks
    """
    if not text:
        return ""

    # Use case-insensitive matching and more flexible patterns
    # Pattern breakdown:
    # - ```(?:python)?\s* - Opening backticks with optional language specifier (case-insensitive)
    # - \n? - Optional newline after opening backticks
    # - (.*?) - Non-greedy capture of code content
    # - \n? - Optional newline before closing backticks
    # - ``` - Closing backticks
    block_patterns = (
        # Python code blocks with optional language, handles various whitespace/newline combinations
        r"```(?:python)?\s*\n?(.*?)\n?```",
        # Generic code blocks (no language specified)
        r"```\s*\n?(.*?)\n?```",
    )

    # Try each pattern with case-insensitive flag
    for pattern in block_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE | re.DOTALL)
        if matches:
            # Return the first match (most likely the main code block)
            code = matches[0].strip()
            # Verify it looks like Python code before returning
            if _looks_like_python_code(code):
                return code

    # Fallback: try to extract code from text that doesn't have proper code blocks
    # Look for common Python automation markers and extract surrounding content
    return _extract_code_fallback(text)


def _looks_like_python_code(text: str) -> bool:
    """Check if extracted text looks like valid Python code.

    Args:
        text: Potentially extracted code text

    Returns:
        True if the text appears to be Python code
    """
    if not text:
        return False

    # Check for common Python indicators
    python_indicators = [
        "import ",
        "def ",
        "class ",
        "if ",
        "for ",
        "while ",
        "try:",
        "except",
        "with ",
        "pyautogui",
        "time.sleep",
        "print(",
    ]

    # Must have at least one Python indicator
    text_lower = text.lower()
    has_indicator = any(indicator.lower() in text_lower for indicator in python_indicators)

    # Should not be mostly non-code text (like entire responses with explanations)
    # If it's longer than 1000 chars and has many sentences, probably not code
    if len(text) > 1000:
        # Count potential sentence endings
        sentence_endings = text.count('. ') + text.count('! ') + text.count('? ')
        if sentence_endings > 5:
            return False

    return has_indicator


def _extract_code_fallback(text: str) -> str:
    """Fallback method to extract code when no code block is found.

    This handles cases where the LLM returns code without proper
    markdown code block formatting.

    Args:
        text: Full response text

    Returns:
        Extracted code or empty string
    """
    if not text:
        return ""

    text_lower = text.lower()

    # Check if response contains Python automation markers (stricter check)
    # Must have a strong indicator like "import pyautogui" or actual code structure
    automation_markers = ("import pyautogui", "def ", "click(", "time.sleep", "pyautogui.")
    has_strong_indicator = any(marker in text_lower for marker in automation_markers)

    # Also check for multiple Python-like lines
    lines = text.split('\n')
    code_line_count = sum(1 for line in lines if _is_code_line(line.strip()))

    if not has_strong_indicator or code_line_count < 2:
        return ""

    # Try to find code-like sections in the text
    code_lines = []
    in_code_section = False

    for line in lines:
        stripped = line.strip()

        # Check if this line looks like code
        if _is_code_line(stripped):
            in_code_section = True
            code_lines.append(line)
        elif in_code_section:
            # Non-code line after code section - stop collecting
            # Only continue if it's an empty line or a comment
            if not stripped or stripped.startswith('#'):
                code_lines.append(line)
            else:
                break

    if code_lines and len(code_lines) >= 2:
        return '\n'.join(code_lines).strip()

    return ""


def _is_code_line(line: str) -> bool:
    """Check if a line looks like Python code.

    Args:
        line: Single line of text

    Returns:
        True if the line appears to be Python code
    """
    if not line:
        return False

    # Code indicators - more strict to avoid false positives
    code_indicators = (
        line.startswith("import "),
        line.startswith("from "),
        line.startswith("def "),
        line.startswith("class "),
        line.startswith("if "),
        line.startswith("for "),
        line.startswith("while "),
        line.startswith("try:"),
        line.startswith("except"),
        line.startswith("with "),
        line.startswith("#"),  # Comment
        " = " in line,  # Assignment
        "pyautogui." in line,
        ".click(" in line,
        ".moveTo(" in line,
        ".typewrite(" in line,
        ".hotkey(" in line,
        "time.sleep" in line,
        "print(" in line,  # Print function
        line.startswith("    "),  # Indented (likely code)
        line.startswith("\t"),  # Tab indented
    )

    return any(code_indicators)
