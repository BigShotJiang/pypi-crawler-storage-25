"""
Prompt management module for the AI automation agent.
Manages system prompts and conversation history.
"""

import json
import datetime
from typing import List, Dict, Any, Optional

from intent.agent.parsing import check_completion_marker, extract_python_code
from intent.agent.system_info import get_context_string


# ---------------------------------------------------------------------------
# Gemini message format helpers
# ---------------------------------------------------------------------------
# Gemini API uses a different schema from OpenAI and Anthropic:
#
#   Role names : "user" and "model"  (NOT "assistant")
#   Content key: "parts"             (NOT "content")
#   Text part  : {"text": "..."}     (no "type" field)
#   Image part : {"inline_data": {"mime_type": "image/png", "data": "<b64>"}}
#
# Getting any of these wrong causes a 400 / INVALID_ARGUMENT error from the API.

def _text_part(text: str) -> Dict[str, Any]:
    """Build a part compatible with your Next.js Proxy."""
    return {"type": "text", "text": text}


def _image_part(screenshot_base64: str) -> Dict[str, Any]:
    """Build an image part compatible with your Next.js Proxy.

    MIME must be image/jpeg — vision.py encodes screenshots as JPEG (q=85) to
    stay under Vercel's 4.5MB body limit. Declaring image/png here while the
    actual bytes are JPEG causes Gemini to 500 when validating the inline_data
    mime_type against the decoded payload.
    """
    return {
        "type": "image_url",
        "image_url": {
            "url": f"data:image/jpeg;base64,{screenshot_base64}"
        }
    }


class PromptManager:
    """Manages prompts and conversation history for the automation agent."""

    SYSTEM_PROMPT = """You are an expert desktop automation assistant. Your task is to analyze desktop screenshots and generate Python code using PyAutoGUI to automate user interactions.

**Core Requirements:**
- Generate ONLY valid, executable Python code - no explanations or text outside code blocks
- Use PyAutoGUI functions: click(), doubleClick(), rightClick(), moveTo(), dragTo(), typewrite(), write(), hotkey(), press(), screenshot()
- Add time.sleep(0.5-2.0) between actions for reliability
- Include descriptive comments for each step
- Use try-except blocks for error handling, especially for coordinate-based actions

**Targeting Strategy (READ THIS — most failures come from ignoring it):**
- PREFER keyboard-driven actions over coordinate clicks. They are far more reliable
  than estimating pixel positions from a screenshot.
- macOS app launching: use Spotlight — `pyautogui.hotkey('command','space')`,
  `time.sleep(0.5)`, `pyautogui.typewrite('AppName', interval=0.05)`,
  `time.sleep(0.4)`, `pyautogui.press('enter')`. This works for ANY app and does
  not depend on the Dock being visible or icon positions.
- App switching: `pyautogui.hotkey('command','tab')`. Menus: `pyautogui.hotkey('command','q')` to quit, etc.
- ONLY click coordinates when the goal genuinely requires clicking a specific
  on-screen element that has no keyboard equivalent. Identify it from the screenshot.
- Use pyautogui.size() to get screen dimensions if needed.

**FORBIDDEN APIs (will crash — do NOT generate these):**
- `pyautogui.locateOnScreen(...)` — needs a reference image file the agent does not have.
- The `confidence=` keyword argument — requires OpenCV which is not installed.
- Anything from `cv2`, `numpy`, `subprocess`, `os.system`, `socket`, network libraries.

**Code Template:**
```python
import pyautogui
import time

# Task: [Brief description]

try:
    # Step 1: [Action description]
    pyautogui.moveTo(x=X, y=Y)  # Move to target location
    time.sleep(0.5)
    pyautogui.click()
    time.sleep(1.0)

    # Step 2: [Next action if needed]
    # ... additional actions ...

except Exception as e:
    print(f"Error: {e}")

# TASK_COMPLETE: [What was accomplished]
```

**Task Completion (STRICT — read carefully):**
- # TASK_COMPLETE may ONLY be written when the CURRENT screenshot ALREADY shows the
  finished goal state, BEFORE you take any new action this turn.
- NEVER write # TASK_COMPLETE in the same code block where you click, type, or press a
  key expecting it to finish the task. You have not seen the result yet — the action may
  fail, hit a dialog, miss the target, or open the wrong thing. You will see the result
  on the NEXT turn and can mark complete then if the screenshot confirms it.
- Phrases like "should now be opening", "will be done", "should have launched" mean you
  are SPECULATING. If you are speculating, DO NOT add TASK_COMPLETE.
- If the task needs more than one action, this turn is NOT the final turn.
- Only mark complete when the final desired state is unambiguously VISIBLE in the
  screenshot you were given for this turn.

**Error Recovery:**
- If previous code failed, analyze the error and screenshot, then generate corrected code
- Focus only on fixing what went wrong, then continue with the next logical step
- If stuck in a loop, try a different approach

**Important:**
- Keep code focused on the immediate next step
- Be precise with coordinates and timing
- Refuse to generate code that would delete files, send messages or emails without explicit content shown to the user, exfiltrate data, or perform irreversible system changes. Ask for confirmation instead.
"""

    def __init__(self, max_history: int = 50):
        """Initialize the prompt manager.

        Args:
            max_history: Maximum number of conversation turns to keep
        """
        self.conversation_history: List[Dict[str, Any]] = []
        self.max_history = max_history
        self.current_iteration = 0
        self.task_goal = ""

        # Cache the system context so get_system_prompt() does not re-spawn
        # subprocesses (xrandr, osascript, sw_vers, etc.) on every call.
        self._cached_system_context: Optional[str] = None

    # ------------------------------------------------------------------
    # Prompt construction
    # ------------------------------------------------------------------

    def get_system_prompt(self) -> str:
        """
        Get the system prompt for the automation agent.

        In the Gemini SDK this string is passed as system_instruction= when
        constructing the GenerativeModel — it is NOT a message in the chat.
        """
        if self._cached_system_context is None:
            self._cached_system_context = get_context_string()

        return (
            f"{self.SYSTEM_PROMPT}\n"
            "**System Context (use this information for accurate coordinate calculations):**\n"
            f"{self._cached_system_context}\n\n"
            "**Remember:** Use the screen resolution above to calculate appropriate "
            "coordinates when a click is truly required. For most app-launching and "
            "navigation tasks, prefer keyboard shortcuts (Spotlight on macOS, Start "
            "menu / Win key on Windows) — they are far more reliable than clicking.\n"
        )

    def invalidate_system_context(self):
        """
        Force the system context to be re-collected on the next call to
        get_system_prompt().  Call this if the display configuration changes
        mid-session (e.g. a monitor is connected or the window is moved).
        """
        self._cached_system_context = None

    # ------------------------------------------------------------------
    # Task / goal management
    # ------------------------------------------------------------------

    def set_task_goal(self, goal: str):
        """Set the overall task goal.

        Args:
            goal: The main objective to accomplish
        """
        self.task_goal = goal

    # ------------------------------------------------------------------
    # History builders
    # ------------------------------------------------------------------

    def add_user_instruction(
        self, instruction: str, screenshot_base64: Optional[str] = None
    ):
        """
        Add the initial user instruction with screenshot.

        Args:
            instruction: The user's goal/task
            screenshot_base64: Optional base64 encoded screenshot
        """
        if not self.task_goal:
            self.task_goal = instruction

        parts = [
            _text_part(
                f"User Goal: {instruction}\n\n"
                + (
                    "Analyze this screenshot and generate Python code for the FIRST step "
                    "toward the goal. Do NOT write # TASK_COMPLETE on this turn — you have "
                    "not yet seen the result of any action. You will get a fresh screenshot "
                    "after execution and can mark complete then if it shows the goal achieved."
                    if screenshot_base64
                    else "Generate Python automation code for the FIRST step toward the goal. "
                    "Do NOT write # TASK_COMPLETE on this turn — the action has not run yet."
                )
            )
        ]
        if screenshot_base64:
            parts.append(_image_part(screenshot_base64))

        self.conversation_history.append(
            {
                "role": "user",
                "parts": parts,
                "iteration": self.current_iteration,
            }
        )
        self._trim_history()

    def add_execution_result(
        self,
        screenshot_base64: Optional[str] = None,
        success: bool = False,
        message: str = "",
        iteration: Optional[int] = None,
    ):
        """
        Add execution result with new screenshot.

        Args:
            screenshot_base64: Optional base64 encoded screenshot after execution
            success: Whether the code executed successfully
            message: Error message if failed, or success note
            iteration: Current iteration number
        """
        if iteration is not None:
            self.current_iteration = iteration

        status = "completed successfully" if success else "failed with error"
        text = f"Iteration {self.current_iteration}: Previous code {status}."

        if message:
            text += f"\n\nError details: {message}"

        if not success:
            text += (
                "\n\nAnalyze the error and current screen. Generate corrected code "
                "that fixes the issue and continues toward the goal."
            )
        else:
            text += (
                f"\n\nGoal: {self.task_goal}\n\n"
                "Current desktop state shown below. If goal is achieved, add "
                "# TASK_COMPLETE: [description]. Otherwise, generate the next automation step:"
            )

        parts = [_text_part(text)]
        if screenshot_base64:
            parts.append(_image_part(screenshot_base64))

        self.conversation_history.append(
            {
                "role": "user",
                "parts": parts,
                "iteration": self.current_iteration,
                "success": success,
            }
        )
        self._trim_history()

        # Always advance the counter — successful steps are still iterations.
        # Previously only failure advanced it, making the count meaningless.
        self.current_iteration += 1

    def add_assistant_response(self, response: str, iteration: Optional[int] = None):
        if iteration is not None:
            self.current_iteration = iteration

        self.conversation_history.append(
            {
                "role": "assistant",  # Changed from "model" to match standard proxy expectations
                "parts": [_text_part(response)], # Keep internal key as 'parts' for now
                "iteration": self.current_iteration,
            }
        )

    # ------------------------------------------------------------------
    # History accessors
    # ------------------------------------------------------------------

    def get_messages(self, include_images: bool = True) -> List[Dict[str, Any]]:
        formatted_messages = []

        # Only the latest user message needs its screenshot — older screenshots
        # bloat the request body and push it over Vercel's 4MB body limit without
        # providing additional value (the model already saw them in prior turns).
        last_user_idx = max(
            (i for i, m in enumerate(self.conversation_history) if m["role"] == "user"),
            default=-1,
        )

        for i, msg in enumerate(self.conversation_history):
            role = msg["role"]
            if role == "model":
                role = "assistant"

            parts = msg.get("parts", [])

            keep_images = include_images and (i == last_user_idx)
            if not keep_images:
                parts = [p for p in parts if p.get("type") != "image_url"]
            if not parts:
                continue

            formatted_messages.append({"role": role, "content": parts})

        return formatted_messages

    def get_last_user_message(self) -> Optional[Dict[str, Any]]:
        """Get the most recent user message.

        Returns:
            Last user message or None if no messages
        """
        for msg in reversed(self.conversation_history):
            if msg.get("role") == "user":
                return msg
        return None

    def get_last_assistant_message(self) -> Optional[Dict[str, Any]]:
        """
        Get the most recent assistant/model message.
        """
        for msg in reversed(self.conversation_history):
            # SYNC: Changed from "model" to "assistant"
            if msg.get("role") == "assistant":
                return msg
        return None

    def get_conversation_summary(self) -> str:
        """Get a summary of the conversation so far.

        Returns:
            Summary string
        """
        if not self.conversation_history:
            return "No conversation history."

        user_count = sum(
            1 for msg in self.conversation_history if msg.get("role") == "user"
        )
        assistant_count = sum(
            1 for msg in self.conversation_history if msg.get("role") == "assistant"
        )

        lines = [
            "Conversation Summary:",
            f"- Task Goal: {self.task_goal}",
            f"- Current Iteration: {self.current_iteration}",
            f"- User Messages: {user_count}",
            f"- Assistant Messages: {assistant_count}",
            f"- Total Messages: {len(self.conversation_history)}",
        ]
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Completion helpers
    # ------------------------------------------------------------------

    def check_completion(self, code: str) -> bool:
        """Check if the generated code signals task completion.

        Args:
            code: The generated Python code

        Returns:
            True if task is complete
        """
        return check_completion_marker(code)

    def is_task_completed(self) -> bool:
        """Check if the last assistant response indicates task completion.

        Returns:
            True if task appears to be completed
        """
        last = self.get_last_assistant_message()
        if last:
            # Model messages are stored as parts; extract text for the check.
            text = "".join(
                p.get("text", "") for p in last.get("parts", []) if "text" in p
            )
            return self.check_completion(text)
        return False

    def get_code_from_last_response(self) -> str:
        """Extract Python code from the last assistant response.

        Returns:
            Extracted code or empty string
        """
        last = self.get_last_assistant_message()
        if last:
            text = "".join(
                p.get("text", "") for p in last.get("parts", []) if "text" in p
            )
            return extract_python_code(text)
        return ""

    # ------------------------------------------------------------------
    # History management
    # ------------------------------------------------------------------

    def _trim_history(self):
        """
        Trim conversation history to max_history entries.

        The very first message (original task instruction) is always kept so
        the model retains the initial goal even after many iterations.
        Previously a plain tail-slice silently discarded it once the history
        grew past max_history.
        """
        if len(self.conversation_history) <= self.max_history:
            return

        first = self.conversation_history[0]
        tail  = self.conversation_history[-(self.max_history - 1):]

        # Avoid duplicating the first message if it already sits in the tail.
        if tail and tail[0] is first:
            self.conversation_history = tail
        else:
            self.conversation_history = [first] + tail

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def export_conversation(self, filepath: str):
        """Export conversation history to JSON file.

        Args:
            filepath: Path to save the conversation
        """
        export_data = {
            "task_goal": self.task_goal,
            "current_iteration": self.current_iteration,
            "max_history": self.max_history,
            "conversation_history": self.conversation_history,
            # datetime is a proper top-level import, not an inline __import__
            "exported_at": str(datetime.datetime.now()),
        }

        with open(filepath, "w") as f:
            json.dump(export_data, f, indent=2)

    def import_conversation(self, filepath: str):
        """Import conversation history from JSON file.

        Args:
            filepath: Path to the conversation file

        Raises:
            FileNotFoundError: If the file does not exist
            ValueError: If the file is not valid JSON or has an unexpected schema
        """
        # Previously swallowed all exceptions silently, making it impossible
        # for callers to detect a failed load.
        try:
            with open(filepath, "r") as f:
                import_data = json.load(f)
        except FileNotFoundError:
            raise
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"Invalid JSON in conversation file: {filepath}"
            ) from exc

        self.task_goal          = import_data.get("task_goal", "")
        self.current_iteration  = import_data.get("current_iteration", 0)
        self.max_history        = import_data.get("max_history", 50)
        self.conversation_history = import_data.get("conversation_history", [])

    # ------------------------------------------------------------------
    # State management
    # ------------------------------------------------------------------

    def reset(self):
        """Clear conversation history and reset state."""
        self.conversation_history = []
        self.current_iteration = 0
        self.task_goal = ""
        self._cached_system_context = None

    def get_statistics(self) -> Dict[str, Any]:
        """Get conversation statistics."""
        user_messages = [
            msg for msg in self.conversation_history if msg.get("role") == "user"
        ]
        # SYNC: Changed from "model" to "assistant"
        assistant_messages = [
            msg for msg in self.conversation_history if msg.get("role") == "assistant"
        ]

        successful_executions = sum(
            1 for msg in user_messages if msg.get("success") is True
        )
        failed_executions = sum(
            1 for msg in user_messages if msg.get("success") is False
        )

        return {
            "total_messages":        len(self.conversation_history),
            "user_messages":         len(user_messages),
            "assistant_messages":    len(assistant_messages),
            "successful_executions": successful_executions,
            "failed_executions":     failed_executions,
            "current_iteration":     self.current_iteration,
            "task_goal":             self.task_goal,
            "is_completed":          self.is_task_completed(),
        }