"""
Main orchestration module for autonomous desktop automation.
Implements the iterative loop: capture -> analyze -> execute -> verify -> repeat.
"""

import time

from rich.panel import Panel
from rich.syntax import Syntax

from intent.agent.executor import CodeExecutor
from intent.agent.interfaces import (
    CompletionVerifier,
    Executor,
    Planner,
    ScreenshotProvider,
)
from intent.agent.llm import LLMClient
from intent.agent.prompts import PromptManager
from intent.agent.verifier import GeminiCompletionVerifier
from intent.agent.vision import ScreenshotCapture
from intent.cli.errors import IntentError, display_error
from intent.cli.theme import (
    EMERALD_300,
    EMERALD_400,
    EMERALD_600,
    EMERALD_700,
    INTENT_EMERALD,
    INTENT_STONE,
    PANEL_BORDER,
    PANEL_BORDER_ERROR,
    SYNTAX_THEME,
    console,
)
from intent.core.config import Config


class AutonomousAutomation:

    def __init__(
        self,
        api_client=None,
        confirm_mode: bool | None = None,
        quiet: bool = False,
        *,
        screenshot_provider: ScreenshotProvider | None = None,
        planner: Planner | None = None,
        executor: Executor | None = None,
        prompt_manager: PromptManager | None = None,
        verifier: CompletionVerifier | None = None,
    ):
        Config.validate()

        self.screenshot = screenshot_provider or ScreenshotCapture()
        self.llm_client = planner or LLMClient(api_client=api_client)
        self.executor = executor or CodeExecutor()
        self.prompt_manager = prompt_manager or PromptManager()
        self.verifier = verifier or GeminiCompletionVerifier(self.llm_client)
        self.api_client = api_client
        self.confirm_mode = (
            confirm_mode if confirm_mode is not None else Config.CONFIRM_BEFORE_EXECUTE
        )
        self.quiet = quiet

        if not quiet:
            console.print(f"[bold {INTENT_EMERALD}]Initialized[/] | Model: {Config.GEMINI_MODEL} | Confirm: {self.confirm_mode}")

    def run(self, user_instruction: str) -> bool:
        _, screenshot_b64 = self.screenshot.capture()
        self.prompt_manager.add_user_instruction(user_instruction, screenshot_b64)

        for iteration in range(1, Config.MAX_ITERATIONS + 1):
            self._print_step_heading(iteration)

            try:
                messages = self.prompt_manager.get_messages()
                with console.status(
                    f"[{EMERALD_400}]thinking…[/]",
                    spinner="dots",
                    spinner_style=INTENT_EMERALD,
                ):
                    full_response, code = self.llm_client.get_automation_code(messages)
                self.prompt_manager.add_assistant_response(full_response)

                if not self.quiet:
                    syntax = Syntax(code, "python", theme=SYNTAX_THEME, line_numbers=True)
                    console.print(syntax)
                    console.print("")

            except Exception as e:
                display_error(IntentError.server(
                    "AI model request failed.",
                    suggestion="Try again or rephrase your command.",
                    debug=str(e),
                ))
                return False

            if self.confirm_mode:
                response = (
                    console.input(
                        f"\n[bold {INTENT_STONE}]Execute this code? (y/n/q): [/]"
                    )
                    .strip()
                    .lower()
                )
                if response == "q":
                    console.print("[bold_rose]User aborted automation.[/bold_rose]")
                    return False
                elif response != "y":
                    console.print("[dim_stone]Skipping execution...[/dim_stone]")
                    _, screenshot_b64 = self.screenshot.capture()
                    self.prompt_manager.add_execution_result(
                        screenshot_b64, False, "User skipped execution", iteration
                    )
                    continue

            with console.status(
                f"[{EMERALD_400}]executing…[/]",
                spinner="dots",
                spinner_style=INTENT_EMERALD,
            ):
                success, stdout, stderr = self.executor.execute(code)

            # Log every execution (success or failure)
            if self.api_client:
                self.api_client.log_action(
                    "execution",
                    {
                        "iteration": iteration,
                        "success": success,
                        "code": code,
                        "credits": 1,
                        "stdout": stdout if success else None,
                        "stderr": stderr if not success else None,
                    },
                )

            if success:
                console.print(f"[bold {INTENT_EMERALD}]✓[/] [stone]done[/]")
                if stdout:
                    console.print(Panel(stdout, title="output", border_style=PANEL_BORDER))
            else:
                display_error(IntentError.execution(
                    "Code execution encountered an error.",
                    suggestion="Try rephrasing your command.",
                    debug=stderr,
                ))
                time.sleep(1)

            with console.status(
                f"[{EMERALD_400}]capturing screen…[/]",
                spinner="dots",
                spinner_style=INTENT_EMERALD,
            ):
                _, screenshot_b64 = self.screenshot.capture()

            error_context = f"Error details:\n{stderr}" if not success else ""
            self.prompt_manager.add_execution_result(
                screenshot_b64, success, error_context, iteration
            )

            if success and self.prompt_manager.check_completion(code):
                with console.status(
                    f"[{EMERALD_400}]verifying…[/]",
                    spinner="dots",
                    spinner_style=INTENT_EMERALD,
                ):
                    verified = self.verifier.verify(
                        user_goal=self.prompt_manager.task_goal,
                        screenshot_b64=screenshot_b64,
                    )

                if verified:
                    console.print(f"[bold {INTENT_EMERALD}]✓[/] [bold_white]task complete[/]")
                    return True
                else:
                    console.print(f"[dim_stone]not yet complete — continuing[/]")

        console.print(
            f"[bold_stone]reached max steps ({Config.MAX_ITERATIONS}) — task may be incomplete[/]"
        )
        return False

    def _print_step_heading(self, iteration: int) -> None:
        """Render a stepper-style progress indicator: ● ● ○ ○ ○."""
        total = Config.MAX_ITERATIONS
        if total <= 10:
            dots = []
            for i in range(1, total + 1):
                if i < iteration:
                    dots.append(f"[{EMERALD_600}]●[/]")
                elif i == iteration:
                    dots.append(f"[bold {EMERALD_300}]●[/]")
                else:
                    dots.append(f"[{EMERALD_700}]○[/]")
            indicator = " ".join(dots)
        else:
            indicator = (
                f"[bold {EMERALD_300}]{iteration:02d}[/]"
                f"[{EMERALD_700}] / {total:02d}[/]"
            )
        console.print(indicator)

    def shutdown(self):
        console.rule("Shutting down automation system")
        console.print(f"Total executions: {self.executor.get_execution_count()}")
        console.print(f"Logs saved to: {Config.LOG_DIR}")
        # Clean up old screenshots to prevent unbounded disk growth
        if hasattr(self.screenshot, 'cleanup_old_screenshots'):
            self.screenshot.cleanup_old_screenshots()
        console.print("")
