class GeminiCompletionVerifier:

    def __init__(self, llm_client):
        self._llm_client = llm_client

    def verify(self, *, user_goal: str, screenshot_b64: str) -> bool:
        verify_prompt = f"""Analyze this screenshot and determine if the user's goal has been achieved.

User Goal: {user_goal}

Look at the current desktop state and answer:
- Is the task COMPLETELY finished?
- Are there any remaining dialogs, prompts, or incomplete actions?
- Is the desired outcome visible?

Respond with ONLY one word: YES or NO"""

        try:
            verify_system = "You are a task verification assistant. Answer YES or NO only."

            messages = [{
                "role": "user",
                "content": [
                    {"type": "text", "text": verify_prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{screenshot_b64}"}}
                ]
            }]

            raw_response = self._llm_client.api_client.generate_content(
                messages=messages,
                system_instruction=verify_system,
                model_name=self._llm_client.model_name
            )

            full_response = (raw_response or "").strip().lower()

            return full_response.startswith("yes")
        except Exception:
            return False
