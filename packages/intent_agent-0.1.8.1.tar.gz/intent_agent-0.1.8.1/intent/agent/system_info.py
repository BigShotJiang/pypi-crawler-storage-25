"""
System information module for desktop automation context.
Collects relevant system information to provide accurate context to the LLM.
"""

import os
import sys
import platform
import socket
import subprocess
import logging
from typing import Dict, Any, Optional, List, Tuple

logger = logging.getLogger(__name__)

try:
    import mss
    HAS_MSS = True
except ImportError:
    HAS_MSS = False

# ---------------------------------------------------------------------------
# Platform-specific optional imports
# ---------------------------------------------------------------------------

_SYSTEM = platform.system()

# macOS: Quartz for window list + AppKit for cursor
HAS_QUARTZ = False
if _SYSTEM == "Darwin":
    try:
        import Quartz
        HAS_QUARTZ = True
    except ImportError:
        pass

# Windows: pywin32 for window enumeration
HAS_WIN32 = False
if _SYSTEM == "Windows":
    try:
        import win32gui
        import win32con
        import ctypes
        HAS_WIN32 = True
    except ImportError:
        pass

# Linux: Xlib or ewmh for window info
HAS_XLIB = False
if _SYSTEM == "Linux":
    try:
        from Xlib import display as XDisplay
        HAS_XLIB = True
    except ImportError:
        pass


# ===========================================================================
# Public API — function names are unchanged
# ===========================================================================

def get_system_info() -> Dict[str, Any]:
    """
    Collect all relevant system information for the LLM context.

    Returns:
        Dictionary containing system context information.
    """
    info: Dict[str, Any] = {
        "os": get_os_info(),
        "screen": get_screen_info(),
        "hostname": socket.gethostname(),
        "python_version": sys.version.split()[0],
    }

    display_info = get_display_info()
    if display_info:
        info["display"] = display_info

    # --- NEW: cursor & active window ---
    cursor = get_cursor_position()
    if cursor:
        info["cursor"] = cursor

    active = get_active_window()
    if active:
        info["active_window"] = active

    return info


def get_os_info() -> str:
    """
    Get detailed OS information.

    Returns:
        String describing the operating system.
    """
    system = platform.system()
    machine = platform.machine()

    if system == "Darwin":
        try:
            result = _run(["sw_vers", "-productVersion"], timeout=5)
            if result:
                return f"macOS {result} ({machine})"
        except Exception:
            pass
        return f"macOS {platform.release()} ({machine})"

    if system == "Linux":
        try:
            if os.path.exists("/etc/os-release"):
                with open("/etc/os-release") as f:
                    for line in f:
                        if line.startswith("PRETTY_NAME="):
                            return line.split("=", 1)[1].strip().strip('"')
        except Exception:
            pass
        return f"Linux {platform.release()} ({machine})"

    if system == "Windows":
        return f"Windows {platform.release()} ({machine})"

    return f"{system} {platform.release()} ({machine})"


def get_screen_info() -> Dict[str, Any]:
    """
    Get screen/display information, DPI-aware.

    Returns:
        Dictionary with screen dimensions, count, and scaling factors.
    """
    info: Dict[str, Any] = {}

    if HAS_MSS:
        try:
            # FIX: use context manager to avoid resource leak
            with mss.mss() as sct:
                monitors = sct.monitors  # [0] = virtual combined; [1:] = real monitors

                info["monitor_count"] = len(monitors) - 1

                if len(monitors) > 1:
                    primary = monitors[1]
                    info["primary"] = {
                        "width": primary["width"],
                        "height": primary["height"],
                        "x": primary.get("left", 0),
                        "y": primary.get("top", 0),
                    }

                if len(monitors) > 2:
                    info["all_monitors"] = [
                        {
                            "index": i,
                            "width": m["width"],
                            "height": m["height"],
                            "x": m.get("left", 0),
                            "y": m.get("top", 0),
                        }
                        for i, m in enumerate(monitors[1:], 1)
                    ]
        except Exception as exc:
            logger.warning("mss screen detection failed: %s", exc)
            info["error"] = str(exc)

    # --- NEW: DPI / scaling factors ---
    scale = _get_dpi_scale()
    if scale:
        info["dpi_scale"] = scale

    return info


def get_display_info() -> Dict[str, Any]:
    """
    Get additional display information using platform-specific methods.

    Returns:
        Dictionary with additional display info (always a dict, never None).
    """
    # FIX: always return a dict (was Optional[Dict] before, causing inconsistent callers)
    info: Dict[str, Any] = {}

    system = platform.system()

    if system == "Darwin":
        info.update(_display_info_macos())
    elif system == "Windows":
        info.update(_display_info_windows())
    elif system == "Linux":
        info.update(_display_info_linux())

    return info


def format_system_context() -> str:
    """
    Format system information as a readable string for the LLM.

    Returns:
        Formatted string with system context.
    """
    info = get_system_info()

    lines = [
        "## System Context",
        f"- **OS**: {info['os']}",
        f"- **Hostname**: {info['hostname']}",
        f"- **Python**: {info['python_version']}",
    ]

    screen = info.get("screen", {})
    if screen.get("primary"):
        p = screen["primary"]
        lines.append(f"- **Primary Screen**: {p['width']}x{p['height']} @ ({p['x']},{p['y']})")
    if screen.get("monitor_count"):
        lines.append(f"- **Monitor Count**: {screen['monitor_count']}")
    if screen.get("dpi_scale"):
        lines.append(f"- **DPI Scale**: {screen['dpi_scale']:.2f}x")

    display = info.get("display", {})
    for i, d in enumerate(display.get("displays", []), 1):
        res = d.get("resolution", "?")
        name = d.get("name", "Unknown")
        lines.append(f"- **Display {i}**: {res} ({name})")

    cursor = info.get("cursor")
    if cursor:
        lines.append(f"- **Cursor Position**: ({cursor['x']}, {cursor['y']})")

    win = info.get("active_window")
    if win:
        lines.append(f"- **Active Window**: \"{win.get('title', 'Unknown')}\"")
        if win.get("bounds"):
            b = win["bounds"]
            lines.append(
                f"  - Bounds: ({b['x']},{b['y']}) {b['width']}x{b['height']}"
            )

    return "\n".join(lines)


# Convenience function
def get_context_string() -> str:
    """Get formatted system context string for LLM."""
    return format_system_context()


# ===========================================================================
# NEW public helpers — window & element geometry
# ===========================================================================

def get_active_window() -> Optional[Dict[str, Any]]:
    """
    Return title and bounds of the currently focused window.

    Returns:
        {"title": str, "bounds": {"x", "y", "width", "height"}, "pid": int}
        or None if unavailable.
    """
    system = platform.system()
    if system == "Darwin":
        return _active_window_macos()
    if system == "Windows":
        return _active_window_windows()
    if system == "Linux":
        return _active_window_linux()
    return None


def get_all_windows() -> List[Dict[str, Any]]:
    """
    Return a list of all visible top-level windows with their geometry.

    Each entry: {"title": str, "bounds": {"x","y","width","height"}, "pid": int}
    """
    system = platform.system()
    if system == "Darwin":
        return _all_windows_macos()
    if system == "Windows":
        return _all_windows_windows()
    if system == "Linux":
        return _all_windows_linux()
    return []


def get_cursor_position() -> Optional[Dict[str, int]]:
    """
    Return the current mouse cursor position in screen coordinates.

    Returns:
        {"x": int, "y": int} or None if unavailable.
    """
    system = platform.system()

    if system == "Darwin":
        try:
            if HAS_QUARTZ:
                loc = Quartz.NSEvent.mouseLocation()
                # Quartz Y is flipped vs screen coords — convert
                screen_h = _primary_screen_height()
                return {"x": int(loc.x), "y": int(screen_h - loc.y) if screen_h else int(loc.y)}
        except Exception:
            pass

    if system == "Windows":
        try:
            import ctypes
            class POINT(ctypes.Structure):
                _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
            pt = POINT()
            ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
            return {"x": pt.x, "y": pt.y}
        except Exception:
            pass

    if system == "Linux":
        try:
            if HAS_XLIB:
                d = XDisplay.Display()
                root = d.screen().root
                data = root.query_pointer()._data
                return {"x": data["root_x"], "y": data["root_y"]}
        except Exception:
            pass
        # Fallback: xdotool
        out = _run(["xdotool", "getmouselocation", "--shell"], timeout=3)
        if out:
            coords = {}
            for line in out.splitlines():
                if "=" in line:
                    k, _, v = line.partition("=")
                    coords[k.lower()] = int(v)
            if "x" in coords and "y" in coords:
                return {"x": coords["x"], "y": coords["y"]}

    return None


def normalize_coordinates(
    x: int,
    y: int,
    source_width: int,
    source_height: int,
    screen_info: Optional[Dict[str, Any]] = None,
) -> Tuple[int, int]:
    """
    Convert coordinates from a scaled/resized image back to real screen coordinates.

    This is critical when your screenshot is downscaled before being sent to the
    LLM — the model returns pixel positions relative to the image, but you need
    positions relative to the physical screen to click correctly.

    Args:
        x, y:              Pixel position in the source image.
        source_width,
        source_height:     Dimensions of the source image (e.g. the screenshot
                           you sent to the LLM).
        screen_info:       Output of get_screen_info(). Fetched fresh if omitted.

    Returns:
        (screen_x, screen_y) adjusted for display scale and image resize ratio.
    """
    if screen_info is None:
        screen_info = get_screen_info()

    primary = screen_info.get("primary", {})
    screen_w = primary.get("width", source_width)
    screen_h = primary.get("height", source_height)

    # Ratio between actual screen pixels and image pixels
    ratio_x = screen_w / source_width
    ratio_y = screen_h / source_height

    # Account for DPI scaling (logical → physical pixels)
    dpi_scale = screen_info.get("dpi_scale", 1.0)

    screen_x = int(x * ratio_x * dpi_scale)
    screen_y = int(y * ratio_y * dpi_scale)

    return screen_x, screen_y


def get_element_center(bounds: Dict[str, int]) -> Tuple[int, int]:
    """
    Compute the center point of a window/element bounding box for click targeting.

    Args:
        bounds: dict with keys "x", "y", "width", "height"

    Returns:
        (center_x, center_y)
    """
    cx = bounds["x"] + bounds["width"] // 2
    cy = bounds["y"] + bounds["height"] // 2
    return cx, cy


def window_to_image_coords(
    screen_x: int,
    screen_y: int,
    window_bounds: Dict[str, int],
    image_width: int,
    image_height: int,
) -> Tuple[int, int]:
    """
    Convert absolute screen coordinates to coordinates within a window screenshot.

    Useful when you've captured just one window and need to tell the LLM where
    something is inside that window's image.

    Args:
        screen_x, screen_y: Absolute screen position.
        window_bounds:       {"x","y","width","height"} of the window on screen.
        image_width,
        image_height:        Pixel size of the window screenshot.

    Returns:
        (image_x, image_y) — coordinates within the captured image.
    """
    rel_x = screen_x - window_bounds["x"]
    rel_y = screen_y - window_bounds["y"]

    scale_x = image_width / window_bounds["width"]
    scale_y = image_height / window_bounds["height"]

    return int(rel_x * scale_x), int(rel_y * scale_y)


# ===========================================================================
# Internal helpers
# ===========================================================================

def _run(cmd: List[str], timeout: int = 5) -> Optional[str]:
    """Run a subprocess, return stdout stripped or None on failure."""
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception as exc:
        logger.debug("Subprocess %s failed: %s", cmd[0], exc)
    return None


def _primary_screen_height() -> Optional[int]:
    """Return height of the primary monitor in logical pixels."""
    info = get_screen_info()
    p = info.get("primary")
    return p["height"] if p else None


# ---------------------------------------------------------------------------
# DPI scale
# ---------------------------------------------------------------------------

def _get_dpi_scale() -> Optional[float]:
    """Return display scale factor (1.0 = 100 %, 2.0 = Retina/200 %)."""
    system = platform.system()

    if system == "Darwin":
        try:
            # system_profiler is slow; prefer Quartz if available
            if HAS_QUARTZ:
                screen = Quartz.CGMainDisplayID()
                physical_w = Quartz.CGDisplayPixelsWide(screen)
                logical_out = _run(
                    ["osascript", "-e",
                     "tell application \"Finder\" to get bounds of window of desktop"],
                    timeout=3,
                )
                # Fall back to comparing physical vs mss logical width
                with mss.mss() as sct:
                    logical_w = sct.monitors[1]["width"]
                if logical_w and physical_w:
                    return round(physical_w / logical_w, 2)
        except Exception:
            pass

    if system == "Windows":
        try:
            import ctypes
            # Use Per-Monitor DPI awareness value
            awareness = ctypes.c_int()
            ctypes.windll.shcore.GetProcessDpiAwareness(0, ctypes.byref(awareness))
            dpi = ctypes.windll.user32.GetDpiForSystem()
            return round(dpi / 96.0, 2)
        except Exception:
            pass

    if system == "Linux":
        # Try GDK_SCALE env var first (common in GNOME/KDE)
        scale = os.environ.get("GDK_SCALE") or os.environ.get("QT_SCALE_FACTOR")
        if scale:
            try:
                return float(scale)
            except ValueError:
                pass
        # Try xrandr
        out = _run(["xrandr", "--current"], timeout=5)
        if out:
            for line in out.splitlines():
                if " connected" in line and "+" in line:
                    # e.g. "eDP-1 connected primary 2560x1600+0+0 ..."
                    parts = line.split()
                    for part in parts:
                        if "x" in part and "+" in part:
                            try:
                                res_part = part.split("+")[0]
                                phys_w = int(res_part.split("x")[0])
                                if HAS_MSS:
                                    with mss.mss() as sct:
                                        log_w = sct.monitors[1]["width"]
                                    return round(phys_w / log_w, 2)
                            except Exception:
                                pass

    return None


# ---------------------------------------------------------------------------
# Display info per platform
# ---------------------------------------------------------------------------

def _display_info_macos() -> Dict[str, Any]:
    info: Dict[str, Any] = {}
    try:
        import json
        out = _run(["system_profiler", "SPDisplaysDataType", "-json"], timeout=10)
        if out:
            data = json.loads(out)
            displays_raw = data.get("SPDisplaysDataType", [])
            displays = []
            for d in displays_raw:
                entry: Dict[str, Any] = {"name": d.get("sppds_model_name", "Unknown")}
                for drv in d.get("spdisplays_ndrvs", []):
                    if "spdisplays_resolution" in drv:
                        entry["resolution"] = drv["spdisplays_resolution"]
                        break
                    # FIX: also try "_spdisplays_resolution" (older macOS key)
                    if "_spdisplays_resolution" in drv:
                        entry["resolution"] = drv["_spdisplays_resolution"]
                        break
                displays.append(entry)
            if displays:
                info["displays"] = displays
    except Exception as exc:
        logger.debug("macOS display info failed: %s", exc)
    return info


def _display_info_windows() -> Dict[str, Any]:
    info: Dict[str, Any] = {}
    try:
        # FIX: wmic is deprecated in Win11 — prefer PowerShell
        out = _run(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance -ClassName Win32_VideoController | "
             "Select-Object -ExpandProperty VideoModeDescription"],
            timeout=10,
        )
        if out:
            info["resolution"] = out.splitlines()[0].strip()
    except Exception as exc:
        logger.debug("Windows display info failed: %s", exc)
    return info


def _display_info_linux() -> Dict[str, Any]:
    info: Dict[str, Any] = {}
    try:
        out = _run(["xrandr", "--current"], timeout=5)
        if out:
            resolutions = []
            for line in out.splitlines():
                # FIX: more robust — match "WxH+X+Y" pattern with *
                if "*" in line:
                    parts = line.split()
                    if parts:
                        resolutions.append(parts[0])
            if resolutions:
                info["resolution"] = resolutions[0]
                if len(resolutions) > 1:
                    info["all_resolutions"] = resolutions
    except Exception as exc:
        logger.debug("Linux display info failed: %s", exc)
    return info


# ---------------------------------------------------------------------------
# Active window per platform
# ---------------------------------------------------------------------------

def _active_window_macos() -> Optional[Dict[str, Any]]:
    if not HAS_QUARTZ:
        return None
    try:
        options = Quartz.kCGWindowListOptionOnScreenOnly | Quartz.kCGWindowListExcludeDesktopElements
        window_list = Quartz.CGWindowListCopyWindowInfo(options, Quartz.kCGNullWindowID)
        for win in window_list:
            if win.get("kCGWindowLayer", 1) == 0:  # layer 0 = normal app windows
                bounds = win.get("kCGWindowBounds", {})
                return {
                    "title": win.get("kCGWindowName") or win.get("kCGWindowOwnerName", ""),
                    "pid": win.get("kCGWindowOwnerPID"),
                    "bounds": {
                        "x": int(bounds.get("X", 0)),
                        "y": int(bounds.get("Y", 0)),
                        "width": int(bounds.get("Width", 0)),
                        "height": int(bounds.get("Height", 0)),
                    },
                }
    except Exception as exc:
        logger.debug("macOS active window failed: %s", exc)
    return None


def _active_window_windows() -> Optional[Dict[str, Any]]:
    if not HAS_WIN32:
        return None
    try:
        hwnd = win32gui.GetForegroundWindow()
        if hwnd:
            title = win32gui.GetWindowText(hwnd)
            rect = win32gui.GetWindowRect(hwnd)
            x, y, x2, y2 = rect
            return {
                "title": title,
                "pid": None,  # needs win32process for PID — kept optional
                "bounds": {
                    "x": x, "y": y,
                    "width": x2 - x, "height": y2 - y,
                },
            }
    except Exception as exc:
        logger.debug("Windows active window failed: %s", exc)
    return None


def _active_window_linux() -> Optional[Dict[str, Any]]:
    # Try xdotool first (most common)
    out = _run(["xdotool", "getactivewindow", "getwindowname"], timeout=3)
    title = out if out else None
    geom = _run(["xdotool", "getactivewindow", "getwindowgeometry", "--shell"], timeout=3)
    if geom:
        coords: Dict[str, int] = {}
        for line in geom.splitlines():
            if "=" in line:
                k, _, v = line.partition("=")
                try:
                    coords[k.strip().lower()] = int(v.strip())
                except ValueError:
                    pass
        if "x" in coords and "width" in coords:
            return {
                "title": title or "",
                "pid": coords.get("pid"),
                "bounds": {
                    "x": coords["x"], "y": coords["y"],
                    "width": coords["width"], "height": coords["height"],
                },
            }

    # Fallback: Xlib
    if HAS_XLIB:
        try:
            d = XDisplay.Display()
            net_active = d.intern_atom("_NET_ACTIVE_WINDOW")
            root = d.screen().root
            active_id = root.get_full_property(net_active, 0).value[0]
            window = d.create_resource_object("window", active_id)
            geom_xlib = window.get_geometry()
            net_name = d.intern_atom("_NET_WM_NAME")
            name_prop = window.get_full_property(net_name, 0)
            title_str = name_prop.value.decode("utf-8", errors="replace") if name_prop else ""
            abs_coords = window.translate_coords(root, 0, 0)
            return {
                "title": title_str,
                "pid": None,
                "bounds": {
                    "x": abs_coords.x, "y": abs_coords.y,
                    "width": geom_xlib.width, "height": geom_xlib.height,
                },
            }
        except Exception as exc:
            logger.debug("Xlib active window failed: %s", exc)

    return None


def _all_windows_macos() -> List[Dict[str, Any]]:
    if not HAS_QUARTZ:
        return []
    windows = []
    try:
        options = Quartz.kCGWindowListOptionOnScreenOnly | Quartz.kCGWindowListExcludeDesktopElements
        window_list = Quartz.CGWindowListCopyWindowInfo(options, Quartz.kCGNullWindowID)
        for win in window_list:
            if win.get("kCGWindowLayer", 1) != 0:
                continue
            bounds = win.get("kCGWindowBounds", {})
            windows.append({
                "title": win.get("kCGWindowName") or win.get("kCGWindowOwnerName", ""),
                "pid": win.get("kCGWindowOwnerPID"),
                "bounds": {
                    "x": int(bounds.get("X", 0)),
                    "y": int(bounds.get("Y", 0)),
                    "width": int(bounds.get("Width", 0)),
                    "height": int(bounds.get("Height", 0)),
                },
            })
    except Exception as exc:
        logger.debug("macOS all windows failed: %s", exc)
    return windows


def _all_windows_windows() -> List[Dict[str, Any]]:
    if not HAS_WIN32:
        return []
    windows: List[Dict[str, Any]] = []

    def _callback(hwnd: int, _: Any) -> bool:
        if win32gui.IsWindowVisible(hwnd):
            title = win32gui.GetWindowText(hwnd)
            if title:
                rect = win32gui.GetWindowRect(hwnd)
                x, y, x2, y2 = rect
                windows.append({
                    "title": title,
                    "pid": None,
                    "bounds": {"x": x, "y": y, "width": x2 - x, "height": y2 - y},
                })
        return True

    try:
        win32gui.EnumWindows(_callback, None)
    except Exception as exc:
        logger.debug("Windows EnumWindows failed: %s", exc)
    return windows


def _all_windows_linux() -> List[Dict[str, Any]]:
    out = _run(["wmctrl", "-lG"], timeout=5)
    if not out:
        return []
    windows = []
    for line in out.splitlines():
        parts = line.split(None, 7)
        # wmctrl -lG format: ID Desktop X Y W H Machine Title
        if len(parts) >= 7:
            try:
                windows.append({
                    "title": parts[7] if len(parts) > 7 else "",
                    "pid": None,
                    "bounds": {
                        "x": int(parts[2]), "y": int(parts[3]),
                        "width": int(parts[4]), "height": int(parts[5]),
                    },
                })
            except (ValueError, IndexError):
                continue
    return windows