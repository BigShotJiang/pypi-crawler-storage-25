"""
Interfaces for the automation agent pipeline.

These protocols make the orchestration (`AutonomousAutomation`) independent
of specific implementations (Gemini vs other LLM, different screenshot sources,
different executors, etc.).
"""

from __future__ import annotations

from typing import Protocol, Tuple, Any


class ScreenshotProvider(Protocol):
    def capture(self) -> Tuple[Any, str]:
        """Return (image, base64_png)."""


class Planner(Protocol):
    def get_automation_code(self, messages: list) -> tuple[str, str]:
        """Return (full_response, extracted_code)."""


class Executor(Protocol):
    def execute(self, code: str) -> tuple[bool, str, str]:
        """Return (success, stdout, stderr)."""


class CompletionVerifier(Protocol):
    def verify(self, *, user_goal: str, screenshot_b64: str) -> bool:
        """Return True if the goal is actually complete."""

