"""
LLM client module for communicating with Google Gemini API.
Generates Python automation code based on desktop screenshots.
"""

import logging
import time

from intent.agent.parsing import extract_python_code
from intent.agent.prompts import PromptManager
from intent.cli.errors import IntentError
from intent.cli.theme import INTENT_STONE, console
from intent.core.config import Config

logger = logging.getLogger("intent.debug")

try:
    from intent.core.api import APIClient
    HAS_API_CLIENT = True
except ImportError:
    HAS_API_CLIENT = False


class LLMClient:

    def __init__(self, api_client=None, model_name: str = None):
        self.api_client = api_client
        self.model_name = model_name or Config.GEMINI_MODEL
        self.prompt_manager = PromptManager()

        self.system_instruction = self.prompt_manager.get_system_prompt()

    def get_automation_code(self, messages: list, retry_count: int = 3) -> tuple[str, str]:
        if not self.api_client:
            raise IntentError.server(
                "No API client provided.",
                suggestion="Ensure you are logged in with 'intent login'.",
            )

        errors = []

        for attempt in range(retry_count + 1):
            try:
                if Config.API_REQUEST_DELAY > 0:
                    time.sleep(Config.API_REQUEST_DELAY)

                full_response = self.api_client.generate_content(
                    messages=messages,
                    system_instruction=self.system_instruction,
                    model_name=self.model_name
                )

                if not full_response:
                    raise IntentError.server(
                        "The AI model returned an empty response.",
                        suggestion="This may be temporary. Try running your command again.",
                    )

                code = self._extract_code(full_response)
                return full_response, code

            except Exception as e:
                error_type = type(e).__name__
                error_msg = str(e)
                logger.warning("Proxy API Error (attempt %d): %s - %s", attempt, error_type, error_msg)
                errors.append(f"{error_type}: {error_msg}")

                console.print(f"\n[{INTENT_STONE}][{error_type}] Proxy API Error: {error_msg}[/{INTENT_STONE}]")

                if attempt < retry_count:
                    sleep_time = 1 * (attempt + 1)
                    console.print(f"\n[{INTENT_STONE}]Retrying in {sleep_time} seconds...[/{INTENT_STONE}]")
                    time.sleep(sleep_time)
                else:
                    raise IntentError.server(
                        "AI model unavailable after multiple attempts.",
                        suggestion="Try again in a moment.",
                        debug=str(errors),
                    )

    def _extract_code(self, response: str) -> str:
        code = extract_python_code(response)
        if code:
            return code

        return (response or "").strip()

    def check_completion(self, code: str) -> bool:
        return self.prompt_manager.check_completion(code)


def create_local_llm_client(api_client, model_name: str = None) -> LLMClient:
    try:
        return LLMClient(api_client=api_client, model_name=model_name)
    except Exception as e:
        logger.error("Failed to setup LLM client: %s", e)
        return None
