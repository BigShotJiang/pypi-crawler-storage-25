"""
Screenshot capture module for desktop automation.
Captures the current desktop state for analysis by the LLM.
"""

import base64
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Tuple

import mss
from PIL import Image

from intent.core.config import Config


class ScreenshotCapture:
    """Handles desktop screenshot capture and processing."""

    def __init__(self):
        self.sct = mss.mss()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def close(self):
        if hasattr(self, "sct") and self.sct:
            try:
                self.sct.close()
            except Exception:
                pass

    def capture(self, save: bool = True) -> Tuple[Image.Image, str]:
        """
        Capture the current desktop screenshot.

        Returns:
            Tuple of (PIL Image, base64 encoded string)
        """
        monitor = self.sct.monitors[1]  # 0 is all monitors, 1 is primary
        screenshot = self.sct.grab(monitor)

        img = Image.frombytes("RGB", screenshot.size, screenshot.rgb)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        if save:
            save_path = Config.get_screenshot_path(timestamp)
            img.save(save_path)

        base64_str = self._encode_image(img)
        return img, base64_str

    def _encode_image(self, image: Image.Image, max_size: int = 1280) -> str:
        """
        Encode PIL Image to base64 JPEG string, resizing if needed.

        max_size capped at 1280 (down from 2048) to keep each request under
        Vercel's 4.5 MB body limit even on Retina displays.  JPEG quality=85
        yields ~300–500 KB vs 3–5 MB for PNG at the same resolution.
        """
        width, height = image.size
        if max(width, height) > max_size:
            ratio = max_size / max(width, height)
            image = image.resize(
                (int(width * ratio), int(height * ratio)), Image.LANCZOS
            )

        # Convert to RGB — JPEG does not support alpha channel
        if image.mode != "RGB":
            image = image.convert("RGB")

        buffered = BytesIO()
        image.save(buffered, format="JPEG", quality=85, optimize=True)
        return base64.b64encode(buffered.getvalue()).decode()

    def capture_region(self, x: int, y: int, width: int, height: int) -> Image.Image:
        """Capture a specific region of the screen."""
        monitor = {"top": y, "left": x, "width": width, "height": height}
        screenshot = self.sct.grab(monitor)
        return Image.frombytes("RGB", screenshot.size, screenshot.rgb)

    def cleanup_old_screenshots(self, retention_days: int = None):
        """Delete screenshot files older than retention_days."""
        days = retention_days if retention_days is not None else Config.LOG_RETENTION_DAYS
        cutoff = datetime.now().timestamp() - days * 86400
        deleted = 0
        for path in Config.SCREENSHOT_DIR.glob("screenshot_*.png"):
            try:
                if path.stat().st_mtime < cutoff:
                    path.unlink()
                    deleted += 1
            except OSError:
                pass
        if deleted:
            import logging
            logging.getLogger("intent.debug").debug(
                "Cleaned up %d screenshot(s) older than %d day(s)", deleted, days
            )


def capture_desktop() -> Tuple[Image.Image, str]:
    """Quick function to capture desktop."""
    capturer = ScreenshotCapture()
    return capturer.capture()
