import logging
import os
import traceback
from enum import Enum
from logging.handlers import RotatingFileHandler

import requests

from intent.cli.theme import console
from intent.core.config import Config

logger = logging.getLogger("intent.debug")


class ErrorCategory(Enum):
    NETWORK = "Connection"
    AUTH = "Authentication"
    SERVER = "Server"
    CONFIG = "Configuration"
    EXECUTION = "Execution"
    CREDITS = "Credits"
    UNKNOWN = "Error"


class IntentError(Exception):

    def __init__(
        self,
        category: ErrorCategory,
        user_message: str,
        suggestion: str = "",
        debug_detail: str = "",
    ):
        self.category = category
        self.user_message = user_message
        self.suggestion = suggestion
        self.debug_detail = debug_detail
        super().__init__(user_message)

    @classmethod
    def network(cls, message: str, *, suggestion: str = "", debug: str = ""):
        return cls(ErrorCategory.NETWORK, message, suggestion, debug)

    @classmethod
    def auth(cls, message: str, *, suggestion: str = "", debug: str = ""):
        return cls(ErrorCategory.AUTH, message, suggestion, debug)

    @classmethod
    def server(cls, message: str, *, suggestion: str = "", debug: str = ""):
        return cls(ErrorCategory.SERVER, message, suggestion, debug)

    @classmethod
    def config(cls, message: str, *, suggestion: str = "", debug: str = ""):
        return cls(ErrorCategory.CONFIG, message, suggestion, debug)

    @classmethod
    def execution(cls, message: str, *, suggestion: str = "", debug: str = ""):
        return cls(ErrorCategory.EXECUTION, message, suggestion, debug)

    @classmethod
    def credits(cls, message: str, *, suggestion: str = "", debug: str = ""):
        return cls(ErrorCategory.CREDITS, message, suggestion, debug)

    @classmethod
    def from_exception(cls, exc: Exception):
        category, user_message, suggestion, debug_detail = classify_exception(exc)
        return cls(category, user_message, suggestion, debug_detail)


def classify_exception(exc: Exception):
    if isinstance(exc, IntentError):
        return (
            exc.category,
            exc.user_message,
            exc.suggestion,
            exc.debug_detail,
        )

    if isinstance(exc, requests.exceptions.ConnectionError):
        return (
            ErrorCategory.NETWORK,
            "Unable to reach the Intent server.",
            "Check your internet connection and try again.",
            str(exc),
        )

    if isinstance(exc, requests.exceptions.Timeout):
        return (
            ErrorCategory.NETWORK,
            "Connection to the server timed out.",
            "Check your internet connection and try again.",
            str(exc),
        )

    if isinstance(exc, requests.exceptions.HTTPError):
        status = exc.response.status_code if exc.response else 0
        if status == 401:
            return (
                ErrorCategory.AUTH,
                "Your session has expired.",
                "Run 'intent login' to authenticate again.",
                str(exc),
            )
        if status == 402:
            return (
                ErrorCategory.CREDITS,
                "Insufficient credits.",
                "Purchase more credits at intent.sh/dashboard.",
                str(exc),
            )
        if status == 403:
            return (
                ErrorCategory.AUTH,
                "Access denied.",
                "Check your account permissions or contact support.",
                str(exc),
            )
        if 500 <= status < 600:
            return (
                ErrorCategory.SERVER,
                "The server encountered an error.",
                "Try again in a moment. If this persists, contact support.",
                str(exc),
            )
        return (
            ErrorCategory.SERVER,
            f"Server returned an error (HTTP {status}).",
            "Try again or contact support.",
            str(exc),
        )

    if isinstance(exc, ValueError):
        msg = str(exc)
        if "Session expired" in msg or "Not authenticated" in msg or "Unauthorized" in msg:
            return (
                ErrorCategory.AUTH,
                "Your session has expired.",
                "Run 'intent login' to authenticate again.",
                msg,
            )
        if "Insufficient credits" in msg:
            return (
                ErrorCategory.CREDITS,
                "Insufficient credits.",
                "Purchase more credits at intent.sh/dashboard.",
                msg,
            )
        if "timeout" in msg.lower() or "Cannot connect" in msg:
            return (
                ErrorCategory.NETWORK,
                "Unable to reach the Intent server.",
                "Check your internet connection and try again.",
                msg,
            )
        if "API error" in msg or "API Error" in msg:
            return (
                ErrorCategory.SERVER,
                "The server returned an error.",
                "Try again in a moment.",
                msg,
            )

    return (
        ErrorCategory.UNKNOWN,
        "An unexpected error occurred.",
        "Try again or run with --verbose for details.",
        f"{type(exc).__name__}: {str(exc)}",
    )


def is_verbose():
    return bool(os.getenv("INTENT_DEBUG"))


def display_error(error: Exception, *, verbose: bool | None = None):
    if isinstance(error, IntentError):
        intent_err = error
    else:
        intent_err = IntentError.from_exception(error)

    logger.error(
        "%s: %s | suggestion: %s | debug: %s",
        intent_err.category.value,
        intent_err.user_message,
        intent_err.suggestion,
        intent_err.debug_detail,
        exc_info=not isinstance(error, IntentError),
    )

    label = intent_err.category.value
    console.print(f"[bold_rose]\u2717 {label}: {intent_err.user_message}[/bold_rose]")

    if intent_err.suggestion:
        console.print(f"[stone]  {intent_err.suggestion}[/stone]")

    show_debug = verbose if verbose is not None else is_verbose()
    if show_debug and intent_err.debug_detail:
        console.print(f"[dim_stone]  Details: {intent_err.debug_detail}[/dim_stone]")


def setup_file_logging():
    if logger.handlers:
        return
    Config._ensure_dirs()
    log_path = Config.LOG_DIR / "debug.log"
    handler = RotatingFileHandler(
        log_path,
        maxBytes=5_000_000,
        backupCount=3,
    )
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s"
        )
    )
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
