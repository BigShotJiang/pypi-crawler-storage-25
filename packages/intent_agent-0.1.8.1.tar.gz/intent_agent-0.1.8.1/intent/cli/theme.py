from rich.console import Console
from rich.theme import Theme

INTENT_EMERALD = "#10b981"
INTENT_STONE = "#a1a1aa"
INTENT_WHITE = "#ffffff"
INTENT_ROSE = "#fb7185"

# Tailwind emerald ramp — used to gradient the banner and accent surfaces.
EMERALD_300 = "#6ee7b7"
EMERALD_400 = "#34d399"
EMERALD_500 = INTENT_EMERALD
EMERALD_600 = "#059669"
EMERALD_700 = "#047857"
EMERALD_900 = "#064e3b"

INTENT_THEME = Theme(
    {
        "emerald": INTENT_EMERALD,
        "bold_emerald": f"bold {INTENT_EMERALD}",
        "stone": INTENT_STONE,
        "dim_stone": f"dim {INTENT_STONE}",
        "rose": INTENT_ROSE,
        "bold_rose": f"bold {INTENT_ROSE}",
        "white": INTENT_WHITE,
        "bold_white": f"bold {INTENT_WHITE}",
        "status": INTENT_EMERALD,
        "status.warn": INTENT_STONE,
        "status.error": INTENT_ROSE,
    }
)

_BANNER_LINES = [
    "██╗███╗   ██╗████████╗███████╗███╗   ██╗████████╗",
    "██║████╗  ██║╚══██╔══╝██╔════╝████╗  ██║╚══██╔══╝",
    "██║██╔██╗ ██║   ██║   █████╗  ██╔██╗ ██║   ██║   ",
    "██║██║╚██╗██║   ██║   ██╔══╝  ██║╚██╗██║   ██║   ",
    "██║██║ ╚████║   ██║   ███████╗██║ ╚████║   ██║   ",
    "╚═╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝╚═╝  ╚═══╝   ╚═╝   ",
]

# Light → deep emerald gradient. Top rows brighter so the banner reads as
# "rising," bottom rows darker so it grounds into the shadow line below.
_BANNER_GRADIENT = [
    EMERALD_300,
    EMERALD_400,
    EMERALD_500,
    EMERALD_500,
    EMERALD_600,
    EMERALD_700,
]

_BANNER_SHADOW = "░" * 49


def render_banner(console: Console, indent: int = 0) -> None:
    """Print the INTENT wordmark with a vertical emerald gradient and shadow."""
    pad = " " * indent
    for color, line in zip(_BANNER_GRADIENT, _BANNER_LINES):
        console.print(f"{pad}[bold {color}]{line}[/]")
    console.print(f"{pad}[{EMERALD_900}]{_BANNER_SHADOW}[/]")


# Plain banner kept for any callers that still want a single string.
BANNER = f"[bold {INTENT_EMERALD}]\n" + "\n".join(_BANNER_LINES) + "\n[/]"

PROMPT_SYMBOL = "›"

PANEL_BORDER = INTENT_EMERALD
PANEL_BORDER_WARN = INTENT_STONE
PANEL_BORDER_ERROR = INTENT_ROSE

SYNTAX_THEME = "monokai"

console = Console(theme=INTENT_THEME)
