import sys

import click
from rich.panel import Panel
from rich.prompt import Prompt

from intent.app.action_runner import run_instruction
from intent.app.context import AppContext, create_app_context
from intent.cli.errors import IntentError, display_error, is_verbose, setup_file_logging
from intent.cli.theme import (
    BANNER,
    EMERALD_300,
    EMERALD_400,
    EMERALD_700,
    INTENT_EMERALD,
    INTENT_ROSE,
    INTENT_STONE,
    PANEL_BORDER,
    PANEL_BORDER_WARN,
    PROMPT_SYMBOL,
    console,
    render_banner,
)
from intent.core.api import APIClient
from intent.core.auth import AuthManager

from intent import __version__

auth_manager: AuthManager | None = None
api_client: APIClient | None = None

_app_context: AppContext | None = None


def get_app_context() -> AppContext | None:
    global _app_context, auth_manager, api_client

    if _app_context is not None:
        return _app_context

    try:
        _app_context = create_app_context()
        auth_manager = _app_context.auth
        api_client = _app_context.api
        return _app_context
    except Exception as e:
        display_error(IntentError.config(
            "Failed to initialize CLI.",
            suggestion="Check your configuration and try again.",
            debug=str(e),
        ))
        return None


class NaturalLanguageGroup(click.Group):

    def parse_args(self, ctx, args):
        if not args:
            return super().parse_args(ctx, args)

        cmd_name = args[0]
        if cmd_name in self.commands or cmd_name in ["--help", "-h", "--version"]:
            return super().parse_args(ctx, args)

        return super().parse_args(ctx, ["act"] + args)


@click.group(cls=NaturalLanguageGroup, invoke_without_command=True)
@click.version_option(version=__version__, prog_name="intent")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output with debug details")
@click.pass_context
def cli(ctx, verbose):
    """Intent CLI Agent - Control your desktop with natural language."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    if verbose:
        import os
        os.environ["INTENT_DEBUG"] = "1"
    setup_file_logging()
    app_ctx = get_app_context()
    if app_ctx is None:
        display_error(IntentError.config(
            "Failed to initialize CLI context.",
            suggestion="Check your configuration and try again.",
        ))
        sys.exit(1)

    auth_manager = app_ctx.auth

    if ctx.invoked_subcommand is None:
        try:
            if auth_manager.is_authenticated():
                start_repl()
            else:
                show_login_message()
        except Exception as e:
            display_error(e)
            show_login_message()


@cli.command()
def login():
    app_ctx = get_app_context()
    if app_ctx is None:
        display_error(IntentError.config(
            "Failed to initialize CLI context.",
            suggestion="Check your configuration and try again.",
        ))
        sys.exit(1)

    auth_manager = app_ctx.auth
    api_client = app_ctx.api

    if auth_manager.is_authenticated():
        user = auth_manager.get_user_info()
        email = user.get("email", "Unknown") if user else "Unknown"
        console.print(f"[bold_emerald]Already logged in as {email}.[/bold_emerald]")
        console.print("[dim_stone]Run 'intent logout' first if you want to re-authenticate.[/dim_stone]")
        return

    console.print(Panel("[bold_white]Intent CLI Login[/bold_white]", style=INTENT_EMERALD))
    try:
        result = auth_manager.login()
        if result:
            try:
                credits = api_client.get_credits()
                console.print(f"Current Credits: [bold_emerald]{credits}[/bold_emerald]")
            except Exception as e:
                display_error(IntentError.credits(
                    "Could not retrieve credit balance.",
                    suggestion="The server may be temporarily unavailable.",
                    debug=str(e),
                ))
            console.print(
                "\n[bold_emerald]You are now logged in and ready to use Intent![/bold_emerald]"
            )
            console.print(
                "[dim_stone]Run 'intent' to start the interactive command mode.[/dim_stone]\n"
            )
        else:
            display_error(IntentError.auth(
                "Login failed.",
                suggestion="Check your connection and try again.",
            ))
            sys.exit(1)
    except KeyboardInterrupt:
        console.print("\n[stone]Login cancelled.[/stone]")
        sys.exit(0)
    except Exception as e:
        display_error(e)
        sys.exit(1)


@cli.command()
def logout():
    app_ctx = get_app_context()
    if app_ctx is None:
        display_error(IntentError.config(
            "Failed to initialize CLI context.",
            suggestion="Check your configuration and try again.",
        ))
        sys.exit(1)

    auth_manager = app_ctx.auth

    user = auth_manager.get_user_info()
    email = user.get("email", "User") if user else "User"
    auth_manager.logout()
    console.print("[bold_emerald]Logged out successfully.[/bold_emerald]")
    console.print(f"[dim_stone]Session for {email} has been terminated.[/dim_stone]")


@cli.command()
def status():
    app_ctx = get_app_context()
    if app_ctx is None:
        display_error(IntentError.config(
            "Failed to initialize CLI context.",
            suggestion="Check your configuration and try again.",
        ))
        sys.exit(1)

    auth_manager = app_ctx.auth
    api_client = app_ctx.api

    token = auth_manager.get_token()
    if not token:
        display_error(IntentError.auth(
            "Not logged in.",
            suggestion="Run 'intent login' to authenticate.",
        ))
        sys.exit(1)

    user = auth_manager.get_user_info()
    if not user:
        display_error(IntentError.auth(
            "Session token is invalid.",
            suggestion="Run 'intent login' to authenticate again.",
        ))
        sys.exit(1)

    console.print(Panel("[bold_white]Intent CLI Status[/bold_white]", style=INTENT_EMERALD))
    email = user.get("email", "Unknown")
    console.print(f"Authenticated as: [bold_emerald]{email}[/bold_emerald]")

    try:
        credits = api_client.get_credits()
        console.print(f"Credits: [bold_emerald]{credits}[/bold_emerald]")
        console.print("Status: [bold_emerald]Online[/bold_emerald]")
    except Exception as e:
        display_error(IntentError.credits(
            "Could not retrieve credit balance.",
            suggestion="The server may be temporarily unavailable.",
            debug=str(e),
        ))
        console.print("Status: [stone]Degraded[/stone]")


@cli.command(name="act", hidden=True)
@click.argument("instruction", nargs=-1)
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.option(
    "--confirm", "-c", is_flag=True, help="Require confirmation before execution"
)
@click.option(
    "--dry-run",
    "-d",
    is_flag=True,
    help="Generate code without executing it",
)
def act(instruction, verbose, confirm, dry_run):
    app_ctx = get_app_context()
    if app_ctx is None:
        display_error(IntentError.config(
            "Failed to initialize CLI context.",
            suggestion="Check your configuration and try again.",
        ))
        sys.exit(1)
    full_instruction = " ".join(instruction)

    result = run_instruction(
        app_ctx,
        full_instruction,
        confirm_mode=confirm,
        dry_run=dry_run,
    )

    if result.success:
        console.print("[bold_emerald]✓ Task Completed Successfully![/bold_emerald]")
    else:
        if result.error:
            display_error(result.error, verbose=verbose or is_verbose())
        elif result.message:
            console.print(f"[bold_rose]✗ {result.message}[/bold_rose]")


def show_login_message():
    console.print()
    console.print(
        Panel(
            "[bold_stone]You are not authenticated.[/bold_stone]\n\n"
            "To use Intent CLI, you need to log in first.\n\n"
            "Run the following command to authenticate:\n"
            f"[bold {INTENT_EMERALD}] intent login[/]\n\n"
            "This will open your browser to complete authentication.",
            title="Intent CLI",
            border_style=PANEL_BORDER_WARN,
        )
    )
    console.print()


def start_repl():
    app_ctx = get_app_context()
    if app_ctx is None:
        display_error(IntentError.config(
            "Failed to initialize CLI context.",
            suggestion="Check your configuration and try again.",
        ))
        return

    auth_manager = app_ctx.auth
    api_client = app_ctx.api

    user_info = auth_manager.get_user_info()
    if not user_info:
        display_error(IntentError.auth(
            "Authentication failed or session expired.",
            suggestion="Run 'intent login' to authenticate.",
        ))
        return

    email = user_info.get("email", "User")

    try:
        credits = api_client.get_credits()
        credits_text = f"[bold {INTENT_EMERALD}]{credits}[/]"
    except Exception:
        credits = None
        credits_text = "[stone]—[/]"

    from intent.core.config import Config

    # Truncate long emails so they don't break the single-line status row.
    display_email = email if len(email) <= 28 else email[:25] + "…"
    model_label = Config.GEMINI_MODEL.replace("gemini-", "")

    render_banner(console)
    console.print(
        f"[italic {EMERALD_300}]desktop control through natural language[/]"
        f"   [dim_stone]· v{__version__}[/]"
    )
    console.print(
        f"[bold {EMERALD_400}]●[/] [white]{display_email}[/]"
        f"   [bold {EMERALD_400}]◆[/] {credits_text} [stone]credits[/]"
        f"   [bold {EMERALD_400}]⬡[/] [stone]{model_label}[/]"
    )
    console.print(f"[{EMERALD_700}]{'━' * 66}[/]")
    console.print(
        f"[dim_stone]▸[/] "
        f"[{INTENT_EMERALD}]\"open music\"[/]  "
        f"[{INTENT_EMERALD}]\"summarize this page\"[/]  "
        f"[{INTENT_EMERALD}]\"take a screenshot\"[/]"
    )
    console.print(f"[dim_stone]help · status · exit[/]")
    console.print()

    while True:
        try:
            try:
                command = Prompt.ask(f"[bold {INTENT_EMERALD}]{PROMPT_SYMBOL}[/]").strip()
            except (EOFError, KeyboardInterrupt):
                console.print("\n[stone]Goodbye![/stone]\n")
                break

            if not command:
                continue

            if command.lower() in ["exit", "quit", "q"]:
                console.print("[stone]Goodbye![/stone]\n")
                break

            elif command.lower() in ["help", "h"]:
                show_help()
                continue

            elif command.lower() == "status":
                show_status()
                continue

            elif command.lower() == "logout":
                auth_manager.logout()
                console.print(
                    "[bold_emerald]Logged out. Exiting interactive mode.[/bold_emerald]\n"
                )
                break

            execute_command(command)

        except KeyboardInterrupt:
            console.print("\n[stone]Command cancelled. Type 'exit' to quit.[/stone]")
            continue
        except Exception as e:
            display_error(e)
            continue


def show_help():
    console.print()
    console.print(
        Panel(
            "[bold_white]Available Commands:[/bold_white]\n\n"
            f"[bold {INTENT_EMERALD}]help[/] or [bold {INTENT_EMERALD}]h[/] - Show this help message\n"
            f"[bold {INTENT_EMERALD}]status[/] - Show authentication status and credits\n"
            f"[bold {INTENT_EMERALD}]logout[/] - Log out and exit\n"
            f"[bold {INTENT_EMERALD}]exit[/] or [bold {INTENT_EMERALD}]quit[/] - Exit interactive mode\n\n"
            "[bold_white]Natural Language Commands:[/bold_white]\n"
            "You can type any natural language command, such as:\n"
            " · [dim_stone]open music[/dim_stone]\n"
            " · [dim_stone]click the settings icon[/dim_stone]\n"
            " · [dim_stone]type hello in the text field[/dim_stone]\n"
            " · [dim_stone]open calculator[/dim_stone]\n"
            " · [dim_stone]take a screenshot[/dim_stone]",
            title="Help",
            border_style=PANEL_BORDER,
        )
    )
    console.print()


def show_status():
    app_ctx = get_app_context()
    if app_ctx is None:
        display_error(IntentError.config(
            "Failed to initialize CLI context.",
            suggestion="Check your configuration and try again.",
        ))
        return

    auth_manager = app_ctx.auth
    api_client = app_ctx.api

    user_info = auth_manager.get_user_info()
    if not user_info:
        display_error(IntentError.auth(
            "Not authenticated.",
            suggestion="Run 'intent login' to authenticate.",
        ))
        return

    email = user_info.get("email", "Unknown")

    try:
        credits = api_client.get_credits()
        credits_status = f"[bold_emerald]{credits}[/bold_emerald]"
        status_color = INTENT_EMERALD if credits > 0 else INTENT_ROSE
        status_text = "Ready" if credits > 0 else "No credits"
    except Exception:
        credits_status = "[stone]Unable to fetch[/stone]"
        status_color = INTENT_STONE
        status_text = "Degraded"

    console.print()
    console.print(
        Panel(
            f"Authenticated as: [bold_emerald]{email}[/bold_emerald]\n"
            f"Credits: {credits_status}\n"
            f"Status: [bold {status_color}]{status_text}[/bold {status_color}]",
            title="Status",
            border_style=PANEL_BORDER,
        )
    )
    console.print()


def execute_command(command):
    app_ctx = get_app_context()
    if app_ctx is None:
        display_error(IntentError.config(
            "Failed to initialize CLI context.",
            suggestion="Check your configuration and try again.",
        ))
        return

    result = run_instruction(
        app_ctx,
        command,
        confirm_mode=False,
        dry_run=False,
        quiet=True,
    )

    if result.success:
        console.print("[bold_emerald]✓ Command completed successfully![/bold_emerald]\n")
    else:
        if result.error:
            display_error(result.error)
        elif result.message:
            console.print(f"[bold_rose]✗ {result.message}[/bold_rose]\n")


if __name__ == "__main__":
    cli()
