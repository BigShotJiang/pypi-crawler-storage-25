"""
Application composition root for the Intent CLI.

This module centralizes construction of shared services so that the CLI
surface (`intent.cli.main`) does not need to manage global singletons
directly.
"""

from __future__ import annotations

from dataclasses import dataclass

from intent.core.auth import AuthManager
from intent.core.api import APIClient


@dataclass
class AppContext:
    """Holds shared CLI services."""

    auth: AuthManager
    api: APIClient


def create_app_context() -> AppContext:
    """Create the default application context for the CLI."""
    auth = AuthManager()
    api = APIClient(auth)
    return AppContext(auth=auth, api=api)

