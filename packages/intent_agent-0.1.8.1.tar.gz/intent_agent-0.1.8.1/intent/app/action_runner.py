"""
Action runner for Intent CLI.

This module centralizes the high-level flow for executing a single
natural-language instruction, so both the Click commands and the REPL
can share the same behavior (including dry-run and confirm modes).
"""

from __future__ import annotations

from dataclasses import dataclass

from intent.agent.core import AutonomousAutomation
from intent.agent.llm import LLMClient
from intent.agent.prompts import PromptManager
from intent.agent.vision import ScreenshotCapture
from intent.app.context import AppContext
from intent.cli.errors import IntentError
from intent.cli.theme import (
    INTENT_STONE,
    console,
)


@dataclass
class RunResult:
    success: bool
    message: str = ""
    error: IntentError | None = None


class WorkingAnimation:
    def __init__(self, message="Working"):
        self.message = message
        self.dots = 0
        self.running = False

    def start(self):
        self.running = True
        self._update()

    def stop(self):
        self.running = False
        console.print("\r" + " " * (len(self.message) + 4), end="")
        console.print("\r", end="")

    def _update(self):
        if self.running:
            console.print(f"\r{self.message}{'.' * self.dots}", end="", style=INTENT_STONE)
            self.dots = (self.dots % 3) + 1


def run_instruction(
    ctx: AppContext,
    instruction: str,
    *,
    confirm_mode: bool,
    dry_run: bool,
    quiet: bool = False,
) -> RunResult:
    auth_manager = ctx.auth
    api_client = ctx.api

    if not instruction.strip():
        return RunResult(False, "Empty instruction.")

    if not auth_manager.is_authenticated():
        return RunResult(
            False,
            error=IntentError.auth(
                "Authentication required.",
                suggestion="Run 'intent login' to authenticate.",
            ),
        )

    try:
        credits = api_client.get_credits()
    except IntentError as e:
        return RunResult(False, error=e)
    except Exception as e:
        return RunResult(False, error=IntentError.from_exception(e))

    if credits <= 0:
        return RunResult(
            False,
            error=IntentError.credits(
                "Insufficient credits.",
                suggestion="Purchase more credits at intent.sh/dashboard.",
            ),
        )

    if dry_run:
        return _run_dry(ctx, instruction)

    automation = AutonomousAutomation(api_client=api_client, confirm_mode=confirm_mode, quiet=True)
    success = automation.run(instruction)

    if success:
        return RunResult(True, "Task completed successfully.")
    else:
        return RunResult(False, "Task execution failed or incomplete.")


def _run_dry(ctx: AppContext, instruction: str) -> RunResult:

    screenshot = ScreenshotCapture()
    _, screenshot_b64 = screenshot.capture()

    prompt_manager = PromptManager()
    prompt_manager.add_user_instruction(instruction, screenshot_b64)

    llm_client = LLMClient(api_client=ctx.api)
    full_response, code = llm_client.get_automation_code(
        prompt_manager.get_messages()
    )

    console.print("\rGenerated code.")
    return RunResult(True, "Dry run complete.")