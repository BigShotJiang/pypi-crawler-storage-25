import base64
import hashlib
import logging
import secrets
import time
import webbrowser

import keyring
import requests

from intent.cli.errors import IntentError, display_error
from intent.cli.theme import (
    INTENT_EMERALD,
    console,
)
from intent.core.config import Config

logger = logging.getLogger("intent.debug")

CLIENT_ID = "intent-cli"
KEYRING_SERVICE = "intent-cli"
KEYRING_USER = "session_token"
KEYRING_REFRESH_TOKEN = "refresh_token"

POLL_INTERVAL = 2
POLL_TIMEOUT = 300

# How far before expiry to proactively refresh (1 hour)
TOKEN_REFRESH_BUFFER = 60 * 60
# Minimum seconds between refresh attempts (avoid hammering the endpoint)
TOKEN_REFRESH_BACKOFF = 60

CODE_VERIFIER_MIN_LENGTH = 32


class AuthManager:

    def __init__(self):
        self._code_verifier = None

    def _generate_code_verifier(self):
        code_verifier = secrets.token_urlsafe(32)
        return code_verifier

    def _generate_code_challenge(self, code_verifier):
        digest = hashlib.sha256(code_verifier.encode("utf-8")).digest()
        code_challenge = base64.urlsafe_b64encode(digest).decode("utf-8").rstrip("=")
        return code_challenge

    def login(self):
        self._code_verifier = None

        try:
            console.print(
                f"[bold {INTENT_EMERALD}]Generating secure authentication challenge...[/]"
            )
            try:
                code_verifier = self._generate_code_verifier()
                code_challenge = self._generate_code_challenge(code_verifier)

                if not code_verifier or len(code_verifier) < CODE_VERIFIER_MIN_LENGTH:
                    return None

                if not code_challenge:
                    return None

                self._code_verifier = code_verifier

            except Exception:
                return None

            console.print(f"[bold {INTENT_EMERALD}]Requesting login session...[/]")
            response = requests.post(
                f"{Config.API_BASE_URL}/auth/cli/init",
                json={"id": CLIENT_ID, "code_challenge": code_challenge},
                timeout=10,
            )

            logger.debug("Init response status: %s", response.status_code)

            response.raise_for_status()
            session_data = response.json()

            logger.debug("Init response: session_id=%s, url=%s",
                (session_data.get("session_id") or session_data.get("code", ""))[:8],
                session_data.get("url", "")[:50],
            )

            session_id = session_data.get("session_id") or session_data.get("code")
            login_url = session_data.get("url")

            expires_in = session_data.get("expires_in")

            if not session_id or not login_url:
                display_error(IntentError.server(
                    "Invalid response from authentication server.",
                    suggestion="Try again in a moment.",
                    debug=str(session_data),
                ))
                self._code_verifier = None
                return None

            if expires_in and isinstance(expires_in, (int, float)):
                pass

        except requests.exceptions.HTTPError as e:
            self._code_verifier = None
            if e.response.status_code == 400:
                try:
                    error_detail = e.response.json().get("error", "Unknown error")
                except Exception:
                    error_detail = str(e)
                display_error(IntentError.server(
                    "Invalid request to authentication server.",
                    suggestion="Try again or contact support.",
                    debug=error_detail,
                ))
            else:
                display_error(IntentError.server(
                    "The server encountered an error.",
                    suggestion="Check your connection and try again.",
                    debug=str(e),
                ))
            return None
        except requests.exceptions.RequestException as e:
            self._code_verifier = None
            display_error(IntentError.network(
                "Unable to reach the authentication server.",
                suggestion="Check your internet connection and run 'intent login' again.",
                debug=str(e),
            ))
            return None

        # Un-indented from the except block above so it executes on a successful init
        console.print(
            "\n[bold_emerald]Opening browser for authentication...[/bold_emerald]"
        )
        console.print(f"[dim_stone]Login URL: {login_url}[/dim_stone]\n")

        webbrowser.open(login_url)

        console.print(
            "[stone]Waiting for you to complete authentication in the browser...[/stone]"
        )
        console.print("[dim_stone]Press Ctrl+C to cancel[/dim_stone]\n")

        start_time = time.time()
        poll_count = 0

        console.print(f"[{INTENT_EMERALD}]Waiting for authentication...[/{INTENT_EMERALD}]\n")

        # Added a try block to properly catch the KeyboardInterrupt at the end of the method
        try:
            while True:
                elapsed = time.time() - start_time
                # Re-indented inside the while loop
                if elapsed > POLL_TIMEOUT:
                    display_error(IntentError.auth(
                        "Authentication timed out.",
                        suggestion="Try running 'intent login' again.",
                    ))
                    self._code_verifier = None
                    return None

                try:
                    poll_response = requests.post(
                        f"{Config.API_BASE_URL}/auth/cli/poll",
                        json={"id": session_id},
                        timeout=5,
                    )

                    if poll_response.status_code == 200:
                        session_result = poll_response.json()
                        status = session_result.get("status")

                        if status == "authorized":
                            # Fixed the structural collapse inside the success condition
                            if not self._code_verifier:
                                display_error(IntentError.auth(
                                    "Security error: Code verifier is missing.",
                                    suggestion="Try running 'intent login' again.",
                                ))
                                return None

                            console.print(
                                f"\n[{INTENT_EMERALD}]Exchanging verification code for access token...[/{INTENT_EMERALD}]"
                            )

                            try:
                                exchange_response = requests.post(
                                    f"{Config.API_BASE_URL}/auth/cli/exchange",
                                    json={
                                        "session_id": session_id,
                                        "code_verifier": self._code_verifier,
                                    },
                                    timeout=10,
                                )

                                if exchange_response.status_code >= 400:
                                    try:
                                        error_body = exchange_response.json()
                                        logger.debug("Exchange error response: %s", error_body)
                                    except Exception:
                                        logger.debug("Exchange error text: %s", exchange_response.text[:200])

                                exchange_response.raise_for_status()
                                token_data = exchange_response.json()
                                access_token = token_data.get("access_token")
                                refresh_token = token_data.get("refresh_token")

                                if not access_token:
                                    display_error(IntentError.auth(
                                        "Authentication exchange failed: No token received.",
                                        suggestion="Try running 'intent login' again.",
                                    ))
                                    self._code_verifier = None
                                    return None

                                if refresh_token:
                                    self._save_refresh_token(refresh_token)

                                # Store expiry so the refresh logic knows when to refresh
                                expires_in = token_data.get("expires_in", 30 * 24 * 3600)
                                self._save_token_expiry(int(expires_in))

                            except requests.exceptions.HTTPError as e:
                                self._code_verifier = None
                                if e.response.status_code == 400:
                                    try:
                                        err_json = e.response.json()
                                        display_error(IntentError.auth(
                                            "Exchange failed: %s" % err_json.get("error"),
                                            suggestion="Try running 'intent login' again.",
                                            debug=str(err_json),
                                        ))
                                    except Exception:
                                        display_error(IntentError.auth(
                                            "Invalid verification code.",
                                            suggestion="Try running 'intent login' again.",
                                        ))
                                else:
                                    display_error(IntentError.server(
                                        "Server error during token exchange.",
                                        suggestion="Try again in a moment.",
                                        debug=str(e),
                                    ))
                                return None
                            except requests.exceptions.RequestException as e:
                                self._code_verifier = None
                                display_error(IntentError.network(
                                    "Lost connection during authentication.",
                                    suggestion="Check your network and run 'intent login' again.",
                                    debug=str(e),
                                ))
                                return None

                            self._code_verifier = None
                            self.save_token(access_token)

                            user_info = self.get_user_info()
                            if user_info:
                                email = user_info.get("email", "Unknown")
                                console.print(
                                    "\n[bold_emerald]✓ Authentication successful![/bold_emerald]"
                                )
                                console.print(
                                    f"[bold_emerald]Logged in as: {email}[/bold_emerald]\n"
                                )
                                return {"access_token": access_token, "user": user_info}
                            else:
                                console.print(
                                    "\n[bold_stone]Authentication completed but could not verify user info.[/bold_stone]"
                                )
                                return {"access_token": access_token}

                        elif status == "pending":
                            time.sleep(POLL_INTERVAL)
                            continue

                        # Restored this block into the same level as status == "authorized"
                        elif (
                            status == "expired"
                            or status == "failed"
                            or status == "rejected"
                        ):
                            display_error(IntentError.auth(
                                f"Authentication {status}.",
                                suggestion="Try running 'intent login' again.",
                            ))
                            self._code_verifier = None
                            return None

                    # Correctly tied back to the poll_response logic chain
                    elif poll_response.status_code == 404:
                        display_error(IntentError.auth(
                            "Session expired or not found.",
                            suggestion="Try running 'intent login' again.",
                        ))
                        self._code_verifier = None
                        return None

                    else:
                        poll_count += 1
                        dots = "." * ((poll_count % 4) or 4)
                        console.print(
                            f"\r[stone]Checking authentication status{dots}[/stone]",
                            end="",
                        )
                        time.sleep(POLL_INTERVAL)
                        continue

                except requests.exceptions.RequestException:
                    poll_count += 1
                    dots = "." * ((poll_count % 4) or 4)
                    console.print(
                        f"\r[stone]Connection error, retrying{dots}[/stone]",
                        end="",
                    )
                    time.sleep(POLL_INTERVAL)
                    continue

        except KeyboardInterrupt:
            console.print("\n\n[stone]Login cancelled by user.[/stone]")
            self._code_verifier = None
            return None
        except Exception as e:
            display_error(IntentError.from_exception(e))
            self._code_verifier = None
            return None

    def save_token(self, token):
        try:
            keyring.set_password(KEYRING_SERVICE, KEYRING_USER, token)
        except Exception as e:
            display_error(IntentError.config(
                "Could not save credentials to your system keychain.",
                suggestion="Check your keychain permissions.",
                debug=str(e),
            ))
            raise

    def get_token(self):
        try:
            return keyring.get_password(KEYRING_SERVICE, KEYRING_USER)
        except Exception:
            return None

    def logout(self):
        try:
            keyring.delete_password(KEYRING_SERVICE, KEYRING_USER)
        except keyring.errors.PasswordDeleteError:
            pass
        except Exception:
            pass
        try:
            keyring.delete_password(KEYRING_SERVICE, KEYRING_REFRESH_TOKEN)
        except keyring.errors.PasswordDeleteError:
            pass
        except Exception:
            pass
        console.print("[emerald]Logged out successfully.[/emerald]")

    def _save_refresh_token(self, token: str):
        try:
            keyring.set_password(KEYRING_SERVICE, KEYRING_REFRESH_TOKEN, token)
        except Exception as e:
            logger.debug("Could not save refresh token: %s", e)

    def _get_refresh_token(self):
        try:
            return keyring.get_password(KEYRING_SERVICE, KEYRING_REFRESH_TOKEN)
        except Exception:
            return None

    def _save_token_expiry(self, expires_in: int):
        """Store when the current access token expires."""
        try:
            expiry = str(time.time() + expires_in)
            keyring.set_password(KEYRING_SERVICE, "token_expires_at", expiry)
        except Exception as e:
            logger.debug("Could not save token expiry: %s", e)

    def _get_token_expiry(self) -> float:
        """Return the epoch timestamp when the current access token expires, or 0."""
        try:
            val = keyring.get_password(KEYRING_SERVICE, "token_expires_at")
            return float(val) if val else 0.0
        except Exception:
            return 0.0

    def _refresh_token_if_needed(self) -> bool:
        """Attempt a token refresh if the access token is near expiry or already expired.

        Returns True if the caller should proceed (either token is still valid, or
        a refresh succeeded). Returns False only when a refresh was attempted and
        the server explicitly rejected the refresh token (force re-login).
        """
        refresh_token = self._get_refresh_token()
        if not refresh_token:
            # No refresh token stored — cannot refresh, but don't force logout
            return False

        expiry = self._get_token_expiry()
        now = time.time()

        # If token still has more than TOKEN_REFRESH_BUFFER seconds left, skip refresh
        if expiry and (expiry - now) > TOKEN_REFRESH_BUFFER:
            return True

        # Throttle: don't hammer the refresh endpoint faster than TOKEN_REFRESH_BACKOFF
        last_attempt = getattr(self, "_last_refresh_attempt", 0.0)
        if (now - last_attempt) < TOKEN_REFRESH_BACKOFF:
            # A refresh was attempted very recently; treat token as potentially valid
            return True

        self._last_refresh_attempt = now
        logger.debug("Attempting token refresh (expiry in %.0fs)", max(0, expiry - now))

        try:
            response = requests.post(
                f"{Config.API_BASE_URL}/auth/cli/refresh",
                json={"refresh_token": refresh_token},
                timeout=10,
            )

            if response.status_code == 401:
                # Server explicitly rejected refresh token — must re-login
                self._clear_tokens()
                return False

            response.raise_for_status()
            token_data = response.json()

            new_access_token = token_data.get("access_token")
            new_refresh_token = token_data.get("refresh_token")
            expires_in = token_data.get("expires_in", 30 * 24 * 3600)

            if new_access_token:
                self.save_token(new_access_token)
                self._save_token_expiry(int(expires_in))
            if new_refresh_token:
                self._save_refresh_token(new_refresh_token)

            logger.debug("Token refreshed successfully")
            return True

        except Exception as e:
            logger.debug("Token refresh failed: %s", e)
            # Network/server error — don't clear tokens, let the next request fail naturally
            return True

    def _clear_tokens(self):
        try:
            keyring.delete_password(KEYRING_SERVICE, KEYRING_USER)
        except Exception:
            pass
        try:
            keyring.delete_password(KEYRING_SERVICE, KEYRING_REFRESH_TOKEN)
        except Exception:
            pass

    def is_authenticated(self):
        token = self.get_token()
        if not token:
            return False

        user_info = self.get_user_info()
        if user_info is not None:
            return True

        if self._refresh_token_if_needed():
            return self.get_user_info() is not None

        return False

    def get_user_info(self):
        token = self.get_token()
        if not token:
            return None

        try:
            response = requests.get(
                f"{Config.API_BASE_URL}/me",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10,
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                self._clear_tokens()
                return None
        except Exception:
            return None