import logging
import requests

from intent.cli.errors import IntentError
from intent.cli.theme import console
from intent.core.config import Config

logger = logging.getLogger("intent.debug")


class APIClient:
    """
    Client for the Intent Web Dashboard API.
    Handles communication for credits, code generation, and status.
    """

    def __init__(self, auth_manager):
        self.auth_manager = auth_manager
        self.base_url = Config.API_BASE_URL.rstrip("/")

    def _get_headers(self):
        token = self.auth_manager.get_token()
        if not token:
            raise IntentError.auth(
                "Not authenticated.",
                suggestion="Run 'intent login' to authenticate.",
            )
        return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    def check_connection(self):
        try:
            requests.get(f"{self.base_url}/health", timeout=2)
            return True
        except Exception:
            return False

    def get_credits(self):
        try:
            response = requests.get(
                f"{self.base_url}/credits", headers=self._get_headers(), timeout=10
            )
            response.raise_for_status()
            data = response.json()
            return int(data.get("credits", 0))
        except IntentError:
            raise
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code
            if status == 401:
                raise IntentError.auth(
                    "Your session has expired.",
                    suggestion="Run 'intent login' to authenticate again.",
                    debug=str(e),
                )
            if status == 403:
                raise IntentError.auth(
                    "Access denied.",
                    suggestion="Check your account permissions.",
                    debug=str(e),
                )
            raise IntentError.server(
                f"Server returned an error (HTTP {status}).",
                suggestion="Try again in a moment.",
                debug=str(e),
            )
        except requests.exceptions.Timeout:
            raise IntentError.network(
                "Connection to the server timed out.",
                suggestion="Check your internet connection and try again.",
            )
        except requests.exceptions.ConnectionError:
            raise IntentError.network(
                "Unable to reach the Intent server.",
                suggestion="Check your internet connection and try again.",
            )
        except Exception as e:
            raise IntentError.from_exception(e)

    def log_action(self, action_type: str, details: dict):
        if not self.auth_manager.get_token():
            return

        try:
            response = requests.post(
                f"{self.base_url}/analytics",
                json={"action": action_type, "details": details},
                headers=self._get_headers(),
                timeout=5,
            )
            if response.status_code >= 400:
                logger.debug("Failed to log action: HTTP %d", response.status_code)
        except Exception as e:
            logger.debug("Could not log action: %s", e)

    def generate_content(self, messages, system_instruction=None, model_name=None):
        payload = {
            "messages": messages,
        }
        if system_instruction:
            payload["systemInstruction"] = system_instruction
        if model_name:
            payload["modelName"] = model_name

        import json as _json
        body_bytes = _json.dumps(payload).encode("utf-8")
        url = f"{self.base_url}/cli/gemini"
        logger.debug(
            "POST %s | body=%d bytes | messages=%d | sys_instr=%d chars | model=%s",
            url,
            len(body_bytes),
            len(messages),
            len(system_instruction or ""),
            model_name,
        )
        for i, m in enumerate(messages):
            content = m.get("content", "")
            if isinstance(content, list):
                summary = []
                for p in content:
                    if p.get("type") == "text":
                        summary.append(f"text({len(p.get('text',''))})")
                    elif p.get("type") == "image_url":
                        url_val = p.get("image_url", {}).get("url", "")
                        prefix = url_val[:30]
                        summary.append(f"image({len(url_val)} chars, prefix={prefix!r})")
                    else:
                        summary.append(f"unknown({p.get('type')})")
                logger.debug("  msg[%d] role=%s parts=[%s]", i, m.get("role"), ", ".join(summary))
            else:
                logger.debug("  msg[%d] role=%s str_content_len=%d", i, m.get("role"), len(str(content)))

        try:
            response = requests.post(
                url,
                data=body_bytes,
                headers=self._get_headers(),
                timeout=90,
            )
            logger.debug(
                "RESPONSE status=%d len=%d content-type=%s body=%r",
                response.status_code,
                len(response.content),
                response.headers.get("content-type"),
                response.text[:500],
            )
            response.raise_for_status()
            data = response.json()
            return data.get("text", "")
        except IntentError:
            raise
        except requests.exceptions.HTTPError as e:
            status = e.response.status_code
            if status == 401:
                raise IntentError.auth(
                    "Your session has expired.",
                    suggestion="Run 'intent login' to authenticate again.",
                    debug=str(e),
                )
            if status == 402:
                raise IntentError.credits(
                    "Insufficient credits.",
                    suggestion="Purchase more credits at intent.sh/dashboard.",
                    debug=str(e),
                )
            server_body = e.response.text if e.response else ""
            raise IntentError.server(
                f"AI generation service error (HTTP {status}): {server_body}",
                suggestion="Try again or rephrase your command.",
                debug=server_body,
            )
        except requests.exceptions.Timeout:
            raise IntentError.network(
                "AI generation request timed out.",
                suggestion="Try again — the model may be under load.",
            )
        except Exception as e:
            raise IntentError.from_exception(e)
