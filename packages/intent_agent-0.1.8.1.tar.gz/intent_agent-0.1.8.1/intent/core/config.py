"""
Configuration module for the autonomous desktop automation system.
Handles environment variables, API keys, and system settings.
"""

import os
from pathlib import Path

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


class Config:
    """Centralized configuration for the automation system."""

    # API Configuration
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

    # Intent Service Configuration
    _env_url = os.getenv("INTENT_API_URL")
    API_BASE_URL = _env_url.rstrip("/") if _env_url else "https://intentt.vercel.app/api"

    # Safety Configuration
    MAX_ITERATIONS = int(os.getenv("MAX_ITERATIONS", "20"))
    CONFIRM_BEFORE_EXECUTE = (
        os.getenv("CONFIRM_BEFORE_EXECUTE", "false").lower() == "true"
    )
    EXECUTION_TIMEOUT = int(os.getenv("EXECUTION_TIMEOUT", "30"))  # seconds
    API_REQUEST_DELAY = float(
        os.getenv("API_REQUEST_DELAY", "2.0")
    )  # seconds between API calls

    # Logging Configuration — always stored in ~/.intent regardless of CWD
    _default_log_dir = Path.home() / ".intent" / "logs"
    LOG_DIR = Path(os.getenv("LOG_DIR", str(_default_log_dir)))
    SCREENSHOT_DIR = LOG_DIR / "screenshots"
    CODE_LOG_DIR = LOG_DIR / "executed_code"
    LOG_RETENTION_DAYS = int(os.getenv("LOG_RETENTION_DAYS", "7"))

    _dirs_ensured = False

    # Track if warnings have been shown
    _warnings_shown = False

    @classmethod
    def _ensure_dirs(cls):
        """Create log directories on first use instead of at import time."""
        if not cls._dirs_ensured:
            cls.LOG_DIR.mkdir(exist_ok=True, parents=True)
            cls.SCREENSHOT_DIR.mkdir(exist_ok=True, parents=True)
            cls.CODE_LOG_DIR.mkdir(exist_ok=True, parents=True)
            cls._dirs_ensured = True

    @classmethod
    def validate(cls):
        """Validate that required configuration is present."""
        cls._ensure_dirs()
        return True

    @classmethod
    def check_config(cls):
        """Check configuration and warn about potential issues."""
        warnings = []

        if "localhost" in cls.API_BASE_URL:
            warnings.append(f"API_BASE_URL is using localhost: {cls.API_BASE_URL}")

        if warnings and not cls._warnings_shown:
            cls._warnings_shown = True

        return warnings

    @classmethod
    def get_log_file(cls, filename: str) -> Path:
        """Get a path for a log file."""
        cls._ensure_dirs()
        return cls.LOG_DIR / filename

    @classmethod
    def get_screenshot_path(cls, timestamp: str) -> Path:
        """Get a path for a screenshot file."""
        cls._ensure_dirs()
        return cls.SCREENSHOT_DIR / f"screenshot_{timestamp}.png"

    @classmethod
    def get_code_log_path(cls, timestamp: str) -> Path:
        """Get a path for a code log file."""
        cls._ensure_dirs()
        return cls.CODE_LOG_DIR / f"code_{timestamp}.py"
