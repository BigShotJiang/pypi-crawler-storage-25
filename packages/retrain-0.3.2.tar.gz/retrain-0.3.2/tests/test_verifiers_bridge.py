"""Unit tests for retrain.verifiers_bridge helper functions."""

from __future__ import annotations

import pytest

from retrain.config import TrainConfig
from retrain.verifiers_bridge import (
    _coerce_float_list,
    encode_prompt_for_sampling,
    load_examples_from_environment,
    parse_environment_args,
    prompt_preview,
)


class _DummyTokenizer:
    def apply_chat_template(self, messages, add_generation_prompt=True, tokenize=True):
        # Stable synthetic IDs for tests.
        size = len(messages)
        return [10 + size, 20 + size]

    def encode(self, text):
        return [len(text), len(text) + 1]


class _EvalOnlyEnv:
    env_id = "primeintellect/aime2025"

    def get_dataset(self, n=-1, seed=None):
        raise ValueError("dataset is not set")


class _BrokenDatasetEnv:
    env_id = "primeintellect/broken"

    def get_dataset(self, n=-1, seed=None):
        raise RuntimeError("backend unavailable")


class TestParseEnvironmentArgs:
    def test_empty_args(self):
        assert parse_environment_args("") == {}
        assert parse_environment_args("   ") == {}
        assert parse_environment_args(None) == {}

    def test_dict_args_passthrough(self):
        assert parse_environment_args({"game": "Wordle-v0", "seed": 42}) == {
            "game": "Wordle-v0",
            "seed": 42,
        }

    def test_valid_json_object(self):
        parsed = parse_environment_args('{"game":"Wordle-v0","seed":42}')
        assert parsed == {"game": "Wordle-v0", "seed": 42}

    def test_invalid_json_raises(self):
        with pytest.raises(ValueError, match="must be valid JSON"):
            parse_environment_args("{bad-json")

    def test_non_object_json_raises(self):
        with pytest.raises(ValueError, match="JSON object"):
            parse_environment_args('["not","object"]')

    def test_non_str_non_dict_raises(self):
        with pytest.raises(ValueError, match="JSON string/object"):
            parse_environment_args(123)  # type: ignore[arg-type]


class TestPromptHelpers:
    def test_prompt_preview_string(self):
        assert prompt_preview("hello world", max_chars=5) == "hello"

    def test_prompt_preview_messages(self):
        preview = prompt_preview(
            [
                {"role": "system", "content": "You are helpful."},
                {"role": "user", "content": "Solve 2+2"},
            ]
        )
        assert "system: You are helpful." in preview
        assert "user: Solve 2+2" in preview

    def test_encode_prompt_string(self):
        tok = _DummyTokenizer()
        ids = encode_prompt_for_sampling(tok, "test prompt")
        assert ids == [11, 21]

    def test_encode_prompt_messages(self):
        tok = _DummyTokenizer()
        ids = encode_prompt_for_sampling(
            tok,
            [{"role": "user", "content": "test prompt"}],
        )
        assert ids == [11, 21]


class TestLoadExamplesFromEnvironment:
    def test_eval_only_env_has_actionable_error(self):
        cfg = TrainConfig(
            environment_provider="verifiers",
            environment_id="primeintellect/aime2025",
        )
        with pytest.raises(RuntimeError, match="does not expose a training dataset"):
            load_examples_from_environment(_EvalOnlyEnv(), cfg)

    def test_other_dataset_errors_preserve_context(self):
        cfg = TrainConfig(
            environment_provider="verifiers",
            environment_id="primeintellect/broken",
        )
        with pytest.raises(RuntimeError, match="Failed to load dataset"):
            load_examples_from_environment(_BrokenDatasetEnv(), cfg)


class TestCoerceFloatList:
    def test_none_returns_empty(self):
        assert _coerce_float_list(None) == []

    def test_non_list_returns_empty(self):
        assert _coerce_float_list(42) == []
        assert _coerce_float_list("not a list") == []

    def test_valid_floats(self):
        assert _coerce_float_list([1.5, 0.0, -0.3]) == [1.5, 0.0, -0.3]

    def test_ints_coerced_to_float(self):
        assert _coerce_float_list([1, 2, 3]) == [1.0, 2.0, 3.0]

    def test_invalid_items_become_zero(self):
        assert _coerce_float_list([1.0, "bad", None, 2.0]) == [1.0, 0.0, 0.0, 2.0]

    def test_empty_list(self):
        assert _coerce_float_list([]) == []
