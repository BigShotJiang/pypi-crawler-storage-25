"""Tests for retrain.config — TrainConfig and TOML loading."""

import warnings
from pathlib import Path

import pytest

from retrain.config import TrainConfig, load_config, parse_cli_overrides


class TestDefaults:
    def test_default_values(self):
        c = TrainConfig()
        assert c.advantage_mode == "maxrl"
        assert c.transform_mode == "gtpo_sepa"
        assert c.backend == "local"
        assert c.model == "Qwen/Qwen3-4B-Instruct-2507"
        assert c.lora_rank == 32
        assert c.max_steps == 500
        assert c.batch_size == 8
        assert c.group_size == 16
        assert c.max_tokens == 10240
        assert c.temperature == pytest.approx(0.7)
        assert c.lr == pytest.approx(4e-5)
        assert c.weight_decay == pytest.approx(0.0)
        assert c.sepa_steps == 500
        assert c.sepa_schedule == "linear"
        assert c.sepa_delay_steps == 50
        assert c.bp_enabled is False
        assert c.inference_engine == "pytorch"
        assert c.prefix_caching is True
        assert c.log_dir == "logs/train"
        assert c.uncertainty_kind == "surprisal"
        assert c.log_generations is True
        assert c.generation_log_samples_per_prompt == 1
        assert c.generation_top_surprisal_limit == 0


class TestLoadConfig:
    def test_load_minimal_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[training]\nmax_steps = 100\n')
        c = load_config(str(toml))
        assert c.max_steps == 100
        # Other defaults preserved
        assert c.batch_size == 8

    def test_all_sections(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text("""\
[algorithm]
advantage_mode = "grpo"
transform_mode = "none"

[backend]
backend = "tinker"
devices = "gpu:0,gpu:1"

[model]
model = "meta-llama/Llama-3-8B"
lora_rank = 16

[training]
max_steps = 200
batch_size = 4
group_size = 8
max_tokens = 1024
temperature = 0.9
lr = 1e-4
weight_decay = 0.01
save_every = 50

[gtpo]
beta = 0.2

[hicra]
alpha = 0.3

[sepa]
steps = 300
schedule = "auto"
delay_steps = 100
correct_rate_gate = 0.2

[inference]
engine = "vllm"
url = "http://localhost:8000"
attention_kernel = "flash"
dtype = "bf16"
kv_cache_dtype = "fp8"
prefix_caching = false

[backpressure]
enabled = true
warmup_steps = 20
ema_decay = 0.95

[logging]
log_dir = "logs/custom"
wandb_project = "my-project"
wandb_run_name = "run-1"
log_generations = false
generation_log_samples_per_prompt = 2
generation_top_surprisal_limit = 3
""")
        c = load_config(str(toml))
        assert c.advantage_mode == "grpo"
        assert c.transform_mode == "none"
        assert c.backend == "tinker"
        assert c.devices == "gpu:0,gpu:1"
        assert c.model == "meta-llama/Llama-3-8B"
        assert c.lora_rank == 16
        assert c.max_steps == 200
        assert c.batch_size == 4
        assert c.temperature == pytest.approx(0.9)
        assert c.lr == pytest.approx(1e-4)
        assert c.weight_decay == pytest.approx(0.01)
        assert c.gtpo_beta == pytest.approx(0.2)
        assert c.hicra_alpha == pytest.approx(0.3)
        assert c.sepa_steps == 300
        assert c.sepa_schedule == "auto"
        assert c.sepa_delay_steps == 100
        assert c.sepa_correct_rate_gate == pytest.approx(0.2)
        assert c.inference_engine == "vllm"
        assert c.inference_url == "http://localhost:8000"
        assert c.attention_kernel == "flash"
        assert c.inference_dtype == "bf16"
        assert c.kv_cache_dtype == "fp8"
        assert c.prefix_caching is False
        assert c.bp_enabled is True
        assert c.bp_warmup_steps == 20
        assert c.bp_ema_decay == pytest.approx(0.95)
        assert c.log_dir == "logs/custom"
        assert c.wandb_project == "my-project"
        assert c.wandb_run_name == "run-1"
        assert c.log_generations is False
        assert c.generation_log_samples_per_prompt == 2
        assert c.generation_top_surprisal_limit == 3

    def test_empty_string_ignored(self, tmp_path):
        """Empty-string TOML values should keep the default (match Mojo behavior)."""
        toml = tmp_path / "config.toml"
        toml.write_text('[model]\nmodel = ""\n')
        c = load_config(str(toml))
        assert c.model == "Qwen/Qwen3-4B-Instruct-2507"

    def test_uncertainty_kind_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[algorithm]\nuncertainty_kind = "surprisal"\n')
        c = load_config(str(toml))
        assert c.uncertainty_kind == "surprisal"

    def test_type_coercion_float_from_int(self, tmp_path):
        """TOML integer should be coerced to float for float fields."""
        toml = tmp_path / "config.toml"
        toml.write_text('[training]\ntemperature = 1\n')
        c = load_config(str(toml))
        assert c.temperature == pytest.approx(1.0)
        assert isinstance(c.temperature, float)

    def test_no_file_returns_defaults(self):
        """When no path given and no retrain.toml in cwd, returns defaults."""
        c = load_config(None)
        assert c.max_steps == 500

    def test_missing_file_raises(self):
        with pytest.raises(FileNotFoundError):
            load_config("/nonexistent/path.toml")

    def test_unknown_sections_ignored(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[unknown_section]\nfoo = "bar"\n\n[training]\nmax_steps = 42\n')
        c = load_config(str(toml))
        assert c.max_steps == 42

    def test_unknown_keys_ignored(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[training]\nmax_steps = 42\nunknown_key = "value"\n')
        c = load_config(str(toml))
        assert c.max_steps == 42

    def test_resume_from_default(self):
        c = TrainConfig()
        assert c.resume_from == ""

    def test_resume_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[resume]\nfrom = "logs/my_run"\n')
        c = load_config(str(toml))
        assert c.resume_from == "logs/my_run"

    def test_seed_default(self):
        c = TrainConfig()
        assert c.seed == -1

    def test_seed_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text("[training]\nseed = 42\n")
        c = load_config(str(toml))
        assert c.seed == 42

    def test_wandb_entity_tags_group_defaults(self):
        c = TrainConfig()
        assert c.wandb_entity == ""
        assert c.wandb_group == ""
        assert c.wandb_tags == ""

    def test_wandb_extended_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            '[logging]\n'
            'wandb_entity = "my-team"\n'
            'wandb_group = "sweep-1"\n'
            'wandb_tags = "baseline,seed42"\n'
        )
        c = load_config(str(toml))
        assert c.wandb_entity == "my-team"
        assert c.wandb_group == "sweep-1"
        assert c.wandb_tags == "baseline,seed42"

    def test_wandb_defaults_from_env(self, monkeypatch):
        monkeypatch.setenv("SOMA_WANDB_PROJECT", "soma-default")
        monkeypatch.setenv("SOMA_WANDB_ENTITY", "team-soma")
        monkeypatch.setenv("SOMA_WANDB_GROUP", "energy")
        monkeypatch.setenv("SOMA_WANDB_TAGS", "energy,rl")
        c = TrainConfig()
        assert c.wandb_project == "soma-default"
        assert c.wandb_entity == "team-soma"
        assert c.wandb_group == "energy"
        assert c.wandb_tags == "energy,rl"

    def test_toml_wandb_values_override_env(self, tmp_path, monkeypatch):
        monkeypatch.setenv("SOMA_WANDB_PROJECT", "soma-default")
        toml = tmp_path / "config.toml"
        toml.write_text('[logging]\nwandb_project = "explicit-project"\n')
        c = load_config(str(toml))
        assert c.wandb_project == "explicit-project"

    def test_new_fields_defaults(self):
        c = TrainConfig()
        assert c.top_p == pytest.approx(0.95)
        assert c.optim_beta1 == pytest.approx(0.9)
        assert c.optim_beta2 == pytest.approx(0.95)
        assert c.optim_eps == pytest.approx(1e-8)
        assert c.lora_alpha == 0
        assert c.lora_dropout == pytest.approx(0.0)
        assert c.backend_options == {}
        assert c.environment_provider == ""
        assert c.environment_id == ""
        assert c.environment_args == ""
        assert c.environment_max_turns == -1
        assert c.environment_auto_install is False
        assert c.log_generations is True
        assert c.generation_log_samples_per_prompt == 1
        assert c.generation_top_surprisal_limit == 0

    def test_generation_logging_limits_reject_negative_values(self):
        with pytest.raises(ValueError, match="generation_log_samples_per_prompt"):
            TrainConfig(generation_log_samples_per_prompt=-1)
        with pytest.raises(ValueError, match="generation_top_surprisal_limit"):
            TrainConfig(generation_top_surprisal_limit=-1)

    def test_new_fields_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            '[training]\ntop_p = 0.9\n\n'
            '[optimizer]\nbeta1 = 0.85\nbeta2 = 0.99\neps = 1e-6\n\n'
            '[lora]\nalpha = 64\ndropout = 0.05\n\n'
            '[backend]\n'
            'backend = "prime_rl"\n'
            '\n'
            '[backend.options]\n'
            'transport = "zmq"\n'
            'zmq_host = "127.0.0.1"\n'
            'zmq_port = 7777\n'
            'zmq_hwm = 32\n'
            'strict_advantages = true\n'
            'sync_wait_s = 5\n'
            'sync_poll_s = 0.5\n'
        )
        c = load_config(str(toml))
        assert c.top_p == pytest.approx(0.9)
        assert c.optim_beta1 == pytest.approx(0.85)
        assert c.optim_beta2 == pytest.approx(0.99)
        assert c.optim_eps == pytest.approx(1e-6)
        assert c.lora_alpha == 64
        assert c.lora_dropout == pytest.approx(0.05)
        assert c.backend_options == {
            "transport": "zmq",
            "zmq_host": "127.0.0.1",
            "zmq_port": 7777,
            "zmq_hwm": 32,
            "strict_advantages": True,
            "sync_wait_s": 5,
            "sync_poll_s": pytest.approx(0.5),
        }

    def test_legacy_prime_rl_backend_keys_raise_with_migration_hint(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            '[backend]\n'
            'backend = "prime_rl"\n'
            'prime_rl_transport = "zmq"\n'
        )
        with pytest.raises(ValueError, match="Legacy PRIME-RL keys"):
            load_config(str(toml))

    def test_backend_options_must_be_table(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[backend]\noptions = "bad"\n')
        with pytest.raises(ValueError, match="Invalid \\[backend\\]\\.options value"):
            load_config(str(toml))

    def test_environment_fields_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            '[environment]\n'
            'provider = "verifiers"\n'
            'id = "primeintellect/aime"\n'
            'args = "{\\"split\\": \\"train\\"}"\n'
            'max_turns = 8\n'
            'auto_install = true\n'
        )
        c = load_config(str(toml))
        assert c.environment_provider == "verifiers"
        assert c.environment_id == "primeintellect/aime"
        assert c.environment_args == '{"split": "train"}'
        assert c.environment_max_turns == 8
        assert c.environment_auto_install is True

    def test_environment_args_table_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            '[environment]\n'
            'provider = "verifiers"\n'
            'id = "primeintellect/aime"\n'
            'args = { split = "train", seed = 7 }\n'
        )
        c = load_config(str(toml))
        assert c.environment_provider == "verifiers"
        assert c.environment_id == "primeintellect/aime"
        assert c.environment_args == '{"split": "train", "seed": 7}'

    def test_algorithm_params_tables_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            '[algorithm]\n'
            'algorithm_mode = "custom_algorithms.my_algo"\n'
            '\n[algorithm.params]\n'
            "alpha = 0.2\n"
            '\n[algorithm.advantage_params]\n'
            "scale = 3\n"
            '\n[algorithm.transform_params]\n'
            "cap = 0.1\n"
        )
        c = load_config(str(toml))
        assert c.algorithm_mode == "custom_algorithms.my_algo"
        assert c.algorithm_params == {"alpha": pytest.approx(0.2)}
        assert c.advantage_params == {"scale": 3}
        assert c.transform_params == {"cap": pytest.approx(0.1)}

    def test_plugins_section_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            "[plugins]\n"
            'search_paths = ["plugins", "lab_plugins"]\n'
            "strict = false\n"
        )
        c = load_config(str(toml))
        assert c.plugins_search_paths == ["plugins", "lab_plugins"]
        assert c.plugins_strict is False


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

class TestValidation:
    def test_algorithm_mode_builtin_accepted(self):
        c = TrainConfig(algorithm_mode="maxrl_gtpo")
        assert c.algorithm_mode == "maxrl_gtpo"

    def test_dotted_algorithm_mode_accepted(self):
        c = TrainConfig(algorithm_mode="custom_algorithms.my_algo")
        assert c.algorithm_mode == "custom_algorithms.my_algo"

    def test_invalid_algorithm_mode_raises(self):
        with pytest.raises(ValueError, match="Invalid algorithm_mode"):
            TrainConfig(algorithm_mode="bad")

    def test_invalid_advantage_mode_raises(self):
        with pytest.raises(ValueError, match="Invalid advantage_mode"):
            TrainConfig(advantage_mode="invalid")

    def test_invalid_transform_mode_raises(self):
        with pytest.raises(ValueError, match="Invalid transform_mode"):
            TrainConfig(transform_mode="typo")

    def test_valid_modes_accepted(self):
        for am in ("grpo", "maxrl"):
            for tm in (
                "none",
                "gtpo",
                "entropy_mask",
                "gtpo_hicra",
                "gtpo_sepa",
                "gtpo_sepa_amp",
                "gtpo_sepa_amp_c",
            ):
                c = TrainConfig(advantage_mode=am, transform_mode=tm)
                assert c.advantage_mode == am
                assert c.transform_mode == tm

    def test_invalid_mode_from_toml_raises(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[algorithm]\nadvantage_mode = "wrong"\n')
        with pytest.raises(ValueError, match="Invalid advantage_mode"):
            load_config(str(toml))

    def test_dotted_advantage_mode_accepted(self):
        c = TrainConfig(advantage_mode="custom_advantages.hipa_like_advantages")
        assert c.advantage_mode == "custom_advantages.hipa_like_advantages"

    def test_malformed_dotted_advantage_mode_rejected(self):
        with pytest.raises(ValueError, match="Invalid advantage_mode"):
            TrainConfig(advantage_mode="custom_advantages.")

    def test_dotted_transform_mode_accepted(self):
        c = TrainConfig(transform_mode="custom_transforms.make_transform_spec")
        assert c.transform_mode == "custom_transforms.make_transform_spec"

    def test_malformed_dotted_transform_mode_rejected(self):
        with pytest.raises(ValueError, match="Invalid transform_mode"):
            TrainConfig(transform_mode="custom_transforms.")

    def test_uncertainty_kind_alias_is_canonicalized(self):
        c = TrainConfig(uncertainty_kind="entropy")
        assert c.uncertainty_kind == "shannon_entropy"

    def test_invalid_uncertainty_kind_raises(self):
        with pytest.raises(ValueError, match="Unknown uncertainty kind"):
            TrainConfig(uncertainty_kind="mystery_metric")

    def test_invalid_environment_provider_raises(self):
        with pytest.raises(ValueError, match="Invalid environment_provider"):
            TrainConfig(environment_provider="unknown")

    def test_environment_provider_requires_id(self):
        with pytest.raises(ValueError, match="environment_id is required"):
            TrainConfig(environment_provider="verifiers", environment_id="")

    def test_environment_args_must_be_object_when_provider_set(self):
        with pytest.raises(ValueError, match="must decode to a JSON object"):
            TrainConfig(
                environment_provider="verifiers",
                environment_id="primeintellect/aime",
                environment_args='["not","an","object"]',
            )

    def test_backend_options_unknown_key_raises(self):
        with pytest.raises(ValueError, match="Unknown \\[backend\\.options\\] key"):
            TrainConfig(
                backend="prime_rl",
                backend_options={"tranport": "filesystem"},
            )

    def test_backend_options_choice_validation_raises(self):
        with pytest.raises(ValueError, match="must be one of"):
            TrainConfig(
                backend="prime_rl",
                backend_options={"transport": "http"},
            )

    def test_backend_options_range_validation_raises(self):
        with pytest.raises(ValueError, match="must be in \\[1, 65535\\]"):
            TrainConfig(
                backend="prime_rl",
                backend_options={"zmq_port": 0},
            )

    def test_prime_rl_strict_advantages_false_rejected(self):
        with pytest.raises(ValueError, match="strict_advantages=false is disallowed"):
            TrainConfig(
                backend="prime_rl",
                backend_options={"strict_advantages": False},
            )

    def test_backend_options_accepts_dotted_plugin_backend(self):
        c = TrainConfig(
            backend="my_backend.Factory",
            backend_options={"custom_flag": "x", "num_workers": 4},
        )
        assert c.backend_options == {"custom_flag": "x", "num_workers": 4}

    def test_plugin_search_paths_validation(self):
        with pytest.raises(ValueError, match="plugins_search_paths"):
            TrainConfig(plugins_search_paths=["", "ok"])


# ---------------------------------------------------------------------------
# CLI parsing
# ---------------------------------------------------------------------------


class TestCLIParsing:
    def test_positional_and_flags(self):
        path, overrides = parse_cli_overrides(["config.toml", "--seed", "42"])
        assert path == "config.toml"
        assert overrides == {"seed": "42"}

    def test_flags_only(self):
        path, overrides = parse_cli_overrides(["--seed", "42", "--lr", "1e-4"])
        assert path is None
        assert overrides == {"seed": "42", "lr": "1e-4"}

    def test_flag_equals_syntax(self):
        path, overrides = parse_cli_overrides(["--seed=42"])
        assert path is None
        assert overrides == {"seed": "42"}

    def test_unknown_flag_exits(self):
        with pytest.raises(SystemExit):
            parse_cli_overrides(["--sead", "42"])

    def test_resume_alias(self):
        _, overrides = parse_cli_overrides(["--resume", "/path/to/logs"])
        assert overrides == {"resume_from": "/path/to/logs"}

    def test_kebab_to_snake(self):
        _, overrides = parse_cli_overrides(["--batch-size", "4"])
        assert overrides == {"batch_size": "4"}

    def test_plugin_param_flags(self):
        _, overrides = parse_cli_overrides(
            [
                "--algorithm-param",
                "alpha=0.2",
                "--advantage-param",
                "scale=3",
                "--transform-param",
                "enabled=true",
            ]
        )
        assert overrides["algorithm_params"] == {"alpha": pytest.approx(0.2)}
        assert overrides["advantage_params"] == {"scale": 3}
        assert overrides["transform_params"] == {"enabled": True}

    def test_backend_opt_repeated(self):
        _, overrides = parse_cli_overrides(
            [
                "--backend-opt",
                "transport=zmq",
                "--backend-opt=zmq_port=7777",
            ]
        )
        assert overrides == {
            "backend_options": {
                "transport": "zmq",
                "zmq_port": "7777",
            }
        }

    def test_backend_opt_requires_key_value(self):
        with pytest.raises(SystemExit):
            parse_cli_overrides(["--backend-opt", "transport"])

    def test_overrides_applied_to_config(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text("[training]\nmax_steps = 200\n")
        c = load_config(str(toml), overrides={"seed": "42"})
        assert c.seed == 42
        assert c.max_steps == 200

    def test_cli_beats_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text("[training]\nmax_steps = 200\n")
        c = load_config(str(toml), overrides={"max_steps": "50"})
        assert c.max_steps == 50

    def test_bool_override(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text("")
        c = load_config(str(toml), overrides={"bp_enabled": "true"})
        assert c.bp_enabled is True

    def test_backend_opt_cli_beats_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            '[backend]\n'
            'backend = "prime_rl"\n'
            '\n'
            '[backend.options]\n'
            'transport = "filesystem"\n'
            'zmq_port = 5555\n'
        )
        c = load_config(
            str(toml),
            overrides={"backend_options": {"transport": "zmq", "zmq_port": "7777"}},
        )
        assert c.backend_options["transport"] == "zmq"
        assert c.backend_options["zmq_port"] == 7777

    def test_missing_value_exits(self):
        with pytest.raises(SystemExit):
            parse_cli_overrides(["--seed"])


# ---------------------------------------------------------------------------
# Numeric validation
# ---------------------------------------------------------------------------


class TestNumericValidation:
    def test_batch_size_zero(self):
        with pytest.raises(ValueError, match="batch_size must be > 0"):
            TrainConfig(batch_size=0)

    def test_group_size_zero(self):
        with pytest.raises(ValueError, match="group_size must be > 0"):
            TrainConfig(group_size=0)

    def test_lr_zero(self):
        with pytest.raises(ValueError, match="lr must be > 0"):
            TrainConfig(lr=0)

    def test_lr_negative(self):
        with pytest.raises(ValueError, match="lr must be > 0"):
            TrainConfig(lr=-1e-5)

    def test_max_steps_zero(self):
        with pytest.raises(ValueError, match="max_steps must be > 0"):
            TrainConfig(max_steps=0)

    def test_max_tokens_zero(self):
        with pytest.raises(ValueError, match="max_tokens must be > 0"):
            TrainConfig(max_tokens=0)

    def test_lora_rank_zero(self):
        with pytest.raises(ValueError, match="lora_rank must be > 0"):
            TrainConfig(lora_rank=0)

    def test_temperature_negative(self):
        with pytest.raises(ValueError, match="temperature must be >= 0"):
            TrainConfig(temperature=-0.1)

    def test_temperature_zero_ok(self):
        c = TrainConfig(temperature=0.0)
        assert c.temperature == 0.0

    def test_top_p_zero(self):
        with pytest.raises(ValueError, match="top_p must be in"):
            TrainConfig(top_p=0.0)

    def test_top_p_above_one(self):
        with pytest.raises(ValueError, match="top_p must be in"):
            TrainConfig(top_p=1.1)

    def test_multiple_errors_batched(self):
        with pytest.raises(ValueError) as exc_info:
            TrainConfig(batch_size=0, lr=-1)
        msg = str(exc_info.value)
        assert "batch_size" in msg
        assert "lr" in msg


# ---------------------------------------------------------------------------
# Validation warnings
# ---------------------------------------------------------------------------


class TestValidationWarnings:
    def test_default_adapter_path_does_not_warn(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            TrainConfig()
        msgs = [str(x.message) for x in w]
        assert not any("adapter_path starts with /tmp" in m for m in msgs)

    def test_tmp_adapter_warns(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            TrainConfig(adapter_path="/tmp/foo")
        msgs = [str(x.message) for x in w]
        assert any("/tmp" in m for m in msgs)

    def test_high_temperature_warns(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            TrainConfig(temperature=3.0)
        msgs = [str(x.message) for x in w]
        assert any("unusually high" in m for m in msgs)

    def test_save_every_zero_warns(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            TrainConfig(save_every=0)
        msgs = [str(x.message) for x in w]
        assert any("disables periodic" in m for m in msgs)


# ---------------------------------------------------------------------------
# Entropy mask rho
# ---------------------------------------------------------------------------


class TestSurprisalMaskRho:
    def test_default_value(self):
        c = TrainConfig()
        assert c.surprisal_mask_rho == pytest.approx(0.0)

    def test_toml_loading_new_key(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[algorithm]\nsurprisal_mask_rho = 0.2\n')
        c = load_config(str(toml))
        assert c.surprisal_mask_rho == pytest.approx(0.2)

    def test_toml_loading_legacy_key(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[algorithm]\nentropy_mask_rho = 0.2\n')
        c = load_config(str(toml))
        assert c.surprisal_mask_rho == pytest.approx(0.2)

    def test_out_of_range_negative(self):
        with pytest.raises(ValueError, match="surprisal_mask_rho"):
            TrainConfig(surprisal_mask_rho=-0.1)

    def test_out_of_range_above_one(self):
        with pytest.raises(ValueError, match="surprisal_mask_rho"):
            TrainConfig(surprisal_mask_rho=1.1)

    def test_boundary_zero(self):
        c = TrainConfig(surprisal_mask_rho=0.0)
        assert c.surprisal_mask_rho == 0.0

    def test_boundary_one(self):
        c = TrainConfig(surprisal_mask_rho=1.0)
        assert c.surprisal_mask_rho == 1.0

    def test_post_process_params_property(self):
        c = TrainConfig(surprisal_mask_rho=0.3)
        params = c.post_process_params
        assert params["surprisal_mask_rho"] == 0.3
        assert params["entropy_mask_rho"] == 0.3  # backward-compat alias

    def test_post_process_params_default(self):
        c = TrainConfig()
        params = c.post_process_params
        assert params["surprisal_mask_rho"] == 0.0
        assert params["entropy_mask_rho"] == 0.0


# ---------------------------------------------------------------------------
# Ratio clipping config
# ---------------------------------------------------------------------------


class TestClipEpsConfig:
    def test_defaults(self):
        c = TrainConfig()
        assert c.clip_eps == pytest.approx(0.0)
        assert c.clip_eps_high == pytest.approx(0.0)

    def test_valid_symmetric(self):
        c = TrainConfig(clip_eps=0.2)
        assert c.clip_eps == pytest.approx(0.2)
        assert c.clip_eps_high == pytest.approx(0.0)

    def test_valid_asymmetric(self):
        c = TrainConfig(clip_eps=0.2, clip_eps_high=0.28)
        assert c.clip_eps == pytest.approx(0.2)
        assert c.clip_eps_high == pytest.approx(0.28)

    def test_negative_clip_eps_raises(self):
        with pytest.raises(ValueError, match="clip_eps must be >= 0"):
            TrainConfig(clip_eps=-0.1)

    def test_negative_clip_eps_high_raises(self):
        with pytest.raises(ValueError, match="clip_eps_high must be >= 0"):
            TrainConfig(clip_eps=0.2, clip_eps_high=-0.1)

    def test_clip_eps_high_without_clip_eps_raises(self):
        with pytest.raises(ValueError, match="clip_eps_high > 0 requires clip_eps > 0"):
            TrainConfig(clip_eps=0.0, clip_eps_high=0.28)

    def test_clip_eps_non_local_warns(self):
        """clip_eps warns for backends other than local and tinker."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            TrainConfig(clip_eps=0.2, backend="prime_rl")
        msgs = [str(x.message) for x in w]
        assert any("ratio clipping is only implemented in the local and tinker backends" in m for m in msgs)

    def test_clip_eps_tinker_no_warn(self):
        """clip_eps on tinker backend should NOT warn (PPO loss supported)."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            TrainConfig(clip_eps=0.2, backend="tinker")
        msgs = [str(x.message) for x in w]
        assert not any("ratio clipping" in m for m in msgs)

    def test_clip_eps_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[training]\nclip_eps = 0.2\nclip_eps_high = 0.28\n')
        c = load_config(str(toml))
        assert c.clip_eps == pytest.approx(0.2)
        assert c.clip_eps_high == pytest.approx(0.28)

    def test_clip_eps_cli_override(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text("")
        c = load_config(str(toml), overrides={"clip_eps": "0.2", "clip_eps_high": "0.28"})
        assert c.clip_eps == pytest.approx(0.2)
        assert c.clip_eps_high == pytest.approx(0.28)


class TestAdvClipMaxConfig:
    def test_default(self):
        c = TrainConfig()
        assert c.adv_clip_max == pytest.approx(0.0)

    def test_valid(self):
        c = TrainConfig(adv_clip_max=5.0)
        assert c.adv_clip_max == pytest.approx(5.0)

    def test_negative_raises(self):
        with pytest.raises(ValueError, match="adv_clip_max must be >= 0"):
            TrainConfig(adv_clip_max=-1.0)

    def test_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[training]\nadv_clip_max = 5.0\n')
        c = load_config(str(toml))
        assert c.adv_clip_max == pytest.approx(5.0)


class TestBatchAdvantageNormConfig:
    def test_default(self):
        c = TrainConfig()
        assert c.batch_advantage_norm is False

    def test_enabled(self):
        c = TrainConfig(batch_advantage_norm=True)
        assert c.batch_advantage_norm is True

    def test_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text('[training]\nbatch_advantage_norm = true\n')
        c = load_config(str(toml))
        assert c.batch_advantage_norm is True

    def test_with_reinforce_pp(self):
        """Common combination: reinforce_pp + batch_advantage_norm."""
        c = TrainConfig(advantage_mode="reinforce_pp", batch_advantage_norm=True)
        assert c.advantage_mode == "reinforce_pp"
        assert c.batch_advantage_norm is True


class TestTlGrpoConfig:
    def test_defaults(self):
        c = TrainConfig()
        assert c.tl_grpo is False
        assert c.tl_grpo_branch_size == 4

    def test_enabled(self):
        c = TrainConfig(tl_grpo=True, tl_grpo_branch_size=4)
        assert c.tl_grpo is True
        assert c.tl_grpo_branch_size == 4

    def test_branch_size_too_small_raises(self):
        with pytest.raises(ValueError, match="tl_grpo_branch_size must be >= 2"):
            TrainConfig(tl_grpo=True, tl_grpo_branch_size=1)

    def test_branch_size_unchecked_when_disabled(self):
        # No error when tl_grpo is off, even with small branch_size.
        c = TrainConfig(tl_grpo=False, tl_grpo_branch_size=1)
        assert c.tl_grpo_branch_size == 1

    def test_ema_defaults(self):
        c = TrainConfig()
        assert c.tl_grpo_ema_decay == pytest.approx(0.9)
        assert c.tl_grpo_ema_init == pytest.approx(0.5)

    def test_ema_decay_out_of_range(self):
        with pytest.raises(ValueError, match="tl_grpo_ema_decay must be > 0"):
            TrainConfig(tl_grpo=True, tl_grpo_ema_decay=0.0)
        with pytest.raises(ValueError, match="tl_grpo_ema_decay must be < 1"):
            TrainConfig(tl_grpo=True, tl_grpo_ema_decay=1.0)

    def test_ema_unchecked_when_disabled(self):
        c = TrainConfig(tl_grpo=False, tl_grpo_ema_decay=0.0)
        assert c.tl_grpo_ema_decay == pytest.approx(0.0)

    def test_from_toml(self, tmp_path):
        toml = tmp_path / "config.toml"
        toml.write_text(
            '[training]\ntl_grpo = true\ntl_grpo_branch_size = 8\n'
            'tl_grpo_ema_decay = 0.95\ntl_grpo_ema_init = 0.4\n'
        )
        c = load_config(str(toml))
        assert c.tl_grpo is True
        assert c.tl_grpo_branch_size == 8
        assert c.tl_grpo_ema_decay == pytest.approx(0.95)
        assert c.tl_grpo_ema_init == pytest.approx(0.4)
