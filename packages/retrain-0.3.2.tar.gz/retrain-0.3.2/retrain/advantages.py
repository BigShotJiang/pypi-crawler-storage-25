"""Advantage computation: GRPO, MaxRL, GTPO, HICRA, SEPA + planning tokens.

Ports the core functions from src/advantages.mojo into pure Python.
"""

from __future__ import annotations

import inspect
import math
import re
from dataclasses import dataclass, field
from collections.abc import Mapping
from functools import lru_cache
from typing import Callable, cast

from retrain.plugin_resolver import get_plugin_runtime, resolve_dotted_attribute

# Cap token surprisal values to prevent inf from poisoning downstream math.
# Real per-token surprisal (-logprob of sampled token) rarely exceeds ~15;
# 50 is a safe upper bound.
MAX_SURPRISAL = 50.0
MAX_ENTROPY = MAX_SURPRISAL  # backward-compat alias

_UNCERTAINTY_KIND_ALIASES = {
    "surprisal": "surprisal",
    "token_surprisal": "surprisal",
    "neg_logprob": "surprisal",
    "negative_logprob": "surprisal",
    "nll": "surprisal",
    "shannon": "shannon_entropy",
    "entropy": "shannon_entropy",
    "token_entropy": "shannon_entropy",
    "shannon_entropy": "shannon_entropy",
    "varentropy": "varentropy",
    "predictive_variance": "predictive_variance",
    "pred_var": "predictive_variance",
    "bernoulli_variance": "predictive_variance",
}
_UNCERTAINTY_KIND_PARAM_KEYS = (
    "uncertainty_kind",
    "uncertainty_metric",
    "token_uncertainty",
)


# ---------------------------------------------------------------------------
# EntropyStats
# ---------------------------------------------------------------------------

@dataclass
class EntropyStats:
    """Summary stats for execution vs planning token-surprisal distributions.

    Note:
    Field names retain `entropy` for backward compatibility with existing logs
    and dashboards. Values are sampled-token surprisal (-logprob), not full
    Shannon entropy.
    """
    exec_mean: float = 0.0
    exec_var: float = 0.0
    exec_count: float = 0.0
    plan_mean: float = 0.0
    plan_var: float = 0.0
    plan_count: float = 0.0
    # Post-transform stats (after SEPA/entropy transform, before GTPO weighting)
    post_exec_mean: float = 0.0
    post_exec_var: float = 0.0
    post_exec_count: float = 0.0
    post_plan_mean: float = 0.0
    post_plan_var: float = 0.0
    post_plan_count: float = 0.0


@dataclass
class AdvantageResult:
    """Result of composable advantage computation."""
    token_advs: list[list[float]] = field(default_factory=list)
    has_stats: bool = False
    stats: EntropyStats = field(default_factory=EntropyStats)
    extra_metrics: dict[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class AdvantageContext:
    """Context passed to context-style advantage plugins."""

    rewards: list[float]
    params: Mapping[str, object] = field(default_factory=dict)
    step: int = 0


@dataclass
class AdvantageOutput:
    """Output container for context-style advantage plugins."""

    advantages: list[float] = field(default_factory=list)


@dataclass(frozen=True)
class TransformContext:
    """Context passed to context-style transform plugins."""

    episode_advantages: list[float]
    logprobs_G: list[list[float]]
    planning_masks_G: list[list[int]]
    sepa_lambda: float = 0.0
    params: Mapping[str, object] = field(default_factory=dict)
    step: int = 0
    gtpo_beta: float = 0.1
    hicra_alpha: float = 0.2
    token_distributions_G: list[list[list[float]]] | None = None

    def gtpo(self, advantage: float, surprisals: list[float], beta: float | None = None) -> list[float]:
        """Utility helper exposed to transform plugins."""
        return apply_gtpo_weighting(
            advantage,
            surprisals,
            beta=self.gtpo_beta if beta is None else beta,
        )

    def hicra(self, token_advs: list[float], planning_mask: list[int], alpha: float | None = None) -> list[float]:
        """Utility helper exposed to transform plugins."""
        return apply_hicra(
            token_advs,
            planning_mask,
            alpha=self.hicra_alpha if alpha is None else alpha,
        )

    def sepa_pool(self, surprisals: list[float], planning_mask: list[int], lambda_t: float | None = None) -> list[float]:
        """Utility helper exposed to transform plugins."""
        return apply_sepa_pooling(
            surprisals,
            planning_mask,
            self.sepa_lambda if lambda_t is None else lambda_t,
        )

    def sepa_amp(self, surprisals: list[float], planning_mask: list[int], lambda_t: float | None = None) -> list[float]:
        """Utility helper exposed to transform plugins."""
        return apply_sepa_amplification(
            surprisals,
            planning_mask,
            self.sepa_lambda if lambda_t is None else lambda_t,
        )


@dataclass
class TransformOutput:
    """Output container for context-style transform plugins."""

    token_advs: list[list[float]] = field(default_factory=list)
    has_stats: bool = False
    stats: EntropyStats = field(default_factory=EntropyStats)
    extra_metrics: dict[str, float] = field(default_factory=dict)
    needs_planning: bool = False
    uses_sepa_controller: bool = False


@dataclass(frozen=True)
class AlgorithmContext:
    """Context passed to full algorithm plugins."""

    rewards_G: list[float]
    logprobs_G: list[list[float]]
    planning_masks_G: list[list[int]]
    params: Mapping[str, object] = field(default_factory=dict)
    step: int = 0
    sepa_lambda: float = 0.0
    gtpo_beta: float = 0.1
    hicra_alpha: float = 0.2
    token_distributions_G: list[list[list[float]]] | None = None
    precomputed_entropies_G: list[list[float]] | None = None


@dataclass
class AlgorithmOutput:
    """Output container for full algorithm plugins."""

    token_advs: list[list[float]] = field(default_factory=list)
    has_stats: bool = False
    stats: EntropyStats = field(default_factory=EntropyStats)
    extra_metrics: dict[str, float] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Uncertainty specs (pluggable token-uncertainty signals)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class UncertaintyContext:
    """Input context for uncertainty compute functions."""

    logprobs: list[float]
    token_distributions: list[list[float]] | None = None
    precomputed_entropy: list[float] | None = None
    planning_mask: list[int] | None = None
    params: Mapping[str, object] = field(default_factory=dict)


UncertaintyComputeFn = Callable[[UncertaintyContext], list[float]]


@dataclass(frozen=True)
class UncertaintySpec:
    """Behavioral contract for uncertainty signals."""

    name: str
    compute: UncertaintyComputeFn
    needs_distributions: bool = False


# ---------------------------------------------------------------------------
# Transform specs (TOML-selectable, plugin-friendly)
# ---------------------------------------------------------------------------

EntropyTransformFn = Callable[[list[float], list[int], float], list[float]]
EpisodeAdvantageFn = Callable[[list[float]], list[float]]
EpisodeAdvantageFnWithParams = Callable[
    [list[float], Mapping[str, object]],
    list[float],
]
EpisodeAdvantageComputeFn = EpisodeAdvantageFn | EpisodeAdvantageFnWithParams
EpisodeAdvantageRunner = Callable[
    [list[float], Mapping[str, object]],
    list[float],
]
TransformContextFn = Callable[
    [TransformContext],
    TransformOutput | AdvantageResult | list[list[float]],
]
AlgorithmContextFn = Callable[
    [AlgorithmContext],
    AlgorithmOutput | AdvantageResult | list[list[float]],
]

PostProcessFn = Callable[
    [list[list[float]], list[list[float]], Mapping[str, object]],
    tuple[list[list[float]], dict[str, float]],
]


@dataclass(frozen=True)
class TransformSpec:
    """Behavioral contract for transform modes.

    `entropy_transform` can be overridden by custom plugins loaded from
    dotted-path names in TOML (e.g. `my_module.make_transform_spec`).
    `post_process` runs after GTPO weighting + HICRA, receives all token
    advantages and raw entropies, returns modified advantages and metrics.
    """

    name: str
    use_gtpo: bool = True
    needs_planning: bool = False
    uses_sepa_controller: bool = False
    apply_hicra: bool = False
    entropy_transform: EntropyTransformFn | None = None
    post_process: PostProcessFn | None = None
    compute_context: TransformContextFn | None = None


# ---------------------------------------------------------------------------
# Advantage specs (built-ins + dotted-path plugins)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AdvantageSpec:
    """Behavioral contract for episode-level advantage modes."""

    name: str
    compute: EpisodeAdvantageRunner


@dataclass(frozen=True)
class AlgorithmSpec:
    """Behavioral contract for full algorithm plugins."""

    name: str
    compute: AlgorithmContextFn
    needs_planning: bool = False
    uses_sepa_controller: bool = False


def _normalize_advantage_compute(
    compute: EpisodeAdvantageComputeFn,
) -> EpisodeAdvantageRunner:
    """Adapt a plugin function to the internal `(rewards, params)` signature."""
    try:
        sig = inspect.signature(compute)
    except (TypeError, ValueError):
        return lambda rewards, _params: compute(rewards)  # type: ignore[missing-argument]

    params = sig.parameters
    positional = [
        p
        for p in params.values()
        if p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    ]
    if len(positional) == 1 and positional[0].name in {"ctx", "context"}:
        def _run_ctx_style(
            rewards: list[float], params_map: Mapping[str, object]
        ) -> list[float]:
            out = compute(AdvantageContext(rewards=rewards, params=params_map))  # type: ignore[missing-argument, invalid-argument-type]
            if isinstance(out, AdvantageOutput):
                return out.advantages
            return out

        return _run_ctx_style

    params_arg = params.get("params")
    accepts_varkw = any(
        p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values()
    )

    if params_arg is not None and params_arg.kind in (
        inspect.Parameter.POSITIONAL_OR_KEYWORD,
        inspect.Parameter.KEYWORD_ONLY,
    ):
        if params_arg.kind is inspect.Parameter.POSITIONAL_OR_KEYWORD:
            return lambda rewards, params_map: compute(rewards, params_map)  # type: ignore[too-many-positional-arguments]
        return lambda rewards, params_map: compute(rewards, params=params_map)  # type: ignore[missing-argument, unknown-argument]

    if accepts_varkw:
        return lambda rewards, params_map: compute(rewards, params=params_map)  # type: ignore[missing-argument, unknown-argument]

    return lambda rewards, _params: compute(rewards)  # type: ignore[missing-argument]


def _coerce_advantages_output(
    raw_advantages: object, expected_len: int, mode_name: str
) -> list[float]:
    """Normalize and validate episode-level advantage output shape."""
    try:
        advantages = [float(v) for v in raw_advantages]  # type: ignore[arg-type]
    except TypeError as exc:
        raise TypeError(
            f"advantage_mode '{mode_name}' must return an iterable of floats."
        ) from exc

    if len(advantages) != expected_len:
        raise ValueError(
            f"advantage_mode '{mode_name}' returned {len(advantages)} values, "
            f"expected {expected_len}."
        )
    for idx, value in enumerate(advantages):
        if not math.isfinite(value):
            raise ValueError(
                f"advantage_mode '{mode_name}' returned non-finite value "
                f"at index {idx}: {value!r}"
            )
    return advantages


def _as_advantage_spec(
    name: str, compute: EpisodeAdvantageComputeFn
) -> AdvantageSpec:
    """Build an AdvantageSpec from a one-arg or two-arg callable."""
    return AdvantageSpec(name=name, compute=_normalize_advantage_compute(compute))


def _callable_takes_no_positional_args(obj: object) -> bool:
    """Return True when callable is likely a zero-arg factory."""
    if not callable(obj):
        return False
    try:
        sig = inspect.signature(obj)
    except (TypeError, ValueError):
        return False
    positional = [
        p
        for p in sig.parameters.values()
        if p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    ]
    accepts_varargs = any(
        p.kind is inspect.Parameter.VAR_POSITIONAL for p in sig.parameters.values()
    )
    return not positional and not accepts_varargs


def _validate_token_advs(
    token_advs: list[list[float]],
    *,
    expected_lens: list[int],
    mode_name: str,
) -> None:
    """Validate shape and numeric sanity for token-level advantages."""
    if len(token_advs) != len(expected_lens):
        raise ValueError(
            f"{mode_name} returned {len(token_advs)} sequences, "
            f"expected {len(expected_lens)}."
        )
    for seq_idx, (seq, expected_len) in enumerate(zip(token_advs, expected_lens)):
        if len(seq) != expected_len:
            raise ValueError(
                f"{mode_name} returned {len(seq)} token advantages for sequence "
                f"{seq_idx}, expected {expected_len}."
            )
        for tok_idx, value in enumerate(seq):
            if not math.isfinite(value):
                raise ValueError(
                    f"{mode_name} returned non-finite value at sequence {seq_idx}, "
                    f"token {tok_idx}: {value!r}"
                )


def _coerce_transform_output(
    raw_output: object,
    *,
    expected_lens: list[int],
    mode_name: str,
) -> AdvantageResult:
    """Normalize transform plugin output to AdvantageResult."""
    if isinstance(raw_output, AdvantageResult):
        result = raw_output
    elif isinstance(raw_output, TransformOutput):
        result = AdvantageResult(
            token_advs=raw_output.token_advs,
            has_stats=raw_output.has_stats,
            stats=raw_output.stats,
            extra_metrics=raw_output.extra_metrics,
        )
    else:
        token_advs = raw_output
        result = AdvantageResult(
            token_advs=[[float(v) for v in seq] for seq in token_advs],  # type: ignore[arg-type]
            has_stats=False,
            stats=EntropyStats(),
            extra_metrics={},
        )

    _validate_token_advs(
        result.token_advs,
        expected_lens=expected_lens,
        mode_name=mode_name,
    )
    return result


def _coerce_algorithm_output(
    raw_output: object,
    *,
    expected_lens: list[int],
    mode_name: str,
) -> AdvantageResult:
    """Normalize algorithm plugin output to AdvantageResult."""
    if isinstance(raw_output, AlgorithmOutput):
        result = AdvantageResult(
            token_advs=raw_output.token_advs,
            has_stats=raw_output.has_stats,
            stats=raw_output.stats,
            extra_metrics=raw_output.extra_metrics,
        )
    else:
        result = _coerce_transform_output(
            raw_output,
            expected_lens=expected_lens,
            mode_name=mode_name,
        )
        return result

    _validate_token_advs(
        result.token_advs,
        expected_lens=expected_lens,
        mode_name=mode_name,
    )
    return result


# ---------------------------------------------------------------------------
# 0. GRPO advantages (simple reward centering)
# ---------------------------------------------------------------------------


def compute_grpo_advantages(rewards: list[float]) -> list[float]:
    """A_i = r_i - mean(r)."""
    n = len(rewards)
    if n == 0:
        return []
    mean_r = sum(rewards) / n
    return [r - mean_r for r in rewards]


# ---------------------------------------------------------------------------
# 0b. REINFORCE++ advantages (group-mean subtraction, same as GRPO step 1)
# ---------------------------------------------------------------------------
# REINFORCE++ (Hu 2025, arxiv:2501.03262) uses the same per-group mean
# subtraction as GRPO but follows it with a global batch normalization pass.
# The episode-level computation is identical — the batch normalization is
# applied separately in the trainer via apply_batch_advantage_normalization().


def compute_reinforce_pp_advantages(rewards: list[float]) -> list[float]:
    """A_i = r_i - mean(r).

    Identical to GRPO at the per-group level. The key REINFORCE++ innovation
    is the batch-level normalization pass applied afterward — see
    ``apply_batch_advantage_normalization``.
    """
    return compute_grpo_advantages(rewards)


# ---------------------------------------------------------------------------
# 0c. Batch-level advantage normalization (REINFORCE++ step 2)
# ---------------------------------------------------------------------------


def apply_batch_advantage_normalization(
    all_advantages: list[list[float]],
    eps: float = 1e-8,
) -> tuple[list[list[float]], dict[str, float]]:
    """Normalize all non-zero advantages across the full batch.

    REINFORCE++ (Hu 2025) fixes GRPO's biased local normalization by
    normalizing advantages across the entire batch rather than within each
    prompt's group.  This makes the estimator effectively unbiased as the
    batch size grows (the bias vanishes as N→∞).

    Two-step process (per the paper):
      Step 1 (already done by advantage_mode): A' = r_i - mean_group(r)
      Step 2 (this function):
        A_norm = (A' - mean_batch(A')) / (std_batch(A') + eps)

    Only normalizes tokens with non-zero advantages (prompt tokens are padded
    with 0.0 and should not participate in batch statistics).

    Note: uses ``a != 0.0`` as a sentinel to distinguish prompt padding from
    response tokens.  This is safe because the only way a response advantage
    is exactly 0.0 is when all group rewards are identical, in which case
    exclusion from batch statistics is the correct behavior (no gradient
    signal).  If a future transform produces legitimate 0.0 advantages for
    individual response tokens, this function should be updated to accept a
    separate mask.

    Returns:
        (normalized_advantages, metrics_dict)
        metrics_dict contains batch_adv_mean, batch_adv_std, batch_adv_count.
    """
    # Collect all non-zero advantage values across the batch
    all_values: list[float] = []
    for seq in all_advantages:
        for a in seq:
            if a != 0.0:
                all_values.append(a)

    n = len(all_values)
    metrics: dict[str, float] = {
        "batch_adv_count": float(n),
        "batch_adv_mean": 0.0,
        "batch_adv_std": 0.0,
    }
    if n == 0:
        return all_advantages, metrics

    mean_val = sum(all_values) / n
    var_val = sum((v - mean_val) ** 2 for v in all_values) / n
    std_val = math.sqrt(var_val)
    metrics["batch_adv_mean"] = mean_val
    metrics["batch_adv_std"] = std_val

    # If std is near zero, all advantages are ~equal — just center them
    if std_val < eps:
        result: list[list[float]] = []
        for seq in all_advantages:
            result.append([
                (a - mean_val) if a != 0.0 else 0.0
                for a in seq
            ])
        return result, metrics

    denom = std_val + eps
    result = []
    for seq in all_advantages:
        result.append([
            (a - mean_val) / denom if a != 0.0 else 0.0
            for a in seq
        ])
    return result, metrics


# ---------------------------------------------------------------------------
# 1. MaxRL advantages (inverse success-rate reweighting)
# ---------------------------------------------------------------------------


def compute_maxrl_advantages(
    rewards: list[float], eps: float = 1e-6
) -> list[float]:
    """A_i = (r_i - mean(r)) / (mean(r) + eps). Zero if mean(r) ~ 0."""
    n = len(rewards)
    if n == 0:
        return []
    mean_r = sum(rewards) / n
    if mean_r <= eps:
        return [0.0] * n
    denom = mean_r + eps
    return [(r - mean_r) / denom for r in rewards]


# ---------------------------------------------------------------------------
# 1b. Advantage mode registry (built-ins + dotted-path plugins)
# ---------------------------------------------------------------------------

_BUILTIN_ADVANTAGE_SPECS: dict[str, AdvantageSpec] = {
    "grpo": _as_advantage_spec("grpo", compute_grpo_advantages),
    "reinforce_pp": _as_advantage_spec("reinforce_pp", compute_reinforce_pp_advantages),
    "maxrl": _as_advantage_spec("maxrl", compute_maxrl_advantages),
}

_ADVANTAGE_SPEC_CACHE: dict[str, AdvantageSpec] = {}


def register_advantage_mode(
    name: str, compute: EpisodeAdvantageComputeFn
) -> None:
    """Register or replace a short-name episode advantage mode at runtime."""
    if not name or "." in name:
        raise ValueError(
            "Advantage mode name must be non-empty and cannot contain '.'. "
            "Use dotted paths directly in TOML for external plugins."
        )
    _BUILTIN_ADVANTAGE_SPECS[name] = _as_advantage_spec(name, compute)
    _ADVANTAGE_SPEC_CACHE.pop(name, None)


def get_builtin_advantage_modes() -> list[str]:
    """Return sorted built-in advantage mode names."""
    return sorted(_BUILTIN_ADVANTAGE_SPECS)


def is_valid_advantage_mode_name(advantage_mode: str) -> bool:
    """True for built-ins or dotted plugin paths (`module.attr`)."""
    if advantage_mode in _BUILTIN_ADVANTAGE_SPECS:
        return True
    module_path, _, attr_name = advantage_mode.rpartition(".")
    return bool(module_path and attr_name)


def _load_custom_advantage_spec(dotted_path: str) -> AdvantageSpec:
    resolved = resolve_dotted_attribute(
        dotted_path,
        selector="advantage_mode",
        expected="a callable (rewards[, params]) or AdvantageSpec",
    )
    obj = resolved.obj

    if isinstance(obj, AdvantageSpec):
        return obj
    if callable(obj):
        if _callable_takes_no_positional_args(obj):
            built = obj()  # type: ignore[call-top-callable]
            if isinstance(built, AdvantageSpec):
                return built
            if callable(built):
                return _as_advantage_spec(dotted_path, built)  # type: ignore[invalid-argument-type]
            raise TypeError(
                f"advantage_mode '{dotted_path}' factory returned "
                f"{type(built).__name__}, expected AdvantageSpec or callable."
            )
        return _as_advantage_spec(dotted_path, obj)  # type: ignore[invalid-argument-type]

    raise TypeError(
        f"advantage_mode '{dotted_path}' must resolve to AdvantageSpec "
        f"or a callable, got {type(obj).__name__}."
    )


def get_advantage_spec(advantage_mode: str) -> AdvantageSpec:
    """Resolve an advantage mode to a behavior spec."""
    cached = _ADVANTAGE_SPEC_CACHE.get(advantage_mode)
    if cached is not None:
        return cached

    spec = _BUILTIN_ADVANTAGE_SPECS.get(advantage_mode)
    if spec is None:
        if "." in advantage_mode:
            spec = _load_custom_advantage_spec(advantage_mode)
        else:
            raise ValueError(
                f"Unknown advantage_mode '{advantage_mode}'. "
                f"Built-in options: {get_builtin_advantage_modes()}. "
                "For custom advantages use dotted path format "
                "(e.g. 'my_module.my_advantage')."
            )
    _ADVANTAGE_SPEC_CACHE[advantage_mode] = spec
    return spec


# ---------------------------------------------------------------------------
# 1c. Algorithm mode registry (built-ins + dotted-path plugins)
# ---------------------------------------------------------------------------


def _make_builtin_algorithm_spec(
    name: str,
    *,
    advantage_mode: str,
    transform_mode: str,
    needs_planning: bool,
    uses_sepa_controller: bool,
) -> AlgorithmSpec:
    """Create a built-in AlgorithmSpec by delegating to composable pipeline."""

    def _compute(ctx: AlgorithmContext) -> AdvantageResult:
        post_process = dict(ctx.params.get("transform_params", {}))  # type: ignore[no-matching-overload]
        if "entropy_mask_rho" in ctx.params:
            post_process.setdefault("entropy_mask_rho", ctx.params["entropy_mask_rho"])
        return compute_composable_advantages(
            rewards_G=ctx.rewards_G,
            logprobs_G=ctx.logprobs_G,
            planning_masks_G=ctx.planning_masks_G,
            # Built-in algorithm modes are fixed recipes by design.
            advantage_mode=advantage_mode,
            transform_mode=transform_mode,
            gtpo_beta=ctx.gtpo_beta,
            hicra_alpha=ctx.hicra_alpha,
            sepa_lambda=ctx.sepa_lambda,
            advantage_params=ctx.params.get("advantage_params")  # type: ignore[invalid-argument-type]
            if isinstance(ctx.params.get("advantage_params"), Mapping)
            else {},
            transform_params=ctx.params.get("transform_params")  # type: ignore[invalid-argument-type]
            if isinstance(ctx.params.get("transform_params"), Mapping)
            else {},
            step=ctx.step,
            post_process_params=post_process,
        )

    return AlgorithmSpec(
        name=name,
        compute=_compute,
        needs_planning=needs_planning,
        uses_sepa_controller=uses_sepa_controller,
    )


def _discover_softmax_probs(rewards: list[float], beta: float) -> list[float]:
    """Boltzmann probabilities over sampled returns."""
    if not rewards:
        return []
    max_r = max(rewards)
    exps = [math.exp(max(-700.0, beta * (r - max_r))) for r in rewards]
    denom = sum(exps)
    if denom <= 0.0:
        n = len(rewards)
        return [1.0 / n] * n
    return [value / denom for value in exps]


def _discover_kl_to_uniform(probs: list[float]) -> float:
    """KL(probs || uniform)."""
    n = len(probs)
    if n <= 1:
        return 0.0
    log_n = math.log(float(n))
    kl = 0.0
    for prob in probs:
        if prob > 0.0:
            kl += prob * (math.log(prob) + log_n)
    return kl


def _resolve_discover_beta(
    rewards: list[float],
    params: Mapping[str, object],
) -> tuple[float, float]:
    """Choose beta from a fixed value or a target-KL constraint."""
    n = len(rewards)
    if n <= 1:
        return 0.0, 0.0
    if max(rewards) - min(rewards) <= 1e-12:
        return 0.0, 0.0

    fixed_beta = params.get("beta")
    if isinstance(fixed_beta, (int, float)) and not isinstance(fixed_beta, bool):
        beta = max(0.0, float(fixed_beta))
        probs = _discover_softmax_probs(rewards, beta)
        return beta, _discover_kl_to_uniform(probs)

    target_kl = params.get("target_kl", params.get("discover_target_kl", 0.2))
    beta_max = params.get("beta_max", params.get("discover_beta_max", 50.0))
    search_steps = params.get("beta_search_steps", 24)

    if not isinstance(target_kl, (int, float)) or isinstance(target_kl, bool):
        target_kl = 0.2
    if not isinstance(beta_max, (int, float)) or isinstance(beta_max, bool):
        beta_max = 50.0
    if not isinstance(search_steps, int) or isinstance(search_steps, bool):
        search_steps = 24

    target = max(0.0, float(target_kl))
    hi = max(0.0, float(beta_max))
    if target == 0.0 or hi == 0.0:
        return 0.0, 0.0

    probs_hi = _discover_softmax_probs(rewards, hi)
    kl_hi = _discover_kl_to_uniform(probs_hi)
    if kl_hi <= target:
        return hi, kl_hi

    lo = 0.0
    best_beta = 0.0
    best_kl = 0.0
    for _ in range(max(search_steps, 1)):
        mid = (lo + hi) / 2.0
        probs_mid = _discover_softmax_probs(rewards, mid)
        kl_mid = _discover_kl_to_uniform(probs_mid)
        if kl_mid <= target:
            best_beta = mid
            best_kl = kl_mid
            lo = mid
        else:
            hi = mid
    return best_beta, best_kl


def _compute_discover_entropic(ctx: AlgorithmContext) -> AdvantageResult:
    """TTT-Discover-style entropic objective over sampled returns."""
    beta, beta_kl = _resolve_discover_beta(ctx.rewards_G, ctx.params)
    probs = _discover_softmax_probs(ctx.rewards_G, beta)
    n = len(probs)
    weights = [prob * n for prob in probs] if probs else [0.0] * len(ctx.rewards_G)
    episode_advantages = [weight - 1.0 for weight in weights]
    token_advs = [
        [episode_advantages[idx]] * len(logprobs)
        for idx, logprobs in enumerate(ctx.logprobs_G)
    ]
    return AdvantageResult(
        token_advs=token_advs,
        has_stats=False,
        stats=EntropyStats(),
        extra_metrics={
            "discover_beta": beta,
            "discover_kl": beta_kl,
            "discover_reward_max": max(ctx.rewards_G) if ctx.rewards_G else 0.0,
            "discover_reward_mean": (
                sum(ctx.rewards_G) / len(ctx.rewards_G) if ctx.rewards_G else 0.0
            ),
        },
    )


_BUILTIN_ALGORITHM_SPECS: dict[str, AlgorithmSpec] = {
    "discover_entropic": AlgorithmSpec(
        name="discover_entropic",
        compute=_compute_discover_entropic,
        needs_planning=False,
        uses_sepa_controller=False,
    ),
    "ttt_discover_entropic": AlgorithmSpec(
        name="ttt_discover_entropic",
        compute=_compute_discover_entropic,
        needs_planning=False,
        uses_sepa_controller=False,
    ),
    "grpo_none": _make_builtin_algorithm_spec(
        "grpo_none",
        advantage_mode="grpo",
        transform_mode="none",
        needs_planning=False,
        uses_sepa_controller=False,
    ),
    "maxrl_none": _make_builtin_algorithm_spec(
        "maxrl_none",
        advantage_mode="maxrl",
        transform_mode="none",
        needs_planning=False,
        uses_sepa_controller=False,
    ),
    "maxrl_gtpo": _make_builtin_algorithm_spec(
        "maxrl_gtpo",
        advantage_mode="maxrl",
        transform_mode="gtpo",
        needs_planning=False,
        uses_sepa_controller=False,
    ),
    "maxrl_gtpo_hicra": _make_builtin_algorithm_spec(
        "maxrl_gtpo_hicra",
        advantage_mode="maxrl",
        transform_mode="gtpo_hicra",
        needs_planning=True,
        uses_sepa_controller=False,
    ),
    "maxrl_gtpo_sepa": _make_builtin_algorithm_spec(
        "maxrl_gtpo_sepa",
        advantage_mode="maxrl",
        transform_mode="gtpo_sepa",
        needs_planning=True,
        uses_sepa_controller=True,
    ),
    "reinforce_pp_none": _make_builtin_algorithm_spec(
        "reinforce_pp_none",
        advantage_mode="reinforce_pp",
        transform_mode="none",
        needs_planning=False,
        uses_sepa_controller=False,
    ),
    "reinforce_pp_gtpo": _make_builtin_algorithm_spec(
        "reinforce_pp_gtpo",
        advantage_mode="reinforce_pp",
        transform_mode="gtpo",
        needs_planning=False,
        uses_sepa_controller=False,
    ),
    "reinforce_pp_gtpo_sepa": _make_builtin_algorithm_spec(
        "reinforce_pp_gtpo_sepa",
        advantage_mode="reinforce_pp",
        transform_mode="gtpo_sepa",
        needs_planning=True,
        uses_sepa_controller=True,
    ),
    "reinforce_pp_delight": _make_builtin_algorithm_spec(
        "reinforce_pp_delight",
        advantage_mode="reinforce_pp",
        transform_mode="delight",
        needs_planning=False,
        uses_sepa_controller=False,
    ),
    "reinforce_pp_delight_sepa": _make_builtin_algorithm_spec(
        "reinforce_pp_delight_sepa",
        advantage_mode="reinforce_pp",
        transform_mode="delight_sepa",
        needs_planning=False,
        uses_sepa_controller=True,
    ),
}

_ALGORITHM_SPEC_CACHE: dict[str, AlgorithmSpec] = {}


def register_algorithm_mode(name: str, spec_or_fn: AlgorithmSpec | AlgorithmContextFn) -> None:
    """Register or replace a short-name algorithm mode at runtime."""
    if not name or "." in name:
        raise ValueError(
            "Algorithm mode name must be non-empty and cannot contain '.'. "
            "Use dotted paths directly in TOML for external plugins."
        )
    if isinstance(spec_or_fn, AlgorithmSpec):
        spec = spec_or_fn
    elif callable(spec_or_fn):
        spec = AlgorithmSpec(name=name, compute=spec_or_fn)
    else:
        raise TypeError(
            f"Algorithm registration for '{name}' must be AlgorithmSpec "
            f"or callable, got {type(spec_or_fn).__name__}."
        )
    _BUILTIN_ALGORITHM_SPECS[name] = spec
    _ALGORITHM_SPEC_CACHE.pop(name, None)


def get_builtin_algorithm_modes() -> list[str]:
    """Return sorted built-in algorithm mode names."""
    return sorted(_BUILTIN_ALGORITHM_SPECS)


def is_valid_algorithm_mode_name(algorithm_mode: str) -> bool:
    """True for built-ins or dotted plugin paths (`module.attr`)."""
    if algorithm_mode in _BUILTIN_ALGORITHM_SPECS:
        return True
    module_path, _, attr_name = algorithm_mode.rpartition(".")
    return bool(module_path and attr_name)


def _load_custom_algorithm_spec(dotted_path: str) -> AlgorithmSpec:
    resolved = resolve_dotted_attribute(
        dotted_path,
        selector="algorithm_mode",
        expected="AlgorithmSpec, callable(ctx), or zero-arg factory",
    )
    obj = resolved.obj
    if isinstance(obj, AlgorithmSpec):
        return obj
    if callable(obj):
        if _callable_takes_no_positional_args(obj):
            built = obj()  # type: ignore[call-top-callable]
            if isinstance(built, AlgorithmSpec):
                return built
            if callable(built):
                return AlgorithmSpec(
                    name=dotted_path,
                    compute=built,  # type: ignore[invalid-argument-type]
                    needs_planning=bool(getattr(built, "needs_planning", False)),
                    uses_sepa_controller=bool(
                        getattr(built, "uses_sepa_controller", False)
                    ),
                )
            raise TypeError(
                f"algorithm_mode '{dotted_path}' factory returned "
                f"{type(built).__name__}, expected AlgorithmSpec or callable."
            )
        return AlgorithmSpec(
            name=dotted_path,
            compute=obj,  # type: ignore[invalid-argument-type]
            needs_planning=bool(getattr(obj, "needs_planning", False)),
            uses_sepa_controller=bool(
                getattr(obj, "uses_sepa_controller", False)
            ),
        )
    raise TypeError(
        f"algorithm_mode '{dotted_path}' must resolve to AlgorithmSpec "
        f"or callable, got {type(obj).__name__}."
    )


def get_algorithm_spec(algorithm_mode: str) -> AlgorithmSpec:
    """Resolve an algorithm mode to a behavior spec."""
    cached = _ALGORITHM_SPEC_CACHE.get(algorithm_mode)
    if cached is not None:
        return cached

    spec = _BUILTIN_ALGORITHM_SPECS.get(algorithm_mode)
    if spec is None:
        if "." in algorithm_mode:
            spec = _load_custom_algorithm_spec(algorithm_mode)
        else:
            raise ValueError(
                f"Unknown algorithm_mode '{algorithm_mode}'. "
                f"Built-in options: {get_builtin_algorithm_modes()}. "
                "For custom algorithms use dotted path format "
                "(e.g. 'my_module.my_algorithm')."
            )
    _ALGORITHM_SPEC_CACHE[algorithm_mode] = spec
    return spec


# ---------------------------------------------------------------------------
# 2. GTPO entropy-weighted credit assignment
# ---------------------------------------------------------------------------


def apply_gtpo_weighting(
    advantage: float, surprisals: list[float], beta: float = 0.1
) -> list[float]:
    """Surprisal-weighted token-level advantages."""
    n = len(surprisals)
    if n == 0:
        return []
    if beta == 0.0:
        return [advantage] * n

    surprisals = [min(e, MAX_SURPRISAL) for e in surprisals]
    mean_h = sum(surprisals) / n
    if mean_h < 1e-7:
        return [advantage] * n

    result = []
    for h in surprisals:
        h_norm = h / (mean_h + 1e-8)
        weight = max(0.0, 1.0 + beta * (h_norm - 1.0))
        result.append(advantage * weight)
    return result


# ---------------------------------------------------------------------------
# 2b. Delight gating (Osband 2026, arxiv:2603.14608)
# ---------------------------------------------------------------------------


def _sigmoid(x: float) -> float:
    """Numerically stable sigmoid."""
    if x > 20:
        return 1.0
    if x < -20:
        return 0.0
    return 1.0 / (1.0 + math.exp(-x))


def apply_hard_delight_gating(
    advantage: float,
    surprisals: list[float],
    k_frac: float = 0.2,
) -> list[float]:
    """Hard top-K delight gating: sign-aware binary token selection.

    Ranks tokens by surprisal. For correct rollouts (A > 0), keeps the
    top k_frac% highest-surprisal tokens (fork-points) at full advantage
    and zeros the rest. For incorrect rollouts (A < 0), keeps the bottom
    k_frac% (routine tokens) and zeros the high-surprisal "blunders".

    This produces a ~60% gradient directional change vs uniform PG
    (compared to ~5% for sigmoid DG), making it a strong enough
    intervention for the optimizer to actually respond to.

    Args:
        advantage: Episode-level advantage.
        surprisals: Per-token surprisal values (-logprob).
        k_frac: Fraction of tokens to keep (0.2 = top/bottom 20%).
    """
    n = len(surprisals)
    if n == 0 or advantage == 0.0:
        return [0.0] * n

    k = max(1, int(n * k_frac))
    # For correct rollouts: keep highest surprisal (fork-points)
    # For incorrect rollouts: keep lowest surprisal (routine tokens)
    indexed = sorted(range(n), key=lambda i: surprisals[i],
                     reverse=(advantage > 0))
    keep = set(indexed[:k])
    return [advantage if i in keep else 0.0 for i in range(n)]


def apply_hard_delight_sepa_gating(
    advantage: float,
    surprisals: list[float],
    lambda_t: float,
    k_frac: float = 0.2,
) -> list[float]:
    """SEPA-annealed hard delight gating: PG → hard-DG transition.

    Interpolates between uniform PG (λ=0) and hard top-K gating (λ=1):
        token_adv = A × [(1-λ) + λ × mask_k(t)]
    where mask_k(t) is 1 for kept tokens and 0 for zeroed tokens.
    """
    n = len(surprisals)
    if n == 0 or advantage == 0.0:
        return [0.0] * n

    lam = max(0.0, min(1.0, lambda_t))
    if lam == 0.0:
        return [advantage] * n

    k = max(1, int(n * k_frac))
    indexed = sorted(range(n), key=lambda i: surprisals[i],
                     reverse=(advantage > 0))
    keep = set(indexed[:k])
    pg_w = 1.0 - lam
    return [advantage * (pg_w + lam * (1.0 if i in keep else 0.0))
            for i in range(n)]


def _normalize_surprisals(surprisals: list[float]) -> list[float]:
    """Scale surprisals to unit-std without centering.

    Returns ℓ / std for each token. This keeps surprisals non-negative
    (preserving DG's sign semantics) while scaling them so the sigmoid
    argument covers its sensitive range.

    Centering (z-scoring) is wrong here because surprisal distributions
    are right-skewed: most tokens have z < 0 after centering, which
    inverts the gate for the majority of tokens. Scaling without
    centering preserves: high surprisal → large positive → gate opens
    for correct rollouts, closes for incorrect.
    """
    n = len(surprisals)
    if n < 2:
        return list(surprisals)
    mean_s = sum(surprisals) / n
    var_s = sum((s - mean_s) ** 2 for s in surprisals) / n
    std_s = var_s ** 0.5
    if std_s < 1e-8:
        return list(surprisals)
    return [s / std_s for s in surprisals]


def _median(values: list[float]) -> float:
    """Median of a non-empty list."""
    ordered = sorted(values)
    n = len(ordered)
    mid = n // 2
    if n % 2 == 1:
        return ordered[mid]
    return 0.5 * (ordered[mid - 1] + ordered[mid])


def _mad_scale_surprisals(surprisals: list[float]) -> list[float]:
    """Scale surprisals by robust MAD estimate without centering."""
    n = len(surprisals)
    if n < 2:
        return list(surprisals)
    med = _median(surprisals)
    abs_dev = [abs(s - med) for s in surprisals]
    mad = _median(abs_dev)
    robust_std = 1.4826 * mad
    if robust_std < 1e-8:
        return _normalize_surprisals(surprisals)
    return [s / robust_std for s in surprisals]


def _quantile(values: list[float], q: float) -> float:
    """Linear-interpolated quantile for q in [0, 1]."""
    if not values:
        return 0.0
    ordered = sorted(values)
    if q <= 0.0:
        return ordered[0]
    if q >= 1.0:
        return ordered[-1]
    pos = q * (len(ordered) - 1)
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return ordered[lo]
    frac = pos - lo
    return ordered[lo] * (1.0 - frac) + ordered[hi] * frac


def _coerce_delight_norm_mode(
    *,
    normalize: bool | None = None,
    norm_mode: str | None = None,
    default: str = "none",
) -> str:
    """Resolve Delight normalization mode from API parameters."""
    if norm_mode is not None:
        mode = norm_mode.strip().lower()
        if mode in {"none", "scale", "mad_scale"}:
            return mode
        raise ValueError(
            f"Invalid delight norm_mode '{norm_mode}'. "
            "Expected one of: none, scale, mad_scale."
        )

    if normalize is None:
        return default
    return "scale" if normalize else "none"


def _resolve_delight_norm_mode(
    params: Mapping[str, object], *, default: str
) -> str:
    """Resolve Delight normalization mode from transform params.

    `delight_norm_mode` is the primary API. `delight_normalize` remains as a
    backward-compatible boolean alias: true -> "scale", false -> "none".
    """
    raw_mode = params.get("delight_norm_mode")
    if raw_mode is not None:
        if not isinstance(raw_mode, str):
            raise ValueError("delight_norm_mode must be a string")
        return _coerce_delight_norm_mode(norm_mode=raw_mode, default=default)

    raw_normalize = params.get("delight_normalize")
    if raw_normalize is not None:
        if not isinstance(raw_normalize, bool):
            raise ValueError("delight_normalize must be a boolean")
        return _coerce_delight_norm_mode(
            normalize=raw_normalize,
            default=default,
        )

    return default


def _apply_delight_norm_mode(
    surprisals: list[float], norm_mode: str
) -> list[float]:
    """Apply the configured Delight normalization mode."""
    if norm_mode == "none":
        return list(surprisals)
    if norm_mode == "scale":
        return _normalize_surprisals(surprisals)
    if norm_mode == "mad_scale":
        return _mad_scale_surprisals(surprisals)
    raise ValueError(
        f"Invalid delight norm_mode '{norm_mode}'. Expected one of: none, scale, mad_scale."
    )


def _resolve_delight_eta_mode(
    params: Mapping[str, object], *, default: str = "fixed"
) -> str:
    """Resolve Delight eta mode from transform params."""
    raw_mode = params.get("delight_eta_mode")
    if raw_mode is None:
        raw_adaptive = params.get("delight_eta_adaptive")
        if raw_adaptive is None:
            return default
        if not isinstance(raw_adaptive, bool):
            raise ValueError("delight_eta_adaptive must be a boolean")
        return "adaptive" if raw_adaptive else "fixed"

    if not isinstance(raw_mode, str):
        raise ValueError("delight_eta_mode must be a string")
    mode = raw_mode.strip().lower()
    if mode in {"fixed", "adaptive"}:
        return mode
    raise ValueError(
        f"Invalid delight eta_mode '{raw_mode}'. Expected one of: fixed, adaptive."
    )


def _iter_delight_rollouts(
    ctx: TransformContext,
    norm_mode: str,
) -> list[tuple[float, list[float]]]:
    """Materialize normalized Delight surprisal sequences for the batch."""
    rollouts: list[tuple[float, list[float]]] = []
    for idx in range(len(ctx.logprobs_G)):
        advantage = ctx.episode_advantages[idx]
        if advantage == 0.0:
            continue
        raw_surprisals = [min(-lp, MAX_SURPRISAL) for lp in ctx.logprobs_G[idx]]
        s_values = _apply_delight_norm_mode(raw_surprisals, norm_mode)
        rollouts.append((advantage, s_values))
    return rollouts


def _compute_delight_corrected_ordering_gaps(
    rollouts: list[tuple[float, list[float]]],
    eta: float,
) -> tuple[list[float], list[float], list[float]]:
    """Return sign-corrected high-vs-low gate gaps for Delight rollouts."""
    inv_eta = 1.0 / max(eta, 1e-8)
    all_gaps: list[float] = []
    pos_gaps: list[float] = []
    neg_gaps: list[float] = []

    for advantage, s_values in rollouts:
        if len(s_values) < 2:
            continue
        rollout_pairs = [
            (s, _sigmoid(advantage * s * inv_eta))
            for s in s_values
        ]
        ordered = sorted(rollout_pairs, key=lambda p: p[0])
        half = len(ordered) // 2
        if half == 0:
            continue
        low_mean = sum(g for _, g in ordered[:half]) / half
        high_mean = sum(g for _, g in ordered[-half:]) / half
        gap = high_mean - low_mean
        corrected_gap = gap if advantage > 0 else -gap
        all_gaps.append(corrected_gap)
        if advantage > 0:
            pos_gaps.append(corrected_gap)
        else:
            neg_gaps.append(corrected_gap)

    return all_gaps, pos_gaps, neg_gaps


def _resolve_delight_eta(
    ctx: TransformContext,
    *,
    norm_mode: str,
) -> tuple[float, dict[str, float]]:
    """Resolve effective Delight eta for this batch.

    `delight_eta_mode = "adaptive"` chooses eta from the batch's current
    |A * s| logit magnitudes so the gate lands near a target neutral
    fraction, then optionally sharpens further to hit a minimum ordering gap.
    """
    eta_mode = _resolve_delight_eta_mode(ctx.params, default="fixed")
    base_eta = max(float(cast(float, ctx.params.get("delight_eta", 1.0))), 1e-8)
    ema_decay = float(cast(float, ctx.params.get("delight_eta_ema_decay", 0.0)))
    if ema_decay < 0.0 or ema_decay >= 1.0:
        raise ValueError(
            "delight_eta_ema_decay must be in [0, 1). Try: delight_eta_ema_decay = 0.8"
        )
    raw_prev_eta = ctx.params.get("delight_eta_prev")
    prev_eta: float | None = None
    if raw_prev_eta is not None:
        prev_eta = max(float(cast(float, raw_prev_eta)), 1e-8)

    if eta_mode == "fixed":
        return base_eta, {
            "dg_eta": base_eta,
            "dg_eta_adaptive": 0.0,
        }

    rollouts = _iter_delight_rollouts(ctx, norm_mode)
    if not rollouts:
        eta = base_eta
        metrics = {
            "dg_eta": eta,
            "dg_eta_adaptive": 1.0,
        }
        if prev_eta is not None and ema_decay > 0.0:
            eta = max(ema_decay * prev_eta + (1.0 - ema_decay) * eta, 1e-8)
            metrics.update({
                "dg_eta": eta,
                "dg_eta_raw": base_eta,
                "dg_eta_prev": prev_eta,
                "dg_eta_ema_decay": ema_decay,
            })
        return eta, metrics

    target_neutral = float(cast(float, ctx.params.get("delight_eta_target_neutral_frac", 0.5)))
    target_neutral = min(max(target_neutral, 0.0), 1.0)
    target_gap = max(0.0, float(cast(float, ctx.params.get("delight_eta_target_ordering_gap", 0.0))))
    eta_min = max(1e-8, float(cast(float, ctx.params.get("delight_eta_min", 0.05))))
    eta_max = max(eta_min, float(cast(float, ctx.params.get("delight_eta_max", 5.0))))
    neutral_logit = math.log(0.6 / 0.4)

    magnitudes = [
        abs(advantage * s)
        for advantage, s_values in rollouts
        for s in s_values
    ]
    if magnitudes:
        eta_raw = _quantile(magnitudes, target_neutral) / max(neutral_logit, 1e-8)
    else:
        eta_raw = base_eta
    eta_raw = min(max(eta_raw, eta_min), eta_max)
    eta = eta_raw

    if target_gap > 0.0:
        ordering_gaps, _, _ = _compute_delight_corrected_ordering_gaps(rollouts, eta)
        if ordering_gaps:
            gap_now = sum(ordering_gaps) / len(ordering_gaps)
            if gap_now < target_gap:
                ratio = max(gap_now / max(target_gap, 1e-8), 0.25)
                eta = min(max(eta * ratio, eta_min), eta_max)
    eta_raw = eta

    if prev_eta is not None and ema_decay > 0.0:
        eta = min(
            max(ema_decay * prev_eta + (1.0 - ema_decay) * eta, eta_min),
            eta_max,
        )

    metrics = {
        "dg_eta": eta,
        "dg_eta_adaptive": 1.0,
        "dg_eta_target_neutral_frac": target_neutral,
        "dg_eta_target_ordering_gap": target_gap,
        "dg_eta_min": eta_min,
        "dg_eta_max": eta_max,
    }
    if prev_eta is not None and ema_decay > 0.0:
        metrics.update({
            "dg_eta_raw": eta_raw,
            "dg_eta_prev": prev_eta,
            "dg_eta_ema_decay": ema_decay,
        })
    return eta, metrics


def apply_delight_gating(
    advantage: float,
    surprisals: list[float],
    eta: float = 1.0,
    normalize: bool | None = None,
    norm_mode: str | None = None,
) -> list[float]:
    """Delight-gated token-level advantages.

    Gates each token's advantage by σ(advantage × s / η), where σ is the
    sigmoid and s is per-token surprisal (raw or rollout-scaled).

    When normalized in "scale" mode, surprisals are divided by rollout std
    before the gate so the sigmoid operates in its sensitive region
    regardless of absolute surprisal scale. "mad_scale" uses a robust MAD
    estimate for the same purpose on outlier-heavy batches. Neither mode
    centers the values, preserving surprisal's non-negativity and DG's sign
    semantics. This is critical for instruct-tuned models where mean
    surprisal is ~0.06 (raw gate argument < 0.03 → all neutral).

    Args:
        advantage: Episode-level advantage for this sample.
        surprisals: Per-token surprisal values (-logprob).
        eta: Temperature (η=1 default; η→∞ recovers uniform weighting).
        normalize: Backward-compatible alias for norm_mode="scale".
        norm_mode: Delight normalization mode. Supported values:
            "none", "scale", "mad_scale".
    """
    n = len(surprisals)
    if n == 0:
        return []
    if advantage == 0.0:
        return [0.0] * n

    resolved_norm = _coerce_delight_norm_mode(
        normalize=normalize,
        norm_mode=norm_mode,
        default="none",
    )
    s_values = _apply_delight_norm_mode(
        [min(s, MAX_SURPRISAL) for s in surprisals],
        resolved_norm,
    )

    inv_eta = 1.0 / max(eta, 1e-8)
    result = []
    for s in s_values:
        gate = _sigmoid(advantage * s * inv_eta)
        result.append(advantage * gate)
    return result


def apply_delight_sepa_gating(
    advantage: float,
    surprisals: list[float],
    lambda_t: float,
    eta: float = 1.0,
    normalize: bool | None = None,
    norm_mode: str | None = None,
) -> list[float]:
    """SEPA-annealed delight gating: smooth PG → DG transition.

    Interpolates between uniform policy gradient (λ=0) and full delight
    gating (λ=1):

        token_adv = A_i × [(1 - λ) + λ · σ(A_i · s'_t / η)]

    where s'_t is optionally normalized surprisal. Supported normalization
    modes preserve non-negativity by scaling without centering.

    At λ=0 (early training), every token gets the same advantage (pure PG).
    At λ=1 (late training), only fork-tokens get gradient (pure DG).

    Args:
        advantage: Episode-level advantage for this sample.
        surprisals: Per-token surprisal values (-logprob).
        lambda_t: SEPA interpolation strength in [0, 1].
        eta: DG temperature (η=1 default; η→∞ recovers uniform weighting).
        normalize: Backward-compatible alias for norm_mode="scale".
        norm_mode: Delight normalization mode. Supported values:
            "none", "scale", "mad_scale".
    """
    n = len(surprisals)
    if n == 0:
        return []
    if advantage == 0.0:
        return [0.0] * n

    lam = max(0.0, min(1.0, lambda_t))
    if lam == 0.0:
        return [advantage] * n

    resolved_norm = _coerce_delight_norm_mode(
        normalize=normalize,
        norm_mode=norm_mode,
        default="none",
    )
    s_values = _apply_delight_norm_mode(
        [min(s, MAX_SURPRISAL) for s in surprisals],
        resolved_norm,
    )

    inv_eta = 1.0 / max(eta, 1e-8)
    pg_weight = 1.0 - lam
    result = []
    for s in s_values:
        gate = _sigmoid(advantage * s * inv_eta)
        blended = pg_weight + lam * gate
        result.append(advantage * blended)
    return result


# ---------------------------------------------------------------------------
# 3. HICRA planning token amplification
# ---------------------------------------------------------------------------


def apply_hicra(
    token_advs: list[float], planning_mask: list[int], alpha: float = 0.2
) -> list[float]:
    """A_HICRA(t) = A(t) + alpha * |A(t)| * mask(t)."""
    if len(token_advs) != len(planning_mask):
        raise ValueError(
            f"Length mismatch: token_advs ({len(token_advs)}) "
            f"vs planning_mask ({len(planning_mask)})"
        )
    if alpha == 0.0:
        return list(token_advs)
    return [
        a + alpha * abs(a) if m else a
        for a, m in zip(token_advs, planning_mask)
    ]


# ---------------------------------------------------------------------------
# 3b. Entropy masking (Yue et al. proxy replication)
# ---------------------------------------------------------------------------


def compute_entropy_mask_threshold(
    all_entropies: list[float], rho: float
) -> float:
    """Compute the threshold for top-ρ entropy masking.

    Returns the entropy value at the ρ-percentile boundary (descending).
    Tokens with entropy >= threshold are kept; the rest are zeroed.
    """
    if rho >= 1.0:
        return float("-inf")
    if rho <= 0.0:
        return float("inf")
    n = len(all_entropies)
    if n == 0:
        return 0.0
    sorted_desc = sorted(all_entropies, reverse=True)
    idx = max(1, int(n * rho)) - 1
    return sorted_desc[idx]


def apply_entropy_mask(
    token_advs: list[float], entropies: list[float], threshold: float
) -> list[float]:
    """Zero out advantages for tokens below the entropy threshold."""
    return [
        a if e >= threshold else 0.0
        for a, e in zip(token_advs, entropies)
    ]


def surprisal_mask_post_process(
    all_token_advs: list[list[float]],
    all_raw_surprisals: list[list[float]],
    params: Mapping[str, object],
) -> tuple[list[list[float]], dict[str, float]]:
    """Post-process hook: Yue et al. surprisal masking."""
    raw_rho = params.get("surprisal_mask_rho", params.get("entropy_mask_rho", 0.0))
    rho = float(raw_rho) if isinstance(raw_rho, int | float) else 0.0
    if rho <= 0.0:
        return all_token_advs, {}

    flat_surprisals = [e for seq in all_raw_surprisals for e in seq]
    threshold = compute_entropy_mask_threshold(flat_surprisals, rho)

    total_tokens = 0
    masked_tokens = 0
    for idx in range(len(all_token_advs)):
        all_token_advs[idx] = apply_entropy_mask(
            all_token_advs[idx], all_raw_surprisals[idx], threshold
        )
        for e in all_raw_surprisals[idx]:
            total_tokens += 1
            if e < threshold:
                masked_tokens += 1

    fraction = masked_tokens / total_tokens if total_tokens > 0 else 0.0
    return all_token_advs, {
        "entropy_mask_threshold": threshold,
        "entropy_mask_fraction": fraction,
    }


entropy_mask_post_process = surprisal_mask_post_process  # backward-compat alias


# ---------------------------------------------------------------------------
# 4. SEPA selective entropy pooling
# ---------------------------------------------------------------------------


def apply_sepa_pooling(
    surprisals: list[float], planning_mask: list[int], lambda_t: float
) -> list[float]:
    """Pull execution token surprisals toward their mean."""
    if len(surprisals) != len(planning_mask):
        raise ValueError(
            f"Length mismatch: surprisals ({len(surprisals)}) "
            f"vs planning_mask ({len(planning_mask)})"
        )
    lam = max(0.0, min(1.0, lambda_t))
    if lam == 0.0:
        return list(surprisals)

    surprisals = [min(e, MAX_SURPRISAL) for e in surprisals]
    exec_vals = [e for e, m in zip(surprisals, planning_mask) if m == 0]
    if not exec_vals:
        return list(surprisals)
    mean_h_exec = sum(exec_vals) / len(exec_vals)

    return [
        e if m else lam * mean_h_exec + (1.0 - lam) * e
        for e, m in zip(surprisals, planning_mask)
    ]


def apply_sepa_amplification(
    surprisals: list[float], planning_mask: list[int], lambda_t: float
) -> list[float]:
    """Push execution token surprisals away from their mean.

    h'_t = h_t + λ·(h_t - μ_exec) = (1+λ)·h_t - λ·μ_exec

    High-surprisal execution tokens get pushed higher (more GTPO gradient
    weight), low-surprisal ones get pushed lower. Planning tokens are
    left untouched.
    """
    if len(surprisals) != len(planning_mask):
        raise ValueError(
            f"Length mismatch: surprisals ({len(surprisals)}) "
            f"vs planning_mask ({len(planning_mask)})"
        )
    lam = max(0.0, min(1.0, lambda_t))
    if lam == 0.0:
        return list(surprisals)

    surprisals = [min(e, MAX_SURPRISAL) for e in surprisals]
    exec_vals = [e for e, m in zip(surprisals, planning_mask) if m == 0]
    if not exec_vals:
        return list(surprisals)
    mean_h_exec = sum(exec_vals) / len(exec_vals)

    return [
        e if m else (1.0 + lam) * e - lam * mean_h_exec
        for e, m in zip(surprisals, planning_mask)
    ]


def apply_sepa_amplification_clamped(
    surprisals: list[float], planning_mask: list[int], lambda_t: float
) -> list[float]:
    """Push execution token surprisals away from their mean, clamped to >= 0.

    Same as apply_sepa_amplification but floors results at zero so no token
    gets a negative surprisal value.  Keeps amplification purely soft —
    low-surprisal tokens shrink toward zero but never flip sign.
    """
    if len(surprisals) != len(planning_mask):
        raise ValueError(
            f"Length mismatch: surprisals ({len(surprisals)}) "
            f"vs planning_mask ({len(planning_mask)})"
        )
    lam = max(0.0, min(1.0, lambda_t))
    if lam == 0.0:
        return list(surprisals)

    surprisals = [min(e, MAX_SURPRISAL) for e in surprisals]
    exec_vals = [e for e, m in zip(surprisals, planning_mask) if m == 0]
    if not exec_vals:
        return list(surprisals)
    mean_h_exec = sum(exec_vals) / len(exec_vals)

    return [
        e if m else max(0.0, (1.0 + lam) * e - lam * mean_h_exec)
        for e, m in zip(surprisals, planning_mask)
    ]


# ---------------------------------------------------------------------------
# 4b. Transform mode registry (built-ins + dotted-path plugins)
# ---------------------------------------------------------------------------

def _compute_delight_gate_metrics(
    ctx: TransformContext,
    token_advs: list[list[float]],
    eta: float,
    lambda_t: float | None = None,
    norm_mode: str = "none",
) -> dict[str, float]:
    """Compute gate statistics for delight transforms.

    Collects per-token gate values σ(A·s/η) across all rollouts and
    returns summary metrics for logging/blog post diagnostics.

    When norm_mode uses scaling ("scale" or "mad_scale"), surprisals are
    rescaled without centering before computing gate values, matching what
    the actual gating does.

    Besides raw gate moments, this also logs a sign-corrected
    high-vs-low surprisal gate gap. That metric is positive when DG
    preserves its intended within-rollout ordering: high-surprisal
    tokens get larger gates for positive-advantage rollouts and smaller
    gates for negative-advantage rollouts.
    """
    all_gates: list[float] = []
    pos_gates: list[float] = []  # gates from correct rollouts (A > 0)
    neg_gates: list[float] = []  # gates from incorrect rollouts (A < 0)
    inv_eta = 1.0 / max(eta, 1e-8)
    rollouts = _iter_delight_rollouts(ctx, norm_mode)

    for advantage, s_values in rollouts:
        for s in s_values:
            gate = _sigmoid(advantage * s * inv_eta)
            all_gates.append(gate)
            if advantage > 0:
                pos_gates.append(gate)
            else:
                neg_gates.append(gate)

    if not all_gates:
        return {}

    ordering_gaps, ordering_gaps_pos, ordering_gaps_neg = (
        _compute_delight_corrected_ordering_gaps(rollouts, eta)
    )

    n = len(all_gates)
    mean_g = sum(all_gates) / n
    var_g = sum((g - mean_g) ** 2 for g in all_gates) / n
    breakthrough_frac = sum(1 for g in all_gates if g > 0.8) / n
    suppressed_frac = sum(1 for g in all_gates if g < 0.2) / n
    neutral_frac = sum(1 for g in all_gates if 0.4 <= g <= 0.6) / n

    metrics: dict[str, float] = {
        "dg_gate_mean": mean_g,
        "dg_gate_std": var_g ** 0.5,
        "dg_gate_min": min(all_gates),
        "dg_gate_max": max(all_gates),
        "dg_breakthrough_frac": breakthrough_frac,
        "dg_suppressed_frac": suppressed_frac,
        "dg_neutral_frac": neutral_frac,
    }

    if pos_gates:
        metrics["dg_gate_mean_pos"] = sum(pos_gates) / len(pos_gates)
    if neg_gates:
        metrics["dg_gate_mean_neg"] = sum(neg_gates) / len(neg_gates)
    if ordering_gaps:
        metrics["dg_gate_ordering_gap"] = (
            sum(ordering_gaps) / len(ordering_gaps)
        )
    if ordering_gaps_pos:
        metrics["dg_gate_ordering_gap_pos"] = (
            sum(ordering_gaps_pos) / len(ordering_gaps_pos)
        )
    if ordering_gaps_neg:
        metrics["dg_gate_ordering_gap_neg"] = (
            sum(ordering_gaps_neg) / len(ordering_gaps_neg)
        )
    if lambda_t is not None:
        metrics["dg_lambda"] = lambda_t

    # --- Zero-sum break: net advantage bias ---
    # With uniform PG, token_adv = A_i for each token, so the sum across
    # all tokens equals Σ(A_i × n_tokens_i). This is nonzero when the
    # batch has unequal correct/incorrect counts (natural GRPO imbalance).
    # DG's asymmetric gating ADDS to this imbalance.
    #
    # To isolate the DG-specific bias, we compute:
    #   dg_bias = Σ(actual_token_advs) - Σ(uniform_PG_token_advs)
    # This is zero when λ=0 (pure PG) and positive when DG is active.
    all_flat = [a for rollout in token_advs for a in rollout]
    if all_flat:
        n_tok = len(all_flat)
        adv_sum = sum(all_flat)
        adv_mean = adv_sum / n_tok

        # Compute what uniform PG would give (same advantage, every token)
        pg_sum = 0.0
        for idx in range(len(ctx.logprobs_G)):
            advantage = ctx.episode_advantages[idx]
            n_tokens = len(ctx.logprobs_G[idx])
            pg_sum += advantage * n_tokens

        dg_bias = adv_sum - pg_sum
        metrics["dg_net_advantage_bias"] = dg_bias
        metrics["dg_net_advantage_bias_per_token"] = dg_bias / n_tok
        adv_var = sum((a - adv_mean) ** 2 for a in all_flat) / n_tok
        metrics["dg_token_adv_std"] = adv_var ** 0.5

        # Per-rollout advantage variance (mean across rollouts):
        # how much DG differentiates tokens within a single rollout.
        # High = DG is actively selecting tokens. Low = uniform like PG.
        rollout_vars = []
        for rollout in token_advs:
            if len(rollout) < 2:
                continue
            r_mean = sum(rollout) / len(rollout)
            r_var = sum((a - r_mean) ** 2 for a in rollout) / len(rollout)
            rollout_vars.append(r_var)
        if rollout_vars:
            metrics["dg_within_rollout_adv_var"] = (
                sum(rollout_vars) / len(rollout_vars)
            )

    return metrics


def _compute_delight_transform(ctx: TransformContext) -> AdvantageResult:
    """Delightful Policy Gradient transform (Osband 2026, arxiv:2603.14608).

    Gates each token's advantage by σ(advantage × s / η) where s is raw
    surprisal or normalized surprisal according to delight_norm_mode.

    Scaling by rollout std (without centering) is critical for instruct-tuned
    models where mean surprisal is ~0.06: without it, the sigmoid argument is
    < 0.03 and 99% of tokens land in the neutral zone (gate ≈ 0.5). A robust
    `mad_scale` mode is also available for heavy-tailed batches.
    """
    norm_mode = _resolve_delight_norm_mode(ctx.params, default="none")
    eta, eta_metrics = _resolve_delight_eta(ctx, norm_mode=norm_mode)
    all_token_advs: list[list[float]] = []
    all_exec_surprisals: list[float] = []
    all_plan_surprisals: list[float] = []

    for idx in range(len(ctx.logprobs_G)):
        advantage = ctx.episode_advantages[idx]
        logprobs = ctx.logprobs_G[idx]
        planning_mask = ctx.planning_masks_G[idx]
        surprisals = [min(-lp, MAX_SURPRISAL) for lp in logprobs]

        token_advs = apply_delight_gating(
            advantage, surprisals, eta=eta, norm_mode=norm_mode
        )
        all_token_advs.append(token_advs)

        for j, s in enumerate(surprisals):
            if planning_mask[j]:
                all_plan_surprisals.append(s)
            else:
                all_exec_surprisals.append(s)

    stats = compute_surprisal_stats(all_exec_surprisals, all_plan_surprisals)
    extra = _compute_delight_gate_metrics(
        ctx, all_token_advs, eta, norm_mode=norm_mode
    )
    extra.update(eta_metrics)
    return AdvantageResult(all_token_advs, True, stats, extra_metrics=extra)


def _compute_delight_sepa_transform(ctx: TransformContext) -> AdvantageResult:
    """SEPA-annealed Delight gating: PG → DG transition over training.

    Uses the SEPA controller's lambda to interpolate between uniform PG
    (lambda=0, early training) and full DG gating (lambda=1, late training).

    delight_norm_mode (default "scale") controls how surprisals are
    normalized before gating. "scale" divides by rollout std without
    centering, while "mad_scale" uses a robust MAD estimate for
    outlier-heavy batches. delight_eta_mode can be "fixed" or "adaptive",
    and adaptive eta can be smoothed across steps with delight_eta_ema_decay.
    """
    norm_mode = _resolve_delight_norm_mode(ctx.params, default="scale")
    eta, eta_metrics = _resolve_delight_eta(ctx, norm_mode=norm_mode)
    # Allow fixed lambda override from transform_params (bypasses SEPA ramp)
    lam_override = ctx.params.get("delight_lambda")
    lam = float(cast(float, lam_override)) if lam_override is not None else ctx.sepa_lambda
    all_token_advs: list[list[float]] = []
    all_exec_surprisals: list[float] = []
    all_plan_surprisals: list[float] = []

    for idx in range(len(ctx.logprobs_G)):
        advantage = ctx.episode_advantages[idx]
        logprobs = ctx.logprobs_G[idx]
        planning_mask = ctx.planning_masks_G[idx]
        surprisals = [min(-lp, MAX_SURPRISAL) for lp in logprobs]

        token_advs = apply_delight_sepa_gating(
            advantage, surprisals, lambda_t=lam, eta=eta, norm_mode=norm_mode
        )
        all_token_advs.append(token_advs)

        for j, s in enumerate(surprisals):
            if planning_mask[j]:
                all_plan_surprisals.append(s)
            else:
                all_exec_surprisals.append(s)

    stats = compute_surprisal_stats(all_exec_surprisals, all_plan_surprisals)
    extra = _compute_delight_gate_metrics(
        ctx, all_token_advs, eta, lambda_t=lam, norm_mode=norm_mode
    )
    extra.update(eta_metrics)
    return AdvantageResult(all_token_advs, True, stats, extra_metrics=extra)


def _compute_hard_delight_transform(ctx: TransformContext) -> AdvantageResult:
    """Hard top-K delight gating: binary token selection.

    Keeps top k_frac% tokens by surprisal for correct rollouts (fork-points),
    bottom k_frac% for incorrect rollouts (routine tokens), zeros the rest.
    Produces ~60% gradient directional change vs PG (13x stronger than sigmoid DG).
    """
    k_frac = float(cast(float, ctx.params.get("delight_k_frac", 0.2)))
    lam_override = ctx.params.get("delight_lambda")
    lam = float(cast(float, lam_override)) if lam_override is not None else ctx.sepa_lambda
    all_token_advs: list[list[float]] = []
    all_exec_surprisals: list[float] = []
    all_plan_surprisals: list[float] = []

    for idx in range(len(ctx.logprobs_G)):
        advantage = ctx.episode_advantages[idx]
        logprobs = ctx.logprobs_G[idx]
        planning_mask = ctx.planning_masks_G[idx]
        surprisals = [min(-lp, MAX_SURPRISAL) for lp in logprobs]

        token_advs = apply_hard_delight_sepa_gating(
            advantage, surprisals, lambda_t=lam, k_frac=k_frac
        )
        all_token_advs.append(token_advs)

        for j, s in enumerate(surprisals):
            if planning_mask[j]:
                all_plan_surprisals.append(s)
            else:
                all_exec_surprisals.append(s)

    stats = compute_surprisal_stats(all_exec_surprisals, all_plan_surprisals)

    # Compute metrics: what fraction of tokens are active (non-zero)?
    all_flat = [a for seq in all_token_advs for a in seq]
    n_total = len(all_flat)
    n_active = sum(1 for a in all_flat if a != 0.0)
    extra: dict[str, float] = {
        "hard_dg_active_frac": n_active / max(n_total, 1),
        "hard_dg_k_frac": k_frac,
        "hard_dg_lambda": lam,
    }
    if n_total > 0:
        adv_sum = sum(all_flat)
        pg_sum = sum(
            ctx.episode_advantages[i] * len(ctx.logprobs_G[i])
            for i in range(len(ctx.logprobs_G))
        )
        extra["hard_dg_net_bias"] = adv_sum - pg_sum

    return AdvantageResult(all_token_advs, True, stats, extra_metrics=extra)


_BUILTIN_TRANSFORM_SPECS: dict[str, TransformSpec] = {
    "none": TransformSpec(name="none", use_gtpo=False),
    "delight": TransformSpec(
        name="delight",
        use_gtpo=False,
        compute_context=_compute_delight_transform,
    ),
    "delight_sepa": TransformSpec(
        name="delight_sepa",
        use_gtpo=False,
        uses_sepa_controller=True,
        compute_context=_compute_delight_sepa_transform,
    ),
    "hard_delight": TransformSpec(
        name="hard_delight",
        use_gtpo=False,
        uses_sepa_controller=True,
        compute_context=_compute_hard_delight_transform,
    ),
    "gtpo": TransformSpec(name="gtpo"),
    "entropy_mask": TransformSpec(name="entropy_mask", use_gtpo=True, post_process=surprisal_mask_post_process),
    "gtpo_hicra": TransformSpec(
        name="gtpo_hicra", needs_planning=True, apply_hicra=True
    ),
    "gtpo_sepa": TransformSpec(
        name="gtpo_sepa",
        needs_planning=True,
        uses_sepa_controller=True,
        entropy_transform=apply_sepa_pooling,
    ),
    "gtpo_sepa_amp": TransformSpec(
        name="gtpo_sepa_amp",
        needs_planning=True,
        uses_sepa_controller=True,
        entropy_transform=apply_sepa_amplification,
    ),
    "gtpo_sepa_amp_c": TransformSpec(
        name="gtpo_sepa_amp_c",
        needs_planning=True,
        uses_sepa_controller=True,
        entropy_transform=apply_sepa_amplification_clamped,
    ),
}

_TRANSFORM_SPEC_CACHE: dict[str, TransformSpec] = {}


def register_transform_mode(name: str, spec_or_fn: TransformSpec | TransformContextFn) -> None:
    """Register or replace a short-name transform mode at runtime."""
    if not name or "." in name:
        raise ValueError(
            "Transform mode name must be non-empty and cannot contain '.'. "
            "Use dotted paths directly in TOML for external plugins."
        )
    if isinstance(spec_or_fn, TransformSpec):
        spec = spec_or_fn
    elif callable(spec_or_fn):
        spec = TransformSpec(name=name, compute_context=spec_or_fn)
    else:
        raise TypeError(
            f"Transform registration for '{name}' must be TransformSpec "
            f"or callable, got {type(spec_or_fn).__name__}."
        )
    _BUILTIN_TRANSFORM_SPECS[name] = spec
    _TRANSFORM_SPEC_CACHE.pop(name, None)


def get_builtin_transform_modes() -> list[str]:
    """Return sorted built-in transform mode names."""
    return sorted(_BUILTIN_TRANSFORM_SPECS)


def is_valid_transform_mode_name(transform_mode: str) -> bool:
    """True for built-ins or dotted plugin paths (`module.attr`)."""
    if transform_mode in _BUILTIN_TRANSFORM_SPECS:
        return True
    module_path, _, attr_name = transform_mode.rpartition(".")
    return bool(module_path and attr_name)


def _load_custom_transform_spec(dotted_path: str) -> TransformSpec:
    resolved = resolve_dotted_attribute(
        dotted_path,
        selector="transform_mode",
        expected="TransformSpec, context callable, or zero-arg factory",
    )
    obj = resolved.obj

    if isinstance(obj, TransformSpec):
        return obj
    if callable(obj):
        if _callable_takes_no_positional_args(obj):
            built = obj()  # type: ignore[call-top-callable]
            if isinstance(built, TransformSpec):
                return built
            if callable(built):
                return TransformSpec(
                    name=dotted_path,
                    needs_planning=bool(getattr(built, "needs_planning", False)),
                    uses_sepa_controller=bool(
                        getattr(built, "uses_sepa_controller", False)
                    ),
                    compute_context=built,  # type: ignore[invalid-argument-type]
                )
            raise TypeError(
                f"transform_mode '{dotted_path}' factory returned "
                f"{type(built).__name__}, expected TransformSpec or callable."
            )
        return TransformSpec(
            name=dotted_path,
            needs_planning=bool(getattr(obj, "needs_planning", False)),
            uses_sepa_controller=bool(
                getattr(obj, "uses_sepa_controller", False)
            ),
            compute_context=obj,  # type: ignore[invalid-argument-type]
        )

    raise TypeError(
        f"transform_mode '{dotted_path}' must resolve to TransformSpec "
        f"or callable, got {type(obj).__name__}."
    )


def get_transform_spec(transform_mode: str) -> TransformSpec:
    """Resolve a transform mode to a behavior spec."""
    cached = _TRANSFORM_SPEC_CACHE.get(transform_mode)
    if cached is not None:
        return cached

    spec = _BUILTIN_TRANSFORM_SPECS.get(transform_mode)
    if spec is None:
        if "." in transform_mode:
            spec = _load_custom_transform_spec(transform_mode)
        else:
            raise ValueError(
                f"Unknown transform_mode '{transform_mode}'. "
                f"Built-in options: {get_builtin_transform_modes()}. "
                "For custom transforms use dotted path format "
                "(e.g. 'my_module.make_transform_spec')."
            )
    _TRANSFORM_SPEC_CACHE[transform_mode] = spec
    return spec


# ---------------------------------------------------------------------------
# 4c. Uncertainty kind registry (built-ins + dotted-path plugins)
# ---------------------------------------------------------------------------


def _compute_surprisal(ctx: UncertaintyContext) -> list[float]:
    """Sampled-token surprisal: -logprob (clamped)."""
    return [min(-lp, MAX_SURPRISAL) for lp in ctx.logprobs]


def _compute_shannon_entropy(ctx: UncertaintyContext) -> list[float]:
    """Full-distribution Shannon entropy: -sum(p * log(p)).

    Fast path: if precomputed_entropy is available (GPU-computed scalars
    from PyTorchEngine), use those directly. Otherwise fall back to
    computing from full token_distributions.
    """
    if ctx.precomputed_entropy is not None:
        return [min(h, MAX_SURPRISAL) for h in ctx.precomputed_entropy]
    if ctx.token_distributions is not None:
        result: list[float] = []
        for dist in ctx.token_distributions:
            h = -sum(p * math.log(p) for p in dist if p > 0)
            result.append(min(h, MAX_SURPRISAL))
        return result
    raise ValueError(
        "shannon_entropy requires either precomputed per-token entropy "
        "(from PyTorch engine with compute_entropy=True) or full "
        "per-position token distributions. Use inference_engine = "
        "\"pytorch\" to enable GPU-side entropy computation."
    )


def _compute_predictive_variance(ctx: UncertaintyContext) -> list[float]:
    """Bernoulli predictive variance: p * (1 - p) where p = exp(logprob)."""
    result: list[float] = []
    for lp in ctx.logprobs:
        p = math.exp(max(lp, -MAX_SURPRISAL))
        p = max(0.0, min(1.0, p))
        result.append(p * (1.0 - p))
    return result


_BUILTIN_UNCERTAINTY_SPECS: dict[str, UncertaintySpec] = {
    "surprisal": UncertaintySpec(
        name="surprisal",
        compute=_compute_surprisal,
    ),
    "shannon_entropy": UncertaintySpec(
        name="shannon_entropy",
        compute=_compute_shannon_entropy,
        needs_distributions=True,
    ),
    "predictive_variance": UncertaintySpec(
        name="predictive_variance",
        compute=_compute_predictive_variance,
    ),
}

_UNCERTAINTY_SPEC_CACHE: dict[str, UncertaintySpec] = {}


def register_uncertainty_kind(
    name: str, spec_or_fn: UncertaintySpec | UncertaintyComputeFn
) -> None:
    """Register or replace a short-name uncertainty kind at runtime."""
    if not name or "." in name:
        raise ValueError(
            "Uncertainty kind name must be non-empty and cannot contain '.'. "
            "Use dotted paths directly in TOML for external plugins."
        )
    if isinstance(spec_or_fn, UncertaintySpec):
        spec = spec_or_fn
    elif callable(spec_or_fn):
        spec = UncertaintySpec(name=name, compute=spec_or_fn)
    else:
        raise TypeError(
            f"Uncertainty registration for '{name}' must be UncertaintySpec "
            f"or callable, got {type(spec_or_fn).__name__}."
        )
    _BUILTIN_UNCERTAINTY_SPECS[name] = spec
    _UNCERTAINTY_SPEC_CACHE.pop(name, None)


def get_builtin_uncertainty_kinds() -> list[str]:
    """Return sorted built-in uncertainty kind names."""
    return sorted(_BUILTIN_UNCERTAINTY_SPECS)


def is_valid_uncertainty_kind_name(kind: str) -> bool:
    """True for aliases, builtins, or dotted plugin paths (`module.attr`)."""
    if kind in _UNCERTAINTY_KIND_ALIASES:
        return True
    if kind in _BUILTIN_UNCERTAINTY_SPECS:
        return True
    module_path, _, attr_name = kind.rpartition(".")
    return bool(module_path and attr_name)


def _load_custom_uncertainty_spec(dotted_path: str) -> UncertaintySpec:
    resolved = resolve_dotted_attribute(
        dotted_path,
        selector="uncertainty_kind",
        expected="UncertaintySpec, compute callable, or zero-arg factory",
    )
    obj = resolved.obj

    if isinstance(obj, UncertaintySpec):
        return obj
    if callable(obj):
        if _callable_takes_no_positional_args(obj):
            built = obj()  # type: ignore[call-top-callable]
            if isinstance(built, UncertaintySpec):
                return built
            if callable(built):
                return UncertaintySpec(name=dotted_path, compute=built)  # type: ignore[invalid-argument-type]
            raise TypeError(
                f"uncertainty_kind '{dotted_path}' factory returned "
                f"{type(built).__name__}, expected UncertaintySpec or callable."
            )
        return UncertaintySpec(name=dotted_path, compute=obj)  # type: ignore[invalid-argument-type]

    raise TypeError(
        f"uncertainty_kind '{dotted_path}' must resolve to UncertaintySpec "
        f"or callable, got {type(obj).__name__}."
    )


def get_uncertainty_spec(kind: str) -> UncertaintySpec:
    """Resolve an uncertainty kind to a behavior spec."""
    cached = _UNCERTAINTY_SPEC_CACHE.get(kind)
    if cached is not None:
        return cached

    spec = _BUILTIN_UNCERTAINTY_SPECS.get(kind)
    if spec is None:
        if "." in kind:
            spec = _load_custom_uncertainty_spec(kind)
        else:
            raise ValueError(
                f"Unknown uncertainty_kind '{kind}'. "
                f"Built-in options: {get_builtin_uncertainty_kinds()}. "
                "For custom uncertainty signals use dotted path format "
                "(e.g. 'my_module.my_uncertainty')."
            )
    _UNCERTAINTY_SPEC_CACHE[kind] = spec
    return spec


def _resolve_uncertainty_kind(params: Mapping[str, object]) -> str:
    """Resolve uncertainty metric for GTPO-family transforms.

    Default is sampled-token surprisal (`-logprob`).
    """
    raw_value: object = "surprisal"
    for key in _UNCERTAINTY_KIND_PARAM_KEYS:
        if key in params:
            raw_value = params[key]
            break
    return canonicalize_uncertainty_kind(raw_value)


def canonicalize_uncertainty_kind(raw_value: object) -> str:
    """Normalize a user-facing uncertainty-kind setting."""
    if not isinstance(raw_value, str):
        raise ValueError(
            f"{_UNCERTAINTY_KIND_PARAM_KEYS[0]} must be a string; "
            f"got {type(raw_value).__name__}."
        )
    # Check aliases first.
    canonical = _UNCERTAINTY_KIND_ALIASES.get(raw_value.strip().lower())
    if canonical is not None:
        return canonical
    # Accept runtime-registered builtins.
    stripped = raw_value.strip()
    if stripped in _BUILTIN_UNCERTAINTY_SPECS:
        return stripped
    # Accept dotted plugin paths.
    if "." in stripped:
        return stripped
    allowed = sorted(set(_UNCERTAINTY_KIND_ALIASES) | set(_BUILTIN_UNCERTAINTY_SPECS))
    raise ValueError(
        f"Unknown uncertainty kind '{raw_value}'. "
        f"Supported values: {allowed}."
    )


# ---------------------------------------------------------------------------
# 5. Entropy statistics
# ---------------------------------------------------------------------------


def compute_surprisal_stats(
    exec_surprisals: list[float], plan_surprisals: list[float]
) -> EntropyStats:
    """Compute summary stats for execution vs planning token surprisal."""
    stats = EntropyStats()

    exec_surprisals = [min(e, MAX_SURPRISAL) for e in exec_surprisals]
    plan_surprisals = [min(e, MAX_SURPRISAL) for e in plan_surprisals]

    if exec_surprisals:
        n = len(exec_surprisals)
        mean_e = sum(exec_surprisals) / n
        var_e = sum((e - mean_e) ** 2 for e in exec_surprisals) / n
        stats.exec_mean = mean_e
        stats.exec_var = var_e
        stats.exec_count = float(n)

    if plan_surprisals:
        n = len(plan_surprisals)
        mean_p = sum(plan_surprisals) / n
        var_p = sum((p - mean_p) ** 2 for p in plan_surprisals) / n
        stats.plan_mean = mean_p
        stats.plan_var = var_p
        stats.plan_count = float(n)

    return stats


compute_entropy_stats = compute_surprisal_stats  # backward-compat alias


# ---------------------------------------------------------------------------
# 6. Planning token identification (regex-based)
# ---------------------------------------------------------------------------

DEFAULT_STRATEGIC_GRAMS = [
    "wait let me",
    "let me think",
    "on second thought",
    "let me check",
    "let me verify",
    "is this right",
    "double check",
    "try another approach",
    "go back and",
    "start over",
    "that's not right",
    "that doesn't work",
    "another way to",
    "or we could",
    "what if we",
    "notice that",
    "the key is",
    "the key insight",
]


@lru_cache(maxsize=8192)
def _clean_token_fragment(fragment: str) -> str:
    """Clean a tokenizer fragment: replace subword markers with space."""
    # sentencepiece: \u2581, GPT-2/BPE: \u0120
    return fragment.replace("\u2581", " ").replace("\u0120", " ").strip()


# Cache compiled regex patterns keyed by the tuple of grams
_pattern_cache: dict[tuple[str, ...], list[re.Pattern[str]]] = {}


def _get_gram_patterns(strategic_grams: list[str]) -> list[re.Pattern[str]]:
    """Return compiled regex patterns for strategic grams (cached)."""
    key = tuple(strategic_grams)
    if key not in _pattern_cache:
        _pattern_cache[key] = [
            re.compile(r"\b" + re.escape(gram) + r"\b", re.IGNORECASE)
            for gram in strategic_grams
        ]
    return _pattern_cache[key]


def identify_planning_tokens(
    token_strs: list[str],
    strategic_grams: list[str],
    max_window: int = 5,
) -> list[int]:
    """Identify planning tokens via strategic gram matching.

    Sliding window over token fragments, checking for word-boundary matches.
    """
    n_tokens = len(token_strs)
    if n_tokens == 0 or not strategic_grams:
        return [0] * n_tokens

    # Effective window covers longest gram by word count
    effective_window = max(max_window, max(len(g.split()) for g in strategic_grams))

    # Pre-clean all fragments
    cleaned = [_clean_token_fragment(t) for t in token_strs]

    patterns = _get_gram_patterns(strategic_grams)

    mask = [0] * n_tokens

    for start in range(n_tokens):
        window_end = min(start + effective_window, n_tokens)
        matched = False
        window_text = ""

        for end in range(start, window_end):
            if cleaned[end]:
                if window_text:
                    window_text += " " + cleaned[end]
                else:
                    window_text = cleaned[end]

            for pat in patterns:
                if pat.search(window_text):
                    for idx in range(start, end + 1):
                        mask[idx] = 1
                    matched = True
                    break
            if matched:
                break

    return mask


def _raise_missing_data(
    uncertainty_kind: str,
    *,
    has_logprobs: bool,
    has_distributions: bool,
    n_episodes: int = 0,
) -> None:
    """Raise a diagnostic ValueError when required data is absent."""
    logprobs_status = f"provided ({n_episodes} episodes)" if has_logprobs else "absent"
    distributions_status = (
        f"provided ({n_episodes} episodes)" if has_distributions else "absent"
    )
    raise ValueError(
        f"uncertainty_kind='{uncertainty_kind}' requires per-position token distributions.\n"
        f"Data received: logprobs_G={logprobs_status}, "
        f"token_distributions_G={distributions_status}.\n"
        f"Use uncertainty_kind='surprisal' (requires only logprobs) or use a backend "
        f"that returns full token distributions."
    )


# ---------------------------------------------------------------------------
# Composable advantage pipeline
# ---------------------------------------------------------------------------


def compute_composable_advantages(
    rewards_G: list[float],
    logprobs_G: list[list[float]],
    planning_masks_G: list[list[int]],
    *,
    advantage_mode: str = "grpo",
    transform_mode: str = "none",
    gtpo_beta: float = 0.1,
    hicra_alpha: float = 0.2,
    sepa_lambda: float = 0.0,
    advantage_params: Mapping[str, object] | None = None,
    transform_params: Mapping[str, object] | None = None,
    step: int = 0,
    post_process_params: Mapping[str, object] | None = None,
    token_distributions_G: list[list[list[float]]] | None = None,
    precomputed_entropies_G: list[list[float]] | None = None,
) -> AdvantageResult:
    """Compute token-level advantages with composable transforms."""
    advantage_spec = get_advantage_spec(advantage_mode)
    transform_spec = get_transform_spec(transform_mode)

    # Step 1: Episode-level advantages
    raw_advantages = advantage_spec.compute(rewards_G, advantage_params or {})
    advantages_G = _coerce_advantages_output(
        raw_advantages,
        expected_len=len(rewards_G),
        mode_name=advantage_spec.name,
    )
    expected_lens = [len(seq) for seq in logprobs_G]

    merged_transform_params: dict[str, object] = {}
    if post_process_params:
        merged_transform_params.update(post_process_params)
    if transform_params:
        merged_transform_params.update(transform_params)

    if transform_spec.compute_context is not None:
        ctx = TransformContext(
            episode_advantages=advantages_G,
            logprobs_G=logprobs_G,
            planning_masks_G=planning_masks_G,
            sepa_lambda=sepa_lambda,
            params=merged_transform_params,
            step=step,
            gtpo_beta=gtpo_beta,
            hicra_alpha=hicra_alpha,
        )
        raw_output = transform_spec.compute_context(ctx)
        return _coerce_transform_output(
            raw_output,
            expected_lens=expected_lens,
            mode_name=f"transform_mode '{transform_spec.name}'",
        )

    # Step 2: Token-level expansion
    if not transform_spec.use_gtpo:
        all_token_advs = [
            [advantages_G[i]] * len(logprobs_G[i])
            for i in range(len(logprobs_G))
        ]
        _validate_token_advs(
            all_token_advs,
            expected_lens=expected_lens,
            mode_name=f"transform_mode '{transform_spec.name}'",
        )
        # Observational stats — advantages are unchanged but we still
        # compute surprisal distributions for cross-condition comparison.
        obs_exec: list[float] = []
        obs_plan: list[float] = []
        for idx in range(len(logprobs_G)):
            for j, lp in enumerate(logprobs_G[idx]):
                s = min(-lp, MAX_SURPRISAL)
                if planning_masks_G[idx][j]:
                    obs_plan.append(s)
                else:
                    obs_exec.append(s)
        stats = compute_surprisal_stats(obs_exec, obs_plan)
        return AdvantageResult(all_token_advs, True, stats)

    uncertainty_kind = _resolve_uncertainty_kind(merged_transform_params)
    uncertainty_spec = get_uncertainty_spec(uncertainty_kind)

    if (
        uncertainty_spec.needs_distributions
        and token_distributions_G is None
        and precomputed_entropies_G is None
    ):
        _raise_missing_data(
            uncertainty_kind,
            has_logprobs=True,
            has_distributions=False,
            n_episodes=len(logprobs_G),
        )

    # GTPO-based transforms need per-token uncertainty values.
    # The pipeline is agnostic to the kind — the backend determines what's
    # available, and the user picks via uncertainty_kind.
    all_token_advs = []
    all_exec_surprisals: list[float] = []
    all_plan_surprisals: list[float] = []
    all_post_exec_surprisals: list[float] = []
    all_post_plan_surprisals: list[float] = []
    all_raw_surprisals: list[list[float]] = []  # for surprisal_mask compatibility

    for idx in range(len(logprobs_G)):
        logprobs = logprobs_G[idx]
        advantage = advantages_G[idx]
        planning_mask = planning_masks_G[idx]

        ctx = UncertaintyContext(
            logprobs=logprobs,
            token_distributions=token_distributions_G[idx] if token_distributions_G else None,
            precomputed_entropy=precomputed_entropies_G[idx] if precomputed_entropies_G else None,
            planning_mask=planning_mask,
            params=merged_transform_params,
        )
        surprisals = uncertainty_spec.compute(ctx)

        # Store raw surprisals before any transform (for surprisal masking)
        all_raw_surprisals.append(list(surprisals))

        # Collect pre-transform surprisal stats
        for j, e in enumerate(surprisals):
            if planning_mask[j]:
                all_plan_surprisals.append(e)
            else:
                all_exec_surprisals.append(e)

        # Optional surprisal transform (SEPA variants or custom plugin)
        if transform_spec.entropy_transform is not None:
            surprisals = transform_spec.entropy_transform(
                surprisals, planning_mask, sepa_lambda
            )

        # Collect post-transform surprisal stats (before GTPO weighting)
        for j, e in enumerate(surprisals):
            if planning_mask[j]:
                all_post_plan_surprisals.append(e)
            else:
                all_post_exec_surprisals.append(e)

        # GTPO weighting
        token_advs = apply_gtpo_weighting(advantage, surprisals, beta=gtpo_beta)

        # HICRA amplification
        if transform_spec.apply_hicra:
            token_advs = apply_hicra(token_advs, planning_mask, alpha=hicra_alpha)

        all_token_advs.append(token_advs)

    # Post-process hook (e.g. surprisal masking)
    extra_metrics: dict[str, float] = {}
    n_seqs = len(all_token_advs)
    seq_lens = [len(seq) for seq in all_token_advs]
    if transform_spec.post_process is not None:
        all_token_advs, extra_metrics = transform_spec.post_process(
            all_token_advs, all_raw_surprisals, merged_transform_params
        )
        # Validate hook output shape
        if len(all_token_advs) != n_seqs:
            raise ValueError(
                f"post_process hook '{transform_spec.name}' returned "
                f"{len(all_token_advs)} sequences, expected {n_seqs}"
            )
        for i, seq in enumerate(all_token_advs):
            if len(seq) != seq_lens[i]:
                raise ValueError(
                    f"post_process hook '{transform_spec.name}' returned "
                    f"{len(seq)} tokens for sequence {i}, expected {seq_lens[i]}"
                )

    _validate_token_advs(
        all_token_advs,
        expected_lens=expected_lens,
        mode_name=f"transform_mode '{transform_spec.name}'",
    )
    stats = compute_surprisal_stats(all_exec_surprisals, all_plan_surprisals)
    post_stats = compute_surprisal_stats(all_post_exec_surprisals, all_post_plan_surprisals)
    stats.post_exec_mean = post_stats.exec_mean
    stats.post_exec_var = post_stats.exec_var
    stats.post_exec_count = post_stats.exec_count
    stats.post_plan_mean = post_stats.plan_mean
    stats.post_plan_var = post_stats.plan_var
    stats.post_plan_count = post_stats.plan_count
    return AdvantageResult(all_token_advs, True, stats, extra_metrics=extra_metrics)


def compute_algorithm_advantages(
    rewards_G: list[float],
    logprobs_G: list[list[float]],
    planning_masks_G: list[list[int]],
    *,
    algorithm_mode: str,
    params: Mapping[str, object] | None = None,
    gtpo_beta: float = 0.1,
    hicra_alpha: float = 0.2,
    sepa_lambda: float = 0.0,
    step: int = 0,
    token_distributions_G: list[list[list[float]]] | None = None,
    precomputed_entropies_G: list[list[float]] | None = None,
) -> AdvantageResult:
    """Compute token-level advantages through a full algorithm plugin."""
    spec = get_algorithm_spec(algorithm_mode)
    ctx = AlgorithmContext(
        rewards_G=rewards_G,
        logprobs_G=logprobs_G,
        planning_masks_G=planning_masks_G,
        params=params or {},
        step=step,
        sepa_lambda=sepa_lambda,
        gtpo_beta=gtpo_beta,
        hicra_alpha=hicra_alpha,
        token_distributions_G=token_distributions_G,
        precomputed_entropies_G=precomputed_entropies_G,
    )
    try:
        raw_output = spec.compute(ctx)
        return _coerce_algorithm_output(
            raw_output,
            expected_lens=[len(seq) for seq in logprobs_G],
            mode_name=f"algorithm_mode '{spec.name}'",
        )
    except Exception:
        if get_plugin_runtime().strict:
            raise
        # Non-strict mode still surfaces errors by default to avoid silent bad runs.
        raise
