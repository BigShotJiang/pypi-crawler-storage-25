#ifndef OPENMM_AMOEBA_TORSION_TORSION_FORCE_IMPL_H_
#define OPENMM_AMOEBA_TORSION_TORSION_FORCE_IMPL_H_

/* -------------------------------------------------------------------------- *
 *                                OpenMMAmoeba                                *
 * -------------------------------------------------------------------------- *
 * This is part of the OpenMM molecular simulation toolkit.                   *
 * See https://openmm.org/development.                                        *
 *                                                                            *
 * Portions copyright (c) 2008 Stanford University and the Authors.           *
 * Authors:                                                                   *
 * Contributors:                                                              *
 *                                                                            *
 * Permission is hereby granted, free of charge, to any person obtaining a    *
 * copy of this software and associated documentation files (the "Software"), *
 * to deal in the Software without restriction, including without limitation  *
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,   *
 * and/or sell copies of the Software, and to permit persons to whom the      *
 * Software is furnished to do so, subject to the following conditions:       *
 *                                                                            *
 * The above copyright notice and this permission notice shall be included in *
 * all copies or substantial portions of the Software.                        *
 *                                                                            *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,   *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL    *
 * THE AUTHORS, CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,    *
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR      *
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE  *
 * USE OR OTHER DEALINGS IN THE SOFTWARE.                                     *
 * -------------------------------------------------------------------------- */

#include "openmm/internal/ForceImpl.h"
#include "openmm/AmoebaTorsionTorsionForce.h"
#include "openmm/Kernel.h"
#include <utility>
#include <string>

namespace OpenMM {

/**
 * This is the internal implementation of AmoebaTorsionTorsionForce.
 */

class AmoebaTorsionTorsionForceImpl : public ForceImpl {
public:
    AmoebaTorsionTorsionForceImpl(const AmoebaTorsionTorsionForce& owner);
    ~AmoebaTorsionTorsionForceImpl();
    void initialize(ContextImpl& context);
    const AmoebaTorsionTorsionForce& getOwner() const {
        return owner;
    }
    void updateContextState(ContextImpl& context, bool& forcesInvalid) {
        // This force field doesn't update the state directly.
    }
    double calcForcesAndEnergy(ContextImpl& context, bool includeForces, bool includeEnergy, int groups);
    std::map<std::string, double> getDefaultParameters() {
        return {}; // This force field doesn't define any parameters.
    }
    std::vector<std::string> getKernelNames();

    OPENMM_EXPORT_AMOEBA static void reorderGrid(const TorsionTorsionGrid& grid, TorsionTorsionGrid& reorderedGrid);

private:
    const AmoebaTorsionTorsionForce& owner;
    Kernel kernel;
};

} // namespace OpenMM

#endif /*OPENMM_AMOEBA_TORSION_TORSION_FORCE_IMPL_H_*/
