#ifndef OPENMM_AMOEBA_VDW_FORCE_IMPL_H_
#define OPENMM_AMOEBA_VDW_FORCE_IMPL_H_

/* -------------------------------------------------------------------------- *
 *                                OpenMMAmoeba                                *
 * -------------------------------------------------------------------------- *
 * This is part of the OpenMM molecular simulation toolkit.                   *
 * See https://openmm.org/development.                                        *
 *                                                                            *
 * Portions copyright (c) 2008 Stanford University and the Authors.           *
 * Authors:                                                                   *
 * Contributors:                                                              *
 *                                                                            *
 * Permission is hereby granted, free of charge, to any person obtaining a    *
 * copy of this software and associated documentation files (the "Software"), *
 * to deal in the Software without restriction, including without limitation  *
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,   *
 * and/or sell copies of the Software, and to permit persons to whom the      *
 * Software is furnished to do so, subject to the following conditions:       *
 *                                                                            *
 * The above copyright notice and this permission notice shall be included in *
 * all copies or substantial portions of the Software.                        *
 *                                                                            *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,   *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL    *
 * THE AUTHORS, CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,    *
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR      *
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE  *
 * USE OR OTHER DEALINGS IN THE SOFTWARE.                                     *
 * -------------------------------------------------------------------------- */

#include "openmm/internal/ForceImpl.h"
#include "openmm/AmoebaVdwForce.h"
#include "openmm/Kernel.h"
#include <utility>
#include <set>
#include <string>

namespace OpenMM {

class System;

/**
 * This is the internal implementation of AmoebaVdwForce.
 */

class OPENMM_EXPORT_AMOEBA AmoebaVdwForceImpl : public ForceImpl {
public:
    AmoebaVdwForceImpl(const AmoebaVdwForce& owner);
    ~AmoebaVdwForceImpl();
    void initialize(ContextImpl& context);
    const AmoebaVdwForce& getOwner() const {
        return owner;
    }
    void updateContextState(ContextImpl& context, bool& forcesInvalid) {
        // This force field doesn't update the state directly.
    }
    double calcForcesAndEnergy(ContextImpl& context, bool includeForces, bool includeEnergy, int groups);
    std::map<std::string, double> getDefaultParameters() {
        return {{AmoebaVdwForce::Lambda(), 1.0}};
    }
    std::vector<std::string> getKernelNames();
    /**
     * Compute the matrix of sigma and epsilon to use between every pair of particle types.
     * 
     * @param force               the force for which to calculate it
     * @param[out] type           on exit, this contains the type index of every particle
     * @param[out] sigmaMatrix    on exit, sigma[i][j] contains the value to use for interactions between particles
     *                            of types i and j
     * @param[out] epsilonMatrix  on exit, epsilon[i][j] contains the value to use for interactions between particles
     *                            of types i and j
     */
    static void createParameterMatrix(const AmoebaVdwForce& force, std::vector<int>& type,
        std::vector<std::vector<double> >& sigmaMatrix, std::vector<std::vector<double> >& epsilonMatrix);
    /**
     * Compute the coefficient which, when divided by the periodic box volume, gives the
     * long range dispersion correction to the energy.
     */
    static double calcDispersionCorrection(const System& system, const AmoebaVdwForce& force);
    void updateParametersInContext(ContextImpl& context);
private:
    const AmoebaVdwForce& owner;
    Kernel kernel;
};

} // namespace OpenMM

#endif /*OPENMM_AMOEBA_VDW_FORCE_IMPL_H_*/

