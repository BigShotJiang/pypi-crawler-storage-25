# argentina

Paquete Python para utilidades y procesamiento de datos de Argentina.

## Instalación

```bash
pip install -e .
```
