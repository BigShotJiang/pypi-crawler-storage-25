import argentina


def test_import():
    assert argentina.__version__ == "0.0.1"
