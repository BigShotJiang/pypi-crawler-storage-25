"""Tests for agent sync writers."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from crossby.config.linker import create_symlink
from crossby.models.ai import AIToolID
from crossby.sync.agents import (
    _GITIGNORE_BLOCK_ID,
    ClaudeAgentsWriter,
    CodexAgentsWriter,
    CopilotAgentsWriter,
    CursorAgentsWriter,
    GeminiAgentsWriter,
    _parse_frontmatter,
    _render_frontmatter,
    _translate_tools,
    update_agents_gitignore,
)
from crossby.sync.base import SyncConcern, SyncData

# Derive the markers from the block ID, matching gitignore_utils conventions
_BLOCK_START = f"# >>> crossby {_GITIGNORE_BLOCK_ID} (generated — do not edit) >>>"
_BLOCK_END = f"# <<< crossby {_GITIGNORE_BLOCK_ID} <<<"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _data(
    source: str = ".crossby/agents",
    strategy: str = "symlink",
    gitignore: bool = True,
) -> SyncData:
    return SyncData(
        agents_source=source,
        agents_strategy=strategy,
        agents_gitignore=gitignore,
    )


def _make_source(tmp_path: Path, agents: list[str] | None = None) -> Path:
    """Create a .crossby/agents source dir with optional agent files."""
    source = tmp_path / ".crossby" / "agents"
    source.mkdir(parents=True)
    for name in agents or []:
        (source / name).write_text(
            f"---\nname: {name.removesuffix('.md')}\ndescription: test\n---\nBody.\n",
            encoding="utf-8",
        )
    return source


# ---------------------------------------------------------------------------
# create_symlink (shared helper, used by agents sync)
# ---------------------------------------------------------------------------


class TestCreateDirSymlink:
    def test_creates_relative_symlink(self, tmp_path: Path) -> None:
        source = tmp_path / "src"
        source.mkdir()
        link = tmp_path / "sub" / "link"
        created = create_symlink(source, link, force=True, dry_run=False)
        assert created is True
        assert link.is_symlink()
        # Symlink target must be relative
        assert not os.path.isabs(os.readlink(link))
        assert link.resolve() == source.resolve()

    def test_idempotent_correct_symlink(self, tmp_path: Path) -> None:
        source = tmp_path / "src"
        source.mkdir()
        link = tmp_path / "link"
        create_symlink(source, link, force=True, dry_run=False)
        created = create_symlink(source, link, force=True, dry_run=False)
        assert created is False  # already correct

    def test_dry_run_does_not_create(self, tmp_path: Path) -> None:
        source = tmp_path / "src"
        source.mkdir()
        link = tmp_path / "link"
        created = create_symlink(source, link, force=True, dry_run=True)
        assert created is True
        assert not link.exists()

    def test_wrong_target_updated(self, tmp_path: Path) -> None:
        source_a = tmp_path / "a"
        source_b = tmp_path / "b"
        source_a.mkdir()
        source_b.mkdir()
        link = tmp_path / "link"
        os.symlink(os.path.relpath(source_a, tmp_path), link)
        # Now change to source_b
        created = create_symlink(source_b, link, force=True, dry_run=False)
        assert created is True
        assert link.resolve() == source_b.resolve()

    def test_existing_real_path_skipped(self, tmp_path: Path) -> None:
        source = tmp_path / "src"
        source.mkdir()
        link = tmp_path / "link"
        link.mkdir()  # real dir
        created = create_symlink(source, link, force=True, dry_run=False)
        assert created is False  # skipped — linker refuses to remove real dirs


# ---------------------------------------------------------------------------
# Frontmatter helpers
# ---------------------------------------------------------------------------


class TestParseFrontmatter:
    def test_parses_valid_frontmatter(self) -> None:
        content = "---\nname: foo\ndescription: bar\n---\nBody text.\n"
        fm, body = _parse_frontmatter(content)
        assert fm == {"name": "foo", "description": "bar"}
        assert body == "Body text.\n"

    def test_no_frontmatter(self) -> None:
        content = "Just some text."
        fm, body = _parse_frontmatter(content)
        assert fm is None
        assert body == "Just some text."

    def test_non_dict_yaml_frontmatter(self) -> None:
        """Non-dict YAML (list, scalar) in frontmatter returns None — copy verbatim."""
        content = "---\n- item1\n- item2\n---\nBody.\n"
        fm, body = _parse_frontmatter(content)
        assert fm is None
        assert body == content  # verbatim, not stripped

    def test_roundtrip(self) -> None:
        fm = {"name": "test", "tools": ["Read", "Bash"]}
        body = "Hello world.\n"
        rendered = _render_frontmatter(fm, body)
        fm2, body2 = _parse_frontmatter(rendered)
        assert fm2 == fm
        assert body2 == body


class TestTranslateTools:
    def test_copilot_translation(self) -> None:
        tools = ["Read", "Bash", "Grep", "Unknown"]
        result = _translate_tools(tools, "copilot")
        assert result == ["read", "shell", "search", "Unknown"]

    def test_cursor_translation(self) -> None:
        tools = ["Read", "Bash", "Grep"]
        result = _translate_tools(tools, "cursor")
        assert result == ["Read", "Shell", "Grep"]

    def test_claude_no_translation(self) -> None:
        tools = ["Read", "Bash", "Grep"]
        assert _translate_tools(tools, "claude") == tools

    def test_codex_no_translation(self) -> None:
        tools = ["WebSearch", "WebFetch"]
        assert _translate_tools(tools, "codex") == tools


# ---------------------------------------------------------------------------
# Directory symlink strategy (non-Copilot writers)
# ---------------------------------------------------------------------------


class TestClaudeAgentsWriter:
    def test_creates_symlink(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["reviewer.md"])
        w = ClaudeAgentsWriter()
        data = _data(source=".crossby/agents")
        result = w.sync(data, tmp_path)
        assert result.action == "created"
        link = tmp_path / ".claude" / "agents"
        assert link.is_symlink()
        assert link.resolve() == (tmp_path / ".crossby" / "agents").resolve()

    def test_idempotent(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["a.md"])
        w = ClaudeAgentsWriter()
        data = _data()
        w.sync(data, tmp_path)
        result = w.sync(data, tmp_path)
        assert result.action == "skipped"
        assert result.message == "already linked"

    def test_missing_source_is_error(self, tmp_path: Path) -> None:
        w = ClaudeAgentsWriter()
        data = _data(source=".crossby/agents")
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "source directory not found" in (result.message or "")

    def test_existing_real_dir_is_error_without_force(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        (target / "unmanaged.txt").write_text("user content", encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "--force" in (result.message or "")

    def test_symlinked_md_files_in_target_dir_are_unmanaged(self, tmp_path: Path) -> None:
        """A target dir containing .md symlinks is treated as unmanaged (not a safe fallback)."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        # Symlinked .md file — should NOT be treated as a managed fallback
        other = tmp_path / "external.md"
        other.write_text("external", encoding="utf-8")
        os.symlink(os.path.relpath(other, target), target / "a.md")
        w = ClaudeAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "--force" in (result.message or "")

    def test_empty_target_dir_is_managed_fallback(self, tmp_path: Path) -> None:
        """An empty target directory is treated as a managed fallback — proceed with copy."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        w = ClaudeAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        # Target dir already existed (empty), so this is an "updated" sync.
        assert result.action == "updated"
        assert (target / "a.md").is_file()

    def test_source_is_file_is_error(self, tmp_path: Path) -> None:
        """Source path that exists as a file (not a directory) returns an error."""
        source = tmp_path / ".crossby" / "agents"
        source.parent.mkdir(parents=True)
        source.write_text("not a directory", encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "not a directory" in (result.message or "")

    def test_force_backs_up_and_replaces(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        (target / "old.md").write_text("old", encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path, force=True)
        assert result.action == "created"
        assert target.is_symlink()
        backup = Path(str(target) + ".bak")
        assert backup.is_dir()
        assert (backup / "old.md").exists()

    def test_dry_run_no_files_written(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["a.md"])
        w = ClaudeAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path, dry_run=True)
        assert result.action == "created"
        assert not (tmp_path / ".claude" / "agents").exists()

    def test_force_dry_run_with_real_dir_reports_created(self, tmp_path: Path) -> None:
        """dry_run=True + force=True with existing real dir should report 'created'."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        w = ClaudeAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path, dry_run=True, force=True)
        assert result.action == "created"
        # Nothing written
        assert target.is_dir() and not target.is_symlink()

    def test_force_twice_no_backup_collision(self, tmp_path: Path) -> None:
        """Running --force twice does not crash due to existing .bak directory."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        (target / "old.md").write_text("old", encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data()
        w.sync(data, tmp_path, force=True)
        # Replace symlink with a real dir again for second force run
        (tmp_path / ".claude" / "agents").unlink()
        target.mkdir(parents=True)
        (target / "newer.md").write_text("newer", encoding="utf-8")
        result = w.sync(data, tmp_path, force=True)
        assert result.action == "created"

    def test_regular_file_at_target_is_error(self, tmp_path: Path) -> None:
        """A regular file at the symlink target path returns an error (not 'already linked')."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.parent.mkdir(parents=True)
        target.write_text("regular file", encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "regular file or directory" in (result.message or "")
        assert "--force" in (result.message or "")

    def test_no_agents_source_skipped(self, tmp_path: Path) -> None:
        """Writers skip when agents_source is None (no agents config)."""
        _make_source(tmp_path, ["a.md"])
        w = ClaudeAgentsWriter()
        data = SyncData()  # agents_source=None by default
        result = w.sync(data, tmp_path)
        assert result.action == "skipped"


class TestRelativeSymlinkPaths:
    """Verify symlink targets are relative, not absolute."""

    @pytest.mark.parametrize(
        "writer_cls, target_rel",
        [
            (ClaudeAgentsWriter, ".claude/agents"),
            (CursorAgentsWriter, ".cursor/agents"),
            (GeminiAgentsWriter, ".gemini/agents"),
        ],
    )
    def test_symlink_is_relative(self, tmp_path: Path, writer_cls: type, target_rel: str) -> None:
        # CodexAgentsWriter intentionally does not symlink — it translates
        # markdown agents into TOML at .codex/agents/<name>.toml. See
        # TestCodexAgentsTranslate below.
        _make_source(tmp_path, ["a.md"])
        w = writer_cls()
        data = _data()
        w.sync(data, tmp_path)
        link = tmp_path / target_rel
        assert link.is_symlink()
        assert not os.path.isabs(os.readlink(link)), "symlink target must be relative"


# ---------------------------------------------------------------------------
# Copy strategy
# ---------------------------------------------------------------------------


class TestSymlinkFailureFallback:
    """When ``create_symlink`` raises (e.g. cross-device, sandboxed FS), the
    writer falls back to copying. The copied output must carry the managed
    marker so the next sync recognizes it instead of refusing the directory
    as user-owned."""

    def test_agents_symlink_failure_marks_managed(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        _make_source(tmp_path, ["reviewer.md"])

        def _boom(*_args: object, **_kwargs: object) -> bool:
            raise OSError("simulated symlink failure")

        monkeypatch.setattr("crossby.sync.agents.create_symlink", _boom)

        w = ClaudeAgentsWriter()
        first = w.sync(_data(), tmp_path)
        assert first.action == "created"
        assert first.message == "copy (symlink failed)"
        marker = tmp_path / ".claude" / "agents" / ".crossby-managed"
        assert marker.is_file(), "fallback copy must drop the .crossby-managed marker"

        # Second run still under simulated failure must not refuse its own output.
        second = w.sync(_data(), tmp_path)
        assert second.action != "error", second.message


class TestCopyStrategy:
    def test_copy_creates_files(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["reviewer.md"])
        w = ClaudeAgentsWriter()
        data = _data(strategy="copy")
        result = w.sync(data, tmp_path)
        assert result.action == "created"
        target = tmp_path / ".claude" / "agents" / "reviewer.md"
        assert target.is_file()
        assert not target.is_symlink()

    def test_copy_translates_tool_names_copilot(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path)
        agent_content = "---\nname: test\ndescription: d\ntools:\n  - Read\n  - Bash\n---\nBody.\n"
        (source / "test.md").write_text(agent_content, encoding="utf-8")
        w = CopilotAgentsWriter()
        data = _data(strategy="copy")
        w.sync(data, tmp_path)
        dest = tmp_path / ".github" / "agents" / "test.agent.md"
        content = dest.read_text(encoding="utf-8")
        assert "read" in content
        assert "shell" in content
        assert "Read" not in content
        assert "Bash" not in content

    def test_copy_no_translation_for_claude(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path)
        agent_content = "---\nname: t\ndescription: d\ntools:\n  - Read\n  - Bash\n---\nBody.\n"
        (source / "t.md").write_text(agent_content, encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data(strategy="copy")
        w.sync(data, tmp_path)
        dest = tmp_path / ".claude" / "agents" / "t.md"
        content = dest.read_text(encoding="utf-8")
        assert "Read" in content
        assert "Bash" in content

    def test_copy_errors_on_unmanaged_directory(self, tmp_path: Path) -> None:
        """Copy strategy also errors when target has unmanaged (non-.md) content."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        (target / "unmanaged.txt").write_text("user content", encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data(strategy="copy")
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "--force" in (result.message or "")

    def test_copy_handles_managed_directory(self, tmp_path: Path) -> None:
        """Copy strategy is re-entrant when target carries the crossby marker."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        (target / "a.md").write_text("old content", encoding="utf-8")
        # Marker is what makes the dir crossby-managed; before the marker
        # check existed, the .md-only shape alone was treated as managed,
        # which let sync overwrite hand-curated agent dirs.
        (target / ".crossby-managed").write_text("", encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data(strategy="copy")
        result = w.sync(data, tmp_path)
        # Target dir + file existed but content differs → updated.
        assert result.action == "updated"

    def test_copy_refuses_unmarked_directory(self, tmp_path: Path) -> None:
        """Unmarked dir of .md files is treated as user-owned, not crossby-managed."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        (target / "user.md").write_text("hand-written", encoding="utf-8")
        w = ClaudeAgentsWriter()
        data = _data(strategy="copy")
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "not crossby-managed" in (result.message or "")
        # User file is untouched.
        assert (target / "user.md").read_text(encoding="utf-8") == "hand-written"

    def test_copy_idempotent_skipped_on_no_op(self, tmp_path: Path) -> None:
        """Re-running copy when nothing changed reports skipped, not created."""
        _make_source(tmp_path, ["a.md"])
        w = ClaudeAgentsWriter()
        data = _data(strategy="copy")
        first = w.sync(data, tmp_path)
        second = w.sync(data, tmp_path)
        assert first.action == "created"
        assert second.action == "skipped"
        assert "already copied" in (second.message or "")

    def test_copy_errors_on_symlinked_target_without_force(self, tmp_path: Path) -> None:
        """Copy strategy errors when target path is a symlink (would write outside project)."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.parent.mkdir(parents=True)
        other = tmp_path / "other"
        other.mkdir()
        os.symlink(os.path.relpath(other, target.parent), target)
        w = ClaudeAgentsWriter()
        data = _data(strategy="copy")
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "symlink" in (result.message or "")
        assert "--force" in (result.message or "")

    def test_copy_replaces_symlinked_target_with_force(self, tmp_path: Path) -> None:
        """With --force, copy strategy removes the symlink and copies into a real directory."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".claude" / "agents"
        target.parent.mkdir(parents=True)
        other = tmp_path / "other"
        other.mkdir()
        os.symlink(os.path.relpath(other, target.parent), target)
        w = ClaudeAgentsWriter()
        data = _data(strategy="copy")
        result = w.sync(data, tmp_path, force=True)
        assert result.action == "created"
        assert not target.is_symlink()
        assert (target / "a.md").is_file()


# ---------------------------------------------------------------------------
# Copilot writer (file-level symlinks)
# ---------------------------------------------------------------------------


class TestCopilotAgentsWriter:
    def test_creates_agent_md_symlinks(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["reviewer.md", "tester.md"])
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "created"
        target_dir = tmp_path / ".github" / "agents"
        assert (target_dir / "reviewer.agent.md").is_symlink()
        assert (target_dir / "tester.agent.md").is_symlink()
        assert not (target_dir / "reviewer.md").exists()

    def test_symlinks_are_relative(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["a.md"])
        w = CopilotAgentsWriter()
        data = _data()
        w.sync(data, tmp_path)
        link = tmp_path / ".github" / "agents" / "a.agent.md"
        assert not os.path.isabs(os.readlink(link))

    def test_idempotent(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["a.md"])
        w = CopilotAgentsWriter()
        data = _data()
        w.sync(data, tmp_path)
        result = w.sync(data, tmp_path)
        assert result.action == "skipped"

    def test_stale_cleanup(self, tmp_path: Path) -> None:
        """Stale .agent.md symlinks are removed when source file is deleted."""
        source = _make_source(tmp_path, ["a.md", "old.md"])
        w = CopilotAgentsWriter()
        data = _data()
        w.sync(data, tmp_path)
        # Remove old.md from source
        (source / "old.md").unlink()
        # Re-sync
        w.sync(data, tmp_path)
        target_dir = tmp_path / ".github" / "agents"
        assert not (target_dir / "old.agent.md").exists()
        assert (target_dir / "a.agent.md").is_symlink()

    def test_missing_source_is_error(self, tmp_path: Path) -> None:
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"

    def test_copy_strategy_uses_agent_md_extension(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["foo.md"])
        w = CopilotAgentsWriter()
        data = _data(strategy="copy")
        w.sync(data, tmp_path)
        dest = tmp_path / ".github" / "agents" / "foo.agent.md"
        assert dest.is_file()
        assert not dest.is_symlink()

    def test_existing_real_dir_with_unmanaged_content_is_error(self, tmp_path: Path) -> None:
        """A pre-existing directory with non-.agent.md files blocks sync (needs --force)."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".github" / "agents"
        target.mkdir(parents=True)
        (target / "existing.md").write_text("user content", encoding="utf-8")
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "--force" in (result.message or "")

    def test_force_works_with_unmanaged_content(self, tmp_path: Path) -> None:
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".github" / "agents"
        target.mkdir(parents=True)
        (target / "existing.md").write_text("user content", encoding="utf-8")
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path, force=True)
        assert result.action == "created"
        assert (target / "a.agent.md").is_symlink()

    def test_force_backs_up_unmanaged_directory(self, tmp_path: Path) -> None:
        """--force with unmanaged content backs up the directory before replacing."""
        _make_source(tmp_path, ["a.md"])
        target = tmp_path / ".github" / "agents"
        target.mkdir(parents=True)
        (target / "existing.md").write_text("user content", encoding="utf-8")
        w = CopilotAgentsWriter()
        data = _data()
        w.sync(data, tmp_path, force=True)
        backup = tmp_path / ".github" / "agents.bak"
        assert backup.is_dir()
        assert (backup / "existing.md").exists()

    def test_force_false_does_not_overwrite_wrong_symlink(self, tmp_path: Path) -> None:
        """Without --force, a wrong existing per-file symlink returns an error."""
        _make_source(tmp_path, ["a.md"])
        other = tmp_path / "other.md"
        other.write_text("other", encoding="utf-8")
        target_dir = tmp_path / ".github" / "agents"
        target_dir.mkdir(parents=True)
        link = target_dir / "a.agent.md"
        os.symlink(os.path.relpath(other, target_dir), link)
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path, force=False)
        assert result.action == "error"
        assert "--force" in (result.message or "")
        assert link.resolve() == other.resolve()  # symlink still points to "other"

    def test_source_is_file_is_error(self, tmp_path: Path) -> None:
        """Source path that exists as a file (not a directory) returns an error."""
        source = tmp_path / ".crossby" / "agents"
        source.parent.mkdir(parents=True)
        source.write_text("not a directory", encoding="utf-8")
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "not a directory" in (result.message or "")

    def test_regular_file_at_link_path_is_updated(self, tmp_path: Path) -> None:
        """A regular .agent.md file (copy-fallback output) is updated via copy, not errored."""
        _make_source(tmp_path, ["a.md"])
        target_dir = tmp_path / ".github" / "agents"
        target_dir.mkdir(parents=True)
        (target_dir / "a.agent.md").write_text("stale content", encoding="utf-8")
        # Marker proves the directory is crossby-managed (a prior sync's output).
        (target_dir / ".crossby-managed").write_text("", encoding="utf-8")
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "created"
        # Content should now match what _copy_agent_file produces from source
        assert (target_dir / "a.agent.md").read_text(encoding="utf-8") != "stale content"

    def test_stale_regular_file_is_cleaned_up(self, tmp_path: Path) -> None:
        """A stale regular .agent.md file (copy-fallback) is removed when its source is gone."""
        _make_source(tmp_path, ["a.md"])
        target_dir = tmp_path / ".github" / "agents"
        target_dir.mkdir(parents=True)
        # Simulate a prior copy-fallback output for a source that no longer exists
        (target_dir / "old.agent.md").write_text("stale copy from prior run", encoding="utf-8")
        (target_dir / ".crossby-managed").write_text("", encoding="utf-8")
        w = CopilotAgentsWriter()
        data = _data()
        w.sync(data, tmp_path)
        assert not (target_dir / "old.agent.md").exists()
        assert (target_dir / "a.agent.md").is_symlink()

    def test_unmarked_dir_with_agent_md_files_refused(self, tmp_path: Path) -> None:
        """A native-looking dir of .agent.md files without the marker is user-owned."""
        _make_source(tmp_path, ["a.md"])
        target_dir = tmp_path / ".github" / "agents"
        target_dir.mkdir(parents=True)
        # Hand-curated Copilot agent — no crossby marker.
        (target_dir / "user.agent.md").write_text("user content", encoding="utf-8")
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "not crossby-managed" in (result.message or "")
        assert (target_dir / "user.agent.md").read_text(encoding="utf-8") == "user content"

    def test_marker_written_on_sync(self, tmp_path: Path) -> None:
        """Successful sync drops the .crossby-managed marker so re-runs are safe."""
        _make_source(tmp_path, ["a.md"])
        w = CopilotAgentsWriter()
        w.sync(_data(), tmp_path)
        assert (tmp_path / ".github" / "agents" / ".crossby-managed").is_file()

    def test_target_symlink_is_error_without_force(self, tmp_path: Path) -> None:
        """A symlink at the target directory path errors without --force."""
        _make_source(tmp_path, ["a.md"])
        target_dir = tmp_path / ".github" / "agents"
        target_dir.parent.mkdir(parents=True)
        other = tmp_path / "other"
        other.mkdir()
        os.symlink(os.path.relpath(other, target_dir.parent), target_dir)
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path)
        assert result.action == "error"
        assert "symlink" in (result.message or "")

    def test_target_symlink_replaced_with_force(self, tmp_path: Path) -> None:
        """With --force, a symlink at the target path is replaced with a real directory."""
        _make_source(tmp_path, ["a.md"])
        target_dir = tmp_path / ".github" / "agents"
        target_dir.parent.mkdir(parents=True)
        other = tmp_path / "other"
        other.mkdir()
        os.symlink(os.path.relpath(other, target_dir.parent), target_dir)
        w = CopilotAgentsWriter()
        data = _data()
        result = w.sync(data, tmp_path, force=True)
        assert result.action == "created"
        assert not target_dir.is_symlink()
        assert (target_dir / "a.agent.md").exists()


# ---------------------------------------------------------------------------
# Gitignore managed block
# ---------------------------------------------------------------------------


class TestUpdateAgentsGitignore:
    def test_creates_block_when_missing(self, tmp_path: Path) -> None:
        data = _data()
        result = update_agents_gitignore(data, tmp_path)
        assert result is not None
        assert result.action in ("created", "updated")
        content = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        assert _BLOCK_START in content
        assert ".claude/agents" in content
        assert _BLOCK_END in content

    def test_appends_to_existing_gitignore(self, tmp_path: Path) -> None:
        gitignore = tmp_path / ".gitignore"
        gitignore.write_text("*.pyc\n__pycache__\n", encoding="utf-8")
        data = _data()
        update_agents_gitignore(data, tmp_path)
        content = gitignore.read_text(encoding="utf-8")
        assert "*.pyc" in content
        assert _BLOCK_START in content

    def test_malformed_block_missing_end_marker(self, tmp_path: Path) -> None:
        """A malformed block (start but no end marker) replaces from orphan to EOF."""
        gitignore = tmp_path / ".gitignore"
        malformed = f"*.pyc\n{_BLOCK_START}\n.old/agents\n# end marker is missing\n"
        gitignore.write_text(malformed, encoding="utf-8")
        data = _data()
        update_agents_gitignore(data, tmp_path)
        content = gitignore.read_text(encoding="utf-8")
        # Content before orphan preserved
        assert "*.pyc" in content
        # Fresh block replaces orphaned content
        assert content.count(_BLOCK_START) == 1
        assert _BLOCK_END in content
        assert ".claude/agents" in content

    def test_replaces_existing_block(self, tmp_path: Path) -> None:
        gitignore = tmp_path / ".gitignore"
        old_block = f"{_BLOCK_START}\n.old/agents\n{_BLOCK_END}\n"
        gitignore.write_text(old_block, encoding="utf-8")
        data = _data()
        update_agents_gitignore(data, tmp_path)
        content = gitignore.read_text(encoding="utf-8")
        assert ".old/agents" not in content
        assert ".claude/agents" in content
        # Only one block
        assert content.count(_BLOCK_START) == 1

    def test_idempotent(self, tmp_path: Path) -> None:
        data = _data()
        update_agents_gitignore(data, tmp_path)
        content_before = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        result = update_agents_gitignore(data, tmp_path)
        assert result is None  # No change
        content_after = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        assert content_before == content_after

    def test_installed_tools_filter_entries(self, tmp_path: Path) -> None:
        data = _data()
        update_agents_gitignore(data, tmp_path, installed_tools=[AIToolID.CLAUDE, AIToolID.CURSOR])
        content = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        assert ".claude/agents" in content
        assert ".cursor/agents" in content
        assert ".github/agents" not in content
        assert ".gemini/agents" not in content

    def test_gitignore_false_does_nothing(self, tmp_path: Path) -> None:
        data = _data(gitignore=False)
        result = update_agents_gitignore(data, tmp_path)
        assert result is None
        assert not (tmp_path / ".gitignore").exists()

    def test_dry_run_no_write(self, tmp_path: Path) -> None:
        data = _data()
        result = update_agents_gitignore(data, tmp_path, dry_run=True)
        assert result is not None
        assert not (tmp_path / ".gitignore").exists()

    def test_tool_id_is_none(self, tmp_path: Path) -> None:
        """Gitignore result should have tool_id=None (cross-tool operation)."""
        data = _data()
        result = update_agents_gitignore(data, tmp_path)
        assert result is not None
        assert result.tool_id is None

    def test_action_created_when_file_absent(self, tmp_path: Path) -> None:
        """action='created' when .gitignore doesn't exist yet."""
        data = _data()
        result = update_agents_gitignore(data, tmp_path)
        assert result is not None
        assert result.action == "created"

    def test_action_updated_when_file_exists_but_empty(self, tmp_path: Path) -> None:
        """action='updated' for an existing but empty .gitignore (not 'created')."""
        gitignore = tmp_path / ".gitignore"
        gitignore.write_text("", encoding="utf-8")
        data = _data()
        result = update_agents_gitignore(data, tmp_path)
        assert result is not None
        assert result.action == "updated"

    def test_installed_tools_filters_entries_when_targets_empty(self, tmp_path: Path) -> None:
        """With no agents.targets, installed_tools restricts gitignore entries."""
        data = _data()  # targets={}
        result = update_agents_gitignore(
            data, tmp_path, installed_tools=[AIToolID.CLAUDE, AIToolID.CURSOR]
        )
        assert result is not None
        content = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        assert ".claude/agents" in content
        assert ".cursor/agents" in content
        assert ".github/agents" not in content
        assert ".gemini/agents" not in content

    def test_installed_tools_none_includes_all(self, tmp_path: Path) -> None:
        """With installed_tools=None and no targets, all known paths are included."""
        data = _data()
        result = update_agents_gitignore(data, tmp_path, installed_tools=None)
        assert result is not None
        content = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        assert ".claude/agents" in content
        assert ".github/agents" in content
        assert ".cursor/agents" in content


# ---------------------------------------------------------------------------
# Integration: run_sync with agents concern
# ---------------------------------------------------------------------------


class TestRunSyncAgents:
    def test_full_sync_all_tools(self, tmp_path: Path) -> None:
        from crossby.sync import run_sync
        from crossby.sync.agents import (
            ClaudeAgentsWriter,
            CopilotAgentsWriter,
            CursorAgentsWriter,
        )
        from crossby.sync.base import SyncRegistry

        _make_source(tmp_path, ["a.md"])
        reg = SyncRegistry()
        reg.register(ClaudeAgentsWriter())
        reg.register(CopilotAgentsWriter())
        reg.register(CursorAgentsWriter())

        data = _data()
        results = run_sync(
            data,
            tmp_path,
            tool_id=None,
            concern=SyncConcern.AGENTS,
            installed_tools=[AIToolID.CLAUDE, AIToolID.COPILOT, AIToolID.CURSOR],
            registry=reg,
        )

        tool_ids = [r.tool_id for r in results]
        assert AIToolID.CLAUDE in tool_ids
        assert AIToolID.COPILOT in tool_ids
        assert AIToolID.CURSOR in tool_ids

        # Gitignore should have been updated
        assert (tmp_path / ".gitignore").exists()
        content = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        assert _BLOCK_START in content

    def test_dry_run_no_files_written(self, tmp_path: Path) -> None:
        from crossby.sync import run_sync
        from crossby.sync.base import SyncRegistry

        _make_source(tmp_path, ["a.md"])
        reg = SyncRegistry()
        reg.register(ClaudeAgentsWriter())

        data = _data()
        run_sync(
            data,
            tmp_path,
            concern=SyncConcern.AGENTS,
            installed_tools=[AIToolID.CLAUDE],
            dry_run=True,
            registry=reg,
        )

        assert not (tmp_path / ".claude" / "agents").exists()
        assert not (tmp_path / ".gitignore").exists()

    def test_force_forwarded_to_writers(self, tmp_path: Path) -> None:
        """force=True passed to run_sync is forwarded to each writer."""
        from crossby.sync import run_sync
        from crossby.sync.base import SyncRegistry

        _make_source(tmp_path, ["a.md"])
        # Create a real directory at the target — without force this would error
        target = tmp_path / ".claude" / "agents"
        target.mkdir(parents=True)
        (target / "unmanaged.txt").write_text("user content", encoding="utf-8")

        reg = SyncRegistry()
        reg.register(ClaudeAgentsWriter())

        data = _data()
        results = run_sync(
            data,
            tmp_path,
            concern=SyncConcern.AGENTS,
            installed_tools=[AIToolID.CLAUDE],
            force=True,
            registry=reg,
        )

        actions = [r.action for r in results]
        assert "created" in actions  # force allowed the backup+replace


# ---------------------------------------------------------------------------
# CodexAgentsWriter translates markdown → TOML
# ---------------------------------------------------------------------------


class TestCodexAgentsTranslate:
    """CodexAgentsWriter writes per-file TOML to .codex/agents/, not a symlink."""

    def _claude_agent(
        self,
        source_dir: Path,
        name: str,
        *,
        body: str = "Do work.",
        permission_mode: str | None = None,
        tools: list[str] | None = None,
        model: str | None = None,
        effort: str | None = None,
    ) -> None:
        lines = [
            "---",
            f"name: {name}",
            "description: A test agent.",
        ]
        if model is not None:
            lines.append(f"model: {model}")
        if effort is not None:
            lines.append(f"effort: {effort}")
        if permission_mode is not None:
            lines.append(f"permissionMode: {permission_mode}")
        if tools:
            lines.append("tools:")
            for tool in tools:
                lines.append(f"  - {tool}")
        lines.append("---")
        lines.append(body)
        (source_dir / f"{name}.md").write_text("\n".join(lines) + "\n")

    def test_writes_toml_files_under_codex_agents(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent(source, "release-lead")

        result = CodexAgentsWriter().sync(_data(), tmp_path)

        assert result.action == "created"
        out = tmp_path / ".codex" / "agents" / "release-lead.toml"
        assert out.is_file()
        parsed = tomllib.loads(out.read_text(encoding="utf-8"))
        assert parsed["name"] == "release-lead"
        assert parsed["description"] == "A test agent."
        assert "Do work." in parsed["developer_instructions"]

    def test_old_dot_agents_path_is_not_touched(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._claude_agent(source, "x")

        CodexAgentsWriter().sync(_data(), tmp_path)
        assert not (tmp_path / ".agents").exists(), (
            "old codex path .agents/ must not be created — that's the skills root"
        )

    def test_translates_permission_mode_to_sandbox(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent(source, "x", permission_mode="acceptEdits")

        CodexAgentsWriter().sync(_data(), tmp_path)
        out = tmp_path / ".codex" / "agents" / "x.toml"
        parsed = tomllib.loads(out.read_text(encoding="utf-8"))
        # PR #46's emit_codex maps acceptEdits → workspace-write via the
        # subagents IR. The mapping happens at parse time on the Claude
        # side.
        assert parsed.get("sandbox_mode") == "workspace-write"

    def test_unmapped_permission_mode_emits_manual_fix(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent(source, "x", permission_mode="plan")

        CodexAgentsWriter().sync(_data(), tmp_path)
        parsed = tomllib.loads(
            (tmp_path / ".codex" / "agents" / "x.toml").read_text(encoding="utf-8")
        )
        # 'plan' has no Codex equivalent — emit_codex drops it with a warning
        # that surfaces in the manual-fix block embedded in
        # developer_instructions.
        assert "sandbox_mode" not in parsed
        assert "Manual migration required" in parsed["developer_instructions"]
        assert "permission_mode" in parsed["developer_instructions"]

    def test_tools_become_manual_fix(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent(source, "x", tools=["Read", "Bash"])

        CodexAgentsWriter().sync(_data(), tmp_path)
        parsed = tomllib.loads(
            (tmp_path / ".codex" / "agents" / "x.toml").read_text(encoding="utf-8")
        )
        instr = parsed["developer_instructions"]
        # emit_codex collapses the per-tool allowlist into sandbox_mode and
        # warns that the fine-grained list was dropped.
        assert "no per-agent tool allowlist" in instr or "tools" in instr

    def test_model_and_effort_translated(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent(source, "x", model="claude-sonnet-4.6", effort="high")

        CodexAgentsWriter().sync(_data(), tmp_path)
        parsed = tomllib.loads(
            (tmp_path / ".codex" / "agents" / "x.toml").read_text(encoding="utf-8")
        )
        # _translate_codex_agent pre-translates Claude-family models +
        # effort tiers to GPT equivalents before calling emit_codex (which
        # would otherwise pass the Claude model id through verbatim).
        assert parsed["model"] == "gpt-5.4-mini"
        # Sonnet HIGH bumps to XHIGH per family-aware mapping.
        assert parsed["model_reasoning_effort"] == "xhigh"

    def test_idempotent(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._claude_agent(source, "x")

        first = CodexAgentsWriter().sync(_data(), tmp_path)
        second = CodexAgentsWriter().sync(_data(), tmp_path)

        assert first.action == "created"
        assert second.action == "skipped"

    def test_stale_toml_removed(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._claude_agent(source, "keep")
        self._claude_agent(source, "drop")

        CodexAgentsWriter().sync(_data(), tmp_path)
        # Remove one source file.
        (source / "drop.md").unlink()

        result = CodexAgentsWriter().sync(_data(), tmp_path)
        assert result.action in {"created", "updated", "skipped"}
        assert (tmp_path / ".codex" / "agents" / "keep.toml").is_file()
        assert not (tmp_path / ".codex" / "agents" / "drop.toml").exists()

    def test_dry_run_writes_nothing(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._claude_agent(source, "x")

        result = CodexAgentsWriter().sync(_data(), tmp_path, dry_run=True)

        assert result.action in {"created", "updated"}
        assert not (tmp_path / ".codex" / "agents" / "x.toml").exists()

    def test_codex_source_round_trip(self, tmp_path: Path) -> None:
        """When source is already TOML, parse and re-render so the output stays
        canonical (and any older format quirks are normalised)."""
        import tomllib

        import tomli_w

        source = _make_source(tmp_path, [])
        # Simulate an existing .codex/agents/x.toml as the canonical source.
        (source / "x.toml").write_text(
            tomli_w.dumps(
                {
                    "name": "x",
                    "description": "y",
                    "developer_instructions": "Do work.",
                }
            ),
            encoding="utf-8",
        )

        result = CodexAgentsWriter().sync(_data(), tmp_path)
        assert result.action in {"created", "updated"}
        out = tmp_path / ".codex" / "agents" / "x.toml"
        parsed = tomllib.loads(out.read_text(encoding="utf-8"))
        assert parsed["name"] == "x"
        assert "Do work." in parsed["developer_instructions"]

    def test_no_source_files_skipped(self, tmp_path: Path) -> None:
        _make_source(tmp_path, [])

        result = CodexAgentsWriter().sync(_data(), tmp_path)
        assert result.action == "skipped"
        assert "no agents to translate" in (result.message or "")


# ---------------------------------------------------------------------------
# Legacy `.agents/` codex layout detection
# ---------------------------------------------------------------------------


class TestLegacyCodexAgentsDetection:
    """Pre-PR codex agents lived at `.agents/`; new path is `.codex/agents/`.
    A small detector warns users on next sync so they can clean up."""

    def test_returns_none_when_no_legacy_dir(self, tmp_path: Path) -> None:
        from crossby.sync.agents import detect_legacy_codex_agents

        assert detect_legacy_codex_agents(tmp_path) is None

    def test_returns_path_when_dot_agents_is_symlink(self, tmp_path: Path) -> None:
        from crossby.sync.agents import detect_legacy_codex_agents

        source = tmp_path / "src"
        source.mkdir()
        (tmp_path / ".agents").symlink_to(source)
        assert detect_legacy_codex_agents(tmp_path) == tmp_path / ".agents"

    def test_returns_path_when_dot_agents_has_top_level_md(self, tmp_path: Path) -> None:
        from crossby.sync.agents import detect_legacy_codex_agents

        legacy = tmp_path / ".agents"
        legacy.mkdir()
        (legacy / "release-lead.md").write_text("# x", encoding="utf-8")
        assert detect_legacy_codex_agents(tmp_path) == legacy

    def test_skills_only_dir_is_not_legacy(self, tmp_path: Path) -> None:
        # `.agents/skills/` is Codex's current skills root and must not trip
        # the warning.
        from crossby.sync.agents import detect_legacy_codex_agents

        skills = tmp_path / ".agents" / "skills" / "my-skill"
        skills.mkdir(parents=True)
        (skills / "SKILL.md").write_text("# x", encoding="utf-8")
        assert detect_legacy_codex_agents(tmp_path) is None

    def test_writer_invokes_warning_helper(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Real CodexAgentsWriter run calls _warn_legacy_codex_agents_path
        when the legacy `.agents/` symlink exists.

        We mock the helper directly rather than chasing structlog's
        process-wide writer pipeline (which can be reconfigured by other
        tests in the suite, making capsys-based assertions flaky).
        """
        from crossby.sync import agents as agents_mod
        from crossby.sync.agents import CodexAgentsWriter

        source = _make_source(tmp_path, [])
        (source / "x.md").write_text(
            "---\nname: x\ndescription: y\n---\nbody",
            encoding="utf-8",
        )
        (tmp_path / ".agents").symlink_to(source)

        called: list[Path] = []

        def _spy(project_root: Path) -> None:
            called.append(project_root)

        monkeypatch.setattr(agents_mod, "_warn_legacy_codex_agents_path", _spy)
        result = CodexAgentsWriter().sync(_data(), tmp_path)

        assert result.action in {"created", "updated"}
        assert called == [tmp_path]


# ---------------------------------------------------------------------------
# Agents translate strategy
# ---------------------------------------------------------------------------


class TestAgentsTranslateStrategy:
    """`--strategy translate` annotates Claude-specific lossy fields with a
    manual-fix block when the target is a markdown-shape tool other than Claude.

    Codex agents are handled by CodexAgentsWriter (TOML); this covers the
    Claude → Cursor / Gemini / Copilot path."""

    def _make_claude_agent(
        self,
        source_dir: Path,
        name: str,
        *,
        permission_mode: str | None = None,
        skills_list: list[str] | None = None,
        tools: list[str] | None = None,
        disallowed: list[str] | None = None,
    ) -> None:
        lines = ["---", f"name: {name}", "description: A test agent."]
        if permission_mode is not None:
            lines.append(f"permissionMode: {permission_mode}")
        if skills_list:
            lines.append("skills:")
            for s in skills_list:
                lines.append(f"  - {s}")
        if tools:
            lines.append("tools:")
            for t in tools:
                lines.append(f"  - {t}")
        if disallowed:
            lines.append("disallowedTools:")
            for d in disallowed:
                lines.append(f"  - {d}")
        lines.extend(["---", "Body.", ""])
        (source_dir / f"{name}.md").write_text("\n".join(lines))

    def test_unmappable_permission_mode_emits_manual_fix_for_cursor(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x", permission_mode="plan")
        result = CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        assert result.action == "created"
        out = tmp_path / ".cursor" / "agents" / "x.md"
        text = out.read_text(encoding="utf-8")
        assert "<!-- crossby:manual-fix:start -->" in text
        # Note generated by the subagents.emit_cursor warning loop.
        assert "permission_mode" in text

    def test_skills_preload_emits_manual_fix(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x", skills_list=["release-notes"])
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        text = (tmp_path / ".cursor" / "agents" / "x.md").read_text(encoding="utf-8")
        assert "<!-- crossby:manual-fix:start -->" in text
        # The skills list itself isn't preserved in the rendered cursor file
        # (Cursor has no per-agent skill binding); the warning names the
        # `skills` field and explains why it was dropped.
        assert "skills" in text

    def test_disallowed_tools_emits_manual_fix(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x", disallowed=["Write"])
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        text = (tmp_path / ".cursor" / "agents" / "x.md").read_text(encoding="utf-8")
        # disallowed_tools is dropped by emit_cursor with a warning that
        # surfaces in the manual-fix block.
        assert "<!-- crossby:manual-fix:start -->" in text
        assert "disallowed_tools" in text

    def test_no_manual_fix_when_only_neutral_fields(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x")  # no Claude-only fields
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        text = (tmp_path / ".cursor" / "agents" / "x.md").read_text(encoding="utf-8")
        assert "<!-- crossby:manual-fix" not in text

    def test_claude_target_never_gets_manual_fix(self, tmp_path: Path) -> None:
        # When the target IS Claude, the fields apply natively and shouldn't
        # be annotated.
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x", permission_mode="plan")
        result = ClaudeAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        assert result.action == "created"
        text = (tmp_path / ".claude" / "agents" / "x.md").read_text(encoding="utf-8")
        assert "<!-- crossby:manual-fix" not in text

    def test_idempotent_translate(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x", permission_mode="plan")
        first = CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        second = CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        assert first.action == "created"
        assert second.action == "skipped"
        assert "already translated" in (second.message or "")

    def test_stale_md_removed(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "keep")
        self._make_claude_agent(source, "drop")
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        (source / "drop.md").unlink()
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        assert (tmp_path / ".cursor" / "agents" / "keep.md").is_file()
        assert not (tmp_path / ".cursor" / "agents" / "drop.md").exists()

    def test_dry_run_writes_nothing(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x")
        result = CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path, dry_run=True)
        assert result.action in {"created", "updated"}
        assert "dry-run" in (result.message or "")
        assert not (tmp_path / ".cursor" / "agents").exists()

    def test_dry_run_reports_manual_fix_count(self, tmp_path: Path) -> None:
        """Dry-run should surface the number of manual-fix items so --plan
        can summarize the manual review surface accurately."""
        source = _make_source(tmp_path, [])
        # One agent that triggers a manual-fix block (Claude permissionMode),
        # one that doesn't.
        self._make_claude_agent(source, "needs_fix", permission_mode="plan")
        self._make_claude_agent(source, "clean")
        result = CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path, dry_run=True)
        assert "1 manual-fix" in (result.message or "")
        # And the hint detector in plan.summarize_plan should bucket this row.
        from crossby.sync.plan import summarize_plan

        summary = summarize_plan([result])
        assert summary.manual_fix_count == 1

    def test_dry_run_no_manual_fix_omits_count(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "clean")
        result = CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path, dry_run=True)
        assert "manual-fix" not in (result.message or "")

    def test_re_translate_after_source_change(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x")  # no Claude-only fields initially
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        text_before = (tmp_path / ".cursor" / "agents" / "x.md").read_text(encoding="utf-8")
        assert "<!-- crossby:manual-fix" not in text_before

        # Add a Claude-only field — re-running should produce a manual-fix block.
        self._make_claude_agent(source, "x", permission_mode="plan")
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        text_after = (tmp_path / ".cursor" / "agents" / "x.md").read_text(encoding="utf-8")
        assert text_after.count("<!-- crossby:manual-fix:start -->") == 1
        assert "permission_mode" in text_after


class TestCopilotAgentsTranslate:
    """``CopilotAgentsWriter`` must honor ``--strategy translate`` and emit
    rendered ``.agent.md`` files with manual-fix notes — previously it fell
    through to the symlink path, producing source-shape symlinks instead."""

    def _make_claude_agent(
        self,
        source_dir: Path,
        name: str,
        *,
        permission_mode: str | None = None,
    ) -> None:
        lines = ["---", f"name: {name}", "description: A test agent."]
        if permission_mode is not None:
            lines.append(f"permissionMode: {permission_mode}")
        lines.extend(["---", "Body.", ""])
        (source_dir / f"{name}.md").write_text("\n".join(lines))

    def test_translate_writes_rendered_agent_md(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x")
        result = CopilotAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        assert result.action == "created"
        out = tmp_path / ".github" / "agents" / "x.agent.md"
        assert out.is_file()
        # Translate must produce a real file, not a symlink.
        assert not out.is_symlink()
        text = out.read_text(encoding="utf-8")
        assert "name: x" in text

    def test_translate_emits_manual_fix_for_claude_only_field(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x", permission_mode="plan")
        result = CopilotAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        assert result.action == "created"
        text = (tmp_path / ".github" / "agents" / "x.agent.md").read_text(encoding="utf-8")
        assert "<!-- crossby:manual-fix:start -->" in text
        assert "permission_mode" in text

    def test_translate_replaces_existing_symlink(self, tmp_path: Path) -> None:
        """A prior symlink-strategy run should not block translate from writing."""
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x")
        # First, symlink strategy.
        CopilotAgentsWriter().sync(_data(strategy="symlink"), tmp_path)
        target = tmp_path / ".github" / "agents" / "x.agent.md"
        assert target.is_symlink()
        # Now translate — the rendered file must replace the symlink.
        result = CopilotAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        assert result.action == "updated"
        assert not target.is_symlink()
        assert target.is_file()

    def test_translate_dry_run_writes_nothing(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "x")
        result = CopilotAgentsWriter().sync(_data(strategy="translate"), tmp_path, dry_run=True)
        assert result.action in {"created", "updated"}
        assert "dry-run" in (result.message or "")
        assert not (tmp_path / ".github" / "agents").exists()

    def test_translate_stale_cleanup(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        self._make_claude_agent(source, "keep")
        self._make_claude_agent(source, "drop")
        CopilotAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        (source / "drop.md").unlink()
        CopilotAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        assert (tmp_path / ".github" / "agents" / "keep.agent.md").is_file()
        assert not (tmp_path / ".github" / "agents" / "drop.agent.md").exists()


class TestAgentsTranslateNoDuplicateManualFix:
    """A source agent that already contains a `<!-- crossby:manual-fix -->`
    block must not accumulate a second block on re-translate. Regression
    test for a real bug discovered in review: ``_ir_body_with_manual_fix``
    used to ``append`` without stripping the prior block."""

    def test_source_with_manual_fix_block_is_replaced_not_stacked(self, tmp_path: Path) -> None:
        source = _make_source(tmp_path, [])
        (source / "x.md").write_text(
            "---\n"
            "name: x\n"
            "description: y\n"
            "permissionMode: plan\n"
            "---\n"
            "Body.\n\n"
            "<!-- crossby:manual-fix:start -->\n"
            "## Manual migration required\n\n"
            "- [dropped] permission_mode: stale note\n"
            "<!-- crossby:manual-fix:end -->\n",
            encoding="utf-8",
        )
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        out = tmp_path / ".cursor" / "agents" / "x.md"
        text = out.read_text(encoding="utf-8")
        assert text.count("<!-- crossby:manual-fix:start -->") == 1
        # The stale message should be gone — only the fresh emit warning text
        # belongs in the block now.
        assert "stale note" not in text

    def test_source_with_only_stale_block_and_no_lossy_fields_strips_block(
        self, tmp_path: Path
    ) -> None:
        # Source has a leftover block but no Claude-only fields to translate.
        # The strip path in _ir_body_with_manual_fix should still run.
        source = _make_source(tmp_path, [])
        (source / "x.md").write_text(
            "---\n"
            "name: x\n"
            "description: y\n"
            "---\n"
            "Body.\n\n"
            "<!-- crossby:manual-fix:start -->\n"
            "## Manual migration required\n\n"
            "- [dropped] leftover from a previous run\n"
            "<!-- crossby:manual-fix:end -->\n",
            encoding="utf-8",
        )
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        text = (tmp_path / ".cursor" / "agents" / "x.md").read_text(encoding="utf-8")
        assert "leftover from a previous run" not in text
        assert "<!-- crossby:manual-fix" not in text

    def test_missing_name_in_frontmatter_falls_back_to_filename(self, tmp_path: Path) -> None:
        """Parsers should infer name from source_path when frontmatter lacks one.

        Before source_path was wired through, every nameless agent collapsed
        to the literal string ``agent`` in the rendered output. Now distinct
        filenames produce distinct names.
        """
        source = _make_source(tmp_path, [])
        # Two source agents, neither declaring ``name`` in frontmatter.
        (source / "reviewer.md").write_text(
            "---\ndescription: reviews PRs\n---\nBody.\n",
            encoding="utf-8",
        )
        (source / "writer.md").write_text(
            "---\ndescription: writes docs\n---\nBody.\n",
            encoding="utf-8",
        )
        CursorAgentsWriter().sync(_data(strategy="translate"), tmp_path)
        reviewer = (tmp_path / ".cursor" / "agents" / "reviewer.md").read_text(encoding="utf-8")
        writer = (tmp_path / ".cursor" / "agents" / "writer.md").read_text(encoding="utf-8")
        assert "name: reviewer" in reviewer
        assert "name: writer" in writer

    def test_copilot_source_filenames_normalized_for_markdown_targets(self, tmp_path: Path) -> None:
        """Copilot ``foo.agent.md`` should land as ``foo.md`` under Claude/Cursor/Gemini.

        Keeping the ``.agent.md`` suffix in a markdown target's directory
        would leave the file invisible to that tool (Claude expects plain
        ``.md`` filenames under ``.claude/agents/``).
        """
        # Source dir is the Copilot path, with a Copilot-shaped filename.
        source = tmp_path / ".github" / "agents"
        source.mkdir(parents=True)
        (source / "reviewer.agent.md").write_text(
            "---\nname: reviewer\ndescription: reviews PRs\n---\nBody.\n",
            encoding="utf-8",
        )
        data = _data(source=".github/agents", strategy="translate")
        CursorAgentsWriter().sync(data, tmp_path)
        assert (tmp_path / ".cursor" / "agents" / "reviewer.md").is_file()
        # The double-suffix form must NOT be present.
        assert not (tmp_path / ".cursor" / "agents" / "reviewer.agent.md").exists()


class TestCodexPermissionModeMappings:
    """My patch to subagents.emit_codex maps Claude `permissionMode` →
    Codex `sandbox_mode` for the three values that translate cleanly,
    and suppresses the dropped-Claude-only warning when the mapping
    fires."""

    def _claude_agent_with_mode(self, source: Path, name: str, mode: str) -> None:
        (source / f"{name}.md").write_text(
            f"---\nname: {name}\ndescription: y\npermissionMode: {mode}\n---\nBody.\n",
            encoding="utf-8",
        )

    def test_accept_edits_maps_to_workspace_write(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent_with_mode(source, "x", "acceptEdits")
        CodexAgentsWriter().sync(_data(), tmp_path)
        parsed = tomllib.loads(
            (tmp_path / ".codex" / "agents" / "x.toml").read_text(encoding="utf-8")
        )
        assert parsed["sandbox_mode"] == "workspace-write"
        # When the mapping fires the dropped-Claude-only warning should NOT
        # appear in developer_instructions.
        assert "permission_mode" not in parsed["developer_instructions"]

    def test_read_only_maps_to_read_only(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent_with_mode(source, "x", "readOnly")
        CodexAgentsWriter().sync(_data(), tmp_path)
        parsed = tomllib.loads(
            (tmp_path / ".codex" / "agents" / "x.toml").read_text(encoding="utf-8")
        )
        assert parsed["sandbox_mode"] == "read-only"

    def test_bypass_permissions_maps_to_danger_full_access(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent_with_mode(source, "x", "bypassPermissions")
        CodexAgentsWriter().sync(_data(), tmp_path)
        parsed = tomllib.loads(
            (tmp_path / ".codex" / "agents" / "x.toml").read_text(encoding="utf-8")
        )
        assert parsed["sandbox_mode"] == "danger-full-access"

    def test_unmapped_mode_falls_through_to_warning(self, tmp_path: Path) -> None:
        import tomllib

        source = _make_source(tmp_path, [])
        self._claude_agent_with_mode(source, "x", "plan")
        CodexAgentsWriter().sync(_data(), tmp_path)
        parsed = tomllib.loads(
            (tmp_path / ".codex" / "agents" / "x.toml").read_text(encoding="utf-8")
        )
        # No sandbox_mode set; the dropped warning appears in the manual-fix
        # block embedded in developer_instructions.
        assert "sandbox_mode" not in parsed
        assert "permission_mode" in parsed["developer_instructions"]
