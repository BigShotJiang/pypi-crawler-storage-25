"""Tests for rules .gitignore managed-block logic."""

from pathlib import Path

from crossby.models.ai import AIToolID
from crossby.sync.base import SyncData
from crossby.sync.rules import _GITIGNORE_BLOCK_ID, update_rules_gitignore

# Derive the markers from the block ID, matching gitignore_utils conventions
_BLOCK_START = f"# >>> crossby {_GITIGNORE_BLOCK_ID} (generated — do not edit) >>>"
_BLOCK_END = f"# <<< crossby {_GITIGNORE_BLOCK_ID} <<<"


def _cfg(
    source: str = "AGENTS.md",
    gitignore: bool = True,
) -> SyncData:
    return SyncData(
        rules_source=source,
        rules_gitignore=gitignore,
    )


def _setup_source(tmp_path: Path, source: str = "AGENTS.md") -> None:
    """Create the source file so gitignore entries can be computed."""
    p = tmp_path / source
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text("# rules\n")


class TestUpdateRulesGitignore:
    def test_add_block_to_empty_file(self, tmp_path: Path):
        _setup_source(tmp_path)
        result = update_rules_gitignore(_cfg(), tmp_path)
        assert result is not None

        content = (tmp_path / ".gitignore").read_text()
        assert _BLOCK_START in content
        assert _BLOCK_END in content
        assert ".cursorrules" in content
        assert "CLAUDE.md" in content

    def test_add_block_to_existing_gitignore(self, tmp_path: Path):
        _setup_source(tmp_path)
        (tmp_path / ".gitignore").write_text("node_modules/\n.env\n")
        update_rules_gitignore(_cfg(), tmp_path)

        content = (tmp_path / ".gitignore").read_text()
        assert content.startswith("node_modules/")
        assert "CLAUDE.md" in content

    def test_update_existing_block(self, tmp_path: Path):
        _setup_source(tmp_path)
        # First: only claude
        update_rules_gitignore(
            _cfg(),
            tmp_path,
            installed_tools=[AIToolID.CLAUDE],
        )
        # Then: claude + gemini
        update_rules_gitignore(
            _cfg(),
            tmp_path,
            installed_tools=[AIToolID.CLAUDE, AIToolID.GEMINI],
        )

        content = (tmp_path / ".gitignore").read_text()
        assert "GEMINI.md" in content
        assert content.count(_BLOCK_START) == 1

    def test_no_modification_when_up_to_date(self, tmp_path: Path):
        _setup_source(tmp_path)
        update_rules_gitignore(_cfg(), tmp_path)
        result = update_rules_gitignore(_cfg(), tmp_path)
        assert result is None

    def test_preserves_user_entries(self, tmp_path: Path):
        _setup_source(tmp_path)
        (tmp_path / ".gitignore").write_text("# my custom ignore\n*.pyc\n")
        update_rules_gitignore(_cfg(), tmp_path)

        content = (tmp_path / ".gitignore").read_text()
        assert "# my custom ignore" in content
        assert "*.pyc" in content

    def test_entries_are_sorted(self, tmp_path: Path):
        _setup_source(tmp_path)
        update_rules_gitignore(_cfg(), tmp_path)
        content = (tmp_path / ".gitignore").read_text()
        lines = content.splitlines()
        start = lines.index(_BLOCK_START)
        end = lines.index(_BLOCK_END)
        entries = lines[start + 1 : end]
        assert entries == sorted(entries)

    def test_creates_gitignore_if_missing(self, tmp_path: Path):
        _setup_source(tmp_path)
        assert not (tmp_path / ".gitignore").exists()
        update_rules_gitignore(_cfg(), tmp_path)
        assert (tmp_path / ".gitignore").exists()

    def test_orphan_start_marker_does_not_duplicate(self, tmp_path: Path):
        """Orphan _BLOCK_START without _BLOCK_END should not create a second block."""
        _setup_source(tmp_path)
        (tmp_path / ".gitignore").write_text(f"node_modules/\n{_BLOCK_START}\nCLAUDE.md\n")
        update_rules_gitignore(_cfg(), tmp_path)

        content = (tmp_path / ".gitignore").read_text()
        assert content.count(_BLOCK_START) == 1

    def test_returns_none_when_disabled(self, tmp_path: Path):
        _setup_source(tmp_path)
        result = update_rules_gitignore(_cfg(gitignore=False), tmp_path)
        assert result is None

    def test_returns_none_when_no_installed_tools(self, tmp_path: Path):
        _setup_source(tmp_path)
        result = update_rules_gitignore(_cfg(), tmp_path, installed_tools=[])
        assert result is None

    def test_skips_circular_target(self, tmp_path: Path):
        """AGENTS.md as source + codex target → codex excluded from gitignore."""
        _setup_source(tmp_path)
        update_rules_gitignore(
            _cfg(),
            tmp_path,
            installed_tools=[AIToolID.CLAUDE, AIToolID.CODEX],
        )

        content = (tmp_path / ".gitignore").read_text()
        assert "CLAUDE.md" in content
        # AGENTS.md is both source and codex target — should NOT be in gitignore
        assert "AGENTS.md" not in content

    def test_all_enabled_targets_present_on_idempotent_run(self, tmp_path: Path):
        """Gitignore block includes ALL enabled targets, not just newly-synced ones."""
        _setup_source(tmp_path)
        data = _cfg()
        # First run creates the block
        update_rules_gitignore(data, tmp_path)
        content1 = (tmp_path / ".gitignore").read_text()
        assert "CLAUDE.md" in content1
        assert ".cursorrules" in content1

        # Second run (idempotent) — block should remain identical
        result = update_rules_gitignore(data, tmp_path)
        assert result is None  # No change
        content2 = (tmp_path / ".gitignore").read_text()
        assert content1 == content2

    def test_installed_tools_filter_excludes_uninstalled(self, tmp_path: Path):
        """installed_tools limits gitignore entries to tools that actually ran."""
        _setup_source(tmp_path)
        data = _cfg()  # all targets enabled
        update_rules_gitignore(data, tmp_path, installed_tools=[AIToolID.CLAUDE])

        content = (tmp_path / ".gitignore").read_text()
        assert "CLAUDE.md" in content
        assert ".cursorrules" not in content
        assert "GEMINI.md" not in content

    def test_installed_tools_none_includes_all_enabled(self, tmp_path: Path):
        """When installed_tools is None, all known entries are included."""
        _setup_source(tmp_path)
        data = _cfg()
        update_rules_gitignore(data, tmp_path, installed_tools=None)

        content = (tmp_path / ".gitignore").read_text()
        assert "CLAUDE.md" in content
        assert ".cursorrules" in content
