"""Claude Code adapter."""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any, ClassVar

import structlog

from crossby.ai_tools.base import AbstractAITool
from crossby.handoff.models import ConversationTranscript, SessionRef
from crossby.handoff.readers import claude as claude_reader
from crossby.models.ai import (
    AIToolCapabilities,
    AIToolID,
    AIToolType,
    EffortLevel,
    TokenUsage,
)

logger = structlog.get_logger()


def _encode_claude_path(path: Path) -> str:
    """Encode a filesystem path the way Claude Code does for project directories.

    Claude Code replaces ``/`` with ``-`` **and** ``.`` with ``-``.
    """
    return str(path).replace("/", "-").replace(".", "-")


class ClaudeAdapter(AbstractAITool):
    """Adapter for Claude Code CLI."""

    TOOL_ID: ClassVar[AIToolID] = AIToolID.CLAUDE

    def capabilities(self) -> AIToolCapabilities:
        return AIToolCapabilities(
            tool_id=AIToolID.CLAUDE,
            display_name="Claude Code",
            binary="claude",
            tool_type=AIToolType.TERMINAL,
            supports_model_flag=True,
            headless_flag="--print",
            supports_headless=True,
            supports_effort=True,
            supports_yolo=True,
            supports_resume=True,
            supports_trusted_dirs=True,
            supports_plan_mode=True,
        )

    def build_resume_command(self, session_id: str) -> list[str] | None:
        """Resume a Claude session: ``claude --resume <session_id>``."""
        return ["claude", "--resume", session_id]

    def locate_sessions(self, project_path: Path) -> list[SessionRef]:
        return claude_reader.locate_sessions(project_path)

    def read_session(self, ref: SessionRef) -> ConversationTranscript:
        return claude_reader.read_session(ref)

    def initial_message_args(self, prompt: str) -> list[str]:
        """Claude accepts the initial message as a positional argument."""
        return [prompt]

    def parse_transcript(self, transcript_path: Path) -> TokenUsage:
        usage = super().parse_transcript(transcript_path)
        # Standardize model IDs from Claude's dashed format to canonical dotted format
        for breakdown in usage.model_breakdown:
            breakdown.model = self.standardize_model_id(breakdown.model)
        return usage

    def is_model_compatible(self, model: str) -> bool:
        """Claude CLI accepts only claude-* model IDs."""
        return model.lower().startswith("claude-")

    def plan_mode_args(self) -> list[str]:
        """Claude supports --permission-mode plan."""
        return ["--permission-mode", "plan"]

    def plan_dir_args(self, plan_dir: str) -> list[str]:
        """Claude uses --add-dir for plan directory access."""
        return ["--add-dir", plan_dir]

    def normalize_model_format(self, model_id: str) -> str:
        """Claude uses dashed format for model IDs."""
        if model_id.startswith("claude-"):
            import re

            # Convert claude-haiku-4.5 -> claude-haiku-4-5
            return re.sub(r"(\d)\.(\d)", r"\1-\2", model_id)
        return model_id

    def standardize_model_id(self, raw_model_id: str) -> str:
        """Convert Claude's dashed format back to the internal dotted format."""
        if raw_model_id.startswith("claude-"):
            import re

            # Convert claude-haiku-4-5 -> claude-haiku-4.5
            return re.sub(r"(\d)-(\d)", r"\1.\2", raw_model_id)
        return raw_model_id

    def preserve_session_data(self, working_dir: Path, main_checkout_path: Path) -> bool:
        """Copy Claude Code session data from source directory to target's project dir.

        Claude Code stores sessions in ``~/.claude/projects/<encoded-path>/``.
        The path encoding replaces every ``/`` with ``-`` **and** every ``.``
        with ``-``, so ``/Users/foo/.worktrees/bar`` becomes
        ``-Users-foo--worktrees-bar``.

        Files are copied without overwriting any that already exist in the
        target's session directory, so existing memory and settings are
        preserved.
        """
        claude_projects_dir = Path.home() / ".claude" / "projects"

        wt_encoded = _encode_claude_path(working_dir)
        main_encoded = _encode_claude_path(main_checkout_path)

        wt_session_dir = claude_projects_dir / wt_encoded
        main_session_dir = claude_projects_dir / main_encoded

        if not wt_session_dir.exists():
            logger.debug(
                "claude.preserve_session_data.no_source",
                working_dir=str(working_dir),
            )
            return True

        main_session_dir.mkdir(parents=True, exist_ok=True)

        copied = 0
        for item in wt_session_dir.iterdir():
            dest = main_session_dir / item.name
            if dest.exists():
                continue
            if item.is_file():
                shutil.copy2(item, dest)
                copied += 1
            elif item.is_dir():
                shutil.copytree(item, dest)
                copied += 1

        logger.info(
            "claude.preserve_session_data.copied",
            working_dir=str(working_dir),
            main=str(main_checkout_path),
            items=copied,
        )
        return True

    def session_data_dirs(self) -> list[str]:
        return [".claude"]

    def allowed_commands_args(self, commands: list[str]) -> list[str]:
        """Translate canonical patterns to Claude --allowedTools flags.

        Canonical ``"cmd:args"`` becomes ``"Bash(cmd:args)"``.
        """
        from crossby.config.claude_allowlist import canonical_to_claude

        patterns = [canonical_to_claude(cmd) for cmd in commands]
        if not patterns:
            return []
        return ["--allowedTools", *patterns]

    def structured_output_args(self, json_schema: dict[str, Any]) -> list[str]:
        return ["--output-format", "json", "--json-schema", json.dumps(json_schema)]

    def effort_args(self, effort: EffortLevel) -> list[str]:
        """Claude uses the native ``--effort <level>`` flag."""
        return ["--effort", effort.value]

    def yolo_args(self) -> list[str]:
        """Claude uses ``--dangerously-skip-permissions``."""
        return ["--dangerously-skip-permissions"]
